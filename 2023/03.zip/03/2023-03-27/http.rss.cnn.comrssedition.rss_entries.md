# Source:CNN, URL:http://rss.cnn.com/rss/edition.rss, language:en-US

## How a historic general strike brought Israel to a standstill
 - [https://www.cnn.com/videos/world/2023/03/27/israel-protests-netanyahu-vpx.cnn](https://www.cnn.com/videos/world/2023/03/27/israel-protests-netanyahu-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 23:06:31+00:00

Israel's political crisis escalated into uncharted territory as the country's largest trade union announced a "historic" strike shutting down transportation, universities, restaurants and retailers in protest against Prime Minister Benjamin Netanyahu's planned judicial overhaul. CNN's Hadas Gold reports.

## Terrifying video captures moment a coyote charges after toddler
 - [https://www.cnn.com/videos/us/2023/03/27/coyote-toddler-attack-doorbell-camera-affil-dnt-cprog-vpx.kpnx](https://www.cnn.com/videos/us/2023/03/27/coyote-toddler-attack-doorbell-camera-affil-dnt-cprog-vpx.kpnx)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 23:05:57+00:00

A home security camera catches a coyote attack involving a child in Scottsdale, Arizona. CNN affiliate KPNX reports.

## 'We too mean business': Russian civilian reacts to Putin's latest nuclear strategy
 - [https://www.cnn.com/videos/world/2023/03/27/putin-nuclear-weapons-russia-belarus-chance-lead-vpx.cnn](https://www.cnn.com/videos/world/2023/03/27/putin-nuclear-weapons-russia-belarus-chance-lead-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 22:20:01+00:00

Russian President Vladimir Putin says he plans to deploy tactical nuclear weapons to Belarus -- something he says the US has done for decades. CNN's Matthew Chance reports.

## Gwyneth Paltrow accuser testifies in ski trial: 'I've never been hit that hard'
 - [https://www.cnn.com/2023/03/27/entertainment/gwyneth-paltrow-ski-collision-trial-monday/index.html](https://www.cnn.com/2023/03/27/entertainment/gwyneth-paltrow-ski-collision-trial-monday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 21:20:36+00:00

The Utah civil trial involving actress Gwyneth Paltrow and a man who is accusing her of wrongdoing in relation to a 2016 ski collision resumed Monday for its second week of proceedings.

## Water is trapped in glass beads on the moon's surface, lunar samples show
 - [https://www.cnn.com/2023/03/27/world/water-moon-lunar-sample-chang-e-5-scn/index.html](https://www.cnn.com/2023/03/27/world/water-moon-lunar-sample-chang-e-5-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 20:51:05+00:00

Trillions of pounds of water may be strewn across the moon, trapped in tiny glass beads that could have formed when asteroids struck the lunar surface, according to a new study.

## Netanyahu says he will delay his judicial overhaul. But will that be enough for protesters?
 - [https://www.cnn.com/2023/03/27/middleeast/israel-netanyahu-judicial-overhaul-postpone-intl/index.html](https://www.cnn.com/2023/03/27/middleeast/israel-netanyahu-judicial-overhaul-postpone-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 20:44:13+00:00

Israeli Prime Minister Benjamin Netanyahu on Monday said he would postpone the votes on his planned judicial overhaul, but analysts say that may not be enough to cool the protests.

## Angry shooting survivor who is visiting Nashville jumps in at news conference
 - [https://www.cnn.com/videos/us/2023/03/27/shooting-survivor-mother-jumps-in-nashville-presser-vpx.wsmv](https://www.cnn.com/videos/us/2023/03/27/shooting-survivor-mother-jumps-in-nashville-presser-vpx.wsmv)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 20:28:46+00:00

Ashbey Beasley, a survivor of the Highland Park mass shooting that took place July 4, 2022, jumps in at the end of a Nashville police news conference to protest gun violence.

## Ex-National Enquirer publisher meets with Manhattan grand jury in Trump hush money probe
 - [https://www.cnn.com/2023/03/27/politics/david-pecker-national-enquirer-trump-hush-money-investigation/index.html](https://www.cnn.com/2023/03/27/politics/david-pecker-national-enquirer-trump-hush-money-investigation/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 20:15:48+00:00

The former head of the company that publishes the National Enquirer met Monday with the Manhattan grand jury investigating former President Donald Trump's alleged role in a scheme to pay hush money to an adult film star, one source confirms to CNN.

## US air travel is 'overwhelmed' and that's putting off some flyers, industry group says
 - [https://www.cnn.com/travel/article/spring-break-travel-2023-concerns/index.html](https://www.cnn.com/travel/article/spring-break-travel-2023-concerns/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 18:55:24+00:00

Travel is so busy this spring break season at Miami International Airport that officials are advising flyers to give themselves an extra hour -- arriving three hours, rather than two -- before a domestic flight.

## Actor Jonathan Majors arraigned on several assault and harassment charges
 - [https://www.cnn.com/2023/03/27/entertainment/jonathan-majors-arraigned/index.html](https://www.cnn.com/2023/03/27/entertainment/jonathan-majors-arraigned/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 18:39:06+00:00

Actor Jonathan Majors was arraigned on several assault and harassment charges Sunday, the Manhattan DA's office tells CNN.

## Madonna adds special tour date to 'celebrate' the queer community amid anti-LGBTQ legislation
 - [https://www.cnn.com/2023/03/27/entertainment/madonna-tennessee-concert-anti-lgbtq-legislation/index.html](https://www.cnn.com/2023/03/27/entertainment/madonna-tennessee-concert-anti-lgbtq-legislation/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 18:28:02+00:00

Amid a crushing flood of anti-trans and anti-drag bills cropping up throughout the country, music icon and social activist Madonna is making a change to her upcoming Celebration tour schedule.

## Prince Harry in London for hearing against Daily Mail publisher
 - [https://www.cnn.com/videos/world/2023/03/27/prince-harry-british-celebs-against-daily-mail-publisher-london-ath-vpx.cnn](https://www.cnn.com/videos/world/2023/03/27/prince-harry-british-celebs-against-daily-mail-publisher-london-ath-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 17:53:45+00:00

Prince Harry arrived at London's High Court to attend a hearing in his claim against Associated Newspapers Limited over allegations of unlawful information gathering. CNN's Max Foster has the report.

## Elian Gonzalez is becoming a lawmaker. Cuban exiles predicted this would happen
 - [https://www.cnn.com/videos/world/2023/03/27/elian-gonzalez-cuba-lawmaker-pkg-oppmann-intl-nr-contd-vpx.cnn](https://www.cnn.com/videos/world/2023/03/27/elian-gonzalez-cuba-lawmaker-pkg-oppmann-intl-nr-contd-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 17:51:06+00:00

Elian Gonzalez, famous for being the subject of a bitter custody battle, speaks to CNN's Patrick Oppmann from hometown in Cardenas, Cuba. He talked about his decision to become a lawmaker and his hope for Cuban exiles.

## White House says 50 US officials targeted with spyware as it rolls out new ban of hacking tools
 - [https://www.cnn.com/2023/03/27/politics/us-government-bans-spyware/index.html](https://www.cnn.com/2023/03/27/politics/us-government-bans-spyware/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 17:45:57+00:00

At least 50 US government officials are suspected or confirmed to have been targeted by invasive commercial spyware designed to hack mobile phones, a senior US administration official told reporters on Monday, revealing a far bigger number than previously known.

## Female shooter, who was possibly a teen, fatally shot by officers at Nashville school, authorities say
 - [https://www.cnn.com/2023/03/27/us/covenant-school-shooting-nashville-tennessee/index.html](https://www.cnn.com/2023/03/27/us/covenant-school-shooting-nashville-tennessee/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 17:30:18+00:00

[Breaking news update, 1:03 p.m. ET]

## Video shows scene right outside of Nashville school
 - [https://www.cnn.com/videos/us/2023/03/27/covenant-school-shooting-nashville-tennessee-vpx.cnn](https://www.cnn.com/videos/us/2023/03/27/covenant-school-shooting-nashville-tennessee-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 17:08:48+00:00

Nashville Fire Department tweeted the gunman involved in a shooting at Covenant School in Nashville, Tennessee, Monday is dead. Officials say the scene remains active and multiple patients are being treated.

## Multiple people hurt in Tennessee school shooting, officials say
 - [https://edition.cnn.com/us/live-news/nashville-shooting-covenant-school-03-27-23/index.html](https://edition.cnn.com/us/live-news/nashville-shooting-covenant-school-03-27-23/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 17:06:34.766675+00:00



## Multiple people hurt in Tennessee elementary school shooting, officials say
 - [https://edition.cnn.com/webview/us/live-news/nashville-shooting-covenant-school-03-27-23/index.html](https://edition.cnn.com/webview/us/live-news/nashville-shooting-covenant-school-03-27-23/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 17:06:34.660129+00:00



## White House scales up 'concern' rhetoric, marking rare involvement in Israeli domestic affairs
 - [https://www.cnn.com/2023/03/27/politics/joe-biden-israel-netanyahu/index.html](https://www.cnn.com/2023/03/27/politics/joe-biden-israel-netanyahu/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 17:04:41+00:00

A week after President Joe Biden spoke by phone with Israeli Prime Minister Benjamin Netanyahu to urge him to find a compromise on his planned judicial reforms, events on the ground in Israel continue to generate deep concern inside the White House — particularly as Biden prepares to highlight global democracy during a major summit this week.

## Israel judicial overhaul plans delayed amid huge protests, says Ben Gvir's Jewish Power party
 - [https://edition.cnn.com/webview/middleeast/live-news/israel-protests-netanyahu-updates-03-27-23-intl/index.html](https://edition.cnn.com/webview/middleeast/live-news/israel-protests-netanyahu-updates-03-27-23-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 16:06:38.045853+00:00



## Nick Cannon opens up about past antisemitic comments and his 'growth moment'
 - [https://www.cnn.com/2023/03/27/entertainment/nick-cannon-discusses-antisemitic-remarks-intl-scli/index.html](https://www.cnn.com/2023/03/27/entertainment/nick-cannon-discusses-antisemitic-remarks-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 16:03:09+00:00

TV personality Nick Cannon has addressed his past antisemitic remarks, describing the subsequent fallout as "a growth moment."

## Israel judicial overhaul plans delayed amid huge protests, says Ben Gvir's Jewish Power party
 - [https://www.cnn.com/2023/03/27/middleeast/israel-judicial-overhaul-protests-intl/index.html](https://www.cnn.com/2023/03/27/middleeast/israel-judicial-overhaul-protests-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 15:45:47+00:00

Benjamin Netanyahu's controversial plans to weaken Israel's judiciary will be put on hold after widespread strikes and protests drove the country to a standstill, the party of National Security Minister Itamar Ben Gvir announced Monday.

## A one-eyed rescue cat is the newest Cadbury Bunny and the first feline to hold the role
 - [https://www.cnn.com/2023/03/27/us/cadbury-bunny-crash-cat-commercial-trnd/index.html](https://www.cnn.com/2023/03/27/us/cadbury-bunny-crash-cat-commercial-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 14:56:03+00:00

A one-eyed cat named Crash is the first-ever cat to win the Cadbury Bunny contest, making him the brand's official "spokesbunny" for the year.

## A 1,500 pound great white shark named 'Breton' is currently swimming off the coast of North Carolina
 - [https://www.cnn.com/2023/03/27/us/great-white-shark-breton-north-carolina-trnd/index.html](https://www.cnn.com/2023/03/27/us/great-white-shark-breton-north-carolina-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 14:01:41+00:00

As spring breakers take to the beaches of North Carolina's Outer Banks, they might be joined by an aquatic friend spotted just off the coast: a great white shark named Breton.

## Twitter says portions of source code leaked online
 - [https://www.cnn.com/2023/03/27/tech/twitter-source-code-leaked/index.html](https://www.cnn.com/2023/03/27/tech/twitter-source-code-leaked/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 13:43:54+00:00

Twitter said parts of its proprietary code were posted online and had been exposed until Friday, when the company had the material removed from the web and filed for a court order to hunt down the source of the leak.

## Biden helped the people of Mississippi. As usual, Donald Trump helped himself
 - [https://www.cnn.com/2023/03/27/opinions/biden-trump-campaign-rally-mississippi-obeidallah/index.html](https://www.cnn.com/2023/03/27/opinions/biden-trump-campaign-rally-mississippi-obeidallah/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 13:35:24+00:00

This weekend, we were reminded about a major reason that President Joe Biden soundly defeated Donald Trump in 2020.

## Humza Yousaf wins race to replace Sturgeon as Scotland's next leader
 - [https://www.cnn.com/2023/03/27/uk/snp-new-leader-intl/index.html](https://www.cnn.com/2023/03/27/uk/snp-new-leader-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 13:35:03+00:00

Scottish nationalists picked Humza Yousaf to be the country's next leader on Monday after a bitterly fought contest that exposed deep divisions in his party over policy and a stalled independence campaign.

## A dog steals the show after catching home run ball during spring training game
 - [https://www.cnn.com/2023/03/27/sport/dog-catches-baseball-spring-training-spt-intl/index.html](https://www.cnn.com/2023/03/27/sport/dog-catches-baseball-spring-training-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 13:20:18+00:00

There was an unexpected star of the show during the Los Angeles Dodgers' spring training game against the Kansas City Royals on Saturday, after a dog managed to get his teeth on a home run ball.

## Tech expert weighs in on viral AI-generated photo of the Pope
 - [https://www.cnn.com/videos/business/2023/03/27/pope-puffer-jacket-fake-ai-generated-photo-cnntm-cprog-sot-vpx.cnn](https://www.cnn.com/videos/business/2023/03/27/pope-puffer-jacket-fake-ai-generated-photo-cnntm-cprog-sot-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 13:19:00+00:00

A photo of Pope Francis rocking a white puffer coat went viral over the weekend, but it's not real. The image was created using Midjourney, an artificial intelligence tool that can generate shockingly realistic images. Futurist tech entrepreneur and startup founder Sinead Bovell joins CNN This Morning to discuss.

## Cuban migrants successfully reach US using motorized hang glider
 - [https://www.cnn.com/videos/world/2023/03/27/cuba-flee-florida-key-west-hang-glider-ovn-cprog-intl-hnk-vpx.cnn](https://www.cnn.com/videos/world/2023/03/27/cuba-flee-florida-key-west-hang-glider-ovn-cprog-intl-hnk-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 13:16:50+00:00

Two Cuban migrants landed at Key West International Airport via a motorized hang glider, according to the Monroe County Sheriff's Office.

## Fox News producer who sued network last week over her Dominion testimony says she was fired
 - [https://www.cnn.com/2023/03/27/media/fox-dominion-abby-grossberg/index.html](https://www.cnn.com/2023/03/27/media/fox-dominion-abby-grossberg/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 13:11:10+00:00

The Fox News producer who accused the right-wing network of pressuring her into giving misleading testimony in the Dominion defamation case has been fired, she dis in new court filings.

## How fatherhood made this writer take comfort in life's little joys
 - [https://www.cnn.com/style/article/clint-smith-above-ground-profile-wellness-cec/index.html](https://www.cnn.com/style/article/clint-smith-above-ground-profile-wellness-cec/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 12:57:36+00:00

Fans of Clint Smith may best know the writer and journalist from his extensive work chronicling the history of racism and slavery in the US. Or, maybe, they know Smith from his tweets about soccer, specifically Arsenal F.C. Or, they may recognize his name from his work at The Atlantic.

## Jack Ma makes rare public appearance in China
 - [https://www.cnn.com/2023/03/27/tech/jack-ma-china-school-visit/index.html](https://www.cnn.com/2023/03/27/tech/jack-ma-china-school-visit/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 12:47:34+00:00

Jack Ma, the billionaire founder of Alibaba and once one of China's most prominent entrepreneurs, has made a rare public appearance in the country.

## 'John Wick' franchise 'not ready to say goodbye' to Keanu Reeves
 - [https://www.cnn.com/2023/03/27/entertainment/john-wick-keanu-reeves/index.html](https://www.cnn.com/2023/03/27/entertainment/john-wick-keanu-reeves/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 12:47:26+00:00

Looks like Keanu Reeves will be around a bit longer in the "John Wick" franchise.

## Jet lag hits differently depending on your travel direction. Here are 6 tips to get over it
 - [https://www.cnn.com/travel/article/jet-lag-tips-on-how-to-beat-wellness/index.html](https://www.cnn.com/travel/article/jet-lag-tips-on-how-to-beat-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 12:33:03+00:00

After a few difficult years of lockdowns and travel restrictions, people are finally winging their way across the globe again; families are being reunited and sights are being seen.

## Agatha Christie's classic detective novels edited to remove potentially offensive language
 - [https://www.cnn.com/style/article/agatha-christie-novels-edited-offensive-language-gbr-intl-scli/index.html](https://www.cnn.com/style/article/agatha-christie-novels-edited-offensive-language-gbr-intl-scli/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 12:31:03+00:00

Novels by "Queen of Crime" Agatha Christie are the latest classic works to be revised to remove racist references and other language considered offensive to modern audiences.

## 'Historic' strikes leave Israel at standstill with crowds in streets to protest judicial reform
 - [https://www.cnn.com/2023/03/27/middleeast/israel-judicial-overhaul-legislation-intl/index.html](https://www.cnn.com/2023/03/27/middleeast/israel-judicial-overhaul-legislation-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 12:06:03+00:00

Israel's political crisis escalated into uncharted territory Monday as the country's largest trade union announced a "historic" strike shutting down transportation, universities, restaurants and retailers in protest against Prime Minister's Benjamin Netanyahu's planned judicial overhaul.

## More than two dozen Israeli mayors declare hunger strike over judicial overhaul
 - [https://edition.cnn.com/middleeast/live-news/israel-protests-netanyahu-updates-03-27-23-intl/h_c18f20712db932dee7a2697516b16c3a](https://edition.cnn.com/middleeast/live-news/israel-protests-netanyahu-updates-03-27-23-intl/h_c18f20712db932dee7a2697516b16c3a)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 11:36:36.400126+00:00



## Italian mayor invites ousted US principal to Florence following Michelangelo 'David' statue controversy
 - [https://www.cnn.com/style/article/florence-mayor-michelangelo-david-florida-school/index.html](https://www.cnn.com/style/article/florence-mayor-michelangelo-david-florida-school/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 11:19:00+00:00

The mayor of Florence has invited Hope Carrasquilla, the former principal of a Florida school embroiled in controversy over a sixth-grade lesson on Michelangelo's "David," to visit Italy after she was forced out of her job last week.

## 2 dead, 29 wounded in Sloviansk missile strike, Ukrainian authorities say
 - [https://www.cnn.com/europe/live-news/russia-ukraine-war-news-03-27-23/index.html](https://www.cnn.com/europe/live-news/russia-ukraine-war-news-03-27-23/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 11:06:09+00:00

• Russia takes no chances in defense of Crimea
• Putin declares tactical nuclear plan. Read the fine print

## First Citizens Bank to purchase assets of Silicon Valley Bank
 - [https://www.cnn.com/collections/intl-banks-crisis-022723/](https://www.cnn.com/collections/intl-banks-crisis-022723/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 11:05:00+00:00



## Huge strikes in Germany disrupt flights, trains and buses
 - [https://www.cnn.com/2023/03/27/business/germany-transport-strikes-intl/index.html](https://www.cnn.com/2023/03/27/business/germany-transport-strikes-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 10:59:25+00:00

Nationwide strikes in Germany — the biggest the country has seen in decades — are causing disruption at the country's biggest port, airports, and on public transport Monday.

## This teenager cycled from Alaska to Argentina
 - [https://www.cnn.com/travel/article/teenager-who-cycled-from-alaska-to-argentina/index.html](https://www.cnn.com/travel/article/teenager-who-cycled-from-alaska-to-argentina/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 10:33:10+00:00

He'd longed to go on a "crazy adventure" for years, and as Liam Garner's high school graduation day grew closer, the teenager was more determined than ever to make his escape.

## Ralphie, the 'demon dog' of Niagara, has finally been adopted
 - [https://www.cnn.com/2023/03/27/us/ralphie-demon-dog-adopted-trnd/index.html](https://www.cnn.com/2023/03/27/us/ralphie-demon-dog-adopted-trnd/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 10:01:23+00:00

Fourth time's the charm for this mischievous pup -- hopefully.

## Europe's banking stocks recover as SVB deal brings respite
 - [https://www.cnn.com/2023/03/27/investing/europe-banking-stocks-rebound-svb-deal/index.html](https://www.cnn.com/2023/03/27/investing/europe-banking-stocks-rebound-svb-deal/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 09:59:48+00:00

European banking stocks rose Monday, boosted by the news that US lender First Citizens Bank would buy most of the business of failed Silicon Valley Bank.

## Cristiano Ronaldo marks two-goal performance with new celebration against Luxembourg
 - [https://www.cnn.com/2023/03/27/football/cristiano-ronaldo-celebration-portugal-spt-intl/index.html](https://www.cnn.com/2023/03/27/football/cristiano-ronaldo-celebration-portugal-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 09:56:17+00:00

Cristiano Ronaldo scored twice as Portugal thrashed Luxembourg 6-0, marking his first goal with a new celebration.

## Prince Harry back in London for UK High Court fight
 - [https://www.cnn.com/2023/03/27/uk/prince-harry-court-intl/index.html](https://www.cnn.com/2023/03/27/uk/prince-harry-court-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 09:51:05+00:00

Britain's Prince Harry has arrived at London's High Court to attend a hearing in his claim against Associated Newspapers Limited over allegations of unlawful information gathering.

## Saudi National Bank chair resigns after Credit Suisse comments
 - [https://www.cnn.com/2023/03/27/investing/saudi-national-bank-chair-resigns-credit-suisse/index.html](https://www.cnn.com/2023/03/27/investing/saudi-national-bank-chair-resigns-credit-suisse/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 09:48:56+00:00

The chairman of Credit Suisse's largest shareholder, Saudi National Bank, has resigned less than two weeks after comments he made about the Swiss lender accelerated a plunge in its share price.

## Thousands of animal mummies discovered at ancient Egyptian site
 - [https://www.cnn.com/travel/article/mummified-ram-heads-ancient-egyptian-intl-scli-scn/index.html](https://www.cnn.com/travel/article/mummified-ram-heads-ancient-egyptian-intl-scli-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 09:25:31+00:00

At least 2,000 mummified ram heads dating from the Ptolemaic period and a palatial Old Kingdom structure have been uncovered at the temple of Ramses II in the ancient city of Abydos in southern Egypt, antiquities officials said on Saturday.

## Coffee drinkers get more steps but also less sleep, study finds
 - [https://www.cnn.com/2023/03/27/health/coffee-fitness-sleep-heart-effects-wellness/index.html](https://www.cnn.com/2023/03/27/health/coffee-fitness-sleep-heart-effects-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 09:12:23+00:00

Coffee is one of the most consumed beverages worldwide, but the pendulum has swung back and forth about its benefits and drawbacks.

## Israel's biggest union calls 'historic' strike to stop 'judicial revolution'
 - [https://edition.cnn.com/middleeast/live-news/israel-protests-netanyahu-updates-03-27-23-intl/h_bb6bb214dc6e8c6d16c61fe3d69d6dcd](https://edition.cnn.com/middleeast/live-news/israel-protests-netanyahu-updates-03-27-23-intl/h_bb6bb214dc6e8c6d16c61fe3d69d6dcd)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 08:36:19.079550+00:00



## How scientists are decoding what the past smelled like
 - [https://www.cnn.com/2023/03/27/world/decoding-how-the-past-smells-scn/index.html](https://www.cnn.com/2023/03/27/world/decoding-how-the-past-smells-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 08:25:32+00:00

Smells hover just below our conscious awareness, conjuring up emotions and memories that shape how we perceive and navigate the world.

## Israeli journalist predicts what could happen next with protests
 - [https://www.cnn.com/videos/world/2023/03/27/israel-protests-analysis-yaakov-katz-jerusalem-post-ovn-intl-ldn-vpx.cnn](https://www.cnn.com/videos/world/2023/03/27/israel-protests-analysis-yaakov-katz-jerusalem-post-ovn-intl-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 08:00:41+00:00

For months, hundreds of thousands of Israelis have been taking to the streets across the country against far-reaching changes to Israel's legal system some say threaten the country's democratic foundations. CNN spoke to Jerusalem Post editor-in-chief Yaakov Katz to discuss the current developments.

## Antonio Conte: After calling players 'selfish' and criticizing club culture, manager leaves Tottenham Hotspur
 - [https://www.cnn.com/2023/03/27/football/antonio-conte-leaves-tottenham-spt-intl/index.html](https://www.cnn.com/2023/03/27/football/antonio-conte-leaves-tottenham-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 07:58:09+00:00

Tottenham Hotspur says it has parted with manager Antonio Conte "by mutual agreement" less than two years after he took over at the English Premier League club.

## Authorities urge residents to evacuate Ukrainian town as Russian attacks disrupt utilities
 - [https://edition.cnn.com/europe/live-news/russia-ukraine-war-news-03-27-23/index.html](https://edition.cnn.com/europe/live-news/russia-ukraine-war-news-03-27-23/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 07:36:17.285657+00:00



## Clearing land mines by hand, farmers in Ukraine risk their lives for planting season
 - [https://www.cnn.com/2023/03/27/europe/farmers-land-mines-clearance-ukraine-russia-invasion-intl-hnk/index.html](https://www.cnn.com/2023/03/27/europe/farmers-land-mines-clearance-ukraine-russia-invasion-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 06:56:00+00:00



## Myanmar junta throws huge military parade days after new US sanctions
 - [https://www.cnn.com/2023/03/27/asia/myanmar-armed-forces-day-us-sanctions-intl-hnk/index.html](https://www.cnn.com/2023/03/27/asia/myanmar-armed-forces-day-us-sanctions-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 06:10:46+00:00

Myanmar's ruling military paraded an arsenal of weapons in the capital Naypyidaw on Monday, in a grand display of force days after the United States imposed fresh sanctions against the junta for inflicting "pain and suffering on the people of Burma."

## FDIC announces First-Citizens Bank & Trust Company to purchase assets of  Silicon Valley Bank
 - [https://www.cnn.com/2023/03/27/business/fdic-announces-first-citizens-purchase-silicon-valley-bank/index.html](https://www.cnn.com/2023/03/27/business/fdic-announces-first-citizens-purchase-silicon-valley-bank/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 05:56:46+00:00

The Federal Deposit Insurance Corporation has announced that First-Citizens Bank & Trust Company will purchase all deposits and loans of Silicon Valley Bridge Bank.

## Pharrell Williams and Lorraine Schwartz team up for sale featuring iconic celebrity-worn jewelry
 - [https://www.cnn.com/style/article/pharrell-williams-lorraine-schwartz-jewelry-sale/index.html](https://www.cnn.com/style/article/pharrell-williams-lorraine-schwartz-jewelry-sale/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 05:34:25+00:00

Beyoncé, Kim Kardashian, Blake Lively. These are just some of the names Lorraine Schwartz reels off as she points out items of exquisite jewelry kept in a row of glass vitrines.

## IMF chief warns of 'risks' to global financial stability, but China showing signs of recovery
 - [https://www.cnn.com/2023/03/27/business/imf-chief-warning-financial-stability-risks-intl-hnk/index.html](https://www.cnn.com/2023/03/27/business/imf-chief-warning-financial-stability-risks-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 04:41:33+00:00

The head of the International Monetary Fund called for greater vigilance over the global financial system during a speech in China on Sunday in which she also pointed to "green shoots" emerging in the world's second-largest economy.

## Israel protests erupt amid deepening political crisis after Netanyahu fires defense minister
 - [https://edition.cnn.com/middleeast/live-news/israel-protests-netanyahu-updates-03-27-23-intl/index.html](https://edition.cnn.com/middleeast/live-news/israel-protests-netanyahu-updates-03-27-23-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 04:36:18.692917+00:00



## Trump leans into extremism at first 2024 rally as legal woes mount
 - [https://www.cnn.com/2023/03/27/politics/trump-extremism-2024-legal-woes/index.html](https://www.cnn.com/2023/03/27/politics/trump-extremism-2024-legal-woes/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 04:08:26+00:00

Donald Trump is igniting his White House bid at a moment of unprecedented peril in the criminal investigations against him -- a confluence that could send America into a new political and legal collision.

## Actor Jonathan Majors is arrested on assault charge in New York, police say
 - [https://www.cnn.com/2023/03/25/us/jonathan-majors-arrest-new-york/index.html](https://www.cnn.com/2023/03/25/us/jonathan-majors-arrest-new-york/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 03:11:45+00:00

Actor Jonathan Majors, who has recently starred in "Creed III" and "Ant-Man and the Wasp: Quantumania," was arrested Saturday morning in an alleged domestic dispute, New York police say.

## Watch Dana Carvey impersonate President Biden talking about Adam Sandler
 - [https://www.cnn.com/videos/entertainment/2023/03/26/mark-twain-prize-american-humor-adam-sandler-cprog-orig-kj.cnn](https://www.cnn.com/videos/entertainment/2023/03/26/mark-twain-prize-american-humor-adam-sandler-cprog-orig-kj.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 03:00:38+00:00

Adam Sandler is the 2023 recipient of the Mark Twain Prize for American Humor. He was honored at a ceremony in Washington, DC where many of his close friends paid him tribute by poking fun at him.

## All the restaurants Eva Longoria visits in 'Searching for Mexico'
 - [https://www.cnn.com/travel/article/eva-longoria-searching-for-mexico-restaurants/index.html](https://www.cnn.com/travel/article/eva-longoria-searching-for-mexico-restaurants/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 02:33:06+00:00

You'll no doubt be hungry after watching "Eva Longoria: Searching for Mexico."

## Mass protests erupt in Israel after Netanyahu fires minister who opposed judicial overhaul
 - [https://www.cnn.com/collections/intl-2703-israel-protests/](https://www.cnn.com/collections/intl-2703-israel-protests/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 02:15:25+00:00



## Nearly 8 million driver license numbers and passport numbers stolen in Australia
 - [https://www.cnn.com/2023/03/26/australia/latitude-group-information-theft-intl-hnk/index.html](https://www.cnn.com/2023/03/26/australia/latitude-group-information-theft-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-03-27 02:02:20+00:00

Digital payments and lending firm Latitude Holdings said on Monday that 7.9 million Australian and New Zealand driver license numbers were stolen in a large-scale information theft on March 16.

