# Source:PC world, URL:https://www.pcworld.com/index.rss, language:en-US

## Microsoft’s new version of Teams is faster and smarter
 - [https://www.pcworld.com/article/1672726/sleeker-teams-preview-shows-topsy-turvy-ui-and-ai-too.html](https://www.pcworld.com/article/1672726/sleeker-teams-preview-shows-topsy-turvy-ui-and-ai-too.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-03-27 16:42:33+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>Microsoft Teams is about to get flipped on its head with a new version Microsoft will begin rolling out in June. The updated Teams will be significantly faster, but also feature some dramatic new changes like adding a new AI-powered Microsoft 365 Copilot plus a new interface that places the latest information right on top.</p>



<p>It&rsquo;s a significant change to Teams in both how it will feel to use as well as the user interface itself. You may not notice some of the performance improvements&mdash;launching twice as fast and joining meetings twice as fast, too&mdash;but your PC will definitely benefit from a redesign of the Teams code that cuts memory usage down to as little as half what it used to. Disk space will also decrease by about 70 percent, Microsoft said. Both will make your PC feel faster.</p>



<p>It&rsquo;s not clear what the addition of AI will mean to corporate culture nor has Microsoft said which apps will receive the new <a href="https://www.pcworld.com/article/1661514/microsoft-365-copilot-is-microsofts-ai-powers-applied-to-work.html">AI-powered Microsoft 365 Copilot</a> first. But when the new version of Teams debuts, you&rsquo;ll be able to message Bing&rsquo;s chatbot to ask questions, summarize conversations, and more. If nothing else, Microsoft promises that you&rsquo;ll be able to use Teams&rsquo; new AI to jump to relevant points in the discussion and pare down your windy CEO&rsquo;s lengthy explanations to stuff you actually need to do.</p>



<p>Microsoft is making more fundamental changes to the user interface, however, including one that apparently felt near and dear to the hearts of Teams users: where new content appears in a chat. Apps like Slack and Discord as well as the current Teams place the text entry box at the bottom of the chat. Once you type in a message to your coworkers, it appears at the bottom of the conversation.</p>



<figure class="wp-block-embed is-type-video is-provider-youtube wp-block-embed-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio"><div class="wp-block-embed__wrapper">

</div></figure>



<p>Apparently this was a big deal to some Teams users. &ldquo;Initially, we chose to follow a chat-like model for channels (open field at the bottom and a conversation that flows bottom-up) because threaded conversations were a unique differentiator for Teams,&rdquo; Microsoft Design&rsquo;s Thad Scott and Colin Day wrote in a <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://medium.com/microsoft-design/designing-the-new-era-of-teams-523d772add4&amp;xcust=2-2-1672726-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow">blog post</a> on Medium. &ldquo;But this is where we needed to be humble and admit mistakes based on feedback; differentiator or not, the model confused people. Now, we&rsquo;ve flipped things to adopt a post-and-reply experience at the top, which feels much more familiar.&rdquo;</p>



<p>Threads will also feature infinite scrolling instead of the current ten items at a time, Scott and Day wrote. Part of the code revamp also involved background loading, which should make loading threads quicker if not instantaneous. Finally, you&rsquo;ll be able to access Teams while logged into more than once account&mdash;a sneaky way to encourage users to use <a href="https://www.pcworld.com/article/398958/microsoft-adds-microsoft-teams-for-consumers-as-office-365-becomes-microsoft-365-for-all.html">Teams for both work and play</a>, perhaps.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Microsoft Teams breakout" class="wp-image-1672804" height="539" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/Teams-breakout-1.jpg?quality=50&amp;strip=all&amp;w=1200" width="1200" /><figcaption>A  breakdown of some of the new Teams features, according to Microsoft.</figcaption></figure><p class="imageCredit">Microsoft</p></div>



<p>Microsoft said that the new Teams would roll out in June. If you&rsquo;re part of the Targeted Release program, however, your business may receive it in April.</p>

Professional Software</div>

## How to change your laptop’s power settings
 - [https://www.pcworld.com/article/1663411/how-to-change-your-laptops-energy-settings.html](https://www.pcworld.com/article/1663411/how-to-change-your-laptops-energy-settings.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-03-27 14:30:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>If you&rsquo;re looking to lengthen the life of your laptop, listen up. Changing your power settings can help conserve battery life by preventing the laptop from using all of its power. Adjusting these settings is relatively easy to do and has little impact on the daily use of your device. Read on to learn more.</p>



<blockquote class="wp-block-quote"><p>Are you in the market for a brand new laptop? If so, check out our roundup of the <a href="https://www.pcworld.com/article/436674/the-best-pc-laptops-of-the-year.html">best laptops</a> available today.</p></blockquote>



<h2 id="how-to-make-your-laptop-more-energy-efficient">How to make your laptop more energy efficient</h2>



<p id="E61">You can find your laptop&rsquo;s energy settings in the Settings menu. To get to Settings, click on the gear icon in the Start menu.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-full"><img alt="Click the gear icon with &ldquo;Settings&rdquo; below it in the Start Menu." class="wp-image-1663348" height="683" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/press-windows-button-and-select-settings-icon-1.jpg?quality=50&amp;strip=all" width="1024" /></figure><p class="imageCredit">IDG / Alex Huebner</p></div>



<p id="E82">Click the &ldquo;Power &amp; battery&rdquo; button.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-full"><img alt="Click the Power &amp; Battery button." class="wp-image-1663441" height="683" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/power-and-battery-in-settings.jpg?quality=50&amp;strip=all" width="1024" /></figure><p class="imageCredit">IDG / Alex Huebner</p></div>



<p id="E86">In this menu, you&rsquo;ll see the &ldquo;Energy recommendations&rdquo; bar at the top. Left click through to open a new menu.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-full"><img alt="Left-click through to open a new menu. " class="wp-image-1663443" height="683" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/power-and-battery-laptop-energy-settings.jpg?quality=50&amp;strip=all" width="1024" /></figure><p class="imageCredit">IDG / Alex Huebner</p></div>



<p id="E107">This action will open a page of recommendations. If you want to apply all of the recommended settings, click &ldquo;Apply all&rdquo;.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-full"><img alt="The top selection is to apply all of the recommended settings. " class="wp-image-1663445" height="683" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/apply-all-laptop-energy-settings.jpg?quality=50&amp;strip=all" width="1024" /></figure><p class="imageCredit">IDG / Alex Huebner</p></div>



<p id="E145">You can also chose to individually apply specific settings. To do this, click the &ldquo;Apply&rdquo; button next to the ones you want.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-full"><img alt="Individually apply the settings you like." class="wp-image-1663450" height="683" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/choose-which-laptop-energy-settings-to-apply.jpg?quality=50&amp;strip=all" width="1024" /></figure><p class="imageCredit">IDG / Alex Huebner</p></div>

Laptops</div>

## Save $80 on this ultra-fast 170Hz Acer gaming monitor for a limited time
 - [https://www.pcworld.com/article/1672407/1672407.html](https://www.pcworld.com/article/1672407/1672407.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-03-27 13:52:38+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>There&rsquo;s nothing worse than using on a monitor that can&rsquo;t keep pace with a faster game. Well, if you&rsquo;re on the hunt for a brand new gaming monitor, you&rsquo;re in luck, as we&rsquo;ve got a fantastic deal for you today. Newegg&rsquo;s currently selling the <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.newegg.com/p/N82E16824011451?item=N82E16824011451&amp;xcust=2-1-1672407-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow">Acer Nitro gaming monitor for $189.99, which is a savings of $80</a>. From the 170Hz refresh rate to the 1ms response time, you can expect buttery smooth visuals and responsive gameplay. Let&rsquo;s get into it, folks.</p>



<p>The 27-inch Nitro has a resolution of 2560&times;1440, a refresh rate of up to 175Hz, a response time of 1ms, and a brightness level of 350 nits. It has AMD FreeSync as well, which syncs your PC&rsquo;s GPU up with your monitor, reducing lag and screen tearing issues, resulting in smoother gameplay. For connectivity options, you&rsquo;re getting one DisplayPort 1.2, two HDMI, and one audio out. This is a great deal. However, as of this writing, the sale ends in 17 hours. You best nab it now.</p>


<p class="cta wp-block wp-block-button"><a class="cta__btn" href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.newegg.com/p/N82E16824011451?item=N82E16824011451&amp;xcust=2-1-1672407-7-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow" target="_blank">Get the Acer Nitro gaming monitor for $189.99 at Newegg</a></p>
Monitors</div>

## Password managers: Why I switched from free to paid premium
 - [https://www.pcworld.com/article/1663329/password-managers-free-vs-premium-protection.html](https://www.pcworld.com/article/1663329/password-managers-free-vs-premium-protection.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-03-27 10:45:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>If you&rsquo;re not already using a password manager to protect the keys to your digital kingdom, you&rsquo;re making a grave mistake. We&rsquo;ve already told you <a href="https://www.pcworld.com/article/709052/6-common-reasons-people-dont-use-a-password-manager-and-why-theyre-wrong.html">why going without a password manager is a terrible idea</a>. We&rsquo;ve even tested and <a href="https://www.pcworld.com/article/407092/best-password-managers-reviews-and-buying-advice.html">rated the top password managers for you</a>. </p>



<p>But far too many people still think the free password management tools that comes with their phones is good enough, and just go with what&rsquo;s convenient rather than what&rsquo;s best. Here&rsquo;s why you should ditch that free password management utility and upgrade to the more robust protection of a premium password manager like Dashlane or Keeper.</p>



<p><strong>Separation of Data</strong></p>



<p>Keeping all your data in one place is super convenient, to be sure. But it also creates a single point of failure. Since everything in your iCloud or Google account is ultimately protected by just one password, using the password utility provided by those big vendors means that anyone who gets in grabs not only access to your email and other data, but also takes everything they need to get into every single <em>other </em>account you have, anywhere on the internet. </p>



<p>Given that current hacker automations are designed to crank through that kind of credential data in seconds, you&rsquo;ve created a one-and-done opportunity for the very people you&rsquo;re defending against. So you&rsquo;ll want to separate your password management data from everything else.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Android password manager" class="wp-image-798828" height="1200" src="https://b2c-contenthub.com/wp-content/uploads/2022/06/Android-password.png?w=1200" width="1200" /><figcaption>You may be tempted to use the free password utility that comes with your phone, but beware the trade-off of control and security for convenience.</figcaption></figure><p class="imageCredit">Google</p></div>



<p><strong>Full Cross-Platform Capability</strong></p>



<p>Free password tools tend to provide very limited cross-platform support. Apple Passwords has a Chrome plugin, but it&rsquo;s clunky and requires constant re-authentication. Google Password Manager is built for Chrome only, and while it works on Windows, Mac, and iOS, it still requires Chrome as the browser. </p>



<p>These vendor-imposed limitations are typically presented as being designed for your protection, but in reality they&rsquo;re an extension of the old Silicon Valley platform wars that have hindered true open computing since the 1990s. By contrast, premium password managers compete with one another to provide the broadest cross-platform support and best user experience, coupled with the most robust security. It&rsquo;s in their interests to serve your interests and make cross-device password management work for you.</p>



		<div class="wp-block-product-widget-block product-widget is-half-width is-float-right">
			<div class="product-widget__block-title-wrapper">
				<h4 class="product-widget__block-title" id="our-1-password-manager-pick">
					Our #1 password manager pick				</h4>
			</div>

			<div class="product-widget__content-wrapper">
									<div class="product-widget__title-wrapper">
						<h3 class="product-widget__title" id="dashlane">Dashlane</h3>
					</div>
				
									<div class="product-widget__image-outer-wrapper">
						<div class="product-widget__image-wrapper">
							<img alt="Dashlane" class="product-widget__image" height="4013" src="https://b2c-contenthub.com/wp-content/uploads/2022/06/Dashlane-Lockup-Green-3619X1385.png" width="15080" />
						</div>
					</div>
				
									<div class="review product-widget__review-details">
						<img alt="Editors' Choice" class="product-widget__review-details--editors-choice-logo" src="https://www.pcworld.com/wp-content/uploads/2021/09/PC-ED-CHOICE.png" />							<div class="product-widget__rating-and-review-link">
								<div class="product-widget__review-details--rating">
											<div class="starRating"></div>
										</div>									<a class="product-widget__review-link" href="https://www.pcworld.com/article/407081/dashlane-password-manager-review.html" target="_blank">Read our review</a>
									
							</div>
											</div>
				
				<div class="product-widget__information">
												<div class="product-widget__information--rrp-wrapper">
									<span class="product-widget__information--rrp-label">
																	</span>
									<span class="product-widget__information--rrp-value">
																		</span>
								</div>
								
											<div class="product-widget__pricing-details  ">
															<span class="product-widget__pricing-details--label">
									Best Prices Today:
								</span>
														<span class="product-widget__pricing-details--links-wrapper">
								<a class="product-widget__pricing-details--link" href="https://www.tkqlhce.com/click-100470607-12528922?sid=2-1-1663329-5-389931-15360" rel="nofollow" target="_blank">$33 at  Dashlane</a>							</span>
						</div>
									</div>
			</div>
		</div>

		


<p><strong>Better Password Sharing</strong></p>



<p>Sometimes you actually <em>do </em>want to share a password with someone, or at least share access to an account. The top premium password managers, such as <a href="https://www.pcworld.com/article/407081/dashlane-password-manager-review.html">Dashlane</a> and <a href="https://www.pcworld.com/article/398233/keeper-password-manager-review.html">Keeper</a>, make it easy to share passwords securely with other users of the platform, and let you decide whether than user can see the credentials for themselves or merely use them without ever seeing the actual password. </p>



<p>These features make it easy to give someone time-limited access to an online account without having to change the password afterward. You just don&rsquo;t find this level of control in the free options. Most even offer family plans that not only give you a better deal on multiple licenses, but also make it easier to share passwords with family members.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Keeper" class="wp-image-1531525" height="964" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/en_US_Account.png?w=1200" width="1200" /><figcaption><p>Keeper&rsquo;s Family plan provides password vaults for five people.</p>
</figcaption></figure><p class="imageCredit">Keeper</p></div>



<p><strong>Comprehensive Dashboards</strong></p>



<p>With the free tools, you generally don&rsquo;t get a very robust management interface. Most are just lists of passwords that you can edit or delete. Premium password managers all come with rich web interfaces that make it easy to categorize passwords, see security details like whether you&rsquo;ve reused the same password on multiple accounts, and even change your passwords across multiple accounts automatically.&nbsp;</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Dashlane" class="wp-image-1507250" height="671" src="https://b2c-contenthub.com/wp-content/uploads/2023/02/Screen-Shot-2023-02-08-at-11.38.25-AM.png?w=1200" width="1200" /><figcaption><p>Dashlane provides a password health score and highlights your most at-risk passwords.</p>
</figcaption></figure><p class="imageCredit">Michael Ansaldo/IDG</p></div>



<p><strong>Autogeneration and Autofill</strong></p>



<p>Pretty much all password managers can autofill passwords on the sites you visit. The robustness of that capability varies widely, and is often limited by vendors&rsquo; revenue interests, as we&rsquo;ve said before. The ability to autogenerate passwords and give you control over how the passwords are structured varies widely. Some of the free options force their own structure on you, and at times that structure doesn&rsquo;t meet the security requirements of certain websites, so you end up having to edit them by hand. </p>



<p>The best premium password managers give you granular control over how passwords are generated: how many characters, what types of characters, whether capitals or lowercase are to be used, and whether to include symbols. This makes it easy for you to ratchet security up and down, or even generate simpler passwords that are easier to remember if you happen to want that for something like your kids&rsquo; math-game site.&nbsp;</p>



<p><strong>Dark Web Monitoring</strong></p>



<p>Having complex passwords locked up in a password manager won&rsquo;t help you much if your credentials get compromised some other way and you don&rsquo;t even know about it. One of the biggest reasons to subscribe to a premium password manager is dark web monitoring. When your credentials are leaked on hacker sites or compromised in a breach, you get an alert. Right in the dashboard, you can see what happened, and automatically change your password to eliminate the threat.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Keeper" class="wp-image-1531526" height="964" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/en_US_BreachWatch.png?w=1200" width="1200" /><figcaption><p>Keeper&rsquo;s BreachWatch feature scans the Dark Web to see if your passwords have been compromised.</p>
</figcaption></figure><p class="imageCredit">Keeper</p></div>



<p><strong>The Bottom line</strong></p>



<p>The clich&eacute; that you get what you pay for isn&rsquo;t always true, but it&rsquo;s true enough in this case. Most free tools are usually free for a reason, and those reasons have nothing to do with giving you the most value. </p>



<p>With <a href="https://www.pcworld.com/article/407092/best-password-managers-reviews-and-buying-advice.html">the best password managers</a>, you can try them for free, but getting access to the serious protection and robust features requires a subscription. Check out the top password managers, and even take a few for a spin in a free trial, but ultimately, protect yourself by ditching the free tools and leveling up for better security.</p>



		<div class="wp-block-product-widget-block product-widget is-float-right">
			<div class="product-widget__block-title-wrapper">
				<h4 class="product-widget__block-title" id="our-1-password-manager-pick">
					Our #1 password manager pick				</h4>
			</div>

			<div class="product-widget__content-wrapper">
									<div class="product-widget__title-wrapper">
						<h3 class="product-widget__title" id="dashlane">Dashlane</h3>
					</div>
				
									<div class="product-widget__image-outer-wrapper">
						<div class="product-widget__image-wrapper">
							<img alt="Dashlane" class="product-widget__image" height="4013" src="https://b2c-contenthub.com/wp-content/uploads/2022/06/Dashlane-Lockup-Green-3619X1385.png" width="15080" />
						</div>
					</div>
				
									<div class="review product-widget__review-details">
						<img alt="Editors' Choice" class="product-widget__review-details--editors-choice-logo" src="https://www.pcworld.com/wp-content/uploads/2021/09/PC-ED-CHOICE.png" />							<div class="product-widget__rating-and-review-link">
								<div class="product-widget__review-details--rating">
											<div class="starRating"></div>
										</div>									<a class="product-widget__review-link" href="https://www.pcworld.com/article/407081/dashlane-password-manager-review.html" target="_blank">Read our review</a>
									
							</div>
											</div>
				
				<div class="product-widget__information">
												<div class="product-widget__information--rrp-wrapper">
									<span class="product-widget__information--rrp-label">
																	</span>
									<span class="product-widget__information--rrp-value">
																		</span>
								</div>
								
											<div class="product-widget__pricing-details  ">
															<span class="product-widget__pricing-details--label">
									Best Prices Today:
								</span>
														<span class="product-widget__pricing-details--links-wrapper">
								<a class="product-widget__pricing-details--link" href="https://www.tkqlhce.com/click-100470607-12528922?sid=2-1-1663329-5-389931-15360" rel="nofollow" target="_blank">$33 at  Dashlane</a>							</span>
						</div>
									</div>
			</div>
		</div>

		
Security</div>

## Samsung Galaxy Book3 Ultra review: A beautiful beast of a laptop
 - [https://www.pcworld.com/article/1525530/samsung-galaxy-book3-ultra-review.html](https://www.pcworld.com/article/1525530/samsung-galaxy-book3-ultra-review.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-03-27 10:30:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>


<div class="review" id="review-body"><img alt="Editors' Choice" class="review-logo" src="https://www.pcworld.com/wp-content/uploads/2021/09/PC-ED-CHOICE.png" /><span class="review-title">At a glance</span><h3 class="review-subTitle" id="experts-rating">Expert's Rating</h3><div class="starRating"></div>
<div><div class="review-columns"><div class="review-column"><h3 class="review-subTitle" id="pros">Pros</h3><ul class="pros review-list"><li>Solid performance <em>and</em> great battery life</li><li>Entry-level RTX 4xxx-series GPU</li><li>Gorgeous, powerful OLED screen</li><li>A 1080p webcam with Windows Studio Effects</li><li>Good interaction with Galaxy device ecosystem and apps</li></ul></div><div class="review-column"><h3 class="review-subTitle" id="cons">Cons</h3><ul class="cons review-list"><li>Average keyboard, trackpad</li><li>Audio needs some tweaking</li></ul></div></div></div><h3 class="review-subTitle review-subTitle--borderTop" id="our-verdict">Our Verdict</h3><p class="verdict">Samsung&rsquo;s Galaxy Book3 Ultra is Samsung&rsquo;s excellent first entry into the content-creation PC space. This thin laptop packs power and battery life behind a superb screen though at a fairly high price.</p>
</div>
				<h3 class="review-best-price" id="best-prices-today-samsung-galaxy-book3-ultra">
			Best Prices Today: Samsung Galaxy Book3 Ultra		</h3>
				<div class="wp-block-price-comparison price-comparison ">
			<div class="price-comparison__record price-comparison__record--header">
				<div>
					<span>Retailer</span>
				</div>
				<div class="price-comparison__price">
					<span>Price</span>
				</div>
			</div>

														<div class="price-comparison__record">
							<div class="price-comparison__image">
																	<img alt="Best Buy" src="https://www.pcworld.com/wp-content/themes/idg-base-theme/dist/static/img/best-buy-logo.png" />
															</div>
							<div class="price-comparison__price">
								<span>$2399.99</span>
							</div>
							<div>
								<a class="price-comparison__view-button" href="https://bestbuy.7tiv.net/c/321564/633495/10014?prodsku=6531072&amp;u=https%3A%2F%2Fapi.bestbuy.com%2Fclick%2F-%2F6531072%2Fpdp&amp;intsrc=CATF_4831&amp;subid1=2-1-1525530-2-1515863-11290" rel="nofollow" target="_blank">View Deal</a>							</div>
						</div>
												<div class="price-comparison__record price-comparison__record--footer">
					<span class="price-comparison__footer-text">
													Price comparison from over 24,000 stores worldwide												</span>
									</div>
						</div>
		


<p>Samsung&rsquo;s Galaxy Book3 Ultra challenges all comers in content creation, a market Samsung hasn&rsquo;t previously addressed with its Book3 series. But this sleek 16-inch laptop with its stunning OLED screen combines both a 13th-gen Intel Core CPU and a new Nvidia GeForce RTX 4050 GPU, giving you an entry point into the latest PC hardware.</p>



<p>There&rsquo;s a lot to love here. You&rsquo;re getting outstanding battery life, a lovely design, modern Thunderbolt 4 ports, and more. No, the GPU isn&rsquo;t what you&rsquo;ll find in a true gaming notebook and the keyboard is a bit shallower than other productivity laptops. You&rsquo;ll be hard-pressed, however, to find a better notebook PC for content creation.</p>



<blockquote class="wp-block-quote"><p>Looking for more content creator laptops? Check out our top picks on our roundup of the <a href="https://www.pcworld.com/article/436674/the-best-pc-laptops-of-the-year.html">best laptops</a>.</p></blockquote>



<h2 id="samsung-galaxy-book3-ultra-what-it-offers-where-it-fits">Samsung Galaxy Book3 Ultra: What it offers, where it fits</h2>



<p>Samsung&rsquo;s Galaxy Book3 Pro 360 is one of a&nbsp;<a href="https://www.pcworld.com/article/1486723/samsung-reveals-galaxy-book3-oled-laptops.html">small family of new Book3 laptops</a>&nbsp;that consists of the Book3 Ultra, <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.techadvisor.com/article/1520643/samsung-galaxy-book-3-pro-review.html&amp;xcust=2-1-1525530-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow">the Book3 Pro clamshell</a>, and the Book3 Pro 360 and Book3 360 two-in-one convertibles. (We&rsquo;ve <a href="https://www.pcworld.com/article/1499055/samsung-galaxy-book3-pro-360-review.html">reviewed the Samsung Galaxy Book3 Pro 360 separately</a>, and sister site <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.techadvisor.com/article/1520643/samsung-galaxy-book-3-pro-review.html&amp;xcust=2-1-1525530-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow">TechAdvisor reviewed the Book3 Pro</a>.) The Book3 Ultra is the new addition to the family, sporting an Nvidia RTX GeForce 4xxx GPU inside a thicker frame that makes it suitable for content creation and light gaming. It&rsquo;s a market Samsung hasn&rsquo;t addressed with its earlier Galaxy Books.</p>



<p>Samsung&rsquo;s Galaxy Book3 Ultra ships with a single 16-inch display option, though you&rsquo;ll have the choice of two performance configurations like the Core i7/RTX 4050 model that begins at $2,399.99, which we test here, and a Core i9/RTX 4070 version, starting at $2,999.99. The former option also offers 16GB of RAM, while the latter ships with 32GB. For either configuration, you can choose between 512GB and 1TB of SSD storage, though Samsung itself currently offers just a 1TB SSD option. </p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Samsung Galaxy Book3 Ultra" class="wp-image-1660332" height="1066" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/primary-redo.jpg?quality=50&amp;strip=all&amp;w=1200" width="1200" /><figcaption>Samsung&rsquo;s Galaxy Book3 Ultra is a member of <a href="https://www.pcworld.com/article/560732/intel-expands-premium-evo-brand-into-desktops-foldables-and-more.html">Intel&rsquo;s Evo program</a>, where Intel engineers help Samsung design the laptop.</figcaption></figure><p class="imageCredit">Mark Hachman / IDG</p></div>



<p>Keep in mind that there&rsquo;s a substantial difference between Nvidia&rsquo;s RTX 4050 mobile GPU and the RTX 4070 mobile GPU, though Nvidia didn&rsquo;t go into too much detail <a href="https://www.pcworld.com/article/1445469/nvidia-unleashes-geforce-rtx-4070-ti-rtx-40-series-laptops-and-more.html">when launching them</a>. Nvidia&rsquo;s RTX 4050 is the least powerful of the RTX 4xxx GPU family. While the 4050 and the 4070 otherwise offer similar features, <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.nvidia.com/en-us/geforce/laptops/compare/&amp;xcust=2-1-1525530-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow">Nvidia&rsquo;s specifications</a> show that they differ considerably in both memory width and CUDA core count, which will affect gaming performance but may also reduce battery life significantly. As a content creation machine, though, the new capabilities of the GPU&rsquo;s video encoders are just as important.</p>



<p>Put another way, the Book3 Ultra isn&rsquo;t a &ldquo;gaming&rdquo; laptop, but a &ldquo;gaming-capable&rdquo; laptop. Content creation and consumption is its primary purpose.</p>



<figure class="wp-block-pullquote"><blockquote><p>Samsung&rsquo;s Galaxy Book3 Ultra combines both power and long battery life, all behind a beautiful OLED screen that you&rsquo;ll be as eager to show off as to work upon.</p></blockquote></figure>



<h2 class="toc" id="samsung-galaxy-book3-ultra-specifications">Samsung Galaxy Book3 Ultra: Specifications</h2>



<ul><li><strong>Processor:</strong>&nbsp;Intel Core i7-13700H/Core i9-13900H (Core i7 as tested)</li><li><strong>Display:</strong>&nbsp;16-inch non-touch (2,880&times;1800), 120Hz AMOLED 2X, 400 nits, 120% DCI-P3 color volume</li><li><strong>Memory:</strong>&nbsp;16GB/32GB LPDDR5 (16GB as tested)</li><li><strong>Storage:</strong>&nbsp;512GB/1TB SSD plus expansion slot (1TB as tested)</li><li><strong>Graphics:</strong>&nbsp;Nvidia GeForce RTX 4050/4070 Laptop GPU (RTX 4050 as tested)</li><li><strong>Ports:</strong>&nbsp;2 Thunderbolt 4, USB Type-A, HDMI 2.0, microSD, Headphone/Mic</li><li><strong>Security:</strong>&nbsp;Fingerprint reader</li><li><strong>Camera:&nbsp;</strong>1080p (user-facing)</li><li><strong>Battery:&nbsp;</strong>73.8Wh (rated) / 74.5Wh (actual)</li><li><strong>Wireless:</strong>&nbsp;Wi-Fi 6E (Gig+), 802.11 ax 2&times;2, Bluetooth 5.1</li><li><strong>Audio:</strong>&nbsp;AKG Quad Speaker (two 5W woofers, two 2W tweeters), Smart Amp, Dolby Atmos</li><li><strong>Operating system:</strong>&nbsp;Windows 11</li><li><strong>Dimensions:</strong>&nbsp;&nbsp;13.99 x 9.86 x 0.65in. (16.5mm)</li><li><strong>Weight:</strong>&nbsp;3.95lbs (rated)</li><li><strong>Colors:</strong>&nbsp;Graphite</li><li><strong>Price:</strong>&nbsp;&nbsp;beginning at $2,399</li></ul>



<p>After recently reviewing the <a href="https://www.pcworld.com/article/1499055/samsung-galaxy-book3-pro-360-review.html">Samsung Galaxy Book3 Pro 360</a>, the additional weight and thickness that the Ultra offers is a bit of a shock. Like the other Book3 laptops, however, the aluminum chassis attracts fingerprints readily, which show up as smudges on the black Graphite surface. The Ultra doesn&rsquo;t feel especially thick&mdash;just more like a traditional laptop than Samsung&rsquo;s ultrathin Book lineup. At 14 inches wide and about four pounds, however, the weight is noticeable.</p>



<p>We said similar things about the Book3 Pro 360, with the caveat that the relatively tiny gallium nitrate (GaN) charger offset those concerns. Here, the charger adds to them, unfortunately. You probably have older devices that combine the power transformer and the plug into the same unit: &ldquo;wall warts&rdquo;. Here, there&rsquo;s a sizeable power brick (70mm x 75mm, or about three inches on a side) with a plug on one side of it, which can make plugging into the wall or even a power strip a little awkward, depending on the orientation. Samsung might rethink this with its next generation.</p>



<p>The charger does accomplish one thing, though, it powers up the Book3 Ultra quickly. Samsung claims that the Book3 will charge to 55 percent in 30 minutes. That&rsquo;s true, provided that you leave the laptop closed and in a sleep state. When open, we recorded a charge of about 25 percent during the same time.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Samsung Galaxy Book3 Ultra vents" class="wp-image-1660333" height="900" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/vents-1.jpg?quality=50&amp;strip=all&amp;w=1200" width="1200" /><figcaption>The Galaxy Book3 Ultra venting seems adequate, pulling air from underneath and pushing it out through the hinge vents.</figcaption></figure><p class="imageCredit">Mark Hachman / IDG</p></div>



<p>The Book3 Ultra&rsquo;s lid opens up with just the crook of a finger, exposing the gorgeous AMOLED 2X screen inside that fills almost all of the available space; there are no chunky bezels on this device. The new AMOLED 2X OLED is a key selling point of the Book3 lineup and it applies here. OLEDs are simply gorgeous displays, with absolute jet blacks that underscore the terrific contrast ratio. </p>



<p>In the real world, you won&rsquo;t notice as much impact on day-to-day office work, with its multicolored images and light backgrounds. If you prefer dark mode, however, it&rsquo;s a bonus. Movies, though, are where it really shines. Dark scenes appear truly <em>dark,</em> which adds an additional layer of visual fidelity to the experience.</p>



<figure class="wp-block-jetpack-image-compare"><div class="juxtapose"><img alt="Samsung Galaxy Book3 Ultra OLED color gamut" class="image-compare__image-before" height="1416" id="1663563" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/AMOLED-color-profile.png" width="1982" /><img alt="Samsung Galaxy Book3 Ultra AdobeRGB color gamut" class="image-compare__image-after" height="1397" id="1663562" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/color-profile-AdobeRGB.jpg?quality=50&amp;strip=all" width="1995" /></div><figcaption>Our colorimeter compares the standard &ldquo;OLED Mode&rdquo; color gamut (the default is an &ldquo;Auto&rdquo; setting) versus the AdobeRGB setting.</figcaption></figure>



<p>Samsung claims that the laptop produces 120 percent of the DCI-P3 color gamut, which simply translates into brighter, more vivid colors, as well as being rated for VESA ClearMR and DisplayHDR TRUE BLACK 500 certified. The Pro 360 OLED display does feature dedicated modes for DCI-P3, AdobeRGB and sRGB, as well as an &ldquo;Auto&rdquo; mode that presumably optimizes itself for the application. Based on our colorimeter, the Book3 Ultra appears to accommodate the full range of the color gamuts we tested under. </p>



<p>Samsung also claims that the display reduces blue light by 78 percent while in dark mode versus its light mode, which we haven&rsquo;t been able to verify.  It&rsquo;s an interesting claim, though, because normally laptops reduce blue light while in &ldquo;light mode,&rdquo; skewing the display towards yellowish tinges. The Book3 Ultra does the latter, too. However, reducing the amount of light hitting your eyeball while in dark mode <em>and</em> lowering the amount of blue light certainly should appeal to migraine sufferers.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Samsung Galaxy Book3 Ultra left side" class="wp-image-1660331" height="662" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/left-side.jpg?quality=50&amp;strip=all&amp;w=1200" width="1200" /><figcaption>A pair of Thunderbolt 4 ports can be found on the left side of the Samsung Galaxy Book3 Ultra.</figcaption></figure><p class="imageCredit">Mark Hachman / IDG</p></div>



<p>Samsung&rsquo;s new AMOLED 2X offers more than just visual improvements, though. Like the Microsoft Surface Laptop Studio, the Book3 Ultra&rsquo;s display is a &ldquo;dynamic&rdquo; 120Hz. When needed, the display can dial down to a more conservative 60Hz when idling, saving power. When necessary the display can increase its refresh rate to 120Hz, offering smoother mousing and gameplay. Normally, this helps inking, too. However, the Galaxy Book3 Ultra does not ship with a touchscreen, or a pen. For that, there&rsquo;s the Book3 Pro 360 instead.</p>



<h2 class="toc" id="samsung-galaxy-book3-ultra-chassis-and-ports">Samsung Galaxy Book3 Ultra: Chassis and ports</h2>



<p>When we first opened up the Book3 and began setting it up, we noticed the distinct high-pitched tones that indicate coil whine, when the fans speed up to cool the laptop down. In fairness, however, we haven&rsquo;t heard them since. Instead, the Book3 Ultra sucks in air through a small matrix of holes in the bottom of the chassis and pushes it out the back, though the hinge. The hiss it produces is noticeable though not overwhelming. We&rsquo;d expect more noise, though, if you opt for the Core i9/RTX 4070 option instead.</p>



<p>On the left side of the Book3 Ultra are a pair of Thunderbolt 4 ports, which can be used to connect to a <a href="https://www.pcworld.com/article/393714/best-thunderbolt-docks-for-a-laptop-pc.html">Thunderbolt dock</a>, including for external storage or a pair of 4K displays. Failing that, the Book3 Ultra also offers a dedicated HDMI 2.0 port, which can project to a single external 4K monitor, as well. On the right side, Samsung includes a microSD slot and a legacy USB-A port for a mouse, plus a headphone jack.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Samsung Galaxy Book3 Ultra right side" class="wp-image-1660334" height="759" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/right-side.jpg?quality=50&amp;strip=all&amp;w=1200" width="1200" /><figcaption>On the right side of the Samsung Galaxy Book3 Ultra you&rsquo;ll find a standard USB-A port, a microSD slot, and a headphone jack. You can barely see the speaker on the underside, to the left, which fires out and down.</figcaption></figure><p class="imageCredit">Mark Hachman / IDG</p></div>



<p>Samsung is a little less pushy than Microsoft in terms of encouraging you to connect your laptop to Samsung&rsquo;s network of apps, services, and devices, but the Book3 Ultra does ask for (but doesn&rsquo;t demand) a Samsung password when you set up the system. Doing so provides some benefits if you own other Samsung devices, and also enables some specific Samsung applications, which we&rsquo;ll talk about later.</p>



<h2 class="toc" id="samsung-galaxy-book3-ultra-typing-experience">Samsung Galaxy Book3 Ultra: Typing experience</h2>



<p>Samsung&rsquo;s 1.6:1 display ratio allows for a roomy keyboard, with a narrow number pad to the right-hand side&mdash;if you&rsquo;re a right-handed person, that might just be a convenience. As a lefty, though, the number pad is the equivalent of the WASD keys right-handers use, so any laptop with gaming potential earns a plus in that regard. Given that Samsung offers 16-inch options across most of its Book3 line, I would assume that any device you buy in this family will have the same keyboard, and they all should be equally usable.</p>



<p>As I wrote in my Book3 Pro 360 review, Samsung&rsquo;s chiclet keyboards always make me wonder if they&rsquo;ll actually be usable, as their key travel is often shallower than I&rsquo;d like. While I&rsquo;m still not sure if I&rsquo;d prefer them for long-term use, they&rsquo;re comfortable enough. Keyboards have become shallower over time, however, as manufacturers prefer to design thinner systems with less room for deep key travel. That&rsquo;s not a trend I endorse, but Samsung at least has managed a compromise. There are three levels of backlighting.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Samsung Galaxy Book3 Ultra keyboard" class="wp-image-1660330" height="783" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/keyboard-1.jpg?quality=50&amp;strip=all&amp;w=1200" width="1200" /><figcaption>The Samsung Galaxy Book3 Ultra&rsquo;s keyboard isn&rsquo;t terrific, but it&rsquo;s surprisingly serviceable. Like the other members of the Galaxy Book3 family, the laptop features a massive touchpad.</figcaption></figure><p class="imageCredit">Mark Hachman / IDG</p></div>



<p>Samsung again chooses to use a fingerprint reader, mounted inside the power button. Pushing it when the laptop is off or in standby allows you to power on and log in at the same time. While depth cameras can log you in quickly, they can become fooled by facial hair, wrinkles, or glasses. The Book3 lineup lacks depth cameras, using the fingerprint reader instead.</p>



<p>Fingerprint readers tend to be more consistent, but they can also become less accurate over time as the sensor becomes smudged. They&rsquo;re also sensitive to schmutz on your finger either during setup or authentication, as the Book3 Ultra was. Put another way, the fingerprint sensor worked acceptably during our time with the Book3, but this means little compared to the long term. </p>



<p>All of the new Book3 models seem to share an additional quirk. The gigantic touchpad at the bottom of the keyboard, which measures a massive 6 inches wide by about 4.25 inches deep. While you can tap upon its full breadth, the upper fifth or so isn&rsquo;t clickable. Even with such an enormous input device, there&rsquo;s still enough room for your palms on either side, though the touchpad is skewed toward the left-hand side. Taken together, the trackpad and keyboard are acceptable, though not outstanding.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Samsung Galaxy Book3 Ultra fingerprint reader power button" class="wp-image-1660341" height="871" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/fingerprint-reader-power-button.jpg?quality=50&amp;strip=all&amp;w=1200" width="1200" /><figcaption>Samsung&rsquo;s Galaxy Boo3 Ultra hides a fingerprint reader under the power button.</figcaption></figure><p class="imageCredit">Mark Hachman / IDG</p></div>



<h2 id="samsung-galaxy-book3-ultra-audio">Samsung Galaxy Book3 Ultra: Audio</h2>



<p>I made the mistake of reading TechAdvisor&rsquo;s review of the Book3 Pro right before writing this section and I can&rsquo;t help but agree with Anyron Copeman&rsquo;s <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.techadvisor.com/article/1520643/samsung-galaxy-book-3-pro-review.html&amp;xcust=2-1-1525530-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow">take</a>. The Book3 lineup excels at voice playback, whether in terms of music or the spoken word, and falls a bit short everywhere else. Out of the box, the Book3 Ultra and Pro 360 don&rsquo;t sound all that great, and require some tuning of the pre-installed Dolby Atmos app to arrive at an acceptable setting. (As far as I can tell, the Book 3 Pro 360 and the Book3 Ultra produce about the same audio quality.) Otherwise, the audio just sounds a bit distorted, though the volume level is excellent.</p>



<p>The Book3 Ultra uses a pair of downward facing speakers with discrete 5W woofers and 2W tweeters, sufficient to full the room with whatever you&rsquo;re playing back. None of the Book3 lineup provides poor audio; it&rsquo;s just that some other laptops I&rsquo;ve heard do better. Again, some tweaking will resolve most issues, and there&rsquo;s a headphone jack, too.</p>



<h2 id="samsung-galaxy-book3-ultra-webcam">Samsung Galaxy Book3 Ultra: Webcam</h2>



<p>When Intel launched its 13th-gen Core chips, the company said that &ldquo;select&rdquo; laptops would include a Movidius AI chip inside of them to enable AI effects. To date, the signal for those effects has been the Windows Studio Effects suite, originally launched with the Surface Pro 9 (5G) and its Qualcomm Snapdragon Arm chip. (Arm has integrated AI functions; the current 13th-gen Core chips do not.) </p>



<p>The Book3 includes the AI-powered Studio Effects suite, which includes an on-device replica of the background blurring effects you can find in Zoom, Teams, or Google Meet. HDR effects don&rsquo;t do much. You&rsquo;ll be more impressed with the webcam&rsquo;s ability to automatically pan and zoom, keeping you in frame. Indulge your vanity and turn on Face Effects, which can subtly remove the bags under your eyes from too many late nights. </p>



<figure class="wp-block-jetpack-image-compare"><div class="juxtapose"><img alt="Samsung Galaxy Book3 Pro Ultra webcam" class="image-compare__image-before" height="1080" id="1662112" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/WIN_20230315_17_12_54_Pro.jpg?quality=50&amp;strip=all" width="1920" /><img alt="Samsung Galaxy Book3 Pro Ultra webcam" class="image-compare__image-after" height="1080" id="1662113" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/WIN_20230315_17_14_14_Pro.jpg?quality=50&amp;strip=all" width="1920" /></div><figcaption>Two pictures with the Samsung Galaxy Book3 Ultra&rsquo;s webcam: one in a dimly lit room (left) and the other in more natural light.</figcaption></figure>



<p>Otherwise, the 1080p webcam&rsquo;s on the upper end of the spectrum of laptop webcams, with good color balance but a slightly soft focus. Like the Pro 360, Samsung does use AI to help cancel noise in video calls, however, and does so very well via a pair of studio mics. </p>



<h2 id="samsung-galaxy-book3-ultra-the-galaxy-ecosystem">Samsung Galaxy Book3 Ultra: The Galaxy ecosystem</h2>



<p>Samsung developed a suite of its own apps to connect its Galaxy devices such as the Book lineup, Tab tablets, and, of course, its Galaxy phones. These apps supplement and in some cases replace the applications that Microsoft itself provides, like &ldquo;Link to Windows&rdquo; as a replacement for <a href="https://www.pcworld.com/article/628261/microsoft-is-updating-your-phone-and-calling-it-phone-link.html">Phone Link</a>. This &ldquo;set bonus&rdquo; may not justify buying a suite of Samsung devices by themselves. If you do, however, there are benefits, as our tests of the Book3 and the latest Samsung Galaxy phones indicated.</p>



<p>Remember <a href="https://www.pcworld.com/article/407999/hands-on-how-one-mouse-can-control-multiple-pcs-with-microsofts-mouse-without-borders-app.html#:~:text=Like%20Flow%2C%20Microsoft%E2%80%99s%20Mouse%20without%20Borders%20allows%20you,to%20bring%20in%20additional%20PCs%20into%20your%20workspace.">Mouse without Borders</a>? The handy Microsoft app allows you to move a mouse between computers, which is a nifty trick. Samsung&rsquo;s Multi Control app does the same thing, which is a little bizarre&mdash;moving your mouse cursor from your laptop to your phone, and interacting with photos and files, even copying them or cutting and pasting&mdash;is neat, and useful. It&rsquo;s essentially a return to the old &ldquo;sneakernet&rdquo; of just copying files from one device to another. (Yes, you can automatically upload them to the cloud and then re-download them, too, but there&rsquo;s an immediacy to Multi Control which is extremely convenient.) If you own a Galaxy Tab tablet, you can also use a Tab as a second screen via the Second Screen app, too.</p>



<p>In fact, most of the Samsung app ecosystem is all about moving and sharing files. Quick Share can send a file to another Galaxy device and Private Share can be used to securely encrypt and share files to other devices&mdash;a bit like sharing a file from the cloud with another user, complete with file permissions and an expiration date. One exception is Clip Studio Paint, which gets around the lack of a touchscreen and pen by allowing you to use a Galaxy Phone with an S Pen instead. All of these apps have their own niches.</p>



<p>Samsung also has an app called Expert RAW Auto Share, which automatically sends photos taken with a Galaxy S23 phone to a nearby Galaxy tablet. As Samsung explains, that&rsquo;s handy for editing RAW photos with Adobe Lightroom&mdash;which Samsung provides a two-month trial of.</p>



<h2 class="toc" id="samsung-galaxy-book3-ultra-performance">Samsung Galaxy Book3 Ultra: Performance</h2>



<p>Content-creation notebooks represent a small and evolving niche of PCs, somewhere midway between a traditional gaming notebook and a productivity machine. Microsoft set out to help create this niche with its Surface Laptop Studio, and more recently we&rsquo;ve seen laptops like the <a href="https://www.pcworld.com/article/1428656/these-new-asus-laptops-may-have-the-best-display-youve-ever-seen.html">Asus ProArt StudioBook 16</a> 3D OLED (H7604 3D OLED), with a 120Hz OLED display all of its own. (We haven&rsquo;t received that device for testing yet.) </p>



<p>Unlike a pure gaming notebook, the importance of the Nvidia 4-series GPU is put to a variety of tasks such as gaming, 3D content creation, photo and video editing, and encoding. Content creation typically means video encoding, and this notebook seizes upon two emerging trends. First, <a href="https://www.pcworld.com/article/827992/tested-intel-arc-av1-video-encoder-vs-nvidia-amd.html">new video codecs like AV1</a>, which provide smaller file sizes (and less bandwidth for streaming) at the cost of more severe hardware requirements. Secondly, popular encoding software packages like OBS Studio now support AV1, a codec that requires either an Nvidia GeForce 3-series or 4-series GPU. Encoding using the more aggressive codec on cutting-edge laptop hardware should save both time and disk space, both arguments in favor of buying this laptop.</p>



<p>Keep in mind, though, that you&rsquo;re certainly not going to see the surprisingly high battery life when using the Book3 Ultra for content creation, versus the video playback test that we use to measure battery life, or content consumption. It&rsquo;s at this point that you&rsquo;ll see the Book3 echo some of the problems gaming notebooks have&mdash;they&rsquo;re great when connected to their power cord, but their longevity can suffer when on battery and under load.</p>



<p>Incidentally, the Book3 Ultra is one of the few that we saw that did not suffer from thermal throttling, at least in terms of 3D performance. (Throttling can occur when the laptop slows down its CPU or GPU to maintain thermal limits, reducing performance for the sake of stability.) Performance dropped 11 percent when our CPU benchmark was looped for 10 straight minutes. However, when we looped the 3DMark benchmark for 20 straight runs, it passed the test, delivering 99.6 percent of the frame rate that it did in the beginning.</p>



<p>Anecdotally, the Book3 Ultra felt laggy when loading applications. But after checking the transfer rates, we changed our tune. Random reads and writes aren&rsquo;t too shabby, but the sequential read and write speeds are outstanding.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-full"><img alt="Samsung Galaxy Book3 Ultra SSD CrystalDiskMark 8" class="wp-image-1663528" height="724" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/CrystalDiskMark-scores.jpg?quality=50&amp;strip=all" width="1024" /></figure><p class="imageCredit">Mark Hachman / IDG</p></div>



<p>We&rsquo;ve compared the $2,399 Samsung Galaxy Book3 Ultra to its stablemate, the <a href="https://www.pcworld.com/article/1499055/samsung-galaxy-book3-pro-360-review.html">Samsung Galaxy Book3 Pro 360</a>, which we highlight in orange. We compare the Book3 Ultra to the mainstream $1,799 <a href="https://www.pcworld.com/article/1357810/microsoft-surface-laptop-5-review-for-surface-fans-only.html">Surface Laptop 5 (15-inch)</a> and Microsoft&rsquo;s $2,699 content-creation laptop, the <a href="https://www.pcworld.com/article/1357810/microsoft-surface-laptop-5-review-for-surface-fans-only.html">Surface Laptop Studio</a>. To that we add the <a href="https://www.pcworld.com/article/631211/lenovo-yoga-9i-review-the-pinnacle-of-design.html">Lenovo Yoga 9i 14</a>, a $1,449 mainstream OLED laptop. Our main focus, though, is seeking out comparably-sized laptops with discrete graphics. Those include the $1,765 <a href="https://www.pcworld.com/article/834845/lenovo-slim-7-pro-x-review-packing-prosumer-power-at-a-reasonable-price.html">Lenovo Slim 7 Pro X</a> and the $1,599 <a href="https://www.pcworld.com/article/697179/asus-vivobook-pro-16x-oled-review-a-practical-creator-laptop-with-a-brilliant-display.html">Asus Vivobook Pro 16X OLED</a>, another content-creation machine. </p>



<p>We round out our testing by adding three &ldquo;traditional&rdquo; gaming laptops, all of which could potentially replace the Book3 Ultra. The $1,049 <a href="https://www.pcworld.com/article/1529835/msi-katana-gf66-review.html">MSI Katana GF66 12UD</a>, the $3,825 <a href="https://www.pcworld.com/article/1519631/asus-rog-zephyrus-duo-16-2022-review">Asus ROG Zephyrus Duo 16</a>, a dual-screen laptop aimed at both content creation and gaming, and the <a href="https://www.pcworld.com/article/1561127/msi-titan-gt77-hx-13v-review.html">MSI Titan GT 77 HX 13V</a>, priced at a &ldquo;you could buy two Book3&rsquo;s for this&rdquo; $5,299.</p>



<p>We use four tests to measure performance: UL&rsquo;s PCMark10 and 3DMark; Cinebench R15, and Handbrake.</p>



<p>PCMark10 is an excellent metric of everyday performance, using actual apps that measure everything from office work, photo and video editing to CAD work. Normally, we expect a laptop to perform well here, but there&rsquo;s still room for separation from the pack. The &ldquo;H&rdquo;-class processor and discrete GPU help achieve this.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-full"><img alt="Samsung Galaxy Book3 Ultra" class="wp-image-1662102" height="640" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/PCMark-10.png" width="1024" /><figcaption>The Samsung Galaxy Book3 Ultra performs just fine as an everyday office PC, as expected.</figcaption></figure><p class="imageCredit">Mark Hachman / IDG</p></div>



<p>We use the Cinebench R15 benchmark as a metric for a quick burst of CPU performance, stressing all of its cores and threads.  With six dual-threaded performance cores and eight single-threaded efficiency cores, the twenty threads chew through our test in a matter of moments. (We also test using the more sophisticated R20 benchmark, with the idea that we&rsquo;ll eventually transition to that metric.) </p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-full"><img alt="Samsung Galaxy Book3 Ultra" class="wp-image-1662105" height="634" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/Cinebench-R15.jpg?quality=50&amp;strip=all" width="1024" /><figcaption>The Samsung Galaxy Book3 Ultra performs admirably in our COU test, outclassed only by the powerful 13th-gen HX CPU of the MSI Titan.</figcaption></figure><p class="imageCredit">Mark Hachman / IDG</p></div>



<p>Handbrake measures CPU performance as well, though over a prolonged period of time.  We use the open-source app to transcode a movie into a format that could be used by a tablet. This real-world test demonstrates how well a laptop can perform under prolonged load. Since it accomplishes its task in just minutes, it also demonstrates the practical purposes of the app, too.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Samsung Galaxy Book3 Ultra" class="wp-image-1662103" height="793" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/Handbrake-1.jpg?quality=50&amp;strip=all&amp;w=1200" width="1200" /><figcaption>Not a terrific score for the Samsung Galaxy Book3 Ultra, but serviceable.</figcaption></figure><p class="imageCredit">Mark Hachman / IDG</p></div>



<p>We use the 3DMark Time Spy test to measure 3D performance with an eye toward gaming, as the video-encoding capabilities aren&rsquo;t put to the test. There&rsquo;s a significant gap between the GeForce RTX 4050 and the remainder of the GeForce RTX 4-series GPUs&hellip; though even the lowest rung on this ladder is high up.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-full"><img alt="Samsung Galaxy Book3 Ultra" class="wp-image-1662106" height="707" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/3DMark-Time-Spy.jpg?quality=50&amp;strip=all" width="1024" /><figcaption>The Samsung Galaxy Book3 Ultra isn&rsquo;t a gaming machine, but generally holds its own on the low end of the gaming PC market. Many of these PCs include discrete GPUs.</figcaption></figure><p class="imageCredit">Mark Hachman / IDG</p></div>



<p>We also tested two games, <em>Forza Horizon 4</em> and <em>Troy: A Total War Saga</em>, to measure game performance. The Book3 excelled at the default resolution and Ultra settings. It rendered 70 frames per second in Forza, a terrific performance. In the <em>Total War</em> battle simulator, the laptop rendered almost 40 fps at Ultra settings as well.</p>



<p>A real strength of the Book3 Ultra, however, is delivering terrific battery life<em> and</em> fantastic performance. Yes, some of that can be felt on your back as you lug about the Book3&rsquo;s four pounds or so. Still, we often don&rsquo;t see all-day performance in a laptop.</p>



<figure class="wp-block-jetpack-image-compare"><div class="juxtapose"><img alt="Samsung Galaxy Book3 Ultra Forza Horizon 4" class="image-compare__image-before" height="1800" id="1662128" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/Forza-4-full-ultra.jpg?quality=50&amp;strip=all" width="2880" /><img alt="Total War: Troy full rez" class="image-compare__image-after" height="1800" id="1662129" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/Troy-full-res-2880x1800-1.jpg?quality=50&amp;strip=all" width="2875" /></div><figcaption>Both games were run on Ultra settings at the native 2880&times;1800 resolution. Both were playable, at over 60 fps for Forza Horizon 4, and above 30 fps for the real-time strategy game <em>Troy: A Total War Story.</em> Lowering the resolution or visual quality will improve performance.</figcaption></figure>



<p>Keep in mind, though, that our video test only really measures how long the laptop can keep the display lit and CPU active; looping a 4K video doesn&rsquo;t really push the laptop hard, if at all. Our tests show that it lasts 786 minutes, or just over 13 hours&mdash;that&rsquo;s a full day&rsquo;s work and then some. Looping a 3D benchmark over and over is a good measure of how long you&rsquo;ll be able to play or do strenuous work on the laptop&rsquo;s battery before it expires; there, the laptop only lasted 1 hour and 46 minutes. </p>



<p>That may sound like a huge difference, but it&rsquo;s pretty typical for a gaming notebook and, under load, the H-series CPU and RTX 4xxx GPU essentially act like a gaming laptop.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-full"><img alt="Samsung Galaxy Book3 Ultra" class="wp-image-1662104" height="673" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/Battery-life.jpg?quality=50&amp;strip=all" width="1024" /><figcaption>The Samsung Galaxy Book3 Ultra turns in quite an impressive score in terms of battery life. The OLED display may play a role here. Gaming laptops don&rsquo;t often worry too much abut battery, either.</figcaption></figure><p class="imageCredit">Mark Hachman / IDG</p></div>



<p>During the benchmark loop, though, the laptop shut off the fan about 50 loops in, dropping the frame rate from about 30 frames per second to 10 fps or so&mdash;then down to 3 fps a bit later. That was wholly unexpected. We asked Samsung for comment, but they hadn&rsquo;t yet responded after several days. </p>



<p>Still, there&rsquo;s quite a discrepancy between 13.1 hours of battery life while looping a video and just under two hours while playing a game. Plan accordingly!</p>



<h2 id="samsung-galaxy-book3-ultra-should-you-buy-it">Samsung Galaxy Book3 Ultra: Should you buy it?</h2>



<p>With more variety in terms of display, processor, GPU, and features than perhaps ever before, it&rsquo;s difficult to compare the Samsung Galaxy Book3 Ultra to anything else currently on the market. The Book3 Ultra holds its own in terms of performance against everything but the MSI Katana, a budget gaming laptop that&rsquo;s comparable on paper but little else. </p>



<p>Samsung compares well in performance, with very little competition in battery life&mdash;at least when it comes back to playing back video. And video <em>looks</em> great, too, on the Book3 Ultra&rsquo;s OLED screen. The price certainly leans heavily toward the premium tier, though not too far out of reach for what the Book3 Ultra offers.</p>



<p>Based on what we know of the upcoming Asus Vivobook Pro 16X 3D OLED and last year&rsquo;s <a href="https://www.pcworld.com/article/697179/asus-vivobook-pro-16x-oled-review-a-practical-creator-laptop-with-a-brilliant-display.html">VivoBook Pro 16X OLED</a>, we&rsquo;d say the upcoming Asus Vivobook promises the stiffest challenge to the Book3 Ultra. But it hasn&rsquo;t arrived yet. Right now, the Samsung Galaxy Book3 Ultra is the content-creation notebook to beat&mdash;and for the moment, nothing does.</p>



<p></p>



<p></p>

Laptops</div>

## Avoid roaming charges with this specialized eSIM
 - [https://www.pcworld.com/article/1671173/avoid-roaming-charges-with-this-specialized-esim.html](https://www.pcworld.com/article/1671173/avoid-roaming-charges-with-this-specialized-esim.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-03-27 08:00:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>Whether you&rsquo;re traveling for&nbsp;<a href="https://www.pcworld.com/article/435092/5-apps-business-travelers-shouldnt-leave-home-without.html" rel="noreferrer noopener" target="_blank">business</a>&nbsp;or pleasure, if you have a bad phone plan, you won&rsquo;t be thrilled when you see the overages and roaming charges on your bill. You don&rsquo;t even have to be traveling abroad, it can happen domestically, too.</p>



<p>When you know you&rsquo;re going to incur annoying fees, it&rsquo;s helpful to have a tool like an&nbsp;<a href="https://shop.pcworld.com/sales/instabridge-esim-usa-lifetime-plan-2-gb-month?utm_source=pcworld.com&amp;utm_medium=referral&amp;utm_campaign=instabridge-esim-usa-lifetime-plan-2-gb-month&amp;utm_term=scsf-567446&amp;utm_content=a0x1P0000058XwNQAU&amp;scsonar=1" rel="noreferrer noopener" target="_blank">Instabridge eSIM</a>&nbsp;in your pocket. This innovative app lets you activate a data eSIM on your device to get a fast, reliable internet connection that helps you avoid data overages or roaming charges.</p>



<p>With Instabridge, you can access free mobile data packages by simply watching ads. Better yet, you can pay upfront for a Lifetime Plan to ensure you always have data available without having to waste time with ads. And during our Spring Digital Blowout, the plan is 85% off. Just make sure to order between 3/22 and 4/3.</p>



<p>Don&rsquo;t suffer surprise fees and data overages. Now through 11:59 pm on 4/3, you can get an&nbsp;<a href="https://shop.pcworld.com/sales/instabridge-esim-usa-lifetime-plan-2-gb-month?utm_source=pcworld.com&amp;utm_medium=referral&amp;utm_campaign=instabridge-esim-usa-lifetime-plan-2-gb-month&amp;utm_term=scsf-567446&amp;utm_content=a0x1P0000058XwNQAU&amp;scsonar=1" rel="noreferrer noopener" target="_blank">Instabridge eSIM</a>&nbsp;Lifetime Plan for 85% off $1,000 at just $149.</p>



<p><a href="https://shop.pcworld.com/sales/instabridge-esim-usa-lifetime-plan-2-gb-month?utm_source=pcworld.com&amp;utm_medium=referral-cta&amp;utm_campaign=instabridge-esim-usa-lifetime-plan-2-gb-month&amp;utm_term=scsf-567446&amp;utm_content=a0x1P0000058XwNQAU&amp;scsonar=1" rel="noreferrer noopener" target="_blank">&nbsp;</a></p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image"><img alt="" src="https://cdnp1.stackassets.com/61d06c33d5ca61416103dc78fcc61459f8592998/store/af699063b298018e61964b86efb79fcf12943d05d67977a3bfa1330ef996/sale_320898_primary_image.jpg" /></figure></div>



<p><strong>Instabridge eSIM: Lifetime Plan &ndash; $149</strong></p>



<p><a href="https://shop.pcworld.com/sales/instabridge-esim-usa-lifetime-plan-2-gb-month?utm_source=pcworld.com&amp;utm_medium=referral-cta&amp;utm_campaign=instabridge-esim-usa-lifetime-plan-2-gb-month&amp;utm_term=scsf-567446&amp;utm_content=a0x1P0000058XwNQAU&amp;scsonar=1" rel="noreferrer noopener" target="_blank">See Deal</a></p>



<p>Prices subject to change.</p>

Business</div>

