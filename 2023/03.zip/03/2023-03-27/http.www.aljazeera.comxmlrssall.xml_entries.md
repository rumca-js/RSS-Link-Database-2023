# Source:Aljazeera, URL:http://www.aljazeera.com/xml/rss/all.xml, language:en-US

## UN Security Council turns down request for Nord Stream inquiry
 - [https://www.aljazeera.com/news/2023/3/27/un-security-council-turns-down-request-for-nord-stream-inquiry](https://www.aljazeera.com/news/2023/3/27/un-security-council-turns-down-request-for-nord-stream-inquiry)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 23:18:14+00:00

Questions remain over explosions in September that damaged gas pipelines connecting Russia and Germany.

## Brazilian teenager accused of fatally stabbing Sao Paulo teacher
 - [https://www.aljazeera.com/news/2023/3/27/brazil-teenager-accused-of-fatally-stabbing-teacher](https://www.aljazeera.com/news/2023/3/27/brazil-teenager-accused-of-fatally-stabbing-teacher)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 21:41:15+00:00

Brazilian media outlets say the 13-year-old suspect appeared to be inspired by a deadly school shooting in 2019.

## Will Vladimir Putin go nuclear in Ukraine?
 - [https://www.aljazeera.com/program/inside-story/2023/3/27/will-vladimir-putin-go-nuclear-in-ukraine](https://www.aljazeera.com/program/inside-story/2023/3/27/will-vladimir-putin-go-nuclear-in-ukraine)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 20:33:00+00:00

The Russian president said he will deploy nuclear weapons in neighbouring Belarus.

## Kenya police fire tear gas to disperse anti-government protesters
 - [https://www.aljazeera.com/gallery/2023/3/27/photo-kenya-police-fire-tear-gas-at-anti-government-protesters](https://www.aljazeera.com/gallery/2023/3/27/photo-kenya-police-fire-tear-gas-at-anti-government-protesters)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 20:26:37+00:00

Thousands of protesters march in Nairobi against the rising cost of living despite the government ban on rallies.

## Biden signs executive order restricting use of commercial spyware
 - [https://www.aljazeera.com/news/2023/3/27/biden-signs-executive-order-restricting-use-of-commercial-spyware](https://www.aljazeera.com/news/2023/3/27/biden-signs-executive-order-restricting-use-of-commercial-spyware)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 19:18:51+00:00

The decision comes as governments around the world face accusations of using spyware to target dissidents.

## Ecuador: At least 16 dead after heavy rainfall causes landslide
 - [https://www.aljazeera.com/gallery/2023/3/27/ecuador-at-least-16-dead-after-heavy-rainfall-causes-landslide](https://www.aljazeera.com/gallery/2023/3/27/ecuador-at-least-16-dead-after-heavy-rainfall-causes-landslide)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 18:25:35+00:00

Emergency officials say the massive landslide also injured 16 people in Andean community in central Ecuador.

## Scientists discover water inside tiny beads of glass on moon
 - [https://www.aljazeera.com/news/2023/3/27/scientists-find-water-inside-glass-beads-scattered-across-moon](https://www.aljazeera.com/news/2023/3/27/scientists-find-water-inside-glass-beads-scattered-across-moon)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 17:56:06+00:00

Analysis of lunar soil samples shows spheres of glass hold water inside them, scientists have said.

## China says no conditions on Honduras diplomatic deal
 - [https://www.aljazeera.com/news/2023/3/27/china-says-no-conditions-on-honduras-diplomatic-deal](https://www.aljazeera.com/news/2023/3/27/china-says-no-conditions-on-honduras-diplomatic-deal)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 17:27:29+00:00

Honduras has become the latest Latin American country to open formal ties with Beijing and end relations with Taiwan.

## Israel PM Netanyahu delays judicial overhaul plan after protests
 - [https://www.aljazeera.com/news/2023/3/27/israel-pm-netanyahu-suspends-judicial-change-plan-after-protest](https://www.aljazeera.com/news/2023/3/27/israel-pm-netanyahu-suspends-judicial-change-plan-after-protest)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 17:20:32+00:00

Netanyahu postponed the plan until May, and in the meantime, granted right-wing minister Ben Gvir a new security force.

## Ecuador landslide kills at least 16, others reported missing
 - [https://www.aljazeera.com/news/2023/3/27/ecuador-landslide-kills-at-least-16-others-reported-missing](https://www.aljazeera.com/news/2023/3/27/ecuador-landslide-kills-at-least-16-others-reported-missing)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 17:09:13+00:00

Seven people are missing as rescuers clear debris after wave of mud and debris swept through small town of Alausi.

## 3 children killed in Nashville primary school shooting: Officials
 - [https://www.aljazeera.com/news/2023/3/27/children-killed-in-nashville-primary-school-shooting-officials](https://www.aljazeera.com/news/2023/3/27/children-killed-in-nashville-primary-school-shooting-officials)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 17:01:28+00:00

Three children suffering gunshot wounds pronounced dead at hospital after shooting on Monday morning.

## South Africa shocked by prison break of rapist who faked death
 - [https://www.aljazeera.com/news/2023/3/27/rapists-fake-death-prison-break-shocks-south-africa](https://www.aljazeera.com/news/2023/3/27/rapists-fake-death-prison-break-shocks-south-africa)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 16:49:32+00:00

Recent DNA tests reveal a body found in a prison and believed to be the serial sex offender is someone else.

## Cuba hails legislative election as ‘victory’ despite criticism
 - [https://www.aljazeera.com/news/2023/3/27/cuba-hails-legislative-election-as-victory-despite-criticism](https://www.aljazeera.com/news/2023/3/27/cuba-hails-legislative-election-as-victory-despite-criticism)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 16:26:38+00:00

Authorities say turnout surpassed 75 percent in weekend vote that did not include any opposition candidates.

## Kamala Harris begins Africa tour, announces security aid in Ghana
 - [https://www.aljazeera.com/news/2023/3/27/kamala-harris-starts-africa-tour-in-ghana-announces-security-aid](https://www.aljazeera.com/news/2023/3/27/kamala-harris-starts-africa-tour-in-ghana-announces-security-aid)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 16:17:46+00:00

The US pledged help for Benin, Ghana, Guinea, Ivory Coast and Togo to tackle violent groups and instability.

## More than 180 Rohingya refugees land in western Indonesia
 - [https://www.aljazeera.com/news/2023/3/27/more-than-180-rohingya-land-in-western-indonesia](https://www.aljazeera.com/news/2023/3/27/more-than-180-rohingya-land-in-western-indonesia)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 15:54:04+00:00

Hundreds have reached Indonesia since November last year as they escape desperate conditions in Myanmar and Bangladesh.

## UN mission accuses EU of aiding crimes against humanity in Libya
 - [https://www.aljazeera.com/news/2023/3/27/un-mission-accuses-eu-of-aiding-crimes-against-humanity-in-libya-2](https://www.aljazeera.com/news/2023/3/27/un-mission-accuses-eu-of-aiding-crimes-against-humanity-in-libya-2)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 15:35:42+00:00

Fact-finding mission says state security forces and armed militia groups have committed a wide array of crimes.

## Lebanon’s cabinet reverses decision to delay clock change
 - [https://www.aljazeera.com/news/2023/3/27/lebanon-reverts-to-daylight-saving-time-after-confusion-furor](https://www.aljazeera.com/news/2023/3/27/lebanon-reverts-to-daylight-saving-time-after-confusion-furor)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 15:31:44+00:00

Lebanon has operated in two time zones as some businesses and institutions followed the order and others refused.

## Mississippi faces ‘long road to recovery’ after deadly tornadoes
 - [https://www.aljazeera.com/news/2023/3/27/mississippi-faces-long-road-to-recovery-after-deadly-tornadoes](https://www.aljazeera.com/news/2023/3/27/mississippi-faces-long-road-to-recovery-after-deadly-tornadoes)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 14:14:58+00:00

Residents of storm-stricken southern US state, one of nation&#039;s poorest, are grappling with widespread devastation.

## Iraqi parliament passes controversial vote law amendments
 - [https://www.aljazeera.com/news/2023/3/27/iraqi-parliament-passes-controversial-vote-law-amendments](https://www.aljazeera.com/news/2023/3/27/iraqi-parliament-passes-controversial-vote-law-amendments)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 13:38:24+00:00

Move will increase the size of electoral districts, a decision widely supported by the country&#039;s Iran-backed coalition.

## Scotland’s ruling SNP picks Humza Yousaf to succeed Sturgeon
 - [https://www.aljazeera.com/news/2023/3/27/scotlands-ruling-snp-picks-humza-yousaf-to-succeed-sturgeon](https://www.aljazeera.com/news/2023/3/27/scotlands-ruling-snp-picks-humza-yousaf-to-succeed-sturgeon)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 13:11:03+00:00

The new party leader is due to be confirmed as first minister by Scottish lawmakers on Tuesday.

## Ex-Taiwan leader visits China, first such trip since civil war
 - [https://www.aljazeera.com/news/2023/3/27/former-taiwan-leader-arrives-in-china-first-such-trip-in-decades](https://www.aljazeera.com/news/2023/3/27/former-taiwan-leader-arrives-in-china-first-such-trip-in-decades)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 12:47:50+00:00

Former President Ma Ying-jeou in Beijing as Taiwan&#039;s ruling party accuses him of &#039;endorsing&#039; Beijing&#039;s Taiwan policy.

## German transport workers stage one of largest strikes in decades
 - [https://www.aljazeera.com/news/2023/3/27/germanys-transport-workers-stage-largest-strike-in-decades](https://www.aljazeera.com/news/2023/3/27/germanys-transport-workers-stage-largest-strike-in-decades)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 12:45:35+00:00

Employees are demanding better pay and working conditions as inflation weakens living standards.

## El Salvador: A nation under hypnosis
 - [https://www.aljazeera.com/opinions/2023/3/27/el-salvador-a-nation-under-hypnosis](https://www.aljazeera.com/opinions/2023/3/27/el-salvador-a-nation-under-hypnosis)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 12:44:02+00:00

After a year of President Bukele&#039;s state of emergency, a &#039;new reality&#039; is settling into the country.

## Black children six times likelier to be strip-searched: UK report
 - [https://www.aljazeera.com/news/2023/3/27/black-children-six-times-likelier-to-be-strip-searched-uk-report](https://www.aljazeera.com/news/2023/3/27/black-children-six-times-likelier-to-be-strip-searched-uk-report)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 12:14:12+00:00

An investigation was launched after a Black 15-year-old girl was strip-searched at a London school in 2020.

## Alibaba founder Jack Ma makes rare public appearance in China
 - [https://www.aljazeera.com/news/2023/3/27/alibaba-founder-jack-ma-makes-rare-public-appearance-in-china](https://www.aljazeera.com/news/2023/3/27/alibaba-founder-jack-ma-makes-rare-public-appearance-in-china)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 11:37:01+00:00

The return of China&#039;s best-known entrepreneur may help quell concerns of private sector after regulatory crackdown.

## History Illustrated: Russia and Ukraine, a history of violence
 - [https://www.aljazeera.com/gallery/2023/3/27/history-illustrated-russia-and-ukraine-a-history-of-violence](https://www.aljazeera.com/gallery/2023/3/27/history-illustrated-russia-and-ukraine-a-history-of-violence)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 11:29:49+00:00

Putin thinks Ukraine belongs to Russia based on what happened 1,000 years ago. The Ukrainians could not disagree more.

## Kenyan opposition leader Odinga says protests on despite police ban
 - [https://www.aljazeera.com/news/2023/3/27/kenyan-opposition-leader-odinga-says-protests-on-despite-police-ban-2](https://www.aljazeera.com/news/2023/3/27/kenyan-opposition-leader-odinga-says-protests-on-despite-police-ban-2)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 10:20:04+00:00

Odinga has called for indefinite twice-weekly protests, citing high living costs and electoral malpractice in 2022 vote.

## Timeline: How Israel’s judicial changes crisis unfolded
 - [https://www.aljazeera.com/news/2023/3/27/timeline-how-did-israels-judiciary-protest-unfold](https://www.aljazeera.com/news/2023/3/27/timeline-how-did-israels-judiciary-protest-unfold)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 10:08:52+00:00

Israelis have been protesting for months against Netanyahu&#039;s proposed judicial changes.

## Blast near Afghanistan’s foreign ministry kills at least two: NGO
 - [https://www.aljazeera.com/news/2023/3/27/blast-near-afghanistan-foreign-ministry-kills-at-least-two-ngo](https://www.aljazeera.com/news/2023/3/27/blast-near-afghanistan-foreign-ministry-kills-at-least-two-ngo)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 10:02:18+00:00

Twelve people are also injured in the explosion in downtown Kabul, according to a hospital run by an Italian NGO.

## Burkina Faso halts France 24 broadcasts after al-Qaeda interview
 - [https://www.aljazeera.com/news/2023/3/27/burkina-faso-suspends-france-24-broadcasts-in-the-country-after-al-qaeda-interview](https://www.aljazeera.com/news/2023/3/27/burkina-faso-suspends-france-24-broadcasts-in-the-country-after-al-qaeda-interview)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 09:45:53+00:00

Paris and Ouagadougou&#039;s relations have deteriorated sharply since Burkinabe military seized power in an October coup.

## The judicial change plan that led Israel to political crisis
 - [https://www.aljazeera.com/news/2023/3/27/the-judicial-change-plan-led-israel-political-crisis](https://www.aljazeera.com/news/2023/3/27/the-judicial-change-plan-led-israel-political-crisis)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 09:36:16+00:00

Reports that PM Netanyahu will halt his plans, after weeks of protest and the sacking of his defence minister.

## Saudi National Bank appoints chairman after Credit Suisse loss
 - [https://www.aljazeera.com/news/2023/3/27/saudi-national-bank-appoints-chairman-after-credit-suisse-loss](https://www.aljazeera.com/news/2023/3/27/saudi-national-bank-appoints-chairman-after-credit-suisse-loss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 09:28:12+00:00

SNB acquired almost 9.9 percent of Credit Suisse for $1.46bn in November but has lost more than $1bn on its investment.

## Taiwan welcomes Czech delegation after Honduras shifts allegiance
 - [https://www.aljazeera.com/news/2023/3/27/taiwan-welcomes-czech-delegation-after-honduras-shifts-allegiance](https://www.aljazeera.com/news/2023/3/27/taiwan-welcomes-czech-delegation-after-honduras-shifts-allegiance)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 09:10:24+00:00

US allies have been bolstering support for the island despite Honduras&#039;s move to cut ties with Taiwan.

## Myanmar military pledges decisive action against opponents
 - [https://www.aljazeera.com/news/2023/3/27/myanmar-military-pledges-decisive-action-to-crush-opponents](https://www.aljazeera.com/news/2023/3/27/myanmar-military-pledges-decisive-action-to-crush-opponents)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 08:52:13+00:00

At Armed Forces Day parade, Min Aung Hlaing says &#039;terror acts&#039; of coup opponents need to be tackled &#039;for good and all&#039;.

## ‘Either Imran Khan exists or we do’, says Pakistan home minister
 - [https://www.aljazeera.com/news/2023/3/27/either-imran-khan-exists-or-we-do-says-pakistan-home-minister](https://www.aljazeera.com/news/2023/3/27/either-imran-khan-exists-or-we-do-says-pakistan-home-minister)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 08:37:34+00:00

Rana Sanaullah&#039;s remarks against Khan during a TV interview trigger a sharp reaction from the opposition PTI party.

## Photos: Mass protests erupt in Israel as it faces ‘an abyss’
 - [https://www.aljazeera.com/gallery/2023/3/27/photos-mass-protests-erupt-in-israel](https://www.aljazeera.com/gallery/2023/3/27/photos-mass-protests-erupt-in-israel)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 07:53:45+00:00

Sacked defence chief had warned the deep divisions in Israel were threatening to weaken the military.

## Russia may demand compensation over Nord Stream blasts: Diplomat
 - [https://www.aljazeera.com/news/2023/3/27/russia-may-demand-compensation-over-nord-stream-blasts-diplomat](https://www.aljazeera.com/news/2023/3/27/russia-may-demand-compensation-over-nord-stream-blasts-diplomat)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 07:33:16+00:00

Dmitry Birichevsky says Moscow intends to continue to insist on a comprehensive and open international probe.

## Canada’s McCarthyism and the spies stirring a yellow peril scare
 - [https://www.aljazeera.com/opinions/2023/3/27/canadas-mccarthyism-and-the-spies-stirring-a-yellow-peril-scare](https://www.aljazeera.com/opinions/2023/3/27/canadas-mccarthyism-and-the-spies-stirring-a-yellow-peril-scare)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 07:25:50+00:00

Anonymously but very effectively, they&#039;re peddling racist tropes about the loyalty of Canadians of Chinese descent.

## Despite a buyer for SVB, default stress haunts banks
 - [https://www.aljazeera.com/economy/2023/3/27/despite-a-buyer-for-svb-default-stress-haunts-banks](https://www.aljazeera.com/economy/2023/3/27/despite-a-buyer-for-svb-default-stress-haunts-banks)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 07:09:18+00:00

SVB&#039;s purchase by First Citizens gives markets some respite but it&#039;s only &#039;a little bit of calm before the next storm&#039;.

## Banking turmoil has ‘potential’ to spark global crisis: ANZ CEO
 - [https://www.aljazeera.com/economy/2023/3/27/banking-turmoil-has-potential-to-spark-global-crisis-anz-ceo](https://www.aljazeera.com/economy/2023/3/27/banking-turmoil-has-potential-to-spark-global-crisis-anz-ceo)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 05:47:06+00:00

Shayne Elliott says it&#039;s &#039;premature&#039; to say Silicon Valley Bank, Credit Suisse woes will cause repeat of 2008 crisis.

## Afghanistan wins landmark cricket series against Pakistan
 - [https://www.aljazeera.com/news/2023/3/27/afghanistan-wins-landmark-cricket-series-against-pakistan](https://www.aljazeera.com/news/2023/3/27/afghanistan-wins-landmark-cricket-series-against-pakistan)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 05:46:25+00:00

Afghanistan beat Pakistan by seven wickets in second Twenty20 international and take an unassailable 2-0 lead in series.

## France’s Borne to meet opposition, unions amid pension crisis
 - [https://www.aljazeera.com/news/2023/3/27/frances-borne-to-meet-opposition-unions-amid-pension-crisis](https://www.aljazeera.com/news/2023/3/27/frances-borne-to-meet-opposition-unions-amid-pension-crisis)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 05:10:36+00:00

Prime minister says her objective is to &#039;bring calm to&#039; France after violent protests against pension reform plans.

## China’s Baidu cancels showcase for ChatGPT rival Ernie
 - [https://www.aljazeera.com/economy/2023/3/27/chinas-baidu-cancels-showcase-for-chatgpt-rival-ernie](https://www.aljazeera.com/economy/2023/3/27/chinas-baidu-cancels-showcase-for-chatgpt-rival-ernie)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 04:56:43+00:00

Beijing-based search engine giant changes showcase to closed-door event for firms, citing &#039;strong demand&#039;.

## Nepal suspends two controllers after flights avert midair crash
 - [https://www.aljazeera.com/news/2023/3/27/nepal-suspends-two-controllers-after-flights-avert-mid-air-crash](https://www.aljazeera.com/news/2023/3/27/nepal-suspends-two-controllers-after-flights-avert-mid-air-crash)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 04:33:11+00:00

Civil Aviation Authority of Nepal suspends the employees of the air traffic controller department for &#039;carelessness&#039;.

## Twitter source code partially leaked online, court filing says
 - [https://www.aljazeera.com/economy/2023/3/27/twitter-source-code-partially-leaked-online-court-filing-says](https://www.aljazeera.com/economy/2023/3/27/twitter-source-code-partially-leaked-online-court-filing-says)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 04:28:57+00:00

GitHub removed code shared without permission after request by social media giant, court filing says.

## Saudi, Iran foreign ministers to meet during Ramadan
 - [https://www.aljazeera.com/news/2023/3/27/saudi-iranian-foreign-ministers-to-meet-during-ramadan](https://www.aljazeera.com/news/2023/3/27/saudi-iranian-foreign-ministers-to-meet-during-ramadan)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 04:09:31+00:00

Planned meeting comes after Saudi Arabia and Iran signed a deal to restore ties after seven years of estrangement.

## Russia-Ukraine war: List of key events, day 397
 - [https://www.aljazeera.com/news/2023/3/27/russia-ukraine-war-list-of-key-events-day-397](https://www.aljazeera.com/news/2023/3/27/russia-ukraine-war-list-of-key-events-day-397)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 03:27:45+00:00

As the Russia-Ukraine war enters its 397th day, we take a look at the main developments.

## Picking up the pieces after twin cyclones hit Vanuatu
 - [https://www.aljazeera.com/news/2023/3/27/picking-up-the-pieces-after-twin-cyclones-hit-vanuatu](https://www.aljazeera.com/news/2023/3/27/picking-up-the-pieces-after-twin-cyclones-hit-vanuatu)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 03:08:18+00:00

Two Category 4 cyclones hit Vanuatu within 72 hours in early March.

## China’s rich flee crackdowns for ‘Asia’s Switzerland’ Singapore
 - [https://www.aljazeera.com/economy/2023/3/27/chinas-rich-flee-crackdowns-for-asias-switzerland-singapore](https://www.aljazeera.com/economy/2023/3/27/chinas-rich-flee-crackdowns-for-asias-switzerland-singapore)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 02:47:53+00:00

Chinese wealth is rushing into the Southeast Asian city-state, prompting unease among some locals.

## Mass protests in Israel after Netanyahu fires defence minister
 - [https://www.aljazeera.com/news/2023/3/27/mass-protests-in-israel-after-netanyahu-fires-defence-minister](https://www.aljazeera.com/news/2023/3/27/mass-protests-in-israel-after-netanyahu-fires-defence-minister)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 01:31:46+00:00

Protesters block highway in Tel Aviv as police scuffle with crowds in front of Netanyahu&#039;s home in Jerusalem.

## North Korea fires ballistic missiles after protesting US drills
 - [https://www.aljazeera.com/news/2023/3/27/north-korea-fires-ballistic-missiles-toward-sea-of-japan](https://www.aljazeera.com/news/2023/3/27/north-korea-fires-ballistic-missiles-toward-sea-of-japan)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-03-27 00:36:34+00:00

Pyongyang&#039;s latest missile launches come after claiming to have tested nuclear-capable underwater attack drone.

