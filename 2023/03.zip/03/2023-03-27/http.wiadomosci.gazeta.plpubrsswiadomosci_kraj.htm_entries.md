# Source:wiadomości.gazeta.pl, URL:http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm, language:pl-PL

## Rekolekcje w Polsce. "Wciąż dochodzi do absurdalnych sytuacji". Spowiedź w kantorku dla wuefistów
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29601773,rekolekcje-w-polsce-wciaz-dochodzi-do-absurdalnych-sytuacji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29601773,rekolekcje-w-polsce-wciaz-dochodzi-do-absurdalnych-sytuacji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-03-27 12:59:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/82/3a/1c/z29601666M,Rekolekcje-w-szkolnej-sali-gimnastycznej--zdjecie-.jpg" vspace="2" />- To, że rekolekcje odbywają się w czasie lekcji i zamiast lekcji, jest tylko polską specyfiką. W Europie nie ma tak, że uczniowie mogą nie być trzy dni w szkole tylko dlatego, że ich Kościół i związek wyznaniowy organizują w tym czasie msze. Takie rzeczy się nie dzieją i to też świadczy o tym, że jesteśmy trochę państwem wyznaniowym - mówi w rozmowie z radiozet.pl Dorota Wójcik z Fundacji Wolność od Religii.

## Matka udusiła czwórkę noworodków. Zwłoki wrzuciła do pieca. Sąd Najwyższy uchylił karę 25 lat więzienia
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29602527,sad-najwyzszy-uchylil-kare-25-lat-wiezienia-dla-matki-za-zabojstwo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29602527,sad-najwyzszy-uchylil-kare-25-lat-wiezienia-dla-matki-za-zabojstwo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-03-27 12:27:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f6/83/1b/z28852214M,Sad-Najwyzszy-w-Warszawie.jpg" vspace="2" />Sąd Najwyższy uchylił karę 25 lat pozbawienia wolności dla matki skazanej za zabójstwo czwórki noworodków. Sprawa została przekazana do ponownego rozpatrzenia przez Sąd Apelacyjny we Wrocławiu w zakresie dotyczącym tylko wymiaru kary. Wyrok sądu odwoławczego w zakresie sprawstwa nie został przez Sąd Najwyższy zmieniony.

## Czarnek o religii dla trzylatków w przedszkolach. "Prawo i Sprawiedliwość ma program ochrony religii"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29600685,czarnek-o-zmianach-w-systemie-edukacji-religii-dla-trzylatkow.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29600685,czarnek-o-zmianach-w-systemie-edukacji-religii-dla-trzylatkow.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-03-27 12:13:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/70/1f/1c/z29490288M.jpg" vspace="2" />Wcześniejsze emerytury dla nauczycieli i stały fundusz dla szkół specjalnych to tylko niektóre z planów resortu edukacji, jakie w niedzielę przedstawił Przemysław Czarnek na spotkaniu z mieszkańcami Lublina. Minister edukacji odniósł się też do pomysłu wprowadzenia zajęć religii dla trzylatków w przedszkolu oraz zapowiedział zmniejszenie liczby jednostek lekcyjnych w szkołach, a także zmianę ich charakteru.

## Policja rozwiązała sprawę morderstwa 17-letniego Fabiana Zydora. Zatrzymano trzech mężczyzn
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29602298,policja-rozwiazala-sprawe-morderstwa-fabiana-zydora-zatrzymano.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29602298,policja-rozwiazala-sprawe-morderstwa-fabiana-zydora-zatrzymano.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-03-27 12:10:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/68/3b/1c/z29602408M,Zatrzymano-podejrzanych-o-zabojstwo-Fabiana-Zydora.jpg" vspace="2" />Trzy osoby podejrzane o zabójstwo Fabiana Zydora zostały zatrzymane i tymczasowo aresztowane - informuje Andrzej Borowiak z KWP w Poznaniu. Materiał dowodowy zebrany przez policjantów i prokuratorów z Prokuratury Okręgowej w Poznaniu okazał się przełomowy. 17-letni Fabian w 2016 roku został zamordowany, a jego ciało ukryte.

## Błażej Kmieciak podał się do dymisji. Nie będzie już szefem Państwowej Komisji ds. Pedofilii
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29602394,blazej-kmieciak-podal-sie-do-dymisji-nie-bedzie-juz-szefem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29602394,blazej-kmieciak-podal-sie-do-dymisji-nie-bedzie-juz-szefem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-03-27 11:55:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/63/d4/1b/z29181539M,Blazej-Kmieciak---zdjecie-archiwalne.jpg" vspace="2" />Błażej Kmieciak poinformował, że złożył rezygnację ze stanowiska przewodniczącego Państwowej Komisji ds. Pedofilii. Funkcję tę będzie pełnił jeszcze do połowy kwietnia.

## Rosyjski szpieg zatrzymany w Polsce. Przyznał się i podał szczegóły. Grozi mu do 10 lat więzienia
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29601125,rosyjski-szpieg-w-polsce-przyznal-sie-i-podal-szczegoly-grozi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29601125,rosyjski-szpieg-w-polsce-przyznal-sie-i-podal-szczegoly-grozi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-03-27 08:16:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/1d/19/1c/z29463069M,Policja--Zatrzymany-w-kajdankach--Zdjecie-ilustrac.jpg" vspace="2" />Rzeczniczka prasowa Prokuratury Okręgowej w Gdańsku prok. Grażyna Wawryniuk poinformowała o zatrzymaniu mężczyzny podejrzanego o prowadzenie działalności szpiegowskiej na rzecz Rosji. Miał m.in. przekazywać Rosjanom informacje dotyczące infrastruktury krytycznej w województwach pomorskim i kujawsko-pomorskim. Cudzoziemiec przebywał w Polsce od stycznia. Został zatrzymany w miniony wtorek.

## Polacy zapytani o Jana Pawła II i pedofilię w Kościele. Wyborcy PiS i opozycji zgodni co do jednego
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29600708,afera-wokol-jana-pawla-ii-i-pedofilii-w-kosciele-to-element.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29600708,afera-wokol-jana-pawla-ii-i-pedofilii-w-kosciele-to-element.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-03-27 07:48:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/8e/2d/1c/z29546126M,Papiez-Jan-Pawel-II.jpg" vspace="2" />Ponad połowa Polaków uważa, że próba wyjaśnienia postawy Karola Wojtyły wobec problemu pedofilii wśród księży jest "element walki politycznej". Taka opinia przeważa zarówno wśród wyborców Zjednoczonej Prawicy, jak i sympatyków opozycji.

## Trzaskowski o "piątce konfederacji": Trzeba o niej przypominać
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29600321,trzaskowski-pis-stworzyl-glebe-dla-konfederacji-zapowiada.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29600321,trzaskowski-pis-stworzyl-glebe-dla-konfederacji-zapowiada.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-03-27 07:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/88/3a/1c/z29600392M,Rafal-Trzaskowski.jpg" vspace="2" />- To, co robi Konfederacja, współgra z tym, co robi PiS, jak niszczy nasze państwo. To PiS stworzył glebę dla tego typu poglądów i nadaje im walor legitymacji, a my się z tym nie zgadzamy - mówił w Porannej Rozmowie Gazeta.pl prezydent Warszawy Rafał Trzaskowski. Przekonywał, że o tzw. "piątce Konfederacji" trzeba przypominać, żeby ci, którzy "się na nią nabierają, wiedzieli z czym mają do czynienia".

## Pogoda. Nagły powrót zimy, nawet 25 cm śniegu. "Na kilka dni pożegnamy wiosnę"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29600557,pogoda-nagly-powrot-zimy-na-poczatku-tygodnia-nawet-25-cm.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29600557,pogoda-nagly-powrot-zimy-na-poczatku-tygodnia-nawet-25-cm.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-03-27 06:16:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/5b/3a/1c/z29600603M,Do-Polski-wraca-zima.jpg" vspace="2" />Od poniedziałku w Polsce ponownie zagości zima. Niż znad Bałtyku przyniesie zdecydowaną zmianę pogody. Nastąpi nagłe ochłodzenie, a w wielu miejscach pojawi się śnieg oraz deszcz ze śniegiem. Instytut Meteorologii i Gospodarki Wodnej wydał nowe ostrzeżenia meteorologiczne.

## Wypadek z udziałem trzech porsche na niemieckiej autostradzie. Czterech Holendrów nie żyje
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29600543,wypadek-z-udzialem-trzech-porsche-na-niemieckiej-autostradzie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29600543,wypadek-z-udzialem-trzech-porsche-na-niemieckiej-autostradzie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-03-27 06:02:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/3a/3a/1c/z29600570M,Trzy-porsche--cztery-ofiary--Koszmarny-wypadek-w-N.jpg" vspace="2" />Czterech Holendrów zginęło w niedzielę w tragicznym wypadku na autostradzie A3 w Niemczech - informują niemieckie media. W wypadku uczestniczyły trzy samochody porsche na holenderskich tablicach rejestracyjnych. Według policji kierowcy nie dostosowali prędkości do panujących na drodze trudnych warunków.

