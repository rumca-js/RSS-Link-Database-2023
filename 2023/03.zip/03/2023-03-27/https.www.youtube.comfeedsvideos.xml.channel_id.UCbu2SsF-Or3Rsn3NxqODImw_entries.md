# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Diablo 4 Necromancer Level 25 Dungeon Beta Gameplay
 - [https://www.youtube.com/watch?v=X65_goWC9YE](https://www.youtube.com/watch?v=X65_goWC9YE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2023-03-27 18:45:01+00:00

Check out a Necromancer at the beta level cap of 25 going through the Impalers Delve Dungeon in Diablo 4. The Necromancer is using Sever Skeletal Warriors, Bone Mages, and the Bone Golem for summons, while using blood skills including Blood Mist, Bloodsurge, Hemorrhage, and the ultimate skill Blood Wave.

We have the legendary effect where Blood Mist triggers corpse explosions on surrounding corpses. While also having the legendary effect where the movement speed decrease is removed which makes Blood Mist a very strong skill.

#diablo4 #necromancer #gaming

