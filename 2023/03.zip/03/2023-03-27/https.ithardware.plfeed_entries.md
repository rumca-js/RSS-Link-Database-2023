# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## Podsumowanie newsów ITHardware - tydzień 98. Sprawdź co Cię ominęło
 - [https://ithardware.pl/aktualnosci/newsy_podsumowanie_tydzien_dziewiecdziesiaty_osmy_marzec_2023-26530.html](https://ithardware.pl/aktualnosci/newsy_podsumowanie_tydzien_dziewiecdziesiaty_osmy_marzec_2023-26530.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-27 21:52:12+00:00

<img src="https://ithardware.pl/artykuly/min/26530_1.jpg" />            Jak co tydzień zapraszamy naszych czytelnik&oacute;w do odwiedzenia kanału&nbsp;ITHardware na YouTube i do zapoznania się z materiałem prezentującym najważniejsze wydarzenia minionych 7 dni.

Za powstanie wideo odpowiada&nbsp;nasz redakcyjny...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/newsy_podsumowanie_tydzien_dziewiecdziesiaty_osmy_marzec_2023-26530.html">https://ithardware.pl/aktualnosci/newsy_podsumowanie_tydzien_dziewiecdziesiaty_osmy_marzec_2023-26530.html</a></p>

## OnePlus i Oppo wycofają się z Polskiego rynku? Firmy wydały oświadczenia
 - [https://ithardware.pl/aktualnosci/oneplus_i_oppo_wycofaja_sie_z_polskiego_rynku_firmy_wydaly_oswiadczenia-26529.html](https://ithardware.pl/aktualnosci/oneplus_i_oppo_wycofaja_sie_z_polskiego_rynku_firmy_wydaly_oswiadczenia-26529.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-27 20:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/26529_1.jpg" />            Dziś pojawiła się informacja jakoby Oppo i OnePlus wycofały się częściowo z Europy, aczkolwiek do medialnych doniesień szybko odniosły się polskie oddziały firm, kt&oacute;re wystosowały oficjalne oświadczenia.

Oppo oraz OnePlus nie mają...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/oneplus_i_oppo_wycofaja_sie_z_polskiego_rynku_firmy_wydaly_oswiadczenia-26529.html">https://ithardware.pl/aktualnosci/oneplus_i_oppo_wycofaja_sie_z_polskiego_rynku_firmy_wydaly_oswiadczenia-26529.html</a></p>

## Kingston FURY poszerza gamę produktów pamięci RAM DDR5
 - [https://ithardware.pl/aktualnosci/kingston_fury_poszerza_game_produktow_pamieci_ram_ddr5-26528.html](https://ithardware.pl/aktualnosci/kingston_fury_poszerza_game_produktow_pamieci_ram_ddr5-26528.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-27 18:21:54+00:00

<img src="https://ithardware.pl/artykuly/min/26528_1.jpg" />            Kingston ogłosił&nbsp;dodanie białych radiator&oacute;w do swojej&nbsp;linii moduł&oacute;w pamięci Kingston FURY DDR5. Zapewni to więcej opcji dla tych, kt&oacute;rzy chcą budować wyr&oacute;żniające się zestawy komputerowe.

Kingston FURY...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/kingston_fury_poszerza_game_produktow_pamieci_ram_ddr5-26528.html">https://ithardware.pl/aktualnosci/kingston_fury_poszerza_game_produktow_pamieci_ram_ddr5-26528.html</a></p>

## TP-Link prezentuje nowy router Wi-Fi 6 Archer AX95
 - [https://ithardware.pl/aktualnosci/tp_link_prezentuje_nowy_router_wi_fi_6_archer_ax95-26527.html](https://ithardware.pl/aktualnosci/tp_link_prezentuje_nowy_router_wi_fi_6_archer_ax95-26527.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-27 16:40:00+00:00

<img src="https://ithardware.pl/artykuly/min/26527_1.jpg" />            TP-Link prezentuje nowy router&nbsp;Archer AX95 działający w technologii Wi-Fi 6. Urządzenie znajdzie zastosowanie zar&oacute;wno w domu, jak i mniejszym biurze. Oto, czego możemy oczekiwać po propozycji producenta.

TP-Link&nbsp;Archer AX95 to...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/tp_link_prezentuje_nowy_router_wi_fi_6_archer_ax95-26527.html">https://ithardware.pl/aktualnosci/tp_link_prezentuje_nowy_router_wi_fi_6_archer_ax95-26527.html</a></p>

## Dmitrij Miedwiediew chce zniszczyć Netflixa. Apeluje do Rosjan, by wrzucali do sieci co tylko się da
 - [https://ithardware.pl/aktualnosci/dmitrij_miedwiediew_chce_zniszczyc_netflixa_apeluje_do_rosjan_by_wrzucali_do_sieci_co_tylko_sie_da-26526.html](https://ithardware.pl/aktualnosci/dmitrij_miedwiediew_chce_zniszczyc_netflixa_apeluje_do_rosjan_by_wrzucali_do_sieci_co_tylko_sie_da-26526.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-27 15:48:27+00:00

<img src="https://ithardware.pl/artykuly/min/26526_1.jpg" />            Z Rosji po wybuchu pełnoskalowej wojny w Ukrainie wycofało się dużo przedsiębiorstw r&oacute;wnież przedstawicieli branży technologicznej. Netflix ostatecznie zrezygnował z rosyjskiego rynku w maju 2022 r., co nie pozostało bez uwagi władz tego...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/dmitrij_miedwiediew_chce_zniszczyc_netflixa_apeluje_do_rosjan_by_wrzucali_do_sieci_co_tylko_sie_da-26526.html">https://ithardware.pl/aktualnosci/dmitrij_miedwiediew_chce_zniszczyc_netflixa_apeluje_do_rosjan_by_wrzucali_do_sieci_co_tylko_sie_da-26526.html</a></p>

## God of War: Ragnarok otrzyma kontynuację? Aktor głosowy się wygadał
 - [https://ithardware.pl/aktualnosci/god_of_war_ragnarok_otrzyma_kontynuacje_aktor_glosowy_sie_wygadal-26525.html](https://ithardware.pl/aktualnosci/god_of_war_ragnarok_otrzyma_kontynuacje_aktor_glosowy_sie_wygadal-26525.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-27 14:40:00+00:00

<img src="https://ithardware.pl/artykuly/min/26525_1.jpg" />            God of War: Ragnarok odni&oacute;sł duży sukces i domknął historię rozpoczętą w poprzedniej części. Jak się okazuje Kratos może powr&oacute;cić w kontynuacji, o czym poinformował aktor głosowy wcielający się w jedną z postaci...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/god_of_war_ragnarok_otrzyma_kontynuacje_aktor_glosowy_sie_wygadal-26525.html">https://ithardware.pl/aktualnosci/god_of_war_ragnarok_otrzyma_kontynuacje_aktor_glosowy_sie_wygadal-26525.html</a></p>

## Counter-Strike: Global Offensive z kolejnym rekordem graczy. Pomogła beta CS2?
 - [https://ithardware.pl/aktualnosci/counter_strike_global_offensive_z_kolejnym_rekordem_graczy_pomogla_beta_cs2-26524.html](https://ithardware.pl/aktualnosci/counter_strike_global_offensive_z_kolejnym_rekordem_graczy_pomogla_beta_cs2-26524.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-27 13:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/26524_1.jpg" />            Counter-Strike: Global Offensive nie zatrzymuje się i bije w marcu kolejny rekord. Do ogromnego zainteresowania strzelanką Valve przyczyniła się beta CS2, bowiem by uzyskać do niej dostęp trzeba mieć na koncie Steam CS:GO.

CS:GO przez większą...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/counter_strike_global_offensive_z_kolejnym_rekordem_graczy_pomogla_beta_cs2-26524.html">https://ithardware.pl/aktualnosci/counter_strike_global_offensive_z_kolejnym_rekordem_graczy_pomogla_beta_cs2-26524.html</a></p>

## AMD ujawnia szczegóły FSR 3.0 - dwukrotny wzrost wydajności
 - [https://ithardware.pl/aktualnosci/amd_ujawnia_szczegoly_fsr_3_0_dwukrotny_wzrost_wydajnosci-26521.html](https://ithardware.pl/aktualnosci/amd_ujawnia_szczegoly_fsr_3_0_dwukrotny_wzrost_wydajnosci-26521.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-27 12:34:01+00:00

<img src="https://ithardware.pl/artykuly/min/26521_1.jpg" />            Pod koniec zeszłego roku AMD ogłosiło nową wersję swojego rozwiązania upscalingu FidelityFX Super Resolution. Czerwoni wr&oacute;cili do tematu na Game Developer Conference, ujawniając więcej szczeg&oacute;ł&oacute;w na temat korzyści,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/amd_ujawnia_szczegoly_fsr_3_0_dwukrotny_wzrost_wydajnosci-26521.html">https://ithardware.pl/aktualnosci/amd_ujawnia_szczegoly_fsr_3_0_dwukrotny_wzrost_wydajnosci-26521.html</a></p>

## Pójdzie mi na tym Windows 12? Czyli przecieki odnośnie wymagań nowego OS
 - [https://ithardware.pl/aktualnosci/pojdzie_mi_na_tym_windows_12_czyli_przecieki_odnosnie_wymagan_nowego_os-26520.html](https://ithardware.pl/aktualnosci/pojdzie_mi_na_tym_windows_12_czyli_przecieki_odnosnie_wymagan_nowego_os-26520.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-27 11:14:01+00:00

<img src="https://ithardware.pl/artykuly/min/26520_1.jpg" />            Chociaż wciąż możemy liczyć na kilka dużych aktualizacji Windowsa 11 (Moment 3 i Moment 4), Microsoft już pracuje w pocie czoła nad kolejną generacją swojego OS, kt&oacute;ry nieoficjalnie nosi nazwę Windows 12 nowej generacji, co nie jest...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/pojdzie_mi_na_tym_windows_12_czyli_przecieki_odnosnie_wymagan_nowego_os-26520.html">https://ithardware.pl/aktualnosci/pojdzie_mi_na_tym_windows_12_czyli_przecieki_odnosnie_wymagan_nowego_os-26520.html</a></p>

## NVIDIA: Kryptowaluty nie wnoszą nic pożytecznego do społeczeństwa
 - [https://ithardware.pl/aktualnosci/nvidia_kryptowaluty_nie_wnosza_nic_pozytecznego_do_spoleczenstwa-26523.html](https://ithardware.pl/aktualnosci/nvidia_kryptowaluty_nie_wnosza_nic_pozytecznego_do_spoleczenstwa-26523.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-27 11:14:00+00:00

<img src="https://ithardware.pl/artykuly/min/26523_1.jpg" />            NVIDIA zarobiła ogromne pieniądze na szale kryptowalut, sprzedając niesamowite ilości kart graficznych g&oacute;rnikom cyfrowych token&oacute;w, jednak teraz, gdy sytuacja właściwie wr&oacute;ciła do normy, firma postanowiła szczerze powiedzieć,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nvidia_kryptowaluty_nie_wnosza_nic_pozytecznego_do_spoleczenstwa-26523.html">https://ithardware.pl/aktualnosci/nvidia_kryptowaluty_nie_wnosza_nic_pozytecznego_do_spoleczenstwa-26523.html</a></p>

## Nowa generacja GPU Intela ma podwoić liczbę rdzeni. Wiemy, jakiej wydajności można się spodziewać
 - [https://ithardware.pl/aktualnosci/nowa_generacja_gpu_intela_ma_podwoic_liczbe_rdzeni_wiemy_jakiej_wydajnosci_mozna_sie_spodziewac-26519.html](https://ithardware.pl/aktualnosci/nowa_generacja_gpu_intela_ma_podwoic_liczbe_rdzeni_wiemy_jakiej_wydajnosci_mozna_sie_spodziewac-26519.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-27 10:22:01+00:00

<img src="https://ithardware.pl/artykuly/min/26519_1.jpg" />            Choć Raja Koduri opuścił Intela, zdaje się, że dział graficzny firmy nie pr&oacute;żnuje i według RedGamingTech, następna generacja procesor&oacute;w graficznych Arc może podwoić liczbę rdzeni.

Przypominamy, że RedGamingTech ujawniło...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nowa_generacja_gpu_intela_ma_podwoic_liczbe_rdzeni_wiemy_jakiej_wydajnosci_mozna_sie_spodziewac-26519.html">https://ithardware.pl/aktualnosci/nowa_generacja_gpu_intela_ma_podwoic_liczbe_rdzeni_wiemy_jakiej_wydajnosci_mozna_sie_spodziewac-26519.html</a></p>

## Profil XMP w pamięci RAM nie działa? Rozwiązanie jest proste!
 - [https://ithardware.pl/poradniki/profil_xmp_w_pamieci_ram_nie_dziala_rozwiazanie_jest_proste-26485.html](https://ithardware.pl/poradniki/profil_xmp_w_pamieci_ram_nie_dziala_rozwiazanie_jest_proste-26485.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-27 10:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/26485_1.jpg" />            Rozwiązywanie problem&oacute;w z profilami XMP - poradnik

Składając nowy zestaw komputerowy, tudzież ulepszając posiadaną maszynę o nową pamięć RAM, oczekujemy że komponent ten będzie bez problem&oacute;w działał z parametrami ustalonymi...
            <p>Pełna wersja strony <a href="https://ithardware.pl/poradniki/profil_xmp_w_pamieci_ram_nie_dziala_rozwiazanie_jest_proste-26485.html">https://ithardware.pl/poradniki/profil_xmp_w_pamieci_ram_nie_dziala_rozwiazanie_jest_proste-26485.html</a></p>

## Wenezuela zamyka farmy kryptowalut i giełdy. System został opanowany przez korupcję
 - [https://ithardware.pl/aktualnosci/wenezuela_zamyka_farmy_kryptowalut_i_gieldy_system_zostal_opanowany_przez_korupcje-26522.html](https://ithardware.pl/aktualnosci/wenezuela_zamyka_farmy_kryptowalut_i_gieldy_system_zostal_opanowany_przez_korupcje-26522.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-27 09:53:00+00:00

<img src="https://ithardware.pl/artykuly/min/26522_1.jpg" />            Pięć lat temu Wenezuela widziała w kryptowalutach ratunek dla swojej sytuacji gospodarczej. Rząd&nbsp;stworzył nawet kryptowalutę Petro, kt&oacute;rą powiązano z ropą naftową, jednak wiele rzeczy nie poszło zgodnie z założeniami, a system...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/wenezuela_zamyka_farmy_kryptowalut_i_gieldy_system_zostal_opanowany_przez_korupcje-26522.html">https://ithardware.pl/aktualnosci/wenezuela_zamyka_farmy_kryptowalut_i_gieldy_system_zostal_opanowany_przez_korupcje-26522.html</a></p>

## Huawei opracował własny pakiet do projektowania chipów 14 nm. Chiny reagują na amerykańskie sankcje
 - [https://ithardware.pl/aktualnosci/huawei_opracowal_wlasny_pakiet_do_projektowania_chipow_14_nm_chiny_reaguja_na_amerykanskie_sankcje-26513.html](https://ithardware.pl/aktualnosci/huawei_opracowal_wlasny_pakiet_do_projektowania_chipow_14_nm_chiny_reaguja_na_amerykanskie_sankcje-26513.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-27 09:16:10+00:00

<img src="https://ithardware.pl/artykuly/min/26513_1.jpg" />            Według chińskich medi&oacute;w, Huawei zakończył prace nad platformą narzędzi do automatyzacji projektowania elektronicznego (EDA), kt&oacute;ra pozwala na tworzenie układ&oacute;w scalonych w procesie 14 nm.

Platforma ta została opracowana w...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/huawei_opracowal_wlasny_pakiet_do_projektowania_chipow_14_nm_chiny_reaguja_na_amerykanskie_sankcje-26513.html">https://ithardware.pl/aktualnosci/huawei_opracowal_wlasny_pakiet_do_projektowania_chipow_14_nm_chiny_reaguja_na_amerykanskie_sankcje-26513.html</a></p>

## Dokumenty AMD potwierdzają hybrydowe procesory Phoenix 2
 - [https://ithardware.pl/aktualnosci/dokumenty_amd_potwierdzaja_hybrydowe_procesory_phoenix_2-26518.html](https://ithardware.pl/aktualnosci/dokumenty_amd_potwierdzaja_hybrydowe_procesory_phoenix_2-26518.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-27 09:15:01+00:00

<img src="https://ithardware.pl/artykuly/min/26518_1.jpg" />            Jak wynika z przewodnika programowania procesor&oacute;w AMD odkrytego przez InstLatX64, nadchodzące procesory AMD o nazwie kodowej Phoenix 2 będą miały tak zwaną konstrukcję hybrydową zawierającą zar&oacute;wno wysokowydajne rdzenie Zen 4, jak...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/dokumenty_amd_potwierdzaja_hybrydowe_procesory_phoenix_2-26518.html">https://ithardware.pl/aktualnosci/dokumenty_amd_potwierdzaja_hybrydowe_procesory_phoenix_2-26518.html</a></p>

## Czym jest technologia informacyjna?
 - [https://ithardware.pl/artykuly/czym_jest_technologia_informacyjna-26397.html](https://ithardware.pl/artykuly/czym_jest_technologia_informacyjna-26397.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-27 09:10:00+00:00

<img src="https://ithardware.pl/artykuly/min/26397_1.jpg" />            Technologia informacyjna to jedna z najszybciej rozwijających się branż w dzisiejszym świecie. Stanowi ona sektor, kt&oacute;ry zajmuje się tworzeniem, przetwarzaniem, przechowywaniem i dystrybucją informacji. Bez niej wsp&oacute;łczesne...
            <p>Pełna wersja strony <a href="https://ithardware.pl/artykuly/czym_jest_technologia_informacyjna-26397.html">https://ithardware.pl/artykuly/czym_jest_technologia_informacyjna-26397.html</a></p>

## Unia Europejska ugina się pod presją Niemiec. Auta na e-paliwa będą sprzedawane po 2035 roku
 - [https://ithardware.pl/aktualnosci/unia_europejska_ugina_sie_pod_presja_niemiec_auta_na_e_paliwa_beda_sprzedawane_po_2035_roku-26516.html](https://ithardware.pl/aktualnosci/unia_europejska_ugina_sie_pod_presja_niemiec_auta_na_e_paliwa_beda_sprzedawane_po_2035_roku-26516.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-27 08:18:20+00:00

<img src="https://ithardware.pl/artykuly/min/26516_1.jpg" />            Unia Europejska zgodziła się na wyłączenie paliw syntetycznych w proponowanym od 2035 r. zakazie sprzedaży nowych samochod&oacute;w z silnikami spalinowymi.&nbsp;

Według Associated Press Unia zawarła w sobotę umowę z Niemcami, aby umożliwić...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/unia_europejska_ugina_sie_pod_presja_niemiec_auta_na_e_paliwa_beda_sprzedawane_po_2035_roku-26516.html">https://ithardware.pl/aktualnosci/unia_europejska_ugina_sie_pod_presja_niemiec_auta_na_e_paliwa_beda_sprzedawane_po_2035_roku-26516.html</a></p>

## Administracja Bidena żądała cenzury niepożądanych rozmów w WhatsApp
 - [https://ithardware.pl/aktualnosci/administracja_bidena_zadala_cenzury_niepozadanych_rozmow_na_whatsapp-26512.html](https://ithardware.pl/aktualnosci/administracja_bidena_zadala_cenzury_niepozadanych_rozmow_na_whatsapp-26512.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-27 07:53:00+00:00

<img src="https://ithardware.pl/artykuly/min/26512_1.jpg" />            Administracja Bidena została oskarżona o nacisk na cenzurę treści związanych z COVID na platformie komunikacyjnej WhatsApp, zgodnie z informacjami przekazywanymi między Białym Domem a właścicielem platformy - firmą Meta. To posunięcie...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/administracja_bidena_zadala_cenzury_niepozadanych_rozmow_na_whatsapp-26512.html">https://ithardware.pl/aktualnosci/administracja_bidena_zadala_cenzury_niepozadanych_rozmow_na_whatsapp-26512.html</a></p>

## Adobe wprowadza generatywną sztuczną inteligencję Firefly - konkurencję dla DALL-E i Midjourney
 - [https://ithardware.pl/aktualnosci/adobe_wprowadza_generatywna_sztuczna_inteligencje_firefly_konkurencje_dla_dall_e_lub_midjourney-26507.html](https://ithardware.pl/aktualnosci/adobe_wprowadza_generatywna_sztuczna_inteligencje_firefly_konkurencje_dla_dall_e_lub_midjourney-26507.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-27 07:28:20+00:00

<img src="https://ithardware.pl/artykuly/min/26507_1.jpg" />            Adobe to kolejna firma reklamująca swoją generatywną sztuczną inteligencję jako konkurencję dla system&oacute;w DALL-E lub Midjourney.&nbsp;Nazywa się Firefly i była szkolona między innymi ze zdjęć z&nbsp;banku zdjęć Adobe...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/adobe_wprowadza_generatywna_sztuczna_inteligencje_firefly_konkurencje_dla_dall_e_lub_midjourney-26507.html">https://ithardware.pl/aktualnosci/adobe_wprowadza_generatywna_sztuczna_inteligencje_firefly_konkurencje_dla_dall_e_lub_midjourney-26507.html</a></p>

## Chris Avellone - zarzuty w sprawie scenarzysty wycofane. Sprawa kończy się ugodą
 - [https://ithardware.pl/aktualnosci/chris_avellone_zarzuty_w_sprawie_scenarzysty_wycofane_sprawa_konczy_sie_ugoda-26517.html](https://ithardware.pl/aktualnosci/chris_avellone_zarzuty_w_sprawie_scenarzysty_wycofane_sprawa_konczy_sie_ugoda-26517.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-27 07:27:11+00:00

<img src="https://ithardware.pl/artykuly/min/26517_1.jpg" />            Blisko 3 lata temu pisaliśmy o sprawie Chrisa Avellone'a, czyli popularnego w branży gier scenarzysty, kt&oacute;ry został oskarżony o bycie drapieżnikiem seksualnym, napaści na tle seksualnym i molestowanie. Właśnie wycofano te zarzuty, a to...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/chris_avellone_zarzuty_w_sprawie_scenarzysty_wycofane_sprawa_konczy_sie_ugoda-26517.html">https://ithardware.pl/aktualnosci/chris_avellone_zarzuty_w_sprawie_scenarzysty_wycofane_sprawa_konczy_sie_ugoda-26517.html</a></p>

## Mercedes-Benz przetestował elektryczne ciężarówki eActros w mroźnej Finlandii w temperaturze -25°C
 - [https://ithardware.pl/aktualnosci/mercedes_benz_przetestowal_elektryczne_ciezarowki_eactros_w_mroznej_finlandii_w_temperaturze_25_c-26506.html](https://ithardware.pl/aktualnosci/mercedes_benz_przetestowal_elektryczne_ciezarowki_eactros_w_mroznej_finlandii_w_temperaturze_25_c-26506.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-27 07:18:50+00:00

<img src="https://ithardware.pl/artykuly/min/26506_1.jpg" />            Daimler Truck wysłał swoje ciągniki do mroźnej Finlandii, gdzie chciał por&oacute;wnać osiągi wariant&oacute;w diesla i elektrycznych, w tym nadchodzącego eActrosa LongHaul.&nbsp;Test wypadł dobrze dla samochod&oacute;w elektrycznych, choć nie...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/mercedes_benz_przetestowal_elektryczne_ciezarowki_eactros_w_mroznej_finlandii_w_temperaturze_25_c-26506.html">https://ithardware.pl/aktualnosci/mercedes_benz_przetestowal_elektryczne_ciezarowki_eactros_w_mroznej_finlandii_w_temperaturze_25_c-26506.html</a></p>

## Cześć kodu źródłowgo Twittera wyciekła do sieci. Elon Musk może mieć duży problem
 - [https://ithardware.pl/aktualnosci/czesc_kodu_zrodlowgo_twittera_wyciekla_do_sieci_elon_musk_moze_miec_duzy_problem-26514.html](https://ithardware.pl/aktualnosci/czesc_kodu_zrodlowgo_twittera_wyciekla_do_sieci_elon_musk_moze_miec_duzy_problem-26514.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-27 06:13:53+00:00

<img src="https://ithardware.pl/artykuly/min/26514_1.jpg" />            Twitter nie ma ostatnio szczęścia i wydaje się, że po tym jak stery tej globalnej platformy społecznościowej przejął Elon Musk, tylko boryka się on z kolejnymi kryzysami. Tym razem dokumenty sądowe ujawniają, że fragmenty kodu...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/czesc_kodu_zrodlowgo_twittera_wyciekla_do_sieci_elon_musk_moze_miec_duzy_problem-26514.html">https://ithardware.pl/aktualnosci/czesc_kodu_zrodlowgo_twittera_wyciekla_do_sieci_elon_musk_moze_miec_duzy_problem-26514.html</a></p>

## Wielka wyprzedaż w x-komie. Ceny sprzętów obniżone nawet o 61%
 - [https://ithardware.pl/aktualnosci/wielka_wyprzedaz_w_x_komie_ceny_sprzetow_obnizone_nawet_o_61-26515.html](https://ithardware.pl/aktualnosci/wielka_wyprzedaz_w_x_komie_ceny_sprzetow_obnizone_nawet_o_61-26515.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-03-27 06:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/26515_1.jpg" />            Nieważne, jakie sprzętu potrzebujesz, sprawdź promocje w x-komie, a prawdopodobnie znajdziesz tam to, czego szukasz. Podczas wielkiej, kwartalnej wyprzedaży ceny setek sprzęt&oacute;w zostały obniżone nawet o 61%. Opr&oacute;cz tego możesz...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/wielka_wyprzedaz_w_x_komie_ceny_sprzetow_obnizone_nawet_o_61-26515.html">https://ithardware.pl/aktualnosci/wielka_wyprzedaz_w_x_komie_ceny_sprzetow_obnizone_nawet_o_61-26515.html</a></p>

