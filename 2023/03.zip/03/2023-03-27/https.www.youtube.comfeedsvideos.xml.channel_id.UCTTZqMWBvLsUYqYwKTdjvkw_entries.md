# Source:Mateusz Chrobok, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw, language:pl-PL

## 👴 Bob Metcalfe uhonorowany
 - [https://www.youtube.com/watch?v=GKPoR8i3rv4](https://www.youtube.com/watch?v=GKPoR8i3rv4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw
 - date published: 2023-03-27 04:00:06+00:00

Kojarzycie Boba Metcalfe’a? To raczej żadne zaskoczenie, ale jest on autorem dość znanego prawa nazwanego od jego nazwiska Prawem Metcalfe’a. Zgodnie z nim wartość sieci telekomunikacyjnej jest wykładniczo proporcjonalna do liczby jej użytkowników.


Źródła:
https://news.mit.edu/2023/bob-metcalfe-wins-acm-turing-award-0322
https://bit.ly/2JSpaka

#ethernet #internet #metcalfe #standard

