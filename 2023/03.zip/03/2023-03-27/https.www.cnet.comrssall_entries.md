# Source:CNET, URL:https://www.cnet.com/rss/all/, language:en-US

## WatchOS 9.4: Here's What Is New for Apple Watch     - CNET
 - [https://www.cnet.com/tech/mobile/watchos-9-4-heres-what-is-new-for-apple-watch/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/watchos-9-4-heres-what-is-new-for-apple-watch/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-03-27 21:23:00+00:00

The update brings bug fixes and expands Cycle Tracking features to more countries.

## Fitbit Shuts Down Some Popular Social Features     - CNET
 - [https://www.cnet.com/tech/mobile/fitbit-shuts-down-some-popular-social-features/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/fitbit-shuts-down-some-popular-social-features/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-03-27 21:20:00+00:00

Challenges and Adventures, as well as Open Groups, have gotten the ax.

## Are Solar Panels Worth It in Idaho? What You Need to Know     - CNET
 - [https://www.cnet.com/how-to/httpswww-cnet-comhomeenergy-and-utilitiesidaho-solar-panels/#ftag=CADf328eec](https://www.cnet.com/how-to/httpswww-cnet-comhomeenergy-and-utilitiesidaho-solar-panels/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-03-27 21:00:10+00:00

Idaho gets plenty of sunlight making solar panels a potential solution to help offset your utility bill.

## The 4 Worst Spots You Could Put Your Alexa Speaker     - CNET
 - [https://www.cnet.com/how-to/the-4-worst-spots-you-could-put-your-alexa-speaker/#ftag=CADf328eec](https://www.cnet.com/how-to/the-4-worst-spots-you-could-put-your-alexa-speaker/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-03-27 20:34:40+00:00

It's best to avoid putting your Amazon Echo device in certain spots. Here's where it should go instead.

## iOS 16.4 Brings These New Emoji to Your iPhone     - CNET
 - [https://www.cnet.com/tech/services-and-software/ios-16-4-brings-these-new-emoji-to-your-iphone/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/ios-16-4-brings-these-new-emoji-to-your-iphone/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-03-27 20:30:10+00:00

The latest iOS update, and these emoji, can be downloaded now.

## How to Interpret Your Dreams, According to Sleep Experts     - CNET
 - [https://www.cnet.com/health/sleep/how-to-interpret-your-dreams-mean-according-to-experts/#ftag=CADf328eec](https://www.cnet.com/health/sleep/how-to-interpret-your-dreams-mean-according-to-experts/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-03-27 20:11:43+00:00

Everything you need to know about your dreams.

## 13 Hidden iOS 16 Features You Didn't Know Your iPhone Had     - CNET
 - [https://www.cnet.com/tech/services-and-software/13-hidden-ios-16-features-you-didnt-know-your-iphone-had/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/13-hidden-ios-16-features-you-didnt-know-your-iphone-had/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-03-27 20:05:02+00:00

You haven't unlocked your iPhone's full potential until you've tinkered with these lesser-known features and settings.

## Best Car Rental Companies in 2022     - CNET
 - [https://www.cnet.com/roadshow/news/best-car-rental-company-of-2022/#ftag=CADf328eec](https://www.cnet.com/roadshow/news/best-car-rental-company-of-2022/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-03-27 19:24:26+00:00

These are the best car rental companies based on price, customer satisfaction, service, rewards and more.

## iOS 16.4 Is Here. These New Features Just Landed on Your iPhone     - CNET
 - [https://www.cnet.com/tech/services-and-software/ios-16-4-is-here-these-new-features-just-landed-on-your-iphone/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/ios-16-4-is-here-these-new-features-just-landed-on-your-iphone/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-03-27 19:21:27+00:00

New emoji, voice isolation in cellular calls and more just hit your iPhone.

## Space Exploration Could Lower Home Energy Bills in Weird, Wonderful Ways     - CNET
 - [https://www.cnet.com/news/space-exploration-could-lower-home-energy-bills-in-weird-wonderful-ways/#ftag=CADf328eec](https://www.cnet.com/news/space-exploration-could-lower-home-energy-bills-in-weird-wonderful-ways/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-03-27 18:14:06+00:00

Get ready for a future where we can live in houses made from mushrooms and powered by our own poo.

## Disney Reportedly Begins First Round of Layoffs in Plan to Cut 7,000 Employees     - CNET
 - [https://www.cnet.com/tech/disney-reportedly-begins-first-round-of-layoffs-in-plan-to-cut-7000-employees/#ftag=CADf328eec](https://www.cnet.com/tech/disney-reportedly-begins-first-round-of-layoffs-in-plan-to-cut-7000-employees/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-03-27 18:08:00+00:00

Notices are being sent out this week.

## iOS 16.4 Is Out. How to Download the Latest iPhone Update     - CNET
 - [https://www.cnet.com/tech/mobile/ios-16-4-is-out-how-to-download-the-latest-iphone-update/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/ios-16-4-is-out-how-to-download-the-latest-iphone-update/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-03-27 18:06:00+00:00

Added features include new emoji, voice isolation for better cellular calls, Safari website notifications for the lock screen and more.

## Avoid Expensive Airfare: 3 Simple Tricks for Cheaper Plane Tickets     - CNET
 - [https://www.cnet.com/personal-finance/credit-cards/avoid-expensive-airfare-3-simple-tricks-for-cheaper-plane-tickets/#ftag=CADf328eec](https://www.cnet.com/personal-finance/credit-cards/avoid-expensive-airfare-3-simple-tricks-for-cheaper-plane-tickets/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-03-27 17:25:00+00:00

If you're planning a spring or summer vacation, try these air travel hacks to find cheaper fares.

## This Google Maps Feature Takes Your Street Back in Time     - CNET
 - [https://www.cnet.com/tech/services-and-software/this-google-maps-feature-takes-your-street-back-in-time/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/this-google-maps-feature-takes-your-street-back-in-time/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-03-27 16:15:07+00:00

Street View lets you take a look at your home and other places, as far back as 2007.

## Are Solar Panels Worth It in Oregon?     - CNET
 - [https://www.cnet.com/how-to/oregon-solar-panels/#ftag=CADf328eec](https://www.cnet.com/how-to/oregon-solar-panels/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-03-27 16:10:47+00:00

Oregon's notoriously rainy climate may not be the most suitable for solar panels, but you could still lower your energy bills with solar power.

## March Madness 2023: Fantastic Food Deals From Domino's, Little Caesars, Subway and More     - CNET
 - [https://www.cnet.com/deals/march-madness-2023-fantastic-food-deals-from-dominos-little-caesars-subway-and-more/#ftag=CADf328eec](https://www.cnet.com/deals/march-madness-2023-fantastic-food-deals-from-dominos-little-caesars-subway-and-more/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-03-27 16:00:02+00:00

Everyone's a winner with discounts and promotions from America's top eateries.

## Amazon Knocks Up to $180 Off Its Already-Affordable Fire TV 4-Series     - CNET
 - [https://www.cnet.com/deals/amazon-knocks-up-to-180-off-its-already-affordable-fire-tv-4-series/#ftag=CADf328eec](https://www.cnet.com/deals/amazon-knocks-up-to-180-off-its-already-affordable-fire-tv-4-series/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-03-27 15:42:15+00:00

These are some of our favorite budget TVs on the market, and right now you can snag one for as much as 38% off.

## Everything You Need to Know About the EV Tax Credit Before This Week's Big Changes     - CNET
 - [https://www.cnet.com/roadshow/news/ev-tax-credit-heres-what-you-need-to-know-before-changes/#ftag=CADf328eec](https://www.cnet.com/roadshow/news/ev-tax-credit-heres-what-you-need-to-know-before-changes/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-03-27 15:25:00+00:00

The tax break can be worth up to $7,500 for electric vehicle owners. But confusion remains about which cars are covered.

## You Can Now Bundle YouTube TV With Frontier Internet in One Bill     - CNET
 - [https://www.cnet.com/tech/services-and-software/you-can-now-bundle-youtube-tv-with-frontier-internet-in-one-bill/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/you-can-now-bundle-youtube-tv-with-frontier-internet-in-one-bill/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-03-27 15:04:00+00:00

Frontier subscribers can get up to $15 off for 12 months when signing up for YouTube TV.

## One Quick Flip of Your Light Switch Can Save a Considerable Amount of Money and Energy     - CNET
 - [https://www.cnet.com/how-to/one-quick-flip-of-your-light-switch-can-save-a-considerable-amount-of-money-and-energy/#ftag=CADf328eec](https://www.cnet.com/how-to/one-quick-flip-of-your-light-switch-can-save-a-considerable-amount-of-money-and-energy/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-03-27 14:30:02+00:00

It's true: Just turning off a few lights when you're not home can lead to substantial savings.

## Save Up to 33% on Worx Power Tools to Tackle All Your Spring Yard Work     - CNET
 - [https://www.cnet.com/deals/save-up-to-33-on-worx-power-tools-to-tackle-all-your-spring-yard-work/#ftag=CADf328eec](https://www.cnet.com/deals/save-up-to-33-on-worx-power-tools-to-tackle-all-your-spring-yard-work/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-03-27 14:09:31+00:00

Save up to $50 on leaf blowers, string trimmers, leaf mulchers and more right now at Amazon.

## Machine-Wash Your Sheets and Bedding the Right Way With These 5 Simple Steps     - CNET
 - [https://www.cnet.com/health/sleep/machine-wash-your-sheets-and-bedding-the-right-way-with-these-5-simple-steps/#ftag=CADf328eec](https://www.cnet.com/health/sleep/machine-wash-your-sheets-and-bedding-the-right-way-with-these-5-simple-steps/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-03-27 14:00:06+00:00

Your bed sheets collect all sorts of grim and dirt. That means cleaning your sheets regularly is critical.

## Inside the Fan-Powered Push for a Bigger Extended Edition of Lord of the Rings     - CNET
 - [https://www.cnet.com/culture/entertainment/inside-the-fan-powered-push-for-a-bigger-extended-edition-of-lord-of-the-rings/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/inside-the-fan-powered-push-for-a-bigger-extended-edition-of-lord-of-the-rings/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-03-27 14:00:02+00:00

Commentary: It's a golden age for Tolkien fans, and they're going to make the most of it by asking for something big.

## Don't Feel Obligated to Pay Over $100 on Streaming TV. Try This Instead     - CNET
 - [https://www.cnet.com/tech/services-and-software/dont-feel-obligated-to-pay-over-100-streaming-tv-try-this/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/dont-feel-obligated-to-pay-over-100-streaming-tv-try-this/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-03-27 13:58:00+00:00

Tighten up your monthly subscription budget for Netflix, HBO Max and your other favorite platforms.

## Apple Demos AR/VR Headset to Top Executives, Report Says     - CNET
 - [https://www.cnet.com/tech/computing/apple-demos-arvr-headset-to-top-executives-report-says/#ftag=CADf328eec](https://www.cnet.com/tech/computing/apple-demos-arvr-headset-to-top-executives-report-says/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-03-27 13:54:29+00:00

The device might be unveiled to the public soon, according to Bloomberg.

## Microsoft Office Deal: Treat Your PC to a License for Just $40 Right Now     - CNET
 - [https://www.cnet.com/deals/microsoft-office-license-discounted-to-40/#ftag=CADf328eec](https://www.cnet.com/deals/microsoft-office-license-discounted-to-40/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-03-27 13:29:04+00:00

It's a one-time buy instead of a monthly expense, but it's only available at this price for a limited time.

## Sonos Era 100 Review: The Best Smart Speaker Gets Even Better     - CNET
 - [https://www.cnet.com/tech/home-entertainment/sonos-era-100-review-the-best-smart-speaker-gets-even-better/#ftag=CADf328eec](https://www.cnet.com/tech/home-entertainment/sonos-era-100-review-the-best-smart-speaker-gets-even-better/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-03-27 13:00:07+00:00

The Sonos Era 100 offers excellent sonics, refined design and one of the best streaming platforms for any speaker.

## Shame Is Sabotaging Your Happiness. Here's How to Stop It     - CNET
 - [https://www.cnet.com/health/mental/shame-is-sabotaging-your-happiness-heres-how-to-stop-it/#ftag=CADf328eec](https://www.cnet.com/health/mental/shame-is-sabotaging-your-happiness-heres-how-to-stop-it/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-03-27 13:00:03+00:00

Shame can increase stress and anxiety levels. Here's how to take control.

## Here Are Today's Mortgage Rates on March 27, 2023: Rates Recede     - CNET
 - [https://www.cnet.com/personal-finance/mortgages/here-are-todays-mortgage-rates-on-march-27-2023-rates-recede/#ftag=CADf328eec](https://www.cnet.com/personal-finance/mortgages/here-are-todays-mortgage-rates-on-march-27-2023-rates-recede/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-03-27 13:00:00+00:00

This last week, a couple of notable mortgage rates slid lower, though rates remain high compared to a year ago. The Fed's interest rate hikes are increasing costs for prospective homebuyers.

## Mortgage Refinance Rates for March 27, 2023: Rates Drop Off     - CNET
 - [https://www.cnet.com/personal-finance/mortgages/mortgage-refinance-rates-for-march-27-2023-rates-drop-off/#ftag=CADf328eec](https://www.cnet.com/personal-finance/mortgages/mortgage-refinance-rates-for-march-27-2023-rates-drop-off/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-03-27 13:00:00+00:00

Multiple key refinance rates were down this last week. The Fed's interest rate hikes have affected the refinance market.

## These Are the 3 Worst Spots to Install a Home Security Camera     - CNET
 - [https://www.cnet.com/how-to/these-are-the-3-worst-spots-to-install-a-home-security-camera/#ftag=CADf328eec](https://www.cnet.com/how-to/these-are-the-3-worst-spots-to-install-a-home-security-camera/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-03-27 12:00:02+00:00

Don't end up creating a privacy issue. Here's where you shouldn't put up security cameras around your property.

## Best Phones Under $300: 5G Phones at Starter Prices     - CNET
 - [https://www.cnet.com/tech/mobile/best-phones-under-300/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/best-phones-under-300/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-03-27 10:00:03+00:00

These phones prioritize essential features while providing a few productivity perks.

