# Source:The Intercept, URL:https://theintercept.com/feed/?lang=en, language:en-US

## Biden Is Fulfilling Trump’s Cruel Policy on Wild Horses
 - [https://theintercept.com/2023/03/27/wild-horses-burros-path-forward/](https://theintercept.com/2023/03/27/wild-horses-burros-path-forward/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2023-03-27 13:00:17+00:00

<p>The record-breaking roundups of iconic Western mustangs are a gift to ranching and mining interests.</p>
<p>The post <a href="https://theintercept.com/2023/03/27/wild-horses-burros-path-forward/" rel="nofollow">Biden Is Fulfilling Trump’s Cruel Policy on Wild Horses</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>

## Anti-Palestinian Hate on Social Media Is Growing, Says a Facebook Partner
 - [https://theintercept.com/2023/03/27/anti-palestinian-hate-social-media/](https://theintercept.com/2023/03/27/anti-palestinian-hate-social-media/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2023-03-27 09:00:18+00:00

<p>Violent and racist anti-Palestinian rhetoric grew more prevalent across social media platforms last year, according to a new report published by 7amleh, an organization that partners with Meta, the parent company of Instagram and Facebook. Hateful anti-Palestinian remarks grew by 10 percent in 2022, compared to the prior year, according to the new report, based<a class="ti-read-more-link" href="https://theintercept.com/2023/03/27/anti-palestinian-hate-social-media/">&#62;&#62;</a></p>
<p>The post <a href="https://theintercept.com/2023/03/27/anti-palestinian-hate-social-media/" rel="nofollow">Anti-Palestinian Hate on Social Media Is Growing, Says a Facebook Partner</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>

