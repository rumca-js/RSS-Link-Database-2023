# Source:Forsal.pl, URL:https://forsal.pl/.feed, language:pl-PL

## Biden wezwał Kongres do wprowadzenia zakazu sprzedaży karabinów szturmowych
 - [https://forsal.pl/swiat/usa/artykuly/8689537,biden-wezwal-kongres-do-wprowadzenia-zakazu-sprzedazy-karabinow-szturmowych.html](https://forsal.pl/swiat/usa/artykuly/8689537,biden-wezwal-kongres-do-wprowadzenia-zakazu-sprzedazy-karabinow-szturmowych.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 20:33:25+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/-FVktkuTURBXy80YjJjNmViNy0yNWIzLTQ1NWItYWI0Ni0yNDFlMTk3ODc0NGEuanBlZ5GTBc0BHcyg" />Prezydent USA Joe Biden wezwał w poniedziałek Kongres do wprowadzenia zakazu sprzedaży karabinów szturmowych po masakrze w szkole podstawowej w Nashville w stanie Tennessee. Jak dodał, trzeba zrobić wszystko, by chronić szkoły i by nie stały się one &quot;więzieniami&quot;.

## Strona internetowa francuskiego parlamentu zhakowana przez rosyjską grupę hakerów NoName
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8689361,strona-internetowa-francuskiego-parlamentu-zhakowana-prorosyjscy-hakerzy.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8689361,strona-internetowa-francuskiego-parlamentu-zhakowana-prorosyjscy-hakerzy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 19:00:23+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/YNzktkuTURBXy8wYmE3MTUwNi1iOTc5LTRhYjctYjJhOS0wYTdmYmFlYWRkYmQuanBlZ5GTBc0BHcyg" />Strony internetowe francuskiego Zgromadzenia Narodowego i Senatu zostały w poniedziałek zaatakowane przez prorosyjskich hakerów w odwecie za wsparcie Francji dla odpierającej inwazję Rosji Ukrainy.

## Przydacz: Zapowiedź rozmieszczenia rosyjskiej broni atomowej na Białorusi to propaganda. Musimy podchodzić do niej spokojnie
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8689359,przydacz-rozmieszczenie-broni-atomowej-na-bialorusi-to-propaganda.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8689359,przydacz-rozmieszczenie-broni-atomowej-na-bialorusi-to-propaganda.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 18:50:44+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ZXYktkuTURBXy81M2Y4YzE1Ni02NDA3LTQxMzItOWUzYS0yZjg1Yzc1MTFjMTguanBlZ5GTBc0BHcyg" />Nie możemy tego typu informacji lekceważyć, ale musimy do tego podchodzić spokojnie i nie ulegać strategii rosyjskiej propagandy - powiedział szef prezydenckiego BPM Marcin Przydacz o zapowiedzi rozmieszczenia na Białorusi taktycznej broni jądrowej przez Rosję. Jesteśmy bezpieczni pod parasolem NATO - dodał.

## Pegasus i inne komercyjne programy szpiegowskie na cenzurowanym. Biden zakazał ich używania
 - [https://forsal.pl/swiat/usa/artykuly/8689355,usa-pegasus-programy-szpiegowskie-zakazane-przez-bidena.html](https://forsal.pl/swiat/usa/artykuly/8689355,usa-pegasus-programy-szpiegowskie-zakazane-przez-bidena.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 18:32:53+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/TLiktkuTURBXy8zNjBkNjI2YS0wYjQ4LTQyYjctYmRiZi00MjZkNzFhMDRhZDguanBlZ5GTBc0BHcyg" />Prezydent Biden podpisał w poniedziałek rozporządzenie wykonawcze zakazujące instytucjom rządowym używania komercyjnego oprogramowania szpiegowskiego (spyware) takiego jak m.in. Pegasus. Według Białego Domu ewentualne używanie takich programów stanowiłoby ryzyko dla bezpieczeństwa narodowego.

## Netanjahu zawiesił prace nad reformą sądownictwa
 - [https://forsal.pl/gospodarka/prawo/artykuly/8689346,netanjahu-zawiesil-prace-nad-reforma-sadownictwa.html](https://forsal.pl/gospodarka/prawo/artykuly/8689346,netanjahu-zawiesil-prace-nad-reforma-sadownictwa.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 17:33:19+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/0RpktkuTURBXy85NWUyOTgwOS04ODVkLTRmM2UtYTU0MC00Njk1NmI3ZjZjMDguanBlZ5GTBc0BHcyg" />Premier Izraela Benjamin Netanjahu odroczy pracę nad projektem kontrowersyjnej ustawy o reformie sądownictwa do przyszłego miesiąca - poinformowała koalicyjna partia Żydowska Siła, którą cytuje agencja Reutera. Plan reformy wywołał masowe demonstracje i strajki w Izraelu.

## „FT”: Orban sprzeciwia się umowie regulującej imigrację. Wszystko z powodu zapisów o równości płci
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8689345,ft-orban-przeciw-umowie-regulujacej-imigracje-zapisy-o-rownosci-plci.html](https://forsal.pl/swiat/unia-europejska/artykuly/8689345,ft-orban-przeciw-umowie-regulujacej-imigracje-zapisy-o-rownosci-plci.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 17:29:01+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/KbJktkuTURBXy8zYjFhNmQzZC05ZTI5LTQxY2UtODIyNy1hYjZkYTA5MDM0YmEuanBlZ5GTBc0BHcyg" />Premier Węgier Viktor Orban sprzeciwił się nowej umowie Unii Europejskiej z państwami Afryki, Karaibów i Pacyfiku (AKP), ponieważ są w niej zapisy o perspektywie i równości płci - poinformował w poniedziałek brytyjski dziennik „Financial Times”.

## Węgierski parlament zgodził się na przyjęcie Finlandii do NATO
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8689336,wegierski-parlament-zgodzil-sie-na-przyjecie-finlandii-do-nato.html](https://forsal.pl/swiat/unia-europejska/artykuly/8689336,wegierski-parlament-zgodzil-sie-na-przyjecie-finlandii-do-nato.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 16:37:23+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/HG4ktkuTURBXy81YmJmMzBkYy1jODMwLTRjNTMtODNlZS1jMjMxM2IzZjhhMzcuanBlZ5GTBc0BHcyg" />Parlament Węgier poparł w poniedziałek wniosek Finlandii o przystąpienie do NATO. W głosowaniu akcesję Finlandii do Sojuszu Północnoatlantyckiego poparło 182 posłów, sześciu było przeciw, nikt nie wstrzymał się od głosu.

## Rzeczkowska: Polskie banki są silne. Przygotowują się na decyzję TUSE w sprawie kredytów frankowych
 - [https://forsal.pl/biznes/bankowosc/artykuly/8689331,rzeczkowska-polskie-banki-sa-silne-czekaja-na-decyzje-tuse-o-kredytach-chf.html](https://forsal.pl/biznes/bankowosc/artykuly/8689331,rzeczkowska-polskie-banki-sa-silne-czekaja-na-decyzje-tuse-o-kredytach-chf.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 16:29:20+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/uwNktkuTURBXy8zOTA4MjMwNy0zMGVmLTQzMjktYjJlNS0wMzdmNzk4NmRmZWMuanBlZ5GTBc0BHcyg" />undefined

## Rosjanie manipulują poziomem wody na Dnieprze. Czy latem zabraknie wody do chłodzenia reaktorów w ZEA?
 - [https://forsal.pl/biznes/energetyka/artykuly/8689321,rosjanie-manipuluja-poziomem-wody-na-dnieprze-zagrozenie-dla-zea.html](https://forsal.pl/biznes/energetyka/artykuly/8689321,rosjanie-manipuluja-poziomem-wody-na-dnieprze-zagrozenie-dla-zea.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 15:38:32+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/jh6ktkuTURBXy82Y2I4ZDFiYi03OGI1LTQyM2EtOGUxZS05YjY1NzE1MDk4ZjYuanBlZ5GTBc0BHcyg" />Dnieprzańska Elektrownia Wodna jest kluczową częścią systemu, który zapewnia bezpieczeństwo Zaporoskiej Elektrowni Atomowej; spotkałem się z prezydentem Ukrainy Wołodymyrem Zełenskim, który pokazał mi ostatnie zniszczenia tamy - poinformował w poniedziałek szef Międzynarodowej Agencji Energii Atomowej (MAEA) Rafael Grossi, który przebywa na Ukrainie.

## Urlop rodzicielski po japońsku. Młodzi ojcowie nie korzystają z niego, bo boją się reakcji pracodawcy
 - [https://forsal.pl/praca/kariera/artykuly/8689314,urlop-rodzicielski-po-japonsku-mlodzi-ojcowie-obawiaja-sie-pracodawcy.html](https://forsal.pl/praca/kariera/artykuly/8689314,urlop-rodzicielski-po-japonsku-mlodzi-ojcowie-obawiaja-sie-pracodawcy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 15:16:33+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Sl9ktkuTURBXy9jNDIwMTMxYy0wMTc4LTRjOTQtYTRiNi0yNGJhNTczZGJiNjkuanBlZ5GTBc0BHcyg" />Młodzi japońscy ojcowie boją się reakcji pracodawców i nie występują o urlopy rodzicielskie, podaje w poniedziałek CNN, przypominając, iż w ubiegłym roku liczba urodzeń spadła po raz pierwszy od XIX wieku poniżej 800 tysięcy.

## Dlaczego Putin chce rozmieścić broń nuklearną na Białorusi? Oto trzy powody
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8689311,dlaczego-putin-chce-rozmiescic-bron-nuklearna-na-bialorusi-trzy-powody.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8689311,dlaczego-putin-chce-rozmiescic-bron-nuklearna-na-bialorusi-trzy-powody.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 15:05:39+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Np_ktkuTURBXy9kNzY3ZWI2YS1mOWVhLTRjZTUtYTc3YS0wYzUxYmJhZjBmNDkuanBlZ5GTBc0BHcyg" />Władimir Putin zapowiedział rozmieszczenie rosyjskiej taktycznej broni jądrowej na Białorusi; są trzy powody, dla których chce to zrobić - uważa profesor stosunków międzynarodowych w Hertie School Marina Henke, która jest też szefową Centrum Bezpieczeństwa Międzynarodowego.

## DZIEŃ NA FX/FI: EUR/PLN czeka na nowe impulsy. Rentowność SPW może wzrosnąć powyżej 6,5 proc.
 - [https://forsal.pl/finanse/waluty/artykuly/8689308,eurpln-czeka-na-nowe-impulsy-rentownosc-spw-moze-wzrosnac-powyzej-65-proc.html](https://forsal.pl/finanse/waluty/artykuly/8689308,eurpln-czeka-na-nowe-impulsy-rentownosc-spw-moze-wzrosnac-powyzej-65-proc.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 14:52:50+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/KVJktkuTURBXy9hZTY0YTU2Yi0wZGJiLTQ5ZmEtYTE4Yi1iNzQ2Y2IxY2I3NGUuanBlZ5GTBc0BHcyg" />Lokalne przepływy stabilizują kurs EUR/PLN, a rynek czeka na silniejsze impulsy, które mogłyby wyrwać go z trendu bocznego - ocenia Mirosław Budzicki z PKO BP. Jego zdaniem, w otoczeniu możliwego spadku rynkowych wycen agresywnych obniżek stóp procentowych, rentowności SPW mogą wzrosnąć powyżej 6,5 proc.

## Minister Moskwa: Do zablokowania rozporządzenia metanowego potrzebne głosy polskich europarlamentarzystów
 - [https://forsal.pl/biznes/energetyka/artykuly/8689302,minister-moskwa-zablokowanie-rozporzadzenia-metanowego-glosy-europarlamentarzystow.html](https://forsal.pl/biznes/energetyka/artykuly/8689302,minister-moskwa-zablokowanie-rozporzadzenia-metanowego-glosy-europarlamentarzystow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 14:41:24+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/c0FktkuTURBXy9lMzE2N2U1ZS0zMDkxLTQ2MDgtODlhMi1hNGNlMWM3YTc0NDcuanBlZ5GTBc0BHcyg" />Żeby zablokować rozporządzenie metanowe Parlamentu Europejskiego i Rady, które dotknęłoby polskie kopalnie węgla kamiennego, potrzebne jest solidarne głosowanie wszystkich polskich europarlamentarzystów - powiedziała w poniedziałek minister klimatu i środowiska Anna Moskwa w na terenie kopalni węgla kamiennego w Bogdance (Lubelskie).

## Czeskie media polecają zakupy w Polsce. Mamy najniższe ceny wśród czeskich sąsiadów
 - [https://forsal.pl/biznes/handel/artykuly/8689299,czeskie-media-polecaja-zakupy-w-polsce-najnizsze-ceny-wsrod-sasiadow.html](https://forsal.pl/biznes/handel/artykuly/8689299,czeskie-media-polecaja-zakupy-w-polsce-najnizsze-ceny-wsrod-sasiadow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 14:11:55+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/E-YktkuTURBXy8zMWVjNjU1OS00YTZkLTRlYjEtYjIzNC1hYWM3ZjZiNzg3M2MuanBlZ5GTBc0BHcyg" />Czeski portal internetowy Seznam Zpravy zwrócił w poniedziałek uwagę, że dla Czechów Polska jest najtańszym z sąsiednich państw. Tak wynika z porównania cen podstawowych produktów w przygranicznych sklepach.

## Symulator samolotu Boeing 737 MAX powstaje na PW. To pierwsze takie urządzenie na polskiej uczelni
 - [https://forsal.pl/transport/lotnictwo/artykuly/8689294,pw-boeing-tworza-pierwszy-na-polskiej-uczelni-cywilny-symulator-lotow.html](https://forsal.pl/transport/lotnictwo/artykuly/8689294,pw-boeing-tworza-pierwszy-na-polskiej-uczelni-cywilny-symulator-lotow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 14:00:57+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/CR-ktkuTURBXy80ZDM3NGMxNi1jYzk4LTRkMjAtOTRkOS03MmEyM2E0YTMwMzYuanBlZ5GTBc0BHcyg" />Na Wydziale Mechanicznym Energetyki i Lotnictwa Politechniki Warszawskiej powstaje symulator samolotu Boeing 737 MAX. Będzie to pierwszy symulator lotu samolotu pasażerskiego na polskiej uczelni cywilnej.

## Francja sparaliżowana. Trwa kolejny dzień protestów przeciwko reformie emerytalnej
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8689286,we-francji-trwa-kolejny-dzien-protestow-przeciwko-reformie-emerytalnej.html](https://forsal.pl/swiat/unia-europejska/artykuly/8689286,we-francji-trwa-kolejny-dzien-protestow-przeciwko-reformie-emerytalnej.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 13:40:47+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/2QJktkuTURBXy9iZmE4NWNiOC04ZDQ0LTRjN2UtOGNiNi1jODdjOTBiZjNhY2MuanBlZ5GTBc0BHcyg" />W wielu miejscach Francji odnotowano w poniedziałek blokady dróg, zakładów i instytucji kultury w związku z protestem przeciwko wprowadzanej przez rząd reformie emerytalnej. We wtorek Francuzi po raz dziesiąty wyjdą na ulice, aby sprzeciwić się projektowi rządu i prezydenta Emmanuela Macrona podniesienia wieku emerytalnego.

## Izrael: Do protestu przeciwko reformie sądownictwa dołączają pracownicy MSZ. 27 burmistrzów zapowiedziało strajk głodowy
 - [https://forsal.pl/gospodarka/polityka/artykuly/8689277,izrael-msz-i-burmistrzowie-dolaczaja-do-protestu-reforma-sadownictwa.html](https://forsal.pl/gospodarka/polityka/artykuly/8689277,izrael-msz-i-burmistrzowie-dolaczaja-do-protestu-reforma-sadownictwa.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 13:11:43+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/S4aktkuTURBXy9iMDBiNGNmMy03ZDhlLTQ3NzMtYWNiNi04NjFiMWNjOTc0MzcuanBlZ5GTBc0BHcyg" />Ambasady Izraela na całym świecie zostały w poniedziałek poinstruowane, aby przyłączyć się do strajku przeciwko wprowadzanej przez rząd premiera Benjamina Netanjahu reformie sądownictwa. W kraju 27 burmistrzów zapowiedziało w poniedziałek strajk głodowy, w proteście przeciwko planowanej reformie sądownictwa. Mają prowadzić go przed kancelarią premiera w Jerozolimie.

## Goldman Sachs: W 2023 r. poziom inflacji utrzyma stopy procentowe na obecnym poziomie
 - [https://forsal.pl/gospodarka/inflacja/artykuly/8689231,goldman-sachs-w-2023-r-inflacja-utrzyma-stopy-procentowe-na-obecnym-poziomie.html](https://forsal.pl/gospodarka/inflacja/artykuly/8689231,goldman-sachs-w-2023-r-inflacja-utrzyma-stopy-procentowe-na-obecnym-poziomie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 12:48:40+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Wi0ktkuTURBXy8xOWY1ODhiZS00NDM5LTRhMTEtODkzMi1kNWRmYmY3YTcxZTkuanBlZ5GTBc0BHcyg" />Tegoroczna ścieżka inflacji nie daje możliwości obniżki stóp procentowych w 2023 r., ze względu na uporczywość inflacji bazowej, oceniają oceniają analitycy Goldman Sachs.

## Breton: Kraje UE powinny oddać Ukrainie amunicję ze swoich magazynów
 - [https://forsal.pl/swiat/ukraina/artykuly/8689227,breton-kraje-ue-powinny-oddac-ukrainie-amunicje-ze-swoich-magazynow.html](https://forsal.pl/swiat/ukraina/artykuly/8689227,breton-kraje-ue-powinny-oddac-ukrainie-amunicje-ze-swoich-magazynow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 12:38:40+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/qSNktkuTURBXy9lZjFlNzU2Yi04ZmMxLTQyMGQtOGYyOC00MzQxNTc5ZWY0YTQuanBlZ5GTBc0BHcyg" />Nadszedł czas, by kraje UE oddały amunicję, którą mają w tej chwili w swoich magazynach, i oddały ją Ukrainie - mówił w poniedziałek komisarz UE ds. rynku wewnętrznego Thierry Breton. Podkreślał determinację, by długofalowo przemysł obronny w Europie zwiększył swoją zdolność produkcyjną.

## Ile w tym roku wydamy na Wielkanoc? Polacy planują większe oszczędności
 - [https://forsal.pl/gospodarka/aktualnosci/artykuly/8689215,ile-w-tym-roku-wydamy-na-wielkanoc-polacy-planuja-wieksze-oszczednosci.html](https://forsal.pl/gospodarka/aktualnosci/artykuly/8689215,ile-w-tym-roku-wydamy-na-wielkanoc-polacy-planuja-wieksze-oszczednosci.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 12:08:15+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/6iBktkuTURBXy9mZTA4MzQ2MS0zOWVkLTQ2MzUtYTVmZS1mOThjYTVhZjMwODcuanBlZ5GTBc0BHcyg" />undefined

## Kiedy liczba ludności na świecie osiągnie apogeum? Nowe szacunki
 - [https://forsal.pl/gospodarka/demografia/artykuly/8689213,kiedy-liczba-ludnosci-na-swiecie-osiagnie-apogeum-nowe-szacunki.html](https://forsal.pl/gospodarka/demografia/artykuly/8689213,kiedy-liczba-ludnosci-na-swiecie-osiagnie-apogeum-nowe-szacunki.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 12:02:10+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/YYIktkuTURBXy84MzMyNjI2ZC02MDMzLTRkNTItODRhYi02NTJkNDBjODhjY2EuanBlZ5GTBc0BHcyg" />Ludzkość osiągnie apogeum przyrostu naturalnego wcześniej, niż dotąd zakładano, ale będzie ono niższe niż przewidywano - poinformował w poniedziałek dziennik &quot;Guardian&quot;, powołując się na najnowszy raport Klubu Rzymskiego.

## Produkcja amunicji w różnych miejscach Polski. Rząd przyjmie specjalny program
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8689205,produkcja-amunicji-w-roznych-miejscach-polski-rzad-przyjmie-specjalny-program.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8689205,produkcja-amunicji-w-roznych-miejscach-polski-rzad-przyjmie-specjalny-program.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 11:55:26+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/uqlktkuTURBXy9jNmZjZjY4OC1kYjQxLTRmMGUtODJiZC03OGRmOTI4OTJkOGEuanBlZ5GTBc0BHcyg" />Rada Ministrów w ciągu kilku najbliższych dni przyjmie specjalny, wieloletni program wspierania produkcji amunicji, w zakładach prywatnych i państwowych. Dzisiaj wiemy, że tej amunicji w całej Europie, a nawet w całym NATO jest zbyt mało - powiedział premier Mateusz Morawiecki.

## Ekspert: Tempo rosyjskiej ofensywy zmniejszyło się o 80 proc.
 - [https://forsal.pl/swiat/rosja/artykuly/8689181,ekspert-tempo-rosyjskiej-ofensywy-zmniejszylo-sie-o-80-proc.html](https://forsal.pl/swiat/rosja/artykuly/8689181,ekspert-tempo-rosyjskiej-ofensywy-zmniejszylo-sie-o-80-proc.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 11:32:17+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/8DtktkuTURBXy9lNGQ1OGYxMC1mMWRmLTQ3MjEtOGVjZS1lMDY3ZmYxODlhZDYuanBlZ5GTBc0BHcyg" />Tempo rosyjskich działań ofensywnych na Ukrainie zmniejszyło się o 80 proc., dlatego Kreml zostanie zmuszony do zmiany swojej taktyki i skoncentrowania się nie na ataku, lecz na obronie przed przewidywanym ukraińskim kontrnatarciem - ocenił emerytowany wicemarszałek brytyjskich sił powietrznych Sean Bell, cytowany w poniedziałek przez stację Sky News.

## Jakość wody pitnej. KE wezwała Polskę do wdrożenia przepisów UE
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8689154,jakosc-wody-pitnej-ke-wezwala-polske-do-wdrozenia-przepisow-ue.html](https://forsal.pl/swiat/unia-europejska/artykuly/8689154,jakosc-wody-pitnej-ke-wezwala-polske-do-wdrozenia-przepisow-ue.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 11:24:06+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/tPgktkuTURBXy83MmNkZjBjNC1kYThmLTQ2YTUtYWUwNC05MGEwOWE2ZWNhNWMuanBlZ5GTBc0BHcyg" />undefined

## KE zatwierdziła polski program wsparcia dla produkcji pszenicy i kukurydzy
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8689121,ke-zatwierdzila-polski-program-wsparcia-dla-produkcji-pszenicy-i-kukurydzy.html](https://forsal.pl/swiat/unia-europejska/artykuly/8689121,ke-zatwierdzila-polski-program-wsparcia-dla-produkcji-pszenicy-i-kukurydzy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 11:08:58+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/_4jktkuTURBXy8wZjUwYTJkNy00ZjQ1LTRmYTAtYmM4NC1hN2EwYzM0MjNiNjAuanBlZ5GTBc0BHcyg" />Komisja Europejska zatwierdziła polski program pomocy publicznej o wartości około 126 mln euro (600 mln zł), mający na celu wsparcie sektora produkcji pszenicy i kukurydzy w kontekście wojny Rosji z Ukrainą.

## Rewolucja w nieruchomościach? Powstanie rządowa strona z cenami transakcyjnymi mieszkań
 - [https://forsal.pl/nieruchomosci/artykuly/8689119,ceny-transakcyjne-mieszkan-strona-internetowa.html](https://forsal.pl/nieruchomosci/artykuly/8689119,ceny-transakcyjne-mieszkan-strona-internetowa.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 11:05:59+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/FqjktkuTURBXy9iZmQwN2M5Mi0xNmY1LTRkMzktYjQ3ZC1mM2ZiNmIwYWQyNWMuanBlZ5GTBc0BHcyg" />Z początkiem 2024 r. uruchomimy stronę internetową z przejrzystym podglądem cen transakcyjnych mieszkań z podziałem na miejscowość, dzielnicę i metraż - zapowiedział w poniedziałek w Studiu PAP minister rozwoju i technologii Waldemar Buda.

## Powstaje "Twierdza Północy". Państwa nordyckie łączą siły powietrzne
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8689112,powstaje-twierdza-polnocy-panstwa-nordyckie-lacza-sily-powietrzne.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8689112,powstaje-twierdza-polnocy-panstwa-nordyckie-lacza-sily-powietrzne.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 10:53:55+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/NDsktkuTURBXy8zY2Q3ZTg4Yy03OTEwLTRmY2EtYWVlNy01NWYwZjc5MjkzMzguanBlZ5GTBc0BHcyg" />Wspólne nordyckie eskadry myśliwców Danii, Finlandii, Szwecji i Norwegii liczące ok. 250 maszyn, to proces przygotowywany już od 15 lat, ale dopiero, gdy Finlandia znalazła się na ostatniej prostej do NATO, a Rosja na szeroką skalę zaatakowała Ukrainę, zaczęto mówić o tym „otwarcie” – pisze w poniedziałek fińska prasa.

## Jak Polska zareaguje na plany rozmieszczenia rosyjskiej broni jądrowej na Białorusi? Głos z rządu
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8689107,jak-polska-zareaguje-na-plany-rozmieszczenia-rosyjskiej-broni-jadrowej-na-bialorusi.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8689107,jak-polska-zareaguje-na-plany-rozmieszczenia-rosyjskiej-broni-jadrowej-na-bialorusi.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 10:46:41+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/-sektkuTURBXy84Y2ZmYzYyOS02OWQwLTRlZjQtOGU2MC0wOGUzNTBmNGQ4YzAuanBlZ5GTBc0BHcyg" />Zapowiedź Putina ws. rozmieszczenia na Białorusi taktycznej broni jądrowej, to element eskalacji narracyjnej; reakcja powinna być w tej sprawie spokojna, ale też stanowcza - stwierdził minister ds. UE Szymon Szynkowski vel Sęk.

## Kneset odrzucił wniosek o wotum nieufności wobec rządu Netanjahu
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8689104,kneset-odrzucil-wniosek-o-wotum-nieufnosci-wobec-rzadu-netanjahu.html](https://forsal.pl/swiat/aktualnosci/artykuly/8689104,kneset-odrzucil-wniosek-o-wotum-nieufnosci-wobec-rzadu-netanjahu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 10:37:03+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/LgjktkuTURBXy83NWQxYWRlMC02ZGM1LTRjMTktYWI1NS03MmFhYTE4NWZjOTUuanBlZ5GTBc0BHcyg" />Parlament Izraela - Kneset, odrzucił w poniedziałek wniosek o wotum nieufności wobec prawicowego rządu premiera Benjamina Netanjahu. Jak podała agencja Reutera, wniosek przepadł stosunkiem głosów 53:59. Największy związek zawodowy ogłosił strajk, prace wstrzymały porty morskie i lotnicze.

## Jak długo jeszcze pożyjesz? Oto, co mówią tablice GUS [KALKULATOR 2023]
 - [https://forsal.pl/gospodarka/demografia/artykuly/8689108,jak-dlugo-jeszcze-pozyjesz-oto-co-mowia-tablice-gus-kalkulator-2023.html](https://forsal.pl/gospodarka/demografia/artykuly/8689108,jak-dlugo-jeszcze-pozyjesz-oto-co-mowia-tablice-gus-kalkulator-2023.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 10:35:22+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Li5ktkuTURBXy9mZDllY2U5NS05MTU0LTRmMmUtYWQwMC03NTQ0MTlkNDJkYmUuanBlZ5GTBc0BHcyg" />Z najnowszych danych GUS wynika, że będziemy żyć nieco dłużej w porównaniu z szacunkami z zeszłego roku. Na podstawie tablic statystycznych opracowaliśmy kalkulator, który pokazuje średnią długość dalszego trwania życia w konkretnym wieku.

## Polska liczy na miliard zł z Europejskiego Instrumentu na rzecz Pokoju
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8689101,polska-liczy-na-miliard-zl-z-europejskiego-instrumentu-na-rzecz-pokoju.html](https://forsal.pl/swiat/unia-europejska/artykuly/8689101,polska-liczy-na-miliard-zl-z-europejskiego-instrumentu-na-rzecz-pokoju.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 10:27:43+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/U2PktkuTURBXy8xM2ZkZTdlMi0wMmQ4LTRlNDQtYjllOC0wYmUyNDRlN2EzMzYuanBlZ5GTBc0BHcyg" />Polska otrzymała już ponad 100 mln zł wsparcia z Europejskiego Instrumentu na rzecz Pokoju; liczymy, że do końca kwietnia, do polskiego budżetu może wpłynąć wsparcie w kwocie sięgającej nawet 1 mld zł - powiedział w poniedziałek, w Poznaniu, minister ds. UE Szymon Szynkowski vel Sęk.

## Lotnisko Chopina odwołuje loty. Powód? Strajki w Niemczech i Izraelu
 - [https://forsal.pl/transport/lotnictwo/artykuly/8689094,lotnisko-chopina-odwoluje-loty-strajki-w-niemczech-i-izraelu.html](https://forsal.pl/transport/lotnictwo/artykuly/8689094,lotnisko-chopina-odwoluje-loty-strajki-w-niemczech-i-izraelu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 10:23:29+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/8byktkuTURBXy9mMGFkMzU3ZC01MTI4LTRiMzUtYjk5Yi1hOWQ5ZjdhYzk3MDcuanBlZ5GTBc0BHcyg" />Z powodu poniedziałkowych strajków w Niemczech i w Izraelu odwołano rejsy z Warszawy do tych krajów - poinformowało PAP biuro prasowe Lotniska Chopina. Nie odbędą się loty PLL LOT i Lufthansy m.in. do Stuttgartu, Monachium, Frankfurtu, a także LOT-u z Tel Awiwu.

## Kto najchętniej odwiedza nasz kraj? Wybijają się dwa narody [DANE GUS]
 - [https://forsal.pl/lifestyle/turystyka/artykuly/8689090,kto-najchetniej-odwiedza-nasz-kraj-wybija-sie-jeden-narod-dane-gus.html](https://forsal.pl/lifestyle/turystyka/artykuly/8689090,kto-najchetniej-odwiedza-nasz-kraj-wybija-sie-jeden-narod-dane-gus.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 10:20:38+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/D3ZktkuTURBXy9lOWE1NWE0MC00MWU3LTQyNTgtYjk1NC01MThhNTJlYzU3YjIuanBlZ5GTBc0BHcyg" />Najwięcej turystów zagranicznych korzystających z noclegów w styczniu tego roku stanowili Niemcy, było ich 85 tys. - wynika z opublikowanych w poniedziałek danych Głównego Urzędu Statystycznego.

## Polska nie kupi Remdesiviru. Jest komentarz resortu zdrowia
 - [https://forsal.pl/lifestyle/zdrowie/artykuly/8689085,polska-nie-kupi-remdesiviru-jest-komentarz-resortu-zdrowia.html](https://forsal.pl/lifestyle/zdrowie/artykuly/8689085,polska-nie-kupi-remdesiviru-jest-komentarz-resortu-zdrowia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 10:15:28+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/9uKktkuTURBXy85NGJlNGUxYS1mNjFiLTRiNTYtODBhZi1kYWNiOGIyYmNmZjAuanBlZ5GTBc0BHcyg" />Uwzględniając dostępne analizy i opracowania, po rekomendacji AOTMiT uznającej terapię Remdesivirem jako nieskuteczną lub bardzo mało skuteczną w przebiegu COVID-19, Ministerstwo Zdrowia zdecydowało nie finansować zakupu tego leku ze środków publicznych - przekazał PAP rzecznik resortu Wojciech Andrusiewicz.

## Jakiej inflacji w marcu powinniśmy się spodziewać? Prognoza
 - [https://forsal.pl/gospodarka/inflacja/artykuly/8689063,jakiej-inflacji-w-marcu-powinnismy-sie-spodziewac-prognoza.html](https://forsal.pl/gospodarka/inflacja/artykuly/8689063,jakiej-inflacji-w-marcu-powinnismy-sie-spodziewac-prognoza.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 09:19:17+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/uQ3ktkuTURBXy8yODdhYWVjOS1kMDNlLTQ5MjAtYTQzNi0wNzU3ZmE0NzZlZTcuanBlZ5GTBc0BHcyg" />undefined

## "Wrogie przejęcie państwa Izrael". Demonstranci znów przed izraelskim parlamentem
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8689027,protesty-w-izraelu.html](https://forsal.pl/swiat/aktualnosci/artykuly/8689027,protesty-w-izraelu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 08:44:44+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/UifktkuTURBXy8wNTUyNzViOS1mYWFiLTRmMzItOWM1OS1mOWM3Nzg1NmFkYmQuanBlZ5GTBc0BHcyg" />Przewodniczący Histadrut, największej izraelskiej federacji związków zawodowych, Arnon Bar-Dawid zapowiedział w poniedziałek strajk generalny przeciwko wprowadzanej przez prawicowy rząd reformie sądownictwa. Rano przed parlamentem ponownie zebrali się demonstranci, a w ramach protestów wstrzymane zostały odloty z lotniska Ben Guriona.

## Ukraiński żołnierz po rosyjskiej niewoli: Nie walczymy z żadnym Putinem, ale po prostu z Rosjanami
 - [https://forsal.pl/swiat/ukraina/artykuly/8689003,ukrainski-zolnierz-po-rosyjskiej-niewoli-nie-walczymy-z-zadnym-putinem-ale-po-prostu-z-rosjanami.html](https://forsal.pl/swiat/ukraina/artykuly/8689003,ukrainski-zolnierz-po-rosyjskiej-niewoli-nie-walczymy-z-zadnym-putinem-ale-po-prostu-z-rosjanami.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 08:08:15+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/V6nktkuTURBXy80YjEwZWRkNi1lNjJkLTRjYWItYjUzZS01ZDhiOGIzOGRmYTIuanBlZ5GTBc0BHcyg" />Chciałbym, żeby wszyscy to dobrze zrozumieli - nie walczymy z żadnym Putinem, lecz po prostu z Rosjanami; w więzieniu Putina nie było, natomiast widziałem tam wielu Rosjan, którzy nas torturowali - oświadczył ukraiński żołnierz Maksym Kołesnikow, uwolniony w lutym z rosyjskiej niewoli. Rozmowę z wojskowym opublikował w poniedziałek ukraiński portal Obozrevatel.

## Strajk paraliżuje transport publiczny w Niemczech. "Gniew pracowników jest ogromny"
 - [https://forsal.pl/transport/aktualnosci/artykuly/8688993,strajk-paralizuje-transport-publiczny-w-niemczech-gniew-pracownikow-jest-ogromny.html](https://forsal.pl/transport/aktualnosci/artykuly/8688993,strajk-paralizuje-transport-publiczny-w-niemczech-gniew-pracownikow-jest-ogromny.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 07:59:42+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/h_RktkuTURBXy81YmZhYmZlYy1jYWIwLTRiYmItODEwMy0xYTU0NmM0MmQ3OTkuanBlZ5GTBc0BHcyg" />Strajk ostrzegawczy sparaliżował w poniedziałek transport publiczny w Niemczech. Zatrzymał się ruch pociągów, autobusów i samolotów, dotknięte są również drogi wodne, autostrady i porty. Spośród pracowników kolei strajkuje co najmniej 30 tys. osób - podaje agencja dpa.

## Sztuczna inteligencja przewiduje genetykę raka. To szansa na wydłużenie życia pacjentów
 - [https://forsal.pl/lifestyle/zdrowie/artykuly/8688992,sztuczna-inteligencja-przewiduje-genetyke-raka.html](https://forsal.pl/lifestyle/zdrowie/artykuly/8688992,sztuczna-inteligencja-przewiduje-genetyke-raka.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 07:57:01+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/SJ4ktkuTURBXy9hNzBjY2IyOC1lNGM3LTRjN2EtOTJjNC02NjFiMjM4YjM3OTguanBlZ5GTBc0BHcyg" />Powstał system sztucznej inteligencji, który na podstawie zdjęć w niecałe dwie minuty określa genetyczne mutacje w guzach. Taka wiedza to tymczasem klucz do jak najlepszej terapii.

## "Foreign Policy": Polska i Ukraina powinny stworzyć wspólne państwo
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8688961,foreign-policy-polska-i-ukraina-powinny-stworzyc-wspolne-panstwo.html](https://forsal.pl/swiat/aktualnosci/artykuly/8688961,foreign-policy-polska-i-ukraina-powinny-stworzyc-wspolne-panstwo.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 07:31:05+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/sXaktkuTURBXy8wOTFmNjYwMy01MGVmLTQ2MWEtOGE2OC1mNDQ4YjMzMzA5NDQuanBlZ5GTBc0BHcyg" />Z koncepcją powołania w obecnych czasach struktury na wzór unii polsko-litewskiej wystąpił w niedzielę amerykański magazyn &quot;Foreign Policy&quot;. Stwierdził, że zapoczątkowany ponad 600 lat temu układem w Krewie związek oferuje rozwiązania dla dzisiejszej Europy.

## Co oznacza broń jądrowa Rosji na Białorusi? "To nowa fala napięcia i destabilizacji w Europie"
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8688947,co-oznacza-bron-jadrowa-rosji-na-bialorusi-to-nowa-fala-napiecia-i-destabilizacji-w-europie.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8688947,co-oznacza-bron-jadrowa-rosji-na-bialorusi-to-nowa-fala-napiecia-i-destabilizacji-w-europie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 07:13:57+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ejxktkuTURBXy9hNzg3NzA0ZS0wMjhiLTRkMzctOGZiNS1iODdhZGEyMWMyNjIuanBlZ5GTBc0BHcyg" />Rozmieszczenie przez Rosję broni jądrowej na Białorusi wywołałoby nową falę napięcia i destabilizacji w Europie – oświadczyło litewskie MSZ i zapowiedziało, że w odpowiedzi Litwa będzie nakłaniać swoich partnerów euroatlantyckich do wprowadzenia nowych sankcji.

## Wiadomo, kiedy ruszy i co obejmie konsolidacja finansów publicznych. Minister Rzeczkowska zabrała głos
 - [https://forsal.pl/gospodarka/finanse-publiczne/artykuly/8688938,wiadomo-kiedy-ruszy-i-co-obejmie-konsolidacja-finansow-publicznych-minister-rzeczkowska-zabrala-glos.html](https://forsal.pl/gospodarka/finanse-publiczne/artykuly/8688938,wiadomo-kiedy-ruszy-i-co-obejmie-konsolidacja-finansow-publicznych-minister-rzeczkowska-zabrala-glos.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 07:04:48+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/2ERktkuTURBXy83ZGM3MWU0Zi01YmYyLTQxMDMtYjY2Ny05NGQ0Njg1YmI2YTAuanBlZ5GTBc0BHcyg" />undefined

## Szczyt inflacji za nami. Kiedy wrócimy do poziomu 2,5 proc.?
 - [https://forsal.pl/gospodarka/inflacja/artykuly/8688923,pfr-szczyt-inflacji-za-nami-kiedy-wrocimy-do-poziomu-25-proc-ji.html](https://forsal.pl/gospodarka/inflacja/artykuly/8688923,pfr-szczyt-inflacji-za-nami-kiedy-wrocimy-do-poziomu-25-proc-ji.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 06:56:52+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/KJxktkuTURBXy9kZGRlN2M2Zi03ZjdlLTQ5OTEtYThhOS04NzQwOGRiMzlkMTAuanBlZ5GTBc0BHcyg" />W lutym mieliśmy szczyt inflacji; w tej chwili przechodzimy do dezinflacji. Inflacja na koniec tego roku zapewne osiągnie koło 7 proc. - ocenił w poniedziałek prezes Polskiego Funduszu Rozwoju Paweł Borys.

## Bank Millennium sprzeda udziały w Millennium Financial Services. Jest zgoda UOKiK
 - [https://forsal.pl/biznes/bankowosc/artykuly/8688917,bank-millennium-sprzeda-udzialy-w-millennium-financial-services-jest-zgoda-uokik.html](https://forsal.pl/biznes/bankowosc/artykuly/8688917,bank-millennium-sprzeda-udzialy-w-millennium-financial-services-jest-zgoda-uokik.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 06:51:06+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/0LzktkuTURBXy8yMTdmNjA0MC1mYzEzLTQyNjQtYTIyOS1iZTRjY2MxYjJjZGYuanBlZ5GTBc0BHcyg" />undefined

## Londyn: Ukraińskie drony nawodne zatrzymują... Flotę Czarnomorską
 - [https://forsal.pl/swiat/rosja/artykuly/8688911,londyn-ukrainskie-drony-nawodne-zatrzymuja-flote-czarnomorska.html](https://forsal.pl/swiat/rosja/artykuly/8688911,londyn-ukrainskie-drony-nawodne-zatrzymuja-flote-czarnomorska.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 06:46:43+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/HXKktkuTURBXy80ZDRiMTFmZS04ZmU3LTQzYWEtOTc5OS00ODVmZDQxYTVjNjQuanBlZ5GTBc0BHcyg" />Zagrożenie ze strony ukraińskich bezzałogowych statków nawodnych (USV) nadal ogranicza działania rosyjskiej Floty Czarnomorskiej - przekazało w poniedziałek brytyjskie ministerstwo obrony.

## Niektóre firmy wypracowały w 2022 roku rekordowe wyniki finansowe. Jednak inflacja nadszarpnęła sukcesem
 - [https://forsal.pl/biznes/firma/artykuly/8688757,niektore-firmy-wypracowaly-w-2022-roku-rekordowe-wyniki-finansowe-jednak-inflacja-nadszarpnela-sukcesem.html](https://forsal.pl/biznes/firma/artykuly/8688757,niektore-firmy-wypracowaly-w-2022-roku-rekordowe-wyniki-finansowe-jednak-inflacja-nadszarpnela-sukcesem.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 06:38:23+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/TsKktkuTURBXy9iMGEzZTAwNC1jODQ5LTRlOTUtYWUwYy01ZGFkZjI5ODliOTAuanBlZ5GTBc0BHcyg" />Spółki z branży paliwowej, budowlanej, sprzedające artykuły konsumentom, a także niektóre banki, wypracowały w 2022 r. najlepsze w historii lub bliskie historycznym rekordom wyniki finansowe.

## Jak długo potrwa wojna w Ukrainie? Analitycy wskazują kluczowy czynnik
 - [https://forsal.pl/swiat/rosja/artykuly/8688897,jak-dlugo-potrwa-wojna-w-ukrainie-analitycy-wskazuja-kluczowy-czynnik.html](https://forsal.pl/swiat/rosja/artykuly/8688897,jak-dlugo-potrwa-wojna-w-ukrainie-analitycy-wskazuja-kluczowy-czynnik.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 06:35:58+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/16mktkuTURBXy9kMDllMTAwNC1hYzEyLTRmOWMtYmRhNy0zOTgxMjczOTMwOGMuanBlZ5GTBc0BHcyg" />Inwazja Rosji na Ukrainę będzie trwać tak długo, jak Władimir Putin wierzy, że może działaniami militarnymi narzucić Ukrainie swoją wolę lub zmusić ją do zaprzestania walk w sytuacji, gdy Zachód ją porzuci - ocenia amerykański Instytut Studiów nad Wojną (ISW).

## Prezes UOKiK zostanie rekordzistą? Może kierować urzędem nawet 13 lat
 - [https://forsal.pl/gospodarka/polityka/artykuly/8688777,prezes-uokik-zostanie-rekordzista-moze-kierowac-urzedem-nawet-13-lat.html](https://forsal.pl/gospodarka/polityka/artykuly/8688777,prezes-uokik-zostanie-rekordzista-moze-kierowac-urzedem-nawet-13-lat.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 06:31:49+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/yj-ktkuTURBXy80MjFiNjdkNi1lZGE5LTQzYzQtYTY4MS03ZGNiYzQwOGEzNWYuanBlZ5GTBc0BHcyg" />Obecny szef może być rekordzistą na stanowisku szefa urzędu antymonopolowego i kierować nim przez 8 albo nawet 13 lat.

## Nowa edycja programu "Mój prąd": można uzyskać nawet 28 tys. zł dopłaty do pomp ciepła
 - [https://forsal.pl/biznes/energetyka/artykuly/8688889,nowa-edycja-programu-moj-prad-mozna-uzyskac-nawet-28-tys-zl-doplaty-do-pomp-ciepla.html](https://forsal.pl/biznes/energetyka/artykuly/8688889,nowa-edycja-programu-moj-prad-mozna-uzyskac-nawet-28-tys-zl-doplaty-do-pomp-ciepla.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 06:26:23+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/0kvktkuTURBXy8yMmEyN2E3MS1mNGU2LTRkZTYtYjJhNy0xNDZkMWNiMzAzM2EuanBlZ5GTBc0BHcyg" />Od 4,4 tys. zł do 28 tys. zł mogą wynieść dopłaty do pomp ciepła w piątej odsłonie programu &quot;Mój prąd&quot;; w przypadku kolektorów ma być to do 3,5 tys. zł - poinformował PAP wiceszef NFOŚiGW Paweł Mirowski. Dodał, że &quot;Mój prąd&quot; 5.0 miałby ruszyć w drugiej połowie kwietnia.

## Zboże potaniało, ale tylko w porównaniu z rekordowym 2022 r.
 - [https://forsal.pl/gospodarka/aktualnosci/artykuly/8688793,zboze-potanialo-ale-tylko-w-porownaniu-z-rekordowym-2022-r.html](https://forsal.pl/gospodarka/aktualnosci/artykuly/8688793,zboze-potanialo-ale-tylko-w-porownaniu-z-rekordowym-2022-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 06:24:10+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/45dktkuTURBXy80ZjE3ZWUxMC1hMzg3LTQ3ZTEtYTJiNS1lZmQ1NGE3NmUyZDQuanBlZ5GTBc0BHcyg" />Faktem jest, że zalała nas produkcja rolno-spożywcza z Ukrainy. Ale ceny ziarna wcale nie są niskie. Zboże potaniało, ale tylko w porównaniu z rekordowym 2022 r.

## Kuba: Teledyrygowana kampania rządowa, wybory parlamentarne
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8688880,kuba-teledyrygowana-kampania-rzadowa-wybory-parlamentarne.html](https://forsal.pl/swiat/aktualnosci/artykuly/8688880,kuba-teledyrygowana-kampania-rzadowa-wybory-parlamentarne.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 06:00:52+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ItxktkuTURBXy85ODY5OWE2ZS1lYTg1LTRiMjItOWZjMC01Y2QzODNkODQ1Y2YuanBlZ5GTBc0BHcyg" />Po - jak to określa w internetowych komentarzach kubańska opozycja - „niezwykle intensywnie teledyrygowanej kampanii rządowej”, mającej przełamać obojętność społeczeństwa, w niedzielę na Kubie odbyło się głosowanie do Zgromadzenia Narodowego Władzy Ludowej, tj. do parlamentu.

## W Polsce ubyło osób najbiedniejszych. Przybyło klasy średniej
 - [https://forsal.pl/gospodarka/aktualnosci/artykuly/8688879,w-polsce-ubylo-osob-najbiedniejszych-przybylo-klasy-sredniej.html](https://forsal.pl/gospodarka/aktualnosci/artykuly/8688879,w-polsce-ubylo-osob-najbiedniejszych-przybylo-klasy-sredniej.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 05:55:23+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Ip4ktkuTURBXy84YTk3NmViMS1jMDFjLTRlMDYtOThlMi04MWE4NTg1N2U2ZjguanBlZ5GTBc0BHcyg" />Na przestrzeni czterech lat wzrosła liczba deklaracji składanych przez najbogatszych podatników o rocznych dochodach ponad 1 mln zł. Dane pokazują też, że Polacy nie zbiednieli w trakcie pandemii - donosi w poniedziałek &quot;Dziennik Gazeta Prawna&quot;.

## Stan wyjątkowy w Georgii. Tornado uszkodziło co najmniej 100 budynków
 - [https://forsal.pl/swiat/usa/artykuly/8688874,stan-wyjatkowy-w-georgii-tornado-uszkodzilo-co-najmniej-100-budynkow.html](https://forsal.pl/swiat/usa/artykuly/8688874,stan-wyjatkowy-w-georgii-tornado-uszkodzilo-co-najmniej-100-budynkow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 05:47:56+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/gLIktkuTURBXy8xY2JmMWY3YS04YzcyLTQxMGMtODlkMi02NWU3NDFjZGUzMmMuanBlZ5GTBc0BHcyg" />Zniszczone budynki, powalone drzewa, kilka rannych osób, a wiele innych uwięzionych w domach, to pokłosie niedzielnego tornada w stanie Georgia. Gubernator Brian Kemp wprowadził tam stan wyjątkowy.

## Program budowy 100 obwodnic. Realizowane są inwestycje za prawie 2,6 mld zł
 - [https://forsal.pl/transport/drogi/artykuly/8688870,program-budowy-100-obwodnic-realizowane-sa-inwestycje-za-prawie-26-mld-zl.html](https://forsal.pl/transport/drogi/artykuly/8688870,program-budowy-100-obwodnic-realizowane-sa-inwestycje-za-prawie-26-mld-zl.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 05:41:50+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/2NjktkuTURBXy8wODk0ZWVhNi04NDljLTQwZmUtOTM0ZC05MjJmNTZhYTI5NGEuanBlZ5GTBc0BHcyg" />Generalna Dyrekcja Dróg Krajowych i Autostrad realizuje 13 inwestycji w Programie budowy 100 obwodnic (PB100) o wartości 2 mld 570 mln zł i długości 105,3 km - poinformował PAP rzecznik Ministerstwa Infrastruktury Szymon Huptyś.

## Izrael rozważa możliwość wstrzymania reformy sądownictwa
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8688864,izrael-rozwaza-mozliwosc-wstrzymania-reformy-sadownictwa.html](https://forsal.pl/swiat/aktualnosci/artykuly/8688864,izrael-rozwaza-mozliwosc-wstrzymania-reformy-sadownictwa.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 05:35:43+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/UifktkuTURBXy8wNTUyNzViOS1mYWFiLTRmMzItOWM1OS1mOWM3Nzg1NmFkYmQuanBlZ5GTBc0BHcyg" />Izraelski rząd rozważa możliwość odstąpienia od kontrowersyjnej reformy sądownictwa. Jak podał portal dziennika &quot;Jerusalem Post&quot;, premier Benjamin Netanjahu do późnych godzin nocnych z niedzieli na poniedziałek dyskutował o tym z ministrami ze swego gabinetu.

## Kolejna próba rakietowa Pjongjangu
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8688860,kolejna-proba-rakietowa-pjongjangu.html](https://forsal.pl/swiat/aktualnosci/artykuly/8688860,kolejna-proba-rakietowa-pjongjangu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 05:31:38+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/f8bktkuTURBXy83Mzk5OTNkMS0yZWI2LTQyNWMtODY0ZS0xMjAwZDI4MjY4YzYuanBlZ5GTBc0BHcyg" />Korea Północna wystrzeliła dwie rakiety balistyczne krótkiego zasięgu w kierunku Morza Japońskiego - poinformowała w poniedziałek południowokoreańska armia. To kolejna z serii prób rakietowych prowadzonych przez Pjongjang w tym roku.

## Niemcy: Rozpoczął się 24-godzinny strajk sektora transportu publicznego
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8688858,niemcy-rozpoczal-sie-24-godzinny-strajk-sektora-transportu-publicznego.html](https://forsal.pl/swiat/aktualnosci/artykuly/8688858,niemcy-rozpoczal-sie-24-godzinny-strajk-sektora-transportu-publicznego.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 05:27:53+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/hPSktkuTURBXy84ZGVlMzA4My1jZmY1LTRkYjQtYjYwNi1jZWE3NTM4MmM3ODAuanBlZ5GTBc0BHcyg" />W poniedziałek o północy rozpoczął się w Niemczech 24-godzinny strajk ostrzegawczy sektora transportu publicznego. Protest może sparaliżować komunikację kolejową, drogowa i lotniczą w całym kraju. Do strajku mają dołączyć także firmy obsługujące autostrady. Protestujący domagają się podwyżki płac.

## Fiasko referendum klimatycznego w Berlinie
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8688854,fiasko-referendum-klimatycznego-w-berlinie.html](https://forsal.pl/swiat/aktualnosci/artykuly/8688854,fiasko-referendum-klimatycznego-w-berlinie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 05:23:48+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/4BbktkuTURBXy81NGEwMjlkOC04NzI0LTQ2ZWQtYjQ5Ni05NDY4MThjODNlMWUuanBlZ5GTBc0BHcyg" />Niedzielne referendum w Berlinie dotyczące przyspieszenia neutralności klimatycznej stolicy zakończyło się fiaskiem - poinformowała komisja wyborcza. Do osiągnięcia 25-procentowego kworum zabrakło ponad 160 tys. głosów. „Referendum w sprawie bardziej ambitnych celów klimatycznych w Berlinie nie powiodło się” – podkreślił portal dziennika „Welt”.

## Izrael: Tysiące demonstrantów, próba ataku na dom premiera
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8688850,izrael-tysiace-demonstrantow-proba-ataku-na-dom-premiera.html](https://forsal.pl/swiat/aktualnosci/artykuly/8688850,izrael-tysiace-demonstrantow-proba-ataku-na-dom-premiera.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 05:17:35+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/37MktkuTURBXy8yODg0YzI5OS0yM2U3LTQ1ZTQtYjk4OS1iNWI4OTUxOWVmZjIuanBlZ5GTBc0BHcyg" />Tysiące mieszkańców Izraela wyszły na ulice po niedzielnym zdymisjonowaniu ministra obrony Joawa Galanta - informuje portal dziennika &quot;Jerusalem Post&quot;.

## Sztuczna Inteligencja pyta o najważniejszą lekcję w życiu, Bill Gates odpowiada
 - [https://forsal.pl/lifestyle/psychologia/artykuly/8688322,ai-pyta-o-najwazniejsza-lekcje-w-zyciu-bill-gates-odpowiada.html](https://forsal.pl/lifestyle/psychologia/artykuly/8688322,ai-pyta-o-najwazniejsza-lekcje-w-zyciu-bill-gates-odpowiada.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 04:50:24+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/RQdktkuTURBXy9kZGM3MGVjYS00MDYyLTQ5ODUtOGYzOS01YjRmNzNmYTZmMjUuanBlZ5GTBc0BHcyg" />Podczas jednego ze spotkań Bill Gates został zapytany przez bota podobnego do ChatGPT o najlepszą radę, jaką kiedykolwiek otrzymał oraz o to, jak wpłynęła ona na jego życie. W odpowiedzi założyciel Microsoftu odniósł się do słów, jakie usłyszał od swojego długoletniego przyjaciela i miliardera Warrena Buffetta na temat pielęgnowania… przyjaźni.

## Magazyny energii są niezbędne, ale ich podłączenie nie jest proste
 - [https://forsal.pl/biznes/energetyka/artykuly/8688272,magazyny-energii-sa-niezbedne-ale-ich-podlaczenie-nie-jest-proste.html](https://forsal.pl/biznes/energetyka/artykuly/8688272,magazyny-energii-sa-niezbedne-ale-ich-podlaczenie-nie-jest-proste.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 04:33:13+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/MlgktkuTURBXy9hN2YxMGUxOS1mNDU4LTQyNTYtODBmNi01OWNhMGM0YjUyMWEuanBlZ5GTBc0BHcyg" />Pomimo tego, że magazyny energii niwelują skutki niestabilnego charakteru pracy instalacji OZE, a także stabilizują pracę sieci, to wciąż uzyskanie warunków przyłączenia magazynu energii nie jest łatwe. Wynika to przede wszystkim ze stanu sieci energetycznych

## Tesla rozpoczęła chińską wojnę cenową. To może zniszczyć niektórych producentów samochodów
 - [https://forsal.pl/motoforsal/motobiznes/artykuly/8687394,tesla-rozpoczela-chinska-wojne-cenowa-to-moze-zniszczyc-niektorych-producentow-samochodow.html](https://forsal.pl/motoforsal/motobiznes/artykuly/8687394,tesla-rozpoczela-chinska-wojne-cenowa-to-moze-zniszczyc-niektorych-producentow-samochodow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-03-27 04:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/QeKktkuTURBXy9jNjc5ZDYyMi01ZTlkLTQ4N2YtOTZkYy00NmIxNjVjMjA2OTkuanBlZ5GTBc0BHcyg" />Tesla wywołała wojnę cenową w Chinach, która może zmienić kształt największego na świecie rynku samochodowego. To może spowodować, że część producentów zniknie z rynku.

