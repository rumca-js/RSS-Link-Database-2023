# Source:Wired business, URL:https://www.wired.com/feed/category/business/latest/rss, language:en-US

## ChatGPT Opened a New Era in Search. Microsoft Could Ruin It
 - [https://www.wired.com/story/chatgpt-opened-a-new-era-in-search-microsoft-could-ruin-it/](https://www.wired.com/story/chatgpt-opened-a-new-era-in-search-microsoft-could-ruin-it/)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2023-03-27 11:00:00+00:00

Startups say Microsoft and its Bing chatbot—not just Google—are stifling competition when it comes to creating better search engines.

