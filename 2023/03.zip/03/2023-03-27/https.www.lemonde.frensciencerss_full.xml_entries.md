# Source:Le Monde - science, URL:https://www.lemonde.fr/en/science/rss_full.xml, language:en-US

## Felines in majesty at the Muséum National d'Histoire Naturelle
 - [https://www.lemonde.fr/en/science/article/2023/03/28/felines-in-majesty-at-the-museum-national-d-histoire-naturelle_6020900_10.html](https://www.lemonde.fr/en/science/article/2023/03/28/felines-in-majesty-at-the-museum-national-d-histoire-naturelle_6020900_10.html)
 - RSS feed: https://www.lemonde.fr/en/science/rss_full.xml
 - date published: 2023-03-27 22:18:40+00:00

The 'Felines' exhibition at the Grande Galerie de l'Evolution immerses visitors in the amazing biology of 38 species of these fascinating predators, until January 7, 2024.

