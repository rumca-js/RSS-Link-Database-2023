# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Dow i S&P 500 w górę w ślad za drożejącymi bankami
 - [https://www.bankier.pl/wiadomosc/Dow-i-S-P-500-w-gore-w-slad-za-drozejacymi-bankami-8512630.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Dow-i-S-P-500-w-gore-w-slad-za-drozejacymi-bankami-8512630.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 21:08:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/9/78a9e350c388bc-948-568-20-50-1980-1187.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Poniedziałkowa sesja na Wall Street zakończyła się przewagą wzrostów głównych indeksów. Liderami zwyżek był sektor bankowy, traciły spółki technologiczne. Mocno drożała ropa naftowa.</p>

## Stanowisko premiera dla TK: zapisy noweli o Sądzie Najwyższym są konstytucyjne
 - [https://www.bankier.pl/wiadomosc/Stanowisko-premiera-dla-TK-zapisy-noweli-o-Sadzie-Najwyzszym-sa-konstytucyjne-8512582.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Stanowisko-premiera-dla-TK-zapisy-noweli-o-Sadzie-Najwyzszym-sa-konstytucyjne-8512582.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 18:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/d/b88cc0e593f887-948-568-0-45-2000-1199.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zaskarżone przez prezydenta Andrzeja Dudę zapisy styczniowej nowelizacji ustawy o Sądzie Najwyższym, m.in. te dotyczące testu niezależności sędziego oraz przekazujące sprawy dyscyplinarne i immunitetowe sędziów do NSA są zgodne z konstytucją - głosi stanowisko Prezesa Rady Ministrów przekazane TK.</p>

## Premier Izraela wstrzymuje reformę wymiaru sprawiedliwości, by uniknąć wojny domowej
 - [https://www.bankier.pl/wiadomosc/Premier-Izraela-wstrzymuje-reforme-wymiaru-sprawiedliwosci-by-uniknac-wojny-domowej-8512580.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Premier-Izraela-wstrzymuje-reforme-wymiaru-sprawiedliwosci-by-uniknac-wojny-domowej-8512580.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 18:45:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/9/9e56dbf9476651-948-568-0-103-1732-1039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Premier Izraela Benjamin Netanjahu ogłosił w poniedziałek w przemówieniu do narodu, że tymczasowo wstrzymuje plany swego rządu dotyczące kontrowersyjnej reformy wymiaru sprawiedliwości, aby uniknąć "wojny domowej".</p>

## Największy prywatny pracodawca w USA zaczyna zwalniać. "To trudna decyzja"
 - [https://www.bankier.pl/wiadomosc/Walmart-oglosil-zwolnienia-Prace-straca-setki-osob-8512469.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Walmart-oglosil-zwolnienia-Prace-straca-setki-osob-8512469.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 18:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/b/4a85b587296420-948-568-0-62-2500-1499.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Amerykańska sieć sklepów Walmart zwolni kilkaset osób z działu sprzedaży internetowej – poinformowały agencja Reuters oraz telewizja CNBC. Największy prywatny pracodawca w USA nie ukrywa, że nadchodzące miesiące nie będą należały do najłatwiejszych, zwłaszcza biorąc pod uwagę mało optymistyczną prognozę dotyczącą sprzedaży.
</p>

## Koniec Pegasusa w USA. Biden zakazał rządowym agencjom używania komercyjnego oprogramowania szpiegowskiego
 - [https://www.bankier.pl/wiadomosc/Koniec-Pegasusa-w-USA-Biden-zakazal-rzadowym-agencjom-uzywania-komercyjnego-oprogramowania-szpiegowskiego-8512536.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Koniec-Pegasusa-w-USA-Biden-zakazal-rzadowym-agencjom-uzywania-komercyjnego-oprogramowania-szpiegowskiego-8512536.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 17:23:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/7/c943c0652283d0-948-568-0-31-2508-1504.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prezydent Biden podpisał w poniedziałek rozporządzenie wykonawcze zakazujące instytucjom rządowym używania komercyjnego oprogramowania szpiegowskiego (spyware) takiego jak m.in. Pegasus. Według Białego Domu ewentualne używanie takich programów stanowiłoby ryzyko dla bezpieczeństwa narodowego.</p>

## Węgry za przyjęciem Finlandii do NATO
 - [https://www.bankier.pl/wiadomosc/Wegry-za-przyjeciem-Finlandii-do-NATO-8512531.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wegry-za-przyjeciem-Finlandii-do-NATO-8512531.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 17:17:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/3/42edad34fa2248-948-568-0-104-1672-1003.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Parlament Węgier poparł w poniedziałek wniosek 
Finlandii o przystąpienie do NATO. W głosowaniu akcesję Finlandii do 
Sojuszu Północnoatlantyckiego poparło 182 posłów, sześciu było przeciw, 
nikt nie wstrzymał się od głosu.</p>

## Kłopotliwe kredyty "frankowe". Resort finansów też pracuje nad prawnym rozwiązaniem tej kwestii
 - [https://www.bankier.pl/wiadomosc/Klopotliwe-kredyty-frankowe-Resort-finansow-tez-pracuje-nad-prawnym-rozwiazaniem-tej-kwestii-8512526.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Klopotliwe-kredyty-frankowe-Resort-finansow-tez-pracuje-nad-prawnym-rozwiazaniem-tej-kwestii-8512526.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 17:13:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/6/bbb74fb71e2665-948-568-0-0-2000-1199.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ministerstwo Finansów pracuje nad prawnym uregulowaniem kwestii walutowych kredytów hipotecznych w CHF - powiedziała minister finansów Magdalena Rzeczkowska, cytowana przez agencję Bloomberg.</p>

## Tydzień na GPW rozpoczęty od zieleni. Te spółki zaliczyły spektakularny wzrost
 - [https://www.bankier.pl/wiadomosc/Tydzien-na-GPW-rozpoczety-od-zieleni-Te-spolki-zaliczyly-spektakularny-wzrost-8512481.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tydzien-na-GPW-rozpoczety-od-zieleni-Te-spolki-zaliczyly-spektakularny-wzrost-8512481.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 16:45:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/4/a42ca6f1319839-945-560-7-78-1492-895.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Początek tygodnia przyniósł wzrosty głównych indeksów na GPW, co wpisywało się w lepszy sentyment na rynkach bazowych związany ze zmniejszeniem napięć w sektorze bankowym. Kilka spółek zaliczyło spektakularny wzrost kursu. Natomiast nad kwestiami geopolitycznych zapowiedzi Rosji umieszczenia broni nuklearnej na Białorusi rynki przeszły obojętnie.</p>

## KNF wszczęła postępowania wyjaśniające dot. obrotu akcjami kilku spółek, m.in. Ekipy Friza
 - [https://www.bankier.pl/wiadomosc/KNF-wszczela-postepowania-wyjasniajace-dot-obrotu-akcjami-kilku-spolek-8512493.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/KNF-wszczela-postepowania-wyjasniajace-dot-obrotu-akcjami-kilku-spolek-8512493.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 16:42:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/1/5ec4520d6477af-948-568-0-163-2510-1505.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Komisja Nadzoru Finansowego wszczęła postępowania wyjaśniające dotyczące podejrzenia popełnienia przestępstw wykorzystania i ujawnienia informacji poufnej oraz manipulacji w obrocie akcjami spółek: Ekipa Holding, Impera Capital ASI, Medicofarma Biotech, Medcamp - podała Komisja w komunikacie.</p>

## Młodzi Japończycy nie biorą urlopów rodzicielskich w obawie przed reakcją pracodawcy
 - [https://www.bankier.pl/wiadomosc/Mlodzi-Japonczycy-nie-biora-urlopow-rodzicielskich-w-obawie-przed-reakcja-pracodawcy-8512447.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Mlodzi-Japonczycy-nie-biora-urlopow-rodzicielskich-w-obawie-przed-reakcja-pracodawcy-8512447.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 15:45:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/1/9ec4f9902b140b-948-568-0-181-2487-1492.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Młodzi japońscy ojcowie boją się reakcji pracodawców i nie występują o urlopy rodzicielskie, podaje w poniedziałek CNN, przypominając, iż w ubiegłym roku liczba urodzeń spadła po raz pierwszy od XIX wieku poniżej 800 tysięcy.</p>

## Tanie konto firmowe bez ograniczeń czasowych. Sprawdzamy, co oferują banki
 - [https://www.bankier.pl/wiadomosc/Tanie-konto-firmowe-bez-ograniczen-czasowych-8512156.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tanie-konto-firmowe-bez-ograniczen-czasowych-8512156.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 15:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/6/9ac211b0ee8334-948-568-0-50-3360-2015.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Niski koszt korzystania z konta firmowego w długim horyzoncie czasowym jest jednym z kluczowych elementów wpływających na wybór rachunku biznesowego. Istotny jest również brak dodatkowych warunków do spełnienia, aby korzystać z darmowego rachunku, karty płatniczej, przelewów zewnętrznych oraz zleceń stałych. Przeanalizowaliśmy oferty kont firmowych pod kątem bezterminowej możliwości korzystania z rachunku bez opłat.</p>

## Czechom wciąż opłaca się jeździć na zakupy do Polski
 - [https://www.bankier.pl/wiadomosc/Czechom-wciaz-oplaca-sie-jezdzic-na-zakupy-do-Polski-8512390.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Czechom-wciaz-oplaca-sie-jezdzic-na-zakupy-do-Polski-8512390.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 14:44:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/5/b02cf64d966863-948-568-2-0-997-598.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Czeski portal internetowy Seznam Zpravy zwrócił w poniedziałek uwagę, że dla Czechów Polska jest najtańszym z sąsiednich państw. Tak wynika  z porównania cen podstawowych produktów w przygranicznych sklepach.</p>

## Rząd znów nie da zarobić. Oprocentowanie obligacji oszczędnościowych bez zmian
 - [https://www.bankier.pl/wiadomosc/Oprocentowanie-obligacji-detalicznych-bez-zmian-8512378.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Oprocentowanie-obligacji-detalicznych-bez-zmian-8512378.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 14:34:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/8/bea4098a49024f-948-568-0-130-3583-2150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Oprocentowanie obligacji detalicznych, które będą sprzedawane w kwietniu, pozostało na poziomie z marca – poinformowało Ministerstwo Finansów w środowym komunikacie.</p>

## Minister Moskwa: Odejście od silników spalinowych od 2035 roku jest nierealne
 - [https://www.bankier.pl/wiadomosc/Minister-Moskwa-Odejscie-od-silnikow-spalinowych-od-2035-roku-jest-nierealne-8512364.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Minister-Moskwa-Odejscie-od-silnikow-spalinowych-od-2035-roku-jest-nierealne-8512364.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 14:24:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/2/e1bceb543827d3-948-568-0-119-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wraz z innymi państwami będziemy nadal blokować unijne regulacje dot. samochodów z silnikami spalinowymi - zapowiedziała w poniedziałek minister klimatu i środowiska Anna Moskwa. Oceniła, że zaproponowane odejście od stosowania silników spalinowych od 2035 r. jest nierealne.</p>

## Blokady dróg i zakładów w całej Francji przed kolejnym dniem protestów przeciwko reformie emerytalnej
 - [https://www.bankier.pl/wiadomosc/Blokady-drog-i-zakladow-w-calej-Francji-przed-kolejnym-dniem-protestow-przeciwko-reformie-emerytalnej-8512339.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Blokady-drog-i-zakladow-w-calej-Francji-przed-kolejnym-dniem-protestow-przeciwko-reformie-emerytalnej-8512339.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 13:57:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/8/d33ad4ebd6d2cd-948-568-0-56-3254-1952.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W wielu miejscach Francji odnotowano w poniedziałek blokady dróg, zakładów i instytucji kultury w związku z protestem przeciwko wprowadzanej przez rząd reformie emerytalnej. We wtorek Francuzi po raz dziesiąty wyjdą na ulice, aby sprzeciwić się projektowi rządu i prezydenta Emmanuela Macrona podniesienia wieku emerytalnego.</p>

## "Otwarcie chińskiej gospodarki nie uratuje globalnego rynku przed recesją"
 - [https://www.bankier.pl/wiadomosc/Otwarcie-chinskiej-gospodarki-nie-uratuje-globalnego-rynku-przed-recesja-8512327.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Otwarcie-chinskiej-gospodarki-nie-uratuje-globalnego-rynku-przed-recesja-8512327.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 13:34:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/e/84ac0337adc6d8-948-568-0-150-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Otwarcie chińskiej gospodarki, po obostrzeniach związanych z pandemią koronawirusa, wcale nie pomoże oprzeć się globalnemu rynkowi przed recesją - oceniają uczestnicy XXX debaty PAP Biznes "Strategie rynkowe TFI". Sytuacja na rynku surowców wraca do normy, ale sytuacja może ulec zmianie pod wpływem czynników geopolitycznych.</p>

## EY: inwestorzy wydali na polskim rynku nieruchomości 5,8 mld euro w 2022 roku
 - [https://www.bankier.pl/wiadomosc/EY-inwestorzy-wydali-na-polskim-rynku-nieruchomosci-5-8-mld-euro-w-2022-roku-8512302.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/EY-inwestorzy-wydali-na-polskim-rynku-nieruchomosci-5-8-mld-euro-w-2022-roku-8512302.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 13:20:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/0/966334bca99f1e-948-568-14-465-1905-1143.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Na polskim rynku nieruchomości w '22 zawarto 122 transakcje o wartości 5,8 mld euro, rok wcześniej było to 5,9 mld euro - poinformował EY w komunikacie prasowym. Jedna trzecia inwestorów pochodziła z USA, a 22 proc. to inwestorzy z Europy Zachodniej.</p>

## Ci politycy cieszą się największym zaufaniem, a tym ufamy najmniej
 - [https://www.bankier.pl/wiadomosc/Ci-politycy-ciesza-sie-najwiekszym-zaufaniem-a-tym-ufamy-najmniej-8512287.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ci-politycy-ciesza-sie-najwiekszym-zaufaniem-a-tym-ufamy-najmniej-8512287.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 13:07:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/5/3abba4927d90d0-948-568-4-13-1768-1061.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prezydent Andrzej Duda, szef MON Mariusz Błaszczak i premier Mateusz Morawiecki to liderzy rankingu zaufania w marcu - wynika z sondażu CBOS. Z największą nieufnością spotykają się szef PO Donald Tusk, prezes PiS Jarosław Kaczyński oraz minister sprawiedliwości Zbigniew Ziobro.</p>

## Leroy Merlin wreszcie wycofa się z Rosji. Po 18 latach
 - [https://www.bankier.pl/wiadomosc/Leroy-Merlin-wreszcie-wycofa-sie-z-Rosji-Po-18-latach-8512238.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Leroy-Merlin-wreszcie-wycofa-sie-z-Rosji-Po-18-latach-8512238.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 12:45:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/8/346b185edf95d6-948-568-0-129-3970-2381.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Francuska sieć marketów Leroy Merlin zapowiedziała, że planuje wycofanie
 się z rosyjskiego rynku. Nie stanie się to jednak szybko.</p>

## "Banki centralne nie mogą już podnosić stóp procentowych dowolnie wysoko"
 - [https://www.bankier.pl/wiadomosc/Banki-centralne-nie-moga-juz-podnosic-stop-procentowych-dowolnie-wysoko-8512260.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Banki-centralne-nie-moga-juz-podnosic-stop-procentowych-dowolnie-wysoko-8512260.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 12:40:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/f/002fc61d586dfa-948-567-0-32-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Aktualne problemy sektora bankowego na świecie pokazują, że banki centralne nie mogą podnosić stóp procentowych na dowolnie wysoki poziom - uważają uczestnicy XXX debaty PAP Biznes "Strategie rynkowe TFI". Zdaniem zarządzających, nie można z pewnością stwierdzić, że inflacja globalnie została opanowana.</p>

## Premier Morawiecki: Rząd przyjmie wieloletni program wspierania produkcji amunicji
 - [https://www.bankier.pl/wiadomosc/Premier-Rzad-przyjmie-wieloletni-program-wspierania-produkcji-amunicji-8512255.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Premier-Rzad-przyjmie-wieloletni-program-wspierania-produkcji-amunicji-8512255.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 12:39:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/8/a24c7ee922424b-948-568-0-0-965-579.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rada Ministrów w ciągu kilku najbliższych dni 
przyjmie specjalny, wieloletni program wspierania produkcji amunicji, w 
zakładach prywatnych i państwowych. Dzisiaj wiemy, że tej amunicji w 
całej Europie, a nawet w całym NATO jest zbyt mało - powiedział premier 
Mateusz Morawiecki.</p>

## Muskowi udało się niemożliwe. Twitter wart mniej niż 20 mld dolarów
 - [https://www.bankier.pl/wiadomosc/Twitter-wart-mniej-niz-20-mld-dolarow-Musk-obnizyl-wartosc-o-polowe-8512098.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Twitter-wart-mniej-niz-20-mld-dolarow-Musk-obnizyl-wartosc-o-polowe-8512098.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 12:28:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/8/7d88afed24aea8-948-568-0-15-997-598.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Elon Musk zapłacił za Twittera 44 mld dolarów. Jak 
się okazuje, w trzy miesiące platforma straciła połowę swojej 
szacunkowej wartości. Sam CEO przyznał, że spółka wyceniana jest obecnie
 na mniej niż 20 mld dolarów. </p>

## KE zatwierdza polski program wsparcia dla rolników na kwotę ok. 126 mln euro
 - [https://www.bankier.pl/wiadomosc/KE-zatwierdza-polski-program-wsparcia-dla-rolnikow-na-kwote-ok-126-mln-euro-8512218.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/KE-zatwierdza-polski-program-wsparcia-dla-rolnikow-na-kwote-ok-126-mln-euro-8512218.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 11:58:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/9/3f998baa21f9f2-948-568-0-100-2508-1504.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Komisja Europejska zatwierdziła polski program pomocy publicznej o wartości około 126 mln euro (600 mln zł), mający na celu wsparcie sektora produkcji pszenicy i kukurydzy w kontekście wojny Rosji z Ukrainą.</p>

## Niedzielski zapowiada "permanentny problem z personelem medycznym"
 - [https://www.bankier.pl/wiadomosc/Niedzielski-zapowiada-permanentny-problem-z-personelem-medycznym-8512199.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Niedzielski-zapowiada-permanentny-problem-z-personelem-medycznym-8512199.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 11:35:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/e/c2fc204dd02da5-948-568-316-100-1579-947.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />System opieki zdrowotnej będzie miał permanentny problem z personelem medycznym, nie tylko w Polsce, ale i w różnych krajach europejskich - ocenił w poniedziałek minister zdrowia Adam Niedzielski. Za 10 lat i tak będziemy mieli za mało tych lekarzy - dodał.</p>

## Buda: Przyglądamy się cesji na rynku pierwotnym
 - [https://www.bankier.pl/wiadomosc/Pierwsze-mieszkanie-Rzad-bedzie-walczyc-ze-spekulacja-na-rynku-nieruchomosci-8512178.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Pierwsze-mieszkanie-Rzad-bedzie-walczyc-ze-spekulacja-na-rynku-nieruchomosci-8512178.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 11:20:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/0/965df37ac89e86-948-568-0-31-2510-1505.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przyglądamy się cesji na rynku pierwotnym, zamawianiu i blokowaniu u deweloperów mieszkań i późniejszej ich odsprzedaży - powiedział w poniedziałek w Studiu PAP szef MRiT Waldemar Buda. Wskazał, że można się spodziewać rozwiązania opartego na wyłączeniu w umowie deweloperskiej cesji.</p>

## Lotnisko Chopina uziemione. Loty do Niemiec i Izraela odwołane
 - [https://www.bankier.pl/wiadomosc/Lotnisko-Chopina-uziemione-Loty-do-Niemiec-i-Izraela-odwolane-8512165.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Lotnisko-Chopina-uziemione-Loty-do-Niemiec-i-Izraela-odwolane-8512165.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 10:59:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/4/6fc30c55f02de2-945-560-0-0-2992-1795.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Z powodu poniedziałkowych strajków w Niemczech i w Izraelu odwołano rejsy z Warszawy do tych krajów - poinformowało PAP biuro prasowe Lotniska Chopina. Nie odbędą się loty PLL LOT i Lufthansy m.in. do Stuttgartu, Monachium, Frankfurtu, a także LOT-u z Tel Awiwu.</p>

## Zremb zyskuje dzięki półwiecznej koncesji od MSWiA. Kurs w górę o 50% w dwa dni
 - [https://www.bankier.pl/wiadomosc/Zremb-zyskuje-dzieki-polwiecznej-koncesji-od-MSWiA-Kurs-w-gore-o-50-w-dwa-dni-8512149.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zremb-zyskuje-dzieki-polwiecznej-koncesji-od-MSWiA-Kurs-w-gore-o-50-w-dwa-dni-8512149.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 10:45:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/a/95ae549ce68f77-948-568-0-91-2602-1561.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Akcje Zrembu mocno zyskują drugi dzień z rzędu po komunikacie opublikowanym w piątek, informującym o przyznaniu przez MSWiA długoletniej licencji na wytwarzanie wyrobów o przeznaczeniu wojskowym i policyjnym.</p>

## Prezes CI Games: Premiera "Lords of The Fallen" może kilkakrotnie zwiększyć wycenę
 - [https://www.bankier.pl/wiadomosc/Premiera-Lords-of-The-Fallen-moze-kilkakrotnie-zwiekszyc-wycene-CI-Games-prezes-wywiad-8512150.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Premiera-Lords-of-The-Fallen-moze-kilkakrotnie-zwiekszyc-wycene-CI-Games-prezes-wywiad-8512150.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 10:40:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/a/ccc3e25e452372-948-568-244-0-1432-859.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Premiera gry "Lords of The Fallen" może kilkakrotnie zwiększyć wycenę CI Games - uważa prezes spółki Marek Tymiński. Wiadomo też, że do premiery zostało jedynie kilka miesięcy. Prezes poinformował, że gra, mimo relatywnie niskich kosztów produkcji, będzie sprzedawana w cenie właściwej dla segmentu AAA. 
</p>

## Na nielegalnym hazardzie mieli zarobić ponad 150 mln złotych. Liczne zatrzymania
 - [https://www.bankier.pl/wiadomosc/380-salonow-gier-i-2200-automatow-Grupa-hazardowa-rozbita-przez-KAS-8512061.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/380-salonow-gier-i-2200-automatow-Grupa-hazardowa-rozbita-przez-KAS-8512061.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 10:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/d/7cfc5138da4374-945-567-11-11-1488-893.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />50 osób zatrzymanych, zlikwidowane 382 nielegalne salony gier i prawie 2200 zabezpieczonych automatów – to efekty śledztwa prowadzonego przez funkcjonariuszy śląskiej Krajowej Administracji Skarbowej i policjantów przeciwko grupie zajmującej się nielegalnym hazardem.</p>

## Gorąco w Izraelu. Największy związek zawodowy strajkuje, tłumy pod parlamentem
 - [https://www.bankier.pl/wiadomosc/Goraco-w-Izraelu-Najwiekszy-zwiazek-zawodowy-strajkuje-tlumy-pod-parlamentem-8512097.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Goraco-w-Izraelu-Najwiekszy-zwiazek-zawodowy-strajkuje-tlumy-pod-parlamentem-8512097.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 09:27:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/e/47d6a5e62eaf41-948-568-370-1010-3316-1990.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przewodniczący Histadrut, największej izraelskiej federacji związków zawodowych, Arnon Bar-Dawid zapowiedział w poniedziałek strajk generalny przeciwko wprowadzanej przez prawicowy rząd reformie sądownictwa. Rano przed parlamentem ponownie zebrali się demonstranci, a w ramach protestów wstrzymane zostały odloty z lotniska Ben Guriona.</p>

## Polskie firmy chcą wprowadzać innowacje, ale napotykają poważne przeszkody
 - [https://www.bankier.pl/wiadomosc/Polskie-firmy-chca-wprowadzac-innowacje-ale-napotykaja-powazne-przeszkody-8505537.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polskie-firmy-chca-wprowadzac-innowacje-ale-napotykaja-powazne-przeszkody-8505537.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 09:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/7/d17f70b1769db7-948-568-7-24-986-591.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Jak wynika z IV edycji badania „Monitoring innowacyjności polskich przedsiębiorstw” przeprowadzonego przez PARP, w 2021 r. aż 79,6 proc. polskich przedsiębiorstw wprowadziło lub próbowało wdrożyć przynajmniej jedną innowację, a ponad jedna trzecia firm innowacyjnych przeznaczyła na ten cel nie więcej niż 50 tys. zł.</p>

## Kurs euro bez większych zmian. Frank odzyskuje grunt
 - [https://www.bankier.pl/wiadomosc/Kurs-euro-bez-wiekszych-zmian-Frank-odzyskuje-grunt-8512086.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kurs-euro-bez-wiekszych-zmian-Frank-odzyskuje-grunt-8512086.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 09:10:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/a/2b0117ce206f73-948-568-0-200-1672-1003.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kurs euro pozostał poniżej 4,70 zł przy stabilizacji na parze
euro-dolar. Po ostatnich spadkach straty odrabiał kurs franka.</p>

## Huta przetrwała choć była na skraju bankructwa. Zrezygnowała z gazu z PGNiG
 - [https://www.bankier.pl/wiadomosc/Huta-przetrwala-choc-byla-na-skraju-bankructwa-Zrezygnowala-z-gazu-z-PGNiG-8512067.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Huta-przetrwala-choc-byla-na-skraju-bankructwa-Zrezygnowala-z-gazu-z-PGNiG-8512067.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 09:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/0/e9ff8c25fc6393-948-568-0-17-3500-2099.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przepis na uniknięcie bankructwa przez hutę z Wielkopolski był prosty - wystarczyło zrezygnować z dostaw gazu od PGNiG i zacząć go importować. Stawki są o 40 proc. niższe. </p>

## Ceny zbóż spadają w ślad za rynkami światowymi
 - [https://www.bankier.pl/wiadomosc/Ceny-zboz-spadaja-w-slad-za-rynkami-swiatowymi-8512073.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ceny-zboz-spadaja-w-slad-za-rynkami-swiatowymi-8512073.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 08:48:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/9/3f998baa21f9f2-948-568-0-100-2508-1504.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ceny zbóż spadają w ślad za rynkami światowymi oraz małym zainteresowaniem przetwórców w kraju - podała Izba Zbożowo-Paszowa w newsletterze.</p>

## Mieli badać odporność, a naciągali klientów. Polmediq z zarzutami UOKiK
 - [https://www.bankier.pl/wiadomosc/Polmediq-z-zarzutami-UOKiK-Mieli-badac-odpornosc-a-naciagali-klientow-8512069.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polmediq-z-zarzutami-UOKiK-Mieli-badac-odpornosc-a-naciagali-klientow-8512069.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 08:40:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/0/720dddcd2bef66-948-568-0-97-4896-2937.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kolejna odsłona batalii Urzędu Ochrony Konkurencji i Konsumentów przeciw "bezpłatnym badaniom". Poznańskiej spółce Polmediq postawiono zarzuty, że konsumenci zapraszani na "bezpłatne badania" odporności nie wiedzą, że mają one charakter handlowy. Co więcej, uczestnicy mogą zostać wprowadzeni w błąd odnośnie stanu swojego zdrowia.</p>

## Robert Lewandowski za słaby dla InPostu? Nie weźmie udziału w nowych reklamach
 - [https://www.bankier.pl/wiadomosc/Robert-Lewandowski-za-slaby-dla-InPostu-Nie-wezmie-udzialu-w-nowych-reklamach-8512063.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Robert-Lewandowski-za-slaby-dla-InPostu-Nie-wezmie-udzialu-w-nowych-reklamach-8512063.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 08:33:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/f/1d8244d91fd1f0-948-568-0-69-1980-1187.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Robert Lewandowski nie weźmie udziału w najnowszych reklamach InPostu – informuje „Interia”. Jak komentują specjaliści od marketingu sportowego, wizerunek najlepszego polskiego napastnika może być już zbyt słaby lub za mało przekonujący w reklamie zbiorowej.</p>

## Grupowe zwolnienia w Levi'sie obejmą też modeli. Zastąpi ich AI
 - [https://www.bankier.pl/wiadomosc/Grupowe-zwolnienia-w-Levi-sie-obejma-tez-modeli-Zastapi-ich-AI-8512030.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Grupowe-zwolnienia-w-Levi-sie-obejma-tez-modeli-Zastapi-ich-AI-8512030.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 08:27:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/b/3f0166a178b560-948-568-1158-1028-1837-1102.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Reklamy Levi'sa będą tworzone przez AI. Znany koncern odzieżowy zapewne wypowie umowy modelom i modelkom w ramach zapowiedzianych zwolnień grupowych. W tym samym czasie rozpoczął współpracę z firmą Lalaland.ai z Holandii. To ona ma dostarczyć sztucznie wygenerowane osoby do prezentacji produktów. Firma wyjaśnia, że zapewni to różnorodność.</p>

## Prezes Saudi National Bank rezygnuje ze stanowiska. Bank był największym udziałowcem Credit Suisse
 - [https://www.bankier.pl/wiadomosc/Saudi-National-Bank-i-Credit-Suisse-Prezes-odchodzi-z-powodow-osobistych-8512059.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Saudi-National-Bank-i-Credit-Suisse-Prezes-odchodzi-z-powodow-osobistych-8512059.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 08:20:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/3/d8f1cef18b2899-945-560-0-56-1500-899.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ammar Al Khudairy, prezes Saudi National Bank, największego akcjonariusza Credit Suisse, podał się do dymisji zaledwie kilka dni po tym, jak jego komentarze przyczyniły się do ostrego spadku kursu akcji szwajcarskiego banku.</p>

## Bumech szacuje, że przychody w 2022 były 160 proc. wyższe rdr
 - [https://www.bankier.pl/wiadomosc/Bumech-szacuje-przychody-w-22-na-1-112-mln-zl-a-EBITDA-na-562-mln-zl-8512052.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Bumech-szacuje-przychody-w-22-na-1-112-mln-zl-a-EBITDA-na-562-mln-zl-8512052.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 08:04:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/b/ccf4d09f95918d-945-560-978-236-3521-2112.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Bumech szacuje, że w 2022 roku skonsolidowane przychody ze sprzedaży wyniosły 1.112 mln zł, co oznacza wzrost o 160,3 proc. rdr. EBITDA szacowana jest na 562 mln zł, wyżej o 105,3 proc. rdr - podała spółka w komunikacie.</p>

## Ile potrwa walka z inflacją? Szef PFR przewiduje, że będzie to kilka lat
 - [https://www.bankier.pl/wiadomosc/Borys-W-lutym-byl-szczyt-inflacji-teraz-przechodzimy-do-dezinflacji-8512044.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Borys-W-lutym-byl-szczyt-inflacji-teraz-przechodzimy-do-dezinflacji-8512044.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 07:45:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/1/687815100baf40-948-568-4-84-1768-1061.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Szczyt inflacji minęliśmy w lutym, teraz przechodzimy do dezinflacji - ocenił w poniedziałek prezes Polskiego Funduszu Rozwoju Paweł Borys. Jego zdaniem, inflacja na koniec tego roku zapewne osiągnie koło 7 proc.</p>

## ZBP chce zmian w ustawie o nadzorze makroostrożnościowym
 - [https://www.bankier.pl/wiadomosc/ZBP-chce-zmian-w-ustawie-o-nadzorze-makroostroznosciowym-8512031.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/ZBP-chce-zmian-w-ustawie-o-nadzorze-makroostroznosciowym-8512031.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 07:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/b/d595025fa8b9cb-948-568-0-60-1730-1038.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Związek Banków Polskich chciałby zmian w ustawie o nadzorze makroostrożnościowym. Wskazuje przy tym na potrzebę lepszej koordynacji stanowisk między Komitetem Stabilności Finansowej a różnymi organami państwa, szczególnie w sprawach kluczowych dla sektora finansowego.</p>

## Ten bank kiedyś wyszedł z Polski. Dziś znów oferuje konto za 0 złotych
 - [https://www.bankier.pl/wiadomosc/Raiffeisen-Digital-Bank-wprowadzil-konta-osobiste-8512022.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Raiffeisen-Digital-Bank-wprowadzil-konta-osobiste-8512022.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 07:14:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/6/0c4331333f7857-893-535-6-24-893-535.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Pierwsi klienci dostali już zaproszenie do założenia konta osobistego w Raiffeisen Digital Bank. Konto jest w pełni cyfrowe i można je obsługiwać za pomocą aplikacji mobilnej. Do rachunku wydawana jest wirtualna karta Visa, którą można podpiąć do Google Pay (a wkrótce Apple Pay).</p>

## Ceny ropy rosną. W tle obawy o sektor bankowy
 - [https://www.bankier.pl/wiadomosc/Ceny-ropy-rosna-W-tle-obawy-o-sektor-bankowy-8512021.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ceny-ropy-rosna-W-tle-obawy-o-sektor-bankowy-8512021.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 07:13:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/7/613012a503e7bd-948-568-0-124-1920-1151.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ceny ropy na giełdzie paliw w Nowym Jorku rosną, a inwestorzy przygotowują się na dalszą zmienność na rynkach w związku z konsekwencjami kryzysu bankowego, który raz się wzmaga, a raz opada na rynkach - informują maklerzy.</p>

## Wielkie zielone inwestycje. Blisko połowa prądu w Polsce ma pochodzić z OZE
 - [https://www.bankier.pl/wiadomosc/Wielkie-zielone-inwestycje-Blisko-polowa-pradu-w-Polsce-ma-pochodzic-z-OZE-8512007.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wielkie-zielone-inwestycje-Blisko-polowa-pradu-w-Polsce-ma-pochodzic-z-OZE-8512007.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 06:08:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/a/9e2b3523c1d316-948-568-0-199-3464-2078.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Gigantyczne nakłady finansowe czekają OZE i energetykę jądrową, a ceny wytwarzania prądu mają radykalnie spaść. Takie są bowiem szczegóły założeń do aktualizacji strategii energetycznej - donosi w poniedziałek "Rzeczpospolita". Transformacja energetyczna w Polsce pochłonie setki miliardów złotych.</p>

## Drożeją prywatne ubezpieczenia zdrowotne. Ale to nie odstrasza Polaków
 - [https://www.bankier.pl/wiadomosc/Drozeja-prywatne-ubezpieczenia-zdrowotne-Ale-to-nie-odstrasza-Polakow-8512002.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Drozeja-prywatne-ubezpieczenia-zdrowotne-Ale-to-nie-odstrasza-Polakow-8512002.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 06:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/0/3b8ddcf7267d38-948-568-10-54-4342-2605.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Co 4. pracujący ma ubezpieczenie zdrowotne. W ciągu ostatniego roku liczba ta wzrosła o prawie 11 proc., choć - w związku z inflacją - rosną również ich ceny. - W 2022 roku koszty prywatnych pakietów medycznych wzrosły średnio o 20-30 proc., w tym roku spodziewamy się kolejnych podwyżek rzędu nawet 40 proc. - mówi Marcin Rybarczyk z Compensy. </p>

## Polska klasa średnia się rozrasta. Ubywa osób najbiedniejszych
 - [https://www.bankier.pl/wiadomosc/Polska-klasa-srednia-sie-rozrasta-Ubywa-osob-najbiedniejszych-8512000.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polska-klasa-srednia-sie-rozrasta-Ubywa-osob-najbiedniejszych-8512000.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 05:59:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/4/939f70ecdd05f4-948-568-7-70-992-595.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Polacy nie zbiednieli podczas pandemii. Tak wynika z deklaracji składanych przez ostatnie cztery lata. Wzrosła liczba dokumentów dostarczanych przez najbogatszych podatników o rocznych dochodach ponad 1 mln zł - informuje "Dziennik Gazeta Prawna".</p>

## Media w Polsce ograniczone. Dziennikarze nie mają łatwo
 - [https://www.bankier.pl/wiadomosc/Media-w-Polsce-ograniczone-Dziennikarze-nie-maja-latwo-8511994.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Media-w-Polsce-ograniczone-Dziennikarze-nie-maja-latwo-8511994.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 05:53:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/a/99549d58a422f4-945-567-0-0-1550-930.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ograniczona swoboda wypowiedzi i utrzudnianie pracy dziennikarzy to jedno z najistotniejszych naruszeń praw człowieka w Polsce – głosi amerykański raport, którego wyniki publikuje w poniedziałek "Rzeczpospolita". "Raport nie tylko pokazuje kłopoty mediów w Polsce, ale odzwierciedla też spojrzenie Amerykanów na demokrację" - ocenia prof. Maciej Mrozowski.</p>

## Polska na wojnie z TikTokiem. Rząd chce go zakazać
 - [https://www.bankier.pl/wiadomosc/Polska-na-wojnie-z-TikTokiem-Rzad-chce-go-zakazac-8511992.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polska-na-wojnie-z-TikTokiem-Rzad-chce-go-zakazac-8511992.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 05:44:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/7/30850521a3154f-948-568-0-73-1732-1039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Walka z chińską aplikacją TikTok trwa na całym świecie. Działająca przy premierze Rada ds. Cyfryzacji przedstawi w poniedziałek rekomendację odnośnie zakazu korzystania z TikToka na urządzeniach urzędników państwowych - donosi "Rzeczpospolita".</p>

## Izrael wstrzyma reformę sądownictwa? Prezydent apeluje
 - [https://www.bankier.pl/wiadomosc/Izrael-wstrzyma-reforme-sadownictwa-Media-Rzad-moze-sie-ugiac-8511975.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Izrael-wstrzyma-reforme-sadownictwa-Media-Rzad-moze-sie-ugiac-8511975.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 05:02:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/d/14eca75850210e-948-568-0-50-2507-1504.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Izraelski rząd rozważa możliwość odstąpienia od kontrowersyjnej reformy sądownictwa. Jak podał portal dziennika "Jerusalem Post", premier Benjamin Netanjahu do późnych godzin nocnych z niedzieli na poniedziałek dyskutował o tym z ministrami ze swego gabinetu.</p>

## Branża meblarska tonie w długach. Od 6 miesięcy jest tylko gorzej
 - [https://www.bankier.pl/wiadomosc/Branza-meblarska-tonie-w-dlugach-Od-6-miesiecy-jest-tylko-gorzej-8511974.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Branza-meblarska-tonie-w-dlugach-Od-6-miesiecy-jest-tylko-gorzej-8511974.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 05:01:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/d/d43fc4550a091c-948-568-0-56-2508-1504.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zadłużenie branży meblarskiej rośnie od sześciu miesięcy, obecnie wynosi 101,1 mln zł - wynika z danych Krajowego Rejestru Długów. Kondycję sektora pogorszyła inflacja i wojna za wschodnią granicą  - ocenia prezes KRD. Niemal 3/4 zaległości należy do producentów mebli.</p>

## Pożegnanie z wysokimi stawkami na lokatach? Banki już tną oprocentowanie
 - [https://www.bankier.pl/wiadomosc/Obnizki-na-lokatach-terminowych-8511789.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Obnizki-na-lokatach-terminowych-8511789.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/5/55e3325356f558-948-568-0-187-2677-1606.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Utrzymanie stóp procentowych na takim samym poziomie od miesięcy nie sprzyja oszczędzającym. Od jakiegoś czasu częściej mamy do czynienia z cięciami na lokatach niż z podwyżkami. Wiele banków obniża stawki nawet o 1 pp. lub całkowicie wycofuje najlepszą propozycję z oferty.</p>

## W których bankach z GPW szukać dywidendy? "Frankowe" problemy mogą rozczarować inwestorów
 - [https://www.bankier.pl/wiadomosc/W-ktorych-bankach-z-GPW-szukac-dywidendy-Frankowe-problemy-moga-rozczarowac-inwestorow-8509791.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/W-ktorych-bankach-z-GPW-szukac-dywidendy-Frankowe-problemy-moga-rozczarowac-inwestorow-8509791.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/8/2eeb92b247f15c-948-568-7-97-2992-1795.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Chociaż rok 2022 r. był dla polskiego sektora bankowego
wymagający po stronie kosztowej, to i tak zyski powróciły do poziomów z czasów
przed pandemią. Niestety "frankowe" problemy mogą skutecznie zablokować możliwość wypłaty
dywidendy przez banki notowane na GPW.</p>

## "To paraliż". Niemcy rozpoczęli strajk sektora publicznego
 - [https://www.bankier.pl/wiadomosc/To-paraliz-Niemcy-rozpoczeli-strajk-sektora-publicznego-8511963.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/To-paraliz-Niemcy-rozpoczeli-strajk-sektora-publicznego-8511963.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-03-27 01:36:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/d/1f29fb7e2514db-948-568-0-14-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Samoloty uziemione, pociągi stoją, autobusy w zajezdniach - tak w poniedziałek o północy rozpoczął się w Niemczech 24-godzinny strajk ostrzegawczy sektora transportu publicznego. Do protestujących mają też dołączyć także firmy obsługujące autostrady. </p>

