# Source:China Insights, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwjvvgGX6oby5mZ3gbDe8Ug, language:en-US

## Chinese men/officials become offended when failing in the courtship. Who are "you" and who are "we"?
 - [https://www.youtube.com/watch?v=f0eec98_WQ0](https://www.youtube.com/watch?v=f0eec98_WQ0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwjvvgGX6oby5mZ3gbDe8Ug
 - date published: 2023-03-27 01:15:09+00:00

#chinainsights 
In the minds of some Chinese men, wealth and status are blatant bargaining chips used for romance and courtship. 
According to what was said by the male official in this episode after the blind date, "We are the ones who are free from stress and live comfortably", while "you are the ones who won't be able to make it even till the retirement. This kind of expressions have gradually made the Chinese people distinguish who is "we" and who is "you". 

Have questions? Do you have something to share with us about China? We want to hear from you! 
Email: Cinsights.subscription@gmail.com
Facebook www.facebook.com/EyesOnChina.

Your support allows us to produce more high-quality videos. 
Consider donating at https://www.paypal.com/paypalme/ChinaInsights

Copyright @ China Insights 2021. Any illegal reproduction of this content in any form will result in immediate action against the person(s) concerned.

