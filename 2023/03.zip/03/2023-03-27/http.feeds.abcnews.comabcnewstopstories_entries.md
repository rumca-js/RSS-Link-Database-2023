# Source:ABC News, URL:http://feeds.abcnews.com/abcnews/topstories, language:en-US

## Train carrying iron ore derails in San Bernardino County, California
 - [https://abcnews.go.com/US/train-carrying-iron-ore-derails-san-bernardino-county/story?id=98160194](https://abcnews.go.com/US/train-carrying-iron-ore-derails-san-bernardino-county/story?id=98160194)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-27 22:34:47+00:00

A train carrying raw material derailed in California on Monday, according to San Bernardino County fire officials.

## N. Carolina governor signs Medicaid expansion bill into law
 - [https://abcnews.go.com/Politics/wireStory/carolina-governor-signs-medicaid-expansion-bill-law-98164119](https://abcnews.go.com/Politics/wireStory/carolina-governor-signs-medicaid-expansion-bill-law-98164119)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-27 22:33:01+00:00

North Carolina Democratic Gov. Roy Cooper has signed a Medicaid expansion law that was a decade in the making

## Family of US couple kidnapped in Haiti plea for release
 - [https://abcnews.go.com/International/wireStory/family-us-couple-kidnapped-haiti-plea-release-98162389](https://abcnews.go.com/International/wireStory/family-us-couple-kidnapped-haiti-plea-release-98162389)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-27 22:18:07+00:00

The family of a U.S. couple who has been kidnapped in Haiti is pleading for their release

## At least 20 dead when bus hits bridge, burns in Saudi Arabia
 - [https://abcnews.go.com/International/wireStory/20-dead-bus-hits-bridge-burns-saudi-arabia-98163485](https://abcnews.go.com/International/wireStory/20-dead-bus-hits-bridge-burns-saudi-arabia-98163485)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-27 22:14:07+00:00

State media in Sauid Arabia say at least 20 people were killed when a packed bus hit a bridge, overturned and burst into flames in the country's southwest

## New source of water found in moon samples from China mission
 - [https://abcnews.go.com/Technology/wireStory/new-source-water-found-moon-samples-china-mission-98162299](https://abcnews.go.com/Technology/wireStory/new-source-water-found-moon-samples-china-mission-98162299)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-27 22:12:31+00:00

Scientists have discovered a new and renewable source of water on the moon for future explorers in lunar samples returned from a Chinese mission

## Terry Sanderson testifies in Gwyneth Paltrow ski crash trial
 - [https://abcnews.go.com/GMA/Culture/gwyneth-paltrow-trial-2016-ski-crash/story?id=98015777](https://abcnews.go.com/GMA/Culture/gwyneth-paltrow-trial-2016-ski-crash/story?id=98015777)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-27 21:09:16+00:00

Terry Sanderson, the man taking Gwyneth Paltrow to court over a 2016 ski crash, testified in court Monday during the civil trial.

## WATCH:  Corgis get VIP tour of Madame Tussauds’ new Royal Palace attraction
 - [https://abcnews.go.com/GMA/Culture/video/corgis-vip-tour-madame-tussauds-new-royal-palace-98155263](https://abcnews.go.com/GMA/Culture/video/corgis-vip-tour-madame-tussauds-new-royal-palace-98155263)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-27 19:31:08+00:00

Nine corgis got to see wax figures of the Royal Family ahead of King Charles III’s coronation.

## Timeline: How the Nashville shooting at Covenant School unfolded
 - [https://abcnews.go.com/US/timeline-shooting-covenant-school-unfolded/story?id=98158185](https://abcnews.go.com/US/timeline-shooting-covenant-school-unfolded/story?id=98158185)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-27 19:22:42+00:00

Police said 14 minutes passed between the time they got a 911 call about a shooter at a Christian school outside Nashville and the suspect's death.

## George Washington University to replace controversial 'Colonials' moniker
 - [https://abcnews.go.com/Politics/george-washington-university-replace-controversial-colonials-moniker/story?id=98153154](https://abcnews.go.com/Politics/george-washington-university-replace-controversial-colonials-moniker/story?id=98153154)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-27 17:53:56+00:00

Students said the name had a negative connotation regarding violence toward Native Americans.

## Train derails in rural North Dakota and spills chemical
 - [https://abcnews.go.com/US/wireStory/train-derails-rural-north-dakota-spills-chemical-98154142](https://abcnews.go.com/US/wireStory/train-derails-rural-north-dakota-spills-chemical-98154142)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-27 17:50:41+00:00

A Canadian Pacific train derailed in rural North Dakota Sunday night and spilled some hazardous materials, but local authorities and the railroad said there is no threat to public safety

## Restaurant owner describes the moment she saved her staff from tornado
 - [https://abcnews.go.com/GMA/Food/restaurant-owner-describes-sky-saved-staff-tornado/story?id=98145014](https://abcnews.go.com/GMA/Food/restaurant-owner-describes-sky-saved-staff-tornado/story?id=98145014)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-27 17:09:19+00:00

Tracy Harden, the owner of Chuck's Dairy Bar in Rolling Fork, Mississippi, rushed her staff into a cooler moments before a tornado hit.

## Fox News producer who sued network says she's been fired
 - [https://abcnews.go.com/US/fox-news-producer-sued-network-shes-fired-testifying/story?id=98149663](https://abcnews.go.com/US/fox-news-producer-sued-network-shes-fired-testifying/story?id=98149663)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-27 16:59:02+00:00

The Fox News producer who sued the network last week alleging she was "coerced" into giving false testimony against Dominion Voting Systems says she has now been fired.

## Twitter celebs balk at paying Elon Musk for blue check mark
 - [https://abcnews.go.com/Technology/wireStory/twitter-celebs-balk-paying-elon-musk-blue-check-98155253](https://abcnews.go.com/Technology/wireStory/twitter-celebs-balk-paying-elon-musk-blue-check-98155253)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-27 16:50:33+00:00

William Shatner, Monica Lewinsky and other prolific Twitter commentators &mdash; some household names, others little-known journalists &mdash; could soon be losing the blue check marks that helped verify their identity on the social media platform

## Multiple patients reported amid 'active aggressor' at Nashville school
 - [https://abcnews.go.com/US/multiple-patients-reported-amid-active-aggressor-nashville-school/story?id=98152651](https://abcnews.go.com/US/multiple-patients-reported-amid-active-aggressor-nashville-school/story?id=98152651)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-27 15:56:07+00:00

The Nashville Fire Department is reporting multiple patients from an "active aggressor" at a private school in Nashville, Tennessee.

## Sheriff: Man who fled traffic shot shoots officer in Florida
 - [https://abcnews.go.com/US/wireStory/sheriff-man-fled-traffic-shot-shoots-officer-florida-98150308](https://abcnews.go.com/US/wireStory/sheriff-man-fled-traffic-shot-shoots-officer-florida-98150308)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-27 14:32:14+00:00

Sheriff's officials say a man who sped away from a traffic stop in Florida last week shot and critically wounded a sheriff&rsquo;s officer before killing himself during a standoff at his home

## Louvre staff block entrances as part of pension protest
 - [https://abcnews.go.com/International/wireStory/louvre-staff-block-entrances-part-pension-protest-98149503](https://abcnews.go.com/International/wireStory/louvre-staff-block-entrances-part-pension-protest-98149503)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-27 13:17:13+00:00

The Louvre Museum in Paris has been closed to the public because its workers took part in the wave of French protest strikes against the government&rsquo;s unpopular pension reform plans

## Russian shelling of Ukraine city kills 2, wounds 29 people
 - [https://abcnews.go.com/International/wireStory/russian-shelling-ukraine-city-kills-2-wounds-29-98147832](https://abcnews.go.com/International/wireStory/russian-shelling-ukraine-city-kills-2-wounds-29-98147832)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-27 13:16:18+00:00

Officials in Ukraine say two people were killed and 29 wounded when Russian forces shelled the Ukrainian city of Sloviansk, in the partially occupied eastern Donetsk region

## South reels from deadly tornado outbreak as new storm takes aim in the West
 - [https://abcnews.go.com/US/south-reels-deadly-tornado-outbreak-new-storm-takes/story?id=98143392](https://abcnews.go.com/US/south-reels-deadly-tornado-outbreak-new-storm-takes/story?id=98143392)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-27 12:35:46+00:00

Over the weekend, at least 27 tornadoes were reported across five states -- Louisiana, Mississippi, Alabama, Georgia and Tennessee.

## Elizabeth Warren running for 3rd US Senate term in 2024
 - [https://abcnews.go.com/Politics/wireStory/elizabeth-warren-running-3rd-us-senate-term-2024-98146076](https://abcnews.go.com/Politics/wireStory/elizabeth-warren-running-3rd-us-senate-term-2024-98146076)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-27 12:15:23+00:00

Massachusetts Democratic U.S. Sen. Elizabeth Warren has announced she will seek a third term in 2024

## Alibaba's Jack Ma returns to mainland China
 - [https://abcnews.go.com/International/wireStory/alibabas-jack-ma-returns-mainland-china-98147111](https://abcnews.go.com/International/wireStory/alibabas-jack-ma-returns-mainland-china-98147111)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-27 12:13:52+00:00

Alibaba founder Jack Ma has resurfaced in China after months of overseas travel, visiting a school in the eastern city of Hangzhou where he discussed various topics including artificial intelligence

## Israel's airport departures suspended amid public outcry over justice reform bill
 - [https://abcnews.go.com/International/israels-airport-departures-suspended-amid-public-outcry-prime/story?id=98144543](https://abcnews.go.com/International/israels-airport-departures-suspended-amid-public-outcry-prime/story?id=98144543)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-27 11:40:09+00:00

Protesters streamed on to Israel's streets overnight, as thousands voiced their opposition to a controversial justice reform bill.

## WATCH:  Car flips after being hit by flying tire
 - [https://abcnews.go.com/US/video/car-flips-after-hit-flying-tire-98145731](https://abcnews.go.com/US/video/car-flips-after-hit-flying-tire-98145731)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-27 11:09:32+00:00

Police said no major injuries were sustained in the dramatic incident in Los Angeles.

## Iraqi parliament passes controversial vote law amendments
 - [https://abcnews.go.com/International/wireStory/iraqi-parliament-passes-controversial-vote-law-amendments-98144338](https://abcnews.go.com/International/wireStory/iraqi-parliament-passes-controversial-vote-law-amendments-98144338)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-27 09:48:01+00:00

Iraqi lawmakers have passed controversial amendments to the country's election law that could undermine the chances for smaller parties and independent candidates to win seats in future polls

## 2 dead, 5 injured in shootings at 2 Little Rock locations, police say
 - [https://abcnews.go.com/US/2-dead-5-injured-shootings-2-rock-locations/story?id=98144144](https://abcnews.go.com/US/2-dead-5-injured-shootings-2-rock-locations/story?id=98144144)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-27 07:41:39+00:00

Two people were killed and five were injured in a pair of shootings in Little Rock, Arkansas, on Sunday evening, local police said.

## In Macron's France, streets and fields seethe with protest
 - [https://abcnews.go.com/Business/wireStory/macrons-france-streets-fields-seethe-protest-98143576](https://abcnews.go.com/Business/wireStory/macrons-france-streets-fields-seethe-protest-98143576)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-27 07:22:40+00:00

Protesting is a rite of passage in France and again the rage

## Deputies accused of shoving guns in mouths of 2 Black men
 - [https://abcnews.go.com/US/wireStory/deputies-accused-shoving-guns-mouths-2-black-men-98143955](https://abcnews.go.com/US/wireStory/deputies-accused-shoving-guns-mouths-2-black-men-98143955)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-27 07:22:07+00:00

Police and court records obtained by The Associated Press show that deputies who were accepted to a Mississippi sheriff's department's special tactical unit have been involved in at least four violent encounters with Black men since 2019 that left two ...

## Taiwan's former leader Ma begins China visit
 - [https://abcnews.go.com/International/wireStory/taiwans-former-leader-ma-begins-china-visit-98143956](https://abcnews.go.com/International/wireStory/taiwans-former-leader-ma-begins-china-visit-98143956)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-27 07:18:08+00:00

Former Taiwan President Ma Ying-jeou departed for a 12-day tour of China Monday, a day after Taiwan lost another of its 14 diplomatic partners to China

## First Citizens to buy $72 billion in assets of failed Silicon Valley Bank, FDIC says
 - [https://abcnews.go.com/Business/citizens-buy-72-billion-assets-failed-silicon-valley/story?id=98142831](https://abcnews.go.com/Business/citizens-buy-72-billion-assets-failed-silicon-valley/story?id=98142831)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-27 06:13:38+00:00

First Citizens Bank will buy about $72 billion in assets from the failed Silicon Valley Bank, the Federal Deposit Insurance Corporation said.

## Twitter: parts of its source code leaked online
 - [https://abcnews.go.com/Technology/wireStory/twitter-parts-source-code-leaked-online-98140440](https://abcnews.go.com/Technology/wireStory/twitter-parts-source-code-leaked-online-98140440)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-27 00:17:53+00:00

Some parts of Twitter&rsquo;s source code _ the fundamental computer code on which the social network runs _ were leaked online, the social media company said in a legal filing on Sunday that was first reported by The New York Times

## Mass protests erupt after Netanyahu fires defense chief
 - [https://abcnews.go.com/International/wireStory/israeli-group-asks-court-punish-netanyahu-legal-plan-98133304](https://abcnews.go.com/International/wireStory/israeli-group-asks-court-punish-netanyahu-legal-plan-98133304)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-03-27 00:17:22+00:00

Tens of thousands of Israelis have poured into the streets across the country in a spontaneous outburst of anger after Prime Minister Benjamin Netanyahu abruptly fired his defense minister for challenging the Israeli leader&rsquo;s judicial overhaul plan

