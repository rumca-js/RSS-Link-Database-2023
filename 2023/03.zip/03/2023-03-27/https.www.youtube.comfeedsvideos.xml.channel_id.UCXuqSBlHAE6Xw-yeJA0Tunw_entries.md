# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## I’m breaking one of my biggest rules..
 - [https://www.youtube.com/watch?v=0IhmkF50VgE](https://www.youtube.com/watch?v=0IhmkF50VgE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2023-03-27 19:00:01+00:00

Get 69% off any of XSplit’s video tools. Use code LINUS at https://lmg.gg/XSplit

Check out Corsair’s Xeneon Flex 45WQHD240 OLED Bendable Monitor at https://lmg.gg/corsairxeneonflex.

We asked our community to send us their hot tech takes for Linus to react to. Some of them are pretty hot...

Discuss on the forum: https://linustechtips.com/topic/1496999-i%E2%80%99m-breaking-one-of-my-biggest-rules/

Buy an ASUS TUF NVIDIA GeForce RTX 4070 Ti: https://geni.us/NhTlo3i
Buy a ZOTAC GeForce RTX 3070 Ti: https://geni.us/Te4W
Buy a Razer Core X GPU Enclosure: https://geni.us/Jrn6S
Buy a Valve Steam Deck: https://geni.us/Apee9DU

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► LTX 2023 TICKETS AVAILABLE NOW: https://lmg.gg/ltx23
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► OUR WAN PODCAST GEAR: https://lmg.gg/wanset

FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
1:26 let's get ready to roasteeeeem
29:33 Outro

