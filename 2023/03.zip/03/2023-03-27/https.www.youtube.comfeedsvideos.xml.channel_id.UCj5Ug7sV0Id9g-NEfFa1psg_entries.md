# Source:Tomasz Samołyk, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCj5Ug7sV0Id9g-NEfFa1psg, language:en-US

## O spotkaniu Jezusa na planie "The Chosen" i serialowych sekretach, o których nie słyszeliście
 - [https://www.youtube.com/watch?v=OWC9RCwpwL8](https://www.youtube.com/watch?v=OWC9RCwpwL8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCj5Ug7sV0Id9g-NEfFa1psg
 - date published: 2023-03-27 15:00:22+00:00

Zapraszam do wysłuchania rozmowy z Andrzejem Sobczykiem - człowiekiem, który sprowadził @thechosenpolska do Polski i był na planie serialu.

#thechosen #tajemnice #andrzejsobczyk

Obróbka audio 👉 https://radekhrynek.com/ 

Strona mojej żony OIi 👉 https://olasamolyk.pl/

Kontynuowanie i rozwijanie mojej pracy możliwe jest dzięki Patronom. Tu można do nich dołączyć oraz dowiedzieć się o tym na co idą środki ze wsparcia oraz poczytać o planowanych kierunkach rozwoju kanału 👉 https://patronite.pl/Samolyk

JAK MOŻNA WESPRZEĆ KANAŁ i DOŁĄCZYĆ DO GRUPY FACEBOOK DLA WSPIERAJĄCYCH:

Można mnie wesprzeć na https://patronite.pl/samolyk, przez przycisk "WESPRZYJ" lub wpłacając dobrowolną kwotę na nr konta: Bank Pekao SA 08 1240 2786 1111 0010 1984 8265 tytułem: "darowizna"
--------------------------------------------------------------------------------------
Jeżeli wpłaciłeś darowiznę, wsparłeś mnie przez przycisk "WESPRZYJ" i chcesz być w napisach końcowych I dołączyć do grupy Patronów na Facebooku to daj mi znać na tsamolyk@gmail.com. Kiedyś wpisywałem w napisach końcowych wszystkich Darczyńców, ale kilku z nich zwróciło mi uwagę, że chcą pozostać anonimowi. Mają do tego prawo więc wprowadzam taką praktykę. Dziękuję za zrozumienie.

ROZMOWA W FORMIE PODCASTU:
Spotify: https://open.spotify.com/show/5LQ8IsR8xSdFKt3JxlFUUJ

