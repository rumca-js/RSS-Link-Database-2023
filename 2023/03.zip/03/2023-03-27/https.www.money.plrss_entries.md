# Source:Money PL, URL:https://www.money.pl/rss/, language:pl-PL

## Tusk obiecuje energetyczną samodzielność gmin i powiatów
 - [https://www.money.pl/gospodarka/tusk-obiecuje-energetyczna-samodzielnosc-gmin-i-powiatow-6881017598245664a.html](https://www.money.pl/gospodarka/tusk-obiecuje-energetyczna-samodzielnosc-gmin-i-powiatow-6881017598245664a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-27 16:52:14+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/5b5c93ca-cc99-445a-a668-261644da25e6" width="308" /> Doprowadzimy do tego, że w Polsce będzie własny prąd na poziomie gminy i powiatu, będzie energetyczna samodzielność gmin i powiatów - powiedział w poniedziałek na spotkaniu w Strzelcach Opolskich  szef PO Donald Tusk.

## Decyzja o kredycie w jeden dzień? Te banki najszybciej podejmą decyzję
 - [https://www.money.pl/pieniadze/decyzja-o-kredycie-w-jeden-dzien-te-banki-najszybciej-podejma-decyzje-6880986756975392a.html](https://www.money.pl/pieniadze/decyzja-o-kredycie-w-jeden-dzien-te-banki-najszybciej-podejma-decyzje-6880986756975392a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-27 14:46:43+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/70e1e7ec-3c3e-4bdf-aab0-0ca52c6282ad" width="308" /> Kredyt gotówkowy na dowolny cel jest przyznawany bardzo szybko. Pieniądze trafiają na konto klienta nawet jeszcze tego samego dnia. Rozpatrzenie wniosku o kredyt hipoteczny trwa niestety dłużej. Ile twa rozpatrywanie wniosku w poszczególnych bankach?

## Czesi na zakupy wybierają się do Polski. U nas kupują najtaniej
 - [https://www.money.pl/gospodarka/czesi-na-zakupy-wybieraja-sie-do-polski-u-nas-kupuja-najtaniej-6880981659253536a.html](https://www.money.pl/gospodarka/czesi-na-zakupy-wybieraja-sie-do-polski-u-nas-kupuja-najtaniej-6880981659253536a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-27 14:25:59+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b6944aaf-d875-4032-9df3-50d5c5562ebb" width="308" /> Czeski portal internetowy Seznam Zpravy zwrócił uwagę, że dla Czechów Polska jest najtańszym z sąsiednich państw. Tak wynika z porównania cen podstawowych produktów w przygranicznych sklepach.

## W co opłaca się inwestować w 2023 r.? "Konieczne selektywne podejście"
 - [https://www.money.pl/gielda/gpw-w-co-oplaca-sie-inwestowac-w-2023-r-konieczne-selektywne-podejscie-6880969842563904a.html](https://www.money.pl/gielda/gpw-w-co-oplaca-sie-inwestowac-w-2023-r-konieczne-selektywne-podejscie-6880969842563904a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-27 14:22:41+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/8c9f9962-bf20-4878-beee-01b320f2ac16" width="308" /> Polska gospodarka będzie hamować, jednak na GPW jest nadal sporo atrakcyjnie wycenionych spółek. Konieczne jest jednak selektywne podejście do rynku – ocenili uczestnicy XXX debaty PAP Biznes "Strategie rynkowe TFI". Oto w co – ich zdaniem – opłaca się obecnie inwestować na rynkach.

## Polska może dostać nawet miliard złotych z Brukseli
 - [https://www.money.pl/gospodarka/polska-moze-dostac-nawet-miliard-zlotych-z-brukseli-6880961438862144a.html](https://www.money.pl/gospodarka/polska-moze-dostac-nawet-miliard-zlotych-z-brukseli-6880961438862144a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-27 13:03:31+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/2ef85361-3986-4cb1-b268-ea7d12e1beca" width="308" /> Polska otrzymała już ponad 100 mln zł wsparcia z Europejskiego Instrumentu na rzecz Pokoju, liczymy, że do końca kwietnia do polskiego budżetu może wpłynąć nawet 1 mld zł - powiedział  minister ds. UE Szymon Szynkowski vel Sęk.

## Płacimy około biliona złotych danin. Na co rząd wydaje te pieniądze?
 - [https://www.money.pl/podatki/placimy-okolo-biliona-zlotych-danin-na-co-rzad-wydaje-te-pieniadze-6879587275770656a.html](https://www.money.pl/podatki/placimy-okolo-biliona-zlotych-danin-na-co-rzad-wydaje-te-pieniadze-6879587275770656a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-27 13:00:37+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/7e2cae6d-c292-421c-9fd5-d689d6bf9455" width="308" /> Dodatkowe, wielomiliardowe wpływy podatkowe do budżetu to wynik uszczelnienia systemu i skuteczna walka z przestępcami skarbowymi, a nie podwyżki podatków – przekonuje premier i Ministerstwo Finansów. Na co rząd wydawał te ekstra pieniądze? Do tej pory priorytetem był socjal, ale to się zmienia.

## W Polsce wzrośnie produkcja amunicji. Rząd przyjmie specjalny program
 - [https://www.money.pl/gospodarka/w-polsce-wzrosnie-produkcja-amunicji-rzad-przyjmie-specjalny-program-6880955639503680a.html](https://www.money.pl/gospodarka/w-polsce-wzrosnie-produkcja-amunicji-rzad-przyjmie-specjalny-program-6880955639503680a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-27 12:40:07+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/3d0fe0d5-6f08-40a6-8bf3-f6f45c7c02ac" width="308" /> Rada Ministrów w ciągu kilku najbliższych dni przyjmie specjalny, wieloletni program wspierania produkcji amunicji, w zakładach prywatnych i państwowych. Dzisiaj wiemy, że tej amunicji w całej Europie, a nawet w całym NATO jest zbyt mało - powiedział premier Mateusz Morawiecki.

## Trzeba spieszyć się z wnioskiem o emeryturę. Od kwietnia świadczenia będą niższe
 - [https://www.money.pl/emerytury/emerytury-trzeba-spieszyc-sie-z-wnioskiem-o-emeryture-od-kwietnia-swiadczenia-beda-nizsze-6880938323057472a.html](https://www.money.pl/emerytury/emerytury-trzeba-spieszyc-sie-z-wnioskiem-o-emeryture-od-kwietnia-swiadczenia-beda-nizsze-6880938323057472a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-27 12:12:38+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/606846b3-aabe-48ad-aa36-c8ca4c6df483" width="308" /> ZUS ogłosił, że Polacy będą żyć dłużej. W związku z tym szczególnie muszą uważać ci, którzy właśnie wybierają się na emeryturę. Jeśli nie złożą wniosku w marcu, w kwietniu ZUS wyliczy im niższą kwotę świadczenia. Jak zauważa "Fakt", w grę wchodzi nawet do kilkuset złotych miesięcznie.

## To nie jest dobra informacja dla oszczędzających. Banki obniżają oprocentowania depozytów
 - [https://www.money.pl/banki/to-nie-jest-dobra-informacja-dla-oszczedzajacych-banki-obnizaja-oprocentowania-depozytow-6880947189943072a.html](https://www.money.pl/banki/to-nie-jest-dobra-informacja-dla-oszczedzajacych-banki-obnizaja-oprocentowania-depozytow-6880947189943072a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-27 12:05:38+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/0a263724-195d-46e9-bcca-2a561fa27e20" width="308" /> Marzec to kolejny miesiąc, w którym banki obniżają oprocentowania depozytów - wskazano w najnowszej analizie HRE Investments. Średnie oprocentowanie tych produktów spadło do poziomu 6,99 proc., podczaspodczas gdy w styczniu było to 7,3 proc., a w lutym 7,18 proc.

## Onet: pół miliona rocznie od Orlenu dla spółki kumpla członka zarządu. Koncern reaguje
 - [https://www.money.pl/gospodarka/onet-pol-miliona-rocznie-od-orlenu-dla-spolki-kumpla-czlonka-zarzadu-koncern-reaguje-6880915669711648a.html](https://www.money.pl/gospodarka/onet-pol-miliona-rocznie-od-orlenu-dla-spolki-kumpla-czlonka-zarzadu-koncern-reaguje-6880915669711648a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-27 11:17:28+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/7f3e4902-05b7-4461-b186-5a3c00cd7b26" width="308" /> Do pół miliona zł rocznie zobowiązał się płacić PKN Orlen spółce Publicon za obsługę swoich mediów społecznościowych – opisuje portal Onet.pl, który dotarł do umowy obu firm. Przedstawiciele branży PR mówią o "bardziej niż przyzwoitej" stawce, a źródła portalu sugerują, że tą sprawą interesuje się NIK.

## Rząd uruchomi specjalną stronę internetową z cenami transakcyjnymi   mieszkań
 - [https://www.money.pl/gospodarka/rzad-uruchomi-specjalna-strone-internetowa-z-cenami-transakcyjnymi-mieszkan-6880934149147456a.html](https://www.money.pl/gospodarka/rzad-uruchomi-specjalna-strone-internetowa-z-cenami-transakcyjnymi-mieszkan-6880934149147456a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-27 11:12:40+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/9735ec6d-9e1d-4a35-a951-b43492bcf279" width="308" /> Z początkiem 2024 r. uruchomimy stronę internetową z przejrzystym podglądem cen transakcyjnych mieszkań z podziałem na miejscowość, dzielnicę i metraż - zapowiedział w poniedziałek w studiu PAP minister rozwoju i technologii Waldemar Buda.

## Różne ceny tego samego produktu w dwóch Biedronkach. Sieć się tłumaczy
 - [https://www.money.pl/gospodarka/rozne-ceny-tego-samego-produktu-w-dwoch-biedronkach-siec-sie-tlumaczy-6880925451352864a.html](https://www.money.pl/gospodarka/rozne-ceny-tego-samego-produktu-w-dwoch-biedronkach-siec-sie-tlumaczy-6880925451352864a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-27 10:37:15+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/97e7686d-021b-4aab-aa00-a19856f97292" width="308" /> Klienci Biedronki odnotowują, że te same produkty mogą różnić się ceną w dwóch innych sklepach na terenie jednego miasta. Podają przykłady, gdzie i w jakiej cenie znaleźli dany artykuł. Głos w tej sprawie zabrała już sama sieć. Wytłumaczyła, skąd mogą się brać różnice w cenach.

## Od kwietnia emerytury będą niższe. GUS pokazał nowe "tablice trwania życia"
 - [https://www.money.pl/pieniadze/od-kwietnia-emerytury-beda-nizsze-gus-pokazal-nowe-tablice-trwania-zycia-6880904460061504a.html](https://www.money.pl/pieniadze/od-kwietnia-emerytury-beda-nizsze-gus-pokazal-nowe-tablice-trwania-zycia-6880904460061504a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-27 09:32:48+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/7b9709a2-a09a-4421-ab57-cfad662ab73d" width="308" /> Najnowsze tablice GUS-u nie są korzystne dla emerytów. Świadczenia przyznawane od kwietnia będą niższe o 6-6,6 proc. Tablice średniego trwania dalszego życia służą ZUS-owi do obliczania wysokości świadczenia.

## Nagły zwrot ws. upadłego Sillicon Valley Bank. "Temat kryzysu nadal się tli"
 - [https://www.money.pl/gielda/nagly-zwrot-ws-upadlego-sillicon-valley-bank-temat-kryzysu-nadal-sie-tli-6880884050053952a.html](https://www.money.pl/gielda/nagly-zwrot-ws-upadlego-sillicon-valley-bank-temat-kryzysu-nadal-sie-tli-6880884050053952a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-27 08:07:57+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/5479aee2-d9ff-4529-87ce-44bd0b4a5227" width="308" /> First Citizens odkupi część aktywów upadłego SVB. Z kolei szef Saudyjskiego Banku Narodowego, jednego z głównych udziałowców Credit Suisse, złożył w poniedziałek rano dymisję. – Temat kryzysu bankowego nadal się tli, ale to żarzące się węgielki – komentuje Przemysław Kwiecień z XTB.

## Marketing automation – jakie to ma zastosowanie?
 - [https://www.money.pl/gospodarka/marketing-automation-jakie-to-ma-zastosowanie-6880886706858816a.html](https://www.money.pl/gospodarka/marketing-automation-jakie-to-ma-zastosowanie-6880886706858816a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-27 07:59:37+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/58e157f0-4498-48b3-9b63-f0f7be37b24d" width="308" /> Prowadzenie działań marketingowych w dzisiejszych czasach jest ułatwione dzięki nowoczesnym technologiom. Najlepszym tego przykładem jest marketing automation. Co to jest? Zobacz, gdzie ma zastosowanie i jakie korzyści może przynieść przedsiębiorstwu.

## Coraz mniej osób biednych w Polsce. Rośnie klasa średnia
 - [https://www.money.pl/podatki/coraz-mniej-osob-biednych-w-polsce-rosnie-grupa-klasy-sredniej-6880861620087616a.html](https://www.money.pl/podatki/coraz-mniej-osob-biednych-w-polsce-rosnie-grupa-klasy-sredniej-6880861620087616a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-27 06:17:29+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/9e1ef370-96b6-4dbb-ac6a-31c14443d740" width="308" /> W ciągu czterech ostatnich lat wzrosła liczba osób najbogatszych deklarujących dochody powyżej 1 mln zł. Co ciekawe, z danych wynika także, że Polacy nie zbiednieli w trakcie pandemii – podaje "Dziennik Gazeta Prawna".

## Kursy walut 27.03.2023. Poniedziałkowy kurs funta, euro, dolara i franka szwajcarskiego
 - [https://www.money.pl/pieniadze/kursy-walut-27-03-2023-poniedzialkowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6880851561720640a.html](https://www.money.pl/pieniadze/kursy-walut-27-03-2023-poniedzialkowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6880851561720640a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-27 05:36:29+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/f25df134-ca5f-469f-b693-7773e001842b" width="308" /> Kursy walut - 27.03.2023. We wtorek za jednego dolara (USD) zapłacimy 4.3560 zł. Cena jednego funta szterlinga (GBP) to 5.3302 zł, a franka szwajcarskiego (CHF) 4.7423 zł. Z kolei euro (EUR) możemy zakupić za 4.6899 zł.

## 14. emerytury już na stałe, ale na niższym poziomie. PiS zapomniało o swojej obietnicy
 - [https://www.money.pl/emerytury/14-emerytury-juz-na-stale-ale-na-nizszym-poziomie-pis-zapomnialo-o-swojej-obietnicy-6880848157371168a.html](https://www.money.pl/emerytury/14-emerytury-juz-na-stale-ale-na-nizszym-poziomie-pis-zapomnialo-o-swojej-obietnicy-6880848157371168a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-27 05:22:44+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/50779d69-9524-46d0-9dcb-05cb1666aadd" width="308" /> 14. emerytury będą już na stałe. To zakłada projekt ustawy przygotowany przez Ministerstwo Rodziny i Polityki Społecznej. Jednak Prawo i Sprawiedliwość zapomniało o jednej obietnicy. A przez to spora grupa seniorów otrzyma zaniżone świadczenia. Inni natomiast nie dostaną ich wcale – pisze "Fakt".

## Ile kosztuje dolar? Kurs dolara do złotego PLN/USD 27.03.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-27-03-2023-6880842884725568a.html](https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-27-03-2023-6880842884725568a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-27 05:01:24+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e0ba71a8-9c02-482d-85dd-ebac5362ee3b" width="308" /> Kurs dolara - 27.03.2023. W poniedziałek za jednego dolara (USD) trzeba zapłacić 4.3528 zł.

## Ile kosztuje funt? Kurs funta do złotego PLN/GBP 27.03.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-27-03-2023-6880842884553504a.html](https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-27-03-2023-6880842884553504a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-27 05:01:24+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c374eefc-9e8b-424a-aaa7-91759b47d116" width="308" /> Kurs funta szterlinga - 27.03.2023. W poniedziałek za jednego funta brytyjskiego (GBP) trzeba zapłacić 5.3269 zł.

## Ile kosztuje euro? Kurs euro do złotego PLN/EUR 27.03.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-27-03-2023-6880842869939008a.html](https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-27-03-2023-6880842869939008a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-27 05:01:20+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cf3a8300-d9c9-461f-9fbc-2f314332a28c" width="308" /> Kurs euro - 27.03.2023. W poniedziałek za jedno euro (EUR) trzeba zapłacić 4.6873 zł.

## Ile kosztuje frank szwajcarski? Kurs franka do złotego PLN/CHF 27.03.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-27-03-2023-6880842870123328a.html](https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-27-03-2023-6880842870123328a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-03-27 05:01:20+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b1c04e3f-7bce-4c35-b03c-7a8d7b0adc65" width="308" /> Kurs franka szwajcarskiego - 27.03.2023. W poniedziałek za jednego franka (CHF) trzeba zapłacić 4.7382 zł.

