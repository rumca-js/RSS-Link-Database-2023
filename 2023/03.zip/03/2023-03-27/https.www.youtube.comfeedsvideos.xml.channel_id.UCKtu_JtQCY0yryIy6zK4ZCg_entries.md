# Source:Marc Brunet, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCKtu_JtQCY0yryIy6zK4ZCg, language:en-US

## 🎨 HOW TO PAINT:  SKIN, METAL, PLASTIC
 - [https://www.youtube.com/watch?v=Mbu4m3CqjTc](https://www.youtube.com/watch?v=Mbu4m3CqjTc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKtu_JtQCY0yryIy6zK4ZCg
 - date published: 2023-03-27 13:30:13+00:00

🎉 15,000 STUDENTS SALE!! Get a MEGA 28% OFF ($154) the ART School for Digital Artists program  🎓 http://cbr.sh/q8zql0 until March 31st 2023 ONLY!!  

Join our epic art community! WE JUST REACHED 15,000 ENROLLED STUDENTS! Nani?!

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

🖌 Get my brushes for FREE here: http://cbr.sh/befto
💻 HOW TO USE THE FREE BRUSHES: https://youtu.be/8EC1Ibda3BI
🖌 Clip Studio Paint MB LENGENDARY Lineart Brush: http://cbr.sh/vb2lt6
🖌 Get my advanced brush set here: http://cbr.sh/btml0

🚀 My Store: https://cubebrush.co/mb
🎨 Practice files download: http://cbr.sh/xsqi64

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

FOLLOW ME ON SOCIAL MEDIA:
✏ Twitter: https://twitter.com/bluefley
📷 Instagram: https://instagram.com/bluefley

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ 


#skintexture  #materials #ARTSchool

