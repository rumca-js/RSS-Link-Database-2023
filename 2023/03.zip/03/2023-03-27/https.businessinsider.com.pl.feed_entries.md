# Source:Business insider, URL:https://businessinsider.com.pl/.feed, language:en-US

## Izrael. Masowe strajki przerwane po przemówieniu premiera Netanjahu
 - [https://businessinsider.com.pl/wiadomosci/masowe-strajki-w-izraelu-przerwane-po-oredziu-premiera/vnvn6t5](https://businessinsider.com.pl/wiadomosci/masowe-strajki-w-izraelu-przerwane-po-oredziu-premiera/vnvn6t5)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 19:29:09+00:00

Związki zawodowe w Izraelu odwołują masowe strajki po orędziu premiera Benjamina Netanjahu, który wstrzymał plany dotyczące kontrowersyjnej reformy. Izrael boryka się z największą od lat falą protestów.

## Miliarder, który uciekł przed reżimem, wrócił do Chin. Pekin ociepla wizerunek?
 - [https://businessinsider.com.pl/wiadomosci/jack-ma-wrocil-do-chin-pekin-ociepla-wizerunek/zlcmgk3](https://businessinsider.com.pl/wiadomosci/jack-ma-wrocil-do-chin-pekin-ociepla-wizerunek/zlcmgk3)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 18:53:47+00:00

Założyciel Alibaba Jack Ma, który naraził się rządowi, wrócił do Chin po długiej nieobecności. Ponowne pojawienie się Ma w przestrzeni publicznej jest wsparciem dla złagodzenia tonu Pekinu wobec biznesu, gdy przywódcy próbują wzmocnić gospodarkę dotkniętą przez trzy lata ograniczeń związanych z COVID-19.

## Nowe źródło wody na Księżycu. To się kiedyś przyda
 - [https://businessinsider.com.pl/technologie/nowe-technologie/znaleziono-nowe-zrodlo-wody-na-ksiezycu-to-sie-kiedys-przyda/wc5n0q3](https://businessinsider.com.pl/technologie/nowe-technologie/znaleziono-nowe-zrodlo-wody-na-ksiezycu-to-sie-kiedys-przyda/wc5n0q3)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 18:01:00+00:00

Chiński łazik Chang'e 5 znalazł mikroskopijne koraliki podczas wiercenia i wydobywania próbek na Księżycu w 2020 r. W tych koralikach jest woda. Według tych badań na Księżycu jest wystarczająco dużo koralików, aby pomieścić równowartość około 270 mln ton wody.

## Przepisy covidowe mogły działać na szkodę podatników? Ważna uchwała NSA
 - [https://businessinsider.com.pl/prawo/podatki/uchwala-nsa-w-sprawie-przepisow-covidowych-co-zyskaja-podatnicy/et80ml6](https://businessinsider.com.pl/prawo/podatki/uchwala-nsa-w-sprawie-przepisow-covidowych-co-zyskaja-podatnicy/et80ml6)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 17:24:26+00:00

Naczelny Sąd Administracyjny rozstrzygnął w poniedziałek bardzo ważną sprawę. Do wczoraj nie było wiadomo, czy zawieszenie w czasie pandemii terminów przedawnienia dotyczyło również spraw podatkowych. Od dziś podatnicy mogą triumfować. Uchwała NSA ma wymierne skutki dla wielu postępowań w sprawach podatkowych.

## Krok ku rozpadowi Wielkiej Brytanii? Szkocja ma nowego lidera
 - [https://businessinsider.com.pl/wiadomosci/krok-ku-rozpadowi-wielkiej-brytanii-oto-nowy-lider-szkocji/4scde9d](https://businessinsider.com.pl/wiadomosci/krok-ku-rozpadowi-wielkiej-brytanii-oto-nowy-lider-szkocji/4scde9d)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 17:20:00+00:00

Humza Yousaf w poniedziałek wygrał wybory na stanowisko nowego lidera proniepodległościowej Szkockiej Partii Narodowej (SNP). Powiedział, że jest zdeterminowany, aby poprowadzić kraj ku niepodległości.

## Tylu Polaków już rozliczyło się przez Twój e-PIT. Resort podaje dane
 - [https://businessinsider.com.pl/twoje-pieniadze/tylu-polakow-juz-rozliczylo-sie-przez-twoj-e-pit-resort-podaje-dane/55t1rqt](https://businessinsider.com.pl/twoje-pieniadze/tylu-polakow-juz-rozliczylo-sie-przez-twoj-e-pit-resort-podaje-dane/55t1rqt)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 16:56:38+00:00

Podatnicy złożyli już ponad 5 mln deklaracji za pośrednictwem usługi Twój e-PIT. Urzędy skarbowe zwróciły im już łącznie ponad 10 mld zł podatku – informuje Ministerstwo Finansów.

## Spacer kobiet z mentorkami i mentorami. Jest rekord
 - [https://businessinsider.com.pl/wiadomosci/spacer-kobiet-z-mentorami-i-mentorkami-jest-rekord/d8wnme3](https://businessinsider.com.pl/wiadomosci/spacer-kobiet-z-mentorami-i-mentorkami-jest-rekord/d8wnme3)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 16:25:55+00:00

Już po raz dwunasty liderzy i liderki ze świata biznesu, dyplomacji, mediów, nauki i kultury spotkali się na spacerze z kobietami z potencjałem przywódczym i szukającymi zawodowej drogi. Do najnowszej edycji "Global Mentoring Walk" zgłosiło się niemal 300 osób.

## Przyjęcie Finlandii do NATO. Węgierski parlament zdecydował
 - [https://businessinsider.com.pl/wiadomosci/przyjecie-finlandii-do-nato-jest-decyzja-wegier/wejs66z](https://businessinsider.com.pl/wiadomosci/przyjecie-finlandii-do-nato-jest-decyzja-wegier/wejs66z)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 16:20:30+00:00

Węgierski parlament zagłosował w poniedziałek za przyjęciem Finlandii do NATO. Wcześniej Budapeszt kilkakrotnie przesuwał datę głosowania. Teraz zielone światło musi dać jeszcze jeden kraj.

## Ambasady Izraela przyłączają się do strajku. "Rząd działa rażąco bezprawnie"
 - [https://businessinsider.com.pl/wiadomosci/w-izraelu-strajkuja-juz-nawet-ambasady-rzad-dziala-razaco-bezprawnie/dr14xmd](https://businessinsider.com.pl/wiadomosci/w-izraelu-strajkuja-juz-nawet-ambasady-rzad-dziala-razaco-bezprawnie/dr14xmd)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 16:10:46+00:00

Próba radykalnego zredukowania roli wyroków Sądu Najwyższego wzbudziła masowe protesty w Izraelu. Do protestu przyłączył się personel dyplomatyczny za granicami kraju. Netanjahu ostatecznie odroczył jednak reformę.

## Ośrodki zapłacą niższy podatek. Pojeździmy taniej na nartach?
 - [https://businessinsider.com.pl/prawo/podatki/podatek-od-wyciagow-narciarskich-od-calosci-czy-czesci-przelomowy-wyrok-nsa/6568ddw](https://businessinsider.com.pl/prawo/podatki/podatek-od-wyciagow-narciarskich-od-calosci-czy-czesci-przelomowy-wyrok-nsa/6568ddw)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 15:59:16+00:00

Korzystanie z białego szaleństwa powinno być przyjemniejsze, a to za sprawą ważnego i korzystnego wyroku Naczelnego Sądu Administracyjnego. W jego efekcie właściciele wyciągów narciarskich zapłacą niższy podatek od nieruchomości, a zaoszczędzone czy odzyskane pieniądze mogą zainwestować w rozbudowę ośrodka.

## Zaskakujące odkrycie. Na Księżycu mogą być "miliardy ton wody"
 - [https://businessinsider.com.pl/wiadomosci/miliardy-ton-wody-na-ksiezycu-oto-co-odkryli-naukowcy/r3hdpgk](https://businessinsider.com.pl/wiadomosci/miliardy-ton-wody-na-ksiezycu-oto-co-odkryli-naukowcy/r3hdpgk)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 15:55:07+00:00

Na Księżycu znajdują się "małe szklane kule", które mogą potencjalnie zawierać nawet miliardy ton wody – ustalili naukowcy. To odkrycie może być przełomem dla przyszłych misji astronautów.

## Nowe prognozy. Bank Światowy ostrzega przed straconą dekadą
 - [https://businessinsider.com.pl/gospodarka/stracona-dekada-przygnebiajace-prognozy-banku-swiatowego/xjggdnp](https://businessinsider.com.pl/gospodarka/stracona-dekada-przygnebiajace-prognozy-banku-swiatowego/xjggdnp)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 15:51:06+00:00

Globalnej gospodarce grozi stracona dekada wzrostu z powodu utrzymujących się skutków pandemii COVID-19 i wojny na Ukrainie — wynika z najnowszego raportu Banku Światowego.

## Wielki boom na kampery u sąsiada. "Berlin zamiast Bahamów"
 - [https://businessinsider.com.pl/wiadomosci/wielki-boom-na-kampery-u-sasiada-berlin-zamiast-bahamow/nrl0tb9](https://businessinsider.com.pl/wiadomosci/wielki-boom-na-kampery-u-sasiada-berlin-zamiast-bahamow/nrl0tb9)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 15:20:03+00:00

W Niemczech trwa wielki boom na ośrodki kempingowe i kampery. Eksperci tłumaczą to na dwa sposoby.

## Kary za brak świadectwa energetycznego. Czy bać się 5 tys. zł grzywny?
 - [https://businessinsider.com.pl/prawo/kara-za-brak-swiadectwa-energetycznego-od-27-kwietnia-komu-grozi/k5fewfk](https://businessinsider.com.pl/prawo/kara-za-brak-swiadectwa-energetycznego-od-27-kwietnia-komu-grozi/k5fewfk)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 15:06:05+00:00

Świadectwo energetyczne robi medialną karierę. Gdzie nie spojrzeć, słychać, że zarabiający na wynajmie muszą je przekazać od 27 kwietnia najemcom. Jeśli nie przekażą, to zapłacą do 5 tys. zł grzywny. W przepisach rzeczywiście pojawi się nowa kara, ale w praktyce będzie trudna do wyegzekwowania. Wyjaśniamy dlaczego.

## Rewolucja na rynku mieszkaniowym. Cena transakcji będzie jawna dla każdego
 - [https://businessinsider.com.pl/gospodarka/ceny-mieszkan-w-transakcji-beda-jawne-dla-kazdego-idzie-rewolucja-na-rynku/1m5tbrx](https://businessinsider.com.pl/gospodarka/ceny-mieszkan-w-transakcji-beda-jawne-dla-kazdego-idzie-rewolucja-na-rynku/1m5tbrx)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 15:01:53+00:00

Dotąd o cenach transakcyjnych mieszkań na rynku można było dowiedzieć się z kilkumiesięcznym opóźnieniem z raportów NBP. Teraz nie dość, że dowiemy się po ile zostało mieszkanie sprzedane w danym mieście, to jeszcze w jakiej dzielnicy o praktycznie na bieżąco. Rząd uruchomi stronę internetową, która pozwoli nam sprawdzić, czy cena w ofercie, którą rozważamy nie jest przypadkiem za wysoka i po jakiej cenie sprzedaje się mieszkania w okolicy.

## Ekspertom zapalają się bezpieczniki. Mówią o pęknięciu "bańki spekulacyjnej na wszystkim"
 - [https://businessinsider.com.pl/gielda/wiadomosci/jest-grozba-pekniecia-banki-spekulacyjnej-na-wszystkim-lepiej-uwazac/vsq1gcv](https://businessinsider.com.pl/gielda/wiadomosci/jest-grozba-pekniecia-banki-spekulacyjnej-na-wszystkim-lepiej-uwazac/vsq1gcv)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 14:38:32+00:00

Eksperci funduszy inwestycyjnych debatowali w poniedziałek na temat obecnej, trudnej sytuacji na rynkach finansowych m.in. w kontekście kryzysu bankowego. Przyznają, że znowu doszło do zderzenia ze ścianą, a rynki są na rozstaju dróg. Przyszłość nie rysuje się w najjaśniejszych barwach, choć są "przechowalnie kapitału", które dają szanse na zarobek.

## Koniec zagrożenia epidemicznego oznacza powrót starego prawa. O tych rzeczach dobrze pamiętać
 - [https://businessinsider.com.pl/prawo/koniec-zagrozenia-epidemicznego-wraca-stare-prawo-o-tych-rzeczach-dobrze-pamietac/zkbvl0f](https://businessinsider.com.pl/prawo/koniec-zagrozenia-epidemicznego-wraca-stare-prawo-o-tych-rzeczach-dobrze-pamietac/zkbvl0f)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 14:18:42+00:00

Stan zagrożenia epidemicznego trwa już tylko do końca marca. Być może będzie przedłużony o miesiąc, ale pracodawcy już muszą się szykować na powrót prawa sprzed ustaw covidowych.

## Czescy dziennikarze na zakupach w Polsce. Zaskoczeni cenami i... tablicami rejestracyjnymi
 - [https://businessinsider.com.pl/gospodarka/czescy-dziennikarze-na-zakupach-w-polsce-zaskoczeni-nie-tylko-cenami/8p24zgz](https://businessinsider.com.pl/gospodarka/czescy-dziennikarze-na-zakupach-w-polsce-zaskoczeni-nie-tylko-cenami/8p24zgz)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 14:03:02+00:00

Dla Czechów Polska jest najtańszym z sąsiednich państw – wynika z artykułu znanego serwisu seznamzpravy.cz. Redaktorzy byli zresztą zaskoczeni nie tylko cenami.

## Tyle Polacy planują wydać w tym roku na Wielkanoc
 - [https://businessinsider.com.pl/twoje-pieniadze/tyle-wydamy-w-tym-roku-na-swieta-wielkanocne/clwgdzh](https://businessinsider.com.pl/twoje-pieniadze/tyle-wydamy-w-tym-roku-na-swieta-wielkanocne/clwgdzh)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 13:34:58+00:00

W tym roku Polacy planują przeznaczyć średnio 599 zł na święta wielkanocne. To znacznie więcej niż przed rokiem. Z analizy wynika też, że niezależnie od cen nie wyobrażamy sobie Wielkanocy bez jajek.

## Goldman Sachs nie widzi szans na zmiany upragnione przez miliony Polaków
 - [https://businessinsider.com.pl/gospodarka/znaczaco-nizsze-raty-w-2023-r-oni-twierdza-ze-nie-ma-szans/n2xe78h](https://businessinsider.com.pl/gospodarka/znaczaco-nizsze-raty-w-2023-r-oni-twierdza-ze-nie-ma-szans/n2xe78h)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 13:31:41+00:00

Ekonomiści są dość zgodni. Szczyt inflacji w Europie Środkowo-Wschodniej jest raczej za nami i powinno być lepiej. Niestety tegoroczna ścieżka zmian cen w regionie nie daje możliwości obniżek stóp procentowych w 2023 r., wyczekiwanych m.in. przez Polaków spłacających kredyty. Tak przynajmniej twierdzą analitycy Goldman Sachs. Wskazują na wciąż uporczywą inflację bazową.

## Nielegalne dokarmianie ptaków. Oto co grozi "przestępcom"
 - [https://businessinsider.com.pl/prawo/nielegalne-dokarmianie-ptakow-co-grozi-przestepcom/63nxzs7](https://businessinsider.com.pl/prawo/nielegalne-dokarmianie-ptakow-co-grozi-przestepcom/63nxzs7)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 13:01:44+00:00

"Zakaz karmienia gołębi pod karą grzywny". Taki napis coraz częściej można spotkać na naszych osiedlach, a nawet w witrynach sklepów. Strażnicy miejscy zdarza się, że wystawiają mandaty. Grozi nawet do 500 zł. Kwestia w tym, czy mają podstawy prawne do interwencji? A to nie jest takie oczywiste.

## Znalazł się kupiec na Silicon Valley Bank
 - [https://businessinsider.com.pl/gospodarka/wiadomo-kto-kupi-upadly-silicon-valley-bank/bz2gblv](https://businessinsider.com.pl/gospodarka/wiadomo-kto-kupi-upadly-silicon-valley-bank/bz2gblv)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 13:01:35+00:00

First Citizens BancShares, do której należy m.in. First Citizens Bank, zgodziła się na zakup Silicon Valley Bank — wynika z oświadczenia amerykańskich władz federalnych.

## Nowe prognozy dla świata. Liczba ludności gwałtownie spadnie
 - [https://businessinsider.com.pl/wiadomosci/nowe-prognozy-dla-swiata-jednak-bedzie-nas-miliard-mniej/5cskv2s](https://businessinsider.com.pl/wiadomosci/nowe-prognozy-dla-swiata-jednak-bedzie-nas-miliard-mniej/5cskv2s)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 12:59:38+00:00

Liczba ludności na świecie osiągnie najwyższy poziom — 8,8 mld — szybciej, niż zakładano, ale będzie on niższy od wcześniejszych prognoz. Następnie liczba ludności gwałtownie spadnie — wynika z opublikowanego w poniedziałek raportu Klubu Rzymskiego. Eksperci kreślą dwa scenariusze — bardziej i mniej obciążający dla środowiska.

## Niespodziewana poprawa nastrojów w Niemczech. "Nie są oparte na niczym więcej niż nadziei"
 - [https://businessinsider.com.pl/gospodarka/deutsche-bank-w-tarapatach-a-nastroje-w-niemczech-sie-poprawiaja-jest-nadzieja/yynsftl](https://businessinsider.com.pl/gospodarka/deutsche-bank-w-tarapatach-a-nastroje-w-niemczech-sie-poprawiaja-jest-nadzieja/yynsftl)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 12:51:33+00:00

Od kilku miesięcy systematycznie poprawiają się nastroje w niemieckich firmach, mierzone indeksem Ifo. Klaus Wohlrabe sugeruje, że niemiecka gospodarka rozpoczyna wiosnę z dobrym samopoczuciem. Większy sceptycyzm bije od analityków. Oceniają, że klimat biznesowy nie jest jeszcze oparty na niczym więcej niż nadziei.

## Nowy ranking popularności lornetek — aż dwa pentaxy
 - [https://businessinsider.com.pl/technologie/nowy-ranking-popularnosci-lornetek-az-dwa-pentaxy/63fgxj9](https://businessinsider.com.pl/technologie/nowy-ranking-popularnosci-lornetek-az-dwa-pentaxy/63fgxj9)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 12:31:00+00:00

W porównaniu do poprzedniego rankingu popularności lornetki, w najnowszym mamy kilka zmian. Do pierwszej piątki przebojem wdarły się dwa modele Pentaxa, a jeden z nich został nawet zwycięzcą. Dane na temat popularności pochodzą z internetowej porównywarki cen Skąpiec.pl.

## Nie tylko Amazon. Kolejna wielka sieć handlowa zwolni setki pracowników
 - [https://businessinsider.com.pl/wiadomosci/juz-nie-tylko-amazon-kolejna-wielka-siec-handlowa-zwolni-setki-pracownikow/2n29h15](https://businessinsider.com.pl/wiadomosci/juz-nie-tylko-amazon-kolejna-wielka-siec-handlowa-zwolni-setki-pracownikow/2n29h15)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 12:30:09+00:00

Największy amerykański prywatny pracodawca i lider handlu internetowego ogłosił zamiar zwolnienia kilkuset pracowników. Sieć Walmart przewiduje spadek zainteresowania zakupami online w najbliższej przyszłości i chce "lepiej przygotować się na przyszłe potrzeby klientów".

## Firma Solorza jednoznacznie o przejęciu ukraińskiego banku [TYLKO U NAS]
 - [https://businessinsider.com.pl/gospodarka/firma-solorza-jednoznacznie-o-przejeciu-ukrainskiego-banku/t1q4b67](https://businessinsider.com.pl/gospodarka/firma-solorza-jednoznacznie-o-przejeciu-ukrainskiego-banku/t1q4b67)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 12:16:51+00:00

Grupa Polsat Plus i żadna ze spółek Grupy Polsat Plus nie ma z kwestią inwestycji w Sense Bank nic wspólnego – mówi Business Insiderowi rzecznik Grupy Tomasz Matwiejczuk. Wcześniej ukraińskie media sugerowały, że polski przedsiębiorca jest zainteresowany taką inwestycją.

## Deutsche Bank opuszcza siedzibę w Londynie. Nowy inwestor na przebudowę wyda 1 mld funtów
 - [https://businessinsider.com.pl/finanse/deutsche-bank-opuszcza-siedzibe-w-londynie-nowy-inwestor-wyda-1-mld-funtow/jlekkz5](https://businessinsider.com.pl/finanse/deutsche-bank-opuszcza-siedzibe-w-londynie-nowy-inwestor-wyda-1-mld-funtow/jlekkz5)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 12:03:00+00:00

Siedziba Deutsche Bank w londyńskim City została sprzedana brytyjskim i malezyjskim inwestorom. Jak opisuje "Financial Times", planują przebudowę o wartości 1 mld funtów w związku z przeniesieniem się banku do nowej siedziby.

## Konkurent Rossmanna się rozkręca. Tam będą nowe sklepy
 - [https://businessinsider.com.pl/gospodarka/konkurent-rossmanna-sie-rozkreca-tam-beda-nowe-sklepy/vbt0s27](https://businessinsider.com.pl/gospodarka/konkurent-rossmanna-sie-rozkreca-tam-beda-nowe-sklepy/vbt0s27)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 11:58:58+00:00

Sieć dm będzie miała już niebawem 13 punktów w Polsce i 4 tys. w całej Europie – podaje firma w komunikacie. Firma się zatem rozwija, choć ciągle daleko jej do głównego konkurenta.

## Temat kryzysu bankowego nadal się tli. Byle z dala od benzyny
 - [https://businessinsider.com.pl/gielda/wiadomosci/akcje-bankow-odrabiaja-straty-najgorsze-juz-za-nami/d2zb3hv](https://businessinsider.com.pl/gielda/wiadomosci/akcje-bankow-odrabiaja-straty-najgorsze-juz-za-nami/d2zb3hv)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 11:55:58+00:00

Obawy o kondycję Deutsche Banku chwilowo przygasły. Notowania akcji niemieckiego giganta odrabiają wcześniejsze straty. Ulgę mogą poczuć też posiadacze akcji innych największych banków Europy, a także inwestorzy z warszawskiej giełdy. Ekonomista XTB porównuje aktualną sytuację do żarzących się węgielków. Pożar więc ciągle nie jest w pełni ugaszony.

## Cięcie lokat postępuje. Tak dziś wygląda "dobre" oprocentowanie
 - [https://businessinsider.com.pl/poradnik-finansowy/oszczedzanie/ciecie-lokat-postepuje-tak-dzis-wyglada-dobre-oprocentowanie/h36x98k](https://businessinsider.com.pl/poradnik-finansowy/oszczedzanie/ciecie-lokat-postepuje-tak-dzis-wyglada-dobre-oprocentowanie/h36x98k)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 11:51:36+00:00

Marzec to kolejny miesiąc, w którym banki obniżają oprocentowania depozytów — wskazano w opublikowanej w poniedziałek analizie HRE Investments. Średnie oprocentowanie tych produktów spadło do poziomu 6,99 proc., podczas gdy w styczniu było to 7,3 proc., a w lutym 7,18 proc.

## Rząd wprowadzi specjalny program. Chodzi o większe wydatki na wojsko
 - [https://businessinsider.com.pl/gospodarka/rzad-wprowadzi-specjalny-program-chce-wiecej-wydawac-na-wojsko/bgxckk7](https://businessinsider.com.pl/gospodarka/rzad-wprowadzi-specjalny-program-chce-wiecej-wydawac-na-wojsko/bgxckk7)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 11:41:25+00:00

Rada Ministrów w ciągu kilku dni przyjmie specjalny wieloletni program, który będzie wspierał produkcję amunicji w różnych częściach kraju, w firmach prywatnych i państwowych - poinformował premier Mateusz Morawiecki.

## Marcowy ranking najpopularniejszych wideorejestratorów
 - [https://businessinsider.com.pl/technologie/marcowy-ranking-najpopularniejszych-wideorejestratorow/xxm0lwc](https://businessinsider.com.pl/technologie/marcowy-ranking-najpopularniejszych-wideorejestratorow/xxm0lwc)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 11:31:00+00:00

Wideorejestrator to niezwykle przydatne urządzenie w każdym samochodzie. Może ustrzec cię przed oszustami, bo w razie kolizji nagra całe zdarzenie. Niektóre modele mają też funkcję monitoringu podczas postoju. Sprawdź najnowszy ranking popularności wideorejestratorów według Skąpiec.pl.

## Skutki protestów w Izraelu. Dwa największe banki w tym kraju przestają działać
 - [https://businessinsider.com.pl/gospodarka/protesty-w-izraelu-dwa-najwieksze-banki-w-tym-kraju-przestaja-dzialac/nclpvfh](https://businessinsider.com.pl/gospodarka/protesty-w-izraelu-dwa-najwieksze-banki-w-tym-kraju-przestaja-dzialac/nclpvfh)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 11:20:57+00:00

Jak podaje "Financial Times", protesty w Izraelu mogą sparaliżować tamtejszy system bankowy. Z powodu strajków przestać działać mogą oddziały dwóch największych banków w kraju.

## Wcześniejsze emerytury dla nauczycieli. Chyba głodowe
 - [https://businessinsider.com.pl/prawo/praca/wczesniejsze-emerytury-dla-nauczycieli-chyba-glodowe/79btsmw](https://businessinsider.com.pl/prawo/praca/wczesniejsze-emerytury-dla-nauczycieli-chyba-glodowe/79btsmw)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 11:15:02+00:00

Projekt przywracający emerytury nauczycielskie jest na końcowym etapie prac – poinformował w czwartek minister edukacji i nauki Przemysław Czarnek. Stwierdził, że projekt wypracowywany jest wspólnie ze związkami zawodowymi. Serwis portalsamorzadowy.pl postanowił powiedzieć "sprawdzam" i odpytał związkowców o ich obawy odnośnie do nowych przepisów. Dominują czarne myśli.

## Miliony euro dla polskich rolników. Bruksela zatwierdza program
 - [https://businessinsider.com.pl/gospodarka/bruksela-da-miliony-na-polskich-rolnikow/mt2jc9q](https://businessinsider.com.pl/gospodarka/bruksela-da-miliony-na-polskich-rolnikow/mt2jc9q)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 11:04:29+00:00

Komisja Europejska zatwierdziła nowy program dla polskich rolników. Jego celem jest wsparcie sektora produkcji pszenicy i kukurydzy w kontekście wojny Rosji z Ukrainą – przekazał komisarz Janusz Wojciechowski.

## Wojna i inflacja zamroziły transakcje na rynku PE. Ekspert liczy na odwilż
 - [https://businessinsider.com.pl/biznes/skutki-wojny-i-inflacji-na-rynku-transakcje-zostaly-zamrozone/y6dfvb8](https://businessinsider.com.pl/biznes/skutki-wojny-i-inflacji-na-rynku-transakcje-zostaly-zamrozone/y6dfvb8)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 10:54:56+00:00

Niepewność rynkowa, związana z wojną na Ukrainie i wysoką inflacją, przekłada się na zamrożenie transakcji na rynku private equity. Jednak drugie półrocze powinno przynieść ożywienie, być może przy niższych wycenach — prognozuje Paweł Szreder z Bain &amp; Company.

## Nowy bat na deweloperów i sprzedawców mieszkań. Minister zdradził szczegóły
 - [https://businessinsider.com.pl/nieruchomosci/nowy-bat-na-deweloperow-i-sprzedawcow-mieszkan-koniec-ukrywania-cen/6y7xlpj](https://businessinsider.com.pl/nieruchomosci/nowy-bat-na-deweloperow-i-sprzedawcow-mieszkan-koniec-ukrywania-cen/6y7xlpj)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 10:52:52+00:00

Polacy mają zyskać darmowy dostęp do danych o rzeczywistych cenach mieszkań, jakiego jeszcze nie mieli. — Z początkiem 2024 r. uruchomimy stronę internetową z przejrzystym podglądem cen transakcyjnych mieszkań z podziałem na miejscowość, dzielnicę i metraż — zapowiedział w poniedziałek w Studiu PAP minister rozwoju i technologii Waldemar Buda.

## Dwie licealistki twierdzą, że znalazły dowód na twierdzenie Pitagorasa. Matematycy myśleli, że to niemożliwe
 - [https://businessinsider.com.pl/wiadomosci/dwie-licealistki-twierdza-ze-znalazly-dowod-na-twierdzenie-pitagorasa-matematycy/7b9sb3l](https://businessinsider.com.pl/wiadomosci/dwie-licealistki-twierdza-ze-znalazly-dowod-na-twierdzenie-pitagorasa-matematycy/7b9sb3l)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 10:25:46+00:00

Dwie licealistki są przekonane, że mają dowód na twierdzenie Pitagorasa. Ich wnioski są obiecujące, ale do tej pory nie przeszły przez rygorystyczny proces akademickiej recenzji ani nie zostały potwierdzone przez innych ekspertów w tej dziedzinie.

## Musk maile w nocy pisze. Chodzi o puste biura
 - [https://businessinsider.com.pl/gospodarka/musk-przypomina-o-sobie-pracownikom-w-srodku-nocy/087ph8h](https://businessinsider.com.pl/gospodarka/musk-przypomina-o-sobie-pracownikom-w-srodku-nocy/087ph8h)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 10:24:38+00:00

Elon Musk w środku nocy wysłał e-maila do pracowników Twittera. Przypomniał w nich, że praca w biurze nie jest opcjonalna.

## Tąpnięcie w meblarstwie. Branża ma katastroficzną wizję
 - [https://businessinsider.com.pl/wiadomosci/tapniecie-w-branzy-meblarskiej-ponad-100-mln-zl-zadluzenia/5ckel5s](https://businessinsider.com.pl/wiadomosci/tapniecie-w-branzy-meblarskiej-ponad-100-mln-zl-zadluzenia/5ckel5s)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 10:08:27+00:00

Sytuacja w polskim meblarstwie jest coraz gorsza. Zadłużenie branży wzrosło do ponad 100 mln zł, wzrost przychodów w 2022 r. "zjadła" inflacja, zapowiada się spadek wartości produkcji sprzedanej i możliwa fala zwolnień. Kłopoty meblarzy zaczęły się już kilka lat temu, podczas pandemii.

## To już nie Ukraińcy najczęściej jeżdżą do Polski. Są nowe dane
 - [https://businessinsider.com.pl/wiadomosci/kto-najczesciej-jezdzi-do-polski-sa-nowe-dane/zc72tbk](https://businessinsider.com.pl/wiadomosci/kto-najczesciej-jezdzi-do-polski-sa-nowe-dane/zc72tbk)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 09:54:44+00:00

Najwięcej osób, które w styczniu skorzystało z polskiej bazy noclegowej, stanowili Niemcy. Na drugim miejscu znaleźli się Ukraińcy.

## Niemiecki gigant chce przejąć polską firmę. Błyskawicznie wskoczyła na szczyt notowań
 - [https://businessinsider.com.pl/gielda/wiadomosci/polska-firma-na-celowniku-niemieckiego-giganta-z-marszu-stala-sie-gwiazda-gieldy/dnp592y](https://businessinsider.com.pl/gielda/wiadomosci/polska-firma-na-celowniku-niemieckiego-giganta-z-marszu-stala-sie-gwiazda-gieldy/dnp592y)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 09:53:51+00:00

Informacja o planach przejęcia polskiej firmy przez niemieckiego konkurenta wywołała błyskawiczną reakcję na warszawskiej giełdzie. Notowania akcji skoczyły do poziomów niewidzianych od 2007 r. W efekcie rynkowa wycena biznesu TIM przekroczyła 1 mld zł. Prezes Krzysztof Folta mówi o kamieniu milowym w rozwoju.

## Wyścig dyskontów w Polsce. Biedronka komentuje ruchy Dino
 - [https://businessinsider.com.pl/firmy/wyscig-dyskontow-w-polsce-biedronka-komentuje-ruchy-dino/tng1xzv](https://businessinsider.com.pl/firmy/wyscig-dyskontow-w-polsce-biedronka-komentuje-ruchy-dino/tng1xzv)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 09:51:49+00:00

Choć królową dyskontów pod względem liczby sklepów w Polsce jest Biedronka, to już na miano króla wsi bardziej zasługuje Dino. Szefostwo Biedronki ruchy konkurencji dostrzega i szanuje, ale nie zamierza iść jego drogą.

## Pięć laptopów za mniej niż 1,5 tys. zł — czy warto je kupić?
 - [https://businessinsider.com.pl/technologie/piec-laptopow-za-mniej-niz-15-tys-zl-czy-warto-je-kupic/klmnhvx](https://businessinsider.com.pl/technologie/piec-laptopow-za-mniej-niz-15-tys-zl-czy-warto-je-kupic/klmnhvx)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 09:40:00+00:00

Laptop w cenie smartfona ze średniej półki? To możliwe, a wybór jest całkiem spory. Wybraliśmy pięć ciekawych modeli w cenie od 1,2 do 1,5 tys. zł. Wśród nich znalazł się Chromebook, na którego warto zwrócić uwagę, szukając taniego laptopa.

## Ukraińscy rolnicy sami rozminowują pola. "Śmiertelne zagrożenie"
 - [https://businessinsider.com.pl/wiadomosci/ukrainscy-rolnicy-musza-sami-rozminowywac-pola-nie-moga-dluzej-czekac/0crbe9d](https://businessinsider.com.pl/wiadomosci/ukrainscy-rolnicy-musza-sami-rozminowywac-pola-nie-moga-dluzej-czekac/0crbe9d)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 09:39:03+00:00

Ukraińscy rolnicy, którzy powrócili w rodzinne strony, wyzwolone jesienią ubiegłego roku spod rosyjskiej okupacji, własnoręcznie rozminowują swoje pola – opisuje CNN. Jest to niezwykle ryzykowne, ale często Ukraińcy mówią, że nie mają alternatywy

## Egipt, Kenia lub RPA — zaplanuj wakacje w Afryce
 - [https://businessinsider.com.pl/lifestyle/podroze/egipt-kenia-lub-rpa-zaplanuj-wakacje-w-afryce/gbbrfg5](https://businessinsider.com.pl/lifestyle/podroze/egipt-kenia-lub-rpa-zaplanuj-wakacje-w-afryce/gbbrfg5)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 09:29:00+00:00

Przenikanie się społeczności, kultur, języków, kolorów, dźwięków i zwyczajów to cechy charakterystyczne dla krajów afrykańskich. Każdy, kto wybiera się na urlop do Afryki, może liczyć na słoneczną pogodę, piaszczyste plaże, piękne krajobrazy oraz wiele przygód i atrakcji. Kenia, Egipt i RPA to popularne kierunki turystyczne, pozwalające na wypoczynek w słońcu i wiele niesamowitych przygód. Kraje afrykańskie od lat przyciągają turystów dobrą pogodą, wysokim standardem usług hotelowych, dziką przyrodą i cenami, które nie są szczególnie wygórowane dla Europejczyków. W artykule polecamy sprawdzone i docenione przez klientów wycieczki biura podróży Albatros. Biuro podróży Albatros już od wielu lat specjalizuje się w wycieczkach objazdowych po Kenii, Egipcie i RPA. Zapraszamy!

## Szpiegował dla Rosji. Polskie służby znów w akcji
 - [https://businessinsider.com.pl/wiadomosci/szpiegowal-dla-rosji-polskie-sluzby-znow-w-akcji/7q69mky](https://businessinsider.com.pl/wiadomosci/szpiegowal-dla-rosji-polskie-sluzby-znow-w-akcji/7q69mky)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 09:22:47+00:00

Służba Kontrwywiadu Wojskowego podała, że zidentyfikowała kolejną osobę, która działała rzecz wywiadu rosyjskiego. Mężczyzna przyznał się do winy.

## Rosjanie narzekają, ale i tak kupują. "Nie są gorsze od mercedesa"
 - [https://businessinsider.com.pl/wiadomosci/rosjanie-narzekaja-ale-i-tak-kupuja-nie-sa-gorsze-od-mercedesa/cvbr2bw](https://businessinsider.com.pl/wiadomosci/rosjanie-narzekaja-ale-i-tak-kupuja-nie-sa-gorsze-od-mercedesa/cvbr2bw)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 09:22:36+00:00

Rosjanie mają coraz mniejsze pole wyboru samochodów dostępnych na tamtejszym rynku. Masowe wyjście zachodnich producentów samochodów pozostawia na rosyjskim rynku lukę, którą szybko wypełniają chińskie auta — pisze agencja Reutera. To jednak niejedyna przyczyna przejmowania rynku motoryzacyjnego przez Chińczyków.

## Ukraińcy opanowali obsługę kolejnego rodzaju czołgów. Tak wyglądało szkolenie [WIDEO]
 - [https://businessinsider.com.pl/gospodarka/ukraincy-obsluguja-kolejne-czolgi-tak-wygladalo-szkolenie-wideo/zweegch](https://businessinsider.com.pl/gospodarka/ukraincy-obsluguja-kolejne-czolgi-tak-wygladalo-szkolenie-wideo/zweegch)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 08:54:01+00:00

Jak przekazało w poniedziałek brytyjskie ministerstwo obrony, ukraińskie załogi zakończyły szkolenia na przekazywanych przez Wielką Brytanię czołgach Challenger 2 i wróciły do kraju, aby kontynuować walkę z rosyjską inwazją.

## Ogromny wzrost ruchu na granicy z Polską. Wydatki cudzoziemców liczone w dziesiątkach miliardów
 - [https://businessinsider.com.pl/gospodarka/ruch-na-granicy-z-polska-mocno-wzrosl-jest-z-tego-duzy-pozytek/7kngsyn](https://businessinsider.com.pl/gospodarka/ruch-na-granicy-z-polska-mocno-wzrosl-jest-z-tego-duzy-pozytek/7kngsyn)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 08:53:40+00:00

W ubiegłym roku cudzoziemcy przekraczali naszą granicę o ponad 40 proc. częściej. Jeszcze szybciej rosła kwota pieniędzy, jakie zostawiali w Polsce. W sumie to ponad 37 mld zł. Ciągle znacznie większy ruch był na zachodniej granicy.

## Nowa kampania reklamowa z reprezentacją Polski bez Lewandowskiego. "Powoli schodzi z rynku"
 - [https://businessinsider.com.pl/firmy/nowa-kampania-reklamowa-z-reprezentacja-polski-zabraknie-lewandowskiego/gvzndzt](https://businessinsider.com.pl/firmy/nowa-kampania-reklamowa-z-reprezentacja-polski-zabraknie-lewandowskiego/gvzndzt)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 08:33:16+00:00

Jak opisuje portal Wirtualnemedia.pl, InPost już wkrótce ruszy z kampanią reklamową z udziałem piłkarzy reprezentacji Polski w piłce nożnej. Okazuje się jednak, że nie wystąpi w niej Robert Lewandowski, choć jest kapitanem drużyny. — Możliwe, że InPost nie chce inwestować w zawodnika po prostu powoli już schodzącego z rynku — ocenia ekspert z branży, cytowany przez serwis.

## Loty z Tel Awiwu uziemione. Protesty przelewają się przez kraj
 - [https://businessinsider.com.pl/wiadomosci/loty-z-tel-awiwu-uziemione-protesty-przelewaja-sie-przez-kraj/n8m22tm](https://businessinsider.com.pl/wiadomosci/loty-z-tel-awiwu-uziemione-protesty-przelewaja-sie-przez-kraj/n8m22tm)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 08:22:07+00:00

Loty z lotniska Ben Gurion w Tel Awiwie zostały uziemione — podają "Financial Times" i "Times of Israel". Szef związku zawodowego pracowników lotniska ogłosił strajk, w proteście przeciw planowanej przez Benjamina Netanjahu zmianie ustawodawstwa sądowniczego.

## Polityczny absurd kanału przez mierzeję. "Nasz terminal stoi pusty"
 - [https://businessinsider.com.pl/wiadomosci/absurd-kanalu-przez-mierzeje-nasz-terminal-stoi-pusty/mezmcd2](https://businessinsider.com.pl/wiadomosci/absurd-kanalu-przez-mierzeje-nasz-terminal-stoi-pusty/mezmcd2)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 08:02:04+00:00

Otwarty z wielką pompą kanał przez Mierzeję Wiślaną wciąż ma potężny mankament. Bez pogłębienia 900-metrowego odcinka na rzece Elbląg port w mieście o tej samej nazwie stoi bezużyteczny. Trwa w tej sprawie konflikt rządu z lokalnymi władzami — pisze portalsamorzadowy.pl.

## GUS pokazał nowe tablice dla emerytów. Będą niższe świadczenia
 - [https://businessinsider.com.pl/prawo/tablice-trwania-zycia-2023-gus-pokazal-kluczowe-dane-emerytury-beda-nizsze/36wk9v8](https://businessinsider.com.pl/prawo/tablice-trwania-zycia-2023-gus-pokazal-kluczowe-dane-emerytury-beda-nizsze/36wk9v8)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 08:01:14+00:00

Główny Urząd Statystyczny opublikował nowe tablice średniego dalszego trwania życia kobiet i mężczyzn. To wskaźnik kluczowy dla ustalania wysokości emerytur. ZUS oblicza wysokość świadczenia osób kończących aktywność zawodową właśnie na podstawie danych GUS.

## To po jego wypowiedzi akcje Credit Suisse sięgnęły dna. Teraz składa dymisję
 - [https://businessinsider.com.pl/finanse/to-po-jego-wypowiedzi-akcje-credit-suisse-siegnely-dna-teraz-sklada-dymisje/v70e5gn](https://businessinsider.com.pl/finanse/to-po-jego-wypowiedzi-akcje-credit-suisse-siegnely-dna-teraz-sklada-dymisje/v70e5gn)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 07:58:54+00:00

Ammar Al Khudairy, prezes Saudi National Bank, największego akcjonariusza Credit Suisse, podał się do dymisji zaledwie kilka dni po tym, jak jego komentarze przyczyniły się do ostrego spadku kursu akcji szwajcarskiego banku.

## Zbliża się wielka majówka. Rekordowa liczba rezerwacji. W te miejsca wybierają się Polacy
 - [https://businessinsider.com.pl/lifestyle/zbliza-sie-wielka-majowka-rekordowa-liczba-rezerwacji-tam-jezdza-polacy/5fktc07](https://businessinsider.com.pl/lifestyle/zbliza-sie-wielka-majowka-rekordowa-liczba-rezerwacji-tam-jezdza-polacy/5fktc07)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 07:42:11+00:00

Majowy kalendarz jest w tym roku wyjątkowo łaskawy dla miłośników przedłużonych weekendów. Wystarczy wziąć jeden dzień urlopu z pracy, żeby mieć pięciodniowy wypoczynek. Jeśli weźmiemy trzy dni wolnego - wielka majówka może trwać nawet dziewięć dni. Rezerwacji na majowy weekend jest o 61 proc. więcej niż w zeszłym roku. Zauważalnie wzrosły też ceny wypoczynku.

## Borys: w tej chwili przechodzimy do dezinflacji. Co to oznacza dla cen i naszych portfeli?
 - [https://businessinsider.com.pl/gospodarka/wchodzimy-w-czas-dezinflacji-sprawdz-co-to-oznacza-dla-twojego-portfela/wdkfszj](https://businessinsider.com.pl/gospodarka/wchodzimy-w-czas-dezinflacji-sprawdz-co-to-oznacza-dla-twojego-portfela/wdkfszj)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 07:41:19+00:00

Pod względem cenowym polska gospodarka wchodzi w nowy etap — dezinflacji. To dobra wiadomość dla naszych portfeli, ale według zapowiedzi prezesa PFR jest zdecydowanie za wcześnie na ogłaszanie zwycięstwa w walce z inflacją.

## Oto sposób na zakaz spalinówek? Paliwo "wyłącznie dla bogatych"
 - [https://businessinsider.com.pl/gospodarka/to-skuteczny-sposob-na-zakaz-spalinowek-paliwo-wylacznie-dla-bogatych/zqzw243](https://businessinsider.com.pl/gospodarka/to-skuteczny-sposob-na-zakaz-spalinowek-paliwo-wylacznie-dla-bogatych/zqzw243)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 07:27:50+00:00

Bezemisyjne paliwa syntetyczne potencjalnie mogłyby stanowić odpowiedź na planowany przez Unię Europejską zakaz rejestracji samochodów spalinowych. Jak ostrzegają analitycy, może okazać się, że ten pomysł doprowadzi do stworzenia paliwa "wyłącznie dla bogatych".

## Kurs franka 27 marca powyżej 4,7 zł
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-franka-frank-szwajcarski-chfpln-27-marca-2023/h2zmvc0](https://businessinsider.com.pl/gielda/kursy-walut/kurs-franka-frank-szwajcarski-chfpln-27-marca-2023/h2zmvc0)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 07:27:07+00:00

Frank szwajcarski powyżej 4,7 zł. W poniedziałek rano 27 marca 2023 r. kurs tej waluty wobec polskiego złotego wynosi 4,7364.

## Kurs dolara 27 marca powyżej 4,3 zł
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-dolara-usdpln-notowania-walut-27-marca-2023/e21kdv3](https://businessinsider.com.pl/gielda/kursy-walut/kurs-dolara-usdpln-notowania-walut-27-marca-2023/e21kdv3)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 07:23:21+00:00

Kurs dolara powyżej 4,3 zł. W poniedziałek rano 27 marca 2023 r. kurs USD/PLN wynosi 4,3509.

## Kurs euro 27 marca poniżej 4,7 zł
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-euro-eurpln-notowania-walut-27-marca-2023/v3n7g5c](https://businessinsider.com.pl/gielda/kursy-walut/kurs-euro-eurpln-notowania-walut-27-marca-2023/v3n7g5c)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 07:21:36+00:00

Kurs euro poniżej 4,7 zł. W poniedziałek rano 27 marca 2023 r. kurs EUR/PLN wynosił 4,6830 zł.

## Zamek krzyżacki do kupienia w Polsce. Ile trzeba zapłacić?
 - [https://businessinsider.com.pl/nieruchomosci/zamek-krzyzacki-do-kupienia-w-polsce-ile-trzeba-zaplacic/nr998n6](https://businessinsider.com.pl/nieruchomosci/zamek-krzyzacki-do-kupienia-w-polsce-ile-trzeba-zaplacic/nr998n6)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 07:18:43+00:00

Jeśli ktoś ma odpowiedni zapas gotówki i dużą dozę biznesowej odwagi, może stać się właścicielem prawdziwego zamku krzyżackiego. Jak czytamy w ogłoszeniu, "zamek posiada własne jezioro", choć wymaga ono kolejnych nakładów finansowych.

## Wyższy wiek emerytalny nieuchronny? Szef rady nadzorczej ZUS odpowiada
 - [https://businessinsider.com.pl/praca/wyzszy-wiek-emerytalny-nieuchronny-szef-rady-nadzorczej-zus-odpowiada/46p2tnf](https://businessinsider.com.pl/praca/wyzszy-wiek-emerytalny-nieuchronny-szef-rady-nadzorczej-zus-odpowiada/46p2tnf)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 06:27:36+00:00

Emerytura jest prawem, ale nie obowiązkiem — podkreśla w rozmowie z "Rzeczpospolitą", Łukasz Hardt, przewodniczący rady nadzorczej ZUS. W rozmowie z dziennikiem przyznaje, że powinniśmy dążyć do zwiększania efektywnego wieku emerytalnego. Zaznacza jednak, że nie podnosiłby go ustawowo.

## Nowy "Mój prąd" to dopłaty do 58 tys. zł. Znamy terminy i szczegóły kolejnej edycji
 - [https://businessinsider.com.pl/gospodarka/nowy-moj-prad-to-doplaty-do-58-tys-zl-terminy-i-szczegoly-nowej-edycji/vekvg64](https://businessinsider.com.pl/gospodarka/nowy-moj-prad-to-doplaty-do-58-tys-zl-terminy-i-szczegoly-nowej-edycji/vekvg64)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 06:01:01+00:00

Jak podał wiceszef NFOŚiGW Paweł Mirowski, od 4,4 tys. zł do 28 tys. zł mogą wynieść dopłaty do pomp ciepła w piątej odsłonie programu "Mój prąd". W przypadku kolektorów ma być to do 3,5 tys. zł . Mirowski wskazał też, kiedy ma ruszyć piąta edycja dopłat.

## Co warzywo to inne wytłumaczenie. Kiedy ceny wreszcie spadną?
 - [https://businessinsider.com.pl/wiadomosci/co-warzywo-to-inne-wytlumaczenie-kiedy-ceny-wreszcie-spadna/hvjdx5v](https://businessinsider.com.pl/wiadomosci/co-warzywo-to-inne-wytlumaczenie-kiedy-ceny-wreszcie-spadna/hvjdx5v)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 05:50:34+00:00

Ceny cebuli najmocniej zależą od sytuacji w Ukrainie. Papryka i pomidory potanieją, gdy zaczną się dostawy z polskich szklarni. Natomiast marchew zacznie mniej kosztować, jeśli będą dobre plony z upraw na polach. Wygląda na to, że w warzywniakach na niższe ceny sporo jeszcze poczekamy.

## Tak odejdziemy od węgla. Wiemy, ile wydamy na OZE i atom
 - [https://businessinsider.com.pl/gospodarka/tak-odejdziemy-od-wegla-wiemy-ile-wydamy-na-oze-i-atom/es850k5](https://businessinsider.com.pl/gospodarka/tak-odejdziemy-od-wegla-wiemy-ile-wydamy-na-oze-i-atom/es850k5)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 05:34:00+00:00

Jak donosi w poniedziałek "Rzeczpospolita", znane są już szczegóły założeń do aktualizacji strategii energetycznej. Według planów, już wkrótce mają nastąpić gigantyczne inwestycje w OZE i energetykę jądrową. A dzięki temu ceny wytwarzania prądu miałyby radykalnie spaść.

## Najnowocześniejsze fotoradary w Polsce już działają. Oto ich możliwości
 - [https://businessinsider.com.pl/wiadomosci/najnowoczesniejsze-fotoradary-w-polsce-zamontowane-jakie-sa-ich-mozliwosci/0kn179f](https://businessinsider.com.pl/wiadomosci/najnowoczesniejsze-fotoradary-w-polsce-zamontowane-jakie-sa-ich-mozliwosci/0kn179f)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 05:31:35+00:00

Na razie uważać na nowe fotoradary uważać muszą kierowcy na północy Polski, ale wkrótce podobnych urządzeń ma być w Polsce grubo ponad 100. Są w stanie śledzić na raz wiele samochodów na kilku pasach ruchu.

## Skala podatkowa czy liniowy? Tak Polacy rozliczają PIT. Są dane ministerstwa
 - [https://businessinsider.com.pl/gospodarka/skala-podatkowa-czy-liniowy-tak-polacy-rozliczaja-pit-sa-dane-ministerstwa/h2kdpet](https://businessinsider.com.pl/gospodarka/skala-podatkowa-czy-liniowy-tak-polacy-rozliczaja-pit-sa-dane-ministerstwa/h2kdpet)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 05:10:14+00:00

Ministerstwo finansów udostępniło dane pokazujące w jaki sposób rozliczają się Polacy. Jak zauważa "Dziennik Gazeta Prawna", tuż przed Polskim Ładem obywatele nie zniechęcili się do podatku liniowego. I nie zbiednieli w czasie pandemii.

## PiS rozmawia o waloryzacji programu 500 plus
 - [https://businessinsider.com.pl/gospodarka/pis-rozmawia-o-waloryzacji-programu-500-plus/69hwhzf](https://businessinsider.com.pl/gospodarka/pis-rozmawia-o-waloryzacji-programu-500-plus/69hwhzf)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 05:02:23+00:00

Kampania wyborcza trwa, rosną więc szanse na waloryzację programu 500 plus. Cena diesla na stacjach benzynowych spadła w tydzień o 20 gr, natomiast agencja Moody’s przez problemy z frankami szwajcarskimi obniżyła rating mBanku i perspektywę ratingu Banku Millennium. Na giełdach przed weekendem znów mieliśmy popłoch w sektorze bankowym, tym razem z Deutsche Bankiem w roli głównej. Unia Europejska zaś w tym tygodniu ma już ostatecznie zatwierdzić przepisy o zakazie wprowadzania na rynek nowych aut spalinowych po 2035 r. Oto pięć najciekawszych wydarzeń w gospodarce teraz.

## "Babciowe" Tuska ma więcej minusów niż plusów [ANALIZA]
 - [https://businessinsider.com.pl/prawo/praca/babciowe-tuska-kto-straci-kto-zyska-eksperci-widza-wiecej-minusow-niz-plusow/d0fyqb9](https://businessinsider.com.pl/prawo/praca/babciowe-tuska-kto-straci-kto-zyska-eksperci-widza-wiecej-minusow-niz-plusow/d0fyqb9)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 04:50:41+00:00

Donald Tusk proponuje 1500 zł kobietom, które wrócą do pracy po urodzeniu dziecka. — To za mało — mówią eksperci. I nie chodzi o wysokość świadczenia, ale brak innych rozwiązań. Tusk zapomniał, że trzeba zwiększyć liczbę żłobków, uelastycznić godziny pracy i ułatwić zatrudnienie na część etatu. Kolejny raz PR i chęć przypodobania się wyborcom przesłonił politykom bardziej racjonalne rozwiązania.

## Wyższe bezrobocie, uboższe rodziny i mniej inwestycji, czyli Polska bez funduszy unijnych
 - [https://businessinsider.com.pl/gospodarka/wyzsze-bezrobocie-i-ubozsze-rodziny-to-dopiero-poczatek-ryzyko-utraty-funduszy/x2l570c](https://businessinsider.com.pl/gospodarka/wyzsze-bezrobocie-i-ubozsze-rodziny-to-dopiero-poczatek-ryzyko-utraty-funduszy/x2l570c)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 04:39:15+00:00

Brak środków europejskich oznacza niższe PKB, wyższe bezrobocie i mniejsze inwestycje. A to jeszcze nie jest największe zagrożenie, które płynie z konfliktu Warszawa-Bruksela i ryzyka utraty 75 mld euro unijnych funduszy.

## Wielki strajk w Niemczech. Transport sparaliżowany
 - [https://businessinsider.com.pl/gospodarka/wielki-strajk-w-niemczech-transport-sparalizowany/201x659](https://businessinsider.com.pl/gospodarka/wielki-strajk-w-niemczech-transport-sparalizowany/201x659)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 04:37:47+00:00

Dziś o północy rozpoczął się w Niemczech 24-godzinny strajk ostrzegawczy sektora transportu publicznego. Podwyżek domagają się pracownicy zarówno kolei, lotnisk, jak i ci pracujący w transporcie drogowym. Do strajku mają dołączyć także firmy obsługujące autostrady. Związki zawodowe domagają się podwyżki sięgającej co najmniej 500 euro miesięcznie.

## Darowizna samochodu po leasingu? Uważaj, by nie narazić się fiskusowi
 - [https://businessinsider.com.pl/prawo/podatki/leasing-samochodu-co-po-wykupie-darowizna-mozna-narazic-sie-fiskusowi/zy4skvs](https://businessinsider.com.pl/prawo/podatki/leasing-samochodu-co-po-wykupie-darowizna-mozna-narazic-sie-fiskusowi/zy4skvs)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 04:27:18+00:00

Darowizna po wykupie z leasingu może być sposobem na uniknięcie PIT i VAT, ale nie może prowadzić do optymalizacji podatków. Tłumaczymy, co musi zrobić przedsiębiorca, który wykupił samochód z leasingu i chce go przekazać członkowi najbliższej rodziny, aby nie narobić sobie problemów z fiskusem.

## "Nie możemy w nieskończoność dokładać nowych zadań i wydatków". Minister finansów mówi o priorytetach rządu [WYWIAD]
 - [https://businessinsider.com.pl/finanse/waloryzacja-500-plus-15-emerytura-i-priorytetowe-wydatki-minister-finansow-zabiera/qy5gj3x](https://businessinsider.com.pl/finanse/waloryzacja-500-plus-15-emerytura-i-priorytetowe-wydatki-minister-finansow-zabiera/qy5gj3x)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 04:05:00+00:00

Wiemy, jakie są priorytety i na nie muszą się znaleźć pieniądze. Jeśli chcemy realizować inne projekty, to musimy zastanowić się nad efektywnością takich wydatków i szukać finansowania. Jeśli dysponent budżetowy proponuje wzrost wydatków, to powinien wskazać jego źródła finansowania – mówi w wywiadzie dla Business Insider Polska minister finansów Magdalena Rzeczkowska.

## Jedną funkcją podbili świat. Teraz założyciel Glovo ujawnia pomysł na Polskę [WYWIAD]
 - [https://businessinsider.com.pl/technologie/jedna-funkcja-podbili-swiat-teraz-gigant-ujawnia-pomysl-na-polske-wywiad/07vmgwp](https://businessinsider.com.pl/technologie/jedna-funkcja-podbili-swiat-teraz-gigant-ujawnia-pomysl-na-polske-wywiad/07vmgwp)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-03-27 04:05:00+00:00

Jesteśmy w około 80 proc. miejskiej populacji kraju. Do końca roku będzie to 100 proc. – zapowiada w rozmowie z Business Insiderem Sacha Michaud, współzałożyciel i wiceprezes Glovo ds. globalnych. — Pozornie nasz biznes nie był niczym innowacyjnym — przyznaje. Wskazuje jednak na jedną funkcję, która pozwoliła pokonać konkurencję i stworzyć startup, działający dziś na wszystkich kontynentach.

