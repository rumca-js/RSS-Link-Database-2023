# Source:CodeProject, URL:https://www.codeproject.com/WebServices/NewsRSS.aspx, language:en-US

## Are Lenovo laptops any good?
 - [https://www.codeproject.com/Messages/5933657/Are-Lenovo-laptops-any-good](https://www.codeproject.com/Messages/5933657/Are-Lenovo-laptops-any-good)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-03-27 04:00:00+00:00

"We shape our tools and then our tools shape us."

## GitHub's Private RSA SSH key mistakenly exposed in public repository
 - [https://www.darkreading.com/application-security/github-private-rsa-ssh-key-mistakenly-exposed-public-repository](https://www.darkreading.com/application-security/github-private-rsa-ssh-key-mistakenly-exposed-public-repository)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-03-27 04:00:00+00:00

Oh, ssh!

## Gordon Moore, Intel co-founder and creator of Moore's Law, dies aged 94
 - [https://www.bbc.com/news/world-us-canada-65073812](https://www.bbc.com/news/world-us-canada-65073812)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-03-27 04:00:00+00:00

"If the auto industry advanced as rapidly as the semiconductor industry, a Rolls Royce would get half a million miles per gallon, and it would be cheaper to throw it away than to park it."

## In a swift decision, judge eviscerates Internet Archive’s scanning and lending program
 - [https://www.publishersweekly.com/pw/by-topic/industry-news/libraries/article/91862-in-a-swift-decision-judge-eviscerates-internet-archive-s-scanning-and-lending-program.html](https://www.publishersweekly.com/pw/by-topic/industry-news/libraries/article/91862-in-a-swift-decision-judge-eviscerates-internet-archive-s-scanning-and-lending-program.html)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-03-27 04:00:00+00:00

No ebooks for you!

## Inaudible ultrasound attack can stealthily control your phone, smart speaker
 - [https://www.bleepingcomputer.com/news/security/inaudible-ultrasound-attack-can-stealthily-control-your-phone-smart-speaker/](https://www.bleepingcomputer.com/news/security/inaudible-ultrasound-attack-can-stealthily-control-your-phone-smart-speaker/)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-03-27 04:00:00+00:00

Beware of bat hackers

## Mads Kristensen's sneak peek at Visual Studio's AI future, to 'Rekindle our love of coding'
 - [https://visualstudiomagazine.com/articles/2023/03/23/vs-ai.aspx](https://visualstudiomagazine.com/articles/2023/03/23/vs-ai.aspx)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-03-27 04:00:00+00:00

What if you never lost it?

## Microsoft now claims GPT-4 shows 'sparks' of general intelligence
 - [https://www.vice.com/en/article/g5ypex/microsoft-now-claims-gpt-4-shows-sparks-of-general-intelligence](https://www.vice.com/en/article/g5ypex/microsoft-now-claims-gpt-4-shows-sparks-of-general-intelligence)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-03-27 04:00:00+00:00

Just like the rest of Microsoft

## On trust in software development
 - [https://blog.ploeh.dk/2023/03/20/on-trust-in-software-development/](https://blog.ploeh.dk/2023/03/20/on-trust-in-software-development/)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-03-27 04:00:00+00:00

Trust everyone, but always verify the code

## OneDrive, AWS, Etc.
 - [https://www.codeproject.com/Messages/5933637/OneDrive-AWS-Etc](https://www.codeproject.com/Messages/5933637/OneDrive-AWS-Etc)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-03-27 04:00:00+00:00

It is good, until it isn't

## OpenAI CEO 'feels awful' after ChatGPT leaks conversations, payment info
 - [https://www.theregister.com/2023/03/23/openai_ceo_leak](https://www.theregister.com/2023/03/23/openai_ceo_leak)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-03-27 04:00:00+00:00

AI in front, no 'I' in back

## Portions of Twitter's source code were reportedly leaked online
 - [https://www.engadget.com/portions-of-twitters-source-code-have-reportedly-leaked-online-234405620.html](https://www.engadget.com/portions-of-twitters-source-code-have-reportedly-leaked-online-234405620.html)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-03-27 04:00:00+00:00

Live by the hostile work environment, die by the hostile work environment

