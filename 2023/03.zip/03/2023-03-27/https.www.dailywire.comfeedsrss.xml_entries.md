# Source:Daily Wire, URL:https://www.dailywire.com/feeds/rss.xml, language:en-US

## China Influences Utah Lawmakers By Appealing To Mormonism: Report
 - [https://www.dailywire.com/news/china-influences-utah-lawmakers-by-appealing-to-mormonism-report](https://www.dailywire.com/news/china-influences-utah-lawmakers-by-appealing-to-mormonism-report)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-27 18:57:12+00:00

A new investigative report published this week from the Associated Press found that China has been able to forge ties in Utah that have led to the communist nation scoring public relations and legislative victories in the state and from its lawmakers. The report found that the Chinese &#8220;appealed&#8221; to the lawmaker&#8217;s ties to the ...

## Regulators Move Against World’s Largest Crypto Exchange For ‘Disregard’ Of Financial Laws
 - [https://www.dailywire.com/news/regulators-move-against-worlds-largest-crypto-exchange-for-disregard-of-financial-laws](https://www.dailywire.com/news/regulators-move-against-worlds-largest-crypto-exchange-for-disregard-of-financial-laws)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-27 18:49:13+00:00

Officials at the Commodity Futures Trading Commission, also known as the CFTC, filed a civil enforcement action against Binance CEO Changpeng Zhao and three entities with the company for “numerous violations” of the law. Three business units within Binance, the largest cryptocurrency exchange in the world, allegedly chose to “knowingly disregard” portions of the Commodity ...

## NFL Lineman Claims He Was Sexually Assaulted By TSA: ‘Extremely Unnecessary And Dehumanizing’
 - [https://www.dailywire.com/news/nfl-lineman-claims-he-was-sexually-assaulted-by-tsa-extremely-unnecessary-and-dehumanizing](https://www.dailywire.com/news/nfl-lineman-claims-he-was-sexually-assaulted-by-tsa-extremely-unnecessary-and-dehumanizing)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-27 18:16:45+00:00

Los Angeles Chargers defensive end Sebastian Joseph-Day accused the Transportation Security Administration (TSA) of sexually assaulting him late last week at an airport in California. Joseph-Day said that the incident happened on Friday at John Wayne Airport in Orange County. “I really just got sexually assaulted by TSA at @JohnWayneAir,” he tweeted. “After I asked ...

## Monday Afternoon Update: Nashville School Shooting, Israeli Protests, Zombie Drug Hits Nation
 - [https://www.dailywire.com/news/monday-afternoon-update-nashville-school-shooting-israeli-protests-zombie-drug-hits-nation](https://www.dailywire.com/news/monday-afternoon-update-nashville-school-shooting-israeli-protests-zombie-drug-hits-nation)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-27 18:08:42+00:00

This article is adapted from today’s Morning Wire Afternoon Update. To listen to the podcast version, click here. Nashville School Shooting At least six people, including three children, have died as the result of the mass shooting at a private Christian school in Nashville this morning. The shooter, a 28-year-old female who identified as a man, ...

## Megyn Kelly Destroys ESPN For Including Lia Thomas In Women’s History Month, Takes Down Kamala Harris
 - [https://www.dailywire.com/news/megyn-kelly-destroys-espn-for-including-lia-thomas-in-womens-history-month-takes-down-kamala-harris](https://www.dailywire.com/news/megyn-kelly-destroys-espn-for-including-lia-thomas-in-womens-history-month-takes-down-kamala-harris)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-27 18:06:23+00:00

Megyn Kelly destroyed ESPN for including biological male trans swimmer Lia Thomas in its women&#8217;s history month segment and took down Kamala Harris for ignoring white women and Republican ones in her tribute to females. During the Sirius XM &#8220;The Megyn Kelly Show&#8221; podcast, the host was speaking to guests Amala Ekpunobi and Evita Duffy-Alfonso about ...

## Biden Team ‘Astounded’ By Number Of Feds Targeted By Spyware
 - [https://www.dailywire.com/news/biden-team-astounded-by-number-of-feds-targeted-by-spyware](https://www.dailywire.com/news/biden-team-astounded-by-number-of-feds-targeted-by-spyware)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-27 17:52:56+00:00

Biden administration officials expressed shock as they revealed dozens of U.S. government employees are believed to have been targeted by commercial spyware. Mobile phones belonging to at least 50 federal employees, some of whom held senior positions, were confirmed or were suspected to have been hit by hacking attacks in 10 foreign countries across multiple ...

## Another Former Top Trump Campaign Official Joins Pro-DeSantis PAC Urging Governor To Run
 - [https://www.dailywire.com/news/another-former-top-trump-campaign-official-joins-pro-desantis-pac-urging-governor-to-run](https://www.dailywire.com/news/another-former-top-trump-campaign-official-joins-pro-desantis-pac-urging-governor-to-run)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-27 17:51:17+00:00

A senior communications official on former President Donald Trump’s 2020 presidential campaign has joined the Never Back Down PAC, which is urging Florida Governor Ron DeSantis to run for president.  Matt Wolking, the former deputy communications director for Trump’s campaign, said in a statement that it was time to move on from the former president ...

## ‘Republicans Ain’t Got No Swag’: Why Progressives Go Out Of Their Way To Oppose TikTok Ban
 - [https://www.dailywire.com/news/republicans-aint-got-no-swag-why-progressives-go-out-of-their-way-to-oppose-tiktok-ban](https://www.dailywire.com/news/republicans-aint-got-no-swag-why-progressives-go-out-of-their-way-to-oppose-tiktok-ban)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-27 17:49:40+00:00

Every once in a while there’s a political no-brainer. Something along the lines of: The Chinese Communist Party is using an app to data mine and influence American kids — should we put a stop to it? For any sane, fully grown adult the answer to this question is obviously: Yes. Yes we should stamp ...

## Religion, Patriotism, Other Core American Values On The Decline, But One Not-So-Wholesome Value Is Growing: Poll
 - [https://www.dailywire.com/news/religion-patriotism-other-core-american-values-on-the-decline-but-one-not-so-wholesome-value-is-growing-poll](https://www.dailywire.com/news/religion-patriotism-other-core-american-values-on-the-decline-but-one-not-so-wholesome-value-is-growing-poll)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-27 17:40:58+00:00

Americans see the values once core to the nation’s way of life as less important than ever, while the extent to which they prioritize money is increasing. The Wall Street Journal and the National Opinion Research Center unveiled survey results on Monday which indicated that only 39% of respondents view “religion” as “very important” to ...

## Nashville Christian School Shooter Identified As Transgender: Authorities
 - [https://www.dailywire.com/news/nashville-christian-school-shooter-identified-as-transgender-authorities](https://www.dailywire.com/news/nashville-christian-school-shooter-identified-as-transgender-authorities)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-27 17:35:00+00:00

Authorities confirmed at a press conference that the 28-year-old woman who killed six, including three children, at a Christian school in Nashville identified as transgender. The shooter, a white 28-year-old Nashville woman who identified as a man, was engaged by police at the Covenant School around 10:27 a.m., 14 minutes after the first call was ...

## Hayden Panettiere Recalls Experience With Postpartum Depression: ‘Something Seriously Wrong With Me’
 - [https://www.dailywire.com/news/hayden-panettiere-recalls-experience-with-postpartum-depression-something-seriously-wrong-with-me](https://www.dailywire.com/news/hayden-panettiere-recalls-experience-with-postpartum-depression-something-seriously-wrong-with-me)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-27 17:24:21+00:00

Actress Hayden Panettiere opened up about her experience with postpartum depression.  The “Heroes” alum made the comments during an interview with E! News&#8217; “The Rundown.”  &#8220;I wish I knew about postpartum depression. I wish I knew to look out for it,&#8221; she told host Erin Lim Rhodes. &#8220;I just thought there was something seriously wrong ...

## Johnny Depp Says He’s Enjoying Life Out Of The Spotlight, Talks New Home After Heard Trial
 - [https://www.dailywire.com/news/johnny-depp-says-hes-enjoying-life-out-of-the-spotlight-talks-new-home-after-heard-trial](https://www.dailywire.com/news/johnny-depp-says-hes-enjoying-life-out-of-the-spotlight-talks-new-home-after-heard-trial)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-27 17:09:50+00:00

Johnny Depp said he&#8217;s enjoying life out of the spotlight as he talked about his new home in the English countryside following his very public defamation trial against his ex-wife Amber Heard. The 59-year-old actor said life in the county of Somerset is where he&#8217;s been able to be himself and hasn&#8217;t really had to deal ...

## Police Identify Victims In Nashville Christian School Shooting
 - [https://www.dailywire.com/news/police-identify-victims-in-nashville-christian-school-shooting](https://www.dailywire.com/news/police-identify-victims-in-nashville-christian-school-shooting)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-27 17:06:45+00:00

Police have identified the six victims killed in a mass shooting at a Nashville Christian school, and they include three 9-year-old children and three adults 60 years old and above. According to the Metro Nashville Police Department, the victims are &#8220;Evelyn Dieckhaus, Hallie Scruggs, and William Kinney, all age 9, Cynthia Peak, age 61, Katherine ...

## Almost Half Of Democrat Voters Say Manhattan DA Prosecuting Trump Would Be ‘Outrageous Abuse of Power’
 - [https://www.dailywire.com/news/almost-half-of-democrat-voters-say-manhattan-da-prosecuting-trump-would-be-outrageous-abuse-of-power](https://www.dailywire.com/news/almost-half-of-democrat-voters-say-manhattan-da-prosecuting-trump-would-be-outrageous-abuse-of-power)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-27 16:55:19+00:00

Nearly half of Democrats voters agree that a grand jury indictment of former President Donald Trump from the Manhattan district attorney would be an “outrageous abuse of power,” a new survey found. Earlier this month, a report claimed federal, state, and local law enforcement agencies were analyzing security assessments and making plans to prepare for ...

## White House Blames Republicans After Nashville Christian School Shooting
 - [https://www.dailywire.com/news/white-house-blames-republicans-after-nashville-christian-school-shooting](https://www.dailywire.com/news/white-house-blames-republicans-after-nashville-christian-school-shooting)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-27 14:56:57+00:00

White House Press Secretary Karine Jean-Pierre blamed Republicans and their stance on gun control for the grade school shooting Monday that left three children and three adults dead. The shooting at Covenant Christian school shocked Nashville, and was particularly unusual given that police said the shooter was a 28-year-old woman. The White House, however, was ...

## Billionaire Who Committed Suicide Allotted Just $25 Million Of His Massive Fortune In Will
 - [https://www.dailywire.com/news/billionaire-who-committed-suicide-allotted-just-25-million-of-his-massive-fortune-in-will](https://www.dailywire.com/news/billionaire-who-committed-suicide-allotted-just-25-million-of-his-massive-fortune-in-will)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-27 14:22:48+00:00

Famed billionaire financier Thomas H. Lee, who committed suicide last month, listed just $25 million worth of his assets in his will. Lee, who was 78 when he died, is estimated to be worth $2 billion, so the $25 million allocated in his will would be a small fraction of his true net worth, the ...

## Disney Will Begin Mass Layoffs This Week, CEO Announces
 - [https://www.dailywire.com/news/disney-will-begin-mass-layoffs-this-week-ceo-announces](https://www.dailywire.com/news/disney-will-begin-mass-layoffs-this-week-ceo-announces)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-27 13:45:05+00:00

Disney CEO Bob Iger announced on Monday that the company would initiate the first of three headcount reductions this week. The longtime executive announced last month that the company would dismiss 7,000 workers as part of a “strategic realignment” meant to reduce costs. The layoffs expected this week will precede a “larger round of notifications” ...

## Female Shooter Kills At Least 6, Including 3 Kids In Nashville Christian School Shooting: Officials
 - [https://www.dailywire.com/news/female-shooter-kills-at-least-6-including-3-kids-in-nashville-christian-school-shooting](https://www.dailywire.com/news/female-shooter-kills-at-least-6-including-3-kids-in-nashville-christian-school-shooting)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-27 13:42:28+00:00

An unidentified female killed at least three children and three adults Monday inside a Nashville Christian school before police fatally shot her, officials said. The shooter, who was described as possibly a teenaged female, was engaged by police around 10:27 a.m., 14 minutes after the first call was made to police, Nashville authorities said in ...

## Michigan Repeals ‘Right-To-Work’ Law In Major Victory For Unions
 - [https://www.dailywire.com/news/michigan-repeals-right-to-work-law-in-major-victory-for-unions](https://www.dailywire.com/news/michigan-repeals-right-to-work-law-in-major-victory-for-unions)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-27 12:40:17+00:00

Michigan Democratic Gov. Gretchen Whitmer enacted legislation repealing right-to-work laws in the state on Friday, the first time such laws have been overturned in five decades. The right-to-work measures had allowed residents to decline union membership in their workplaces and exempted them from being forced to pay union dues. Whitmer and other Democrats nevertheless celebrated ...

## Brooke Shields Claims Andre Agassi ‘Smashed All His Trophies’ After She Appeared On ‘Friends’ As Obsessed Fan Of Joey
 - [https://www.dailywire.com/news/brooke-shields-claims-andre-agassi-smashed-all-his-trophies-after-she-appeared-on-friends-as-obsessed-fan-of-joey](https://www.dailywire.com/news/brooke-shields-claims-andre-agassi-smashed-all-his-trophies-after-she-appeared-on-friends-as-obsessed-fan-of-joey)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-27 12:27:16+00:00

Brooke Shields claims her ex, Andre Agassi, reacted with rage when she made a guest appearance on the NBC comedy “Friends” in the late 90s. The 57-year-old star described the behavior her tennis pro boyfriend exhibited during filming while speaking with The New Yorker for an interview published Sunday. In the episode titled &#8220;The One ...

## Multiple Children Killed At Private Nashville Christian School
 - [https://www.dailywire.com/news/multiple-people-shot-at-private-nashville-christian-school](https://www.dailywire.com/news/multiple-people-shot-at-private-nashville-christian-school)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-27 12:26:38+00:00

The person accused of shooting up a private Christian school in Nashville on Monday is dead after being engaged by local law enforcement officials. &#8220;An active shooter event has taken place at Covenant School, Covenant Presbyterian Church, on Burton Hills Dr.,&#8221; the Nashville Metro Police Department said in a tweet. &#8220;The shooter was engaged by ...

## Stanford’s Handling Of DEI Dean Is A Microcosm Of A Much Larger Problem In Higher Education
 - [https://www.dailywire.com/news/stanfords-handling-of-dei-dean-is-a-microcosm-of-a-much-larger-problem-in-higher-education](https://www.dailywire.com/news/stanfords-handling-of-dei-dean-is-a-microcosm-of-a-much-larger-problem-in-higher-education)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-27 12:24:47+00:00

Stanford University&#8217;s move to put Associate Dean for Diversity, Equity, and Inclusion Tirien Steinbach on leave was a step in the right direction after she brazenly attacked U.S. Court of Appeals Judge for the Fifth Circuit Kyle Duncan for nearly eight minutes. Dean Steinbach had a fundamental responsibility as an administrator to uphold the university&#8217;s ...

## No End In Sight: Publisher Woke-Editing Best-Selling Fiction Novelist Of All Time
 - [https://www.dailywire.com/news/no-end-in-sight-publisher-woke-editing-best-selling-fiction-novelist-of-all-time](https://www.dailywire.com/news/no-end-in-sight-publisher-woke-editing-best-selling-fiction-novelist-of-all-time)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-27 12:16:14+00:00

The best-selling author of all time outside of William Shakespeare can now join fellow British authors Roald Dahl and Ian Fleming by suffering the ignominy of having her books edited for woke purposes. The works of Agatha Christie, whose mysteries featuring detectives Hercule Poirot and Miss Marple delighted readers enough for her novels to have ...

## Blac Chyna Posts Video Of Removing ‘Demonic’ Baphomet Tattoo After Conversion To Christianity
 - [https://www.dailywire.com/news/blac-chyna-posts-video-of-removing-demonic-baphomet-tattoo-after-conversion-to-christianity](https://www.dailywire.com/news/blac-chyna-posts-video-of-removing-demonic-baphomet-tattoo-after-conversion-to-christianity)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-27 12:08:36+00:00

Former OnlyFans star and model Blac Chyna just documented the process of getting a “demonic” tattoo removed. The 34-year-old started going by her birth name, Angela White, ever since converting to Christianity and has been sharing her lifestyle changes with her 16.7 million Instagram followers. Over the weekend, White shared two social media posts focused ...

## Reese Witherspoon Announces Divorce From Jim Toth After 12 Years Of Marriage
 - [https://www.dailywire.com/news/reese-witherspoon-announces-divorce-from-jim-toth-after-12-years-of-marriage](https://www.dailywire.com/news/reese-witherspoon-announces-divorce-from-jim-toth-after-12-years-of-marriage)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-27 11:46:18+00:00

Actress Reese Witherspoon just announced that she and her husband of 12 years, Jim Toth, are getting divorced. The 47-year-old mom of three broke the news via her Instagram page on Friday, just days before the couple’s anniversary on Sunday.  “We have some personal news to share,” the couple’s joint statement said. “It is with ...

## Netanyahu Postpones Judicial Reform Plan Amid Widespread Protests, Strikes
 - [https://www.dailywire.com/news/netanyahu-postpones-judicial-reform-plan-amid-widespread-protests-strikes](https://www.dailywire.com/news/netanyahu-postpones-judicial-reform-plan-amid-widespread-protests-strikes)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-27 11:42:18+00:00

Israeli Prime Minister Benjamin Netanyahu agreed Monday to delay a vote on sweeping judicial reforms until the summer amid widespread protests and strikes, according to reports. A nationwide strike by labor unions and university workers was set to begin Monday, after a night of protests on Israel’s streets following Netanyahu’s sacking of a cabinet member opposed to ...

## Afroman Enjoys The Streisand Effect After Sheriff’s Dept That Raided His House Sues Him Over His Music Videos
 - [https://www.dailywire.com/news/afroman-enjoys-the-streisand-effect-after-sheriffs-dept-that-raided-his-house-sues-him-over-his-music-videos](https://www.dailywire.com/news/afroman-enjoys-the-streisand-effect-after-sheriffs-dept-that-raided-his-house-sues-him-over-his-music-videos)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-27 11:32:23+00:00

There&#8217;s a phenomenon on the world wide web (AKA the information super-highway) known as the Streisand effect. The effect is named after singer Barbra Streisand, whose 2003 attempt to suppress the California Coastal Records Project&#8217;s photograph of her cliff-top residence in Malibu failed miserably. Instead, her vehement effort to censor the image, taken to measure ...

## ‘What A Coincidence’: Massive Donations Come To Light After AOC Defends TikTok From Possible Ban
 - [https://www.dailywire.com/news/what-a-coincidence-massive-donations-come-to-light-after-aoc-defends-tiktok-from-possible-ban](https://www.dailywire.com/news/what-a-coincidence-massive-donations-come-to-light-after-aoc-defends-tiktok-from-possible-ban)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-27 11:10:18+00:00

An organization that Rep. Alexandria Ocasio-Cortez (D-NY) is a member of has accepted sizable donations from ByteDance, the Chinese parent company of the social media platform TikTok, which the democratic socialist recently defended from a possible nationwide ban. Jake Denton, a technology policy expert at the Heritage Foundation, noted that Ocasio-Cortez is a member of ...

## Grit N’Guts: Jeremy Renner Shares First Video Of Him Walking Since Horrific Snowplow Accident
 - [https://www.dailywire.com/news/grit-nguts-jeremy-renner-shares-first-video-of-him-walking-since-horrific-snowplow-accident](https://www.dailywire.com/news/grit-nguts-jeremy-renner-shares-first-video-of-him-walking-since-horrific-snowplow-accident)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-27 10:45:38+00:00

Two-time Oscar nominee Jeremy Renner, whose horrific snowplow accident — a result of a heroic effort to save his nephew on New Year’s Day — left him with over 30 broken bones, posted a video for the first time publicly showing him upright and walking. According to a Nevada sheriff&#8217;s office incident report, the tragic incident ...

## Financial Authorities Announce Buyer For Collapsed Silicon Valley Bank
 - [https://www.dailywire.com/news/financial-authorities-announce-buyer-for-collapsed-silicon-valley-bank](https://www.dailywire.com/news/financial-authorities-announce-buyer-for-collapsed-silicon-valley-bank)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-27 10:20:17+00:00

First Citizens Bank will acquire Silicon Valley Bank on Monday after the latter company faced a run on deposits and collapsed. The implosion of Silicon Valley Bank, where the vast majority of account balances exceeded the $250,000 threshold guaranteed by the Federal Deposit Insurance Corporation, also called the FDIC, prompted the government-backed company to secure ...

## Gwyneth Paltrow Mocked For Trial Statement: ‘Well, We Lost Half A Day Of Skiing’
 - [https://www.dailywire.com/news/gwyneth-paltrow-mocked-for-trial-statement-well-we-lost-half-a-day-of-skiing](https://www.dailywire.com/news/gwyneth-paltrow-mocked-for-trial-statement-well-we-lost-half-a-day-of-skiing)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-27 10:08:27+00:00

Gwyneth Paltrow, who is testifying in a trial in which a retired optometrist is suing her for allegedly crashing into him on a ski slope, was mocked for a statement she made about any loss she suffered from the accident. Paltrow was sued by retired optometrist Terry Sanderson in 2019; he alleged she plowed into him on Flagstaff ...

## Protests Roil Israel After Bibi Sacks Minister Over Proposed Judicial Reforms
 - [https://www.dailywire.com/news/protests-roil-israel-after-bibi-sacks-minister-over-proposed-judicial-reforms](https://www.dailywire.com/news/protests-roil-israel-after-bibi-sacks-minister-over-proposed-judicial-reforms)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-03-27 09:47:22+00:00

Massive protests erupted on Israel’s streets and a nationwide strike was set to begin after Prime Minister Benjamin Netanyahu sacked a cabinet member opposed to his bid to reform the Jewish State’s judicial system by curbing the Supreme Court&#8217;s power. Netanyahu, who is seeking to expand the Israeli parliament’s lawmaking authority by curbing the Supreme ...

