# Source:Sekurak, URL:https://sekurak.pl/rss, language:pl-PL

## Microsoft łata podatność w windowsowym narzędziu do screenshotów (Snipping Tool). Czasem w pliku graficznym mogą wyciekać wrażliwe informacje (z oryginału ocenzurowanego pliku)
 - [https://sekurak.pl/microsoft-lata-podatnosc-w-windowsowym-narzedziu-do-screenshotow-czasem-w-pliku-graficznym-moga-wyciekac-wrazliwe-informacje-z-oryginalu-ocenzurowanego-pliku/](https://sekurak.pl/microsoft-lata-podatnosc-w-windowsowym-narzedziu-do-screenshotow-czasem-w-pliku-graficznym-moga-wyciekac-wrazliwe-informacje-z-oryginalu-ocenzurowanego-pliku/)
 - RSS feed: https://sekurak.pl/rss
 - date published: 2023-03-27 08:08:35+00:00

<p>Jakiś czas temu pisaliśmy o podatności aCropalypse, która dotyczyła telefonów Google Pixel (czy dokładniej &#8211; wbudowanej appki Markup): W tym przypadku okazywało się, że jeśli edytowaliśmy zdjęcie (np. przycinaliśmy je) i zapisywaliśmy ponownie w tym samym pliku &#8211; część oryginału mogła pozostać w nowym (przyciętym) pliku. O podobnym problemie w...</p>
<p>Artykuł <a href="https://sekurak.pl/microsoft-lata-podatnosc-w-windowsowym-narzedziu-do-screenshotow-czasem-w-pliku-graficznym-moga-wyciekac-wrazliwe-informacje-z-oryginalu-ocenzurowanego-pliku/" rel="nofollow">Microsoft łata podatność w windowsowym narzędziu do screenshotów (Snipping Tool). Czasem w pliku graficznym mogą wyciekać wrażliwe informacje (z oryginału ocenzurowanego pliku)</a> pochodzi z serwisu <a href="https://sekurak.pl" rel="nofollow">Sekurak</a>.</p>

