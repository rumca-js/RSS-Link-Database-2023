# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## Dope Tech: Better than Expected!
 - [https://www.youtube.com/watch?v=O-buiiyp_xU](https://www.youtube.com/watch?v=O-buiiyp_xU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2023-03-27 21:13:03+00:00

Everything in this Dope Tech has 1 thing in common: I thought it would be terrible, and it turned out to be... not completely terrible.

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

Earbuds provided by Huawei for review.
Motorized shoes provided by Shift for review.
Astro provided by my wallet.

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

