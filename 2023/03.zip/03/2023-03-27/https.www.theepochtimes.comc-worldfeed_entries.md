# Source:Epoch times world, URL:https://www.theepochtimes.com/c-world/feed/, language:en-US

## ‘Harsh Reminder of the Risks Our Heroes in Uniform Face’: Regimental Funeral for 2 Slain Edmonton Officers
 - [https://www.theepochtimes.com/harsh-reminder-of-the-risks-our-heroes-in-uniform-face-regimental-funeral-for-2-slain-edmonton-officers_5153294.html](https://www.theepochtimes.com/harsh-reminder-of-the-risks-our-heroes-in-uniform-face-regimental-funeral-for-2-slain-edmonton-officers_5153294.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 23:06:38+00:00

City police march during the procession for Edmonton Police Service constables Travis Jordan and Brett Ryan in Edmonton on March 27, 2023. The officers were killed in the line of duty on March 16, 2023. (Jason Franson/The Canadian Press)

## Liberal Leader Backs Down as Moira Deeming Suspended, Not Expelled
 - [https://www.theepochtimes.com/liberal-leader-backs-down-as-moira-deeming-suspended-not-expelled_5150986.html](https://www.theepochtimes.com/liberal-leader-backs-down-as-moira-deeming-suspended-not-expelled_5150986.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 22:55:29+00:00

Victorian Opposition Leader Giovanni Pesutto addresses the media at the Parliament of Victoria in Melbourne in Melbourne, Monday, March 27, 2023. Victorian MP Moira Deeming will face the music as Liberal colleagues vote on expelling her from the parliamentary caucus after her part in an anti-trans rally. (AAP Image/Diego Fedele)

## Trade Minister Confronted on Lack of Forced Labour Products Intercepted at Borders
 - [https://www.theepochtimes.com/trade-minister-confronted-on-lack-of-forced-labour-products-interdicted-at-borders_5153174.html](https://www.theepochtimes.com/trade-minister-confronted-on-lack-of-forced-labour-products-interdicted-at-borders_5153174.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 22:32:37+00:00

Minister of International Trade, Export Promotion, Small Business and Economic Development Mary Ng appears as a witness at a meeting of the House of Commons Standing Committee on Access to Information, Privacy and Ethics, in Ottawa on Feb. 10, 2023. (The Canadian Press/Sean Kilpatrick)

## John Robson: There’s Nothing Remotely Conservative About Ford’s Ontario Budget
 - [https://www.theepochtimes.com/john-robson-theres-nothing-remotely-conservative-about-fords-ontario-budget_5152118.html](https://www.theepochtimes.com/john-robson-theres-nothing-remotely-conservative-about-fords-ontario-budget_5152118.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 22:23:55+00:00

Ontario Finance Minister Peter Bethlenfalvy tables the provincial budget at the legislature at Queen's Park in Toronto on March 23, 2023. (The Canadian Press/Frank Gunn)

## MP Han Dong Suing Global News Over Report Alleging He Told Chinese Diplomat to Delay Releasing 2 Michaels
 - [https://www.theepochtimes.com/mp-han-dong-to-sue-global-news-over-report-alleging-he-told-chinese-diplomat-to-delay-releasing-2-michaels_5152460.html](https://www.theepochtimes.com/mp-han-dong-to-sue-global-news-over-report-alleging-he-told-chinese-diplomat-to-delay-releasing-2-michaels_5152460.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 22:14:53+00:00

Han Dong celebrates with supporters as a provincial Liberal candidate in the Toronto area on May 22, 2014. He later became a Liberal MP, but recently resigned over Chinese interference allegations and now sits as an independent. (The Canadian Press/Nathan Denette)

## Michael Taube: How the Trudeau Liberals Lost the Plot With Chinese Election Interference
 - [https://www.theepochtimes.com/michael-taube-how-the-trudeau-liberals-lost-the-plot-with-chinese-election-interference_5150440.html](https://www.theepochtimes.com/michael-taube-how-the-trudeau-liberals-lost-the-plot-with-chinese-election-interference_5150440.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 22:12:59+00:00

The Chinese Embassy in Ottawa in a file photo. (Sean Kilpatrick/The Canadian Press)

## Ahead of Budget Announcement, Poilievre Criticizes Trudeau for ‘War on Work’
 - [https://www.theepochtimes.com/poilievre-criticizes-trudeau-for-war-on-work-ahead-of-budget-announcement_5152478.html](https://www.theepochtimes.com/poilievre-criticizes-trudeau-for-war-on-work-ahead-of-budget-announcement_5152478.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 22:10:08+00:00

Conservative Leader Pierre Poilievre rises during Question Period in Ottawa on Feb. 7, 2023. (Adrian Wyld/The Canadian Press)

## Liberal MP Discussing 2 Michaels With Chinese Consulate Directly Amounts to ‘Monumental Government Negligence’: Former Envoy to China
 - [https://www.theepochtimes.com/liberal-mp-discussing-2-michaels-with-chinese-consulate-directly-amounts-to-monumental-government-negligence-former-envoy-to-china_5151592.html](https://www.theepochtimes.com/liberal-mp-discussing-2-michaels-with-chinese-consulate-directly-amounts-to-monumental-government-negligence-former-envoy-to-china_5151592.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 21:22:36+00:00

Ontario Premiere Kathleen Wynne, second right, along with Liberal leader of Canada Justin Trudeau, second left, federal candidate Adam Vaughan, left, and provincial candidate Han Dong, right, celebrate with supporters while taking part in a rally during a campaign stop in Toronto on Thursday, May 22, 2014. THE CANADIAN PRESS/Nathan Denette

## No Change to US Nuclear Posture Following Russia’s Pledge to Arm Belarus: State Department
 - [https://www.theepochtimes.com/no-change-to-us-nuclear-posture-following-russias-pledge-to-arm-belarus-state-department_5152639.html](https://www.theepochtimes.com/no-change-to-us-nuclear-posture-following-russias-pledge-to-arm-belarus-state-department_5152639.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 21:18:14+00:00

An inert Minuteman III missile in a training launch tube at Minot Air Force Base, N.D., on June 25, 2014. (Charlie Riedel/AP Photo)

## At Least 10 Injured After Explosion Destroys Calgary Home: Fire Department
 - [https://www.theepochtimes.com/at-least-10-injured-after-explosion-destroys-calgary-home-fire-department_5152945.html](https://www.theepochtimes.com/at-least-10-injured-after-explosion-destroys-calgary-home-fire-department_5152945.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 21:01:17+00:00

Firefighters attend the scene of a house explosion that injured several people, destroyed one home and damaged others in Calgary, Alta., Mar. 27, 2023. (The Canadian Press/Jeff McIntosh)

## Two Final Bodies Pulled From Rubble After Old Montreal Fire, Five Bodies Identified
 - [https://www.theepochtimes.com/two-final-bodies-pulled-from-rubble-after-old-montreal-fire-five-bodies-identified_5152916.html](https://www.theepochtimes.com/two-final-bodies-pulled-from-rubble-after-old-montreal-fire-five-bodies-identified_5152916.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 20:57:36+00:00

Firefighters enter the building as they continue the search for victims Mar. 21, 2023, at the scene of last week’s fire that left one person dead and six people missing in Montreal. (The Canadian Press/Ryan Remiorz)

## Anti-Social Behaviour Crackdown Targets Include Bad Tenants and ‘Harmful’ Beggars
 - [https://www.theepochtimes.com/anti-social-behaviour-crackdown-targets-include-bad-tenants-and-harmful-beggars_5094989.html](https://www.theepochtimes.com/anti-social-behaviour-crackdown-targets-include-bad-tenants-and-harmful-beggars_5094989.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 20:02:33+00:00

Prime Minister Rishi Sunak departs 10 Downing Street to attend Prime Minister's Questions at the Houses of Parliament, in London, on March 22, 2023. (Victoria Jones/PA Media)

## Israeli Government Delays Judicial Overhaul Bill Amid Mass Protests
 - [https://www.theepochtimes.com/israeli-government-delays-judicial-overhaul-bill-amid-mass-protests_5152278.html](https://www.theepochtimes.com/israeli-government-delays-judicial-overhaul-bill-amid-mass-protests_5152278.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 19:55:45+00:00

Israelis protest during a demonstration after Israeli Prime Minister Benjamin Netanyahu dismissed the Defense Minister Yoav Gallant, and his nationalist coalition government presses on with its judicial overhaul, in Jerusalem, on March 27, 2023. (Ilan Rosenberg/Reuters)

## Unknown Outcome for Billions Spent on Canada’s Feminist Foreign Policy, Says Auditor General
 - [https://www.theepochtimes.com/unknown-outcome-for-billions-spent-on-canadas-feminist-foreign-policy-says-auditor-general_5152643.html](https://www.theepochtimes.com/unknown-outcome-for-billions-spent-on-canadas-feminist-foreign-policy-says-auditor-general_5152643.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 19:52:16+00:00

Auditor General Karen Hogan leaves after holding a press conference in Ottawa on Dec. 6, 2022. (The Canadian Press/Sean Kilpatrick)

## Tories Raise Bill C-11 Censorship Concerns as It Comes Back to House After Senate Deliberations
 - [https://www.theepochtimes.com/conservative-mp-says-bill-c-11-is-about-censoring-canadians_5152171.html](https://www.theepochtimes.com/conservative-mp-says-bill-c-11-is-about-censoring-canadians_5152171.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 19:33:43+00:00

Heritage Minister Pablo Rodriguez prepares to appear before the Senate Committee on Transport and Communications on Bill C-11, on Parliament Hill in Ottawa on Nov. 22, 2022. (The Canadian Press/Justin Tang)

## Taliban Threat to Ex-SAS Soldier in Jail, Court Told
 - [https://www.theepochtimes.com/taliban-threat-to-ex-sas-soldier-in-jail-court-told_5151137.html](https://www.theepochtimes.com/taliban-threat-to-ex-sas-soldier-in-jail-court-told_5151137.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 19:30:45+00:00

Australian Army soldiers run during Exercise Chong Ju at the Puckapunyal Military Area on May 9, 2019 in Seymour, Australia. (Scott Barbour/Getty Images)

## Feds Reject Proposal to Allow Coal Workers Early Access to Pension Benefits
 - [https://www.theepochtimes.com/feds-reject-proposal-to-allow-coal-workers-early-access-to-pension-benefits_5152403.html](https://www.theepochtimes.com/feds-reject-proposal-to-allow-coal-workers-early-access-to-pension-benefits_5152403.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 19:29:47+00:00

A conveyor belt transports coal at the Westmoreland Coal Company's Sheerness Mine near Hanna, Alta., on Dec. 13, 2016. (The Canadian Press/Jeff McIntosh)

## Thousands of Officers March in Funeral Procession for Two Edmonton Police Constables Killed on Duty
 - [https://www.theepochtimes.com/thousands-of-officers-march-in-funeral-procession-for-two-edmonton-police-constables-killed-on-duty_5152467.html](https://www.theepochtimes.com/thousands-of-officers-march-in-funeral-procession-for-two-edmonton-police-constables-killed-on-duty_5152467.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 19:20:33+00:00

Police march along side the hearses during the procession for Edmonton Police Service constables Travis Jordan and Brett Ryan in Edmonton, March 27, 2023. The officers were killed in the line of duty on March 16, 2023. (The Canadian Press/Jason Franson)

## Health Canada Considers Cutting Marijuana Regulations After Numerous Bankruptcies in Industry: Report
 - [https://www.theepochtimes.com/health-canada-considers-cutting-marijuana-regulations-after-numerous-bankruptcies-in-industry-report_5151806.html](https://www.theepochtimes.com/health-canada-considers-cutting-marijuana-regulations-after-numerous-bankruptcies-in-industry-report_5151806.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 19:06:06+00:00

A marijuana plant is seen in Vancouver in a file photo. (Don Mackinnon/AFP/Getty Images)

## MPs to Vote on Questioning Special Rapporteur Johnston on Foreign Interference Investigation
 - [https://www.theepochtimes.com/mps-to-vote-on-questioning-special-rapporteur-johnston-on-foreign-interference-investigation_5152158.html](https://www.theepochtimes.com/mps-to-vote-on-questioning-special-rapporteur-johnston-on-foreign-interference-investigation_5152158.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 18:54:09+00:00

Then Governor General David Johnston and Prime Minister Stephen Harper take part in a Royal Assent ceremony in the Senate chamber on Parliament Hill on Dec. 15, 2010.(Reuters/Blair Gable)

## US in ‘Competition of Coalitions’ Against China and Russia, as It Seeks to Counter Threats in Africa and Middle East
 - [https://www.theepochtimes.com/us-in-competition-of-coalitions-against-china-and-russia-as-it-seeks-to-counter-threats-in-africa-and-middle-east_5152049.html](https://www.theepochtimes.com/us-in-competition-of-coalitions-against-china-and-russia-as-it-seeks-to-counter-threats-in-africa-and-middle-east_5152049.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 18:53:48+00:00

A file photo showing an explosion in the Syrian city of Kobani during a reported suicide car bomb attack by the ISIS terrorists on Oct. 20, 2014. (Gokhan Sahin/Getty Images)

## Quebec Girl, 9, Dies After Snow Fort Collapses Behind Residence
 - [https://www.theepochtimes.com/quebec-girl-9-dies-after-snow-fort-collapses-behind-residence_5152420.html](https://www.theepochtimes.com/quebec-girl-9-dies-after-snow-fort-collapses-behind-residence_5152420.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 18:43:35+00:00

A Surete du Quebec police car is seen in Montreal on July 22, 2020. (The Canadian Press/Paul Chiasson)

## Reducing Police Strip-Search Powers Could Lead to Higher Risk of Child Exploitation, Says Expert
 - [https://www.theepochtimes.com/reducing-police-strip-search-powers-could-lead-to-higher-risk-of-child-exploitation-says-expert_5151674.html](https://www.theepochtimes.com/reducing-police-strip-search-powers-could-lead-to-higher-risk-of-child-exploitation-says-expert_5151674.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 18:11:10+00:00

British school pupils walking to school on Nov. 26, 2012. (David Jones/PA Media)

## Denying Shamima Begum of Citizenship ‘A Form of Capital Punishment,’ Parliament Told
 - [https://www.theepochtimes.com/denying-shamima-begum-of-citizenship-a-form-of-capital-punishment-parliament-told_5151962.html](https://www.theepochtimes.com/denying-shamima-begum-of-citizenship-a-form-of-capital-punishment-parliament-told_5151962.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 18:01:15+00:00

Shamima Begum being interviewed by Sky News in northern Syria on Feb. 17, 2019. (Reuters)

## Moscow-Backed Talks Between Turkey, Syria Set to Resume Following Pause
 - [https://www.theepochtimes.com/moscow-backed-talks-between-turkey-syria-set-to-resume-following-pause_5152058.html](https://www.theepochtimes.com/moscow-backed-talks-between-turkey-syria-set-to-resume-following-pause_5152058.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 17:19:20+00:00

Russian President Vladimir Putin (R) shakes hands with his Syrian counterpart Bashar al-Assad during their meeting in Sochi on May 17, 2018. (Mikhail Klimentyev/AFP/Getty Images)

## Centre Block Construction Within Cost, but Ottawa Needs to Make Faster Decisions: AG
 - [https://www.theepochtimes.com/centre-block-construction-within-cost-but-ottawa-needs-to-make-faster-decisions-ag_5152120.html](https://www.theepochtimes.com/centre-block-construction-within-cost-but-ottawa-needs-to-make-faster-decisions-ag_5152120.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 17:05:08+00:00

Auditor General Karen Hogan leaves after holding a press conference in Ottawa on Dec. 6, 2022. (The Canadian Press/Sean Kilpatrick)

## Health Secretary Urges NHS Bodies to Review Diversity and Inclusion Memberships
 - [https://www.theepochtimes.com/health-secretary-urges-nhs-bodies-to-review-diversity-and-inclusion-memberships_5151316.html](https://www.theepochtimes.com/health-secretary-urges-nhs-bodies-to-review-diversity-and-inclusion-memberships_5151316.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 16:54:28+00:00

UK Health Secretary Steve Barclay arrives ahead of a Cabinet meeting in Downing Street, London, on Nov. 22, 2022. (Stefan Rousseau/PA Media)

## At Least 29 African Migrants Die When 2 Boats Sink Off Tunisia
 - [https://www.theepochtimes.com/at-least-29-african-migrants-die-when-2-boats-sink-off-tunisia_5151385.html](https://www.theepochtimes.com/at-least-29-african-migrants-die-when-2-boats-sink-off-tunisia_5151385.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 16:50:32+00:00

File photo of the Tunisia's national guard. (Fethi Belaid/AFP via Getty Images)

## Rich Chinese Face Dwindling Immigration Choices as Europe’s Golden Visa Era Ends
 - [https://www.theepochtimes.com/rich-chinese-face-dwindling-immigration-choices-as-europes-golden-visa-era-ends_5150956.html](https://www.theepochtimes.com/rich-chinese-face-dwindling-immigration-choices-as-europes-golden-visa-era-ends_5150956.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 16:42:13+00:00

European Union flags outside the European Commission building in Brussels, Belgium, on Oct. 24, 2014. (Carl Court/Getty Images)

## North Korea Fires Missiles as Provocation Continues Over Military Drills
 - [https://www.theepochtimes.com/north-korea-fires-missiles-as-provocation-continues-over-military-drills_5151729.html](https://www.theepochtimes.com/north-korea-fires-missiles-as-provocation-continues-over-military-drills_5151729.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 15:59:29+00:00

U.S. Army soldiers wait to board their CH-47 Chinook helicopter during a joint military drill between South Korea and the United States at Rodriguez Live Fire Complex in Pocheon, South Korea, on March 19, 2023. (Ahn Young-joon/AP Photo)

## Empty Shipping Containers Pile Up in Chinese Ports as China’s Exports Continue to Decline
 - [https://www.theepochtimes.com/empty-shipping-containers-pile-up-in-chinese-ports-as-chinas-exports-continue-to-decline_5150443.html](https://www.theepochtimes.com/empty-shipping-containers-pile-up-in-chinese-ports-as-chinas-exports-continue-to-decline_5150443.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 15:45:09+00:00

Containers at a port in Nanjing in eastern China's Jiangsu province, on Oct. 27, 2022. (Chinatopix via AP)

## Canada and US Signed Deal to Close Roxham Road a Year Before Announcement: Document
 - [https://www.theepochtimes.com/canada-and-us-signed-deal-to-close-roxham-road-a-year-before-announcement-documents_5151606.html](https://www.theepochtimes.com/canada-and-us-signed-deal-to-close-roxham-road-a-year-before-announcement-documents_5151606.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 15:40:51+00:00

US President Joe Biden and Canada's Prime Minister Justin Trudeau arrive for a joint press conference at the Sir John A. Macdonald Building in Ottawa, Canada, on March 24, 2023. (Photo by Mandel NGAN / AFP) (Photo by MANDEL NGAN/AFP via Getty Images)

## Humza Yousaf to Succeed Nicola Sturgeon as First Minister of Scotland
 - [https://www.theepochtimes.com/humza-yousaf-to-succeed-nicola-sturgeon-as-first-minister-of-scotland_5151556.html](https://www.theepochtimes.com/humza-yousaf-to-succeed-nicola-sturgeon-as-first-minister-of-scotland_5151556.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 15:24:48+00:00

Humza Yousaf speaking at Murrayfield Stadium in Edinburgh, after it was announced that he is the new Scottish National Party leader, and will become the next first minister of Scotland, on March 27, 2023. (PA Media)

## Is Elon Musk’s Growing Global Influence a Dilemma for the White House?
 - [https://www.theepochtimes.com/is-elon-musks-growing-global-influence-a-dilemma-for-the-white-house_5144236.html](https://www.theepochtimes.com/is-elon-musks-growing-global-influence-a-dilemma-for-the-white-house_5144236.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 15:21:55+00:00

Musk attends the opening ceremony of the new Tesla Gigafactory for electric cars in Gruenheide, Germany, on March 22, 2022. (Patrick Pleul/Pool via Reuters)

## Ethics Committee Approves New Lobbying Rules That Will ‘Legalize Bribery,’ Say Canadian Citizen Groups
 - [https://www.theepochtimes.com/ethics-committee-approves-new-lobbying-rules-that-will-legalize-bribery-say-canadian-citizen-groups_5151621.html](https://www.theepochtimes.com/ethics-committee-approves-new-lobbying-rules-that-will-legalize-bribery-say-canadian-citizen-groups_5151621.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 15:15:11+00:00

Commissioner of Lobbying Nancy Belanger speaks during an interview in her office in Ottawa on June 12, 2018. (Justin Tang/The Canadian Press)

## Border Crossings Returning to Pre-Pandemic Opening Hours
 - [https://www.theepochtimes.com/border-crossings-returning-to-pre-pandemic-opening-hours_5151824.html](https://www.theepochtimes.com/border-crossings-returning-to-pre-pandemic-opening-hours_5151824.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 15:11:27+00:00

Canadian and U.S. flags fly atop the Peace Arch monument at the Douglas-Peace Arch border crossing in Surrey, B.C., on Nov. 8, 2021. (The Canadian Press/Darryl Dyck)

## Canada Sanctions More Iran Guard Corps Members, Police After Toronto Rally Criticism
 - [https://www.theepochtimes.com/canada-sanctions-more-iran-guard-corps-members-police-after-toronto-rally-criticism_5151814.html](https://www.theepochtimes.com/canada-sanctions-more-iran-guard-corps-members-police-after-toronto-rally-criticism_5151814.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 15:07:39+00:00

Foreign Affairs Minister Melanie Joly rises during Question Period, Mar. 23, 2023 in Ottawa. (The Canadian Press/Adrian Wyld)

## Czech Republic Sends Large Delegation to Taiwan to Deepen Relations
 - [https://www.theepochtimes.com/czech-republic-sends-large-delegation-to-taiwan-to-deepen-relations_5151326.html](https://www.theepochtimes.com/czech-republic-sends-large-delegation-to-taiwan-to-deepen-relations_5151326.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 15:06:28+00:00

Taiwan's President Tsai Ing-wen speaks during a press conference at the presidential office in Taipei, Taiwan, on Dec. 27, 2022. (Sam Yeh/AFP via Getty Images)

## More Than 94,000 Prepayment Meters Forcibly Installed in UK Homes Last Year
 - [https://www.theepochtimes.com/more-than-94000-prepayment-meters-forcibly-installed-in-uk-homes-last-year_5151551.html](https://www.theepochtimes.com/more-than-94000-prepayment-meters-forcibly-installed-in-uk-homes-last-year_5151551.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 14:48:04+00:00

Undated photo of a gas hob next to a British Gas bill. (Owen Humphreys/PA Media)

## Reports About Closed COVID-19 Mass Quarantine Centers Attract International Attention
 - [https://www.theepochtimes.com/reports-about-closed-covid-19-mass-quarantine-centers-attract-international-attention_5150905.html](https://www.theepochtimes.com/reports-about-closed-covid-19-mass-quarantine-centers-attract-international-attention_5150905.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 14:42:19+00:00

Workers building a makeshift hospital that will be used for COVID-19 patients in China's southwestern city of Chongqing on Nov. 22, 2022. (CNS/AFP via Getty Images)

## London Metals Exchange Hit by Another Nickel Scam
 - [https://www.theepochtimes.com/london-metals-exchange-hit-by-another-nickel-scam_5150835.html](https://www.theepochtimes.com/london-metals-exchange-hit-by-another-nickel-scam_5150835.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 14:41:45+00:00

A sign for the London Metal Exchange (LME) on a wall by the new Ring, the open trading floor of the LME following its relocation in central London, on Feb. 18, 2016. (Leon Neal/AFP via Getty Images)

## Indonesia’s Pertamina Says 2 Crew Killed After Fire on Tanker
 - [https://www.theepochtimes.com/indonesias-pertamina-says-2-crew-killed-after-fire-on-tanker_5151296.html](https://www.theepochtimes.com/indonesias-pertamina-says-2-crew-killed-after-fire-on-tanker_5151296.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 14:38:59+00:00

Pertamina tanker, MT Kristin, carrying fuel, catches fire on the coast of Mataram, West Nusa Tenggara province, Indonesia, on March 26, 2023. (Antara Foto/Ahmad Subaidi/via Reuters)

## Deutsche Bank Shares Rebound as Stress on Banking Sector Eases
 - [https://www.theepochtimes.com/deutsche-bank-shares-rebound-as-stress-on-banking-sector-eases_5151492.html](https://www.theepochtimes.com/deutsche-bank-shares-rebound-as-stress-on-banking-sector-eases_5151492.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 14:31:06+00:00

A Deutsche Bank branch in Frankfurt am Main, Germany, on Feb. 4, 2021. (Armando Babani/AFP via Getty Images)

## Ancient Egypt Excavation Uncovers 2,000 Mummified Ram Heads at Abydos
 - [https://www.theepochtimes.com/ancient-egypt-excavation-uncovers-2000-mummified-ram-heads-at-abydos_5151323.html](https://www.theepochtimes.com/ancient-egypt-excavation-uncovers-2000-mummified-ram-heads-at-abydos_5151323.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 14:25:29+00:00

A mummified ram's head uncovered during excavation work by an American mission from New York University in Abydos, Sohag Governorate, Egypt, on March 25, 2023. (The Egyptian Ministry of Antiquities/Handout via Reuters)

## US Urges Israeli Leaders to Find Compromise Amid Political Turmoil
 - [https://www.theepochtimes.com/us-urges-israeli-leaders-to-find-compromise-amid-political-turmoil_5151496.html](https://www.theepochtimes.com/us-urges-israeli-leaders-to-find-compromise-amid-political-turmoil_5151496.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 14:17:43+00:00

Then-former Israeli Prime Minister Benjamin Netanyahu speaks during a rally in Jerusalem on April 6, 2022. (Ronen Zvulun/Reuters)

## Indonesia Security Forces Claim Suspected Papuan Rebel Killed in Shoot-Out
 - [https://www.theepochtimes.com/indonesia-security-forces-claim-suspected-papuan-rebel-killed-in-shoot-out_5151114.html](https://www.theepochtimes.com/indonesia-security-forces-claim-suspected-papuan-rebel-killed-in-shoot-out_5151114.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 13:56:24+00:00

Indonesian riot police take positions as fresh unrest broke out in Indonesia's restive Papua region in provincial capital Jayapura on Sept. 23, 2019. (Faisal Narwawan/AFP via Getty Images)

## Former Vancouver Mayor Says He Was Informed of Chinese Consulate Interference in City’s Election
 - [https://www.theepochtimes.com/former-vancouver-mayor-says-he-was-informed-of-chinese-consulate-interference-in-citys-election_5151405.html](https://www.theepochtimes.com/former-vancouver-mayor-says-he-was-informed-of-chinese-consulate-interference-in-citys-election_5151405.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 13:44:34+00:00

Then-Vancouver Mayor Kennedy Stewart speaks during a press conference in Vancouver on July 4, 2019. (The Canadian Press/Darryl Dyck)

## Toronto Police Say Man Seriously Injured in Stabbing on Board TTC Bus
 - [https://www.theepochtimes.com/toronto-police-say-man-seriously-injured-in-stabbing-on-board-ttc-bus_5151599.html](https://www.theepochtimes.com/toronto-police-say-man-seriously-injured-in-stabbing-on-board-ttc-bus_5151599.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 13:42:08+00:00

A Toronto Transit Commission sign is shown at a downtown Toronto subway stop on Jan. 31, 2023. (The Canadian Press/Graeme Roy)

## Conrad Black: A Tale of Two Countries: The Trajectory of Conservatism in Canada and US
 - [https://www.theepochtimes.com/conrad-black-a-tale-of-two-countries-the-trajectory-of-conservatism-in-canada-and-us_5150891.html](https://www.theepochtimes.com/conrad-black-a-tale-of-two-countries-the-trajectory-of-conservatism-in-canada-and-us_5150891.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 13:37:12+00:00

Canadian and American flags are seen at the U.S.–Canada border in Pittsburg, N.H., on March 1, 2017. (Don Emmert/AFP via Getty Images)

## Funeral for Two Edmonton Police Officers Shot and Killed Responding to Family Dispute
 - [https://www.theepochtimes.com/funeral-for-two-edmonton-police-officers-shot-and-killed-responding-to-family-dispute_5151560.html](https://www.theepochtimes.com/funeral-for-two-edmonton-police-officers-shot-and-killed-responding-to-family-dispute_5151560.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 13:25:04+00:00

Police salute during a procession to a funeral home for Const. Travis Jordan and Const. Brett Ryan in Edmonton on March 21, 2023. (The Canadian Press/Jason Franson)

## New Zealand Teetering Between China and Western Allies
 - [https://www.theepochtimes.com/new-zealand-teeters-between-china-and-western-allies-as-first-ministerial-visit-to-beijing-in-years-concludes_5151108.html](https://www.theepochtimes.com/new-zealand-teeters-between-china-and-western-allies-as-first-ministerial-visit-to-beijing-in-years-concludes_5151108.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 13:16:06+00:00

New Zealand Minister of Foreign Affairs Nanaia Mahuta speaks during a press conference at Parliament in Wellington, New Zealand on Oct. 4, 2022. (Hagen Hopkins/Getty Images)

## Blast Near Afghan Foreign Ministry Kills 6, Hurts Several
 - [https://www.theepochtimes.com/blast-near-afghan-foreign-ministry-kills-6-hurts-several_5151454.html](https://www.theepochtimes.com/blast-near-afghan-foreign-ministry-kills-6-hurts-several_5151454.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 12:40:33+00:00

An ambulance carries victims from near the site of a suicide attack in Kabul on March 27, 2023. (Wakil Kohsar/AFP via Getty Images)

## Hong Kong Remains the World’s Most Unaffordable City for Housing
 - [https://www.theepochtimes.com/hong-kong-remains-the-worlds-most-unaffordable-city-for-housing_5144139.html](https://www.theepochtimes.com/hong-kong-remains-the-worlds-most-unaffordable-city-for-housing_5144139.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 12:22:53+00:00

Properties as Lohas Park, Hong Kong on Aug. 20, 2022. (Bill Cox/The Epoch Times)

## Taiwan Accuses China of Interfering in Relations With Argentina
 - [https://www.theepochtimes.com/taiwan-accuses-china-of-interfering-in-relations-with-argentina_5150888.html](https://www.theepochtimes.com/taiwan-accuses-china-of-interfering-in-relations-with-argentina_5150888.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 11:59:35+00:00

The Chinese and Taiwanese printed flags, on April 28, 2022. (Dado Ruvic/Reuters)

## Delays to HS2’s Euston Leg May Lead to Higher Spending, Watchdog Warns
 - [https://www.theepochtimes.com/delays-to-hs2s-euston-leg-may-lead-to-higher-spending-watchdog-warns_5151351.html](https://www.theepochtimes.com/delays-to-hs2s-euston-leg-may-lead-to-higher-spending-watchdog-warns_5151351.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 11:17:05+00:00

Undated image of a graphic representation of the HS2 trains which would run between London and Birmingham. (Hitachi Rail-Alstom/PA)

## Rebellion on Illegal Migration Bill Seen Off for Now
 - [https://www.theepochtimes.com/rebellion-on-illegal-migration-bill-seen-off-for-now_5151335.html](https://www.theepochtimes.com/rebellion-on-illegal-migration-bill-seen-off-for-now_5151335.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 10:46:01+00:00

UK Home Secretary Suella Braverman arrives in Downing Street, central London, on March 7, 2023. (Leon Neal/Getty Images)

## Public Urged to Avoid Poole Harbour After Oil Leak Causes Major Incident
 - [https://www.theepochtimes.com/public-urged-to-avoid-poole-harbour-after-oil-leak-causes-major-incident_5151319.html](https://www.theepochtimes.com/public-urged-to-avoid-poole-harbour-after-oil-leak-causes-major-incident_5151319.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 10:35:38+00:00

An aerial view of poole harbour in dorset perched on the edge of world famous jurassic coast in this undated image. (Alamy Stock Photo/PA)

## Ultra-Orthodox Jews Have Lower Autism Rates–Is It Because They Circumcise Their Boys Differently?
 - [https://www.theepochtimes.com/health/ultra-orthodox-jews-have-lower-autism-rates-is-it-because-they-circumcise-their-boys-differently_5142854.html](https://www.theepochtimes.com/health/ultra-orthodox-jews-have-lower-autism-rates-is-it-because-they-circumcise-their-boys-differently_5142854.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 10:03:36+00:00

Mohel Manachem Fleischmann (L) concludes the circumcision ceremony of baby infant Mendl Teichtal at the Chabad Lubawitsch Orthodox Jewish synagogue on March 3, 2013 in Berlin, Germany. (Sean Gallup/Getty Images)

## EU Threatens More Sanctions If Russia Stations Tactical Nuclear Weapons in Belarus
 - [https://www.theepochtimes.com/eu-threatens-more-sanctions-if-russia-stations-tactical-nuclear-weapons-in-belarus_5151177.html](https://www.theepochtimes.com/eu-threatens-more-sanctions-if-russia-stations-tactical-nuclear-weapons-in-belarus_5151177.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 09:52:07+00:00

Russian President Vladimir Putin listens to Russian Transport Minister Vitaly Savelyev during their meeting in Moscow, Russia, on March 25, 2023. (Gavriil Grigorov, Sputnik, Kremlin Pool Photo via AP)

## Global Financial Risks Have Risen Amid Bank Turmoil, IMF Chief Warns
 - [https://www.theepochtimes.com/global-financial-risks-have-risen-amid-bank-turmoil-imf-chief-warns_5151047.html](https://www.theepochtimes.com/global-financial-risks-have-risen-amid-bank-turmoil-imf-chief-warns_5151047.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 09:09:24+00:00

IMF Managing Director Kristalina Georgieva participates in a town hall discussion with civil society organizations at IMF headquarters in Washington on Oct. 10, 2022. (Drew Angerer/Getty Images)

## Bolsonaro to Return to Brazil on March 30, His Party Says
 - [https://www.theepochtimes.com/bolsonaro-to-return-to-brazil-on-march-30-his-party-says_5148642.html](https://www.theepochtimes.com/bolsonaro-to-return-to-brazil-on-march-30-his-party-says_5148642.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 06:41:47+00:00

Jair Bolsonaro, former President of Brazil, arrives to speak at the Conservative Political Action Conference (CPAC) at Gaylord National Convention Center in National Harbor, Md., on March 4, 2023. (Evelyn Hockstein/Reuters)

## Taiwan Says Unreasonable Aid Demands Behind Honduras Switching Ties to China
 - [https://www.theepochtimes.com/taiwan-says-unreasonable-aid-demands-behind-honduras-switching-ties-to-china_5151046.html](https://www.theepochtimes.com/taiwan-says-unreasonable-aid-demands-behind-honduras-switching-ties-to-china_5151046.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 05:58:06+00:00

Taiwan's Foreign Minister Joseph Wu speaks during a press conference in Taipei, Taiwan, on March 26, 2023. (SAM YEH/AFP via Getty Images)

## Netanyahu Sacks Defence Minister as Military Reservists Threaten Refusal to Serve Over Judicial Reform Bill
 - [https://www.theepochtimes.com/netanyahu-sacks-defence-minister-as-military-reservists-threaten-refusal-to-serve-over-judicial-reform-bill_5150825.html](https://www.theepochtimes.com/netanyahu-sacks-defence-minister-as-military-reservists-threaten-refusal-to-serve-over-judicial-reform-bill_5150825.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 04:43:00+00:00

Protesters block a road and hold national flags during a rally against the Israeli government's judicial reform in Tel Aviv, Israel, on March 27, 2023. (AHMAD GHARABLI/AFP via Getty Images)

## Slain Officers’ Families Issue Statements Thanking Public for Support
 - [https://www.theepochtimes.com/slain-officers-families-issue-statements-thanking-public-for-support_5151013.html](https://www.theepochtimes.com/slain-officers-families-issue-statements-thanking-public-for-support_5151013.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 04:14:08+00:00

The family of Constable Brett Ryan look over flowers laid at a vigil for Ryan and fellow Constable Travis Jordan who were shot and killed while on duty, in Edmonton on March 17, 2023. (Jason Franson/The Canadian Press)

## New Research Reveals Alarming Gambling Trend Among Australians
 - [https://www.theepochtimes.com/new-research-reveals-alarming-gambling-trend-among-australians_5150983.html](https://www.theepochtimes.com/new-research-reveals-alarming-gambling-trend-among-australians_5150983.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 04:04:09+00:00

The betting hall at Wentworth Park in Sydney, Australia, on July 16, 2016. (Brook Mitchell/Getty Images)

## The CCP Consuming Russia in Its Desire for World Domination
 - [https://www.theepochtimes.com/the-ccp-consuming-russia-in-its-desire-for-world-domination_5150918.html](https://www.theepochtimes.com/the-ccp-consuming-russia-in-its-desire-for-world-domination_5150918.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 03:56:12+00:00

Russian President Vladimir Putin meets with Chinese leader Xi Jinping at the Kremlin in Moscow on March 21, 2023. (Sergei Karpukhin/SPUTNIK/AFP via Getty Images)

## No Advisory Body is Going to Close the Gap: Lidia Thorpe
 - [https://www.theepochtimes.com/no-advisory-body-is-going-to-close-the-gap-lidia-thorpe_5150769.html](https://www.theepochtimes.com/no-advisory-body-is-going-to-close-the-gap-lidia-thorpe_5150769.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 03:46:13+00:00

Australian Senator Lidia Thorpe addresses the media and crowd in Melbourne, Australia, on Nov. 15, 2022. (Photo by Tamati Smith/Getty Images)

## Longer Scripts Will Make GP Visits Cheaper: Doctors
 - [https://www.theepochtimes.com/longer-scripts-will-make-gp-visits-cheaper-doctors_5150820.html](https://www.theepochtimes.com/longer-scripts-will-make-gp-visits-cheaper-doctors_5150820.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 01:44:04+00:00

Various medicine pills in their original packaging in Brussels on Aug. 9, 2019. (Yves Herman/Illustration/Reuters)

## A Red Wave Sweeps Australia
 - [https://www.theepochtimes.com/a-red-wave-sweeps-australia_5150832.html](https://www.theepochtimes.com/a-red-wave-sweeps-australia_5150832.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 01:14:57+00:00

Labor leader and Premier elect Chris Minns during the NSW Labor reception in Sydney, Australia, on March 25, 2023. Labor won the election and will form a majority government after Premier Dominic Perrottet conceded defeat. (AAP Image/Dean Lewins)

## Daniel Andrews Announces Surprise Visit to China
 - [https://www.theepochtimes.com/daniel-andrews-announces-surprise-visit-to-china_5150771.html](https://www.theepochtimes.com/daniel-andrews-announces-surprise-visit-to-china_5150771.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-03-27 01:09:45+00:00

Victorian Premier Daniel Andrews delivers  his victory speech at the Labour election party in his seat of Mulgrave in Melbourne, Australia on Nov. 26, 2022. (Asanka Ratnayake/Getty Images)

