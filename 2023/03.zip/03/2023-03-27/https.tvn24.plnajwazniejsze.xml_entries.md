# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## Lewandowski zauważa: czas, by odpowiedzialność schodziła na wielu innych piłkarzy
 - [https://eurosport.tvn24.pl/lewandowski-po-meczu---czas---eby-odpowiedzialno---schodzi-a-na-wielu-innych-pi-karzy-,1141188.html?source=rss](https://eurosport.tvn24.pl/lewandowski-po-meczu---czas---eby-odpowiedzialno---schodzi-a-na-wielu-innych-pi-karzy-,1141188.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 21:16:58+00:00

<img alt="Lewandowski zauważa: czas, by odpowiedzialność schodziła na wielu innych piłkarzy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-190ev6-robert-lewandowski-nie-strzelil-gola-w-meczu-z-albania-6866275/alternates/LANDSCAPE_1280" />
    Kapitan kadry po meczu z Albanią.

## "W jakiejś części zmazaliśmy plamę"
 - [https://eurosport.tvn24.pl/-w-jakiej--cz--ci-zmazali-my-plam--,1141181.html?source=rss](https://eurosport.tvn24.pl/-w-jakiej--cz--ci-zmazali-my-plam--,1141181.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 21:03:45+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cre6b-karol-swiderski-6866069/alternates/LANDSCAPE_1280" />
    Na Karola Świderskiego można liczyć.

## Wołodymyr Zełenski rozmawiał z Andrzejem Dudą. "Przygotowujemy się na ważne wydarzenia"
 - [https://tvn24.pl/swiat/ukraina-wolodymyr-zelenski-po-rozmowie-z-andrzejem-duda-przygotowujemy-sie-na-wazne-wydarzenia-6865763?source=rss](https://tvn24.pl/swiat/ukraina-wolodymyr-zelenski-po-rozmowie-z-andrzejem-duda-przygotowujemy-sie-na-wazne-wydarzenia-6865763?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 21:00:16+00:00

<img alt="Wołodymyr Zełenski rozmawiał z Andrzejem Dudą. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-rnsz57-zelensky-6865867/alternates/LANDSCAPE_1280" />
    Wpis prezydenta Ukrainy.

## "Lewy" jednym z najsłabszych, dwóch bohaterów. Oceny
 - [https://eurosport.tvn24.pl/-lewy--jednym-z-najs-abszych--dw-ch-bohater-w--ocenili-my-polak-w-za-mecz,1141195.html?source=rss](https://eurosport.tvn24.pl/-lewy--jednym-z-najs-abszych--dw-ch-bohater-w--ocenili-my-polak-w-za-mecz,1141195.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 20:49:53+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-de2vqi-polska-albania-6864069/alternates/LANDSCAPE_1280" />
    W skali szkolnej 1-6.

## Czesi rozczarowali. Niespodzianka w drugim meczu naszej grupy
 - [https://eurosport.tvn24.pl/czesi-rozczarowali--niespodzianka-w-drugim-meczu-naszej-grupy,1141180.html?source=rss](https://eurosport.tvn24.pl/czesi-rozczarowali--niespodzianka-w-drugim-meczu-naszej-grupy,1141180.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 20:42:58+00:00

<img alt="Czesi rozczarowali. Niespodzianka w drugim meczu naszej grupy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pzvqy5-czesi-nie-poszli-za-ciosem-po-pokonaniu-polski-6865760/alternates/LANDSCAPE_1280" />
    Podopieczni Jaroslava Silhavy'ego tylko zremisowali z Mołdawią.

## Tabela i terminarz meczów Polaków
 - [https://eurosport.tvn24.pl/eliminacje-euro-2024--kiedy-gra-polska--terminarz-i-tabela-grupy-polak-w,1136407.html?source=rss](https://eurosport.tvn24.pl/eliminacje-euro-2024--kiedy-gra-polska--terminarz-i-tabela-grupy-polak-w,1136407.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 20:42:00+00:00

<img alt="Tabela i terminarz meczów Polaków" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lw3tm2-polacy-walczyli-niedawno-w-mundialu-w-katarze-6860501/alternates/LANDSCAPE_1280" />
    Biało-Czerwoni rozegrali dwa spotkania.

## Polacy nie porwali, ale Albania pokonana
 - [https://eurosport.tvn24.pl/polacy-nie-porwali--ale-albania-pokonana,1141176.html?source=rss](https://eurosport.tvn24.pl/polacy-nie-porwali--ale-albania-pokonana,1141176.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 20:35:56+00:00

<img alt="Polacy nie porwali, ale Albania pokonana" src="https://tvn24.pl/najnowsze/cdn-zdjecie-b9w1mi-radosc-polakow-6865744/alternates/LANDSCAPE_1280" />
    Polacy piłkarze mają pierwsze zwycięstwo w eliminacjach Euro 2024. Na Stadionie Narodowym w Warszawie pokonali Albanię 1:0.

## Linette przegrała w Miami. Faworytka przebudziła się w idealnym momencie
 - [https://eurosport.tvn24.pl/linette--egna-si--z-miami--faworytka-przebudzi-a-si--w-idealnym-momencie,1141198.html?source=rss](https://eurosport.tvn24.pl/linette--egna-si--z-miami--faworytka-przebudzi-a-si--w-idealnym-momencie,1141198.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 20:00:05+00:00

<img alt="Linette przegrała w Miami. Faworytka przebudziła się w idealnym momencie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8qxxca-magda-linette-6864065/alternates/LANDSCAPE_1280" />
    Polka robiła co mogła, ale rywalka okazała się za mocna.

## Popcorn skażony substancją produkowaną przez grzyby. Ostrzeżenie
 - [https://tvn24.pl/biznes/z-kraju/wycofanie-partii-popcornu-z-powodu-skazenia-grzybem-6864005?source=rss](https://tvn24.pl/biznes/z-kraju/wycofanie-partii-popcornu-z-powodu-skazenia-grzybem-6864005?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 19:46:27+00:00

<img alt="Popcorn skażony substancją produkowaną przez grzyby. Ostrzeżenie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9gqfnj-shutterstock_248123497-6864031/alternates/LANDSCAPE_1280" />
    Informuje Główny Inspektorat Sanitarny.

## Pokazał spryt i nie tylko. Świderski tę bramkę wyszarpał
 - [https://eurosport.tvn24.pl/w-polu-karnym-spryt-i-nie-tylko---widerski-t--bramk--wyszarpa-,1141184.html?source=rss](https://eurosport.tvn24.pl/w-polu-karnym-spryt-i-nie-tylko---widerski-t--bramk--wyszarpa-,1141184.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 19:45:52+00:00

<img alt="Pokazał spryt i nie tylko. Świderski tę bramkę wyszarpał" src="https://tvn24.pl/najnowsze/cdn-zdjecie-iadiis-karol-swiderski-i-strzal-ktory-dal-polsce-prowadzenie-6864043/alternates/LANDSCAPE_1280" />
    Był bohaterem pierwszej połowy meczu Polska – Albania.

## Disney rozpoczął zwolnienia. Pracę straci kilka tysięcy osób
 - [https://tvn24.pl/biznes/ze-swiata/disney-rozpoczal-zwolnienia-prace-straci-kilka-tysiecy-osob-6863996?source=rss](https://tvn24.pl/biznes/ze-swiata/disney-rozpoczal-zwolnienia-prace-straci-kilka-tysiecy-osob-6863996?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 19:26:43+00:00

<img alt="Disney rozpoczął zwolnienia. Pracę straci kilka tysięcy osób" src="https://tvn24.pl/najnowsze/cdn-zdjecie-w7iqd0-logo-disney-5511399/alternates/LANDSCAPE_1280" />
    Ma to dać 5,5 mld dolarów oszczędności.

## Premier nie zgadza się z prezydentem. Jego stanowisko trafiło do Trybunału Konstytucyjnego
 - [https://tvn24.pl/polska/zmiany-w-sadownictwie-nowelizacja-skierowana-do-tk-premier-nie-zgadza-sie-z-prezydentem-stanowisko-6863948?source=rss](https://tvn24.pl/polska/zmiany-w-sadownictwie-nowelizacja-skierowana-do-tk-premier-nie-zgadza-sie-z-prezydentem-stanowisko-6863948?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 19:14:34+00:00

<img alt="Premier nie zgadza się z prezydentem. Jego stanowisko trafiło do Trybunału Konstytucyjnego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-237bx6-trybunal-konstytucyjny-5451463/alternates/LANDSCAPE_1280" />
    W sprawie nowelizacji ustawy o Sądzie Najwyższym.

## Bodnar o "zaskakujących" słowach wiceszefa MSZ i rozprzestrzenianiu się "autorytarnego wirusa"
 - [https://tvn24.pl/polska/protesty-w-izraelu-w-sprawie-zmian-w-sadownictwie-adam-bodnar-o-slowach-wiceszefa-msz-pawla-jablonskiego-6863951?source=rss](https://tvn24.pl/polska/protesty-w-izraelu-w-sprawie-zmian-w-sadownictwie-adam-bodnar-o-slowach-wiceszefa-msz-pawla-jablonskiego-6863951?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 18:40:56+00:00

<img alt="Bodnar o " src="https://tvn24.pl/najnowsze/cdn-zdjecie-4wefxj-27-1930-fpf-gosc-0046-6863944/alternates/LANDSCAPE_1280" />
    Były rzecznik praw obywatelskich w "Faktach po Faktach" w TVN24.

## Liczy się tylko wygrana. Polacy chcą odzyskać zaufanie kibiców
 - [https://eurosport.tvn24.pl/polska---albania-w-eliminacjach-euro-2024--wynik-meczu-i-relacja-na--ywo,1141138.html?source=rss](https://eurosport.tvn24.pl/polska---albania-w-eliminacjach-euro-2024--wynik-meczu-i-relacja-na--ywo,1141138.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 18:33:00+00:00

<img alt="Liczy się tylko wygrana. Polacy chcą odzyskać zaufanie kibiców" src="https://tvn24.pl/najnowsze/cdn-zdjecie-k1t4g5-mid-23327583-6863990/alternates/LANDSCAPE_1280" />
    Relacja eurosport.pl ze spotkania z Albanią.

## Tramwaje mają opuszczone pantografy, jeżdżą bez prądu z sieci
 - [https://tvn24.pl/tvnwarszawa/bialoleka/warszawa-tramwaje-jezdza-bez-pantografu-6863892?source=rss](https://tvn24.pl/tvnwarszawa/bialoleka/warszawa-tramwaje-jezdza-bez-pantografu-6863892?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 18:16:13+00:00

<img alt="Tramwaje mają opuszczone pantografy, jeżdżą bez prądu z sieci" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-73wyg8-tramwaj-bez-zasilania-w-sieci-6863963/alternates/LANDSCAPE_1280" />
    Od poniedziałku, tramwaje linii 4. Film.

## Złote Blachy 2023 przyznane. Specjalne nagrody dla policjantów
 - [https://tvn24.pl/biznes/najnowsze/nagrody-koalicji-antypirackiej-zlote-blachy-2023-dla-policjantow-6863757?source=rss](https://tvn24.pl/biznes/najnowsze/nagrody-koalicji-antypirackiej-zlote-blachy-2023-dla-policjantow-6863757?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 18:12:37+00:00

<img alt="Złote Blachy 2023 przyznane. Specjalne nagrody dla policjantów" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-rvp8nm-wreczenie-nagrod-zlote-blachy-2023-6863875/alternates/LANDSCAPE_1280" />
    Wyróżnienia Koalicji Antypirackiej.

## Rada do spraw cyfryzacji ostrzega przed TikTokiem. Sekretarz stanu: to nie zmienia praktycznie nic
 - [https://tvn24.pl/biznes/z-kraju/rada-ds-cyfryzacji-rekomenduje-zakaz-tiktoka-w-polsce-na-urzadzeniach-sluzbowych-administracji-publicznej-6863883?source=rss](https://tvn24.pl/biznes/z-kraju/rada-ds-cyfryzacji-rekomenduje-zakaz-tiktoka-w-polsce-na-urzadzeniach-sluzbowych-administracji-publicznej-6863883?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 17:46:05+00:00

<img alt="Rada do spraw cyfryzacji ostrzega przed TikTokiem. Sekretarz stanu: to nie zmienia praktycznie nic" src="https://tvn24.pl/najnowsze/cdn-zdjecie-yi68w9-tiktok-shutterstock_1681173646-6863905/alternates/LANDSCAPE_1280" />
    Sekretarz stanu w KPRM Janusz Cieszyński komentuje na Twitterze.

## Nowe oszustwo "na zwrot podatku". Przestępcy chcą wyłudzić dane do bankowości
 - [https://tvn24.pl/biznes/najnowsze/oszustwo-na-zwrot-podatku-falszywe-maile-od-krajowej-administracji-skarbowej-i-ministerstwa-finansow-6863716?source=rss](https://tvn24.pl/biznes/najnowsze/oszustwo-na-zwrot-podatku-falszywe-maile-od-krajowej-administracji-skarbowej-i-ministerstwa-finansow-6863716?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 17:18:11+00:00

<img alt="Nowe oszustwo " src="https://tvn24.pl/najnowsze/cdn-zdjecie-gbqyyj-kobieta-uwierzyla-ze-rozmawia-z-pracownikiem-banku-zdj-ilustracyjne-6770909/alternates/LANDSCAPE_1280" />
    CERT Polska przestrzega.

## Trener Polaków reaguje. Wiele zmian w składzie na mecz z Albanią
 - [https://eurosport.tvn24.pl/oficjalny-sk-ad-polak-w-na-mecz-z-albani-,1141125.html?source=rss](https://eurosport.tvn24.pl/oficjalny-sk-ad-polak-w-na-mecz-z-albani-,1141125.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 17:16:25+00:00

<img alt="Trener Polaków reaguje. Wiele zmian w składzie na mecz z Albanią" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jb6awk-fernando-santos-6863868/alternates/LANDSCAPE_1280" />
    Poznaliśmy wyjściowe jedenastki.

## Dotacje dla organizacji byłych asystentów posłanki. Politycy Solidarnej Polski bronią Marii Kurowskiej
 - [https://fakty.tvn24.pl/dotacje-dla-organizacji-by-ych-asystent-w-pos-anki--politycy-solidarnej-polski-broni--marii-kurowskiej,1141161.html?source=rss](https://fakty.tvn24.pl/dotacje-dla-organizacji-by-ych-asystent-w-pos-anki--politycy-solidarnej-polski-broni--marii-kurowskiej,1141161.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 17:14:00+00:00

<img alt="Dotacje dla organizacji byłych asystentów posłanki. Politycy Solidarnej Polski bronią Marii Kurowskiej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-f1f0d6-pis-podzielil-wszystkie-organizacje-pozarzadowe-na-dwie-grupy-lewackie-i-te-w-ktorych-sa-dzialacze-pis-u-6863955/alternates/LANDSCAPE_1280" />
    Materiał "Faktów" TVN.

## "Są skłonni połowie Polaków odmawiać prawa do polskości"
 - [https://fakty.tvn24.pl/kontrowersyjne-s-owa-minister-moskwy---s--sk-onni-po-owie-polak-w-odmawia--prawa-do-polsko-ci-,1141151.html?source=rss](https://fakty.tvn24.pl/kontrowersyjne-s-owa-minister-moskwy---s--sk-onni-po-owie-polak-w-odmawia--prawa-do-polsko-ci-,1141151.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 17:13:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-f3fv98-27-6863957/alternates/LANDSCAPE_1280" />
    Komentarze po słowach minister Moskwy.

## "Nie znam szczegółów", "pierwsze słyszę". Politycy PiS lekceważą raport Departamentu Stanu USA
 - [https://fakty.tvn24.pl/-nie-znam-szczeg---w----pierwsze-s-ysz----politycy-pis-lekcewa---raport-departamentu-stanu-usa,1141152.html?source=rss](https://fakty.tvn24.pl/-nie-znam-szczeg---w----pierwsze-s-ysz----politycy-pis-lekcewa---raport-departamentu-stanu-usa,1141152.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 17:12:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-56uys1-27-6863960/alternates/LANDSCAPE_1280" />
    Prawa człowieka są w Polsce naruszane. Po czym widać to najbardziej? Po ograniczeniach pracy dziennikarzy i swobody wypowiedzi.

## Strzały w szkole w Nashville. Nie żyje troje dzieci
 - [https://tvn24.pl/swiat/usa-tennessee-strzelanina-w-szkole-w-nashville-nie-zyje-kilkoro-dzieci-zginal-napastnik-6863830?source=rss](https://tvn24.pl/swiat/usa-tennessee-strzelanina-w-szkole-w-nashville-nie-zyje-kilkoro-dzieci-zginal-napastnik-6863830?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 16:55:46+00:00

<img alt="Strzały w szkole w Nashville. Nie żyje troje dzieci " src="https://tvn24.pl/najnowsze/cdn-zdjecie-lurdef-strzelanina-w-szkole-w-nashville-6863843/alternates/LANDSCAPE_1280" />
    Napastnik zginął podczas interwencji funkcjonariuszy - przekazała lokalna policja.

## Strzały w szkole. Nie żyją dzieci
 - [https://tvn24.pl/swiat/usa-tennessee-strzelanina-w-szkole-w-nashville-nie-zyje-kilkoro-dzieci-zginela-napastniczka-6863830?source=rss](https://tvn24.pl/swiat/usa-tennessee-strzelanina-w-szkole-w-nashville-nie-zyje-kilkoro-dzieci-zginela-napastniczka-6863830?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 16:55:46+00:00

<img alt="Strzały w szkole. Nie żyją dzieci" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fveinp-strzelanina-w-szkole-w-nashville-6863843/alternates/LANDSCAPE_1280" />
    Napastnik zginął podczas interwencji funkcjonariuszy - przekazała lokalna policja.

## "Gorąca prośba" Tuska: Słuchajcie tego, co mówią. Oni mówią to serio
 - [https://tvn24.pl/polska/donald-tusk-na-spotkaniu-z-mieszkancami-strzelec-opolskich-6863755?source=rss](https://tvn24.pl/polska/donald-tusk-na-spotkaniu-z-mieszkancami-strzelec-opolskich-6863755?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 16:50:12+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fz0dq0-27-1645-tusk-0016-6863680/alternates/LANDSCAPE_1280" />
    Przewodniczący Platformy Obywatelskiej Donald Tusk na spotkaniu z mieszkańcami w Strzelcach Opolskich.

## "Jesteśmy świadkami strasznej tragedii". Osunęła się ziemia, wiele osób zginęło
 - [https://tvn24.pl/tvnmeteo/swiat/ekwador-osunela-sie-ziemia-po-ulewnych-deszczach-zabici-i-zaginieni-6863762?source=rss](https://tvn24.pl/tvnmeteo/swiat/ekwador-osunela-sie-ziemia-po-ulewnych-deszczach-zabici-i-zaginieni-6863762?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 16:46:12+00:00

<img alt="" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-opl7nm-osuniecie-ziemi-w-ekwadorze-6863792/alternates/LANDSCAPE_1280" />
    Osuwisko pochłonęło część miasta Alausi w Ekwadorze.

## "Wzgórze runęło jak rakieta". Ziemia osunęła się na domy, są zabici i ranni
 - [https://tvn24.pl/tvnmeteo/swiat/ekwador-osunela-sie-ziemia-po-ulewnych-deszczach-w-andach-zabici-i-ranni-6863762?source=rss](https://tvn24.pl/tvnmeteo/swiat/ekwador-osunela-sie-ziemia-po-ulewnych-deszczach-w-andach-zabici-i-ranni-6863762?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 16:46:12+00:00

<img alt="" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-onquec-ziemia-osunela-sie-w-ekwadorze-6863913/alternates/LANDSCAPE_1280" />
    Trwa akcja ratunkowa w Alausi w Ekwadorze.

## Atrakcyjna kobieta poznana w sieci poprosiła go o intymne zdjęcie. Wysłał je i wtedy się zaczęło
 - [https://tvn24.pl/tvnwarszawa/okolice/ostroleka-dal-sie-namowic-na-wyslanie-intymnego-zdjecia-pozniej-byl-szantaz-6863763?source=rss](https://tvn24.pl/tvnwarszawa/okolice/ostroleka-dal-sie-namowic-na-wyslanie-intymnego-zdjecia-pozniej-byl-szantaz-6863763?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 16:41:21+00:00

<img alt="Atrakcyjna kobieta poznana w sieci poprosiła go o intymne zdjęcie. Wysłał je i wtedy się zaczęło" src="https://tvn24.pl/najnowsze/cdn-zdjecief5288bc119dffe0653d2a3f64d8fe5c8-wyludzenia-w-internecie-staja-sie-coraz-powszechniejsze-4251712/alternates/LANDSCAPE_1280" />
    Szantażowała go, żądając pieniędzy.

## Parada planet pojawi się na nocnym niebie. "Jak perły w naszyjniku"
 - [https://tvn24.pl/tvnmeteo/nauka/parada-planet-2023-kiedy-czy-bedzie-widoczna-w-polsce-jakie-planety-ustawia-sie-w-jednej-linii-6862211?source=rss](https://tvn24.pl/tvnmeteo/nauka/parada-planet-2023-kiedy-czy-bedzie-widoczna-w-polsce-jakie-planety-ustawia-sie-w-jednej-linii-6862211?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 16:31:00+00:00

<img alt="Parada planet pojawi się na nocnym niebie. " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-izuiji-czym-jest-parada-planet-6862777/alternates/LANDSCAPE_1280" />
    Czy zjawisko będzie widoczne w Polsce? Jakie planety ustawią się w jednej linii?

## Kierowca F1 chciał sprawdzić Świątek. Zamknęła oczy i go zawstydziła
 - [https://eurosport.tvn24.pl/kierowca-f1-chcia--sprawdzi---wi-tek--polka-zamkn--a-oczy-i-go-zawstydzi-a,1141147.html?source=rss](https://eurosport.tvn24.pl/kierowca-f1-chcia--sprawdzi---wi-tek--polka-zamkn--a-oczy-i-go-zawstydzi-a,1141147.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 16:26:00+00:00

<img alt="Kierowca F1 chciał sprawdzić Świątek. Zamknęła oczy i go zawstydziła" src="https://tvn24.pl/najnowsze/cdn-zdjecie-h9eg6j-swiatek-spokojnie-wykonala-wyzwanie-od-gaslyego-6863796/alternates/LANDSCAPE_1280" />
    Dla Polki takie wyzwanie to pestka.

## Węgierski parlament za przyjęciem Finlandii do NATO
 - [https://tvn24.pl/najnowsze/wegry-parlament-za-przyjeciem-finlandii-do-nato-6863794?source=rss](https://tvn24.pl/najnowsze/wegry-parlament-za-przyjeciem-finlandii-do-nato-6863794?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 16:24:05+00:00

<img alt="Węgierski parlament za przyjęciem Finlandii do NATO" src="https://tvn24.pl/najnowsze/cdn-zdjecie-yqsmtb-finscy-zolnierze-6863819/alternates/LANDSCAPE_1280" />
    Przekazała agencja Reuters.

## Węgierski parlament za przyjęciem Finlandii do NATO
 - [https://tvn24.pl/swiat/wegry-parlament-za-przyjeciem-finlandii-do-nato-6863794?source=rss](https://tvn24.pl/swiat/wegry-parlament-za-przyjeciem-finlandii-do-nato-6863794?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 16:24:05+00:00

<img alt="Węgierski parlament za przyjęciem Finlandii do NATO" src="https://tvn24.pl/najnowsze/cdn-zdjecie-yqsmtb-finscy-zolnierze-6863819/alternates/LANDSCAPE_1280" />
    W sprawie wniosku akcesyjnego Szwecji parlament ma głosować w późniejszym terminie.

## Kontrowersyjna scena z igrzysk. Rosyjska trenerka żąda przeprosin
 - [https://eurosport.tvn24.pl/sporty-zimowe,130/eteri-tutberidze-trenerka-kamily-walijewej-oczekuje-przeprosin-od-thomasa-bacha-szefa-mkol-i-broni-swojej-podopiecznej,1141139.html?source=rss](https://eurosport.tvn24.pl/sporty-zimowe,130/eteri-tutberidze-trenerka-kamily-walijewej-oczekuje-przeprosin-od-thomasa-bacha-szefa-mkol-i-broni-swojej-podopiecznej,1141139.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 15:46:00+00:00

<img alt="Kontrowersyjna scena z igrzysk. Rosyjska trenerka żąda przeprosin " src="https://tvn24.pl/najnowsze/cdn-zdjecie-lm8h64-walijewa-igrzyska-6863732/alternates/LANDSCAPE_1280" />
    Wróciła do sprawy zachowania wobec Kamiły Walijewej.

## Chiny komentują zapowiedź Putina w sprawie rozmieszczenia broni jądrowej na Białorusi
 - [https://tvn24.pl/swiat/bialorus-wladimir-putin-zapowiada-rozmieszczenie-broni-jadrowej-na-bialorusi-odpowiedz-chin-6863670?source=rss](https://tvn24.pl/swiat/bialorus-wladimir-putin-zapowiada-rozmieszczenie-broni-jadrowej-na-bialorusi-odpowiedz-chin-6863670?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 15:45:40+00:00

<img alt="Chiny komentują zapowiedź Putina w sprawie rozmieszczenia broni jądrowej na Białorusi" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4pkera-wladimir-putin-6847089/alternates/LANDSCAPE_1280" />
    Rzeczniczka chińskiego MSZ przypomniała o wspólnej deklaracji mocarstw nuklearnych.

## Obietnice minus. Co PiS obiecywał w sprawie budowy mieszkań i rynku mieszkaniowego
 - [https://konkret24.tvn24.pl/polityka/obietnice-minus-co-pis-obiecywal-w-sprawie-budowy-mieszkan-i-rynku-mieszkaniowego-lista-6858048?source=rss](https://konkret24.tvn24.pl/polityka/obietnice-minus-co-pis-obiecywal-w-sprawie-budowy-mieszkan-i-rynku-mieszkaniowego-lista-6858048?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 15:44:35+00:00

<img alt="Obietnice minus. Co PiS obiecywał w sprawie budowy mieszkań i rynku mieszkaniowego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-58r2w8-obietnice-minus-czesc-1-mieszkania-drv-6863766/alternates/LANDSCAPE_1280" />
    Na starcie kolejnej kampanii wyborczej postanowiliśmy sprawdzić i przypomnieć te obietnice Prawa i Sprawiedliwości, których wypełnić się nie udało.

## Autobus szkolny zderzył się z samochodem i uderzył w drzewo
 - [https://tvn24.pl/tvnwarszawa/najnowsze/wierzbica-kolo-legionowa-autobus-szkolny-zderzyl-sie-z-autem-osobowym-pozniej-wjechal-w-drzewo-dwie-osoby-ranne-w-tym-dziecko-6863695?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/wierzbica-kolo-legionowa-autobus-szkolny-zderzyl-sie-z-autem-osobowym-pozniej-wjechal-w-drzewo-dwie-osoby-ranne-w-tym-dziecko-6863695?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 15:35:13+00:00

<img alt="Autobus szkolny zderzył się z samochodem i uderzył w drzewo" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-2s3kci-dwie-osoby-trafily-do-szpitala-6863715/alternates/LANDSCAPE_1280" />
    W miejscowości Wierzbica pod Legionowem.

## Po potrąceniu nie chciała pomocy. Następnego dnia okazało, że ma złamaną miednicę
 - [https://tvn24.pl/tvnwarszawa/okolice/makow-mazowiecki-po-potraceniu-nie-chciala-pomocy-nastepnego-dnia-okazalo-ze-ma-zlamana-miednice-6863656?source=rss](https://tvn24.pl/tvnwarszawa/okolice/makow-mazowiecki-po-potraceniu-nie-chciala-pomocy-nastepnego-dnia-okazalo-ze-ma-zlamana-miednice-6863656?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 15:28:56+00:00

<img alt="Po potrąceniu nie chciała pomocy. Następnego dnia okazało, że ma złamaną miednicę" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-ulsh97-potracenie-pieszej-w-makowie-mazowieckim-6863660/alternates/LANDSCAPE_1280" />
    Policjanci dostali nagranie i dotarli do pieszej oraz do kierowcy.

## Efekt brexitu. Wielka Brytania mierzy się z "największym spadkiem poziomu życia" w historii
 - [https://tvn24.pl/biznes/ze-swiata/wielka-brytania-obr-ocenia-jak-brexit-wplynal-na-gospodarke-najwiekszy-spadek-poziomu-zycia-6863375?source=rss](https://tvn24.pl/biznes/ze-swiata/wielka-brytania-obr-ocenia-jak-brexit-wplynal-na-gospodarke-najwiekszy-spadek-poziomu-zycia-6863375?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 15:16:33+00:00

<img alt="Efekt brexitu. Wielka Brytania mierzy się z " src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-glkovz-wielka-brytania-warzywa-brak-6778324/alternates/LANDSCAPE_1280" />
    "Straciliśmy około 500 tysięcy pracowników".

## Albańczycy pokonani. Młodzi Polacy dali przykład podopiecznym Santosa
 - [https://eurosport.tvn24.pl/alba-czycy-pokonani--m-odzi-polacy-dali-przyk-ad-podopiecznym-santosa,1141135.html?source=rss](https://eurosport.tvn24.pl/alba-czycy-pokonani--m-odzi-polacy-dali-przyk-ad-podopiecznym-santosa,1141135.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 15:03:08+00:00

<img alt="Albańczycy pokonani. Młodzi Polacy dali przykład podopiecznym Santosa" src="https://tvn24.pl/najnowsze/cdn-zdjecie-17yw53-polska-mlodziezowka-nie-miala-problemow-z-pokonaniem-albanii-6863674/alternates/LANDSCAPE_1280" />
    Reprezentacja Polski do lat 21 wygrał mecz towarzyski rozegrany w Turcji.

## Trybuny w Miami przeciwko Ostapenko
 - [https://eurosport.tvn24.pl/trybuny-w-miami-przeciwko-ostapenko---zachowywali-si--troch--lekcewa--co-,1141142.html?source=rss](https://eurosport.tvn24.pl/trybuny-w-miami-przeciwko-ostapenko---zachowywali-si--troch--lekcewa--co-,1141142.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 14:47:46+00:00

<img alt="Trybuny w Miami przeciwko Ostapenko" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7eatst-jelena-ostapenko-dobrze-radzi-sobie-w-miami-6863662/alternates/LANDSCAPE_1280" />
    "Zachowywali się trochę lekceważąco".

## W koszyku zakupy za ponad trzy tysiące. Wyszedł bez płacenia
 - [https://tvn24.pl/tvnwarszawa/okolice/sierpc-w-koszyku-mial-zakupy-za-ponad-trzy-tysiace-ze-sklepu-wyszedl-bez-placenia-6863575?source=rss](https://tvn24.pl/tvnwarszawa/okolice/sierpc-w-koszyku-mial-zakupy-za-ponad-trzy-tysiace-ze-sklepu-wyszedl-bez-placenia-6863575?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 14:23:41+00:00

<img alt="W koszyku zakupy za ponad trzy tysiące. Wyszedł bez płacenia" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ar7jzh-sklep-market-koszyk-zakupy-shutterstock1688252332-5421612/alternates/LANDSCAPE_1280" />
    Po godzinie ustalili tożsamość podejrzanego o kradzież.

## "Pobili go na śmierć i wyrzucili z celi jak zwierzę"
 - [https://tvn24.pl/swiat/salwador-pobili-go-na-smierc-i-wyrzucili-z-celi-jak-zwierze-wstrzasajaca-relacja-z-pobytu-w-tamtejszym-wiezieniu-6863430?source=rss](https://tvn24.pl/swiat/salwador-pobili-go-na-smierc-i-wyrzucili-z-celi-jak-zwierze-wstrzasajaca-relacja-z-pobytu-w-tamtejszym-wiezieniu-6863430?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 14:20:25+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-onzhge-salwador-kolejny-transport-wiezniow-6842406/alternates/LANDSCAPE_1280" />
    Wstrząsająca relacja z pobytu w więzieniu w Salwadorze.

## Porzuciła bezpieczną Polskę, gdy tylko wybuchła wojna. "Rodzice do tej pory w pełni się nie pogodzili"
 - [https://tvn24.pl/go/programy,7/opinie-i-wydarzenia-odcinki,16593/odcinek-3105,S00E3105,1027832?source=rss](https://tvn24.pl/go/programy,7/opinie-i-wydarzenia-odcinki,16593/odcinek-3105,S00E3105,1027832?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 14:00:00+00:00

<img alt="Porzuciła bezpieczną Polskę, gdy tylko wybuchła wojna. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-gahb6x-viktoria-czarkowska-6862956/alternates/LANDSCAPE_1280" />
    Viktoria ma 23 lata. Jej niewielki zespół ewakuuje z terenów działań wojennych w Ukrainie tych, którzy bali się lub nie mogli wcześniej uciec.

## Upadłość banku SVB. Znalazł się na niego nabywca
 - [https://tvn24.pl/biznes/ze-swiata/upadlosc-banku-svb-first-citizens-bank-przejmie-jego-aktywa-6863535?source=rss](https://tvn24.pl/biznes/ze-swiata/upadlosc-banku-svb-first-citizens-bank-przejmie-jego-aktywa-6863535?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 13:57:21+00:00

<img alt="Upadłość banku SVB. Znalazł się na niego nabywca" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ev530p-shutterstock_1633395511-6822570/alternates/LANDSCAPE_1280" />
    Podał amerykański urząd.

## Trzeci miesiąc z rzędu spada oprocentowanie lokat
 - [https://tvn24.pl/biznes/z-kraju/oprocentowanie-lokat-i-rachunkow-oszczednosciowych-marzec-2023-6863422?source=rss](https://tvn24.pl/biznes/z-kraju/oprocentowanie-lokat-i-rachunkow-oszczednosciowych-marzec-2023-6863422?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 13:22:48+00:00

<img alt="Trzeci miesiąc z rzędu spada oprocentowanie lokat" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjeciea262b92fbbfa5b76d83fd382f46179aa-polacy-trzymaja-miliardy-zlotych-na-lokatach-ktore-nie-daja-zarobic-4558564/alternates/LANDSCAPE_1280" />
    Analiza HRE Investments.

## 18-latek stracił prawo jazdy, które odebrał kilka godzin wcześniej
 - [https://tvn24.pl/pomorze/chojnice-18-latek-stracil-prawo-jazdy-ktore-odebral-kilka-godzin-wczesniej-jechal-za-szybko-6863386?source=rss](https://tvn24.pl/pomorze/chojnice-18-latek-stracil-prawo-jazdy-ktore-odebral-kilka-godzin-wczesniej-jechal-za-szybko-6863386?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 13:14:46+00:00

<img alt="18-latek stracił prawo jazdy, które odebrał kilka godzin wcześniej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-yf8jlp-18-latek-za-predkosc-stracil-prawo-jazdy-ktore-mial-zaledwie-od-kilku-godzin-6863384/alternates/LANDSCAPE_1280" />
    Jechał z prędkością 109 km/h.

## Skradziono dane prawie ośmiu milionów kierowców
 - [https://tvn24.pl/swiat/australia-skradziono-dane-prawie-osmiu-milionow-kierowcow-z-baz-latitude-holdings-6863473?source=rss](https://tvn24.pl/swiat/australia-skradziono-dane-prawie-osmiu-milionow-kierowcow-z-baz-latitude-holdings-6863473?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 13:07:51+00:00

<img alt="Skradziono dane prawie ośmiu milionów kierowców" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9c9pie-hakerzy-dezinformacja-5149174/alternates/LANDSCAPE_1280" />
     O ogromnym wycieku danych poinformowała firma Latitude Holdings.

## Zasypiała z rakietą na poduszce. I co z tego, że za dużą?
 - [https://tvn24.pl/premium/zasypiala-z-rakieta-na-poduszce-i-co-z-tego-ze-za-duza-jak-magda-linette-zostala-tenisistka-6750055?source=rss](https://tvn24.pl/premium/zasypiala-z-rakieta-na-poduszce-i-co-z-tego-ze-za-duza-jak-magda-linette-zostala-tenisistka-6750055?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 12:57:25+00:00

<img alt="Zasypiała z rakietą na poduszce. I co z tego, że za dużą?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-famsbo-magda-linette-rozpoczela-kariere-bardzo-wczesnie-6749215/alternates/LANDSCAPE_1280" />
    Bez pomocy rodziny, dziadka i babci w szczególności, nic by z tej kariery nie wyszło. Wozili, gotowali, pocieszali i mobilizowali, a kiedy w domowym budżecie z pieniędzmi było naprawdę krucho, sięgali po emerytury. W styczniu ich wnuczka Magda Linette zadziwiła świat, docierając w dalekim Melbourne do półfinału Australian Open. A dopiero co w wielce prestiżowej imprezie rozgrywanej w Miami odprawiła byłą liderkę rankingu, Białorusinkę Wiktorię Azarenkę. Dziś jej przeciwniczką będzie trzecia rakieta świata Jessica Pegula.

## Nakaz zamknięcia firmy za nieprzestrzeganie postu
 - [https://tvn24.pl/swiat/iran-lokale-nie-przestrzegaja-zasad-ramadanu-dostaja-nakaz-zamkniecia-od-policji-6863416?source=rss](https://tvn24.pl/swiat/iran-lokale-nie-przestrzegaja-zasad-ramadanu-dostaja-nakaz-zamkniecia-od-policji-6863416?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 12:54:31+00:00

<img alt="Nakaz zamknięcia firmy za nieprzestrzeganie postu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fij3b4-rozpoczeto-obchody-ramadanu-6863286/alternates/LANDSCAPE_1280" />
    Policja zapowiada kolejne kontrole.

## Otworzył drzwi samolotu i uciekł awaryjną zjeżdżalnią tuż przed startem
 - [https://tvn24.pl/swiat/usa-otworzyl-drzwi-samolotu-i-uciekl-awaryjna-zjezdzalnia-tuz-przed-startem-6863150?source=rss](https://tvn24.pl/swiat/usa-otworzyl-drzwi-samolotu-i-uciekl-awaryjna-zjezdzalnia-tuz-przed-startem-6863150?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 12:53:26+00:00

<img alt="Otworzył drzwi samolotu i uciekł awaryjną zjeżdżalnią tuż przed startem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ft8k5q-boeing-737-delta-airlines-samolot-lotnisko-plane-airport-shutterstock_236239246-6863196/alternates/LANDSCAPE_1280" />
    Mężczyzna został zatrzymany.

## Nawet 28 tysięcy złotych dopłaty. Wkrótce ma ruszyć kolejna odsłona rządowego programu
 - [https://tvn24.pl/biznes/pieniadze/wiceszef-nfosigw-od-44-tys-zl-do-28-tys-zl-doplaty-do-pomp-ciepla-w-piatej-edycji-mojego-pradu-6863201?source=rss](https://tvn24.pl/biznes/pieniadze/wiceszef-nfosigw-od-44-tys-zl-do-28-tys-zl-doplaty-do-pomp-ciepla-w-piatej-edycji-mojego-pradu-6863201?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 12:35:17+00:00

<img alt="Nawet 28 tysięcy złotych dopłaty. Wkrótce ma ruszyć kolejna odsłona rządowego programu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9vuq3k-pompa-ciepla-shutterstock_2216924667-6850203/alternates/LANDSCAPE_1280" />
    Szczegóły.

## Khusru i Liliosa w walce o pogodową dominację nad Polską
 - [https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-5-dni-niz-khusru-i-wyz-liliosa-zawalcza-o-pogodowa-dominacje-nad-polska-6863257?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-5-dni-niz-khusru-i-wyz-liliosa-zawalcza-o-pogodowa-dominacje-nad-polska-6863257?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 12:35:08+00:00

<img alt="Khusru i Liliosa w walce o pogodową dominację nad Polską" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-du6qn4-forsycja-w-deszczu-6863276/alternates/LANDSCAPE_1280" />
    Sprawdź prognozę na 5 dni.

## Premier zapowiada "wieloletni program wspierania produkcji amunicji"
 - [https://tvn24.pl/polska/premier-zapowiada-wieloletni-program-wspierania-produkcji-amunicji-6863400?source=rss](https://tvn24.pl/polska/premier-zapowiada-wieloletni-program-wspierania-produkcji-amunicji-6863400?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 12:30:50+00:00

<img alt="Premier zapowiada " src="https://tvn24.pl/najnowsze/cdn-zdjecie-dd5op7-konfa-6863338/alternates/LANDSCAPE_1280" />
    Według niego amunicji w całej Europie, a nawet NATO, jest zbyt mało.

## Albański piłkarz Legii o reprezentacji Polski: nie jest jak przed mundialem
 - [https://eurosport.tvn24.pl/alba-ski-pi-karz-legii-o-reprezentacji-polski--nie-jest-jak-przed-mundialem,1141122.html?source=rss](https://eurosport.tvn24.pl/alba-ski-pi-karz-legii-o-reprezentacji-polski--nie-jest-jak-przed-mundialem,1141122.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 12:28:58+00:00

<img alt="Albański piłkarz Legii o reprezentacji Polski: nie jest jak przed mundialem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-c218h5-ernest-muci-6863437/alternates/LANDSCAPE_1280" />
    Ernest Muci spotkanie oglądać będzie w roli kibica.

## Drastyczny wzrost zachorowań na raka. Winna między innymi pandemia
 - [https://tvn24.pl/bialystok/bialystok-drastyczny-wzrost-zachorowan-na-raka-winna-miedzy-innymi-pandemia-6863157?source=rss](https://tvn24.pl/bialystok/bialystok-drastyczny-wzrost-zachorowan-na-raka-winna-miedzy-innymi-pandemia-6863157?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 12:24:04+00:00

<img alt="Drastyczny wzrost zachorowań na raka. Winna między innymi pandemia" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2og7ur-szpital-lozko-shutterstock_104336624-6767349/alternates/LANDSCAPE_1280" />
    Według lekarzy, świadczy to o fatalnej profilaktyce.

## Motocyklista nie żyje, areszt dla kierowcy auta osobowego
 - [https://tvn24.pl/tvnwarszawa/ulice/izdebno-kolonia-mazowsze-motocyklista-nie-zyje-areszt-dla-kierowcy-auta-osobowego-6863300?source=rss](https://tvn24.pl/tvnwarszawa/ulice/izdebno-kolonia-mazowsze-motocyklista-nie-zyje-areszt-dla-kierowcy-auta-osobowego-6863300?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 12:18:16+00:00

<img alt="Motocyklista nie żyje, areszt dla kierowcy auta osobowego" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-nso94k-tymczasowy-areszt-dla-26-latka-podejrzanego-o-spowodowanie-smiertelnego-wypadku-6863301/alternates/LANDSCAPE_1280" />
    Do tragedii doszło podczas wyprzedzania.

## Miał wrzucić do drinka trutkę na szczury. Agent nieruchomości oskarżony o zabójstwo studentki
 - [https://tvn24.pl/swiat/japonia-mial-wrzucic-do-drinka-trutke-na-szczury-agent-nieruchomosci-oskarzony-o-zabojstwo-studentki-6863084?source=rss](https://tvn24.pl/swiat/japonia-mial-wrzucic-do-drinka-trutke-na-szczury-agent-nieruchomosci-oskarzony-o-zabojstwo-studentki-6863084?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 12:13:54+00:00

<img alt="Miał wrzucić do drinka trutkę na szczury. Agent nieruchomości oskarżony o zabójstwo studentki" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wwtfi9-shutterstock_1910372983-6863135/alternates/LANDSCAPE_1280" />
    21-latka zmarła kilka dni później.

## Niecodzienna interwencja strażaków. Pies zakleszczył się w zderzaku
 - [https://tvn24.pl/lodz/zarnow-soczowki-pies-wbiegl-pod-samochod-i-zakleszczyl-sie-w-zderzaku-pomogli-strazacy-6862763?source=rss](https://tvn24.pl/lodz/zarnow-soczowki-pies-wbiegl-pod-samochod-i-zakleszczyl-sie-w-zderzaku-pomogli-strazacy-6862763?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 12:13:10+00:00

<img alt="Niecodzienna interwencja strażaków. Pies zakleszczył się w zderzaku" src="https://tvn24.pl/najnowsze/cdn-zdjecie-38i3e-strazacy-wyciagali-zakleszczonego-w-zderzaku-psa-6862643/alternates/LANDSCAPE_1280" />
    Musieli użyć nożyc hydraulicznych.

## Błażej Kmieciak rezygnuje z funkcji przewodniczącego Państwowej Komisji ds. pedofilii
 - [https://tvn24.pl/polska/blazej-kmieciak-zlozyl-rezygnacje-z-funkcji-przewodniczacego-panstwowej-komisji-ds-pedofilii-6863320?source=rss](https://tvn24.pl/polska/blazej-kmieciak-zlozyl-rezygnacje-z-funkcji-przewodniczacego-panstwowej-komisji-ds-pedofilii-6863320?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 11:49:45+00:00

<img alt="Błażej Kmieciak rezygnuje z funkcji przewodniczącego Państwowej Komisji ds. pedofilii" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wgy2g8-blazej-kmieciak-6863369/alternates/LANDSCAPE_1280" />
    Oświadczenie.

## Błażej Kmieciak rezygnuje. "Nie było żadnych nacisków"
 - [https://tvn24.pl/polska/blazej-kmieciak-zlozyl-rezygnacje-z-funkcji-przewodniczacego-panstwowej-komisji-ds-pedofilii-nie-bylo-zadnych-naciskow-6863320?source=rss](https://tvn24.pl/polska/blazej-kmieciak-zlozyl-rezygnacje-z-funkcji-przewodniczacego-panstwowej-komisji-ds-pedofilii-nie-bylo-zadnych-naciskow-6863320?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 11:49:45+00:00

<img alt="Błażej Kmieciak rezygnuje. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-wgy2g8-blazej-kmieciak-6863369/alternates/LANDSCAPE_1280" />
    Oświadczenie.

## Finałowy sezon "Sukcesji" już w HBO Max. "Jest wielkim znakiem zapytania"
 - [https://tvn24.pl/kultura-i-styl/sukcesja-4-sezon-w-hbo-max-nowy-sezon-jest-wielkim-znakiem-zapytania-6862764?source=rss](https://tvn24.pl/kultura-i-styl/sukcesja-4-sezon-w-hbo-max-nowy-sezon-jest-wielkim-znakiem-zapytania-6862764?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 11:48:06+00:00

<img alt="Finałowy sezon " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ciivi2-sukcesja-od-7-marca-w-tvn-6768073/alternates/LANDSCAPE_1280" />
    "Nie wiemy, kto pozostanie na placu boju".

## Nawet pół miliona rocznie dla spółki przyjaciela członka zarządu Orlenu
 - [https://tvn24.pl/biznes/z-kraju/spolki-skarbu-panstwa-pol-miliona-rocznie-dla-przyjaciela-czlonka-zarzadu-orlenu-6862955?source=rss](https://tvn24.pl/biznes/z-kraju/spolki-skarbu-panstwa-pol-miliona-rocznie-dla-przyjaciela-czlonka-zarzadu-orlenu-6862955?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 11:42:08+00:00

<img alt="Nawet pół miliona rocznie dla spółki przyjaciela członka zarządu Orlenu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xwyp4g-shutterstock2152259391-6775314/alternates/LANDSCAPE_1280" />
    Na ustalenia Onetu odpowiada PKN Orlen.

## Fragment przesłuchania Gwyneth Paltrow stał się hitem sieci
 - [https://tvn24.pl/kultura-i-styl/proces-gwyneth-paltrow-wideo-z-fragmentem-przesluchania-aktorki-hitem-sieci-6863151?source=rss](https://tvn24.pl/kultura-i-styl/proces-gwyneth-paltrow-wideo-z-fragmentem-przesluchania-aktorki-hitem-sieci-6863151?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 11:41:15+00:00

<img alt="Fragment przesłuchania Gwyneth Paltrow stał się hitem sieci" src="https://tvn24.pl/najnowsze/cdn-zdjecie-icp7e1-gwyneth-paltrow-przesluchiwana-przez-kristin-vanorman-6862987/alternates/LANDSCAPE_1280" />
    Media zwracają uwagę na "dziwaczne" pytania.

## Kolumbijski kolarz zderzył się z samochodem. Kamera uchwyciła dramatyczny wypadek
 - [https://eurosport.tvn24.pl/kolumbijski-kolarz-zderzy--si--z-samochodem--kamera-uchwyci-a-dramatyczny-wypadek,1141114.html?source=rss](https://eurosport.tvn24.pl/kolumbijski-kolarz-zderzy--si--z-samochodem--kamera-uchwyci-a-dramatyczny-wypadek,1141114.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 11:39:15+00:00

<img alt="Kolumbijski kolarz zderzył się z samochodem. Kamera uchwyciła dramatyczny wypadek" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6pj1tw-juan-sebastian-molano-6863305/alternates/LANDSCAPE_1280" />
    W pobliżu belgijskiej miejscowości Waregem.

## Mecz z Albanią przy zamkniętym dachu
 - [https://eurosport.tvn24.pl/mecz-z-albani--przy-zamkni-tym-dachu,1141120.html?source=rss](https://eurosport.tvn24.pl/mecz-z-albani--przy-zamkni-tym-dachu,1141120.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 11:26:34+00:00

<img alt="Mecz z Albanią przy zamkniętym dachu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-up5vlo-podczas-meczu-polska-albania-dach-pge-narodowego-bedzie-zamkniety-6863269/alternates/LANDSCAPE_1280" />
    Ogłoszono po spotkaniu delegata UEFA z przedstawicielami PZPN.

## Klientka uwięziona w sklepie. Obsługa nie zauważyła jej, zamknęła drzwi i poszła do domu
 - [https://tvn24.pl/pomorze/klientka-uwieziona-w-sklepie-obsluga-nie-zauwazyla-jej-zamknela-drzwi-i-poszla-do-domu-6862855?source=rss](https://tvn24.pl/pomorze/klientka-uwieziona-w-sklepie-obsluga-nie-zauwazyla-jej-zamknela-drzwi-i-poszla-do-domu-6862855?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 11:24:28+00:00

<img alt="Klientka uwięziona w sklepie. Obsługa nie zauważyła jej, zamknęła drzwi i poszła do domu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5utdtp-klientka-zostala-zamknieta-w-sklepie-6862860/alternates/LANDSCAPE_1280" />
    Interweniować musiały policja i straż pożarna.

## W tej branży pracę straciło nawet 60 tysięcy osób
 - [https://tvn24.pl/biznes/z-kraju/krd-rosnie-zadluzenie-branzy-meblarskiej-do-ponad-101-mln-zl-6862923?source=rss](https://tvn24.pl/biznes/z-kraju/krd-rosnie-zadluzenie-branzy-meblarskiej-do-ponad-101-mln-zl-6862923?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 11:24:12+00:00

<img alt="W tej branży pracę straciło nawet 60 tysięcy osób" src="https://tvn24.pl/najnowsze/cdn-zdjecie-f9hnft-meble-produkcja-shutterstock516941086-6146150/alternates/LANDSCAPE_1280" />
    Od kilku miesięcy zadłużenie tego segmentu rośnie.

## Sytuacja w Awdijiwce porównywalna jest z Bachmutem. "Jeśli zostaną w mieście, to będzie źle"
 - [https://tvn24.pl/swiat/wojna-w-ukrainie-awdijiwka-pracownicy-sluzb-komunalnych-ewakuowani-z-miasta-sytuacja-porownywalna-z-bachmutem-6863121?source=rss](https://tvn24.pl/swiat/wojna-w-ukrainie-awdijiwka-pracownicy-sluzb-komunalnych-ewakuowani-z-miasta-sytuacja-porownywalna-z-bachmutem-6863121?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 11:09:29+00:00

<img alt="Sytuacja w Awdijiwce porównywalna jest z Bachmutem. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-wocokf-zniszcenia-w-awdijiwce-w-obwodzie-donieckim-6789386/alternates/LANDSCAPE_1280" />
    Mer miasta Witalij Barbasz poinformował o ewakuacji pracowników służb komunalnych.

## Ktoś włożył psa do reklamówki, zawiązał ją i wyrzucił w lesie
 - [https://tvn24.pl/krakow/zarzecze-ktos-wsadzil-do-reklamowki-psa-zawiazal-i-wyrzucil-w-lesie-policjanci-znalezli-mu-dom-szukaja-tez-sprawcy-6862577?source=rss](https://tvn24.pl/krakow/zarzecze-ktos-wsadzil-do-reklamowki-psa-zawiazal-i-wyrzucil-w-lesie-policjanci-znalezli-mu-dom-szukaja-tez-sprawcy-6862577?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 11:05:05+00:00

<img alt="Ktoś włożył psa do reklamówki, zawiązał ją i wyrzucił w lesie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-di5wot-policja-szuka-osoby-lub-osob-ktore-porzucily-psa-w-lesie-6862607/alternates/LANDSCAPE_1280" />
    Policjanci uratowali zwierzę i znaleźli mu dom.

## Śnieg na Dolnym Śląsku. "Inny świat"
 - [https://tvn24.pl/tvnmeteo/pogoda/snieg-na-dolnym-slasku-calkiem-inny-swiat-6863097?source=rss](https://tvn24.pl/tvnmeteo/pogoda/snieg-na-dolnym-slasku-calkiem-inny-swiat-6863097?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 10:58:46+00:00

<img alt="Śnieg na Dolnym Śląsku. " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-kpg13v-zima-trzyma-6863090/alternates/LANDSCAPE_1280" />
    Zabielił się powiat karkonoski.

## Komendant straży miejskiej zwrócił uwagę nastolatkowi. Został brutalnie pobity
 - [https://tvn24.pl/krakow/gorlice-komendant-strazy-miejskiej-brutalnie-pobity-wczesniej-zwrocil-uwage-nastolatkom-6863139?source=rss](https://tvn24.pl/krakow/gorlice-komendant-strazy-miejskiej-brutalnie-pobity-wczesniej-zwrocil-uwage-nastolatkom-6863139?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 10:56:25+00:00

<img alt="Komendant straży miejskiej zwrócił uwagę nastolatkowi. Został brutalnie pobity" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wivmuf-straznik-miejski-zdjecie-ilustracyjne-6863108/alternates/LANDSCAPE_1280" />
    Potem rzucił się z nożem na policjantów.

## "Kontrowersyjna" piosenka Miley Cyrus i Dolly Parton zakazana w szkole. Rodzice złożyli skargę
 - [https://tvn24.pl/kultura-i-styl/usa-kontrowersyjna-piosenka-miley-cyrus-i-dolly-parton-zakazana-w-szkole-rodzice-zlozyli-skarge-6862805?source=rss](https://tvn24.pl/kultura-i-styl/usa-kontrowersyjna-piosenka-miley-cyrus-i-dolly-parton-zakazana-w-szkole-rodzice-zlozyli-skarge-6862805?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 10:51:02+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xdmov3-miley-cyrus-dolly-parton-gettyimages-1244969991-6862890/alternates/LANDSCAPE_1280" />
    Na cenzurowanym znalazł się też utwór Kermita z "Muppetów".

## Zmienił nagle pas i wjechał wprost pod nadjeżdżającą ciężarówkę
 - [https://tvn24.pl/pomorze/olsztyn-wypadek-zjechal-nagle-na-przeciwlegly-pas-i-wjechal-pod-nadjezdzajaca-ciezarowke-6862721?source=rss](https://tvn24.pl/pomorze/olsztyn-wypadek-zjechal-nagle-na-przeciwlegly-pas-i-wjechal-pod-nadjezdzajaca-ciezarowke-6862721?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 10:45:47+00:00

<img alt="Zmienił nagle pas i wjechał wprost pod nadjeżdżającą ciężarówkę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1zthkf-zderzenie-samochodu-osobowego-z-ciezarowka-w-olsztynie-6862944/alternates/LANDSCAPE_1280" />
    Kierowca trafił do szpitala.

## 48-latek stracił panowanie nad quadem i uderzył w drzewo. Zginął na miejscu. Jechał bez kasku
 - [https://tvn24.pl/lodz/zelow-jawor-na-luku-drogi-stracil-panowanie-nad-quadem-i-uderzyl-w-drzewo-48-latek-nie-zyje-6862886?source=rss](https://tvn24.pl/lodz/zelow-jawor-na-luku-drogi-stracil-panowanie-nad-quadem-i-uderzyl-w-drzewo-48-latek-nie-zyje-6862886?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 10:30:25+00:00

<img alt="48-latek stracił panowanie nad quadem i uderzył w drzewo. Zginął na miejscu. Jechał bez kasku" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jh4vgw-na-luku-drogi-stracil-panowanie-nad-quadem-i-uderzyl-w-drzewo-48-latek-nie-zyje-6862874/alternates/LANDSCAPE_1280" />
    Okoliczności wypadku wyjaśnia policja pod nadzorem prokuratury.

## Pomyłkowa interwencja i wpis na Twitterze. "Po 5 latach policja mnie przeprosiła"
 - [https://tvn24.pl/polska/dziennikarka-anna-rokicinska-przeproszona-przez-policje-za-pomylkowa-interwencje-w-jej-domu-i-obrazliwy-wpis-6862857?source=rss](https://tvn24.pl/polska/dziennikarka-anna-rokicinska-przeproszona-przez-policje-za-pomylkowa-interwencje-w-jej-domu-i-obrazliwy-wpis-6862857?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 10:24:32+00:00

<img alt="Pomyłkowa interwencja i wpis na Twitterze. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-86n9jh-untitled-1-6863028/alternates/LANDSCAPE_1280" />
    Przeprosiny zamieszczono na oficjalnej stronie internetowej policji.

## Europa mogłaby być trzecim globalnym graczem w kosmosie. Czego brakuje?
 - [https://tvn24.pl/tvnmeteo/najnowsze/raport-esa-europa-moglaby-byc-trzecim-globalnym-graczem-w-kosmosie-czego-brakuje-6862932?source=rss](https://tvn24.pl/tvnmeteo/najnowsze/raport-esa-europa-moglaby-byc-trzecim-globalnym-graczem-w-kosmosie-czego-brakuje-6862932?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 10:23:27+00:00

<img alt="Europa mogłaby być trzecim globalnym graczem w kosmosie. Czego brakuje?" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-ii8pgr-jak-zwiekszyc-role-europy-w-podboju-kosmosu-6863020/alternates/LANDSCAPE_1280" />
    Eksperci z zespołu doradczego Europejskiej Agencji Kosmicznej opracowali raport.

## Akcja ratunkowa na Bałtyku. Mężczyzna skoczył z falochronu do wody. Nagranie
 - [https://tvn24.pl/pomorze/wladyslawowo-akcja-ratunkowa-na-baltyku-mezczyzna-skoczyl-z-falochronu-do-wody-wideo-6862536?source=rss](https://tvn24.pl/pomorze/wladyslawowo-akcja-ratunkowa-na-baltyku-mezczyzna-skoczyl-z-falochronu-do-wody-wideo-6862536?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 10:18:55+00:00

<img alt="Akcja ratunkowa na Bałtyku. Mężczyzna skoczył z falochronu do wody. Nagranie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-47bv01-mezczyzna-wszedl-na-falochron-i-wpadl-do-wody-6862526/alternates/LANDSCAPE_1280" />
    Informację oraz film dostaliśmy na Kontakt24.

## Książę Harry stawił się przed sądem w Londynie
 - [https://tvn24.pl/swiat/londyn-ksiaze-harry-przed-sadem-pozew-przeciw-associated-newspapers-6862988?source=rss](https://tvn24.pl/swiat/londyn-ksiaze-harry-przed-sadem-pozew-przeciw-associated-newspapers-6862988?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 10:15:43+00:00

<img alt="Książę Harry stawił się przed sądem w Londynie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-yc6ttl-ksiaze-harry-w-londynie-zdjecie-z-2019-roku-6616854/alternates/LANDSCAPE_1280" />
    Książę złożył pozew wspólnie z m.in. Eltonem Johnem i Elizabeth Hurley.

## W rękach wybuchła jej paczka. Pani Urszula "wciąż w ciele znajduje odłamki bomby"
 - [https://tvn24.pl/poznan/siecieborzyce-dostala-paczke-w-srodku-byla-bomba-pani-urszula-stracila-reke-teraz-czeka-na-przeszczep-nowej-6862720?source=rss](https://tvn24.pl/poznan/siecieborzyce-dostala-paczke-w-srodku-byla-bomba-pani-urszula-stracila-reke-teraz-czeka-na-przeszczep-nowej-6862720?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 10:02:12+00:00

<img alt="W rękach wybuchła jej paczka. Pani Urszula " src="https://tvn24.pl/najnowsze/cdn-zdjecie-6e0eiw-pani-urszula-czekala-na-paczke-od-kuriera-a-dostala-bombe-ktora-miala-zabic-ja-i-jej-dzieci-6647131/alternates/LANDSCAPE_1280" />
    Trzy miesiące po tragedii "Uwaga" TVN sprawdziła, jak kobieta odnajduje się w nowej rzeczywistości.

## Przywrócić narodową twierdzę. Polacy po długiej przerwie wracają na ulubiony obiekt
 - [https://eurosport.tvn24.pl/przywr-ci--narodow--twierdz---polacy-po-d-ugiej-przerwie-wracaj--na-ulubiony-obiekt,1141112.html?source=rss](https://eurosport.tvn24.pl/przywr-ci--narodow--twierdz---polacy-po-d-ugiej-przerwie-wracaj--na-ulubiony-obiekt,1141112.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 10:01:45+00:00

<img alt="Przywrócić narodową twierdzę. Polacy po długiej przerwie wracają na ulubiony obiekt" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fjr80-polacy-wroca-do-wygrywania-na-pge-narodowym-6863032/alternates/LANDSCAPE_1280" />
    Na zwycięstwo na Stadionie Narodowym czekają zaskakująco długo.

## Emerytury będą niższe. GUS pokazał nowe tablice trwania życia
 - [https://tvn24.pl/biznes/z-kraju/emerytura-tablice-trwania-zycia-gus-wysokosc-swiadczen-6862797?source=rss](https://tvn24.pl/biznes/z-kraju/emerytura-tablice-trwania-zycia-gus-wysokosc-swiadczen-6862797?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 09:59:50+00:00

<img alt="Emerytury będą niższe. GUS pokazał nowe tablice trwania życia" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-ob7uwm-emeryci-ofe-zus-emerytura-16-4623417/alternates/LANDSCAPE_1280" />
    "Do poziomu sprzed pandemii nie wróciliśmy".

## Mocny kandydat na następcę Włocha
 - [https://eurosport.tvn24.pl/conte-doigra--si---mocny-kandydat-na-nast-pc--w-ocha,1141110.html?source=rss](https://eurosport.tvn24.pl/conte-doigra--si---mocny-kandydat-na-nast-pc--w-ocha,1141110.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 09:42:03+00:00

<img alt="Mocny kandydat na następcę Włocha" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qef15w-antonio-conte-6862970/alternates/LANDSCAPE_1280" />
    Tottenham Hotspur potwierdził rozstanie z Antonio Conte.

## Daniel Radcliffe zostanie ojcem
 - [https://tvn24.pl/kultura-i-styl/daniel-radcliffe-zostanie-ojcem-partnerka-aktora-erin-darke-spodziewa-sie-dziecka-6862806?source=rss](https://tvn24.pl/kultura-i-styl/daniel-radcliffe-zostanie-ojcem-partnerka-aktora-erin-darke-spodziewa-sie-dziecka-6862806?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 09:28:46+00:00

<img alt="Daniel Radcliffe zostanie ojcem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4cwq4a-daniel-radcliffe-i-erin-darke-6862770/alternates/LANDSCAPE_1280" />
    Gwiazdor Harry'ego Pottera i jego partnerka przerywają spekulacje mediów.

## Jechali odwiedzić chorą rodzinę, porwano ich dla okupu
 - [https://tvn24.pl/swiat/haiti-jechali-odwiedzic-rodzine-abigail-i-jean-dickens-toussaint-porwani-dla-okupu-6862525?source=rss](https://tvn24.pl/swiat/haiti-jechali-odwiedzic-rodzine-abigail-i-jean-dickens-toussaint-porwani-dla-okupu-6862525?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 09:25:33+00:00

<img alt="Jechali odwiedzić chorą rodzinę, porwano ich dla okupu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6wx5x5-abigail-i-jean-dickens-toussaint-6862567/alternates/LANDSCAPE_1280" />
    Reakcja Departamentu Stanu USA.

## Skład reprezentacji Polski na finałowe zawody w Planicy
 - [https://eurosport.tvn24.pl/sk-ad-reprezentacji-polski-na-fina-owe-zawody-w-planicy,1141115.html?source=rss](https://eurosport.tvn24.pl/sk-ad-reprezentacji-polski-na-fina-owe-zawody-w-planicy,1141115.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 09:19:06+00:00

<img alt="Skład reprezentacji Polski na finałowe zawody w Planicy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-m6d490-polscy-skoczkowie-podczas-druzynowego-konkursu-w-lahti-6862910/alternates/LANDSCAPE_1280" />
    Trener Thomas Thurnbichler odkrył karty.

## Dyrektorka straciła pracę, bo pokazała uczniom Dawida. Galeria zaprasza ich, by zobaczyli rzeźbę na żywo
 - [https://tvn24.pl/kultura-i-styl/florencja-dyrektorka-szkoly-stracila-prace-galeria-akademii-zaprasza-uczniow-z-florydy-do-zobaczenia-rzezby-dawida-6862638?source=rss](https://tvn24.pl/kultura-i-styl/florencja-dyrektorka-szkoly-stracila-prace-galeria-akademii-zaprasza-uczniow-z-florydy-do-zobaczenia-rzezby-dawida-6862638?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 09:12:37+00:00

<img alt="Dyrektorka straciła pracę, bo pokazała uczniom Dawida. Galeria zaprasza ich, by zobaczyli rzeźbę na żywo" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie797f1f41de72a1fbb53893960a822483-podziwianie-dawida-michala-aniola-moze-zamienic-sie-w-koszmar-4661166/alternates/LANDSCAPE_1280" />
    Dyrektorkę osobiście zaprasza burmistrz Florencji.

## Protestujący krzyczą, że "Izrael to nie jest Polska". Wiceszef MSZ: strona izraelska nas o to pytała
 - [https://tvn24.pl/swiat/protestujacy-w-izraelu-krzycza-ze-nie-chca-byc-jak-polska-wiceszef-msz-strona-izraelska-nas-o-to-pytala-6862766?source=rss](https://tvn24.pl/swiat/protestujacy-w-izraelu-krzycza-ze-nie-chca-byc-jak-polska-wiceszef-msz-strona-izraelska-nas-o-to-pytala-6862766?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 08:58:10+00:00

<img alt="Protestujący krzyczą, że " src="https://tvn24.pl/najnowsze/cdn-zdjecie-l575ey-protesty-w-izraelu-6849450/alternates/LANDSCAPE_1280" />
    Dzieliliśmy się naszymi doświadczeniami w tym zakresie - powiedział Paweł Jabłoński.

## Prezes największego akcjonariusza Credit Suisse zrezygnował ze stanowiska
 - [https://tvn24.pl/biznes/ze-swiata/rezygnacja-prezesa-saudi-national-bank-w-zwiazku-z-credit-suisse-6862617?source=rss](https://tvn24.pl/biznes/ze-swiata/rezygnacja-prezesa-saudi-national-bank-w-zwiazku-z-credit-suisse-6862617?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 08:57:13+00:00

<img alt="Prezes największego akcjonariusza Credit Suisse zrezygnował ze stanowiska" src="https://tvn24.pl/najnowsze/cdn-zdjecie-tld9hu-gettyimages-1187467000-6862684/alternates/LANDSCAPE_1280" />
    Jego komentarze przyczyniły się do ostrego spadku kursu akcji szwajcarskiego banku.

## Brzezińscy upamiętnieni w Przemyślu. Ambasador: ojciec byłby dumny z Polski i przyjaźni polsko-amerykańskiej
 - [https://tvn24.pl/polska/rodzina-brzezinskich-upamietniona-w-szkole-w-przemyslu-ambasador-mark-brzezinski-lekcja-o-tym-co-mnie-uksztaltowalo-6862672?source=rss](https://tvn24.pl/polska/rodzina-brzezinskich-upamietniona-w-szkole-w-przemyslu-ambasador-mark-brzezinski-lekcja-o-tym-co-mnie-uksztaltowalo-6862672?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 08:40:59+00:00

<img alt="Brzezińscy upamiętnieni w Przemyślu. Ambasador: ojciec byłby dumny z Polski i przyjaźni polsko-amerykańskiej" src="https://tvn24.pl/polska/cdn-zdjecie-p02cxo-brzezinski-w-szkole-nr-1-w-przemyslu-6862734/alternates/LANDSCAPE_1280" />
    Pamiątkowa tablica w Szkole Podstawowej nr 1 w Przemyślu.

## Putin "uprawia grę" z Zachodem. Pełczyńska-Nałęcz: grozi, kiedy napotyka opór
 - [https://tvn24.pl/swiat/wladimir-putin-zapowiada-umieszczenie-broni-jadrowej-na-bialorusi-katarzyna-pelczynska-nalecz-komentuje-6862601?source=rss](https://tvn24.pl/swiat/wladimir-putin-zapowiada-umieszczenie-broni-jadrowej-na-bialorusi-katarzyna-pelczynska-nalecz-komentuje-6862601?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 08:20:58+00:00

<img alt="Putin " src="https://tvn24.pl/najnowsze/cdn-zdjecie-htqldn-rosjanie-sugeruja-ze-moga-rozbudowac%20arsenal-jadrowy-3146213/alternates/LANDSCAPE_1280" />
    Była ambasador RP w Moskwie o kolejnej decyzji prezydenta Rosji.

## Dziwny sygnał z Voyagera 2 odczytany. Co chce nam przekazać sonda
 - [https://tvn24.pl/tvnmeteo/nauka/dziwny-sygnal-z-sondy-voyager-2-odczytany-po-kilkudziesieciu-latach-dwa-ksiezyce-urana-moga-miec-oceany-6862522?source=rss](https://tvn24.pl/tvnmeteo/nauka/dziwny-sygnal-z-sondy-voyager-2-odczytany-po-kilkudziesieciu-latach-dwa-ksiezyce-urana-moga-miec-oceany-6862522?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 08:10:08+00:00

<img alt="Dziwny sygnał z Voyagera 2 odczytany. Co chce nam przekazać sonda" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-6rl7n8-uran-zdjecie-wykonane-przez-sonde-voyager-2-5680673/alternates/LANDSCAPE_1280" />
    Wnioski analizy danych zostały zaprezentowane podczas 54. konferencji Lunar and Planetary Science.

## Prawdopodobny skład Polaków na Albanię. Sporo znaków zapytania w obronie
 - [https://eurosport.tvn24.pl/prawdopodobny-sk-ad-polak-w-na-albani---sporo-znak-w-zapytania-w-obronie,1141108.html?source=rss](https://eurosport.tvn24.pl/prawdopodobny-sk-ad-polak-w-na-albani---sporo-znak-w-zapytania-w-obronie,1141108.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 07:55:57+00:00

<img alt="Prawdopodobny skład Polaków na Albanię. Sporo znaków zapytania w obronie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-olajun-na-kogo-postawi-fernando-santos-w-meczu-polska-albania-6862703/alternates/LANDSCAPE_1280" />
    Już tylko godziny dzielą nas od drugiego meczu Biało-Czerwonych w eliminacjach mistrzostw Europy 2024.

## Macron protestuje przeciw samemu sobie, Trump szarpie z policją
 - [https://tvn24.pl/swiat/deepfake-emmanuel-macron-i-donald-trump-na-obrazach-stworzonych-przez-sztuczna-inteligencje-6860846?source=rss](https://tvn24.pl/swiat/deepfake-emmanuel-macron-i-donald-trump-na-obrazach-stworzonych-przez-sztuczna-inteligencje-6860846?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 07:37:58+00:00

<img alt="Macron protestuje przeciw samemu sobie, Trump szarpie z policją" src="https://tvn24.pl/najnowsze/cdn-zdjecie-njjlym-emmanuel-macron-i-donald-trump-zdjecia-powstaly-z-uzyciem-sztucznej-inteligencji-6860951/alternates/LANDSCAPE_1280" />
    W sieci rośnie liczba nieprawdziwych zdjęć tworzonych metodą deepfake.

## Rusza kolejna sprawa "Krystka" o wykorzystywanie seksualne nieletniej
 - [https://tvn24.pl/pomorze/wejherowo-rusza-kolejna-sprawa-krystka-o-wykorzystywanie-seksualne-nieletniej-6862549?source=rss](https://tvn24.pl/pomorze/wejherowo-rusza-kolejna-sprawa-krystka-o-wykorzystywanie-seksualne-nieletniej-6862549?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 07:27:25+00:00

<img alt="Rusza kolejna sprawa " src="https://tvn24.pl/najnowsze/cdn-zdjecie720d71878197cf59338ce5ab28d0bdc4-krystek-w-prokuraturze-4009992/alternates/LANDSCAPE_1280" />
    Grozi mu 12 lat więzienia.

## Zatrzymany ruch pociągów, autobusów i samolotów. Strajkuje co najmniej 30 tysięcy osób
 - [https://tvn24.pl/biznes/ze-swiata/niemcy-strajk-sparalizowal-transport-publiczny-6862548?source=rss](https://tvn24.pl/biznes/ze-swiata/niemcy-strajk-sparalizowal-transport-publiczny-6862548?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 07:16:23+00:00

<img alt="Zatrzymany ruch pociągów, autobusów i samolotów. Strajkuje co najmniej 30 tysięcy osób" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qn6hh3-strajk-w-niemczech-sparalizowal-transport-publiczny-6862597/alternates/LANDSCAPE_1280" />
    W Niemczech.

## Pożar domu z instalacją fotowoltaiczną. Z ogniem walczyło ponad 40 strażaków
 - [https://tvn24.pl/tvnwarszawa/najnowsze/ostrow-pozar-domu-z-instalacja-fotowoltaiczna-pod-otwockiem-6862527?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/ostrow-pozar-domu-z-instalacja-fotowoltaiczna-pod-otwockiem-6862527?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 07:14:32+00:00

<img alt="Pożar domu z instalacją fotowoltaiczną. Z ogniem walczyło ponad 40 strażaków" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-ump1fl-pozar-w-miejscowosci-ostrow-6862561/alternates/LANDSCAPE_1280" />
    W miejscowości Ostrów (powiat otwocki).

## Jeremy Renner pokazał nowe nagranie po wypadku z pługiem śnieżnym
 - [https://tvn24.pl/kultura-i-styl/jeremy-renner-staje-na-nogi-aktor-opublikowal-nagranie-pokazujace-postepy-w-rehabilitacji-6862512?source=rss](https://tvn24.pl/kultura-i-styl/jeremy-renner-staje-na-nogi-aktor-opublikowal-nagranie-pokazujace-postepy-w-rehabilitacji-6862512?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 07:09:39+00:00

<img alt="Jeremy Renner pokazał nowe nagranie po wypadku z pługiem śnieżnym " src="https://tvn24.pl/najnowsze/cdn-zdjecie-xvbnns-jeremy-renner-6588375/alternates/LANDSCAPE_1280" />
    Uległ wypadkowi 1 stycznia tego roku.

## Raport Departamentu Stanu o mediach i wolności słowa w Polsce
 - [https://tvn24.pl/polska/media-i-wolnosc-slowa-w-polsce-raport-departamentu-stanu-6862448?source=rss](https://tvn24.pl/polska/media-i-wolnosc-slowa-w-polsce-raport-departamentu-stanu-6862448?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 06:56:00+00:00

<img alt="Raport Departamentu Stanu o mediach i wolności słowa w Polsce" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qt7u5-wolne-media-sa-w-smiertelnym-niebezpieczenstwie-5162987/alternates/LANDSCAPE_1280" />
    Za 2022 rok.

## Włosi czekali na takiego napastnika prawie 55 lat. Znaleźli w Argentynie
 - [https://eurosport.tvn24.pl/w-osi-czekali-na-takiego-napastnika-prawie-55-lat--znale-li-w-argentynie,1141105.html?source=rss](https://eurosport.tvn24.pl/w-osi-czekali-na-takiego-napastnika-prawie-55-lat--znale-li-w-argentynie,1141105.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 06:47:18+00:00

<img alt="Włosi czekali na takiego napastnika prawie 55 lat. Znaleźli w Argentynie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-yo5ijg-wlosi-znalezli-nowa-dziewiatke-6862542/alternates/LANDSCAPE_1280" />
    Dwa mecze i dwa gole.

## Orlando Bloom pojechał na Ukrainę
 - [https://tvn24.pl/swiat/orlando-bloom-w-ukrainie-odwiedzil-dzieci-w-osrodku-spilno-spotkal-sie-z-prezydentem-wolodymyrem-zelenskim-6862508?source=rss](https://tvn24.pl/swiat/orlando-bloom-w-ukrainie-odwiedzil-dzieci-w-osrodku-spilno-spotkal-sie-z-prezydentem-wolodymyrem-zelenskim-6862508?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 06:45:37+00:00

<img alt="Orlando Bloom pojechał na Ukrainę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ab9lia-orlando-bloom-w-ukrainie-odwiedzil-dzieci-w-osrodku-spilno-6862517/alternates/LANDSCAPE_1280" />
    Brytyjski aktor i ambasador Dobrej Woli UNICEF spotkał się z dziećmi. Rozmawiał też z prezydentem Wołodymyrem Zełenskim.

## Drzewo spadło na karetkę. "Życie przeleciało mi przed oczami"
 - [https://tvn24.pl/tvnmeteo/swiat/georgia-usa-tornado-zniszczylo-domy-sa-ranni-stan-wyjatkowy-6862435?source=rss](https://tvn24.pl/tvnmeteo/swiat/georgia-usa-tornado-zniszczylo-domy-sa-ranni-stan-wyjatkowy-6862435?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 06:21:26+00:00

<img alt="Drzewo spadło na karetkę. " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-b4fb77-tornado-georgia-usa-6862445/alternates/LANDSCAPE_1280" />
    Przez amerykański stan Georgia przetoczyło się tornado, wprowadzono stan wyjątkowy.

## Zderzenie tramwaju z taksówką. Trzy linie na objazdach
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-zderzenie-tramwaju-z-taksowka-w-alei-jana-pawla-ii-objazdy-6862471?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-zderzenie-tramwaju-z-taksowka-w-alei-jana-pawla-ii-objazdy-6862471?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 06:21:06+00:00

<img alt="Zderzenie tramwaju z taksówką. Trzy linie na objazdach" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-6445pp-zderzenie-auta-z-tramwajem-6862489/alternates/LANDSCAPE_1280" />
    W alei Jana Pawła II w Warszawie.

## Tak zwana 14. emerytura na stałe? Borys: jeśli rząd szacuje, że stać go na to, poczekajmy, aż pokaże szczegóły
 - [https://tvn24.pl/polska/tak-zwana-14-emerytura-na-stale-pawel-borys-jesli-rzad-szacuje-ze-stac-go-na-to-poczekajmy-az-pokaze-szczegoly-6862461?source=rss](https://tvn24.pl/polska/tak-zwana-14-emerytura-na-stale-pawel-borys-jesli-rzad-szacuje-ze-stac-go-na-to-poczekajmy-az-pokaze-szczegoly-6862461?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 06:11:26+00:00

<img alt="Tak zwana 14. emerytura na stałe? Borys: jeśli rząd szacuje, że stać go na to, poczekajmy, aż pokaże szczegóły" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kq3esn-emeryci-shutterstock_1397798255-5474025/alternates/LANDSCAPE_1280" />
    Prezes Polskiego Funduszu Rozwoju w "Rozmowie Piaseckiego".

## Prezes PFR:  w tym tygodniu kończymy najgorszy kwartał gospodarczy w tym cyklu
 - [https://tvn24.pl/biznes/z-kraju/inflacja-w-polsce-marzec-2023-pawel-borys-szef-pfr-gosciem-konrada-piaseckiego-6862460?source=rss](https://tvn24.pl/biznes/z-kraju/inflacja-w-polsce-marzec-2023-pawel-borys-szef-pfr-gosciem-konrada-piaseckiego-6862460?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 06:06:12+00:00

<img alt="Prezes PFR:  w tym tygodniu kończymy najgorszy kwartał gospodarczy w tym cyklu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-o1014f-adobestock35215616-5599361/alternates/LANDSCAPE_1280" />
    Paweł Borys w "Rozmowie Piaseckiego".

## Miał grać w meczu eliminacyjnym. Zamiast tego przeszedł operację
 - [https://eurosport.tvn24.pl/mia--gra--w-meczu-eliminacyjnym--zamiast-tego-przeszed--operacj-,1141080.html?source=rss](https://eurosport.tvn24.pl/mia--gra--w-meczu-eliminacyjnym--zamiast-tego-przeszed--operacj-,1141080.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 05:42:00+00:00

<img alt="Miał grać w meczu eliminacyjnym. Zamiast tego przeszedł operację" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1k97we-phil-foden-jest-reprezentantem-anglii-6862467/alternates/LANDSCAPE_1280" />
    Anglii musiała radzić sobie bez Phila Fodena.

## Powrót zimy. Alerty IMGW dla całego kraju
 - [https://tvn24.pl/tvnmeteo/polska/alerty-imgw-przymrozki-oblodzenie-intensywne-opady-deszczu-snieg-pogoda-w-poniedzialek-i-kolejnych-dniach-6862422?source=rss](https://tvn24.pl/tvnmeteo/polska/alerty-imgw-przymrozki-oblodzenie-intensywne-opady-deszczu-snieg-pogoda-w-poniedzialek-i-kolejnych-dniach-6862422?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 05:30:39+00:00

<img alt="Powrót zimy. Alerty IMGW dla całego kraju" src="https://tvn24.pl/najnowsze/cdn-zdjecie-11iqyt-mroz-przymrozki-zimno-6862962/alternates/LANDSCAPE_1280" />
    Instytut Meteorologii i Gospodarki Wodnej ostrzega przed wieloma pogodowymi zagrożeniami.

## Przymrozki, ślizgawica, śnieg i silny wiatr. Żółte alerty IMGW w całym kraju
 - [https://tvn24.pl/tvnmeteo/polska/alerty-imgw-przymrozki-oblodzenie-snieg-silny-wiatr-pogoda-w-poniedzialek-i-w-kolejne-dni-6862422?source=rss](https://tvn24.pl/tvnmeteo/polska/alerty-imgw-przymrozki-oblodzenie-snieg-silny-wiatr-pogoda-w-poniedzialek-i-w-kolejne-dni-6862422?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 05:30:39+00:00

<img alt="Przymrozki, ślizgawica, śnieg i silny wiatr. Żółte alerty IMGW w całym kraju" src="https://tvn24.pl/najnowsze/cdn-zdjecie-z5cuzh-noc-lekki-snieg-6643841/alternates/LANDSCAPE_1280" />
    Sprawdź, jakie pogodowe zagrożenia mogą wystąpić w twojej okolicy.

## Spadnie do 10 centymetrów śniegu, wystąpią też ulewy. Alerty IMGW
 - [https://tvn24.pl/tvnmeteo/polska/spadnie-do-10-centymetrow-sniegu-wystapia-tez-ulewy-alerty-imgw-6862422?source=rss](https://tvn24.pl/tvnmeteo/polska/spadnie-do-10-centymetrow-sniegu-wystapia-tez-ulewy-alerty-imgw-6862422?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 05:30:39+00:00

<img alt="Spadnie do 10 centymetrów śniegu, wystąpią też ulewy. Alerty IMGW" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-p5x5su-snieg-6816752/alternates/LANDSCAPE_1280" />
    Sprawdź, gdzie obowiązują ostrzeżenia.

## Wracają zimowe niebezpieczeństwa. Cała Polska żółta od alarmów
 - [https://tvn24.pl/tvnmeteo/polska/alerty-imgw-przymrozki-oblodzenie-snieg-pogoda-w-poniedzialek-i-w-kolejne-dni-6862422?source=rss](https://tvn24.pl/tvnmeteo/polska/alerty-imgw-przymrozki-oblodzenie-snieg-pogoda-w-poniedzialek-i-w-kolejne-dni-6862422?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 05:30:39+00:00

<img alt="Wracają zimowe niebezpieczeństwa. Cała Polska żółta od alarmów" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-bynu7u-obfite-opady-sniegu-w-szczecinie-6816291/alternates/LANDSCAPE_1280" />
    Sprawdź, gdzie aura może być groźna.

## Jonathan Majors oskarżony o napaść na kobietę. Amerykańska armia wstrzymuje kampanię z gwiazdorem
 - [https://tvn24.pl/kultura-i-styl/usa-aktor-jonathan-majors-zatrzymany-przez-policje-i-oskarzony-o-napasc-6862393?source=rss](https://tvn24.pl/kultura-i-styl/usa-aktor-jonathan-majors-zatrzymany-przez-policje-i-oskarzony-o-napasc-6862393?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 05:27:32+00:00

<img alt="Jonathan Majors oskarżony o napaść na kobietę. Amerykańska armia wstrzymuje kampanię z gwiazdorem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-r9mxq6-pap_20230312_2gk-1-6862452/alternates/LANDSCAPE_1280" />
    W sobotę został przesłuchany i zwolniony bez kaucji.

## Efektowny pościg w drugim secie. Linette z awansem w deblu
 - [https://eurosport.tvn24.pl/efektowny-po-cig-w-drugim-secie--linette-z-awansem-w-deblu,1141104.html?source=rss](https://eurosport.tvn24.pl/efektowny-po-cig-w-drugim-secie--linette-z-awansem-w-deblu,1141104.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 05:25:33+00:00

<img alt="Efektowny pościg w drugim secie. Linette z awansem w deblu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-s5dyjr-linette-swietnie-radzi-sobie-w-tym-roku-6862453/alternates/LANDSCAPE_1280" />
    Magda Linette świetnie radzi sobie na korcie w Miami nie tylko w grze pojedynczej.

## Wyciek ropy w dużym porcie naturalnym
 - [https://tvn24.pl/biznes/ze-swiata/wielka-brytania-wyciek-ropy-w-porcie-poole-harbour-6862397?source=rss](https://tvn24.pl/biznes/ze-swiata/wielka-brytania-wyciek-ropy-w-porcie-poole-harbour-6862397?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 05:24:16+00:00

<img alt="Wyciek ropy w dużym porcie naturalnym" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5w9gxy-shutterstock_2264100377-6862451/alternates/LANDSCAPE_1280" />
     "Poważny incydent" .

## Drzewo rosło 114 lat. "Nikt nie pomyślał, żeby je ściąć. Aż przyszedł rok 2023 i powód się znalazł"
 - [https://tvn24.pl/tvnwarszawa/mokotow/warszawa-buduja-tramwaj-do-wilanowa-stuletnie-drzewo-przy-sobieskiego-wyciete-6860281?source=rss](https://tvn24.pl/tvnwarszawa/mokotow/warszawa-buduja-tramwaj-do-wilanowa-stuletnie-drzewo-przy-sobieskiego-wyciete-6860281?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 05:15:54+00:00

<img alt="Drzewo rosło 114 lat. " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-58ajgx-drzewo-przy-sobieskiego-wycieto-6860303/alternates/LANDSCAPE_1280" />
    "Przeżyło dwie wojny, Powstanie Warszawskie".

## Normą będą 40-osobowe klasy, lekcje na trzy zmiany w salach pożyczonych od podstawówek
 - [https://tvn24.pl/premium/rekrutacja-do-liceow-20232024-takiego-scisku-nie-bylo-w-szkolach-srednich-od-niemal-20-lat-6857719?source=rss](https://tvn24.pl/premium/rekrutacja-do-liceow-20232024-takiego-scisku-nie-bylo-w-szkolach-srednich-od-niemal-20-lat-6857719?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 05:02:45+00:00

<img alt="Normą będą 40-osobowe klasy, lekcje na trzy zmiany w salach pożyczonych od podstawówek" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wlq7lm-forum-0470486787-6858486/alternates/LANDSCAPE_1280" />
    Kiedy w końcu w szkołach będzie normalnie? - pytają rodzice. Niestety - dla nich i ich nastoletnich dzieci nie mamy dobrych wieści. Od września w szkołach ponadpodstawowych będzie wyjątkowo ciasno. We Wrocławiu licea będą "pożyczać" sale lekcyjne w podstawówkach, w Krakowie nowy ogólniak powstanie w budynku przedszkola. Samorządy kupują ławki i krzesła, by posadzić niemal dwa miliony licealistów w dosłownie każdym zakamarku szkół.

## Brytyjskie władze szykują zakaz sprzedaży popularnego środka. "Każdy widzi te małe pojemniki"
 - [https://tvn24.pl/biznes/ze-swiata/wielka-brytania-wladze-maja-zakazac-sprzedazy-gazu-rozweselajacego-michael-gove-zapowiada-6862433?source=rss](https://tvn24.pl/biznes/ze-swiata/wielka-brytania-wladze-maja-zakazac-sprzedazy-gazu-rozweselajacego-michael-gove-zapowiada-6862433?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 04:51:44+00:00

<img alt="Brytyjskie władze szykują zakaz sprzedaży popularnego środka. " src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-9wh3d3-londyn-banki-londynskie-city-wielka-brytania-6842642/alternates/LANDSCAPE_1280" />
    Władze chcą walczyć z zachowaniami antyspołecznymi.

## Granerud narzeka na absurdalne warunki w Lahti. "Czuję się beznadziejnie"
 - [https://eurosport.tvn24.pl/granerud-narzeka-na-absurdalne-warunki-w-lahti---czuj--si--beznadziejnie-,1141097.html?source=rss](https://eurosport.tvn24.pl/granerud-narzeka-na-absurdalne-warunki-w-lahti---czuj--si--beznadziejnie-,1141097.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 04:48:05+00:00

<img alt="Granerud narzeka na absurdalne warunki w Lahti. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-3h9536-halvor-egner-granerud-wygral-krysztalowa-kule-6862436/alternates/LANDSCAPE_1280" />
    Znany z bezkompromisowych wypowiedzi Halvor Egner Granerud miał okazję dać upust negatywnym emocjom.

## Korea Północna wystrzeliła dwa pociski balistyczne
 - [https://tvn24.pl/swiat/korea-polnocna-wystrzelila-dwa-pociski-balistyczne-korea-poludniowa-i-japonia-komentuja-6862410?source=rss](https://tvn24.pl/swiat/korea-polnocna-wystrzelila-dwa-pociski-balistyczne-korea-poludniowa-i-japonia-komentuja-6862410?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 04:42:03+00:00

<img alt="Korea Północna wystrzeliła dwa pociski balistyczne " src="https://tvn24.pl/najnowsze/cdn-zdjecie-16mw7v-korea-polnocna-wystrzelila-dwa-pociski-balistyczne-w-kierunku-morza-6830493/alternates/LANDSCAPE_1280" />
    Poinformowało wojsko Korei Południowej.

## "To wrogie przejęcie państwa". Wszyscy czekają na decyzję Netanjahu
 - [https://tvn24.pl/swiat/protesty-w-izraelu-zmiany-w-sadownictwie-lotnisko-ben-guriona-wstrzymalo-odloty-co-zrobi-benjamin-netanjahu-6862284?source=rss](https://tvn24.pl/swiat/protesty-w-izraelu-zmiany-w-sadownictwie-lotnisko-ben-guriona-wstrzymalo-odloty-co-zrobi-benjamin-netanjahu-6862284?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 04:29:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ftmdoc-izrael-6862898/alternates/LANDSCAPE_1280" />
    Izraelski rząd ma rozważać możliwość odstąpienia od kontrowersyjnej reformy sądownictwa, przeciwko której protestują tysiące Izraelczyków.

## Protesty wstrząsnęły całym krajem. Prace nad reformą odłożone
 - [https://tvn24.pl/swiat/protesty-w-izraelu-zmiany-w-sadownictwie-benjamin-netanjahu-odklada-reforme-6862284?source=rss](https://tvn24.pl/swiat/protesty-w-izraelu-zmiany-w-sadownictwie-benjamin-netanjahu-odklada-reforme-6862284?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 04:29:00+00:00

<img alt="Protesty wstrząsnęły całym krajem. Prace nad reformą odłożone " src="https://tvn24.pl/najnowsze/cdn-zdjecie-3ob6bc-protesty-w-izraelu-6863889/alternates/LANDSCAPE_1280" />
    Przeciwko zmianom w sądownictwie protestują tysiące Izraelczyków.

## Ulica wrze, szef sztabu generalnego zwrócił się do żołnierzy. "Nie doświadczyliśmy jeszcze podobnych dni"
 - [https://tvn24.pl/swiat/protesty-w-izraelu-zmiany-w-sadownictwie-co-zrobi-benjamin-netanjahu-6862284?source=rss](https://tvn24.pl/swiat/protesty-w-izraelu-zmiany-w-sadownictwie-co-zrobi-benjamin-netanjahu-6862284?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 04:29:00+00:00

<img alt="Ulica wrze, szef sztabu generalnego zwrócił się do żołnierzy. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-2kzroj-demonstracja-w-jerozolimie-6863642/alternates/LANDSCAPE_1280" />
    Izraelski rząd ma rozważać możliwość odstąpienia od kontrowersyjnej reformy sądownictwa, przeciwko której protestują tysiące Izraelczyków.

## Polacy chcą zmazać plamę. Dziś mecz z Albanią
 - [https://eurosport.tvn24.pl/polska---albania--o-kt-rej-godzinie-dzisiaj-mecz-el--euro-2024-,1141023.html?source=rss](https://eurosport.tvn24.pl/polska---albania--o-kt-rej-godzinie-dzisiaj-mecz-el--euro-2024-,1141023.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 04:22:00+00:00

<img alt="Polacy chcą zmazać plamę. Dziś mecz z Albanią" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6yckng-polacy-zagraja-na-pge-narodowym-6862429/alternates/LANDSCAPE_1280" />
    O której godzinie dzisiaj mecz eliminacji Euro 2024 na Stadionie Narodowym?

## Ukraina. Najważniejsze wydarzenia ostatnich godzin
 - [https://tvn24.pl/swiat/wojna-w-ukrainie-najwazniejsze-wydarzenia-ostatnich-godzin-27-marca-2023-6862409?source=rss](https://tvn24.pl/swiat/wojna-w-ukrainie-najwazniejsze-wydarzenia-ostatnich-godzin-27-marca-2023-6862409?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 04:19:58+00:00

<img alt="Ukraina. Najważniejsze wydarzenia ostatnich godzin" src="https://tvn24.pl/najnowsze/cdn-zdjecie-dp25yx-zniszczenia-w-bachmucie-6821288/alternates/LANDSCAPE_1280" />
    Rosyjska inwazja trwa 397. dzień.

## Ihor pojechał na obóz do Rosji, ale "wakacje zamieniły się w porwanie"
 - [https://tvn24.pl/swiat/ukraina-tysiace-dzieci-uprowadzonych-przez-rosjan-rodzice-walcza-o-ich-powrot-do-domow-6862387?source=rss](https://tvn24.pl/swiat/ukraina-tysiace-dzieci-uprowadzonych-przez-rosjan-rodzice-walcza-o-ich-powrot-do-domow-6862387?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 03:54:26+00:00

<img alt="Ihor pojechał na obóz do Rosji, ale " src="https://tvn24.pl/najnowsze/cdn-zdjecie-vxhpy0-ukrainskie-dzieci-uciekly-przed-wojna-5631301/alternates/LANDSCAPE_1280" />
    Rodzice dzieci wywiezionych z Ukrainy walczą o ich powrót do domów.

## "Jasno opowiadamy się po stronie Ukrainy". Chcą przekazać śmigłowce bojowe
 - [https://tvn24.pl/swiat/wojna-w-ukrainie-macedonia-polnocna-przekaze-ukrainie-smiglowce-bojowe-jest-zapowiedz-6862389?source=rss](https://tvn24.pl/swiat/wojna-w-ukrainie-macedonia-polnocna-przekaze-ukrainie-smiglowce-bojowe-jest-zapowiedz-6862389?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 03:38:49+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4p515x-ukraina-zolnierze-w-poblizu-bachmutu-6862390/alternates/LANDSCAPE_1280" />
    "To sprzęt, którym ukraińska armia potrafi się posługiwać".

## "Mocno nakłaniamy przywódców do znalezienia kompromisu tak szybko, jak to możliwe"
 - [https://tvn24.pl/swiat/usa-izrael-bialy-dom-komentuje-wydarzenia-w-izraelu-6862406?source=rss](https://tvn24.pl/swiat/usa-izrael-bialy-dom-komentuje-wydarzenia-w-izraelu-6862406?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 03:25:10+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-96u55s-starcia-izraelskiej-policji-z-protestujacymi-w-tel-awiwie-6858563/alternates/LANDSCAPE_1280" />
    Oświadczenie rzeczniczki Rady Bezpieczeństwa Narodowego Białego Domu w sprawie Izraela.

## "To złe i niesprawiedliwe". Zełenski apeluje do rodaków
 - [https://tvn24.pl/swiat/wojna-w-ukrainie-relacja-na-zywo-27-marca-2023-6862416?source=rss](https://tvn24.pl/swiat/wojna-w-ukrainie-relacja-na-zywo-27-marca-2023-6862416?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-03-27 03:20:57+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qeyd05-zelenski-front-6855399/alternates/LANDSCAPE_1280" />
    Relacjonujemy wydarzenia z i wokół Ukrainy.

