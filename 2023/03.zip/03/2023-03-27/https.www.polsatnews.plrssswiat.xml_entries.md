# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## Białoruski propagandysta grozi Polsce bronią jądrową. "Warszawa się stopi"
 - [https://www.polsatnews.pl/wiadomosc/2023-03-27/bialoruski-propagandysta-grozi-polsce-bronia-jadrowa-warszawa-sie-stopi/](https://www.polsatnews.pl/wiadomosc/2023-03-27/bialoruski-propagandysta-grozi-polsce-bronia-jadrowa-warszawa-sie-stopi/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-27 20:11:00+00:00

Władimir Putin ogłosił, że Rosja zamierza rozmieścić na Białorusi broń jądrową. Obietnica bardzo ucieszyła jednego z białoruskich propagandystów, który będąc na wizji zaczął grozić Polsce i Litwie. - Warszawa się stopi, a Wilno zatonie! - stwierdził.

## Izrael: Netanjahu chwilo ustępuje. Zwrot ws. reformy sądownictwa
 - [https://www.polsatnews.pl/wiadomosc/2023-03-27/izrael-netanjahu-chwilo-ustepuje-zwrot-ws-reformy-sadownictwa/](https://www.polsatnews.pl/wiadomosc/2023-03-27/izrael-netanjahu-chwilo-ustepuje-zwrot-ws-reformy-sadownictwa/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-27 18:44:00+00:00

Benjamin Netanjahu wygłosił orędzie, w którym poinformował o odroczeniu procedowania swojej reformy sądownictwa do następnej sesji parlamentu. Organizujące protesty związki zawodowe odwołały swoje akcje strajkowe. Bardziej sceptyczna jest opozycja. Były premier Izraela pyta czy to nie sztuczka lub blef.

## Ukraina: Nie żyje polski wolontariusz
 - [https://www.polsatnews.pl/wiadomosc/2023-03-27/ukraina-nie-zyje-polski-wolontariusz/](https://www.polsatnews.pl/wiadomosc/2023-03-27/ukraina-nie-zyje-polski-wolontariusz/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-27 17:21:00+00:00

W Kijowie zmarł polski wolontariusz, który jeździł z pomocą humanitarną do Ukrainy. Marek zginął od ran odniesionych podczas ostrzału Rosjan.

## USA. Chwaliła się, że nigdy nie miała wypadku. Zginęła kilka dni później w wypadku
 - [https://www.polsatnews.pl/wiadomosc/2023-03-27/chwalila-sie-ze-nigdy-nie-miala-wypadku-zginela-kilka-dni-pozniej-w-wypadku/](https://www.polsatnews.pl/wiadomosc/2023-03-27/chwalila-sie-ze-nigdy-nie-miala-wypadku-zginela-kilka-dni-pozniej-w-wypadku/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-27 17:15:00+00:00

Uczennica liceum, która chwaliła się na TikToku, że nigdy nie miała wypadku samochodowego, zginęła zaledwie kilka dni później w czołowym zderzeniu z innym autem.

## Kanada: Złote rybki zagrożeniem dla środowiska. Ludzie spuszczali je w toaletach
 - [https://www.polsatnews.pl/wiadomosc/2023-03-27/kanada-zlote-rybki-zagrozeniem-dla-srodowiska-ludzie-spuszczali-je-w-toaletach/](https://www.polsatnews.pl/wiadomosc/2023-03-27/kanada-zlote-rybki-zagrozeniem-dla-srodowiska-ludzie-spuszczali-je-w-toaletach/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-27 16:58:00+00:00

Kanadyjscy naukowcy alarmują, że złote rybki stanowią zagrożenie dla środowiska naturalnego i są niebezpieczne dla rodzimych gatunków ryb. Rozmnażają się w niekontrolowany sposób, a do zbiorników wodnych trafiły między innymi przez toalety, kiedy ludzie chcieli się ich pozbyć ze swoich akwariów.

## USA. Strzelanina w prywatnej, chrześcijańskiej szkole. Nie żyje troje dzieci i dwoje dorosłych
 - [https://www.polsatnews.pl/wiadomosc/2023-03-27/usa-strzelanina-w-prywatnej-chrzescijanskiej-szkole-nie-zyje-troje-dzieci-i-napastnik/](https://www.polsatnews.pl/wiadomosc/2023-03-27/usa-strzelanina-w-prywatnej-chrzescijanskiej-szkole-nie-zyje-troje-dzieci-i-napastnik/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-27 16:50:00+00:00

Co najmniej pięć zginęło w strzelaninie, do której doszło w poniedziałek rano w szkole chrześcijańskiej w Nashville (USA). Wśród ofiar jest troje dzieci i napastnik. Na razie nie wiadomo, dlaczego zaatakował uczniów - podje Reuters.

## Węgierski parlament wyraził zgodę na wstąpienie Finlandii do NATO
 - [https://www.polsatnews.pl/wiadomosc/2023-03-27/wegierski-parlament-wyrazil-zgode-na-wstapienie-finlandii-do-nato/](https://www.polsatnews.pl/wiadomosc/2023-03-27/wegierski-parlament-wyrazil-zgode-na-wstapienie-finlandii-do-nato/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-27 16:14:00+00:00

Węgierski parlament zatwierdził w poniedziałek ustawę zezwalającą Finlandii na przystąpienie do NATO po ratyfikacji jej wniosku przez 30 członków sojuszu. Kończy to wielomiesięczne ociąganie się rządzącej partii Fidesz w tej sprawie - informuje Reuters.

## Wojna w Ukrainie. Media: Niemcy przekazały 18 czołgów
 - [https://www.polsatnews.pl/wiadomosc/2023-03-27/wojna-w-ukrainie-media-niemcy-przekazaly-18-czolgow/](https://www.polsatnews.pl/wiadomosc/2023-03-27/wojna-w-ukrainie-media-niemcy-przekazaly-18-czolgow/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-27 16:12:00+00:00

18 czołgów Leopard 2A6 przekazanych przez Niemcy jest już w Ukrainie - przekazał dziennik Der Spiegel. Rząd federalny dostarczył sprzęt dwa miesiące po deklaracji oraz miesiąc po przekazaniu czołgów przez Polskę.

## Turbulencje w samolocie. 10 pasażerów zostało rannych
 - [https://www.polsatnews.pl/wiadomosc/2023-03-27/turbulencje-w-samolocie-10-pasazerow-zostalo-rannych/](https://www.polsatnews.pl/wiadomosc/2023-03-27/turbulencje-w-samolocie-10-pasazerow-zostalo-rannych/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-27 15:43:00+00:00

Pasażerowie lecący z Angoli do Portugalii zapamiętają tę podróż na długo. Wszystko z powodu bardzo silnych turbulencji, w które wpadła maszyna. W ich wyniku 10 osób na pokładzie zostało rannych.

## USA. Zabiła swoje córki po rozstaniu z mężem. To była zemsta
 - [https://www.polsatnews.pl/wiadomosc/2023-03-27/usa-zabila-swoje-corki-po-rozstaniu-z-mezem-to-byla-zemsta/](https://www.polsatnews.pl/wiadomosc/2023-03-27/usa-zabila-swoje-corki-po-rozstaniu-z-mezem-to-byla-zemsta/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-27 15:01:00+00:00

Veronica Youngblood z Wirginii (USA) została uznana za winną zamordowania swoich dwóch córek - pięciolatki i piętnastolatki. Według prokuratury kobieta zrobiła to z zemsty na byłym mężu, który chciał się wyprowadzić z jedną z dziewcząt. Po zastrzeleniu córek kobieta zadzwoniła do niego i powiedziała, co zrobiła.

## USA. Nauczycielka molestowała uczniów. Wysyłała im nagie zdjęcia
 - [https://www.polsatnews.pl/wiadomosc/2023-03-27/usa-nauczycielka-molestowala-uczniow-wysylala-im-nagie-zdjecia/](https://www.polsatnews.pl/wiadomosc/2023-03-27/usa-nauczycielka-molestowala-uczniow-wysylala-im-nagie-zdjecia/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-27 14:42:00+00:00

43-letnia nauczycielka z liceum w Oklahomie została aresztowana przez policję za molestowanie i prześladowanie uczniów. Kobieta miała wysyłać nastolatkom swoje nagie zdjęcia oraz domagać się tego samego od nich.

## Indie: Mężczyźni skazani za morderstwo i rabunek. Sprawców wskazała papuga
 - [https://www.polsatnews.pl/wiadomosc/2023-03-27/indie-mezczyzni-skazani-za-morderstwo-i-rabunek-sprawcow-wskazala-papuga/](https://www.polsatnews.pl/wiadomosc/2023-03-27/indie-mezczyzni-skazani-za-morderstwo-i-rabunek-sprawcow-wskazala-papuga/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-27 13:55:00+00:00

Policja w Indiach przez lata nie mogła udowodnić, kto stoi za morderstwem żony redaktora naczelnego jednej z lokalnych gazet. Ostatecznie pomocne okazało się zeznanie papugi, która w obecności funkcjonariuszy wskazała sprawcę. Kiedy mężczyzna został zatrzymany, wyjawił, kto był jego wspólnikiem.

## Belgia. Zmarł gangster Alain Moussa. "Odszedł bez broni i bez nienawiści"
 - [https://www.polsatnews.pl/wiadomosc/2023-03-27/belgia-zmarl-gangster-alain-moussa/](https://www.polsatnews.pl/wiadomosc/2023-03-27/belgia-zmarl-gangster-alain-moussa/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-27 13:07:00+00:00

Belgijski gangster Alain Moussa, jeden z podejrzanych w sprawie Brabant Killers, zmarł w piątek wieczorem na atak serca. Miał 71 lat. W mediach społecznościowych jego partnerka napisała, że odszedł bez broni, bez przemocy i bez nienawiści. Gangster ostatnie lata swojego życia spędził w Ganshoren, gdzie prowadził skromne życie.

## Rosjanie i Białorusini wystąpią na igrzyskach w Paryżu? Polskie MSZ: Nie ma ani jednego powodu
 - [https://www.polsatnews.pl/wiadomosc/2023-03-27/rosjanie-i-bialorusini-wystapia-na-igrzyskach-w-paryzu-polskie-msz-nie-ma-ani-jednego-powodu/](https://www.polsatnews.pl/wiadomosc/2023-03-27/rosjanie-i-bialorusini-wystapia-na-igrzyskach-w-paryzu-polskie-msz-nie-ma-ani-jednego-powodu/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-27 11:47:00+00:00

Możliwe, że rosyjscy i białoruscy sportowcy pojawią się na Igrzyskach Olimpijskich w Paryżu w 2024 roku. MKOl rozważa zdjęcie szlabanu pod warunkiem, że zawodnicy z tych państw wystąpią pod neutralną flagą i nie będą manifestować swojej narodowości. Decyzji jeszcze nie podjęto, ale Polska i inne kraje przestrzegają przed złagodzeniem polityki wobec Rosji i Białorusi. Wydały wspólne oświadczenie.

## Przerażający wypadek w USA. Samochód leciał nad autostradą
 - [https://www.polsatnews.pl/wiadomosc/2023-03-27/przerazajacy-wypadek-w-usa-samochod-lecial-nad-autostrada/](https://www.polsatnews.pl/wiadomosc/2023-03-27/przerazajacy-wypadek-w-usa-samochod-lecial-nad-autostrada/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-27 10:55:00+00:00

Tesla zarejestrowała spektakularny i niezwykle groźny wypadek na jednej z kalifornijskich autostrad. Auto dosłownie wystrzeliło w powietrze, unosząc się kilka metrów nad ziemią.

## USA: Hydraulik zasnął podczas pracy. Był wtedy w ciasnym pomieszczeniu pod podłogą
 - [https://www.polsatnews.pl/wiadomosc/2023-03-27/usa-hydraulik-zasnal-podczas-pracy-byl-wtedy-w-ciasnym-pomieszczeniu-pod-podloga/](https://www.polsatnews.pl/wiadomosc/2023-03-27/usa-hydraulik-zasnal-podczas-pracy-byl-wtedy-w-ciasnym-pomieszczeniu-pod-podloga/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-27 10:52:00+00:00

50-letni hydraulik przyszedł do domu klienta w amerykańskim stanie Kalifornia. Wszedł do ciasnego, pustego pomieszczenia pod podłogą, a kontakt z nim urwał się. Zmartwiony właściciel budynku zadzwonił po pomoc. Na miejsce przyjechali strażacy, którzy postanowili wykonać dziury w podłodze i wyciągnąć fachowca. Wtedy okazało się, że specjaliście od rur nic nie jest. Po prostu...zasnął.

## Japonia: Studentka zmarła po spotkaniu ze znajomym. W drinku był trujący pierwiastek
 - [https://www.polsatnews.pl/wiadomosc/2023-03-27/japonia-studentka-zmarla-po-spotkaniu-ze-znajomym-w-drinku-byl-trujacy-pierwiastek/](https://www.polsatnews.pl/wiadomosc/2023-03-27/japonia-studentka-zmarla-po-spotkaniu-ze-znajomym-w-drinku-byl-trujacy-pierwiastek/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-27 10:10:00+00:00

Agent nieruchomości z Japonii jest podejrzany o zabójstwo 21-letniej studentki, z którą umówił się na spędzenie wieczoru. Śledczy twierdzą, że dodał do jej napoju tal - pierwiastek, którego nawet niewielka ilość może spowodować śmierć. Do uznania, że 37-latek jest mordercą, prokuratorów skłoniła też historia jego krewnej. Kobieta od trzech lat jest w stanie śpiączki, również po otruciu talem.

## Zamach na szefa policji w okupowanym Mariupolu. Ukraina: To nasi partyzanci
 - [https://www.polsatnews.pl/wiadomosc/2023-03-27/zamach-na-szefa-policji-w-okupowanym-mariupolu-ukraina-to-nasi-partyzanci/](https://www.polsatnews.pl/wiadomosc/2023-03-27/zamach-na-szefa-policji-w-okupowanym-mariupolu-ukraina-to-nasi-partyzanci/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-27 10:09:00+00:00

W poniedziałek rano doszło do próby zamachu na samochód Michaiła Moskwina, szefa policji w okupowanym przez Rosjan Mariupolu. Według Ukrainy zamach zorganizował ukraiński ruch oporu. Moskwin przeżył, doznał wstrząsu mózgu.

## USA: Wyszedł do toalety i nie wrócił. Chirurg plastyczny Tomasz Kosowski oskarżony o zabójstwo
 - [https://www.polsatnews.pl/wiadomosc/2023-03-27/usa-wyszedl-do-toalety-i-nie-wrocil-dr-tomasz-kosowski-oskarzony-o-zabojstwo/](https://www.polsatnews.pl/wiadomosc/2023-03-27/usa-wyszedl-do-toalety-i-nie-wrocil-dr-tomasz-kosowski-oskarzony-o-zabojstwo/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-27 10:03:00+00:00

Prawnik Steven Cozzi z Florydy poszedł do toalety w swojej firmie i nigdy nie wrócił. Mimo, że wciąż nie znaleziono jego ciała, śledczy zarzucają chirurgowi plastycznemu Tomaszowi Kosowskiemu dokonanie zabójstwa.

## Włochy: Szybowiec rozbił się w ogrodzie niedaleko kościoła. Pilot skakał
 - [https://www.polsatnews.pl/wiadomosc/2023-03-27/wlochy-szybowiec-rozbil-sie-w-ogrodzie-niedaleko-kosciola/](https://www.polsatnews.pl/wiadomosc/2023-03-27/wlochy-szybowiec-rozbil-sie-w-ogrodzie-niedaleko-kosciola/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-27 09:11:00+00:00

Wypadek szybowca niedaleko Mediolanu w Lombardii we Włoszech. 22-letni pilot wpadł w kłopoty inie opanował maszyny, co zmusiło go do awaryjnego jej opuszczenia. Ocalał skacząc ze spadochronem. Jednak pozbawiony sterowania płatowiec spadł bezwładnie na osiedle i wbił się w trawnik przed jedna z rezydencji. Maszyna uległa kompletnemu zniszczeniu. Nikt nie ucierpiał.

## Finlandia: Ben Zyskowicz zaatakowany na ulicy. "Za NATO i judaizm"
 - [https://www.polsatnews.pl/wiadomosc/2023-03-27/finlandia-ben-zyskowicz-zaatakowany-na-ulicy-za-nato-i-judaizm/](https://www.polsatnews.pl/wiadomosc/2023-03-27/finlandia-ben-zyskowicz-zaatakowany-na-ulicy-za-nato-i-judaizm/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-27 08:28:00+00:00

Ben Zyskowicz to popularny fiński polityk. Od ponad 40 lat jest regularnie wybierany na posła do Eduskunty. W miniony weekend został zaatakowany na ulicach Helsinek. Agresywny mężczyzna rzucił się na niego i groził mu śmiercią. Wszystko przez NATO i żydowskie pochodzenie polityka.

## Izrael: Prezydent wzywa rząd do wstrzymania reformy sądownictwa. W kraju trwają protesty
 - [https://www.polsatnews.pl/wiadomosc/2023-03-27/izrael-prezydent-wzywa-rzad-do-wstrzymania-reformy-sadownictwa-w-kraju-trwaja-protesty/](https://www.polsatnews.pl/wiadomosc/2023-03-27/izrael-prezydent-wzywa-rzad-do-wstrzymania-reformy-sadownictwa-w-kraju-trwaja-protesty/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-27 08:21:00+00:00

Prezydent Izraela Izzak Herzog wezwał rząd do natychmiastowego wstrzymania reformy sądownictwa, przeciwko której w kraju trwają gwałtowne protesty. Głowa państwa napisał na Twitterze, że należy wstrzymać proces legislacyjny w imię odpowiedzialności i dobra Izraela.

## Wielka Brytania: Pokaz agresji na drodze. Kierowca celowo potrącił motocyklistę
 - [https://www.polsatnews.pl/wiadomosc/2023-03-27/wielka-brytania-pokaz-agresji-na-drodze-kierowca-celowo-potracil-motocykliste/](https://www.polsatnews.pl/wiadomosc/2023-03-27/wielka-brytania-pokaz-agresji-na-drodze-kierowca-celowo-potracil-motocykliste/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-27 07:43:00+00:00

Zachowanie motocyklisty rozwścieczyło kierowcę renault. 69-latek postanowił samodzielnie wymierzyć sprawiedliwość i rozpoczął szaleńczy pościg za uciekającym pojazdem. W końcu udało mu się go potrącić. Sąd nie miał litości - wymierzył karę bezwzględnego więzienia.

## Jonathan Majors zatrzymany. Hollywoodzki aktor jest oskarżony o napaść na kobietę
 - [https://www.polsatnews.pl/wiadomosc/2023-03-27/jonathan-majors-zatrzymany-hollywoodzki-aktor-jest-oskarzony-o-napasc-na-kobiete/](https://www.polsatnews.pl/wiadomosc/2023-03-27/jonathan-majors-zatrzymany-hollywoodzki-aktor-jest-oskarzony-o-napasc-na-kobiete/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-27 07:10:00+00:00

Hollywoodzki aktor Jonathan Majors został aresztowany pod zarzutem napaści na kobietę. Ofiarą miała być partnerka gwiazdora Marvela, a powodem ataku kłótnia pary.

## Orlando Bloom odwiedził Ukrainę. Spotkał się z Wołodymyrem Zełenskim
 - [https://www.polsatnews.pl/wiadomosc/2023-03-27/orlando-bloom-odwiedzil-ukraine-spotkal-sie-z-wolodymyrem-zelenskim/](https://www.polsatnews.pl/wiadomosc/2023-03-27/orlando-bloom-odwiedzil-ukraine-spotkal-sie-z-wolodymyrem-zelenskim/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-27 06:54:00+00:00

Hollywodzki gwiazdor, Orlando Bloom, niespodziewanie przyjechał do ogarniętej wojną Ukrainy. Aktor od lat współpracuje z UNICEF. W Kijowie spotkał się dziećmi w jednym z ośrodków pomocy dla najmłodszych. Rozmawiał także z prezydentem Ukrainy.

## Niemcy. Wypadek trzech porsche, zginęło czworo Holendrów. Dramat na autostradzie pod Kolonią
 - [https://www.polsatnews.pl/wiadomosc/2023-03-27/niemcy-wypadek-trzech-porsche-zginelo-czworo-holendrow-dramat-na-autostradzie-pod-kolonia/](https://www.polsatnews.pl/wiadomosc/2023-03-27/niemcy-wypadek-trzech-porsche-zginelo-czworo-holendrow-dramat-na-autostradzie-pod-kolonia/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-27 06:28:00+00:00

Tragedia na autostradzie A3 w pobliżu Kolonii w Niemczech. W trudnych warunkach doszło do wypadku z udziałem trzech aut marki Porsche. Zginęły cztery osoby. Dwie z nich przeżyły najpierw kolizję pierwszego auta, a kierowca drugiego zatrzymał się, by pomóc. Gdy wysiadł, uderzyło w nich trzecie. Zginęli wszyscy troje. Zmarł też kierowca ostatniego porsche. Przeżył pasażer ostatniego z aut.

## Holandia: Skakał po radiowozie, ugryzł policjanta w rękę
 - [https://www.polsatnews.pl/wiadomosc/2023-03-27/holandia-skakal-po-radiowozie-ugryzl-policjanta-w-reke/](https://www.polsatnews.pl/wiadomosc/2023-03-27/holandia-skakal-po-radiowozie-ugryzl-policjanta-w-reke/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-27 06:21:00+00:00

Niecodzienny widok ukazał się oczom funkcjonariusza jadącego rowerem o świcie do pracy. Na dachu zaparkowanego radiowozu zobaczył skaczącego mężczyznę. Udało mu się skutecznie powstrzymać wandala, ale przypłacił to obrażeniami - 49-latek ugryzł policjanta w rękę.

## Niemcy: Strajk ostrzegawczy pracowników transportu. Nie jeżdżą pociągi, odwołane loty
 - [https://www.polsatnews.pl/wiadomosc/2023-03-27/niemcy-strajk-ostrzegawczy-pracownikow-transportu-nie-jezdza-pociagi-odwolane-loty/](https://www.polsatnews.pl/wiadomosc/2023-03-27/niemcy-strajk-ostrzegawczy-pracownikow-transportu-nie-jezdza-pociagi-odwolane-loty/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-03-27 05:02:00+00:00

24-godzinny strajk ostrzegawczy pracowników transportu publicznego rozpoczął się w Niemczech w nocy z niedzieli na poniedziałek. Odwoływane są setki połączeń kolejowych, lotniczych i autobusowych, niekoniecznie przejezdne są też autostrady. Protestujący żądają podwyżek, a dotychczasowe propozycje pracodawców uznają za niewystarczające. Kolejny taki protest może odbyć się w czasie Wielkanocy.

