# Source:GamingBolt, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXa_bzvv7Oo1glaW9FldDhQ, language:en-US

## 15 BOSS BATTLES That Were Just PLAIN SILLY
 - [https://www.youtube.com/watch?v=wFNtONRnzyU](https://www.youtube.com/watch?v=wFNtONRnzyU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXa_bzvv7Oo1glaW9FldDhQ
 - date published: 2023-03-27 15:30:19+00:00

Boss fights are arguably one of the highlights for any action game, and they come in a wide variety of shapes and sizes. Some fights are brutal while others can be forgettable, but the most interesting types of bosses are the ones that can best be described as silly. 

This can be due to some hilarious boss design, funny mechanics, weird difficulty, or perhaps something completely different - and we will be running down 15 of such silly boss fights in games with this feature.

## 15 RISKIEST AAA Games of All Time
 - [https://www.youtube.com/watch?v=m6WFdTOhMd8](https://www.youtube.com/watch?v=m6WFdTOhMd8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXa_bzvv7Oo1glaW9FldDhQ
 - date published: 2023-03-27 13:30:15+00:00

The games industry has come a long way from its humble beginnings, and stands tall as one of the most valuable mediums of entertainment with a market cap that’s much larger than TV or movies. 

Games require large amounts of capital, time, and manpower to produce - which is why publishers and investors are too resistant to take risks that might or might not pay off. But of course, that’s not always the case and we have had plenty of examples of risky AAA ventures which we will be discussing in this feature.

