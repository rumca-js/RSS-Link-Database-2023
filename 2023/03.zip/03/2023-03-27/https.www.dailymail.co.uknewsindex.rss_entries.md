# Source:Daily Mail, URL:https://www.dailymail.co.uk/news/index.rss, language:en-US

## British scientists discover how high blood pressure affects NINE different parts of the brain
 - [https://www.dailymail.co.uk/news/article-11909233/British-scientists-discover-high-blood-pressure-affects-NINE-different-parts-brain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11909233/British-scientists-discover-high-blood-pressure-affects-NINE-different-parts-brain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 23:59:37+00:00

British researchers discovered it causes changes to nine regions of the brain - including those associated with learning, decision making, cognition and emotions.

## Tugun Gold Coast: Woman dies after she allegedly entered property and scuffled with residents
 - [https://www.dailymail.co.uk/news/article-11909057/Tugun-Gold-Coast-Woman-dies-allegedly-entered-property-scuffled-residents.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11909057/Tugun-Gold-Coast-Woman-dies-allegedly-entered-property-scuffled-residents.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 23:57:37+00:00

A woman has died after she allegedly entered a home at Tugun on the Gold Coast and was restrained by residents in the early hours of Tuesday morning.

## Pence to make eighth trip to Iowa as he mulls 2024 bid
 - [https://www.dailymail.co.uk/news/article-11908719/Pence-make-eighth-trip-Iowa-mulls-2024-bid.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908719/Pence-make-eighth-trip-Iowa-mulls-2024-bid.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 23:54:04+00:00

Former Vice President Mike Pence will make his eighth trip to Iowa Wednesday, as he flirts with launching a presidential bid against his ex-running mate, former President Donald Trump.

## Jim Jordan accuses Democrats of 'politicizing' Nashville shooting and delays ATF markup
 - [https://www.dailymail.co.uk/news/article-11908957/Jim-Jordan-accuses-Democrats-politicizing-Nashville-shooting-delays-ATF-markup.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908957/Jim-Jordan-accuses-Democrats-politicizing-Nashville-shooting-delays-ATF-markup.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 23:53:18+00:00

Judiciary Chair Jim Jordan is delaying his panel's Tuesday markup of Biden's budget seeking to implement more gun control by massively increasing funding by 7.3% for the ATF.

## Policeman who pushed pregnant partner down stairs convicted of controlling and coercive behaviour
 - [https://www.dailymail.co.uk/news/article-11908993/Policeman-pushed-pregnant-partner-stairs-convicted-controlling-coercive-behaviour.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908993/Policeman-pushed-pregnant-partner-stairs-convicted-controlling-coercive-behaviour.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 23:52:25+00:00

Thomas Gair, 23, pushed his pregnant girlfriend Chloe Bradley down the stairs at their home in Norton, Teesside after three years of abusive behaviour.

## Foreign Secretary criticises government's plan to house migrants in a former RAF base
 - [https://www.dailymail.co.uk/news/article-11909115/Foreign-Secretary-criticises-governments-plan-house-migrants-former-RAF-base.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11909115/Foreign-Secretary-criticises-governments-plan-house-migrants-former-RAF-base.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 23:45:56+00:00

A former RAF base at Wethersfield in north Essex has been identified as a suitable site to house 1,500 male asylum seekers - more than double the 700 residents who live nearby.

## Princess of Wales will hand coveted trophy to both men and women's singles champions
 - [https://www.dailymail.co.uk/news/article-11909105/Princess-Wales-hand-coveted-trophy-men-womens-singles-champions.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11909105/Princess-Wales-hand-coveted-trophy-men-womens-singles-champions.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 23:41:30+00:00

Continuing her tradition of presenting the singles trophies as the All England Club's patron, sources say she will hand over silverware to any winner, regardless of their nationality.

## Retailers warn the rising cost of key ingredients means food inflation grew to 15 per cent
 - [https://www.dailymail.co.uk/news/article-11909139/Retailers-warn-rising-cost-key-ingredients-means-food-inflation-surpass-15.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11909139/Retailers-warn-rising-cost-key-ingredients-means-food-inflation-surpass-15.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 23:39:07+00:00

Food price inflation rose from 14.5 per cent in February to 15 per cent this month, while the figure for fresh food hit a record of 17 per cent, according to the British Retail Consortium.

## Georgia teen in ICU after brutal hazing incident
 - [https://www.dailymail.co.uk/news/article-11908777/Georgia-teen-ICU-brutal-hazing-incident.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908777/Georgia-teen-ICU-brutal-hazing-incident.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 23:35:53+00:00

Trent Lehrkamp, 19, remains in the intensive care unit in a stable condition following the out-of-control abuse he suffered during a spring break house party at a Saint Simon's Island party.

## Queensland housing crisis: Photos reveal devastating effect of homelessness in the sunshine state
 - [https://www.dailymail.co.uk/news/article-11908763/Queensland-housing-crisis-Photos-reveal-devastating-effect-homelessness-sunshine-state.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908763/Queensland-housing-crisis-Photos-reveal-devastating-effect-homelessness-sunshine-state.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 23:35:23+00:00

Heartbreaking photos have confirmed fears of a deepening housing crisis, with more and more Queenslanders forced to live in cars and 'tent cities'.

## Millions of British families are already failing to pay vital bills
 - [https://www.dailymail.co.uk/news/article-11909155/Millions-British-families-failing-pay-vital-bills.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11909155/Millions-British-families-failing-pay-vital-bills.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 23:29:58+00:00

Prices are set to surge by as much as 17.3 per cent on broadband and mobile, alongside other rises in April. The increases come as 2.5million families have already fallen behind on 'must pay' bills.

## Schools face MORE closures from strikes as teaching union urges members to reject fresh pay offer
 - [https://www.dailymail.co.uk/news/article-11909027/Schools-face-closures-strikes-teaching-union-urges-members-reject-fresh-pay-offer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11909027/Schools-face-closures-strikes-teaching-union-urges-members-reject-fresh-pay-offer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 23:02:07+00:00

The call by the National Education Union last night to reject a new pay offer sparked fears that pupils could face more misery less than two months before some sit their GCSE exams.

## GOP House chair blasts Manhattan DA for 'engaging with federal agencies' on Trump case
 - [https://www.dailymail.co.uk/news/article-11908045/GOP-House-chair-blasts-Manhattan-DA-engaging-federal-agencies-Trump-case.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908045/GOP-House-chair-blasts-Manhattan-DA-engaging-federal-agencies-Trump-case.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 23:01:50+00:00

Republican Rep. Bryan Steil of Wisconsin continues his attacks on what he called a 'politically motivated' prosecution of former President Trump, in reference to DA Alvin Bragg's probe.

## Child migrants will NOT be excluded from tough new measures to combat the Channel crisis
 - [https://www.dailymail.co.uk/news/article-11909067/Child-migrants-NOT-excluded-tough-new-measures-combat-Channel-crisis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11909067/Child-migrants-NOT-excluded-tough-new-measures-combat-Channel-crisis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 23:00:35+00:00

Proposals to exclude child migrants from tough new measures to combat the Channel crisis were ruled out by the Government last night.

## Nashville school shooter Audrey Hale is transgender former student who plotted massacre in detail
 - [https://www.dailymail.co.uk/news/article-11908745/Nashville-school-shooter-Audrey-Hale-transgender-former-student-plotted-massacre-detail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908745/Nashville-school-shooter-Audrey-Hale-transgender-former-student-plotted-massacre-detail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 23:00:19+00:00

The private school shooter in Nashville who killed six, including three nine-year-old children and three staff members, is a transgender woman and alumnus of the school and left a manifesto.

## Phillip Schofield's brother sexually abused a schoolboy, court hears
 - [https://www.dailymail.co.uk/news/article-11908075/Phillip-Schofields-brother-sexually-abused-schoolboy-court-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908075/Phillip-Schofields-brother-sexually-abused-schoolboy-court-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 22:59:39+00:00

The brother of presenter Phillip Schofield (far left) Timothy Schofield (right) 54, is charged with 11 counts of sexual offences against a boy over three years from October 2016 at Exeter Crown Court.

## Key witness in Mail case says hacking claims 'false': Private investigator denies allegations
 - [https://www.dailymail.co.uk/news/article-11908555/Key-witness-Mail-case-says-hacking-claims-false-Private-investigator-denies-allegations.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908555/Key-witness-Mail-case-says-hacking-claims-false-Private-investigator-denies-allegations.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 22:45:21+00:00

In a smart black suit and blue tie, Harry sat behind his lawyers in Court 76 of the Royal Courts of Justice, listening intently and making notes.

## AI poses a threat to two thirds of jobs in the US and Europe, study finds
 - [https://www.dailymail.co.uk/news/article-11908991/AI-poses-threat-two-thirds-jobs-Europe-study-finds.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908991/AI-poses-threat-two-thirds-jobs-Europe-study-finds.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 22:42:56+00:00

A quarter of jobs could soon be automated as a result of breakthroughs in artificial intelligence, a report has warned.

## Bob Carr sheds light on Barack Obama's unique eating habits
 - [https://www.dailymail.co.uk/news/article-11908741/Bob-Carr-sheds-light-Barack-Obamas-unique-eating-habits.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908741/Bob-Carr-sheds-light-Barack-Obamas-unique-eating-habits.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 22:41:49+00:00

Former US President Barack Obama has been praised by a  senior former Australian politician not only for his political talent, but for the 'admirable discipline' of his eating habits.

## Children's books written by celebrities 'do nothing for literacy', says Anthony Horowitz
 - [https://www.dailymail.co.uk/news/article-11908975/Childrens-books-written-celebrities-literacy-says-Anthony-Horowitz.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908975/Childrens-books-written-celebrities-literacy-says-Anthony-Horowitz.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 22:34:50+00:00

The novelist Anthony Horowitz, 57, who writes the popular young adult Alex Rider franchise, said some books may be entertaining, but the writing quality is not 'literary'.

## Nashville TV anchors break down in tears while reporting on school shooting that killed six
 - [https://www.dailymail.co.uk/news/article-11908737/Nashville-TV-anchors-break-tears-reporting-school-shooting-killed-six.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908737/Nashville-TV-anchors-break-tears-reporting-school-shooting-killed-six.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 22:27:14+00:00

Two local NBC affiliate anchors faced a difficult task during their live news coverage of the tragic Nashville school shooting that saw six killed including three children.

## Cost of living squeeze will start to ease within WEEKS thanks to a 'sharp fall in inflation'
 - [https://www.dailymail.co.uk/news/article-11908757/Cost-living-squeeze-start-ease-WEEKS-thanks-sharp-fall-inflation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908757/Cost-living-squeeze-start-ease-WEEKS-thanks-sharp-fall-inflation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 22:27:10+00:00

Andrew Bailey (pictured) predicted better times ahead in a major speech. Other forecasters also painted a positive picture of the economy alongside Rishi Sunak.

## Humza Yousaf won the SNP election... but is Sir Keir Starmer the real victor?
 - [https://www.dailymail.co.uk/news/article-11908723/Humza-Yousaf-won-SNP-election-Sir-Keir-Starmer-real-victor.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908723/Humza-Yousaf-won-SNP-election-Sir-Keir-Starmer-real-victor.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 22:02:47+00:00

Continuity candidate Humza Yousaf yesterday triumphed by a whisker in the bitter battle to succeed Nicola Sturgeon as leader of the SNP.

## Sir David Jason discovers he has a 52-year-old daughter who he had no idea existed
 - [https://www.dailymail.co.uk/news/article-11908733/Sir-David-Jason-discovers-52-year-old-daughter-no-idea-existed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908733/Sir-David-Jason-discovers-52-year-old-daughter-no-idea-existed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 22:01:41+00:00

The TV icon has now welcomed his newfound daughter, Abi Harris, and grandson, Charlie, into the family and says he is making up for lost time by doing as much as he can with them.

## Mom of student reveals she'd complain there was 'something wrong in my head' before Mexico trip
 - [https://www.dailymail.co.uk/news/article-11908263/Mom-student-reveals-shed-complain-wrong-head-Mexico-trip.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908263/Mom-student-reveals-shed-complain-wrong-head-Mexico-trip.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 22:01:03+00:00

Liza Burke, 21, complained that there was 'something wrong with my head' years before a bleed and brain tumor was discovered while she was on Spring Break.

## Nashville school shooting victims are identified
 - [https://www.dailymail.co.uk/news/article-11908753/Nashville-school-shooting-victims-identified.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908753/Nashville-school-shooting-victims-identified.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 21:50:22+00:00

Katherine Koonce, the 60-year-old head of The Covenant School in Nashville, was one of three adults and three nine-year-old children shot and killed on Monday by a female attacker.

## Prepare for the rental crisis to get even worse in Australia warns property investor
 - [https://www.dailymail.co.uk/news/article-11892041/Prepare-rental-crisis-worse-Australia-warns-property-investor.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11892041/Prepare-rental-crisis-worse-Australia-warns-property-investor.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 21:49:50+00:00

Property developer Tim Gurner predicts a new heyday is just around the corner with a building boom ahead for property developer - but billionaire builder Harry Triguboff blames RBA for crisis.

## Zelensky's security team feared Bear Grylls was trying to assassinate him with poisoned chocolate
 - [https://www.dailymail.co.uk/news/article-11908339/Zelenskys-security-team-feared-Bear-Grylls-trying-assassinate-poisoned-chocolate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908339/Zelenskys-security-team-feared-Bear-Grylls-trying-assassinate-poisoned-chocolate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 21:45:05+00:00

Survival expert Bear Grylls told GMB how he was stopped from giving President Volodymyr Zelensky a piece of chocolate amid security team fears that he was trying to poison him.

## Georgia homeowner shoots and kills intruder trying to break in to his house
 - [https://www.dailymail.co.uk/news/article-11908581/Georgia-homeowner-shoots-kills-intruder-trying-break-house.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908581/Georgia-homeowner-shoots-kills-intruder-trying-break-house.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 21:43:45+00:00

Police said the homeowner would not be charged with anything related to the shooting and the suspect's death because he was acting in self defense.

## Rhino dies at Werribee Open Range Zoo
 - [https://www.dailymail.co.uk/news/article-11908687/Rhino-dies-Werribee-Open-Range-Zoo.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908687/Rhino-dies-Werribee-Open-Range-Zoo.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 21:42:23+00:00

A popular Melbourne zoo is investigating the sudden death of a five-day-old female southern white rhinoceros calf.

## Charlamagne Tha God DEFENDS white Mississippi anchor FIRED for reciting Snoop Dogg lyrics
 - [https://www.dailymail.co.uk/news/article-11908429/Charlamagne-Tha-God-DEFENDS-white-Mississippi-anchor-FIRED-reciting-Snoop-Dogg-lyrics.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908429/Charlamagne-Tha-God-DEFENDS-white-Mississippi-anchor-FIRED-reciting-Snoop-Dogg-lyrics.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 21:41:58+00:00

White WLBT, employee Barbie Bassett,(right) was swiftly removed from the show after the incident on March 8.

## Nashville elementary attacked by former student provides $16,500-per-year Presbyterian education
 - [https://www.dailymail.co.uk/news/article-11908575/Nashville-elementary-attacked-former-student-provides-16-500-year-Presbyterian-education.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908575/Nashville-elementary-attacked-former-student-provides-16-500-year-Presbyterian-education.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 21:39:49+00:00

The Covenant School was founded in 2001 as a ministry of Covenant Presbyterian Church, with which it shares a building, and serves just about 200 students from preschool through sixth-grade.

## Horrifying moment masked teenager stabbed teacher dead and wounded five others, at Brazilian school
 - [https://www.dailymail.co.uk/news/article-11908141/Horrifying-moment-masked-teenager-stabbed-teacher-dead-wounded-five-Brazilian-school.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908141/Horrifying-moment-masked-teenager-stabbed-teacher-dead-wounded-five-Brazilian-school.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 21:38:58+00:00

A 13-year-old boy was apprehended at a Brazilian  school Monday morning after he stabbed a teacher, who died from a heart attack at a hospital, and wounded three others as well as a student, too.

## 'Oh hell no!' Megyn Kelly blasts ESPN for honoring transgender swimmer Lia Thomas
 - [https://www.dailymail.co.uk/news/article-11908513/Oh-hell-no-Megyn-Kelly-blasts-ESPN-honoring-transgender-swimmer-Lia-Thomas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908513/Oh-hell-no-Megyn-Kelly-blasts-ESPN-honoring-transgender-swimmer-Lia-Thomas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 21:25:03+00:00

Megyn Kelly has attacked ESPN for honoring transgender swimmer Lia Thomas as part of it celebration of Women's History Month.

## Prince Harry's estranged family have no plans to meet with him during his whirlwind visit to the UK
 - [https://www.dailymail.co.uk/news/article-11908457/Prince-Harrys-estranged-family-no-plans-meet-whirlwind-visit-UK.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908457/Prince-Harrys-estranged-family-no-plans-meet-whirlwind-visit-UK.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 21:16:02+00:00

Sources close to Harry seemingly briefed chosen members of the media that he had 'made contact' with his father to let him know he would be in the country, but was told that the king was 'busy'

## Google's chatbot denies any bias, but promotes transgenderism, Joe Biden and veganism
 - [https://www.dailymail.co.uk/news/article-11908383/Googles-chatbot-denies-bias-promotes-transgenderism-Joe-Biden-veganism.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908383/Googles-chatbot-denies-bias-promotes-transgenderism-Joe-Biden-veganism.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 21:13:34+00:00

Google's new chatbot insists it does not have a liberal bias, but DailyMail's 10 tests of Bard reveal its implicit political support for Joe Biden, transgender ideology, and universal healthcare access.

## Melbourne landlord $65,000 out of pocket after tenant refuses to leave property or pay rent
 - [https://www.dailymail.co.uk/news/article-11908427/Melbourne-landlord-65-000-pocket-tenant-refuses-leave-property-pay-rent.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908427/Melbourne-landlord-65-000-pocket-tenant-refuses-leave-property-pay-rent.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 21:03:00+00:00

Melbourne mum Nicole Hicks had rented out her house to a single mother on government welfare six years ago without a problem.

## JACI STEPHEN: Deliciously psychopathic SUCCESSion! Our favorite family of cut throats is back
 - [https://www.dailymail.co.uk/news/article-11908235/JACI-STEPHEN-Deliciously-psychopathic-SUCCESSion-favorite-family-cut-throats-back.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908235/JACI-STEPHEN-Deliciously-psychopathic-SUCCESSion-favorite-family-cut-throats-back.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 21:02:19+00:00

STEPHEN: Kendall, Shiv and Roman are in control. They've beaten Logan at his own game. Then comes the call. 'Congratulations on saying the biggest number, yer f***ing morons.'

## Prestigious school which taught six former PMs will admit girls for the first time in 700 yr history
 - [https://www.dailymail.co.uk/news/article-11908647/Prestigious-school-taught-six-former-PMs-admit-girls-time-700-yr-history.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908647/Prestigious-school-taught-six-former-PMs-admit-girls-time-700-yr-history.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 21:01:46+00:00

Westminster School (pictured), whose alma mater includes six former British Prime Minister, has allowed female pupils to join its sixth form for 50 years. Now it plans to extend that access.

## Florida teen killed in crash days after she posted viral video saying she'd never been in a wreck
 - [https://www.dailymail.co.uk/news/article-11908375/Florida-teen-killed-crash-days-posted-viral-video-saying-shed-never-wreck.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908375/Florida-teen-killed-crash-days-posted-viral-video-saying-shed-never-wreck.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 21:01:16+00:00

Kara Santorelli, 18, who posted a viral video saying she had never been in a car crash was killed just days after uploading the video to TikTok. The teen's vehicle was struck head-on on Highway 29.

## Car chases, KGB honeytraps and a furious Robert Maxwell... the astonishing tale of Tetris
 - [https://www.dailymail.co.uk/news/article-11908615/Car-chases-KGB-honeytraps-furious-Robert-Maxwell-astonishing-tale-Tetris.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908615/Car-chases-KGB-honeytraps-furious-Robert-Maxwell-astonishing-tale-Tetris.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 21:00:57+00:00

A fast-paced Cold War thriller featuring sinister KGB agents, Muscovite boffins, powerful U.S. capitalists and a raging British media tycoon. It all sounds like the plot of a computer game.

## 'I tried to help students - only for them to turn on me when I failed to endorse ideology'
 - [https://www.dailymail.co.uk/news/article-11908547/I-tried-help-students-turn-failed-endorse-ideology.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908547/I-tried-help-students-turn-failed-endorse-ideology.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 21:00:28+00:00

Are teenagers finding it easier to dress as girls than admit to being gay as a camp, insecure boys in a rough state school, asks secondary school teacher and whistleblower Harry Winter.

## Brian Kohberger pastor tells how he prays with the quadruple murderer
 - [https://www.dailymail.co.uk/news/article-11890075/Brian-Kohberger-pastor-tells-prays-quadruple-murderer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11890075/Brian-Kohberger-pastor-tells-prays-quadruple-murderer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 20:50:41+00:00

Bryan Kohberger has been receiving one-on-one sessions with members of Project Hope Idaho, a local Christian organization that provides gospel services to prisoners.

## Inside the wild trial of Pras Michel who is accused of taking $100m to influence Obama and Trump
 - [https://www.dailymail.co.uk/news/article-11907789/Inside-wild-trial-Pras-Michel-accused-taking-100m-influence-Obama-Trump.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907789/Inside-wild-trial-Pras-Michel-accused-taking-100m-influence-Obama-Trump.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 20:43:00+00:00

Pras Michel, 50, is accused of helping Malaysian billion-dollar financial conman Jho Low attempt to buy influence with the Obama and Trump administrations.

## Desperate search is launched after five-year-old boy vanishes without a trace
 - [https://www.dailymail.co.uk/news/article-11908473/Desperate-search-launched-five-year-old-boy-vanishes-without-trace.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908473/Desperate-search-launched-five-year-old-boy-vanishes-without-trace.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 20:41:31+00:00

A 5-year-old boy has vanished from his home in far-west Queensland.

## Tennessee congressman faces backlash for posing with rifle in 2021 holiday card
 - [https://www.dailymail.co.uk/news/article-11908439/Tennessee-congressman-faces-backlash-posing-rifle-2021-holiday-card.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908439/Tennessee-congressman-faces-backlash-posing-rifle-2021-holiday-card.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 20:16:48+00:00

Rep. Andy Ogles faced backlash after saying he was 'utterly heartbroken' over the mass shooting at The Covenant School in Tennessee - because of an image of the politician bearing arms.

## Josef Fritzl, 87, describes himself as a 'good guy' and 'responsible family man' in new book
 - [https://www.dailymail.co.uk/news/article-11908151/Josef-Fritzl-87-describes-good-guy-responsible-family-man-new-book.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908151/Josef-Fritzl-87-describes-good-guy-responsible-family-man-new-book.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 19:59:14+00:00

Josef Fritzl claims in a new book written with the help of a lawyer, that he is a 'good guy', has fathered multiple children abroad and is sent love letters to his cell in Stein prison in Krems an der Donau.

## Alabama cops pursue runaway pony named Ginuwine for two hours
 - [https://www.dailymail.co.uk/news/article-11907987/Alabama-cops-pursue-runaway-pony-named-Ginuwine-two-hours.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907987/Alabama-cops-pursue-runaway-pony-named-Ginuwine-two-hours.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 19:50:35+00:00

Police in Alabama released body cam footage of officers attempting to capture an escaped pony that  eluded their custody for two hours.

## Haunting picture of Nashville school children escaping shooting is reminiscent of Sandy Hook photo
 - [https://www.dailymail.co.uk/news/article-11908209/Haunting-picture-Nashville-school-children-escaping-shooting-reminiscent-Sandy-Hook-photo.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908209/Haunting-picture-Nashville-school-children-escaping-shooting-reminiscent-Sandy-Hook-photo.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 19:05:41+00:00

Just like the mass shooting 11 years ago, young children were today seen being shepherded, one by one, away from the school building where bullets rained.

## Female school shooter in Nashville is just the FIFTH in history
 - [https://www.dailymail.co.uk/news/article-11908187/Female-school-shooter-Nashville-just-FIFTH-history.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908187/Female-school-shooter-Nashville-just-FIFTH-history.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 19:04:56+00:00

The 28-year-old woman who opened fire at a private school in Nashville, Tennessee is just the fifth female school shooter in history.

## Nashville school shooting is America's 129th mass shooting in 2023
 - [https://www.dailymail.co.uk/news/article-11907933/Nashville-school-shooting-Americas-129th-mass-shooting-2023.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907933/Nashville-school-shooting-Americas-129th-mass-shooting-2023.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 19:04:25+00:00

The US surpassed the disturbing milestone of more than 100 mass shootings on March 5 - with the rate rising faster than the past ten years.

## Biden renews calls for Congress to pass 'my assault weapon ban'
 - [https://www.dailymail.co.uk/news/article-11908307/Biden-renews-calls-Congress-pass-assault-weapon-ban.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908307/Biden-renews-calls-Congress-pass-assault-weapon-ban.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 19:04:22+00:00

Biden renewed pressure on Congress to pass an assault weapons ban after a Nashville woman carrying two semi-automatic rifles killed six at an elementary school.

## Parents at Nashville school shooting express fury at gun laws
 - [https://www.dailymail.co.uk/news/article-11908121/Mass-shooting-survivors-parents-blast-gun-laws-three-kids-killed-school.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908121/Mass-shooting-survivors-parents-blast-gun-laws-three-kids-killed-school.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 19:02:32+00:00

Parents in Nashville - some of which have been victims of mass shooting themselves - have expressed their fury after a female shooter opened fire at a private elementary school on Monday.

## Phillip Schofield's brother sexually abused a schoolboy before confessing  to his famous sibling
 - [https://www.dailymail.co.uk/news/article-11908075/Phillip-Schofields-brother-sexually-abused-schoolboy-confessing-famous-sibling.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908075/Phillip-Schofields-brother-sexually-abused-schoolboy-confessing-famous-sibling.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 19:01:03+00:00

The brother of presenter Phillip Schofield (far left) Timothy Schofield (right) 54, is charged with 11 counts of sexual offences against a boy over three years from October 2016 at Exeter Crown Court.

## Mom of Navy sailor, 21, who disappeared in thin air after leaving Illinois bar begs for help
 - [https://www.dailymail.co.uk/news/article-11907979/Mom-Navy-sailor-21-disappeared-air-leaving-Illinois-bar-begs-help.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907979/Mom-Navy-sailor-21-disappeared-air-leaving-Illinois-bar-begs-help.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 18:59:52+00:00

Seamus Gray, who vanished from an Illinois bar, is still missing as his mother has described his disappearance as 'grueling, nauseating... and quite honestly soul crushing.'

## Life on Britain's most diverse street: 70 languages spoken on residential road near the Cotswolds
 - [https://www.dailymail.co.uk/news/article-11908237/Life-Britains-diverse-street-70-languages-spoken-residential-road-near-Cotswolds.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908237/Life-Britains-diverse-street-70-languages-spoken-residential-road-near-Cotswolds.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 18:47:23+00:00

This is Britain's most diverse street, where residents speak 70 languages from dozens of different ethnic groups.

## Nashville reporter shares that her mother-in-law was working at school when shooter opened fire
 - [https://www.dailymail.co.uk/news/article-11908143/Nashville-reporter-shares-mother-law-working-school-shooter-opened-fire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908143/Nashville-reporter-shares-mother-law-working-school-shooter-opened-fire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 18:46:31+00:00

A Nashville news reporter has described how her mother-in-law was working on the front desk of Covenant School when the shooter opened fire on Monday morning.

## Bare-knuckle boxers take to the ring at London's O2 arena at brutal event where gloves are banned
 - [https://www.dailymail.co.uk/news/article-11908269/Bare-knuckle-boxers-ring-Londons-O2-arena-brutal-event-gloves-banned.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908269/Bare-knuckle-boxers-ring-Londons-O2-arena-brutal-event-gloves-banned.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 18:43:34+00:00

Fearsome pictures have been released from BKB 31 showing the bloody aftermath of the bare-knuckle boxing event at London's O2 arena on the weekend.

## Historic fish and chip shop is forced to close after 62 years
 - [https://www.dailymail.co.uk/news/article-11908125/Historic-fish-chip-shop-forced-close-62-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908125/Historic-fish-chip-shop-forced-close-62-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 18:41:58+00:00

Owner Dennis Jackson, 84, said his age and the rising cost of food and energy were behind the decision to shut Jackson's Chippie in Ilkeston.

## Multi-millionaire tech investor 'pushed his groin against woman as she loaded dishwater', court told
 - [https://www.dailymail.co.uk/news/article-11908039/Multi-millionaire-tech-investor-pushed-groin-against-woman-loaded-dishwater-court-told.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908039/Multi-millionaire-tech-investor-pushed-groin-against-woman-loaded-dishwater-court-told.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 18:40:31+00:00

Stefan Glaenzer, 61, is accused of pressing his private parts against the woman as she loaded her dirty dishes into the machine at offices in Notting Hill, west London, on 9 June 2021.

## Five times chat show queen Oprah Winfrey got it wrong while grilling showbiz stars
 - [https://www.dailymail.co.uk/news/article-11907767/Five-times-chat-queen-Oprah-Winfrey-got-wrong-grilling-showbiz-stars.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907767/Five-times-chat-queen-Oprah-Winfrey-got-wrong-grilling-showbiz-stars.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 18:24:42+00:00

Popular talk show queen Oprah Winfrey is known for her intimate sit down chats, like her bombshell interview with Harry and Meghan - but even long-time hosts like Oprah get it wrong sometimes.

## 'I am truly without words': Jill Biden reacts to news six were killed in Nashville school shooting
 - [https://www.dailymail.co.uk/news/article-11908153/I-truly-without-words-Jill-Biden-reacts-news-six-killed-Nashville-school-shooting.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908153/I-truly-without-words-Jill-Biden-reacts-news-six-killed-Nashville-school-shooting.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 17:58:19+00:00

First Lady Jill Biden said she is 'without words' as she became the first person in the White House to publicly react to news of a school shooting in Nashville that left three children dead.

## Woman secretly filmed in changing room by 'creep' photographer blasts his 20 month sentence
 - [https://www.dailymail.co.uk/news/article-11908107/Woman-secretly-filmed-changing-room-creep-photographer-blasts-20-month-sentence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908107/Woman-secretly-filmed-changing-room-creep-photographer-blasts-20-month-sentence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 17:55:24+00:00

Francesca Rowden, 32, of Cambridgeshire, who has waived her right to anonymity, said she 'felt really sick' when it emerged that 'creep' David Glover, 48, had secretly recorded her.

## Gwyneth Paltrow is staying at swanky Park City gated community loved by Taylor Swift during trial
 - [https://www.dailymail.co.uk/news/article-11907009/Gwyneth-Paltrow-staying-swanky-Park-City-gated-community-loved-Taylor-Swift-trial.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907009/Gwyneth-Paltrow-staying-swanky-Park-City-gated-community-loved-Taylor-Swift-trial.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 17:53:59+00:00

Gwyneth Paltrow is staying at The Colony at White Pine Canyon - an exclusive, gated community in Park City, Utah - during the duration of her trial over a 2016 ski collision.

## Police officer accused of string of offences including sexual assaults and sending indecent messages
 - [https://www.dailymail.co.uk/news/article-11907591/Police-officer-accused-string-offences-including-sexual-assaults-sending-indecent-messages.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907591/Police-officer-accused-string-offences-including-sexual-assaults-sending-indecent-messages.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 17:49:40+00:00

Adnan Ali allegedly took advantage of 'inadequate oversight' by commanders to target 'young and vulnerable people'. The Greater Manchester Police constable is accused of 20 offences,

## Rishi Sunak plays for time amid Tory rebellion over Channel migrant laws with PM to consider changes
 - [https://www.dailymail.co.uk/news/article-11908099/Rishi-Sunak-plays-time-amid-Tory-rebellion-Channel-migrant-laws-PM-consider-changes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908099/Rishi-Sunak-plays-time-amid-Tory-rebellion-Channel-migrant-laws-PM-consider-changes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 17:41:52+00:00

The Prime Minister promised to continue speaking with Conservative backbenchers after they made  attempts to amend his Illegal Migration Bill.

## The abandoned $4m Florida lair of Osama bin Laden's brother
 - [https://www.dailymail.co.uk/news/article-11907693/The-abandoned-4m-Florida-lair-Osama-bin-Ladens-brother.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907693/The-abandoned-4m-Florida-lair-Osama-bin-Ladens-brother.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 17:38:42+00:00

Osama Bin Laden's brother Khalil Bin Laden purchased a $1.6 million Florida mansion in 1980 and was at the mansion with his wife Isabel and their son Sultan on September 11, 2001 attack on the World Trade Center

## Home Secretary Suella Braverman vows 'hippy crack' ban will stop 'youths loitering in parks'
 - [https://www.dailymail.co.uk/news/article-11908011/Home-Secretary-Suella-Braverman-vows-hippy-crack-ban-stop-youths-loitering-parks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11908011/Home-Secretary-Suella-Braverman-vows-hippy-crack-ban-stop-youths-loitering-parks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 17:28:38+00:00

The Home Secretary faced down critics of the Government's new anti-social behaviour drive, which would see nitrous oxide become a Class C drug by the end of the year.

## Transgender … or dipping a toe in the water? US trans adults dodge hormones and surgery, study shows
 - [https://www.dailymail.co.uk/news/article-11900091/Transgender-dipping-toe-water-trans-adults-dodge-hormones-surgery-study-shows.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11900091/Transgender-dipping-toe-water-trans-adults-dodge-hormones-surgery-study-shows.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 17:26:00+00:00

A survey of some 500 transgender adults found that three quarters were happier due to transitioning, but that in many cases these changes were only partial, cosmetic or infrequent.

## Energy firms forcibly installed more than 94,000 prepayment meters in customers' homes last year
 - [https://www.dailymail.co.uk/news/article-11907841/Energy-firms-forcibly-installed-94-000-prepayment-meters-customers-homes-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907841/Energy-firms-forcibly-installed-94-000-prepayment-meters-customers-homes-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 17:13:08+00:00

More than 94,000 prepayment meters were last year forcibly installed in homes without customer consent, new figures show - but who were the worst offenders among big gas companies?

## In Trump probe, Manhattan grand jury is back at work
 - [https://www.dailymail.co.uk/news/article-11907661/In-Trump-probe-Manhattan-grand-jury-work.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907661/In-Trump-probe-Manhattan-grand-jury-work.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 17:04:33+00:00

The Manhattan grand jury investigating former President Donald Trump over hush money payments returns on Monday to hear more evidence

## Nashville school shooting LIVE updates: Suspect dead, 'active aggressor' stormed private elementary
 - [https://www.dailymail.co.uk/news/live/article-11907785/Nashville-school-shooting-LIVE-updates-Suspect-dead-active-aggressor-stormed-private-elementary.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/live/article-11907785/Nashville-school-shooting-LIVE-updates-Suspect-dead-active-aggressor-stormed-private-elementary.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 17:02:42+00:00

DAILYMAIL.COM LIVE BLOG: Follow along for updates on police's response to the ongoing shooting at the city's Covenant School, which has a preschool.

## Cubans migrants land motorized hang glider at Florida airport
 - [https://www.dailymail.co.uk/news/article-11907207/Cubans-migrants-land-motorized-hang-glider-Florida-airport.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907207/Cubans-migrants-land-motorized-hang-glider-Florida-airport.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 17:00:26+00:00

Two migrants from Cuba were busted at Key West International Airport in Key West, Florida, on Saturday after they landed onboard a powered hang glider.

## Top Fed official warns banking crisis 'definitely brings us closer' to a recession
 - [https://www.dailymail.co.uk/news/article-11907739/Top-Fed-official-warns-banking-crisis-definitely-brings-closer-recession.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907739/Top-Fed-official-warns-banking-crisis-definitely-brings-closer-recession.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 16:59:51+00:00

Minneapolis Fed President Neel Kashkari said that the recent banking crisis that led to the shuttering of Silicon Valley Bank and Signature 'definitely' edge the U.S. closer to a recession.

## 'AI' fake image of Pope Francis in a puffer coat tricks the internet
 - [https://www.dailymail.co.uk/news/article-11907391/Social-media-stunned-AI-image-Pope-Francis-wearing-stylish-puffer-coat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907391/Social-media-stunned-AI-image-Pope-Francis-wearing-stylish-puffer-coat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 16:56:28+00:00

The photo is said to have been created using an AI-generated AI (artificial intelligence) image generator called Midjourney.

## Babysitter arrested for child abuse for putting marijuana cigarette in one-year-old girl's mouth
 - [https://www.dailymail.co.uk/news/article-11907495/Babysitter-arrested-child-abuse-putting-marijuana-cigarette-one-year-old-girls-mouth.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907495/Babysitter-arrested-child-abuse-putting-marijuana-cigarette-one-year-old-girls-mouth.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 16:53:45+00:00

Naledi Roberts, 17, was arrested by Pinellas County Sheriff's Office on Friday after detectives discovered the footage.

## Pentagon REFUSES to release shot down 'UFO' footage over North America
 - [https://www.dailymail.co.uk/news/article-11907515/Pentagon-REFUSES-release-shot-UFO-footage-North-America.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907515/Pentagon-REFUSES-release-shot-UFO-footage-North-America.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 16:53:13+00:00

Pentagon officials told DailyMail.com they have footage of three unidentified objects shot down by US fighter jets over Alaska last month, but that they could not release it.

## Man jailed for harassment against paedophile drag queen months before found dead in alleyway
 - [https://www.dailymail.co.uk/news/article-11907545/Man-jailed-harassment-against-paedophile-drag-queen-months-dead-alleyway.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907545/Man-jailed-harassment-against-paedophile-drag-queen-months-dead-alleyway.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 16:51:53+00:00

Donovan Clarkson was jailed for harassing Darren Meah-Moore (pictured), including chasing him as h filmed and accused of him of being a paedophile, Newport Crown Court heard

## Woman shoots man dead on Facebook Live after arguing as she screams: 'I don't want to go to jail'
 - [https://www.dailymail.co.uk/news/article-11907577/Woman-shoots-man-dead-Facebook-Live-arguing-screams-dont-want-jail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907577/Woman-shoots-man-dead-Facebook-Live-arguing-screams-dont-want-jail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 16:51:13+00:00

A Mississippi woman is accused of fatally shooting her husband while streaming an argument they were having on Facebook Live Saturday morning.

## Nearly 75 percent say Trump won't be hurt if indicted by hush-money probe: poll
 - [https://www.dailymail.co.uk/news/article-11907363/Nearly-75-percent-say-Trump-wont-hurt-indicted-hush-money-probe-poll.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907363/Nearly-75-percent-say-Trump-wont-hurt-indicted-hush-money-probe-poll.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 16:49:16+00:00

Nearly 75 percent of respondents in a new poll said they believed Donald Trump's 2024 campaign wouldn't be impacted or would be helped if he gets indicted in the Stormy Daniels probe.

## Exact dates you'll receive first cost of living payments revealed
 - [https://www.dailymail.co.uk/money/article-11906653/Millions-Brits-three-301-cost-living-payments-month.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/money/article-11906653/Millions-Brits-three-301-cost-living-payments-month.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 16:48:23+00:00

Millions of Brits will receive the first of three cost-of-living payments from the government next month. The first £301 installment of the £900 cost-of-living payment will be made this spring.

## Killer who lured best friend to secluded spot where he was stabbed 23 times jailed for five years
 - [https://www.dailymail.co.uk/news/article-11907463/Killer-lured-best-friend-secluded-spot-stabbed-23-times-jailed-five-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907463/Killer-lured-best-friend-secluded-spot-stabbed-23-times-jailed-five-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 16:41:00+00:00

Louis Hackett, 20, has been jailed for five years after Newcastle Crown Court heard how he lured pal Kieran Williams, 18, to a secluded spot where he was buried in a clandestine grave.

## Rivals warn Humza Yousaf after he limps home in race to succeed Sturgeon
 - [https://www.dailymail.co.uk/news/article-11907625/Rivals-warn-Humza-Yousaf-limps-home-race-succeed-Sturgeon.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907625/Rivals-warn-Humza-Yousaf-limps-home-race-succeed-Sturgeon.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 16:33:55+00:00

The health minister is set to be installed formally as First Minister tomorrow after limping home in the contest by a margin of 52 per cent to 48 per cent.

## UGA student who suffered horrific brain bleed on Mexico Spring Break has  tumor -but responsive
 - [https://www.dailymail.co.uk/news/article-11907453/UGA-student-suffered-horrific-brain-bleed-Mexico-Spring-Break-tumor-responsive.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907453/UGA-student-suffered-horrific-brain-bleed-Mexico-Spring-Break-tumor-responsive.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 16:33:21+00:00

Liza Burke, 22, was complaining about having headaches while on vacation before being put on life support - and now doctors have found a tumor on her brain stem.

## Californian tourist dies during vacation with his girlfriend in Majorca after jumping off 12m cliff
 - [https://www.dailymail.co.uk/news/article-11906845/Californian-tourist-dies-vacation-girlfriend-Majorca-jumping-12m-cliff.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906845/Californian-tourist-dies-vacation-girlfriend-Majorca-jumping-12m-cliff.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 16:29:35+00:00

The man from California and his girlfriend were visiting the Cala Varques bay located in the east of Majorca, when the accident happened at 1.50pm on Saturday, March 25.

## Shocking moment secondary school teacher appears to 'push pupil out of class and onto floor'
 - [https://www.dailymail.co.uk/news/article-11906695/Shocking-moment-secondary-school-teacher-appears-push-pupil-class-floor.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906695/Shocking-moment-secondary-school-teacher-appears-push-pupil-class-floor.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 16:01:44+00:00

The clip was reportedly recorded inside a classroom in the Greater Manchester area last week, with footage of the alleged incident having been shared widely on social media.

## New Orleans high school students say they have new proof for Pythagoras' theorem using trigonometry
 - [https://www.dailymail.co.uk/news/article-11907481/New-Orleans-high-school-students-say-new-proof-Pythagoras-theorem-using-trigonometry.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907481/New-Orleans-high-school-students-say-new-proof-Pythagoras-theorem-using-trigonometry.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 16:01:31+00:00

Two high school students in New Orleans think they have found a way to prove Pythagoras's Theorem in a way mathematicians previously said was impossible.

## Stripping Shamima Begum of her British citizenship 'is a form of capital punishment'
 - [https://www.dailymail.co.uk/news/article-11907681/Stripping-Shamima-Begum-British-citizenship-form-capital-punishment.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907681/Stripping-Shamima-Begum-British-citizenship-form-capital-punishment.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 16:01:31+00:00

Home Office minister Lord Murray of Blidworth was questioned about the 23-year-old's case in Parliament by Labour peer Lord Griffiths of Burry Port.

## Gwyneth Paltrow arrives alone for fifth day of ski crash trial without kids Apple and Moses
 - [https://www.dailymail.co.uk/news/article-11907409/Gwyneth-Paltrow-arrives-fifth-day-ski-crash-trial-without-kids-Apple-Moses.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907409/Gwyneth-Paltrow-arrives-fifth-day-ski-crash-trial-without-kids-Apple-Moses.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 16:01:07+00:00

Gwyneth Paltrow arrived alone for the fifth day of her ski crash trial without her two children Apple, 18, and Moses, 16, who are expected to take the stand today in Park City, Utah.

## Ukraine: The celebrity supporters who have visited Zelensky
 - [https://www.dailymail.co.uk/news/article-11907257/Ukraine-celebrity-supporters-visited-Zelensky.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907257/Ukraine-celebrity-supporters-visited-Zelensky.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 15:58:54+00:00

Once Kyiv was deemed relatively safe, famous faces have popped up in Kyiv every few weeks to tour regions left devastated by bombs and to shake hands with president Volodymyr Zelensky.

## Mummified heads of 2,000 rams killed in tribute to pharaoh Ramesses II are discovered in Egypt
 - [https://www.dailymail.co.uk/news/article-11907643/Mummified-heads-2-000-rams-killed-tribute-pharaoh-Ramesses-II-discovered-Egypt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907643/Mummified-heads-2-000-rams-killed-tribute-pharaoh-Ramesses-II-discovered-Egypt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 15:58:27+00:00

Archaeologists uncovered the heads in Abydos, Egypt, near the temple of Egyptian pharoah Ramesses II and are said to be more than 2,000 years old.

## Gruesome Stephen Smith crime scene photos show him lying in road next to trail of blood
 - [https://www.dailymail.co.uk/news/article-11907285/Gruesome-Stephen-Smith-crime-scene-photos-lying-road-trail-blood.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907285/Gruesome-Stephen-Smith-crime-scene-photos-lying-road-trail-blood.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 15:58:23+00:00

WARNING GRAPHIC CONTENT: Smith was found lying in the middle of the road on July 8, 2015. Police were immediately suspicious that he had been murdered, but it was ruled a hit-and-run.

## Ultimate DIY guide to checking your breasts for cancer
 - [https://www.dailymail.co.uk/health/article-11906537/Ultimate-DIY-guide-checking-breasts-cancer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-11906537/Ultimate-DIY-guide-checking-breasts-cancer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 15:57:09+00:00

A third of women don't check for breast cancer. Following Kelly Hoppen's breast cancer diagnosis and and Linda Nolan's news that her cancer has spread, we're sharing tips on how to check for cancer

## Former child actor who played Ben in BBC sitcom Outnumbered seen holding packets of 'drugs' in Asia
 - [https://www.dailymail.co.uk/news/article-11907457/Former-child-actor-played-Ben-BBC-sitcom-Outnumbered-seen-holding-packets-drugs-Asia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907457/Former-child-actor-played-Ben-BBC-sitcom-Outnumbered-seen-holding-packets-drugs-Asia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 15:57:08+00:00

Daniel Roche, 23, posted a series of photos on Instagram documenting his travels around southeast Asia with friends. The final picture he shared showed him holding five sealed bags.

## Two-thirds of workers would prefer working a four-day week, a survey of 12,000 people has found.
 - [https://www.dailymail.co.uk/news/article-11907593/Two-thirds-workers-prefer-working-four-day-week-survey-12-000-people-found.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907593/Two-thirds-workers-prefer-working-four-day-week-survey-12-000-people-found.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 15:55:32+00:00

Almost two-thirds of workers would prefer working a four-day week, a recent poll has found. A survey of 12,000 people  found that nearly two in three workers would favour the switch.

## Multiple injured at private Nashville Christian school
 - [https://www.dailymail.co.uk/news/article-11907711/Multiple-injured-private-Nashville-Christian-school.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907711/Multiple-injured-private-Nashville-Christian-school.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 15:51:43+00:00

Multiple people have been injured at a private Christian school in Nashville, Tennessee.

## Transgender woman, 54, is jailed for nine years for stabbing another trans woman
 - [https://www.dailymail.co.uk/news/article-11907547/Transgender-woman-54-jailed-nine-years-stabbing-trans-woman.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907547/Transgender-woman-54-jailed-nine-years-stabbing-trans-woman.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 15:50:36+00:00

Zara Jade, 54, from Halifax, West Yorkshire, slashed her victim in the arm and abdomen while she sat on her knee.

## Pictured: Single mother, who fell victim to thief who stole phone selling to pay daughter's funeral
 - [https://www.dailymail.co.uk/news/article-11907175/Pictured-Single-mother-fell-victim-thief-stole-phone-selling-pay-daughters-funeral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907175/Pictured-Single-mother-fell-victim-thief-stole-phone-selling-pay-daughters-funeral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 15:50:34+00:00

EXCLUSIVE: Loretta Bacchus, from Cheltenham, Gloucestershire, said she was left shaken by the ordeal - as she had told the thief about her baby while they talked

## 'Creep' photographer who set up hidden cameras to film 35 models is jailed for 20 months
 - [https://www.dailymail.co.uk/news/article-11907489/Creep-photographer-set-hidden-cameras-film-35-models-jailed-20-months.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907489/Creep-photographer-set-hidden-cameras-film-35-models-jailed-20-months.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 15:47:36+00:00

An 'absolute creep' who set up hidden cameras in changing rooms to film dozens of aspiring young models who came for portfolio shoots has been jailed for 20 months in Peterborough.

## TSA warns travelers that they can't take a full-size jar of peanut butter on an airplane
 - [https://www.dailymail.co.uk/news/article-11907375/TSA-warns-travelers-size-jar-peanut-butter-airplane.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907375/TSA-warns-travelers-size-jar-peanut-butter-airplane.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 15:02:52+00:00

For years, the the agency tasked with vetting Americans for air travel has maintained the savory snack is a liquid - due to it having 'no definite shape' and taking a form 'dictated by its container.'

## Army pulls its new ad campaign featuring Marvel star Jonathan Majors after his arrest for assault
 - [https://www.dailymail.co.uk/news/article-11907159/Army-pulls-new-ad-campaign-featuring-Marvel-star-Jonathan-Majors-arrest-assault.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907159/Army-pulls-new-ad-campaign-featuring-Marvel-star-Jonathan-Majors-arrest-assault.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 15:01:48+00:00

Jonathan Majors was featured in a pair of dramatic new United States Army ads. The US Army pulled the ads, but noted Majors was innocent until proven guilty.

## Medals awarded to British soldier who was part of 1879 Anglo-Zulu war go on sale for £20,000
 - [https://www.dailymail.co.uk/news/article-11907219/Medals-awarded-British-soldier-1879-Anglo-Zulu-war-sale-20-000.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907219/Medals-awarded-British-soldier-1879-Anglo-Zulu-war-sale-20-000.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 15:01:25+00:00

The medals of Alfred Saxty (far left), who was just 22 at the time of the famous battle on January 22 1879, are expected to fetch up to £20,000.

## Thar she goes! Russian floating restaurant named Silver Whale SINKS in St Petersburg
 - [https://www.dailymail.co.uk/news/article-11907465/Thar-goes-Russian-floating-restaurant-named-Silver-Whale-SINKS-St-Petersburg.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907465/Thar-goes-Russian-floating-restaurant-named-Silver-Whale-SINKS-St-Petersburg.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 14:59:39+00:00

The 'Silver Whale' restaurant, moored on the Neva River, St Petersburg, was pictured on its side today. It was 'flooded' at about 7.30am because of damage caused by the river's icy conditions.

## Olivia Pratt-Korbel murder accused Thomas Cashman, 34, is 'trying to pull the wool over your eyes'
 - [https://www.dailymail.co.uk/news/article-11907213/Olivia-Pratt-Korbel-murder-accused-Thomas-Cashman-34-trying-pull-wool-eyes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907213/Olivia-Pratt-Korbel-murder-accused-Thomas-Cashman-34-trying-pull-wool-eyes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 14:56:23+00:00

The man on trial for killing nine-year-old Olivia Pratt-Korbel was accused today on Manchester of trying to 'pull the wool' over jurors' eyes.

## Family doctor, 46, denies sex attacks on four of his female patients at GP surgery
 - [https://www.dailymail.co.uk/news/article-11907261/Family-doctor-46-denies-sex-attacks-four-female-patients-GP-surgery.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907261/Family-doctor-46-denies-sex-attacks-four-female-patients-GP-surgery.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 14:36:56+00:00

Mohan Babu, 46, has been accused of non-penetrative sex attacks on four women who were receiving medical treatment at the Staunton Surgery in Havant, Hampshire.

## Triplets set two world records for most premature and lightest birth weight at a combined 2.83lbs
 - [https://www.dailymail.co.uk/news/article-11907249/Triplets-set-two-world-records-premature-lightest-birth-weight-combined-2-83lbs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907249/Triplets-set-two-world-records-premature-lightest-birth-weight-combined-2-83lbs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 14:31:23+00:00

Rubi-Rose, Payton Jane and Porscha-Mae Hopkins (pictured) were born at 22 weeks and five days with a combined weight of 2.83lb on February 14, 2021. They have just celebrated their second birthday.

## Father who killed his 12-year-old son in crash while speeding weeps as he avoids jail
 - [https://www.dailymail.co.uk/news/article-11907427/Father-killed-12-year-old-son-crash-speeding-weeps-avoids-jail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907427/Father-killed-12-year-old-son-crash-speeding-weeps-avoids-jail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 14:29:58+00:00

Paul Vines, 47, was said to have been speeding on an B-road and had failed to observe signs warning of the uneven surface before the crash that lead to the death of his son Ted (pictured).

## Indooroopilly State High School grooming charges: Teacher Chelsea Edwards spotted at Gold Coast
 - [https://www.dailymail.co.uk/news/article-11905657/Indooroopilly-State-High-School-grooming-charges-Teacher-Chelsea-Edwards-spotted-Gold-Coast.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905657/Indooroopilly-State-High-School-grooming-charges-Teacher-Chelsea-Edwards-spotted-Gold-Coast.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 14:14:27+00:00

Alleged school sex scandal teacher Chelsea Jane Edwards put child grooming charges behind her and joined her family for an emotion-charged day on the beach.

## Mississippi restaurant workers survived fierce twister that killed 26 by hiding in walk-in fridge
 - [https://www.dailymail.co.uk/news/article-11906961/Mississippi-restaurant-workers-survived-fierce-twister-killed-26-hiding-walk-fridge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906961/Mississippi-restaurant-workers-survived-fierce-twister-killed-26-hiding-walk-fridge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 14:13:41+00:00

Tracy Harden, 48, owner of Chuck's Dairy Bar in Rolling Fork, Mississippi, rushed her employees into a walk-in-cooler at the diner Friday night, saving their lives, as a tornado ripped through the area.

## Former Government drug tsar slams ban on hippy crack because it 'isn't based on evidence'
 - [https://www.dailymail.co.uk/health/article-11906629/Former-Government-drug-tsar-claims-slams-ban-hippy-crack-isnt-based-evidence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-11906629/Former-Government-drug-tsar-claims-slams-ban-hippy-crack-isnt-based-evidence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 14:12:39+00:00

The move forms one part of Rishi Sunak's ambitious plan to tackle the blight of anti-social behaviour. The action could see anyone caught facing 'potential prison sentences' and 'unlimited fines'.

## Breeder whose 'escaped' dogs mauled a four-year-old girl has 14 animals in the property, locals say
 - [https://www.dailymail.co.uk/news/article-11907031/Breeder-escaped-dogs-mauled-four-year-old-girl-14-animals-property-locals-say.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907031/Breeder-escaped-dogs-mauled-four-year-old-girl-14-animals-property-locals-say.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 14:09:08+00:00

The owner of the American Bully-style animals which savaged a little girl kept 14 dogs in his house. Neighbours claim the dogs escaped from a home and attacked her as she played in a front garden.

## Missing Indiana teen Scottie Morris, 14, found safe with his MOM before police arrived
 - [https://www.dailymail.co.uk/news/article-11907035/Missing-Indiana-teen-Scottie-Morris-14-safe-MOM-police-arrived.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907035/Missing-Indiana-teen-Scottie-Morris-14-safe-MOM-police-arrived.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 14:08:40+00:00

Scottie Morris, 14, disappeared from his home in Eaton, Indiana, at 8.30pm on March 16 - with police scanners appearing to imply that he  had  'run away'.

## Indigenous Voice to Parliament: Q&A descends into shouting match as Senators argue
 - [https://www.dailymail.co.uk/news/article-11906925/Indigenous-Voice-Parliament-Q-descends-shouting-match-Senators-argue.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906925/Indigenous-Voice-Parliament-Q-descends-shouting-match-Senators-argue.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 14:06:18+00:00

On the panel were Country Liberal Senator Jacinta Yangapi Nampijinpa Price and Labor Senator Malarndirri McCarthy who together hold the Northern Territory's only two Senate seats.

## Russian pupils faint as they are made to sit at desks decorated with faces of killed soldiers
 - [https://www.dailymail.co.uk/news/article-11907215/Russian-pupils-faint-sit-desks-decorated-faces-killed-soldiers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907215/Russian-pupils-faint-sit-desks-decorated-faces-killed-soldiers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 14:02:55+00:00

Others students refused to sit at the 'macabre' desks at the school in Irkutsk, Russia, which display pictures of dead national guardsmen.

## Gwyneth Paltrow trial LIVE: Retired doctor suing actress over 'reckless' ski crash is set to testify
 - [https://www.dailymail.co.uk/news/live/article-11907127/Gwyneth-Paltrow-trial-LIVE-updates-day-five.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/live/article-11907127/Gwyneth-Paltrow-trial-LIVE-updates-day-five.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 13:58:30+00:00

DailyMail.com reporters will bring you all the latest from actress Gwyneth Paltrow's trial over a 2016 ski collision that allegedly left a retired optometrist with a brain injury.

## Up to 50 million Britons are planning to celebrate the King's Coronation in the pub
 - [https://www.dailymail.co.uk/news/article-11906875/Up-50-million-Britons-planning-celebrate-Kings-Coronation-pub.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906875/Up-50-million-Britons-planning-celebrate-Kings-Coronation-pub.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 13:47:18+00:00

Experts believe up to three quarters of the entire population will sink a record 36 million pints during the extended weekend.

## Kia Soul is launched 10 feet into the air after a loose wheel plows into it on LA freeway
 - [https://www.dailymail.co.uk/news/article-11906949/Kia-Soul-launched-10-feet-air-loose-wheel-plows-LA-freeway.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906949/Kia-Soul-launched-10-feet-air-loose-wheel-plows-LA-freeway.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 13:42:49+00:00

A wheel came loose from a widened pickup truck driving along an LA highway, launching a Kia Soul 10 foot into the air.

## Teenager, 14, caught towing a caravan on the M4 with three friends is ordered to pay £20
 - [https://www.dailymail.co.uk/news/article-11907051/Teenager-14-caught-towing-caravan-M4-three-friends-ordered-pay-20.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907051/Teenager-14-caught-towing-caravan-M4-three-friends-ordered-pay-20.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 13:42:11+00:00

The schoolboy, 14, was driving the Saab with three friends in the passenger seats when police spotted them on the M4 in Wiltshire. He was arrested and later admitted a raft of driving offences.

## How Matt Kean is being accused of ruining the NSW Liberal Party with his left-leaning policies
 - [https://www.dailymail.co.uk/news/article-11905053/How-Matt-Kean-accused-ruining-NSW-Liberal-Party-left-leaning-policies.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905053/How-Matt-Kean-accused-ruining-NSW-Liberal-Party-left-leaning-policies.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 13:38:49+00:00

Matt Kean pulled out of a race to lead the NSW Liberal Party following a Labor win. A Liberal Party insider said the renewable energy focus had cost it seats in western Sydney and in retiree electorates.

## Victory for 'continuity candidate' Humza Yousaf in SNP battle
 - [https://www.dailymail.co.uk/news/article-11906915/Victory-continuity-candidate-Humza-Yousaf-SNP-battle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906915/Victory-continuity-candidate-Humza-Yousaf-SNP-battle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 13:31:08+00:00

Humza Yousaf, seen as the 'continuity' candidate, emerged victorious and is now set to take over from Nicola Sturgeon as First Minister tomorrow.

## DeSantis leads Trump in Iowa by eight points in head-to-head matchup
 - [https://www.dailymail.co.uk/news/article-11907049/DeSantis-leads-Trump-Iowa-eight-points-head-head-matchup.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907049/DeSantis-leads-Trump-Iowa-eight-points-head-head-matchup.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 13:30:19+00:00

Ron DaSantis' has built up a an 45 to 37 lead over Donald Trump in battleground Iowa, following a week that featured some of their most direct attacks on each another.

## Trump warns of nuclear escalation after Russia announces it will move tactical missiles into Belarus
 - [https://www.dailymail.co.uk/news/article-11907083/Trump-warns-nuclear-escalation-Russia-announces-tactical-missiles-Belarus.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11907083/Trump-warns-nuclear-escalation-Russia-announces-tactical-missiles-Belarus.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 13:28:52+00:00

Donald Trump warned of nuclear escalation with Russia due to 'incompetent people' in the U.S. government on Monday morning.

## Rishi Sunak berated over 'noisy nuisance' Airbnb lets in leafy neighborhoods
 - [https://www.dailymail.co.uk/news/article-11906959/Rishi-Sunak-berated-noisy-nuisance-Airbnb-lets-leafy-neighborhoods.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906959/Rishi-Sunak-berated-noisy-nuisance-Airbnb-lets-leafy-neighborhoods.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 13:22:03+00:00

The Prime Minister was cornered during a question and answer session in Chelmsford this morning as he launched a £160million package of proposed reforms.

## Man arrested for 'stupid and dangerous' 10-minute laser attack on a police helicopter
 - [https://www.dailymail.co.uk/news/article-11906799/Man-arrested-stupid-dangerous-10-minute-laser-attack-police-helicopter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906799/Man-arrested-stupid-dangerous-10-minute-laser-attack-police-helicopter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 13:06:41+00:00

The South West National Police Air Service have confirmed a man has been arrested after shining a light at its aircraft for a period of ten minutes on Sunday 26 March in Exeter.

## Oklahoma State Rep. Dean Davis is arrested for public drunkenness
 - [https://www.dailymail.co.uk/news/article-11906887/Oklahoma-State-Rep-Dean-Davis-arrested-public-drunkenness.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906887/Oklahoma-State-Rep-Dean-Davis-arrested-public-drunkenness.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 12:44:47+00:00

Rep. Dean Davis, 50, had been drinking with friends at the bar in Broken Arrow, Oklahoma, when police officers arrived. The police say he and his friends were refusing to leave the bar, which had closed.

## South Carolina hunting lodge where Alex Murdaugh murdered wife Maggie and son Paul sells for $2.6m
 - [https://www.dailymail.co.uk/news/article-11906793/South-Carolina-hunting-lodge-Alex-Murdaugh-murdered-wife-Maggie-son-Paul-sells-2-6m.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906793/South-Carolina-hunting-lodge-Alex-Murdaugh-murdered-wife-Maggie-son-Paul-sells-2-6m.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 12:43:03+00:00

The property, Moselle, in South Carolina, was the scene of the gristly double murder of Maggie and Paul Murdaugh by disgraced legal scion Alex in June 2021 .

## McCarthy says House 'will be moving forward' with TikTok restriction
 - [https://www.dailymail.co.uk/news/article-11906847/McCarthy-says-House-moving-forward-TikTok-restriction.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906847/McCarthy-says-House-moving-forward-TikTok-restriction.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 12:36:08+00:00

'It's very concerning that the CEO of TikTok can't be honest and admit what we already know to be true-China has access to TikTok user data,' the California Republican tweeted Sunday.

## Dramatic moment house explodes in gas blast [Video]
 - [https://www.dailymail.co.uk/news/article-11906667/Dramatic-moment-house-explodes-gas-blast-Video.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906667/Dramatic-moment-house-explodes-gas-blast-Video.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 12:35:24+00:00

The fire broke out on Wednesday in Winsford, Cheshire. Dramatic footage shows the explosion erupting through the roof of the house and subsequent flames engulfing the property.

## Which Barclays bank branches are closing in the UK?
 - [https://www.dailymail.co.uk/money/article-11906119/Barclays-shut-14-branches-55-closures-announced.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/money/article-11906119/Barclays-shut-14-branches-55-closures-announced.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 12:30:33+00:00

Barclays has revealed plans to shut 14 more branches across England and Wales in June. These closures will be in addition to the 55 branches already planned to shut this year.

## Putin 'negotiated guarantees for his safety with President Xi in case he loses power'
 - [https://www.dailymail.co.uk/news/article-11906775/Putin-negotiated-guarantees-safety-President-Xi-case-loses-power.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906775/Putin-negotiated-guarantees-safety-President-Xi-case-loses-power.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 12:26:28+00:00

Xi visited Moscow and met his despotic Russian counterpart last week, where the pair professed friendship and pledged closer ties, as Putin's forces continue to struggle in Ukraine.

## Mr Kipling Angel Slices and Birds Eye Potato Waffles soar in price
 - [https://www.dailymail.co.uk/news/article-11906389/Mr-Kipling-Angel-Slices-Birds-Eye-Potato-Waffles-soar-price.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906389/Mr-Kipling-Angel-Slices-Birds-Eye-Potato-Waffles-soar-price.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 12:22:50+00:00

The Grocer said its weekly mystery shopping survey had found an eight-pack of the Mr Kipling Angel Slices had gone up 62 per cent year-on-year to an average of £2.73.

## Student used 44 different numbers to contact Muslim woman, had a kilo of pork delivered
 - [https://www.dailymail.co.uk/news/article-11906581/Student-used-44-different-numbers-contact-Muslim-woman-kilo-pork-delivered.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906581/Student-used-44-different-numbers-contact-Muslim-woman-kilo-pork-delivered.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 12:15:49+00:00

Kaichen Ma, 21, became obsessed with his Durham University student victim, leaving her afraid to leave the house and being physically sick

## Russian politician who spoke out against Ukraine war POISONED, she reveals
 - [https://www.dailymail.co.uk/news/article-11906689/Russian-politician-spoke-against-Ukraine-war-POISONED-reveals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906689/Russian-politician-spoke-against-Ukraine-war-POISONED-reveals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 12:13:28+00:00

Elvira Vikhareva, 32, an outspoken critic of the Kremlin, shared  tests with Russia's Sota news channel that showed she had traces of potassium dichromate in her blood.

## Sir Bradley Wiggins says he suffered 'borderline rape, sexual abuse' over three years from 12
 - [https://www.dailymail.co.uk/news/article-11906371/Sir-Bradley-Wiggins-says-suffered-borderline-rape-sexual-abuse-three-years-12.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906371/Sir-Bradley-Wiggins-says-suffered-borderline-rape-sexual-abuse-three-years-12.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 11:57:40+00:00

Olympic cycling and Tour de France winner Sir Bradley Wiggins revealed today he had suffered 'borderline rape and sexual abuse' from the age of 12 by a coach.

## Prince Harry arrives at High Court for hearing against Associated Newspapers over 'hacking claims'
 - [https://www.dailymail.co.uk/news/article-11906335/Prince-Harry-arrives-High-Court-hearing-against-Associated-Newspapers-hacking-claims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906335/Prince-Harry-arrives-High-Court-hearing-against-Associated-Newspapers-hacking-claims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 11:32:50+00:00

Publisher Associated Newspapers categorically denies the claims which were lodged by a group including the duke, Sir Elton John and Baroness Doreen Lawrence.

## Mother of boy who was mauled to death by dog taking fight for tighter breeding laws to Parliament
 - [https://www.dailymail.co.uk/news/article-11906587/Mother-boy-mauled-death-dog-taking-fight-tighter-breeding-laws-Parliament.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906587/Mother-boy-mauled-death-dog-taking-fight-tighter-breeding-laws-Parliament.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 11:31:18+00:00

The heartbroken mother of Jack Lis, 10, who was mauled to death by a XL Bully dog in South Wales on November 8, 2022. Emma Whitfield is set to lobby MPs at Westminster for tighter breeding laws.

## 'Mad' new recycling plans could force every UK household to have SEVEN different bins
 - [https://www.dailymail.co.uk/news/article-11906599/Mad-new-recycling-plans-force-UK-household-SEVEN-different-bins.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906599/Mad-new-recycling-plans-force-UK-household-SEVEN-different-bins.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 11:31:09+00:00

New waste plans that could see UK households have as many as seven bins have been blasted as 'madness' by MP's with councils warning it could cost millions of pounds.

## Luxury 425ft 'Thunder Bird' hydrofoil vessel with full glass decks is unveiled in concept design
 - [https://www.dailymail.co.uk/news/article-11906433/Luxury-425ft-Thunder-Bird-hydrofoil-vessel-glass-decks-unveiled-concept-design.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906433/Luxury-425ft-Thunder-Bird-hydrofoil-vessel-glass-decks-unveiled-concept-design.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 11:30:23+00:00

Turkish yacht designer Aras Kazar, has called his creation Wakinyan, a Native American Lakota people word for thunder.

## Sydney Taxi driver refuses to let passenger out as the car drives through CBD with both doors open
 - [https://www.dailymail.co.uk/news/article-11906271/Sydney-Taxi-driver-refuses-let-passenger-car-drives-CBD-doors-open.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906271/Sydney-Taxi-driver-refuses-let-passenger-car-drives-CBD-doors-open.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 11:15:38+00:00

The male passenger had gotten a lift through the Sydney CBD on Sunday but when they wanted to get out at Oxford Street the argument broke out over how the fare would be paid.

## Liberal MP Moira Deeming survives motion to expel after attending Let Women Speak rally
 - [https://www.dailymail.co.uk/news/article-11906679/Liberal-MP-Moira-Deeming-survives-motion-expel-attending-Let-Women-Speak-rally.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906679/Liberal-MP-Moira-Deeming-survives-motion-expel-attending-Let-Women-Speak-rally.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 11:13:33+00:00

Ms Deeming has been removed from the party room for nine months after appearing at a Let Women Speak rally that was also attended by neo-Nazis but was not voted out.

## Now trans activists burn Harry Potter books: JK Rowling ridicules Australian campaigner over video
 - [https://www.dailymail.co.uk/news/article-11906395/Now-trans-activists-burn-Harry-Potter-books-JK-Rowling-ridicules-Australian-campaigner-video.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906395/Now-trans-activists-burn-Harry-Potter-books-JK-Rowling-ridicules-Australian-campaigner-video.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 11:07:17+00:00

JK Rowling has ridiculed a trans rights activist who posted video of a Harry Potter book being burned, mocking the firestarter's copyright mark as 'Just in case people try and submit to the Academy Awards'.

## Moment hapless thieves who tried to steal a cash machine flee after part of their van breaks off
 - [https://www.dailymail.co.uk/news/article-11906615/Moment-hapless-thieves-tried-steal-cash-machine-flee-van-breaks-off.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906615/Moment-hapless-thieves-tried-steal-cash-machine-flee-van-breaks-off.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 11:05:56+00:00

A strap was tied around the cash machine inside the shop in and attached to the chassis bar of the van, but when the group tried to drive off they broke part of the vehicle and fled empty-handed.

## Gay asylum seeker in Newquay hotel says coming to UK was his 'worst decision'
 - [https://www.dailymail.co.uk/news/article-11906511/Gay-asylum-seeker-Newquay-hotel-says-coming-UK-worst-decision.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906511/Gay-asylum-seeker-Newquay-hotel-says-coming-UK-worst-decision.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 10:52:59+00:00

'Chris' was transferred to Newquay, Cornwall in November and is staying in a hotel while waiting for his claim to be processed.

## Dutch musician faces court bid to halt his 'obsessive' sperm donation
 - [https://www.dailymail.co.uk/news/article-11906249/Dutch-musician-faces-court-bid-halt-obsessive-sperm-donation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906249/Dutch-musician-faces-court-bid-halt-obsessive-sperm-donation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 10:35:49+00:00

Jonathan Jacob Meijer, 41, has misled hundreds of women all over the world and may have fathered nearly 550 children, claimed the Donorkind foundation, who is suing Mr Meijer.

## Angel Lynn: CH4 to air story of woman who fell from moving van while escaping kidnapper boyfriend
 - [https://www.dailymail.co.uk/news/article-11906227/Angel-Lynn-CH4-air-story-woman-fell-moving-van-escaping-kidnapper-boyfriend.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906227/Angel-Lynn-CH4-air-story-woman-fell-moving-van-escaping-kidnapper-boyfriend.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 10:32:12+00:00

Angel Lynn (pictured), 21, was left paralysed and unable to eat, walk or talk by herself following the 2020 ordeal on the A6 in Leicestershire at the hands of Chay Bowskill.

## Anthony Horowitz slams Roald Dahl publishers for censoring literary icon's works
 - [https://www.dailymail.co.uk/news/article-11906375/Anthony-Horowitz-slams-Roald-Dahl-publishers-censoring-literary-icons-works.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906375/Anthony-Horowitz-slams-Roald-Dahl-publishers-censoring-literary-icons-works.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 10:31:48+00:00

Horowitz, who penned the Alex Rider series aimed at under-15s, said he was against publishers making changes amid an ongoing row over reader sensitivity blighting Britain's literary industry.

## Cost of building HS2 railway station at London Euston soars to £4.8billion
 - [https://www.dailymail.co.uk/news/article-11906121/Cost-building-HS2-railway-station-London-Euston-soars-4-8billion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906121/Cost-building-HS2-railway-station-London-Euston-soars-4-8billion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 10:27:46+00:00

Construction of the 10-platform London terminus was budgeted by HS2 Ltd at £2.6billion as recently as April 2020, but this has now soared by £2.2billion to £4.8billion, the National Audit Office said today.

## Rishi Sunak and Suella Braverman heckled during walkabout in Chelmsford
 - [https://www.dailymail.co.uk/news/article-11906439/Rishi-Sunak-Suella-Braverman-heckled-walkabout-Chelmsford.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906439/Rishi-Sunak-Suella-Braverman-heckled-walkabout-Chelmsford.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 10:27:00+00:00

Rishi Sunak and Suella Braverman were berated by a lone protester as they took a brief stroll through the streets of Chelmsford this morning before formally launching an anti-social behaviour drive.

## Police seize 2,800 suspected illegal vapes across Bolton after 'medical incidents' at a school
 - [https://www.dailymail.co.uk/news/article-11906409/Police-seize-2-800-suspected-illegal-vapes-Bolton-medical-incidents-school.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906409/Police-seize-2-800-suspected-illegal-vapes-Bolton-medical-incidents-school.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 10:25:32+00:00

Greater Manchester Police took possession of 2800 vapes which may produce a 'highly toxic gas' during a day of action with Trading Standards workers.

## Mother murdered two daughters, sedating and shooting them to get revenge on ex-husband
 - [https://www.dailymail.co.uk/news/article-11906601/Mother-murdered-two-daughters-sedating-shooting-revenge-ex-husband.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906601/Mother-murdered-two-daughters-sedating-shooting-revenge-ex-husband.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 10:22:41+00:00

Veronica Youngblood (pictured) called her ex-husband Ron Youngblood to tell him that she hated him and that she had shot the children as her sedated 15-year-old lay dying in their McLean apartment.

## Australian SAS soldier accused of war crimes in Afghanistan asks for bail
 - [https://www.dailymail.co.uk/news/article-11906527/Australian-SAS-soldier-accused-war-crimes-Afghanistan-asks-bail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906527/Australian-SAS-soldier-accused-war-crimes-Afghanistan-asks-bail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 10:22:32+00:00

The man, who cannot be named for legal reasons, was arrested by the Australian Federal Police last Monday and has spent a week behind bars.

## Shocking moment car ploughs through a crowd of people in chaotic scenes outside bowling alley
 - [https://www.dailymail.co.uk/news/article-11905127/Shocking-moment-car-ploughs-crowd-people-chaotic-scenes-outside-bowling-alley.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905127/Shocking-moment-car-ploughs-crowd-people-chaotic-scenes-outside-bowling-alley.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 10:18:30+00:00

Police are looking for a driver after a car collided with a group of pedestrians during a mass brawl outside Tenpin alley in Acton, West London, shortly after midnight yesterday.

## Migrant rescue ship funded by Banksy is impounded in Italy after responding to Med distress calls
 - [https://www.dailymail.co.uk/news/article-11906385/Migrant-rescue-ship-funded-Banksy-impounded-Italy-responding-Med-distress-calls.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906385/Migrant-rescue-ship-funded-Banksy-impounded-Italy-responding-Med-distress-calls.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 10:12:09+00:00

The coast guard said it had ordered the MV Louise Michel ship to dock in Trapani in Sicily after it performed an initial rescue operation in Libya's Search And Rescue area.

## Cocaine dealer posted 'last supper' selfie - minutes before she was locked up over drugs racket
 - [https://www.dailymail.co.uk/news/article-11906281/Cocaine-dealer-posted-supper-selfie-minutes-locked-drugs-racket.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906281/Cocaine-dealer-posted-supper-selfie-minutes-locked-drugs-racket.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 10:06:17+00:00

Jaymie Dawson brazenly posted a photo of herself smiling by Manchester Crown Court before she and members of her gang awaited sentencing following a a multi-million pound drugs racket.

## Labour gloats that SNP meltdown will make it 'easier' for Keir Starmer to win next election
 - [https://www.dailymail.co.uk/news/article-11906465/Labour-gloats-SNP-meltdown-make-easier-Keir-Starmer-win-election.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906465/Labour-gloats-SNP-meltdown-make-easier-Keir-Starmer-win-election.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 09:43:10+00:00

The party's Scottish leader, Anas Sarwar, claimed none of the three candidates to replace Ms Sturgeon was of the same 'calibre' as the departing First Minister.

## Alison Hammond breaks her silence after suspect was bailed following blackmail arrest
 - [https://www.dailymail.co.uk/tvshowbiz/article-11906421/Alison-Hammond-breaks-silence-suspect-bailed-following-blackmail-arrest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-11906421/Alison-Hammond-breaks-silence-suspect-bailed-following-blackmail-arrest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 09:37:06+00:00

Taking to Instagram, the presenter, 48, shared a beaming selfie from her 'girls night' with pals Holly Willoughby, Nicole Appleton and Emma Bunton, writing the caption: 'Needed that.'

## How abdicated Edward VIII helped the Nazis bomb Buckingham Palace at the height of the Blitz
 - [https://www.dailymail.co.uk/news/article-11906055/How-abdicated-Edward-VIII-helped-Nazis-bomb-Buckingham-Palace-height-Blitz.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906055/How-abdicated-Edward-VIII-helped-Nazis-bomb-Buckingham-Palace-height-Blitz.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 09:32:53+00:00

Classified documents from The Royal Archives may reveal the truth of claims that the Duke of Windsor was a Nazi sympathiser who gave up plans of Buckingham Palace allowing it to be bombed.

## Rival London sex therapists in £2m court war over claims ex-pal stole clients
 - [https://www.dailymail.co.uk/news/article-11906117/Rival-London-sex-therapists-2m-court-war-claims-ex-pal-stole-clients.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906117/Rival-London-sex-therapists-2m-court-war-claims-ex-pal-stole-clients.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 09:32:52+00:00

Siobhain Crosbie (left) claims former pal and protege Caroline Ley (right) stole her clients after the two women fell out in 2011. The pair both work as sex therapists in London.

## Keir Starmer moves to officially BLOCK Jeremy Corbyn from standing as Labour MP
 - [https://www.dailymail.co.uk/news/article-11906449/Keir-Starmer-moves-officially-BLOCK-Jeremy-Corbyn-standing-Labour-MP.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906449/Keir-Starmer-moves-officially-BLOCK-Jeremy-Corbyn-standing-Labour-MP.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 09:32:39+00:00

Sir Keir Starmer will expected to demand the move at a meeting of Labour's National Executive Committee (NEC), at least a year before a general election is expected.

## The BBC's University Challenge is accused of treating non-Oxbridge institutions as 'second class'
 - [https://www.dailymail.co.uk/news/article-11906015/The-BBCs-University-Challenge-accused-treating-non-Oxbridge-institutions-second-class.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906015/The-BBCs-University-Challenge-accused-treating-non-Oxbridge-institutions-second-class.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 09:31:59+00:00

The rules of University Challenge allow separate colleges from Oxford and Cambridge to enter while limiting all other universities to one team each.

## NHS will be short of 570,000 nurses, doctors and dentists within 15 years
 - [https://www.dailymail.co.uk/health/article-11906021/NHS-short-570-000-nurses-doctors-dentists-15-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-11906021/NHS-short-570-000-nurses-doctors-dentists-15-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 09:29:45+00:00

The NHS in England needs to boost its workforce by a third, drastically increasing the number of doctors and nurses trained  by 2036 a leaked document has revealed.

## Trinny Woodall hints she has split with partner Charles Saatchi by revealing she has 'moved house'
 - [https://www.dailymail.co.uk/news/article-11906221/Trinny-Woodall-hints-split-partner-Charles-Saatchi-revealing-moved-house.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906221/Trinny-Woodall-hints-split-partner-Charles-Saatchi-revealing-moved-house.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 09:27:34+00:00

Trinny, 49, has been dating Saatchi, 79, for 10 years - since he split from wife Nigella Lawson - but the make-up and beauty mogul said on Instagram on Friday that she has 'moved house.'

## Dolly Parton's 2017 duet with Miley Cyrus 'Rainbowland' is banned from first-grade concert
 - [https://www.dailymail.co.uk/news/article-11906155/Dolly-Partons-2017-duet-Miley-Cyrus-Rainbowland-banned-grade-concert.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906155/Dolly-Partons-2017-duet-Miley-Cyrus-Rainbowland-banned-grade-concert.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 09:26:05+00:00

On the setlist were Louis Armstrong's What a Wonderful World, Rainbow Connection by Kermit the Frog from The Muppet Movie and Dolly Parton's duet with Miley Cyrus Rainbowland.

## Hundreds of sex crime trials collapse as alleged victims withdraw complaints amid court backlogs
 - [https://www.dailymail.co.uk/news/article-11906083/Hundreds-sex-crime-trials-collapse-alleged-victims-withdraw-complaints-amid-court-backlogs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906083/Hundreds-sex-crime-trials-collapse-alleged-victims-withdraw-complaints-amid-court-backlogs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 09:26:01+00:00

Data shows more than 1,600 sex crime cases have collapsed in England and Wales over the last five years after allege victims have withdrawn their complaints.

## Britain will bask in 15C temperatures by the end of this week but heavy rain will arrive tomorrow
 - [https://www.dailymail.co.uk/news/article-11906149/Britain-bask-15C-temperatures-end-week-heavy-rain-arrive-tomorrow.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906149/Britain-bask-15C-temperatures-end-week-heavy-rain-arrive-tomorrow.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 09:25:51+00:00

Nearly every county in the UK is forecast to experience temperatures above 10C in the coming days, but wet weather is also on the way.

## Rishi Sunak's £160million war on louts: Bigger fines for graffiti and 'nuisance' beggar restrictions
 - [https://www.dailymail.co.uk/news/article-11906203/Rishi-Sunaks-160million-war-louts-Bigger-fines-graffiti-nuisance-beggar-restrictions.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906203/Rishi-Sunaks-160million-war-louts-Bigger-fines-graffiti-nuisance-beggar-restrictions.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 09:24:06+00:00

As he seeks to wrestle back the Tories shrinking reputation as the party of law and order the Prime Minister vowed stronger powers for the police and punitive action against local hooligans.

## Jonathan Hallinan dead: BPM Corp property mogul dies from cancer after apprentice tradie job
 - [https://www.dailymail.co.uk/news/article-11905631/Jonathan-Hallinan-dead-BPM-Corp-property-mogul-dies-cancer-apprentice-tradie-job.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905631/Jonathan-Hallinan-dead-BPM-Corp-property-mogul-dies-cancer-apprentice-tradie-job.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 09:23:03+00:00

Jonathan Hallinan, 47, the founder and managing director of construction group BPM Corp passed away on Thursday after a two-year battle with cancer.

## Schoolboy, 13, is fighting for his life after being hit by a vehicle outside tube station
 - [https://www.dailymail.co.uk/news/article-11906315/Schoolboy-13-fighting-life-hit-vehicle-outside-tube-station.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906315/Schoolboy-13-fighting-life-hit-vehicle-outside-tube-station.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 09:22:41+00:00

The teen was struck near Stockwell Station around 7.45am this morning. Police say he is in critical condition. Stockwell Road is closed while paramedics treat the victim.

## Manchester Police arrest three as girl, four, is rushed to hospital after mauled by a pack of dogs
 - [https://www.dailymail.co.uk/news/article-11906293/Manchester-Police-arrest-three-girl-four-rushed-hospital-mauled-pack-dogs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906293/Manchester-Police-arrest-three-girl-four-rushed-hospital-mauled-pack-dogs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 09:14:46+00:00

Police arrested three people on suspicion of owning a dangerous dog. They also seizing four canines, which were taken away by specialists in Carrington, Greater Manchester.

## How Putin's winter offensive failed:
 - [https://www.dailymail.co.uk/news/article-11906291/How-Putins-winter-offensive-failed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906291/How-Putins-winter-offensive-failed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 09:08:31+00:00

VIDEO: For the last two months, Putin's generals have been hurling men, armour and artillery at Ukrainian positions - but they have almost nothing to show for it.

## Hair stylist, 49, who went on drunken rampage at an A&E unit is spared jail
 - [https://www.dailymail.co.uk/news/article-11906193/Hair-stylist-49-went-drunken-rampage-E-unit-spared-jail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906193/Hair-stylist-49-went-drunken-rampage-E-unit-spared-jail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 09:01:45+00:00

Lindsey Saville, 49, who called her hair salon in Stretford, Greater Manchester 'Off Your Head' as a tribute to her 'partying years' at the iconic Hacienda nightclub.

## More than 600 of UK's worst criminals could be blocked from prison release every year
 - [https://www.dailymail.co.uk/news/article-11906125/More-600-UKs-worst-criminals-blocked-prison-release-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906125/More-600-UKs-worst-criminals-blocked-prison-release-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 08:55:54+00:00

The new Victims and Prisoners bill would give the UK Justice Secretary Dominic Raab a veto to automatically block the release of the worst offenders.

## Why you're not losing weight: One of these salads has 330 calories more than the other
 - [https://www.dailymail.co.uk/femail/food/article-11905773/Why-youre-not-losing-weight-One-salads-330-calories-other.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/food/article-11905773/Why-youre-not-losing-weight-One-salads-330-calories-other.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 08:37:04+00:00

A nutritionist has revealed how the addition of one ingredient can add hundreds of calories to your meal.

## Russian recruits are offered £500 for every kilometre of ground they gain in Ukraine
 - [https://www.dailymail.co.uk/news/article-11906127/Russian-recruits-offered-500-kilometre-ground-gain-Ukraine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906127/Russian-recruits-offered-500-kilometre-ground-gain-Ukraine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 08:32:46+00:00

One advertisement posted by a council in the Yaroslavl region promised a £3,100 sign-up bonus and an extra £530 for 'each kilometre of advancement within assault teams'.

## Principals at school banned for life after failing to report teacher who abused a pupil
 - [https://www.dailymail.co.uk/news/article-11906019/Principals-school-banned-life-failing-report-teacher-abused-pupil.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906019/Principals-school-banned-life-failing-report-teacher-abused-pupil.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 08:31:34+00:00

The Teaching Regulation Agency (TRA) disciplinary panel ruled that Stephen and Sheila Welsby breached safeguarding obligations at St Annes College Grammar School in Lancashire, in 2018.

## Gary Lineker reveals he and BBC DG Tim Davie have 'deal' he can post about refugees
 - [https://www.dailymail.co.uk/news/article-11906053/Gary-Lineker-reveals-BBC-DG-Tim-Davie-deal-post-refugees.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906053/Gary-Lineker-reveals-BBC-DG-Tim-Davie-deal-post-refugees.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 08:30:24+00:00

Gary Lineker claims he and BBC director general Tim Davie have a deal he can Tweet about refugees and climate change.

## Pet owner reunited with lost cat Ruby after creating dating profiles for her on Grindr and Tinder
 - [https://www.dailymail.co.uk/news/article-11905997/Pet-owner-reunited-lost-cat-Ruby-creating-dating-profiles-Grindr-Tinder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905997/Pet-owner-reunited-lost-cat-Ruby-creating-dating-profiles-Grindr-Tinder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 08:12:46+00:00

Erin Johansen's black-and-white cat Ruby (pictured together) went missing last weekend, resulting in her and her friends sticking up posters and scouring the streets for the six-year-old cat.

## Crooks are targeting British golfers by creating FAKE greens to rob them
 - [https://www.dailymail.co.uk/news/article-11906161/Crooks-targeting-British-golfers-creating-FAKE-greens-rob-them.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906161/Crooks-targeting-British-golfers-creating-FAKE-greens-rob-them.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 08:05:15+00:00

Crooks are targeting British golfers in Majorca, Spain, by drilling 'false holes' in secluded areas of golf courses so they can rob them.

## Perth house auction crowd stunned after woman walks in off the street and places winning bid
 - [https://www.dailymail.co.uk/news/article-11905897/Perth-house-auction-crowd-stunned-woman-walks-street-places-winning-bid.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905897/Perth-house-auction-crowd-stunned-woman-walks-street-places-winning-bid.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 08:01:50+00:00

The property at 448 Cambridge St in the inner western Perth suburb of Floreat went under the hammer earlier this month but the crowd was stunned when a buyer swooped in as the auction was closing.

## Tory revolt to force Suella Braverman to toughen up Channel migrants Bill 'is put on hold'
 - [https://www.dailymail.co.uk/news/article-11906079/Tory-revolt-force-Suella-Braverman-toughen-Channel-migrants-Bill-hold.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11906079/Tory-revolt-force-Suella-Braverman-toughen-Channel-migrants-Bill-hold.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 07:58:09+00:00

Rebels have indicated they are unlikely to push amendments today that would completely block Strasbourg from interfering in deportations.

## Two-year-old girl is mauled by family dog in Osborne, Adelaide
 - [https://www.dailymail.co.uk/news/article-11905971/Two-year-old-girl-rushed-hospital-facial-injuries-mauled-family-dog.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905971/Two-year-old-girl-rushed-hospital-facial-injuries-mauled-family-dog.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 07:29:44+00:00

A two-year-old girl has been rushed to hospital after being attacked by a family dog in Adelaide.

## Orlando Bloom tells Zelensky 'the strength of the Ukrainians is awe-inspiring' as he visits Kyiv
 - [https://www.dailymail.co.uk/news/article-11905917/Orlando-Bloom-tells-Zelensky-strength-Ukrainians-awe-inspiring-visits-Kyiv.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905917/Orlando-Bloom-tells-Zelensky-strength-Ukrainians-awe-inspiring-visits-Kyiv.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 07:26:49+00:00

In his role as a goodwill ambassador for the UN children's organisation UNICEF, the actor spent three days in the country and visited Kyiv, Irpin and Demydiv.

## Teen thugs armed with catapults killed four swans and injured others in attack at rescue sanctuary
 - [https://www.dailymail.co.uk/news/article-11905899/Teen-thugs-armed-catapults-killed-four-swans-injured-attack-rescue-sanctuary.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905899/Teen-thugs-armed-catapults-killed-four-swans-injured-attack-rescue-sanctuary.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 07:25:24+00:00

Two cygnets and two adult swans were killed in the attack. A number of birds were injured. A 13-year-old boy was convicted of causing unnecessary suffering to protected animals last week.

## Nicola Sturgeon's successor as SNP chief will be announced TODAY
 - [https://www.dailymail.co.uk/news/article-11905977/Nicola-Sturgeons-successor-SNP-chief-announced-TODAY.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905977/Nicola-Sturgeons-successor-SNP-chief-announced-TODAY.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 07:10:17+00:00

Voting closes at noon in the bitter contest that has threatened to rip the nationalists to shreds, with the winner declared around 2pm.

## Treasurer Jim Chalmers is confronted by the Greens for not wiping student debt
 - [https://www.dailymail.co.uk/news/article-11905715/Treasurer-Jim-Chalmers-confronted-Greens-not-wiping-student-debt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905715/Treasurer-Jim-Chalmers-confronted-Greens-not-wiping-student-debt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 07:07:26+00:00

The Treasurer was grilled over the matter by Greens MP Stephen Bates during question time in federal parliament in Canberra on Monday.

## Ivanka Trump celebrates her son Theo's birthday at a skate park in Miami as she poses with a board
 - [https://www.dailymail.co.uk/news/article-11905713/Ivanka-Trump-celebrates-son-Theos-birthday-skate-park-Miami-poses-board.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905713/Ivanka-Trump-celebrates-son-Theos-birthday-skate-park-Miami-poses-board.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 06:34:40+00:00

Ivanka Trump and Jared Kushner celebrated their son's seventh birthday at a skate park in Miami with friends. The former first daughter put together a cookout while her husband coordinated with her outfit.

## Extinct Tasmanian tiger may have lived into the 2000s, study of more than 1,200 sightings finds
 - [https://www.dailymail.co.uk/news/article-11905823/Extinct-Tasmanian-tiger-lived-2000s-study-1-200-sightings-finds.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905823/Extinct-Tasmanian-tiger-lived-2000s-study-1-200-sightings-finds.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 06:34:09+00:00

The Tasmanian 'tiger' - really a marsupial - could have survived in the wild for decades longer than thought, potentially into the early 2000s, and there is a 'very small' chance some may still survive, a study suggests.

## Kamala Harris lands in Ghana on a mission to get Africa to 'expand their options' beyond China
 - [https://www.dailymail.co.uk/news/article-11905769/Kamala-Harris-lands-Ghana-mission-Africa-expand-options-China.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905769/Kamala-Harris-lands-Ghana-mission-Africa-expand-options-China.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 06:28:56+00:00

Kamala Harris landed in Ghana on Sunday at the start of a three-nation tour which officials say is intended to show Africa that the U.S. is there as a partner - and lure them away from China.

## Shark attack victim off Western Australia's Pilbara Coast bit twice near remote Montebello Islands
 - [https://www.dailymail.co.uk/news/article-11905851/Shark-attack-victim-Western-Australias-Pilbara-Coast-bit-twice-near-remote-Montebello-Islands.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905851/Shark-attack-victim-Western-Australias-Pilbara-Coast-bit-twice-near-remote-Montebello-Islands.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 06:27:44+00:00

Adam Norton was on a fishing trip off Western Australia's Pilbara Coast on Thursday when they pulled in close to the Montebello Islands in the evening, about 130km from the WA mainland.

## Michelle Obama looks unimpressed while visisting Sydney with husband Barack
 - [https://www.dailymail.co.uk/news/article-11905791/Michelle-Obama-looks-unimpressed-visisting-Sydney-husband-Barack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905791/Michelle-Obama-looks-unimpressed-visisting-Sydney-husband-Barack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 06:23:04+00:00

Former US First Lady Michelle Obama has been spotted in Sydney looking unimpressed after dining with her husband at a plush restaurant.

## Dr Charlie Teo says slapping brain tumour patient in coma nothing like Will Smith hitting Chris Rock
 - [https://www.dailymail.co.uk/news/article-11905597/Dr-Charlie-Teo-says-slapping-brain-tumour-patient-coma-like-Smith-hitting-Chris-Rock.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905597/Dr-Charlie-Teo-says-slapping-brain-tumour-patient-coma-like-Smith-hitting-Chris-Rock.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 06:18:09+00:00

Charlie Teo returned to the witness stand in Sydney on Monday for a hearing against the Health Care Complaints Commission (HCCC) into two surgeries he performed that left patients with brain injuries.

## Up to 500k women and children as young as 12 fleeing North Korea at risk of rape and sexual slavery
 - [https://www.dailymail.co.uk/news/article-11891191/Up-500k-women-children-young-12-fleeing-North-Korea-risk-rape-sexual-slavery.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11891191/Up-500k-women-children-young-12-fleeing-North-Korea-risk-rape-sexual-slavery.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 06:10:31+00:00

A human rights law firm estimates that half a million women and young girls are at 'critical risk of extreme human rights violations' including systematic rape, sexual slavery and forced pregnancy.

## Activist BLOCKS Texas senate's sergeant at arms as trans woman compares lawmakers to Nazis
 - [https://www.dailymail.co.uk/news/article-11905683/Activist-BLOCKS-Texas-senates-sergeant-arms-trans-woman-compares-lawmakers-Nazis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905683/Activist-BLOCKS-Texas-senates-sergeant-arms-trans-woman-compares-lawmakers-Nazis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 05:32:05+00:00

Loren Perkins, a transgender woman, appeared at the state capital on Thursday to provide public comment on a few laws that would prohibit drag performances in the Lone Star state.

## Bali to cancel Russian, Ukrainian tourist visa on arrival amid crackdown on bad behaviour
 - [https://www.dailymail.co.uk/news/article-11905389/Bali-cancel-Russian-Ukrainian-tourist-visa-arrival-amid-crackdown-bad-behaviour.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905389/Bali-cancel-Russian-Ukrainian-tourist-visa-arrival-amid-crackdown-bad-behaviour.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 05:24:37+00:00

Balines officials want to make it harder for travellers from two countries to get visas amid a crackdown on badly behaved tourists - and Australia is not one of them.

## Dash Cam Owners Australia: Truck's brakes fail as it hurtles down Mt Victoria, Blue Mountains, NSW
 - [https://www.dailymail.co.uk/news/article-11905603/Dash-Cam-Owners-Australia-Trucks-brakes-fail-hurtles-Mt-Victoria-Blue-Mountains-NSW.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905603/Dash-Cam-Owners-Australia-Trucks-brakes-fail-hurtles-Mt-Victoria-Blue-Mountains-NSW.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 05:24:27+00:00

A 40-tonne truck's brakes failed causing it to hurl downhill travelling on a road on Mt Victoria in the NSW Blue Mountains.

## Couple are caught cavorting NYC hotel window as in-room photographer captures 'porn shoot' on film
 - [https://www.dailymail.co.uk/news/article-11905563/Couple-caught-cavorting-NYC-hotel-window-room-photographer-captures-porn-shoot-film.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905563/Couple-caught-cavorting-NYC-hotel-window-room-photographer-captures-porn-shoot-film.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 05:17:23+00:00

Footage has been captured of what appears to be a porn shoot taking place in one of the hotel rooms of The Standard, High Line Hotel in New York City.

## Caitlin Thornton, young mum, is found dead in a suspected suicide in Cessnock
 - [https://www.dailymail.co.uk/news/article-11905513/Caitlin-Thornton-young-mum-dead-suspected-suicide-Cessnock.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905513/Caitlin-Thornton-young-mum-dead-suspected-suicide-Cessnock.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 05:12:42+00:00

Caitlin Thornton, 21, was found unconscious in the backyard of a home in Cessnock, in NSW's Hunter region, about 8.30pm on 8 March.

## Brisbane tenant scammed into paying rent for vacant rental home in Aspley
 - [https://www.dailymail.co.uk/news/article-11905017/Brisbane-tenant-scammed-paying-rent-vacant-rental-home-Aspley.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905017/Brisbane-tenant-scammed-paying-rent-vacant-rental-home-Aspley.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 05:11:17+00:00

The tenant had moved into the home on Robinson Road West, in Aspley, Brisbane, after seeing it advertised on social media in a buy and sell group.

## How to save money on your home loan: Aussies pay an average of 6.5 per cent more than cheapest rate
 - [https://www.dailymail.co.uk/news/article-11905675/How-save-money-home-loan-Aussies-pay-average-6-5-cent-cheapest-rate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905675/How-save-money-home-loan-Aussies-pay-average-6-5-cent-cheapest-rate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 04:59:12+00:00

New data shows almost a quarter of all borrowers are paying 6.5 per cent or more on their variable rate loans which is 1.81 per cent higher than the cheapest loan rate.

## Gastro doctors: This is the one food I will never eat and why it's wreaking havoc with your health
 - [https://www.dailymail.co.uk/femail/health/article-11905549/Gastro-doctors-one-food-never-eat-wreaking-havoc-health.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/health/article-11905549/Gastro-doctors-one-food-never-eat-wreaking-havoc-health.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 04:50:22+00:00

Leading experts on gas, bloating, colon cancer and other digestive issues have revealed the one food they would never eat, and some of them might surprise you.

## 'I don't know how he can live with himself': Victim slams crypto 'prodigy' who lost her $36k
 - [https://www.dailymail.co.uk/news/article-11905531/I-dont-know-live-Victim-slams-crypto-prodigy-lost-36k.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905531/I-dont-know-live-Victim-slams-crypto-prodigy-lost-36k.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 04:30:19+00:00

Aiden Pleterski, 23, from Whitby, Ontario, is accused of scamming dozens of investors by promising to put their money into cryptocurrency, but then spending much of it on himself.

## Chef Rick Stein rumoured to have bought the Oaks pub in Neutral Bay Sydney for up to $175million
 - [https://www.dailymail.co.uk/news/article-11905033/Chef-Rick-Stein-rumoured-bought-Oaks-pub-Neutral-Bay-Sydney-175million.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905033/Chef-Rick-Stein-rumoured-bought-Oaks-pub-Neutral-Bay-Sydney-175million.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 04:19:18+00:00

It is rumoured TV chef Rick Stein bought the Oaks pub in Neutral Bay in Sydney with a pool of investors after it was on sale with the record-breaking $175million price tag last August.

## Podcaster and finance expert says $80,000 isn't enough for parents
 - [https://www.dailymail.co.uk/news/article-11904755/Podcaster-finance-expert-says-80-000-isnt-parents.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11904755/Podcaster-finance-expert-says-80-000-isnt-parents.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 04:15:59+00:00

Victoria Devine admitted the salary was a 'good income' but explained why it wasn't enough for a family on her podcast, 'She's On the Money'.

## Anthony Albanese gets cranky at Indigenous Voice to Parliament questions and rips into Peter Dutton
 - [https://www.dailymail.co.uk/news/article-11905595/Anthony-Albanese-gets-cranky-Indigenous-Voice-Parliament-questions-rips-Peter-Dutton.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905595/Anthony-Albanese-gets-cranky-Indigenous-Voice-Parliament-questions-rips-Peter-Dutton.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 04:10:52+00:00

An exasperated Prime Minister Anthony Albanese dismissed concerns about the Indigenous Voice to Parliament with a bizarre NRL reference in a fiery exchange with media in Canberra.

## Lachlan Murdoch superyacht: $150million ship almost ready for News Corp media mogul after five years
 - [https://www.dailymail.co.uk/news/article-11903347/Lachlan-Murdoch-superyacht-150million-ship-ready-News-Corp-media-mogul-five-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11903347/Lachlan-Murdoch-superyacht-150million-ship-ready-News-Corp-media-mogul-five-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 03:57:27+00:00

The News Corp heir is set to receive the superyacht after  patiently waiting five years for it to be developed and finally constructed by Dutch company Royal Huisman.

## Victorian premier Dan Andrews bans the media from his trip to China
 - [https://www.dailymail.co.uk/news/article-11905025/Victorian-premier-Dan-Andrews-bans-media-trip-China.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905025/Victorian-premier-Dan-Andrews-bans-media-trip-China.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 03:51:39+00:00

Dan Andrews will not allow any media to follow him on his recently-announced trip to China.

## Declassified footage shows how B-52 crews would conduct nuclear strikes during Cold War
 - [https://www.dailymail.co.uk/news/article-11905511/Declassified-footage-shows-B-52-crews-conduct-nuclear-strikes-Cold-War.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905511/Declassified-footage-shows-B-52-crews-conduct-nuclear-strikes-Cold-War.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 03:47:50+00:00

The video, Nuclear Effects During SAC Delivery Missions, released by The U.S. National Archives and Records Administration on March 20 helped prepare bomber crews operating B-52s.

## Australian tourist warns travellers in Bali after finding Apple Airtag in her suitcase
 - [https://www.dailymail.co.uk/news/article-11905141/Australian-tourist-warns-travellers-Bali-finding-Apple-Airtag-suitcase.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905141/Australian-tourist-warns-travellers-Bali-finding-Apple-Airtag-suitcase.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 03:38:31+00:00

An Australian tourist travelling Bali with her partner posted a dire warning for others after discovering a disturbing item hidden in her luggage.

## NSW election 2023: How Chris Minns became one of Australia's most powerful men
 - [https://www.dailymail.co.uk/news/article-11904845/Minns-giggles-hes-addressed-Premier-promises-excited.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11904845/Minns-giggles-hes-addressed-Premier-promises-excited.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 03:28:37+00:00

For all Minns's quiet confidence throughout the campaign, the most surprised of all of them was the man himself.

## Cuddles Childcare Centre in Byford, Perth, fined after toddler suffered burns to foot on playground
 - [https://www.dailymail.co.uk/news/article-11905361/Cuddles-Childcare-Centre-Byford-Perth-fined-toddler-suffered-burns-foot-playground.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905361/Cuddles-Childcare-Centre-Byford-Perth-fined-toddler-suffered-burns-foot-playground.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 03:15:25+00:00

The one-year-old girl had been in the outdoor play area at the Cuddles Early Learning and Childcare Centre in Byford, in Perth's south-east, during a scorching hot day in February last year.

## Barack Obama meets with Anthony Albanese on a rainy Sydney day
 - [https://www.dailymail.co.uk/news/article-11905227/Barack-Obama-meets-Anthony-Albanese-rainy-Sydney-day.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905227/Barack-Obama-meets-Anthony-Albanese-rainy-Sydney-day.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 02:31:28+00:00

Barack Obama met with Anthony Albanese and the US Ambassador to Australia just hours after the former US President arrived in Australia for a speaking tour.

## Charlie Teo seethes as he's grilled over whether he cut into too much of a patient's brain
 - [https://www.dailymail.co.uk/news/article-11905429/Charlie-Teo-seethes-hes-grilled-cut-patients-brain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905429/Charlie-Teo-seethes-hes-grilled-cut-patients-brain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 02:31:20+00:00

Charlie Teo returned to the witness stand in Sydney on Monday for a hearing against the Health Care Complaints Commission (HCCC) into two surgeries he performed that left patients with brain injuries.

## Cops arrest 'prostitute' after Georgia dad, 42, 'overdosed' was found wrapped in a carpet
 - [https://www.dailymail.co.uk/news/article-11905163/Cops-arrest-prostitute-Georgia-dad-42-overdosed-wrapped-carpet.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905163/Cops-arrest-prostitute-Georgia-dad-42-overdosed-wrapped-carpet.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 02:16:05+00:00

Tiffany Ann Guidry, 26, was arrested on Friday for unlawful disposal of remains in connection to the February 23 disappearance of Nathan Millard, 42, according to an arrest report.

## French journal from 1687 on L'Oiseau ship records first European sighting of Australian coastline
 - [https://www.dailymail.co.uk/news/article-11904929/French-journal-1687-LOiseau-ship-records-European-sighting-Australian-coastline.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11904929/French-journal-1687-LOiseau-ship-records-European-sighting-Australian-coastline.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 02:06:39+00:00

A 330-year-old journal written by a French naval surgeon onboard Louis XIV's royal fleet describes the first ever European sighting of Australia's coastline.

## Dentist found guilty of sexually assaulting patients in two Mascot clinics
 - [https://www.dailymail.co.uk/news/article-11905293/Dentist-guilty-sexually-assaulting-patients-two-Mascot-clinics.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905293/Dentist-guilty-sexually-assaulting-patients-two-Mascot-clinics.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 02:01:14+00:00

The jury heard during a trial that Bassem Magdy El-Badrawy Fouad molested five female patients, including a 15-year-old girl, at his two dental clinics in Mascot between 2015 and 2021.

## Judge fired after his porn star double-life on OnlyFans was exposed posts selfie at Adele concert
 - [https://www.dailymail.co.uk/news/article-11905183/Judge-fired-porn-star-double-life-OnlyFans-exposed-posts-selfie-Adele-concert.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905183/Judge-fired-porn-star-double-life-OnlyFans-exposed-posts-selfie-Adele-concert.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 01:56:08+00:00

Gregory A. Locke ,33, a former judge who was fired for moonlighting as a porn star on OnlyFans, posted Instagram video attending an Adele concert in Las Vegas.

## 'Rolex ripper' gangs stalk celebrity social media profiles before rare timepieces are stolen
 - [https://www.dailymail.co.uk/news/article-11905329/Rolex-ripper-gangs-stalk-celebrity-social-media-profiles-rare-timepieces-stolen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905329/Rolex-ripper-gangs-stalk-celebrity-social-media-profiles-rare-timepieces-stolen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 01:33:37+00:00

The thugs, aware of the value of these timepieces, are robbing people on the street using knives and guns to pressgang victims into handing over their valuables.

## Heston Blumenthal, 56, ties the knot for the THIRD time as he weds his 36-year-old partner
 - [https://www.dailymail.co.uk/tvshowbiz/article-11904725/Heston-Blumenthal-56-ties-knot-time-weds-36-year-old-partner.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-11904725/Heston-Blumenthal-56-ties-knot-time-weds-36-year-old-partner.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 01:30:40+00:00

EXCLUSIVE: The Michelin-starred owner of The Fat Duck, who's known for delighting diners with surprising dishes exchanged vows with entrepreneur Melanie Ceysson, 36, on Saturday.

## Sovereign citizen is brutally slapped down by a cop in NSW: 'This isn't America'
 - [https://www.dailymail.co.uk/news/article-11905197/Sovereign-citizen-brutally-slapped-cop-NSW-isnt-America.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905197/Sovereign-citizen-brutally-slapped-cop-NSW-isnt-America.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 01:29:45+00:00

A 'sovereign citizen' who was pulled over in NSW for a random breath test has been given a serving by a police after he got into an argument, with one officer telling him 'this is not America'.

## Russian MPs' sons are 'mobilised to cronies unit far away from front lines'
 - [https://www.dailymail.co.uk/news/article-11905403/Russian-MPs-sons-mobilised-cronies-unit-far-away-lines.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905403/Russian-MPs-sons-mobilised-cronies-unit-far-away-lines.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 01:25:48+00:00

Kremlin politicians are accused of establishing a 'cronies' military unit in Ukraine far away from the frontlines of battle, so that they and their sons can serve without a risk of being killed.

## Greens support Labor's safeguard mechanism introducing coal and gas 'limits'
 - [https://www.dailymail.co.uk/news/article-11905341/Greens-support-Labors-safeguard-mechanism-introducing-coal-gas-limits.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905341/Greens-support-Labors-safeguard-mechanism-introducing-coal-gas-limits.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 01:25:31+00:00

The safeguard mechanism will now be able to pass through the Senate and become law, after weeks of concerns the Greens could destroy the proposal by refusing to back it.

## Melissa Caddick: Pickles auction house sells son's toys, Dior Chanel books, Ruinart champagne
 - [https://www.dailymail.co.uk/news/article-11904969/Melissa-Caddick-Pickles-auction-house-sells-sons-toys-Dior-Chanel-books-Ruinart-champagne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11904969/Melissa-Caddick-Pickles-auction-house-sells-sons-toys-Dior-Chanel-books-Ruinart-champagne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 01:20:37+00:00

Liquidators are  auctioning off the financial advisor's family goods to repay some of the $23million she stole from clients before   vanishing in November 2020.

## Twitter's source code is published online - forcing Elon Musk's firm to immediately file a lawsuit
 - [https://www.dailymail.co.uk/news/article-11905169/Twitters-source-code-published-online-forcing-Elon-Musks-firm-immediately-file-lawsuit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905169/Twitters-source-code-published-online-forcing-Elon-Musks-firm-immediately-file-lawsuit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 01:14:09+00:00

Twitter's source code has been published online on the site GitHub, thanks to a user named 'FreeSpeechEnthusiast'. Twitter is seeking a subpoena to reveal who is behind the account.

## Sidney Cooke, 96, should be quizzed about string of unsolved child murders says ex-detective
 - [https://www.dailymail.co.uk/news/article-11905359/Sidney-Cooke-96-quizzed-string-unsolved-child-murders-says-ex-detective.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905359/Sidney-Cooke-96-quizzed-string-unsolved-child-murders-says-ex-detective.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 01:12:43+00:00

An ex-detective wants Sidney Cooke (centre) to be questioned over a  unsolved child murders after he convicted over Jason Swift's (left) death and linked to the death of Mark Tildesley (right).

## Gina Rinehart, Australia's richest person, gives interview as Hancock Prospecting prospers
 - [https://www.dailymail.co.uk/news/article-11904873/Gina-Rinehart-Australias-richest-person-gives-interview-Hancock-Prospecting-prospers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11904873/Gina-Rinehart-Australias-richest-person-gives-interview-Hancock-Prospecting-prospers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 01:11:08+00:00

Gina Rinehart, who was named Australia's richest person with an estimated $34billion fortune, has given a rare interview where she targeted those who don't appreciate the benefits mining delivers.

## Manchester United star Brendon Williams caught 'inhaling nitrous oxide from a balloon'
 - [https://www.dailymail.co.uk/news/article-11905177/Manchester-United-star-Brendon-Williams-caught-inhaling-nitrous-oxide-balloon.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905177/Manchester-United-star-Brendon-Williams-caught-inhaling-nitrous-oxide-balloon.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 01:09:18+00:00

The 22-year-old full-back, who has failed to break-out into Manchester United's first team this season, was filmed inhaling the laughing gas in a moving Mercedes Brabus supercar.

## One of Nicola Sturgeon's aides tried to force Kate Forbes to ditch her leadership bid, allies claim
 - [https://www.dailymail.co.uk/news/article-11905379/One-Nicola-Sturgeons-aides-tried-force-Kate-Forbes-ditch-leadership-bid-allies-claim.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905379/One-Nicola-Sturgeons-aides-tried-force-Kate-Forbes-ditch-leadership-bid-allies-claim.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 01:02:22+00:00

Liz Lloyd, who is reported to have been helping rival candidate Humza Yousaf with his campaign, is alleged to have urged Ms Forbes not to enter the contest.

## Police probing Madeleine McCann case 'set to get hundreds of thousands of pounds in new funding'
 - [https://www.dailymail.co.uk/news/article-11905333/Police-probing-Madeleine-McCann-case-set-hundreds-thousands-pounds-new-funding.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905333/Police-probing-Madeleine-McCann-case-set-hundreds-thousands-pounds-new-funding.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 01:01:59+00:00

A significant sum of money has been requested by the Met Police and is likely to be approved by the Home Office to try and find Madeleine McCann, almost 16 years after her disappearance.

## Week-long rain to hit Sydney, Melbourne, Canberra and Hobart
 - [https://www.dailymail.co.uk/news/article-11904751/Week-long-rain-hit-Sydney-Melbourne-Canberra-Hobart.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11904751/Week-long-rain-hit-Sydney-Melbourne-Canberra-Hobart.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 00:45:32+00:00

Two heavy rain systems are set to bring week-long rain to several major cities.

## Thomastown crash: Melbourne victim Lara Guglielmi linked to Bill Hexter death in Burwood
 - [https://www.dailymail.co.uk/news/article-11904993/Thomastown-crash-Melbourne-victim-Lara-Guglielmi-linked-Bill-Hexter-death-Burwood.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11904993/Thomastown-crash-Melbourne-victim-Lara-Guglielmi-linked-Bill-Hexter-death-Burwood.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 00:40:58+00:00

Lara Guglielmi, 19, was travelling in a white Kia Cerato when it collided with a Mercedes SUV in the north Melbourne suburb of Thomastown about 1.10am on Sunday.

## CHRISTOPHER STEVENS: 'Not even the great Olivia Colman can rescue the BBC's Woke Desecrations'
 - [https://www.dailymail.co.uk/tvshowbiz/article-11904711/CHRISTOPHER-STEVENS-Not-great-Olivia-Colman-rescue-BBCs-Woke-Desecrations.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-11904711/CHRISTOPHER-STEVENS-Not-great-Olivia-Colman-rescue-BBCs-Woke-Desecrations.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 00:34:46+00:00

CHRISTOPHER STEVENS: How Charles Dickens would have loved and hated the pan-jandrums of the BBC. Loved laughing at them, hated them for ruining his finest story.

## Labor's Chris Minns election pledges after beating Liberal Dominic Perrottet in NSW state election
 - [https://www.dailymail.co.uk/news/article-11904739/Labors-Chris-Minns-election-pledges-beating-Liberal-Dominic-Perrottet-NSW-state-election.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11904739/Labors-Chris-Minns-election-pledges-beating-Liberal-Dominic-Perrottet-NSW-state-election.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 00:28:05+00:00

Chris Minns resoundingly defeated Dominic Perrottet to become the 47th premier of NSW on Saturday night.

## Antonio Conte LEAVES Tottenham by mutual consent
 - [https://www.dailymail.co.uk/sport/football/article-11884729/Tottenham-Hotspur-SACK-Antonio-Conte-manager.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/football/article-11884729/Tottenham-Hotspur-SACK-Antonio-Conte-manager.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 00:27:05+00:00

Conte had taken over as Spurs in November 2021 following an ill-fated start to the season under his predecessor Nuno Espirito Santo and what's followed has been a rollercoaster 16-months in charge.

## LatitudePay Australian buy now, pay later provider used by JB-HiFi and Harvey Norman hacked
 - [https://www.dailymail.co.uk/news/article-11905315/LatitudePay-Australian-buy-pay-later-provider-used-JB-HiFi-Harvey-Norman-hacked.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905315/LatitudePay-Australian-buy-pay-later-provider-used-JB-HiFi-Harvey-Norman-hacked.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 00:27:03+00:00

Digital payments and lending firm Latitude Group Holdings Ltd has admitted a hacker has stolen the personal information of up to 15 million customers - in one of the most significant hacks of an Australian company this year.

## Thomastown crash: Melbourne teen Lara Guglielmi dies in allegedly stolen Kia Cerato as driver flees
 - [https://www.dailymail.co.uk/news/article-11904915/Thomastown-crash-Melbourne-teen-Lara-Guglielmi-dies-allegedly-stolen-Kia-Cerato-driver-flees.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11904915/Thomastown-crash-Melbourne-teen-Lara-Guglielmi-dies-allegedly-stolen-Kia-Cerato-driver-flees.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 00:26:33+00:00

Lara Guglielmi, 19, died on Sunday in the north Melbourne suburb of Thomastown when the Kia Cerato she was a passenger in smashed into a Mercedes SUV.

## Study finds 10 versions of honey on sale in UK were diluted with cheap sugar syrup
 - [https://www.dailymail.co.uk/news/article-11905201/Study-finds-10-versions-honey-sale-UK-diluted-cheap-sugar-syrup.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905201/Study-finds-10-versions-honey-sale-UK-diluted-cheap-sugar-syrup.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 00:25:38+00:00

All honeys tested in the UK for a study by the European Commission were found to have been diluted with cheap sugar syrup as the Government says it will investigate the claims.

## Ukrainian soldiers trained by Britain return home to fight Vladimir Putin's forces
 - [https://www.dailymail.co.uk/news/article-11905237/Ukrainian-soldiers-trained-Britain-return-home-fight-Vladimir-Putins-forces.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905237/Ukrainian-soldiers-trained-Britain-return-home-fight-Vladimir-Putins-forces.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 00:25:31+00:00

Ukrainian army crews trained in Britain have returned to the front-line to continue the fight against Vladmir Putin's troops, armed with Challenger 2 tanks.

## TOM RAWSTORNE: Linked to dozens of deaths and paralysis, why laughing gas is far from a joke
 - [https://www.dailymail.co.uk/debate/article-11904919/TOM-RAWSTORNE-Linked-dozens-deaths-paralysis-laughing-gas-far-joke.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/debate/article-11904919/TOM-RAWSTORNE-Linked-dozens-deaths-paralysis-laughing-gas-far-joke.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 00:24:29+00:00

TOM RAWSTORNE: Images show skip-fulls of industrial-grade canisters of nitrous oxide, a substance which has been linked to deaths, including that of 16-year-old Kayleigh Burnes (left)

## Black children in Britain are SIX times more likely to be strip-searched by police
 - [https://www.dailymail.co.uk/news/article-11905225/Black-children-Britain-SIX-times-likely-strip-searched-police.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905225/Black-children-Britain-SIX-times-likely-strip-searched-police.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 00:17:34+00:00

Almost 3,000 children as young as eight were strip-searched between 2018 and mid-2022, according to research from the children's commissioner Dame Rachel de Souza (pictured).

## Keir Starmer hits out at lawyers for refusing to prosecute disruptive climate activists
 - [https://www.dailymail.co.uk/news/article-11905157/Keir-Starmer-hits-lawyers-refusing-prosecute-disruptive-climate-activists.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905157/Keir-Starmer-hits-lawyers-refusing-prosecute-disruptive-climate-activists.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 00:07:52+00:00

The former director of public prosecutions said he was committed to the 'cab-rank rule', where lawyers take on cases as they are assigned them rather than hand-picking clients.

## How homeowners in commuter belt counties will be hardest hit by the interest rate rise
 - [https://www.dailymail.co.uk/news/article-11905171/How-homeowners-commuter-belt-counties-hardest-hit-rate-rise.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11905171/How-homeowners-commuter-belt-counties-hardest-hit-rate-rise.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-03-27 00:05:46+00:00

Every month more than 17,000 residents in the South East reach the end of a fixed-rate mortgage - more than any other part of the country.

