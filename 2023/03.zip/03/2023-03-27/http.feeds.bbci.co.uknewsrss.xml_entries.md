# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## The Papers: Fight for union and 'crackdown on party houses'
 - [https://www.bbc.co.uk/news/blogs-the-papers-65095046?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-65095046?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 23:27:36+00:00

Tuesday's newspapers include the new SNP leader and the government's anti-social behaviour crackdown.

## Nazare: Love and pain on the world's biggest wave
 - [https://www.bbc.co.uk/sport/surfing/65056499?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/surfing/65056499?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 23:16:53+00:00

For generations of locals, Nazare's giant waves meant only death and danger to locals. Now, they have fuelled a big-wave surfing boom in the town.

## Clearview AI used nearly 1m times by US police, it tells the BBC
 - [https://www.bbc.co.uk/news/technology-65057011?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-65057011?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 22:44:57+00:00

Clearview AI has been used by the police nearly a million times in the US, it tells the BBC.

## Rangers 1-1 Celtic: Dramatic SWPL draw ends with apparent headbutt on Fran Alonso
 - [https://www.bbc.co.uk/sport/football/65094399?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65094399?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 22:43:29+00:00

Celtic head coach Fran Alonso appeared to be headbutted by a member of the Rangers coaching staff in the aftermath of a dramatic 1-1 draw in the Scottish Women's Premier League.

## Gwyneth Paltrow ski crash trial: Accuser heard 'blood-curdling scream'
 - [https://www.bbc.co.uk/news/world-us-canada-65095127?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-65095127?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 22:36:37+00:00

A man suing Gwyneth Paltrow over a ski crash says it sounded "like someone was out of control".

## Chris Mason: Old tensions to remain for SNP's new leader
 - [https://www.bbc.co.uk/news/uk-politics-65093594?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-65093594?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 22:27:53+00:00

The election of Humza Yousaf gives the SNP a softer political landing than a Kate Forbes victory.

## Man uses bare hands to rescue trapped DRC miners
 - [https://www.bbc.co.uk/news/world-africa-65095295?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-65095295?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 22:04:22+00:00

Authorities say nine men survived a collapsed gold mine in South Kivu.

## Can Humza Yousaf unite the SNP?
 - [https://www.bbc.co.uk/news/uk-scotland-scotland-politics-65095168?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-scotland-politics-65095168?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 22:02:30+00:00

Humza Yousaf faces several challenges as he takes over as SNP leader and Scotland's first minister.

## Shooting survivor: 'Aren't you tired of covering this?'
 - [https://www.bbc.co.uk/news/world-us-canada-65095161?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-65095161?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 21:33:33+00:00

After surviving a mass shooting in Illinois, a woman visiting Nashville confronts media.

## Euro 2024 qualifiers: Republic of Ireland 0-1 France - Pavard goal gives French win in Dublin
 - [https://www.bbc.co.uk/sport/football/65029441?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65029441?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 21:12:43+00:00

The Republic of Ireland make a losing start to Euro 2024 qualifying as Benjamin Pavard's superb second-half goal gives France victory in Dublin.

## Antonio Conte: Italian thanks Tottenham and fans for sharing 'passion' for football
 - [https://www.bbc.co.uk/sport/football/65094349?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65094349?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 20:25:58+00:00

Antonio Conte has thanked Tottenham's fans for their "support and appreciation", adding he welcomed those at the club who shared his passion for football.

## NFT: Plans for Royal Mint produced token dropped by government
 - [https://www.bbc.co.uk/news/uk-politics-65094297?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-65094297?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 19:42:28+00:00

Plans for a government-backed digital token, ordered to be created by Rishi Sunak, have been axed.

## Israel protests: PM Netanyahu delays legal reforms after day of strikes
 - [https://www.bbc.co.uk/news/world-middle-east-65093509?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-65093509?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 18:53:03+00:00

His proposed changes provoked an outpouring of anger from nearly all parts of Israeli society.

## Civil servants to strike in April
 - [https://www.bbc.co.uk/news/business-65091905?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-65091905?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 17:49:39+00:00

The PCS union said 130,000 members voted to strike on 28 April in a continued row over pay, pensions and job security.

## Rotherham grooming survivor awarded £425k after suing rapist
 - [https://www.bbc.co.uk/news/uk-england-south-yorkshire-65090793?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-south-yorkshire-65090793?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 17:03:34+00:00

Liz says she is "proud" to have brought the action against the man who raped her as a teenager.

## Nashville Covenant School shooting: Multiple victims, shooter dead
 - [https://www.bbc.co.uk/news/uk-65092102?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-65092102?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 16:38:24+00:00

Multiple people have been injured at a Nashville school, according to local officials.

## How will Scotland's new first minister be appointed?
 - [https://www.bbc.co.uk/news/uk-scotland-scotland-politics-65080624?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-scotland-politics-65080624?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 16:24:50+00:00

Humza Yousaf will face a vote in the Scottish Parliament on Tuesday before being confirmed as the country's sixth first minister.

## Harry's power play: Why has the prince turned up at court?
 - [https://www.bbc.co.uk/news/uk-65092316?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-65092316?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 16:23:01+00:00

The prince's appearance at London’s High Court took many by surprise.

## Nitrous oxide: What is it and how dangerous is it?
 - [https://www.bbc.co.uk/news/health-65088226?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-65088226?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 15:43:33+00:00

How is laughing gas used and what does it do to your body?

## Teacher strikes: Government makes offer to end dispute
 - [https://www.bbc.co.uk/news/education-65037422?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/education-65037422?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 15:37:43+00:00

It marks the end of intensive talks on the pay, conditions and workload of teachers in England.

## Man who praised Samuel Paty murder found guilty of terrorism offences
 - [https://www.bbc.co.uk/news/uk-england-nottinghamshire-65086949?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-nottinghamshire-65086949?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 15:36:19+00:00

Ajmal Shahpal posted an image of a terrorist victim's severed head on Twitter.

## Alexa Bliss: WWE star urges sunbed safety after skin cancer scare
 - [https://www.bbc.co.uk/news/newsbeat-65069697?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-65069697?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 15:35:09+00:00

The WWE star, who recently had skin cancer treatment, says she should have avoided tanning beds.

## Families of HMS Dasher dead demand answers
 - [https://www.bbc.co.uk/news/uk-scotland-65086104?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-65086104?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 15:30:41+00:00

Aircraft carrier HMS Dasher exploded in 1943 killing 379 - 80 years on relatives feel cheated of the truth.

## Winter sports: How Great Britain 'came back fighting' after 'terrible' Beijing Winter Olympics
 - [https://www.bbc.co.uk/sport/winter-sports/64993239?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/winter-sports/64993239?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 15:18:22+00:00

Team GB were left to "lick their wounds" after a "terrible" Winter Olympics. A year on, GB's winter athletes have mounted an incredible comeback.

## Lebanon reverses decision to delay daylight savings time change
 - [https://www.bbc.co.uk/news/world-middle-east-65090888?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-65090888?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 15:06:18+00:00

Christian authorities changed clocks on Sunday, in defiance of a move meant to help fasting Muslims.

## Johnny Sexton: Leinster captain set to miss rest of season with groin injury
 - [https://www.bbc.co.uk/sport/rugby-union/65092091?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/65092091?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 14:59:15+00:00

Ireland's Johnny Sexton is "likely" to miss the rest of the season after suffering a groin injury.

## The OnlyFans creators getting tax deductible breast implants
 - [https://www.bbc.co.uk/news/entertainment-arts-65050950?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-65050950?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 14:50:46+00:00

An unnamed creator became the first case to be known to the media, but it's not a new phenomenon.

## Humza Yousaf: We will be the generation that delivers independence for Scotland
 - [https://www.bbc.co.uk/news/uk-scotland-65091157?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-65091157?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 14:26:07+00:00

Humza Yousaf has called on the party to unite behind him after he was elected as new leader of the SNP.

## Gwyneth Paltrow ski crash trial: Who's who
 - [https://www.bbc.co.uk/news/world-us-canada-65088874?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-65088874?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 14:25:52+00:00

Paltrow's accuser Terry Sanderson will testify on Monday, as will three members of her family,

## Five planets to line up in night sky
 - [https://www.bbc.co.uk/news/science-environment-65056407?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-65056407?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 14:24:14+00:00

To spot all five, timing and a clear view of the western horizon will be key.

## Japanese student dresses as Volodymyr Zelensky for graduation
 - [https://www.bbc.co.uk/news/world-asia-65090318?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-65090318?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 14:17:49+00:00

Taking part in a Kyoto university tradition, it took him three months to grow a beard for the look.

## Heathrow strike forces BA Easter flight cancellations
 - [https://www.bbc.co.uk/news/business-65091012?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-65091012?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 14:14:29+00:00

The move is due to a planned 10-day strike by some Heathrow security workers in the Unite union.

## Stuart Hogg profile after Scotland & Lions full-back plots end of career
 - [https://www.bbc.co.uk/sport/rugby-union/64879804?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/64879804?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 14:10:10+00:00

After announcing his decision to retire later this year, Tom English profiles the compelling, complex and unsparingly honest Stuart Hogg.

## Marco Silva: Fulham boss receives further FA charge relating to FA Cup loss at Manchester United
 - [https://www.bbc.co.uk/sport/football/65090167?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65090167?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 13:37:49+00:00

Fulham manager Marco Silva is charged with misconduct for comments he made following his side's FA Cup defeat by Manchester United.

## Italian art experts astonished by David statue uproar in Florida
 - [https://www.bbc.co.uk/news/world-europe-65087218?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-65087218?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 13:24:44+00:00

A Florida school head was forced out after the famous Michaelangelo statue was shown to art students.

## Humza Yousaf to succeed Sturgeon as SNP leader
 - [https://www.bbc.co.uk/news/uk-scotland-scotland-politics-65086551?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-scotland-politics-65086551?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 13:23:21+00:00

Scotland's health secretary defeats rivals Kate Forbes and Ash Regan in a vote of party members.

## Who is Humza Yousaf, the SNP's new leader?
 - [https://www.bbc.co.uk/news/uk-scotland-scotland-politics-64874821?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-scotland-politics-64874821?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 13:14:15+00:00

He was widely seen as the preferred candidate of the SNP establishment - including Nicola Sturgeon.

## Lions & Scotland full-back Hogg to retire after World Cup
 - [https://www.bbc.co.uk/sport/rugby-union/65090358?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/65090358?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 12:46:27+00:00

Scotland and Exeter full-back Stuart Hogg announces he will retire from rugby after the World Cup in France this autumn.

## Actor Orlando Bloom meets children affected by Ukraine war and visits Zelensky
 - [https://www.bbc.co.uk/news/world-europe-65085212?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-65085212?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 12:23:28+00:00

The Lord of the Rings star, who is a goodwill ambassador for Unicef, also met President Zelensky.

## Gary Lineker says he teared up over co-hosts' support in impartiality row
 - [https://www.bbc.co.uk/news/entertainment-arts-65087544?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-65087544?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 12:13:53+00:00

The football TV host says had "a tear in my eye" after his co-presenters supported him over BBC row.

## Israel judicial reform: Why is there a crisis?
 - [https://www.bbc.co.uk/news/world-middle-east-65086871?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-65086871?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 11:35:57+00:00

Israel is facing one of the biggest internal crises in its history - here's why.

## Hannah Dingley: Forest Green's trailblazing academy manager on encouraging women into coaching
 - [https://www.bbc.co.uk/sport/football/65080960?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65080960?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 11:16:39+00:00

Forest Green academy manager Hannah Dingley thinks it "will not be long" until a woman is managing a men's professional club.

## Laughing gas: Experts warn nitrous oxide ban will not stop use
 - [https://www.bbc.co.uk/news/uk-politics-65085987?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-65085987?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 11:08:41+00:00

The government defends new plans to tackle anti-social behaviour by clamping down on nitrous oxide.

## Outrage at public contract for firm behind P&O sackings
 - [https://www.bbc.co.uk/news/business-65086060?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-65086060?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 09:46:30+00:00

It comes after DP World is chosen to run a new freeport, despite having sacked 800 workers without notice last year.

## Linda Nolan says cancer has spread to her brain, in fourth diagnosis
 - [https://www.bbc.co.uk/news/entertainment-arts-65086268?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-65086268?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 09:44:49+00:00

It is her fourth diagnosis with the disease, and says it is "frightening" but is "staying positive".

## Prince Harry arrives for newspaper phone-tapping High Court hearing
 - [https://www.bbc.co.uk/news/uk-65085209?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-65085209?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 09:19:43+00:00

He is attending the High Court as legal proceedings begin in a phone-tapping and privacy case.

## Prince Harry turns up to High Court in Associated Newspapers hearing
 - [https://www.bbc.co.uk/news/entertainment-arts-65087072?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-65087072?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 09:18:22+00:00

The Duke of Sussex has accused the publisher of the Daily Mail of unlawful information gathering.

## Benjamin Netanyahu, Israel's defiant leader
 - [https://www.bbc.co.uk/news/world-middle-east-18008697?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-18008697?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 08:56:45+00:00

How an ex-commando became the most dominant figure in the country's recent history.

## Welsh language: New law to help all students speak confidently by 2050
 - [https://www.bbc.co.uk/news/uk-wales-65082197?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-65082197?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 08:56:38+00:00

More Welsh-medium schools and increased Welsh language provision in English-medium schools are aims.

## Republic of Ireland v France: Kylian Mbappe determined to thwart teenager Evan Ferguson
 - [https://www.bbc.co.uk/sport/football/65085934?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65085934?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 08:24:13+00:00

France captain Kylian Mbappe is determined to prevent Republic of Ireland striker Evan Ferguson from adding another chapter to his football fairytale.

## Harry Potter: Final coin issued to celebrate 25th anniversary
 - [https://www.bbc.co.uk/news/uk-wales-65085944?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-65085944?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 08:03:41+00:00

The coin features Hogwarts School of Witchcraft and Wizardry and completes the collection.

## British Gas,Scottish Power and Ovo dominate forced installations
 - [https://www.bbc.co.uk/news/business-65086134?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-65086134?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 08:02:11+00:00

British Gas, Scottish Power and Ovo Energy made up 70% of all forced installations last year, the government says.

## 'Serious questions' over oil field's 200-barrel leak - council
 - [https://www.bbc.co.uk/news/uk-england-dorset-65085130?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-dorset-65085130?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 06:58:37+00:00

The pipeline was shut down and specialist oil spill companies brought in after the 200-barrel leak.

## England's Hall loses to Boutier in LPGA play-off
 - [https://www.bbc.co.uk/sport/golf/65085081?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/golf/65085081?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 06:53:30+00:00

England's Georgia Hall loses to France's Celine Boutier in a play-off at the LPGA Drive On Championship in Arizona.

## O'Neill's Northern Ireland return - below par or reality check?
 - [https://www.bbc.co.uk/sport/football/65084042?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65084042?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 06:49:14+00:00

An analysis of where Northern Ireland are at as Michael O'Neill's second spell in charge begins with a win away to San Marino and defeat at home to Finland.

## Silicon Valley Bank: Collapsed US lender bought by rival
 - [https://www.bbc.co.uk/news/business-65084248?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-65084248?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 06:30:45+00:00

The collapsed lender was seized by US regulators after a run on the bank.

## Antonio Conte: Nagelsmann, Pochettino, Enrique - who should be Tottenham's long-term successor?
 - [https://www.bbc.co.uk/sport/football/65037269?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65037269?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 06:08:06+00:00

Tottenham will be looking for a new manager this summer after the departure of Antonio Conte, but who do you think they should appoint?

## 1Xtra: Reece Parkinson leaves BBC radio station after six years
 - [https://www.bbc.co.uk/news/newsbeat-64978263?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-64978263?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 06:06:31+00:00

BBC Newsbeat gets help from a very special guest to give the drive-time host the perfect send-off.

## Arlo Parks on creating her version of My Bloody Valentine's 'wall of sound'
 - [https://www.bbc.co.uk/news/entertainment-arts-65083000?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-65083000?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 05:40:44+00:00

The singer-songwriter says she will show her love of bands like My Bloody Valentine on her second LP.

## Women's Six Nations 2023: Best moments of round one
 - [https://www.bbc.co.uk/sport/av/rugby-union/65081153?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/rugby-union/65081153?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 05:15:25+00:00

Watch the best moments from the opening round of the Women's Six Nations as Sarah Hunter bows out and Sisilia Tuipulotu reacts to being named player of the match.

## Match of the Day Top 10: Micah Richards explains why Roy Keane & Ian Wright are great football pundits
 - [https://www.bbc.co.uk/sport/av/football/64976975?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/64976975?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 05:10:43+00:00

Gary Lineker, Alan Shearer and Micah Richards discuss how social media has changed the role of a pundit as they attempt to rank the biggest names.

## Afghanistan girls' education: 'When I see the boys going to school, it hurts'
 - [https://www.bbc.co.uk/news/world-asia-65058099?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-65058099?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 05:00:12+00:00

Afghan teenage girls describe feeling "broken" at being barred from attending school under Taliban rule.

## Tory rebellion over small boats bill put on hold
 - [https://www.bbc.co.uk/news/uk-politics-65084430?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-65084430?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 04:55:34+00:00

A group of MPs will meet with ministers to look at how to tighten up the bill, instead of voting against it.

## Cost of living: Derbyshire chip shop that opened in 1961 to close
 - [https://www.bbc.co.uk/news/uk-england-derbyshire-65056909?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-derbyshire-65056909?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 01:25:49+00:00

Dennis Jackson, 84, will hang up his apron on 8 April and says it will be an emotional day.

## SNP to announce Nicola Sturgeon's successor
 - [https://www.bbc.co.uk/news/uk-scotland-scotland-politics-65065112?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-scotland-politics-65065112?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 01:16:19+00:00

The party will confirm their next leader later after a process that has revealed deep divisions.

## Mass Israel protests after Netanyahu fires defence minister
 - [https://www.bbc.co.uk/news/world-middle-east-65083776?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-65083776?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 00:48:19+00:00

Tens of thousands demonstrate after the removal of Yoav Gallant - who spoke out against controversial judicial reforms.

## The Papers: 'Crunch vote on small boats' and laughing gas ban
 - [https://www.bbc.co.uk/news/blogs-the-papers-65083908?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-65083908?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 00:04:05+00:00

Monday's papers lead on the return of the Illegal Migration Bill and the government's nitrous oxide ban.

## Eurovision 2023: Mae Muller and other hopefuls get pre-parties started across Europe
 - [https://www.bbc.co.uk/news/entertainment-arts-65066094?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-65066094?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-03-27 00:00:41+00:00

Participants of the song contest begin the build-up to Liverpool by performing for fans across Europe.

