# Source:Washington Examiner - politics, URL:https://feeds.feedburner.com/dcexaminer/Politics, language:en-US

## More than 6 in 10 do not want Trump as president: Poll
 - [https://www.washingtonexaminer.com/news/campaigns/more-than-six-in-10-do-not-want-trump-as-president-poll](https://www.washingtonexaminer.com/news/campaigns/more-than-six-in-10-do-not-want-trump-as-president-poll)
 - RSS feed: https://feeds.feedburner.com/dcexaminer/Politics
 - date published: 2023-03-27 19:48:52+00:00

More than 6 in 10 adults do not want former President Donald Trump, who appears to be on the verge of being indicted by a Manhattan grand jury, to be elected president again.

