# Source:Epoch Times Tech, URL:https://www.theepochtimes.com/c-tech/feed/, language:en-US

## Data Gathered Through Tiktok Might Enable CCP to Undermine US Economy: Former Diplomat Official
 - [https://www.theepochtimes.com/data-gathered-through-tiktok-might-enable-ccp-to-undermine-us-economy-former-diplomat-official_5151895.html](https://www.theepochtimes.com/data-gathered-through-tiktok-might-enable-ccp-to-undermine-us-economy-former-diplomat-official_5151895.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2023-03-27 17:25:40+00:00

David Stilwell, U.S. Assistant Secretary for East Asian and Pacific Affairs, answers reporters' questions after a meeting with his South Korean counterpart Cho Sei-young at the Foreign Ministry in Seoul, South Korea, on Nov. 6, 2019.   (Heo Ran/File Photo/Reuters)

## Europol Warns of ‘Grim Outlook’ Regarding ChatGPT
 - [https://www.theepochtimes.com/europol-warns-of-grim-outlook-regarding-chatgpt_5151935.html](https://www.theepochtimes.com/europol-warns-of-grim-outlook-regarding-chatgpt_5151935.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2023-03-27 16:52:44+00:00

A smartphone with a displayed ChatGPT logo sits on a computer motherboard in this illustration taken on Feb. 23, 2023. (Dado Ruvic/Reuters)

## Twitter Source Code Leaked Online, Prompting Lawsuit to Identify Leaker
 - [https://www.theepochtimes.com/twitter-source-code-leaked-online-prompting-lawsuit-to-identify-leaker_5151241.html](https://www.theepochtimes.com/twitter-source-code-leaked-online-prompting-lawsuit-to-identify-leaker_5151241.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2023-03-27 10:27:32+00:00

A Twitter logo hangs outside the company's offices in San Francisco on Dec. 19, 2022. (Jeff Chiu/AP Photo)

## Data of 14 Million Customers Stolen in Cyber Attack
 - [https://www.theepochtimes.com/data-of-14-million-customers-stolen-in-cyber-attack_5150917.html](https://www.theepochtimes.com/data-of-14-million-customers-stolen-in-cyber-attack_5150917.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2023-03-27 03:41:04+00:00

A general view of indoor diners at a restaurant on Chapel Street in Melbourne, Australia on Oct. 22, 2021. (Asanka Ratnayake/Getty Images)

## Directive for Aussie Dating Apps Over Safety Concerns
 - [https://www.theepochtimes.com/directive-for-aussie-dating-apps-over-safety-concerns_5150828.html](https://www.theepochtimes.com/directive-for-aussie-dating-apps-over-safety-concerns_5150828.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2023-03-27 00:48:43+00:00

Dating apps on a mobile phone screen on November 24, 2016 in London, England.  (Leon Neal/Getty Images)

