# Source:NBC tech, URL:https://feeds.nbcnews.com/nbcnews/public/tech, language:en-US

## AI-generated images of Pope Francis in puffer jacket fool the internet
 - [https://www.nbcnews.com/tech/pope-francis-ai-generated-images-fool-internet-rcna76838](https://www.nbcnews.com/tech/pope-francis-ai-generated-images-fool-internet-rcna76838)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2023-03-27 20:17:32+00:00

AI-generated images of Pope Francis blew up on Twitter and fooled scores of users, marking one of the first instances of wide-scale misinformation stemming from AI.

## Nashville Christian School shooting live updates: Three children, two adults pronounced dead
 - [https://www.nbcnews.com/news/us-news/live-blog/nashville-school-shooting-covenant-live-updates-rcna76861](https://www.nbcnews.com/news/us-news/live-blog/nashville-school-shooting-covenant-live-updates-rcna76861)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2023-03-27 17:18:37+00:00

live blog linkout

## Shooting at Nashville Christian school leaves at least 3 children and the gunman dead, officials say
 - [https://www.nbcnews.com/news/us-news/school-shooting-tennessee-leaves-multiple-injured-shooter-dead-officia-rcna76841](https://www.nbcnews.com/news/us-news/school-shooting-tennessee-leaves-multiple-injured-shooter-dead-officia-rcna76841)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2023-03-27 17:03:17+00:00

At least three children are dead after gunfire erupted Monday at a private Christian school in Tennessee, officials said, adding that the gunman was killed by police.

## At least 50 U.S. government employees hit with spyware, White House says
 - [https://www.nbcnews.com/tech/security/least-50-us-government-employees-hit-spyware-white-house-says-rcna76820](https://www.nbcnews.com/tech/security/least-50-us-government-employees-hit-spyware-white-house-says-rcna76820)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2023-03-27 16:58:29+00:00

At least 50 U.S. government employees are suspected or confirmed to have been targeted with commercial spyware that hacks smartphones to spy on their owners, the White House said Monday.

## Found through Google, bought with Visa and Mastercard: Inside the deepfake porn economy
 - [https://www.nbcnews.com/tech/internet/deepfake-porn-ai-mr-deep-fake-economy-google-visa-mastercard-download-rcna75071](https://www.nbcnews.com/tech/internet/deepfake-porn-ai-mr-deep-fake-economy-google-visa-mastercard-download-rcna75071)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2023-03-27 15:56:15+00:00

Deepfake porn made using AI software that takes an existing video and seamlessly replace one person’s face with another’s has taken off online in recent years.

## GOP senators introduce measure to overturn Biden's student debt forgiveness plan
 - [https://www.nbcnews.com/politics/congress/gop-senators-introduce-measure-overturn-bidens-student-debt-forgivenes-rcna76812](https://www.nbcnews.com/politics/congress/gop-senators-introduce-measure-overturn-bidens-student-debt-forgivenes-rcna76812)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2023-03-27 15:05:49+00:00

Republican senators unveiled a proposal to revoke President Joe Biden's executive action last year to forgive some federal student loan debt.

## Trump news live updates: Grand jury to return as potential Trump indictment looms
 - [https://www.nbcnews.com/politics/donald-trump/live-blog/-trump-news-ny-grand-jury-indictment-live-updates-rcna76525](https://www.nbcnews.com/politics/donald-trump/live-blog/-trump-news-ny-grand-jury-indictment-live-updates-rcna76525)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2023-03-27 14:01:27+00:00

linkout

## Ex-Tucker Carlson producer files new claims Fox News lawyers coached her testimony in Dominion lawsuit
 - [https://www.nbcnews.com/politics/politics-news/abby-grossberg-fox-news-lawsuit-new-allegations-dominion-rcna76734](https://www.nbcnews.com/politics/politics-news/abby-grossberg-fox-news-lawsuit-new-allegations-dominion-rcna76734)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2023-03-27 10:00:41+00:00

Abby Grossberg, who sued Fox News last week alleging she was pressured into giving misleading testimony about Fox's election fraud coverage, has filed new allegations about coercive coaching by Fox lawyers.

## U.S., Mexico near deal for Mexico to crack down on fentanyl going north, U.S. to fight guns going south
 - [https://www.nbcnews.com/politics/national-security/fentanyl-gun-smuggling-us-mexico-border-deal-rcna75782](https://www.nbcnews.com/politics/national-security/fentanyl-gun-smuggling-us-mexico-border-deal-rcna75782)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2023-03-27 10:00:00+00:00

The U.S. is preparing to announce a deal in which Mexico cracks down on fentanyl crossing the border north while the U.S. cracks down on guns crossing south.

## Woman framed in ‘rape fantasy’ plot speaks out after conviction of ex-U.S. Marshal
 - [https://www.nbcnews.com/news/woman-framed-rape-fantasy-plot-speaks-conviction-ex-us-marshal-rcna76542](https://www.nbcnews.com/news/woman-framed-rape-fantasy-plot-speaks-conviction-ex-us-marshal-rcna76542)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2023-03-27 10:00:00+00:00

The guilty verdict represents a fresh round of vindication for Michelle Hadley, who spent 88 days in jail as a result of Ian Diaz’s scheme.

## Twitter says parts of its source code were leaked online
 - [https://www.nbcnews.com/news/us-news/twitter-says-parts-source-code-leaked-online-rcna76764](https://www.nbcnews.com/news/us-news/twitter-says-parts-source-code-leaked-online-rcna76764)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2023-03-27 09:38:26+00:00

Some parts of Twitter’s source code — the fundamental computer code on which the social network runs — were leaked online, the social media company said in a legal filing on Sunday.

## First Citizens Bank to buy Silicon Valley Bank deposits and loans
 - [https://www.nbcnews.com/business/business-news/first-citizens-bank-buy-silicon-valley-bank-deposits-loans-rcna76758](https://www.nbcnews.com/business/business-news/first-citizens-bank-buy-silicon-valley-bank-deposits-loans-rcna76758)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2023-03-27 05:35:19+00:00

First Citizens Bank agreed to buy Silicon Valley Bank’s deposits and loans, the U.S.

## Philadelphia rescinds bottled-water alert after chemical spill in the Delaware River
 - [https://www.nbcnews.com/news/us-news/philadelphia-officials-alert-residents-drink-bottled-water-chemical-sp-rcna76736](https://www.nbcnews.com/news/us-news/philadelphia-officials-alert-residents-drink-bottled-water-chemical-sp-rcna76736)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2023-03-27 03:17:34+00:00

Philadelphia officials Sunday afternoon rescinded their recommendation that residents use bottled drinking water after a toxic spill in the Delaware River.

