# Source:NY times technology, URL:http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml, language:en-US

## Lyft Co-Founders to Resign; David Risher Is Named CEO
 - [https://www.nytimes.com/2023/03/27/technology/lyft-founders-resign.html](https://www.nytimes.com/2023/03/27/technology/lyft-founders-resign.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-03-27 21:49:17+00:00

Lyft has been slow to bounce back from early pandemic problems even as the business of its much bigger rival, Uber, has improved.

## Everything to Know About Artificial Intelligence, or AI
 - [https://www.nytimes.com/article/ai-artificial-intelligence-chatbot.html](https://www.nytimes.com/article/ai-artificial-intelligence-chatbot.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-03-27 16:35:59+00:00

Part 1 of our weeklong series.

## Artificial Intelligence Glossary: AI Terms Everyone Should Learn
 - [https://www.nytimes.com/article/ai-artificial-intelligence-glossary.html](https://www.nytimes.com/article/ai-artificial-intelligence-glossary.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-03-27 16:04:04+00:00

The concepts and jargon you need to understand ChatGPT.

## A Sting Operation to Save Elephants, With No Stings
 - [https://www.nytimes.com/2023/03/27/science/elephants-bees-buzzbox.html](https://www.nytimes.com/2023/03/27/science/elephants-bees-buzzbox.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-03-27 15:16:51+00:00

While live bees can be used as a deterrent to keep elephants away from farms, a new technology fills in for cases where a buzz without the sting is preferable.

## Silicon Valley Bank’s Collapse Chills Start-Up Funding
 - [https://www.nytimes.com/2023/03/27/technology/silicon-valley-bank-start-ups.html](https://www.nytimes.com/2023/03/27/technology/silicon-valley-bank-start-ups.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-03-27 12:24:07+00:00

Two weeks after Silicon Valley Bank failed, the fallout has hit the start-up market as investors pull back further and fear has risen.

