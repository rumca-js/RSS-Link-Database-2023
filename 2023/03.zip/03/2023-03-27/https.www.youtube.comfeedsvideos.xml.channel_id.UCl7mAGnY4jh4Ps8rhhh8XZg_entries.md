# Source:Serpentza, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl7mAGnY4jh4Ps8rhhh8XZg, language:en-US

## She Paid 50,000USD to Escape China - Why?
 - [https://www.youtube.com/watch?v=CGNGxUoG6K4](https://www.youtube.com/watch?v=CGNGxUoG6K4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl7mAGnY4jh4Ps8rhhh8XZg
 - date published: 2023-03-27 14:30:05+00:00

Go to https://Surfshark.deals/serpentza and use code serpentza to get 83% off a 2 year plan plus 3 extra months for free!

Illegal border crossings by Chinese nationals has increased 930% Why???

Sources for the clips from Border patrol:
https://twitter.com/GriffJenkins
https://twitter.com/USBPChiefRGV
https://twitter.com/VenturaReport

Join me for the China Show, a weekly dive into what's happening in China: https://www.youtube.com/advpodcasts

And my Secret Show can be found at: http://www.patreon.com/advpodcasts

Support Sasha and I on Patreon: http://www.patreon.com/serpentza
Bitcoin - bc1qxfjp2t6x5dpslv59u0jl89m6k643hcn8h2jsvp
Ethereum - 0x6Da150a2A8529110017Ed4db68B3dF0084900280
Paypal: https://paypal.me/serpentza

DOCUMENTARY LINKS:

Conquering China Boxset SPECIAL:
https://vimeo.com/ondemand/conqueringchinaboxset

Conquering Southern China:
https://vimeo.com/ondemand/conqueringsouthernchina

Conquering Northern China:
https://vimeo.com/ondemand/conqueringnorthernchina

Stay Awesome China (my new documentary): https://vimeo.com/ondemand/stayawesomechina

For Motorcycle adventures around the world, and a talk-show on two wheels go to ADVChina every Monday 1pm EST
https://www.youtube.com/advchina

For a realistic perspective on China and world travel from an American father and a Chinese mother with two half-Chinese daughters go to Laowhy86 every Wednesday 1pm EST
https://youtu.be/mErixa-YIJE

For a no-nonsense on the street look at Chinese culture and beyond from China's original YouTuber, join SerpentZA on Friday at 1pm EST
https://www.youtube.com/serpentza

Join me on Facebook: http://www.facebook.com/winstoninchina
Twitter: @serpentza
Instagram: serpent_za

