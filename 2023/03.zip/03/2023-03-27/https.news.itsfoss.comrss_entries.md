# Source:It's FOSS News, URL:https://news.itsfoss.com/rss/, language:en-US

## Open-Source Model 'Dolly' Claims to be a Cheaper Alternative to ChatGPT
 - [https://news.itsfoss.com/open-source-model-dolly/](https://news.itsfoss.com/open-source-model-dolly/)
 - RSS feed: https://news.itsfoss.com/rss/
 - date published: 2023-03-27 11:27:25+00:00

An affordable alternative to ChatGPT? And, open-source? Looks like we're joining the open-source race against ChatGPT.

## blendOS Aims to Replace All Linux Distributions
 - [https://news.itsfoss.com/blendos/](https://news.itsfoss.com/blendos/)
 - RSS feed: https://news.itsfoss.com/rss/
 - date published: 2023-03-27 04:17:48+00:00

Ubuntu Unity's lead has come up with a new distro that sounds like something everyone might want to keep an eye on.

