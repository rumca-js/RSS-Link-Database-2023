# Source:SomeOrdinaryGamers, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCtMVHI3AJD4Qk4hcbZnI9ZQ, language:en-US

## The Nintendo 3DS/Wii U eShop Died Today...
 - [https://www.youtube.com/watch?v=GK7PskFK1oA](https://www.youtube.com/watch?v=GK7PskFK1oA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtMVHI3AJD4Qk4hcbZnI9ZQ
 - date published: 2023-03-27 22:33:08+00:00

Hello guys and gals, it's me Mutahar again! With Nintendo finally shutting down the eShop today for the Nintendo 3DS and Wii U, the world of game preservation takes a hit and leaves a lot of us wondering how we get to play some of these classics again. Thanks for watching!
Like, Comment and Subscribe for more videos!

Check out the newest Podcast episode: https://youtu.be/ab4VwqGgVkE

