# Source:The Telegraph Business, URL:https://www.telegraph.co.uk/business/rss.xml, language:en-UK

## Gold hits six-month high as traders bet interest rates have peaked - latest updates
 - [https://www.telegraph.co.uk/business/2023/11/27/ftse-100-markets-news-live-gold-price-interest-rates](https://www.telegraph.co.uk/business/2023/11/27/ftse-100-markets-news-live-gold-price-interest-rates)
 - RSS feed: https://www.telegraph.co.uk/business/rss.xml
 - date published: 2023-11-27T07:20:51+00:00



