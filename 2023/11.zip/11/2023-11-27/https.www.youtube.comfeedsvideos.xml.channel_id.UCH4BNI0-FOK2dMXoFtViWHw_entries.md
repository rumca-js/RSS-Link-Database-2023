# Source:Be Smart, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw, language:en-US

## This is why coral reefs are in BIG trouble 😳
 - [https://www.youtube.com/watch?v=x0qavLcoI0g](https://www.youtube.com/watch?v=x0qavLcoI0g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw
 - date published: 2023-11-27T19:34:22+00:00

Another YouTube #shorts from your favorite science dad, Dr. Joe!

Join us on Patreon! 
https://patreon.com/itsokaytobesmart

Instagram 
http://www.instagram.com/DrJoeHanson 
http://www.instagram.com/okaytobesmart

This content is licensed exclusively to YouTube

