# Source:E Poznan, URL:https://epoznan.pl/rss, language:pl-PL

## Szukają tych dwóch mężczyzn. Rozpoznajesz?
 - [https://epoznan.pl/news-news-145406-szukaja_tych_dwoch_mezczyzn_rozpoznajesz?rss=1](https://epoznan.pl/news-news-145406-szukaja_tych_dwoch_mezczyzn_rozpoznajesz?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-11-27T21:30:00+00:00

Sprawa dotyczy kradzieży.

## Pod poznaniem otworzą wielkie i jedyne w Polsce centrum dystrybucji znanej sieci
 - [https://epoznan.pl/news-news-145408-pod_poznaniem_otworza_wielkie_i_jedyne_w_polsce_centrum_dystrybucji_znanej_sieci?rss=1](https://epoznan.pl/news-news-145408-pod_poznaniem_otworza_wielkie_i_jedyne_w_polsce_centrum_dystrybucji_znanej_sieci?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-11-27T21:15:00+00:00

Chodzi o KIK.

## Ogromna inwestycja pod Poznaniem i ogromne korki. &quot;Dramat komunikacyjny&quot;
 - [https://epoznan.pl/news-news-145407-ogromna_inwestycja_pod_poznaniem_i_ogromne_korki_dramat_komunikacyjny?rss=1](https://epoznan.pl/news-news-145407-ogromna_inwestycja_pod_poznaniem_i_ogromne_korki_dramat_komunikacyjny?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-11-27T21:00:00+00:00

Zdaniem kierowców to przez złe ustawienie świateł w Kobylnicy.

## Podczas kontroli wrzucił policjantom plik banknotów do radiowozu
 - [https://epoznan.pl/news-news-145405-podczas_kontroli_wrzucil_policjantom_plik_banknotow_do_radiowozu?rss=1](https://epoznan.pl/news-news-145405-podczas_kontroli_wrzucil_policjantom_plik_banknotow_do_radiowozu?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-11-27T20:30:00+00:00

54-latek może trafić do więzienia na 10 lat.

## &quot;Dómek Szpeniolka&quot; - kolejna znana książka po poznańsku!
 - [https://epoznan.pl/news-news-145404-domek_szpeniolka_kolejna_znana_ksiazka_po_poznansku?rss=1](https://epoznan.pl/news-news-145404-domek_szpeniolka_kolejna_znana_ksiazka_po_poznansku?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-11-27T20:00:00+00:00

Po &quot;Księciu Szaranku&quot; i &quot;Misiu Szpeniolku&quot; nadszedł czas na kolejną książkę przetłumaczoną na gwarę poznańską.

## &quot;Świadek&quot; pozostanie na swoim miejscu - w poznańskim parku
 - [https://epoznan.pl/news-news-145403-swiadek_pozostanie_na_swoim_miejscu_w_poznanskim_parku?rss=1](https://epoznan.pl/news-news-145403-swiadek_pozostanie_na_swoim_miejscu_w_poznanskim_parku?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-11-27T19:30:00+00:00

To topola kanadyjska w Parku Drwęskich

## Pożar zabytkowego budynku i ewakuacja kilkunastu rodzin. Podpalacz chce iść do więzienia na 4 lata
 - [https://epoznan.pl/news-news-145402-pozar_zabytkowego_budynku_i_ewakuacja_kilkunastu_rodzin_podpalacz_chce_isc_do_wiezienia_na_4_lata?rss=1](https://epoznan.pl/news-news-145402-pozar_zabytkowego_budynku_i_ewakuacja_kilkunastu_rodzin_podpalacz_chce_isc_do_wiezienia_na_4_lata?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-11-27T19:03:00+00:00

Decyzję podejmie sąd.

## Nowe muzeum w Poznaniu. Zapowiedziano &quot;drzwi otwarte&quot;
 - [https://epoznan.pl/news-news-145401-nowe_muzeum_w_poznaniu_zapowiedziano_drzwi_otwarte?rss=1](https://epoznan.pl/news-news-145401-nowe_muzeum_w_poznaniu_zapowiedziano_drzwi_otwarte?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-11-27T18:30:00+00:00

To Muzeum Unitra.

## Pojawiała się w jednej drogerii co jakiś czas i nie płaciła. Tak &quot;chciała przechytrzyć mundurowych&quot;
 - [https://epoznan.pl/news-news-145400-pojawiala_sie_w_jednej_drogerii_co_jakis_czas_i_nie_placila_tak_chciala_przechytrzyc_mundurowych?rss=1](https://epoznan.pl/news-news-145400-pojawiala_sie_w_jednej_drogerii_co_jakis_czas_i_nie_placila_tak_chciala_przechytrzyc_mundurowych?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-11-27T18:03:00+00:00

Teraz 28-latka odpowie za swoje zachowanie.

## Niezwykła atrakcja. Na trasę wyjedzie &quot;ryjek&quot; z &quot;kowbojką&quot;.
 - [https://epoznan.pl/news-news-145399-niezwykla_atrakcja_na_trase_wyjedzie_ryjek_z_kowbojka?rss=1](https://epoznan.pl/news-news-145399-niezwykla_atrakcja_na_trase_wyjedzie_ryjek_z_kowbojka?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-11-27T17:30:00+00:00

MPK Poznań na Mikołajki przygotowało dla fanów Maltanki niezwykłą niespodziankę.

## Tragiczny wypadek przy Cytadeli. 25-latka wciąż walczy o życie
 - [https://epoznan.pl/news-news-145398-tragiczny_wypadek_przy_cytadeli_25_latka_wciaz_walczy_o_zycie?rss=1](https://epoznan.pl/news-news-145398-tragiczny_wypadek_przy_cytadeli_25_latka_wciaz_walczy_o_zycie?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-11-27T16:30:00+00:00

Do wypadku doszło w piątkowy wieczór.

## Jest nowy rząd Mateusza Morawieckiego. Poznaniak ministrem spraw zagranicznych
 - [https://epoznan.pl/news-news-145397-jest_nowy_rzad_mateusza_morawieckiego_poznaniak_ministrem_spraw_zagranicznych?rss=1](https://epoznan.pl/news-news-145397-jest_nowy_rzad_mateusza_morawieckiego_poznaniak_ministrem_spraw_zagranicznych?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-11-27T16:03:00+00:00

Mateusz Morawiecki ma dwa tygodnie na zdobycie większości i wotum zaufania w nowym Sejmie.

## Ogromna inwestycja pod Poznaniem. Jeszcze w tym roku samochody przejadą nowym tunelem!
 - [https://epoznan.pl/news-news-145393-ogromna_inwestycja_pod_poznaniem_jeszcze_w_tym_roku_samochody_przejada_nowym_tunelem?rss=1](https://epoznan.pl/news-news-145393-ogromna_inwestycja_pod_poznaniem_jeszcze_w_tym_roku_samochody_przejada_nowym_tunelem?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-11-27T15:30:00+00:00

Prace trwają w Kobylnicy.

## Zaginął 15-latek!
 - [https://epoznan.pl/news-news-145394-zaginal_15_latek?rss=1](https://epoznan.pl/news-news-145394-zaginal_15_latek?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-11-27T15:00:00+00:00

Ostatni raz kontaktował się z bliskimi w piątek.

## Od przyszłego tygodnia uruchomią nowe przystanki
 - [https://epoznan.pl/news-news-145392-od_przyszlego_tygodnia_uruchomia_nowe_przystanki?rss=1](https://epoznan.pl/news-news-145392-od_przyszlego_tygodnia_uruchomia_nowe_przystanki?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-11-27T14:30:00+00:00

Autobusy będą się na nich zatrzymywały od 1 grudnia.

## Uruchomią nowe przystanki. Już za kilka dni
 - [https://epoznan.pl/news-news-145392-uruchomia_nowe_przystanki_juz_za_kilka_dni?rss=1](https://epoznan.pl/news-news-145392-uruchomia_nowe_przystanki_juz_za_kilka_dni?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-11-27T14:30:00+00:00

Autobusy będą się na nich zatrzymywały od 1 grudnia.

## Policjanci szukają mężczyzny. Ze sklepu skradziono towar za ponad 1000 zł
 - [https://epoznan.pl/news-news-145389-policjanci_szukaja_mezczyzny_ze_sklepu_skradziono_towar_za_ponad_1000_zl?rss=1](https://epoznan.pl/news-news-145389-policjanci_szukaja_mezczyzny_ze_sklepu_skradziono_towar_za_ponad_1000_zl?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-11-27T13:55:00+00:00

Do kradzieży doszło w Posnanii.

## Łosie przechadzały się po wielkopolskiej drodze. Leśnicy apelują o ostrożność i tłumaczą, że to ciekawskie zwierzęta
 - [https://epoznan.pl/news-news-145387-losie_przechadzaly_sie_po_wielkopolskiej_drodze_lesnicy_apeluja_o_ostroznosc_i_tlumacza_ze_to_ciekawskie_zwierzeta?rss=1](https://epoznan.pl/news-news-145387-losie_przechadzaly_sie_po_wielkopolskiej_drodze_lesnicy_apeluja_o_ostroznosc_i_tlumacza_ze_to_ciekawskie_zwierzeta?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-11-27T13:40:00+00:00

Niestety, wypadki drogowe z udziałem łosi mogą się skończyć tragicznie.

## Ławniczka przewróciła się w sądzie, wyroku w sprawie śmierci 6-tygodniowej Zuzi w tym roku nie będzie
 - [https://epoznan.pl/news-news-145386-lawniczka_przewrocila_sie_w_sadzie_wyroku_w_sprawie_smierci_6_tygodniowej_zuzi_w_tym_roku_nie_bedzie?rss=1](https://epoznan.pl/news-news-145386-lawniczka_przewrocila_sie_w_sadzie_wyroku_w_sprawie_smierci_6_tygodniowej_zuzi_w_tym_roku_nie_bedzie?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-11-27T13:20:00+00:00

O tej sprawie pisaliśmy na epoznan.pl wielokrotnie.

## Wkrótce rusza Festiwal Prezentów na MTP. To morze inspiracji dla niezdecydowanych
 - [https://epoznan.pl/news-news-145390-wkrotce_rusza_festiwal_prezentow_na_mtp_to_morze_inspiracji_dla_niezdecydowanych?rss=1](https://epoznan.pl/news-news-145390-wkrotce_rusza_festiwal_prezentow_na_mtp_to_morze_inspiracji_dla_niezdecydowanych?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-11-27T13:10:00+00:00

Będzie to okazja do kupienia przedmiotów od rękodzielników i rzemieślników.

## Trwa szał przedświątecznych zakupów. Oszuści już wysyłają SMS-y do Polaków podszywając się pod InPost i Pocztę Polską
 - [https://epoznan.pl/news-news-145382-trwa_szal_przedswiatecznych_zakupow_oszusci_juz_wysylaja_sms_y_do_polakow_podszywajac_sie_pod_inpost_i_poczte_polska?rss=1](https://epoznan.pl/news-news-145382-trwa_szal_przedswiatecznych_zakupow_oszusci_juz_wysylaja_sms_y_do_polakow_podszywajac_sie_pod_inpost_i_poczte_polska?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-11-27T13:00:00+00:00

Trzeba uważać.

## W Poznaniu z dnia na dzień zamknięto przychodnię medyczną. Co z pacjentami?
 - [https://epoznan.pl/news-news-145385-w_poznaniu_z_dnia_na_dzien_zamknieto_przychodnie_medyczna_co_z_pacjentami?rss=1](https://epoznan.pl/news-news-145385-w_poznaniu_z_dnia_na_dzien_zamknieto_przychodnie_medyczna_co_z_pacjentami?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-11-27T12:40:00+00:00

NFZ potwierdza, że doszło do takiej sytuacji.

## Ogromny wyciek wyników badań medycznych tysięcy Polaków. Firma ma wiele punktów w Poznaniu
 - [https://epoznan.pl/news-news-145377-ogromny_wyciek_wynikow_badan_medycznych_tysiecy_polakow_firma_ma_wiele_punktow_w_poznaniu?rss=1](https://epoznan.pl/news-news-145377-ogromny_wyciek_wynikow_badan_medycznych_tysiecy_polakow_firma_ma_wiele_punktow_w_poznaniu?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-11-27T12:20:00+00:00

Zdaniem Zaufanej Trzeciej Strony, to &quot;jeden z najgorszych wycieków danych w historii Polski&quot;.

## 19-latka przyszła do szpitala z noworodkiem. Twierdziła, że znalazła go w lesie. Okazało się, że jest jego matką
 - [https://epoznan.pl/news-news-145384-19_latka_przyszla_do_szpitala_z_noworodkiem_twierdzila_ze_znalazla_go_w_lesie_okazalo_sie_ze_jest_jego_matka?rss=1](https://epoznan.pl/news-news-145384-19_latka_przyszla_do_szpitala_z_noworodkiem_twierdzila_ze_znalazla_go_w_lesie_okazalo_sie_ze_jest_jego_matka?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-11-27T12:00:00+00:00

W Krotoszynie.

## Na poznańskim dworcu kolejowym otwarto sklep Żabka. Drugi znajduje się... tuż obok. W rekordowym dniu sprzedano w nim 270 hot dogów
 - [https://epoznan.pl/news-news-145380-na_poznanskim_dworcu_kolejowym_otwarto_sklep_zabka_drugi_znajduje_sie_tuz_obok_w_rekordowym_dniu_sprzedano_w_nim_270_hot_dogow?rss=1](https://epoznan.pl/news-news-145380-na_poznanskim_dworcu_kolejowym_otwarto_sklep_zabka_drugi_znajduje_sie_tuz_obok_w_rekordowym_dniu_sprzedano_w_nim_270_hot_dogow?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-11-27T11:40:00+00:00

Od przybytku głowa nie boli.

## Pędził mercedesem trasą S5 ponad 200 km/h. To drogowy recydywista
 - [https://epoznan.pl/news-news-145383-pedzil_mercedesem_trasa_s5_ponad_200_kmh_to_drogowy_recydywista?rss=1](https://epoznan.pl/news-news-145383-pedzil_mercedesem_trasa_s5_ponad_200_kmh_to_drogowy_recydywista?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-11-27T11:20:00+00:00

Musi słono zapłacić za swój wyczyn.

## Nie żyje Honorowa Obywatelka Poznania. Jako pierwsza Polka przepłynęła Kanał La Manche
 - [https://epoznan.pl/news-news-145381-nie_zyje_honorowa_obywatelka_poznania_jako_pierwsza_polka_przeplynela_kanal_la_manche?rss=1](https://epoznan.pl/news-news-145381-nie_zyje_honorowa_obywatelka_poznania_jako_pierwsza_polka_przeplynela_kanal_la_manche?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-11-27T11:00:00+00:00

Teresa Zarzeczańska - Różańska miała 77 lat.

## Ciało mężczyzny przy torach kolejowych
 - [https://epoznan.pl/news-news-145379-cialo_mezczyzny_przy_torach_kolejowych?rss=1](https://epoznan.pl/news-news-145379-cialo_mezczyzny_przy_torach_kolejowych?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-11-27T10:20:00+00:00

Znaleziono go w Złotowie.

## Tragiczny wypadek na krajowej &quot;jedenastce&quot;. Droga zablokowana
 - [https://epoznan.pl/news-news-145378-tragiczny_wypadek_na_krajowej_jedenastce_droga_zablokowana?rss=1](https://epoznan.pl/news-news-145378-tragiczny_wypadek_na_krajowej_jedenastce_droga_zablokowana?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-11-27T10:06:00+00:00

Do zdarzenia doszło w powiecie złotowskim.

## Cmentarna hiena zatrzymana w Lesznie. Kradł mosiężne wazony z nagrobków w całym regionie
 - [https://epoznan.pl/news-news-145375-cmentarna_hiena_zatrzymana_w_lesznie_kradl_mosiezne_wazony_z_nagrobkow_w_calym_regionie?rss=1](https://epoznan.pl/news-news-145375-cmentarna_hiena_zatrzymana_w_lesznie_kradl_mosiezne_wazony_z_nagrobkow_w_calym_regionie?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-11-27T09:55:00+00:00

To mieszkaniec województwa lubuskiego.

## Dyrektorka szkoły miała podsłuchiwać pracowników i płacić mężowi, choć w szkole nie pracował. Rusza proces
 - [https://epoznan.pl/news-news-145373-dyrektorka_szkoly_miala_podsluchiwac_pracownikow_i_placic_mezowi_choc_w_szkole_nie_pracowal_rusza_proces?rss=1](https://epoznan.pl/news-news-145373-dyrektorka_szkoly_miala_podsluchiwac_pracownikow_i_placic_mezowi_choc_w_szkole_nie_pracowal_rusza_proces?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-11-27T09:10:00+00:00

Zarzuca się jej więcej czynów.

## Stoją w korkach przy tunelu na Grunwaldzkiej i mają dosyć. Będą zmiany
 - [https://epoznan.pl/news-news-145372-stoja_w_korkach_przy_tunelu_na_grunwaldzkiej_i_maja_dosyc_beda_zmiany?rss=1](https://epoznan.pl/news-news-145372-stoja_w_korkach_przy_tunelu_na_grunwaldzkiej_i_maja_dosyc_beda_zmiany?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-11-27T08:25:00+00:00

Ale czy pomogą?

## Sarna utknęła w bagnie. Uratowali ją strażacy
 - [https://epoznan.pl/news-news-145371-sarna_utknela_w_bagnie_uratowali_ja_strazacy?rss=1](https://epoznan.pl/news-news-145371-sarna_utknela_w_bagnie_uratowali_ja_strazacy?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-11-27T07:45:00+00:00

Do zdarzenia doszło w sobotę w Anastazewie na terenie powiatu konińskiego.

## Rosyjski propagandysta odwiedził nasz kraj. Na poznańskim dworcu zobaczył &quot;polską biedę&quot;
 - [https://epoznan.pl/news-news-145370-rosyjski_propagandysta_odwiedzil_nasz_kraj_na_poznanskim_dworcu_zobaczyl_polska_biede?rss=1](https://epoznan.pl/news-news-145370-rosyjski_propagandysta_odwiedzil_nasz_kraj_na_poznanskim_dworcu_zobaczyl_polska_biede?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-11-27T07:10:00+00:00

Witalij Soczkan z tabloidu &quot;Komsomolskaja Prawda&quot;, opisał jak jego zdaniem wygląda dziś Polska.

## Urządzili na poznańskim jarmarku świątecznym &quot;Januszową wieczerzę wigilijną&quot; z własnym jedzeniem i piciem
 - [https://epoznan.pl/news-news-145369-urzadzili_na_poznanskim_jarmarku_swiatecznym_januszowa_wieczerze_wigilijna_z_wlasnym_jedzeniem_i_piciem?rss=1](https://epoznan.pl/news-news-145369-urzadzili_na_poznanskim_jarmarku_swiatecznym_januszowa_wieczerze_wigilijna_z_wlasnym_jedzeniem_i_piciem?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-11-27T06:35:00+00:00

Na nietypowy pomysł wpadła Młodzież Wszechpolska.

## Nocna interwencja strażaków w bloku. Z kuchenki miał się ulatniać gaz
 - [https://epoznan.pl/news-news-145368-nocna_interwencja_strazakow_w_bloku_z_kuchenki_mial_sie_ulatniac_gaz?rss=1](https://epoznan.pl/news-news-145368-nocna_interwencja_strazakow_w_bloku_z_kuchenki_mial_sie_ulatniac_gaz?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-11-27T06:06:00+00:00

Do zdarzenia doszło około 23.30 w budynku przy Jawornickiej.

