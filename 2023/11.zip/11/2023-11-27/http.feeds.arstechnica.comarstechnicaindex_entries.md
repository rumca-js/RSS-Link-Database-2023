# Source:ArsTechnica, URL:http://feeds.arstechnica.com/arstechnica/index, language:en-US

## New “Stable Video Diffusion” AI model can animate any still image
 - [https://arstechnica.com/?p=1986424](https://arstechnica.com/?p=1986424)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index
 - date published: 2023-11-27T20:28:30+00:00

Given GPU and patience, SVD can turn any image into a 2-second video clip.

## DOS_deck offers free, all-timer DOS games in a browser, with controller support
 - [https://arstechnica.com/?p=1986461](https://arstechnica.com/?p=1986461)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index
 - date published: 2023-11-27T19:50:13+00:00

Playing <em>Warcraft</em> in a browser, using a controller, somehow feels… okay?

## Amazon’s $195 thin clients are repurposed Fire TV Cubes
 - [https://arstechnica.com/?p=1986468](https://arstechnica.com/?p=1986468)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index
 - date published: 2023-11-27T19:32:15+00:00

Amazon Workspaces Thin Client is a Fire TV Cube with different software.

## Big brands keep dropping X over antisemitism; $75M loss, report estimates
 - [https://arstechnica.com/?p=1986523](https://arstechnica.com/?p=1986523)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index
 - date published: 2023-11-27T19:22:48+00:00

Creators worried advertisers dropping X could hurt revenue-sharing payouts.

## Google says bumpy Pixel 8 screens are nothing to worry about
 - [https://arstechnica.com/?p=1986396](https://arstechnica.com/?p=1986396)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index
 - date published: 2023-11-27T19:04:17+00:00

Display "bumps" are screw heads and other components pushing into the OLED panel.

## Researchers figure out how to bypass the fingerprint readers in most Windows PCs
 - [https://arstechnica.com/?p=1986413](https://arstechnica.com/?p=1986413)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index
 - date published: 2023-11-27T18:52:07+00:00

Microsoft's Surface didn't even use the Microsoft-developed security protocol.

## Meta routinely ignored reports of kids under 13 on Instagram, states allege
 - [https://arstechnica.com/?p=1986474](https://arstechnica.com/?p=1986474)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index
 - date published: 2023-11-27T18:35:29+00:00

Newly unredacted suit cites internal documents, including report to Zuckerberg.

## The 2024 Alfa Romeo Tonale is a confoundingly charming plug-in hybrid
 - [https://arstechnica.com/?p=1986441](https://arstechnica.com/?p=1986441)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index
 - date published: 2023-11-27T17:16:29+00:00

Faults that should have been frustrating just seem to add character when it's an Alfa.

## Study: The serotine bat uses its super-large penis as an arm when mating
 - [https://arstechnica.com/?p=1985239](https://arstechnica.com/?p=1985239)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index
 - date published: 2023-11-27T16:45:24+00:00

Further research involves building a "bat porn box" to catch more mating acts on camera.

## “Tasmanian Devil” event has the power of hundreds of billions of Suns
 - [https://arstechnica.com/?p=1986340](https://arstechnica.com/?p=1986340)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index
 - date published: 2023-11-27T16:21:05+00:00

We don't really know what can cause repeated outbursts of this sort.

## Complex, volatile coast makes preparing for tsunamis tough in Alaska
 - [https://arstechnica.com/?p=1986389](https://arstechnica.com/?p=1986389)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index
 - date published: 2023-11-27T14:42:05+00:00

Educating local residents about the risks carries challenges.

## Cyber Monday 2023: The best deals on Lenovo, Herman Miller, Apple, Anker, Dyson, and more
 - [https://arstechnica.com/?p=1986369](https://arstechnica.com/?p=1986369)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index
 - date published: 2023-11-27T12:30:03+00:00

Cyber Week is here, and these are the best deals on Apple, Dyson, Lenovo, Vitamix, and more.

