# Source:Aljazeera, URL:https://www.aljazeera.com/xml/rss/all.xml, language:en-US

## US rights advocates launch hunger strike for Israel-Hamas ceasefire
 - [https://www.aljazeera.com/news/2023/11/27/us-rights-advocates-launch-hunger-strike-for-israel-hamas-ceasefire?traffic_source=rss](https://www.aljazeera.com/news/2023/11/27/us-rights-advocates-launch-hunger-strike-for-israel-hamas-ceasefire?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-11-27T22:23:53+00:00

Actor Cynthia Nixon joins activists and state legislators outside White House in protest against US backing of Gaza war.

## Hamas releases 11 more captives from Gaza, Israeli army says
 - [https://www.aljazeera.com/news/2023/11/27/hamas-releases-11-more-captives-from-gaza-israeli-army-says?traffic_source=rss](https://www.aljazeera.com/news/2023/11/27/hamas-releases-11-more-captives-from-gaza-israeli-army-says?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-11-27T21:06:41+00:00

Release comes after mediator Qatar says Israel-Hamas truce in Gaza extended by two days.

## Twenty killed in Sierra Leone attack on military barracks, army says
 - [https://www.aljazeera.com/news/2023/11/27/sierra-leone-says-20-people-killed-in-weekend-attack-on-military-barracks?traffic_source=rss](https://www.aljazeera.com/news/2023/11/27/sierra-leone-says-20-people-killed-in-weekend-attack-on-military-barracks?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-11-27T20:33:03+00:00

President says most of the leaders arrested after attack on military barracks and prisons in the West African nation.

## Can a divided EU have any meaningful policy on Gaza?
 - [https://www.aljazeera.com/program/inside-story/2023/11/27/can-a-divided-eu-have-any-meaningful-policy-on-gaza?traffic_source=rss](https://www.aljazeera.com/program/inside-story/2023/11/27/can-a-divided-eu-have-any-meaningful-policy-on-gaza?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-11-27T20:23:43+00:00

Member states at odds, some supporting Israel, others opposing its war against Hamas in Gaza.

## Palestinian killed after Israel prevents medics from helping him
 - [https://www.aljazeera.com/program/newsfeed/2023/11/27/palestinian-killed-after-israel-prevents-medics-from-helping-him?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2023/11/27/palestinian-killed-after-israel-prevents-medics-from-helping-him?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-11-27T20:01:18+00:00

A mother recalls her son’s killing after Israeli forces raided their home and prevented an ambulance from reaching him.

## US says Somali pirates likely behind attempted tanker seizure near Yemen
 - [https://www.aljazeera.com/news/2023/11/27/us-says-somali-pirates-likely-behind-attempted-tanker-seizure-near-yemen?traffic_source=rss](https://www.aljazeera.com/news/2023/11/27/us-says-somali-pirates-likely-behind-attempted-tanker-seizure-near-yemen?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-11-27T19:00:49+00:00

The Pentagon has said that the attempted hijacking was likely the work of Somali pirates rather than Houthi fighters.

## ‘We want permanent ceasefire,’ Palestinians in Gaza say as truce extended
 - [https://www.aljazeera.com/features/2023/11/27/we-want-permanent-ceasefire-palestinians-in-gaza-say-as-truce-extended?traffic_source=rss](https://www.aljazeera.com/features/2023/11/27/we-want-permanent-ceasefire-palestinians-in-gaza-say-as-truce-extended?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-11-27T17:31:56+00:00

Four-day pause has quietened the skies over Gaza but has shone a light on the suffering of displaced Palestinians.

## Israel-Hamas truce in Gaza extended by two days, says mediator Qatar
 - [https://www.aljazeera.com/news/2023/11/27/israel-hamas-truce-in-gaza-extended-by-two-days-says-mediator-qatar?traffic_source=rss](https://www.aljazeera.com/news/2023/11/27/israel-hamas-truce-in-gaza-extended-by-two-days-says-mediator-qatar?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-11-27T17:31:48+00:00

Hamas official tells Al Jazeera the group hopes to extend the truce even further and put an end to the war.

## Photos: Empty towns to sea laundry: How war has changed Israel, Palestine
 - [https://www.aljazeera.com/gallery/2023/11/27/photos-empty-towns-to-sea-laundry-how-war-has-changed-israel-palestine?traffic_source=rss](https://www.aljazeera.com/gallery/2023/11/27/photos-empty-towns-to-sea-laundry-how-war-has-changed-israel-palestine?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-11-27T16:57:45+00:00

From border towns in Israel to devastated cities in Gaza and harassed Palestinians in Jerusalem, nothing is the same.

## Mountain villages fight for future as melting glaciers spell floods
 - [https://www.aljazeera.com/gallery/2023/11/27/mountain-villages-fight-for-future-as-melting-glaciers-spell?traffic_source=rss](https://www.aljazeera.com/gallery/2023/11/27/mountain-villages-fight-for-future-as-melting-glaciers-spell?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-11-27T16:51:48+00:00

Fifteen million people worldwide are at risk of glacial lake flooding, with two million of them in Pakistan.

## A ceasefire in a time of genocide
 - [https://www.aljazeera.com/opinions/2023/11/27/a-ceasefire-in-a-time-of-genocide?traffic_source=rss](https://www.aljazeera.com/opinions/2023/11/27/a-ceasefire-in-a-time-of-genocide?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-11-27T15:49:32+00:00

The people of Gaza will not settle for anything short of the end of the siege, the occupation and apartheid.

## ‘Our only outlet’: Palestinians in Gaza go to the beach during truce
 - [https://www.aljazeera.com/gallery/2023/11/27/palestinians-in-gaza-go-to-the-beach?traffic_source=rss](https://www.aljazeera.com/gallery/2023/11/27/palestinians-in-gaza-go-to-the-beach?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-11-27T15:44:07+00:00

After a month and a half of a devastating war on Gaza Strip, residents take to the beach to relieve tensions and stress.

## At least three killed as storm hits Russia, Ukraine’s Black Sea coast
 - [https://www.aljazeera.com/news/2023/11/27/at-least-three-killed-as-storm-hits-russia-ukraines-black-sea-coast?traffic_source=rss](https://www.aljazeera.com/news/2023/11/27/at-least-three-killed-as-storm-hits-russia-ukraines-black-sea-coast?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-11-27T15:30:45+00:00

Hundreds of thousands of people without power as fierce storm devastates infrastructure.

## Fact or Fiction: The propaganda war won’t stop, even during a truce
 - [https://www.aljazeera.com/opinions/2023/11/27/fact-or-fiction-the-propaganda-war-wont-stop-even-during-a-truce?traffic_source=rss](https://www.aljazeera.com/opinions/2023/11/27/fact-or-fiction-the-propaganda-war-wont-stop-even-during-a-truce?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-11-27T14:41:21+00:00

That includes a war on diplomacy itself, amid the competing propaganda interests of Hamas and Netanyahu.

## Lorries line up at Poland-Ukraine border as truckers expand blockade
 - [https://www.aljazeera.com/news/2023/11/27/lorries-line-up-at-poland-ukraine-border-as-truckers-expand-blockade?traffic_source=rss](https://www.aljazeera.com/news/2023/11/27/lorries-line-up-at-poland-ukraine-border-as-truckers-expand-blockade?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-11-27T14:12:49+00:00

Polish truckers and farmers are staging an around-the-clock blockade of the southeastern Medyka crossing.

## French court opens case against teens over beheading of teacher
 - [https://www.aljazeera.com/news/2023/11/27/six-teens-in-court-in-connection-with-beheading-of-french-teacher?traffic_source=rss](https://www.aljazeera.com/news/2023/11/27/six-teens-in-court-in-connection-with-beheading-of-french-teacher?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-11-27T13:41:33+00:00

The teacher was killed in 2020 outside his school in Paris, after sharing cartoons of Prophet Muhammad in class.

## People in Gaza are still in ‘desperate’ need, despite truce
 - [https://www.aljazeera.com/program/newsfeed/2023/11/27/people-in-gaza-are-still-in-desperate-need-despite-truce?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2023/11/27/people-in-gaza-are-still-in-desperate-need-despite-truce?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-11-27T13:13:32+00:00

A UN official has described seeing thin and thirsty Palestinians “desperate” for aid as his team delivered supplies.

## India rescuers dig by hand to free 41 tunnel workers trapped for weeks
 - [https://www.aljazeera.com/news/2023/11/27/india-rescuers-dig-by-hand-to-free-41-tunnel-workers-trapped-for-weeks?traffic_source=rss](https://www.aljazeera.com/news/2023/11/27/india-rescuers-dig-by-hand-to-free-41-tunnel-workers-trapped-for-weeks?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-11-27T12:58:10+00:00

&#039;Rat miners&#039; to drill through pipe to pull out workers trapped in Himalayan tunnel after high-powered machines fail.

## Grief to courage: A Palestinian stranded in Egypt as Israel bombs Gaza
 - [https://www.aljazeera.com/features/2023/11/27/grief-to-courage-a-palestinian-stranded-in-egypt-as-israel-bombs-gaza?traffic_source=rss](https://www.aljazeera.com/features/2023/11/27/grief-to-courage-a-palestinian-stranded-in-egypt-as-israel-bombs-gaza?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-11-27T12:55:42+00:00

Mohammed Kafarna spoke to Al Jazeera over two months of being trapped in Egypt, despairing as friends died, family fled.

## Another Roma boy dies in police chase, marking grim pattern in Greece
 - [https://www.aljazeera.com/news/2023/11/27/death-of-another-roma-boy-in-greece?traffic_source=rss](https://www.aljazeera.com/news/2023/11/27/death-of-another-roma-boy-in-greece?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-11-27T12:39:19+00:00

Greece&#039;s Roma minority demands answers after Christos Michalopoulos, 17, died while being pursued by police.

## Elon Musk in Israel to discuss Starlink, anti-Semitism
 - [https://www.aljazeera.com/news/2023/11/27/elon-musk-arrives-in-israel-flight-tracker?traffic_source=rss](https://www.aljazeera.com/news/2023/11/27/elon-musk-arrives-in-israel-flight-tracker?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-11-27T12:27:49+00:00

Israeli leaders Netanyahu and Herzog will emphasise to the billionaire the plight of captives held in Gaza.

## Mozambique to present new $80bn energy transition plan at COP28
 - [https://www.aljazeera.com/news/2023/11/27/mozambique-to-present-new-80bn-energy-transition-plan-at-cop28?traffic_source=rss](https://www.aljazeera.com/news/2023/11/27/mozambique-to-present-new-80bn-energy-transition-plan-at-cop28?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-11-27T12:17:43+00:00

President Nyusi is expected to officially present the energy strategy to the international community during COP28.

## New probe over vanished Malaysia Airlines plane urged in China court
 - [https://www.aljazeera.com/news/2023/11/27/families-urge-renewed-quest-for-answers-in-2014-malaysia-airlines-crash?traffic_source=rss](https://www.aljazeera.com/news/2023/11/27/families-urge-renewed-quest-for-answers-in-2014-malaysia-airlines-crash?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-11-27T11:37:27+00:00

Nearly a decade after the plane vanished, families say it is time for a new hunt for the truth.

## Biden reportedly ignored staff caution on ‘beheaded Israeli babies’
 - [https://www.aljazeera.com/news/2023/11/27/biden-ignored-staff-warning-on-hamas-beheading-babies-claim-report?traffic_source=rss](https://www.aljazeera.com/news/2023/11/27/biden-ignored-staff-warning-on-hamas-beheading-babies-claim-report?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-11-27T11:35:00+00:00

The report gives account of divisions inside the White House over the unverified claim.

## Happily, Joe Biden is finished
 - [https://www.aljazeera.com/opinions/2023/11/27/happily-joe-biden-is-finished?traffic_source=rss](https://www.aljazeera.com/opinions/2023/11/27/happily-joe-biden-is-finished?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-11-27T11:21:36+00:00

Biden’s stubborn support for Israel&#039;s war on Gaza have not only offended but also infuriated crucial constituencies.

## Three Palestinian students aged 20 shot in Vermont, US: What to know
 - [https://www.aljazeera.com/news/2023/11/27/three-palestinian-students-aged-20-shot-injured-in-vermont-what-to-know?traffic_source=rss](https://www.aljazeera.com/news/2023/11/27/three-palestinian-students-aged-20-shot-injured-in-vermont-what-to-know?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-11-27T10:55:35+00:00

According to police the victims were speaking Arabic and two were wearing keffiyehs when attacked in Burlington.

## Lightning strikes in India’s Gujarat kill 24, more rains predicted
 - [https://www.aljazeera.com/news/2023/11/27/lightning-strikes-in-indias-gujarat-kill-24-more-rains-predicted?traffic_source=rss](https://www.aljazeera.com/news/2023/11/27/lightning-strikes-in-indias-gujarat-kill-24-more-rains-predicted?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-11-27T10:37:10+00:00

Gujarat is not unfamiliar with rain-related calamities but big rainstorms are not expected there during winter months.

## Vermont police arrest suspect in ‘hate-motivated’ shooting of Palestinians
 - [https://www.aljazeera.com/news/2023/11/27/suspect-apprehended-in-us-shooting-of-3-palestinian-students?traffic_source=rss](https://www.aljazeera.com/news/2023/11/27/suspect-apprehended-in-us-shooting-of-3-palestinian-students?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-11-27T10:36:38+00:00

The three victims of the attack in the US remain hospitalised with multiple gunshot wounds after &#039;chilling&#039; attack.

## Israel, Hamas and the toil of the prisoner exchange
 - [https://www.aljazeera.com/gallery/2023/11/27/israel-hamas-and-the-toil-of-the-prisoner-exchange?traffic_source=rss](https://www.aljazeera.com/gallery/2023/11/27/israel-hamas-and-the-toil-of-the-prisoner-exchange?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-11-27T10:16:11+00:00

The latest prisoner exchange, while promising, is only the start to what is expected to be a long, difficult negotiation

## Diplomatic dash as end of Israel-Gaza truce looms
 - [https://www.aljazeera.com/news/2023/11/27/biden-hopes-for-extension-of-israel-hamas-truce-as-more-hostages-released?traffic_source=rss](https://www.aljazeera.com/news/2023/11/27/biden-hopes-for-extension-of-israel-hamas-truce-as-more-hostages-released?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-11-27T10:09:46+00:00

The US, China and others push to extend the pause as Israel and Hamas express their conditions.

## Russia’s bid to arrest Meta spokesperson revealed amid media crackdown
 - [https://www.aljazeera.com/news/2023/11/27/meta-spokesman-andy-stone-placed-on-russian-wanted-list?traffic_source=rss](https://www.aljazeera.com/news/2023/11/27/meta-spokesman-andy-stone-placed-on-russian-wanted-list?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-11-27T08:59:22+00:00

Andy Stone has reportedly been wanted on unspecified criminal charges since last year.

## Israel-Hamas war: List of key events, day 52
 - [https://www.aljazeera.com/news/2023/11/27/israel-hamas-war-list-of-key-events-day-52?traffic_source=rss](https://www.aljazeera.com/news/2023/11/27/israel-hamas-war-list-of-key-events-day-52?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-11-27T08:33:51+00:00

As the truce enters its final day and attacks on Palestinians continue in the West Bank, here are the major updates.

## Israel-Palestine conflict: A brief history in maps and charts
 - [https://www.aljazeera.com/news/2023/11/27/palestine-and-israel-brief-history-maps-and-charts?traffic_source=rss](https://www.aljazeera.com/news/2023/11/27/palestine-and-israel-brief-history-maps-and-charts?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-11-27T07:38:47+00:00

As Gaza reels from Israel&#039;s devastating bombardments, here&#039;s a brief history of the conflict using maps and charts.

## Analysis: Less than a day left on the Gaza pause, what are the prospects?
 - [https://www.aljazeera.com/news/2023/11/27/analysis-less-than-a-day-left-on-the-gaza-pause-what-are-the-prospects?traffic_source=rss](https://www.aljazeera.com/news/2023/11/27/analysis-less-than-a-day-left-on-the-gaza-pause-what-are-the-prospects?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-11-27T07:36:32+00:00

After a tense delay on Saturday, the pause seems to be holding. Will Israel and Hamas agree to extend it?

## Palestinians welcome third set of prisoners in Gaza truce deal
 - [https://www.aljazeera.com/program/newsfeed/2023/11/27/palestinians-welcome-third-set-of-prisoners-in-gaza-truce-deal?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2023/11/27/palestinians-welcome-third-set-of-prisoners-in-gaza-truce-deal?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-11-27T07:34:12+00:00

Palestinian families gathered to celebrate the third batch of 39 Palestinian prisoners freed.

## US Navy thwarts seizure of Israel-linked cargo ship
 - [https://www.aljazeera.com/news/2023/11/27/us-navy-thwarts-attempted-seizure-of-israel-linked-cargo-ship?traffic_source=rss](https://www.aljazeera.com/news/2023/11/27/us-navy-thwarts-attempted-seizure-of-israel-linked-cargo-ship?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-11-27T07:06:49+00:00

The destroyer USS Mason responded to a distress call from an Israel-linked commercial tanker in the Gulf of Aden.

## An unexpected friendship: The graveyard keeper and the polio survivor
 - [https://www.aljazeera.com/features/2023/11/27/an-unexpected-friendship-the-graveyard-keeper-and-the-polio-survivor?traffic_source=rss](https://www.aljazeera.com/features/2023/11/27/an-unexpected-friendship-the-graveyard-keeper-and-the-polio-survivor?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-11-27T07:03:10+00:00

In Lampedusa, two longtime friends observe the refugee crisis close-up and discuss the value of human life.

## Barbeques, suspicion and song as Israeli soldiers break from Gaza war
 - [https://www.aljazeera.com/features/2023/11/27/barbeques-suspicion-and-song-as-israeli-soldiers-break-from-gaza-war?traffic_source=rss](https://www.aljazeera.com/features/2023/11/27/barbeques-suspicion-and-song-as-israeli-soldiers-break-from-gaza-war?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-11-27T06:51:49+00:00

Reservists come back to southern Israel, welcomed by families, feasts and distant explosions.

## Palestinians gather in Ramallah streets to welcome freed prisoners
 - [https://www.aljazeera.com/gallery/2023/11/27/palestinians-gather-in-ramallah-streets-to-welcome-freed-prisoners?traffic_source=rss](https://www.aljazeera.com/gallery/2023/11/27/palestinians-gather-in-ramallah-streets-to-welcome-freed-prisoners?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-11-27T06:50:05+00:00

The exchange of captives for prisoners between Hamas and Israel continued for a third day on Sunday.

## Al Nassr vs Persepolis – AFC Champions League Group E match preview
 - [https://www.aljazeera.com/sports/2023/11/27/al-nassr-vs-persepolis-afc-champions-league-match-preview-cristiano-ronaldo-to-play-iran-saudi-arabia-football-riyadh-group-e?traffic_source=rss](https://www.aljazeera.com/sports/2023/11/27/al-nassr-vs-persepolis-afc-champions-league-match-preview-cristiano-ronaldo-to-play-iran-saudi-arabia-football-riyadh-group-e?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-11-27T05:27:00+00:00

Ronaldo is set to play for Saudi club Al Nassr as they host Iran&#039;s Persepolis FC for their AFC Champions League match.

## Volunteer recalls final hours at Indonesian Hospital amid Israeli siege
 - [https://www.aljazeera.com/news/2023/11/27/volunteer-calls-final-hours-at-indonesian-hospital-amid-israeli-siege?traffic_source=rss](https://www.aljazeera.com/news/2023/11/27/volunteer-calls-final-hours-at-indonesian-hospital-amid-israeli-siege?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-11-27T04:32:07+00:00

Volunteer medical worker Fikri Rofiul Haq says lsraeli tanks repeatedly fired on hospital in northern Gaza.

