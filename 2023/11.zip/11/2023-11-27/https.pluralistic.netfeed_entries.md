# Source:Pluralistic: Daily links from Cory Doctorow, URL:https://pluralistic.net/feed, language:en-US

## Pluralistic: The real AI fight (27 Nov 2023)
 - [https://pluralistic.net/2023/11/27/10-types-of-people](https://pluralistic.net/2023/11/27/10-types-of-people)
 - RSS feed: https://pluralistic.net/feed
 - date published: 2023-11-27T13:16:23+00:00

Today's links The real AI fight: Effective Accelerationists and Effective Altruists are both in vigorous agreement about something genuinely stupid. Hey look at this: Delights to delectate. This day in history: 2003, 2008, 2013, 2018, 2022 Colophon: Recent publications, upcoming/recent appearances, current writing projects, current reading The real AI fight (permalink) Last week's spectacular OpenAI soap-opera hijacked the attention of millions of normal, productive people and nonsensually crammed them full of the fine details of the debate between "Effective Altruism" (doomers) and "Effective Accelerationism" (AKA e/acc), a genuinely absurd debate that was allegedly at the center of the drama. Very broadly speaking: the Effective Altruists are doomers, who believe that Large Language Models (AKA "spicy autocomplete") will someday become so advanced that it could wake up and annihilate or enslave the human race. To prevent this, we need to employ "AI Safety" &#8211; measures that wil

