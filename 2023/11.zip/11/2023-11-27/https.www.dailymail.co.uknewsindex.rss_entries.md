# Source:Daily Mail, URL:https://www.dailymail.co.uk/news/index.rss, language:en-US

## Biden slammed for bragging he is bringing prices down - even though they are UP since he entered office: President launches bid to take credit despite the majority of Americans disapproving of his economic record
 - [https://www.dailymail.co.uk/news/article-12797659/Biden-prices-groceries-slammed-Thanksgiving-inflation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12797659/Biden-prices-groceries-slammed-Thanksgiving-inflation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T23:20:14+00:00

President Joe Biden on Monday touted his administration's success in bringing down the price of gas, groceries and airline tickets during the past year but received little thanks for his efforts.

## Mother of alleged bathtub murder victim speaks out about daughter's boyfriend  - as grisly details emerge about her 43-year-old daughter's body being found packed in frozen food bags
 - [https://www.dailymail.co.uk/news/article-12797433/Mother-alleged-bathtub-murder-victim-Catiusca-Machada-breaks-silence-reveals-fresh-details-life-dead-Chiswick-Sydney-apartment.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12797433/Mother-alleged-bathtub-murder-victim-Catiusca-Machada-breaks-silence-reveals-fresh-details-life-dead-Chiswick-Sydney-apartment.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T23:20:11+00:00

The mother of the woman who died in the alleged bathtub murder has spoken out from Brazil about her daughter's accused killer, as grisly details emerge about the young woman's remains.

## Importing disposable vapes to be banned in Australia from next year
 - [https://www.dailymail.co.uk/news/article-12797707/Importing-disposable-vapes-banned-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12797707/Importing-disposable-vapes-banned-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T23:17:32+00:00

It is one of a number of measures set for 2024 aiming to make Australia the first country in the world to restrict vapes containing nicotine to only people with a valid prescription.

## James Cleverly backtracks after playing down the Rwanda asylum scheme, calling it a 'key element' of plans to tackle the Channel crisis
 - [https://www.dailymail.co.uk/news/article-12797793/James-Cleverly-backtracks-playing-Rwanda-asylum-scheme-calling-key-element-plans-tackle-Channel-crisis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12797793/James-Cleverly-backtracks-playing-Rwanda-asylum-scheme-calling-key-element-plans-tackle-Channel-crisis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T23:15:26+00:00

The Home Secretary told MPs the programme was 'incredibly important', despite saying at the weekend that the plan was 'not the be-all and end-all' of the Government's efforts to tackle the issue.

## Washington mom reveals horrifying agony waiting for cops to locate missing 14-year-old Emma Liudahl after an Amber Alert is issued
 - [https://www.dailymail.co.uk/news/article-12797171/Washington-state-amber-alert-14-Emma-Liudhal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12797171/Washington-state-amber-alert-14-Emma-Liudhal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T23:13:35+00:00

A 14-year-old girl from Washington State believed to have been taken by a 35-year-old man has been found safe in Seattle, police confirmed.

## Trump insists he has NEVER attacked the judge in his fraud trial (even though he called him 'crazy' and 'unhinged') and demands an end to the gag order - as it's revealed he'll take the stand AGAIN in his own defense
 - [https://www.dailymail.co.uk/news/article-12797591/Trump-insists-NEVER-attacked-judge-clerk-fraud-trial-demands-end-gag-order-executives-tell-court-stopped-writing-financial-statements-central-New-Yorks-case.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12797591/Trump-insists-NEVER-attacked-judge-clerk-fraud-trial-demands-end-gag-order-executives-tell-court-stopped-writing-financial-statements-central-New-Yorks-case.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T23:13:19+00:00

Lawyers for Donald Trump want to keep a judge's 'gag' order against him from being in effect - and say he can't be blamed for 'hostile or offensive' speech by others.

## All the bombshells from Omid Scobie's new book Endgame: from taking aim at 'cold' to Kate, Harry and William's 'irreparable' rift
 - [https://www.dailymail.co.uk/news/article-12797059/omid-scobie-book-endgame-bombshells.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12797059/omid-scobie-book-endgame-bombshells.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T23:12:53+00:00

The author, who is a close confidant of the Duke and Duchess of Sussex, is set to release his latest work, Endgame, about the Royal Family on Tuesday in Britain.

## REVEALED: Texas spent a staggering $86.1 MILLION busing migrants to New York City, Chicago, Philadelphia, Los Angeles, Washington DC, Denver at a cost of $1,650 per migrant
 - [https://www.dailymail.co.uk/news/article-12796675/Texas-spent-whooping-86-1-MILLION-busing-migrants-away-border-New-York-Chicago-Philadelphia-Los-Angeles-Washington-DC-Denver-cost-1-650-migrant-taxpayer-donated-funds.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12796675/Texas-spent-whooping-86-1-MILLION-busing-migrants-away-border-New-York-Chicago-Philadelphia-Los-Angeles-Washington-DC-Denver-cost-1-650-migrant-taxpayer-donated-funds.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T23:08:45+00:00

Texas has spent more than $86M dollars busing migrants to self-declared sanctuary cities that claimed to welcome migrants with open arms - until they changed their tune.

## Markle vs. Markle! Meghan faces defamation trial after half-sister Samantha claimed she was defamed in order to 'cover up' her 'false rags-to-riches' narrative
 - [https://www.dailymail.co.uk/news/article-12796943/Meghan-Markle-trial-date-Samantha-Oprah-child-Tampa.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12796943/Meghan-Markle-trial-date-Samantha-Oprah-child-Tampa.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T23:08:34+00:00

Samantha, 59, claims Meghan defamed her when she said in her Oprah Winfrey interview that she had grown up an only child.

## Ex-boyfriend of Real Housewives of New York City star Luann de Lesseps is sued by New York Times reporter who claims the celebrity trainer plied her with alcohol and raped her in the Hamptons in 2001 when she was 18 and he was 31
 - [https://www.dailymail.co.uk/news/article-12797607/luann-lesseps-ex-boyfriend-garth-wakeford-rape-sarah-maslin-nir-hamptons.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12797607/luann-lesseps-ex-boyfriend-garth-wakeford-rape-sarah-maslin-nir-hamptons.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T23:08:16+00:00

Garth Wakeford, a South African personal trainer, briefly dated reality TV star Luann de Lesseps. He is accused in a new lawsuit of raping a woman in 2001 on the beach in the Hamptons.

## Baby died after midwives missed her mother's blood loss while relying on telephone assessments, report finds
 - [https://www.dailymail.co.uk/news/article-12797569/Baby-died-midwives-missed-mothers-blood-loss-relying-telephone-assessments-report-finds.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12797569/Baby-died-midwives-missed-mothers-blood-loss-relying-telephone-assessments-report-finds.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T23:03:03+00:00

Baby Abigail Miller died 48 hours after being born as her mother, Katie Fowler, 37, went into cardiac arrest. Now she and her husband are calling for an inquiry into England's maternity services

## Brazilian baby who went viral seconds after she was born by frowning at doctor is now a 'smart, affectionate and intelligent' 3-year-old girl
 - [https://www.dailymail.co.uk/news/article-12797231/Viral-baby-frowning-doctor-3-years-old.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12797231/Viral-baby-frowning-doctor-3-years-old.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T22:52:32+00:00

The newborn who became a social media meme when she frowned at a doctor moments after she was delivered in the operation room is all grown up now.

## Single father devastated after daughter's NDIS funding is suddenly slashed - and he has no idea why
 - [https://www.dailymail.co.uk/news/article-12791915/Single-father-Peter-Voelker-NDIS-funding-slashed-daughter-Canberra.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12791915/Single-father-Peter-Voelker-NDIS-funding-slashed-daughter-Canberra.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T22:38:28+00:00

Father Peter Voelker has been left shocked after NDIS funding for his daughter Ellie, who lives with severe disabilities, was cut by $26,000, forcing him to cancel some of her vital treatment.

## Pepsi fans are left mind blown after realizing the secret meaning behind the popular soft drink's name
 - [https://www.dailymail.co.uk/news/article-12797085/Pepsi-meaning-shocking.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12797085/Pepsi-meaning-shocking.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T22:30:23+00:00

The meaning of Pepsi goes way beyond a fizzy drink that provides an energy boost. Here is the surprising meaning behind the company's name.

## That rocks! Huge 115-million-year-old fossil which weighs at least 24 stone is found in a fallen boulder on the Isle of Wight
 - [https://www.dailymail.co.uk/news/article-12797527/115-million-fossil-24-stone-Isle-Wight.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12797527/115-million-fossil-24-stone-Isle-Wight.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T22:22:30+00:00

Jack Wonfor, 23, recovered the epicheloniceras ammonite weighing in at 24 stone, an enormous shelled creature as big as a car wheel, on the Isle of Wight

## Broadmeadows, Melbourne: Gunman on the run after man was shot
 - [https://www.dailymail.co.uk/news/article-12797447/Broadmeadows-Melbourne-man-shot.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12797447/Broadmeadows-Melbourne-man-shot.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T22:21:43+00:00

A gunman is on the loose in Melbourne's north after a young man was shot while reportedly trying to run down a group of people.

## Bruce Lehrmann admits he has mysteriously fallen out with two of his closest mates - as he braces for fresh grilling
 - [https://www.dailymail.co.uk/news/article-12797349/bruce-lehrmann-news-Brittany-higgins-defamation-trial-live.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12797349/bruce-lehrmann-news-Brittany-higgins-defamation-trial-live.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T22:20:42+00:00

DAILY MAIL AUSTRALIA LIVE BLOG: Bruce Lehrmann's defamation case against Network 10 is being heard in the Federal Court.

## Shocking moment woman is robbed by rifle-wielding gang on busy Chicago street - before suspects stick up three other people and cops REFUSED to follow them
 - [https://www.dailymail.co.uk/news/article-12797245/Chicago-robbery-rifle-woman-video-police-suspects.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12797245/Chicago-robbery-rifle-woman-video-police-suspects.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T22:20:19+00:00

This is the shocking moment a woman was robbed in Chicago by a rifle-wielding gang before they robbed three others. A total of 20 armed robberies were reported on Sunday in Chicago.

## Paedophile teacher who abducted 15-year-old schoolgirl and fled to France is fired from his new job at a Kent bakery after employers learn about his 'sensitive history'
 - [https://www.dailymail.co.uk/news/article-12797423/Paedophile-teacher-abducted-schoolgirl-France-fired-Kent-bakery-sensitive-history.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12797423/Paedophile-teacher-abducted-schoolgirl-France-fired-Kent-bakery-sensitive-history.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T22:19:48+00:00

Gilda Bakery in Canterbury announced that it has terminated his employment 'with immediate effect', adding that the revelations came 'as a shock' to the 'close-knit team'.

## Mysterious 'witch bottles' appear along the Gulf of Mexico - and researchers are avoiding opening them
 - [https://www.dailymail.co.uk/news/article-12796721/Gulf-Mexico-Witch-Bottles-open.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12796721/Gulf-Mexico-Witch-Bottles-open.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T22:11:23+00:00

A researcher fears opening up some of his witchy artifacts found  along the Gulf of Mexico. The bottle get their name as they come from an unknown sender and often have weird items inside.

## Disneyland employee Taron Sargsyan claims he spent $24,000 on his corporate credit card so his paycheck could go to DRUGS - and the House of Mouse allowed him to pay it back without firing him
 - [https://www.dailymail.co.uk/news/article-12797141/Disneyland-employee-credit-card-drugs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12797141/Disneyland-employee-credit-card-drugs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T21:55:16+00:00

Taron Saygsyan, a Californian of Armenian descent, revealed the personal struggles he was facing as he attempted to balance his meth addiction with his first job out of college at Disney.

## Chilling update after drive-by shooting in Sydney suburb of Guildford
 - [https://www.dailymail.co.uk/news/article-12797205/Chilling-update-drive-shooting-Sydney-suburb-Guildford.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12797205/Chilling-update-drive-shooting-Sydney-suburb-Guildford.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T21:50:51+00:00

Emergency services were called to a home in Guildford, about 27km west of the CBD, at about 9.35pm on Monday after reports of shots fired.

## Maryland's largest school district wants to rename Francis Scott Key Middle School - named after the author of The Star-Spangled Banner - because he owned slaves
 - [https://www.dailymail.co.uk/news/article-12797179/Marylands-largest-school-district-wants-rename-Francis-Scott-Key-Middle-School-named-author-Star-Spangled-Banner-owned-slaves.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12797179/Marylands-largest-school-district-wants-rename-Francis-Scott-Key-Middle-School-named-author-Star-Spangled-Banner-owned-slaves.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T21:50:47+00:00

A recent report found seven schools in Montgomery County are named after slave owners and communities are launching efforts to rename them.

## Trump unveils wrapping paper with his mugshot on as part of his Christmas collection to keep bringing in millions in donations ahead of the Iowa caucuses
 - [https://www.dailymail.co.uk/news/article-12796869/Trump-unveils-wrapping-paper-mugshot-Christmas-collection-bringing-millions-donations-ahead-Iowa-caucuses.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12796869/Trump-unveils-wrapping-paper-mugshot-Christmas-collection-bringing-millions-donations-ahead-Iowa-caucuses.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T21:44:19+00:00

Former President Donald Trump's campaign is offering 'free' Christmas wrapping paper with his infamous hug shot on it to campaign donors, as Trump tries to take his prosecution to the bank.

## Southwest Airlines passenger is taken to hospital for evaluation after opening emergency exit, jumping out of the plane, running across the tarmac and trying to hijack a service truck at New Orleans airport
 - [https://www.dailymail.co.uk/news/article-12796895/Southwest-Airlines-passenger-emergency-exit-New-Orleans.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12796895/Southwest-Airlines-passenger-emergency-exit-New-Orleans.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T21:14:28+00:00

An unidentified 38-year-old man escaped a stationary plane through the emergency door at the Louis Armstrong New Orleans International Airport on Sunday night.

## Young Aussie left stunned after racist remark from 'old fart' while he was playing basketball: 'No one deserves that'
 - [https://www.dailymail.co.uk/news/article-12794297/Young-Aussie-left-stunned-racist-remark-old-fart-playing-basketball-No-one-deserves-that.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12794297/Young-Aussie-left-stunned-racist-remark-old-fart-playing-basketball-No-one-deserves-that.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T21:09:03+00:00

A young Aussie has unleashed a scathing attack on an 'old white man' over a racist remark made while he was playing basketball.

## The Americans left behind in Gaza as hostage releases continue - State Department provides scant details of US citizens captured by Hamas
 - [https://www.dailymail.co.uk/news/article-12796353/Americans-kidnapped-Israel-list-exchange-Hamas-war.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12796353/Americans-kidnapped-Israel-list-exchange-Hamas-war.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T21:08:09+00:00

At least ten Americans are believed to remain in the hands of Hamas as prisoner exchanges continue between Israel and the radical Palestinians.

## Two women aged 25 and 26 are charged with hate crimes after assaulting Jewish victim, 41, who confronted them for tearing down posters of kidnapped Israelis in NYC
 - [https://www.dailymail.co.uk/news/article-12797005/hate-crime-Mehwish-Omer-Jewish-NYC.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12797005/hate-crime-Mehwish-Omer-Jewish-NYC.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T21:07:06+00:00

Two women have been charged with hate crimes after they attacked a Jewish victim who confronted them for tearing down posters in New York City of Israelis kidnapped by Hamas, according to police.

## Student is stabbed to death and another is injured at Southeast Raleigh Magnet High School in NC: Suspect is arrested
 - [https://www.dailymail.co.uk/news/article-12797119/NC-southeast-raleigh-high-school-stabbing-dead.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12797119/NC-southeast-raleigh-high-school-stabbing-dead.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T21:03:27+00:00

One student is dead and another is in the hospital following a stabbing at a North Carolina high school that remains under lockdown.

## Match and Bumble pull Instagram Reels advertising after learning they ads ran next to child-sexualizing videos along with ads for erectile dysfunction drugs, Disney and Pizza Hut
 - [https://www.dailymail.co.uk/news/article-12796883/Match-Bumble-pull-Instagram-Reels-advertising-learning-ads-ran-child-sexualizing-videos-ads-erectile-dysfunction-drugs-Disney-Pizza-Hut.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12796883/Match-Bumble-pull-Instagram-Reels-advertising-learning-ads-ran-child-sexualizing-videos-ads-erectile-dysfunction-drugs-Disney-Pizza-Hut.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T21:00:55+00:00

An investigation by the Wall Street Journal found the ads along with content that was served up by the app's video algorithm.

## Palestinian student shot in Vermont will likely never walk again after having bullet lodged in his spine - as cops say they don't have evidence yet to charge suspect Jason Eaton with hate crime
 - [https://www.dailymail.co.uk/news/article-12797295/Palestinian-student-shot-Vermont-likely-never-walk-having-bullet-lodged-spine-cops-say-dont-evidence-charge-suspect-Jason-Eaton-hate-crime.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12797295/Palestinian-student-shot-Vermont-likely-never-walk-having-bullet-lodged-spine-cops-say-dont-evidence-charge-suspect-Jason-Eaton-hate-crime.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T20:57:52+00:00

Hisham Awartani, Kinnan Abdel Hamid and Tahseen Ahmed were visiting Awartani's grandmother's house when they were shot on Saturday afternoon, allegedly by Jason J. Eaton.

## Horrifying moment oilman Gustavo Degliantoni, 71, and killed in helicopter crash that injured three passengers in Argentina
 - [https://www.dailymail.co.uk/news/article-12796517/Gustavo-Degliantoni-helicopter-crash-stock-car-race-Argentina.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12796517/Gustavo-Degliantoni-helicopter-crash-stock-car-race-Argentina.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T20:33:35+00:00

Gustavo Degliantoni, a retired stock car race driver in the 1980s in Argentina and who was the owner of a natural gas and oil company, died in a helicopter crash in Buenos Aires on Sunday.

## Asylum seeking criminal vanishes after being released from immigration detention - while four others refuse to wear ankle monitoring devices
 - [https://www.dailymail.co.uk/news/article-12796987/Asylum-seeking-criminal-vanishes-released-immigration-detention-four-refuse-wear-ankle-monitoring-devices.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12796987/Asylum-seeking-criminal-vanishes-released-immigration-detention-four-refuse-wear-ankle-monitoring-devices.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T20:32:40+00:00

Australia's Federal Police are unable to contact one of the detainees refusing to wear an ankle monitoring device while refusing to specify what crimes they have committed.

## Melania Trump and all living first ladies to attend Rosalynn Carter's funeral: Jill Biden, Michelle Obama, Hillary Clinton and Laura Bush to mourn their predecessor - whose husband Jimmy was vocal critic of Donald
 - [https://www.dailymail.co.uk/news/article-12796939/Melania-Trump-attend-Rosalynn-Carter-funeral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12796939/Melania-Trump-attend-Rosalynn-Carter-funeral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T20:08:08+00:00

Melania Trump and all living former first ladies will join President Joe Biden and first lady Jill Biden in paying tribute to Rosalynn Carter in Atlanta on Tuesday.

## Breeder mourns loss of pregnant Cleveland Bay mare 'rarer than a giant panda' that 'was killed after being fed by an ignorant member of the public'
 - [https://www.dailymail.co.uk/news/article-12797041/pregnant-Cleveland-Bay-mare-rarer-giant-panda-killed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12797041/pregnant-Cleveland-Bay-mare-rarer-giant-panda-killed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T20:08:02+00:00

The pregnant mare, called Harmony, was found dead at Penrhyn Stud in Caernarfon, Wales, having allegedly been fed over the fence by a member of the public. It is not clear what she could have been given

## San Francisco faces private school construction boom as parents refuse to send their kids to public school because 'they haves been driven into the ground by the extreme left'
 - [https://www.dailymail.co.uk/news/article-12796615/San-Francisco-private-school-boom.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12796615/San-Francisco-private-school-boom.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T20:06:07+00:00

Expensive San Francisco private schools have plans to renovate their campuses and increase the number of students as parents grow outraged with the public school system.

## Generous Aussie pays off all Christmas lay-by items at a popular Melbourne Kmart
 - [https://www.dailymail.co.uk/news/article-12797097/Generous-Aussie-pays-Christmas-lay-items-popular-Melbourne-Kmart.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12797097/Generous-Aussie-pays-Christmas-lay-items-popular-Melbourne-Kmart.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T20:06:01+00:00

Families grappling with the cost of living Melbourne's inner city were unexpectedly uplifted by an incredible gesture from an anonymous shopper at the Victoria Gardens store of Kmart.

## Biden's Democratic primary challenger Dean Phillips tears into 'absurd' menthol cigarette ban he says will infringe on American 'liberty' and 'freedom'
 - [https://www.dailymail.co.uk/news/article-12796657/biden-democratic-primary-challenger-dean-phillips-tears-absurd-menthol-cigarette-ban.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12796657/biden-democratic-primary-challenger-dean-phillips-tears-absurd-menthol-cigarette-ban.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T19:58:00+00:00

President Joe Biden's 2024 Democratic challenger Rep. Dean Phillips is tearing into the administration's proposed ban on menthol cigarettes, calling it 'absurd.'

## 142,000 lights, 34,000 ornaments, tributes to fallen soldiers and Joe and Jill's beloved pets: The White House Christmas decorations - with Santa's workshop, 15,000 feet of ribbon and a 200-year tradition
 - [https://www.dailymail.co.uk/news/article-12796847/White-house-2023-decorations.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12796847/White-house-2023-decorations.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T19:55:17+00:00

Jill Biden thanked the 300 volunteers who spent six days decorating the White House with candy, fake snow, twinkling lights, and a variety of ornaments for this year's holiday theme.

## Grandfather could be forced to sell his own house after spending thousands of pounds in legal planning disputes after removing his own wall
 - [https://www.dailymail.co.uk/news/article-12796991/Grandfather-sell-house-thousands-pounds-legal-planning-dispute-somerset-devon.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12796991/Grandfather-sell-house-thousands-pounds-legal-planning-dispute-somerset-devon.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T19:27:56+00:00

Ron Knight, 88, has been embroiled in a six-year-long legal battle with South Somerset District Council over a parcel of farmland in the village of Milborne Port in Somerset

## Burglar caught with book titled 'Confessions of Master Jewel Thief' arrested after bungling a raid by leaving his DNA at the scene and allowing his face to be caught on CCTV
 - [https://www.dailymail.co.uk/news/article-12796677/Burglar-caught-book-Confessions-Master-Jewel-Thief-arrested.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12796677/Burglar-caught-book-Confessions-Master-Jewel-Thief-arrested.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T19:27:23+00:00

Peter O'Halloran, 49, carried out a series of home invasions in five counties over three years, stealing hundreds of thousands of pounds in cash, gems and other valuables.

## Migrant showdown in Chicago: Two residents set to face judge as they SUE city officials to stop them from housing migrants in public schools, parks and police stations
 - [https://www.dailymail.co.uk/news/article-12796605/chicago-migrants-lawsuit-asylum-seekers-housing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12796605/chicago-migrants-lawsuit-asylum-seekers-housing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T19:17:29+00:00

Natasha Dunn, Jimmy Darnell Jones and others filed the lawsuit in September against the city, Democratic mayor Brandon Johnson and Chicago public schools.

## My friend spent $400k on her wedding - then she told each guest what clothes to wear and the exact color
 - [https://www.dailymail.co.uk/news/article-12796303/Indian-wedding-cost-viral-post-400K.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12796303/Indian-wedding-cost-viral-post-400K.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T19:10:01+00:00

A woman on Reddit posted about a friend invited to a $400,000 wedding with a strict dress code that required guess to pay significant money to attend.

## 'Do you know these people?': Met Police releases website with faces of over 60 people suspected of hate crimes and offences at UK protests since Hamas' Israel v Hamas conflict began
 - [https://www.dailymail.co.uk/news/article-12796815/Met-Police-60-people-suspected-hate-crimes-offences-UK-protests-Hamas-Israel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12796815/Met-Police-60-people-suspected-hate-crimes-offences-UK-protests-Hamas-Israel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T18:54:31+00:00

The Metropolitan Police have launched an appeal to track down more than 60 people suspected of committing hate crimes and other offences following an incident in London over the weekend

## Eight more small boats filled with migrants wrapped in red blankets and scarves land in Dover after making perilous Channel crossing - taking total to 28,072 this year
 - [https://www.dailymail.co.uk/news/article-12796755/small-boats-migrants-Dover-Channel-crossing-total-28000-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12796755/small-boats-migrants-Dover-Channel-crossing-total-28000-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T18:44:41+00:00

With 364 asylum seekers arriving on Sunday alone, 28,072 people have now made the perilous journey across the 21-mile Dover Strait so far in 2023, according to official government figures.

## NC family lucky to be alive after turkey fryer EXPLODED inside their home and blew out the windows after cook fell asleep and left boiling oil unattended
 - [https://www.dailymail.co.uk/news/article-12796241/NC-turkey-fry-fire-family-home-destroyed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12796241/NC-turkey-fry-fire-family-home-destroyed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T18:44:17+00:00

Members of a North Carolina family are lucky to have escaped with their lives after a turkey fryer burst into flames, blowing out windows and leaving their home badly burned.

## Pro-Palestine activists smash windows and throw blood red paint over group they claim is 'landlord to IDF arms dealers' - as four are arrested
 - [https://www.dailymail.co.uk/news/article-12796789/Pro-Palestine-activists-smash-windows-throw-blood-red-paint-group-claim-landlord-IDF-arms-dealers-four-arrested.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12796789/Pro-Palestine-activists-smash-windows-throw-blood-red-paint-group-claim-landlord-IDF-arms-dealers-four-arrested.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T18:41:16+00:00

Three men in their late 20s and early 30s and a 20-year-old woman, were arrested after they smashed windows and threw paint over the Birmingham offices of FTSE-listed LondonMetric

## EXCLUSIVE: T.J. Holmes and Amy Robach are still going strong as they are seen canoodling on NYC street and sharing boozy lunch - one year after their affair was exposed
 - [https://www.dailymail.co.uk/news/article-12780305/TJ-Holmes-Amy-Robach-canoodle-Manhattan-one-year-later.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12780305/TJ-Holmes-Amy-Robach-canoodle-Manhattan-one-year-later.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T18:20:39+00:00

One year after DailyMail.com blew the lid off of their clandestine romance, co-stars-turned-lovers Amy Robach and T.J. Holmes have proved solid and no longer have anything to hide.

## At least 400 female and child migrants have been brutalized in 'rape tents' along infamous Darien Gap while making treacherous journey to the US, bombshell new report reveals
 - [https://www.dailymail.co.uk/news/article-12796245/Women-children-migrants-rape-tents-Darien-Gap-doctors-without-borders.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12796245/Women-children-migrants-rape-tents-Darien-Gap-doctors-without-borders.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T18:16:40+00:00

At least 400 women and children have been treated this year by Doctors Without Borders after they were raped in tents set up specifically to abuse migrants in the notorious Darien Gap.

## Woman, 35, was starved, burned with a blowtorch and had boiling water thrown over her before being locked in a cupboard to die, murder trial hears
 - [https://www.dailymail.co.uk/news/article-12796407/Woman-starved-burned-blowtorch-cupboard-murder-trial.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12796407/Woman-starved-burned-blowtorch-cupboard-murder-trial.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T18:13:13+00:00

Shakira Spencer, 35, was found dead in her flat in Hanwell on September 25, 2022 after a neighbour raised the alarm. Three people are currently on trial over her death

## Eight Americans are STILL being held by Hamas: White House working to have ceasefire 'extended' so they can get more hostages out as talks continue with Israel
 - [https://www.dailymail.co.uk/news/article-12796391/american-hamas-hostages-ceasefire-extended.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12796391/american-hamas-hostages-ceasefire-extended.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T18:11:49+00:00

President Joe Biden wants to extend the ceasefire between Israel and Hamas to get the remaining eight U.S. hostages out of the Palestinian enclave of Gaza.

## Pensioner, 70, and his Border Collie named Lad are nearly trampled to death by cows in horror ordeal - as local farmer is fined £2,000
 - [https://www.dailymail.co.uk/news/article-12796621/Pensioner-70-Border-Collie-named-Lad-nearly-trampled-death-cows-horror-ordeal-local-farmer-fined-2-000.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12796621/Pensioner-70-Border-Collie-named-Lad-nearly-trampled-death-cows-horror-ordeal-local-farmer-fined-2-000.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T17:53:49+00:00

Retired chartered surveyor Patrick Atherton, 70, and his 13-year-old Border Collie 'Lad' were knocked to the ground by seven cows while walking near Birdcage Farm in Devon in June last year.

## The Crown actor Jared Harris who portrayed dying King George VI in first season of Netflix show says Royal Family would be 'delighted' by the series because it 'humanises' them
 - [https://www.dailymail.co.uk/news/article-12796079/crown-season-actor-jarred-harris-king-george-vi-royal-family.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12796079/crown-season-actor-jarred-harris-king-george-vi-royal-family.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T17:45:28+00:00

Jared Harris, 62, portrayed the ailing King George VI in the show's first season. The Crown has come in for significant criticism over its portrayal of key figures in the Royal Family and its historical inaccuracies.

## On-duty police officer missed 999 call because he was 'having sex with his ex-girlfriend', misconduct hearing told
 - [https://www.dailymail.co.uk/news/article-12796703/On-duty-police-officer-missed-999-call-having-sex-ex-girlfriend-misconduct-hearing-told.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12796703/On-duty-police-officer-missed-999-call-having-sex-ex-girlfriend-misconduct-hearing-told.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T17:45:15+00:00

PC Steven Austin had allegedly visited his ex's house in the middle of the day despite being on duty serving for Sussex Police but missed a call involving a man being punched in head four times.

## Desperate search for California mother, 36, who vanished in Texas after being discharged from clinic for mental health treatment
 - [https://www.dailymail.co.uk/news/article-12796317/Danielle-Friedland-California-Mother-Missing-Houston-Texas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12796317/Danielle-Friedland-California-Mother-Missing-Houston-Texas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T17:43:36+00:00

Danielle Friedland, 36, went missing from a Houston airport after she was released from the Menninger Clinic for mental health treatment. The mother of two is originally from California.

## 'Numerous' horses die after massive fire at Franktown, Colorado, barn where smoke and flames could be seen for miles
 - [https://www.dailymail.co.uk/news/article-12796347/barn-fire-horses-dead-franktown-colorado.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12796347/barn-fire-horses-dead-franktown-colorado.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T17:39:39+00:00

A barn fire in Franktown, Colorado killed 'numerous' horses as the structure went up in flames around 4.50am on Monday. One person was injured and taken to a hospital.

## Omid Scobie accuses King Charles of evicting Prince Harry and Meghan Markle from Frogmore Cottage in 'cheap shot' to 'punish' the couple for their bombshell Netflix series
 - [https://www.dailymail.co.uk/news/article-12796627/Omid-Scobie-Charles-Prince-Harry-Meghan-Markle-Frogmore-Cottage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12796627/Omid-Scobie-Charles-Prince-Harry-Meghan-Markle-Frogmore-Cottage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T17:30:12+00:00

Omid Scobie claimed Frogmore Cottage in Windsor was the Sussexes' 'only truly safe option when visiting the United Kingdom' because its grounds are surrounded by armed guards.

## Amazon is fined a $7K after 20-year-old Indiana worker Caes Gruesbeck DIES when he hit his head trying to clear a blocked conveyor and got trapped in the machinery
 - [https://www.dailymail.co.uk/news/article-12795995/Indiana-Amazon-fined-worker-dies-Caes-Gruesbeck.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12795995/Indiana-Amazon-fined-worker-dies-Caes-Gruesbeck.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T17:19:45+00:00

Amazon has been fined $7,000 after a 20-year-old worker died when he hit his head trying to clear a blocked conveyor and got trapped in the machinery.

## Dubai's climate shambles exposed: UAE energy tsar Sultan Al Jaber secretly used COP28 talks to push his own oil and gas projects, in latest shock revelations about warming meet
 - [https://www.dailymail.co.uk/news/article-12796143/Dubai-climate-shambles-UAE-energy-Sultan-Al-Jaber-secret-COP28-oil-gas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12796143/Dubai-climate-shambles-UAE-energy-Sultan-Al-Jaber-secret-COP28-oil-gas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T17:15:38+00:00

'As a COP president you should not represent any national or commercial interest, it is your job to lead the world,' said Michael Jacobs, a Sheffield University climate professor.

## America's healthiest state Colorado is set to ban 'fatphobia' to stop discrimination by employers and housing providers against overweight people as obesity rates across US soar
 - [https://www.dailymail.co.uk/news/article-12795333/Americas-healthiest-state-Colorado-fatphobia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12795333/Americas-healthiest-state-Colorado-fatphobia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T17:07:27+00:00

Colorado is set to join a group of US states banning workplace discrimination based on weight despite the Rocky Mountain state being the healthiest in the nation.

## Police filmed getting heavy handed with suspects in parking lot outside McDonald's in McFarland, California
 - [https://www.dailymail.co.uk/news/article-12795829/McFarland-California-police-suspect-arrest-attack-video.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12795829/McFarland-California-police-suspect-arrest-attack-video.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T16:59:55+00:00

A man was restrained by several police officers at a McDonald's in McFarland, California, after he and a female got into an argument with a cop inside the restaurant.

## Are YOU due to receive new £600 Winter fuel payment from today? How to check if you're eligible for allowance
 - [https://www.dailymail.co.uk/news/article-12795713/winter-fuel-payment-eligible-cost-living.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12795713/winter-fuel-payment-eligible-cost-living.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T16:45:34+00:00

Who exactly will receive the payment and do those eligible need to do anything specific to claim it? Here is everything you need to know about the latest winter fuel payment by the government.

## Moment four-year-old American citizen Abigail Edan is reunited with her family after being released from Hamas captivity - 49 days after her parents were killed by terrorists
 - [https://www.dailymail.co.uk/news/article-12796263/Moment-four-year-old-American-citizen-Abigail-Edan-reunited-family-released-Hamas-captivity-49-days-parents-killed-terrorists.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12796263/Moment-four-year-old-American-citizen-Abigail-Edan-reunited-family-released-Hamas-captivity-49-days-parents-killed-terrorists.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T16:44:48+00:00

Abigail Edan was the youngest hostage - and the first American -  released on Sunday during a ceasefire deal between Israel and Hamas.

## King Charles and Prince William are 'allowing selfish agendas and family discord to take over the House of Windsor' - but there is 'friction' in their relationship and they are 'tussling for spotlight': Bombshells from Omid Scobie's new book
 - [https://www.dailymail.co.uk/news/article-12796339/King-Charles-Prince-William-Harry-Meghan-Markle-Omid-Scobie-endgame.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12796339/King-Charles-Prince-William-Harry-Meghan-Markle-Omid-Scobie-endgame.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T16:43:58+00:00

Mr Scobie says the monarch and his heir are 'pursuing selfish agendas' and 'one-upmanship' that threatens their relationship, Elizabeth II's legacy and the future of the Crown.

## Omid Scobie's 'Sussex Squad': Royal biographer recruits influencers and bloggers to promote his new book Endgame
 - [https://www.dailymail.co.uk/news/article-12796337/Omid-Scobies-Sussex-Squad-Royal-biographer-recruits-influencers-bloggers-promote-new-book-Endgame.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12796337/Omid-Scobies-Sussex-Squad-Royal-biographer-recruits-influencers-bloggers-promote-new-book-Endgame.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T16:43:05+00:00

The royal biographer asked them to sign a non-disclosure agreement ahead of the 400-page Endgame's release.

## Biden to skip annual UN climate summit in Dubai attended by 200 world leaders as he tries to turn around sagging poll numbers at home
 - [https://www.dailymail.co.uk/news/article-12796271/Biden-Cop-28-climate-summit-Dubai.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12796271/Biden-Cop-28-climate-summit-Dubai.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T16:34:01+00:00

When world leaders gather in Dubai this week to consider climate change , President Joe Biden will not be among them even though he has placed green policies at the heart of his administration.

## Tommy Robinson is charged with breaching an exclusion order after being escorted from march against antisemitism
 - [https://www.dailymail.co.uk/news/article-12796305/Tommy-Robinson-charged-breaching-exclusion-order-escorted-march-against-antisemitism.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12796305/Tommy-Robinson-charged-breaching-exclusion-order-escorted-march-against-antisemitism.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T15:41:36+00:00

Tommy Robinson has been charged with breaching an exclusion order after he was escorted from a march against antisemitism.

## Up to snow good: Man, 54, handed road ban after being caught driving his van... with a frozen windscreen
 - [https://www.dailymail.co.uk/news/article-12796081/Man-handed-road-ban-caught-driving-van-frozen-windscreen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12796081/Man-handed-road-ban-caught-driving-van-frozen-windscreen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T15:40:11+00:00

David Hyslop, 54, was stopped by officers on the A701 at Dumfries, Scotland, in December 2022. He was convicted of dangerous driving last week following a trial at Dumfries Sheriff Court.

## Trump rejects claims he is 'cognitively impaired', insists he deliberately mixes up Obama and Biden and boasts that he 'ACED' his latest cognitive exam as he fires back at claims he is too old and brushes off recent gaffes
 - [https://www.dailymail.co.uk/news/article-12796147/Trump-rejects-claims-cognitively-impaired-insists-deliberately-mixes-Obama-Biden-boasts-ACED-latest-cognitive-exam-fires-claims-old-brushes-recent-gaffes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12796147/Trump-rejects-claims-cognitively-impaired-insists-deliberately-mixes-Obama-Biden-boasts-ACED-latest-cognitive-exam-fires-claims-old-brushes-recent-gaffes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T15:39:10+00:00

Trump said he was speaking 'sarcastically' when he has inserted the name of Barack Obama while railing against President Biden. He said he 'aced' a cognitive test on his recent physical.

## Downing Street slaps down minister who publicly backed sale of Daily Telegraph to a UAE fund
 - [https://www.dailymail.co.uk/news/article-12796249/Downing-Street-slaps-minister-publicly-backed-sale-Daily-Telegraph-UAE-fund.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12796249/Downing-Street-slaps-minister-publicly-backed-sale-Daily-Telegraph-UAE-fund.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T15:33:27+00:00

Investment minister Dominic Johnson dismissed 'sentimental' objections to the deal, which Tory MPs have warned could put at risk the newspaper's editorial independence.

## Will it snow for Christmas 2023? Met Office reveals weather prediction for December
 - [https://www.dailymail.co.uk/news/article-12795933/snow-white-Christmas-2023-Met-Office-weather-prediction-December.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12795933/snow-white-Christmas-2023-Met-Office-weather-prediction-December.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T15:32:27+00:00

With December less than one week away, plenty of Brits will be dreaming of a white Christmas - but is snow on the cards for this year? The Met Office have shared their long range forecast for December.

## Senate tees up busy December: Schumer vows to bring Biden's $100B  Ukraine and Israel aid package up next week and tells members to brace for 'long nights and weekends'
 - [https://www.dailymail.co.uk/news/article-12796037/Senate-tees-busy-December-Schumer-vows-bring-Bidens-100B-foreign-aid-package-week-tells-members-brace-long-nights-weekends.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12796037/Senate-tees-busy-December-Schumer-vows-bring-Bidens-100B-foreign-aid-package-week-tells-members-brace-long-nights-weekends.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T15:32:24+00:00

Schumer vowed to have senators working 'long days and nights and potentially weekends' to push through a foreign aid package and work through spending before the Senate skips town.

## Moment longtime Walmart employee Gail Lewis gives emotional sign-off after working at the Illinois store for 10 years: 'Today was an end of an era for me'
 - [https://www.dailymail.co.uk/news/article-12795815/Gail-Lewis-Walmart-employee-Illinois-viral-video.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12795815/Gail-Lewis-Walmart-employee-Illinois-viral-video.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T15:32:00+00:00

Beloved former Walmart employee Gail Lewis, 42, said her final goodbyes in an emotional announcement that she uploaded to TikTok. The video and her have since gone viral.

## Vermont shooting suspect Jason J Eaton, 48, is seen in mugshot as his 'shocked' mother says he was acting normal days before 'attacking Palestinian students in hate crime'
 - [https://www.dailymail.co.uk/news/article-12795243/Pictured-Suspected-Vermont-gunman-Jason-J-Eaton-48-accused-shooting-three-Palestinian-students.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12795243/Pictured-Suspected-Vermont-gunman-Jason-J-Eaton-48-accused-shooting-three-Palestinian-students.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T15:29:32+00:00

Jason J. Eaton, 48, is in custody on charges of aggravated assault. His shocked mother said she was stunned to learn he'd been arrested for the shooting of the three students.

## Family of female 'serial killer's' victim slams Ohio AG for 'shaming' men targeted by sex worker when he warned, 'don't buy sex - it ruins lives': Woman 'fatally drugged and robbed four men'
 - [https://www.dailymail.co.uk/news/article-12795785/serial-killer-Ohio-rebecca-auborn.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12795785/serial-killer-Ohio-rebecca-auborn.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T15:27:53+00:00

Rebecca Auborn, 33, has been charged with the murders of four customers, including Wayne Akin, a former postal worker who struggled with a drug addiction.

## Massive cross-country storm throws post-Thanksgiving travel into chaos with more than 1,000 flights delayed: Millions of Americans could see the COLDEST air of the season as deep freeze moves across the US
 - [https://www.dailymail.co.uk/news/article-12795801/thanksgiving-travel-weather-delays.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12795801/thanksgiving-travel-weather-delays.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T15:25:22+00:00

The Monday after Thanksgiving is a popular day for post-holiday travel, but winter weather across the Northeast and Great Lakes could cause flight delays and poor driving conditions.

## Nikki Haley and Ron DeSantis scramble in desperate bid to catch frontrunner Trump with just 49 DAYS until the Iowa caucuses
 - [https://www.dailymail.co.uk/news/article-12795811/Nikki-Haley-Ron-DeSantis-scramble-catch-Trump-49-days-Iowa-caucuses.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12795811/Nikki-Haley-Ron-DeSantis-scramble-catch-Trump-49-days-Iowa-caucuses.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T14:37:11+00:00

The primary sprint has begun with Thanksgiving in the rear-view and Gov. Ron DeSantis and ex-UN Ambassador Nikki Haley having just 49 days to convince Iowans to caucus for them instead of Trump.

## More than 45,000 Portland students return to class for the first time since HALLOWEEN after teachers' union reaches deal to end strike of 4,000 educators
 - [https://www.dailymail.co.uk/news/article-12795773/Portland-students-return-class-teachers-union-deal-end-strike-pay-rise-Oregon.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12795773/Portland-students-return-class-teachers-union-deal-end-strike-pay-rise-Oregon.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T14:36:45+00:00

Portland Association of Teachers (PAT) union called off industrial action after securing a 13.75 percent pay rise for teachers over the next three years.

## Moment Bruce Lehrmann sings 'I fought the law and Bruce won' after Brittany Higgins trial collapsed
 - [https://www.dailymail.co.uk/news/article-12795427/Bruce-Lehrmann-sings-fought-law-Brittany-Higgins.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12795427/Bruce-Lehrmann-sings-fought-law-Brittany-Higgins.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T14:36:39+00:00

Footage shows the former Liberal Party staffer in the kitchen of a home sitting on a stool and belting out the chorus to the 1979 hit by The Clash, but with a distinct change to the lyrics.

## Osher Günsberg and other ABC panellists belittle Australians who voted No to the Voice - as viewers unleash on the 'insufferable' final episode of Q+A for the year
 - [https://www.dailymail.co.uk/news/article-12795653/Osher-Gunsberg-ABC-No-Voice-Q-A.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12795653/Osher-Gunsberg-ABC-No-Voice-Q-A.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T14:35:44+00:00

TV presenter Osher Günsberg told ABC's Q+A program on Monday night that Australians were manipulated into voting No in the Indigenous Voice to Parliament referendum.

## White House unveils Christmas decorations WITHOUT stockings for grandchildren after Biden acknowledged Hunter's daughter: Holiday display includes Commander, a gingerbread 1600 Pennsylvania Avenue and lots of candy
 - [https://www.dailymail.co.uk/news/article-12794251/White-house-Christmas-decorations-joe-jill-grandchild-hunter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12794251/White-house-Christmas-decorations-joe-jill-grandchild-hunter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T14:33:44+00:00

This year's White House Christmas decorations were inspired by a child's wonder of the holidays but were missing is one crucial part: the stockings by the fireplace.

## Rishi Sunak rules out return of Elgin Marbles to Athens as Downing Street hits back at Greek PM's claim keeping them in Britain is like 'cutting the Mona Lisa in half'
 - [https://www.dailymail.co.uk/news/article-12795985/Rishi-Sunak-rules-return-Elgin-Marbles-Athens-Downing-Street-hits-Greek-PMs-claim-keeping-Britain-like-cutting-Mona-Lisa-half.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12795985/Rishi-Sunak-rules-return-Elgin-Marbles-Athens-Downing-Street-hits-Greek-PMs-claim-keeping-Britain-like-cutting-Mona-Lisa-half.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T14:23:09+00:00

Kyriakos Mitsotakis's visit to London, during which he is expected to meet with both Mr Sunak and Labour's Sir Keir Starmer, has seen a fresh row over the artefacts.

## Met Police officer 'tasered girl, 10, twice within seconds' after arriving to child holding garden shears after threatening her mother with them
 - [https://www.dailymail.co.uk/news/article-12795827/Met-Police-officer-tasered-girl-10-twice-seconds-arriving-child-holding-garden-shears-threatening-mother-them.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12795827/Met-Police-officer-tasered-girl-10-twice-seconds-arriving-child-holding-garden-shears-threatening-mother-them.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T14:11:13+00:00

PC Jonathan Broadhead and a colleague were sent to the child's address after her mother had reported that her daughter had threatened her with the gardening equipment and a hammer.

## Warning as five children are among several people to fall ill after eating £1 'mystery' chocolate bars at town's Christmas market
 - [https://www.dailymail.co.uk/news/article-12795739/Warning-five-children-people-fall-ill-eating-1-mystery-chocolate-bars-towns-Christmas-market.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12795739/Warning-five-children-people-fall-ill-eating-1-mystery-chocolate-bars-towns-Christmas-market.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T14:09:43+00:00

Police have issued an urgent warning for people not to eat 'mystery' chocolate bars being sold in Mansfield, Nottingham, this weekend. There were reports they had been laced with drugs.

## The REAL inside story of how Melbourne couple's wedding night was marred by screwdriver attack - as extraordinary details emerge about how horrific stabbing unfolded... and guest tells of victim's brave act
 - [https://www.dailymail.co.uk/news/article-12794095/williamstown-sunshine-west-wedding-screwdriver-stabbing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12794095/williamstown-sunshine-west-wedding-screwdriver-stabbing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T13:58:26+00:00

Maketh Bul and his bride Aluet Diing Aruai exchanged vows on Saturday at Williamstown's Holy Trinity Anglican Church in front of around 700 relatives, friends, and community members.

## Is THIS why Putin hates Zelensky so much? Former comic's 2014 TV sketch mocking Vladimir and his gymnast lover 'sparked life-long loathing'
 - [https://www.dailymail.co.uk/news/article-12795513/Why-Putin-hates-Zelensky.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12795513/Why-Putin-hates-Zelensky.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T13:28:05+00:00

The sketch appears innocuous by Western standards but according to author Mikhail Zygar, it sealed the autocrat's loathing of Zelensky, against whom he would later go to war

## Girl, 5, dies and man, 54, is still missing after waves swept them both out to sea at California's Half Moon Bay as coast guard makes tough choice to call off search after 22 hours
 - [https://www.dailymail.co.uk/news/article-12795457/girl-dies-martins-beach-california-grandfather-missing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12795457/girl-dies-martins-beach-california-grandfather-missing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T13:23:21+00:00

The U.S. Coast Guard responded to reports that the pair had been hit by a sneaker wave at around 2pm on Saturday on Martin's Beach in California 's Half Moon Bay.

## Channel 5 pulls history doc from TV schedules after contributor was exposed as a 'hardline Nazi' who posted images of herself doing Hitler salute, licking swastika lollipop and calling for Sam Smith to be 'gassed'
 - [https://www.dailymail.co.uk/news/article-12795621/Channel-5-pulls-history-doc-TV-schedules-contributor-exposed-hardline-Nazi-posted-images-doing-Hitler-salute-licking-swastika-lollipop-calling-Sam-Smith-gassed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12795621/Channel-5-pulls-history-doc-TV-schedules-contributor-exposed-hardline-Nazi-posted-images-doing-Hitler-salute-licking-swastika-lollipop-calling-Sam-Smith-gassed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T13:23:12+00:00

Nikki Shaw, who has penned self-published books about Victorian murder victims and Georgian London, was set to feature in The Year the Thames Flooded, which was due to air last night.

## Laurence Fox was 'shocked and upset' when he was dropped by his agent after calling two people 'paedophiles' in Twitter row, libel trial hears
 - [https://www.dailymail.co.uk/news/article-12795573/Laurence-Fox-shocked-upset-dropped-agent-calling-two-people-paedophiles-Twitter-row-libel-trial-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12795573/Laurence-Fox-shocked-upset-dropped-agent-calling-two-people-paedophiles-Twitter-row-libel-trial-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T13:14:04+00:00

Laurence Fox is being sued by Simon Blake, a former trustee of the LGBT + charity Stonewall and drag queen Colin Seymour, known as Crystal, for calling them 'paedophiles' on Twitter.

## Shocking moment mob of gunmen attack security guard and rob truck full of tobacco and cigarettes in crime-ridden Oakland
 - [https://www.dailymail.co.uk/news/article-12795579/robbery-truck-cigarettes-Oakland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12795579/robbery-truck-cigarettes-Oakland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T13:12:05+00:00

The robbery happened outside at a 7-Eleven in Oakland's Grand Lake neighborhood on Saturday afternoon.

## First reviews of Omid Scobie's book Endgame: New York Times says it's 'like a press release cooked up by ChatGPT' that will leave readers 'disappointed', and its slated by The Independent for 'painting Harry and Meghan in a relentless saintly light'
 - [https://www.dailymail.co.uk/news/article-12795171/omid-scobie-endgame-book-reviews-royals-meghan-markle-prince-harry.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12795171/omid-scobie-endgame-book-reviews-royals-meghan-markle-prince-harry.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T13:09:30+00:00

In a pithy review of Endgame, the New York Times says the book, out tomorrow, 'is not all that different from what Harry presented in "Spare",

## Landlady behind heartwarming Christmas advert set at her Northern Ireland pub is 'blown away' by the 'phenomenal' reaction to it as she reveals couple who star with their dog are regulars at the bar
 - [https://www.dailymail.co.uk/news/article-12795517/Landlady-heartwarming-Christmas-advert-set-Northern-Ireland-pub-blown-away-phenomenal-reaction-reveals-couple-star-dog-regulars-bar.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12795517/Landlady-heartwarming-Christmas-advert-set-Northern-Ireland-pub-blown-away-phenomenal-reaction-reveals-couple-star-dog-regulars-bar.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T13:07:21+00:00

Una Burns (pictured) admitted she never expected her humble home-made video to go viral, putting Charlie's Bar in Enniskillen, Co Fermanagh on the map.

## Captain Tom's daughter admits pocketing £18,000 to judge charity award and hand out plaque - while the foundation set up in her father's name received just £2,000
 - [https://www.dailymail.co.uk/news/article-12795473/Captain-Toms-daughter-admits-pocketing-18-000-judge-charity-award-hand-plaque-foundation-set-fathers-received-just-2-000.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12795473/Captain-Toms-daughter-admits-pocketing-18-000-judge-charity-award-hand-plaque-foundation-set-fathers-received-just-2-000.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T12:23:28+00:00

Hannah Ingram-Moore and the charity - Captain Sir Tom Moore Foundation - is now being investigated by the Charity Commission.

## Dubai's billionaire ruler Sheikh Maktoum who 'kidnapped his daughter' is given go-ahead to expand sprawling Highland estate that boasts 17-bedroom house, hunting lodge, helipads and a pool
 - [https://www.dailymail.co.uk/news/article-12795303/Dubais-billionaire-ruler-Sheikh-Maktoum-kidnapped-daughter-given-ahead-expand-sprawling-Highland-estate-boasts-17-bedroom-house-hunting-lodge-helipads-pool.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12795303/Dubais-billionaire-ruler-Sheikh-Maktoum-kidnapped-daughter-given-ahead-expand-sprawling-Highland-estate-boasts-17-bedroom-house-hunting-lodge-helipads-pool.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T12:19:51+00:00

Sheikh Mohammed bin Rashid al-Maktoum is to extend a 17-bedroom house on Inverinate Estate, Scotland

## Nigel Farage's (not so) secret French 'lover' 15 years his junior: How ardent Brexiteer struck up 'six-year romance' with Eurosceptic politician a decade after meeting her while she worked as a waitress in Strasbourg
 - [https://www.dailymail.co.uk/news/article-12795037/Nigel-Farages-not-secret-French-lover-15-years-junior-ardent-Brexiteer-struck-six-year-romance-Eurosceptic-politician-decade-meeting-worked-waitress-Strasbourg.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12795037/Nigel-Farages-not-secret-French-lover-15-years-junior-ardent-Brexiteer-struck-six-year-romance-Eurosceptic-politician-decade-meeting-worked-waitress-Strasbourg.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T12:19:31+00:00

Ms Ferrari, who at 44 is 15 years Mr Farage's junior, first met the former UKIP leader while she was working as a waitress in Strasbourg in 2007 - a decade before rumours emerged about the pair.

## Moment strip club bouncer punches Ed Sheeran fan to the floor in 'unprovoked' attack while on the way home from a concert
 - [https://www.dailymail.co.uk/news/article-12795293/strip-club-bouncer-punches-Ed-Sheeran-fan-attack-concert.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12795293/strip-club-bouncer-punches-Ed-Sheeran-fan-attack-concert.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T12:18:19+00:00

Kevin Davies, 39, was working as a doorman at For Your Eyes Only in Cardiff at 4:27am when he set upon Michael Barraclough on his way home from seeing the singer in May 2022.

## Family doctor who served in the British Army is banned from treating patients for six weeks after groping colleague's bottom during boozy post-lockdown dinner at military base
 - [https://www.dailymail.co.uk/news/article-12795501/Family-doctor-served-British-Army-banned-treating-patients-six-weeks-groping-colleagues-bottom-boozy-post-lockdown-dinner-military-base.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12795501/Family-doctor-served-British-Army-banned-treating-patients-six-weeks-groping-colleagues-bottom-boozy-post-lockdown-dinner-military-base.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T12:16:52+00:00

Dr Graham Wheatley, 60, touched the woman on repeated occasions and was also accused of fondling her breast.

## Inside Peter Dutton's extraordinary change in fortunes as he follows the ruthless Tony Abbott - Peta Credlin strategy to destroy Anthony Albanese's government
 - [https://www.dailymail.co.uk/news/article-12793625/Inside-Peter-Duttons-extraordinary-change-fortunes-follows-ruthless-Tony-Abbott-Peta-Credlin-strategy-destroy-Anthony-Albaneses-government.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12793625/Inside-Peter-Duttons-extraordinary-change-fortunes-follows-ruthless-Tony-Abbott-Peta-Credlin-strategy-destroy-Anthony-Albaneses-government.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T12:16:07+00:00

The latest Newspoll revealed voters had swung back toward the Coalition, which now has an equal grip on the two-party preferred vote.

## Kanye West attends the F1 Abu Dhabi Grand Prix after sparking an 'antisemitism' row with his new single Vultures
 - [https://www.dailymail.co.uk/tvshowbiz/article-12795399/Kanye-West-Abu-Dhabi-Grand-Prix-antisemitism.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-12795399/Kanye-West-Abu-Dhabi-Grand-Prix-antisemitism.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T11:47:00+00:00

The rapper, 46, was among a slew of stars in attendance to watch the Formula One race unfold, before Max Verstappen was once again crowned World Champion .

## Jonathon Hawtin: Man left tetraplegic in horror axe attack allegedly orchestrated by his ex-wife Dr Lisa Lines and her lover speaks out as she's extradited from Palau
 - [https://www.dailymail.co.uk/news/article-12795157/tetraplegic-axe-attack-ex-wife-extradited.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12795157/tetraplegic-axe-attack-ex-wife-extradited.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T11:46:46+00:00

A man left paralysed from the neck down in a murder plot allegedly orchestrated by his former wife has spoken out about his struggles since the 2017 axe attack.

## EV charging station: Why this ute in a multi-storey car park has drivers fuming - and they could be slapped with a nasty fine before Christmas
 - [https://www.dailymail.co.uk/news/article-12795017/Ute-parks-EV-charging-station.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12795017/Ute-parks-EV-charging-station.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T11:25:19+00:00

A fed-up Aussie shared a photo of the Volkswagen Amarok to Reddit with the caption: 'Ute parked in one of the 5 Ev charging slots. Typical ute driver behaviour.'

## Terrifying moment Hamas gunmen riddle Israeli petrol station with bullets as workers run for cover: Terrorists give up trying to murder civilians and loot store during October 7 attack...even stealing the trash can
 - [https://www.dailymail.co.uk/news/article-12795225/Terrifying-moment-Hamas-gunmen-riddle-Israeli-petrol-station-bullets-workers-run-cover-Terrorists-trying-murder-civilians-loot-store-October-7-attack-stealing-trash-can.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12795225/Terrifying-moment-Hamas-gunmen-riddle-Israeli-petrol-station-bullets-workers-run-cover-Terrorists-trying-murder-civilians-loot-store-October-7-attack-stealing-trash-can.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T11:22:31+00:00

Cameras captured the moment the evil terrorists burst into the shop, frantically looking for the two employees who have hidden in the freezer out of shot

## Is THIS Britain's worst hoarder? Bodies of mummified cats are discovered in among piles of belongings left in home - as cleaners say it is the 'worst case' they have ever seen
 - [https://www.dailymail.co.uk/news/article-12795131/Is-Britains-worst-hoarder-Bodies-mummified-cats-discovered-piles-belongings-left-home-cleaners-say-worst-case-seen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12795131/Is-Britains-worst-hoarder-Bodies-mummified-cats-discovered-piles-belongings-left-home-cleaners-say-worst-case-seen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T11:20:22+00:00

The extreme case in Lancashire was uncovered after the male homeowner in his late 70s, who lived in the property alone, died without any known close family.

## Top cop's blue light 'taxi'
 - [https://www.dailymail.co.uk/news/article-12795253/Top-cops-blue-light-taxi.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12795253/Top-cops-blue-light-taxi.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T11:19:56+00:00

The on-duty traffic officer who took Scotland's police chief Jo Farrell on a 'taxpayer-funded taxi ride' to England switched on the car's blue lights, the Mail can reveal.

## A Leonardo Di Vinci masterpiece.. or just an inferior copy? Mystery over the 'Isleworth Mona Lisa' as it goes on display in Turin, with experts divided over whether the painting of a 'younger, happier' Mona Lisa really is by the Italian master
 - [https://www.dailymail.co.uk/news/article-12795121/Isleworth-Mona-Lisa-debate-Leonardo-da-Vinci.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12795121/Isleworth-Mona-Lisa-debate-Leonardo-da-Vinci.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T11:18:02+00:00

The so-called Isleworth Mona Lisa spent more than two centuries in England before being hidden for decades in a vault in Switzlerland. Now it is being exhibited at an exhibition in Turin.

## Omid Scobie claims King Charles branded Prince Harry a 'fool' after Duke's Netflix series - as insiders hit back at his new book and insist Royal staff were 'on eggshells around the Sussexes trying to keep them happy' after their engagement
 - [https://www.dailymail.co.uk/news/article-12794961/Omid-Scobie-Endgame-King-Charles-Prince-Harry-Meghan-Markle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12794961/Omid-Scobie-Endgame-King-Charles-Prince-Harry-Meghan-Markle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T11:08:32+00:00

Prince Harry made a series of allegations against the Royal Family in the series released in December last year as part of his £80million deal with the streaming network.

## Rishi Sunak woos business leaders to come to the UK at glitzy investment summit at Hampton Court Palace
 - [https://www.dailymail.co.uk/news/article-12795283/Rishi-Sunak-taxes-business-investment-summit-Hampton-Court-Palace.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12795283/Rishi-Sunak-taxes-business-investment-summit-Hampton-Court-Palace.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T11:08:30+00:00

Rishi Sunak underlined the scale of the perks included in the Autumn Statement as he kicked off a major conference at Hampton Court.

## NHS doctor, 30, who broke his spine and was paralysed after his £2,300 all-terrain bike 'sheared in two' while going downhill sues firm for £10million
 - [https://www.dailymail.co.uk/news/article-12795245/NHS-doctor-paralysed-bike-sheared-sues-firm.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12795245/NHS-doctor-paralysed-bike-sheared-sues-firm.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T11:00:05+00:00

Dr Daniel Gordon, 30, suffered life-changing injuries when the forks of his £2,300 all-terrain gravel bike 'sheared in two'  while riding it in Inverness, Scotland, in July 2020.

## Boy, 5, and his mother, Hanoi Peralta, are found stabbed to death inside their Bronx apartment while his father, Jonathan Rivera, is discovered dead in the lobby as police investigate triple homicide
 - [https://www.dailymail.co.uk/news/article-12794959/family-dead-bronx-apartment-new-york-triple-homicide-jonathan-rivera-hanoi-peralta.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12794959/family-dead-bronx-apartment-new-york-triple-homicide-jonathan-rivera-hanoi-peralta.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T10:56:17+00:00

The bodies of Jonathan Rivera, 38, Hanoi Peralta, 33, and Kayden Rivera, 5, were found inside an apartment building on 674 East 136th Street in Mott Haven at 8 a.m.

## 'Sussex cheerleader' Omid Scobie claims Queen Camilla personally thanked Piers Morgan for 'defending the Firm' from Meghan Markle after the Duchess accused Royal Family of racism in Oprah interview
 - [https://www.dailymail.co.uk/news/article-12794781/Queen-Camilla-thanked-Piers-Morgan-Meghan-Markle-Princess-Pinocchio-Omid-Scobie-Endgame.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12794781/Queen-Camilla-thanked-Piers-Morgan-Meghan-Markle-Princess-Pinocchio-Omid-Scobie-Endgame.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T10:45:26+00:00

The King's wife allegedly thanked the British journalist and broadcaster for 'defending The Firm' and 'standing up' to the Duchess of Sussex after her and Harry's volley of attacks on the royals.

## The world's biggest iceberg on the move at speed
 - [https://www.dailymail.co.uk/galleries/article-12795219/The-worlds-biggest-iceberg-speed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/galleries/article-12795219/The-worlds-biggest-iceberg-speed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T10:16:06+00:00

Iceberg A23a - which is shaped like a 'tooth' - is being carried northwards by wind and ocean currents after 30 years of being grounded by the ocean floor.

## Catiuscia Machado's final moments revealed after boyfriend Diogo De Oliveira charged with murder
 - [https://www.dailymail.co.uk/news/article-12794889/Catiuscia-Machados-final-moments-Diogo-Oliveira.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12794889/Catiuscia-Machados-final-moments-Diogo-Oliveira.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T10:01:25+00:00

Diogo De Oliveira, 40, is accused of killing Catiuscia Machado during a domestic incident about 9.50pm on Saturday at their Chiswick unit in Sydney 's inner west.

## Rishi Sunak rejects claims that Britain faces a new wave of austerity after tax-cutting pre-election Autumn Statement - saying public spending will still be higher than before Covid
 - [https://www.dailymail.co.uk/news/article-12795019/Rishi-Sunak-rejects-Britain-new-wave-austerity-tax-cuts-Autumn-Statement.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12795019/Rishi-Sunak-rejects-Britain-new-wave-austerity-tax-cuts-Autumn-Statement.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T09:37:11+00:00

He used a TV interview to hit back at warnings from economists that his fiscal plans will result in painful and 'implausible' savings for already-squeezed departments and public services.

## The last thing we need! Calls for Australian parliament to be expanded by nearly 50 MORE MPs (and guess whose idea it is!)
 - [https://www.dailymail.co.uk/news/article-12794755/Australian-parliament-expanded-200-MPs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12794755/Australian-parliament-expanded-200-MPs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T09:21:13+00:00

The expansion of Australia's federal parliament to 200 MPs - up from the current 151 - is a step closer with the backing of a controversial new proposal.

## Five dead in wedding massacre as 'drunk' groom shoots his wife, mother-in-law and guests then kills himself after arguing during the ceremony in Thailand
 - [https://www.dailymail.co.uk/news/article-12794841/drunk-thai-groom-shoots-dead-wife-mother-law-thailand-wedding.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12794841/drunk-thai-groom-shoots-dead-wife-mother-law-thailand-wedding.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T09:04:28+00:00

The incident took place in north-east Thailand, where a wedding party was being held for Chaturong Suksuk and Kanchana Pachunthuek. Chaturong went out to his car and returned with a pistol.

## Matthew Cox makes legal move after allegedly murdering wife Tayla Cox and newborn Murphy Margaret
 - [https://www.dailymail.co.uk/news/article-12794895/Matthew-Cox-murder-wife-Tayla-Cox-Murphy-Margaret.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12794895/Matthew-Cox-murder-wife-Tayla-Cox-Murphy-Margaret.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T09:03:30+00:00

Matthew Cox, 31, was charged with two counts of murder after police found the bodies of his wife Tayla Cox, 30, and their 11-week-old daughter, Murphy Margaret.

## Bali tourist slammed for dangerous act while riding on the back of a motorbike
 - [https://www.dailymail.co.uk/news/article-12794659/Bali-tourist-slammed-dangerous-act-riding-motorbike.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12794659/Bali-tourist-slammed-dangerous-act-riding-motorbike.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T08:51:51+00:00

A tourist in Bali has been widely criticised for behaving dangerously while riding on the back of a motorbike on a busy street, as authorities on the popular holiday island crack down on foreigners.

## Woolworths boss Brad Banducci fires back at customers complaining about self-service checkouts
 - [https://www.dailymail.co.uk/news/article-12794629/Woolworths-self-service-checkouts-boss.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12794629/Woolworths-self-service-checkouts-boss.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T07:42:05+00:00

Woolworths CEO Brad Banducci has hit back at one of customers' biggest complaints - self-service check-outs.

## Saleh Atasoy: Manhunt for bikie with ankle tracker after he allegedly fired gun at car during road rage incident
 - [https://www.dailymail.co.uk/news/article-12794553/Saleh-Atasoy-Manhunt-alleged-bikie-gun-road-rage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12794553/Saleh-Atasoy-Manhunt-alleged-bikie-gun-road-rage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T07:36:24+00:00

Detectives on Monday issued an arrest warrant for Saleh Atasoy, a 37-year-old Oxenford man who they allege was behind an attack in Mermaid Waters on the Gold Coast on Friday.

## Suspect, 48, is arrested in shooting of three Vermont Palestinian college students - as cops launch hate crime investigation
 - [https://www.dailymail.co.uk/news/article-12794609/jason-j-Eaton-palestinian-shot-vermont-hate-burlington.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12794609/jason-j-Eaton-palestinian-shot-vermont-hate-burlington.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T06:52:33+00:00

Jason J. Eaton, 48, was seized on Sunday afternoon at the site of the attack.

## 'No matter what the enemy throw at me... I'm not scared!' Arkansas 'squatter bishop' refuses to leave historic church he's been pent up in for FOUR YEARS after owners doubled his rent
 - [https://www.dailymail.co.uk/news/article-12794479/No-matter-enemy-throw-Im-not-scared-Arkansas-squatter-bishop-refuses-leave-historic-church-hes-pent-FOUR-YEARS-owners-doubled-rent.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12794479/No-matter-enemy-throw-Im-not-scared-Arkansas-squatter-bishop-refuses-leave-historic-church-hes-pent-FOUR-YEARS-owners-doubled-rent.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T06:49:44+00:00

A man given the unfriendly nickname as the 'squatter bishop' in an Arkansas Church is refusing to leave the building where he's held services for four years after the landlord doubled his rent.

## The disturbing sign Australia could become completely cashless in just two years
 - [https://www.dailymail.co.uk/news/article-12794017/The-disturbing-sign-Australia-completely-cashless-just-two-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12794017/The-disturbing-sign-Australia-completely-cashless-just-two-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T06:49:26+00:00

Almost three-quarters of transactions for purchases of $10 or less were now done with a card or a digital payment instead of cash. Finance expert Sarah Wells has issued a dire warning.

## Bob Katter wants to change Australian coins: 'Get rid of King Charles'
 - [https://www.dailymail.co.uk/news/article-12794569/Bob-Katter-change-coins-Australia-King.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12794569/Bob-Katter-change-coins-Australia-King.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T06:48:01+00:00

Federal MP Bob Katter wants the King's effigy to be scrapped from the country's coins in favour of significant Australians such as Kokoda hero Ralph Honner.

## Incredible moment Colorado mountain rescue workers save a HOUSE that slips off a cliff edge when semi it was being moved on jackknifes
 - [https://www.dailymail.co.uk/news/article-12794571/Colorado-mountain-HOUSE-slips-cliff-edge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12794571/Colorado-mountain-HOUSE-slips-cliff-edge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T06:37:18+00:00

The 13ft modular home slid over a steep cliffside in the Colorado Rocky Mountains on November 21 - and workers feared the property would crumble like a 'pile of toothpicks.'

## New Zealand scraps world-first smoking ban to help fund tax cuts
 - [https://www.dailymail.co.uk/news/article-12794461/New-Zealand-scraps-world-smoking-ban-help-fund-tax-cuts.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12794461/New-Zealand-scraps-world-smoking-ban-help-fund-tax-cuts.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T06:08:11+00:00

New Zealand 's new conservative government has dismantled world-first plans to ban future generations from smoking.

## Woolworths customers shocked after noticing a major change - but the supermarket giant insists it's for a very good reason
 - [https://www.dailymail.co.uk/news/article-12794361/Woolworths-locks-deodorant-cans-Goodna-store-fears-chroming.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12794361/Woolworths-locks-deodorant-cans-Goodna-store-fears-chroming.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T06:00:50+00:00

The Queensland couple were stunned to see a new safety initiative in the health and beauty aisle at a Goodna store near Ipswich west of Brisbane this week.

## Shocking moment mob of NYC schoolkids repeatedly punch school cop - a week before Jewish teacher was forced to HIDE from 'radicalized' students demanding she be fired for attending pro-Israel rally
 - [https://www.dailymail.co.uk/news/article-12794423/mob-NYC-schoolkids-punch-cop.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12794423/mob-NYC-schoolkids-punch-cop.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T05:54:48+00:00

Hillcrest High School has now been slammed for attempting to 'cover up crimes committed by their students,' as local politicians called for the institution to be shut down and investigated.

## North Bondi rave is shut down by cops as partygoers lash out at 'nanny state'
 - [https://www.dailymail.co.uk/news/article-12794399/North-Bondi-rave-shut-cops-partygoers-lash-nanny-state.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12794399/North-Bondi-rave-shut-cops-partygoers-lash-nanny-state.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T05:53:25+00:00

Hundreds of revellers were left frustrated after police shut down an 'unauthorised' beach rave at Ben Buckler Reserve, North Bondi, in Sydney 's east, late on Sunday afternoon.

## Shocking moment Disneyland guest strips NAKED and crawls around 'It's a Small World' ride - leaving onlookers stunned
 - [https://www.dailymail.co.uk/news/article-12794347/Disneyland-naked-small-world-streaker.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12794347/Disneyland-naked-small-world-streaker.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T05:52:34+00:00

Leaving his clothes in a pile on the floor he climbed out of a boat and plonked himself down in a representation of the Taj Mahal's pool, as Aladdin's flying carpets circled overhead.

## Wild scenes at the US consulate in Melbourne as cops drag pro-Palestine protesters away
 - [https://www.dailymail.co.uk/news/article-12794335/melbourne-consulate-Palestine-protest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12794335/melbourne-consulate-Palestine-protest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T05:36:26+00:00

Four people were arrested after pro- Palestine supporters chained themselves to a gate and covered the entrance way of the US Consulate in Melbourne with red paint and banners. .

## Awkward moment Sydney driver becomes stuck in Cross City Tunnel
 - [https://www.dailymail.co.uk/news/article-12794381/Awkward-moment-Sydney-driver-stuck-Cross-City-Tunnel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12794381/Awkward-moment-Sydney-driver-stuck-Cross-City-Tunnel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T05:35:24+00:00

The embarrassing incident unfolded in Sydney's Cross City tunnel over the weekend, with a driver capturing the whole ordeal on their phone.

## Asylum seekers refuse to wear ankle bracelets - as Albanese government admits ABF officers were unprepared to enforce new rules
 - [https://www.dailymail.co.uk/news/article-12794241/Asylum-seekers-refuse-wear-ankle-bracelets-Albanese-government-admits-ABF-officers-unprepared-enforce-new-rules.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12794241/Asylum-seekers-refuse-wear-ankle-bracelets-Albanese-government-admits-ABF-officers-unprepared-enforce-new-rules.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T05:13:10+00:00

The asylum seekers were released on November 8 after a High Court ruling found that indefinite detention was unlawful.

## Westfield Parramatta and DFO Black Friday hell: Aussies left trapped in cars for hours at sales nightmare
 - [https://www.dailymail.co.uk/news/article-12794089/Westfield-Parramatta-black-Friday-hell-Aussies-trapped-cars-hours.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12794089/Westfield-Parramatta-black-Friday-hell-Aussies-trapped-cars-hours.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T04:42:34+00:00

The popular sales sparked mayhem at two of Sydney's biggest shopping centres in the city's west- Westfield Parramatta and at DFO in Homebush.

## Telling photo shows Outback Wrangler Matt Wright reacting amid fallout after deadly chopper crash bombshell dropped… as mate shares foul-mouthed blast
 - [https://www.dailymail.co.uk/news/article-12793801/Telling-photo-shows-Outback-Wrangler-Matt-Wright-reacting-amid-fallout-deadly-chopper-crash-bombshell-dropped-mate-shares-foul-mouthed-blast.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12793801/Telling-photo-shows-Outback-Wrangler-Matt-Wright-reacting-amid-fallout-deadly-chopper-crash-bombshell-dropped-mate-shares-foul-mouthed-blast.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T04:29:11+00:00

The image of the Outback Wrangler sitting next to a watering hole with his family on Tipperary Station, about 200km south of Darwin, was posted by his friend to X on Saturday night.

## Heroic moment Texas troopers and Border Patrol agents perform CPR on drowning victim and save drenched migrants during mass illegal crossing in Eagle Pass
 - [https://www.dailymail.co.uk/news/article-12794273/Heroic-moment-Texas-troopers-Border-Patrol-agents-perform-CPR-drowning-victim-save-drenched-migrants-mass-illegal-crossing-Eagle-Pass.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12794273/Heroic-moment-Texas-troopers-Border-Patrol-agents-perform-CPR-drowning-victim-save-drenched-migrants-mass-illegal-crossing-Eagle-Pass.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T04:29:06+00:00

Stunning video shows a group of Texas State Troopers and Border Patrol agents going all out to perform CPR on a drowning victim as they saved a group of drenched migrants.

## How a wife dragged her cheating husband  back to brothel after he spent $6,000 over seven hours
 - [https://www.dailymail.co.uk/news/article-12794075/wife-brothel-molendinar-gold-coast-protest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12794075/wife-brothel-molendinar-gold-coast-protest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T04:28:47+00:00

A Gold Coast brothel owner has revealed the wild claim made by a male client before he went on seven-hour sex binge.

## Iran-backed Houthi rebels fire MISSILES at US destroyer off Yemen in 'significant escalation' after American troops freed Israeli-linked tanker from pirates
 - [https://www.dailymail.co.uk/news/article-12794147/Houthi-rebels-MISSILES-Yemen-American.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12794147/Houthi-rebels-MISSILES-Yemen-American.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T03:41:39+00:00

The USS Mason warship responded to a distress call from the commercial tanker, named Central Park, in the Gulf of Aden that had been seized by armed rebels.

## Catiuscia Machado is allegedly murdered by her boyfriend in the bathtub at their Chiswick, inner western Sydney apartment
 - [https://www.dailymail.co.uk/news/article-12794323/Catiuscia-Machado-chiswick-murder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12794323/Catiuscia-Machado-chiswick-murder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T03:30:45+00:00

Diogo De Oliveira, 40, is accused of killing Catiuscia Machado during a domestic incident on Saturday night at their Chiswick unit in Sydney 's inner west.

## Boomers hit back at 'self-entitled whingeing' young Aussies - and reveal why they're not to blame for housing crisis
 - [https://www.dailymail.co.uk/news/article-12793605/Boomers-hit-self-entitled-whingeing-young-Aussies-reveal-theyre-not-blame-housing-crisis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12793605/Boomers-hit-self-entitled-whingeing-young-Aussies-reveal-theyre-not-blame-housing-crisis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T03:30:26+00:00

Tensions rise as Australia's housing crisis deepens, with baby boomers pushing back against accusations of hoarding family homes.

## Shopper sues Coles for 'false imprisonment' in bizarre lawsuit over alleged incident as she bought bread
 - [https://www.dailymail.co.uk/news/article-12793789/Coles-lawsuit-shopper-bread.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12793789/Coles-lawsuit-shopper-bread.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T03:18:53+00:00

The woman alleged she was stopped from leaving Coles at Wanneroo Shopping Centre in Perth's northern suburbs on two occasions after refusing to pay for a newspaper she bought at another shop.

## Shocking video shows suspected murderer stabbing himself to death after cops fired tasers and non-lethal rounds when he asked to be killed
 - [https://www.dailymail.co.uk/news/article-12793921/Loc-Duong-kill-stabbed-tasered-LAPD-suicide.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12793921/Loc-Duong-kill-stabbed-tasered-LAPD-suicide.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T03:08:37+00:00

Graphic police video shows Loc Duong, 67, repeatedly tasered as he lurches with a knife towards officers down an apartment corridor telling them 'I want you to kill me'.

## Man is allegedly shot dead at a home on the same street where detectives believe William Tyrrell's body was buried - as three people are charged
 - [https://www.dailymail.co.uk/news/article-12793655/Man-allegedly-shot-dead-home-street-detectives-believe-William-Tyrrells-body-buried-three-people-charged.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12793655/Man-allegedly-shot-dead-home-street-detectives-believe-William-Tyrrells-body-buried-three-people-charged.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T02:21:33+00:00

One women and two men have been charged over the alleged murder of a 43-year-old man whose body was found at a home at Kendall on the the NSW mid-north-coast.

## Sydney, Melbourne, Brisbane, Perth, weather: When rain will end
 - [https://www.dailymail.co.uk/news/article-12793353/Sydney-Melbourne-Brisbane-Perth-weather-rain-end.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12793353/Sydney-Melbourne-Brisbane-Perth-weather-rain-end.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T02:17:24+00:00

Millions of Aussies are bracing for another wet week as more heavy rain and storms smash the east coast a few days from summer.

## Hamish MacDonald reveals he was 'stricken with paralysing fear' when he hosted ABC's Q&A: 'Hit by a wall of hate'
 - [https://www.dailymail.co.uk/news/article-12793933/Hamish-MacDonald-ABC-qanda-qa-trolling.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12793933/Hamish-MacDonald-ABC-qanda-qa-trolling.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T01:59:45+00:00

Hamish Macdonald hosted the ABC's flagship TV political panel show for 16 months until he dramatically quit in June 2021 after coming under constant attack from online trolls.

## Is this Australia's wokest judge? Chief justice announces sneaky change in 'fight against the patriarchy'
 - [https://www.dailymail.co.uk/news/article-12793897/Queensland-chief-justice-Helen-Bowskill-court-form-change-pronouns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12793897/Queensland-chief-justice-Helen-Bowskill-court-form-change-pronouns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T01:54:09+00:00

Queensland Chief Justice Helen Bowskill has put men in 'their place' and struck a blow 'against the patriarchy' by reversing the   traditional 'Mr/Ms' order on court forms to instead say 'Ms/Ms'.

## 'I'm sorry... I'm disappointed in myself': Joe Biden secretly APOLOGIZES to group of Muslim Americans for casting 'excessive skepticism' on the number of Palestinian deaths released by Gaza's Hamas-run Ministry of Health
 - [https://www.dailymail.co.uk/news/article-12793769/Joe-Biden-secretly-APOLOGIZES-Muslim-Americans.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12793769/Joe-Biden-secretly-APOLOGIZES-Muslim-Americans.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T01:36:01+00:00

The president, 81, faced five Muslim community figureheads who were irate one day after he publicly dismissed a Palestinian death toll on October 25.

## High speed LA police chase ends in huge fireball after stolen Dodge crashes into truck and sends both careening into GAS STATION
 - [https://www.dailymail.co.uk/news/article-12793887/High-speed-LA-police-chase-ends-huge-fireball-stolen-Dodge-crashes-truck-sends-careening-GAS-STATION.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12793887/High-speed-LA-police-chase-ends-huge-fireball-stolen-Dodge-crashes-truck-sends-careening-GAS-STATION.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T01:35:57+00:00

Shocking surveillance video showed the moment a violent crash at the end of a high-speed chase in the Los Angeles area exploded into a massive fireball.

## Schools should be legally required to warn parents if their children are caught vaping, says MP
 - [https://www.dailymail.co.uk/news/article-12793973/teens-vaping.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12793973/teens-vaping.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T01:35:19+00:00

Troy MP Craig Whittaker has made the call following a recent survey shows nine in ten mums and dads want to be informed if their young ones are vaping.

## Forget Black Friday! Cyber Monday is predicted to be the busiest Christmas shopping day of the year for gifts
 - [https://www.dailymail.co.uk/news/article-12794055/Black-Friday-Cyber-Monday-predicted-busiest-Christmas-shopping-day-year-gifts.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12794055/Black-Friday-Cyber-Monday-predicted-busiest-Christmas-shopping-day-year-gifts.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T01:27:13+00:00

Research by retail experts suggests the best bargains of the weekend are likely to be found on Cyber Monday with millions shopping online rather than visiting the High Street.

## Why your Christmas hamper may not be such a bargain basket after all as figures reveal some can be far more expensive than the cost of their individual items
 - [https://www.dailymail.co.uk/news/article-12793335/Why-Christmas-hamper-not-bargain-basket-figures-reveal-far-expensive-cost-individual-items.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12793335/Why-Christmas-hamper-not-bargain-basket-figures-reveal-far-expensive-cost-individual-items.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T01:26:39+00:00

Research by Which? found that a Waitrose Christmas Treats Gift Box was 74 per cent costlier compared with buying the contents individually.

## Schoolchildren are 'abusing' AI to create and send fake nude photos of other pupils, campaigners warn
 - [https://www.dailymail.co.uk/news/article-12794015/Schoolchildren-abusing-AI-create-send-fake-nude-photos-pupils-campaigners-warn.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12794015/Schoolchildren-abusing-AI-create-send-fake-nude-photos-pupils-campaigners-warn.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T01:23:38+00:00

The UK Safer Internet Centre said it is receiving reports from schools that students were using them against other pupils, with fears they could be used for 'blackmail'.

## Desperate search for fisherman after he disappeared off the Sunshine Coast - as emergency crews make disheartening discovery
 - [https://www.dailymail.co.uk/news/article-12794045/Desperate-search-fisherman-disappeared-Sunshine-Coast-emergency-crews-make-chilling-discovery.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12794045/Desperate-search-fisherman-disappeared-Sunshine-Coast-emergency-crews-make-chilling-discovery.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T01:22:31+00:00

The man, aged in his 40s, set out from Mooloolaba when his family reported him missing on Sunday after he failed to return home.

## Keir Starmer appears to row back on plans to spend £28 billion a year on green investments following warnings they could damage the economy
 - [https://www.dailymail.co.uk/news/article-12793995/Keir-Starmer-appears-row-plans-spend-28-billion-year-green-investments-following-warnings-damage-economy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12793995/Keir-Starmer-appears-row-plans-spend-28-billion-year-green-investments-following-warnings-damage-economy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T01:22:24+00:00

Shadow chief secretary to the Treasury, Darren Jones, said the £28bn-a-year commitment would now be met 'towards the end of the next Parliament' should Labour win the election

## AA warns drivers to avoid puddles in case they're perilous potholes after a record month of related breakdowns
 - [https://www.dailymail.co.uk/news/article-12793931/AA-warns-drivers-avoid-puddles-case-theyre-perilous-potholes-record-month-related-breakdowns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12793931/AA-warns-drivers-avoid-puddles-case-theyre-perilous-potholes-record-month-related-breakdowns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T01:15:05+00:00

The AA issued the guidance as it revealed it received 52,541 callouts for vehicles damaged by road defects last month, the most for October on record and 12 per cent up the same month last year.

## BBC is criticised for spending more than £600,000 on 'diversity and inclusion' staff as critics slam taxpayer money being spent on 'woke nonsense'
 - [https://www.dailymail.co.uk/news/article-12794039/BBC-criticised-spending-600-000-diversity-inclusion-staff-critics-slam-taxpayer-money-spent-woke-nonsense.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12794039/BBC-criticised-spending-600-000-diversity-inclusion-staff-critics-slam-taxpayer-money-spent-woke-nonsense.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T01:08:26+00:00

The BBC has been slammed after it emerged it is spending more than £600,000 a year on staff responsible for 'diversity and inclusion'.

## Radical solution to help millions of struggling Aussies pay off their mortgage after aggressive interest rate rises
 - [https://www.dailymail.co.uk/news/article-12793567/Radical-solution-Aussies-superannuation-offset-account-help-pay-mortgage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12793567/Radical-solution-Aussies-superannuation-offset-account-help-pay-mortgage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T01:03:55+00:00

Andrew Bragg, a Liberal Party senator, is calling for Australians to be allowed to divert their superannuation into the bank offset account so they can deal with rising mortgage rates.

## Dick Smith's urgent warning for Albanese's government - as energy minister Chris Bowen rubbishes the idea: 'Fantasy wrapped in a delusion'
 - [https://www.dailymail.co.uk/news/article-12793733/Dick-Smiths-urgent-warning-Albaneses-government-energy-minister-Chris-Bowen-rubbishes-idea-Fantasy-wrapped-delusion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12793733/Dick-Smiths-urgent-warning-Albaneses-government-energy-minister-Chris-Bowen-rubbishes-idea-Fantasy-wrapped-delusion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T00:47:26+00:00

Self-made millionaire Dick Smith has issued some words of advice for Anthony Albanese's government - but energy minister Chris Bowen is not listening.

## Colorado boy, 2, is left horrifically-injured after suffering severe beating while being cared for by care worker 'who was DRINKING'
 - [https://www.dailymail.co.uk/news/article-12793543/McKinley-Hernandez-Giovanni-Stefanie-Reichert-Lakewood-childminder-childcare.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12793543/McKinley-Hernandez-Giovanni-Stefanie-Reichert-Lakewood-childminder-childcare.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T00:21:56+00:00

Stefanie Reichert left baby Giovanni with McKinley Slone Hernandez, 25, for an overnight stay but 
hours later her son was fighting for his life with blunt force trauma injuries to his head and body

## Housebuilding must be trebled to 500,000 every year to match the demand generated by soaring immigration, study warns
 - [https://www.dailymail.co.uk/news/article-12793917/Housebuilding-trebled-500-000-year-match-demand-generated-soaring-immigration-study-warns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12793917/Housebuilding-trebled-500-000-year-match-demand-generated-soaring-immigration-study-warns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T00:19:26+00:00

Housebuilding needs to almost treble to keep pace with the demand generated by soaring immigration, a study warns today.

## Nothing to see here! Cover-up claims as Arizona border patrol sector that saw record 15,300 illegal crossings last week PAUSES sharing photos and updates on the worsening crisis
 - [https://www.dailymail.co.uk/news/article-12793527/Nothing-Cover-claims-Arizona-border-patrol-sector-saw-record-15-300-illegal-crossings-week-PAUSES-sharing-photos-updates-worsening-crisis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12793527/Nothing-Cover-claims-Arizona-border-patrol-sector-saw-record-15-300-illegal-crossings-week-PAUSES-sharing-photos-updates-worsening-crisis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T00:18:36+00:00

The chief of an Arizona Border Patrol sector that has recently seen what he called a 'demoralizing' number of illegal crossings has stopped sharing photos and updates on the crisis.

## The school where teachers are so scared they've gone on STRIKE: Parents and staff reveal the horror of facing racial abuse, threats of sexual assault against female teachers, a warning one would have her throat cut and gang fights galore
 - [https://www.dailymail.co.uk/news/article-12793877/The-school-teachers-scared-theyve-gone-STRIKE-Parents-staff-reveal-horror-facing-racial-abuse-threats-sexual-assault-against-female-teachers-warning-one-throat-cut-gang-fights-galore.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12793877/The-school-teachers-scared-theyve-gone-STRIKE-Parents-staff-reveal-horror-facing-racial-abuse-threats-sexual-assault-against-female-teachers-warning-one-throat-cut-gang-fights-galore.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T00:11:28+00:00

Oasis Academy in Sheerness found itself the subject of newspaper headlines pondering whether it might be the worst school in Britain - a title for which there is stiff competition.

## Mick Gatto fires back at Natalie Barr as she fearlessly posed a question most would be afraid to ask: 'Really don't want to talk about that'
 - [https://www.dailymail.co.uk/news/article-12793583/Mick-Gatto-fires-Natalie-Barr-Sunrise.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12793583/Mick-Gatto-fires-Natalie-Barr-Sunrise.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T00:05:36+00:00

Mick Gatto found himself in the hot seat as veteran journalist Natalie Barr fearlessly posed a question that left many on the edge of their seats.

## Would YOU ride the scariest fairground attraction in the country? Amazing photo of the swing that towers over the Scott Monument
 - [https://www.dailymail.co.uk/news/article-12793153/Would-ride-scariest-fairground-attraction-country-Amazing-photo-swing-towers-Scott-Monument.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12793153/Would-ride-scariest-fairground-attraction-country-Amazing-photo-swing-towers-Scott-Monument.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T00:04:24+00:00

IT HAS towered over Princes Street since the 19th century, a permanent tribute to one of the world's greatest writers.

## Fury as SNP says they WON'T ban deadly XL bully dogs
 - [https://www.dailymail.co.uk/news/article-12793143/Fury-SNP-says-WONT-ban-deadly-XL-bully-dogs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12793143/Fury-SNP-says-WONT-ban-deadly-XL-bully-dogs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T00:04:06+00:00

Nationalist MSPs have been accused of gambling with Scots' lives after refusing to sign up to the Prime Minister's ban on XL Bully dogs.

## Battered on the beat - horrific toll of assaults on Scottish police is revealed
 - [https://www.dailymail.co.uk/news/article-12793149/Battered-beat-horrific-toll-assaults-Scottish-police-revealed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12793149/Battered-beat-horrific-toll-assaults-Scottish-police-revealed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T00:03:42+00:00

Police officers have been stabbed, strangled and beaten in 14,000 frontline assaults as the force reels from yet another night of violent disorder.

## Stephen Daisley: Another shameful betrayal by the SNP… and the broken system that lets them get away with it
 - [https://www.dailymail.co.uk/news/article-12793151/Stephen-Daisley-shameful-betrayal-SNP-broken-lets-away-it.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12793151/Stephen-Daisley-shameful-betrayal-SNP-broken-lets-away-it.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T00:03:12+00:00

Last week brought the news that the SNP 's free laptops scheme was being delayed once again. Finance Secretary Shona Robison said she would 'continue to review

## Home Affairs Secretary Michael Pezzullo is sacked over code of conduct breach
 - [https://www.dailymail.co.uk/news/article-12793729/Home-Affairs-Secretary-Michael-Pezzullo-sacked-code-conduct-breach.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12793729/Home-Affairs-Secretary-Michael-Pezzullo-sacked-code-conduct-breach.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-11-27T00:00:02+00:00

Michael Pezzullo has been terminated from his position as Secretary of the Department of Home Affairs after an inquiry found he had breached the public service code of conduct.

