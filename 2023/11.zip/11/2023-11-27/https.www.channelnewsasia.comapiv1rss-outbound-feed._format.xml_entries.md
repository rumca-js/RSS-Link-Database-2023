# Source:Channel Asia Latest News, URL:https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml, language:en

## Money Talks Podcast: Am I Adulting Right - How to travel on a budget
 - [https://www.channelnewsasia.com/podcasts/money-talks-travel-budget-cheap-hacks-tips-air-tickets-accommodation-sightseeing-3943131](https://www.channelnewsasia.com/podcasts/money-talks-travel-budget-cheap-hacks-tips-air-tickets-accommodation-sightseeing-3943131)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T23:27:02+00:00

That two-week trip to Japan sounds like a balm to cure many busy days. But the cost of travel can limit what you want to do, especially if you are on a tight budget. Our guest shares how you can have fun without breaking the bank.

## This new restaurant and tea room in Singapore transports guests to a bygone Sri Lankan era
 - [https://www.channelnewsasia.com/dining/kunthaville-sri-lankan-restaurant-tea-3943926](https://www.channelnewsasia.com/dining/kunthaville-sri-lankan-restaurant-tea-3943926)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T23:21:00+00:00

Kunthaville, a two-storey heritage shophouse in Little India, serves authentic Sri Lankan cuisine and tea straight from the owner's family's plantations.

## Medical pedicure: How is it different from a normal pedicure and should you get one?
 - [https://www.channelnewsasia.com/style-beauty/medical-pedicure-3831886](https://www.channelnewsasia.com/style-beauty/medical-pedicure-3831886)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T23:16:53+00:00

More than just about prettying up your feet, a medical pedicure can help to address issues such as ingrown toenails, nail fungus and calluses, or just to upkeep the health of your feet.

## Spanish Putellas pulls out of training camp due to knee injury
 - [https://www.channelnewsasia.com/sport/spanish-putellas-pulls-out-training-camp-due-knee-injury-3949786](https://www.channelnewsasia.com/sport/spanish-putellas-pulls-out-training-camp-due-knee-injury-3949786)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T23:09:00+00:00



## Analysis:West's de-risking starts to bite China's prospects
 - [https://www.channelnewsasia.com/business/analysiswests-de-risking-starts-bite-chinas-prospects-3949781](https://www.channelnewsasia.com/business/analysiswests-de-risking-starts-bite-chinas-prospects-3949781)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T23:04:20+00:00



## How a Thai luxury hotel brand is conquering Italy
 - [https://www.channelnewsasia.com/experiences/thai-luxury-hotel-brand-anantara-italy-3938886](https://www.channelnewsasia.com/experiences/thai-luxury-hotel-brand-anantara-italy-3938886)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T23:00:15+00:00

At last count, Anantara and its sister brands have more than 60 hotels operating under multiple brands, including Tivoli, NH Collection, NHOW, Avani Hotels and NH Hotels in Italy.

## AI threat demands new approach to security designs -US official
 - [https://www.channelnewsasia.com/business/ai-threat-demands-new-approach-security-designs-us-official-3949726](https://www.channelnewsasia.com/business/ai-threat-demands-new-approach-security-designs-us-official-3949726)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T22:45:12+00:00



## Cathay favouring Airbus for widely watched freighter deal - sources
 - [https://www.channelnewsasia.com/business/cathay-favouring-airbus-widely-watched-freighter-deal-sources-3949731](https://www.channelnewsasia.com/business/cathay-favouring-airbus-widely-watched-freighter-deal-sources-3949731)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T22:44:12+00:00



## Cathay seen favouring Airbus for widely watched freighter deal
 - [https://www.channelnewsasia.com/business/cathay-seen-favouring-airbus-widely-watched-freighter-deal-3949731](https://www.channelnewsasia.com/business/cathay-seen-favouring-airbus-widely-watched-freighter-deal-3949731)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T22:44:12+00:00



## Willian's penalty double earns Fulham 3-2 win over Wolves
 - [https://www.channelnewsasia.com/sport/willians-penalty-double-earns-fulham-3-2-win-over-wolves-3949671](https://www.channelnewsasia.com/sport/willians-penalty-double-earns-fulham-3-2-win-over-wolves-3949671)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T22:12:21+00:00



## CNA Explains: How the Israel-Hamas war could haunt UN climate change talks
 - [https://www.channelnewsasia.com/sustainability/cop28-climate-change-israel-hamas-war-3943696](https://www.channelnewsasia.com/sustainability/cop28-climate-change-israel-hamas-war-3943696)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T22:05:59+00:00

Nations must enhance cooperation to avoid the most catastrophic effects of climate change. But conflict and the humanitarian crisis in Gaza have deepened distrust ahead of COP28, and could even keep important participants away from the forum.

## Beach resorts and Disneyland: Incentive trips motivate staff and help to recruit talent, say HR experts
 - [https://www.channelnewsasia.com/singapore/paid-trips-employee-rewards-citadel-tokyo-disneyland-evolve-mma-3943851](https://www.channelnewsasia.com/singapore/paid-trips-employee-rewards-citadel-tokyo-disneyland-evolve-mma-3943851)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T22:00:00+00:00

One Singapore-based company organises annual retreats to beach resorts on islands such as Maldives and Bali.

## Commentary: China seeks to lessen developing countries’ reliance on the US dollar
 - [https://www.channelnewsasia.com/commentary/china-yuan-us-dollar-dominant-currency-swap-deal-argentina-3948331](https://www.channelnewsasia.com/commentary/china-yuan-us-dollar-dominant-currency-swap-deal-argentina-3948331)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T22:00:00+00:00

The US dollar remains the dominant currency, but China is driving the yuan as an alternative, says this writer.

## Commentary: In a time of shrinkflation, how will consumers’ elasticity of forgiveness hold up?
 - [https://www.channelnewsasia.com/commentary/shrinkflation-carrefour-warning-posters-customers-brand-loyalty-3945311](https://www.channelnewsasia.com/commentary/shrinkflation-carrefour-warning-posters-customers-brand-loyalty-3945311)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T22:00:00+00:00

In the world of shrinkflation, where product sizes mysteriously shrink while prices stay put, how much can consumers forgive before they walk away? Accenture Song’s Growth Markets president Flaviano Faleiro weighs in.

## Commentary: ‘Double dipping’ - why managers worry that staff have a second job on the sly
 - [https://www.channelnewsasia.com/commentary/remote-work-second-job-secret-moonlight-3948386](https://www.channelnewsasia.com/commentary/remote-work-second-job-secret-moonlight-3948386)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T22:00:00+00:00

There is growing concern that remote workers are secretly working for multiple companies, says the Financial Times’ Pilita Clark.

## Suspect charged for shooting US-Palestinian students
 - [https://www.channelnewsasia.com/world/suspect-charged-shooting-us-palestinian-students-3949241](https://www.channelnewsasia.com/world/suspect-charged-shooting-us-palestinian-students-3949241)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T21:58:56+00:00



## Marketmind: Markets drift but hoping for low vol bounce
 - [https://www.channelnewsasia.com/business/marketmind-markets-drift-hoping-low-vol-bounce-3949626](https://www.channelnewsasia.com/business/marketmind-markets-drift-hoping-low-vol-bounce-3949626)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T21:51:21+00:00



## Chinese fast-fashion retailer Shein files for US IPO - WSJ
 - [https://www.channelnewsasia.com/business/chinese-fast-fashion-retailer-shein-files-us-ipo-wsj-3949616](https://www.channelnewsasia.com/business/chinese-fast-fashion-retailer-shein-files-us-ipo-wsj-3949616)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T21:47:41+00:00



## Shein files to go public in US - WSJ
 - [https://www.channelnewsasia.com/business/shein-files-go-public-us-wsj-3949616](https://www.channelnewsasia.com/business/shein-files-go-public-us-wsj-3949616)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T21:47:41+00:00



## Hamas releases 11 more hostages all dual Israeli citizens
 - [https://www.channelnewsasia.com/world/hamas-releases-11-more-hostages-dual-israeli-citizens-3949601](https://www.channelnewsasia.com/world/hamas-releases-11-more-hostages-dual-israeli-citizens-3949601)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T21:37:02+00:00



## Israel-Hamas truce in Gaza extended two days; 11 more hostages freed
 - [https://www.channelnewsasia.com/world/israel-hamas-war-truce-gaza-extended-more-hostages-freed-3949601](https://www.channelnewsasia.com/world/israel-hamas-war-truce-gaza-extended-more-hostages-freed-3949601)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T21:37:00+00:00



## Ten-man Al-Nassr secure spot in Asian Champions League last 16
 - [https://www.channelnewsasia.com/sport/ten-man-al-nassr-secure-spot-asian-champions-league-last-16-3949576](https://www.channelnewsasia.com/sport/ten-man-al-nassr-secure-spot-asian-champions-league-last-16-3949576)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T21:08:28+00:00



## Howe aims to boost Newcastle's momentum in PSG clash
 - [https://www.channelnewsasia.com/sport/howe-aims-boost-newcastles-momentum-psg-clash-3949501](https://www.channelnewsasia.com/sport/howe-aims-boost-newcastles-momentum-psg-clash-3949501)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T20:08:59+00:00



## Rivian launches leasing for R1T electric pickup truck in some US states
 - [https://www.channelnewsasia.com/business/rivian-launches-leasing-r1t-electric-pickup-truck-some-us-states-3949481](https://www.channelnewsasia.com/business/rivian-launches-leasing-r1t-electric-pickup-truck-some-us-states-3949481)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T19:56:04+00:00



## US federal judge rules against Meta in privacy fight with FTC
 - [https://www.channelnewsasia.com/business/us-federal-judge-rules-against-meta-privacy-fight-ftc-3949461](https://www.channelnewsasia.com/business/us-federal-judge-rules-against-meta-privacy-fight-ftc-3949461)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T19:43:24+00:00



## Former Binance CEO Changpeng Zhao must stay in US for time being, judge says
 - [https://www.channelnewsasia.com/business/former-binance-ceo-changpeng-zhao-must-stay-us-time-being-judge-says-3949426](https://www.channelnewsasia.com/business/former-binance-ceo-changpeng-zhao-must-stay-us-time-being-judge-says-3949426)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T19:13:43+00:00



## Former Binance CEO Changpeng Zhao must stay in US for time being, judge says
 - [https://www.channelnewsasia.com/business/former-binance-crypto-ceo-stay-us-judge-says-3949426](https://www.channelnewsasia.com/business/former-binance-crypto-ceo-stay-us-judge-says-3949426)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T19:13:00+00:00



## More US shoppers tack on buy now, pay later debt for Cyber Monday
 - [https://www.channelnewsasia.com/business/more-us-shoppers-tack-buy-now-pay-later-debt-cyber-monday-3949411](https://www.channelnewsasia.com/business/more-us-shoppers-tack-buy-now-pay-later-debt-cyber-monday-3949411)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T18:57:56+00:00



## Finland PM expecting more asylum seekers to arrive from Russia
 - [https://www.channelnewsasia.com/asia/finland-pm-expecting-more-asylum-seekers-arrive-russia-3948971](https://www.channelnewsasia.com/asia/finland-pm-expecting-more-asylum-seekers-arrive-russia-3948971)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T18:04:53+00:00



## EU antitrust regulators say Amazon's iRobot deal may restrict competition
 - [https://www.channelnewsasia.com/business/eu-antitrust-regulators-say-amazons-irobot-deal-may-restrict-competition-3949376](https://www.channelnewsasia.com/business/eu-antitrust-regulators-say-amazons-irobot-deal-may-restrict-competition-3949376)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T18:04:01+00:00



## Brook, Sciver-Brunt win top prizes at Cricket Writers' Club Awards
 - [https://www.channelnewsasia.com/sport/brook-sciver-brunt-win-top-prizes-cricket-writers-club-awards-3949331](https://www.channelnewsasia.com/sport/brook-sciver-brunt-win-top-prizes-cricket-writers-club-awards-3949331)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T17:35:25+00:00



## Uganda to borrow $150 million from China's Exim after World Bank halts funding
 - [https://www.channelnewsasia.com/business/uganda-borrow-150-million-chinas-exim-after-world-bank-halts-funding-3949246](https://www.channelnewsasia.com/business/uganda-borrow-150-million-chinas-exim-after-world-bank-halts-funding-3949246)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T16:32:46+00:00



## UK detects first human case of flu strain similar to pig virus
 - [https://www.channelnewsasia.com/world/uk-detects-first-human-flu-strain-similar-pig-virus-3948851](https://www.channelnewsasia.com/world/uk-detects-first-human-flu-strain-similar-pig-virus-3948851)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T16:30:00+00:00



## No more wooden medals for RideLondon finishers
 - [https://www.channelnewsasia.com/sport/no-more-wooden-medals-ridelondon-finishers-3949221](https://www.channelnewsasia.com/sport/no-more-wooden-medals-ridelondon-finishers-3949221)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T16:17:22+00:00



## China's Didi Global says ride-hailing app had 'systems malfunction'
 - [https://www.channelnewsasia.com/business/chinas-didi-global-says-ride-hailing-app-had-systems-malfunction-3949191](https://www.channelnewsasia.com/business/chinas-didi-global-says-ride-hailing-app-had-systems-malfunction-3949191)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T16:02:47+00:00



## MotoGP drops CryptoDATA team after "repeated breaches"
 - [https://www.channelnewsasia.com/sport/motogp-drops-cryptodata-team-after-repeated-breaches-3949146](https://www.channelnewsasia.com/sport/motogp-drops-cryptodata-team-after-repeated-breaches-3949146)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T15:33:06+00:00



## Foxconn to invest $1.5 billion to expand India operations
 - [https://www.channelnewsasia.com/business/foxconn-invest-15-billion-expand-india-operations-3949141](https://www.channelnewsasia.com/business/foxconn-invest-15-billion-expand-india-operations-3949141)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T15:29:16+00:00



## Netherlands to allow takeover of chip startup Nowi by Chinese-owned Nexperia
 - [https://www.channelnewsasia.com/business/netherlands-allow-takeover-chip-startup-nowi-chinese-owned-nexperia-3949131](https://www.channelnewsasia.com/business/netherlands-allow-takeover-chip-startup-nowi-chinese-owned-nexperia-3949131)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T15:27:37+00:00



## UN chief pushes for Gaza truce to become full humanitarian ceasefire
 - [https://www.channelnewsasia.com/world/un-chief-pushes-gaza-truce-become-full-humanitarian-ceasefire-3949071](https://www.channelnewsasia.com/world/un-chief-pushes-gaza-truce-become-full-humanitarian-ceasefire-3949071)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T15:20:07+00:00



## Qatar: Israel and Hamas agree to extend truce for two more days
 - [https://www.channelnewsasia.com/world/qatar-israel-and-hamas-agree-extend-truce-two-more-days-3949071](https://www.channelnewsasia.com/world/qatar-israel-and-hamas-agree-extend-truce-two-more-days-3949071)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T15:20:00+00:00



## Vietnam upgrades ties with Japan to highest level
 - [https://www.channelnewsasia.com/asia/vietnam-upgrades-ties-japan-highest-level-south-china-sea-tensions-3948996](https://www.channelnewsasia.com/asia/vietnam-upgrades-ties-japan-highest-level-south-china-sea-tensions-3948996)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T15:14:36+00:00



## SFA investigating video allegedly showing twitching rat on food tray at Tangs Market
 - [https://www.channelnewsasia.com/singapore/rat-tangs-market-food-court-tray-fei-xiong-group-sfa-investigating-3948966](https://www.channelnewsasia.com/singapore/rat-tangs-market-food-court-tray-fei-xiong-group-sfa-investigating-3948966)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T15:12:10+00:00



## Man City's Gvardiol happy to be on same side as Haaland
 - [https://www.channelnewsasia.com/sport/man-citys-gvardiol-happy-be-same-side-haaland-3949086](https://www.channelnewsasia.com/sport/man-citys-gvardiol-happy-be-same-side-haaland-3949086)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T15:02:01+00:00



## Room for improvement for Red Bull? Rivals hope not
 - [https://www.channelnewsasia.com/sport/room-improvement-red-bull-rivals-hope-not-3949041](https://www.channelnewsasia.com/sport/room-improvement-red-bull-rivals-hope-not-3949041)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T14:45:06+00:00



## Russia condemns 'provocative' Israeli attack on Damascus airport
 - [https://www.channelnewsasia.com/world/russia-condemns-provocative-israeli-attack-damascus-airport-3948921](https://www.channelnewsasia.com/world/russia-condemns-provocative-israeli-attack-damascus-airport-3948921)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T14:43:00+00:00



## PSG's Champions League tie with Newcastle is like a final, says Luis Enrique
 - [https://www.channelnewsasia.com/sport/psgs-champions-league-tie-newcastle-final-says-luis-enrique-3949016](https://www.channelnewsasia.com/sport/psgs-champions-league-tie-newcastle-final-says-luis-enrique-3949016)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T14:29:21+00:00



## Britain hopes to attract investment from Chinese carmakers - minister
 - [https://www.channelnewsasia.com/business/britain-hopes-attract-investment-chinese-carmakers-minister-3949021](https://www.channelnewsasia.com/business/britain-hopes-attract-investment-chinese-carmakers-minister-3949021)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T14:28:57+00:00



## AFC Cup tie moved to neutral venue after Australia denies Myanmar club visas
 - [https://www.channelnewsasia.com/sport/afc-cup-tie-moved-neutral-venue-after-australia-denies-myanmar-club-visas-3948066](https://www.channelnewsasia.com/sport/afc-cup-tie-moved-neutral-venue-after-australia-denies-myanmar-club-visas-3948066)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T14:09:50+00:00



## UK's musicMagpie will keep seeking buyers as BT ends talks
 - [https://www.channelnewsasia.com/business/uks-musicmagpie-will-keep-seeking-buyers-bt-ends-talks-3948936](https://www.channelnewsasia.com/business/uks-musicmagpie-will-keep-seeking-buyers-bt-ends-talks-3948936)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T14:08:41+00:00



## L3Harris to sell its commercial aviation solutions business for $800 million
 - [https://www.channelnewsasia.com/business/l3harris-sell-its-commercial-aviation-solutions-business-800-million-3948911](https://www.channelnewsasia.com/business/l3harris-sell-its-commercial-aviation-solutions-business-800-million-3948911)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T13:57:03+00:00



## US Cyber Monday online sales set to cross $12 billion as big discounts lure shoppers - report
 - [https://www.channelnewsasia.com/business/us-cyber-monday-online-sales-set-cross-12-billion-big-discounts-lure-shoppers-report-3948906](https://www.channelnewsasia.com/business/us-cyber-monday-online-sales-set-cross-12-billion-big-discounts-lure-shoppers-report-3948906)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T13:50:16+00:00



## OPEC+ looking at deeper oil cuts ahead of Thursday meeting
 - [https://www.channelnewsasia.com/business/opec-looking-deeper-oil-cuts-ahead-thursday-meeting-3948901](https://www.channelnewsasia.com/business/opec-looking-deeper-oil-cuts-ahead-thursday-meeting-3948901)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T13:46:19+00:00



## OPEC+ to start meeting at 1300 GMT on Thursday; talks continue
 - [https://www.channelnewsasia.com/business/opec-start-meeting-1300-gmt-thursday-talks-continue-3948901](https://www.channelnewsasia.com/business/opec-start-meeting-1300-gmt-thursday-talks-continue-3948901)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T13:46:19+00:00



## Xavi calls on Barcelona fans for vital Champions League tie with Porto
 - [https://www.channelnewsasia.com/sport/xavi-calls-barcelona-fans-vital-champions-league-tie-porto-3948861](https://www.channelnewsasia.com/sport/xavi-calls-barcelona-fans-vital-champions-league-tie-porto-3948861)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T13:20:31+00:00



## German government to agree budget fixes as way out of crisis
 - [https://www.channelnewsasia.com/world/german-government-agree-budget-fixes-way-out-crisis-3948501](https://www.channelnewsasia.com/world/german-government-agree-budget-fixes-way-out-crisis-3948501)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T12:52:10+00:00



## Paris mayor quits X platform, calling it a 'gigantic global sewer'
 - [https://www.channelnewsasia.com/business/paris-mayor-quits-x-platform-calling-it-gigantic-global-sewer-3948786](https://www.channelnewsasia.com/business/paris-mayor-quits-x-platform-calling-it-gigantic-global-sewer-3948786)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T12:46:06+00:00



## Health experts decry New Zealand's scrapping of world-first tobacco ban
 - [https://www.channelnewsasia.com/world/health-experts-decry-new-zealands-scrapping-world-first-tobacco-ban-3948641](https://www.channelnewsasia.com/world/health-experts-decry-new-zealands-scrapping-world-first-tobacco-ban-3948641)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T12:45:00+00:00



## DouYu International forms committee to manage ops after CEO's arrest
 - [https://www.channelnewsasia.com/business/douyu-international-forms-committee-manage-ops-after-ceos-arrest-3948746](https://www.channelnewsasia.com/business/douyu-international-forms-committee-manage-ops-after-ceos-arrest-3948746)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T12:37:50+00:00



## CNA Explains: China's pneumonia outbreak – should you be concerned?
 - [https://www.channelnewsasia.com/asia/china-pneumonia-cna-explains-respiratory-illness-flu-covid-19-pandemic-3948616](https://www.channelnewsasia.com/asia/china-pneumonia-cna-explains-respiratory-illness-flu-covid-19-pandemic-3948616)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T12:33:43+00:00

A surge in respiratory illnesses in the north has led to long waits at pediatric hospitals and medical facilities coming under growing pressure.

## Ineos Grenadiers sign Norwegian Foss
 - [https://www.channelnewsasia.com/sport/ineos-grenadiers-sign-norwegian-foss-3948731](https://www.channelnewsasia.com/sport/ineos-grenadiers-sign-norwegian-foss-3948731)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T12:31:31+00:00



## British great Laura Kenny sets sights on Paris
 - [https://www.channelnewsasia.com/sport/british-great-laura-kenny-sets-sights-paris-3948716](https://www.channelnewsasia.com/sport/british-great-laura-kenny-sets-sights-paris-3948716)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T12:19:04+00:00



## Dairy Farm Residences cuts condo maintenance fees by 40% after complaints
 - [https://www.channelnewsasia.com/singapore/dairy-farm-residences-condo-maintenance-fees-revised-after-complaints-3948001](https://www.channelnewsasia.com/singapore/dairy-farm-residences-condo-maintenance-fees-revised-after-complaints-3948001)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T12:18:29+00:00

The condo’s developer told CNA that it received approval for the revised monthly maintenance charges on Nov 23, and has informed residents of the lowered fees.

## China's central bank pledges to support domestic demand
 - [https://www.channelnewsasia.com/business/chinas-central-bank-pledges-support-domestic-demand-3948706](https://www.channelnewsasia.com/business/chinas-central-bank-pledges-support-domestic-demand-3948706)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T12:16:07+00:00



## China's central bank sets economy guidelines, local debt risks
 - [https://www.channelnewsasia.com/business/chinas-central-bank-sets-economy-guidelines-local-debt-risks-3948706](https://www.channelnewsasia.com/business/chinas-central-bank-sets-economy-guidelines-local-debt-risks-3948706)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T12:16:07+00:00



## China's central bank unveils measures to fortify economy
 - [https://www.channelnewsasia.com/business/chinas-central-bank-unveils-measures-fortify-economy-3948706](https://www.channelnewsasia.com/business/chinas-central-bank-unveils-measures-fortify-economy-3948706)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T12:16:07+00:00



## Sri Lanka approves Sinopec's $4.5 billion refinery proposal
 - [https://www.channelnewsasia.com/business/sri-lanka-approves-sinopecs-45-billion-refinery-proposal-3948676](https://www.channelnewsasia.com/business/sri-lanka-approves-sinopecs-45-billion-refinery-proposal-3948676)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T12:08:02+00:00



## Elephants trample car after it hits calf along Malaysia highway
 - [https://www.channelnewsasia.com/asia/elephants-trample-car-hit-calf-malaysia-east-west-highway-penang-terengganu-3948656](https://www.channelnewsasia.com/asia/elephants-trample-car-hit-calf-malaysia-east-west-highway-penang-terengganu-3948656)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T12:01:52+00:00



## Trump refuses to rule out new migrant family separations, but allies are wary
 - [https://www.channelnewsasia.com/world/donald-trump-immigration-crack-down-presidential-election-2024-3948546](https://www.channelnewsasia.com/world/donald-trump-immigration-crack-down-presidential-election-2024-3948546)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T12:01:03+00:00



## Australia to amend law to regulate digital payments like Apple, Google Pay
 - [https://www.channelnewsasia.com/business/australia-amend-law-regulate-digital-payments-apple-google-pay-3948646](https://www.channelnewsasia.com/business/australia-amend-law-regulate-digital-payments-apple-google-pay-3948646)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T11:52:45+00:00



## Rise in anti-Singapore sentiments online since outbreak of Israel-Hamas hostilities: Shanmugam
 - [https://www.channelnewsasia.com/singapore/shanmugam-anti-singapore-sentiments-online-after-oct-7-hamas-israel-3948091](https://www.channelnewsasia.com/singapore/shanmugam-anti-singapore-sentiments-online-after-oct-7-hamas-israel-3948091)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T11:51:00+00:00

Hamas carried out the Oct 7 attacks with a "high level" of planning but with "low-tech" equipment - lessons that Singapore can draw from a security perspective, says the Law and Home Affairs Minister.

## Japan's TSE starts market maker trial in carbon credit market
 - [https://www.channelnewsasia.com/business/japans-tse-starts-market-maker-trial-carbon-credit-market-3948631](https://www.channelnewsasia.com/business/japans-tse-starts-market-maker-trial-carbon-credit-market-3948631)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T11:43:18+00:00



## COP28 climate summit puts spotlight on turning methane pledges into action
 - [https://www.channelnewsasia.com/sustainability/cop28-climate-change-summit-methane-greenhouse-gas-3948111](https://www.channelnewsasia.com/sustainability/cop28-climate-change-summit-methane-greenhouse-gas-3948111)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T11:28:19+00:00



## Critically endangered Sumatran rhino born in Indonesia
 - [https://www.channelnewsasia.com/sustainability/critically-endangered-indonesia-sumatran-rhino-born-3947956](https://www.channelnewsasia.com/sustainability/critically-endangered-indonesia-sumatran-rhino-born-3947956)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T11:28:11+00:00



## Experts trash Hong Kong's 'throwaway culture' ahead of plastic ban
 - [https://www.channelnewsasia.com/sustainability/hong-kong-plastic-disposable-trash-ban-throwaway-culture-3948176](https://www.channelnewsasia.com/sustainability/hong-kong-plastic-disposable-trash-ban-throwaway-culture-3948176)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T11:28:07+00:00



## Who's at the COP28 climate talks, and what do they want?
 - [https://www.channelnewsasia.com/sustainability/cop28-climate-change-summit-countries-participating-3948171](https://www.channelnewsasia.com/sustainability/cop28-climate-change-summit-countries-participating-3948171)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T11:28:01+00:00



## Amazon agrees deal with most Spanish workers over Cyber Monday walkout
 - [https://www.channelnewsasia.com/business/amazon-agrees-deal-most-spanish-workers-over-cyber-monday-walkout-3948611](https://www.channelnewsasia.com/business/amazon-agrees-deal-most-spanish-workers-over-cyber-monday-walkout-3948611)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T11:27:38+00:00



## Kenaikan 43% perceraian di Malaysia tahun lalu kesan PKP semasa pandemik, kata pakar
 - [https://www.channelnewsasia.com/malaysia/kadar-perceraian-malaysia-melonjak-semasa-pandemik-3948561](https://www.channelnewsasia.com/malaysia/kadar-perceraian-malaysia-melonjak-semasa-pandemik-3948561)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T11:22:43+00:00

Menurut para peguam selain kesan PKP, sikap "moden" generasi muda turut menyumbang kepada sebahagian besar perceraian dari kalangan generasi tersebut.

## In 2024, Republican EV attacks may fall short as swing states reap investment
 - [https://www.channelnewsasia.com/business/2024-republican-ev-attacks-may-fall-short-swing-states-reap-investment-3948591](https://www.channelnewsasia.com/business/2024-republican-ev-attacks-may-fall-short-swing-states-reap-investment-3948591)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T11:22:24+00:00



## Tesla sues Sweden over blocked license plates, business daily DI reports
 - [https://www.channelnewsasia.com/business/tesla-sues-sweden-over-blocked-license-plates-business-daily-di-reports-3948571](https://www.channelnewsasia.com/business/tesla-sues-sweden-over-blocked-license-plates-business-daily-di-reports-3948571)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T11:11:20+00:00



## MotoGP great Rossi to do full world endurance season
 - [https://www.channelnewsasia.com/sport/motogp-great-rossi-do-full-world-endurance-season-3948556](https://www.channelnewsasia.com/sport/motogp-great-rossi-do-full-world-endurance-season-3948556)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T10:59:49+00:00



## Car-sharing is here to stay amid rise in membership sign-ups, say observers
 - [https://www.channelnewsasia.com/singapore/car-sharing-companies-record-jump-sign-ups-over-past-year-high-coe-prices-car-ownership-public-transport-3948511](https://www.channelnewsasia.com/singapore/car-sharing-companies-record-jump-sign-ups-over-past-year-high-coe-prices-car-ownership-public-transport-3948511)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T10:55:59+00:00

This comes amid soaring Certificate of Entitlement (COE) premiums, which have made owning a car too expensive for some people.

## NZ brace for 'hard-fought' series against depleted Bangladesh
 - [https://www.channelnewsasia.com/sport/nz-brace-hard-fought-series-against-depleted-bangladesh-3948531](https://www.channelnewsasia.com/sport/nz-brace-hard-fought-series-against-depleted-bangladesh-3948531)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T10:47:06+00:00



## Vitesco says new Schaeffler offer for EV merger 'inadequate'
 - [https://www.channelnewsasia.com/business/vitesco-says-new-schaeffler-offer-ev-merger-inadequate-3948506](https://www.channelnewsasia.com/business/vitesco-says-new-schaeffler-offer-ev-merger-inadequate-3948506)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T10:32:26+00:00



## Pope's condition after illness 'good and stable': Vatican
 - [https://www.channelnewsasia.com/world/popes-condition-after-illness-good-and-stable-vatican-3948436](https://www.channelnewsasia.com/world/popes-condition-after-illness-good-and-stable-vatican-3948436)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T10:30:08+00:00



## Marini replaces Marc Marquez at Honda on a two-year deal
 - [https://www.channelnewsasia.com/sport/marini-replaces-marc-marquez-honda-two-year-deal-3948491](https://www.channelnewsasia.com/sport/marini-replaces-marc-marquez-honda-two-year-deal-3948491)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T10:11:08+00:00



## Alibaba's research arm shuts quantum computing lab amid restructuring
 - [https://www.channelnewsasia.com/business/alibabas-research-arm-shuts-quantum-computing-lab-amid-restructuring-3948486](https://www.channelnewsasia.com/business/alibabas-research-arm-shuts-quantum-computing-lab-amid-restructuring-3948486)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T10:07:38+00:00



## Standard Chartered Bank China starts digital yuan exchange services
 - [https://www.channelnewsasia.com/business/standard-chartered-bank-china-starts-digital-yuan-exchange-services-3948461](https://www.channelnewsasia.com/business/standard-chartered-bank-china-starts-digital-yuan-exchange-services-3948461)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T09:57:38+00:00



## Shanmugam, Balakrishnan obtain court injunctions against Lee Hsien Yang over defamatory Ridout Road post
 - [https://www.channelnewsasia.com/singapore/shanmugam-vivian-balakrishnan-court-injunctions-lee-hsien-yang-ridout-road-defamation-3948291](https://www.channelnewsasia.com/singapore/shanmugam-vivian-balakrishnan-court-injunctions-lee-hsien-yang-ridout-road-defamation-3948291)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T09:52:09+00:00

The judgment was entered without Mr Lee Hsien Yang's response or participation, but the judge found that the defamation claims would have been made out on a reading of his offending Facebook post.

## US President Joe Biden to skip COP28 climate summit in Dubai
 - [https://www.channelnewsasia.com/world/us-president-joe-biden-skip-cop28-climate-summit-dubai-3947811](https://www.channelnewsasia.com/world/us-president-joe-biden-skip-cop28-climate-summit-dubai-3947811)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T07:16:12+00:00



## Currency clashes sour Russia's oil trade with Asia
 - [https://www.channelnewsasia.com/business/currency-clashes-sour-russias-oil-trade-asia-3948121](https://www.channelnewsasia.com/business/currency-clashes-sour-russias-oil-trade-asia-3948121)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T07:10:07+00:00



## South Korean city turns to matchmaking to boost low birth rates
 - [https://www.channelnewsasia.com/asia/south-korea-seongnam-matchmaking-event-3947981](https://www.channelnewsasia.com/asia/south-korea-seongnam-matchmaking-event-3947981)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T07:08:00+00:00



## China's money market shows signs of liquidity tightness towards month-end
 - [https://www.channelnewsasia.com/business/chinas-money-market-shows-signs-liquidity-tightness-towards-month-end-3948096](https://www.channelnewsasia.com/business/chinas-money-market-shows-signs-liquidity-tightness-towards-month-end-3948096)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T07:02:26+00:00



## Households can donate unused 2023 CDC vouchers to charity from Dec 1
 - [https://www.channelnewsasia.com/singapore/cdc-vouchers-households-donate-unused-charity-3948061](https://www.channelnewsasia.com/singapore/cdc-vouchers-households-donate-unused-charity-3948061)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T06:59:05+00:00



## BP enters Japan's power retail market
 - [https://www.channelnewsasia.com/business/bp-enters-japans-power-retail-market-3948086](https://www.channelnewsasia.com/business/bp-enters-japans-power-retail-market-3948086)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T06:54:51+00:00



## Beijing court begins compensation hearings for MH370 victims
 - [https://www.channelnewsasia.com/asia/mh370-china-beijing-court-compensation-hearings-victims-malaysia-airlines-3948046](https://www.channelnewsasia.com/asia/mh370-china-beijing-court-compensation-hearings-victims-malaysia-airlines-3948046)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T06:42:00+00:00



## BOJ's Ueda: Cannot say with conviction inflation will hit 2% target sustainably
 - [https://www.channelnewsasia.com/business/bojs-ueda-cannot-say-conviction-inflation-will-hit-2-target-sustainably-3948021](https://www.channelnewsasia.com/business/bojs-ueda-cannot-say-conviction-inflation-will-hit-2-target-sustainably-3948021)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T06:23:08+00:00



## Marina Bay Sands to Orchard Road for S$65? MBS acts to tackle taxi touts
 - [https://www.channelnewsasia.com/singapore/marina-bay-sands-taxi-touting-tourists-orchard-road-lta-3947616](https://www.channelnewsasia.com/singapore/marina-bay-sands-taxi-touting-tourists-orchard-road-lta-3947616)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T06:16:00+00:00

Some taxi drivers reportedly quoted fares of S$50 to S$65 for a ride that was just 4km, citing rainy weather and traffic jams.

## 97% of escalator incidents due to improper use, says Building and Construction Authority
 - [https://www.channelnewsasia.com/singapore/escalator-incidents-user-behaviour-97-cent-3947871](https://www.channelnewsasia.com/singapore/escalator-incidents-user-behaviour-97-cent-3947871)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T06:04:46+00:00

Nearly two in 10 incidents were caused by users struggling with bulky items on escalators, including prams, luggage and shopping trolleys.

## Suspended primary school teacher gets jail for sexual abuse of 3 boys in 1990s
 - [https://www.channelnewsasia.com/singapore/suspended-primary-school-teacher-jail-sexual-abuse-3-boys-student-volunteer-3947876](https://www.channelnewsasia.com/singapore/suspended-primary-school-teacher-jail-sexual-abuse-3-boys-student-volunteer-3947876)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T05:55:48+00:00

The man, now 48, was a student volunteer in his late teens when he sexually abused the young boys he was tasked to care for or give tuition to.

## Property agent pocketed S$20,000 from proceeds of condo unit he sold for 80-year-old woman
 - [https://www.channelnewsasia.com/singapore/property-agent-pocket-20k-condo-unit-sell-80-year-old-woman-3947906](https://www.channelnewsasia.com/singapore/property-agent-pocket-20k-condo-unit-sell-80-year-old-woman-3947906)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T05:54:23+00:00

He assured the woman that he would look after her for the rest of her life and got her to set up a joint bank account with him containing the S$462,300 in sale proceeds.

## Singapore households have managed rising interest rates well: MAS
 - [https://www.channelnewsasia.com/business/singapore-household-mortgage-higher-interest-debt-stability-resilience-3947801](https://www.channelnewsasia.com/business/singapore-household-mortgage-higher-interest-debt-stability-resilience-3947801)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T05:21:00+00:00

Households should stay prudent and continue to ensure they have sufficient funds for emergencies, says MAS in its annual financial stability review.

## Beijing exchange suspends share reduction by major shareholders of listed companies - sources
 - [https://www.channelnewsasia.com/business/beijing-exchange-suspends-share-reduction-major-shareholders-listed-companies-sources-3947901](https://www.channelnewsasia.com/business/beijing-exchange-suspends-share-reduction-major-shareholders-listed-companies-sources-3947901)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T05:01:54+00:00



## Exclusive-Beijing stock exchange tells 'major shareholders' to refrain from selling -sources
 - [https://www.channelnewsasia.com/business/exclusive-beijing-stock-exchange-tells-major-shareholders-refrain-selling-sources-3947901](https://www.channelnewsasia.com/business/exclusive-beijing-stock-exchange-tells-major-shareholders-refrain-selling-sources-3947901)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T05:01:54+00:00



## DBS, OCBC and UOB introduce money-locking features to protect against scams
 - [https://www.channelnewsasia.com/singapore/dbs-uob-ocbc-banks-money-locking-features-protect-against-scams-3947701](https://www.channelnewsasia.com/singapore/dbs-uob-ocbc-banks-money-locking-features-protect-against-scams-3947701)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T04:59:00+00:00

Customers can lock up money using internet banking or on their app. These funds can only be unlocked when they visit a bank branch.

## New Zealand to scrap generational smoking ban to help pay for promised tax cuts: Reports
 - [https://www.channelnewsasia.com/world/new-zealand-smoking-generation-ban-scrapped-fund-tax-cuts-3947791](https://www.channelnewsasia.com/world/new-zealand-smoking-generation-ban-scrapped-fund-tax-cuts-3947791)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T04:46:00+00:00



## Paul Rudd says his diet while training for Ant-Man was 'horrible' and 'restrictive'
 - [https://www.channelnewsasia.com/entertainment/paul-rudd-ant-man-diet-3947806](https://www.channelnewsasia.com/entertainment/paul-rudd-ant-man-diet-3947806)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T04:44:27+00:00

Paul Rudd revealed the eating regime he followed for Ant-Man was so strict that he allowed himself some sparkling water as a treat.

## Bradley Cooper would do another Hangover movie in 'an instant'
 - [https://www.channelnewsasia.com/entertainment/bradley-cooper-hangover-possibility-3947781](https://www.channelnewsasia.com/entertainment/bradley-cooper-hangover-possibility-3947781)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T04:41:40+00:00

Bradley Cooper would love to star in another Hangover movie but doubts it will happen.

## China raises fuel oil import quotas by 3 million tons for non-state firms
 - [https://www.channelnewsasia.com/business/china-raises-fuel-oil-import-quotas-3-million-tons-non-state-firms-3947866](https://www.channelnewsasia.com/business/china-raises-fuel-oil-import-quotas-3-million-tons-non-state-firms-3947866)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T04:41:03+00:00



## China’s efforts to lower decoupling risks on show as it holds yet another global trade fair
 - [https://www.channelnewsasia.com/asia/china-supply-chain-expo-global-trade-us-china-ties-3947821](https://www.channelnewsasia.com/asia/china-supply-chain-expo-global-trade-us-china-ties-3947821)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T04:41:00+00:00

US firms make up a fifth of foreign registrations at the China International Supply Chain Expo - a tally described by the organiser as “much higher than expected”.

## Thai October export growth highest in more than a year but misses forecast
 - [https://www.channelnewsasia.com/business/thai-october-export-growth-highest-more-year-misses-forecast-3947786](https://www.channelnewsasia.com/business/thai-october-export-growth-highest-more-year-misses-forecast-3947786)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T04:02:55+00:00



## Thai October exports rise 8.0% y/y, missing forecast
 - [https://www.channelnewsasia.com/business/thai-october-exports-rise-80-y-y-missing-forecast-3947786](https://www.channelnewsasia.com/business/thai-october-exports-rise-80-y-y-missing-forecast-3947786)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T04:02:55+00:00



## 2 contestants of Netflix's Squid Game: The Challenge claim they suffered 'hypothermia and nerve damage' while filming
 - [https://www.channelnewsasia.com/entertainment/squid-game-challenge-netflix-contestants-seeking-compensation-injury-3947681](https://www.channelnewsasia.com/entertainment/squid-game-challenge-netflix-contestants-seeking-compensation-injury-3947681)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T03:32:56+00:00

The contestants are now seeking compensation for the alleged injuries.

## FairPrice to absorb GST increase on 500 items for first half of 2024
 - [https://www.channelnewsasia.com/singapore/ntuc-fairprice-absorb-gst-increase-500-items-2024-six-months-3947516](https://www.channelnewsasia.com/singapore/ntuc-fairprice-absorb-gst-increase-500-items-2024-six-months-3947516)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T03:29:13+00:00

FairPrice Group will also extend its discount schemes for seniors to Dec 31, 2024.

## Pitchside VAR screen a 'farce', says Everton's Dyche
 - [https://www.channelnewsasia.com/sport/pitchside-var-screen-farce-says-evertons-dyche-3947741](https://www.channelnewsasia.com/sport/pitchside-var-screen-farce-says-evertons-dyche-3947741)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T03:26:27+00:00



## Can Taiwan continue to fight off Chinese disinformation?
 - [https://www.channelnewsasia.com/asia/taiwan-china-disinformation-3947641](https://www.channelnewsasia.com/asia/taiwan-china-disinformation-3947641)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T03:18:33+00:00

Ahead of a presidential election in January, Taiwanese fact checkers and watchdogs say they are ready for Beijing. But they are still worried.

## China needs to unblock, sustain financial channels for private firms
 - [https://www.channelnewsasia.com/business/china-needs-unblock-sustain-financial-channels-private-firms-3947711](https://www.channelnewsasia.com/business/china-needs-unblock-sustain-financial-channels-private-firms-3947711)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-11-27T03:12:21+00:00



