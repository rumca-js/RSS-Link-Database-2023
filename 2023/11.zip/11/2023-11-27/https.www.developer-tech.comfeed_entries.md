# Source:Developer Tech News, URL:https://www.developer-tech.com/feed/, language:en-GB

## PHP 8.0 reaches EOL leaving some websites vulnerable
 - [https://www.developer-tech.com/news/2023/nov/27/php-8-0-reaches-eol-leaving-some-websites-vulnerable](https://www.developer-tech.com/news/2023/nov/27/php-8-0-reaches-eol-leaving-some-websites-vulnerable)
 - RSS feed: https://www.developer-tech.com/feed/
 - date published: 2023-11-27T12:43:31+00:00

<p>PHP 8.0 reached its end of life (EOL) on 26 November 2023 and will no longer receive any updates or patches. PHP 8.0 was released on 26 November 2020 and brought many new features and improvements such as named arguments, attributes, constructor property promotion, match expression, nullsafe operator, JIT, and more. The EOL of PHP<a class="excerpt-read-more" href="https://www.developer-tech.com/news/2023/nov/27/php-8-0-reaches-eol-leaving-some-websites-vulnerable/" title="ReadPHP 8.0 reaches EOL leaving some websites vulnerable">... Read more &#187;</a></p>
<p>The post <a href="https://www.developer-tech.com/news/2023/nov/27/php-8-0-reaches-eol-leaving-some-websites-vulnerable/">PHP 8.0 reaches EOL leaving some websites vulnerable</a> appeared first on <a href="https://www.developer-tech.com">Developer Tech News</a>.</p>

