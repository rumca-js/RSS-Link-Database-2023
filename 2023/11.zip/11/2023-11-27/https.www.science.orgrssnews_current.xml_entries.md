# Source:Latest News from Science Magazine, URL:https://www.science.org/rss/news_current.xml, language:en-US

## Cheaper microscope could bring protein mapping technique to the masses
 - [https://www.science.org/content/article/cheaper-microscope-could-bring-protein-mapping-technique-masses](https://www.science.org/content/article/cheaper-microscope-could-bring-protein-mapping-technique-masses)
 - RSS feed: https://www.science.org/rss/news_current.xml
 - date published: 2023-11-27T21:00:58.118391+00:00



## This may be one of the last giant rats of Vangunu
 - [https://www.science.org/content/article/may-be-one-last-giant-rats-vangunu](https://www.science.org/content/article/may-be-one-last-giant-rats-vangunu)
 - RSS feed: https://www.science.org/rss/news_current.xml
 - date published: 2023-11-27T21:00:58.118260+00:00

Camera traps have captured a species that may soon be driven extinct by logging

## Saudi universities lose highly cited researchers after payment schemes raise ethics concerns
 - [https://www.science.org/content/article/saudi-universities-lose-highly-cited-researchers-after-payment-schemes-raise-ethics](https://www.science.org/content/article/saudi-universities-lose-highly-cited-researchers-after-payment-schemes-raise-ethics)
 - RSS feed: https://www.science.org/rss/news_current.xml
 - date published: 2023-11-27T18:52:15.499017+00:00

Crackdown on how researchers list affiliations expected to push Saudi institutions down global rankings

