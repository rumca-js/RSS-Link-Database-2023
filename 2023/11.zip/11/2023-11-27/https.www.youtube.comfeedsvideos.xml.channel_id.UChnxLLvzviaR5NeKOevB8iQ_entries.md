# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## STOPLYING #shorts
 - [https://www.youtube.com/watch?v=Lv1tpnEVbgA](https://www.youtube.com/watch?v=Lv1tpnEVbgA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2023-11-27T16:37:24+00:00

Patreon: https://goo.gl/LMjqBm
Bandcamp: https://goo.gl/41Lxcg
Soundcloud: https://goo.gl/vpTsJX
Spotify: https://goo.gl/h8ryUS
Google Play: https://goo.gl/DqHd4E
iTunes: https://goo.gl/n2fQTc
Amazon Music: https://goo.gl/sRormA
T-Shirts: https://goo.gl/xgGfxv
Twitter: https://goo.gl/drCK9Q
Website: https://goo.gl/GWfhTM

## in the hall of the jazz scat king #aerophone
 - [https://www.youtube.com/watch?v=L-saZbKYuMg](https://www.youtube.com/watch?v=L-saZbKYuMg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2023-11-27T16:36:45+00:00

Support the channel on Patreon: http://bit.ly/rmrpatreon
Take a lesson with me: https://rmr.media/education

Find my music here: 
Bandcamp: http://bit.ly/2Kq617o
Spotify: https://spoti.fi/2N40SoX
YouTube Music: https://bit.ly/3PZQ4ol
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

Connect:
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia

