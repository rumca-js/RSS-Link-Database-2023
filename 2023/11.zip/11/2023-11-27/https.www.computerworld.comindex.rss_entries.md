# Source:ComputerWorld, URL:https://www.computerworld.com/index.rss, language:en-US

## New Amazon Lex AI features aim to let developers quickly build, enhance bots
 - [https://www.infoworld.com/article/3711441/new-amazon-lex-ai-features-aim-to-let-developers-quickly-build-enhance-bots.html#tk.rss_all](https://www.infoworld.com/article/3711441/new-amazon-lex-ai-features-aim-to-let-developers-quickly-build-enhance-bots.html#tk.rss_all)
 - RSS feed: https://www.computerworld.com/index.rss
 - date published: 2023-11-27T14:22:00+00:00

Amazon has added generative AI tools to Lex, its chatbot development tool.

