# Source:Uwaga! Naukowy Bełkot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA, language:pl-PL

## Kaczka to najlepszy ptak - oto 6 powodów
 - [https://www.youtube.com/watch?v=CuWGr4OlEI4](https://www.youtube.com/watch?v=CuWGr4OlEI4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA
 - date published: 2023-11-27T18:50:31+00:00

Kaczy merch jest tutaj
👉  https://naukowybelkot.pl/sklep-belkotowy

Kup moją nową książkę!
📚📚📚 7 CZĄSTECZEK 📚📚📚 
wejdź na https://siedem.alt.pl

👉 Patronite ► https://patronite.pl/NaukowyBelkot 
📚 Moja pierwsza książka ► https://altenberg.pl/geny/
📚 E-book ► https://tinyurl.com/pnp-ebook
🎧 Mix audio ► http://ratstudios.pl/

Przez moje długoletnie związki z żółtą kaczuszką, w konkursie na najlepszego ptaka mógłbym zgłosić tylko jedną kandydaturę. I wcale nie bylbym z miejsca na pozycji straconej...

===
Film o spaniu na Ziemi
https://www.youtube.com/watch?v=-0jjKA_a84A&amp;t=951s

Film o penisie kaczki
https://www.youtube.com/watch?v=KEFm3iRRIcY

===
Rozkład jazdy:
0:00 Wstęp
0:55 Oczy dookoła głowy
2:16 Głosy z jaja
3:52 Ciekawe święto
6:51 Autopromocja
8:04 Kaczka uziemiona
9:50 Formacja kaczątek
12:23 Wyróżnienia
13:37 Myślenie prawie jak człowiek

===
Źródła (wybrane):

Z. Yuan i in. - Wave-riding and wave-passing by ducklings in formation swimming
A. Martinho i in. - Ducklings im

