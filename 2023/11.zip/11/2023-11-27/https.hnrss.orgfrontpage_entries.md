# Source:Hacker News - frontpage, URL:https://hnrss.org/frontpage, language:en-US

## Shein Files for U.S. IPO
 - [https://www.cnbc.com/2023/11/27/shein-files-for-us-ipo-as-fast-fashion-giant-looks-to-expand-its-global-reach.html](https://www.cnbc.com/2023/11/27/shein-files-for-us-ipo-as-fast-fashion-giant-looks-to-expand-its-global-reach.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T22:31:45+00:00

<p>Article URL: <a href="https://www.cnbc.com/2023/11/27/shein-files-for-us-ipo-as-fast-fashion-giant-looks-to-expand-its-global-reach.html">https://www.cnbc.com/2023/11/27/shein-files-for-us-ipo-as-fast-fashion-giant-looks-to-expand-its-global-reach.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38439386">https://news.ycombinator.com/item?id=38439386</a></p>
<p>Points: 16</p>
<p># Comments: 4</p>

## Cory Doctorow: The real AI fight
 - [https://pluralistic.net/2023/11/27/10-types-of-people/#taking-up-a-lot-of-space](https://pluralistic.net/2023/11/27/10-types-of-people/#taking-up-a-lot-of-space)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T22:05:25+00:00

<p>Article URL: <a href="https://pluralistic.net/2023/11/27/10-types-of-people/#taking-up-a-lot-of-space">https://pluralistic.net/2023/11/27/10-types-of-people/#taking-up-a-lot-of-space</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38439082">https://news.ycombinator.com/item?id=38439082</a></p>
<p>Points: 13</p>
<p># Comments: 4</p>

## Range Energy's electric trailer can improve semi-truck mpg by 36%
 - [https://electrek.co/2023/11/27/range-energys-electric-trailer-can-improve-semi-truck-mpg-by-36](https://electrek.co/2023/11/27/range-energys-electric-trailer-can-improve-semi-truck-mpg-by-36)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T21:29:11+00:00

<p>Article URL: <a href="https://electrek.co/2023/11/27/range-energys-electric-trailer-can-improve-semi-truck-mpg-by-36/">https://electrek.co/2023/11/27/range-energys-electric-trailer-can-improve-semi-truck-mpg-by-36/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38438621">https://news.ycombinator.com/item?id=38438621</a></p>
<p>Points: 23</p>
<p># Comments: 5</p>

## Amazon's $195 thin clients are repurposed Fire TV Cubes
 - [https://arstechnica.com/information-technology/2023/11/amazons-195-thin-clients-are-repurposed-fire-tv-cubes](https://arstechnica.com/information-technology/2023/11/amazons-195-thin-clients-are-repurposed-fire-tv-cubes)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T21:05:14+00:00

<p>Article URL: <a href="https://arstechnica.com/information-technology/2023/11/amazons-195-thin-clients-are-repurposed-fire-tv-cubes/">https://arstechnica.com/information-technology/2023/11/amazons-195-thin-clients-are-repurposed-fire-tv-cubes/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38438270">https://news.ycombinator.com/item?id=38438270</a></p>
<p>Points: 22</p>
<p># Comments: 10</p>

## God Help Us, Let's Try to Understand AI Monosemanticity
 - [https://www.astralcodexten.com/p/god-help-us-lets-try-to-understand](https://www.astralcodexten.com/p/god-help-us-lets-try-to-understand)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T21:04:46+00:00

<p>Article URL: <a href="https://www.astralcodexten.com/p/god-help-us-lets-try-to-understand">https://www.astralcodexten.com/p/god-help-us-lets-try-to-understand</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38438261">https://news.ycombinator.com/item?id=38438261</a></p>
<p>Points: 16</p>
<p># Comments: 3</p>

## Ask HN: Tutorial on LLM / already grasp neural nets
 - [https://news.ycombinator.com/item?id=38438202](https://news.ycombinator.com/item?id=38438202)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T20:59:51+00:00

<p>I've watched the 4 videos from 3blue1brown on neural nets. The web and youtube are awash with mediocre videos on Large Language Models. I'm looking for a good one.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38438202">https://news.ycombinator.com/item?id=38438202</a></p>
<p>Points: 4</p>
<p># Comments: 3</p>

## Tesla sues Swedish government after worker rebellion cripples car biz
 - [https://www.theregister.com/2023/11/27/tesla_sweden_strike_lawsuit](https://www.theregister.com/2023/11/27/tesla_sweden_strike_lawsuit)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T20:35:37+00:00

<p>Article URL: <a href="https://www.theregister.com/2023/11/27/tesla_sweden_strike_lawsuit/">https://www.theregister.com/2023/11/27/tesla_sweden_strike_lawsuit/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38437878">https://news.ycombinator.com/item?id=38437878</a></p>
<p>Points: 32</p>
<p># Comments: 12</p>

## Synchronize a 3D scene across multiple windows using Three.js and localStorage
 - [https://github.com/bgstaal/multipleWindow3dScene](https://github.com/bgstaal/multipleWindow3dScene)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T20:27:21+00:00

<p>Article URL: <a href="https://github.com/bgstaal/multipleWindow3dScene">https://github.com/bgstaal/multipleWindow3dScene</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38437773">https://news.ycombinator.com/item?id=38437773</a></p>
<p>Points: 5</p>
<p># Comments: 3</p>

## Évariste Galois
 - [https://en.wikipedia.org/wiki/%C3%89variste_Galois](https://en.wikipedia.org/wiki/%C3%89variste_Galois)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T20:19:21+00:00

<p>Article URL: <a href="https://en.wikipedia.org/wiki/%C3%89variste_Galois">https://en.wikipedia.org/wiki/%C3%89variste_Galois</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38437666">https://news.ycombinator.com/item?id=38437666</a></p>
<p>Points: 14</p>
<p># Comments: 3</p>

## GitHub is investigating an incident with Pull Requests, Issues and Webhooks
 - [https://www.githubstatus.com/incidents/66vhjmd266r9](https://www.githubstatus.com/incidents/66vhjmd266r9)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T20:00:36+00:00

<p>Article URL: <a href="https://www.githubstatus.com/incidents/66vhjmd266r9">https://www.githubstatus.com/incidents/66vhjmd266r9</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38437388">https://news.ycombinator.com/item?id=38437388</a></p>
<p>Points: 51</p>
<p># Comments: 28</p>

## The official Rails job board is live
 - [https://rubyonrails.org/2023/11/27/rails-job-board-is-live](https://rubyonrails.org/2023/11/27/rails-job-board-is-live)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T19:27:58+00:00

<p>Article URL: <a href="https://rubyonrails.org/2023/11/27/rails-job-board-is-live">https://rubyonrails.org/2023/11/27/rails-job-board-is-live</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38436975">https://news.ycombinator.com/item?id=38436975</a></p>
<p>Points: 10</p>
<p># Comments: 0</p>

## Metals: Where Electricity May Flow Without Electrons
 - [https://www.quantamagazine.org/meet-strange-metals-where-electricity-may-flow-without-electrons-20231127](https://www.quantamagazine.org/meet-strange-metals-where-electricity-may-flow-without-electrons-20231127)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T19:18:08+00:00

<p>Article URL: <a href="https://www.quantamagazine.org/meet-strange-metals-where-electricity-may-flow-without-electrons-20231127/">https://www.quantamagazine.org/meet-strange-metals-where-electricity-may-flow-without-electrons-20231127/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38436851">https://news.ycombinator.com/item?id=38436851</a></p>
<p>Points: 8</p>
<p># Comments: 1</p>

## Covid-19 3rd leading cause of death among Canadians in 2022
 - [https://www150.statcan.gc.ca/t1/tbl1/en/cv.action?pid=1310039401](https://www150.statcan.gc.ca/t1/tbl1/en/cv.action?pid=1310039401)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T18:58:14+00:00

<p>Article URL: <a href="https://www150.statcan.gc.ca/t1/tbl1/en/cv.action?pid=1310039401">https://www150.statcan.gc.ca/t1/tbl1/en/cv.action?pid=1310039401</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38436588">https://news.ycombinator.com/item?id=38436588</a></p>
<p>Points: 30</p>
<p># Comments: 7</p>

## 'It gets scary': Neighbors say these Bay Area ghost kitchens are out of control
 - [https://www.sfchronicle.com/food/restaurants/article/ghost-kitchens-neighbors-18483456.php](https://www.sfchronicle.com/food/restaurants/article/ghost-kitchens-neighbors-18483456.php)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T18:57:28+00:00

<p>Article URL: <a href="https://www.sfchronicle.com/food/restaurants/article/ghost-kitchens-neighbors-18483456.php">https://www.sfchronicle.com/food/restaurants/article/ghost-kitchens-neighbors-18483456.php</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38436579">https://news.ycombinator.com/item?id=38436579</a></p>
<p>Points: 15</p>
<p># Comments: 17</p>

## Sports Illustrated Published Articles by Fake, AI-Generated Writers
 - [https://futurism.com/sports-illustrated-ai-generated-writers](https://futurism.com/sports-illustrated-ai-generated-writers)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T18:53:56+00:00

<p>Article URL: <a href="https://futurism.com/sports-illustrated-ai-generated-writers">https://futurism.com/sports-illustrated-ai-generated-writers</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38436516">https://news.ycombinator.com/item?id=38436516</a></p>
<p>Points: 44</p>
<p># Comments: 15</p>

## Broadcom lays off many VMware employees after closing acquisition
 - [https://www.businessinsider.com/broadcom-vmware-layoffs-employees-face-job-cuts-acquisition-2023-11](https://www.businessinsider.com/broadcom-vmware-layoffs-employees-face-job-cuts-acquisition-2023-11)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T18:48:27+00:00

<p>Article URL: <a href="https://www.businessinsider.com/broadcom-vmware-layoffs-employees-face-job-cuts-acquisition-2023-11">https://www.businessinsider.com/broadcom-vmware-layoffs-employees-face-job-cuts-acquisition-2023-11</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38436419">https://news.ycombinator.com/item?id=38436419</a></p>
<p>Points: 102</p>
<p># Comments: 30</p>

## AI is a weapon to surpass Metal Gear
 - [https://xeiaso.net/blog/a-weapon-to-surpass-metal-gear](https://xeiaso.net/blog/a-weapon-to-surpass-metal-gear)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T18:20:05+00:00

<p>Article URL: <a href="https://xeiaso.net/blog/a-weapon-to-surpass-metal-gear/">https://xeiaso.net/blog/a-weapon-to-surpass-metal-gear/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38435978">https://news.ycombinator.com/item?id=38435978</a></p>
<p>Points: 28</p>
<p># Comments: 26</p>

## My Toddler Loves Planes, So I Built Her a Radar
 - [https://jacobbartlett.substack.com/p/my-toddler-loves-planes-so-i-built](https://jacobbartlett.substack.com/p/my-toddler-loves-planes-so-i-built)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T18:16:07+00:00

<p>Article URL: <a href="https://jacobbartlett.substack.com/p/my-toddler-loves-planes-so-i-built">https://jacobbartlett.substack.com/p/my-toddler-loves-planes-so-i-built</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38435908">https://news.ycombinator.com/item?id=38435908</a></p>
<p>Points: 34</p>
<p># Comments: 4</p>

## Organizer invents fake women speakers for DevTernity and JDKon conferences
 - [https://twitter.com/GergelyOrosz/status/1728177708608450705?s=20](https://twitter.com/GergelyOrosz/status/1728177708608450705?s=20)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T17:48:17+00:00

<p>Article URL: <a href="https://twitter.com/GergelyOrosz/status/1728177708608450705?s=20">https://twitter.com/GergelyOrosz/status/1728177708608450705?s=20</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38435481">https://news.ycombinator.com/item?id=38435481</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## Agency: Pure Go LangChain Alternative
 - [https://github.com/neurocult/agency](https://github.com/neurocult/agency)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T17:28:16+00:00

<p>Article URL: <a href="https://github.com/neurocult/agency">https://github.com/neurocult/agency</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38435182">https://news.ycombinator.com/item?id=38435182</a></p>
<p>Points: 3</p>
<p># Comments: 1</p>

## Pinecone Open-Sources AWS Reference Architecture with Pulumi
 - [https://www.pinecone.io/blog/aws-reference-architecture](https://www.pinecone.io/blog/aws-reference-architecture)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T17:26:14+00:00

<p>Article URL: <a href="https://www.pinecone.io/blog/aws-reference-architecture/">https://www.pinecone.io/blog/aws-reference-architecture/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38435145">https://news.ycombinator.com/item?id=38435145</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## ed.bf: text editor in Brainfuck
 - [https://github.com/bf-enterprise-solutions/ed.bf](https://github.com/bf-enterprise-solutions/ed.bf)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T17:15:55+00:00

<p>Article URL: <a href="https://github.com/bf-enterprise-solutions/ed.bf">https://github.com/bf-enterprise-solutions/ed.bf</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38435017">https://news.ycombinator.com/item?id=38435017</a></p>
<p>Points: 24</p>
<p># Comments: 5</p>

## Learnings from fine-tuning LLM on my Telegram messages
 - [https://asmirnov.xyz/doppelganger](https://asmirnov.xyz/doppelganger)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T17:09:37+00:00

<p>Article URL: <a href="https://asmirnov.xyz/doppelganger">https://asmirnov.xyz/doppelganger</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38434914">https://news.ycombinator.com/item?id=38434914</a></p>
<p>Points: 25</p>
<p># Comments: 0</p>

## Several Piracy-Related Arrests Spark Fears of High-Level Crackdown
 - [https://torrentfreak.com/several-piracy-related-arrests-spark-fears-of-high-level-crackdown-231127](https://torrentfreak.com/several-piracy-related-arrests-spark-fears-of-high-level-crackdown-231127)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T16:56:50+00:00

<p>Article URL: <a href="https://torrentfreak.com/several-piracy-related-arrests-spark-fears-of-high-level-crackdown-231127/">https://torrentfreak.com/several-piracy-related-arrests-spark-fears-of-high-level-crackdown-231127/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38434713">https://news.ycombinator.com/item?id=38434713</a></p>
<p>Points: 33</p>
<p># Comments: 10</p>

## Prettier $20k Bounty was Claimed
 - [https://prettier.io/blog/2023/11/27/20k-bounty-was-claimed](https://prettier.io/blog/2023/11/27/20k-bounty-was-claimed)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T16:50:20+00:00

<p>Article URL: <a href="https://prettier.io/blog/2023/11/27/20k-bounty-was-claimed">https://prettier.io/blog/2023/11/27/20k-bounty-was-claimed</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38434613">https://news.ycombinator.com/item?id=38434613</a></p>
<p>Points: 15</p>
<p># Comments: 1</p>

## Show HN: Trains.fyi – a live map of passenger trains in the US and Canada
 - [https://trains.fyi](https://trains.fyi)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T16:47:19+00:00

<p>Hey all! My train the other day was delayed and I got curious where they all were at any given time, so I built a map and figured I'd share it.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38434574">https://news.ycombinator.com/item?id=38434574</a></p>
<p>Points: 48</p>
<p># Comments: 26</p>

## Web Components Eliminate JavaScript Framework Lock-In
 - [https://jakelazaroff.com/words/web-components-eliminate-javascript-framework-lock-in](https://jakelazaroff.com/words/web-components-eliminate-javascript-framework-lock-in)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T16:41:35+00:00

<p>Article URL: <a href="https://jakelazaroff.com/words/web-components-eliminate-javascript-framework-lock-in/">https://jakelazaroff.com/words/web-components-eliminate-javascript-framework-lock-in/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38434470">https://news.ycombinator.com/item?id=38434470</a></p>
<p>Points: 30</p>
<p># Comments: 1</p>

## Nutrient found in beef and dairy improves immune response to cancer
 - [https://biologicalsciences.uchicago.edu/news/tva-nutrient-cancer-immunity](https://biologicalsciences.uchicago.edu/news/tva-nutrient-cancer-immunity)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T15:41:53+00:00

<p>Article URL: <a href="https://biologicalsciences.uchicago.edu/news/tva-nutrient-cancer-immunity">https://biologicalsciences.uchicago.edu/news/tva-nutrient-cancer-immunity</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38433563">https://news.ycombinator.com/item?id=38433563</a></p>
<p>Points: 109</p>
<p># Comments: 50</p>

## Poll_next
 - [https://without.boats/blog/poll-next](https://without.boats/blog/poll-next)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T15:39:26+00:00

<p>Article URL: <a href="https://without.boats/blog/poll-next/">https://without.boats/blog/poll-next/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38433517">https://news.ycombinator.com/item?id=38433517</a></p>
<p>Points: 6</p>
<p># Comments: 1</p>

## Ask HN: What photo sharing solution should we use for our destination wedding?
 - [https://news.ycombinator.com/item?id=38433502](https://news.ycombinator.com/item?id=38433502)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T15:38:28+00:00

<p>I am getting married next week on a beach (yay!)<p>I'd like to collect everyone's photos into a high-res shared album.<p>100 friends/family are joining and we are all staying at a resort for the week. They will be taking lots of great photos during the week!<p>We will have a WhatsApp group chat. In my experience folks tend to send their photos there, but the image quality is very poor once it's uploaded to WhatsApp.<p>My two requirements:<p>1. Should be very low friction for people to upload. No downloading another app.<p>2. Images/videos should remain in original/high quality<p>I am willing to pay for a good solution.<p>Does anyone have any ideas?<p>My ideal solution would be a bot that you could add to a WhatsApp group chat. Images uploaded to the WhatsApp group chat also get automatically uploaded in their original quality to a shared google album. I don't think this is possible.<p>If anyone from WhatsApp/Telegram/Signal/etc is reading this, I would pay a lot for a "Pro" accoun

## AirJet makes a MacBook Air perform like a MacBook Pro
 - [https://www.macworld.com/article/2150862/airjet-makes-a-macbook-air-perform-like-a-macbook-pro.html](https://www.macworld.com/article/2150862/airjet-makes-a-macbook-air-perform-like-a-macbook-pro.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T15:35:10+00:00

<p>Article URL: <a href="https://www.macworld.com/article/2150862/airjet-makes-a-macbook-air-perform-like-a-macbook-pro.html">https://www.macworld.com/article/2150862/airjet-makes-a-macbook-air-perform-like-a-macbook-pro.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38433452">https://news.ycombinator.com/item?id=38433452</a></p>
<p>Points: 79</p>
<p># Comments: 44</p>

## Python Is Easy. Go Is Simple. Simple != Easy
 - [https://preslav.me/2023/11/27/python-is-easy-golang-is-simple-simple-is-not-easy](https://preslav.me/2023/11/27/python-is-easy-golang-is-simple-simple-is-not-easy)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T15:28:04+00:00

<p>Article URL: <a href="https://preslav.me/2023/11/27/python-is-easy-golang-is-simple-simple-is-not-easy/">https://preslav.me/2023/11/27/python-is-easy-golang-is-simple-simple-is-not-easy/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38433358">https://news.ycombinator.com/item?id=38433358</a></p>
<p>Points: 29</p>
<p># Comments: 12</p>

## Robot Dad
 - [https://blog.untrod.com/2023/11/robot-dad.html](https://blog.untrod.com/2023/11/robot-dad.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T15:26:44+00:00

<p>Article URL: <a href="https://blog.untrod.com/2023/11/robot-dad.html">https://blog.untrod.com/2023/11/robot-dad.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38433330">https://news.ycombinator.com/item?id=38433330</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## Favorite Database T-Shirts
 - [https://www.cs.cmu.edu/~pavlo/blog/2016/07/my-favorite-database-shirts.html](https://www.cs.cmu.edu/~pavlo/blog/2016/07/my-favorite-database-shirts.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T15:07:48+00:00

<p>Article URL: <a href="https://www.cs.cmu.edu/~pavlo/blog/2016/07/my-favorite-database-shirts.html">https://www.cs.cmu.edu/~pavlo/blog/2016/07/my-favorite-database-shirts.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38433083">https://news.ycombinator.com/item?id=38433083</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## Google Maps reverse geocoding API can be a thousand miles off
 - [https://placekit.io/blog/articles/google-maps-is-always-right-right-5919](https://placekit.io/blog/articles/google-maps-is-always-right-right-5919)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T15:00:41+00:00

<p>Article URL: <a href="https://placekit.io/blog/articles/google-maps-is-always-right-right-5919">https://placekit.io/blog/articles/google-maps-is-always-right-right-5919</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38432992">https://news.ycombinator.com/item?id=38432992</a></p>
<p>Points: 12</p>
<p># Comments: 3</p>

## Show HN: A Dalle-3 and GPT4-Vision feedback loop
 - [https://dalle.party](https://dalle.party)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T14:18:24+00:00

<p>I used to enjoy Translation Party, and over the weekend I realized that we can build the same feedback loop with DALLE-3 and GPT4-Vision.  Start with a text prompt, let DALLE-3 generate an image, then GPT-4 Vision turns that image back into a text prompt, DALLE-3 creates another image, and so on.<p>You need to bring your own OpenAI API key (costs about $0.10/run)<p>Some prompts are very stable, others go wild. If you bias GPT4's prompting by telling it to "make it weird" you can get crazy results.<p>Here's a few of my favorites:<p>- Gnomes: <a href="https://dalle.party/?party=k4eeMQ6I" rel="nofollow noreferrer">https://dalle.party/?party=k4eeMQ6I</a><p>- Start with a sailboat but bias GPT4V to "replace everything with cats": <a href="https://dalle.party/?party=0uKfJjQn" rel="nofollow noreferrer">https://dalle.party/?party=0uKfJjQn</a><p>- A more stable one (but everyone is always an actor): <a href="https://dalle.party/?party=oxpeZKh5" rel="nofollow noreferrer">https://dalle.party

## Physical attractiveness and intergenerational social mobility
 - [https://onlinelibrary.wiley.com/doi/10.1111/ssqu.13320](https://onlinelibrary.wiley.com/doi/10.1111/ssqu.13320)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T14:15:26+00:00

<p>Article URL: <a href="https://onlinelibrary.wiley.com/doi/10.1111/ssqu.13320">https://onlinelibrary.wiley.com/doi/10.1111/ssqu.13320</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38432451">https://news.ycombinator.com/item?id=38432451</a></p>
<p>Points: 41</p>
<p># Comments: 10</p>

## Download all of Wikipedia on your phone
 - [https://practicalbetterments.com/download-all-of-wikipedia-on-your-phone](https://practicalbetterments.com/download-all-of-wikipedia-on-your-phone)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T14:15:08+00:00

<p>Article URL: <a href="https://practicalbetterments.com/download-all-of-wikipedia-on-your-phone/">https://practicalbetterments.com/download-all-of-wikipedia-on-your-phone/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38432445">https://news.ycombinator.com/item?id=38432445</a></p>
<p>Points: 7</p>
<p># Comments: 1</p>

## GitHub: Can no longer search code without being logged in
 - [https://github.com/orgs/community/discussions/77046](https://github.com/orgs/community/discussions/77046)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T13:56:50+00:00

<p>Article URL: <a href="https://github.com/orgs/community/discussions/77046">https://github.com/orgs/community/discussions/77046</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38432261">https://news.ycombinator.com/item?id=38432261</a></p>
<p>Points: 38</p>
<p># Comments: 18</p>

## Struggles with the Continuum
 - [https://arxiv.org/abs/1609.01421](https://arxiv.org/abs/1609.01421)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T13:40:06+00:00

<p>Article URL: <a href="https://arxiv.org/abs/1609.01421">https://arxiv.org/abs/1609.01421</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38432134">https://news.ycombinator.com/item?id=38432134</a></p>
<p>Points: 28</p>
<p># Comments: 5</p>

## How are zlib, gzip and zip related?
 - [https://stackoverflow.com/questions/20762094/how-are-zlib-gzip-and-zip-related-what-do-they-have-in-common-and-how-are-they](https://stackoverflow.com/questions/20762094/how-are-zlib-gzip-and-zip-related-what-do-they-have-in-common-and-how-are-they)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T13:39:15+00:00

<p>Article URL: <a href="https://stackoverflow.com/questions/20762094/how-are-zlib-gzip-and-zip-related-what-do-they-have-in-common-and-how-are-they">https://stackoverflow.com/questions/20762094/how-are-zlib-gzip-and-zip-related-what-do-they-have-in-common-and-how-are-they</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38432127">https://news.ycombinator.com/item?id=38432127</a></p>
<p>Points: 29</p>
<p># Comments: 4</p>

## FreeBSD 14.0 Delivering Great Performance Uplift
 - [https://www.phoronix.com/review/freebsd-14-epyc](https://www.phoronix.com/review/freebsd-14-epyc)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T13:01:30+00:00

<p>Article URL: <a href="https://www.phoronix.com/review/freebsd-14-epyc">https://www.phoronix.com/review/freebsd-14-epyc</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38431792">https://news.ycombinator.com/item?id=38431792</a></p>
<p>Points: 9</p>
<p># Comments: 1</p>

## Google Drive misplaces months' worth of customer data
 - [https://www.theregister.com/2023/11/27/google_drive_files_disappearing](https://www.theregister.com/2023/11/27/google_drive_files_disappearing)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T12:54:42+00:00

<p>Article URL: <a href="https://www.theregister.com/2023/11/27/google_drive_files_disappearing/">https://www.theregister.com/2023/11/27/google_drive_files_disappearing/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38431743">https://news.ycombinator.com/item?id=38431743</a></p>
<p>Points: 37</p>
<p># Comments: 4</p>

## FPGAs and the Renaissance of Retro Hardware
 - [https://brainbaking.com/post/2023/11/fpgas-and-the-renaissance-of-retro-hardware](https://brainbaking.com/post/2023/11/fpgas-and-the-renaissance-of-retro-hardware)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T12:45:25+00:00

<p>Article URL: <a href="https://brainbaking.com/post/2023/11/fpgas-and-the-renaissance-of-retro-hardware/">https://brainbaking.com/post/2023/11/fpgas-and-the-renaissance-of-retro-hardware/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38431652">https://news.ycombinator.com/item?id=38431652</a></p>
<p>Points: 11</p>
<p># Comments: 1</p>

## $10M AI Mathematical Olympiad Prize
 - [https://aimoprize.com](https://aimoprize.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T12:25:06+00:00

<p>Article URL: <a href="https://aimoprize.com/">https://aimoprize.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38431482">https://news.ycombinator.com/item?id=38431482</a></p>
<p>Points: 66</p>
<p># Comments: 13</p>

## Wealth Systems in RPGs
 - [https://troypress.com/wealth-systems-in-rpgs](https://troypress.com/wealth-systems-in-rpgs)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T12:16:28+00:00

<p>Article URL: <a href="https://troypress.com/wealth-systems-in-rpgs/">https://troypress.com/wealth-systems-in-rpgs/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38431402">https://news.ycombinator.com/item?id=38431402</a></p>
<p>Points: 34</p>
<p># Comments: 7</p>

## Support HTTP over Unix domain sockets
 - [https://bugzilla.mozilla.org/show_bug.cgi?id=1688774](https://bugzilla.mozilla.org/show_bug.cgi?id=1688774)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T12:05:14+00:00

<p>Article URL: <a href="https://bugzilla.mozilla.org/show_bug.cgi?id=1688774">https://bugzilla.mozilla.org/show_bug.cgi?id=1688774</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38431308">https://news.ycombinator.com/item?id=38431308</a></p>
<p>Points: 16</p>
<p># Comments: 9</p>

## OneSignal (YC S11) Is Hiring Engineers
 - [https://onesignal.com/careers](https://onesignal.com/careers)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T12:00:26+00:00

<p>Article URL: <a href="https://onesignal.com/careers">https://onesignal.com/careers</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38431273">https://news.ycombinator.com/item?id=38431273</a></p>
<p>Points: 0</p>
<p># Comments: 0</p>

## Tesla sues Swedish state agency over number plate blockage
 - [https://www.thelocal.se/20231127/tesla-sues-swedish-transport-agency-over-number-plate-blockage](https://www.thelocal.se/20231127/tesla-sues-swedish-transport-agency-over-number-plate-blockage)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T11:43:10+00:00

<p>Article URL: <a href="https://www.thelocal.se/20231127/tesla-sues-swedish-transport-agency-over-number-plate-blockage">https://www.thelocal.se/20231127/tesla-sues-swedish-transport-agency-over-number-plate-blockage</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38431147">https://news.ycombinator.com/item?id=38431147</a></p>
<p>Points: 19</p>
<p># Comments: 19</p>

## German Autobahn speed limit would bring €1bn in benefits
 - [https://www.carbonbrief.org/autobahn-speed-limit-would-cut-carbon-and-bring-e1bn-in-benefits-study-says](https://www.carbonbrief.org/autobahn-speed-limit-would-cut-carbon-and-bring-e1bn-in-benefits-study-says)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T11:26:42+00:00

<p>Article URL: <a href="https://www.carbonbrief.org/autobahn-speed-limit-would-cut-carbon-and-bring-e1bn-in-benefits-study-says/">https://www.carbonbrief.org/autobahn-speed-limit-would-cut-carbon-and-bring-e1bn-in-benefits-study-says/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38431042">https://news.ycombinator.com/item?id=38431042</a></p>
<p>Points: 10</p>
<p># Comments: 29</p>

## Tata Consultancy Services ordered to cough up $210M in code theft trial
 - [https://www.theregister.com/2023/11/24/tata_210m_code_theft](https://www.theregister.com/2023/11/24/tata_210m_code_theft)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T11:18:11+00:00

<p>Article URL: <a href="https://www.theregister.com/2023/11/24/tata_210m_code_theft/">https://www.theregister.com/2023/11/24/tata_210m_code_theft/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38430974">https://news.ycombinator.com/item?id=38430974</a></p>
<p>Points: 24</p>
<p># Comments: 1</p>

## Ransomware-hit British Library: Too open for business, or not open enough?
 - [https://www.theregister.com/2023/11/27/british_library_opinion_column](https://www.theregister.com/2023/11/27/british_library_opinion_column)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T10:57:42+00:00

<p>Article URL: <a href="https://www.theregister.com/2023/11/27/british_library_opinion_column/">https://www.theregister.com/2023/11/27/british_library_opinion_column/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38430831">https://news.ycombinator.com/item?id=38430831</a></p>
<p>Points: 6</p>
<p># Comments: 1</p>

## Switzerland agrees to export 25 Panzer 87 tanks to Germany
 - [https://www.armyrecognition.com/defense_news_november_2023_global_security_army_industry/switzerland_agrees_to_export_25_panzer_87_tanks_to_germany.html](https://www.armyrecognition.com/defense_news_november_2023_global_security_army_industry/switzerland_agrees_to_export_25_panzer_87_tanks_to_germany.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T09:35:31+00:00

<p>Article URL: <a href="https://www.armyrecognition.com/defense_news_november_2023_global_security_army_industry/switzerland_agrees_to_export_25_panzer_87_tanks_to_germany.html">https://www.armyrecognition.com/defense_news_november_2023_global_security_army_industry/switzerland_agrees_to_export_25_panzer_87_tanks_to_germany.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38430232">https://news.ycombinator.com/item?id=38430232</a></p>
<p>Points: 9</p>
<p># Comments: 2</p>

## Where Is OpenCV 5?
 - [https://opencv.org/blog/2023/10/03/where-is-opencv-5](https://opencv.org/blog/2023/10/03/where-is-opencv-5)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T09:18:52+00:00

<p>Article URL: <a href="https://opencv.org/blog/2023/10/03/where-is-opencv-5/">https://opencv.org/blog/2023/10/03/where-is-opencv-5/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38430074">https://news.ycombinator.com/item?id=38430074</a></p>
<p>Points: 9</p>
<p># Comments: 4</p>

## Where Is OpenCV 5?
 - [https://opencv.org/blog/where-is-opencv-5](https://opencv.org/blog/where-is-opencv-5)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T09:18:52+00:00

<p>Article URL: <a href="https://opencv.org/blog/where-is-opencv-5/">https://opencv.org/blog/where-is-opencv-5/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38430074">https://news.ycombinator.com/item?id=38430074</a></p>
<p>Points: 46</p>
<p># Comments: 21</p>

## Amazon EC2 Enhances Defense in Depth with Default IMDSv2
 - [https://www.infoq.com/news/2023/11/aws-ec2-IMDSv2](https://www.infoq.com/news/2023/11/aws-ec2-IMDSv2)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T08:50:18+00:00

<p>Article URL: <a href="https://www.infoq.com/news/2023/11/aws-ec2-IMDSv2/">https://www.infoq.com/news/2023/11/aws-ec2-IMDSv2/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38429817">https://news.ycombinator.com/item?id=38429817</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## Apple's developers reflashed Mac ROMs in the '90s
 - [https://www.downtowndougbrown.com/2023/11/how-apples-developers-reflashed-mac-roms-in-the-90s](https://www.downtowndougbrown.com/2023/11/how-apples-developers-reflashed-mac-roms-in-the-90s)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T08:11:42+00:00

<p>Article URL: <a href="https://www.downtowndougbrown.com/2023/11/how-apples-developers-reflashed-mac-roms-in-the-90s/">https://www.downtowndougbrown.com/2023/11/how-apples-developers-reflashed-mac-roms-in-the-90s/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38429460">https://news.ycombinator.com/item?id=38429460</a></p>
<p>Points: 4</p>
<p># Comments: 1</p>

## Why Bother with uBlock Being Blocked in Chrome? Time to Switch to Firefox
 - [https://tuta.com/blog/best-private-browsers](https://tuta.com/blog/best-private-browsers)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T07:57:20+00:00

<p>Article URL: <a href="https://tuta.com/blog/best-private-browsers">https://tuta.com/blog/best-private-browsers</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38429370">https://news.ycombinator.com/item?id=38429370</a></p>
<p>Points: 11</p>
<p># Comments: 1</p>

## Brother [printers] have gotten to where they are now, by NOT innovating
 - [https://retro.social/@ifixcoinops/111480744130939877](https://retro.social/@ifixcoinops/111480744130939877)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T07:43:06+00:00

<p>Article URL: <a href="https://retro.social/@ifixcoinops/111480744130939877">https://retro.social/@ifixcoinops/111480744130939877</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38429291">https://news.ycombinator.com/item?id=38429291</a></p>
<p>Points: 33</p>
<p># Comments: 15</p>

## No-Bullshit Games
 - [https://nobsgames.stavros.io](https://nobsgames.stavros.io)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T06:59:49+00:00

<p>Article URL: <a href="https://nobsgames.stavros.io/">https://nobsgames.stavros.io/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38429080">https://news.ycombinator.com/item?id=38429080</a></p>
<p>Points: 83</p>
<p># Comments: 18</p>

## Show HN:Draw Fast - Real-time AI image generation based on drawings in a canvas
 - [https://drawfast.io](https://drawfast.io)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T06:55:50+00:00

<p>Article URL: <a href="https://drawfast.io/">https://drawfast.io/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38429060">https://news.ycombinator.com/item?id=38429060</a></p>
<p>Points: 15</p>
<p># Comments: 7</p>

## Getting Started with Orca-2-13B
 - [https://www.secondstate.io/articles/orca-2-13b](https://www.secondstate.io/articles/orca-2-13b)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T05:07:33+00:00

<p>Article URL: <a href="https://www.secondstate.io/articles/orca-2-13b/">https://www.secondstate.io/articles/orca-2-13b/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38428301">https://news.ycombinator.com/item?id=38428301</a></p>
<p>Points: 26</p>
<p># Comments: 9</p>

## Ask HN: Why do half of Internet users think we are living in a simulation?
 - [https://news.ycombinator.com/item?id=38428249](https://news.ycombinator.com/item?id=38428249)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T04:58:24+00:00

<p>My question is inspired by an Internet poll[1]. When it appeared on HN two years ago[2], 45% voted that, yes, we are living in a simulation (of 14,463 votes at the time). When I checked back just now, about half (51%) still voted yes, but now at 4,111,498 votes.<p>Whether we are living in a computer simulation is indeed a fascinating question, and I'm not dismissing it, but there's no proof or experimental evidence for it as far as I know.<p>I know about the simulation argument[3], but that's not a mathematical/physical proof or an experimental result. Lots of brainteasers and paradoxes have arguments structured like the simulation argument; one example is Olbers' paradox: Why is the night sky dark if there is an infinity of stars, covering every part of the celestial sphere? The argument about the stars seems to make sense but it doesn't count as proof or experimental result, and we know it's not true.<p>So I'm wondering how and why so many people are now convinced that we are li

## Dive into Deep Learning: Interactive deep learning book with codes and maths
 - [https://d2l.ai](https://d2l.ai)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T04:55:20+00:00

<p>Article URL: <a href="https://d2l.ai/">https://d2l.ai/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38428225">https://news.ycombinator.com/item?id=38428225</a></p>
<p>Points: 34</p>
<p># Comments: 1</p>

## Housing wealth is meaningless, destructive and fundamentally changing society
 - [https://www.theguardian.com/australia-news/2023/nov/27/australian-housing-wealth-is-meaningless-destructive-and-fundamentally-changing-our-society](https://www.theguardian.com/australia-news/2023/nov/27/australian-housing-wealth-is-meaningless-destructive-and-fundamentally-changing-our-society)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T04:46:15+00:00

<p>Article URL: <a href="https://www.theguardian.com/australia-news/2023/nov/27/australian-housing-wealth-is-meaningless-destructive-and-fundamentally-changing-our-society">https://www.theguardian.com/australia-news/2023/nov/27/australian-housing-wealth-is-meaningless-destructive-and-fundamentally-changing-our-society</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38428169">https://news.ycombinator.com/item?id=38428169</a></p>
<p>Points: 84</p>
<p># Comments: 85</p>

## Any Users of Dropbox Dash? Beginning of Personal LLMs?
 - [https://www.dropbox.com/dash](https://www.dropbox.com/dash)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T04:29:51+00:00

<p>Article URL: <a href="https://www.dropbox.com/dash">https://www.dropbox.com/dash</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38428053">https://news.ycombinator.com/item?id=38428053</a></p>
<p>Points: 4</p>
<p># Comments: 1</p>

## Google Drive has lost user data
 - [https://support.google.com/drive/thread/245055606/google-drive-files-suddenly-disappeared-the-drive-literally-went-back-to-condition-in-may-2023?hl=en](https://support.google.com/drive/thread/245055606/google-drive-files-suddenly-disappeared-the-drive-literally-went-back-to-condition-in-may-2023?hl=en)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T03:55:00+00:00

<p>Article URL: <a href="https://support.google.com/drive/thread/245055606/google-drive-files-suddenly-disappeared-the-drive-literally-went-back-to-condition-in-may-2023?hl=en">https://support.google.com/drive/thread/245055606/google-drive-files-suddenly-disappeared-the-drive-literally-went-back-to-condition-in-may-2023?hl=en</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38427864">https://news.ycombinator.com/item?id=38427864</a></p>
<p>Points: 119</p>
<p># Comments: 42</p>

## College Sports Need Their Tax-Exempt Status Revoked
 - [https://www.bloomberg.com/opinion/articles/2023-11-25/jimbo-fisher-is-why-college-sports-need-to-lose-tax-exemption-status](https://www.bloomberg.com/opinion/articles/2023-11-25/jimbo-fisher-is-why-college-sports-need-to-lose-tax-exemption-status)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T03:48:44+00:00

<p>Article URL: <a href="https://www.bloomberg.com/opinion/articles/2023-11-25/jimbo-fisher-is-why-college-sports-need-to-lose-tax-exemption-status">https://www.bloomberg.com/opinion/articles/2023-11-25/jimbo-fisher-is-why-college-sports-need-to-lose-tax-exemption-status</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38427818">https://news.ycombinator.com/item?id=38427818</a></p>
<p>Points: 20</p>
<p># Comments: 0</p>

## AWS debuts Amazon WorkSpaces Thin Client device for virtual desktop access
 - [https://aws.amazon.com/blogs/aws/new-amazon-workspaces-thin-client](https://aws.amazon.com/blogs/aws/new-amazon-workspaces-thin-client)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T03:41:31+00:00

<p>Article URL: <a href="https://aws.amazon.com/blogs/aws/new-amazon-workspaces-thin-client/">https://aws.amazon.com/blogs/aws/new-amazon-workspaces-thin-client/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38427781">https://news.ycombinator.com/item?id=38427781</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## Beej's Guide to Interprocess Communication
 - [https://beej.us/guide/bgipc/html](https://beej.us/guide/bgipc/html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T02:36:18+00:00

<p>Article URL: <a href="https://beej.us/guide/bgipc/html/">https://beej.us/guide/bgipc/html/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38427448">https://news.ycombinator.com/item?id=38427448</a></p>
<p>Points: 11</p>
<p># Comments: 0</p>

## Pixel 8 Pro owners complain about display bumps
 - [https://me.mashable.com/mobile/35238/pixel-8-pro-owners-complain-about-display-bumps-google-says-there-is-no-functional-impact](https://me.mashable.com/mobile/35238/pixel-8-pro-owners-complain-about-display-bumps-google-says-there-is-no-functional-impact)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T02:36:14+00:00

<p>Article URL: <a href="https://me.mashable.com/mobile/35238/pixel-8-pro-owners-complain-about-display-bumps-google-says-there-is-no-functional-impact">https://me.mashable.com/mobile/35238/pixel-8-pro-owners-complain-about-display-bumps-google-says-there-is-no-functional-impact</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38427447">https://news.ycombinator.com/item?id=38427447</a></p>
<p>Points: 12</p>
<p># Comments: 3</p>

## LaTeX Talks from the Tug Conference 2023 in Bonn
 - [https://www.latex-project.org/news/2023/11/25/TUG-online-talks-2023](https://www.latex-project.org/news/2023/11/25/TUG-online-talks-2023)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T02:18:44+00:00

<p>Article URL: <a href="https://www.latex-project.org/news/2023/11/25/TUG-online-talks-2023/">https://www.latex-project.org/news/2023/11/25/TUG-online-talks-2023/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38427343">https://news.ycombinator.com/item?id=38427343</a></p>
<p>Points: 10</p>
<p># Comments: 0</p>

## Amazon EFS now supports up to 250k IOPS per file system
 - [https://aws.amazon.com/about-aws/whats-new/2023/11/amazon-efs-250000-iops-per-file-system](https://aws.amazon.com/about-aws/whats-new/2023/11/amazon-efs-250000-iops-per-file-system)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T02:13:42+00:00

<p>Article URL: <a href="https://aws.amazon.com/about-aws/whats-new/2023/11/amazon-efs-250000-iops-per-file-system/">https://aws.amazon.com/about-aws/whats-new/2023/11/amazon-efs-250000-iops-per-file-system/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38427314">https://news.ycombinator.com/item?id=38427314</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Kongsberg, Norway and Germany to Develop New "Super Missile"
 - [https://defence-industry.eu/kongsberg-norway-and-germany-to-develop-new-super-missile](https://defence-industry.eu/kongsberg-norway-and-germany-to-develop-new-super-missile)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T02:08:29+00:00

<p>Article URL: <a href="https://defence-industry.eu/kongsberg-norway-and-germany-to-develop-new-super-missile/">https://defence-industry.eu/kongsberg-norway-and-germany-to-develop-new-super-missile/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38427287">https://news.ycombinator.com/item?id=38427287</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## Spaced repetition for teaching two-year olds how to read
 - [https://chipmonk.substack.com/p/spaced-repetition-for-teaching-two](https://chipmonk.substack.com/p/spaced-repetition-for-teaching-two)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T01:24:21+00:00

<p>Article URL: <a href="https://chipmonk.substack.com/p/spaced-repetition-for-teaching-two">https://chipmonk.substack.com/p/spaced-repetition-for-teaching-two</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38427034">https://news.ycombinator.com/item?id=38427034</a></p>
<p>Points: 25</p>
<p># Comments: 7</p>

## Htmx Webring
 - [https://htmx.org/webring](https://htmx.org/webring)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T01:02:24+00:00

<p>Article URL: <a href="https://htmx.org/webring/">https://htmx.org/webring/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38426899">https://news.ycombinator.com/item?id=38426899</a></p>
<p>Points: 9</p>
<p># Comments: 0</p>

## Studio One 6.5 is now available as public beta version for Ubuntu Linux
 - [https://www.presonussoftware.com/en_US/blog/studio-one-6-5-for-linux](https://www.presonussoftware.com/en_US/blog/studio-one-6-5-for-linux)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-27T00:27:17+00:00

<p>Article URL: <a href="https://www.presonussoftware.com/en_US/blog/studio-one-6-5-for-linux">https://www.presonussoftware.com/en_US/blog/studio-one-6-5-for-linux</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38426677">https://news.ycombinator.com/item?id=38426677</a></p>
<p>Points: 15</p>
<p># Comments: 1</p>

