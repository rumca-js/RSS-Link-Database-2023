# Source:ScreenGeek, URL:https://www.screengeek.net/feed/, language:en-US

## Amazon Takes Over Popular Franchise From Netflix
 - [https://www.screengeek.net/2023/11/27/amazon-takes-over-popular-franchise-netflix](https://www.screengeek.net/2023/11/27/amazon-takes-over-popular-franchise-netflix)
 - RSS feed: https://www.screengeek.net/feed/
 - date published: 2023-11-27T16:41:50+00:00

<p>It looks like Netflix is losing a popular action franchise to Amazon. This comes after Netflix spent as much as $30 million to try and create a new installment in said franchise. A new report reveals that &#8220;Amazon MGM Studios is in serious talks to mount a live-action &#8216;Masters of the Universe&#8216; movie from Adam [...]</p>
<p>The post <a href="https://www.screengeek.net/2023/11/27/amazon-takes-over-popular-franchise-netflix/">Amazon Takes Over Popular Franchise From Netflix</a> appeared first on <a href="https://www.screengeek.net">ScreenGeek</a>.</p>

