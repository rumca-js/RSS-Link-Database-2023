# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## Why use many streetlights when one will do?
 - [https://www.youtube.com/watch?v=LDiXNsWQzD0](https://www.youtube.com/watch?v=LDiXNsWQzD0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2023-11-27T16:00:13+00:00

The moonlight towers of Austin, Texas, are the last urban municipal lighting towers in the world: because before every street was wired to the grid, how else would you light up a city? ■ Austin Energy: https://austinenergy.com/ ■ Moonlight Towers https://www.austintexas.org/listings/moonlight-towers/5895/

Producer: Jodi Shores at Sparksight https://sparksight.com
Director: Kelly Shores at @readysetdrone
DoP: Noah Killeen
Drone: Kris Waters
Editor: Michelle Martin https://twitter.com/mrsmmartin

🟥 MORE FROM TOM: https://www.tomscott.com/
(you can find contact details and social links there too)

📰 WEEKLY NEWSLETTER with good stuff from the rest of the internet: https://www.tomscott.com/newsletter/
❓ LATERAL, free weekly podcast: https://lateralcast.com/ https://youtube.com/lateralcast/
➕ TOM SCOTT PLUS: https://youtube.com/tomscottplus
👥 THE TECHNICAL DIFFICULTIES: https://youtube.com/techdif

