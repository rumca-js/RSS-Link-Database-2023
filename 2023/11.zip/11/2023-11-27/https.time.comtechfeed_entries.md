# Source:TIME - tech, URL:https://time.com/tech/feed, language:en-UK

## Meta Knowingly Designed Its Platforms to Hook Kids, Reports Say
 - [https://time.com/6340123/meta-court-child-online-harms](https://time.com/6340123/meta-court-child-online-harms)
 - RSS feed: https://time.com/tech/feed
 - date published: 2023-11-27T19:26:27+00:00

Company documents cited in lawsuit reveal that Facebook parent Meta Platforms deliberately engineered its social platforms to exploit youthful psychology

