# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Apple please watch this.
 - [https://www.youtube.com/watch?v=ji5kZ3VdFDY](https://www.youtube.com/watch?v=ji5kZ3VdFDY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2023-11-27T18:33:16+00:00

Buy a Seasonic TX 1000 PSU: https://geni.us/aryiquT

Purchases made through some store links may provide some compensation to Linus Media Group.

Shop the holiday sale by going to https://www.ridge.com/LINUS and get up to 30% off through December 20th.

We've made the MacBook Air cooler many times, but with the help of Frore Systems this time Apple should pay attention.

Discuss on the forum: https://linustechtips.com/topic/1543827-apple-please-watch-this/

Check out Frore Systems: https://www.froresystems.com/
Buy an Apple M2 MacBook Air: https://geni.us/9CSriF
Buy an Apple M2 MacBook Pro: https://geni.us/UGH6G
Check Out M2 MacBooks at Best Buy: https://lmg.gg/84gIL

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► EQUIPMENT WE USE TO FILM LTT: https://lmg.gg/LTTEquipment
► OU

