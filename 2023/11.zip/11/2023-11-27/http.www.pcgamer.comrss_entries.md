# Source:pcgamer, URL:http://www.pcgamer.com/rss, language:en-US

## Marvel Snap reassures players it will 'continue to operate' despite closure of publisher Nuverse as TikTok parent ByteDance looks to exit gaming
 - [https://www.pcgamer.com/marvel-snap-reassures-players-it-will-continue-to-operate-despite-closure-of-publisher-nuverse-as-tiktok-parent-bytedance-looks-to-exit-gaming](https://www.pcgamer.com/marvel-snap-reassures-players-it-will-continue-to-operate-despite-closure-of-publisher-nuverse-as-tiktok-parent-bytedance-looks-to-exit-gaming)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-11-27T22:40:23+00:00

ByteDance's move into mainstream gaming has come to an unhappy end.

## 6 things PC Gamer's team actually bought on Black Friday and Cyber Monday
 - [https://www.pcgamer.com/6-things-pc-gamers-team-actually-bought-on-black-friday-and-cyber-monday](https://www.pcgamer.com/6-things-pc-gamers-team-actually-bought-on-black-friday-and-cyber-monday)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-11-27T22:33:57+00:00

The deals that we just couldn't resist.

## The Game Awards will beef up security to prevent stage-crashers this year: 'That's top of mind for us,' Geoff Keighley says
 - [https://www.pcgamer.com/the-game-awards-will-beef-up-security-to-prevent-stage-crashers-this-year-thats-top-of-mind-for-us-geoff-keighley-says](https://www.pcgamer.com/the-game-awards-will-beef-up-security-to-prevent-stage-crashers-this-year-thats-top-of-mind-for-us-geoff-keighley-says)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-11-27T21:14:33+00:00

Don't expect a repeat of last year's on-stage weirdness.

## Assassin's Creed: Syndicate, the one about murderous siblings in London during the Industrial Revolution, is free to keep from Ubisoft
 - [https://www.pcgamer.com/assassins-creed-syndicate-the-one-about-murderous-siblings-in-london-during-the-industrial-revolution-is-free-to-keep-from-ubisoft](https://www.pcgamer.com/assassins-creed-syndicate-the-one-about-murderous-siblings-in-london-during-the-industrial-revolution-is-free-to-keep-from-ubisoft)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-11-27T19:36:00+00:00

You've got until December 6 to make it yours.

## Dredge publisher says profits will likely be down this year due to certain games 'not meeting internal expectations'
 - [https://www.pcgamer.com/dredge-publisher-says-profits-will-likely-be-down-this-year-due-to-certain-games-not-meeting-internal-expectations](https://www.pcgamer.com/dredge-publisher-says-profits-will-likely-be-down-this-year-due-to-certain-games-not-meeting-internal-expectations)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-11-27T18:59:27+00:00

Team17 says it remains "well positioned" but plans to reevaluate its portfolio, which also included Gord and Blasphemous 2 this year.

## I am a very large journalist and this Cyber Monday deal on the Secretlab Titan Evo makes me kinda happy
 - [https://www.pcgamer.com/i-am-a-very-large-journalist-and-this-cyber-monday-deal-on-the-secretlab-titan-evo-makes-me-kinda-happy](https://www.pcgamer.com/i-am-a-very-large-journalist-and-this-cyber-monday-deal-on-the-secretlab-titan-evo-makes-me-kinda-happy)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-11-27T18:26:39+00:00

Our favourite gaming chair, also in XL.

## Bungie admits Destiny 2: The Final Shape is being delayed until June: 'We’re taking the time we need to deliver an even bigger and bolder vision'
 - [https://www.pcgamer.com/bungie-admits-destiny-2-the-final-shape-is-being-delayed-until-june-were-taking-the-time-we-need-to-deliver-an-even-bigger-and-bolder-vision](https://www.pcgamer.com/bungie-admits-destiny-2-the-final-shape-is-being-delayed-until-june-were-taking-the-time-we-need-to-deliver-an-even-bigger-and-bolder-vision)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-11-27T17:40:35+00:00

Rumors of the delay first surfaced in October, but now it's official.

## Here are my four favourite Cyber Monday gaming laptop deals still available
 - [https://www.pcgamer.com/here-are-my-four-favourite-cyber-monday-gaming-laptop-deals-still-available](https://www.pcgamer.com/here-are-my-four-favourite-cyber-monday-gaming-laptop-deals-still-available)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-11-27T16:41:01+00:00

From a budget gamer to a monster machine, every one of these is just right.

## David Braben says Frontier Developments has had a ‘turbulent and difficult year’ as Warhammer Age of Sigmar: Realms of Ruin flops
 - [https://www.pcgamer.com/david-braben-says-frontier-developments-has-had-a-turbulent-and-difficult-year-as-warhammer-age-of-sigmar-realms-of-ruin-flops](https://www.pcgamer.com/david-braben-says-frontier-developments-has-had-a-turbulent-and-difficult-year-as-warhammer-age-of-sigmar-realms-of-ruin-flops)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-11-27T16:35:21+00:00

Company expects to lose £9 million this year.

## I have been sitting down almost my entire life and this Corsair TC100 Relaxed Cyber Monday chair deal makes me want to do it some more
 - [https://www.pcgamer.com/i-have-been-sitting-down-almost-my-entire-life-and-this-corsair-tc100-relaxed-cyber-monday-chair-deal-makes-me-want-to-do-it-some-more](https://www.pcgamer.com/i-have-been-sitting-down-almost-my-entire-life-and-this-corsair-tc100-relaxed-cyber-monday-chair-deal-makes-me-want-to-do-it-some-more)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-11-27T16:34:56+00:00

£50 off Corsair's laid-back gaming chair makes for a comfortable deal.

## After Starfield, I thought I was done with large-scale space travel, but Star Citizen's spectacular latest trailer has pulled me right back in
 - [https://www.pcgamer.com/after-starfield-i-thought-i-was-done-with-large-scale-space-travel-but-star-citizens-spectacular-latest-trailer-has-pulled-me-right-back-in](https://www.pcgamer.com/after-starfield-i-thought-i-was-done-with-large-scale-space-travel-but-star-citizens-spectacular-latest-trailer-has-pulled-me-right-back-in)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-11-27T16:26:40+00:00

You had me at "Volumetric clouds at a gas giant scale".

## Hideki Kamiya breaks out the tiny violin for the 9 Bayonetta games he once imagined: 'I may have to take the full saga to the grave'
 - [https://www.pcgamer.com/hideki-kamiya-breaks-out-the-tiny-violin-for-the-9-bayonetta-games-he-once-imagined-i-may-have-to-take-the-full-saga-to-the-grave](https://www.pcgamer.com/hideki-kamiya-breaks-out-the-tiny-violin-for-the-9-bayonetta-games-he-once-imagined-i-may-have-to-take-the-full-saga-to-the-grave)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-11-27T16:15:22+00:00

Hideki Kamiya breaks out the tiny violin for the 9 Bayonetta games he once imagined: 'I may have to take the full saga to the grave'

## Take a break from deal-hunting with the most bamboozling Cyber Monday deals of 2023
 - [https://www.pcgamer.com/take-a-break-from-deal-hunting-with-the-most-bamboozling-cyber-monday-deals-of-2023](https://www.pcgamer.com/take-a-break-from-deal-hunting-with-the-most-bamboozling-cyber-monday-deals-of-2023)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-11-27T15:53:14+00:00

The strangest and worst Cyber Monday deals out there.

## The best Cyber Monday gaming monitor deal is giving us 34 inches of OLED Alienware for its lowest price ever
 - [https://www.pcgamer.com/the-best-cyber-monday-gaming-monitor-deal-is-giving-us-34-inches-of-oled-alienware-for-its-lowest-price-ever](https://www.pcgamer.com/the-best-cyber-monday-gaming-monitor-deal-is-giving-us-34-inches-of-oled-alienware-for-its-lowest-price-ever)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-11-27T15:25:27+00:00

"Absolutely farking fabulous."

## I'm tracking all the best Cyber Monday SSD deals live right now, join me in my palace of storage dreams
 - [https://www.pcgamer.com/live/news/cyber-monday-ssd-deals-live-now](https://www.pcgamer.com/live/news/cyber-monday-ssd-deals-live-now)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-11-27T12:55:53+00:00

I'm keeping a beady eye on all the best Cyber Monday SSD deals live on this page, so roll up roll up, let's find some fast storage!

## The best thing I did this deals season was revive my old desktop with a cheap SSD
 - [https://www.pcgamer.com/the-best-thing-i-did-this-deals-season-was-revive-my-old-desktop-with-a-cheap-ssd](https://www.pcgamer.com/the-best-thing-i-did-this-deals-season-was-revive-my-old-desktop-with-a-cheap-ssd)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-11-27T12:44:11+00:00

4TB might be nice, but 1TB gets the job done: and I don't have the money to burn anyway.

## Silent Hill 2 remake devs try to calm down fans, saying (for the second time) that it's on Konami to share anything: 'we kindly ask for a bit more patience'
 - [https://www.pcgamer.com/silent-hill-2-remake-devs-try-to-calm-down-fans-saying-for-the-second-time-that-its-on-konami-to-share-anything-we-kindly-ask-for-a-bit-more-patience](https://www.pcgamer.com/silent-hill-2-remake-devs-try-to-calm-down-fans-saying-for-the-second-time-that-its-on-konami-to-share-anything-we-kindly-ask-for-a-bit-more-patience)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-11-27T12:31:34+00:00

Hands tied.

## You can buy this forgotten '90s shooter from its original website, which is a perfectly preserved time capsule of PC gaming's golden age
 - [https://www.pcgamer.com/you-can-buy-this-forgotten-90s-shooter-from-its-original-website-which-is-a-perfectly-preserved-time-capsule-of-pc-gamings-golden-age](https://www.pcgamer.com/you-can-buy-this-forgotten-90s-shooter-from-its-original-website-which-is-a-perfectly-preserved-time-capsule-of-pc-gamings-golden-age)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-11-27T12:31:21+00:00

Bad Toys 3D is available on Tibo Software's website for $9.95.

## Remnant 2 player gets punished with eternal torment upon the spike after drawing with a DLC boss
 - [https://www.pcgamer.com/remnant-2-player-gets-punished-to-eternal-torment-upon-the-spike-after-drawing-with-a-dlc-boss](https://www.pcgamer.com/remnant-2-player-gets-punished-to-eternal-torment-upon-the-spike-after-drawing-with-a-dlc-boss)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-11-27T11:29:41+00:00

Eventually, the traveller stopped thinking.

## Wordle today: Hint and answer #891 for Monday, November 27
 - [https://www.pcgamer.com/wordle-today-answer-891-november-27](https://www.pcgamer.com/wordle-today-answer-891-november-27)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-11-27T04:01:56+00:00

Today's Wordle: Help with solving Monday's puzzle.

## Pony-inspired fighting game Them's Fightin' Herds abandons its unfinished story mode
 - [https://www.pcgamer.com/pony-inspired-fighting-game-thems-fightin-herds-abandons-its-unfinished-story-mode](https://www.pcgamer.com/pony-inspired-fighting-game-thems-fightin-herds-abandons-its-unfinished-story-mode)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-11-27T01:36:34+00:00

It'll cease active development next year.

