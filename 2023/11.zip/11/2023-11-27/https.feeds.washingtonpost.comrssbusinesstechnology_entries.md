# Source:The Washington Post - Tech, URL:https://feeds.washingtonpost.com/rss/business/technology, language:en-US

## NameDrop is safe. The fearmongering about it is not.
 - [https://www.washingtonpost.com/technology/2023/11/27/namedrop-iphone-ios17-safety](https://www.washingtonpost.com/technology/2023/11/27/namedrop-iphone-ios17-safety)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-11-27T19:53:52+00:00

Local police have been warning about the safety of the NameDrop feature in iPhones to wirelessly share contact information. Don’t worry. They’re wrong.

## Elon Musk meets with Netanyahu in Israel, tours kibbutz attacked by Hamas
 - [https://www.washingtonpost.com/business/2023/11/27/elon-musk-israel-starlink-netanyahu](https://www.washingtonpost.com/business/2023/11/27/elon-musk-israel-starlink-netanyahu)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-11-27T14:09:28+00:00

The SpaceX founder said he found it “troubling” to see the joy on the faces of Hamas militants as they killed innocent people.

## The new dating app etiquette
 - [https://www.washingtonpost.com/technology/2023/11/27/dating-app-etiquette](https://www.washingtonpost.com/technology/2023/11/27/dating-app-etiquette)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-11-27T11:00:00+00:00

Want to snag a partner? Treat them kindly right from the start.

