# Source:HackRead, URL:https://www.hackread.com/feed, language:en-US

## General Electric Probes Security Breach as Hackers Sell DARPA-Related Access
 - [https://www.hackread.com/general-electric-security-breach-hackers-darpa-data](https://www.hackread.com/general-electric-security-breach-hackers-darpa-data)
 - RSS feed: https://www.hackread.com/feed
 - date published: 2023-11-27T19:04:27+00:00

<p>By <a href="https://www.hackread.com/author/hackread/" rel="nofollow">Waqas</a></p>
<p>The data breach was announced by IntelBroker, a threat actor mostly known for data breaches against delivery and logistics companies.</p>
<p>This is a post from HackRead.com Read the original post: <a href="https://www.hackread.com/general-electric-security-breach-hackers-darpa-data/" rel="nofollow">General Electric Probes Security Breach as Hackers Sell DARPA-Related Access</a></p>

## Study Finds Amazon, eBay and Afterpay as Top Android User Data Collectors
 - [https://www.hackread.com/amazon-ebay-afterpay-android-apps-collect-data](https://www.hackread.com/amazon-ebay-afterpay-android-apps-collect-data)
 - RSS feed: https://www.hackread.com/feed
 - date published: 2023-11-27T14:16:09+00:00

<p>By <a href="https://www.hackread.com/author/deeba/" rel="nofollow">Deeba Ahmed</a></p>
<p>Amazon and eBay have been declared the highest data-collecting platforms among all the Android shopping apps researchers examined.</p>
<p>This is a post from HackRead.com Read the original post: <a href="https://www.hackread.com/amazon-ebay-afterpay-android-apps-collect-data/" rel="nofollow">Study Finds Amazon, eBay and Afterpay as Top Android User Data Collectors</a></p>

