# Source:Jake Tran, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ, language:en-US

## Where does foreign aid ACTUALLY go?
 - [https://www.youtube.com/watch?v=s2jKehS1r6U](https://www.youtube.com/watch?v=s2jKehS1r6U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ
 - date published: 2023-11-27T19:47:31+00:00

📦 Get a 60-day free trial at → https://www.shipstation.com/jaketran. Thanks to ShipStation for sponsoring the show!

Click HERE to learn if term limits are even possible on @SeanMSpicer's channel! ➡️ https://youtu.be/DifeV66NOBM

💻 Learn exactly how I landed my $40/hr work-from-home job ($83k/yr) at 19 years old WITHOUT a degree or experience ✅ Click here ➡️ https://www.evil.university/remote

😳 Learn the ONE SECRET that has made every giant corporation and government successful ➡️ https://evil.university/war 

😈 Watch exclusive documentaries that are too controversial to ever be released to the public: https://jake.yt/join 
Updated refund policy: Email us within your first month of joining and we'll refund you for your first month. There is no refund if you cancel at a later time.

📹 Take a peak at all the private documentaries here: https://jake.yt/hidden-vids

🟢 Watch and listen to our videos on Spotify! https://jake.yt/spotify

🐤 Follow me on Twitter: @jaketrann https://jake.yt/x

