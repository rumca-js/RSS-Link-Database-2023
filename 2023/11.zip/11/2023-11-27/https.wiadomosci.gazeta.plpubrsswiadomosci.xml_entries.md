# Source:Wiadomosci - Gazeta.pl, URL:https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml, language:pl-PL

## Jacek Ozdoba przez dwa tygodnie będzie ministrem bez teki. "Nie ma w tym nic zaskakującego"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30449836,jacek-ozdoba-przez-dwa-tygodnie-bedzie-ministrem-bez-teki-nie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30449836,jacek-ozdoba-przez-dwa-tygodnie-bedzie-ministrem-bez-teki-nie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T21:22:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/0e/0a/1d/z30449934M,Jacek-Ozdoba.jpg" vspace="2" />Jacek Ozdoba został w nowym rządzie Mateusza Morawieckiego ministrem bez teki. Czym się będzie zajmował przez dwa tygodnie - tego jeszcze nie wiadomo. - Zakres moich kompetencji opinia publiczna pozna zapewne jutro. W każdym gabinecie jest członek Rady MinistrĂłw bez teki, nie ma w tym nic zaskakującego - mĂłwi w rozmowie z Gazeta.pl polityk Suwerennej Polski.

## PiS wprowadza zmiany. Powołało 17 nowych szefĂłw. "Chcemy się jak najlepiej przygotować"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30449883,pis-wprowadza-zmiany-powolalo-17-nowych-szefow-chcemy-sie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30449883,pis-wprowadza-zmiany-powolalo-17-nowych-szefow-chcemy-sie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T21:12:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/71/08/1d/z30444145M,Politycy-PiS-w-lawach-poselskich.jpg" vspace="2" />W 17 okręgach Prawo i Sprawiedliwość powołało nowych szefĂłw. Terytorialnie odpowiadają one wojewĂłdztwom. Władzę objęli w nich politycy młodszego pokolenia. - Przed nami ważny czas i niezwykle istotne wybory samorządowe oraz europejskie - przekazał rzecznik partii Rafał Bochenek.

## Gafa podczas zaprzysiężenia rządu Mateusza Morawieckiego. "Wygląda to niepoważnie"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30449820,wpadka-podczas-zaprzysiezenia-rzadu-mateusza-morawieckiego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30449820,wpadka-podczas-zaprzysiezenia-rzadu-mateusza-morawieckiego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T21:03:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/0c/0a/1d/z30449932M,Urzednicy-z-telefonami.jpg" vspace="2" />Podczas zaprzysiężenia nowego rządu premiera Mateusza Morawiecki dwaj urzędnicy zwrĂłcili na siebie szczegĂłlną uwagę - gdy ministrowie składali przysięgi, mężczyźni byli zajęci swoimi telefonami. - Powaga uroczystości wymaga powagi zachowania - zauważył dr Janusz Sibora.

## Byli poszukiwani w całej Europie. Zatrzymali ich "łowcy cieni". To pseudokibice z Radomia? [WIDEO]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30446428,lowcy-cieni-z-polski-zatrzymali-poszukiwanych-w-calej-ue.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30446428,lowcy-cieni-z-polski-zatrzymali-poszukiwanych-w-calej-ue.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T21:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/1b/09/1d/z30446875M,-Lowcy-cieni--z-CBSP-zatrzymali-mezczyzn-poszukiwa.jpg" vspace="2" />Mężczyźni poszukiwani Europejskim Nakazem Aresztowania zostali zatrzymani przez funkcjonariuszy Centralnego Biura Śledczego Policji. Polscy "łowcy cieni" opisali okoliczności, w jakich schwytano osoby podejrzane o popełnienie poważnych przestępstw.

## Zaprzysiężenie rządu. Politolożka: Smutna uroczystość. Koniec Morawieckiego jako politycznego lidera
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30449688,zaprzysiezenie-rzadu-politolozka-smutna-uroczystosc-koniec.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30449688,zaprzysiezenie-rzadu-politolozka-smutna-uroczystosc-koniec.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T20:02:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/72/0a/1d/z30449778M,Zaprzysiezenie-nowego-rzadu-Mateusza-Morawieckiego.jpg" vspace="2" />- Cały ten proces tworzenia rządu przez premiera okazał się dość żałosny. Jak widzimy, sięgnięto do na prawdę dalekich szeregĂłw - komentuje w Gazeta.pl zaprzysiężenie nowego rządu Matausza Morawieckiego dr Anna Materska-Sosnowska.

## Alerty IMGW. Śnieżyce i wielkie ochłodzenie na południu kraju. Cyklon Oliver przyniesie prawdziwą zimę
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30449671,alerty-imgw-sniezyce-i-wielkie-ochlodzenie-na-poludniu-kraju.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30449671,alerty-imgw-sniezyce-i-wielkie-ochlodzenie-na-poludniu-kraju.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T19:34:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/80/0a/1d/z30449792M,Sniezyce-nadciagaja-do-Polski.jpg" vspace="2" />Synoptycy ostrzegają przed intensywnymi opadami śniegu na południu kraju. Ostrzeżenie pierwszego stopnia wydano dla sześciu wojewĂłdztw. "Wysokość pokrywy śnieżnej na Wyżynie Elbląskiej sięga już 35 cm" - poinformowało IMGW.

## Kryzys budżetowy w Niemczech. Szef CSU domaga się przyspieszonych wyborĂłw
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,127561,30449716,szef-csu-domaga-sie-przyspieszonych-wyborow-do-bundestagu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,127561,30449716,szef-csu-domaga-sie-przyspieszonych-wyborow-do-bundestagu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T18:53:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/45/0a/1d/z30449733M,Olaf-Scholz.jpg" vspace="2" />Marcus Soeder domaga się przedterminowych wyborĂłw w Niemczech. Unia CDU/CSU wyznaczyłaby kanclerza i widzi w SPD partnera koalicyjnego.

## Sejmowe przepustki dla ochroniarzy Jarosława Kaczyńskiego ważne do końca roku. Sejm wyjaśnia, co dalej
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30449609,sejmowe-przepustki-dla-ochroniarzy-jaroslawa-kaczynskiego-wazne.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30449609,sejmowe-przepustki-dla-ochroniarzy-jaroslawa-kaczynskiego-wazne.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T18:16:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/01/0a/1d/z30449665M,Jaroslaw-Kaczynski.jpg" vspace="2" />Jest bardzo prawdopodobne, że od przyszłego roku prywatni ochroniarze Jarosława Kaczyńskiego nie będą mogli towarzyszyć prezesowi PiS w parlamencie. Kancelaria Sejmu podkreśla, że nad bezpieczeństwem w parlamencie czuwa Straż Marszałkowska. Przyznaje ponadto, że "zasadność merytoryczna odnowienia przepustek zostanie poddana głębokiej refleksji i ocenie".

## Protest przewoźnikĂłw na granicy. Michał Kołodziejczak: PiS dopuściło do tego, żeby problem narastał
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30448768,protest-przewoznikow-na-granicy-polsko-ukrainskiej-michal-kolodziejczak.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30448768,protest-przewoznikow-na-granicy-polsko-ukrainskiej-michal-kolodziejczak.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T18:09:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/cd/09/1d/z30449613M,Michal-Kolodziejczak.jpg" vspace="2" />Michał Kołodziejczak przyznał, że protesty na granicy polsko-ukraińskiej go nie dziwią. - PiS dopuściło do tego, żeby ten problem narastał - powiedział poseł KO. Lider Agrounii przyznał, że protesty mają swĂłj cel, a on nie dziwi się, że dochodzi do nich właśnie teraz.

## Przyznał się do 96 gwałtĂłw, wkrĂłtce może wyjść na wolność. "Jak mnie wypuszczą, będę zabijał"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30447693,przyznal-sie-do-96-gwaltow-wkrotce-moze-wyjsc-na-wolnosc-jak.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30447693,przyznal-sie-do-96-gwaltow-wkrotce-moze-wyjsc-na-wolnosc-jak.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T18:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/42/09/1d/z30448194M,Zaklad-karny--zdjecie-ilustracyjne-.jpg" vspace="2" />Andrzej Ś. niebawem skończy odsiadywanie wyroku za brutalne gwałty. Mężczyzna szczegĂłłowo opisał w swoim pamiętniku 96 przestępstw, do ktĂłrych się przyznał. "BĂłg zwalnia mnie z grzechu gwałtu na kobiecie" - napisał. Ten najniebezpieczniejszy gwałciciel w historii Polski prawdopodobnie wyjdzie na wolność, ponieważ ośrodek, do ktĂłrego mĂłgłby trafić, "jest przepełniony".

## Nowe porozumienie między Izraelem a Hamasem. Katar ma swĂłj dzień
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30449649,nowe-porozumienie-miedzy-izraelem-a-hamasem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30449649,nowe-porozumienie-miedzy-izraelem-a-hamasem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T17:59:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f4/09/1d/z30449652M,Strefa-Gazy.jpg" vspace="2" />Zawieszenie broni w Gazie zostało przedłużone o dwa dni - poinformował rzecznik Ministerstwa Spraw Zagranicznych Kataru. To właśnie Katar jest głĂłwnym negocjatorem pomiędzy Izraelem a Hamasem.

## PiS przypomniał sobie o kobietach. Szkoda, że dopiero kiedy szykuje się do oddania władzy
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30449269,pis-przypomnial-sobie-o-kobietach-szkoda-ze-dopiero-kiedy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30449269,pis-przypomnial-sobie-o-kobietach-szkoda-ze-dopiero-kiedy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T17:51:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/6b/09/1d/z30449259M,Uroczystosc-powolania-przez-prezydenta-RP-Andrzeja.jpg" vspace="2" />Cieszy mnie ogromna reprezentacja pań w tym gabinecie - powiedział prezydent Andrzej Duda podczas zaprzysiężenia kolejnego rządu Mateusza Morawieckiego. Rzeczywiście, chwila jest historyczna. Pierwszy raz mamy rząd, gdzie ministerek jest więcej niż ministrĂłw. Dotąd mieliśmy raczej rządy, w ktĂłrych zasiadało więcej MichałĂłw niż kobiet - pisze Agata Kalińska, szefowa działu Nowe Trendy w Gazeta.pl.

## Nowy rząd Mateusza Morawieckiego. Kim jest Dominika Chorosińska? Z "M jak miłość" do resortu kultury
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30449431,nowy-rzad-mateusza-morawieckiego-kim-jest-dominika-chorosinska.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30449431,nowy-rzad-mateusza-morawieckiego-kim-jest-dominika-chorosinska.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T17:39:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/78/09/1d/z30449528M,Dominika-Chorosinska.jpg" vspace="2" />Dominika Chorosińska (z domu Figurska) została ministerką kultury w nowym rządzie Mateusza Morawieckiego. Zanim zaangażowała się w politykę, zajmowała się aktorstwem. W ostatnich tygodniach było o niej głośno, bo w trakcie posiedzenia Sejmu wykrzykiwała do Szymona Hołowni "masz talent!".

## Zaprzysiężenie dwutygodniowego rządu Morawieckiego. NiektĂłre wybory zaskakują. W sieci lawina komentarzy
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30448811,mateusz-morawicki-podal-sklad-nowego-rzadu-pierwsze-komentarze.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30448811,mateusz-morawicki-podal-sklad-nowego-rzadu-pierwsze-komentarze.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T16:15:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ea/09/1d/z30449386M,Prezydent-powoluje-premiera-i-Rzad.jpg" vspace="2" />Prezydent Andrzej Duda zaprzysiągł rząd Mateusza Morawieckiego. Wiadomo już oficjalnie, kto wejdzie w jego skład. W sieci pojawiła się lawina komentarzy. "Rząd iście eksperymentalny. Trwa wyszukiwanie w necie, kim są ci ludzie" - stwierdziła np. Katarzyna Lubnauer.

## Andrzej Duda zaprzysiągł nowy rząd Mateusza Morawieckiego. Kaczyński nie przyszedł na uroczystość
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30449050,andrzej-duda-zaprzysiega-nowy-rzad-mateusza-morawieckiego-kaczynski.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30449050,andrzej-duda-zaprzysiega-nowy-rzad-mateusza-morawieckiego-kaczynski.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T15:49:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/43/09/1d/z30449219M,Prezydent-powoluje-premiera-i-rzad.jpg" vspace="2" />Prezydent Andrzej Duda odebrał przysięgę od członkĂłw nowego rządu Mateusza Morawieckiego. - W większości państwa znam, ale nie znam większości z państwa jako ministrĂłw - powiedział Duda. Uroczystość obserwuje grupa posłĂłw PiS, dotychczasowy rzecznik rządu i rodziny nowych ministrĂłw. Nie pojawił się jednak Jarosław Kaczyński.

## Pełna lista ministrĂłw w nowym rządzie PiS. Jest jedna sensacja
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30448847,pelna-lista-ministrow-w-nowym-rzadzie-pis-jest-jedna-sensacja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30448847,pelna-lista-ministrow-w-nowym-rzadzie-pis-jest-jedna-sensacja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T15:03:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/12/09/1d/z30447378M,Mateusz-Morawiecki-i-Jaroslaw-Kaczynski-w-Belweder.jpg" vspace="2" />Przedstawiamy pełny skład rządu, ktĂłry premier Mateusz Morawiecki przedstawi prezydentowi Andrzejowi Dudzie. W istocie będzie to rząd na około dwa tygodnie. Największą sensacją jest obecność Mariusza Błaszczaka jako szefa MON, choć on sam zapowiadał, że go w tym rządzie nie będzie.

## Dyrektorka XXX LO w Krakowie ma zostać odwołana. Kontrola ujawniła, że zniknęło ponad 600 tys. zł
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30448129,dyrektorka-xxx-lo-w-krakowie-ma-zostac-odwolana-kontrola-ujawnila.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30448129,dyrektorka-xxx-lo-w-krakowie-ma-zostac-odwolana-kontrola-ujawnila.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T14:55:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/55/09/1d/z30448725M,XXX-LO-w-Krakowie.jpg" vspace="2" />Władze Krakowa zapowiedziały odwołanie dyrektorki XXX Liceum OgĂłlnokształcącego. Ma to związek z wieloma nieprawidłowościami, ktĂłre odkryto w placĂłwce podczas przeprowadzonej kontroli. Według protokołu ponad 600 tys. złotych miało zostać wydane nieprawidłowo.

## Reuters o sytuacji politycznej w Polsce: Rząd Morawieckiego przetrwa tylko do grudnia. "Farsa"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30448216,reuters-o-sytuacji-politycznej-w-polsce-rzad-morawieckiego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30448216,reuters-o-sytuacji-politycznej-w-polsce-rzad-morawieckiego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T14:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/7c/d4/1c/z30231164M,Premier-rzadu-PiS-Mateusz-Morawiecki-i-jego-partyj.jpg" vspace="2" />Prezydent Andrzej Duda dokona w poniedziałek zaprzysiężenia członkĂłw rządu, ktĂłry prawdopodobnie przetrwa tylko do grudnia, co według opozycji jest "farsą" - pisze Reuters.

## Nieoficjalnie: Prokuratura umorzyła dwa postępowania prowadzone wobec Jarosława Kaczyńskiego
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30448288,nieoficjalnie-prokuratura-umorzyla-dwa-postepowania-prowadzone.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30448288,nieoficjalnie-prokuratura-umorzyla-dwa-postepowania-prowadzone.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T13:45:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ba/07/1d/z30438842M,Jaroslaw-Kaczynski-z-tabletem.jpg" vspace="2" />Prokuratura umorzyła dwa postępowania prowadzone wobec Jarosława Kaczyńskiego - ustaliło RMF FM. Chodzi m.in. o znieważenie pomnika smoleńskiego.

## Rada MediĂłw Narodowych zgodziła się na zmiany m.in. w statucie TVP. Ma to je uchronić przed Tuskiem
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30448080,rada-mediow-narodowych-zgodzila-sie-na-zmiany-m-in-w-statucie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30448080,rada-mediow-narodowych-zgodzila-sie-na-zmiany-m-in-w-statucie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T13:04:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/71/eb/1c/z30323313M,Przewodniczacy-RMN-Krzysztof-Czabanski-i-prezes-TV.jpg" vspace="2" />Rada MediĂłw Narodowych zgodziła się na dokonanie zmian w statutach TVP, Polskiego Radia i PAP. O to wnioskował minister kultury Piotr Gliński. Zgodnie ze zmianami "w razie otwarcia likwidacji likwidatorami są wszyscy członkowie zarządu oraz kierownik komĂłrki organizacyjnej spĂłłki zajmującej się obsługą prawną".

## Nieprawidłowości w bazie samolotĂłw rządowych. Do jednostki weszła Żandarmeria Wojskowa
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30447765,nieprawidlowosci-w-bazie-samolotow-rzadowych-do-jednostki-weszla.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30447765,nieprawidlowosci-w-bazie-samolotow-rzadowych-do-jednostki-weszla.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T12:55:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ca/e9/17/z25072586M,Rzadowy-samolot-Gulfstream-G550-Ksiaze-Jozef-Ponia.jpg" vspace="2" />Żandarmeria Wojskowa prowadzi czynności w 1. Bazie Lotnictwa Transportowego - podaje Onet. To reakcja na tekst portalu dot. uchybień w jednostce zajmującej się transportem powietrznym VIP-Ăłw.

## Nie żyje Paweł Huelle. Pisarz odszedł w wieku 66 lat
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30447709,nie-zyje-pawel-huelle-pisarz-odszedl-w-wieku-66-lat.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30447709,nie-zyje-pawel-huelle-pisarz-odszedl-w-wieku-66-lat.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T12:53:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/7b/09/1d/z30447739M,Pawel-Huelle.jpg" vspace="2" />Polski pisarz Paweł Huelle nie żyje - poinformowała w poniedziałek "Gazeta Wyborcza". Artysta odszedł w wieku 66 lat.

## Kosiniak-Kamysz miał być premierem? Mastalerek: Propozycje wyszły z PSL
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30447372,kosiniak-kamysz-mial-byc-premierem-mastalerek-propozycje-wyszly.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30447372,kosiniak-kamysz-mial-byc-premierem-mastalerek-propozycje-wyszly.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T12:52:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ce/09/1d/z30447566M,Wladyslaw-Kosiniak-Kamysz--prezes-PSL.jpg" vspace="2" />Propozycja powierzenia misji stworzenia rządu Władysławowi Kosiniakowi-Kamyszowi miała wyjść ze środowiska Polskiego Stronnictwa Ludowego - twierdził w rozmowie z portalem wp.pl Marcin Mastalerek, szef gabinetu prezydenta Dudy. - To były konfidencjonalne rozmowy, ale z kilku źrĂłdeł z PSL - mĂłwił. - Nigdy, proszę zwrĂłcić uwagę, pan Władysław Kosiniak-Kamysz temu nie zaprzeczał - podkreślał.

## Lubelskie. Nie żyje żubr znaleziony w lesie niedaleko Białej Podlaskiej. Czuwali przy nim druhowie z OSP
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30447258,lubelskie-nie-zyje-zubr-znaleziony-w-lesie-niedaleko-bialej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30447258,lubelskie-nie-zyje-zubr-znaleziony-w-lesie-niedaleko-bialej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T12:26:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/93/78/18/z25660563M,zubr--zdjecie-ilustracyjne-.jpg" vspace="2" />Nie żyje żubr, ktĂłrego znaleziono w lesie niedaleko Białej Podlaskiej. Przy zwierzęciu czuwali strażacy z OSP, ktĂłrzy przywieźli siana, przykryli go, dali mu jeść i pić. Lekarz weterynarii ma pobrać prĂłbki i ustalić, co było przyczyną śmierci żubra.

## Nowe informacje ws. stanu zdrowia papieża Franciszka. "Oddycha coraz lepiej"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30447326,nowe-informacje-ws-stanu-zdrowia-papieza-franciszka-oddycha.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30447326,nowe-informacje-ws-stanu-zdrowia-papieza-franciszka-oddycha.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T12:23:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/07/09/1d/z30447367M,Papiez-Franciszek.jpg" vspace="2" />Papież Franciszek nie ma gorączki i oddycha coraz lepiej - poinformował w poniedziałek rano Matteo Bruni, dyrektor Biura Prasowego Stolicy Apostolskiej. Stan zdrowia papieża poprawił się, wykluczono także zapalenie płuc.

## Policja odda substancje do produkcji narkotykĂłw właścicielowi. Absurdalny powĂłd. "Bawią się z nami"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30447156,policja-odda-substancje-do-produkcji-narkotykow-wlascicielowi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30447156,policja-odda-substancje-do-produkcji-narkotykow-wlascicielowi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T12:16:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/b5/09/1d/z30447541M,Policja--zdjecie-ilustracyjne-.jpg" vspace="2" />Holenderska policja musi zwrĂłcić ponad tonę substancji przeznaczonych do produkcji narkotykĂłw właścicielowi. Lokalne władze i miejscowi funkcjonariusze skrytykowali absurdalne, ich zdaniem przepisy, ktĂłre do tego doprowadziły.

## Gdzie pada śnieg? Polska znajdzie się w zasięgu niżu. Są ostrzeżenia IMGW
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30446933,gdzie-pada-snieg-polska-znajdzie-sie-w-zasiegu-nizu-sa-ostrzezenia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30446933,gdzie-pada-snieg-polska-znajdzie-sie-w-zasiegu-nizu-sa-ostrzezenia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T12:05:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/37/09/1d/z30447159M,Snieg--zdjecie-ilustracyjne-.jpg" vspace="2" />W nocy i godzinach porannych w poniedziałek opady śniegu zostały odnotowane w dziewięciu wojewĂłdztwach. W związku z sytuacją pogodową GDDKiA wystosowało apel do kierowcĂłw o zachowanie szczegĂłlnej ostrożności na drogach. Na Pomorzu wciąż obowiązują alerty pogodowe, wystosowane przez IMGW.

## Gorący tydzień w Sejmie. Kiedy kolejne posiedzenie? Wiemy, nad czym będą głosować posłowie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30446857,goracy-tydzien-w-sejmie-kiedy-kolejne-posiedzenie-wiemy-nad.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30446857,goracy-tydzien-w-sejmie-kiedy-kolejne-posiedzenie-wiemy-nad.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T11:22:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/3b/06/1d/z30435899M,Posiedzenie-Sejmu-X-kadencji.jpg" vspace="2" />Już we wtorek posłowie zbiorą się na kolejnym posiedzeniu nowego Sejmu, w trakcie ktĂłrego powołają między innymi Rzecznika Praw Dziecka. Głosowań będzie znacznie więcej. - Drodzy państwo, zaopatrzcie się solidnie w popcorn - radził w ubiegłym tygodniu marszałek Sejmu Szymon Hołownia. Co czeka nas na wtorkowym posiedzeniu?

## Niespodziewane słowa Dworczyka z PiS. "Być może zagłosuję za powołaniem komisji śledczej"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30446835,niespodziewane-slowa-dworczyka-z-pis-byc-moze-zaglosuje-za.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30446835,niespodziewane-slowa-dworczyka-z-pis-byc-moze-zaglosuje-za.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T11:19:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/bf/c8/1c/z30182847M,Mateusz-Morawiecki-i-Michal-Dworczyk.jpg" vspace="2" />- Być może nawet sam zagłosuję za powołaniem tej komisji, bo mam dosyć kłamstw i manipulacji, ktĂłrych przez ostatnie dwa lata muszę wysłuchiwać - powiedział Michał Dworczyk, odnosząc się do pomysłu Koalicji Obywatelskiej, aby powołać komisję śledczą ws. wyborĂłw kopertowych. Jak dodał, ma nadzieję, że "przetnie ona dwuletni taniec oskarżeń i manipulacji".

## Rząd Donalda Tuska jest gotowy "w 100 procentach". Sekretarz generalny PO mĂłwi o nowych ministrach
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30446925,rzad-donalda-tuska-jest-gotowy-w-100-procentach-sekretarz.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30446925,rzad-donalda-tuska-jest-gotowy-w-100-procentach-sekretarz.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T11:12:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/13/09/1d/z30447123M,Donald-Tusk.jpg" vspace="2" />- Rząd Donalda Tuska jest w 100 procentach zamknięty - przekazał Marcin Kierwiński, ekretarz generalny PO. Kierwiński poinformował, kto "z dużym prawdopodobieństwem" obejmie resort nauki. Powiedział też, dlaczego nowy minister zdrowia będzie miał "trudną misję". Zapewnił przy tym, że Tusk znalazł kandydata, ktĂłry jej podoła.

## Matczak o depisyzacji: Zębami zgrzytam, ale Pawłowicz jest legalna
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30444079,matczak-o-depisyzacji-zebami-zgrzytam-ale-pawlowicz-jest.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30444079,matczak-o-depisyzacji-zebami-zgrzytam-ale-pawlowicz-jest.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T10:57:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a4/09/1d/z30446756M,Wywiady-Sroczynskiego.jpg" vspace="2" />- Obawiam się dwĂłch rzeczy. Nierobienia niczego, na zasadzie, że przecież Duda i tak zawetuje, albo robienia za mocno, na zasadzie, że skoro Duda wetuje, to wszystkie chwyty dozwolone - z Marcinem Matczakiem rozmawia Grzegorz Sroczyński.

## Piotr Gliński ma pomysł, jak uratować TVP i inne media publiczne? "Wystąpił z wnioskiem"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30446997,piotr-glinski-chce-ratowac-tvp-wystapil-z-wnioskiem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30446997,piotr-glinski-chce-ratowac-tvp-wystapil-z-wnioskiem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T10:48:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/b0/09/1d/z30447024M,Piotr-Glinski.jpg" vspace="2" />Piotr Gliński wystąpił z wnioskiem w sprawie uzyskania zgody na zmiany w statutach mediĂłw publicznych - podał w poniedziałek Onet. "Polityk PiS chce uniemożliwić przejęcie kontroli nad mediami przez nową władzę, ktĂłra zamierzała to zrobić w ramach procedury likwidacyjnej" - opisuje portal.

## "Jestem gotowy". Jacek Sasin tłumaczy się z wyborĂłw kopertowych. "Mieliśmy sytuację wyjątkową"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30446494,jacek-sasin-komentuje-misje-morawieckiego-i-szanse-na-wotum.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30446494,jacek-sasin-komentuje-misje-morawieckiego-i-szanse-na-wotum.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T10:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c1/09/1d/z30446785M,Jacek-Sasin-obok-premiera-Mateusza-Morawieckiego.jpg" vspace="2" />Jacek Sasin nie wejdzie w skład nowego rządu Mateusza Morawieckiego. Ustępujący minister aktywĂłw państwowych ocenił w rozmowie z TVN24 szanse premiera na wotum zaufania i odniĂłsł się do planĂłw zbudowania rządu "bardziej eksperckiego". Skomentował też plany koalicji demokratycznej, by stworzyć komisję sejmową do zbadania nieprawidłowości w tzw. wyborach kopertowych.

## To Kaczyński ustalił skład rządu. "Pozwoli Morawieckiemu wybrać chociaż krawat"? [KOMENTARZE]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30446472,kaczynski-ustalil-sklad-rzadu-myslicie-ze-pozwoli-morawieckiemu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30446472,kaczynski-ustalil-sklad-rzadu-myslicie-ze-pozwoli-morawieckiemu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T10:16:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/fe/09/1d/z30446846M,Lawina-komentarzy-po-wypowiedzi-Kaczynskiego----Mo.jpg" vspace="2" />Po tym, jak Jarosław Kaczyński oświadczył, że kształt rządu ekspercko-politycznego jest jego pomysłem, w sieci pojawiły się komentarze politykĂłw. - Kaczyński wymyślił, Morawiecki zrealizuje. Człowiek na pilota będzie zawsze działał na pilota. Wstyd - napisał w mediach społecznościowych poseł Nowej Lewicy. Padały także stwierdzenia o "marionetce" oraz "najbardziej upokorzonym premierze III RP".

## Sasin o nowym rządzie Morawieckiego i 10 proc. szans. "Nie jesteśmy naiwni. Będzie ekstremalnie trudno"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30446542,jacek-sasin-o-swoich-oczekiwaniach-wobec-trzeciej-drogi-powinni.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30446542,jacek-sasin-o-swoich-oczekiwaniach-wobec-trzeciej-drogi-powinni.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T10:14:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d3/09/1d/z30446803M,Jacek-Sasin.jpg" vspace="2" />- Oczywiście my nie jesteśmy naiwni. Wiemy, że będzie ekstremalnie trudno uzyskać wotum zaufania dla tego rządu. Ale to nie znaczy, że nie powinniśmy tej prĂłby podjąć - mĂłwił w poniedziałek w TVN24 Jacek Sasin.

## Czy "babciowe" to dobry pomysł? Motyka: Albo zasuwasz, albo poświęcasz się rodzinie. To musi zniknąć
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30446300,czy-babciowe-to-dobry-pomysl-motyka-albo-zasuwasz-albo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30446300,czy-babciowe-to-dobry-pomysl-motyka-albo-zasuwasz-albo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T09:54:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/3d/09/1d/z30446397M,Milosz-Motyka.jpg" vspace="2" />- Jest takie zjawisko, że albo jesteś dyspozycyjny, albo zasuwasz, czyli masz dobre wynagrodzenie albo poświęcasz się rodzinie i masz dzieci. To musi zniknąć - powiedział Miłosz Motyka w "Porannej rozmowie Gazeta.pl".

## Kto w tymczasowym rządzie PiS? Znikną znane nazwiska. To ma być młody gabinet
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30446386,kto-w-tymczasowym-rzadzie-pis-znikna-znane-nazwiska-to-ma.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30446386,kto-w-tymczasowym-rzadzie-pis-znikna-znane-nazwiska-to-ma.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T09:42:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/2e/09/1d/z30446382M,Premier-rzadu-PiS-Mateusz-Morawiecki-i-jego-partyj.jpg" vspace="2" />W obozie PiS ścierały się pomysły na nowy rząd Mateusza Morawieckiego. Premier optował za odmłodzonym i eksperckim gabinetem. Chciał odciąć balast choćby w osobie szefa MSZ prof. Zbigniewa Raua. Znikną m.in Jacek Sasin, Piotr Gliński, Przemysław Czarnek. Sporo ma być awansowanych wiceministrĂłw i ludzi premiera.

## Miller o tym, co opozycja powinna zrobić. "W ten sposĂłb zakończy się mordęga Mateusza"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30446561,miller-o-tym-co-opozycja-powinna-zrobic-w-ten-sposob-zakonczy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30446561,miller-o-tym-co-opozycja-powinna-zrobic-w-ten-sposob-zakonczy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T09:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ba/f7/1c/z30374842M,Leszek-Miller.jpg" vspace="2" />"Natychmiast po zaprzysiężeniu rządu Morawieckiego do Sejmu powinien wpłynąć wniosek o konstruktywne votum nieufności do Rady MinistrĂłw" - stwierdził Leszek Miller. "W ten sposĂłb zakończy się mordęga Mateusza i ośmieszanie władzy wykonawczej w oczach obywateli" - dodał. Słowa byłego premiera skrytykował Włodzimierz Czarzasty.

## SkrĂłcenie kadencji Andrzeja Dudy w drodze referendum? Prof. Chmaj: Nie wycofuję się ze swoich słĂłw
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30446307,skrocenie-kadencji-andrzeja-dudy-w-drodze-referendum-prof.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30446307,skrocenie-kadencji-andrzeja-dudy-w-drodze-referendum-prof.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T09:25:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d6/04/1d/z30426326M,Prezydent-RP-Andrzej-Duda.jpg" vspace="2" />- SkrĂłcenie kadencji prezydenta jest hipotetycznie możliwe. Zarazem nie jest to prosta procedura, a samo skrĂłcenie kadencji mogłoby być następstwem innych podjętych przez suwerena decyzji - powiedział prof. Marek Chmaj. - Nie wycofuję się ze swoich słĂłw - dodał konstytucjonalista.

## Morawiecki powoła "ekspercko-polityczny" rząd. Po co? Prof. Rychard: To jasny sygnał dla elektoratu
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30446457,morawiecki-powola-ekspercko-polityczny-rzad-ekspert-tlumaczy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30446457,morawiecki-powola-ekspercko-polityczny-rzad-ekspert-tlumaczy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T08:58:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/cf/09/1d/z30446543M,Mateusz-Morawiecki.jpg" vspace="2" />Mateusz Morawiecki przedstawi skład rządu, ktĂłry będzie miał "polityczno-ekspercki" charakter. Socjolog prof. Andrzej Rychard powiedział, jaki jest cel tworzenia Rady MinistrĂłw, ktĂłra nie może liczyć na poparcie w Sejmie. Jego zdaniem chodzi o wysłanie jasnego komunikatu do elektoratu PiS.

## Francja. Ojciec zasztyletował trzy cĂłrki. Wcześniej był karany za przemoc domową
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30446197,francja-ojciec-zasztyletowal-trzy-corki-wczesniej-byl-karany.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30446197,francja-ojciec-zasztyletowal-trzy-corki-wczesniej-byl-karany.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T08:55:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/02/0e/1b/z28370946M,Francja--Policja--zdjecie-ilustracyjne-.jpg" vspace="2" />Trzy dziewczynki zostały zamordowane w gminie Alfortville na obrzeżach Paryża. Do zabĂłjstwa przyznał się ich ojciec, ktĂłry zgłosił się na policję w miejscowości oddalonej 200 kilometrĂłw od miejsca zbrodni. 41-latek był wcześniej karany za przemoc domową.

## Dzieci migrantĂłw wykorzystywane w "namiotach gwałtu". Niepokojący raport "Lekarzy bez granic"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30446226,dzieci-migrantow-wykorzystywane-w-namiotach-gwaltu-niepokojacy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30446226,dzieci-migrantow-wykorzystywane-w-namiotach-gwaltu-niepokojacy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T08:47:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/74/09/1d/z30446452M,Migranci--zdjecie-ilustracyjne-.jpg" vspace="2" />Tysiące migrantĂłw padło ofiarą atakĂłw uzbrojonych bandytĂłw podczas wędrĂłwki z Ameryki Południowej do StanĂłw Zjednoczonych. Jak wynika z raportu opublikowanego przez "Lekarzy bez granic" prawie 400 osĂłb doświadczyło także napaści na tle seksualnym. W tym celu przestępcy ustawiali na trasie specjalne "namioty gwałtu". WśrĂłd ofiar były także dzieci.

## Znęcali się nad dwiema kobietami. Policja zatrzymała dwĂłch patostreamerĂłw ze Śląska
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30446132,znecali-sie-nad-dwiema-kobietami-policja-zatrzymala-dwoch-patostreamerow.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30446132,znecali-sie-nad-dwiema-kobietami-policja-zatrzymala-dwoch-patostreamerow.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T08:24:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/65/09/1d/z30446181M,Policja-zatrzymala-patostreamerow-ze-Slaska.jpg" vspace="2" />Policja zatrzymała dwĂłch osiemnastolatkĂłw ze Śląska, ktĂłrzy znęcali się nad dwiema kobietami podczas transmisji na żywo. Jeszcze w poniedziałek mają usłyszeć zarzuty. Młodzi mężczyźni mieli upić jedną z kobiet i nie udzielić jej pomocy, drugą z kolei mieli pobić.

## Wielka ewakuacja w TVP. "CĂłż mają robić ci 'dziennikarze'? Wszyscy się w TV Trwam nie pomieszczą"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30446112,wielka-ewakuacja-w-tvp-coz-maja-robic-ci-dziennikarze-wszyscy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30446112,wielka-ewakuacja-w-tvp-coz-maja-robic-ci-dziennikarze-wszyscy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T07:56:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/32/db/1b/z29212210M,Danuta-Holecka.jpg" vspace="2" />Za kilka tygodni w Telewizji Polskiej może dojść do masowych zwolnień. Stanie się tak - jak zapewnia opozycja - jeśli Donald Tusk zostanie premierem. Tymczasem niektĂłrzy zawczasu prĂłbują ewakuować się z TVP.

## Coraz więcej zakażeń COVID-19. Czy wrĂłcą obostrzenia? "Sytuacja jest dynamiczna"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30446081,coraz-wiecej-zakazen-covid-19-czy-wroca-obostrzenia-sytuacja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30446081,coraz-wiecej-zakazen-covid-19-czy-wroca-obostrzenia-sytuacja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T07:36:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/94/05/1d/z30432148M,Szczepienia--zdjecia-ilustracyjne-.jpg" vspace="2" />W Polsce wciąż pojawia się coraz więcej przypadkĂłw COVID-19. Wiele szpitali zareagowało na sezon infekcyjny ograniczeniem odwiedzin w placĂłwkach oraz przywrĂłceniem obowiązku noszenia maseczek. Dr Agata Kusz-Rynkun zwraca uwagę, że dalsze rozprzestrzenianie się choroby może zadecydować o konieczności wprowadzenia dodatkowych obostrzeń.

## Polacy ocenili zachowanie Andrzeja Dudy. "Prezydent za bardzo przykleił się do PiS" [SONDAŻ]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30446076,polacy-ocenili-zachowanie-andrzeja-dudy-prezydent-za-bardzo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30446076,polacy-ocenili-zachowanie-andrzeja-dudy-prezydent-za-bardzo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T06:59:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/10/09/1d/z30446096M,Andrzej-Duda.jpg" vspace="2" />Większość PolakĂłw negatywnie ocenia zachowanie Andrzeja Dudy wobec nowej większości parlamentarnej - wynika z sondażu IBRiS dla "Rzeczpospolitej". 24 proc. badanych wybrało odpowiedź "zdecydowanie źle" a 34,8 proc. "raczej źle".

## Brutalny atak nożownika na imprezie andrzejkowej. Policja zatrzymała podejrzanego
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30446080,brutalny-atak-nozownika-na-imprezie-andrzejkowej-policja-zatrzymala.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30446080,brutalny-atak-nozownika-na-imprezie-andrzejkowej-policja-zatrzymala.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T06:54:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/26/09/1d/z30446118M,Policja--zdjecie-ilustracyjne-.jpg" vspace="2" />Policja ustaliła, że podczas balu andrzejkowego 39-latek został zaatakowany przez innego uczestnika imprezy, ktĂłry dźgnął go nożem. Mężczyzna w ciężkim stanie trafił do szpitala. Funkcjonariusze zatrzymali podejrzanego i przedstawili przebieg zajścia.

## Jak Rosja oczernia Polskę? Stanisław Żaryn ostrzega przed dezinformacją. Przykłady
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30446087,stanislaw-zaryn-ostrzega-przed-rosyjska-dezinformacja-pokazuje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30446087,stanislaw-zaryn-ostrzega-przed-rosyjska-dezinformacja-pokazuje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T06:53:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/28/09/1d/z30446120M,Stanislaw-Zaryn-ostrzega-Polakow-przed-rosyjska-de.jpg" vspace="2" />"Rosyjska dezinformacja stale oczernia Polskę, prezentując nasz kraj jako państwo agresywne, ktĂłre planuje ataki na inne kraje" - napisał w mediach społecznościowych pełnomocnik rządu ds. bezpieczeństwa przestrzeni informacyjnej RP Stanisław Żaryn. To nie pierwszy raz, kiedy zastępca ministra koordynatora służb specjalnych wskazuje na szkodliwe działania Rosji.

## Morawiecki ogłosi skład rządu. Kaczyński: To mĂłj pomysł. "Błaszczak być może się w nim znajdzie"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30446082,morawiecki-oglosi-sklad-rzadu-kaczynski-to-moj-pomysl-blaszczak.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30446082,morawiecki-oglosi-sklad-rzadu-kaczynski-to-moj-pomysl-blaszczak.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T06:10:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/5e/02/1d/z30416990M,Jaroslaw-Kaczynski.jpg" vspace="2" />- Kształt rządu ekspercko-politycznego, ktĂłry w poniedziałek przedstawi premier Mateusz Morawiecki, to mĂłj pomysł - powiedział w rozmowie z PAP Jarosław Kaczyński. - Chodzi o to, aby w tym rządzie nie było zbyt wielu politykĂłw. Ale akurat minister Błaszczak być może się w nim znajdzie - dodał prezes PiS.

## Nagroda Bookera 2023 przyznana Paulowi Lynchowi. "To nie była łatwa książka do napisania"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30446043,nagroda-bookera-2023-przyznana-paulowi-lynchowi-to-nie-byla.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30446043,nagroda-bookera-2023-przyznana-paulowi-lynchowi-to-nie-byla.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T06:01:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e1/09/1d/z30446049M,Paul-Lynch.jpg" vspace="2" />Laureatem tegorocznej Nagrody Bookera został Irlandczyk Paul Lynch. Pisarz został wyrĂłżniony za powieść "Pieśń Proroka" (ang. "Prophet Song"). - Racjonalna część mnie wierzyła, że pisząc tę powieść, skazuję swoją karierę na porażkę, ale i tak musiałem ją napisać - mĂłwił laureat na gali.

## Horoskop dzienny - poniedziałek 27 listopada 2023 [Baran, Byk, Bliźnięta, Rak, Lew, Panna, Waga, Skorpion, Strzelec, Koziorożec, Wodnik, Ryby]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,168571,30445130,horoskop-dzienny-poniedzialek-27-listopada-2023-baran-byk.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,168571,30445130,horoskop-dzienny-poniedzialek-27-listopada-2023-baran-byk.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-27T04:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/50/08/1d/z30445136M,Horoskop-dzienny-na-poniedzialek-27-listopada-2023.jpg" vspace="2" />Horoskop dzienny na poniedziałek 27 listopada 2023. Dla ktĂłrego znaku zodiaku najbliższy czas okaże się pomyślny, a ktĂłry powinien trzymać się na baczności? Sprawdź, czego możesz się dziś spodziewać.

