# Source:Epoch Times - World, URL:https://feed.theepochtimes.com/world/feed, language:en-US

## Police Release Names of Victims in Mass Shooting in Winnipeg
 - [https://www.theepochtimes.com/world/police-release-names-of-victims-in-mass-shooting-in-winnipeg-5536589](https://www.theepochtimes.com/world/police-release-names-of-victims-in-mass-shooting-in-winnipeg-5536589)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T23:00:52+00:00

Police secure a crime scene where multiple people were killed in the 100 block of Langside Street in Winnipeg on Nov. 26, 2023. (The Canadian Press/David Lipnowski)

## ‘Extreme Green Left’ Fueling Anti-Semitic Sentiment in Schools: Liberal MP
 - [https://www.theepochtimes.com/world/extreme-green-left-fueling-anti-semitic-sentiment-in-schools-liberal-mp-5536371](https://www.theepochtimes.com/world/extreme-green-left-fueling-anti-semitic-sentiment-in-schools-liberal-mp-5536371)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T22:58:00+00:00

Protesters gather at Flinders Street Station on November 23, 2023 in Melbourne, Australia. Organised by School Students For Palestine, the call for action on the group's social media feeds prompted a statement from federal Education Minister Jason Clare that children should be in class during school hours. The ongoing Israel-Hamas conflict continues to cause social tensions in societies around the world, including in Australian cities. (Photo by Asanka Ratnayake/Getty Images)

## Pro-Palestine Activists Target US Consulate and Pine Gap Military Base
 - [https://www.theepochtimes.com/world/pro-palestine-activists-target-us-consulate-and-pine-gap-military-base-5536328](https://www.theepochtimes.com/world/pro-palestine-activists-target-us-consulate-and-pine-gap-military-base-5536328)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T22:43:17+00:00

Police officers work to remove a protester at protest outside of the United States Consulate in Melbourne, Australia, on Nov. 27, 2023. (AAP Image/James Ross)

## Alberta Invokes Sovereignty Act Against Feds for First Time
 - [https://www.theepochtimes.com/world/alberta-invokes-sovereignty-act-against-feds-for-first-time-5536516](https://www.theepochtimes.com/world/alberta-invokes-sovereignty-act-against-feds-for-first-time-5536516)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T22:10:56+00:00

Alberta Premier Danielle Smith speaks at a press conference in Edmonton on Oct. 25, 2023. (The Canadian Press/Jason Fransson)

## Israeli Music Festival Survivor Shares Harrowing Story of Escape From Hamas Terrorists
 - [https://www.theepochtimes.com/world/israeli-music-festival-survivor-shares-harrowing-story-of-escape-from-hamas-terrorists-5519359](https://www.theepochtimes.com/world/israeli-music-festival-survivor-shares-harrowing-story-of-escape-from-hamas-terrorists-5519359)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T22:02:55+00:00

An aerial picture taken on Oct. 10 shows the abandoned site of the weekend music festival attacked by Hamas terrorist near Kibbutz Reim in the Negev desert in southern Israel, on Oct. 7, 2023. (Jack Guez/AFP via Getty Images)

## ‘It’s Remarkable What Humans Are Capable of If They’re Fed Falsehoods’: Elon Musk in Jerusalem
 - [https://www.theepochtimes.com/epochtv/its-remarkable-what-humans-are-capable-of-if-theyre-fed-falsehoods-elon-musk-in-jerusalem-5536785](https://www.theepochtimes.com/epochtv/its-remarkable-what-humans-are-capable-of-if-theyre-fed-falsehoods-elon-musk-in-jerusalem-5536785)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T21:54:24+00:00

Elon Musk meets with Israeli President Isaac Herzog on Nov. 27, 2023. (Reuters/Screenshot via NTD)

## Ontario to Provide $1.2B in Bid to Alleviate Toronto’s Funding Woes
 - [https://www.theepochtimes.com/world/ontario-to-provide-1-2b-in-bid-to-alleviate-torontos-funding-woes-5536792](https://www.theepochtimes.com/world/ontario-to-provide-1-2b-in-bid-to-alleviate-torontos-funding-woes-5536792)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T21:37:22+00:00

Ontario Premier Doug Ford and Toronto Mayor Olivia Chow hold a news conference in Toronto on Monday Nov. 27, 2023. Ford says the province will upload two Toronto highways in order to help alleviate the city's growing financial pressures. THE CANADIAN PRESS/Chris Young

## Political Prisoner of Brazil’s Jan. 8 Protest Dies
 - [https://www.theepochtimes.com/opinion/political-prisoner-of-brazils-jan-8-protest-dies-5536247](https://www.theepochtimes.com/opinion/political-prisoner-of-brazils-jan-8-protest-dies-5536247)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T21:30:51+00:00

Security forces arrest rioters after retaking control of Planalto Presidential Palace in Brasilia on Jan. 8, 2023. (Ton Molina/AFP via Getty Images)

## ‘Absolutely No Talk’ of Moving Paul Bernardo to Minimum Security: Corrections Head
 - [https://www.theepochtimes.com/world/absolutely-no-talk-of-moving-paul-bernardo-to-minimum-security-corrections-head-5536793](https://www.theepochtimes.com/world/absolutely-no-talk-of-moving-paul-bernardo-to-minimum-security-corrections-head-5536793)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T21:29:16+00:00

Paul Bernardo arrives at the provincial courthouse in the back of a police van in Toronto in a file photo on Nov. 3, 1995. (The Canadian Press/Frank Gunn)

## Doubling the Size of Parliament to 300: Expert Says Australians May Be Under-Represented
 - [https://www.theepochtimes.com/world/doubling-the-size-of-parliament-to-300-expert-says-australians-may-be-under-represented-5536302](https://www.theepochtimes.com/world/doubling-the-size-of-parliament-to-300-expert-says-australians-may-be-under-represented-5536302)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T20:30:45+00:00

Treasurer Jim Chalmers hands down the 2023 Budget in the House of Representatives at Parliament House in Canberra, Australia on May 9, 2023. (Martin Ollman/Getty Images)

## There’s a Dead Cat That You Really Should See
 - [https://www.theepochtimes.com/bright/theres-a-dead-cat-that-you-really-should-see-5536263](https://www.theepochtimes.com/bright/theres-a-dead-cat-that-you-really-should-see-5536263)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T20:30:21+00:00

Objects from Ramses &#038; the Gold of the Pharaohs. (Courtesy of World Heritage Exhibitions)

## John Robson: Canada Should Take a Lesson From Dublin Riots and End Massive Immigration
 - [https://www.theepochtimes.com/opinion/john-robson-canada-should-take-a-lesson-from-dublin-riots-and-end-massive-immigration-5536520](https://www.theepochtimes.com/opinion/john-robson-canada-should-take-a-lesson-from-dublin-riots-and-end-massive-immigration-5536520)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T20:22:51+00:00

Flames rise from a car and a bus at the junction of Bachelors Walk and O'Connell Bridge in Dublin, Ireland, on Nov. 23, 2023, as people rioted following the stabbing of three children earlier in the day.  (Peter Murphy/AFP via Getty Images)

## RCMP Say 12-Year-Old Boy in BC Killed Himself Over Online Sextortion
 - [https://www.theepochtimes.com/world/rcmp-say-12-year-old-boy-in-bc-killed-himself-over-online-sextortion-5536741](https://www.theepochtimes.com/world/rcmp-say-12-year-old-boy-in-bc-killed-himself-over-online-sextortion-5536741)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T20:22:03+00:00

The RCMP logo is seen outside the force's 'E' division headquarters in Surrey, B.C., on Mar. 16, 2023. (The Canadian Press/Darryl Dyck)

## Israel and Hamas to Halt Gaza War for Extra Two Days, US, Qatari Officials Say
 - [https://www.theepochtimes.com/world/israel-and-hamas-to-halt-gaza-war-for-extra-two-days-us-qatari-officials-say-5536581](https://www.theepochtimes.com/world/israel-and-hamas-to-halt-gaza-war-for-extra-two-days-us-qatari-officials-say-5536581)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T18:47:39+00:00

An Israeli soldier rides in a Merkava tank, amid the ongoing ground operation of the Israeli army against Hamas in Gaza, on Nov. 20, 2023. (Israel Defense Forces/Handout via Reuters)

## Canadians’ Life Expectancy Declined in 2022 for Third Year in a Row: StatCan
 - [https://www.theepochtimes.com/world/canadians-life-expectancy-declined-in-2022-for-third-year-in-a-row-statcan-5536615](https://www.theepochtimes.com/world/canadians-life-expectancy-declined-in-2022-for-third-year-in-a-row-statcan-5536615)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T18:46:08+00:00

A Statistics Canada sign is pictured in Ottawa on July 3, 2019. (The Canadian Press/Sean Kilpatrick)

## Elon Musk Visits Israeli Kibbutz Attacked by Hamas, Calls for End to Murderous Propaganda
 - [https://www.theepochtimes.com/epochtv/elon-musk-visits-israeli-kibbutz-attacked-by-hamas-calls-for-end-to-murderous-propaganda-5536602](https://www.theepochtimes.com/epochtv/elon-musk-visits-israeli-kibbutz-attacked-by-hamas-calls-for-end-to-murderous-propaganda-5536602)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T18:38:54+00:00

Social media platform X’s owner Elon Musk (C, left) joins Israeli Prime Minister Benjamin Netanyahu (C, right) on a visit to a kibbutz destroyed in the Oct. 2023 Hamas attack on Nov. 27, 2023. (CNN/Screenshot via NTD)

## Argentina’s Milei Invites Brazil’s Lula to Inauguration, Travels to US
 - [https://www.theepochtimes.com/world/argentinas-milei-invites-brazils-lula-to-inauguration-travels-to-us-5536370](https://www.theepochtimes.com/world/argentinas-milei-invites-brazils-lula-to-inauguration-travels-to-us-5536370)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T18:12:07+00:00

Argentine president-elect Javier Milei addresses supporters after winning Argentina's runoff presidential election, in Buenos Aires, Argentina, on Nov. 19, 2023. (Agustin Marcarian/Reuters)

## Suspect in Shooting of 3 Men of Palestinian Descent Near University of Vermont Pleads Not Guilty
 - [https://www.theepochtimes.com/us/suspect-in-shooting-of-3-men-of-palestinian-descent-near-university-of-vermont-pleads-not-guilty-5536591](https://www.theepochtimes.com/us/suspect-in-shooting-of-3-men-of-palestinian-descent-near-university-of-vermont-pleads-not-guilty-5536591)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T18:10:38+00:00

Jason J. Eaton appears at his court arraignment from the Northwest State Correctional Facility in Swanton, Vt., on Nov.  27, 2023 in a still image from Webex video. (Vermont Judiciary/Handout via Reuters)

## Government Signals Plans to Raise Skilled Worker Visa Salary Threshold Amid Immigration Concerns
 - [https://www.theepochtimes.com/world/government-signals-plans-to-raise-skilled-worker-visa-salary-threshold-amid-immigration-concerns-5536525](https://www.theepochtimes.com/world/government-signals-plans-to-raise-skilled-worker-visa-salary-threshold-amid-immigration-concerns-5536525)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T17:55:17+00:00

Business Secretary Kemi Badenoch at the Shaping the Future: UK-Korea Business Forum, at Mansion House, central London, on day two of the state visit by President of South Korea Yoon Suk Yeol to the UK, in London on Nov. 22, 2023. (Aaron Chown - WPA Pool/Getty Images)

## ‘Decolonisation’ Is Being Used Drive Classical Music out of the Curriculum: Professor
 - [https://www.theepochtimes.com/world/decolonisation-is-being-used-drive-classical-music-out-of-the-curriculum-professor-5536452](https://www.theepochtimes.com/world/decolonisation-is-being-used-drive-classical-music-out-of-the-curriculum-professor-5536452)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T17:35:19+00:00

Professor Ian Pace speaks to "British Thought Leaders" in London on Nov. 9, 2023. (NTD)

## CBC Ombudsman Says Network Didn’t Breach Standards for Not Calling Hamas ‘Terrorists’
 - [https://www.theepochtimes.com/world/cbc-ombudsman-says-network-didnt-breach-standards-for-not-calling-hamas-terrorists-5536480](https://www.theepochtimes.com/world/cbc-ombudsman-says-network-didnt-breach-standards-for-not-calling-hamas-terrorists-5536480)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T17:17:25+00:00

Hamas terrorists move toward the border fence with Israel from Khan Yunis in the southern Gaza Strip on Oct. 7, 2023. (Said Khatib/AFP via Getty Images)

## 6 Teenagers Go on Trial for Their Alleged Role in 2020 Beheading of French Teacher
 - [https://www.theepochtimes.com/world/6-teenagers-go-on-trial-for-their-alleged-role-in-2020-beheading-of-french-teacher-5536404](https://www.theepochtimes.com/world/6-teenagers-go-on-trial-for-their-alleged-role-in-2020-beheading-of-french-teacher-5536404)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T16:52:40+00:00

Flowers next to a placard reading "I am a teacher" in tribute to Samuel Paty, it pictured near the Bois d'Aulne school in Conflans-Sainte-Honorine, outside Paris on Oct. 16, 2023. (Bertrand Guay, Pool via AP)

## Study Finds Higher Incidence of COVID-19 Among Consistent Mask Wearers
 - [https://www.theepochtimes.com/health/study-finds-higher-incidence-of-covid-19-among-consistent-mask-wearers-5536488](https://www.theepochtimes.com/health/study-finds-higher-incidence-of-covid-19-among-consistent-mask-wearers-5536488)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T16:50:21+00:00

A mask lays disgared on a sidewalk in Orange, Calif., on June 19, 2020. (John Fredricks/The Epoch Times)

## Armenia Remains ‘Ally,’ Head of Moscow-Led Military Alliance Asserts
 - [https://www.theepochtimes.com/world/armenia-remains-ally-head-of-moscow-led-military-alliance-asserts-5536471](https://www.theepochtimes.com/world/armenia-remains-ally-head-of-moscow-led-military-alliance-asserts-5536471)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T16:43:46+00:00

Armenian Prime Minister Nikol Pashinyan (L) and Russian President Vladimir Putin (R) shake hands as they attend the Collective Security Treaty Organization (CSTO) summit in Yerevan, Armenia, Nov. 23, 2022. (Hayk Baghdasaryan/Photolure via Reuters)

## Montreal Police Investigating After ‘Molotov Cocktail’ Thrown at Jewish Centre
 - [https://www.theepochtimes.com/world/montreal-police-investigating-after-molotov-cocktail-thrown-at-jewish-centre-5536493](https://www.theepochtimes.com/world/montreal-police-investigating-after-molotov-cocktail-thrown-at-jewish-centre-5536493)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T16:34:30+00:00

Police vehicles are shown in this file phone on Mar. 19, 2021. (The Canadian Press/Graham Hughes)

## Doctor: Women ‘Left to Pick up the Pieces’ Because of Legalised Abortion
 - [https://www.theepochtimes.com/world/doctor-women-left-to-pick-up-the-pieces-because-of-legalised-abortion-5535967](https://www.theepochtimes.com/world/doctor-women-left-to-pick-up-the-pieces-because-of-legalised-abortion-5535967)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T16:30:12+00:00

Dr. Calum Miller speaks to NTD's "British Thought Leaders" programme. (NTD)

## Indonesian Authorities Initiate Sea Patrols to Prevent Rohingya Arrivals
 - [https://www.theepochtimes.com/world/indonesian-authorities-initiate-sea-patrols-to-prevent-rohingya-arrivals-5536409](https://www.theepochtimes.com/world/indonesian-authorities-initiate-sea-patrols-to-prevent-rohingya-arrivals-5536409)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T16:02:45+00:00

A boat carries Rohingya people stranded at sea near Indonesia on Dec. 27, 2021. (Aditya Setiawan/Reuters)

## Young People More Likely to Favour Building on Green Belt Land: Poll
 - [https://www.theepochtimes.com/world/young-people-more-likely-to-favour-building-on-green-belt-land-poll-5536440](https://www.theepochtimes.com/world/young-people-more-likely-to-favour-building-on-green-belt-land-poll-5536440)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T16:00:49+00:00

Builders constructing homes on the Chilmington development in Ashford, Kent, England, on Jan. 13, 2020. (PA)

## First Case of Sexually Transmitted Virulent Monkeypox Strain Detected in Congo: WHO
 - [https://www.theepochtimes.com/health/first-case-of-sexually-transmitted-virulent-monkeypox-strain-detected-in-congo-who-5536463](https://www.theepochtimes.com/health/first-case-of-sexually-transmitted-virulent-monkeypox-strain-detected-in-congo-who-5536463)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T15:43:26+00:00

This 2003 electron microscope image made available by the Centers for Disease Control and Prevention shows mature, oval-shaped monkeypox virions (L) and spherical immature virions (R) obtained from a sample of human skin associated with the 2003 prairie dog outbreak. (Cynthia S. Goldsmith, Russell Regner/CDC via AP)

## 13 People Injured as Snowstorm Causes Havoc in Ukraine
 - [https://www.theepochtimes.com/world/13-people-injured-as-snowstorm-causes-havoc-in-ukraine-5536413](https://www.theepochtimes.com/world/13-people-injured-as-snowstorm-causes-havoc-in-ukraine-5536413)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T15:41:31+00:00

Emergency workers release a car which is stuck in snow during a heavy snow storm in Odesa region, Ukraine, in a handout picture released on Nov. 27, 2023. (Press service of the State Emergency Service of Ukraine in Odesa region/Handout via Reuters)

## Buyer Beware: Porch Piracy Set to Ramp up With Holiday Season Fast Approaching
 - [https://www.theepochtimes.com/world/buyer-beware-porch-piracy-set-to-ramp-up-with-holiday-season-fast-approaching-5536445](https://www.theepochtimes.com/world/buyer-beware-porch-piracy-set-to-ramp-up-with-holiday-season-fast-approaching-5536445)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T14:58:09+00:00

The company logo is shown on a FedEx delivery van in downtown Denver on Sept. 13, 2023. (The Canadian Press/AP-David Zalubowski)

## Israel and Hamas Look Open to Extending Truce on Its Final Day, With One More Hostage Swap Planned
 - [https://www.theepochtimes.com/world/israel-and-hamas-look-open-to-extending-truce-on-its-final-day-with-one-more-hostage-swap-planned-5536390](https://www.theepochtimes.com/world/israel-and-hamas-look-open-to-extending-truce-on-its-final-day-with-one-more-hostage-swap-planned-5536390)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T14:44:33+00:00

A group of Israelis celebrate as a helicopter carrying hostages released from the Gaza Strip lands at the helipad of the Schneider Children's Medical Center in Petah Tikva, Israel, on Nov. 26, 2023. (Leo Correa/AP Photo)

## BC in Court Against Pharma Companies in Bid to Certify Opioid Class-Action Lawsuit
 - [https://www.theepochtimes.com/world/bc-in-court-against-pharma-companies-in-bid-to-certify-opioid-class-action-lawsuit-5536435](https://www.theepochtimes.com/world/bc-in-court-against-pharma-companies-in-bid-to-certify-opioid-class-action-lawsuit-5536435)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T14:37:16+00:00

Prescription pills containing oxycodone and acetaminophen are shown in this June 20, 2012 photo. (The Canadian Press/Graeme Roy)

## Search for Answers Underway After Winnipeg Shooting Left Three Dead, Two Injured
 - [https://www.theepochtimes.com/world/search-for-answers-underway-after-winnipeg-shooting-left-three-dead-two-injured-5536424](https://www.theepochtimes.com/world/search-for-answers-underway-after-winnipeg-shooting-left-three-dead-two-injured-5536424)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T14:23:41+00:00

Police secure a crime scene where multiple people were killed in the 100 block of Langside Street in Winnipeg on Nov. 26, 2023. (The Canadian Press/David Lipnowski)

## LIVE NOW: Hamas and Israel Exchange Hostages for Prisoners as Part of Truce Deal (Nov. 27)
 - [https://www.theepochtimes.com/epochtv/live-view-of-israels-ofer-prison-in-west-bank-5536405](https://www.theepochtimes.com/epochtv/live-view-of-israels-ofer-prison-in-west-bank-5536405)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T14:02:50+00:00

Released Palestinian prisoners react in a vehicle as they leave the Israeli military prison, Ofer, amid a hostages-prisoners swap deal between Hamas and Israel, in Ramallah in the Israeli-occupied West Bank on Nov. 26, 2023. (Ammar Awad/Reuters)

## LIVE NOW: Hamas and Israel Exchange Hostages for Prisoners as Part of Truce Deal (Nov. 27)
 - [https://www.theepochtimes.com/epochtv/hamas-and-israel-exchange-hostages-for-prisoners-as-part-of-truce-deal-nov-27-post-5536405](https://www.theepochtimes.com/epochtv/hamas-and-israel-exchange-hostages-for-prisoners-as-part-of-truce-deal-nov-27-post-5536405)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T14:02:50+00:00

Released Palestinian prisoners react in a vehicle as they leave the Israeli military prison, Ofer, amid a hostages-prisoners swap deal between Hamas and Israel, in Ramallah in the Israeli-occupied West Bank on Nov. 26, 2023. (Ammar Awad/Reuters)

## 2 Ballistic Missiles Fired Toward US Destroyer Aiding Israel-Linked Tanker
 - [https://www.theepochtimes.com/world/2-ballistic-missiles-fired-toward-us-destroyer-aiding-israel-linked-tanker-5536316](https://www.theepochtimes.com/world/2-ballistic-missiles-fired-toward-us-destroyer-aiding-israel-linked-tanker-5536316)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T14:02:06+00:00

The tanker Central Park is seen. (Zodiac Maritime via AP)

## After Machines Fail, ‘Rat Miners’ to Help Rescue 41 Men Stuck in Indian Tunnel
 - [https://www.theepochtimes.com/world/after-machines-fail-rat-miners-to-help-rescue-41-men-stuck-in-indian-tunnel-5536398](https://www.theepochtimes.com/world/after-machines-fail-rat-miners-to-help-rescue-41-men-stuck-in-indian-tunnel-5536398)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T13:19:57+00:00

Rat miners stand before they begin manual drilling as rescue operations are in progress after workers got trapped in a collapse of an under-construction tunnel, in Uttarkashi in the northern state of Uttarakhand, India, on Nov. 27, 2023. (Francis Mascarenhas/Reuters)

## Charity Commission Chief Warns of Consequences for ‘Forums of Hate Speech’
 - [https://www.theepochtimes.com/world/charity-commission-chief-warns-of-consequences-for-forums-of-hate-speech-5536362](https://www.theepochtimes.com/world/charity-commission-chief-warns-of-consequences-for-forums-of-hate-speech-5536362)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T13:03:00+00:00

Demonstrators (L to R, the chief rabbi, Sir Ephraim Mirvis, Eddie Marsan, Tracy-Ann Oberman, Rachel Riley, Maureen Lipman, unknown man, and Vanessa Feltz take part in a march against anti-Semitism on Nov. 26, 2023. (Jordan Pettitt/PA Wire)

## Russia Adds Meta’s Communications Director to Wanted List
 - [https://www.theepochtimes.com/world/russia-adds-metas-communications-director-to-wanted-list-5536242](https://www.theepochtimes.com/world/russia-adds-metas-communications-director-to-wanted-list-5536242)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T10:28:07+00:00

The logo of Meta in Davos, Switzerland, on May 22, 2022. (Arnd Wiegmann/Reuters)

## US Says Warship War Obeying ‘International Law’ in South China Sea as China Protests
 - [https://www.theepochtimes.com/china/us-says-warship-war-obeying-international-law-in-south-china-sea-as-china-protests-5536123](https://www.theepochtimes.com/china/us-says-warship-war-obeying-international-law-in-south-china-sea-as-china-protests-5536123)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T07:07:57+00:00



## Australian PM Pressed on Dangerous Chinese Sonar Incident in Parliament
 - [https://www.theepochtimes.com/world/australian-pm-pressed-on-dangerous-chinese-sonar-incident-in-parliament-5536284](https://www.theepochtimes.com/world/australian-pm-pressed-on-dangerous-chinese-sonar-incident-in-parliament-5536284)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T06:30:44+00:00

Australian Prime Minister Anthony Albanese reacts during Question Time in the House of Representatives at Parliament House in Canberra on Nov. 27, 2023. (AAP Image/Lukas Coch)

## $255 Million to Keep Tags on Immigrants Released From Detention
 - [https://www.theepochtimes.com/world/255-million-to-keep-tags-on-immigrants-released-from-detention-5536215](https://www.theepochtimes.com/world/255-million-to-keep-tags-on-immigrants-released-from-detention-5536215)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T06:13:33+00:00

Activists in support of refugees gather outside Park Hotel in Melbourne, Australia, on Jan. 6, 2022. (Diego Fedele/Getty Images)

## Injuring Divers With Sonar Show Us What the CCP Really Thinks
 - [https://www.theepochtimes.com/opinion/injuring-divers-with-sonar-show-us-what-the-ccp-really-thinks-5536239](https://www.theepochtimes.com/opinion/injuring-divers-with-sonar-show-us-what-the-ccp-really-thinks-5536239)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T05:49:35+00:00

The type 052C destroyer Haikou of the Chinese People's Liberation Army (PLA) Navy participates in a naval parade to commemorate the 70th anniversary of the founding of China's PLA Navy in the sea near Qingdao, in eastern China's Shandong province on April 23, 2019. (Mark Schiefelbein/AFP via Getty Images)

## Home Affairs Chief Dismissed for Breaching Code of Conduct
 - [https://www.theepochtimes.com/world/home-affairs-chief-dismissed-for-breaching-code-of-conduct-5536225](https://www.theepochtimes.com/world/home-affairs-chief-dismissed-for-breaching-code-of-conduct-5536225)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T04:41:02+00:00

The secretary of the home affairs department, Mike Pezzullo is questioned during Senate Estimates at Parliament House on February 18, 2019 in Canberra, Australia. (Tracey Nearmy/Getty Images)

## ‘Demonising the State of Israel’: New Senator Raises Greens’ Anti-Semitism
 - [https://www.theepochtimes.com/world/demonising-the-state-of-israel-new-senator-raises-greens-anti-semitism-5536127](https://www.theepochtimes.com/world/demonising-the-state-of-israel-new-senator-raises-greens-anti-semitism-5536127)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T03:46:09+00:00

Smoke in the Gaza Strip as seen from Israel's border with the Gaza Strip, in southern Israel, on Oct. 18, 2023. (Amir Cohen/Reuters)

## 12 Crew Members Missing, One Dead After Cargo Ship Sinks Off Greek Island in Stormy Seas
 - [https://www.theepochtimes.com/world/12-crew-members-missing-one-dead-after-cargo-ship-sinks-off-greek-island-in-stormy-seas-5536075](https://www.theepochtimes.com/world/12-crew-members-missing-one-dead-after-cargo-ship-sinks-off-greek-island-in-stormy-seas-5536075)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T03:28:43+00:00

Paramedics transfer a survivor of a shipwreck at a hospital, on the northeastern Aegean Sea island of Lesbos, Greece, on Nov. 26, 2023. (Panagiotis Balaskas/AP Photo)

## NZ Greens Launch Petition to Stop Government’s Plan to Overturn Oil, Gas Ban
 - [https://www.theepochtimes.com/world/nz-greens-launch-petition-to-stop-governments-plan-to-overturn-oil-gas-ban-5536159](https://www.theepochtimes.com/world/nz-greens-launch-petition-to-stop-governments-plan-to-overturn-oil-gas-ban-5536159)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T02:57:50+00:00

Green Party Leader James Shaw speaks to media in Auckland, New Zealand, on Sept. 23, 2017. (Fiona Goodall/Getty Images)

## Greens Leader Backs Blockade of the World’s Largest Coal Port After 100 Arrested
 - [https://www.theepochtimes.com/world/greens-leader-backs-blockade-of-the-worlds-largest-coal-port-after-100-arrested-5536135](https://www.theepochtimes.com/world/greens-leader-backs-blockade-of-the-worlds-largest-coal-port-after-100-arrested-5536135)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T02:43:05+00:00

People take to the water as they blockade access to the world's busiest coal port in protest for climate action at Horseshoe Beach in Newcastle, Australia on Nov. 26, 2023. (Roni Bintang/Getty Images)

## New Zealand’s New Government Sworn In, Parliament Expected to Open Next Week
 - [https://www.theepochtimes.com/world/new-zealands-new-government-sworn-in-parliament-expected-to-open-next-week-5536167](https://www.theepochtimes.com/world/new-zealands-new-government-sworn-in-parliament-expected-to-open-next-week-5536167)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T02:41:59+00:00

National leader Christopher Luxon arrives at Shed 10 after winning the general election in Auckland, New Zealand on Oct. 14, 2023. (Fiona Goodall/Getty Images)

## A 4-Day School Week Puts Students Last
 - [https://www.theepochtimes.com/opinion/a-4-day-school-week-puts-students-last-5536118](https://www.theepochtimes.com/opinion/a-4-day-school-week-puts-students-last-5536118)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T01:58:33+00:00

A student does school work on a laptop while being home-schooled in Sydney, Australia, on April 09, 2020. (Brendon Thorne/Getty Images)

## Where is the Support to Slow Male Suicide Rates?
 - [https://www.theepochtimes.com/opinion/where-is-the-support-to-slow-male-suicide-rates-5536128](https://www.theepochtimes.com/opinion/where-is-the-support-to-slow-male-suicide-rates-5536128)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T01:51:08+00:00

Australia is failing some of its most vulnerable. (John Christian Fjellestad/Shutterstock)

## Think Tank Calls for ‘Ambitious Targets’ to Close Vaccination Gap
 - [https://www.theepochtimes.com/world/think-tank-calls-for-ambitious-targets-to-close-vaccination-gap-5536120](https://www.theepochtimes.com/world/think-tank-calls-for-ambitious-targets-to-close-vaccination-gap-5536120)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T01:22:12+00:00

A nurse prepares a vaccine on Oct. 3, 2021. (Lisa Maree Williams/Getty Images)

## English to Become Official Language of New Zealand Under New Government
 - [https://www.theepochtimes.com/world/english-to-become-official-language-of-new-zealand-under-new-government-5535918](https://www.theepochtimes.com/world/english-to-become-official-language-of-new-zealand-under-new-government-5535918)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T01:08:50+00:00

(L-R) Winston Peters, leader of New Zealand First party, New Zealand's incoming Prime Minister Christopher Luxon, and David Seymour, leader of the ACT New Zealand party, attend the signing of an agreement to form a three-party coalition government at Parliament in Wellington on Nov. 24, 2023. (Marty Melville/AFP via Getty Images)

## CRTC to Hold Hearing on Licensing Foreign Broadcasters
 - [https://www.theepochtimes.com/world/crtc-to-hold-hearing-on-licensing-foreign-broadcasters-5535970](https://www.theepochtimes.com/world/crtc-to-hold-hearing-on-licensing-foreign-broadcasters-5535970)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-27T00:58:28+00:00

The social media page of the Canadian Radio-television and Telecommunications Commission (CRTC) on a cellphone in a file photo. (The Canadian Press/Sean Kilpatrick)

