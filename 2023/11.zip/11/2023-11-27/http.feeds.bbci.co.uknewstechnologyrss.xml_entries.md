# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Elon Musk visits Israel after antisemitism row
 - [https://www.bbc.co.uk/news/technology-67544945?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-67544945?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-11-27T21:35:06+00:00

The X boss, recently accused of antisemitism, discussed tackling hate with Israel's president.

## Children making AI-generated child abuse images, says charity
 - [https://www.bbc.co.uk/news/technology-67521226?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-67521226?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-11-27T15:03:29+00:00

A charity says it is receiving "small numbers" of reports from schools but now is the time to act.

## The job sharing apps that feel like online dating
 - [https://www.bbc.co.uk/news/business-67413201?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-67413201?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-11-27T00:05:56+00:00

New website platforms are working like matchmakers to connect potential job sharers.

