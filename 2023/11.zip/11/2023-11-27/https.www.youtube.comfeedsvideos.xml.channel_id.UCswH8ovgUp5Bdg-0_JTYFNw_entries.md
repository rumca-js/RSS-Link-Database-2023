# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## The U.S. Military Just Did WHAT To Unvaccinated Soldiers?!
 - [https://www.youtube.com/watch?v=iUuMACRGZ-o](https://www.youtube.com/watch?v=iUuMACRGZ-o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2023-11-27T18:19:09+00:00

Get your gold here: https://offers.americanhartfordgold.com/brand/
Call 866 505 8315 or text BRAND to 998899

The US Army is having a hard time recruiting. Now it's asking soldiers dismissed for refusing the COVID-19 vaccine to come back. 

Support Me Directly HERE: https://rb.rumble.com

WATCH me LIVE weekdays on Rumble: https://bit.ly/russellbrand-rumble

