# Source:Kotaku, URL:https://kotaku.com/rss, language:en

## Meet Regitube, The ‘Fake’ Pokémon Who’s A Hit Among Fans
 - [https://kotaku.com/pokemon-regitube-regifloat-water-regi-tiktok-1851051335](https://kotaku.com/pokemon-regitube-regifloat-water-regi-tiktok-1851051335)
 - RSS feed: https://kotaku.com/rss
 - date published: 2023-11-27T21:45:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/e5079cf391ce7bfce4402bc4c8602744.jpg" /><p>Fan-made Pokémon are nothing new, but the community seldom rallies around one like they have Regitube (or Regifloat, depending on who you ask). The hypothetical water-type Legendary Giant originated in a TikTok shitpost and has since become a legend within the Pokémon fandom, inspiring fan art, memes, and even modded…</p><p><a href="https://kotaku.com/pokemon-regitube-regifloat-water-regi-tiktok-1851051335">Read more...</a></p>

## New Disney Movie Wish Could Have Big Ramifications For Kingdom Hearts
 - [https://kotaku.com/wish-kingdom-hearts-4-asha-magnifico-sora-1851050123](https://kotaku.com/wish-kingdom-hearts-4-asha-magnifico-sora-1851050123)
 - RSS feed: https://kotaku.com/rss
 - date published: 2023-11-27T20:45:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/88908c83c7af9db7412dbd82794af7a8.jpg" /><p>Wish, the 62nd film released by Walt Disney Animation Studios, is a bad movie. The film is meant to celebrate the studio’s 100th anniversary, but instead, its incoherent story and reliance on millennial cliches for cheap jokes come off like it was fed into an AI generator and spat out onto the big screen. And the…</p><p><a href="https://kotaku.com/wish-kingdom-hearts-4-asha-magnifico-sora-1851050123">Read more...</a></p>

## GTA: Vice City's Weird Moon Easter Egg Finally Explained
 - [https://kotaku.com/grand-theft-auto-3-moon-vice-city-san-andreas-gta-1851049650](https://kotaku.com/grand-theft-auto-3-moon-vice-city-san-andreas-gta-1851049650)
 - RSS feed: https://kotaku.com/rss
 - date published: 2023-11-27T19:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/d37c0502ab791940d04664643d186ec0.jpg" /><p>In 2001’s genre-defining PlayStation 2 smash <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/gta-iii-made-just-vibing-in-its-world-incredible-1847929103">Grand Theft Auto III</a>, if you pulled out a sniper rifle and shot at the moon, it would change size. For years, fans tried to explain why this funny little secret was included in the game. Was it a reference to something? A smaller part of a larger secret? Now, in 2023,…</p><p><a href="https://kotaku.com/grand-theft-auto-3-moon-vice-city-san-andreas-gta-1851049650">Read more...</a></p>

## TGA’s Geoff Keighley Weighs In On Dave The Diver Nomination Controversy
 - [https://kotaku.com/tgas-dave-the-diver-indie-game-geoff-keighley-debate-1851049334](https://kotaku.com/tgas-dave-the-diver-indie-game-geoff-keighley-debate-1851049334)
 - RSS feed: https://kotaku.com/rss
 - date published: 2023-11-27T18:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/dd0a3336b95d56f3e5f308c1fb50f7e7.jpg" /><p>An intense debate ignited November 13, when The Game Awards host Geoff Keighley announced the nominees for this year’s trophy ceremony. While some folks were surprised Pikachu face by<a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/starfield-ghosted-at-the-2023-game-awards-1851017191"> Starfield’s absence</a>, most people were shook by one particular title offered up for the “Best Independent Game” category. Now, after a…</p><p><a href="https://kotaku.com/tgas-dave-the-diver-indie-game-geoff-keighley-debate-1851049334">Read more...</a></p>

## Kids Want Digital Currency And Subscriptions More Than New Games This Xmas
 - [https://kotaku.com/video-game-esa-report-digital-currency-vbucks-christmas-1851049230](https://kotaku.com/video-game-esa-report-digital-currency-vbucks-christmas-1851049230)
 - RSS feed: https://kotaku.com/rss
 - date published: 2023-11-27T18:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/ea677a39199c1b6b4b3c8ac80df7f211.jpg" /><p>The <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/esa-halts-political-donations-after-u-s-capitol-stormi-1846046945">Entertainment Software Association (ESA)</a> has revealed new data showing kids want video game-related gifts more than anything else this holiday season. But if you dig into the data a little bit more, you’ll discover that most kids don’t want a new physical game. Instead, what they’re really looking for in their…</p><p><a href="https://kotaku.com/video-game-esa-report-digital-currency-vbucks-christmas-1851049230">Read more...</a></p>

## Destiny 2 Promises More Content To Fill Void Left By Big Expansion Delay
 - [https://kotaku.com/destiny-2-final-shape-delay-season-wish-into-light-1851049227](https://kotaku.com/destiny-2-final-shape-delay-season-wish-into-light-1851049227)
 - RSS feed: https://kotaku.com/rss
 - date published: 2023-11-27T17:45:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/3fce441dc2d9e1e33f271a8ce6773af1.jpg" /><p>Bungie has finally confirmed that The Final Shape, <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/destiny-2-final-shape-forsaken-layoffs-delay-bungie-1850986895">Destiny 2's major expansion 10 years in the making</a>, has been delayed, and will now arrive June 4 instead of on its previously planned release date of February 27. More importantly, the studio explained what players will be doing in the meantime. </p><p><a href="https://kotaku.com/destiny-2-final-shape-delay-season-wish-into-light-1851049227">Read more...</a></p>

## It Happened To Me: The GameStop Black Friday Deal From Hell
 - [https://kotaku.com/gamestop-black-friday-nintendo-switch-zelda-1851049114](https://kotaku.com/gamestop-black-friday-nintendo-switch-zelda-1851049114)
 - RSS feed: https://kotaku.com/rss
 - date published: 2023-11-27T17:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/1130aca518bc7246e79adc990bcfd93a.jpg" /><p>One of my <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/the-black-friday-backlog-of-shame-1820739047">favorite Black Friday traditions</a> is scrolling through GameStop on my phone and getting a bunch of cool games for cheap. Usually it works out just fine. Last weekend it was a nightmare. It’s hard to convey just how terrible navigating the experience of trying to buy something from GameStop has become in 2023,…</p><p><a href="https://kotaku.com/gamestop-black-friday-nintendo-switch-zelda-1851049114">Read more...</a></p>

## The Game Awards Is Beefing Up Security Following Stage Invasions
 - [https://kotaku.com/the-game-awards-2023-geoff-keighley-security-1851048956](https://kotaku.com/the-game-awards-2023-geoff-keighley-security-1851048956)
 - RSS feed: https://kotaku.com/rss
 - date published: 2023-11-27T16:45:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/c479b467e8c8d8e7657d36c9c0695c80.jpg" /><p>Award ceremonies aren’t important, and if we all stopped looking at them, they’d stop existing. Anyway, The Game Awards are coming up next week, December 7, and we’re hearing news about some planned changes for this year’s outing. <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/summer-game-fest-geoff-keighley-women-diversity-1850553957">Will they let women on stage?</a> Ha ha, no one’s mentioned that. But we have heard they’ll…</p><p><a href="https://kotaku.com/the-game-awards-2023-geoff-keighley-security-1851048956">Read more...</a></p>

## Spider-Man 2 Reportedly Cut A Ton Of Venom Content
 - [https://kotaku.com/spider-man-2-miles-morales-venom-symbiote-cut-content-1851048904](https://kotaku.com/spider-man-2-miles-morales-venom-symbiote-cut-content-1851048904)
 - RSS feed: https://kotaku.com/rss
 - date published: 2023-11-27T16:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/7797015c8c0c7a626f05c02f05b14006.jpg" /><p>About one month on from<a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/marvel-spider-man-2-review-ps5-venom-miles-morales-1850929271"> Marvel’s Spider-Man 2</a>'s launch, we’re learning some new details about Insomniac Games’ open-world robber-stopper RPG. According to a report by YouTuber Evan Filarca, the game had a ton of content cut before releasing on October 20, particularly relating to <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/spider-man-3-has-plenty-of-ways-to-bring-back-venom-1850976956">the big-bad Venom</a>.</p><p><a href="https://kotaku.com/spider-man-2-miles-morales-venom-symbiote-cut-content-1851048904">Read more...</a></p>

## Baldur’s Gate 3 Takes Place In A Very Small Part Of The Dungeons & Dragons Map
 - [https://kotaku.com/baldurs-gate-3-map-faerun-location-dungeons-dragons-1851048914](https://kotaku.com/baldurs-gate-3-map-faerun-location-dungeons-dragons-1851048914)
 - RSS feed: https://kotaku.com/rss
 - date published: 2023-11-27T15:45:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/766d36bc54ff6b31ae8994a21e5caf3d.jpg" /><p>Larian Studios’ hit RPG <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/baldurs-gate-3-dungeons-dragons-romance-characters-1850989467">Baldur’s Gate 3</a> is expansive and consuming, but its map isn’t quite the size of something you’d expect in open-world games like The Witcher 3 or The Elder Scrolls V: Skyrim. So it shouldn’t be surprising that a fan was able to pretty much mark exactly where in the Dungeons & Dragons universe…</p><p><a href="https://kotaku.com/baldurs-gate-3-map-faerun-location-dungeons-dragons-1851048914">Read more...</a></p>

## One Of The Best Assassin's Creed Games Is Free On PC
 - [https://kotaku.com/assassins-creed-pc-free-syndicate-ubisoft-connect-1851048773](https://kotaku.com/assassins-creed-pc-free-syndicate-ubisoft-connect-1851048773)
 - RSS feed: https://kotaku.com/rss
 - date published: 2023-11-27T15:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/a739d5e20ae88dbe3f6aefb8051248ee.jpg" /><p>Assassin’s Creed Syndicate, the Ubisoft stealth adventure series’ 2015 entry featuring dual protagonists that’s set in 19th century London, is currently free on PC until December 6. There’s just one twist: You’ll need to get it from Ubisoft Connect launcher (insert horror emoji). Don’t hate the messenger.</p><p><a href="https://kotaku.com/assassins-creed-pc-free-syndicate-ubisoft-connect-1851048773">Read more...</a></p>

## The Week In Games: Dark Knights And Dark Princes
 - [https://kotaku.com/november-games-this-week-batman-arkham-trilogy-1851048733](https://kotaku.com/november-games-this-week-batman-arkham-trilogy-1851048733)
 - RSS feed: https://kotaku.com/rss
 - date published: 2023-11-27T14:50:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/824ae58adf304d43dde66bdb4384e9ff.jpg" /><p><a href="https://kotaku.com/november-games-this-week-batman-arkham-trilogy-1851048733">Read more...</a></p>

