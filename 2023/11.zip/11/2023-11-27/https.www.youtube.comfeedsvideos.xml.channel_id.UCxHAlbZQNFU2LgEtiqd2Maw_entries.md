# Source:C++ Weekly With Jason Turner, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCxHAlbZQNFU2LgEtiqd2Maw, language:en

## C++ Weekly - Ep 404 - How (and Why) To Write Code That Avoids std::move
 - [https://www.youtube.com/watch?v=6SaUwqw4ueE](https://www.youtube.com/watch?v=6SaUwqw4ueE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCxHAlbZQNFU2LgEtiqd2Maw
 - date published: 2023-11-27T16:29:49+00:00

☟☟ Awesome T-Shirts! Sponsors! Books! ☟☟

Calling all C++ developers: A free preview of CLion with much faster core IDE functions is out! 🎉 Introducing CLion Nova – a version of CLion with the C++ language engine from ReSharper C++ and JetBrains Rider. It brings:

    Faster highlighting speeds
    A more responsive UI
    Significantly fewer freezes and hangs in refactorings


Learn more and use it for free: https://jb.gg/cpp_nova 

Episode Notes: https://github.com/lefticus/cpp_weekly/issues/299
Episode 125 - The Optimal Way To Return From A Function - https://youtu.be/9mWWNYRHAIQ

T-SHIRTS AVAILABLE!

► Are you a constexprt? https://my-store-d16a2f.creator-spring.com/


WANT MORE JASON?

► My Training Classes: http://emptycrate.com/training.html
► Follow me on twitter: https://twitter.com/lefticus


SUPPORT THE CHANNEL

► Patreon: https://www.patreon.com/lefticus 
► Github Sponsors: https://github.com/sponsors/lefticus
► Paypal Donation: https://www.paypal.com/donate/?hosted_butto

