# Source:CodeProject, URL:https://www.codeproject.com/WebServices/NewsRSS.aspx, language:en-US

## C++ needs undefined behavior, but maybe less
 - [https://www.codeproject.com/script/News/View.aspx?nwid=63395](https://www.codeproject.com/script/News/View.aspx?nwid=63395)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-11-27T05:00:00+00:00

I thought that was C++'s middle name?

## Church entirely devoted to worshiping AI gets a reboot
 - [https://www.codeproject.com/script/News/View.aspx?nwid=63398](https://www.codeproject.com/script/News/View.aspx?nwid=63398)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-11-27T05:00:00+00:00

And the AI said, "Let x= 01101100 01101001 01100111 01101000 01110100"

## Generating power on Earth from the coldness of deep space
 - [https://www.codeproject.com/script/News/View.aspx?nwid=63393](https://www.codeproject.com/script/News/View.aspx?nwid=63393)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-11-27T05:00:00+00:00

"In this house, we obey the laws of thermodynamics!"

## Generative AI adoption speed unprecedented, O’Reilly survey says
 - [https://www.codeproject.com/script/News/View.aspx?nwid=63391](https://www.codeproject.com/script/News/View.aspx?nwid=63391)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-11-27T05:00:00+00:00

If all the other kids start an AI Apocalypse, would you do it too?

## Git discussion Bingo
 - [https://www.codeproject.com/script/News/View.aspx?nwid=63392](https://www.codeproject.com/script/News/View.aspx?nwid=63392)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-11-27T05:00:00+00:00



## North Korean hackers are posing as job interviewers - don't be fooled
 - [https://www.codeproject.com/script/News/View.aspx?nwid=63390](https://www.codeproject.com/script/News/View.aspx?nwid=63390)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-11-27T05:00:00+00:00

It's never a good sign if they start the interview by asking how you feel about the Supreme Leader

## Penny for your thoughts
 - [https://www.codeproject.com/script/News/View.aspx?nwid=63389](https://www.codeproject.com/script/News/View.aspx?nwid=63389)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-11-27T05:00:00+00:00

And we are all richer for it

## Robocar tech biz sues Nvidia, claims stolen code shared in Teams meeting blunder
 - [https://www.codeproject.com/script/News/View.aspx?nwid=63396](https://www.codeproject.com/script/News/View.aspx?nwid=63396)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-11-27T05:00:00+00:00

More proof Microsoft Teams is dangerous

## Software development and postmortems
 - [https://www.codeproject.com/script/News/View.aspx?nwid=63394](https://www.codeproject.com/script/News/View.aspx?nwid=63394)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-11-27T05:00:00+00:00

It's all fun-and-games until the autopsy

## The radiating programmer
 - [https://www.codeproject.com/script/News/View.aspx?nwid=63397](https://www.codeproject.com/script/News/View.aspx?nwid=63397)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-11-27T05:00:00+00:00

"Shine on you crazy diamond"

