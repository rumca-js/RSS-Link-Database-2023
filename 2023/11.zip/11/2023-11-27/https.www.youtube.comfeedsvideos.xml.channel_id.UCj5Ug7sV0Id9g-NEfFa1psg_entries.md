# Source:Tomasz Samołyk, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCj5Ug7sV0Id9g-NEfFa1psg, language:pl-PL

## Jesteś w ciąży i nie wiesz co dalej? Boisz się i potrzebujesz pomocy? Poznaj "Dwie kreski" (rozmowa)
 - [https://www.youtube.com/watch?v=utBes07Y7H0](https://www.youtube.com/watch?v=utBes07Y7H0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCj5Ug7sV0Id9g-NEfFa1psg
 - date published: 2023-11-27T15:50:58+00:00

Czujesz się zaniepokojona przez ciążę i szukasz wsparcia? Masz dość kontrowersji wokół tematu czarnych marszy, wyroku Trybunału, oceniania i nachalnych próśb o decyzje? Zapraszam do obejrzenia wywiadu, który przeprowadziłem z wolontariuszkami Stowarzyszenia Dwie Kreski! 🌟

#dwiekreski #ciąża #pomoc 

🌟 Stowarzyszenie Dwie Kreski zaprasza do działania! 🌟

👉 Dowiedz się więcej o misji "Dwóch kresek": www.dwiekreski.pl. 
👉 Dołącz do "Dwóch kresek" angażując się w wybrany przez Ciebie sposób: https://dwiekreski.pl/dolacz/
👉 Wesprzyj finansowo "Dwie kreski": https://dwiekreski.pl/wspieraj/
👉 Rozmawiaj o tym filmie ze znajomymi 🗣️ i podawaj go dalej informację o "Dwóch kreskach" 
👉 Dołącz do Jarmarku Świątecznego Stowarzyszenia Dwie Kreski na Facebooku: https://www.facebook.com/groups/3731191207116822 

Jeśli chcesz wspomóc moją działalność, istnieją następujące możliwości wsparcia:
👉 Dołączenie do mojej grupy Patronów: https://patronite.pl/Samolyk
👉 Skorzystanie z przycisku "Wesprzyj", zn

