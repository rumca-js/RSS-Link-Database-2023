# Source:Sekurak, URL:https://sekurak.pl/rss, language:pl-PL

## Wyciek wrażliwych danych medycznych oraz osobowych z ALAB Laboratoria. Można sprawdzić czy Twoje dane wyciekły.
 - [https://sekurak.pl/wyciek-wrazliwych-danych-medycznych-oraz-osobowych-z-alab-laboratoria-mozna-sprawdzic-czy-twoje-dane-wyciekly](https://sekurak.pl/wyciek-wrazliwych-danych-medycznych-oraz-osobowych-z-alab-laboratoria-mozna-sprawdzic-czy-twoje-dane-wyciekly)
 - RSS feed: https://sekurak.pl/rss
 - date published: 2023-11-27T21:35:51+00:00

<p>O wycieku napisała kompleksowo Zaufana Trzecia Strona, sama dotknięta firma przygotowała stosowne oświadczenie. Ne tę chwilę nie mamy więcej do dodania, a w skrócie: Interface na razie nie jest super oczywisty. Aby sprawdzić czy Twoje dane znalazły się w ostatnim wycieku z ALAB Laboratoria &#8211; wystarczy: a) Zalogować się w...</p>
<p>Artykuł <a href="https://sekurak.pl/wyciek-wrazliwych-danych-medycznych-oraz-osobowych-z-alab-laboratoria-mozna-sprawdzic-czy-twoje-dane-wyciekly/" rel="nofollow">Wyciek wrażliwych danych medycznych oraz osobowych z ALAB Laboratoria. Można sprawdzić czy Twoje dane wyciekły.</a> pochodzi z serwisu <a href="https://sekurak.pl" rel="nofollow">Sekurak</a>.</p>

## Współpracuj komercyjnie z sekurakiem – dwa różne ~stanowiska: teksty / prowadzenie szkoleń
 - [https://sekurak.pl/wspolpracuj-komercyjnie-z-sekurakiem-dwa-rozne-stanowiska-teksty-prowadzenie-szkolen](https://sekurak.pl/wspolpracuj-komercyjnie-z-sekurakiem-dwa-rozne-stanowiska-teksty-prowadzenie-szkolen)
 - RSS feed: https://sekurak.pl/rss
 - date published: 2023-11-27T18:39:08+00:00

<p>Przejdźmy od razu do szczegółów. Jeśli chcesz regularnie lub okazjonalnie pracować dla sekuraka, czytaj dalej :-) Lub od razu wypełnij formularz. W jakich obszarach poszukujemy współpracowników? W obu obszarach proponujemy regularną lub luźną współpracę (np. 1 tekst na miesiąc), chociaż w przypadku newsów może być z tym nieco trudniej (wymagana...</p>
<p>Artykuł <a href="https://sekurak.pl/wspolpracuj-komercyjnie-z-sekurakiem-dwa-rozne-stanowiska-teksty-prowadzenie-szkolen/" rel="nofollow">Współpracuj komercyjnie z sekurakiem – dwa różne ~stanowiska: teksty / prowadzenie szkoleń</a> pochodzi z serwisu <a href="https://sekurak.pl" rel="nofollow">Sekurak</a>.</p>

