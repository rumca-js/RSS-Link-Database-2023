# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## Excess deaths in 2023
 - [https://www.youtube.com/watch?v=nJ0QL7EwJp4](https://www.youtube.com/watch?v=nJ0QL7EwJp4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2023-11-27T10:32:03+00:00

Iceland halts Moderna jabs over heart-inflammation fears

https://medicalxpress.com/news/2021-10-iceland-halts-moderna-jabs-heart-inflammation.html

Iceland suspended Moderna anti-COVID vaccine
 
Chief Epidemiologist Þórólfur Guðnason

https://www.icelandreview.com/news/moderna-use-on-pause-in-iceland/

Iceland will halt the use of Moderna vaccine

Decision was made after reviewing new data from the Nordic countries, 

which shows an increased incidence of myocarditis,

as well as pericarditis
 
Decision was announced on website of the Directorate of health

https://island.is/um-embaettid/frettir/frett/item47717/Notkun-COVID-19-boluefnis-Moderna-a-Islandi

"the increased incidence of myocarditis and pericarditis after vaccination with the Moderna vaccine, as well as with vaccination using Pfizer/BioNTech,"

Sweden

Currently restricts Moderna to people individuals born after 1991. 

Norway and Denmark

Recommend against Moderna for children aged 12 – 17. 

https://island.is/en

https

