# Source:POLITICO, URL:https://www.politico.eu/feed, language:en-US

## Greek PM slams Sunak as row over Elgin Marbles escalates
 - [https://www.politico.eu/article/greek-pm-slams-sunak-as-row-over-elgin-marbles-escalates/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/greek-pm-slams-sunak-as-row-over-elgin-marbles-escalates/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-11-27T21:01:48+00:00

Kyriakos Mitsotakis expresses his 'annoyance' that Sunak called off a meeting at late notice

## Brussels must trim €13B from proposed budget increase, EU capitals say
 - [https://www.politico.eu/article/eu-capitals-tell-brussels-to-cut-down-its-budget-increase/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/eu-capitals-tell-brussels-to-cut-down-its-budget-increase/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-11-27T19:18:57+00:00

More frugal member countries want the Commission to redeploy existing funds to pay for new priorities.

## Poland’s zombie government shuffles into being
 - [https://www.politico.eu/article/poland-government-election-donald-tusk-mateusz-morawiecki-andrzej-duda/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/poland-government-election-donald-tusk-mateusz-morawiecki-andrzej-duda/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-11-27T17:03:38+00:00

One former PM joked that the new Cabinet led by Mateusz Morawiecki would have a lifespan shorter than that of a house fly.

## Tesla sues Sweden over blocked license plates
 - [https://www.politico.eu/article/tesla-sues-sweden-over-blocked-license-plates/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/tesla-sues-sweden-over-blocked-license-plates/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-11-27T17:01:54+00:00

The Swedish Transport Agency denies  blocking the distribution of license plates.

## Israel-Hamas truce extended by two days, Qatari official says
 - [https://www.politico.eu/article/israel-hamas-truce-extended-by-two-days-qatari-official-says/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/israel-hamas-truce-extended-by-two-days-qatari-official-says/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-11-27T16:47:40+00:00

The previous cease-fire deal was set to expire on Tuesday morning.

## Swedish PM rebukes far-right leader who said mosques should be flattened
 - [https://www.politico.eu/article/swedish-pm-ulf-kristersson-slams-far-right-party-leader-for-suggesting-mosques-should-be-demolished/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/swedish-pm-ulf-kristersson-slams-far-right-party-leader-for-suggesting-mosques-should-be-demolished/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-11-27T16:44:31+00:00

'In Sweden, we don't tear down places of worship,' Ulf Kristersson says.

## Bavaria’s premier calls for early election as budget crisis roils German politics
 - [https://www.politico.eu/article/bavaria-premier-markus-soder-calls-for-early-election-as-budget-crisis-roils-german-politics/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/bavaria-premier-markus-soder-calls-for-early-election-as-budget-crisis-roils-german-politics/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-11-27T16:23:58+00:00

As Germany's ruling coalition struggles to deal with the political fallout of the budget crisis, the conservative opposition is pouncing.

## Ireland: Israel is overreacting on Varadkar
 - [https://www.politico.eu/article/ireland-israel-overreacting-leo-varadkar/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/ireland-israel-overreacting-leo-varadkar/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-11-27T15:40:14+00:00

Israeli foreign minister summoned the Irish envoy over prime minister's biblical remarks.

## COVID inquiry: UK’s top official Simon Case ‘excused’ from appearing this year
 - [https://www.politico.eu/article/covid-inquiry-uk-top-official-simon-case-excused-from-appearing-this-year/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/covid-inquiry-uk-top-official-simon-case-excused-from-appearing-this-year/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-11-27T13:54:47+00:00

Britain's most senior official won't be giving evidence until next year at the earliest.

## UAE plotted to use COP28 to push for oil and gas deals, leaked notes show
 - [https://www.politico.eu/article/uae-cop28-climate-oil-gas-deal-leak-sultan-ahmed-al-jaber/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/uae-cop28-climate-oil-gas-deal-leak-sultan-ahmed-al-jaber/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-11-27T12:55:55+00:00

Documents include estimates of national oil company's commercial interests in the targeted countries.

## ‘Vast worldwide sewer’: Paris mayor quits X with swipe at Elon Musk
 - [https://www.politico.eu/article/paris-mayor-hidalgo-quits-elon-musks-x-says-its-become-vast-worldwide-sewer/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/paris-mayor-hidalgo-quits-elon-musks-x-says-its-become-vast-worldwide-sewer/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-11-27T12:42:15+00:00

'This platform and its owner act deliberately to exacerbate tensions and conflicts,' Anne Hidalgo says.

## China has changed since David Cameron’s ‘golden age,’ Rishi Sunak says
 - [https://www.politico.eu/article/china-has-changed-since-david-camerons-golden-age-rishi-sunak-says/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/china-has-changed-since-david-camerons-golden-age-rishi-sunak-says/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-11-27T12:42:03+00:00

The former PM’s appointment as foreign secretary has led to speculation of a thawing of U.K.-China relations.

## Elon Musk row: UK’s Rishi Sunak says antisemitism ‘wrong in all its forms’
 - [https://www.politico.eu/article/elon-musk-row-uk-rishi-sunak-says-antisemitism-wrong-in-all-forms/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/elon-musk-row-uk-rishi-sunak-says-antisemitism-wrong-in-all-forms/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-11-27T11:55:46+00:00

British PM distances himself from tech billionaire's controversial social media post.

## Geert Wilders’ coalition scout resigns over fraud scandal
 - [https://www.politico.eu/article/geert-wilders-coalition-scout-gom-van-strien-resign-fraud-scandal/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/geert-wilders-coalition-scout-gom-van-strien-resign-fraud-scandal/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-11-27T11:29:04+00:00

Gom van Strien, who was tasked with identifying potential coalition partners, was accused of misdeeds by his former employer.

## How to get tech right in Europe?
 - [https://www.politico.eu/sponsored-content/how-to-get-tech-right-in-europe/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/sponsored-content/how-to-get-tech-right-in-europe/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-11-27T08:00:00+00:00

A European strategy for EU tech to nurture and support its valuable assets — tech companies.

## Enquête sur l’Expo 2030 : rien ne vous sera caviardé !
 - [https://www.politico.eu/article/enquete-sur-lexpo-2030-rien-ne-vous-sera-caviarde/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/enquete-sur-lexpo-2030-rien-ne-vous-sera-caviarde/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-11-27T06:30:00+00:00

Notre newsletter quotidienne sur les enjeux de lobbying et de transparence en France. Par ALEXANDRE LÉCHENET Avec AURORE GORIUS, GIORGIO LEALI et PAUL DE VILLEPIN Infos, tuyaux et mini-drames à partager ? Ecrivez à Océane Herrero, Aurore Gorius, Alexandre Léchenet et Paul de Villepin | Voir dans votre navigateur LE MENU DU JOUR — Budget […]

## Q&A: Ending HIV in the EU
 - [https://www.politico.eu/sponsored-content/qa-ending-hiv-in-the-eu/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/sponsored-content/qa-ending-hiv-in-the-eu/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-11-27T03:21:00+00:00

Europe could be the first region worldwide to reach the UN’s goals to end AIDS. What’s holding us back?

## A football star, caviar and a water show: Inside Saudi Arabia’s campaign to host the 2030 Expo
 - [https://www.politico.eu/article/football-star-caviar-and-water-shows-inside-saudi-arabias-campaign-to-host-the-2030-expo/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/football-star-caviar-and-water-shows-inside-saudi-arabias-campaign-to-host-the-2030-expo/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-11-27T03:00:00+00:00

Crown Prince Mohammed bin Salman has turned the bid into a campaign to showcase the OPEC kingpin's attempt to rebrand.

## Germany chokes on its own austerity medicine
 - [https://www.politico.eu/article/germany-debt-austerity-climate-olaf-scholz-christian-lindner/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/germany-debt-austerity-climate-olaf-scholz-christian-lindner/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-11-27T03:00:00+00:00

Berlin’s make-believe debt crisis gives southern Europe a healthy dose of schadenfreude.

## Israel’s trauma was compounded by talk of an existential threat
 - [https://www.politico.eu/article/israels-trauma-was-compounded-by-talk-of-an-existential-threat/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/israels-trauma-was-compounded-by-talk-of-an-existential-threat/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-11-27T03:00:00+00:00

Hamas gunmen say their leaders ramped up indoctrination with religious leaders lecturing them to inflict maximum pain and suffering on the Jews they encountered.

## Stalemate best describes the state of war in Ukraine
 - [https://www.politico.eu/article/stalemate-best-describes-the-state-of-war-in-ukraine/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/stalemate-best-describes-the-state-of-war-in-ukraine/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-11-27T03:00:00+00:00

By providing Kyiv with tangible security guarantees, Moscow would be made to understand it will never determine Ukraine’s future.

