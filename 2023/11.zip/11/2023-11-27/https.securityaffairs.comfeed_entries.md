# Source:Security Affairs, URL:https://securityaffairs.com/feed, language:en-US

## Ukraine’s intelligence service hacked Russia’s Federal Air Transport Agency, Rosaviatsia
 - [https://securityaffairs.com/154839/cyber-warfare-2/ukraine-hacked-russia-rosaviatsia.html](https://securityaffairs.com/154839/cyber-warfare-2/ukraine-hacked-russia-rosaviatsia.html)
 - RSS feed: https://securityaffairs.com/feed
 - date published: 2023-11-27T19:29:54+00:00

Ukraine&#8217;s intelligence service announced the hack of the Russian Federal Air Transport Agency, &#8216;Rosaviatsia.&#8217; Ukraine&#8217;s intelligence service announced they have hacked Russia&#8217;s Federal Air Transport Agency, &#8216;Rosaviatsia.&#8217; The attack is the result of a complex special cyber operation. &#8220;The Defence Intelligence of Ukraine informs that as a result of a successful complex special operation in [&#8230;]

## Iranian hacker group Cyber Av3ngers hacked the Municipal Water Authority of Aliquippa in Pennsylvania
 - [https://securityaffairs.com/154818/hacktivism/cyber-av3ngers-hacked-municipal-water-authority-of-aliquippa.html](https://securityaffairs.com/154818/hacktivism/cyber-av3ngers-hacked-municipal-water-authority-of-aliquippa.html)
 - RSS feed: https://securityaffairs.com/feed
 - date published: 2023-11-27T15:12:03+00:00

Threat actors breached the Municipal Water Authority of Aliquippa in Pennsylvania and took control of a booster station. During the weekend, Iranian threat actors hacked the Municipal Water Authority of Aliquippa (MWAA) and took control of one of their booster stations. The Authority pointed out that the attack did not impact the operations at the [&#8230;]

## The hack of MSP provider CTS potentially impacted hundreds of UK law firms
 - [https://securityaffairs.com/154807/hacking/cts-suffered-cyber-attack.html](https://securityaffairs.com/154807/hacking/cts-suffered-cyber-attack.html)
 - RSS feed: https://securityaffairs.com/feed
 - date published: 2023-11-27T06:36:08+00:00

The cyber attack that hit the managed service provider (MSP) CTS potentially impacted hundreds in the United Kingdom. CTS is a trusted provider of IT services to the legal sector in the UK. The company announced that it is investigating a cyber attack that caused a service outage. The incident impacted a portion of the [&#8230;]

