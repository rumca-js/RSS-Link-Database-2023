# Source:Nineteenth century videos. Back to life., URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC8abMPJmTPmsaSc7j-lwIhQ, language:en-US

## [4k, 60fps](1959) The Total Electric Home. The Home of the future.
 - [https://www.youtube.com/watch?v=IRrMLaiiAGY](https://www.youtube.com/watch?v=IRrMLaiiAGY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC8abMPJmTPmsaSc7j-lwIhQ
 - date published: 2023-11-27T20:21:24+00:00

Join as a member to support this channel:
https://www.youtube.com/channel/UC8abMPJmTPmsaSc7j-lwIhQ/join

Back in the late 1950s, Westinghouse offered promotional material for sixteen different all-electric home floor plans designed by five different architects, which sold for $10 each and spanned 900-2000 square feet. The architects were also contracted to design model homes in different regions of the country. The Westinghouse Total Electric Home officially opened for public tours on Sunday, April 24, 1960. 
Measuring 1,604-square-feet, the house boasted two courtyard areas, called “Outdoor Living Centers,” three bedrooms, a living room, entertainment center and food preparation center located in the middle of a large open area. Visitors were asked to note the built-in appliances, as Westinghouse wanted them to think of it as a home manager who has a great number of electrical assistants, rather than using traditional methods.

