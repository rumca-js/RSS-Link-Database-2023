# Source:KnowledgeHusk, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw, language:en-US

## People in the 80s Making Fun of Predictions From The 60s
 - [https://www.youtube.com/watch?v=L-B6zeAKAEQ](https://www.youtube.com/watch?v=L-B6zeAKAEQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw
 - date published: 2023-11-27T20:50:00+00:00

Go to https://ground.news/Husk to see all sides of every story. Subscribe for less than $1/month or take advantage of their biggest sale of the year to get 40% off unlimited access. Sale ends November 30. 

I like seeing people in the past try and make predictions about the future. I also like seeing people in the past make fun of people who, in the past, tried making predictions before them, before proceeding to make predictions about the future, expecting that eventually people will make of them for……you get the point.

Back in 1965 BBC’s Tomorrow’s World made predictions for the future, in the 80s the same show revisited the topic, and now today, many years later, I will revisit both of their predictions.

Part of me was tempted to just make my own guesses for 2043, but they mostly included ‘smart cats’ and ‘smart hats’ and ‘smart rats’.

Consumer electronics, predictions, 1980s, 1960s, technology, futurism

