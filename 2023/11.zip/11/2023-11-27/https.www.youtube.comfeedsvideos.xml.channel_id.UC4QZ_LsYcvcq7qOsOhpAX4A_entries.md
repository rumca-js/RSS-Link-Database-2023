# Source:Coldfusion, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A, language:en-US

## The Entire OpenAI Chaos Explained
 - [https://www.youtube.com/watch?v=_yjc8AulnDk](https://www.youtube.com/watch?v=_yjc8AulnDk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A
 - date published: 2023-11-27T15:46:27+00:00

Go to https://incogni.com/coldfusion 60% off.

Biography: https://www.youtube.com/watch?v=GKaVb3jc2No

Last week featured one of the most bizarre shakeups in the tech landscape. OpenAI fired their CEO Sam Altman, before taking him back days later. What followed was a flurry of rumours as to what happened, the most interesting of which is a human level (AGI) project called Q*. What happened? In this episode we take a look.

--- About ColdFusion ---
ColdFusion is an Australian based online media company independently run by Dagogo Altraide since 2009. Topics cover anything in science, technology, history and business in a calm and relaxed environment. 

» ColdFusion Discord:  https://discord.gg/coldfusion
» Twitter | @ColdFusion_TV
» Instagram | coldfusiontv
» Facebook | https://www.facebook.com/ColdFusioncollective
» Podcast I Co-host: https://www.youtube.com/channel/UC6jKUaNXSnuW52CxexLcOJg

ColdFusion Music Channel: https://www.youtube.com/channel/UCGkpFfEMF0eMJlh9xXj2lMw

ColdFusio

