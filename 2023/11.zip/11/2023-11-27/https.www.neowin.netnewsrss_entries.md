# Source:Neowin, URL:https://www.neowin.net/news/rss/, language:en-us

## Cyber Monday: This may be the last day for deep discounts on Amazon hardware products
 - [https://www.neowin.net/deals/cyber-monday-this-may-be-the-last-day-for-deep-discounts-on-amazon-hardware-products](https://www.neowin.net/deals/cyber-monday-this-may-be-the-last-day-for-deep-discounts-on-amazon-hardware-products)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-11-27T22:52:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/04/1682553635_1383586_medium.jpg" /></div>Amazon still has some all-time or close to all-time low prices on its tech products like Fire TV streaming sticks, Fire tablets, Echo Show smart display and more for Cyber Monday 2023. <a href="https://www.neowin.net/deals/cyber-monday-this-may-be-the-last-day-for-deep-discounts-on-amazon-hardware-products">Read more...</a>

## Microsoft is working to add GPT-4 Turbo to Bing/Copilot; will try to boost character limits
 - [https://www.neowin.net/news/microsoft-is-working-to-add-gpt-4-turbo-to-bingcopilot-will-try-to-boost-character-limits](https://www.neowin.net/news/microsoft-is-working-to-add-gpt-4-turbo-to-bingcopilot-will-try-to-boost-character-limits)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-11-27T21:34:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/04/1681134786_1678474108_microsoft-bing-chat-1_medium.jpg" /></div>Microsoft is currently trying to add in the more powerful GPT-4 Turbo to its Copilot (formerly Bing Chat) AI services. It may also finally increase the 5,000-character limit for the chatbot. <a href="https://www.neowin.net/news/microsoft-is-working-to-add-gpt-4-turbo-to-bingcopilot-will-try-to-boost-character-limits">Read more...</a>

## The Microsoft 365 extension for Edge and Chrome browsers will be retired January 15, 2024
 - [https://www.neowin.net/news/the-microsoft-365-extension-for-edge-and-chrome-browsers-will-be-retired-january-15-2024](https://www.neowin.net/news/the-microsoft-365-extension-for-edge-and-chrome-browsers-will-be-retired-january-15-2024)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-11-27T20:28:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/11/1701115674_1693418650_microsoft-365-app_medium.jpg" /></div>Microsoft has announced that it will end support for the Microsoft 365 browser extensions for both its own Edge browser and Google&#039;s Chrome on January 15, 2024. There&#039;s no word on why this will happen <a href="https://www.neowin.net/news/the-microsoft-365-extension-for-edge-and-chrome-browsers-will-be-retired-january-15-2024">Read more...</a>

## Cyber Monday: Microsoft Office 2021 Professional for Windows now 72% off
 - [https://www.neowin.net/deals/cyber-monday-microsoft-office-2021-professional-for-windows-now-72-off](https://www.neowin.net/deals/cyber-monday-microsoft-office-2021-professional-for-windows-now-72-off)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-11-27T20:00:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/04/1681987131_1655982433_office-2021-win_medium.jpg" /></div>Price Dropped again for you! Word, Excel, Teams, PowerPoint, Outlook, and OneNote! Get all these essential Microsoft apps for your Windows PC for a low one-time cost; classic apps that don&#039;t expire. <a href="https://www.neowin.net/deals/cyber-monday-microsoft-office-2021-professional-for-windows-now-72-off">Read more...</a>

## Cities: Skylines II editor tools to go through early access, releasing in early 2024
 - [https://www.neowin.net/news/cities-skylines-ii-editor-tools-to-go-through-early-access-releasing-in-early-2024](https://www.neowin.net/news/cities-skylines-ii-editor-tools-to-go-through-early-access-releasing-in-early-2024)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-11-27T18:58:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/07/1690210886_26_water_infoview_medium.jpg" /></div>Colossal Order has revealed an early access program for Cities: Skylines II&#039;s upcoming editor for assets and maps. A major update is also planned for December containing performance boosts and fixes. <a href="https://www.neowin.net/news/cities-skylines-ii-editor-tools-to-go-through-early-access-releasing-in-early-2024">Read more...</a>

## Destiny 2: The Final Shape is offically delayed by Bungie until June 4, 2024
 - [https://www.neowin.net/news/destiny-2-the-final-shape-is-offically-delayed-by-bungie-until-june-4-2024](https://www.neowin.net/news/destiny-2-the-final-shape-is-offically-delayed-by-bungie-until-june-4-2024)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-11-27T18:42:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/08/1692730348_destiny-2-the-final-shape-pre-orders-1_medium.jpg" /></div>After weeks of rumors, Bungie has officially announced a release date delay in the next Destiny 2 expansion pack, The Final Shape. The date was pushed back from February 27 to June 4, 2024. <a href="https://www.neowin.net/news/destiny-2-the-final-shape-is-offically-delayed-by-bungie-until-june-4-2024">Read more...</a>

## Cyber Monday: Microsoft Office Home & Business 2021 for Mac now 77% off
 - [https://www.neowin.net/deals/cyber-monday-microsoft-office-home--business-2021-for-mac-now-77-off](https://www.neowin.net/deals/cyber-monday-microsoft-office-home--business-2021-for-mac-now-77-off)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-11-27T18:00:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2022/02/1643710891_764161_medium.jpg" /></div>Word, Excel, PowerPoint, Outlook, Teams, and OneNote! Get all these essential Microsoft apps for your Mac with this one-time purchase, no faffing about with online subscriptions, just classic apps. <a href="https://www.neowin.net/deals/cyber-monday-microsoft-office-home--business-2021-for-mac-now-77-off">Read more...</a>

## Microsoft announces retirement dates for Azure ACS and SharePoint Add-In services
 - [https://www.neowin.net/news/microsoft-announces-retirement-dates-for-azure-acs-and-sharepoint-add-in-services](https://www.neowin.net/news/microsoft-announces-retirement-dates-for-azure-acs-and-sharepoint-add-in-services)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-11-27T17:38:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2019/03/1553429078_sharepoint4_medium.jpg" /></div>Microsoft has announced that Azure ACS and SharePoint Add-In services will stop working for new tenants on November 1, 2024, and will be shut down for existing tenants on April 2, 2026. <a href="https://www.neowin.net/news/microsoft-announces-retirement-dates-for-azure-acs-and-sharepoint-add-in-services">Read more...</a>

## Download Teach Yourself VISUALLY Excel 365 ($18 Value, FREE till 11/30)
 - [https://www.neowin.net/sponsored/download-teach-yourself-visually-excel-365-18-value-free-till-1130](https://www.neowin.net/sponsored/download-teach-yourself-visually-excel-365-18-value-free-till-1130)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-11-27T17:00:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/11/1701088714_tyv_excel_neowin_medium.jpg" /></div>A can&#039;t-miss handbook perfect for anyone looking for straightforward and easy-to-follow tutorials on basic and advanced Excel techniques, now free to download until the end of November. <a href="https://www.neowin.net/sponsored/download-teach-yourself-visually-excel-365-18-value-free-till-1130">Read more...</a>

## Cyber Monday: Get the Xbox Series X game console for $399.99 before this deal disappears
 - [https://www.neowin.net/deals/cyber-monday-get-the-xbox-series-x-game-console-for-39999-before-this-deal-disappears](https://www.neowin.net/deals/cyber-monday-get-the-xbox-series-x-game-console-for-39999-before-this-deal-disappears)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-11-27T16:49:39+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2020/10/1603833026_x3_medium.jpg" /></div>You can get Microsoft&#039;s  Xbox Series X, which normally costs $499.99, for $100 less at just $399.99 at Amazon for a limited time if you click on the $49.01 digital coupon on the site. <a href="https://www.neowin.net/deals/cyber-monday-get-the-xbox-series-x-game-console-for-39999-before-this-deal-disappears">Read more...</a>

## Microsoft reveals new features for its Teams Updates app including exporting data to Excel
 - [https://www.neowin.net/news/microsoft-reveals-new-features-for-its-teams-updates-app-including-exporting-data-to-excel](https://www.neowin.net/news/microsoft-reveals-new-features-for-its-teams-updates-app-including-exporting-data-to-excel)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-11-27T16:30:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/11/1701101322_yuxiang_zhou_2-1701074336724_medium.jpg" /></div>Microsoft has revealed some new features it has added to the Updates app in Teams. They include a way to export received submissions data to an Excel file, and new collaboration features. <a href="https://www.neowin.net/news/microsoft-reveals-new-features-for-its-teams-updates-app-including-exporting-data-to-excel">Read more...</a>

## Amazon is retrofitting its Fire TV Cube as a thin client for business cloud users
 - [https://www.neowin.net/news/amazon-is-retrofitting-its-fire-tv-cube-as-a-thin-client-for-business-cloud-users](https://www.neowin.net/news/amazon-is-retrofitting-its-fire-tv-cube-as-a-thin-client-for-business-cloud-users)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-11-27T15:32:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/11/1701097590_tc_setup_3_medium.jpg" /></div>Amazon has announced a new WorkSpaces Thin Client for its AWS End User Computing services, and it uses the hardware that&#039;s already included in its Fire TV Cube streaming TV set-top box.  <a href="https://www.neowin.net/news/amazon-is-retrofitting-its-fire-tv-cube-as-a-thin-client-for-business-cloud-users">Read more...</a>

## TikTok owner ByteDance will likely lay off hundreds of workers in its gaming division
 - [https://www.neowin.net/news/tiktok-owner-bytedance-will-likely-lay-off-hundreds-of-workers-in-its-gaming-division](https://www.neowin.net/news/tiktok-owner-bytedance-will-likely-lay-off-hundreds-of-workers-in-its-gaming-division)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-11-27T14:58:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2022/08/1660063549_bytedance_medium.jpg" /></div>ByteDance, the parent company of TikTok, has confirmed it will &quot;restructure our gaming business&quot; and could lay off hundreds of its workers in that division as a result of those changes. <a href="https://www.neowin.net/news/tiktok-owner-bytedance-will-likely-lay-off-hundreds-of-workers-in-its-gaming-division">Read more...</a>

## Ubisoft is giving away Assassin's Creed Syndicate for free on PC
 - [https://www.neowin.net/news/ubisoft-is-giving-away-assassins-creed-syndicate-for-free-on-pc](https://www.neowin.net/news/ubisoft-is-giving-away-assassins-creed-syndicate-for-free-on-pc)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-11-27T14:42:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/11/1701095656_ss_851199df5f2f2d44b4a8125e854af27d6204c1b6.1920x1080_medium.jpg" /></div>The ninth mainline entry in the Assassin&#039;s Creed franchise, Syndicate, is currently free to claim on Ubisoft&#039;s Connect platform. The Victorian era London-set title originally released in 2015. <a href="https://www.neowin.net/news/ubisoft-is-giving-away-assassins-creed-syndicate-for-free-on-pc">Read more...</a>

## A number of Google Drive users have reported their files have mysteriously disappeared
 - [https://www.neowin.net/news/a-number-of-google-drive-users-have-reported-their-files-have-mysteriously-disappeared](https://www.neowin.net/news/a-number-of-google-drive-users-have-reported-their-files-have-mysteriously-disappeared)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-11-27T14:10:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2020/12/1607558845_google_drive_new_1_medium.jpg" /></div>Over the past few days, a number of Google Drive users have reported that their files have disappeared from their accounts, some of which have been stored on those accounts for several months. <a href="https://www.neowin.net/news/a-number-of-google-drive-users-have-reported-their-files-have-mysteriously-disappeared">Read more...</a>

## Get these Cyber Monday deals on SSDs, Microsoft audio docks, and more before they go away
 - [https://www.neowin.net/deals/get-these-cyber-monday-deals-on-ssds-microsoft-audio-docks-and-more-before-they-go-away](https://www.neowin.net/deals/get-these-cyber-monday-deals-on-ssds-microsoft-audio-docks-and-more-before-they-go-away)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-11-27T13:36:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2016/11/1479824481_cyber-monday_medium.jpg" /></div>It&#039;s Cyber Monday 2023, which means that all the deep all-time discounts we have tracked on Amazon on items like internal SSDs, audio docks and many more items could go away after today is over. <a href="https://www.neowin.net/deals/get-these-cyber-monday-deals-on-ssds-microsoft-audio-docks-and-more-before-they-go-away">Read more...</a>

## RCS chats on Google Messages now support Ultra HDR images
 - [https://www.neowin.net/news/rcs-chats-on-google-messages-now-support-ultra-hdr-images](https://www.neowin.net/news/rcs-chats-on-google-messages-now-support-ultra-hdr-images)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-11-27T12:24:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2020/12/1607703117_google_messages_4_medium.jpg" /></div>Google has updated Messages recently with the ability to share Ultra HDR images within RCS chats, however it has only just been spotted and reported on having rolled out to Pixel 8 users. <a href="https://www.neowin.net/news/rcs-chats-on-google-messages-now-support-ultra-hdr-images">Read more...</a>

## OnePlus 12 to debut in China on 5th December with Snapdragon 8 Gen 3 processor
 - [https://www.neowin.net/news/oneplus-12-to-debut-in-china-on-5th-december-with-snapdragon-8-gen-3-processor](https://www.neowin.net/news/oneplus-12-to-debut-in-china-on-5th-december-with-snapdragon-8-gen-3-processor)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-11-27T11:42:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/11/1701076644_ezgif-3-6d3df5299a_medium.jpg" /></div>OnePlus is to launch its upcoming OnePlus 12 phone in China next week on 5th December as it approaches the brand&#039;s 10 year anniversary. The renders revealed look very similar to the current OnePlus 11 <a href="https://www.neowin.net/news/oneplus-12-to-debut-in-china-on-5th-december-with-snapdragon-8-gen-3-processor">Read more...</a>

