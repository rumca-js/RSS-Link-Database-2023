# Source:The Wall Street - Tech, URL:https://feeds.a.dj.com/rss/RSSWSJD.xml, language:en-US

## Instagram's Algorithm Delivers Toxic Video Mix to Adults Who Follow Children
 - [https://www.wsj.com/articles/meta-instagram-video-algorithm-children-adult-sexual-content-72874155?mod=rss_Technology](https://www.wsj.com/articles/meta-instagram-video-algorithm-children-adult-sexual-content-72874155?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-11-27T10:30:00+00:00

Content served to WSJ test accounts included risqué footage of kids, overtly sexual adult videos and ads from major brands.

## TikTok's Owner Wanted to Create a Hit Videogame. It Failed.
 - [https://www.wsj.com/articles/tiktoks-owner-wanted-to-create-a-hit-videogame-it-failed-0eccb165?mod=rss_Technology](https://www.wsj.com/articles/tiktoks-owner-wanted-to-create-a-hit-videogame-it-failed-0eccb165?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-11-27T10:17:00+00:00

ByteDance is to lay off hundreds of staff at its videogame unit, Nuverse, as it pulls back on another big bet on expansion.

## Yelp, Strava and Duolingo Are…Dating Apps?
 - [https://www.wsj.com/articles/unexpected-dating-apps-strava-duolingo-0f64ec04?mod=rss_Technology](https://www.wsj.com/articles/unexpected-dating-apps-strava-duolingo-0f64ec04?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-11-27T02:00:00+00:00

Singles are meeting people in unusual places online.

