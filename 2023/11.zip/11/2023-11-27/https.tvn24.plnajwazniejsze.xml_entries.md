# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## PiS obsadza nowe struktury. 17 szefów okręgów
 - [https://tvn24.pl/polska/pis-obsadza-nowe-struktury-szefami-w-duzej-mierze-politycy-mlodszego-pokolenia-7457750?source=rss](https://tvn24.pl/polska/pis-obsadza-nowe-struktury-szefami-w-duzej-mierze-politycy-mlodszego-pokolenia-7457750?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T21:45:24+00:00

<img alt="PiS obsadza nowe struktury. 17 szefów okręgów " src="https://tvn24.pl/najnowsze/cdn-zdjecie-gukqnt-sejm-z-pap-7447954/alternates/LANDSCAPE_1280" />
    Partia nie zdecydowała jeszcze, kto pokieruje strukturami opolskimi.

## Ostre protesty kibiców po porażce kadry. Prezes podał się do dymisji
 - [https://eurosport.tvn24.pl/pilka-nozna/borislaw-michajlow-zrezygnowal-z-funkcji-prezesa-bulgarskiej-federacji-pilkarskiej.-protesty-kibicow_sto9898750/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/borislaw-michajlow-zrezygnowal-z-funkcji-prezesa-bulgarskiej-federacji-pilkarskiej.-protesty-kibicow_sto9898750/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T21:27:54+00:00

<img alt="Ostre protesty kibiców po porażce kadry. Prezes podał się do dymisji" src="https://tvn24.pl/najnowsze/cdn-zdjecie-eo4i11-starcia-kibicow-z-policja-przy-okazji-meczu-bulgaria-wegry-7457795/alternates/LANDSCAPE_1280" />
    Trzęsienie ziemi w bułgarskiej piłce.

## Piątek powoli rozkręca się w Turcji. Trzeci gol w sezonie
 - [https://eurosport.tvn24.pl/pilka-nozna/turecka-super-lig/2023-2024/krzysztof-piatek-strzela-w-turcji_sto9898916/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/turecka-super-lig/2023-2024/krzysztof-piatek-strzela-w-turcji_sto9898916/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T21:16:12+00:00

<img alt="Piątek powoli rozkręca się w Turcji. Trzeci gol w sezonie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-se8efy-krzysztof-piatek-powoli-wraca-do-strzeleckiej-formy-7457788/alternates/LANDSCAPE_1280" />
    Jego Basaksehir pewnie pokonał w 13. kolejce ligi tureckiej Pendikspor.

## Sagan wygrał na koniec kariery na szosie
 - [https://eurosport.tvn24.pl/kolarstwo/peter-sagan-zakonczyl-kariere-na-szosie.-gdzie-startowal-co-powiedzial-ostatni-wyscig-kolarstwo_sto9898367/story.shtml?source=rss](https://eurosport.tvn24.pl/kolarstwo/peter-sagan-zakonczyl-kariere-na-szosie.-gdzie-startowal-co-powiedzial-ostatni-wyscig-kolarstwo_sto9898367/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T20:59:36+00:00

<img alt="Sagan wygrał na koniec kariery na szosie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rfomx0-sagan-se-despide-a-lo-grande-del-ciclismo-en-ruta-tras-ganar-a-pogacar-en-monaco-7457766/alternates/LANDSCAPE_1280" />
    "To była świetna zabawa".

## "Na Podhalu ten temat jest zupełnie niewidzialny"
 - [https://fakty.tvn24.pl/zobacz-fakty/przemoc-domowa-goralki-walcza-o-przyjecie-uchwaly-antyprzemocowej-st7457691?source=rss](https://fakty.tvn24.pl/zobacz-fakty/przemoc-domowa-goralki-walcza-o-przyjecie-uchwaly-antyprzemocowej-st7457691?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T20:14:31+00:00

<img alt="" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-cy12ow-kijowska-7457690/alternates/LANDSCAPE_1280" />
    Góralki walczą o przyjęcie uchwały antyprzemocowej.

## On też był małym bohaterem weekendu w Ruce. Syn legendy powtórzył słynny gest
 - [https://eurosport.tvn24.pl/skoki-narciarskie/ruka/2023-2024/janne-ahonen-zostal-pozdrowiony-przez-syna-mico.-jaki-gest-wykonal-skoczek_sto9898621/story.shtml?source=rss](https://eurosport.tvn24.pl/skoki-narciarskie/ruka/2023-2024/janne-ahonen-zostal-pozdrowiony-przez-syna-mico.-jaki-gest-wykonal-skoczek_sto9898621/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T20:10:58+00:00

<img alt="On też był małym bohaterem weekendu w Ruce. Syn legendy powtórzył słynny gest" src="https://tvn24.pl/najnowsze/cdn-zdjecie-f9a3vo-janne-i-mico-ahonen-w-2013-roku-7457712/alternates/LANDSCAPE_1280" />
    Jego ojciec, jeden z najlepszych skoczków w historii, 20 lat temu zrobił to samo.

## Joński: Będziemy jutro u nowej minister kultury. Nie może tylko i wyłącznie mówić, że ona nie wie
 - [https://tvn24.pl/polska/dariusz-jonski-zapowiada-wizyte-u-nowej-minister-kultury-w-sprawie-zmian-w-mediach-rzadowych-7457677?source=rss](https://tvn24.pl/polska/dariusz-jonski-zapowiada-wizyte-u-nowej-minister-kultury-w-sprawie-zmian-w-mediach-rzadowych-7457677?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T20:06:28+00:00

<img alt="Joński: Będziemy jutro u nowej minister kultury. Nie może tylko i wyłącznie mówić, że ona nie wie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-tqdo86-27-2000-kropka-gosc-0027-7457646/alternates/LANDSCAPE_1280" />
    Joanna Mucha i Dariusz Joński w "Kropce nad i".

## Gdzie leczyły rzesze medyków wyedukowanych na "Podręczniku bosonogiego lekarza"?
 - [https://tvn24.pl/toteraz/milionerzy-tvn-gdzie-leczyly-rzesze-medykow-wyedukowanych-na-podreczniku-bosonogiego-lekarza-pytanie-i-odpowiedz-7457170?source=rss](https://tvn24.pl/toteraz/milionerzy-tvn-gdzie-leczyly-rzesze-medykow-wyedukowanych-na-podreczniku-bosonogiego-lekarza-pytanie-i-odpowiedz-7457170?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T20:05:00+00:00

<img alt="Gdzie leczyły rzesze medyków wyedukowanych na " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ugin2m-pytanie-z-milionerow-o-medykow-wyedukowanych-na-podreczniku-bosonogiego-lekarza-za-40-tysiecy-zlotych-7457124/alternates/LANDSCAPE_1280" />
    W Rosji, w Chinach, w Grecji czy we Francji - gdzie leczyły rzesze medyków wyedukowanych na jednej tylko książce, "Podręczniku bosonogiego lekarza"?  Na to pytanie odpowiadał Tomasz Wojsa z Ostrowca Świętokrzyskiego.

## Niedziele handlowe w grudniu. Propozycja PiS-u przepadła
 - [https://tvn24.pl/biznes/z-kraju/handlowe-niedziele-w-grudniu-kiedy-beda-otwarte-sklepy-st7457679?source=rss](https://tvn24.pl/biznes/z-kraju/handlowe-niedziele-w-grudniu-kiedy-beda-otwarte-sklepy-st7457679?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T20:00:26+00:00

<img alt="Niedziele handlowe w grudniu. Propozycja PiS-u przepadła" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7xd3vj-handel-inflacja-zakupy-galeria-handlowa-6305047/alternates/LANDSCAPE_1280" />
    Szczegóły.

## Lider miał problemy w Radomiu
 - [https://eurosport.tvn24.pl/pilka-nozna/pko-bp-ekstraklasa/2023-2024/radomiak-radom-slask-wroclaw-wynik-i-relacja_sto9898794/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/pko-bp-ekstraklasa/2023-2024/radomiak-radom-slask-wroclaw-wynik-i-relacja_sto9898794/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T19:59:55+00:00

<img alt="Lider miał problemy w Radomiu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-66qtxf-erik-exposito-cieszy-sie-z-kolegami-z-gola-7457701/alternates/LANDSCAPE_1280" />
    Niezawodny strzelec zapewnił wygraną.

## Ginekolog skazany za gwałt na pacjentce po wyroku prowadził zajęcia na uczelni i pracował w szpitalu
 - [https://fakty.tvn24.pl/zobacz-fakty/ginekolog-skazany-za-gwalt-na-pacjentce-po-wyroku-prowadzil-zajecia-na-uczelni-i-pracowal-w-szpitalu-st7457662?source=rss](https://fakty.tvn24.pl/zobacz-fakty/ginekolog-skazany-za-gwalt-na-pacjentce-po-wyroku-prowadzil-zajecia-na-uczelni-i-pracowal-w-szpitalu-st7457662?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T19:38:44+00:00

<img alt="Ginekolog skazany za gwałt na pacjentce po wyroku prowadził zajęcia na uczelni i pracował w szpitalu" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-ugpv0u-gorniak-7457663/alternates/LANDSCAPE_1280" />
    Placówki twierdzą, że nie wiedziały o zarzutach i wyroku.

## "Drogie dwa tygodnie obciachu"
 - [https://tvn24.pl/polska/prezydent-zaprzysiagl-rzad-mateusza-morawieckiego-ktory-nie-ma-wiekszosci-joanna-scheuring-wielgus-i-krzysztof-kwiatkowski-komentuja-7457594?source=rss](https://tvn24.pl/polska/prezydent-zaprzysiagl-rzad-mateusza-morawieckiego-ktory-nie-ma-wiekszosci-joanna-scheuring-wielgus-i-krzysztof-kwiatkowski-komentuja-7457594?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T19:36:31+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-me2h97-fpf-7457607/alternates/LANDSCAPE_1280" />
    W "Faktach po Faktach" o ministrach rządu, który nie ma większości.

## Autobus z dziećmi utknął w lesie
 - [https://tvn24.pl/tvnwarszawa/najnowsze/katy-wegierskie-autobus-z-dziecmi-utknal-w-lesie-wybierali-sie-na-slask-pojechali-w-przeciwnym-kierunku-st7457613?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/katy-wegierskie-autobus-z-dziecmi-utknal-w-lesie-wybierali-sie-na-slask-pojechali-w-przeciwnym-kierunku-st7457613?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T19:31:44+00:00

<img alt="Autobus z dziećmi utknął w lesie " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-jhuvkr-autokar-zakopal-sie-w-katach-wegierskich-7457650/alternates/LANDSCAPE_1280" />
    Wybierali się na Śląsk, pojechali w przeciwnym kierunku.

## Wybierali się na Śląsk, pojechali w przeciwnym kierunku. Autobus z dziećmi utknął w lesie
 - [https://tvn24.pl/tvnwarszawa/najnowsze/katy-wegierskie-autobus-z-dziecmi-zakopal-sie-w-lesie-mieli-jechac-na-slask-st7457613?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/katy-wegierskie-autobus-z-dziecmi-zakopal-sie-w-lesie-mieli-jechac-na-slask-st7457613?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T19:31:44+00:00

<img alt="Wybierali się na Śląsk, pojechali w przeciwnym kierunku. Autobus z dziećmi utknął w lesie " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-jhuvkr-autokar-zakopal-sie-w-katach-wegierskich-7457650/alternates/LANDSCAPE_1280" />
    W Kątach Węgierskich, w powiecie legionowskim.

## "Mnóstwo osób pytało: gdzie jest Rzecznik Praw Dziecka?"
 - [https://tvn24.pl/go/programy,7/czarno-na-bialym-odcinki,11367/odcinek-2392,S00E2392,1034756?source=rss](https://tvn24.pl/go/programy,7/czarno-na-bialym-odcinki,11367/odcinek-2392,S00E2392,1034756?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T19:28:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ckmw0w-mikolaj-pawlak-7064030/alternates/LANDSCAPE_1280" />
    Reportaż Artura Zakrzewskiego.

## To oni zgaszą światło w ministerstwach
 - [https://tvn24.pl/biznes/z-kraju/rzad-mateusza-morawieckiego-zaprzysiezenie-kto-odchodzi-z-rzadu-st7457491?source=rss](https://tvn24.pl/biznes/z-kraju/rzad-mateusza-morawieckiego-zaprzysiezenie-kto-odchodzi-z-rzadu-st7457491?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T19:24:06+00:00

<img alt="To oni zgaszą światło w ministerstwach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7yjvpi-27-1600-palac-0009-7457217/alternates/LANDSCAPE_1280" />
    Pożegnania w czołowych resortach.

## Jego nazwisko pojawiło się przy okazji Willi plus. Został ministrem edukacji
 - [https://tvn24.pl/polska/krzysztof-szczucki-kim-jest-byly-szef-rcl-nowym-ministrem-edukacji-7457557?source=rss](https://tvn24.pl/polska/krzysztof-szczucki-kim-jest-byly-szef-rcl-nowym-ministrem-edukacji-7457557?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T19:15:35+00:00

<img alt="Jego nazwisko pojawiło się przy okazji Willi plus. Został ministrem edukacji " src="https://tvn24.pl/najnowsze/cdn-zdjecie-vyfife-krzysztof-szczucki-powolany-na-ministra-edukacji-i-nauki-7457595/alternates/LANDSCAPE_1280" />
    Do niedawna był szefem Rządowego Centrum Legislacji.

## "Przed nową panią rzecznik bardzo trudna praca, bo trzeba przywrócić wagę temu urzędowi"
 - [https://fakty.tvn24.pl/zobacz-fakty/monika-horna-cieslak-jedyna-kandydatka-na-rzecznika-praw-dziecka-otrzymala-poparcie-sejmowych-komisji-st7457392?source=rss](https://fakty.tvn24.pl/zobacz-fakty/monika-horna-cieslak-jedyna-kandydatka-na-rzecznika-praw-dziecka-otrzymala-poparcie-sejmowych-komisji-st7457392?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T18:59:14+00:00

<img alt="" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-39hfe3-otreba-7457619/alternates/LANDSCAPE_1280" />
    Monika Horna-Cieślak jest jedyną kandydatką na Rzecznika Praw Dziecka.

## Trzy kobiety potrącone na przejściu dla pieszych
 - [https://tvn24.pl/polska/wielun-wypadek-trzy-kobiety-potracone-na-przejsciu-dla-pieszych-7457569?source=rss](https://tvn24.pl/polska/wielun-wypadek-trzy-kobiety-potracone-na-przejsciu-dla-pieszych-7457569?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T18:37:26+00:00

<img alt="Trzy kobiety potrącone na przejściu dla pieszych " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ncwk1-wielun-7457597/alternates/LANDSCAPE_1280" />
    W Wieluniu.

## "Człowiek Marka Suskiego" na czele Ministerstwa Finansów
 - [https://tvn24.pl/biznes/najnowsze/nowy-minister-finansow-kim-jest-andrzej-kosztowniak-st7457471?source=rss](https://tvn24.pl/biznes/najnowsze/nowy-minister-finansow-kim-jest-andrzej-kosztowniak-st7457471?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T18:22:49+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3j544b-andrzej-kosztowniak-odbiera-powolanie-na-urzad-ministra-finansow-7457343/alternates/LANDSCAPE_1280" />
    Były prezydent Radomia zastąpi Magdalenę Rzeczkowską.

## Na S7 spalił się wojskowy autobus. Podróżowało nim 34 żołnierzy
 - [https://tvn24.pl/tvnwarszawa/ulice/s7-plonsk-pozar-wojskowego-autobusu-podrozowalo-nim-34-zolnierzy-st7457530?source=rss](https://tvn24.pl/tvnwarszawa/ulice/s7-plonsk-pozar-wojskowego-autobusu-podrozowalo-nim-34-zolnierzy-st7457530?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T18:03:33+00:00

<img alt="Na S7 spalił się wojskowy autobus. Podróżowało nim 34 żołnierzy" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-2ik6fo-pozar-wojskowego-autobusu-na-trasie-s7-7457532/alternates/LANDSCAPE_1280" />
    Pod Płońskiem.

## Dwa dodatkowe dni. Katar informuje o przedłużeniu rozejmu
 - [https://tvn24.pl/swiat/strefa-gazy-rozejm-humanitarny-przedluzony-o-dwa-dni-7457476?source=rss](https://tvn24.pl/swiat/strefa-gazy-rozejm-humanitarny-przedluzony-o-dwa-dni-7457476?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T17:44:33+00:00

<img alt="Dwa dodatkowe dni. Katar informuje o przedłużeniu rozejmu " src="https://tvn24.pl/najnowsze/cdn-zdjecie-cycls5-strefa-gazy-7457468/alternates/LANDSCAPE_1280" />
    W Strefie Gazy.

## Klub ekstraklasy pożegnał trenera
 - [https://eurosport.tvn24.pl/pilka-nozna/pko-bp-ekstraklasa/2023-2024/constantin-galca-nie-jest-juz-trenerem-radomiaka-radom_sto9898746/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/pko-bp-ekstraklasa/2023-2024/constantin-galca-nie-jest-juz-trenerem-radomiaka-radom_sto9898746/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T17:35:49+00:00

<img alt="Klub ekstraklasy pożegnał trenera" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1lac3m-constantin-galca-7457520/alternates/LANDSCAPE_1280" />
    Niespełna półtorej godziny przed meczem.

## Siarczysty mróz i bardzo nietypowy problem biegacza
 - [https://eurosport.tvn24.pl/biegi-narciarskie/ruka/2023-2024/calle-halfvarsson-i-nietypowy-problem-po-biegu-masowym-w-ruce_sto9898649/story.shtml?source=rss](https://eurosport.tvn24.pl/biegi-narciarskie/ruka/2023-2024/calle-halfvarsson-i-nietypowy-problem-po-biegu-masowym-w-ruce_sto9898649/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T17:16:22+00:00

<img alt="Siarczysty mróz i bardzo nietypowy problem biegacza" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pv2myu-calle-halfvarsson-7457489/alternates/LANDSCAPE_1280" />
    "Na szczęście dziecko jest już w drodze".

## Aktorka serialowa nową minister kultury. Kim jest Dominika Chorosińska
 - [https://tvn24.pl/polska/dominika-chorosinska-kim-jest-aktorka-serialowa-powolana-na-ministra-kultury-w-rzadzie-mateusza-morawieckiego-7457295?source=rss](https://tvn24.pl/polska/dominika-chorosinska-kim-jest-aktorka-serialowa-powolana-na-ministra-kultury-w-rzadzie-mateusza-morawieckiego-7457295?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T16:58:54+00:00

<img alt="Aktorka serialowa nową minister kultury. Kim jest Dominika Chorosińska " src="https://tvn24.pl/najnowsze/cdn-zdjecie-x26il8-dominika-chorosinska-7457322/alternates/LANDSCAPE_1280" />
    W Sejmie zasiada od 2019 roku, wcześniej występowała m.in. w filmach i serialach.

## Na trzech komisjach śledczych się nie skończy? "Mamy Ostrołękę, NCBiR, cały obszar pandemii"
 - [https://fakty.tvn24.pl/fakty-po-poludniu/sejmowa-wiekszosc-planuje-kolejne-komisje-sledcze-chce-rozliczyc-pis-z-kolejnych-afer-st7457227?source=rss](https://fakty.tvn24.pl/fakty-po-poludniu/sejmowa-wiekszosc-planuje-kolejne-komisje-sledcze-chce-rozliczyc-pis-z-kolejnych-afer-st7457227?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T16:56:29+00:00

<img alt="Na trzech komisjach śledczych się nie skończy? " src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-3fjmva-bilinska-7457265/alternates/LANDSCAPE_1280" />
    Dotychczasowa opozycja zapewnia, że spełni żądanie wyborców i rozliczy odchodzącą władzę.

## Rząd Morawieckiego zaprzysiężony. Prezydent "bardzo się cieszy" i życzy powodzenia
 - [https://tvn24.pl/polska/rzad-mateusza-morawieckiego-bez-wiekszosci-zaprzysiezony-prezydent-andrzej-duda-bardzo-sie-ciesze-7457368?source=rss](https://tvn24.pl/polska/rzad-mateusza-morawieckiego-bez-wiekszosci-zaprzysiezony-prezydent-andrzej-duda-bardzo-sie-ciesze-7457368?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T16:33:54+00:00

<img alt="Rząd Morawieckiego zaprzysiężony. Prezydent " src="https://tvn24.pl/najnowsze/cdn-zdjecie-dpv6e6-23b27301-7457337/alternates/LANDSCAPE_1280" />
    Uroczystość odbyła się w Pałacu Prezydenckim.

## Polki z życiowymi wynikami. "Nie dowierzałam"
 - [https://eurosport.tvn24.pl/biathlon/puchar-swiata-w-biathlonie-2023-2024.-anna-maka-i-joanna-jakiela-o-starcie-w-oestersund_sto9898425/story.shtml?source=rss](https://eurosport.tvn24.pl/biathlon/puchar-swiata-w-biathlonie-2023-2024.-anna-maka-i-joanna-jakiela-o-starcie-w-oestersund_sto9898425/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T15:57:15+00:00

<img alt="Polki z życiowymi wynikami. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-65ujjw-polskie-biathlonistki-zaliczyly-udany-start-7457346/alternates/LANDSCAPE_1280" />
    Anna Mąka i Joanna Jakieła nie kryją dumy i zadowolenia.

## Początek jak z koszmaru. Najgorszy start sezonu Kamila Stocha
 - [https://eurosport.tvn24.pl/skoki-narciarskie/ruka/2023-2024/kamil-stoch-zanotowal-najgorszy-start-sezonu-w-historii-wystepow-w-pucharze-swiata_sto9898531/story.shtml?source=rss](https://eurosport.tvn24.pl/skoki-narciarskie/ruka/2023-2024/kamil-stoch-zanotowal-najgorszy-start-sezonu-w-historii-wystepow-w-pucharze-swiata_sto9898531/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T15:26:50+00:00

<img alt="Początek jak z koszmaru. Najgorszy start sezonu Kamila Stocha" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cxcaf4-kamil-stoch-7457257/alternates/LANDSCAPE_1280" />
    Sezon Pucharu Świata w skokach narciarskich ledwo wystartował, a dla polskich kibiców już jest wyjątkowy. W negatywnym sensie.

## Oto ministrowie w rządzie bez większości. Lista nazwisk
 - [https://tvn24.pl/polska/nowy-rzad-mateusza-morawieckiego-lista-ministrow-7457209?source=rss](https://tvn24.pl/polska/nowy-rzad-mateusza-morawieckiego-lista-ministrow-7457209?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T15:16:05+00:00

<img alt="Oto ministrowie w rządzie bez większości. Lista nazwisk " src="https://tvn24.pl/najnowsze/cdn-zdjecie-lbr8kp-pap_20231011_07t-7425278/alternates/LANDSCAPE_1280" />
    Mają wejść w skład nowego rządu Mateusza Morawieckiego.

## Minister Gliński chce powstrzymać zmiany w mediach rządowych. "Pozdrawiam Wszystkie Oczy Wielkiego Brata"
 - [https://tvn24.pl/biznes/z-kraju/rada-mediow-narodowych-zgodzila-sie-na-dokonanie-zmian-w-statutach-tvp-polskiego-radia-i-pap-st7457196?source=rss](https://tvn24.pl/biznes/z-kraju/rada-mediow-narodowych-zgodzila-sie-na-dokonanie-zmian-w-statutach-tvp-polskiego-radia-i-pap-st7457196?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T15:12:25+00:00

<img alt="Minister Gliński chce powstrzymać zmiany w mediach rządowych. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-2q49r1-tvp-6303091/alternates/LANDSCAPE_1280" />
    Szczegóły.

## Nie chciała wpuścić policjantów do mieszkania, w łazience znaleźli ciało i "liczne ślady krwi"
 - [https://tvn24.pl/lodz/pabianice-cialo-mezczyzny-z-ranami-klutymi-w-lazience-zarzut-zabojstwa-dla-27-latki-7457147?source=rss](https://tvn24.pl/lodz/pabianice-cialo-mezczyzny-z-ranami-klutymi-w-lazience-zarzut-zabojstwa-dla-27-latki-7457147?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T14:57:04+00:00

<img alt="Nie chciała wpuścić policjantów do mieszkania, w łazience znaleźli ciało i " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-lvsks2-interweniowala-policja-zdjecie-ilustracyjne-7412324/alternates/LANDSCAPE_1280" />
    Zarzut zabójstwa dla 27-latki.

## "Nawet kot prezesa nie dzwonił". Sprawdziliśmy, z kim rozmawiał Morawiecki. Niektóre odpowiedzi zaskakują
 - [https://tvn24.pl/polska/rzad-mateusza-morawieckiego-z-ktorymi-poslami-opozycji-rozmawial-zapytalismy-wszystkich-7456392?source=rss](https://tvn24.pl/polska/rzad-mateusza-morawieckiego-z-ktorymi-poslami-opozycji-rozmawial-zapytalismy-wszystkich-7456392?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T14:40:26+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qomjku-pierwsze-posiedzenie-sejmu-7456539/alternates/LANDSCAPE_1280" />
    Każdemu z 266 parlamentarzystów KO, PSL, Polski 2050, Lewicy oraz Konfederacji dziennikarki "Faktów" TVN i tvn24.pl zadały to samo pytanie: czy kontaktował się z nimi ktokolwiek z PiS-u.

## Prokuratura umorzyła postępowania wobec Jarosława Kaczyńskiego
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-prokuratura-umorzyla-postepowania-wobec-prezesa-pis-jaroslawa-kaczynskiego-st7457104?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-prokuratura-umorzyla-postepowania-wobec-prezesa-pis-jaroslawa-kaczynskiego-st7457104?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T14:37:46+00:00

<img alt="Prokuratura umorzyła postępowania wobec Jarosława Kaczyńskiego " src="https://tvn24.pl/najnowsze/cdn-zdjecie-cg2z3-nerwowa-atmosfera-podczas-obchodow-miesiecznicy-smolenskiej-w-pazdzierniku-7385517/alternates/LANDSCAPE_1280" />
    Chodzi o incydenty na miesięcznicy smoleńskiej.

## Mróz nie odpuści, a śniegu dosypie. Pogoda na 5 dni
 - [https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-5-dni-mroz-nie-odpusci-sniegu-dosypie-gdzie-spadnie-snieg-st7457077?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-5-dni-mroz-nie-odpusci-sniegu-dosypie-gdzie-spadnie-snieg-st7457077?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T14:28:02+00:00

<img alt="Mróz nie odpuści, a śniegu dosypie. Pogoda na 5 dni" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4xfcov-pogoda-na-5-dni-7457121/alternates/LANDSCAPE_1280" />
    Nadchodzące dni upłyną pod znakiem zimowej aury.

## 25-latek próbował sam uciec terrorystom z Hamasu. Teraz został uwolniony
 - [https://tvn24.pl/swiat/izrael-wojna-z-hamasem-25-latek-wsrod-uwolnionych-zakladnikow-wczesniej-sam-probowal-uciec-7456923?source=rss](https://tvn24.pl/swiat/izrael-wojna-z-hamasem-25-latek-wsrod-uwolnionych-zakladnikow-wczesniej-sam-probowal-uciec-7456923?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T13:39:18+00:00

<img alt="25-latek próbował sam uciec terrorystom z Hamasu. Teraz został uwolniony" src="https://tvn24.pl/najnowsze/cdn-zdjecie-dd5jn5-uwolnieni-zakladnicy-trafili-do-centrum-medycznego-chaim-sheba-w-ramat-gan-kolo-tel-awiwu-7455190/alternates/LANDSCAPE_1280" />
    Zwolniono go wraz z kobietami i dziećmi. Wiadomo dlaczego.

## Za kierownicą 14-latek, obok kilku innych nastolatków. Dachowanie
 - [https://tvn24.pl/krakow/chocholow-dachowanie-na-zasniezonej-drodze-za-kierownica-14-latek-nagranie-7457003?source=rss](https://tvn24.pl/krakow/chocholow-dachowanie-na-zasniezonej-drodze-za-kierownica-14-latek-nagranie-7457003?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T13:38:07+00:00

<img alt="Za kierownicą 14-latek, obok kilku innych nastolatków. Dachowanie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hwvr7s-do-zdarzenia-doszlo-w-chocholowie-za-kierownica-siedzial-14-latek-7456882/alternates/LANDSCAPE_1280" />
    Nagranie z Chochołowa.

## Media: wyniki badań medycznych kilkudziesięciu tysięcy Polek i Polaków wyciekły
 - [https://tvn24.pl/biznes/z-kraju/atak-hakerski-na-alab-wyniki-badan-medycznych-kilkudziesieciu-tysiecy-polek-i-polakow-ujawnione-st7456871?source=rss](https://tvn24.pl/biznes/z-kraju/atak-hakerski-na-alab-wyniki-badan-medycznych-kilkudziesieciu-tysiecy-polek-i-polakow-ujawnione-st7456871?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T13:31:45+00:00

<img alt="Media: wyniki badań medycznych kilkudziesięciu tysięcy Polek i Polaków wyciekły" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rrjuxs-leki-laboratorium-shutterstock_1726134715-6233810/alternates/LANDSCAPE_1280" />
    Według ustaleń miało dojść do ataku hakerów.

## Paweł Huelle nie żyje
 - [https://tvn24.pl/polska/pawel-huelle-nie-zyje-pisarz-mial-66-lat-7456927?source=rss](https://tvn24.pl/polska/pawel-huelle-nie-zyje-pisarz-mial-66-lat-7456927?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T12:30:18+00:00

<img alt="Paweł Huelle nie żyje" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qyodal-pap_20210602_1v3-7456925/alternates/LANDSCAPE_1280" />
    Miał 66 lat. Twórczość poświęcił miastu, w którym się urodził - Gdańskowi.

## Rząd na dwa tygodnie może kosztować setki tysięcy złotych
 - [https://tvn24.pl/biznes/z-kraju/odprawy-i-wyrownania-dla-ministrow-ile-wyniosa-kto-je-dostanie-st7456598?source=rss](https://tvn24.pl/biznes/z-kraju/odprawy-i-wyrownania-dla-ministrow-ile-wyniosa-kto-je-dostanie-st7456598?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T12:28:43+00:00

<img alt="Rząd na dwa tygodnie może kosztować setki tysięcy złotych" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-omm2xy-premier-mateusz-morawiecki-7456633/alternates/LANDSCAPE_1280" />
    Ministrowie mogą liczyć na odprawy.

## Rząd na dwa tygodnie może kosztować setki tysięcy złotych
 - [https://tvn24.pl/biznes/z-kraju/rzad-morawieckiego-odprawy-dla-ministrow-ile-wyniosa-kto-je-dostanie-st7456598?source=rss](https://tvn24.pl/biznes/z-kraju/rzad-morawieckiego-odprawy-dla-ministrow-ile-wyniosa-kto-je-dostanie-st7456598?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T12:28:43+00:00

<img alt="Rząd na dwa tygodnie może kosztować setki tysięcy złotych" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-omm2xy-premier-mateusz-morawiecki-7456633/alternates/LANDSCAPE_1280" />
    Ministrowie mogą liczyć na odprawy.

## Uczniowie protestowali i pytali o finanse szkoły. Jest zapowiedź odwołania dyrektorki
 - [https://tvn24.pl/krakow/krakow-po-wewnetrznej-kontroli-jest-zapowiedz-odwolania-dyrektorki-xxx-lo-7456847?source=rss](https://tvn24.pl/krakow/krakow-po-wewnetrznej-kontroli-jest-zapowiedz-odwolania-dyrektorki-xxx-lo-7456847?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T12:24:00+00:00

<img alt="Uczniowie protestowali i pytali o finanse szkoły. Jest zapowiedź odwołania dyrektorki" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ovia7c-xxx-liceum-krakow-7428271/alternates/LANDSCAPE_1280" />
    Stwierdzono "dużą ilość różnego rodzaju nieprawidłowości".

## Kiedy i o której losowanie grup Euro 2024? Z kim może zagrać Polska?
 - [https://eurosport.tvn24.pl/pilka-nozna/euro/2024/kiedy-i-o-ktorej-losowanie-grup-euro-2024-data-i-godzina-z-kim-moze-zagrac-polska_sto9898310/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/euro/2024/kiedy-i-o-ktorej-losowanie-grup-euro-2024-data-i-godzina-z-kim-moze-zagrac-polska_sto9898310/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T12:14:24+00:00

<img alt="Kiedy i o której losowanie grup Euro 2024? Z kim może zagrać Polska?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-21jd77-robert-lewandowski-7445179/alternates/LANDSCAPE_1280" />
    Przed nami losowanie Euro 2024.

## Pościg w Gdyni. Policjant użył broni
 - [https://tvn24.pl/trojmiasto/gdynia-poscig-ulicami-miasta-policjant-uzyl-broni-nagranie-7456777?source=rss](https://tvn24.pl/trojmiasto/gdynia-poscig-ulicami-miasta-policjant-uzyl-broni-nagranie-7456777?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T11:58:07+00:00

<img alt="Pościg w Gdyni. Policjant użył broni" src="https://tvn24.pl/najnowsze/cdn-zdjecie-k1mjyj-doszlo-do-kolizji-uciekajacego-kierowcy-z-radiowozem-7456788/alternates/LANDSCAPE_1280" />
    Kierowca zderzył się z radiowozem i wjechał na chodnik.

## Polskie alpejki piszą historię. 21-letnia łodzianka dobija się do czołówki
 - [https://eurosport.tvn24.pl/narciarstwo-alpejskie/killington-vt/2023-2024/alpejski-puchar-swiata-killington-2023.-jak-spisaly-sie-polki.-kim-jest-magdalena-luczak_sto9898229/story.shtml?source=rss](https://eurosport.tvn24.pl/narciarstwo-alpejskie/killington-vt/2023-2024/alpejski-puchar-swiata-killington-2023.-jak-spisaly-sie-polki.-kim-jest-magdalena-luczak_sto9898229/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T11:30:39+00:00

<img alt="Polskie alpejki piszą historię. 21-letnia łodzianka dobija się do czołówki" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5dkty8-magdalena-luczak-na-trasie-giganta-w-killington-7456850/alternates/LANDSCAPE_1280" />
    Coraz śmielej poczyna sobie w Pucharze Świata.

## Czteromiesięczna Nadia w szpitalu, rodzice z zarzutami. Prokuratura sprawdza, jak działał GOPS
 - [https://tvn24.pl/rzeszow/rzeszow-jaslo-rodzice-czteromiesiecznej-nadii-sa-podejrzani-o-znecanie-sie-nad-dzieckiem-prokuratura-sprawdza-jak-dzialal-gops-7456647?source=rss](https://tvn24.pl/rzeszow/rzeszow-jaslo-rodzice-czteromiesiecznej-nadii-sa-podejrzani-o-znecanie-sie-nad-dzieckiem-prokuratura-sprawdza-jak-dzialal-gops-7456647?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T11:17:57+00:00

<img alt="Czteromiesięczna Nadia w szpitalu, rodzice z zarzutami. Prokuratura sprawdza, jak działał GOPS" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ovj9wp-dziewczynka-przebywa-w-klinicznym-szpitalu-wojewodzkim-w-rzeszowie-7406612/alternates/LANDSCAPE_1280" />
    Dziewczynka trafi do rodziny zastępczej.

## Wielka kumulacja w Lotto rozbita. Podano, gdzie padła główna wygrana
 - [https://tvn24.pl/biznes/z-kraju/kumulacja-w-lotto-rozbita-glowna-wygrana-radzionkow-st7456746?source=rss](https://tvn24.pl/biznes/z-kraju/kumulacja-w-lotto-rozbita-glowna-wygrana-radzionkow-st7456746?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T11:11:07+00:00

<img alt="Wielka kumulacja w Lotto rozbita. Podano, gdzie padła główna wygrana" src="https://tvn24.pl/najnowsze/cdn-zdjecie-dnysue-lotto_1997459012-5742813/alternates/LANDSCAPE_1280" />
    W sobotnim losowaniu.

## Od stycznia nowe świadczenie. Trzeba złożyć wniosek
 - [https://tvn24.pl/biznes/z-kraju/swiadczenie-wspierajace-dla-osob-z-niepelnosprawnosciami-od-1-stycznia-2024-dla-kogo-na-jakich-zasadach-st7456666?source=rss](https://tvn24.pl/biznes/z-kraju/swiadczenie-wspierajace-dla-osob-z-niepelnosprawnosciami-od-1-stycznia-2024-dla-kogo-na-jakich-zasadach-st7456666?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T11:02:07+00:00

<img alt="Od stycznia nowe świadczenie. Trzeba złożyć wniosek" src="https://tvn24.pl/najnowsze/cdn-zdjecie-58dbla-pieniadze-na-zakupy-wegla-z-pozyczek-i-obligacji-na-co-sie-juz-zadluzylismy-6173482/alternates/LANDSCAPE_1280" />
    Resort rodziny wyjaśnia.

## NIK wskazuje na ministra i szefa partii. Zawiadamia prokuraturę
 - [https://tvn24.pl/premium/nik-zawiadamia-prokurature-w-sprawie-ncbr-wskazuje-na-ministra-i-szefa-partii-7456382?source=rss](https://tvn24.pl/premium/nik-zawiadamia-prokurature-w-sprawie-ncbr-wskazuje-na-ministra-i-szefa-partii-7456382?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T11:01:00+00:00

<img alt="NIK wskazuje na ministra i szefa partii. Zawiadamia prokuraturę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-463r4r-przez-ostatnie-miesiace-zylismy-w-niepewnosci-7081658/alternates/LANDSCAPE_1280" />
    Jak ustalił tvn24.pl, zdaniem Najwyższej Izby Kontroli istnieje uzasadnione podejrzenie, że przestępstwa popełnili europoseł i szef partii Republikanie Adam Bielan, minister funduszy i polityki regionalnej Grzegorz Puda oraz dyrektor Narodowego Centrum Badań i Rozwoju Jacek Orzeł. NIK przygotowała już zawiadomienie do prokuratury w tej sprawie.

## Chciała pomóc synowi. Straciła 5000 złotych
 - [https://tvn24.pl/wroclaw/walbrzych-chciala-pomoc-synowi-przez-oszustow-stracila-pieniadze-7456423?source=rss](https://tvn24.pl/wroclaw/walbrzych-chciala-pomoc-synowi-przez-oszustow-stracila-pieniadze-7456423?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T10:52:09+00:00

<img alt="Chciała pomóc synowi. Straciła 5000 złotych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qjazok-przyszedl-na-komende-odebrac-telefon-komorkowy-zdjecie-ilustracyjne-7300247/alternates/LANDSCAPE_1280" />
    Policja apeluje i przestrzega.

## Przechodził przez pasy, potrącił go 83-letni taksówkarz. Pieszy nie żyje
 - [https://tvn24.pl/wroclaw/wroclaw-wypadek-na-pasach-83-letni-taksowkarz-smiertelnie-potracil-pieszego-7456713?source=rss](https://tvn24.pl/wroclaw/wroclaw-wypadek-na-pasach-83-letni-taksowkarz-smiertelnie-potracil-pieszego-7456713?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T10:48:22+00:00

<img alt="Przechodził przez pasy, potrącił go 83-letni taksówkarz. Pieszy nie żyje" src="https://tvn24.pl/najnowsze/cdn-zdjecie-682tbm-policja-policyjny-kogut-6722449/alternates/LANDSCAPE_1280" />
    Okoliczności zdarzenia wyjaśnia policja pod nadzorem prokuratury.

## Świętowanie wygranej przyniosło fatalne skutki
 - [https://eurosport.tvn24.pl/kolarstwo/kraksa-kolarzy-na-finiszu.-chcieli-razem-swietowac-sukces_sto9898232/story.shtml?source=rss](https://eurosport.tvn24.pl/kolarstwo/kraksa-kolarzy-na-finiszu.-chcieli-razem-swietowac-sukces_sto9898232/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T10:41:22+00:00

<img alt="Świętowanie wygranej przyniosło fatalne skutki" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kwp90e-swietowanie-sukcesu-wymknelo-sie-spod-kontroli-7456725/alternates/LANDSCAPE_1280" />
    Jeden z najdziwniejszych kolarskich finiszów ostatnich lat.

## Historyczny gol Bellinghama. Przebił osiągnięcie legend Realu
 - [https://eurosport.tvn24.pl/pilka-nozna/primera-division/2023-2024/jude-bellingham-z-najlepszym-poczatkiem-w-historii-realu-pobil-rekord-cristiano-ronaldo-i-alfredo-di_sto9898131/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/primera-division/2023-2024/jude-bellingham-z-najlepszym-poczatkiem-w-historii-realu-pobil-rekord-cristiano-ronaldo-i-alfredo-di_sto9898131/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T10:11:14+00:00

<img alt="Historyczny gol Bellinghama. Przebił osiągnięcie legend Realu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kfq06u-bellingham-blyszczy-od-poczatku-sezonu-7456662/alternates/LANDSCAPE_1280" />
    Nikt nie miał takiego startu w madryckim klubie jak Anglik.

## Na przejazd czeka tu ponad 1400 kierowców
 - [https://tvn24.pl/rzeszow/medyka-protest-na-granicy-rozpoczela-sie-calodobowa-blokada-terminala-kolejki-tirow-przed-przejsciem-7456536?source=rss](https://tvn24.pl/rzeszow/medyka-protest-na-granicy-rozpoczela-sie-calodobowa-blokada-terminala-kolejki-tirow-przed-przejsciem-7456536?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T10:00:39+00:00

<img alt="Na przejazd czeka tu ponad 1400 kierowców" src="https://tvn24.pl/krakow/cdn-zdjecie-4hmn3c-rozpoczela-sie-calodobowa-blokada-przejscia-granicznego-w-medyce-7456528/alternates/LANDSCAPE_1280" />
    Rozpoczęto całodobową blokadę przejścia granicznego.

## Nowe limity zarobkowe dla części emerytów. ZUS wyjaśnia
 - [https://tvn24.pl/biznes/dla-seniora/emerytury-nowe-limity-zarobkowe-zus-wyjasnia-st7456572?source=rss](https://tvn24.pl/biznes/dla-seniora/emerytury-nowe-limity-zarobkowe-zus-wyjasnia-st7456572?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T10:00:38+00:00

<img alt="Nowe limity zarobkowe dla części emerytów. ZUS wyjaśnia" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jxtbsw-zus-szczecin-grand-warszawski-shutterstock_2360135365-7375977/alternates/LANDSCAPE_1280" />
    Od grudnia.

## Polak na ustach francuskich mediów. "Ten rekord stanie się jego obsesją"
 - [https://eurosport.tvn24.pl/pilka-nozna/ligue-1/2023-2024/marcin-bulka-wciaz-nie-pokonany.-rosnie-liczba-minut-bez-wpuszczonego-gola_sto9898086/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/ligue-1/2023-2024/marcin-bulka-wciaz-nie-pokonany.-rosnie-liczba-minut-bez-wpuszczonego-gola_sto9898086/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T09:59:51+00:00

<img alt="Polak na ustach francuskich mediów. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-4niw6e-marcin-bulka-po-meczu-z-monaco-7456628/alternates/LANDSCAPE_1280" />
    Wyrasta na postać numer jeden tegorocznych rozgrywek francuskiej ekstraklasy.

## Zatonął statek przewożący sól. Jedna osoba zginęła, 12 zaginionych
 - [https://tvn24.pl/swiat/lesbos-zatonal-statek-przewozacy-sol-12-osob-zaginionych-7456226?source=rss](https://tvn24.pl/swiat/lesbos-zatonal-statek-przewozacy-sol-12-osob-zaginionych-7456226?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T09:49:46+00:00

<img alt="Zatonął statek przewożący sól. Jedna osoba zginęła, 12 zaginionych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wdnxrd-uratowano-jedna-osobe-7456225/alternates/LANDSCAPE_1280" />
    Statek zatonął u wybrzeży greckiej wyspy Lesbos. Uratowano zaledwie jedną osobę.

## 14 kolizji o poranku w Krakowie
 - [https://tvn24.pl/tvnmeteo/polska/14-kolizji-o-poranku-w-krakowie-zwracajmy-uwage-na-pieszych-st7456459?source=rss](https://tvn24.pl/tvnmeteo/polska/14-kolizji-o-poranku-w-krakowie-zwracajmy-uwage-na-pieszych-st7456459?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T09:37:44+00:00

<img alt="14 kolizji o poranku w Krakowie" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-pupkws-sliskie-drogi-w-czesci-kraju-7456510/alternates/LANDSCAPE_1280" />
    Warunki na drogach są trudne.

## Nowy rząd Morawieckiego. Szefowa Kancelarii Prezydenta przedstawiła plan na dziś
 - [https://tvn24.pl/polska/zaprzysiezenie-rzadu-mateusza-morawieckiego-szefowa-kancelarii-prezydenta-andrzeja-dudy-o-szczegolach-uroczystosci-7456311?source=rss](https://tvn24.pl/polska/zaprzysiezenie-rzadu-mateusza-morawieckiego-szefowa-kancelarii-prezydenta-andrzeja-dudy-o-szczegolach-uroczystosci-7456311?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T09:00:14+00:00

<img alt="Nowy rząd Morawieckiego. Szefowa Kancelarii Prezydenta przedstawiła plan na dziś" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wscvot-prezydent-powierzyl-misje-tworzenia-rzadu-mateuszowi-morawieckiemu-7436168/alternates/LANDSCAPE_1280" />
    Uroczystość odbędzie się w poniedziałek o godz. 16:30.

## Trybunał Stanu za wybory kopertowe? Kto, kiedy i jakie decyzje podejmował
 - [https://konkret24.tvn24.pl/polityka/jacek-sasin-przed-trybunal-stanu-za-wybory-kopertowe-kto-kiedy-jakie-decyzje-podejmowal-st7453114?source=rss](https://konkret24.tvn24.pl/polityka/jacek-sasin-przed-trybunal-stanu-za-wybory-kopertowe-kto-kiedy-jakie-decyzje-podejmowal-st7453114?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T08:41:30+00:00

<img alt="Trybunał Stanu za wybory kopertowe? Kto, kiedy i jakie decyzje podejmował " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ayfjp7-pap_20221011_0pv-1-7453027/alternates/LANDSCAPE_1280" />
    Jacek Sasin firmował wybory prezydenckie, które się nie odbyły, ale kto podjął bezprawne decyzje? Oto kalendarium zdarzeń

## Sochan kontuzjowany. Spurs dalej w kryzysie
 - [https://eurosport.tvn24.pl/koszykowka/nba/2023-2024/denver-nuggets-san-antonio-spurs-wynik-meczu-i-relacja.-jak-zagral-sochan-co-z-polakiem-nba_sto9898083/story.shtml?source=rss](https://eurosport.tvn24.pl/koszykowka/nba/2023-2024/denver-nuggets-san-antonio-spurs-wynik-meczu-i-relacja.-jak-zagral-sochan-co-z-polakiem-nba_sto9898083/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T08:22:38+00:00

<img alt="Sochan kontuzjowany. Spurs dalej w kryzysie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-z8agzj-sochan-w-meczu-z-nuggets-7456410/alternates/LANDSCAPE_1280" />
    Polak wystąpił tylko w pierwszej połowie.

## Dwóch patostreamerów z zarzutami po transmisjach w internecie. "Umniejszali swoją rolę"
 - [https://tvn24.pl/katowice/patostreamerzy-z-zarzutami-jest-wniosek-o-areszt-dla-kawiaqa-i-bartlomieja-k-7456390?source=rss](https://tvn24.pl/katowice/patostreamerzy-z-zarzutami-jest-wniosek-o-areszt-dla-kawiaqa-i-bartlomieja-k-7456390?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T08:17:17+00:00

<img alt="Dwóch patostreamerów z zarzutami po transmisjach w internecie. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-6h42fl-pato-skl-7456431/alternates/LANDSCAPE_1280" />
    Jak informuje prokuratura, nie przyznali się.

## Dwóch patostreamerów zatrzymanych. Prokurator przedstawi im dziś zarzuty
 - [https://tvn24.pl/katowice/slask-dwoch-patostreamerow-zatrzymanych-kawiaq-i-bartlomiej-k-w-rekach-policji-7456390?source=rss](https://tvn24.pl/katowice/slask-dwoch-patostreamerow-zatrzymanych-kawiaq-i-bartlomiej-k-w-rekach-policji-7456390?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T08:17:17+00:00

<img alt="Dwóch patostreamerów zatrzymanych. Prokurator przedstawi im dziś zarzuty" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6h42fl-pato-skl-7456431/alternates/LANDSCAPE_1280" />
    W poniedziałek mają zostać doprowadzeni do prokuratury.

## Dwóch patostreamerów zatrzymanych. Prokurator przedstawi im dziś zarzuty
 - [https://tvn24.pl/katowice/dwoch-patostreamerow-zatrzymanych-kawiaq-i-bartlomiej-k-w-rekach-policji-7456390?source=rss](https://tvn24.pl/katowice/dwoch-patostreamerow-zatrzymanych-kawiaq-i-bartlomiej-k-w-rekach-policji-7456390?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T08:17:17+00:00

<img alt="Dwóch patostreamerów zatrzymanych. Prokurator przedstawi im dziś zarzuty" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6h42fl-pato-skl-7456431/alternates/LANDSCAPE_1280" />
    W poniedziałek mają zostać doprowadzeni do prokuratury.

## "Taki jest charakter państwowego biznesu, że trafiają do niego również ludzie z polityki"
 - [https://tvn24.pl/polska/jacek-sasin-o-spolkach-skarbu-panstwa-niestety-nie-udalo-nam-sieuniknac-bledow-ktore-robili-poprzednicy-7456331?source=rss](https://tvn24.pl/polska/jacek-sasin-o-spolkach-skarbu-panstwa-niestety-nie-udalo-nam-sieuniknac-bledow-ktore-robili-poprzednicy-7456331?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T08:02:20+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-l74ezu-pap_20231114_13x-7456368/alternates/LANDSCAPE_1280" />
    Ustępujący minister o spółkach Skarbu Państwa.

## Utwory skomponowane w Auschwitz wybrzmią ponownie po niemal 80 latach
 - [https://tvn24.pl/swiat/utwory-skomponowane-w-auschwitz-zostana-zagrane-po-80-latach-w-wielkiej-brytanii-7456303?source=rss](https://tvn24.pl/swiat/utwory-skomponowane-w-auschwitz-zostana-zagrane-po-80-latach-w-wielkiej-brytanii-7456303?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T07:43:45+00:00

<img alt="Utwory skomponowane w Auschwitz wybrzmią ponownie po niemal 80 latach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-a10bje-partytury-skomponowane-w-auschwitz-7456297/alternates/LANDSCAPE_1280" />
    Zniszczone partytury zdołał odtworzyć brytyjski kompozytor, Leo Geyer.

## Były trener Lecha w Bundeslidze. Debiut od razu w Lidze Mistrzów
 - [https://eurosport.tvn24.pl/pilka-nozna/bundesliga/2023-2024/bundesliga.-nenad-bjelica-nowym-trenerem-unionu-berlin_sto9898069/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/bundesliga/2023-2024/bundesliga.-nenad-bjelica-nowym-trenerem-unionu-berlin_sto9898069/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T07:37:45+00:00

<img alt="Były trener Lecha w Bundeslidze. Debiut od razu w Lidze Mistrzów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-36zr4u-bjelica-zaprezentowany-7456343/alternates/LANDSCAPE_1280" />
    Zastąpił Ursa Fischera.

## Końca fatalnej serii nie widać. Siatkarze z Radomia zapomnieli, jak się wygrywa
 - [https://eurosport.tvn24.pl/siatkowka/plusliga/2023-2024/plusliga-pge-stal-nysa-enea-czarni-radom-wynik-meczu-i-relacja.-ktora-porazka-z-rzedu-czarnych-kiedy_sto9898065/story.shtml?source=rss](https://eurosport.tvn24.pl/siatkowka/plusliga/2023-2024/plusliga-pge-stal-nysa-enea-czarni-radom-wynik-meczu-i-relacja.-ktora-porazka-z-rzedu-czarnych-kiedy_sto9898065/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T07:17:43+00:00

<img alt="Końca fatalnej serii nie widać. Siatkarze z Radomia zapomnieli, jak się wygrywa" src="https://tvn24.pl/najnowsze/cdn-zdjecie-r6acym-siatkarze-enea-czarni-radom-zapomnieli-jak-sie-wygrywa-7456320/alternates/LANDSCAPE_1280" />
    Kolejna porażka, choć tym razem zdecydowanie mniej bolesna niż poprzednie.

## Sasin: mówi się, że jest 10 procent szans
 - [https://tvn24.pl/polska/mateusz-morawiecki-z-misja-stworzenia-rzadu-jacek-sasin-bedzie-ekstremalnie-trudno-mowi-sie-ze-10-procent-szans-7456283?source=rss](https://tvn24.pl/polska/mateusz-morawiecki-z-misja-stworzenia-rzadu-jacek-sasin-bedzie-ekstremalnie-trudno-mowi-sie-ze-10-procent-szans-7456283?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T07:02:58+00:00

<img alt="Sasin: mówi się, że jest 10 procent szans" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wrx2d5-sasin-piasek-7456286/alternates/LANDSCAPE_1280" />
    Jacek Sasin był gościem "Rozmowy Piaseckiego".

## Miliony na doradców Glapińskiego. NBP nie chce ujawniać nazwisk
 - [https://tvn24.pl/biznes/z-kraju/nbp-miliony-na-doradcow-glapinskiego-nbp-nie-chce-ujawniac-nazwisk-st7456271?source=rss](https://tvn24.pl/biznes/z-kraju/nbp-miliony-na-doradcow-glapinskiego-nbp-nie-chce-ujawniac-nazwisk-st7456271?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T06:56:49+00:00

<img alt="Miliony na doradców Glapińskiego. NBP nie chce ujawniać nazwisk" src="https://tvn24.pl/najnowsze/cdn-zdjecie-nudial-adam-glapinski-prezes-nbp-7425448/alternates/LANDSCAPE_1280" />
    Informuje dziennik "Rzeczpospolita".

## Poszukiwani za porwanie Belgów kilka miesięcy ukrywali się na Mazowszu
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-byli-poszukiwani-za-porwanie-dwoch-belgow-przez-kilka-miesiecy-ukrywali-sie-na-mazowszu-st7456274?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-byli-poszukiwani-za-porwanie-dwoch-belgow-przez-kilka-miesiecy-ukrywali-sie-na-mazowszu-st7456274?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T06:43:55+00:00

<img alt="Poszukiwani za porwanie Belgów kilka miesięcy ukrywali się na Mazowszu" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-f3bwlv-byli-poszukiwani-za-przestepstwo-popelnione-w-belgii-zatrzymano-ich-na-mazowszu-7456287/alternates/LANDSCAPE_1280" />
    "Łowcy cieni" zatrzymali czterech Polaków poszukiwanych przez belgijską policję.

## Kubacki odniósł się do słów trenera. "Nie tędy droga"
 - [https://eurosport.tvn24.pl/skoki-narciarskie/ruka/2023-2024/skoki-narciarskie-ruka-2023.-dawid-kubacki-zaskoczyl-w-studiu-tvn-puchar-swiata-2023-24_sto9898062/story.shtml?source=rss](https://eurosport.tvn24.pl/skoki-narciarskie/ruka/2023-2024/skoki-narciarskie-ruka-2023.-dawid-kubacki-zaskoczyl-w-studiu-tvn-puchar-swiata-2023-24_sto9898062/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T06:43:25+00:00

<img alt="Kubacki odniósł się do słów trenera. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-nop1fh-kubacki-nie-opuszcza-ruki-w-dobrym-nastroju-7456299/alternates/LANDSCAPE_1280" />
    Był najlepszym polskim skoczkiem podczas pierwszego weekendu z Pucharem Świata.

## "Polacy byli jeszcze gorsi". Rywale pocieszają się po kiepskim starcie
 - [https://eurosport.tvn24.pl/skoki-narciarskie/ruka/2023-2024/skoki-narciarskie.-ruka-2023.-norweskie-media-po-pierwszym-weekendzie-pucharu-swiata_sto9897848/story.shtml?source=rss](https://eurosport.tvn24.pl/skoki-narciarskie/ruka/2023-2024/skoki-narciarskie.-ruka-2023.-norweskie-media-po-pierwszym-weekendzie-pucharu-swiata_sto9897848/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T06:35:55+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hh3zdv-halvor-egner-granerud-w-ruce-7456295/alternates/LANDSCAPE_1280" />
    Nowego sezonu Pucharu Świata.

## Pełnia Bobrzego Księżyca oczami Reporterów 24
 - [https://tvn24.pl/tvnmeteo/ciekawostki/pelnia-ksiezyca-listopad-2023-pelnia-bobrzego-ksiezyca-pelnia-mroznego-ksiezyca-kiedy-jak-obserwowac-st7456245?source=rss](https://tvn24.pl/tvnmeteo/ciekawostki/pelnia-ksiezyca-listopad-2023-pelnia-bobrzego-ksiezyca-pelnia-mroznego-ksiezyca-kiedy-jak-obserwowac-st7456245?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T06:27:31+00:00

<img alt="Pełnia Bobrzego Księżyca oczami Reporterów 24" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-bod2qn-pelnia-ksiezyca-7456258/alternates/LANDSCAPE_1280" />
    Materiały otrzymaliśmy na Kontakt 24.

## "Gdy tylko dostaną wodę, natychmiast zaczynają ją pić. Są spragnieni. Spragnieni od wielu dni"
 - [https://tvn24.pl/swiat/noc-strefa-gazy-konwoj-z-pomoca-humanitarna-w-drodze-do-polnocnej-czesci-7456222?source=rss](https://tvn24.pl/swiat/noc-strefa-gazy-konwoj-z-pomoca-humanitarna-w-drodze-do-polnocnej-czesci-7456222?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T06:24:03+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-o00vuw-ciezarowki-z-pomoca-7456228/alternates/LANDSCAPE_1280" />
    Największy od miesiąca konwój z pomocą humanitarną już wkrótce może dotrzeć do osób zamieszkujących północną część Strefy Gazy.

## Rząd na dwa tygodnie. Za chwilę zaprzysiężenie
 - [https://tvn24.pl/polska/rzad-mateusza-morawieckiego-zaprzysiezenie-relacja-komentarze-polityczne-27-listopada-7456269?source=rss](https://tvn24.pl/polska/rzad-mateusza-morawieckiego-zaprzysiezenie-relacja-komentarze-polityczne-27-listopada-7456269?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T06:04:45+00:00

<img alt="Rząd na dwa tygodnie. Za chwilę zaprzysiężenie " src="https://tvn24.pl/najnowsze/cdn-zdjecie-3xcphd-palac-prezydencki-7457220/alternates/LANDSCAPE_1280" />
    W tvn24.pl relacjonujemy wydarzenia politycznego poniedziałku.

## Zostało 10 metrów skał do przewiercenia. Pogoda może dziś utrudnić akcję ratunkową
 - [https://tvn24.pl/swiat/indie-uttarkashi-problemy-z-akcja-ratunkowa-w-zawalonym-tunelu-7456206?source=rss](https://tvn24.pl/swiat/indie-uttarkashi-problemy-z-akcja-ratunkowa-w-zawalonym-tunelu-7456206?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T05:39:09+00:00

<img alt="Zostało 10 metrów skał do przewiercenia. Pogoda może dziś utrudnić akcję ratunkową" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ma4dv1-akcje-ratunkowa-wstrzymano-z-powodu-usterki-technicznej-7456210/alternates/LANDSCAPE_1280" />
    41 robotników pozostaje uwięzionych od 16 dni w zawalonym tunelu drogowym na północy Indii. Ratownicy wiercą nowy, pionowy, szyb ewakuacyjny.

## Obfite opady śniegu. Alerty IMGW w siedmiu województwach
 - [https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-intensywne-opady-sniegu-pogoda-w-poniedzialek-2711-prognoza-zagrozen-oblodzenia-opady-marznace-gololedz-st7456239?source=rss](https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-intensywne-opady-sniegu-pogoda-w-poniedzialek-2711-prognoza-zagrozen-oblodzenia-opady-marznace-gololedz-st7456239?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T05:20:55+00:00

<img alt="Obfite opady śniegu. Alerty IMGW w siedmiu województwach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-u4wjnd-pogoda-bedzie-niebezpieczna-5007716/alternates/LANDSCAPE_1280" />
    IMGW wydał także prognozę zagrożeń.

## Uwaga na śliskie drogi i chodniki
 - [https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-intensywne-opady-sniegu-oblodzenia-pogoda-w-poniedzialek-2711-st7456239?source=rss](https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-intensywne-opady-sniegu-oblodzenia-pogoda-w-poniedzialek-2711-st7456239?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T05:20:55+00:00

<img alt="Uwaga na śliskie drogi i chodniki" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-t3v1m5-oblodzenia-5593660/alternates/LANDSCAPE_1280" />
    IMGW ostrzega.

## Poleciał na całość. Rekordowa nota na dużej skoczni
 - [https://eurosport.tvn24.pl/skoki-narciarskie/ruka/2023-2024/stefan-kraft-polecial-na-calosc.-jubileusz-okraszony-rekordem_sto9897825/story.shtml?source=rss](https://eurosport.tvn24.pl/skoki-narciarskie/ruka/2023-2024/stefan-kraft-polecial-na-calosc.-jubileusz-okraszony-rekordem_sto9897825/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T05:15:03+00:00

<img alt="Poleciał na całość. Rekordowa nota na dużej skoczni" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hx0q6i-stefan-kraft-7456240/alternates/LANDSCAPE_1280" />
    To był teatr jednego aktora. Oba konkursy w Ruce wygrał Stefan Kraft. Jego liczby powalają na kolana.

## Gorąco na granicy między Koreami
 - [https://tvn24.pl/swiat/goraco-na-granicy-miedzy-koreami-zolnierze-odbudowuja-wartownie-koniec-strefy-zdemilitaryzowanej-7456231?source=rss](https://tvn24.pl/swiat/goraco-na-granicy-miedzy-koreami-zolnierze-odbudowuja-wartownie-koniec-strefy-zdemilitaryzowanej-7456231?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-11-27T05:02:54+00:00

<img alt="Gorąco na granicy między Koreami" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ybxt9u-kim-dzong-un-7456230/alternates/LANDSCAPE_1280" />
    Korea Północna rozmieszcza żołnierzy i ciężki sprzęt wojskowy– podaje agencja informacyjna Yonhap.

