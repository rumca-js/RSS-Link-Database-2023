# Source:Academy of Ideas, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCiRiQGCHGjDLT9FQXFW0I3A, language:en-US

## Is Rapid Personality Transformation Possible? – The Psychology of Quantum Change
 - [https://www.youtube.com/watch?v=tidmA_EW3Jo](https://www.youtube.com/watch?v=tidmA_EW3Jo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCiRiQGCHGjDLT9FQXFW0I3A
 - date published: 2023-11-27T20:09:58+00:00

This is a clip from our latest membership video, access this video, and over 80 others exclusive to members - become a Supporting Member - https://academyofideas.com/members/

