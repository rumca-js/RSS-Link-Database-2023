# Source:Daily Wire, URL:https://www.dailywire.com/feeds/rss.xml, language:en-US

## More Than 2,500 NYPD Cops Have Quit This Year
 - [https://www.dailywire.com/news/more-than-2500-nypd-cops-have-quit-this-year](https://www.dailywire.com/news/more-than-2500-nypd-cops-have-quit-this-year)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-11-27T18:04:26+00:00

Cops are quitting New York City&#8216;s police force in droves with more than 2,500 officers leaving just this year. A total of 2,516 NYPD officers have left so far this year, the fourth highest in the past 10 years, according to NYPD pension data obtained by the New York Post. The number also 43% higher ...

## Male Disneyland Guest Arrested After Stripping Down Fully Naked On ‘It’s A Small World’ Ride
 - [https://www.dailywire.com/news/male-disneyland-guest-arrested-after-stripping-down-fully-naked-on-its-a-small-world-ride](https://www.dailywire.com/news/male-disneyland-guest-arrested-after-stripping-down-fully-naked-on-its-a-small-world-ride)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-11-27T18:04:08+00:00

An adult male guest at Disneyland was arrested on Sunday after he stripped down fully naked and caused havoc in the California park during the Thanksgiving holiday — boarding a boat on the &#8220;It&#8217;s A Small World&#8221; ride before he was apprehended and removed from the property. Anaheim Police Department spokesperson Jonathan McClintock told People ...

## Disney: Lack Of ‘Consumer Acceptance’ Cutting Into Company Revenue
 - [https://www.dailywire.com/news/disney-lack-of-consumer-acceptance-cutting-into-company-revenue](https://www.dailywire.com/news/disney-lack-of-consumer-acceptance-cutting-into-company-revenue)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-11-27T17:58:37+00:00

Disney acknowledged risks due to a “misalignment” between the company’s products and the public that are hurting its bottom line in recent filings with the government. Disney filed its annual SEC report for the year ending on September 30 last week. George Washington law professor Jonathan Turley pointed out the report in a column with ...

## Hamas Official: We Kidnapped Foreign Nationals For ‘Their Own Protection’
 - [https://www.dailywire.com/news/hamas-official-we-kidnapped-foreign-nationals-for-their-own-protection](https://www.dailywire.com/news/hamas-official-we-kidnapped-foreign-nationals-for-their-own-protection)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-11-27T17:53:02+00:00

Hamas official Hisham Qasem spouted a new propaganda talking point for the terrorist group this week, claiming that Hamas terrorists had kidnapped Thai nationals &#8220;for their own protection&#8221; during their October 7 attack on Israel. Qasem&#8217;s remarks come after Hamas terrorists murdered 39 Thai nationals during their attack and took an unknown number hostage. Qasem ...

## ‘Blood On Her Hands’: The Growing List Of Katy Perry’s Egregious Actions
 - [https://www.dailywire.com/news/blood-on-her-hands-the-growing-list-of-katy-perrys-egregious-actions](https://www.dailywire.com/news/blood-on-her-hands-the-growing-list-of-katy-perrys-egregious-actions)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-11-27T17:52:59+00:00

Pop star Katy Perry has received some negative attention (not enough) for her disturbing battle with elderly nuns over a property, a former convent, in Los Angeles. But Perry’s suspect actions don’t come close to ending there. Here’s a list of five jarring moves from the sometimes-malfunctioning 39-year-old “Teenage Dream” singer: ‘Blood On Her Hands’  ...

## ‘We Will Expose The Hamas Lie Of Inflated Civilian Casualties’: IDF Spokesman
 - [https://www.dailywire.com/news/we-will-expose-the-hamas-lie-of-inflated-civilian-casualties-idf-spokesman](https://www.dailywire.com/news/we-will-expose-the-hamas-lie-of-inflated-civilian-casualties-idf-spokesman)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-11-27T17:26:32+00:00

Asked about the extraordinarily high casualty numbers claimed by Hamas as Israel has conducted its war effort against the terrorist group. Israel Defense Forces spokesman Lieutenant Colonel Jonathan Conricus asserted that the numbers given by Palestinian sources were exaggerated. “We will expose the Hamas lie of inflated civilian casualties in Gaza, just like we have ...

## Ozzy Osbourne Gives Health Update: ‘At Best, I’ve Got 10 Years Left’
 - [https://www.dailywire.com/news/ozzy-osbourne-gives-health-update-at-best-ive-got-10-years-left](https://www.dailywire.com/news/ozzy-osbourne-gives-health-update-at-best-ive-got-10-years-left)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-11-27T17:20:35+00:00

Rock and roll singer Ozzy Osbourne recently gave an update about his health status, saying he’d like to perform in concert at least one more time. The 74-year-old British musician was diagnosed with Parkinson’s disease, a progressive disorder which affects the nervous system, in 2003. He discussed his feelings about his public image during an ...

## Faith Leaders Urge Congress To ‘Fund Israel’s Defenses As Soon As Possible’
 - [https://www.dailywire.com/news/faith-leaders-urge-congress-to-fund-israels-defenses-as-soon-as-possible](https://www.dailywire.com/news/faith-leaders-urge-congress-to-fund-israels-defenses-as-soon-as-possible)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-11-27T17:19:30+00:00

A coalition of religious leaders is pushing Congress to pass financial support for Israel’s war on Hamas as well as take steps to combat anti-Semitism. Fifteen leaders of religious organizations and institutions signed a letter sent to Democratic and Republican Congressional leaders on Monday urging legislators to step up support for Israel and the Jewish ...

## Christian School That Protested Trans-Identifying Student Sues State
 - [https://www.dailywire.com/news/christian-school-that-protested-trans-identifying-student-sues-state](https://www.dailywire.com/news/christian-school-that-protested-trans-identifying-student-sues-state)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-11-27T17:12:07+00:00

A Vermont Christian school that pulled out of a basketball game over a trans-identifying male player is suing the state for barring it from state tournaments as well as a state tuition program. Mid Vermont Christian School in Hartford filed a federal lawsuit against the state in Burlington on Tuesday, alleging that the Vermont Agency ...

## WATCH: Police Officer Brutally Beaten In New York City School
 - [https://www.dailywire.com/news/watch-police-officer-brutally-beaten-in-new-york-city-school](https://www.dailywire.com/news/watch-police-officer-brutally-beaten-in-new-york-city-school)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-11-27T16:30:07+00:00

A New York City Council member shared a leaked video on social media Sunday night that showed multiple students beating a police officer at Hillcrest High School. Councilwoman Vickie Paladino, a Republican, shared the video on X after a source in the city&#8217;s Department of Education gave her the video. The release of the video ...

## ‘How Can You Compare My 12-Year-Old Face?’: Kylie Jenner Shuts Down Plastic Surgery Rumors
 - [https://www.dailywire.com/news/how-can-you-compare-my-12-year-old-face-kylie-jenner-shuts-down-plastic-surgery-rumors](https://www.dailywire.com/news/how-can-you-compare-my-12-year-old-face-kylie-jenner-shuts-down-plastic-surgery-rumors)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-11-27T15:57:35+00:00

Kylie Jenner shut down plastic surgery rumors and asked how people could compare the face she had when she was 12 years old to the one she has now. In a cover story for Interview magazine, actress Jennifer Lawrence and the 26-year-old reality TV star talked about being accused of having work done to change ...

## Speaker Johnson Says He Spoke To Santos ‘About His Options’ As Expulsion Looms
 - [https://www.dailywire.com/news/speaker-johnson-says-he-spoke-to-santos-about-his-options-as-expulsion-looms](https://www.dailywire.com/news/speaker-johnson-says-he-spoke-to-santos-about-his-options-as-expulsion-looms)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-11-27T15:46:40+00:00

Speaker Mike Johnson (R-LA) shared on Monday that he has been in contact with Rep. George Santos (R-NY) ahead of a possible expulsion vote following a scathing House Ethics Committee report. Speaking to reporters during a trip to Sarasota, Florida, Johnson noted that he had &#8220;spoken to Congressman Santos at some length over the holiday ...

## Derek Chauvin’s Family Updated After Prison Stabbing: Report
 - [https://www.dailywire.com/news/derek-chauvins-family-updated-after-prison-stabbing-report](https://www.dailywire.com/news/derek-chauvins-family-updated-after-prison-stabbing-report)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-11-27T15:41:07+00:00

The mother of former Minneapolis police officer Derek Chauvin said federal authorities updated her about her son’s condition on Monday, three days after another inmate stabbed him in prison. Chauvin, who is currently serving a 20-plus year sentence for second-degree murder in connection with the death of George Floyd, was stabbed at Federal Correctional Institution, ...

## Elle Macpherson Opens Up About Getting Sober After Celebrating Major Milestone
 - [https://www.dailywire.com/news/elle-macpherson-opens-up-about-getting-sober-after-celebrating-major-milestone](https://www.dailywire.com/news/elle-macpherson-opens-up-about-getting-sober-after-celebrating-major-milestone)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-11-27T15:34:13+00:00

Elle Macpherson recently opened up about her decision to get sober twenty years ago. During a wide-ranging interview for Body+Soul magazine, the 59-year-old supermodel said that before she celebrated her 40th birthday, she realized she had an alcohol problem. &#8220;I stopped drinking in 2003 because I felt I couldn&#8217;t be fully present in my life ...

## Border Patrol Chiefs Say ‘Unprecedented’ Number Of Illegal Immigrants Entering U.S.
 - [https://www.dailywire.com/news/border-patrol-chiefs-say-unprecedented-number-of-illegal-immigrants-entering-u-s](https://www.dailywire.com/news/border-patrol-chiefs-say-unprecedented-number-of-illegal-immigrants-entering-u-s)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-11-27T15:26:47+00:00

Border Patrol chiefs told lawmakers that they are seeing an historic number of illegal immigrants released into the U.S. as encounters reach record highs, according to interviews released on Sunday. Transcripts of depositions with sector chiefs were released by the House Homeland Security Committee that show the drastic influx of illegal migrants under President Joe ...

## Will Israel’s Hostage Deal Help Hamas?
 - [https://www.dailywire.com/news/will-israels-hostage-deal-help-hamas](https://www.dailywire.com/news/will-israels-hostage-deal-help-hamas)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-11-27T15:22:29+00:00

This weekend, Hamas released some of the 240 hostages the terror group took during their mass killing spree on October 7: 13 Israeli hostages the first day, Friday; 13 more hostages on Saturday; and 17 hostages on Sunday, bringing the current total to 43 hostages. Under the current break in operations, Hamas is set to ...

## John Travolta Remembers Near-Death Experience While Flying Plane: ‘I Thought It Was Over’
 - [https://www.dailywire.com/news/john-travolta-remembers-near-death-experience-while-flying-plane-i-thought-it-was-over](https://www.dailywire.com/news/john-travolta-remembers-near-death-experience-while-flying-plane-i-thought-it-was-over)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-11-27T15:02:10+00:00

Actor John Travolta recalled a near-death experience he had while piloting a plane in 1992. The 69-year-old recently discussed what happened while attending the London premiere of the Disney+ short film “The Shepherd.” In the movie, a pilot loses electrical control of the plane he’s flying. &#8220;I actually experienced a total electrical failure, not in ...

## NYC Library Vandalized By Pro-Palestinian Protesters Needs $75,000 Clean-Up Amid Migrant Budget Cuts
 - [https://www.dailywire.com/news/nyc-library-vandalized-by-pro-palestinian-protesters-needs-75000-clean-up-amid-migrant-budget-cuts](https://www.dailywire.com/news/nyc-library-vandalized-by-pro-palestinian-protesters-needs-75000-clean-up-amid-migrant-budget-cuts)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-11-27T14:39:32+00:00

Pro-Palestinian protesters vandalized New York City&#8217;s flagship public library in Manhattan on Thanksgiving, and the clean-up process could cost up to $75,000. The enormous building on Fifth Avenue and 42nd Street, known for its iconic lion statues out front, was defaced with red handprints, stickers, and green spray paint during at least three separate protests ...

## Biden Should Push Qatar To Arrest Hamas Leadership Over Hostage Crisis, GOP Senator Says
 - [https://www.dailywire.com/news/biden-should-push-qatar-to-arrest-hamas-leadership-over-hostage-crisis-gop-senator-says](https://www.dailywire.com/news/biden-should-push-qatar-to-arrest-hamas-leadership-over-hostage-crisis-gop-senator-says)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-11-27T14:16:29+00:00

The United States should aggressively push Qatar to imprison Hamas leaders for the hundreds of hostages the terror group is holding in Gaza, according to GOP Sen. Mike Lee of Utah. Top Hamas leaders are currently granted safe haven in Qatar’s capital city of Doha, from which Hamas makes many of its most significant decisions. ...

## ‘It’s War’: Jon Lovitz Shuts Down Critics Of His Support For Israel
 - [https://www.dailywire.com/news/its-war-jon-lovitz-shuts-down-critics-of-his-support-for-israel](https://www.dailywire.com/news/its-war-jon-lovitz-shuts-down-critics-of-his-support-for-israel)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-11-27T14:15:34+00:00

Jon Lovitz shut down critics who slammed him as a supporter of &#8220;genocide&#8221; for his defense of Israel following the Hamas terrorist attacks that resulted in the deaths of more than 1,400 people. The 66-year-old actor-comedian took to X on Monday and hit back at one follower who wrote that he liked Lovitz but, &#8220;You ...

## Family Of Taylor Swift Fan Who Died After Her Show Attends Singer’s Final Brazil Performance
 - [https://www.dailywire.com/news/family-of-taylor-swift-fan-who-died-after-her-show-attends-singers-final-brazil-performance](https://www.dailywire.com/news/family-of-taylor-swift-fan-who-died-after-her-show-attends-singers-final-brazil-performance)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-11-27T13:16:51+00:00

The family of the Taylor Swift fan who died at an Eras Tour show in Rio de Janeiro earlier this month attended the singer’s show on Sunday. Ana Clara Benevides Machado’s family and friends were invited to Swift’s final Brazil performance, per People. A photo of them posing with the singer was posted on multiple fan ...

## ‘It Is Poison’: Ted Cruz Blasts NSA Over Woke Diversity Glossary Uncovered By Daily Wire
 - [https://www.dailywire.com/news/it-is-poison-ted-cruz-blasts-nsa-over-woke-diversity-glossary-uncovered-by-daily-wire](https://www.dailywire.com/news/it-is-poison-ted-cruz-blasts-nsa-over-woke-diversity-glossary-uncovered-by-daily-wire)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-11-27T13:00:28+00:00

Senator Ted Cruz (R-TX) blasted the National Security Agency (NSA) on Monday in response to a Daily Wire investigation that revealed the agency created a woke diversity, equity, and inclusion glossary that pushes Critical Race Theory and radical gender ideology. The glossary, first uncovered in an exclusive investigation from The Daily Wire, blames “white Europeans” for ...

## Widow Of Serial Killer Charged With Aiding In Kidnappings And Murders
 - [https://www.dailywire.com/news/widow-of-serial-killer-charged-with-aiding-in-kidnappings-and-murders](https://www.dailywire.com/news/widow-of-serial-killer-charged-with-aiding-in-kidnappings-and-murders)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-11-27T12:50:35+00:00

The widow of a French serial killer who was previously convicted of helping her husband kidnap and murder virgins has been charged in her alleged role in three additional murders. Monique Olivier, wife of serial killer Michel Fourniret, will face trial over charges of aiding and abetting the kidnapping and murder of three young women ...

## Elon Musk Tours Kibbutz Massacred On October 7: ‘Jarring To See The Scene’
 - [https://www.dailywire.com/news/elon-musk-tours-kibbutz-massacred-on-october-7-jarring-to-see-the-scene](https://www.dailywire.com/news/elon-musk-tours-kibbutz-massacred-on-october-7-jarring-to-see-the-scene)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-11-27T12:49:43+00:00

Elon Musk visited a kibbutz in southern Israel on Monday alongside Israel&#8217;s Prime Minister Benjamin Netanyahu to witness firsthand the violence inflicted by Hamas terrorists against civilians on October 7. Sporting a protective bulletproof vest, Musk viewed the burnt and destroyed homes in the kibbutz near the Gaza border, where more than 50 people were ...

## Indiana Man Charged With Leaking Evidence Related To Delphi Murder Trial
 - [https://www.dailywire.com/news/indiana-man-charged-with-leaking-evidence-related-to-delphi-murder-trial](https://www.dailywire.com/news/indiana-man-charged-with-leaking-evidence-related-to-delphi-murder-trial)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-11-27T12:37:53+00:00

An Indiana man has been charged with leaking evidence related to the high-profile murder of two Delphi teenagers. Mitchell Westerman, 41, has been charged with one count of conversion after admitting that he took pictures of crime scene evidence related to the 2017 murders of 13-year-old Abby Williams and 14-year-old Libby German, WSBT reported. Westerman ...

## DailyWire+ Drops Trailer For ‘The Most Triggering Comedy Of The Year’ Mocking Men In Women’s Sports
 - [https://www.dailywire.com/news/dailywire-drops-trailer-for-the-most-triggering-comedy-of-the-year-mocking-men-in-womens-sports](https://www.dailywire.com/news/dailywire-drops-trailer-for-the-most-triggering-comedy-of-the-year-mocking-men-in-womens-sports)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-11-27T12:24:23+00:00

The Daily Wire released the trailer for its first-ever feature-length comedy “Lady Ballers” on Monday, a movie that mocks the recent and controversial phenomenon of men competing in women’s sports.  “Lady Ballers,” a DailyWire+ original, is directed by the company’s co-founder Jeremy Boreing, who also stars in the film alongside Daily Wire sports show “Crain ...

## Why The Loudest Anti-Israel Voices Are Also The Loudest ‘Green New Deal’ Voices
 - [https://www.dailywire.com/news/why-the-loudest-anti-israel-voices-are-also-the-loudest-green-new-deal-voices](https://www.dailywire.com/news/why-the-loudest-anti-israel-voices-are-also-the-loudest-green-new-deal-voices)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-11-27T12:17:47+00:00

It should come as no surprise to witness the very same people calling for a Green New Deal and the energy disarming of America appear to be the very same people who are proudly anti-Israel. This became even more clear as many of us were gathering with family to celebrate gratitude during Thanksgiving, because opponents ...

## Hospital At Center Of ‘Take Care Of Maya’ Lawsuits Requests New Trial, Alleges Juror Misconduct
 - [https://www.dailywire.com/news/hospital-at-center-of-take-care-of-maya-lawsuits-requests-new-trial-alleges-juror-misconduct](https://www.dailywire.com/news/hospital-at-center-of-take-care-of-maya-lawsuits-requests-new-trial-alleges-juror-misconduct)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-11-27T12:10:57+00:00

The children’s hospital that was ordered to pay a family hundreds of millions of dollars for reporting a mother for child abuse is seeking a new trial. Johns Hopkins All Children’s Hospital in St. Petersburg, Florida, was found liable in a massive medical malpractice lawsuit that was featured in the Netflix documentary “Take Care of ...

## Jeremy’s Razors Viral Ad Was Just The Beginning Of The Alternative Economy
 - [https://www.dailywire.com/news/jeremys-razors-viral-ad-was-just-the-beginning-of-the-alternative-economy](https://www.dailywire.com/news/jeremys-razors-viral-ad-was-just-the-beginning-of-the-alternative-economy)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-11-27T10:44:17+00:00

How do you change the world? Well, it turns out it can all start with a razor. For years, conservatives have complained about woke companies taking over the world. Sure, it sucks to watch it happen, but hardly anyone was doing anything about it. Typical, right? But then it all changed. The woke shaving industry ...

## Natalie Portman Says Children Shouldn’t Be Actors: ‘Kids Should Play And Go To School’
 - [https://www.dailywire.com/news/natalie-portman-says-children-shouldnt-be-actors-kids-should-play-and-go-to-school](https://www.dailywire.com/news/natalie-portman-says-children-shouldnt-be-actors-kids-should-play-and-go-to-school)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-11-27T10:25:50+00:00

Former child star Natalie Portman said she doesn’t think children should work in Hollywood, citing potential dangers as one reason why. “I would not encourage young people to go into this. I don’t mean ever; I mean as children,” Portman told Variety during a recent interview. “I feel it was almost an accident of luck ...

## Tom Cotton: Hamas ‘Contemptuous’ Of Biden
 - [https://www.dailywire.com/news/tom-cotton-hamas-contemptuous-of-biden](https://www.dailywire.com/news/tom-cotton-hamas-contemptuous-of-biden)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-11-27T09:12:36+00:00

Arkansas GOP Senator Tom Cotton ripped President Joe Biden when he discussed American hostages still held by the terrorist group Hamas, asserting that the terrorist group is simply contemptuous of Biden. Cotton appeared on Fox News with Shannon Bream, who noted Cotton’s service in the military overseas, then asked, “What do you make about this ...

## Weekend Media Wrap, Vol. 19: What You Missed If You Weren’t Glued To The Sunday Shows
 - [https://www.dailywire.com/news/weekend-media-wrap-vol-19-what-you-missed-if-you-werent-glued-to-the-sunday-shows](https://www.dailywire.com/news/weekend-media-wrap-vol-19-what-you-missed-if-you-werent-glued-to-the-sunday-shows)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-11-27T08:26:27+00:00

Every Sunday morning, legacy media outlets are taken over by elected officials, aspiring elected officials, administration insiders, and the usual collection of talking heads — all of whom are there to discuss specific policies, push talking points, or simply promote their own campaigns. For those who don&#8217;t spend their Sunday mornings glued to the television ...

