# Source:NY times technology, URL:http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml, language:en-US

## How Your Child’s Online Mistake Can Ruin Your Digital Life
 - [https://www.nytimes.com/2023/11/27/technology/google-youtube-abuse-mistake.html](https://www.nytimes.com/2023/11/27/technology/google-youtube-abuse-mistake.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-11-27T08:00:11+00:00

Google has a zero-tolerance policy for child abuse content. The scanning process can sometimes go awry and tar innocent individuals as abusers.

