# Source:Ben Shapiro, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw, language:en-US

## Conor McGregor's In Trouble
 - [https://www.youtube.com/watch?v=9gq5R7Z_yZU](https://www.youtube.com/watch?v=9gq5R7Z_yZU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-11-27T22:30:01+00:00



## Will Israel’s Hostage Deal Help Hamas?
 - [https://www.youtube.com/watch?v=pKM0B4YEJcM](https://www.youtube.com/watch?v=pKM0B4YEJcM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-11-27T22:00:31+00:00

In the wake of the hostage trade-off in the Middle East, the media are pushing the argument that Israel trading terrorists for innocent civilians means that terrorists and innocent civilians are essentially the same thing. This idea makes zero sense.

1️⃣ Click here to join the member-exclusive portion of my show: https://get.dailywireplus.com/member-block/ben-shapiro

2️⃣ Become a DailyWire+ member to gain access to movies, shows, documentaries, and more: https://bit.ly/3lfVtwK 

3️⃣ Watch the full episode here: Ep.1856 - https://youtu.be/Vx6SNYovPG8

👕 Get your Ben Shapiro merch here: https://bit.ly/3TAu2cw

#BenShapiro #TheBenShapiroShow #News #Politics #DailyWire #Israel #Hamas #Gaza #GazaStrip #Jew #Jewish #Israeli #War #MiddleEast #MiddleEasternWar

## 13 Year Old vs. Veteran Chess Player
 - [https://www.youtube.com/watch?v=pG1qEfoMPhs](https://www.youtube.com/watch?v=pG1qEfoMPhs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-11-27T20:00:19+00:00



## Why Conor McGregor Is Now Under Investigation
 - [https://www.youtube.com/watch?v=Vx6SNYovPG8](https://www.youtube.com/watch?v=Vx6SNYovPG8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-11-27T18:00:07+00:00

Irish police investigate MMA legend Conor McGregor for tweeting about open immigration; right-wing nationalist Geert Wilders triumphs in the Netherlands; and as some Israeli hostages come home, the legacy media do their damndest to throw Hamas a lifeline.

Ep.1856

- - -

1️⃣  Click here to join the member exclusive portion of my show:  https://bit.ly/41LQK62

2️⃣ LAST CHANCE to shop DailyWire+ Black Friday Deals: https://bit.ly/3QVgtGy

👕 Get your Ben Shapiro Polo here: https://bit.ly/3TAu2cw

#BenShapiro #TheBenShapiroShow #News #Politics #DailyWire

