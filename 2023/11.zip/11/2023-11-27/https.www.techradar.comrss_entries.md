# Source:Techradar, URL:https://www.techradar.com/rss, language:en-US

## This awesome SanDisk SSD Cyber Monday deal is so good, I might fly to the US to get it
 - [https://www.techradar.com/cameras/camera-accessories/this-awesome-sandisk-ssd-cyber-monday-deal-is-so-good-i-might-fly-to-the-us-to-get-it](https://www.techradar.com/cameras/camera-accessories/this-awesome-sandisk-ssd-cyber-monday-deal-is-so-good-i-might-fly-to-the-us-to-get-it)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T22:50:17+00:00

Start spreading the news, I'm leaving today

## At under $40, this is probably the cheapest office desk deal worth buying on Cyber Monday
 - [https://www.techradar.com/pro/at-under-dollar40-this-is-probably-the-cheapest-office-desk-deal-worth-buying-on-cyber-monday](https://www.techradar.com/pro/at-under-dollar40-this-is-probably-the-cheapest-office-desk-deal-worth-buying-on-cyber-monday)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T22:50:06+00:00

Probably the cheapest office desk deal we can find this Cyber Monday.

## These are my 5 favorite Cyber Monday Bluetooth speaker deals for under $100
 - [https://www.techradar.com/audio/wireless-headphones/these-are-my-5-favorite-cyber-monday-bluetooth-speaker-deals-for-under-dollar100](https://www.techradar.com/audio/wireless-headphones/these-are-my-5-favorite-cyber-monday-bluetooth-speaker-deals-for-under-dollar100)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T22:48:58+00:00

Looking for a Cyber Monday Bluetooth speaker deal for under $100? Here are our top five picks.

## The 6 best Cyber Monday TV deals for PS5 and Xbox Series X owners
 - [https://www.techradar.com/seasonal-sales/the-6-best-cyber-monday-tv-deals-for-ps5-and-xbox-series-x-owners](https://www.techradar.com/seasonal-sales/the-6-best-cyber-monday-tv-deals-for-ps5-and-xbox-series-x-owners)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T22:38:57+00:00

Own a PS5 or Xbox Series X? These TVs will take your gaming to the next level, and they're all on sale for Cyber Monday.

## Cyber Monday is almost done, so these rock bottom Cyber Monday MacBook deals won't last forever
 - [https://www.techradar.com/seasonal-sales/cyber-monday-is-almost-done-so-these-rock-bottom-cyber-monday-macbook-deals-wont-last-forever](https://www.techradar.com/seasonal-sales/cyber-monday-is-almost-done-so-these-rock-bottom-cyber-monday-macbook-deals-wont-last-forever)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T22:37:19+00:00

These Apple Cyber Monday MacBook deals are some of the best you'll find all year, but you don't have much longer to grab yours.

## This is one office chair deal for Cyber Monday that will make work a bit more comfortable
 - [https://www.techradar.com/pro/this-is-one-office-chair-deal-for-cyber-monday-that-will-make-work-a-bit-more-comfortable](https://www.techradar.com/pro/this-is-one-office-chair-deal-for-cyber-monday-that-will-make-work-a-bit-more-comfortable)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T22:33:17+00:00

A comfortable Cyber Monday deal on the Nouhaus Ergo3D office chair

## This Lego 'Up' House deal is so good I could cry – and I will, while building it
 - [https://www.techradar.com/seasonal-sales/this-lego-up-house-deal-is-so-good-i-could-cry-and-i-will-while-building-it](https://www.techradar.com/seasonal-sales/this-lego-up-house-deal-is-so-good-i-could-cry-and-i-will-while-building-it)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T22:19:30+00:00

Make sure you also buy some tissues if you're planning on building this Pixar-themed Lego set – you'll need them.

## If you didn't buy AirPods Pro 2 you failed Cyber Monday – and I'm giving you one last chance
 - [https://www.techradar.com/audio/earbuds-airpods/if-you-didnt-buy-airpods-pro-2-you-failed-cyber-monday-and-im-giving-you-one-last-chance](https://www.techradar.com/audio/earbuds-airpods/if-you-didnt-buy-airpods-pro-2-you-failed-cyber-monday-and-im-giving-you-one-last-chance)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T22:13:43+00:00

Get this deal on the best wireless earbuds for iPhone users before they sell out – or before Cyber Monday is over for another year.

## Want a cheap air fryer? You can't beat these Cyber Monday deals under $100
 - [https://www.techradar.com/home/air-fryers/want-a-cheap-air-fryer-you-cant-beat-these-cyber-monday-deals-under-dollar100](https://www.techradar.com/home/air-fryers/want-a-cheap-air-fryer-you-cant-beat-these-cyber-monday-deals-under-dollar100)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T21:57:17+00:00

These Cyber Monday Air Fryer deals net you a handy kitchen gadget at a fraction of its normal price.

## Mint Mobile Cyber Monday: get three months free or a Google Pixel 7 Pro for $299
 - [https://www.techradar.com/seasonal-sales/mint-mobile-cyber-monday-get-three-months-free-or-a-google-pixel-7-pro-for-dollar299](https://www.techradar.com/seasonal-sales/mint-mobile-cyber-monday-get-three-months-free-or-a-google-pixel-7-pro-for-dollar299)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T21:38:19+00:00

Mint Mobile has superb deals for Cyber Monday - covering both plans and devices.

## Own Barbie and Oppenheimer forever with these almost-record-low Blu-Ray deals
 - [https://www.techradar.com/streaming/own-barbie-and-oppenheimer-forever-with-these-almost-record-low-blu-ray-deals](https://www.techradar.com/streaming/own-barbie-and-oppenheimer-forever-with-these-almost-record-low-blu-ray-deals)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T21:21:09+00:00

Pick up physical copies of Oppenheimer and Barbie for less with these Cyber Monday Blu-Ray deals.

## 17 Cyber Monday Apple deals worth buying: AirPods, Apple Watch, iPads and MacBooks
 - [https://www.techradar.com/seasonal-sales/17-cyber-monday-apple-deals-worth-buying-airpods-apple-watch-ipads-and-macbooks](https://www.techradar.com/seasonal-sales/17-cyber-monday-apple-deals-worth-buying-airpods-apple-watch-ipads-and-macbooks)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T21:18:35+00:00

I'm rounding up the 17 Cyber Monday Apple deals worth buying, with record-low prices on AirPods, the Apple Watch, iPads, and MacBooks.

## Hurry! Get these Cyber Monday DJI drone deals (or this Potensic) before they fly off the shelves
 - [https://www.techradar.com/cameras/drones/hurry-get-these-cyber-monday-dji-drone-deals-or-this-potensic-before-they-fly-off-the-shelves](https://www.techradar.com/cameras/drones/hurry-get-these-cyber-monday-dji-drone-deals-or-this-potensic-before-they-fly-off-the-shelves)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T20:35:53+00:00

Handpicked DJI Cyber Monday 2023 deals for you and a surprising alternative

## Score the best Cyber Monday price on the Dell XPS 13, our favorite Windows laptop of 2023
 - [https://www.techradar.com/computing/printers-scanners/score-the-best-cyber-monday-price-on-the-dell-xps-13-our-favorite-windows-laptop-of-2023](https://www.techradar.com/computing/printers-scanners/score-the-best-cyber-monday-price-on-the-dell-xps-13-our-favorite-windows-laptop-of-2023)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T20:20:21+00:00

Discover unmatched Cyber Monday savings on our favorite Windows laptop, featuring top-line specs, customization options, and a festive year-end discount.

## If this robot vacuum gets any cheaper, Amazon will practically be giving it away
 - [https://www.techradar.com/home/robot-vacuums/if-this-robot-vacuum-gets-any-cheaper-amazon-will-practically-be-giving-it-away](https://www.techradar.com/home/robot-vacuums/if-this-robot-vacuum-gets-any-cheaper-amazon-will-practically-be-giving-it-away)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T20:18:20+00:00

One of Amazon's best-selling iRobot Roomba robot vacuums is almost half-price right now

## OLED TVs too dark for you? Check out these 6 Cyber Monday deals on super-bright mini-LED TVs
 - [https://www.techradar.com/televisions/oled-tvs-too-dark-for-you-check-out-these-6-cyber-monday-deals-on-super-bright-mini-led-tvs](https://www.techradar.com/televisions/oled-tvs-too-dark-for-you-check-out-these-6-cyber-monday-deals-on-super-bright-mini-led-tvs)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T19:55:24+00:00

Watch TV in a bright room? A super bright mini-LED TV may be the answer over an OLED TV. Here are six Cyber Monday deals to check out.

## This Bose QuietComfort II Cyber Monday deal will have you forgetting all about the AirPods sale
 - [https://www.techradar.com/audio/earbuds-airpods/this-bose-quietcomfort-ii-cyber-monday-deal-will-have-you-forgetting-all-about-the-airpods-sale](https://www.techradar.com/audio/earbuds-airpods/this-bose-quietcomfort-ii-cyber-monday-deal-will-have-you-forgetting-all-about-the-airpods-sale)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T19:38:36+00:00

Not only are the Bose QuietComfort II earbuds discounted by 30%, but you can also find the new QuietComfort Ultras reduced by 17%.

## Forget OLED TVs – I review projectors and these 10 Cyber Monday deals are serious upgrades
 - [https://www.techradar.com/seasonal-sales/forget-oled-tvs-i-review-projectors-and-these-10-cyber-monday-deals-are-serious-upgrades](https://www.techradar.com/seasonal-sales/forget-oled-tvs-i-review-projectors-and-these-10-cyber-monday-deals-are-serious-upgrades)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T19:28:08+00:00

If you're shopping for a big TV on Cyber Monday, a projector will deliver an even bigger bang for your home theater buck.

## Over $300 off one of the best battery life iPhones this Cyber Monday
 - [https://www.techradar.com/phones/over-dollar300-off-one-of-the-best-battery-life-iphones-this-cyber-monday](https://www.techradar.com/phones/over-dollar300-off-one-of-the-best-battery-life-iphones-this-cyber-monday)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T19:14:50+00:00

The iPhone 14 Plus has some of the best battery life out there and right now, this Amazon discount.

## I reviewed the Samsung Galaxy S22 Ultra, and I can't believe this Cyber Monday deal
 - [https://www.techradar.com/seasonal-sales/i-reviewed-the-samsung-galaxy-s22-ultra-and-i-cant-believe-this-cyber-monday-deal](https://www.techradar.com/seasonal-sales/i-reviewed-the-samsung-galaxy-s22-ultra-and-i-cant-believe-this-cyber-monday-deal)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T19:06:52+00:00

The Samsung Galaxy S22 Ultra is at its lowest price yet in this Cyber Monday deal at Best Buy.

## Grab these Surfshark Cyber Monday deals before it’s too late
 - [https://www.techradar.com/vpn/grab-these-surfshark-cyber-monday-2023-deals-before-its-too-late](https://www.techradar.com/vpn/grab-these-surfshark-cyber-monday-2023-deals-before-its-too-late)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T18:56:03+00:00

There’s only 1 week left to claim this awesome Surfshark Cyber Monday deal, and get a 2-year plan for just $1.99 a month. Here’s everything you need to know:

## The 27 best Cyber Monday TV deals to shop before they're gone - save over $1,000
 - [https://www.techradar.com/televisions/the-27-best-cyber-monday-tv-deals-to-shop-before-theyre-gone-save-over-dollar1000](https://www.techradar.com/televisions/the-27-best-cyber-monday-tv-deals-to-shop-before-theyre-gone-save-over-dollar1000)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T18:51:29+00:00

Cyber Monday TV deals are ending soon, and I'm rounding up the 27 best offers with over $1,000 in savings on 4K, QLED, and OLED displays.

## Boom! This Cyber Monday GoPro deal is even better than its Black Friday equivalent
 - [https://www.techradar.com/phones/phone-accessories/boom-this-cyber-monday-gopro-deal-is-even-better-than-its-black-friday-equivalent](https://www.techradar.com/phones/phone-accessories/boom-this-cyber-monday-gopro-deal-is-even-better-than-its-black-friday-equivalent)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T18:24:24+00:00

Amazon has further discounted the still-excellent GoPro Hero 10 Black in the US.

## The Force is strong with these Cyber Monday Lego Star Wars deals
 - [https://www.techradar.com/tech/the-force-is-strong-with-these-cyber-monday-lego-star-wars-deals](https://www.techradar.com/tech/the-force-is-strong-with-these-cyber-monday-lego-star-wars-deals)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T18:24:04+00:00

Cyber Monday Lego deals are here and there are still some massive savings to be had on Star Wars sets in the US and UK.

## Hacker claims to have hit General Electric and stolen company data
 - [https://www.techradar.com/pro/security/hacker-claims-to-have-hit-general-electric-and-stolen-data](https://www.techradar.com/pro/security/hacker-claims-to-have-hit-general-electric-and-stolen-data)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T18:07:02+00:00

General Electric attackers first tried to sell network access, and later expanded it with alleged data.

## Dyson has cleaned the floor with Shark in this year's Cyber Monday vacuum deals
 - [https://www.techradar.com/home/small-appliances/dyson-has-cleaned-the-floor-with-shark-in-this-years-cyber-monday-vacuum-deals](https://www.techradar.com/home/small-appliances/dyson-has-cleaned-the-floor-with-shark-in-this-years-cyber-monday-vacuum-deals)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T18:05:35+00:00

While Shark offered some great savings this weekend, my verdict is in: Dyson absolutely thrashed Shark in terms of record-low prices and big discounts.

## AWS reveals a new pocket-sized PC that is strictly for business
 - [https://www.techradar.com/pro/aws-reveals-a-new-pocket-sized-pc-that-is-strictly-for-business](https://www.techradar.com/pro/aws-reveals-a-new-pocket-sized-pc-that-is-strictly-for-business)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T17:16:34+00:00

AWS unveils a space-saving enterprise thin client PC that's perfect for your home office.

## 11 Kindle Cyber Monday deals that are actually worth buying before it's too late
 - [https://www.techradar.com/tablets/ereaders/kindle-cyber-monday-deals](https://www.techradar.com/tablets/ereaders/kindle-cyber-monday-deals)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T17:07:57+00:00

The Cyber Monday deals are in full swing so now's the time go grab a Kindle for a discount price.

## The brilliant Canon EOS R5 for under $3,000 is my pick of the Cyber Monday camera deals
 - [https://www.techradar.com/cameras/mirrorless-cameras/the-brilliant-canon-eos-r5-for-under-dollar3000-is-my-pick-of-the-cyber-monday-camera-deals](https://www.techradar.com/cameras/mirrorless-cameras/the-brilliant-canon-eos-r5-for-under-dollar3000-is-my-pick-of-the-cyber-monday-camera-deals)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T17:01:15+00:00

Canon’s best ever-camera for photography is at a record-low price for Cyber Monday at B&amp;H Photo.

## Still looking for a Cyber Monday coffee machine deal? These Keurig deals might be your last chance
 - [https://www.techradar.com/home/coffee-machines/still-looking-for-a-cyber-monday-coffee-machine-deal-these-keurig-deals-might-be-your-last-chance](https://www.techradar.com/home/coffee-machines/still-looking-for-a-cyber-monday-coffee-machine-deal-these-keurig-deals-might-be-your-last-chance)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T16:54:14+00:00

If a coffee machine is on your Cyber Monday shopping list, look no further than Keurig's fantastic sale.

## Astarion fans rejoice - Baldur’s Gate 3 patch 5 will let you kiss your favorite vampire properly again
 - [https://www.techradar.com/gaming/consoles-pc/astarion-fans-rejoice-baldurs-gate-3-patch-5-will-let-you-kiss-your-favorite-vampire-properly-again](https://www.techradar.com/gaming/consoles-pc/astarion-fans-rejoice-baldurs-gate-3-patch-5-will-let-you-kiss-your-favorite-vampire-properly-again)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T16:53:50+00:00

Larian Studios has confirmed that it's aiming to release Baldur's Gate 3 Patch 5 this week, with a fix for Astarion's broken kisses.

## Cyber Monday only! Get one of the best unlimited plans for just $35 per month
 - [https://www.techradar.com/seasonal-sales/cyber-monday-only-get-one-of-the-best-unlimited-plans-for-just-dollar35-per-month](https://www.techradar.com/seasonal-sales/cyber-monday-only-get-one-of-the-best-unlimited-plans-for-just-dollar35-per-month)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T16:53:34+00:00

Visible Wireless is offering its best deal all year for Cyber Monday - get the Visible Plus plan for just $35 per month.

## I'm on a tight budget, what should I look for in a mattress this Cyber Monday?
 - [https://www.techradar.com/health-fitness/mattresses/im-on-a-tight-budget-what-should-i-look-for-in-a-mattress-this-cyber-monday](https://www.techradar.com/health-fitness/mattresses/im-on-a-tight-budget-what-should-i-look-for-in-a-mattress-this-cyber-monday)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T16:29:00+00:00

Get a budget bed that's worth the money with these buying tips.

## Some Google Drive users are reporting losing six months of files
 - [https://www.techradar.com/computing/cloud-computing/some-google-drive-users-are-reporting-losing-six-months-of-files](https://www.techradar.com/computing/cloud-computing/some-google-drive-users-are-reporting-losing-six-months-of-files)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T16:23:38+00:00

If your Google Drive suddenly reverts to a state from months ago, with recent files vanishing, you’re not alone.

## Time is running out to get this exclusive NordVPN Cyber Monday deal
 - [https://www.techradar.com/vpn/time-is-running-out-to-get-this-exclusive-nordvpn-cyber-monday-2023-deal](https://www.techradar.com/vpn/time-is-running-out-to-get-this-exclusive-nordvpn-cyber-monday-2023-deal)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T16:21:32+00:00

It’s almost a wrap on Cyber Monday, but you haven’t missed your chance to claim one of the biggest deals of the year. Save 69% on NordVPN—and get a free Amazon gift card.

## NameDrop in iOS 17 doesn’t have to be a privacy nightmare – here’s how to control it
 - [https://www.techradar.com/phones/ios/namedrop-in-ios-17-doesnt-have-to-be-a-privacy-nightmare-heres-how-to-control-it](https://www.techradar.com/phones/ios/namedrop-in-ios-17-doesnt-have-to-be-a-privacy-nightmare-heres-how-to-control-it)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T16:16:45+00:00

iOS 17 NameDrop lets you quickly share contact info with very nearby iPhones – just be sure to use it smartly and safely

## Looking to build a new gaming PC? Here's the best computer you can assemble using only Cyber Monday deals
 - [https://www.techradar.com/computing/computing-components/looking-to-build-a-new-gaming-pc-heres-the-best-computer-you-can-assemble-using-only-cyber-monday-deals](https://www.techradar.com/computing/computing-components/looking-to-build-a-new-gaming-pc-heres-the-best-computer-you-can-assemble-using-only-cyber-monday-deals)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T16:16:12+00:00

Cyber Monday has plenty of deals on PC components, and this is the best gaming rig you can build with them.

## 5 amazing Cyber Monday 65-inch TV deals you won't want to miss, starting from just $349
 - [https://www.techradar.com/televisions/5-amazing-cyber-monday-65-inch-tv-deals-you-wont-want-to-miss-starting-from-just-dollar349](https://www.techradar.com/televisions/5-amazing-cyber-monday-65-inch-tv-deals-you-wont-want-to-miss-starting-from-just-dollar349)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T16:15:57+00:00

A 65-inch TV for just $349? Here are five of the best Cyber Monday deals we've found so far.

## North Korean hackers are carrying out even more cyberattacks than previously thought
 - [https://www.techradar.com/pro/security/north-korean-hackers-are-carrying-out-even-more-cyberattacks-than-previously-thought](https://www.techradar.com/pro/security/north-korean-hackers-are-carrying-out-even-more-cyberattacks-than-previously-thought)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T16:05:25+00:00

Three separate campaigns were spotted in the last few months alone, with most being supply chain attacks.

## I review TVs for a living and these are the 8 best Cyber Monday TV deals I've seen
 - [https://www.techradar.com/televisions/i-review-tvs-for-a-living-and-these-are-the-8-best-cyber-monday-tv-deals-ive-seen](https://www.techradar.com/televisions/i-review-tvs-for-a-living-and-these-are-the-8-best-cyber-monday-tv-deals-ive-seen)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T15:48:32+00:00

After searching through hundreds of deals this Cyber Monday, these are the eight best, as a TV reviewer, I can find so far.

## The Game Awards will have tighter security this year following 2022 stage invasion
 - [https://www.techradar.com/gaming/the-game-awards-will-have-tighter-security-this-year-following-2022s-stage-crashing](https://www.techradar.com/gaming/the-game-awards-will-have-tighter-security-this-year-following-2022s-stage-crashing)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T15:43:51+00:00

The Game Awards host Geoff Keighley says new security measures are being implemented to keep everyone safe.

## Geoff Keighley says Best Independent Game is ‘a really complicated’ category to define
 - [https://www.techradar.com/gaming/geoff-keighley-says-best-independent-game-is-a-really-complicated-category-to-define](https://www.techradar.com/gaming/geoff-keighley-says-best-independent-game-is-a-really-complicated-category-to-define)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T15:41:32+00:00

The Game Awards host Geoff Keighley says that Best Independent Game is a "really complicated" category to give strict rules to.

## The reports of on-prem’s death are greatly exaggerated
 - [https://www.techradar.com/pro/the-reports-of-on-prems-death-are-greatly-exaggerated](https://www.techradar.com/pro/the-reports-of-on-prems-death-are-greatly-exaggerated)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T15:31:03+00:00

Calvin Hsu, VP at Citrix discusses the importance of a hybrid balance between on-premises and cloud computing.

## Long recovery times after cyberattacks could annihilate your organization
 - [https://www.techradar.com/pro/long-recovery-times-after-cyberattacks-could-annihilate-your-organization](https://www.techradar.com/pro/long-recovery-times-after-cyberattacks-could-annihilate-your-organization)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T15:28:03+00:00

The average organization spends only 12% of its IT budget on cybersecurity. They're still getting attacked.

## Don’t waste your money – these are the only Cyber Monday laptop deals you need to buy
 - [https://www.techradar.com/computing/macbooks/dont-waste-your-money-these-are-the-only-cyber-monday-laptop-deals-you-need-to-buy](https://www.techradar.com/computing/macbooks/dont-waste-your-money-these-are-the-only-cyber-monday-laptop-deals-you-need-to-buy)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T15:19:43+00:00

Cyber Monday is the only time you should buy a laptop – and these deals show why.

## Many of the world's biggest tech firms are majorly falling behind on emissions
 - [https://www.techradar.com/pro/many-of-the-worlds-biggest-tech-firms-are-majorly-falling-behind-on-emissions](https://www.techradar.com/pro/many-of-the-worlds-biggest-tech-firms-are-majorly-falling-behind-on-emissions)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T15:00:01+00:00

Greenpeace report claims tech giants are struggling to meet emissions targets, but it’s not all black and white.

## Forget charging EV batteries – this video shows how fast Nio's battery-swap tech is
 - [https://www.techradar.com/vehicle-tech/hybrid-electric-vehicles/forget-charging-ev-batteries-this-video-shows-how-fast-nios-battery-swap-tech-is](https://www.techradar.com/vehicle-tech/hybrid-electric-vehicles/forget-charging-ev-batteries-this-video-shows-how-fast-nios-battery-swap-tech-is)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T14:59:37+00:00

Video surfaces revealing how quick and easy it is to use a battery swap station from Chinese EV maker Nio.

## Gulf Air hit with data breach, customer data possibly affected
 - [https://www.techradar.com/pro/security/gulf-air-hit-with-data-breach-customer-data-possibly-affected](https://www.techradar.com/pro/security/gulf-air-hit-with-data-breach-customer-data-possibly-affected)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T14:14:56+00:00

Airline notifies Gulf Air customers of a data breach, saying personal data may be affected.

## Squid Game: The Challenge may not be Netflix's #1 TV show this week due to a nerdy comedy juggernaut
 - [https://www.techradar.com/streaming/netflix/squid-game-the-challenge-has-a-big-and-surprising-rival-for-netflixs-1-tv-show-of-the-week](https://www.techradar.com/streaming/netflix/squid-game-the-challenge-has-a-big-and-surprising-rival-for-netflixs-1-tv-show-of-the-week)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T14:05:36+00:00

It's Squids versus Sheldon in the race to be crowned Netflix's most popular TV show in the final week of November.

## This malicious Telegram bot could create huge phishing scams
 - [https://www.techradar.com/pro/security/this-malicious-telegram-bot-could-create-huge-phishing-scams](https://www.techradar.com/pro/security/this-malicious-telegram-bot-could-create-huge-phishing-scams)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T14:00:06+00:00

Even low-skilled hackers can become experts in phishing thanks to this multi-purpose tool.

## There's still time to grab the best Cyber Monday VPN deals
 - [https://www.techradar.com/vpn/theres-still-time-to-grab-the-best-cyber-monday-vpn-deals](https://www.techradar.com/vpn/theres-still-time-to-grab-the-best-cyber-monday-vpn-deals)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T13:54:39+00:00

Don't miss out on the best Cyber Monday VPN deals. Here’s what savings are still about as VPNs hit their lowest prices all year.

## It’s Cyber Monday, but prices of Nvidia RTX 4090 GPUs are skyrocketing – what gives?
 - [https://www.techradar.com/computing/gpu/its-cyber-monday-but-prices-of-nvidia-rtx-4090-gpus-are-skyrocketing-what-gives](https://www.techradar.com/computing/gpu/its-cyber-monday-but-prices-of-nvidia-rtx-4090-gpus-are-skyrocketing-what-gives)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T13:52:34+00:00

Noticed how very expensive RTX 4090 graphics cards have got? There’s a reason for that.

## When will Spotify Wrapped 2023 be released? History suggests very soon
 - [https://www.techradar.com/audio/audio-streaming/when-will-spotify-wrapped-2023-be-released-history-suggests-very-soon](https://www.techradar.com/audio/audio-streaming/when-will-spotify-wrapped-2023-be-released-history-suggests-very-soon)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T13:43:19+00:00

Spotify is dropping hints that its year-end Wrapped roundup is coming soon. But when? Here are our best guesses.

## Act fast! These MacBook Cyber Monday deals could be your last chance to save big on Apple laptops
 - [https://www.techradar.com/computing/macbooks/act-fast-these-macbook-cyber-monday-deals-could-be-your-last-chance-to-save-big-on-apple-laptops](https://www.techradar.com/computing/macbooks/act-fast-these-macbook-cyber-monday-deals-could-be-your-last-chance-to-save-big-on-apple-laptops)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T12:51:14+00:00

The final countdown begins on these great MacBook Cyber Monday deals - and this could be your last chance to save before Christmas.

## Marvel Snap will ‘continue to operate and flourish’ as publisher Nuverse faces restructure
 - [https://www.techradar.com/gaming/marvel-snap-will-continue-to-operate-and-flourish-as-publisher-nuverse-faces-restructure](https://www.techradar.com/gaming/marvel-snap-will-continue-to-operate-and-flourish-as-publisher-nuverse-faces-restructure)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T12:21:31+00:00

Marvel Snap publisher Nuverse is facing restructure after a review at its parent company ByteDance.

## The Samsung Galaxy S24 could be its first 'AI phone' – here's what that means
 - [https://www.techradar.com/phones/the-samsung-galaxy-s24-could-be-its-first-ai-phone-heres-what-that-means](https://www.techradar.com/phones/the-samsung-galaxy-s24-could-be-its-first-ai-phone-heres-what-that-means)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T12:14:30+00:00

New Samsung trademark applications suggest it's planning to call the S24 an 'AI phone'. But what exactly does that mean?

## Chinese hackers sneakily stole secrets from Dutch chip company
 - [https://www.techradar.com/pro/security/chinese-hackers-sneakily-stole-secrets-from-dutch-chip-company](https://www.techradar.com/pro/security/chinese-hackers-sneakily-stole-secrets-from-dutch-chip-company)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T12:00:39+00:00

NXP’s IP has been exposed to a Chinese hacking group, but the company really isn’t bothered.

## Bought a MacBook on Cyber Monday and worried about the Atomic Stealer virus? Here's what you need to know
 - [https://www.techradar.com/pro/security/bought-a-macbook-on-cyber-monday-and-worried-about-the-atomic-stealer-virus-heres-what-you-need-to-know](https://www.techradar.com/pro/security/bought-a-macbook-on-cyber-monday-and-worried-about-the-atomic-stealer-virus-heres-what-you-need-to-know)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T11:58:35+00:00

Apple’s Macs have a great reputation for security, but a new Mac malware proves they’re not invulnerable.

## Prime Video's Bosch is getting another TV spin-off starring a character we haven't met yet
 - [https://www.techradar.com/streaming/amazon-prime-video/prime-videos-bosch-is-getting-another-tv-spin-off-starring-a-character-we-havent-met-yet](https://www.techradar.com/streaming/amazon-prime-video/prime-videos-bosch-is-getting-another-tv-spin-off-starring-a-character-we-havent-met-yet)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T11:30:55+00:00

If you like faintly cheesy LA cop dramas, you're going to love the latest spin-off from Amazon's Bosch TV show.

## Microsoft’s AI tinkering continues with powerful new GPT-4 Turbo upgrade for Copilot in Windows 11
 - [https://www.techradar.com/computing/artificial-intelligence/microsofts-ai-tinkering-continues-with-powerful-new-gpt-4-turbo-upgrade-for-copilot-in-windows-11](https://www.techradar.com/computing/artificial-intelligence/microsofts-ai-tinkering-continues-with-powerful-new-gpt-4-turbo-upgrade-for-copilot-in-windows-11)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T11:22:43+00:00

The implementation of GPT-4 Turbo will make for faster and more accurate responses from the AI, and more besides.

## Starfield mod stops the camera from awkwardly zooming in on NPCs when you talk to them
 - [https://www.techradar.com/gaming/pc-gaming/starfield-mod-stops-the-camera-from-awkwardly-zooming-in-on-npcs-when-you-talk-to-them](https://www.techradar.com/gaming/pc-gaming/starfield-mod-stops-the-camera-from-awkwardly-zooming-in-on-npcs-when-you-talk-to-them)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T11:19:46+00:00

A new Starfield mod allows you to speak to NPCs in first or third person, without the camera zooming in on their faces.

## Top file-sharing service hit with embarrassing security bug that reveals admin passwords
 - [https://www.techradar.com/pro/security/top-file-sharing-service-hit-with-embarrassing-security-bug-that-reveals-admin-passwords](https://www.techradar.com/pro/security/top-file-sharing-service-hit-with-embarrassing-security-bug-that-reveals-admin-passwords)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T11:15:47+00:00

Three critical vulnerabilities were found in an open-source cloud platform used by millions of people worldwide.

## Got an old Android phone? Google Calendar could soon stop working on it
 - [https://www.techradar.com/computing/software/got-an-old-android-phone-google-calendar-could-soon-stop-working-on-it](https://www.techradar.com/computing/software/got-an-old-android-phone-google-calendar-could-soon-stop-working-on-it)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T10:51:33+00:00

If you've got a device that's on Android 7 or older, you might want to think about upgrading.

## Margot Robbie might have crushed your Barbie sequel dreams: 'I can't imagine what would be next'
 - [https://www.techradar.com/streaming/entertainment/margot-robbie-might-have-crushed-your-barbie-sequel-dreams-i-cant-imagine-what-would-be-next](https://www.techradar.com/streaming/entertainment/margot-robbie-might-have-crushed-your-barbie-sequel-dreams-i-cant-imagine-what-would-be-next)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T10:49:04+00:00

Barbie's lead star has suggested there are no plans for a follow-up to 2023's highest-grossing movie.

## Tiny11 is now even smaller, giving you Windows 11 23H2 but without the clutter
 - [https://www.techradar.com/computing/windows/tiny11-is-now-even-smaller-giving-you-windows-11-23h2-but-without-the-clutter](https://www.techradar.com/computing/windows/tiny11-is-now-even-smaller-giving-you-windows-11-23h2-but-without-the-clutter)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T10:41:58+00:00

The highly streamlined version of Windows 11 is fully up to date and 20% smaller, plus offers the option of Copilot.

## Surprise, surprise - Black Friday 2023 was the biggest ever
 - [https://www.techradar.com/pro/surprise-surprise-black-friday-2023-was-the-biggest-ever](https://www.techradar.com/pro/surprise-surprise-black-friday-2023-was-the-biggest-ever)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T10:29:06+00:00

Consumers are happy to part with their own cash for Black Friday deals, but here’s the best time to buy.

## The OnePlus 12 has been officially shown off in photos and a video
 - [https://www.techradar.com/phones/oneplus-phones/the-oneplus-12-has-been-officially-shown-off-in-photos-and-a-video](https://www.techradar.com/phones/oneplus-phones/the-oneplus-12-has-been-officially-shown-off-in-photos-and-a-video)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T10:22:13+00:00

OnePlus has shown off the OnePlus 12, and revealed that it will be fully unveiled on December 5.

## Silent Hill 2 remake is ‘progressing smoothly’ according to Bloober Team
 - [https://www.techradar.com/gaming/consoles-pc/silent-hill-2-remake-is-progressing-smoothly-according-to-bloober-team](https://www.techradar.com/gaming/consoles-pc/silent-hill-2-remake-is-progressing-smoothly-according-to-bloober-team)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T10:01:32+00:00

Bloober Team's Silent Hill 2 remake is "progressing smoothly" through production and is "in accordance with our schedule."

## There’s not long left to bag the best Oculus Quest 2 deals of 2023
 - [https://www.techradar.com/computing/virtual-reality-augmented-reality/theres-not-long-left-to-bag-the-best-oculus-quest-2-deals-of-2023](https://www.techradar.com/computing/virtual-reality-augmented-reality/theres-not-long-left-to-bag-the-best-oculus-quest-2-deals-of-2023)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T09:25:47+00:00

Black Friday's best deals on Meta's Oculus Quest 2 are still up for grabs this Cyber Monday.

## The 17 best Walmart Cyber Monday deals you can buy right now
 - [https://www.techradar.com/cyber-monday-walmart-cyber-monday-sale](https://www.techradar.com/cyber-monday-walmart-cyber-monday-sale)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T03:48:06+00:00

The Walmart Cyber Monday sale just launched, and I'm rounding up the 17 best Cyber Monday deals you can shop for right now.

## The Best Buy Cyber Monday sale is now live: shop the 25 best deals I recommend
 - [https://www.techradar.com/cyber-monday-best-buy-cyber-monday-deals](https://www.techradar.com/cyber-monday-best-buy-cyber-monday-deals)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T01:48:29+00:00

The Best Buy Cyber Monday sale is now live, and I'm rounding up the 25 best deals I recommend on TVs, laptops, and Apple devices.

## Cyber Monday 8K TV deals are here – grab great savings on Samsung sets and more
 - [https://www.techradar.com/televisions/cyber-monday-8k-tv-deals](https://www.techradar.com/televisions/cyber-monday-8k-tv-deals)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T01:43:44+00:00

Here's our guide to finding all the best Cyber Monday 8K TV deals still running in 2023.

## Cyber Monday 85-inch TV deals are live – shop the sales at Amazon, Best Buy and more
 - [https://www.techradar.com/televisions/cyber-monday-85-inch-tv-deals](https://www.techradar.com/televisions/cyber-monday-85-inch-tv-deals)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T01:38:11+00:00

Cyber Monday has arrived and these are the best 85-inch TV deals that we've found

## Cyber Monday Lego deals are here – shop the 23 best sets including Star Wars and Harry Potter & Marvel
 - [https://www.techradar.com/seasonal-sales/cyber-monday-lego-deals-are-here-shop-the-23-best-sets-including-star-wars-and-harry-potter-and-marvel](https://www.techradar.com/seasonal-sales/cyber-monday-lego-deals-are-here-shop-the-23-best-sets-including-star-wars-and-harry-potter-and-marvel)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T01:21:33+00:00

Cyber Monday Lego deals are live – this is your chance to score a cheap Star Wars, Harry Potter, Icons or kids' set before the holidays.

## We've tested loads of office chairs - and our top choice gets the deal treatment for Cyber Monday
 - [https://www.techradar.com/pro/weve-tested-loads-of-office-chairs-and-our-top-choice-gets-the-deal-treatment-for-cyber-monday](https://www.techradar.com/pro/weve-tested-loads-of-office-chairs-and-our-top-choice-gets-the-deal-treatment-for-cyber-monday)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T00:50:14+00:00

We've tested a lot, and our top-rated office chair. the Branch Verve, gets a discount in latest Cyber Monday deal.

## Quordle today - hints and answers for Monday, November 27 (game #672)
 - [https://www.techradar.com/computing/websites-apps/quordle-today-answers-clues-27-november-2023](https://www.techradar.com/computing/websites-apps/quordle-today-answers-clues-27-november-2023)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T00:15:07+00:00

Looking for Quordle clues? We can help. Plus get the answers to Quordle today and past solutions.

## Cyber Monday dash cam deals: the best sales you can shop right now
 - [https://www.techradar.com/vehicle-tech/dash-cams/cyber-monday-dash-cam-deals](https://www.techradar.com/vehicle-tech/dash-cams/cyber-monday-dash-cam-deals)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-27T00:04:30+00:00

Cyber Monday 2023 is here, with plenty of Cyber Monday dash cam deals available in both the US and UK

