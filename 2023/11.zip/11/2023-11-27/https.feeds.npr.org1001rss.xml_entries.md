# Source:Npr, URL:https://feeds.npr.org/1001/rss.xml, language:en-US

## Mother of Palestinian student shot in Vermont thought he would be safer in U.S.
 - [https://www.npr.org/2023/11/27/1215362007/vermont-palestinian-shooting-mother-west-bank](https://www.npr.org/2023/11/27/1215362007/vermont-palestinian-shooting-mother-west-bank)
 - RSS feed: https://feeds.npr.org/1001/rss.xml
 - date published: 2023-11-27T19:21:35+00:00

Elizabeth Price's son Hisham Awartani was one of three men of Palestinian descent shot on Saturday in Vermont. Speaking to NPR from Ramallah, Price fears her son "is confronting a life of disability."

## Israel and Hamas hint at extending truce as more captives are slated to be freed
 - [https://www.npr.org/2023/11/27/1215330196/israel-and-hamas-hint-at-extending-truce-as-more-captives-are-slated-to-be-freed](https://www.npr.org/2023/11/27/1215330196/israel-and-hamas-hint-at-extending-truce-as-more-captives-are-slated-to-be-freed)
 - RSS feed: https://feeds.npr.org/1001/rss.xml
 - date published: 2023-11-27T10:46:57+00:00

Monday marks the official end of a four-day cease-fire deal between the two sides, but an extension looked likely. Over that time 58 Hamas hostages have been exchanged for 117 Palestinian prisoners.

## U.S. Navy seizes attackers who held Israel-linked tanker
 - [https://www.npr.org/2023/11/27/1215329411/us-navy-seizes-attackers-who-held-israel-linked-tanker](https://www.npr.org/2023/11/27/1215329411/us-navy-seizes-attackers-who-held-israel-linked-tanker)
 - RSS feed: https://feeds.npr.org/1001/rss.xml
 - date published: 2023-11-27T06:06:11+00:00

Armed assailants seized and later let go of a tanker linked to Israel off the coast of Yemen on Sunday before being apprehended by the United States Navy.

