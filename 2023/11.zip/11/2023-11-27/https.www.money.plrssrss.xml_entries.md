# Source:Money PL, URL:https://www.money.pl/rss/rss.xml, language:pl-PL

## Chleb od przyszłego roku zdrożeje? Są podstawy do obaw
 - [https://www.money.pl/podatki/chleb-od-przyszlego-roku-zdrozeje-sa-podstawy-do-obaw-6967772717435392a.html](https://www.money.pl/podatki/chleb-od-przyszlego-roku-zdrozeje-sa-podstawy-do-obaw-6967772717435392a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-11-27T20:35:52+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/297aea9e-4765-4a73-8025-acd5365778d0" width="308" /> Podniesienie płacy minimalnej i urealnienie kosztów zakupu paliwa doprowadzi do fali wzrostów, do tego likwidacja zerowej stawki VAT na żywność oraz odmrożenie cen gazu dla piekarni i cukierni - to czynniki, które mogą podnieść ceny pieczywa w 2024 roku.

## Nowy rząd Morawieckiego rusza do pracy. Premier zapowiada trzy ustawy
 - [https://www.money.pl/podatki/nowy-rzad-morawieckiego-rusza-do-pracy-premier-zapowiada-trzy-ustawy-6967762111548288a.html](https://www.money.pl/podatki/nowy-rzad-morawieckiego-rusza-do-pracy-premier-zapowiada-trzy-ustawy-6967762111548288a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-11-27T19:52:49+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/afd4928e-63e0-4b33-b78f-695ff55af2d9" width="308" /> Premier Mateusz Morawiecki zapowiedział, że w najbliższych dwóch tygodniach rząd będzie intensywnie pracował nad kilkoma projektami ustaw. Przedstawił trzy propozycje ustaw, które jego zdaniem są niezwykle korzystne dla społeczeństwa.

## Allegro skupi akcje i rozda pracownikom. Wkrótce rusza półroczny program
 - [https://www.money.pl/gielda/allegro-skupi-akcje-i-rozda-pracownikom-wkrotce-rusza-polroczny-program-6967757012339584a.html](https://www.money.pl/gielda/allegro-skupi-akcje-i-rozda-pracownikom-wkrotce-rusza-polroczny-program-6967757012339584a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-11-27T19:43:08+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/1d9cb5c1-830c-40cf-8934-c57e7b69d1b0" width="308" /> Allegro przeprowadzi skup akcji własnych w celu zrealizowania nagród w ramach pracowniczego programu motywacyjnego - poinformowała spółka w komunikacie.

## Zabiorą się za zmiany w PPK? "Pomysły mogą skończyć się katastrofą"
 - [https://www.money.pl/emerytury/zabiora-sie-za-zmiany-w-ppk-pomysly-moga-skonczyc-sie-katastrofa-6967721559128960a.html](https://www.money.pl/emerytury/zabiora-sie-za-zmiany-w-ppk-pomysly-moga-skonczyc-sie-katastrofa-6967721559128960a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-11-27T19:05:17+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c348df06-7933-4b2f-bbdb-4f16ddd7e7e2" width="308" /> Pracownicze Plany Kapitałowe (PPK) znalazły się na celowniku ekipy Donalda Tuska. Jakiekolwiek zmiany w sztandarowej reformie PiS-u mogą być katastrofalne w skutkach — ostrzegają eksperci pytani przez money.pl. Likwidacja automatycznego zapisu do programu emerytalnego byłaby początkiem jego końca.

## Orban broni atomowych interesów. Zablokował sankcje przeciw Rosji
 - [https://www.money.pl/gielda/orban-broni-atomowych-interesow-zablokowal-sankcje-przeciw-rosji-6967744655469056a.html](https://www.money.pl/gielda/orban-broni-atomowych-interesow-zablokowal-sankcje-przeciw-rosji-6967744655469056a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-11-27T18:48:24+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/0c063bcf-ac10-4997-a761-7e875b8ad70a" width="308" /> Węgry zablokowały propozycję unijnych sankcji wobec rosyjskiej energetyki jądrowej. Według ministra spraw zagranicznych Węgier Petera Szijjártó ich włączenie do 12. pakietu zagroziłoby bezpieczeństwu energetycznemu krajów europejskich.

## Ponad dwa miliony Włochów dało się oszukać. Kierowcy na celowniku
 - [https://www.money.pl/ubezpieczenia/ponad-dwa-miliony-wlochow-dalo-sie-oszukac-kierowcy-na-celowniku-6967738782484992a.html](https://www.money.pl/ubezpieczenia/ponad-dwa-miliony-wlochow-dalo-sie-oszukac-kierowcy-na-celowniku-6967738782484992a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-11-27T18:29:18+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/4f6aec27-069b-4c81-8272-42c4be61f472" width="308" /> Ponad 2,3 miliona Włochów padło w ciągu ostatniego roku ofiarą oszustwa, kupując fałszywe ubezpieczenia OC samochodu lub motocykla. W sumie stracili na tym setki milionów euro.

## "PiS spił śmietankę". Trudne zadanie dla nowej władzy
 - [https://www.money.pl/gospodarka/pis-spil-smietanke-trudne-zadanie-dla-nowej-wladzy-6967598166977408a.html](https://www.money.pl/gospodarka/pis-spil-smietanke-trudne-zadanie-dla-nowej-wladzy-6967598166977408a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-11-27T14:31:43+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cf35ba67-ec8b-4cb8-b32c-576e37214982" width="308" /> PiS zostawia gospodarkę w stanie "do remontu". Zdaniem ekonomistów nowy rząd powinien skoncentrować się na inwestycjach i eksporcie. Przyszły rok nie będzie sprzyjał oszczędzaniu. Problemy budżetowe poddadzą koalicję próbie czasu.

## Jak kończy PiS? "Zastanawiałem się nad trzy na szynach" [OPINIA]
 - [https://www.money.pl/gospodarka/jak-konczy-pis-zastanawialem-sie-nad-trzy-na-szynach-6967663492807168a.html](https://www.money.pl/gospodarka/jak-konczy-pis-zastanawialem-sie-nad-trzy-na-szynach-6967663492807168a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-11-27T13:40:44+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/32556915-d658-4d78-b1b4-b5b78d658508" width="308" /> W skali szkolnej od 1 do 6 dałbym rządom PiS ocenę trzy z minusem. Zastanawiałem się nad trzy na szynach, ale rynek pracy przeważył - pisze w opinii dla money.pl Piotr Kuczyński, główny analityk domu inwestycyjnego Xelion.

## Zagadkowe ruchy wokół TVP. "Utrudnienie dla przyszłego rządu"
 - [https://www.money.pl/gospodarka/zagadkowe-ruchy-wokol-tvp-utrudnienie-dla-przyszlego-rzadu-6967653287132032a.html](https://www.money.pl/gospodarka/zagadkowe-ruchy-wokol-tvp-utrudnienie-dla-przyszlego-rzadu-6967653287132032a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-11-27T12:50:46+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/bdfe81e5-7ddd-4c44-8727-88a6c43d3580" width="308" /> Piotr Gliński wystąpił do Rady Mediów Narodowych z wnioskiem o wyrażenie zgody na zmiany w statutach mediów publicznych. A RMN miała na to przystać – informują media. Zmiany dotyczą procedury likwidacji spółek. W ten sposób ustępujący rząd chce utrudnić nowej władzy proces przejęcia kontroli nad mediami.

## "Starym" ministrom nie opłaca się wchodzić do nowego rządu PiS. Stracą wysokie odprawy
 - [https://www.money.pl/gospodarka/starym-ministrom-nie-oplaca-sie-wchodzic-do-nowego-rzadu-pis-straca-wysokie-odprawy-6967639178349440a.html](https://www.money.pl/gospodarka/starym-ministrom-nie-oplaca-sie-wchodzic-do-nowego-rzadu-pis-straca-wysokie-odprawy-6967639178349440a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-11-27T11:59:01+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/67a2f1e6-5ecc-4eb7-a350-d0c2f2f3fd66" width="308" /> Ministrowie dotychczas zasiadający w rządzie Mateusza Morawieckiego nie kwapią się do wejścia do jego nowego gabinetu. I w sumie nie ma się co im dziwić. Jeżeli przyjęliby nominację, to wiązałoby się to z utratą wysokich odpraw. Prawo w tym wypadku jest jasne.

## W Niemczech "wszystkie strzałki na czerwono". Kolejny bank obniża prognozy
 - [https://www.money.pl/gospodarka/w-niemczech-wszystkie-strzalki-na-czerwono-kolejny-bank-obniza-prognozy-6967638550743936a.html](https://www.money.pl/gospodarka/w-niemczech-wszystkie-strzalki-na-czerwono-kolejny-bank-obniza-prognozy-6967638550743936a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-11-27T11:36:51+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/15aa9934-f237-426a-a606-8282194ec16f" width="308" /> Deutsche Bank obniżył swoją prognozę dla niemieckiej gospodarki i spodziewa się, że PKB Niemiec w 2023 roku skurczy się o 0,5 procent. Sytuacja gospodarcza w kraju ma się więc pogorszyć, bo poprzednia prognoza zakładała spadek o 0,3 procent. Bank jest również mniej optymistyczny co do 2024 r.

## Problem z wyższą kwotą wolną. "Na pewno nie będzie to pierwsza zrealizowana obietnica"
 - [https://www.money.pl/podatki/problem-z-wyzsza-kwota-wolna-na-pewno-nie-bedzie-to-pierwsza-zrealizowana-obietnica-6967617425460096a.html](https://www.money.pl/podatki/problem-z-wyzsza-kwota-wolna-na-pewno-nie-bedzie-to-pierwsza-zrealizowana-obietnica-6967617425460096a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-11-27T11:02:14+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/d4c4dd31-7eb7-49bb-9db7-903f173b38c7" width="308" /> Koalicja Obywatelska przed wyborami obiecała podniesienie kwoty wolnej od podatku do poziomu 60 tys. zł. Po wyborach jednak podkreśla, że będzie to trudne zadanie. Teraz Marcin Kierwiński przyznaje, że to nie będzie pierwsza zrealizowana obietnica przyszłej koalicji rządzącej.

## PiS jest dumny z reformy PPK. Tusk namiesza? "Trzeba być ostrożnym"
 - [https://www.money.pl/emerytury/pis-jest-dumny-z-reformy-ppk-tusk-namiesza-trzeba-byc-ostroznym-6967607885282272a.html](https://www.money.pl/emerytury/pis-jest-dumny-z-reformy-ppk-tusk-namiesza-trzeba-byc-ostroznym-6967607885282272a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-11-27T09:45:20+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/6cba7756-be6a-42cf-bda3-18d5ed570479" width="308" /> "Można oczywiście wprowadzać korekty, ale trzeba tu być więcej niż ostrożnym" - napisał na platformie X Bartosz Marczuk, wiceprezes Polskiego Funduszu Rozwoju, zarządzającego PPK. Odniósł się do doniesień "Wyborczej" o szykowanych zmianach w sztandarowej reformie PiS. I przypomniał o decyzji Tuska sprzed lat.

## Rząd reaguje na skargę KE. Proponuje nowelę wprowadzającą opłatę
 - [https://www.money.pl/gospodarka/rzad-reaguje-na-skarge-ke-proponuje-nowele-wprowadzajaca-oplate-6967596040682368a.html](https://www.money.pl/gospodarka/rzad-reaguje-na-skarge-ke-proponuje-nowele-wprowadzajaca-oplate-6967596040682368a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-11-27T09:36:55+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/61a24f13-ec3d-4a1a-bd18-5b502a7f73da" width="308" /> Komisja Europejska zarzuciła Polsce, że ta ma zbyt restrykcyjne wymogi dotyczące magazynowania gazu przez firmy. Na reakcję nie trzeba było długo czekać. Na ostatniej prostej ustępujący rząd pracuje nad ustawą zwalniającą firmy z obowiązku utrzymywania zapasów gazu. Będzie jednak opłata dla części firm.

## Ogromny wyciek danych pacjentów. Hakerzy grożą firmie i dają jej czas na zapłatę okupu
 - [https://www.money.pl/gospodarka/ogromny-wyciek-danych-pacjentow-hakerzy-groza-firmie-i-daja-jej-czas-na-zaplate-okupu-6967607169158112a.html](https://www.money.pl/gospodarka/ogromny-wyciek-danych-pacjentow-hakerzy-groza-firmie-i-daja-jej-czas-na-zaplate-okupu-6967607169158112a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-11-27T09:20:55+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/bf2ea108-9218-46cf-ba29-150f1baeb0b8" width="308" /> Firma ALAB Laboratoria mierzy się ze skutkami ogromnego wycieku danych. Hakerzy opublikowali dane medyczne co najmniej kilkudziesięciu tysięcy Polek i Polaków, którzy w latach 2017-2023 wykonywali badania medyczne w tej sieci. Dali też termin zapłaty okupu. W przeciwnym wypadku opublikują pełne dane.

## "Nowy" prezes KNF o swoich kompetencjach. "Narosły mity"
 - [https://www.money.pl/banki/nowy-prezes-knf-o-swoich-kompetencjach-narosly-mity-6967585616399328a.html](https://www.money.pl/banki/nowy-prezes-knf-o-swoich-kompetencjach-narosly-mity-6967585616399328a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-11-27T08:15:59+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/8d7a339b-d365-47a7-937f-5094bcff8447" width="308" /> Jacek Jastrzębski udzielił pierwszego wywiadu po ponownej nominacji na szefa KNF. Zapewnił w nim, że Urząd będzie "profesjonalny, rzetelny" i będzie działał "w sposób przewidywalny". Stwierdził zarazem, że "narosły mity" dotyczące odwołania prezesów banków.

## Ropa tanieje na początku tygodnia. Wszyscy wyczekują na ruch kartelu
 - [https://www.money.pl/gielda/ropa-tanieje-na-poczatku-tygodnia-wszyscy-wyczekuja-ruchu-kartelu-6967575422770048a.html](https://www.money.pl/gielda/ropa-tanieje-na-poczatku-tygodnia-wszyscy-wyczekuja-ruchu-kartelu-6967575422770048a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-11-27T07:28:23+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/2510b99f-82f4-4128-ae0f-f6a4b98ad767" width="308" /> Nowy tydzień rozpoczyna się przeceną ropy naftowej na rynkach. To kolejne spadki cen; surowiec traci na wartości już czwartą sesję z rzędu. Rynek oczekuje na przełożone spotkanie OPEC+. Kartel może wpłynąć na notowania surowca kolejną decyzją o ograniczeniu wydobycia.

## Rozliczenie PiS może nie pójść gładko. "Trybunał Stanu to martwy organ"
 - [https://www.money.pl/gospodarka/rozliczenie-pis-moze-nie-pojsc-gladko-trybunal-stanu-to-martwy-organ-6967564179852256a.html](https://www.money.pl/gospodarka/rozliczenie-pis-moze-nie-pojsc-gladko-trybunal-stanu-to-martwy-organ-6967564179852256a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-11-27T06:44:52+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/927c9907-0c89-45f2-b885-56e45eccc438" width="308" /> Wybory korespondencyjne będą zakresem prac pierwszej komisji śledczej, którą zamierza powołać obecna koalicja. W Naczelnym Sądzie Administracyjnym leży wniosek kasacyjny Mateusza Morawieckiego w tym zakresie. Jego rozpatrzenie mogłoby utorować drogę do Trybunału Stanu, który od lat jest martwym organem.

## Kursy walut 27.11.2023. Poniedziałkowy kurs funta, euro, dolara i franka szwajcarskiego
 - [https://www.money.pl/pieniadze/kursy-walut-27-11-2023-poniedzialkowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6967561859214304a.html](https://www.money.pl/pieniadze/kursy-walut-27-11-2023-poniedzialkowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6967561859214304a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-11-27T06:06:02+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/42673486-e5fa-426a-a05b-a827a357deb3" width="308" /> Kursy walut - 27.11.2023. W poniedziałek za jednego dolara (USD) zapłacimy 3,99 zł. Cena jednego funta szterlinga (GBP) to 5,03 zł, a franka szwajcarskiego (CHF) 4,52 zł. Z kolei euro (EUR) możemy zakupić za 4,36 zł.

## Sztandarowa reforma PiS do zmiany. Dziennikarze ujawniają plany przyszłego rządu
 - [https://www.money.pl/emerytury/sztandarowa-reforma-pis-do-zmiany-dziennikarze-ujawniaja-plany-przyszlego-rzadu-6967557213354976a.html](https://www.money.pl/emerytury/sztandarowa-reforma-pis-do-zmiany-dziennikarze-ujawniaja-plany-przyszlego-rzadu-6967557213354976a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-11-27T06:05:13+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/591dc148-b3e4-4d63-a78e-026301685dd0" width="308" /> Pracownicze Plany Kapitałowe (PPK) miały być propozycją Prawa i Sprawiedliwości na zapewnienie Polakom dodatkowych pieniędzy na emeryturę. Nie porwały one jednak Polaków. Dlatego też przyszły rząd zamierza dokonać kilku zmian w programie – pisze "Gazeta Wyborcza".

## Ile kosztuje dolar? Kurs dolara do złotego PLN/USD 27.11.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-27-11-2023-6967561574165472a.html](https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-27-11-2023-6967561574165472a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-11-27T06:00:39+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e0ba71a8-9c02-482d-85dd-ebac5362ee3b" width="308" /> Kurs dolara - 27.11.2023. W poniedziałek za jednego dolara (USD) trzeba zapłacić 3.9871 zł.

## Ile kosztuje euro? Kurs euro do złotego PLN/EUR 27.11.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-27-11-2023-6967561541962720a.html](https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-27-11-2023-6967561541962720a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-11-27T06:00:31+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cf3a8300-d9c9-461f-9fbc-2f314332a28c" width="308" /> Kurs euro - 27.11.2023. W poniedziałek za jedno euro (EUR) trzeba zapłacić 4.366 zł.

## Ile kosztuje frank szwajcarski? Kurs franka do złotego PLN/CHF 27.11.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-27-11-2023-6967561542409184a.html](https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-27-11-2023-6967561542409184a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-11-27T06:00:31+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b1c04e3f-7bce-4c35-b03c-7a8d7b0adc65" width="308" /> Kurs franka szwajcarskiego - 27.11.2023. W poniedziałek za jednego franka (CHF) trzeba zapłacić 4.5207 zł.

## Ile kosztuje funt? Kurs funta do złotego PLN/GBP 27.11.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-27-11-2023-6967561539406720a.html](https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-27-11-2023-6967561539406720a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-11-27T06:00:30+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c374eefc-9e8b-424a-aaa7-91759b47d116" width="308" /> Kurs funta szterlinga - 27.11.2023. W poniedziałek za jednego funta brytyjskiego (GBP) trzeba zapłacić 5.0282 zł.

## Nowe świadczenie od 2024 r. Trzeba pamiętać o złożeniu wniosku
 - [https://www.money.pl/gospodarka/nowe-swiadczenie-od-2024-r-trzeba-pamietac-o-zlozeniu-wniosku-6967551337970656a.html](https://www.money.pl/gospodarka/nowe-swiadczenie-od-2024-r-trzeba-pamietac-o-zlozeniu-wniosku-6967551337970656a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-11-27T05:37:26+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/af5ac391-aaa1-4e0c-9b24-fc600815eaa8" width="308" /> Od 2024 r. rozpoczną się wypłaty świadczenia wspierającego. Skorzystają z niego osoby z niepełnosprawnością. Najpierw jednak muszą uzyskać orzeczenie lekarskie określające poziom wsparcia. Od niego jest uzależniona wysokość wypłaty, jaka trafi na konto świadczeniobiorcy.

## Unia szykuje embargo na LPG z Rosji. Może być gorąco. "Odczujemy podwyżki"
 - [https://www.money.pl/gielda/unia-szykuje-embargo-na-lpg-z-rosji-moze-byc-goraco-odczujemy-podwyzki-6966559215311744a.html](https://www.money.pl/gielda/unia-szykuje-embargo-na-lpg-z-rosji-moze-byc-goraco-odczujemy-podwyzki-6966559215311744a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-11-27T05:12:37+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/3b78586c-e624-4e37-a839-6e45a3344df3" width="308" /> Polska jest największym odbiorcą rosyjskiego LPG. Sama zabiegała, aby objąć embargiem unijnym również ten gaz. Przedstawiony niedawno Komisji Europejskiej projekt 12. pakietu sankcji ma w końcu zakazać jego sprowadzania. Będzie to jednak oznaczać poważne problemy dla 3,4 mln kierowców.

