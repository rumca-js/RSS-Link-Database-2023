# Source:Popular Science, URL:https://www.popsci.com/feed, language:en-US

## Sneak away for some arousing browsing … of the best Cyber Monday sex toy deals
 - [https://www.popsci.com/gear/sex-toys-sexual-wellness-amazon-deals-cyber-monday-2023](https://www.popsci.com/gear/sex-toys-sexual-wellness-amazon-deals-cyber-monday-2023)
 - RSS feed: https://www.popsci.com/feed
 - date published: 2023-11-27T23:45:00+00:00

<figure class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="A Womanizer OG in a pattern on a plain background" class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="959" src="https://www.popsci.com/uploads/2023/11/27/amazon-sexual-wellness-deal.jpg?auto=webp&amp;width=1440&amp;height=959.76" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><figcaption class="orgnc-SingleImage-caption"><span class="orgnc-SingleImage-credit">Amanda Reed</span></figcaption></figure><p>Whether it's with your lover or by yourself, there's no better activity than ... shopping our favorite sexual wellness accessories on Amazon.</p>
<p>The post <a href="https://www.popsci.com/gear/sex-toys-sexual-wellness-amazon-deals-cyber-monday-2023/" rel="nofollow">Sneak away for some arousing browsing &#8230; of the best Cyber Monday sex toy deals</a> 

## 20+ luxury items that are less pricey for Cyber Monday
 - [https://www.popsci.com/gear/luxury-high-end-deals-cyber-monday-2023](https://www.popsci.com/gear/luxury-high-end-deals-cyber-monday-2023)
 - RSS feed: https://www.popsci.com/feed
 - date published: 2023-11-27T21:55:00+00:00

<figure class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="LG OLED Evo TV in a room with viewers" class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="960" src="https://www.popsci.com/uploads/2023/11/27/2023-LG-OLED-evo-C3_Lifestyle-sport_PR-scaled-1.jpg?auto=webp&amp;width=1440&amp;height=960.1875" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><figcaption class="orgnc-SingleImage-caption"><span class="orgnc-SingleImage-credit">LG</span></figcaption></figure><p>Do you need a $5,000 TV? $5,000 speakers? How about a $5,000 headphones-amp combo? Probably not. But that and more is all on sale for Cyber Monday. </p>
<p>The post <a href="https://www.popsci.com/gear/luxury-high-end-deals-cyber-monday-2023/" rel="nofollow">20+ luxury items that are less pricey for Cyber Monday</a> appeared first on <a href="https://www

## Our favorite cannabis vaporizer is $90 off for Cyber Monday
 - [https://www.popsci.com/gear/pax-cannabis-amazon-deals-cyber-monday-2023](https://www.popsci.com/gear/pax-cannabis-amazon-deals-cyber-monday-2023)
 - RSS feed: https://www.popsci.com/feed
 - date published: 2023-11-27T21:20:00+00:00

<figure class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="A Pax Plus cannabis vaporizer on a rolling tray with some oregano seasoning" class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="810" src="https://www.popsci.com/uploads/2023/11/27/pax-header-scaled.jpg?auto=webp&amp;width=1440&amp;height=810" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><figcaption class="orgnc-SingleImage-caption"><span class="orgnc-SingleImage-credit">Amanda Reed</span></figcaption></figure><p>When it comes to saving money on Cyber Monday, this is a CANNabis deal, not a CAN'Tabis one.</p>
<p>The post <a href="https://www.popsci.com/gear/pax-cannabis-amazon-deals-cyber-monday-2023/" rel="nofollow">Our favorite cannabis vaporizer is $90 off for Cyber Monday</a> appeared first on <a href="https://www.popsci.com" rel="nofollow">Popular

## How AI could help scientists spot ‘ultra-emission’ methane plumes faster—from space
 - [https://www.popsci.com/environment/methane-plume-ai-detection](https://www.popsci.com/environment/methane-plume-ai-detection)
 - RSS feed: https://www.popsci.com/feed
 - date published: 2023-11-27T20:00:00+00:00

<figure class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="Global Warming photo" class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="810" src="https://www.popsci.com/uploads/2023/11/27/Banner_illustration-scaled.jpg?auto=webp&amp;width=1440&amp;height=810" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div></figure><p>Reducing leaks of the potent greenhouse gas could alleviate global warming by as much as 0.3 degrees Celsius over the next two decades.</p>
<p>The post <a href="https://www.popsci.com/environment/methane-plume-ai-detection/" rel="nofollow">How AI could help scientists spot &#8216;ultra-emission&#8217; methane plumes faster—from space</a> appeared first on <a href="https://www.popsci.com" rel="nofollow">Popular Science</a>.</p>

## A critically endangered Sumatran rhino named Delilah welcomes first calf
 - [https://www.popsci.com/environment/sumatran-rhino-calf-born](https://www.popsci.com/environment/sumatran-rhino-calf-born)
 - RSS feed: https://www.popsci.com/feed
 - date published: 2023-11-27T19:00:00+00:00

<figure class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="A newborn rhino calf stands under his mother. He is black and does not have his signature horns in yet." class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="810" src="https://www.popsci.com/uploads/2023/11/27/rare-rhino-born.jpg?auto=webp&amp;width=1440&amp;height=810" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><figcaption class="orgnc-SingleImage-caption">The new arrival is the fifth calf born at the Way Kambas Sanctuary and second in 2023. <span class="orgnc-SingleImage-credit">Indonesian Ministry of Environment and Forestry</span></figcaption></figure><p>The species is critically endangered, with fewer than 50 animals left.</p>
<p>The post <a href="https://www.popsci.com/environment/sumatran-rhino-calf-born/" rel="nofollow">A critically endangere

## Save big with Cyber Monday deals on premium home appliances we love
 - [https://www.popsci.com/gear/vitamix-blender-amazon-deal-cyber-monday-2023](https://www.popsci.com/gear/vitamix-blender-amazon-deal-cyber-monday-2023)
 - RSS feed: https://www.popsci.com/feed
 - date published: 2023-11-27T18:55:00+00:00

<figure class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="The best appliance Cyber Monday deals" class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="936" src="https://www.popsci.com/uploads/2023/11/27/The-best-appliance-Cyber-Monday-deals.jpg?auto=webp&amp;width=1440&amp;height=936" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><figcaption class="orgnc-SingleImage-caption"><span class="orgnc-SingleImage-credit">Brandt Ranj / Popular Science </span></figcaption></figure><p>These limited-time deals won't last long, but the quality appliances you buy will.</p>
<p>The post <a href="https://www.popsci.com/gear/vitamix-blender-amazon-deal-cyber-monday-2023/" rel="nofollow">Save big with Cyber Monday deals on premium home appliances we love</a> appeared first on <a href="https://www.popsci.com" rel="nofollow">Popula

## Log into your abandoned Google account now
 - [https://www.popsci.com/technology/google-old-account-deletion](https://www.popsci.com/technology/google-old-account-deletion)
 - RSS feed: https://www.popsci.com/feed
 - date published: 2023-11-27T18:00:00+00:00

<figure class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="Closeup of female hands is holding cellphone outdoors on the street in evening lights." class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="810" src="https://www.popsci.com/uploads/2023/11/27/Depositphotos_117507286_L.jpg?auto=webp&amp;width=1440&amp;height=810" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><figcaption class="orgnc-SingleImage-caption">Google is purging accounts inactive for over two years, citing online security purposes. <span class="orgnc-SingleImage-credit"><a href="https://depositphotos.com/photo/closeup-of-female-hands-is-holding-cellphone-outdoors-on-the-street-in-evening-lights-woman-117507286.html">Deposit Photos</a></span></figcaption></figure><p>Google will begin purging 'inactive' accounts this week. Here's how to keep your

## My dog’s safe space can be your dog’s new happy place
 - [https://www.popsci.com/environment/fable-crate-dog-accessories-cyber-monday-2023](https://www.popsci.com/environment/fable-crate-dog-accessories-cyber-monday-2023)
 - RSS feed: https://www.popsci.com/feed
 - date published: 2023-11-27T17:55:00+00:00

<figure class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="Charli my toy Aussie Shepherd in her Fable crate next to the couch" class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="960" src="https://www.popsci.com/uploads/2023/11/27/Charli-dog-in-her-Fable-crate-next-to-the-couch.jpg?auto=webp&amp;width=1440&amp;height=960" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><figcaption class="orgnc-SingleImage-caption"><span class="orgnc-SingleImage-credit">Tony Ware</span></figcaption></figure><p>If you need a crate your dog will love napping in and you won't get tired looking at, check out this Cyber Monday special.</p>
<p>The post <a href="https://www.popsci.com/environment/fable-crate-dog-accessories-cyber-monday-2023/" rel="nofollow">My dog&#8217;s safe space can be your dog&#8217;s new happy place</a> appeared 

## We personally love Celestron telescopes—they’re on sale for Cyber Monday
 - [https://www.popsci.com/gear/celestron-deal-amazon-cyber-monday-2023](https://www.popsci.com/gear/celestron-deal-amazon-cyber-monday-2023)
 - RSS feed: https://www.popsci.com/feed
 - date published: 2023-11-27T17:42:57+00:00

<figure class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="A Celestron telescope in a pattern on a plain background" class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="959" src="https://www.popsci.com/uploads/2023/11/27/celestron-telescope-deal.jpg?auto=webp&amp;width=1440&amp;height=959.76" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><figcaption class="orgnc-SingleImage-caption"><span class="orgnc-SingleImage-credit">Amanda Reed</span></figcaption></figure><p>Get a great view of the stars, planets, and other extraterrestrial sights with this Celestron telescope deal at Amazon.</p>
<p>The post <a href="https://www.popsci.com/gear/celestron-deal-amazon-cyber-monday-2023/" rel="nofollow">We personally love Celestron telescopes—they&#8217;re on sale for Cyber Monday</a> appeared first on <a href="https://www.p

## Green shipping picks up speed
 - [https://www.popsci.com/environment/green-shipping](https://www.popsci.com/environment/green-shipping)
 - RSS feed: https://www.popsci.com/feed
 - date published: 2023-11-27T17:00:00+00:00

<figure class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="shipping containers on ship sailing through the sea" class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="810" src="https://www.popsci.com/uploads/2023/11/23/shipping-containers-ship-sailing.jpg?auto=webp&amp;width=1440&amp;height=810" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><figcaption class="orgnc-SingleImage-caption">Ships transported over 80 percent of world trade in 2021, according to the UN Conference on Trade and Development, but the voyages are a serious source of greenhouse gas emissions. <span class="orgnc-SingleImage-credit"><a href="https://depositphotos.com/photo/container-cargo-logistics-shipping-import-export-industry-business-service-transportation-549794068.html">DepositPhotos</a></span></figcaption></figure><p>An international tr

## The best Cyber Monday deals on expert-approved Bluetooth speakers
 - [https://www.popsci.com/gear/jbl-sony-bose-bluetooth-speaker-amazon-deal-cyber-monday-2023](https://www.popsci.com/gear/jbl-sony-bose-bluetooth-speaker-amazon-deal-cyber-monday-2023)
 - RSS feed: https://www.popsci.com/feed
 - date published: 2023-11-27T16:55:00+00:00

<figure class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="The best Bluetooth speaker Cyber Monday deals" class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="936" src="https://www.popsci.com/uploads/2023/11/27/The-best-Bluetooth-speaker-Cyber-Monday-deals.jpg?auto=webp&amp;width=1440&amp;height=936" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><figcaption class="orgnc-SingleImage-caption"><span class="orgnc-SingleImage-credit">Brandt Ranj / Popular Science </span></figcaption></figure><p>These deals include speakers of every size and shape to deliver beats at prices you can't beat</p>
<p>The post <a href="https://www.popsci.com/gear/jbl-sony-bose-bluetooth-speaker-amazon-deal-cyber-monday-2023/" rel="nofollow">The best Cyber Monday deals on expert-approved Bluetooth speakers</a> appeared first on <a href="htt

## African penguins may tell each other apart by the spots in their plumage
 - [https://www.popsci.com/environment/african-penguins-spots](https://www.popsci.com/environment/african-penguins-spots)
 - RSS feed: https://www.popsci.com/feed
 - date published: 2023-11-27T16:00:00+00:00

<figure class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="Six African penguins standing on a rock. They have white plumage with black dots arranged in individual patterns on their chests." class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="810" src="https://www.popsci.com/uploads/2023/11/27/african-penguin-dots.png?auto=webp&amp;width=1440&amp;height=810" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><figcaption class="orgnc-SingleImage-caption">A few members of the Zoomarine Italia penguin colony. The unique ventral dot patterns are visible on each penguin's chest. <span class="orgnc-SingleImage-credit">Cristina Pilenga/Animal Behaviour (2023)</span></figcaption></figure><p>The dots reemerge in the exact same position when their annual plumage comes in.</p>
<p>The post <a href="https://www.popsci.com/enviro

## How to open a QR code on your computer
 - [https://www.popsci.com/diy/qr-code-on-computer](https://www.popsci.com/diy/qr-code-on-computer)
 - RSS feed: https://www.popsci.com/feed
 - date published: 2023-11-27T15:00:00+00:00

<figure class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="Opening QR code on a laptop at the park" class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="810" src="https://www.popsci.com/uploads/2023/11/22/how-to-scan-qr-code-on-your-computer.jpg?auto=webp&amp;width=1440&amp;height=810" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><figcaption class="orgnc-SingleImage-caption">You don't need your phone to open a QR code. <span class="orgnc-SingleImage-credit"><a href="https://depositphotos.com/photo/man-working-in-park-with-laptop-50706333.html">DepositPhotos</a></span></figcaption></figure><p>Scanning a QR code without your phone requires a little help from Google or a webcam.</p>
<p>The post <a href="https://www.popsci.com/diy/qr-code-on-computer/" rel="nofollow">How to open a QR code on your computer</a> appe

## 2024 BMW G 310 R review: A starter bike you won’t outgrow
 - [https://www.popsci.com/technology/2024-bmw-g-310-r-review](https://www.popsci.com/technology/2024-bmw-g-310-r-review)
 - RSS feed: https://www.popsci.com/feed
 - date published: 2023-11-27T14:00:00+00:00

<figure class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="BMW G 310 R (K03)" class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="810" src="https://www.popsci.com/uploads/2023/11/23/00-bmw-bike-lead.jpg?auto=webp&amp;width=1440&amp;height=810" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><figcaption class="orgnc-SingleImage-caption">The bike's light weight contributes to corner-carving agility. <span class="orgnc-SingleImage-credit">BMW</span></figcaption></figure><p>The G310 R delivers sophisticated tech you'd expect on a more expensive ride.</p>
<p>The post <a href="https://www.popsci.com/technology/2024-bmw-g-310-r-review/" rel="nofollow">2024 BMW G 310 R review: A starter bike you won’t outgrow</a> appeared first on <a href="https://www.popsci.com" rel="nofollow">Popular Science</a>.</p>

## An live-updating list of Cyber Monday deals that don’t suck
 - [https://www.popsci.com/gear/best-cyber-monday-deals-2023](https://www.popsci.com/gear/best-cyber-monday-deals-2023)
 - RSS feed: https://www.popsci.com/feed
 - date published: 2023-11-27T13:45:39+00:00

<figure class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="A Hydroflask bag with a hydroflask water bottle and a picnic laid out on a plain background" class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="809" src="https://www.popsci.com/uploads/2023/11/27/best-cyber-monday-deals-2023-header.jpg?auto=webp&amp;width=1440&amp;height=809.57171991842" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><figcaption class="orgnc-SingleImage-caption"><span class="orgnc-SingleImage-credit">HydroFlask</span></figcaption></figure><p>You can save money on just about everything from kitchen gadgets and Hydroflasks, to generators and massagers on Cyber Monday.</p>
<p>The post <a href="https://www.popsci.com/gear/best-cyber-monday-deals-2023/" rel="nofollow">An live-updating list of Cyber Monday deals that don&#8217;t suck</a> app

## Upgrade your space with these limited-time Cyber Monday smart home deals
 - [https://www.popsci.com/gear/best-smart-home-amazon-deals-cyber-monday-2023](https://www.popsci.com/gear/best-smart-home-amazon-deals-cyber-monday-2023)
 - RSS feed: https://www.popsci.com/feed
 - date published: 2023-11-27T11:58:00+00:00

<figure class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="Best Smart Home Cyber Monday Deals" class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="936" src="https://www.popsci.com/uploads/2023/11/26/Best-Smart-Home-Cyber-Monday-Deals.jpg?auto=webp&amp;width=1440&amp;height=936" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><figcaption class="orgnc-SingleImage-caption"><span class="orgnc-SingleImage-credit">Brandt Ranj / Popular Science </span></figcaption></figure><p>Save hundreds of dollars on smart security systems, locks, light bulbs, thermostats and more during Cyber Monday.</p>
<p>The post <a href="https://www.popsci.com/gear/best-smart-home-amazon-deals-cyber-monday-2023/" rel="nofollow">Upgrade your space with these limited-time Cyber Monday smart home deals</a> appeared first on <a href="https://www.po

## Save up to 40% on Shark vacuums and Ninja kitchen gear for Cyber Monday at Amazon
 - [https://www.popsci.com/gear/shark-ninja-amazon-deal-cyber-monday-2023](https://www.popsci.com/gear/shark-ninja-amazon-deal-cyber-monday-2023)
 - RSS feed: https://www.popsci.com/feed
 - date published: 2023-11-27T11:43:00+00:00

<figure class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="A Shak vacuum and griddle in a pattern on a plain background" class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="959" src="https://www.popsci.com/uploads/2023/11/27/shark-vacuum-cyber-monday-deal.jpg?auto=webp&amp;width=1440&amp;height=959.76" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><figcaption class="orgnc-SingleImage-caption"><span class="orgnc-SingleImage-credit">Amanda Reed</span></figcaption></figure><p>From vacuums to coffee makers and blenders, here's what you can get on sale from Shark and Ninja this Cyber Monday at Amazon. </p>
<p>The post <a href="https://www.popsci.com/gear/shark-ninja-amazon-deal-cyber-monday-2023/" rel="nofollow">Save up to 40% on Shark vacuums and Ninja kitchen gear for Cyber Monday at Amazon</a> appeared first on 

## Save big on soundbars from Sonos, JBL, Sony, Bose, Samsung, and more during Cyber Monday
 - [https://www.popsci.com/gear/best-soundbar-deals-samsung-sonos-polk-jbl-sony-cyber-monday-2023](https://www.popsci.com/gear/best-soundbar-deals-samsung-sonos-polk-jbl-sony-cyber-monday-2023)
 - RSS feed: https://www.popsci.com/feed
 - date published: 2023-11-27T11:28:00+00:00

<figure class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="The best cyber monday soundbar deals" class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="936" src="https://www.popsci.com/uploads/2023/11/27/The-best-cyber-monday-soundbar-deals.jpg?auto=webp&amp;width=1440&amp;height=936" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><figcaption class="orgnc-SingleImage-caption"><span class="orgnc-SingleImage-credit">Brandt Ranj / Popular Science </span></figcaption></figure><p>These Cyber Monday deals will quite literally sound good.</p>
<p>The post <a href="https://www.popsci.com/gear/best-soundbar-deals-samsung-sonos-polk-jbl-sony-cyber-monday-2023/" rel="nofollow">Save big on soundbars from Sonos, JBL, Sony, Bose, Samsung, and more during Cyber Monday</a> appeared first on <a href="https://www.popsci.com" rel="no

## Our favorite smart lighting from Govee is up to 44% off for Cyber Monday at Amazon
 - [https://www.popsci.com/gear/govee-smart-lights-amazon-deal-cyber-monday-2023](https://www.popsci.com/gear/govee-smart-lights-amazon-deal-cyber-monday-2023)
 - RSS feed: https://www.popsci.com/feed
 - date published: 2023-11-27T11:13:00+00:00

<figure class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="Govee smart LED strip lights lit up in different colors with the control app in the foreground" class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="810" src="https://www.popsci.com/uploads/2023/11/27/govee-smart-lights-cyber-monday.jpg?auto=webp&amp;width=1440&amp;height=810" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><figcaption class="orgnc-SingleImage-caption"><span class="orgnc-SingleImage-credit">Govee</span></figcaption></figure><p>Govee smart lights add tons of illumination options to the inside and outside of your home. They're all on sale for Cyber Monday at Amazon.</p>
<p>The post <a href="https://www.popsci.com/gear/govee-smart-lights-amazon-deal-cyber-monday-2023/" rel="nofollow">Our favorite smart lighting from Govee is up to 44% off fo

## This best-selling air purifier is at its lowest price of the year for Cyber Monday at Amazon
 - [https://www.popsci.com/gear/air-purifier-amazon-deal-cyber-monday-2023](https://www.popsci.com/gear/air-purifier-amazon-deal-cyber-monday-2023)
 - RSS feed: https://www.popsci.com/feed
 - date published: 2023-11-27T10:58:00+00:00

<figure class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="A PuroAir air purifier in a pattern on a plain background" class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="959" src="https://www.popsci.com/uploads/2023/11/26/air-purifier-cyber-monday-deal.jpg?auto=webp&amp;width=1440&amp;height=959.76" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><figcaption class="orgnc-SingleImage-caption"><span class="orgnc-SingleImage-credit">Amanda Reed</span></figcaption></figure><p>Get major savings on air purifiers from BLUEAIR, Levoit, Molekule, and more for Cyber Monday at Amazon. </p>
<p>The post <a href="https://www.popsci.com/gear/air-purifier-amazon-deal-cyber-monday-2023/" rel="nofollow">This best-selling air purifier is at its lowest price of the year for Cyber Monday at Amazon</a> appeared first on <a href="http

## These limited Cyber Monday deals have Jackery generators at their lowest prices of the year
 - [https://www.popsci.com/gear/jackery-solar-generator-amazon-deals-cyber-monday-2023](https://www.popsci.com/gear/jackery-solar-generator-amazon-deals-cyber-monday-2023)
 - RSS feed: https://www.popsci.com/feed
 - date published: 2023-11-27T10:28:00+00:00

<figure class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="Jackery 2000 plus solar generator sitting on a paved driveway" class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="809" src="https://www.popsci.com/uploads/2023/11/26/jackery-cyber-monday-deals.jpg?auto=webp&amp;width=1440&amp;height=809.53846153846" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><figcaption class="orgnc-SingleImage-caption"><span class="orgnc-SingleImage-credit">Stan Horaczek</span></figcaption></figure><p>Whether you need a small portable power station or a massive solar generator, these Cyber Monday deals on Jackery products will save lots of cash.</p>
<p>The post <a href="https://www.popsci.com/gear/jackery-solar-generator-amazon-deals-cyber-monday-2023/" rel="nofollow">These limited Cyber Monday deals have Jackery generators at the

## Ooni’s pizza oven is down to its lowest price ever on Amazon for Cyber Monday
 - [https://www.popsci.com/gear/ooni-pizza-oven-amazon-deal-cyber-monday-2023](https://www.popsci.com/gear/ooni-pizza-oven-amazon-deal-cyber-monday-2023)
 - RSS feed: https://www.popsci.com/feed
 - date published: 2023-11-27T10:13:00+00:00

<figure class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="ooni Fyra 12 Wood Fired Outdoor Pizza Oven" class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="936" src="https://www.popsci.com/uploads/2023/11/27/ooni-Fyra-12-Wood-Fired-Outdoor-Pizza-Oven-1.jpg?auto=webp&amp;width=1440&amp;height=936" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><figcaption class="orgnc-SingleImage-caption"><span class="orgnc-SingleImage-credit">ooni</span></figcaption></figure><p>This discount on the Fyra 12 is a can't-miss deal for anyone who loves homemade pizza.</p>
<p>The post <a href="https://www.popsci.com/gear/ooni-pizza-oven-amazon-deal-cyber-monday-2023/" rel="nofollow">Ooni&#8217;s pizza oven is down to its lowest price ever on Amazon for Cyber Monday</a> appeared first on <a href="https://www.popsci.com" rel="nofollow">

## Score a 75-inch Roku TV for only $450 with this Cyber Monday deal
 - [https://www.popsci.com/gear/best-roku-deals-cyber-monday-2023](https://www.popsci.com/gear/best-roku-deals-cyber-monday-2023)
 - RSS feed: https://www.popsci.com/feed
 - date published: 2023-11-27T09:58:00+00:00

<figure class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="The best Roku Cyber Monday deals" class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="936" src="https://www.popsci.com/uploads/2023/11/27/The-best-Roku-Cyber-Monday-deals.jpg?auto=webp&amp;width=1440&amp;height=936" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><figcaption class="orgnc-SingleImage-caption"><span class="orgnc-SingleImage-credit">Roku</span></figcaption></figure><p>Fulfill all your streaming desires with Roku boxes, TVs, and more during these Cyber Monday sales.</p>
<p>The post <a href="https://www.popsci.com/gear/best-roku-deals-cyber-monday-2023/" rel="nofollow">Score a 75-inch Roku TV for only $450 with this Cyber Monday deal</a> appeared first on <a href="https://www.popsci.com" rel="nofollow">Popular Science</a>.</p>

