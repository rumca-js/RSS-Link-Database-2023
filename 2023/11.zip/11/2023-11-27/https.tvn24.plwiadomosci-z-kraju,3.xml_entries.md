# Source:TVN24 Z kraju, URL:https://tvn24.pl/wiadomosci-z-kraju,3.xml, language:pl-PL

## Karolina Bućko pozytywnie zaopiniowana jako kandydatka do państwowej komisji ds. pedofilii
 - [https://tvn24.pl/polska/komisja-do-spraw-pedofilii-karolina-bucko-pozytywnie-zaopiniowana-przez-sejmowa-komisje-kacper-switkiewicz-negatywnie-7457714?source=rss](https://tvn24.pl/polska/komisja-do-spraw-pedofilii-karolina-bucko-pozytywnie-zaopiniowana-przez-sejmowa-komisje-kacper-switkiewicz-negatywnie-7457714?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T21:18:34+00:00

<img alt="Karolina Bućko pozytywnie zaopiniowana jako kandydatka do państwowej komisji ds. pedofilii" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mbnnyk-karolina-bucko-i-kacper-switkiewicz-podczas-posiedzenia-komisji-sprawiedliwosci-i-praw-czlowieka-7457735/alternates/LANDSCAPE_1280" />
    Sejmowa komisja sprawiedliwości i praw człowieka pozytywnie zaopiniowała kandydaturę Karoliny Bućko na członka państwowej komisji ds. pedofilii, zgłoszoną przez posłów Koalicji Obywatelskiej, Lewicy, Trzeciej Drogi oraz PSL. Natomiast kandydaturę Kacpra Świtkiewicza zaopiniowano negatywnie. Posłowie mają wybrać nowego członka komisji we wtorek.

## "Zaopatrzcie się w popcorn. Polska ma teraz dwa rządy". Europejskie media przyglądają się sytuacji na polskiej scenie politycznej
 - [https://fakty.tvn24.pl/fakty-o-swiecie/zaopatrzcie-sie-w-popcorn-polska-ma-teraz-dwa-rzady-europejskie-media-przygladaja-sie-sytuacji-na-polskiej-scenie-po-st7457721?source=rss](https://fakty.tvn24.pl/fakty-o-swiecie/zaopatrzcie-sie-w-popcorn-polska-ma-teraz-dwa-rzady-europejskie-media-przygladaja-sie-sytuacji-na-polskiej-scenie-po-st7457721?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T20:38:28+00:00

<img alt="" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-cwjhfz-mid-23b27307-7457733/alternates/LANDSCAPE_1280" />
    Zagranicznym mediom trudno jest zrozumieć polityczny scenariusz, realizowany przez Mateusza Morawieckiego. Dlatego w tytułach artykułów opisujących sytuację polityczną w Polsce coraz częściej pojawiają się słowa "farsa" lub "kabaret". Tak nazywany jest manewr mający opóźnić zmianę władzy w Polsce.

## Umowa na budowę parku nad tunelem obwodnicy podpisana, prace ruszą w przyszłym roku
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-umowa-na-budowe-parku-nad-pow-podpisana-jak-bedzie-wygladal-st7457119?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-umowa-na-budowe-parku-nad-pow-podpisana-jak-bedzie-wygladal-st7457119?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T20:26:30+00:00

<img alt="Umowa na budowę parku nad tunelem obwodnicy podpisana, prace ruszą w przyszłym roku" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-ef1p8v-park-linearny-na-ursynowie-%E2%80%93-wkrotce-poczatek-budowy-6784067/alternates/LANDSCAPE_1280" />
    W poniedziałek podpisano umowę na budowę parku linearnego nad tunelem Południowej Obwodnicy Warszawy na Ursynowie, inwestycja obiecywana była od 2016 roku. Park powstanie na 12 hektarach, zakończenie prac przewidziano na 2026 rok, a ich koszt to 43 miliony złotych.

## Awarie w Elektrociepłowni Będzin, niemal do końca tygodnia może być zimno w mieszkaniach
 - [https://tvn24.pl/polska/slaskie-awarie-w-elektrocieplowni-bedzin-zimno-w-mieszkaniach-moze-byc-niemal-do-konca-tygodnia-7457620?source=rss](https://tvn24.pl/polska/slaskie-awarie-w-elektrocieplowni-bedzin-zimno-w-mieszkaniach-moze-byc-niemal-do-konca-tygodnia-7457620?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T19:12:05+00:00

<img alt="Awarie w Elektrociepłowni Będzin, niemal do końca tygodnia może być zimno w mieszkaniach " src="https://tvn24.pl/najnowsze/cdn-zdjecie-tg1lst-drastycznie-wrosnie-cena-oplat-za-miejskie-ogrzewanie-zdj-ilustracyjne-6062448/alternates/LANDSCAPE_1280" />
    W poniedziałek w Elektrociepłowni Będzin, dostarczającej ciepło mieszkańcom Sosnowca, Będzina i Czeladzi, doszło do awarii kotła parowego. Dzień wcześniej zepsuł się wymiennik ciepła. Trwają prace naprawcze, z informacji firmy wynika, że ciepło ma wrócić do mieszkańców pod koniec tygodnia.

## Pogoda na jutro - wtorek 28.11. Nocą nawet -11 stopni na termometrach
 - [https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-jutro-wtorek-2811-noca-nawet-11-stopni-na-termometrach-st7457590?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-jutro-wtorek-2811-noca-nawet-11-stopni-na-termometrach-st7457590?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T18:31:53+00:00

<img alt="Pogoda na jutro - wtorek 28.11. Nocą nawet -11 stopni na termometrach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-utb3hb-mroz-na-szybie-zimno-7457588/alternates/LANDSCAPE_1280" />
    Pogoda na jutro, czyli wtorek, zapowiada się bardzo zimowo. Nocą będzie sypać śnieg, miejscami utworzą się też mgły. Ściśnie mróz. Opady pojawią się także za dnia. Biomet w całej Polsce okaże się niekorzystny.

## Chorwacja. Pierwszy śnieg w Dalmacji sprawił trudność kierowcom
 - [https://tvn24.pl/tvnmeteo/swiat/chorwacja-pierwszy-snieg-w-dalmacji-sprawil-trudnosc-kierowcom-st7457429?source=rss](https://tvn24.pl/tvnmeteo/swiat/chorwacja-pierwszy-snieg-w-dalmacji-sprawil-trudnosc-kierowcom-st7457429?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T17:23:47+00:00

<img alt="Chorwacja. Pierwszy śnieg w Dalmacji sprawił trudność kierowcom" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-gthzg4-snieg-w-dalmacji-7457439/alternates/LANDSCAPE_1280" />
    Poniedziałek w chorwackiej części Dalmacji powitał kierowców opadami śniegu, pierwszymi tej jesieni w tym regionie. Nie był to jednak miły początek tygodnia - kierowcy musieli liczyć się z utrudnieniami.

## Mają 15 i osiem lat, w niewoli Hamasu przeżyły koszmar. "Moje drogie córki wróciły do mnie"
 - [https://tvn24.pl/swiat/izrael-hamas-uwolnil-15-letnia-dafne-i-osmioletnia-elle-moje-drogie-corki-wrocily-do-mnie-7457345?source=rss](https://tvn24.pl/swiat/izrael-hamas-uwolnil-15-letnia-dafne-i-osmioletnia-elle-moje-drogie-corki-wrocily-do-mnie-7457345?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T17:07:02+00:00

<img alt="Mają 15 i osiem lat, w niewoli Hamasu przeżyły koszmar. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-gw49m4-sklejka1b-7457455/alternates/LANDSCAPE_1280" />
    15-letnia Dafna i ośmioletnia 8-letnia Ella spędziły w niewoli Hamasu przeszło 50 dni. W niedzielę zostały uwolnione. Matka dziewczynek, Maayan Ziv, spotkała się z nimi w izraelskiej bazie wojskowej.

## Pięć samochodów zniszczonych i przewrócona latarnia
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-zderzenie-na-wale-miedzeszynskim-utworzyl-sie-duzy-korek-st7457387?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-zderzenie-na-wale-miedzeszynskim-utworzyl-sie-duzy-korek-st7457387?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T16:32:05+00:00

<img alt="Pięć samochodów zniszczonych i przewrócona latarnia" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-ovn3ae-zderzenie-na-wale-miedzeszynskim-7457402/alternates/LANDSCAPE_1280" />
    Pięć samochodów zderzyło się na Wale Miedzeszyńskim. Pojazdy są mocno zniszczone. Są duże utrudnienia w kierunku Otwocka.

## Nagrody last minute. Jest projekt rozporządzenia
 - [https://tvn24.pl/biznes/z-kraju/nagrody-dla-dyrektorow-projekt-rozporzadzenia-ministra-infrastruktury-st7457260?source=rss](https://tvn24.pl/biznes/z-kraju/nagrody-dla-dyrektorow-projekt-rozporzadzenia-ministra-infrastruktury-st7457260?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T16:22:36+00:00

<img alt="Nagrody last minute. Jest projekt rozporządzenia" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kazpl8-pap_20221013_1ev-6178055/alternates/LANDSCAPE_1280" />
    Specjalne nagrody dla dyrektorów przedsiębiorstw państwowych z zakresu gospodarki morskiej - to przewiduje projekt rozporządzenia ministra infrastruktury, który pojawił się na stronie Rządowego Centrum Legislacji (RCL). Odpowiedzialny za projekt jest wiceminister Marek Gróbarczyk.

## Profesor Stefan Chwin wspomina Pawła Huellego: brak takiej osobowości jest też osobistą krzywdą
 - [https://tvn24.pl/polska/pawel-huelle-nie-zyje-wspomina-go-profesor-stefan-chwin-7457102?source=rss](https://tvn24.pl/polska/pawel-huelle-nie-zyje-wspomina-go-profesor-stefan-chwin-7457102?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T15:28:50+00:00

<img alt="Profesor Stefan Chwin wspomina Pawła Huellego: brak takiej osobowości jest też osobistą krzywdą " src="https://tvn24.pl/najnowsze/cdn-zdjecie-itzb3l-forum-0429504937-7457133/alternates/LANDSCAPE_1280" />
    Myśmy stworzyli zjawisko, które do historii literatury przeszło pod nazwą gdańska szkoła prozy w literaturze polskiej, więc ten temat nas połączył - mówił profesor Stefan Chwin pisarz, krytyk literacki, eseista, historyk literatury wspominając zmarłego Pawła Huellego. - On położył wielkie zasługi w tym, co ja nazywam renesansem gdańskiej tożsamości po roku 1989 - dodał.

## Zmienili tekst "najbardziej kontrowersyjnej piosenki wszech czasów"
 - [https://tvn24.pl/kultura-i-styl/muzyka-zespol-the-prodigy-zmienil-tekst-najbardziej-kontrowersyjnej-piosenki-wszech-czasow-7457051?source=rss](https://tvn24.pl/kultura-i-styl/muzyka-zespol-the-prodigy-zmienil-tekst-najbardziej-kontrowersyjnej-piosenki-wszech-czasow-7457051?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T15:22:23+00:00

<img alt="Zmienili tekst " src="https://tvn24.pl/najnowsze/cdn-zdjecie-fna10w-koncert-the-prodigy-w-brighton-20-listopada-2023-r-7457231/alternates/LANDSCAPE_1280" />
    The Prodigy po 26 latach zmieniło tekst swojego kontrowersyjnego przeboju "Smack My Bitch Up", informują brytyjskie media, relacjonując ostatnie występy grupy. Jednocześnie przypominają, że utwór, krytykowany między innymi przez artystów i organizacje kobiece, przed laty został wybrany najbardziej kontrowersyjną piosenką wszech czasów.

## Kierowca tira usłyszał niepokojące dźwięki, w naczepie ukrywało się 13 osób
 - [https://tvn24.pl/tvnwarszawa/najnowsze/mazowieckie-straz-graniczna-zatrzymala-13-imigrantow-podrozowali-w-naczepie-tira-st7457045?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/mazowieckie-straz-graniczna-zatrzymala-13-imigrantow-podrozowali-w-naczepie-tira-st7457045?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T15:21:52+00:00

<img alt="Kierowca tira usłyszał niepokojące dźwięki, w naczepie ukrywało się 13 osób " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-r0kuma-interweniowala-straz-graniczna-zdjecie-ilustracyjne-7457066/alternates/LANDSCAPE_1280" />
    Kierowca tira zatrzymał się na postój. Wtedy usłyszał niepokojące dźwięki, dochodzące z wnętrza pojazdu. Na miejsce przyjechali funkcjonariusze z placówki Straży Granicznej Warszawa-Modlin wraz z policjantami z Wołomina. W naczepie tira ukrywało się 13 osób.

## Okupanci na Krymie przeżyli "armagedon"
 - [https://tvn24.pl/swiat/okupanci-na-krymie-przezyli-armagedon-7456972?source=rss](https://tvn24.pl/swiat/okupanci-na-krymie-przezyli-armagedon-7456972?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T15:20:04+00:00

<img alt="Okupanci na Krymie przeżyli " src="https://tvn24.pl/najnowsze/cdn-zdjecie-59jbl9-pogoda-krym-7457037/alternates/LANDSCAPE_1280" />
    - Przeżyliśmy armagedon: takiej siły wiatru i fal nie pamiętają tutejsi najstarsi mieszkańcy - stwierdził szef parlamentu na zaanektowanym Krymie Władimir Konstantinow. Okupowany półwysep nawiedziła sztormowa pogoda. Prawie 400 tysięcy mieszkańców zostało bez prądu. Na Telegramie pojawią się informacje, że fale zmyły wojskowe okopy na plażach i unieruchomiły okręty.

## Zderzenie autobusu z taksówką, reanimowano jedną osobę
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-zderzenie-samochodu-i-autobusu-w-alei-stanow-zjednoczonych-sa-utrudnienia-st7457153?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-zderzenie-samochodu-i-autobusu-w-alei-stanow-zjednoczonych-sa-utrudnienia-st7457153?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T14:49:46+00:00

<img alt="Zderzenie autobusu z taksówką, reanimowano jedną osobę " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-tqcu5-zderzenie-w-alei-stanow-zjednoczonych-7457178/alternates/LANDSCAPE_1280" />
    W alei Stanów Zjednoczonych zderzyły się taksówka i autobus. Do wypadku doszło na nitce, którą mogą się poruszać tylko pojazdy komunikacji. Do szpitala trafił 85-letni  kierowca toyoty. Oba pojazdy są mocno zniszczone. Są utrudnienia.

## Sprawy o bezumowne korzystanie z kapitału. "Skala działań banków jest coraz większa"
 - [https://tvn24.pl/biznes/z-kraju/kredyty-bezumowne-korzystanie-z-kapitalu-liczba-rozpraw-ile-wygranych-dane-st7457083?source=rss](https://tvn24.pl/biznes/z-kraju/kredyty-bezumowne-korzystanie-z-kapitalu-liczba-rozpraw-ile-wygranych-dane-st7457083?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T14:46:53+00:00

<img alt="Sprawy o bezumowne korzystanie z kapitału. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-tiy00n-bank-4732042/alternates/LANDSCAPE_1280" />
    Kredytobiorcy wygrywają z bankami w sprawach o bezumowne korzystanie z kapitału i waloryzację około 97 procent spraw - wynika z danych zebranych i przygotowanych przez kancelarię Votum Robin Lawyers. Prawnicy podkreślają, że "skala działań banków jest coraz większa", co wpływa na liczbę rozstrzyganych przez sądy spraw, które po czerwcowym wyroku przyśpieszyły rozpatrywanie bankowych powództw.

## Pijany kierowca staranował ogrodzenie przy przystanku tramwajowym
 - [https://tvn24.pl/krakow/krakow-wjechal-w-przystanek-byl-pijany-7457053?source=rss](https://tvn24.pl/krakow/krakow-wjechal-w-przystanek-byl-pijany-7457053?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T14:26:43+00:00

<img alt="Pijany kierowca staranował ogrodzenie przy przystanku tramwajowym" src="https://tvn24.pl/krakow/cdn-zdjecie-ruk8xl-kierowca-wjechal-w-przystanek-7457056/alternates/LANDSCAPE_1280" />
    Kierowca subaru wjechał w przystanek tramwajowy w Krakowie. Jak się okazało, mężczyzna był pijany. Grozi mu więzienie.

## Miller: konstruktywne wotum nieufności "natychmiast po zaprzysiężeniu rządu". Prawnicy przestrzegają
 - [https://konkret24.tvn24.pl/polityka/miller-konstruktywne-wotum-nieufnosci-natychmiast-po-zaprzysiezeniu-rzadu-prawnicy-przestrzegaja-st7456490?source=rss](https://konkret24.tvn24.pl/polityka/miller-konstruktywne-wotum-nieufnosci-natychmiast-po-zaprzysiezeniu-rzadu-prawnicy-przestrzegaja-st7456490?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T14:13:00+00:00

<img alt="Miller: konstruktywne wotum nieufności " src="https://tvn24.pl/najnowsze/cdn-zdjecie-82gfx6-leszek-miller-7456494/alternates/LANDSCAPE_1280" />
    Według byłego premiera można skrócić okres rządów Mateusza Morawieckiego i nowej Rady Ministrów i w to miejsce szybciej powołać Donalda Tuska i jego rząd - wystarczy zastosować procedurę konstruktywnego wotum nieufności. Konstytucjonaliści mają bardzo duże wątpliwości.

## Sejm we wtorek. Powołanie Rzecznika Praw Dziecka i nowe komisje śledcze
 - [https://tvn24.pl/polska/sejm-we-wtorek-i-srode-plan-obrad-posiedzenia-7457019?source=rss](https://tvn24.pl/polska/sejm-we-wtorek-i-srode-plan-obrad-posiedzenia-7457019?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T14:11:03+00:00

<img alt="Sejm we wtorek. Powołanie Rzecznika Praw Dziecka i nowe komisje śledcze" src="https://tvn24.pl/najnowsze/cdn-zdjecie-tg0je1-sejm-7450072/alternates/LANDSCAPE_1280" />
    Wtorek to kolejny dzień pierwszego posiedzenia Sejmu X kadencji. Posłowie mają m.in. powołać Rzecznika Praw Dziecka i członka komisji ds. pedofilii. W harmonogramie obrad przewidziano też debatę nad trzema projektami powołującymi komisje śledcze. Co jeszcze? Oto harmonogram obrad.

## Nowe prawo miało ratować tysiące żyć. Będzie cofnięte, by obniżyć podatki
 - [https://tvn24.pl/swiat/nowa-zelandia-zakaz-sprzedazy-papierosow-bedzie-cofniety-by-obnizyc-podatki-7457005?source=rss](https://tvn24.pl/swiat/nowa-zelandia-zakaz-sprzedazy-papierosow-bedzie-cofniety-by-obnizyc-podatki-7457005?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T13:56:22+00:00

<img alt="Nowe prawo miało ratować tysiące żyć. Będzie cofnięte, by obniżyć podatki" src="https://tvn24.pl/najnowsze/cdn-zdjecie-plk8op-papieros-palenie-papierosow-7376375/alternates/LANDSCAPE_1280" />
    Uformowany w ubiegłym tygodniu rząd Nowej Zelandii wycofuje się z pionierskich regulacji eliminujących palenie tytoniu - informuje brytyjski "Guardian". Powodem zmiany ma być konieczność znalezienia środków na sfinansowanie obniżki podatków. Zapowiedź spotkała się z krytyką ze strony ekspertów oraz organizacji prozdrowotnych.

## Z banku znikały pieniądze. Kasjer podejrzany o przywłaszczenie niemal 400 tysięcy złotych
 - [https://tvn24.pl/trojmiasto/sopot-kasjer-podejrzany-o-przywlaszczenie-niemal-400-tysiecy-zlotych-mial-je-przegrac-w-zakladach-bukmacherskich-7456968?source=rss](https://tvn24.pl/trojmiasto/sopot-kasjer-podejrzany-o-przywlaszczenie-niemal-400-tysiecy-zlotych-mial-je-przegrac-w-zakladach-bukmacherskich-7456968?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T13:50:32+00:00

<img alt="Z banku znikały pieniądze. Kasjer podejrzany o przywłaszczenie niemal 400 tysięcy złotych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kxx6zn-mezczyznie-grozi-do-10-lat-wiezienia-7456940/alternates/LANDSCAPE_1280" />
    Ze skrytki bankowej placówki w Sopocie znikały pieniądze. W sumie niemal 400 tysięcy złotych. Jak informuje policja, gotówkę zabierał kasjer. Mundurowym miał przyznać, że przeznaczał ją na zakłady bukmacherskie i "praktycznie wszystkie pieniądze przegrał". Usłyszał zarzuty.

## Trzy niepokojące objawy. Naukowcy zbadali, co się z nami dzieje podczas wideokonferencji
 - [https://tvn24.pl/ciekawostki/praca-zdalna-trzy-nieprzyjemne-objawy-naukowcy-zbadali-co-sie-dzieje-w-naszym-mozgu-podczas-wideokonferencji-7456696?source=rss](https://tvn24.pl/ciekawostki/praca-zdalna-trzy-nieprzyjemne-objawy-naukowcy-zbadali-co-sie-dzieje-w-naszym-mozgu-podczas-wideokonferencji-7456696?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T13:50:27+00:00

<img alt="Trzy niepokojące objawy. Naukowcy zbadali, co się z nami dzieje podczas wideokonferencji" src="https://tvn24.pl/najnowsze/cdn-zdjecie-r9blib-zoom-wideokonferencja-5164324/alternates/LANDSCAPE_1280" />
    Nowe badania ukazują "ciemne strony" uczestniczenia w wideokonferencjach na popularnych platformach internetowych. Ich konsekwencje "wykraczają daleko poza zwykłe zmęczenie" - podkreślają naukowcy. I wskazują, co zrobić, by zmęczenie spowodowane wideokonferencjami było mniejsze.

## Ukradły mysz z klatką i biżuterię. Nastolatki zatrzymane przez policję
 - [https://tvn24.pl/tvnwarszawa/zoliborz/warszawa-nastolatki-ukradly-mysz-z-klatka-i-bizuterie-zatrzymala-je-policja-st7456984?source=rss](https://tvn24.pl/tvnwarszawa/zoliborz/warszawa-nastolatki-ukradly-mysz-z-klatka-i-bizuterie-zatrzymala-je-policja-st7456984?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T13:34:14+00:00

<img alt="Ukradły mysz z klatką i biżuterię. Nastolatki zatrzymane przez policję " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-c32ies-nastolatki-ukradly-mysz-hodowlana-7456997/alternates/LANDSCAPE_1280" />
    Dwie nastolatki przebywające w Pogotowiu Opiekuńczym ukradły mysz hodowlaną wraz z klatką i pożywieniem, oprócz tego pierścionki i łańcuszek. 14-latkę i 16-latkę zatrzymali policjanci z Żoliborza. Obie już zostały przesłuchane.

## Dwa auta zderzyły się pod wiaduktem trasy ekspresowej. Mają wyłamane koła
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-dwa-auta-zderzyly-sie-pod-wiaduktem-trasy-ekspresowej-maja-wylamane-kola-st7456833?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-dwa-auta-zderzyly-sie-pod-wiaduktem-trasy-ekspresowej-maja-wylamane-kola-st7456833?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T13:28:48+00:00

<img alt="Dwa auta zderzyły się pod wiaduktem trasy ekspresowej. Mają wyłamane koła" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-bp4avo-zderzenie-w-alei-krakowskiej-7456844/alternates/LANDSCAPE_1280" />
    Do zderzenia dwóch aut osobowych w alei Krakowskiej pod trasą S2. Jedna osoba jest poszkodowana.

## Po zderzeniu auta z autobusem w alei Wilanowskiej zmarła jedna osoba. Jest prokuratorskie śledztwo
 - [https://tvn24.pl/tvnwarszawa/mokotow/warszawa-po-zderzeniu-auta-z-autobusem-w-alei-wilanowskiej-zmarla-jedna-osoba-jest-sledztwo-st7456947?source=rss](https://tvn24.pl/tvnwarszawa/mokotow/warszawa-po-zderzeniu-auta-z-autobusem-w-alei-wilanowskiej-zmarla-jedna-osoba-jest-sledztwo-st7456947?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T13:26:53+00:00

<img alt="Po zderzeniu auta z autobusem w alei Wilanowskiej zmarła jedna osoba. Jest prokuratorskie śledztwo" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-jxau9w-zderzenie-w-alei-wilanowskiej-7449789/alternates/LANDSCAPE_1280" />
    W szpitalu zmarła jedna osoba ranna po zderzeniu samochodu osobowego z autobusem miejskim w alei Wilanowskiej. Prokuratura wszczęła śledztwo w sprawie spowodowania wypadku. Śledczy analizują między innymi nagrania z monitoringu i przesłuchują świadków.

## Łódź się przewróciła, nie żyją cztery osoby. Zarzut dla armatora
 - [https://tvn24.pl/trojmiasto/gdansk-zarzut-dla-armatora-galara-gdanskiego-i-lodz-sie-przewrocila-zginely-cztery-osoby-7457010?source=rss](https://tvn24.pl/trojmiasto/gdansk-zarzut-dla-armatora-galara-gdanskiego-i-lodz-sie-przewrocila-zginely-cztery-osoby-7457010?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T13:17:08+00:00

<img alt="Łódź się przewróciła, nie żyją cztery osoby. Zarzut dla armatora " src="https://tvn24.pl/najnowsze/cdn-zdjecie-3g9n82-wywrocona-lodz-na-motlawie-6153879/alternates/LANDSCAPE_1280" />
    Zarzut dla armatora łodzi, która w październiku 2022 roku przewróciła się na wodach Kanału Kaszubskiego. Zdaniem prokuratury przyczynił się do umyślnego sprowadzenia katastrofy w ruchu wodnym. Zginęły cztery osoby, w tym kobieta w zaawansowanej ciąży.

## "Niby Warszawa, ale jak zamierzchła wieś". Nie mogą doprosić się o chodnik
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-mieszkancy-szamocin-domagaja-sie-budowy-chodnika-droga-prowadzaca-do-centrum-dzielnicy-jest-niebezpieczna-st7452098?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-mieszkancy-szamocin-domagaja-sie-budowy-chodnika-droga-prowadzaca-do-centrum-dzielnicy-jest-niebezpieczna-st7452098?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T12:48:42+00:00

<img alt="" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-9i7tgw-ulica-waluszewska-i-szamocin-7454731/alternates/LANDSCAPE_1280" />
    Na białołęckim Szamocinie najkrótsza droga do szkoły i sklepów jest wąska, ciemna i pozbawiona chodników. Mieszkańcy boją się o swoje bezpieczeństwo i domagają zmian. Walczą o to od lat.

## Mężczyzna raniony ostrym narzędziem. Policja zabezpieczyła "substancje zabronione"
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-mezczyzna-raniony-ostrym-narzedziem-policja-zabezpieczyla-substancje-zabronione-st7456632?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-mezczyzna-raniony-ostrym-narzedziem-policja-zabezpieczyla-substancje-zabronione-st7456632?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T11:52:51+00:00

<img alt="Mężczyzna raniony ostrym narzędziem. Policja zabezpieczyła " src="https://tvn24.pl/najnowsze/cdn-zdjecie-zin4fx-policja-ustala-szczegoly-zdarzenia-zdjecie-ilustracyjne-6552615/alternates/LANDSCAPE_1280" />
    W niedzielę wieczorem do jednego ze stołecznych szpitali przewieziono mężczyznę z raną ciętą szyi. Policja zatrzymała do sprawy jedną osobę. Zabezpieczono też "substancje prawdopodobnie zabronione".

## Transpłciowa nastolatka zamordowana w parku. Rusza proces oskarżonych, to jej rówieśnicy
 - [https://tvn24.pl/swiat/anglia-morderstwo-brianny-ghey-rusza-proces-oskarzonych-16-latkow-7456741?source=rss](https://tvn24.pl/swiat/anglia-morderstwo-brianny-ghey-rusza-proces-oskarzonych-16-latkow-7456741?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T11:49:49+00:00

<img alt="Transpłciowa nastolatka zamordowana w parku. Rusza proces oskarżonych, to jej rówieśnicy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1sfb4s-zamordowana-16-letnia-brianna-ghey-6755424/alternates/LANDSCAPE_1280" />
    W poniedziałek rozpoczyna się proces dwojga nastolatków, którym postawiono zarzut zabójstwa 16-letniej Brianny Ghey spod Manchesteru, identyfikującej się jako osoba transpłciowa - informuje "Independent". Oskarżeni nie przyznają się do winy.

## Awaria rozjazdów w Legionowie. Utrudnienia w kursowaniu pociągów Kolei Mazowieckich i SKM
 - [https://tvn24.pl/tvnwarszawa/okolice/legionowo-awaria-i-utrudnienia-w-kursowaniu-pociagow-kolei-mazowieckich-i-skm-st7456845?source=rss](https://tvn24.pl/tvnwarszawa/okolice/legionowo-awaria-i-utrudnienia-w-kursowaniu-pociagow-kolei-mazowieckich-i-skm-st7456845?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T11:48:50+00:00

<img alt="Awaria rozjazdów w Legionowie. Utrudnienia w kursowaniu pociągów Kolei Mazowieckich i SKM" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-dz8zre-utrudnienia-w-kursowaniu-pociagow-kolei-mazowieckich-i-skm-zdj-ilustracyjne-7456848/alternates/LANDSCAPE_1280" />
    Warszawski Transport Publiczny przestrzega przed utrudnieniami w kursowaniu pociągów Kolei Mazowieckich i Szybkiej Kolei Miejskiej. Opóźnienia są spowodowane awarią na stacji w Legionowie.

## Inowrocław nadal bez komisarza. "Lekceważące niewypełnienie ustawowego obowiązku"
 - [https://tvn24.pl/kujawsko-pomorskie/inowroclaw-ponad-miesiac-po-wyborach-miasto-wciaz-nie-ma-komisarza-byly-prezydent-ryszard-brejza-komentuje-7456761?source=rss](https://tvn24.pl/kujawsko-pomorskie/inowroclaw-ponad-miesiac-po-wyborach-miasto-wciaz-nie-ma-komisarza-byly-prezydent-ryszard-brejza-komentuje-7456761?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T11:33:32+00:00

<img alt="Inowrocław nadal bez komisarza. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-lunozy-inowroclaw-bez-gazu-7454390/alternates/LANDSCAPE_1280" />
    Podczas wyborów parlamentarnych Ryszard Brejza, dotychczasowy prezydent Inowrocławia (woj. kujawsko-pomorskie), został wybrany na senatora. Automatycznie zakończyło to jego prezydenturę oraz urzędowanie wiceprezydentów miasta. Mimo że od wyborów minął ponad miesiąc, premier Mateusz Morawiecki nadal nie powołał komisarza dla Inowrocławia.

## WHO chciało wyjaśnień w sprawie nowej fali zachorowań. Odpowiedź Chin
 - [https://tvn24.pl/swiat/chiny-wzrost-chorob-ukladu-oddechowego-powoduja-znane-juz-patogeny-w-tym-wirus-grypy-odpowiedz-do-who-7456636?source=rss](https://tvn24.pl/swiat/chiny-wzrost-chorob-ukladu-oddechowego-powoduja-znane-juz-patogeny-w-tym-wirus-grypy-odpowiedz-do-who-7456636?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T11:26:29+00:00

<img alt="WHO chciało wyjaśnień w sprawie nowej fali zachorowań. Odpowiedź Chin" src="https://tvn24.pl/najnowsze/cdn-zdjecie-axmfpe-wzrost-zachorowan-na-choroby-ukladu-oddechowego-w-chinach-7456621/alternates/LANDSCAPE_1280" />
    Wzrost zachorowań dzieci na choroby układu oddechowego w Chinach jest spowodowany jednoczesnym występowaniem kilku znanych już patogenów, między innymi wirusa grypy - przekazał rzecznik chińskiego ministerstwa zdrowia. W ten sposób Pekin odpowiedział na apel Światowej Organizacji Zdrowia o informacje na temat niewyjaśnionych przypadków zapalenia płuc u najmłodszych na północy kraju.

## Kiedy kierowca spał, wybijali szybę i kradli
 - [https://tvn24.pl/tvnwarszawa/najnowsze/mazowsze-policja-zatrzymala-troje-podejrzanych-o-okradanie-kierowcow-st7456701?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/mazowsze-policja-zatrzymala-troje-podejrzanych-o-okradanie-kierowcow-st7456701?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T11:14:44+00:00

<img alt="Kiedy kierowca spał, wybijali szybę i kradli" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-u4t3kn-policja-zatrzymala-podejrzanych-o-okradanie-kierowcow-7456755/alternates/LANDSCAPE_1280" />
    Policja zatrzymała trzy osoby podejrzane o okradanie kierowców odpoczywających na parkingach przy drogach szybkiego ruchu. Grozi im do 10 lat więzienia.

## Grecy domagają się od Wielkiej Brytanii zwrotu słynnych rzeźb z Partenonu. "Zostały zasadniczo skradzione"
 - [https://tvn24.pl/swiat/wielka-brytania-grecy-chca-zwrotu-rzezb-z-partenonu-7456198?source=rss](https://tvn24.pl/swiat/wielka-brytania-grecy-chca-zwrotu-rzezb-z-partenonu-7456198?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T11:04:06+00:00

<img alt="Grecy domagają się od Wielkiej Brytanii zwrotu słynnych rzeźb z Partenonu. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-qlnmi7-shutterstock_2229534571-7456734/alternates/LANDSCAPE_1280" />
    - Uważamy, że rzeźby należą do Grecji i że zostały zasadniczo skradzione - powiedział w niedzielę w wywiadzie dla BBC premier Grecji Kyriakos Micotakis o greckich rzeźbach z Partenonu, które znajdują się w Muzeum Brytyjskim. W zeszłym roku trzy fragmenty Partenonu zwrócił Watykan.

## Nie zatrzymał się do kontroli, zderzył się z radiowozem. Nie miał prawa jazdy
 - [https://tvn24.pl/szczecin/koszalin-podczas-ucieczki-przed-policyjna-kontrola-uderzyl-w-radiowoz-7456599?source=rss](https://tvn24.pl/szczecin/koszalin-podczas-ucieczki-przed-policyjna-kontrola-uderzyl-w-radiowoz-7456599?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T11:02:10+00:00

<img alt="Nie zatrzymał się do kontroli, zderzył się z radiowozem. Nie miał prawa jazdy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ctry9x-mezczyzna-byl-trzezwy-i-nie-posiadal-prawa-jazdy-7456575/alternates/LANDSCAPE_1280" />
    Kierowca chciał uniknąć kontroli drogowej i zaczął uciekać przed policjantami z Koszalina (woj. zachodniopomorskie). Doprowadził do kolizji z radiowozem i innym samochodem. Był trzeźwy, ale nie posiadał prawa jazdy. Teraz grozi mu do pięciu lat więzienia.

## "Rząd pana premiera Donalda Tuska, jeśli chodzi o ministrów, jest w 100 procentach zamknięty"
 - [https://tvn24.pl/polska/donald-tusk-szykuje-sie-na-premiera-marcin-kierwinski-jesli-chodzi-o-ministrow-rzad-jest-w-100-procentach-zamkniety-7456661?source=rss](https://tvn24.pl/polska/donald-tusk-szykuje-sie-na-premiera-marcin-kierwinski-jesli-chodzi-o-ministrow-rzad-jest-w-100-procentach-zamkniety-7456661?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T10:46:59+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6z8wkl-donald-tusk-7444305/alternates/LANDSCAPE_1280" />
    Rząd Donalda Tuska jest w 100 procentach zamknięty, jeśli chodzi o ministrów. Tusk sam ogłosi, kto w tym gabinecie będzie - poinformował Marcin Kierwiński, poseł Koalicji Obywatelskiej, sekretarz generalny Platformy Obywatelskiej.

## "Chcę udowodnić pani od matematyki, że nie skończę na kopaniu rowów". Kim jest zwycięzca "Top Model"?
 - [https://tvn24.pl/kultura-i-styl/top-model-dominik-szymanski-chce-udowodnic-pani-od-matematyki-ze-nie-skoncze-na-kopaniu-rowow-7456639?source=rss](https://tvn24.pl/kultura-i-styl/top-model-dominik-szymanski-chce-udowodnic-pani-od-matematyki-ze-nie-skoncze-na-kopaniu-rowow-7456639?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T10:37:47+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1m4h77-top-model-12-final-7456625/alternates/LANDSCAPE_1280" />
    Zwycięzcą 12. edycji "Top Model" został Dominik Szymański. Zdobył 200 tysięcy złotych i kontrakt z agencją Selective Management. Jego zdjęcie ukaże się też na okładce magazynu "Glamour". - Bałem się troszkę na początku, że Dominik to będzie taka typowa smutna historia. Ale to jest superchłopak. Po to robimy ten program, żeby dać szansę takim ludziom - mówił Marcin Tyszka, juror programu. Finał "Top Model" można oglądać w Playerze.

## Rzucił w niego krzesłem, a potem uderzył. Pan Marek zmarł po trzech tygodniach. Co się wydarzyło w osiedlowym pubie?
 - [https://tvn24.pl/kujawsko-pomorskie/torun-rzucil-w-niego-krzeslem-i-uderzyl-pan-marek-zmarl-po-trzech-tygodniach-co-sie-wydarzylo-w-osiedlowym-pubie-7452541?source=rss](https://tvn24.pl/kujawsko-pomorskie/torun-rzucil-w-niego-krzeslem-i-uderzyl-pan-marek-zmarl-po-trzech-tygodniach-co-sie-wydarzylo-w-osiedlowym-pubie-7452541?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T10:35:10+00:00

<img alt="Rzucił w niego krzesłem, a potem uderzył. Pan Marek zmarł po trzech tygodniach. Co się wydarzyło w osiedlowym pubie?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-oifqyk-do-pobicia-doszlo-w-osiedlowym-pubie-7456468/alternates/LANDSCAPE_1280" />
    W połowie kwietnia w jednym z osiedlowych pubów w Toruniu (woj. kujawsko-pomorskie) rozegrała się tragedia. W ogródku piwnym 23-latek zaatakował 51-letniego  Marka R. Najpierw rzucił w niego krzesłem, a później uderzył. Mężczyzna stracił przytomność, trafił do szpitala, gdzie po trzech tygodniach zmarł. Teraz Adriana Ciechackiego organy ścigania poszukują listem gończym.

## Holenderska policja musi zwrócić właścicielowi tonę materiałów do produkcji narkotyków
 - [https://tvn24.pl/swiat/holandia-policja-musi-zwrocic-wlascicielowi-tone-materialow-do-produkcji-narkotykow-7456478?source=rss](https://tvn24.pl/swiat/holandia-policja-musi-zwrocic-wlascicielowi-tone-materialow-do-produkcji-narkotykow-7456478?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T10:31:23+00:00

<img alt="Holenderska policja musi zwrócić właścicielowi tonę materiałów do produkcji narkotyków  " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ikh0hq-narkotyki-7364246/alternates/LANDSCAPE_1280" />
    Holenderska policja musi zwrócić właścicielowi ponad 1100 kilogramów zarekwirowanych materiałów do produkcji narkotyków - informuje holenderski dziennik "De Telegraaf". Jak wyjaśniono, w ich składzie nie znaleziono bowiem żadnej z substancji wskazanych przez przepisy antynarkotykowe. Zdaniem lokalnych władz przestępcy skutecznie obchodzą te przepisy, wykorzystując do produkcji narkotyków substancje minimalnie różniące się od tych zakazanych.

## Załamanie pogody w Ukrainie. Zaspy śnieżne wznoszą się na dwa metry
 - [https://tvn24.pl/tvnmeteo/swiat/ukraina-zalamanie-pogody-w-ukrainie-zaspy-sniezne-siegaja-dwoch-metrow-st7456542?source=rss](https://tvn24.pl/tvnmeteo/swiat/ukraina-zalamanie-pogody-w-ukrainie-zaspy-sniezne-siegaja-dwoch-metrow-st7456542?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T10:28:39+00:00

<img alt="Załamanie pogody w Ukrainie. Zaspy śnieżne wznoszą się na dwa metry" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9gdgqx-zasypana-ukraina-7456602/alternates/LANDSCAPE_1280" />
    Ukrainę nawiedziły intensywne opady śniegu. Jak przekazały władze, ponad dwa tysiące miejscowości jest pozbawionych prądu. Ponadto na Krymie, i nie tylko, rozszalały się sztormy.

## Śnieżyce w Ukrainie. 13 osób zostało rannych, ciężarówki toną w zaspach
 - [https://tvn24.pl/tvnmeteo/swiat/ukraina-sniezyce-13-osob-rannych-wiele-miejscowosci-bez-pradu-st7456542?source=rss](https://tvn24.pl/tvnmeteo/swiat/ukraina-sniezyce-13-osob-rannych-wiele-miejscowosci-bez-pradu-st7456542?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T10:28:39+00:00

<img alt="Śnieżyce w Ukrainie. 13 osób zostało rannych, ciężarówki toną w zaspach" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-ichwf2-ukraina-7457276/alternates/LANDSCAPE_1280" />
    Ukrainę nawiedziły intensywne opady śniegu. 13 osób zostało rannych, w tym osiem doznało objawów hipotermii. W zaspach utknęło prawie 1700 ciężarówek. Jak przekazały władze, ponad półtora tysiąca miejscowości nadal jest pozbawionych prądu. Ponadto na Krymie, i nie tylko, rozszalały się sztormy.

## NIK rusza z kontrolą. "Niepokojące doniesienia"
 - [https://tvn24.pl/biznes/z-kraju/nik-kontrola-dorazna-w-parp-polskiej-agencji-rozwoju-przedsiebiorczosci-niepokojace-doniesienia-st7456569?source=rss](https://tvn24.pl/biznes/z-kraju/nik-kontrola-dorazna-w-parp-polskiej-agencji-rozwoju-przedsiebiorczosci-niepokojace-doniesienia-st7456569?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T10:27:01+00:00

<img alt="NIK rusza z kontrolą. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-97f9uk-pap_20230928_0gv-7456654/alternates/LANDSCAPE_1280" />
    Najwyższa Izba Kontroli rozpoczyna kontrolę doraźną w Polskiej Agencji Rozwoju Przedsiębiorczości - przekazała NIK. Wyjaśniono, że jest to efekt "niepokojących" doniesień mediów, które pojawiły się w ostatnich dniach.

## Ranny żubr ponad dobę leżał w rowie, zwierzę nie przeżyło. "Sytuacja była trudna, bo wydarzyła się w weekend"
 - [https://tvn24.pl/lublin/kalilow-biala-podlaska-ranny-zubr-przez-weekend-lezal-w-rowie-zwierze-nie-przezylo-7456369?source=rss](https://tvn24.pl/lublin/kalilow-biala-podlaska-ranny-zubr-przez-weekend-lezal-w-rowie-zwierze-nie-przezylo-7456369?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T10:24:05+00:00

<img alt="Ranny żubr ponad dobę leżał w rowie, zwierzę nie przeżyło. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-uclczs-ranny-zubr-lezal-przy-drodze-zabezpieczali-go-strazacy-7456523/alternates/LANDSCAPE_1280" />
    Nie udało się uratować rannego żubra, którego znaleziono w rowie przy drodze pożarowej w miejscowości Kaliłów niedaleko Białej Podlaskiej (woj. lubelskie). Zwierzę - które zauważono w sobotę - miało wyłamaną kończynę. - Sytuacja była trudna, bo wydarzyła się w weekend, kiedy urzędy nie działają - powiedział nam przedstawiciel gminy Biała Podlaska. Lekarz weterynarii pobierze próbki do badań, żeby ustalić przyczynę śmierci zwierzęcia.

## Co z czwartą turą uwalniania zakładników? "Istnieje drobny problem"
 - [https://tvn24.pl/swiat/izrael-wojna-w-hamasem-zawieszenie-broni-czwarta-tura-wymiany-zakladnikow-kiedy-7456243?source=rss](https://tvn24.pl/swiat/izrael-wojna-w-hamasem-zawieszenie-broni-czwarta-tura-wymiany-zakladnikow-kiedy-7456243?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T10:15:17+00:00

<img alt="Co z czwartą turą uwalniania zakładników? " src="https://tvn24.pl/najnowsze/cdn-zdjecie-v92966-przerwa-w-walkach-pomiedzy-izraelem-i-hamasem-umozliwia-wymiany-zakladnikow-izraelskich-i-wiezniow-palestynskich-7456521/alternates/LANDSCAPE_1280" />
    Izrael i Hamas wyrazili zastrzeżenia, co do list izraelskich zakładników i palestyńskich więźniów, którzy mają zostać uwolnieni w poniedziałek - podał Reuters. Agencja dodała, że nad rozwiązaniem problemu pracują katarscy mediatorzy. To ostatnia wymiana w podstawowym czasie wstrzymania walk między Izraelem i Hamasem.

## Zjazd na pontonie w tunelu ze światełek. "Bajeczna Górka" już otwarta
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-bajeczna-gorka-w-wilanowie-dni-i-godziny-otwarcia-st7456398?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-bajeczna-gorka-w-wilanowie-dni-i-godziny-otwarcia-st7456398?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T10:15:15+00:00

<img alt="Zjazd na pontonie w tunelu ze światełek. " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-9yja0k-bajeczna-gorka-w-wilanowie-7456519/alternates/LANDSCAPE_1280" />
    W ostatni weekend w Wilanowie otwarto bezpłatną zimową atrakcję. "Bajeczna Górka" to zjeżdżalnia pontonowa otoczona świetlnym tunelem.

## Nie żyje Kevin "Geordie" Walker. "Jeden z najważniejszych gitarzystów rockowych"
 - [https://tvn24.pl/kultura-i-styl/kevin-walker-z-zespolu-killing-joke-nie-zyje-mial-64-lata-podano-przyczyne-smierci-7456589?source=rss](https://tvn24.pl/kultura-i-styl/kevin-walker-z-zespolu-killing-joke-nie-zyje-mial-64-lata-podano-przyczyne-smierci-7456589?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T10:05:33+00:00

<img alt="Nie żyje Kevin " src="https://tvn24.pl/najnowsze/cdn-zdjecie-amwbxi-kevin-walker-7456452/alternates/LANDSCAPE_1280" />
    W wieku 64 lat zmarł Kevin "Geordie" Walker, gitarzysta brytyjskiego postpunkowego zespołu Killing Joke - potwierdzili członkowie grupy. Walker pozostawał jedynym, obok wokalisty, członkiem Killing Joke wywodzącym się z jej oryginalnego składu.

## Medyka. Na przejazd czeka ponad 1400 kierowców. Rozpoczęto całodobową blokadę przejścia granicznego
 - [https://tvn24.pl/rzeszow/protest-na-granicy-medyka-rozpoczela-sie-calodobowa-blokada-terminala-kolejki-tirow-przed-przejsciem-7456536?source=rss](https://tvn24.pl/rzeszow/protest-na-granicy-medyka-rozpoczela-sie-calodobowa-blokada-terminala-kolejki-tirow-przed-przejsciem-7456536?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T10:00:39+00:00

<img alt="Medyka. Na przejazd czeka ponad 1400 kierowców. Rozpoczęto całodobową blokadę przejścia granicznego" src="https://tvn24.pl/krakow/cdn-zdjecie-4hmn3c-rozpoczela-sie-calodobowa-blokada-przejscia-granicznego-w-medyce-7456528/alternates/LANDSCAPE_1280" />
    Rozpoczęła się całodobowa blokada przejścia granicznego w Medyce na Podkarpaciu. Blokada trwa przez całą dobę, protestujący przepuszczają tylko samochody osobowe, autokary i TIR-y wiozące pomoc humanitarną i sprzęt wojskowy. Pozostał ciężarówki stoją w wielokilometrowych kolejkach.

## 14 kolizji o poranku w Krakowie. "Najwyższy czas na zmianę opon"
 - [https://tvn24.pl/tvnmeteo/polska/14-kolizji-o-poranku-w-krakowie-najwyzszy-czas-na-zmiane-opon-st7456459?source=rss](https://tvn24.pl/tvnmeteo/polska/14-kolizji-o-poranku-w-krakowie-najwyzszy-czas-na-zmiane-opon-st7456459?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T09:37:44+00:00

<img alt="14 kolizji o poranku w Krakowie. " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-pupkws-sliskie-drogi-w-czesci-kraju-7456510/alternates/LANDSCAPE_1280" />
    Opady śniegu, a miejscami śniegu z deszczem, spowodowały, że na drogach jest ślisko. W Krakowie w poniedziałek rano doszło do 14 kolizji. - Zdejmijmy nogę z gazu, zwracajmy uwagę na pieszych - apelował w poniedziałek Piotr Szpiech, rzecznik prasowy komendy w Krakowie.

## Hamas wypuścił z niewoli 4-letnią Abigail. Widziała, jak terroryści zabili jej rodziców
 - [https://tvn24.pl/swiat/izrael-rozejm-z-hamasem-4-letnia-abigail-wsrod-uwolnionych-zakladnikow-7456408?source=rss](https://tvn24.pl/swiat/izrael-rozejm-z-hamasem-4-letnia-abigail-wsrod-uwolnionych-zakladnikow-7456408?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T09:34:49+00:00

<img alt="Hamas wypuścił z niewoli 4-letnią Abigail. Widziała, jak terroryści zabili jej rodziców" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jldt5m-izrael-abigail-mor-edan-7456535/alternates/LANDSCAPE_1280" />
    Abigail Mor Edan, czteroletnia obywatelka Stanów Zjednoczonych, jest wśród zakładników, których Hamas przekazał Izraelowi w ramach kilkudniowego rozejmu. Dziewczynka w październikowym ataku straciła oboje rodziców. Dziewczynka stała się w ostatnich tygodniach symbolem dzieci  przetrzymywanych przez terrorystów, jej uwolnienie skomentował prezydent Joe Biden.

## Tankowiec odbity z rąk porywaczy. Zaczęli uciekać na widok niszczyciela US Navy
 - [https://tvn24.pl/swiat/jemen-tankowiec-central-park-odzyskany-napastnicy-uciekali-na-widok-amerykanskiego-niszczyciela-uss-mason-7456375?source=rss](https://tvn24.pl/swiat/jemen-tankowiec-central-park-odzyskany-napastnicy-uciekali-na-widok-amerykanskiego-niszczyciela-uss-mason-7456375?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T09:23:11+00:00

<img alt="Tankowiec odbity z rąk porywaczy. Zaczęli uciekać na widok niszczyciela US Navy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-g9kxyv-amerykanski-niszczyciel-uss-mason-7456315/alternates/LANDSCAPE_1280" />
    Zajęty w niedzielę u wybrzeży Jemenu tankowiec Central Park został odzyskany. Napastnicy opuścili pokład jednostki na widok przybywającego z pomocą amerykańskiego niszczyciela USS Mason - poinformowało Centralne Dowództwo Sił Zbrojnych USA. Niedługo później w stronę okrętu wystrzelone zostały z Jemenu dwa pociski rakietowe.

## Nowe informacje o stanie zdrowia papieża
 - [https://tvn24.pl/polska/papiez-franciszek-chory-nowe-informacje-o-jego-stanie-zdrowia-7456457?source=rss](https://tvn24.pl/polska/papiez-franciszek-chory-nowe-informacje-o-jego-stanie-zdrowia-7456457?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T09:17:15+00:00

<img alt="Nowe informacje o stanie zdrowia papieża" src="https://tvn24.pl/polska/cdn-zdjecie-h78fol-papiez-franciszek-7456463/alternates/LANDSCAPE_1280" />
    Watykan przekazał najnowsze informacje o stanie zdrowia papieża. Franciszek jest w "dobrym i stabilnym stanie" nie ma gorączki, lepiej oddycha, ale w najbliższych dniach ograniczy swoje aktywności.

## Joe Biden nie weźmie udziału w szczycie klimatycznym w Dubaju
 - [https://tvn24.pl/swiat/joe-biden-nie-wezmie-udzialu-w-szczycie-klimatycznym-w-dubaju-7456221?source=rss](https://tvn24.pl/swiat/joe-biden-nie-wezmie-udzialu-w-szczycie-klimatycznym-w-dubaju-7456221?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T09:15:29+00:00

<img alt="Joe Biden nie weźmie udziału w szczycie klimatycznym w Dubaju" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9j5xwy-epa10906396-7380498/alternates/LANDSCAPE_1280" />
    Prezydent USA Joe Biden nie weźmie udziału w zgromadzeniu światowych przywódców poświęconych zmianom klimatycznym - poinformowano w niedzielę. Szczyt klimatyczny ONZ ruszy w czwartek w Dubaju.

## Pasem do wyprzedzania na S8 pod prąd. 83-latek pomylił zjazdy, nie wiedział jak wrócić
 - [https://tvn24.pl/tvnwarszawa/ulice/wyszkow-pasem-do-wyprzedzania-na-s8-pod-prad-83-latek-pomylil-zjazdy-st7456416?source=rss](https://tvn24.pl/tvnwarszawa/ulice/wyszkow-pasem-do-wyprzedzania-na-s8-pod-prad-83-latek-pomylil-zjazdy-st7456416?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T09:11:58+00:00

<img alt="Pasem do wyprzedzania na S8 pod prąd. 83-latek pomylił zjazdy, nie wiedział jak wrócić" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-go8otq-kierowca-jechal-pod-prad-trasa-s8-7456387/alternates/LANDSCAPE_1280" />
    Kierowca auta osobowego jechał pod prąd trasą S8 na wysokości Wyszkowa. Nagranie z niebezpiecznej sytuacji otrzymaliśmy na Kontakt 24. Policja zablokowała trasę, by mężczyzna zatrzymał samochód. Okazało się, że za kierownicą siedział 83-latek, który - jak sam przyznał - pomylił zjazdy.

## Labrador z orderem. Przez 11 lat pracował dla straży pożarnej
 - [https://tvn24.pl/tvnmeteo/swiat/wielka-brytania-pies-labrador-reqs-otrzymal-odznaczenie-za-11-letnia-sluzbe-st7456350?source=rss](https://tvn24.pl/tvnmeteo/swiat/wielka-brytania-pies-labrador-reqs-otrzymal-odznaczenie-za-11-letnia-sluzbe-st7456350?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T09:06:50+00:00

<img alt="Labrador z orderem. Przez 11 lat pracował dla straży pożarnej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-k5dlru-reqs-otrzymal-odznaczenie-za-11-letnia-sluzbe-7456374/alternates/LANDSCAPE_1280" />
    Labrador o imieniu Reqs pracował przez 11 lat dla straży pożarnej w hrabstwie Hertfordshire we wschodniej Anglii. Po wielu latach służby czworonóg otrzymał order zasługi PDSA. Jak poinformowała brytyjska telewizja BBC, Reqs był najdłużej pracującym psem strażackim w Wielkiej Brytanii, zanim w lipcu bieżącego roku przeszedł na emeryturę.

## W zabytkowej willi miało powstać Muzeum Paderewskiego. Remont nawet nie ruszył
 - [https://tvn24.pl/tvnwarszawa/srodmiescie/warszawa-co-z-muzeum-paderewskiego-st7448111?source=rss](https://tvn24.pl/tvnwarszawa/srodmiescie/warszawa-co-z-muzeum-paderewskiego-st7448111?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T08:59:56+00:00

<img alt="W zabytkowej willi miało powstać Muzeum Paderewskiego. Remont nawet nie ruszył " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-sva9ld-willa-narutowicza-w-warszawie-7448257/alternates/LANDSCAPE_1280" />
    Wyjątkowego pecha ma Ignacy Paderewski. Los dwóch pomysłów na upamiętnienie jednego z najwybitniejszych ojców naszej niepodległości jest wciąż niepewny. Prace remontowe nad planowanym od pięciu lat Muzeum Paderewskiego w Warszawie nawet nie ruszyły. A wokół Izby Pamięci Paderewskiego w Otwocku trwa polityczna awantura o wyprowadzanie przez PiS w ostatniej chwili pieniędzy z ministerstwa kultury.

## Zjechał z drogi, uderzył w słup energetyczny. Kierowca bmw nie żyje
 - [https://tvn24.pl/lodz/pabianice-wypadek-na-ulicy-jutrzkowickiej-nie-zyje-kierowca-bmw-7456442?source=rss](https://tvn24.pl/lodz/pabianice-wypadek-na-ulicy-jutrzkowickiej-nie-zyje-kierowca-bmw-7456442?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T08:58:44+00:00

<img alt="Zjechał z drogi, uderzył w słup energetyczny. Kierowca bmw nie żyje " src="https://tvn24.pl/najnowsze/cdn-zdjecie-qm0upj-tragiczny-wypadek-w-pabianicach-nie-zyje-44-latek-7456426/alternates/LANDSCAPE_1280" />
    Wypadek na ulicy Jutrzkowickiej w Pabianicach (woj. łódzkie). 44-letni kierowca bmw uderzył w słup energetyczny, nie przeżył.

## Dwóch patostreamerów zatrzymanych. "Dopuścili się przestępstw przeciwko życiu i zdrowiu"
 - [https://tvn24.pl/katowice/slask-dwoch-patostreamerow-zatrzymanych-7456390?source=rss](https://tvn24.pl/katowice/slask-dwoch-patostreamerow-zatrzymanych-7456390?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T08:17:17+00:00

<img alt="Dwóch patostreamerów zatrzymanych. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-vlb1kk-policjanci-zatrzymali-dwoch-patostreamerow-7456335/alternates/LANDSCAPE_1280" />
    Policjanci zatrzymali dwóch patostreamerów, którzy podczas transmisji w internecie mieli znęcać się nad upijanymi dziewczynami. Jak informują mundurowi, nastolatkowie "dopuścili się przestępstw przeciwko życiu i zdrowiu". Gdy o sprawie stało się głośno, wyjechali za granicę. Prokuratura prowadzi sprawę m.in. pod kątem nieudzielenia pomocy u jednej z dziewczyn i spowodowania obrażeń ciała u drugiej.

## Indie. 24 ofiary śmiertelne uderzeń piorunów
 - [https://tvn24.pl/tvnmeteo/swiat/indie-stan-gudzarat-24-ofiary-smiertelne-uderzen-piorunow-st7456313?source=rss](https://tvn24.pl/tvnmeteo/swiat/indie-stan-gudzarat-24-ofiary-smiertelne-uderzen-piorunow-st7456313?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T08:14:13+00:00

<img alt="Indie. 24 ofiary śmiertelne uderzeń piorunów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6qu1x6-burza-piorun-blyskawica-niebo-chmury-6878318/alternates/LANDSCAPE_1280" />
    W ciągu ostatnich dwóch dni, z powodu uderzeń piorunów zginęło 24 mieszkańców indyjskiego stanu Gudźarat. Lokalne władze podały, że kilkadziesiąt osób zostało też rannych.

## Na morskim dnie kryła się góra dwa razy wyższa niż Burdż Chalifa
 - [https://tvn24.pl/tvnmeteo/nauka/na-morskim-dnie-kryla-sie-gora-dwa-razy-wyzsza-niz-burdz-chalifa-st7455914?source=rss](https://tvn24.pl/tvnmeteo/nauka/na-morskim-dnie-kryla-sie-gora-dwa-razy-wyzsza-niz-burdz-chalifa-st7455914?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T08:12:17+00:00

<img alt="Na morskim dnie kryła się góra dwa razy wyższa niż Burdż Chalifa" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-95wsqd-naukowcy-david-caress-jennifer-paduan-i-jeff-beeson-badaja-dno-oceaniczne-7456279/alternates/LANDSCAPE_1280" />
    Podwodna góra została odkryta niedaleko wybrzeży Gwatemali. Ma ona 1600 metrów wysokości i zajmuje powierzchnię 14 kilometrów kwadratowych. Jak tłumaczą badacze, mapowanie dna morskiego pozwoli nam lepiej poznać procesy zachodzące głęboko w oceanie.

## Bójka z użyciem noża, dwie osoby zatrzymane
 - [https://tvn24.pl/tvnwarszawa/najnowsze/dabrowka-bojka-z-uzyciem-noza-dwie-osoby-zatrzymane-st7456306?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/dabrowka-bojka-z-uzyciem-noza-dwie-osoby-zatrzymane-st7456306?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T07:23:24+00:00

<img alt="Bójka z użyciem noża, dwie osoby zatrzymane" src="https://tvn24.pl/najnowsze/cdn-zdjecie-agp3a0-policja-zdjecie-ilustracyjne-7415782/alternates/LANDSCAPE_1280" />
    W miejscowości Dąbrówka koło Grójca (Mazowsze) doszło do bójki z użyciem noża. Jedna osoba została ranna. Zatrzymano dwie osoby.

## Przedwyborcze obniżki cen. Jacek Sasin komentuje
 - [https://tvn24.pl/biznes/z-kraju/ceny-paliw-przed-wyborami-jacek-sasin-komentuje-st7456304?source=rss](https://tvn24.pl/biznes/z-kraju/ceny-paliw-przed-wyborami-jacek-sasin-komentuje-st7456304?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T07:22:06+00:00

<img alt="Przedwyborcze obniżki cen. Jacek Sasin komentuje" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5l0acv-orlen-stacja-paliw-daniel-obajtek-7424297/alternates/LANDSCAPE_1280" />
    Mam zaufanie do pana prezesa Orlenu Daniela Obajtka, efekty jego pracy są znakomite - powiedział w programie "Rozmowa Piaseckiego" na antenie TVN24 minister aktywów państwowych Jacek Sasin, pytany o przedwyborcze obniżki cen na stacjach. Szef MAP stwierdził, że był zapewniany o tym, że stawki "są rynkowe" i nie powodują strat dla koncernu.

## Jarosław Kaczyński: kształt nowego rządu Mateusza Morawieckiego to mój pomysł
 - [https://tvn24.pl/polska/jaroslaw-kaczynski-ksztalt-nowego-rzadu-mateusza-morawieckiego-to-moj-pomysl-7456309?source=rss](https://tvn24.pl/polska/jaroslaw-kaczynski-ksztalt-nowego-rzadu-mateusza-morawieckiego-to-moj-pomysl-7456309?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T07:20:37+00:00

<img alt="Jarosław Kaczyński: kształt nowego rządu Mateusza Morawieckiego to mój pomysł" src="https://tvn24.pl/najnowsze/cdn-zdjecie-gy7067-jaroslaw-kaczynski-7438455/alternates/LANDSCAPE_1280" />
    Chcemy zaproponować nowe twarze - mówi o składzie rządu Mateusza Morawieckiego prezes Prawa i Sprawiedliwości Jarosław Kaczyński. - Koncepcja rządu ekspercko-politycznego nie jest zamknięta. Nie tylko premier wywodzący się z PiS może ją realizować, ale i inny kandydat. Być może z PSL, także ktoś inny niż lider tej partii. Może to być też ktoś spoza polityki - sugerował.

## Inflacja, PKB i ceny ropy. Taki będzie tydzień w gospodarce
 - [https://tvn24.pl/biznes/z-kraju/gospodarka-inflacja-pkb-i-ceny-ropy-najwazniejsze-wydarzenia-tygodnia-kalendarz-st7456244?source=rss](https://tvn24.pl/biznes/z-kraju/gospodarka-inflacja-pkb-i-ceny-ropy-najwazniejsze-wydarzenia-tygodnia-kalendarz-st7456244?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T06:13:02+00:00

<img alt="Inflacja, PKB i ceny ropy. Taki będzie tydzień w gospodarce" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9wsgja-warszawa-s-shutterstock1471656701-5033908/alternates/LANDSCAPE_1280" />
    W tym tygodniu w centrum uwagi w gospodarce znajdzie się szybki szacunek inflacji za listopad, szczegóły PKB w trzecim kwartale i odczyt PMI. MF przeprowadzi przetarg sprzedaży obligacji i opublikuje podaż SPW na grudzień. Na piątek przegląd ratingu Polski zaplanowała agencja S&amp;P. Z kolei wyniki kwartalne opublikuje między innymi CD Projekt. W tygodniu zabiorą głos także liczni bankierzy centralni, odbędzie się również spotkanie grupy OPEC+.

## Kaczyński: kształt nowego rządu Morawieckiego to mój pomysł
 - [https://tvn24.pl/polska/zaprzysiezenie-rzadu-mateusza-morawieckiego-o-ktorej-relacja-komentarze-polityczne-27-listopada-7456269?source=rss](https://tvn24.pl/polska/zaprzysiezenie-rzadu-mateusza-morawieckiego-o-ktorej-relacja-komentarze-polityczne-27-listopada-7456269?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T06:04:45+00:00

<img alt="Kaczyński: kształt nowego rządu Morawieckiego to mój pomysł " src="https://tvn24.pl/najnowsze/cdn-zdjecie-gy7067-jaroslaw-kaczynski-7438455/alternates/LANDSCAPE_1280" />
    Kształt rządu ekspercko-politycznego, który w poniedziałek przedstawi premier Mateusz Morawiecki, to mój pomysł - powiedział prezes Prawa i Sprawiedliwości Jarosław Kaczyński. Uroczystość zaprzysiężenia odbędzie się w Pałacu Prezydenckim o godzinie 16.30. W tvn24.pl relacjonujemy wydarzenia politycznego poniedziałku.

## Egipskie ciemności na budowie. Piesi nie czują się bezpiecznie
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-egipskie-ciemnosci-na-budowie-tramwaju-na-sobieskiego-st7456163?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-egipskie-ciemnosci-na-budowie-tramwaju-na-sobieskiego-st7456163?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T05:52:46+00:00

<img alt="Egipskie ciemności na budowie. Piesi nie czują się bezpiecznie" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-1h5abo-niedoswietlone-przejscia-na-czarnomorskiej-7450746/alternates/LANDSCAPE_1280" />
    Niedziałające latarnie to stale powracający problem na budowie linii tramwajowej do Wilanowa. Na Sobieskiego jest niebezpiecznie, szczególnie dla pieszych.

## Gorąco na granicy między Koreami. Pojawili się tam żołnierze i ciężki sprzęt wojskowy
 - [https://tvn24.pl/swiat/goraco-na-granicy-miedzy-koreami-pojawili-sie-tam-zolnierze-i-ciezki-sprzet-wojskowy-7456231?source=rss](https://tvn24.pl/swiat/goraco-na-granicy-miedzy-koreami-pojawili-sie-tam-zolnierze-i-ciezki-sprzet-wojskowy-7456231?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T05:02:54+00:00

<img alt="Gorąco na granicy między Koreami. Pojawili się tam żołnierze i ciężki sprzęt wojskowy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ybxt9u-kim-dzong-un-7456230/alternates/LANDSCAPE_1280" />
    W odpowiedzi na wystrzelenie satelity szpiegowskiego przez reżim w Pjongjangu, władze Korei Południowej rozpoczęły zwiad na granicy. Teraz Korea Północna rozmieszcza tam żołnierzy i ciężki sprzęt wojskowy– podaje południowokoreańska agencja informacyjna Yonhap.

## Zamordował trzy swoje córki. Sam zgłosił się na policję
 - [https://tvn24.pl/swiat/francja-dieppe-zamordowal-swoje-trzy-corki-sam-zglosil-sie-na-policje-7456233?source=rss](https://tvn24.pl/swiat/francja-dieppe-zamordowal-swoje-trzy-corki-sam-zglosil-sie-na-policje-7456233?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T04:52:12+00:00

<img alt="Zamordował trzy swoje córki. Sam zgłosił się na policję" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ayemix-policja-francja-jose-hernandez-shutterstock_1926706805-7170651/alternates/LANDSCAPE_1280" />
    Na posterunek policji w Dieppe w Normandii (Francja) zgłosił się mężczyzna, który przyznał się do zabójstwa swoich trzech córek w wieku od 4 do 11 lat. Do zbrodni doszło w Alfortville na obrzeżach Paryża.

## Policja zatrzymała podejrzanego o atak z bronią na trzech studentów
 - [https://tvn24.pl/swiat/policja-zatrzymala-podejrzanego-o-atak-z-bronia-na-trzech-studentow-7456214?source=rss](https://tvn24.pl/swiat/policja-zatrzymala-podejrzanego-o-atak-z-bronia-na-trzech-studentow-7456214?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T04:50:51+00:00

<img alt="Policja zatrzymała podejrzanego o atak z bronią na trzech studentów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xz43x0-trzej-palestynscy-studenci-postrzeleni-w-poblizu-uniwersytetu-vermont-7456235/alternates/LANDSCAPE_1280" />
    Zaatakowana trójka nosiła charakterystyczne palestyńskie chusty i rozmawiała po arabsku. Sprawca bez słowa oddał w ich kierunku cztery strzały. Ich rodziny apelują do amerykańskich władz, by potraktowali ten incydent jako przestępstwo z nienawiści.

## Trzej palestyńscy studenci postrzeleni w pobliżu Uniwersytetu Vermont
 - [https://tvn24.pl/swiat/trzej-palestynscy-studenci-postrzeleni-w-poblizu-uniwersytetu-vermont-7456214?source=rss](https://tvn24.pl/swiat/trzej-palestynscy-studenci-postrzeleni-w-poblizu-uniwersytetu-vermont-7456214?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T04:50:51+00:00

<img alt="Trzej palestyńscy studenci postrzeleni w pobliżu Uniwersytetu Vermont" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xz43x0-trzej-palestynscy-studenci-postrzeleni-w-poblizu-uniwersytetu-vermont-7456235/alternates/LANDSCAPE_1280" />
    Trzech palestyńskich studentów zostało postrzelonych w sobotę wieczorem w pobliżu Uniwersytetu Vermont. Ich rodziny apelują do amerykańskich władz, by potraktowali ten incydent jako przestępstwo z nienawiści.

## Zalany Berdiańsk, zasypany Kijów. Ekstremalna pogoda na Ukrainie
 - [https://tvn24.pl/swiat/ukraina-najwazniejsze-wydarzenia-ostatnich-godzin-27-listopada-2023-7456215?source=rss](https://tvn24.pl/swiat/ukraina-najwazniejsze-wydarzenia-ostatnich-godzin-27-listopada-2023-7456215?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T04:42:43+00:00

<img alt="Zalany Berdiańsk, zasypany Kijów. Ekstremalna pogoda na Ukrainie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-byxacy-ukraina-zima-7456219/alternates/LANDSCAPE_1280" />
    Rosyjska pełnoskalowa inwazja na Ukrainę trwa już od 642 dni. Gwałtowne załamanie pogody niemal w całej Ukrainie. 400 osiedli pozostaje bez prądu. Rosjanie w masowym ataku na Kijów mieli użyć nowego typu dronów, trudnych do wykrycia przez radary. Oto najważniejsze wydarzenia ostatnich godzin wojny w Ukrainie.

## Prezydent zna już skład rządu Morawieckiego, koszmar skoczków, choroba papieża
 - [https://tvn24.pl/swiat/piec-rzeczy-ktore-warto-wiedziec-27-listopada-7456220?source=rss](https://tvn24.pl/swiat/piec-rzeczy-ktore-warto-wiedziec-27-listopada-7456220?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T04:33:23+00:00

<img alt="Prezydent zna już skład rządu Morawieckiego, koszmar skoczków, choroba papieża" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-bzvfij-mateusz-morawiecki-szuka-chetnych-do-koalicji-jestem-przekonany-ze-nikt-nie-poszedl-na-takie-rozmowy-7452062/alternates/LANDSCAPE_1280" />
    Ślisko na drogach, na północy kraju ma spaść śniegu. Prezydent zna już skład rządu Mateusza Morawieckiego, który nie ma szans na wotum zaufania. Hamas uwolnił kolejnych zakładników. Skoczkowie srogo zawiedli. Oto pięć rzeczy, które warto wiedzieć 27 listopada.

## Pogoda na dziś - poniedziałek 27.11. Dwie strefy opadów śniegu, na termometrach maksymalnie 2 stopnie
 - [https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-dzis-poniedzialek-2711-dwie-strefy-opadow-sniegu-na-termometrach-maksymalnie-2-stopnie-st7456044?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-dzis-poniedzialek-2711-dwie-strefy-opadow-sniegu-na-termometrach-maksymalnie-2-stopnie-st7456044?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-11-27T01:00:00+00:00

<img alt="Pogoda na dziś - poniedziałek 27.11. Dwie strefy opadów śniegu, na termometrach maksymalnie 2 stopnie" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-u4qxer-pochmurno-lekki-snieg-jesien-7456089/alternates/LANDSCAPE_1280" />
    Pogoda na dziś. Poniedziałek 27.11 w całym kraju zapowiada się zimno - termometry pokażą od -4 do 2 stopni Celsjusza. Miejscami prognozowane są opady śniegu do 5 centymetrów. W większości regionów warunki biometeorologiczne okażą się niekorzystne.

