# Source:3D Printing, URL:https://www.reddit.com/r/3Dprinting/.rss, language:en

## Yup...
 - [https://www.reddit.com/r/3Dprinting/comments/185egls/yup](https://www.reddit.com/r/3Dprinting/comments/185egls/yup)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-11-27T21:35:52+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/185egls/yup/"> <img alt="Yup..." src="https://preview.redd.it/30uyrf3zly2c1.jpeg?width=320&amp;crop=smart&amp;auto=webp&amp;s=67e45008410023ea71d9d085885abd2c1a8f0977" title="Yup..." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/NagyBig"> /u/NagyBig </a> <br /> <span><a href="https://i.redd.it/30uyrf3zly2c1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/185egls/yup/">[comments]</a></span> </td></tr></table>

## Tribute to Gail Lewis
 - [https://www.reddit.com/r/3Dprinting/comments/185dtrv/tribute_to_gail_lewis](https://www.reddit.com/r/3Dprinting/comments/185dtrv/tribute_to_gail_lewis)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-11-27T21:11:32+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/185dtrv/tribute_to_gail_lewis/"> <img alt="Tribute to Gail Lewis" src="https://external-preview.redd.it/Y3c3c284NndneTJjMer86EmH-CPf1cFuAKyuuM9u6yZk22MJpIlbTZX4zWrC.png?width=320&amp;crop=smart&amp;auto=webp&amp;s=eacf955e72afe6ccb3f9ae23571e78bd120954c6" title="Tribute to Gail Lewis" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/whopperlover17"> /u/whopperlover17 </a> <br /> <span><a href="https://v.redd.it/cbkm146xgy2c1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/185dtrv/tribute_to_gail_lewis/">[comments]</a></span> </td></tr></table>

## I 3D printed Shanghai (1:5000)
 - [https://www.reddit.com/r/3Dprinting/comments/185dq0w/i_3d_printed_shanghai_15000](https://www.reddit.com/r/3Dprinting/comments/185dq0w/i_3d_printed_shanghai_15000)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-11-27T21:07:24+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/185dq0w/i_3d_printed_shanghai_15000/"> <img alt="I 3D printed Shanghai (1:5000)" src="https://b.thumbs.redditmedia.com/MjqiBAk-V1wuwt_06e0xAHWZvejOxN9wrUdQVgniGnM.jpg" title="I 3D printed Shanghai (1:5000)" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>City is 1:5000 and represents a square KM. Worked on the CAD for a few weeks on and off with the final print taking around 3 days. Give my instagram a follow :).</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Wiseteller"> /u/Wiseteller </a> <br /> <span><a href="https://www.reddit.com/gallery/185dq0w">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/185dq0w/i_3d_printed_shanghai_15000/">[comments]</a></span> </td></tr></table>

## I designed a desktop speaker, with the help of the DIY Audio community!
 - [https://www.reddit.com/r/3Dprinting/comments/185b9rx/i_designed_a_desktop_speaker_with_the_help_of_the](https://www.reddit.com/r/3Dprinting/comments/185b9rx/i_designed_a_desktop_speaker_with_the_help_of_the)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-11-27T19:26:28+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/185b9rx/i_designed_a_desktop_speaker_with_the_help_of_the/"> <img alt="I designed a desktop speaker, with the help of the DIY Audio community!" src="https://preview.redd.it/g3vxqpemyx2c1.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=150a8c41ef41b11120a3cafe23ac3ba7f4827dea" title="I designed a desktop speaker, with the help of the DIY Audio community!" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/chargedcapacitor"> /u/chargedcapacitor </a> <br /> <span><a href="https://i.redd.it/g3vxqpemyx2c1.jpg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/185b9rx/i_designed_a_desktop_speaker_with_the_help_of_the/">[comments]</a></span> </td></tr></table>

## Suspect my nephew tried to destroy my printer
 - [https://www.reddit.com/r/3Dprinting/comments/185avzu/suspect_my_nephew_tried_to_destroy_my_printer](https://www.reddit.com/r/3Dprinting/comments/185avzu/suspect_my_nephew_tried_to_destroy_my_printer)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-11-27T19:10:52+00:00

<!-- SC_OFF --><div class="md"><p>My family came over this past weekend, I had an arguement with my Nephew over video games. They went home and I went to print yesterday, the bed wasn't heating. I then noticed the hotend wires dangling. I suspect he cut both wires, and knocked the pad fully off the negative. I've been trying to solder the cables back on, but they just won't stick. I've tried flux core and lead solder (with flux). How can I get these things re-soldered on again? Ender 5+ bed.</p> <p><a href="https://imgur.com/1NOd1ha.png">https://imgur.com/1NOd1ha.png</a></p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/sdswiki"> /u/sdswiki </a> <br /> <span><a href="https://www.reddit.com/r/3Dprinting/comments/185avzu/suspect_my_nephew_tried_to_destroy_my_printer/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/185avzu/suspect_my_nephew_tried_to_destroy_my_printer/">[comments]</a></span>

## 3D printed LED sign
 - [https://www.reddit.com/r/3Dprinting/comments/185apgc/3d_printed_led_sign](https://www.reddit.com/r/3Dprinting/comments/185apgc/3d_printed_led_sign)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-11-27T19:03:13+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/185apgc/3d_printed_led_sign/"> <img alt="3D printed LED sign" src="https://b.thumbs.redditmedia.com/qntvZ0DGqGizxZMc19h2oXNbD2IbzOhaRirhPuYhHXI.jpg" title="3D printed LED sign" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Andreaspetersen12"> /u/Andreaspetersen12 </a> <br /> <span><a href="https://www.reddit.com/gallery/185apgc">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/185apgc/3d_printed_led_sign/">[comments]</a></span> </td></tr></table>

## I feel like really big brain energy here... :D
 - [https://www.reddit.com/r/3Dprinting/comments/1859uj6/i_feel_like_really_big_brain_energy_here_d](https://www.reddit.com/r/3Dprinting/comments/1859uj6/i_feel_like_really_big_brain_energy_here_d)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-11-27T18:28:12+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1859uj6/i_feel_like_really_big_brain_energy_here_d/"> <img alt="I feel like really big brain energy here... :D" src="https://preview.redd.it/mapbnokdox2c1.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=b306bba4e98eeac147b787139e1433e4a57767e3" title="I feel like really big brain energy here... :D" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/bonobomaster"> /u/bonobomaster </a> <br /> <span><a href="https://i.redd.it/mapbnokdox2c1.jpg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1859uj6/i_feel_like_really_big_brain_energy_here_d/">[comments]</a></span> </td></tr></table>

## Just added the P1S to my printing corner. Curious how it will compare to the MK4.
 - [https://www.reddit.com/r/3Dprinting/comments/1859py0/just_added_the_p1s_to_my_printing_corner_curious](https://www.reddit.com/r/3Dprinting/comments/1859py0/just_added_the_p1s_to_my_printing_corner_curious)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-11-27T18:23:02+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1859py0/just_added_the_p1s_to_my_printing_corner_curious/"> <img alt="Just added the P1S to my printing corner. Curious how it will compare to the MK4." src="https://preview.redd.it/n7b9fyhknx2c1.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=261ae5173da79d729b8e69065069a25d97aaf6fb" title="Just added the P1S to my printing corner. Curious how it will compare to the MK4." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Darkzed1"> /u/Darkzed1 </a> <br /> <span><a href="https://i.redd.it/n7b9fyhknx2c1.jpg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1859py0/just_added_the_p1s_to_my_printing_corner_curious/">[comments]</a></span> </td></tr></table>

## Is it doable?
 - [https://www.reddit.com/r/3Dprinting/comments/1859cw2/is_it_doable](https://www.reddit.com/r/3Dprinting/comments/1859cw2/is_it_doable)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-11-27T18:08:31+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1859cw2/is_it_doable/"> <img alt="Is it doable?" src="https://b.thumbs.redditmedia.com/KKCNL1Jodp3gjaiFwuuy5UVPrVjF3AELdRQrebCs6Uw.jpg" title="Is it doable?" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I've tried this thrice... It's pla on a ender 3 v2 neo. I've used support only for the first two or three loops, otherwise it would be hard to remove them...</p> <p>I do know if those swirls are a sign of too low or too high temperature. For what I've observed, it seems that the printer is starting the layer at the non supported part of it, in other words, printing on air...</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ppfmagno"> /u/ppfmagno </a> <br /> <span><a href="https://www.reddit.com/gallery/1859cw2">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1859cw2/is_it_doable/">[comments]</a></span> </td></tr></table>

## Rikku - Final Fantasy X
 - [https://www.reddit.com/r/3Dprinting/comments/1858w3o/rikku_final_fantasy_x](https://www.reddit.com/r/3Dprinting/comments/1858w3o/rikku_final_fantasy_x)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-11-27T17:49:53+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1858w3o/rikku_final_fantasy_x/"> <img alt="Rikku - Final Fantasy X" src="https://external-preview.redd.it/XRGecvLeeW-kBI_Yb8wlxTmkbX24b61X4QlJEdQyzXE.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=346084a5723522b8675ed870954fe90f128e077b" title="Rikku - Final Fantasy X" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/tslater2006"> /u/tslater2006 </a> <br /> <span><a href="https://imgur.com/gallery/NdQQWVp">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1858w3o/rikku_final_fantasy_x/">[comments]</a></span> </td></tr></table>

## How do y'all monitor your printers in another room?
 - [https://www.reddit.com/r/3Dprinting/comments/18580y8/how_do_yall_monitor_your_printers_in_another_room](https://www.reddit.com/r/3Dprinting/comments/18580y8/how_do_yall_monitor_your_printers_in_another_room)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-11-27T17:14:51+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18580y8/how_do_yall_monitor_your_printers_in_another_room/"> <img alt="How do y'all monitor your printers in another room?" src="https://preview.redd.it/w5hfn8kebx2c1.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=522b4c870db484ab34d56e75b1a9eff0455b537d" title="How do y'all monitor your printers in another room?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Szetyi"> /u/Szetyi </a> <br /> <span><a href="https://i.redd.it/w5hfn8kebx2c1.jpg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18580y8/how_do_yall_monitor_your_printers_in_another_room/">[comments]</a></span> </td></tr></table>

## Issues with esun abs+
 - [https://www.reddit.com/r/3Dprinting/comments/1857b69/issues_with_esun_abs](https://www.reddit.com/r/3Dprinting/comments/1857b69/issues_with_esun_abs)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-11-27T16:45:06+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1857b69/issues_with_esun_abs/"> <img alt="Issues with esun abs+" src="https://b.thumbs.redditmedia.com/Er5JYj2M6OB5jBT73B1R8g6c8TFDhkS7GTA5gr962Ik.jpg" title="Issues with esun abs+" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I'm going to preface this by stating I have about 5k hours across 3 vorons and used around 200 rolls of abs+ in this time. im 99% certain this isn't a skill issue. </p> <p>I respect there's other places for print help but I'm posting this here purely in hope that someone recently has also encountered this issue. </p> <p>So yeah thousands of hours, only used esun abs+ in this time. Primarily black and red, both seem problematic now, red not as bad but the material black is made out of seems way different.</p> <p>I've replaced the motherboard, cable from motherboard to extruder motor, extruder motor, hot end, thermistor, heater cartridge and rebuilt my extruder assembly to just try elim

## First usable print is a success.
 - [https://www.reddit.com/r/3Dprinting/comments/1856wb9/first_usable_print_is_a_success](https://www.reddit.com/r/3Dprinting/comments/1856wb9/first_usable_print_is_a_success)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-11-27T16:27:22+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1856wb9/first_usable_print_is_a_success/"> <img alt="First usable print is a success." src="https://b.thumbs.redditmedia.com/l33Hma4RQdJO_O6JtPwA79KFGnjSE-m2-pQ7i4IG-QI.jpg" title="First usable print is a success." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/mattycrits"> /u/mattycrits </a> <br /> <span><a href="https://www.reddit.com/gallery/1856wb9">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1856wb9/first_usable_print_is_a_success/">[comments]</a></span> </td></tr></table>

## Snowflake Mechanical Box
 - [https://www.reddit.com/r/3Dprinting/comments/1856cnd/snowflake_mechanical_box](https://www.reddit.com/r/3Dprinting/comments/1856cnd/snowflake_mechanical_box)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-11-27T16:04:35+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1856cnd/snowflake_mechanical_box/"> <img alt="Snowflake Mechanical Box" src="https://b.thumbs.redditmedia.com/e6pl3Kge_iSdNdoXpB9-6PiUK5En2rAsCGe169r0PjU.jpg" title="Snowflake Mechanical Box" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/magnuspsa"> /u/magnuspsa </a> <br /> <span><a href="https://than.gs/m/969382">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1856cnd/snowflake_mechanical_box/">[comments]</a></span> </td></tr></table>

## Bowser from super mario :))
 - [https://www.reddit.com/r/3Dprinting/comments/185654a/bowser_from_super_mario](https://www.reddit.com/r/3Dprinting/comments/185654a/bowser_from_super_mario)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-11-27T15:55:32+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/185654a/bowser_from_super_mario/"> <img alt="Bowser from super mario :))" src="https://b.thumbs.redditmedia.com/9N1irtzXrvMtjX9QHut7RIkvOi7eCxurehNkkwUrAtM.jpg" title="Bowser from super mario :))" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Fit-Calendar-7175"> /u/Fit-Calendar-7175 </a> <br /> <span><a href="https://www.reddit.com/gallery/185654a">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/185654a/bowser_from_super_mario/">[comments]</a></span> </td></tr></table>

## I printed a tank!
 - [https://www.reddit.com/r/3Dprinting/comments/1855wlm/i_printed_a_tank](https://www.reddit.com/r/3Dprinting/comments/1855wlm/i_printed_a_tank)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-11-27T15:44:42+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1855wlm/i_printed_a_tank/"> <img alt="I printed a tank!" src="https://preview.redd.it/ht42zokbvw2c1.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=991fd8384133cbb130b3c04eeb293d8a4738838b" title="I printed a tank!" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I'm super happy with how it came out.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/shigitybum"> /u/shigitybum </a> <br /> <span><a href="https://i.redd.it/ht42zokbvw2c1.jpg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1855wlm/i_printed_a_tank/">[comments]</a></span> </td></tr></table>

## With prices on PETG this good is there a benefit of using PLA? I’m getting great results and I understand PETG has the benefit of being more resistant to temperature.
 - [https://www.reddit.com/r/3Dprinting/comments/1855ut6/with_prices_on_petg_this_good_is_there_a_benefit](https://www.reddit.com/r/3Dprinting/comments/1855ut6/with_prices_on_petg_this_good_is_there_a_benefit)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-11-27T15:42:19+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1855ut6/with_prices_on_petg_this_good_is_there_a_benefit/"> <img alt="With prices on PETG this good is there a benefit of using PLA? I’m getting great results and I understand PETG has the benefit of being more resistant to temperature." src="https://preview.redd.it/3u6mh2bwuw2c1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=c025737733428a65975f072b54bfa8e8e107e70e" title="With prices on PETG this good is there a benefit of using PLA? I’m getting great results and I understand PETG has the benefit of being more resistant to temperature." /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I make a lot of functional prints as well as models. PLA always painted and sanded great but figured I would try more of it at this price.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Bitter-Rain-306"> /u/Bitter-Rain-306 </a> <br /> <span><a href="https://i.redd.it/3u6mh2bwuw2c1.jpeg"

## My new puzzle designs
 - [https://www.reddit.com/r/3Dprinting/comments/1855pkq/my_new_puzzle_designs](https://www.reddit.com/r/3Dprinting/comments/1855pkq/my_new_puzzle_designs)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-11-27T15:35:51+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1855pkq/my_new_puzzle_designs/"> <img alt="My new puzzle designs" src="https://b.thumbs.redditmedia.com/h18cmsvZnIRKABt3sWGLJVMW602jM3l3sG2F4CUW1Cc.jpg" title="My new puzzle designs" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/kthuen"> /u/kthuen </a> <br /> <span><a href="https://www.reddit.com/gallery/1855pkq">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1855pkq/my_new_puzzle_designs/">[comments]</a></span> </td></tr></table>

## Cyber Monday deal - Official Creality Ender 3 V2 Neo 3D Printer at half price
 - [https://www.reddit.com/r/3Dprinting/comments/1855nif/cyber_monday_deal_official_creality_ender_3_v2](https://www.reddit.com/r/3Dprinting/comments/1855nif/cyber_monday_deal_official_creality_ender_3_v2)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-11-27T15:33:25+00:00

<!-- SC_OFF --><div class="md"><p>Really nice <a href="https://techtub.shop">deal on Amazon today</a></p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/jusraynn"> /u/jusraynn </a> <br /> <span><a href="https://www.reddit.com/r/3Dprinting/comments/1855nif/cyber_monday_deal_official_creality_ender_3_v2/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1855nif/cyber_monday_deal_official_creality_ender_3_v2/">[comments]</a></span>

## Just throw money at it
 - [https://www.reddit.com/r/3Dprinting/comments/1855fyo/just_throw_money_at_it](https://www.reddit.com/r/3Dprinting/comments/1855fyo/just_throw_money_at_it)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-11-27T15:24:09+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1855fyo/just_throw_money_at_it/"> <img alt="Just throw money at it" src="https://b.thumbs.redditmedia.com/eGq4DZ7y5cqFXdY7tC84fCD8ObguC2OPPdDU_zG3uqM.jpg" title="Just throw money at it" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Before and after. After about a year of off snd on fighting my ender 5 plus i just gave up and replaced the hot end and extruder. Boom perfect. P.s. dear newbies dont do this figure why it isnt working and fix it haha.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/subtlyfantastic"> /u/subtlyfantastic </a> <br /> <span><a href="https://www.reddit.com/gallery/1855fyo">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1855fyo/just_throw_money_at_it/">[comments]</a></span> </td></tr></table>

## I could not resist and 3D printed the Balancing Tetris too. Exposed gyroid infil to give base more character
 - [https://www.reddit.com/r/3Dprinting/comments/18558xc/i_could_not_resist_and_3d_printed_the_balancing](https://www.reddit.com/r/3Dprinting/comments/18558xc/i_could_not_resist_and_3d_printed_the_balancing)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-11-27T15:15:41+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18558xc/i_could_not_resist_and_3d_printed_the_balancing/"> <img alt="I could not resist and 3D printed the Balancing Tetris too. Exposed gyroid infil to give base more character" src="https://preview.redd.it/7h04dj75qw2c1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=9e8be6c313925dca24582a7aaeb28242bd1f7b04" title="I could not resist and 3D printed the Balancing Tetris too. Exposed gyroid infil to give base more character" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Vojtech_Bucek_Brno"> /u/Vojtech_Bucek_Brno </a> <br /> <span><a href="https://i.redd.it/7h04dj75qw2c1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18558xc/i_could_not_resist_and_3d_printed_the_balancing/">[comments]</a></span> </td></tr></table>

## Super Slicer vs. Prusa slicer. How do I fix those gaps?
 - [https://www.reddit.com/r/3Dprinting/comments/1854tzu/super_slicer_vs_prusa_slicer_how_do_i_fix_those](https://www.reddit.com/r/3Dprinting/comments/1854tzu/super_slicer_vs_prusa_slicer_how_do_i_fix_those)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-11-27T14:57:06+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1854tzu/super_slicer_vs_prusa_slicer_how_do_i_fix_those/"> <img alt="Super Slicer vs. Prusa slicer. How do I fix those gaps?" src="https://a.thumbs.redditmedia.com/nPhwtbTW-T26v5-L75zb0ph0125WmxymTfLqWpNIMw0.jpg" title="Super Slicer vs. Prusa slicer. How do I fix those gaps?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/PCgeek345"> /u/PCgeek345 </a> <br /> <span><a href="https://www.reddit.com/gallery/1854tzu">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1854tzu/super_slicer_vs_prusa_slicer_how_do_i_fix_those/">[comments]</a></span> </td></tr></table>

## My metric screw fit tester, but for horizontal bores!
 - [https://www.reddit.com/r/3Dprinting/comments/18540d3/my_metric_screw_fit_tester_but_for_horizontal](https://www.reddit.com/r/3Dprinting/comments/18540d3/my_metric_screw_fit_tester_but_for_horizontal)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-11-27T14:19:41+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18540d3/my_metric_screw_fit_tester_but_for_horizontal/"> <img alt="My metric screw fit tester, but for horizontal bores!" src="https://b.thumbs.redditmedia.com/qRT1QL_ih0B4crjPe862MCIRXeEXO8IfZfN5A7KgCXE.jpg" title="My metric screw fit tester, but for horizontal bores!" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>On my post about a metric screw fit and tolerance tester I designed, a commenter made me aware that a guide for horizontal bores would be just as important. Not only can printers have different tolerances in the Z direction, the interaction between layer lines and screw threads has a big effect on fit as well. So I made a standing version to go along with my other guide!</p> <p>Model: <a href="https://makerworld.com/models/75721#profileId-80275">https://makerworld.com/models/75721#profileId-80275</a></p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/spookycromc

## 3d printers that dont require any kind of tinkering and are easy to use? Any suggestions
 - [https://www.reddit.com/r/3Dprinting/comments/1853a3r/3d_printers_that_dont_require_any_kind_of](https://www.reddit.com/r/3Dprinting/comments/1853a3r/3d_printers_that_dont_require_any_kind_of)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-11-27T13:44:28+00:00

<!-- SC_OFF --><div class="md"><p>I am looking for a 3d printer that doesnt required tedious work. I want a reliable printed with no eg. first layer issues etc</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Calm_String926"> /u/Calm_String926 </a> <br /> <span><a href="https://www.reddit.com/r/3Dprinting/comments/1853a3r/3d_printers_that_dont_require_any_kind_of/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1853a3r/3d_printers_that_dont_require_any_kind_of/">[comments]</a></span>

## Ergonomic Mouse (more informations in the comments)
 - [https://www.reddit.com/r/3Dprinting/comments/1852jgf/ergonomic_mouse_more_informations_in_the_comments](https://www.reddit.com/r/3Dprinting/comments/1852jgf/ergonomic_mouse_more_informations_in_the_comments)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-11-27T13:06:30+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1852jgf/ergonomic_mouse_more_informations_in_the_comments/"> <img alt="Ergonomic Mouse (more informations in the comments)" src="https://a.thumbs.redditmedia.com/jQ4vWnfpxAX6S0BfAfqtTSghcwI4IypkOVQbXNs_z34.jpg" title="Ergonomic Mouse (more informations in the comments)" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Neighborhood69"> /u/Neighborhood69 </a> <br /> <span><a href="https://www.reddit.com/gallery/1852jgf">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1852jgf/ergonomic_mouse_more_informations_in_the_comments/">[comments]</a></span> </td></tr></table>

## Completed the body of my, 1:8 scale, 2023 F1 car project!
 - [https://www.reddit.com/r/3Dprinting/comments/1852cc7/completed_the_body_of_my_18_scale_2023_f1_car](https://www.reddit.com/r/3Dprinting/comments/1852cc7/completed_the_body_of_my_18_scale_2023_f1_car)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-11-27T12:55:54+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1852cc7/completed_the_body_of_my_18_scale_2023_f1_car/"> <img alt="Completed the body of my, 1:8 scale, 2023 F1 car project!" src="https://b.thumbs.redditmedia.com/5JvLPzKD2RY1Dug8PjAsKmvris0vDzb6fnuZG3x3Z_Y.jpg" title="Completed the body of my, 1:8 scale, 2023 F1 car project!" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/stllabs"> /u/stllabs </a> <br /> <span><a href="https://www.reddit.com/gallery/1852cc7">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1852cc7/completed_the_body_of_my_18_scale_2023_f1_car/">[comments]</a></span> </td></tr></table>

## What do i do
 - [https://www.reddit.com/r/3Dprinting/comments/1851h02/what_do_i_do](https://www.reddit.com/r/3Dprinting/comments/1851h02/what_do_i_do)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-11-27T12:06:23+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1851h02/what_do_i_do/"> <img alt="What do i do" src="https://preview.redd.it/yz0tjkjcsv2c1.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=3b3c9202d9fc034a1bd3d80842d8f09bb51e7f46" title="What do i do" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>So i want to change filament on my creality k1 but i think i messed up. I cut it off and i didnt pull it out. What can i do?</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/WinnerStandard1070"> /u/WinnerStandard1070 </a> <br /> <span><a href="https://i.redd.it/yz0tjkjcsv2c1.jpg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1851h02/what_do_i_do/">[comments]</a></span> </td></tr></table>

## TPU Sleeve for the AirPods Pro which makes them fit much better
 - [https://www.reddit.com/r/3Dprinting/comments/1851b8g/tpu_sleeve_for_the_airpods_pro_which_makes_them](https://www.reddit.com/r/3Dprinting/comments/1851b8g/tpu_sleeve_for_the_airpods_pro_which_makes_them)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-11-27T11:57:25+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1851b8g/tpu_sleeve_for_the_airpods_pro_which_makes_them/"> <img alt="TPU Sleeve for the AirPods Pro which makes them fit much better" src="https://a.thumbs.redditmedia.com/u_vKFbfoml0GVIHyx_7a6_hZZPTjPSk7yGJ8Yb1AuW0.jpg" title="TPU Sleeve for the AirPods Pro which makes them fit much better" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/jacknoris111"> /u/jacknoris111 </a> <br /> <span><a href="https://www.reddit.com/gallery/18518ve">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1851b8g/tpu_sleeve_for_the_airpods_pro_which_makes_them/">[comments]</a></span> </td></tr></table>

## Dual color silk filament really is something else
 - [https://www.reddit.com/r/3Dprinting/comments/18503ys/dual_color_silk_filament_really_is_something_else](https://www.reddit.com/r/3Dprinting/comments/18503ys/dual_color_silk_filament_really_is_something_else)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-11-27T10:40:41+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18503ys/dual_color_silk_filament_really_is_something_else/"> <img alt="Dual color silk filament really is something else" src="https://b.thumbs.redditmedia.com/7wchgaWXMCfeSlt5GA-9PmiG22pvrKAMQCll9YBB-kM.jpg" title="Dual color silk filament really is something else" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ikilledmypc"> /u/ikilledmypc </a> <br /> <span><a href="https://www.reddit.com/gallery/18503ys">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18503ys/dual_color_silk_filament_really_is_something_else/">[comments]</a></span> </td></tr></table>

## I Need Some Help
 - [https://www.reddit.com/r/3Dprinting/comments/184zssv/i_need_some_help](https://www.reddit.com/r/3Dprinting/comments/184zssv/i_need_some_help)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-11-27T10:19:53+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/184zssv/i_need_some_help/"> <img alt="I Need Some Help" src="https://b.thumbs.redditmedia.com/4-R_Y_BKYci67dcDSPXg6AvrkxgC_tC98IAvjMDoxbc.jpg" title="I Need Some Help" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>My ender 3 s1 pro and i can't manage to level the bed or calibrate it at all. I need help please.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/BrxdleyTM"> /u/BrxdleyTM </a> <br /> <span><a href="https://www.reddit.com/gallery/184zssv">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/184zssv/i_need_some_help/">[comments]</a></span> </td></tr></table>

## Really love printing and modelling things for my IKEA Skådis pegboard
 - [https://www.reddit.com/r/3Dprinting/comments/184zrcy/really_love_printing_and_modelling_things_for_my](https://www.reddit.com/r/3Dprinting/comments/184zrcy/really_love_printing_and_modelling_things_for_my)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-11-27T10:17:16+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/184zrcy/really_love_printing_and_modelling_things_for_my/"> <img alt="Really love printing and modelling things for my IKEA Skådis pegboard" src="https://preview.redd.it/c12j4zjw8v2c1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=6e5c763f392d6df704d89e367899c8a5f986046b" title="Really love printing and modelling things for my IKEA Skådis pegboard" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Some models were found on Printables and Thingiverse, and some I designed myself. Too bad the board is now full, but I can always buy more boards to hang things in.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ThatBotTho"> /u/ThatBotTho </a> <br /> <span><a href="https://i.redd.it/c12j4zjw8v2c1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/184zrcy/really_love_printing_and_modelling_things_for_my/">[comments]</a></span> </td></tr></ta

## that STL got my bowtie rollin' 😂😂😂
 - [https://www.reddit.com/r/3Dprinting/comments/184zhu5/that_stl_got_my_bowtie_rollin](https://www.reddit.com/r/3Dprinting/comments/184zhu5/that_stl_got_my_bowtie_rollin)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-11-27T09:59:51+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/184zhu5/that_stl_got_my_bowtie_rollin/"> <img alt="that STL got my bowtie rollin' 😂😂😂" src="https://external-preview.redd.it/bWpxbnh0a3M1djJjMQZkBVuQBx07OBhVQkETDvSQVXeVXcKcN5F6cydkcLeP.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=eb1ed4ea8008aa4cd012a2543817e760abe5cf87" title="that STL got my bowtie rollin' 😂😂😂" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Comgrow3D"> /u/Comgrow3D </a> <br /> <span><a href="https://v.redd.it/03mqhfwm5v2c1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/184zhu5/that_stl_got_my_bowtie_rollin/">[comments]</a></span> </td></tr></table>

## Before/after printer maintenance
 - [https://www.reddit.com/r/3Dprinting/comments/184zaca/beforeafter_printer_maintenance](https://www.reddit.com/r/3Dprinting/comments/184zaca/beforeafter_printer_maintenance)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-11-27T09:44:34+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/184zaca/beforeafter_printer_maintenance/"> <img alt="Before/after printer maintenance" src="https://b.thumbs.redditmedia.com/azJxeBTE2cLUwzST3FjrQIyCsLOxTeBcelfUojVrANI.jpg" title="Before/after printer maintenance" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Old CR-10 S4 that I had stored away for just over a year and decided to pull it out as a coworker was nagging me about printing him some stuff for some time.</p> <p>First print was right after setting it, though after I figured out x endstop switch issue. Let's just say, worst complete print I have ever had. </p> <p>2nd picture is after oiling bearings, making sure all bolts were tight (found some on rails that were a bit loose), replaced nozzle. </p> <p>Both prints with same roll of filament about 2 days apart.</p> <p>Things still to come are bearings/rollers (noticed 3 that were either shot or on the way), z-rods rattling at higher speed movement(cur

## Is Qidi Tech X Plus 3 Opensourced?
 - [https://www.reddit.com/r/3Dprinting/comments/184y3kj/is_qidi_tech_x_plus_3_opensourced](https://www.reddit.com/r/3Dprinting/comments/184y3kj/is_qidi_tech_x_plus_3_opensourced)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-11-27T08:17:56+00:00

<!-- SC_OFF --><div class="md"><p>Hey everyone, with the sales going around, the Qidi X Plus 3 sounds extremely enticing with its features. However, I am considering putting significant time and effort into this hobby, but I have no clue if the Tech X Plus 3 is open-sourced. I have searched for several hours and cannot even get a proper mention if it is open-sourced. Since I am going to put much of my time into 3D printing, it would be great to know if Qidi allows users to be extremely flexible in regard to the hardware and software of the 3D printer so users can fit their needs. I also would like to know for anyone who has used Tech X Plus 3 how much it fares in customizability to an open-sourced 3D printer like the SV06. Thank you very much and it would also be nice for any suggestions for 3D printers in the $500-$600 range.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Stunning_Tension_468"> /u/Stunning_Tension_468 </a> <br /> <span><a href

## Calvin and Hobbes deserved better. I’m sure everyone else out there already thought to themselves, "Don’t use a brown filament to print lumpy little snowman miniatures. That’ll look like poop on a platter." But for anyone else who may not have thought it through…
 - [https://www.reddit.com/r/3Dprinting/comments/184wocf/calvin_and_hobbes_deserved_better_im_sure](https://www.reddit.com/r/3Dprinting/comments/184wocf/calvin_and_hobbes_deserved_better_im_sure)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-11-27T06:41:10+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/184wocf/calvin_and_hobbes_deserved_better_im_sure/"> <img alt="Calvin and Hobbes deserved better. I’m sure everyone else out there already thought to themselves, &quot;Don’t use a brown filament to print lumpy little snowman miniatures. That’ll look like poop on a platter.&quot; But for anyone else who may not have thought it through…" src="https://preview.redd.it/mlkz6cin5u2c1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=96f251fed08c89d3888ba77353502baad85255c8" title="Calvin and Hobbes deserved better. I’m sure everyone else out there already thought to themselves, &quot;Don’t use a brown filament to print lumpy little snowman miniatures. That’ll look like poop on a platter.&quot; But for anyone else who may not have thought it through…" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/H2olt"> /u/H2olt </a> <br /> <span><a href="https://i.redd.it/mlkz6cin5u2c1.png">[link]</a></

## CF-PETG looks great!
 - [https://www.reddit.com/r/3Dprinting/comments/184vm56/cfpetg_looks_great](https://www.reddit.com/r/3Dprinting/comments/184vm56/cfpetg_looks_great)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-11-27T05:34:39+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/184vm56/cfpetg_looks_great/"> <img alt="CF-PETG looks great!" src="https://preview.redd.it/2h187aehut2c1.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=af89fc73ecfcce5e906170e8dca3950af60dc0fd" title="CF-PETG looks great!" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Just finished printing the new camera mount for my LED staff that I bring to cons, and this blue CF-PETG from Bambu looks awesome!</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Superseaslug"> /u/Superseaslug </a> <br /> <span><a href="https://i.redd.it/2h187aehut2c1.jpg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/184vm56/cfpetg_looks_great/">[comments]</a></span> </td></tr></table>

## Doing some testing with hilbert curve on the first layer with dual color filament.
 - [https://www.reddit.com/r/3Dprinting/comments/184vim1/doing_some_testing_with_hilbert_curve_on_the](https://www.reddit.com/r/3Dprinting/comments/184vim1/doing_some_testing_with_hilbert_curve_on_the)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-11-27T05:28:34+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/184vim1/doing_some_testing_with_hilbert_curve_on_the/"> <img alt="Doing some testing with hilbert curve on the first layer with dual color filament." src="https://b.thumbs.redditmedia.com/Y8Q6Q1l3IGr6eGV6V_XRpfGt4Rjby08qjhx6Ch7ef4Y.jpg" title="Doing some testing with hilbert curve on the first layer with dual color filament." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/areinhart66"> /u/areinhart66 </a> <br /> <span><a href="https://www.reddit.com/gallery/184vim1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/184vim1/doing_some_testing_with_hilbert_curve_on_the/">[comments]</a></span> </td></tr></table>

## Is this a good deal or more trouble than it's worth for a newbie?
 - [https://www.reddit.com/r/3Dprinting/comments/184uz23/is_this_a_good_deal_or_more_trouble_than_its](https://www.reddit.com/r/3Dprinting/comments/184uz23/is_this_a_good_deal_or_more_trouble_than_its)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-11-27T04:56:33+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/184uz23/is_this_a_good_deal_or_more_trouble_than_its/"> <img alt="Is this a good deal or more trouble than it's worth for a newbie?" src="https://preview.redd.it/wogkfzqont2c1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=1f81dc8334d3ed7547f333befa6b3f824faebe8e" title="Is this a good deal or more trouble than it's worth for a newbie?" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I don't currently have a 3D printer, but do have a pretty decent woodshop and laser. I honestly haven't had the time to properly research the current machines but I figured I'd check here before dropping $200 on dust collecotors. Thanks.</p> <p>2x Ended Pro 1x Voxelab Aquilla x2</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Mixitman"> /u/Mixitman </a> <br /> <span><a href="https://i.redd.it/wogkfzqont2c1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/com

## 3D Printed Starlink Flatmount
 - [https://www.reddit.com/r/3Dprinting/comments/184tyba/3d_printed_starlink_flatmount](https://www.reddit.com/r/3Dprinting/comments/184tyba/3d_printed_starlink_flatmount)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-11-27T03:59:05+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/184tyba/3d_printed_starlink_flatmount/"> <img alt="3D Printed Starlink Flatmount" src="https://external-preview.redd.it/b2wwODN5emVkdDJjMVwmcdmEXOUo4ZeZvw4nTbJMUt9c0cjMQ7X_krC-ljg-.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=dd6ae024e20fbe8847319d2c04030b48e9f4eab3" title="3D Printed Starlink Flatmount" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Timhaiti"> /u/Timhaiti </a> <br /> <span><a href="https://v.redd.it/i6gsth4fdt2c1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/184tyba/3d_printed_starlink_flatmount/">[comments]</a></span> </td></tr></table>

## Custom printed Nightingale from Skyrim
 - [https://www.reddit.com/r/3Dprinting/comments/184snik/custom_printed_nightingale_from_skyrim](https://www.reddit.com/r/3Dprinting/comments/184snik/custom_printed_nightingale_from_skyrim)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-11-27T02:52:27+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/184snik/custom_printed_nightingale_from_skyrim/"> <img alt="Custom printed Nightingale from Skyrim" src="https://preview.redd.it/pb9newof1t2c1.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=57759cafe40e1a1c0b9fb33d679d63c3a5c44178" title="Custom printed Nightingale from Skyrim" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Hexxegone"> /u/Hexxegone </a> <br /> <span><a href="https://i.redd.it/pb9newof1t2c1.jpg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/184snik/custom_printed_nightingale_from_skyrim/">[comments]</a></span> </td></tr></table>

## I hope I won't get disqualified from MakerWorld "Make my sign" contest...
 - [https://www.reddit.com/r/3Dprinting/comments/184sjp6/i_hope_i_wont_get_disqualified_from_makerworld](https://www.reddit.com/r/3Dprinting/comments/184sjp6/i_hope_i_wont_get_disqualified_from_makerworld)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-11-27T02:47:11+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/184sjp6/i_hope_i_wont_get_disqualified_from_makerworld/"> <img alt="I hope I won't get disqualified from MakerWorld &quot;Make my sign&quot; contest..." src="https://b.thumbs.redditmedia.com/Eojchn2uv5M2-qaR69TKlrRkOgEDUrTO5K52W0axJ4s.jpg" title="I hope I won't get disqualified from MakerWorld &quot;Make my sign&quot; contest..." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/nexflatline"> /u/nexflatline </a> <br /> <span><a href="https://www.reddit.com/gallery/184sjp6">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/184sjp6/i_hope_i_wont_get_disqualified_from_makerworld/">[comments]</a></span> </td></tr></table>

## Any thing I should know before I start printing with this?
 - [https://www.reddit.com/r/3Dprinting/comments/184sf57/any_thing_i_should_know_before_i_start_printing](https://www.reddit.com/r/3Dprinting/comments/184sf57/any_thing_i_should_know_before_i_start_printing)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-11-27T02:40:54+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/184sf57/any_thing_i_should_know_before_i_start_printing/"> <img alt="Any thing I should know before I start printing with this?" src="https://preview.redd.it/ai02n4jgzs2c1.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=0bae7eedd3c52692898ad97b4f152cc0b2f6e883" title="Any thing I should know before I start printing with this?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/loose_cannon007"> /u/loose_cannon007 </a> <br /> <span><a href="https://i.redd.it/ai02n4jgzs2c1.jpg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/184sf57/any_thing_i_should_know_before_i_start_printing/">[comments]</a></span> </td></tr></table>

## All the same filament! Tri-color is so cool!
 - [https://www.reddit.com/r/3Dprinting/comments/184se02/all_the_same_filament_tricolor_is_so_cool](https://www.reddit.com/r/3Dprinting/comments/184se02/all_the_same_filament_tricolor_is_so_cool)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-11-27T02:39:19+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/184se02/all_the_same_filament_tricolor_is_so_cool/"> <img alt="All the same filament! Tri-color is so cool!" src="https://preview.redd.it/lwc66f86zs2c1.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=97f810acfb04da67cfef659ed08a7a0dc20d78a5" title="All the same filament! Tri-color is so cool!" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Printed on the Ender 3v2 in vase mode!</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/loose_cannon007"> /u/loose_cannon007 </a> <br /> <span><a href="https://i.redd.it/lwc66f86zs2c1.jpg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/184se02/all_the_same_filament_tricolor_is_so_cool/">[comments]</a></span> </td></tr></table>

## My first Benchy!!!
 - [https://www.reddit.com/r/3Dprinting/comments/184qqyc/my_first_benchy](https://www.reddit.com/r/3Dprinting/comments/184qqyc/my_first_benchy)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-11-27T01:19:00+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/184qqyc/my_first_benchy/"> <img alt="My first Benchy!!!" src="https://preview.redd.it/zplufidvks2c1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=349c3a245a29756cd7e5584bff2d5fd560ff7287" title="My first Benchy!!!" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Just got my very first 3D printer on a Black Friday sale (Anycubic Kobra 2 Neo) and it's awesome!!! I printed my very first Benchy and it was awesome!!</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Orrera_"> /u/Orrera_ </a> <br /> <span><a href="https://i.redd.it/zplufidvks2c1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/184qqyc/my_first_benchy/">[comments]</a></span> </td></tr></table>

## My cousin thinks she's clever.
 - [https://www.reddit.com/r/3Dprinting/comments/184p9bf/my_cousin_thinks_shes_clever](https://www.reddit.com/r/3Dprinting/comments/184p9bf/my_cousin_thinks_shes_clever)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-11-27T00:10:26+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/184p9bf/my_cousin_thinks_shes_clever/"> <img alt="My cousin thinks she's clever." src="https://preview.redd.it/3s3vekxm8s2c1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=21eb5c1d0d4d3ddf9ff13f3bb96712c3dbd7b2fe" title="My cousin thinks she's clever." /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Last year my cousin wrapped my present in a few rolls of tape so I would struggle to get into it. This year is the first year i have been designing and 3d printing things. For Christmas for her I have encased £20 in a 40x100mm cylinder with 10mm thick solid walls all around. You may think it's overkill but it will be funny and that makes it worth it to me lol.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/jddgfhdhrhbhks"> /u/jddgfhdhrhbhks </a> <br /> <span><a href="https://i.redd.it/3s3vekxm8s2c1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dpri

