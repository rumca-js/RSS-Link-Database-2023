# Source:LMG Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFLFc8Lpbwt4jPtY1_Ai5yA, language:en-US

## Dennis Sponsor Spots Vol. 2
 - [https://www.youtube.com/watch?v=zHuo2DccurE](https://www.youtube.com/watch?v=zHuo2DccurE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFLFc8Lpbwt4jPtY1_Ai5yA
 - date published: 2023-11-27T21:00:29+00:00

We let Dennis make more sponsor spots, for some reason.

Original videos:
The Ridge(Linus Tec Tips November 13, 2023): https://youtu.be/ZdGhTOKPRo8?si=-e54_-7yXceDv-We
----- Check out the Ridge Carry-On Luggage and the rest of their offerings at https://www.ridge.com/LINUS Save 10% and Free Shipping at Ridge by using offer code LINUS!

Govee(GameLinked September 26, 2023): https://youtu.be/NECyQhw4-_c?si=N4USYpfbDHhjO7ur
------ Check out Govee’s new Glide Hexagon Light Panels Ultra and more using the links below!
Govee Website: https://bit.ly/3P5iptJ
Amazon Store: https://amzn.to/3PtCrjh

FlexiSpot (Linus Tech Tips September 24, 2023): https://youtu.be/z9XWN7u8mSU?si=jHgKZgNQ77A9DaeM
------ FlexiSpot Sale, use the code "LINUS30' to save $30 on purchases over $500
US:  https://bit.ly/3rmPGcc
CAN: https://bit.ly/3qEuXjy


► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► OUR WAN PODCAST GEAR: https://lmg.

