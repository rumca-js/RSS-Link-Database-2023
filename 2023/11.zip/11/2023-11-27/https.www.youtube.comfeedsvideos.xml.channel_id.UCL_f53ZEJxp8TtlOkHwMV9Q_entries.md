# Source:Jordan B Peterson, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCL_f53ZEJxp8TtlOkHwMV9Q, language:en-US

## An Alternative to Western Nihilism | His Excellency Saeed Al Nazari | EP 400
 - [https://www.youtube.com/watch?v=bgfyxc1NN58](https://www.youtube.com/watch?v=bgfyxc1NN58)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCL_f53ZEJxp8TtlOkHwMV9Q
 - date published: 2023-11-27T22:00:17+00:00

Dr. Jordan B Peterson sits down with the Secretary General of Great Arab Minds, His Excellency Saeed Al Nazari. They discuss the origins of the United Arab Emirates, how the Abraham Accords and a Tri-Faith system have taken effect and opened dialogue, the projects spearheaded by Saeed for the education, entrepreneurialism and empowerment of young Emiratees, and why the unique vision and strong values of the UAE have lifted the country to unimaginable heights in only half a century.

​​His Excellency Saeed Al Nazari is the Secretary General of Great Arab Minds. He is also spearheading Transformational Projects and Creative Affairs at the Executive Office of His Highness Sheikh Mohammed bin Rashid Al Maktoum, in addition to the Mohammed bin Rashid Leadership Development Center and the Arab Strategy Forum.

Dr. Peterson's extensive catalog is available now on DailyWire+: https://bit.ly/3KrWbS8


- Sponsors -

ExpressVPN: Get 3 Months FREE of ExpressVPN: https://expressvpn.com/jordan

Pr

