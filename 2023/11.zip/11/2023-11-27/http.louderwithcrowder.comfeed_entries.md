# Source:Louder With Crowder, URL:http://louderwithcrowder.com/feed/, language:en-US

## WH Reporter Interrupts Question Question About Stevie Wonder So Ridiculous, The Other Reporters Laughed At Her
 - [https://www.louderwithcrowder.com/april-ryan-wonder](https://www.louderwithcrowder.com/april-ryan-wonder)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-11-27T23:30:12+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=50575044&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C0" /><br /><br /><p>We all know what Democrats think, “If you have a problem figuring out whether you’re for [Biden] or Trump, then you ain’t black.”</p><p>Election season is right around the corner. This means that Democrats will begin virtue signaling their butts off in an attempt to hold on to minority votes as the left screams about things no one cares about, as shown in today's press brieifing. </p><p>Far-left reporter April Ryan asked Karine Jean-Pierre if President Biden would be “amenable to meeting with Stevie Wonder” to discuss his concerns with the administration regarding “the black agenda falling along the wayside." </p><p>Obviously, her very serious statement was interrupted by others laughing at her questionable train of thought.</p><p>The left has made it very clear they feel they are entitled to every vote in the Black community, e

## NYC Passes New Law, It's Now Discrimination To Judge Fat People For Being Fat
 - [https://www.louderwithcrowder.com/nyc-weight-law](https://www.louderwithcrowder.com/nyc-weight-law)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-11-27T23:24:17+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=50575022&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C0" /><br /><br /><p>In America, obesity is not treated as a health emergency. In fact, it is seen as quite the opposite. Obesity is often a manifestation of gluttony. One reason that this sin is so shameful is that it is the hardest sin to hide from the public. Any notion of shame is considered to be bad because it may subsequently turn into a hindrance to degenerate lifestyles, at least according to most progressive causes.</p><p>Gluttony is an excessive indulgence of eating. It also subsequently disregards moderation, which arguably makes it a deception of moral reasoning. Like most progressive causes, the Body Positivity movement is essentially a form of groupthink where the sole purpose is to validate self-destructive behavior. </p><p>Fat people don't deserve to be punished. But they also don’t deserve special treatment. However, according to l

## Canadian Government: Celebrating Christmas And Easter Amounts To “Systemic Religious Discrimination”
 - [https://www.louderwithcrowder.com/christmas-easter-canada](https://www.louderwithcrowder.com/christmas-easter-canada)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-11-27T22:00:22+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=50574541&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C0" /><br /><br /><p>It is not a new phenomenon when a political group tries to subvert culture in an attempt to gain power. In one example, the war on Christmas has been going on for several hundred years. </p><p>In the days of the<a href="https://ancestralfindings.com/russian-christmas-traditions-you-should-know/" rel="noopener noreferrer" target="_blank"> Soviet Union</a>, Christmas was not celebrated. In fact, following the revolution in 1917, Christmas was banned as a religious holiday and Christmas Trees were banned until 1935 when they turned into New Year Trees. If people did want to celebrate the holiday, they had to do it in secret. </p><p>But Christmas hatred is not unique to the soviet union. Disgust for the holiday is quite common among oppressive regimes. </p><p>French rulers <a href="https://slife.org/christmas/" rel="noopener norefer

## YouTube suspended us for our Bongino episode. Not because of anything we said. They just hate Bongino's existence.
 - [https://www.louderwithcrowder.com/crowder-bongino-youtube-suspension](https://www.louderwithcrowder.com/crowder-bongino-youtube-suspension)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-11-27T21:50:14+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=50574355&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C0" /><br /><br /><p>Stop me if you've heard this one before: YouTube removed some of our videos and suspended us over something really f*cking stupid. Maybe not as dumb as <a href="https://www.louderwithcrowder.com/steven-crowder-youtube-strike" target="_blank">suspending us over a FIFTEEN-MONTH-OLD VIDEO</a>. But I'd say this is at least a close second, and it involves our friend Dan Bongino.</p><p>Fresh off of an extended Thanksgiving break of lecturing their grandparents about pronouns and making their parents embarrassed for ever having kids, YouTube employees took down the video of the Crowder X Bongino Joint Livestream. That's the Crowder main page. They also took down a clip of Bongino and Crowder talking about police fights on our CrowderBits page.</p><p>And I know what you're thinking: "But I thought you guys have a YouTube dump button for

## Watch: Senator not only admits she's limiting your freedom, she brags about it "for the common good"
 - [https://www.louderwithcrowder.com/irish-senator-online-hate-crime](https://www.louderwithcrowder.com/irish-senator-online-hate-crime)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-11-27T18:43:31+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=50572665&amp;width=1200&amp;height=800&amp;coordinates=144%2C0%2C56%2C0" /><br /><br /><p>I'm glad this is happening to Ireland right now. Not to Ireland specifically, but happening so Americans can see what could happen here if we aren't careful. We have an election next year where we need to be thinking long and hard, comparing candidate policies and past records of electoral victory, and making sure the Left is removed from the White House.</p><p>If not? Instead of Irish Senator Pauline O'Reilly, this could easily be Joe Biden or social media influencer Rep. AOC. By "easily," I mean it sounds like them now. But we have a Bill of Rights (for now), and Ireland does not.</p><p>"When you think about it, all law, all legislation is about the restriction of freedom. That's exactly what we're doing here. We are restricting freedom. But we're doing it for the common good. "</p><p>She then says's the job of the governme

## A TikTok Video On Bidenomics Has Team Biden So Wee-wee'd Up, They Want Social Media To Label It Misinformation
 - [https://www.louderwithcrowder.com/biden-misinformation-economy](https://www.louderwithcrowder.com/biden-misinformation-economy)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-11-27T17:46:12+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=50572580&amp;width=1200&amp;height=800&amp;coordinates=133%2C0%2C67%2C0" /><br /><br /><p>You don’t need to log onto social media to know that every time families shop at the grocery store, they get an expensive taste of Sleepy Joe's economy, otherwise known as “Bidenomics.” </p><p>Americans are currently dealing with elevated levels of inflation that have not been seen in decades and the White House wants you to disbelieve your eyes to improve low approval ratings on the economy.</p><p>A TikTok <a href="https://www.tiktok.com/@topherolive/video/7179658803867077934?embed_source=121355058%2C121351166%2C121331973%2C120811592%2C120810756%3Bnull%3Bembed_blank&amp;refer=embed&amp;referer_url=www.washingtonexaminer.com%2Fnews%2Fbusiness%2Ftiktoker-mcdonalds-meal-cost-over-16&amp;referer_video_id=7179658803867077934" target="_blank">video </a>of a man claiming that his double quarter pounder meal cost $16.10 is circulati

## “That does not sound like antisemitic rhetoric to me": Elon Musk travels to Israel, calls for Hamas to be destroyed
 - [https://www.louderwithcrowder.com/elon-musk-israel](https://www.louderwithcrowder.com/elon-musk-israel)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-11-27T17:07:11+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=50572338&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C0" /><br /><br /><p>Elon Musk <a href="https://abcnews.go.com/Business/wireStory/elon-musk-visits-israel-meet-top-leaders-accusations-105175868" rel="noopener noreferrer" target="_blank">is on a visit to Israel</a> where he toured a rural village that was attacked by Hamas last month and is set to meet with top leaders. Today’s show gets into that.</p><p class="shortcode-media shortcode-media-rumble">

</p><p>Musk and Prime Minister Benjamin Netanyahu toured the Kfar Aza kibbutz that Hamas stormed on Oct. 7. He also visited the homes of some victims, including the family of Abigail Edan, a 4-year-old girl who was held hostage by Hamas after her parents were killed. She was released Sunday in the latest round of exchanges. </p><p>"I think that [Israel] has every right to execute every single last member of Hamas, but it is not lost on me that the mo

## Mayim Bialik wonders where the feminists are and why they're not condemning the systematic rape and torture by Hamas
 - [https://www.louderwithcrowder.com/mayim-bialik-un-women](https://www.louderwithcrowder.com/mayim-bialik-un-women)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-11-27T14:42:10+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=50571177&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C0" /><br /><br /><p>
	Like many Jewish progressives post October 7th, actress Mayim Bialik is wondering where her social justice peers on the Left are. She was there to say black lives matter, believe all women, and me too. Yet after the terror attack where Hamas systematically raped and tortured Jewish women (and children), there is a whole lot of silence <a href="https://www.louderwithcrowder.com/susan-sarandon-son" target="_blank">unless it's supporting the terrorists</a>.
</p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/DrEliDavid/status/1725516110248739003"></a>
</blockquote>
<p>
	Bialik dropped X calling the global women's organizations out for their silence. Most notable is the U.N. Women - the United Nations Entity for Gender Equality and the Empowerment of Women.

## Watch Today's Show: Ireland Riots After Migrant Stabbing, McGregor Investigated for Hate Speech?!
 - [https://www.louderwithcrowder.com/ireland-riots](https://www.louderwithcrowder.com/ireland-riots)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-11-27T13:59:24+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.webp?id=50571071&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C1" /><br /><br /><p>We have lots to discuss today, including Ireland's immigration crisis, stabbings by an Algerian migrant & subsequent protests, Conor McGregor being investigated for hate speech for his comments, the young Kansas City Chiefs fan who donned black face and Native American headdress at the game, leftists in media spread false rumors that South Carolina-Clemson fans booed Trump and more! </p><p class="shortcode-media shortcode-media-rumble">

</p><p><strong>ELON VISITS ISRAEL</strong></p><ul><li><a href="https://twitter.com/songsofyoni/status/1729094009027752430" target="_blank">Elon Musk in Israel</a></li><li><a href="https://www.mediamatters.org/twitter/musk-endorses-antisemitic-conspiracy-theory-x-has-been-placing-ads-apple-bravo-ibm-oracle" rel="noopener noreferrer" target="_blank">As Musk endorses antisemitic conspiracy theory,

## NYC school tries to cover up safety officer getting assaulted, same school that rioted and terrorized Jewish teacher
 - [https://www.louderwithcrowder.com/queens-school-safety-officer](https://www.louderwithcrowder.com/queens-school-safety-officer)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-11-27T13:26:33+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=50570705&amp;width=1200&amp;height=800&amp;coordinates=131%2C0%2C69%2C0" /><br /><br /><p>News broke over the weekend of a Queens school where students started a riot, targeting a Jewish teacher that <a href="https://www.louderwithcrowder.com/nyc-school-riot-jewish" target="_blank">had to be LOCKED IN HER CLASSROOM</a> for her own safety. Mayor Eric Adams said in response that, quote, this was not who New York City was.</p><p>It's growing increasingly clear <a href="https://www.louderwithcrowder.com/jewish-student-barricaded" target="_blank">that this is exactly who New York City is</a>. It's definitely who the administration of Hillcrest High School is. A week before they attempted to cover up a riot, they attempted to cover up a school safety officer getting brutally assaulted by students.</p><p>That is the accusation being made by Councilwoman Vickie Paladino, who shared a video provided to her by a whistleblow

## They're investigating Conor McGregor for "online hate speech" over tweets criticizing Irish govt, migrant stabbing
 - [https://www.louderwithcrowder.com/conor-mcgregor-online-hate-speech](https://www.louderwithcrowder.com/conor-mcgregor-online-hate-speech)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-11-27T12:37:53+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=50570315&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C0" /><br /><br /><p>UFC fighter Conor McGregor spoke out about his government and an alleged migrant stabbing. He is now under investigation for "online hate speech." This is where we say "Pay Attention, America."</p><p>You may have read on X about how Ireland wants new hate crime laws. Conor is being investigated under the old hate crime laws. The new laws the Irish government wants are utter insanity.</p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/EndWokeness/status/1728886773613543896"></a>
</blockquote>
<p>McGregor is being investigated under basic hate crime laws. <a href="https://www.louderwithcrowder.com/man-arrested-for-social-media-post" target="_blank">The kind that says you can't give anyone anxiety</a>. The kind where the <a href="https://www.louderwithcrowde

