# Source:Reuters - World News, URL:https://www.reuters.com/world/, language:en

## Britain's Sunak cancels meeting with Greek PM in row over Parthenon sculptures
 - [https://www.reuters.com/world/europe/greek-pm-expresses-annoyance-after-meeting-with-british-pm-cancelled-over-2023-11-27](https://www.reuters.com/world/europe/greek-pm-expresses-annoyance-after-meeting-with-british-pm-cancelled-over-2023-11-27)
 - RSS feed: https://www.reuters.com/world/
 - date published: 2023-11-27T22:29:59.751679+00:00

Britain's Sunak cancels meeting with Greek PM in row over Parthenon sculptures

## North Korea's Kim received photos taken by spy satellite of White House, Pentagon -KCNA
 - [https://www.reuters.com/world/asia-pacific/north-koreas-kim-received-photos-taken-by-spy-satellite-white-house-pentagon-2023-11-27](https://www.reuters.com/world/asia-pacific/north-koreas-kim-received-photos-taken-by-spy-satellite-white-house-pentagon-2023-11-27)
 - RSS feed: https://www.reuters.com/world/
 - date published: 2023-11-27T22:29:47.834541+00:00

North Korea's Kim received photos taken by spy satellite of White House, Pentagon -KCNA

## Putin approves big military spending hikes for Russia's budget
 - [https://www.reuters.com/world/europe/putin-approves-big-military-spending-hikes-russias-budget-2023-11-27](https://www.reuters.com/world/europe/putin-approves-big-military-spending-hikes-russias-budget-2023-11-27)
 - RSS feed: https://www.reuters.com/world/
 - date published: 2023-11-27T21:47:54.614348+00:00

Putin approves big military spending hikes for Russia's budget

## Twenty killed in Sierra Leone attack and nearly 2,000 prisoners escape
 - [https://www.reuters.com/world/africa/sierra-leones-capital-quiet-after-attack-barracks-2023-11-27](https://www.reuters.com/world/africa/sierra-leones-capital-quiet-after-attack-barracks-2023-11-27)
 - RSS feed: https://www.reuters.com/world/
 - date published: 2023-11-27T21:29:07.244998+00:00

Twenty killed in Sierra Leone attack and nearly 2,000 prisoners escape

## North Korea, US envoys engage in rare, public sparring match at UN
 - [https://www.reuters.com/world/asia-pacific/north-korea-us-envoys-engage-rare-public-sparring-match-un-2023-11-27](https://www.reuters.com/world/asia-pacific/north-korea-us-envoys-engage-rare-public-sparring-match-un-2023-11-27)
 - RSS feed: https://www.reuters.com/world/
 - date published: 2023-11-27T20:47:01.135460+00:00

North Korea, US envoys engage in rare, public sparring match at UN

## Drones show how Israeli bombs turned Gaza into moonscape
 - [https://www.reuters.com/world/middle-east/drones-show-how-israeli-bombs-turned-gaza-into-moonscape-2023-11-27](https://www.reuters.com/world/middle-east/drones-show-how-israeli-bombs-turned-gaza-into-moonscape-2023-11-27)
 - RSS feed: https://www.reuters.com/world/
 - date published: 2023-11-27T20:27:05.082914+00:00

Drones show how Israeli bombs turned Gaza into moonscape

## Israeli hostage, 84, released by Hamas in 'fight for her life'
 - [https://www.reuters.com/world/middle-east/israeli-hostage-84-released-by-hamas-fight-her-life-2023-11-27](https://www.reuters.com/world/middle-east/israeli-hostage-84-released-by-hamas-fight-her-life-2023-11-27)
 - RSS feed: https://www.reuters.com/world/
 - date published: 2023-11-27T20:07:11.061680+00:00

Israeli hostage, 84, released by Hamas in 'fight for her life'

## Suspect arraigned in shooting of three Palestinian American students in Vermont
 - [https://www.reuters.com/world/suspect-arraigned-shooting-three-palestinian-american-students-vermont-2023-11-27](https://www.reuters.com/world/suspect-arraigned-shooting-three-palestinian-american-students-vermont-2023-11-27)
 - RSS feed: https://www.reuters.com/world/
 - date published: 2023-11-27T17:48:56.129975+00:00

Suspect arraigned in shooting of three Palestinian American students in Vermont

## Arab states, EU agree on need for two-state solution to Israel crisis
 - [https://www.reuters.com/world/europe/four-day-truce-israel-hamas-conflict-is-important-first-step-eus-borrell-2023-11-27](https://www.reuters.com/world/europe/four-day-truce-israel-hamas-conflict-is-important-first-step-eus-borrell-2023-11-27)
 - RSS feed: https://www.reuters.com/world/
 - date published: 2023-11-27T17:28:08.615967+00:00

Arab states, EU agree on need for two-state solution to Israel crisis

## Finland plans more measures to stop asylum surge from Russia border
 - [https://www.reuters.com/world/europe/finland-expects-more-asylum-seekers-arrive-russia-pm-says-2023-11-27](https://www.reuters.com/world/europe/finland-expects-more-asylum-seekers-arrive-russia-pm-says-2023-11-27)
 - RSS feed: https://www.reuters.com/world/
 - date published: 2023-11-27T17:06:53.683161+00:00

Finland plans more measures to stop asylum surge from Russia border

## Elon Musk to Israel: 'propaganda' that begets murder must be stopped
 - [https://www.reuters.com/world/middle-east/elon-musk-israel-propaganda-that-begets-murder-must-be-stopped-2023-11-27](https://www.reuters.com/world/middle-east/elon-musk-israel-propaganda-that-begets-murder-must-be-stopped-2023-11-27)
 - RSS feed: https://www.reuters.com/world/
 - date published: 2023-11-27T16:02:25.049417+00:00

Elon Musk to Israel: 'propaganda' that begets murder must be stopped

## Tears and laughter on Gaza beach as children get break from war
 - [https://www.reuters.com/world/middle-east/tears-laughter-gaza-beach-children-get-break-war-2023-11-27](https://www.reuters.com/world/middle-east/tears-laughter-gaza-beach-children-get-break-war-2023-11-27)
 - RSS feed: https://www.reuters.com/world/
 - date published: 2023-11-27T14:27:23.674409+00:00

Tears and laughter on Gaza beach as children get break from war

## Paris mayor quits X platform, calling it a 'gigantic global sewer'
 - [https://www.reuters.com/world/europe/paris-mayor-quits-x-platform-calling-it-gigantic-global-sewer-2023-11-27](https://www.reuters.com/world/europe/paris-mayor-quits-x-platform-calling-it-gigantic-global-sewer-2023-11-27)
 - RSS feed: https://www.reuters.com/world/
 - date published: 2023-11-27T13:52:09.756913+00:00

Paris mayor quits X platform, calling it a 'gigantic global sewer'

## Polish truckers start round-the-clock blockade of fourth Ukrainian border crossing
 - [https://www.reuters.com/world/europe/polish-truckers-start-round-the-clock-blockade-fourth-ukrainian-border-crossing-2023-11-27](https://www.reuters.com/world/europe/polish-truckers-start-round-the-clock-blockade-fourth-ukrainian-border-crossing-2023-11-27)
 - RSS feed: https://www.reuters.com/world/
 - date published: 2023-11-27T13:07:13.896925+00:00

Polish truckers start round-the-clock blockade of fourth Ukrainian border crossing

## Gaza hostage briefly escaped captors after building was bombed, family says
 - [https://www.reuters.com/world/middle-east/gaza-hostage-briefly-escaped-captors-after-building-was-bombed-family-says-2023-11-27](https://www.reuters.com/world/middle-east/gaza-hostage-briefly-escaped-captors-after-building-was-bombed-family-says-2023-11-27)
 - RSS feed: https://www.reuters.com/world/
 - date published: 2023-11-27T12:46:59.450379+00:00

Gaza hostage briefly escaped captors after building was bombed, family says

## Biden to invoke Cold War-era law to boost medical supplies
 - [https://www.reuters.com/world/us/biden-invoke-cold-war-era-law-boost-medical-supplies-2023-11-27](https://www.reuters.com/world/us/biden-invoke-cold-war-era-law-boost-medical-supplies-2023-11-27)
 - RSS feed: https://www.reuters.com/world/
 - date published: 2023-11-27T11:56:10.477074+00:00

Biden to invoke Cold War-era law to boost medical supplies

## Chinese families of missing Malaysia MH370 plane seek compensation in court
 - [https://www.reuters.com/world/asia-pacific/chinese-families-missing-malaysia-mh370-plane-seek-compensation-court-2023-11-27](https://www.reuters.com/world/asia-pacific/chinese-families-missing-malaysia-mh370-plane-seek-compensation-court-2023-11-27)
 - RSS feed: https://www.reuters.com/world/
 - date published: 2023-11-27T10:44:36.673144+00:00

Chinese families of missing Malaysia MH370 plane seek compensation in court

## In setback, Wilders' first post-election appointee resigns
 - [https://www.reuters.com/world/europe/wilders-scout-leading-first-phase-dutch-election-talks-resigns-2023-11-27](https://www.reuters.com/world/europe/wilders-scout-leading-first-phase-dutch-election-talks-resigns-2023-11-27)
 - RSS feed: https://www.reuters.com/world/
 - date published: 2023-11-27T10:24:41.991969+00:00

In setback, Wilders' first post-election appointee resigns

## Winter storm causes power outages, road closures in Ukraine
 - [https://www.reuters.com/world/europe/winter-storm-causes-power-outages-road-closures-ukraine-2023-11-27](https://www.reuters.com/world/europe/winter-storm-causes-power-outages-road-closures-ukraine-2023-11-27)
 - RSS feed: https://www.reuters.com/world/
 - date published: 2023-11-27T10:24:37.844580+00:00

Winter storm causes power outages, road closures in Ukraine

## In Russia, war and fear trouble one presidential hopeful
 - [https://www.reuters.com/world/europe/russia-war-fear-trouble-one-presidential-hopeful-2023-11-27](https://www.reuters.com/world/europe/russia-war-fear-trouble-one-presidential-hopeful-2023-11-27)
 - RSS feed: https://www.reuters.com/world/
 - date published: 2023-11-27T10:00:49.974947+00:00

In Russia, war and fear trouble one presidential hopeful

## Polish president to swear in government; opposition condemns 'farce'
 - [https://www.reuters.com/world/europe/polish-president-swear-govt-opposition-condemns-farce-2023-11-27](https://www.reuters.com/world/europe/polish-president-swear-govt-opposition-condemns-farce-2023-11-27)
 - RSS feed: https://www.reuters.com/world/
 - date published: 2023-11-27T09:40:05.268186+00:00

Polish president to swear in government; opposition condemns 'farce'

## Beijing frets over Taiwan opposition split as parties go on the attack over China ties
 - [https://www.reuters.com/world/asia-pacific/beijing-frets-over-taiwan-opposition-split-parties-go-attack-over-china-ties-2023-11-27](https://www.reuters.com/world/asia-pacific/beijing-frets-over-taiwan-opposition-split-parties-go-attack-over-china-ties-2023-11-27)
 - RSS feed: https://www.reuters.com/world/
 - date published: 2023-11-27T09:15:36.910769+00:00

Beijing frets over Taiwan opposition split as parties go on the attack over China ties

## China says it values follow-up to MH370 incident
 - [https://www.reuters.com/world/china-says-it-values-follow-up-mh370-incident-2023-11-27](https://www.reuters.com/world/china-says-it-values-follow-up-mh370-incident-2023-11-27)
 - RSS feed: https://www.reuters.com/world/
 - date published: 2023-11-27T08:54:55.316631+00:00

China says it values follow-up to MH370 incident

## China's respiratory illness surge not as high as pre-pandemic- WHO official
 - [https://www.reuters.com/world/china/chinas-respiratory-illness-surge-not-high-pre-pandemic-who-official-2023-11-27](https://www.reuters.com/world/china/chinas-respiratory-illness-surge-not-high-pre-pandemic-who-official-2023-11-27)
 - RSS feed: https://www.reuters.com/world/
 - date published: 2023-11-27T08:36:18.296036+00:00

China's respiratory illness surge not as high as pre-pandemic- WHO official

## New crypto front emerges in Israel's militant financing fight
 - [https://www.reuters.com/world/middle-east/new-crypto-front-emerges-israels-militant-financing-fight-2023-11-27](https://www.reuters.com/world/middle-east/new-crypto-front-emerges-israels-militant-financing-fight-2023-11-27)
 - RSS feed: https://www.reuters.com/world/
 - date published: 2023-11-27T08:36:05.422373+00:00

New crypto front emerges in Israel's militant financing fight

## Elon Musk begins wartime visit to Israel, aviation tracker says
 - [https://www.reuters.com/world/middle-east/elon-musk-begins-wartime-visit-israel-aviation-tracker-says-2023-11-27](https://www.reuters.com/world/middle-east/elon-musk-begins-wartime-visit-israel-aviation-tracker-says-2023-11-27)
 - RSS feed: https://www.reuters.com/world/
 - date published: 2023-11-27T07:54:35.336849+00:00

Elon Musk begins wartime visit to Israel, aviation tracker says

## Almost 30 schools closed in Belgium due to bomb alert
 - [https://www.reuters.com/world/europe/almost-30-schools-closed-belgium-due-bomb-alert-2023-11-27](https://www.reuters.com/world/europe/almost-30-schools-closed-belgium-due-bomb-alert-2023-11-27)
 - RSS feed: https://www.reuters.com/world/
 - date published: 2023-11-27T07:36:39.473964+00:00

Almost 30 schools closed in Belgium due to bomb alert

## South Korean city turns to matchmaking to boost low birth rates
 - [https://www.reuters.com/world/asia-pacific/south-korean-city-turns-matchmaking-boost-low-birth-rates-2023-11-27](https://www.reuters.com/world/asia-pacific/south-korean-city-turns-matchmaking-boost-low-birth-rates-2023-11-27)
 - RSS feed: https://www.reuters.com/world/
 - date published: 2023-11-27T07:13:40.623036+00:00

South Korean city turns to matchmaking to boost low birth rates

## Rainy weather closing in on Indian rescuers trying to reach trapped men
 - [https://www.reuters.com/world/india/rainy-weather-closing-indian-rescuers-trying-reach-trapped-men-2023-11-27](https://www.reuters.com/world/india/rainy-weather-closing-indian-rescuers-trying-reach-trapped-men-2023-11-27)
 - RSS feed: https://www.reuters.com/world/
 - date published: 2023-11-27T05:52:28.551328+00:00

Rainy weather closing in on Indian rescuers trying to reach trapped men

## North Korea lashes out at critics, hints at more satellite launches
 - [https://www.reuters.com/world/asia-pacific/north-korea-lashes-out-critics-hints-more-satellite-launches-2023-11-27](https://www.reuters.com/world/asia-pacific/north-korea-lashes-out-critics-hints-more-satellite-launches-2023-11-27)
 - RSS feed: https://www.reuters.com/world/
 - date published: 2023-11-27T04:33:33.180293+00:00

North Korea lashes out at critics, hints at more satellite launches

## Biden hopes for extension of Israel-Hamas truce as more hostages released
 - [https://www.reuters.com/world/middle-east/biden-hopes-extension-israel-hamas-truce-enters-final-day-2023-11-27](https://www.reuters.com/world/middle-east/biden-hopes-extension-israel-hamas-truce-enters-final-day-2023-11-27)
 - RSS feed: https://www.reuters.com/world/
 - date published: 2023-11-27T04:33:18.021273+00:00

Biden hopes for extension of Israel-Hamas truce as more hostages released

## Vietnam set to raise effective tax rate on multinationals as part of global deal
 - [https://www.reuters.com/world/asia-pacific/vietnam-set-raise-effective-tax-rate-multinationals-part-global-deal-2023-11-27](https://www.reuters.com/world/asia-pacific/vietnam-set-raise-effective-tax-rate-multinationals-part-global-deal-2023-11-27)
 - RSS feed: https://www.reuters.com/world/
 - date published: 2023-11-27T04:33:17.456971+00:00

Vietnam set to raise effective tax rate on multinationals as part of global deal

## North Korea deploys troops, weapons near border after military pact suspended -Yonhap
 - [https://www.reuters.com/world/asia-pacific/north-korea-deploys-troops-weapons-near-border-after-military-pact-suspended-2023-11-27](https://www.reuters.com/world/asia-pacific/north-korea-deploys-troops-weapons-near-border-after-military-pact-suspended-2023-11-27)
 - RSS feed: https://www.reuters.com/world/
 - date published: 2023-11-27T04:33:12.299856+00:00

North Korea deploys troops, weapons near border after military pact suspended -Yonhap

## Netanyahu's two-front war against Hamas and for his own political survival
 - [https://www.reuters.com/world/middle-east/netanyahus-two-front-war-against-hamas-his-own-political-survival-2023-11-27](https://www.reuters.com/world/middle-east/netanyahus-two-front-war-against-hamas-his-own-political-survival-2023-11-27)
 - RSS feed: https://www.reuters.com/world/
 - date published: 2023-11-27T04:33:11.828994+00:00

Netanyahu's two-front war against Hamas and for his own political survival

## Malaysia to allow visa-free entry to Chinese, Indian nationals from Dec. 1
 - [https://www.reuters.com/world/asia-pacific/malaysia-allow-visa-free-entry-china-india-citizens-dec-1-pm-2023-11-27](https://www.reuters.com/world/asia-pacific/malaysia-allow-visa-free-entry-china-india-citizens-dec-1-pm-2023-11-27)
 - RSS feed: https://www.reuters.com/world/
 - date published: 2023-11-27T03:09:19.335719+00:00

Malaysia to allow visa-free entry to Chinese, Indian nationals from Dec. 1

## Six teenagers in court over beheading of French teacher
 - [https://www.reuters.com/world/europe/six-teenagers-court-over-beheading-french-teacher-2023-11-27](https://www.reuters.com/world/europe/six-teenagers-court-over-beheading-french-teacher-2023-11-27)
 - RSS feed: https://www.reuters.com/world/
 - date published: 2023-11-27T01:53:59.199769+00:00

Six teenagers in court over beheading of French teacher

## Australia PM fires a top bureaucrat over influence probe
 - [https://www.reuters.com/world/asia-pacific/australia-pm-fires-top-bureaucrat-over-influence-probe-2023-11-27](https://www.reuters.com/world/asia-pacific/australia-pm-fires-top-bureaucrat-over-influence-probe-2023-11-27)
 - RSS feed: https://www.reuters.com/world/
 - date published: 2023-11-27T01:34:08.320858+00:00

Australia PM fires a top bureaucrat over influence probe

