# Source:Wirtualne Media, URL:https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml, language:pl-PL

## Amaterasu – niezwykła cząstka z kosmosu
 - [https://www.wirtualnemedia.pl/artykul/co-to-jest-amaterasu-niezwykla-czastka-kosmos](https://www.wirtualnemedia.pl/artykul/co-to-jest-amaterasu-niezwykla-czastka-kosmos)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-11-27T07:15:32.463192+00:00

Japońscy naukowcy w kosmicznym promieniowaniu odkryli nieznaną dotąd cząstkę o wyjątkowo wysokiej energii. Nazwali ją imieniem bogini Słońca, która miała pomóc w utworzeniu Japonii.

## Polski producent oprogramowania zmienia właściciela. MCI wyłożył ponad 163 mln zł
 - [https://www.wirtualnemedia.pl/artykul/mci-capital-tomasz-czechowicz-inwestycja-webcon](https://www.wirtualnemedia.pl/artykul/mci-capital-tomasz-czechowicz-inwestycja-webcon)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-11-27T07:15:32.461644+00:00

Fundusz inwestycyjny MCI Capital za 163,27 mln zł przejął 65,05 proc. spółki Webcon oferujące oprogramowanie biznesowe.

## Kłódka na pasku adresu strony internetowej to mit dający nam złudne poczucie bezpieczeństwa
 - [https://www.wirtualnemedia.pl/artykul/klodka-pasek-adres-strona-internetowa-co-daje-na-co-uwazac](https://www.wirtualnemedia.pl/artykul/klodka-pasek-adres-strona-internetowa-co-daje-na-co-uwazac)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-11-27T06:10:50.101301+00:00

Kłódka na pasku adresu strony internetowej to mit dający nam złudne poczucie bezpieczeństwa - powiedziała PAP Iwona Prószyńska z CERT Polska NASK. Dodała, że większość stron phishingowych ma w adresie kłódkę, a kluczem do bezpieczeństwa jest sprawdzanie możliwych różnic w adresie strony.

## TVP kupiła produkcje TV Republika za milion zł. Bez negocjacji i przestrzegania procedur
 - [https://www.wirtualnemedia.pl/artykul/tvp-kupila-tv-republika-miliony-zl-brak-przestrzegania-procedur](https://www.wirtualnemedia.pl/artykul/tvp-kupila-tv-republika-miliony-zl-brak-przestrzegania-procedur)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-11-27T05:05:30.928658+00:00

W ub.r. szefostwo TVP World kupiło za 1,04 mln zł prawa do emisji dwóch anglojęzycznych programów Telewizji Republika. Według Najwyższej Izby Kontroli naruszono przy tym wewnętrzne procedury. Były dyrektor TVP World stwierdził, że nie pamięta dokładnie okoliczności zawarcia umów, jego następca - że był wówczas świeżo po objęciu tego stanowiska, a prezes TVP tłumaczy, że błędnie odczytano zapisy regulaminu organizacyjnego stacji.

