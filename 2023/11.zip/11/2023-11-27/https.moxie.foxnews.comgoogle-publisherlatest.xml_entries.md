# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## Liberal reporter pushes Biden to meet with Stevie Wonder on racial issues: 'He's very concerned'
 - [https://www.foxnews.com/media/liberal-reporter-pushes-biden-meet-stevie-wonder-racial-issues-concerned](https://www.foxnews.com/media/liberal-reporter-pushes-biden-meet-stevie-wonder-racial-issues-concerned)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T23:10:56+00:00

TheGrio reporter April Ryan asked Karine Jean-Pierre whether President Biden would be interested in speaking with Stevie Wonder to discuss racial issues.

## Melania Trump expected to attend Rosalynn Carter tribute service, former President Trump not on guest list
 - [https://www.foxnews.com/politics/melania-trump-expected-attend-rosalynn-carter-tribute-service-former-president-trump-guest-list](https://www.foxnews.com/politics/melania-trump-expected-attend-rosalynn-carter-tribute-service-former-president-trump-guest-list)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T23:10:32+00:00

Former Fist Lady Melania Trump will attend a tribute service for Rosalynn Carter, also a former fist lady who passed away last week at age 96.

## Jennifer Lawrence hits back at plastic surgery rumors, says new look is due to makeup and aging
 - [https://www.foxnews.com/entertainment/jennifer-lawrence-hits-back-plastic-surgery-rumors-says-new-look-due-to-makeup-aging](https://www.foxnews.com/entertainment/jennifer-lawrence-hits-back-plastic-surgery-rumors-says-new-look-due-to-makeup-aging)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T23:07:22+00:00

Jennifer Lawrence told Kylie Jenner in a new interview that &quot;everyone&apos;s&quot; convinced that she&apos;s had &quot;eye surgery,&quot; but credits her make-up artist for the new look.

## Irish police investigating former UFC fighter Conor McGregor’s tweets about Dublin riots: report
 - [https://www.foxnews.com/sports/irish-police-investigating-former-ufc-fighter-conor-mcgregors-tweets-about-dublin-riots-report](https://www.foxnews.com/sports/irish-police-investigating-former-ufc-fighter-conor-mcgregors-tweets-about-dublin-riots-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T23:05:40+00:00

A series of tweets by former UFC fighter Conor McGregor addressing last weeks riots in Dublin is reportedly part of an investigation by Irish police.

## New Pop-Tarts Bowl reveals delicious surprise for winning college football team
 - [https://www.foxnews.com/sports/new-pop-tarts-bowl-reveals-delicious-surprise-winning-college-football-team](https://www.foxnews.com/sports/new-pop-tarts-bowl-reveals-delicious-surprise-winning-college-football-team)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T23:02:57+00:00

The first-ever Pop-Tarts Bowl for college football will not only feature a giant Pop-Tart mascot that will interact with fans throughout the game, it&apos;s also edible.

## Chiefs' Justyn Ross has criminal charges dropped after case approved for diversion
 - [https://www.foxnews.com/sports/chiefs-justyn-ross-criminal-charges-dropped-case-approved-for-diversion](https://www.foxnews.com/sports/chiefs-justyn-ross-criminal-charges-dropped-case-approved-for-diversion)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T22:50:57+00:00

Kansas City Chiefs wide receiver Justyn Ross&apos; domestic battery and criminal damage case stemming from an Oct. 23 arrest was dropped after being approved for diversion.

## As Mexico marks conservation day, advocates say it takes too long to list vulnerable species
 - [https://www.foxnews.com/world/mexico-marks-conservation-day-advocates-takes-list-vulnerable-species](https://www.foxnews.com/world/mexico-marks-conservation-day-advocates-takes-list-vulnerable-species)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T22:46:44+00:00

Mexican conservationists alleged that the government is neglecting its responsibilities to protect the nation&apos;s endangered species.

## Florida pest control worker arrested for 'disgusting' act toward women, including 76-year-old: authorities
 - [https://www.foxnews.com/us/florida-pest-control-worker-arrested-disgusting-act-toward-women-including-authorities](https://www.foxnews.com/us/florida-pest-control-worker-arrested-disgusting-act-toward-women-including-authorities)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T22:34:31+00:00

A Florida man working as a pest control and lawn care employee was arrested this week after allegedly exposing himself to two women, including a 76-year-old.

## Video shows train in Mexico filled with migrants riding on top as it heads to US southern border
 - [https://www.foxnews.com/us/video-shows-train-mexico-filled-migrants-riding-top-heads-us-southern-border](https://www.foxnews.com/us/video-shows-train-mexico-filled-migrants-riding-top-heads-us-southern-border)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T22:17:31+00:00

A train headed toward a town near the U.S. border was seen carrying what appeared to be hundreds of migrants riding on top in Mexico on Monday.

## Maine caretaker charged with killing partner, grandmother
 - [https://www.foxnews.com/us/maine-caretaker-charged-killing-partner-grandmother](https://www.foxnews.com/us/maine-caretaker-charged-killing-partner-grandmother)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T22:14:17+00:00

Tzara Jones, 53, of Denmark, Maine, has been charged with the killings of her romantic partner, Michael Willett, and her grandmother, Aremean Mayo.

## Pro-Palestinian protesters block Manhattan bridge, backing up traffic, demanding ceasefire in Gaza
 - [https://www.foxnews.com/us/pro-palestinian-protesters-block-manhattan-bridge-traffic-demanding-ceasefire-gaza](https://www.foxnews.com/us/pro-palestinian-protesters-block-manhattan-bridge-traffic-demanding-ceasefire-gaza)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T22:13:57+00:00

Hundreds of Pro-Palestinian protesters demanding a permanent cease-fire in Gaza shut down the Manhattan Bridge in both directions on Sunday.

## WWII gunner identified nearly 80 years after being shot down in France
 - [https://www.foxnews.com/us/wwii-gunner-identified-80-years-shot-down-france](https://www.foxnews.com/us/wwii-gunner-identified-80-years-shot-down-france)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T22:12:24+00:00

A U.S. Army Air Force gunner shot down over France in early 1944 has been identified as Franklin P. Hall of the 66th Bombardment Squadron.

## New Mexico Supreme Court upholds Democrat-drawn congressional map
 - [https://www.foxnews.com/politics/new-mexico-supreme-court-upholds-democrat-drawn-congressional-map](https://www.foxnews.com/politics/new-mexico-supreme-court-upholds-democrat-drawn-congressional-map)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T22:11:05+00:00

New Mexico&apos;s Supreme Court ruled Monday that the state&apos;s congressional map does not constitute an unreasonable gerrymander, upholding it.

## Lula names own justice minister to high court bench
 - [https://www.foxnews.com/world/lula-names-own-justice-minister-high-court-bench](https://www.foxnews.com/world/lula-names-own-justice-minister-high-court-bench)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T22:09:25+00:00

Brazilian President Luiz Inácio Lula da Silva, a socialist, has appointed Justice Minister Flávio Dino to fill a vacancy on the country&apos;s 11-judge Supreme Federal Court.

## Bills' Jordan Phillips, Shaq Lawson say Eagles fan made 'life threatening remarks' before sideline incident
 - [https://www.foxnews.com/sports/bills-jordan-phillips-shaq-lawson-eagles-fan-made-life-threatening-remarks-sideline-incident](https://www.foxnews.com/sports/bills-jordan-phillips-shaq-lawson-eagles-fan-made-life-threatening-remarks-sideline-incident)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T22:00:27+00:00

Buffalo Bills linemen Jordan Phillips and Shaq Lawson responded to confronting a Philadelphia Eagles fan on the sideline during their game on Sunday.

## Will online gambling spread beyond these six states, or is it just a fad?
 - [https://www.foxnews.com/lifestyle/online-gambling-spread-beyond-six-states-fad](https://www.foxnews.com/lifestyle/online-gambling-spread-beyond-six-states-fad)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T21:58:41+00:00

There are currently six US states in which internet casino gambling is legal. It is a debated question as to whether or not gambling will spread to other states.

## Diplomatic spat over the Parthenon Marbles scuttles meeting of British and Greek leaders
 - [https://www.foxnews.com/world/diplomatic-spat-parthenon-marbles-scuttles-meeting-british-greek-leaders](https://www.foxnews.com/world/diplomatic-spat-parthenon-marbles-scuttles-meeting-british-greek-leaders)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T21:44:52+00:00

For decades Greece has called for the return of the Parthenon Marbles from the British Museum, a collection of ancient sculptures.

## Soros pushed $15M to nonprofit linked to Biden super PAC to test 'critical' policy issues, tax docs reveal
 - [https://www.foxnews.com/politics/soros-pushed-15m-nonprofit-tied-biden-super-pac-test-critical-policy-issues-tax-docs-reveal](https://www.foxnews.com/politics/soros-pushed-15m-nonprofit-tied-biden-super-pac-test-critical-policy-issues-tax-docs-reveal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T21:43:06+00:00

A nonprofit linked to Biden&apos;s primary super PAC received tens of millions of dollars from a George Soros-funded group for research and to test &quot;critical&quot; policy issues, tax forms show.

## Prehistoric women believed to be hunters, not just gatherers, in new study of hormones and genetics
 - [https://www.foxnews.com/lifestyle/prehistoric-women-believed-hunters-gatherers-new-study-hormones-genetics](https://www.foxnews.com/lifestyle/prehistoric-women-believed-hunters-gatherers-new-study-hormones-genetics)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T21:39:15+00:00

Newly published research suggests females were doing more than just cooking and taking care of babies in prehistoric times. Women are believed to have been hunters as well.

## Man charged with NH school shooting threat changes plea
 - [https://www.foxnews.com/us/man-charged-nh-school-shooting-threat-changes-plea](https://www.foxnews.com/us/man-charged-nh-school-shooting-threat-changes-plea)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T21:22:10+00:00

Maine resident Kyle Hendrickson has pleaded guilty to charges alleging he threatened to &quot;shoot up&quot; Portsmouth High School in New Hampshire.

## US suspends, reduces vehicle processing along southern border at select Texas and Arizona ports of entry
 - [https://www.foxnews.com/us/us-suspends-reduces-vehicle-processing-southern-border-select-texas-arizona-ports-entry](https://www.foxnews.com/us/us-suspends-reduces-vehicle-processing-southern-border-select-texas-arizona-ports-entry)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T21:20:21+00:00

U.S. CBP suspended vehicle processing at one port of entry in Texas while reducing processing at an entry point in Arizona in response to a surge in migrant encounters.

## Former President Jimmy Carter will attend Rosalynn Carter tribute service in Georgia
 - [https://www.foxnews.com/politics/former-president-jimmy-carter-will-attend-rosalynn-carter-tribute-service-georgia](https://www.foxnews.com/politics/former-president-jimmy-carter-will-attend-rosalynn-carter-tribute-service-georgia)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T21:17:20+00:00

Former President Jimmy Carter will attend a tribute service in Georgia for his late wife, former First Lady Rosalynn Carter, the Carter Center said.

## At least 76 dead, thousands marooned as floods sweep Kenya
 - [https://www.foxnews.com/world/76-dead-thousands-marooned-floods-sweep-kenya](https://www.foxnews.com/world/76-dead-thousands-marooned-floods-sweep-kenya)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T21:08:27+00:00

Government officials in Kenya are urging residents of flood-prone areas to seek higher ground as heavy rains and flash flooding kill dozens across the East African nation.

## Israel-Hamas war: Identities of 11 recently-released Israeli hostages revealed
 - [https://www.foxnews.com/world/israel-hamas-war-identities-11-recently-released-israeli-hostages-revealed](https://www.foxnews.com/world/israel-hamas-war-identities-11-recently-released-israeli-hostages-revealed)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T20:53:42+00:00

As the truce between Israel and Hamas entered its fourth day on Monday, an additional 11 Israeli hostages released by Hamas have now been identified.

## Prison system tied up in guard sex scandal hit with sickening new claims
 - [https://www.foxnews.com/us/prison-system-tied-guard-sex-scandal-hit-sickening-new-claims](https://www.foxnews.com/us/prison-system-tied-guard-sex-scandal-hit-sickening-new-claims)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T20:47:54+00:00

Seven employees of the South Carolina Department of Corrections were indicted this month for allegedly smuggling contraband into prisons, most notably cellphones.

## Sunny Hostin takes shot at 'The View' for only showing 'reunification of Jewish families, not Palestinian ones
 - [https://www.foxnews.com/media/sunny-hostin-takes-shot-show-only-showing-reunification-jewish-families](https://www.foxnews.com/media/sunny-hostin-takes-shot-show-only-showing-reunification-jewish-families)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T20:38:34+00:00

&quot;The View&quot; co-host Sunny Hostin took exception to the show on Monday only showing reunification of hostages taken by Hamas with their families.

## Opposition candidate claims Madagascar election invalid, sues to overturn results
 - [https://www.foxnews.com/world/opposition-candidate-claims-madagascar-election-invalid-sues-overturn-results](https://www.foxnews.com/world/opposition-candidate-claims-madagascar-election-invalid-sues-overturn-results)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T20:26:20+00:00

Madagascar&apos;s main opposition candidate in this year&apos;s presidential race, Siteny Randrianasoloniaiko, has sued over incumbent Andry Rajoelina&apos;s controversial victory.

## WATCH: Jean-Pierre gives terse response when questioned on possible staff shakeup amid Biden polling crisis
 - [https://www.foxnews.com/politics/karine-jean-pierre-terse-response-questioned-possible-staff-shakeup-biden-polling-crisis](https://www.foxnews.com/politics/karine-jean-pierre-terse-response-questioned-possible-staff-shakeup-biden-polling-crisis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T20:22:40+00:00

The White House issued a terse response to a question about whether there would be a staffing shakeup or strategy changes due to President Biden&apos;s bad poll numbers.

## Attempted Maryland carjacking goes wrong when suspects realize they couldn't drive a stick shift
 - [https://www.foxnews.com/us/attempted-maryland-carjacking-wrong-suspects-realize-couldnt-drive-stick-shift](https://www.foxnews.com/us/attempted-maryland-carjacking-wrong-suspects-realize-couldnt-drive-stick-shift)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T20:13:19+00:00

A Maryland man was beaten by a group of carjackers who chose not to steal his SUV because they didn&apos;t know how to drive a manual transmission.

## Homemade license plate on stolen car leads to California woman's arrest
 - [https://www.foxnews.com/us/homemade-license-plate-stolen-car-leads-california-womans-arrest](https://www.foxnews.com/us/homemade-license-plate-stolen-car-leads-california-womans-arrest)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T20:08:58+00:00

A California woman was arrested after she was caught with a handwritten, fake license plate on the back of a suspected stolen car.

## New book on royal family hit for being 'sympathetic' to Harry and Meghan: 'Press release cooked up by ChatGPT'
 - [https://www.foxnews.com/media/new-book-royal-family-hit-being-sympathetic-harry-meghan-press-release-cooked-up-by-chatgpt](https://www.foxnews.com/media/new-book-royal-family-hit-being-sympathetic-harry-meghan-press-release-cooked-up-by-chatgpt)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T20:00:33+00:00

A new book focused on the royal family after Queen Eilzabeth&apos;s death was criticized for being &quot;unfailingly sympathetic&quot; towards Prince Harry and Meghan Markle.

## Puerto Rico's opposition to hold gubernatorial primary as race heats up
 - [https://www.foxnews.com/politics/puerto-ricos-opposition-hold-gubernatorial-primary-race](https://www.foxnews.com/politics/puerto-ricos-opposition-hold-gubernatorial-primary-race)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T19:59:10+00:00

Rep. Jesús Manuel Ortiz of Puerto-Rico&apos;s anti-statehood Popular Democratic Party has announced his bid for governor, triggering a primary election next year.

## Police in this blue state will continue enforcing ‘draconian’ handgun law ruled unconstitutional by court
 - [https://www.foxnews.com/politics/police-blue-state-continue-enforcing-draconian-handgun-law-ruled-unconstitutional-court](https://www.foxnews.com/politics/police-blue-state-continue-enforcing-draconian-handgun-law-ruled-unconstitutional-court)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T19:56:44+00:00

Maryland State Police are continuing to enforce a strict handgun licensing requirement until a federal court issues its mandate, which could take two more weeks.

## Six teens stand trial for allegedly inciting beheading of French teacher who showed Muslim cartoon
 - [https://www.foxnews.com/world/six-teens-stand-trial-allegedly-inciting-beheading-teacher-showed-muslim-cartoon](https://www.foxnews.com/world/six-teens-stand-trial-allegedly-inciting-beheading-teacher-showed-muslim-cartoon)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T19:42:43+00:00

Six teens accused of inciting the murder of teacher Samuel Paty by an Islamic extremist for showing cartoons of the Prophet Muhammad on trial in Paris.

## German priest freed by al-Qaeda-linked captors in Mali
 - [https://www.foxnews.com/world/german-priest-freed-al-qaeda-linked-captors-mali](https://www.foxnews.com/world/german-priest-freed-al-qaeda-linked-captors-mali)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T19:30:52+00:00

Rev. Hans-Joachim Lohre of Germany has reportedly been released by al-Qaeda affiliates who were holding him hostage in Bamako, Mali, for about a year.

## Natalie Portman doesn't think 'any children' should work in Hollywood, 'luck that I was not harmed'
 - [https://www.foxnews.com/entertainment/natalie-portman-doesnt-think-any-children-should-work-hollywood-luck-not-harmed](https://www.foxnews.com/entertainment/natalie-portman-doesnt-think-any-children-should-work-hollywood-luck-not-harmed)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T19:24:20+00:00

Natalie Portman doesn&apos;t think the Hollywood industry is safe for &quot;any children&quot; to work in. Portman shares two children with her husband Benjamin Millepied.

## White House says 3 Palestinian students shot in Vermont should be ‘back in school... not in a hospital room’
 - [https://www.foxnews.com/politics/white-house-reacts-3-palestinian-students-shot-burlington-vermont](https://www.foxnews.com/politics/white-house-reacts-3-palestinian-students-shot-burlington-vermont)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T19:18:27+00:00

White House press secretary Karine Jean-Pierre says President Biden was “horrified&quot; to learn about the shooting in Burlington, Vermont, over the weekend.

## Black Americans should be treated like 'swing voters' as Biden struggles, pollster says
 - [https://www.foxnews.com/media/black-americans-should-be-treated-swing-voters-biden-struggles-pollster-says](https://www.foxnews.com/media/black-americans-should-be-treated-swing-voters-biden-struggles-pollster-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T19:13:09+00:00

According to a Democratic pollster, Black voters should be treated like &quot;swing voters&quot; if Democrats are serious about helping President Biden win re-election in 2024.

## Pakistani army kills 8 militants in Afghan border raid
 - [https://www.foxnews.com/world/pakistani-army-kills-8-militants-afghan-border-raid](https://www.foxnews.com/world/pakistani-army-kills-8-militants-afghan-border-raid)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T19:09:02+00:00

Pakistan&apos;s army reportedly killed eight militants along the Afghan border Sunday in an intelligence-based operation likely targeting Taliban-allied forces.

## Georgia animal control issues urgent adoption deadline as overcrowding threatens euthanasia for two dozen dogs
 - [https://www.foxnews.com/us/georgia-animal-control-issues-urgent-adoption-deadline-overcrowding-threatens-euthanasia-two-dozen-dogs](https://www.foxnews.com/us/georgia-animal-control-issues-urgent-adoption-deadline-overcrowding-threatens-euthanasia-two-dozen-dogs)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T18:45:04+00:00

A Georgia animal control group has declared an urgent deadline, warning that overcrowding may lead to the euthanasia of two dozen dogs by November 30.

## Body found inside ventilation system of Michigan college arts center
 - [https://www.foxnews.com/us/body-found-ventilation-system-michigan-college-arts-center](https://www.foxnews.com/us/body-found-ventilation-system-michigan-college-arts-center)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T18:44:34+00:00

Michigan police are investigating the discovery of a body in the ventilation system of a college arts center in Detroit. The incident was reported at Macomb Community College.

## Giving Tuesday plays pivotal role in bridging funding gap after declining support, nonprofits say
 - [https://www.foxnews.com/us/giving-tuesday-plays-pivotal-role-bridging-funding-gap-declining-support-nonprofits-say](https://www.foxnews.com/us/giving-tuesday-plays-pivotal-role-bridging-funding-gap-declining-support-nonprofits-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T18:41:07+00:00

Donations to nonprofits are reportedly down compared with previous years, prompting many organizations to look to make up the difference on Giving Tuesday.

## AG Garland probing possible hate crime after shooting of 3 Palestinian men in Vermont
 - [https://www.foxnews.com/politics/ag-garland-probing-possible-hate-crime-shooting-3-palestinian-men-vermont](https://www.foxnews.com/politics/ag-garland-probing-possible-hate-crime-shooting-3-palestinian-men-vermont)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T18:39:32+00:00

Attorney General Merrick Garland said the Department of Justice will assist federal agencies in the investigation of possible hate crimes in the U.S.

## Michigan high school football player makes no-look interception in state title game
 - [https://www.foxnews.com/sports/michigan-high-school-football-player-makes-no-look-interception-state-title-game](https://www.foxnews.com/sports/michigan-high-school-football-player-makes-no-look-interception-state-title-game)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T18:38:49+00:00

Michigan high school football star Adrian Walker Jr. made one of the craziest plays in the state championship game on Sunday night.

## Wisconsin Gov. Evers faces scrutiny over use of baseball Hall of Famer's name in state email
 - [https://www.foxnews.com/politics/wisconsin-gov-evers-faces-scrutiny-use-baseball-hall-famers-name-state-email](https://www.foxnews.com/politics/wisconsin-gov-evers-faces-scrutiny-use-baseball-hall-famers-name-state-email)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T18:34:52+00:00

Wisconsin Gov. Tony Evers is under scrutiny for reportedly using the name of baseball Hall of Famer Warren Spahn in a state email account for security.

## Pennsylvania Republican Kat Copeland enters 2024 race for attorney general
 - [https://www.foxnews.com/politics/pennsylvania-republican-kat-copeland-enters-2024-race-attorney-general](https://www.foxnews.com/politics/pennsylvania-republican-kat-copeland-enters-2024-race-attorney-general)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T18:23:37+00:00

Republican Katayoun &quot;Kat&quot; Copeland has announced her candidacy for attorney general of Pennsylvania in the 2024 election. She has a background of three decades as a prosecutor.

## CNBC host clashes with Democratic congressman over Israel-Hamas war
 - [https://www.foxnews.com/media/cnbc-host-clashes-democratic-congressman-israel-hamas-war](https://www.foxnews.com/media/cnbc-host-clashes-democratic-congressman-israel-hamas-war)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T18:17:33+00:00

Rep. Ro Khanna, D-Calif., a supporter of a cease-fire in the Israel-Hamas war, clashed with CNBC host Joe Kernen over Israel&apos;s response to Hamas terrorist attacks.

## 3 hacks for finding the best deals on Travel Tuesday, according to a travel expert
 - [https://www.foxnews.com/lifestyle/3-hacks-how-find-best-deals-travel-tuesday-travel-expert](https://www.foxnews.com/lifestyle/3-hacks-how-find-best-deals-travel-tuesday-travel-expert)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T18:08:02+00:00

A travel expert shared her top tips for how to set yourself up for success this Travel Tuesday. Learn more about her three hacks that will help you save money.

## UK detects 1st human case of swine flu strain H1N2
 - [https://www.foxnews.com/world/uk-detects-first-human-case-swine-flu-strain-h1n2](https://www.foxnews.com/world/uk-detects-first-human-case-swine-flu-strain-h1n2)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T18:04:25+00:00

Health officials in the United Kingdom have confirmed the first case of Influenza A(H1N2)v in humans while undergoing “routine national flu surveillance.&quot;

## Hochul touts 'media literacy toolkit' for kids against 'misinformation' as hate crimes surge
 - [https://www.foxnews.com/media/hochul-touts-media-literacy-toolkit-kids-against-misinformation-hate-crimes-surge](https://www.foxnews.com/media/hochul-touts-media-literacy-toolkit-kids-against-misinformation-hate-crimes-surge)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T18:00:05+00:00

New York Gov. Kathy Hochul announced initiatives last week to help curb hateful rhetoric online as antisemitism and Islamophobia remain hot-button issues in the U.S.

## Kentucky train derailment caused by failed wheel bearing, company says
 - [https://www.foxnews.com/us/kentucky-train-derailment-caused-failed-wheel-bearing-company-says](https://www.foxnews.com/us/kentucky-train-derailment-caused-failed-wheel-bearing-company-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T17:47:30+00:00

CSX says a failed wheel bearing on a train car caused a derailment that sparked a chemical fire in a small Kentucky town. The accident occured on Nov. 22, 2023.

## UNC Chapel Hill accused shooter Tailei Qi found unfit for trial, referred to mental health facility
 - [https://www.foxnews.com/us/unc-chapel-hill-accused-shooter-tailei-qi-found-unfit-trial-referred-mental-health-facility](https://www.foxnews.com/us/unc-chapel-hill-accused-shooter-tailei-qi-found-unfit-trial-referred-mental-health-facility)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T17:47:03+00:00

UNC Ph.D. student Tailei Qi, accused of fatally shooting Prof. Zijie Yan, was deemed unfit to stand trial and will be committed to a psychiatric hospital.

## Deion Sanders' Colorado football program sees top recruit decommit amid disappointing 2023 season
 - [https://www.foxnews.com/sports/deion-sanders-colorado-football-program-sees-top-recruit-decommit-disappointing-2023-season](https://www.foxnews.com/sports/deion-sanders-colorado-football-program-sees-top-recruit-decommit-disappointing-2023-season)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T17:42:01+00:00

Georgia high school quarterback Antwann Hill Jr. decommitted from Colorado as the Buffaloes face another issue at the end of a disappointing season.

## Cashier's mistake leads to Illinois man winning $25,000 a year for life
 - [https://www.foxnews.com/us/cashiers-mistake-leads-illinois-man-winning-25000-year-life](https://www.foxnews.com/us/cashiers-mistake-leads-illinois-man-winning-25000-year-life)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T17:39:40+00:00

An Illinois man won $25,000 a year for life after purchasing a lottery ticket in Michigan even though the retailer accidentally printed the wrong ticket.

## Nicolas Cage decides to make less movies, focus on his daughter as he nears 60
 - [https://www.foxnews.com/entertainment/nicolas-cage-decides-make-less-movies-focus-daughter-nears-60](https://www.foxnews.com/entertainment/nicolas-cage-decides-make-less-movies-focus-daughter-nears-60)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T17:26:28+00:00

Nicolas Cage is focusing on &quot;what&apos;s important&quot; as he gets ready to celebrate his 60th birthday. The &quot;Dream Scenario&quot; star revealed how he wants to spend his time moving forward.

## Attorney General Garland expresses 'hope' Hamas will release more American hostages 'in the days to come'
 - [https://www.foxnews.com/politics/attorney-general-garland-expresses-hope-hamas-release-more-american-hostages-days-come](https://www.foxnews.com/politics/attorney-general-garland-expresses-hope-hamas-release-more-american-hostages-days-come)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T17:22:10+00:00

Attorney General Merrick Garland addressed the Americans taken hostage by Hamas in Gaza and how his office is hoping for more releases.

## Suspect accused of shooting 3 Palestinian students in Vermont enters plea in first court appearance
 - [https://www.foxnews.com/us/suspect-accused-shooting-3-palestinian-students-vermont-enters-plea-first-court-appearance](https://www.foxnews.com/us/suspect-accused-shooting-3-palestinian-students-vermont-enters-plea-first-court-appearance)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T17:20:55+00:00

Jason J. Eaton was arraigned Monday morning in connection with the shooting of three Palestinian college students in Burlington, Vermont.

## Disney admitted foray into politics, culture wars hurt its bottom line in SEC filing: Jonathan Turley
 - [https://www.foxnews.com/media/disney-admitted-foray-politics-culture-wars-hurt-bottom-line-sec-filing-jonathan-turley](https://www.foxnews.com/media/disney-admitted-foray-politics-culture-wars-hurt-bottom-line-sec-filing-jonathan-turley)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T17:19:47+00:00

The Walt Disney Co. &quot;appears to acknowledge&quot; that famed economist Adam Smith’s invisible hand is giving the House of Mouse the middle finger, Jonathan Turley says.

## Elizabeth Hurley, 58, shows off age-defying figure while swimming on vacation in Thailand
 - [https://www.foxnews.com/entertainment/elizabeth-hurley-58-shows-off-age-defying-figure-swimming-vacation-thailand](https://www.foxnews.com/entertainment/elizabeth-hurley-58-shows-off-age-defying-figure-swimming-vacation-thailand)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T17:13:55+00:00

Elizabeth Hurley, 58, showed off her enviable figure in a new video posted to Instagram. The British beauty swam around a pool in Thailand, where she just wrapped her spa vacation.

## Indiana couple and 2 dogs found dead in single-engine plane crash in western Michigan
 - [https://www.foxnews.com/us/indiana-couple-2-dogs-found-dead-single-engine-plane-crash-western-michigan](https://www.foxnews.com/us/indiana-couple-2-dogs-found-dead-single-engine-plane-crash-western-michigan)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T17:12:25+00:00

An Indiana couple and two dogs died when their single-engine plane crashed in western Michigan on Sunday. Authorities did not immediately release the names of the victims.

## Massachusetts woman sets fire inside police station after getting courtesy ride after crash: cops
 - [https://www.foxnews.com/us/massachusetts-woman-torches-donation-box-after-free-ride-police-station-police](https://www.foxnews.com/us/massachusetts-woman-torches-donation-box-after-free-ride-police-station-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T17:12:18+00:00

Westborough, Massachusetts, police arrested a 22-year-old woman for allegedly &quot;intentionally&quot; setting fire to a donation box inside the police department lobby.

## The final countdown: Trump holds commanding lead over DeSantis, Haley, with 50 days until Iowa caucuses
 - [https://www.foxnews.com/politics/the-final-countdown-trump-holds-commanding-lead-over-desantis-haley-50-days-until-iowa-caucuses](https://www.foxnews.com/politics/the-final-countdown-trump-holds-commanding-lead-over-desantis-haley-50-days-until-iowa-caucuses)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T17:04:11+00:00

With 50 days to go until the Iowa caucuses lead off the Republican presidential nominating calendar, former President Trump remains the commanding front-runner over Florida Gov. Ron DeSantis and former South Carolina Gov. Nikki Haley.

## Palestinian diplomat pushes for Israel-Hamas cease-fire extension: ‘We have work so that this truce continues’
 - [https://www.foxnews.com/world/palestinian-diplomat-pushes-israel-hamas-cease-fire-extension-we-have-work-this-truce-continues](https://www.foxnews.com/world/palestinian-diplomat-pushes-israel-hamas-cease-fire-extension-we-have-work-this-truce-continues)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T16:53:22+00:00

Palestinian Foreign Affairs Minister Riad al-Malki is arguing Monday for an extension of the Israel-Hamas cease-fire, which is soon set to run out.

## Georgia land dispute: Residents challenge railroad expansion in fight for property rights
 - [https://www.foxnews.com/us/georgia-land-dispute-residents-challenge-railroad-expansion-fight-property-rights](https://www.foxnews.com/us/georgia-land-dispute-residents-challenge-railroad-expansion-fight-property-rights)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T16:47:00+00:00

A legal battle over land ownership is unfolding in Georgia as the Sandersville Railroad seeks to build a 4.5-mile rail line connecting to a rock quarry.

## Colorado babysitter accused of leaving 2-year-old fighting for life with brain bleed
 - [https://www.foxnews.com/us/colorado-babysitter-accused-leaving-2-year-old-fighting-life-brain-bleed](https://www.foxnews.com/us/colorado-babysitter-accused-leaving-2-year-old-fighting-life-brain-bleed)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T16:46:30+00:00

McKinley Slone Hernandez, 25, was arrested on felony child abuse charges on Thanksgiving after allegedly leaving a Colorado 2-year-old with a life-threatening brain bleed.

## Environmental protesters refuse to leave Pacific Ocean vessel until company agrees to withdrawal from mission
 - [https://www.foxnews.com/us/environmental-protesters-refuse-leave-pacific-ocean-vessel-company-agrees-withdrawal-mission](https://www.foxnews.com/us/environmental-protesters-refuse-leave-pacific-ocean-vessel-company-agrees-withdrawal-mission)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T16:46:10+00:00

Environmental protesters have boarded a deep-sea vessel to protest the activities conducted by The Metals Company, and the company accuses the activists of endangering the crew.

## Ozzy Osbourne reveals spinal tumor, gives Parkinson's disease update: 'At best, I've got 10 years left'
 - [https://www.foxnews.com/entertainment/ozzy-osbourne-spinal-tumor-parkinsons-disease-update](https://www.foxnews.com/entertainment/ozzy-osbourne-spinal-tumor-parkinsons-disease-update)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T16:26:29+00:00

Ozzy Osbourne spoke at length about his medical issues, including the recent removal of a tumor in his spine, in a new interview.

## Man captured after New Orleans tarmac hatch escape, dramatic runway struggle caught on video
 - [https://www.foxnews.com/us/man-captured-after-new-orleans-tarmac-hatch-escape-dramatic-runway-struggle-caught-video](https://www.foxnews.com/us/man-captured-after-new-orleans-tarmac-hatch-escape-dramatic-runway-struggle-caught-video)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T16:24:33+00:00

A Southwest Airlines passenger allegedly opened the over-wing emergency exit hatch Sunday evening, climbed out and struggled with airport workers near a utility vehicle.

## Texas mother seen on video fighting off pit bull that attacked toddler
 - [https://www.foxnews.com/us/texas-mother-seen-video-fighting-pit-bull-attacked-toddler](https://www.foxnews.com/us/texas-mother-seen-video-fighting-pit-bull-attacked-toddler)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T16:18:20+00:00

A 2-year-old boy in Texas and his mother are recovering following a pit bull attack in their front yard. The vicious incident was caught on doorbell camera.

## Rex Ryan fires shots at Bill Belichick amid Patriots' struggles: 'Your team stinks'
 - [https://www.foxnews.com/sports/rex-ryan-fires-shots-bill-belichick-patriots-struggles-team-stinks](https://www.foxnews.com/sports/rex-ryan-fires-shots-bill-belichick-patriots-struggles-team-stinks)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T16:15:15+00:00

Rex Ryan had terse criticism for New England Patriots head coach Bill Belichick on Monday as the team fell to 2-9 following a loss to the New York Giants.

## Immigrants to US rally over work permit disparities as advocates call for equality
 - [https://www.foxnews.com/us/us-immigrants-rally-work-permit-disparities-advocates-call-equality](https://www.foxnews.com/us/us-immigrants-rally-work-permit-disparities-advocates-call-equality)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T16:14:26+00:00

Tensions are rising among immigrants in the U.S. over disparities in work permits. Advocates are pushing for equal treatment, while local leaders focus on aiding new arrivals.

## Colorado paramedics face homicide charges in death of Elijah McClain
 - [https://www.foxnews.com/us/colorado-paramedics-face-homicide-charges-death-elijah-mcclain](https://www.foxnews.com/us/colorado-paramedics-face-homicide-charges-death-elijah-mcclain)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T16:13:15+00:00

Two Colorado paramedics are facing homicide and manslaughter charges in the 2019 death of Elijah McClain. McClain, a Black man, died after being stopped by police in Denver.

## Ireland anti-hate law pushed in wake of Dublin riots could criminalize memes, poses free speech concerns
 - [https://www.foxnews.com/world/ireland-anti-hate-law-pushed-wake-dublin-riots-could-criminalize-memes-poses-free-speech-concerns](https://www.foxnews.com/world/ireland-anti-hate-law-pushed-wake-dublin-riots-could-criminalize-memes-poses-free-speech-concerns)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T16:09:08+00:00

Ireland is pushing anti-hate legislation in the wake of Dublin riots raising new freedom of speech concerns regarding mass migration and other issues.

## Baton Rouge teenage murder suspect breaks out of jail in 2nd escape in 2 weeks
 - [https://www.foxnews.com/us/baton-rouge-teenage-murder-suspect-breaks-out-jail-second-escape-two-weeks](https://www.foxnews.com/us/baton-rouge-teenage-murder-suspect-breaks-out-jail-second-escape-two-weeks)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T16:03:58+00:00

Two teenage murder suspects allegedly broke out of a Baton Rouge jail over the weekend, which is the second time one of the suspects escaped this month.

## How to set up a separate Wi-Fi network for your guests
 - [https://www.foxnews.com/tech/how-set-up-separate-wi-fi-network-your-guests](https://www.foxnews.com/tech/how-set-up-separate-wi-fi-network-your-guests)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T16:00:20+00:00

Kurt “CyberGuy&quot; Knutsson discusses how a guest WiFi network is a way to let your visitors use the internet without compromising your main network’s security and privacy.

## New images of Avigail Idan show released 4-year-old US citizen smiling, reunited with family members
 - [https://www.foxnews.com/world/new-images-avigail-idan-show-released-4-year-old-us-citizen-smiling-reunited-family-members](https://www.foxnews.com/world/new-images-avigail-idan-show-released-4-year-old-us-citizen-smiling-reunited-family-members)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T15:47:27+00:00

U.S. citizen Avigail Idan, 4, was photographed after being released from Hamas captivity and reunited with family members in Israel on Sunday.

## Mass protests erupt across Italy after extradition of college student's suspected killer
 - [https://www.foxnews.com/world/mass-protests-erupt-italy-extradition-college-students-suspected-killer](https://www.foxnews.com/world/mass-protests-erupt-italy-extradition-college-students-suspected-killer)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T15:37:06+00:00

Mass protests swept across Italy following the extradition of a suspected killer who has been charged with the murder of a 22-year-old college student.

## Glam to grit: 'Get Ready with Me' video trend transitions from date night to job survival stories
 - [https://www.foxnews.com/entertainment/glam-grit-get-ready-me-video-trend-transitions-date-night-job-survival-stories](https://www.foxnews.com/entertainment/glam-grit-get-ready-me-video-trend-transitions-date-night-job-survival-stories)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T15:36:26+00:00

&apos;Get Ready with Me&apos; videos, a popular trend on platforms like TikTok, showcase individuals preparing for various activities. These videos have garnered billions of views.

## San Francisco's rampant drugs, homelessness shock new resident: 'This is a disgrace'
 - [https://www.foxnews.com/media/san-franciscos-rampant-drugs-homelessness-shock-new-resident-disgrace](https://www.foxnews.com/media/san-franciscos-rampant-drugs-homelessness-shock-new-resident-disgrace)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T15:23:56+00:00

A software engineer and new resident told &quot;FOX &amp; Friends First&quot; the city has already returned to a den of drugs and homelessness after the APEC summit.

## Panthers fire Frank Reich, a move that immediately goes down in NFL history
 - [https://www.foxnews.com/sports/panthers-fire-frank-reich-move-immediately-goes-down-nfl-history](https://www.foxnews.com/sports/panthers-fire-frank-reich-move-immediately-goes-down-nfl-history)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T15:22:13+00:00

The Carolina Panthers fired head coach Frank Reich after just 11 games. It&apos;s a move that will go down in NFL history as one of the quickest dismissal.

## Left-leaning think tank co-founder sounds alarm on 'No Labels' effort: Biden 'loses'
 - [https://www.foxnews.com/media/left-leaning-think-tank-co-founder-sounds-alarm-no-labels-effort-biden-loses](https://www.foxnews.com/media/left-leaning-think-tank-co-founder-sounds-alarm-no-labels-effort-biden-loses)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T15:05:39+00:00

Matt Bennet, co-founder of left-leaning think tank Third-Way, sounded the alarm on a possible third-party ticket and warned President Biden could lose in 2024.

## Panthers fire coach Frank Reich after 11 games
 - [https://www.foxnews.com/sports/panthers-fire-coach-frank-reich-11-games](https://www.foxnews.com/sports/panthers-fire-coach-frank-reich-11-games)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T14:54:34+00:00

The Carolina Panthers on Monday fired head coach Frank Reich following the team&apos;s loss to the Tennessee Titans. He was in the middle of his first season.

## Family of Taylor Swift fan who died at Rio concert meets pop star at final show in Brazil
 - [https://www.foxnews.com/entertainment/family-taylor-swift-fan-died-rio-concert-meets-pop-star-final-show-brazil](https://www.foxnews.com/entertainment/family-taylor-swift-fan-died-rio-concert-meets-pop-star-final-show-brazil)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T14:49:55+00:00

Taylor Swift welcomed the family of Ana Clara Benevides, the fan who passed away earlier this month at one of her Eras Tour concerts, to her show in São Paulo.

## Schumer to send Biden's $106 billion supplemental package request to Senate floor as early as next week
 - [https://www.foxnews.com/politics/schumer-send-bidens-106-billion-supplemental-package-request-senate-floor-early-next-week](https://www.foxnews.com/politics/schumer-send-bidens-106-billion-supplemental-package-request-senate-floor-early-next-week)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T14:48:41+00:00

Sen. Majority Leader Chuck Schumer, D-N.Y., plans to bring Biden&apos;s multibillion-dollar national security supplemental package for a Senate vote next week.

## Bills' Shaq Lawson pushes Eagles fan in heated confrontation
 - [https://www.foxnews.com/sports/bills-shaq-lawson-pushes-eagles-fan-heated-confrontation](https://www.foxnews.com/sports/bills-shaq-lawson-pushes-eagles-fan-heated-confrontation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T14:34:29+00:00

Buffalo Bills defensive end Shaq Lawson appeared to get physical with a Philadelphia Eagles fan on Sunday night during their overtime loss.

## Hamas terrorists use Israeli hostage release in game of psychological warfare
 - [https://www.foxnews.com/world/hamas-terrorists-use-israeli-hostage-release-game-psychological-warfare](https://www.foxnews.com/world/hamas-terrorists-use-israeli-hostage-release-game-psychological-warfare)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T14:28:28+00:00

Hamas terror group&apos;s slow release of Israeli hostages is seemingly designed to inflict the maximum amount of anxiety and terror on Israeli society and the families of hostages.

## 'Hunger Games' prequel and 'Napoleon' dominate Thanksgiving box office, topping Disney's 'Wish'
 - [https://www.foxnews.com/entertainment/hunger-games-prequel-napoleon-dominate-thanksgiving-box-office-topping-disneys-wish](https://www.foxnews.com/entertainment/hunger-games-prequel-napoleon-dominate-thanksgiving-box-office-topping-disneys-wish)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T14:26:35+00:00

&quot;The Hunger Games: The Ballad of Songbirds and Snakes&quot; continues to lead the Thanksgiving weekend box office, outperforming new releases like Disney&apos;s &quot;Wish.&quot;

## New York works to keep food waste out of landfills over environmental concerns
 - [https://www.foxnews.com/us/new-york-works-keep-food-waste-out-landfills-environmental-concerns](https://www.foxnews.com/us/new-york-works-keep-food-waste-out-landfills-environmental-concerns)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T14:25:54+00:00

New York is addressing food waste through statewide initiatives, emphasizing donations of edible food and recycling of food scraps to reduce landfill usage.

## Merriam-Webster chooses 'authentic' as the 2023 word of the year
 - [https://www.foxnews.com/lifestyle/merriam-webster-chooses-authentic-2023-word-year](https://www.foxnews.com/lifestyle/merriam-webster-chooses-authentic-2023-word-year)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T14:02:07+00:00

The Merriam-Webster word of the year for 2023 is &quot;authentic.&quot; This choice reflects a heightened interest in authenticity in the emerging age of artificial intelligence.

## Baby Sumatran rhino born in Asia brings hope for critically endangered species
 - [https://www.foxnews.com/world/baby-sumatran-rhino-born-asia-brings-hope-critically-endangered-species](https://www.foxnews.com/world/baby-sumatran-rhino-born-asia-brings-hope-critically-endangered-species)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T13:52:24+00:00

In a positive development for the critically endangered Sumatran rhino, a 25-kilogram male calf was born in Indonesia. Delilah, a seven-year-old female, gave birth to the calf.

## Florida police truck crashes into car on way to emergency, 5-year-old girl dies
 - [https://www.foxnews.com/us/florida-police-truck-crashes-car-way-emergency-5-year-old-girl-dies](https://www.foxnews.com/us/florida-police-truck-crashes-car-way-emergency-5-year-old-girl-dies)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T13:28:30+00:00

A 5-year-old girl&apos;s mother said she heard sirens from a police truck while stopped at a red light, but could not tell how far out the vehicle was.

## Jon Gruden named 'big wildcard' candidate for Indiana football job: report
 - [https://www.foxnews.com/sports/jon-gruden-named-big-wildcard-candidate-indiana-football-job-report](https://www.foxnews.com/sports/jon-gruden-named-big-wildcard-candidate-indiana-football-job-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T13:11:44+00:00

Jon Gruden was named as a potential &quot;wildcard&quot; candidate to take over the Indiana Hoosiers football job on Sunday. Gruden has not coached since the Las Vegas Raiders in 2021.

## Elizabeth Warren's 'epiphany' on Obamacare's unintended consequences is overdue: WSJ
 - [https://www.foxnews.com/media/elizabeth-warrens-epiphany-obamacares-unintended-consequences-overdue-wsj](https://www.foxnews.com/media/elizabeth-warrens-epiphany-obamacares-unintended-consequences-overdue-wsj)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T13:10:10+00:00

Sen. Elizabeth Warren, D-Mass., has finally admitted that &quot;ObamaCare has increased healthcare prices and industry consolidation,&quot; the Wall Street Journal wrote Friday.

## Biden-Xi summit: Showing weakness to this evil regime endangers Americans
 - [https://www.foxnews.com/opinion/biden-xi-summit-showing-weakness-evil-regime-endangers-americans](https://www.foxnews.com/opinion/biden-xi-summit-showing-weakness-evil-regime-endangers-americans)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T13:00:53+00:00

President Biden rolled out the red carpet for China&apos;s Xi Jinping, ready to make nice with the regime responsible for human rights violations and a global campaign to undermine democracy.

## Pennsylvania Democrat Jack Stollsteimer enters 2024 race for attorney general
 - [https://www.foxnews.com/politics/pennsylvania-democrat-jack-stollsteimer-enters-2024-race-attorney-general](https://www.foxnews.com/politics/pennsylvania-democrat-jack-stollsteimer-enters-2024-race-attorney-general)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T13:00:32+00:00

Jack Stollsteimer, the district attorney of Delaware County, has announced his candidacy for Pennsylvania attorney general in 2024. The Democrat is a former federal prosecutor.

## 5-year-old girl dies, search suspended for grandfather after wave sweeps them out to sea at California beach
 - [https://www.foxnews.com/us/5-year-old-girl-dies-search-suspended-grandfather-wave-sweeps-them-sea-california-beach](https://www.foxnews.com/us/5-year-old-girl-dies-search-suspended-grandfather-wave-sweeps-them-sea-california-beach)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T12:47:06+00:00

The U.S. Coast Guard has suspended a search for a 54-year-old man who was swept out to sea in Northern California and said his granddaughter had died.

## Pennsylvania man sentenced for fatal Christmas eve shooting of store owner over stolen necklace
 - [https://www.foxnews.com/us/pennsylvania-man-sentenced-fatal-christmas-eve-shooting-store-owner-stolen-necklace](https://www.foxnews.com/us/pennsylvania-man-sentenced-fatal-christmas-eve-shooting-store-owner-stolen-necklace)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T12:46:09+00:00

A Pennsylvania man has pleaded guilty to third-degree murder for the fatal Christmas Eve shooting of an 81-year-old store owner in south Philadelphia nearly seven years ago.

## Ohio mobile home fire kills 5, including 2 children, on Thanksgiving morning
 - [https://www.foxnews.com/us/ohio-mobile-home-fire-kills-5-2-children-thanksgiving-morning](https://www.foxnews.com/us/ohio-mobile-home-fire-kills-5-2-children-thanksgiving-morning)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T12:42:12+00:00

An Ohio mobile home fire claimed the lives of five people, including two children, on Thanksgiving. One occupant of the Athens County home survived and was hospitalized.

## Pope in 'good and stable' condition after lung inflammation diagnosis, Vatican says
 - [https://www.foxnews.com/world/pope-good-stable-condition-lung-inflammation-diagnosis-vatican-says](https://www.foxnews.com/world/pope-good-stable-condition-lung-inflammation-diagnosis-vatican-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T12:39:19+00:00

Pope Francis is in &apos;good, stable&apos; condition after he was taken to a Rome hospital, where he underwent a CT scan for possible pneumonia, the Vatican said.

## Draymond Green not losing sleep over choking Rudy Gobert: 'Don't live my life with regrets'
 - [https://www.foxnews.com/sports/draymond-green-not-losing-sleep-choking-rudy-gobert](https://www.foxnews.com/sports/draymond-green-not-losing-sleep-choking-rudy-gobert)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T12:37:00+00:00

Golden State Warriors forward Draymond Green revealed that he does not regret placing Minnesota Timberwolves center Rudy Gobert in a chokehold.

## Chiefs' Travis Kelce makes franchise history in win over Raiders
 - [https://www.foxnews.com/sports/chiefs-travis-kelce-makes-franchise-history-win-raiders](https://www.foxnews.com/sports/chiefs-travis-kelce-makes-franchise-history-win-raiders)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T12:30:14+00:00

Kansas City Chiefs star Travis Kelce hit a mark no other player in franchise history has hit as the team won the game 31-17 on Sunday evening.

## NY official demands resignation of college president who claimed 'complex history' after Hamas terror attack
 - [https://www.foxnews.com/politics/ny-official-demands-resignation-college-president-claimed-complex-history-hamas-terror-attack](https://www.foxnews.com/politics/ny-official-demands-resignation-college-president-claimed-complex-history-hamas-terror-attack)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T12:19:38+00:00

Nassau County Executive Bruce Blakeman called on Hofstra President Susan Poser to resign over a statement claiming &quot;complex history&quot; after Hamas&apos; attack.

## Maryland man killed after firing at officers, woman fatally shot
 - [https://www.foxnews.com/us/maryland-man-killed-firing-officers-woman-fatally-shot](https://www.foxnews.com/us/maryland-man-killed-firing-officers-woman-fatally-shot)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T12:01:50+00:00

A domestic disturbance in Maryland prompted a police response Friday, leading to a fatal shootout. As police approached, a man opened the door and began firing at them.

## Alaska landslide: Fourth victim identified as 11-year-old girl
 - [https://www.foxnews.com/us/alaska-landslide-fourth-victim-identified-11-year-old-girl](https://www.foxnews.com/us/alaska-landslide-fourth-victim-identified-11-year-old-girl)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T11:59:05+00:00

A southeast Alaska landslide resulted in the death of an 11-year-old girl, marking the fourth casualty from the incident. Her parents and sister were also confirmed dead.

## Harrowing details emerge from hostage families, ex-WH doc warns of Biden mental decline and more top headlines
 - [https://www.foxnews.com/us/captivity-details-from-hostage-families-ex-wh-doctor-warns-biden-cognitive-decline-more-top-headlines](https://www.foxnews.com/us/captivity-details-from-hostage-families-ex-wh-doctor-warns-biden-cognitive-decline-more-top-headlines)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T11:55:18+00:00

Get all the stories you need-to-know from the most powerful name in news delivered first thing every morning to your inbox.

## North Korea building border guard posts following spy satellite launch, South Korea says
 - [https://www.foxnews.com/world/north-korea-building-border-guard-posts-following-spy-satellite-launch-south-korea-says](https://www.foxnews.com/world/north-korea-building-border-guard-posts-following-spy-satellite-launch-south-korea-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T11:51:04+00:00

South Korea says North Korea is restoring guard posts along the border and is moving military assets around following the launch of a spy satellite.

## 10 ways to keep packages safe from being stolen this holiday season
 - [https://www.foxnews.com/tech/10-ways-to-keep-packages-safe-from-being-stolen-this-holiday-season](https://www.foxnews.com/tech/10-ways-to-keep-packages-safe-from-being-stolen-this-holiday-season)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T11:00:58+00:00

Kurt &quot;CyberGuy&quot; Knutsson talks about how to stop a porch pirate from stealing your packages. These 10 ways to keep deliveries from being stolen can keep you safe.

## Country music couples Tim McGraw, Faith Hill and Garth Brooks, Trisha Yearwood share tips to lasting marriages
 - [https://www.foxnews.com/entertainment/country-music-couples-tim-mcgraw-faith-hill-garth-brooks-trisha-yearwood-lasting-marriages](https://www.foxnews.com/entertainment/country-music-couples-tim-mcgraw-faith-hill-garth-brooks-trisha-yearwood-lasting-marriages)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T11:00:44+00:00

From Tim McGraw and Faith Hill to Garth Brooks and Trisha Yearwood, country music couples give insight into their successful and long-lasting marriages.

## Kim Kardashian's 'push up bra' with fake nipples built in sold out online: 'Get lots of attention'
 - [https://www.foxnews.com/media/kim-kardashians-push-up-bra-fake-nipples-built-sold-out-online-get-lots-attention](https://www.foxnews.com/media/kim-kardashians-push-up-bra-fake-nipples-built-sold-out-online-get-lots-attention)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T11:00:14+00:00

Kim Kardashian&apos;s Skims collection debuted the &apos;Ultimate Nipple Bra&apos; to create an eye-popping look and was shortly sold-out online.

## For cold and flu treatments, do you need a prescription or are over-the-counter meds good enough?
 - [https://www.foxnews.com/health/cold-flu-treatments-do-you-need-prescription-is-over-counter-good-enough](https://www.foxnews.com/health/cold-flu-treatments-do-you-need-prescription-is-over-counter-good-enough)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T10:51:42+00:00

There are many options to alleviate cold and flu symptoms, including over-the-counter (OTC) and prescription medications — and it’s important to know the difference.

## Democratic mayor responds after 2 shot following Christmas tree lighting ceremony: 'Enough is enough'
 - [https://www.foxnews.com/us/democratic-mayor-responds-shot-following-christmas-tree-lighting-ceremony-enough-is-enough](https://www.foxnews.com/us/democratic-mayor-responds-shot-following-christmas-tree-lighting-ceremony-enough-is-enough)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T10:47:26+00:00

After a shooting following a Christmas tree lighting ceremony left two people wounded, the city&apos;s mayor condemned the &apos;senseless violence&apos; and said residents deserve to feel safe.

## Bradley Cooper supports Brad Pitt, Brooke Shields as real-life Hollywood hero
 - [https://www.foxnews.com/entertainment/bradley-cooper-supports-brad-pitt-brooke-shields-real-life-hollywood-hero](https://www.foxnews.com/entertainment/bradley-cooper-supports-brad-pitt-brooke-shields-real-life-hollywood-hero)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T10:30:44+00:00

Bradley Cooper has inspired Hollywood stars to get sober, including Brad Pitt and Ben Affleck, and once helped Brooke Shields through a grand mal seizure.

## Suspect arrested in shooting of 3 Palestinian US students near University of Vermont
 - [https://www.foxnews.com/us/suspect-arrested-shooting-3-palestinian-us-students-near-university-vermont](https://www.foxnews.com/us/suspect-arrested-shooting-3-palestinian-us-students-near-university-vermont)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T10:11:27+00:00

Police arrested a suspect Sunday evening following the shooting of three U.S. college students of Palestinian descent in Burlington, Vermont.

## Progressive mayors demand $1.5 billion for drug crisis they created
 - [https://www.foxnews.com/opinion/progressive-mayors-demand-billion-drug-crisis-they-created](https://www.foxnews.com/opinion/progressive-mayors-demand-billion-drug-crisis-they-created)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T10:00:52+00:00

Mayors of America’s biggest Democrat-controlled cities are among those jonesing for tax dollars to tackle a drug crisis they helped to create.

## Marine veteran breaks down 'tragic' data showing increasing rate of veteran suicide
 - [https://www.foxnews.com/media/marine-veteran-breaks-down-tragic-trend-increasing-rate-veteran-suicide](https://www.foxnews.com/media/marine-veteran-breaks-down-tragic-trend-increasing-rate-veteran-suicide)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T10:00:51+00:00

U.S. Marine Corps veteran, Cole Lyle, points to COVID and the Afghanistan withdrawal as reason for the spike in veteran suicide.

## Biden's mishandling of documents, his family's business schemes threaten our national security
 - [https://www.foxnews.com/opinion/bidens-mishandling-documents-familys-business-schemes-threaten-national-security](https://www.foxnews.com/opinion/bidens-mishandling-documents-familys-business-schemes-threaten-national-security)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T10:00:44+00:00

The House Committee on Oversight and Accountability’s inquiry into Joe Biden&apos;s mishandling of classified documents is accelerating. This investigation is anything but closed.

## Paul Walker remembered 10 years after his death by daughter and friends: 'I love you and miss you every day'
 - [https://www.foxnews.com/entertainment/paul-walker-remembered-10-years-after-death-daughter-friends-i-love-you-miss-you-every-day](https://www.foxnews.com/entertainment/paul-walker-remembered-10-years-after-death-daughter-friends-i-love-you-miss-you-every-day)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T10:00:32+00:00

&quot;Fast and the Furious&quot; star Paul Walker died 10 years ago, and has been honored by his friends and family, including daughter Meadow and co-star Vin Diesel, throughout the years.

## Biden’s ‘abolish ICE’ agenda puts American lives at risk
 - [https://www.foxnews.com/opinion/bidens-abolish-ice-agenda-puts-american-lives-risk](https://www.foxnews.com/opinion/bidens-abolish-ice-agenda-puts-american-lives-risk)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T10:00:12+00:00

The continued dismantlement of immigration enforcement means a nonstop flow of illegal aliens at the border that we can’t possibly vet. It’s putting American lives in danger.

## Comedian Bill Engvall left California for Utah after successful career: 'Felt more at home'
 - [https://www.foxnews.com/entertainment/bill-engvall-left-california-utah-successful-career-felt-like-home](https://www.foxnews.com/entertainment/bill-engvall-left-california-utah-successful-career-felt-like-home)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T09:30:57+00:00

Bill Engvall left California after he felt like he&apos;d accomplished what he wanted with his career, but also when taxes started to rise. The comedian says he now feels &quot;more at home&quot; in Utah.

## When measuring heart attack risk, one important red flag is often overlooked, doctors say
 - [https://www.foxnews.com/health/measuring-heart-attack-risk-one-important-red-flag-often-overlooked-doctors-say](https://www.foxnews.com/health/measuring-heart-attack-risk-one-important-red-flag-often-overlooked-doctors-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T09:15:42+00:00

Dr. Seth Baum, a cardiologist and chief scientific officer at Flourish Reseach in Florida, told Fox News Digital about the importance of an often overlooked risk factor for heart disease.

## Mark Wahlberg is prioritizing 'recovery' instead of 'intense workouts' as he gets older
 - [https://www.foxnews.com/entertainment/mark-wahlberg-prioritizing-recovery-instead-intense-workouts-gets-older](https://www.foxnews.com/entertainment/mark-wahlberg-prioritizing-recovery-instead-intense-workouts-gets-older)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T09:00:53+00:00

Mark Wahlberg told Fox News Digital he&apos;s prioritizing his recovery and slowing down on his intense workout routine. Now, Wahlberg is practicing cold plunges and resting two days a week.

## NYC councilwoman blasts failure of ‘modern progressivism’ after anti-Israel high school riot
 - [https://www.foxnews.com/us/nyc-councilwoman-blasts-failure-modern-progressivism-anti-israel-high-school-riot](https://www.foxnews.com/us/nyc-councilwoman-blasts-failure-modern-progressivism-anti-israel-high-school-riot)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T09:00:46+00:00

New York City Councilwoman Vicki Paladino demanded action against high school students and teachers who took part in a riot against a pro-Israel teacher at Hillcrest High.

## Biden gives interview to radio show that promoted notorious antisemite who compared Jews to 'termites'
 - [https://www.foxnews.com/politics/biden-gives-interview-show-promoted-antisemite-compared-jews-termites](https://www.foxnews.com/politics/biden-gives-interview-show-promoted-antisemite-compared-jews-termites)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T09:00:40+00:00

A radio host who wished Minister Louis Farrakhan a happy birthday in May recently sat down for an interview with President Joe Biden, according to the White House.

## Pentagon official overseeing federal schools arrested in Georgia human-trafficking sting
 - [https://www.foxnews.com/us/pentagon-official-overseeing-federal-schools-arrested-georgia-human-trafficking-sting](https://www.foxnews.com/us/pentagon-official-overseeing-federal-schools-arrested-georgia-human-trafficking-sting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T09:00:09+00:00

Former Department of Defense Education Activity (DoDEA) chief of staff Stephen Hovanic was arrested earlier this month in connection with a Georgia human-trafficking sting.

## 10 natural treatments that doctors recommend for the cold and flu
 - [https://www.foxnews.com/health/10-natural-treatments-doctors-recommend-cold-flu](https://www.foxnews.com/health/10-natural-treatments-doctors-recommend-cold-flu)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T09:00:06+00:00

Fox News Digital spoke to several doctors to see what they advise people to do when they come down with cold or flu symptoms. Here are 10 tips to consider.

## Experts weigh in on whether DeSantis' Iowa strategy will be enough to topple Trump: 'Hail Mary'
 - [https://www.foxnews.com/politics/experts-weigh-in-on-whether-desantis-iowa-strategy-will-be-enough-to-topple-trump-hail-mary](https://www.foxnews.com/politics/experts-weigh-in-on-whether-desantis-iowa-strategy-will-be-enough-to-topple-trump-hail-mary)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T09:00:05+00:00

The presidential campaign of Florida Gov. Ron DeSantis will likely come down to the success or failure of a &quot;Hail Mary&quot; strategy in Iowa, experts told Fox News Digital.

## Satanic 'Hail Santa' Christmas tree faces blowback for display at Wisconsin museum
 - [https://www.foxnews.com/media/satanic-hail-santa-christmas-tree-faces-blowback-display-wisconsin-museum](https://www.foxnews.com/media/satanic-hail-santa-christmas-tree-faces-blowback-display-wisconsin-museum)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T09:00:02+00:00

The Satanic Temple tree at a Wisconsin museum faced pushback from a Republican congressman who called it &apos;cultural propaganda&apos;

## Surge of random violence 'is never random,' says expert on how to protect yourself
 - [https://www.foxnews.com/us/surge-random-violence-never-random-says-expert-protect-yourself](https://www.foxnews.com/us/surge-random-violence-never-random-says-expert-protect-yourself)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T09:00:02+00:00

A protection specialist and retired U.S. Marine said most violent crimes have an element of predictability that can save you from being victimized.

## Traffic stop leads to arrest in years-old unsolved murder of woman, unborn child
 - [https://www.foxnews.com/us/traffic-stop-leads-arrest-years-old-unsolved-murder-woman-unborn-child](https://www.foxnews.com/us/traffic-stop-leads-arrest-years-old-unsolved-murder-woman-unborn-child)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T09:00:01+00:00

Jose Eduardo Dominguez-Garcia, 26, was apprehended in Missouri after three years on the run in the death of his girlfriend Rosaly &quot;Cindy&quot; Chavarria Rodriguez, 25, and her unborn child.

## Kyle Rittenhouse writes book to correct misleading 'narrative': 'Tell my story'
 - [https://www.foxnews.com/us/kyle-rittenhouse-writes-book-correct-misleading-narrative-tell-my-story](https://www.foxnews.com/us/kyle-rittenhouse-writes-book-correct-misleading-narrative-tell-my-story)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T09:00:00+00:00

Kyle Rittenhouse says he wanted to write a book to tell his side of his story two years after a jury acquitted him of charges related to the BLM Kenosha riot.

## Portland Public Schools reach tentative deal with teachers union, classes resume Monday with 2-hour delay
 - [https://www.foxnews.com/us/portland-public-schools-reach-tentative-deal-teachers-union-classes-resume-monday-2-hour-delay](https://www.foxnews.com/us/portland-public-schools-reach-tentative-deal-teachers-union-classes-resume-monday-2-hour-delay)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T08:17:35+00:00

Portland Public Schools said it had reached a tentative agreement with its teachers union after more than three weeks out of school, and classes will resume on Monday.

## This US bomber is why China suddenly wants to talk about nukes and AI
 - [https://www.foxnews.com/opinion/us-bomber-why-china-suddenly-wants-talk-about-nukes-ai](https://www.foxnews.com/opinion/us-bomber-why-china-suddenly-wants-talk-about-nukes-ai)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T07:00:24+00:00

It’s the only U.S. Air Force combat plane with the range and stealth to chase China’s mobile missiles and carry the deep penetrating weapons to hit underground bunkers.

## Chargers' turnover frenzy leads Ravens to 9th win of season
 - [https://www.foxnews.com/sports/chargers-turnover-frenzy-leads-ravens-9th-win-season](https://www.foxnews.com/sports/chargers-turnover-frenzy-leads-ravens-9th-win-season)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T05:17:47+00:00

The Baltimore Ravens came up with multiple turnovers on the Los Angeles Chargers leading to its ninth victory of the season to sit atop the AFC North.

## On this day in history, November 27, 1924, the first Macy's Thanksgiving Day parade is held in NYC
 - [https://www.foxnews.com/lifestyle/this-day-history-november-27-1924-first-macys-thanksgiving-day-parade-held-nyc](https://www.foxnews.com/lifestyle/this-day-history-november-27-1924-first-macys-thanksgiving-day-parade-held-nyc)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T05:02:27+00:00

The Macy&apos;s Thanksgiving Day Parade was first held on this day in history, November 27, 1924. The parade featured several floats, but none of the now-iconic balloons.

## Biden offers apology to Muslim-American leaders for questioning Hamas death toll: report
 - [https://www.foxnews.com/politics/biden-offers-apology-muslim-american-leaders-questioning-hamas-death-toll](https://www.foxnews.com/politics/biden-offers-apology-muslim-american-leaders-questioning-hamas-death-toll)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T02:35:46+00:00

New reports state President Biden apologized to several prominent Muslim-American leaders for publicly questioning the Palestinian death toll being reported by the Hamas-controlled Gaza Ministry of Health.

## Israel-Hamas war: Details begin to emerge of life in captivity after some hostages are freed
 - [https://www.foxnews.com/world/israel-hamas-war-details-emerge-life-captivity-some-hostages-freed](https://www.foxnews.com/world/israel-hamas-war-details-emerge-life-captivity-some-hostages-freed)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T02:29:25+00:00

It&apos;s been three days since Israel and Hamas declared a truce, allowing for the release of hostage, and details are beginning to emerge about life in captivity.

## Jalen Hurts leads Eagles to thrilling overtime win over Bills at home
 - [https://www.foxnews.com/sports/jalen-hurts-leads-eagles-thrilling-overtime-win-bills](https://www.foxnews.com/sports/jalen-hurts-leads-eagles-thrilling-overtime-win-bills)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T02:10:08+00:00

Philadelphia Eagles quarterback Jalen Hurts rushed it in from 12 yards out to defeat the Buffalo Bills, 37-34, in a thrilling overtime victory on Sunday.

## New York corrections officer arrested after allegedly forcing inmate to perform sexual act
 - [https://www.foxnews.com/us/new-york-corrections-officer-arrested-allegedly-forcing-inmate-perform-sexual-act](https://www.foxnews.com/us/new-york-corrections-officer-arrested-allegedly-forcing-inmate-perform-sexual-act)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T02:09:25+00:00

A Suffolk County, New York correctional officer in Riverhead, New York was arrested on Friday after allegedly forcing an inmate to perform a sexual act.

## 'NFL RedZone' host Scott Hanson evacuates studio on live TV as alarm sounds
 - [https://www.foxnews.com/sports/nfl-redzone-host-scott-hanson-evacuates-studio-live-tv-alarm-sounds](https://www.foxnews.com/sports/nfl-redzone-host-scott-hanson-evacuates-studio-live-tv-alarm-sounds)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T01:29:06+00:00

&quot;NFL RedZone&quot; host Scott Hanson was interrupted Sunday afternoon by an alarm blaring in the studio where his broadcast took place. He had to evacuate live.

## North Carolina shooting leaves 4 dead at homeless camp in suspected murder-suicide
 - [https://www.foxnews.com/us/north-carolina-shooting-leaves-dead-homeless-camp-suspected-murder-suicide](https://www.foxnews.com/us/north-carolina-shooting-leaves-dead-homeless-camp-suspected-murder-suicide)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T01:11:01+00:00

Sampson County, North Carolina sheriff&apos;s office deputies responded to shots fired at a homeless encampment and found four people dead from gunfire wounds.

## Broncos' defense swarms Browns in big win to get back to over .500
 - [https://www.foxnews.com/sports/broncos-defense-swarms-browns-big-win-get-back-over-500](https://www.foxnews.com/sports/broncos-defense-swarms-browns-big-win-get-back-over-500)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T01:09:12+00:00

The Denver Broncos are above .500 for the first time under coach Sean Payton and got there with a 29-12 victory over the Cleveland Browns on Sunday.

## Linda Evangelista hasn't dated since CoolSculpting incident: 'Not interested'
 - [https://www.foxnews.com/entertainment/linda-evangelista-hasnt-dated-since-coolsculpting-incident-not-interested](https://www.foxnews.com/entertainment/linda-evangelista-hasnt-dated-since-coolsculpting-incident-not-interested)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T00:42:12+00:00

Linda Evangelista admitted she&apos;s &quot;not interested&quot; in pursuing a romantic relationship after facial procedures eight years ago which left her &quot;disfigured.&quot;

## Rams' Kyren Williams explodes for over 200 yards in blowout win over Cardinals
 - [https://www.foxnews.com/sports/rams-kyren-williams-explodes-over-200-yards-blowout-win-over-cardinals](https://www.foxnews.com/sports/rams-kyren-williams-explodes-over-200-yards-blowout-win-over-cardinals)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T00:35:44+00:00

In his return to the starting lineup, Los Angeles Rams running back Kyren Williams exploded for over 200 scrimmage yards with two touchdowns to help defeat the Arizona Cardinals.

## Chiefs climb back from 14-point deficit to top Raiders
 - [https://www.foxnews.com/sports/chiefs-climb-back-from-14-point-deficit-top-raiders](https://www.foxnews.com/sports/chiefs-climb-back-from-14-point-deficit-top-raiders)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T00:35:08+00:00

Patrick Mahomes guided the Kansas City Chiefs to a victory after being down 14 points to the Las Vegas Raiders early in the game. The Chiefs won 31-17.

## New York couple, 5-year-old son, found stabbed to death in apartment: officials
 - [https://www.foxnews.com/us/new-york-couple-5-year-old-son-found-stabbed-death-apartment-officials](https://www.foxnews.com/us/new-york-couple-5-year-old-son-found-stabbed-death-apartment-officials)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T00:26:34+00:00

Police investigating the death of a Bronx couple and five-year-old son after discovering them stabbed to death inside their apartment early Sunday morning.

## Huge crowd fills streets of London in march against antisemitism, support for Israel
 - [https://www.foxnews.com/world/huge-crowd-streets-london-march-against-antisemitism-support-israel](https://www.foxnews.com/world/huge-crowd-streets-london-march-against-antisemitism-support-israel)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T00:19:17+00:00

About 105,000 people marched through London on Nov. 26, 2023, against antisemitism, which has surged since the Oct. 7 invasion of Israel by Hamas-led terrorists.

## US Navy responds to distress call after Israeli-owned tanker seized off coast of Yemen
 - [https://www.foxnews.com/world/us-navy-responds-distress-call-israeli-owned-tanker-seized-coast-yemen](https://www.foxnews.com/world/us-navy-responds-distress-call-israeli-owned-tanker-seized-coast-yemen)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T00:11:52+00:00

The US Navy responded to a distress call from an Israeli-linked vessel in the Gulf of Aden Sunday, underscoring tensions in the region amid the ongoing war between Israel and Hamas.

## NFL fans skewer refs for missed penalty after tackle on Bills' Josh Allen
 - [https://www.foxnews.com/sports/nfl-fans-skewer-refs-missed-penalty-tackle-bills-josh-allen](https://www.foxnews.com/sports/nfl-fans-skewer-refs-missed-penalty-tackle-bills-josh-allen)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T00:00:49+00:00

Buffalo Bills quarterback Josh Allen appeared to be dragged to the ground by his collar and NFL fans were left wondering why he was penalized on the play instead.

## Single man 'f--king traumatized' after girl brings two surprise guests to first date: 'Our time here is done'
 - [https://www.foxnews.com/media/man-left-traumatized-after-girl-brings-two-surprise-guests-first-date-time-here-is-done](https://www.foxnews.com/media/man-left-traumatized-after-girl-brings-two-surprise-guests-first-date-time-here-is-done)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-27T00:00:07+00:00

An Indian influencer described in viral video being &apos;traumatized&apos; on a first date nightmare when a girl brought two surprise guests to dinner.

