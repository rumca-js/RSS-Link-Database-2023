# Source:Nerdstalgic, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXjmz8dFzRJZrZY8eFiXNUQ, language:en-US

## Where Did All The Manic Pixie Dream Girls Go?
 - [https://www.youtube.com/watch?v=i4PcSAIxpao](https://www.youtube.com/watch?v=i4PcSAIxpao)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXjmz8dFzRJZrZY8eFiXNUQ
 - date published: 2023-11-27T18:00:21+00:00

Not that long ago, it seemed the idea of the Manic Pixie Dream girl was all over the media landscape.  Movies like Garden State and Scott Pilgrim along side shows like New Girl cemented the idea of the Manic Pixie Dream girl into the cultural zeitgeist.  Though looking at film and tv today, it seems the Manic Pixie Dream girl has all but disappeared. 

#ramonaflowers #newgirl #nerdstalgic 

SOURCES
https://www.avclub.com/the-bataan-death-march-of-whimsy-case-file-1-elizabet-1798210595
https://www.indiewire.com/features/general/augustus-waters-the-fault-in-our-stars-manic-pixie-dream-guy-126424/
https://www.theguardian.com/music/2022/jul/21/zooey-deschanel-manic-pixie-dream-girl-im-not-a-girl-im-a-woman

