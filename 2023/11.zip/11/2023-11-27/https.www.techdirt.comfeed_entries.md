# Source:Techdirt, URL:https://www.techdirt.com/feed/, language:en-US

## Dear Marin County Board of Supervisors: Reject The Sheriff’s Proposal To Install License Plate Cameras In The County
 - [https://www.techdirt.com/2023/11/27/dear-marin-county-board-of-supervisors-reject-the-sheriffs-proposal-to-install-license-plate-cameras-in-the-county](https://www.techdirt.com/2023/11/27/dear-marin-county-board-of-supervisors-reject-the-sheriffs-proposal-to-install-license-plate-cameras-in-the-county)
 - RSS feed: https://www.techdirt.com/feed/
 - date published: 2023-11-27T21:30:00+00:00

With almost zero public notice, the Board of Supervisors of Marin County, California (just to the north of San Francisco over the Golden Gate Bridge) is on the verge of approving tomorrow a demand by the county sheriff’s department to install license plate cameras throughout the county. As a county resident, I object. My comment [&#8230;]

## Republicans Want To Block Broadband Funding To Schools That Refuse To Implement Easily Bypassed TikTok Bans
 - [https://www.techdirt.com/2023/11/27/republicans-want-to-block-broadband-funding-to-schools-that-refuse-to-implement-easily-bypassed-tiktok-bans](https://www.techdirt.com/2023/11/27/republicans-want-to-block-broadband-funding-to-schools-that-refuse-to-implement-easily-bypassed-tiktok-bans)
 - RSS feed: https://www.techdirt.com/feed/
 - date published: 2023-11-27T20:01:58+00:00

We&#8217;ve noted how the GOP&#8217;s obsession with TikTok is&#8230; weird and superficial. Guys like Ted Cruz or Brendan Carr will suffer absolute embolisms about TikTok (and TikTok only) to get on cable news where they&#8217;ll be portrayed as good faith privacy reformers. While simultaneously refusing to pass a privacy law or regulate dodgy data brokers [&#8230;]

## Facial Recognition Tech Is Encouraging Cops To Ignore The Best Suspects In Favor Of The *Easiest* Suspects
 - [https://www.techdirt.com/2023/11/27/facial-recognition-tech-is-encouraging-cops-to-ignore-the-best-suspects-in-favor-of-the-easiest-suspects](https://www.techdirt.com/2023/11/27/facial-recognition-tech-is-encouraging-cops-to-ignore-the-best-suspects-in-favor-of-the-easiest-suspects)
 - RSS feed: https://www.techdirt.com/feed/
 - date published: 2023-11-27T18:49:27+00:00

Facial recognition tech has slowly gone mainstream over the past half-decade. Not just in acceptance, but also in opposition. Kashmir Hill exposed perhaps the worst purveyor of this tech &#8212; Clearview &#8212; with a series of articles exposing the company&#8217;s tactics as well as its far right backers. Clearview has managed to become a pariah [&#8230;]

## Daily Deal: The Award-Winning Luminar Neo Bundle
 - [https://www.techdirt.com/2023/11/27/daily-deal-the-award-winning-luminar-neo-bundle-3](https://www.techdirt.com/2023/11/27/daily-deal-the-award-winning-luminar-neo-bundle-3)
 - RSS feed: https://www.techdirt.com/feed/
 - date published: 2023-11-27T18:44:27+00:00

Luminar Neo is an easy-to-use photo editing software that empowers photography lovers to express the beauty they imagined using innovative AI-driven tools. Luminar Neo was built from the ground up to be different from previous Luminar editors. It keeps your favorite LuminarAI tools and expands your arsenal with more state-of-the-art technologies and important changes at [&#8230;]

## Elon’s Censorial Lawsuit Against Media Matters Inspiring Many More People To Find ExTwitter Ads On Awful Content
 - [https://www.techdirt.com/2023/11/27/elons-censorial-lawsuit-against-media-matters-inspiring-many-more-people-to-find-extwitter-ads-on-awful-content](https://www.techdirt.com/2023/11/27/elons-censorial-lawsuit-against-media-matters-inspiring-many-more-people-to-find-extwitter-ads-on-awful-content)
 - RSS feed: https://www.techdirt.com/feed/
 - date published: 2023-11-27T17:36:28+00:00

We’ve already discussed the extremely censorial nature of ExTwitter’s lawsuit against Media Matters for accurately describing ads from major brands that appeared next to explicitly neoNazi content. The lawsuit outright admits that Media Matters did, in fact, see those ads next to that content. Its main complaint is that Elon is mad that he thinks [&#8230;]

## California Activists Say State Isn’t Being Transparent About How Billions In Broadband Subsidies Are Being Spent
 - [https://www.techdirt.com/2023/11/27/california-activists-say-state-isnt-being-transparent-about-how-billions-in-broadband-subsidies-are-being-spent](https://www.techdirt.com/2023/11/27/california-activists-say-state-isnt-being-transparent-about-how-billions-in-broadband-subsidies-are-being-spent)
 - RSS feed: https://www.techdirt.com/feed/
 - date published: 2023-11-27T13:31:28+00:00

Two years ago the state of California unveiled a major broadband plan that, among other things, aims to spend $3.5 billion to create a massive, open access “middle mile” fiber network in a bid to boost competition. It’s part of a broader quest to make broadband both more affordable and more competitive (see our Copia report from last year discussing the [&#8230;]

