# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## OnePlus 12 zadebiutuje w grudniu. Producent zaprezentował swój nowy smartfon
 - [https://ithardware.pl/aktualnosci/oneplus_12_zadebiutuje_w_grudniu_producent_zaprezentowal_swoj_nowy_smartfon-30437.html](https://ithardware.pl/aktualnosci/oneplus_12_zadebiutuje_w_grudniu_producent_zaprezentowal_swoj_nowy_smartfon-30437.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-11-27T22:51:35+00:00

<img src="https://ithardware.pl/artykuly/min/30437_1.jpg" />            Poznaliśmy datę premiery OnePlus 12, kt&oacute;ry trafi na rynek chiński w grudniu. Producent, zapowiadając smartfona ujawnił także jego wygląd. Oto co zaoferuje nowe urządzenie.

OnePlus 12 zadebiutuje początkowo tylko w Chinach...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/oneplus_12_zadebiutuje_w_grudniu_producent_zaprezentowal_swoj_nowy_smartfon-30437.html">https://ithardware.pl/aktualnosci/oneplus_12_zadebiutuje_w_grudniu_producent_zaprezentowal_swoj_nowy_smartfon-30437.html</a></p>

## Assassin's Creed: Syndicate dostępny za darmo
 - [https://ithardware.pl/aktualnosci/assassin_s_creed_syndicate_dostepny_za_darmo-30436.html](https://ithardware.pl/aktualnosci/assassin_s_creed_syndicate_dostepny_za_darmo-30436.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-11-27T21:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/30436_1.jpg" />            Ubisoft przygotował niespodziankę dla graczy i udostępnił bezpłatnie grę Assassin's Creed: Syndicate, kt&oacute;ry przenosi nas do epoki wiktoriańskiej. Oferta jest ograniczona czasowo.

Assassin's Creed: Syndicate jest dostępny za...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/assassin_s_creed_syndicate_dostepny_za_darmo-30436.html">https://ithardware.pl/aktualnosci/assassin_s_creed_syndicate_dostepny_za_darmo-30436.html</a></p>

## Red Dead Redemption 2 z nowym rekordem graczy
 - [https://ithardware.pl/aktualnosci/red_dead_redemption_2_z_rekordem_graczy-30435.html](https://ithardware.pl/aktualnosci/red_dead_redemption_2_z_rekordem_graczy-30435.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-11-27T19:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/30435_1.jpg" />            Red Dead Redemption 2 wraca do żywych. Dzięki wyprzedaży Black Friday gra ponownie wzbudziła zainteresowanie graczy, do tego stopnia, że ustanowiła rekord jednocześnie aktywnych os&oacute;b.

Red Dead Redemption 2 trafił na konsole w 2018 roku,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/red_dead_redemption_2_z_rekordem_graczy-30435.html">https://ithardware.pl/aktualnosci/red_dead_redemption_2_z_rekordem_graczy-30435.html</a></p>

## Użytkownicy Dysku Google skarżą się na znikające pliki
 - [https://ithardware.pl/aktualnosci/uzytkownicy_dysku_google_skarza_sie_na_znikajace_pliki-30434.html](https://ithardware.pl/aktualnosci/uzytkownicy_dysku_google_skarza_sie_na_znikajace_pliki-30434.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-11-27T18:23:50+00:00

<img src="https://ithardware.pl/artykuly/min/30434_1.jpg" />            W sieci pojawiły się doniesienia o znikających plikach z Dysku Google. Jeden z użytkownik&oacute;w opublikował na forum wpis, w kt&oacute;rym skarży się na usunięcie wszystkich danych od maja. Struktura folder&oacute;w została przywr&oacute;cona...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/uzytkownicy_dysku_google_skarza_sie_na_znikajace_pliki-30434.html">https://ithardware.pl/aktualnosci/uzytkownicy_dysku_google_skarza_sie_na_znikajace_pliki-30434.html</a></p>

## Remake'i gier mogą doczekać się własnej kategorii nagród
 - [https://ithardware.pl/aktualnosci/remake_i_gier_moga_doczekac_sie_wlasnej_kategorii_nagrod-30433.html](https://ithardware.pl/aktualnosci/remake_i_gier_moga_doczekac_sie_wlasnej_kategorii_nagrod-30433.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-11-27T17:22:20+00:00

<img src="https://ithardware.pl/artykuly/min/30433_1.jpg" />            Geoff Keighley rozważył osobną kategorię dla gier, kt&oacute;re&nbsp;zostały odświeżone. Remake'i byłyby tym samym brane pod uwagę jako odrębna część. Problem polega tylko na tym, że aby stworzyć nową kategorię dla tego rodzaju...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/remake_i_gier_moga_doczekac_sie_wlasnej_kategorii_nagrod-30433.html">https://ithardware.pl/aktualnosci/remake_i_gier_moga_doczekac_sie_wlasnej_kategorii_nagrod-30433.html</a></p>

## TP-Link prezentuje dwa przełączniki zasilane przez PoE
 - [https://ithardware.pl/aktualnosci/tp_link_prezentuje_dwa_przelaczniki_zasilane_przez_poe-30432.html](https://ithardware.pl/aktualnosci/tp_link_prezentuje_dwa_przelaczniki_zasilane_przez_poe-30432.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-11-27T15:47:00+00:00

<img src="https://ithardware.pl/artykuly/min/30432_1.jpg" />            TP-Link rozszerza sw&oacute;j asortyment o dwa nowe, pięcioportowe przełączniki PoE+ zasilane przez PoE++ &ndash; modele SG2005P-PD oraz TL-SG1005P-PD. Urządzenia zdaniem producenta znajdą zastosowanie przy rozbudowie&nbsp;sieci kablowej w...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/tp_link_prezentuje_dwa_przelaczniki_zasilane_przez_poe-30432.html">https://ithardware.pl/aktualnosci/tp_link_prezentuje_dwa_przelaczniki_zasilane_przez_poe-30432.html</a></p>

## Test SMX Stormy 120 mm. Ładne i ciche chłodzenie procesora
 - [https://ithardware.pl/testyirecenzje/smx_stormy_120_mm_ladne_i_ciche_chlodzenie_procesora-30324.html](https://ithardware.pl/testyirecenzje/smx_stormy_120_mm_ladne_i_ciche_chlodzenie_procesora-30324.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-11-27T14:22:10+00:00

<img src="https://ithardware.pl/artykuly/min/30324_1.jpg" />            Jakiś czas temu marka Silver Monkey X wprowadziła&nbsp;nowe chłodzenia procesora, ostatnio testowałem SMX Frosty Pro 2 x 120 mm, a dziś zajmiemy się słabszym modelem SMX Stormy. SMX Stormy to asymetryczna jednowieżowa konstrukcja z...
            <p>Pełna wersja strony <a href="https://ithardware.pl/testyirecenzje/smx_stormy_120_mm_ladne_i_ciche_chlodzenie_procesora-30324.html">https://ithardware.pl/testyirecenzje/smx_stormy_120_mm_ladne_i_ciche_chlodzenie_procesora-30324.html</a></p>

## Cyber Monday w Geekbuying! Mnóstwo sprzętu w obniżonej cenie!
 - [https://ithardware.pl/aktualnosci/cyber_monday_w_geekbuying_mnostwo_sprzetu_w_obnizonej_cenie-30429.html](https://ithardware.pl/aktualnosci/cyber_monday_w_geekbuying_mnostwo_sprzetu_w_obnizonej_cenie-30429.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-11-27T14:13:50+00:00

<img src="https://ithardware.pl/artykuly/min/30429_1.jpg" />            Był Black Friday, a teraz czas na Cyber Monday! W serwisie Geekbuying znajdziecie całe mn&oacute;stwo rabat&oacute;w na sprzęt i gadżety elektroniczne. Sprawdź, na jakie obniżki możesz liczyć tym razem!

Geekbuying to jeden z najbardziej...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/cyber_monday_w_geekbuying_mnostwo_sprzetu_w_obnizonej_cenie-30429.html">https://ithardware.pl/aktualnosci/cyber_monday_w_geekbuying_mnostwo_sprzetu_w_obnizonej_cenie-30429.html</a></p>

## Windows ma ogromny problem z bezpieczeństwem logowania
 - [https://ithardware.pl/aktualnosci/windows_ma_ogromny_problem_z_bezpieczenstwem_logowania-30430.html](https://ithardware.pl/aktualnosci/windows_ma_ogromny_problem_z_bezpieczenstwem_logowania-30430.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-11-27T13:42:50+00:00

<img src="https://ithardware.pl/artykuly/min/30430_1.jpg" />            Microsoft Windows Hello to obecnie dość powszechna metoda logowania się do systemu Windows.&nbsp;Jednakże ochronę biometryczną udało się już pokonać na kilka sposob&oacute;w, a problemem są gł&oacute;wnie producenci notebook&oacute;w i...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/windows_ma_ogromny_problem_z_bezpieczenstwem_logowania-30430.html">https://ithardware.pl/aktualnosci/windows_ma_ogromny_problem_z_bezpieczenstwem_logowania-30430.html</a></p>

## Elon Musk się ugiął w Izraelu. Starlink w Strefie Gazy tylko za zgodą izraelskiego ministra
 - [https://ithardware.pl/aktualnosci/elon_musk_sie_ugial_w_izraelu_starlink_w_strefie_gazy_tylko_za_zgoda_izraelskiego_ministra-30428.html](https://ithardware.pl/aktualnosci/elon_musk_sie_ugial_w_izraelu_starlink_w_strefie_gazy_tylko_za_zgoda_izraelskiego_ministra-30428.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-11-27T12:38:20+00:00

<img src="https://ithardware.pl/artykuly/min/30428_1.jpg" />            Minister Komunikacji, Shlomo Karhi, ogłosił w poniedziałek, że wykorzystanie jednostek satelitarnych Starlink w Izraelu, w tym w Strefie Gazy, wymaga zgody izraelskiego Ministerstwa Komunikacji.

Elon Musk, założyciel Starlink i właściciel X,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/elon_musk_sie_ugial_w_izraelu_starlink_w_strefie_gazy_tylko_za_zgoda_izraelskiego_ministra-30428.html">https://ithardware.pl/aktualnosci/elon_musk_sie_ugial_w_izraelu_starlink_w_strefie_gazy_tylko_za_zgoda_izraelskiego_ministra-30428.html</a></p>

## AMD Ryzen 8040HS/H/U - układy APU Hawk Point (Zen 4 i RDNA 3) coraz bliżej. Nowe przecieki
 - [https://ithardware.pl/aktualnosci/amd_ryzen_8040hs_h_u_uklady_apu_hawk_point_zen_4_i_rdna_3_coraz_blizej_nowe_przecieki-30421.html](https://ithardware.pl/aktualnosci/amd_ryzen_8040hs_h_u_uklady_apu_hawk_point_zen_4_i_rdna_3_coraz_blizej_nowe_przecieki-30421.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-11-27T12:30:02+00:00

<img src="https://ithardware.pl/artykuly/min/30421_1.jpg" />            Niedawno pojawił się przeciek dotyczący flagowego APU AMD Ryzen 8000 do laptop&oacute;w. Ten nie ujawnił nazw nadchodzących procesor&oacute;w, jednak możemy się domyślać plan&oacute;w AMD, tym bardziej że w sieci pojawiają się kolejne...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/amd_ryzen_8040hs_h_u_uklady_apu_hawk_point_zen_4_i_rdna_3_coraz_blizej_nowe_przecieki-30421.html">https://ithardware.pl/aktualnosci/amd_ryzen_8040hs_h_u_uklady_apu_hawk_point_zen_4_i_rdna_3_coraz_blizej_nowe_przecieki-30421.html</a></p>

## Procesory Intel Arrow Lake otrzymają nowe iGPU Arc Xe-LPG Plus z XMX. Jeszcze lepsze XeSS
 - [https://ithardware.pl/aktualnosci/procesory_intel_arrow_lake_otrzymaja_nowe_igpu_arc_xe_lpg_plus_z_xmx_jeszcze_lepsze_xess-30420.html](https://ithardware.pl/aktualnosci/procesory_intel_arrow_lake_otrzymaja_nowe_igpu_arc_xe_lpg_plus_z_xmx_jeszcze_lepsze_xess-30420.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-11-27T11:39:01+00:00

<img src="https://ithardware.pl/artykuly/min/30420_1.jpg" />            Procesory Intel Arrow Lake, kt&oacute;re mają pojawić się w przyszłym roku, będą wyposażone w nieco ulepszoną zintegrowaną kartę graficzną Arc Xe-LPG Plus, kt&oacute;ra oferować będzie akcelerację XMX.

Z najnowszych danych...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/procesory_intel_arrow_lake_otrzymaja_nowe_igpu_arc_xe_lpg_plus_z_xmx_jeszcze_lepsze_xess-30420.html">https://ithardware.pl/aktualnosci/procesory_intel_arrow_lake_otrzymaja_nowe_igpu_arc_xe_lpg_plus_z_xmx_jeszcze_lepsze_xess-30420.html</a></p>

## Samsung rejestrował znaki towarowe "AI Smartphone" i "AI Phone"
 - [https://ithardware.pl/aktualnosci/samsung_rejestrowal_znaki_towarowe_ai_smartphone_i_ai_phone-30427.html](https://ithardware.pl/aktualnosci/samsung_rejestrowal_znaki_towarowe_ai_smartphone_i_ai_phone-30427.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-11-27T11:26:10+00:00

<img src="https://ithardware.pl/artykuly/min/30427_1.jpg" />            Samsung może chcieć promować swoją nadchodzącą generację flagowych smartfon&oacute;w jako urządzenia napędzane przez sztuczną inteligencję. Firma miała bowiem rejestrować znaki towarowe&nbsp;&quot;AI Smartphone&quot; i &quot;AI...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/samsung_rejestrowal_znaki_towarowe_ai_smartphone_i_ai_phone-30427.html">https://ithardware.pl/aktualnosci/samsung_rejestrowal_znaki_towarowe_ai_smartphone_i_ai_phone-30427.html</a></p>

## Pierwszy na świecie gamingowy laptop na platformie AMD z Linuxem już dostępny
 - [https://ithardware.pl/aktualnosci/pierwszy_na_swiecie_gamingowy_laptop_na_platformie_amd_z_linuxem_juz_dostepny-30426.html](https://ithardware.pl/aktualnosci/pierwszy_na_swiecie_gamingowy_laptop_na_platformie_amd_z_linuxem_juz_dostepny-30426.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-11-27T10:44:50+00:00

<img src="https://ithardware.pl/artykuly/min/30426_1.jpg" />            Prawdopodobnie pierwszy na świecie laptop gamingowy z systemem Linux, kt&oacute;ry opiera się wyłącznie na platformie AMD, trafił do sprzedaży.

Sukces Steam Deck otworzył drogę dla gamingowych produkt&oacute;w opartych o system Linux i...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/pierwszy_na_swiecie_gamingowy_laptop_na_platformie_amd_z_linuxem_juz_dostepny-30426.html">https://ithardware.pl/aktualnosci/pierwszy_na_swiecie_gamingowy_laptop_na_platformie_amd_z_linuxem_juz_dostepny-30426.html</a></p>

## Nowe procesory na AM4? AMD podobno szykuje kilka modeli w tym układy z 3D V-Cache
 - [https://ithardware.pl/aktualnosci/nowe_procesory_na_am4_amd_podobno_szykuje_kilka_modeli_w_tym_uklady_z_3d_v_cache-30425.html](https://ithardware.pl/aktualnosci/nowe_procesory_na_am4_amd_podobno_szykuje_kilka_modeli_w_tym_uklady_z_3d_v_cache-30425.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-11-27T10:39:00+00:00

<img src="https://ithardware.pl/artykuly/min/30425_1.jpg" />            O platformie AM4 może niedługo po raz kolejny zrobić się głośno. Nowe doniesienia m&oacute;wią, że AMD szykuje jeszcze kilka nowych procesor&oacute;w z linii Ryzen 5000. W ich skład mają wchodzić modele z pamięcią 3D V-Cache i jednostki z...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nowe_procesory_na_am4_amd_podobno_szykuje_kilka_modeli_w_tym_uklady_z_3d_v_cache-30425.html">https://ithardware.pl/aktualnosci/nowe_procesory_na_am4_amd_podobno_szykuje_kilka_modeli_w_tym_uklady_z_3d_v_cache-30425.html</a></p>

## TeamGroup wprowadza zestaw AIO dla dysków SSD
 - [https://ithardware.pl/aktualnosci/teamgroup_wprowadza_zestaw_aio_dla_dyskow_ssd-30424.html](https://ithardware.pl/aktualnosci/teamgroup_wprowadza_zestaw_aio_dla_dyskow_ssd-30424.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-11-27T10:19:20+00:00

<img src="https://ithardware.pl/artykuly/min/30424_1.jpg" />            Premiera zestawu chłodzenia cieczą dla dysk&oacute;w&nbsp;SSD o nazwie&nbsp;Siren GD120S AIO zbliża się wielkimi krokami, obiecując utrzymanie szybkiego dysku SSD w znacznie niższej temperaturze nawet podczas intensywnego użytkowania.

Nie tylko...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/teamgroup_wprowadza_zestaw_aio_dla_dyskow_ssd-30424.html">https://ithardware.pl/aktualnosci/teamgroup_wprowadza_zestaw_aio_dla_dyskow_ssd-30424.html</a></p>

## Redmagic prezentuje gamingowy monitor 4K z podświetleniem mini LED z aż 5088 strefami
 - [https://ithardware.pl/aktualnosci/redmagic_prezentuje_gamingowy_monitor_4k_z_podswietleniem_mini_led_z_az_5088_strefami-30418.html](https://ithardware.pl/aktualnosci/redmagic_prezentuje_gamingowy_monitor_4k_z_podswietleniem_mini_led_z_az_5088_strefami-30418.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-11-27T10:17:01+00:00

<img src="https://ithardware.pl/artykuly/min/30418_1.jpg" />            Wyświetlacze mini-LED wykorzystują podświetlenie oparte na diodach LED, kt&oacute;re może obsługiwać mn&oacute;stwo lokalnych stref przyciemniania, zapewniając lepsze wrażenia podczas oglądania treści HDR. Redmagic zaprezentował zaś...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/redmagic_prezentuje_gamingowy_monitor_4k_z_podswietleniem_mini_led_z_az_5088_strefami-30418.html">https://ithardware.pl/aktualnosci/redmagic_prezentuje_gamingowy_monitor_4k_z_podswietleniem_mini_led_z_az_5088_strefami-30418.html</a></p>

## Radeon RX 7900 GRE - grafika do kupienia w Polsce już za 2900 zł, a cena ciągle spada
 - [https://ithardware.pl/aktualnosci/radeon_rx_7900_gre_grafika_do_kupienia_w_polsce_juz_za_2900_zl_a_cena_ciagle_spada-30422.html](https://ithardware.pl/aktualnosci/radeon_rx_7900_gre_grafika_do_kupienia_w_polsce_juz_za_2900_zl_a_cena_ciagle_spada-30422.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-11-27T09:15:02+00:00

<img src="https://ithardware.pl/artykuly/min/30422_1.jpg" />            Gracze w Europie, kt&oacute;rzy zastanawiają się nad kartami graficznymi RDNA 3 do komputer&oacute;w stacjonarnych, mają teraz twardy orzech do zgryzienia, bo Radeon RX 7900 GRE jawi się jako naprawdę kusząco opcja.&nbsp;

Pomimo tego, że Radeon...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/radeon_rx_7900_gre_grafika_do_kupienia_w_polsce_juz_za_2900_zl_a_cena_ciagle_spada-30422.html">https://ithardware.pl/aktualnosci/radeon_rx_7900_gre_grafika_do_kupienia_w_polsce_juz_za_2900_zl_a_cena_ciagle_spada-30422.html</a></p>

## Ogromny wyciek danych pacjentów ALABu. Mają wszystko - od numeru PESEL po wyniki badań
 - [https://ithardware.pl/aktualnosci/ogromny_wyciek_danych_pacjentow_z_alabu_maja_wszystko_od_numeru_pesel_po_wyniki_badan-30423.html](https://ithardware.pl/aktualnosci/ogromny_wyciek_danych_pacjentow_z_alabu_maja_wszystko_od_numeru_pesel_po_wyniki_badan-30423.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-11-27T09:07:10+00:00

<img src="https://ithardware.pl/artykuly/min/30423_1.jpg" />            Do internetu wyciekły dane osobowe i wyniki badań medycznych z jednej z największych sieci laboratori&oacute;w medycznych w Polsce, firmy ALAB.&nbsp;

Polscy pacjenci mają kolejny problem.&nbsp;Grupa ransomware o nazwie RA World zdołała włamać...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/ogromny_wyciek_danych_pacjentow_z_alabu_maja_wszystko_od_numeru_pesel_po_wyniki_badan-30423.html">https://ithardware.pl/aktualnosci/ogromny_wyciek_danych_pacjentow_z_alabu_maja_wszystko_od_numeru_pesel_po_wyniki_badan-30423.html</a></p>

## Dimensity 9300 - flagowiec MediaTek traci nawet 46% wydajności na skutek throttlingu
 - [https://ithardware.pl/aktualnosci/dimensity_9300_flagowiec_mediatek_traci_nawet_46_wydajnosci_na_skutek_throttlingu-30419.html](https://ithardware.pl/aktualnosci/dimensity_9300_flagowiec_mediatek_traci_nawet_46_wydajnosci_na_skutek_throttlingu-30419.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-11-27T08:39:00+00:00

<img src="https://ithardware.pl/artykuly/min/30419_1.jpg" />            W tym roku MediaTek nie trzymało się tradycyjnego podziału na klastry w swoim flagowym układzie Dimensity 9300, jak np. Snapdragon 8 Gen 3 i największą r&oacute;żnicą między tymi dwoma chipsetami jest brak energooszczędnych rdzeni w nowym...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/dimensity_9300_flagowiec_mediatek_traci_nawet_46_wydajnosci_na_skutek_throttlingu-30419.html">https://ithardware.pl/aktualnosci/dimensity_9300_flagowiec_mediatek_traci_nawet_46_wydajnosci_na_skutek_throttlingu-30419.html</a></p>

## Chiny budują podwodne centrum danych o mocy 6 milionów komputerów PC
 - [https://ithardware.pl/aktualnosci/chiny_buduja_podwodne_centrum_danych_o_mocy_6_milionow_komputerow_pc-30417.html](https://ithardware.pl/aktualnosci/chiny_buduja_podwodne_centrum_danych_o_mocy_6_milionow_komputerow_pc-30417.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-11-27T08:02:13+00:00

<img src="https://ithardware.pl/artykuly/min/30417_1.jpg" />            Podwodne centra danych nie są niczym nowym, Microsoft i rozpoczął ten trend za sprawą projektu Natick, w ramach kt&oacute;rego zanurzył takowe w głębinach oceanu już w 2014 roku, a teraz Chiny rozpoczęły budowę pierwszego na świecie...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/chiny_buduja_podwodne_centrum_danych_o_mocy_6_milionow_komputerow_pc-30417.html">https://ithardware.pl/aktualnosci/chiny_buduja_podwodne_centrum_danych_o_mocy_6_milionow_komputerow_pc-30417.html</a></p>

## Ruszył Cyber Monday w x-komie. Ceny sprzętów obniżone do 66%
 - [https://ithardware.pl/aktualnosci/ruszyl_cyber_monday_w_x_komie_ceny_sprzetow_obnizone_do_66-30408.html](https://ithardware.pl/aktualnosci/ruszyl_cyber_monday_w_x_komie_ceny_sprzetow_obnizone_do_66-30408.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-11-27T06:30:01+00:00

<img src="https://ithardware.pl/artykuly/min/30408_1.jpg" />            Jeszcze dobrze nie opadły emocje po Black Friday, a już w x-komie ruszyła nowa promocja przygotowana z okazji Cyber Monday. Tym razem rabaty sięgają nawet do 66%. Natomiast w sklepie al.to wciąż trwa Black Friday, gdzie rabaty sięgają 99%....
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/ruszyl_cyber_monday_w_x_komie_ceny_sprzetow_obnizone_do_66-30408.html">https://ithardware.pl/aktualnosci/ruszyl_cyber_monday_w_x_komie_ceny_sprzetow_obnizone_do_66-30408.html</a></p>

