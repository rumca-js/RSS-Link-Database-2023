# Source:Ign - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw, language:en-US

## Sony Is Releasing More Marvel Movies In 2024 Than Disney Is - IGN The Fix: Entertainment
 - [https://www.youtube.com/watch?v=RwfOdRxzvpc](https://www.youtube.com/watch?v=RwfOdRxzvpc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-11-27T23:33:28+00:00

Who will win the Marvel movie war of 2024: Sony or Disney? While Sony seems to be focused on releasing more Marvel-related movies in 2024, Disney surprisingly seems to be more concentrated on pushing out Disney Plus-related Marvel content. So far, Sony has Madame Web, Kraven the Hunter, and Venom 3 all releasing in theaters sometime in 2024. Whereas Disney’s Marvel Studios only has Deadpool 3 slated to release next year. But looking at Disney’s MCU streaming schedule, there’s 5 coming in 2024: Marvel Zombies, Spider-Man: Freshman Year, Agatha: Darkhold Diaries, X-Men ‘97 and Echo.

## Scott Pilgrim Takes Off: Did you catch these voice actors? #scottpilgrim #scottpilgrimtakesoff #tv
 - [https://www.youtube.com/watch?v=X6DwKPXFexI](https://www.youtube.com/watch?v=X6DwKPXFexI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-11-27T20:25:41+00:00



## Suicide Squad: Kill the Justice League - Official Captain Boomerang Trailer
 - [https://www.youtube.com/watch?v=M2Gjeq3DKgY](https://www.youtube.com/watch?v=M2Gjeq3DKgY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-11-27T20:00:17+00:00

Meet George Harkness a.k.a Captain Boomerang, learn about the character, and see him in action in this latest trailer for the upcoming third-person action shooter game Suicide Squad: Kill the Justice League. 

Taken down by the Flash more times than he can count, this Boomerang keeps coming back. With a hint of speedforce of his own, Captain Boomerang is on his mark to catch the Scarlet Speedster and put him in his place.

Suicide Squad: Kill the Justice League will be available on PlayStation 5, Xbox Series X/S, and PC on February 2, 2024.

## EarthBound USA - Official Teaser Trailer (2023) Shigesato Itoi (Documentary)
 - [https://www.youtube.com/watch?v=1WcLsufcDg8](https://www.youtube.com/watch?v=1WcLsufcDg8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-11-27T18:00:02+00:00

Check out the trailer for EarthBound USA, an independent documentary on EarthBound, and featuring interviews with MOTHER series creator Shigesato Itoi, former Nintendo employees, and more. American teenagers connect on the early internet to crusade for their favorite videogame of all time, pitting their fan site against a corporate goliath and their own looming adulthoods.

EarthBound USA is a movie about discovering the power of online community set in the burgeoning Wild West of Web 1.0, butting heads with corporate goliaths and your own looming adulthood, and your fan site becoming the cult behind one of the most infamous cult classic videogames of all time.

EarthBound USA began life in 2013 as a passion project started by writer & director Jazzy Benson. Inspired by the internet folklore surrounding EarthBound’s U.S. fanbase, and from hearing the insider stories behind Starmen.Net’s legendary petitions and letter-writing campaigns, Jazzy aimed to create a documentary that evokes 

## Indiana Jones and the Dial of Destiny - Official Disney+ Release Date Trailer (2023) Harrison Ford
 - [https://www.youtube.com/watch?v=LC88-ecBPkM](https://www.youtube.com/watch?v=LC88-ecBPkM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-11-27T17:26:29+00:00

Indiana Jones and the Dial of Destiny arrives on Disney+ on December 1, 2023. Watch the latest trailer for another look at this movie starring Harrison Ford as the iconic hero archeologist Indiana Jones. The film also stars Phoebe Waller-Bridge, Antonio Banderas, John Rhys-Davies, Shaunette Renee Wilson, Thomas Kretschmann, Toby Jones, Boyd Holbrook, Oliver Richters, Ethann Isidore, and Mads Mikkelsen.

#IGN #Movies #IndianaJones

## Apex Legends - Official 'Kill Code Part 4' Trailer
 - [https://www.youtube.com/watch?v=BCW7G_MOF-w](https://www.youtube.com/watch?v=BCW7G_MOF-w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-11-27T17:00:12+00:00

Check out Kill Code Part 4, the final installment from the Apex Legends miniseries. United in their goals, the Legends face off with Duardo to destroy Revenant’s head once and for all. Apex Legends is available now on PlayStation 4, PlayStation 5, Xbox One, Xbox Series X/S, Nintendo Switch, and PC via EA App and Steam.

#IGN #Gaming #ApexLegends

## Project M - Official G-STAR 2023 Trailer
 - [https://www.youtube.com/watch?v=ME51GDsPRb8](https://www.youtube.com/watch?v=ME51GDsPRb8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-11-27T16:00:17+00:00

Here's your look at NCSOFT's 'Project M' in this trailer for the upcoming interactive adventure game. Project M will be available on consoles and PC.

#IGN #Gaming #Games

## King Arthur: Knight's Tale: Legion IX - Official Cinematic Reveal Trailer
 - [https://www.youtube.com/watch?v=yncKVZekB90](https://www.youtube.com/watch?v=yncKVZekB90)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-11-27T15:13:38+00:00

Check out the latest trailer for King Arthur: Knight's Tale to see the reveal of the upcoming Legion IX expansion for the dark fantasy tactics game, featuring a new Roman campaign and more. 

In the Legion IX expansion, the kingdom of Avalon is facing an all-new threat, as the Roman Ninth Legion has discovered a path to the mystical island, and is preparing an invasion. You will experience the brand new Roman campaign through the eyes of a tribune of the Ninth Legion, and you will uncover the remains of a Roman colony in Avalon and reveal the hidden secrets of the Lady of the Lake.

King Arthur: Knight's Tale's Legion IX will be available in early 2024.

#IGN #Gaming #KingArthur

