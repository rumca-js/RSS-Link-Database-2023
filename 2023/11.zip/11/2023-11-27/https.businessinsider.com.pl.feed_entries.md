# Source:Business insider, URL:https://businessinsider.com.pl/.feed, language:pl-PL

## "Misja trudna, ale potrzebna". Premier o swoim nowym rządzie
 - [https://businessinsider.com.pl/wiadomosci/misja-trudna-ale-potrzebna-premier-o-swoim-nowym-rzadzie/9kf0bgs](https://businessinsider.com.pl/wiadomosci/misja-trudna-ale-potrzebna-premier-o-swoim-nowym-rzadzie/9kf0bgs)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T20:37:37+00:00

Choć PiS nie ma większości w Sejmie, prezydent powołał nowy rząd Morawieckiego. "Rozpoczynamy trudną, ale potrzebną misję" – stwierdził premier.

## Perła niemieckiej gospodarki "nie jest już konkurencyjna". Szef przyznaje
 - [https://businessinsider.com.pl/gospodarka/perla-niemieckiej-gospodarki-nie-jest-juz-konkurencyjna/gz71d8b](https://businessinsider.com.pl/gospodarka/perla-niemieckiej-gospodarki-nie-jest-juz-konkurencyjna/gz71d8b)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T19:36:20+00:00

"Nie jesteśmy już konkurencyjni" – przyznał Thomas Schäfer, szef pionu aut osobowych VW. Dodał, że problemem legendarnego brandu są wysokie koszty produkcji. Firma wprowadza zatem ostre cięcia.

## 5 proc. Polaków nie kupi prezentów na święta. Nie zawsze chodzi o pieniądze
 - [https://businessinsider.com.pl/poradnik-finansowy/5-proc-polakow-nie-kupi-prezentow-na-swieta/bwt1k06](https://businessinsider.com.pl/poradnik-finansowy/5-proc-polakow-nie-kupi-prezentow-na-swieta/bwt1k06)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T19:05:06+00:00

Najwięcej Polaków kupuje prezenty w połowie listopada i na początku grudnia – wynika z najnowszych badań przeprowadzonych przez firmę Klarna. Całkiem sporo osób zupełnie jednak rezygnuje z takich zakupów.

## KSeF zbliża się wielkimi krokami. Odpowiadamy na siedem najważniejszych pytań
 - [https://businessinsider.com.pl/prawo/podatki/ksef-zbliza-sie-wielkimi-krokami-eksperci-odpowiadaja-na-siedem-najwazniejszych-pytan/7xkcnn9](https://businessinsider.com.pl/prawo/podatki/ksef-zbliza-sie-wielkimi-krokami-eksperci-odpowiadaja-na-siedem-najwazniejszych-pytan/7xkcnn9)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T18:57:52+00:00

Od 1 lipca 2024 r. po dwóch latach dobrowolnego pilotażu Krajowy System e-Faktur stanie się obowiązkowy. To będzie niemała rewolucja w sposobie funkcjonowania wewnętrznych procedur przedsiębiorcy, dotyczących całości rozliczeń z kontrahentami. Czasu jest coraz mniej, zatem warto rozpocząć przygotowania. Jak piszą dr Jacek Matarewicz i Agnieszka Ławnicka z kancelarii Tomczykowski Tomczykowska.

## Dalekobieżne autobusy też będą elektryczne. Znany przewoźnik zapewnia
 - [https://businessinsider.com.pl/gospodarka/dalekobiezne-autobusy-tez-beda-elektryczne-znany-przewoznik-zapewnia/9fc64g5](https://businessinsider.com.pl/gospodarka/dalekobiezne-autobusy-tez-beda-elektryczne-znany-przewoznik-zapewnia/9fc64g5)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T18:11:38+00:00

FlixBus zapewnia, że do 2040 r. zapewni pasażerom w Europie "całkowicie neutralne podróże pod względem emisji dwutlenku węgla". Wozić nas będą zatem elektryczne autobusy – choć nie tylko takie.

## Flipperzy kochają Polskę. Deweloperzy też zacierają ręce
 - [https://businessinsider.com.pl/nieruchomosci/flipperzy-kochaja-polske-deweloperzy-tez-zacieraja-rece/bd9j2jk](https://businessinsider.com.pl/nieruchomosci/flipperzy-kochaja-polske-deweloperzy-tez-zacieraja-rece/bd9j2jk)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T18:04:17+00:00

Ceny mieszkań wyraźnie rosną i to nie koniec podwyżek. Pojawiają się głosy, że deweloperzy będą podnosić ceny nawet kosztem utraty klientów. To olbrzymi problem dla wszystkich chcących kupić swoje pierwsze mieszkanie. Natomiast flipperzy zacierają ręce.

## Flipperzy kochają Polskę. Deweloperzy też zacierają ręce
 - [https://businessinsider.com.pl/nieruchomosci/ceny-mieszkan-wystrzelily-flipperzy-zacieraja-rece/bd9j2jk](https://businessinsider.com.pl/nieruchomosci/ceny-mieszkan-wystrzelily-flipperzy-zacieraja-rece/bd9j2jk)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T18:04:17+00:00

Ceny mieszkań wyraźnie rosną i to nie koniec podwyżek. Pojawiają się głosy, że deweloperzy będą podnosić ceny nawet kosztem utraty klientów. To olbrzymi problem dla wszystkich chcących kupić swoje pierwsze mieszkanie. Natomiast flipperzy zacierają ręce.

## "To już czas na nas". Tak eksministrowie żegnają się w sieci
 - [https://businessinsider.com.pl/wiadomosci/to-juz-czas-tak-eksministrowie-zegnaja-sie-w-sieci/xnrvp15](https://businessinsider.com.pl/wiadomosci/to-juz-czas-tak-eksministrowie-zegnaja-sie-w-sieci/xnrvp15)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T17:11:14+00:00

Prezydent powołał nowy rząd, który będzie rządził zapewne najwyżej kilkanaście dni. W nowym gabinecie nie znalazło się natomiast wielu ministrów z ostatniego rządu Mateusza Morawieckiego. Waldemar Buda i Magdalena Rzeczkowska już żegnają się poprzez media społecznościowe.

## Natychmiastowy efekt promocji na węgiel. Sprzedaż w PGG wzrosła niemal dziesięciokrotnie
 - [https://businessinsider.com.pl/poradnik-finansowy/natychmiastowy-efekt-promocji-na-wegiel-sprzedaz-w-pgg-wzrosla-niemal/fd8qgcj](https://businessinsider.com.pl/poradnik-finansowy/natychmiastowy-efekt-promocji-na-wegiel-sprzedaz-w-pgg-wzrosla-niemal/fd8qgcj)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T17:06:08+00:00

Czasowa obniżka ceny węgla opałowego o 200 zł na tonie przyniosła niemal dziesięciokrotny wzrost sprzedaży w sklepie internetowym Polskiej Grupy Górniczej (PGG) — poinformowała w poniedziałek spółka, która po raz pierwszy przygotowała dla nabywców surowca ofertę pod hasłem Black Weeks.

## Zastąpi Annę Moskwę. Co wiemy o nowej minister w rządzie Morawieckiego?
 - [https://businessinsider.com.pl/wiadomosci/oto-minister-klimatu-w-nowym-rzadzie-morawieckiego-zastapi-anne-moskwe/el2bcb1](https://businessinsider.com.pl/wiadomosci/oto-minister-klimatu-w-nowym-rzadzie-morawieckiego-zastapi-anne-moskwe/el2bcb1)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T16:56:43+00:00

W nowym rządzie Mateusza Morawieckiego ministrem klimatu i środowiska została Anna Łukaszewska-Trzeciakowska. Dotychczasowa pełnomocnik rządu ds. strategicznej infrastruktury energetycznej zastąpiła na tym stanowisku Annę Moskwę. Kim jest nowa minister?

## Jest porozumienie Izraela i Hamasu o przedłużeniu rozejmu
 - [https://businessinsider.com.pl/wiadomosci/jest-porozumienie-izraela-i-hamasu-o-przedluzeniu-rozejmu/xsmx1y7](https://businessinsider.com.pl/wiadomosci/jest-porozumienie-izraela-i-hamasu-o-przedluzeniu-rozejmu/xsmx1y7)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T16:44:28+00:00

Ministerstwo spraw zagranicznych Kataru poinformowało w poniedziałek po południu, że zawieszenie broni między Izraelem a Hamasem zostało przedłużone o dwa dni. Katar wraz z Egiptem i USA pełni rolę mediatorów w negocjacjach pokojowych.

## To ona zastąpi Jacka Sasina. Co wiemy o nowej szefowej MAP?
 - [https://businessinsider.com.pl/wiadomosci/to-ona-zastapi-jacka-sasina-co-wiemy-o-nowej-szefowej-map/m23p5ec](https://businessinsider.com.pl/wiadomosci/to-ona-zastapi-jacka-sasina-co-wiemy-o-nowej-szefowej-map/m23p5ec)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T16:20:23+00:00

W nowym rządzie Mateusza Morawieckiego, który ma szansę utrzymać się tylko dwa tygodnie, na czele Ministerstwa Aktywów Państwowych stanie Marzena Małek. Zastąpi na tym miejscu Jacka Sasina. Tym samym potwierdziły się wcześniejsze informacje Business Insider Polska.

## Sejmowa komisja zdecydowała w sprawie handlu w wigilię
 - [https://businessinsider.com.pl/gospodarka/sejmowa-komisja-zaglosowala-w-sprawie-handlu-w-wigilie/5v3psks](https://businessinsider.com.pl/gospodarka/sejmowa-komisja-zaglosowala-w-sprawie-handlu-w-wigilie/5v3psks)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T16:14:41+00:00

Komisja Gospodarki i Rozwoju przyjęła poselski projekt Polski 2050 w sprawie handlu w wigilię. Według tego projektu 24 grudnia zakupów nie zrobimy.

## Ruch PiS nie zabetonuje TVP. "Połknęli haczyk"
 - [https://businessinsider.com.pl/wiadomosci/ruch-glinskiego-nie-zabetonuje-tvp-polkneli-haczyk/mkfcgm0](https://businessinsider.com.pl/wiadomosci/ruch-glinskiego-nie-zabetonuje-tvp-polkneli-haczyk/mkfcgm0)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T16:06:10+00:00

PiS chce zablokować przejęcie kontroli m.in. nad TVP poprzez zmianę statutów mediów publicznych. Jednak nagły ruch ministra kultury Piotra Glińskiego nie przekreśla planów nadchodzącej władzy. Jak przekonują rozmówcy Onetu, do zmian w mediach publicznych dojdzie jeszcze w tym roku i będzie to "szybkie cięcie".

## Pięć rejsów najpiękniejszymi rzekami Europy — Sekwana, Douro, Ren i Mozela
 - [https://businessinsider.com.pl/lifestyle/podroze/piec-rejsow-najpiekniejszymi-rzekami-europy-sekwana-douro-ren-i-mozela/ntc0m7k](https://businessinsider.com.pl/lifestyle/podroze/piec-rejsow-najpiekniejszymi-rzekami-europy-sekwana-douro-ren-i-mozela/ntc0m7k)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T16:00:00+00:00

Rejs jedną z najpiękniejszych europejskich rzek może być doskonałą alternatywą dla urlopu, podczas którego większość czasu spędzamy na plaży, opuszczając ją jedynie na posiłki w bogatej formule all inclusive. Rzeczne rejsy pasażerskie to interesująca forma wypoczynku dla wszystkich, którym znudziły się tradycyjne urlopy i potrzebują przeżyć coś nowego. Rejsy wycieczkowe to połączenie innej perspektyw zwiedzania, poznawania zabytków, architektury, historii, kultury z jednoczesną wygodą i relaksem. Widok kameralnych wiosek położonych wzdłuż Renu, wspaniałej architektury Wiednia, Budapesztu i Bratysławy, który towarzyszy podczas rejsu Dunajem to tylko część atrakcji, jakie można podziwiać z pokładu statku. W artykule polecamy sprawdzone i docenione przez klientów rejsy wycieczkowe biura podróży Albatros. Zapraszamy!

## Znamy skład rządu PiS. Oto nowy minister finansów
 - [https://businessinsider.com.pl/gospodarka/znamy-sklad-rzadu-pis-oto-nowy-minister-finansow/21x38w7](https://businessinsider.com.pl/gospodarka/znamy-sklad-rzadu-pis-oto-nowy-minister-finansow/21x38w7)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T15:48:51+00:00

Premier Mateusz Morawiecki ogłosił skład nowego rządu, który najpewniej pozostanie u władzy zaledwie dwa tygodnie. Ministerstwem Finansów pokieruje Andrzej Kosztowniak. Kim jest nowy szef tego kluczowego resortu?

## Rząd bez Kaczyńskiego i Ziobry. Prezydenta cieszą dwie rzeczy
 - [https://businessinsider.com.pl/wiadomosci/rzad-bez-wiekszosci-juz-zaprzysiezony/x43kvhk](https://businessinsider.com.pl/wiadomosci/rzad-bez-wiekszosci-juz-zaprzysiezony/x43kvhk)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T15:34:46+00:00

Andrzej Duda powołał nowy rząd Mateusza Morawieckiego. Uroczystość odbyła się w Pałacu Prezydenckim. Prezydent mówi, że cieszy go to, że w gabinecie jest dużo "ekspertów" oraz kobiet.

## Rząd bez większości u prezydenta. Będzie zaprzysiężenie
 - [https://businessinsider.com.pl/wiadomosci/rzad-bez-wiekszosci-u-prezydenta-bedzie-zaprzysiezenie/x43kvhk](https://businessinsider.com.pl/wiadomosci/rzad-bez-wiekszosci-u-prezydenta-bedzie-zaprzysiezenie/x43kvhk)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T15:34:46+00:00

Andrzej Duda powołuje nowy rząd Mateusza Morawieckiego. Uroczystość odbywa się w Pałacu Prezydenckim.

## Elektroniczne nianie w niewygórowanej cenie w Black November
 - [https://businessinsider.com.pl/technologie/elektroniczne-nianie-w-niewygorowanej-cenie-w-black-friday/f4n704g](https://businessinsider.com.pl/technologie/elektroniczne-nianie-w-niewygorowanej-cenie-w-black-friday/f4n704g)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T15:21:00+00:00

Niania elektroniczna to nieoceniony gadżet w każdym domu, w którym zamieszkał nowo narodzony członek rodziny. Pozwala zostawić śpiące dziecko w osobnym pokoju i mieć ciągły podgląd. Przedstawiamy tutaj cztery nianie elektroniczne z funkcją kamery, które niewiele kosztują, a mają przyzwoite opinie. Na końcu artykułu znajdziesz też sześć tanich niań elektrycznych bez kamerki.

## Kojarzysz te drzewa z "Gry o Tron"? Właśnie umierają
 - [https://businessinsider.com.pl/lifestyle/podroze/kojarzysz-te-drzewa-z-gry-o-tron-wlasnie-umieraja/enklx4r](https://businessinsider.com.pl/lifestyle/podroze/kojarzysz-te-drzewa-z-gry-o-tron-wlasnie-umieraja/enklx4r)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T15:11:10+00:00

Nieco ponad dziesięć lat temu zaciszna aleja starych buków w Irlandii Północnej stała się sławna za sprawą "Gry o tron". Jednak niespodziewana sława przyniosła wiekowym drzewom więcej zkody niż pożytku.

## Jest wniosek o powołanie rządu. Połowa stanowisk dla kobiet
 - [https://businessinsider.com.pl/wiadomosci/jest-wniosek-o-powolanie-rzadu-polowa-stanowisk-dla-kobiet/632ce03](https://businessinsider.com.pl/wiadomosci/jest-wniosek-o-powolanie-rzadu-polowa-stanowisk-dla-kobiet/632ce03)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T15:10:04+00:00

Premier Morawiecki skierował do prezydenta Dudy wniosek o powołanie nowej Rady Ministrów. W składzie nowego rządu ponad połowę będą stanowiły kobiety.

## PiS chce zabetonować media publiczne. Oto ile płacimy na TVP
 - [https://businessinsider.com.pl/gospodarka/pis-chce-zabetonowac-media-publiczne-oto-ile-placimy-na-tvp/27w6x03](https://businessinsider.com.pl/gospodarka/pis-chce-zabetonowac-media-publiczne-oto-ile-placimy-na-tvp/27w6x03)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T15:04:56+00:00

PiS próbuje wykorzystać ostatnie tygodnie władzy na "zabetonowanie" mediów publicznych, w tym TVP. Ile wydajemy na państwową telewizję? NIK ostatnio dokładnie to zbadał.

## Mateusz Morawiecki ogłosił skład rządu [LISTA NAZWISK]
 - [https://businessinsider.com.pl/wiadomosci/mateusz-morawiecki-oglosil-sklad-rzadu-lista-nazwisk/0rq2mdv](https://businessinsider.com.pl/wiadomosci/mateusz-morawiecki-oglosil-sklad-rzadu-lista-nazwisk/0rq2mdv)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T15:04:34+00:00

Premier Mateusz Morawiecki skierował do prezydenta Andrzeja Dudy wniosek o powołanie nowej Rady Ministrów. W składzie nowego rządu ponad połowę będą stanowiły kobiety — powiedział PAP rzecznik rządu Piotr Müller.

## Zadyszka na GPW. Byki słabną po ustanowieniu nowych rekordów
 - [https://businessinsider.com.pl/gielda/wiadomosci/zadyszka-na-gpw-byki-slabna-po-ustanowieniu-nowych-rekordow/v4tw22c](https://businessinsider.com.pl/gielda/wiadomosci/zadyszka-na-gpw-byki-slabna-po-ustanowieniu-nowych-rekordow/v4tw22c)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T14:54:38+00:00

Na GPW od ponad roku trwa hossa, która została dodatkowo napędzona powyborczym entuzjazmem. Jednak w ostatnich dniach siły byków nieco opadły. W całym ubiegłym tygodniu (trwającym od 20 do 24 listopada) indeks WIG zyskał 0,5 proc., a WIG20 zamknął się na takim samym poziomie jak poprzednio. Początek nowego tygodnia GPW rozpoczęła od spadków.

## Elon Musk w Izraelu. Zapowiada, że chce pomóc w odbudowie Gazy
 - [https://businessinsider.com.pl/wiadomosci/elon-musk-w-izraelu-zapowiada-ze-chce-pomoc-w-odbudowie-gazy/wyrmtzj](https://businessinsider.com.pl/wiadomosci/elon-musk-w-izraelu-zapowiada-ze-chce-pomoc-w-odbudowie-gazy/wyrmtzj)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T14:49:31+00:00

Miliarder Elon Musk odwiedził Izrael. W rozmowie z premierem Benjaminem Netanjahu powiedział, że po wojnie chciałby pomóc w odbudowie Gazy.

## Chińczycy marzą o karierze urzędników. To efekt kryzysu
 - [https://businessinsider.com.pl/wiadomosci/chinczycy-marza-o-karierze-urzednikow-to-efekt-kryzysu/066ebh0](https://businessinsider.com.pl/wiadomosci/chinczycy-marza-o-karierze-urzednikow-to-efekt-kryzysu/066ebh0)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T14:42:57+00:00

Przeszło 2,25 mln Chińczyków przystąpiło do tegorocznej tury egzaminów państwowych, które zdecydują o obsadzie blisko 40 tys. stanowisk w administracji publicznej – poinformowały państwowe media.

## Jest nowa szefowa komisji rodziny. Zagwarantuje wakacje składkowe i rentę wdowią?
 - [https://businessinsider.com.pl/prawo/jest-nowa-szefowa-komisji-rodziny-zagwarantuje-wakacje-skladkowe-i-rente-wdowia/dgq8xsn](https://businessinsider.com.pl/prawo/jest-nowa-szefowa-komisji-rodziny-zagwarantuje-wakacje-skladkowe-i-rente-wdowia/dgq8xsn)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T14:08:55+00:00

Przewodniczącą sejmowej Komisji Polityki Społecznej i Rodziny została Katarzyna Kotula z Lewicy. Funkcja ta ma istotne znaczenie, bo większość sejmowa zapowiadała wiele zmian w polityce socjalnej, w tym m.in. wsparcie dla emerytów po śmierci małżonka i zwolnienie w opłacaniu składek przez przedsiębiorców.

## Przyszły rząd ma plan na ceny prądu. Nieoficjalnie: jest projekt ustawy
 - [https://businessinsider.com.pl/poradnik-finansowy/przyszly-rzad-ma-plan-na-ceny-pradu-nieoficjalnie-jest-projekt-ustawy/mr1vct6](https://businessinsider.com.pl/poradnik-finansowy/przyszly-rzad-ma-plan-na-ceny-pradu-nieoficjalnie-jest-projekt-ustawy/mr1vct6)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T14:05:42+00:00

Przyszły rząd Donalda Tuska, który ma przejąć władzę w grudniu, chce utrzymać zamrożone ceny prądu do końca czerwca 2024 r. Jednocześnie wprowadzi dwie inne zmiany na rynku energii — przywróci obligo giełdowe i złagodzi obostrzenia dla budowy farm wiatrowych na lądzie.

## Sieć dyskontów daje premie i bony świąteczne
 - [https://businessinsider.com.pl/gospodarka/siec-dyskontow-daje-premie-i-bony-swiateczne/md7etw9](https://businessinsider.com.pl/gospodarka/siec-dyskontow-daje-premie-i-bony-swiateczne/md7etw9)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T14:02:33+00:00

Aldi przekazuje wszystkim swoim pracownikom świąteczne bony zakupowe w postaci dodatkowego doładowania na karty przedpłacone. Sieć zaplanowała także dodatek za frekwencję.

## Nowe świadczenie od 1 stycznia. Już teraz trzeba złożyć wniosek
 - [https://businessinsider.com.pl/gospodarka/nowe-swiadczenie-od-1-stycznia-juz-teraz-trzeba-zlozyc-wniosek/56fe2k5](https://businessinsider.com.pl/gospodarka/nowe-swiadczenie-od-1-stycznia-juz-teraz-trzeba-zlozyc-wniosek/56fe2k5)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T13:24:07+00:00

Od 1 stycznia 2024 r. wypłacane będzie nowe świadczenie, które trafi do rodzin pełnoletnich osób z niepełnosprawnościami. Cały program wsparcia będzie kosztował około 4 mld zł i trafi do co najmniej pół miliona potrzebujących Polaków.

## Rosja ostrzega Izrael. Szef NATO wzywa do przedłużenia zawieszenia broni
 - [https://businessinsider.com.pl/wiadomosci/rosja-ostrzega-izrael-szef-nato-wzywa-do-przedluzenia-zawieszenia-broni/hdw84hd](https://businessinsider.com.pl/wiadomosci/rosja-ostrzega-izrael-szef-nato-wzywa-do-przedluzenia-zawieszenia-broni/hdw84hd)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T13:15:00+00:00

Rosja ostrzega Izrael przed ponowną ofensywą w Strefie Gazy — podaje "Financial Times". Według gazety Jurij Uszakow, doradca prezydenta Rosji Władimira Putina ds. polityki zagranicznej, stwierdził, że "nawet wyeliminowanie przywództwa Hamasu, nawet zlanie Strefy Gazy krwią raczej nie zapewni bezpieczeństwa Izraelowi".

## Nie żyje słynny pisarz z Gdańska. Miał 66 lat
 - [https://businessinsider.com.pl/wiadomosci/nie-zyje-slynny-pisarz-z-gdanska-mial-66-lat/95dp7k2](https://businessinsider.com.pl/wiadomosci/nie-zyje-slynny-pisarz-z-gdanska-mial-66-lat/95dp7k2)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T13:13:15+00:00

Nie żyje znany pisarz, poeta i wykładowca Paweł Huelle. Informacje o jego śmierci rodzina przekazała prezydent Gdańska.

## Zaostrza się protest kierowców. Blokada na granicy z Ukrainą potrwa przez całą dobę
 - [https://businessinsider.com.pl/gospodarka/protest-polskich-kierowcow-ciezarowek-i-rolnikow-medyka-blokowana-cala-dobe/4vst4nx](https://businessinsider.com.pl/gospodarka/protest-polskich-kierowcow-ciezarowek-i-rolnikow-medyka-blokowana-cala-dobe/4vst4nx)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T13:06:37+00:00

Polscy kierowcy ciężarówek i rolnicy rozpoczęli w poniedziałek całodobową blokadę dostępu do przejścia granicznego w Medyce, jednego z najbardziej ruchliwych przejść z Ukrainą — donosi Reuters. Przedłuża się i intensyfikuje w ten sposób protest, w wyniku którego tysiące ciężarówek utknęło na wiele dni w ciągnących się kilometrami kolejkach.

## Sprzedali domy, aby ruszyć w podróż życia. 3-letni rejs odwołany w ostatniej chwili
 - [https://businessinsider.com.pl/lifestyle/podroze/3-letni-rejs-odwolany-w-ostatniej-chwili-nie-mamy-gdzie-mieszkac/k2z3c2w](https://businessinsider.com.pl/lifestyle/podroze/3-letni-rejs-odwolany-w-ostatniej-chwili-nie-mamy-gdzie-mieszkac/k2z3c2w)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T12:42:37+00:00

To miała być przygoda życia — ponad 300 portów w 135 krajach. Niektórzy sprzedali domy, aby zapłacić za bilet na 3-letni rejs dookoła świata. Na kilka dni przed startem organizator odwołał podróż, bo... nie było go stać na zakup statku. "Przez następne trzy lata miałam prowadzić niezwykłe życie, a teraz nie mam nic" — powiedziała niedoszła pasażerka.

## Skok PiS na media publiczne. Będą zmiany w statutach spółek
 - [https://businessinsider.com.pl/biznes/skok-pis-na-media-publiczne-beda-zmiany-w-statutach-spolek/0g5phgn](https://businessinsider.com.pl/biznes/skok-pis-na-media-publiczne-beda-zmiany-w-statutach-spolek/0g5phgn)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T12:40:24+00:00

Rada Mediów Narodowych zgodziła się w poniedziałek na dokonanie zmian w statutach TVP, Polskiego Radia i PAP — dowiedziała się PAP. Informacje te potwierdził przewodniczący RMN Krzysztof Czabański. Zgodnie ze zmianami "w razie otwarcia likwidacji likwidatorami są wszyscy członkowie zarządu oraz kierownik komórki organizacyjnej spółki zajmującej się obsługą prawną".

## Menadżer od L4: nowy sposób dyscyplinowania pracowników. Związki zawodowe protestują
 - [https://businessinsider.com.pl/praca/menadzer-od-l4-nowy-sposob-dyscyplinowania-pracownikow/fsekfkh](https://businessinsider.com.pl/praca/menadzer-od-l4-nowy-sposob-dyscyplinowania-pracownikow/fsekfkh)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T12:39:29+00:00

Niektóre firmy zdecydowały się wprowadzić do swojej organizacji pracowniczej nowe stanowisko: menadżer od L4. Specjaliści mieliby zajmować się zarządzaniem absencją chorobową osób zatrudnionych. Związki zawodowe bardzo nieprzyjaźnie podchodzą do nowego pomysłu.

## ZUS ostrzega przed fałszywym wnioskiem. Sprawa dotyczy podwyżki 500 plus
 - [https://businessinsider.com.pl/finanse/wyrownanie-swiadczenia-500-plus-do-800-zl-zus-ostrzega-przed-falszerzami/1fg6q6y](https://businessinsider.com.pl/finanse/wyrownanie-swiadczenia-500-plus-do-800-zl-zus-ostrzega-przed-falszerzami/1fg6q6y)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T12:38:27+00:00

W internecie krąży informacja, że możliwe jest osiągnięcie wyrównania świadczenia 500 plus do kwoty 800 zł za okres od sierpnia 2023 r. do grudnia 2023 r. Uwaga: Zakład Ubezpieczeń Społecznych ostrzega, że to fałszywe doniesienia.

## Trzy powody, dla których państwa na całym świecie chcą odejść od dolara
 - [https://businessinsider.com.pl/wiadomosci/trzy-powody-dla-ktorych-panstwa-na-calym-swiecie-chca-odejsc-od-dolara/4649d3p](https://businessinsider.com.pl/wiadomosci/trzy-powody-dla-ktorych-panstwa-na-calym-swiecie-chca-odejsc-od-dolara/4649d3p)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T12:34:59+00:00

Od dziesięcioleci dolar amerykański pozostaje światową walutą rezerwową, ale jego dominacja słabnie. Sankcje nałożone na Rosję skłoniły wiele innych państw do poszukiwania alternatywnych walut na potrzeby handlu. Powodów dedolaryzacji jest jednak więcej.

## Hakerzy ujawnili dane medyczne tysięcy Polaków. Włamano się do wielkiej sieci laboratoriów
 - [https://businessinsider.com.pl/wiadomosci/hakerzy-ujawnili-dane-medyczne-tysiecy-polakow-wlamano-sie-do-laboratoriow/fw7fe6n](https://businessinsider.com.pl/wiadomosci/hakerzy-ujawnili-dane-medyczne-tysiecy-polakow-wlamano-sie-do-laboratoriow/fw7fe6n)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T12:30:42+00:00

Jak ujawnia serwis Zaufana Trzecia Strona, niedawno doszło do włamania do sieci laboratoriów ALAB — jednego z największych tego typu podmiotów w Polsce. W efekcie do internetu trafiły dane medyczne tysięcy Polaków.

## Sztuczna inteligencja przepyta kandydata do pracy. Tak technologie wpłyną na HR
 - [https://businessinsider.com.pl/prawo/praca/sztuczna-inteligencja-przepyta-kandydata-do-pracy-tak-technologie-wplyna-na-hr/zl7wye5](https://businessinsider.com.pl/prawo/praca/sztuczna-inteligencja-przepyta-kandydata-do-pracy-tak-technologie-wplyna-na-hr/zl7wye5)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T12:18:54+00:00

Sztuczna inteligencja zintegrowana z chatbotem będzie komunikować się z kandydatami do zatrudnienia i np. dopyta ich o kwalifikacje lub oczekiwania płacowe. Takie rozwiązania będą coraz powszechniejsze w przyszłości. Z raportu Polskiego Forum HR wynika, że ponad połowa polskich przedsiębiorców chce wykorzystywać nowoczesne technologie, w tym sztuczną inteligencję, przy rekrutacji do pracy.

## Będzie kontrola NIK w PARP. "Niepokojące doniesienia"
 - [https://businessinsider.com.pl/wiadomosci/najwyzsza-izba-kontroli-zapowiada-kontrole-w-parp-niepokojace-doniesienia/92ppe6g](https://businessinsider.com.pl/wiadomosci/najwyzsza-izba-kontroli-zapowiada-kontrole-w-parp-niepokojace-doniesienia/92ppe6g)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T12:06:41+00:00

Najwyższa Izba Kontroli zapowiedziała kontrolę w Polskiej Agencji Rozwoju Przedsiębiorczości. Najprawdopodobniej chodzi o kontrowersje związane z przyznawaniem dotacji unijnych w ramach konkursu "Ścieżka Smart". Posłowie Koalicji Obywatelskiej nazwali ten proces "ostatnim skokiem PiS na dotacje".

## Polski producent AGD przedstawi nową strategię. Na razie odczuwa dekoniunkturę i broni się przed stratą
 - [https://businessinsider.com.pl/biznes/amica-odczuwa-dekoniunkture-i-broni-sie-przed-strata-ale-liczy-na-poprawe/fgyj90v](https://businessinsider.com.pl/biznes/amica-odczuwa-dekoniunkture-i-broni-sie-przed-strata-ale-liczy-na-poprawe/fgyj90v)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T11:56:30+00:00

Amica spodziewa się w 2024 r. poprawy koniunktury w AGD i wyników grupy, ale na razie odczuwa spowolnienie gospodarcze w Europie. Mimo gorszej kondycji konsumentów spodziewa się dodatniego wyniku netto w 2023 r. Pod koniec stycznia grupa planuje przedstawić nową, dziesięcioletnią strategię.

## PiS zabetonuje media publiczne? Minister Gliński ma propozycję
 - [https://businessinsider.com.pl/wiadomosci/pis-zabetonuje-media-publiczne-minister-glinski-ma-propozycje/zjjtfqq](https://businessinsider.com.pl/wiadomosci/pis-zabetonuje-media-publiczne-minister-glinski-ma-propozycje/zjjtfqq)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T11:44:33+00:00

Minister kultury Piotr Gliński znalazł sposób na to, jak nie utracić kontroli nad mediami publicznymi po zmianie rządu. Jak dowiedział się Onet, Gliński wystąpił do Rady Mediów Narodowych z wnioskiem o wyrażenie zgody na zmiany w statutach Telewizji Polskiej, Polskiego Radia i Polskiej Agencji Prasowej. Na czym ma polegać zmiana? W razie likwidacji tych spółek likwidatorami mają być członkowie ich zarządów.

## Konfederacja ma inne pomysły na komisje śledcze. Energetyka, COVID-19 i żywność
 - [https://businessinsider.com.pl/gospodarka/konfederacja-ma-inne-pomysly-na-komisje-sledcze-energetyka-covid-19-i-zywnosc/6fy2bgq](https://businessinsider.com.pl/gospodarka/konfederacja-ma-inne-pomysly-na-komisje-sledcze-energetyka-covid-19-i-zywnosc/6fy2bgq)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T11:16:26+00:00

Konfederacja przygotowała trzy projekty wniosków o komisje śledcze — dot. polityki energetycznej, do zbadania przyczyn i skutków niekontrolowanego importu żywności z Ukrainy oraz ds. potencjalnych nieprawidłowości związanych z polityką covidową — poinformowali w poniedziałek politycy ugrupowania.

## Młodzi nie chcą randkować w Internecie. Tinder zniszczył rynek miłosny
 - [https://businessinsider.com.pl/lifestyle/rozrywka/mlodzi-nie-chca-randkowac-w-internecie-tinder-zniszczyl-rynek-milosny/wnh3pqr](https://businessinsider.com.pl/lifestyle/rozrywka/mlodzi-nie-chca-randkowac-w-internecie-tinder-zniszczyl-rynek-milosny/wnh3pqr)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T11:03:40+00:00

Czterech na pięciu studentów w USA praktycznie nie korzysta z aplikacji randkowych — wynika z najnowszego badania. "Aplikacje zrujnowały scenę randkową i pewność siebie wielu osób w moim wieku" – powiedziała jedna ze studentek.

## Banki będą więcej zarabiać. Żniwa dla branży mogą się wydłużyć
 - [https://businessinsider.com.pl/finanse/banki-beda-wiecej-zarabiac-zniwa-dla-branzy-moga-sie-wydluzyc/wyg1mkq](https://businessinsider.com.pl/finanse/banki-beda-wiecej-zarabiac-zniwa-dla-branzy-moga-sie-wydluzyc/wyg1mkq)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T11:02:39+00:00

Żniwa dla banków mogą być dłuższe, niż oczekiwano, a negatywne skutki spowolnienia gospodarczego raczej nie będą tak duże, jak się obawiano. Dodatkowo rezultaty banków za III kwartał były lepsze od prognoz, a uchwalenie wakacji kredytowych opóźnia się — ocenili analitycy Trigon Domu Maklerskiego, którzy podnieśli prognozy zysku netto banków na lata 2023-2025.

## Taka wygrana w Lotto nie zdarza się często. Majątek na koncie zwycięzcy
 - [https://businessinsider.com.pl/poradnik-finansowy/nieczesta-wygrana-w-lotto-majatek-na-koncie-zwyciezcy/8svwctg](https://businessinsider.com.pl/poradnik-finansowy/nieczesta-wygrana-w-lotto-majatek-na-koncie-zwyciezcy/8svwctg)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T11:02:19+00:00

Sześć poprawnie wytypowanych liczb i brak innych osób, które wybrały tę samą kombinację — to przepis na rekordową wygraną w Lotto. Taka właśnie miała miejsce po losowaniu 25 października, w którym szczęśliwcem został pewien mieszkaniec Radzionkowa. Na jego konto wpłynie prawdziwa fortuna!

## Bill Gates prognozuje, jak AI zmieni naszą pracę. Wielu się to spodoba
 - [https://businessinsider.com.pl/technologie/gates-prognozuje-jak-ai-zmieni-nasza-prace-wielu-sie-to-spodoba/h8w8f3r](https://businessinsider.com.pl/technologie/gates-prognozuje-jak-ai-zmieni-nasza-prace-wielu-sie-to-spodoba/h8w8f3r)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T10:52:25+00:00

Rozwój sztucznej inteligencji (AI) to wielka niewiadoma dla naszej przyszłości i wielu ekspertów wieszczy, że może to oznaczać masowe zwolnienia. Bill Gates do sprawy podchodzi dużo bardziej optymistycznie.

## Kopalnie potrzebują pilnie miliardów. Rząd PiS szykuje poprawkę do projektu budżetu państwa
 - [https://businessinsider.com.pl/biznes/kopalnie-potrzebuja-pilnie-miliardow-rzad-pis-szykuje-poprawke-do-projektu-budzetu/37pfbyz](https://businessinsider.com.pl/biznes/kopalnie-potrzebuja-pilnie-miliardow-rzad-pis-szykuje-poprawke-do-projektu-budzetu/37pfbyz)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T10:52:09+00:00

Polskie kopalnie potrzebują finansowej kroplówki od państwa. Wiceminister aktywów państwowych Marek Wesoły poinformował właśnie, że rząd przygotowuje autopoprawkę do projektu budżetu państwa, dzięki której obligacje o wartości 7 mld zł zostaną przeznaczone na pomoc dla górniczych firm. Tylko do Polskiej Grupy Górniczej popłynie 5,5 mld zł, co potwierdza nasze wcześniejsze ustalenia.

## Co Elon Musk, Bill Gates i 12 innych liderów biznesu myślą o sztucznej inteligencji i ChatGPT?
 - [https://businessinsider.com.pl/technologie/od-ekscytacji-po-wizje-zaglady-miliardzerzy-i-liderzy-biznesu-o-chatgpt/r5zbydb](https://businessinsider.com.pl/technologie/od-ekscytacji-po-wizje-zaglady-miliardzerzy-i-liderzy-biznesu-o-chatgpt/r5zbydb)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T10:48:00+00:00

Narzędzia sztucznej inteligencji (AI) szturmem zdobyły świat. Liderzy biznesu komentują, jak AI wpłynie na nasze życie. Ich podejścia bywają odmienne.

## Pięć priorytetów na pierwsze 100 dni rządu. Tego oczekuje rynek mieszkaniowy
 - [https://businessinsider.com.pl/prawo/kryzys-mieszkaniowy-co-rzad-powinien-zrobic-w-pierwszych-100-dniach/9rvghx4](https://businessinsider.com.pl/prawo/kryzys-mieszkaniowy-co-rzad-powinien-zrobic-w-pierwszych-100-dniach/9rvghx4)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T10:30:00+00:00

Opracowanie spójnej, długofalowej i kompleksowej strategii polityki mieszkaniowej na najbliższą kadencję. To podstawowy postulat Platformy Mieszkaniowo Budowlanej Pracodawców RP. Ponadto branża, chce zmian w specustawie, stawkach amortyzacji i odwołaniach od decyzji o pozwoleniu na budowę.

## W Polsce rosły płace jak (prawie) nigdzie. Jesteśmy w czołówce światowego zestawienia
 - [https://businessinsider.com.pl/gospodarka/w-polsce-rosly-place-jak-prawie-nigdzie-swiatowa-czolowka-ranking/7drfxt6](https://businessinsider.com.pl/gospodarka/w-polsce-rosly-place-jak-prawie-nigdzie-swiatowa-czolowka-ranking/7drfxt6)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T10:15:11+00:00

Brytyjska firma analityczna Utility Bidder przygotowała zestawienie państw OECD z największym wzrostem płac w ostatnich latach. Okazuje się, że w niewielu miejscach na świecie rosły one tak szybko jak w Polsce.

## Polak inwestor. W co inwestują: złoto, bitcoin, a może w naukę?
 - [https://businessinsider.com.pl/gospodarka/w-co-polacy-inwestuja-najchetniej-jedna-odpowiedz-zaskoczy/llvt6zd](https://businessinsider.com.pl/gospodarka/w-co-polacy-inwestuja-najchetniej-jedna-odpowiedz-zaskoczy/llvt6zd)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T10:15:08+00:00

Kim jest Polak inwestor? Czy w ogóle jesteśmy narodem, który stara się inwestować nadwyżki finansowe w jakiś konkretny cel? Niedawno powstał portret Polaków w tym temacie, a wniosek może wiele osób zaskoczyć.

## ZUS zmienia limity zarobkowe dla emerytów i rencistów. Sprawdź, ile możesz dorobić
 - [https://businessinsider.com.pl/finanse/zus-zmienia-limity-dla-emerytow-i-rencistow-sprawdz-ile-mozesz-dorobic/8zbs3kf](https://businessinsider.com.pl/finanse/zus-zmienia-limity-dla-emerytow-i-rencistow-sprawdz-ile-mozesz-dorobic/8zbs3kf)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T09:53:12+00:00

Emeryci i renciści mogą pracować i dorabiać, ale niektórych z nich obowiązują limity zarobkowe. Gdy je przekroczą, ZUS może zmniejszyć lub zawiesić wypłacane świadczenie. Od 1 grudnia limity będą wyższe.

## Nowe miejsca postojowe przed dyskontami. Zablokujesz? Kara 3 tys. zł
 - [https://businessinsider.com.pl/poradnik-finansowy/biedronka-i-lidl-maja-nowe-miejsca-postojowe-zablokujesz-kara-3-tys-zl/n1j659q](https://businessinsider.com.pl/poradnik-finansowy/biedronka-i-lidl-maja-nowe-miejsca-postojowe-zablokujesz-kara-3-tys-zl/n1j659q)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T09:52:21+00:00

Przybywa obostrzeń dotyczących parkowania pod popularnymi sieciami handlowymi. Standardem stały się bilety uprawniające do bezpłatnego postoju ograniczonego czasowo. Teraz kierowcy muszą uważać na nowe miejsca wyposażone w infrastrukturę do ładowania pojazdów.

## Koniec czeskiego najazdu na Polskę. Zakupy u nas przestają się opłacać
 - [https://businessinsider.com.pl/wiadomosci/koniec-czeskiego-najazdu-na-polske-zakupy-u-nas-przestaja-sie-oplacac/66p2kmc](https://businessinsider.com.pl/wiadomosci/koniec-czeskiego-najazdu-na-polske-zakupy-u-nas-przestaja-sie-oplacac/66p2kmc)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T09:27:02+00:00

W ostatnich miesiącach Polska była dla Czechów zakupowym rajem. Nie dość, że w sklepach było taniej, to i stacje paliw kusiły cenami. Te czasy już się jednak kończą.

## Szykuje się boom inwestycyjny w Polsce. Skąd wziąć setki miliardów?
 - [https://businessinsider.com.pl/gospodarka/ogromna-skala-inwestycji-w-polska-energetyke-jest-luka-finansowania/mbx19h0](https://businessinsider.com.pl/gospodarka/ogromna-skala-inwestycji-w-polska-energetyke-jest-luka-finansowania/mbx19h0)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T09:11:30+00:00

Rząd prezentuje scenariusz wzrostu produkcji energii elektrycznej z OZE, do czego konieczne będzie też odpowiednie rozbudowanie sieci przesyłowej i dystrybucyjnej. Skala inwestycji jest ogromna, bo łącznie do 2040 r. wydatki na te cele mogą wynieść 1226 mld zł, co stanowi 47 proc. PKB z 2022 r. Kłopotem może okazać się znalezienie finansowania tych projektów, ale nawet w razie mniejszej skali rozbudowy, rozpoczęcie tego procesu może w 2025 r. przynieść boom inwestycyjny — ocenili ekonomiści Credit Agricole Banku Polska.

## Nawet 2 tys. dla pracownika bez podatku. Od 1 stycznia będzie mniej
 - [https://businessinsider.com.pl/praca/nawet-2-tys-dla-pracownika-bez-podatku-od-1-stycznia-bedzie-mniej/e72j2e9](https://businessinsider.com.pl/praca/nawet-2-tys-dla-pracownika-bez-podatku-od-1-stycznia-bedzie-mniej/e72j2e9)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T09:00:24+00:00

Jeszcze tylko do końca 2023 r. pracownicy mają możliwość skorzystania z podwyższonego do 2 tys. limitu zwolnienia w PIT. Chodzi o sumę benefitów, bonusów i świadczeń, które finansowane są z Zakładowego Funduszu Świadczeń Socjalnych. Od 1 stycznia kwota zostanie drastycznie zmniejszona.

## Od 16 lat jestem CEO. Oto najważniejsza rada dotycząca kariery, jakiej mogę udzielić [KOMENTARZ]
 - [https://businessinsider.com.pl/twoje-pieniadze/praca/od-16-lat-jestem-ceo-oto-najwazniejsza-rada-dotyczaca-kariery-jaka-mam/03elykj](https://businessinsider.com.pl/twoje-pieniadze/praca/od-16-lat-jestem-ceo-oto-najwazniejsza-rada-dotyczaca-kariery-jaka-mam/03elykj)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T09:00:00+00:00

Henry Blodget, współzałożyciel portalu Business Insider, który w listopadzie zrezygnował z funkcji CEO, zdecydował się na dzielenie swojej wiedzy i doświadczenia z rynku pracy poprzez pisanie felietonów. W swoich kolumnach z poradami, Blodget radzi, jak odkryć swoje mocne strony i zdobyć posadę marzeń.

## Oto nowe "rządowe domy". Projekty można pobrać za darmo
 - [https://businessinsider.com.pl/wiadomosci/oto-nowe-rzadowe-domy-projekty-mozna-pobrac-za-darmo/4q7rcje](https://businessinsider.com.pl/wiadomosci/oto-nowe-rzadowe-domy-projekty-mozna-pobrac-za-darmo/4q7rcje)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T08:57:18+00:00

Szykując się do budowy domu, nie trzeba już wydawać pieniędzy na jego projekt. To oczywiście pod warunkiem, że skorzysta się z państwowej bazy. Pojawiły się w niej właśnie cztery nowe projekty domów o powierzchniach ok. 120 i ok. 180 m kw.

## COVID-19 uderzył w demografię Europy. Polska w czołówce niechlubnego rankingu
 - [https://businessinsider.com.pl/gospodarka/covid-19-uderzyl-w-demografie-europy-polska-w-czolowce-niechlubnego-rankingu/xrj98cs](https://businessinsider.com.pl/gospodarka/covid-19-uderzyl-w-demografie-europy-polska-w-czolowce-niechlubnego-rankingu/xrj98cs)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T08:46:06+00:00

Eurostat opublikował najnowsze dane o demograficznej sytuacji Europy. Nie napawają optymizmem — w 2021 r. ubyło ponad 250 tys. mieszkańców kontynentu. A Polska jest jednym z najbardziej poszkodowanych państw. W tym roku w Polsce może urodzić się najmniej dzieci od czasów II wojny światowej.

## Kreml wypowiedział wojnę gigantowi internetowemu. Ściga jego rzecznika. "Promowanie terroryzmu"
 - [https://businessinsider.com.pl/wiadomosci/kreml-wypowiedzial-wojne-gigantowi-internetowemu-promowanie-terroryzmu/8wygn40](https://businessinsider.com.pl/wiadomosci/kreml-wypowiedzial-wojne-gigantowi-internetowemu-promowanie-terroryzmu/8wygn40)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T08:36:54+00:00

Andy Stone, specjalista do spraw komunikacji w firmie Meta, do której należą m.in. Facebook, Instagram i WhatsApp, jest poszukiwany przez władze Rosji. Znalazł się na liście ściganych w związku z oskarżeniem o promowanie terroryzmu. W niedzielę ogłosiły to oficjalnie rosyjskie media.

## Branża drży przed nowym rokiem. Pieczywo będzie droższe i gorszej jakości
 - [https://businessinsider.com.pl/wiadomosci/branza-drzy-przed-nowym-rokiem-pieczywo-bedzie-drozsze-i-gorszej-jakosci/v4wg0ck](https://businessinsider.com.pl/wiadomosci/branza-drzy-przed-nowym-rokiem-pieczywo-bedzie-drozsze-i-gorszej-jakosci/v4wg0ck)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T08:34:18+00:00

Sytuacja w branży piekarniczej wciąż jest mocno napięta, a od 2024 r. kilka czynników może mocno wpłynąć na finalne ceny detaliczne. Zdaniem ekspertów należy się tego poważnie obawiać. Podniesienie płacy minimalnej i urealnienie kosztów zakupu paliwa doprowadzi do fali wzrostów. Do tego może jeszcze dojść likwidacja zerowej stawki VAT na żywność oraz odmrożenie cen gazu dla piekarni i cukierni.

## Kurs CHF/PLN 27 listopada 2023 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-chfpln-27-listopada-2023-r/w3zvmcr](https://businessinsider.com.pl/gielda/kursy-walut/kurs-chfpln-27-listopada-2023-r/w3zvmcr)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T08:05:12+00:00

Poznaj szczegółowe zmiany kursu CHF/PLN. Jak kształtuje się kurs złotówki do franka? Jak silna jest waluta, od której zależy wysokość raty kredytowej wielu pożyczkobiorców? Wczoraj kurs franka wynosił 4,52515 zł. O tym, jak kształtuje się on dziś, dowiesz się z tego artykułu. Sprawdź, czy opłaca się wymienić złotówki na franki.

## Kurs GBP/PLN 27 listopada 2023 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-gbppln-27-listopada-2023-r/093cv8t](https://businessinsider.com.pl/gielda/kursy-walut/kurs-gbppln-27-listopada-2023-r/093cv8t)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T08:04:35+00:00

Prezentujemy bieżące notowania kursu waluty GBP oraz zmiany kursu w ujęciu dziennym. Poniżej znajduje się kurs na dzień 27 listopada 2023 - jak zmienił się on w stosunku do złotówki? Wczorajszy kurs wynosił 5,03135 zł. Jeśli chcesz dowiedzieć się, jak sytuacja wygląda dziś, przeczytaj artykuł.

## Kurs TRY/PLN 27 listopada 2023 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-trypln-27-listopada-2023-r/nvw2tse](https://businessinsider.com.pl/gielda/kursy-walut/kurs-trypln-27-listopada-2023-r/nvw2tse)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T08:04:00+00:00

Oto bieżący kurs liry tureckiej. Poznaj wahania waluty Turcji w ujęciu zmiany dziennej, a także jak zmienił się jej kurs w odniesieniu tygodniowym. Aktualny kurs liry warto poznać przed wyjazdem na wakacje do jednego z tureckich kurortów.

## Kurs USD/PLN 27 listopada 2023 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-usdpln-27-listopada-2023-r/pj2fmfh](https://businessinsider.com.pl/gielda/kursy-walut/kurs-usdpln-27-listopada-2023-r/pj2fmfh)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T08:02:57+00:00

Oto aktualny kurs waluty USD na dzień 27 listopada 2023. Dolar jest jedną z głównych walut, w których przeprowadzane są transakcje na światowych rynkach, od jego ceny zależą surowce takie jak ropa, mające wpływ na nasze codzienne życie. Z tego powodu warto wiedzieć, po ile obecnie można wymienić amerykańską walutę oraz jak zmienia się wartość dolara w dłuższej perspektywie. Wczoraj kurs USD wynosił 3,9915 zł.

## Kurs NOK/PLN 27 listopada 2023 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-nokpln-27-listopada-2023-r/x9w2953](https://businessinsider.com.pl/gielda/kursy-walut/kurs-nokpln-27-listopada-2023-r/x9w2953)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T08:02:17+00:00

Jak zmienił się kurs korony norweskiej od wczoraj? Czy złoty słabnie, czy może umacnia się względem waluty Norwegów? To ważna informacja dla wszystkich, którzy aktualnie pracują lub wybierają się do Skandynawii. Sprawdź, jak dziś prezentuje się kurs NOK.

## Google usunie stare dane z Gmaila i zdjęcia. Oto jak możesz temu zapobiec
 - [https://businessinsider.com.pl/technologie/google-usunie-stare-dane-z-gmaila-i-zdjecia-oto-jak-mozesz-temu-zapobiec/3gv8nxe](https://businessinsider.com.pl/technologie/google-usunie-stare-dane-z-gmaila-i-zdjecia-oto-jak-mozesz-temu-zapobiec/3gv8nxe)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T08:01:20+00:00

Google zapowiedziało, że w grudniu rozpocznie usuwanie danych z nieaktywnych kont użytkowników. Robi to ze względów bezpieczeństwa. Można się jednak w prosty sposób uchronić przed utratą cennych plików.

## Z rządu PiS do zarządu NBP. Do Glapińskiego dołączy polityk "do zadań specjalnych"
 - [https://businessinsider.com.pl/wiadomosci/z-rzadu-pis-do-zarzadu-nbp-to-polityk-do-zadan-specjalnych/18psvy3](https://businessinsider.com.pl/wiadomosci/z-rzadu-pis-do-zarzadu-nbp-to-polityk-do-zadan-specjalnych/18psvy3)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T07:15:21+00:00

Zgodnie ze źródłami Onetu, już wkrótce ma dojść do zmian w składzie zarządu NBP. Do instytucji trafi bowiem Artur Soboń, obecnie wiceminister finansów. Na dokooptowanie polityka odpowiedzialnego niegdyś za naprawę Polskiego Ładu miał już zgodzić się prezydent Andrzej Duda.

## Doradcy Glapińskiego zasypani milionami. Kim są? Nie wiadomo
 - [https://businessinsider.com.pl/wiadomosci/doradcy-glapinskiego-zasypani-milionami-kim-sa-nie-wiadomo/br75kv2](https://businessinsider.com.pl/wiadomosci/doradcy-glapinskiego-zasypani-milionami-kim-sa-nie-wiadomo/br75kv2)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T06:44:50+00:00

Jak donosi "Rzeczpospolita", w ubiegłym roku doradcy prezesa NBP Adama Glapińskiego zarobili nawet 4,6 mln zł. Narodowy Bank Polski odmówił jednak ujawnienia ich nazwisk.

## Niemal 400 mikrokawalerek tuż za granicami Warszawy. Nigdzie nie pada słowo "mieszkanie"
 - [https://businessinsider.com.pl/wiadomosci/niemal-400-mikrokawalerek-tuz-za-granicami-warszawy-nigdzie-nie-pada-slowo-mieszkanie/jh19cfs](https://businessinsider.com.pl/wiadomosci/niemal-400-mikrokawalerek-tuz-za-granicami-warszawy-nigdzie-nie-pada-slowo-mieszkanie/jh19cfs)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T06:43:57+00:00

Metraże zaczynające się od 17 m kw., w sumie aż 379 mikrokawalerek ulokowanych w sześciu niewysokich blokach — tak ma wyglądać inwestycja tuż przy Alejach Jerozolimskich w Warszawie, na którą zwraca uwagę portal warszawa.wyborcza.pl. Co ciekawe, deweloper nie używa w kontekście lokali słowa "mieszkanie".

## Rodzinna piekarnia działała od lat. Dobiły ją podwyżki cen, "rachunek za gaz to 8 tys. zł"
 - [https://businessinsider.com.pl/gospodarka/rodzinna-piekarnia-dzialala-od-lat-rachunek-za-gaz-to-8-tys-zl/jbw3gxy](https://businessinsider.com.pl/gospodarka/rodzinna-piekarnia-dzialala-od-lat-rachunek-za-gaz-to-8-tys-zl/jbw3gxy)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T06:30:00+00:00

Rodzinna piekarnia w Katowicach, która działała nieprzerwanie od 1945 roku, zdecydowała się na zamknięcie. Właściciele ogłosili, że listopad będzie ostatnim miesiącem funkcjonowania zakładu. Decyzję o zamknięciu piekarni przyspieszyły ostatnie podwyżki cen.

## Przecieki z nowego rządu Mateusza Morawieckiego [LISTA NAZWISK]
 - [https://businessinsider.com.pl/gospodarka/nowy-rzad-mateusza-morawieckiego-znamy-nazwiska/q4y5wbx](https://businessinsider.com.pl/gospodarka/nowy-rzad-mateusza-morawieckiego-znamy-nazwiska/q4y5wbx)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T06:18:20+00:00

Onet dowiedział się, kto znajdzie się w składzie nowego rządu Mateusza Morawieckiego. Mają do niego wejść głównie bliscy współpracownicy urzędującego premiera. Zabraknie natomiast kilku "znanych twarzy" PiS.

## Wskaźnik zatrudnienia kobiet pierwszy raz przekroczył w Polsce 50 proc.
 - [https://businessinsider.com.pl/gospodarka/wskaznik-zatrudnienia-kobiet-pierwszy-raz-przekroczyl-w-polsce-50-proc/0vpryy5](https://businessinsider.com.pl/gospodarka/wskaznik-zatrudnienia-kobiet-pierwszy-raz-przekroczyl-w-polsce-50-proc/0vpryy5)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T06:04:04+00:00

Aktywność zawodowa w Polsce bije rekordy, zwłaszcza w przypadku kobiet, rekordy biją też wpływy z niektórych podatków do budżetu. Mamy obniżki cen paliw na stacjach i kolejna dobrą prognozę dla naszego PKB na przyszły rok. A Niemcy powoli zaczynają dostrzegać, że limitu długu przynoszą ich gospodarce więcej szkody, niż pożytku. Oto pięć najciekawszych wydarzeń w gospodarce teraz.

## Polacy po stronie nowej większości czy prezydenta? Nowy sondaż
 - [https://businessinsider.com.pl/gospodarka/polacy-po-stronie-nowej-wiekszosci-czy-prezydenta-nowy-sondaz/wd9k3vl](https://businessinsider.com.pl/gospodarka/polacy-po-stronie-nowej-wiekszosci-czy-prezydenta-nowy-sondaz/wd9k3vl)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T05:49:47+00:00

58,8 proc. Polaków źle ocenia prezydenta, a dobrze jedynie 32,5. Tylko 8,8 proc. respondentów nie ma zdania w sprawie oceny działania prezydenta Andrzeja Dudy wobec nowej większości parlamentarnej — wynika z sondażu IBRiS dla "Rzeczpospolitej".

## We wtorek Sejm wznowi obrady. Oto pięć najważniejszych spraw, którymi się zajmie
 - [https://businessinsider.com.pl/prawo/czym-zajmie-sie-sejm-handel-w-wigilie-komisje-sledcze-lex-tusk/l75n7q5](https://businessinsider.com.pl/prawo/czym-zajmie-sie-sejm-handel-w-wigilie-komisje-sledcze-lex-tusk/l75n7q5)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T05:48:25+00:00

Dawno tak długo nie trwało pierwsze posiedzenie Sejmu. Posłowie przysięgę złożyli w poniedziałek 13 listopada, potem obradowali jeszcze 14, 21 i 22 listopada, zbiorą się ponownie 28 i 29 listopada, a to formalnie wciąż to samo posiedzenie. Czym parlamentarzyści zajmą się tym razem? Między innymi powołaniem komisji śledczych, odwołaniem członków komisji do zbadania wpływów rosyjskich, ale też zakazem handlu w Wigilię.

## Adam Glapiński stanie przed Trybunałem Stanu? "Opozycja stawia jeszcze jeden zarzut"
 - [https://businessinsider.com.pl/gospodarka/adam-glapinski-przed-trybunalem-stanu-opozycja-stawia-jeszcze-jeden-zarzut/wehjhlj](https://businessinsider.com.pl/gospodarka/adam-glapinski-przed-trybunalem-stanu-opozycja-stawia-jeszcze-jeden-zarzut/wehjhlj)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T05:38:58+00:00

"Adam Glapiński coraz bliżej Trybunału Stanu" — opisuje dziennik "Rzeczpospolita". I wskazuje, że jego obrońcy odwołują się do dwóch zarzutów formułowanych pod adresem prezesa Narodowego Banku Polskiego. Tymczasem zastrzeżeń jest więcej.

## Pieniądze na odchodne. Ile dostanie premier, a ile ministrowie?
 - [https://businessinsider.com.pl/prawo/zmiana-rzadu-pieniadze-na-odchodne-ile-dostanie-morawiecki-ile-kaczynski-a-ile/e2qq1lg](https://businessinsider.com.pl/prawo/zmiana-rzadu-pieniadze-na-odchodne-ile-dostanie-morawiecki-ile-kaczynski-a-ile/e2qq1lg)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T05:35:22+00:00

W poniedziałek mamy poznać skład nowego gabinetu Mateusza Morawieckiego. Tego dnia z władzą pożegnają się więc ci, którzy nie zdecydują się przyjąć w nim teki ministra, Jest niemal pewne, że wygłoszeniu exposé nowy gabinet nie uzyska wotum zaufania w Sejmie. W efekcie z władzą będą musieli pożegnać się i ci nowi. Czy wszyscy dostaną odprawy? Wyjaśniamy.

## Potrzebna pilna decyzja w sprawie cen ciepła. "Rachunki mogą wzrosnąć nawet o 100 proc."
 - [https://businessinsider.com.pl/poradnik-finansowy/potrzebna-pilna-decyzja-w-sprawie-cen-ciepla-rachunki-moga-wzrosnac-nawet-o-100-proc/fchg5cd](https://businessinsider.com.pl/poradnik-finansowy/potrzebna-pilna-decyzja-w-sprawie-cen-ciepla-rachunki-moga-wzrosnac-nawet-o-100-proc/fchg5cd)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T05:23:41+00:00

Ceny węgla i gazu spadają, ale nie na tyle, by uchronić Polaków przed podwyżkami cen ciepła płynącego z miejskich sieci. — W przyszłym roku sytuacja wielu gospodarstw domowych będzie bardzo trudna. Po wygaśnięciu systemu wsparcia rachunki za ciepło mogą wzrosnąć od 50 proc. do nawet 100 proc. — alarmuje Jacek Szymczak, prezes Izby Gospodarczej Ciepłownictwo Polskie. Proponuje rozwiązania, które ulżą portfelom Polaków tej zimy i w kolejnych latach.

## Wielka zmiana na stacjach paliw. Znika popularne paliwo, oto co już wiemy
 - [https://businessinsider.com.pl/poradnik-finansowy/wielka-zmiana-na-stacjach-paliw-znika-popularne-paliwo-oto-co-juz-wiemy/2s326d7](https://businessinsider.com.pl/poradnik-finansowy/wielka-zmiana-na-stacjach-paliw-znika-popularne-paliwo-oto-co-juz-wiemy/2s326d7)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T05:18:37+00:00

Z początkiem 2024 r. ze wszystkich stacji paliw w Polsce zniknie benzyna 95-oktanowa oznaczana symbolem E5. Zastąpi ją benzyna E10. Oto co już wiemy o zmianie, do której został niewiele ponad miesiąc.

## Fatalne wieści przed świętami. Wydajemy coraz więcej [Koszyk zakupowy Business Insidera i aplikacji PanParagon]
 - [https://businessinsider.com.pl/poradnik-finansowy/fatalne-wiesci-przed-swietami-wydajemy-coraz-wiecej/yknne1y](https://businessinsider.com.pl/poradnik-finansowy/fatalne-wiesci-przed-swietami-wydajemy-coraz-wiecej/yknne1y)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T05:12:00+00:00

Ostatnio nasz koszyk przebił granicę 120 zł. Niestety, jego wartość wciąż idzie w górę. Wzrosty tym razem może dramatyczne nie są, za to drożeje większość artykułów.

## Pierwszy wywiad "nowego" szefa KNF. "Mamy ambitne plany"
 - [https://businessinsider.com.pl/finanse/szef-knf-ma-juz-druga-kadencje-pokazuje-jakie-ma-plany-i-co-bedzie-priorytetem-dla/h2w1ylx](https://businessinsider.com.pl/finanse/szef-knf-ma-juz-druga-kadencje-pokazuje-jakie-ma-plany-i-co-bedzie-priorytetem-dla/h2w1ylx)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T05:05:00+00:00

Komisja Nadzoru Finansowego dalej będzie profesjonalna i obiektywna. Byłoby naiwnością twierdzić, że nadzór finansowy nie ma styku ze światem polityki, ten styk jest naturalny i zrozumiały – mówi w pierwszym wywiadzie po powołaniu na drugą kadencję przewodniczący KNF Jacek Jastrzębski. Dodaje przy tym, że zarówno przepisy krajowe, jak i standardy międzynarodowe dotyczące nadzoru finansowego są skonstruowane w ten sposób, że "jest pewien próg odcięcia".

## Kurs EUR/PLN 27 listopada 2023 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-eurpln-27-listopada-2023-r/9979bcs](https://businessinsider.com.pl/gielda/kursy-walut/kurs-eurpln-27-listopada-2023-r/9979bcs)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-11-27T05:00:01+00:00

Przedstawiamy bieżące notowania kursu waluty EUR oraz zmiany w ujęciu tygodniowym i dzień po dniu na 27 listopada 2023. Pokazujemy, jak zmienia się kurs euro w stosunku do polskiego złotego. Czy nasza waluta obecnie traci? Wczoraj kurs EUR wynosił: 4,369 zł. Wszystkiego dowiesz się z poniższego artykułu.

