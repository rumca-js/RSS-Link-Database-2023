# Source:rp.pl, URL:https://www.rp.pl/rss_main, language:pl-PL

## Ukraina zmienia politykę naboru do wojska. Wyzwanie dla Umerowa
 - [https://www.rp.pl/konflikty-zbrojne/art39478391-ukraina-zmienia-polityke-naboru-do-wojska-wyzwanie-dla-umerowa](https://www.rp.pl/konflikty-zbrojne/art39478391-ukraina-zmienia-polityke-naboru-do-wojska-wyzwanie-dla-umerowa)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T22:47:00+00:00

Rząd ukraiński planuje zmienić swoje praktyki poboru do wojska, chcąc utrzymać zdolność bojową po prawie dwóch latach  wojny z Rosją.

## Szef RMN chce wnioskować o trzy miliardy złotych na "misję" mediów publicznych
 - [https://www.rp.pl/polityka/art39478311-szef-rmn-chce-wnioskowac-o-trzy-miliardy-zlotych-na-misje-mediow-publicznych](https://www.rp.pl/polityka/art39478311-szef-rmn-chce-wnioskowac-o-trzy-miliardy-zlotych-na-misje-mediow-publicznych)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T22:00:00+00:00

Szef Rady Mediów Narodowych Krzysztof Czabański chce zwrócić się z wnioskiem do zaprzysiężonego dziś rządu Mateusza Morawieckiego o największą jak dotąd rekompensatę dla mediów publicznych. Wniosek ma opiewać na ponad trzy miliardy złotych.

## Wyścig zbrojeń: czas na audyt i weryfikację
 - [https://radar.rp.pl/modernizacja-sil-zbrojnych/art39478181-wyscig-zbrojen-czas-na-audyt-i-weryfikacje](https://radar.rp.pl/modernizacja-sil-zbrojnych/art39478181-wyscig-zbrojen-czas-na-audyt-i-weryfikacje)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T20:50:19+00:00

- Audyt i krytyczna ocena efektów zakupowej gorączki przy modernizowaniu armii w ostatnich latach rządów PiS będą w resorcie obrony narodowej nieuchronne – ocenia Janusz Zemke b. wieloletni szef sejmowej komisji obrony i wiceminister ds. zakupów w rządzie Leszka Millera, eurodeputowany kilku kadencji.

## Morawiecki: Polacy zdecydowali, że musimy mieć koalicjanta
 - [https://www.rp.pl/polityka/art39478141-morawiecki-polacy-zdecydowali-ze-musimy-miec-koalicjanta](https://www.rp.pl/polityka/art39478141-morawiecki-polacy-zdecydowali-ze-musimy-miec-koalicjanta)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T20:40:00+00:00

Dlaczego mamy się tylko kłócić, dlaczego mamy się tylko koncentrować na zemście, na igrzyskach?  Rząd PiS oferuje zgodę i bardzo pozytywny program dla wszystkich Polaków - mówił w TVP Info szef zaprzysiężonego dzisiaj rządu, Mateusz Morawiecki.

## Polskie innowacje zmieniają świat
 - [https://www.rp.pl/nauka/art39478291-polskie-innowacje-zmieniaja-swiat](https://www.rp.pl/nauka/art39478291-polskie-innowacje-zmieniaja-swiat)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T20:00:00+00:00

Każda innowacja zmienia świat, w którym żyjemy. W Polsce nie brakuje projektów, które są ważne na globalnej mapie.

## CNN: Rozejm w Strefie Gazy przedłużony
 - [https://www.rp.pl/konflikty-zbrojne/art39477971-cnn-rozejm-w-strefie-gazy-przedluzony](https://www.rp.pl/konflikty-zbrojne/art39477971-cnn-rozejm-w-strefie-gazy-przedluzony)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T19:55:00+00:00

Osiągnięto porozumienie w sprawie przedłużenia rozejmu w Gazie między Izraelem a Hamasem o kolejne dwa dni, oznajmił w poniedziałek rzecznik ministerstwa spraw zagranicznych Kataru Majed Al-Ansari.

## Alumetal, STS, Ciech. Kto jeszcze planuje opuszczenie giełdy
 - [https://www.rp.pl/gielda/art39477731-alumetal-sts-ciech-kto-jeszcze-planuje-opuszczenie-gieldy](https://www.rp.pl/gielda/art39477731-alumetal-sts-ciech-kto-jeszcze-planuje-opuszczenie-gieldy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T19:51:52+00:00

W kolejce do delistingu ustawiają się już kolejne spółki, a chętnych do debiutu na GPW nadal nie widać. Czy w roku 2024 sytuacja się poprawi?

## Bogusław Chrabota: Przyznaliśmy Nagrodę Giedroycia 2023
 - [https://www.rp.pl/komentarze/art39477911-boguslaw-chrabota-przyznalismy-nagrode-giedroycia-2023](https://www.rp.pl/komentarze/art39477911-boguslaw-chrabota-przyznalismy-nagrode-giedroycia-2023)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T19:37:28+00:00

Wśród wyróżnionych nagrodą „Rzeczpospolitej” im. Jerzego Giedroycia są działacze społeczni, pisarze, historycy, politycy z całego regionu. Zawsze, bez wyjątku, ludzie wybitni, patrioci swoich ojczyzn. Jest w nich ten sam dostojny rys. W tym roku wyróżniamy dwóch wybitnych naukowców i społeczników, orędowników polsko-ukraińskich spraw.

## Kto zachwycił, a kto rozczarował. Podsumowanie weekendu na zimowych arenach
 - [https://www.rp.pl/sporty-zimowe/art39477841-kto-zachwycil-a-kto-rozczarowal-podsumowanie-weekendu-na-zimowych-arenach](https://www.rp.pl/sporty-zimowe/art39477841-kto-zachwycil-a-kto-rozczarowal-podsumowanie-weekendu-na-zimowych-arenach)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T19:11:00+00:00

W Ruce zainaugurowano Puchar Świata w narciarstwie klasycznym, w Oestersund zaczął się najważniejszy zimowy cykl w biatlonie, a w USA rozegrano zmagania najlepszych alpejek. Kto ma powody do świętowania, a kto zawiódł.

## Profesor Stanisław Stępień: Polacy i Ukraińcy razem osiągnąć mogą więcej
 - [https://www.rp.pl/kultura/art39469131-profesor-stanislaw-stepien-polacy-i-ukraincy-razem-osiagnac-moga-wiecej](https://www.rp.pl/kultura/art39469131-profesor-stanislaw-stepien-polacy-i-ukraincy-razem-osiagnac-moga-wiecej)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T19:01:15+00:00

- Stworzyliśmy najlepszą w Polsce bibliotekę ukrainoznawczą, poznałem osobiście Jerzego Giedroycia - mówi profesor Stanisław Stępień, dyrektor Południowo-Wschodniego Instytutu Naukowego w Przemyślu, laureat tegorocznej Nagrody im. Giedroycia.

## Fiskus pożonglował wykładnią przepisów, żeby tylko dostać PIT za wyjazd do USA
 - [https://www.rp.pl/podatki/art39477491-fiskus-pozonglowal-wykladnia-przepisow-zeby-tylko-dostac-pit-za-wyjazd-do-usa](https://www.rp.pl/podatki/art39477491-fiskus-pozonglowal-wykladnia-przepisow-zeby-tylko-dostac-pit-za-wyjazd-do-usa)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T18:57:39+00:00

Jeśli wydatki spółki na organizację wycieczki nagrody miały charakter kosztów reprezentacyjnych, których nie można rozliczyć, to u jej uczestników nie powstał przychód z nieodpłatnego świadczenia.

## Jaka kara dla patostreamerów? Prawniczka: najlepsza byłaby resocjalizacja
 - [https://www.rp.pl/prawo-karne/art39474971-jaka-kara-dla-patostreamerow-prawniczka-najlepsza-bylaby-resocjalizacja](https://www.rp.pl/prawo-karne/art39474971-jaka-kara-dla-patostreamerow-prawniczka-najlepsza-bylaby-resocjalizacja)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T18:38:00+00:00

Więzienie w Polsce nikogo nie poprawia. Lepszym pomysłem byłaby więc terapia uzależnień i psychoterapia, a także zakaz publikowania treści w internecie – mówi Agata Bzdyń, radczyni prawna.

## Jacek Nizinkiewicz: Czternastodniowy rząd Morawieckiego zbudowany na kłamstwie
 - [https://www.rp.pl/komentarze/art39475051-jacek-nizinkiewicz-czternastodniowy-rzad-morawieckiego-zbudowany-na-klamstwie](https://www.rp.pl/komentarze/art39475051-jacek-nizinkiewicz-czternastodniowy-rzad-morawieckiego-zbudowany-na-klamstwie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T18:32:17+00:00

Powołaniu nowego rządu PiS towarzyszyły zaskoczenia. Miały być nowe twarze i eksperci. Okazało się, że wróciły stare nazwiska, a ekspertów w nim niewielu. Prezydent z powagą mówił o wyzwaniach stojących przed gabinetem, który nie będzie rządził.

## Sądy chcą, by adwokaci poświadczali, że nie korzystali z AI
 - [https://www.rp.pl/sady-i-trybunaly/art39476681-sady-chca-by-adwokaci-poswiadczali-ze-nie-korzystali-z-ai](https://www.rp.pl/sady-i-trybunaly/art39476681-sady-chca-by-adwokaci-poswiadczali-ze-nie-korzystali-z-ai)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T18:31:00+00:00

Federalny sąd apelacyjny w Nowym Orleanie proponuje wprowadzenie wymogu, aby prawnicy potwierdzali, że albo nie polegali na programach sztucznej inteligencji przy sporządzaniu pism procesowych, albo że każde pismo wygenerowane przez AI zostało sprawdzone przez ludzi pod kątem poprawności.

## Ruszyła konkurencja SWIFT: platforma BRICS Pay
 - [https://www.rp.pl/finanse/art39474981-ruszyla-konkurencja-swift-platforma-brics-pay](https://www.rp.pl/finanse/art39474981-ruszyla-konkurencja-swift-platforma-brics-pay)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T18:14:27+00:00

Pracę rozpoczęła powstała z inicjatywy Kremla platforma BRISC Pay. Ma to być konkurencja dla SWIFT, umożliwiająca wymianę w narodowych walutach. Do platformy przyłączył się już pierwszy zachodni bank - działający głównie na rynkach wschodzących brytyjski Standard Chartered.

## Łakomy dla logistyków rynek żywności w Polsce
 - [https://logistyka.rp.pl/rynek/art39477151-lakomy-dla-logistykow-rynek-zywnosci-w-polsce](https://logistyka.rp.pl/rynek/art39477151-lakomy-dla-logistykow-rynek-zywnosci-w-polsce)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T18:05:33+00:00

Amerykański fundusz Lineage umacnia pozycję w Europie Środkowo-Wschodniej otwierając biuro w Warszawie.

## Giedroyc dał przykład Europie
 - [https://www.rp.pl/kultura/art39476761-giedroyc-dal-przyklad-europie](https://www.rp.pl/kultura/art39476761-giedroyc-dal-przyklad-europie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T18:02:00+00:00

Profesorowie Igor Cependa i Stanisław Stępień są laureatami tegorocznej nagrody przyznawanej przez „Rzeczpospolitą”.

## Nagroda „Rzeczpospolitej” im. Jerzego Giedroycia: Za pogłębianie współpracy polsko-ukraińskiej
 - [https://www.rp.pl/kultura/art39476761-nagroda-rzeczpospolitej-im-jerzego-giedroycia-za-poglebianie-wspolpracy-polsko-ukrainskiej](https://www.rp.pl/kultura/art39476761-nagroda-rzeczpospolitej-im-jerzego-giedroycia-za-poglebianie-wspolpracy-polsko-ukrainskiej)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T18:02:00+00:00

Profesorowie Igor Cependa i Stanisław Stępień są laureatami tegorocznej nagrody przyznawanej przez „Rzeczpospolitą”.

## Profesor Igor Cependa: Przez setki lat walczymy z imperium
 - [https://www.rp.pl/kultura/art39476731-profesor-igor-cependa-przez-setki-lat-walczymy-z-imperium](https://www.rp.pl/kultura/art39476731-profesor-igor-cependa-przez-setki-lat-walczymy-z-imperium)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T17:55:00+00:00

Nikt nie zapomni, jak Polak brał nieznajomego Ukraińca na granicy za rękę i prowadził go do swojego domu – mówi prof. Igor Cependa.

## Profesor Stanisław Stępień: Razem możemy osiągnąć więcej
 - [https://www.rp.pl/kultura/art39476491-profesor-stanislaw-stepien-razem-mozemy-osiagnac-wiecej](https://www.rp.pl/kultura/art39476491-profesor-stanislaw-stepien-razem-mozemy-osiagnac-wiecej)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T17:51:48+00:00

W przybliżaniu Ukraińcom polskiej kultury mamy  ciągle wiele do zrobienia – przekonuje profesor Stanisław Stępień.

## 109 aresztowanych za blokadę największego na świecie portu węglowego
 - [https://www.rp.pl/prawo-dla-ciebie/art39475091-109-aresztowanych-za-blokade-najwiekszego-na-swiecie-portu-weglowego](https://www.rp.pl/prawo-dla-ciebie/art39475091-109-aresztowanych-za-blokade-najwiekszego-na-swiecie-portu-weglowego)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T17:38:50+00:00

Pływali lub korzystali z kajaków, tak aktywiści zablokowali największy na świecie port węglowy, który znajduje się w Australii. Dwudniowa blokada skończyła się aresztem dla 109 osób.

## Złoty znów pokazał moc
 - [https://www.rp.pl/waluty/art39475141-zloty-znow-pokazal-moc](https://www.rp.pl/waluty/art39475141-zloty-znow-pokazal-moc)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T17:28:07+00:00

Nowy tydzień rozpoczął się od istotnego umocnienia złotego, co przełożyło się na kilkugroszowe spadki kursów najważniejszych walut.

## Nie żyje Paweł Huelle. Kolibra lot ostatni
 - [https://www.rp.pl/literatura/art39474931-nie-zyje-pawel-huelle-kolibra-lot-ostatni](https://www.rp.pl/literatura/art39474931-nie-zyje-pawel-huelle-kolibra-lot-ostatni)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T17:18:14+00:00

W swoim domu w Gdańsku zmarł 27 listopada znakomity pisarz, dramaturg, poeta Paweł Huelle. Twórca „Weisera Dawidka” i autor sztuki „Kursk” miał 66 lat.

## Murapol może ruszać z ofertą akcji
 - [https://www.rp.pl/nieruchomosci/art39475121-murapol-moze-ruszac-z-oferta-akcji](https://www.rp.pl/nieruchomosci/art39475121-murapol-moze-ruszac-z-oferta-akcji)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T17:12:59+00:00

Komisja Nadzoru Finansowego zatwierdziła prospekt dewelopera mieszkaniowego.

## Nowe świadczenie z ZUS tylko dla dorosłych niepełnosprawnych. Nawet 3495 zł
 - [https://www.rp.pl/niepelnosprawni/art39474991-nowe-swiadczenie-z-zus-tylko-dla-doroslych-niepelnosprawnych-nawet-3495-zl](https://www.rp.pl/niepelnosprawni/art39474991-nowe-swiadczenie-z-zus-tylko-dla-doroslych-niepelnosprawnych-nawet-3495-zl)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T17:10:47+00:00

Od 1 stycznia 2024 r. dorosłe osoby niepełnosprawne mogą otrzymywać z ZUS świadczenie wspierające. Nie wystarczy jednak mieć orzeczenie o niepełnosprawności. Komisją lekarska wyda osobną decyzję ustalającą poziom potrzeby wsparcia. Wysokość świadczenia zależeć będzie od liczby punktów.

## Korekta zawitała na giełdę w Warszawie
 - [https://www.rp.pl/gielda/art39475101-korekta-zawitala-na-gielde-w-warszawie](https://www.rp.pl/gielda/art39475101-korekta-zawitala-na-gielde-w-warszawie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T17:10:03+00:00

Z początkiem nowego tygodnia inwestorzy handlujący w Warszawie postanowili zrealizować zyski wykorzystując słabość zagranicznych parkietów.

## Nawet 3495 zł z ZUS dla dorosłych niepełnosprawnych już od Nowego Roku
 - [https://www.rp.pl/niepelnosprawni/art39474991-nawet-3495-zl-z-zus-dla-doroslych-niepelnosprawnych-juz-od-nowego-roku](https://www.rp.pl/niepelnosprawni/art39474991-nawet-3495-zl-z-zus-dla-doroslych-niepelnosprawnych-juz-od-nowego-roku)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T17:10:00+00:00

Od 1 stycznia 2024 r. dorosłe osoby niepełnosprawne mogą otrzymywać z ZUS świadczenie wspierające. Nie wystarczy jednak mieć orzeczenie o niepełnosprawności. Komisją lekarska wyda osobną decyzję ustalającą poziom potrzeby wsparcia. Wysokość świadczenia zależeć będzie od liczby punktów.

## Prezydent Andrzej Duda zaprzysiągł "przełomowy" rząd
 - [https://www.rp.pl/polityka/art39475011-prezydent-andrzej-duda-zaprzysiagl-przelomowy-rzad](https://www.rp.pl/polityka/art39475011-prezydent-andrzej-duda-zaprzysiagl-przelomowy-rzad)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T16:44:00+00:00

Dopełniamy politycznego i historycznego, konstytucyjnego zwyczaju, powołując  rząd RP, który jest formowany przez kandydata przedstawionego przez  obóz polityczny, który wygrał wybory parlamentarne – powiedział prezydent Andrzej Duda.

## Nowy rząd Morawieckiego: kto będzie zarządzał finansami i gospodarką
 - [https://www.rp.pl/gospodarka/art39474911-nowy-rzad-morawieckiego-kto-bedzie-zarzadzal-finansami-i-gospodarka](https://www.rp.pl/gospodarka/art39474911-nowy-rzad-morawieckiego-kto-bedzie-zarzadzal-finansami-i-gospodarka)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T16:37:39+00:00

Andrzej Kosztowniak, były prezydent Radomia, będzie ministrem finansów w tymczasowym gabinecie Mateusza Morawieckiego. Nie brakuje innych zaskakujących nominacji.

## Trener kadry polskich sztangistów dla "Rz": Może czas na zmiany w szkoleniu
 - [https://www.rp.pl/inne-sporty/art39474301-trener-kadry-polskich-sztangistow-dla-rz-moze-czas-na-zmiany-w-szkoleniu](https://www.rp.pl/inne-sporty/art39474301-trener-kadry-polskich-sztangistow-dla-rz-moze-czas-na-zmiany-w-szkoleniu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T16:16:27+00:00

Wierzę, że zobaczymy Polaka na pomoście podczas igrzysk olimpijskich w Paryżu, choć faworytem nie będzie - mówi „Rzeczpospolitej” Piotr Wysocki.

## Elon Musk poparł cele Izraela. "Ci, którzy zamierzają mordować, muszą zostać zneutralizowani"
 - [https://www.rp.pl/spoleczenstwo/art39474761-elon-musk-poparl-cele-izraela-ci-ktorzy-zamierzaja-mordowac-musza-zostac-zneutralizowani](https://www.rp.pl/spoleczenstwo/art39474761-elon-musk-poparl-cele-izraela-ci-ktorzy-zamierzaja-mordowac-musza-zostac-zneutralizowani)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T16:07:29+00:00

Elon Musk udzielił wsparcia izraelskiej kampanii przeciwko Hamasowi, mówiąc, że jednym z wyzwań jest powstrzymanie propagandy, która doprowadziła do ataku z 7 października, po którym Izrael rozpoczął bombardowania i operację lądową w Gazie.

## Roman Kuźniar: Izrael-Palestyna – bez dobrego wyjścia, z perspektywą dalszej przemocy
 - [https://www.rp.pl/opinie-polityczno-spoleczne/art39474231-roman-kuzniar-izrael-palestyna-bez-dobrego-wyjscia-z-perspektywa-dalszej-przemocy](https://www.rp.pl/opinie-polityczno-spoleczne/art39474231-roman-kuzniar-izrael-palestyna-bez-dobrego-wyjscia-z-perspektywa-dalszej-przemocy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T15:52:10+00:00

Niektórzy myśląc o perspektywach procesu pokojowego między Izraelem i Palestyną, próbują porównywać te relacje ze stosunkami polsko-niemieckimi po 1945 r. Takie porównania ignorują jednak ważne czynniki kulturowe i religijne różniące obie strony.

## Twórca Alibaby powraca z nowym biznesem. Jack Ma chce podbić branżę spożywczą
 - [https://sukces.rp.pl/biznes/art39474861-tworca-alibaby-powraca-z-nowym-biznesem-jack-ma-chce-podbic-branze-spozywcza](https://sukces.rp.pl/biznes/art39474861-tworca-alibaby-powraca-z-nowym-biznesem-jack-ma-chce-podbic-branze-spozywcza)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T15:41:56+00:00

Twórca serwisu Alibaba, chiński miliarder Jack Ma, chce teraz podbić branżę spożywczą. Nowa firma chińskiego miliardera będzie sprzedawać żywność. To ma być nowy początek dla człowieka, który kilka lat temu podpadł władzom w Pekinie i musiał usunąć się w cień.

## Michał Szułdrzyński: Mariusz Błaszczak i inni eksperci w rządzie Mateusza Morawieckiego
 - [https://www.rp.pl/komentarze/art39474391-michal-szuldrzynski-mariusz-blaszczak-i-inni-eksperci-w-rzadzie-mateusza-morawieckiego](https://www.rp.pl/komentarze/art39474391-michal-szuldrzynski-mariusz-blaszczak-i-inni-eksperci-w-rzadzie-mateusza-morawieckiego)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T15:35:56+00:00

Jarosław Kaczyński zdecydował, że Mariusz Błaszczak pozostanie w MON. Nawet władze PiS uznały, że istnieją granice politycznej maskarady. Ale tym samym pokazały, że cała narracja o eksperckim rządzie przejściowym to tylko political fiction.

## Nowy rok może przynieść wiele dobrego dla marek odzieżowych i obuwniczych
 - [https://firma.rp.pl/finanse/art39471991-nowy-rok-moze-przyniesc-wiele-dobrego-dla-marek-odziezowych-i-obuwniczych](https://firma.rp.pl/finanse/art39471991-nowy-rok-moze-przyniesc-wiele-dobrego-dla-marek-odziezowych-i-obuwniczych)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T15:27:00+00:00

Optymistyczne nastroje przedsiębiorców wynikające z wysokich wyników sprzedaży z m.in. wyprzedaży w ciągu Black Friday czy Cyber Monday oraz świątecznego szaleństwa zakupów mogą utrzymać się w także w 2024 roku.

## Przyszłość polskiego biznesu ma zielony kolor
 - [https://www.rp.pl/ekonomia/art39474811-przyszlosc-polskiego-biznesu-ma-zielony-kolor](https://www.rp.pl/ekonomia/art39474811-przyszlosc-polskiego-biznesu-ma-zielony-kolor)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T15:23:00+00:00

Zmiany, jakie zachodzą na rynku energii definiują nie tylko to, w jaki sposób ją pozyskujemy, ale także to jak wyglądać będzie polski horyzont najbliższych dziesięcioleci. Nie będzie w nim miejsca na wysokie, dymiące kominy i kłęby dymu. Te widoki ustąpią miejsca smukłym i potężnym wiatrakom.

## Klienci chińskiego parabanku mogą stracić dziesiątki miliardów dolarów
 - [https://www.rp.pl/banki/art39474691-klienci-chinskiego-parabanku-moga-stracic-dziesiatki-miliardow-dolarow](https://www.rp.pl/banki/art39474691-klienci-chinskiego-parabanku-moga-stracic-dziesiatki-miliardow-dolarow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T15:15:24+00:00

Inwestorzy mogą stracić dziesiątki miliardów dolarów na bankructwie Zhongzhi Enterprise Group, czyli konglomeratu będącego jednym z największych chińskich parabanków. To kolejna odsłona kryzysu nieruchomościowego w Chinach.

## Polityka mieszkaniowa według przyszłej koalicji. Co z kredytem 2 proc.?
 - [https://www.rp.pl/nieruchomosci-mieszkaniowe/art39474541-polityka-mieszkaniowa-wedlug-przyszlej-koalicji-co-z-kredytem-2-proc](https://www.rp.pl/nieruchomosci-mieszkaniowe/art39474541-polityka-mieszkaniowa-wedlug-przyszlej-koalicji-co-z-kredytem-2-proc)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T15:07:02+00:00

Państwo powinno i budować mieszkania dla najbardziej potrzebujących, i wspierać kredytobiorców – ale rozsądnie. Na konkrety trzeba poczekać - aż zainstaluje się i utrze nowa koalicja.

## Rekordowy Black Friday. Sprzedaż w Europie Wschodniej wyższa o niemal 25 proc.
 - [https://www.rp.pl/handel/art39474661-rekordowy-black-friday-sprzedaz-w-europie-wschodniej-wyzsza-o-niemal-25-proc](https://www.rp.pl/handel/art39474661-rekordowy-black-friday-sprzedaz-w-europie-wschodniej-wyzsza-o-niemal-25-proc)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T15:04:42+00:00

Dzień będący tradycyjnym początkiem świątecznego sezonu zakupów nie tylko w USA wypadł bardzo dobrze. Wskazują na to dane Adobe, Salesforce i Mastercard. Sprzedaż w internecie była rekordowo wysoka.

## Roch Zygmunt: Nowy rząd Morawieckiego to test na pamięć złotej rybki
 - [https://www.rp.pl/opinie-polityczno-spoleczne/art39474451-roch-zygmunt-nowy-rzad-morawieckiego-to-test-na-pamiec-zlotej-rybki](https://www.rp.pl/opinie-polityczno-spoleczne/art39474451-roch-zygmunt-nowy-rzad-morawieckiego-to-test-na-pamiec-zlotej-rybki)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T15:00:49+00:00

Mateusz Morawiecki uważa, że to „rząd polityczno-ekspercki”. I rzeczywiście nazwiska ministrów nie są z politycznego pierwszego szeregu, ale czy to faktyczni eksperci?

## Francja: nastolatkowie zamieszani w ścięcie głowy nauczycielowi stanęli przed sądem
 - [https://www.rp.pl/prawo-karne/art39474721-francja-nastolatkowie-zamieszani-w-sciecie-glowy-nauczycielowi-staneli-przed-sadem](https://www.rp.pl/prawo-karne/art39474721-francja-nastolatkowie-zamieszani-w-sciecie-glowy-nauczycielowi-staneli-przed-sadem)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T14:59:25+00:00

W poniedziałek ruszył proces sześciu nastolatków zamieszanych w śmierć francuskiego nauczyciela Samuela Paty'ego. Paty został zaatakowany nożem przez 18-letniego imigranta z Czeczecii. Nastolatek zamordował nauczyciela odcinając mu głowę.

## Nowy rząd Mateusza Morawieckiego. Trwa zaprzysiężenie
 - [https://www.rp.pl/polityka/art39474131-nowy-rzad-mateusza-morawieckiego-trwa-zaprzysiezenie](https://www.rp.pl/polityka/art39474131-nowy-rzad-mateusza-morawieckiego-trwa-zaprzysiezenie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T14:58:19+00:00

W Pałacu Prezydenckim rozpoczęło się zaprzysiężenie nowego rządu Mateusza Morawieckiego (PiS). W gabinecie ponad połowę stanowisk obejmą kobiety.

## Nowy rząd Mateusza Morawieckiego. Znamy nazwiska ministrów
 - [https://www.rp.pl/polityka/art39474131-nowy-rzad-mateusza-morawieckiego-znamy-nazwiska-ministrow](https://www.rp.pl/polityka/art39474131-nowy-rzad-mateusza-morawieckiego-znamy-nazwiska-ministrow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T14:58:19+00:00

Wiemy, kto wejdzie w skład nowego rządu Mateusza Morawieckiego (PiS). W gabinecie ponad połowę stanowisk obejmą kobiety.

## Nowy rząd Mateusza Morawieckiego zaprzysiężony. Dwa tygodnie na znalezienie większości
 - [https://www.rp.pl/polityka/art39474131-nowy-rzad-mateusza-morawieckiego-zaprzysiezony-dwa-tygodnie-na-znalezienie-wiekszosci](https://www.rp.pl/polityka/art39474131-nowy-rzad-mateusza-morawieckiego-zaprzysiezony-dwa-tygodnie-na-znalezienie-wiekszosci)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T14:58:00+00:00

Nowy rząd Mateusza Morawieckiego (PiS) zaprzysiężony. W gabinecie ponad połowę stanowisk objęły kobiety. - Dopełniamy politycznego i historycznego zwyczaju - powiedział prezydent Andrzej Duda.

## Nowy rząd Mateusza Morawieckiego zaprzysiężony. Dwatygodnie na znalezienie większości
 - [https://www.rp.pl/polityka/art39474131-nowy-rzad-mateusza-morawieckiego-zaprzysiezony-dwatygodnie-na-znalezienie-wiekszosci](https://www.rp.pl/polityka/art39474131-nowy-rzad-mateusza-morawieckiego-zaprzysiezony-dwatygodnie-na-znalezienie-wiekszosci)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T14:58:00+00:00

W Pałacu Prezydenckim zakończyło się zaprzysiężenie nowego rządu Mateusza Morawieckiego (PiS). W gabinecie ponad połowę stanowisk objęły kobiety.

## Piotr Gliński chce zabetonować władze TVP i mediów publicznych
 - [https://www.rp.pl/media/art39474491-piotr-glinski-chce-zabetonowac-wladze-tvp-i-mediow-publicznych](https://www.rp.pl/media/art39474491-piotr-glinski-chce-zabetonowac-wladze-tvp-i-mediow-publicznych)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T14:50:00+00:00

PiS ma pomysł na to, jak powstrzymać zmiany w mediach publicznych zapowiadane przez idącą po władzę dotychczasową opozycję. Rada Mediów Narodowych wyraziła zgodę na zmianę statutów TVP, Polskiego Radia i Polskiej Agencji Prasowej.

## Wniosek o 300+ można złożyć tylko do końca listopada
 - [https://www.rp.pl/praca-emerytury-i-renty/art39474671-wniosek-o-300-mozna-zlozyc-tylko-do-konca-listopada](https://www.rp.pl/praca-emerytury-i-renty/art39474671-wniosek-o-300-mozna-zlozyc-tylko-do-konca-listopada)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T14:28:08+00:00

Rodzic ucznia może złożyć wniosek o 300 zł z programu „Dobry start”. Kwota ta przysługuje niezależnie od dochodu raz w roku na dziecko uczące się w szkole aż do ukończenia przez nie 20. roku życia

## Konfederacja chce trzech komisji śledczych. "Pociągnąć przestępców politycznych do odpowiedzialności"
 - [https://www.rp.pl/polityka/art39474441-konfederacja-chce-trzech-komisji-sledczych-pociagnac-przestepcow-politycznych-do-odpowiedzialnosci](https://www.rp.pl/polityka/art39474441-konfederacja-chce-trzech-komisji-sledczych-pociagnac-przestepcow-politycznych-do-odpowiedzialnosci)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T14:23:08+00:00

Konfederacja przygotowała projekty uchwał w sprawie powołania komisji śledczych dot. polityki energetycznej, ds. zbadania przyczyn i skutków niekontrolowanego importu żywności z Ukrainy oraz ds. potencjalnych nieprawidłowości związanych z polityką covidową.

## Nowy byk w stajni: Polska premiera Lamborghini Revuelto
 - [https://moto.rp.pl/premiery/art39474521-nowy-byk-w-stajni-polska-premiera-lamborghini-revuelto](https://moto.rp.pl/premiery/art39474521-nowy-byk-w-stajni-polska-premiera-lamborghini-revuelto)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T14:20:50+00:00

Lamborghini wprowadza na rynek zupełnie nowy flagowy model - Revuelto. To następcę Aventadora, który jest wyposażony w hybrydowy układ napędowy typu plug-in, podwozie z włókna węglowego, piękne nadwozie i nowoczesne wnętrze.

## Badanie: szczyty klimatyczne faworyzują kraje bogate. „Biedni nie mają szans”
 - [https://klimat.rp.pl/klimat/art39474211-badanie-szczyty-klimatyczne-faworyzuja-kraje-bogate-biedni-nie-maja-szans](https://klimat.rp.pl/klimat/art39474211-badanie-szczyty-klimatyczne-faworyzuja-kraje-bogate-biedni-nie-maja-szans)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T14:18:52+00:00

Wielkimi krokami zbliża się konferencja COP28 w Dubaju, na której światowi przywódcy mają pracować nad wspólną strategię w walce ze zmianami klimatu. Szwedzcy i brytyjscy naukowcy zwracają uwagę, że tego typu wydarzenia organizowane są w sposób niesprawiedliwy i faworyzujący wielkie, bogate kraje.

## Turystyka odchodzi od modelu sun & beach. Teraz stawia na sun & blue
 - [https://turystyka.rp.pl/zanim-wyjedziesz/art39474551-turystyka-odchodzi-od-modelu-sun-beach-teraz-stawia-na-sun-blue](https://turystyka.rp.pl/zanim-wyjedziesz/art39474551-turystyka-odchodzi-od-modelu-sun-beach-teraz-stawia-na-sun-blue)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T14:13:28+00:00

Błękitna turystyka ma pomóc turystyce zwrócić się w stronę zrównoważonego rozwoju. Pod pojęciem tym kryje się co prawda także typowy wypoczynek na ciepłych plażach, ale chodzi o włączenie w biznes nowych akwenów i rozwinięcie ich pod potrzeby bardziej niszowych grup klientów.

## Prokuratura umorzyła postępowania wobec Jarosława Kaczyńskiego
 - [https://www.rp.pl/prawo-karne/art39474431-prokuratura-umorzyla-postepowania-wobec-jaroslawa-kaczynskiego](https://www.rp.pl/prawo-karne/art39474431-prokuratura-umorzyla-postepowania-wobec-jaroslawa-kaczynskiego)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T14:05:00+00:00

Dwa prokuratorskie postępowania prowadzone wobec prezesa PiS Jarosława Kaczyńskiego zostały umorzone - dowiedziało się RMF FM. Chodziło o incydenty podczas jednej z miesięcznic smoleńskich.

## Mer Paryża nazwała platformę X Muska "ściekiem, który niszczy demokrację"
 - [https://www.rp.pl/polityka/art39474511-mer-paryza-nazwala-platforme-x-muska-sciekiem-ktory-niszczy-demokracje](https://www.rp.pl/polityka/art39474511-mer-paryza-nazwala-platforme-x-muska-sciekiem-ktory-niszczy-demokracje)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T14:04:37+00:00

Anne Hidalgo, mer Paryża, zapowiedziała, że opuszcza należącą do Elona Muska platformę X (dawny Twitter).

## Skarb Scytów wrócił na Ukrainę. Kreml chce go dla siebie
 - [https://www.rp.pl/biznes/art39474411-skarb-scytow-wrocil-na-ukraine-kreml-chce-go-dla-siebie](https://www.rp.pl/biznes/art39474411-skarb-scytow-wrocil-na-ukraine-kreml-chce-go-dla-siebie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T13:59:00+00:00

Muzeum Allarda Pearsona w Amsterdamie zwróciło Ukrainie przechowywany od 2014 r. skarb znany jako Złoto Scytów. Skarb zawierający wyjątkowej urody złote ozdoby o wadze 2694 kg, dziś wjechał do Kijowa.

## Epidemia „syndromu oszusta”: czego boimy się na Linkedinie?
 - [https://sukces.rp.pl/spoleczenstwo/art39474371-epidemia-syndromu-oszusta-czego-boimy-sie-na-linkedinie](https://sukces.rp.pl/spoleczenstwo/art39474371-epidemia-syndromu-oszusta-czego-boimy-sie-na-linkedinie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T13:47:26+00:00

Korzystanie z takich serwisów jak Linkedin pogłębia objawy „syndromu oszusta” – twierdzą autorzy nowego badania na ten temat. Czym jest „syndrom oszusta” i jak sobie z nim radzić w pracy?

## Wyzwania artylerii na współczesnych polach walki: precyzja, zasięg, informacja
 - [https://radar.rp.pl/innowacje-w-armiach/art39474021-wyzwania-artylerii-na-wspolczesnych-polach-walki-precyzja-zasieg-informacja](https://radar.rp.pl/innowacje-w-armiach/art39474021-wyzwania-artylerii-na-wspolczesnych-polach-walki-precyzja-zasieg-informacja)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T13:47:00+00:00

Bezpieczeństwo kraju i jego odporność na próby ataków opierają się na szeregu rozwiązań, które nie tylko służą bezpośredniej obronie, ale przede wszystkim nowoczesne technologie mają w pierwszej kolejności odstraszać i zniechęcać do agresji. Wiele krajów na świecie umacnia swoje bezpieczeństwo wykorzystując solidne doświadczenie firmy Leonardo i jej wiodącą pozycję w dziedzinie rozwiązań elektronicznych dla obronności. Stojąca za tym technologia stwarza jeszcze inną korzyść – przemysłową – co umacnia suwerenność i bezpieczeństwo narodu. Również Polska jest zapraszana do takiej współpracy z firmą Leonardo, aby rozwijać zdolności obronne i przemysłowe.

## Nowy szef MSZ Wielkiej Brytanii na liście płac Chin
 - [https://www.rp.pl/dyplomacja/art39473621-nowy-szef-msz-wielkiej-brytanii-na-liscie-plac-chin](https://www.rp.pl/dyplomacja/art39473621-nowy-szef-msz-wielkiej-brytanii-na-liscie-plac-chin)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T13:42:45+00:00

Czy brytyjską dyplomacją może kierować człowiek, który jest w kieszeni Pekinu? Media na Wyspach mają coraz większe wątpliwości.

## Krzysztof A. Kowalczyk: Blokada granicy w obliczu rotacji ministrów
 - [https://www.rp.pl/opinie-ekonomiczne/art39473991-krzysztof-a-kowalczyk-blokada-granicy-w-obliczu-rotacji-ministrow](https://www.rp.pl/opinie-ekonomiczne/art39473991-krzysztof-a-kowalczyk-blokada-granicy-w-obliczu-rotacji-ministrow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T13:40:28+00:00

W sprawie blokady polsko-ukraińskich przejść granicznych poprzedni minister infrastruktury schował głowę w piasek. Nowy, z chwilowego rządu PiS, już nie może. Głupio byłoby, gdyby Sejm go odwołał, zanim za dwa tygodnie premier Mateusz Morawiecki przegra głosowanie ws. wotum zaufania.

## ChatERP nowy wymiar wsparcia użytkownika systemów Comarch ERP
 - [https://www.rp.pl/ekonomia/art39474341-chaterp-nowy-wymiar-wsparcia-uzytkownika-systemow-comarch-erp](https://www.rp.pl/ekonomia/art39474341-chaterp-nowy-wymiar-wsparcia-uzytkownika-systemow-comarch-erp)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T13:32:00+00:00

Comarch, największy dostawca systemów ERP w Polsce, przedstawia nowe narzędzie – Comarch ChatERP. Jest to interaktywny asystent o nazwie ChatERP, który jest równolegle rozwijane we flagowym produkcie tj. w Comarch ERP Optima, a docelowo będzie dostępny we wszystkich systemach Comarch ERP. Narzędzie jest oparte o generatywną sztuczną inteligencję.

## Wyrównanie 500+ do 800 zł od sierpnia 2023? ZUS wydał komunikat
 - [https://www.rp.pl/praca-emerytury-i-renty/art39474381-wyrownanie-500-do-800-zl-od-sierpnia-2023-zus-wydal-komunikat](https://www.rp.pl/praca-emerytury-i-renty/art39474381-wyrownanie-500-do-800-zl-od-sierpnia-2023-zus-wydal-komunikat)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T13:31:00+00:00

Wyrównanie świadczenia 500+ do kwoty 800 zł za okres od sierpnia 2023 r. do grudnia 2023 r.  to fałszywa informacja, która krąży w internecie - wskazuje Zakład Ubezpieczeń Społecznych.

## Bartosz Arłukowicz o nowym rządzie: Morawiecki upadł zupełnie, ale że prezydent?
 - [https://www.rp.pl/polityka/art39474281-bartosz-arlukowicz-o-nowym-rzadzie-morawiecki-upadl-zupelnie-ale-ze-prezydent](https://www.rp.pl/polityka/art39474281-bartosz-arlukowicz-o-nowym-rzadzie-morawiecki-upadl-zupelnie-ale-ze-prezydent)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T13:23:00+00:00

- mówił w TVN24 o poniedziałkowym zaprzysiężeniu nowego rządu Mateusza Morawieckiego poseł KO, Bartosz Arłukowicz.

## Podróbka to nie problem? Lepiej polować na przedmiot vintage, niż kupować replikę
 - [https://kobieta.rp.pl/moda/art39472071-podrobka-to-nie-problem-lepiej-polowac-na-przedmiot-vintage-niz-kupowac-replike](https://kobieta.rp.pl/moda/art39472071-podrobka-to-nie-problem-lepiej-polowac-na-przedmiot-vintage-niz-kupowac-replike)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T13:17:16+00:00

W 2022 r. celnicy przejęli na całym świecie ponad pięć milionów podrobionych produktów Chanel. W Internecie działają nowi, coraz bardziej wyspecjalizowani fałszerze.

## Letycja – w czym tkwi siła królowej Hiszpanii
 - [https://kobieta.rp.pl/jej-historia/art39472021-letycja-w-czym-tkwi-sila-krolowej-hiszpanii](https://kobieta.rp.pl/jej-historia/art39472021-letycja-w-czym-tkwi-sila-krolowej-hiszpanii)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T13:16:13+00:00

„To była ta kobieta: delikatna i zniewalająca, a jednocześnie silna i zdecydowana, powiedział król Hiszpanii (wówczas książę) Filip VI na widok dziennikarki Letycji Ortiz Rocasolano, którą później pojął za żonę. Królowa Letycja przez wielu uznawana jest za najpiękniejszą i najlepiej ubraną monarchinię Europy.

## Fatalne zaniedbanie ze strony British Museum. Tłumaczka walczy o swoje prawa
 - [https://kobieta.rp.pl/kultura/art39472191-fatalne-zaniedbanie-ze-strony-british-museum-tlumaczka-walczy-o-swoje-prawa](https://kobieta.rp.pl/kultura/art39472191-fatalne-zaniedbanie-ze-strony-british-museum-tlumaczka-walczy-o-swoje-prawa)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T13:05:46+00:00

Mozolna praca tłumacza często pozostaje niezauważona, nawet przez taką instytucję jak British Museum.

## DPD zwiększa dostępność punktów OOH a Klienci robią zakupy z wyprzedzeniem
 - [https://logistyka.rp.pl/produkty-i-uslugi/art39474241-dpd-zwieksza-dostepnosc-punktow-ooh-a-klienci-robia-zakupy-z-wyprzedzeniem](https://logistyka.rp.pl/produkty-i-uslugi/art39474241-dpd-zwieksza-dostepnosc-punktow-ooh-a-klienci-robia-zakupy-z-wyprzedzeniem)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T13:00:00+00:00

Prezes DPD Polska Rafał Nawłoka mówi o nowych formach doręczeń i elektryfikacji transportu.

## Prof. Ewa Łętowska: Strasburg dał nam rok na porządek z neosędziami
 - [https://www.rp.pl/sady-i-trybunaly/art39473551-prof-ewa-letowska-strasburg-dal-nam-rok-na-porzadek-z-neosedziami](https://www.rp.pl/sady-i-trybunaly/art39473551-prof-ewa-letowska-strasburg-dal-nam-rok-na-porzadek-z-neosedziami)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T13:00:00+00:00

Sejm może wiele osiągnąć uchwałami w sprawie KRS czy Trybunału Konstytucyjnego - mówi prof. Ewa Łętowska.

## Minister wyliczył ile samolotów Rosja straciła przez „wrogie kraje”
 - [https://www.rp.pl/transport/art39474191-minister-wyliczyl-ile-samolotow-rosja-stracila-przez-wrogie-kraje](https://www.rp.pl/transport/art39474191-minister-wyliczyl-ile-samolotow-rosja-stracila-przez-wrogie-kraje)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T12:52:09+00:00

Rosja straciła bezpowrotnie 76 samolotów z powodu zachodnich sankcji - przyznał minister transportu Witalij Sawieljew.

## Paweł Huelle, autor „Weisera Dawidka”  nie żyje
 - [https://www.rp.pl/literatura/art39474171-pawel-huelle-autor-weisera-dawidka-nie-zyje](https://www.rp.pl/literatura/art39474171-pawel-huelle-autor-weisera-dawidka-nie-zyje)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T12:44:00+00:00

Zmarł Paweł Huelle, jeden z najważniejszych polskich pisarzy ostatnich dekad, dramaturg, człowiek pierwszej "Solidarności". Krytykował antysemickie wypowiedzi ks. Jankowskiego i wygrał z nim proces. Miał 66 lat.

## Hamas wypuścił kobiety, dzieci i Rosjanina, który raz mu prawie uciekł
 - [https://www.rp.pl/konflikty-zbrojne/art39474151-hamas-wypuscil-kobiety-dzieci-i-rosjanina-ktory-raz-mu-prawie-uciekl](https://www.rp.pl/konflikty-zbrojne/art39474151-hamas-wypuscil-kobiety-dzieci-i-rosjanina-ktory-raz-mu-prawie-uciekl)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T12:33:16+00:00

W niedzielę w grupie 17 zakładników wypuszczonych przez Hamas był, niespodziewanie, 25-letni mężczyzna, Roni Kriboy. Wcześniej Hamas deklarował, że w ramach zawieszenia broni z Izraelem będzie uwalniać kobiety i dzieci.

## Itaka: To był najlepszy rok w historii biur podróży, ale liczymy na  jeszcze lepszy
 - [https://turystyka.rp.pl/biura-podrozy/art39474121-itaka-to-byl-najlepszy-rok-w-historii-biur-podrozy-ale-liczymy-na-jeszcze-lepszy](https://turystyka.rp.pl/biura-podrozy/art39474121-itaka-to-byl-najlepszy-rok-w-historii-biur-podrozy-ale-liczymy-na-jeszcze-lepszy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T12:30:12+00:00

Ten rok biura podróży zaliczą do najlepszych w historii. Od tej pory będzie on dla nas punktem odniesienia, jak wcześniej rok 2019. Itaka obsłuży milion klientów w kraju, a półtora miliona, licząc razem z turystami z krajów ościennych – mówi serwisowi Turystyka.rp.pl wiceprezes Itaki Piotr Henicz.

## Prokuratorzy chcą wyrównania wynagrodzeń. Barski wysłał pismo do MF
 - [https://www.rp.pl/zawody-prawnicze/art39473981-prokuratorzy-chca-wyrownania-wynagrodzen-barski-wyslal-pismo-do-mf](https://www.rp.pl/zawody-prawnicze/art39473981-prokuratorzy-chca-wyrownania-wynagrodzen-barski-wyslal-pismo-do-mf)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T12:24:00+00:00

Niedawny wyrok Trybunału Konstytucyjnego zapewnił sędziom wyrównanie wynagrodzeń za ubiegłe miesiące. Teraz o to samo zawalczyć postanowili prokuratorzy. Domagają się uruchomienia rezerwy celowej sięgającej 200 mln zł.

## Pogoda zatrzymuje walki na Ukrainie. Nie latają drony, nie strzela artyleria
 - [https://www.rp.pl/konflikty-zbrojne/art39473941-pogoda-zatrzymuje-walki-na-ukrainie-nie-lataja-drony-nie-strzela-artyleria](https://www.rp.pl/konflikty-zbrojne/art39473941-pogoda-zatrzymuje-walki-na-ukrainie-nie-lataja-drony-nie-strzela-artyleria)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T12:09:23+00:00

Huraganowy wiatr, opady śniegu i śniegu z deszczem zastopowały działania wojenne.

## Afera wizowa. KO chce powołania komisji śledczej, jest projekt uchwały
 - [https://www.rp.pl/polityka/art39473571-afera-wizowa-ko-chce-powolania-komisji-sledczej-jest-projekt-uchwaly](https://www.rp.pl/polityka/art39473571-afera-wizowa-ko-chce-powolania-komisji-sledczej-jest-projekt-uchwaly)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T12:02:43+00:00

Posłowie Koalicji Obywatelskiej złożyli w Sejmie projekt uchwały w sprawie powołania komisji śledczej ws. tzw. afery wizowej.

## Liga Mistrzów. Robert Lewandowski zagra z Porto, Piotr Zieliński – z Realem
 - [https://www.rp.pl/pilka-nozna/art39473791-liga-mistrzow-robert-lewandowski-zagra-z-porto-piotr-zielinski-z-realem](https://www.rp.pl/pilka-nozna/art39473791-liga-mistrzow-robert-lewandowski-zagra-z-porto-piotr-zielinski-z-realem)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T11:56:00+00:00

Znamy już sześciu z 16 uczestników fazy pucharowej Ligi Mistrzów. Hitem kolejki będą mecze PSG - Newcastle i Real - Napoli. Na ławce Unionu Berlin zadebiutuje były trener Lecha Nenad Bjelica.

## Dziś poznamy laureata XXIII edycji Nagrody „Rzeczpospolitej” im. Jerzego Giedroycia
 - [https://www.rp.pl/kraj/art39473951-dzis-poznamy-laureata-xxiii-edycji-nagrody-rzeczpospolitej-im-jerzego-giedroycia](https://www.rp.pl/kraj/art39473951-dzis-poznamy-laureata-xxiii-edycji-nagrody-rzeczpospolitej-im-jerzego-giedroycia)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T11:55:12+00:00

W poniedziałek wieczorem, w Bibliotece Narodowej, odbędzie się uroczystość wręczenia Nagrody „Rzeczpospolitej” im. Jerzego Giedroycia. To już XXIII edycja tej nagrody.

## UOKiK stawia zarzuty Dr Smile. "Wywieranie presji i manipulowanie"
 - [https://www.rp.pl/konsumenci/art39473871-uokik-stawia-zarzuty-dr-smile-wywieranie-presji-i-manipulowanie](https://www.rp.pl/konsumenci/art39473871-uokik-stawia-zarzuty-dr-smile-wywieranie-presji-i-manipulowanie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T11:44:29+00:00

Korzystający z usług Dr Smile mogli mieć utrudniony dostęp do pełnych warunków umowy oraz być poddawani presji w celu natychmiastowego jej podpisania - uważa Prezes Urzędu Konkurencji i Konsumentów. Firma oferowała nakładki ortodontyczne na zęby.

## Polskie samorządy wyznaczają europejskie standardy w mediach społecznościowych
 - [https://regiony.rp.pl/z-regionow/art39473781-polskie-samorzady-wyznaczaja-europejskie-standardy-w-mediach-spolecznosciowych](https://regiony.rp.pl/z-regionow/art39473781-polskie-samorzady-wyznaczaja-europejskie-standardy-w-mediach-spolecznosciowych)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T11:37:09+00:00

Największy problem to niespotykana nigdzie indziej w Europie skala hejtu na samorządowców - mówi Michał Fedorowicz, prezes Instytutu Badań Internetu i Mediów Społecznościowych, jeden z prelegentów II Samorządowego Kongresu Internetu i Mediów Społecznościowych Local SoMe'23. "Rzeczpospolita" jest patronem medialnym tego wydarzenia.

## Poseł PiS mówi, że nie wejdzie do rządu, bo "jest wyrazistym politykiem"
 - [https://www.rp.pl/polityka/art39473831-posel-pis-mowi-ze-nie-wejdzie-do-rzadu-bo-jest-wyrazistym-politykiem](https://www.rp.pl/polityka/art39473831-posel-pis-mowi-ze-nie-wejdzie-do-rzadu-bo-jest-wyrazistym-politykiem)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T11:32:48+00:00

Rząd chwilówki, rząd dwutygodniówki, rząd fejkowy - mówił w rozmowie z TVN24 rzecznik PSL, Miłosz Motyka, pytany o nowy rząd Mateusza Morawieckiego, który ma zostać zaprzysiężony w Pałacu Prezydenckim o 16:30.

## Rekord zakażeń HIV. Polacy się nie badają
 - [https://www.rp.pl/spoleczenstwo/art39473851-rekord-zakazen-hiv-polacy-sie-nie-badaja](https://www.rp.pl/spoleczenstwo/art39473851-rekord-zakazen-hiv-polacy-sie-nie-badaja)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T11:32:00+00:00

Od stycznia do połowy listopada w Polsce odnotowano 2590 zakażeń HIV. I choć do końca 2023 roku zostało jeszcze półtora miesiąca, to liczba nowo wykrytych zakażeń już przekroczyła tę z całego 2022 roku.

## Raport: Polacy świetnie mówią po angielsku. Liderem wcale nie jest Warszawa
 - [https://sukces.rp.pl/spoleczenstwo/art39427371-raport-polacy-swietnie-mowia-po-angielsku-liderem-wcale-nie-jest-warszawa](https://sukces.rp.pl/spoleczenstwo/art39427371-raport-polacy-swietnie-mowia-po-angielsku-liderem-wcale-nie-jest-warszawa)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T11:28:12+00:00

Polska znalazła się czołówce krajów, których mieszkańcy najlepiej znają angielski – donosi najnowszy globalny raport EF Education First. Najlepiej wypadają jednak wcale nie mieszkańcy Warszawy, Krakowa czy Trójmiasta, dużych metropolii, które zwykliśmy kojarzyć z najlepszą znajomością języków obcych.

## Dawid Pałka: Nie skończ jak ptak dodo
 - [https://www.rp.pl/opinie-ekonomiczne/art39473821-dawid-palka-nie-skoncz-jak-ptak-dodo](https://www.rp.pl/opinie-ekonomiczne/art39473821-dawid-palka-nie-skoncz-jak-ptak-dodo)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T11:19:54+00:00

Wczoraj moja żona wróciła z wieczornej wywiadówki. Nieświadom jej nastroju, cały w skowronkach zapytałem naiwnie, jak poszło.

## Lidl ma nową ofertę na święta. Będzie wypożyczać swetry świąteczne
 - [https://sukces.rp.pl/moda/art39465371-lidl-ma-nowa-oferte-na-swieta-bedzie-wypozyczac-swetry-swiateczne](https://sukces.rp.pl/moda/art39465371-lidl-ma-nowa-oferte-na-swieta-bedzie-wypozyczac-swetry-swiateczne)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T11:18:16+00:00

Lidl przed tegorocznymi świętami postanowił zaproponować klientom w Wielkiej Brytanii nietypową usługę – mogą oni wypożyczyć sweter świąteczny, zamiast go kupować.

## Wiemy kto będzie szefem MSZ i ministrem sprawiedliwości w nowym rządzie Morawieckiego
 - [https://www.rp.pl/polityka/art39473771-wiemy-kto-bedzie-szefem-msz-i-ministrem-sprawiedliwosci-w-nowym-rzadzie-morawieckiego](https://www.rp.pl/polityka/art39473771-wiemy-kto-bedzie-szefem-msz-i-ministrem-sprawiedliwosci-w-nowym-rzadzie-morawieckiego)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T11:10:22+00:00

Ponad połowa składu nowego rządu premiera Mateusza Morawieckiego to kobiety - wynika z informacji "Rzeczpospolitej".

## Łotwa chce pomóc rozwiązać polsko-ukraiński spór na granicy. Wiemy dlaczego
 - [https://www.rp.pl/transport/art39473641-lotwa-chce-pomoc-rozwiazac-polsko-ukrainski-spor-na-granicy-wiemy-dlaczego](https://www.rp.pl/transport/art39473641-lotwa-chce-pomoc-rozwiazac-polsko-ukrainski-spor-na-granicy-wiemy-dlaczego)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T11:08:41+00:00

Władze Łotwy wyraziły gotowość przyłączenia się do negocjacji w sprawie odblokowania ukraińsko-polskiej granicy. Powód związany jest z sytuacją w łotewskim przetwórstwie.

## Kierwiński: Morawiecki ma twarz przegranego. Przegrał wybory, ale i w PiS
 - [https://www.rp.pl/polityka/art39473761-kierwinski-morawiecki-ma-twarz-przegranego-przegral-wybory-ale-i-w-pis](https://www.rp.pl/polityka/art39473761-kierwinski-morawiecki-ma-twarz-przegranego-przegral-wybory-ale-i-w-pis)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T11:04:00+00:00

Jak powiedział w rozmowie z Radiem ZET sekretarz generalny PO Marcin Kierwiński, „rząd Donalda Tuska, jeśli chodzi o konstrukcję ministrów, jest w 100 proc. zamknięty”.

## Pogoda w Polsce. IMGW ostrzega: W niektórych miejscach spaść może do 20 cm śniegu
 - [https://www.rp.pl/spoleczenstwo/art39473511-pogoda-w-polsce-imgw-ostrzega-w-niektorych-miejscach-spasc-moze-do-20-cm-sniegu](https://www.rp.pl/spoleczenstwo/art39473511-pogoda-w-polsce-imgw-ostrzega-w-niektorych-miejscach-spasc-moze-do-20-cm-sniegu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T11:01:00+00:00

Pogoda w tym tygodniu w Polsce będzie zdecydowanie zimowa. Z przewidywań synoptyków IMGW wynika, że nadchodzące dni będą w niektórych regionach kraju bardzo śnieżne oraz mroźne. Możliwy jest przyrost pokrywy śnieżnej o 15 cm - 20 cm.

## Pogoda w Polsce. W niektórych miejscach spaść może do 20 cm śniegu
 - [https://www.rp.pl/spoleczenstwo/art39473511-pogoda-w-polsce-w-niektorych-miejscach-spasc-moze-do-20-cm-sniegu](https://www.rp.pl/spoleczenstwo/art39473511-pogoda-w-polsce-w-niektorych-miejscach-spasc-moze-do-20-cm-sniegu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T11:01:00+00:00

Z przewidywań synoptyków IMGW wynika, że nadchodzące dni będą w niektórych regionach kraju bardzo śnieżne oraz mroźne. Możliwy jest przyrost pokrywy śnieżnej o 15 cm - 20 cm.

## Korea Płn. kieruje wojsko na granicę. Kim oglądał zdjęcia Rzymu zrobione przez satelitę z Północy
 - [https://www.rp.pl/dyplomacja/art39473611-korea-pln-kieruje-wojsko-na-granice-kim-ogladal-zdjecia-rzymu-zrobione-przez-satelite-z-polnocy](https://www.rp.pl/dyplomacja/art39473611-korea-pln-kieruje-wojsko-na-granice-kim-ogladal-zdjecia-rzymu-zrobione-przez-satelite-z-polnocy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T10:59:09+00:00

Korea Północna oświadczyła w poniedziałek, że będzie nadal korzystać ze swoich suwerennych praw. Pjongjang zapowiada umieszczenie na orbicie kolejnych satelitów szpiegowskich, odtwarza też strażnice na granicy z Koreą Południową.

## Komisja ds. wyborów kopertowych. Michał Dworczyk: Może za nią zagłosuję
 - [https://www.rp.pl/polityka/art39473381-komisja-ds-wyborow-kopertowych-michal-dworczyk-moze-za-nia-zaglosuje](https://www.rp.pl/polityka/art39473381-komisja-ds-wyborow-kopertowych-michal-dworczyk-moze-za-nia-zaglosuje)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T10:57:43+00:00

- Być może sam zagłosuję za powołaniem tej komisji, bo mam dosyć kłamstw i manipulacji, których przez ostatnie dwa lata muszę wysłuchiwać na ten temat - powiedział w RMF FM poseł PiS Michał Dworczyk, odnosząc się do mającej powstać komisji śledczej ds. tzw. wyborów kopertowych.

## Posłanka KO pozwała Magdalenę Ogórek. Jest wyrok sądu
 - [https://www.rp.pl/dobra-osobiste/art39473631-poslanka-ko-pozwala-magdalene-ogorek-jest-wyrok-sadu](https://www.rp.pl/dobra-osobiste/art39473631-poslanka-ko-pozwala-magdalene-ogorek-jest-wyrok-sadu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T10:55:02+00:00

Posłanka Koalicji Obywatelskiej Iwona Hartwich przegrała proces z Magdaleną Ogórek z TVP. Sprawa dotyczyła słów, jakie padły w programie "W tyle wizji".

## W Niemczech nie ma już kto pracować. "Utracimy dobrobyt"
 - [https://www.rp.pl/gospodarka/art39473601-w-niemczech-nie-ma-juz-kto-pracowac-utracimy-dobrobyt](https://www.rp.pl/gospodarka/art39473601-w-niemczech-nie-ma-juz-kto-pracowac-utracimy-dobrobyt)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T10:32:00+00:00

Niemiecka gospodarka cierpi z powodu braku pracowników. To odbije się na naszym dobrobycie, ostrzega szef związku pracodawców.

## Jacek Nizinkiewicz: Dlaczego Jarosław Kaczyński kazał Mateuszowi Morawieckiemu zbudować rząd i publicznie go upokarza?
 - [https://www.rp.pl/polityka/art39472891-jacek-nizinkiewicz-dlaczego-jaroslaw-kaczynski-kazal-mateuszowi-morawieckiemu-zbudowac-rzad-i-publicznie-go-upokarza](https://www.rp.pl/polityka/art39472891-jacek-nizinkiewicz-dlaczego-jaroslaw-kaczynski-kazal-mateuszowi-morawieckiemu-zbudowac-rzad-i-publicznie-go-upokarza)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T10:08:39+00:00

Jarosław Kaczyński mówiąc, że chce zakończyć wojnę, którą jego zdaniem prowadzi mająca za sobą większość parlamentarną PO, nie może pogodzić się z oddaniem władzy i, desperacko walcząc o przywództwo w PiS, skazuje partię na kolejne porażki.

## Drogi zegarek w kosztach firmy? Jest najnowsza interpretacja fiskusa
 - [https://firma.rp.pl/pit-cit-vat/art39473501-drogi-zegarek-w-kosztach-firmy-jest-najnowsza-interpretacja-fiskusa](https://firma.rp.pl/pit-cit-vat/art39473501-drogi-zegarek-w-kosztach-firmy-jest-najnowsza-interpretacja-fiskusa)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T10:05:56+00:00

Fiskus nie zgodził się na rozliczenie w firmie zegarka za 30 tys. zł. Urzędnicy uznali bowiem, że wydatki na budowanie wizerunku przedsiębiorcy są wyłączoną z kosztów reprezentacją.

## ORLEN Paczka ma 4000 automatów paczkowych i rośnie w imponującym tempie
 - [https://www.rp.pl/ekonomia/art39473521-orlen-paczka-ma-4000-automatow-paczkowych-i-rosnie-w-imponujacym-tempie](https://www.rp.pl/ekonomia/art39473521-orlen-paczka-ma-4000-automatow-paczkowych-i-rosnie-w-imponujacym-tempie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T10:04:00+00:00

Usługa ORLEN Paczka rozwija się w niesamowitym tempie. Przez dwa lata istnienia liczba automatów paczkowych zwiększyła się dwudziestokrotnie, z 200 do 4000. Sieć punktów odbioru ORLEN Paczki z każdym miesiącem jest coraz gęstsza. Rośnie dostępność usługi, dzięki czemu sprzedawcy zyskują możliwość dotarcia do nowych grup klientów. Skorzystaj z szansy – brak ORLEN Paczki, to brak ważnej części Twojego biznesu!

## Obowiązkowe e-fakturowanie i nowe podatki. Oto, co czeka firmy w 2024 roku
 - [https://firma.rp.pl/pit-cit-vat/art39473461-obowiazkowe-e-fakturowanie-i-nowe-podatki-oto-co-czeka-firmy-w-2024-roku](https://firma.rp.pl/pit-cit-vat/art39473461-obowiazkowe-e-fakturowanie-i-nowe-podatki-oto-co-czeka-firmy-w-2024-roku)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T09:57:01+00:00

Eksperci firmy doradczej PwC Polska opowiadali podczas konferencji, jakich przepisów i praktyk w świecie podatków mogą się spodziewać w 2024 roku osoby, które zajmują się podatkami w polskich firmach.

## Reuters o powołaniu rządu Morawieckiego: Przetrwa do grudnia
 - [https://www.rp.pl/polityka/art39473171-reuters-o-powolaniu-rzadu-morawieckiego-przetrwa-do-grudnia](https://www.rp.pl/polityka/art39473171-reuters-o-powolaniu-rzadu-morawieckiego-przetrwa-do-grudnia)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T09:56:39+00:00

Prezydent Andrzej Duda dokona w poniedziałek zaprzysiężenia członków rządu, który prawdopodobnie przetrwa tylko do grudnia - pisze agencja Reutera.

## Książka, która przerazi Europejczyków, zdobyła Booker Prize
 - [https://www.rp.pl/literatura/art39473281-ksiazka-ktora-przerazi-europejczykow-zdobyla-booker-prize](https://www.rp.pl/literatura/art39473281-ksiazka-ktora-przerazi-europejczykow-zdobyla-booker-prize)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T09:45:00+00:00

Książka “Prophet Song” Paula Lyncha o tym, jak Irlandia staje się faszystowską tyranią, zdobyła prestiżową Booker Prize 2023. To piąty irlandzki autor z tą nagrodą.

## Książka, która przerazi Europejczyków, zdybyła Booker Prize
 - [https://www.rp.pl/literatura/art39473281-ksiazka-ktora-przerazi-europejczykow-zdybyla-booker-prize](https://www.rp.pl/literatura/art39473281-ksiazka-ktora-przerazi-europejczykow-zdybyla-booker-prize)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T09:45:00+00:00

Książka “Prophet Song” Paula Lyncha o tym, jak Irlandia staje się faszystowską tyranią, zdobyła prestiżową Booker Prize 2023. To piąty irlandzki autor z tą nagrodą.

## Waluty: Złoty coraz mocniejszy
 - [https://www.rp.pl/waluty/art39473341-waluty-zloty-coraz-mocniejszy](https://www.rp.pl/waluty/art39473341-waluty-zloty-coraz-mocniejszy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T09:42:14+00:00

Nowy tydzień rozpoczyna się od umocnienia złotego , co oznacza dalsze spadki kursów najważniejszych walut.

## Armagedon nad Rosją: burze, huragany i czarna zamieć
 - [https://www.rp.pl/gospodarka/art39473081-armagedon-nad-rosja-burze-huragany-i-czarna-zamiec](https://www.rp.pl/gospodarka/art39473081-armagedon-nad-rosja-burze-huragany-i-czarna-zamiec)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T09:38:11+00:00

Nie trzeba ukraińskich dronów, wystarczy atak zimy. Burza i huragan nawiedziły Rosję. Miliony ludzi zostało bez ogrzewania, prądu i wody. Nie działa kanalizacja i lotniska. W Moskwie szaleją „czarne zamiecie”. Władze apelują o pozostanie w domach.

## Tomczyk o rządzie Morawieckiego: Nawet ministrowie nie wiedzą z kim w nim będą
 - [https://www.rp.pl/polityka/art39473181-tomczyk-o-rzadzie-morawieckiego-nawet-ministrowie-nie-wiedza-z-kim-w-nim-beda](https://www.rp.pl/polityka/art39473181-tomczyk-o-rzadzie-morawieckiego-nawet-ministrowie-nie-wiedza-z-kim-w-nim-beda)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T09:29:00+00:00

Chyba rzeczywiście jesteśmy w cyrku, skoro w dzień zaprzysiężenia jest to jakaś tajemnica - mówił w rozmowie z TVN24 Cezary Tomczyk, poseł Koalicji Obywatelskiej, zwracając uwagę, że w dniu powołania rządu Mateusza Morawieckiego przez prezydenta, nikt nie zna jego składu.

## Przepychanki na granicy z Ukrainą
 - [https://logistyka.rp.pl/drogowy/art39473251-przepychanki-na-granicy-z-ukraina](https://logistyka.rp.pl/drogowy/art39473251-przepychanki-na-granicy-z-ukraina)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T09:24:55+00:00

Ukraińscy kierowcy blokują przejazd na Ukrainę cystern z paliwem jednak nie brakuje na za wschodnią granicą.

## Prezydent Ciechanowa: Jedna lista do sejmików to błąd. Rozwiązaniem dwie listy
 - [https://www.rp.pl/polityka/art39473201-prezydent-ciechanowa-jedna-lista-do-sejmikow-to-blad-rozwiazaniem-dwie-listy](https://www.rp.pl/polityka/art39473201-prezydent-ciechanowa-jedna-lista-do-sejmikow-to-blad-rozwiazaniem-dwie-listy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T09:20:54+00:00

Jedna lista do sejmików w mojej ocenie jest błędem. Optymalnym rozwiązaniem na poziomie sejmików, które mogłoby dać zwycięstwo nawet w 15 z 16 województw, byłyby dwie listy – lista Trzecia Droga oraz KO ze wszystkimi swoimi partnerami, plus Lewica. W takiej układance jesteśmy w stanie zwyciężyć w zdecydowanej większości sejmików - ocenił Krzysztof Kosiński.

## Włodzimierz Czarzasty: Nie będzie tak, że w rządzie Tuska będą cztery kobiety
 - [https://www.rp.pl/polityka/art39472811-wlodzimierz-czarzasty-nie-bedzie-tak-ze-w-rzadzie-tuska-beda-cztery-kobiety](https://www.rp.pl/polityka/art39472811-wlodzimierz-czarzasty-nie-bedzie-tak-ze-w-rzadzie-tuska-beda-cztery-kobiety)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T08:49:27+00:00

- To są już ostatnie dwa tygodnie psucia państwa i psucia zaufania do instytucji państwa - powiedział Włodzimierz Czarzasty, komentując powstawanie nowego rządu Mateusza Morawieckiego. Lider Nowej Lewicy zaprzeczył w Polsat News, że rządzie Donalda Tuska będą cztery kobiety.

## Sąd: Nawacki ma 3 dni. Inaczej grozi mu grzywna i areszt
 - [https://www.rp.pl/sady-i-trybunaly/art39472941-sad-nawacki-ma-3-dni-inaczej-grozi-mu-grzywna-i-areszt](https://www.rp.pl/sady-i-trybunaly/art39472941-sad-nawacki-ma-3-dni-inaczej-grozi-mu-grzywna-i-areszt)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T08:27:07+00:00

Prezes Sądu Rejonowego w Olsztynie i członek nowej KRS Maciej Nawacki ma 3 dni na dopuszczenie sędziego Pawła Juszczyszyna do pracy w macierzystym wydziale cywilnym. Nakazał mu to sąd w Bydgoszczy pod rygorem grzywny, z dalszą zamianą na areszt - donosi portal oko.press.

## Huda Kattan – wizażystka, która znalazła się w tym roku na liście 100 najbardziej wpływowych kobiet według BBC
 - [https://kobieta.rp.pl/uroda/art39472241-huda-kattan-wizazystka-ktora-znalazla-sie-w-tym-roku-na-liscie-100-najbardziej-wplywowych-kobiet-wedlug-bbc](https://kobieta.rp.pl/uroda/art39472241-huda-kattan-wizazystka-ktora-znalazla-sie-w-tym-roku-na-liscie-100-najbardziej-wplywowych-kobiet-wedlug-bbc)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T08:17:29+00:00

Będąc dzieckiem, Huda Kattan postanowiła, że obedrze rynek kosmetyczny z hipokryzji. Dzisiaj wraz z siostrami prowadzi firmę kosmetyczną, której pierwszym produktem były… sztuczne rzęsy.

## Policja zatrzymała patostreamerów. Upili i upodlili młode kobiety
 - [https://www.rp.pl/prawo-karne/art39472881-policja-zatrzymala-patostreamerow-upili-i-upodlili-mlode-kobiety](https://www.rp.pl/prawo-karne/art39472881-policja-zatrzymala-patostreamerow-upili-i-upodlili-mlode-kobiety)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T08:10:07+00:00

Policja zatrzymała patostreamerów Marcina F. (pseudonim Kawiaq) i Bartłomieja K. Byli oni poszukiwani za znęcanie się nad młodymi dziewczynami podczas transmisji na żywo w internecie.

## Nowa generacja ciężarówek Iveco
 - [https://logistyka.rp.pl/drogowy/art39472821-nowa-generacja-ciezarowek-iveco](https://logistyka.rp.pl/drogowy/art39472821-nowa-generacja-ciezarowek-iveco)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T07:40:41+00:00

Iveco wydało miliard euro na gamę samochodów ciężarowych nowej generacji w wersji spalinowej i elektrycznej.

## Jacek Sasin o Trzeciej Drodze: Nazwa zobowiązuje. Czy oszukali Polaków?
 - [https://www.rp.pl/polityka/art39472721-jacek-sasin-o-trzeciej-drodze-nazwa-zobowiazuje-czy-oszukali-polakow](https://www.rp.pl/polityka/art39472721-jacek-sasin-o-trzeciej-drodze-nazwa-zobowiazuje-czy-oszukali-polakow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T06:50:13+00:00

Kończę swoją misję jako minister aktywów dzisiaj - mówił w rozmowie z TVN24 Jacek Sasin, minister aktywów państwowych.

## Jacek Sasin o Trzeciej Drodze: Powinni rozważyć propozycję Morawieckiego
 - [https://www.rp.pl/polityka/art39472721-jacek-sasin-o-trzeciej-drodze-powinni-rozwazyc-propozycje-morawieckiego](https://www.rp.pl/polityka/art39472721-jacek-sasin-o-trzeciej-drodze-powinni-rozwazyc-propozycje-morawieckiego)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T06:50:13+00:00

Kończę swoją misję jako minister aktywów dzisiaj - mówił w rozmowie z TVN24 Jacek Sasin, minister aktywów państwowych.

## Minister sprawiedliwości chce zmienić stawki dla biegłych sądowych
 - [https://www.rp.pl/sady-i-trybunaly/art39471351-minister-sprawiedliwosci-chce-zmienic-stawki-dla-bieglych-sadowych](https://www.rp.pl/sady-i-trybunaly/art39471351-minister-sprawiedliwosci-chce-zmienic-stawki-dla-bieglych-sadowych)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T06:32:34+00:00

Biegli przez osiem lat nie wywalczyli nowej ustawy, ale podwyżki dostaną.

## Urzędy nie będą już musiały pracować od 8.15 do 16.15
 - [https://www.rp.pl/urzednicy/art39471361-urzedy-nie-beda-juz-musialy-pracowac-od-8-15-do-16-15](https://www.rp.pl/urzednicy/art39471361-urzedy-nie-beda-juz-musialy-pracowac-od-8-15-do-16-15)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T06:30:04+00:00

Urzędy administracji rządowej nie będą już musiały pracować od 8.15 do 16.15, ale w soboty nie będą otwarte – wyjaśnia Sylwia Ojdym, zastępca dyrektora departamentu służby cywilnej KPRM.

## Jednoosobowy skład udrożnił apelację
 - [https://www.rp.pl/sady-i-trybunaly/art39471421-jednoosobowy-sklad-udroznil-apelacje](https://www.rp.pl/sady-i-trybunaly/art39471421-jednoosobowy-sklad-udroznil-apelacje)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T06:23:57+00:00

Dwa miesiące rozstrzygania odwołań przez jednego sędziego dowodzi, że nie opanowano chaosu po uchwale siedmiu sędziów Sądu Najwyższego.

## Jak chronione są dzieci przed przemocą
 - [https://www.rp.pl/prawo-rodzinne/art39471381-jak-chronione-sa-dzieci-przed-przemoca](https://www.rp.pl/prawo-rodzinne/art39471381-jak-chronione-sa-dzieci-przed-przemoca)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T06:21:24+00:00

W przypadku przemocy w rodzinie najczęściej są odbierane rodzicom najmłodsze dzieci. Ponad połowa z nich nie poszła jeszcze do szkoły.

## Daniel Książek: ZUS i sądy muszą dostosować się do zmian w świadczeniu pracy
 - [https://www.rp.pl/zus/art39471371-daniel-ksiazek-zus-i-sady-musza-dostosowac-sie-do-zmian-w-swiadczeniu-pracy](https://www.rp.pl/zus/art39471371-daniel-ksiazek-zus-i-sady-musza-dostosowac-sie-do-zmian-w-swiadczeniu-pracy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T06:18:26+00:00

Trudno sobie wyobrazić, że jedna osoba faktycznie wykona obowiązki służbowe z pięciu etatów – mówi dr hab. Daniel Książek, wspólnik zarządzający w kancelarii BKB Baran Książek Bigaj.

## Najzdrowsze z polskich miast
 - [https://regiony.rp.pl/jakosc-zycia/art39472671-najzdrowsze-z-polskich-miast](https://regiony.rp.pl/jakosc-zycia/art39472671-najzdrowsze-z-polskich-miast)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T06:15:42+00:00

Warszawa ma najwięcej punktów w indeksie zdrowych miast, a Rzeszów wygrał w dwóch cząstkowych kategoriach.

## Marszałek wojwództwa lubuskiego: Musimy biec do przodu
 - [https://regiony.rp.pl/ludzie/art39472551-marszalek-wojwodztwa-lubuskiego-musimy-biec-do-przodu](https://regiony.rp.pl/ludzie/art39472551-marszalek-wojwodztwa-lubuskiego-musimy-biec-do-przodu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T06:11:53+00:00

Trzeba przywrócić takie zasady finansowania samorządów, aby były one jasne i aby każdy samorząd – gmina, powiat czy województwo – znał i rozumiał algorytm, według którego będą mu wydzielane i przekazywane środki z budżetu państwa – mówi Marcin Jabłoński, marszałek województwa lubuskiego.

## Nowy rząd Morawieckiego: Rzecznik rządu zostanie ministrem nauki?
 - [https://www.rp.pl/polityka/art39472541-nowy-rzad-morawieckiego-rzecznik-rzadu-zostanie-ministrem-nauki](https://www.rp.pl/polityka/art39472541-nowy-rzad-morawieckiego-rzecznik-rzadu-zostanie-ministrem-nauki)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T05:54:19+00:00

O 16:30 prezydent Andrzej Duda ma powołać nowy rząd stworzony przez Mateusza Morawieckiego. Od momentu jego powołania Morawiecki będzie miał 14 dni na zdobycie wotum zaufania w Sejmie.

## Nowy rząd Morawieckiego: Rzecznik rządu ministrem nauki? Müller zaprzecza
 - [https://www.rp.pl/polityka/art39472541-nowy-rzad-morawieckiego-rzecznik-rzadu-ministrem-nauki-mueller-zaprzecza](https://www.rp.pl/polityka/art39472541-nowy-rzad-morawieckiego-rzecznik-rzadu-ministrem-nauki-mueller-zaprzecza)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T05:54:00+00:00

O 16:30 prezydent Andrzej Duda ma powołać nowy rząd stworzony przez Mateusza Morawieckiego. Od momentu jego powołania Morawiecki będzie miał 14 dni na zdobycie wotum zaufania w Sejmie.

## Lokalnym władzom potrzebny jest powrót do samodzielności
 - [https://regiony.rp.pl/spolecznosci-lokalne/art39472531-lokalnym-wladzom-potrzebny-jest-powrot-do-samodzielnosci](https://regiony.rp.pl/spolecznosci-lokalne/art39472531-lokalnym-wladzom-potrzebny-jest-powrot-do-samodzielnosci)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T05:35:55+00:00

Podczas debaty „Rzeczpospolitej" samorządowcy opowiadali nam o tym, jakie zmiany powinny zajść teraz w regionach.

## Nowa Zelandia wycofuje się z zakazu palenia dla kolejnych pokoleń
 - [https://www.rp.pl/spoleczenstwo/art39472491-nowa-zelandia-wycofuje-sie-z-zakazu-palenia-dla-kolejnych-pokolen](https://www.rp.pl/spoleczenstwo/art39472491-nowa-zelandia-wycofuje-sie-z-zakazu-palenia-dla-kolejnych-pokolen)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T04:56:02+00:00

Nowy rząd Nowej Zelandii zrezygnuje z przyjętych przez poprzedni rząd planów wprowadzenia "zakazu palenia dla przyszłych pokoleń" oraz z redukcji liczby punktów sprzedających papierosy w kraju.

## Czy ostatni dzień zawieszenia broni między Izraelem a Hamasem będzie ostatni?
 - [https://www.rp.pl/konflikty-zbrojne/art39472471-czy-ostatni-dzien-zawieszenia-broni-miedzy-izraelem-a-hamasem-bedzie-ostatni](https://www.rp.pl/konflikty-zbrojne/art39472471-czy-ostatni-dzien-zawieszenia-broni-miedzy-izraelem-a-hamasem-bedzie-ostatni)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T04:28:18+00:00

Poniedziałek jest czwartym, ostatnim dniem wynegocjowanego za pośrednictwem Kataru zawieszenia broni między Izraelem a Hamasem. Możliwe jednak, że czas trwania zawieszenia broni zostanie przedłużony.

## Hakerzy udostępnili wyniki badań medycznych Polaków
 - [https://www.rp.pl/przestepczosc/art39472451-hakerzy-udostepnili-wyniki-badan-medycznych-polakow](https://www.rp.pl/przestepczosc/art39472451-hakerzy-udostepnili-wyniki-badan-medycznych-polakow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T04:04:58+00:00

Grupa hakerska RA World opublikowała na swoim blogu informację o włamaniu do komputerów firmy ALAB, jednej z największych ogólnopolskich sieci laboratoriów medycznych. Na dowód, że do takiego włamania doszło, RA World opublikowała na blogu wyniki ponad 50 tys. badań medycznych - informuje serwis zaufanatrzeciastrona.pl.

## Wojna Rosji z Ukrainą. Dzień 642
 - [https://www.rp.pl/swiat/art39472431-wojna-rosji-z-ukraina-dzien-642](https://www.rp.pl/swiat/art39472431-wojna-rosji-z-ukraina-dzien-642)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T03:45:32+00:00

24 lutego 2022 roku Rosa rozpoczęła pełnowymiarową inwazję na Ukrainę. Prezydent Ukrainy, Wołodymyr Zełenski mówił w wieczornym wystąpieniu, że walki nie ustają w obwodzie donieckim i w rejonie Kupiańska w obwodzie charkowskim.

## Adam Bodnar: Czeka nas dramatyczny rok zmian
 - [https://www.rp.pl/polityka/art39472141-adam-bodnar-czeka-nas-dramatyczny-rok-zmian](https://www.rp.pl/polityka/art39472141-adam-bodnar-czeka-nas-dramatyczny-rok-zmian)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T02:00:00+00:00

Przywrócenie praworządności jest priorytetem rządu większości parlamentarnej – deklaruje prof. Adam Bodnar, senator Koalicji Obywatelskiej, były RPO, kandydat na ministra sprawiedliwości w przyszłym gabinecie Donalda Tuska.

## Adam Glapiński coraz bliżej Trybunału Stanu
 - [https://www.rp.pl/banki/art39471801-adam-glapinski-coraz-blizej-trybunalu-stanu](https://www.rp.pl/banki/art39471801-adam-glapinski-coraz-blizej-trybunalu-stanu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T02:00:00+00:00

Wzmożenie obrońców NBP wskazuje na narastające w banku centralnym obawy, że prezes tej instytucji Adam Glapiński zostanie pociągnięty do odpowiedzialności przed Trybunałem Stanu. Ale stąd do jego odwołania droga jest daleka.

## Armagedon Adama Glapińskiego. Za co prezes NBP mógłby trafić przed Trybunał Stanu
 - [https://www.rp.pl/opinie-ekonomiczne/art39471781-armagedon-adama-glapinskiego-za-co-prezes-nbp-moglby-trafic-przed-trybunal-stanu](https://www.rp.pl/opinie-ekonomiczne/art39471781-armagedon-adama-glapinskiego-za-co-prezes-nbp-moglby-trafic-przed-trybunal-stanu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T02:00:00+00:00

Po co szefowi banku centralnego agencja PR, która ma wkraczać do akcji za każdym razem, gdy ktoś wypowie słowa „Trybunał Stanu” i „Glapiński” na jednym wydechu?

## Bogusław Chrabota: Polacy już chyba nie zmienią złego zdania o prezydencie
 - [https://www.rp.pl/komentarze/art39469151-boguslaw-chrabota-polacy-juz-chyba-nie-zmienia-zlego-zdania-o-prezydencie](https://www.rp.pl/komentarze/art39469151-boguslaw-chrabota-polacy-juz-chyba-nie-zmienia-zlego-zdania-o-prezydencie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T02:00:00+00:00

Warto przypomnieć prezydentowi Andrzejowi Dudzie rotę złożonej przysięgi. Jest w niej o wierności konstytucji, godności Narodu oraz pomyślności (wszystkich) obywateli. O partii nie ma ani słowa.

## Hossa czeka małe spółki?
 - [https://www.rp.pl/gielda/art39471851-hossa-czeka-male-spolki](https://www.rp.pl/gielda/art39471851-hossa-czeka-male-spolki)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T02:00:00+00:00

Małe i średnie firmy w ostatnim czasie pozostawały w cieniu spółek z WIG20. Szansą dla mniejszych emitentów są krajowe fundusze i drobni gracze.

## Ile Polacy wydają w sklepach przed świętami Bożego Narodzenia?
 - [https://www.rp.pl/handel/art39471891-ile-polacy-wydaja-w-sklepach-przed-swietami-bozego-narodzenia](https://www.rp.pl/handel/art39471891-ile-polacy-wydaja-w-sklepach-przed-swietami-bozego-narodzenia)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T02:00:00+00:00

Listopad i grudzień generują średnio o 40 proc. więcej przychodów ze sprzedaży niż przeciętny miesiąc w innej części roku. Dlatego bój o wydatki konsumentów w tym okresie jest tak zażarty.

## Javier Milei, czyli prezydent z piłą łańcuchową
 - [https://www.rp.pl/gospodarka/art39471831-javier-milei-czyli-prezydent-z-pila-lancuchowa](https://www.rp.pl/gospodarka/art39471831-javier-milei-czyli-prezydent-z-pila-lancuchowa)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T02:00:00+00:00

Nowy przywódca zapowiada wielką rewolucję ekonomiczną. Nie przedstawił jednak jej szczegółowych planów ani składu swojej administracji. Misja wygląda na niemal samobójczą, gdyż kraj jest pogrążony w ciężkim kryzysie.

## Kolejne spotkanie przeciwników Putina w Warszawie
 - [https://www.rp.pl/polityka/art39472271-kolejne-spotkanie-przeciwnikow-putina-w-warszawie](https://www.rp.pl/polityka/art39472271-kolejne-spotkanie-przeciwnikow-putina-w-warszawie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T02:00:00+00:00

Część rosyjskiej opozycji po raz kolejny zebrała się w Warszawie i szuka sposobu na obalenie reżimu w swojej ojczyźnie.

## Kto wejdzie w skład nowego rządu Mateusza Morawieckiego? Znanych nazwisk nie będzie
 - [https://www.rp.pl/polityka/art39472111-kto-wejdzie-w-sklad-nowego-rzadu-mateusza-morawieckiego-znanych-nazwisk-nie-bedzie](https://www.rp.pl/polityka/art39472111-kto-wejdzie-w-sklad-nowego-rzadu-mateusza-morawieckiego-znanych-nazwisk-nie-bedzie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T02:00:00+00:00

Nowy gabinet premiera Morawieckiego to pierwszy krok PiS w stronę bycia opozycją.

## Marek A. Cichocki: Nasze miejsce w sporze o nowy ustrój Unii
 - [https://www.rp.pl/opinie-polityczno-spoleczne/art39471931-marek-a-cichocki-nasze-miejsce-w-sporze-o-nowy-ustroj-unii](https://www.rp.pl/opinie-polityczno-spoleczne/art39471931-marek-a-cichocki-nasze-miejsce-w-sporze-o-nowy-ustroj-unii)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T02:00:00+00:00

Pole dla politycznych negocjacji wokół zmian traktatów Unii Europejskiej jest w punkcie wyjścia dość szerokie.

## Max Verstappen: To był niesamowity rok i trudno będzie to przebić
 - [https://www.rp.pl/formula-1/art39471981-max-verstappen-to-byl-niesamowity-rok-i-trudno-bedzie-to-przebic](https://www.rp.pl/formula-1/art39471981-max-verstappen-to-byl-niesamowity-rok-i-trudno-bedzie-to-przebic)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T02:00:00+00:00

Ten sezon był pokazem dominacji Red Bulla i Maksa Verstappena, który bez problemów i oporu ze strony rywali zdobył trzeci z rzędu tytuł, bijąc kilka rekordów.

## Młodzież coraz słabiej popiera Bidena
 - [https://www.rp.pl/polityka/art39472181-mlodziez-coraz-slabiej-popiera-bidena](https://www.rp.pl/polityka/art39472181-mlodziez-coraz-slabiej-popiera-bidena)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T02:00:00+00:00

Stanowisko prezydenta USA wobec konfliktu na Bliskim Wschodzie zraża do niego wyborców młodego pokolenia.

## NBP płaci miliony doradcom Glapińskiego. I nie chce ujawnić ich nazwisk
 - [https://www.rp.pl/banki/art39471791-nbp-placi-miliony-doradcom-glapinskiego-i-nie-chce-ujawnic-ich-nazwisk](https://www.rp.pl/banki/art39471791-nbp-placi-miliony-doradcom-glapinskiego-i-nie-chce-ujawnic-ich-nazwisk)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T02:00:00+00:00

Ponad 4,6 mln zł zarobili w 2022 r. doradcy Adama Glapińskiego. NBP odmawia ujawnienia ich nazwisk.

## Nie umiesz docenić pracownika? No to możesz go stracić
 - [https://www.rp.pl/rynek-pracy/art39471861-nie-umiesz-docenic-pracownika-no-to-mozesz-go-stracic](https://www.rp.pl/rynek-pracy/art39471861-nie-umiesz-docenic-pracownika-no-to-mozesz-go-stracic)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T02:00:00+00:00

Dla prawie dziewięciu na dziesięciu pracujących Polaków brak doceniania przez przełożonego jest silnym argumentem przemawiającym za zmianą pracodawcy. Zwiększa to ryzyko rotacji kadr, która nadal jest wyzwaniem dla wielu firm.

## Polska buduje wartą 54 mld zł tarczę powietrzną. Ochroni m.in. patrioty
 - [https://www.rp.pl/biznes/art39471841-polska-buduje-warta-54-mld-zl-tarcze-powietrzna-ochroni-m-in-patrioty](https://www.rp.pl/biznes/art39471841-polska-buduje-warta-54-mld-zl-tarcze-powietrzna-ochroni-m-in-patrioty)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T02:00:00+00:00

Warta 54 mld zł tarcza powietrzna „Narew”, a nie inwestycja w patrioty, ma rozpędzić technologicznie zbrojeniówkę. Cel: budowa własnej broni precyzyjnej.

## Prezes NRL: Jako samorząd lekarski będziemy surowymi recenzentami nowej władzy
 - [https://www.rp.pl/prawo/art39471401-prezes-nrl-jako-samorzad-lekarski-bedziemy-surowymi-recenzentami-nowej-wladzy](https://www.rp.pl/prawo/art39471401-prezes-nrl-jako-samorzad-lekarski-bedziemy-surowymi-recenzentami-nowej-wladzy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T02:00:00+00:00

Trzeba pilnie odbudować zaufanie pacjentów do lekarzy – mówi Łukasz Jankowski, prezes Naczelnej Rady Lekarskiej.

## Rekordowa liczba komisji w Senacie. Ale PiS otrzyma niewiele
 - [https://www.rp.pl/polityka/art39472161-rekordowa-liczba-komisji-w-senacie-ale-pis-otrzyma-niewiele](https://www.rp.pl/polityka/art39472161-rekordowa-liczba-komisji-w-senacie-ale-pis-otrzyma-niewiele)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T02:00:00+00:00

Liczba komisji stałych w izbie refleksji ma wzrosnąć do rekordowego poziomu, jednak niewiele z nich przypadnie PiS.

## Rok 2024 to rok e-faktur i nowych podatków dla przedsiębiorców
 - [https://www.rp.pl/abc-firmy/art39471431-rok-2024-to-rok-e-faktur-i-nowych-podatkow-dla-przedsiebiorcow](https://www.rp.pl/abc-firmy/art39471431-rok-2024-to-rok-e-faktur-i-nowych-podatkow-dla-przedsiebiorcow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T02:00:00+00:00

Choć w przyszłym roku raczej nie czekają nas rewolucje podatkowe, to aktywność fiskusa nie osłabnie.

## Sondaż: Prezydent Andrzej Duda traci przez PiS
 - [https://www.rp.pl/polityka/art39472131-sondaz-prezydent-andrzej-duda-traci-przez-pis](https://www.rp.pl/polityka/art39472131-sondaz-prezydent-andrzej-duda-traci-przez-pis)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T02:00:00+00:00

Notowania głowy państwa słabną. Większość respondentów sondażu IBRiS negatywnie ocenia prezydenta, który traci głównie przez PiS.

## Sędzia Międzynarodowej Federacji Narciarskiej: Zdalnego oceniania skoków nie będzie
 - [https://www.rp.pl/skoki-narciarskie/art39472031-sedzia-miedzynarodowej-federacji-narciarskiej-zdalnego-oceniania-skokow-nie-bedzie](https://www.rp.pl/skoki-narciarskie/art39472031-sedzia-miedzynarodowej-federacji-narciarskiej-zdalnego-oceniania-skokow-nie-bedzie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T02:00:00+00:00

Zmiany sprzętowe to miecz obosieczny, bo pozwalają dalej odlecieć, ale utrudniają lądowanie i odjazd – mówi „Rz” sędzia Międzynarodowej Federacji Narciarskiej (FIS) Jarosław Poloczek.

## Trener Thurnbichler ma ból głowy
 - [https://www.rp.pl/skoki-narciarskie/art39471961-trener-thurnbichler-ma-bol-glowy](https://www.rp.pl/skoki-narciarskie/art39471961-trener-thurnbichler-ma-bol-glowy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T02:00:00+00:00

Start sezonu w Ruce pokazał słabą formę Polaków, ale nie zgasił optymizmu, że czeka nas zima pełna atrakcji.

## Trybunał Stanu za wybory kopertowe? Długie oczekiwanie na wyrok
 - [https://www.rp.pl/polityka/art39472171-trybunal-stanu-za-wybory-kopertowe-dlugie-oczekiwanie-na-wyrok](https://www.rp.pl/polityka/art39472171-trybunal-stanu-za-wybory-kopertowe-dlugie-oczekiwanie-na-wyrok)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T02:00:00+00:00

Kasacja premiera Morawieckiego ws. wyborów korespondencyjnych utknęła w NSA na trzy lata. Wciąż nie wyznaczono terminu rozprawy.

## Urzędy dla obywateli. Czy administracja wprowadzi elastyczne godziny pracy
 - [https://www.rp.pl/urzednicy/art39471411-urzedy-dla-obywateli-czy-administracja-wprowadzi-elastyczne-godziny-pracy](https://www.rp.pl/urzednicy/art39471411-urzedy-dla-obywateli-czy-administracja-wprowadzi-elastyczne-godziny-pracy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T02:00:00+00:00

Załatwianie spraw urzędowych nie powinno zmuszać interesanta do wzięcia urlopu.

## Zegarek w podatkowych kosztach firmy? Skarbówka się nie zgadza
 - [https://www.rp.pl/podatki/art39471391-zegarek-w-podatkowych-kosztach-firmy-skarbowka-sie-nie-zgadza](https://www.rp.pl/podatki/art39471391-zegarek-w-podatkowych-kosztach-firmy-skarbowka-sie-nie-zgadza)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T02:00:00+00:00

Przedsiębiorca nie zaliczy do kosztów uzyskania przychodów wydatków na zegarek używany podczas spotkań z klientami – to ostatnie stanowisko fiskusa.

## Jak rozliczyć prezenty i firmowe imprezy świąteczne
 - [https://www.rp.pl/podatki/art39462881-jak-rozliczyc-prezenty-i-firmowe-imprezy-swiateczne](https://www.rp.pl/podatki/art39462881-jak-rozliczyc-prezenty-i-firmowe-imprezy-swiateczne)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T01:00:00+00:00

Zorganizowanie przez pracodawcę wigilii czy przekazanie prezentów zarówno pracownikom i ich rodzinom, jak i współpracownikom lub kontrahentom może spowodować obowiązki w PIT i w zakresie składek ZUS.

## Kiedy trzeba zapłacić składki na ubezpieczenia
 - [https://www.rp.pl/zus/art39462971-kiedy-trzeba-zaplacic-skladki-na-ubezpieczenia](https://www.rp.pl/zus/art39462971-kiedy-trzeba-zaplacic-skladki-na-ubezpieczenia)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T01:00:00+00:00

Prezenty dla pracowników oprócz obciążeń związanych z zapłatą PIT mogą także wiązać się z zapłatą składki ZUS na ubezpieczenia społeczne i zdrowotne.

## Odpowiednie finansowanie to wyższa jakość szpitali
 - [https://www.rp.pl/zdrowie/art39472391-odpowiednie-finansowanie-to-wyzsza-jakosc-szpitali](https://www.rp.pl/zdrowie/art39472391-odpowiednie-finansowanie-to-wyzsza-jakosc-szpitali)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T00:00:00+00:00

Goście debaty zorganizowanej na zakończenie rankingu liderów zarządzania BFF, zastanawiali się, czy nowa ustawa o jakości w opiece zdrowotnej i bezpieczeństwie pacjenta przyniesie korzyści polskim szpitalom i chorym.

## Razem dla Planety, czyli chemia dla zrównoważonej przyszłości
 - [https://www.rp.pl/biznes/art39472401-razem-dla-planety-czyli-chemia-dla-zrownowazonej-przyszlosci](https://www.rp.pl/biznes/art39472401-razem-dla-planety-czyli-chemia-dla-zrownowazonej-przyszlosci)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T00:00:00+00:00

Diamentowe Planety w rękach liderów zrównoważonego rozwoju branży chemicznej, czyli wielki finał programu BASF dla klientów „Razem dla Planety”.

## Zaskoczenie nowymi usługami Orange
 - [https://www.rp.pl/biznes/art39472381-zaskoczenie-nowymi-uslugami-orange](https://www.rp.pl/biznes/art39472381-zaskoczenie-nowymi-uslugami-orange)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-27T00:00:00+00:00

Orange Polska od niedawna oferuje nowy rodzaj usług. Dowiedzieliśmy się o co chodzi i kto na tym skorzysta.

