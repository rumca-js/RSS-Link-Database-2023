# Source:The Intercept, URL:https://theintercept.com/feed/?lang=en, language:en-US

## A Big-Money Operation Purged Critics of Israel From the Democratic Party
 - [https://theintercept.com/2023/11/27/israel-democrats-aipac-book](https://theintercept.com/2023/11/27/israel-democrats-aipac-book)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2023-11-27T19:54:40+00:00

<p>How the Israel lobby moved to quash rising dissent in Congress against Israel’s apartheid regime.</p>
<p>The post <a href="https://theintercept.com/2023/11/27/israel-democrats-aipac-book/" rel="nofollow">A Big-Money Operation Purged Critics of Israel From the Democratic Party</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>

## NYPD Paid Out $30 Million in Misconduct Cases Before Litigation in First Half of 2023
 - [https://theintercept.com/2023/11/27/nypd-misconduct-pre-litigation-settlements](https://theintercept.com/2023/11/27/nypd-misconduct-pre-litigation-settlements)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2023-11-27T14:54:47+00:00

<p> Including the newly revealed $30 million, the NYPD paid out more than $80 million in misconduct cases in just the first six months of the year.</p>
<p>The post <a href="https://theintercept.com/2023/11/27/nypd-misconduct-pre-litigation-settlements/" rel="nofollow">NYPD Paid Out $30 Million in Misconduct Cases Before Litigation in First Half of 2023</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>

