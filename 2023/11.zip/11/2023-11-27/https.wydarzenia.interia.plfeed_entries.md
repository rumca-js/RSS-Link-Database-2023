# Source:Wydarzenia Interia, URL:https://wydarzenia.interia.pl/feed, language:pl-PL

## TOPR poszukuje turysty. Samotnie wyruszył w góry
 - [https://wydarzenia.interia.pl/kraj/news-topr-poszukuje-turysty-samotnie-wyruszyl-w-gory,nId,7175309](https://wydarzenia.interia.pl/kraj/news-topr-poszukuje-turysty-samotnie-wyruszyl-w-gory,nId,7175309)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T22:15:51+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-topr-poszukuje-turysty-samotnie-wyruszyl-w-gory,nId,7175309"><img align="left" alt="TOPR poszukuje turysty. Samotnie wyruszył w góry" src="https://i.iplsc.com/topr-poszukuje-turysty-samotnie-wyruszyl-w-gory/000I3MS08LD28Y4R-C321.jpg" /></a>Tatrzańskie Ochotnicze Pogotowie Ratunkowe rozpoczyna akcję poszukiwawczą. Zaginiony turysta wyruszył w sobotę na Czerwone Wierchy. Od tego dnia nie ma z nim kontaktu. W górach obowiązuje drugi stopień zagrożenia lawinowego. Idąc w wyższe partie należy odpowiednio się przygotować.</p><br clear="all" />

## Rosja się zbroi. Władimir Putin zwiększa wydatki na wojsko
 - [https://wydarzenia.interia.pl/zagranica/news-rosja-sie-zbroi-wladimir-putin-zwieksza-wydatki-na-wojsko,nId,7175302](https://wydarzenia.interia.pl/zagranica/news-rosja-sie-zbroi-wladimir-putin-zwieksza-wydatki-na-wojsko,nId,7175302)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T21:15:37+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-rosja-sie-zbroi-wladimir-putin-zwieksza-wydatki-na-wojsko,nId,7175302"><img align="left" alt="Rosja się zbroi. Władimir Putin zwiększa wydatki na wojsko" src="https://i.iplsc.com/rosja-sie-zbroi-wladimir-putin-zwieksza-wydatki-na-wojsko/000I3MLDNOGA05O4-C321.jpg" /></a>Władimir Putin podpisał projekt ustawy budżetowej na 2024 rok. Zagraniczne media ustaliły, że w dokumencie znalazły się zapisy o zwiększeniu wydatków na wojsko. Od stycznia prawie co trzeci rubel należący do państwa będzie przekazywany na rzecz armii. </p><br clear="all" />

## Rozejm przedłużony. Hamas ma uwolnić kolejnych zakładników
 - [https://wydarzenia.interia.pl/raport-wojna-w-izraelu/news-rozejm-przedluzony-hamas-ma-uwolnic-kolejnych-zakladnikow,nId,7175300](https://wydarzenia.interia.pl/raport-wojna-w-izraelu/news-rozejm-przedluzony-hamas-ma-uwolnic-kolejnych-zakladnikow,nId,7175300)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T21:02:38+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wojna-w-izraelu/news-rozejm-przedluzony-hamas-ma-uwolnic-kolejnych-zakladnikow,nId,7175300"><img align="left" alt="Rozejm przedłużony. Hamas ma uwolnić kolejnych zakładników" src="https://i.iplsc.com/rozejm-przedluzony-hamas-ma-uwolnic-kolejnych-zakladnikow/000I3MJQVHSMOLWS-C321.jpg" /></a>Zawieszenie broni pomiędzy Izraelem a Hamasem zostało przedłużone o dwa dni - podało Ministerstwo Spraw Zagranicznych Kataru. Jak zastrzegli Izraelczycy, warunkiem utrzymania przerwy w walkach jest uwalnianie przez Hamas kolejnych zakładników. </p><br clear="all" />

## Starogard: Sensacyjne odkrycie w lesie. Natrafił na przedmioty z epoki brązu
 - [https://wydarzenia.interia.pl/pomorskie/news-starogard-sensacyjne-odkrycie-w-lesie-natrafil-na-przedmioty,nId,7175295](https://wydarzenia.interia.pl/pomorskie/news-starogard-sensacyjne-odkrycie-w-lesie-natrafil-na-przedmioty,nId,7175295)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T20:39:29+00:00

<p><a href="https://wydarzenia.interia.pl/pomorskie/news-starogard-sensacyjne-odkrycie-w-lesie-natrafil-na-przedmioty,nId,7175295"><img align="left" alt="Starogard: Sensacyjne odkrycie w lesie. Natrafił na przedmioty z epoki brązu" src="https://i.iplsc.com/starogard-sensacyjne-odkrycie-w-lesie-natrafil-na-przedmioty/000I3MHOVQ5GTTNU-C321.jpg" /></a>Na terenie Nadleśnictwa Starogard znaleziono przedmioty pochodzące z epoki brązu. Odkrył je jeden z pasjonatów, który wyruszył na poszukiwania zaopatrzony w wykrywacz metali. Tak doszło do znalezienia przedmiotów mających około 3500 lat. W sieci zamieszczono ich zdjęcia.</p><br clear="all" />

## Premier Morawiecki: Marszałek Hołownia zaoferował nam dintojrę
 - [https://wydarzenia.interia.pl/kraj/news-premier-morawiecki-marszalek-holownia-zaoferowal-nam-dintojr,nId,7175275](https://wydarzenia.interia.pl/kraj/news-premier-morawiecki-marszalek-holownia-zaoferowal-nam-dintojr,nId,7175275)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T20:12:46+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-premier-morawiecki-marszalek-holownia-zaoferowal-nam-dintojr,nId,7175275"><img align="left" alt="Premier Morawiecki: Marszałek Hołownia zaoferował nam dintojrę" src="https://i.iplsc.com/premier-morawiecki-marszalek-holownia-zaoferowal-nam-dintojr/000I3MHYA07X76AU-C321.jpg" /></a>- Oferujemy zgodę i bardzo pozytywny program dla wszystkich Polaków; coś, co może nas połączyć, zamiast tych bardzo hałaśliwych, pełnych draki wydarzeń, w które obfituje Sejm - powiedział Mateusz Morawiecki w rozmowie na antenie TVP Info. Nowo zaprzysiężony premier nie szczędził słów krytyki wobec politycznych oponentów. Stwierdził m.in., że marszałek Sejmu &quot;w pierwszych dniach marszałek zafundował nam&quot; zemstę, dintojrę i mściwość. - To jest paliwo, na którym daleko nie pojedziemy - uznał.</p><br clear="all" />

## Niemcy: Nastoletni bracia szukali bursztynu. Zaskoczył ich nagły przypływ
 - [https://wydarzenia.interia.pl/zagranica/news-niemcy-nastoletni-bracia-szukali-bursztynu-zaskoczyl-ich-nag,nId,7175265](https://wydarzenia.interia.pl/zagranica/news-niemcy-nastoletni-bracia-szukali-bursztynu-zaskoczyl-ich-nag,nId,7175265)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T19:57:19+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niemcy-nastoletni-bracia-szukali-bursztynu-zaskoczyl-ich-nag,nId,7175265"><img align="left" alt="Niemcy: Nastoletni bracia szukali bursztynu. Zaskoczył ich nagły przypływ" src="https://i.iplsc.com/niemcy-nastoletni-bracia-szukali-bursztynu-zaskoczyl-ich-nag/000I3M8MH7LGFQJF-C321.jpg" /></a>Trzech braci szukało bursztynu wzdłuż nabrzeża w północnych Niemczech. Zajęcie tak pochłonęło nastolatków, że nie zauważyli wzbierającej wokół wody. Pomoc dotarła do nich niemal w ostatniej chwili.</p><br clear="all" />

## J. Sasin o dacie budowy elektrowni jądrowej w Polsce
 - [https://wydarzenia.interia.pl/kraj/news-budowa-elektrowni-jadrowej-w-polsce-jacek-sasin-o-dacie,nId,7175245](https://wydarzenia.interia.pl/kraj/news-budowa-elektrowni-jadrowej-w-polsce-jacek-sasin-o-dacie,nId,7175245)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T18:55:58+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-budowa-elektrowni-jadrowej-w-polsce-jacek-sasin-o-dacie,nId,7175245"><img align="left" alt="J. Sasin o dacie budowy elektrowni jądrowej w Polsce" src="https://i.iplsc.com/j-sasin-o-dacie-budowy-elektrowni-jadrowej-w-polsce/000I3LZGMBPM1BGE-C321.jpg" /></a>- Etap przygotowawczy mamy za sobą. Polskie i koreańskie firmy są w stanie zbudować elektrownię atomową Pątnów-Konin - powiedział w poniedziałkowym &quot;Gościu Wydarzeń&quot; Jacek Sasin. Według polityka PiS wbicie pierwszej łopaty w 2028 roku to realny termin.</p><br clear="all" />

## Kartonowy Łukaszenka przed sklepem w Rosji. Wita klientów
 - [https://wydarzenia.interia.pl/zagranica/news-kartonowy-lukaszenka-przed-sklepem-w-rosji-wita-klientow,nId,7175062](https://wydarzenia.interia.pl/zagranica/news-kartonowy-lukaszenka-przed-sklepem-w-rosji-wita-klientow,nId,7175062)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T18:39:30+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-kartonowy-lukaszenka-przed-sklepem-w-rosji-wita-klientow,nId,7175062"><img align="left" alt="Kartonowy Łukaszenka przed sklepem w Rosji. Wita klientów" src="https://i.iplsc.com/kartonowy-lukaszenka-przed-sklepem-w-rosji-wita-klientow/000I3LK6AFB88GMT-C321.jpg" /></a>Tuż przed jednym ze sklepów w Rosji, w którym sprzedawane są białoruskie towary, stanął Alaksandr Łukaszenka. Kartonowa podobizna dyktatora Białorusi w nieco &quot;podrasowanej&quot; wersji ma zachęcać do zakupów. Czy skutecznie? Nie wiadomo, jednak sam fakt widoku uśmiechniętego lidera reżimu z podniesionym do góry kciukiem może przyciągać wzrok ciekawskich.</p><br clear="all" />

## Rewolucja w regionalnych strukturach PiS. Decyzja zapadła
 - [https://wydarzenia.interia.pl/kraj/news-rewolucja-w-regionalnych-strukturach-pis-decyzja-zapadla,nId,7175252](https://wydarzenia.interia.pl/kraj/news-rewolucja-w-regionalnych-strukturach-pis-decyzja-zapadla,nId,7175252)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T18:16:18+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-rewolucja-w-regionalnych-strukturach-pis-decyzja-zapadla,nId,7175252"><img align="left" alt="Rewolucja w regionalnych strukturach PiS. Decyzja zapadła" src="https://i.iplsc.com/rewolucja-w-regionalnych-strukturach-pis-decyzja-zapadla/000GJ1UVJPXL63WE-C321.jpg" /></a>PiS ma 17 nowych szefów okręgów, które odpowiadają województwom, w tym oddzielnie dla Warszawy. Dotychczas było ich 94. Partia chciała, aby szefami struktur zostali w dużej mierze politycy młodszego pokolenia.</p><br clear="all" />

## Rząd Mateusza Morawieckiego zaprzysiężony. Lawina komentarzy w sieci
 - [https://wydarzenia.interia.pl/kraj/news-rzad-mateusza-morawieckiego-zaprzysiezony-lawina-komentarzy-,nId,7175125](https://wydarzenia.interia.pl/kraj/news-rzad-mateusza-morawieckiego-zaprzysiezony-lawina-komentarzy-,nId,7175125)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T18:08:53+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-rzad-mateusza-morawieckiego-zaprzysiezony-lawina-komentarzy-,nId,7175125"><img align="left" alt="Rząd Mateusza Morawieckiego zaprzysiężony. Lawina komentarzy w sieci" src="https://i.iplsc.com/rzad-mateusza-morawieckiego-zaprzysiezony-lawina-komentarzy/000I3LWM0PLTCBJS-C321.jpg" /></a>Rząd Mateusza Morawieckiego został zaprzysiężony w poniedziałkowe popołudnie, a w sieci pojawiły się już pierwsze komentarze. &quot;Polacy zagłosowali za zmianą na lepsze, nie za kiepskim, dwutygodniowym kabaretem&quot; - ocenia Władysław Kosiniak-Kamysz. Z kolei Marcin Przydacz zwrócił uwagę na brak marszałków Sejmu i Senatu podczas uroczystości w Pałacu Prezydenckim.</p><br clear="all" />

## Kandyduje na Rzecznika Praw Dziecka. Zielone światło od komisji w Sejmie
 - [https://wydarzenia.interia.pl/kraj/news-kandyduje-na-rzecznika-praw-dziecka-zielone-swiatlo-od-komis,nId,7174978](https://wydarzenia.interia.pl/kraj/news-kandyduje-na-rzecznika-praw-dziecka-zielone-swiatlo-od-komis,nId,7174978)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T17:47:47+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-kandyduje-na-rzecznika-praw-dziecka-zielone-swiatlo-od-komis,nId,7174978"><img align="left" alt="Kandyduje na Rzecznika Praw Dziecka. Zielone światło od komisji w Sejmie" src="https://i.iplsc.com/kandyduje-na-rzecznika-praw-dziecka-zielone-swiatlo-od-komis/000I3LWCT1LXVMHM-C321.jpg" /></a>Monika Horna-Cieślak, kandydatka na urząd Rzecznika Praw Dziecka, uzyskała pozytywną opinię na połączonym posiedzeniu sejmowych komisji: Edukacji, Nauki i Młodzieży oraz Sprawiedliwości i Praw Człowieka. Jej kandydatura została zgłoszona przez Koalicję Obywatelską, Trzecią Drogą i Lewicę. </p><br clear="all" />

## Handel, budownictwo, szpitale - fala bankructw w Niemczech
 - [https://wydarzenia.interia.pl/zagranica/news-handel-budownictwo-szpitale-fala-bankructw-w-niemczech,nId,7175145](https://wydarzenia.interia.pl/zagranica/news-handel-budownictwo-szpitale-fala-bankructw-w-niemczech,nId,7175145)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T17:38:26+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-handel-budownictwo-szpitale-fala-bankructw-w-niemczech,nId,7175145"><img align="left" alt="Handel, budownictwo, szpitale - fala bankructw w Niemczech" src="https://i.iplsc.com/handel-budownictwo-szpitale-fala-bankructw-w-niemczech/000I3LUZCRTSLMDY-C321.jpg" /></a>Słaba koniunktura gospodarcza odciska swoje piętno na firmach. Coraz więcej dużych przedsiębiorstw bankrutuje, także w sektorze zdrowia. Do września 2023 roku stan upadłości ogłosiło łącznie dwanaście dużych przedsiębiorstw tekstylnych i detalicznych branży modowej, a także sześć szpitali – wynika z badania ubezpieczyciela Alianze Trade.</p><br clear="all" />

## Zakaz handlu w niedziele. Sejmowa komisja za zmianami w prawie
 - [https://wydarzenia.interia.pl/kraj/news-zakaz-handlu-w-niedziele-sejmowa-komisja-za-zmianami-w-prawi,nId,7175236](https://wydarzenia.interia.pl/kraj/news-zakaz-handlu-w-niedziele-sejmowa-komisja-za-zmianami-w-prawi,nId,7175236)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T17:24:19+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-zakaz-handlu-w-niedziele-sejmowa-komisja-za-zmianami-w-prawi,nId,7175236"><img align="left" alt="Zakaz handlu w niedziele. Sejmowa komisja za zmianami w prawie" src="https://i.iplsc.com/zakaz-handlu-w-niedziele-sejmowa-komisja-za-zmianami-w-prawi/000FZ899M2IC99HN-C321.jpg" /></a>Sejmowa komisja gospodarki przyjęła projekt Polski 2050 dotyczący zmian w zakazie handlu w niedziele. Jak przekazał Arkadiusz Pączka, wiceszef Federacji Przedsiębiorców Polskich, pomysł zmian w prawie zakłada, że w tegorocznym grudniu byłyby dwie niedziele handlowe, a w wigilię - wypadającą również w niedzielę - sklepy byłyby zamknięte.</p><br clear="all" />

## Nowy wirus w Europie. Brytyjczycy wykryli infekcję u mężczyzny
 - [https://wydarzenia.interia.pl/zagranica/news-nowy-wirus-w-europie-brytyjczycy-wykryli-infekcje-u-mezczyzn,nId,7175073](https://wydarzenia.interia.pl/zagranica/news-nowy-wirus-w-europie-brytyjczycy-wykryli-infekcje-u-mezczyzn,nId,7175073)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T17:00:20+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-nowy-wirus-w-europie-brytyjczycy-wykryli-infekcje-u-mezczyzn,nId,7175073"><img align="left" alt="Nowy wirus w Europie. Brytyjczycy wykryli infekcję u mężczyzny" src="https://i.iplsc.com/nowy-wirus-w-europie-brytyjczycy-wykryli-infekcje-u-mezczyzn/000I3LK2OYQSUWY4-C321.jpg" /></a>Brytyjska Agencja ds. Bezpieczeństwa Zdrowia poinformowała o wykryciu przypadku zakażenia człowieka wirusem A(H1N2)v. Jest to szczep grypy podobny do wirusów rozprzestrzeniających się u świń. Infekcja, którą wykryto w Wielkiej Brytanii, jest pierwszym takim zdarzeniem w tym kraju. Na razie nie poinformowano, czy zakażony miał kontakt ze zwierzętami.</p><br clear="all" />

## Prezydent Andrzej Duda: Budowa elektrowni atomowej ma wymiar historyczny
 - [https://wydarzenia.interia.pl/kraj/news-prezydent-andrzej-duda-budowa-elektrowni-atomowej-ma-wymiar-,nId,7175070](https://wydarzenia.interia.pl/kraj/news-prezydent-andrzej-duda-budowa-elektrowni-atomowej-ma-wymiar-,nId,7175070)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T16:25:17+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-prezydent-andrzej-duda-budowa-elektrowni-atomowej-ma-wymiar-,nId,7175070"><img align="left" alt="Prezydent Andrzej Duda: Budowa elektrowni atomowej ma wymiar historyczny" src="https://i.iplsc.com/prezydent-andrzej-duda-budowa-elektrowni-atomowej-ma-wymiar/000I3LBVG6GQDM3J-C321.jpg" /></a>- Rozpoczyna się w Polsce nowa era energetyczna, era atomowa (...). Budowa elektrowni atomowej ma wymiar historyczny - powiedział prezydent podczas zaprzysiężenia nowego rządu Mateusza Morawieckiego. Andrzej Duda wskazywał na wyzwania, przed jakimi stoi nowa Rada Ministrów.</p><br clear="all" />

## Pałac Prezydencki. Zaprzysiężenie rządu premiera Mateusza Morawieckiego
 - [https://wydarzenia.interia.pl/kraj/news-nowy-rzad-mateusza-morawieckiego-zaprzysiezenie-u-prezydenta,nId,7175038](https://wydarzenia.interia.pl/kraj/news-nowy-rzad-mateusza-morawieckiego-zaprzysiezenie-u-prezydenta,nId,7175038)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T15:34:06+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-nowy-rzad-mateusza-morawieckiego-zaprzysiezenie-u-prezydenta,nId,7175038"><img align="left" alt=" Pałac Prezydencki. Zaprzysiężenie rządu premiera Mateusza Morawieckiego" src="https://i.iplsc.com/palac-prezydencki-zaprzysiezenie-rzadu-premiera-mateusza-mor/000I3L6FOJNOIHUV-C321.jpg" /></a>Prezydent RP Andrzej Duda zaprzysiągł gabinet Mateusza Morawieckiego, którego wcześniej desygnował na stanowisko szefa rządu. Od tej chwili premier ma dwa tygodnie, by uzyskać wotum zaufania od Sejmu, gdzie większość ma obecna opozycja. Kilka dni temu Morawiecki zapowiedział, że porozmawia o terminie swojego expose z marszałkiem izby niższej Szymonem Hołownią.</p><br clear="all" />

## Jeden błąd i można stracić emeryturę. Od grudnia nowe limity
 - [https://wydarzenia.interia.pl/kraj/news-jeden-blad-i-mozna-stracic-emeryture-od-grudnia-nowe-limity,nId,7174522](https://wydarzenia.interia.pl/kraj/news-jeden-blad-i-mozna-stracic-emeryture-od-grudnia-nowe-limity,nId,7174522)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T15:28:06+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-jeden-blad-i-mozna-stracic-emeryture-od-grudnia-nowe-limity,nId,7174522"><img align="left" alt="Jeden błąd i można stracić emeryturę. Od grudnia nowe limity" src="https://i.iplsc.com/jeden-blad-i-mozna-stracic-emeryture-od-grudnia-nowe-limity/000GN3QLDJMKWXXY-C321.jpg" /></a>Od 1 grudnia 2023 roku obowiązywać będą nowe limity dorabiania do emerytury i renty. Zbyt wysokie zarobki mogą doprowadzić do zmniejszenia lub zawieszenia wypłat z ZUS. Ile będzie można dorobić do emerytury i renty od grudnia 2023 roku?</p><br clear="all" />

## Plan posiedzenia Sejmu budzi emocje. Na liście "lex Tusk", in vitro i komisje śledcze
 - [https://wydarzenia.interia.pl/kraj/news-plan-posiedzenia-sejmu-budzi-emocje-na-liscie-lex-tusk-in-vi,nId,7175004](https://wydarzenia.interia.pl/kraj/news-plan-posiedzenia-sejmu-budzi-emocje-na-liscie-lex-tusk-in-vi,nId,7175004)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T15:15:13+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-plan-posiedzenia-sejmu-budzi-emocje-na-liscie-lex-tusk-in-vi,nId,7175004"><img align="left" alt="Plan posiedzenia Sejmu budzi emocje. Na liście &quot;lex Tusk&quot;, in vitro i komisje śledcze " src="https://i.iplsc.com/plan-posiedzenia-sejmu-budzi-emocje-na-liscie-lex-tusk-in-vi/000I3K7PA1DRRLMC-C321.jpg" /></a>&quot;Lex Tusk&quot;, in vitro, wybór Rzecznika Praw Dziecka - to tylko cześć punktów rozpoczynającego się we wtorek posiedzenia Sejmu. Posłowie zajmą się też sprawą powołania trzech komisji śledczych. Według harmonogramu będą debatować nad nimi dziewięć godzin.</p><br clear="all" />

## Sensacyjne narodziny. To zwierzę jest na wagę złota
 - [https://wydarzenia.interia.pl/ciekawostki/news-sensacyjne-narodziny-to-zwierze-jest-na-wage-zlota,nId,7175015](https://wydarzenia.interia.pl/ciekawostki/news-sensacyjne-narodziny-to-zwierze-jest-na-wage-zlota,nId,7175015)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T14:55:51+00:00

<p><a href="https://wydarzenia.interia.pl/ciekawostki/news-sensacyjne-narodziny-to-zwierze-jest-na-wage-zlota,nId,7175015"><img align="left" alt="Sensacyjne narodziny. To zwierzę jest na wagę złota" src="https://i.iplsc.com/sensacyjne-narodziny-to-zwierze-jest-na-wage-zlota/000I3KYUFU0HFN15-C321.jpg" /></a>To jedno z najrzadszych zwierząt na świecie: na wolności żyje ich zaledwie kilkaset. Tym większą sensacją jest fakt, że nosorożcom czarnym udało się rozmnożyć w jednym z ogrodów zoologicznych w Wielkiej Brytanii. W dodatku narodziny miały miejsce w środku dnia, czego nie spodziewali się nawet specjaliści.</p><br clear="all" />

## Nowy rząd Mateusza Morawieckiego. Wszystko już jasne
 - [https://wydarzenia.interia.pl/kraj/news-nowy-rzad-mateusza-morawieckiego-wszystko-juz-jasne,nId,7175009](https://wydarzenia.interia.pl/kraj/news-nowy-rzad-mateusza-morawieckiego-wszystko-juz-jasne,nId,7175009)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T14:49:13+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-nowy-rzad-mateusza-morawieckiego-wszystko-juz-jasne,nId,7175009"><img align="left" alt="Nowy rząd Mateusza Morawieckiego. Wszystko już jasne" src="https://i.iplsc.com/nowy-rzad-mateusza-morawieckiego-wszystko-juz-jasne/000I3L0XFNYTC83S-C321.jpg" /></a>Marlena Maląg, Mariusz Błaszczak, Paweł Szefernaker, Dominika Chorosińska i Alvin Gajadhur - między innymi te osoby znajdą się w rządzie tworzonym przez Mateusza Morawieckiego. W poniedziałek premier skierował do prezydenta Andrzeja Dudy wniosek o powołanie nowej Rady Ministrów, w której ponad połowę będą stanowiły kobiety. Tym samym potwierdziły się ustalenia Interii ws. obsady ministerialnych stanowisk.</p><br clear="all" />

## Zawieszenie wojny w Ukrainie? Eksperci: Putin nie zgodzi się na pokój
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-zawieszenie-wojny-w-ukrainie-eksperci-putin-nie-zgodzi-sie-n,nId,7174935](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-zawieszenie-wojny-w-ukrainie-eksperci-putin-nie-zgodzi-sie-n,nId,7174935)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T14:31:49+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-zawieszenie-wojny-w-ukrainie-eksperci-putin-nie-zgodzi-sie-n,nId,7174935"><img align="left" alt="Zawieszenie wojny w Ukrainie? Eksperci: Putin nie zgodzi się na pokój" src="https://i.iplsc.com/zawieszenie-wojny-w-ukrainie-eksperci-putin-nie-zgodzi-sie-n/000I3J0SYPLXVLD3-C321.jpg" /></a>W związku z niepowodzeniem kontrofensywy Sił Zbrojnych Ukrainy i nasileniem działań ofensywnych Rosjan coraz głośniejsze stają się wypowiedzi nawołujące do zmuszenia władz w Kijowie do negocjacji z Kremlem. Zdaniem ekspertów z &quot;Foreign Policy&quot; może to być jednak znacznie trudniejsze do realizacji, niż wydaje się politykom.</p><br clear="all" />

## Wprowadzili restrykcje jako pierwsi na świecie. Nagle rezygnują z historycznej decyzji
 - [https://wydarzenia.interia.pl/zagranica/news-wprowadzili-restrykcje-jako-pierwsi-na-swiecie-nagle-rezygnu,nId,7174928](https://wydarzenia.interia.pl/zagranica/news-wprowadzili-restrykcje-jako-pierwsi-na-swiecie-nagle-rezygnu,nId,7174928)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T13:55:49+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wprowadzili-restrykcje-jako-pierwsi-na-swiecie-nagle-rezygnu,nId,7174928"><img align="left" alt="Wprowadzili restrykcje jako pierwsi na świecie. Nagle rezygnują z historycznej decyzji " src="https://i.iplsc.com/wprowadzili-restrykcje-jako-pierwsi-na-swiecie-nagle-rezygnu/000I3J32EF0NBL4R-C321.jpg" /></a>Nowa Zelandia zrezygnuje z wprowadzenia zakazu sprzedaży papierosów dla młodych osób - ogłosiła nowa minister finansów Nicola Willis. Rząd szuka środków, które mają pozwolić na zmianę polityki podatkowej. Decyzja spotkała się z krytyką ekspertów ds. zdrowia.</p><br clear="all" />

## Będzie wniosek o ponad trzy miliardy złotych dla mediów publicznych
 - [https://wydarzenia.interia.pl/kraj/news-bedzie-wniosek-o-ponad-trzy-miliardy-zlotych-dla-mediow-publ,nId,7174919](https://wydarzenia.interia.pl/kraj/news-bedzie-wniosek-o-ponad-trzy-miliardy-zlotych-dla-mediow-publ,nId,7174919)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T13:49:28+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-bedzie-wniosek-o-ponad-trzy-miliardy-zlotych-dla-mediow-publ,nId,7174919"><img align="left" alt="Będzie wniosek o ponad trzy miliardy złotych dla mediów publicznych" src="https://i.iplsc.com/bedzie-wniosek-o-ponad-trzy-miliardy-zlotych-dla-mediow-publ/000I3JU4AISI448Q-C321.jpg" /></a>Szef Rady Mediów Narodowych Krzysztof Czabański chce wystąpić do nowo powołanego rządu Mateusza Morawieckiego z wnioskiem o zwiększenie rekompensaty dla mediów publicznych - dowiedziała się Interia. Z obliczeń Rady wynika, że aby media publiczne mogły wypełniać swoją misję, kwota dotacji z budżetu powinna wynieść ponad trzy miliardy złotych. Większość miałaby trafić do TVP.</p><br clear="all" />

## Zbigniew Ziobro poza rządem. Wiemy, kto go zastąpi
 - [https://wydarzenia.interia.pl/kraj/news-zbigniew-ziobro-poza-rzadem-wiemy-kto-go-zastapi,nId,7174931](https://wydarzenia.interia.pl/kraj/news-zbigniew-ziobro-poza-rzadem-wiemy-kto-go-zastapi,nId,7174931)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T13:35:08+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-zbigniew-ziobro-poza-rzadem-wiemy-kto-go-zastapi,nId,7174931"><img align="left" alt="Zbigniew Ziobro poza rządem. Wiemy, kto go zastąpi" src="https://i.iplsc.com/zbigniew-ziobro-poza-rzadem-wiemy-kto-go-zastapi/000I3IQF8LE5KD7X-C321.jpg" /></a>W nowym rządzie Mateusza Morawieckiego dominować będą debiutanci. Znanych polityków w niektórych resortach zastąpią mniejsi dotychczas gracze na scenie politycznej. W nowym gabinecie PiS zabraknie Zbigniewa Ziobry. Zastąpi go kolega z partii Marcin Warchoł.</p><br clear="all" />

## Rada Mediów Narodowych zdecydowała. Zmiany w TVP, Polskim Radiu i PAP
 - [https://wydarzenia.interia.pl/kraj/news-rada-mediow-narodowych-zdecydowala-zmiany-w-tvp-polskim-radi,nId,7174909](https://wydarzenia.interia.pl/kraj/news-rada-mediow-narodowych-zdecydowala-zmiany-w-tvp-polskim-radi,nId,7174909)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T13:14:17+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-rada-mediow-narodowych-zdecydowala-zmiany-w-tvp-polskim-radi,nId,7174909"><img align="left" alt="Rada Mediów Narodowych zdecydowała. Zmiany w TVP, Polskim Radiu i PAP" src="https://i.iplsc.com/rada-mediow-narodowych-zdecydowala-zmiany-w-tvp-polskim-radi/000HWVZ64A1DQKQX-C321.jpg" /></a>Jest zgoda Rady Mediów Narodowych na dokonanie zmian w statutach Telewizji Polskiej, Polskiego Radia oraz Polskiej Agencji Prasowej. Zmiany przewidują, że &quot;w razie otwarcia likwidacji&quot; TVP, PR i PAP &quot;likwidatorami są wszyscy członkowie Zarządu oraz kierownik komórki organizacyjnej Spółki zajmującej się obsługą prawną&quot;. To ruch wyprzedzający, ponieważ nieoficjalnie wiadomo, że postawienie państwowych spółek medialnych w stan likwidacji to jeden ze scenariuszy zmian w tych instytucjach.</p><br clear="all" />

## Opozycja nie musi czekać do 14 grudnia na powołania premiera. Nowy pomysł
 - [https://wydarzenia.interia.pl/kraj/news-opozycja-nie-musi-czekac-do-14-grudnia-na-powolania-premiera,nId,7174468](https://wydarzenia.interia.pl/kraj/news-opozycja-nie-musi-czekac-do-14-grudnia-na-powolania-premiera,nId,7174468)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T13:09:14+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-opozycja-nie-musi-czekac-do-14-grudnia-na-powolania-premiera,nId,7174468"><img align="left" alt="Opozycja nie musi czekać do 14 grudnia na powołania premiera. Nowy pomysł" src="https://i.iplsc.com/opozycja-nie-musi-czekac-do-14-grudnia-na-powolania-premiera/000I3FJNUQ9099K5-C321.jpg" /></a>Dzisiejsze zaprzysiężenie rządu oznacza, że Mateusz Morawiecki będzie miał 14 dni na zdobycie wotum zaufania w Sejmie. Jeśli go nie uzyska, rozpocznie się tzw. drugi krok, w którym to niższa izba wybierze premiera, zapewne Donalda Tuska. Według przewidywań nastąpi to 13 lub 14 grudnia, a więc w dniu szczytu Rady Europejskiej. Pojawił się pomysł, jak przyspieszyć tę procedurę.</p><br clear="all" />

## Tajlandia: Tragedia na weselu. Pan młody zastrzelił żonę i gości
 - [https://wydarzenia.interia.pl/zagranica/news-tajlandia-tragedia-na-weselu-pan-mlody-zastrzelil-zone-i-gos,nId,7174886](https://wydarzenia.interia.pl/zagranica/news-tajlandia-tragedia-na-weselu-pan-mlody-zastrzelil-zone-i-gos,nId,7174886)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T13:06:20+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-tajlandia-tragedia-na-weselu-pan-mlody-zastrzelil-zone-i-gos,nId,7174886"><img align="left" alt="Tajlandia: Tragedia na weselu. Pan młody zastrzelił żonę i gości" src="https://i.iplsc.com/tajlandia-tragedia-na-weselu-pan-mlody-zastrzelil-zone-i-gos/000I3IBY7ML3LUFL-C321.jpg" /></a>Były żołnierz piechoty morskiej zastrzelił swoją nowo poślubioną żonę i trzy inne osoby, po czym popełnił samobójstwo w czasie wesela w tajlandzkim regionie Isan. Do śmiertelnego zajścia doszło w chwili, w której w Tajlandii toczy się debata nad ograniczeniem obywatelom dostępu do broni.</p><br clear="all" />

## Komunikat Watykanu ws. stanu zdrowia papieża. "Ogranicza swoją aktywność"
 - [https://wydarzenia.interia.pl/zagranica/news-komunikat-watykanu-ws-stanu-zdrowia-papieza-ogranicza-swoja-,nId,7174855](https://wydarzenia.interia.pl/zagranica/news-komunikat-watykanu-ws-stanu-zdrowia-papieza-ogranicza-swoja-,nId,7174855)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T12:50:57+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-komunikat-watykanu-ws-stanu-zdrowia-papieza-ogranicza-swoja-,nId,7174855"><img align="left" alt="Komunikat Watykanu ws. stanu zdrowia papieża. &quot;Ogranicza swoją aktywność&quot;" src="https://i.iplsc.com/komunikat-watykanu-ws-stanu-zdrowia-papieza-ogranicza-swoja/000I3HVH2LR49Y2D-C321.jpg" /></a>- Aby ułatwić papieżowi powrót do zdrowia, niektóre ważne zobowiązania zaplanowane na te dni zostały przełożone - poinformował watykański rzecznik Matteo Bruni. Głowa Kościoła katolickiego od kilku dni choruje i przyjmuje dożylnie antybiotyki. Jak jednak zapewnia Watykan, stan papieża jest stabilny, a jego dalsze zobowiązania nie zostały odwołane.</p><br clear="all" />

## Afera w ukraińskim wojsku. Żywność dla żołnierzy sprzedawana w sklepach
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-afera-w-ukrainskim-wojsku-zywnosc-dla-zolnierzy-sprzedawana-,nId,7174861](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-afera-w-ukrainskim-wojsku-zywnosc-dla-zolnierzy-sprzedawana-,nId,7174861)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T12:46:29+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-afera-w-ukrainskim-wojsku-zywnosc-dla-zolnierzy-sprzedawana-,nId,7174861"><img align="left" alt="Afera w ukraińskim wojsku. Żywność dla żołnierzy sprzedawana w sklepach" src="https://i.iplsc.com/afera-w-ukrainskim-wojsku-zywnosc-dla-zolnierzy-sprzedawana/000I3H66FPBIKCYT-C321.jpg" /></a>Ukraińskie Państwowe Biuro Śledcze i Służby Bezpieczeństwa Ukrainy rozbiły grupę przestępczą zajmującą się nielegalną sprzedażą produktów przeznaczonych dla wojska. Żywność trafiała do prywatnych sklepów, restauracji i na lokalne bazary.</p><br clear="all" />

## Krytyka Zełenskiego i dowódców. Ukraińcy na froncie nie kryją frustracji
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-krytyka-zelenskiego-i-dowodcow-ukraincy-na-froncie-nie-kryja,nId,7174834](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-krytyka-zelenskiego-i-dowodcow-ukraincy-na-froncie-nie-kryja,nId,7174834)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T12:34:50+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-krytyka-zelenskiego-i-dowodcow-ukraincy-na-froncie-nie-kryja,nId,7174834"><img align="left" alt="Krytyka Zełenskiego i dowódców. Ukraińcy na froncie nie kryją frustracji" src="https://i.iplsc.com/krytyka-zelenskiego-i-dowodcow-ukraincy-na-froncie-nie-kryja/000I3H4KJLD15MQS-C321.jpg" /></a>Ukraińscy żołnierze walczą z rosyjskimi najeźdźcami od 21 miesięcy. Mimo wsparcia Zachodu, m.in. ciężkiej broni, ukraińscy żołnierze wskazują na porażki na froncie, złe decyzje dowództwa i poważne problemy w logistyce. Krytykują generałów i Wołodymyra Zełenskiego.</p><br clear="all" />

## Tragedia na drodze. Nie żyje 10-latek
 - [https://wydarzenia.interia.pl/wielkopolskie/news-tragedia-na-drodze-nie-zyje-10-latek,nId,7174862](https://wydarzenia.interia.pl/wielkopolskie/news-tragedia-na-drodze-nie-zyje-10-latek,nId,7174862)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T12:31:12+00:00

<p><a href="https://wydarzenia.interia.pl/wielkopolskie/news-tragedia-na-drodze-nie-zyje-10-latek,nId,7174862"><img align="left" alt="Tragedia na drodze. Nie żyje 10-latek" src="https://i.iplsc.com/tragedia-na-drodze-nie-zyje-10-latek/000HMNCR2VC15MRX-C321.jpg" /></a>Tragiczne zdarzenie w województwie wielkopolskim. W sobotę na drodze między Nową Wsią i Pawłowicami zderzyły się dwa samochody osobowe. W wypadku ucierpiały cztery osoby, w tym dwoje dzieci. - Po kilku godzinach otrzymaliśmy tragiczną informację ze szpitala w Poznaniu, że 10-letni chłopiec zmarł na skutek odniesionych obrażeń - przekazała Interii oficer prasowa Komendy Miejskiej Policji w Lesznie asp. szt. Monika Żymełka.</p><br clear="all" />

## Pogoda wmieszała się w wojnę. Obie strony mocno to odczuły
 - [https://wydarzenia.interia.pl/zagranica/news-pogoda-wmieszala-sie-w-wojne-obie-strony-mocno-to-odczuly,nId,7174799](https://wydarzenia.interia.pl/zagranica/news-pogoda-wmieszala-sie-w-wojne-obie-strony-mocno-to-odczuly,nId,7174799)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T11:44:08+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-pogoda-wmieszala-sie-w-wojne-obie-strony-mocno-to-odczuly,nId,7174799"><img align="left" alt="Pogoda wmieszała się w wojnę. Obie strony mocno to odczuły" src="https://i.iplsc.com/pogoda-wmieszala-sie-w-wojne-obie-strony-mocno-to-odczuly/000I3GHQ281G9THX-C321.jpg" /></a>Ponad dwa tysiące miejscowości w Ukrainie nie ma prądu, po tym jak w kraju doszło do potężnego załamania pogody. Osłabiona przez ciągłe ataki wroga ukraińska infrastruktura została dodatkowo uszkodzona przez potężne śnieżyce. Miejscami tworzą się zaspy wysokie na dwa metry. Silny wiatr uszkodził między innymi największą flagę w kraju, którą trzeba było zdjęć z masztu. Jednak nie tylko Ukraina zmaga się z ciężkimi warunkami. Na okupowanym przez Rosjan wybrzeżu Krymu szaleje sztorm. Sama Rosja również odczuła uderzenie pogody - prawie dwa...</p><br clear="all" />

## Konflikt między polskim a niemieckim Kościołem. "Złośliwe oczernianie"
 - [https://wydarzenia.interia.pl/zagranica/news-konflikt-miedzy-polskim-a-niemieckim-kosciolem-zlosliwe-ocze,nId,7174786](https://wydarzenia.interia.pl/zagranica/news-konflikt-miedzy-polskim-a-niemieckim-kosciolem-zlosliwe-ocze,nId,7174786)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T11:41:37+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-konflikt-miedzy-polskim-a-niemieckim-kosciolem-zlosliwe-ocze,nId,7174786"><img align="left" alt="Konflikt między polskim a niemieckim Kościołem. &quot;Złośliwe oczernianie&quot;" src="https://i.iplsc.com/konflikt-miedzy-polskim-a-niemieckim-kosciolem-zlosliwe-ocze/000I3GHUY9D3CF8R-C321.jpg" /></a>Przewodniczący Episkopatu Niemiec zarzucił arcybiskupowi Stanisławowi Gądeckiemu &quot;ogromne przekroczenie uprawnień&quot; i &quot;złośliwe oczernianie&quot;. Wszystko przez list polskiego duchownego do papieża Franciszka, w którym Gądecki krytykuje zabiegi reformatorskie przebiegające w niemieckim Kościele katolickim. &quot;Zamiast dialogu wybrał Ks. Arcybiskup list do papieża Franciszka, w którym z wielką gwałtownością oraz nieprecyzyjnymi i fałszującymi stwierdzeniami narzeka na Drogę Synodalną Kościoła katolickiego w Niemczech&quot; - pisze biskup Georg Bätzing i...</p><br clear="all" />

## Wewnętrzne tarcia w Ukrainie. Posłanka Zełenskiego wzywa do dymisji generała Załużnego
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-wewnetrzne-tarcia-w-ukrainie-poslanka-zelenskiego-wzywa-do-d,nId,7174682](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-wewnetrzne-tarcia-w-ukrainie-poslanka-zelenskiego-wzywa-do-d,nId,7174682)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T11:38:26+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-wewnetrzne-tarcia-w-ukrainie-poslanka-zelenskiego-wzywa-do-d,nId,7174682"><img align="left" alt="Wewnętrzne tarcia w Ukrainie. Posłanka Zełenskiego wzywa do dymisji generała Załużnego" src="https://i.iplsc.com/wewnetrzne-tarcia-w-ukrainie-poslanka-zelenskiego-wzywa-do-d/000I3GAURN3H46I4-C321.jpg" /></a>&quot;To przywództwo (generał Walerij Załużny - red.) musi odejść&quot; - twierdzi Mariana Bezugla. Posłanka z partii Sługa Narodu wezwała Naczelnego Dowódcę Sił Zbrojnych Ukrainy do natychmiastowego ustąpienia ze stanowiska, czym wywołała prawdziwą burzę medialną.</p><br clear="all" />

## Nowy rząd Mateusza Morawieckiego. Znamy nazwiska, są zaskoczenia
 - [https://wydarzenia.interia.pl/kraj/news-nowy-rzad-mateusza-morawieckiego-znamy-nazwiska-sa-zaskoczen,nId,7174689](https://wydarzenia.interia.pl/kraj/news-nowy-rzad-mateusza-morawieckiego-znamy-nazwiska-sa-zaskoczen,nId,7174689)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T11:13:59+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-nowy-rzad-mateusza-morawieckiego-znamy-nazwiska-sa-zaskoczen,nId,7174689"><img align="left" alt="Nowy rząd Mateusza Morawieckiego. Znamy nazwiska, są zaskoczenia" src="https://i.iplsc.com/nowy-rzad-mateusza-morawieckiego-znamy-nazwiska-sa-zaskoczen/000GDJY4YCVFG1QO-C321.jpg" /></a>Znamy większość nazwisk nowego rządu premiera Mateusza Morawieckiego. Dominują debiutanci. Z poprzedniego składu znajdą się, oprócz samego premiera, jedynie trzy osoby. Do Rady Ministrów trafi także reprezentant Suwerennej Polski. Nie będzie to jednak Zbigniew Ziobro, lecz Marcin Warchoł.</p><br clear="all" />

## Walka o media publiczne. Ruch ministra kultury
 - [https://wydarzenia.interia.pl/kraj/news-walka-o-media-publiczne-ruch-ministra-kultury,nId,7174693](https://wydarzenia.interia.pl/kraj/news-walka-o-media-publiczne-ruch-ministra-kultury,nId,7174693)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T10:57:18+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-walka-o-media-publiczne-ruch-ministra-kultury,nId,7174693"><img align="left" alt="Walka o media publiczne. Ruch ministra kultury" src="https://i.iplsc.com/walka-o-media-publiczne-ruch-ministra-kultury/000I3GHGP4ERLQWB-C321.jpg" /></a>Minister kultury prof. Piotr Gliński chce zmian w statutach TVP, Polskiego Radia, a także Polskiej Agencji Prasowej. Złożył w tej sprawie wniosek do Rady Mediów Narodowych.</p><br clear="all" />

## Generał NATO mówił o "wojskowej strefie Schengen". Ostra reakcja Kremla
 - [https://wydarzenia.interia.pl/zagranica/news-general-nato-mowil-o-wojskowej-strefie-schengen-ostra-reakcj,nId,7174565](https://wydarzenia.interia.pl/zagranica/news-general-nato-mowil-o-wojskowej-strefie-schengen-ostra-reakcj,nId,7174565)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T10:46:52+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-general-nato-mowil-o-wojskowej-strefie-schengen-ostra-reakcj,nId,7174565"><img align="left" alt="Generał NATO mówił o &quot;wojskowej strefie Schengen&quot;. Ostra reakcja Kremla" src="https://i.iplsc.com/general-nato-mowil-o-wojskowej-strefie-schengen-ostra-reakcj/000I3FHHKCYVHTOX-C321.jpg" /></a>Generał NATO zaproponował ograniczenie biurokracji i utworzenie &quot;wojskowej strefy Schengen&quot; w Europie, która usprawniłaby przerzut wojsk. Na wypowiedź błyskawicznie zareagował Kreml. Dmitrij Pieskow oświadczył, że działania Sojuszu budzą obawy Rosji. Zasugerował też, że Moskwa może zareagować. </p><br clear="all" />

## Miliony dla doradców Adama Glapińskiego. Tajemnicza lista nazwisk
 - [https://wydarzenia.interia.pl/kraj/news-miliony-dla-doradcow-adama-glapinskiego-tajemnicza-lista-naz,nId,7174498](https://wydarzenia.interia.pl/kraj/news-miliony-dla-doradcow-adama-glapinskiego-tajemnicza-lista-naz,nId,7174498)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T10:03:17+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-miliony-dla-doradcow-adama-glapinskiego-tajemnicza-lista-naz,nId,7174498"><img align="left" alt="Miliony dla doradców Adama Glapińskiego. Tajemnicza lista nazwisk" src="https://i.iplsc.com/miliony-dla-doradcow-adama-glapinskiego-tajemnicza-lista-naz/000I3DJTF236NS30-C321.jpg" /></a>Doradcy Adama Glapińskiego zarobili w 2022 roku ponad 4,6 mln zł. Według danych, które publikuje &quot;Rzeczpospolita&quot;, doradcy prezesa NBP zarabiają ok. 29 tys. zł miesięcznie. Bank centralny odmawia jednak ujawnienia ich nazwisk. &quot;Tajemniczość NBP prowokuje podejrzenia, że krąg doradców prezesa staje się przechowalnią dla ludzi PiS&quot; - stwierdzono.</p><br clear="all" />

## Śmiertelnie groźna pogoda w Azji. Wiele ofiar piorunów
 - [https://wydarzenia.interia.pl/zagranica/news-smiertelnie-grozna-pogoda-w-azji-wiele-ofiar-piorunow,nId,7174506](https://wydarzenia.interia.pl/zagranica/news-smiertelnie-grozna-pogoda-w-azji-wiele-ofiar-piorunow,nId,7174506)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T09:57:31+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-smiertelnie-grozna-pogoda-w-azji-wiele-ofiar-piorunow,nId,7174506"><img align="left" alt="Śmiertelnie groźna pogoda w Azji. Wiele ofiar piorunów" src="https://i.iplsc.com/smiertelnie-grozna-pogoda-w-azji-wiele-ofiar-piorunow/000I3DV6O6USDJLC-C321.jpg" /></a>Potężne burze w niedzielę zebrały śmiertelne żniwo w Indiach. Same pioruny zabiły co najmniej 18 osób, choć wiadomo, że ofiar żywiołu jest więcej. Minister spraw wewnętrznych kraju złożył rodzinom zmarłych &quot;najgłębsze kondolencje&quot;. Oprócz ludzi burze zabiły też dziesiątki zwierząt. To kolejna tego typu tragedia w stanie Gudźarat w ostatnich latach.</p><br clear="all" />

## Przejęli w pełni załadowany tankowiec. Do akcji wkroczyli Amerykanie
 - [https://wydarzenia.interia.pl/zagranica/news-przejeli-w-pelni-zaladowany-tankowiec-do-akcji-wkroczyli-ame,nId,7174501](https://wydarzenia.interia.pl/zagranica/news-przejeli-w-pelni-zaladowany-tankowiec-do-akcji-wkroczyli-ame,nId,7174501)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T09:41:03+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-przejeli-w-pelni-zaladowany-tankowiec-do-akcji-wkroczyli-ame,nId,7174501"><img align="left" alt="Przejęli w pełni załadowany tankowiec. Do akcji wkroczyli Amerykanie" src="https://i.iplsc.com/przejeli-w-pelni-zaladowany-tankowiec-do-akcji-wkroczyli-ame/000I3DIVYJSEM018-C321.jpg" /></a>Okręt USA odpowiedział na wezwanie pomocy i przeprowadził operację uwolnienia tankowca porwanego przez piratów w Zatoce Adeńskiej. Napastnicy próbowali uciekać. Amerykanie oświadczyli, że załoga tankowca jest bezpieczna.</p><br clear="all" />

## Zaskakujące ruchy Łukaszenki wobec Polski. "Rozpoczyna grę z nowym rządem"
 - [https://wydarzenia.interia.pl/zagranica/news-zaskakujace-ruchy-lukaszenki-wobec-polski-rozpoczyna-gre-z-n,nId,7174465](https://wydarzenia.interia.pl/zagranica/news-zaskakujace-ruchy-lukaszenki-wobec-polski-rozpoczyna-gre-z-n,nId,7174465)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T09:34:49+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zaskakujace-ruchy-lukaszenki-wobec-polski-rozpoczyna-gre-z-n,nId,7174465"><img align="left" alt="Zaskakujące ruchy Łukaszenki wobec Polski. &quot;Rozpoczyna grę z nowym rządem&quot;" src="https://i.iplsc.com/zaskakujace-ruchy-lukaszenki-wobec-polski-rozpoczyna-gre-z-n/000I3DH1GO4H2WC1-C321.jpg" /></a>- Łukaszenka chce rozpocząć grę z nowym rządem polegająca na wymianie zakładników w zamian za konkrety. A te dotyczą granicy - mówi Siarhiej Pielasa. Opozycjonista odniósł się do kolejnych wypowiedzi dyktatora z Mińska dotyczących Polski.</p><br clear="all" />

## Elektrownia jądrowa w Koninie. Jacek Sasin: To wielki dzień
 - [https://wydarzenia.interia.pl/kraj/news-elektrownia-jadrowa-w-koninie-jacek-sasin-to-wazne-miejsce-n,nId,7174466](https://wydarzenia.interia.pl/kraj/news-elektrownia-jadrowa-w-koninie-jacek-sasin-to-wazne-miejsce-n,nId,7174466)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T09:15:19+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-elektrownia-jadrowa-w-koninie-jacek-sasin-to-wazne-miejsce-n,nId,7174466"><img align="left" alt="Elektrownia jądrowa w Koninie. Jacek Sasin: To wielki dzień" src="https://i.iplsc.com/elektrownia-jadrowa-w-koninie-jacek-sasin-to-wielki-dzien/000I3CYI1XPSSO15-C321.jpg" /></a>Chcemy oprzeć nasz miks energetyczny o zrównoważoną energię ze źródeł odnawialnych. Zasadniczym elementem ma stać się energetyka jądrowa - powiedział Jacek Sasin podczas konferencji prasowej dotyczącej budowy elektrowni jądrowej w Koninie-Pątnowie. Dodał także, że jest to &quot;element transformacji energetycznej&quot;. - Szanowni państwo to wielki dzień dla polskiej energetyki, przyszłości - zaznaczył.</p><br clear="all" />

## "Szalona taktyka Rosjan". Wykorzystują metodę "wabików"
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-szalona-taktyka-rosjan-wykorzystuja-metode-wabikow,nId,7174441](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-szalona-taktyka-rosjan-wykorzystuja-metode-wabikow,nId,7174441)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T08:59:05+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-szalona-taktyka-rosjan-wykorzystuja-metode-wabikow,nId,7174441"><img align="left" alt="&quot;Szalona taktyka Rosjan&quot;. Wykorzystują metodę &quot;wabików&quot; " src="https://i.iplsc.com/szalona-taktyka-rosjan-wykorzystuja-metode-wabikow/000I3CVANDWHQA75-C321.jpg" /></a>Pomimo coraz trudniejszych warunków atmosferycznych rosyjskie wojsko stara się prowadzić działania ofensywne na wielu kierunkach frontu. Wyjątkowo gorąco w ostatnich godzinach było przede wszystkim w południowych okolicach miasta Bachmut.</p><br clear="all" />

## Ciemna strona
 - [https://wydarzenia.interia.pl/felietony/news-ciemna-strona,nId,7174416](https://wydarzenia.interia.pl/felietony/news-ciemna-strona,nId,7174416)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T08:35:24+00:00

<p><a href="https://wydarzenia.interia.pl/felietony/news-ciemna-strona,nId,7174416"><img align="left" alt="Ciemna strona" src="https://i.iplsc.com/ciemna-strona/000I3CY0OYR0NDT3-C321.jpg" /></a>Podczas gdy Jarosław Kaczyński, Mateusz Morawiecki i Andrzej Duda ośmieszają siebie i państwo przedłużającą się farsą o budowaniu fasadowego rządu, który nigdy nie uzyska wotum zaufania, nowa demokratyczna większość wierzy, że pisowski antykonstytucyjny system jest kolosem na glinianych nogach i właśnie trwale kończy swój żywot. Tymczasem na amerykańskim i europejskim horyzoncie majaczą znaki, które nowa władza powinna potraktować poważnie i znaleźć na nie w niedalekiej przyszłości wiarygodną odpowiedź polityczną. </p><br clear="all" />

## Zalane lotnisko, brak prądu, huraganowy wiatr. Rosja walczy z katastrofalną pogodą
 - [https://wydarzenia.interia.pl/zagranica/news-zalane-lotnisko-brak-pradu-huraganowy-wiatr-rosja-walczy-z-k,nId,7174451](https://wydarzenia.interia.pl/zagranica/news-zalane-lotnisko-brak-pradu-huraganowy-wiatr-rosja-walczy-z-k,nId,7174451)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T08:32:13+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zalane-lotnisko-brak-pradu-huraganowy-wiatr-rosja-walczy-z-k,nId,7174451"><img align="left" alt="Zalane lotnisko, brak prądu, huraganowy wiatr. Rosja walczy z katastrofalną pogodą" src="https://i.iplsc.com/zalane-lotnisko-brak-pradu-huraganowy-wiatr-rosja-walczy-z-k/000I3CVI3I9R48SB-C321.jpg" /></a>Rosja walczy ze skutkami pogody. Na Kamczatce woda zalała lotnisko, w Kraju Krasnodarskim zawieszono loty. Najtrudniejsza sytuacja jest na okupowanym Krymie, gdzie około pół miliona osób jest pozbawionych dostaw prądu. W regionie zginęła też jedna osoba.</p><br clear="all" />

## Polacy będą dowodzić ćwiczeniami NATO. "Wyraz dużego zaufania"
 - [https://wydarzenia.interia.pl/kraj/news-polacy-beda-dowodzic-cwiczeniami-nato-wyraz-duzego-zaufania,nId,7174437](https://wydarzenia.interia.pl/kraj/news-polacy-beda-dowodzic-cwiczeniami-nato-wyraz-duzego-zaufania,nId,7174437)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T07:52:15+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-polacy-beda-dowodzic-cwiczeniami-nato-wyraz-duzego-zaufania,nId,7174437"><img align="left" alt="Polacy będą dowodzić ćwiczeniami NATO. &quot;Wyraz dużego zaufania&quot;" src="https://i.iplsc.com/polacy-beda-dowodzic-cwiczeniami-nato-wyraz-duzego-zaufania/000I3CUI40PKS8Q2-C321.jpg" /></a>Rozpoczyna się doroczne ćwiczenie wojsk cybernetycznych państw NATO &quot;Cyber Coalition 2023&quot;.  W tym roku to Polska będzie pełnić rolę dowództwa dla państw regionu. - To niewątpliwie wyraz dużego zaufania sojuszników do naszych Wojsk Obrony Cyberprzestrzeni oraz dowód na to, że polscy cyberżołnierze są na światowym poziomie - stwierdził rzecznik Wojsk Obrony Cyberprzestrzeni</p><br clear="all" />

## Zamieszanie w PiS. Ważny polityk może jednak wejść do rządu
 - [https://wydarzenia.interia.pl/kraj/news-zamieszanie-w-pis-wazny-polityk-moze-jednak-wejsc-do-rzadu,nId,7174411](https://wydarzenia.interia.pl/kraj/news-zamieszanie-w-pis-wazny-polityk-moze-jednak-wejsc-do-rzadu,nId,7174411)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T07:51:23+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-zamieszanie-w-pis-wazny-polityk-moze-jednak-wejsc-do-rzadu,nId,7174411"><img align="left" alt="Zamieszanie w PiS. Ważny polityk może jednak wejść do rządu" src="https://i.iplsc.com/zamieszanie-w-pis-wazny-polityk-moze-jednak-wejsc-do-rzadu/000I3CJ9V4W8GLOM-C321.jpg" /></a>- W nowym rządzie Mateusza Morawieckiego nie będzie zbyt wielu polityków, ale akurat minister Mariusz Błaszczak być może się w nim znajdzie - stwierdził Jarosław Kaczyński. Słowa prezesa PiS nie pokrywają się z deklaracją samego szefa MON, który w sobotę zaprzeczył, że dołączy do nowego gabinetu.</p><br clear="all" />

## Już niedługo Barbórka. Jak wyglądają obchody górniczego święta?
 - [https://wydarzenia.interia.pl/ciekawostki/news-juz-niedlugo-barborka-jak-wygladaja-obchody-gorniczego-swiet,nId,7164982](https://wydarzenia.interia.pl/ciekawostki/news-juz-niedlugo-barborka-jak-wygladaja-obchody-gorniczego-swiet,nId,7164982)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T07:30:00+00:00

<p><a href="https://wydarzenia.interia.pl/ciekawostki/news-juz-niedlugo-barborka-jak-wygladaja-obchody-gorniczego-swiet,nId,7164982"><img align="left" alt="Już niedługo Barbórka. Jak wyglądają obchody górniczego święta?" src="https://i.iplsc.com/juz-niedlugo-barborka-jak-wygladaja-obchody-gorniczego-swiet/000E00VEYBNDVE94-C321.jpg" /></a>Wielkimi krokami zbliża się jedno z najbardziej hucznych świąt na Śląsku. Barbórka to okazja dla górników i ich rodzin na celebrację i dobrą zabawę. Skąd pochodzi nazwa święta i w jaki sposób dzisiaj się je obchodzi? Czy tegoroczne obchody będą huczne?</p><br clear="all" />

## Kreml ma sposób na żony wojskowych. "Wolą pieniądze niż mężów w domu"
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-kreml-ma-sposob-na-zony-wojskowych-wola-pieniadze-niz-mezow-,nId,7174383](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-kreml-ma-sposob-na-zony-wojskowych-wola-pieniadze-niz-mezow-,nId,7174383)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T07:24:48+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-kreml-ma-sposob-na-zony-wojskowych-wola-pieniadze-niz-mezow-,nId,7174383"><img align="left" alt="Kreml ma sposób na żony wojskowych. &quot;Wolą pieniądze niż mężów w domu&quot;" src="https://i.iplsc.com/kreml-ma-sposob-na-zony-wojskowych-wola-pieniadze-niz-mezow/000I3BUR7UQ6MOIK-C321.jpg" /></a>Protestujące żony rosyjskich żołnierzy budzą niepokój Kremla przed nadchodzącymi wyborami prezydenckimi. Władze chcą je zatem przekupić, by zaprzestały demonstracji - wynika z doniesień medialnych. Rosyjskie władze państwowe mają twierdzić, że kobietom zależy &quot;bardziej na zdobyciu pieniędzy niż na powrocie mężów z wojny&quot;.</p><br clear="all" />

## Poniżali młode dziewczyny podczas transmisji. Patostreamerzy zatrzymani
 - [https://wydarzenia.interia.pl/slaskie/news-ponizali-mlode-dziewczyny-podczas-transmisji-patostreamerzy-,nId,7174396](https://wydarzenia.interia.pl/slaskie/news-ponizali-mlode-dziewczyny-podczas-transmisji-patostreamerzy-,nId,7174396)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T07:06:42+00:00

<p><a href="https://wydarzenia.interia.pl/slaskie/news-ponizali-mlode-dziewczyny-podczas-transmisji-patostreamerzy-,nId,7174396"><img align="left" alt="Poniżali młode dziewczyny podczas transmisji. Patostreamerzy zatrzymani" src="https://i.iplsc.com/ponizali-mlode-dziewczyny-podczas-transmisji-patostreamerzy/000GGSI23CHFQDOA-C321.jpg" /></a>Policja zatrzymała dwóch 18-letnich patostreamerów. Nastolatkowie 17 listopada podczas transmisji w internecie poniżali młode dziewczyny. Kiedy sprawa nabrała rozgłosu, uciekli za granicę, jednak w ubiegły weekend ujęto ich na terenie Śląska. Patostreamerzy trafili do aresztu, czekają na przedstawienie im zarzutów.</p><br clear="all" />

## Polacy zmienili zdanie o prezydencie. Najnowszy sondaż
 - [https://wydarzenia.interia.pl/kraj/news-polacy-zmienili-zdanie-o-prezydencie-najnowszy-sondaz,nId,7174378](https://wydarzenia.interia.pl/kraj/news-polacy-zmienili-zdanie-o-prezydencie-najnowszy-sondaz,nId,7174378)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T06:02:02+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-polacy-zmienili-zdanie-o-prezydencie-najnowszy-sondaz,nId,7174378"><img align="left" alt="Polacy zmienili zdanie o prezydencie. Najnowszy sondaż" src="https://i.iplsc.com/polacy-zmienili-zdanie-o-prezydencie-najnowszy-sondaz/000HCCOIXHKHOXPS-C321.jpg" /></a>Prawie 60 procent badanych negatywnie ocenia ostatnie decyzje Andrzeja Dudy w stosunku do nowej większości parlamentarnej. Najgorszą opinię o prezydencie mają wyborcy opozycyjnych ugrupowań. Głowa państwa wciąż może jednak liczyć na poparcie elektoratu Prawa i Sprawiedliwości. Według ekspertów powierzenie misji utworzenia rządu Mateuszowi Morawieckiemu przynosi notowaniom prezydenta &quot;skutek odwrotny od zamierzonego&quot;. </p><br clear="all" />

## Jarosław Kaczyński: Skład rządu to mój pomysł
 - [https://wydarzenia.interia.pl/kraj/news-jaroslaw-kaczynski-sklad-rzadu-to-moj-pomysl,nId,7174376](https://wydarzenia.interia.pl/kraj/news-jaroslaw-kaczynski-sklad-rzadu-to-moj-pomysl,nId,7174376)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T05:51:51+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-jaroslaw-kaczynski-sklad-rzadu-to-moj-pomysl,nId,7174376"><img align="left" alt="Jarosław Kaczyński: Skład rządu to mój pomysł" src="https://i.iplsc.com/jaroslaw-kaczynski-sklad-rzadu-to-moj-pomysl/000HBT23RXD3DLXU-C321.jpg" /></a>Kształt rządu ekspercko-politycznego, który w poniedziałek przedstawi premier Mateusz Morawiecki, to mój pomysł. Chcemy zaproponować nowe twarze. Trzeba zakończyć wojnę, którą prowadzi Platforma Obywatelska - przekazał Jarosław Kaczyński.</p><br clear="all" />

## Kolejna wymiana zakładników. Pojawiają się komplikacje
 - [https://wydarzenia.interia.pl/raport-wojna-w-izraelu/news-kolejna-wymiana-zakladnikow-pojawiaja-sie-komplikacje,nId,7174375](https://wydarzenia.interia.pl/raport-wojna-w-izraelu/news-kolejna-wymiana-zakladnikow-pojawiaja-sie-komplikacje,nId,7174375)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T05:48:37+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wojna-w-izraelu/news-kolejna-wymiana-zakladnikow-pojawiaja-sie-komplikacje,nId,7174375"><img align="left" alt="Kolejna wymiana zakładników. Pojawiają się komplikacje" src="https://i.iplsc.com/kolejna-wymiana-zakladnikow-pojawiaja-sie-komplikacje/000I3BMYDDU7DAD1-C321.jpg" /></a>Wymiana więźniów między Izraelem a Hamasem trwa od piątku. Czwartego dnia rozejmu w walkach między stronami pojawiły się jednak pewne komplikacje. Jak donoszą lokalne media, Izrael nie otrzymał jeszcze listy 11 zakładników, którzy mają zostać uwolnieni w poniedziałek przez Hamas.</p><br clear="all" />

## Ruch Korei Północnej. Rozmieszczono wojsko przy granicy
 - [https://wydarzenia.interia.pl/zagranica/news-ruch-korei-polnocnej-rozmieszczono-wojsko-przy-granicy,nId,7174366](https://wydarzenia.interia.pl/zagranica/news-ruch-korei-polnocnej-rozmieszczono-wojsko-przy-granicy,nId,7174366)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T04:58:41+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-ruch-korei-polnocnej-rozmieszczono-wojsko-przy-granicy,nId,7174366"><img align="left" alt="Ruch Korei Północnej. Rozmieszczono wojsko przy granicy" src="https://i.iplsc.com/ruch-korei-polnocnej-rozmieszczono-wojsko-przy-granicy/000I3BLJAVHVY754-C321.jpg" /></a>Korea Północna rozmieściła wojsko i uzbrojenie w pobliżu granicy z Koreą Południową po tym, jak zawieszono porozumienie między krajami z 2018 roku. Agencja Yonhap dodaje, że południowokoreańskie wojsko obserwuje ruchy przeciwników.</p><br clear="all" />

## Ruch Korei Północnej. Rozmieszczono wojsko przy granicy z Koreą Południową
 - [https://wydarzenia.interia.pl/zagranica/news-ruch-korei-polnocnej-rozmieszczono-wojsko-przy-granicy-z-kor,nId,7174366](https://wydarzenia.interia.pl/zagranica/news-ruch-korei-polnocnej-rozmieszczono-wojsko-przy-granicy-z-kor,nId,7174366)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-11-27T04:58:41+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-ruch-korei-polnocnej-rozmieszczono-wojsko-przy-granicy-z-kor,nId,7174366"><img align="left" alt="Ruch Korei Północnej. Rozmieszczono wojsko przy granicy z Koreą Południową" src="https://i.iplsc.com/ruch-korei-polnocnej-rozmieszczono-wojsko-przy-granicy-z-kor/000I3BLJAVHVY754-C321.jpg" /></a>Korea Północna rozmieściła wojsko i broń w pobliżu granicy z Korea Południową po tym, jak zawieszono porozumienie między krajami z 2018 roku. Agencja Yonhap dodaje, że południowokoreańskie wojsko obserwuje ruchy przeciwników. </p><br clear="all" />

