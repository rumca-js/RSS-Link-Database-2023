# Source:FlashGitz, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNnKprAG-MWLsk-GsbsC2BA, language:en-US

## Link's got big plans for today..
 - [https://www.youtube.com/watch?v=jGngh_VR6rg](https://www.youtube.com/watch?v=jGngh_VR6rg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNnKprAG-MWLsk-GsbsC2BA
 - date published: 2023-11-27T17:00:37+00:00

#flashgitz #animationmeme #zeldatearsofthekingdom #zeldabreathofthewild

