# Source:Niebezpiecznik, URL:https://feeds.feedburner.com/niebezpiecznik/, language:pl-PL

## Wyciekły wyniki badań tysięcy Polaków, którzy oddali krew do badań w ALAB
 - [https://niebezpiecznik.pl/post/wyciekly-wyniki-badan-tysiecy-polakow-z-firmy-alab](https://niebezpiecznik.pl/post/wyciekly-wyniki-badan-tysiecy-polakow-z-firmy-alab)
 - RSS feed: https://feeds.feedburner.com/niebezpiecznik/
 - date published: 2023-11-27T10:25:14+00:00

<a href="https://niebezpiecznik.pl/post/wyciekly-wyniki-badan-tysiecy-polakow-z-firmy-alab/"><img align="left" alt="" class="alignleft tfe wp-post-image" height="100" hspace="5" src="https://niebezpiecznik.pl/wp-content/uploads/2023/11/wyni-150x150.png" width="100" /></a>Włamywacze z ransomwarowego gangu &#8220;RA World&#8221; opublikowali informację o ataku na firmę &#8220;ALAB laboratoria&#8220;, popularne w kraju laboratorium diagnostyczne. W udostępnionym pliku, który pobrało już 100 osób, znajdują się dane ponad 54 000 pacjentów. Wyciek jest poważny, nie tylko dlatego, że wyniki badań medycznych opisują stan zdrowia poszczególnych pacjentów, ale także ze względu na to jak [&#8230;]

