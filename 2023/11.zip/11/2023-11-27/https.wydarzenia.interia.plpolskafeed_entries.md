# Source:Wydarzenia Interia - Polska, URL:https://wydarzenia.interia.pl/polska/feed, language:pl-PL

## Spore zaskoczenie. Znana aktorka weszła do rządu
 - [https://wydarzenia.interia.pl/kraj/news-spore-zaskoczenie-znana-aktorka-weszla-do-rzadu,nId,7175105](https://wydarzenia.interia.pl/kraj/news-spore-zaskoczenie-znana-aktorka-weszla-do-rzadu,nId,7175105)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-11-27T17:38:45+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-spore-zaskoczenie-znana-aktorka-weszla-do-rzadu,nId,7175105"><img align="left" alt="Spore zaskoczenie. Znana aktorka weszła do rządu" src="https://i.iplsc.com/spore-zaskoczenie-znana-aktorka-weszla-do-rzadu/000I3LTKU3TX79NH-C321.jpg" /></a>Prezydent Andrzej Duda zaprzysiągł nowy rząd Mateusza Morawieckiego. Przed ceremonią w Pałacu Prezydenckim rzecznik rządu Piotr Müller informował, że do nowej rady ministrów trafią przede wszystkim eksperci. Urząd objęła m.in. Dominika Chorosińska. Aktorka znana chociażby z roli w serialu &quot;M jak miłość&quot; będzie kierowała Ministerstwem Kultury i Dziedzictwa Narodowego.</p><br clear="all" />

## NIK zawiadamia prokuraturę. "Europoseł stosował groźby". A. Bielan odpowiada
 - [https://wydarzenia.interia.pl/kraj/news-nik-zawiadamia-prokurature-europosel-stosowal-grozby-a-biela,nId,7174857](https://wydarzenia.interia.pl/kraj/news-nik-zawiadamia-prokurature-europosel-stosowal-grozby-a-biela,nId,7174857)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-11-27T13:04:56+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-nik-zawiadamia-prokurature-europosel-stosowal-grozby-a-biela,nId,7174857"><img align="left" alt="NIK zawiadamia prokuraturę. &quot;Europoseł stosował groźby&quot;. A. Bielan odpowiada" src="https://i.iplsc.com/nik-zawiadamia-prokurature-europosel-stosowal-grozby-a-biela/000I3HUH9VP0RU2O-C321.jpg" /></a>Najwyższa Izba Kontroli zawiadomi prokuraturę o podejrzeniu popełnienia przestępstwa przez posła do Parlamentu Europejskiego. Jak ustaliła Interia, mowa o Adamie Bielanie, który miał stosować groźby  wobec Jacka Żalka, wymuszając na nim powołanie na stanowisko dyrektora NCBiR Pawła Kucha. Ponadto, w zawiadomieniu mowa także o ministrze funduszy i polityki regionalnej Grzegorzu Pudzie oraz o dyrektorze Narodowego Centrum Badań i Rozwoju Jacku Orle. - Trudno tę wrzutkę komentować poważnie. To nieudolna próba ze strony Jacka Żalka i jego...</p><br clear="all" />

## Zaprzysiężenie nowego rządu. Mateusz Morawiecki zaprezentuje ministrów
 - [https://wydarzenia.interia.pl/kraj/na-zywo-zaprzysiezenie-nowego-rzadu-mateusz-morawiecki-zaprezentuje-,nzId,5026](https://wydarzenia.interia.pl/kraj/na-zywo-zaprzysiezenie-nowego-rzadu-mateusz-morawiecki-zaprezentuje-,nzId,5026)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-11-27T10:14:24+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/na-zywo-zaprzysiezenie-nowego-rzadu-mateusz-morawiecki-zaprezentuje-,nzId,5026"><img align="left" alt="Zaprzysiężenie nowego rządu. Mateusz Morawiecki zaprezentuje ministrów" src="https://i.iplsc.com/zaprzysiezenie-nowego-rzadu-mateusz-morawiecki-zaprezentuje/000I3FBR3O5Q8WXY-C321.jpg" /></a>O godz. 16:30 w Pałacu Prezydenckim rozpocznie się uroczystość zaprzysiężenia nowego rządu Mateusza Morawieckiego przez prezydenta Andrzeja Dudę.</p><br clear="all" />

## Polacy ocenili prezydenta. Najnowszy sondaż
 - [https://wydarzenia.interia.pl/kraj/news-polacy-ocenili-prezydenta-najnowszy-sondaz,nId,7174378](https://wydarzenia.interia.pl/kraj/news-polacy-ocenili-prezydenta-najnowszy-sondaz,nId,7174378)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-11-27T06:02:02+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-polacy-ocenili-prezydenta-najnowszy-sondaz,nId,7174378"><img align="left" alt="Polacy ocenili prezydenta. Najnowszy sondaż" src="https://i.iplsc.com/polacy-ocenili-prezydenta-najnowszy-sondaz/000HCCOIXHKHOXPS-C321.jpg" /></a>Prawie 60 procent badanych negatywnie ocenia ostatnie decyzje Andrzeja Dudy w stosunku do nowej większości parlamentarnej. Najgorszą opinię o prezydencie mają wyborcy opozycyjnych ugrupowań. Głowa państwa wciąż może jednak liczyć na poparcie elektoratu Prawa i Sprawiedliwości. Według ekspertów powierzenie misji utworzenia rządu Mateuszowi Morawieckiemu przynosi notowaniom prezydenta &quot;skutek odwrotny od zamierzonego&quot;. </p><br clear="all" />

