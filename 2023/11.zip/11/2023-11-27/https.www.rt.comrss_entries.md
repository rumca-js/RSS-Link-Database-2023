# Source:RT - Daily news, URL:https://www.rt.com/rss/, language:en

## Another NATO member runs out of weapons for Ukraine
 - [https://www.rt.com/news/588095-czech-weapons-ukraine-end/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/588095-czech-weapons-ukraine-end/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T22:21:42+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6565138185f5403fc555d49f.jpg" style="margin-right: 10px;" /> The Czech Republic wants to keep helping Kiev through contracts with private companies, as its military has nothing more to spare <br /><a href="https://www.rt.com/news/588095-czech-weapons-ukraine-end/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## The Jews and Boris Johnson: Zelensky’s top political ally looks for scapegoats as Ukrainian elites begin to accept the war is lost
 - [https://www.rt.com/russia/588013-ukraine-arakhamia-jews-war/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/588013-ukraine-arakhamia-jews-war/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T22:18:15+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/656484f685f5407d3119a8d6.jpg" style="margin-right: 10px;" /> David Arakhamia, the head of Vladimir Zelensky’s parliamentary bloc, admits Kiev's dependency on the West and lack of a coherent strategy <br /><a href="https://www.rt.com/russia/588013-ukraine-arakhamia-jews-war/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## First human case of new illness found in UK
 - [https://www.rt.com/news/588093-swine-flu-human-case/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/588093-swine-flu-human-case/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T21:18:24+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/656502ae2030276e7f0273d4.jpg" style="margin-right: 10px;" /> British authorities have discovered the first human case of a new strain of swine flu <br /><a href="https://www.rt.com/news/588093-swine-flu-human-case/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Crimea hit by ‘worst storm in history’ (VIDEOS)
 - [https://www.rt.com/russia/588092-crimea-worst-storm-history/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/588092-crimea-worst-storm-history/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T20:36:29+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6564fca485f5407d3119a900.jpg" style="margin-right: 10px;" /> Crimea has been hit by the most powerful storm in recorded history, a Russian weather service official has said <br /><a href="https://www.rt.com/russia/588092-crimea-worst-storm-history/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## US dictionary reveals ‘word of the year’
 - [https://www.rt.com/news/588090-merriam-webster-word-of-year/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/588090-merriam-webster-word-of-year/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T20:29:50+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6564e7f320302724870bc113.jpg" style="margin-right: 10px;" /> Merriam-Webster says the word ‘authentic’ has attracted a major increase in search traffic this year <br /><a href="https://www.rt.com/news/588090-merriam-webster-word-of-year/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## German army would only last two days – MP
 - [https://www.rt.com/news/588091-germany-army-low-stockpiles-ukraine/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/588091-germany-army-low-stockpiles-ukraine/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T20:24:31+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6564fa1720302761681da5b4.jpg" style="margin-right: 10px;" /> German MP Johann Wadephul says the Bundeswehr would last a maximum of two days in a war due to its low stocks <br /><a href="https://www.rt.com/news/588091-germany-army-low-stockpiles-ukraine/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## We should never underestimate Russia – NATO chief
 - [https://www.rt.com/news/588088-nato-underestimate-russia-stoltenberg/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/588088-nato-underestimate-russia-stoltenberg/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T19:52:43+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6564edea2030270e6e6da973.jpg" style="margin-right: 10px;" /> Ukraine’s failure to move front lines after months of intense fighting proves that NATO cannot underestimate Russia, Jens Stoltenberg said <br /><a href="https://www.rt.com/news/588088-nato-underestimate-russia-stoltenberg/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Canada ‘convicted’ India before investigation – envoy
 - [https://www.rt.com/india/588089-india-canada-spat-khalistan-activist/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/india/588089-india-canada-spat-khalistan-activist/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T19:16:30+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6564e4aa203027548a542332.jpg" style="margin-right: 10px;" /> A “lot of dialogue” is going on to restore ties with Canada amid a diplomatic row over the killing of a Sikh activist, New Delhi said <br /><a href="https://www.rt.com/india/588089-india-canada-spat-khalistan-activist/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Musk backs Israeli assault on Gaza
 - [https://www.rt.com/news/588087-elon-musk-israel-netanyahu/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/588087-elon-musk-israel-netanyahu/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T19:09:08+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6564d9392030270d2b3779a3.jpg" style="margin-right: 10px;" /> X owner Elon Musk visited Israel and endorsed the government’s actions after touring a kibbutz attacked by Hamas and watching a documentary <br /><a href="https://www.rt.com/news/588087-elon-musk-israel-netanyahu/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Truce in Gaza extended by two days
 - [https://www.rt.com/news/588080-gaza-truce-extension-qatar/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/588080-gaza-truce-extension-qatar/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T18:22:34+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6564cbce85f54030ce2b0b70.jpg" style="margin-right: 10px;" /> Though Israel has vowed to resume the war, Hamas hopes the Qatari-brokered extension may result in a permanent ceasefire <br /><a href="https://www.rt.com/news/588080-gaza-truce-extension-qatar/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Kiev using ‘toxic chemicals’ against Russian officials – Moscow
 - [https://www.rt.com/russia/588086-kiev-toxic-chemicals-russian-officials/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/588086-kiev-toxic-chemicals-russian-officials/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T18:22:25+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6564d7a185f5405738661f79.jpg" style="margin-right: 10px;" /> Moscow has said it has “irrefutable evidence” of Kiev using chemicals supplied by the West in attacks against Russian officials <br /><a href="https://www.rt.com/russia/588086-kiev-toxic-chemicals-russian-officials/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Deputy FM meets with freed Russian hostage’s family
 - [https://www.rt.com/russia/588079-russia-fm-prisoner-release/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/588079-russia-fm-prisoner-release/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T17:09:50+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6564be0685f5407a45437398.jpg" style="margin-right: 10px;" /> Russian Deputy Foreign Minister Mikhail Bogdanov says the release of a Russian national by Hamas was not part of the deal with Israel <br /><a href="https://www.rt.com/russia/588079-russia-fm-prisoner-release/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## ‘Satanic’ Christmas tree draws dispraise
 - [https://www.rt.com/news/588084-us-satanic-christmas-tree-criticism/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/588084-us-satanic-christmas-tree-criticism/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T17:07:15+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6564c80720302706e1670e4d.jpg" style="margin-right: 10px;" /> A US museum has generated controversy by including a ‘Satanic’ exhibit in its annual Christmas tree festival <br /><a href="https://www.rt.com/news/588084-us-satanic-christmas-tree-criticism/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## US denies pushing Ukraine to negotiate
 - [https://www.rt.com/news/588082-us-denies-ukraine-negotiations/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/588082-us-denies-ukraine-negotiations/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T17:05:17+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6564c81a20302708085f217a.jpg" style="margin-right: 10px;" /> The US and Germany are not pushing Kiev to seek peace with Russia, a State Department official has said <br /><a href="https://www.rt.com/news/588082-us-denies-ukraine-negotiations/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Sanctioned Russian lenders enjoyed ‘highly successful’ year – top banker
 - [https://www.rt.com/business/588077-russia-putin-banks-sanctions/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/588077-russia-putin-banks-sanctions/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T16:48:40+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6564b9bc85f54001f120970c.jpg" style="margin-right: 10px;" /> Russian banks have withstood Western sanctions and have had a very profitable 2023, the head of VTB says <br /><a href="https://www.rt.com/business/588077-russia-putin-banks-sanctions/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Sword of Bharat: How India aims to conquer the global arms market
 - [https://www.rt.com/india/588053-india-business-defence-exports/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/india/588053-india-business-defence-exports/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T16:27:44+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/65648c7520302708e15de286.jpg" style="margin-right: 10px;" /> Import dependency is strategically risky when it comes to military needs, especially with regional wars spreading across the world <br /><a href="https://www.rt.com/india/588053-india-business-defence-exports/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Gold price hits six-month high
 - [https://www.rt.com/business/588063-gold-hits-six-month-high/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/588063-gold-hits-six-month-high/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T16:24:51+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/656496b585f5400f4262b4b1.jpg" style="margin-right: 10px;" /> The price of gold has hit its highest since May, hovering above $2,000 per ounce on a weaker US dollar <br /><a href="https://www.rt.com/business/588063-gold-hits-six-month-high/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Millions of dogs could flood Seoul streets – media
 - [https://www.rt.com?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T16:03:14+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6564bd67203027233b2ed845.jpg" style="margin-right: 10px;" /> South Korean farmers have threatened to release 2 million dogs as the country plans to ban their meat, local news outlets have reported <br /><a href="https://www.rt.com?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Millions of dogs could flood Seoul streets – media
 - [https://www.rt.com/news/588075-farmers-threaten-release-dogs-seoul/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/588075-farmers-threaten-release-dogs-seoul/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T16:03:14+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6564bd67203027233b2ed845.jpg" style="margin-right: 10px;" /> South Korean farmers have threatened to release 2 million dogs as the country plans to ban their meat, local news outlets have reported <br /><a href="https://www.rt.com/news/588075-farmers-threaten-release-dogs-seoul/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## South Korean man jailed over poem
 - [https://www.rt.com/news/588072-korea-poem-sentence-pyongyang/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/588072-korea-poem-sentence-pyongyang/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T16:01:30+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6564ac2720302728dc61baba.jpg" style="margin-right: 10px;" /> A South Korean man will spend 14 months in prison for a poem praising the socialist government in North Korea, local media has reported <br /><a href="https://www.rt.com/news/588072-korea-poem-sentence-pyongyang/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## US to expedite returning stolen antiques to India – media
 - [https://www.rt.com/india/588078-india-us-stolen-antiques/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/india/588078-india-us-stolen-antiques/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T16:00:58+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6564b8d785f54001f120970a.jpg" style="margin-right: 10px;" /> Earlier this year, the US transported 105 artifacts to India amid ongoing talks between New Delhi and Washington  <br /><a href="https://www.rt.com/india/588078-india-us-stolen-antiques/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## China rubbishes Western media’s Crimea claim
 - [https://www.rt.com/news/588070-china-crimea-russia-tunnel/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/588070-china-crimea-russia-tunnel/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T15:51:48+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6564a68b85f5407bc311496f.jpg" style="margin-right: 10px;" /> China’s foreign ministry has dismissed reports of a project to build an underwater tunnel between mainland Russia and Crimea as “baseless” <br /><a href="https://www.rt.com/news/588070-china-crimea-russia-tunnel/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Ukrainian troops report poor command and equipment shortage – Bild
 - [https://www.rt.com/russia/588076-ukraine-poor-command-equipment-shortage/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/588076-ukraine-poor-command-equipment-shortage/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T15:47:26+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6564b5da85f5405738661f6f.jpg" style="margin-right: 10px;" /> The Ukrainian army is suffering from poor command as well as lack of essential equipment and funding, soldiers have told Bild <br /><a href="https://www.rt.com/russia/588076-ukraine-poor-command-equipment-shortage/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Kremlin comments on Crimean treasure transfer to Kiev
 - [https://www.rt.com/russia/588068-kremlin-ukraine-scythian-gold/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/588068-kremlin-ukraine-scythian-gold/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T15:23:36+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6564a53085f54030ce2b0b5c.jpg" style="margin-right: 10px;" /> A collection of Scythian gold transferred from the Netherlands to Ukraine belongs to Russia’s Crimean peninsula, the Kremlin has said <br /><a href="https://www.rt.com/russia/588068-kremlin-ukraine-scythian-gold/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Lavrov set to take part in OSCE meeting
 - [https://www.rt.com/russia/588071-lavrov-osce-north-macedonia/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/588071-lavrov-osce-north-macedonia/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T15:22:04+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6564abd285f5407d3119a8e5.jpg" style="margin-right: 10px;" /> Foreign Minister Sergey Lavrov says he will join talks in North Macedonia if Bulgaria opens its airspace to a Russian delegation <br /><a href="https://www.rt.com/russia/588071-lavrov-osce-north-macedonia/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## US weaponizing the dollar – Lavrov
 - [https://www.rt.com/business/588065-us-weaponizing-dollar-lavrov/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/588065-us-weaponizing-dollar-lavrov/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T14:31:22+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/65649ab585f5407bc3114963.jpg" style="margin-right: 10px;" /> US efforts to isolate Russia have backfired, prompting countries to reduce their reliance on Western currencies, Sergey Lavrov has said

  <br /><a href="https://www.rt.com/business/588065-us-weaponizing-dollar-lavrov/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russia delivers 25,000 tons of free wheat to Somalia
 - [https://www.rt.com/africa/588064-russia-somalia-free-grains/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/africa/588064-russia-somalia-free-grains/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T14:28:37+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/65649e3e2030270e6e6da92c.jpg" style="margin-right: 10px;" /> Russian ambassador Mikhail Golovanov arrived in Somalia on Saturday to deliver free wheat to the country <br /><a href="https://www.rt.com/africa/588064-russia-somalia-free-grains/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## FIFA owes over million to Russian clubs – RFU
 - [https://www.rt.com/news/588066-football-fifa-russia-compensation/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/588066-football-fifa-russia-compensation/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T14:16:47+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/65649ce085f540649a323150.jpg" style="margin-right: 10px;" /> Russian clubs have not received payments related to last year’s World Cup in Qatar due to FIFA sanctions, an RFU official has said <br /><a href="https://www.rt.com/news/588066-football-fifa-russia-compensation/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## NATO state threatens to close entire eastern border
 - [https://www.rt.com/news/588061-finland-border-russia-asylum/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/588061-finland-border-russia-asylum/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T14:08:50+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6564948520302707ae22c821.jpg" style="margin-right: 10px;" /> The government of Finnish Prime Minister Petteri Orpo may completely suspend land travel with Russia, Helsingin Sanomat has reported <br /><a href="https://www.rt.com/news/588061-finland-border-russia-asylum/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russian tycoon expects EU to cave in on gas purchases from Moscow
 - [https://www.rt.com/business/588044-deripaska-eu-russian-gas-resumption/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/588044-deripaska-eu-russian-gas-resumption/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T13:18:12+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/65648bf02030270733114d6d.jpg" style="margin-right: 10px;" /> Businessman Oleg Deripaska expects EU nations to start seeking a compromise on gas supplies from Russia's Gazprom within 18 months <br /><a href="https://www.rt.com/business/588044-deripaska-eu-russian-gas-resumption/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Knifeman apprehended outside Moscow shopping mall
 - [https://www.rt.com/news/588062-knifeman-moscow-police-arrest/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/588062-knifeman-moscow-police-arrest/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T13:14:44+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6564958320302712df24fa3e.jpg" style="margin-right: 10px;" /> A man has been arrested in Moscow after threatening passersby with a knife, local media has reported <br /><a href="https://www.rt.com/news/588062-knifeman-moscow-police-arrest/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Ukraine’s largest flag destroyed (VIDEO)
 - [https://www.rt.com/russia/588060-ukraine-largest-flag-destroyed/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/588060-ukraine-largest-flag-destroyed/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T13:00:22+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6564929685f5405738661f5d.jpg" style="margin-right: 10px;" /> The 16-meter banner was torn in half by strong winds despite being lowered in an effort to protect it, Kiev city officials have said <br /><a href="https://www.rt.com/russia/588060-ukraine-largest-flag-destroyed/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Kiev denies Russian sleeper spies now activated in security agency
 - [https://www.rt.com/russia/588059-danilov-sleeper-agents-sbu/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/588059-danilov-sleeper-agents-sbu/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T12:39:49+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6564872185f540649a32313f.jpg" style="margin-right: 10px;" /> The secretary of Ukraine’s security council has reportedly claimed that Russian ‘sleeper spies’ are now working in Kiev to topple government <br /><a href="https://www.rt.com/russia/588059-danilov-sleeper-agents-sbu/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## India’s growth forecast raised
 - [https://www.rt.com/india/588049-india-economy-growth-forecast-raised/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/india/588049-india-economy-growth-forecast-raised/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T12:28:50+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/656474762030270b4d681228.jpg" style="margin-right: 10px;" /> The S&amp;P has revised upwards its forecast for India’s 2024 GDP growth but has lowered its projection for 2025 <br /><a href="https://www.rt.com/india/588049-india-economy-growth-forecast-raised/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Israel-linked tanker briefly seized off Yemen’s coast
 - [https://www.rt.com/news/588051-yemen-tanker-israel-us/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/588051-yemen-tanker-israel-us/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T12:22:11+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/656476df85f54032e15ea29f.jpg" style="margin-right: 10px;" /> The US Navy has detained armed men who briefly seized an Israel-linked tanker off the coast of Yemen, Centcom has said <br /><a href="https://www.rt.com/news/588051-yemen-tanker-israel-us/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## NATO’s stubbornness to blame for Ukraine crisis – Putin aide
 - [https://www.rt.com/russia/588057-natos-stubbornness-ukraine-conflict/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/588057-natos-stubbornness-ukraine-conflict/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T12:21:21+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/656485e185f540636915d86e.jpg" style="margin-right: 10px;" /> The Ukraine conflict was sparked by NATO’s reluctance to address Russia’s security concerns, an aide to Vladimir Putin has said <br /><a href="https://www.rt.com/russia/588057-natos-stubbornness-ukraine-conflict/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Ukraine conflict may expand – top military commander
 - [https://www.rt.com/russia/588043-ukraine-fears-conflict-expand/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/588043-ukraine-fears-conflict-expand/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T11:35:56+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/65647bcd2030270e6e6da91d.jpg" style="margin-right: 10px;" /> The conflict in Ukraine may expand beyond the east and south if Russia keeps increasing weapons production, a top commander told ABC <br /><a href="https://www.rt.com/russia/588043-ukraine-fears-conflict-expand/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Italy rallies African states to tackle EU migration crisis
 - [https://www.rt.com/africa/588048-italy-tunisia-libya-eu-illegal-migration-measures/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/africa/588048-italy-tunisia-libya-eu-illegal-migration-measures/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T11:23:54+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6564753a85f54030ce2b0b3d.jpg" style="margin-right: 10px;" /> Italy has called for Tunisia and Libya to work together to address illegal migration flows into the EU <br /><a href="https://www.rt.com/africa/588048-italy-tunisia-libya-eu-illegal-migration-measures/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Major Russian stock exchange denies bankruptcy reports
 - [https://www.rt.com/business/588045-russia-stock-exchange-sanctions/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/588045-russia-stock-exchange-sanctions/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T11:06:09+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/656471ba85f540067c556076.jpg" style="margin-right: 10px;" /> Russia’s SPB Exchange has refuted reports of insolvency resulting from US sanctions <br /><a href="https://www.rt.com/business/588045-russia-stock-exchange-sanctions/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Crimea declares ‘state of emergency’ (VIDEOS)
 - [https://www.rt.com/russia/588050-russia-crimea-storm-emergency/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/588050-russia-crimea-storm-emergency/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T11:05:05+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/656477812030270733114d5c.jpg" style="margin-right: 10px;" /> Authorities in the Russian region took the step after it was hit by ‘the storm of the century’ <br /><a href="https://www.rt.com/russia/588050-russia-crimea-storm-emergency/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Africans must radically alter conditions - South African minister
 - [https://www.rt.com/africa/588046-cape-town-conversation-pandor/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/africa/588046-cape-town-conversation-pandor/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T10:27:35+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6564635385f5403fc555d456.jpg" style="margin-right: 10px;" /> South African minister for international relations has expressed concern about the ongoing underdevelopment of African economies <br /><a href="https://www.rt.com/africa/588046-cape-town-conversation-pandor/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## West ‘screwed over’ Ukraine – ex-presidential aide
 - [https://www.rt.com/russia/588047-west-screwed-ukraine-military-aid/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/588047-west-screwed-ukraine-military-aid/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T10:04:09+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/656467df2030270b4d68121e.jpg" style="margin-right: 10px;" /> The West has abandoned Ukraine by failing to provide it with enough weapons, Aleksey Arestovich has said <br /><a href="https://www.rt.com/russia/588047-west-screwed-ukraine-military-aid/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Only 16% of Russians believe Ukraine is a democracy – poll
 - [https://www.rt.com/russia/588041-ukraine-democracy-poll-russians/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/588041-ukraine-democracy-poll-russians/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T09:42:56+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6564629b85f5407a4543735a.jpg" style="margin-right: 10px;" /> A survey has shown prevailing skepticism among Russians over Ukraine’s political system and independence  <br /><a href="https://www.rt.com/russia/588041-ukraine-democracy-poll-russians/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Investors dumping dollar – FT
 - [https://www.rt.com/business/587935-investors-selling-dollar-positions/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/587935-investors-selling-dollar-positions/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T09:20:32+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6560d5322030276f522a83df.jpg" style="margin-right: 10px;" /> Asset managers are set to unload 1.6% of their dollar positions this month in the largest sell-off since last year, the FT says <br /><a href="https://www.rt.com/business/587935-investors-selling-dollar-positions/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Moscow hit by unusual ‘black blizzard’ (VIDEOS)
 - [https://www.rt.com/russia/588029-moscow-snowfall-black-blizzard/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/588029-moscow-snowfall-black-blizzard/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T08:14:46+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/65644b7520302728dc61ba85.jpg" style="margin-right: 10px;" /> Heavy snowfall that started in Moscow overnight is expected to continue into Tuesday, Mayor Sergey Sobyanin has warned <br /><a href="https://www.rt.com/russia/588029-moscow-snowfall-black-blizzard/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russia blasts American ‘falsehoods’ on Soviet famine
 - [https://www.rt.com/news/588034-us-holodomor-narrative-ambassador/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/588034-us-holodomor-narrative-ambassador/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T08:11:10+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/65644b8485f5407a4543734b.jpg" style="margin-right: 10px;" /> Russia’s Ambassador in Washington Anatoly Antonov has blasted the US government’s stance on the Holodomor <br /><a href="https://www.rt.com/news/588034-us-holodomor-narrative-ambassador/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Israel to hit Hamas ‘with full force’ after truce ends – Netanyahu
 - [https://www.rt.com/news/588028-israel-hit-hamas-truce-ends/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/588028-israel-hit-hamas-truce-ends/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T07:40:49+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6564479e20302712df24fa1e.jpg" style="margin-right: 10px;" /> Benjamin Netanyahu has said Israel is open to extending the truce with Hamas but will continue to attack the group after it is over <br /><a href="https://www.rt.com/news/588028-israel-hit-hamas-truce-ends/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## ‘Death rate’ of UK businesses rising – report
 - [https://www.rt.com/business/587810-uk-businesses-closures-crisis/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/587810-uk-businesses-closures-crisis/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T07:17:02+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/655e2a8385f540432e771a18.jpg" style="margin-right: 10px;" /> A record number of businesses have closed up across the UK amid the cost-of-living crisis, the ONS reports <br /><a href="https://www.rt.com/business/587810-uk-businesses-closures-crisis/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## War with Hamas damaging Israel’s economy – Moody’s
 - [https://www.rt.com/business/587859-israel-hamas-war-cost/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/587859-israel-hamas-war-cost/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T05:54:34+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/655f684e85f54044a0408fe5.jpg" style="margin-right: 10px;" /> The Israeli economy is set to face multiple shocks from reduced investment, a disrupted labor market, and plummeting demand, Moody’s says

  <br /><a href="https://www.rt.com/business/587859-israel-hamas-war-cost/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## US Senate announces vote on Ukraine aid
 - [https://www.rt.com/news/588020-us-senate-vote-ukraine-aid/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/588020-us-senate-vote-ukraine-aid/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T05:54:15+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6564252e85f54001f12096c5.jpg" style="margin-right: 10px;" /> The White House is trying to push through $106bn in funding for Ukraine, Israel and Taiwan <br /><a href="https://www.rt.com/news/588020-us-senate-vote-ukraine-aid/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Rescue mission to save men trapped in tunnel enters third week
 - [https://www.rt.com/india/588019-india-tunnel-uttarakhand-men-trapped/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/india/588019-india-tunnel-uttarakhand-men-trapped/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T05:26:08+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6564277f85f540636915d83f.jpg" style="margin-right: 10px;" /> Efforts continue to reach 41 construction workers who have been trapped inside a mountain in Uttarakhand for over two weeks <br /><a href="https://www.rt.com/india/588019-india-tunnel-uttarakhand-men-trapped/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Musk to meet Israeli president
 - [https://www.rt.com/news/588018-musk-israel-visit-antisemitism/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/588018-musk-israel-visit-antisemitism/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T02:32:41+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6563ff822030272f7e68b77f.jpg" style="margin-right: 10px;" /> Elon Musk, the owner of the X (formerly Twitter) social media network, is set to meet with Israeli President Isaac Herzog on Monday <br /><a href="https://www.rt.com/news/588018-musk-israel-visit-antisemitism/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## ‘Russia will not lose’ – EU member state
 - [https://www.rt.com/news/588017-orban-russia-will-not-lose/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/588017-orban-russia-will-not-lose/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-27T00:56:23+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6563e8c985f5407d3119a8a0.png" style="margin-right: 10px;" /> Hungarian Prime Minister Viktor Orban said that the US and the European Union’s strategy of funding Ukraine’s battle with Russia is futile <br /><a href="https://www.rt.com/news/588017-orban-russia-will-not-lose/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

