# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Teenage Sequence - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=2wOR8uEjVGM](https://www.youtube.com/watch?v=2wOR8uEjVGM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-11-27T16:00:02+00:00

http://KEXP.ORG presents Teenage Sequence performing live in the KEXP studio. Recorded, October 26, 2023

Songs:
The City Is Hungover
I Can
All This Art
Tell Me Your Name

Dewan-Dean Soomary - Vocals, Laptop, Pedal Board Manipulation
Nick Tamburro - Percussion, Sampler, Synth
Rob Barrett - Drums

Host: Troy Nelson
Audio Engineer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Scott Holpainen
Editor: Luke Knecht

https://teenagesequence.bandcamp.com
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Teenage Sequence - I Can (Live on KEXP)
 - [https://www.youtube.com/watch?v=l4wyqa59Gmw](https://www.youtube.com/watch?v=l4wyqa59Gmw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-11-27T12:00:44+00:00

http://KEXP.ORG presents Teenage Sequence performing “I Can” live in the KEXP studio. Recorded, October 26, 2023

Dewan-Dean Soomary - Vocals, Laptop, Pedal Board Manipulation
Nick Tamburro - Percussion, Sampler, Synth
Rob Barrett - Drums

Host: Troy Nelson
Audio Engineer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Scott Holpainen
Editor: Luke Knecht

https://teenagesequence.bandcamp.com
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Teenage Sequence - Tell Me Your Name (Live on KEXP)
 - [https://www.youtube.com/watch?v=WFilAd_4Zvc](https://www.youtube.com/watch?v=WFilAd_4Zvc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-11-27T12:00:25+00:00

http://KEXP.ORG presents Teenage Sequence performing “Tell Me Your Name” live in the KEXP studio. Recorded, October 26, 2023

Dewan-Dean Soomary - Vocals, Laptop, Pedal Board Manipulation
Nick Tamburro - Percussion, Sampler, Synth
Rob Barrett - Drums

Host: Troy Nelson
Audio Engineer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Scott Holpainen
Editor: Luke Knecht

https://teenagesequence.bandcamp.com
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Teenage Sequence - The City Is Hungover (Live on KEXP)
 - [https://www.youtube.com/watch?v=FNKiKia1pzI](https://www.youtube.com/watch?v=FNKiKia1pzI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-11-27T12:00:19+00:00

http://KEXP.ORG presents Teenage Sequence performing “The City Is Hungover” live in the KEXP studio. Recorded, October 26, 2023

Dewan-Dean Soomary - Vocals, Laptop, Pedal Board Manipulation
Nick Tamburro - Percussion, Sampler, Synth
Rob Barrett - Drums

Host: Troy Nelson
Audio Engineer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Scott Holpainen
Editor: Luke Knecht

https://teenagesequence.bandcamp.com
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Teenage Sequence - All This Art (Live on KEXP)
 - [https://www.youtube.com/watch?v=MWeDiq1UuqM](https://www.youtube.com/watch?v=MWeDiq1UuqM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-11-27T12:00:16+00:00

http://KEXP.ORG presents Teenage Sequence performing “All This Art” live in the KEXP studio. Recorded, October 26, 2023

Dewan-Dean Soomary - Vocals, Laptop, Pedal Board Manipulation
Nick Tamburro - Percussion, Sampler, Synth
Rob Barrett - Drums

Host: Troy Nelson
Audio Engineer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Scott Holpainen
Editor: Luke Knecht

https://teenagesequence.bandcamp.com
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

