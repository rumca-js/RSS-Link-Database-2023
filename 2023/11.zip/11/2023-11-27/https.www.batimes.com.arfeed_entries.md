# Source:Argentina - Buenos Aires Times, URL:https://www.batimes.com.ar/feed, language:en

## President Fernández denounces 'threats' against him in interview
 - [https://www.batimes.com.ar/news/argentina/president-fernandez-denounces-threats-against-him-in-interview.phtml](https://www.batimes.com.ar/news/argentina/president-fernandez-denounces-threats-against-him-in-interview.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2023-11-27T16:50:43+00:00

<p><img alt="President Alberto Fernández." src="https://fotos.perfil.com/2023/11/27/trim/540/304/president-alberto-fernandez-1707189.jpg" /></p>President Alberto Fernandez says he has subjected to threats while travelling in the state helicopter.
 <a href="https://www.batimes.com.ar/news/argentina/president-fernandez-denounces-threats-against-him-in-interview.phtml">Leer más</a>

## Milei lines up ‘protocol meetings’ in United States with IMF, World Bank
 - [https://www.batimes.com.ar/news/argentina/milei-lines-up-protocol-meetings-in-united-states-with-imf-world-bank.phtml](https://www.batimes.com.ar/news/argentina/milei-lines-up-protocol-meetings-in-united-states-with-imf-world-bank.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2023-11-27T14:27:57+00:00

<p><img alt="Javier Milei, Nicolás Posse and Luis Caputo." src="https://fotos.perfil.com/2023/11/27/trim/540/304/javier-milei-nicolas-posse-and-luis-caputo-1706999.jpg" /></p>President-elect has meetings scheduled with Juan Gonzalez, the National Security Council senior director for Western Hemisphere affairs, and officials from International Monetary Fund and World Bank.
 <a href="https://www.batimes.com.ar/news/argentina/milei-lines-up-protocol-meetings-in-united-states-with-imf-world-bank.phtml">Leer más</a>

