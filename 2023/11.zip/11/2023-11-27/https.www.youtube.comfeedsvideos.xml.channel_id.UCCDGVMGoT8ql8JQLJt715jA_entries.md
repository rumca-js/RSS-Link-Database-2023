# Source:emzdanowicz, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCCDGVMGoT8ql8JQLJt715jA, language:pl

## Przez Rosję po czesku. Recenzja Last Train Home
 - [https://www.youtube.com/watch?v=yBq0wjkvsv4](https://www.youtube.com/watch?v=yBq0wjkvsv4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCCDGVMGoT8ql8JQLJt715jA
 - date published: 2023-11-27T14:10:00+00:00

Jak wypadło połączenie survivalowo-managementowej rozgrywki i RTS-a? Nawet nieźle. Recenzja Last Train Home.

Subskrybuj, to pomaga w rozwoju kanału :)

I oglądajcie recenzję Talos Principle 2, bo to grzech, że takie arcydzieło (gra, nie moja recenzja xD) ma mało wyświetleń! Hańba! https://www.youtube.com/watch?v=ivB8qObAbj8

#lasttrainhome #recenzja

