# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## The Killer - Movie Review
 - [https://www.youtube.com/watch?v=dS0NH3fd6Gw](https://www.youtube.com/watch?v=dS0NH3fd6Gw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2023-11-27T14:00:24+00:00

Install Star Trek Fleet Command for FREE now https://t2m.io/JeremyJahnsSTFC and enter the promo code WARPSPEED to unlock 10 Epic Shards of Kirk, enhancing your command instantly! How to easily redeem the promo code 👉 
https://t2m.io/promo_STFC

David Fincher brings us a look into the life of a hitman on a quest for vengeance. Here's my review for THE KILLER!

