# Source:Nautilus, URL:https://nautil.us/feed/, language:en-US

## My 3 Greatest Revelations
 - [https://nautil.us/my-3-greatest-revelations-6-449438](https://nautil.us/my-3-greatest-revelations-6-449438)
 - RSS feed: https://nautil.us/feed/
 - date published: 2023-11-27T16:16:33+00:00

<p>The author on writing her new book "Curious Species: How Animals Made Natural History."</p>
<p>The post <a href="https://nautil.us/my-3-greatest-revelations-6-449438/">My 3 Greatest Revelations</a> appeared first on <a href="https://nautil.us">Nautilus</a>.</p>

