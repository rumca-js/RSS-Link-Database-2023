# Source:Wydarzenia Interia - Świat, URL:https://wydarzenia.interia.pl/swiat/feed, language:pl-PL

## Wyszedł z własnego wesela, po chwili wrócił z bronią. Pięć osób nie żyje
 - [https://wydarzenia.interia.pl/zagranica/news-wyszedl-z-wlasnego-wesela-po-chwili-wrocil-z-bronia-piec-oso,nId,7174539](https://wydarzenia.interia.pl/zagranica/news-wyszedl-z-wlasnego-wesela-po-chwili-wrocil-z-bronia-piec-oso,nId,7174539)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-11-27T10:44:05+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wyszedl-z-wlasnego-wesela-po-chwili-wrocil-z-bronia-piec-oso,nId,7174539"><img align="left" alt="Wyszedł z własnego wesela, po chwili wrócił z bronią. Pięć osób nie żyje " src="https://i.iplsc.com/wyszedl-z-wlasnego-wesela-po-chwili-wrocil-z-bronia-piec-oso/000A7XCPA8EA76B2-C321.jpg" /></a>Tajlandzki sportowiec z niepełnosprawnością na własnym przyjęciu weselnym zastrzelił świeżo poślubioną małżonkę, jej matkę oraz siostrę. Kule raniły też gości weselnych, a jeden z nich zmarł w szpitalu. Pan młody, działający najprawdopodobniej pod wpływem środków odurzających, odebrał sobie życie. Według świadków tragedii para miała się wcześniej pokłócić. </p><br clear="all" />

## Kolejna wymiana zakładników. Pojawiły się komplikacje
 - [https://wydarzenia.interia.pl/raport-wojna-w-izraelu/news-kolejna-wymiana-zakladnikow-pojawily-sie-komplikacje,nId,7174375](https://wydarzenia.interia.pl/raport-wojna-w-izraelu/news-kolejna-wymiana-zakladnikow-pojawily-sie-komplikacje,nId,7174375)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-11-27T05:48:37+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wojna-w-izraelu/news-kolejna-wymiana-zakladnikow-pojawily-sie-komplikacje,nId,7174375"><img align="left" alt="Kolejna wymiana zakładników. Pojawiły się komplikacje" src="https://i.iplsc.com/kolejna-wymiana-zakladnikow-pojawily-sie-komplikacje/000I3BMYDDU7DAD1-C321.jpg" /></a>Wymiana więźniów między Izraelem a Hamasem trwa od piątku. Czwartego dnia rozejmu w walkach między stronami pojawiły się jednak pewne komplikacje. Izrael otrzymał listę zakładników, którzy w poniedziałek mają być uwolnieni ze Strefy Gazy przez palestyńską organizację terrorystyczną Hamas - donosi Times of Izrael. 11 osób, których nazwiska znalazły się na liście, znajdą się na wolności po ponad 50 dniach.</p><br clear="all" />

