# Source:The Moscow Times - Independent News From Russia, URL:https://www.themoscowtimes.com/rss/news, language:en-us

## Crimean Treasures Return to Kyiv After Years of Legal Battles
 - [https://www.themoscowtimes.com/2023/11/27/crimean-treasures-return-to-kyiv-after-years-of-legal-battles-a83231](https://www.themoscowtimes.com/2023/11/27/crimean-treasures-return-to-kyiv-after-years-of-legal-battles-a83231)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2023-11-27T16:48:05+00:00

The Scythian artifacts – some around 2,000 years old – were on loan to Amsterdam's Allard Pierson museum when they were suddenly at the center of a geopolitical crisis following Russia's 2014 annexation of Crimea.

## Russian Central Bank To Resume Currency Trades in 2024
 - [https://www.themoscowtimes.com/2023/11/27/russian-central-bank-to-resume-currency-trades-in-2024-a83230](https://www.themoscowtimes.com/2023/11/27/russian-central-bank-to-resume-currency-trades-in-2024-a83230)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2023-11-27T14:22:33+00:00

The Bank had suspended those transactions in August as the ruble slid below 100 against the U.S. dollar.

## Ex-Russian State TV Reporter Sent to 'Punishment Pit' in Occupied Ukraine
 - [https://www.themoscowtimes.com/2023/11/27/ex-russian-state-tv-reporter-sent-to-punishment-pit-in-occupied-ukraine-a83229](https://www.themoscowtimes.com/2023/11/27/ex-russian-state-tv-reporter-sent-to-punishment-pit-in-occupied-ukraine-a83229)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2023-11-27T13:52:04+00:00

Ilya Andreyev was reportedly sentenced to punishment in a hole dug in the ground after he asked for 10 days of leave to renew his expired passport.

## Soaring Turkish Exports of Military-Linked Goods to Russia Raise Western Concerns – FT
 - [https://www.themoscowtimes.com/2023/11/27/soaring-turkish-exports-of-military-linked-goods-to-russia-raise-western-concerns-ft-a83224](https://www.themoscowtimes.com/2023/11/27/soaring-turkish-exports-of-military-linked-goods-to-russia-raise-western-concerns-ft-a83224)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2023-11-27T12:53:09+00:00

Turkish exports are labeled as being destined for Azerbaijan, Georgia, Kazakhstan, Kyrgyzstan and Uzbekistan, but authorities there do not report increased imports.

## Three Killed In Methane Blast In Siberian Mine
 - [https://www.themoscowtimes.com/2023/11/27/three-killed-in-methane-blast-in-siberian-mine-a83226](https://www.themoscowtimes.com/2023/11/27/three-killed-in-methane-blast-in-siberian-mine-a83226)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2023-11-27T12:20:00+00:00

Accidents at Russian mines and factories are relatively common due to an often lax approach to safety measures.

## Russia Intensely Attacking Avdiivka, Robotyne, Says Ukraine
 - [https://www.themoscowtimes.com/2023/11/27/russia-intensely-attacking-avdiivka-robotyne-says-ukraine-a83227](https://www.themoscowtimes.com/2023/11/27/russia-intensely-attacking-avdiivka-robotyne-says-ukraine-a83227)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2023-11-27T11:52:26+00:00

Neither side has made significant breakthroughs on the battlefield for weeks, as Moscow's invasion drags on for a 22nd month.

## 'Storm of the Century' Kills 1, Cuts Power to Almost 700K in Crimea and Donetsk
 - [https://www.themoscowtimes.com/2023/11/27/storm-of-the-century-kills-1-cuts-power-to-almost-700k-in-crimea-and-donetsk-a83223](https://www.themoscowtimes.com/2023/11/27/storm-of-the-century-kills-1-cuts-power-to-almost-700k-in-crimea-and-donetsk-a83223)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2023-11-27T10:36:22+00:00

Winds reached speeds of 144 kilometers per hour along the coast of southern Ukraine and Russia.

## 'Storm of the Century' Kills 1, Cuts Power to 2Mln in  Russia, Occupied Ukraine
 - [https://www.themoscowtimes.com/2023/11/27/storm-of-the-century-kills-1-cuts-power-to-2mln-in-russia-occupied-ukraine-a83223](https://www.themoscowtimes.com/2023/11/27/storm-of-the-century-kills-1-cuts-power-to-2mln-in-russia-occupied-ukraine-a83223)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2023-11-27T10:36:00+00:00

Winds reached speeds of 144 kilometers per hour along the coast of southern Ukraine and Russia.

## 'Storm of the Century' Kills 4, Cuts Power to 2Mln in Russia, Occupied Ukraine
 - [https://www.themoscowtimes.com/2023/11/27/storm-of-the-century-kills-4-cuts-power-to-2mln-in-russia-occupied-ukraine-a83223](https://www.themoscowtimes.com/2023/11/27/storm-of-the-century-kills-4-cuts-power-to-2mln-in-russia-occupied-ukraine-a83223)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2023-11-27T10:36:00+00:00

Winds reached speeds of 144 kilometers per hour along the coast of southern Ukraine and Russia.

