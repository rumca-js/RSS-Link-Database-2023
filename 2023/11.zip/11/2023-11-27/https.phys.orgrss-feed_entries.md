# Source:Phys.org - latest science and technology news stories, URL:https://phys.org/rss-feed/, language:en-us

## International Criminal Court judges 'cautious' about using impact of mental health
 - [https://phys.org/news/2023-11-international-criminal-court-cautious-impact.html](https://phys.org/news/2023-11-international-criminal-court-cautious-impact.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T17:23:03+00:00

International Criminal Court judges have taken a "cautious" attitude to considering the impact of mental health issues on witnesses and the accused, a new analysis shows.

## Protected Texas songbirds show up in pet stores abroad, due to elusive trafficking industry
 - [https://phys.org/news/2023-11-texas-songbirds-pet-due-elusive.html](https://phys.org/news/2023-11-texas-songbirds-pet-due-elusive.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T17:21:04+00:00

In 1970, there were approximately 10 billion birds in North America. Now, there are around 7 billion, representing a loss of over a quarter of the continent's birds.

## Shared community spaces are key to tackling issues caused by Cornish gentrification, study says
 - [https://phys.org/news/2023-11-community-spaces-key-tackling-issues.html](https://phys.org/news/2023-11-community-spaces-key-tackling-issues.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T17:16:03+00:00

Creating and fostering "shared spaces" can help to tackle the problems caused by gentrification and changing communities in Cornwall, a new study says.

## Giant sea salt aerosols found to play major role in Hawai'i's coastal clouds, rain
 - [https://phys.org/news/2023-11-giant-sea-salt-aerosols-play.html](https://phys.org/news/2023-11-giant-sea-salt-aerosols-play.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T17:15:04+00:00

Despite their tiny sizes, aerosols, such as sea salt, dust, and ash, play a giant role in shaping weather and climate. These particles scatter light, act as the starting point for cloud formation, and can even initiate or limit rainfall. A new study from atmospheric scientists at the University of Hawai'i at Mānoa has revealed that the coastline can produce up to five times the concentration of giant sea salt aerosols compared to the open ocean and that coastal clouds may contain more of these particles than clouds over the open ocean—affecting cloud formation and rain around the Hawaiian Islands.

## Study finds your profile picture plays a significant role in whether you get hired
 - [https://phys.org/news/2023-11-profile-picture-plays-significant-role.html](https://phys.org/news/2023-11-profile-picture-plays-significant-role.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T17:11:03+00:00

A study has found that your online profile picture may play a key role in whether you get hired. The study also found that if your profile photo suggests you "look the part," those hiring you as an employee or freelancer may be more likely to give that more weight than lower ratings, lack of certifications and a fewer number of reviews than your close competitors.

## Review article shows key role of Brazil in research on sugarcane for bioenergy
 - [https://phys.org/news/2023-11-article-key-role-brazil-sugarcane.html](https://phys.org/news/2023-11-article-key-role-brazil-sugarcane.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T17:07:04+00:00

Publications on sugar cane have increased exponentially since 2006 worldwide, and Brazil has had more articles published on the topic than any other country in the period, according to a review in BioEnergy Research.

## Framing nationalism in former colonies
 - [https://phys.org/news/2023-11-nationalism-colonies.html](https://phys.org/news/2023-11-nationalism-colonies.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T16:54:04+00:00

Conquest, subjugation and plunder are words that spring to mind when we consider colonization. George Orwell, who spent time during the 1920s as a policeman for the British occupiers in what was then Burma, described colonization as a racist system of "despotism with theft as its final object."

## Sensitive ecosystems at risk from mine waste, finds study
 - [https://phys.org/news/2023-11-sensitive-ecosystems.html](https://phys.org/news/2023-11-sensitive-ecosystems.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T16:50:03+00:00

Nearly a third of the world's mine tailings are stored within or near protected conservation areas, University of Queensland research has found. A study led by UQ's Bora Aska, from the Sustainable Minerals Institute and School of the Environment, said these waste facilities pose an enormous risk to some of Earth's most precious species and landscapes.

## Researchers pave the way for faster and safer T-cell therapy through novel contamination-detection method
 - [https://phys.org/news/2023-11-pave-faster-safer-t-cell-therapy.html](https://phys.org/news/2023-11-pave-faster-safer-t-cell-therapy.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T16:46:04+00:00

Researchers from Critical Analytics for Manufacturing Personalized-Medicine (CAMP) Interdisciplinary Research Group (IRG) at Singapore-MIT Alliance for Research and Technology (SMART), MIT's research enterprise in Singapore, in collaboration with Singapore Centre for Environmental Life Sciences Engineering (SCELSE) and Massachusetts Institute of Technology (MIT), have developed a novel method capable of identifying contaminants in T-cell cultures within 24 hours.

## New research shows extra practice in blending letter sounds helps struggling readers
 - [https://phys.org/news/2023-11-extra-blending-letter-struggling-readers.html](https://phys.org/news/2023-11-extra-blending-letter-struggling-readers.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T16:43:03+00:00

New research at Aston University has shown that extra practice in blending printed letter sounds can help struggling beginner readers in reception classes learn to read.

## Calciferous organisms are a good tool in climate research, says scientist
 - [https://phys.org/news/2023-11-calciferous-good-tool-climate-scientist.html](https://phys.org/news/2023-11-calciferous-good-tool-climate-scientist.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T16:41:03+00:00

The fossil calciferous skeletons of single-celled foraminifers are a beautiful history book with information on CO2-levels in the oceans of the distant past.

## Smog from major Copenhagen street heads straight into living rooms
 - [https://phys.org/news/2023-11-smog-major-copenhagen-street-straight.html](https://phys.org/news/2023-11-smog-major-copenhagen-street-straight.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T16:38:04+00:00

A large amount of the heavy automobile pollution from Copenhagen's Bispeengbuen thoroughfare goes straight into people's homes, according to a study by researchers at the University of Copenhagen. A sensor developed by one of the researchers can help fill in the blanks of our understanding about local air pollution.

## Inferring causative microbial features from metagenomic data of limited samples
 - [https://phys.org/news/2023-11-inferring-causative-microbial-features-metagenomic.html](https://phys.org/news/2023-11-inferring-causative-microbial-features-metagenomic.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T16:34:03+00:00

Increasing evidence has shown an association between gut microbiota and numerous diseases inferred by metagemomic (MWAS), indicating the microbiota as one of the most promising and effective strategies to control these diseases. However, inferring causalities and strong associations from high-dimensional data are very challenging, leading to low concordance in causal microbe identification between metagenomic studies.

## Recycled phosphorus fertilizer reduces nutrient leaching, maintains yield
 - [https://phys.org/news/2023-11-recycled-phosphorus-fertilizer-nutrient-leaching.html](https://phys.org/news/2023-11-recycled-phosphorus-fertilizer-nutrient-leaching.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T16:07:51+00:00

A promising new form of ammonium phosphate fertilizer has been field-tested by University of Illinois Urbana-Champaign researchers. The fertilizer, struvite, offers a triple win for sustainability and crop production, as it recycles nutrients from wastewater streams, reduces leaching of phosphorus and nitrogen in agricultural soils, and maintains or improves soybean yield compared to conventional phosphorus fertilizers.

## Owner personality and mental well-being associated with human–pet attachment
 - [https://phys.org/news/2023-11-owner-personality-mental-well-being-humanpet.html](https://phys.org/news/2023-11-owner-personality-mental-well-being-humanpet.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T16:07:45+00:00

University of Helsinki researchers have collected data about the personality traits of thousands of dogs, cats and their owners to explore owner–pet attachment. The data encompass about 2,500 pet owners and 3,300 pets. The work is published in the journal iScience.

## Research links climate change to vampire bat expansion and rabies virus spillover
 - [https://phys.org/news/2023-11-links-climate-vampire-expansion-rabies.html](https://phys.org/news/2023-11-links-climate-vampire-expansion-rabies.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T16:07:40+00:00

Vampire bats may soon take up residence in the United States and bring with them an ancient pathogen. "What we found was that the distribution of vampire bats has moved northward across time due to past climate change, which has corresponded with an increase in rabies cases in many Latin American countries," said Paige Van de Vuurst, a Ph.D. student in Virginia Tech's Translational Biology, Medicine, and Health Graduate Program.

## PhD graduates with disabilities are underpaid and underrepresented in US academia: Study
 - [https://phys.org/news/2023-11-phd-disabilities-underpaid-underrepresented-academia.html](https://phys.org/news/2023-11-phd-disabilities-underpaid-underrepresented-academia.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T16:07:03+00:00

New research from the Johns Hopkins Disability Health Research Center suggests that Ph.D. graduates in science, technology, engineering and medicine (STEM) in the U.S. who became disabled before age 25 earn $14,360 less per year in academia than those without disabilities. They are also underrepresented at higher faculty levels (such as deans and presidents) and in tenured positions.

## Emergence of collective phenomena in fractured rocks: Exploring the 'more is different' perspective
 - [https://phys.org/news/2023-11-emergence-phenomena-fractured-exploring-perspective.html](https://phys.org/news/2023-11-emergence-phenomena-fractured-exploring-perspective.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T16:02:02+00:00

For many decades, the rock mechanics community has been tacitly assumed that a rock mass can be equated to the sum of fractures and intact rocks. Accordingly, the behavior of a rock mass can be understood by decomposing it into smaller pieces and characterizing these pieces completely. However, from the statistical physics point of view, this commonly assumed equation (i.e. rock mass = fractures + intact rocks) is either incorrect or at least incomplete.

## Durable, inexpensive electrocatalyst generates clean hydrogen and oxygen from water
 - [https://phys.org/news/2023-11-durable-inexpensive-electrocatalyst-generates-hydrogen.html](https://phys.org/news/2023-11-durable-inexpensive-electrocatalyst-generates-hydrogen.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T15:59:03+00:00

A new electrocatalyst made of nickel (Ni), iron (Fe) and silicon (Si) that decreases the amount of energy required to synthesize H2 from water has been manufactured in a simple and cost-effective way, increasing the practicality of H2 as a clean and renewable energy of the future.

## New automatic algorithm unveils key insights into leaf orientation and plant productivity
 - [https://phys.org/news/2023-11-automatic-algorithm-unveils-key-insights.html](https://phys.org/news/2023-11-automatic-algorithm-unveils-key-insights.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T15:46:03+00:00

Maize (Zea mays L.), the most globally produced cereal, owes its enhanced productivity to genetic, agronomic, and climatic factors, with cultivars adapted to higher density playing a crucial role. Recent research has focused on maize's architectural plasticity, particularly its ability to adapt leaf architecture to maximize light interception under varying densities. This adaptation includes leaf reorientation, a response to intraspecific competition, influenced by changes in red to far-red light ratios.

## Revolutionizing plant disease diagnosis: Pre-trained models outperform traditional methods
 - [https://phys.org/news/2023-11-revolutionizing-disease-diagnosis-pre-trained-outperform.html](https://phys.org/news/2023-11-revolutionizing-disease-diagnosis-pre-trained-outperform.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T15:39:08+00:00

Diagnosing plant disease is essential to meet the world's growing food demand, which is expected to increase with a population of 9.1 billion by 2050. Diseases can reduce crop yields by 20–40%, so early detection is critical. Traditional disease identification methods include expert analysis and machine learning-based image processing. However, the manual approach is inefficient and error-prone, while machine learning, particularly deep learning methods like Convolutional Neural Networks (CNNs), has revolutionized disease detection by extracting detailed image features.

## Gig workers saw greater financial hardship during COVID-19 than other workers
 - [https://phys.org/news/2023-11-gig-workers-greater-financial-hardship.html](https://phys.org/news/2023-11-gig-workers-greater-financial-hardship.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T15:38:06+00:00

Many gig workers experienced financial hardships during the COVID-19 pandemic, including food insecurity and trouble paying bills, according to a recent study published in Work and Occupations.

## Using the world's three most powerful particle accelerators to reveal the space-time geometry of quark matter
 - [https://phys.org/news/2023-11-world-powerful-particle-reveal-space-time.html](https://phys.org/news/2023-11-world-powerful-particle-reveal-space-time.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T15:32:29+00:00

Physicists from the Eötvös Loránd University (ELTE) have been conducting research on the matter constituting the atomic nucleus utilizing the world's three most powerful particle accelerators. Their focus has been on mapping the "primordial soup" that filled the universe in the first millionth of a second following its inception.

## Study show extracellular vesicles can also deliver messages from non-human cells
 - [https://phys.org/news/2023-11-extracellular-vesicles-messages-non-human-cells.html](https://phys.org/news/2023-11-extracellular-vesicles-messages-non-human-cells.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T15:14:03+00:00

Messenger bubbles produced by human cells can pick up bacterial products and deliver them to other cells, University of Connecticut researchers report in the Nov. 16 issue of  Nature Cell Biology. The discovery may explain a key mechanism by which bacteria, whether friendly or infectious, affect our health.

## Why does puberty trigger us to stop growing?
 - [https://phys.org/news/2023-11-puberty-trigger.html](https://phys.org/news/2023-11-puberty-trigger.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T15:00:01+00:00

All animals start out as a single-celled organism and then start growing. At some point, of course, they need to stop getting bigger, but the process by which this happens is poorly understood.

## Orbital-angular-momentum-encoded diffractive networks for object classification tasks
 - [https://phys.org/news/2023-11-orbital-angular-momentum-encoded-diffractive-networks-classification-tasks.html](https://phys.org/news/2023-11-orbital-angular-momentum-encoded-diffractive-networks-classification-tasks.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T14:58:03+00:00

Deep learning has revolutionized the way we perceive and utilize data. However, as datasets grow and computational demands increase, we need more efficient ways to handle, store, and process data. In this regard, optical computing is seen as the next frontier of computing technology. Rather than using electronic signals, optical computing relies on the properties of light waves, such as wavelength and polarization, to store and process data.

## Team discovers protein crucial for B cell differentiation and antibodies
 - [https://phys.org/news/2023-11-team-protein-crucial-cell-differentiation.html](https://phys.org/news/2023-11-team-protein-crucial-cell-differentiation.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T14:49:06+00:00

A cell nucleus is a busy place. Cellular proteins twist and pull DNA, folding the genome into intricate 3D structures that support functioning of its coding parts.

## Researchers hijack solar cell technology to develop a simple spray test for lead
 - [https://phys.org/news/2023-11-hijack-solar-cell-technology-simple.html](https://phys.org/news/2023-11-hijack-solar-cell-technology-simple.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T14:46:04+00:00

AMOLF researchers have used the special properties of perovskite semiconductors to develop a simple spray test to demonstrate the presence of lead. Perovskite is a material suitable for use in LEDs and solar cells, for example. A lead-containing surface shines bright green when it is sprayed with the test. This test is 1,000 times more sensitive than existing tests and the researchers found no false positive or false negative results. The study was published on November 27 in the journal Environmental Science & Technology.

## Study is the first to document dialect differences in a parrot across its European range
 - [https://phys.org/news/2023-11-document-dialect-differences-parrot-european.html](https://phys.org/news/2023-11-document-dialect-differences-parrot-european.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T14:40:03+00:00

In the 50 years since monk parakeets arrived in Europe and spread across the continent, the species has developed distinct dialects that vary across countries and cities, according to a team of researchers from the Max Planck Institutes of Animal Behavior in Konstanz and for Evolutionary Anthropology in Leipzig, Germany.

## How minimum wage rises will affect the early years education and childcare sector
 - [https://phys.org/news/2023-11-minimum-wage-affect-early-years.html](https://phys.org/news/2023-11-minimum-wage-affect-early-years.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T14:35:04+00:00

The early years sector—nurseries and childminders who offer services to children under the age of five—waited expectantly for news of investment in the UK chancellor's recent autumn statement. But this was not delivered, even though Jeremy Hunt presented 110 economic measures designed to boost UK growth and productivity.

## Black Friday is an environmental nightmare. The Victorians had a much more sustainable approach to fashion
 - [https://phys.org/news/2023-11-black-friday-environmental-nightmare-victorians.html](https://phys.org/news/2023-11-black-friday-environmental-nightmare-victorians.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T14:34:03+00:00

Around 46 million people across the UK are expected to have visited their local high street to go shopping over the last weekend in November, encouraged by so-called Black Friday sales. The projected spend in-store and online is forecast to reach close to £9 billion.

## Having a single parent doesn't determine your life chances. Data shows poverty is far more important
 - [https://phys.org/news/2023-11-parent-doesnt-life-chances-poverty.html](https://phys.org/news/2023-11-parent-doesnt-life-chances-poverty.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T14:30:01+00:00

Numerous research studies have suggested that children from a single-parent family are worse off than those who have two parents at home. These findings chime with decades of stigma that have painted coming from a single-parent home as undesirable.

## Understanding charged particles helps physicists simulate element creation in stars
 - [https://phys.org/news/2023-11-particles-physicists-simulate-element-creation.html](https://phys.org/news/2023-11-particles-physicists-simulate-element-creation.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T14:29:03+00:00

New research from North Carolina State University and Michigan State University opens a new avenue for modeling low-energy nuclear reactions, which are key to the formation of elements within stars. The research lays the groundwork for calculating how nucleons interact when the particles are electrically charged.

## Gender-based violence: Teaching about its root causes is necessary to address it
 - [https://phys.org/news/2023-11-gender-based-violence-root.html](https://phys.org/news/2023-11-gender-based-violence-root.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T14:20:01+00:00

In 2022, 184 women and girls were killed by violence in Canada. This number has steadily increased in each of the past three years; 148 women and girls were killed in 2019, 172 in 2020 and 177 in 2021.

## Climate crisis: What to consider if you're questioning whether to have children
 - [https://phys.org/news/2023-11-climate-crisis-youre-children.html](https://phys.org/news/2023-11-climate-crisis-youre-children.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T14:10:01+00:00

The warnings about the disastrous impact we are having on our planet are becoming more dire. The UN Environment Program's most recent emissions gap report, which tracks our progress in limiting global warming, revealed that the world is on course for a "hellish" 3°C of global heating before the end of this century.

## Collaboration between women helps close the gender gap in ice core science
 - [https://phys.org/news/2023-11-collaboration-women-gender-gap-ice.html](https://phys.org/news/2023-11-collaboration-women-gender-gap-ice.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T14:05:25+00:00

A Perspective article published today in Nature Geoscience tackles the longstanding issue of gender representation in science, focusing on the field of ice core science.

## Q&A: 'We need to act very fast,' says sustainability researcher
 - [https://phys.org/news/2023-11-qa-fast-sustainability.html](https://phys.org/news/2023-11-qa-fast-sustainability.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T14:04:06+00:00

The effects of climate change are increasingly tangible. Reforms at the Intergovernmental Panel on Climate Change (IPCC) could serve to increase its political clout and thus advance the battle against global warming, argues sustainability researcher Bernd Siebenhüner.

## Storm leaves thousands without power in Crimea
 - [https://phys.org/news/2023-11-storm-thousands-power-crimea.html](https://phys.org/news/2023-11-storm-thousands-power-crimea.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T14:03:41+00:00

Over 400,000 people in Crimea were left without power on Monday, after hurricane force winds and heavy rains battered the Russian-annexed peninsula over the weekend.

## Extreme rainfall increases exponentially with global warming: Study
 - [https://phys.org/news/2023-11-extreme-rainfall-exponentially-global.html](https://phys.org/news/2023-11-extreme-rainfall-exponentially-global.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T14:01:29+00:00

State-of-the-art climate models drastically underestimate how much extreme rainfall increases under global warming, according to a study published Monday that signals a future of more frequent catastrophic floods unless humanity curbs greenhouse emissions.

## It's not a cost of living crisis. It's a poverty pandemic
 - [https://phys.org/news/2023-11-crisis-poverty-pandemic.html](https://phys.org/news/2023-11-crisis-poverty-pandemic.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T14:00:01+00:00

There is a poverty crisis in the UK. But when outlining his 110 growth measures aimed at getting "the British economy working" during his autumn statement, the chancellor's measures to tackle the cost of living crisis were limited to economic support payments focused on short-term wins.

## A critically endangered Sumatran rhino named Delilah successfully gives birth in Indonesia
 - [https://phys.org/news/2023-11-critically-endangered-sumatran-rhino-delilah.html](https://phys.org/news/2023-11-critically-endangered-sumatran-rhino-delilah.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T13:59:12+00:00

A critically endangered Sumatran rhino was born in Indonesia's western island of Sumatra on Saturday, the second Sumatran rhino born in the country this year and a welcome addition to a species that currently numbers fewer than 50 animals.

## Nonprofit organizations can act as drivers of sustainability for multinational companies
 - [https://phys.org/news/2023-11-nonprofit-drivers-sustainability-multinational-companies.html](https://phys.org/news/2023-11-nonprofit-drivers-sustainability-multinational-companies.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T13:56:35+00:00

For successful nonprofit impact on business governance, it is essential to advocacy nonprofit organizations to engage key business stakeholders, a new study from the University of Eastern Finland shows. These stakeholders, such as employees, investors, politicians and the media, can be influenced by nonprofit organizations in various ways. The study has been published in Nonprofit and Voluntary Sector Quarterly.

## Culling gray squirrels not necessary for overall biodiversity, expert suggests
 - [https://phys.org/news/2023-11-culling-gray-squirrels-biodiversity-expert.html](https://phys.org/news/2023-11-culling-gray-squirrels-biodiversity-expert.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T13:56:32+00:00

Life on Earth is facing the greatest rate of extinction in history—and humans are the disruptive force, according to a leading ecologist.

## A method for the early prediction of El Niño events with high hazard potential
 - [https://phys.org/news/2023-11-method-early-el-nio-events.html](https://phys.org/news/2023-11-method-early-el-nio-events.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T13:56:28+00:00

At irregular intervals, a momentous weather phenomenon called El Niño (Spanish for "Christ Child") occurs in the Pacific. The warm surface water initially driven by the trade winds towards the coasts of Indonesia and eastern Australia then sloshes back eastwards, which can have devastating consequences.

## Advanced AI techniques for predicting and visualizing citrus fruit maturity
 - [https://phys.org/news/2023-11-advanced-ai-techniques-visualizing-citrus.html](https://phys.org/news/2023-11-advanced-ai-techniques-visualizing-citrus.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T13:55:03+00:00

Citrus, the world's most valuable fruit crop, is at a crossroads with slowing production growth and a focus on improving fruit quality and post-harvest processes. Key to this is understanding citrus color change, a critical indicator of fruit maturity, traditionally gauged by human judgment.

## What is the 'sunk cost fallacy'? Is it ever a good thing?
 - [https://phys.org/news/2023-11-sunk-fallacy-good.html](https://phys.org/news/2023-11-sunk-fallacy-good.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T13:50:01+00:00

Have you ever encountered a subpar hotel breakfast while on holiday? You don't really like the food choices on offer, but since you already paid for the meal as part of your booking, you force yourself to eat something anyway rather than go down the road to a cafe.

## Trying to spend less on food? Following the dietary guidelines might save you $160 a fortnight
 - [https://phys.org/news/2023-11-food-dietary-guidelines-fortnight.html](https://phys.org/news/2023-11-food-dietary-guidelines-fortnight.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T13:40:01+00:00

A rise in the cost of living has led many households to look for ways to save money.

## May the 'Star Wars' vocabulary be with us
 - [https://phys.org/news/2023-11-star-wars-vocabulary.html](https://phys.org/news/2023-11-star-wars-vocabulary.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T13:35:44+00:00

These days, "Star Wars" is everywhere. There are numerous films and all kinds of merchandise. But is "Star Wars" also an integral part of the English language? That is the question Prof Dr. Christina Sanchez-Stockhammer, chair of English and Digital Linguistics at Chemnitz University of Technology, set out to investigate. "I wanted to find out whether words from the 'Star Wars' universe have already become part of our own universe," notes the linguist.

## We've committed to protect 30% of Australia's land by 2030. Here's how we could actually do it
 - [https://phys.org/news/2023-11-weve-committed-australia.html](https://phys.org/news/2023-11-weve-committed-australia.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T13:35:13+00:00

In the mid 1990s, only 7% of Australia's land was protected for conservation. Now, it's more than tripled to 22%.

## Carved trees and burial sites: Wiradjuri Elders share the hidden stories of marara and dhabuganha
 - [https://phys.org/news/2023-11-trees-burial-sites-wiradjuri-elders.html](https://phys.org/news/2023-11-trees-burial-sites-wiradjuri-elders.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T13:34:08+00:00

Aboriginal and Torres Strait Islander readers are advised that the following contains information about deceased persons, ceremonial practices, and Men's and Women's Business with the permission of the Gaanha-bula Action Group.

## Stones inside fish ears mark time like tree rings. How they're helping us learn about climate change
 - [https://phys.org/news/2023-11-stones-fish-ears-tree-theyre.html](https://phys.org/news/2023-11-stones-fish-ears-tree-theyre.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T13:34:04+00:00

As a marine biologist, I've always found it fascinating to learn about how animals adapt to their habitat. But climate change has made it more important than ever—wild animals' futures may depend on how much we understand about them.

## Enhancing rice biomass estimation with UAV-based models
 - [https://phys.org/news/2023-11-rice-biomass-uav-based.html](https://phys.org/news/2023-11-rice-biomass-uav-based.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T13:32:03+00:00

Aboveground biomass (AGB) of rice, vital for carbon pool and yield estimation, is traditionally measured through labor-intensive manual sampling. Recent advancements employ remote sensing, particularly unmanned aerial vehicles (UAVs), to derive vegetation indices (VIs) from plant interactions with the electromagnetic spectrum.

## High-valence metal-doped amorphous IrOx as stable electrocatalyst for acidic oxygen evolution reaction
 - [https://phys.org/news/2023-11-high-valence-metal-doped-amorphous-irox-stable.html](https://phys.org/news/2023-11-high-valence-metal-doped-amorphous-irox-stable.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T13:30:03+00:00

Hydrogen has been regarded as a potential energy carrier instead of fossil fuels, addressing energy demand and environmental issues. Proton exchange membrane water electrolysis (PEMWE), with its high energy density, elevated hydrogen purity, and rapid system response, is considered an ideal and sustainable approach to produce green hydrogen. Thus, it could be an effective solution to mitigate the intermittency and volatility of renewable energies and benefit their large-scale application.

## Green growth or degrowth: What is the right way to tackle climate change?
 - [https://phys.org/news/2023-11-green-growth-degrowth-tackle-climate.html](https://phys.org/news/2023-11-green-growth-degrowth-tackle-climate.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T13:30:01+00:00

Nearly all the world's governments and vast numbers of its people are convinced that addressing human-induced climate change is essential if healthy societies are to survive. The two solutions most often proposed go by various names but are widely known as "green growth" and "degrowth." Can these ideas be reconciled? What do both have to say about the climate challenge?

## Comprehensive analysis of the telomere-to-telomere genome of soybean cultivar ZH13
 - [https://phys.org/news/2023-11-comprehensive-analysis-telomere-to-telomere-genome-soybean.html](https://phys.org/news/2023-11-comprehensive-analysis-telomere-to-telomere-genome-soybean.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T13:27:03+00:00

Soybean (Glycine max) is one of the most crucial oil and protein crops, and contributes to more than a quarter of the protein utilized in both human food and animal feed. It is widely acknowledged that the cultivated soybean emerged through the domestication of its annual ancestor in the Yellow River basin. Therefore, the exploration of genetic resources within the origin region bears immense significance in advancing the global frontiers of soybean breeding.

## Coping with uncertainty in customer demand: How mathematics can improve logistics processes
 - [https://phys.org/news/2023-11-coping-uncertainty-customer-demand-mathematics.html](https://phys.org/news/2023-11-coping-uncertainty-customer-demand-mathematics.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T13:20:03+00:00

How do you distribute drinking water fairly across an area recently hit by a natural disaster? Or how can you make sure you have enough bottles of water, granola bars and fruit in your delivery van to refill all the vending machines at a school when you don't know how full they are?

## Climate adaptation funds are not reaching front-line communities: What needs to be done about it
 - [https://phys.org/news/2023-11-climate-funds-front-line-communities.html](https://phys.org/news/2023-11-climate-funds-front-line-communities.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T13:20:01+00:00

Communities around the world face increasingly severe and frequent impacts from climate change. They are on the "frontlines" of droughts, flooding, desertification and sea level rise.

## Next-generation space telescopes could use deformable mirrors to image Earth-sized worlds
 - [https://phys.org/news/2023-11-next-generation-space-telescopes-deformable-mirrors.html](https://phys.org/news/2023-11-next-generation-space-telescopes-deformable-mirrors.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T13:19:04+00:00

Observing distant objects is no easy task, thanks to our planet's thick and fluffy atmosphere. As light passes through the upper reaches of our atmosphere, it is refracted and distorted, making it much harder to discern objects at cosmological distances (billions of light years away) and small objects in adjacent star systems like exoplanets.

## Most unmarried, low-income couples show positive co-parenting
 - [https://phys.org/news/2023-11-unmarried-low-income-couples-positive-co-parenting.html](https://phys.org/news/2023-11-unmarried-low-income-couples-positive-co-parenting.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T13:14:12+00:00

Despite the many challenges they face, slightly more than half of unmarried low-income couples with children have positive co-parenting relationships, a new study found.

## Oral delivery a possibility for silica-based nanocarriers for therapeutics
 - [https://phys.org/news/2023-11-oral-delivery-possibility-silica-based-nanocarriers.html](https://phys.org/news/2023-11-oral-delivery-possibility-silica-based-nanocarriers.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T13:10:24+00:00

Take a pill, or get a shot? Given the choice, most people would likely go for the former.

## A novel quantification method for ribonucleotides, which are needed in almost all cellular processes
 - [https://phys.org/news/2023-11-quantification-method-ribonucleotides-cellular.html](https://phys.org/news/2023-11-quantification-method-ribonucleotides-cellular.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T13:10:01+00:00

RNA (ribonucleic acid), which is made up of ribonucleotides, is a molecule found in all living organisms. RNA is thought to have probably preceded DNA in primordial life billions of years ago. RNA was eventually replaced by DNA as a chemically more stable carrier of genetic information.

## A new map points at the impacts of rare earth elements
 - [https://phys.org/news/2023-11-impacts-rare-earth-elements.html](https://phys.org/news/2023-11-impacts-rare-earth-elements.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T13:09:38+00:00

A map created by the Debt Observatory in Globalization in collaboration with the EJAtlas of Institute of Environmental Science and Technology of the Universitat Autònoma de Barcelona (ICTA-UAB), the Institute for Policy Studies and CRAAD-OI Madagascar, documents 28 social and environmental conflicts derived from the extraction, processing and recycling of these minerals.

## Q&A: Scientific collaboration paves the way to cleaner technologies for industry
 - [https://phys.org/news/2023-11-qa-scientific-collaboration-paves-cleaner.html](https://phys.org/news/2023-11-qa-scientific-collaboration-paves-cleaner.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T13:08:52+00:00

During the nearly five decades of its operation, the European Molecular Biology Laboratory (EMBL) in Hamburg has developed many fruitful collaborations with other scientific institutions located in the Hamburg metropolitan area. One example is the long-lasting collaboration between researchers at EMBL Hamburg and the Center for Biobased Solutions (CBBS) at the Hamburg University of Technology (TUHH), which has recently yielded new insights into the structure and function of a lipid-degrading enzyme found in a microbe adapted to living in extreme conditions. The findings could help improve chemical processes in various branches of industry.

## Japanese snail adaptation and speciation in anti-predation escape behavior
 - [https://phys.org/news/2023-11-japanese-snail-speciation-anti-predation-behavior.html](https://phys.org/news/2023-11-japanese-snail-speciation-anti-predation-behavior.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T13:04:02+00:00

Snails often get a bad rap for being slow and inefficient and are sometimes used to express laziness. However, a team of researchers from Kyoto and Hokkaido has now revealed that snails are anything but lazy, particularly when feeling threatened. Two species of the genus Karaftohelix—K editha and K gainesi—showed opposite behaviors in response to predator-like stimuli.

## Researchers reveal the 'Viral Language' of the pandemic
 - [https://phys.org/news/2023-11-reveal-viral-language-pandemic.html](https://phys.org/news/2023-11-reveal-viral-language-pandemic.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T13:01:04+00:00

Remember "COVIDiots" and the first protests by "anti-vaxxers"?

## Here's why union support is so high right now
 - [https://phys.org/news/2023-11-union-high.html](https://phys.org/news/2023-11-union-high.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T13:00:53+00:00

Over 65,000 teachers in Québec could remain on strike until Christmas if a deal isn't reached, their union said on Sunday. The warning comes amid widespread labor unrest in the province, including nearly 570,000 workers on strike at the same time last week.

## Algorithmic recommendation technology or human curation? Study of online news outlet suggests both
 - [https://phys.org/news/2023-11-algorithmic-technology-human-curation-online.html](https://phys.org/news/2023-11-algorithmic-technology-human-curation-online.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T13:00:28+00:00

Recommender systems are machine learning applications in online platforms that automate tasks historically done by people. In the news industry, recommender algorithms can assume the tasks of editors who select which news stories people see online, with the goal of increasing the number of clicks by users, but few studies have examined how the two compare.

## Alien haze, cooked in a lab, clears view to distant water worlds
 - [https://phys.org/news/2023-11-alien-haze-cooked-lab-view.html](https://phys.org/news/2023-11-alien-haze-cooked-lab-view.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T13:00:03+00:00

Scientists have simulated conditions that allow hazy skies to form in water-rich exoplanets, a crucial step in determining how haziness muddles observations by ground and space telescopes.

## Quality of tidal mudflats changes in gas extraction area of Wadden Sea
 - [https://phys.org/news/2023-11-quality-tidal-mudflats-gas-area.html](https://phys.org/news/2023-11-quality-tidal-mudflats-gas-area.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T12:59:09+00:00

As tidal flats subside due to gas extraction, their composition changes. This is shown in a paper published in this month's Journal of Applied Ecology. "The average grain size in the parts of the mudflats where gas is extracted has decreased over 10% in 12 years. With that, sand is getting finer," says NIOZ researcher Allert Bijleveld. In this period, the composition of the benthic life in subsided areas has also changed in comparison to similar areas where subsidence due to gas extraction did not occur.

## Making a difference, belonging drives rural festival volunteers and bolsters community development
 - [https://phys.org/news/2023-11-difference-rural-festival-volunteers-bolsters.html](https://phys.org/news/2023-11-difference-rural-festival-volunteers-bolsters.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T12:58:31+00:00

During Orange City's three-day tulip festival each May, the northwest Iowa town attracts roughly 40,000 visitors, more than six times its population. People come for the blooms and parades, traditional Dutch food and musical theater. For the community, it's an opportunity to celebrate its cultural heritage and give a boost to local businesses.

## PUNCH mission advances toward 2025 launch
 - [https://phys.org/news/2023-11-mission-advances.html](https://phys.org/news/2023-11-mission-advances.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T12:57:57+00:00

On November 17, 2023, the Polarimeter to UNify the Corona and Heliosphere (PUNCH) mission achieved an important milestone, passing its internal system integration review and clearing the mission to start integrating its four observatories. Southwest Research Institute (SwRI) leads PUNCH, a NASA Small Explorer (SMEX) mission that will integrate understanding of the sun's corona, the outer atmosphere visible during total solar eclipses, with the "solar wind" that fills and defines the solar system. SwRI is also building the spacecraft and three of its five instruments.

## Longing to know about longhorn beetles in Australia
 - [https://phys.org/news/2023-11-longhorn-beetles-australia.html](https://phys.org/news/2023-11-longhorn-beetles-australia.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T12:57:34+00:00

The Titan beetle (Titanus giganteus) is the biggest beetle in the world. It's a dark brown colored longhorn that lives in the Amazon and grows to 17.7 centimeters long.

## Facilitating learning chemistry with conceptual modeling
 - [https://phys.org/news/2023-11-chemistry.html](https://phys.org/news/2023-11-chemistry.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T12:50:38+00:00

A team of researchers and teachers from the University of Twente have developed a novel teaching method that uses conceptual modeling to facilitate learning and foster creativity in classrooms of chemical science and engineering students. The students tackled real-world problems related to sustainability.

## Beaver exploitation testifies to prey choice diversity of Middle Pleistocene hominins
 - [https://phys.org/news/2023-11-beaver-exploitation-testifies-prey-choice.html](https://phys.org/news/2023-11-beaver-exploitation-testifies-prey-choice.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T12:50:28+00:00

Exploitation of smaller game is rarely documented before the latest phases of the Pleistocene, which is often taken to imply narrow diets for earlier hominins.

## Silk lines help pirate spiders trick, capture eight-legged prey
 - [https://phys.org/news/2023-11-silk-lines-pirate-spiders-capture.html](https://phys.org/news/2023-11-silk-lines-pirate-spiders-capture.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T12:50:19+00:00

Headlamps alone illuminated the trail bisecting the Costa Rican rainforest. Having waded the black of the Tirimbina reserve so often before, Gilbert Barrantes, Laura Segura Hernández and Diego Solano Brenes knew the routine.

## Using the principles of evolution to defeat cancer
 - [https://phys.org/news/2023-11-principles-evolution-defeat-cancer.html](https://phys.org/news/2023-11-principles-evolution-defeat-cancer.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T12:44:25+00:00

November 24 marked 164 years since the publication of Charles Darwin's revolutionary "On the Origin of Species," one of the most influential scientific books ever written. In acknowledgement, 24 November is known as "Evolution Day" or the quirkier titled "All Our Uncles are Monkeys Day." The Institute of Cancer Research feels bound to commemorate this important work that challenged, and eventually transformed, our understanding of the natural world.

## Researcher: Honeybees cluster together when it's cold, but we've been completely wrong about why
 - [https://phys.org/news/2023-11-honeybees-cluster-cold-weve-wrong.html](https://phys.org/news/2023-11-honeybees-cluster-cold-weve-wrong.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T12:44:11+00:00

Honeybees in man-made hives may have been suffering the cold unnecessarily for over a century because commercial hive designs are based on erroneous science, my new research shows.

## Human rights law demands climate change adaptation, researchers say
 - [https://phys.org/news/2023-11-human-rights-law-demands-climate.html](https://phys.org/news/2023-11-human-rights-law-demands-climate.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T12:44:04+00:00

Continued high emissions of greenhouse gases mean the well-being of all people now depends on profound changes in policies and practices to effect climate change adaptation.

## New study analyzes how people choose friendships at school
 - [https://phys.org/news/2023-11-people-friendships-school.html](https://phys.org/news/2023-11-people-friendships-school.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T12:44:00+00:00

Researchers from the Universidad Carlos III de Madrid (UC3M), the Polytechnic University of Madrid (UPM) and Loyola University have discovered that personality does not seem to have much influence when it comes to choosing social friendships at school, which are based more on the closeness of our contacts, according to a study recently published in the journal PNAS.

## Researchers develop photoactivatable nanomedicine for the treatment of age-related macular degeneration
 - [https://phys.org/news/2023-11-photoactivatable-nanomedicine-treatment-age-related-macular.html](https://phys.org/news/2023-11-photoactivatable-nanomedicine-treatment-age-related-macular.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T12:43:43+00:00

Researchers at the LKS Faculty of Medicine of the University of Hong Kong (HKUMed), and collaborators from the Zhongshan Ophthalmic Center of Sun Yat-sen University, Guangzhou, have developed a light-activatable prodrug nanomedicine for age-related macular degeneration (AMD) therapy.

## Pocket-sized DNA sequencers track malaria drug resistance in Ghana in near real-time
 - [https://phys.org/news/2023-11-pocket-sized-dna-sequencers-track-malaria.html](https://phys.org/news/2023-11-pocket-sized-dna-sequencers-track-malaria.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T12:43:23+00:00

Scientists have developed a technique to rapidly and reliably detect genetic changes in malaria parasites in Ghana, using just a gaming laptop and portable MinION sequencer from Oxford Nanopore.

## New fluorescence-based methods for fast and accessible light intensity measurements
 - [https://phys.org/news/2023-11-fluorescence-based-methods-fast-accessible-intensity.html](https://phys.org/news/2023-11-fluorescence-based-methods-fast-accessible-intensity.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T12:43:07+00:00

Accurate measurements of light intensity provide vital data for scientists and everyday applications. For example, precise values help optimize microscopy signals, trigger physiological processes in the brain, and drive light-absorbing reactions while enabling different research teams to share and reproduce experimental results.

## More than a meteorite: New clues about the demise of dinosaurs
 - [https://phys.org/news/2023-11-meteorite-clues-demise-dinosaurs.html](https://phys.org/news/2023-11-meteorite-clues-demise-dinosaurs.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T12:42:43+00:00

What wiped out the dinosaurs? A meteorite plummeting to Earth is only part of the story, a new study suggests. Climate change triggered by massive volcanic eruptions may have ultimately set the stage for the dinosaur extinction, challenging the traditional narrative that a meteorite alone delivered the final blow to the ancient giants.

## The psychology of success in data science contest design
 - [https://phys.org/news/2023-11-psychology-success-science-contest.html](https://phys.org/news/2023-11-psychology-success-science-contest.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T12:41:37+00:00

In today's data-driven world, holding data science competitions is a popular way to address real-world problems. Companies leverage these competitions to crowdsource solutions and strategically attract potential employees. Recent research from the University of Waterloo highlights the importance of motivating participants in these competitions through the appropriate contest structure and incentives to achieve success.

## Crop yield prediction: New model uses sun-induced chlorophyll fluorescence for enhanced photosynthetic trait estimation
 - [https://phys.org/news/2023-11-crop-yield-sun-induced-chlorophyll-fluorescence.html](https://phys.org/news/2023-11-crop-yield-sun-induced-chlorophyll-fluorescence.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T12:41:03+00:00

Crops use carbon dioxide (CO2) through photosynthesis to create organic matter, with enhanced photosynthetic rates crucial for meeting global food demands. While crop phenomics has focused on structural traits, it's the functional traits like maximum carboxylation rate (Vcmax) and stomatal conductance (gs) that are vital for accurate predictions of crop yield.

## Night study of native plant survival
 - [https://phys.org/news/2023-11-night-native-survival.html](https://phys.org/news/2023-11-night-native-survival.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T12:35:03+00:00

With land clearance, bushfires, weeds and climate change, small pockets of native vegetation are important for future plant and animal conservation—but do plants in small reserves struggle with reduced habitat for both plants and their pollinators?

## The 'jigglings and wigglings of atoms' reveal key aspects of COVID-19 virulence evolution
 - [https://phys.org/news/2023-11-jigglings-wigglings-atoms-reveal-key.html](https://phys.org/news/2023-11-jigglings-wigglings-atoms-reveal-key.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T12:34:04+00:00

Richard Feynman famously stated, "Everything that living things do can be understood in terms of the jigglings and wigglings of atoms." This week, Nature Nanotechnology features a study that sheds new light on the evolution of the coronavirus and its variants of concern by analyzing the behavior of atoms in the proteins at the interface between the virus and humans.

## New platform solves key problems in targeted drug delivery
 - [https://phys.org/news/2023-11-platform-key-problems-drug-delivery.html](https://phys.org/news/2023-11-platform-key-problems-drug-delivery.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T12:32:06+00:00

In recent years, cell and gene therapies have shown significant promise for treating cancer, cystic fibrosis, diabetes, heart disease, HIV/AIDS and other difficult-to-treat diseases. But the lack of effective ways to deliver biological treatments into the body has posed a major barrier for bringing these new therapies to the market—and, ultimately, to the patients who need them most.

## JWST reveals protoplanetary disks in a nearby star cluster
 - [https://phys.org/news/2023-11-jwst-reveals-protoplanetary-disks-nearby.html](https://phys.org/news/2023-11-jwst-reveals-protoplanetary-disks-nearby.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T12:31:03+00:00

The Orion Nebula is a favorite among stargazers. It's a giant stellar nebula out of which, hot young stars are forming. Telescopically to the eye it appears as a gray/green haze of wonderment but cameras reveal the true glory of these star forming regions. The sun was once part of such an object and astronomers have been probing their secrets for decades.

## Where are all the double planets?
 - [https://phys.org/news/2023-11-planets.html](https://phys.org/news/2023-11-planets.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T12:29:04+00:00

A recent study published in the Monthly Notices of the Royal Astronomical Society examines formation mechanisms for how binary planets—two large planetary bodies orbiting each other—can be produced from a type of tidal heating known as tidal dissipation, or the energy that is shared between two planetary bodies as the orbit close to each other, which the Earth and our moon experiences.

## Dark matter could help solve the final parsec problem of black holes
 - [https://phys.org/news/2023-11-dark-parsec-problem-black-holes.html](https://phys.org/news/2023-11-dark-parsec-problem-black-holes.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T12:28:02+00:00

When galaxies collide, their supermassive black holes enter into a gravitational dance, gradually orbiting each other ever closer until eventually merging. We know they merge because we see the gravitational beasts that result, and we have detected the gravitational waves they emit as they inspiral. But the details of their final consummation remain a mystery. Now a new paper published on the pre-print server arXiv suggests part of that mystery can be solved with a bit of dark matter.

## What would happen to Earth if a rogue star came too close?
 - [https://phys.org/news/2023-11-earth-rogue-star.html](https://phys.org/news/2023-11-earth-rogue-star.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T12:26:04+00:00

Stars are gravitationally fastened to their galaxies and move in concert with their surroundings. But sometimes, something breaks the bond. If a star gets too close to a supermassive black hole, for example, the black hole can expel it out into space as a rogue star.

## Vera Rubin Observatory will find binary supermassive black holes: Here's how
 - [https://phys.org/news/2023-11-vera-rubin-observatory-binary-supermassive.html](https://phys.org/news/2023-11-vera-rubin-observatory-binary-supermassive.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T12:23:04+00:00

When galaxies merge, we expect them to produce binary black holes (BBHs.) BBHs orbit one another closely, and when they merge, they produce gravitational waves that have been detected by LIGO-Virgo. The upcoming Vera Rubin Observatory should be able to find them before they merge, which would open a whole new window into the study of galaxy mergers, supermassive black holes, binary black holes, and gravitational waves.

## Enhancing the immunosuppressive properties of human umbilical cord mesenchymal stem cells
 - [https://phys.org/news/2023-11-immunosuppressive-properties-human-umbilical-cord.html](https://phys.org/news/2023-11-immunosuppressive-properties-human-umbilical-cord.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T12:01:03+00:00

Mesenchymal stem cells (MSCs) have great potential for the treatment of various immune diseases due to their unique immunomodulatory properties. However, MSCs exposed to the harsh inflammatory environment of damaged tissue after intravenous transplantation cannot exert their biological effects, and therefore, their therapeutic efficacy is reduced.

## Deoxygenation levels similar to today's played major role in marine extinctions 200 million years ago
 - [https://phys.org/news/2023-11-deoxygenation-similar-today-played-major.html](https://phys.org/news/2023-11-deoxygenation-similar-today-played-major.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T11:54:04+00:00

Scientists have made a surprising discovery that sheds new light on the role that oceanic deoxygenation (anoxia) played in one of the most devastating extinction events in Earth's history. Their finding has implications for current-day ecosystems—and serves as a warning that marine environments are likely more fragile than apparent.

## There are many reasons disabled people can't just work from home: Cutting benefits won't fix the wider problems
 - [https://phys.org/news/2023-11-disabled-people-home-benefits-wont.html](https://phys.org/news/2023-11-disabled-people-home-benefits-wont.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T11:50:06+00:00

As part of the UK government's latest economic plan, disabled people may have to look for jobs they can do from home or face cuts to their benefits. Previously, disabled people with limited ability to work may have received benefits without being required to look for work. Now, Laura Trott, chief secretary to the Treasury, has said that disabled people not in work must "do their duty" and work from home.

## Opinion: Responsible ESG investing in the Global South requires overcoming the Global North's savior complex
 - [https://phys.org/news/2023-11-opinion-responsible-esg-investing-global.html](https://phys.org/news/2023-11-opinion-responsible-esg-investing-global.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T11:50:04+00:00

ESG standards (Environment, Social and Governance) are metrics designed to guide responsible investing. The "S" in ESG has evolved into the financial innovation of social impact investing (SII), which promotes social benefits such as environmental protection, gender equality and human development, and also generates profits for beneficiaries and investors.

## This tiny spinal stimulator could someday have a big impact on paralysis
 - [https://phys.org/news/2023-11-tiny-spinal-big-impact-paralysis.html](https://phys.org/news/2023-11-tiny-spinal-big-impact-paralysis.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T11:39:03+00:00

A Johns Hopkins materials scientist and a team of collaborators have developed a tiny device that may hold promise for restoring mobility to those with lower limb paralysis, a condition affecting approximately 1.4 million Americans.

## Groundbreaking method to match celestial objects across telescopes
 - [https://phys.org/news/2023-11-groundbreaking-method-celestial-telescopes.html](https://phys.org/news/2023-11-groundbreaking-method-celestial-telescopes.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T11:38:04+00:00

A team of Johns Hopkins researchers has developed a cutting-edge data science approach capable of matching observations of celestial objects taken across multiple telescope surveys, overcoming a significant challenge in modern astronomy.

## Unlocking long-term genetic memory: Dormant bacterial spores offer key insights into evolutionary survival strategies
 - [https://phys.org/news/2023-11-long-term-genetic-memory-dormant-bacterial.html](https://phys.org/news/2023-11-long-term-genetic-memory-dormant-bacterial.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T11:34:03+00:00

A recent study spearheaded by Prof. Sigal Ben Yehuda and her team at Hebrew University has unveiled a captivating facet of bacterial dormancy. Their research illuminates the mechanism through which dormant bacterial spores uphold and activate an enduring transcriptional program upon revival, showcasing an extraordinary genetic memory system.

## Scientists 'fingerprint' methane to track a climate change culprit
 - [https://phys.org/news/2023-11-scientists-fingerprint-methane-track-climate.html](https://phys.org/news/2023-11-scientists-fingerprint-methane-track-climate.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T11:21:04+00:00

Methane is the second-most abundant greenhouse gas in Earth's atmosphere, and its emissions have been rapidly—and mysteriously—rising since 2007. Though pervasive, the origin of the colorless compound is tricky to trace, complicating efforts to curb gases that trap heat in the atmosphere and warm the planet.

## Researchers pioneer a new way of searching for dark matter
 - [https://phys.org/news/2023-11-dark.html](https://phys.org/news/2023-11-dark.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T11:19:04+00:00

The existence of dark matter is a long-standing puzzle in our universe. Dark matter makes up about a quarter of our universe, yet it does not interact significantly with ordinary matter.

## All-weather solar-powered CO&#8322; utilization achieved by mimicking natural photosynthesis
 - [https://phys.org/news/2023-11-all-weather-solar-powered-co8322-mimicking-natural.html](https://phys.org/news/2023-11-all-weather-solar-powered-co8322-mimicking-natural.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T11:15:03+00:00

In a study published in National Science Review, researchers from the Institute of Earth Environment of the Chinese Academy of Sciences (CAS), together with collaborators, have used the charge storage mechanism of tungsten-based nanomaterials for all-weather carbon dioxide (CO2) conversion.

## Study unveils new insights into asymmetric particle collisions
 - [https://phys.org/news/2023-11-unveils-insights-asymmetric-particle-collisions.html](https://phys.org/news/2023-11-unveils-insights-asymmetric-particle-collisions.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T11:12:02+00:00

A study has been published in Nuclear Science and Techniques, by researchers led by Prof. Hua Zheng from Shaanxi Normal University, heralding a significant breakthrough in high-energy particle physics. This study sheds new light on the behavior of particles in high-energy collisions, an area of research integral to deepening our understanding of the universe's origins.

## Researchers use AI to increase the high-temperature strength of nickel–aluminum alloys
 - [https://phys.org/news/2023-11-ai-high-temperature-strength-nickelaluminum-alloys.html](https://phys.org/news/2023-11-ai-high-temperature-strength-nickelaluminum-alloys.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T11:09:03+00:00

A materials research team consisting of NIMS and Nagoya University has designed a novel two-step thermal aging schedule (i.e., non-isothermal aging or unconventional heat treatment) capable of fabricating nickel-aluminum (Ni-Al) alloys that are stronger at high temperatures than Ni-Al alloys fabricated using conventional thermal aging processes.

## Solar storms hit more locally than expected: Current instrument network too sparse, says study
 - [https://phys.org/news/2023-11-solar-storms-locally-current-instrument.html](https://phys.org/news/2023-11-solar-storms-locally-current-instrument.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T10:55:04+00:00

A new study shows that there is greater local variation in the impact of solar storms on Earth than previously estimated. Researchers show that the effects can vary widely even over distances as small as 100 kilometers. The findings are published in Scientific Reports.

## A new approach to the sensible use of carbon dioxide from car exhaust gases
 - [https://phys.org/news/2023-11-approach-carbon-dioxide-car-exhaust.html](https://phys.org/news/2023-11-approach-carbon-dioxide-car-exhaust.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T10:51:03+00:00

Using impure CO2 from car exhaust, the team of Prof. Dr. Shoubik Das, Chair of Organic Chemistry I at the University of Bayreuth, presents a cost-effective synthetic route for γ-lactams. γ-Lactam is an organic chemical compound, which is an inhibitory neurotransmitter. This means that CO2, which is frequently produced anyway, can be put to good use. Valuable chemicals and pharmaceuticals can be combined with this CO2. The paper is published in the journal Nature Communications.

## Molecular cooperation at the threshold of life
 - [https://phys.org/news/2023-11-molecular-cooperation-threshold-life.html](https://phys.org/news/2023-11-molecular-cooperation-threshold-life.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T10:45:04+00:00

Protein-like aggregates known as amyloids can bind to molecules of genetic material. It is possible that these two types of molecules stabilized each other during the development of life—and that this might even have paved the way for the genetic code.

## Was 'witchcraft' in the Devil's Church in Koli based on acoustic resonance?
 - [https://phys.org/news/2023-11-witchcraft-devil-church-koli-based.html](https://phys.org/news/2023-11-witchcraft-devil-church-koli-based.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T10:25:03+00:00

The national park of Koli in eastern Finland is home to a famous, 34-meter-long crevice cave known as Pirunkirkko, or Devil's Church in English. In folklore, this crevice cave was known as a place where local sages would meet to contact the spirit world. Even today, the place is visited by practitioners of shamanism, who organize drumming sessions in the cave.

## Research advances magnetic graphene for low-power electronics
 - [https://phys.org/news/2023-11-advances-magnetic-graphene-low-power-electronics.html](https://phys.org/news/2023-11-advances-magnetic-graphene-low-power-electronics.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T10:23:04+00:00

National University of Singapore (NUS) physicists have developed a concept to induce and directly quantify spin splitting in two-dimensional materials. By using this concept, they have experimentally achieved large tunability and a high degree of spin-polarization in graphene. This research achievement can potentially advance the field of two-dimensional (2D) spintronics, with applications for low-power electronics.

## Experiment shows how water-filled channels crisscrossing multi-crystal ice lead to fractures
 - [https://phys.org/news/2023-11-water-filled-channels-crisscrossing-multi-crystal-ice.html](https://phys.org/news/2023-11-water-filled-channels-crisscrossing-multi-crystal-ice.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T10:10:01+00:00

A combined team of materials scientists and engineers from the Swiss Federal Institute of Technology and Yale University, has shown via lab experiment, how water-filled channels crisscrossing multi-crystal ice can lead to fractures in materials such as cement and asphalt. In their paper published in the journal Physical Review Letters, the group describes the experiments they conducted with transparent objects, water and silicone, to show how liquid channels in ice can lead to fractures in porous materials.

## CRISPR-powered optothermal nanotweezers
 - [https://phys.org/news/2023-11-crispr-powered-optothermal-nanotweezers.html](https://phys.org/news/2023-11-crispr-powered-optothermal-nanotweezers.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T09:59:01+00:00

Optothermal nanotweezers are an innovative optical design method that has revolutionized classical optical techniques to capture a broad range of nanoparticles. While the optothermal temperature field can be employed for in situ regulation of nanoparticles, challenges remain in identifying their potential for regulating bionanoparticles.

## New insights into broken symmetries: Applying the Lorentz reciprocal theorem to fluids with odd viscosities
 - [https://phys.org/news/2023-11-insights-broken-symmetries-lorentz-reciprocal.html](https://phys.org/news/2023-11-insights-broken-symmetries-lorentz-reciprocal.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T09:56:03+00:00

The Lorentz reciprocal theorem can now be applied to fluids with broken symmetries. Scientists at the Max Planck Institute for Dynamics and Self-Organization (MPI-DS) in Göttingen have found a way to also accommodate this classical theorem in fluids with odd viscosities. Their discovery opens a new way to explore systems with broken symmetries.

## Potential threats, promising resources in thriving colonies of bacteria and fungi on ocean plastic trash
 - [https://phys.org/news/2023-11-potential-threats-resources-colonies-bacteria.html](https://phys.org/news/2023-11-potential-threats-resources-colonies-bacteria.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T09:48:04+00:00

A team of scientists from the Nanyang Technological University, Singapore (NTU Singapore) has found both potential threats and promising resources in the thriving colonies of bacteria and fungi on plastic trash washed up on Singapore shores.

## Researchers describe the journey of thermal antibubbles in a hot bath
 - [https://phys.org/news/2023-11-journey-thermal-antibubbles-hot.html](https://phys.org/news/2023-11-journey-thermal-antibubbles-hot.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T09:30:03+00:00

Bubbles are thin liquid shells surrounded by air. Although less well known, there are also antibubbles, which are the opposite of bubbles, i.e., a thin envelope of vapor surrounded by liquid. In a new study, we show that it is possible to create antibubbles by impacting a droplet of a volatile liquid on a bath of viscous oil heated to a temperature above the droplet's boiling point.

## Astronomers discover the Milky Way's faintest satellite
 - [https://phys.org/news/2023-11-astronomers-milky-faintest-satellite.html](https://phys.org/news/2023-11-astronomers-milky-faintest-satellite.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T09:29:55+00:00

By analyzing the images from the Ultraviolet Near Infrared Optical Northern Survey (UNIONS), an international team of astronomers has discovered a new compact satellite of the Milky Way, which received designation Ursa Major III/UNIONS 1. The newfound object turns out to be the least luminous known satellite of the Milky Way. The finding is reported in a paper published Nov. 16 on the pre-print server arXiv.

## 5,200 years of migrations from Mexico to California may be the origin of a mystery language
 - [https://phys.org/news/2023-11-years-migrations-mexico-california-mystery.html](https://phys.org/news/2023-11-years-migrations-mexico-california-mystery.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T09:29:25+00:00

Research led by Nathan Nakatsuka of the Department of Genetics at Harvard Medical School, Boston, has found evidence supporting migrations into California from Mexico and the presence of Mexican-related ancestry in Central and Southern California starting around 5,200 years ago.

## The formation of an excitonic Mott insulator state in a moiré superlattice
 - [https://phys.org/news/2023-11-formation-excitonic-mott-insulator-state.html](https://phys.org/news/2023-11-formation-excitonic-mott-insulator-state.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T09:10:01+00:00

When a negatively charged electron and a positively charged hole in a pair remain bound together following excitation by light, they produce states known as excitons. These states can influence the optical properties of materials, in turn enabling their use for developing various technologies.

## NASA feels a 'sense of urgency' to get to Mars: Idaho scientists could help us get there
 - [https://phys.org/news/2023-11-nasa-urgency-mars-idaho-scientists.html](https://phys.org/news/2023-11-nasa-urgency-mars-idaho-scientists.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T07:33:42+00:00

China has repeatedly stunned the U.S. intelligence community in the last five years with rapid progress in its space exploration program, landing a rover on the far side of the moon and completing its very own space station orbiting Earth.

## Critically endangered Sumatran rhino born in Indonesia
 - [https://phys.org/news/2023-11-critically-endangered-sumatran-rhino-born.html](https://phys.org/news/2023-11-critically-endangered-sumatran-rhino-born.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T02:55:30+00:00

A Sumatran rhino has been born in western Indonesia, officials said Monday, a rare sanctuary birth for the critically endangered animal with only several dozen believed to be left in the world.

## Winter isn't coming: climate change hits Greek olive crop
 - [https://phys.org/news/2023-11-winter-isnt-climate-greek-olive.html](https://phys.org/news/2023-11-winter-isnt-climate-greek-olive.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T02:53:21+00:00

Greek organic farmer Zaharoula Vassilaki looks with admiration at a huge olive tree on her property believed to be over two centuries old, still yielding despite a direct lightning hit years ago.

## Experts trash Hong Kong's 'throwaway culture' ahead of plastic ban
 - [https://phys.org/news/2023-11-experts-trash-hong-kong-throwaway.html](https://phys.org/news/2023-11-experts-trash-hong-kong-throwaway.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-11-27T02:52:51+00:00

Unlike her fellow Hong Kong urbanites toting plastic or paper cups filled with coffee, pet groomer Lucine Mo takes her caffeine hit in a thermal mug with a QR code.

