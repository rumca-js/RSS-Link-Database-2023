# Source:InsiderBusiness, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCcyq283he07B7_KUX07mmtA, language:en-US

## At West Point, the kitchen staff serves over 13,000 meals a day to 4,400 #Army cadets. #lunch
 - [https://www.youtube.com/watch?v=BkykvTeBw70](https://www.youtube.com/watch?v=BkykvTeBw70)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCcyq283he07B7_KUX07mmtA
 - date published: 2023-11-27T21:52:25+00:00



## How To Channel An Interest in All Things Tech Into An Investment Portfolio | Bright Ideas
 - [https://www.youtube.com/watch?v=E5oUUm7eEpA](https://www.youtube.com/watch?v=E5oUUm7eEpA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCcyq283he07B7_KUX07mmtA
 - date published: 2023-11-27T19:48:19+00:00

Sponsored by Fidelity

Generative AI was one of the year’s most notable tech disruptions. So, how can big moments in tech show up in an investment portfolio? In this episode of “Bright Ideas,” join host Rod Thill and Fidelity’s Adam Benjamin for a discussion of disruptions like AI – and how investment professionals have likely been tracking them for years.

And you can learn more about linking building a portfolio that leans into disruption at https://www.fidelity.com/mutual-funds/investing-ideas/bright-ideas?immid=100726&amp;imm_pid=370483688&amp;imm_aid=a568132639&amp;dfid=&amp;buf=99999999
------------------------------------------------------
#businessinsider #investing #investmentportfolio 
Business Insider tells you all you need to know about business, finance, tech, retail, and more.

Visit our homepage for the top stories of the day: https://www.businessinsider.com
Insider Business on Facebook: https://www.facebook.com/businessinsider
Insider Business on Instagram: https://ww

## We are running out of places to put all of this #garbage.  #recycling #InsiderBusiness
 - [https://www.youtube.com/watch?v=1pexfofMvzA](https://www.youtube.com/watch?v=1pexfofMvzA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCcyq283he07B7_KUX07mmtA
 - date published: 2023-11-27T19:33:07+00:00



