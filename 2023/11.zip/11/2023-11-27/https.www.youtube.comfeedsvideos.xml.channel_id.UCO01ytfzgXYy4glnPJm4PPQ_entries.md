# Source:Matt Walsh, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ, language:en-US

## Get Out of Your Head
 - [https://www.youtube.com/watch?v=KX92Lm5ab9g](https://www.youtube.com/watch?v=KX92Lm5ab9g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2023-11-27T20:00:07+00:00



