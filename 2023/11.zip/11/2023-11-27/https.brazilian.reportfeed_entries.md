# Source:The Brazilian Report, URL:https://brazilian.report/feed/, language:en-US

## Lula makes a highly political Supreme Court nomination
 - [https://brazilian.report/power/2023/11/27/flavio-dino-nominated-supreme-court](https://brazilian.report/power/2023/11/27/flavio-dino-nominated-supreme-court)
 - RSS feed: https://brazilian.report/feed/
 - date published: 2023-11-27T20:22:14+00:00

<p>The post <a href="https://brazilian.report/power/2023/11/27/flavio-dino-nominated-supreme-court/" rel="nofollow">Lula makes a highly political Supreme Court nomination</a> appeared first on <a href="https://brazilian.report" rel="nofollow">The Brazilian Report</a>.</p>

## Lula’s campaign social media guru exposed by recording
 - [https://brazilian.report/liveblog/politics-insider/2023/11/27/lula-social-media-guru-exposed](https://brazilian.report/liveblog/politics-insider/2023/11/27/lula-social-media-guru-exposed)
 - RSS feed: https://brazilian.report/feed/
 - date published: 2023-11-27T19:39:06+00:00

<p>An audio recording published on Monday by news website Metrópoles shows Congressman André Janones, a savvy social media user who played a key role in President Luiz Inácio Lula da Silva’s 2022 campaign, demanding an aide to surrender part of their salary to pay for his campaign expenses.  “Some people here, who I will talk [&#8230;]</p>
<p>The post <a href="https://brazilian.report/liveblog/politics-insider/2023/11/27/lula-social-media-guru-exposed/" rel="nofollow">Lula&#8217;s campaign social media guru exposed by recording</a> appeared first on <a href="https://brazilian.report" rel="nofollow">The Brazilian Report</a>.</p>

## Deal with creditors provides lifeline to Brazilian retail giant Americanas
 - [https://brazilian.report/business/2023/11/27/retail-giant-americanas-a-lifeline](https://brazilian.report/business/2023/11/27/retail-giant-americanas-a-lifeline)
 - RSS feed: https://brazilian.report/feed/
 - date published: 2023-11-27T17:51:30+00:00

<p>The post <a href="https://brazilian.report/business/2023/11/27/retail-giant-americanas-a-lifeline/" rel="nofollow">Deal with creditors provides lifeline to Brazilian retail giant Americanas</a> appeared first on <a href="https://brazilian.report" rel="nofollow">The Brazilian Report</a>.</p>

## Brazilian producers complain about looser biodiesel import rules
 - [https://brazilian.report/liveblog/politics-insider/2023/11/27/complain-looser-biodiesel-import-rules](https://brazilian.report/liveblog/politics-insider/2023/11/27/complain-looser-biodiesel-import-rules)
 - RSS feed: https://brazilian.report/feed/
 - date published: 2023-11-27T16:13:17+00:00

<p>Brazil’s vegetable oil industry association on Friday criticized a recent decision that will expand the import of biodiesel. The National Oil Agency (ANP) approved a resolution on Thursday allowing the use of imported biodiesel in the mandatory blend with diesel oil of fossil origin. This modifies a 2019 regulation that restricts the sale of imported [&#8230;]</p>
<p>The post <a href="https://brazilian.report/liveblog/politics-insider/2023/11/27/complain-looser-biodiesel-import-rules/" rel="nofollow">Brazilian producers complain about looser biodiesel import rules</a> appeared first on <a href="https://brazilian.report" rel="nofollow">The Brazilian Report</a>.</p>

## Tech Roundup: Brazilian medical cannabis startup opens U.S. office
 - [https://brazilian.report/tech/2023/11/27/tech-roundup-brazilian-cannabis-startup](https://brazilian.report/tech/2023/11/27/tech-roundup-brazilian-cannabis-startup)
 - RSS feed: https://brazilian.report/feed/
 - date published: 2023-11-27T14:16:04+00:00

<p>The post <a href="https://brazilian.report/tech/2023/11/27/tech-roundup-brazilian-cannabis-startup/" rel="nofollow">Tech Roundup: Brazilian medical cannabis startup opens U.S. office</a> appeared first on <a href="https://brazilian.report" rel="nofollow">The Brazilian Report</a>.</p>

