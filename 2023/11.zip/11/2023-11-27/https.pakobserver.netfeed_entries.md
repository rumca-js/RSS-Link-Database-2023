# Source:Pakistan Observer, URL:https://pakobserver.net/feed/, language:en-US

## Pakistan runs short of essential medicines
 - [https://pakobserver.net/pakistan-runs-short-of-essential-medicines](https://pakobserver.net/pakistan-runs-short-of-essential-medicines)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-11-27T16:15:33+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/11/drugs-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />LAHORE &#8211; Various essential and lifesaving drugs are no longer available in the market, putting health and even lives of patients at risk. These essential drugs are not available at the wholesale medicine market and medical stores in Lahore including outlets of all leading chains of pharmacies. Common citizens are the ultimate victims as the [&#8230;]

## Lahore, Punjab weather update; light rain likely
 - [https://pakobserver.net/lahore-punjab-weather-update-light-rain-likely](https://pakobserver.net/lahore-punjab-weather-update-light-rain-likely)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-11-27T15:25:39+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/09/LW-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />&#160; LAHORE &#8211; Pakistan Meteorological Department (PMD) has forecast light rain/drizzle for Lahore and parts of Punjab on Monday night. According to the synoptic situation, a westerly wave is present over the eastern part of Pakistan. Under these conditions, light rain is likely in Lahore, Sialkot and Gujranwala on Monday night. Dry and partly cloudy [&#8230;]

## Shock and outrage as another girl killed in Kohistan over viral dance video
 - [https://pakobserver.net/shock-and-outrage-as-another-girl-killed-in-kohistan-over-viral-dance-video](https://pakobserver.net/shock-and-outrage-as-another-girl-killed-in-kohistan-over-viral-dance-video)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-11-27T15:15:22+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/11/kill-21-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />MANSEHRA &#8211; As rights groups continue to protest against killing of women and children in Pakistan, another heinous crime is sanctioned by local Jirga in Kohistan. The incident of killing of 5 girls that occurred a decade back in Kohistan, resurfaced as a young girl has been gunned down on the orders of tribal chiefs, [&#8230;]

## Honda CG 125 224, CG 125s Gold edition price in Pakistan latest update
 - [https://pakobserver.net/honda-cg-125-224-cg-125s-gold-edition-price-in-pakistan-latest-update](https://pakobserver.net/honda-cg-125-224-cg-125s-gold-edition-price-in-pakistan-latest-update)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-11-27T14:42:57+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/11/maxresdefault-1-1-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Honda bikes continue to rule Pakistani streets, with its powerful bikes Honda 125, and Honda 125 Gold edition remained the most famous units of the company. The company claimed issuing new top-selling units comes with dozens of improvements in the Honda CG 125 2024 model but seemingly, the latest edition comes with a mere sticker, [&#8230;]

## Islamabad, Rawalpindi weather update; rains likely during this week
 - [https://pakobserver.net/islamabad-rawalpindi-weather-update-rains-likely-during-this-week](https://pakobserver.net/islamabad-rawalpindi-weather-update-rains-likely-during-this-week)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-11-27T13:59:21+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/10/ISDW-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />ISLAMABAD &#8211; Pakistan Meteorological Department (PMD) has forecast mainly cold and cloudy weather for Islamabad, Rawalpindi and parts of Pakistan on Monday night and the next days. Rainfall of varying intensities are likely in the twin cities on Wednesday and Thursday. According to the synoptic situation, a westerly wave is present over the eastern part [&#8230;]

## Lahore remains most polluted city in world
 - [https://pakobserver.net/lahore-remains-most-polluted-city-in-world](https://pakobserver.net/lahore-remains-most-polluted-city-in-world)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-11-27T13:25:00+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/11/fog-1-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />LAHORE &#8211; Lahore continued to lead the list of the most polluted cities of the world with Air Quality Index reaching hazardous level on Monday evening. At 5;40 pm, AQI of Lahore was recorded 305, the highest in the world. India capital Delhi remained on the second spot with AQI 270 followed by Karachi where [&#8230;]

## Lahore man attempting to take driving test for friend lands in jail
 - [https://pakobserver.net/lahore-man-attempting-to-take-driving-test-for-friend-lands-in-jail](https://pakobserver.net/lahore-man-attempting-to-take-driving-test-for-friend-lands-in-jail)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-11-27T13:07:49+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/11/1685707148-7888-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />LAHORE – A Lahore resident who attempted to take the driving test for a friend was nabbed and facing jail time in Lahore. In a social media post, Lahore Traffic Police shared an update, saying two men identified as Farrukh Ejaz and his friend Usman were held and a case has been registered against them [&#8230;]

## UHS grants affiliation to 10 nursing colleges in Punjab
 - [https://pakobserver.net/uhs-grants-affiliation-to-10-nursing-colleges-in-punjab](https://pakobserver.net/uhs-grants-affiliation-to-10-nursing-colleges-in-punjab)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-11-27T12:32:34+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/11/UHS-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />LAHORE &#8211; The University of Health Sciences (UHS) on Monday sanctioned the appointment of 29 faculty members and granted affiliation to 10 nursing colleges in Punjab. The UHS Syndicate, endorsing the Selection Board&#8217;s recommendations, approved the appointment of one professor and one assistant professor for hematology, two associate professors for physiology, and one assistant professor [&#8230;]

## Pakistani rupee loses more value to US dollar in inter-bank; check latest rates here
 - [https://pakobserver.net/pakistani-rupee-loses-more-value-to-us-dollar-in-inter-bank-check-latest-rates-here](https://pakobserver.net/pakistani-rupee-loses-more-value-to-us-dollar-in-inter-bank-check-latest-rates-here)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-11-27T12:05:47+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/11/today-s-currency-exchange-rates-in-pakistan-dollar-euro-pound-riyal-rates-on-march-20-2023-1679289825-7922-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />KARACHI &#8211; Pakistani rupee rebounded from an all-time low this year but it remained under pressure against the dollar as the pressure of import payments advanced. Data shared by the State Bank suggests that the local currency moved down for the third successive session against the greenback in the inter-bank market. US dollar rate in [&#8230;]

## Shehzad Akbar suffers injuries in acid attack in London
 - [https://pakobserver.net/shehzad-akbar-suffers-injuries-in-acid-attack-in-london](https://pakobserver.net/shehzad-akbar-suffers-injuries-in-acid-attack-in-london)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-11-27T11:26:36+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/11/FFFF-2-900x450-1-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />LONDON &#8211; Mirza Shahzad Akbar, the infamous barrister who served as PM’s aide to Interior and Accountability, claimed that he left with injuries after an acid attack in London. The close aide of Imran Khan, who is currently in exile in Britain with his family, shared an update about an assault at his residence involving [&#8230;]

## Banks starts receiving applicants for Hajj 2024 today (Check cost details)
 - [https://pakobserver.net/banks-starts-receiving-applicants-for-hajj-2024-today-check-cost-details](https://pakobserver.net/banks-starts-receiving-applicants-for-hajj-2024-today-check-cost-details)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-11-27T09:05:58+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2021/05/hajj-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />LAHORE – Designated banks will start receiving applications for the next year&#8217;s Hajj under government scheme from today (November 27). Aspokesperson of Ministry of Religious Affairs in a statement said that the process will continue till December 12. The applications can be submitted on a passport valid till 16 December 2024. Hajj application can also [&#8230;]

## Pakistani forces kill eight terrorists in South Waziristan gunfight
 - [https://pakobserver.net/pakistani-forces-kill-eight-terrorists-in-south-waziristan-gunfight](https://pakobserver.net/pakistani-forces-kill-eight-terrorists-in-south-waziristan-gunfight)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-11-27T09:03:40+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/11/sy-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />RAWALPINDI – Security forces killed eight terrorists during an intensive exchange of fire in Sararogha area of South Waziristan District on Sunday. The Inter Services Public Relations (ISPR) in a statement said the security forces conducted an Intelligence Based Operation in the area on reported presence of terrorists. The killed terrorists remained actively involved in [&#8230;]

## Is Pakistan on the list? China announces visa-free entry for more countries
 - [https://pakobserver.net/is-pakistan-on-the-list-china-announces-visa-free-entry-for-more-countries](https://pakobserver.net/is-pakistan-on-the-list-china-announces-visa-free-entry-for-more-countries)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-11-27T09:01:31+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/11/free-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />BEIJING – China has announced visa-free travel for citizens of various countries on a trial-basis, starting from December 1, 2023. The announcement was made by a spokesperson of the Chinese Ministry of Foreign Affairs last week during a routine press briefing. He said the service has been launched in order “to further facilitate cross-border travel [&#8230;]

## Currency exchange rates in Pakistan today – November 27, 2023
 - [https://pakobserver.net/currency-exchange-rates-in-pakistan-today-november-27-2023](https://pakobserver.net/currency-exchange-rates-in-pakistan-today-november-27-2023)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-11-27T04:25:57+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/11/curreny-rate-today-15-1-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />KARACHI – The exchange rate for one US Dollar against Pakistani Rupees was recorded at Rs 284.7 in the local and open market, with a selling rate of Rs 285.2 on Monday, November 27, 2023. Note: Exchange rates can vary based on the location and the Exchange Company or bank involved in the transaction. Below are [&#8230;]

## Gold rate in Pakistan today – 27 November, 2023
 - [https://pakobserver.net/gold-rate-in-pakistan-today-27-november-2023](https://pakobserver.net/gold-rate-in-pakistan-today-27-november-2023)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-11-27T04:20:27+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/11/gold-rate-in-pakistan-today-24-March-2023-1-1024x576-4-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />KARACHI – The gold rate of 24-karat is being traded at PKR 216,600 on Monday, November 27, 2023. Similarly, the gold price for 24-karat was recorded at Rs 185,700 per 10g as per the bullion market. Gold Price in Pakistan’s different cities. City Gold Silver Karachi PKR 216,600 PKR 2,450 Lahore PKR 216,600 PKR 2,450 [&#8230;]

## Killing reported in Gaza refugee camp on third day of truce
 - [https://pakobserver.net/killing-reported-in-gaza-refugee-camp-on-third-day-of-truce](https://pakobserver.net/killing-reported-in-gaza-refugee-camp-on-third-day-of-truce)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-11-27T00:47:20+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/11/AP23298238147171-1698216454-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Gaza/Jerusalem A Palestinian farmer was killed and another injured on Sunday after they were targeted by Israeli forces in the Maghazi refugee camp in the center of Gaza, the Palestinan Red Crescent said as a truce between Israel and Hamas fighters entered a third day. There was no immediate comment from Israel on the report [&#8230;]

## Saudi FM, Colombian counterpart discuss situation in Gaza
 - [https://pakobserver.net/saudi-fm-colombian-counterpart-discuss-situation-in-gaza](https://pakobserver.net/saudi-fm-colombian-counterpart-discuss-situation-in-gaza)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-11-27T00:44:19+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/11/Untitled-1-2-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Saudi Foreign Minister Prince Faisal bin Farhan and his Colombian counterpart Alvaro Leyva Duran discussed the latest development in Gaza, the Saudi foreign ministry said. The two sides discussed developments in the situation in the Palestinian enclave and its surroundings, and the harm to unarmed civilians, in addition to discussing the importance of the international [&#8230;]

## PML-N’s narrative ahead of general elections
 - [https://pakobserver.net/pml-ns-narrative-ahead-of-general-elections](https://pakobserver.net/pml-ns-narrative-ahead-of-general-elections)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-11-27T00:44:10+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/08/Nawaz-1-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Fida Hussnain After visiting Lahore Chamber of Commerce and Industry (LCCI) few days ago, Pakistan Muslim League-Nawaz (PML-N) Supremo and former three-time Prime Minister Nawaz Sharif reached Sialkot to have an interaction with the traders and to deliver a speech at Sialkot Chamber of Commerce and Industry (SCCI) on Saturday. The traders’ community of both [&#8230;]

## NAB grilled PTI chief over 2 hours
 - [https://pakobserver.net/nab-grilled-pti-chief-over-2-hours](https://pakobserver.net/nab-grilled-pti-chief-over-2-hours)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-11-27T00:43:06+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/03/imran-khan-1-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />A National Accountability Bureau (NAB) team grilled former prime minister and Pakistan Tehreek-e-Insaf (PTI) Chairman, Imran Khan in £190m settlement case. The team led by Assistant Director Mohsin Ali Khan interrogated the PTI chairman in Adiala Jail for two and half hours. The team is quizzing, the former prime minister in the £190m case from [&#8230;]

## ECP to hear Imran’s case tomorrow
 - [https://pakobserver.net/ecp-to-hear-imrans-case-tomorrow](https://pakobserver.net/ecp-to-hear-imrans-case-tomorrow)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-11-27T00:42:09+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/03/ecp-1-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Yet another test for the cornered Pakistan Tehreek-i-Insaf (PTI), which is already grappling with so many issues, as the Election Commission of Pakistan (ECP) will take up the case of stripping PTI Chairman Imran Khan off his party chairmanship on Tuesday (November 28). A five-member bench, headed by Chief Election Commissioner (CEC) Sikandar Sultan Raja, [&#8230;]

## PM in UAE on two-day visit
 - [https://pakobserver.net/pm-in-uae-on-two-day-visit](https://pakobserver.net/pm-in-uae-on-two-day-visit)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-11-27T00:41:13+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/11/1-22-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Caretaker Prime Minister Anwaar-ul-Haq Kakar on Sunday arrived here on a two-day visit to the United Arab Emirates (UAE). Minister for Justice of the UAE Abdullah Sultan bin Awad Al Nuaimi  and Pakistani diplomatic staff received the prime minister on his arrival at the Abu Dhabi’s Al- Bateen Airport, a Prime Minister Office Press Release [&#8230;]

## Zardari forms committee to foster political dialogue
 - [https://pakobserver.net/zardari-forms-committee-to-foster-political-dialogue](https://pakobserver.net/zardari-forms-committee-to-foster-political-dialogue)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-11-27T00:36:45+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/09/asif-zardari-to-camp-in-lahore-for-general-elections-strategy-1694515688-9839-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />The Pakistan Peoples Party Parliamentarians (PPPP) has decided to contact political parties and personalities for a political dialogue before and after the upcoming general elections. PPPP President Asif Ali Zardari formed the committee to make political contact and initiate political dialogue with the political parties and personalities for the upcoming general elections. According to a [&#8230;]

## IPP vows to give ‘electric shock’ to rich, relief to poor
 - [https://pakobserver.net/ipp-vows-to-give-electric-shock-to-rich-relief-to-poor](https://pakobserver.net/ipp-vows-to-give-electric-shock-to-rich-relief-to-poor)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-11-27T00:36:43+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/11/2-16-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Istehkam-e-Pakistan Party (IPP) President Abdul Aleem Khan on Sunday vowed to provide free electricity to the poor while the power utility would be available for the rich at double rates if his party is voted to power in the upcoming general elections. Addressing a public rally in Punjab’s Kamoke on Sunday, Aleem Khan said: “The [&#8230;]

## Committee on missing persons in the works, says HRs minister
 - [https://pakobserver.net/committee-on-missing-persons-in-the-works-says-hrs-minister](https://pakobserver.net/committee-on-missing-persons-in-the-works-says-hrs-minister)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-11-27T00:27:07+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/11/Khalil-George-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Caretaker Human Rights Minister Khalil George has said that a committee on the issue of missing persons is in the works, adding that government was “thoroughly” looking into the matter. The human rights minister made the remarks in an interview with a private TV channel on Sunday night. Earlier, the Islamabad High Court (IHC) had [&#8230;]

## World’s largest iceberg breaks free, heads toward Southern Ocean
 - [https://pakobserver.net/worlds-largest-iceberg-breaks-free-heads-toward-southern-ocean](https://pakobserver.net/worlds-largest-iceberg-breaks-free-heads-toward-southern-ocean)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-11-27T00:26:43+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/11/2-15-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />The world’s largest iceberg is on the move for the first time in more than three decades, scientists said on Friday. At almost 4,000 square km (1,500 square miles), the Antarctic iceberg called A23a is roughly three times the size of New York City. Since calving off West Antarctica’s Filchner-Ronne Ice Shelf in 1986, the [&#8230;]

