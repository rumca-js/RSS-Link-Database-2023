# Source:Eurogamer.net Latest Articles Feed, URL:https://www.eurogamer.net/feed, language:en-gb

## Destiny 2: The Final Shape delay announced by Bungie
 - [https://www.eurogamer.net/destiny-2-the-final-shape-delay-announced-by-bungie](https://www.eurogamer.net/destiny-2-the-final-shape-delay-announced-by-bungie)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2023-11-27T17:31:01+00:00

<img src="https://assetsio.reedpopcdn.com/WRP_Standard_Key_Art_Final-4K_Logo_Date_Locs_EN-(1).jpg?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>
Bungie will now launch its climactic Destiny 2 expansion The Final Shape on 4th June 2024.
</p><p>
The four-month delay was <a href="https://www.eurogamer.net/bungie-reportedly-delays-destiny-2s-final-shape-expansion-and-marathon">previously leaked</a> following <a href="https://www.eurogamer.net/destiny-2-developer-bungie-latest-playstation-studio-to-be-hit-by-layoffs">news of job cuts at the studio</a>, and a sense that the game's big finale expansion needed more time. Bungie's other announced game project Marathon has also reportedly been delayed - and will now launch in 2025.
</p><p>
In a <a href="https://www.bungie.net/7/en/News/article/final_shape_release_update">blog post</a> today, Bungie confirmed that The Final Shape did indeed need longer "to become exactly what we want it to be". 
</

## Editor's blog: Eurogamer owner seeking buyer
 - [https://www.eurogamer.net/editors-blog-eurogamer-owner-seeking-buyer](https://www.eurogamer.net/editors-blog-eurogamer-owner-seeking-buyer)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2023-11-27T15:59:48+00:00

<img src="https://assetsio.reedpopcdn.com/eurogamer-launches-paid-work-experience-programme-for-ethnic-minorities-1616072986126_s0oGqLZ.jpg?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>
Hey everyone, I wanted to share a quick update about Eurogamer, and its future which now looks to lie outside the Reedpop business.
</p><p>
If you've been reading for a while you may know Eurogamer has been around a few years (24!) and spent most of that time as part of the family-run Gamer Network. 
</p><p>
Five years ago, Gamer Network was bought by Reedpop, the pop culture-focused arm of events company Reed Exhibitions, which already ran PAX and New York Comic-Con. 
</p> <p><a href="https://www.eurogamer.net/editors-blog-eurogamer-owner-seeking-buyer">Read more</a></p>

## NCSoft shows new trailers for Project M and LLL
 - [https://www.eurogamer.net/ncsoft-shows-new-trailers-for-project-m-and-lll](https://www.eurogamer.net/ncsoft-shows-new-trailers-for-project-m-and-lll)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2023-11-27T15:32:47+00:00

<img src="https://assetsio.reedpopcdn.com/ncsoft-lll-gstar-trailer.png?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>NCSoft unveiled new trailers for its upcoming games Project M and LLL at G-Star 2023 which show off new features.
</p><p>Project M is a narrative thriller which we first saw in June 2022 with a trailer filled with <a href="https://www.eurogamer.net/stunning-korean-heavy-rain-like-thriller-is-next-game-from-ncsoft">quicktime events</a> reminiscent of Heavy Rain and Detroit: Become Human. The game looks packed with drama, family, violence, and the supernatural. LLL was announced a few months later in November 2022 and is a <a href="https://www.eurogamer.net/ncsoft-announces-new-sci-fi-shooter-mmo">sci-fi MMO</a> set in an alternate history which caused modern-day Seoul, the Byzantine Empire and the 23rd century to become entangled with one another.</p><p>The trailer for Project M gives us a look at a new environment, a brigh

## Marvel Snap publisher's parent company confirms restructuring, stepping away from video games
 - [https://www.eurogamer.net/marvel-snap-publishers-parent-company-confirms-restructuring-stepping-away-from-video-games](https://www.eurogamer.net/marvel-snap-publishers-parent-company-confirms-restructuring-stepping-away-from-video-games)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2023-11-27T15:30:28+00:00

<img src="https://assetsio.reedpopcdn.com/MarvelSnap_2023_S18_KA_V08.png?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>Chinese internet technology firm ByteDance is restructuring the video games side of its business.
</p><p>The company, the parent of Marvel Snap publisher Nuverse, called this a "difficult" decision to make. 
</p><p>"We regularly review our businesses and make adjustments to centre on long-term strategic growth areas," a spokesman for the ByteDance said in a statement shared with <a href="https://www.reuters.com/technology/bytedance-wind-down-gaming-brand-nuverse-full-retreat-gaming-sources-2023-11-27/">Reuters</a>. "Following a recent review, we've made the difficult decision to restructure our gaming business."</p> <p><a href="https://www.eurogamer.net/marvel-snap-publishers-parent-company-confirms-restructuring-stepping-away-from-video-games">Read more</a></p>

## Them's Fightin' Herds accused of breaking promises as it ceases development of Story Mode
 - [https://www.eurogamer.net/thems-fightin-herds-accused-of-breaking-promises-as-it-ceases-development-of-story-mode](https://www.eurogamer.net/thems-fightin-herds-accused-of-breaking-promises-as-it-ceases-development-of-story-mode)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2023-11-27T13:25:27+00:00

<img src="https://assetsio.reedpopcdn.com/ss_7497ac66fd72333de92e9dee5eae74d5169c480b.jpg?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>
Developer Mane6 is ceasing active development on Them's Fightin' Herds, meaning there will be no new content once the game's Season Pass 1 is finished. 
</p><p>
This includes its Story Mode, a feature which was promised as part of Them's Fightin' Herds' initial Indiegogo campaign. 
</p><p>
The studio slipped this news in rather casually towards the end of a <a href="https://store.steampowered.com/news/app/574980/view/3882727783056476087">recent blog update</a> about the game, where it detailed its upcoming DLC characters.
</p> <p><a href="https://www.eurogamer.net/thems-fightin-herds-accused-of-breaking-promises-as-it-ceases-development-of-story-mode">Read more</a></p>

## New Tribes game seen in first gameplay footage
 - [https://www.eurogamer.net/new-tribes-game-seen-in-first-gameplay-footage](https://www.eurogamer.net/new-tribes-game-seen-in-first-gameplay-footage)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2023-11-27T11:55:10+00:00

<img src="https://assetsio.reedpopcdn.com/tribes-3-playtest-screenshot.jpg?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>Videos of gameplay from a new Tribes entry have been shared online ahead of a public playtest later this week.
</p><p>The most recent release in the series was Tribes: Ascend in 2012, which was developed and published by Hi-Rez Studios.</p><p>Tribes 3: Rivals is in development by <a href="https://www.prophecygames.com/">Prophecy Games</a>, an independent studio which was founded in 2019 within Hi-Rez Studios.</p> <p><a href="https://www.eurogamer.net/new-tribes-game-seen-in-first-gameplay-footage">Read more</a></p>

## Amazon's Tomb Raider project adds WandaVision writer to its team
 - [https://www.eurogamer.net/amazons-tomb-raider-project-adds-wandavision-writer-to-its-team](https://www.eurogamer.net/amazons-tomb-raider-project-adds-wandavision-writer-to-its-team)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2023-11-27T11:51:35+00:00

<img src="https://assetsio.reedpopcdn.com/ss_3b46aa127290e6ad2f62c125096bf5e901458ad6.jpg?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>
Writer Megan McDonnell, who has worked on Marvel projects WandaVision and The Marvels, has joined the team working on Amazon's Tomb Raider adaptation. 
</p><p>
In a recent report by <a href="https://variety.com/lists/variety-10-screenwriters-to-watch-2023/">Variety</a>, the outlet confirmed McDonnell's inclusion in the series. 
</p><p>
When discussing her wider portfolio, McDonnell said she often takes inspiration from her own experiences when writing characters. "Most of my stories start with whatever funk or crisis or feeling I'm living in, then I figure out how to explore that through speculative fiction," McDonnell shared.
</p> <p><a href="https://www.eurogamer.net/amazons-tomb-raider-project-adds-wandavision-writer-to-its-team">Read more</a></p>

## Bloober Team asks fans for patience on Silent Hill 2 Remake, says things are "progressing smoothly"
 - [https://www.eurogamer.net/bloober-team-asks-fans-for-patience-on-silent-hill-2-remake-says-things-are-progressing-smoothly](https://www.eurogamer.net/bloober-team-asks-fans-for-patience-on-silent-hill-2-remake-says-things-are-progressing-smoothly)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2023-11-27T11:27:02+00:00

<img src="https://assetsio.reedpopcdn.com/ss_ff0541de92268dec576e3672a013b958de1b0158.jpg?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>

The Silent Hill 2 remake is "progressing smoothly", developer Bloober Team has assured fans.
</p><p>
Last night, Bloober Team released a statement on X (formerly Twitter) saying it "would like to clarify" that work on the upcoming remake is continuing on "in accordance with [its] schedule". 
</p><p>
"As Bloober Team, we are proud to be a part of Konami's plans for the Silent Hill franchise," it wrote. "Alongside our partner, we are diligently working to ensure the Silent Hill 2 remake attains the highest quality."
</p> <p><a href="https://www.eurogamer.net/bloober-team-asks-fans-for-patience-on-silent-hill-2-remake-says-things-are-progressing-smoothly">Read more</a></p>

## Uncovering the eldritch horror monster-collecting RPG Book of Abominations
 - [https://www.eurogamer.net/uncovering-the-eldritch-horror-monster-collecting-rpg-book-of-abominations](https://www.eurogamer.net/uncovering-the-eldritch-horror-monster-collecting-rpg-book-of-abominations)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2023-11-27T10:00:00+00:00

<img src="https://assetsio.reedpopcdn.com/BOA-title-screen.png?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>I was so taken with one game at EGX 2023 that I returned to play it every day I was there. It's called Book of Abominations and it's a bit like Pok&eacute;mon - if Pok&eacute;mon existed in a Lovecraftian nightmare.</p><p>Essentially, Book of Abominations is a monster-collecting RPG where you accidentally release monsters into the universe after finding a big, suspiciously evil book. And because it was your fault, it's now your job to find all of these monsters and return them. Most of them are semi-willing to go back inside but some big ones you will need to fight first. Luckily, though, as you capture more monsters, you'll be able to build bigger and better teams to deal with them.</p><p>Combat is turn-based and you can get your allied monsters to chip away at the enemy's health until, once you&rsquo;re confident you can win, yo

