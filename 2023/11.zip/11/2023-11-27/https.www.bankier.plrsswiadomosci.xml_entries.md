# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Tydzień na Wall Street zaczął się od niewielkich spadków
 - [https://www.bankier.pl/wiadomosc/Tydzien-na-Wall-Street-zaczal-sie-od-niewielkich-spadkow-8653748.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tydzien-na-Wall-Street-zaczal-sie-od-niewielkich-spadkow-8653748.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T21:08:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/a/d29d93a7d5f16e-948-568-150-179-2850-1709.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Poniedziałkowa sesja na Wall Street zakończyła się niewielkimi spadkami głównych indeksów. Inwestorzy analizują najnowsze dane makro i ich wpływ na politykę monetarną Fed.</p>

## Morawiecki: Proponujemy trzy bardzo dobre ustawy; rząd będzie bardzo intensywnie pracował w najbliższych dwóch tygodniach
 - [https://www.bankier.pl/wiadomosc/Morawiecki-Proponujemy-trzy-bardzo-dobre-ustawy-rzad-bedzie-bardzo-intensywnie-pracowal-w-najblizszych-dwoch-tygodniach-8653705.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Morawiecki-Proponujemy-trzy-bardzo-dobre-ustawy-rzad-bedzie-bardzo-intensywnie-pracowal-w-najblizszych-dwoch-tygodniach-8653705.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T19:31:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/9/c30fdf65da0096-948-568-0-0-1955-1173.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Proponujemy trzy bardzo dobre ustawy: wakacje kredytowe, zerowy VAT na żywność i zamrożenie rachunków na energię elektryczną; będzie gotowych kilka kolejnych ustaw, ponieważ rząd będzie bardzo intensywnie pracował w najbliższych dwóch tygodniach - powiedział w poniedziałek wieczorem premier Mateusz Morawiecki.</p>

## Spiker Izby Reprezentantów: Kongres USA uchwali nowy pakiet środków dla Ukrainy przed Bożym Narodzeniem
 - [https://www.bankier.pl/wiadomosc/Spiker-Izby-Reprezentantow-Kongres-USA-uchwali-nowy-pakiet-srodkow-dla-Ukrainy-przed-Bozym-Narodzeniem-8653704.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Spiker-Izby-Reprezentantow-Kongres-USA-uchwali-nowy-pakiet-srodkow-dla-Ukrainy-przed-Bozym-Narodzeniem-8653704.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T19:25:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/0/578943080693c3-948-568-460-720-3250-1950.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Spiker amerykańskiej Izby Reprezentantów Mike Johnson wyraził w poniedziałek "optymizm i pewność", że Kongres będzie w stanie uchwalić dodatkowe środki na pomoc Ukrainie i Izraelowi przed świąteczną przerwą. Dodał jednak, że w pakiecie muszą znaleźć się też zmiany w polityce imigracyjnej.</p>

## Rafał Brzoska nabył 187 218 akcji InPostu po średniej cenie 10,40 euro za akcję
 - [https://www.bankier.pl/wiadomosc/Rafal-Brzoska-nabyl-187-218-akcji-InPostu-po-sredniej-cenie-10-40-euro-za-akcje-8653692.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rafal-Brzoska-nabyl-187-218-akcji-InPostu-po-sredniej-cenie-10-40-euro-za-akcje-8653692.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T19:04:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/8/8bb17104216222-948-568-0-80-3583-2149.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rafał Brzoska, założyciel i prezes InPostu, nabył 187 218 akcji InPostu po średniej cenie 10,40 euro za akcję - poinformowała spółka w komunikacie. </p>

## PiS wprowadza zmiany i się odmładza - we władzach politycy młodszego pokolenia
 - [https://www.bankier.pl/wiadomosc/PiS-wprowadza-zmiany-i-sie-odmladza-we-wladzach-politycy-mlodszego-pokolenia-8653672.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PiS-wprowadza-zmiany-i-sie-odmladza-we-wladzach-politycy-mlodszego-pokolenia-8653672.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T18:20:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/e/22d339cb83e02c-948-568-0-270-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />PiS ma 17 nowych szefów okręgów, które odpowiadają terytorialnie województwom, w tym oddzielnie dla Warszawy, a nie, jak dotychczas 94 – zdecydowało kierownictwo partii. Szefami struktur – jak dowiedziała się PAP - zostali w dużej mierze politycy młodszego pokolenia.</p>

## WIG20 najniżej od dwóch tygodni. Agresywna gra na spadki kursu JSW
 - [https://www.bankier.pl/wiadomosc/WIG20-najnizej-od-dwoch-tygodni-Agresywna-gra-na-spadki-kursu-JSW-8653620.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/WIG20-najnizej-od-dwoch-tygodni-Agresywna-gra-na-spadki-kursu-JSW-8653620.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T16:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/c/ab4817a9275b1c-948-568-0-52-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Na GPW w poniedziałek dominowały spadki, wpisujące się w cofniecie
na rynkach bazowych. WIG20 znalazł się na zamknięciu najniżej od dwóch
tygodniu. Notowaniom indeksów największych spółek oraz szerokiego rynku ciążyły
akcje banków. Po przeciwnej stronie był natomiast sektor energetyczny.</p>

## Zawieszenie broni między Izraelem a Hamasem zostało przedłużone
 - [https://www.bankier.pl/wiadomosc/Zawieszenie-broni-miedzy-Izraelem-a-Hamasem-zostalo-przedluzone-8653625.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zawieszenie-broni-miedzy-Izraelem-a-Hamasem-zostalo-przedluzone-8653625.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T16:47:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/0/f571cd0b51de0f-948-568-0-180-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ministerstwo spraw zagranicznych Kataru poinformowało w poniedziałek po południu, że zawieszenie broni między Izraelem a Hamasem zostało przedłużone o dwa dni. Katar wraz z Egiptem i USA pełni rolę mediatorów w negocjacjach pokojowych.</p>

## Murapol w drodze na GPW. KNF zatwierdziła prospekt spółki; ustalono cenę maksymalną akcji w IPO
 - [https://www.bankier.pl/wiadomosc/Murapol-w-drodze-na-GPW-KNF-zatwierdzila-prospekt-spolki-ustalono-cene-maksymalna-akcji-w-IPO-8653622.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Murapol-w-drodze-na-GPW-KNF-zatwierdzila-prospekt-spolki-ustalono-cene-maksymalna-akcji-w-IPO-8653622.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T16:38:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/1/8a028b8c5b4be3-948-568-46-126-4561-2737.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Komisja Nadzoru Finansowego zatwierdziła prospekt Murapolu sporządzony w związku z ofertą publiczną akcji serii C1 oraz zamiarem ubiegania się o dopuszczenie do obrotu na rynku regulowanym akcji serii A1, A2, B, C1, C2 i D - poinformowała KNF w komunikacie.</p>

## Black Weeks w PGG, czyli tańszy węgiel. Polacy chętnie korzystają z obniżki ceny
 - [https://www.bankier.pl/wiadomosc/Black-Weeks-w-PGG-czyli-tanszy-wegiel-Polacy-chetnie-korzystaja-z-obnizki-ceny-8653585.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Black-Weeks-w-PGG-czyli-tanszy-wegiel-Polacy-chetnie-korzystaja-z-obnizki-ceny-8653585.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T16:01:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/0/93988dac8f3e56-948-568-0-67-1698-1019.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Czasowa obniżka ceny węgla opałowego o 200 zł na tonie przyniosła niemal dziesięciokrotny wzrost sprzedaży w sklepie internetowym Polskiej Grupy Górniczej (PGG) - poinformowała w poniedziałek spółka, która po raz pierwszy przygotowała dla nabywców paliwa ofertę pod hasłem Black Weeks.</p>

## Koniec z zakazem handlu w niedzielę? "Koalicja złoży całościowy projekt"
 - [https://www.bankier.pl/wiadomosc/Koniec-z-zakazem-handlu-w-niedziele-Koalicja-zlozy-calosciowy-projekt-8653579.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Koniec-z-zakazem-handlu-w-niedziele-Koalicja-zlozy-calosciowy-projekt-8653579.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T15:56:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/4/0677e42ed8a588-948-568-43-0-3456-2073.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przewodniczący sejmowej Komisji Gospodarki i Rozwoju Ryszard Petru zadeklarował w imieniu koalicji KO-TD-Lewica, w trakcie poniedziałkowego posiedzenia komisji, że po ustaleniach między koalicjantami zostanie złożony całościowy projekt regulujący handel w niedzielę.</p>

## Czeskie związki zawodowe zorganizowały jeden z największych strajków w historii
 - [https://www.bankier.pl/wiadomosc/Czeskie-zwiazki-zawodowe-zorganizowaly-jeden-z-najwiekszych-strajkow-w-historii-8653577.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Czeskie-zwiazki-zawodowe-zorganizowaly-jeden-z-najwiekszych-strajkow-w-historii-8653577.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T15:53:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/b/e14abfc4036a6b-948-568-0-180-3970-2381.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Czeskie związki zawodowe przeprowadziły w poniedziałek dwugodzinny strajk, który był jednym z największych takich protestów w historii. Protestowano przeciwko polityce centroprawicowego rządu, między innymi przeciwko pakietowi oszczędnościowemu. Osobny, całodzienny strajk zorganizowali związkowcy działający w edukacji.</p>

## Jednak nie ma tajnego planu Niemiec i USA dla Ukrainy? Departament Stanu odpowiada na doniesienia medialne
 - [https://www.bankier.pl/wiadomosc/Jednak-nie-ma-tajnego-planu-Niemiec-i-USA-dla-Ukrainy-Departament-Stanu-odpowiada-na-doniesienia-medialne-8653564.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Jednak-nie-ma-tajnego-planu-Niemiec-i-USA-dla-Ukrainy-Departament-Stanu-odpowiada-na-doniesienia-medialne-8653564.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T15:36:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/3/7c7381dac77a26-948-568-0-148-1459-875.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nie prowadzimy polityki zmuszania Ukrainy do podjęcia negocjacji z Rosją, zaś Putin chce przeczekać jeszcze co najmniej rok, by rozważyć zakończenie wojny - powiedział w poniedziałek asystent sekretarza stanu ds. europejskich i eurazjatyckich James O'Brien, odpowiadając na pytanie PAP o doniesienia "Bilda" o rzekomym planie Waszyngtonu i Berlina, by popchnąć Kijów do rozmów z Putinem.</p>

## Prokuratura umorzyła dochodzenia ws. prezesa PiS Jarosława Kaczyńskiego
 - [https://www.bankier.pl/wiadomosc/Prokuratura-umorzyla-dochodzenia-ws-prezesa-PiS-Jaroslawa-Kaczynskiego-8653554.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Prokuratura-umorzyla-dochodzenia-ws-prezesa-PiS-Jaroslawa-Kaczynskiego-8653554.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T15:29:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/8/4023474e6bd3f3-948-568-0-57-1920-1151.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prokuratura podęła decyzję o umorzeniu dochodzeń w sprawie zajść podczas obchodów miesięcznicy katastrofy smoleńskiej - wynika z informacji przekazanych przez rzecznika Prokuratury Okręgowej w Warszawie Szymona Bannę. Chodzi o złożone przez demonstrantów zawiadomienia dotyczące prezesa PiS J. Kaczyńskiego.</p>

## Elon Musk poparł walkę Izraela z Hamasem i zapowiedział położenie kresu propagandzie
 - [https://www.bankier.pl/wiadomosc/Elon-Musk-poparl-walke-Izraela-z-Hamasem-i-zapowiedzial-polozenie-kresu-propagandzie-8653541.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Elon-Musk-poparl-walke-Izraela-z-Hamasem-i-zapowiedzial-polozenie-kresu-propagandzie-8653541.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T15:12:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/8/712771a71160e7-948-568-0-44-1280-767.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Właściciel platformy X Elon Musk odwiedził w poniedziałek Izrael i spotkał się z premierem Benjaminem Netanjahu. Miliarder wyraził poparcie dla walki Izraela z Hamasem i zapowiedział położenie kresu propagandzie, która prowadzi do morderstw - relacjonuje agencja Reutera.</p>

## Premier Morawiecki powołał rząd. Stery przejmie nowa gwardia. "Ponad połowę będą stanowiły kobiety"
 - [https://www.bankier.pl/wiadomosc/Nowy-rzad-premiera-Mateusza-Morawieckiego-8653351.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nowy-rzad-premiera-Mateusza-Morawieckiego-8653351.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T14:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/e/fde15eb63de3e1-948-568-0-19-3808-2284.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Mateusz Morawiecki powołał nowy rząd. W poniedziałek popołudniu odbyło 
się zaprzysiężenie ministrów. Teraz premier ma dwa tygodnie na uzyskanie
 większości w Sejmie.</p>

## Data wyroku TSUE ws. kredytów we frankach dot. przedawniania roszczeń i terminu liczenia odsetek
 - [https://www.bankier.pl/wiadomosc/Data-wyroku-TSUE-ws-kredytow-we-frankach-dot-przedawniania-roszczen-i-terminu-liczenia-odsetek-8653495.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Data-wyroku-TSUE-ws-kredytow-we-frankach-dot-przedawniania-roszczen-i-terminu-liczenia-odsetek-8653495.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T14:34:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/d/854e83e36b4596-948-568-20-77-979-587.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Trybunał Sprawiedliwości Unii Europejskiej 7 grudnia wyda wyrok w sprawie C-140/22, który będzie miał istotne znacznie dla spraw frankowych i wypracowania stanowiska przez sądy powszechne w przedmiocie przedawniania roszczeń i terminu liczenia odsetek – poinformował PAP radca prawny Wojciech Bochenek z kancelarii Bochenek, Ciesielski i Wspólnicy Kancelaria Adwokatów i Radców Prawnych.</p>

## Izrael zaproponował Hamasowi opcję przedłużenia rozejmu
 - [https://www.bankier.pl/wiadomosc/Izrael-zaproponowal-Hamasowi-opcje-przedluzenia-rozejmu-8653494.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Izrael-zaproponowal-Hamasowi-opcje-przedluzenia-rozejmu-8653494.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T14:33:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/a/75ca426b97d24b-948-568-0-112-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Izrael zaproponował Hamasowi "opcję" przedłużenia rozejmu, który rozpoczął się w piątek i który ma zakończyć się we wtorek o godzinie 7:00 (6:00 czasu polskiego) - poinformował w poniedziałek rzecznik izraelskiego rządu Ejlon Levy.</p>

## Rząd Tuska weźmie się za PPK? Oto czego możemy się spodziewać
 - [https://www.bankier.pl/wiadomosc/Rzad-Tuska-wezmie-sie-za-PPK-Oto-czego-mozemy-sie-spodziewac-8653459.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rzad-Tuska-wezmie-sie-za-PPK-Oto-czego-mozemy-sie-spodziewac-8653459.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T14:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/5/2e1ec77fcccb69-948-568-0-28-1894-1136.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rząd Donalda Tuska ma zamiar wprowadzić kilka zmian w
 sztandarowym projecie rządu PiS. PPK czekają zmiany - dowiedziała się 
"Gazeta Wyborcza". </p>

## Kryzys gospodarczy w Chinach. Młodzi decydują się na "żelazną miskę ryżu" - 77 kandydatów na 1 miejsce
 - [https://www.bankier.pl/wiadomosc/Kryzys-gospodarczy-w-Chinach-Mlodzi-decyduja-sie-na-zelazna-miske-ryzu-77-kandydatow-na-1-miejsce-8653482.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kryzys-gospodarczy-w-Chinach-Mlodzi-decyduja-sie-na-zelazna-miske-ryzu-77-kandydatow-na-1-miejsce-8653482.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T14:12:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/f/7e024d1655b73a-948-568-0-110-3983-2390.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przeszło 2,25 mln Chińczyków przystąpiło do tegorocznej tury egzaminów państwowych, które zdecydują o obsadzie blisko 40 tys. stanowisk w administracji publicznej – poinformowały państwowe media w poniedziałek. Tak wysokie zainteresowanie może wskazywać na zmianę nastawienia młodego pokolenia, które w obliczu słabnącej gospodarki decyduje się na "żelazną miskę ryżu", karierę urzędniczą zapewniającą stałość zatrudnienia, choć przy stosunkowo niskich zarobkach.</p>

## Tesla złożyła pozew przeciwko Szwecji za wspieranie strajku. "Przyczynia się do dyskryminacji"
 - [https://www.bankier.pl/wiadomosc/Tesla-zlozyla-pozew-przeciwko-Szwecji-za-wspieranie-strajku-Przyczynia-sie-do-dyskryminacji-8653464.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tesla-zlozyla-pozew-przeciwko-Szwecji-za-wspieranie-strajku-Przyczynia-sie-do-dyskryminacji-8653464.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T13:54:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/5/71d5d2ecb3083e-948-567-0-47-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Amerykański producent samochodów elektrycznych Tesla złożył w poniedziałek w sądzie w Norrkoepingu (południowa Szwecja) pozew przeciwko państwu szwedzkiemu. Koncern zarzuca władzom Szwecji wspieranie trwającego w tym kraju od początku listopada protestu związkowego.</p>

## Kolejne miasto w Polsce podnosi podatek od nieruchomości
 - [https://www.bankier.pl/wiadomosc/Bialystok-podnosi-podatek-od-nieruchomosci-8653460.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Bialystok-podnosi-podatek-od-nieruchomosci-8653460.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T13:49:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/c/1b8bb95becfefd-948-568-0-176-3915-2348.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />O 15 proc. wyższy ma być od stycznia 2024 roku podatek od nieruchomości w Białymstoku. W poniedziałek zdecydowali o tym białostoccy radni.</p>

## Korea Południowa. Ponad rok więzienia za wiersz gloryfikujący reżim Kim Dzong Una
 - [https://www.bankier.pl/wiadomosc/Korea-Poludniowa-Ponad-rok-wiezienia-za-wiersz-gloryfikujacy-rezim-Kim-Dzong-Una-8653437.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Korea-Poludniowa-Ponad-rok-wiezienia-za-wiersz-gloryfikujacy-rezim-Kim-Dzong-Una-8653437.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T13:25:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/3/e77bb0cef2aa6f-945-560-4-4-1854-1112.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sąd w Seulu skazał mężczyznę na 14 miesięcy więzienia za napisanie wiersza wychwalającego północnokoreański reżim – poinformowała w poniedziałek agencja Yonhap. "Nie muszę spędzać każdego dnia w rozpaczy, ponieważ nie mam pracy" – tak opisywał zalety życia na Północy skazany uczestnik konkursu zorganizowanego przez propagandowy portal kontrolowany przez rząd w Pjongjangu.</p>

## Energetyka jasnym punktem na GPW. Atomowa decyzja, KPO i spadek cen węgla w grze
 - [https://www.bankier.pl/wiadomosc/Energetyka-jasnym-punktem-na-GPW-Atomowa-decyzja-KPO-i-spadek-cen-wegla-w-grze-8653406.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Energetyka-jasnym-punktem-na-GPW-Atomowa-decyzja-KPO-i-spadek-cen-wegla-w-grze-8653406.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T13:05:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/1/2edc5cdb7609ff-948-568-0-431-2974-1784.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Po raz kolejny wyróżniającym się sektorem na GPW jest energetyka. Kursy największych branżowych spółek wyraźnie zyskują w poniedziałek przy słabszym ogólny sentymencie na rynkach akcji. Za wzrostami stoją informacje o zaliczce z KPO, atomowej decyzji dla ZE PAK-u i PGE oraz doniesienia o spadku cen węgla dla producentów energii elektrycznej.</p>

## Minister Moskwa: Polska wyśle skargę na Niemcy do TSUE ws. odpadów
 - [https://www.bankier.pl/wiadomosc/Minister-Moskwa-Polska-wysle-skarge-na-Niemcy-do-TSUE-ws-odpadow-8653389.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Minister-Moskwa-Polska-wysle-skarge-na-Niemcy-do-TSUE-ws-odpadow-8653389.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T12:32:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/2/19e1301f54cea5-948-568-0-0-2039-1223.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przygotowaliśmy kompletną skargę do TSUE na Niemcy w sprawie porzuconych w Polsce odpadów - wynika z poniedziałkowego wpisu minister klimatu i środowiska Anny Moskwy na platformie X (d. Twitter). Dodała, że skarga jeszcze w poniedziałek ma zostać wysłana do Trybunału.</p>

## Likwidacja TVP na horyzoncie. Minister Gliński chce zmiany w statutach TVP, Polskiego Radia i PAP. Jest zgoda
 - [https://www.bankier.pl/wiadomosc/Likwidacja-TVP-na-horyzoncie-Minister-Glinski-chce-zmiany-w-statutach-TVP-Polskiego-Radia-i-PAP-Jest-zgoda-8653382.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Likwidacja-TVP-na-horyzoncie-Minister-Glinski-chce-zmiany-w-statutach-TVP-Polskiego-Radia-i-PAP-Jest-zgoda-8653382.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T12:22:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/f/c5a46b0e42b9f0-948-567-0-67-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rada Mediów Narodowych zgodziła się w poniedziałek na dokonanie zmian w statutach TVP, Polskiego Radia i PAP - dowiedziała się PAP. Informacje te potwierdził przewodniczący RMN Krzysztof Czabański. Zgodnie ze zmianami "w razie otwarcia likwidacji likwidatorami są wszyscy członkowie Zarządu oraz kierownik komórki organizacyjnej Spółki zajmującej się obsługą prawną".</p>

## Nowy konserwatywny rząd Nowej Zelandii wycofał się z planu walki z paleniem papierosów
 - [https://www.bankier.pl/wiadomosc/Nowa-Zelandia-wycofala-sie-z-planu-walki-z-paleniem-papierosow-8653376.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nowa-Zelandia-wycofala-sie-z-planu-walki-z-paleniem-papierosow-8653376.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T12:12:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/3/0ec358137e189d-948-568-0-253-3750-2249.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nowy konserwatywny rząd Nowej Zelandii wycofa się z ambitnego planu walki z paleniem papierosów - potwierdził w poniedziałek nowy premier Christopher Luxon. Przegłosowany wcześniej tzw. pokoleniowy zakaz palenia zakładał zakaz sprzedaży papierosów osobom urodzonym po 2008 roku.</p>

## Emerytury dla artystów zawodowych i dopłaty do składek ZUS. Projekt ustawy w Sejmie
 - [https://www.bankier.pl/wiadomosc/Emerytury-dla-artystow-zawodowych-i-doplaty-do-skladek-ZUS-Projekt-ustawy-w-Sejmie-8653372.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Emerytury-dla-artystow-zawodowych-i-doplaty-do-skladek-ZUS-Projekt-ustawy-w-Sejmie-8653372.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T12:09:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/a/afd784e5f825ef-948-568-0-0-3351-2010.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Do Sejmu w poniedziałek wpłynął projekt ustawy o artystach zawodowych, który skierował premier Mateusz Morawiecki. Do prezentowania stanowiska rządu w tej sprawie w toku prac parlamentarnych został upoważniony Minister Kultury i Dziedzictwa Narodowego - zaznaczył premier.</p>

## 500+ zostanie wyrównane do 800 zł za okres sierpień-grudzeń 2023? ZUS zabrał głos
 - [https://www.bankier.pl/wiadomosc/500-zostanie-wyrownane-do-800-zl-za-okres-sierpien-grudzen-2023-ZUS-zabral-glos-8653368.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/500-zostanie-wyrownane-do-800-zl-za-okres-sierpien-grudzen-2023-ZUS-zabral-glos-8653368.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T12:05:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/a/5fc22f3aff3fdf-948-568-0-30-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wyrównanie świadczenia 500+ do kwoty 800 zł za okres od sierpnia 2023 r. do grudnia 2023 r. to fałszywa informacja, która krąży w internecie – wskazał Zakład Ubezpieczeń Społecznych.</p>

## Jacek Sasin zabrał głos na temat elektrowni jądrowej w Koninie
 - [https://www.bankier.pl/wiadomosc/Jacek-Sasin-zabral-glos-na-temat-elektrowni-jadrowej-w-Koninie-8653324.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Jacek-Sasin-zabral-glos-na-temat-elektrowni-jadrowej-w-Koninie-8653324.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T11:02:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/a/fb49e827e76e90-948-568-0-67-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Elektrownia jądrowa w Koninie-Pątnowie będzie ważnym elementem krajowego bezpieczeństwa energetycznego - podkreślił w poniedziałek minister aktywów państwowych Jacek Sasin. Prezes PGE PAK Energia Jądrowa Jakub Rybicki podkreślił, że trwają pracę nad tym, by w latach 2028-2029 "wbić pierwszą łopatę".</p>

## Konfederacja wnioskuje o trzy komisje śledcze. Ma jednak inne pomysły niż KO
 - [https://www.bankier.pl/wiadomosc/Konfederacja-wnioskuje-o-trzy-komisje-sledcze-Ma-jednak-inne-pomysly-niz-KO-8653314.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Konfederacja-wnioskuje-o-trzy-komisje-sledcze-Ma-jednak-inne-pomysly-niz-KO-8653314.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T10:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/a/5d1773204cb76b-948-568-30-0-4051-2430.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Konfederacja przygotowała trzy projekty wniosków o komisje śledcze - dot. polityki energetycznej, do zbadania przyczyn i skutków niekontrolowanego importu żywności z Ukrainy oraz ds. potencjalnych nieprawidłowości związanych z polityką covidową - poinformowali w poniedziałek politycy ugrupowania.</p>

## Posiłki w restauracjach coraz droższe. Ile średnio trzeba zapłacić za pizzę?
 - [https://www.bankier.pl/wiadomosc/Posilki-w-restauracjach-coraz-drozsze-Ile-srednio-trzeba-zaplacic-za-pizze-8653307.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Posilki-w-restauracjach-coraz-drozsze-Ile-srednio-trzeba-zaplacic-za-pizze-8653307.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T10:38:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/e/44154bdbd9dc5a-948-568-0-39-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W tym roku za pizzę trzeba zapłacić średnio 43 zł, czyli o 10 proc. więcej niż w 2022 roku – wynika z tegorocznego Raportu Food Trendów, który przedstawiła zarówno preferencje żywieniowe Polaków, jak i średnie ceny najpopularniejszych dań w restauracjach.
 </p>

## Zmiany w refundacji leków. NFZ podał szczegóły
 - [https://www.bankier.pl/wiadomosc/Zmiany-w-refundacji-lekow-NFZ-podal-szczegoly-8653306.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zmiany-w-refundacji-lekow-NFZ-podal-szczegoly-8653306.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T10:38:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/3/28ea4cf070287c-948-568-440-0-3483-2090.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Refundacja leków recepturowych, czyli leków na receptę, które farmaceuta przygotowuje w aptece, stale rośnie. Szacujemy, że w tym roku przekroczy ona 700 mln zł. Ministerstwo Zdrowia postanowiło uregulować rynek leków recepturowych - przekazał w poniedziałek Narodowy Fundusz Zdrowia.</p>

## Wnorowski: Obecne tempo dezinflacji to brak przestrzeni do obniżek stóp na dłużej
 - [https://www.bankier.pl/wiadomosc/Wnorowski-Obecne-tempo-dezinflacji-to-brak-przestrzeni-do-obnizek-stop-na-dluzej-8653295.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wnorowski-Obecne-tempo-dezinflacji-to-brak-przestrzeni-do-obnizek-stop-na-dluzej-8653295.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T10:24:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/b/9e0e16bb90b8fa-948-568-0-86-3131-1878.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Uporczywość inflacji w Polsce daje mocne przesłanki do strategii "higher for longer" dla stóp procentowych, a jeśli kolejne projekcje pokażą tempo dezinflacji zbliżone do zakładanego obecnie, to przestrzeni do obniżek stóp nie będzie przez dłuższy czas - powiedział PAP Biznes członek RPP Henryk Wnorowski.</p>

## UOKiK z zarzutami dla Dr Smile. Na tapecie nierzetelność i naruszanie zbiorowych interesów konsumentów
 - [https://www.bankier.pl/wiadomosc/UOKiK-z-zarzutami-dla-Dr-Smile-Na-tapecie-nierzetelnosc-i-naruszanie-zbiorowych-interesow-konsumentow-8653294.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/UOKiK-z-zarzutami-dla-Dr-Smile-Na-tapecie-nierzetelnosc-i-naruszanie-zbiorowych-interesow-konsumentow-8653294.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T10:22:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/d/0a9a497d7f61d3-948-568-5-0-2042-1225.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prezes UOKIK Tomasz Chróstny postawił zarzuty spółce Dr Smile za nierzetelność i naruszanie zbiorowych interesów konsumentów. Chodzi m.in. o utrudniony dostęp do pełnych warunków umowy i poddawanie presji w celu natychmiastowego jej podpisania.</p>

## Stracił prawie wszystko na kryptowalutach. Nie posłuchał matki – szefowej EBC
 - [https://www.bankier.pl/wiadomosc/Stracil-prawie-wszystko-na-kryptowalutach-Nie-posluchal-matki-szefowej-EBC-8653274.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Stracil-prawie-wszystko-na-kryptowalutach-Nie-posluchal-matki-szefowej-EBC-8653274.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T09:54:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/4/6331caff2372ff-948-568-0-52-1750-1049.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W czasie spotkania ze studentami we Frankfurcie nad Menem prezeska Europejskiego Banku Centralnego, kształtującego politykę monetarną w strefie euro przyznała, że ma syna, który zignorował jej ostrzeżenia na temat kryptowalut i stracił „prawie wszystko”, co w nie zainwestował.
</p>

## Biedronka wprowadza elektroniczne cenówki. Do złudzenia przypominają papier
 - [https://www.bankier.pl/wiadomosc/Biedronka-wprowadza-elektroniczne-cenowki-Do-zludzenia-przypominaja-papier-8653258.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Biedronka-wprowadza-elektroniczne-cenowki-Do-zludzenia-przypominaja-papier-8653258.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T09:45:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/6/4dd44c0ea0ae3b-948-568-2-64-957-574.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Biedronka otworzyła właśnie swoją 3,5-tysięczną placówkę. Sklep powstał w
 oparciu o strategię zrównoważonego rozwoju sieci i jako 
pierwszy w Polsce został wyposażony w elektroniczne etykiety cenowe.</p>

## ZUS od grudnia zwiększa limity. Dobra wiadomość dla wcześniejszych emerytów i rencistów
 - [https://www.bankier.pl/wiadomosc/ZUS-od-grudnia-zwieksza-limity-Dobra-wiadomosc-dla-wczesniejszych-emerytow-i-rencistow-8653259.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/ZUS-od-grudnia-zwieksza-limity-Dobra-wiadomosc-dla-wczesniejszych-emerytow-i-rencistow-8653259.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T09:37:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/d/eda21d13f93a6e-945-560-10-53-4277-2566.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Emeryci i renciści mogą pracować i dorabiać, ale niektórych z nich obowiązują limity zarobkowe. Gdy je przekroczą, ZUS może zmniejszyć lub zawiesić wypłacane świadczenie - powiedział PAP rzecznik ZUS Paweł Żebrowski. Od 1 grudnia limity będą wyższe.</p>

## Rząd przygotuje autopoprawkę do projektu budżetu. Górnicy odetchną z ulgą
 - [https://www.bankier.pl/wiadomosc/Rzad-przygotuje-autopoprawke-do-projektu-budzetu-Gornicy-odetchna-z-ulga-8653253.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rzad-przygotuje-autopoprawke-do-projektu-budzetu-Gornicy-odetchna-z-ulga-8653253.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T09:27:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/7/c5e53e7d5da82d-948-568-0-0-1920-1151.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rząd przygotuje autopoprawkę do projektu budżetu państwa, dzięki której obligacje o wartości 7 mld zł zostaną przeznaczone na pomoc dla Polskiej Grupy Górniczej i dwóch innych górniczych spółek, objętych programem wsparcia - poinformował w poniedziałek PAP wiceminister aktywów państwowych Marek Wesoły.</p>

## Hakerzy włamali się ALAB. Do sieci wyciekły dane medyczne kilkudziesięciu tysięcy Polaków
 - [https://www.bankier.pl/wiadomosc/Hakerzy-wlamali-sie-ALAB-Do-sieci-wyciekly-dane-medyczne-kilkudziesieciu-tysiecy-Polakow-8653240.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Hakerzy-wlamali-sie-ALAB-Do-sieci-wyciekly-dane-medyczne-kilkudziesieciu-tysiecy-Polakow-8653240.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T09:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/e/299380f72296e4-929-557-70-2-929-557.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Do internetu trafiły wyniki badań medycznych wykonanych przez ostatnie 
kilka lat w jednej z największych ogólnopolskich sieci laboratoriów 
medycznych, firmy ALAB - donosi Zaufana Trzecia Strona. Wyciek jest skutkiem ataku grupy ransomware, a dane to podobno tylko próbka.</p>

## Rolnicy blokują przejście graniczne w Medyce. W tym roku protest się nie skończy
 - [https://www.bankier.pl/wiadomosc/Rolnicy-blokuja-przejscie-graniczne-w-Medyce-W-tym-roku-protest-sie-nie-skonczy-8653228.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rolnicy-blokuja-przejscie-graniczne-w-Medyce-W-tym-roku-protest-sie-nie-skonczy-8653228.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T08:39:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/8/cab59132cf770d-948-568-30-127-2970-1781.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rolnicy z "Oszukanej wsi" rozpoczęli w poniedziałek całodobową blokadę przejścia granicznego w Medyce na Podkarpaciu i ma ona potrwać do 3 stycznia 2024 r. Przepuszczają, auta osobowe, autokary oraz TIR-y, ale tylko z pomocą humanitarną i sprzętem wojskowym. Nie wykluczają jednak zaostrzenia protestu.</p>

## Jaką decyzję podejmie KNF ws. polityki dywidendowej dla banków?
 - [https://www.bankier.pl/wiadomosc/Jaka-decyzje-podejmie-KNF-ws-polityki-dywidendowej-dla-bankow-8653224.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Jaka-decyzje-podejmie-KNF-ws-polityki-dywidendowej-dla-bankow-8653224.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T08:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/b/4c1ce1b7235374-948-568-0-258-4500-2699.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Komisja Nadzoru Finansowego z dużym prawdopodobieństwem utrzyma na 2024 rok dotychczasowe założenia polityki dywidendowej dla banków komercyjnych określone w perspektywie średniookresowej - poinformował PAP Biznes zastępca Przewodniczącego KNF Marcin Mikołajczyk.</p>

## Frank testuje wsparcie. Dolar poniżej 4 zł
 - [https://www.bankier.pl/wiadomosc/Frank-testuje-wsparcie-Dolar-ponizej-4-zl-8653220.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Frank-testuje-wsparcie-Dolar-ponizej-4-zl-8653220.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T08:26:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/a/1fe10281afc9cb-948-568-31-137-1684-1010.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nowy tydzień rozpoczynamy z kursem euro leżącym tuż powyżej postcovidowego minimum. Także frank szwajcarski nie pokonał poziomu wsparcia. Za dolara amerykańskiego płacono mniej niż 4 złote.
</p>

## Nowe, bezpłatne projekty domów już dostępne do pobrania
 - [https://www.bankier.pl/wiadomosc/Nowe-bezplatne-projekty-domow-juz-dostepne-do-pobrania-8653198.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nowe-bezplatne-projekty-domow-juz-dostepne-do-pobrania-8653198.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T07:43:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/6/feffcb8e6bb5a7-948-567-0-22-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Na stronie Głównego Urzędu Nadzoru Budowlanego (GUNB) dostępne są cztery nowe, bezpłatne projekty domów. Dwa z nich to domy o powierzchni ok. 120 m kw., a kolejne dwa o powierzchni ok. 180 m kw. – przekazało PAP ministerstwo rozwoju i technologii.</p>

## Po ślub do kościoła czy urzędu? W ostatnich latach zaszła duża zmiana
 - [https://www.bankier.pl/wiadomosc/Po-slub-do-kosciola-czy-urzedu-W-ostatnich-latach-zaszla-duza-zmiana-8653196.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Po-slub-do-kosciola-czy-urzedu-W-ostatnich-latach-zaszla-duza-zmiana-8653196.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T07:38:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/f/5ec050c17eba6f-945-560-0-22-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W 2022 roku odsetek małżeństw
 wyznaniowych wyniósł zaledwie 50,9 proc. Dwadzieścia lat wcześniej było
 to 73 proc. Polacy zamiast kościoły częściej wybierają Urząd Stanu 
Cywilnego - wynika z najnowszych danych GUS, opublikowanym w Roczniku 
Statystycznym 2023.</p>

## NBP przeznacza miliony na "tajnych doradców" prezesa Glapińskiego?
 - [https://www.bankier.pl/wiadomosc/NBP-przeznacza-miliony-na-tajnych-doradcow-prezesa-Glapinskiego-8653171.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/NBP-przeznacza-miliony-na-tajnych-doradcow-prezesa-Glapinskiego-8653171.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T06:47:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/c/064417999acffe-948-568-0-0-3465-2079.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ponad 4,6 mln zł zarobili w 2022 r. doradcy Adama Glapińskiego. NBP 
odmawia ujawnienia ich nazwisk - ustaliła "Rzeczpospolita". I sugeruje, 
że to idealne miejsce do przeczekania "wiatru zmian" dla kadr PiS-u.</p>

## Elon Musk spotka się z prezydentem Izraela. Biznesmen ratuje wizerunek?
 - [https://www.bankier.pl/wiadomosc/Elon-Musk-spotka-sie-z-prezydentem-Izraela-Biznesmen-ratuje-wizerunek-8653168.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Elon-Musk-spotka-sie-z-prezydentem-Izraela-Biznesmen-ratuje-wizerunek-8653168.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T06:33:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/3/32ec997e318854-948-568-2-12-997-598.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prezydent Izraela Icchak Hercog spotka się z miliarderem Elonem Muskiem podczas wizyty biznesmena w poniedziałek w tym kraju; tematem ich rozmowy ma być walka z antysemityzmem - poinformowała agencja AFP, powołując się na kancelarię prezydencką.</p>

## Średnio kilkanaście tys. zł. Takie odprawy dostanie "nowy" rząd Mateusza Morawieckiego
 - [https://www.bankier.pl/wiadomosc/Srednio-kilkanascie-tys-zl-Takie-odprawy-dostanie-nowy-rzad-Mateusza-Morawieckiego-8653164.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Srednio-kilkanascie-tys-zl-Takie-odprawy-dostanie-nowy-rzad-Mateusza-Morawieckiego-8653164.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T06:18:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/d/35c87b5f8d19ff-948-568-0-27-2717-1630.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Po wyborach parlamentarnych, w których najwięcej głosów otrzymał PiS, jednak nie posiada parlamentarnej większości, prezydent Andrzej Duda powierzył sformułowanie rządu Mateuszowi Morawieckiemu (mimo sprzeciwu większości środowisk). Będą to krótkie - bo dwutygodniowe rządy - ale odprawy całkiem spore. Dostaną je też ci ministrowie, którzy nie dostaną ponownego zaproszenia tj. Przemysław Czarnek, Mariusz Błaszczak czy Jacek Sasin. 
</p>

## Polska ziemią obiecaną dla flipperów i deweloperów
 - [https://www.bankier.pl/wiadomosc/Polska-ziemia-obiecana-dla-flipperow-i-deweloperow-8653117.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polska-ziemia-obiecana-dla-flipperow-i-deweloperow-8653117.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T06:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/8/5258c2234bb88a-948-568-36-275-2787-1672.png" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Polska stała się rajem dla „dostawców” nieruchomości mieszkaniowych. Rynek jest mocno rozchwiany, na czym tracą ludzie kupujący swoje pierwsze lokum, a nieliczni zbijają fortuny. Kilku z tych nielicznych dyskutowało podczas Forum Finansów i Inwestycji.
</p>

## Kaczyński: kształt rządu ekspercko-politycznego to mój pomysł
 - [https://www.bankier.pl/wiadomosc/Kaczynski-ksztalt-rzadu-ekspercko-politycznego-to-moj-pomysl-8653150.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kaczynski-ksztalt-rzadu-ekspercko-politycznego-to-moj-pomysl-8653150.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T05:51:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/b/a034db9e9f98cf-948-568-0-184-4092-2455.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kształt rządu ekspercko-politycznego, który w poniedziałek przedstawi premier Mateusz Morawiecki, to mój pomysł. Chcemy zaproponować nowe twarze - mówi w rozmowie z PAP prezes Prawa i Sprawiedliwości Jarosław Kaczyński. Trzeba zakończyć wojnę, którą prowadzi Platforma Obywatelska - podkreśla.</p>

## Polska gospodarka niebawem przyspieszy. Napotka jednak poważny problem
 - [https://www.bankier.pl/wiadomosc/Polska-gospodarka-niebawem-przyspieszy-Napotka-jednak-powazny-problem-8653149.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polska-gospodarka-niebawem-przyspieszy-Napotka-jednak-powazny-problem-8653149.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T05:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/a/5fc5cac18965e7-948-568-0-209-2987-1792.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Według różnych prognoz PKB naszego kraju wzrośnie w przyszłym roku o około 3 proc. Prognozowanie jest jednak obarczone dużym marginesem błędu ze względu na liczne niewiadome i wyzwania tj. spowolnienie w Niemczech i całej strefie euro, poziom konsumpcji czy decyzje, jakie podejmie nowy rząd ws. stawek podatkowych czy tarcz antyinflacyjnych. To, co dla przedsiębiorstw istotne, to przewidywalne otoczenie prawno-podatkowe.</p>

## Miasta narażone na zmiany klimatu i klęski żywiołowe. Czy jest jakieś rozwiązanie?
 - [https://www.bankier.pl/wiadomosc/Miasta-narazone-na-zmiany-klimatu-i-kleski-zywiolowe-Czy-jest-jakies-rozwiazanie-8653139.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Miasta-narazone-na-zmiany-klimatu-i-kleski-zywiolowe-Czy-jest-jakies-rozwiazanie-8653139.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T05:35:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/1/e09fef6c191b35-948-568-0-0-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wszechobecna betonoza i asfalt w miastach potęgują ekstremalne zjawiska pogodowe, wynikające ze zmian klimatu. Według raportu „Innowacyjne miasta” ThinkCo i Otodom prawie 60 proc. miast liczących ok. 300 tys. mieszkańców jest obecnie narażonych na co najmniej jeden z sześciu rodzajów klęsk żywiołowych: cyklony, susze, powodzie, trzęsienia ziemi, osuwiska i erupcje wulkanów. Dlatego zrównoważony rozwój i przygotowanie miast na skutki wynikające ze zmian klimatycznych jest dziś centralnym zagadnieniem miejskich polityk.
</p>

## Nowe technologie również dla rolników. Do tego mogą je wykorzystać
 - [https://www.bankier.pl/wiadomosc/Nowe-technologie-rowniez-dla-rolnikow-Do-tego-moga-je-wykorzystac-8653140.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nowe-technologie-rowniez-dla-rolnikow-Do-tego-moga-je-wykorzystac-8653140.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T05:35:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/9/cbfcb8d0d35d84-948-568-10-140-1990-1193.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nowe technologie i rozwiązania cyfrowe mają coraz większe zastosowanie w rolnictwie. Dzięki nim procesy rolnicze są bardziej wydajne, efektywne i zrównoważone, a rolnik jest w stanie zautomatyzować...</p>

## Jak radzi sobie Andrzej Duda? Polacy ocenili prezydenta
 - [https://www.bankier.pl/wiadomosc/Jak-radzi-sobie-Andrzej-Duda-Polacy-ocenili-prezydenta-8653138.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Jak-radzi-sobie-Andrzej-Duda-Polacy-ocenili-prezydenta-8653138.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T05:34:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/5/1a04d075792c51-948-568-0-17-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />58,8 proc. Polaków źle ocenia prezydenta, a dobrze jedynie 32,5. Tylko 8,8 proc. respondentów nie ma zdania w sprawie oceny działania prezydenta Andrzeja Dudy wobec nowej większości parlamentarnej - wynika z sondażu IBRiS dla "Rzeczpospolitej".</p>

## Koniec z obowiązkiem magazynowania gazu? Nowelizacja ustawy w toku
 - [https://www.bankier.pl/wiadomosc/Koniec-z-obowiazkiem-magazynowania-gazu-Nowelizacja-ustawy-w-toku-8653136.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Koniec-z-obowiazkiem-magazynowania-gazu-Nowelizacja-ustawy-w-toku-8653136.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T05:31:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/f/9f0e5ce0b55b04-948-568-2-32-997-598.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nowela ustawy o zapasach ropy naftowej, produktów naftowych i gazu zwolni firmy z obowiązku utrzymywania zapasów gazu; odpowiedzialna za to stanie się Rządowa Agencja Rezerw Strategicznych - poinformował PAP resort klimatu i środowiska. Obecnie projekt nowelizacji rozpatruje Stały Komitet Rady Ministrów.</p>

## Janusz Palikot o śledztwie prokuratury i przyczynach kryzysu. "Do końca myślałem, że pojawi się inwestor"
 - [https://www.bankier.pl/wiadomosc/Wywiad-z-Januszem-Palikotem-wierzyciele-nowi-inwestorzy-i-prokuratura-8652402.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wywiad-z-Januszem-Palikotem-wierzyciele-nowi-inwestorzy-i-prokuratura-8652402.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/f/cb7fb04c930e67-948-568-0-0-4174-2504.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Janusza Palikota zapytaliśmy o śledztwo prokuratury ws. Buntu Finansowego, plany spłaty wierzycieli i przyczyny problemów finansowych Grupy Tenczynek. Biznesmen opowiedział nam też o współpracy z Kubą Wojewódzkim i liczbie osób, które zainwestowały w jego biznes.</p>

## NBP prognozuje – hipoteczna hossa prędko nie wróci
 - [https://www.bankier.pl/wiadomosc/NBP-prognozuje-hipoteczna-hossa-predko-nie-wroci-8653023.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/NBP-prognozuje-hipoteczna-hossa-predko-nie-wroci-8653023.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/b/e3e71c948ac099-948-568-0-297-1980-1187.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Epizod, który można nazwać „hipoteczną zimą”, już za nami. Nie oznacza to, że w najbliższych kwartałach popyt na kredyty mieszkaniowe ma szansę powrócić do wartości obserwowanych przed 2022 r. Z prognoz przedstawionych przez Narodowy Bank Polski wynika, że do końca 2025 r. dynamika będzie niska, jednocyfrowa.</p>

## Prognoza walutowa. Analitycy nie przekonali się do "ery mocnego złotego"
 - [https://www.bankier.pl/wiadomosc/Prognoza-walutowa-listopad-2023-Era-mocnego-zlotego-8651608.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Prognoza-walutowa-listopad-2023-Era-mocnego-zlotego-8651608.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/3/4ca758d6b61efb-948-568-0-11-4266-2560.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Jesienne umocnienie polskiej waluty zaskoczyło analityków
niczym przysłowiowa już zima drogowców. Nikt nie spodziewał się spadku kursu
euro poniżej 4,40 zł. Teraz trzeba będzie zrewidować prognozy.</p>

## Tu trwa boom na pracę, a jak wypadają sąsiednie miasta? Nie jest już tak kolorowo
 - [https://www.bankier.pl/wiadomosc/W-Wielkopolsce-trwa-boom-na-prace-W-kujawsko-pomorskim-bezrobocie-powyzej-sredniej-8651529.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/W-Wielkopolsce-trwa-boom-na-prace-W-kujawsko-pomorskim-bezrobocie-powyzej-sredniej-8651529.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/e/a562b1c0db9d96-948-568-0-88-1773-1064.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W czasach stabilnie niskiego bezrobocia łatwo zapomnieć o tym, że 
wskaźniki w poszczególnych województwach potrafią się znacznie od siebie
 różnić. Tradycyjnie najlepszą koniunkturę obserwuje się na 
wielkopolskim rynku pracy. Toruń i Bydgoszcz, choć pod względem 
geograficznym niewiele dzieli je od Wielkopolski, mają z bezrobociem 
zdecydowanie większy problem, choć wydają się wychodzić na prostą.</p>

## „Bezpieczny kredyt”. Czy można zarejestrować firmę w mieszkaniu, nie prowadząc tam działalności? Tak, ale...
 - [https://www.bankier.pl/wiadomosc/Bezpieczny-kredyt-2-proc-Czy-mozna-zarejestrowac-firme-w-mieszkaniu-nie-prowadzac-tam-dzialalnosci-8651431.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Bezpieczny-kredyt-2-proc-Czy-mozna-zarejestrowac-firme-w-mieszkaniu-nie-prowadzac-tam-dzialalnosci-8651431.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-27T05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/4/ad1c20ccb1dda7-948-568-0-98-2184-1310.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Jedną z kwestii budzących wątpliwości w przypadku „Bezpiecznego kredytu 2 proc.” jest możliwość zarejestrowania działalności gospodarczej. Ustawa mówi, że kredytowany lokal nie może być przeznaczony na prowadzenie firmy. Jak wygląda natomiast kwestia samej rejestracji działalności, bez fizycznego wykonywania tam pracy?</p>

