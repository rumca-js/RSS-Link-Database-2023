# Source:Science News, URL:https://www.sciencenews.org/feed, language:en-US

## Some picky Australian mosquitoes may target frog nostrils for blood
 - [https://www.sciencenews.org/article/australian-mosquitoes-target-frog-nostrils-blood](https://www.sciencenews.org/article/australian-mosquitoes-target-frog-nostrils-blood)
 - RSS feed: https://www.sciencenews.org/feed
 - date published: 2023-11-27T15:00:00+00:00

The insects seem to sip from nowhere else on frogs’ bodies. Thinner skin or denser blood vessels near the nostrils might explain why.

## Reindeer herders and scientists collaborate to understand Arctic warming
 - [https://www.sciencenews.org/article/reindeer-indigenous-herders-arctic-warming-rain-on-snow](https://www.sciencenews.org/article/reindeer-indigenous-herders-arctic-warming-rain-on-snow)
 - RSS feed: https://www.sciencenews.org/feed
 - date published: 2023-11-27T13:00:00+00:00

Siberian reindeer herders and scientists are working together to figure out how to predict rain-on-snow events that turn tundra into deadly ice.

