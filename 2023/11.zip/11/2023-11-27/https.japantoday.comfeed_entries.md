# Source:Japan Today, URL:https://japantoday.com/feed, language:en

## Willian strikes twice from the spot as Fulham beat Wolves
 - [https://japantoday.com/category/sports/willian-strikes-twice-from-the-spot-as-fulham-beat-wolves](https://japantoday.com/category/sports/willian-strikes-twice-from-the-spot-as-fulham-beat-wolves)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-11-27T22:53:59+00:00

Willian scored twice from the penalty spot on Monday as Fulham beat Wolves 3-2 to notch their first Premier League win since early October and climb 10 points…

## Nagasaki survivor urges nuke weapons abolition at U.N. treaty confab
 - [https://japantoday.com/category/national/nagasaki-survivor-urges-nuke-weapons-abolition-at-u.n.-treaty-confab](https://japantoday.com/category/national/nagasaki-survivor-urges-nuke-weapons-abolition-at-u.n.-treaty-confab)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-11-27T22:52:18+00:00

An 83-year-old survivor of the U.S. atomic bombing of Japan's Nagasaki called Monday for the elimination of nuclear weapons in his speech at the onset of a five-day…

## New incentives could boost satisfaction with in-person work, but few employers are making changes
 - [https://japantoday.com/category/business/new-incentives-could-boost-satisfaction-with-in-person-work-but-few-employers-are-making-changes](https://japantoday.com/category/business/new-incentives-could-boost-satisfaction-with-in-person-work-but-few-employers-are-making-changes)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-11-27T22:50:27+00:00

Justin Ryan Horton has two jobs. When he's not putting in 24-hour shifts as a firefighter, the 22-year-old is working as an administrative assistant for a local community…

## Shop employee fights off three robbers with polearm in Tokyo's Ueno district
 - [https://japantoday.com/category/crime/shop-employee-fights-off-three-robbers-with-polearm-in-ueno](https://japantoday.com/category/crime/shop-employee-fights-off-three-robbers-with-polearm-in-ueno)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-11-27T22:25:38+00:00

At around 6:40 p.m. on Sunday evening, a pair of men on a motor bike pulled up to a store that sells precious metals in Tokyo’s Ueno district, located…

## Diplomatic spat over the Parthenon Marbles scuttles meeting of British and Greek leaders
 - [https://japantoday.com/category/world/diplomatic-spat-over-the-parthenon-marbles-scuttles-meeting-of-british-and-greek-leaders](https://japantoday.com/category/world/diplomatic-spat-over-the-parthenon-marbles-scuttles-meeting-of-british-and-greek-leaders)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-11-27T22:05:57+00:00

A diplomatic spat erupted Monday between Greece and Britain after the U.K. canceled a planned meeting of their prime ministers, prompting the Greek premier to accuse his British…

## Imanaga becomes free agent Tuesday
 - [https://japantoday.com/category/sports/wbc-final-winner-shota-imanaga-becomes-free-agent-tuesday-talks-can-run-through-jan.-11](https://japantoday.com/category/sports/wbc-final-winner-shota-imanaga-becomes-free-agent-tuesday-talks-can-run-through-jan.-11)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-11-27T21:52:17+00:00

Shōta Imanaga, who got the win for Japan in this year's World Baseball Classic final against the United States, will become a free agent Tuesday and major league…

## Cyber Monday marks year's biggest online shopping day in U.S.
 - [https://japantoday.com/category/business/still-looking-for-deals-on-holiday-gifts-retailers-are-offering-discounts-on-cyber-monday](https://japantoday.com/category/business/still-looking-for-deals-on-holiday-gifts-retailers-are-offering-discounts-on-cyber-monday)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-11-27T21:49:05+00:00

Consumers are scouring the internet for online deals as they begin to cap off the five-day post-Thanksgiving shopping bonanza with Cyber Monday.
Even though e-commerce is now part…

## Why do they give? Donors speak about what moves them and how they plan end-of-year donations
 - [https://japantoday.com/category/features/lifestyle/why-do-they-give-donors-speak-about-what-moves-them-and-how-they-plan-end-of-year-donations](https://japantoday.com/category/features/lifestyle/why-do-they-give-donors-speak-about-what-moves-them-and-how-they-plan-end-of-year-donations)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-11-27T21:43:06+00:00

What motivates people to donate to charities or causes they care about is often deeply personal. Donors name relatives or friends who have survived or died from illnesses.…

## Kenya flooding death toll rises to 76, with thousands marooned by worsening rains
 - [https://japantoday.com/category/world/kenya-raises-alarm-as-flooding-death-toll-rises-to-76-with-thousands-marooned-by-worsening-rains](https://japantoday.com/category/world/kenya-raises-alarm-as-flooding-death-toll-rises-to-76-with-thousands-marooned-by-worsening-rains)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-11-27T21:41:32+00:00

The Kenyan government on Monday urged people living in flood-prone areas to relocate to higher ground as heavy rains and flash floods continued to wreak havoc across East…

## Assailants in latest ship attack near Yemen were likely Somali, not Houthi rebels, Pentagon says
 - [https://japantoday.com/category/world/militants-in-latest-ship-attack-near-yemen-were-likely-somali-not-houthi-rebels-pentagon-says](https://japantoday.com/category/world/militants-in-latest-ship-attack-near-yemen-were-likely-somali-not-houthi-rebels-pentagon-says)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-11-27T21:41:23+00:00

The five armed assailants captured by U.S. forces after seizing a commercial ship near Yemen over the weekend were likely Somali and not Iranian-backed Houthi rebels, the Pentagon…

## UK government reaches pay deal with senior doctors that could end disruptive strikes
 - [https://japantoday.com/category/world/uk-government-reaches-a-pay-deal-with-senior-doctors-that-could-end-disruptive-strikes](https://japantoday.com/category/world/uk-government-reaches-a-pay-deal-with-senior-doctors-that-could-end-disruptive-strikes)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-11-27T21:41:16+00:00

Britain's government reached a deal with senior doctors in England that could potentially end a series of disruptive strikes, officials said Monday.
The Department of Health and Social…

## N Korean, U.S. envoys engage in rare, public sparring match at U.N.
 - [https://japantoday.com/category/world/north-korea-us-envoys-engage-in-rare-public-sparring-match-at-un](https://japantoday.com/category/world/north-korea-us-envoys-engage-in-rare-public-sparring-match-at-un)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-11-27T21:41:09+00:00

The United Nations ambassadors of the United States and North Korea sparred at the Security Council on Monday over Pyongyang's first spy satellite launch and the reasons for…

## Hungary's Orban ramps up anti-EU rhetoric amid row over frozen funds
 - [https://japantoday.com/category/world/hungary%27s-orban-ramps-up-anti-eu-rhetoric-amid-row-over-frozen-funds](https://japantoday.com/category/world/hungary%27s-orban-ramps-up-anti-eu-rhetoric-amid-row-over-frozen-funds)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-11-27T21:40:33+00:00

EU chief Charles Michel met Prime Minister Viktor Orban Monday in a bid to ease rising tensions, with the increasingly belligerent Hungarian leader threatening to block key decisions…

## Sweden PM condemns far-right call to tear down mosques
 - [https://japantoday.com/category/world/sweden-pm-condemns-far-right-call-to-tear-down-mosques](https://japantoday.com/category/world/sweden-pm-condemns-far-right-call-to-tear-down-mosques)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-11-27T21:40:24+00:00

Swedish Prime Minister Ulf Kristersson denounced the leader of the far-right party propping up his government Monday after he called for some mosques to be torn down.
Sweden…

## Musk visits Israel to meet top leaders as accusations of antisemitism on X grow
 - [https://japantoday.com/category/world/elon-musk-visits-israel-to-meet-top-leaders-as-accusations-of-antisemitism-on-x-grow](https://japantoday.com/category/world/elon-musk-visits-israel-to-meet-top-leaders-as-accusations-of-antisemitism-on-x-grow)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-11-27T21:40:04+00:00

Elon Musk, who's been under fire for endorsing an antisemitic conspiracy theory and wider accusations of hatred flourishing on his social media platform X, visited Israel, where he…

## Deadly storm cuts power to nearly two million in Russia, Ukraine
 - [https://japantoday.com/category/world/deadly-storm-cuts-power-to-nearly-2-mn-people-in-russia-ukraine](https://japantoday.com/category/world/deadly-storm-cuts-power-to-nearly-2-mn-people-in-russia-ukraine)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-11-27T21:39:52+00:00

Hurricane force winds, snowfall and flooding that swept parts of southern Russia, Ukraine and Moldova left at least eight people dead Monday and almost two million without power,…

## Israel and Hamas agree to extend truce for two more days, and to free more hostages and prisoners
 - [https://japantoday.com/category/world/israel-and-hamas-look-to-extend-cease-fire-on-its-final-day-with-one-more-hostage-swap-planned](https://japantoday.com/category/world/israel-and-hamas-look-to-extend-cease-fire-on-its-final-day-with-one-more-hostage-swap-planned)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-11-27T21:39:37+00:00

Israel and Hamas agreed to extend their cease-fire for two more days past Monday, the Qatari government said, raising the prospect of a longer halt to their deadliest…

## Ronaldo rejects penalty he's awarded in Asian Champions League
 - [https://japantoday.com/category/sports/ronaldo-rejects-penalty-he%27s-awarded-in-asian-champions-league](https://japantoday.com/category/sports/ronaldo-rejects-penalty-he%27s-awarded-in-asian-champions-league)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-11-27T21:39:26+00:00

Cristiano Ronaldo's honesty helped to nullify a penalty he was awarded as his 10-man Al-Nassr side held on to draw with Persepolis of Iran 0-0 in the Asian…

## FIBA holds draw for final 4 Olympic men's basketball qualifying events
 - [https://japantoday.com/category/sports/fiba-holds-draw-for-final-4-olympic-men%27s-basketball-qualifying-events](https://japantoday.com/category/sports/fiba-holds-draw-for-final-4-olympic-men%27s-basketball-qualifying-events)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-11-27T21:39:19+00:00

Dallas' Luka Doncic, Milwaukee's Giannis Antetokounmpo and Minnesota's Karl-Anthony Towns all still have a chance to play in next summer’s Paris Olympics.
But at least two of those…

## China turns to households in fight to slash carbon emissions
 - [https://japantoday.com/category/tech/analysis-china-turns-to-households-in-fight-to-slash-carbon-emissions1](https://japantoday.com/category/tech/analysis-china-turns-to-households-in-fight-to-slash-carbon-emissions1)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-11-27T21:38:52+00:00

At a gleaming new metro station on the edge of Shenzhen, the local government is promoting &quot;carbon coins&quot; to commuters to earn and trade for shopping vouchers and…

## Google to start deleting inactive accounts in December
 - [https://japantoday.com/category/tech/google-will-start-deleting-%27inactive%27-accounts-in-december.-here%27s-what-you-need-to-know](https://japantoday.com/category/tech/google-will-start-deleting-%27inactive%27-accounts-in-december.-here%27s-what-you-need-to-know)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-11-27T21:38:44+00:00

Have a Google account you haven't used in a while? If you want to keep it from disappearing, you should sign in before the end of the week.…

## Prosecutors allege rapper Young Thug led gang as trial begins
 - [https://japantoday.com/category/entertainment/prosecutors-allege-rapper-young-thug-led-gang-as-trial-begins](https://japantoday.com/category/entertainment/prosecutors-allege-rapper-young-thug-led-gang-as-trial-begins)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-11-27T21:37:46+00:00

Prosecutors in Atlanta said Monday that rapper Young Thug was the &quot;proclaimed leader&quot; of a gang that &quot;moved like a pack&quot; to commit crimes, as opening statements in…

## Locals use big-city thinking to bring Gunma onsen town back from brink
 - [https://japantoday.com/category/national/feature-locals-use-big-city-thinking-to-bring-onsen-town-back-from-brink](https://japantoday.com/category/national/feature-locals-use-big-city-thinking-to-bring-onsen-town-back-from-brink)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-11-27T21:37:12+00:00

A once-thriving, desolate-looking &quot;onsen&quot; hot spring town in eastern Japan is undergoing a transformation through a project that could work as a promising model for enlivening fellow struggling…

## House of Representatives staff member arrested for shoplifting
 - [https://japantoday.com/category/crime/house-of-representatives-staff-member-arrested-for-shoplifting](https://japantoday.com/category/crime/house-of-representatives-staff-member-arrested-for-shoplifting)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-11-27T21:36:19+00:00

Police in Yokohama have arrested a 53-year-old House of Representatives Secretariat staff member on suspicion of theft after he allegedly stole grocery items worth about 9,000 yen from…

## Kishida grilled over alleged gifts to IOC for Tokyo's Olympic bid
 - [https://japantoday.com/category/politics/update1-japan-pm-grilled-over-alleged-gifts-to-ioc-for-tokyo%27s-olympic-bid](https://japantoday.com/category/politics/update1-japan-pm-grilled-over-alleged-gifts-to-ioc-for-tokyo%27s-olympic-bid)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-11-27T21:35:46+00:00

Japan's Prime Minister Fumio Kishida was grilled in the Diet on Monday by the opposition bloc over Ishikawa Gov Hiroshi Hase's remarks that gifts were provided to International…

## Japan, Vietnam to strengthen security and economic ties
 - [https://japantoday.com/category/politics/japan-and-vietnam-agree-to-boost-ties-and-start-discussing-japanese-military-aid-amid-china-threat](https://japantoday.com/category/politics/japan-and-vietnam-agree-to-boost-ties-and-start-discussing-japanese-military-aid-amid-china-threat)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-11-27T21:35:36+00:00

Japan and Vietnam on Monday agreed to strengthen their security and economic ties in the face of China’s growing influence in the region. 
Japanese Prime Minister Fumio Kishida…

## 3 Asian powers' framework sparks hope for cooperation on N Korea
 - [https://japantoday.com/category/politics/focus-3-asian-powers%27-framework-sparks-hope-for-cooperation-on-n.-korea](https://japantoday.com/category/politics/focus-3-asian-powers%27-framework-sparks-hope-for-cooperation-on-n.-korea)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-11-27T21:35:10+00:00

The foreign ministers from Japan, China, and South Korea agreed in Busan on Sunday to communicate closely over North Korean issues, sparking hope that cooperative possibilities on the…

## Space man
 - [https://japantoday.com/category/picture-of-the-day/space-man-1](https://japantoday.com/category/picture-of-the-day/space-man-1)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-11-27T21:34:26+00:00

Yusaku Maezawa, the entrepreneur who became the first Japanese civilian to travel to the International Space Station in December 2021, attends an event in Tokyo on Monday, showing…

## Incoming New Zealand gov't to abandon anti-smoking laws
 - [https://japantoday.com/category/world/incoming-new-zealand-govt-to-abandon-anti-smoking-laws1](https://japantoday.com/category/world/incoming-new-zealand-govt-to-abandon-anti-smoking-laws1)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-11-27T09:52:26+00:00

New Zealand's incoming conservative government will jettison world-leading measures to stub out smoking, new Prime Minister Christopher Luxon confirmed Monday, in a move described by health campaigners as…

## Asian shares mostly decline, as investors watch spending, inflation
 - [https://japantoday.com/category/business/stock-market-today-asian-shares-mostly-decline-as-investors-watch-spending-inflation](https://japantoday.com/category/business/stock-market-today-asian-shares-mostly-decline-as-investors-watch-spending-inflation)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-11-27T07:39:12+00:00

Asian shares retreated Monday as investors awaited updates on consumer spending and inflation in the U.S. and other nations.
Japan’s benchmark Nikkei 225 dipped 0.5% to finish at…

## Father arrested for fatally stabbing 48-year-old son
 - [https://japantoday.com/category/crime/father-arrested-for-fatally-stabbing-48-year-old-son](https://japantoday.com/category/crime/father-arrested-for-fatally-stabbing-48-year-old-son)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-11-27T07:38:59+00:00

Police in Kagoshima have arrested a 70-year-old man on suspicion of murder after he fatally stabbed his 48-year-old son with a knife.
According to police, Yukihide Tai, a…

## Sumitomo Mitsui Financial Group CEO dies at 65
 - [https://japantoday.com/category/business/japan%27s-sumitomo-mitsui-financial-group-ceo-dies-at-65](https://japantoday.com/category/business/japan%27s-sumitomo-mitsui-financial-group-ceo-dies-at-65)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-11-27T07:38:13+00:00

Sumitomo Mitsui Financial Group (SMFG) on Monday said group CEO Jun Ohta died on Nov 25 aged 65 of pancreatic cancer.
Japan's second-biggest lender after Mitsubishi UFJ Financial…

## Line operator says 400,000 personal data items possibly leaked
 - [https://japantoday.com/category/national/line-operator-says-400-000-personal-data-items-possibly-leaked](https://japantoday.com/category/national/line-operator-says-400-000-personal-data-items-possibly-leaked)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-11-27T07:37:53+00:00

Some 400,000 items of personal data, including some linked to the Line messaging app, may have been leaked by its operator Japanese tech giant LY Corp, a company…

## North Korea restores border guard posts amid rising tensions over its satellite launch, Seoul says
 - [https://japantoday.com/category/world/north-korea-restores-border-guard-posts-amid-rising-tensions-over-its-satellite-launch-seoul-says](https://japantoday.com/category/world/north-korea-restores-border-guard-posts-amid-rising-tensions-over-its-satellite-launch-seoul-says)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-11-27T06:43:38+00:00

South Korea said Monday North Korea is restoring frontline guard posts that it had dismantled during a previous period of inter-Korean rapprochement, deepening tensions that spiked over the…

## Six teenagers to go on trial over beheading of French teacher
 - [https://japantoday.com/category/world/six-teenagers-in-court-over-beheading-of-french-teacher](https://japantoday.com/category/world/six-teenagers-in-court-over-beheading-of-french-teacher)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-11-27T03:05:06+00:00

Six teenagers go on trial behind closed doors on Monday, accused of involvement in the beheading of French history teacher Samuel Paty by a suspected Islamist in 2020…

