# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## LP performs "Golden" in The Current studio #music #shorts
 - [https://www.youtube.com/watch?v=FDnM5QgbHPk](https://www.youtube.com/watch?v=FDnM5QgbHPk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2023-11-27T20:12:41+00:00

New York artist Laura Pergolizzi — best known by their stage name LP — visited The Current studio to play songs from their latest album, "Love Lines," including this song, "Golden."

You can watch the full performance of "Golden" here: https://www.youtube.com/watch?v=eVQVJVzrw_Y

Musicians
Laura Pergolizzi – vocals, ukulele
Greg Garman – percussion
Andrew Berkeley Martin – guitar
J Ryan Kern – piano, guitar

Credits
Guests – @iamlpofficial 
Host – Mac Wilson
Producer – Derrick Stevens
Video Director – Aaron Ankrum
Video Editor – Eric Xu Romani 
Audio – Eric Xu Romani
Graphics – Natalia Toledo
Digital Producer – Luke Taylor

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube  

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1  

Like/Follow:
https://www.facebook.com/TheCu

