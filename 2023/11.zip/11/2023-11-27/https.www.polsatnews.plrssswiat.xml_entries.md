# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## Ukraina "zaopatruje" Rosję. Zaskakujące wyniki śledztwa
 - [https://www.polsatnews.pl/wiadomosc/2023-11-27/ukraina-zaopatruje-rosje-zaskakujace-wyniki-sledztwa](https://www.polsatnews.pl/wiadomosc/2023-11-27/ukraina-zaopatruje-rosje-zaskakujace-wyniki-sledztwa)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-11-27T21:04:00+00:00

Rosyjska firma Avia FED Service dostarczyła rodzimemu przemysłowi lotniczemu części o wartości 650 mln rubli w czasie wojny. Większość z nich pochodziła z Ukrainy - wynika z dziennikarskiego śledztwa niezależnego rosyjskiego portalu Ważnyje istorii. Według ustaleń ukraińskie sankcje udawało się obchodzić przez dostawy do spółek zarejestrowanych w Zjednoczonych Emiratach Arabskich i Kirgistanie.

## Pan młody wyciągnął broń na weselu. Żona i teściowa wśród ofiar
 - [https://www.polsatnews.pl/wiadomosc/2023-11-27/pan-mlody-wyciagnal-bron-na-weselu-zona-i-tesciowa-wsrod-ofiar](https://www.polsatnews.pl/wiadomosc/2023-11-27/pan-mlody-wyciagnal-bron-na-weselu-zona-i-tesciowa-wsrod-ofiar)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-11-27T16:08:00+00:00

Były tajlandzki żołnierz urządził strzelaninę na własnym ślubie. 29-latek zabił swoją żonę, teściową i szwagierkę, a następnie odebrał sobie życie. Tragedię miała poprzedzić kłótnia młodej pary.

## Wielka Brytania. Pierwszy przypadek zakażenia A(H1N2)v przez człowieka. "Nowa świńska grypa"
 - [https://www.polsatnews.pl/wiadomosc/2023-11-27/wielka-brytania-pierwszy-przypadek-zakazenia-ah1n2v-przez-czlowieka-nowa-swinska-grypa](https://www.polsatnews.pl/wiadomosc/2023-11-27/wielka-brytania-pierwszy-przypadek-zakazenia-ah1n2v-przez-czlowieka-nowa-swinska-grypa)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-11-27T14:27:00+00:00

Władze w Wielkiej Brytanii poinformowały o pierwszym przypadku zakażenia się szczepem grypy A(H1N2)v przez człowieka. Patogen atakuje świnie i jest podobny do wirusa świńskiej grypy. Trwa dochodzenie, które ma ustalić źródło zakażenia i zapobiec jego rozprzestrzenieniu się.

## Niemiecko-polski spór biskupów. Powodem list do papieża Franciszka
 - [https://www.polsatnews.pl/wiadomosc/2023-11-27/niemiecko-polski-spor-biskupow-papiez-wskazal-zwyciezce](https://www.polsatnews.pl/wiadomosc/2023-11-27/niemiecko-polski-spor-biskupow-papiez-wskazal-zwyciezce)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-11-27T14:14:00+00:00

Przewodniczący Episkopatu Polski wysłał list do papieża Franciszka ws. reform w Kościele w Niemczech. W odpowiedzi szef niemieckiego episkopatu zarzucił abp Stanisławowi Gądeckiemu przekroczenie uprawnień i złośliwe oczernianie. Spór rozstrzygnął ojciec święty, który wyraził zaniepokojenie krokami podjętymi przez niemieckich hierarchów kościelnych.

## USA: Muzeum w ogniu krytyki. Wystawiło choinkę z czerwonymi ozdobami
 - [https://www.polsatnews.pl/wiadomosc/2023-11-27/usa-muzeum-w-ogniu-krytyki-wystawilo-choinke-z-czerwonymi-ozdobami](https://www.polsatnews.pl/wiadomosc/2023-11-27/usa-muzeum-w-ogniu-krytyki-wystawilo-choinke-z-czerwonymi-ozdobami)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-11-27T12:14:00+00:00

Na corocznym Festiwalu Choinek w Narodowym Muzeum Kolejnictwa w stanie Wisconsin pojawiła się choinka, która wywołała falę krytyki wśród polityków i internautów. Republikański kongresman stwierdził, że jest obraźliwa, a dyrektor konserwatywnej organizacji, że dekoracje znajdujące się na drzewku to elementy kultu szatana. Do sprawy odniosło się muzeum.

## Atak zimy w Ukrainie. Dwa tysiące miejscowości bez prądu, zablokowane drogi
 - [https://www.polsatnews.pl/wiadomosc/2023-11-27/ukraina-atak-zimy-dwa-tysiace-miejscowosci-bez-pradu-zablokowane-drogi](https://www.polsatnews.pl/wiadomosc/2023-11-27/ukraina-atak-zimy-dwa-tysiace-miejscowosci-bez-pradu-zablokowane-drogi)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-11-27T11:16:00+00:00

Ponad dwa tysiące miejscowości w kilkunastu regionach Ukrainy zostało odciętych od prądu. Wiele dróg jest zblokowanych. Paraliż jest spowodowany gwałtownym atakiem zimy. Wszystkie nasze służby pracują przez całą dobę - zapewnił prezydent Wołodymyr Zełenski.

## Papież Franciszek musi ograniczyć aktywność. Watykan wydał komunikat ws. jego zdrowia
 - [https://www.polsatnews.pl/wiadomosc/2023-11-27/papiez-franciszek-musi-ograniczyc-aktywnosc-watykan-wydal-komunikat-ws-jego-zdrowia](https://www.polsatnews.pl/wiadomosc/2023-11-27/papiez-franciszek-musi-ograniczyc-aktywnosc-watykan-wydal-komunikat-ws-jego-zdrowia)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-11-27T09:35:00+00:00

Papież Franciszek, który cierpi na zapalenie płuc, jest w dobrym i stabilnym stanie - poinformował w poniedziałek Watykan. Dodano, że papież musi przyjmować antybiotyki i w kolejnych dniach ograniczy działalność.

## WHO zwraca uwagę na nowe zagrożenie w Chinach. Pekin odpowiada
 - [https://www.polsatnews.pl/wiadomosc/2023-11-27/who-zwraca-uwage-na-nowe-zagrozenie-w-chinach-pekin-odpowiada](https://www.polsatnews.pl/wiadomosc/2023-11-27/who-zwraca-uwage-na-nowe-zagrozenie-w-chinach-pekin-odpowiada)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-11-27T09:30:00+00:00

Gwałtowny wzrost zachorowań na choroby układu oddechowego w Chinach nie jest spowodowany pojawieniem się nowego wirusa - przekazało w komunikacie chińskie ministerstwo zdrowia. Kilka dni wcześniej Światowa Organizacja Zdrowia (WHO) zwróciła się do rządu w Pekinie z prośbą o wyjaśnienie sytuacji po tym, jak media odnotowały nadzwyczaj dużą liczbę hospitalizacji w tym kraju.

## Francja. Ojciec zabił trzy córki. Policja szuka matki
 - [https://www.polsatnews.pl/wiadomosc/2023-11-27/francja-ojciec-zabil-trzy-corki-policja-szuka-matki](https://www.polsatnews.pl/wiadomosc/2023-11-27/francja-ojciec-zabil-trzy-corki-policja-szuka-matki)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-11-27T08:29:00+00:00

41-latek zgłosił się w niedzielę do francuskiej policji i przyznał do zamordowania w swoim domu w Alfortville na obrzeżach Paryża trzech córek w wieku 4, 10 i 11 lat. Służby nie wiedzą, gdzie przebywa matka zamordowanych dziewczynek.

## W Rosji obawa przed buntem żon żołnierzy.  "Trzeba je przekupić"
 - [https://www.polsatnews.pl/wiadomosc/2023-11-27/w-rosji-obawa-przed-buntem-zon-zolnierzy-trzeba-je-przekupic](https://www.polsatnews.pl/wiadomosc/2023-11-27/w-rosji-obawa-przed-buntem-zon-zolnierzy-trzeba-je-przekupic)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-11-27T08:18:00+00:00

Na początku listopada w Moskwie odbył się protest żon żołnierzy, które domagały się objęcia swoich bliskich rotacją wojskową i odesłaniem ich z linii frontu. Jak się okazuje, wzbudziło to niepokój Kremla przed nadchodzącymi wyborami prezydenckimi w Rosji. Zdecydowano, że kobiety trzeba przekupić.

## To prawo mogło uratować pięć tysięcy osób rocznie. Rząd Nowej Zelandii się wycofuje
 - [https://www.polsatnews.pl/wiadomosc/2023-11-27/to-prawo-moglo-uratowac-piec-tysiecy-osob-rocznie-rzad-nowej-zelandii-sie-wycofuje](https://www.polsatnews.pl/wiadomosc/2023-11-27/to-prawo-moglo-uratowac-piec-tysiecy-osob-rocznie-rzad-nowej-zelandii-sie-wycofuje)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-11-27T08:04:00+00:00

Rząd Nowej Zelandii wycofa się z prawa wprowadzającego dożywotni zakaz sprzedaży wyrobów tytoniowych dla osób urodzonych po 2008 roku - przekazał w poniedziałek premier Christopher Luxon. Decyzja zaskoczyła ta ekspertów, którzy skrytykowali zmianę polityki.

## Izrael może przedłużyć rozejm z Hamasem. Premier Benjamin Netanjahu podał warunek
 - [https://www.polsatnews.pl/wiadomosc/2023-11-27/izrael-moze-przedluzyc-rozejm-z-hamasem-premier-benjamin-netanjahu-podal-warunek](https://www.polsatnews.pl/wiadomosc/2023-11-27/izrael-moze-przedluzyc-rozejm-z-hamasem-premier-benjamin-netanjahu-podal-warunek)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-11-27T05:38:00+00:00

W niedzielę premier Izraela rozmawiał z prezydentem Stanów Zjednoczonych. - Powiedziałem mu, że obecny czterodniowy rozejm można przedłużyć - relacjonował Benjamin Netanjahu. Dodał, że byłoby to możliwe, gdyby wciąż uwalniano zakładników - za każdy dzień kolejnych 10. Wcześniej gotowość do przedłużenia rozejmu wyraził Hamas.

