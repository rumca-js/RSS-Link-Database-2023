# Source:TVN24 Ze świata, URL:https://tvn24.pl/wiadomosci-ze-swiata,2.xml, language:pl-PL

## Nagły wzrost przypadków chorób płuc, tysiące pacjentów czekających w szpitalach. "Władze twierdzą, że winne są znane patogeny"
 - [https://fakty.tvn24.pl/fakty-o-swiecie/chiny-nagly-wzrost-przypadkow-chorob-pluc-tysiace-pacjentow-czekajacych-w-szpitalach-st7457739?source=rss](https://fakty.tvn24.pl/fakty-o-swiecie/chiny-nagly-wzrost-przypadkow-chorob-pluc-tysiace-pacjentow-czekajacych-w-szpitalach-st7457739?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-11-27T20:55:57+00:00

<img alt="Nagły wzrost przypadków chorób płuc, tysiące pacjentów czekających w szpitalach. " src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-wfb24n-kazimierczak-7457740/alternates/LANDSCAPE_1280" />
    Światowa Organizacja Zdrowia monitoruje sytuację zdrowotną w Chinach. Liczba zachorowań dzieci na infekcję, której objawy przypominają zapalenie płuc, gwałtownie wzrosła. Izby przyjęć w szpitalach są przepełnione, ludzie czekają w kolejkach do lekarzy wiele godzin. Chińskie służby twierdzą, że nie ma mowy o żadnym nowym nieznanym wirusie, który mógłby doprowadzić do pandemii.

