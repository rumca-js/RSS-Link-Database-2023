# Source:CBC | Top Stories News, URL:https://www.cbc.ca/webfeed/rss/rss-topstories, language:en

## Ex-Ontario teacher silenced for views on books gets court OK to proceed with lawsuit against school board
 - [https://www.cbc.ca/news/canada/kitchener-waterloo/carolyn-burjoski-defamation-lawsuit-waterloo-region-school-board-1.7041375?cmp=rss](https://www.cbc.ca/news/canada/kitchener-waterloo/carolyn-burjoski-defamation-lawsuit-waterloo-region-school-board-1.7041375?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-11-27T18:02:11+00:00

<img alt="A woman wearing a blue shirt faces the camera." height="349" src="https://i.cbc.ca/1.6494758.1655744798!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/carolyn-burjoski.jpg" title="Retired teacher Carolyn Burjoski hopes that the Ontario court system will permit her to finish a delegation that was ended early by trustees of the Waterloo Region District School Board." width="620" /><p>A retired teacher who was working at an elementary school when she was ejected from a meeting for speaking on the age appropriateness of certain books can proceed with her defamation case against the Waterloo Region District School Board, an Ontario judge has ruled.</p>

## Going head to head (and foot to foot) in world freestyle football championship
 - [https://www.cbc.ca/news/world/going-head-to-head-and-foot-to-foot-in-world-freestyle-football-championship-1.7041592?cmp=rss](https://www.cbc.ca/news/world/going-head-to-head-and-foot-to-foot-in-world-freestyle-football-championship-1.7041592?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-11-27T17:18:00+00:00

<img alt="" height="349" src="https://thumbnails.cbc.ca/maven_legacy/thumbnails/279/1015/FREESTYLEFOOTBALL.jpg" title="" width="620" /><p>Thirty-two of the top freestyle football athletes from across the globe competed in Nairobi, Kenya's capital, to see who would claim the titles of male and female world champions. Poland's Aguska Mnich won the top prize in the women's bracket, while Erlend Fagerli of Norway was declared the men's champion in his final event as a professional freestyler before retirement, following more than a decade in the acrobatic sport.</p>

## Professor terminated by Christian college was repeatedly accused of sexual harassment
 - [https://www.cbc.ca/news/canada/misconduct-allegations-1.7040902?cmp=rss](https://www.cbc.ca/news/canada/misconduct-allegations-1.7040902?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-11-27T15:54:10+00:00

<img alt="A person is seated in front of a bookshelf." height="349" src="https://i.cbc.ca/1.7041043.1701115838!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/john-stackhouse.jpg" title="John Stackhouse Jr.,was terminated from Crandall University in Moncton, N.B., following an investigation into allegations of inappropriate behaviour." width="620" /><p>A professor who was terminated by a Christian university in Moncton, N.B., was previously investigated at another Christian college in Vancouver because of his alleged conduct toward female staff and students, CBC News has learned.</p>

## Not opening books on Windsor NextStar EV plant is 'injustice' to Canada's skilled trades, House committee told
 - [https://www.cbc.ca/news/canada/windsor/nextstar-battery-manufacturing-electric-vehicle-korean-windsor-1.7040936?cmp=rss](https://www.cbc.ca/news/canada/windsor/nextstar-battery-manufacturing-electric-vehicle-korean-windsor-1.7040936?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-11-27T15:39:13+00:00

<img alt="Drone footage picture of the Stellantis/LG electric battery plant in Windsor, Ont." height="349" src="https://i.cbc.ca/1.6883491.1700506926!/fileImage/httpImage/image.JPG_gen/derivatives/16x9_620/stellantis-windsor-ev-battery-plant-drone-footage-nextstar.JPG" title="The NextStar EV battery plant in Windsor, Ont., is shown under construction in the summer of 2023." width="620" /><p>An emergency committee meeting on Parliament Hill about the NextStar electric vehicle (EV) battery plant in Windsor, Ont., was told Canadians feel as though jobs are being "stolen from their fingertips." The Conservatives are pushing the Liberals, carmaker Stellantis and LG Energy Solution to reveal details of contracts for building the factory, amid backlash over plans to hire some 900 foreign workers.</p>

## 'Absolutely no talk' of moving Paul Bernardo to minimum security, Correctional Services Canada head says
 - [https://www.cbc.ca/news/politics/bernardo-minimum-security-1.7041309?cmp=rss](https://www.cbc.ca/news/politics/bernardo-minimum-security-1.7041309?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-11-27T15:02:07+00:00

<img alt="Convicted killer and serial rapist Paul Bernardo in a courtroom sketch from 2018." height="349" src="https://i.cbc.ca/1.6864083.1685745153!/cpImage/httpImage/image.jpg_gen/derivatives/16x9_620/bernardo-parole-20181030.jpg" title="Paul Bernardo is shown in this courtroom sketch during Ontario court proceedings via video link in Napanee, Ont., on October 5, 2018. Despite being denied parole twice, Correctional Service of Canada confirmed that Bernardo was transferred from a maximum security facility in Ontario to a medium security prison in Quebec. " width="620" /><p>The commissioner of Correctional Service Canada says there is "absolutely no talk" of moving notorious serial killer and rapist Paul Bernardo to an even lower security level following his transfer to a medium-security prison.</p>

## Federal advocate calls Inuit housing conditions a 'staggering failure' of government
 - [https://www.cbc.ca/news/canada/north/inuit-housing-crisis-houle-report-1.7041217?cmp=rss](https://www.cbc.ca/news/canada/north/inuit-housing-crisis-houle-report-1.7041217?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-11-27T14:33:12+00:00

<img alt="A woman with dark hair and glasses, with Canadian flags displayed in the background." height="349" src="https://i.cbc.ca/1.7041245.1701111633!/cpImage/httpImage/image.jpg_gen/derivatives/16x9_620/inuit-housing-crisis-20231127.jpg" title="Federal Housing Advocate Marie-Josee Houle speaks during a news conference on the launch an observational report on the housing crisis in Inuit communities, at the National Press Theatre in Ottawa on Monday, Nov. 27, 2023. " width="620" /><p>A federal housing advocate is accusing every level of government in Canada of failing to uphold the Inuit's right to housing — and therefore denying their human rights.</p>

## U.K. detects first human case of 'distinct' form of swine flu
 - [https://www.cbc.ca/news/health/u-k-swine-flu-human-case-1.7041165?cmp=rss](https://www.cbc.ca/news/health/u-k-swine-flu-human-case-1.7041165?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-11-27T14:13:23+00:00

<img alt="Breeding sows are seen inside a barn on a family run pig farm near Driffield, Britain, October 12, 2021." height="349" src="https://i.cbc.ca/1.6211622.1701110612!/fileImage/httpImage/image.JPG_gen/derivatives/16x9_620/three-pigs-at-a-farm-near-driffield-england.JPG" title="The UK Health Security Agency (UKHSA) has detected a single confirmed human case of influenza A(H1N2)v, one that is &quot;distinct&quot; but similar to viruses currently circulating in pigs." width="620" /><p>Officials are racing to track the contacts of the United Kingdom's first human case of a "distinct" form of swine flu. On Monday, the U.K. Health Security Agency announced it had detected a single confirmed human case of influenza A(H1N2)v as part of routine national flu surveillance.</p>

## Police link suicide of 12-year-old B.C. boy to online sextortion
 - [https://www.cbc.ca/news/canada/british-columbia/bc-prince-george-death-sextortion-1.7041185?cmp=rss](https://www.cbc.ca/news/canada/british-columbia/bc-prince-george-death-sextortion-1.7041185?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-11-27T14:04:55+00:00

<img alt="Man holding a phone" height="349" src="https://i.cbc.ca/1.6921859.1690581092!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/shutterstock-medium-file.jpg" title="Man in black shirt is typing a text message on his smartphone, close up image, focus on hands and the phone device.; Shutterstock ID 132886142; Cost Ctr: 9688225; Manager: Brenda Carroll; Email: brenda.carroll@cbc.ca; Project: archive" width="620" /><p>Police in Prince George, B.C., are warning about the dangers of sexual extortion after the suicide of a 12-year-old boy in their community.</p>

## Police link suicide of 12-year-old B.C. boy to online sextortion
 - [https://www.cbc.ca/news/canada/british-columbia/police-link-suicide-of-12-year-old-b-c-boy-to-online-sextortion-1.7041185?cmp=rss](https://www.cbc.ca/news/canada/british-columbia/police-link-suicide-of-12-year-old-b-c-boy-to-online-sextortion-1.7041185?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-11-27T14:04:55+00:00

<img alt="Photo of a playground in Prince George, B.C." height="349" src="https://i.cbc.ca/1.7041618.1701125226!/fileImage/httpImage/image.JPG_gen/derivatives/16x9_620/prince-george-playground.JPG" title="A school playground in Prince George, B.C., is pictured. A 12-year-old boy in Prince George, B.C., died by suicide in October after being a victim of online sextortion, RCMP have determined. (i" width="620" /><p>Police in Prince George, B.C., are warning about the dangers of sexual extortion after the suicide of a 12-year-old boy in their community.</p>

## 60 Ontario jail staff were alerted about Soleiman Faqiri's state. Still, he wasn't sent to hospital
 - [https://www.cbc.ca/news/canada/toronto/faqiri-inquest-day-6-1.7041186?cmp=rss](https://www.cbc.ca/news/canada/toronto/faqiri-inquest-day-6-1.7041186?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-11-27T13:58:30+00:00

<img alt="A picture of a man smiling at the camera, pasted on paper on top of a stick. Flowers are seen on top of the photo.Soleiman Faqiri was born on New Year&apos;s Day in Kabul, Afghanistan, in 1986 and came to Canada in 1993. According to his family, he was a straight-A student, captain of his high school rugby team and had a close and loving relationship with his four siblings and parents. " height="349" src="https://i.cbc.ca/1.4983951.1700781845!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/soleiman-faqiri.jpg" title="Soleiman Faqiri was born on New Year&apos;s Day in Kabul, Afghanistan, in 1986 and came to Canada in 1993. According to his family, he was a straight-A student, captain of his high school rugby team and had a close and loving relationship with his four siblings and parents. " width="620" /><p>In the days before Soleiman Faqiri's death, an operational manager at the Lindsay, Ont., jail sent a note to some 60 corrections staff alerting them about his cond

## Winnipeg police to give update on Langside shooting that killed 4
 - [https://www.cbc.ca/news/canada/manitoba/langside-fatal-shooting-update-1.7041137?cmp=rss](https://www.cbc.ca/news/canada/manitoba/langside-fatal-shooting-update-1.7041137?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-11-27T13:13:00+00:00

<img alt="A large white van with the words &apos;forensics&apos; and &apos;police&apos; on the side can be seen parked outside a blue and tan house. " height="349" src="https://i.cbc.ca/1.7041143.1701108571!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/langside-shooting-investigation.jpg" title="A forensics unit van and police officers remain Monday morning at the site of a deadly mass shooting in Winnipeg&apos;s West Broadway neighbourhood. " width="620" /><p>Winnipeg police will give an update this afternoon on their investigation into a mass shooting in the West Broadway area that left four people dead.</p>

## 5 dead, 2 injured in weekend crashes across B.C.'s South Coast
 - [https://www.cbc.ca/news/canada/british-columbia/5-dead-fatal-crashes-bc-chilliwack-surrey-whistler-nov-26-27-1.7041108?cmp=rss](https://www.cbc.ca/news/canada/british-columbia/5-dead-fatal-crashes-bc-chilliwack-surrey-whistler-nov-26-27-1.7041108?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-11-27T13:11:24+00:00

<img alt="A black car is severely damadged on the left side, the airbags can be seen deployed. " height="349" src="https://i.cbc.ca/1.7040731.1701046439!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/fatal-collision.jpg" title="The driver of the black Toyota Corolla, pictured above, fled the scene on foot, according to Surrey RCMP. " width="620" /><p>It was a deadly weekend on the roads of B.C.'s South Coast, with crashes in Chilliwack, Surrey and Whistler causing five fatalities — including a child — and sending another two people to hospital.</p>

## Trudeau offended Israel with call for 'maximum restraint,' says Israeli president
 - [https://www.cbc.ca/news/politics/herzog-says-trudeau-offended-israel-1.7041040?cmp=rss](https://www.cbc.ca/news/politics/herzog-says-trudeau-offended-israel-1.7041040?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-11-27T12:07:31+00:00

<img alt="Issac Herzog, a white male wearing a suit, speaks from a podium. " height="349" src="https://i.cbc.ca/1.7041048.1701103268!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/austria-israel.jpg" title="Israel&apos;s President, Isaac Herzog, adresses the media at a press statement in Vienna, Austria, Tuesday, Sept. 5, 2023." width="620" /><p>Israeli President Isaac Herzog said Prime Minister Justin Trudeau offended his country earlier this month when he asked Israel to exercise “maximum restraint” in military operations in Gaza.</p>

## Alberta women's shelters strained 'far past their limits' to meet rising need, report says
 - [https://www.cbc.ca/news/canada/edmonton/alberta-women-s-shelters-strained-far-past-their-limits-to-meet-rising-need-report-says-1.7039120?cmp=rss](https://www.cbc.ca/news/canada/edmonton/alberta-women-s-shelters-strained-far-past-their-limits-to-meet-rising-need-report-says-1.7039120?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-11-27T12:00:59+00:00

<img alt="The outline of a person at a window, with their hand on the curtain, seen from the outside of the window." height="349" src="https://i.cbc.ca/1.5217430.1696965946!/cumulusImage/httpImage/image.jpg_gen/derivatives/16x9_620/domestic-violence-image.jpg" title="Toronto&apos;s rent crisis is particularly impactful for women escaping domestic violence and need affordable housing options. " width="620" /><p>The Alberta Council of Women's Shelters says the number of people who stayed in a shelter after fleeing abuse is up 19 per cent, but cases where agencies had to deny shelter requests for lack of space have also increased 32 per cent.</p>

## 104-year-old Saskatoon WWII veteran spends birthday giving upright bass performance
 - [https://www.cbc.ca/news/canada/saskatchewan/veteran-birthday-1.7040908?cmp=rss](https://www.cbc.ca/news/canada/saskatchewan/veteran-birthday-1.7040908?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-11-27T11:54:20+00:00

<img alt="Older bald man with tattoo on his forearm plays a dark brown stand up bass. " height="349" src="https://i.cbc.ca/1.7040947.1701101922!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/liam-o-connor.jpg" title="Nick Kazuska plays the stand-up bass at his birthday party. " width="620" /><p>Friends, family and bandmates squeezed into the Preston Park Retirement Residence chapel to live-up Nick Kazuska's milestone.</p>

## COP28 host used climate talks to push for oilpatch deals, including in Canada
 - [https://www.cbc.ca/news/world/bakx-cop28-oilpatch-al-jaber-dubai-1.7040913?cmp=rss](https://www.cbc.ca/news/world/bakx-cop28-oilpatch-al-jaber-dubai-1.7040913?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-11-27T11:06:56+00:00

<img alt="A smiling man in glasses and a white headdress. " height="349" src="https://i.cbc.ca/1.6871906.1686343828!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/1253497389.jpg" title="Sultan al-Jaber, chief executive of the UAE&apos;s Abu Dhabi National Oil Company (ADNOC) and president of this year&apos;s COP28 climate, attends the &quot;UAE Climate Tech&quot; conference at Abu Dhabi Energy centre, on May 10, 2023. (Photo by Karim SAHIB / AFP) (Photo by KARIM SAHIB/AFP via Getty Images)" width="620" /><p>Allegations are being raised about COP28 president Sultan al-Jaber and his willingness to use climate meetings with foreign governments to make oil and gas deals, including with Canada.</p>

## Paris mayor quitting Elon Musk's 'global sewer' platform X before 2024 Olympics
 - [https://www.cbc.ca/sports/olympics/summer/anne-hidalgo-paris-mayor-quitting-x-olympics-1.7040900?cmp=rss](https://www.cbc.ca/sports/olympics/summer/anne-hidalgo-paris-mayor-quitting-x-olympics-1.7040900?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-11-27T10:23:24+00:00

<img alt="Paris mayor, sporting long black hair and red lipstick, stands at podium addressing reporters." height="349" src="https://i.cbc.ca/1.7040928.1701098437!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/hidalgo-anne-231121-1180.jpg" title="Paris Mayor Anne Hidalgo says life on X, the platform previously known as Twitter, is the exact opposite of democratic life. &quot;I refuse to endorse this evil scheme,&quot; Hidalgo says, adding she will close her account at the end of this week. " width="620" /><p>The mayor of future Olympic host city Paris says she is quitting X, accusing Elon Musk's platform previously known as Twitter of spreading disinformation and hatred and of becoming a "gigantic global sewer" that is toxic for democracy and constructive debate.</p>

## 'Authentic' named Merriam-Webster's 2023 word of the year
 - [https://www.cbc.ca/news/world/merriam-webster-word-year-2023-authentic-1.7040829?cmp=rss](https://www.cbc.ca/news/world/merriam-webster-word-year-2023-authentic-1.7040829?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-11-27T09:22:10+00:00

<img alt="A red Merriam-Webster dictionary sits on top of a drawer in a file cabinet." height="349" src="https://i.cbc.ca/1.7040841.1701092952!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/merriam-webster-word-of-the-year.jpg" title="FILE - A Merriam-Webster dictionary sits atop their citation files at the dictionary publisher&apos;s offices on Dec. 9, 2014, in Springfield, Mass. Merriam-Webster&apos;s word of the year for 2023 is “authentic.” " width="620" /><p>In an age of deepfakes and post-truth, as artificial intelligence rose and Elon Musk turned Twitter into X, the Merriam-Webster word of the year for 2023 is "authentic."</p>

## Arrest made in U.S. shooting of 3 college students of Palestinian descent
 - [https://www.cbc.ca/news/world/palestinians-students-shot-vermont-1.7040774?cmp=rss](https://www.cbc.ca/news/world/palestinians-students-shot-vermont-1.7040774?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-11-27T06:52:52+00:00

<img alt="Four armed police offices stand on a home&apos;s porch at the front door." height="349" src="https://i.cbc.ca/1.7040776.1701070364!/fileImage/httpImage/image.JPG_gen/derivatives/16x9_620/vermont-shooting.JPG" title="Police search a house in the neighbourhood after a gunman shot and wounded three college students of Palestinian descent in Burlington, Vermont, U.S. November 25, 2023 in a still image from video.  Courtesy Wayne Savage via REUTERS.   THIS IMAGE HAS BEEN SUPPLIED BY A THIRD PARTY. MANDATORY CREDIT" width="620" /><p>Police have arrested a suspect in the shooting of three young men of Palestinian descent who were attending a Thanksgiving holiday gathering near the University of Vermont campus. The 48-year-old suspect is scheduled to be arraigned on Monday.</p>

## Israel's Arab neighbours want to see Hamas gone, but spurn role in governing Gaza afterward
 - [https://www.cbc.ca/news/world/israels-arab-neighbours-1.7040540?cmp=rss](https://www.cbc.ca/news/world/israels-arab-neighbours-1.7040540?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-11-27T04:00:40+00:00

<img alt="A wide view of a street with debris items strewn across between buildings with a number of people walking in the distance." height="349" src="https://i.cbc.ca/1.7040044.1700877749!/cpImage/httpImage/image.jpg_gen/derivatives/16x9_620/palestinians-khan-younis-gaza-truce-day.jpg" title="Palestinians inspect their destroyed houses in the town of Kazaa, eastern Khan Younis, southern Gaza Strip, Friday, Nov. 24, 2023, as the four-day cease-fire in the Israel-Hamas war begins as part of an agreement that Qatar helped broker." width="620" /><p>Arab and Islamic foreign ministers have been touring global capitals pushing for an end to the war in Gaza. CBC News was invited to a private briefing to hear their solutions. None of the outcomes involve having their nations establish a presence in Gaza when the fighting ends.</p>

