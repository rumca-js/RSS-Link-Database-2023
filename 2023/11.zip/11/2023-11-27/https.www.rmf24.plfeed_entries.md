# Source:RMF24.pl, URL:https://www.rmf24.pl/feed, language:pl

## Cristiano Ronaldo się przyznał. Rzut karny przepadł
 - [https://www.rmf24.pl/sport/pilka-nozna/news-cristiano-ronaldo-sie-przyznal-rzut-karny-przepadl,nId,7175329](https://www.rmf24.pl/sport/pilka-nozna/news-cristiano-ronaldo-sie-przyznal-rzut-karny-przepadl,nId,7175329)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T22:34:34+00:00

<p><a href="https://www.rmf24.pl/sport/pilka-nozna/news-cristiano-ronaldo-sie-przyznal-rzut-karny-przepadl,nId,7175329"><img align="left" alt="Cristiano Ronaldo się przyznał. Rzut karny przepadł" src="https://interia-s.pluscdn.pl/cristiano-ronaldo-sie-przyznal-rzut-karny-przepadl/000I3MU3C3FXFDJO-C307.jpg" /></a>Cristiano Ronaldo padł na polu karnym, sędzia wskazał na 11 metr i wszystko wskazywało na to, że słynny Portugalczyk zamieni tę sytuację na bramkę dla swojej saudyjskiej drużyny. Wtedy zupełnie nieoczekiwanie Ronaldo powiedział arbitrowi, co się naprawdę wydarzyło.</p><br clear="all" />

## Hamas uwolnił kolejnych izraelskich zakładników
 - [https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-hamas-uwolnil-kolejnych-izraelskich-zakladnikow,nId,7175313](https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-hamas-uwolnil-kolejnych-izraelskich-zakladnikow,nId,7175313)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T21:55:46+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-hamas-uwolnil-kolejnych-izraelskich-zakladnikow,nId,7175313"><img align="left" alt="Hamas uwolnił kolejnych izraelskich zakładników" src="https://interia-s.pluscdn.pl/hamas-uwolnil-kolejnych-izraelskich-zakladnikow/000I3MS35RCHCAFC-C307.jpg" /></a>Kolejnych 11 izraelskich zakładników, uprowadzonych przez Hamas do Strefy Gazy w trakcie ataku z 7 października, zostało uwolnionych przez Palestyńczyków.</p><br clear="all" />

## Śmiertelna ofiara pożaru kamienicy w Zabrzu
 - [https://www.rmf24.pl/regiony/slaskie/news-smiertelna-ofiara-pozaru-kamienicy-w-zabrzu,nId,7175311](https://www.rmf24.pl/regiony/slaskie/news-smiertelna-ofiara-pozaru-kamienicy-w-zabrzu,nId,7175311)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T21:28:10+00:00

<p><a href="https://www.rmf24.pl/regiony/slaskie/news-smiertelna-ofiara-pozaru-kamienicy-w-zabrzu,nId,7175311"><img align="left" alt="Śmiertelna ofiara pożaru kamienicy w Zabrzu" src="https://interia-s.pluscdn.pl/smiertelna-ofiara-pozaru-kamienicy-w-zabrzu/000I3MPAYDWHNT8O-C307.jpg" /></a>W pożarze, który późnym popołudniem w poniedziałek wybuchł na poddaszu kamienicy przy ul. Księdza Knosały w Zabrzu, zginęła jedna osoba. Po ugaszeniu ognia strażacy znaleźkli w pogorzelisku nadpalone ciało. </p><br clear="all" />

## Zasłabł kierowca autobusu wiozącego dzieci. Interweniowały służby
 - [https://www.rmf24.pl/regiony/warszawa/news-zaslabl-kierowca-autobusu-wiozacego-dzieci-interweniowaly-sl,nId,7175304](https://www.rmf24.pl/regiony/warszawa/news-zaslabl-kierowca-autobusu-wiozacego-dzieci-interweniowaly-sl,nId,7175304)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T20:50:42+00:00

<p><a href="https://www.rmf24.pl/regiony/warszawa/news-zaslabl-kierowca-autobusu-wiozacego-dzieci-interweniowaly-sl,nId,7175304"><img align="left" alt="Zasłabł kierowca autobusu wiozącego dzieci. Interweniowały służby" src="https://interia-s.pluscdn.pl/zaslabl-kierowca-autobusu-wiozacego-dzieci-interweniowaly-sl/000I3MK8D10WJ1JK-C307.jpg" /></a>Kierowca autobusu przewożącego dzieci zasłabł i zjechał z drogi - tak wynika ze wstępnych ustaleń mundurowych, o których powiedziała podkom. Małgorzata Wersocka z Komendy Stołecznej Policji. Dodała, że dzieci są bezpieczne, a podróż będzie kontynuowana z drugim kierowcą.</p><br clear="all" />

## Dwie awarie w EC Będzin. Wznowienie dostaw ciepła w końcu tygodnia
 - [https://www.rmf24.pl/regiony/slaskie/news-dwie-awarie-w-ec-bedzin-wznowienie-dostaw-ciepla-w-koncu-tyg,nId,7175281](https://www.rmf24.pl/regiony/slaskie/news-dwie-awarie-w-ec-bedzin-wznowienie-dostaw-ciepla-w-koncu-tyg,nId,7175281)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T19:50:58+00:00

<p><a href="https://www.rmf24.pl/regiony/slaskie/news-dwie-awarie-w-ec-bedzin-wznowienie-dostaw-ciepla-w-koncu-tyg,nId,7175281"><img align="left" alt="Dwie awarie w EC Będzin. Wznowienie dostaw ciepła w końcu tygodnia" src="https://interia-s.pluscdn.pl/dwie-awarie-w-ec-bedzin-wznowienie-dostaw-ciepla-w-koncu-tyg/000I3MDIBRW9K3RL-C307.jpg" /></a>W Elektrociepłowni Będzin, wytwarzającej ciepło dla mieszkańców Sosnowca, Będzina i Czeladzi, doszło do awarii kotła parowego, a dzień wcześniej - do awarii wymiennika ciepła. Trwają prace naprawcze. Wznowienie dostaw ciepła ma nastąpić w końcu tego tygodnia - wynika z informacji firmy.</p><br clear="all" />

## Potrącenie trzech kobiet w Wieluniu. Zostały zabrane do szpitala
 - [https://www.rmf24.pl/regiony/lodz/news-potracenie-trzech-kobiet-w-wieluniu-zostaly-zabrane-do-szpit,nId,7175285](https://www.rmf24.pl/regiony/lodz/news-potracenie-trzech-kobiet-w-wieluniu-zostaly-zabrane-do-szpit,nId,7175285)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T19:50:34+00:00

<p><a href="https://www.rmf24.pl/regiony/lodz/news-potracenie-trzech-kobiet-w-wieluniu-zostaly-zabrane-do-szpit,nId,7175285"><img align="left" alt="Potrącenie trzech kobiet w Wieluniu. Zostały zabrane do szpitala" src="https://interia-s.pluscdn.pl/potracenie-trzech-kobiet-w-wieluniu-zostaly-zabrane-do-szpit/000I3MIUYNE36LK3-C307.jpg" /></a>​Trzy kobiety zostały potrącone na przejściu dla pieszych w Wieluniu w Łódzkiem. Na miejsce wezwano helikopter Lotniczego Pogotowia Ratunkowego.</p><br clear="all" />

## Monika Horna-Cieślak z poparciem komisji sejmowych na Rzecznika Praw Dziecka
 - [https://www.rmf24.pl/polityka/news-monika-horna-cieslak-z-poparciem-komisji-sejmowych-na-rzeczn,nId,7175290](https://www.rmf24.pl/polityka/news-monika-horna-cieslak-z-poparciem-komisji-sejmowych-na-rzeczn,nId,7175290)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T19:44:07+00:00

<p><a href="https://www.rmf24.pl/polityka/news-monika-horna-cieslak-z-poparciem-komisji-sejmowych-na-rzeczn,nId,7175290"><img align="left" alt="Monika Horna-Cieślak z poparciem komisji sejmowych na Rzecznika Praw Dziecka" src="https://interia-s.pluscdn.pl/monika-horna-cieslak-z-poparciem-komisji-sejmowych-na-rzeczn/000I3MF59K66C70F-C307.jpg" /></a>Monika Horna-Cieślak otrzymała poparcie komisji sejmowych na stanowisko Rzecznika Praw Dziecka. Jest jedyną kandydatką do tej funkcji. Została zgłoszona przez KO, Lewicę, PSL-TD i Polskę 2050-TD.</p><br clear="all" />

## Monika Horny-Cieślak z poparciem komisji sejmowych na Rzecznika Praw Dziecka
 - [https://www.rmf24.pl/polityka/news-monika-horny-cieslak-z-poparciem-komisji-sejmowych-na-rzeczn,nId,7175290](https://www.rmf24.pl/polityka/news-monika-horny-cieslak-z-poparciem-komisji-sejmowych-na-rzeczn,nId,7175290)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T19:44:07+00:00

<p><a href="https://www.rmf24.pl/polityka/news-monika-horny-cieslak-z-poparciem-komisji-sejmowych-na-rzeczn,nId,7175290"><img align="left" alt="Monika Horny-Cieślak z poparciem komisji sejmowych na Rzecznika Praw Dziecka" src="https://interia-s.pluscdn.pl/monika-horny-cieslak-z-poparciem-komisji-sejmowych-na-rzeczn/000I3MF59K66C70F-C307.jpg" /></a>Moika Horny-Cieślak otrzymała poparcie komisji sejmowych na stanowisko Rzecznika Praw Dziecka. Jest jedyną kandydatką do tej funkcji. Została zgłoszona przez KO, Lewicę, PSL-TD i Polskę 2050.</p><br clear="all" />

## ​Jan Grabiec gościem Rozmowy o 7:00 w RMF FM i Radiu RMF24
 - [https://www.rmf24.pl/tylko-w-rmf24/rozmowa-o-7/news-jan-grabiec-gosciem-rozmowy-o-7-00-w-rmf-fm-i-radiu-rmf24,nId,7175279](https://www.rmf24.pl/tylko-w-rmf24/rozmowa-o-7/news-jan-grabiec-gosciem-rozmowy-o-7-00-w-rmf-fm-i-radiu-rmf24,nId,7175279)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T19:33:08+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/rozmowa-o-7/news-jan-grabiec-gosciem-rozmowy-o-7-00-w-rmf-fm-i-radiu-rmf24,nId,7175279"><img align="left" alt="​Jan Grabiec gościem Rozmowy o 7:00 w RMF FM i Radiu RMF24" src="https://interia-s.pluscdn.pl/jan-grabiec-gosciem-rozmowy-o-7-00-w-rmf-fm-i-radiu-rmf24/000I3MCMVQ10VFH5-C307.jpg" /></a>Gościem Tomasza Weryńskiego w Rozmowie o 7:00 w RMF FM i Radiu RMF24 będzie poseł Koalicji Obywatelskiej, rzecznik prasowy PO Jan Grabiec. Porozmawiamy m.in. o nowym rządzie Mateusza Morawieckiego, który został zaprzysiężony, a także o tym gabinecie, który zapewne stworzy Donald Tusk.</p><br clear="all" />

## Wyciek danych medycznych. Spółka ALAB wydała komunikat
 - [https://www.rmf24.pl/fakty/polska/news-wyciek-danych-medycznych-spolka-alab-wydala-komunikat,nId,7175272](https://www.rmf24.pl/fakty/polska/news-wyciek-danych-medycznych-spolka-alab-wydala-komunikat,nId,7175272)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T19:16:49+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-wyciek-danych-medycznych-spolka-alab-wydala-komunikat,nId,7175272"><img align="left" alt="Wyciek danych medycznych. Spółka ALAB wydała komunikat" src="https://interia-s.pluscdn.pl/wyciek-danych-medycznych-spolka-alab-wydala-komunikat/000I3M9ZO7WX1DQM-C307.jpg" /></a>Incydent naruszenia danych osobowych w sieci ALAB Laboratoria, która zajmuje się wykonywaniem badań medycznych. Z wydanego dzisiaj wieczorem komunikatu wynika, że 19 listopada zaobserwowano próbę zmasowanego ataku na serwery spółki. Jak poinformowano, w efekcie &quot;dostęp do danych części pacjentów (...) mogły uzyskać osoby nieuprawnione&quot;. Wcześniej serwis Zaufana Trzecia Strona informował, że do internetu trafiło ponad 50 tys. wyników badań medycznych.</p><br clear="all" />

## Aktorka, szpadzistka. Niespodzianki w nowym rządzie Morawieckiego
 - [https://www.rmf24.pl/polityka/news-aktorka-szpadzistka-niespodzianki-w-nowym-rzadzie-morawiecki,nId,7175257](https://www.rmf24.pl/polityka/news-aktorka-szpadzistka-niespodzianki-w-nowym-rzadzie-morawiecki,nId,7175257)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T18:47:00+00:00

<p><a href="https://www.rmf24.pl/polityka/news-aktorka-szpadzistka-niespodzianki-w-nowym-rzadzie-morawiecki,nId,7175257"><img align="left" alt="Aktorka, szpadzistka. Niespodzianki w nowym rządzie Morawieckiego" src="https://interia-s.pluscdn.pl/aktorka-szpadzistka-niespodzianki-w-nowym-rzadzie-morawiecki/000I3M37S8THXAL5-C307.jpg" /></a>W Pałacu Prezydenckim zaprzysiężony został nowy rząd powołany przez Mateusza Morawieckiego. W jego składzie są niespodzianki. Szefową Ministerstwa Kultury i Dziedzictwa Narodowego została Dominika Chorosińska - aktorka znana z serialu &quot;M jak miłość&quot;. Była szpadzistka, mistrzyni Europy i świata Danuta Dmowska-Andrzejuk pokieruje natomiast pracami resortu sportu i turystyki.</p><br clear="all" />

## "Miotła" w strukturach PiS. Zamiast 94 pełnomocników okręgów, jest 17
 - [https://www.rmf24.pl/polityka/news-miotla-w-strukturach-pis-zamiast-94-pelnomocnikow-okregow-je,nId,7175256](https://www.rmf24.pl/polityka/news-miotla-w-strukturach-pis-zamiast-94-pelnomocnikow-okregow-je,nId,7175256)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T18:26:09+00:00

<p><a href="https://www.rmf24.pl/polityka/news-miotla-w-strukturach-pis-zamiast-94-pelnomocnikow-okregow-je,nId,7175256"><img align="left" alt="&quot;Miotła&quot; w strukturach PiS. Zamiast 94 pełnomocników okręgów, jest 17" src="https://interia-s.pluscdn.pl/miotla-w-strukturach-pis-zamiast-94-pelnomocnikow-okregow-je/000I3MANA1COCNAF-C307.jpg" /></a>Duże zmiany w strukturach Prawa i Sprawiedliwości. Dotychczas istniejące 100 okręgów w partii zarządzanych przez 94 pełnomocników zostało zastąpione przez 17 okręgów - na ich czele stanie taka sama liczba szefów.</p><br clear="all" />

## Duda: Patrzę z radością na premiera, na ministrów
 - [https://www.rmf24.pl/polityka/news-duda-patrze-z-radoscia-na-premiera-na-ministrow,nId,7175072](https://www.rmf24.pl/polityka/news-duda-patrze-z-radoscia-na-premiera-na-ministrow,nId,7175072)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T17:17:01+00:00

<p><a href="https://www.rmf24.pl/polityka/news-duda-patrze-z-radoscia-na-premiera-na-ministrow,nId,7175072"><img align="left" alt="Duda: Patrzę z radością na premiera, na ministrów" src="https://interia-s.pluscdn.pl/duda-patrze-z-radoscia-na-premiera-na-ministrow/000I3LQM0JQ4EKR5-C307.jpg" /></a>&quot;Przed rządem czas wielkich wyzwań, które powinny być podjęte przez ludzi energicznych, dynamicznych, którzy młodymi oczyma patrzą na rzeczywistość, nie boją się podejmować wyzwań, a jednocześnie mają doświadczenie&quot; - powiedział prezydent Andrzej Duda podczas zaprzysiężenia nowego rządu. Wymienił on m.in. sytuację geopolityczną, w tym wojnę na Ukrainie, zmiany traktatów UE i transformację energetyczną.</p><br clear="all" />

## "Osiągnięto porozumienie". Katar o przedłużeniu rozejmu między Izraelem a Hamasem
 - [https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-osiagnieto-porozumienie-katar-o-przedluzeniu-rozejmu-miedzy-,nId,7175147](https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-osiagnieto-porozumienie-katar-o-przedluzeniu-rozejmu-miedzy-,nId,7175147)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T17:03:46+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-osiagnieto-porozumienie-katar-o-przedluzeniu-rozejmu-miedzy-,nId,7175147"><img align="left" alt="&quot;Osiągnięto porozumienie&quot;. Katar o przedłużeniu rozejmu między Izraelem a Hamasem" src="https://interia-s.pluscdn.pl/osiagnieto-porozumienie-katar-o-przedluzeniu-rozejmu-miedzy/000I3LNA3O6RFUX7-C307.jpg" /></a>Ministerstwo spraw zagranicznych Kataru poinformowało, że zawieszenie broni między Izraelem a Hamasem zostało przedłużone o dwa dni. Katar wraz z Egiptem i USA pełni rolę mediatorów w negocjacjach pokojowych.</p><br clear="all" />

## Kobosko o rządzie Morawieckiego: To jest żart wobec Polek i Polaków
 - [https://www.rmf24.pl/tylko-w-rmf24/popoludniowa-rozmowa/news-kobosko-o-rzadzie-morawieckiego-to-jest-zart-wobec-polek-i-p,nId,7174982](https://www.rmf24.pl/tylko-w-rmf24/popoludniowa-rozmowa/news-kobosko-o-rzadzie-morawieckiego-to-jest-zart-wobec-polek-i-p,nId,7174982)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T17:02:00+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/popoludniowa-rozmowa/news-kobosko-o-rzadzie-morawieckiego-to-jest-zart-wobec-polek-i-p,nId,7174982"><img align="left" alt="Kobosko o rządzie Morawieckiego: To jest żart wobec Polek i Polaków" src="https://interia-s.pluscdn.pl/kobosko-o-rzadzie-morawieckiego-to-jest-zart-wobec-polek-i-p/000I3K52Q4A4QDN8-C307.jpg" /></a>Dziś został powołany rząd na chwilę, rząd, który jest niestety żartem – komentował w Popołudniowej rozmowie w RMF FM poseł Michał Kobosko. Mówiąc o gabinecie, który zamierza skonstruować Donald Tusk, polityk Polski 2050 zapewnił, że jego partia będzie w nim reprezentowana przez kobiety. Kobosko przekazał także, że nie znajdzie się w składzie ekipy rządowej Tuska.</p><br clear="all" />

## Michał Kobosko gościem Popołudniowej rozmowy w RMF FM
 - [https://www.rmf24.pl/tylko-w-rmf24/popoludniowa-rozmowa/news-michal-kobosko-gosciem-popoludniowej-rozmowy-w-rmf-fm,nId,7174982](https://www.rmf24.pl/tylko-w-rmf24/popoludniowa-rozmowa/news-michal-kobosko-gosciem-popoludniowej-rozmowy-w-rmf-fm,nId,7174982)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T16:40:26+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/popoludniowa-rozmowa/news-michal-kobosko-gosciem-popoludniowej-rozmowy-w-rmf-fm,nId,7174982"><img align="left" alt="Michał Kobosko gościem Popołudniowej rozmowy w RMF FM" src="https://interia-s.pluscdn.pl/michal-kobosko-gosciem-popoludniowej-rozmowy-w-rmf-fm/000I3K52Q4A4QDN8-C307.jpg" /></a>Z gościem Popołudniowej rozmowy w RMF FM Michałem Koboską z Polski 2050 Tomasz Terlikowski porozmawia o nowym rządzie Mateusza Morawieckiego. Naszego gościa zapytamy, czy nowa większość sejmowa ma pewność, że nie uzyska poparcia, a także o czekający już w kolejce nowy rząd i o to, czy Michał Kobosko wejdzie w skład gabinetu Donalda Tuska.</p><br clear="all" />

## Nowy rząd Morawieckiego. Są nazwiska ministrów
 - [https://www.rmf24.pl/polityka/news-nowy-rzad-morawieckiego-sa-nazwiska-ministrow,nId,7175019](https://www.rmf24.pl/polityka/news-nowy-rzad-morawieckiego-sa-nazwiska-ministrow,nId,7175019)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T14:58:32+00:00

<p><a href="https://www.rmf24.pl/polityka/news-nowy-rzad-morawieckiego-sa-nazwiska-ministrow,nId,7175019"><img align="left" alt="Nowy rząd Morawieckiego. Są nazwiska ministrów" src="https://interia-s.pluscdn.pl/nowy-rzad-morawieckiego-sa-nazwiska-ministrow/000I3KVKNT3YNF4C-C307.jpg" /></a>Mariusz Błaszczak pozostanie szefem MON w nowym rządzie Mateusza Morawieckiego. Marlena Maląg zostanie nową minister rozwoju i technologii, Szymon Szynkowski vel Sęk będzie szefem MSZ, a pracami resortu sprawiedliwości pokieruje Marcin Warchoł. O godz. 16:30 prezydent Andrzej Duda dokona zaprzysiężenia nowego rządu.</p><br clear="all" />

## Tragedia na weselu. Pan młody zastrzelił cztery osoby, w tym pannę młodą
 - [https://www.rmf24.pl/fakty/swiat/news-tragedia-na-weselu-pan-mlody-zastrzelil-cztery-osoby-w-tym-p,nId,7175012](https://www.rmf24.pl/fakty/swiat/news-tragedia-na-weselu-pan-mlody-zastrzelil-cztery-osoby-w-tym-p,nId,7175012)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T14:54:03+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-tragedia-na-weselu-pan-mlody-zastrzelil-cztery-osoby-w-tym-p,nId,7175012"><img align="left" alt="Tragedia na weselu. Pan młody zastrzelił cztery osoby, w tym pannę młodą " src="https://interia-s.pluscdn.pl/tragedia-na-weselu-pan-mlody-zastrzelil-cztery-osoby-w-tym-p/000I3KUWH31WGKIU-C307.jpg" /></a>Tragedia podczas wesela w Tajlandii. Pan młody zastrzelił swoją narzeczoną i trzy inne osoby, a następnie popełnił samobójstwo.</p><br clear="all" />

## Zderzenie autobusu z samochodem w Warszawie
 - [https://www.rmf24.pl/regiony/warszawa/news-zderzenie-autobusu-z-samochodem-w-warszawie,nId,7175005](https://www.rmf24.pl/regiony/warszawa/news-zderzenie-autobusu-z-samochodem-w-warszawie,nId,7175005)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T14:44:00+00:00

<p><a href="https://www.rmf24.pl/regiony/warszawa/news-zderzenie-autobusu-z-samochodem-w-warszawie,nId,7175005"><img align="left" alt="Zderzenie autobusu z samochodem w Warszawie" src="https://interia-s.pluscdn.pl/zderzenie-autobusu-z-samochodem-w-warszawie/000I3KUOHYE38WWT-C307.jpg" /></a>Poważny wypadek na Trasie Łazienkowskiej w Warszawie. Na skrzyżowaniu ul. Międzynarodowej i al. Stanów Zjednoczonych miejski autobus zderzył się z autem przewozu osób.</p><br clear="all" />

## Zderzenie autobusu z samochodem w Warszawie. Jedna osoba w szpitalu
 - [https://www.rmf24.pl/regiony/warszawa/news-zderzenie-autobusu-z-samochodem-w-warszawie-jedna-osoba-w-sz,nId,7175005](https://www.rmf24.pl/regiony/warszawa/news-zderzenie-autobusu-z-samochodem-w-warszawie-jedna-osoba-w-sz,nId,7175005)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T14:44:00+00:00

<p><a href="https://www.rmf24.pl/regiony/warszawa/news-zderzenie-autobusu-z-samochodem-w-warszawie-jedna-osoba-w-sz,nId,7175005"><img align="left" alt="Zderzenie autobusu z samochodem w Warszawie. Jedna osoba w szpitalu" src="https://interia-s.pluscdn.pl/zderzenie-autobusu-z-samochodem-w-warszawie-jedna-osoba-w-sz/000I3KUOHYE38WWT-C307.jpg" /></a>Poważny wypadek na Trasie Łazienkowskiej w Warszawie - na skrzyżowaniu ul. Międzynarodowej i al. Stanów Zjednoczonych miejski autobus zderzył się z autem przewozu osób. Kierowa auta osobowego był reanimowany i trafił do szpitala - powiedziała podkom. Małgorzata Wersocka z Komendy Stołecznej Policji.</p><br clear="all" />

## Zderzenie autobusu z samochodem w Warszawie. Kierowca jest reanimowany
 - [https://www.rmf24.pl/regiony/warszawa/news-zderzenie-autobusu-z-samochodem-w-warszawie-kierowca-jest-re,nId,7175005](https://www.rmf24.pl/regiony/warszawa/news-zderzenie-autobusu-z-samochodem-w-warszawie-kierowca-jest-re,nId,7175005)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T14:44:00+00:00

<p><a href="https://www.rmf24.pl/regiony/warszawa/news-zderzenie-autobusu-z-samochodem-w-warszawie-kierowca-jest-re,nId,7175005"><img align="left" alt="Zderzenie autobusu z samochodem w Warszawie. Kierowca jest reanimowany" src="https://interia-s.pluscdn.pl/zderzenie-autobusu-z-samochodem-w-warszawie-kierowca-jest-re/000I3KUOHYE38WWT-C307.jpg" /></a>Poważny wypadek na Trasie Łazienkowskiej w Warszawie. Na skrzyżowaniu ul. Międzynarodowej i al. Stanów Zjednoczonych miejski autobus zderzył się z autem przewozu osób.</p><br clear="all" />

## Nowy rząd Morawieckiego. Wiemy, kto zostanie ministrem zdrowia
 - [https://www.rmf24.pl/polityka/news-nowy-rzad-morawieckiego-wiemy-kto-zostanie-ministrem-zdrowia,nId,7174985](https://www.rmf24.pl/polityka/news-nowy-rzad-morawieckiego-wiemy-kto-zostanie-ministrem-zdrowia,nId,7174985)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T14:25:44+00:00

<p><a href="https://www.rmf24.pl/polityka/news-nowy-rzad-morawieckiego-wiemy-kto-zostanie-ministrem-zdrowia,nId,7174985"><img align="left" alt="Nowy rząd Morawieckiego. Wiemy, kto zostanie ministrem zdrowia " src="https://interia-s.pluscdn.pl/nowy-rzad-morawieckiego-wiemy-kto-zostanie-ministrem-zdrowia/000I3JX9HKFFV543-C307.jpg" /></a>Znamy nazwisko ministra zdrowia w nowym rządzie, który dzisiaj ma zaprezentować Mateusz Morawiecki. Jak dowiedział się nasz reporter - szefową resortu zdrowia ma zostać Ewa Krajewska, pełniąca do tej pory funkcję Głównego Inspektora Farmaceutycznego.</p><br clear="all" />

## Świąteczny Biały Dom. Zobaczcie niezwykłe zdjęcia
 - [https://www.rmf24.pl/fakty/swiat/news-swiateczny-bialy-dom-zobaczcie-niezwykle-zdjecia,nId,7174944](https://www.rmf24.pl/fakty/swiat/news-swiateczny-bialy-dom-zobaczcie-niezwykle-zdjecia,nId,7174944)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T13:40:36+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-swiateczny-bialy-dom-zobaczcie-niezwykle-zdjecia,nId,7174944"><img align="left" alt="Świąteczny Biały Dom. Zobaczcie niezwykłe zdjęcia" src="https://interia-s.pluscdn.pl/swiateczny-bialy-dom-zobaczcie-niezwykle-zdjecia/000I3J4CU57MIOWK-C307.jpg" /></a>Biały Dom pokazał tegoroczne świąteczne dekoracje. Rezydencja prezydenta USA w Waszyngtonie jest już gotowa na Boże Narodzenie.</p><br clear="all" />

## Prokuratura umorzyła dwa postępowania ws. Jarosława Kaczyńskiego
 - [https://www.rmf24.pl/regiony/warszawa/news-prokuratura-umorzyla-dwa-postepowania-ws-jaroslawa-kaczynski,nId,7174914](https://www.rmf24.pl/regiony/warszawa/news-prokuratura-umorzyla-dwa-postepowania-ws-jaroslawa-kaczynski,nId,7174914)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T13:21:05+00:00

<p><a href="https://www.rmf24.pl/regiony/warszawa/news-prokuratura-umorzyla-dwa-postepowania-ws-jaroslawa-kaczynski,nId,7174914"><img align="left" alt="Prokuratura umorzyła dwa postępowania ws. Jarosława Kaczyńskiego" src="https://interia-s.pluscdn.pl/prokuratura-umorzyla-dwa-postepowania-ws-jaroslawa-kaczynski/000I3ILVDIIXAJVT-C307.jpg" /></a>Warszawska prokuratura umorzyła dwa postępowania prowadzone w sprawie prezesa PiS Jarosława Kaczyńskiego - dowiedział się reporter RMF FM. Dotyczyły one zdarzeń podczas październikowych obchodów miesięcznicy katastrofy smoleńskiej, gdy na Placu Piłsudskiego polityk wyrwał telefon jednemu z manifestantów. Miał też - według drugiego z zawiadomień - znieważyć smoleński pomnik.</p><br clear="all" />

## Nawet 25 cm śniegu. Są alerty IMGW
 - [https://www.rmf24.pl/pogoda/news-nawet-25-cm-sniegu-sa-alerty-imgw,nId,7174904](https://www.rmf24.pl/pogoda/news-nawet-25-cm-sniegu-sa-alerty-imgw,nId,7174904)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T13:18:00+00:00

<p><a href="https://www.rmf24.pl/pogoda/news-nawet-25-cm-sniegu-sa-alerty-imgw,nId,7174904"><img align="left" alt="Nawet 25 cm śniegu. Są alerty IMGW" src="https://interia-s.pluscdn.pl/nawet-25-cm-sniegu-sa-alerty-imgw/000I3J1OD96548TE-C307.jpg" /></a>Instytut Meteorologii i Gospodarki Wodnej wydał ostrzeżenia pierwszego stopnia dla części kraju przed intensywnymi opadami śniegu. Możliwy jest przyrost pokrywy śnieżnej o 15 cm do 25 cm. Alerty dotyczą południa kraju, południowego zachodu, a także części województwa pomorskiego. Tej nocy temperatura może spaść nawet do -12 stopni.</p><br clear="all" />

## Katastrofa barki w Gdańsku. Jest zarzut dla armatora jednostki
 - [https://www.rmf24.pl/regiony/trojmiasto/news-katastrofa-barki-w-gdansku-jest-zarzut-dla-armatora-jednostk,nId,7174899](https://www.rmf24.pl/regiony/trojmiasto/news-katastrofa-barki-w-gdansku-jest-zarzut-dla-armatora-jednostk,nId,7174899)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T12:55:48+00:00

<p><a href="https://www.rmf24.pl/regiony/trojmiasto/news-katastrofa-barki-w-gdansku-jest-zarzut-dla-armatora-jednostk,nId,7174899"><img align="left" alt="Katastrofa barki w Gdańsku. Jest zarzut dla armatora jednostki" src="https://interia-s.pluscdn.pl/katastrofa-barki-w-gdansku-jest-zarzut-dla-armatora-jednostk/000I3I7KODPJLBT9-C307.jpg" /></a>Prokuratura Okręgowa w Gdańsku przedstawiła armatorowi jachtu Galar Gdański I zarzut umyślnego przyczynienia się do sprowadzenia katastrofy w ruchu wodnym. Na skutek wypadku, do którego doszło w październiku zeszłego roku zginęły cztery osoby, a dwoje pasażerów zostało rannych.</p><br clear="all" />

## Nie tak szybko ze śledczymi
 - [https://www.rmf24.pl/polityka/news-nie-tak-szybko-ze-sledczymi,nId,7174894](https://www.rmf24.pl/polityka/news-nie-tak-szybko-ze-sledczymi,nId,7174894)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T12:53:33+00:00

<p><a href="https://www.rmf24.pl/polityka/news-nie-tak-szybko-ze-sledczymi,nId,7174894"><img align="left" alt="Nie tak szybko ze śledczymi" src="https://interia-s.pluscdn.pl/nie-tak-szybko-ze-sledczymi/000I3HWXCKWR8R8R-C307.jpg" /></a>Przewidziane na jutro wielogodzinne debaty nad powołaniem pierwszych trzech komisji śledczych wcale nie oznaczają ich powołania. Nieprędko także wybrani zostaną ich członkowie. Na razie nie jest nawet znany sposób podziału w nich miejsc między posłów koalicji i opozycji.</p><br clear="all" />

## Paweł Huelle nie żyje. Pisarz miał 66 lat
 - [https://www.rmf24.pl/kultura/news-pawel-huelle-nie-zyje-pisarz-mial-66-lat,nId,7174856](https://www.rmf24.pl/kultura/news-pawel-huelle-nie-zyje-pisarz-mial-66-lat,nId,7174856)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T12:39:00+00:00

<p><a href="https://www.rmf24.pl/kultura/news-pawel-huelle-nie-zyje-pisarz-mial-66-lat,nId,7174856"><img align="left" alt="Paweł Huelle nie żyje. Pisarz miał 66 lat" src="https://interia-s.pluscdn.pl/pawel-huelle-nie-zyje-pisarz-mial-66-lat/000I3H5OKULHJC29-C307.jpg" /></a>W wieku 66 lat zmarł Paweł Huelle, autor powieści takich jak &quot;Weiser Dawidek&quot; i „Ostatnia Wieczerza”. Informację o śmierci pisarza potwierdziła prezydent Gdańska Aleksandra Dulkiewicz. </p><br clear="all" />

## Szejkowie chcą na szczycie klimatycznym zawierać umowy naftowe
 - [https://www.rmf24.pl/raporty/raport-kryzys-klimatyczny/news-obroncy-paliw-kopalnych-szejkowie-chca-na-szczycie-klimatycz,nId,7174692](https://www.rmf24.pl/raporty/raport-kryzys-klimatyczny/news-obroncy-paliw-kopalnych-szejkowie-chca-na-szczycie-klimatycz,nId,7174692)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T12:17:00+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-kryzys-klimatyczny/news-obroncy-paliw-kopalnych-szejkowie-chca-na-szczycie-klimatycz,nId,7174692"><img align="left" alt="Szejkowie chcą na szczycie klimatycznym zawierać umowy naftowe" src="https://interia-s.pluscdn.pl/szejkowie-chca-na-szczycie-klimatycznym-zawierac-umowy-nafto/000I3GS6L3KME8UO-C307.jpg" /></a>Coraz więcej kontrowersji przed ruszającym w czwartek szczytem klimatycznym ONZ w Dubaju. Dziennikarze z Centre for Climate Reporting, organizacji współpracującej z BBC, informują, że Zjednoczone Emiraty Arabskie planowały wykorzystać COP28 do zawierania nowych umów naftowo-gazowych. </p><br clear="all" />

## "Rzeczpospolita": NBP płaci miliony doradcom Glapińskiego
 - [https://www.rmf24.pl/ekonomia/news-rzeczpospolita-nbp-placi-miliony-doradcom-glapinskiego,nId,7174831](https://www.rmf24.pl/ekonomia/news-rzeczpospolita-nbp-placi-miliony-doradcom-glapinskiego,nId,7174831)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T11:53:42+00:00

<p><a href="https://www.rmf24.pl/ekonomia/news-rzeczpospolita-nbp-placi-miliony-doradcom-glapinskiego,nId,7174831"><img align="left" alt="&quot;Rzeczpospolita&quot;: NBP płaci miliony doradcom Glapińskiego" src="https://interia-s.pluscdn.pl/rzeczpospolita-nbp-placi-miliony-doradcom-glapinskiego/000I3GQUKXY182M1-C307.jpg" /></a>Ponad 4,6 mln zł zarobili w 2022 r. doradcy Adama Glapińskiego - donosi &quot;Rzeczpospolita&quot;. Narodowy Bank Polski odmówił jednak ujawnienia ich nazwisk.</p><br clear="all" />

## Jest kolejny kandydat na prezydenta Krakowa
 - [https://www.rmf24.pl/regiony/krakow/news-jest-kolejny-kandydat-na-prezydenta-krakowa,nId,7174822](https://www.rmf24.pl/regiony/krakow/news-jest-kolejny-kandydat-na-prezydenta-krakowa,nId,7174822)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T11:37:29+00:00

<p><a href="https://www.rmf24.pl/regiony/krakow/news-jest-kolejny-kandydat-na-prezydenta-krakowa,nId,7174822"><img align="left" alt="Jest kolejny kandydat na prezydenta Krakowa" src="https://interia-s.pluscdn.pl/jest-kolejny-kandydat-na-prezydenta-krakowa/000I3HT6VW0AD0VJ-C307.jpg" /></a>Lista kandydatów na prezydenta Krakowa wydłuża się. Dzisiaj (27 listopada) Łukasz Gibała ogłosił, że wystartuje w przyszłorocznych wyborach samorządowych i będzie walczył o fotel prezydenta miasta.</p><br clear="all" />

## Stoltenberg z apelem do Izraela i Hamasu
 - [https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-stoltenberg-z-apelem-do-izraela-i-hamasu,nId,7174809](https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-stoltenberg-z-apelem-do-izraela-i-hamasu,nId,7174809)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T11:37:11+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-stoltenberg-z-apelem-do-izraela-i-hamasu,nId,7174809"><img align="left" alt="Stoltenberg z apelem do Izraela i Hamasu" src="https://interia-s.pluscdn.pl/stoltenberg-z-apelem-do-izraela-i-hamasu/000I3GHDIWY4O6Q9-C307.jpg" /></a>Cieszę się, że porozumienie między Hamasem i Izraelem doprowadziło do zwolnienia zakładników i dostarczania większej ilości pomocy humanitarnej; wzywam do przedłużenia zawieszenia broni - oświadczył sekretarz generalny NATO Jens Stoltenberg na konferencji prasowej w Brukseli.</p><br clear="all" />

## Kołodziejczak o nowym rządzie Morawieckiego: Jeden wielki mem
 - [https://www.rmf24.pl/tylko-w-rmf24/rozmowa-w-poludnie/news-kolodziejczak-o-nowym-rzadzie-morawieckiego-jeden-wielki-mem,nId,7174447](https://www.rmf24.pl/tylko-w-rmf24/rozmowa-w-poludnie/news-kolodziejczak-o-nowym-rzadzie-morawieckiego-jeden-wielki-mem,nId,7174447)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T11:21:00+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/rozmowa-w-poludnie/news-kolodziejczak-o-nowym-rzadzie-morawieckiego-jeden-wielki-mem,nId,7174447"><img align="left" alt="Kołodziejczak o nowym rządzie Morawieckiego: Jeden wielki mem" src="https://interia-s.pluscdn.pl/kolodziejczak-o-nowym-rzadzie-morawieckiego-jeden-wielki-mem/000I3CV6HCCNAHI6-C307.jpg" /></a>&quot;Protest jest zasadny. Nie ma się co dziwić tym, którzy dzisiaj stoją na granicy i mówią, że przepisy, które w nich uderzyły, są tak naprawdę zaprzeczeniem funkcjonowania Unii Europejskiej” – tak akcję polskich przewoźników, którzy blokują polsko-ukraińskie przejścia graniczne na Lubelszczyźnie i Podkarpaciu komentował w Rozmowie w południe w RMF FM i Radiu RMF24 Michał Kołodziejczak. &quot;Mateusz Morawiecki dzisiaj zajmuje się rozdawaniem kolejnych stanowisk, tworzeniem fikcyjnego rządu. Nie rozwiązuje się poważnych problemów. To jest jeden...</p><br clear="all" />

## Kołodziejczak o nowym rządzie Morawieckiego: Jeden wielki mem
 - [https://www.rmf24.pl/tylko-w-rmf24/rozmowa-w-poludnie/news-kolodziejczak-to-pis-dopuscilo-by-problem-na-granicy-z-ukrai,nId,7174447](https://www.rmf24.pl/tylko-w-rmf24/rozmowa-w-poludnie/news-kolodziejczak-to-pis-dopuscilo-by-problem-na-granicy-z-ukrai,nId,7174447)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T11:02:00+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/rozmowa-w-poludnie/news-kolodziejczak-to-pis-dopuscilo-by-problem-na-granicy-z-ukrai,nId,7174447"><img align="left" alt="Kołodziejczak o nowym rządzie Morawieckiego: Jeden wielki mem" src="https://interia-s.pluscdn.pl/kolodziejczak-o-nowym-rzadzie-morawieckiego-jeden-wielki-mem/000I3CV6HCCNAHI6-C307.jpg" /></a>„Nie ma się co dziwić tym, którzy dzisiaj stoją na granicy. PiS dopuściło do tego, żeby ten problem narastał” – powiedział w Rozmowie w południe w RMF FM i Radiu RMF24 lider Agrounii i poseł KO, Michał Kołodziejczak. Polityk powiedział, że w tym tygodniu ponownie wybiera się na granicę. Chce też zostać członkiem komisji śledczej, która zajmie się sprawą importu ukraińskiego zboża. </p><br clear="all" />

## Jeśli zaprzysiężenie 13 grudnia, to...
 - [https://www.rmf24.pl/polityka/news-jesli-zaprzysiezenie-13-grudnia-to,nId,7174561](https://www.rmf24.pl/polityka/news-jesli-zaprzysiezenie-13-grudnia-to,nId,7174561)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T10:37:11+00:00

<p><a href="https://www.rmf24.pl/polityka/news-jesli-zaprzysiezenie-13-grudnia-to,nId,7174561"><img align="left" alt="Jeśli zaprzysiężenie 13 grudnia, to..." src="https://interia-s.pluscdn.pl/jesli-zaprzysiezenie-13-grudnia-to/000I3FJI3ERLQYK0-C307.jpg" /></a>Dzisiejsze zaprzysiężenie rządu Mateusza Morawieckiego przebiega dokładnie według harmonogramu przewidzianego już kilka tygodni temu. Ciąg wydarzeń niepowstrzymanie prowadzi do problemu, którego rowiązaniem może być zaprzysiężenie rządu Donalda Tuska w rocznicę wprowadzenia stanu wojennego. Jeśli tak się stanie, to za sprawą działań prezydenta Andrzeja Dudy.</p><br clear="all" />

## Ile zarobią "tymczasowi" ministrowie?
 - [https://www.rmf24.pl/polityka/news-ile-zarobia-tymczasowi-ministrowie,nId,7174541](https://www.rmf24.pl/polityka/news-ile-zarobia-tymczasowi-ministrowie,nId,7174541)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T10:30:14+00:00

<p><a href="https://www.rmf24.pl/polityka/news-ile-zarobia-tymczasowi-ministrowie,nId,7174541"><img align="left" alt="Ile zarobią &quot;tymczasowi&quot; ministrowie?" src="https://interia-s.pluscdn.pl/ile-zarobia-tymczasowi-ministrowie/000I3EURTDCOEYPN-C307.jpg" /></a>Dwa tygodnie pracy - dwa miesiące wynagrodzenia? Taki przywilej czeka nowych &quot;tymczasowych&quot; ministrów, których dzisiaj powołać ma prezydent, dając szansę na chwilowe podtrzymanie władzy przez Mateusza Morawieckiego. Nawet na trzymiesięczne odprawy mogą za to liczyć obecni ministrowie, którzy nie znajdą się w tymczasowym gabinecie Morawieckiego. </p><br clear="all" />

## Nielegalne składowisko odpadów w Kamieńcu. Są zarzuty dla 44-latka
 - [https://www.rmf24.pl/regiony/trojmiasto/news-nielegalne-skladowisko-odpadow-w-kamiencu-sa-zarzuty-dla-44-,nId,7174552](https://www.rmf24.pl/regiony/trojmiasto/news-nielegalne-skladowisko-odpadow-w-kamiencu-sa-zarzuty-dla-44-,nId,7174552)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T10:16:35+00:00

<p><a href="https://www.rmf24.pl/regiony/trojmiasto/news-nielegalne-skladowisko-odpadow-w-kamiencu-sa-zarzuty-dla-44-,nId,7174552"><img align="left" alt="Nielegalne składowisko odpadów w Kamieńcu. Są zarzuty dla 44-latka " src="https://interia-s.pluscdn.pl/nielegalne-skladowisko-odpadow-w-kamiencu-sa-zarzuty-dla-44/000I3G39WORQETW5-C307.jpg" /></a>Prokuratura Okręgowa w Słupsku przedstawiła zarzuty dotyczące nielegalnego składowania tysięcy ton odpadów tekstylnych w Kamieńcu na Pomorzu. W ciągu 3 lat wybuchły tam 33 pożary. Podejrzany to 44-letni Dariusz Z. ze Środy Wielkopolskiej.</p><br clear="all" />

## Dwa auta zderzyły się na pustej drodze. Obaj kierowcy byli pijani
 - [https://www.rmf24.pl/regiony/wroclaw/news-dwa-auta-zderzyly-sie-na-pustej-drodze-obaj-kierowcy-byli-pi,nId,7174534](https://www.rmf24.pl/regiony/wroclaw/news-dwa-auta-zderzyly-sie-na-pustej-drodze-obaj-kierowcy-byli-pi,nId,7174534)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T09:59:05+00:00

<p><a href="https://www.rmf24.pl/regiony/wroclaw/news-dwa-auta-zderzyly-sie-na-pustej-drodze-obaj-kierowcy-byli-pi,nId,7174534"><img align="left" alt="Dwa auta zderzyły się na pustej drodze. Obaj kierowcy byli pijani" src="https://interia-s.pluscdn.pl/dwa-auta-zderzyly-sie-na-pustej-drodze-obaj-kierowcy-byli-pi/000I3EFNW3MXVMFB-C307.jpg" /></a>W niedzielę nad ranem do policji wpłynęło zgłoszenie, że na ul. Wrocławskiej w Legnicy doszło do kolizji. Na miejscu okazało się, że kierowca mazdy wyjechał z bocznej drogi pod prąd, prosto na prawidłowo jadącego volkswagena. Obaj kierowcy byli pijani i już stracili prawa jazdy.</p><br clear="all" />

## Stan zdrowia papieża Franciszka - jest najnowszy komunikat
 - [https://www.rmf24.pl/fakty/swiat/news-stan-zdrowia-papieza-franciszka-jest-najnowszy-komunikat,nId,7174533](https://www.rmf24.pl/fakty/swiat/news-stan-zdrowia-papieza-franciszka-jest-najnowszy-komunikat,nId,7174533)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T09:59:00+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-stan-zdrowia-papieza-franciszka-jest-najnowszy-komunikat,nId,7174533"><img align="left" alt="Stan zdrowia papieża Franciszka - jest najnowszy komunikat" src="https://interia-s.pluscdn.pl/stan-zdrowia-papieza-franciszka-jest-najnowszy-komunikat/000I3EHOX072N3I9-C307.jpg" /></a>Papież Franciszek jest w dobrym stanie zdrowia, nie ma gorączki, a jego oddech wyraźnie się poprawia - przekazał Watykan. W niedzielę 87-letni papież nie odczytał tekstu rozważań podczas południowego spotkania na modlitwie Anioł Pański i wyjaśnił wiernym, że ma &quot;problem z zapaleniem w płucach&quot;.</p><br clear="all" />

## Koniec CBA blisko? Tak może wyglądać likwidacja
 - [https://www.rmf24.pl/fakty/polska/news-koniec-cba-blisko-tak-moze-wygladac-likwidacja,nId,7174504](https://www.rmf24.pl/fakty/polska/news-koniec-cba-blisko-tak-moze-wygladac-likwidacja,nId,7174504)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T09:50:00+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-koniec-cba-blisko-tak-moze-wygladac-likwidacja,nId,7174504"><img align="left" alt="Koniec CBA blisko? Tak może wyglądać likwidacja" src="https://interia-s.pluscdn.pl/koniec-cba-blisko-tak-moze-wygladac-likwidacja/000I3DSCNGFQG321-C307.jpg" /></a>Obcięcie budżetu, reorganizacja kadrowa i stopniowe wygaszanie działalności - tak według ekspertów, z którymi rozmawiał reporter RMF FM, może wyglądać likwidacja CBA. To plan na okres przejściowy, bo do likwidacji Biura potrzebna jest ustawa. Na razie w związku z kadencją prezydenta Andrzeja Dudy jej przyjęcie będzie raczej niemożliwe. </p><br clear="all" />

## Awaria sieci w Inowrocławiu. Przywracanie gazu może potrwać kilka dni
 - [https://www.rmf24.pl/fakty/polska/news-awaria-sieci-w-inowroclawiu-przywracanie-gazu-moze-potrwac-k,nId,7174483](https://www.rmf24.pl/fakty/polska/news-awaria-sieci-w-inowroclawiu-przywracanie-gazu-moze-potrwac-k,nId,7174483)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T09:20:53+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-awaria-sieci-w-inowroclawiu-przywracanie-gazu-moze-potrwac-k,nId,7174483"><img align="left" alt="Awaria sieci w Inowrocławiu. Przywracanie gazu może potrwać kilka dni" src="https://interia-s.pluscdn.pl/awaria-sieci-w-inowroclawiu-przywracanie-gazu-moze-potrwac-k/000I3DHQSUW1EXHM-C307.jpg" /></a>Z 75 tys. mieszkańców Inowrocławia 25 tys. ma już gaz w swoich mieszkaniach i firmach. W pierwszej kolejności podłączono szpitale, domy pomocy społecznej, żłobki i przedszkola. W sobotę doszło do awarii głównej sieci zasilającej miasto.</p><br clear="all" />

## Gigantyczny wyciek danych medycznych. Ponad 50 tys. wyników badań trafiło do sieci
 - [https://www.rmf24.pl/fakty/polska/news-gigantyczny-wyciek-danych-medycznych-ponad-50-tys-wynikow-ba,nId,7174467](https://www.rmf24.pl/fakty/polska/news-gigantyczny-wyciek-danych-medycznych-ponad-50-tys-wynikow-ba,nId,7174467)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T09:16:00+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-gigantyczny-wyciek-danych-medycznych-ponad-50-tys-wynikow-ba,nId,7174467"><img align="left" alt="Gigantyczny wyciek danych medycznych. Ponad 50 tys. wyników badań trafiło do sieci " src="https://interia-s.pluscdn.pl/gigantyczny-wyciek-danych-medycznych-ponad-50-tys-wynikow-ba/000I3DG1RFSTQ7RC-C307.jpg" /></a>Do internetu trafiło ponad 50 tysięcy wyników badań medycznych. Dane pacjentów pochodziły z jednej z największych sieci laboratoriów w Polsce – firmy ALAB – informuje serwis Zaufana Trzecia Strona.</p><br clear="all" />

## Katastrofa śmigłowca ukraińskiego MSW. Są wyniki śledztwa
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-katastrofa-smiglowca-ukrainskiego-msw-sa-wyniki-sledztwa,nId,7174471](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-katastrofa-smiglowca-ukrainskiego-msw-sa-wyniki-sledztwa,nId,7174471)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T08:48:01+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-katastrofa-smiglowca-ukrainskiego-msw-sa-wyniki-sledztwa,nId,7174471"><img align="left" alt="Katastrofa śmigłowca ukraińskiego MSW. Są wyniki śledztwa" src="https://interia-s.pluscdn.pl/katastrofa-smiglowca-ukrainskiego-msw-sa-wyniki-sledztwa/000I3D06QCKUI3U3-C307.jpg" /></a>Naruszenie zasad bezpieczeństwa transportu lotniczego - to główna przyczyna katastrofy śmigłowca, w której zginęło całe kierownictwo ukraińskiego MSW. Zakończyło się śledztwo w sprawie tragedii ze stycznia tego roku, gdy śmigłowiec spadł na przedszkole w okolicach Kijowa. </p><br clear="all" />

## Przetrzymywał ich Hamas. Po odzyskaniu wolności nastolatkom przekazano tragiczną wiadomość
 - [https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-przetrzymywal-ich-hamas-po-odzyskaniu-wolnosci-nastolatkom-p,nId,7174450](https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-przetrzymywal-ich-hamas-po-odzyskaniu-wolnosci-nastolatkom-p,nId,7174450)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T08:21:00+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-przetrzymywal-ich-hamas-po-odzyskaniu-wolnosci-nastolatkom-p,nId,7174450"><img align="left" alt="Przetrzymywał ich Hamas. Po odzyskaniu wolności nastolatkom przekazano tragiczną wiadomość" src="https://interia-s.pluscdn.pl/przetrzymywal-ich-hamas-po-odzyskaniu-wolnosci-nastolatkom-p/000I3CWL1YQSSMR1-C307.jpg" /></a>13-letnia Alma Or i jej 16-letni brat Noam są wśród zakładników uwolnionych do tej pory przez Hamas w ramach zawieszenia broni z Izraelem. Rodzeństwo spędziło w niewoli 50 dni. Po odzyskaniu wolności nastolatkowie dowiedzieli się jednak, że terroryści z Hamasu zabili jej matkę, a los ich ojca jest nieznany. </p><br clear="all" />

## Porwano kolejny statek. Napastnicy zostali schwytani przez marynarkę wojenną USA
 - [https://www.rmf24.pl/fakty/swiat/news-porwano-kolejny-statek-napastnicy-zostali-schwytani-przez-ma,nId,7174430](https://www.rmf24.pl/fakty/swiat/news-porwano-kolejny-statek-napastnicy-zostali-schwytani-przez-ma,nId,7174430)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T08:01:00+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-porwano-kolejny-statek-napastnicy-zostali-schwytani-przez-ma,nId,7174430"><img align="left" alt="Porwano kolejny statek. Napastnicy zostali schwytani przez marynarkę wojenną USA" src="https://interia-s.pluscdn.pl/porwano-kolejny-statek-napastnicy-zostali-schwytani-przez-ma/000I3CEUVMIQ6LHM-C307.jpg" /></a>Uzbrojeni napastnicy, którzy w niedzielę u wybrzeży Jemenu przejęli, a potem wypuścili zarządzany przez izraelską firmę tankowiec Central Park, zostali zatrzymani przez marynarkę wojenną Stanów Zjednoczonych. Rząd Jemenu oskarżył o atak rebeliantów Huti.</p><br clear="all" />

## Dworczyk o nowym rządzie Morawieckiego: Jest pewna koncepcja
 - [https://www.rmf24.pl/tylko-w-rmf24/poranna-rozmowa/news-dworczyk-o-nowym-rzadzie-morawieckiego-jest-pewna-koncepcja,nId,7173000](https://www.rmf24.pl/tylko-w-rmf24/poranna-rozmowa/news-dworczyk-o-nowym-rzadzie-morawieckiego-jest-pewna-koncepcja,nId,7173000)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T07:02:00+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/poranna-rozmowa/news-dworczyk-o-nowym-rzadzie-morawieckiego-jest-pewna-koncepcja,nId,7173000"><img align="left" alt="Dworczyk o nowym rządzie Morawieckiego: Jest pewna koncepcja" src="https://interia-s.pluscdn.pl/dworczyk-o-nowym-rzadzie-morawieckiego-jest-pewna-koncepcja/000I3A34R8TGUX5X-C307.jpg" /></a>&quot;Jest pewna koncepcja stworzenia rządu, który będzie działał w oparciu o ekspertów i niektórych polityków&quot; - powiedział w Porannej rozmowie w RMF FM poseł PiS, Michał Dworczyk. &quot;Dopóki realizowaliśmy program Prawa i Sprawiedliwości, zasadnym było, żeby rząd tworzyli wyłącznie politycy PiS&quot; - dodał gość Roberta Mazurka.</p><br clear="all" />

## Dworczyk: Może sam zagłosuję za tą komisją. Mam dosyć kłamstw
 - [https://www.rmf24.pl/tylko-w-rmf24/poranna-rozmowa/news-dworczyk-moze-sam-zaglosuje-za-ta-komisja-mam-dosyc-klamstw,nId,7173000](https://www.rmf24.pl/tylko-w-rmf24/poranna-rozmowa/news-dworczyk-moze-sam-zaglosuje-za-ta-komisja-mam-dosyc-klamstw,nId,7173000)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T07:02:00+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/poranna-rozmowa/news-dworczyk-moze-sam-zaglosuje-za-ta-komisja-mam-dosyc-klamstw,nId,7173000"><img align="left" alt="Dworczyk: Może sam zagłosuję za tą komisją. Mam dosyć kłamstw" src="https://interia-s.pluscdn.pl/dworczyk-moze-sam-zaglosuje-za-ta-komisja-mam-dosyc-klamstw/000I3A34R8TGUX5X-C307.jpg" /></a>&quot;Jest pewna koncepcja stworzenia rządu, który będzie działał w oparciu o ekspertów i niektórych polityków&quot; - powiedział w Porannej rozmowie w RMF FM poseł PiS, Michał Dworczyk. &quot;Dopóki realizowaliśmy program Prawa i Sprawiedliwości, zasadnym było, żeby rząd tworzyli wyłącznie politycy PiS&quot; - dodał gość Roberta Mazurka. Jak powiedział, być może zagłosuje za komisją śledczą w sprawie tzw. wyborów kopertowych.</p><br clear="all" />

## Michał Dworczyk gościem Porannej rozmowy w RMF FM
 - [https://www.rmf24.pl/tylko-w-rmf24/poranna-rozmowa/news-michal-dworczyk-gosciem-porannej-rozmowy-w-rmf-fm,nId,7173000](https://www.rmf24.pl/tylko-w-rmf24/poranna-rozmowa/news-michal-dworczyk-gosciem-porannej-rozmowy-w-rmf-fm,nId,7173000)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T06:45:00+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/poranna-rozmowa/news-michal-dworczyk-gosciem-porannej-rozmowy-w-rmf-fm,nId,7173000"><img align="left" alt="Michał Dworczyk gościem Porannej rozmowy w RMF FM" src="https://interia-s.pluscdn.pl/michal-dworczyk-gosciem-porannej-rozmowy-w-rmf-fm/000I3A34R8TGUX5X-C307.jpg" /></a>Gościem Porannej rozmowy w RMF FM jest minister Michał Dworczyk, poseł Prawa i Sprawiedliwości. Porozmawiamy o próbie stworzenia rządu przez Mateusza Morawieckiego. Dlaczego wielu z dotychczasowych ministrów nie otrzymało do niego zaproszenia? </p><br clear="all" />

## Kaczyński: Kształt gabinetu Morawieckiego to mój pomysł
 - [https://www.rmf24.pl/polityka/news-dzis-zaprzysiezenie-rzadu-morawieckiego-kaczynski-ksztalt-ga,nId,7174391](https://www.rmf24.pl/polityka/news-dzis-zaprzysiezenie-rzadu-morawieckiego-kaczynski-ksztalt-ga,nId,7174391)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T06:32:50+00:00

<p><a href="https://www.rmf24.pl/polityka/news-dzis-zaprzysiezenie-rzadu-morawieckiego-kaczynski-ksztalt-ga,nId,7174391"><img align="left" alt="Kaczyński: Kształt gabinetu Morawieckiego to mój pomysł" src="https://interia-s.pluscdn.pl/kaczynski-ksztalt-gabinetu-morawieckiego-to-moj-pomysl/000I3BQNH5A2EU3V-C307.jpg" /></a>&quot;Kształt rządu ekspercko-politycznego, który w poniedziałek przedstawi premier Mateusz Morawiecki, to mój pomysł. Chcemy zaproponować nowe twarze&quot; - mówił w rozmowie z PAP prezes Prawa i Sprawiedliwości Jarosław Kaczyński. &quot;Trzeba zakończyć wojnę, którą prowadzi Platforma Obywatelska&quot; - podkreślił.</p><br clear="all" />

## Kawiaq i jego kolega zatrzymani. Patostreamerzy znęcali się nad młodymi kobietami
 - [https://www.rmf24.pl/regiony/slaskie/news-kawiaq-i-jego-kolega-zatrzymani-patostreamerzy-znecali-sie-n,nId,7174389](https://www.rmf24.pl/regiony/slaskie/news-kawiaq-i-jego-kolega-zatrzymani-patostreamerzy-znecali-sie-n,nId,7174389)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T06:31:34+00:00

<p><a href="https://www.rmf24.pl/regiony/slaskie/news-kawiaq-i-jego-kolega-zatrzymani-patostreamerzy-znecali-sie-n,nId,7174389"><img align="left" alt="Kawiaq i jego kolega zatrzymani. Patostreamerzy znęcali się nad młodymi kobietami" src="https://interia-s.pluscdn.pl/kawiaq-i-jego-kolega-zatrzymani-patostreamerzy-znecali-sie-n/000I3BPS9EA5UY77-C307.jpg" /></a>Policjanci z Katowic zatrzymali dwóch 18-letnich patostreamerów, którzy 17 listopada podczas transmisji w internecie znęcali się nad upijanymi dziewczynami. Gdy sprawa stała się głośna, uciekli za granicę. Nastolatkowie trafili do policyjnego aresztu. Dziś mają usłyszeć prokuratorskie zarzuty.</p><br clear="all" />

## Kawiaq zatrzymany. Patostreamer znęcał się nad młodymi kobietami
 - [https://www.rmf24.pl/regiony/slaskie/news-kawiaq-i-jego-kolega-zatrzymani-sa-wnioski-o-aresztowanie-pa,nId,7174389](https://www.rmf24.pl/regiony/slaskie/news-kawiaq-i-jego-kolega-zatrzymani-sa-wnioski-o-aresztowanie-pa,nId,7174389)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T06:31:34+00:00

<p><a href="https://www.rmf24.pl/regiony/slaskie/news-kawiaq-i-jego-kolega-zatrzymani-sa-wnioski-o-aresztowanie-pa,nId,7174389"><img align="left" alt="Kawiaq zatrzymany. Patostreamer znęcał się nad młodymi kobietami" src="https://interia-s.pluscdn.pl/kawiaq-zatrzymany-patostreamer-znecal-sie-nad-mlodymi-kobiet/000I3BPS9EA5UY77-C307.jpg" /></a>Katowicka prokuratura przesłała do sądu wnioski o aresztowanie dwóch 18-letnich patostreamerów, którzy podczas transmisji w internecie znęcali się nad dwiema upijanymi dziewczynami. Gdy sprawa stała się głośna, uciekli za granicę. Zostali zatrzymani po powrocie do Polski.</p><br clear="all" />

## "Łowcy cieni" w akcji. Zatrzymano czterech mężczyzn
 - [https://www.rmf24.pl/regiony/warszawa/news-lowcy-cieni-w-akcji-zatrzymano-czterech-mezczyzn,nId,7174381](https://www.rmf24.pl/regiony/warszawa/news-lowcy-cieni-w-akcji-zatrzymano-czterech-mezczyzn,nId,7174381)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T06:15:42+00:00

<p><a href="https://www.rmf24.pl/regiony/warszawa/news-lowcy-cieni-w-akcji-zatrzymano-czterech-mezczyzn,nId,7174381"><img align="left" alt="&quot;Łowcy cieni&quot; w akcji. Zatrzymano czterech mężczyzn" src="https://interia-s.pluscdn.pl/lowcy-cieni-w-akcji-zatrzymano-czterech-mezczyzn/000I3BOUIEIB4O14-C307.jpg" /></a>&quot;Łowcy cieni&quot; CBŚP zatrzymali czterech mężczyzn poszukiwanych Europejskim Nakazem Aresztowania przez belgijskie służby. Mężczyźni ścigani byli za porwanie i bezprawne pozbawienie wolności z użyciem broni palnej dwóch obywateli Belgii.</p><br clear="all" />

## Klich o proteście przewoźników: Morawiecki chce ten gorący kartofel przerzucić na Tuska
 - [https://www.rmf24.pl/tylko-w-rmf24/rozmowa-o-7/news-klich-o-protescie-przewoznikow-morawiecki-chce-ten-goracy-ka,nId,7172968](https://www.rmf24.pl/tylko-w-rmf24/rozmowa-o-7/news-klich-o-protescie-przewoznikow-morawiecki-chce-ten-goracy-ka,nId,7172968)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T05:57:32+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/rozmowa-o-7/news-klich-o-protescie-przewoznikow-morawiecki-chce-ten-goracy-ka,nId,7172968"><img align="left" alt="Klich o proteście przewoźników: Morawiecki chce ten gorący kartofel przerzucić na Tuska" src="https://interia-s.pluscdn.pl/klich-o-protescie-przewoznikow-morawiecki-chce-ten-goracy-ka/000I39RCKAQU1M4L-C307.jpg" /></a>&quot;Jak zwykle do tej pory: polski rząd się spóźnił. Przecież protest przewoźników na granicy z Ukrainą trwa od początku listopada. To któryś tydzień trwania tego protestu. I ze strony polskiego rządu nie ma negocjacji prowadzonych na najwyższym szczeblu. W tym czasie premier Morawiecki zajmuje się szopką pod tytułem: &quot;tworzenie nowego rządu&quot;, który wiadomo, że nie powstanie&quot; - mówi w Rozmowie o 7:00 w RMF FM i Radiu RMF24 senator Koalicji Obywatelskiej, były minister obrony Bogdan Klich pytany o, kto ponosi odpowiedzialność za kryzys na...</p><br clear="all" />

## Śnieg i mróz. Zimowy początek tygodnia
 - [https://www.rmf24.pl/pogoda/news-snieg-i-mroz-zimowy-poczatek-tygodnia,nId,7174370](https://www.rmf24.pl/pogoda/news-snieg-i-mroz-zimowy-poczatek-tygodnia,nId,7174370)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T05:53:52+00:00

<p><a href="https://www.rmf24.pl/pogoda/news-snieg-i-mroz-zimowy-poczatek-tygodnia,nId,7174370"><img align="left" alt="Śnieg i mróz. Zimowy początek tygodnia" src="https://interia-s.pluscdn.pl/snieg-i-mroz-zimowy-poczatek-tygodnia/000I3BMGV1HEKLBS-C307.jpg" /></a>To będzie pochmurny dzień w całym kraju. Miejscami spadnie śnieg. Największych opadów należy spodziewać się na Wybrzeżu. Będzie zimno. Najchłodniej na północnym wschodzie: tam temperatura spadnie do minus 4 stopni Celsjusza. </p><br clear="all" />

## Śnieg, mróz, trudne warunki na drogach. Zimowy początek tygodnia
 - [https://www.rmf24.pl/pogoda/news-snieg-mroz-trudne-warunki-na-drogach-zimowy-poczatek-tygodni,nId,7174370](https://www.rmf24.pl/pogoda/news-snieg-mroz-trudne-warunki-na-drogach-zimowy-poczatek-tygodni,nId,7174370)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T05:53:52+00:00

<p><a href="https://www.rmf24.pl/pogoda/news-snieg-mroz-trudne-warunki-na-drogach-zimowy-poczatek-tygodni,nId,7174370"><img align="left" alt="Śnieg, mróz, trudne warunki na drogach. Zimowy początek tygodnia" src="https://interia-s.pluscdn.pl/snieg-mroz-trudne-warunki-na-drogach-zimowy-poczatek-tygodni/000I3BMGV1HEKLBS-C307.jpg" /></a>Początek tygodnia przywitał nas zimową aurą. W wielu regionach Polski sypie śnieg i panują trudne warunki do jazdy. Jest zimno. Najchłodniej na północnym wschodzie: tam temperatura spadnie do minus 4 stopni Celsjusza. </p><br clear="all" />

## ​Dla kogo koronawirus jest teraz szczególnie groźny?
 - [https://www.rmf24.pl/raporty/raport-koronawirus-z-chin/europa/news-dla-kogo-koronawirus-jest-teraz-szczegolnie-grozny,nId,7174372](https://www.rmf24.pl/raporty/raport-koronawirus-z-chin/europa/news-dla-kogo-koronawirus-jest-teraz-szczegolnie-grozny,nId,7174372)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T05:38:11+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-koronawirus-z-chin/europa/news-dla-kogo-koronawirus-jest-teraz-szczegolnie-grozny,nId,7174372"><img align="left" alt="​Dla kogo koronawirus jest teraz szczególnie groźny?" src="https://interia-s.pluscdn.pl/dla-kogo-koronawirus-jest-teraz-szczegolnie-grozny/000I3BMR293N4IAX-C307.jpg" /></a>Od ponad miesiąca liczba zakażeń koronawirusem w Polsce systematycznie rośnie. W ubiegłym tygodniu w naszym kraju rejestrowano jednego dnia średnio prawie dwa tysiące infekcji Covid-19. W szpitalach w całej Polsce jest obecnie ponad 1200 osób zakażonych koronawirusem. Pojedynczy pacjenci wymagają pomocy respiratora. To najwyższe wskaźniki od wczesnej wiosny.</p><br clear="all" />

## Ojciec zabił trzy córki i zgłosił się na policję
 - [https://www.rmf24.pl/fakty/swiat/news-ojciec-zabil-trzy-corki-i-zglosil-sie-na-policje,nId,7174369](https://www.rmf24.pl/fakty/swiat/news-ojciec-zabil-trzy-corki-i-zglosil-sie-na-policje,nId,7174369)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T05:23:48+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-ojciec-zabil-trzy-corki-i-zglosil-sie-na-policje,nId,7174369"><img align="left" alt="Ojciec zabił trzy córki i zgłosił się na policję" src="https://interia-s.pluscdn.pl/ojciec-zabil-trzy-corki-i-zglosil-sie-na-policje/000I3BMLM6YE37SF-C307.jpg" /></a>Tragedia we Francji. 41-letni mężczyzna zgłosił się w niedzielę na policję i przyznał się do zamordowania trzech córek w wieku 4, 10 i 11 lat - podała agencja AFP. Do zdarzenia doszło w domu w Alfortville na obrzeżach Paryża. </p><br clear="all" />

## Europejska Prokurator Generalna dla RMF FM: Nie mogę się doczekać na współpracę z Polską
 - [https://www.rmf24.pl/fakty/polska/news-europejska-prokurator-generalna-dla-rmf-fm-nie-moge-sie-docz,nId,7173035](https://www.rmf24.pl/fakty/polska/news-europejska-prokurator-generalna-dla-rmf-fm-nie-moge-sie-docz,nId,7173035)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T05:20:24+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-europejska-prokurator-generalna-dla-rmf-fm-nie-moge-sie-docz,nId,7173035"><img align="left" alt="Europejska Prokurator Generalna dla RMF FM: Nie mogę się doczekać na współpracę z Polską" src="https://interia-s.pluscdn.pl/europejska-prokurator-generalna-dla-rmf-fm-nie-moge-sie-docz/000I3AOV7SFTSJB0-C307.jpg" /></a>&quot;Nie mogę się doczekać na współpracę z Polską&quot; - mówi w rozmowie z RMF FM Europejska Prokurator Generalna Laura Codruța Kövesi. Jej zdaniem, gdy po zmianie rządu Polska dołączy do Prokuratury Europejskiej, to pieniądze polskich podatników będą o wiele lepiej chronione. Przystąpienie Polski do EPPO powinno zająć kilka miesięcy, nie dłużej. Natomiast przez brak współpracy władzy PiS w ramach EPPO Polska traciła pieniądze i była postrzegana przez oszustów finansowych jako &quot;przystań&quot;.</p><br clear="all" />

## Koniec porozumienia. Korea Północna kieruje wojsko na granicę
 - [https://www.rmf24.pl/fakty/swiat/news-koniec-porozumienia-korea-polnocna-kieruje-wojsko-na-granice,nId,7174365](https://www.rmf24.pl/fakty/swiat/news-koniec-porozumienia-korea-polnocna-kieruje-wojsko-na-granice,nId,7174365)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T04:40:56+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-koniec-porozumienia-korea-polnocna-kieruje-wojsko-na-granice,nId,7174365"><img align="left" alt="Koniec porozumienia. Korea Północna kieruje wojsko na granicę" src="https://interia-s.pluscdn.pl/koniec-porozumienia-korea-polnocna-kieruje-wojsko-na-granice/000I3BLUVFH45EJI-C307.jpg" /></a>Korea Północna rozmieściła wojsko i broń w pobliżu granicy z Korea Południową. Nastąpiło to kilka dni po tym, jak władze w Pjongjangu ogłosiły, że nie będą już ograniczały się porozumieniem z 2018 roku o łagodzeniu napięć. Informację o rozmieszczeniu wojska podała południowokoreańska agencja informacyjna Yonhap.</p><br clear="all" />

## Alarm przeciwlotniczy w pięciu obwodach Ukrainy [RELACJA]
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/na-zywo/news-alarm-przeciwlotniczy-w-pieciu-obwodach-ukrainy-relacja,nId,7174364](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/na-zywo/news-alarm-przeciwlotniczy-w-pieciu-obwodach-ukrainy-relacja,nId,7174364)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T04:11:40+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/na-zywo/news-alarm-przeciwlotniczy-w-pieciu-obwodach-ukrainy-relacja,nId,7174364"><img align="left" alt="Alarm przeciwlotniczy w pięciu obwodach Ukrainy [RELACJA]" src="https://interia-s.pluscdn.pl/alarm-przeciwlotniczy-w-pieciu-obwodach-ukrainy-relacja/000I3BKZVVR6J9ON-C307.jpg" /></a>W nocy w pięciu obwodach Ukrainy ogłoszono alarm przeciwlotniczy. Siły Powietrzne zaapelowały do mieszkańców o pozostanie w schronach - poinformowały lokalne media. Dziś jest 642. dzień wojny Rosji przeciwko Ukrainie. Najważniejsze informacje dotyczące konfliktu za naszą wschodnią granicą zbieramy w relacji z 28.11.2023 r.</p><br clear="all" />

## Johnson: Nie możemy pozwolić Putinowi na marsz przez Europę [RELACJA]
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/na-zywo/news-johnson-nie-mozemy-pozwolic-putinowi-na-marsz-przez-europe-r,nId,7174364](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/na-zywo/news-johnson-nie-mozemy-pozwolic-putinowi-na-marsz-przez-europe-r,nId,7174364)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T04:11:40+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/na-zywo/news-johnson-nie-mozemy-pozwolic-putinowi-na-marsz-przez-europe-r,nId,7174364"><img align="left" alt="Johnson: Nie możemy pozwolić Putinowi na marsz przez Europę [RELACJA]" src="https://interia-s.pluscdn.pl/johnson-nie-mozemy-pozwolic-putinowi-na-marsz-przez-europe-r/000I3MH8URA5TP5M-C307.jpg" /></a>Spiker amerykańskiej Izby Reprezentantów Mike Johnson wyraził &quot;optymizm i pewność&quot;, że Kongres będzie w stanie uchwalić dodatkowe środki na pomoc Ukrainie i Izraelowi przed świąteczną przerwą. W Międzynarodowej Organizacji Morskiej (IMO) nie ma miejsca dla Rosji; w ciągu dziesięcioleci nikt nie wyrządził większej szkody wolnej żegludze niż Rosja - oświadczył prezydent Ukrainy Wołodymyr Zełenski w zdalnym przemówieniu do członków 33. zgromadzenia IMO. Ostatnie sześć tygodni prawdopodobnie przyniosło stronie rosyjskiej jedne z najwyższych...</p><br clear="all" />

## Johnson: Nie możemy pozwolić Putinowi na marsz przez Europę [ZAPIS RELACJI]
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/na-zywo/news-johnson-nie-mozemy-pozwolic-putinowi-na-marsz-przez-europe-z,nId,7174364](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/na-zywo/news-johnson-nie-mozemy-pozwolic-putinowi-na-marsz-przez-europe-z,nId,7174364)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-27T04:11:40+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/na-zywo/news-johnson-nie-mozemy-pozwolic-putinowi-na-marsz-przez-europe-z,nId,7174364"><img align="left" alt="Johnson: Nie możemy pozwolić Putinowi na marsz przez Europę [ZAPIS RELACJI]" src="https://interia-s.pluscdn.pl/johnson-nie-mozemy-pozwolic-putinowi-na-marsz-przez-europe-z/000I3MH8URA5TP5M-C307.jpg" /></a>Spiker amerykańskiej Izby Reprezentantów Mike Johnson wyraził &quot;optymizm i pewność&quot;, że Kongres będzie w stanie uchwalić dodatkowe środki na pomoc Ukrainie i Izraelowi przed świąteczną przerwą. W Międzynarodowej Organizacji Morskiej (IMO) nie ma miejsca dla Rosji; w ciągu dziesięcioleci nikt nie wyrządził większej szkody wolnej żegludze niż Rosja - oświadczył prezydent Ukrainy Wołodymyr Zełenski w zdalnym przemówieniu do członków 33. zgromadzenia IMO. Ostatnie sześć tygodni prawdopodobnie przyniosło stronie rosyjskiej jedne z najwyższych...</p><br clear="all" />

