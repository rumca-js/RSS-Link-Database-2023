# Source:SAMTIME, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCd6vEDS3SOhWbXZrxbrf_bw, language:en-US

## YouTube Apologises For Slowing Down AdBlock Users
 - [https://www.youtube.com/watch?v=a51RgbcCutk](https://www.youtube.com/watch?v=a51RgbcCutk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCd6vEDS3SOhWbXZrxbrf_bw
 - date published: 2023-11-27T18:50:08+00:00

YouTube intentionally slowed down their site site for some users, and they are strongly sorry…ish.

The Verge Article: https://www.theverge.com/2023/11/21/23970721/google-youtube-ad-blocker-five-second-delay-firefox-chrome

SUPPORT: https://funkytime.tv/patriot-signup/
MERCH: https://funkytime.tv/shop/
FUNKY TIME WEBSITE: https://funkytime.tv

FACEBOOK: http://www.facebook.com/SamtimeNews
TWITTER: http://twitter.com/SamtimeNews
INSTAGRAM: http://instagram.com/samtimenews

-----------------------------------

#YouTube #Sorry #NotSorry

3D YouTube Image by xvector on Freepik

'Escape the ordinary. Embrace the FUNKY!'

-----------------------------------

For sponsorship enquiries: samtime@bossmgmtgrp.com
For other business enquiries: business@funkytime.tv
Copyright FUNKY TIME PRODUCTIONS 2023

