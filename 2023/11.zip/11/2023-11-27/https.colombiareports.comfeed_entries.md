# Source:Colombia News | Colombia Reports, URL:https://colombiareports.com/feed/, language:en-US

## Colombia’s government coalition cracks
 - [https://colombiareports.com/colombias-government-coalition-cracks](https://colombiareports.com/colombias-government-coalition-cracks)
 - RSS feed: https://colombiareports.com/feed/
 - date published: 2023-11-27T14:20:52+00:00

<p>Conservative and progressive liberals are threatening to leave the congressional coalition of President Gustavo Petro. In an open letter to the president, Liberal Party leader Cesar Gaviria said that &#8220;we&#8230;</p>
<p>The post <a href="https://colombiareports.com/colombias-government-coalition-cracks/" rel="nofollow">Colombia&#8217;s government coalition cracks</a> appeared first on <a href="https://colombiareports.com" rel="nofollow">Colombia News | Colombia Reports</a>.</p>

