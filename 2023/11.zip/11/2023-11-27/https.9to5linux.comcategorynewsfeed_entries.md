# Source:9to5Linux News, URL:https://9to5linux.com/category/news/feed, language:en-US

## Nitrux 3.2 Released with Aesthetic FHS, Linux Kernel 6.6 LTS, and Updated Installer
 - [https://9to5linux.com/nitrux-3-2-released-with-aesthetic-fhs-linux-kernel-6-6-lts-and-updated-installer](https://9to5linux.com/nitrux-3-2-released-with-aesthetic-fhs-linux-kernel-6-6-lts-and-updated-installer)
 - RSS feed: https://9to5linux.com/category/news/feed
 - date published: 2023-11-27T21:58:06+00:00

<p>Nitrux 3.2 systemd-free and Debian-based distribution is now available for download with Aesthetic FHS file system implementation, Secure Boot support, and Linux kernel 6.6 LTS.</p>
<p>The post <a href="https://9to5linux.com/nitrux-3-2-released-with-aesthetic-fhs-linux-kernel-6-6-lts-and-updated-installer">Nitrux 3.2 Released with Aesthetic FHS, Linux Kernel 6.6 LTS, and Updated Installer</a> appeared first on <a href="https://9to5linux.com">9to5Linux</a> - do not reproduce this article without permission. This RSS feed is intended for readers, not scrapers.</p>

