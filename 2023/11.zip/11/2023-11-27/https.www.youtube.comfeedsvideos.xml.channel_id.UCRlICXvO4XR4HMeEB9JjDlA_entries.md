# Source:Thoughty2, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRlICXvO4XR4HMeEB9JjDlA, language:en-US

## The Sneaky Tricks Napoleon Used To Win Every Battle
 - [https://www.youtube.com/watch?v=OLo-K2_AyHs](https://www.youtube.com/watch?v=OLo-K2_AyHs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRlICXvO4XR4HMeEB9JjDlA
 - date published: 2023-11-27T20:03:42+00:00

Want to restore the planet's ecosystems and see your impact in monthly videos? For the first 200 people to join Planet Wild, I will personally pay for the first month of your Planet Wild subscription at https://www.planetwild.com/thoughty2/foodforest
If you want to get to know them better first, check out their latest video here:
- Planting 40,000 trees in Senegal to overcome desertification: https://www.planetwild.com/thoughty2/9

Thoughty2 Patreon & Discord: https://www.patreon.com/thoughty2
Thoughty2 Audiobook: https://geni.us/t2audio
Thoughty2 Book: https://geni.us/t2book

Follow Thoughty2
TikTok: https://www.tiktok.com/@realthoughty2
Facebook: https://facebook.com/thoughty2
Instagram: https://instagram.com/thoughty2
Website: http://thoughty2.com

About Thoughty2
Thoughty2 (Arran) is a British YouTuber and gatekeeper of useless facts. Thoughty2 creates mind-blowing factual videos about science, tech, history, opinion and just about everything else.
#Thoughty2

Writing: Steven Rix

