# Source:Warhammer, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg, language:en-US

## How to Paint Battle Ready Legions Imperialis Rhino
 - [https://www.youtube.com/watch?v=JFYkmkWPmvg](https://www.youtube.com/watch?v=JFYkmkWPmvg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg
 - date published: 2023-11-27T12:00:16+00:00

How to Paint: Battle Ready Legions Imperialis Rhino        

A rugged and reliable armoured transport vehicle, the Rhino is relied upon to deliver Space Marines into the heart of battle. In this Warhammer painting guide, we'll be showing you how to paint the robust Rhino in the colours of the Death Guard.        

If you're new to painting - check out our Citadel Colour Painting Essentials videos to learn all about it

Follow for more Warhammer, more often:
- Twitter: https://twitter.com/warhammer
- Facebook: https://www.facebook.com/WarhammerOfficial/
- Instagram: https://www.instagram.com/warhammerofficial/
- Warhammer Community: https://www.warhammer-community.com/

## Paint Your Entire Adeptus Mechanicus Combat Patrol
 - [https://www.youtube.com/watch?v=dS35U1H_6bc](https://www.youtube.com/watch?v=dS35U1H_6bc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg
 - date published: 2023-11-27T10:06:45+00:00

Combat Patrol: Adeptus Mechanicus is here and ready to take on the battlefields of Warhammer 40,000! In this official Warhammer Painting video, we're going to show you how to batch paint your Adeptus Mechanicus in order to get them fighting for the Omnissiah in no time at all!

If you're new to painting - check out our Citadel Colour Painting Essentials videos to learn all about it

CHAPTERS
00:00 - Introduction
01:08 - Serberys Sulphurhounds
07:13 - Pteraxii Sterylizors
09:33 - Tech-Priest Manipulus
12:07 - Skitarii Vanguard

