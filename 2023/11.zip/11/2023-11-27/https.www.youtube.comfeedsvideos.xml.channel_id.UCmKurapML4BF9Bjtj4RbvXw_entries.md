# Source:The Piano Guys, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCmKurapML4BF9Bjtj4RbvXw, language:en-US

## Süsser de Glocken (Jon Schmidt Christmas Album) The Piano Guys
 - [https://www.youtube.com/watch?v=J2elpimHJEg](https://www.youtube.com/watch?v=J2elpimHJEg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmKurapML4BF9Bjtj4RbvXw
 - date published: 2023-11-27T15:25:24+00:00

Experience the magic of the holiday season with Jon Schmidt's piano rendition of the classic German Christmas carol, "Süsser die Glocken" (Sweet Are the Bells). Immerse yourself in the festive atmosphere as Jons piano interpretation brings to life the timeless melody, capturing the joy and warmth of the Christmas season. Each note resonates with the sweetness of the bells, creating a harmonious celebration of peace and goodwill. 

Whether you're looking for the perfect backdrop to your holiday gatherings or simply seeking a moment of musical bliss, let this rendition transport you to the heart of Christmas magic. Join us in spreading cheer with the timeless beauty of this beloved carol, beautifully expressed through the keys of the piano.

👉 Subscribe to our channel https://bit.ly/2XH4GCF for more heartwarming melodies that capture the spirit of the season. May "Süsser die Glocken" become a part of your holiday traditions, creating lasting memories for years to come. 

Download the A

## Silent Night Lullaby (Steven Sharp Nelson/Christmas Cello) The Piano Guys
 - [https://www.youtube.com/watch?v=Rhl3kanfKfA](https://www.youtube.com/watch?v=Rhl3kanfKfA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmKurapML4BF9Bjtj4RbvXw
 - date published: 2023-11-27T00:00:16+00:00

Close your eyes and let the harmonies envelop you in a cozy embrace as you listen to Steven Sharp Nelsons "Silent Night Lullaby". This song can be found on his album "Christmas Cello". The guitar's melodic whispers and the cello's expressive tones intertwine, breathing new life into this beloved carol. This rendition is not just a performance; it's a collaborative journey, where each instrument adds its own unique voice to the timeless melody.

Download the Album "Christmas Cello" https://thepianoguys.com/collections/albums/products/christmas-cello?variant=1990084231212

👉 Subscribe to our channel https://bit.ly/2XH4GCF for more heartwarming melodies that capture the spirit of the season. May "Silent Night Lullaby" become a part of your holiday traditions, creating lasting memories for years to come.

WE’RE ON TOUR: https://smarturl.it/the10tour 
The Piano Guys Christmas Playlist: https://www.youtube.com/watch?v=n543eKIdbUI&amp;list=PL606521018AE6D597
Learn about our beliefs: https:/

