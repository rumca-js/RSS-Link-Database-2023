# Source:Epoch Times - Tech, URL:https://feed.theepochtimes.com/tech/feed, language:en-US

## Police Warn Parents About iPhone’s New ‘NameDrop’ Feature
 - [https://www.theepochtimes.com/tech/police-warn-parents-about-iphones-new-namedrop-feature-5536388](https://www.theepochtimes.com/tech/police-warn-parents-about-iphones-new-namedrop-feature-5536388)
 - RSS feed: https://feed.theepochtimes.com/tech/feed
 - date published: 2023-11-27T12:51:19+00:00

A woman uses an iPhone mobile device as she passes a lighted Apple logo at the Apple store at Grand Central Terminal in New York on April 14, 2023. (Mike Segar/Reuters)

## Israel Hosts Wartime Visit by Elon Musk, Eyes Starlink for Gaza
 - [https://www.theepochtimes.com/world/israel-hosts-wartime-visit-by-elon-musk-eyes-starlink-for-gaza-5536087](https://www.theepochtimes.com/world/israel-hosts-wartime-visit-by-elon-musk-eyes-starlink-for-gaza-5536087)
 - RSS feed: https://feed.theepochtimes.com/tech/feed
 - date published: 2023-11-27T11:03:28+00:00

Elon Musk, Chief Executive Officer of SpaceX and Tesla and owner of X, formerly known as Twitter,  attends the Viva Technology conference dedicated to innovation and startups at the Porte de Versailles exhibition centre in Paris, France, on June 16, 2023. (Gonzalo Fuentes/Reuters)

