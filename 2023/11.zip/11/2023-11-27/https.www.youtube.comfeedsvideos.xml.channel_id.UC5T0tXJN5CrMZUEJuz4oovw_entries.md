# Source:Nerdrotic, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC5T0tXJN5CrMZUEJuz4oovw, language:en-US

## Doctor Who is DEAD | Murdered by The Message
 - [https://www.youtube.com/watch?v=f_QdVnOajWM](https://www.youtube.com/watch?v=f_QdVnOajWM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC5T0tXJN5CrMZUEJuz4oovw
 - date published: 2023-11-27T20:14:13+00:00

The Doctor Who 60th Anniversary Special is a DISASTER. You can't go home again.
RIP Doctor Who
#doctorwho #disney #BBC

Become a Nerdrotic Channel Member
www.youtube.com/c/sutrowatchtower/join

Edited by @PierryChan 

Subscribe to The Nerdrotic Network: @nerdrotic @NerdroticLive @NerdroticDaily 

Nerdrotic Merch Store!
https://mixedtees.com/nerdrotic

FNT T-Shirt!
https://mixedtees.com/nerdrotic/friday-night-tights

Sponsored by MetaPCs!
Click here to get a discount on a PC: https://www.metapcs.com/creator-nerdrotic/

Sponsored by GEEK GRIND!
Nerdrotic Blend Coffee from Geek Grind
Use Promo Code "Nerdrotic" for 20% off:
https://geekgrindcoffee.com/products/...

Nerdrotic Coffee Cup from Geek Grind:
https://geekgrindcoffee.com/products/...

