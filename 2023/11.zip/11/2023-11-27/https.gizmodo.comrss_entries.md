# Source:Gizmodo, URL:https://gizmodo.com/rss, language:en-US

## Timothy Olyphant Is Joining the Alien Universe
 - [https://gizmodo.com/alien-fx-show-noah-hawley-timothy-olyphant-prometheus-1851051651](https://gizmodo.com/alien-fx-show-noah-hawley-timothy-olyphant-prometheus-1851051651)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-11-27T23:20:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/f9363374bcc7494ea9298db15634bc89.jpg" /><p>The world of Alien just got a whole lot sexier with the addition of actor <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/timothy-olyphant-star-trek-reboot-missed-roles-1850733032">Timothy Olyphant</a>. The Justified star, who recently dipped his toe into another major sci-fi universe as <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/well-the-mandalorian-boba-fett-situation-might-have-ju-1843544487">Cobb Vanth on The Mandalorian</a> and The Book of Boba Fett, has been cast in <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/the-alien-show-has-some-good-news-and-some-not-so-good-1848557076">Noah Hawley’s upcoming FX show</a> set in the universe of Alien, <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/moms-th

## This Mandalorian Star Doesn't Agree Your Theories About Her Character
 - [https://gizmodo.com/the-mandalorian-star-wars-armorer-emily-swallow-disney-1851049437](https://gizmodo.com/the-mandalorian-star-wars-armorer-emily-swallow-disney-1851049437)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-11-27T22:20:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/d44129c6f9e361995493121b9ad0a54d.jpg" /><p>From the <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/the-mandalorian-is-here-and-star-wars-will-never-be-the-1839793444">very first episode of The Mandalorian</a>, you wanted to know about the Armorer. She was fierce. She was mysterious. And she was wise beyond her years. As we’ve <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/mandalorian-season-3-armorer-favreau-filoni-star-wars-1850168568">learned more about her</a> in subsequent seasons, that mystique <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/book-of-boba-fett-chapter-5-recap-return-of-the-mandalo-1848423500">has only grown</a>. Is she honest? Does she have ulterior motives? What’s her deal?</p><p><a href="https://gizmodo.com/the-mandalorian-star-wars-armorer-emily-swallow-disney-

## Oh, Doctor Who, We're So Back
 - [https://gizmodo.com/doctor-who-star-beast-recap-review-doctor-donna-rose-1851047392](https://gizmodo.com/doctor-who-star-beast-recap-review-doctor-donna-rose-1851047392)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-11-27T19:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/1ae6a9897ddcee793691b1f6296f00b8.png" /><p>Human drama suffused with alien weirdness? A shotgun blast of emotional sincerity to sweep you away from barely coherent sci-fi technobabble? The power of love, specifically encapsulating queer love? David Tennant and Catherine Tate running around the place having the time of their lives? Do not adjust your clocks…</p><p><a href="https://gizmodo.com/doctor-who-star-beast-recap-review-doctor-donna-rose-1851047392">Read more...</a></p>

## Avatar 2 Made More Money in 2023 Than Most of Disney's New Releases
 - [https://gizmodo.com/disney-2023-film-avatar-2-box-office-james-cameron-wish-1851049198](https://gizmodo.com/disney-2023-film-avatar-2-box-office-james-cameron-wish-1851049198)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-11-27T18:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/ff72be518b10033a96b1742a64d67493.jpg" /><p>Just when you thought <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/james-cameron-the-abyss-near-death-4k-release-avatar-1850882517">James Cameron</a> might <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/new-star-wars-movies-release-dates-delay-avatar-3-delay-1850533930">take a break from</a> winning, <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/james-cameron-4k-abyss-aliens-true-lies-release-date-1851022102">you realize he’s been beating up</a> Marvel, Lucasfilm, Disney, and Pixar without even trying. Let us explain.</p><p><a href="https://gizmodo.com/disney-2023-film-avatar-2-box-office-james-cameron-wish-1851049198">Read more...</a></p>

## California Legislators Slam ‘Rash’ NASA Cuts to Marquee Mars Mission
 - [https://gizmodo.com/california-legislators-nasa-cuts-mars-sample-return-1851049179](https://gizmodo.com/california-legislators-nasa-cuts-mars-sample-return-1851049179)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-11-27T17:55:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/2565c6658f8dd36f68e6b0fb7b6e795a.png" /><p>Six California lawmakers wrote to NASA Administrator Bill Nelson last week to oppose the agency’s recent cuts to the Mars Sample Return mission, which aims to bring samples collected by the Perseverance rover on Mars to Earth.</p><p><a href="https://gizmodo.com/california-legislators-nasa-cuts-mars-sample-return-1851049179">Read more...</a></p>

## Samsung Galaxy S24 Leaks Confirm Recent Renders
 - [https://gizmodo.com/samsung-galaxy-s24-leaks-confirm-recent-renders-1851048698](https://gizmodo.com/samsung-galaxy-s24-leaks-confirm-recent-renders-1851048698)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-11-27T15:50:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/56f0667b32e5b2f965a6bd6b52ce534e.jpg" /><p>If you liked the <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/samsung-galaxy-s24-ultra-iphone-15-pro-titanium-1850996572">Samsung Galaxy S24 Ultra renders</a> that were floating around a couple of weeks ago, then there’s good news for you. A few recently released leaks of the upcoming phone allegedly show that it is going to look exactly like the renders. These leaks were originally posted by <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://twitter.com/DavidMa05368498/status/1725258705128812569" rel="noopener noreferrer" target="_blank">DavidMa05368498</a> on X (formerly…</p><p><a href="https://gizmodo.com/samsung-galaxy-s24-leaks-confirm-recent-renders-1851048698">Read more...</a></p>

