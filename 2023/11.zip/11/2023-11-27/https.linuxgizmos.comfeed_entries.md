# Source:LinuxGizmos.com, URL:https://linuxgizmos.com/feed/, language:en-US

## IBASE announces 3.5” SBC with 13th Gen Intel Core CPUs
 - [https://linuxgizmos.com/ibase-announces-3-5-sbc-with-13th-gen-intel-core-cpus](https://linuxgizmos.com/ibase-announces-3-5-sbc-with-13th-gen-intel-core-cpus)
 - RSS feed: https://linuxgizmos.com/feed/
 - date published: 2023-11-27T07:49:29+00:00

IBASE Technology has introduced a 3.5&#8243; Single Board Computer equipped with 13th Gen Intel Core processors which utilize a performance hybrid architecture, integrating up to 6 Performance-cores (P-core) and 8 Efficient-cores (E-core), optimizing the SBC for handling demanding computing tasks. According to the product announcement, the IB961 can be configured with any of the following [&#8230;]

