# Source:Seth's Blog, URL:https://seths.blog/feed, language:en-US

## The hard part first
 - [https://seths.blog/2023/11/the-hard-part-first](https://seths.blog/2023/11/the-hard-part-first)
 - RSS feed: https://seths.blog/feed
 - date published: 2023-11-27T09:33:00+00:00

If you&#8217;re trying to reduce risk, do the hard part first. That way, if it fails, you&#8217;ll have minimized your time and effort. On the other hand, if you&#8217;re looking for buy-in and commitment so you can through the hard part, do it last. People are terrible at ignoring sunk costs, and the early wins [&#8230;]

