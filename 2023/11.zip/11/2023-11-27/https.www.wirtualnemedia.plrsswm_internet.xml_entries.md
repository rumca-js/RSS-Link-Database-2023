# Source:Wirtualne Media - Internet, URL:https://www.wirtualnemedia.pl/rss/wm_internet.xml, language:pl-PL

## Allegro skupi swoje akcje za 87 mln zł. Na nagrody dla menedżerów
 - [https://www.wirtualnemedia.pl/artykul/allegro-kurs-akcji-gielda-skup-program-motywacyjny-dla-pracownikow](https://www.wirtualnemedia.pl/artykul/allegro-kurs-akcji-gielda-skup-program-motywacyjny-dla-pracownikow)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-11-27T14:26:46.782953+00:00

Rada dyrektorów Allegro zatwierdziła skup przez spółkę akcji własnych za maksymalnie 86,9 mln zł. Celem jest realizacja nagród w ramach pracowniczego programu motywacyjnego.

## UODO nie widzi problemu: patostreamerzy mają zgodę Kononowicza na transmisje
 - [https://www.wirtualnemedia.pl/artykul/krzysztof-kononowicz-patostreamer-transmisje](https://www.wirtualnemedia.pl/artykul/krzysztof-kononowicz-patostreamer-transmisje)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-11-27T06:10:50.822771+00:00

Rzecznik Praw Obywatelskich poprosił Urząd Ochrony Danych Osobowych o interwencję w sprawie patostreamerów, nagrywających i emitujących na YouTube filmy z Krzysztofem Kononowiczem. Po roku kontrolowania, urzędnicy odpowiadają: nie ma naruszenia przepisów, autorzy nagrań mieli zgodę Kononowicza na nagrywanie i transmisję. Filmiki powstają nadal, kanał ma coraz więcej subskrybentów.

## 25 mln Polaków na Facebooku, a 13 mln na TikToku. Zyskuje Pinterest, spadek Snapchata
 - [https://www.wirtualnemedia.pl/artykul/25-mln-polakow-na-facebooku-13-mln-na-tiktoku-zyskuje-pinterest-spadek-snapchata](https://www.wirtualnemedia.pl/artykul/25-mln-polakow-na-facebooku-13-mln-na-tiktoku-zyskuje-pinterest-spadek-snapchata)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-11-27T06:10:50.820744+00:00

Z Facebooka korzysta ponad 80 proc. polskich internautów, z Instagrama - prawie połowa, a z TikToka - przeszło 40 proc. Na tym ostatnim średni użytkownik spędził w październiku 18,5 godziny, ponad trzy godziny więcej niż na Facebooku. Zmalała natomiast odwiedzalność Snapchata.

