# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## Toyota’s New Ammonia Engine (And Why It’s A Terrible Idea) | Lightning Round
 - [https://www.youtube.com/watch?v=Q_WZ9O5wULY](https://www.youtube.com/watch?v=Q_WZ9O5wULY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2023-11-27T14:51:37+00:00

Head to http://www.80000hours.org/joescott to start planning a career that is meaningful, fulfilling, and helps solve one of the world’s most pressing problems.

In today’s Lightning Round video, we’re going to talk about a recently announced ammonia engine Toyota’s been working on, along with stories about nutritional depletion in our food, a chat with author Scott Carney, and an update on the Earth With Rings video. Enjoy!

Check out Scott’s book, The Vortex, here: https://a.co/d/f6iGhFz

Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Check out my 2nd channel, Joe Scott TMI:
https://www.youtube.com/channel/UCqi721JsXlf0wq3Z_cNA_Ew

And my podcast channel, Conversations With Joe:
https://www.youtube.com/channel/UCJzc7TiJ2nnuyJkUpOZ8RKA

You can listen to my podcast, Conversations With Joe on Spotify, Apple

