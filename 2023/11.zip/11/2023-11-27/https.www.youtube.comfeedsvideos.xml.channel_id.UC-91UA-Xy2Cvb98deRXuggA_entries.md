# Source:Joshua Fluke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-91UA-Xy2Cvb98deRXuggA, language:en-US

## The Return To Office DISASTER
 - [https://www.youtube.com/watch?v=F6qzqbw7FtQ](https://www.youtube.com/watch?v=F6qzqbw7FtQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-91UA-Xy2Cvb98deRXuggA
 - date published: 2023-11-27T22:53:19+00:00

Thanks to Bespoke Post for sponsoring this video! New subscribers get 20% off their first box of awesome — go to https://bespokepost.com/jfluke20 and enter code JFLUKE20 at checkout.

❤️ Support my content on patreon! 
 https://www.patreon.com/joshuafluke

🔥 Need a resume/cover letter? Check out my templates!  
https://grindreel.com/

👊 Join the community! 
https://discord.gg/Joshuafluke

Socials🤳
https://www.tiktok.com/@joshua_fluke
https://www.instagram.com/joshuafluke/  📸
https://twitter.com/joshuafluke  🐦

📧 Email me directly!: grindreel@gmail.com
📧 Business inquiries: Joshuafluke@thoughtleaders.io  

My Gear ⚙️:  https://kit.co/JoshuaFluke


Join me, Joshua, as I humorously dissect the 'Return to Office Disaster'! In this video, I'll dive into the quirky and desperate tactics companies use to lure employees back to the office. From 'innovative' renovated conference rooms that look suspiciously ordinary to the absurdity of 'collaborative' workspaces filled with grass and blank wa

