# Source:NPR Music, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A, language:en-US

## Tiny Desk Korea: Tomorrow X Together
 - [https://www.youtube.com/watch?v=r5rCcKj84JU](https://www.youtube.com/watch?v=r5rCcKj84JU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A
 - date published: 2023-11-27T10:00:42+00:00

Sheldon Pearce | November 27, 2023
This video is part of the newly launched international version of Tiny Desk, a joint venture between NPR and LG U+, a Korean telecommunications and media company. All concerts — including the first few episodes with the Kim Chang Wan Band, Sunwoo Jung-A and the Yun Seok Cheol trio — are available on the Tiny Desk Korea YouTube channel, which will unveil a new video every Thursday.

The boys of Tomorrow X Together, or TXT, began as the only act in the immediate orbit of the K-pop titans BTS. Created by the masterminds at Big Hit Music, the group has always had to manage certain expectations — even as a standout of K-pop's fourth generation, it seemed to be searching for an identity separate from the art-rap reputation established by its label. TXT's most recent album, The Name Chapter: Freefall, captures its sprawling ambitions: from new wave-y retro-pop to bassy, beaming dance music; the mildly grungy to flat-out nu metal. The group's performance of

