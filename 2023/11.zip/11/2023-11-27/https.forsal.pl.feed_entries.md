# Source:Forsal.pl, URL:https://forsal.pl/.feed, language:pl-PL

## Holenderski raport: W ciągu 3 lat ponad 900 urzędników przyłapano na kradzieżach i oszustwach
 - [https://forsal.pl/swiat/artykuly/9365312,holenderski-raport-w-ciagu-3-lat-ponad-900-urzednikow-przylapano-na-kradziezach-i-oszustwach.html](https://forsal.pl/swiat/artykuly/9365312,holenderski-raport-w-ciagu-3-lat-ponad-900-urzednikow-przylapano-na-kradziezach-i-oszustwach.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T22:06:03+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/UiUktkuTURBXy81NWJkNjA0Yi0wZWRlLTRmNzEtYTcyMi1kOTE5ZTc3MmQzMzcuanBlZ5GTBc0BHcyg" />Ponad 900 urzędników samorządowych zostało przyłapanych w ostatnich trzech latach na kradzieżach i oszustwach, informuje w poniedziałek portal RTL Nieruws, przedstawiając raport przygotowany na podstawie danych ze wszystkich holenderskich gmin.

## Jarmarki bożonarodzeniowe w Niemczech. Biznes wart miliardy euro
 - [https://forsal.pl/lifestyle/turystyka/artykuly/9365234,jarmarki-bozonarodzeniowe-w-niemczech-biznes-wart-miliardy-euro.html](https://forsal.pl/lifestyle/turystyka/artykuly/9365234,jarmarki-bozonarodzeniowe-w-niemczech-biznes-wart-miliardy-euro.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T22:00:28+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/wUPktkuTURBXy84YzNkYmU5OC00N2ZkLTRjYzctOTRlMi03ZmRiYzRlMzE3ZmUuanBlZ5GTBc0BHcyg" />Wiele z około 3000 jarmarków bożonarodzeniowych w Niemczech otworzyło w poniedziałek swoje podwoje. Choć wiele jarmarków ma wielowiekowe tradycje, dopiero w ostatnich latach stały się one biznesem, który jest wart miliardy - pisze dziennik &quot;Frankfurter Allgemeine Zeitung&quot; (FAZ). Jarmarki przyciągają miliony odwiedzających.

## "Korea Północna przekazała Rosji ponad tysiąc kontenerów ze sprzętem wojskowym"
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9365220,korea-polnocna-przekazala-rosji-ponad-tysiac-kontenerow-ze-sprzetem-wojskowym.html](https://forsal.pl/swiat/aktualnosci/artykuly/9365220,korea-polnocna-przekazala-rosji-ponad-tysiac-kontenerow-ze-sprzetem-wojskowym.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T21:11:32+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Hr-ktkuTURBXy9jNjgwOTU1ZC1kYjNhLTRiNjctOWI4Mi1lZTIwNjk2NzMzZWYuanBlZ5GTBc0BHcyg" />Korea Północna przekazała Rosji ponad tysiąc kontenerów ze sprzętem wojskowym - powiedziała w poniedziałek w Radzie Bezpieczeństwa ambasador USA przy ONZ Linda Thomas-Greenfield. Ostrzegła, że współpraca obu reżimów się pogłębia wbrew ONZ-owskim sankcjom.

## Letnie Igrzyska Olimpijskie w Paryżu 2024. Bilety na metro będą prawie dwa razy droższe
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9365219,igrzyska-olimpijskie-w-paryzu-2024-bilety-na-metro-beda-prawie-dwa-razy-drozsze.html](https://forsal.pl/swiat/aktualnosci/artykuly/9365219,igrzyska-olimpijskie-w-paryzu-2024-bilety-na-metro-beda-prawie-dwa-razy-drozsze.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T21:01:01+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/u9dktkuTURBXy8yNTRmYjA1NC0xYTQwLTQwNjUtYTJiNy00NmJmZTk1YTM2NDkuanBlZ5GTBc0BHcyg" />Podczas przyszłorocznych igrzysk olimpijskich w Paryżu bilety na metro będą prawie dwa razy droższe w związku koniecznością sfinansowania dodatkowego transportu - poinformował Związek Transportu regionu Ile-de-France (IDFM).

## Morawiecki: Oni chcą być takim tłustym, brukselskim kanapowym kotem
 - [https://forsal.pl/gospodarka/polityka/artykuly/9365211,morawiecki-oni-chca-byc-takim-tlustym-brukselskim-kanapowym-kotem.html](https://forsal.pl/gospodarka/polityka/artykuly/9365211,morawiecki-oni-chca-byc-takim-tlustym-brukselskim-kanapowym-kotem.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T20:41:14+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/wOKktkuTURBXy9mMjdkZmM2Yi1lMTdmLTRlYTItOTMzYS01NzBlNWIxMjMzYWEuanBlZ5GTBc0BHcyg" />Teraz może przejść przez Parlament Europejski niezwykle groźna dla Polski regulacja, która może nas pozbawić naszych kompetencji i możliwości decydowania. Polska może się stać zaledwie kolejnym województwem lub departamentem w Unii - powiedział w TVP Info premier Mateusz Morawiecki.

## Elektrownie jądrowe. Sasin: Spór między Westinghouse i KHNP o technologię zostanie rozwiązany
 - [https://forsal.pl/biznes/aktualnosci/artykuly/9365137,elektrownie-jadrowe-sasin-spor-miedzy-westinghouse-i-khnp-o-technologie-zostanie-rozwiazany.html](https://forsal.pl/biznes/aktualnosci/artykuly/9365137,elektrownie-jadrowe-sasin-spor-miedzy-westinghouse-i-khnp-o-technologie-zostanie-rozwiazany.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T20:03:21+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/KS8ktkuTURBXy9hMTdhYjFiZS1iNzBmLTRmMzQtOGRkZS1hM2E4ZjYwM2RiNDIuanBlZ5GTBc0BHcyg" />Jestem absolutnie spokojny o to, że spór między Westinghouse i KHNP o technologię budowy elektrowni jądrowych zostanie rozwiązany i taka inwestycja w Polsce będzie mogła być realizowana - stwierdził w poniedziałek były minister aktywów państwowych Jacek Sasin.

## Odtworzenie wymarłego ptaka dodo? Jest umowa ws. projektu
 - [https://forsal.pl/lifestyle/nauka/artykuly/9365094,odtworzenie-wymarlego-ptaka-dodo-jest-umowa-ws-projektu.html](https://forsal.pl/lifestyle/nauka/artykuly/9365094,odtworzenie-wymarlego-ptaka-dodo-jest-umowa-ws-projektu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T19:50:57+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/5AnktkuTURBXy82OTMzNTUwZS0xYmNkLTQ0ZTMtYWQ5Ny0xMDRjYTdjZjZiY2UuanBlZ5GTBc0BHcyg" />Amerykańska firma ,zajmująca się biotechnologią i inżynierią genetyczną, podpisała z pozarządową organizacją Mauritian Wildlife Foundation umowę mającą na celu odtworzenie wymarłego w XVII stuleciu ptaka dodo - poinformowała w poniedziałek BBC.

## Kiedy Kongres USA uchwali nowy pakiet środków dla Ukrainy i Izraela?
 - [https://forsal.pl/swiat/usa/artykuly/9365090,kiedy-kongres-usa-uchwali-nowy-pakiet-srodkow-dla-ukrainy-i-izraela.html](https://forsal.pl/swiat/usa/artykuly/9365090,kiedy-kongres-usa-uchwali-nowy-pakiet-srodkow-dla-ukrainy-i-izraela.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T19:37:17+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/tKvktkuTURBXy8xZTM4Mjk4Mi02ZDJlLTRjNDEtYTZmZC1lMTQ4NTlkOGE4MWUuanBlZ5GTBc0BHcyg" />Spiker amerykańskiej Izby Reprezentantów Mike Johnson wyraził w poniedziałek &quot;optymizm i pewność&quot;, że Kongres będzie w stanie uchwalić dodatkowe środki na pomoc Ukrainie i Izraelowi przed świąteczną przerwą. Dodał jednak, że w pakiecie muszą znaleźć się też zmiany w polityce imigracyjnej.

## Wyciek danych pacjentów w ALAB. Są nowe doniesienia
 - [https://forsal.pl/lifestyle/technologie/artykuly/9365086,wyciek-danych-pacjentow-w-alab-sa-nowe-doniesienia.html](https://forsal.pl/lifestyle/technologie/artykuly/9365086,wyciek-danych-pacjentow-w-alab-sa-nowe-doniesienia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T19:10:25+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/8t1ktkuTURBXy9hNDJiOWRiZC1kMDBhLTRkMTYtOTcwMS1lNzJhOGNlY2RlMDEuanBlZ5GTBc0BHcyg" />Spółka zgłosiła naruszenie do Prezesa Urzędu Ochrony Danych Osobowych, poinformowała uprawnione instytucje oraz złożyła zawiadomienie o podejrzeniu popełnienia przestępstwa do Centralnego Biura Zwalczania Cyberprzestępczości - poinformowała spółka ALAB laboratoria odnosząc się do wycieku wyników badań pacjentów.

## Zakaz sprzedaży papierosów? Ten kraj wycofuje się z pomysłu. "Ogromne zwycięstwo przemysłu tytoniowego"
 - [https://forsal.pl/biznes/handel/artykuly/9365077,zakaz-sprzedazy-papierosow-ten-kraj-wycofuje-sie-z-pomyslu-ogromne-zwyciestwo-przemyslu-tytoniowego.html](https://forsal.pl/biznes/handel/artykuly/9365077,zakaz-sprzedazy-papierosow-ten-kraj-wycofuje-sie-z-pomyslu-ogromne-zwyciestwo-przemyslu-tytoniowego.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T17:58:25+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/sIVktkuTURBXy82ZjU2ZTZiMS0zZDcxLTRkMmQtODM2Ny04YWNhNGNiYzg2NTguanBlZ5GTBc0BHcyg" />Nowy konserwatywny rząd Nowej Zelandii wycofa się z ambitnego planu walki z paleniem papierosów - potwierdził w poniedziałek nowy premier Christopher Luxon. Przegłosowany wcześniej tzw. pokoleniowy zakaz palenia zakładał zakaz sprzedaży papierosów osobom urodzonym po 2008 roku.

## Zawieszenie broni między Izraelem a Hamasem. "Zostało przedłużone o dwa dni"
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9364939,zawieszenie-broni-miedzy-izraelem-a-hamasem-msz-kataru-zostalo-przedluzone-o-dwa-dni.html](https://forsal.pl/swiat/aktualnosci/artykuly/9364939,zawieszenie-broni-miedzy-izraelem-a-hamasem-msz-kataru-zostalo-przedluzone-o-dwa-dni.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T16:56:49+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/MLiktkuTURBXy8yOTkzZTFkOS1lMWM3LTQ0OTAtOTVjNS0zZmQzYjYzMTJmMGQuanBlZ5GTBc0BHcyg" />Ministerstwo spraw zagranicznych Kataru poinformowało w poniedziałek po południu, że zawieszenie broni między Izraelem a Hamasem zostało przedłużone o dwa dni. Katar wraz z Egiptem i USA pełni rolę mediatorów w negocjacjach pokojowych.

## "Bezpieczny kredyt 2 proc.". Ile umów podpisano? [DANE]
 - [https://forsal.pl/biznes/bankowosc/artykuly/9364905,bezpieczny-kredyt-2-proc-ile-umow-podpisano-dane.html](https://forsal.pl/biznes/bankowosc/artykuly/9364905,bezpieczny-kredyt-2-proc-ile-umow-podpisano-dane.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T16:52:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/4s0ktkuTURBXy8yZDA1MzM2ZC1iMDAxLTQ5MmEtOGIwOC0xM2MyYzRiNzZiNDcuanBlZ5GTBc0BHcyg" />undefined

## PGG: Po obniżce cen węgla sprzedaż w e-sklepie wzrosła niemal dziesięciokrotnie
 - [https://forsal.pl/biznes/energetyka/artykuly/9364849,pgg-po-obnizce-cen-wegla-sprzedaz-w-e-sklepie-wzrosla-niemal-dziesieciokrotnie.html](https://forsal.pl/biznes/energetyka/artykuly/9364849,pgg-po-obnizce-cen-wegla-sprzedaz-w-e-sklepie-wzrosla-niemal-dziesieciokrotnie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T16:44:13+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Z3IktkuTURBXy85YmM4NmU0My1jYTc1LTQ1YmMtODIwNS1lYTg0YmI0ZjZhNzkuanBlZ5GTBc0BHcyg" />Czasowa obniżka ceny węgla opałowego o 200 zł na tonie przyniosła niemal dziesięciokrotny wzrost sprzedaży w sklepie internetowym Polskiej Grupy Górniczej (PGG) - poinformowała w poniedziałek spółka, która po raz pierwszy przygotowała dla nabywców paliwa ofertę pod hasłem Black Weeks.

## Nie tylko Holandia. Na jakie poparcie mogą liczyć największe partie prawicowe w Europie? [MAPA]
 - [https://forsal.pl/gospodarka/polityka/artykuly/9361850,nie-tylko-holandia-na-jakie-poparcie-moga-liczyc-najwieksze-partie-pr.html](https://forsal.pl/gospodarka/polityka/artykuly/9361850,nie-tylko-holandia-na-jakie-poparcie-moga-liczyc-najwieksze-partie-pr.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T16:39:32+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/JOhktkuTURBXy8zZDUzZDJkYi00ZjhmLTQ0YjItOTIxNC04Y2ZjMDFkMjU1YTYuanBlZ5GTBc0BHcyg" />W środę skrajnie prawicowa, populistyczna, eurosceptyczna i antyimigrancka PVV (Partia Wolności), na czele której stoi Geert Wilders, zwyciężyła w holenderskich wyborach parlamentarnych. Sprawdź, jak silną reprezentację w innych krajach Europy mają partie o podobnych poglądach.

## Prezydent Andrzej Duda powołał nowy rząd Mateusza Morawieckiego
 - [https://forsal.pl/gospodarka/polityka/artykuly/9364840,prezydent-andrzej-duda-powolal-nowy-rzad-mateusza-morawieckiego.html](https://forsal.pl/gospodarka/polityka/artykuly/9364840,prezydent-andrzej-duda-powolal-nowy-rzad-mateusza-morawieckiego.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T16:15:39+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/_EdktkuTURBXy8wNWY1ZDhkYy1lM2I1LTQxOTEtYjM1ZC01MzNjN2NjODQ1MzIuanBlZ5GTBc0BHcyg" />Prezydent Andrzej Duda zaprzysiągł w poniedziałek po południu Mateusza Morawieckiego na Prezesa Rady Ministrów; powołał także nowy rząd.

## Jeden z największych strajków w historii Czech. Oto powód protestów
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9364836,jeden-z-najwiekszych-strajkow-w-historii-czech-oto-powod-protestow.html](https://forsal.pl/swiat/aktualnosci/artykuly/9364836,jeden-z-najwiekszych-strajkow-w-historii-czech-oto-powod-protestow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T16:04:19+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Y2gktkuTURBXy8xNmJiMTM2MS1mOGRiLTRhN2MtYjBiZS02YWNhNmFiZjRmYTAuanBlZ5GTBc0BHcyg" />Czeskie związki zawodowe przeprowadziły w poniedziałek dwugodzinny strajk, który był jednym z największych takich protestów w historii. Protestowano przeciwko polityce centroprawicowego rządu, między innymi przeciwko pakietowi oszczędnościowemu. Osobny, całodzienny strajk zorganizowali związkowcy działający w edukacji.

## Elon Musk: Należy położyć kres propagandzie, która prowadzi do morderstw
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9364769,elon-musk-nalezy-polozyc-kres-propagandzie-ktora-prowadzi-do-morderstw.html](https://forsal.pl/swiat/aktualnosci/artykuly/9364769,elon-musk-nalezy-polozyc-kres-propagandzie-ktora-prowadzi-do-morderstw.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T15:32:26+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ESaktkuTURBXy8xZTAzMGE4ZS00NmI2LTQ2N2QtOTZkNi03MTc5NGExYzk0ZTMuanBlZ5GTBc0BHcyg" />Właściciel platformy X Elon Musk odwiedził w poniedziałek Izrael i spotkał się z premierem Benjaminem Netanjahu. Miliarder wyraził poparcie dla walki Izraela z Hamasem i zapowiedział położenie kresu propagandzie, która prowadzi do morderstw - relacjonuje agencja Reutera.

## Kobiety szturmują Sejm i rząd. Jaka jest ich pozycja w polskiej polityce?
 - [https://forsal.pl/gospodarka/polityka/artykuly/9364657,kobiety-szturmuja-sejm-i-rzad-jaka-jest-ich-pozycja-w-polskiej-polity.html](https://forsal.pl/gospodarka/polityka/artykuly/9364657,kobiety-szturmuja-sejm-i-rzad-jaka-jest-ich-pozycja-w-polskiej-polity.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T15:30:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/DooktkuTURBXy82OWVhMTJlZS0zNWQxLTRkMzQtYTc4MC1jNTQyNmJkMjUwYjIuanBlZ5GTBc0BHcyg" />Znaczenie Polek w polskiej polityce już od dawna rośnie. Z kadencji na kadencję zwiększa się także liczba kobiet zajmujących ministerialne stanowiska. Ile w polskim rządzie było dotychczas kobiet i które ministerstwa były przez nie kierowane?

## Społem zmienia strategię dla swoich klientów
 - [https://forsal.pl/biznes/handel/artykuly/9361957,spolem-zmienia-strategie-dla-swoich-klientow.html](https://forsal.pl/biznes/handel/artykuly/9361957,spolem-zmienia-strategie-dla-swoich-klientow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T14:43:52+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/dMmktkuTURBXy9jZDliZThmYi1mNGI5LTRlNGMtYjc4Ny1lZTlhZWY0ZjFhZDAuanBlZ5GTBc0BHcyg" />Sieć spożywczych sklepów Społem, staje przed wyzwaniem adaptacji do zmieniającego się rynku.

## Ceny mieszkań w Polsce. Co przyniosą najbliższe miesiące?
 - [https://forsal.pl/nieruchomosci/mieszkania/artykuly/9364735,ceny-mieszkan-w-polsce-co-przyniosa-najblizsze-miesiace.html](https://forsal.pl/nieruchomosci/mieszkania/artykuly/9364735,ceny-mieszkan-w-polsce-co-przyniosa-najblizsze-miesiace.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T14:40:34+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/QL5ktkuTURBXy8zODMxOGY5YS02NDg5LTQ4ZmMtOGZhNC03NzZlODI2YmVlMWIuanBlZ5GTBc0BHcyg" />Październik był trzecim miesiącem z rzędu, kiedy deweloperzy rozpoczęli w Polsce budowę ponad 10 tys. mieszkań. W najbliższych miesiącach można spodziewać się uspokojenia na rynku mieszkaniowym, co wyhamowałoby dynamikę wzrostu cen - uważa ekspert Otodom Marcin Krasoń.

## Sprawa Jarosława Ziętary. Świadek: Gawronik powiedział, że trzeba uciszyć dziennikarza
 - [https://forsal.pl/gospodarka/prawo/artykuly/9364674,sprawa-jaroslawa-zietary-swiadek-gawronik-powiedzial-ze-trzeba-uciszyc-dziennikarza.html](https://forsal.pl/gospodarka/prawo/artykuly/9364674,sprawa-jaroslawa-zietary-swiadek-gawronik-powiedzial-ze-trzeba-uciszyc-dziennikarza.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T13:35:37+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Tp9ktkuTURBXy9mZjc3N2EzYy05YzBmLTQ0NjQtOGUzYy05ZTJmZDU2NTQ1OTQuanBlZ5GTBc0BHcyg" />Gawronik powiedział, że jest dziennikarz, który mu bardzo przeszkadza, że trzeba go uciszyć, chodziło o Jarosława Ziętarę – zeznał w poniedziałek Ryszard B., nowy świadek w procesie apelacyjnym b. senatora Aleksandra Gawronika, osk. o podżeganie do zabójstwa poznańskiego dziennikarza.

## ZUS ostrzega: Informacja o wyrównaniu świadczenia 500+ do kwoty 800 zł to fake news
 - [https://forsal.pl/gospodarka/finanse-publiczne/artykuly/9364535,zus-ostrzega-informacja-o-wyrownaniu-swiadczenia-500-do-kwoty-800-zl.html](https://forsal.pl/gospodarka/finanse-publiczne/artykuly/9364535,zus-ostrzega-informacja-o-wyrownaniu-swiadczenia-500-do-kwoty-800-zl.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T12:20:46+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/bDgktkuTURBXy9iNDZlZmJmZC00ZDcxLTQxZGItOGQyZi0zOGFjNmQ4YWJhOWYuanBlZ5GTBc0BHcyg" />Wyrównanie świadczenia 500+ do kwoty 800 zł za okres od sierpnia 2023 r. do grudnia 2023 r. to fałszywa informacja, która krąży w internecie – wskazał Zakład Ubezpieczeń Społecznych.

## Ustawa mrożąca ceny prądu przywróci obligo i „uwolni” wiatraki
 - [https://forsal.pl/biznes/energetyka/artykuly/9364536,ustawa-mrozaca-ceny-pradu-przywroci-obligo-i-uwolni-wiatraki.html](https://forsal.pl/biznes/energetyka/artykuly/9364536,ustawa-mrozaca-ceny-pradu-przywroci-obligo-i-uwolni-wiatraki.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T12:19:05+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/XTZktkuTURBXy8wZmExZjAwMC0zYzdjLTRlOWQtYTI3My0zMDgzZmM5Zjg1MjIuanBlZ5GTBc0BHcyg" />DGP poznał wstępne założenia ustawy mrożącej ceny energii na 2024 r. Ceny zostaną ustawowo utrzymane na obecnym poziomie do końca czerwca. Koalicja KO-Trzecia Droga-Lewica chce jednocześnie odwrócić dwie inne kontrowersyjne zmiany wprowadzone w czasie rządów Prawa i Sprawiedliwości - w tym tę o odległości turbin wiatrowych od budynków mieszkalnych.

## Największy wyciek danych medycznych w Polsce. Alab milczy na ten temat
 - [https://forsal.pl/lifestyle/zdrowie/artykuly/9364521,najwiekszy-wyciek-danych-medycznych-w-polsce-alab-milczy-na-ten-temat.html](https://forsal.pl/lifestyle/zdrowie/artykuly/9364521,najwiekszy-wyciek-danych-medycznych-w-polsce-alab-milczy-na-ten-temat.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T12:08:52+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/LR9ktkuTURBXy80ZDZmMjU4MC00NzM1LTRmMDktYWMxNy0xYTljOTdjNzRmNzAuanBlZ5GTBc0BHcyg" />Do sieci trafiły informacje o 50 tys. pacjentach Alabu. Hakerzy żądali okupu. Dostęp do danych ma już ponad 100 osób. Tymczasem spółka milczy na ten temat.

## Stoltenberg: Nielegalna migracja to sposób Kremla na destabilizację sytuacji w europejskich krajach
 - [https://forsal.pl/swiat/rosja/artykuly/9364520,stoltenberg-nielegalna-migracja-to-sposob-kremla-na-destabilizacje-sy.html](https://forsal.pl/swiat/rosja/artykuly/9364520,stoltenberg-nielegalna-migracja-to-sposob-kremla-na-destabilizacje-sy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T12:07:42+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/3iBktkuTURBXy9mMDhjYTM5OS1lZWE0LTRlMjgtODMwYi0zZDRmOTIyMTZmYzguanBlZ5GTBc0BHcyg" />Sytuacja na granicy fińsko-rosyjskiej pokazuje, że Kreml używa migrantów jako narzędzia do wywierania presji na europejskie państwa - powiedział w poniedziałek na konferencji prasowej w kwaterze głównej NATO w Brukseli sekretarz generalny Sojuszu Jens Stoltenberg.

## Allegro przyjęło program buy-backu wart max. 86,9 mln zł na cele programu motywacyjnego
 - [https://forsal.pl/finanse/gielda/artykuly/9364516,allegro-przyjelo-program-buy-backu-wart-max-869-mln-zl-na-cele-progr.html](https://forsal.pl/finanse/gielda/artykuly/9364516,allegro-przyjelo-program-buy-backu-wart-max-869-mln-zl-na-cele-progr.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T12:03:10+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/avkktkuTURBXy9iZDQ4ZWU4Yy02MTY0LTRlYmItYjFmZS05NzRiMzc5ZGExMmQuanBlZ5GTBc0BHcyg" />undefined

## InPost zwiększył sieć paczkomatów w Europie o 2 tys., w UK ma 6 tys. i 4 tys. we Francji
 - [https://forsal.pl/finanse/gielda/artykuly/9364515,inpost-zwiekszyl-siec-paczkomatow-w-europie-o-2-tys-w-uk-ma-6-tys-i.html](https://forsal.pl/finanse/gielda/artykuly/9364515,inpost-zwiekszyl-siec-paczkomatow-w-europie-o-2-tys-w-uk-ma-6-tys-i.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T12:01:09+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/u-FktkuTURBXy9jZTE1ZGYyNi0zNjU5LTQ5NzQtODk2OC0zOGRhMTE3MjM4ZTMuanBlZ5GTBc0BHcyg" />undefined

## Amica spodziewa się zysku netto na koniec 2023 roku
 - [https://forsal.pl/finanse/gielda/artykuly/9364509,amica-spodziewa-sie-zysku-netto-na-koniec-2023-roku.html](https://forsal.pl/finanse/gielda/artykuly/9364509,amica-spodziewa-sie-zysku-netto-na-koniec-2023-roku.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T11:58:07+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/CXHktkuTURBXy9iMWFiYmIwZi1lZjI5LTQ3ODQtOTdiYi0zODI5ZmIxYmFiZjYuanBlZ5GTBc0BHcyg" />undefined

## Dekpol miał portfolio kontraktów łącznie na 1,54 mld zł na koniec III kw. 2023 r.
 - [https://forsal.pl/finanse/gielda/artykuly/9364505,dekpol-mial-portfolio-kontraktow-lacznie-na-154-mld-zl-na-koniec-iii.html](https://forsal.pl/finanse/gielda/artykuly/9364505,dekpol-mial-portfolio-kontraktow-lacznie-na-154-mld-zl-na-koniec-iii.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T11:55:21+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/DtcktkuTURBXy84OTllYTg0Ni0zMWU2LTQwYmQtYjIxZC00NzJiOTQ4MjlmOWMuanBlZ5GTBc0BHcyg" />undefined

## Antyimigrancka Partia Wolności przekreśliła szanse holenderskiego premiera na objęcie stanowiska szefa NATO
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9364501,antyimigrancka-partia-wolnosci-przekreslila-szanse-holenderskiego-prem.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9364501,antyimigrancka-partia-wolnosci-przekreslila-szanse-holenderskiego-prem.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T11:54:05+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/6dnktkuTURBXy84MzI5NjVmOC1lZWY0LTQ2MzktODExYi1jNGU5YmVkNzU1MDEuanBlZ5GTBc0BHcyg" />Zwycięstwo prawicowej i antyimigranckiej Partii Wolnosci (PVV) w wyborach parlamentarnych może zaszkodzić staraniom premiera Marka Ruttego w objęciu funkcji sekretarza generalnego Paktu Północnoatlantyckiego - informuje w poniedziałek portal NOS.

## Wesoły z MAP: Rząd zabezpieczył górnicze spółki. Złożył autopoprawkę do projektu budżetu
 - [https://forsal.pl/gospodarka/finanse-publiczne/artykuly/9364427,wesoly-z-map-rzad-zabezpieczyl-gornicze-spolki-zlozyl-autopoprawke-d.html](https://forsal.pl/gospodarka/finanse-publiczne/artykuly/9364427,wesoly-z-map-rzad-zabezpieczyl-gornicze-spolki-zlozyl-autopoprawke-d.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T11:29:51+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/8UfktkuTURBXy8xZmIzMGI1ZC01YTU2LTQ2MDgtYTMxMS0yN2UzMDNiMzY3ZGMuanBlZ5GTBc0BHcyg" />Rząd przygotuje autopoprawkę do projektu budżetu państwa, dzięki której obligacje o wartości 7 mld zł zostaną przeznaczone na pomoc dla Polskiej Grupy Górniczej i dwóch innych górniczych spółek, objętych programem wsparcia - poinformował w poniedziałek PAP wiceminister aktywów państwowych Marek Wesoły.

## Amica miała 2,2 mln zł zysku netto, 18,5 mln zł zysku EBIT w III kw. 2023 r.
 - [https://forsal.pl/finanse/gielda/artykuly/9364395,amica-miala-22-mln-zl-zysku-netto-185-mln-zl-zysku-ebit-w-iii-kw-2.html](https://forsal.pl/finanse/gielda/artykuly/9364395,amica-miala-22-mln-zl-zysku-netto-185-mln-zl-zysku-ebit-w-iii-kw-2.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T11:24:40+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/V-JktkuTURBXy9kZDAyOGMwMi02ZGVkLTQ0NzMtODA2MC1hNjliZThlY2RiZDMuanBlZ5GTBc0BHcyg" />undefined

## Koronawirus w Polsce: 97 zakażeń, nie było przypadków śmiertelnych [DANE Z 27.11]
 - [https://forsal.pl/artykuly/1458115,koronawirus-w-polsce-97-zakazen-nie-bylo-przypadkow-smiertelnych-da.html](https://forsal.pl/artykuly/1458115,koronawirus-w-polsce-97-zakazen-nie-bylo-przypadkow-smiertelnych-da.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T09:48:01+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/3QYktkuTURBXy9lNjE1ZGFlZC02OTg5LTQzNzItOTg5OS1jZWEzOWVhODg4OWYuanBlZ5GTBc0BHcyg" />Minionej doby badania potwierdziły 97 zakażeń koronawirusem, w tym 16 ponownych. Z powodu COVID-19 nie zmarł żaden pacjent – poinformowano w poniedziałek na stronach rządowych. Wykonano 589 testów w kierunku SARS-CoV-2.

## Kaczyński o utworzeniu nowego gabinetu Morawieckiego: Kształt rządu ekspercko-politycznego to mój pomysł
 - [https://forsal.pl/gospodarka/polityka/artykuly/9363762,kaczynski-o-utworzeniu-nowego-gabinetu-morawieckiego-ksztalt-rzadu-ek.html](https://forsal.pl/gospodarka/polityka/artykuly/9363762,kaczynski-o-utworzeniu-nowego-gabinetu-morawieckiego-ksztalt-rzadu-ek.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T08:52:04+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ZeFktkuTURBXy9kMTc0YmFjYi1lNWE4LTQzNGQtYjdkMS0zMTNiMzk0YmUyNTYuanBlZ5GTBc0BHcyg" />Kształt rządu ekspercko-politycznego, który w poniedziałek przedstawi premier Mateusz Morawiecki, to mój pomysł. Chcemy zaproponować nowe twarze - mówi w rozmowie z PAP prezes Prawa i Sprawiedliwości Jarosław Kaczyński. Trzeba zakończyć wojnę, którą prowadzi Platforma Obywatelska - podkreśla.

## Od poniedziałku ćwiczenie wojsk cybernetycznych NATO "Cyber Coalition 2023"
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9363781,od-poniedzialku-cwiczenie-wojsk-cybernetycznych-nato-cyber-coalition.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9363781,od-poniedzialku-cwiczenie-wojsk-cybernetycznych-nato-cyber-coalition.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T08:44:04+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/UQEktkuTURBXy9mOWEyMGI0NC00MTQzLTRkYTItYmJmNC0zMDI2Y2VjMDE2ZmUuanBlZ5GTBc0BHcyg" />W poniedziałek rozpoczyna się doroczne ćwiczenie wojsk cybernetycznych państw NATO &quot;Cyber Coalition 2023&quot;; w tym roku Polska będzie pełnić rolę dowództwa dla państw regionu. Rzecznik Wojsk Obrony Cyberprzestrzeni uważa, że to wyraz dużego zaufania sojuszników do naszych WOC.

## Tarcia w Lewicy. Czarzasty skrytykował pomysł Millera dotyczący utworzenia rządu Morawieckiego
 - [https://forsal.pl/gospodarka/polityka/artykuly/9363520,tarcia-w-lewicy-czarzasty-skrytykowal-pomysl-millera-dotyczacy-utworz.html](https://forsal.pl/gospodarka/polityka/artykuly/9363520,tarcia-w-lewicy-czarzasty-skrytykowal-pomysl-millera-dotyczacy-utworz.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T08:02:35+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/w-cktkuTURBXy9lNDZkYzkwZi1lY2RmLTQwOTItYThlZi0xNzg2ZGI2NzA1MGEuanBlZ5GTBc0BHcyg" />Nie słucham Leszka Millera, bo on ma trochę oderwane od życia pomysły - powiedział w poniedziałek w Polsat News współprzewodniczący Nowej Lewicy, wicemarszałek Sejmu Włodzimierz Czarzasty, odnosząc się do wypowiedzi byłego premiera Leszka Millera, dotyczącego wniosku o konstruktywne wotum nieufności.

## Hakerzy ujawnili wyniki badań medycznych kilkudziesięciu tysięcy pacjentów. Czy to przestroga dla sektora opieki zdrowotnej?
 - [https://forsal.pl/biznes/aktualnosci/artykuly/9363502,hakerzy-ujawnili-wyniki-badan-medycznych-kilkudziesieciu-tysiecy-pacje.html](https://forsal.pl/biznes/aktualnosci/artykuly/9363502,hakerzy-ujawnili-wyniki-badan-medycznych-kilkudziesieciu-tysiecy-pacje.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T07:50:19+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/eVAktkuTURBXy9lZDRmNDM5Ny00YTYzLTQ4YTEtYjFjNi00OTc4MzY5NTZlM2MuanBlZ5GTBc0BHcyg" />Niedawny cyberatak na ALAB, jedną z największych sieci laboratoriów medycznych w Polsce, stanowi drastyczne przypomnienie o narastających ekonomicznych zagrożeniach, jakie niosą ataki ransomware w sektorze opieki zdrowotnej. Ale skutki tej akcji odczuje co najmniej kilkadziesiąt tysięcy Polek i Polaków, którzy od roku 2017 do 2023 wykonywali badania medyczne w sieci ALAB laboratoria.

## Czy rozejm w Strefie Gazy będzie przedłużony? Netanjahu nie oponuje
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9363286,czy-rozejm-w-strefie-gazy-bedzie-przedluzony-netanjahu-nie-oponuje.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9363286,czy-rozejm-w-strefie-gazy-bedzie-przedluzony-netanjahu-nie-oponuje.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T06:58:55+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/yU4ktkuTURBXy9hZDljNmQ0Yi03NTI4LTQwYzUtODJmNy03ZmQxN2E2Yjg4MzEuanBlZ5GTBc0BHcyg" />Prezydent USA Joe Biden rozmawiał w niedzielę z premierem Izraela Benjaminem Netanjahu, aby omówić sytuację w Gazie. Prezydent z zadowoleniem przyjął uwolnienie przez Hamas w ciągu ostatnich trzech dni zakładników, w tym młodej Amerykanki - poinformował w niedzielę Biały Dom. Netanjahu wyraził gotowość do przedłużenia rozejmu z Hamasem.

## Przepisy zmuszą producentów do naprawy sprzętu nawet po gwarancji. To nie wszystkie zmiany
 - [https://forsal.pl/swiat/unia-europejska/artykuly/9362985,przepisy-zmusza-producentow-do-naprawy-sprzetu-nawet-po-gwarancji-to.html](https://forsal.pl/swiat/unia-europejska/artykuly/9362985,przepisy-zmusza-producentow-do-naprawy-sprzetu-nawet-po-gwarancji-to.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T06:51:37+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/fJ3ktkuTURBXy9jZTczODkzZi0wZTc5LTRjZGQtYmY5OS1iMzhmNTM1NjBjZTQuanBlZ5GTBc0BHcyg" />Przepisy, które mają promować naprawianie towarów, są już gotowe do negocjacji między Parlamentem Europejskim, Radą i Komisją Europejską. W ubiegłym tygodniu mandat negocjacyjny w sprawie dyrektywy o prawie do naprawy przyjęła Rada UE, a wcześniej swoje stanowisko przegłosował europarlament.

## Nasz eksport słaby, ale i tak błyszczy na tle UE
 - [https://forsal.pl/swiat/unia-europejska/artykuly/9363170,nasz-eksport-slaby-ale-i-tak-blyszczy-na-tle-ue.html](https://forsal.pl/swiat/unia-europejska/artykuly/9363170,nasz-eksport-slaby-ale-i-tak-blyszczy-na-tle-ue.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T06:45:50+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/aqiktkuTURBXy82NTM0MzRiNi05MmEzLTQzNTctYmNjZS1kYTBlM2QwMjJiYTUuanBlZ5GTBc0BHcyg" />Pogorszenie koniunktury na świecie sprawia, że tylko nieliczne kraje Unii notują w ostatnim czasie wzrost sprzedaży zagranicznej.

## Wyludniająca się Europa. Ilu mieszkańców stracił Stary Kontynent, a ilu Polska?
 - [https://forsal.pl/gospodarka/demografia/artykuly/9363137,wyludniajaca-sie-europa-ilu-mieszkancow-stracil-stary-kontynent-a-il.html](https://forsal.pl/gospodarka/demografia/artykuly/9363137,wyludniajaca-sie-europa-ilu-mieszkancow-stracil-stary-kontynent-a-il.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T06:39:47+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/HGHktkuTURBXy9iNDEzM2FmNy1lNDA3LTRmYTgtYTVhNi05MzYwNzY3OGY0NDQuanBlZ5GTBc0BHcyg" />Tylko w ciągu jednego roku ubyło ponad ćwierć miliona Europejczyków – wynika z najnowszych danych Eurostatu. Polska znalazła się w grupie najbardziej poszkodowanych.

## NFZ płaci krocie, pacjenci i tak stracą. Co dalej z lekami recepturowymi?
 - [https://forsal.pl/lifestyle/zdrowie/artykuly/9363097,nfz-placi-krocie-pacjenci-i-tak-straca-co-dalej-z-lekami-recepturowy.html](https://forsal.pl/lifestyle/zdrowie/artykuly/9363097,nfz-placi-krocie-pacjenci-i-tak-straca-co-dalej-z-lekami-recepturowy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T06:32:54+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/unkktkuTURBXy9mMzE0ZTFlYy1iNGFiLTQ3OGItOWVhNi02YWNmMGNkYzMzMWEuanBlZ5GTBc0BHcyg" />Za maść zrobioną w aptece NFZ zwraca nawet kilkaset tysięcy złotych. Zawyżając koszty, farmaceuci i hurtownie oraz lekarze robią biznes na lekach recepturowych. Sprawy badają organy ścigania.

## Nie będzie rezygnacji z szybkiej kolei. Ile to będzie kosztować?
 - [https://forsal.pl/transport/kolej/artykuly/9363165,nie-bedzie-rezygnacji-z-szybkiej-kolei-ile-to-bedzie-kosztowac.html](https://forsal.pl/transport/kolej/artykuly/9363165,nie-bedzie-rezygnacji-z-szybkiej-kolei-ile-to-bedzie-kosztowac.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T06:26:23+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/9MRktkuTURBXy82NzIzYTYyNS1jMWUyLTQxM2UtYjBiNy0zZmRmOTdhNWRmYzkuanBlZ5GTBc0BHcyg" />Koalicja, która przejmie władzę, chce kontynuować przygotowania do budowy nowych torów. Ale raczej nie w formule PPP, co rozważał dotychczasowy rząd.

## Joanna Beczkowska: Duma narodowa drogą do sukcesu gospodarczego
 - [https://forsal.pl/swiat/artykuly/9361809,joanna-beczkowska-duma-narodowa-droga-do-sukcesu-gospodarczego.html](https://forsal.pl/swiat/artykuly/9361809,joanna-beczkowska-duma-narodowa-droga-do-sukcesu-gospodarczego.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T05:45:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/G1lktkuTURBXy9kYjQ5ODJjOS1mODU1LTQ3OGUtYmIzNC0zZTFmMjgxZDI0MGIuanBlZ5GTBc0BHcyg" />Wielki rozwój gospodarczy Korei Południowej został bardzo mocno powiązany z ich nacjonalizmem, bo sukces biznesowy, sukces gospodarczy, sukces koreańskiej marki jest postrzegany jako osiągnięcie narodowe – mówi dr Joanna Beczkowska z Uniwersytetu Łódzkiego.

## Nowe drogi w 2024 roku. Powstanie prawie 200 km ekspresówek [MAPA]
 - [https://forsal.pl/transport/drogi/artykuly/9361903,nowe-drogi-w-2024-roku-powstanie-prawie-200-km-ekspresowek-mapa.html](https://forsal.pl/transport/drogi/artykuly/9361903,nowe-drogi-w-2024-roku-powstanie-prawie-200-km-ekspresowek-mapa.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T05:45:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/E53ktktTURBXy9jYmIzYThjZi1jMzg3LTRmMzYtODI2OC03NTI0OTJkMjJiYTgucG5nkZMFzQEdzKA" />W przyszłym roku Generalna Dyrekcja Dróg Krajowych i Autostrad udostępni blisko 200 km tras szybkiego ruchu. Będą to m.in. ostatnieodcinki drogi S7 między Warszawą i Krakowem czy brakujące fragmenty S3 na północy i południu kraju.

## Populacja Unii Europejskiej kurczy się. Te regiony straciły najwięcej [MAPA]
 - [https://forsal.pl/gospodarka/demografia/artykuly/9361777,populacja-unii-europejskiej-kurczy-sie-te-regiony-stracily-najwiecej.html](https://forsal.pl/gospodarka/demografia/artykuly/9361777,populacja-unii-europejskiej-kurczy-sie-te-regiony-stracily-najwiecej.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T05:45:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/SgsktkuTURBXy9iZTMzY2JhZi1lMTljLTQ3Y2UtODY5YS02NGU3MDk4ZWFhNWMuanBlZ5GTBc0BHcyg" />Populacja w Unii Europejskiej kurczy się. W czasie pandemii Covid-19 w 2021 r., populacja Wspólnoty zmniejszyła się o ponad 265 tys. osób.

## W dwa lata możesz zostać milionerem. Ile zarabiają inżynierowie sztucznej inteligencji? [KWOTY]
 - [https://forsal.pl/praca/wynagrodzenia/artykuly/9361931,w-dwa-lata-mozesz-zostac-milionerem-ile-zarabiaja-inzynierowie-sztucz.html](https://forsal.pl/praca/wynagrodzenia/artykuly/9361931,w-dwa-lata-mozesz-zostac-milionerem-ile-zarabiaja-inzynierowie-sztucz.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T05:45:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/VJ6ktkuTURBXy8wNjk4NWVjZS0xYmUwLTQxYjItOTk4NS1iMzU0M2VjMDU0NzMuanBlZ5GTBc0BHcyg" />W cieniu historii o wyrzuceniu-przywróceniu Sama Altmana przez OpenAI, siedzą sobie cicho postacie mniej medialne, ale wyrastające na nowych krezusów. Inżynierowie zajmujący się sztuczną inteligencją są teraz na rynku niezwykle cenni. Firmy są im gotowe płacić więcej niż innym specjalistom.

## Wtedy Rosja może być gotowa do zaatakowania krajów bałtyckich [RAPORT]
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9362932,wtedy-rosja-moze-byc-gotowa-do-zaatakowania-krajow-baltyckich-raport.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9362932,wtedy-rosja-moze-byc-gotowa-do-zaatakowania-krajow-baltyckich-raport.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-11-27T05:45:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/4XTktkuTURBXy84NjA4ZmU0MS1iOWM2LTQ3OTQtYjlmMi1lOGQ1MGQ1OGU0MDcuanBlZ5GTBc0BHcyg" />Od zakończenia intensywnych działań wojennych na Ukrainie Rosja będzie potrzebować od 6 do 10 lat, by odtworzyć swoje siły i ewentualnie zaatakować któryś z krajów Sojuszu Północnoatlantyckiego. Taką tezę stawiają autorzy w raporcie „Preventing the Next War, Germany and NATO Are in a Race Against Time”, który opublikował na początku listopada niemiecki think tank DGAP.

