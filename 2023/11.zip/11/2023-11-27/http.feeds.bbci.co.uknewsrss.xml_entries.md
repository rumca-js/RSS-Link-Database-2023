# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Fulham 3-2 Wolves: Two Willian penalties help Cottagers clinch win amid VAR controversy
 - [https://www.bbc.co.uk/sport/football/67470815?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67470815?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T22:45:05+00:00

Willian grabs a controversial injury-time winner from the penalty spot as Fulham beat Wolves in the Premier League.

## Laurence Fox 'can't get mortgage' after racism allegations, court told
 - [https://www.bbc.co.uk/news/uk-67549043?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-67549043?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T21:51:51+00:00

Laurence Fox tells the High Court his life has been "destroyed" after being called a racist.

## British Library hack: Customer data offered for sale on dark web
 - [https://www.bbc.co.uk/news/entertainment-arts-67544504?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-67544504?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T20:33:15+00:00

The library urges users to change their passwords after earlier saying only employer data was leaked.

## Sunak cancels Greek PM meeting in Elgin Marbles row
 - [https://www.bbc.co.uk/news/uk-politics-67549044?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-67549044?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T20:27:31+00:00

Kyriakos Mitsotakis says he is "disappointed" the meeting has been called off.

## Imran Khan's former adviser suffers acid attack in UK
 - [https://www.bbc.co.uk/news/uk-67547730?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-67547730?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T19:58:38+00:00

Mirza Shahzad Akbar said the chemical missed his eyes but caused injuries on his body.

## Britain's Got Talent: David Walliams reaches 'amicable resolution' in privacy case
 - [https://www.bbc.co.uk/news/entertainment-arts-67549655?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-67549655?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T18:37:42+00:00

The comic was suing the production company after private comments he made were leaked to the media.

## James Cleverly issues Commons apology for 'inappropriate language'
 - [https://www.bbc.co.uk/news/uk-politics-67546752?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-67546752?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T18:32:03+00:00

Home secretary admits using "inappropriate language" to describe Labour MP - but not Stockton North.

## Cyber-attack leaves home sales in limbo
 - [https://www.bbc.co.uk/news/business-67543838?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-67543838?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T17:22:46+00:00

Buyers say they have been left hanging as a company that provides IT to law firms sees its services hit.

## Excluding us from meetings harmed Covid response, mayors tell inquiry
 - [https://www.bbc.co.uk/news/uk-politics-67546039?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-67546039?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T17:15:13+00:00

Repeated requests to join meetings in early 2020 were refused, London and Greater Manchester mayors say.

## Lionel Messi: Inter Miami forward is 'gripping' United States, says Guillem Balague
 - [https://www.bbc.co.uk/sport/football/67543580?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67543580?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T17:07:01+00:00

Lionel Messi's arrival at Inter Miami is 'gripping' the United States and improving the trajectory of MLS, writes Guillem Balague.

## How Hamas built a force to attack Israel on 7 October
 - [https://www.bbc.co.uk/news/world-middle-east-67480680?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-67480680?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T17:05:55+00:00

BBC Arabic and BBC Verify have pieced together how armed groups came together to train for the assault.

## Israel-Hamas truce in Gaza extended for two days, Qatar says
 - [https://www.bbc.co.uk/news/world-middle-east-67542209?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-67542209?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T17:04:26+00:00

It comes after a four-day pause where hostages in Gaza and prisoners in Israel have been released.

## Ninety-eight Christmas trees and a gingerbread White House
 - [https://www.bbc.co.uk/news/world-us-canada-67548875?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-67548875?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T17:03:31+00:00

Jill Biden unveils this year's White House holiday decorations, designed to evoke wonder and joy.

## UK Championship 2023: Judd Trump dominant in victory over Pang Junxu
 - [https://www.bbc.co.uk/sport/snooker/67547335?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/snooker/67547335?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T16:46:07+00:00

Judd Trump produces a dominant display to thrash Pang Junxu 6-1 in the first round of the UK Championship in York.

## Young Thug: US rapper's racketeering trials opens in Georgia
 - [https://www.bbc.co.uk/news/world-us-canada-67527707?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-67527707?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T16:24:02+00:00

The Grammy-winning rapper is accused of co-founding a violent street gang in Atlanta, Georgia.

## Tommy Robinson charged after attending antisemitism march in London
 - [https://www.bbc.co.uk/news/uk-england-london-67545868?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-67545868?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T16:21:21+00:00

The English Defence League founder was asked by organisers not to attend the rally against antisemitism.

## Brianna Ghey: Murder-accused teens 'had preoccupation with torture'
 - [https://www.bbc.co.uk/news/uk-england-manchester-67543984?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-manchester-67543984?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T16:17:33+00:00

Brianna Ghey was stabbed 28 times in a "sustained and violent assault", a court hears.

## Harry Brook and Nat Sciver-Brunt claim top Cricket Writers' Club awards
 - [https://www.bbc.co.uk/sport/cricket/67542418?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/67542418?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T16:17:26+00:00

England batter Harry Brook claims the top prize at the 2023 Cricket Writers' Club awards.

## Israel-Gaza war: The Red Cross's delicate role in hostage crises
 - [https://www.bbc.co.uk/news/world-middle-east-67520263?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-67520263?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T16:02:15+00:00

The part played by the Red Cross in the Gaza hostage releases highlights its unique role.

## Met officer Tasered girl, 10, twice over garden shears threat, hearing told
 - [https://www.bbc.co.uk/news/uk-england-london-67540706?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-67540706?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T16:01:38+00:00

PC Jonathan Broadhead faces gross misconduct proceedings over Tasering the child in January 2021.

## Ukraine and Russia hit by snow storms and floods
 - [https://www.bbc.co.uk/news/world-europe-67547361?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-67547361?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T15:59:50+00:00

Snowstorms and flooding have hit parts of Russia and Ukraine, leaving nearly two million people without power.

## NFL Plays of the Week: Jevon Holland, Greg Dortch and Ola Zacchaeus all feature
 - [https://www.bbc.co.uk/sport/av/american-football/67545887?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/american-football/67545887?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T15:35:48+00:00

Watch the NFL Plays of the Week featuring Jevon Holland’s 99-yard run for a touchdown and spectacular one-handed catches from Jaxon Smith-Njigba and Greg Dortch.

## Man City v RB Leipzig: Guardiola hungry for Champions League group top spot
 - [https://www.bbc.co.uk/sport/football/67543348?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67543348?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T14:44:09+00:00

Manchester City manager Pep Guardiola wants his team to nail down top spot in their Champions League group on Tuesday.

## Boardmasters Festival applies to expand capacity
 - [https://www.bbc.co.uk/news/uk-england-cornwall-67542992?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-cornwall-67542992?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T14:23:20+00:00

The surf and music festival is applying to increase its capacity by almost 23% to 65,000 people.

## Essex lorry deaths: Caolan Gormley guilty of trafficking offence
 - [https://www.bbc.co.uk/news/uk-england-essex-67543598?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-essex-67543598?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T13:59:45+00:00

Caolan Gormley, 26, will be sentenced at the Old Bailey on Friday after being convicted earlier.

## Human case of flu seen in pigs found in UK for first time
 - [https://www.bbc.co.uk/news/health-67545375?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-67545375?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T13:51:11+00:00

It's the first time that influenza strain A(H1N2)v has been detected in the UK.

## Elon Musk visits 7 October kibbutz with Israeli PM Netanyahu
 - [https://www.bbc.co.uk/news/world-middle-east-67542129?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-67542129?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T13:44:24+00:00

The US entrepreneur was shown around a kibbutz in Israel that was attacked on 7 October.

## No rate cuts for foreseeable future, says Bank
 - [https://www.bbc.co.uk/news/articles/cjrpzxpv90eo?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/articles/cjrpzxpv90eo?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T13:36:33+00:00

Andrew Bailey, governor of the Bank of England, says lowering inflation further will be "hard work".

## Pictures show Dumfries dangerous driver's iced-up windows
 - [https://www.bbc.co.uk/news/uk-scotland-south-scotland-67543666?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-south-scotland-67543666?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T13:27:48+00:00

Police release images of the "very limited view" from a van as a warning to other motorists.

## Eurostar Amsterdam-to-London services to be suspended for six months
 - [https://www.bbc.co.uk/news/world-europe-67544997?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-67544997?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T13:19:07+00:00

Trains will be suspended from next June because of renovation work at Amsterdam's central station.

## Fresh pay offer could end NHS consultant strikes
 - [https://www.bbc.co.uk/news/health-67514362?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-67514362?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T12:35:06+00:00

Extra increase on top of 6% rise given this year will now be put to union members in England.

## Terry Venables: Barcelona training session featuring Gary Lineker and Mark Hughes
 - [https://www.bbc.co.uk/sport/av/football/67544771?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/67544771?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T12:18:04+00:00

Watch the late Terry Venables giving a training session at Barcelona featuring Gary Lineker, Mark Hughes and a hard-working translator.

## Can I get a Cold Weather Payment and how much are they?
 - [https://www.bbc.co.uk/news/business-55992592?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-55992592?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T12:11:25+00:00

Cold Weather Payments are available to some when there is a run of sub-zero temperatures.

## Snowstorm causes massive power cuts across Ukraine
 - [https://www.bbc.co.uk/news/world-europe-67541166?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-67541166?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T11:46:34+00:00

More than 2,000 towns and villages are now without electricity and many roads are closed, officials say.

## Coastguard warns of cliff danger after Pakefield road collapse
 - [https://www.bbc.co.uk/news/uk-england-suffolk-67541260?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-suffolk-67541260?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T11:42:41+00:00

Caravans had to be moved after "very unstable" cliffs gave way in Suffolk.

## Samuel Paty: Six French teenagers on trial over teacher's murder
 - [https://www.bbc.co.uk/news/world-europe-67543278?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-67543278?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T11:18:11+00:00

The suspects are accused of inciting the murder and pointing out the teacher to the killer.

## Potholes: AA advises drivers to avoid puddles to limit vehicle damage
 - [https://www.bbc.co.uk/news/uk-67540985?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-67540985?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T11:13:12+00:00

The AA blames the increase in pothole-related problems on poor weather and recent storms.

## Hughie and Freddie: Fundraising teen on moment he got cancer all-clear
 - [https://www.bbc.co.uk/news/uk-67543080?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-67543080?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T11:06:55+00:00

Hughie was diagnosed with leukaemia in 2020, and has gone on to raise thousands with best friend Freddie.

## Israel-Lebanon border: The Irish troops watching Israel’s hidden conflict
 - [https://www.bbc.co.uk/news/world-middle-east-67508534?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-67508534?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T10:37:33+00:00

As one of the region's most dangerous borders hots up, peacekeepers have an ever more perilous job.

## Ruth Perry: Family crowdfunding after legal aid refused
 - [https://www.bbc.co.uk/news/uk-england-berkshire-67536139?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-berkshire-67536139?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T10:36:41+00:00

Ms Perry died in January after being told Caversham Primary received a critical Ofsted report.

## Charlie's Bar, Fermanagh, 'blown away' by Christmas ad response
 - [https://www.bbc.co.uk/news/uk-northern-ireland-67541181?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-northern-ireland-67541181?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T10:33:02+00:00

A Northern Irish pub's take on Christmas adverts gets the John Lewis seal of approval.

## UK braces for snow as cold weather takes a grip
 - [https://www.bbc.co.uk/news/uk-67540978?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-67540978?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T09:29:08+00:00

Forecasters say there could be snow in the south of the UK later this week as temperatures drop.

## Rishi Sunak agreed migrant deal, Suella Braverman's allies say
 - [https://www.bbc.co.uk/news/uk-politics-67541308?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-67541308?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T09:21:11+00:00

But sources close to the PM dispute the document the former home secretary refers to amounted to a deal.

## Grace Dent leaves I'm A Celebrity jungle on medical grounds
 - [https://www.bbc.co.uk/news/entertainment-arts-67541508?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-67541508?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T08:34:05+00:00

In a statement, ITV said the food critic had left the jungle, adding she had been a "great campmate".

## America Ferrera: ‘We are still just fighting to be visible’
 - [https://www.bbc.co.uk/news/entertainment-arts-67533054?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-67533054?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T08:33:03+00:00

The actress finds it hard to reconcile her "fairy tale story" with the tough reality for most Latinos.

## Bellingham breaks Ronaldo scoring record as Real go top
 - [https://www.bbc.co.uk/sport/football/67538934?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67538934?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T08:32:08+00:00

Jude Bellingham scores his 14th goal of the season as Real Madrid return to the top of La Liga with a 3-0 victory at lowly Cadiz.

## Sports Personality of the Year to be held on Tuesday, 19 December in Salford
 - [https://www.bbc.co.uk/sport/sports-personality/67472731?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/sports-personality/67472731?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T08:00:06+00:00

This year's BBC Sports Personality of the Year show will be held at MediaCityUK in Salford on 19 December.

## New Zealand smoking ban: Health experts criticise new government's shock reversal
 - [https://www.bbc.co.uk/news/world-asia-67540190?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-67540190?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T07:36:14+00:00

Health experts are appalled as the new government plans to repeal the policy to fund tax cuts.

## Terry Venables: 'A special man and trailblazer' - former Barcelona manager leaves lasting impression
 - [https://www.bbc.co.uk/sport/football/67538677?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67538677?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T07:34:38+00:00

Terry Venables' impact as manager of Barcelona cannot be underestimated, writes Spanish football expert Guillem Balague.

## Mount Etna sprays lava into Sicily's night sky
 - [https://www.bbc.co.uk/news/world-europe-67529862?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-67529862?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T07:12:45+00:00

Europe's most active volcano spurts lava near Italy's city of Catania.

## NFL week 12 review & results: Eagles beat Bills in thriller Belichick in trouble after Patriots lose
 - [https://www.bbc.co.uk/sport/american-football/67540030?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/american-football/67540030?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T06:56:15+00:00

Jalen Hurts scores a walk-off touchdown as the Philadelphia Eagles win an overtime thriller against the Buffalo Bills while Bill Belichick's job is on the line after another Patriots defeat.

## Napoleon: How Hollywood has landed in the heart of England
 - [https://www.bbc.co.uk/news/uk-england-northamptonshire-67449345?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-northamptonshire-67449345?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T06:35:50+00:00

Scenes for Napoleon, Saltburn and a new Brad Pitt movie were shot just a few miles apart.

## Sir Rod Stewart to sell items from his Essex home after a declutter
 - [https://www.bbc.co.uk/news/uk-england-essex-67522535?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-essex-67522535?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T06:27:11+00:00

Auctioneer director John Black says it is going to be a pleasure to host the sale in December.

## Women's remarkable Civil War roles revealed in Huntingdon display
 - [https://www.bbc.co.uk/news/uk-england-cambridgeshire-67521480?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-cambridgeshire-67521480?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T06:26:04+00:00

They ran businesses, were spies, preachers and faced violence during the 1640s wars, says an expert.

## Upskirting and cyber-flashing laws come into effect in Northern Ireland
 - [https://www.bbc.co.uk/news/uk-northern-ireland-67536870?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-northern-ireland-67536870?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T06:21:56+00:00

Perpetrators could face up to two years in prison and up to 10 years on the Sex Offenders Register.

## Thai groom kills four at wedding, including bride
 - [https://www.bbc.co.uk/news/world-asia-67540210?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-67540210?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T06:09:22+00:00

Police say the shooter, who killed himself, was "quite intoxicated at the time".

## COP28: UAE planned to use climate talks to make oil deals
 - [https://www.bbc.co.uk/news/science-environment-67508331?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-67508331?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T06:00:15+00:00

Leaked documents show how the COP28 host planned to use its role to strike fossil fuel business deals.

## Zhongzhi Enterprise Group: China investigates major shadow bank for 'crimes'
 - [https://www.bbc.co.uk/news/business-67539910?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-67539910?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T05:01:24+00:00

Zhongzhi Enterprise, one of China's biggest shadow banks, has lent billions to real estate firms.

## 'Long Covid triggered our MCAS, but doctors didn't believe us'
 - [https://www.bbc.co.uk/news/uk-england-london-66998448?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-66998448?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T01:39:05+00:00

Elle Gorman and George Cooper explain how they were told their post-long Covid illness didn't exist.

## Leasehold reforms: Michael Gove confident bill will pass by next election
 - [https://www.bbc.co.uk/news/uk-politics-67537218?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-67537218?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T01:26:11+00:00

The bill would make it easier and cheaper for homeowners to extend their lease or buy their freehold.

## Street celebrations as convoy carrying hostages returns to Israel
 - [https://www.bbc.co.uk/news/world-middle-east-67539822?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-67539822?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T01:16:07+00:00

Thousands lined the streets near the Hatzerim military base in southern Israel to welcome the hostages freed from Gaza on Sunday.

## Olivia Dean: BBC Introducing's Artist of the Year finds her voice
 - [https://www.bbc.co.uk/news/newsbeat-67495800?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-67495800?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T00:56:41+00:00

BBC Introducing's Artist of the Year talks about finding her voice and protecting her sound.

## Climate protest: More than 100 arrested at world's largest coal port
 - [https://www.bbc.co.uk/news/world-australia-67539759?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-australia-67539759?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T00:54:56+00:00

Protesters say the 30-hour blockade stopped over half a million tonnes of coal from leaving Australia.

## Kenya abortion: Women go to backstreet clinics amid legal ambiguity
 - [https://www.bbc.co.uk/news/world-africa-67473183?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-67473183?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T00:49:32+00:00

An estimated seven Kenyan women die a day after unsafe abortions even though they are legal in some cases.

## Delhi pollution: Indian Supreme Court's 40-year quest to clean foul air
 - [https://www.bbc.co.uk/news/world-asia-india-67411826?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-india-67411826?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T00:44:03+00:00

The Supreme Court has a mixed record in cleaning up pollution in India's capital.

## The Papers: 'Farewell El Tel' and Sunak-Braverman 'migrant deal'
 - [https://www.bbc.co.uk/news/blogs-the-papers-67539523?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-67539523?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T00:38:39+00:00

Tributes to ex-England boss Terry Venables feature in Monday's newspapers after he died over the weekend.

## Vermont: Three Palestinian students shot near US campus
 - [https://www.bbc.co.uk/news/world-us-canada-67539809?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-67539809?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T00:31:15+00:00

Police in Vermont are still searching for the lone gunman who opened fire in Burlington.

## More Palestinian teens freed amid hopes hostage deal can be extended
 - [https://www.bbc.co.uk/news/world-middle-east-67539533?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-67539533?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T00:21:22+00:00

Abdurahman Al-Zaghal, who was shot in the head, is among the latest prisoners to be released.

## Tobacco firm calls for tougher rules on vapes
 - [https://www.bbc.co.uk/news/business-67539543?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-67539543?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T00:01:38+00:00

BAT wants sellers to be licensed, and sweet flavours banned

## Metro Bank shareholders to vote on rescue deal
 - [https://www.bbc.co.uk/news/business-67535723?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-67535723?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T00:01:29+00:00

A deal to raise extra funds was struck last month after speculation about Metro's financial position.

## Match of the Day 2 analysis: Alejandro Garnacho's bicycle kick was 'one in a million'
 - [https://www.bbc.co.uk/sport/av/football/67539699?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/67539699?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-27T00:00:20+00:00

Match of the Day 2's Mark Chapman, Danny Murphy, Theo Walcott and Jermaine Jenas discuss Alejandro Garnacho's sensational goal of the season contender in Manchester United's win at Everton.

