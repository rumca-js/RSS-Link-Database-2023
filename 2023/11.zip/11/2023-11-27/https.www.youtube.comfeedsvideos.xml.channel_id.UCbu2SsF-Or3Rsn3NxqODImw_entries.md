# Source:GameSpot - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Avatar: Frontiers of Pandora Everything To Know
 - [https://www.youtube.com/watch?v=QfgzwuiKY6k](https://www.youtube.com/watch?v=QfgzwuiKY6k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2023-11-27T16:00:26+00:00

Hot off the heels of the, over a decade in the making, latest installment in James Cameron’s sci-fi film pentalogy, an open-world RPG game set between the first Avatar movie and its sequel the Way of Water is coming to gamers by the way of Ubisoft. From its story, to gameplay and release date, here’s everything to know about Avatar: Frontiers of Pandora.

Timestamps: 
00:33 - Plot
02:40 - Development
04:12 - Gameplay
06:43 - Release Date and Price

