# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Sustainable fishing: The tech making it cheaper and greener
 - [https://www.bbc.co.uk/news/technology-67093211?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-67093211?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-11-03T00:15:27+00:00

Fishermen in Scotland and Indonesia are trialling new technology to improve their catch.

## AI bot capable of insider trading and lying, say researchers
 - [https://www.bbc.co.uk/news/technology-67302788?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-67302788?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-11-03T00:11:41+00:00

The researchers behind the simulation say there is a risk of this happening for real in the future.

