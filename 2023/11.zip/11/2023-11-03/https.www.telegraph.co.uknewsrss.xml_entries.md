# Source:The Telegraph News, URL:https://www.telegraph.co.uk/news/rss.xml, language:en-UK

## Watch: Gaza sit-in protest at King’s Cross station banned by Transport Secretary
 - [https://www.telegraph.co.uk/news/2023/11/03/gaza-protest-kings-cross-station-london-banned](https://www.telegraph.co.uk/news/2023/11/03/gaza-protest-kings-cross-station-london-banned)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-11-03T18:53:56+00:00



## Friday evening news briefing: Netanyahu says no ceasefire with Hamas until hostages freed
 - [https://www.telegraph.co.uk/news/2023/11/03/friday-evening-news-briefing-netanyahu-says-no-ceasefire](https://www.telegraph.co.uk/news/2023/11/03/friday-evening-news-briefing-netanyahu-says-no-ceasefire)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-11-03T18:04:34+00:00



## Gary Lineker backs pro-Palestinian protesters over Armistice Day march
 - [https://www.telegraph.co.uk/news/2023/11/03/gary-lineker-backs-pro-palestinian-protesters-armistice-day](https://www.telegraph.co.uk/news/2023/11/03/gary-lineker-backs-pro-palestinian-protesters-armistice-day)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-11-03T18:03:16+00:00



## Tory MP Bob Stewart found guilty of racially abusing Bahraini activist
 - [https://www.telegraph.co.uk/news/2023/11/03/tory-mp-bob-stewart-guilty-racially-abusing-activist](https://www.telegraph.co.uk/news/2023/11/03/tory-mp-bob-stewart-guilty-racially-abusing-activist)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-11-03T16:32:23+00:00



## 'Somerset Gimp' banned from writhing on ground in full-body suit
 - [https://www.telegraph.co.uk/news/2023/11/03/somerset-gimp-banned-writhing-ground-dark-clothes](https://www.telegraph.co.uk/news/2023/11/03/somerset-gimp-banned-writhing-ground-dark-clothes)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-11-03T12:52:51+00:00



## Zara Aleena murderer wins court appeal to reduce minimum term of life sentence
 - [https://www.telegraph.co.uk/news/2023/11/03/zara-aleena-murderer-jordan-mcsweeney-life-sentence](https://www.telegraph.co.uk/news/2023/11/03/zara-aleena-murderer-jordan-mcsweeney-life-sentence)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-11-03T10:11:16+00:00



