# Source:Wiadomosci - Gazeta.pl, URL:https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml, language:pl-PL

## Skandal w Berlinie. Szef MSZ Chorwacji prĂłbował pocałować niemiecką ministerkę
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30369114,skandaliczne-zachowanie-chorwackiego-ministra-w-berlinie-cieple.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30369114,skandaliczne-zachowanie-chorwackiego-ministra-w-berlinie-cieple.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-03T22:18:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c4/f6/1c/z30369220M,Skandal-w-Berlinie.jpg" vspace="2" />W Berlinie podczas Konferencji MinistrĂłw Spraw Zagranicznych państw Unii Europejskiej doszło do skandalu. Chorwacki polityk prĂłbował pocałować gospodynię spotkania, szefową MSZ Niemiec Annalenę Baerbock. Prasa nie pozostawia na ministrze suchej nitki, jednak ten przyznaje z rozbrajającą szczerością: "Sam nie wiem, w czym tkwi problem".

## Donald Tusk niechcący pokazał w nowym nagraniu za dużo? "Rozmowy idą świetnie"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30368926,nowe-nagranie-donalda-tuska-moglo-zdradzic-tajemnice-umowy-koalicyjnej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30368926,nowe-nagranie-donalda-tuska-moglo-zdradzic-tajemnice-umowy-koalicyjnej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-03T21:04:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/08/f6/1c/z30369032M,Nowe-nagranie-Donalda-Tuska-moglo-zdradzic-tajemni.jpg" vspace="2" />"My, niżej podpisani" - to pierwsze wyrazy dokumentu, ktĂłry widać na najnowszym filmiku Donalda Tuska, jaki opublikował w mediach społecznościowych. Według niektĂłrych dziennikarzy na nagraniu można zobaczyć fragment umowy koalicyjnej. Jej treść oficjalnie poznamy w przyszłym tygodniu.

## 4 razy prĂłbowała zabić byłego męża, a jego rodzinę otruła grzybami? Australijka usłyszała zarzuty
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30368193,australijka-podala-trujace-grzyby-tesciom-uslyszala-zarzut.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30368193,australijka-podala-trujace-grzyby-tesciom-uslyszala-zarzut.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-03T19:58:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c5/f5/1c/z30364357M,Australijska-policja-zatrzymala-Erin-Patterson.jpg" vspace="2" />Osiem zarzutĂłw usłyszała 49-letnia Erin Patterson, podejrzana o podanie rodzinie byłego męża trujących grzybĂłw. Australijka miała także kilkukrotnie prĂłbować zabić byłego partnera.

## Łukaszenka twierdzi, że ostrzegał Zełenskiego. "MĂłwiłem: Wołodia, posłuchaj mnie"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30368691,lukaszenka-twierdzi-ze-ostrzegal-zelenskiego-mowilem-wolodia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30368691,lukaszenka-twierdzi-ze-ostrzegal-zelenskiego-mowilem-wolodia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-03T19:10:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d6/f6/1c/z30368726M,Alaksandr-Lukaszenka-podczas-spotkania-w-Ostrowcu-.jpg" vspace="2" />Podczas swojego przemĂłwienia dla mieszkańcĂłw Ostrowa Alaksandr Łukaszenka odniĂłsł się do konfliktu na Bliskim Wschodzie i stwierdził, że spowoduje on porzucenie Ukrainy przez AmerykanĂłw. Twierdził ponadto, że przestrzegał przed takim scenariuszem prezydenta Zełenskiego. - MĂłwiłem: "Wołodia, posłuchaj mnie. Jestem doświadczonym człowiekiem. Zapomną o tobie jak tylko gdzieś zrobi się bałagan" - wspominał dyktator Białorusi.

## Rosjanie zawzięcie prĂłbują udowodnić, że w tej wojnie da się atakować. Ukraińcy na razie sobie darowali
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30367375,rosjanie-zawziecie-probuja-udowodnic-ze-w-tej-wojnie-da-sie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30367375,rosjanie-zawziecie-probuja-udowodnic-ze-w-tej-wojnie-da-sie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-03T18:58:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/8f/f5/1c/z30367631M,Raport-na-temat-sytuacji-na-froncie--Poczatek-list.jpg" vspace="2" />Rosyjskie wojsko prawie całkowicie przejęło inicjatywę na froncie. Kontynuuje zacięte ataki w rejonie Awdijiwki, gdzie za cenę ciężkich strat pełźnie jednak naprzĂłd. Rosjanie zaatakowali też ponownie Wuhłedar, z podobnym wynikiem jak zimą. Ukraińcy ogĂłlnie zastygli, a ich głĂłwny dowĂłdca otwarcie mĂłwi o patowej sytuacji.

## Niespokojna piątkowa noc. Alerty RCB dla dziewięciu wojewĂłdztw. IMGW ostrzega przed silnym wiatrem
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30368253,niespokojna-piatkowa-noc-alerty-rcb-dla-dziewieciu-wojewodztw.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30368253,niespokojna-piatkowa-noc-alerty-rcb-dla-dziewieciu-wojewodztw.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-03T18:29:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/68/f6/1c/z30368616M,Czwartek-3-listopada--Porywisty-wiatr-wieczorem-i-.jpg" vspace="2" />Mieszkańcy dziewięciu wojewĂłdztw otrzymali alerty RCB przestrzegające przed silnym wiatrem, ktĂłry pojawić może się wieczorem i w godzinach nocnych. Jednocześnie w większości regionĂłw kraju obowiązują ostrzeżenia meteorologiczne IMGW, przestrzegające przed porywistym wiatrem oraz intensywnymi opadami deszczu.

## Lider Hezbollahu zagroził USA. Jest odpowiedź Waszyngtonu
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30368596,lider-hezbollahu-zagrozil-usa-jest-odpowiedz-waszyngtonu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30368596,lider-hezbollahu-zagrozil-usa-jest-odpowiedz-waszyngtonu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-03T17:12:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ec/f0/1c/z30346220M,Rzecznik-Amerykanskiej-Rady-Bezpieczenstwa-Narodow.jpg" vspace="2" />- Hezbollah i inne ugrupowania, państwowe oraz niepaństwowe, nie powinny prĂłbować wykorzystywać trwającego konfliktu między Izraelem i Hamasem - podkreślił rzecznik Rady Bezpieczeństwa Narodowego USA John Kirby. To odpowiedź StanĂłw Zjednoczonych na piątkowe oświadczenie lidera Hezbollahu Hassana Nasrallaha i jego groźby skierowane wprost pod adresem Waszyngotnu.

## Brutalne zabĂłjstwo w Tyrolu. Służby podejrzewają 30-letniego Polaka
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30368499,brutalne-zabojstwo-w-tyrolu-sluzby-podejrzewaja-30-letniego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30368499,brutalne-zabojstwo-w-tyrolu-sluzby-podejrzewaja-30-letniego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-03T17:05:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/6e/f6/1c/z30368622M,Zdjecie-ilustracyjne.jpg" vspace="2" />Austriaccy funkcjonariusze zatrzymali Polaka podejrzanego o zamordowanie 36-latka w miejscowości Itter. Jak przekazał rzecznik prokuratury w Innsbrucku HansjĂśrg Mayr, mężczyźni byli znajomymi. W ostatnim czasie miało dojść między nimi do "sytuacji konfliktowej".

## Białoruskie MSZ wezwało polskiego dyplomatę. Chodzi o "naruszenie granicy"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30368578,bialoruskie-msz-wezwalo-polskiego-dyplomate-chodzi-o-naruszenie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30368578,bialoruskie-msz-wezwalo-polskiego-dyplomate-chodzi-o-naruszenie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-03T16:57:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/56/f6/1c/z30368598M,Prezydent-Bialorusi-Alaksandr-Lukaszenka.jpg" vspace="2" />Polski chargĂŠ d'affaires RP w Mińsku Marcin Wojciechowski został wezwany do Ministerstwa Spraw Zagranicznych Białorusi. Jak wynika z komunikatu resortu, powodem wezwania ma być rzekomy "kolejny przypadek naruszenia granicy przez statek powietrzny ze strony Polski".

## Zmarła trzymiesięczna dziewczynka, ktĂłra trafiła do szpitala z urazem głowy. Możliwa zmiana zarzutĂłw
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30368285,zmarla-trzymiesieczna-dziewczynka-ktora-trafila-do-szpitala.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30368285,zmarla-trzymiesieczna-dziewczynka-ktora-trafila-do-szpitala.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-03T16:39:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/7a/f2/1c/z30354298M,Dziecko-w-szpitalu--zdjecie-ilustracyjne-.jpg" vspace="2" />W szpitalu specjalistycznym w Poznaniu zmarła trzymiesięczna dziewczynka, ktĂłra kilkanaście dni temu z ciężkimi obrażeniami głowy trafiła pod opiekę lekarzy. 21-letniej matce dziecka postawiony został zarzut nieumyślnego spowodowania ciężkiego uszczerbku na zdrowiu. Prokuratura nie wyklucza, że w związku ze śmiercią dziecka zarzut zostanie zmieniony.

## Warszawa. Policja zatrzymała podejrzewanego o ataki maczetą
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30368446,policja-zatrzymala-podejrzewanego-o-atak-maczeta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30368446,policja-zatrzymala-podejrzewanego-o-atak-maczeta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-03T16:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/db/f6/1c/z30368475M,Radiowoz.jpg" vspace="2" />Policja zatrzymała mężczyznę podejrzewanego o ataki maczetą na terenie Warszawy - przekazali funkcjonariusze na portalu X. Wcześniej prezydent miasta Rafał Trzaskowski poinformował, że zwrĂłcił się do Komendy Stołecznej Policji o skierowanie na ulice stolicy dodatkowych patroli.

## Media: Sąsiedzi mĂłwią o awanturze w mieszkaniu Grzegorza Borysa. "Nie dało się tego nie słyszeć"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30367710,media-sasiedzi-mowia-o-awanturze-w-mieszkaniu-grzegorza-borysa.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30367710,media-sasiedzi-mowia-o-awanturze-w-mieszkaniu-grzegorza-borysa.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-03T15:28:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a9/ed/1c/z30332073M,Grzegorz-Borys.jpg" vspace="2" />Poszukiwania Grzegorza Borysa, mężczyzny podejrzanego o zabĂłjstwo swojego sześcioletniego syna, trwają już od ponad dwĂłch tygodni. W ostatnich dniach reporterzy "Faktu" dotarli do informacji, ktĂłre ich zdaniem mogą okazać się istotne w śledztwie. Z rozmĂłw z sąsiadami rodziny dowiedzieli się, że na niedługo przed tragedią w mieszkaniu Borysa dojść miało do awantury.

## Atak maczetą w Warszawie. Policja publikuje zdjęcia agresora
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30368216,policja-opublikowala-zdjecia-rowerzysty-ktory-maczeta-atakowal.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30368216,policja-opublikowala-zdjecia-rowerzysty-ktory-maczeta-atakowal.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-03T15:19:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ef/f6/1c/z30368239M,Policja-opublikowala-zdjecia-rowerzysty--ktory-mac.jpg" vspace="2" />Policja nadal poszukuję mężczyzny, ktĂłry w piątek zaatakował przechodniĂłw maczetą na warszawskich Bielanach. Po kilku godzinach od ataku funkcjonariusze opublikowali zdjęcia podejrzewanego rowerzysty.

## TVP zmieni nazwę? "Kojarzy się z absolutnym złem". Opozycja rozważa "opcję zero"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30366127,tvp-kojarzy-sie-z-absolutnym-zlem-opozycja-chce-rozliczac.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30366127,tvp-kojarzy-sie-z-absolutnym-zlem-opozycja-chce-rozliczac.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-03T14:36:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/3e/f5/1c/z30366270M,Siedziba-TVP-w-Warszawie--18-09-2023-r-.jpg" vspace="2" />Koalicja Obywatelska, Trzecia Droga i Nowa Lewica dostrzegają konieczność przeprowadzenia daleko idących zmian w Telewizji Polskiej. Podkreślają, że potrzebne będą radykalne działania, aby rozliczyć media, ktĂłre uważają za bliskie PiS. Jak stwierdził Borys Budka, szyld TVP jest tak skompromitowany, że jedynym rozwiązaniem może być jego likwidacja. Rzecznik PSL zasugerował natomiast możliwość skorzystania z "opcji zero" przy wprowadzania reformy mediĂłw publicznych.

## Orkan Ciaran pozbawił prądu ponad pĂłł miliona domĂłw we Francji. "Niezwykle poważny kryzys"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30367239,orkan-ciaran-pozbawil-pradu-ponad-pol-miliona-domow-we-francji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30367239,orkan-ciaran-pozbawil-pradu-ponad-pol-miliona-domow-we-francji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-03T14:03:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/51/f5/1c/z30367569M,Orkan-Ciaran-we-Francji-2-pazdziernika.jpg" vspace="2" />Francja boryka się ze stratami, ktĂłre spowodował orkan Ciaran. Rzecznik rządu Olivier VĂŠran przekazał, że około 523 000 domĂłw jest odciętych od prądu. Ponadto kilka tysięcy kilometrĂłw drĂłg jest niedostępnych. Wstępnie oszacowano straty, ktĂłre sięgają kilkuset tysięcy euro.

## Lider Hezbollahu Nasrallah przemawia. Słuchają tłumy. "Wszystkie scenariusze są otwarte"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30367803,lider-hezbollahu-nasrallah-przemawia-sluchaja-tlumy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30367803,lider-hezbollahu-nasrallah-przemawia-sluchaja-tlumy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-03T13:38:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/95/f6/1c/z30367893M,Lider-Hezbollaju--po-lewej--Hassan-Nasrallah--zdje.jpg" vspace="2" />Sekretarz generalny radykalnego ugrupowania Hezbollah wygłasza w Libanie przemĂłwienie do swoich zwolennikĂłw. To jego pierwsze przemĂłwienie od początku wojny Izraela z Hamasem.

## Ludzkie szczątki na ogrĂłdkach działkowych w Szczecinie. Są wstępne ustalenia, może chodzić o trzy osoby
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30367332,ludzkie-szczatki-na-ogrodkach-dzialkowych-robotnicy-zgineli.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30367332,ludzkie-szczatki-na-ogrodkach-dzialkowych-robotnicy-zgineli.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-03T13:27:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/31/f5/1c/z30367537M,Na-terenie-ogrodkow-dzialkowych-w-Szczecinie-znale.jpg" vspace="2" />Na terenie ogrĂłdkĂłw działkowych w Szczecinie odnaleziono ludzkie szczątki. Eksperci badający sprawę podzielili się pierwszymi ustaleniami. Wstępna teoria zakłada, że to kości trzech osĂłb, ktĂłre zginęły w trakcie II wojny światowej.

## W TVP o Przyłębskiej: "Największy autorytet". W tle Boniek, Czarnek i "Pies cię..."
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30366579,najwazniejszy-autorytet-prawny-w-polsce-zawital-do-tvp-przylebska.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30366579,najwazniejszy-autorytet-prawny-w-polsce-zawital-do-tvp-przylebska.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-03T12:56:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c9/f5/1c/z30366665M,Julia-Przylebska.jpg" vspace="2" />Julia Przyłębska, prezeska Trybunału Konstytucyjnego wystąpiła w programie na antenie TVP Info. Jej udział w wywiadzie z Bronisławem Wildsteinem stał się powodem do ostrej wymiany zdań między Zbigniewem Bońkiem a ministrem edukacji Przemysławem Czarnkiem.

## Rotacyjność marszałka Sejmu. Hołownia ma obawy. Nie on jeden. "To może być kosiarka"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30367213,rotacyjnosc-marszalka-sejmu-holownia-ma-obawy-nie-on-jeden.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30367213,rotacyjnosc-marszalka-sejmu-holownia-ma-obawy-nie-on-jeden.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-03T12:27:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e0/a3/1c/z30029792M,Wlodzimierz-Czarzasty--Szymon-Holownia--Donald-Tus.jpg" vspace="2" />Nie wszyscy członkowie koalicji, ktĂłra ma przejąć władzę, patrzą z taką samą przychylnością na pomysł rotacyjnego marszałka Sejmu. Trzecia Droga nie mĂłwi nie, ale pojawiają się już pierwsze obawy.

## Szymon Hołownia o aborcji. "Prawo w Polsce będzie stanowił Sejm, a nie Episkopat Polski"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30366946,szymon-holownia-o-aborcji-prawo-w-polsce-bedzie-stanowil-sejm.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30366946,szymon-holownia-o-aborcji-prawo-w-polsce-bedzie-stanowil-sejm.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-03T12:16:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/1d/f0/1c/z30344733M,Szymon-Holownia.jpg" vspace="2" />- Mamy zgodę co do tego, że nie może być tak, że kobiety w Polsce miałyby bać się rodzić dzieci, zachodzić w ciążę albo iść do szpitala - przyznał Szymon Hołownia w programie "Jeden na jeden". Lider Polski 2050 odniĂłsł się do tematu aborcji oraz rĂłżnic dotyczących tej kwestii wśrĂłd liderĂłw opozycji.

## Konferencja policji ws. poszukiwań Grzegorza Borysa. "Nie wykluczamy, że nie żyje"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30367249,konferencja-policji-ws-poszukiwan-grzegorza-borysa-nie-wykluczamy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30367249,konferencja-policji-ws-poszukiwan-grzegorza-borysa-nie-wykluczamy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-03T11:44:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/af/f5/1c/z30367407M,Grzegorz-Borys.jpg" vspace="2" />- Nie wykluczamy, że Grzegorz Borys nie żyje. Zawęziliśmy obszar poszukiwań do dwĂłch hektarĂłw - poinformowała w piątek kom. Karina Kamińska, rzeczniczka prasowa komendanta WojewĂłdzkiego Policji w Gdańsku. Jak dodała, zapis monitoringu nie wykazał, aby 44-latek opuścił teren leśny.

## Miedwiediew w formie. PorĂłwnał Polskę do III Rzeszy. "Rozpęta III wojnę światową"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30366601,dmitrij-miedwiediew-porownal-polske-do-iii-rzeszy-wtedy-hiena.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30366601,dmitrij-miedwiediew-porownal-polske-do-iii-rzeszy-wtedy-hiena.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-03T11:26:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/dd/f5/1c/z30366941M,Dmitrij-Miedwiediew.jpg" vspace="2" />Dmitrij Miedwiediew porĂłwnał PolakĂłw do nazistĂłw i stwierdził, że nasz kraj może wywołać III wojnę światową, dążąc do konfrontacji z Rosją i Białorusią. Wiceprzewodniczący Rady Bezpieczeństwa Rosji powiedział rĂłwnież, że "polscy panowie" traktują UkraińcĂłw jak "poddanych". Miedwiediew po raz kolejny powielał propagandę, że Polska może użyć swojego wojska, aby dokonać aneksji ukraińskich ziem.

## Czy Tusk spełni oczekiwania UE i Polski? Niemiecka prasa: Nie zaakceptuje wszystkiego
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,127561,30366884,czy-tusk-spelni-oczekiwania-ue-i-polski-niemiecka-prasa-nie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,127561,30366884,czy-tusk-spelni-oczekiwania-ue-i-polski-niemiecka-prasa-nie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-03T11:13:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ea/95/1c/z29970666M,Donald-Tusk---zdjecie-ilustracyjne.jpg" vspace="2" />Partie demokratycznej opozycji - KO, Trzecia Droga i Lewica kontynuują rozmowy nad umową koalicyjną. "Tagesspiegel" zapytał ekspertĂłw, czy rząd Donalda Tuska spełni nadzieje PolakĂłw i UE.

## Tragedia w sanatorium w Kołobrzegu. Nie żyje 21-letni obywatel Czech
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30367021,tragedia-w-sanatorium-w-kolobrzegu-nie-zyje-21-letni-obywatel.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30367021,tragedia-w-sanatorium-w-kolobrzegu-nie-zyje-21-letni-obywatel.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-03T11:03:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/7d/f5/1c/z30365821M,Ambulans--zdjecie-ilustracyjne-.jpg" vspace="2" />Lekarze nie zdołali uratować życia 21-letniemu obywatelowi Czech, ktĂłry wypadł z balkonu na trzecim piętrze sanatorium w Kołobrzegu - poinformował w piątek Ryszard Gąsiorowski, rzecznik prokuratury Okręgowej w Koszalinie w rozmowie z Polską Agencją Prasową.

## Umowa koalicyjna coraz bliżej. Nie obejmie ważnego postulatu Lewicy i KO. Ale pieniądze są
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30366654,umowa-koalicyjna-coraz-blizej-nie-obejmie-waznego-postulatu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30366654,umowa-koalicyjna-coraz-blizej-nie-obejmie-waznego-postulatu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-03T11:02:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d0/f3/1c/z30355664M,Oswiadczenie-liderow-opozycji.jpg" vspace="2" />To koncepcja Lewicy i Koalicji Obywatelskiej na kształt umowy koalicyjnej wygrała. Paradoksalnie przez to nie zostanie w niej zawarty ważny postulat obu partii - ustaliła "Gazeta Wyborcza". Wiemy też, że mają się znaleźć pieniądze na spełnienie obietnicych wyborczych.

## Szokujące nagranie z centrum Warszawy. Zadał ciosy nożem i uciekł. Policja szuka sprawcy ataku
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30366749,szokujace-nagranie-z-centrum-warszawy-zadal-ciosy-nozem-i-uciekl.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30366749,szokujace-nagranie-z-centrum-warszawy-zadal-ciosy-nozem-i-uciekl.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-03T10:39:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/9c/f5/1c/z30366876M,Policja-opublikowala-wizerunek-napastnika--ktory-m.jpg" vspace="2" />Warszawscy policjanci poszukują mężczyzny, ktĂłry jest podejrzewany o usiłowanie zabĂłjstwa we wrześniu tego roku. "Sprawca, najprawdopodobniej nożem, zadał kilka uderzeń przypadkowemu mężczyźnie" - poinformowali policjanci i opublikowali wizerunek poszukiwanego.

## Polityk PiS podsumował kampanię wyborczą partii. "Były momenty, kiedy o Tusku było za dużo"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30366537,stanislaw-karczewski-podsumowal-kampanie-wyborcza-pis-byly.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30366537,stanislaw-karczewski-podsumowal-kampanie-wyborcza-pis-byly.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-03T10:34:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/73/f5/1c/z30366835M,Stanislaw-Karczewski-z-PiS.jpg" vspace="2" />Stanisław Karczewski ocenił tegoroczną kampanię wyborczą PiS i wymienił błędy, ktĂłre jego zdaniem doprowadziły do niesatysfakcjonującego wyniku. - Były momenty, kiedy o Tusku było za dużo - przyznał. WśrĂłd czynnikĂłw, ktĂłre miały wpływ na wynik, wymienił także kwestie decyzji Trybunału Konstytucyjnego w sprawie aborcji czy głosy młodych i niezdecydowanych.

## Prezes PiS wydał ponad 200 tys. zł na biuro. Ile zarabiają jego pracownicy? Pensje nie powalają
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30366418,jaroslaw-kaczynski-wydal-ponad-200-tys-zl-na-biuro-poselskie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30366418,jaroslaw-kaczynski-wydal-ponad-200-tys-zl-na-biuro-poselskie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-03T09:53:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e9/f5/1c/z30366697M,Jaroslaw-Kaczynski.jpg" vspace="2" />Biuro poselskie Jarosława Kaczyńskiego w zeszłym roku kosztowało polityka nieco ponad 200 tys. złotych. Najwięcej pochłonęły pensje pracownikĂłw, opinie, ekspertyzy czy wynajem lokalu przy al. Jerozolimskich. Ile dokładnie zarabiają pracownicy prezesa PiS?

## Nowe informacje ws. Grzegorza Borysa. Jest komunikat policji. "W tym miejscu może znajdować się poszukiwany"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30366700,nowe-informacje-ws-poszukiwan-grzegorza-borysa-jest-komunikat.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30366700,nowe-informacje-ws-poszukiwan-grzegorza-borysa-jest-komunikat.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-03T09:48:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/58/82/1b/z28845912M,Pilne.jpg" vspace="2" />W związku z obławą na Grzegorza Borysa służby podjęły decyzję o zawężeniu terenu poszukiwań do dwĂłch hektarĂłw - przekazała w piątek pomorska policja.

## Przerażające ataki wilkĂłw. "Była poszarpana, zjedzona". Rolnicy apelują o pomoc i zmianę przepisĂłw
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30366334,przerazajace-ataki-wilkow-byla-poszarpana-z-wypatroszonymi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30366334,przerazajace-ataki-wilkow-byla-poszarpana-z-wypatroszonymi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-03T09:46:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/3f/f5/1c/z30366527M,Wilk--zdjecie-ilustracyjne-.jpg" vspace="2" />Rolnicy zmagają się z coraz częstszymi atakami wilkĂłw, ktĂłre wchodzą do obĂłr i zagryzają zwierzęta. Hodowcy mĂłwią, że czują się "sfrustrowani i bezsilni", ponieważ nie otrzymują wystarczającego wsparcia od instytucji państwowych. Rolnicy z Mazur przedstawili swoje żądania w liście do ministra rolnictwa.

## Szokujące zachowanie turystki. Podczas huraganu wyszła na molo, żeby zrobić sobie zdjęcie [WIDEO]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30366377,szokujace-zachowanie-turystki-podczas-huraganu-wyszla-na-molo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30366377,szokujace-zachowanie-turystki-podczas-huraganu-wyszla-na-molo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-03T09:37:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ae/f5/1c/z30366382M,Ciaran.jpg" vspace="2" />Internet obiegło nagranie, na ktĂłrym kobieta usiłuje zrobić selfie na molo w nadmorskiej miejscowości Whitby w Wielkiej Brytanii, mimo niebezpiecznych warunkĂłw pogodowych. W pewnym momencie widać, jak zostaje przewrĂłcona przez fale.

## Putin podpisał ustawę w sprawie prĂłb jądrowych. Polskie MSZ zaniepokojone: Kolejne osłabienie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30366296,polskie-msz-wyrazilo-niepokoj-powodem-decyzja-wladimira-putina.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30366296,polskie-msz-wyrazilo-niepokoj-powodem-decyzja-wladimira-putina.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-03T09:19:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e1/f5/1c/z30366433M,Rosja--Wladimir-Putin-podpisal-ustawe--Polskie-MSZ.jpg" vspace="2" />Polskie MSZ wyraziło zaniepokojenie. Powodem jest ustawa unieważniająca ratyfikację przez Rosję Traktatu o całkowitym zakazie prĂłb jądrowych (CTBT). "Ten nieuzasadniony i bezprecedensowy krok stanowi kolejne osłabienie architektury bezpieczeństwa międzynarodowego" - przekazał resort. Rosja przekazała, że podejmie testy nuklearne w konkretnym przypadku.

## Wojna w Ukrainie. Alarm w pobliżu polskiej granicy. Rosjanie wystrzelili 38 dronĂłw
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30366400,wojna-w-ukrainie-alarm-w-poblizu-polskiej-granicy-rosjanie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30366400,wojna-w-ukrainie-alarm-w-poblizu-polskiej-granicy-rosjanie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-03T09:15:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e3/f5/1c/z30366435M,Zniszczenie-po-ataku-dronow-z-Rosji.jpg" vspace="2" />Rosjanie w nocy masowo atakowali Ukrainę dronami. Celem atakĂłw były obiekty w głębi kraju. Rosyjskie bezzałogowce, bądź ich odłamki spadły w Charkowie, w południowych obwodach, ale też na zachodzie Ukrainy, rĂłwnież blisko polskiej granicy. Rosja znĂłw też atakowała też cywili.

## Dziwne zachowanie Putina. Trzymał się za rękę, potem nerwowo zdejmował zegarek [WIDEO]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30366151,dziwne-zachowanie-putina-trzymal-sie-za-reke-potem-nerwowo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30366151,dziwne-zachowanie-putina-trzymal-sie-za-reke-potem-nerwowo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-03T08:39:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d6/f5/1c/z30366166M,Wladimir-Putin.jpg" vspace="2" />Wracają spekulacje na temat stanu zdrowia Władimira Putina. W sieci pojawiło się nagranie, na ktĂłrym rosyjski przywĂłdca zachowuje się w dziwny sposĂłb. Na jednym z nich prezydent Rosji prĂłbuje nerwowo ściągnąć zegarek z ręki.

## Obława na Grzegorza Borysa. Policja zawęziła teren poszukiwań. Polityk KO: To wydaje się dziwne
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30366147,trwa-oblawa-za-grzegorzem-borysem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30366147,trwa-oblawa-za-grzegorzem-borysem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-03T08:38:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/8e/f5/1c/z30366350M,Slawomir-Nitras.jpg" vspace="2" />W dalszym ciągu w TrĂłjmieście trwają poszukiwania Grzegorza Borysa, ktĂłry jest podejrzany o zabĂłjstwo swojego sześcioletniego syna. Policja poinformowała, że zawężono teren poszukiwań 44-latka. Tę decyzję służb zakwestionował polityk Koalicji Obywatelskiej Sławomir Nitras.

## Kto na marszałka-seniora? Nieoficjalnie: Andrzej Duda ma swĂłj typ. To może być pierwszy przypadek w historii
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30366211,kto-na-marszalka-seniora-nieoficjalnie-andrzej-duda-ma-swoj.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30366211,kto-na-marszalka-seniora-nieoficjalnie-andrzej-duda-ma-swoj.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-03T08:29:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/7e/f2/1c/z30355326M,Andrzej-Duda.jpg" vspace="2" />Żaden poseł z listy PKW może nie zostać marszałkiem-seniorem. Andrzej Duda jest bliski podjęcia decyzji. Pierwsze posiedzenie Sejmu może otwierać kobieta - donosi Wirtualna Polska. Byłby to pierwszy taki przypadek w historii Polski.

## Konfederacja ma problemy? Zza kulis rządzi już inny polityk. "Istnieje ryzyko, że się podzielimy"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30366112,konfederacja-zmaga-sie-z-problemami-z-tylnego-siedzenia-partia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30366112,konfederacja-zmaga-sie-z-problemami-z-tylnego-siedzenia-partia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-03T08:18:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/41/f5/1c/z30366273M,Konfederacja--Janusz-Korwin-Mikke.jpg" vspace="2" />Konfederacja zmaga się z trudnościami, a wiele wskazuje, że mogą nadejść kolejne. Janusz Korwin-Mikke przyznał w rozmowie z "Rzeczpospolitą", że nosi się z zamiarem utworzenia nowej partii. Grzegorz Braun ma w tym czasie stawiać żądania finansowe, Sławomir Mentzen "porządkować sprawy", a z "tylnego siedzenia" partią ma kierować inny polityk.

## Wołodymyra Zełenskiego chce zastąpić jego były dordca. MĂłwi o rozmowach pokojowych z Rosją
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30366028,to-on-chce-zastapic-wolodymyra-zelenskiego-chce-startowac-w.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30366028,to-on-chce-zastapic-wolodymyra-zelenskiego-chce-startowac-w.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-03T08:09:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/bd/f5/1c/z30366141M,Oleksij-Arestowycz.jpg" vspace="2" />Oleksij Arestowicz były doradca prezydenta Wołodymyra Zełenskiego zamierza kandydować w najbliższych wyborach prezydenckich w Ukrainie. - Sam się zgłoszę - zapewnił. Opublikował rĂłwnież swĂłj program wyborczy.

## "Rz": Polska wydała ok. 90 tys. wiz dla informatykĂłw ze Wschodu. 80 tys. osĂłb zniknęło
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30366074,polska-wydala-ok-90-tys-wiz-wsrod-odbiorcow-bialorusini-i.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30366074,polska-wydala-ok-90-tys-wiz-wsrod-odbiorcow-bialorusini-i.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-03T07:52:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/89/6b/1c/z29801609M,Programisci--ilustracyjne.jpg" vspace="2" />Z kilkudziesięciu tysięcy specjalistĂłw IT z zagranicy, ktĂłrzy otrzymali krajową wizę, tylko nieliczni trafili do Polski. Nie wiadomo co stało się z resztą - donosi w piątek "Rzeczpospolita". Dokumenty otrzymywali m.in. Białorusini i Rosjanie.

## Wojna Izraela z Hamasem się rozprzestrzeni? PrzywĂłdca Hezbollahu w piątek wygłosi przemĂłwienie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30366031,wojna-izraela-z-hamasem-sie-rozprzestrzeni-przywodca-hezbollahu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30366031,wojna-izraela-z-hamasem-sie-rozprzestrzeni-przywodca-hezbollahu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-03T07:35:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/dd/f5/1c/z30366173M,Na-tym-zdjeciu-opublikowanym-w-srode--25-pazdziern.jpg" vspace="2" />W piątek po raz pierwszy od początku wybuchu wojny 7 października głos ma zabrać przywĂłdca Hezbollahu Hassan Nasr Allah. Tymczasem strona izraelska stwierdziła, że "zakończono okrążenie miasta Gaza, ktĂłre jest centralnym punktem organizacji terrorystycznej Hamas".

## Znany duchowny o mszy przebłagalnej za Halloween: Strzelanie z potężnych dział religijnych do wrĂłbli
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30366026,znany-duchowny-o-mszy-przeblagalnej-za-halloween-strzelanie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30366026,znany-duchowny-o-mszy-przeblagalnej-za-halloween-strzelanie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-03T07:32:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/99/f5/1c/z30366105M,Dominikanin-ojciec-Pawel-Guzynski.jpg" vspace="2" />Msza przebłagalna za Halloween to "wyraźna przesada z podtekstem neurotycznym", twierdzi ojciec Paweł Gużyński. Dominikanin dostrzega "szajby związane z Halloween", ale uważa, że Eucharystia zorganizowana przez księży z Krakowa nie była dobrą odpowiedzią na te zjawiska.

## Orkan Ciaran przechodzi przez Europę. Wzrosła liczba ofiar. W piątek żywioł dotrze do Polski
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30365983,orkan-ciaran-przechodzi-przez-europe-wzrosla-liczba-ofiar.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30365983,orkan-ciaran-przechodzi-przez-europe-wzrosla-liczba-ofiar.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-03T06:27:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/22/f5/1c/z30365986M,Ciaran.jpg" vspace="2" />Co najmniej dziesięć osĂłb zginęło, a dziesiątki zostało rannych z powodu huraganu Ciaran. W piątek skutki orkanu odczujemy także w Polsce, jednak najniebezpieczniejsze zjawiska atmosferyczne mają ominąć nasz kraj.

## Horoskop dzienny - piątek 3 listopada 2023 [Baran, Byk, Bliźnięta, Rak, Lew, Panna, Waga, Skorpion, Strzelec, Koziorożec, Wodnik, Ryby]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,168571,30364774,horoskop-dzienny-piatek-3-listopada-2023-baran-byk-bliznieta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,168571,30364774,horoskop-dzienny-piatek-3-listopada-2023-baran-byk-bliznieta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-03T04:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/14/89/1c/z29924372M,Horoskop-dzienny---piatek.jpg" vspace="2" />Piątek przyniesie wiele zaskoczeń i niespodzianek. NiektĂłre znaki zodiaku mogą odnosić wrażenie, że los kieruje dziś za nich. Horoskop dzienny na piątek podpowiada, czego można się spodziewać.

## Święto Niepodległości 11 listopada. Czy przysługuje dodatkowy dzień wolnego? Ważny jeden czynnik
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30365794,swieto-niepodleglosci-11-listopada-czy-przysluguje-dodatkowy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30365794,swieto-niepodleglosci-11-listopada-czy-przysluguje-dodatkowy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-03T04:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/6a/f5/1c/z30365802M,Marsz-Niepodleglosci-w-Warszawie.jpg" vspace="2" />Wielkimi krokami zbliża się Narodowe Święto Niepodległości. Obchodzone co roku 11 listopada święto państwowe daje pracownikom dzień wolny od pracy. W tym roku przypada jednak na sobotę. Czy w związku z tym możemy spodziewać się dodatkowego dnia wolnego w naszym grafiku?

## Osoba z niepełnosprawnością musiała wyczołgać się z samolotu. Obsługa odwracała wzrok ze wstydu
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30365714,osoba-z-niepelnosprawnoscia-musiala-wyczolgac-sie-z-samolotu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30365714,osoba-z-niepelnosprawnoscia-musiala-wyczolgac-sie-z-samolotu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-11-03T04:05:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/32/f5/1c/z30365746M,Malzenstwo-postanowilo-naglosnic-sytuacje--z-jaka-.jpg" vspace="2" />Na lotnisku w Las Vegas (USA) obsługa samolotu odmĂłwiła osobie z niepełnosprawnością pomocy przy wydostaniu się z maszyny. 49-letni mężczyzna zmuszony był sam wyczołgać się ze swojego miejsca. Odpowiedzialne za lot linie lotnicze Air Canada wydały oświadczenie.

