# Source:RT - Daily news, URL:https://www.rt.com/rss/, language:en

## US asked Israel to avoid killing civilians – Politico
 - [https://www.rt.com/news/586543-us-israel-civilian-strikes/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/586543-us-israel-civilian-strikes/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T23:28:28+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6545819485f540068e63a85f.jpg" style="margin-right: 10px;" /> The US is “pushing hard” on Israel to avoid more mass casualties in Gaza, Politico has reported citing officials and members of Congress <br /><a href="https://www.rt.com/news/586543-us-israel-civilian-strikes/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Israel launches attack on Russia at UN
 - [https://www.rt.com/news/586542-israel-attack-russia-un/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/586542-israel-attack-russia-un/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T22:21:32+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6545714185f540067037e02a.jpg" style="margin-right: 10px;" /> Moscow’s criticism of the Israeli military operation in Gaza has sparked an angry reaction from West Jerusalem <br /><a href="https://www.rt.com/news/586542-israel-attack-russia-un/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Israel vows to use ‘all power’ to bomb Gaza after US' call for humanitarian pause
 - [https://www.rt.com/news/586541-israel-bomb-gaza-all-power/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/586541-israel-bomb-gaza-all-power/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T22:12:18+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/65456fb585f5405c22383d6d.jpg" style="margin-right: 10px;" /> Israel will continue massive bombardments of Gaza, Prime Minister Benjamin Netanyahu has said after meeting the US state secretary <br /><a href="https://www.rt.com/news/586541-israel-bomb-gaza-all-power/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Why American Muslims aren’t buying Biden’s anti-Islamophobia spiel
 - [https://www.rt.com/news/586524-biden-islamophobia-israel-gaza/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/586524-biden-islamophobia-israel-gaza/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T21:19:34+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6545635e85f5407e7022f0d6.jpg" style="margin-right: 10px;" /> Washington’s unquestioning support for Israel’s attack on Gaza invalidates any anti-hate “strategy” the White House may present at home <br /><a href="https://www.rt.com/news/586524-biden-islamophobia-israel-gaza/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Call to fight ‘snow penises’ issued in Russia
 - [https://www.rt.com/russia/586535-ekaterinburg-russia-snow-penis/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/586535-ekaterinburg-russia-snow-penis/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T21:02:36+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/65454802203027506b4db4a7.png" style="margin-right: 10px;" /> Officials in Ekaterinburg have called on the police and the public to rid the city of phallic snow sculptures <br /><a href="https://www.rt.com/russia/586535-ekaterinburg-russia-snow-penis/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Ally teases Biden with beach invitation
 - [https://www.rt.com/news/586532-biden-beach-invitation-dominican/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/586532-biden-beach-invitation-dominican/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T20:11:10+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/65454ee3203027567d135671.jpg" style="margin-right: 10px;" /> The 2025 Summit of the Americas will be held in the Dominican resort of Punta Cana, beach-loving Joe Biden has been told <br /><a href="https://www.rt.com/news/586532-biden-beach-invitation-dominican/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russia should protect Zelensky
 - [https://www.rt.com/russia/586534-russia-should-protect-zelensky/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/586534-russia-should-protect-zelensky/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T19:58:28+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/654543cd203027567d135667.jpg" style="margin-right: 10px;" /> The erratic behavior and growing Messiah complex of Ukrainian leader Vladimir Zelensky means he’s now an asset to Moscow <br /><a href="https://www.rt.com/russia/586534-russia-should-protect-zelensky/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## South Korea ‘mobilizing banks’ to finance Poland arms sale – Reuters
 - [https://www.rt.com/news/586533-poland-south-korea-arms-loan/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/586533-poland-south-korea-arms-loan/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T18:53:27+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/65453d6b85f540067037e01d.jpg" style="margin-right: 10px;" /> South Korean banks are to help finance a Polish purchase of weapons from Seoul, Reuters says <br /><a href="https://www.rt.com/news/586533-poland-south-korea-arms-loan/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## US preparing nuclear test site in Nevada – Moscow
 - [https://www.rt.com/news/586530-russia-usa-nuclear-tests/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/586530-russia-usa-nuclear-tests/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T18:51:23+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6545345b2030275f5e08d780.jpg" style="margin-right: 10px;" /> Russia has warned the US it will respond in kind if Washington returns to testing nuclear weapons, which neither country has done since 1992 <br /><a href="https://www.rt.com/news/586530-russia-usa-nuclear-tests/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Family of dead ice hockey star demand ‘justice’
 - [https://www.rt.com/news/586531-ice-hockey-death-reckless/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/586531-ice-hockey-death-reckless/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T18:07:43+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6545328020302743b9221ab5.png" style="margin-right: 10px;" /> The family of an ice hockey player who died in a freak accident last week demand justice <br /><a href="https://www.rt.com/news/586531-ice-hockey-death-reckless/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Abortion an ‘acute’ problem in Russia – Putin
 - [https://www.rt.com/russia/586526-putin-russia-abortion-acute/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/586526-putin-russia-abortion-acute/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T18:05:16+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/654526c7203027660f67e0df.jpg" style="margin-right: 10px;" /> Among possible solutions to Russia’s ‘acute’ abortion rate is to increase support for parenthood, President Vladimir Putin has said <br /><a href="https://www.rt.com/russia/586526-putin-russia-abortion-acute/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## France is out, who is in? African countries are building a new security order
 - [https://www.rt.com/africa/586515-crisis-mali-france-influence/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/africa/586515-crisis-mali-france-influence/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T17:30:21+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6545071485f540653678ab56.jpg" style="margin-right: 10px;" /> With Paris’ influence declining, a new security structure is emerging in the Sahel region, bringing both problems and opportunities <br /><a href="https://www.rt.com/africa/586515-crisis-mali-france-influence/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Putin explains reasons for Ukraine military operation
 - [https://www.rt.com/russia/586529-putin-reasons-ukraine-military-operation/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/586529-putin-reasons-ukraine-military-operation/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T17:28:48+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/654528fc85f54015b81c77d0.jpg" style="margin-right: 10px;" /> Russia’s decision to launch a military operation in Ukraine was a response to an “attack” from abroad, Vladimir Putin has said <br /><a href="https://www.rt.com/russia/586529-putin-reasons-ukraine-military-operation/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Zelensky to visit Israel – media
 - [https://www.rt.com/news/586528-zelensky-ukraine-visit-israel/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/586528-zelensky-ukraine-visit-israel/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T17:15:50+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6545274085f5402d2773315c.jpg" style="margin-right: 10px;" /> Ukrainian President Vladimir Zelensky will visit Israel next week in a show of unity, Hebrew-language media have reported <br /><a href="https://www.rt.com/news/586528-zelensky-ukraine-visit-israel/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Niger turns to China to build Africa’s longest oil pipeline – AFP
 - [https://www.rt.com/africa/586527-niger-china-oil-pipeline/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/africa/586527-niger-china-oil-pipeline/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T17:07:25+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6545277b20302743b9221ab0.jpg" style="margin-right: 10px;" /> Niger has commissioned a giant cross-border crude pipeline despite the sanctions from ECOWAS and the EU <br /><a href="https://www.rt.com/africa/586527-niger-china-oil-pipeline/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## India’s EV market booming – Bloomberg
 - [https://www.rt.com/india/586519-india-electric-vehicles-market-growth/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/india/586519-india-electric-vehicles-market-growth/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T16:23:32+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6545178a85f54079bf2d2f1a.jpg" style="margin-right: 10px;" /> India’s electric vehicle market is reportedly flourishing thanks to new models that cost under $20,000 <br /><a href="https://www.rt.com/india/586519-india-electric-vehicles-market-growth/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russian prosecutor refuses to designate Hamas as ‘terrorists’ – media
 - [https://www.rt.com/russia/586517-russia-hamas-terrorist-organization/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/586517-russia-hamas-terrorist-organization/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T16:11:06+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/65450a6e85f54008cb61b473.jpg" style="margin-right: 10px;" /> Russia’s Prosecutor General’s Office has refused to designate Hamas as terrorists as there are no criminal investigations into the group <br /><a href="https://www.rt.com/russia/586517-russia-hamas-terrorist-organization/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Hezbollah ‘entered battle’ on October 8 – leader
 - [https://www.rt.com/news/586523-hezbollah-hassan-nasrallah-speech/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/586523-hezbollah-hassan-nasrallah-speech/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T16:07:14+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6545166a85f5405c22383d5e.jpg" style="margin-right: 10px;" /> Hezbollah leader Hassan Nasrallah has delivered a long-anticipated speech explaining his group’s involvement in the Israel-Hamas war <br /><a href="https://www.rt.com/news/586523-hezbollah-hassan-nasrallah-speech/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Aerosmith’s Steven Tyler hit by new sexual assault allegations
 - [https://www.rt.com/pop-culture/586521-us-aerosmith-tyler-allegations/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/pop-culture/586521-us-aerosmith-tyler-allegations/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T15:52:00+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6545162085f5407e4b0138ee.jpg" style="margin-right: 10px;" /> Grammy Award-winning musician Steven Tyler ‘held a teenage woman captive’ in the 1970s, it was claimed in a lawsuit filed this week <br /><a href="https://www.rt.com/pop-culture/586521-us-aerosmith-tyler-allegations/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Ukrainian security chief seeks to ban Telegram
 - [https://www.rt.com/russia/586520-ukraine-security-chief-ban-telegram/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/586520-ukraine-security-chief-ban-telegram/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T15:28:04+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6545102e20302743b9221aa2.jpg" style="margin-right: 10px;" /> Ukraine’s security chief, Aleksey Danilov, has branded the Telegram messenger app “dangerous,” adding that Kiev is considering blocking it <br /><a href="https://www.rt.com/russia/586520-ukraine-security-chief-ban-telegram/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Branch of Russian university to be set up in Egypt
 - [https://www.rt.com/africa/586507-russian-university-branch-egypt/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/africa/586507-russian-university-branch-egypt/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T14:56:39+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6544f2a385f5404db766efa3.jpg" style="margin-right: 10px;" /> Egypt’s President Abdel Fattah el-Sisi has approved the opening of Kazan University’s Cairo branch <br /><a href="https://www.rt.com/africa/586507-russian-university-branch-egypt/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## NATO state calls for new European security architecture
 - [https://www.rt.com/news/586510-hungary-europe-security-architecture/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/586510-hungary-europe-security-architecture/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T14:52:24+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6544f96a203027400d08e030.jpg" style="margin-right: 10px;" /> Hungary supports a new security architecture in Europe that takes into account Russian and Ukrainian interests, PM Viktor Orban has said <br /><a href="https://www.rt.com/news/586510-hungary-europe-security-architecture/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## India and US to exchange views on China next week
 - [https://www.rt.com/india/586511-india-us-minesterial-dialogue-china/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/india/586511-india-us-minesterial-dialogue-china/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T14:35:20+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6544f9b0203027400d08e033.jpg" style="margin-right: 10px;" /> US top officials Antony Blinken and Lloyd Austin head to New Delhi to discuss defense and strategic issues <br /><a href="https://www.rt.com/india/586511-india-us-minesterial-dialogue-china/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## US house speaker refuses to meet Ukrainian religious lobbyists – WaPo
 - [https://www.rt.com/news/586509-ukraine-orthodox-washington-visit/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/586509-ukraine-orthodox-washington-visit/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T14:08:30+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6544f92085f5405c22383d40.jpg" style="margin-right: 10px;" /> US House Speaker Mike Johnson turned down a request to meet government-aligned clergy from Ukraine, the Washington Post reported <br /><a href="https://www.rt.com/news/586509-ukraine-orthodox-washington-visit/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russia no longer a ‘gas station’ for the rest of the world – Putin
 - [https://www.rt.com/business/586501-russia-self-sufficient-putin/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/586501-russia-self-sufficient-putin/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T14:01:56+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6544fab785f5400efe6b73d5.jpg" style="margin-right: 10px;" /> Russian economy should be sovereign and independent in order to withstand the Western pressure, President Putin has said <br /><a href="https://www.rt.com/business/586501-russia-self-sufficient-putin/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## EU’s Ukraine strategy a ‘complete failure’ – member state
 - [https://www.rt.com/news/586512-eu-ukraine-strategy-failure/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/586512-eu-ukraine-strategy-failure/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T13:53:48+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6544fb3185f5405c22383d48.jpg" style="margin-right: 10px;" /> Hungarian PM Viktor Orban has insisted the EU needs a “plan B” for Ukraine which would provide for a ceasefire and peace negotiations <br /><a href="https://www.rt.com/news/586512-eu-ukraine-strategy-failure/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Zelensky will be Ukraine’s last president – exiled opposition leader
 - [https://www.rt.com/russia/586508-medvedchuk-zelensky-column-traitor/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/586508-medvedchuk-zelensky-column-traitor/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T13:40:58+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6544f51f203027660f67e0c4.jpg" style="margin-right: 10px;" /> Ex-Ukrainian opposition leader Viktor Medvedchuk has blasted President Vladimir Zelensky for allegedly “betraying everyone” during his term <br /><a href="https://www.rt.com/russia/586508-medvedchuk-zelensky-column-traitor/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Algerian lawmakers authorize president to stand against Israel
 - [https://www.rt.com/africa/586504-algerian-president-palestine-support-authorization/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/africa/586504-algerian-president-palestine-support-authorization/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T13:36:10+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6544f0c085f5407e7022f0b2.jpg" style="margin-right: 10px;" /> Algerian lawmakers have voted to allow President Abdelmadjid Tebboune to support Palestine in the Israel-Hamas conflict <br /><a href="https://www.rt.com/africa/586504-algerian-president-palestine-support-authorization/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## US seeks help from Arab states in Gaza – WSJ
 - [https://www.rt.com/news/586500-us-seeks-help-arab-gaza/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/586500-us-seeks-help-arab-gaza/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T13:04:46+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6544ef5d203027400d08e025.jpg" style="margin-right: 10px;" /> US Secretary of State Anthony Blinken is set to hold talks with Arab nations about the post-war governance of Gaza, the WSJ has said <br /><a href="https://www.rt.com/news/586500-us-seeks-help-arab-gaza/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Europe on verge of housing crisis – Bloomberg
 - [https://www.rt.com/business/586499-europe-housing-crisis-permits-decline/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/586499-europe-housing-crisis-permits-decline/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T12:58:41+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6544e42a203027400d08e013.jpg" style="margin-right: 10px;" /> The number of new building permits in wealthy European countries has seen a massive decline this year <br /><a href="https://www.rt.com/business/586499-europe-housing-crisis-permits-decline/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Western nations 'changing tune’ on defeating Russia – Putin
 - [https://www.rt.com/russia/586503-putin-victory-ukraine-enemies/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/586503-putin-victory-ukraine-enemies/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T12:43:55+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/static.en/thumbnail/breaking.jpg" style="margin-right: 10px;" /> Russian President Vladimir Putin has explained how national strength deters foreign players from adopting hostile policies <br /><a href="https://www.rt.com/russia/586503-putin-victory-ukraine-enemies/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Next few years will determine future world order – Biden
 - [https://www.rt.com/news/586496-biden-next-years-decisive/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/586496-biden-next-years-decisive/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T12:25:45+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6544e56020302746e732e9d7.jpg" style="margin-right: 10px;" /> The next few years will determine the fate of the world for generations to come, US President Joe Biden has said <br /><a href="https://www.rt.com/news/586496-biden-next-years-decisive/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## You’re either with us or Hamas – Israel
 - [https://www.rt.com/news/586490-israel-no-neutrality-hamas/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/586490-israel-no-neutrality-hamas/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T12:13:21+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6544e10320302744ce6c23cf.jpg" style="margin-right: 10px;" /> Nations cannot be neutral on Israel’s conflict with Hamas, spokesman for the Israeli Foreign Ministry Lior Hayat has claimed <br /><a href="https://www.rt.com/news/586490-israel-no-neutrality-hamas/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Ukraine ‘going badly’ for US - Trump
 - [https://www.rt.com/news/586493-trump-us-ukraine-bad/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/586493-trump-us-ukraine-bad/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T11:37:26+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6544db3d20302744a70f1779.jpg" style="margin-right: 10px;" /> Former US President Donald Trump noted that the media no longer talks about Ukraine, suggesting that Kiev is faring poorly <br /><a href="https://www.rt.com/news/586493-trump-us-ukraine-bad/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Sanctioned Russian stock exchange to resume trading
 - [https://www.rt.com/business/586482-russia-stock-exchange-sanctions/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/586482-russia-stock-exchange-sanctions/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T11:08:14+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6544cafa85f54079bf2d2ede.jpg" style="margin-right: 10px;" /> The SPB Exchange has announced the resumption of trading in Russian securities after being hit with US sanctions <br /><a href="https://www.rt.com/business/586482-russia-stock-exchange-sanctions/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Pussy Riot founder given eight-year prison sentence
 - [https://www.rt.com/russia/586486-pussy-riot-verzilov-sentenced-absentia/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/586486-pussy-riot-verzilov-sentenced-absentia/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T10:52:07+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6544c0a1203027506b4db472.jpg" style="margin-right: 10px;" /> A Russian court has handed down a prison sentence in absentia to activist Pyotr Verzilov, for promoting fake information about the military <br /><a href="https://www.rt.com/russia/586486-pussy-riot-verzilov-sentenced-absentia/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Putin meets with president of Equatorial Guinea
 - [https://www.rt.com/africa/586483-russia-reopen-embassy-equatorial-guinea/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/africa/586483-russia-reopen-embassy-equatorial-guinea/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T10:42:21+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6544bd0e203027567d13562b.jpg" style="margin-right: 10px;" /> Vladimir Putin has met with President Obiang of Equatorial Guinea and the two have discussed cooperation in different areas <br /><a href="https://www.rt.com/africa/586483-russia-reopen-embassy-equatorial-guinea/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## EU has lost $1.5 trillion over Russia sanctions – Moscow
 - [https://www.rt.com/business/586479-eu-sanctions-russia-losses/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/586479-eu-sanctions-russia-losses/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T10:15:42+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6544c51f85f540068e63a823.jpg" style="margin-right: 10px;" /> Cutting trade ties with Russia is damaging the economies of EU member states, the Foreign Ministry in Moscow has said <br /><a href="https://www.rt.com/business/586479-eu-sanctions-russia-losses/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Everyone in Ukraine must serve – security chief
 - [https://www.rt.com/russia/586484-everyone-must-serve-ukraine/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/586484-everyone-must-serve-ukraine/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T09:50:04+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6544c09685f54015b81c7788.jpg" style="margin-right: 10px;" /> It is a “fundamental truth” that everyone in Ukraine must serve in some capacity, Ukraine’s security chief has said <br /><a href="https://www.rt.com/russia/586484-everyone-must-serve-ukraine/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Moscow to ship more free wheat to Africa
 - [https://www.rt.com/africa/586480-moscow-africa-free-wheat-shipment/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/africa/586480-moscow-africa-free-wheat-shipment/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T09:06:47+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6544b6b82030274b094a8e09.jpg" style="margin-right: 10px;" /> The Russian Foreign Ministry says Moscow will send more free shipments of wheat to six African countries by the end of 2023 <br /><a href="https://www.rt.com/africa/586480-moscow-africa-free-wheat-shipment/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Indian capital hit by ‘severe’ smog as winter arrives
 - [https://www.rt.com/india/586478-new-delhi-pollution-levels/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/india/586478-new-delhi-pollution-levels/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T08:43:53+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6544a87b85f540410d536b92.jpg" style="margin-right: 10px;" /> The capital of India’s government has shut down schools and banned construction as New Delhi faces another air pollution crisis <br /><a href="https://www.rt.com/india/586478-new-delhi-pollution-levels/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## First woman approved to lead US Navy
 - [https://www.rt.com/news/586475-first-fremale-navy-confirmed/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/586475-first-fremale-navy-confirmed/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T08:35:37+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6544a25a85f540067037dff2.jpg" style="margin-right: 10px;" /> US Senator Tommy Tuberville has allowed confirmation votes for three top-level military nominations after criticism by fellow GOP lawmakers <br /><a href="https://www.rt.com/news/586475-first-fremale-navy-confirmed/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Iran seeking to avoid full-scale conflict with Israel – CNN
 - [https://www.rt.com/news/586476-iran-avoid-war-israel/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/586476-iran-avoid-war-israel/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T08:22:19+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6544a2ac85f54079bf2d2ec3.jpg" style="margin-right: 10px;" /> Iran and its regional allies seek to push back against Israel over the Gaza conflict but don’t want a full-scale war, CNN has reported <br /><a href="https://www.rt.com/news/586476-iran-avoid-war-israel/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## EU turns to Ukraine to store gas – FT
 - [https://www.rt.com/business/586364-eu-gas-ukraine-storage/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/586364-eu-gas-ukraine-storage/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T06:04:54+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/65426dd285f540205743df3a.jpg" style="margin-right: 10px;" /> Some European countries are reportedly storing emergency gas supplies in Ukraine despite conflict-related risks <br /><a href="https://www.rt.com/business/586364-eu-gas-ukraine-storage/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russians think ‘Black Friday’ is a scam – survey
 - [https://www.rt.com/business/586420-russia-black-friday-scam-poll/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/586420-russia-black-friday-scam-poll/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T05:15:46+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6543968b2030276985189698.jpg" style="margin-right: 10px;" /> Just one in ten Russians believe that vendors provide a fair reduction in the prices of goods during Black Friday sales <br /><a href="https://www.rt.com/business/586420-russia-black-friday-scam-poll/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## North Korea reacts to US missile launch
 - [https://www.rt.com/news/586465-north-korea-reacts-launch/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/586465-north-korea-reacts-launch/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T04:10:09+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/654470a185f5401cad76eddc.jpg" style="margin-right: 10px;" /> North Korea has condemned a recent intercontinental ballistic missile (ICBM) test by the US military <br /><a href="https://www.rt.com/news/586465-north-korea-reacts-launch/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## UAE considers $50-billion investment in India – media
 - [https://www.rt.com/india/586464-uae-india-investments-infrastructure/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/india/586464-uae-india-investments-infrastructure/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T03:02:26+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6544627320302773f137d65d.jpg" style="margin-right: 10px;" /> Abu Dhabi is deepening its engagement with the world’s fastest-growing major economy <br /><a href="https://www.rt.com/india/586464-uae-india-investments-infrastructure/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Disgraced FTX founder convicted for fraud
 - [https://www.rt.com/news/586463-bankman-fried-convicted-fraud/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/586463-bankman-fried-convicted-fraud/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T02:53:20+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/65445e96203027695f2888bf.jpg" style="margin-right: 10px;" /> FTX founder Sam Bankman-Fried has been found guilty on seven counts of fraud linked to his cryptocurrency exchange <br /><a href="https://www.rt.com/news/586463-bankman-fried-convicted-fraud/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## ‘Too few’ German Muslims have condemned Hamas – vice chancellor
 - [https://www.rt.com/news/586461-germany-muslims-hamas-condemn/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/586461-germany-muslims-hamas-condemn/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-11-03T00:56:11+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6544418f2030277b4f51a495.jpg" style="margin-right: 10px;" /> Many Muslims living in Germany have failed to distance themselves from attacks on Israelis, Vice Chancellor Robert Habeck said <br /><a href="https://www.rt.com/news/586461-germany-muslims-hamas-condemn/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

