# Source:Polygon -  All, URL:https://www.polygon.com/rss/index.xml, language:en

## Spider-Man: Across the Spider-Verse on Netflix, A Haunting in Venice, and every new movie to watch this weekend
 - [https://www.polygon.com/2023/11/3/23938342/new-movies-watch-spider-man-across-spider-verse-netflix-jawan-haunting-venice-hulu](https://www.polygon.com/2023/11/3/23938342/new-movies-watch-spider-man-across-spider-verse-netflix-jawan-haunting-venice-hulu)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-11-03T22:15:00+00:00

<figure>
      <img alt="Spider-Man 2099, a version of Spider-Man with a luchador-like mask and long blades on his arms, presses Miles Morales into the side of a building so hard that it leaves a divot in Spider-Man: Across the Spider-Verse" src="https://cdn.vox-cdn.com/thumbor/yDy7aMEPNrMPGr706d3VwuBNdGU=/536x0:3665x1760/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72827014/SV2_chs0870_1033_sb_v4.0.jpg" />
        <figcaption>Image: Sony Pictures</figcaption>
    </figure>

  <p>The blockbuster animated superhero sequel is finally streaming on Netflix</p>
  <p>
    <a href="https://www.polygon.com/2023/11/3/23938342/new-movies-watch-spider-man-across-spider-verse-netflix-jawan-haunting-venice-hulu">Continue reading&hellip;</a>
  </p>

## The new voice of Mario is also the new voice of Wario
 - [https://www.polygon.com/23945633/nitnendo-wario-voice-actor-charles-martinet-kevin-afghani](https://www.polygon.com/23945633/nitnendo-wario-voice-actor-charles-martinet-kevin-afghani)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-11-03T21:52:17+00:00

<figure>
      <img alt="Artwork of Wario posing on the box art for WarioWare: Move It!" src="https://cdn.vox-cdn.com/thumbor/GyJylFAY7pPM7a3dLowL6vVwQ1w=/0x0:1920x1080/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72826932/WarioWareMoveIt.0.jpg" />
        <figcaption>Image: Nintendo</figcaption>
    </figure>

  <p>Just don’t call him Kevin Wafghani</p>
  <p>
    <a href="https://www.polygon.com/23945633/nitnendo-wario-voice-actor-charles-martinet-kevin-afghani">Continue reading&hellip;</a>
  </p>

## How to get Ubasam Wood in Return to Moria
 - [https://www.polygon.com/guides/23945563/return-to-moria-ubasam-wood-how-to-get](https://www.polygon.com/guides/23945563/return-to-moria-ubasam-wood-how-to-get)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-11-03T20:57:37+00:00

<figure>
      <img alt="Two dwarves stare at a cavern in Return to Moria." src="https://cdn.vox-cdn.com/thumbor/fLWkOTHgPGTuQgk9KBEtZ06ClGo=/0x0:1920x1080/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72826745/return_to_moria_usabam_wood_header.0.jpg" />
        <figcaption>Image: Free Range Games/North Beach Games</figcaption>
    </figure>

  <p>Ubsama Wood is the step beyond Elven Wood</p>
  <p>
    <a href="https://www.polygon.com/guides/23945563/return-to-moria-ubasam-wood-how-to-get">Continue reading&hellip;</a>
  </p>

## How to get to the Lower Deeps and Crystal Descent in Return to Moria
 - [https://www.polygon.com/guides/23945556/return-to-moria-lower-deeps-crystal-descent](https://www.polygon.com/guides/23945556/return-to-moria-lower-deeps-crystal-descent)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-11-03T20:57:35+00:00

<figure>
      <img alt="" src="https://cdn.vox-cdn.com/thumbor/sr5KXukp0H2GfMe_3O0xRantIL0=/0x0:1920x1080/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72826743/return_to_moria_lower_deeps_header.0.jpg" />
    </figure>

  <p>You’ll need to repair the Mine Hoist</p>
  <p>
    <a href="https://www.polygon.com/guides/23945556/return-to-moria-lower-deeps-crystal-descent">Continue reading&hellip;</a>
  </p>

## World of Warcraft’s 3-expansion Worldsoul Saga announced at BlizzCon
 - [https://www.polygon.com/23945493/world-of-warcraft-worldsoul-saga-announcement-blizzcon-2023](https://www.polygon.com/23945493/world-of-warcraft-worldsoul-saga-announcement-blizzcon-2023)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-11-03T20:15:05+00:00

<figure>
      <img alt="Xal’atath, a villain from World of Warcraft in the form of a void elf, smirks at the camera. She wears a gold circlet and runes are carved into her face." src="https://cdn.vox-cdn.com/thumbor/dbB8YDUcJlIfIQ974oyeh61i4wM=/0x0:3840x2160/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72826588/WoW_11_BlizzCon_RevealPK_CinematicStills_001.0.jpeg" />
        <figcaption>Image: Blizzard Entertainment</figcaption>
    </figure>

  <p>Get ready for the next six years of World of Warcraft</p>
  <p>
    <a href="https://www.polygon.com/23945493/world-of-warcraft-worldsoul-saga-announcement-blizzcon-2023">Continue reading&hellip;</a>
  </p>

## BlizzCon 2023: All the news from Blizzard’s opening ceremony
 - [https://www.polygon.com/23945048/blizzcon-2023-announcements-news-wow-diablo-4](https://www.polygon.com/23945048/blizzcon-2023-announcements-news-wow-diablo-4)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-11-03T20:04:54+00:00

<figure>
      <img alt="The logo for BlizzCon" src="https://cdn.vox-cdn.com/thumbor/wQfd8bcvAbTbDILBVCgPmJuIg6g=/0x0:1920x1080/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72826558/blizzcon_logo.0.jpg" />
        <figcaption>Image: Blizzard Entertainment</figcaption>
    </figure>

  <p>What’s next for World of Warcraft, Diablo, Overwatch, and more</p>
  <p>
    <a href="https://www.polygon.com/23945048/blizzcon-2023-announcements-news-wow-diablo-4">Continue reading&hellip;</a>
  </p>

## World of Warcraft’s controversial Cataclysm expansion is coming to Classic
 - [https://www.polygon.com/2023/11/3/23945447/wow-classic-cataclysm-season-of-discovery-blizzcon-2023](https://www.polygon.com/2023/11/3/23945447/wow-classic-cataclysm-season-of-discovery-blizzcon-2023)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-11-03T19:44:51+00:00

<figure>
      <img alt="World of Warcraft Classic key art for the Cataclysm expansion, showing the Dragon Aspect Deathwing bringing an apocalypse of flame to the world of Azeroth" src="https://cdn.vox-cdn.com/thumbor/3eseGGqxUwBZ_gfY5i9NOyTKdRY=/0x0:1920x1080/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72826418/Untitled_design___2023_11_03T153217.088.0.png" />
        <figcaption>Image: Blizzard Entertainment</figcaption>
    </figure>

  <p>There are big changes to come</p>
  <p>
    <a href="https://www.polygon.com/2023/11/3/23945447/wow-classic-cataclysm-season-of-discovery-blizzcon-2023">Continue reading&hellip;</a>
  </p>

## Diablo 4’s first expansion is coming next year, and bringing a brand new class with it
 - [https://www.polygon.com/23944179/diablo-4-expansion-vessel-hatred-reveal-trailer-class-blizzcon-2023](https://www.polygon.com/23944179/diablo-4-expansion-vessel-hatred-reveal-trailer-class-blizzcon-2023)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-11-03T19:14:03+00:00

<figure>
      <img alt="A look at a new jungle area in Diablo 4’s first expansion, Vessel of Hatred" src="https://cdn.vox-cdn.com/thumbor/IZtgAtyKQWxkBMpFYABFcvIBUUk=/418x165:1728x902/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72826187/Diablo_IV___Vessel_of_Hatred___Expansion_Announce_Trailer_0_21_screenshot.0.png" />
        <figcaption>Image: Blizzard Entertainment via YouTube</figcaption>
    </figure>

  <p>The first of Diablo 4’s annual expansions is coming in 2024</p>
  <p>
    <a href="https://www.polygon.com/23944179/diablo-4-expansion-vessel-hatred-reveal-trailer-class-blizzcon-2023">Continue reading&hellip;</a>
  </p>

## Loki season 2 is hinting at the biggest Loki story of the last decade, as best it can
 - [https://www.polygon.com/23944904/loki-season-2-god-of-stories-time-travel](https://www.polygon.com/23944904/loki-season-2-god-of-stories-time-travel)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-11-03T19:01:58+00:00

<figure>
      <img alt="Loki (Tom Hiddleston) sitting and looking concerned with other members of the TVA looking at him behind him" src="https://cdn.vox-cdn.com/thumbor/F65VdjlEkH7Nd5vbUASherkP00k=/0x0:8256x4644/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72826123/ARC_205_18116_R.0.jpg" />
        <figcaption>Photo: Gareth Gatrell/Marvel Studios</figcaption>
    </figure>

  <p>What happens to the God of Lies when he stops lying? </p>
  <p>
    <a href="https://www.polygon.com/23944904/loki-season-2-god-of-stories-time-travel">Continue reading&hellip;</a>
  </p>

## Watch Jawan, 2023’s biggest Indian movie, now on Netflix
 - [https://www.polygon.com/23945067/watch-jawan-netflix-best-new-movie-thriller-bollywood-shah-rukh-khan-srk](https://www.polygon.com/23945067/watch-jawan-netflix-best-new-movie-thriller-bollywood-shah-rukh-khan-srk)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-11-03T18:15:00+00:00

<figure>
      <img alt="Shah Rukh Khan dances in a club with backup dancers in Jawan" src="https://cdn.vox-cdn.com/thumbor/mZ-aMx7C4z8He56mJbs8UeZ8ecw=/0x0:1600x900/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72826082/1600_x_900_NRV.0.jpg" />
        <figcaption>Image: Red Chillies Entertainment</figcaption>
    </figure>

  <p>The Shah Rukh Khan action thriller is one of the best new movies of the year</p>
  <p>
    <a href="https://www.polygon.com/23945067/watch-jawan-netflix-best-new-movie-thriller-bollywood-shah-rukh-khan-srk">Continue reading&hellip;</a>
  </p>

## Invincible season 2 uses its multiverse to teach us more about the characters we already know
 - [https://www.polygon.com/23943955/invincible-season-2-multiverse-episode-1-spoilers](https://www.polygon.com/23943955/invincible-season-2-multiverse-episode-1-spoilers)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-11-03T18:00:00+00:00

<figure>
      <img alt="Mark Grayson/Invincible flies through a hole in the wall in Invincible." src="https://cdn.vox-cdn.com/thumbor/ErQIBH94PxGI-bw0zraQBrPOEuw=/0x0:2000x1125/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72825966/invincible.0.jpeg" />
        <figcaption>Image: Prime Video</figcaption>
    </figure>

  <p>We don’t need infinite Marks if we just get to know our Mark a little better</p>
  <p>
    <a href="https://www.polygon.com/23943955/invincible-season-2-multiverse-episode-1-spoilers">Continue reading&hellip;</a>
  </p>

## Vampire Survivors is getting a big new story mode, sort of
 - [https://www.polygon.com/23945262/vampire-survivors-adventures-patch-update-1-8](https://www.polygon.com/23945262/vampire-survivors-adventures-patch-update-1-8)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-11-03T17:55:13+00:00

<figure>
      <img alt="Artwork for Vampire Survivors of a vampire lord standing under a blood-red moon behind a castle" src="https://cdn.vox-cdn.com/thumbor/wYjtGmhwidq0z1lgmGwMhTu2VGk=/0x0:1920x1080/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72825943/ea4ab26516f545b25c3c13ae8e6205545e592277.0.jpg" />
        <figcaption>Image: poncle</figcaption>
    </figure>

  <p>Adventures reset progress without restarting your main game</p>
  <p>
    <a href="https://www.polygon.com/23945262/vampire-survivors-adventures-patch-update-1-8">Continue reading&hellip;</a>
  </p>

## Unravel a real-life conspiracy in this interactive crime thriller
 - [https://www.polygon.com/gaming/23943598/a-hand-with-many-fingers-game-like-alan-wake-2-mind-place-case-board-mystery](https://www.polygon.com/gaming/23943598/a-hand-with-many-fingers-game-like-alan-wake-2-mind-place-case-board-mystery)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-11-03T17:00:00+00:00

<figure>
      <img alt="A close-up shot of a pinboard decorated with newspaper clippings and head shots connected with red string in A Hand With Many Fingers." src="https://cdn.vox-cdn.com/thumbor/muQdZsQzIJX6CvBpn1T6TS16pBw=/261x0:1644x778/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72825668/a_hand_with_many_fingers_02.0.jpg" />
        <figcaption>Image: Colestia</figcaption>
    </figure>

  <p>A Hand with Many Fingers is the game to play if you love Alan Wake 2’s case board</p>
  <p>
    <a href="https://www.polygon.com/gaming/23943598/a-hand-with-many-fingers-game-like-alan-wake-2-mind-place-case-board-mystery">Continue reading&hellip;</a>
  </p>

## Echo might be the most R-rated thing the MCU’s done yet
 - [https://www.polygon.com/23945165/marvel-echo-trailer-release-date-disney-plus-kingpin-daredevil](https://www.polygon.com/23945165/marvel-echo-trailer-release-date-disney-plus-kingpin-daredevil)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-11-03T16:59:42+00:00

<figure>
      <img alt="Wilson Fisk, the Kingpin, raises an open bloodied hand toward a young Maya Lopez, aka Echo, in a still from the first trailer for Marvel Studios’ Echo TV series." src="https://cdn.vox-cdn.com/thumbor/Y7-wdz0Dujrr718Ytp_zBMKF63E=/0x0:1920x1080/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72825659/Marvel_Studios__Echo___Official_Trailer___Disney__and_Hulu_0_37_screenshot.0.jpg" />
        <figcaption>Image: Marvel Studios</figcaption>
    </figure>

  <p>Kingpin, Daredevil, and Echo return to the MCU in 2024</p>
  <p>
    <a href="https://www.polygon.com/23945165/marvel-echo-trailer-release-date-disney-plus-kingpin-daredevil">Continue reading&hellip;</a>
  </p>

## Gen V’s puppet massacre was ‘a puppeteer’s dream’
 - [https://www.polygon.com/23935009/gen-v-puppet-massacre-so-cute-so-violent](https://www.polygon.com/23935009/gen-v-puppet-massacre-so-cute-so-violent)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-11-03T16:30:00+00:00

<figure>
      <img alt="A behind the scenes close-up of a puppet with a shocked expression on his orange face from the Prime Video series Gen V" src="https://cdn.vox-cdn.com/thumbor/3lA9SrZjJzpwUWIA6Rc8FQvBal0=/0x256:3024x1957/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72825533/Photo_2022_07_15__4_31_51_PM_2_.0.jpg" />
        <figcaption>Photo: Colin Penman/Prime Video</figcaption>
    </figure>


  		<p>This is how you stage a puppet massacre</p>
  <p>
    <a href="https://www.polygon.com/23935009/gen-v-puppet-massacre-so-cute-so-violent">Continue reading&hellip;</a>
  </p>

## Baldur’s Gate 3’s latest patch is bad news for sex speedrunners
 - [https://www.polygon.com/23944976/baldurs-gate-3-patch-4-sex-nerf](https://www.polygon.com/23944976/baldurs-gate-3-patch-4-sex-nerf)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-11-03T16:16:13+00:00

<figure>
      <img alt="Lae’zel from Baldur’s Gate 3" src="https://cdn.vox-cdn.com/thumbor/2EjbNWnzTu53HH6Fe_VTsMCd5RY=/0x0:1920x1080/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72825475/Screenshot_2020_10_16_14.34.09.0.png" />
        <figcaption>Image: Larian Studios via Polygon</figcaption>
    </figure>

  <p>Lae’zel no longer drops pants in under two minutes</p>
  <p>
    <a href="https://www.polygon.com/23944976/baldurs-gate-3-patch-4-sex-nerf">Continue reading&hellip;</a>
  </p>

## Thirsty Suitors has one of the best dog petting sequences in a game I’ve ever seen
 - [https://www.polygon.com/gaming/23944931/thirsty-suitors-best-dog-petting-sequences-ever](https://www.polygon.com/gaming/23944931/thirsty-suitors-best-dog-petting-sequences-ever)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-11-03T16:10:00+00:00

<figure>
      <img alt="An image of a small dog in a restaurant. It’s giving a character a high-five with its paw as it sits on a skateboard." src="https://cdn.vox-cdn.com/thumbor/lU5VHjIWO63L7VxGM-2IsW9fB7U=/0x0:1920x1080/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72825433/vlcsnap_2023_11_03_09h22m04s603.0.png" />
        <figcaption>Image: Outerloop Games/Annapurna Interactive</figcaption>
    </figure>

  <p>You can pet the dog, high five the dog, and more</p>
  <p>
    <a href="https://www.polygon.com/gaming/23944931/thirsty-suitors-best-dog-petting-sequences-ever">Continue reading&hellip;</a>
  </p>

## Netflix’s best new show is a deeply personal revenge story
 - [https://www.polygon.com/23943781/blue-eye-samurai-netflix-review](https://www.polygon.com/23943781/blue-eye-samurai-netflix-review)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-11-03T16:00:00+00:00

<figure>
      <img alt="A close up of Mizu holding a sword up to her face" src="https://cdn.vox-cdn.com/thumbor/YNZNyZjg_w70gqdwWmSa5fldACQ=/0x0:3840x2160/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72825369/BLUE_EYE_SAMURAI_u_S1_E2_00_37_26_13.0.jpg" />
        <figcaption>Image: Netflix</figcaption>
    </figure>


  		<p>The show brings new life and dazzling animation to the revenge thriller</p>
  <p>
    <a href="https://www.polygon.com/23943781/blue-eye-samurai-netflix-review">Continue reading&hellip;</a>
  </p>

## What’s new in Fortnite OG Chapter 4 Season 5: Guns, weapons, vehicles, and map
 - [https://www.polygon.com/fortnite-guide/23944890/chapter-4-season-5-og-new-guns-weapons-vehicles-map](https://www.polygon.com/fortnite-guide/23944890/chapter-4-season-5-og-new-guns-weapons-vehicles-map)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-11-03T15:28:36+00:00

<figure>
      <img alt="Fortnite OG Chapter 4 Season 5 key art" src="https://cdn.vox-cdn.com/thumbor/_XVcqV19FJhsvgx-2kglEu1Uj70=/0x1:2880x1621/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72825251/Fortnite_OG_cover.0.jpg" />
        <figcaption>Image: Epic Games</figcaption>
    </figure>

  <p>All the unvaulted weapons and vehicles, and the returning POIs</p>
  <p>
    <a href="https://www.polygon.com/fortnite-guide/23944890/chapter-4-season-5-og-new-guns-weapons-vehicles-map">Continue reading&hellip;</a>
  </p>

## The new Zelda and ‘hot’ Ganondorf amiibo are available
 - [https://www.polygon.com/deals/23874232/princess-zelda-ganondorf-amiibo-pre-order-buy](https://www.polygon.com/deals/23874232/princess-zelda-ganondorf-amiibo-pre-order-buy)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-11-03T15:24:39+00:00

<figure>
      <img alt="An image of the Ganondorf and Princess Zelda amiibo from The Legend of Zelda: Tears of the Kingdom" src="https://cdn.vox-cdn.com/thumbor/bZDyO5-d0ENdMBbPHYgNMz9CFf8=/0x106:2040x1254/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72648668/amiibozelda.0.jpg" />
        <figcaption>Image: Cameron Faulkner/Polygon | Source images: Nintendo</figcaption>
    </figure>

  <p>Several stores currently have them in stock</p>
  <p>
    <a href="https://www.polygon.com/deals/23874232/princess-zelda-ganondorf-amiibo-pre-order-buy">Continue reading&hellip;</a>
  </p>

## Fortnite OG Chapter 4 Season 5 battle pass skins list, including Lil Split, Renegade Lynx, and Spectra Knight
 - [https://www.polygon.com/fortnite-guide/23944892/chapter-4-season-5-og-battle-pass-skins-list](https://www.polygon.com/fortnite-guide/23944892/chapter-4-season-5-og-battle-pass-skins-list)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-11-03T15:03:21+00:00

<figure>
      <img alt="Spectra Knight, Lil Split, Renegade Lynx, and Omegarok as they appear in Fortnite." src="https://cdn.vox-cdn.com/thumbor/WWnDLFEY1gCJmGZpcvhQu8brlQo=/0x0:1920x1080/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72825154/Fortnite_OG_Battle_Pass.0.png" />
        <figcaption>Image: Epic Games via Polygon</figcaption>
    </figure>

  <p>What skins can you unlock in this season’s battle pass?</p>
  <p>
    <a href="https://www.polygon.com/fortnite-guide/23944892/chapter-4-season-5-og-battle-pass-skins-list">Continue reading&hellip;</a>
  </p>

## Jusant on Game Pass is a great palate cleanser amid Big Game season
 - [https://www.polygon.com/sub-gems/23943624/jusant-game-pass-impressions](https://www.polygon.com/sub-gems/23943624/jusant-game-pass-impressions)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-11-03T15:00:00+00:00

<figure>
      <img alt="Jusant’s young hero, wearing climbing gloves and with sunblock-style face decorations, blows into a wind instrument, with a cute blob creature on their shoulder" src="https://cdn.vox-cdn.com/thumbor/H89zCrqt9q4mAnfHZKjtyC9Gngo=/0x0:3840x2160/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72825105/ss_e67326ddf0d3409ef0cde09d78e67a7b09872bf1.0.jpg" />
        <figcaption>Image: Don’t Nod</figcaption>
    </figure>

  <p>Feeling overwhelmed? Clear your mind with a climb  </p>
  <p>
    <a href="https://www.polygon.com/sub-gems/23943624/jusant-game-pass-impressions">Continue reading&hellip;</a>
  </p>

## We’re giving away 40 tickets to the Godzilla Minus One premiere
 - [https://www.polygon.com/23942281/godzilla-minus-one-premiere-tickets-giveaway](https://www.polygon.com/23942281/godzilla-minus-one-premiere-tickets-giveaway)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-11-03T14:51:36+00:00

<figure>
      <img alt="Godzilla destroys a city in Godzilla Minus One." src="https://cdn.vox-cdn.com/thumbor/MzJXwCsx5xmuldTmwvP-kLd5ySk=/0x17:1597x915/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72825045/GMO3.0.jpg" />
        <figcaption>Image: Toho</figcaption>
    </figure>

  <p>See Japan’s new live-action Godzilla movie before everyone else</p>
  <p>
    <a href="https://www.polygon.com/23942281/godzilla-minus-one-premiere-tickets-giveaway">Continue reading&hellip;</a>
  </p>

## The best movies on Netflix right now
 - [https://www.polygon.com/21266801/best-movies-on-netflix](https://www.polygon.com/21266801/best-movies-on-netflix)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-11-03T14:32:08+00:00

<figure>
      <img alt="Spider-Man (Miles Morales) falling through a series of orange glowing hexagonal portals in Spider-Man: Across the Spider-Verse." src="https://cdn.vox-cdn.com/thumbor/JzYSaCpcX2R5gzpcivk6xG0b1AY=/0x0:2048x1152/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/66828871/Spider_Man_across_the_spider_verse_01.468.jpg" />
        <figcaption>Image: Sony Pictures</figcaption>
    </figure>


  		<p>Skip the algorithm and go straight to the good stuff</p>
  <p>
    <a href="https://www.polygon.com/21266801/best-movies-on-netflix">Continue reading&hellip;</a>
  </p>

## Overwatch 2’s new tank hero leaks ahead of BlizzCon 2023 reveal
 - [https://www.polygon.com/23944115/overwatch-2-new-hero-mauga-tank-blizzcon-2023](https://www.polygon.com/23944115/overwatch-2-new-hero-mauga-tank-blizzcon-2023)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-11-03T14:19:37+00:00

<figure>
      <img alt="Artwork of Mauga and Baptiste from Overwatch 2" src="https://cdn.vox-cdn.com/thumbor/qyzOqPGWh88dPJPs8EKaSlTGxG8=/0x87:1920x1167/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72824944/ow2_mauga.0.jpg" />
        <figcaption>Image: Blizzard Entertainment</figcaption>
    </figure>

  <p>Mauga is coming sooner than you think</p>
  <p>
    <a href="https://www.polygon.com/23944115/overwatch-2-new-hero-mauga-tank-blizzcon-2023">Continue reading&hellip;</a>
  </p>

## The Forgotten City, Chivalry 2, and more star in Humble’s new $16 bundle
 - [https://www.polygon.com/deals/23944829/humble-bundle-forgotten-city-wildermyth-disco-elysium-ign](https://www.polygon.com/deals/23944829/humble-bundle-forgotten-city-wildermyth-disco-elysium-ign)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-11-03T14:15:00+00:00

<figure>
      <img alt="The victims of The Forgotten city’s mysterious Golden Rule" src="https://cdn.vox-cdn.com/thumbor/7Uvcbj1LlAdhvgZqTnrjY3FQKQw=/0x0:1920x1080/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72824926/The_forgotten_city_review_1.0.png" />
        <figcaption>Image: Modern Storyteller</figcaption>
    </figure>

  <p>The bundle focuses on indie games that earned high review scores on IGN, Humble’s sister site</p>
  <p>
    <a href="https://www.polygon.com/deals/23944829/humble-bundle-forgotten-city-wildermyth-disco-elysium-ign">Continue reading&hellip;</a>
  </p>

## Honkai: Star Rail version 1.5 livestream codes
 - [https://www.polygon.com/honkai-star-rail-guides/23943533/version-patch-1-5-livestream-codes-redeem](https://www.polygon.com/honkai-star-rail-guides/23943533/version-patch-1-5-livestream-codes-redeem)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-11-03T14:02:00+00:00

<figure>
      <img alt="Hanya stares over some blue flames in Honkai: Star Rail." src="https://cdn.vox-cdn.com/thumbor/i5tuXnzS20T7ZtlFxwEaIknFnHA=/726x0:3840x1752/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72824899/6.0.png" />
        <figcaption>Image: Hoyoverse</figcaption>
    </figure>

  <p>Get free Stellar Jade by using these three codes</p>
  <p>
    <a href="https://www.polygon.com/honkai-star-rail-guides/23943533/version-patch-1-5-livestream-codes-redeem">Continue reading&hellip;</a>
  </p>

## Genshin Impact version 4.2 livestream codes
 - [https://www.polygon.com/genshin-impact-guides/23943499/patch-version-4-2-livestream-codes-redeem](https://www.polygon.com/genshin-impact-guides/23943499/patch-version-4-2-livestream-codes-redeem)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-11-03T14:01:00+00:00

<figure>
      <img alt="Furina from Genshin Impact poses in her office." src="https://cdn.vox-cdn.com/thumbor/rRh4nzfyfXHfkKqZWVoaE62lxkY=/0x0:3840x2160/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72824893/Furina.0.jpg" />
        <figcaption>Image: Hoyoverse</figcaption>
    </figure>

  <p>Use these codes for easy Primogems</p>
  <p>
    <a href="https://www.polygon.com/genshin-impact-guides/23943499/patch-version-4-2-livestream-codes-redeem">Continue reading&hellip;</a>
  </p>

## Matthew Perry wasn’t afraid to be flawed
 - [https://www.polygon.com/23943932/matthew-perry-friends-death-chandler-obituary](https://www.polygon.com/23943932/matthew-perry-friends-death-chandler-obituary)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-11-03T14:00:00+00:00

<figure>
      <img alt="Chandler (Matthew Perry) dancing while the other friends look on and laugh" src="https://cdn.vox-cdn.com/thumbor/wnOMZWg-W2G8llC5iUxcUFWQxEs=/0x0:3000x1688/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72824869/183117943.0.jpg" />
        <figcaption>Photo: Gary Null/NBCU Photo Bank/NBCUniversal via Getty Images</figcaption>
    </figure>

  <p>His best-known role of Chandler on Friends laid the groundwork for Perry’s unique, awkward blend</p>
  <p>
    <a href="https://www.polygon.com/23943932/matthew-perry-friends-death-chandler-obituary">Continue reading&hellip;</a>
  </p>

## No Man’s Sky just keeps getting better
 - [https://www.polygon.com/gaming/23939222/no-mans-sky-2023-review](https://www.polygon.com/gaming/23939222/no-mans-sky-2023-review)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-11-03T13:00:00+00:00

<figure>
      <img alt="An explorer in No Man’s Sky stands looking out at the views of a sweeping, mountainous planet, with spaceship parts on either side" src="https://cdn.vox-cdn.com/thumbor/4Jh8Pzgw2KjAF3RhD9Gc84vPhBM=/0x0:1920x1080/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72824601/ss_4f501c39d59ca70fe02ced438e43087b0e788074.1920x1080.0.jpg" />
        <figcaption>Image: Hello Games</figcaption>
    </figure>


  		<p>It’s never been easier to get into Hello Games’ masterpiece</p>
  <p>
    <a href="https://www.polygon.com/gaming/23939222/no-mans-sky-2023-review">Continue reading&hellip;</a>
  </p>

