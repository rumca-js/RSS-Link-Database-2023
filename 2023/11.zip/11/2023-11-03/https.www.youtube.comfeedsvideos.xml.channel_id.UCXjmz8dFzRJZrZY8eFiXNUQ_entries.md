# Source:Nerdstalgic, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXjmz8dFzRJZrZY8eFiXNUQ, language:en-US

## How This Sci-Fi Film Almost Killed James Cameron
 - [https://www.youtube.com/watch?v=nBL2pMgAIg4](https://www.youtube.com/watch?v=nBL2pMgAIg4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXjmz8dFzRJZrZY8eFiXNUQ
 - date published: 2023-11-03T17:00:39+00:00

As fans, we love to see an auteur director like James Cameron stop at nothing to achieve their vision.   We want to see movies like Terminator, Titanic, and Aliens realized to their fullest potential.  But even James Cameron can take his vision a step too far and almost end his directing career before it got off the ground.  The Abyss was not only a massive undertaking by James Cameron, it almost cost him his life.  But how exactly did The Abyss almost kill James Cameron?  And how did The Abyss make it to the end of production? 

#jamescameron #theabyss #nerdstalgic 

SOURCE:
https://web.archive.org/web/20180930034021/http://sf-encyclopedia.uk/fe.php?nm=weird_fiction
https://ew.com/article/2016/11/29/ed-harris-movies/
https://variety.com/2023/film/news/james-cameron-the-abyss-4k-1235738502/
https://www.nytimes.com/1989/08/06/movies/film-the-abyss-a-foray-into-deep-waters.html?sec=&amp;spon=&amp;pagewanted=all

