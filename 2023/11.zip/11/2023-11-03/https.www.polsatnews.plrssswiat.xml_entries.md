# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## Austria. Morderstwo 36-latka w Tyrolu. Policja aresztowała Polaka
 - [https://www.polsatnews.pl/wiadomosc/2023-11-03/austria-morderstwo-36-latka-w-tyrolu-policja-aresztowala-polaka](https://www.polsatnews.pl/wiadomosc/2023-11-03/austria-morderstwo-36-latka-w-tyrolu-policja-aresztowala-polaka)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-11-03T20:48:00+00:00

W jednym z mieszkań w Tyrolu znaleziono ciało 36-letniego mężczyzny. Austriacka policja podejrzewa, że mordercą jest 30-letni Polak. Oboje się znali, a ostatnio mieli się ze sobą kłócić. W sprawie wciąż jest jednak wiele niewiadomych.

## Afera dyplomatyczna. Poszło o pocałunek
 - [https://www.polsatnews.pl/wiadomosc/2023-11-03/afera-dyplomatyczna-poszlo-o-pocalunek](https://www.polsatnews.pl/wiadomosc/2023-11-03/afera-dyplomatyczna-poszlo-o-pocalunek)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-11-03T18:08:00+00:00

Fala krytyki spłynęła na szefa chorwackiej dyplomacji, który podczas oficjalnego spotkania próbował pocałować minister spraw zagranicznych Niemiec. Wszystko działo się w obecności kamer.

## Australia: Kobieta oskarżona o otrucie teściów. Nowe informacje
 - [https://www.polsatnews.pl/wiadomosc/2023-11-03/australia-kobieta-oskarzona-o-otrucie-tesciow-miala-probowac-zabic-meza](https://www.polsatnews.pl/wiadomosc/2023-11-03/australia-kobieta-oskarzona-o-otrucie-tesciow-miala-probowac-zabic-meza)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-11-03T17:36:00+00:00

Pojawiają się kolejne informacje z Australii dotyczące sprawy kobiety oskarżonej o otrucie grzybami swoich teściów. 49-letnia Erin Trudi Patterson stawiła się w piątek w sądzie po raz pierwszy od usłyszenia zarzutów. Zdaniem śledczych wcześniej próbowała też czterokrotnie zabić swojego męża.

## Al Pacino w tarapatach. Gwiazdor będzie musiał sięgnąć głębiej do kieszeni
 - [https://www.polsatnews.pl/wiadomosc/2023-11-03/al-pacino-w-tarapatach-gwiazdor-bedzie-musial-siegnac-glebiej-do-kieszeni](https://www.polsatnews.pl/wiadomosc/2023-11-03/al-pacino-w-tarapatach-gwiazdor-bedzie-musial-siegnac-glebiej-do-kieszeni)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-11-03T17:27:00+00:00

Media za oceanem obszernie relacjonują proces sądowy, w jaki uwikłany jest Al Pacino ze swoją partnerką. Mimo że para ma być razem, wymiar sprawiedliwości nakazał legendarnemu aktorowi Ojca Chrzestnego zapłatę sowitych alimentów na rzecz Noory Alfallah.

## Łukaszenka dostał pytanie o Polskę. "Jesteśmy jednym narodem"
 - [https://www.polsatnews.pl/wiadomosc/2023-11-03/lukaszenka-dostal-pytanie-o-polske-jestesmy-jednym-narodem](https://www.polsatnews.pl/wiadomosc/2023-11-03/lukaszenka-dostal-pytanie-o-polske-jestesmy-jednym-narodem)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-11-03T17:07:00+00:00

- Białoruś i jej sąsiedzi - Litwa i Polska - bez wątpienia odbudują swoje więzi w przyszłości - powiedział Alaksandr Łukaszenka podczas spotkania z mieszkańcami Ostrowca w obwodzie grodzieńskim. - Jesteśmy jednym narodem - dodał. Białoruski przywódca skomentował również wyniki wyborów w Polsce.

## MSZ Białorusi informuje o wezwaniu chargé d’affaires Polski. Chodzi o "naruszenie granicy"
 - [https://www.polsatnews.pl/wiadomosc/2023-11-03/msz-bialorusi-informuje-o-wezwaniu-charg-daffaires-polski](https://www.polsatnews.pl/wiadomosc/2023-11-03/msz-bialorusi-informuje-o-wezwaniu-charg-daffaires-polski)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-11-03T16:37:00+00:00

Białoruskie Ministerstwo Spraw Zagranicznych poinformowało o wezwaniu chargé d’affaires Polski. W komunikacie wskazano, że chodzi o kolejny przypadek naruszenia granicy przez statek powietrzny ze strony Polski.

## Polacy utknęli w Strefie Gazy. Jest komunikat MSZ
 - [https://www.polsatnews.pl/wiadomosc/2023-11-03/polacy-utkneli-w-strefie-gazy-jest-komunikat-msz](https://www.polsatnews.pl/wiadomosc/2023-11-03/polacy-utkneli-w-strefie-gazy-jest-komunikat-msz)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-11-03T16:07:00+00:00

W objętej działaniami wojennymi Strefie Gazy wciąż przebywają Polacy. Głos w sprawie zabrało Ministerstwo Spraw Zagranicznych, które poinformowało, że podejmuje wszelkie wysiłki, by umożliwić im opuszczenie Strefy Gazy. Póki co ewakuacja nie jest jednak możliwa.

## Stolica Indii najbardziej zanieczyszczonym miastem na świecie. Lekarze biją na alarm
 - [https://www.polsatnews.pl/wiadomosc/2023-11-03/indie-100-krotnosc-limitu-zanieczyszczen-lekarze-chca-powrotu-do-maseczek](https://www.polsatnews.pl/wiadomosc/2023-11-03/indie-100-krotnosc-limitu-zanieczyszczen-lekarze-chca-powrotu-do-maseczek)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-11-03T16:05:00+00:00

Problemy z oddychaniem, kaszel, przeziębienie, łzawiące i podrażnione oczy to codzienność mieszkańców Delhi. W stolicy Indii rozpoczął się sezon smogu, a zanieczyszczenie powietrza przekroczyło stukrotność limitu zdrowotnego zalecanego przez Światową Organizację Zdrowia(WHO).

## Orkan Ciaran zbiera żniwo. We Włoszech zginęło pięć osób
 - [https://www.polsatnews.pl/wiadomosc/2023-11-03/orkan-ciaran-zbiera-zniwo-we-wloszech-zginely-dwie-osoby](https://www.polsatnews.pl/wiadomosc/2023-11-03/orkan-ciaran-zbiera-zniwo-we-wloszech-zginely-dwie-osoby)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-11-03T15:27:00+00:00

Szalejący nad Europą orkan Ciaran spowodował we Włoszech śmierć pięciu osób. We Francji zginęły dwie osoby. To kolejne ofiary pogodowego kataklizmu - w czwartek po południu bilans ten wynosił co najmniej siedem zmarłych.

## Izrael. Lider Hezbollahu przerwał milczenie po ataku
 - [https://www.polsatnews.pl/wiadomosc/2023-11-03/izrael-lider-hezbollahu-przerwal-milczenie-po-ataku](https://www.polsatnews.pl/wiadomosc/2023-11-03/izrael-lider-hezbollahu-przerwal-milczenie-po-ataku)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-11-03T14:07:00+00:00

Lider Hezbollahu zabrał głos po wybuchu wojny w Izraelu. - To, co dzieje się w Strefie Gazy nie jest podobne do poprzednich wojen. To decydująca bitwa - powiedział Hassan Nasrallah. Bojownik ocenił, że atak Hamasu był odważny i podjęty we właściwym czasie, wskazał także dwa kluczowe cele w toczącej się na Bliskim Wschodzie wojnie. Jego wystąpienie było fetowane na ulicach Bejrutu.

## Białoruś: Kobieta w ukarana grzywną za noszenie biało-czerwonego parasola
 - [https://www.polsatnews.pl/wiadomosc/2023-11-03/bialorus-kobieta-w-ciazy-ukarana-grzywna-za-noszenie-bialo-czerwonego-parasola](https://www.polsatnews.pl/wiadomosc/2023-11-03/bialorus-kobieta-w-ciazy-ukarana-grzywna-za-noszenie-bialo-czerwonego-parasola)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-11-03T13:32:00+00:00

Reżim Łukaszenki stał się czujny nawet na parasole. Mogła się o tym przekonać ciężarna kobieta, która chciała schronić się przed ulewą pod biało-czerwonym parasolem. Barwy te zostały uznane za ekstremistyczne. Parasol nakazano zlikwidować, a kobietę ukarano srogą grzywną.

## Niemcy: Zaskakujące odkrycie sprzed setek lat. Szkielet miał metalową rękę
 - [https://www.polsatnews.pl/wiadomosc/2023-11-03/niemcy-zaskakujace-odkrycie-sprzed-setek-lat-szkielet-mial-metalowa-reke](https://www.polsatnews.pl/wiadomosc/2023-11-03/niemcy-zaskakujace-odkrycie-sprzed-setek-lat-szkielet-mial-metalowa-reke)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-11-03T11:15:00+00:00

Archeolodzy dokonali niesamowitego znaleziska w niemieckim Freising w Bawarii. Znaleźli szkielet mężczyzny zmarłego w średniowieczu, który miał metalową protezę ręki.

## Izrael zamknął pierścień wokół Gazy. "Jesteśmy w szczytowym momencie bitwy"
 - [https://www.polsatnews.pl/wiadomosc/2023-11-03/izrael-okrazyl-gaze-jestesmy-w-szczytowym-momencie-bitwy](https://www.polsatnews.pl/wiadomosc/2023-11-03/izrael-okrazyl-gaze-jestesmy-w-szczytowym-momencie-bitwy)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-11-03T06:31:00+00:00

Siły Obronne Izraela przekazały, że zamknęły pierścień oblężenia wokół miasta Gaza. Oznacza to odcięcie go od południowych rejonów w Strefie Gazy. Izraelski premier Benjamin Netnajahu stwierdził, że armia odniosła imponujące sukcesy i znajduje się w szczytowym momencie bitwy.

