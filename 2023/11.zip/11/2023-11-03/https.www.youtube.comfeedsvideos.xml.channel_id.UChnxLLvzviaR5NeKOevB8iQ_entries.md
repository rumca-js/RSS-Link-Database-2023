# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## Let's Talk About Writing Library Music!
 - [https://www.youtube.com/watch?v=jxXRFAVHh2E](https://www.youtube.com/watch?v=jxXRFAVHh2E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2023-11-03T15:23:32+00:00

Merch drop
https://www.bonfire.com/hands-color/
https://www.bonfire.com/hands-monochrome/
Library music albums
Volume 01: https://fanlink.to/rmr-mfa-v1
Volume 02: https://fanlink.to/rmr-mfa-v2
Volume 03: https://fanlink.to/rmr-mfa-v3
Volume 04: https://fanlink.to/rmr-mfa-v4
 
Support the channel on Patreon: http://bit.ly/rmrpatreon
Take a lesson with me: https://rmr.media/education

Find my music here: 
Bandcamp: http://bit.ly/2Kq617o
Spotify: https://spoti.fi/2N40SoX
YouTube Music: https://bit.ly/3PZQ4ol
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

Connect:
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia

00:00 intro
01:34 merch drop
02:46 what is the youtube music library?
04:31 volume 1 walkthrough
14:24 volume 2 walkthrough
23:49 volume 3 walkthrough
34:26 volume 4 walkthrough
42:12 outro

