# Source:Vlog Casha, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLsnJt_eyqkGZ4ZEM__xCOg, language:pl-PL

## Ruszamy w podróż kampervanem po Australii! - Australia #2
 - [https://www.youtube.com/watch?v=N6s4nZ5xnpI](https://www.youtube.com/watch?v=N6s4nZ5xnpI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLsnJt_eyqkGZ4ZEM__xCOg
 - date published: 2023-11-03T15:00:30+00:00

🗺️ Australia #2. Wyjeżdżając z Australii 5 lat temu obiecałem sobie, że jeszcze kiedyś tu wrócę, ale tym razem na własnych zasadach. Nadszedł najwyższy czas, aby ten plan zrealizować :)

❗ Zostań Patronem kanału!
https://patronite.pl/vlogcasha

Kanał Nejta: @swiatwedlugnejtana 

Vlogi z Australii (2018 r.): https://bit.ly/2OJWYOy

5% zniżki na wynajem KUGA CAMPERVAN od Travellers Autobarn na kod "vlogcasha"!

USA: https://www.travellers-autobarnrv.com/
AUSTRALIA: https://www.travellers-autobarn.com.au/

5% discount for Kuga Campervan rental from Travellers Autobarn, discount code "vlogcasha"

Playlisty filmów z moich podróży:
Kambodża (2022): http://bit.ly/3mVA9xv
Indie (2022): http://bit.ly/3viDgAg
USA (2022): https://bit.ly/3uGVdbd
Kuba (2021): https://bit.ly/3dhLIqK
USA (2021): https://bit.ly/35J0zKd
Meksyk (2021): http://bit.ly/3c7Jycf
Turcja (2019-2020): https://bit.ly/31VPCR3
Kolumbia (2020): https://bit.ly/36tqlhH
Tajlandia, Laos, Wietnam (2019): https://bit.ly/2wrM9t2
Austral

