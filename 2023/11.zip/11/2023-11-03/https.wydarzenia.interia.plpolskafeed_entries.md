# Source:Wydarzenia Interia - Polska, URL:https://wydarzenia.interia.pl/polska/feed, language:pl-PL

## Katarzyna Puzyńska: Często moje lęki przemycam w książkach
 - [https://wydarzenia.interia.pl/autor/piotr-witwicki/news-katarzyna-puzynska-czesto-moje-leki-przemycam-w-ksiazkach,nId,7124601](https://wydarzenia.interia.pl/autor/piotr-witwicki/news-katarzyna-puzynska-czesto-moje-leki-przemycam-w-ksiazkach,nId,7124601)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-11-03T09:00:33+00:00

<p><a href="https://wydarzenia.interia.pl/autor/piotr-witwicki/news-katarzyna-puzynska-czesto-moje-leki-przemycam-w-ksiazkach,nId,7124601"><img align="left" alt="Katarzyna Puzyńska: Często moje lęki przemycam w książkach" src="https://i.iplsc.com/katarzyna-puzynska-czesto-moje-leki-przemycam-w-ksiazkach/000HXD0WFI8MIP26-C321.jpg" /></a>- We wszystkich moich książkach największym lękiem jest to, co człowiek człowiekowi może zrobić - mówi w videocaście z Piotra Witwickiego Katarzyna Puzyńska, autorka serii kryminałów o fikcyjnej wsi Lipowo. Pisarka opowiedziała również o polskiej tradycji picia i stereotypach dotyczących weganizmu.</p><br clear="all" />

