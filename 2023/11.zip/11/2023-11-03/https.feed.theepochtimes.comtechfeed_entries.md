# Source:Epoch Times - Tech, URL:https://feed.theepochtimes.com/tech/feed, language:en-US

## Australia and UK Set to ‘Shape the Next Frontier’ on Quantum Technologies
 - [https://www.theepochtimes.com/world/australia-and-uk-set-to-shape-the-next-frontier-on-quantum-technologies-5522277](https://www.theepochtimes.com/world/australia-and-uk-set-to-shape-the-next-frontier-on-quantum-technologies-5522277)
 - RSS feed: https://feed.theepochtimes.com/tech/feed
 - date published: 2023-11-03T04:48:08+00:00

Illustration of quantum particles. (Sola Solandra/Shutterstock)

