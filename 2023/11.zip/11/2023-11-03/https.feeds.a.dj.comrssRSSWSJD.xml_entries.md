# Source:The Wall Street - Tech, URL:https://feeds.a.dj.com/rss/RSSWSJD.xml, language:en-US

## His Job Was to Make Instagram Safe for Teens. His 14-Year-Old Showed Him What the App Was Really Like.
 - [https://www.wsj.com/articles/instagram-facebook-teens-harassment-safety-5d991be1?mod=rss_Technology](https://www.wsj.com/articles/instagram-facebook-teens-harassment-safety-5d991be1?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-11-03T01:00:00+00:00

When a Meta security expert told Mark Zuckerberg that Instagram’s approach to protecting teens wasn’t working, the CEO didn’t reply. Now the former insider is set to tell Congress about the predatory behavior.

## The AI Deals Enriching Silicon Valley's Tech Giants
 - [https://www.wsj.com/articles/ai-deals-microsoft-google-amazon-7f624054?mod=rss_Technology](https://www.wsj.com/articles/ai-deals-microsoft-google-amazon-7f624054?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-11-03T01:00:00+00:00

Microsoft, Amazon and Google are getting billions in revenue from providing expensive cloud services to the startups they are backing.

