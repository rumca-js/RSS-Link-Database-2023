# Source:RMF24.pl, URL:https://www.rmf24.pl/feed, language:pl

## Katastrofalne trzęsienie ziemi w Nepalu. Rośnie liczba ofiar
 - [https://www.rmf24.pl/fakty/swiat/news-katastrofalne-trzesienie-ziemi-w-nepalu-rosnie-liczba-ofiar,nId,7127418](https://www.rmf24.pl/fakty/swiat/news-katastrofalne-trzesienie-ziemi-w-nepalu-rosnie-liczba-ofiar,nId,7127418)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T22:47:11+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-katastrofalne-trzesienie-ziemi-w-nepalu-rosnie-liczba-ofiar,nId,7127418"><img align="left" alt="Katastrofalne trzęsienie ziemi w Nepalu. Rośnie liczba ofiar" src="https://interia-s.pluscdn.pl/katastrofalne-trzesienie-ziemi-w-nepalu-rosnie-liczba-ofiar/000HXQB66YCVEEQK-C307.jpg" /></a>Co najmniej 54 osoby zginęły, a dziesiątki innych zostało rannych w trzęsieniu ziemi, które w piątek wieczorem nawiedziło Nepal, poinformowała AP. </p><br clear="all" />

## WTA Finals. Aryna Sabalenka awansowała do półfinału
 - [https://www.rmf24.pl/sport/tenis/news-wta-finals-aryna-sabalenka-awansowala-do-polfinalu,nId,7127413](https://www.rmf24.pl/sport/tenis/news-wta-finals-aryna-sabalenka-awansowala-do-polfinalu,nId,7127413)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T22:27:29+00:00

<p><a href="https://www.rmf24.pl/sport/tenis/news-wta-finals-aryna-sabalenka-awansowala-do-polfinalu,nId,7127413"><img align="left" alt="WTA Finals. Aryna Sabalenka awansowała do półfinału" src="https://interia-s.pluscdn.pl/wta-finals-aryna-sabalenka-awansowala-do-polfinalu/000HXQ8O7Q6KEA78-C307.jpg" /></a>Białorusinka Aryna Sabalenka awansowała do półfinału kończącego sezon turnieju tenisowego WTA Finals w meksykańskim Cancun. Liderka światowego rankingu pokonała Jelenę Rybakinę z Kazachstanu 6:2, 3:6, 6:3.</p><br clear="all" />

## Wielkopolska. Wyrwał policjantowi broń i zaczął strzelać
 - [https://www.rmf24.pl/regiony/poznan/news-wielkopolska-wyrwal-policjantowi-bron-i-zaczal-strzelac,nId,7127410](https://www.rmf24.pl/regiony/poznan/news-wielkopolska-wyrwal-policjantowi-bron-i-zaczal-strzelac,nId,7127410)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T21:53:22+00:00

<p><a href="https://www.rmf24.pl/regiony/poznan/news-wielkopolska-wyrwal-policjantowi-bron-i-zaczal-strzelac,nId,7127410"><img align="left" alt="Wielkopolska. Wyrwał policjantowi broń i zaczął strzelać" src="https://interia-s.pluscdn.pl/wielkopolska-wyrwal-policjantowi-bron-i-zaczal-strzelac/000HXQ7IPXMDVEDN-C307.jpg" /></a>Policja i prokuratura wyjaśniają okoliczności strzelaniny, do której doszło w piątek w miejscowości Władysławów (pow. turecki, woj. wielkopolskie). Podczas policyjnej interwencji napastnik zabrał funkcjonariuszowi broń i oddał kilka strzałów.</p><br clear="all" />

## Kobieta skazana na karę śmierci. Doniósł na nią mąż
 - [https://www.rmf24.pl/fakty/swiat/news-kobieta-skazana-na-kare-smierci-doniosl-na-nia-maz,nId,7127405](https://www.rmf24.pl/fakty/swiat/news-kobieta-skazana-na-kare-smierci-doniosl-na-nia-maz,nId,7127405)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T21:25:23+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-kobieta-skazana-na-kare-smierci-doniosl-na-nia-maz,nId,7127405"><img align="left" alt="Kobieta skazana na karę śmierci. Doniósł na nią mąż" src="https://interia-s.pluscdn.pl/kobieta-skazana-na-kare-smierci-doniosl-na-nia-maz/000HXQ45Q1YQU0HF-C307.jpg" /></a>Irański sąd skazał kobietę na śmierć za cudzołóstwo - podały tamtejsze media. Kobietę oskarżył jej mąż, który sprawdził nagrania z monitoringu. </p><br clear="all" />

## Bloomberg: Polska wśród pięciu kluczowych krajów świata
 - [https://www.rmf24.pl/ekonomia/news-bloomberg-polska-wsrod-pieciu-kluczowych-krajow-swiata,nId,7127359](https://www.rmf24.pl/ekonomia/news-bloomberg-polska-wsrod-pieciu-kluczowych-krajow-swiata,nId,7127359)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T20:35:00+00:00

<p><a href="https://www.rmf24.pl/ekonomia/news-bloomberg-polska-wsrod-pieciu-kluczowych-krajow-swiata,nId,7127359"><img align="left" alt="Bloomberg: Polska wśród pięciu kluczowych krajów świata" src="https://interia-s.pluscdn.pl/bloomberg-polska-wsrod-pieciu-kluczowych-krajow-swiata/000HXPVIDYPPH9S8-C307.jpg" /></a>Polska, Maroko, Meksyk, Indonezja i Wietnam to pięć kluczowych krajów, które czerpią największe korzyści z przetasowań w globalnych łańcuchach dostaw, do których dochodzi w związku z napięciami na linii USA-Chiny - podkreśla w obszernym raporcie Bloomberg.</p><br clear="all" />

## Gen. Budanow cudem uniknął śmierci. Uratował go pojazd opancerzony
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-gen-budanow-cudem-uniknal-smierci-uratowal-go-pojazd-opancer,nId,7127369](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-gen-budanow-cudem-uniknal-smierci-uratowal-go-pojazd-opancer,nId,7127369)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T20:29:00+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-gen-budanow-cudem-uniknal-smierci-uratowal-go-pojazd-opancer,nId,7127369"><img align="left" alt="Gen. Budanow cudem uniknął śmierci. Uratował go pojazd opancerzony" src="https://interia-s.pluscdn.pl/gen-budanow-cudem-uniknal-smierci-uratowal-go-pojazd-opancer/000HXPVOFMVK50M5-C307.jpg" /></a>Podczas walk o Siewierodonieck w obwodzie ługańskim szef ukraińskiego wywiadu wojskowego gen. Kyryło Budanow znalazł się wiosną 2022 roku pod ostrzałem sił rosyjskich. Od śmierci uchronił go stojący w pobliżu pojazd opancerzony.</p><br clear="all" />

## Chiński myśliwiec kontra kanadyjski śmigłowiec. O krok od tragedii
 - [https://www.rmf24.pl/fakty/swiat/news-chinski-mysliwiec-kontra-kanadyjski-smiglowiec-o-krok-od-tra,nId,7127348](https://www.rmf24.pl/fakty/swiat/news-chinski-mysliwiec-kontra-kanadyjski-smiglowiec-o-krok-od-tra,nId,7127348)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T19:18:00+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-chinski-mysliwiec-kontra-kanadyjski-smiglowiec-o-krok-od-tra,nId,7127348"><img align="left" alt="Chiński myśliwiec kontra kanadyjski śmigłowiec. O krok od tragedii" src="https://interia-s.pluscdn.pl/chinski-mysliwiec-kontra-kanadyjski-smiglowiec-o-krok-od-tra/000HXPNWIRA3LS5E-C307.jpg" /></a>Nad Morzem Południowochińskim, z dala od wszelkich obszarów, do których zgłaszane są jakiekolwiek roszczenia, pilot chińskiego myśliwca wykonał niebezpieczny manewr - odpalił flary bezpośrednio przed kanadyjskim śmigłowcem. Tylko dzięki wysokim umiejętnościom i przytomnemu umysłowi pilota nie doszło do tragedii.</p><br clear="all" />

## Tragedia u wybrzeży Portugalii: Zatonął jacht, 4 osoby nie żyją
 - [https://www.rmf24.pl/fakty/swiat/news-tragedia-u-wybrzezy-portugalii-zatonal-jacht-4-osoby-nie-zyj,nId,7127347](https://www.rmf24.pl/fakty/swiat/news-tragedia-u-wybrzezy-portugalii-zatonal-jacht-4-osoby-nie-zyj,nId,7127347)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T18:53:07+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-tragedia-u-wybrzezy-portugalii-zatonal-jacht-4-osoby-nie-zyj,nId,7127347"><img align="left" alt="Tragedia u wybrzeży Portugalii: Zatonął jacht, 4 osoby nie żyją" src="https://interia-s.pluscdn.pl/tragedia-u-wybrzezy-portugalii-zatonal-jacht-4-osoby-nie-zyj/000HXPI5PKQ0SYJT-C307.jpg" /></a>Cztery osoby zginęły w wyniku zatonięcia jachtu u wybrzeży Portugalii. To dwóch mężczyzn i dwie kobiety. Mimo ostrzeżeń przed złymi warunkami na morzu, wypłynęli rano z portu w Peniche.</p><br clear="all" />

## Politolog o nowej koalicji: Będziemy obserwować konflikty
 - [https://www.rmf24.pl/raporty/raport-wybory-parlamentarne-2023/news-politolog-o-nowej-koalicji-bedziemy-obserwowac-konflikty,nId,7127331](https://www.rmf24.pl/raporty/raport-wybory-parlamentarne-2023/news-politolog-o-nowej-koalicji-bedziemy-obserwowac-konflikty,nId,7127331)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T17:47:36+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wybory-parlamentarne-2023/news-politolog-o-nowej-koalicji-bedziemy-obserwowac-konflikty,nId,7127331"><img align="left" alt="Politolog o nowej koalicji: Będziemy obserwować konflikty" src="https://interia-s.pluscdn.pl/politolog-o-nowej-koalicji-bedziemy-obserwowac-konflikty/000HXP8Y3DM04NUE-C307.jpg" /></a>Koalicja KO, Trzeciej Drogi oraz Lewicy rozważa wprowadzenie rotacyjnego marszałka Sejmu. Stanowisko miałby piastować Szymon Hołownia i Włodzimierz Czarzasty, zmieniliby się po dwóch lata, w połowie kadencji. „Uważam, że system rotacyjny jest bardzo dobry dla demokracji” - mówi dr hab. Anna Siwierska-Chmaj, politolog z Uniwersytety Rzeszowskiego, na antenie internetowego Radia RMF24.</p><br clear="all" />

## Afera korupcyjna w gdańskim urzędzie. Jest wyrok sądu
 - [https://www.rmf24.pl/regiony/trojmiasto/news-afera-korupcyjna-w-gdanskim-urzedzie-jest-wyrok-sadu,nId,7127329](https://www.rmf24.pl/regiony/trojmiasto/news-afera-korupcyjna-w-gdanskim-urzedzie-jest-wyrok-sadu,nId,7127329)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T17:42:18+00:00

<p><a href="https://www.rmf24.pl/regiony/trojmiasto/news-afera-korupcyjna-w-gdanskim-urzedzie-jest-wyrok-sadu,nId,7127329"><img align="left" alt="Afera korupcyjna w gdańskim urzędzie. Jest wyrok sądu" src="https://interia-s.pluscdn.pl/afera-korupcyjna-w-gdanskim-urzedzie-jest-wyrok-sadu/000HXPGPTV0COF4A-C307.jpg" /></a>8 lat i 5,5 roku bezwzględnego więzienia - takie wyroki usłyszały dwie byłe urzędniczki z Gdańska w sprawie dotyczącej załatwiania mieszkań komunalnych za łapówki. Wyrok jest nieprawomocny.</p><br clear="all" />

## Huragan Ciaran zbiera śmiertelne żniwo w Europie
 - [https://www.rmf24.pl/pogoda/news-huragan-ciaran-zbiera-smiertelne-zniwo-w-europie,nId,7127170](https://www.rmf24.pl/pogoda/news-huragan-ciaran-zbiera-smiertelne-zniwo-w-europie,nId,7127170)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T17:02:00+00:00

<p><a href="https://www.rmf24.pl/pogoda/news-huragan-ciaran-zbiera-smiertelne-zniwo-w-europie,nId,7127170"><img align="left" alt="Huragan Ciaran zbiera śmiertelne żniwo w Europie" src="https://interia-s.pluscdn.pl/huragan-ciaran-zbiera-smiertelne-zniwo-w-europie/000HXOVIQPDPJI0H-C307.jpg" /></a>Huragan Ciaran, który od czwartku szaleje nad Europą, zabił co najmniej 12 osób, w tym 5-letnie dziecko w Belgii. Wichura powala drzewa, woda podmywa drogi. Największe spustoszenie orkan zostawił po sobie w Toskanii we Włoszech.</p><br clear="all" />

## Olko: Prezydent nas jeszcze zaskoczy albo będą protesty
 - [https://www.rmf24.pl/tylko-w-rmf24/popoludniowa-rozmowa/news-olko-prezydent-nas-jeszcze-zaskoczy-albo-beda-protesty,nId,7127010](https://www.rmf24.pl/tylko-w-rmf24/popoludniowa-rozmowa/news-olko-prezydent-nas-jeszcze-zaskoczy-albo-beda-protesty,nId,7127010)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T17:02:00+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/popoludniowa-rozmowa/news-olko-prezydent-nas-jeszcze-zaskoczy-albo-beda-protesty,nId,7127010"><img align="left" alt="Olko: Prezydent nas jeszcze zaskoczy albo będą protesty" src="https://interia-s.pluscdn.pl/olko-prezydent-nas-jeszcze-zaskoczy-albo-beda-protesty/000HXPFDEESQDLY2-C307.jpg" /></a>&quot;Niedawna opozycja, a obecna większość sejmowa, nie może się kierować tym, czy prezydent coś podpisze, czy nie&quot; – stwierdziła posłanka elekt Lewicy Dorota Olko, pytana w Popołudniowej rozmowie w RMF FM o możliwość przeforsowania zmian przepisów dotyczących aborcji. &quot;Prezydent (…) zaskoczy nas jeszcze nie raz bardziej pozytywnie (…). Jeżeli tak nie będzie, to musiałby się spodziewać kobiecych protestów&quot; – oznajmiła.</p><br clear="all" />

## Dorota Olko gościem Popołudniowej rozmowy w RMF FM
 - [https://www.rmf24.pl/tylko-w-rmf24/popoludniowa-rozmowa/news-dorota-olko-gosciem-popoludniowej-rozmowy-w-rmf-fm,nId,7127010](https://www.rmf24.pl/tylko-w-rmf24/popoludniowa-rozmowa/news-dorota-olko-gosciem-popoludniowej-rozmowy-w-rmf-fm,nId,7127010)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T16:45:00+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/popoludniowa-rozmowa/news-dorota-olko-gosciem-popoludniowej-rozmowy-w-rmf-fm,nId,7127010"><img align="left" alt="Dorota Olko gościem Popołudniowej rozmowy w RMF FM" src="https://interia-s.pluscdn.pl/dorota-olko-gosciem-popoludniowej-rozmowy-w-rmf-fm/000HXM5JJJ1KS8UK-C307.jpg" /></a>Gościem Popołudniowej rozmowy w RMF FM będzie rzeczniczka partii Razem i posłanka elekt Lewicy, Dorota Olko. Porozmawiamy z nią m.in. o rozmowach na temat umowy koalicyjnej.</p><br clear="all" />

## Polski dyplomata wezwany na dywanik do białoruskiego MSZ
 - [https://www.rmf24.pl/fakty/swiat/news-polski-dyplomata-wezwany-na-dywanik-do-bialoruskiego-msz,nId,7127163](https://www.rmf24.pl/fakty/swiat/news-polski-dyplomata-wezwany-na-dywanik-do-bialoruskiego-msz,nId,7127163)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T16:36:57+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-polski-dyplomata-wezwany-na-dywanik-do-bialoruskiego-msz,nId,7127163"><img align="left" alt="Polski dyplomata wezwany na dywanik do białoruskiego MSZ" src="https://interia-s.pluscdn.pl/polski-dyplomata-wezwany-na-dywanik-do-bialoruskiego-msz/000HXOV6DIGQETUV-C307.jpg" /></a>Ministerstwo Spraw Zagranicznych Republiki Białorusi wezwało polskiego chargé d'affaires Marcina Wojciechowskiego. Władze w Mińsku twierdzą, że &quot;polski statek powietrzny&quot; znów naruszył białoruską granicę.</p><br clear="all" />

## Atak maczetą w Warszawie. Napastnik schwytany po policyjnej obławie
 - [https://www.rmf24.pl/regiony/warszawa/news-atak-maczeta-w-warszawie-napastnik-schwytany-po-policyjnej-o,nId,7127131](https://www.rmf24.pl/regiony/warszawa/news-atak-maczeta-w-warszawie-napastnik-schwytany-po-policyjnej-o,nId,7127131)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T15:55:02+00:00

<p><a href="https://www.rmf24.pl/regiony/warszawa/news-atak-maczeta-w-warszawie-napastnik-schwytany-po-policyjnej-o,nId,7127131"><img align="left" alt="Atak maczetą w Warszawie. Napastnik schwytany po policyjnej obławie " src="https://interia-s.pluscdn.pl/atak-maczeta-w-warszawie-napastnik-schwytany-po-policyjnej-o/000HXOON0F5HYHGU-C307.jpg" /></a>Warszawska policja poinformowała o zatrzymaniu napastnika, który był poszukiwany za dokonanie w piątek co najmniej trzech napaści. Mężczyzna posługiwał się maczetą.</p><br clear="all" />

## Brutalne zabójstwo w Tyrolu. Zatrzymano 30-letniego Polaka
 - [https://www.rmf24.pl/fakty/swiat/news-brutalne-zabojstwo-w-tyrolu-zatrzymano-30-letniego-polaka,nId,7127088](https://www.rmf24.pl/fakty/swiat/news-brutalne-zabojstwo-w-tyrolu-zatrzymano-30-letniego-polaka,nId,7127088)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T15:12:00+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-brutalne-zabojstwo-w-tyrolu-zatrzymano-30-letniego-polaka,nId,7127088"><img align="left" alt="Brutalne zabójstwo w Tyrolu. Zatrzymano 30-letniego Polaka" src="https://interia-s.pluscdn.pl/brutalne-zabojstwo-w-tyrolu-zatrzymano-30-letniego-polaka/000HXNT5C9BRXD5I-C307.jpg" /></a>Austriacka policja zatrzymała 30-letniego Polaka, podejrzanego o dokonanie brutalnego zabójstwa w Tyrolu. We wtorek wieczorem w mieszkaniu w miejscowości Itter zostało znalezione ciało 36-letniego mężczyzny. </p><br clear="all" />

## Hubert Hurkacz odpadł w ćwierćfinale turnieju ATP w Paryżu
 - [https://www.rmf24.pl/raporty/raport-tenis-na-rmf24/najnowszefakty/news-hubert-hurkacz-odpadl-w-cwiercfinale-turnieju-atp-w-paryzu,nId,7127101](https://www.rmf24.pl/raporty/raport-tenis-na-rmf24/najnowszefakty/news-hubert-hurkacz-odpadl-w-cwiercfinale-turnieju-atp-w-paryzu,nId,7127101)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T15:10:35+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-tenis-na-rmf24/najnowszefakty/news-hubert-hurkacz-odpadl-w-cwiercfinale-turnieju-atp-w-paryzu,nId,7127101"><img align="left" alt="Hubert Hurkacz odpadł w ćwierćfinale turnieju ATP w Paryżu" src="https://interia-s.pluscdn.pl/hubert-hurkacz-odpadl-w-cwiercfinale-turnieju-atp-w-paryzu/000HXOGHQBE0T7IY-C307.jpg" /></a>Hubert Hurkacz za burtą tenisowego turnieju ATP Masters w Paryżu. Polak przegrał w ćwierćfinale w trzech setach z Bułgarem Grigorem Dimitrowem.</p><br clear="all" />

## Świat wstrzymał oddech. Lider Hezbollahu przerwał milczenie
 - [https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-swiat-wstrzymal-oddech-lider-hezbollahu-przerwal-milczenie,nId,7127084](https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-swiat-wstrzymal-oddech-lider-hezbollahu-przerwal-milczenie,nId,7127084)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T15:09:00+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-swiat-wstrzymal-oddech-lider-hezbollahu-przerwal-milczenie,nId,7127084"><img align="left" alt="Świat wstrzymał oddech. Lider Hezbollahu przerwał milczenie" src="https://interia-s.pluscdn.pl/swiat-wstrzymal-oddech-lider-hezbollahu-przerwal-milczenie/000HXOBYGTVWWULD-C307.jpg" /></a>Świat na kilkadziesiąt minut wstrzymał oddech, bowiem lider Hezbollahu Hassan Nasrallah wygłosił pierwsze od ataku Hamasu na Izrael oświadczenie. Komentatorzy spodziewali się wypowiedzenia wojny Izraelowi, ale nic takiego się nie stało. Szef radykalnego szyickiego ugrupowania powiedział jedynie, że &quot;posunięcia militarne na granicy libańskiej wydają się skromne, ale są bardzo istotne&quot;.</p><br clear="all" />

## Polscy żołnierze w Iraku nie doświadczyli bezpośredniego zagrożenia
 - [https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-polscy-zolnierze-w-iraku-dowodztwo-operacyjne-zaden-nie-dosw,nId,7127008](https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-polscy-zolnierze-w-iraku-dowodztwo-operacyjne-zaden-nie-dosw,nId,7127008)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T14:26:00+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-polscy-zolnierze-w-iraku-dowodztwo-operacyjne-zaden-nie-dosw,nId,7127008"><img align="left" alt="TYLKO W RMF FM Polscy żołnierze w Iraku nie doświadczyli bezpośredniego zagrożenia" src="https://interia-s.pluscdn.pl/tylko-w-rmf-fm-polscy-zolnierze-w-iraku-nie-doswiadczyli-bez/000HXM6SH9VNL2JI-C307.jpg" /></a>Nie ma potrzeby wprowadzania dodatkowych procedur bezpieczeństwa w Polskim Kontyngencie Wojskowym w Iraku - zapewnił podpułkownik Jacek Goryszewski z Dowództwa Operacyjnego Rodzajów Sił Zbrojnych. W rozmowie z RMF FM oficer zastrzegł jednak, że od początku obecnego konfliktu palestyńsko-izraelskiego zwiększyła się liczba prób ataków na bazy, w których stacjonują Polacy. Jak dodał Jacek Goryszewski, w amerykańskich bazach, które współdzielimy z sojusznikami, ogłaszano alarmy. Wtedy stosuje się rutynowe procedury i zejścia do schronów. W PKW...</p><br clear="all" />

## USA są bardziej zaangażowane w Strefie Gazy, niż się wydawało
 - [https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-usa-sa-bardziej-zaangazowane-w-strefie-gazy-niz-sie-wydawalo,nId,7127039](https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-usa-sa-bardziej-zaangazowane-w-strefie-gazy-niz-sie-wydawalo,nId,7127039)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T14:20:00+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-usa-sa-bardziej-zaangazowane-w-strefie-gazy-niz-sie-wydawalo,nId,7127039"><img align="left" alt="USA są bardziej zaangażowane w Strefie Gazy, niż się wydawało" src="https://interia-s.pluscdn.pl/usa-sa-bardziej-zaangazowane-w-strefie-gazy-niz-sie-wydawalo/000HXMPFVAS7J6AU-C307.jpg" /></a>Nie ma już wątpliwości, że Stany Zjednoczone są bardziej zaangażowane w Strefie Gazy, niż się do tej pory wydawało. Chodzi bowiem o to, że nad tą palestyńską enklawą latają amerykańskie drony, czego dotychczas nie wiedziano. Misja bezzałogowców jest jednak specyficzna.</p><br clear="all" />

## Jak odzyskać dostęp do Profilu Zaufanego?
 - [https://www.rmf24.pl/news-3-7-mln-polakow-utracilo-dostep-do-profilu-zaufanego-jak-go-,nId,7127036](https://www.rmf24.pl/news-3-7-mln-polakow-utracilo-dostep-do-profilu-zaufanego-jak-go-,nId,7127036)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T13:54:19+00:00

<p><a href="https://www.rmf24.pl/news-3-7-mln-polakow-utracilo-dostep-do-profilu-zaufanego-jak-go-,nId,7127036"><img align="left" alt="Jak odzyskać dostęp do Profilu Zaufanego?" src="https://interia-s.pluscdn.pl/jak-odzyskac-dostep-do-profilu-zaufanego/000HXMRHKLAQRN04-C307.jpg" /></a>31 października wygasło 5,5 mln kont w Profilu Zaufanym. To bezpłatne narzędzie, dzięki któremu bez wychodzenia z domu można załatwiać sprawy urzędowe online w serwisach administracji publicznej. Profil zaufany co do zasady ważny jest 3 lata. W związku z pandemią koronawirusa jego ważność była jednak przedłużana automatycznie. To spowodowało, że wiele osób zapomniało to zrobić. </p><br clear="all" />

## Koreańskie banki mają udzielić Polsce ogromnego kredytu
 - [https://www.rmf24.pl/fakty/swiat/news-zakupy-dla-armii-koreanskie-banki-maja-udzielic-polsce-gigan,nId,7126767](https://www.rmf24.pl/fakty/swiat/news-zakupy-dla-armii-koreanskie-banki-maja-udzielic-polsce-gigan,nId,7126767)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T13:07:02+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-zakupy-dla-armii-koreanskie-banki-maja-udzielic-polsce-gigan,nId,7126767"><img align="left" alt="Koreańskie banki mają udzielić Polsce ogromnego kredytu" src="https://interia-s.pluscdn.pl/koreanskie-banki-maja-udzielic-polsce-ogromnego-kredytu/000HXLS9IEIB4KLC-C307.jpg" /></a>Koreańskie banki planują pożyczyć Polsce ogromne sumy i pomóc zrealizować zamówienia wojskowe za ponad 20 miliardów dolarów. Takie informacje podała agencja Reutera.</p><br clear="all" />

## Wypadł z drogi, uderzył w dom i prawie wjechał do kuchni
 - [https://www.rmf24.pl/regiony/lublin/news-wypadl-z-drogi-na-zakrecie-uderzyl-w-dom-i-prawie-wjechal-do,nId,7126738](https://www.rmf24.pl/regiony/lublin/news-wypadl-z-drogi-na-zakrecie-uderzyl-w-dom-i-prawie-wjechal-do,nId,7126738)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T12:34:51+00:00

<p><a href="https://www.rmf24.pl/regiony/lublin/news-wypadl-z-drogi-na-zakrecie-uderzyl-w-dom-i-prawie-wjechal-do,nId,7126738"><img align="left" alt="Wypadł z drogi, uderzył w dom i prawie wjechał do kuchni" src="https://interia-s.pluscdn.pl/wypadl-z-drogi-uderzyl-w-dom-i-prawie-wjechal-do-kuchni/000HXLEM5A3LOOEV-C307.jpg" /></a>23-letni kierowca hondy wypadł z drogi na zakręcie w Trzebieszowie Pierwszym w woj. lubelskim. Swoją podróż niemal zakończył w kuchni domu, w którego ścianę uderzył. Na szczęście młody mężczyzna odniósł tylko niegroźne obrażenia, a domownicy w ogóle nie ucierpieli.</p><br clear="all" />

## Kosztowne powyborcze decyzje Zbigniewa Ziobry
 - [https://www.rmf24.pl/fakty/polska/news-kosztowne-decyzje-po-wyborach-komu-ziobro-przekazuje-kamieni,nId,7126703](https://www.rmf24.pl/fakty/polska/news-kosztowne-decyzje-po-wyborach-komu-ziobro-przekazuje-kamieni,nId,7126703)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T11:59:48+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-kosztowne-decyzje-po-wyborach-komu-ziobro-przekazuje-kamieni,nId,7126703"><img align="left" alt="Kosztowne powyborcze decyzje Zbigniewa Ziobry" src="https://interia-s.pluscdn.pl/kosztowne-powyborcze-decyzje-zbigniewa-ziobry/000HXL515NS1PKR3-C307.jpg" /></a>Kamienica na warszawskim Mokotowie oraz atrakcyjna działka na Podlasiu przekazane przez Zbigniewa Ziobrę na własność Akademii Wymiaru Sprawiedliwości. Takie decyzje w sprawie nieruchomości należących do więziennictwa podjął w dwa tygodnie po wyborach minister sprawiedliwości. Kamienicę i działkę przekazano na rzecz uczelni zwanej przez opozycję &quot;partyjną kuźnią kadr Suwerennej Polski&quot;.</p><br clear="all" />

## Rotacyjna chwała marszałkowania
 - [https://www.rmf24.pl/tylko-w-rmf24/tomasz_skory/komentarze/news-rotacyjna-chwala-marszalkowania,nId,7126699](https://www.rmf24.pl/tylko-w-rmf24/tomasz_skory/komentarze/news-rotacyjna-chwala-marszalkowania,nId,7126699)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T11:57:29+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/tomasz_skory/komentarze/news-rotacyjna-chwala-marszalkowania,nId,7126699"><img align="left" alt="Rotacyjna chwała marszałkowania" src="https://interia-s.pluscdn.pl/rotacyjna-chwala-marszalkowania/000HXLER5QBE0U8N-C307.jpg" /></a>Im dłużej aktualna jest propozycja rotacyjnego sprawowania urzędu marszałka Sejmu, tym bardziej zastanawiające jest podstawowe pytanie - po co? Być może odpowiedzią jest lakoniczne zdanie zapytanego o rotacyjne marszałkowanie Władysława Teofila Bartoszewskiego: &quot;Stanowisk jest dużo, ale chętnych zawsze jest więcej niż stanowisk&quot;.</p><br clear="all" />

## Sześciu wojewodów przenosi się do Sejmu. W ich miejsce nie będzie powołanych nowych
 - [https://www.rmf24.pl/raporty/raport-wybory-parlamentarne-2023/news-szesciu-wojewodow-przenosi-sie-do-sejmu-w-ich-miejsce-nie-be,nId,7126681](https://www.rmf24.pl/raporty/raport-wybory-parlamentarne-2023/news-szesciu-wojewodow-przenosi-sie-do-sejmu-w-ich-miejsce-nie-be,nId,7126681)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T11:40:47+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wybory-parlamentarne-2023/news-szesciu-wojewodow-przenosi-sie-do-sejmu-w-ich-miejsce-nie-be,nId,7126681"><img align="left" alt="Sześciu wojewodów przenosi się do Sejmu. W ich miejsce nie będzie powołanych nowych" src="https://interia-s.pluscdn.pl/szesciu-wojewodow-przenosi-sie-do-sejmu-w-ich-miejsce-nie-be/000HXKS455CBKVPW-C307.jpg" /></a>Premier nie będzie powoływał nowych wojewodów w miejsce urzędników, którzy zdobyli mandat poselski. Zastępować ich będą wicewojewodowie. To ustalenia reportera RMF FM Mariusza Piekarskiego. Sześcioro obecnych wojewodów przenosi się do parlamentu. </p><br clear="all" />

## Wypadli z trzeciego piętra sanatorium. Nie żyje 21-latek
 - [https://www.rmf24.pl/regiony/szczecin/news-wypadli-z-trzeciego-pietra-sanatorium-nie-zyje-21-latek,nId,7126644](https://www.rmf24.pl/regiony/szczecin/news-wypadli-z-trzeciego-pietra-sanatorium-nie-zyje-21-latek,nId,7126644)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T10:58:02+00:00

<p><a href="https://www.rmf24.pl/regiony/szczecin/news-wypadli-z-trzeciego-pietra-sanatorium-nie-zyje-21-latek,nId,7126644"><img align="left" alt="Wypadli z trzeciego piętra sanatorium. Nie żyje 21-latek" src="https://interia-s.pluscdn.pl/wypadli-z-trzeciego-pietra-sanatorium-nie-zyje-21-latek/000HXKFS13EPEV7D-C307.jpg" /></a>Nie udało się uratować życia 21-letniego obywatela Czech, który wypadł z balkonu na trzecim piętrze sanatorium Bałtyk. 23-letnia Słowaczka, która również ucierpiała w wypadku, przeszła bardzo poważną operację - powiedział rzecznik prokuratury Okręgowej w Koszalinie.</p><br clear="all" />

## Kradzież cennych woluminów z Biblioteki UW. Proceder mógł trwać kilka miesięcy
 - [https://www.rmf24.pl/regiony/warszawa/news-kradziez-cennych-woluminow-z-biblioteki-uw-proceder-mogl-trw,nId,7126628](https://www.rmf24.pl/regiony/warszawa/news-kradziez-cennych-woluminow-z-biblioteki-uw-proceder-mogl-trw,nId,7126628)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T10:46:40+00:00

<p><a href="https://www.rmf24.pl/regiony/warszawa/news-kradziez-cennych-woluminow-z-biblioteki-uw-proceder-mogl-trw,nId,7126628"><img align="left" alt="Kradzież cennych woluminów z Biblioteki UW. Proceder mógł trwać kilka miesięcy" src="https://interia-s.pluscdn.pl/kradziez-cennych-woluminow-z-biblioteki-uw-proceder-mogl-trw/000HXKEOCCM74YKV-C307.jpg" /></a>Prawdopodobnie od grudnia ubiegłego roku do połowy października mogły trwać kradzieże cennych pozycji z zasobów Biblioteki Uniwersytetu Warszawskiego - wynika z komunikatu rektora UW prof. Alojzego Z. Nowaka. Obecnie szacowana wartość skradzionych ok. 80 pozycji według aktualnych cen aukcyjnych przekracza 500 tys. euro. Trwa audyt zbiorów.</p><br clear="all" />

## Atak maczetą w Warszawie. Trwa policyjna obława
 - [https://www.rmf24.pl/regiony/warszawa/news-atak-maczeta-w-warszawie-trwa-policyjna-oblawa,nId,7126619](https://www.rmf24.pl/regiony/warszawa/news-atak-maczeta-w-warszawie-trwa-policyjna-oblawa,nId,7126619)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T10:42:35+00:00

<p><a href="https://www.rmf24.pl/regiony/warszawa/news-atak-maczeta-w-warszawie-trwa-policyjna-oblawa,nId,7126619"><img align="left" alt="Atak maczetą w Warszawie. Trwa policyjna obława" src="https://interia-s.pluscdn.pl/atak-maczeta-w-warszawie-trwa-policyjna-oblawa/000HXKCZTV2LVNKV-C307.jpg" /></a>Stołeczni policjanci szukają mężczyzny, który ranił maczetą co najmniej dwie osoby na warszawskich Bielanach. Jak dowiedział się nieoficjalnie reporter RMF FM, do tych zdarzeń doszło w okolicach ulicy Kochanowskiego. </p><br clear="all" />

## Dyrektor Biblioteki Narodowej gościem Rozmowy w południe w RMF i Radiu RMF24
 - [https://www.rmf24.pl/tylko-w-rmf24/rozmowa-w-poludnie/news-dyrektor-biblioteki-narodowej-gosciem-rozmowy-w-poludnie-w-r,nId,7126598](https://www.rmf24.pl/tylko-w-rmf24/rozmowa-w-poludnie/news-dyrektor-biblioteki-narodowej-gosciem-rozmowy-w-poludnie-w-r,nId,7126598)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T10:19:56+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/rozmowa-w-poludnie/news-dyrektor-biblioteki-narodowej-gosciem-rozmowy-w-poludnie-w-r,nId,7126598"><img align="left" alt="Dyrektor Biblioteki Narodowej gościem Rozmowy w południe w RMF i Radiu RMF24" src="https://interia-s.pluscdn.pl/dyrektor-biblioteki-narodowej-gosciem-rozmowy-w-poludnie-w-r/000HXK4V963WBWL9-C307.jpg" /></a>Gościem Rozmowy w południe w RMF i Radiu RMF24 będzie Tomasz Makowski, dyrektor Biblioteki Narodowej. Porozmawiamy z nim o zuchwałej kradzieży - z zasobów BUW mogło zginąć nawet kilkadziesiąt woluminów.  </p><br clear="all" />

## Dyrektor Biblioteki Narodowej: Co najmniej trzy skradzione książki z BUW trafiły na rynek aukcyjny
 - [https://www.rmf24.pl/tylko-w-rmf24/rozmowa-w-poludnie/news-dyrektor-biblioteki-narodowej-co-najmniej-trzy-skradzione-ks,nId,7126598](https://www.rmf24.pl/tylko-w-rmf24/rozmowa-w-poludnie/news-dyrektor-biblioteki-narodowej-co-najmniej-trzy-skradzione-ks,nId,7126598)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T10:19:56+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/rozmowa-w-poludnie/news-dyrektor-biblioteki-narodowej-co-najmniej-trzy-skradzione-ks,nId,7126598"><img align="left" alt="Dyrektor Biblioteki Narodowej: Co najmniej trzy skradzione książki z BUW trafiły na rynek aukcyjny" src="https://interia-s.pluscdn.pl/dyrektor-biblioteki-narodowej-co-najmniej-trzy-skradzione-ks/000HXK4V963WBWL9-C307.jpg" /></a>&quot;Wiemy o przynajmniej trzech książkach (z Biblioteki Uniwersyteckiej w Warszawie - przyp. red.), które już trafiły na rynek aukcyjny. W grudniu zeszłego roku pierwsza książka pojawiła się na aukcji, następna w kwietniu 2023 roku. Także część zapewne obecnych właścicieli będzie chciała je zwrócić, ale również trzeba podjąć próbę odzyskania ich, bo to była na pewno kradzież&quot; - mówi w Rozmowie w południe w RMF i Radiu RMF24 dyrektor Biblioteki Narodowej Tomasz Makowski. Zapewnia, że &quot;cenne książki w polskich bibliotekach są bezpieczne&quot;. </p><br clear="all" />

## Michał Probierz znów wykorzysta do maksimum czas na powołania
 - [https://www.rmf24.pl/raporty/raport-eliminacje-euro-2024/news-michal-probierz-znow-wykorzysta-do-maksimum-czas-na-powolani,nId,7126577](https://www.rmf24.pl/raporty/raport-eliminacje-euro-2024/news-michal-probierz-znow-wykorzysta-do-maksimum-czas-na-powolani,nId,7126577)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T09:55:07+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-eliminacje-euro-2024/news-michal-probierz-znow-wykorzysta-do-maksimum-czas-na-powolani,nId,7126577"><img align="left" alt="Michał Probierz znów wykorzysta do maksimum czas na powołania" src="https://interia-s.pluscdn.pl/michal-probierz-znow-wykorzysta-do-maksimum-czas-na-powolani/000HXJZAUMK0CNBM-C307.jpg" /></a>Michał Probierz, selekcjoner piłkarskiej reprezentacji Polski, przygotowuje się do ogłoszenia listy powołanych zawodników na listopadowe mecze z Czechami w eliminacjach Euro i towarzyskie starcie z Łotwą. Wiemy, że pochodzący z Bytomia trener z ogłoszeniem ostatecznej kadry podobnie jak poprzednim razem będzie zwlekał do ostatniego momentu. Listę nazwisk 
poznamy dopiero wieczorem po czwartkowych meczach Ligi Europy i Ligi Konferencji 9 listopada.</p><br clear="all" />

## Operacja "Carlos". Wpadło 64 podejrzanych o rozpowszechnianie dziecięcej pornografii
 - [https://www.rmf24.pl/regiony/warszawa/news-operacja-carlos-wpadlo-64-podejrzanych-o-rozpowszechnianie-d,nId,7126571](https://www.rmf24.pl/regiony/warszawa/news-operacja-carlos-wpadlo-64-podejrzanych-o-rozpowszechnianie-d,nId,7126571)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T09:47:27+00:00

<p><a href="https://www.rmf24.pl/regiony/warszawa/news-operacja-carlos-wpadlo-64-podejrzanych-o-rozpowszechnianie-d,nId,7126571"><img align="left" alt="Operacja &quot;Carlos&quot;. Wpadło 64 podejrzanych o rozpowszechnianie dziecięcej pornografii " src="https://interia-s.pluscdn.pl/operacja-carlos-wpadlo-64-podejrzanych-o-rozpowszechnianie-d/000HXJY565AY06US-C307.jpg" /></a>Policjanci zatrzymali 64 osoby podejrzewane o posiadanie i rozpowszechnianie materiałów przedstawiających seksualne wykorzystywanie dzieci. Jest wśród nich mężczyzna, który robił zdjęcia i filmy z nagimi dziećmi i miał zgwałcić oraz wykorzystać dwóch małoletnich. W operacji o kryptonimie &quot;Carlos&quot;, przeprowadzonej przez Centralne Biuro Zwalczania Cyberprzestępczości na terenie całej Polski, uczestniczyło ponad 400 funkcjonariuszy.</p><br clear="all" />

## Policja nie wyklucza, że Grzegorz Borys nie żyje
 - [https://www.rmf24.pl/regiony/trojmiasto/news-policja-nie-wyklucza-ze-grzegorz-borys-nie-zyje,nId,7126561](https://www.rmf24.pl/regiony/trojmiasto/news-policja-nie-wyklucza-ze-grzegorz-borys-nie-zyje,nId,7126561)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T09:37:05+00:00

<p><a href="https://www.rmf24.pl/regiony/trojmiasto/news-policja-nie-wyklucza-ze-grzegorz-borys-nie-zyje,nId,7126561"><img align="left" alt="Policja nie wyklucza, że Grzegorz Borys nie żyje" src="https://interia-s.pluscdn.pl/policja-nie-wyklucza-ze-grzegorz-borys-nie-zyje/000HXJXCJ3QG5B5Q-C307.jpg" /></a>Nie wykluczamy, że Grzegorz Borys nie żyje - poinformowała na konferencji policja i Żandarmeria Wojskowa. Wcześniej służby przekazały, że zawęziły obszar poszukiwań 44-latka. Będą teraz prowadzone na terenie 2 hektarów. Mężczyzna jest podejrzany o zabicie 6-letniego syna.</p><br clear="all" />

## Policja nie wyklucza, że Grzegorz Borys nie żyje. Zawężono obszar poszukiwań
 - [https://www.rmf24.pl/regiony/trojmiasto/news-policja-nie-wyklucza-ze-grzegorz-borys-nie-zyje-zawezono-obs,nId,7126561](https://www.rmf24.pl/regiony/trojmiasto/news-policja-nie-wyklucza-ze-grzegorz-borys-nie-zyje-zawezono-obs,nId,7126561)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T09:37:05+00:00

<p><a href="https://www.rmf24.pl/regiony/trojmiasto/news-policja-nie-wyklucza-ze-grzegorz-borys-nie-zyje-zawezono-obs,nId,7126561"><img align="left" alt="Policja nie wyklucza, że Grzegorz Borys nie żyje. Zawężono obszar poszukiwań" src="https://interia-s.pluscdn.pl/policja-nie-wyklucza-ze-grzegorz-borys-nie-zyje-zawezono-obs/000HXJXCJ3QG5B5Q-C307.jpg" /></a>Nie wykluczamy, że Grzegorz Borys nie żyje - poinformowała na konferencji policja i Żandarmeria Wojskowa. Wcześniej służby przekazały, że zawęziły obszar poszukiwań 44-latka. Będą teraz prowadzone na terenie 2 hektarów. Mężczyzna jest podejrzany o zabicie 6-letniego syna.</p><br clear="all" />

## Poszukiwania Grzegorza Borysa. Zawężono teren poszukiwań
 - [https://www.rmf24.pl/regiony/trojmiasto/news-poszukiwania-grzegorza-borysa-zawezono-teren-poszukiwan,nId,7126561](https://www.rmf24.pl/regiony/trojmiasto/news-poszukiwania-grzegorza-borysa-zawezono-teren-poszukiwan,nId,7126561)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T09:37:05+00:00

<p><a href="https://www.rmf24.pl/regiony/trojmiasto/news-poszukiwania-grzegorza-borysa-zawezono-teren-poszukiwan,nId,7126561"><img align="left" alt="Poszukiwania Grzegorza Borysa. Zawężono teren poszukiwań" src="https://interia-s.pluscdn.pl/poszukiwania-grzegorza-borysa-zawezono-teren-poszukiwan/000HXJVTMVJ1IKAQ-C307.jpg" /></a>Policja i Żandarmeria Wojskowa zawęziły obszar poszukiwań Grzegorza Borysa. Będą teraz prowadzone na terenie 2 hektarów. Borys jest podejrzany o zabicie 6-letniego syna. </p><br clear="all" />

## Prąd zdrożeje od nowego roku
 - [https://www.rmf24.pl/ekonomia/news-prad-zdrozeje-od-nowego-roku,nId,7126533](https://www.rmf24.pl/ekonomia/news-prad-zdrozeje-od-nowego-roku,nId,7126533)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T08:59:31+00:00

<p><a href="https://www.rmf24.pl/ekonomia/news-prad-zdrozeje-od-nowego-roku,nId,7126533"><img align="left" alt="Prąd zdrożeje od nowego roku" src="https://interia-s.pluscdn.pl/prad-zdrozeje-od-nowego-roku/000HXJQAEWFEPFXH-C307.jpg" /></a>Prąd od nowego roku będzie droższy. Wnioski taryfowe od sprzedawców energii elektrycznej wpłynęły już do prezesa Urzędu Regulacji Energetyki. W grudniu określi on taryfy na przyszły rok.  </p><br clear="all" />

## 350 tabletek ecstasy w firmie kurierskiej. Znalazł je pies Yerry
 - [https://www.rmf24.pl/regiony/slaskie/news-350-tabletek-ecstasy-w-firmie-kurierskiej-znalazl-je-pies-ye,nId,7126531](https://www.rmf24.pl/regiony/slaskie/news-350-tabletek-ecstasy-w-firmie-kurierskiej-znalazl-je-pies-ye,nId,7126531)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T08:56:33+00:00

<p><a href="https://www.rmf24.pl/regiony/slaskie/news-350-tabletek-ecstasy-w-firmie-kurierskiej-znalazl-je-pies-ye,nId,7126531"><img align="left" alt="350 tabletek ecstasy w firmie kurierskiej. Znalazł je pies Yerry" src="https://interia-s.pluscdn.pl/350-tabletek-ecstasy-w-firmie-kurierskiej-znalazl-je-pies-ye/000HXJFVUAUGQCJQ-C307.jpg" /></a>Ponad 350 tabletek ecstasy przejęli funkcjonariusze śląskiej Krajowej Administracji Skarbowej, którzy skontrolowali sortownię przesyłek firmy kurierskiej w Zabrzu. Paczkę, w której znajdowały się narkotyki wytypował służbowy pies - Yerry.</p><br clear="all" />

## Jest wniosek o decyzję lokalizacyjną w sprawie CPK
 - [https://www.rmf24.pl/regiony/warszawa/news-jest-wniosek-o-decyzje-lokalizacyjna-w-sprawie-cpk,nId,7126526](https://www.rmf24.pl/regiony/warszawa/news-jest-wniosek-o-decyzje-lokalizacyjna-w-sprawie-cpk,nId,7126526)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T08:54:02+00:00

<p><a href="https://www.rmf24.pl/regiony/warszawa/news-jest-wniosek-o-decyzje-lokalizacyjna-w-sprawie-cpk,nId,7126526"><img align="left" alt="Jest wniosek o decyzję lokalizacyjną w sprawie CPK" src="https://interia-s.pluscdn.pl/jest-wniosek-o-decyzje-lokalizacyjna-w-sprawie-cpk/000HXJFY51N868LA-C307.jpg" /></a>Spółka CPK złożyła w Mazowieckim Urzędzie Wojewódzkim wniosek o decyzję lokalizacyjną dla Centralnego Portu Komunikacyjnego - dowiedział się reporter RMF FM. Chodzi o największe lotnisko w Polsce, które ma powstać między Łodzią a Warszawą.</p><br clear="all" />

## ​72-latek oszukiwał metodą na policjanta. Do samego końca walczył o łup
 - [https://www.rmf24.pl/regiony/warszawa/news-72-latek-oszukiwal-metoda-na-policjanta-do-samego-konca-walc,nId,7126450](https://www.rmf24.pl/regiony/warszawa/news-72-latek-oszukiwal-metoda-na-policjanta-do-samego-konca-walc,nId,7126450)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T07:34:36+00:00

<p><a href="https://www.rmf24.pl/regiony/warszawa/news-72-latek-oszukiwal-metoda-na-policjanta-do-samego-konca-walc,nId,7126450"><img align="left" alt="​72-latek oszukiwał metodą na policjanta. Do samego końca walczył o łup" src="https://interia-s.pluscdn.pl/72-latek-oszukiwal-metoda-na-policjanta-do-samego-konca-walc/000HXI4HA5UVUMM8-C307.jpg" /></a>72-latek jest prawdopodobnie najstarszą osobą dopuszczającą się oszustwa metodą &quot;na policjanta&quot;. Mężczyzna został zatrzymany przez policjantów z warszawskiego Śródmieścia. Chociaż znalazł się w rękach policji, a w reklamówce zamiast pieniędzy znajdował się pocięty papier, senior do samego końca zaciekle walczył o swój łup.</p><br clear="all" />

## Powódź w Toskanii. Dramatyczny apel władz
 - [https://www.rmf24.pl/fakty/swiat/news-powodz-w-toskanii-dramatyczny-apel-wladz,nId,7126448](https://www.rmf24.pl/fakty/swiat/news-powodz-w-toskanii-dramatyczny-apel-wladz,nId,7126448)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T07:32:58+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-powodz-w-toskanii-dramatyczny-apel-wladz,nId,7126448"><img align="left" alt="Powódź w Toskanii. Dramatyczny apel władz" src="https://interia-s.pluscdn.pl/powodz-w-toskanii-dramatyczny-apel-wladz/000HXID51RV1KR7O-C307.jpg" /></a>Trzy osoby zginęły w wyniku powodzi w Toskanii - podały władze regionu. Z powodu szalejącego nad Europą sztormu Ciaran nad tym Włochami przeszły gigantyczne ulew. Największe straty spowodowały właśnie w Toskanii.  </p><br clear="all" />

## Izrael nasila bombardowanie Strefy Gazy
 - [https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-izrael-nasila-bombardowanie-strefy-gazy,nId,7126435](https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-izrael-nasila-bombardowanie-strefy-gazy,nId,7126435)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T07:08:43+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-izrael-nasila-bombardowanie-strefy-gazy,nId,7126435"><img align="left" alt="Izrael nasila bombardowanie Strefy Gazy" src="https://interia-s.pluscdn.pl/izrael-nasila-bombardowanie-strefy-gazy/000HXHV9HQ94TQA9-C307.jpg" /></a>W nocy Izrael nasilił bombardowania Strefy Gazy. Wydaje się, że koncentrowały się one w rejonie miasta Bajt Hanun - podała telewizja CNN. Eksperci cytowani przez BBC uważają, że Izrael próbuje odizolować północny skrawek Strefy Gazy.</p><br clear="all" />

## ​Pożar drewnianego domu: Jedna osoba nie zdążyła się wydostać
 - [https://www.rmf24.pl/regiony/lublin/news-pozar-drewnianego-domu-jedna-osoba-nie-zdazyla-sie-wydostac,nId,7126434](https://www.rmf24.pl/regiony/lublin/news-pozar-drewnianego-domu-jedna-osoba-nie-zdazyla-sie-wydostac,nId,7126434)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T07:07:40+00:00

<p><a href="https://www.rmf24.pl/regiony/lublin/news-pozar-drewnianego-domu-jedna-osoba-nie-zdazyla-sie-wydostac,nId,7126434"><img align="left" alt="​Pożar drewnianego domu: Jedna osoba nie zdążyła się wydostać" src="https://interia-s.pluscdn.pl/pozar-drewnianego-domu-jedna-osoba-nie-zdazyla-sie-wydostac/000HXHTWY9E8Y74W-C307.jpg" /></a>Jedna osoba zginęła w pożarze domu w miejscowości Bedlno (Lubelskie) - poinformowała straż pożarna. Ogień wybuchł w nocy z czwartku na piątek.</p><br clear="all" />

## Silny wiatr w całym kraju. Synoptycy ostrzegają
 - [https://www.rmf24.pl/pogoda/news-silny-wiatr-w-calym-kraju-synoptycy-ostrzegaja,nId,7126433](https://www.rmf24.pl/pogoda/news-silny-wiatr-w-calym-kraju-synoptycy-ostrzegaja,nId,7126433)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T07:07:36+00:00

<p><a href="https://www.rmf24.pl/pogoda/news-silny-wiatr-w-calym-kraju-synoptycy-ostrzegaja,nId,7126433"><img align="left" alt="Silny wiatr w całym kraju. Synoptycy ostrzegają" src="https://interia-s.pluscdn.pl/silny-wiatr-w-calym-kraju-synoptycy-ostrzegaja/000HXHTKN4MQV9LA-C307.jpg" /></a>To będzie pochmurny i deszczowy piątek w całej Polsce. Należy spodziewać się też silnego wiatru. Najmocniej powieje na północnym wschodzie i południu kraju. W Sudetach będzie padać śnieg. </p><br clear="all" />

## Bartoszewski o rotacyjnym marszałku Sejmu. „Jak jest czterech liderów, to pojawiają się nowe pomysły”
 - [https://www.rmf24.pl/tylko-w-rmf24/poranna-rozmowa/news-bartoszewski-o-rotacyjnym-marszalku-sejmu-jak-jest-czterech-,nId,7124695](https://www.rmf24.pl/tylko-w-rmf24/poranna-rozmowa/news-bartoszewski-o-rotacyjnym-marszalku-sejmu-jak-jest-czterech-,nId,7124695)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T07:02:00+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/poranna-rozmowa/news-bartoszewski-o-rotacyjnym-marszalku-sejmu-jak-jest-czterech-,nId,7124695"><img align="left" alt="Bartoszewski o rotacyjnym marszałku Sejmu. „Jak jest czterech liderów, to pojawiają się nowe pomysły”" src="https://interia-s.pluscdn.pl/bartoszewski-o-rotacyjnym-marszalku-sejmu-jak-jest-czterech/000HXE6T1M1BGBAH-C307.jpg" /></a>„Dyskusje cały czas trwają. Rozmaite pomysły się pojawiają” – tak o idei rotacyjnego marszałku Sejmu mówił w Porannej rozmowie w RMF FM Władysław Teofil Bartoszewski. Polityk PSL-u przyznał, że jeszcze niedawno jego ugrupowanie podchodziło do tego pomysłu sceptycznie. „Ale wyraźnie jak jest czterech liderów czterech ugrupowań i zaczynają się dyskusje o bardzo ważnych pozycjach, to pojawiają się nowe pomysły” – przyznał.</p><br clear="all" />

## Władysław Teofil Bartoszewski gościem Porannej rozmowy w RMF FM
 - [https://www.rmf24.pl/tylko-w-rmf24/poranna-rozmowa/news-wladyslaw-teofil-bartoszewski-gosciem-porannej-rozmowy-w-rmf,nId,7124695](https://www.rmf24.pl/tylko-w-rmf24/poranna-rozmowa/news-wladyslaw-teofil-bartoszewski-gosciem-porannej-rozmowy-w-rmf,nId,7124695)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T06:57:00+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/poranna-rozmowa/news-wladyslaw-teofil-bartoszewski-gosciem-porannej-rozmowy-w-rmf,nId,7124695"><img align="left" alt="Władysław Teofil Bartoszewski gościem Porannej rozmowy w RMF FM" src="https://interia-s.pluscdn.pl/wladyslaw-teofil-bartoszewski-gosciem-porannej-rozmowy-w-rmf/000HXE6T1M1BGBAH-C307.jpg" /></a>Gościem Porannej rozmowy w RMF FM będzie Władysław Teofil Bartoszewski, poseł Polskiego Stronnictwa Ludowego, Trzecia Droga. Porozmawiamy o negocjacjach pomiędzy Koalicją Obywatelską, Trzecią Drogą i Lewicą.</p><br clear="all" />

## ​CBŚP zlikwidowało przemytniczy szlak z Dubaju. Ponad 37 mln sztuk papierosów
 - [https://www.rmf24.pl/regiony/poznan/news-cbsp-zlikwidowalo-przemytniczy-szlak-z-dubaju-ponad-37-mln-s,nId,7126419](https://www.rmf24.pl/regiony/poznan/news-cbsp-zlikwidowalo-przemytniczy-szlak-z-dubaju-ponad-37-mln-s,nId,7126419)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T06:38:30+00:00

<p><a href="https://www.rmf24.pl/regiony/poznan/news-cbsp-zlikwidowalo-przemytniczy-szlak-z-dubaju-ponad-37-mln-s,nId,7126419"><img align="left" alt="​CBŚP zlikwidowało przemytniczy szlak z Dubaju. Ponad 37 mln sztuk papierosów" src="https://interia-s.pluscdn.pl/cbsp-zlikwidowalo-przemytniczy-szlak-z-dubaju-ponad-37-mln-s/000HXHRDEOACUBYX-C307.jpg" /></a>Służby przejęły ponad 37 mln sztuk papierosów bez akcyzy, wartych ponad 28 mln zł. Nielegalny towar trafił do Polski najprawdopodobniej z Dubaju. Gdyby papierosy trafiły na polski rynek, straty budżetu państwa wyniosłyby ponad 46 mln zł.</p><br clear="all" />

## Dostali polskie wizy, nad Wisłę dotarł co siódmy. Znikający specjaliści IT
 - [https://www.rmf24.pl/fakty/polska/news-dostali-polskie-wizy-nad-wisle-dotarl-co-siodmy-znikajacy-sp,nId,7126415](https://www.rmf24.pl/fakty/polska/news-dostali-polskie-wizy-nad-wisle-dotarl-co-siodmy-znikajacy-sp,nId,7126415)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T06:30:13+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-dostali-polskie-wizy-nad-wisle-dotarl-co-siodmy-znikajacy-sp,nId,7126415"><img align="left" alt="Dostali polskie wizy, nad Wisłę dotarł co siódmy. Znikający specjaliści IT" src="https://interia-s.pluscdn.pl/dostali-polskie-wizy-nad-wisle-dotarl-co-siodmy-znikajacy-sp/000HXHQFJQ4BAINS-C307.jpg" /></a>Choć nasz kraj wydał ponad 90 tys. wiz dla specjalistów IT ze Wschodu, do Polski przyjechał tylko co siódmy zaproszony cudzoziemiec; nikt nie wie, co się dzieje z pozostałymi - informuje piątkowa &quot;Rzeczpospolita&quot;.</p><br clear="all" />

## Płk Łukasiewicz: Izraelski pierścień wokół Gazy nie jest tak szczelny
 - [https://www.rmf24.pl/tylko-w-rmf24/rozmowa-o-7/news-plk-lukasiewicz-izraelski-pierscien-wokol-gazy-nie-jest-tak-,nId,7124609](https://www.rmf24.pl/tylko-w-rmf24/rozmowa-o-7/news-plk-lukasiewicz-izraelski-pierscien-wokol-gazy-nie-jest-tak-,nId,7124609)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T06:00:00+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/rozmowa-o-7/news-plk-lukasiewicz-izraelski-pierscien-wokol-gazy-nie-jest-tak-,nId,7124609"><img align="left" alt="Płk Łukasiewicz: Izraelski pierścień wokół Gazy nie jest tak szczelny" src="https://interia-s.pluscdn.pl/plk-lukasiewicz-izraelski-pierscien-wokol-gazy-nie-jest-tak/000HXCKL1G8TEJIX-C307.jpg" /></a>&quot;Wojsko izraelskie atakuje z trzech punktów wokół miasta Gazy - od wybrzeża, od obozu Dżabalija, od północy od sieci obozów Bajt Hanun i od południa. Nie wiem, czy można to nazwać pierścieniem, na pewno są to takie trzy miejsca koncentracji sił&quot;- tak o tym, co dzieje się teraz wokół Strefy Gazy mówił w Rozmowie o 7:00 w RMF FM i Radiu RMF24 płk Piotr Łukasiewicz. </p><br clear="all" />

## Miedwiediew znów grozi Polsce. Pisze o końcu państwowości
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-miedwiediew-znow-grozi-polsce-pisze-o-koncu-panstwowosci,nId,7126405](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-miedwiediew-znow-grozi-polsce-pisze-o-koncu-panstwowosci,nId,7126405)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T05:52:10+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-miedwiediew-znow-grozi-polsce-pisze-o-koncu-panstwowosci,nId,7126405"><img align="left" alt="Miedwiediew znów grozi Polsce. Pisze o końcu państwowości" src="https://interia-s.pluscdn.pl/miedwiediew-znow-grozi-polsce-pisze-o-koncu-panstwowosci/000HXHOI60KSB6W2-C307.jpg" /></a>Agresywny tekst Dmitrija Miedwiediewa to typowy dla Kremla seans nienawiści, przepełniony groźbami wobec Polsce i NATO - ocenił  sekretarz stanu w KPRM Stanisław Żaryn. Skomentował w ten sposób artykuł, w którym Miedwiediew ostrzega Polskę, że może utracić państwowość, jeśli będzie kontynuować obecny kurs.</p><br clear="all" />

## Szkielet sprzed wieków z metalową protezą. Niezwykłe odkrycie w Bawarii
 - [https://www.rmf24.pl/nauka/news-szkielet-sprzed-wiekow-z-metalowa-proteza-niezwykle-odkrycie,nId,7126403](https://www.rmf24.pl/nauka/news-szkielet-sprzed-wiekow-z-metalowa-proteza-niezwykle-odkrycie,nId,7126403)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-11-03T05:45:00+00:00

<p><a href="https://www.rmf24.pl/nauka/news-szkielet-sprzed-wiekow-z-metalowa-proteza-niezwykle-odkrycie,nId,7126403"><img align="left" alt="Szkielet sprzed wieków z metalową protezą. Niezwykłe odkrycie w Bawarii" src="https://interia-s.pluscdn.pl/szkielet-sprzed-wiekow-z-metalowa-proteza-niezwykle-odkrycie/000HXHNVV9K658PV-C307.jpg" /></a>Do ciekawe odkrycia doszło w niemieckim Freising (Bawaria). Archeolodzy w trakcie prac znaleźli tam szkielet mężczyzny zmarłego między 1450 a 1620 rokiem, z czterema metalowymi palcami.</p><br clear="all" />

