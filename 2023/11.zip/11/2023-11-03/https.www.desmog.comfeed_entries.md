# Source:DeSmog, URL:https://www.desmog.com/feed/, language:en-US

## Vaclav Smil Tells Shell Canada President Carbon Capture Is ‘the Stupidest Solution’
 - [https://www.desmog.com/2023/11/03/vaclav-smil-tells-shell-canada-president-carbon-capture-is-the-stupidest-solution](https://www.desmog.com/2023/11/03/vaclav-smil-tells-shell-canada-president-carbon-capture-is-the-stupidest-solution)
 - RSS feed: https://www.desmog.com/feed/
 - date published: 2023-11-03T20:14:03+00:00

<p>A well-known Canadian professor who doesn’t believe in global cooperation to prevent climate change described carbon capture and storage (CCS) as “stupid” in a recent discussion hosted by Resource Works, a Canadian natural resource development lobby group. Vaclav Smil, professor emeritus in the Faculty of the Environment at the University of Manitoba, laughed when the [&#8230;]</p>
<p>The post <a href="https://www.desmog.com/2023/11/03/vaclav-smil-tells-shell-canada-president-carbon-capture-is-the-stupidest-solution/" rel="nofollow">Vaclav Smil Tells Shell Canada President Carbon Capture Is ‘the Stupidest Solution’</a> appeared first on <a href="https://www.desmog.com" rel="nofollow">DeSmog</a>.</p>

## Climate Science Denial Rife at Launch of Jordan Peterson’s ARC Project
 - [https://www.desmog.com/2023/11/03/climate-science-denial-rife-at-launch-of-jordan-petersons-arc-project](https://www.desmog.com/2023/11/03/climate-science-denial-rife-at-launch-of-jordan-petersons-arc-project)
 - RSS feed: https://www.desmog.com/feed/
 - date published: 2023-11-03T14:45:57+00:00

<p>Canadian climate science denier Jordan Peterson’s new right-wing project launched this week with claims that carbon emissions have “declined” and that the climate crisis is a “secular religion”.&#160; The three-day Alliance for Responsible Citizenship (ARC) conference in London featured speeches from UK Cabinet ministers Michael Gove and Kemi Badenoch, and culminated with a high-profile event [&#8230;]</p>
<p>The post <a href="https://www.desmog.com/2023/11/03/climate-science-denial-rife-at-launch-of-jordan-petersons-arc-project/" rel="nofollow">Climate Science Denial Rife at Launch of Jordan Peterson’s ARC Project</a> appeared first on <a href="https://www.desmog.com" rel="nofollow">DeSmog</a>.</p>

