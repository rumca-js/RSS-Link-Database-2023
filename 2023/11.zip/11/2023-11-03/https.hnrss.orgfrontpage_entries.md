# Source:Hacker News - frontpage, URL:https://hnrss.org/frontpage, language:en-US

## First Handset with MTE on the Market
 - [https://googleprojectzero.blogspot.com/2023/11/first-handset-with-mte-on-market.html](https://googleprojectzero.blogspot.com/2023/11/first-handset-with-mte-on-market.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T22:03:38+00:00

<p>Article URL: <a href="https://googleprojectzero.blogspot.com/2023/11/first-handset-with-mte-on-market.html">https://googleprojectzero.blogspot.com/2023/11/first-handset-with-mte-on-market.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38135619">https://news.ycombinator.com/item?id=38135619</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## Fuchsia F14
 - [https://fuchsia.dev/whats-new/release-notes/f14](https://fuchsia.dev/whats-new/release-notes/f14)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T21:38:14+00:00

<p>Article URL: <a href="https://fuchsia.dev/whats-new/release-notes/f14">https://fuchsia.dev/whats-new/release-notes/f14</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38135320">https://news.ycombinator.com/item?id=38135320</a></p>
<p>Points: 27</p>
<p># Comments: 24</p>

## The use and misuse of evolutionary psychology in online manosphere communities
 - [https://www.cambridge.org/core/journals/evolutionary-human-sciences/article/use-and-misuse-of-evolutionary-psychology-in-online-manosphere-communities-the-case-of-female-mating-strategies/19522B41CF67DFF9F66D919E1F843CCC](https://www.cambridge.org/core/journals/evolutionary-human-sciences/article/use-and-misuse-of-evolutionary-psychology-in-online-manosphere-communities-the-case-of-female-mating-strategies/19522B41CF67DFF9F66D919E1F843CCC)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T21:04:59+00:00

<p>Article URL: <a href="https://www.cambridge.org/core/journals/evolutionary-human-sciences/article/use-and-misuse-of-evolutionary-psychology-in-online-manosphere-communities-the-case-of-female-mating-strategies/19522B41CF67DFF9F66D919E1F843CCC">https://www.cambridge.org/core/journals/evolutionary-human-sciences/article/use-and-misuse-of-evolutionary-psychology-in-online-manosphere-communities-the-case-of-female-mating-strategies/19522B41CF67DFF9F66D919E1F843CCC</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38134998">https://news.ycombinator.com/item?id=38134998</a></p>
<p>Points: 23</p>
<p># Comments: 3</p>

## BBC World Service Announces Emergency Radio Service for Gaza
 - [https://www.bbc.com/mediacentre/2023/bbc-world-service-announces-emergency-radio-service-for-gaza](https://www.bbc.com/mediacentre/2023/bbc-world-service-announces-emergency-radio-service-for-gaza)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T21:00:48+00:00

<p>Article URL: <a href="https://www.bbc.com/mediacentre/2023/bbc-world-service-announces-emergency-radio-service-for-gaza">https://www.bbc.com/mediacentre/2023/bbc-world-service-announces-emergency-radio-service-for-gaza</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38134947">https://news.ycombinator.com/item?id=38134947</a></p>
<p>Points: 15</p>
<p># Comments: 4</p>

## Why Mozilla is betting on a decentralized social networking future
 - [https://techcrunch.com/2023/11/03/why-mozilla-is-betting-on-a-decentralized-social-networking-future](https://techcrunch.com/2023/11/03/why-mozilla-is-betting-on-a-decentralized-social-networking-future)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T20:39:44+00:00

<p>Article URL: <a href="https://techcrunch.com/2023/11/03/why-mozilla-is-betting-on-a-decentralized-social-networking-future/">https://techcrunch.com/2023/11/03/why-mozilla-is-betting-on-a-decentralized-social-networking-future/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38134697">https://news.ycombinator.com/item?id=38134697</a></p>
<p>Points: 22</p>
<p># Comments: 2</p>

## Show HN: GitInsights – a weekly summary email of your team's GitHub activity
 - [https://gitinsights.io](https://gitinsights.io)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T20:15:03+00:00

<p>Article URL: <a href="https://gitinsights.io/">https://gitinsights.io/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38134389">https://news.ycombinator.com/item?id=38134389</a></p>
<p>Points: 18</p>
<p># Comments: 10</p>

## Microsoft is retiring Visual Studio for Mac in 2024
 - [https://visualstudio.microsoft.com/vs/mac](https://visualstudio.microsoft.com/vs/mac)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T20:14:05+00:00

<p>Article URL: <a href="https://visualstudio.microsoft.com/vs/mac/">https://visualstudio.microsoft.com/vs/mac/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38134381">https://news.ycombinator.com/item?id=38134381</a></p>
<p>Points: 23</p>
<p># Comments: 15</p>

## Show HN: Chat with Garry Tan using RAG on his YouTube channel
 - [https://gtan-chat.arguflow.ai](https://gtan-chat.arguflow.ai)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T19:59:56+00:00

<p>Article URL: <a href="https://gtan-chat.arguflow.ai/">https://gtan-chat.arguflow.ai/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38134200">https://news.ycombinator.com/item?id=38134200</a></p>
<p>Points: 9</p>
<p># Comments: 0</p>

## Good genes are nice, but joy is better
 - [https://news.harvard.edu/gazette/story/2017/04/over-nearly-80-years-harvard-study-has-been-showing-how-to-live-a-healthy-and-happy-life](https://news.harvard.edu/gazette/story/2017/04/over-nearly-80-years-harvard-study-has-been-showing-how-to-live-a-healthy-and-happy-life)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T19:58:30+00:00

<p>Article URL: <a href="https://news.harvard.edu/gazette/story/2017/04/over-nearly-80-years-harvard-study-has-been-showing-how-to-live-a-healthy-and-happy-life/">https://news.harvard.edu/gazette/story/2017/04/over-nearly-80-years-harvard-study-has-been-showing-how-to-live-a-healthy-and-happy-life/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38134181">https://news.ycombinator.com/item?id=38134181</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## Accelerating digital block design with Google's open source Mid-Level Synthesis
 - [https://antmicro.com/blog/2023/09/accelerating-digital-block-design-with-googles-xls](https://antmicro.com/blog/2023/09/accelerating-digital-block-design-with-googles-xls)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T19:53:09+00:00

<p>Article URL: <a href="https://antmicro.com/blog/2023/09/accelerating-digital-block-design-with-googles-xls/">https://antmicro.com/blog/2023/09/accelerating-digital-block-design-with-googles-xls/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38134120">https://news.ycombinator.com/item?id=38134120</a></p>
<p>Points: 9</p>
<p># Comments: 0</p>

## The Tech Gold Rush Is Over. Where's the Next One?
 - [https://www.bloomberg.com/opinion/articles/2023-11-03/the-tech-gold-rush-is-over-the-search-for-the-next-gold-rush-is-on](https://www.bloomberg.com/opinion/articles/2023-11-03/the-tech-gold-rush-is-over-the-search-for-the-next-gold-rush-is-on)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T19:47:43+00:00

<p>Article URL: <a href="https://www.bloomberg.com/opinion/articles/2023-11-03/the-tech-gold-rush-is-over-the-search-for-the-next-gold-rush-is-on">https://www.bloomberg.com/opinion/articles/2023-11-03/the-tech-gold-rush-is-over-the-search-for-the-next-gold-rush-is-on</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38134044">https://news.ycombinator.com/item?id=38134044</a></p>
<p>Points: 21</p>
<p># Comments: 18</p>

## How Coffee and Sugar Powered the Industrial Revolution and Shaped Modern Work
 - [https://www.getchestr.com/post/sweet-stimulants-how-coffee-and-sugar-powered-the-industrial-revolution-and-shaped-modern-work](https://www.getchestr.com/post/sweet-stimulants-how-coffee-and-sugar-powered-the-industrial-revolution-and-shaped-modern-work)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T19:44:28+00:00

<p>Article URL: <a href="https://www.getchestr.com/post/sweet-stimulants-how-coffee-and-sugar-powered-the-industrial-revolution-and-shaped-modern-work">https://www.getchestr.com/post/sweet-stimulants-how-coffee-and-sugar-powered-the-industrial-revolution-and-shaped-modern-work</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38134014">https://news.ycombinator.com/item?id=38134014</a></p>
<p>Points: 9</p>
<p># Comments: 4</p>

## Podman Desktop v1.5 with Compose onboarding and enhanced Kubernetes pod data
 - [https://podman-desktop.io/blog/podman-desktop-release-1.5](https://podman-desktop.io/blog/podman-desktop-release-1.5)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T19:39:03+00:00

<p>Article URL: <a href="https://podman-desktop.io/blog/podman-desktop-release-1.5">https://podman-desktop.io/blog/podman-desktop-release-1.5</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38133963">https://news.ycombinator.com/item?id=38133963</a></p>
<p>Points: 19</p>
<p># Comments: 1</p>

## We are investigating reports of degraded performance
 - [https://www.githubstatus.com/incidents/xb30mby9fs5x](https://www.githubstatus.com/incidents/xb30mby9fs5x)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T18:55:50+00:00

<p>Article URL: <a href="https://www.githubstatus.com/incidents/xb30mby9fs5x">https://www.githubstatus.com/incidents/xb30mby9fs5x</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38133297">https://news.ycombinator.com/item?id=38133297</a></p>
<p>Points: 34</p>
<p># Comments: 24</p>

## Appeals Court Denies Judicial Immunity to Judge Who Personally Searched Home
 - [https://ij.org/press-release/victory-appeals-court-unanimously-denies-judicial-immunity-to-west-virginia-judge-who-personally-searched-home-ordered-items-removed](https://ij.org/press-release/victory-appeals-court-unanimously-denies-judicial-immunity-to-west-virginia-judge-who-personally-searched-home-ordered-items-removed)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T18:54:37+00:00

<p>Article URL: <a href="https://ij.org/press-release/victory-appeals-court-unanimously-denies-judicial-immunity-to-west-virginia-judge-who-personally-searched-home-ordered-items-removed/">https://ij.org/press-release/victory-appeals-court-unanimously-denies-judicial-immunity-to-west-virginia-judge-who-personally-searched-home-ordered-items-removed/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38133279">https://news.ycombinator.com/item?id=38133279</a></p>
<p>Points: 37</p>
<p># Comments: 6</p>

## Show HN: MicroLua – Lua for the RP2040 Microcontroller
 - [https://github.com/MicroLua/MicroLua](https://github.com/MicroLua/MicroLua)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T18:45:04+00:00

<p>MicroLua allows programming the RP2040 microcontroller in Lua. It packages the latest Lua interpreter with bindings for the Pico SDK and a cooperative threading library.<p>MicroLua is licensed under the MIT license.<p>I wanted to learn about Lua and about the RP2040 microcontroller. This is the result :)</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38133134">https://news.ycombinator.com/item?id=38133134</a></p>
<p>Points: 29</p>
<p># Comments: 1</p>

## 11% of the world’s billionaires have held or sought political office
 - [https://news.northwestern.edu/stories/2023/10/11-of-the-worlds-billionaires-have-held-or-sought-political-office](https://news.northwestern.edu/stories/2023/10/11-of-the-worlds-billionaires-have-held-or-sought-political-office)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T17:44:34+00:00

<p>Article URL: <a href="https://news.northwestern.edu/stories/2023/10/11-of-the-worlds-billionaires-have-held-or-sought-political-office/">https://news.northwestern.edu/stories/2023/10/11-of-the-worlds-billionaires-have-held-or-sought-political-office/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38132297">https://news.ycombinator.com/item?id=38132297</a></p>
<p>Points: 48</p>
<p># Comments: 20</p>

## My "retirement" project: Release 40 years worth of my "source code"
 - [https://dunfield.themindfactory.com/dnldsrc.htm](https://dunfield.themindfactory.com/dnldsrc.htm)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T17:26:16+00:00

<p>Article URL: <a href="https://dunfield.themindfactory.com/dnldsrc.htm">https://dunfield.themindfactory.com/dnldsrc.htm</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38132016">https://news.ycombinator.com/item?id=38132016</a></p>
<p>Points: 32</p>
<p># Comments: 0</p>

## Federal Reserve is threatening to sue Bitcoin Mag over parody product
 - [https://bitcoinmagazine.com/legal/federal-reserve-threatens-to-sue-bitcoin-magazine](https://bitcoinmagazine.com/legal/federal-reserve-threatens-to-sue-bitcoin-magazine)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T17:16:34+00:00

<p>Article URL: <a href="https://bitcoinmagazine.com/legal/federal-reserve-threatens-to-sue-bitcoin-magazine">https://bitcoinmagazine.com/legal/federal-reserve-threatens-to-sue-bitcoin-magazine</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38131848">https://news.ycombinator.com/item?id=38131848</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## Oxide Hiring Process
 - [https://rfd.shared.oxide.computer/rfd/0003](https://rfd.shared.oxide.computer/rfd/0003)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T17:14:58+00:00

<p>Article URL: <a href="https://rfd.shared.oxide.computer/rfd/0003">https://rfd.shared.oxide.computer/rfd/0003</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38131816">https://news.ycombinator.com/item?id=38131816</a></p>
<p>Points: 35</p>
<p># Comments: 25</p>

## DALL-E 3 Is So Good It's Stoking an Artist Revolt Against AI Scraping
 - [https://www.bloomberg.com/news/articles/2023-11-03/dall-e-3-is-so-good-it-s-stoking-an-artist-revolt-against-ai-scraping](https://www.bloomberg.com/news/articles/2023-11-03/dall-e-3-is-so-good-it-s-stoking-an-artist-revolt-against-ai-scraping)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T17:05:35+00:00

<p>Article URL: <a href="https://www.bloomberg.com/news/articles/2023-11-03/dall-e-3-is-so-good-it-s-stoking-an-artist-revolt-against-ai-scraping">https://www.bloomberg.com/news/articles/2023-11-03/dall-e-3-is-so-good-it-s-stoking-an-artist-revolt-against-ai-scraping</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38131674">https://news.ycombinator.com/item?id=38131674</a></p>
<p>Points: 26</p>
<p># Comments: 26</p>

## Nuclear Conversion for Starship
 - [http://toughsf.blogspot.com/2021/10/nuclear-conversion-for-starship.html](http://toughsf.blogspot.com/2021/10/nuclear-conversion-for-starship.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T16:52:28+00:00

<p>Article URL: <a href="http://toughsf.blogspot.com/2021/10/nuclear-conversion-for-starship.html">http://toughsf.blogspot.com/2021/10/nuclear-conversion-for-starship.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38131460">https://news.ycombinator.com/item?id=38131460</a></p>
<p>Points: 48</p>
<p># Comments: 38</p>

## Sudo-rs' first security audit
 - [https://ferrous-systems.com/blog/sudo-rs-audit](https://ferrous-systems.com/blog/sudo-rs-audit)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T16:51:46+00:00

<p>Article URL: <a href="https://ferrous-systems.com/blog/sudo-rs-audit/">https://ferrous-systems.com/blog/sudo-rs-audit/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38131442">https://news.ycombinator.com/item?id=38131442</a></p>
<p>Points: 26</p>
<p># Comments: 7</p>

## Sam Bankman-Fried Has a Savior Complex–and Maybe You Should Too (2022)
 - [https://web.archive.org/web/20221027180943/https://www.sequoiacap.com/article/sam-bankman-fried-spotlight](https://web.archive.org/web/20221027180943/https://www.sequoiacap.com/article/sam-bankman-fried-spotlight)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T16:25:12+00:00

<p>Article URL: <a href="https://web.archive.org/web/20221027180943/https://www.sequoiacap.com/article/sam-bankman-fried-spotlight/">https://web.archive.org/web/20221027180943/https://www.sequoiacap.com/article/sam-bankman-fried-spotlight/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38131007">https://news.ycombinator.com/item?id=38131007</a></p>
<p>Points: 34</p>
<p># Comments: 20</p>

## Okta hit by another breach, stealing employee data from 3rd-party vendor
 - [https://arstechnica.com/security/2023/11/okta-hit-by-another-breach-this-one-stealing-employee-data-from-3rd-party-vendor](https://arstechnica.com/security/2023/11/okta-hit-by-another-breach-this-one-stealing-employee-data-from-3rd-party-vendor)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T16:15:13+00:00

<p>Article URL: <a href="https://arstechnica.com/security/2023/11/okta-hit-by-another-breach-this-one-stealing-employee-data-from-3rd-party-vendor/">https://arstechnica.com/security/2023/11/okta-hit-by-another-breach-this-one-stealing-employee-data-from-3rd-party-vendor/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38130870">https://news.ycombinator.com/item?id=38130870</a></p>
<p>Points: 10</p>
<p># Comments: 0</p>

## Sam Bankman-Fried and the effective altruism delusion
 - [https://www.newstatesman.com/long-reads/2023/11/sam-bankman-fried-crypto-king-effective-altruism](https://www.newstatesman.com/long-reads/2023/11/sam-bankman-fried-crypto-king-effective-altruism)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T15:41:10+00:00

<p>Article URL: <a href="https://www.newstatesman.com/long-reads/2023/11/sam-bankman-fried-crypto-king-effective-altruism">https://www.newstatesman.com/long-reads/2023/11/sam-bankman-fried-crypto-king-effective-altruism</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38130458">https://news.ycombinator.com/item?id=38130458</a></p>
<p>Points: 52</p>
<p># Comments: 27</p>

## Diffractive Solar Sail
 - [https://en.wikipedia.org/wiki/Diffractive_solar_sail](https://en.wikipedia.org/wiki/Diffractive_solar_sail)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T15:39:38+00:00

<p>Article URL: <a href="https://en.wikipedia.org/wiki/Diffractive_solar_sail">https://en.wikipedia.org/wiki/Diffractive_solar_sail</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38130433">https://news.ycombinator.com/item?id=38130433</a></p>
<p>Points: 15</p>
<p># Comments: 1</p>

## YouTuber Kitboga trapped 200 scammers in an Impossible Maze [video]
 - [https://www.youtube.com/watch?v=dWzz3NeDz3E](https://www.youtube.com/watch?v=dWzz3NeDz3E)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T15:38:51+00:00

<p>Article URL: <a href="https://www.youtube.com/watch?v=dWzz3NeDz3E">https://www.youtube.com/watch?v=dWzz3NeDz3E</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38130418">https://news.ycombinator.com/item?id=38130418</a></p>
<p>Points: 88</p>
<p># Comments: 12</p>

## GPT-4 Update: 32K Context Window Now for All Users
 - [https://github.com/spdustin/ChatGPT-AutoExpert/blob/main/_system-prompts/all_tools.md](https://github.com/spdustin/ChatGPT-AutoExpert/blob/main/_system-prompts/all_tools.md)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T15:30:30+00:00

<p>Article URL: <a href="https://github.com/spdustin/ChatGPT-AutoExpert/blob/main/_system-prompts/all_tools.md">https://github.com/spdustin/ChatGPT-AutoExpert/blob/main/_system-prompts/all_tools.md</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38130309">https://news.ycombinator.com/item?id=38130309</a></p>
<p>Points: 46</p>
<p># Comments: 20</p>

## U.S. Consumers Spent More on Food in 2022 Than Ever Before (Inflation Adjusted)
 - [https://www.ers.usda.gov/amber-waves/2023/september/u-s-consumers-spent-more-on-food-in-2022-than-ever-before-even-after-adjusting-for-inflation](https://www.ers.usda.gov/amber-waves/2023/september/u-s-consumers-spent-more-on-food-in-2022-than-ever-before-even-after-adjusting-for-inflation)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T15:20:05+00:00

<p>Article URL: <a href="https://www.ers.usda.gov/amber-waves/2023/september/u-s-consumers-spent-more-on-food-in-2022-than-ever-before-even-after-adjusting-for-inflation/">https://www.ers.usda.gov/amber-waves/2023/september/u-s-consumers-spent-more-on-food-in-2022-than-ever-before-even-after-adjusting-for-inflation/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38130129">https://news.ycombinator.com/item?id=38130129</a></p>
<p>Points: 33</p>
<p># Comments: 30</p>

## Guide to Adopting AV1 Encoding
 - [https://bitmovin.com/av1/av1-encoding-guide](https://bitmovin.com/av1/av1-encoding-guide)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T15:17:45+00:00

<p>Article URL: <a href="https://bitmovin.com/av1/av1-encoding-guide/">https://bitmovin.com/av1/av1-encoding-guide/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38130089">https://news.ycombinator.com/item?id=38130089</a></p>
<p>Points: 28</p>
<p># Comments: 4</p>

## Jevons paradox
 - [https://en.wikipedia.org/wiki/Jevons_paradox](https://en.wikipedia.org/wiki/Jevons_paradox)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T15:16:01+00:00

<p>Article URL: <a href="https://en.wikipedia.org/wiki/Jevons_paradox">https://en.wikipedia.org/wiki/Jevons_paradox</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38130060">https://news.ycombinator.com/item?id=38130060</a></p>
<p>Points: 29</p>
<p># Comments: 12</p>

## Daily Telescope: Lucy finds not one but two diamonds in the sky
 - [https://arstechnica.com/space/2023/11/daily-telescope-lucy-finds-not-one-but-two-diamonds-in-the-sky](https://arstechnica.com/space/2023/11/daily-telescope-lucy-finds-not-one-but-two-diamonds-in-the-sky)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T14:55:48+00:00

<p>Article URL: <a href="https://arstechnica.com/space/2023/11/daily-telescope-lucy-finds-not-one-but-two-diamonds-in-the-sky/">https://arstechnica.com/space/2023/11/daily-telescope-lucy-finds-not-one-but-two-diamonds-in-the-sky/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38129754">https://news.ycombinator.com/item?id=38129754</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## Research: Every 5min increase in CI equals 1hr longer time-to-merge
 - [https://graphite.dev/blog/how-long-should-ci-take](https://graphite.dev/blog/how-long-should-ci-take)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T13:53:24+00:00

<p>Article URL: <a href="https://graphite.dev/blog/how-long-should-ci-take">https://graphite.dev/blog/how-long-should-ci-take</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38128775">https://news.ycombinator.com/item?id=38128775</a></p>
<p>Points: 18</p>
<p># Comments: 9</p>

## No dogs were harmed in the making of this app
 - [https://shmck.substack.com/p/no-dogs-were-harmed-in-the-making](https://shmck.substack.com/p/no-dogs-were-harmed-in-the-making)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T13:47:53+00:00

<p>Article URL: <a href="https://shmck.substack.com/p/no-dogs-were-harmed-in-the-making">https://shmck.substack.com/p/no-dogs-were-harmed-in-the-making</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38128699">https://news.ycombinator.com/item?id=38128699</a></p>
<p>Points: 51</p>
<p># Comments: 12</p>

## You can't have a functioning democracy when candidates aren't safe
 - [https://twitter.com/RobertKennedyJr/status/1720156852305191388](https://twitter.com/RobertKennedyJr/status/1720156852305191388)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T13:23:18+00:00

<p>Article URL: <a href="https://twitter.com/RobertKennedyJr/status/1720156852305191388">https://twitter.com/RobertKennedyJr/status/1720156852305191388</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38128351">https://news.ycombinator.com/item?id=38128351</a></p>
<p>Points: 10</p>
<p># Comments: 10</p>

## UMBC team makes first-ever observation of a virus attaching to another virus
 - [https://umbc.edu/stories/first-observed-virus-attaching-to-another](https://umbc.edu/stories/first-observed-virus-attaching-to-another)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T12:47:42+00:00

<p>Article URL: <a href="https://umbc.edu/stories/first-observed-virus-attaching-to-another/">https://umbc.edu/stories/first-observed-virus-attaching-to-another/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38127906">https://news.ycombinator.com/item?id=38127906</a></p>
<p>Points: 28</p>
<p># Comments: 1</p>

## Researcher Claims to Crack RSA-2048 with Quantum Computer
 - [https://www.bankinfosecurity.com/blogs/researcher-claims-to-crack-rsa-2048-quantum-computer-p-3536](https://www.bankinfosecurity.com/blogs/researcher-claims-to-crack-rsa-2048-quantum-computer-p-3536)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T12:24:03+00:00

<p>Article URL: <a href="https://www.bankinfosecurity.com/blogs/researcher-claims-to-crack-rsa-2048-quantum-computer-p-3536">https://www.bankinfosecurity.com/blogs/researcher-claims-to-crack-rsa-2048-quantum-computer-p-3536</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38127660">https://news.ycombinator.com/item?id=38127660</a></p>
<p>Points: 11</p>
<p># Comments: 1</p>

## The Anthropogenic Salt Cycle
 - [https://www.nature.com/articles/s43017-023-00485-y](https://www.nature.com/articles/s43017-023-00485-y)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T12:21:20+00:00

<p>Article URL: <a href="https://www.nature.com/articles/s43017-023-00485-y">https://www.nature.com/articles/s43017-023-00485-y</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38127629">https://news.ycombinator.com/item?id=38127629</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Rwanda joins Kenya to initiate visa-free travel for all Africans
 - [https://africa.businessinsider.com/local/leaders/from-barriers-to-unity-rwanda-joins-kenya-to-initiate-visa-free-travel-for-all/hhqe29q](https://africa.businessinsider.com/local/leaders/from-barriers-to-unity-rwanda-joins-kenya-to-initiate-visa-free-travel-for-all/hhqe29q)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T12:15:03+00:00

<p>Article URL: <a href="https://africa.businessinsider.com/local/leaders/from-barriers-to-unity-rwanda-joins-kenya-to-initiate-visa-free-travel-for-all/hhqe29q">https://africa.businessinsider.com/local/leaders/from-barriers-to-unity-rwanda-joins-kenya-to-initiate-visa-free-travel-for-all/hhqe29q</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38127560">https://news.ycombinator.com/item?id=38127560</a></p>
<p>Points: 65</p>
<p># Comments: 0</p>

## TrueVault (YC W14) Is Hiring Senior Software Engineers (US Remote)
 - [https://careers.truevault.com/jobs/9007-senior-software-engineer?promotion=254-trackable-share-link-yc-jobs-post-nov-2023](https://careers.truevault.com/jobs/9007-senior-software-engineer?promotion=254-trackable-share-link-yc-jobs-post-nov-2023)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T12:00:36+00:00

<p>Article URL: <a href="https://careers.truevault.com/jobs/9007-senior-software-engineer?promotion=254-trackable-share-link-yc-jobs-post-nov-2023">https://careers.truevault.com/jobs/9007-senior-software-engineer?promotion=254-trackable-share-link-yc-jobs-post-nov-2023</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38127422">https://news.ycombinator.com/item?id=38127422</a></p>
<p>Points: 0</p>
<p># Comments: 0</p>

## Extinct Species in Audubon's Birds of North America
 - [https://www.audubonart.com/extinct-species-in-audubons-birds-of-america](https://www.audubonart.com/extinct-species-in-audubons-birds-of-america)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T11:49:05+00:00

<p>Article URL: <a href="https://www.audubonart.com/extinct-species-in-audubons-birds-of-america/">https://www.audubonart.com/extinct-species-in-audubons-birds-of-america/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38127326">https://news.ycombinator.com/item?id=38127326</a></p>
<p>Points: 18</p>
<p># Comments: 3</p>

## Cloudflare outage – 24 hours now
 - [https://news.ycombinator.com/item?id=38112515](https://news.ycombinator.com/item?id=38112515)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T11:47:25+00:00

<p>Article URL: <a href="https://news.ycombinator.com/item?id=38112515">https://news.ycombinator.com/item?id=38112515</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38127313">https://news.ycombinator.com/item?id=38127313</a></p>
<p>Points: 32</p>
<p># Comments: 1</p>

## How do you get APILayer to stop billing you?
 - [https://news.ycombinator.com/item?id=38127264](https://news.ycombinator.com/item?id=38127264)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T11:41:38+00:00

<p>The support is terrible for their MarketStack API product - and several emails have had no joy.<p>I was about to leave a bad review on https://www.trustpilot.com/review/apilayer.com but seems many people are having similar issues.<p>Does anyone have any contacts there?<p>I just want to close the account and stop them billing me.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38127264">https://news.ycombinator.com/item?id=38127264</a></p>
<p>Points: 8</p>
<p># Comments: 2</p>

## 92% of young people would sacrifice other perks for a 4-day workweek
 - [https://www.cnbc.com/2023/11/01/what-young-people-would-give-up-for-a-4-day-workweek.html](https://www.cnbc.com/2023/11/01/what-young-people-would-give-up-for-a-4-day-workweek.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T11:33:47+00:00

<p>Article URL: <a href="https://www.cnbc.com/2023/11/01/what-young-people-would-give-up-for-a-4-day-workweek.html">https://www.cnbc.com/2023/11/01/what-young-people-would-give-up-for-a-4-day-workweek.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38127203">https://news.ycombinator.com/item?id=38127203</a></p>
<p>Points: 56</p>
<p># Comments: 14</p>

## HTTP 999 – the unofficial status code
 - [https://http.dev/999](https://http.dev/999)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T11:25:23+00:00

<p>Article URL: <a href="https://http.dev/999">https://http.dev/999</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38127131">https://news.ycombinator.com/item?id=38127131</a></p>
<p>Points: 35</p>
<p># Comments: 25</p>

## Proxima Fusion looks to take stellarators commercial
 - [https://www.theengineer.co.uk/content/news/proxima-fusion-looks-to-take-stellarators-commercial](https://www.theengineer.co.uk/content/news/proxima-fusion-looks-to-take-stellarators-commercial)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T11:14:48+00:00

<p>Article URL: <a href="https://www.theengineer.co.uk/content/news/proxima-fusion-looks-to-take-stellarators-commercial/">https://www.theengineer.co.uk/content/news/proxima-fusion-looks-to-take-stellarators-commercial/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38127053">https://news.ycombinator.com/item?id=38127053</a></p>
<p>Points: 6</p>
<p># Comments: 5</p>

## EU proposes to take control of web browser root certificates (open letter)
 - [https://eidas-open-letter.org](https://eidas-open-letter.org)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T11:08:42+00:00

<p>Article URL: <a href="https://eidas-open-letter.org/">https://eidas-open-letter.org/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38126997">https://news.ycombinator.com/item?id=38126997</a></p>
<p>Points: 35</p>
<p># Comments: 3</p>

## AMD Unveils Ryzen Mobile 7040U Series with Zen 4c Efficiency Cores
 - [https://www.anandtech.com/show/21111/amd-unveils-ryzen-7040u-series-with-zen-4c-smaller-cores-bigger-efficiency](https://www.anandtech.com/show/21111/amd-unveils-ryzen-7040u-series-with-zen-4c-smaller-cores-bigger-efficiency)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T10:52:51+00:00

<p>Article URL: <a href="https://www.anandtech.com/show/21111/amd-unveils-ryzen-7040u-series-with-zen-4c-smaller-cores-bigger-efficiency">https://www.anandtech.com/show/21111/amd-unveils-ryzen-7040u-series-with-zen-4c-smaller-cores-bigger-efficiency</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38126840">https://news.ycombinator.com/item?id=38126840</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## Apple: Android is a tracking device [pdf]
 - [https://www.justice.gov/d9/2023-11/417532.pdf](https://www.justice.gov/d9/2023-11/417532.pdf)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T10:49:23+00:00

<p>Article URL: <a href="https://www.justice.gov/d9/2023-11/417532.pdf">https://www.justice.gov/d9/2023-11/417532.pdf</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38126819">https://news.ycombinator.com/item?id=38126819</a></p>
<p>Points: 30</p>
<p># Comments: 10</p>

## Pix2tex: Using a ViT to convert images of equations into LaTeX code
 - [https://github.com/lukas-blecher/LaTeX-OCR](https://github.com/lukas-blecher/LaTeX-OCR)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T10:17:03+00:00

<p>Article URL: <a href="https://github.com/lukas-blecher/LaTeX-OCR">https://github.com/lukas-blecher/LaTeX-OCR</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38126623">https://news.ycombinator.com/item?id=38126623</a></p>
<p>Points: 6</p>
<p># Comments: 1</p>

## Why people in Google hate Go?
 - [https://news.ycombinator.com/item?id=38126571](https://news.ycombinator.com/item?id=38126571)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T10:07:23+00:00

<p>When you search "golang" on google for a long time, the question "Why people hate Go?" comes up at the top.<p>Now the blog post "A new way to bring garbage collected programming languages efficiently to WebAssembly" written by the team of V8 (JavaScript and WebAssembly engine) on the official website of Google has appeared.<p>https://v8.dev/blog/wasm-gc-porting<p>When I saw in the first paragraph of the blog that "we will get into the technical details of how GC languages such as Java, Kotlin, Dart, Python, and C# can be ported to Wasm" the question "Why people in Google hate Go?" arose</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38126571">https://news.ycombinator.com/item?id=38126571</a></p>
<p>Points: 3</p>
<p># Comments: 4</p>

## Sam Bankman-Fried and other FTX staff allegedly had 'Wirefraud' chat group
 - [https://www.theguardian.com/business/2022/dec/13/sam-bankman-fried-ftx-signal-wirefraud-chat-alameda](https://www.theguardian.com/business/2022/dec/13/sam-bankman-fried-ftx-signal-wirefraud-chat-alameda)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T09:10:37+00:00

<p>Article URL: <a href="https://www.theguardian.com/business/2022/dec/13/sam-bankman-fried-ftx-signal-wirefraud-chat-alameda">https://www.theguardian.com/business/2022/dec/13/sam-bankman-fried-ftx-signal-wirefraud-chat-alameda</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38126212">https://news.ycombinator.com/item?id=38126212</a></p>
<p>Points: 12</p>
<p># Comments: 2</p>

## Why You Should Write Your Own Static Site Generator
 - [https://arne.me/articles/write-your-own-ssg](https://arne.me/articles/write-your-own-ssg)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T09:10:33+00:00

<p>Article URL: <a href="https://arne.me/articles/write-your-own-ssg">https://arne.me/articles/write-your-own-ssg</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38126210">https://news.ycombinator.com/item?id=38126210</a></p>
<p>Points: 11</p>
<p># Comments: 3</p>

## Java JEP 461: Stream Gatherers
 - [https://openjdk.org/jeps/461](https://openjdk.org/jeps/461)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T08:59:38+00:00

<p>Article URL: <a href="https://openjdk.org/jeps/461">https://openjdk.org/jeps/461</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38126150">https://news.ycombinator.com/item?id=38126150</a></p>
<p>Points: 28</p>
<p># Comments: 13</p>

## Charm has raised $6M in funding
 - [https://charm.sh/blog/the-next-generation](https://charm.sh/blog/the-next-generation)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T08:46:30+00:00

<p>Article URL: <a href="https://charm.sh/blog/the-next-generation/">https://charm.sh/blog/the-next-generation/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38126060">https://news.ycombinator.com/item?id=38126060</a></p>
<p>Points: 24</p>
<p># Comments: 4</p>

## M3 Macs: there's more to performance than counting cores
 - [https://eclecticlight.co/2023/11/03/m3-macs-theres-more-to-performance-than-counting-cores](https://eclecticlight.co/2023/11/03/m3-macs-theres-more-to-performance-than-counting-cores)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T07:59:50+00:00

<p>Article URL: <a href="https://eclecticlight.co/2023/11/03/m3-macs-theres-more-to-performance-than-counting-cores/">https://eclecticlight.co/2023/11/03/m3-macs-theres-more-to-performance-than-counting-cores/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38125771">https://news.ycombinator.com/item?id=38125771</a></p>
<p>Points: 28</p>
<p># Comments: 16</p>

## Tiny device is sending updated iPhones into a never-ending DoS loop
 - [https://arstechnica.com/security/2023/11/flipper-zero-gadget-that-doses-iphones-takes-once-esoteric-attacks-mainstream](https://arstechnica.com/security/2023/11/flipper-zero-gadget-that-doses-iphones-takes-once-esoteric-attacks-mainstream)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T07:04:17+00:00

<p>Article URL: <a href="https://arstechnica.com/security/2023/11/flipper-zero-gadget-that-doses-iphones-takes-once-esoteric-attacks-mainstream/">https://arstechnica.com/security/2023/11/flipper-zero-gadget-that-doses-iphones-takes-once-esoteric-attacks-mainstream/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38125426">https://news.ycombinator.com/item?id=38125426</a></p>
<p>Points: 17</p>
<p># Comments: 3</p>

## Enable MTE on Pixel 8
 - [https://outflux.net/blog/archives/2023/10/26/enable-mte-on-pixel-8](https://outflux.net/blog/archives/2023/10/26/enable-mte-on-pixel-8)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T06:55:22+00:00

<p>Article URL: <a href="https://outflux.net/blog/archives/2023/10/26/enable-mte-on-pixel-8/">https://outflux.net/blog/archives/2023/10/26/enable-mte-on-pixel-8/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38125379">https://news.ycombinator.com/item?id=38125379</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## The Binder Linux driver is being rewritten in Rust
 - [https://lore.kernel.org/rust-for-linux/20231101-rust-binder-v1-0-08ba9197f637@google.com](https://lore.kernel.org/rust-for-linux/20231101-rust-binder-v1-0-08ba9197f637@google.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T06:53:26+00:00

<p>Article URL: <a href="https://lore.kernel.org/rust-for-linux/20231101-rust-binder-v1-0-08ba9197f637@google.com/">https://lore.kernel.org/rust-for-linux/20231101-rust-binder-v1-0-08ba9197f637@google.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38125367">https://news.ycombinator.com/item?id=38125367</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## Bring garbage collected programming languages efficiently to WebAssembly
 - [https://v8.dev/blog/wasm-gc-porting](https://v8.dev/blog/wasm-gc-porting)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T06:50:31+00:00

<p>Article URL: <a href="https://v8.dev/blog/wasm-gc-porting">https://v8.dev/blog/wasm-gc-porting</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38125348">https://news.ycombinator.com/item?id=38125348</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## Frink is a programming language designed to make physical calculations simple
 - [https://frinklang.org/#SampleCalculations](https://frinklang.org/#SampleCalculations)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T06:36:53+00:00

<p>Article URL: <a href="https://frinklang.org/#SampleCalculations">https://frinklang.org/#SampleCalculations</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38125256">https://news.ycombinator.com/item?id=38125256</a></p>
<p>Points: 18</p>
<p># Comments: 2</p>

## Frink is a programming language designed to make physical calculations simple
 - [https://frinklang.org](https://frinklang.org)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T06:36:53+00:00

<p>Article URL: <a href="https://frinklang.org/">https://frinklang.org/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38125256">https://news.ycombinator.com/item?id=38125256</a></p>
<p>Points: 24</p>
<p># Comments: 5</p>

## Looks like Google just abandoned its "Web Environment Integrity" API plans
 - [https://old.reddit.com/r/programming/comments/17me5dq/looks_like_google_has_just_abandoned_its_terrible](https://old.reddit.com/r/programming/comments/17me5dq/looks_like_google_has_just_abandoned_its_terrible)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T06:34:27+00:00

<p>Article URL: <a href="https://old.reddit.com/r/programming/comments/17me5dq/looks_like_google_has_just_abandoned_its_terrible/">https://old.reddit.com/r/programming/comments/17me5dq/looks_like_google_has_just_abandoned_its_terrible/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38125244">https://news.ycombinator.com/item?id=38125244</a></p>
<p>Points: 5</p>
<p># Comments: 1</p>

## Is a Poe.com subscription better than ChatGPT Plus?
 - [https://news.ycombinator.com/item?id=38125243](https://news.ycombinator.com/item?id=38125243)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T06:34:24+00:00

<p>For about $7 more than ChatGPT-Plus, Poe gives you GPT-4 plus other models like Claude-2-100k and StableDiffusionXL image creators plus the ability to make and monetise your own bots.<p>Seems a bit redundant to subscribe to ChatGPT-Plus for GPT-4 and extensions (which are poorly maintained, hard to use, and often broken) when Poe offers more.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38125243">https://news.ycombinator.com/item?id=38125243</a></p>
<p>Points: 8</p>
<p># Comments: 4</p>

## Microsoft Security Bulletin MS98-010 – Critical (1998)
 - [https://learn.microsoft.com/en-us/security-updates/securitybulletins/1998/ms98-010](https://learn.microsoft.com/en-us/security-updates/securitybulletins/1998/ms98-010)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T05:35:36+00:00

<p>Article URL: <a href="https://learn.microsoft.com/en-us/security-updates/securitybulletins/1998/ms98-010">https://learn.microsoft.com/en-us/security-updates/securitybulletins/1998/ms98-010</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38124937">https://news.ycombinator.com/item?id=38124937</a></p>
<p>Points: 9</p>
<p># Comments: 1</p>

## TIL: man {gittutorial,giteveryday,gitglossary,gitworkflows}
 - [https://news.ycombinator.com/item?id=38124845](https://news.ycombinator.com/item?id=38124845)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T05:21:35+00:00

<p>Today I discovered a set of wonderful and slightly hidden manuals on git:<p><pre><code>  man gittutorial
  man giteveryday
  man gitglossary
  man gitworkflow
</code></pre>
Actually they aren’t all that well hidden if an observant user just started poking at git:<p><pre><code>  $ man git
  
  GIT(1)
  
  ...
  
  
  DESCRIPTION
         Git is a fast, scalable, distributed revision control system with an unusually rich command set that provides both high-level operations and full access to internals.
  
         See gittutorial(7) to get started, then see giteveryday(7) for a useful minimum set of commands. The Git User’s Manual[1] has a more in-depth introduction.
  
  ...
  
  
  SEE ALSO
         gittutorial(7), gittutorial-2(7), giteveryday(7), gitcvs-migration(7), gitglossary(7), gitcore-tutorial(7), gitcli(7), The Git User’s Manual[1], gitworkflows(7)
  
  ...</code></pre></p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38124845">https://news.ycombi

## An Open Letter to the FreeBSD Foundation, Core Team, Committers, and Community
 - [https://docs.google.com/document/d/1h3UPx1MkMC-vg-kS7Di45xMG-UsEI7YU2MNVlRtYARM/edit](https://docs.google.com/document/d/1h3UPx1MkMC-vg-kS7Di45xMG-UsEI7YU2MNVlRtYARM/edit)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T04:26:51+00:00

<p>Article URL: <a href="https://docs.google.com/document/d/1h3UPx1MkMC-vg-kS7Di45xMG-UsEI7YU2MNVlRtYARM/edit">https://docs.google.com/document/d/1h3UPx1MkMC-vg-kS7Di45xMG-UsEI7YU2MNVlRtYARM/edit</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38124523">https://news.ycombinator.com/item?id=38124523</a></p>
<p>Points: 5</p>
<p># Comments: 2</p>

## Translations of Russ Cox's Thompson NFA C Program to Rust
 - [https://github.com/BurntSushi/rsc-regexp](https://github.com/BurntSushi/rsc-regexp)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T03:27:51+00:00

<p>Article URL: <a href="https://github.com/BurntSushi/rsc-regexp">https://github.com/BurntSushi/rsc-regexp</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38124114">https://news.ycombinator.com/item?id=38124114</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## Toyota cuts 2023 EV sales forecast by nearly 40%
 - [https://electrek.co/2023/11/01/toyota-drastically-cuts-ev-sales-forecast-amid-strategy-shift](https://electrek.co/2023/11/01/toyota-drastically-cuts-ev-sales-forecast-amid-strategy-shift)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T02:57:23+00:00

<p>Article URL: <a href="https://electrek.co/2023/11/01/toyota-drastically-cuts-ev-sales-forecast-amid-strategy-shift/">https://electrek.co/2023/11/01/toyota-drastically-cuts-ev-sales-forecast-amid-strategy-shift/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38123884">https://news.ycombinator.com/item?id=38123884</a></p>
<p>Points: 12</p>
<p># Comments: 4</p>

## Hearing 'bad grammar' results in physical signs of stress – new study reveals
 - [https://www.birmingham.ac.uk/news/2023/hearing-bad-grammar-results-in-physical-signs-of-stress-new-study-reveals](https://www.birmingham.ac.uk/news/2023/hearing-bad-grammar-results-in-physical-signs-of-stress-new-study-reveals)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T02:36:18+00:00

<p>Article URL: <a href="https://www.birmingham.ac.uk/news/2023/hearing-bad-grammar-results-in-physical-signs-of-stress-new-study-reveals">https://www.birmingham.ac.uk/news/2023/hearing-bad-grammar-results-in-physical-signs-of-stress-new-study-reveals</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38123744">https://news.ycombinator.com/item?id=38123744</a></p>
<p>Points: 25</p>
<p># Comments: 32</p>

## Sam Bankman-Fried: guilty on all charges
 - [https://newsletter.mollywhite.net/p/sam-bankman-fried-guilty-on-all-charges](https://newsletter.mollywhite.net/p/sam-bankman-fried-guilty-on-all-charges)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T02:36:08+00:00

<p>Article URL: <a href="https://newsletter.mollywhite.net/p/sam-bankman-fried-guilty-on-all-charges">https://newsletter.mollywhite.net/p/sam-bankman-fried-guilty-on-all-charges</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38123739">https://news.ycombinator.com/item?id=38123739</a></p>
<p>Points: 19</p>
<p># Comments: 5</p>

## Show HN: Internet Speed Test
 - [https://www.internetspeed.my](https://www.internetspeed.my)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T02:20:07+00:00

<p>Article URL: <a href="https://www.internetspeed.my">https://www.internetspeed.my</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38123595">https://news.ycombinator.com/item?id=38123595</a></p>
<p>Points: 19</p>
<p># Comments: 27</p>

## Email.radio – Free Email Domain for Licensed Ham Radio Operators
 - [https://email.radio](https://email.radio)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T02:10:55+00:00

<p>Article URL: <a href="https://email.radio/">https://email.radio/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38123526">https://news.ycombinator.com/item?id=38123526</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## If You Plant Milkweed, They Will Come
 - [https://www.nytimes.com/2023/10/25/realestate/gardening-milkweed-plants-butterflies.html](https://www.nytimes.com/2023/10/25/realestate/gardening-milkweed-plants-butterflies.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T00:21:08+00:00

<p>Article URL: <a href="https://www.nytimes.com/2023/10/25/realestate/gardening-milkweed-plants-butterflies.html">https://www.nytimes.com/2023/10/25/realestate/gardening-milkweed-plants-butterflies.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38122465">https://news.ycombinator.com/item?id=38122465</a></p>
<p>Points: 12</p>
<p># Comments: 5</p>

## Audacity 3.4 – New Musical Features
 - [https://www.audacityteam.org/blog/audacity-3-4](https://www.audacityteam.org/blog/audacity-3-4)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T00:14:59+00:00

<p>Article URL: <a href="https://www.audacityteam.org/blog/audacity-3-4/">https://www.audacityteam.org/blog/audacity-3-4/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38122396">https://news.ycombinator.com/item?id=38122396</a></p>
<p>Points: 11</p>
<p># Comments: 7</p>

## Curley vs. Electric Vehicle Co. (1902)
 - [https://cite.case.law/set-cookie/?next=%2Fnys%2F74%2F35%2F](https://cite.case.law/set-cookie/?next=%2Fnys%2F74%2F35%2F)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-11-03T00:03:00+00:00

<p>Article URL: <a href="https://cite.case.law/set-cookie/?next=%2Fnys%2F74%2F35%2F">https://cite.case.law/set-cookie/?next=%2Fnys%2F74%2F35%2F</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38122224">https://news.ycombinator.com/item?id=38122224</a></p>
<p>Points: 6</p>
<p># Comments: 2</p>

