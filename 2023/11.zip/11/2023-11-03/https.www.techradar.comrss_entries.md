# Source:Techradar, URL:https://www.techradar.com/rss, language:en-US

## Elon Musk says xAI is launching its first model and it could be a ChatGPT rival
 - [https://www.techradar.com/computing/artificial-intelligence/elon-musk-says-xai-is-launching-its-first-model-and-it-could-be-a-chatgpt-rival](https://www.techradar.com/computing/artificial-intelligence/elon-musk-says-xai-is-launching-its-first-model-and-it-could-be-a-chatgpt-rival)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T23:00:02+00:00

The company's first AI model will only be available to a select few and may be the start of even loftier goals.

## World of Warcraft's next expansion The War Within is coming in 2024
 - [https://www.techradar.com/gaming/pc-gaming/world-of-warcrafts-next-expansion-the-war-within-is-coming-in-2024](https://www.techradar.com/gaming/pc-gaming/world-of-warcrafts-next-expansion-the-war-within-is-coming-in-2024)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T22:18:56+00:00

World of Warcraft's new expansion is coming in 2024 and kicks off the multi-year Worldsoul Saga

## Hearthstone's Battlegrounds mode is getting a team vs team mode
 - [https://www.techradar.com/gaming/consoles-pc/hearthstones-battlegrounds-mode-is-getting-a-team-vs-team-mode](https://www.techradar.com/gaming/consoles-pc/hearthstones-battlegrounds-mode-is-getting-a-team-vs-team-mode)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T21:22:11+00:00

Hearthstone's Battlegrounds spin-off is now getting its own, team-focused, spin-off.

## Finally! This affordable, super fast external SSD is on the way after a 2-year wait — but you will still need to have a USB4 or Thunderbolt port to make the most out of it
 - [https://www.techradar.com/pro/finally-this-affordable-super-fast-external-ssd-is-on-the-way-after-a-2-year-wait-but-you-will-still-need-to-have-a-usb4-or-thunderbolt-port-to-make-the-most-out-of-it](https://www.techradar.com/pro/finally-this-affordable-super-fast-external-ssd-is-on-the-way-after-a-2-year-wait-but-you-will-still-need-to-have-a-usb4-or-thunderbolt-port-to-make-the-most-out-of-it)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T21:20:40+00:00

ADATA’s SE920 external SSD is a powerful piece of kit, albeit with some glaring limitations.

## Black Friday is three weeks away - here are the 71 best deals to shop right now
 - [https://www.techradar.com/seasonal-sales/black-friday-is-three-weeks-away-here-are-the-71-best-deals-to-shop-right-now](https://www.techradar.com/seasonal-sales/black-friday-is-three-weeks-away-here-are-the-71-best-deals-to-shop-right-now)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T21:00:12+00:00

While the Black Friday deals event is three weeks away, there are plenty of offers to shop right now, and I'm rounding up the 71 best.

## Blizzard announces not one but three new World of Warcraft expansions as it unveils The Worldsoul Sega
 - [https://www.techradar.com/gaming/pc-gaming/blizzard-announces-not-one-but-three-new-world-of-warcraft-expansions-as-it-unveils-the-worldsoul-sega](https://www.techradar.com/gaming/pc-gaming/blizzard-announces-not-one-but-three-new-world-of-warcraft-expansions-as-it-unveils-the-worldsoul-sega)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T20:05:22+00:00

There are three new expansions coming to World of Warcraft, starting with World of Warcraft The War Within

## Free to play Warcraft Rumble gets released live at Blizzcon 2023
 - [https://www.techradar.com/gaming/free-to-play-warcraft-rumble-gets-released-live-at-blizzcon-2023](https://www.techradar.com/gaming/free-to-play-warcraft-rumble-gets-released-live-at-blizzcon-2023)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T19:47:02+00:00

Warcraft spin-off Warcraft Rumble is now available for everyone after being released live on stage at Blizzcon 2023

## The Samsung Galaxy S24 Ultra could match the iPhone 15 Pro's titanium build
 - [https://www.techradar.com/phones/the-samsung-galaxy-s24-ultra-could-match-the-iphone-15-pros-titanium-build](https://www.techradar.com/phones/the-samsung-galaxy-s24-ultra-could-match-the-iphone-15-pros-titanium-build)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T19:11:41+00:00

Seemingly inspired by the iPhone 15 Pro, Samsung might use the new metal although it will cost them big to switch over.

## New expansion Diablo 4 Vessel of Hatred will bring a brand new class to the franchise
 - [https://www.techradar.com/gaming/consoles-pc/new-expansion-diablo-4-vessel-of-hatred-will-bring-a-brand-new-class-to-the-franchise](https://www.techradar.com/gaming/consoles-pc/new-expansion-diablo-4-vessel-of-hatred-will-bring-a-brand-new-class-to-the-franchise)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T19:00:57+00:00

Diablo 4 is getting a new expansion in 2024 focusing on the prime evil Mephisto and his impact on the world of Sanctuary

## Overwatch 2's newest hero, Mauga, could be exactly what fans want
 - [https://www.techradar.com/gaming/consoles-pc/overwatch-2s-newest-hero-mauga-could-be-exactly-what-fans-want](https://www.techradar.com/gaming/consoles-pc/overwatch-2s-newest-hero-mauga-could-be-exactly-what-fans-want)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T18:31:24+00:00

Overwatch 2's next hero Mauga will be playable over the weekend.

## Some early Tesla Model 3 Highland owners aren't very happy with Tesla Vision
 - [https://www.techradar.com/vehicle-tech/hybrid-electric-vehicles/early-tesla-model-3-highland-owners-arent-very-happy-with-tesla-vision](https://www.techradar.com/vehicle-tech/hybrid-electric-vehicles/early-tesla-model-3-highland-owners-arent-very-happy-with-tesla-vision)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T17:54:05+00:00

Deliveries of Tesla Model 3 Highland have begun in Europe, but some customers are already complaining about the Tesla Vision system.

## Microsoft drops Windows Maps, TV and Movies apps from new Windows 11 installs – here's what it means for users
 - [https://www.techradar.com/computing/windows/microsoft-drops-windows-maps-tv-and-movies-apps-from-new-windows-11-installs-heres-what-it-means-for-users](https://www.techradar.com/computing/windows/microsoft-drops-windows-maps-tv-and-movies-apps-from-new-windows-11-installs-heres-what-it-means-for-users)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T17:35:10+00:00

Microsoft's Windows 11 Build 25987 removes Windows Maps and Movies & TV apps, signaling a streamlined approach for the operating system's optimization.

## Cities: Skylines 2 hotfix addresses bugs, balances some in-game systems, and removes an "offensive" radio ad
 - [https://www.techradar.com/gaming/consoles-pc/cities-skylines-2-hotfix-addresses-bugs-balances-some-in-game-systems-and-removes-an-offensive-radio-ad](https://www.techradar.com/gaming/consoles-pc/cities-skylines-2-hotfix-addresses-bugs-balances-some-in-game-systems-and-removes-an-offensive-radio-ad)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T17:23:13+00:00

A new hotfix for Cities: Skylines 2 which sees a bunch of improvements and bug fixes.

## Apple could become a $100 billion software-and-services business in 2024 — more than Salesforce, SAP and Adobe combined
 - [https://www.techradar.com/pro/apple-could-become-a-dollar100-billion-software-and-services-business-in-2024-more-than-salesforce-sap-and-adobe-combined-revenues](https://www.techradar.com/pro/apple-could-become-a-dollar100-billion-software-and-services-business-in-2024-more-than-salesforce-sap-and-adobe-combined-revenues)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T17:04:30+00:00

SaaS is now the second biggest revenue generator for Apple, behind $200 billion iPhone business.

## Marvel's Echo TV show gets a new release date, brutal trailer, Daredevil cameo, and surprising R-rating
 - [https://www.techradar.com/streaming/disney-plus/marvels-echo-tv-show-gets-a-new-release-date-brutal-trailer-and-surprising-r-rating](https://www.techradar.com/streaming/disney-plus/marvels-echo-tv-show-gets-a-new-release-date-brutal-trailer-and-surprising-r-rating)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T16:44:40+00:00

Echo's standalone Disney Plus series will make Marvel history in early 2024 as the first R-rated MCU TV show.

## These are the 13 best early Black Friday deals I've found this week
 - [https://www.techradar.com/seasonal-sales/best-early-black-friday-deals-this-week-nov-3](https://www.techradar.com/seasonal-sales/best-early-black-friday-deals-this-week-nov-3)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T16:44:07+00:00

I've searched around and hand-picked the best early Black Friday deals available this week, including Echo Show 5, Ninja DZ071 Foodi air fryer, Apple Watch SE and more.

## BlackCat strikes again - and this time it's breached a healthcare giant
 - [https://www.techradar.com/pro/security/blackcat-strikes-again-and-this-time-its-breached-a-healthcare-giant](https://www.techradar.com/pro/security/blackcat-strikes-again-and-this-time-its-breached-a-healthcare-giant)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T16:00:34+00:00

Henry Schein is the latest victim of a ransomware attack, but it seems as if it paid its attackers.

## 7 new movies and TV shows to stream on Netflix, Prime Video, Disney Plus, and more this weekend (November 3)
 - [https://www.techradar.com/streaming/7-new-movies-and-tv-shows-to-stream-on-netflix-prime-video-disney-plus-and-more-this-weekend-november-3-2023](https://www.techradar.com/streaming/7-new-movies-and-tv-shows-to-stream-on-netflix-prime-video-disney-plus-and-more-this-weekend-november-3-2023)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T15:52:00+00:00

From star-studded murder mysteries to returning superhero shows, there’s plenty to watch this weekend.

## Xbox now features a full-screen Modern Warfare 3 ad on the startup screen sparking user criticism
 - [https://www.techradar.com/gaming/consoles-pc/xbox-now-features-a-full-screen-modern-warfare-3-ad-on-the-startup-screen-sparking-user-criticism](https://www.techradar.com/gaming/consoles-pc/xbox-now-features-a-full-screen-modern-warfare-3-ad-on-the-startup-screen-sparking-user-criticism)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T15:39:17+00:00

Xbox users are criticizing Microsoft for its new full-screen Call of Duty: Modern Warfare 3 advertisement on the startup screen.

## Super Mario Bros. Wonder speedrunner sets world record with bizarre out-of-bounds glitch
 - [https://www.techradar.com/gaming/nintendo-switch/super-mario-bros-wonder-speedrunner-sets-world-record-with-bizarre-out-of-bounds-glitch](https://www.techradar.com/gaming/nintendo-switch/super-mario-bros-wonder-speedrunner-sets-world-record-with-bizarre-out-of-bounds-glitch)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T15:38:11+00:00

An out-of-bounds glitch has been discovered in Super Mario Bros. Wonder which speedrunners are using to set huge new records.

## Cybersecurity is pivotal to a sustainable future for life insurers
 - [https://www.techradar.com/pro/cybersecurity-is-pivotal-to-a-sustainable-future-for-life-insurers](https://www.techradar.com/pro/cybersecurity-is-pivotal-to-a-sustainable-future-for-life-insurers)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T15:26:03+00:00

Data breaches. Incoming regulation. Incident disclosures. Why life insurers must prioritize cybersecurity.

## Cyberattack takes down one of the largest mortgage lenders in the US
 - [https://www.techradar.com/pro/security/cyberattack-takes-down-one-of-the-largest-mortgage-lenders-in-the-us](https://www.techradar.com/pro/security/cyberattack-takes-down-one-of-the-largest-mortgage-lenders-in-the-us)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T15:00:19+00:00

It's still not clear if this was a ransomware attack, but Mr. Cooper was forced to shut some services down.

## EA’s CEO thinks Microsoft’s acquisition of Activision is “a great thing” for the games industry
 - [https://www.techradar.com/gaming/eas-ceo-thinks-microsofts-acquisition-of-activision-is-a-great-thing-for-the-games-industry](https://www.techradar.com/gaming/eas-ceo-thinks-microsofts-acquisition-of-activision-is-a-great-thing-for-the-games-industry)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T14:50:38+00:00

The CEO of EA, Andrew Wilson, says Microsoft buying Activision is "a great thing" for the future of the games industry.

## Hate Copilot in Windows 11? Free privacy tools can now get rid of the AI
 - [https://www.techradar.com/computing/windows/hate-copilot-in-windows-11-free-privacy-tools-can-now-get-rid-of-the-ai](https://www.techradar.com/computing/windows/hate-copilot-in-windows-11-free-privacy-tools-can-now-get-rid-of-the-ai)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T14:14:55+00:00

Ready to hit the ejector seat button for Copilot? Two privacy-focused apps can now jettison the AI from your desktop.

## Business credentials are under constant threat from automated attacks, so make sure you protect them
 - [https://www.techradar.com/pro/security/business-credentials-are-under-constant-threat-from-automated-attacks](https://www.techradar.com/pro/security/business-credentials-are-under-constant-threat-from-automated-attacks)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T14:00:10+00:00

Businesses need to set up mitigations against malicious traffic or face the consequences, F5 Labs says.

## Lords of the Fallen patch features over 100 fixes, buffs bosses, and refines AI behavior
 - [https://www.techradar.com/gaming/consoles-pc/lords-of-the-fallen-patch-features-over-100-fixes-buffs-bosses-and-refines-ai-behavior](https://www.techradar.com/gaming/consoles-pc/lords-of-the-fallen-patch-features-over-100-fixes-buffs-bosses-and-refines-ai-behavior)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T13:48:48+00:00

Lords of the Fallen has received a new patch that features over 100 enhancements, fixes, and tweaks.

## Businesses are finding AI a challenge for data privacy
 - [https://www.techradar.com/pro/security/businesses-are-finding-ai-a-challenge-for-data-privacy](https://www.techradar.com/pro/security/businesses-are-finding-ai-a-challenge-for-data-privacy)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T13:30:57+00:00

Report finds IT leaders are making data privacy a top priority in light of AI implementations.

## Apple called Android a ‘massive tracking device’ before the iPhone’s privacy push
 - [https://www.techradar.com/phones/apple-called-android-a-massive-tracking-device-before-the-iphones-privacy-push](https://www.techradar.com/phones/apple-called-android-a-massive-tracking-device-before-the-iphones-privacy-push)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T13:27:00+00:00

Apple threw shade at Android over privacy, but in fairness, Cupertino does set a high standard to follow.

## This tiny hacking device is attacking iPhones – and there’s currently no fix
 - [https://www.techradar.com/phones/iphone/this-tiny-hacking-device-is-attacking-iphones-and-theres-currently-no-fix](https://www.techradar.com/phones/iphone/this-tiny-hacking-device-is-attacking-iphones-and-theres-currently-no-fix)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T13:04:56+00:00

The Flipper Zero hacking device can now really mess with iPhones and iPads.

## Ransomware attacks are devastating healthcare - and things are only getting worse
 - [https://www.techradar.com/pro/security/ransomware-attacks-are-devastating-healthcare-and-things-are-only-getting-worse](https://www.techradar.com/pro/security/ransomware-attacks-are-devastating-healthcare-and-things-are-only-getting-worse)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T13:00:16+00:00

Healthcare firms are losing the fight against ransomware as the numbers are getting worse by the year.

## Modern Warfare 3 is the game Sledgehammer has “always wanted to make”, creative director says
 - [https://www.techradar.com/gaming/consoles-pc/modern-warfare-3-is-the-game-sledgehammer-has-always-wanted-to-make-creative-director-says](https://www.techradar.com/gaming/consoles-pc/modern-warfare-3-is-the-game-sledgehammer-has-always-wanted-to-make-creative-director-says)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T12:37:58+00:00

Sledgehammer Games creative director Dave Swenson told TRG that Modern Warfare 3 is the "game we’ve always wanted to make.”

## A new ChromeOS tablet could finally be on the way from Lenovo
 - [https://www.techradar.com/computing/chromebooks/a-new-chromeos-tablet-could-finally-be-on-the-way-from-lenovo](https://www.techradar.com/computing/chromebooks/a-new-chromeos-tablet-could-finally-be-on-the-way-from-lenovo)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T12:32:05+00:00

There aren't many ChromeOS 2-in-1s around, but it looks as though Lenovo might be making another one.

## House of the Dragon season 2 and White Lotus season 3 get new dates, and it's mixed news
 - [https://www.techradar.com/streaming/hbo-max/house-of-the-dragon-season-2-and-white-lotus-season-3-get-new-dates-and-its-mixed-news](https://www.techradar.com/streaming/hbo-max/house-of-the-dragon-season-2-and-white-lotus-season-3-get-new-dates-and-its-mixed-news)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T12:24:19+00:00

And more big Max/HBO shows get a new schedule

## Spider-Man 2 patch brings back the Nelson and Murdock sign, leading to questions about why it was missing in the first place
 - [https://www.techradar.com/gaming/consoles-pc/spider-man-2-patch-brings-back-the-nelson-and-murdock-sign-leading-to-questions-about-why-it-was-missing-in-the-first-place](https://www.techradar.com/gaming/consoles-pc/spider-man-2-patch-brings-back-the-nelson-and-murdock-sign-leading-to-questions-about-why-it-was-missing-in-the-first-place)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T12:06:51+00:00

The latest Marvel's Spider-Man 2 patch has brought back the Nelson and Murdock sign.

## Invincible season 2 episode 1 post-credits scene explained: what happened to [SPOILER]?
 - [https://www.techradar.com/streaming/amazon-prime-video/invincible-season-2-episode-1-post-credits-scene-explained-what-happened-to-spoiler](https://www.techradar.com/streaming/amazon-prime-video/invincible-season-2-episode-1-post-credits-scene-explained-what-happened-to-spoiler)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T11:52:16+00:00

Here's how Invincible season 2 episode 1's post-credits scene sets up one of Mark Grayson's most iconic arch-nemeses.

## The top three cybersecurity threats you didn’t know to look out for
 - [https://www.techradar.com/pro/the-top-three-cybersecurity-threats-you-didnt-know-to-look-out-for](https://www.techradar.com/pro/the-top-three-cybersecurity-threats-you-didnt-know-to-look-out-for)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T11:46:57+00:00

LOL attacks go undetected, AI is developing, and Ransomware-as-a-Service is readily available; reassess your strategies.

## Activision blames zombies for the Call of Duty Modern Warfare 3 200GB install size
 - [https://www.techradar.com/gaming/consoles-pc/activision-blames-zombies-for-the-call-of-duty-modern-warfare-3-200gb-install-size](https://www.techradar.com/gaming/consoles-pc/activision-blames-zombies-for-the-call-of-duty-modern-warfare-3-200gb-install-size)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T11:40:51+00:00

Call of Duty Modern Warfare 3's 200GB install is thanks to an "increased amount of content."

## Bungie talks about its “path forward” for Destiny 2 after “one of the most difficult weeks in our studio’s history”
 - [https://www.techradar.com/gaming/consoles-pc/bungie-talks-about-its-path-forward-for-destiny-2-after-one-of-the-most-difficult-weeks-in-our-studios-history](https://www.techradar.com/gaming/consoles-pc/bungie-talks-about-its-path-forward-for-destiny-2-after-one-of-the-most-difficult-weeks-in-our-studios-history)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T11:39:07+00:00

The Destiny 2 dev team has outlined its plans for the future of the FPS following layoffs at Bungie, also acknowledging that "we have lost a lot of your trust."

## Dell launches new eye-friendly displays for hybrid workers
 - [https://www.techradar.com/pro/dell-launches-new-eye-friendly-displays-for-hybrid-workers](https://www.techradar.com/pro/dell-launches-new-eye-friendly-displays-for-hybrid-workers)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T11:37:00+00:00

Next-generation 24-, 27-, and 34-inch displays have been announced by Dell, including a couple of world-firsts.

## Latest rumor suggests Nvidia RTX 4080 Super graphics card might be another flop
 - [https://www.techradar.com/computing/gpu/latest-rumor-suggests-nvidia-rtx-4080-super-graphics-card-might-be-another-flop](https://www.techradar.com/computing/gpu/latest-rumor-suggests-nvidia-rtx-4080-super-graphics-card-might-be-another-flop)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T11:23:49+00:00

Nvidia’s rumored RTX 4070 Super refreshes could be more substantial upgrades than the 4080 Super.

## Tesla reveals more about how its Magic Dock charging system actually works
 - [https://www.techradar.com/vehicle-tech/hybrid-electric-vehicles/tesla-reveals-more-about-how-its-magic-dock-charging-system-actually-works](https://www.techradar.com/vehicle-tech/hybrid-electric-vehicles/tesla-reveals-more-about-how-its-magic-dock-charging-system-actually-works)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T11:20:20+00:00

More details surface of Tesla's Magic Dock charging system

## The Samsung Galaxy S24’s release date might have just leaked
 - [https://www.techradar.com/phones/samsung-galaxy-phones/the-samsung-galaxy-s24s-release-date-might-have-just-leaked](https://www.techradar.com/phones/samsung-galaxy-phones/the-samsung-galaxy-s24s-release-date-might-have-just-leaked)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T11:17:16+00:00

The Samsung Galaxy S24 could land on January 17 according to the latest leak, and come with lots of AI skills.

## Amazon Black Friday deals LIVE: today's best offers on TVs, Apple, headphones, and more
 - [https://www.techradar.com/news/live/early-amazon-black-friday-deals-11-3-23](https://www.techradar.com/news/live/early-amazon-black-friday-deals-11-3-23)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T10:45:53+00:00

I'm searching through all the early Black Friday deals at Amazon to bring you all the best offers I'd buy today.

## Apple slams Android as a "massive tracking device" in internal email
 - [https://www.techradar.com/pro/apple-slams-android-as-a-massive-tracking-device-in-internal-email](https://www.techradar.com/pro/apple-slams-android-as-a-massive-tracking-device-in-internal-email)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T10:45:51+00:00

Apple condemns Google and others in a testimony relating to the company’s search engine dominance.

## Loki season 2 episode 5 just made Marvel fans relive the MCU's most heart-breaking moment
 - [https://www.techradar.com/streaming/disney-plus/loki-season-2-episode-5-just-made-marvel-fans-relive-the-mcus-most-heart-breaking-moment](https://www.techradar.com/streaming/disney-plus/loki-season-2-episode-5-just-made-marvel-fans-relive-the-mcus-most-heart-breaking-moment)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T10:42:55+00:00

The fifth episode of Loki season 2 has emotional Marvel fans comparing it to the MCU's biggest bombshell.

## Payday 3's delayed first patch is finally here and adds "a massive amount of fixes"
 - [https://www.techradar.com/gaming/consoles-pc/payday-3s-delayed-first-patch-is-finally-here-and-adds-a-massive-amount-of-fixes](https://www.techradar.com/gaming/consoles-pc/payday-3s-delayed-first-patch-is-finally-here-and-adds-a-massive-amount-of-fixes)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T10:40:23+00:00

Starbreeze Studios has finally released the first major patch for Payday 3.

## Fortnite OG adds back Tilted Towers, shopping carts and more classic items today
 - [https://www.techradar.com/gaming/consoles-pc/fortnite-og-adds-back-tilted-towers-shopping-carts-and-more-classic-items-today](https://www.techradar.com/gaming/consoles-pc/fortnite-og-adds-back-tilted-towers-shopping-carts-and-more-classic-items-today)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T10:30:34+00:00

Fortnite's latest season brings the battle royale back to its past, starting with the return of Tilted Towers, Greasy Grove and Risky Reels.

## The Sims 4's "For Rent" expansion will add multi-family lots, eviction anxiety, and a new game world next month
 - [https://www.techradar.com/gaming/the-sims-4s-for-rent-expansion-will-add-multi-family-lots-eviction-anxiety-and-a-new-game-world-next-month](https://www.techradar.com/gaming/the-sims-4s-for-rent-expansion-will-add-multi-family-lots-eviction-anxiety-and-a-new-game-world-next-month)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T10:30:15+00:00

The Sims 4 is set to receive a new expansion next month and will replicate the reality of rental.

## Getting a new M3 Mac? Apple is already pushing out a macOS Sonoma update to optimize performance
 - [https://www.techradar.com/computing/software/getting-a-new-m3-mac-apple-is-already-pushing-out-a-macos-sonoma-update-to-optimize-performance](https://www.techradar.com/computing/software/getting-a-new-m3-mac-apple-is-already-pushing-out-a-macos-sonoma-update-to-optimize-performance)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T10:09:51+00:00

Owners of the latest M3 MacBooks and iMacs need to install an essential macOS Sonoma update for optimized performance and security.

## Play hundreds of games for just $0.99 with this early Black Friday deal
 - [https://www.techradar.com/gaming/play-hundreds-of-games-for-just-dollar099-with-this-early-black-friday-deal](https://www.techradar.com/gaming/play-hundreds-of-games-for-just-dollar099-with-this-early-black-friday-deal)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T10:08:41+00:00

EA has revealed a new limited time off that lets you buy a month of EA Play for just $0.99.

## Sony acquires deep learning company iSIZE - signaling a focus on cloud streaming improvements
 - [https://www.techradar.com/gaming/consoles-pc/sony-acquires-deep-learning-company-isize-signaling-a-focus-on-cloud-streaming-improvements](https://www.techradar.com/gaming/consoles-pc/sony-acquires-deep-learning-company-isize-signaling-a-focus-on-cloud-streaming-improvements)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T10:08:40+00:00

Sony has acquired iSIZE, a UK-based company that specializes in AI-powered streaming solutions.

## Microsoft is overhauling the cybersecurity of its cloud services with AI power
 - [https://www.techradar.com/pro/security/microsoft-is-overhauling-the-cybersecurity-of-its-cloud-services-with-ai-power](https://www.techradar.com/pro/security/microsoft-is-overhauling-the-cybersecurity-of-its-cloud-services-with-ai-power)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T09:55:11+00:00

Microsoft will build security into its products from the ground level, as well as improving accessibility with AI.

## Gen V season 1 ending explained: is [SPOILER] dead, post-credits scene, and your biggest questions answered
 - [https://www.techradar.com/streaming/amazon-prime-video/gen-v-season-1-ending-explained](https://www.techradar.com/streaming/amazon-prime-video/gen-v-season-1-ending-explained)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T07:05:30+00:00

You've got questions about Gen V's season 1 finale, and we're here to try and answer them.

## Garmin's Forerunner watches will tell you the best time to take a nap
 - [https://www.techradar.com/health-fitness/smartwatches/garmins-forerunner-watches-will-tell-you-the-best-time-to-take-a-nap](https://www.techradar.com/health-fitness/smartwatches/garmins-forerunner-watches-will-tell-you-the-best-time-to-take-a-nap)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T04:00:53+00:00

Garmin expands the Venu 3's nap tracking tool to the Forerunner series and certain models will receive Red Shift.

## Quordle today - hints and answers for Friday, November 3 (game #648)
 - [https://www.techradar.com/computing/websites-apps/quordle-today-answers-clues-3-november-2023](https://www.techradar.com/computing/websites-apps/quordle-today-answers-clues-3-november-2023)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-11-03T00:15:55+00:00

Looking for Quordle clues? We can help. Plus get the answers to Quordle today and past solutions.

