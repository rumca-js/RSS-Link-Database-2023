# Source:Epoch Times - World, URL:https://feed.theepochtimes.com/world/feed, language:en-US

## EU Calls on China to Release Artist Persecuted for Her Faith
 - [https://www.theepochtimes.com/falun-gong/eu-calls-on-china-to-release-artist-persecuted-for-her-faith-5521698](https://www.theepochtimes.com/falun-gong/eu-calls-on-china-to-release-artist-persecuted-for-her-faith-5521698)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-03T15:21:56+00:00

Falun Gong practitioner Xu Na in an undated photo. (The Epoch Times)

## Putin Pulls Russia Out of Longstanding Nuclear Test Ban Treaty
 - [https://www.theepochtimes.com/world/putin-pulls-russia-out-of-longstanding-nuclear-test-ban-treaty-5522460](https://www.theepochtimes.com/world/putin-pulls-russia-out-of-longstanding-nuclear-test-ban-treaty-5522460)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-03T15:01:14+00:00

Russian President Vladimir Putin chairs a meeting with members of the Russian government via teleconference in Moscow on March 10, 2022. (Mikhail Klimentyev/SPUTNIK/AFP via Getty Images)

## Japan PM Unveils $113 Billion Economic Package to Ease Inflation Pain
 - [https://www.theepochtimes.com/world/japan-pm-unveils-113-billion-economic-package-to-ease-inflation-pain-5522359](https://www.theepochtimes.com/world/japan-pm-unveils-113-billion-economic-package-to-ease-inflation-pain-5522359)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-03T14:08:12+00:00

Japan's Prime Minister Fumio Kishida speaks to reporters about ALPS-treated water from the Fukushima Daiichi Nuclear Power Plant at the prime minister's office on Aug. 24, 2023. (STR/JIJI Press/AFP via Getty Images)

## Blinken Urges Protections for Civilians in Gaza on Visit to Israel Amid Fears War Could Widen
 - [https://www.theepochtimes.com/world/blinken-urges-protections-for-civilians-in-gaza-on-visit-to-israel-amid-fears-war-could-widen-5522448](https://www.theepochtimes.com/world/blinken-urges-protections-for-civilians-in-gaza-on-visit-to-israel-amid-fears-war-could-widen-5522448)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-03T14:01:36+00:00

US Secretary of State Antony Blinken speaks during a press conference in Tel Aviv on Nov. 3, 2023. (Gil Cohen-Magen/AFP via Getty Images)

## LIVE 9:55 AM ET: Blinken Holds a Press Availability in Tel Aviv
 - [https://www.theepochtimes.com/epochtv/blinken-holds-a-press-availability-in-tel-aviv-5522433](https://www.theepochtimes.com/epochtv/blinken-holds-a-press-availability-in-tel-aviv-5522433)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-03T13:58:39+00:00

Secretary of State Antony Blinken looks on, as President Joe Biden (not pictured) speaks about the conflict in Israel, after Hamas launched its biggest attack in decades, while making a statement about the crisis, at the White House on Oct. 7, 2023. (Elizabeth Frantz/Reuters)

## Canada Adds Fewer Jobs Than Expected in October, Jobless Rate Rises
 - [https://www.theepochtimes.com/world/canada-adds-fewer-jobs-than-expected-in-october-jobless-rate-rises-5522432](https://www.theepochtimes.com/world/canada-adds-fewer-jobs-than-expected-in-october-jobless-rate-rises-5522432)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-03T13:49:06+00:00

A help wanted sign hangs in a bar window along Queen Street West in Toronto on June 10, 2022. (Reuters/Carlos Osorio)

## LIVE 9:45 AM ET: Live View Over Israel–Gaza Border From Israel (Nov. 3)
 - [https://www.theepochtimes.com/epochtv/live-view-over-israel-gaza-border-from-israel-nov-3-post-5522407](https://www.theepochtimes.com/epochtv/live-view-over-israel-gaza-border-from-israel-nov-3-post-5522407)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-03T13:32:54+00:00

Smoke rises over Gaza as seen from Israel's border with Gaza in southern Israel on Oct. 28, 2023. (Amir Cohen/Reuters)

## Judge in Freedom Convoy Trial Expected to Rule on Admissibility of Police Evidence
 - [https://www.theepochtimes.com/world/judge-in-freedom-convoy-trial-expected-to-rule-on-admissibility-of-police-evidence-5522420](https://www.theepochtimes.com/world/judge-in-freedom-convoy-trial-expected-to-rule-on-admissibility-of-police-evidence-5522420)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-03T13:14:23+00:00

Chris Barber arrives for his trial at the courthouse in Ottawa, on Sept. 19, 2023. (The Canadian Press/Justin Tang)

## Finance Ministers, Freeland Set to Meet to Discuss Alberta CPP Exit Proposal
 - [https://www.theepochtimes.com/world/finance-ministers-freeland-set-to-meet-to-discuss-alberta-cpp-exit-proposal-5522303](https://www.theepochtimes.com/world/finance-ministers-freeland-set-to-meet-to-discuss-alberta-cpp-exit-proposal-5522303)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-03T12:58:44+00:00

Finance Minister Chrystia Freeland holds a press conference in Ottawa, on Oct. 31, 2023. (The Canadian Press/Sean Kilpatrick)

## US, Allies Assessing Future of Gaza Strip After Hamas Is Destroyed: Blinken
 - [https://www.theepochtimes.com/us/us-allies-assessing-future-of-gaza-strip-after-hamas-is-destroyed-blinken-5522316](https://www.theepochtimes.com/us/us-allies-assessing-future-of-gaza-strip-after-hamas-is-destroyed-blinken-5522316)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-03T11:46:17+00:00

Secretary of State Antony Blinken testifies during a Senate Appropriations Committee hearing on Capitol Hill in Washington on Oct. 31, 2023. (Drew Angerer/Getty Images)

## Migrant Caravan Swells to ‘Over 7,000 People’ En Route to US Border, Says Organizer
 - [https://www.theepochtimes.com/us/migrant-caravan-swells-to-over-7000-people-en-route-to-us-border-says-organizer-5522370](https://www.theepochtimes.com/us/migrant-caravan-swells-to-over-7000-people-en-route-to-us-border-says-organizer-5522370)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-03T11:27:13+00:00

Migrants from Central and South America take part in a caravan attempting to reach the Mexico-US border, in Tapachula, Chiapas state, southern Mexico, on April 23, 2023. (Stringer/AFP via Getty Images)

## Hamas Attacks on Israel Only the Start of Iran’s Onslaught on West, Says Middle East Expert
 - [https://www.theepochtimes.com/world/hamas-attacks-on-israel-only-the-start-of-irans-onslaught-on-west-says-middle-east-expert-5521781](https://www.theepochtimes.com/world/hamas-attacks-on-israel-only-the-start-of-irans-onslaught-on-west-says-middle-east-expert-5521781)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-03T11:17:44+00:00

Catherine Perez-Shakdam speaks to NTD's "British Thought Leaders" programme. (NTD)

## 6 Things We’ve Learned From the Cricket World Cup
 - [https://www.theepochtimes.com/sports/6-things-weve-learned-from-the-cricket-world-cup-5522307](https://www.theepochtimes.com/sports/6-things-weve-learned-from-the-cricket-world-cup-5522307)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-03T11:11:45+00:00

Angelo Matthews of Sri Lanka is bowled by Mohammed Shami of India during the ICC Men's Cricket World Cup 2023 at Wankhede Stadium in Mumbai, India on Nov. 2, 2023. (Surjeet Yadav/Getty Images)

## Hydroxychloroquine Associated With Lower COVID-19 Mortality: Study
 - [https://www.theepochtimes.com/health/hydroxychloroquine-associated-with-lower-covid-19-mortality-study-5521868](https://www.theepochtimes.com/health/hydroxychloroquine-associated-with-lower-covid-19-mortality-study-5521868)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-03T10:45:47+00:00

A pharmacy technician pours out hydroxychloroquine pills at Rock Canyon Pharmacy in Provo, Utah in a file photograph. (George Frey/AFP via Getty Images)

## Author: Working-Class Fathers Kept From Seeing Their Children by ‘Gender Vigilantism’
 - [https://www.theepochtimes.com/world/author-working-class-fathers-kept-from-seeing-their-children-by-gender-vigilantism-5521735](https://www.theepochtimes.com/world/author-working-class-fathers-kept-from-seeing-their-children-by-gender-vigilantism-5521735)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-03T10:44:41+00:00

Vincent McGovern speaks to NTD's "British Thought Leaders" programme. (NTD)

## Incredibly Rare First English Astronomy Book, Published 467 Years Ago, Sells for Thousands
 - [https://www.theepochtimes.com/bright/incredibly-rare-first-english-astronomy-book-published-467-years-ago-sells-for-thousands-5520112](https://www.theepochtimes.com/bright/incredibly-rare-first-english-astronomy-book-published-467-years-ago-sells-for-thousands-5520112)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-03T10:15:19+00:00

(SWNS)

## NZ’s Special Votes Deliver 2 Less Seats to National Party, Winston Peters Now Kingmaker
 - [https://www.theepochtimes.com/world/nzs-special-votes-deliver-2-less-seats-to-national-party-winston-peters-now-kingmaker-5522267](https://www.theepochtimes.com/world/nzs-special-votes-deliver-2-less-seats-to-national-party-winston-peters-now-kingmaker-5522267)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-03T05:37:59+00:00

A voter casts a special vote during election day at Johnsonville School on Oct. 14, 2023 in Wellington, New Zealand. Hagen Hopkins/Getty Images)

## The Prime Minister Must Be Clear Eyed About Beijing’s Intentions
 - [https://www.theepochtimes.com/opinion/the-prime-minister-must-be-clear-eyed-about-beijings-intentions-5522302](https://www.theepochtimes.com/opinion/the-prime-minister-must-be-clear-eyed-about-beijings-intentions-5522302)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-03T04:45:47+00:00

Chinese Leader Xi Jinping attends the opening session of the National People's Congress at The Great Hall of People in Beijing, China on March 5, 2017. (Lintao Zhang/Getty Images)

## Nearly 80 Americans Have Departed Gaza, US Says
 - [https://www.theepochtimes.com/world/nearly-80-americans-have-departed-gaza-us-says-5522007](https://www.theepochtimes.com/world/nearly-80-americans-have-departed-gaza-us-says-5522007)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-03T03:59:55+00:00

Palestinians gather at the site of Israeli strikes on houses in Bureij in the central Gaza Strip on Nov. 2, 2023. (Mohammed Fayq Abu Mostafa/Reuters)

## Spain’s Crown Princess Leonor Turns 18 and Is Feted as Future Queen at Swearing-In Ceremony
 - [https://www.theepochtimes.com/world/spains-crown-princess-leonor-turns-18-and-is-feted-as-future-queen-at-swearing-in-ceremony-5520331](https://www.theepochtimes.com/world/spains-crown-princess-leonor-turns-18-and-is-feted-as-future-queen-at-swearing-in-ceremony-5520331)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-03T03:41:33+00:00

Princess Leonor looks a her father, the Spanish King Felipe VI, as they attend a military parade after swearing allegiance to the Constitution during a gala event that makes her eligible to be queen one day, in Madrid on Oct. 31 2023. (Manu Fernandez/AP Photo)

## Regulator Tackles Online Abuse in Sports
 - [https://www.theepochtimes.com/world/regulator-tackles-online-abuse-in-sports-5521707](https://www.theepochtimes.com/world/regulator-tackles-online-abuse-in-sports-5521707)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-03T03:27:31+00:00

Sean O'Dea of Australia (red) competes against Jiuzhen Yao of China in wrestling on day five of the Australian Youth Olympic Festival at Sydney Olympic Park Sports Halls in Sydney, Australia, on Jan. 20, 2013. (Mark Nolan/Getty Images)

## Fukushima Nuclear Plant Starts 3rd Release of Treated Radioactive Wastewater Into the Sea
 - [https://www.theepochtimes.com/world/fukushima-nuclear-plant-starts-3rd-release-of-treated-radioactive-wastewater-into-the-sea-5521809](https://www.theepochtimes.com/world/fukushima-nuclear-plant-starts-3rd-release-of-treated-radioactive-wastewater-into-the-sea-5521809)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-03T03:15:14+00:00

The Fukushima Daiichi nuclear power plant in Fukushima, northern Japan, on Aug. 24, 2023. (Kyodo News via AP)

## Prime Minister Albanese Switches Tack, Says Cost-of-Living Now Number One Priority
 - [https://www.theepochtimes.com/world/prime-minister-albanese-switches-tack-says-cost-of-living-now-number-one-priority-5522254](https://www.theepochtimes.com/world/prime-minister-albanese-switches-tack-says-cost-of-living-now-number-one-priority-5522254)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-11-03T02:21:04+00:00

Australian Prime Minister Anthony Albanese reacts during Question Time at Parliament House in Canberra, Australia, on March 30, 2023. (Martin Ollman/Getty Images)

