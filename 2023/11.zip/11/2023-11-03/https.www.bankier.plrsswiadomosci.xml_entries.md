# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Niemiecki minister finansów kwestionuje odejście od węgla do 2030 r.
 - [https://www.bankier.pl/wiadomosc/Niemiecki-minister-finansow-kwestionuje-odejscie-od-wegla-w-2030-r-8640290.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Niemiecki-minister-finansow-kwestionuje-odejscie-od-wegla-w-2030-r-8640290.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T18:52:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/0/5f1f284ca7f371-948-567-0-12-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />"Dopóki nie będzie jasne, że energia jest dostępna i przystępna cenowo, powinniśmy przestać marzyć o wycofaniu energii węglowej w 2030 r." - powiedział minister finansów Niemiec i lider liberalnej partii FDP Christian Lindner gazecie "Koelner Stadt-Anzeiger". Minister zakwestionował tym samym cel rządu, w którym zasiada.</p>

## Wybory w Mołdawii. Kandydaci chcieli przekupić głosujących m.in. workami ziemniaków
 - [https://www.bankier.pl/wiadomosc/Wybory-w-Moldawii-Kandydaci-chcieli-przekupic-glosujacych-m-in-workami-ziemniakow-8640244.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wybory-w-Moldawii-Kandydaci-chcieli-przekupic-glosujacych-m-in-workami-ziemniakow-8640244.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T16:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/3/8f06d0059c19d4-948-568-779-0-3708-2225.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Organizacja prawników Promo-Lex z Mołdawii potwierdziła, że kilku kandydatów w niedzielnych wyborach samorządowych w tym kraju dopuściło się działań korupcyjnych w zamian za poparcie w głosowaniu, m.in. poprzez obdarowywanie wyborców produktami spożywczymi.</p>

## Pentagon ogłosił nowy pakiet uzbrojenia dla Ukrainy. Przekracza 400 mln dolarów
 - [https://www.bankier.pl/wiadomosc/Pentagon-oglosil-nowy-pakiet-uzbrojenia-dla-Ukrainy-Przekracza-400-mln-dolarow-8640240.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Pentagon-oglosil-nowy-pakiet-uzbrojenia-dla-Ukrainy-Przekracza-400-mln-dolarow-8640240.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T16:41:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/f/68c4abeb29f1a6-948-568-0-80-2000-1199.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Pentagon ogłosił w piątek nowy, już 50. pakiet uzbrojenia dla Ukrainy, zawierający dodatkową amunicję do systemów obrony powietrznej NASAMS, a także kierowane laserem rakiety do zwalczania dronów. Łączna wartość obiecanej broni to 425 mln dolarów.</p>

## Stan kryzysowy w Toskanii. Kilka prowincji walczy z powodzią
 - [https://www.bankier.pl/wiadomosc/Stan-kryzysowy-w-Toskanii-Kilka-prowincji-walczy-z-powodzia-8640234.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Stan-kryzysowy-w-Toskanii-Kilka-prowincji-walczy-z-powodzia-8640234.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T16:36:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/1/0333d3f5812673-948-568-30-285-2970-1781.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rząd Włoch wprowadził w piątek stan kryzysowy w kilku rejonach w Toskanii z powodu powodzi, w której zginęło 6 osób. Rozporządzenie dotyczy prowincji Florencja, Piza, Pistoia, Livorno i Prato, gdzie zanotowano największe szkody. Nad prawie całym krajem przechodzą gwałtowne burze i ulewy wraz z porywistym wiatrem.</p>

## Z Wrocławia do Seulu. To pierwsze transkontynentalne połączenie
 - [https://www.bankier.pl/wiadomosc/Z-Wroclawia-do-Seulu-To-pierwsze-transkontynentalne-polaczenie-8640226.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Z-Wroclawia-do-Seulu-To-pierwsze-transkontynentalne-polaczenie-8640226.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T16:29:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/5/6e62c47103814d-948-568-37-217-2962-1777.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Pierwszy Boeing 787-8 Dreamliner wystartował w piątek z wrocławskiego lotniska w jedenastogodzinny lot do Seulu. To pierwsze transkontynentalne i bezpośrednie połączenie obsługiwane przez Port Lotniczy Wrocław.</p>

## Dobrze przyjęte plany i wyniki Dino. WIG20 rośnie od czterech tygodni
 - [https://www.bankier.pl/wiadomosc/Dobrze-przyjete-plany-i-wyniki-Dino-WIG20-rosnie-od-czterech-tygodni-8640214.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Dobrze-przyjete-plany-i-wyniki-Dino-WIG20-rosnie-od-czterech-tygodni-8640214.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T16:22:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/8/20ec54012a8c87-945-560-0-0-2048-1228.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Koniec tygodnia przyniósł kontynuację dobrego sentymentu na rynkach akcji, z którego korzystały indeksy na GPW. Najważniejsze z nich notują już czwarty z rzędu tydzień wzrostów.</p>

## Przywódca Hezbollahu groził USA i Izraelowi. "Wszystkie opcje są dla nas otwarte"
 - [https://www.bankier.pl/wiadomosc/Przywodca-Hezbollahu-grozil-USA-i-Izraelowi-Wszystkie-opcje-sa-dla-nas-otwarte-8640187.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Przywodca-Hezbollahu-grozil-USA-i-Izraelowi-Wszystkie-opcje-sa-dla-nas-otwarte-8640187.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T16:09:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/3/720ef227288d93-948-568-19-254-3891-2334.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W pierwszym wystąpieniu od 7 października, kiedy Hamas zaatakował Izrael, Hasan Nasrallah - szef Hezbollahu, radykalnego szyickiego ugrupowania libańskiego oświadczył w  piątek, że za napaścią stali wyłącznie Palestyńczycy, zaś Hezbollah "przystąpił do walki 8 października". Groził Izraelowi i USA, ale nie zapowiedział włączenia się jego organizacji do wojny. Oświadczył jednak, że szerszy konflikt na Bliskim Wschodzie jest "realną możliwością".</p>

## Powrót Burgera Drwala. McDonald's szokuje ceną za kultowego burgera
 - [https://www.bankier.pl/wiadomosc/Powrot-Burgera-Drwala-McDonald-s-szokuje-cena-za-kultowego-burgera-8640148.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Powrot-Burgera-Drwala-McDonald-s-szokuje-cena-za-kultowego-burgera-8640148.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T15:26:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/8/fb456d040dc223-948-567-0-25-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Dla niektórych osób Burger Drwala jest symbolem okresu jesienno-zimowego. Jest to na tyle popularna pozycja, że często trzeba odstać swoje w kolejce, aby ją zamówić. Dla zwolenników tej kanapki nie mamy dobrych wiadomości - McDonald's w tym roku wprowadził podwyżki.</p>

## Urzędniczki przyznawały mieszkania komunalne za łapówki. Jest wyrok sądu
 - [https://www.bankier.pl/wiadomosc/Urzedniczki-przyznawaly-mieszkania-komunalne-za-lapowki-Jest-wyrok-sadu-8640147.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Urzedniczki-przyznawaly-mieszkania-komunalne-za-lapowki-Jest-wyrok-sadu-8640147.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T15:23:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/3/ca47f68174a0e3-948-568-0-124-1989-1193.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />8 lat i 5,5 roku bezwzględnego więzienia dla dwóch byłych urzędniczek gdańskiego magistratu, które za łapówki przyznawały mieszkania komunalne – taki wyrok zapadł w piątek wobec głównych oskarżonych w procesie w sprawie korupcji podczas przyznawania lokali komunalnych w Gdańsku. Wyrok jest nieprawomocny.</p>

## Netanjahu: Nie będzie zawieszenia broni bez zwolnienia zakładników
 - [https://www.bankier.pl/wiadomosc/Netanjahu-Nie-bedzie-zawieszenia-broni-bez-zwolnienia-zakladnikow-8640123.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Netanjahu-Nie-bedzie-zawieszenia-broni-bez-zwolnienia-zakladnikow-8640123.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T14:48:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/6/3b649826cc0edf-948-568-0-0-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Izrael nie zgodzi się na tymczasowe zawieszenie broni z Hamasem, dopóki nie zostanie zwolnionych ponad 240 zakładników, pojmanych przez to ugrupowanie podczas ataku 7 października – oznajmił w piątek premier Izraela Benjamin Netanjahu.</p>

## Dino chce stopniowo budować kompetencje w obszarze e-commerce
 - [https://www.bankier.pl/wiadomosc/Dino-chce-stopniowo-budowac-kompetencje-w-obszarze-e-commerce-8640073.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Dino-chce-stopniowo-budowac-kompetencje-w-obszarze-e-commerce-8640073.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T13:46:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/c/46b87dcc7d7a98-948-568-0-79-1978-1186.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Grupa Dino, która chce kupić drogerię internetową eZebra, zamierza stopniowo budować kompetencje w obszarze e-commerce - poinformował Michał Krauze, członek zarządu i dyrektor finansowy Dino.</p>

## TikTok od 7 października usunął 24 mln kont. Powodem potencjalne dezinformacje
 - [https://www.bankier.pl/wiadomosc/TikTok-od-7-pazdziernika-usunal-24-mln-kont-Powodem-potencjalne-dezinformacje-8640069.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/TikTok-od-7-pazdziernika-usunal-24-mln-kont-Powodem-potencjalne-dezinformacje-8640069.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T13:41:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/0/fc08bffd9a44ab-948-568-0-81-2507-1504.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Od wybuchu wojny Izraela z Hamasem popularna aplikacja do tworzenia krótkich filmów TikTok usunęła 24 miliony fałszywych kont i ponad pół miliona komentarzy botów do treści pod hasztagami związanymi z konfliktem - poinformowała firma na swojej stronie internetowej.</p>

## Tyle gospodarstwa domowe zapłacą za prąd w 2024 bez zamrożonych cen
 - [https://www.bankier.pl/wiadomosc/Tyle-gospodarstwa-domowe-zaplaca-za-prad-w-2024-bez-zamrozonych-cen-8640044.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tyle-gospodarstwa-domowe-zaplaca-za-prad-w-2024-bez-zamrozonych-cen-8640044.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T13:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/9/a466dc8ec986f3-948-568-11-125-4563-2738.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Bez zamrożenia cen w 2024 r. gospodarstwa domowe zużywające do 2000 kWh zapłacą za energię o 68 proc. więcej, czyli dodatkowo 100 zł miesięcznie - wynika raportu Forum Energii.  Analitycy think tanku wyliczyli, że  przy częściowym zamrożeniu cen i bonie energetycznym podwyżki wyniosą ok. 30 proc.</p>

## Trwa batalia sądowa ws. respiratorów. Dojdzie do zaskarżenia umorzenia śledztwa?
 - [https://www.bankier.pl/wiadomosc/Trwa-batalia-sadowa-ws-respiratorow-Dojdzie-do-zaskarzenia-umorzenia-sledztwa-8640027.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Trwa-batalia-sadowa-ws-respiratorow-Dojdzie-do-zaskarzenia-umorzenia-sledztwa-8640027.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T12:43:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/0/e0a2f8cd25f663-948-568-51-0-1776-1065.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Warszawski sąd okręgowy postanowił w piątek zwrócić prokuraturze sprawę śledztwa dot. zakupu respiratorów przez resort zdrowia na początku pandemii. Śledczy muszą prawidłowo dostarczyć postanowienie o umorzeniu tego postępowania posłowi KO Michałowi Szczerbie. Umożliwi to merytoryczne zaskarżenie decyzji o zamknięciu sprawy.</p>

## Rosja chce zdestabilizować Mołdawię. Pompuje tam miliony euro
 - [https://www.bankier.pl/wiadomosc/Rosja-chce-zdestabilizowac-Moldawie-Pompuje-tam-miliony-euro-8640026.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rosja-chce-zdestabilizowac-Moldawie-Pompuje-tam-miliony-euro-8640026.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T12:41:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/6/6d7eb9330b93e5-948-568-0-15-2000-1199.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Od ubiegłego roku Rosja prowadzi zintensyfikowaną kampanię hybrydową w celu destabilizacji Mołdawii, obecnie próbuje wpłynąć na wybory samorządowe – powiedział szef SIS, mołdawskiej Służby Bezpieczeństwa i Wywiadu. Moskwa miała wydzielić na ten cel ponad 1 miliard mołdawskich lei (ok. 52 mln euro).</p>

## Prezes Budimeksu: 2024 r. może być trudny dla branży budowlanej
 - [https://www.bankier.pl/wiadomosc/2024-r-moze-byc-trudny-dla-branzy-budowlanej-a-tempo-ogloszen-przetargow-spowolnic-prezes-Budimeksu-wywiad-8640019.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/2024-r-moze-byc-trudny-dla-branzy-budowlanej-a-tempo-ogloszen-przetargow-spowolnic-prezes-Budimeksu-wywiad-8640019.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T12:32:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/7/7451c4a5daf04c-948-568-0-1248-3543-2126.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rok 2024 może być trudny dla branży budowlanej oraz możemy spodziewać się spowolnienia w ogłaszaniu nowych postępowań przetargowych. W długim terminie branża ma jednak dobre perspektywy – ocenił prezes Budimeksu Artur Popko. Grupa analizuje akwizycje w obszarze zielonej energii oraz inwestycje z zakresu przetwarzania odpadów.</p>

## Słabsze dane z amerykańskiego rynku pracy. Na Wall Street się ucieszą?
 - [https://www.bankier.pl/wiadomosc/Amerykanski-rynek-pracy-pazdziernik-2023-8639983.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Amerykanski-rynek-pracy-pazdziernik-2023-8639983.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T12:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/1/6e38f26d65cd11-948-568-0-290-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wzrost bezrobocia i wyraźnie wolniejszy przyrost
zatrudnienia powinny definitywnie zdjąć z agendy kwestię podwyżek stóp procentowych,
co ucieszyłoby inwestorów z Wall Street.</p>

## Nowy rząd chce zamrożonych cen gazu i prądu w 2024 r. Co z zerowym VAT na żywność?
 - [https://www.bankier.pl/wiadomosc/Nowy-rzad-chce-zamrozonych-cen-gazu-i-pradu-w-2024-r-Co-z-zerowym-VAT-na-zywnosc-8640016.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nowy-rzad-chce-zamrozonych-cen-gazu-i-pradu-w-2024-r-Co-z-zerowym-VAT-na-zywnosc-8640016.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T12:29:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/3/b83e20de079cdc-948-568-0-10-1440-863.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Będziemy dążyć do tego, by w 2024 r. ceny gazu i energii elektrycznej dla gospodarstw domowych i samorządów były zamrożone na poziomie zbliżonym do tego roku - powiedział w piątek w studiu PAP Andrzej Domański (KO). Wskazał, że ewentualne przedłużenie zerowego VAT na żywność będzie przedmiotem ustaleń.</p>

## Oprawy oświetleniowe pod lupą. W 18 na 20 wykryto niezgodności
 - [https://www.bankier.pl/wiadomosc/Oprawy-oswietleniowe-pod-lupa-W-18-na-20-wykryto-niezgodnosci-8640006.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Oprawy-oswietleniowe-pod-lupa-W-18-na-20-wykryto-niezgodnosci-8640006.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T12:17:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/5/4a522265570ea7-948-568-7-7-992-595.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W 18 na 20 skontrolowanych opraw oświetleniowych Inspekcja Handlowa stwierdziła niezgodności formalne lub konstrukcyjne – podał w piątek UOKiK. Za wprowadzenie do obrotu oprawy oświetleniowej niezgodnej z wymaganiami grozi kara do 100 tys. zł.
</p>

## Strajk przewoźników na granicy z Ukrainą. Ta partia wspiera protesty
 - [https://www.bankier.pl/wiadomosc/Strajk-przewoznikow-na-granicy-z-Ukraina-Ta-partia-wspiera-protesty-8639991.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Strajk-przewoznikow-na-granicy-z-Ukraina-Ta-partia-wspiera-protesty-8639991.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T12:07:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/1/ac400efeaf5c5f-948-568-22-15-2977-1786.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Będziemy wspierać protesty polskich przewoźników 6 listopada na granicy z Ukrainą, w związku z niespełnieniem oczekiwań branży – poinformował w piątek lider Konfederacji Krzysztof Bosak.</p>

## Holandia dostarczy Ukrainie amunicję o wartości pół miliarda euro
 - [https://www.bankier.pl/wiadomosc/Holandia-dostarczy-Ukrainie-amunicje-o-wartosci-pol-miliarda-euro-8639972.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Holandia-dostarczy-Ukrainie-amunicje-o-wartosci-pol-miliarda-euro-8639972.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T11:47:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/a/a65227800da35b-948-568-0-62-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Holandia dostarczy Ukrainie amunicję o wartości ponad 500 mln euro - poinformowała w piątek holenderska minister obrony Kajsa Ollongren.</p>

## Ceny węgla energetycznego w górę
 - [https://www.bankier.pl/wiadomosc/Ceny-wegla-energetycznego-w-gore-8639955.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ceny-wegla-energetycznego-w-gore-8639955.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T11:34:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/c/fb188879e974b6-948-568-0-230-3543-2125.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ceny węgla energetycznego wzrosły we wrześniu o 5,4 proc. mdm, a dla rynku ciepła wzrosły o 12,9 proc. - wynika z analizy indeksów cenowych, tworzonych wspólnie przez Agencję Rozwoju Przemysłu i Towarową Giełdę Energii.</p>

## Citi Handlowy oferuje 990 zł bonusu. Jak odebrać pieniądze? Podpowiadamy
 - [https://www.bankier.pl/wiadomosc/Citi-Handlowy-oferuje-990-zl-bonusu-Jak-odebrac-pieniadze-8639885.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Citi-Handlowy-oferuje-990-zl-bonusu-Jak-odebrac-pieniadze-8639885.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T11:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/c/58b7f94e7aad50-867-520-92-70-867-520.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Citi Handlowy promuje swoją kartę kredytową Citi Simplicity. Tym razem proponuje klientom bonus w postaci 990 zł. W ramach cyklu „Prześwietlamy promocje” przyglądamy się warunkom, jakie stawia nowym użytkownikom, i sprawdzamy, jak uzyskać premię.</p>

## Tym będą żyły rynki: tydzień niemiecki
 - [https://www.bankier.pl/wiadomosc/Tym-beda-zyly-rynki-tydzien-niemiecki-8639901.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tym-beda-zyly-rynki-tydzien-niemiecki-8639901.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T11:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/a/549c067be04138-948-568-97-37-2602-1561.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Pierwszy pełny tydzień listopada będzie obfitował w dane
makroekonomiczne z Niemiec oraz raporty kwartale wielkich niemieckich
korporacji.</p>

## Drastyczne podwyżki cen paliw. Definitywny koniec wyborczej promocji na stacjach
 - [https://www.bankier.pl/wiadomosc/Ceny-paliw-w-Polsce-3-listopad-2023-Ile-kosztuje-benzyna-autogaz-i-olej-napedowy-8639930.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ceny-paliw-w-Polsce-3-listopad-2023-Ile-kosztuje-benzyna-autogaz-i-olej-napedowy-8639930.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T10:56:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/6/4e5cf4b9e0d273-948-568-0-221-3847-2308.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przełom października i listopada przyniósł drastyczne,
kilkudziesięciogroszowe podwyżki cen benzyn i oleju napędowego</p>

## Spektakularna przecena kursu studia przed premierą gry. Akcje tańsze niż w debiucie
 - [https://www.bankier.pl/wiadomosc/Spektakularna-przecena-kursu-studia-przed-premiera-gry-Akcje-Starward-Industries-tansze-niz-w-debiucie-8639892.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Spektakularna-przecena-kursu-studia-przed-premiera-gry-Akcje-Starward-Industries-tansze-niz-w-debiucie-8639892.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T10:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/8/dab6501e1c8347-948-568-0-11-1500-899.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Notowania Starward Industries zostały w piątek sprowadzone
poniżej poziomu ceny z ostatniej emisji akcji przed debiutem, która jednocześnie
była jej kursem odniesienia w czasie pierwszej giełdowej sesji na NewConnect. Mnożą
się wątpliwości co do sukcesu sprzedażowego gry „The Invincible” po pierwszych
mieszanych recenzjach portali branżowych.</p>

## Odwołana wycieczka do Izraela? Ostatnie dni na wniosek o zwrot opłat
 - [https://www.bankier.pl/wiadomosc/Odwolana-wycieczka-do-Izraela-Ostatnie-dni-na-wniosek-o-zwrot-oplat-8639920.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Odwolana-wycieczka-do-Izraela-Ostatnie-dni-na-wniosek-o-zwrot-oplat-8639920.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T10:46:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/4/59bcd2f00998a2-948-568-237-0-4221-2533.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Tylko do 5 listopada 2023 r. włącznie podróżni i przedsiębiorcy mogą składać wnioski o zwrot wpłat za niezrealizowane wycieczki do Izraela. Również do 5 listopada należy poprawić błędy w już złożonych wnioskach – poinformował PAP Ubezpieczeniowy Fundusz Gwarancyjny.</p>

## Polska w czołówce krajów UE z najniższym bezrobociem
 - [https://www.bankier.pl/wiadomosc/Polska-w-czolowce-krajow-UE-z-najnizszym-bezrobociem-8639913.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polska-w-czolowce-krajow-UE-z-najnizszym-bezrobociem-8639913.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T10:37:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/e/414a08a8c3961e-948-568-0-40-2000-1199.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Polska należała do krajów o najniższym wskaźniku bezrobocia w UE we wrześniu; wyniosło ono 2,8 proc. - podał w piątek Europejski Urząd Statystyczny (Eurostat). Jedynie w Czechach współczynnik ten był nieco niższy - 2,7 proc., a równie niskie bezrobocie co w Polsce odnotowała tylko Malta.</p>

## Gwiazdy TVP z wysoką pensją nawet rok po zwolnieniu? Walczą o miękkie lądowanie
 - [https://www.bankier.pl/wiadomosc/Gwiazdy-TVP-z-wysoka-pensja-nawet-rok-po-zwolnieniu-Walcza-o-miekkie-ladowanie-8639886.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Gwiazdy-TVP-z-wysoka-pensja-nawet-rok-po-zwolnieniu-Walcza-o-miekkie-ladowanie-8639886.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T10:35:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/1/2b39e224e4880b-948-568-33-0-4398-2639.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Główni propagandyści TVP szykują sobie miękkie lądowanie po tym, jak stracą pracę, gdy zmieni się rząd i władze TVP - donosi serwis Press.pl.</p>

## Za tyle żyli Polacy w 2022 roku. Poniżej średniej w Unii Europejskiej
 - [https://www.bankier.pl/wiadomosc/Dochod-rozporzadzalny-na-mieszkanca-w-Polsce-w-2022-ponizej-sredniej-w-UE-8639899.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Dochod-rozporzadzalny-na-mieszkanca-w-Polsce-w-2022-ponizej-sredniej-w-UE-8639899.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T10:20:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/c/f1c95820b677fa-948-568-0-48-1772-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Dochód rozporządzalny na mieszkańca w Polsce w 2022 poniżej średniej w UE - podał Eurostat.</p>

## Spółka CPK zakłada, że może otrzymać decyzję lokalizacyjną dla lotniska w I kw. 2024 roku
 - [https://www.bankier.pl/wiadomosc/Spolka-CPK-zaklada-ze-moze-otrzymac-decyzje-lokalizacyjna-dla-lotniska-w-I-kw-2024-roku-8639883.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Spolka-CPK-zaklada-ze-moze-otrzymac-decyzje-lokalizacyjna-dla-lotniska-w-I-kw-2024-roku-8639883.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T10:03:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/b/4d512431a410ac-948-568-20-105-1980-1187.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W naszym harmonogramie zakładamy, że jest możliwość pozyskania decyzji lokalizacyjnej dla lotniska CPK w pierwszym kwartale 2024 r. - przekazał w piątek rzecznik spółki Konrad Majszyk. Dodał, że uzyskanie decyzji pozwoli złożyć wniosek o pozwolenie na jego budowę.</p>

## Sztuczna inteligencja potrafi kłamać i łamać prawo na giełdzie
 - [https://www.bankier.pl/wiadomosc/Sztuczna-inteligencja-na-gieldzie-wykorzystuje-insider-trading-i-oszukuje-8639868.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sztuczna-inteligencja-na-gieldzie-wykorzystuje-insider-trading-i-oszukuje-8639868.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T09:34:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/e/9bc89287572ef3-948-568-390-0-3333-2000.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Badacze sztucznej inteligencji twierdzą, że jej algorytmy są zdolne do przeprowadzania nielegalnych transakcji na giełdzie i ukrywania tego faktu.</p>

## Orkan Ciaran. Szkody we Francji wynoszą od 375 do 480 mln euro
 - [https://www.bankier.pl/wiadomosc/Orkan-Ciaran-Szkody-we-Francji-wynosza-od-375-do-480-mln-euro-8639867.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Orkan-Ciaran-Szkody-we-Francji-wynosza-od-375-do-480-mln-euro-8639867.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T09:28:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/c/cf0c656109490f-948-568-0-30-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Szacunkowe szkody wyrządzone przez orkan Ciaran we Francji wynoszą od 375 do 480 mln euro – oceniają firmy ubezpieczeniowe na bazie modeli statystycznych, lustrując zniszczone budynki i przygniecione przez drzewa samochody.</p>

## UOKiK ukarał firmę za ryzykowne inwestycje w quady
 - [https://www.bankier.pl/wiadomosc/UOKiK-ukaral-firme-za-ryzykowne-inwestycje-w-quady-8639855.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/UOKiK-ukaral-firme-za-ryzykowne-inwestycje-w-quady-8639855.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T09:07:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/e/2e6186727e3837-948-568-23-69-4584-2750.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Na firmę Jakub Leśniewski Total Finance, oferującą inwestycje w pojazdy off-roadowe, nałożono karę w łącznej wysokości ponad 56,2 tys. zł  - poinformował w piątek UOKiK. Według urzędu przedsiębiorca naruszał zbiorowe interesy konsumentów.</p>

## Koszty przedłużonych wakacji kredytowych dla banków mogą wynieść ponad 8 mld złotych
 - [https://www.bankier.pl/wiadomosc/Koszty-przedluzonych-wakacji-kredytowych-dla-bankow-moga-wyniesc-ponad-8-mld-zlotych-8639851.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Koszty-przedluzonych-wakacji-kredytowych-dla-bankow-moga-wyniesc-ponad-8-mld-zlotych-8639851.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T09:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/f/efd6bf5f90b126-948-568-0-57-1772-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Koszty przedłużonych wakacji kredytowych dla banków w formule zaproponowanej przez rząd wynieść mogą w 2024 roku 8,06 mld zł - podano w ocenie skutków regulacji projektu przygotowanego przez MRiT.</p>

## Kurs euro trzyma się mocno. Frank w trendzie spadkowym
 - [https://www.bankier.pl/wiadomosc/Kurs-euro-trzyma-sie-mocno-Frank-w-trendzie-spadkowym-8639847.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kurs-euro-trzyma-sie-mocno-Frank-w-trendzie-spadkowym-8639847.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T08:51:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/6/76c8f8dd2ad1a1-948-568-0-218-3500-2099.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Polski złoty pozostaje stosunkowo odporny na zawirowania na
rynkach światowych. Kurs euro utrzymuje się blisko poziomu 4,45 zł. Za to najniżej
od połowy sierpnia znalazły się notowania franka szwajcarskiego.</p>

## Kolejna firma meblarska będzie zwalniać. To część programu oszczędnościowego
 - [https://www.bankier.pl/wiadomosc/Forte-przeprowadzi-zwolnienia-grupowe-i-rozwiaze-umowy-z-maks-230-pracownikami-8639833.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Forte-przeprowadzi-zwolnienia-grupowe-i-rozwiaze-umowy-z-maks-230-pracownikami-8639833.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T08:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/2/decd6d519f7a63-817-490-45-0-817-490.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Fabryka Mebli Forte podjęła decyzję o przeprowadzeniu zwolnień grupowych i rozpoczęciu rozmów z przedstawicielami związków zawodowych. Zamiarem jest rozwiązanie umów o pracę z nie więcej niż 230 pracownikami, co stanowi około 10 proc. wszystkich zatrudnionych w spółce - poinformował spółka w komunikacie.</p>

## Buda: Pieniędzy na "Bezpieczny kredyt" wystarczy do momentu wprowadzenia kredytu 0 proc.
 - [https://www.bankier.pl/wiadomosc/Buda-Pieniedzy-na-Bezpieczny-kredyt-wystarczy-do-momentu-wprowadzenia-kredytu-0-proc-8639824.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Buda-Pieniedzy-na-Bezpieczny-kredyt-wystarczy-do-momentu-wprowadzenia-kredytu-0-proc-8639824.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T08:19:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/5/e596d333de52a1-948-568-0-270-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Jeżeli założy się, że kredyt 0 proc. proponowany 
przez KO miałby wejść w życie od 1 marca 2024r., to środków na 
"Bezpieczny kredyt 2 proc." wystarczy do końca lutego - ocenił minister 
rozwoju i technologii Waldemar Buda w TVP1. Obecnie wykorzystana jest 
około połowa środków na ten cel - dodał.</p>

## Inflacja w Turcji przestała przyspieszać, ale sytuacja nadal jest dramatyczna
 - [https://www.bankier.pl/wiadomosc/Inflacja-w-Turcji-pazdziernik-2023-8639791.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Inflacja-w-Turcji-pazdziernik-2023-8639791.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T07:45:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/3/e4cc1f5d1c9731-948-568-30-277-2862-1717.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Jeśli wierzyć danym Tureckiego Instytutu Statystycznego, to
w październiku inflacja CPI była nieznacznie niższa niż we wrześniu</p>

## Król krypotowalut uznany za winnego. "To jedno z największych oszustw finansowych w historii USA"
 - [https://www.bankier.pl/wiadomosc/Krol-krypotowalut-Sam-Bankman-Fried-uznany-za-winnego-oszustwa-FTX-8639779.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Krol-krypotowalut-Sam-Bankman-Fried-uznany-za-winnego-oszustwa-FTX-8639779.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T07:25:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/1/5f4e52ba42462f-948-568-0-0-3024-1814.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Po trwającym miesiąc procesie przed sądem w Nowym Jorku Sam Bankman-Fried, określany jako król kryptowalut, został uznany za winnego oszustwa i defraudacji pieniędzy. Jury przekazało werdykt zaledwie po czterech i pół godziny od rozpoczęcia obrad. </p>

## Pierwsza kobieta dowódcą amerykańskiej marynarki wojennej
 - [https://www.bankier.pl/wiadomosc/Lisa-Franchetti-pierwsza-kobieta-dowodca-amerykanskiej-marynarki-wojennej-8639767.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Lisa-Franchetti-pierwsza-kobieta-dowodca-amerykanskiej-marynarki-wojennej-8639767.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T06:16:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/a/1e582329899111-948-568-0-69-3999-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Senat USA zatwierdził nominację adm. Lisy Franchetti na Szefa Operacji Morskich, najwyższego rangą oficera w amerykańskiej marynarce wojennej. Jest ona pierwszą kobietą na tym stanowisku i pierwszą kobietą w Kolegium Połączonych Szefów Sztabów, skupiającym dowódców każdego rodzaju sił zbrojnych.</p>

## Plac Trzech Krzyży się zazieleni. Koszt jednego drzewa to prawie 14 tys. złotych
 - [https://www.bankier.pl/wiadomosc/Plac-Trzech-Krzyzy-sie-zazieleni-Koszt-jednego-drzewa-to-prawie-14-tys-zlotych-8639765.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Plac-Trzech-Krzyzy-sie-zazieleni-Koszt-jednego-drzewa-to-prawie-14-tys-zlotych-8639765.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T06:10:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/7/6840720d5f62d1-948-568-0-140-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Na placu Trzech Krzyży pracownicy firmy, która wygrała przetarg, sadzą 24 duże drzewa. To lipy i głogi. Koszt jednego drzewa to prawie 14 tys. zł.</p>

## Gdzie są specjaliści IT ze Wschodu, którym Polska wydała wizy? Z radaru zniknęło 80 tys. cudzoziemców
 - [https://www.bankier.pl/wiadomosc/Gdzie-sa-specjalisci-IT-ze-Wschodu-ktorym-Polska-wydala-wizy-Z-radaru-zniknelo-80-tys-cudzoziemcow-8639749.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Gdzie-sa-specjalisci-IT-ze-Wschodu-ktorym-Polska-wydala-wizy-Z-radaru-zniknelo-80-tys-cudzoziemcow-8639749.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T05:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/9/003a26463e9ed2-948-568-0-210-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Choć nasz kraj wydał ponad 90 tys. wiz dla specjalistów IT ze Wschodu, do Polski przyjechał tylko co siódmy zaproszony cudzoziemiec; nikt nie wie, co się dzieje z pozostałymi - informuje piątkowa "Rzeczpospolita".</p>

## URE: rachunki za prąd mogą mocno wzrosnąć w 2024 roku bez rządowych osłon
 - [https://www.bankier.pl/wiadomosc/URE-rachunki-za-prad-moga-mocno-wzrosnac-w-2024-roku-bez-rzadowych-oslon-8639747.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/URE-rachunki-za-prad-moga-mocno-wzrosnac-w-2024-roku-bez-rzadowych-oslon-8639747.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T05:47:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/9/a466dc8ec986f3-948-568-11-125-4563-2738.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Spółki energetyczne złożyły już wnioski taryfowe na sprzedaż energii elektrycznej do prezesa Urzędu Regulacji Energetyki - pisze piątkowa "Rzeczpospolita". Prognozy URE wskazują, że bez mechanizmów osłonowych wartość rachunku za prąd może w 2024 roku wzrosnąć aż o 60–70 proc. - dodano.</p>

## Podwyżki w budżetówce, 800+, ale bez liberalizacji aborcji. Umowa koalicyjna w toku
 - [https://www.bankier.pl/wiadomosc/Podwyzki-w-budzetowce-800-ale-bez-liberalizacji-aborcji-Umowa-koalicyjna-w-toku-8639743.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Podwyzki-w-budzetowce-800-ale-bez-liberalizacji-aborcji-Umowa-koalicyjna-w-toku-8639743.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T05:43:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/1/ccc02f862ce27e-948-568-0-0-2000-1199.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Umowa koalicyjna z gwarancją podwyżek w budżetówce, in vitro i 800+, ale bez wątku liberalizacji aborcji - to dotychczasowe ustalenia negocjatorów zwycięskich partii opozycyjnych - pisze piątkowa "Gazeta Wyborcza".</p>

## Polacy nie są zadowoleni z pracy policji
 - [https://www.bankier.pl/wiadomosc/Polacy-nie-sa-zadowoleni-z-pracy-policji-8639740.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polacy-nie-sa-zadowoleni-z-pracy-policji-8639740.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T05:39:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/6/25d22e0eb9fb6b-948-568-0-31-2508-1504.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />38 proc. badanych źle oceniło pracę policji, dobrze 30 proc., a neutralne zdanie w tej sprawie miało 29 proc. respondentów - wynika z sondażu Instytutu Badań Pollster dla "Super Expresu".</p>

## Do biura marsz! Co na to pracodawcy i ich podwładni?
 - [https://www.bankier.pl/wiadomosc/Do-biura-marsz-Co-na-to-pracodawcy-i-ich-podwladni-8639659.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Do-biura-marsz-Co-na-to-pracodawcy-i-ich-podwladni-8639659.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/3/2da04ebc7a4dad-948-568-0-174-2380-1428.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Choć
większość pracowników niewątpliwie chwali sobie pracę zdalną, to coraz częściej
słychać, że pracodawcom zależy na ich powrocie do biur. Sprawdziliśmy, czy tak
jest w rzeczywistości. </p>

## Kolejki do lekarzy w Polsce coraz dłuższe. Wypadamy blado na tle innych krajów regionu
 - [https://www.bankier.pl/wiadomosc/Kolejki-do-lekarzy-w-Polsce-coraz-dluzsze-Wypadamy-blado-na-tle-innych-krajow-regionu-8639120.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kolejki-do-lekarzy-w-Polsce-coraz-dluzsze-Wypadamy-blado-na-tle-innych-krajow-regionu-8639120.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/c/e35848d6dce822-948-568-0-149-3138-1882.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Według raportów Watch Health Care w ostatnich kilku latach czas oczekiwania na wizytę u specjalisty w Polsce wydłużył się o prawie dwa miesiące. Średnio co czwarty Polak deklaruje niezaspokojone potrzeby w...</p>

## Podatki nowej władzy: ile zapłacimy za obietnice wyborcze i kto na nich zyska, o ile głęboka dziura budżetowa na to pozwoli
 - [https://www.bankier.pl/wiadomosc/Podatki-nowej-wladzy-kto-zyska-i-ile-zaplacimy-za-obietnice-wyborcze-8639335.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Podatki-nowej-wladzy-kto-zyska-i-ile-zaplacimy-za-obietnice-wyborcze-8639335.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/a/7b2f26b0957509-948-568-0-270-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W trzecią kadencję rządów Prawa i Sprawiedliwości 
wątpią już nawet politycy z tej partii. Blok złożony z Koalicji 
Obywatelskiej, Polski 2050, PSL-u i Lewicy szykuje się do przejęcia 
władzy, a ekonomiści zachodzą w głowę, jakie zmiany zaserwuje nam nowy 
obóz rządzący. Fundacja CenEA przyjrzała się jej podatkowym obietnicom 
wyborczym.</p>

## Znana sieć aptek podsłuchiwała klientów. RPO interweniuje
 - [https://www.bankier.pl/wiadomosc/Znana-siec-aptek-podsluchiwala-klientow-RPO-interweniuje-8639266.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Znana-siec-aptek-podsluchiwala-klientow-RPO-interweniuje-8639266.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/1/5c41a82e986e33-948-568-0-139-3986-2392.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W jednej z największych sieci aptek kamery i mikrofony miały nagrywać rozmowy pracowników, także z klientami przy okienkach - pracownicy mieli podpisywać zgody na to; klientów o tym nie uprzedzano. RPO wystąpił w tej sprawie do prezes Naczelnej Rady Aptekarskiej.</p>

## Średnia cena metra kwadratowego nowych mieszkań w Trójmieście przekroczyła pułap 14 tys. zł
 - [https://www.bankier.pl/wiadomosc/Srednia-cena-metra-kwadratowego-nowych-mieszkan-w-Trojmiescie-przekroczyla-pulap-14-tys-zl-8639537.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Srednia-cena-metra-kwadratowego-nowych-mieszkan-w-Trojmiescie-przekroczyla-pulap-14-tys-zl-8639537.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/2/496ae5af9be4c5-948-568-0-70-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W październiku średnie ceny za metr kwadratowy mieszkań w ofercie deweloperów w największych metropoliach wzrosły lub ustabilizowały się w ujęciu mdm - wynika ze wstępnych danych BIG DATA RynekPierwotny. pl.</p>

## Izrael zamknął pierścień oblężenia wokół Gazy. Zginęło 9 tys. Palestyńczyków
 - [https://www.bankier.pl/wiadomosc/Izrael-zamknal-pierscien-oblezenia-wokol-Gazy-Zginelo-juz-9-tys-Palestynczykow-8639716.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Izrael-zamknal-pierscien-oblezenia-wokol-Gazy-Zginelo-juz-9-tys-Palestynczykow-8639716.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T02:41:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/5/70822e5e0adb48-948-568-0-184-2736-1641.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />"Jesteśmy w szczytowym momencie bitwy" - ogłosił premier Benjamin Netanjahu. Siły Obronny Izraela (IDF) poinformowały w czwartek, że zakończyły okrążanie miasta Gaza, odcinając je od południowych rejonów Strefy Gazy.</p>

## Wojna w Ukrainie. Alarm przeciwlotniczy w obwodzie lwowskim
 - [https://www.bankier.pl/wiadomosc/Wojna-w-Ukrainie-Alarm-przeciwlotniczy-w-obwodzie-lwowskim-8639714.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wojna-w-Ukrainie-Alarm-przeciwlotniczy-w-obwodzie-lwowskim-8639714.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T01:10:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/3/f69a196af396f3-948-568-0-135-2000-1199.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W nocy z czwartku na piątek w obwodzie lwowskim ogłoszono alarm przeciwlotniczy. Szef władz regionu Maksym Kozycki zaapelował do mieszkańców o pozostanie w schronach.</p>

## Kongres chce wysłać pomoc wojskową dla Izraela mimo sprzeciwu prezydenta
 - [https://www.bankier.pl/wiadomosc/Kongres-zdecydowal-o-pomocy-wojskowej-dla-Izraela-mimo-grozby-weta-prezydenta-8639713.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kongres-zdecydowal-o-pomocy-wojskowej-dla-Izraela-mimo-grozby-weta-prezydenta-8639713.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-11-03T00:06:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/3/0fec735ccf74d8-948-567-0-20-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Izba Reprezentantów przegłosowała w czwartek projekt ustawy zakładający przeznaczenie 14 mld dolarów na pomoc wojskową dla Izraela oraz cięcia wydatków na amerykański fiskus. Sprzeciw wobec pakietu i odłączenie go od pomocy dla Ukrainy zapowiedziała większość w Senacie oraz prezydent Biden, który zagroził wetem.</p>

