# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Frankie and The Witch Fingers - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=QRiDjativSY](https://www.youtube.com/watch?v=QRiDjativSY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-11-03T15:00:17+00:00

http://KEXP.ORG presents Frankie and the Witch Fingers performing live in the KEXP studio. Recorded August 31, 2023.

Songs:
Empire
Burn Me Down
Mild Davis
Futurephobic

Dylan Sizemore - Guitar / Vocal
Josh Menashe - Guitar / Vocal
Nikki Pickle - Bass
Nick Aguilar - Drums
Joel Cuplin - Saxophone
Eric Padget - Trumpet

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Audio Mixer: Josh Menashe
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Scott Holpainen, Luke Knecht
Editor: Jim Beckmann

https://www.frankieandthewitchfingers.com
http://kexp.org


Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Frankie and The Witch Fingers - Mild Davis (Live on KEXP)
 - [https://www.youtube.com/watch?v=lvM8N3GgdUo](https://www.youtube.com/watch?v=lvM8N3GgdUo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-11-03T11:00:45+00:00

http://KEXP.ORG presents Frankie and the Witch Fingers performing “Mild Davis” live in the KEXP studio. Recorded August 31st, 2023

Dylan Sizemore - Guitar/Vocal
Josh Menashe - Guitar/Vocal
Nikki Pickle - Bass Guitar
Nick Aguilar - Drums
Joel Cuplin - Saxophone
Eric Padget - Trumpet

Host: Cheryl Waters
Audio Engineers: Kevin Suggs
Audio Mixer: Josh Menashe
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Scott Holpainen
Editor: Jim Beckmann

https://www.frankieandthewitchfingers.com/
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Frankie and The Witch Fingers - Futurephobic (Live on KEXP)
 - [https://www.youtube.com/watch?v=T_yz-utUMM8](https://www.youtube.com/watch?v=T_yz-utUMM8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-11-03T11:00:32+00:00

http://KEXP.ORG presents Frankie and the Witch Fingers performing “Futurephobic” live in the KEXP studio. Recorded August 31st, 2023

Dylan Sizemore - Guitar/Vocal
Josh Menashe - Guitar/Vocal
Nikki Pickle - Bass Guitar
Nick Aguilar - Drums
Joel Cuplin - Saxophone
Eric Padget - Trumpet

Host: Cheryl Waters
Audio Engineers: Kevin Suggs
Audio Mixer: Josh Menashe
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Scott Holpainen
Editor: Jim Beckmann

https://www.frankieandthewitchfingers.com/
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Frankie and The Witch Fingers - Empire (Live on KEXP)
 - [https://www.youtube.com/watch?v=MBHeeoUeVmU](https://www.youtube.com/watch?v=MBHeeoUeVmU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-11-03T11:00:30+00:00

http://KEXP.ORG presents Frankie and the Witch Fingers performing “Empire” live in the KEXP studio. Recorded August 31st, 2023

Dylan Sizemore - Guitar/Vocal
Josh Menashe - Guitar/Vocal
Nikki Pickle - Bass Guitar
Nick Aguilar - Drums
Joel Cuplin - Saxophone
Eric Padget - Trumpet

Host: Cheryl Waters
Audio Engineers: Kevin Suggs
Audio Mixer: Josh Menashe
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Scott Holpainen
Editor: Jim Beckmann

https://www.frankieandthewitchfingers.com/
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Frankie and The Witch Fingers - Burn Me Down (Live on KEXP)
 - [https://www.youtube.com/watch?v=5TIWRMW71x4](https://www.youtube.com/watch?v=5TIWRMW71x4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-11-03T11:00:05+00:00

http://KEXP.ORG presents Frankie and the Witch Fingers performing “Burn Me Down” live in the KEXP studio. Recorded August 31st, 2023

Dylan Sizemore - Guitar/Vocal
Josh Menashe - Guitar/Vocal
Nikki Pickle - Bass Guitar
Nick Aguilar - Drums
Joel Cuplin - Saxophone
Eric Padget - Trumpet

Host: Cheryl Waters
Audio Engineers: Kevin Suggs
Audio Mixer: Josh Menashe
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Scott Holpainen
Editor: Jim Beckmann

https://www.frankieandthewitchfingers.com/
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

