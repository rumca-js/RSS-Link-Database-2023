# Source:Captain Midnight, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCROQqK3_z79JuTetNP3pIXQ, language:en-US

## The Year Video Game Movies Took Over
 - [https://www.youtube.com/watch?v=a1iiFYDAxv4](https://www.youtube.com/watch?v=a1iiFYDAxv4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCROQqK3_z79JuTetNP3pIXQ
 - date published: 2023-11-03T00:20:00+00:00

This video is sponsored by Nebula. Get a GREAT deal on Nebula now: https://go.nebula.tv/captainmidnight
Check out NerdSync's class: https://nebula.tv/how-to-make-a-nerdsync-video?ref=captainmidnight
Five Nights at Freddys and the Super Mario movie have proven to be some of the biggest hits of the year. Meanwhile, superhero films from Marvel and DC are floundering. Does this mean that we may see one start to overtake the other in big blockbuster films?
Music by Epidemic Sound (http://www.epidemicsound.com)
Follow me on Twitter: https://twitter.com/midnightcap
Follow me on Facebook: https://www.facebook.com/midnightcap
Special thanks to Andrew Elliott (Stalli111: https://www.youtube.com/user/Stalli111  ) for editing this video.

