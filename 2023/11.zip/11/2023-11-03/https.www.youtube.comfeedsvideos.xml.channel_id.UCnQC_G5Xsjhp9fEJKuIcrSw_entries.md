# Source:Ben Shapiro, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw, language:en-US

## Pro-Abortion Student Gets SHUT DOWN by Ben Shapiro
 - [https://www.youtube.com/watch?v=CyirB7dqa1M](https://www.youtube.com/watch?v=CyirB7dqa1M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-11-03T23:00:07+00:00

While debating students at Cambridge University, Ben faced off against a pro-abortion student that didn't seem to come prepared. This is why we do our homework.

Watch the full episode here: https://youtu.be/FtX1-OBeEQU

1️⃣ Click here to join the member-exclusive portion of my show: https://get.dailywireplus.com/member-block/ben-shapiro

2️⃣ Become a DailyWire+ member to gain access to movies, shows, documentaries, and more: https://bit.ly/3lfVtwK 

👕 Get your Ben Shapiro merch here: https://bit.ly/3TAu2cw

🔴Today's Sponsors🔴

Start your journey to better health! For a limited time, get 35% off your first order as a preferred customer. Use promo code SHAPIRO at checkout: https://www.balanceofnature.com/

Get $15 off your order PLUS a year of your choice of meat!
Use promo code SHAPIRO at checkout.
https://bit.ly/403CbJC

This video includes information, descriptions, video, and images which are included in order to give important context to the viewer through accurate portrayals of 

## This Is a Really Perverse Game
 - [https://www.youtube.com/watch?v=NAxkCYbYqBk](https://www.youtube.com/watch?v=NAxkCYbYqBk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-11-03T21:30:03+00:00



## Will These American’s Sign a Petition for Hamas?
 - [https://www.youtube.com/watch?v=VNTj6_TK36g](https://www.youtube.com/watch?v=VNTj6_TK36g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-11-03T21:00:20+00:00

Comedian Mikey Greenblatt took to the streets to ask young people if they'd sign a petition to support Hamas, followed by reading them the details of what they'd be supporting. Young people will support anything at this point.

1️⃣ Click here to join the member-exclusive portion of my show: https://get.dailywireplus.com/member-block/ben-shapiro

2️⃣ Become a DailyWire+ member to gain access to movies, shows, documentaries, and more: https://bit.ly/3lfVtwK 

3️⃣ Watch the full episode here: Ep.1843 - https://youtu.be/PN32UIj1mf0

👕 Get your Ben Shapiro merch here: https://bit.ly/3TAu2cw

🔴Today's Sponsors🔴

Get your free life insurance quote & see how much you could save: http://policygenius.com/SHAPIRO

Try Hallow for 3 months FREE: https://hallow.com/shaprio

#BenShapiro #TheBenShapiroShow #News #Politics #DailyWire #MikeyGreenblatt #Comedian #Hamas #Israel #Gaza #Israeli #Israel #MiddleEast #Palestine #Woke

## Marriage Is Forever
 - [https://www.youtube.com/watch?v=rRxGLPhU_WI](https://www.youtube.com/watch?v=rRxGLPhU_WI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-11-03T19:00:27+00:00



## The Islamophobia Lie
 - [https://www.youtube.com/watch?v=PN32UIj1mf0](https://www.youtube.com/watch?v=PN32UIj1mf0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-11-03T17:00:08+00:00

In the wake of the worst slaughter of Jews and anti-Semitic increase since World War II, the White House rushes to fight…Islamophobia; Hezbollah terror leader Hassan Nasrallah warns that the powerfully-armed Iranian proxy may join the war on Israel; and the media continue to provide cover for Hamas.

Ep.1843

- - -

1️⃣  Click here to join the member exclusive portion of my show:  https://bit.ly/41LQK62

2️⃣ Check out Bentkey Kids Entertainment here: https://bit.ly/46NTTVo

👕 Get your Ben Shapiro merch here: https://bit.ly/3TAu2cw

🔴Today's Sponsors🔴

ExpressVPN - Get 3 Months FREE of ExpressVPN: https://expressvpn.com/ben

Balance of Nature - Start your journey to better health! For a limited time, get 35% off your first order as a preferred customer. Use promo code SHAPIRO at checkout: https://www.balanceofnature.com/

Good Ranchers - Get $15 off your order PLUS a year of your choice of meat! Use promo code SHAPIRO at checkout. https://bit.ly/416NvWW 

Policygenius - Get your free 

## Ben Shuts Down Pro Abortion Student
 - [https://www.youtube.com/watch?v=RYGm8E9vD2U](https://www.youtube.com/watch?v=RYGm8E9vD2U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-11-03T01:00:12+00:00



