# Source:Wintergatan, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCcXhhVwCT6_WqjkEniejRJQ, language:en-US

## Making a Custom Fingerboard from Scratch - Collab with @swePudding
 - [https://www.youtube.com/watch?v=COgY3mI0Yzg](https://www.youtube.com/watch?v=COgY3mI0Yzg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCcXhhVwCT6_WqjkEniejRJQ
 - date published: 2023-11-03T16:42:14+00:00

Collab with @swepudding who also edited the video, turned out really nice! Check out the Pudding youtube channel here:

https://www.youtube.com/@swePudding

Edited by Pudding!

