# Source:Engadget, URL:https://www.engadget.com/rss.xml, language:en-US

## Live in Washington D.C.? You might be able to get free AirTags for your car
 - [https://www.engadget.com/live-in-washington-dc-you-might-be-able-to-get-free-airtags-for-your-car-202616642.html?src=rss](https://www.engadget.com/live-in-washington-dc-you-might-be-able-to-get-free-airtags-for-your-car-202616642.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-11-03T20:26:16+00:00

<p>The city of Washington D.C. will distribute free Apple AirTags to residents in certain neighborhoods, mayor Muriel Bowser announced on Wednesday. The aim: to make stolen cars easier for police to track down.</p>
<p>“We are equipping residents with technology that will allow the [Metropolitan Police Department] to address these crimes, recover vehicles, and hold people accountable,” Bowser said in a <a href="https://mayor.dc.gov/release/mayor-bowser-and-mpd-announce-tracking-tag-distribution-program-0">statement</a>, "we will continue to use all the tools we have, and add new tools, to keep our city safe.” Local publication DCist <a href="https://dcist.com/story/23/11/01/dc-car-theft-police-distribute-air-tags/">first reported</a> the story.</p>
<span id="end-legacy-contents"></span><p>D.C. residents in neighborhoods with the highest numbers of vehicle theft will be eligible to get free AirTags at three different events in the city over the next few months, starting next week. It’s

## Diablo IV's first expansion will introduce a brand-new class in late 2024
 - [https://www.engadget.com/diablo-ivs-first-expansion-will-introduce-a-brand-new-class-in-late-2024-200121982.html?src=rss](https://www.engadget.com/diablo-ivs-first-expansion-will-introduce-a-brand-new-class-in-late-2024-200121982.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-11-03T20:01:21+00:00

<p>It's <a class="no-affiliate-link" href="https://www.engadget.com/tag/blizzcon/"><ins>BlizzCon</ins></a> time, which means Blizzard is revealing some of the many things it has lined up for its stable of games. At the opening ceremony, there was a look at <a class="no-affiliate-link" href="https://news.blizzard.com/en-us/diablo4/24023220/catch-up-on-the-diablo-iv-blizzcon-opening-ceremony"><ins>the future</ins></a> of <a class="no-affiliate-link" href="https://www.engadget.com/tag/diablo-iv/"><em><ins>Diablo IV</ins></em></a>, including the game's first expansion.</p>
<p>Vessel of Hatred, which is slated to arrive in 2024, will build on the story of the main game. You'll find out the fate of the villain Mephisto and learn about his evil plans for Sanctuary. The DLC will feature the return of the Nahantu jungle area from <a class="no-affiliate-link" href="https://www.engadget.com/tag/diablo-ii/"><em><ins>Diablo II</ins></em></a>. The expansion will also introduce a brand-new characte

## Apple's extended holiday return policy is now in effect
 - [https://www.engadget.com/apples-extended-holiday-return-policy-is-now-in-effect-192054672.html?src=rss](https://www.engadget.com/apples-extended-holiday-return-policy-is-now-in-effect-192054672.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-11-03T19:20:54+00:00

<p>Apple's <a class="no-affiliate-link" href="https://www.apple.com/shop/help/returns_refund"><ins>extended return policy</ins></a> has kicked in, which means the holiday season is officially upon us. Apple typically offers a standard <a class="no-affiliate-link" href="https://www.engadget.com/2014-03-12-apple-drops-iphone-return-policy-back-to-14-days-m-carriers.html"><ins>14-day return window</ins></a>. But under the newly revised policy, products purchased between November 3, 2023 and December 25, 2023, will be returnable until January 8, 2024. Apple's holiday grace period gives you more than enough time to return those AirPods from your grandmother because she didn't know you were firmly planted in Samsung's ecosystem.</p>
<p>You can return most products in Apple's lineup, but there are a few exceptions. The return policy may not cover phones that are purchased with wireless carrier financing plans, so double-check that before you commit. Additionally, Apple doesn't allow the ret

## You can try new Overwatch 2 hero Mauga this weekend
 - [https://www.engadget.com/you-can-try-new-overwatch-2-hero-mauga-this-weekend-190042655.html?src=rss](https://www.engadget.com/you-can-try-new-overwatch-2-hero-mauga-this-weekend-190042655.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-11-03T19:00:42+00:00

<p>BlizzCon is upon us, which means Blizzard had a ton of announcements for fans of its games duing <a class="no-affiliate-link" href="https://www.youtube.com/watch?v=Yqb8fSs_99U">the opening ceremony</a>. The next <a href="https://www.engadget.com/tag/overwatch-2/"><em>Overwatch 2</em></a> hero was among the reveals and, as expected, the new tank is Baptiste's old running buddy, Mauga. <a class="no-affiliate-link" href="https://www.reddit.com/r/Overwatch/comments/17mst7u/first_look_at_mauga_i_think_from_the_nintendo/">A leak</a> on the Nintendo Switch eShop's news tab gave the game away a few hours early.</p>
<p>Mauga wields a pair of chainguns and he has an unstoppable charge ability that can knock enemies off of maps. Another ability reduces damage sustained by nearby allies and allows them to heal when they attack enemies. Mauga's ultimate ability looks fun, if terrifying for the other team. He traps nearby opponents into a cage match and has unlimited ammo for a short period of 

## Another former Facebook employee will testify at Congress about safety issues at Instagram
 - [https://www.engadget.com/another-former-facebook-employee-will-testify-at-congress-about-safety-issues-at-instagram-185339860.html?src=rss](https://www.engadget.com/another-former-facebook-employee-will-testify-at-congress-about-safety-issues-at-instagram-185339860.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-11-03T18:53:39+00:00

<p>Another former Facebook employee is going public with allegations that the company failed to act on its own research showing that young Instagram users were having harmful experiences on the platform. Arturo Bejar, a former Facebook employee and consultant for Instagram, is scheduled to testify at a Senate Judiciary Committee <a class="no-affiliate-link" href="https://www.judiciary.senate.gov/committee-activity/hearings/social-media-and-the-teen-mental-health-crisis">hearing</a> Tuesday, November, 7.</p>
<p>Bejar, who detailed his efforts to raise the alarm internally about Instagram safety issues to <a class="no-affiliate-link" href="https://www.wsj.com/tech/instagram-facebook-teens-harassment-safety-5d991be1"><em>The Wall Street Journal</em></a>, was a Facebook employee between 2009 and 2015 and returned to the company in 2019 to advise Instagram’s well-being team. He told <em>The Journal</em> that internal research showed that more than 20 percent of users younger than 16 “felt

## Solo Stove's Black Friday deals include up to $245 off fire pit bundles
 - [https://www.engadget.com/solo-stoves-black-friday-deals-include-up-to-245-off-fire-pit-bundles-184011930.html?src=rss](https://www.engadget.com/solo-stoves-black-friday-deals-include-up-to-245-off-fire-pit-bundles-184011930.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-11-03T18:40:11+00:00

<p>Can you smell it? Black Friday is rapidly approaching, and some companies have already begun the onslaught of sales. Solo Stove, for instance, has just cut the ribbon on its annual Black Friday sale, offering discounts on numerous fire pits and related items and accessories. The biggest discount here is for the <a class="rapid-with-clickid" href="https://shopping.yahoo.com/rdlw?merchantId=f5421854-3d3e-46b7-ba38-db91920c7f00&amp;siteId=us-engadget&amp;pageId=1p-autolink&amp;featureId=text-link&amp;merchantName=Solo+Stove&amp;custData=eyJzb3VyY2VOYW1lIjoiV2ViLURlc2t0b3AtVmVyaXpvbiIsImxhbmRpbmdVcmwiOiJodHRwczovL3NvbG9zdG92ZS5jb20vZW4tdXMvcC9yYW5nZXItYmFja3lhcmQtYnVuZGxlP3NrdT1CWUItUkFOR0VSLTIuMC1WMiIsImNvbnRlbnRVdWlkIjoiNGFlZGQyMzctZGMyNS00Y2JjLWE1MDEtYjM5NDYzN2E3MmYwIn0&amp;signature=AQAAAbgn9LW4xr8xLmpwONSqyvAC94oNAtYI1vEqBxHQbEpH&amp;gcReferrer=https%3A%2F%2Fsolostove.com%2Fen-us%2Fp%2Franger-backyard-bundle%3Fsku%3DBYB-RANGER-2.0-V2">Ranger Backyard Bundle 2.0,</a> which now cos

## Thousands of people are uninstalling ad blockers after YouTube's big crackdown
 - [https://www.engadget.com/thousands-of-people-are-uninstalling-ad-blockers-after-youtubes-big-crackdown-174009041.html?src=rss](https://www.engadget.com/thousands-of-people-are-uninstalling-ad-blockers-after-youtubes-big-crackdown-174009041.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-11-03T17:40:09+00:00

<p>YouTube’s <a href="https://www.engadget.com/youtube-is-taking-its-fight-against-ad-blockers-global-122041223.html"><ins>crackdown on ad blockers</ins></a> is hurting the companies who make them. Multiple ad blocking companies say that thousands of people are uninstalling their products after YouTube started showing warnings to people trying to watch videos on its website with ad blockers enabled.</p>
<p>One of the companies, AdGuard, told <a href="https://www.wired.com/story/youtubes-ad-blocker-crackdown-spurs-record-uninstalls/?redirectURL=%2Fstory%2Fyoutubes-ad-blocker-crackdown-spurs-record-uninstalls%2F"><em><ins>Wired</ins></em></a> that more than 11,000 people have uninstalled its Chrome extension each day since October 9, compared to 6,000 uninstallations per day before YouTube implemented the change. On October 18, 52,000 people uninstalled AdGuard, the company’s CTO Andrey Meshkov told <em>Wired</em>. However, installations of AdGuard’s paid version, which YouTube’s crack

## NASA discovered that an asteroid named Dinky actually has its own moon
 - [https://www.engadget.com/nasa-discovered-that-an-asteroid-named-dinky-actually-has-its-own-moon-173028204.html?src=rss](https://www.engadget.com/nasa-discovered-that-an-asteroid-named-dinky-actually-has-its-own-moon-173028204.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-11-03T17:30:28+00:00

<p>NASA’s Lucy spacecraft, first launched in 2021 to <a href="https://www.engadget.com/nas-as-lucy-spacecraft-gets-improvised-fix-on-its-way-to-explore-trojan-asteroids-100356302.html"><ins>explore the Trojan asteroids</ins></a> trapped near Jupiter, has made an interesting discovery. The spacecraft found an asteroid, nicknamed Dinky, that actually has a smaller asteroid orbiting it, <a href="https://www.scientificamerican.com/article/nasa-asteroid-mission-discovers-tiny-surprise-moon-with-really-bizarre-shape/"><ins>as originally reported by </ins><em><ins>Scientific American</ins></em><ins>.</ins></a> That’s right. It’s basically a moon with its own moon. It’s an ouroboros of cosmic curiosity.</p>
<p>The technical term here is a binary asteroid pair and Dinky, whose real name is Dinkinesh, was spotted by Lucy during a quick fly by. That’s when the spacecraft spotted the smaller “moon” orbiting it.</p>
<span id="end-legacy-contents"></span><div id="317d5c933f1c43458695d6c04b2dc1cc">

## Echo will be the first Marvel show to hit Disney+ and Hulu simultaneously
 - [https://www.engadget.com/echo-will-be-the-first-marvel-show-to-hit-disney-and-hulu-simultaneously-172206411.html?src=rss](https://www.engadget.com/echo-will-be-the-first-marvel-show-to-hit-disney-and-hulu-simultaneously-172206411.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-11-03T17:22:06+00:00

<p>Not too long ago, <a href="https://www.engadget.com/tag/marvel-studios/"><ins>Marvel Studios</ins></a> seemed indestructible. But the Marvel Cinematic Universe has faced some significant setbacks over the last few years. As laid out in <a href="https://variety.com/2023/film/features/marvel-jonathan-majors-problem-the-marvels-reshoots-kang-1235774940/"><ins>a </ins><em><ins>Variety </ins></em><ins>report this week</ins></a>, Marvel has been contending with a number of issues such as box office disappointments, while Jonathan Majors (who portrays the MCU's latest centerpiece villain) is <a href="https://www.npr.org/2023/10/25/1191589920/jonathan-majors-trial-assault-harassment-new-york">awaiting trial</a> for assault and harassment charges. Marvel also seemed to be <a href="https://www.engadget.com/disney-will-slow-and-spread-the-releases-of-its-marvel-series-202129646.html"><ins>stretching itself thin</ins></a> between its many movies and TV shows amid reports that <a href="https:/

## Black Friday 2023: The best early deals from Amazon, Target, Best Buy and more
 - [https://www.engadget.com/black-friday-2023-the-best-early-deals-from-amazon-target-best-buy-and-more-163054419.html?src=rss](https://www.engadget.com/black-friday-2023-the-best-early-deals-from-amazon-target-best-buy-and-more-163054419.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-11-03T16:30:54+00:00

<p>With each passing year, the phrase "Black Friday" becomes more of a misnomer. What was once a day of post-Thanksgiving special offers has become a month of sales promotions from retailers across the web. It's happening again in 2023: <a class="rapid-with-clickid" href="https://shopping.yahoo.com/rdlw?merchantId=827d7835-78d6-4491-ae04-c042cab1d6e7&amp;siteId=us-engadget&amp;pageId=1p-autolink&amp;featureId=text-link&amp;merchantName=Target&amp;custData=eyJzb3VyY2VOYW1lIjoiV2ViLURlc2t0b3AtVmVyaXpvbiIsImxhbmRpbmdVcmwiOiJodHRwczovL3d3dy50YXJnZXQuY29tL2MvdGFyZ2V0LWJsYWNrLWZyaWRheS8tL04tNXEwZjIiLCJjb250ZW50VXVpZCI6IjQzYTI3MGI2LTMyMjktNDhkMi05ZDdjLWQ3MDMzYmE1OTdkZSJ9&amp;signature=AQAAAU0qAB37VhK312CpqYMFMIlxVwriBgm5OwtE0BCXwmRK&amp;gcReferrer=https%3A%2F%2Fwww.target.com%2Fc%2Ftarget-black-friday%2F-%2FN-5q0f2">Target</a> and <a class="rapid-with-clickid" href="https://shopping.yahoo.com/rdlw?merchantId=5e0bed65-d2f8-4b34-9b8f-955218c0e37a&amp;siteId=us-engadget&amp;pageId=1p-autolink&

## Vampire Survivors will soon feature 'miniature story modes'
 - [https://www.engadget.com/vampire-survivors-will-soon-feature-miniature-story-modes-161749229.html?src=rss](https://www.engadget.com/vampire-survivors-will-soon-feature-miniature-story-modes-161749229.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-11-03T16:17:49+00:00

<p><a href="https://www.engadget.com/tag/vampire-survivors/"><em><ins>Vampire Survivors</ins></em></a><em>&nbsp;</em>is one of the biggest surprise hits of the last few years and while its developer could have easily kicked back and taken things easy, Poncle has been beavering away on a bunch of updates. The next one is a fresh game mode that'll give players even more to do.</p>
<p>The new Adventures are &quot;self-contained miniature story modes&quot; that will take the <em>Vampire Survivors </em>characters on some &quot;wacky sidequests,&quot; <a href="https://poncle.games/adventures-faq"><ins>according to Poncle</ins></a>. Each mission has its own progression path that's separate from the main game. You'll have a limited set of characters, weapons and power ups at your disposal as you take on custom challenges such as staying alive for a specific length of time or killing a certain number of enemies. Adventures will also have some &quot;lore text&quot; to tie the story together.</

## Elon Musk’s new AI company, xAI, soft launches this weekend
 - [https://www.engadget.com/elon-musks-new-ai-company-xai-soft-launches-this-weekend-160505811.html?src=rss](https://www.engadget.com/elon-musks-new-ai-company-xai-soft-launches-this-weekend-160505811.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-11-03T16:05:05+00:00

<p>We’ve been hearing rumblings about <a href="https://www.engadget.com/elon-musks-new-ai-company-aims-to-understand-the-true-nature-of-the-universe-172255152.html"><ins>Elon Musk’s new AI venture,</ins></a> xAI, for months, and now it looks like it’s almost here. The Tesla CEO and noted social media guru just took to Twitter/X to proclaim that his AI venture will launch its first model tomorrow, November 4.</p>
<p>This is a beta phase, of a sort, as it’s being released <a href="https://twitter.com/elonmusk/status/1720372289378590892"><ins>only to a “select group”,</ins></a> though Musk didn’t specify as to what went into the selection process. Will it be a random drop or will the AI model be reserved for “VIPs” like, uh, Tucker Carlson, Chaya Raichik or the indefatigable Catturd? It’s anyone's guess.</p>
<span id="end-legacy-contents"></span><p>Musk is making lofty promises about his AI, announcing that “in some important respects, it is the best that currently exists.” It’ll be com

## ProtonVPN plans are up to 60 percent off in a Black Friday deal
 - [https://www.engadget.com/protonvpn-plans-are-up-to-60-percent-off-in-a-black-friday-deal-153355317.html?src=rss](https://www.engadget.com/protonvpn-plans-are-up-to-60-percent-off-in-a-black-friday-deal-153355317.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-11-03T15:33:55+00:00

<p>ProtonVPN is running <a class="rapid-with-clickid" href="https://shopping.yahoo.com/rdlw?merchantId=06a20697-4135-4e83-a421-f326eee937ed&amp;siteId=us-engadget&amp;pageId=1p-autolink&amp;featureId=text-link&amp;merchantName=ProtonVPN&amp;custData=eyJzb3VyY2VOYW1lIjoiV2ViLURlc2t0b3AtVmVyaXpvbiIsImxhbmRpbmdVcmwiOiJodHRwczovL3Byb3RvbnZwbi5jb20vYmxhY2tmcmlkYXk_cmVmPWJmXzIzX3Zwbl9uZXctYmFubmVyIiwiY29udGVudFV1aWQiOiIzY2EwMWFhYS0xYTEzLTQ4MzUtYjU3YS05YjRjYWJhN2YwMzQifQ&amp;signature=AQAAAWFDZDYg9oo4Ex7jlzYRdSF3EGqNsEIAg8Z0o2wuyNa4&amp;gcReferrer=https%3A%2F%2Fprotonvpn.com%2Fblackfriday%3Fref%3Dbf_23_vpn_new-banner">a Black Friday Sale</a> on its VPN services, including a 30-month plan for 60 percent off, or $120 total. That works out to $4 per month for two and a half years of access, saving you $180 over paying full price. Proton VPN is our <a href="https://www.engadget.com/best-vpn-130004396.html#:~:text=Best%20VPN%20overall%3A%20ProtonVPN">favorite VPN service</a> and, unlike most VPN

## The M3 MacBook Pro is already $200 off in an early Black Friday deal
 - [https://www.engadget.com/the-m3-macbook-pro-is-already-200-off-in-an-early-black-friday-deal-150707609.html?src=rss](https://www.engadget.com/the-m3-macbook-pro-is-already-200-off-in-an-early-black-friday-deal-150707609.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-11-03T15:07:07+00:00

<p>Apple just revealed some new hardware at a <a href="https://www.engadget.com/apples-scary-fast-mac-event-everything-announced-about-m3-macbook-pro-and-m3-imac-153056716.html">streaming event earlier this week,</a> including <a href="https://www.engadget.com/apple-updates-its-14-inch-and-16-inch-macbook-pros-with-new-m3-chips-specs-price-003015893.html">Macbook Pro laptops</a> equipped with the proprietary M3 chip. These laptops are still on preorder, as they don’t officially release until next week. Despite that, you can already get a <a class="rapid-with-clickid" href="https://shopping.yahoo.com/rdlw?merchantId=0eee6f60-6f21-4ba6-b70e-cc15b39bf860&amp;siteId=us-engadget&amp;pageId=1p-autolink&amp;featureId=text-link&amp;merchantName=Adorama&amp;custData=eyJzb3VyY2VOYW1lIjoiV2ViLURlc2t0b3AtVmVyaXpvbiIsImxhbmRpbmdVcmwiOiJodHRwczovL3d3dy5hZG9yYW1hLmNvbS9hY21hY3Byby5odG1sIiwiY29udGVudFV1aWQiOiI2YmEwYTUzNS0zMmZkLTRmMTctYmNhYy04MDBlYTAyOWRlNzQifQ&amp;signature=AQAAAYS20Dui3HuH-5nith91Y

## The best VR headsets for 2023
 - [https://www.engadget.com/best-vr-headsets-140012529.html?src=rss](https://www.engadget.com/best-vr-headsets-140012529.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-11-03T15:00:08+00:00

<p>If you’ve been holding out for VR hardware to mature, you chose wisely. Headsets have come a long way since the launch of the Oculus Rift and HTC Vive six years ago. The Meta Quest 3 has just come out, and it’s the best standalone headset we’ve ever seen. And if you’re looking for a more immersive experience, high-end PC headsets are getting cheaper and the PS VR2 is a solid option for console gamers. The VR market is in a state of flux as we await <a href="https://www.engadget.com/apple-vision-pro-hands-on-a-new-milestone-for-mixed-reality-060943291.html">Apple’s Vision Pro</a>, but if you’re still hankering for some virtual action, we’ve collected some of the best options that we've tested and reviewed below.</p>
<h2>So what makes a good VR headset?</h2>
<p>I tend to judge them on a few basic criteria: Ergonomics, immersion and controls. It's not that hard to shove a mobile display into a plastic headset and strap some cheap elastic headbands onto it. But it takes skill to craft

## Arm picks up a minority stake in Raspberry Pi
 - [https://www.engadget.com/arm-picks-up-a-minority-stake-in-raspberry-pi-144946332.html?src=rss](https://www.engadget.com/arm-picks-up-a-minority-stake-in-raspberry-pi-144946332.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-11-03T14:49:46+00:00

<p>Even though its <a href="https://www.engadget.com/the-raspberry-pi-5-uses-the-companys-own-chip-designs-061316561.html"><ins>latest microcomputer</ins></a> bears its own chip designs, <a href="https://www.engadget.com/tag/raspberry-pi/"><ins>Raspberry Pi</ins></a> has been using <a href="https://www.engadget.com/tag/arm/"><ins>Arm</ins></a> CPUs since its inception in 2008. The two companies have now formed tighter bonds as Arm has picked up a minority stake in Raspberry Pi. The terms of the deal have not been disclosed. However, the companies say it's a &quot;strategic investment&quot; on Arm's part.</p>
<p>It seems that Arm wants to gain more of a foothold in the Internet of Things (IoT) ecosystem. &quot;With the rapid growth of edge and endpoint AI applications, platforms like those from Raspberry Pi, built on Arm, are critical to driving the adoption of high-performance IoT devices globally by enabling developers to innovate faster and more easily,&quot; Paul Williamson, senio

## Ace Hardware's online ordering and other systems are still down due to a suspected cyberattack
 - [https://www.engadget.com/ace-hardwares-online-ordering-and-other-systems-are-still-down-due-to-a-suspected-cyberattack-143208409.html?src=rss](https://www.engadget.com/ace-hardwares-online-ordering-and-other-systems-are-still-down-due-to-a-suspected-cyberattack-143208409.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-11-03T14:32:08+00:00

<p>Home improvement retailer Ace Hardware still can't take online orders as of Friday while it recovers from &quot;a malicous cyberattack.&quot; News of the outage first started circulating on Sunday, after <a href="https://www.reddit.com/r/sysadmin/comments/17jwvtz/ace_hardware_corp_cybersecurity_incident_10302023/">a Reddit user shared</a> a note from CEO John Venhuizen detailing the incident. Ace Hardware has not responded to a request for comment to verify the email, but the website confirms that it is &quot;currently unable to process orders online&quot; and directs customers to make their purchases in-store.&nbsp;</p>
<p>The cyber incident impacted warehouse management, invoice and other delivery systems, according to Venhuizen's memo. &quot;The impact of this incident is resulting in disruptions to your shipments,&quot; Venhuizen wrote. An <a href="https://www.bleepstatic.com/images/news/u/1220909/2023/Security/36/2nd-notice.png">update issued on Monday</a> urged stores to sta

## The best board games to gift this 2023 holiday season
 - [https://www.engadget.com/best-board-games-holiday-gifts-130003702.html?src=rss](https://www.engadget.com/best-board-games-holiday-gifts-130003702.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-11-03T13:00:03+00:00

<p>Board games are great gifts for anyone who wants to spend time with loved ones and disconnect from technology. But instead of pulling out the same old classics like Monopoly and Scrabble, we recommend giving some <a href="https://www.engadget.com/like-it-or-not-a-call-of-duty-board-game-is-coming-in-2024-141702572.html">new board games</a> a try. Thankfully, this space is full of unique sets that run the gamut from word puzzles to whodunnits to calming playthroughs that showcase the beauty of the little things in life. Here, we’ve compiled a list of games that you might not have heard of, but will still make excellent gifts this holiday season. From games with giant monsters to those with haunted mansions, we’re sure at least one of these will be a hit with friends and family.</p>
<h2>Freelancers</h2>
<p></p>
<h2>Fiction</h2>
<p></p>
<h2>King of Tokyo</h2>
<p></p>
<h2>Wavelength</h2>
<p></p>
<h2>Betrayal at the House on the Hill (3rd Edition)</h2>
<p></p>
<h2>Clank! Catacombs</h2>

## Engadget Podcast: Apple’s spooky M3 MacBook Pros and iMac
 - [https://www.engadget.com/engadget-podcast-apple-m3-macbook-pro-imac-123049924.html?src=rss](https://www.engadget.com/engadget-podcast-apple-m3-macbook-pro-imac-123049924.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-11-03T12:30:49+00:00

<p>Apple’s M3 chip is here, and the company is wasting no time shoving it into new computers. This week, we dive into the new M3-equipped MacBook Pros and iMac, which offer some notable upgrades over the M2 and M1 models. Also, we find time to celebrate the death of the old 13-inch MacBook Pro, and try to determine if the cheaper 14-inch MacBook Pro is actually meant for pros with 8GB of RAM. We also chat about Apple’s healthcare plans, as well as Lenovo’s ridiculous tablet fashion campaign.</p>
<hr />
<p>Listen below or subscribe on your podcast app of choice. If you've got suggestions or topics you'd like covered on the show, be sure to <a href="mailto:podcast@engadget.com?subject=Engadget%20Podcast%20Feedback"><strong>email us</strong></a> or drop a note in the comments! And be sure to check out our other podcast, <a href="https://www.engadget.com/2019-08-01-engadget-podcasts.html">Engadget News</a>!</p>
<span id="end-legacy-contents"></span><div id="undefined"><div style="width: 

## Samsung's SmartTag 2 four-pack is just $80 right now
 - [https://www.engadget.com/samsungs-smarttag-2-four-pack-is-just-80-right-now-122558604.html?src=rss](https://www.engadget.com/samsungs-smarttag-2-four-pack-is-just-80-right-now-122558604.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-11-03T12:25:58+00:00

<p><a href="https://www.engadget.com/samsungs-30-galaxy-smarttag-2-arrives-on-october-11-with-an-all-new-design-082947760.html">Samsung only debuted its new SmartTag 2 in mid-October</a>, but the device already has a great sale going. Right now, you can get <a class="rapid-with-clickid" href="https://shopping.yahoo.com/rdlw?merchantId=66ea567a-c987-4c2e-a2ff-02904efde6ea&amp;siteId=us-engadget&amp;pageId=1p-autolink&amp;featureId=text-link&amp;merchantName=Amazon&amp;custData=eyJzb3VyY2VOYW1lIjoiV2ViLURlc2t0b3AtVmVyaXpvbiIsImxhbmRpbmdVcmwiOiJodHRwczovL3d3dy5hbWF6b24uY29tL2RwL0IwQ0pZTDFROVM_dGFnPWdkZ3QwYy1wLW8tNHgyLTIwIiwiY29udGVudFV1aWQiOiIwMWNiZDcwNC1iYjMwLTRkNmMtYWJhOC04ODNlNTVjOTBjYWUifQ&amp;signature=AQAAAWpgEkA62uzikWvmmpXJX8CbBCBNyAqvpdROLc9iLNvx&amp;gcReferrer=https%3A%2F%2Fwww.amazon.com%2Fdp%2FB0CJYL1Q9S">four SmartTag 2 trackers</a> for just $80, down from $92. The 13 percent price cut puts each one at just $20 — that's quite a saving compared to the $30 a <a class="rapid-w

## The best gaming headsets for 2023
 - [https://www.engadget.com/best-gaming-headset-130006477.html?src=rss](https://www.engadget.com/best-gaming-headset-130006477.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-11-03T11:55:35+00:00

<p>Most of the time, the best gaming headset isn’t a “gaming headset” at all. Although these devices are often thought of as a distinct niche within the wider headphone market, they're ultimately <em>still headphones</em>. And while it’s certainly not impossible to get a gaming headset that sounds nice, doing so still tends to come at a higher cost than a comparable pair of wired headphones (yes, those still exist).</p>
<p>A good wired headphone remains your best bet if you want the most detailed sound possible at a given price point and don’t need something especially portable, which is usually the case whether you’re gaming on a console or PC. If you need to chat with friends, you can always buy an external microphone, whether it’s a USB mic, a cheaper <a href="https://www.engadget.com/best-mobile-microphones-for-recording-with-a-phone-154536629.html">clip-on model</a> or a standalone option like the <a href="https://antlionaudio.com/collections/microphones/">Antlion ModMic</a> or 

## Google's plan to build 15,000 homes for the San Francisco Bay Project fizzles out
 - [https://www.engadget.com/googles-plan-to-build-15000-homes-for-the-san-francisco-bay-project-fizzles-out-113526409.html?src=rss](https://www.engadget.com/googles-plan-to-build-15000-homes-for-the-san-francisco-bay-project-fizzles-out-113526409.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-11-03T11:35:26+00:00

<p>Google has <a class="rapid-with-clickid" href="https://shopping.yahoo.com/rdlw?merchantId=34e37b9c-8975-48da-aa39-df8bcd5badc3&amp;siteId=us-engadget&amp;pageId=1p-autolink&amp;featureId=text-link&amp;merchantName=CNBC&amp;custData=eyJzb3VyY2VOYW1lIjoiV2ViLURlc2t0b3AtVmVyaXpvbiIsImxhbmRpbmdVcmwiOiJodHRwczovL3d3dy5jbmJjLmNvbS8yMDIzLzExLzAyL2dvb2dsZS1lbmRzLWFncmVlbWVudC13aXRoLWxlYWQtZGV2ZWxvcGVyLW9mLWZvdXItY2FsaWZvcm5pYS1jYW1wdXNlcy5odG1sIiwiY29udGVudFV1aWQiOiJiNjU4NTgwYy1mZjBkLTQ3ZWUtOWRkNC05M2FkY2RjZjEyMjcifQ&amp;signature=AQAAAT4Yep2fECChRDaAm5nZCOvwMMfVA7leFws7guJOOF6V&amp;gcReferrer=https%3A%2F%2Fwww.cnbc.com%2F2023%2F11%2F02%2Fgoogle-ends-agreement-with-lead-developer-of-four-california-campuses.html">ended its agreement</a> with real estate developer Landlease for its San Francisco Bay Project, effectively scrapping its plans to build a campus with thousands of homes for employees and locals. The company <a href="https://www.engadget.com/2019-06-18-google-bay-area-housing-inv

## The Morning After: The final Beatles song was made with a little help from AI
 - [https://www.engadget.com/the-morning-after-the-final-beatles-song-was-made-with-a-little-help-from-ai-111541406.html?src=rss](https://www.engadget.com/the-morning-after-the-final-beatles-song-was-made-with-a-little-help-from-ai-111541406.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-11-03T11:15:41+00:00

<p>The Beatles have <a href="https://www.engadget.com/listen-to-the-final-beatles-track-made-with-machine-learning-and-archival-recordings-153253946.html">released another song</a>, the first since 1995. “Now and Then” is being advertised as the <em>final</em> Beatles track, given that two of the members have passed and the other two are well over 80 years old. But then again, millionaires do love money.</p>
<p>The song grew from a John Lennon demo track dating back to the 1970s and a 1995 guitar track from George Harrison. The surviving Beatles, Paul McCartney and Ringo Starr, then finished the tune using machine learning technology. The song was meant to come out back in 1995, along with “Free as a Bird” and “Real Love,” two other tracks culled from old Lennon demos. However, the technology just wasn’t there to pull the vocals without degrading audio quality.</p>
<div id="7723a6b8813446f6b78bac47fcdd88cb"><div style="width: 100%; height: 0; padding-bottom: 56.25%;"></div></div>
<p>

## Amazon is bundling a Fire TV 4K Max and Blink Video Doorbell for $65 in early Black Friday deal
 - [https://www.engadget.com/amazon-is-bundling-a-fire-tv-4k-max-and-blink-video-doorbell-for-65-in-early-black-friday-deal-105046984.html?src=rss](https://www.engadget.com/amazon-is-bundling-a-fire-tv-4k-max-and-blink-video-doorbell-for-65-in-early-black-friday-deal-105046984.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-11-03T10:50:46+00:00

<p>Amazon bundle deals are a relatively common occurrence, but the latest one is a pairing we'd never expect: Ahead of Black Friday, Prime Members can get the <a class="rapid-with-clickid" href="https://shopping.yahoo.com/rdlw?merchantId=66ea567a-c987-4c2e-a2ff-02904efde6ea&amp;siteId=us-engadget&amp;pageId=1p-autolink&amp;featureId=text-link&amp;merchantName=Amazon&amp;custData=eyJzb3VyY2VOYW1lIjoiV2ViLURlc2t0b3AtVmVyaXpvbiIsImxhbmRpbmdVcmwiOiJodHRwczovL3d3dy5hbWF6b24uY29tL2dwL3Byb2R1Y3QvQjBDSE5CR1lDMy8_dGFnPWdkZ3QwYy1wLW8tNHgwLTIwIiwiY29udGVudFV1aWQiOiI4OGU4Y2UzOC1mMjc5LTQ2ZTktOTA1ZC03OWFhOWU3YzAxNjEifQ&amp;signature=AQAAAU2at3HwFI33FGmXWoLZT7YUAEGEf7oYM5AlBqVdLr5T&amp;gcReferrer=https%3A%2F%2Fwww.amazon.com%2Fgp%2Fproduct%2FB0CHNBGYC3%2F">Fire TV Stick 4K Max and Blink Video Doorbell as a pair</a> for $65. The <a class="rapid-with-clickid" href="https://shopping.yahoo.com/rdlw?merchantId=66ea567a-c987-4c2e-a2ff-02904efde6ea&amp;siteId=us-engadget&amp;pageId=1p-autolink&amp;feature

## Legacy HBO Max ad-free subscribers will lose access to 4K streams soon
 - [https://www.engadget.com/legacy-hbo-max-ad-free-subscribers-will-lose-access-to-4k-streams-soon-092315829.html?src=rss](https://www.engadget.com/legacy-hbo-max-ad-free-subscribers-will-lose-access-to-4k-streams-soon-092315829.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-11-03T09:23:15+00:00

<p>In just a bit over a month, legacy HBO Max subscribers paying for ad-free streaming will be losing a couple of perks they're enjoying. One of those is 4K streaming. According to <a href="https://www.theverge.com/2023/11/2/23943859/max-4k-hbo-max-ad-free-subscribers"><em>The Verge</em></a>, the streaming service has started sending affected subscribers an email, notifying them that they won’t be able to stream in 4K anymore after December 5th. Warner Bros. Discovery <a href="https://www.engadget.com/warner-bros-max-streaming-service-launches-with-new-20-4k-tier-092756959.html?_fsig=XLEEMeyHs33UhP9BxR6u1g--%7EA">promised</a> existing subscribers when it rebranded the service into &quot;Max&quot; back in May they they would still have access to their plan's features over the next six months. After that period ends, their only option to retain 4K streaming is to let go of their $16-a-month subscription plan to switch to Max’s Ultimate Ad-Free tier that costs $20 a month.</p>
<p>The se

## Intuit is closing down Mint, its popular free budget-tracking app
 - [https://www.engadget.com/intuit-is-closing-down-mint-its-popular-free-budget-tracking-app-054145229.html?src=rss](https://www.engadget.com/intuit-is-closing-down-mint-its-popular-free-budget-tracking-app-054145229.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-11-03T05:41:45+00:00

<p>Intuit is shutting down its free budgeting app Mint, which had 3.6 million active users in 2021, <a href="https://www.bloomberg.com/news/articles/2023-11-01/intuit-winds-down-personal-finance-app-mint-shifts-users-to-credit-karma?sref=10lNAhZ9#xj4y7vzkg"><em>Bloomberg</em></a> reported. The company will absorb users into its other service called Credit Karma when Mint disappears on January 1st, 2024 — less than two months from now.&nbsp;</p>
<p>&quot;Credit Karma is thrilled to invite all Minters to continue their financial journey on Credit Karma, where they will have access to Credit Karma’s suite of features, products, tools and services, including some of Mint’s most popular features,&quot; Mint wrote in its <a href="https://mint.intuit.com/blog/mint-app-news/intuit-credit-karma-welcomes-minters/">product blog</a>. The company noted that Mint's product team and some features have already shifted over to Credit Karma.&nbsp;</p>
<span id="end-legacy-contents"></span><p>Mint help

## FTX founder Sam Bankman-Fried found guilty on seven charges of fraud and conspiracy
 - [https://www.engadget.com/ftx-founder-sam-bankman-fried-found-guilty-on-seven-charges-of-fraud-and-conspiracy-012316105.html?src=rss](https://www.engadget.com/ftx-founder-sam-bankman-fried-found-guilty-on-seven-charges-of-fraud-and-conspiracy-012316105.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-11-03T01:23:16+00:00

<p>A federal jury has found Sam Bankman-Fried, the founder of FTX, guilty on all seven counts of fraud and conspiracy he was charged with in relation to the downfall of his cryptocurrency exchange. According to <a href="https://www.nytimes.com/live/2023/11/02/business/sam-bankman-fried-trial"><em>The New York Times</em></a>, he faces a maximum sentence of 110 years in federal prison. Bankman-Fried was <a href="https://www.engadget.com/former-ftx-ceo-sam-bankman-fried-arrested-in-bahamas-000800321.html">arrested in the Bahamas</a> back in December 2022 after the Department of Justice took a close look at his role in the rapid collapse of FTX. The agency <a href="https://www.engadget.com/us-prosecutors-reportedly-investigating-ftx-founder-sam-bankman-fried-fraud-214946075.html">examined</a> whether he transferred hundreds of millions of dollars — the company <a href="https://www.engadget.com/ftx-investigates-hack-174047127.html">claimed it was hacked</a> after around $600 million disap

