# Source:The Telegraph Top Stories, URL:https://www.telegraph.co.uk/rss.xml, language:en-UK

## Women in Sport issue call to protect women's sport at every level from transgender athletes
 - [https://www.telegraph.co.uk/sport/2023/11/03/women-in-sport-transgender-athletes-government-school](https://www.telegraph.co.uk/sport/2023/11/03/women-in-sport-transgender-athletes-government-school)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-11-03T18:24:28+00:00



## Ukraine: The Latest - Could Ukraine hold presidential elections?
 - [https://www.telegraph.co.uk/world-news/2023/11/03/ukraine-election-zelenksy-historical-comparison](https://www.telegraph.co.uk/world-news/2023/11/03/ukraine-election-zelenksy-historical-comparison)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-11-03T17:48:23+00:00



## Battle Lines: Interviewing Israeli forensics teams, Hamas' alleged property portfolio and interviewing Bedouin
 - [https://www.telegraph.co.uk/world-news/2023/11/03/battle-lines-israeli-forensics-teams-bedouin-hamas-property](https://www.telegraph.co.uk/world-news/2023/11/03/battle-lines-israeli-forensics-teams-bedouin-hamas-property)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-11-03T15:47:00+00:00



## Monkeypox ‘circulating for five years’ before 2022’s global health emergency
 - [https://www.telegraph.co.uk/global-health/science-and-disease/monkeypox-mutation-virus-outbreak-mpox-infections](https://www.telegraph.co.uk/global-health/science-and-disease/monkeypox-mutation-virus-outbreak-mpox-infections)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-11-03T14:29:54+00:00



## Bongi Mbonambi reignites racism row with 'Wenkant' shirt
 - [https://www.telegraph.co.uk/rugby-union/2023/11/03/bongi-mbonambi-wenkant-shirt-racism-tom-curry-world-cup](https://www.telegraph.co.uk/rugby-union/2023/11/03/bongi-mbonambi-wenkant-shirt-racism-tom-curry-world-cup)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-11-03T14:20:46+00:00



## An expert guide to ski holidays in Zell am See-Kaprun
 - [https://www.telegraph.co.uk/travel/ski/resort-guides/austria/zell-am-see/zell-am-see-ski-holiday-guide](https://www.telegraph.co.uk/travel/ski/resort-guides/austria/zell-am-see/zell-am-see-ski-holiday-guide)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-11-03T13:15:02.314784+00:00



## The best accommodation and ski chalets in Chamonix
 - [https://www.telegraph.co.uk/travel/ski/resort-guides/france/chamonix/chamonix-hotels-and-chalets](https://www.telegraph.co.uk/travel/ski/resort-guides/france/chamonix/chamonix-hotels-and-chalets)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-11-03T13:00:00+00:00



## The perfect ski holiday in Chamonix
 - [https://www.telegraph.co.uk/travel/ski/resort-guides/france/chamonix/chamonix-ski-holiday-guide](https://www.telegraph.co.uk/travel/ski/resort-guides/france/chamonix/chamonix-ski-holiday-guide)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-11-03T13:00:00+00:00



## The best hotels in Zell am See-Kaprun
 - [https://www.telegraph.co.uk/travel/ski/resort-guides/austria/zell-am-see/zell-am-see-hotels-and-chalets](https://www.telegraph.co.uk/travel/ski/resort-guides/austria/zell-am-see/zell-am-see-hotels-and-chalets)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-11-03T12:00:00+00:00



## Politics latest news: Two Labour council leaders call for Starmer to resign over Israel stance
 - [https://www.telegraph.co.uk/politics/2023/11/03/keir-starmer-labour-palestine-poll-remembrance-day-latest](https://www.telegraph.co.uk/politics/2023/11/03/keir-starmer-labour-palestine-poll-remembrance-day-latest)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-11-03T08:27:27+00:00



## Ukraine-Russia war live: Moscow suffers heavy losses in failed tank assault on Vuhledar
 - [https://www.telegraph.co.uk/world-news/2023/11/03/russia-ukraine-zelensky-putin-war-latest-news](https://www.telegraph.co.uk/world-news/2023/11/03/russia-ukraine-zelensky-putin-war-latest-news)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-11-03T08:19:45+00:00



## Israel-Gaza latest news: Dozens of Britons to escape Gaza today through Rafah crossing
 - [https://www.telegraph.co.uk/world-news/2023/11/03/israel-gaza-latest-news-updates-hamas-palestine-day-28-live](https://www.telegraph.co.uk/world-news/2023/11/03/israel-gaza-latest-news-updates-hamas-palestine-day-28-live)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-11-03T08:08:07+00:00



## Watch: How Putin’s rule will end - as Russia collapses around him | Defence in Depth
 - [https://www.telegraph.co.uk/world-news/2023/11/03/defence-in-depth-russia-ukraine-war-putin-collapse-economy](https://www.telegraph.co.uk/world-news/2023/11/03/defence-in-depth-russia-ukraine-war-putin-collapse-economy)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-11-03T08:00:00+00:00



