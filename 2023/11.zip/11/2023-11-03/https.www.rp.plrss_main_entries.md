# Source:rp.pl, URL:https://www.rp.pl/rss_main, language:pl-PL

## Donald Trump nazywa osoby skazane za atak na Kapitol "zakładnikami"
 - [https://www.rp.pl/polityka/art39361301-donald-trump-nazywa-osoby-skazane-za-atak-na-kapitol-zakladnikami](https://www.rp.pl/polityka/art39361301-donald-trump-nazywa-osoby-skazane-za-atak-na-kapitol-zakladnikami)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T21:10:00+00:00

Były prezydent Donald Trump podczas wiecu wyborczego nazwał osoby zatrzymane za atak na Kapitol Stanów Zjednoczonych "zakładnikami". Na rok przed wyborami utrzymuje, że w 2020 roku przegrał z Joe Bidenem z powodu powszechnego oszustwa.

## Uber i Lyft wypłacą wielomilionowe odszkodowania kierowcom
 - [https://www.rp.pl/prawo-w-firmie/art39361261-uber-i-lyft-wyplaca-wielomilionowe-odszkodowania-kierowcom](https://www.rp.pl/prawo-w-firmie/art39361261-uber-i-lyft-wyplaca-wielomilionowe-odszkodowania-kierowcom)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T20:28:10+00:00

Amerykańskie firmy świadczące usługi przewozowe Uber i Lyft po kilku latach postępowania prokuratorskiego podpisały ugodę, na mocy której wypłacą 328 milionów dolarów byłym i obecnym kierowcom taksówek za to, że obarczały ich podatkami i opłatami, które powinni ponieść pasażerowie płacąc za kurs.

## Adam Bodnar zostanie ministrem sprawiedliwości? "Mam spotkanie z Tuskiem"
 - [https://www.rp.pl/polityka/art39361271-adam-bodnar-zostanie-ministrem-sprawiedliwosci-mam-spotkanie-z-tuskiem](https://www.rp.pl/polityka/art39361271-adam-bodnar-zostanie-ministrem-sprawiedliwosci-mam-spotkanie-z-tuskiem)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T20:26:21+00:00

Adam Bodnar, były Rzecznik Praw Obywatelskich, który w wyborach parlamentarnych zdobył mandat senatora, w najbliższych dniach spotka się z Donaldem Tuskiem. Pytany, czy może zostać ministrem sprawiedliwości, odpowiedział, że "jest do dyspozycji".

## Od soboty psa trzymaj na smyczy, a kota w domu
 - [https://www.rp.pl/prawo-dla-ciebie/art39361221-od-soboty-psa-trzymaj-na-smyczy-a-kota-w-domu](https://www.rp.pl/prawo-dla-ciebie/art39361221-od-soboty-psa-trzymaj-na-smyczy-a-kota-w-domu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T19:51:57+00:00

Podczas najbliższych dwóch tygodni mieszkańcy Mazowsza powinni zachować ostrożność podczas wyprowadzania zwierząt domowych.  Od 4 do 15 listopada trwa jesienna akcja rozkładania przynęty dla lisów ze szczepionką przeciw wściekliźnie.

## Niemiecki klub rozwiązał kontrakt z piłkarzem. W sieci wspierał Palestynę
 - [https://www.rp.pl/pilka-nozna/art39361201-niemiecki-klub-rozwiazal-kontrakt-z-pilkarzem-w-sieci-wspieral-palestyne](https://www.rp.pl/pilka-nozna/art39361201-niemiecki-klub-rozwiazal-kontrakt-z-pilkarzem-w-sieci-wspieral-palestyne)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T19:31:38+00:00

Klub FSV Mainz poinformował o rozwiązaniu kontraktu z holenderskim piłkarzem Anwarem El Ghazim. Powodem są wpisy zawodnika w mediach społecznościowych dotyczące wojny w Strefie Gazy.

## Projekt umowy koalicyjnej już gotowy. Nowa większość wywiera presje na prezydenta Dudę
 - [https://www.rp.pl/polityka/art39360511-projekt-umowy-koalicyjnej-juz-gotowy-nowa-wiekszosc-wywiera-presje-na-prezydenta-dude](https://www.rp.pl/polityka/art39360511-projekt-umowy-koalicyjnej-juz-gotowy-nowa-wiekszosc-wywiera-presje-na-prezydenta-dude)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T19:18:44+00:00

Liderzy partii budujących nową większość (KO, TD i Lewica) otrzymali już projekt umowy koalicyjnej, który został wypracowany przez zespół programowy. Mają przyjrzeć mu się przez weekend, ale nie należy się spodziewać, że tekst zostanie uzgodniony do poniedziałku.

## Szuster- Ciesielska: nawet 40 proc. testów na Covid-19 ma dodatni wynik
 - [https://www.rp.pl/covid19/art39361191-szuster-ciesielska-nawet-40-proc-testow-na-covid-19-ma-dodatni-wynik](https://www.rp.pl/covid19/art39361191-szuster-ciesielska-nawet-40-proc-testow-na-covid-19-ma-dodatni-wynik)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T19:08:00+00:00

Polska i Węgry, jako jedyne kraje europejskie nie udostępniła do tej pory aktualizowanej wersji szczepionki przeciwko Covid-19. A zakażeń jest dużo – mówi prof. dr. hab. Agnieszka Szuste-Ciesielska, mikrobiolożka z Uniwersytetu Marii Curie-Skłodowskiej w Lublinie.

## Premier Irlandii: Działania Izraela coraz bardziej przypominają zemstę, a nie samoobronę
 - [https://www.rp.pl/konflikty-zbrojne/art39361051-premier-irlandii-dzialania-izraela-coraz-bardziej-przypominaja-zemste-a-nie-samoobrone](https://www.rp.pl/konflikty-zbrojne/art39361051-premier-irlandii-dzialania-izraela-coraz-bardziej-przypominaja-zemste-a-nie-samoobrone)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T18:54:40+00:00

Irlandzki premier Leo Varadkar określił w piątek działania Izraela w Strefie Gazy jako "coś zbliżającego się do zemsty".

## Urzędniczki surowo ukarane za łapówki przy przyznawaniu mieszkań
 - [https://www.rp.pl/prawo-karne/art39360981-urzedniczki-surowo-ukarane-za-lapowki-przy-przyznawaniu-mieszkan](https://www.rp.pl/prawo-karne/art39360981-urzedniczki-surowo-ukarane-za-lapowki-przy-przyznawaniu-mieszkan)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T18:42:15+00:00

8 lat oraz 5 i pół roku bezwzględnego pozbawienia wolności - to kary za korupcję, której dopuściły się dwie byłe urzędniczki gdańskiego magistratu. Kobiety brały łapówki za przyznawanie lokali komunalnych w Gdańsku.

## Waszyngton naciska na sojusznika, Izrael nie chce "pauz humanitarnych"
 - [https://www.rp.pl/dyplomacja/art39360991-waszyngton-naciska-na-sojusznika-izrael-nie-chce-pauz-humanitarnych](https://www.rp.pl/dyplomacja/art39360991-waszyngton-naciska-na-sojusznika-izrael-nie-chce-pauz-humanitarnych)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T18:26:16+00:00

Sekretarz stanu USA mówił w Tel Awiwie nie tylko o izraelskich ofiarach. I podkreślał, że trzeba robić więcej dla palestyńskich cywilów, w tym ogłaszać „pauzy humanitarne” w wojnie. Premier Izraela dał do zrozumienia, że nie ulegnie nowym planom Waszyngtonu w sprawie Strefy Gazy.

## Portugalczycy będą płacić mniej z tytułu podatków? Budżet zatwierdzony
 - [https://www.rp.pl/budzet-i-podatki/art39360471-portugalczycy-beda-placic-mniej-z-tytulu-podatkow-budzet-zatwierdzony](https://www.rp.pl/budzet-i-podatki/art39360471-portugalczycy-beda-placic-mniej-z-tytulu-podatkow-budzet-zatwierdzony)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T18:02:14+00:00

Portugalska Partia Socjalistyczną mająca absolutną większość 120 posłów w 230-osobowym parlamencie doprowadziła do zatwierdzenia w pierwszym czytaniu projektu ustawy budżetowej na 2024 r. Głosowanie (również bez przeszkód) powinno odbyć się 29 listopada.

## "Szefowa z piekła rodem" Anna Wintour kończy 74 lata. Mało kto pamięta, jak zaczęła karierę
 - [https://kobieta.rp.pl/ludzie/art39359761-szefowa-z-piekla-rodem-anna-wintour-konczy-74-lata-malo-kto-pamieta-jak-zaczela-kariere](https://kobieta.rp.pl/ludzie/art39359761-szefowa-z-piekla-rodem-anna-wintour-konczy-74-lata-malo-kto-pamieta-jak-zaczela-kariere)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T17:55:00+00:00

Wokół jej postaci powstało wiele mitów i legend. W wieku 16 lat porzuciła szkołę, dziś – jako redaktor naczelna amerykańskiego „Vogue’a” – jest jedną z najbardziej wpływowych osób w świecie mody.

## Dyrektor TASS nie odszedł sam. Został zwolniony przez Kreml za relacjonowanie buntu Grupy Wagnera
 - [https://www.rp.pl/polityka/art39360531-dyrektor-tass-nie-odszedl-sam-zostal-zwolniony-przez-kreml-za-relacjonowanie-buntu-grupy-wagnera](https://www.rp.pl/polityka/art39360531-dyrektor-tass-nie-odszedl-sam-zostal-zwolniony-przez-kreml-za-relacjonowanie-buntu-grupy-wagnera)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T17:36:09+00:00

10 dni po buncie przeprowadzonym przez Jewgienija Prigożyna i jego Grupę Wagnera ze stanowiska odszedł dyrektor TASS Siergiej Michajłow. The Moscow Times informuje, że decyzja w tej sprawie zapadła na Kremlu, a powodem był sposób relacjonowania buntu najemników Prigożyna.

## Lufthansa i Air France chwalą się wynikami za ostatni kwartał
 - [https://www.rp.pl/transport/art39360331-lufthansa-i-air-france-chwala-sie-wynikami-za-ostatni-kwartal](https://www.rp.pl/transport/art39360331-lufthansa-i-air-france-chwala-sie-wynikami-za-ostatni-kwartal)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T17:19:06+00:00

Lufthansa wypadła doskonale w III kwartale, lepiej od Air France-KLM, która też miała rekordowy wynik.

## Była premier Finlandii rozpoczęła nowe życie. Zdecydowanym krokiem wkracza do show-biznesu
 - [https://kobieta.rp.pl/jej-historia/art39360461-byla-premier-finlandii-rozpoczela-nowe-zycie-zdecydowanym-krokiem-wkracza-do-show-biznesu](https://kobieta.rp.pl/jej-historia/art39360461-byla-premier-finlandii-rozpoczela-nowe-zycie-zdecydowanym-krokiem-wkracza-do-show-biznesu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T17:13:48+00:00

Ma ponad milion obserwujących na Instagramie. Na tegorocznym tygodniu mody w Paryżu zasiadła w pierwszym rzędzie, obok Anne Wintour, słynnej szefowej amerykańskiego „Vogue'a”. Sanna Marin, była premier fińskiego rządu, zakończyła karierę w polityce i zaczyna nowy rozdział.

## Izrael odsyła do Strefy Gazy palestyńskich pracowników. Mówią o torturach w więzieniu
 - [https://www.rp.pl/konflikty-zbrojne/art39360421-izrael-odsyla-do-strefy-gazy-palestynskich-pracownikow-mowia-o-torturach-w-wiezieniu](https://www.rp.pl/konflikty-zbrojne/art39360421-izrael-odsyla-do-strefy-gazy-palestynskich-pracownikow-mowia-o-torturach-w-wiezieniu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T16:57:47+00:00

W piątek Izrael rozpoczął przymusową deportację na oblężone i zniszczone terytorium Palestyny tysięcy mieszkańców Strefy Gazy, którzy pracowali w Izraelu.

## Rosjanie gwałtownie skupują złoto. Już 75 ton w ich kieszeniach
 - [https://www.rp.pl/finanse/art39360121-rosjanie-gwaltownie-skupuja-zloto-juz-75-ton-w-ich-kieszeniach](https://www.rp.pl/finanse/art39360121-rosjanie-gwaltownie-skupuja-zloto-juz-75-ton-w-ich-kieszeniach)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T16:47:24+00:00

Nie tylko Bank Rosji gromadzi coraz więcej złota, także obywatele federacji gwałtownie skupują cenny kruszec. W tym roku idą na historyczny rekord - 75 ton. Złoto ma ich ochronić przed skutkami wywołanej wojny i rosnącą inflacją.

## Gospodarka Izraela coraz mocniej odczuwa skutki wojny z Hamasem
 - [https://www.rp.pl/gospodarka/art39360111-gospodarka-izraela-coraz-mocniej-odczuwa-skutki-wojny-z-hamasem](https://www.rp.pl/gospodarka/art39360111-gospodarka-izraela-coraz-mocniej-odczuwa-skutki-wojny-z-hamasem)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T16:39:34+00:00

El Al zwiększył przewozy cargo, bo zmalała liczba chętnych do odwiedzania tego kraju. W żegludze stawki ubezpieczenia skoczyły 10-krotnie. Wojna wstrzymała też plany rozbudowy portu w Hajfie.

## I Festiwal Rymkiewiczowski. Poeta nieoczywisty
 - [https://www.rp.pl/kultura/art39360091-i-festiwal-rymkiewiczowski-poeta-nieoczywisty](https://www.rp.pl/kultura/art39360091-i-festiwal-rymkiewiczowski-poeta-nieoczywisty)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T16:38:00+00:00

I Festiwal Rymkiewiczowski, który właśnie rozpoczął się w Warszawie, pokazuje postać Jarosława Marka Rymkiewicza w nieoczywisty sposób. Jako twórcę pełnego sprzeczności, ironicznego i podejmującego w swojej twórczości tematy fundamentalne.

## Kradzież w BUW. Karta kredytowa naprowadzi na ślad złodziei?
 - [https://www.rp.pl/przestepczosc/art39359361-kradziez-w-buw-karta-kredytowa-naprowadzi-na-slad-zlodziei](https://www.rp.pl/przestepczosc/art39359361-kradziez-w-buw-karta-kredytowa-naprowadzi-na-slad-zlodziei)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T16:34:23+00:00

Młoda kobieta ze złodziejskiej szajki, która ukradła m.in. pierwodruk Puszkina za wyrobienie karty bibliotecznej zapłaciła 20 zł kartą kredytową - ustaliła „Rzeczpospolita”. To najmocniejszy trop, który może doprowadzić śledczych do sprawców.

## Roszady w litewskiej spółce Orlenu. Prezes odwołany
 - [https://energia.rp.pl/paliwa/art39360341-roszady-w-litewskiej-spolce-orlenu-prezes-odwolany](https://energia.rp.pl/paliwa/art39360341-roszady-w-litewskiej-spolce-orlenu-prezes-odwolany)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T16:26:53+00:00

W litewskiej spółce Orlenu doszło do zmian kadrowych. Michał Rudnicki, wieloletni prezes Orlen Lietuva przestał pełnić swoje obowiązki z końcem ubiegłego miesiąca.

## Cyberbezpieczeństwo, przetargi i nowe wyzwania. Szkolenia dla przedsiębiorców.
 - [https://www.rp.pl/abc-firmy/art39360321-cyberbezpieczenstwo-przetargi-i-nowe-wyzwania-szkolenia-dla-przedsiebiorcow](https://www.rp.pl/abc-firmy/art39360321-cyberbezpieczenstwo-przetargi-i-nowe-wyzwania-szkolenia-dla-przedsiebiorcow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T16:18:00+00:00

W poniedziałek wystartuje cykl szkoleń z zakresu m.in. nowych regulacji prawnych, cyberbezpieczeństwa i zrównoważonego rozwoju. Ministerstwo Rozwoju i Technologii zaprasza wszystkich przedsiębiorców.

## Serwisy Gremi Media po raz kolejny z rekordowym wzrostem liczby użytkowników
 - [https://www.rp.pl/media/art39360261-serwisy-gremi-media-po-raz-kolejny-z-rekordowym-wzrostem-liczby-uzytkownikow](https://www.rp.pl/media/art39360261-serwisy-gremi-media-po-raz-kolejny-z-rekordowym-wzrostem-liczby-uzytkownikow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T16:08:41+00:00

Grupa Gremi Media odnotowała rekordowe wzrosty wyników online, osiągając najwyższy wynik w swojej dotychczasowej działalności. Według najnowszego raportu Mediapanel w październiku bieżącego roku liczba realnych użytkowników (RU) osiągnęła liczbę ponad 7,3 miliona, co stanowi aż +87% wzrostu w porównaniu do października ubiegłego roku. Jest to niewątpliwie efekt konsekwentnie realizowanej strategii cyfryzacji wydawnictwa.

## Serwisy Gremi Media z kolejny rekordowym wzrostem użytkowników
 - [https://www.rp.pl/media/art39360261-serwisy-gremi-media-z-kolejny-rekordowym-wzrostem-uzytkownikow](https://www.rp.pl/media/art39360261-serwisy-gremi-media-z-kolejny-rekordowym-wzrostem-uzytkownikow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T16:08:41+00:00

Grupa Gremi Media odnotowała rekordowe wzrosty wyników online, osiągając najwyższy wynik w swojej dotychczasowej działalności. Według najnowszego raportu Mediapanel w październiku bieżącego roku liczba realnych użytkowników (RU) osiągnęła liczbę ponad 7,3 miliona, co stanowi aż +87% wzrostu w porównaniu do października ubiegłego roku. Jest to niewątpliwie efekt konsekwentnie realizowanej strategii cyfryzacji wydawnictwa.

## Kim Kardashian i Skims: kulisy biznesu, który uczynił z niej miliarderkę
 - [https://sukces.rp.pl/ludzie/art39360141-kim-kardashian-i-skims-kulisy-biznesu-ktory-uczynil-z-niej-miliarderke](https://sukces.rp.pl/ludzie/art39360141-kim-kardashian-i-skims-kulisy-biznesu-ktory-uczynil-z-niej-miliarderke)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T16:04:51+00:00

W ciagu dekady z gwiazdy telewizji i mediów społecznościowych stała się kobietą sukcesu, matką sukcesu marki, która uczyniła z niej osobę niezwykle bogatą. W jaki sposób zbudowała swój majątek Kim Kardashian?

## Bogusław Chrabota: W dzień zaduszny myślę o Awdijiwce, izraelskich kibucach, o Gazie
 - [https://www.rp.pl/plus-minus/art39354351-boguslaw-chrabota-w-dzien-zaduszny-mysle-o-awdijiwce-izraelskich-kibucach-o-gazie](https://www.rp.pl/plus-minus/art39354351-boguslaw-chrabota-w-dzien-zaduszny-mysle-o-awdijiwce-izraelskich-kibucach-o-gazie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T16:00:00+00:00

Czy ktoś je po ludzku pochowa? Zostawi w ciepłym wspomnieniu? Jeśli ofiary brutalności historii dziejącej się na moich oczach miałyby zniknąć jak pył na wietrze, byłaby to największa kpina z sensu ludzkiego istnienia.

## Dr Andrzej Anusz: Rozegra się krwawa wojna o media
 - [https://www.rp.pl/plus-minus/art39354181-dr-andrzej-anusz-rozegra-sie-krwawa-wojna-o-media](https://www.rp.pl/plus-minus/art39354181-dr-andrzej-anusz-rozegra-sie-krwawa-wojna-o-media)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T16:00:00+00:00

Mając przeciwko sobie mocne PiS, zabetonowane instytucje konstytucyjne – NBP, Trybunał Konstytucyjny itd. – oraz prezydenta z przeciwnego obozu, rządzący będą mieli naprawdę trudno. Dlatego wybory prezydenckie zadecydują o wszystkim - mówi dr. Andrzej Anusz, politolog.

## Irena Lasota: Tłum wciąż chce złapać Żyda
 - [https://www.rp.pl/plus-minus/art39354331-irena-lasota-tlum-wciaz-chce-zlapac-zyda](https://www.rp.pl/plus-minus/art39354331-irena-lasota-tlum-wciaz-chce-zlapac-zyda)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T16:00:00+00:00

Jeśli wściekły tłum następnym razem nie znajdzie Żyda, to może obrócić się przeciwko następnemu dostępnemu celowi – władzy.

## Jak zniszczono przedwojenny socjalizm
 - [https://www.rp.pl/plus-minus/art39354281-jak-zniszczono-przedwojenny-socjalizm](https://www.rp.pl/plus-minus/art39354281-jak-zniszczono-przedwojenny-socjalizm)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T16:00:00+00:00

Komuniści musieli posłużyć się oszustwem, aby umocnić swoją władzę. Ich celem stał się konspiracyjny PPS-WRN, odwołujący się do tradycji przedwojennego socjalizmu. Sfingowany proces jego działaczy sprzed 75 laty ułatwił powstanie PZPR.

## Kataryna: Nowa władza nie uporządkuje rynku medialnego
 - [https://www.rp.pl/plus-minus/art39354321-kataryna-nowa-wladza-nie-uporzadkuje-rynku-medialnego](https://www.rp.pl/plus-minus/art39354321-kataryna-nowa-wladza-nie-uporzadkuje-rynku-medialnego)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T16:00:00+00:00

Tomasz Sakiewicz: „Zająć siłą media publiczne, bo zgodnie z prawem się nie da. Zniszczyć przy pomocy dostępnych instrumentów przemocy państwa media prywatne. Dzisiaj najważniejszym elementem walki o wolną Polskę jest walka o wolne media, przede wszystkim budowanie tych mediów, do których będzie władzy najtrudniej dotrzeć, czyli mediów prywatnych”.

## Michał Szułdrzyński: Niemcy muszą dowiedzieć się, co Polsce zrobiła III Rzesza
 - [https://www.rp.pl/plus-minus/art39354391-michal-szuldrzynski-niemcy-musza-dowiedziec-sie-co-polsce-zrobila-iii-rzesza](https://www.rp.pl/plus-minus/art39354391-michal-szuldrzynski-niemcy-musza-dowiedziec-sie-co-polsce-zrobila-iii-rzesza)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T16:00:00+00:00

Nie zbuduje się pojednania na nieświadomości Niemców o tym, co III Rzesza zrobiła w Polsce nieżydowskim ofiarom wojny.

## Najlepszy aktor na świecie
 - [https://www.rp.pl/plus-minus/art39354431-najlepszy-aktor-na-swiecie](https://www.rp.pl/plus-minus/art39354431-najlepszy-aktor-na-swiecie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T16:00:00+00:00

Ostrzę sobie zęby na „Napoleona” Ridleya Scotta. Jestem przekonany, że to będzie świetne widowisko, bo kiedy ten reżyser robi film, możemy mieć pewność, że będzie to genialne kino.

## Paweł Konzal: Rząd PiS, wbrew swej retoryce, wstydził się polskości
 - [https://www.rp.pl/plus-minus/art39354191-pawel-konzal-rzad-pis-wbrew-swej-retoryce-wstydzil-sie-polskosci](https://www.rp.pl/plus-minus/art39354191-pawel-konzal-rzad-pis-wbrew-swej-retoryce-wstydzil-sie-polskosci)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T16:00:00+00:00

W pierwszym rzędzie należy odzyskać dla Polski i państwa polskiego instytucje kultury, wyparte w ostatnich latach przez nacjonalizm. Odzyskać nie tylko w sferze organizacyjnej, ale i symbolicznej. Rząd PiS, wbrew swej retoryce, był rządem wstydzącym się polskości, a przynajmniej jej części.

## Piękna historia o tym, jak Balcerona przegrała z Albanią
 - [https://www.rp.pl/plus-minus/art39354171-piekna-historia-o-tym-jak-balcerona-przegrala-z-albania](https://www.rp.pl/plus-minus/art39354171-piekna-historia-o-tym-jak-balcerona-przegrala-z-albania)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T16:00:00+00:00

Mieszkańcy Wlory są dumni, że ich miasto było pierwszą stolicą Albanii. Z zadowoleniem obserwują, jak przyciąga coraz liczniejszych turystów, również polskich. Najchętniej wspominają jednak dzień, gdy gościła u nich wielka piłkarska Barcelona. I przegrała!

## Robert Mazurek: Złośliwa satysfakcja pewnego S.
 - [https://www.rp.pl/plus-minus/art39354361-robert-mazurek-zlosliwa-satysfakcja-pewnego-s](https://www.rp.pl/plus-minus/art39354361-robert-mazurek-zlosliwa-satysfakcja-pewnego-s)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T16:00:00+00:00

Nadmierne tempo może tylko wpędzić w zawstydzenie, o czym przekonało się wielu młodzieńców, którzy za wcześnie skończyli. U nas też idzie szybko – jeszcze nie zdążyli objąć władzy, a już się z obietnic wycofali. Na szczęście media ich natychmiast rozliczyły.

## Rumunia nie miała wyjścia – musiała poprzeć Hitlera
 - [https://www.rp.pl/plus-minus/art39354231-rumunia-nie-miala-wyjscia-musiala-poprzec-hitlera](https://www.rp.pl/plus-minus/art39354231-rumunia-nie-miala-wyjscia-musiala-poprzec-hitlera)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T16:00:00+00:00

Ze łzami spływającymi po twarzy Karol II Rumuński palił jednego papierosa za drugim. Z ostatnim szlochem Karol skinął głową. Zgodził się, by Sowieci przejęli Besarabię i północną Bukowinę. Ewakuacja wojska miała się zacząć następnego dnia rano.

## Sarina Wiegman otwiera piłkarką drzwi do męskiej szatni
 - [https://www.rp.pl/plus-minus/art39354301-sarina-wiegman-otwiera-pilkarka-drzwi-do-meskiej-szatni](https://www.rp.pl/plus-minus/art39354301-sarina-wiegman-otwiera-pilkarka-drzwi-do-meskiej-szatni)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T16:00:00+00:00

Sarina Wiegman osiągała już sukcesy z żeńskimi reprezentacjami Holandii i Anglii. To trenerka do zadań specjalnych. Drużyny cierpiące potrafi zmieniać w zespoły wojowników i zwycięzców. Teraz może otworzyć kobietom drzwi do męskiej szatni.

## Tomasz P. Terlikowski: Dziwie się oburzeniu, które wywołują moje słowa
 - [https://www.rp.pl/plus-minus/art39354341-tomasz-p-terlikowski-dziwie-sie-oburzeniu-ktore-wywoluja-moje-slowa](https://www.rp.pl/plus-minus/art39354341-tomasz-p-terlikowski-dziwie-sie-oburzeniu-ktore-wywoluja-moje-slowa)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T16:00:00+00:00

Pozostaję wierzącym katolikiem, przeciwnikiem aborcji, a także zwolennikiem prawnych jej ograniczeń. Kościół jest moim domem, choć uważam, że trzeba Go czynić nieco bardziej empatycznym. Gdzie tu jest przejście na drugą stronę?

## Tomasz Schuchardt: Aktor nie musi cierpieć, aby dobrze grać
 - [https://www.rp.pl/plus-minus/art39354251-tomasz-schuchardt-aktor-nie-musi-cierpiec-aby-dobrze-grac](https://www.rp.pl/plus-minus/art39354251-tomasz-schuchardt-aktor-nie-musi-cierpiec-aby-dobrze-grac)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T16:00:00+00:00

Cała ta narracja, że trzeba dojeżdżać aktorów, że prawdziwa sztuka rodzi się w bólach, zarówno w trakcie pracy, jak i na skutek życiowego poorania, to bzdura - mówi Tomasz Schuchardt, aktor.

## Wielkie wymieranie ukraiński zwierząt
 - [https://www.rp.pl/plus-minus/art39354311-wielkie-wymieranie-ukrainski-zwierzat](https://www.rp.pl/plus-minus/art39354311-wielkie-wymieranie-ukrainski-zwierzat)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T16:00:00+00:00

Kijów szacuje, że straty wynikające ze zniszczenia przyrody w czasie rosyjskiej inwazji przekraczają już 50 mld euro. Cierpień zwierząt domowych i tych żyjących dziko, które straciły właścicieli, domy czy naturalne siedliska, nie da się wycenić. A nadchodząca zima tylko pogorszy sytuację.

## Wina Mazurka: A może by rum?
 - [https://www.rp.pl/plus-minus/art39354381-wina-mazurka-a-moze-by-rum](https://www.rp.pl/plus-minus/art39354381-wina-mazurka-a-moze-by-rum)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T16:00:00+00:00

Po skończonej kolacji z winem, wypitym deserze (porto!), wraz z kawą przychodzi chwila na coś mocniejszego. Włosi proponują grappę, Francuzi armaniak, Gruzini czaczę, a my sięgamy po rum.

## „EA Sports FC 24”: Wiele przewrotek, by było jak zawsze
 - [https://www.rp.pl/plus-minus/art39354411-ea-sports-fc-24-wiele-przewrotek-by-bylo-jak-zawsze](https://www.rp.pl/plus-minus/art39354411-ea-sports-fc-24-wiele-przewrotek-by-bylo-jak-zawsze)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T16:00:00+00:00

Najlepsza gra piłkarska przeszła rewolucję. Ale czy na pewno?

## „Historia pracy. Nowe dzieje ludzkości”: Od polowań do spotkań online
 - [https://www.rp.pl/plus-minus/art39354271-historia-pracy-nowe-dzieje-ludzkosci-od-polowan-do-spotkan-online](https://www.rp.pl/plus-minus/art39354271-historia-pracy-nowe-dzieje-ludzkosci-od-polowan-do-spotkan-online)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T16:00:00+00:00

Nawet w erze sztucznej inteligencji praca wciąż pozostaje nie tylko sposobem na przetrwanie, ale czymś znacznie więcej.

## Rosjanie wkręcili premier Włoch. Współpracownik Meloni podał się do dymisji
 - [https://www.rp.pl/polityka/art39360161-rosjanie-wkrecili-premier-wloch-wspolpracownik-meloni-podal-sie-do-dymisji](https://www.rp.pl/polityka/art39360161-rosjanie-wkrecili-premier-wloch-wspolpracownik-meloni-podal-sie-do-dymisji)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T15:49:12+00:00

Premier Włoch Giorgia Meloni oświadczyła w piątek, że jej doradca dyplomatyczny podał się do dymisji, biorąc na siebie odpowiedzialność za dodzwonienie się do szefowej rządu przez dwóch rosyjskich komików.

## Generacja Z ma poważne problemy ze snem. Rośnie pokolenie niewyspanych
 - [https://sukces.rp.pl/spoleczenstwo/art39360131-generacja-z-ma-powazne-problemy-ze-snem-rosnie-pokolenie-niewyspanych](https://sukces.rp.pl/spoleczenstwo/art39360131-generacja-z-ma-powazne-problemy-ze-snem-rosnie-pokolenie-niewyspanych)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T15:43:33+00:00

Generacja Z ma poważne problemy ze snem – wynika z najnowszego raportu na temat jakości snu. Dlaczego młode pokolenie Z ma problemy ze snem? Odpowiedź nie zaskakuje.

## Nowy Targ. Szpital, w którym zmarła ciężarna Dorota, z certyfikatem bezpieczeństwa
 - [https://www.rp.pl/rynek-zdrowia/art39360101-nowy-targ-szpital-w-ktorym-zmarla-ciezarna-dorota-z-certyfikatem-bezpieczenstwa](https://www.rp.pl/rynek-zdrowia/art39360101-nowy-targ-szpital-w-ktorym-zmarla-ciezarna-dorota-z-certyfikatem-bezpieczenstwa)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T15:22:59+00:00

Certyfikat bezpieczeństwa dla szpitala, w którym w wyniku wstrząsu septycznego zmarła będąca w piątym miesiącu ciąży Dorota z Bochni.

## Złoty kończy tydzień z przytupem. Kurs silny słabością dolara
 - [https://www.rp.pl/waluty/art39360081-zloty-konczy-tydzien-z-przytupem-kurs-silny-slaboscia-dolara](https://www.rp.pl/waluty/art39360081-zloty-konczy-tydzien-z-przytupem-kurs-silny-slaboscia-dolara)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T15:18:18+00:00

Dane ze Stanów Zjednoczonych osłabiły dolara. To była woda na młyn dla kursu złotego.

## Bąkiewicz prawomocnie skazany za chuligaństwo wobec Babci Kasi
 - [https://www.rp.pl/prawo-karne/art39360041-bakiewicz-prawomocnie-skazany-za-chuliganstwo-wobec-babci-kasi](https://www.rp.pl/prawo-karne/art39360041-bakiewicz-prawomocnie-skazany-za-chuliganstwo-wobec-babci-kasi)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T14:46:51+00:00

Robert Bąkiewicz usłyszał prawomocny wyrok  za kierowanie wybrykiem chuligańskim, polegającym na poturbowaniu aktywistki Katarzyny Augustynek, znanej jako Babcia Kasia. Sąd Okręgowy w Warszawie utrzymał wyrok I instancji skazujący Bąkiewicza na 1 rok prac społecznych i 10 tys. nawiązki dla Babci Kasi. Zarządził też  podanie wyroku do publicznej wiadomości.

## Reżyser „Władcy Pierścieni” o nowym teledysku The Beatles "Now and Then"
 - [https://www.rp.pl/muzyka-popularna/art39359921-rezyser-wladcy-pierscieni-o-nowym-teledysku-the-beatles-now-and-then](https://www.rp.pl/muzyka-popularna/art39359921-rezyser-wladcy-pierscieni-o-nowym-teledysku-the-beatles-now-and-then)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T14:38:12+00:00

Peter Jackson ujawnił kulisy nakręcenia wideo „Now And Then”, ostatniej piosenki zespołu. Nie chciał się na to zgodzić, ale nieznane materiały z udziałem Beatlesów wciągnęły go do pracy, z której jest dumny również jako fan.

## Chcą, żeby WHO ogłosiła globalny stan zagrożenia zdrowia publicznego
 - [https://klimat.rp.pl/zdrowie/art39359961-chca-zeby-who-oglosila-globalny-stan-zagrozenia-zdrowia-publicznego](https://klimat.rp.pl/zdrowie/art39359961-chca-zeby-who-oglosila-globalny-stan-zagrozenia-zdrowia-publicznego)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T14:29:09+00:00

Naukowcy zajmujący się medycyną chcą, by Światowa Organizacja Zdrowia (WHO) ogłosiła globalny stan zagrożenia zdrowia publicznego. Podkreślają, że kryzys klimatyczny i przyrodniczy należy traktować niezwykle poważnie.

## Skarbówka wyrzuca niektórych gości z kosztów firmowej imprezy
 - [https://firma.rp.pl/pit-cit-vat/art39359841-skarbowka-wyrzuca-niektorych-gosci-z-kosztow-firmowej-imprezy](https://firma.rp.pl/pit-cit-vat/art39359841-skarbowka-wyrzuca-niektorych-gosci-z-kosztow-firmowej-imprezy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T13:49:21+00:00

Fiskus zgadza się na rozliczenie wydatków na imprezy dla pracowników i osób towarzyszących. Innych gości każe z kosztów wyrzucać.

## Przywódca Hezbollahu o ataku Hamasu na Izrael: W 100 proc. palestyńska operacja
 - [https://www.rp.pl/konflikty-zbrojne/art39359801-przywodca-hezbollahu-o-ataku-hamasu-na-izrael-w-100-proc-palestynska-operacja](https://www.rp.pl/konflikty-zbrojne/art39359801-przywodca-hezbollahu-o-ataku-hamasu-na-izrael-w-100-proc-palestynska-operacja)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T13:45:46+00:00

Hassan Nastrallah, przywódca Hezbollahu, w swoim pierwszym przemówieniu wygłoszonym publicznie po ataku Hamasu na Izrael z 7 października mówił, że plany operacji "Burza Al-Aksa" były przygotowywane w tajemnicy i nawet nie wszyscy członkowie Hamasu je znali.

## W tych miastach Polski smog truje najbardziej
 - [https://klimat.rp.pl/smog/art39359811-w-tych-miastach-polski-smog-truje-najbardziej](https://klimat.rp.pl/smog/art39359811-w-tych-miastach-polski-smog-truje-najbardziej)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T13:34:38+00:00

Smog wciąż truje ale nieco mniej. We wszystkich miejscowościach objętych monitoringiem GIOŚ średnioroczne stężenie pyłów PM10 było w normie - zdarzyło się to pierwszy raz od początku publikacji smogowego rankingu miast.

## Wdowa po Prezydencie Adamowiczu wygrała kolejną batalię z fiskusem
 - [https://www.rp.pl/podatki/art39359321-wdowa-po-prezydencie-adamowiczu-wygrala-kolejna-batalie-z-fiskusem](https://www.rp.pl/podatki/art39359321-wdowa-po-prezydencie-adamowiczu-wygrala-kolejna-batalie-z-fiskusem)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T13:23:04+00:00

Naczelny Sąd Administracyjny uwzględnił skargi kasacyjne Magdaleny Adamowicz w sprawie podatku od najmu mieszkań.

## Zbadano, dlaczego Polacy przechodzą na weganizm. Zaskakujące wyniki
 - [https://kobieta.rp.pl/kuchnia/art39359611-zbadano-dlaczego-polacy-przechodza-na-weganizm-zaskakujace-wyniki](https://kobieta.rp.pl/kuchnia/art39359611-zbadano-dlaczego-polacy-przechodza-na-weganizm-zaskakujace-wyniki)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T13:17:00+00:00

Wśród Polaków sukcesywnie wzrasta liczba zwolenników wegańskiego stylu życia. Najnowsze badanie pokazuje, co stanowi najsilniejszą motywację do dokonania takiego wyboru.

## Amerykański rynek pracy osłabł. Dane gorsze od prognoz
 - [https://www.rp.pl/rynek-pracy/art39359741-amerykanski-rynek-pracy-oslabl-dane-gorsze-od-prognoz](https://www.rp.pl/rynek-pracy/art39359741-amerykanski-rynek-pracy-oslabl-dane-gorsze-od-prognoz)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T13:15:47+00:00

W październiku przybyło w gospodarce amerykańskiej (licząc poza rolnictwem) 150 tys. etatów. Średnio prognozowano, że ich liczba wzrośnie o 180 tys. Dane za wrzesień zrewidowano z 336 tys. do 297 tys., a za sierpień z 227 tys. do 165 tys.

## Piotr Balcerowski: Zielone inwestycje w Polsce muszą być kontynuowane
 - [https://www.rp.pl/opinie-ekonomiczne/art39359711-piotr-balcerowski-zielone-inwestycje-w-polsce-musza-byc-kontynuowane](https://www.rp.pl/opinie-ekonomiczne/art39359711-piotr-balcerowski-zielone-inwestycje-w-polsce-musza-byc-kontynuowane)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T13:12:00+00:00

Zapewne już tylko tygodnie dzielą nas od zmian na szczytach spółek kontrolowanych przez Skarb Państwa, w tym narodowego koncernu multienergetycznego – Orlenu. Prezes Daniel Obajtek publicznie deklarował, że gdy zostanie powołany nowy rząd, złoży rezygnację. Czas więc na bilans: jaki Orlen ustępująca ekipa zostawia, szczególnie w zakresie ambitnych planów związanych z OZE. Tym bardziej, że i dzisiejszy dzień – 2 listopada mija równo rok od finalizacji fuzji Orlenu z Lotosem i PGNiG – skłania do podsumowań.

## Aleksandr Łukaszenko mówi o stosunkach z Polską. Wyraża nadzieję na poprawę
 - [https://www.rp.pl/dyplomacja/art39359641-aleksandr-lukaszenko-mowi-o-stosunkach-z-polska-wyraza-nadzieje-na-poprawe](https://www.rp.pl/dyplomacja/art39359641-aleksandr-lukaszenko-mowi-o-stosunkach-z-polska-wyraza-nadzieje-na-poprawe)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T13:04:06+00:00

Przywódca Białorusi, Aleksandr Łukaszenko mówił, że relacje jego kraju z Polską i Litwą "bez wątpienia zostaną przywrócone w przyszłości".

## Tomasz Pietryga: Tusk mówił o wspieraniu biznesu, Lewica chce ścigać przedsiębiorców
 - [https://www.rp.pl/opinie-prawne/art39359661-tomasz-pietryga-tusk-mowil-o-wspieraniu-biznesu-lewica-chce-scigac-przedsiebiorcow](https://www.rp.pl/opinie-prawne/art39359661-tomasz-pietryga-tusk-mowil-o-wspieraniu-biznesu-lewica-chce-scigac-przedsiebiorcow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T12:56:00+00:00

Jeżeli politycy opozycji szybko nie ukrócą antyrynkowych pomysłów, takich jak tzw. test przedsiębiorcy, kapitał zaufania uzyskany w wyborach - szybko zostanie roztrwoniony.

## Prof. Romanowski: "złote spadochrony" z TVP są do podważenia
 - [https://www.rp.pl/abc-firmy/art39359571-prof-romanowski-zlote-spadochrony-z-tvp-sa-do-podwazenia](https://www.rp.pl/abc-firmy/art39359571-prof-romanowski-zlote-spadochrony-z-tvp-sa-do-podwazenia)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T12:48:59+00:00

Pośpieszne zmiany umów, dające twarzom TVP większe odprawy i zakazy konkurencji są możliwe do unieważnienia na ścieżce cywilnej, może też wchodzić w grę odpowiedzialność karna – mówi prof. Michał Romanowski.

## Dmitrij Miedwiediew o możliwości starcia Polski z Rosją. Kreml komentuje
 - [https://www.rp.pl/polityka/art39359451-dmitrij-miedwiediew-o-mozliwosci-starcia-polski-z-rosja-kreml-komentuje](https://www.rp.pl/polityka/art39359451-dmitrij-miedwiediew-o-mozliwosci-starcia-polski-z-rosja-kreml-komentuje)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T12:47:12+00:00

Dmitrij Miedwiediew przedstawił bardzo dogłębną analizę sytuacji, kreśląc hipotetycznie istniejące scenariusze - tak rzecznik Kremla Dmitrij Pieskow skomentował artykuł, w którym były prezydent Rosji napisał o możliwości bezpośredniego starcia Polski z Białorusią i Rosją.

## Biały Dom trafił w cel: nowe sankcje uderzą w rosyjskie banki, gaz i giełdę
 - [https://www.rp.pl/biznes/art39359341-bialy-dom-trafil-w-cel-nowe-sankcje-uderza-w-rosyjskie-banki-gaz-i-gielde](https://www.rp.pl/biznes/art39359341-bialy-dom-trafil-w-cel-nowe-sankcje-uderza-w-rosyjskie-banki-gaz-i-gielde)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T12:31:52+00:00

Rosyjskie banki prywatne, największa gazowa inwestycja Rosji, giełda w St. Petersburgu, sojusznicze firmy ze Zjednoczonych Emiratów Arabskich, ale też główny konstruktor broni dla rosyjskiej armii - zostały objęte amerykańskimi sankcjami.

## Ochrona zdrowia - pieniądze są, tylko trzeba wydawać je efektywniej. Debata TEP i „Rzeczpospolitej”
 - [https://www.rp.pl/gospodarka/art39359591-ochrona-zdrowia-pieniadze-sa-tylko-trzeba-wydawac-je-efektywniej-debata-tep-i-rzeczpospolitej](https://www.rp.pl/gospodarka/art39359591-ochrona-zdrowia-pieniadze-sa-tylko-trzeba-wydawac-je-efektywniej-debata-tep-i-rzeczpospolitej)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T12:30:52+00:00

W debacie o ochronie zdrowia tematem przewodnim stała się odpowiedź na pytanie, czy i jak można efektywniej wykorzystać pieniądze przeznaczone na ochronę zdrowia w Polsce. Wielu uważa, że w systemie jest za mało pieniędzy. Ale wiadomo, że  można dorzucać pieniędzy bez liku, a zawsze ich będzie za mało.

## Podróżujesz za granicą? Możesz spotkać ten znak - zobacz co oznacza
 - [https://www.rp.pl/prawo-drogowe/art39359501-podrozujesz-za-granica-mozesz-spotkac-ten-znak-zobacz-co-oznacza](https://www.rp.pl/prawo-drogowe/art39359501-podrozujesz-za-granica-mozesz-spotkac-ten-znak-zobacz-co-oznacza)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T12:22:52+00:00

Na francuskich drogach coraz częściej pojawia się nowy znak drogowy w kształcie rombu na niebieskim tle. Warto go znać, bo za jego zignorowanie grożą surowe mandaty. Czy zobaczymy ten znak również w Polsce?

## Fundusze spekulacyjne zarabiają, ale za mało
 - [https://www.rp.pl/finanse/art39358191-fundusze-spekulacyjne-zarabiaja-ale-za-malo](https://www.rp.pl/finanse/art39358191-fundusze-spekulacyjne-zarabiaja-ale-za-malo)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T12:06:32+00:00

Fundusze podwyższonego ryzyka (spekulacyjne) zarobiły przez 12 miesięcy (do 18 października) 119 mld dolarów, ale inwestorzy wycofali z nich 80 mld, bo szukali większych zysków gdzie indziej — ocenił specjalistyczny Aurum Funds.

## Powstaje kolejna dywizja Wojska Polskiego. Na papierze
 - [https://www.rp.pl/wojsko/art39359421-powstaje-kolejna-dywizja-wojska-polskiego-na-papierze](https://www.rp.pl/wojsko/art39359421-powstaje-kolejna-dywizja-wojska-polskiego-na-papierze)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T11:59:06+00:00

Minister Obrony Narodowej Mariusz Błaszczak podpisał właśnie dokument o formowaniu kolejnej, szóstej dywizji Wojska Polskiego. Sęk w tym, że armia narzeka na deficyt żołnierzy i w już istniejących jednostkach są wakaty.

## Produkcja wołowiny odpowiedzialna za większość emisji Brazylii
 - [https://klimat.rp.pl/emisje/art39359471-produkcja-wolowiny-odpowiedzialna-za-wiekszosc-emisji-brazylii](https://klimat.rp.pl/emisje/art39359471-produkcja-wolowiny-odpowiedzialna-za-wiekszosc-emisji-brazylii)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T11:47:48+00:00

Nowe badanie wykazało, że ponad trzy czwarte emisji gazów cieplarnianych generowanych przez przemysł spożywczy w Brazylii pochodzi z produkcji wołowiny.

## Chiński myśliwiec mógł zestrzelić kanadyjski śmigłowiec
 - [https://www.rp.pl/dyplomacja/art39359411-chinski-mysliwiec-mogl-zestrzelic-kanadyjski-smiglowiec](https://www.rp.pl/dyplomacja/art39359411-chinski-mysliwiec-mogl-zestrzelic-kanadyjski-smiglowiec)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T11:47:43+00:00

Chiński myśliwiec wystrzelił flary przed kanadyjskim śmigłowcem nad wodami międzynarodowymi Morza Południowochińskiego - informuje CNN cytując przedstawicieli kanadyjskiej armii.

## Atak maczetą na warszawskich Bielanach. Są ranni
 - [https://www.rp.pl/przestepczosc/art39359431-atak-maczeta-na-warszawskich-bielanach-sa-ranni](https://www.rp.pl/przestepczosc/art39359431-atak-maczeta-na-warszawskich-bielanach-sa-ranni)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T11:42:00+00:00

Na warszawskich Bielanach mężczyzna ranił maczetą co najmniej dwie osoby. Policja poszukuje napastnika – wciąż może mieć przy sobie broń.

## Karczewski: W czasie kampanii były momenty, kiedy o Tusku było za dużo
 - [https://www.rp.pl/polityka/art39359301-karczewski-w-czasie-kampanii-byly-momenty-kiedy-o-tusku-bylo-za-duzo](https://www.rp.pl/polityka/art39359301-karczewski-w-czasie-kampanii-byly-momenty-kiedy-o-tusku-bylo-za-duzo)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T11:22:00+00:00

Zabrakło oferty dla młodych ludzi, chociaż mamy taką ofertę. Powinniśmy zachęcić młodych. Niezdecydowani to bardzo różnorodna grupa i dla tej grupy trzeba mieć różnorodny przekaz, nie tylko krytyki, ale również oferty - powiedział w Polsat News senator PiS Stanisław Karczewski.

## Sąd: prezes Nawacki ma cofnąć karne przeniesienie sędziego Juszczyszyna
 - [https://www.rp.pl/sady-i-trybunaly/art39359311-sad-prezes-nawacki-ma-cofnac-karne-przeniesienie-sedziego-juszczyszyna](https://www.rp.pl/sady-i-trybunaly/art39359311-sad-prezes-nawacki-ma-cofnac-karne-przeniesienie-sedziego-juszczyszyna)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T11:20:42+00:00

Sąd Okręgowy w Bydgoszczy prawomocnie nakazał przywrócić sędziego Pawła Juszczyszyna do orzekania w macierzystym wydziale cywilnym - informuje portal oko.press.

## Rotacyjny Marszałek Sejmu? „Trudniej prowadzić obrady niż 'Mam talent'”
 - [https://www.rp.pl/polityka/art39359231-rotacyjny-marszalek-sejmu-trudniej-prowadzic-obrady-niz-mam-talent](https://www.rp.pl/polityka/art39359231-rotacyjny-marszalek-sejmu-trudniej-prowadzic-obrady-niz-mam-talent)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T11:01:50+00:00

– Jest teoria, że bycie marszałkiem Sejmu to będzie prezydencka trampolina dla Szymona Hołowni. Ale w polityce to co jest trampoliną, staje się fosą w którą można wpaść – mówił w podcaście Polityczne Michałki Michał Kolanko.

## Polscy obywatele w Strefie Gazy apelują do MSZ o pomoc. Żądają ewakuacji
 - [https://www.rp.pl/konflikty-zbrojne/art39359201-polscy-obywatele-w-strefie-gazy-apeluja-do-msz-o-pomoc-zadaja-ewakuacji](https://www.rp.pl/konflikty-zbrojne/art39359201-polscy-obywatele-w-strefie-gazy-apeluja-do-msz-o-pomoc-zadaja-ewakuacji)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T10:50:00+00:00

28 osób z polskimi paszportami, które przebywają w Strefie Gazy, apelują do polskich władz o pomoc. - Ambasada nic nie wie.  Jesteśmy rozczarowani ich podejściem do tego wszystkiego - powiedział w rozmowie z OKO.press jeden z polskich obywateli uwięzionych w Gazie.

## PKO BP Ekstraklasa. Pogoń Szczecin goni czołówkę
 - [https://www.rp.pl/pilka-nozna/art39358761-pko-bp-ekstraklasa-pogon-szczecin-goni-czolowke](https://www.rp.pl/pilka-nozna/art39358761-pko-bp-ekstraklasa-pogon-szczecin-goni-czolowke)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T10:40:09+00:00

Pogoń Szczecin jeszcze pod koniec września zajmowała w tabeli PKO BP Ekstraklasy dziesiąte miejsce. Październik był jednak dla zespołu wyjątkowo udany.

## Byki na GPW nie chcą zwalniać tempa
 - [https://www.rp.pl/gielda/art39359181-byki-na-gpw-nie-chca-zwalniac-tempa](https://www.rp.pl/gielda/art39359181-byki-na-gpw-nie-chca-zwalniac-tempa)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T10:34:03+00:00

Kolor zielony przeważał na początku sesji na GPW. Gwiazdą sesji jest firma Dino.

## Sto procent gazu w polskich magazynach. Ale czy to wystarczy?
 - [https://energia.rp.pl/gaz/art39359011-sto-procent-gazu-w-polskich-magazynach-ale-czy-to-wystarczy](https://energia.rp.pl/gaz/art39359011-sto-procent-gazu-w-polskich-magazynach-ale-czy-to-wystarczy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T10:31:04+00:00

Zapełnione pod korek podziemne magazyny gazu (PMG) w Polsce wystarczą na 18 proc. krajowego rocznego zapotrzebowania. Resztę musi zapewnić gazociąg Baltic Pipe i gazoport.

## Rafako znów na lodzie. „Pozorowany ratunek”?
 - [https://energia.rp.pl/energetyka-zawodowa/art39359161-rafako-znow-na-lodzie-pozorowany-ratunek](https://energia.rp.pl/energetyka-zawodowa/art39359161-rafako-znow-na-lodzie-pozorowany-ratunek)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T10:29:17+00:00

Z końcem października wygasła wyłączność PG Energy Capital Management na rozmowy dotyczące przejęcia raciborskiej spółki. Prezes potencjalnego inwestora Paweł Gryciuk, który był członkiem rady nadzorczej firmy, złożył rezygnacje. W tle rozgorzał spór między byłym prezesem Rafako a Polskim Funduszem Rozwoju TFI, który zwiększył w ostatnim czasie swoje zainteresowanie większą kontrolą nad spółką.

## Rosjanie chcą, by ranni żołnierze szybciej wracali do służby
 - [https://www.rp.pl/konflikty-zbrojne/art39359071-rosjanie-chca-by-ranni-zolnierze-szybciej-wracali-do-sluzby](https://www.rp.pl/konflikty-zbrojne/art39359071-rosjanie-chca-by-ranni-zolnierze-szybciej-wracali-do-sluzby)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T10:22:51+00:00

Ministerstwo Obrony Rosji proponuje zmiany w przepisach, które umożliwią szybszy powrót do służby rannym żołnierzom kontraktowym pełniącym służbę w jednostkach wojsk powietrzno-desantowych.

## KO obiecywała 60 tys. kwoty wolnej. Wiceszefowa Polski 2050: Nie widzę przestrzeni
 - [https://www.rp.pl/polityka/art39358791-ko-obiecywala-60-tys-kwoty-wolnej-wiceszefowa-polski-2050-nie-widze-przestrzeni](https://www.rp.pl/polityka/art39358791-ko-obiecywala-60-tys-kwoty-wolnej-wiceszefowa-polski-2050-nie-widze-przestrzeni)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T10:13:49+00:00

- Nie widzę przestrzeni w ustawie budżetowej do wprowadzenia kwoty wolnej do 60 tys. zł - powiedziała wiceprzewodnicząca Polski 2050 Szymona Hołowni Paulina Hennig-Kloska. W rozmowie z Radiem Zet posłanka przekazała, że umowa koalicyjna między KO, Trzecią Drogą i Lewicą jest "prawie gotowa". Obiecywane przed wyborami 30-proc. podwyżki dla nauczycieli nie zostały w umowie ujęte procentowo - podała.

## Ekspertka Koalicji Klimatycznej: Kobiety ponoszą większe konsekwencje zmiany klimatu
 - [https://kobieta.rp.pl/wywiad/art39341381-ekspertka-koalicji-klimatycznej-kobiety-ponosza-wieksze-konsekwencje-zmiany-klimatu](https://kobieta.rp.pl/wywiad/art39341381-ekspertka-koalicji-klimatycznej-kobiety-ponosza-wieksze-konsekwencje-zmiany-klimatu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T10:09:41+00:00

Kobiece organizmy są relatywnie delikatniejsze od męskich i podlegają intensywnym wahaniom hormonalnym - mówi Weronika Michalak.

## Wraca pomysł "testu przedsiębiorcy". Zapowiada go ważna polityk Lewicy
 - [https://www.rp.pl/abc-firmy/art39358951-wraca-pomysl-testu-przedsiebiorcy-zapowiada-go-wazna-polityk-lewicy](https://www.rp.pl/abc-firmy/art39358951-wraca-pomysl-testu-przedsiebiorcy-zapowiada-go-wazna-polityk-lewicy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T10:03:00+00:00

Senator Lewicy i współprzewodnicząca partii Razem - Magdalena Biejat - stwierdziła, że należy wrócić do dyskusji na temat wprowadzenia tzw. testu przedsiębiorcy.

## 16-latek wywołał 18 pożarów. Stanie przed Sądem Rodzinnym
 - [https://www.rp.pl/prawo-karne/art39358991-16-latek-wywolal-18-pozarow-stanie-przed-sadem-rodzinnym](https://www.rp.pl/prawo-karne/art39358991-16-latek-wywolal-18-pozarow-stanie-przed-sadem-rodzinnym)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T09:55:08+00:00

Policja poinformowała, że Sąd rodzinny i nieletnich zajmie się szesnastolatkiem, który dokonywał podpaleń w gminie Smętowo Graniczne w województwie pomorskim. Straty po 18 pożarach wznieconych przez nastolatka wyceniono na 70 tys. zł.

## Nie tylko mundial. Zimowe igrzyska też odbędą się na pustyni
 - [https://www.rp.pl/sporty-zimowe/art39358731-nie-tylko-mundial-zimowe-igrzyska-tez-odbeda-sie-na-pustyni](https://www.rp.pl/sporty-zimowe/art39358731-nie-tylko-mundial-zimowe-igrzyska-tez-odbeda-sie-na-pustyni)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T09:48:24+00:00

Arabia Saudyjska zorganizuje zimowe igrzyska azjatyckie w kurorcie, który istnieje tylko na papierze, bo książę koronny Mohammed bin Salman chce na nowo zdefiniować turystykę górską.

## Zabójstwo 6-latka w Gdyni: Zawężono obszar poszukiwań Grzegorza Borysa
 - [https://www.rp.pl/przestepczosc/art39358981-zabojstwo-6-latka-w-gdyni-zawezono-obszar-poszukiwan-grzegorza-borysa](https://www.rp.pl/przestepczosc/art39358981-zabojstwo-6-latka-w-gdyni-zawezono-obszar-poszukiwan-grzegorza-borysa)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T09:44:00+00:00

Wciąż prowadzone jest poszukiwanie 44-letniego Grzegorza Borysa, który podejrzany jest o zabójstwo sześcioletniego chłopca w Gdyni. Policja zdecydowała o zawężeniu terenu poszukiwań do 2 hektarów.

## Zmasowany atak rosyjskich dronów na Ukrainę. Cele m.in. blisko granicy z Polską
 - [https://www.rp.pl/konflikty-zbrojne/art39358831-zmasowany-atak-rosyjskich-dronow-na-ukraine-cele-m-in-blisko-granicy-z-polska](https://www.rp.pl/konflikty-zbrojne/art39358831-zmasowany-atak-rosyjskich-dronow-na-ukraine-cele-m-in-blisko-granicy-z-polska)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T09:36:52+00:00

40 dronów-kamikadze użyła Rosja w czasie nocnego, najintensywniejszego od tygodni ataku powietrznego na cele na Ukrainie.

## Kurs złotego nieco słabszy o poranku
 - [https://www.rp.pl/waluty/art39358811-kurs-zlotego-nieco-slabszy-o-poranku](https://www.rp.pl/waluty/art39358811-kurs-zlotego-nieco-slabszy-o-poranku)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T09:32:20+00:00

Kurs złotego w piątek rano notował niewielkie zmiany. Prawdziwe atrakcje są jednak przed nami.

## Ambitny program Japonii: złagodzić skutki inflacji
 - [https://www.rp.pl/gospodarka/art39358181-ambitny-program-japonii-zlagodzic-skutki-inflacji](https://www.rp.pl/gospodarka/art39358181-ambitny-program-japonii-zlagodzic-skutki-inflacji)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T09:27:56+00:00

Rząd Japonii przygotował nowy pakiet działań na sumę 17 bln jenów (106,7 mld euro) na pobudzenie gospodarki i złagodzenie wpływu inflacji. Może to jednak pogorszyć stan finansów publicznych, który i tak nie jest najlepszy.

## Reuters: Pięć koreańskich banków pożyczy Polsce miliardy dolarów na broń
 - [https://www.rp.pl/banki/art39358871-reuters-piec-koreanskich-bankow-pozyczy-polsce-miliardy-dolarow-na-bron](https://www.rp.pl/banki/art39358871-reuters-piec-koreanskich-bankow-pozyczy-polsce-miliardy-dolarow-na-bron)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T09:27:00+00:00

Korea Południowa buduje konsorcjum lokalnych banków, aby pomóc Polsce kupić broń o wartości 22 miliardów dolarów w ramach największej jak dotąd tego rodzaju transakcji - powiedziało agencji Reuters pięć osób zaznajomionych ze sprawą.

## Śmiertelny wypadek podczas jazdy na autopilocie to nie wina Tesli. Tak orzekł sąd
 - [https://moto.rp.pl/tu-i-teraz/art39358691-smiertelny-wypadek-podczas-jazdy-na-autopilocie-to-nie-wina-tesli-tak-orzekl-sad](https://moto.rp.pl/tu-i-teraz/art39358691-smiertelny-wypadek-podczas-jazdy-na-autopilocie-to-nie-wina-tesli-tak-orzekl-sad)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T09:26:22+00:00

Podczas procesu, obrońcy ze strony Tesli przekonali ławę przysięgłych, że zastosowana w samochodzie technologia nie była odpowiedzialna za śmiertelny wypadek, który miał miejsce w cztery lata temu w Kalifornii.

## Forte szuka oszczędności. Zwolni do 230 osób
 - [https://www.rp.pl/biznes/art39358931-forte-szuka-oszczednosci-zwolni-do-230-osob](https://www.rp.pl/biznes/art39358931-forte-szuka-oszczednosci-zwolni-do-230-osob)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T09:22:42+00:00

Zarząd meblarskiej grupy podjął decyzję o przeprowadzeniu zwolnień grupowych i rozpoczęciu rozmów z przedstawicielami związków zawodowych.

## Terroryści z Hamasu mogą być sądzeni jak Adolf Eichmann
 - [https://www.rp.pl/za-granica/art39358781-terrorysci-z-hamasu-moga-byc-sadzeni-jak-adolf-eichmann](https://www.rp.pl/za-granica/art39358781-terrorysci-z-hamasu-moga-byc-sadzeni-jak-adolf-eichmann)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T09:22:00+00:00

Izrael rozważa powołanie specjalnych sądów, które miałyby sądzić terrorystów Hamasu złapanych po 7 października - donosi "The Jerusalem Post". Gazeta zwraca uwagę na swoim portalu, że byłaby to powtórka ze słynnego procesu Adolfa Eichmanna, człowieka obwołanego "architektem Holokaustu".

## Niemcy w zastoju. Bezrobocie było w październiku większe od przewidywanego
 - [https://www.rp.pl/rynek-pracy/art39358171-niemcy-w-zastoju-bezrobocie-bylo-w-pazdzierniku-wieksze-od-przewidywanego](https://www.rp.pl/rynek-pracy/art39358171-niemcy-w-zastoju-bezrobocie-bylo-w-pazdzierniku-wieksze-od-przewidywanego)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T09:20:47+00:00

Liczba Niemców szukających pracy w październiku zwiększyła się o 30 tys., do 2,678 mln, czyli o 1 punkt procentowy wobec września, do 5,8 proc. — podał urząd zatrudnienia. Analitycy pytani wcześniej przez Reutera szacowali liczbę nowych bezrobotnych na 15 tys. osób.

## Rośnie liczba ofiar orkanu Ciaran. W piątek żywioł dotrze do Polski
 - [https://www.rp.pl/spoleczenstwo/art39358801-rosnie-liczba-ofiar-orkanu-ciaran-w-piatek-zywiol-dotrze-do-polski](https://www.rp.pl/spoleczenstwo/art39358801-rosnie-liczba-ofiar-orkanu-ciaran-w-piatek-zywiol-dotrze-do-polski)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T09:19:00+00:00

Rośnie liczba ofiar śmiertelnych huraganu Ciaran, który uderzył w Europę. W Polsce orkan pojawi się w piątek – przewiduje się, że w niektórych częściach kraju wiatr może osiągnąć prędkość 100 km/h.

## Izrael chce stworzyć Trybunał, który osądzi sprawców ataku z 7 października
 - [https://www.rp.pl/konflikty-zbrojne/art39358671-izrael-chce-stworzyc-trybunal-ktory-osadzi-sprawcow-ataku-z-7-pazdziernika](https://www.rp.pl/konflikty-zbrojne/art39358671-izrael-chce-stworzyc-trybunal-ktory-osadzi-sprawcow-ataku-z-7-pazdziernika)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T09:00:20+00:00

Izraelski nadawca publiczny Kan podał, że Izrael planuje stworzenie specjalnego Trybunału, który zająłby się postępowaniami karnymi wobec setek terrorystów biorących udział w ataku Hamasu na Izrael z 7 października.

## Agnieszka Dziemanowicz-Bąk: W edukacji trzeba patrzeć w przyszłość zamiast przeszłość
 - [https://www.rp.pl/plus-minus/art39354121-agnieszka-dziemanowicz-bak-w-edukacji-trzeba-patrzec-w-przyszlosc-zamiast-przeszlosc](https://www.rp.pl/plus-minus/art39354121-agnieszka-dziemanowicz-bak-w-edukacji-trzeba-patrzec-w-przyszlosc-zamiast-przeszlosc)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T09:00:00+00:00

Zgadzam się z prof. Matczakiem. Nie potrzebujemy szkoły radykalnej – potrzebujemy szkoły, która będzie bezpiecznym miejscem nauki i rozwoju dla uczniów, dobrym miejscem pracy dla nauczycieli i pracowników niepedagogicznych, oraz – przede wszystkim – szkoły przewidywalnej - mówi Agnieszka Dziemianowicz-Bąk, posłanka Lewicy.

## Dzieci uciekają ze szkoły. Rodzice też
 - [https://www.rp.pl/plus-minus/art39354141-dzieci-uciekaja-ze-szkoly-rodzice-tez](https://www.rp.pl/plus-minus/art39354141-dzieci-uciekaja-ze-szkoly-rodzice-tez)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T09:00:00+00:00

Tradycyjna szkoła powoli odchodzi do lamusa, na co złożyło się wiele czynników. Rodzice przestali wierzyć w skuteczność powszechnej edukacji i zamiast tego stawiają na tę domową, na placówki niepubliczne czy płatne korepetycje. W efekcie nierówności społeczne się pogłębiają.

## Jak Wanda Półtawska wpłynęła na Jana Pawła II
 - [https://www.rp.pl/plus-minus/art39354161-jak-wanda-poltawska-wplynela-na-jana-pawla-ii](https://www.rp.pl/plus-minus/art39354161-jak-wanda-poltawska-wplynela-na-jana-pawla-ii)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T09:00:00+00:00

Śmierć Wandy Półtawskiej symbolicznie zamyka pewien okres dziejów i myślenia Kościoła. Jej przyjaźń z Karolem Wojtyłą i ich wzajemna intelektualno-duchowa relacja miały znaczący wpływ na teologię ciała i papieską etykę seksualną. Istotnym pytaniem dla teologów, filozofów i analityków życia kościelnego pozostaje, czy ten wpływ zawsze był pozytywny.

## Jak upadał autorytet nauczyciela
 - [https://www.rp.pl/plus-minus/art39354131-jak-upadal-autorytet-nauczyciela](https://www.rp.pl/plus-minus/art39354131-jak-upadal-autorytet-nauczyciela)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T09:00:00+00:00

Nowy rząd zapowiada rychłe podwyżki dla nauczycieli, sądząc, że w ten sposób odbuduje ich autorytet. Jednak nie ma pomysłu na to, jak poradzić sobie z roszczeniowymi rodzicami oraz zapatrzonymi w smartfony uczniami. Znów podnoszą się głosy o konieczności stworzenia szkoły bezstresowej i niewymagającej żadnego wysiłku, bo teraz to tylko zapaść i pruski rygor. Czy rzeczywiście z polską szkołą jest aż tak źle?

## Jak zarobić na Pokemonach i zapalniczkach?
 - [https://www.rp.pl/plus-minus/art39354151-jak-zarobic-na-pokemonach-i-zapalniczkach](https://www.rp.pl/plus-minus/art39354151-jak-zarobic-na-pokemonach-i-zapalniczkach)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T09:00:00+00:00

Inwestycje kojarzą się zazwyczaj z panami w garniturach, skomplikowanymi tabelkami, a także z koniecznością posiadania jako takiego rozeznania w ekonomii. Jednak inwestować można również alternatywnie – w zegarki, zapalniczki, klocki Lego, karty z Pokémonami. Jedno się nie zmienia – potrzebna jest wiedza oraz smykałka do biznesu.

## Józef Hen: Warto mieć talent, ale natchnienie bywa problematyczne
 - [https://www.rp.pl/plus-minus/art39354211-jozef-hen-warto-miec-talent-ale-natchnienie-bywa-problematyczne](https://www.rp.pl/plus-minus/art39354211-jozef-hen-warto-miec-talent-ale-natchnienie-bywa-problematyczne)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T09:00:00+00:00

Unikam wielkich słów. Wolę więc powiedzieć: pisarz ma nie kłamać. I dodam w tajemnicy: warto też mieć talent, a z natchnieniem bym uważał – mówi Józef Hen, który 8 listopada kończy 100 lat - mówi Józef Hen, pisarz.

## „Lęk” Sławomira Fabickiego – nieoczywista rozprawa o eutanazji
 - [https://www.rp.pl/plus-minus/art39354201-lek-slawomira-fabickiego-nieoczywista-rozprawa-o-eutanazji](https://www.rp.pl/plus-minus/art39354201-lek-slawomira-fabickiego-nieoczywista-rozprawa-o-eutanazji)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T09:00:00+00:00

„Lęk” Sławomira Fabickiego, całkowicie niedoceniony na festiwalu w Gdyni, choć ten bardzo ważny film z Magdaleną Cielecką i Martą Nieradkiewicz wpisuje się w falę filmów o eutanazji.

## Twój Profil Zaufany wygasł? Oto co trzeba teraz zrobić
 - [https://www.rp.pl/w-sadzie-i-w-urzedzie/art39358661-twoj-profil-zaufany-wygasl-oto-co-trzeba-teraz-zrobic](https://www.rp.pl/w-sadzie-i-w-urzedzie/art39358661-twoj-profil-zaufany-wygasl-oto-co-trzeba-teraz-zrobic)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T08:35:29+00:00

We wtorek 31 października minął termin na przedłużenie Profilu Zaufanego. Co zrobić, jeśli nie przedłużyliśmy jego ważności i profil zaufany wygasł?

## Sondaż: Przeważająca większość Rosjan zadowolona z Władimira Putina
 - [https://www.rp.pl/polityka/art39358541-sondaz-przewazajaca-wiekszosc-rosjan-zadowolona-z-wladimira-putina](https://www.rp.pl/polityka/art39358541-sondaz-przewazajaca-wiekszosc-rosjan-zadowolona-z-wladimira-putina)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T08:28:28+00:00

Większość mieszkańców Rosji popiera działania prezydenta swego kraju Władimira Putina - wynika z najnowszego sondażu.

## Bajka dla dzieci, świat wewnętrzny mordercy i trudne dylematy współczesności
 - [https://www.rp.pl/film/art39358361-bajka-dla-dzieci-swiat-wewnetrzny-mordercy-i-trudne-dylematy-wspolczesnosci](https://www.rp.pl/film/art39358361-bajka-dla-dzieci-swiat-wewnetrzny-mordercy-i-trudne-dylematy-wspolczesnosci)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T08:23:00+00:00

Na co wybrać się do kina w nadchodzący weekend? „Lęk” Sławomira Fabickiego z Magdaleną Cielecką i Martą Nieradkiewicz po prostu trzeba obejrzeć. Z dziećmi warto pójść na „Kajtka Czarodzieja”, a wytrwałym polecam nietypową opowieść o płatnym mordercy „Zabójcę” Davida Finchera.

## Dariusz Wieczorek: Nie da się całego programu przenieść do umowy koalicyjnej
 - [https://www.rp.pl/polityka/art39358571-dariusz-wieczorek-nie-da-sie-calego-programu-przeniesc-do-umowy-koalicyjnej](https://www.rp.pl/polityka/art39358571-dariusz-wieczorek-nie-da-sie-calego-programu-przeniesc-do-umowy-koalicyjnej)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T08:22:47+00:00

W drafcie umowy koalicyjnej są zapisy dotyczące praw kobiet, to bardzo istotny punkt - mówił w rozmowie z Michałem Kolanką poseł Nowej Lewicy, sekretarz klubu Nowej Lewicy w Sejmie Dariusz Wieczorek.

## Sam Bankman-Fried uznany za winnego. Założycielowi FTX grozi 115 lat więzienia
 - [https://www.rp.pl/waluty/art39358471-sam-bankman-fried-uznany-za-winnego-zalozycielowi-ftx-grozi-115-lat-wiezienia](https://www.rp.pl/waluty/art39358471-sam-bankman-fried-uznany-za-winnego-zalozycielowi-ftx-grozi-115-lat-wiezienia)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T08:16:18+00:00

Ława przysięgłych uznała Sama Bankmana-Frieda, założyciela giełdy kryptowalutowej FTX, za winnego siedmiu zarzutów oszustwa. Grozi mu nawet 115 lat więzienia.

## Nowe BMW i3 będzie wyglądało jak „prawdziwe” BMW
 - [https://moto.rp.pl/na-prad/art39358531-nowe-bmw-i3-bedzie-wygladalo-jak-prawdziwe-bmw](https://moto.rp.pl/na-prad/art39358531-nowe-bmw-i3-bedzie-wygladalo-jak-prawdziwe-bmw)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T08:07:43+00:00

Jeden z dyrektorów BMW porównał model i3 do „outsidera w klasie”. Zapowiedziany następca niedużego „elektryka” ma być zaprojektowany w bardziej konserwatywny sposób.

## Koszty części zamiennych szybują w górę. Cena tylnych świateł wzrosła o 100 proc.
 - [https://moto.rp.pl/za-ile-jezdzic/art39352111-koszty-czesci-zamiennych-szybuja-w-gore-cena-tylnych-swiatel-wzrosla-o-100-proc](https://moto.rp.pl/za-ile-jezdzic/art39352111-koszty-czesci-zamiennych-szybuja-w-gore-cena-tylnych-swiatel-wzrosla-o-100-proc)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T07:45:04+00:00

Stowarzyszenia Niemieckiego Przemysłu Ubezpieczeniowego zleciło badanie dotyczące kosztów napraw i cen części zamiennych. Nowoczesne auta zawierają coraz bardziej wyrafinowaną technologię. Ta pomaga uniknąć wypadków i chronić klimat, ale części zamienne, a co za tym idzie, naprawy stają się coraz droższe.

## Skradzione z BUW rosyjskie woluminy warte 500 tys. euro
 - [https://www.rp.pl/przestepczosc/art39358441-skradzione-z-buw-rosyjskie-woluminy-warte-500-tys-euro](https://www.rp.pl/przestepczosc/art39358441-skradzione-z-buw-rosyjskie-woluminy-warte-500-tys-euro)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T07:40:39+00:00

O kradzieży rosyjskich książek z biblioteki uniwersyteckiej mogło dojść już w listopadzie 2022 roku. Rektor Uniwersytetu Warszawskiego oszacował wartość strat na 500 tysięcy euro. Wśród skradzionych jest pierwodruk dzieł Aleksandra Puszkina.

## WTA Finals. Trzecie zwycięstwo Peguli, mecz Sabalenki przerwany
 - [https://www.rp.pl/tenis/art39358371-wta-finals-trzecie-zwyciestwo-peguli-mecz-sabalenki-przerwany](https://www.rp.pl/tenis/art39358371-wta-finals-trzecie-zwyciestwo-peguli-mecz-sabalenki-przerwany)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T07:12:49+00:00

W Cancun do rywalizacji wtrąciła się pogoda. Mecz Rybakina – Sabalenka wyłaniający drugą półfinalistkę turnieju mistrzyń WTA został wstrzymany w drugim secie z powodu deszczu. Dokończenie w piątkowy wieczór

## Komisja Europejska podsumowała bezpieczeństwo na unijnych drogach
 - [https://logistyka.rp.pl/drogowy/art39358421-komisja-europejska-podsumowala-bezpieczenstwo-na-unijnych-drogach](https://logistyka.rp.pl/drogowy/art39358421-komisja-europejska-podsumowala-bezpieczenstwo-na-unijnych-drogach)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T07:03:54+00:00

Liczba 20 640 ofiar śmiertelnych na drogach UE w zeszłym roku oznaczała wzrost o 4 proc. w porównaniu z rokiem 2021, wraz z nasileniem ruchu drogowego po pandemii.

## Armatorzy stawiają na LNG i metanol
 - [https://logistyka.rp.pl/morski/art39357531-armatorzy-stawiaja-na-lng-i-metanol](https://logistyka.rp.pl/morski/art39357531-armatorzy-stawiaja-na-lng-i-metanol)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T06:53:13+00:00

Właściciele statków inwestują miliardy dolarów w alternatywne napędy. Najczęściej wybierają skroplony gaz ziemny i metanol.

## Nie tylko marszałek Sejmu będzie rotacyjny? Szymon Hołownia mówi o "systemie"
 - [https://www.rp.pl/polityka/art39358391-nie-tylko-marszalek-sejmu-bedzie-rotacyjny-szymon-holownia-mowi-o-systemie](https://www.rp.pl/polityka/art39358391-nie-tylko-marszalek-sejmu-bedzie-rotacyjny-szymon-holownia-mowi-o-systemie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T06:49:00+00:00

Moja kandydatura jest na stole: przyznaję otwarcie - mówił w rozmowie z TVN24 lider Polski 2050, Szymon Hołownia, który ma być kandydatem koalicji KO, Trzeciej Drogi i Nowej Lewicy na marszałka Sejmu.

## Nowe mieszkania. Kolejne progi przekroczone
 - [https://www.rp.pl/nieruchomosci/art39357841-nowe-mieszkania-kolejne-progi-przekroczone](https://www.rp.pl/nieruchomosci/art39357841-nowe-mieszkania-kolejne-progi-przekroczone)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T06:32:00+00:00

Średnia cena mkw. nowych mieszkań w Trójmieście przekroczyła 14 tys. zł, a w Łodzi – 10 tys. zł. W Warszawie październik przyniósł stabilizację – wynika z analiz portalu RynekPierwotny.pl.

## Nieoficjalnie: Liberalizacja aborcji nie pojawi się w umowie koalicyjnej
 - [https://www.rp.pl/polityka/art39358321-nieoficjalnie-liberalizacja-aborcji-nie-pojawi-sie-w-umowie-koalicyjnej](https://www.rp.pl/polityka/art39358321-nieoficjalnie-liberalizacja-aborcji-nie-pojawi-sie-w-umowie-koalicyjnej)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T06:31:00+00:00

Polska 2050 i PSL nie zgodziły się, by w umowie koalicyjnej znalazła się kwestia liberalizacji aborcji - wynika z informacji "Gazety Wyborczej".

## Stary katalog przyczyn prześladowania w głośnej uchwale nowej izby SN
 - [https://www.rp.pl/sady-i-trybunaly/art39355791-stary-katalog-przyczyn-przesladowania-w-glosnej-uchwale-nowej-izby-sn](https://www.rp.pl/sady-i-trybunaly/art39355791-stary-katalog-przyczyn-przesladowania-w-glosnej-uchwale-nowej-izby-sn)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T06:23:33+00:00

Izba Odpowiedzialności Zawodowej SN w uchwale o immunitetach sędziowskich wykorzystała przestarzałe przesłanki prześladowania.

## Sąd: za podsłuchiwanie kolegów nie można zwolnić pracownika
 - [https://www.rp.pl/prawo-pracy/art39355811-sad-za-podsluchiwanie-kolegow-nie-mozna-zwolnic-pracownika](https://www.rp.pl/prawo-pracy/art39355811-sad-za-podsluchiwanie-kolegow-nie-mozna-zwolnic-pracownika)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T06:16:25+00:00

Dyscyplinarka za nagrywanie rozmów kolegów nie jest łatwa do obronienia przez szefa. Stanowisko można jednak stracić za utrudnianie im pracy.

## Brakuje regulacji w sprawie e-hulajnóg
 - [https://www.rp.pl/ustroj-i-kompetencje/art39355841-brakuje-regulacji-w-sprawie-e-hulajnog](https://www.rp.pl/ustroj-i-kompetencje/art39355841-brakuje-regulacji-w-sprawie-e-hulajnog)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T06:16:06+00:00

Operatorzy elektrycznych hulajnóg nie muszą uzyskiwać zezwoleń od gmin, by uruchomić wypożyczalnię.

## Adwokat o doręczeniach elektronicznych: Pełnomocnik będzie musiał mieć dwa konta
 - [https://www.rp.pl/prawnicy/art39355961-adwokat-o-doreczeniach-elektronicznych-pelnomocnik-bedzie-musial-miec-dwa-konta](https://www.rp.pl/prawnicy/art39355961-adwokat-o-doreczeniach-elektronicznych-pelnomocnik-bedzie-musial-miec-dwa-konta)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T06:10:00+00:00

W okresie przejściowym, który ma trwać sześć lat, adwokaci i radcowie prawni będą musieli się posługiwać trzema mechanizmami doręczeń elektronicznych – mówi prof. adw. Grzegorz Sibiga z INP PAN, partner w kancelarii Konarski, Traple i Wspólnicy.

## ZEA o sytuacji na Bliskim Wschodzie: Region bliski stanu wrzenia
 - [https://www.rp.pl/dyplomacja/art39358281-zea-o-sytuacji-na-bliskim-wschodzie-region-bliski-stanu-wrzenia](https://www.rp.pl/dyplomacja/art39358281-zea-o-sytuacji-na-bliskim-wschodzie-region-bliski-stanu-wrzenia)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T06:01:26+00:00

Zjednoczone Emiraty Arabskie alarmują, że istnieje "poważne zagrożenie" iż wojna Izraela z Hamasem przekształci się w większy konflikt regionalny.

## Grupa Wagnera przekaże zestaw przeciwlotniczy Hezbollahowi?
 - [https://www.rp.pl/konflikty-zbrojne/art39358261-grupa-wagnera-przekaze-zestaw-przeciwlotniczy-hezbollahowi](https://www.rp.pl/konflikty-zbrojne/art39358261-grupa-wagnera-przekaze-zestaw-przeciwlotniczy-hezbollahowi)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T04:58:57+00:00

Amerykański wywiad ustalił, że Grupa Wagnera, rosyjska prywatna organizacja wojskowa, może przekazać zestaw przeciwlotniczy Pancyr-S1 Hezbollahowi.

## Republikanie przyjęli ustawę o pomocy dla Izraela, ale Biały Dom zapowiada weto
 - [https://www.rp.pl/polityka/art39358241-republikanie-przyjeli-ustawe-o-pomocy-dla-izraela-ale-bialy-dom-zapowiada-weto](https://www.rp.pl/polityka/art39358241-republikanie-przyjeli-ustawe-o-pomocy-dla-izraela-ale-bialy-dom-zapowiada-weto)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T04:32:37+00:00

Izba Reprezentantów Kongresu, w której większość ma Partia Republikańska, przyjęła przygotowaną przez republikanów ustawę przewidującą przekazania 14,3 mld dolarów pomocy Izraelowi przy jednoczesnym zmniejszeniu finansowania dla amerykańskiej służby skarbowej, IRS.

## Izraelska armia weszła do miasta Gaza. Nad Strefą Gazy latają drony USA
 - [https://www.rp.pl/konflikty-zbrojne/art39358221-izraelska-armia-weszla-do-miasta-gaza-nad-strefa-gazy-lataja-drony-usa](https://www.rp.pl/konflikty-zbrojne/art39358221-izraelska-armia-weszla-do-miasta-gaza-nad-strefa-gazy-lataja-drony-usa)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T04:08:39+00:00

Izraelscy żołnierze po otoczeniu miasta Gaza w północnej części Strefy Gazy weszli do miasta - podaje amerykański serwis "The Hill".

## Wojna Rosji z Ukrainą. Dzień 618
 - [https://www.rp.pl/swiat/art39358201-wojna-rosji-z-ukraina-dzien-618](https://www.rp.pl/swiat/art39358201-wojna-rosji-z-ukraina-dzien-618)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T03:43:55+00:00

24 lutego 2022 roku Rosja rozpoczęła pełnowymiarową inwazję na Ukrainę. W przyszłym tygodniu KE zarekomenduje najprawdopodobniej rozpoczęcie negocjacji ws. akcesji Ukrainy do UE.

## 80 tysięcy specjalistów IT ze Wschodu dostało polskie wizy i zniknęło
 - [https://www.rp.pl/polityka/art39357501-80-tysiecy-specjalistow-it-ze-wschodu-dostalo-polskie-wizy-i-zniknelo](https://www.rp.pl/polityka/art39357501-80-tysiecy-specjalistow-it-ze-wschodu-dostalo-polskie-wizy-i-zniknelo)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T02:00:00+00:00

Nie wiadomo, gdzie jest 80 tys. specjalistów IT ze Wschodu, którzy dostali wizy na pracę w Polsce.

## Armia przygotowuje się do oblężenia miasta Gaza
 - [https://www.rp.pl/konflikty-zbrojne/art39358021-armia-przygotowuje-sie-do-oblezenia-miasta-gaza](https://www.rp.pl/konflikty-zbrojne/art39358021-armia-przygotowuje-sie-do-oblezenia-miasta-gaza)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T02:00:00+00:00

W chwili gdy wojna z Hamasem coraz bardziej eskaluje, dyplomacja USA szuka pokojowego rozwiązania konfliktu.

## Czy Konfederacja się rozpadnie? "Istnieje ryzyko"
 - [https://www.rp.pl/wybory/art39357521-czy-konfederacja-sie-rozpadnie-istnieje-ryzyko](https://www.rp.pl/wybory/art39357521-czy-konfederacja-sie-rozpadnie-istnieje-ryzyko)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T02:00:00+00:00

W koalicji Mentzena, Brauna i Bosaka nastał czas rozliczeń i podziału łupów.

## Dariusz Adamski: Jak naprawić sądy, czyli czas na kolejne kroki
 - [https://www.rp.pl/opinie-prawne/art39355911-dariusz-adamski-jak-naprawic-sady-czyli-czas-na-kolejne-kroki](https://www.rp.pl/opinie-prawne/art39355911-dariusz-adamski-jak-naprawic-sady-czyli-czas-na-kolejne-kroki)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T02:00:00+00:00

Uznanie z mocą wsteczną wszystkich działań neo-KRS za nieważne wywołałoby kolosalny chaos prawny. Ustawodawca może temu zapobiec.

## Jak będzie wyglądało Westerplatte
 - [https://www.rp.pl/historia-polski/art39357561-jak-bedzie-wygladalo-westerplatte](https://www.rp.pl/historia-polski/art39357561-jak-bedzie-wygladalo-westerplatte)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T02:00:00+00:00

Gmach główny muzeum znajdzie się pod ziemią, będzie do niego można wejść przez szczelinę.

## Komputery kwantowe pełne mitów
 - [https://www.rp.pl/biznes/art39357391-komputery-kwantowe-pelne-mitow](https://www.rp.pl/biznes/art39357391-komputery-kwantowe-pelne-mitow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T02:00:00+00:00

To, co rozróżnia komputery kwantowe i klasyczne, to niezwykła szybkość operacji obliczeniowych. Kwantowe maszyny są zdolne przeprowadzać w kilka sekund operacje liczbowe, które komputerom tradycyjnym zajmują tysiące lat.

## Komputery kwantowe skusiły Annę Streżyńską. Dołącza do fińskiego start-upu
 - [https://www.rp.pl/biznes/art39357451-komputery-kwantowe-skusily-anne-strezynska-dolacza-do-finskiego-start-upu](https://www.rp.pl/biznes/art39357451-komputery-kwantowe-skusily-anne-strezynska-dolacza-do-finskiego-start-upu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T02:00:00+00:00

Fiński start-up od komputerów nowej generacji zatrudnił byłą minister cyfryzacji w Polsce. To dobry moment, bo w kraju wybierany jest dostawca takiej maszyny.

## Krzysztof Adam Kowalczyk: Koniec wyborczej promocji. Nie da się mrozić cen energii w nieskończoność
 - [https://www.rp.pl/opinie-ekonomiczne/art39357361-krzysztof-adam-kowalczyk-koniec-wyborczej-promocji-nie-da-sie-mrozic-cen-energii-w-nieskonczonosc](https://www.rp.pl/opinie-ekonomiczne/art39357361-krzysztof-adam-kowalczyk-koniec-wyborczej-promocji-nie-da-sie-mrozic-cen-energii-w-nieskonczonosc)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T02:00:00+00:00

Cen prądu dla gospodarstw domowych nie da się w nieskończoność mrozić, ale skokowy wzrost o 60–70 proc. nam raczej nie grozi. Spodziewałbym się rozmrażania stawek rozłożonego na wiele kwartałów.

## Mariusz Cieślik: Strzępki Teatru Dramatycznego
 - [https://www.rp.pl/opinie-polityczno-spoleczne/art39357771-mariusz-cieslik-strzepki-teatru-dramatycznego](https://www.rp.pl/opinie-polityczno-spoleczne/art39357771-mariusz-cieslik-strzepki-teatru-dramatycznego)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T02:00:00+00:00

Wielu obserwatorów uważa, że to za PiS-u byliśmy świadkami wyjątkowej ideologizacji kultury. Wydaje się jednak, że najgorsze może dopiero nadejść. A laboratorium rewolucji znajduje się w „waginecie” Moniki Strzępki.

## Minister zdecyduje, czy leki bez recepty obejmie refundacja
 - [https://www.rp.pl/zdrowie/art39355861-minister-zdecyduje-czy-leki-bez-recepty-obejmie-refundacja](https://www.rp.pl/zdrowie/art39355861-minister-zdecyduje-czy-leki-bez-recepty-obejmie-refundacja)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T02:00:00+00:00

Minister zadecyduje, czy proszki, które kupowaliśmy do tej pory na stacji benzynowej i w markecie, zostaną wpisane na listę leków refundowanych.

## Mąż dał na mieszkanie, skarbówka chce podatek
 - [https://www.rp.pl/podatki/art39356211-maz-dal-na-mieszkanie-skarbowka-chce-podatek](https://www.rp.pl/podatki/art39356211-maz-dal-na-mieszkanie-skarbowka-chce-podatek)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T02:00:00+00:00

Wypłata z małżeńskiego rachunku może być uznana przez fiskusa za darowiznę i opodatkowana.

## Nie wiadomo co się stało z informatykami ze Wschodu, którym Polska wydała wizy
 - [https://www.rp.pl/polityka/art39357791-nie-wiadomo-co-sie-stalo-z-informatykami-ze-wschodu-ktorym-polska-wydala-wizy](https://www.rp.pl/polityka/art39357791-nie-wiadomo-co-sie-stalo-z-informatykami-ze-wschodu-ktorym-polska-wydala-wizy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T02:00:00+00:00

Choć nasz kraj wydał ponad 90 tys. wiz dla specjalistów IT ze Wschodu, do Polski przyjechał tylko co siódmy zaproszony cudzoziemiec. Nikt nie wie, co się dzieje z pozostałymi.

## Niektórzy prokuratorzy odejdą w stan spoczynku po raz kolejny
 - [https://www.rp.pl/zawody-prawnicze/art39355881-niektorzy-prokuratorzy-odejda-w-stan-spoczynku-po-raz-kolejny](https://www.rp.pl/zawody-prawnicze/art39355881-niektorzy-prokuratorzy-odejda-w-stan-spoczynku-po-raz-kolejny)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T02:00:00+00:00

W Prokuraturze Krajowej nerwowa atmosfera. Na medialnej giełdzie padają nowe nazwiska kolejnych najważniejszych prokuratorów, którzy po wyborach chcą przejść w stan spoczynku – niektórzy po raz kolejny.

## Paweł Wojciechowski: Golono, strzyżono
 - [https://www.rp.pl/opinie-ekonomiczne/art39357491-pawel-wojciechowski-golono-strzyzono](https://www.rp.pl/opinie-ekonomiczne/art39357491-pawel-wojciechowski-golono-strzyzono)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T02:00:00+00:00

Najwięcej o stanie polskich finansów dowiadujemy się ze statystyk Eurostatu. Z październikowej notyfikacji rządu do Brukseli wynika, że deficyt instytucji rządowych i samorządowych w 2023 r. wyniesie 192,1 mld zł. Wobec 112,8 mld zł w roku ubiegłym oznacza to wzrost o ponad 70 proc.!

## Podatek - widmo od samochodów warunkiem KPO
 - [https://www.rp.pl/podatki/art39355951-podatek-widmo-od-samochodow-warunkiem-kpo](https://www.rp.pl/podatki/art39355951-podatek-widmo-od-samochodow-warunkiem-kpo)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T02:00:00+00:00

Konieczność wprowadzenia nowej daniny od samochodów może być okazją do zniesienia dzisiejszej akcyzy od aut.

## Podzielił mieszkanie, które zajmował na dziko
 - [https://www.rp.pl/spoleczenstwo/art39357571-podzielil-mieszkanie-ktore-zajmowal-na-dziko](https://www.rp.pl/spoleczenstwo/art39357571-podzielil-mieszkanie-ktore-zajmowal-na-dziko)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T02:00:00+00:00

Mężczyzna nielegalnie zajmujący mieszkanie oszukał komornika podczas egzekucji, dzięki czemu wydał mu jedynie część lokalu.

## Polityczna gra o budżet państwa. Co zrobi nowy rząd?
 - [https://www.rp.pl/budzet-i-podatki/art39357461-polityczna-gra-o-budzet-panstwa-co-zrobi-nowy-rzad](https://www.rp.pl/budzet-i-podatki/art39357461-polityczna-gra-o-budzet-panstwa-co-zrobi-nowy-rzad)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T02:00:00+00:00

Koszty zamrożonych cen energii, dotacje na inwestycje samorządów, pomoc dla Ukrainy, wydatki na zbrojenia – to między innymi składa się na 100 mld zł deficytu poza budżetem państwa w 2023 roku.

## Przy podziale majątku po rozwodzie liczą się lata dobre i złe
 - [https://www.rp.pl/prawo-rodzinne/art39355781-przy-podziale-majatku-po-rozwodzie-licza-sie-lata-dobre-i-zle](https://www.rp.pl/prawo-rodzinne/art39355781-przy-podziale-majatku-po-rozwodzie-licza-sie-lata-dobre-i-zle)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T02:00:00+00:00

Dla sądu ma znaczenie, jak długo udział małżonka w życiu i dochodach rozwiązanej rodziny nie budził zastrzeżeń.

## Przyspieszą wydatki na nowe technologie
 - [https://www.rp.pl/biznes/art39357421-przyspiesza-wydatki-na-nowe-technologie](https://www.rp.pl/biznes/art39357421-przyspiesza-wydatki-na-nowe-technologie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T02:00:00+00:00

Choć w ostatnim czasie najwięcej emocji wzbudza sztuczna inteligencja, to nie ona będzie motorem wzrostu rynku. Ale jej znaczenie systematycznie rośnie.

## Sędzia NSA: Trzecia instancja i nowe instytucje usprawnią procesy administracyjne
 - [https://www.rp.pl/sady-i-trybunaly/art39355761-sedzia-nsa-trzecia-instancja-i-nowe-instytucje-usprawnia-procesy-administracyjne](https://www.rp.pl/sady-i-trybunaly/art39355761-sedzia-nsa-trzecia-instancja-i-nowe-instytucje-usprawnia-procesy-administracyjne)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T02:00:00+00:00

Trzystopniowe sądownictwo administracyjne skróci oczekiwanie na prawomocny wyrok. Pozwoli usprawnić i przyspieszyć orzekanie w sprawach obywateli czy firm – mówi sędzia NSA Aleksandra Wrzesińska-Nowacka, prezes Ogólnopolskiego Stowarzyszenia Sędziów Sądów Administracyjnych.

## Trzecioligowiec zatopił Bayern
 - [https://www.rp.pl/pilka-nozna/art39358071-trzecioligowiec-zatopil-bayern](https://www.rp.pl/pilka-nozna/art39358071-trzecioligowiec-zatopil-bayern)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T02:00:00+00:00

Trzy dni przed szlagierem z Borussią Dortmund bawarski gigant przegrał w drugiej rundzie krajowego pucharu z 1. FC Saarbruecken 1:2. Niemieckie media piszą o blamażu i hańbie.

## Zbigniew Bochniarz: Kapitał społeczny to cichy zwycięzca wyborów
 - [https://www.rp.pl/opinie-ekonomiczne/art39357381-zbigniew-bochniarz-kapital-spoleczny-to-cichy-zwyciezca-wyborow](https://www.rp.pl/opinie-ekonomiczne/art39357381-zbigniew-bochniarz-kapital-spoleczny-to-cichy-zwyciezca-wyborow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T02:00:00+00:00

Utrzymanie wielkiego kapitału społecznego jest niezbędnym warunkiem zwycięstwa w nadchodzących wkrótce wyborach samorządowych i do Parlamentu Europejskiego.

## Znikający informatycy
 - [https://www.rp.pl/polityka/art39357501-znikajacy-informatycy](https://www.rp.pl/polityka/art39357501-znikajacy-informatycy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T02:00:00+00:00

Nie wiadomo, gdzie jest 80 tys. specjalistów IT ze Wschodu, którzy dostali wizy na pracę w Polsce.

## Zuzanna Dąbrowska: Trzeba przygotować nad Wisłą miękkie lądowanie dla uchodźców i migrantów
 - [https://www.rp.pl/komentarze/art39357811-zuzanna-dabrowska-trzeba-przygotowac-nad-wisla-miekkie-ladowanie-dla-uchodzcow-i-migrantow](https://www.rp.pl/komentarze/art39357811-zuzanna-dabrowska-trzeba-przygotowac-nad-wisla-miekkie-ladowanie-dla-uchodzcow-i-migrantow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-11-03T02:00:00+00:00

Polska musi otwarcie ogłosić, z jakich krajów przyjmie uchodźców z powodu głodu i wojen oraz jakich pracowników napływowych chce zatrudniać. Jeśli nie stworzymy odpowiedzialnej polityki migracyjnej, oni i tak przyjadą, tyle że nikt nad tym procesem nie zapanuje.

