# Source:Chip.pl, URL:https://www.chip.pl/feed, language:pl-PL

## Największy na świecie reaktor termojądrowy osiągnął kluczowy etap. Poznaliśmy pierwsze odczyty
 - [https://www.chip.pl/2023/11/japonski-reaktor-termojadrowy-jtsa60-fuzja](https://www.chip.pl/2023/11/japonski-reaktor-termojadrowy-jtsa60-fuzja)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-11-03T20:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1173" src="https://konto.chip.pl/wp-content/uploads/2023/11/reaktor-termojadrowy.jpg" style="margin-bottom: 10px;" width="1600" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/11/reaktor-termojadrowy.jpg" style="display: block; margin: 1em auto;" /></p>
<p>We Francji trwają prace, które powinny jeszcze w tej dekadzie zaowocować uruchomieniem reaktora ITER. Zanim jednak ten potwór ze Starego Kontynentu rozpocznie swoje działanie, pozostaje nam zachwycanie się osiągnięciami naukowców z dalekiej Azji. Właśnie tam, bo w Japonii, udało się niedawno wytworzyć historyczną plazmę, która pojawiła się po ponad 15 latach budowy i testów urządzenia [&#8230;]</p>

## Przesłonięcie Słońca wiąże się z dużym ryzykiem. Możemy narobić sobie problemów i nic na tym nie skorzystać
 - [https://www.chip.pl/2023/11/przesloniecie-slonca-ryzyko-zero-korzysci](https://www.chip.pl/2023/11/przesloniecie-slonca-ryzyko-zero-korzysci)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-11-03T18:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="965" src="https://konto.chip.pl/wp-content/uploads/2023/11/antarktyda.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/11/antarktyda.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Pomimo wszystkich podejmowanych w skali globalnej wysiłków mających na celu ograniczenie emisji dwutlenku węgla do atmosfery, średnie temperatury na powierzchni Ziemi bezustannie rosną. Już teraz coraz częściej odczuwamy zgubne skutki ocieplania klimatu. Mało tego, ze względu na to, że klimat to niezwykle skomplikowany układ naczyń połączonych, coraz mniej panujemy nad zachodzącymi zmianami. Nic zatem dziwnego, [&#8230;]</p>

## Edge z numerkiem 119 przynosi praktyczną nowość &#8211; i sporo usprawnień dla firm
 - [https://www.chip.pl/2023/11/edge-119-zmiany-poprawki-nowosci](https://www.chip.pl/2023/11/edge-119-zmiany-poprawki-nowosci)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-11-03T17:30:00+00:00

<img alt="Przeglądarka Edge" class="attachment-full size-full wp-post-image" height="1707" src="https://konto.chip.pl/wp-content/uploads/2023/11/Microsoft-Edge-scaled.jpg" style="margin-bottom: 10px;" width="2560" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/11/Microsoft-Edge-scaled.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Przeglądarka Microsoftu doczekała się kolejnej stabilnej edycji. Edge 119 przynosi przede wszystkim usprawnienie pracy dla osób korzystających z funkcji podzielonego ekranu. Ale na tym lista wartych odnotowania nowości się nie kończy. Co jeszcze zmienił Microsoft? Właściwie pełen numer najświeższego to nie 199, a dokładnie 119.0.2151.44. Trzeba przyznać, że Edge to jedna z tych rzeczy, z [&#8230;]</p>

## Niby mamy dopiero listopad, ale w Orange już obowiązuje bożonarodzeniowa oferta. Jest naprawdę atrakcyjna
 - [https://www.chip.pl/2023/11/orange-oferta-swiateczna-promocja](https://www.chip.pl/2023/11/orange-oferta-swiateczna-promocja)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-11-03T17:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="854" src="https://konto.chip.pl/wp-content/uploads/2023/11/boze-narodzenie-1.jpg" style="margin-bottom: 10px;" width="1280" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/11/boze-narodzenie-1.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Nie tylko w marketach widać już pierwsze świąteczne dekoracje i produkty, również operatorzy telekomunikacyjni dość szybko zaczęli zmieniać swoją ofertę. W Orange Boże Narodzenie jest już na wyciągnięcie ręki i z tej okazji można naprawdę dużo zaoszczędzić. Jeśli po ubiegłorocznych świętach obiecywaliście sobie, że do kolejnych zaczniecie przygotowywać się szybciej, to może jest to właśnie [&#8230;]</p>

## Galaxy S24 gamingowym monstrum na miarę Steam Decka? Samsung, AMD i Qualcomm coś wspólnie pichcą
 - [https://www.chip.pl/2023/11/galaxy-s24-gamingowym-monstrum-amd-qualcomm-fsr](https://www.chip.pl/2023/11/galaxy-s24-gamingowym-monstrum-amd-qualcomm-fsr)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-11-03T16:30:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1280" src="https://konto.chip.pl/wp-content/uploads/2023/04/samsung-galaxy-s23-ultra-nightografia-09.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/04/samsung-galaxy-s23-ultra-nightografia-09.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Nabieramy coraz większej ochoty na jakościową mobilną rozrywkę na poziomie gier pecetowych, a takie sprzęty jak Steam Deck czy ROG Ally udowadniają, że technologicznie jest to już możliwe. Rozwój sztucznej inteligencji przyspiesza możliwości w zakresie upchnięcia coraz bardziej wymagających technologii do naszych kieszeni, a zapowiadana na styczeń seria smartfonów Galaxy S24 od Samsunga może się [&#8230;]</p>

## Data premiery nowych flagowców ujawniona? Wszystko, co wiemy o Galaxy S24 przed premierą
 - [https://www.chip.pl/2023/11/galaxy-s24-specyfikacja-wyglad-data-premiery](https://www.chip.pl/2023/11/galaxy-s24-specyfikacja-wyglad-data-premiery)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-11-03T16:00:00+00:00

<img alt="Samsung Galaxy S23+" class="attachment-full size-full wp-post-image" height="1707" src="https://konto.chip.pl/wp-content/uploads/2023/04/Samsung-Galaxy-S23-009.jpg" style="margin-bottom: 10px;" width="2560" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/04/Samsung-Galaxy-S23-009.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Im bliżej końca roku, tym więcej przecieków pojawia się na temat przyszłorocznych smartfonów. Z racji, że Samsung zapewne jako jeden z pierwszych wypuści na rynek swoją flagową serię, warto zacząć kompletować wszystkie doniesienia, jakie na temat Galaxy S24 trafiły już do sieci. Osobny zbiorczy tekst o ultraflagowcu Galaxy S24 Ultra znajdziecie tutaj, tymczasem teraz skupię [&#8230;]</p>

## Pompy ciepła nie potrafią grzać w zimie? Na ten temat mają coś do powiedzenia nasi sąsiedzi
 - [https://www.chip.pl/2023/11/pompy-ciepla-w-norwegii](https://www.chip.pl/2023/11/pompy-ciepla-w-norwegii)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-11-03T14:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="819" src="https://konto.chip.pl/wp-content/uploads/2023/11/tromso-bridge-1180406_1280.jpg" style="margin-bottom: 10px;" width="1280" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/11/tromso-bridge-1180406_1280.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Kraje Europy Północnej wiodą prym pod względem instalacji pomp ciepła. Zaprzecza to popularnemu stereotypowi, że te urządzenia nie potrafią wydajnie działać w niskich temperaturach. Jak widać, Norwegowie, Szwedzi i Finowie mają zupełnie inne zdanie na ten temat. Czy ich pompy ciepła różnią się czymkolwiek od „naszych”? Pompy ciepła są uważane za przyszłościową technologię grzewczą. Ich [&#8230;]</p>

## Przeglądarka Brave z własnym asystentem AI. Teraz to już chyba wstyd nie mieć sztucznej inteligencji
 - [https://www.chip.pl/2023/11/przegladarka-brave-leo-asystent-ai](https://www.chip.pl/2023/11/przegladarka-brave-leo-asystent-ai)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-11-03T13:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1724" src="https://konto.chip.pl/wp-content/uploads/2023/11/brave-scaled.jpg" style="margin-bottom: 10px;" width="2560" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/11/brave-scaled.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Dziś to już chyba po prostu nie wypada mieć aplikacji, która chociaż śladowo nie zahacza o generatywną sztuczną inteligencję? Szczególnie mocno tzw. asystenci AI panoszą się ostatnio w przeglądarkach internetowych. Rewolucję w tym segmencie rozpoczął Microsoft Edge, trend podtrzymała Opera, a teraz również Brave może się pochwalić rozwiązaniem, która przynajmniej w swoim marketingowym założeniu ma [&#8230;]</p>

## Zen 4C &#8211; więcej rdzeni na takiej samej powierzchni. Jak to możliwe?
 - [https://www.chip.pl/2023/11/zen-4c-nowa-architektura-amd](https://www.chip.pl/2023/11/zen-4c-nowa-architektura-amd)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-11-03T12:00:00+00:00

<img alt="AMD Ryzen z Zen 4C" class="attachment-full size-full wp-post-image" height="558" src="https://konto.chip.pl/wp-content/uploads/2023/11/AMD-Ryzen.jpg" style="margin-bottom: 10px;" width="992" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/11/AMD-Ryzen.jpg" style="display: block; margin: 1em auto;" /></p>
<p>AMD w końcu pokazało nowe APU dla Ryzen 7040. Jest ono oparte na mikroarchitekturze Zen 4C. Zastosowano w niej rozwiązanie, które obiecuje nie tylko zwiększenie liczby rdzeni, ale również możliwość ograniczenia przestrzeni. W praktyce mniejsze układy dadzą więcej mocy. W jaki sposób? AMD od lat rozwija architekturę Zen, na bazie której opierają się procesory Ryzen. [&#8230;]</p>

## Co z zasilaniem GeForce RTX 4080 Super? Różnie mówią
 - [https://www.chip.pl/2023/11/geforce-rtx-4080-super-zasilanie-parametry](https://www.chip.pl/2023/11/geforce-rtx-4080-super-zasilanie-parametry)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-11-03T11:00:00+00:00

<img alt="GeForce RTX 4080 Super" class="attachment-full size-full wp-post-image" height="499" src="https://konto.chip.pl/wp-content/uploads/2023/11/RTX4080-Super.jpg" style="margin-bottom: 10px;" width="1200" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/11/RTX4080-Super.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Do niedawna plotki głosiły, że nadchodząca karta graficzna z rodziny RTX &#8211; czyli RTX 4080 Super &#8211; ma mieć wysokie wymagania co do poboru mocy. Jednak dzisiaj pojawiły się przecieki z zaufanych źródeł, które mogą uspokoić. Ostatnie plotki mówiły nam, że nowe modele kart RTX 40 mogą mieć wyższe wymagania co do poboru mocy niż [&#8230;]</p>

## O tym elektrycznym rowerze marzysz, ale lepiej usiądź, zanim poznasz jego cenę
 - [https://www.chip.pl/2023/11/lotus-type-136-elektryczny-rower](https://www.chip.pl/2023/11/lotus-type-136-elektryczny-rower)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-11-03T10:30:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1080" src="https://konto.chip.pl/wp-content/uploads/2023/11/Elektryczny-rower-Lotus-Type-136-3.jpg" style="margin-bottom: 10px;" width="1619" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/11/Elektryczny-rower-Lotus-Type-136-3.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Firma Lotus, która słynie przede wszystkim ze swojego dziedzictwa i nowoczesnych samochodów elektrycznych, zdecydowała się zaprezentować światu Type 136, czyli elektryczny rower, o którym można śnić. Lotus zaprezentował rower elektryczny Type 136. To wysokiej klasy cudo z historycznym akcentem Rowery elektryczne ciągle zyskują na popularności, a wyróżnienie danego modelu na rynku staje się coraz trudniejsze. [&#8230;]</p>

## Biden zadowolony nie będzie. Potężna atomówka USA zawiodła
 - [https://www.chip.pl/2023/11/usa-test-pocisku-minuteman-iii-porazka](https://www.chip.pl/2023/11/usa-test-pocisku-minuteman-iii-porazka)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-11-03T10:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1530" src="https://konto.chip.pl/wp-content/uploads/2023/09/USA-Minuteman-III-pocisk-test.jpg" style="margin-bottom: 10px;" width="2141" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/09/USA-Minuteman-III-pocisk-test.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Pociski mogące wywołać nuklearną zagładę są regularnie testowane przez USA. W najnowszym teście nie zaprezentowały się jednak z najlepszej strony. Test balistycznego pocisku Minuteman III zakończony porażką Międzykontynentalne pociski balistyczne Minuteman III są dla USA jednym z filarów nuklearnej triady, pełniąc funkcję odstraszania oraz broni ostatecznej. Muszą więc być w pełni sprawne i zawsze gotowe [&#8230;]</p>

## Nadchodzące smartfony to fotograficzne bestie. Żadnego z nich nie kupimy w Polsce
 - [https://www.chip.pl/2023/11/najlepsze-fotograficzne-smartfony-nie-dla-europy-xuaimi-14-ultra-vivo-x100](https://www.chip.pl/2023/11/najlepsze-fotograficzne-smartfony-nie-dla-europy-xuaimi-14-ultra-vivo-x100)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-11-03T09:30:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1280" src="https://konto.chip.pl/wp-content/uploads/2023/10/oneplus-open-19.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/10/oneplus-open-19.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Omijanie polskiego, jak i ogółem europejskiego rynku stało się standardem w przypadku najmocniejszych smartfonów chińskich producentów. Ale prawdziwy cios dopiero przed nami, bo modele wyposażone w najnowszy aparat Sony LYT-900, które prawdopodobnie z miejsca staną się liderami rynku pod względem jakości zdjęć, będą dostępne tylko na rynku chińskim. Co jest przyczyną tego, że chińskie firmy [&#8230;]</p>

## Jaki smartfon do 1500 złotych kupić? 7 propozycji godnych uwagi
 - [https://www.chip.pl/2023/11/jaki-smartfon-do-1500-zlotych-2023](https://www.chip.pl/2023/11/jaki-smartfon-do-1500-zlotych-2023)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-11-03T09:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1280" src="https://konto.chip.pl/wp-content/uploads/2023/09/motorola-moto-g84-5g-viva-magenta.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/09/motorola-moto-g84-5g-viva-magenta.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Zaletę dojrzałości rynku smartfonów stanowi to, że za nie tak duże pieniądze znajdziemy dobre telefony. Jaki smartfon do 1500 złotych wybrać? Na szczęście opcji nie brakuje &#8211; zarówno nieco bardziej kompaktowych, jak i tych większych. W tej cenie otrzymacie ładne, kolorowe obudowy, efektowne ekrany, przyzwoitą wydajność i kilka ciekawych rozwiązań rodem ze znacznie droższych urządzeń. [&#8230;]</p>

## Fuzja jądrowa z gigantycznym skokiem. Produkują pięć razy więcej energii, niż wykorzystują
 - [https://www.chip.pl/2023/11/fuzja-jadrowa-5-krotny-wzrost-produkowanej-energii](https://www.chip.pl/2023/11/fuzja-jadrowa-5-krotny-wzrost-produkowanej-energii)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-11-03T08:05:50+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="620" src="https://konto.chip.pl/wp-content/uploads/2023/05/slonce-fuzja.png" style="margin-bottom: 10px;" width="1600" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/05/slonce-fuzja.png" style="display: block; margin: 1em auto;" /></p>
<p>Przy ogromnej sympatii do fuzji jądrowej i jej potencjału, nie da się ukryć, że jak na razie jest ona daleka do stania się podstawowym źródłem energii wykorzystywanej przez ziemskie sieci. Dokonane w ostatnich latach postępy dają jednak nadzieję na rewolucję, a przedstawiciele ENG8 mieli w tym ogromny udział.  Fuzja dostarcza energii gwiazdom i Słońce nie [&#8230;]</p>

## Najbardziej zaawansowany myśliwiec na wojnie. Izraelski F-35I osiągnął niemożliwe
 - [https://www.chip.pl/2023/11/izrael-mysliwiec-f-35i-przechwycenie-pocisku-manewrujacego](https://www.chip.pl/2023/11/izrael-mysliwiec-f-35i-przechwycenie-pocisku-manewrujacego)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-11-03T04:59:15+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1079" src="https://konto.chip.pl/wp-content/uploads/2023/03/F-35-z-dronami.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/03/F-35-z-dronami.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Opracowane przez firmę Lockheed Martin wielozadaniowe myśliwce piątej generacji F-35 służą m.in. w lotnictwie Izraela, biorąc ciągle czynny udział w wojnie i to nie tylko w ataku, ale także obronie. Izraelski F-35I zestrzelił lecący pocisk manewrujący po raz pierwszy w historii Izraelskie myśliwce stealth F-35I &#8220;Adir&#8221; wykazały właśnie swoją bojową sprawność, przechwytując pocisk manewrujący podczas [&#8230;]</p>

