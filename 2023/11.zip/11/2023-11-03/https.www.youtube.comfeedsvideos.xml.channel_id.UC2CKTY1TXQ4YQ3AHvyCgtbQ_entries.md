# Source:Tabletop Miniatures, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2CKTY1TXQ4YQ3AHvyCgtbQ, language:en-US

## I've Been Using the New Army Painter FANATIC Paints for Two Months
 - [https://www.youtube.com/watch?v=d8neacSSkP4](https://www.youtube.com/watch?v=d8neacSSkP4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2CKTY1TXQ4YQ3AHvyCgtbQ
 - date published: 2023-11-03T07:00:24+00:00

The Army Painter sent me the new Fanatic opaque acrylic paints and I've been using them for TWO MONTHS on everything I've been painting - what do I think about them?

Vince Venturella and I made another game! Check out MAJESTIC 13 at http://www.majestic13game.com

I'm now a partner on Twitch! I paint minis every Friday morning and Monday night, and sometimes take paint breaks (play video games poorly). Follow me: http://www.twitch.tv/tabletopminions

Official Tabletop Minions t-shirts: http://bit.ly/merchbunker

Help support the channel on Patreon, and get access to the Discord: http://www.patreon.com/tabletopminions

Twitter: http://www.twitter.com/tabletopminions
Instagram: http://www.instagram.com/tabletopminions

