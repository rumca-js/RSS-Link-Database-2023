# Source:The Washington Post - Tech, URL:https://feeds.washingtonpost.com/rss/business/technology, language:en-US

## The iPhone is obviously superior at one thing. Ask your wallet.
 - [https://www.washingtonpost.com/technology/2023/11/03/iphone-used-resale-values](https://www.washingtonpost.com/technology/2023/11/03/iphone-used-resale-values)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-11-03T16:30:00+00:00

Sorry, Android lovers. Resale values of iPhones are so much higher that it may be financially irresponsible not to buy one.

## Trump Jr. tells courtroom artist ‘make me look sexy,’ points to fake SBF sketch
 - [https://www.washingtonpost.com/politics/2023/11/03/trump-sbf-courtroom-sketch-trial](https://www.washingtonpost.com/politics/2023/11/03/trump-sbf-courtroom-sketch-trial)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-11-03T15:21:49+00:00

A fake — and flattering — courtroom sketch of Sam Bankman-Fried was the inspiration for Donald Trump Jr.’s request to the courtroom sketch artist during his family’s civil fraud trial.

## Greenville was quiet. Then a hometown kid became YouTube’s biggest star.
 - [https://www.washingtonpost.com/technology/2023/11/03/mr-beast-money-hometown-greenville-creator-economy](https://www.washingtonpost.com/technology/2023/11/03/mr-beast-money-hometown-greenville-creator-economy)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-11-03T10:00:16+00:00

Living in the same town as YouTube’s biggest mega-celebrity, Jimmy “MrBeast” Donaldson, has its perks. A waitress at a hot-dog joint won a private island.

## Bankman-Fried convicted on all charges after weeks-long criminal trial
 - [https://www.washingtonpost.com/business/2023/11/02/sbf-bankman-fried-trial-ftx](https://www.washingtonpost.com/business/2023/11/02/sbf-bankman-fried-trial-ftx)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-11-03T00:38:06+00:00

The co-founder of the FTX crypto exchange was accused of one of the largest financial frauds in history.

