# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## Travis Kelce asked if he's 'in love' with Taylor Swift, addresses relationship 'status'
 - [https://www.foxnews.com/sports/travis-kelce-asked-in-love-taylor-swift-addresses-relationship-status](https://www.foxnews.com/sports/travis-kelce-asked-in-love-taylor-swift-addresses-relationship-status)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T22:58:10+00:00

Travis Kelce and Taylor Swift are all but officially official, which prompted a reporter in Germany to ask the Chiefs star if he&apos;s &quot;in love.&quot;

## Tlaib accuses Biden of supporting 'genocide' of Palestinians, warns: 'We will remember in 2024'
 - [https://www.foxnews.com/media/tlaib-accuses-biden-supporting-genocide-palestinians-warns-remember-2024](https://www.foxnews.com/media/tlaib-accuses-biden-supporting-genocide-palestinians-warns-remember-2024)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T22:49:26+00:00

&quot;Squad&quot; member Rep. Rashida Tlaib, D-Mich., accused President Biden of supporting the &quot;genocide&quot; of Palestinians because of his pledge of support for Israel.

## Proposal to subsidize affordable housing by taxing mansions appears on ballots in New Mexico capital
 - [https://www.foxnews.com/politics/proposal-subsidize-affordable-housing-taxing-mansions-appears-ballots-new-mexico-capital](https://www.foxnews.com/politics/proposal-subsidize-affordable-housing-taxing-mansions-appears-ballots-new-mexico-capital)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T22:36:08+00:00

Voters in Santa Fe, New Mexico, are set to decide whether a tax on homes worth over $1 million should be implemented to help pay for affordable housing initiatives.

## Hinds County, Mississippi poll worker training disrupted by September cyber breach
 - [https://www.foxnews.com/politics/hinds-county-mississippi-poll-worker-training-disrupted-september-cyber-breach](https://www.foxnews.com/politics/hinds-county-mississippi-poll-worker-training-disrupted-september-cyber-breach)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T22:26:34+00:00

Hinds County, Mississippi, home to the state&apos;s capital, Jackson, was forced to rush requisite poll worker training after a September breach of county computer systems.

## Veterans help Americans leaving Gaza: ‘Easier time getting people out of Afghanistan’
 - [https://www.foxnews.com/world/veterans-help-americans-leaving-gaza-easier-time-getting-people-out-afghanistan](https://www.foxnews.com/world/veterans-help-americans-leaving-gaza-easier-time-getting-people-out-afghanistan)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T22:10:57+00:00

Special operations veteran says getting Americans out of Gaza has been more challenging than many civilian rescue missions, including the Afghanistan evacuation.

## $8.5M worth of psychedelic mushrooms seized from rural Connecticut property
 - [https://www.foxnews.com/us/8-5m-worth-psychedelic-mushrooms-seized-rural-connecticut-property](https://www.foxnews.com/us/8-5m-worth-psychedelic-mushrooms-seized-rural-connecticut-property)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T22:10:49+00:00

Police in Connecticut uncovered an $8.5 million psychedelic mushroom manufacturing scheme at a home in Hartford County&apos;s rural outskirts.

## Magnitude 5.6 earthquake rocks Nepal, is felt in neighboring India
 - [https://www.foxnews.com/world/magnitude-5-6-earthquake-rocks-nepal-felt-neighboring-india](https://www.foxnews.com/world/magnitude-5-6-earthquake-rocks-nepal-felt-neighboring-india)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T22:05:17+00:00

A magnitude 5.6 earthquake rattled northwestern Nepal late Friday night. Despite being felt as far away as New Delhi, India, no immediate reports of damage have surfaced.

## Protester at NYU pro-Palestinian rally spits on 'Jewish' sign, equates with 'White Supremacy'
 - [https://www.foxnews.com/media/protester-nyu-pro-palestinian-rally-spits-jewish-sign-equates-white-supremacy](https://www.foxnews.com/media/protester-nyu-pro-palestinian-rally-spits-jewish-sign-equates-white-supremacy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T22:02:45+00:00

A protester at New York University (NYU) was caught on film spitting on a banner that said &quot;Jewish&quot; and then created a sign that said &quot;Jewish Supremacy.&quot;

## Lookout in Opa-locka, Florida gang shooting gets life in prison
 - [https://www.foxnews.com/us/lookout-opa-locka-florida-gang-shooting-life-prison](https://www.foxnews.com/us/lookout-opa-locka-florida-gang-shooting-life-prison)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T21:43:43+00:00

Davonte Barnes, 24, has been sentenced to life in prison for his role in a 2021 gang shooting in South Florida that left three people dead and another 20 injured.

## Judges dismiss North Dakota GOP lawsuit over Native-focused state House subdistricts
 - [https://www.foxnews.com/politics/judges-dismiss-north-dakota-gop-lawsuit-native-focused-state-house-subdistricts](https://www.foxnews.com/politics/judges-dismiss-north-dakota-gop-lawsuit-native-focused-state-house-subdistricts)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T21:30:51+00:00

A federal three-judge panel ruled Thursday against Republican officials in North Dakota who claimed race-based interest subdistricts in the state House were unconstitutional.

## PFAS 'forever chemicals' found in 71% of Wisconsin's shallow, private wells
 - [https://www.foxnews.com/us/pfas-forever-chemicals-found-71-wisconsins-shallow-private-wells](https://www.foxnews.com/us/pfas-forever-chemicals-found-71-wisconsins-shallow-private-wells)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T21:28:53+00:00

71% of water samples from hundreds of Wisconsin&apos;s private wells were found to be contaminated by PFAS chemicals, according to a state survey.

## What the FBI seized from the home of New York City Mayor Eric Adams' top fundraiser
 - [https://www.foxnews.com/politics/what-fbi-seized-home-new-york-city-mayor-eric-adams-top-fundraiser](https://www.foxnews.com/politics/what-fbi-seized-home-new-york-city-mayor-eric-adams-top-fundraiser)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T21:26:21+00:00

The FBI is investigating whether foreign money was funneled into Mayor Adams 2021 mayoral campaign. On Thursday the agency raided the home of Adams&apos; top fundraisers

## Deion Sanders making play-caller change ahead of Oregon State matchup: reports
 - [https://www.foxnews.com/sports/deion-sanders-making-play-caller-change-ahead-oregon-state-matchup-reports](https://www.foxnews.com/sports/deion-sanders-making-play-caller-change-ahead-oregon-state-matchup-reports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T21:03:13+00:00

Colorado head coach Deion Sanders will reportedly elevate Pat Shurmur to an on-field role calling plays against Oregon State on Saturday.

## Gun purchases by Jewish Americans surging since Oct. 7 Hamas terror attack, says store owner
 - [https://www.foxnews.com/media/gun-purchases-jewish-americans-surging-oct-7-hamas-terror-attack-store-owner](https://www.foxnews.com/media/gun-purchases-jewish-americans-surging-oct-7-hamas-terror-attack-store-owner)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T21:00:53+00:00

Burbank Ammo and Guns manager Eric Fletcher discusses the surge in firearm sales among Jewish Americans and details roadblocks to purchasing firearms in California.

## Belarus sentences independent news editor to 4-year prison sentence
 - [https://www.foxnews.com/world/belarus-sentences-independent-news-editor-4-year-prison-sentence](https://www.foxnews.com/world/belarus-sentences-independent-news-editor-4-year-prison-sentence)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T20:58:20+00:00

Belarus has convicted chief editor Aliaksandr Mantsevich of the independently-run Regionalnaya Gazeta newspaper of &quot;discrediting the Republic,&quot; sentencing him to four years in prison.

## Florida man 'tried to circumcise' toddler cousin he was babysitting: Police
 - [https://www.foxnews.com/us/florida-man-tried-circumcise-toddler-cousin-babysitting-police](https://www.foxnews.com/us/florida-man-tried-circumcise-toddler-cousin-babysitting-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T20:57:19+00:00

Florida police allege that a 29-year-old man tried to circumcise his 2-year-old cousin he was babysitting on Oct. 17 and was charged with child abuse.

## Deshaun Watson active for Browns after he missed most of last 4 games with lingering injury
 - [https://www.foxnews.com/sports/deshaun-watson-active-browns-lingering-injury-forced-him-miss-most-last-4-games](https://www.foxnews.com/sports/deshaun-watson-active-browns-lingering-injury-forced-him-miss-most-last-4-games)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T20:47:34+00:00

Deshaun Watson returned from his shoulder injury in Week 7 but played just 12 snaps before aggravating it. The Browns say he will play this weekend.

## Rep. Zinke wants Congress to shut down Palestinian immigration: ‘Enough is enough’
 - [https://www.foxnews.com/politics/rep-zinke-wants-congress-shut-down-palestinian-immigration-enough-enough](https://www.foxnews.com/politics/rep-zinke-wants-congress-shut-down-palestinian-immigration-enough-enough)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T20:39:32+00:00

Rep. Ryan Zinke, R-Mont., is calling for the shutdown of all Palestinian immigration into the U.S., in the wake of the the Hamas terror attacks on Israel.

## Virginia teacher shot by 6-year-old may proceed with $40M lawsuit, judge determines
 - [https://www.foxnews.com/us/virginia-teacher-shot-6-year-old-proceed-40m-lawsuit-judge-determines](https://www.foxnews.com/us/virginia-teacher-shot-6-year-old-proceed-40m-lawsuit-judge-determines)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T20:37:55+00:00

Abby Zwerner, a Newport News, Virginia-based public schoolteacher, may proceed with a $40 million lawsuit against the school system, a circuit judge ruled Friday.

## Iran, Hamas leaders proclaim their evil plans. Take them at their words
 - [https://www.foxnews.com/opinion/iran-hamas-leaders-proclaim-evil-plans-words](https://www.foxnews.com/opinion/iran-hamas-leaders-proclaim-evil-plans-words)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T20:35:19+00:00

Iran&apos;s foreign minister Hossein Amir-Adollahian has threatened America&apos;s leaders with violence over the Hamas terror attacks. Hamas&apos; Ghazi Hamad has promised murder sprees to come.

## Mark Wahlberg shares change he made to fitness routine: ‘It’s all about longevity’
 - [https://www.foxnews.com/entertainment/mark-wahlberg-shares-change-made-fitness-routine-all-about-longevity](https://www.foxnews.com/entertainment/mark-wahlberg-shares-change-made-fitness-routine-all-about-longevity)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T20:32:05+00:00

Mark Wahlberg is trying to &quot;live longer&quot; and &quot;be healthier&quot; by trading in two workouts a day for recovery ice baths. The 52-year-old actor is focused on &quot;longevity&quot; as he ages.

## Supreme Court agrees to hear challenges to bump stock ban, New York's financial 'blacklisting' of NRA
 - [https://www.foxnews.com/politics/supreme-court-agrees-hear-challenges-bump-stock-ban-new-yorks-financial-blacklisting-nra](https://www.foxnews.com/politics/supreme-court-agrees-hear-challenges-bump-stock-ban-new-yorks-financial-blacklisting-nra)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T20:26:48+00:00

The Supreme Court agreed to hear arguments in two major cases involving gun rights related to &apos;bump stocks&apos; and First Amendment liberties for the National Rifle Association.

## Supreme Court takes up two major cases that could have sweeping affect on First Amendment and gun rights
 - [https://www.foxnews.com/politics/supreme-court-takes-up-two-major-cases-that-could-have-sweeping-affect-on-first-amendment-and-gun-rights](https://www.foxnews.com/politics/supreme-court-takes-up-two-major-cases-that-could-have-sweeping-affect-on-first-amendment-and-gun-rights)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T20:26:48+00:00

The Supreme Court agreed to hear arguments in two major cases involving gun rights related to &apos;bump stocks&apos; and First Amendment liberties for the National Rifle Association.

## Burmese military junta promises retaliation against rebel forces that seized Chinese border towns
 - [https://www.foxnews.com/world/burmese-military-junta-promises-retaliation-rebel-forces-seized-chinese-border-towns](https://www.foxnews.com/world/burmese-military-junta-promises-retaliation-rebel-forces-seized-chinese-border-towns)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T20:15:02+00:00

Burmese military dictator Min Aung Hlaing has pledged counterattacks against rebel forces that seized control of three Chinese border towns in the country&apos;s northeastern Shan state.

## Are the benefits of cold showers worth the discomfort? Experts weigh in
 - [https://www.foxnews.com/health/are-benefits-cold-showers-worth-discomfort-experts-weigh-in](https://www.foxnews.com/health/are-benefits-cold-showers-worth-discomfort-experts-weigh-in)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T20:14:01+00:00

Cold plunging and cold showers have gained popularity in recent years. Experts share with Fox News Digital the potential benefits, risks and tips forgetting started.

## 'Crazy plane lady' Tiffany Gomas finally reveals reason behind her viral plane freakout: 'Really bad energy'
 - [https://www.foxnews.com/media/crazy-plane-lady-tiffany-gomas-finally-reveals-reason-behind-viral-plane-freakout-really-bad-energy](https://www.foxnews.com/media/crazy-plane-lady-tiffany-gomas-finally-reveals-reason-behind-viral-plane-freakout-really-bad-energy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T20:12:23+00:00

The woman who went viral for her meltdown on an American Airlines flight during the summer finally explained what cause her outburst on Friday.

## More ruins of ancient Roman port city found beneath Moroccan capital
 - [https://www.foxnews.com/world/more-ruins-ancient-roman-port-city-found-moroccan-capital](https://www.foxnews.com/world/more-ruins-ancient-roman-port-city-found-moroccan-capital)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T20:01:06+00:00

Archaeologists digging near Morocco&apos;s capital have excavated more ruins of what was likely once a port city controlled by the Roman Empire.

## House approves funding bill slashing EPA budget to 1990 levels, expanding domestic energy production
 - [https://www.foxnews.com/politics/house-approves-funding-bill-slashing-epa-budget-1990-levels-expanding-domestic-energy-production](https://www.foxnews.com/politics/house-approves-funding-bill-slashing-epa-budget-1990-levels-expanding-domestic-energy-production)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T19:45:43+00:00

The House passed an appropriations bill slashing the Environmental Protection Agency&apos;s budget and expanding energy production on federal lands and waters.

## Michigan businessman gets 8 years for using $180M bank fraud scheme to finance massive classic car collection
 - [https://www.foxnews.com/us/michigan-businessman-8-years-using-180m-bank-fraud-scheme-finance-massive-classic-car-collection](https://www.foxnews.com/us/michigan-businessman-8-years-using-180m-bank-fraud-scheme-finance-massive-classic-car-collection)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T19:34:52+00:00

Najeeb Khan, 70, of Edwardsburg, Michigan, has been sentenced to 97 months in prison for orchestrating a $180 million check-kiting scheme.

## Second teacher at Missouri school on leave over OnlyFans side hustle: 'It’s working out ok so far'
 - [https://www.foxnews.com/us/second-teacher-missouri-school-leave-onlyfans-side-hustle-working-ok-so-far](https://www.foxnews.com/us/second-teacher-missouri-school-leave-onlyfans-side-hustle-working-ok-so-far)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T19:34:43+00:00

Another teacher at a Missouri high school was placed on leave after administrators found out she was selling content on OnlyFans, according to a report.

## Missouri man who allegedly brandished pitchfork at J6 riot pleads guilty to 3 charges
 - [https://www.foxnews.com/us/missouri-man-allegedly-brandished-pitchfork-j6-riot-pleads-guilty-3-charges](https://www.foxnews.com/us/missouri-man-allegedly-brandished-pitchfork-j6-riot-pleads-guilty-3-charges)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T19:33:35+00:00

Christopher Roe, 39, of Raytown, Missouri, has pleaded guilty to three counts of assaulting, resisting and impeding certain officers during the Jan. 6, 2021 Capitol riot.

## Naked man tussles with Las Vegas cop before stealing, crashing patrol car: video
 - [https://www.foxnews.com/us/naked-man-tussles-las-vegas-cop-before-stealing-crashing-patrol-car-video](https://www.foxnews.com/us/naked-man-tussles-las-vegas-cop-before-stealing-crashing-patrol-car-video)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T19:31:16+00:00

Clyde Cabulisan, 29, faces four felonies after going hand-to-hand with a Las Vegas cop in the nude and then taking off in his police car with the lights still flashing on Tuesday.

## Jeffries vows Democrats will 'support each other' as groups threaten to primary anti-Israel progressives
 - [https://www.foxnews.com/politics/jeffries-pledges-democrats-will-support-each-other-groups-threaten-primary-anti-israel-progressives](https://www.foxnews.com/politics/jeffries-pledges-democrats-will-support-each-other-groups-threaten-primary-anti-israel-progressives)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T19:11:09+00:00

House Democratic leadership is signaling it will stick by its anti-Israel incumbents. &quot;I think House Democrats are going to continue to support each other,&quot; Hakeem Jeffries said.

## Blinken push for humanitarian pauses in Israeli war falls flat with Netanyahu
 - [https://www.foxnews.com/world/blinken-push-humanitarian-pauses-israeli-war-falls-flat-netanyahu](https://www.foxnews.com/world/blinken-push-humanitarian-pauses-israeli-war-falls-flat-netanyahu)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T19:08:59+00:00

U.S. Secretary of State Anthony Blinken said at meeting with Israeli Prime Minister Benjamin Netanyahu Friday that several pauses could lead to hostages being released

## Teammate of ex-NHL player calls tragic death 'most traumatizing thing I have seen in my entire life': report
 - [https://www.foxnews.com/sports/teammate-ex-nhl-player-calls-tragic-death-most-traumatizing-thing-i-have-seen-my-entire-life-report](https://www.foxnews.com/sports/teammate-ex-nhl-player-calls-tragic-death-most-traumatizing-thing-i-have-seen-my-entire-life-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T18:58:01+00:00

The teammate of ex-NHLer Adam Johnson, who died after being slashed in the neck by skate, recalled the tragic moment the 29-year-old ice hockey player was fatally injured.

## Clayton Kershaw undergoes shoulder surgery, 'hopeful' for summer return
 - [https://www.foxnews.com/sports/clayton-kershaw-undergoes-shoulder-surgery-hopeful-summer-return](https://www.foxnews.com/sports/clayton-kershaw-undergoes-shoulder-surgery-hopeful-summer-return)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T18:52:11+00:00

Los Angeles Dodgers pitcher Clayton Kershaw underwent shoulder surgery, he announced Friday after dealing with soreness during the season.

## Rocket from Gaza hits near Fox News' Trey Yingst: 'Direct impact'
 - [https://www.foxnews.com/world/rocket-gaza-hits-near-fox-news-trey-yingst-direct-impact](https://www.foxnews.com/world/rocket-gaza-hits-near-fox-news-trey-yingst-direct-impact)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T18:40:51+00:00

A missile launched from the Gaza Strip struck an Israeli kindergarten building Friday, not far from a crowd of journalists covering the conflict.

## Enes Kanter Freedom questions Palestinian supporters amid Israeli conflict: 'Your hypocrisy is killing me'
 - [https://www.foxnews.com/sports/enes-kanter-freedom-questions-palestinian-supporters-amid-israeli-conflict-your-hypocrisy-killing-me](https://www.foxnews.com/sports/enes-kanter-freedom-questions-palestinian-supporters-amid-israeli-conflict-your-hypocrisy-killing-me)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T18:35:34+00:00

Former NBA basketball player Enes Kanter Freedom took to X with questions for those who have shown support for Palestinians across the world.

## Missouri officer accused of kicking suspect in head pleads guilty
 - [https://www.foxnews.com/us/missouri-officer-accused-kicking-suspect-head-pleads-guilty](https://www.foxnews.com/us/missouri-officer-accused-kicking-suspect-head-pleads-guilty)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T18:22:26+00:00

Former Police Officer David Maas of Woodson Terrace, Missouri, who stood accused of kicking a suspect in the head, has pleaded guilty to a federal civil rights charge.

## 2 dead, 1 injured in Mexico City-area graveyard shooting on Day of the Dead
 - [https://www.foxnews.com/world/2-dead-1-injured-mexico-city-area-graveyard-shooting-day-of-the-dead](https://www.foxnews.com/world/2-dead-1-injured-mexico-city-area-graveyard-shooting-day-of-the-dead)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T18:17:52+00:00

Two men were fatally shot and a third wounded Thursday at a Naucalpan, Mexico, cemetery during the country&apos;s iconic Day of the Dead holiday.

## Gas explosion at New York multifamily home injures 10
 - [https://www.foxnews.com/us/gas-explosion-new-york-multifamily-home-injures-10](https://www.foxnews.com/us/gas-explosion-new-york-multifamily-home-injures-10)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T18:07:36+00:00

10 people have been reported injured in a Thursday afternoon gas explosion at a Wappingers Falls, New York, multifamily home, officials say.

## PA police investigating multiple claims of rocks thrown at cars from I-83 overpass
 - [https://www.foxnews.com/us/pa-police-investigating-multiple-claims-rocks-thrown-cars-i-83-overpass](https://www.foxnews.com/us/pa-police-investigating-multiple-claims-rocks-thrown-cars-i-83-overpass)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T18:06:25+00:00

Police are searching for suspects accused of throwing rocks at vehicles from a Harrisburg, Pennsylvania-area Interstate 83 overpass on at least four separate occasions.

## JK Rowling: Asking a woman to refer to her male rapist as 'she' is ‘state-sanctioned abuse’
 - [https://www.foxnews.com/media/jk-rowling-asking-woman-refer-male-rapist-she-state-sanctioned-abuse](https://www.foxnews.com/media/jk-rowling-asking-woman-refer-male-rapist-she-state-sanctioned-abuse)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T18:01:37+00:00

The &quot;Harry Potter&quot; author sounded off on a new policy in courts in Southern Australian that endorses the use of preferred gender pronouns in the courtroom.

## Depraved nurse allegedly confessed to trying to kill 19 nursing home patients
 - [https://www.foxnews.com/us/depraved-nurse-allegedly-confessed-trying-kill-19-nursing-home-patients](https://www.foxnews.com/us/depraved-nurse-allegedly-confessed-trying-kill-19-nursing-home-patients)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T17:57:02+00:00

Former Pennsylvania nurse Heather Pressdee has been charged with mistreating 22 patients and causing the death of 17 of them with massive doses of insulin, police allege.

## AI buzzkill detects rowdy parties in an Airbnb rental
 - [https://www.foxnews.com/tech/ai-buzzkill-detects-rowdy-parties-airbnb-rental](https://www.foxnews.com/tech/ai-buzzkill-detects-rowdy-parties-airbnb-rental)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T17:52:22+00:00

Airbnb is using the power of artificial intelligence to catch all the red flags of guests who could pose problems by throwing parties and damaging properties.

## Matthew Perry Foundation launches after actor’s death to help people struggling with addiction
 - [https://www.foxnews.com/entertainment/matthew-perry-foundation-launches-after-actors-death-help-people-struggling-addiction](https://www.foxnews.com/entertainment/matthew-perry-foundation-launches-after-actors-death-help-people-struggling-addiction)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T17:48:49+00:00

A charity called the Matthew Perry Foundation has just been established. Named after the late actor, its mission is to provide assistance to those dealing with addiction.

## Jordanian national living illegally in Texas accused of 'studying how to build bombs' to target Jews: reports
 - [https://www.foxnews.com/us/jordanian-national-living-illegally-texas-accused-studying-build-bombs-target-jews-reports](https://www.foxnews.com/us/jordanian-national-living-illegally-texas-accused-studying-build-bombs-target-jews-reports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T17:42:29+00:00

Authorities say a possible attack against Jewish people was diverted by arresting a man who was living in the Houston area while &quot;studying how to build bombs.&quot;

## Alert St. Louis hotel staff helps save kidnapped Florida women from captors: report
 - [https://www.foxnews.com/us/alert-st-louis-hotel-staff-helps-save-kidnapped-florida-women-from-captors-report](https://www.foxnews.com/us/alert-st-louis-hotel-staff-helps-save-kidnapped-florida-women-from-captors-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T17:34:59+00:00

Two women who were allegedly kidnapped from Florida were rescued from a St. Louis hotel over the weekend after staff received a bizarre call, police said.

## Family of Utah's Kouri Richins defends author accused of poisoning husband, says she could not kill 'anyone'
 - [https://www.foxnews.com/us/family-utah-kouri-richins-defends-author-accused-poisoning-husband-says-she-could-not-kill-anyone](https://www.foxnews.com/us/family-utah-kouri-richins-defends-author-accused-poisoning-husband-says-she-could-not-kill-anyone)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T17:24:52+00:00

The family of Kouri Richins, the Utah mother of three accused of killing her husband with a lethal dose of fentanyl for an insurance payout, spoke in her defense this week.

## VA governor mandates that parents must be notified about drug overdoses in schools
 - [https://www.foxnews.com/us/va-governor-mandates-parents-must-notified-drug-overdoses-schools](https://www.foxnews.com/us/va-governor-mandates-parents-must-notified-drug-overdoses-schools)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T16:55:13+00:00

Virginia Governor Glen Youngkin has mandated that school systems must inform parents about student drug overdoses. School officials say they are taking the issue seriously.

## Jessica Simpson celebrates 6 years of sobriety: 'Unrecognizable version of myself'
 - [https://www.foxnews.com/entertainment/jessica-simpson-celebrates-6-years-sobriety-unrecognizable-version-myself](https://www.foxnews.com/entertainment/jessica-simpson-celebrates-6-years-sobriety-unrecognizable-version-myself)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T16:54:55+00:00

Jessica Simpson celebrated six years of sobriety with a post on Instagram. Simpson, 43, wrote about the &quot;stigma&quot; behind alcoholism after beginning her sober journey in 2017.

## CA jury grants millions to man in lawsuit against weedkiller company
 - [https://www.foxnews.com/us/ca-jury-grants-millions-man-lawsuit-weedkiller-company](https://www.foxnews.com/us/ca-jury-grants-millions-man-lawsuit-weedkiller-company)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T16:25:36+00:00

A California man has been granted $332 million in a lawsuit against Monsanto Co. He claims his cancer resulted from using the company&apos;s weedkiller, citing an active ingredient.

## Illinois trooper making 'miracle' recovery after being shot in routine traffic stop, mom says
 - [https://www.foxnews.com/media/illinois-trooper-making-miracle-recovery-being-shot-routine-traffic-stop-mom-says](https://www.foxnews.com/media/illinois-trooper-making-miracle-recovery-being-shot-routine-traffic-stop-mom-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T16:14:43+00:00

The mother of Illinois State Trooper Dakotah &quot;Kody&quot; Chapman-Green, joined &quot;FOX &amp; Friends First&quot; to discuss her son&apos;s recovery after being shot during a traffic stop.

## Possum disrupts TCU-Texas Tech game, goes viral after being dragged off the field
 - [https://www.foxnews.com/sports/possum-disrupts-tcu-texas-tech-game-goes-viral-being-dragged-off-field](https://www.foxnews.com/sports/possum-disrupts-tcu-texas-tech-game-goes-viral-being-dragged-off-field)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T16:13:11+00:00

A wild possum is going viral on social media after storming the field and disrupting Thursday night&apos;s game between TCU and Texas Tech.

## Russia backs Hamas terrorists, calls Israel 'occupying power' that 'does not' have right to self-defense
 - [https://www.foxnews.com/world/russia-backs-hamas-terrorists-calls-israel-occupying-power-does-not-have-right-self-defense](https://www.foxnews.com/world/russia-backs-hamas-terrorists-calls-israel-occupying-power-does-not-have-right-self-defense)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T16:09:03+00:00

Israeli Prime Minister Benjamin Netanyahu spent years creating closer ties to Russia, but Jerusalem&apos;s eventual support for Ukraine has seemingly driven a wedge between the two nations.

## NC House Speaker Tim Moore announces congressional run
 - [https://www.foxnews.com/us/nc-house-speaker-tim-moore-announces-congressional-run](https://www.foxnews.com/us/nc-house-speaker-tim-moore-announces-congressional-run)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T16:01:13+00:00

Tim Moore, the Republican Speaker of the North Carolina State House, has announced his congressional run in the coming year, according to his political adviser.

## Meet the American who defined a new national identity, Noah Webster, New England patriot armed with the pen
 - [https://www.foxnews.com/lifestyle/meet-american-defined-new-national-identity-noah-webster-new-england-patriot-with-pen](https://www.foxnews.com/lifestyle/meet-american-defined-new-national-identity-noah-webster-new-england-patriot-with-pen)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T15:48:52+00:00

Noah Webster was America&apos;s patriot armed with the pen. He defined 12,000 new words, while using language to establish a powerful new national identity.

## Titans’ Mike Vrabel provides positive update on Treylon Burks: ‘Probably better than how it looked’
 - [https://www.foxnews.com/sports/titans-mike-vrabel-provides-positive-update-treylon-burks-probably-better-than-how-looked](https://www.foxnews.com/sports/titans-mike-vrabel-provides-positive-update-treylon-burks-probably-better-than-how-looked)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T15:41:58+00:00

Tennessee Titans head coach Mike Vrabel said wide receiver Treylon Burks was alert and moving after being carted off the field Thursday night in a loss to the Steelers.

## KY coal mine collapse: Names of trapped workers released as rescue operation for 1 continues
 - [https://www.foxnews.com/us/ky-coal-mine-collapse-names-trapped-workers-released-rescue-operation-1-continues](https://www.foxnews.com/us/ky-coal-mine-collapse-names-trapped-workers-released-rescue-operation-1-continues)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T15:40:03+00:00

The two Kentucky workers who were trapped when a coal mine plant collapsed have been identified. One worker died during rescue efforts and another is believed to be trapped.

## Al Pacino, 83, ordered to pay $30K a month in child support to 29-year-old girlfriend
 - [https://www.foxnews.com/entertainment/al-pacino-83-ordered-pay-30k-month-child-support-29-year-old-girlfriend](https://www.foxnews.com/entertainment/al-pacino-83-ordered-pay-30k-month-child-support-29-year-old-girlfriend)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T15:33:00+00:00

Al Pacino and Noor Alfallah&apos;s custody agreement has been made public, with the actor being ordered to pay $30,000 each month in child support for their infant son.

## Liberal city council demands Biden push for Israeli ceasefire to end 'current violence' in Gaza
 - [https://www.foxnews.com/us/liberal-city-council-demands-biden-push-israeli-ceasefire-end-current-violence-gaza](https://www.foxnews.com/us/liberal-city-council-demands-biden-push-israeli-ceasefire-end-current-violence-gaza)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T15:27:43+00:00

A Rhode Island city council passed a resolution Thursday urging the Biden administration to order a ceasefire to end the &quot;current violence&quot; in Gaza.

## How to associate a ringtone with one of your contacts on your phone
 - [https://www.foxnews.com/tech/how-associate-ringtone-one-your-contacts-your-phone](https://www.foxnews.com/tech/how-associate-ringtone-one-your-contacts-your-phone)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T15:26:50+00:00

Want to have a specific ringtone for each of your contacts? Kurt &quot;The CyberGuy&quot; Knutsson explains how to select and purchase various sounds for your contacts on the iPhone and Android.

## Hezbollah leader praises 'heroic' Hamas terror attack, threatens to expand fight against Israel
 - [https://www.foxnews.com/world/hezbollah-leader-praises-heroic-hamas-terror-attack-threatens-to-expand-fight-against-israel](https://www.foxnews.com/world/hezbollah-leader-praises-heroic-hamas-terror-attack-threatens-to-expand-fight-against-israel)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T15:19:56+00:00

Hezbollah leader Hassan Nasrallah delivered his first speech since the Israel-Hamas war began, praising the brutal Oct. 7 terror attack and threatening Israel.

## Bowman snaps at reporter for calling out inconsistent fire alarm story: ‘I was straight from the beginning’
 - [https://www.foxnews.com/media/bowman-snaps-reporter-calling-out-inconsistent-fire-alarm-story-straight-from-beginning](https://www.foxnews.com/media/bowman-snaps-reporter-calling-out-inconsistent-fire-alarm-story-straight-from-beginning)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T15:15:34+00:00

Rep. Jamaal Bowman, D-N.Y., refused to answer questions from a reporter as to why his story changed after he pleaded guilty to illegally pulling a fire alarm.

## Bryan Kohberger case: Idaho judge allows cameras to remain in courtroom
 - [https://www.foxnews.com/us/bryan-kohberger-case-idaho-judge-allows-cameras-remain-courtroom](https://www.foxnews.com/us/bryan-kohberger-case-idaho-judge-allows-cameras-remain-courtroom)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T15:11:59+00:00

Idaho judge overseeing Bryan Kohberger&apos;s university student stabbings case says he is &quot;not going to ban cameras&quot; from high-profile court proceedings.

## Black voters in Milwaukee list complaints on Biden, Democratic Party ahead of 2024: 'We're damned anyways'
 - [https://www.foxnews.com/media/black-voters-milwaukee-list-complaints-biden-democratic-party-ahead-2024-were-damned-anyways](https://www.foxnews.com/media/black-voters-milwaukee-list-complaints-biden-democratic-party-ahead-2024-were-damned-anyways)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T14:46:45+00:00

Black voters and activists in Milwaukee are feeling uninspired to vote for President Biden with one year to go before the election, according to a CNN report.

## MI man receives prison sentence for killing parents and burying their bodies
 - [https://www.foxnews.com/us/mi-man-receives-prison-sentence-killing-parents-burying-bodies](https://www.foxnews.com/us/mi-man-receives-prison-sentence-killing-parents-burying-bodies)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T14:24:42+00:00

A Michigan man has received his prison sentence after officials say he murdered his parents and buried their bodies at a state game area. Nicholas Johnson pleaded no contest.

## The scary side of the Biden administration, AOC the Hamburglar, and more from Fox News Opinion
 - [https://www.foxnews.com/opinion/scary-side-biden-administration-aoc-hamburglar-more-fox-news-opinion](https://www.foxnews.com/opinion/scary-side-biden-administration-aoc-hamburglar-more-fox-news-opinion)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T14:06:28+00:00

Read the latest from Fox News Opinion &amp; watch videos from Sean Hannity, Raymond Arroyo &amp; more.

## A $35,000-a-year boarding school named AI bot its 'principal headteacher.' The headmaster says its helping
 - [https://www.foxnews.com/tech/35000-year-boarding-school-named-ai-bot-principal-headteacher-headmaster-says-helping](https://www.foxnews.com/tech/35000-year-boarding-school-named-ai-bot-principal-headteacher-headmaster-says-helping)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T14:00:41+00:00

Cottesmore School announced an AI bot would be the institution&apos;s &quot;principal headteacher.&quot; The tool has helped faculty reduce time spent on administrative tasks, the headmaster said.

## Steelers' TJ Watt sacks rookie Will Levis despite having helmet ripped off
 - [https://www.foxnews.com/sports/steelers-tj-watt-sacks-rookie-will-levis-despite-having-helmet-ripped-off](https://www.foxnews.com/sports/steelers-tj-watt-sacks-rookie-will-levis-despite-having-helmet-ripped-off)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T13:59:21+00:00

Pittsburgh Steelers star linebacker T.J. Watt made sack number 9.5 of the season after taking rookie quarterback Will Levis down after getting his helmet ripped off.

## 2023 Rock & Roll Hall of Fame inductees include Missy Elliot, Willie Nelson and the late George Michael
 - [https://www.foxnews.com/entertainment/2023-rock-roll-hall-fame-inductees-include-missy-elliot-willie-nelson-late-george-michael](https://www.foxnews.com/entertainment/2023-rock-roll-hall-fame-inductees-include-missy-elliot-willie-nelson-late-george-michael)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T13:58:11+00:00

The 2023 Rock &amp; Roll Hall of Fame induction ceremony is welcoming musicians such as Missy Elliott, Kate Bush, Willie Nelson, Sheryl Crow, Chaka Khan and the late George Michael.

## Man in SC accused of driving through Oconee Nuclear Station security fences, search underway
 - [https://www.foxnews.com/us/man-sc-accused-driving-oconee-nuclear-station-security-fences-search-underway](https://www.foxnews.com/us/man-sc-accused-driving-oconee-nuclear-station-security-fences-search-underway)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T13:45:46+00:00

A man attempted to breach security at a nuclear plant in South Carolina Thursday night and injured employees who stood in his way, police say. He is still on the loose.

## TX homeowner found guilty of manslaughter after fatally shooting man who pulled into his driveway
 - [https://www.foxnews.com/us/tx-homeowner-found-guilty-manslaughter-fatally-shooting-man-pulled-driveway](https://www.foxnews.com/us/tx-homeowner-found-guilty-manslaughter-fatally-shooting-man-pulled-driveway)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T13:45:10+00:00

A Texas jury has found 67-year-old Terry Duane Turner guilty of manslaughter after he fatally shot a man parked in his driveway in 2021. The man he killed was allegedly lost.

## French phenom Victor Wembanyama posts career-high 38 points in 5th game
 - [https://www.foxnews.com/sports/french-phenom-victor-wembanyama-posts-career-high-38-points-fifth-game](https://www.foxnews.com/sports/french-phenom-victor-wembanyama-posts-career-high-38-points-fifth-game)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T13:35:49+00:00

San Antonio Spurs rookie Victor Wembanyama scored a career-high 38 points in just his fifth game as the Spurs beat the Phoenix Suns Thursday night.

## 10 essential Thanksgiving kitchen tools that make cooking a breeze
 - [https://www.foxnews.com/lifestyle/amazon-thanksgiving-kitchen-essentials](https://www.foxnews.com/lifestyle/amazon-thanksgiving-kitchen-essentials)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T13:25:02+00:00

Get ready for the biggest cooking holiday of the year with these kitchen essentials on Amazon. From turkey to pie, these kitchen gadgets can help you prepare your favorite Thanksgiving recipes.

## Target CEO calls Pride Month display backlash 'first time' team felt 'not safe' at work
 - [https://www.foxnews.com/media/target-ceo-calls-pride-month-display-backlash-first-time-team-felt-not-safe-work](https://www.foxnews.com/media/target-ceo-calls-pride-month-display-backlash-first-time-team-felt-not-safe-work)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T13:09:15+00:00

CNBC spoke with Target CEO Brian Cornell about ongoing backlash against the company for promoting LGBTQ merchandise and displays ahead of Pride Month.

## Fish travel in style on train as man keeps tank's air filter going: 'Most ridiculous thing I've ever seen'
 - [https://www.foxnews.com/lifestyle/fish-travel-train-man-keeps-tanks-air-filter-going-most-ridiculous-thing-ive-seen](https://www.foxnews.com/lifestyle/fish-travel-train-man-keeps-tanks-air-filter-going-most-ridiculous-thing-ive-seen)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T13:04:56+00:00

A fellow train passenger heading to Derby, in the United Kingdom, snapped this photo of a man traveling with a fish tank full of water — and yes, fish — plugged into the electric socket.

## TX sheriff's office probed by FBI over corruption allegations
 - [https://www.foxnews.com/us/tx-sheriffs-office-probed-fbi-corruption-allegations](https://www.foxnews.com/us/tx-sheriffs-office-probed-fbi-corruption-allegations)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T12:55:36+00:00

A Texas sheriff who has been the target of corruption allegations by his coworkers is now under investigation by the FBI.

## MI man admits to double homicide of 2 women, including teen
 - [https://www.foxnews.com/us/mi-man-admits-double-homicide-2-women-teen](https://www.foxnews.com/us/mi-man-admits-double-homicide-2-women-teen)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T12:55:12+00:00

A Michigan man facing charges in connection to the homicide of two women, including a teen, has admitted to murder in exchange for more lenient charges.

## WI sheriff's deputy fatally shoots armed fugitive during arrest attempt
 - [https://www.foxnews.com/us/wi-sheriffs-deputy-fatally-shoots-armed-fugitive-arrest-attempt](https://www.foxnews.com/us/wi-sheriffs-deputy-fatally-shoots-armed-fugitive-arrest-attempt)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T12:54:38+00:00

A Wisconsin sheriff&apos;s deputy fatally shot and killed a wanted fugitive while attempting to apprehend them. The shooting allegedly happened after the suspect fled from officers.

## Former Playboy White House reporter says 'MAGA and Christian nationalism' are 'bigger threat' to US than Hamas
 - [https://www.foxnews.com/media/former-playboy-white-house-reporter-maga-christian-nationalism-bigger-threat-hamas](https://www.foxnews.com/media/former-playboy-white-house-reporter-maga-christian-nationalism-bigger-threat-hamas)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T12:40:25+00:00

Playboy’s former senior White House correspondent, Brian Karem, wrote a fiery opinion piece condemning House Republicans as a worse threat to the U.S. than Hamas.

## Israeli MMA fighter writes names of Muslim UFC stars on missile
 - [https://www.foxnews.com/sports/israeli-mma-fighter-writes-names-muslim-ufc-stars-missile](https://www.foxnews.com/sports/israeli-mma-fighter-writes-names-muslim-ufc-stars-missile)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T12:34:16+00:00

Former Bellator star Haim Gozali, who is from Israel, posted a photo on social media of the names of four Muslim USC fighters on a missile.

## NY county lawmaker faces criminal mischief charges after allegedly slashing tire outside bar
 - [https://www.foxnews.com/us/ny-county-lawmaker-faces-criminal-mischief-charges-allegedly-slashing-tire-bar](https://www.foxnews.com/us/ny-county-lawmaker-faces-criminal-mischief-charges-allegedly-slashing-tire-bar)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T12:21:19+00:00

A New York county legislator is facing accusations of vandalizing a truck outside a bar. Niagara County Legislator William Collins Sr. has been charged with criminal mischief.

## Fulton County Jail faces civil rights investigation and calls for reform
 - [https://www.foxnews.com/us/fulton-county-jail-faces-civil-rights-investigation-calls-reform](https://www.foxnews.com/us/fulton-county-jail-faces-civil-rights-investigation-calls-reform)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T12:20:13+00:00

The deteriorating state of an Atlanta jail has raised concerns about inmate safety. This comes after reports of inmates using broken flooring and pipes to craft their own weapons.

## GA school superintendent urges lawmakers to grant raise for educators
 - [https://www.foxnews.com/us/ga-school-superintendent-urges-lawmakers-grant-raise-educators](https://www.foxnews.com/us/ga-school-superintendent-urges-lawmakers-grant-raise-educators)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T12:09:38+00:00

A Georgia school superintendent has urged the governor to allocate a salary increase for teachers in the upcoming year in addition to changing the state&apos;s funding plan.

## Speaker Johnson must return People’s House to needs of the people
 - [https://www.foxnews.com/opinion/speaker-johnson-must-return-peoples-house-needs-people](https://www.foxnews.com/opinion/speaker-johnson-must-return-peoples-house-needs-people)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T12:00:10+00:00

New Republican Speaker Mike Johnson has a chance to get the People’s House to embrace the needs of the American people. He must stand strong on the border, economy and Israel.

## Michigan scandal sparks player injury concerns, athletic directors tell to Big Ten must 'step up': report
 - [https://www.foxnews.com/sports/michigan-scandal-sparks-player-injury-concerns-athletic-directors-tell-to-big-ten-must-step-up-report](https://www.foxnews.com/sports/michigan-scandal-sparks-player-injury-concerns-athletic-directors-tell-to-big-ten-must-step-up-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T11:33:36+00:00

A group of athletic directors reportedly urged the Big Ten Conference to take disciplinary action against the Michigan football due to the program&apos;s ongoing sign-stealing scandal.

## Hezbollah claims to strike Israeli army with two suicide drones: report
 - [https://www.foxnews.com/world/hezbollah-claims-strike-israeli-army-two-suicide-drones-report](https://www.foxnews.com/world/hezbollah-claims-strike-israeli-army-two-suicide-drones-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T11:26:51+00:00

The Lebanese militant group Hezbollah claimed Thursday to have targeted Israeli troops with two drones packed with explosives, a report says.

## VP Harris blasted for 'tone deaf' post announcing anti-Islamophobia plan amid Israel-Hamas war
 - [https://www.foxnews.com/politics/vp-harris-blasted-tone-deaf-post-announcing-anti-islamophobia-plan-israel-hamas-war](https://www.foxnews.com/politics/vp-harris-blasted-tone-deaf-post-announcing-anti-islamophobia-plan-israel-hamas-war)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T11:22:46+00:00

Vice President Kamala Harris was slammed by critics who called her tone deaf in response to a video where she announced the White House&apos;s plan against &quot;Islamophobia.&quot;

## AL lawmaker's jail stay extended after violating bond conditions
 - [https://www.foxnews.com/us/al-lawmakers-jail-stay-extended-violating-bond-conditions](https://www.foxnews.com/us/al-lawmakers-jail-stay-extended-violating-bond-conditions)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T11:12:25+00:00

An Alabama judge has ordered the continued detention of Alabama State Representative John Rogers, a Democrat from Birmingham, after determining that he violated bond conditions.

## Virginia high school suffers 7 opioid-related overdoses in 3 weeks
 - [https://www.foxnews.com/media/virginia-high-school-7-opioid-related-overdoses-3-weeks](https://www.foxnews.com/media/virginia-high-school-7-opioid-related-overdoses-3-weeks)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T11:00:40+00:00

A Loudoun County high school had seven students suffer from opioid overdoses, four of which, according to law enforcement, occurred on school grounds.

## Hines Ward: Georgia's No 2 ranking in College Football Playoff made him 'feel some type of way'
 - [https://www.foxnews.com/sports/hines-ward-georgias-no-2-ranking-college-football-playoff-made-him-feel-type-way](https://www.foxnews.com/sports/hines-ward-georgias-no-2-ranking-college-football-playoff-made-him-feel-type-way)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T10:30:51+00:00

Pittsburgh Steelers legend and Georgia Bulldogs alumni Hines Ward admitted that the first College Football Playoffs rubbed him the wrong way after Ohio State was named No. 1.

## As Vikings, Kirk Cousins focus on recovery, future, doctor offers insight into Achilles injuries
 - [https://www.foxnews.com/sports/vikings-kirk-cousins-focus-recovery-future-doctor-offers-insight-achilles-injuries](https://www.foxnews.com/sports/vikings-kirk-cousins-focus-recovery-future-doctor-offers-insight-achilles-injuries)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T10:30:21+00:00

Minnesota Vikings quarterback Kirk Cousins is expected to miss the remainder of the 2023 season, his final contract year, after suffering a torn Achilles on Sunday.

## NASCAR Cup Series Championship Four: What to know about the 2023 title race
 - [https://www.foxnews.com/sports/nascar-cup-series-championship-four-what-know-2023-title-race](https://www.foxnews.com/sports/nascar-cup-series-championship-four-what-know-2023-title-race)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T10:30:13+00:00

The 2023 NASCAR Cup Series season comes down to one race on Sunday afternoon as Ryan Blaney, Christopher Bell, Kyle Larson and William Byron compete for a title.

## Sandwich quiz! How well do you know these facts about the popular grab-and-go meal?
 - [https://www.foxnews.com/lifestyle/sandwich-quiz-how-well-know-these-facts-about-popular-grab-go-meal](https://www.foxnews.com/lifestyle/sandwich-quiz-how-well-know-these-facts-about-popular-grab-go-meal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T10:26:38+00:00

Sandwich quiz! Test your knowledge of all things meat, cheese and condiment-related in this fun lifestyle quiz about different types of sandwiches and more!

## Verdict reached in FTX founder's trial, House passes Israel funding bill and more top headlines
 - [https://www.foxnews.com/us/verdict-reached-in-ftx-founders-trial-house-passes-israel-funding-bill](https://www.foxnews.com/us/verdict-reached-in-ftx-founders-trial-house-passes-israel-funding-bill)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T10:19:42+00:00

Get all the stories you need-to-know from the most powerful name in news delivered first thing every morning to your inbox.

## Travis Kelce's mom explains why Chiefs star has taken game to 'new level' amid Taylor Swift relationship
 - [https://www.foxnews.com/sports/travis-kelces-mom-explains-why-chiefs-star-taken-game-new-level-amid-taylor-swift-relationship](https://www.foxnews.com/sports/travis-kelces-mom-explains-why-chiefs-star-taken-game-new-level-amid-taylor-swift-relationship)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T10:15:19+00:00

Travis Kelce&apos;s relationship with Taylor Swift led some to believe he wouldn&apos;t perform well for the Chiefs this season, but his mother, Donna Kelce, explained why it motivates him more.

## Fox Sports’ Tim Brando weighs in after first College Football Playoff rankings
 - [https://www.foxnews.com/sports/fox-sports-tim-brando-weighs-after-first-college-football-playoff-rankings](https://www.foxnews.com/sports/fox-sports-tim-brando-weighs-after-first-college-football-playoff-rankings)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T10:15:11+00:00

Fox Sports college football play-by-play announcer Tim Brando spoke with Fox News Digital days after the first College Football Playoff rankings were released.

## NFL Week 9 preview: AFC's top teams meet in Germany, Damar Hamlin returns to Cincy and more to know
 - [https://www.foxnews.com/sports/nfl-week-9-preview-afcs-top-teams-meet-germany-damar-hamlin-returns-to-cincy-more-know](https://www.foxnews.com/sports/nfl-week-9-preview-afcs-top-teams-meet-germany-damar-hamlin-returns-to-cincy-more-know)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T10:00:25+00:00

The 2023 NFL season will be half over after the completion of Week 9. But there&apos;s so much to know about this week&apos;s games before kickoff.

## LAURA INGRAHAM: This is a spectacular sabotaging of America by our own president
 - [https://www.foxnews.com/media/laura-ingraham-spectacular-sabotaging-america-our-own-president](https://www.foxnews.com/media/laura-ingraham-spectacular-sabotaging-america-our-own-president)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T09:54:29+00:00

Laura Ingraham highlights how the Biden admin is selling out America to China on &quot;The Ingraham Angle.&quot;

## Ohio State legend Eddie George offers interesting take on Michigan sign-stealing scandal
 - [https://www.foxnews.com/sports/ohio-state-legend-eddie-george-offers-interesting-take-michigan-sign-stealing-scandal](https://www.foxnews.com/sports/ohio-state-legend-eddie-george-offers-interesting-take-michigan-sign-stealing-scandal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T09:30:38+00:00

Former Ohio State Buckeyes star Eddie George talked to OutKick&apos;s Dan Dakich on Thursday morning about the Michigan sign-stealing scandal.

## Matthew Perry toxicology reports provide insight into how star may have died: former medical examiner
 - [https://www.foxnews.com/entertainment/matthew-perry-toxicology-reports-provide-insight-into-how-star-may-have-died](https://www.foxnews.com/entertainment/matthew-perry-toxicology-reports-provide-insight-into-how-star-may-have-died)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T09:30:12+00:00

Questions remain into the death of actor Matthew Perry after reports that fentanyl and meth were not found in his system when he died nearly one week ago.

## Police commissioner who helped catch Gilgo Beach serial murder suspect announces surprise resignation
 - [https://www.foxnews.com/us/police-commissioner-helped-catch-gilgo-beach-serial-murder-suspect-announces-surprise-resignation](https://www.foxnews.com/us/police-commissioner-helped-catch-gilgo-beach-serial-murder-suspect-announces-surprise-resignation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T09:08:38+00:00

Suffolk County Police Commissioner Rodney Harrison, who helped lead the task force that apprehended Rex Heuermann, the suspect in the Gilgo Beach serial murder case.

## Connor Stalions and Michigan alleged cheating scandal: Timeline and everything fans need to know
 - [https://www.foxnews.com/sports/connor-stalions-michigan-alleged-cheating-scandal-timeline-everything-fans-need-know](https://www.foxnews.com/sports/connor-stalions-michigan-alleged-cheating-scandal-timeline-everything-fans-need-know)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T09:00:58+00:00

The college football world waits with baited breath on what the NCAA or the Big Ten will do with Michigan amid the program&apos;s sign-stealing scandal.

## Woman warns freedom under fire after police encounters over 'thought crime' of prayer: 'Nothing they can't do'
 - [https://www.foxnews.com/media/woman-freedom-fire-police-encounters-thought-crime-prayer-nothing](https://www.foxnews.com/media/woman-freedom-fire-police-encounters-thought-crime-prayer-nothing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T09:00:57+00:00

Pro-life activist Isabel Vaughan-Spruce is speaking out after facing threats of being fined for praying inside an abortion clinic&apos;s &quot;buffer zone&quot; in England.

## 7 tips for falling asleep on long-haul flights (Hint: Skip the alcohol, coffee and sedatives)
 - [https://www.foxnews.com/health/7-tips-falling-asleep-long-haul-flights-hint-skip-alcohol-coffee-sedatives](https://www.foxnews.com/health/7-tips-falling-asleep-long-haul-flights-hint-skip-alcohol-coffee-sedatives)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T09:00:55+00:00

Getting some decent sleep on a long-haul flight may be a challenge, but sleep specialists and others shared thoughtful steps to take to help bring on the zzz&apos;s while in the air.

## Why immunotherapy is emerging as the ‘fourth pillar’ of cancer treatments, experts say
 - [https://www.foxnews.com/health/immunotherapy-emerging-fourth-pillar-cancer-treatments-experts-say](https://www.foxnews.com/health/immunotherapy-emerging-fourth-pillar-cancer-treatments-experts-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T09:00:50+00:00

For decades, the go-to treatments for cancer have been chemotherapy, radiation and surgery — but some experts claim that a fourth option, immunotherapy, is showing promising results.

## Attacks on Israel are only the beginning. All democracies are at risk
 - [https://www.foxnews.com/opinion/attacks-israel-only-beginning-democracies-risk](https://www.foxnews.com/opinion/attacks-israel-only-beginning-democracies-risk)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T09:00:36+00:00

Hamas&apos;s horrifying attack in Israel has global support -- from protests in major cities to college campuses. This is an important reminder that all democracies are at risk.

## Reject Biden's hysteria-based climate and energy mandates. Here's the sensible way forward
 - [https://www.foxnews.com/opinion/reject-bidens-hysteria-based-climate-energy-mandates-heres-sensible-way-forward](https://www.foxnews.com/opinion/reject-bidens-hysteria-based-climate-energy-mandates-heres-sensible-way-forward)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T09:00:34+00:00

President Biden and climate activists like to present a stark choice – accept radical decarbonization now or face a catastrophic future. That is a false dichotomy.

## Charlie Chaplin's exile from America included paternity trial, sexual allegations: book
 - [https://www.foxnews.com/entertainment/charlie-chaplins-paternity-trial-sexual-allegations-contributed-stars-exile-america-book](https://www.foxnews.com/entertainment/charlie-chaplins-paternity-trial-sexual-allegations-contributed-stars-exile-america-book)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T09:00:21+00:00

Charlie Chaplin, the silent movie star who famously played The Tramp, died in 1977 at age 88. The actor spent his final years in exile and resided in Switzerland.

## Why does US economically help nations that want to harm the West?
 - [https://www.foxnews.com/opinion/why-does-us-economically-help-nations-want-harm-west](https://www.foxnews.com/opinion/why-does-us-economically-help-nations-want-harm-west)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T09:00:08+00:00

Defeating Russian, Chinese and Iranian aggression requires ending the economic support given to them through sanctions loopholes, subsidies, investments and other aid.

## ‘Happy Days’ star Henry Winkler reveals low point in his 45 year marriage: ‘not my finest hour’
 - [https://www.foxnews.com/entertainment/happy-days-star-henry-winkler-reveals-low-point-45-year-marriage-not-my-finest-hour](https://www.foxnews.com/entertainment/happy-days-star-henry-winkler-reveals-low-point-45-year-marriage-not-my-finest-hour)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T08:30:30+00:00

Henry Winkler and Stacey Weitzman met in 1976. They married in 1978. They&apos;ve raised three children together: Zoe, Jed and Max. The Emmy Award-winning actor has written a new book.

## Homeschooled children honor Medal of Honor recipient Fr. Emil Kapaun at Arlington National Cemetery
 - [https://www.foxnews.com/lifestyle/homeschooled-children-honor-medal-honor-recipient-fr-emil-kapaun-arlington-national-cemetery](https://www.foxnews.com/lifestyle/homeschooled-children-honor-medal-honor-recipient-fr-emil-kapaun-arlington-national-cemetery)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T08:30:08+00:00

Virginia-based homeschooled students honored Fr. Emil Kapaun, an Army chaplain who died in a Korean POW camp, in a ceremony on the anniversary of the heroic act that earned him the Medal of Honor.

## Seinfeld, Margulies, other industry heavyweights rip Hollywood’s hypocrisy on antisemitism: ‘Failed us deeply’
 - [https://www.foxnews.com/media/seinfeld-margulies-industry-heavyweights-rip-hollywoods-hypocrisy-antisemitism-failed-deeply](https://www.foxnews.com/media/seinfeld-margulies-industry-heavyweights-rip-hollywoods-hypocrisy-antisemitism-failed-deeply)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T08:30:05+00:00

Celebrities and other industry insiders have been blasting their Hollywood colleagues for not speaking out against Hamas&apos; attack on Israel and the rising wave of antisemitism.

## United Nations allowing Hamas to ‘literally get away with murder,’ expert says
 - [https://www.foxnews.com/world/united-nations-allowing-hamas-literally-get-away-murder-expert-says](https://www.foxnews.com/world/united-nations-allowing-hamas-literally-get-away-murder-expert-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T08:00:48+00:00

Israeli policy expert Aviva Klompas slammed United Nations Secretary-General António Guterres for calling for a cease-fire as war continues raging in Israel.

## Virginia's elections a key 2024 barometer and a huge test for rising GOP star Glenn Youngkin
 - [https://www.foxnews.com/politics/virginias-elections-key-2024-barometer-huge-test-rising-gop-star-glenn-youngkin](https://www.foxnews.com/politics/virginias-elections-key-2024-barometer-huge-test-rising-gop-star-glenn-youngkin)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T08:00:46+00:00

All political eyes are on Virginia ahead of Tuesday’s high profile and crucial legislative elections, which are seen as a crucial bellwether ahead of the 2024 showdowns

## David Copperfield plans to make moon disappear in epic stunt 30 years in making
 - [https://www.foxnews.com/entertainment/david-copperfield-plans-make-moon-disappear-epic-stunt-30-years-making](https://www.foxnews.com/entertainment/david-copperfield-plans-make-moon-disappear-epic-stunt-30-years-making)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T08:00:38+00:00

David Copperfield revealed his next grand illusion will be making the moon disappear in 2024. The trick has been 30 years in the making, and comes after a series of historic illusions.

## Elite American universities receiving billions in federal funds see rise in antisemitism: 'Gamed the tax code'
 - [https://www.foxnews.com/politics/elite-american-universities-receiving-billions-federal-funds-see-rise-in-antisemitism](https://www.foxnews.com/politics/elite-american-universities-receiving-billions-federal-funds-see-rise-in-antisemitism)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T08:00:37+00:00

Harvard and the University of Pennsylvania, which have been under fire for their response to antisemitic events on campus, receive billions in federal funds, an analysis found.

## Local Alabama newspaper publisher, reporter arrested for reporting confidential grand jury information
 - [https://www.foxnews.com/media/local-alabama-newspaper-publisher-reporter-arrested-reporting-confidential-grand-jury-information](https://www.foxnews.com/media/local-alabama-newspaper-publisher-reporter-arrested-reporting-confidential-grand-jury-information)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T08:00:31+00:00

Atmore News owner Sherry Digmon and reporter Donald Fletcher were arrested and charged with revealing information about a grand jury probe involving the local school system.

## Kristin Smart's killer nearly died during prison attack by inmate who murdered 'I-5 Strangler'
 - [https://www.foxnews.com/us/kristin-smart-killer-nearly-died-during-prison-attack-inmate-who-murdered-i-5-strangler](https://www.foxnews.com/us/kristin-smart-killer-nearly-died-during-prison-attack-inmate-who-murdered-i-5-strangler)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T08:00:28+00:00

Paul Flores, who was found guilty of murdering Kristin Smart, was beaten by California inmate Jason Budrow, who killed his serial killer cellmate in 2021.

## Thousands of National Guard troops have not received promised enlistment bonuses
 - [https://www.foxnews.com/us/thousands-of-national-guard-troops-have-not-received-promised-enlistment-bonuses](https://www.foxnews.com/us/thousands-of-national-guard-troops-have-not-received-promised-enlistment-bonuses)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T08:00:23+00:00

The National Guard is late paying enlistment bonuses to close to 14,000 service members who were promised as much as $20,000 to join the part-time volunteer force.

## 'Take Care of Maya' trial: pics of plaintiff in $220m hospital lawsuit create controversy amid explosive case
 - [https://www.foxnews.com/us/take-care-maya-trial-pics-plaintiff-220m-hospital-lawsuit-create-controversy-amid-explosive-case](https://www.foxnews.com/us/take-care-maya-trial-pics-plaintiff-220m-hospital-lawsuit-create-controversy-amid-explosive-case)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T08:00:19+00:00

Photos of Maya Kowalski at prom, homecoming and Halloween were shown to jurors by attorneys defending Johns Hopkins All Children&apos;s Hospital in a $220 million medical malpractice suit.

## Navy SEAL veteran, Senate candidate urges Biden to 'stop enabling Iran' as Israel fights for 'survival'
 - [https://www.foxnews.com/politics/navy-seal-veteran-senate-candidate-urges-biden-stop-enabling-iran-israel-fights](https://www.foxnews.com/politics/navy-seal-veteran-senate-candidate-urges-biden-stop-enabling-iran-israel-fights)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T08:00:10+00:00

Montana Senate candidate Tim Sheehy overemphasized the need to support Israel during its war against Hamas and said he does not support combining aid to Israel with Ukraine.

## Mike Johnson bucks trend of House speakers owning high-dollar assets: 'Man of the people'
 - [https://www.foxnews.com/politics/mike-johnson-bucks-trend-house-speakers-owning-high-dollar-financial-assets-man-people](https://www.foxnews.com/politics/mike-johnson-bucks-trend-house-speakers-owning-high-dollar-financial-assets-man-people)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T08:00:08+00:00

Speaker Mike Johnson, R-La., is facing criticism for having a financial portfolio similar to most Americans after his predecessors owned hundreds of thousands of dollars in assets.

## House Republican bill targets Biden's progressive Climate Corps plan
 - [https://www.foxnews.com/politics/house-republican-bill-targets-bidens-progressive-climate-corps-plan](https://www.foxnews.com/politics/house-republican-bill-targets-bidens-progressive-climate-corps-plan)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T08:00:06+00:00

A new House GOP bill is targeting President Biden&apos;s plan for a civilian climate corps.

## Casey Anthony attorney to represent ex-wife of slain Microsoft exec
 - [https://www.foxnews.com/us/casey-anthony-attorney-represent-ex-wife-slain-microsoft-exec](https://www.foxnews.com/us/casey-anthony-attorney-represent-ex-wife-slain-microsoft-exec)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T08:00:01+00:00

The attorney who famously won an acquittal in the Casey Anthony murder trial is now representing Shanna Gardner-Fernandez, who is charged with planning the fatal shooting of her ex.

## Alarming new trend is emerging as younger Americans eschew alcohol on dates, go more for cannabis
 - [https://www.foxnews.com/media/alarming-trend-younger-americans-alcohol-dates-more-cannabis](https://www.foxnews.com/media/alarming-trend-younger-americans-alcohol-dates-more-cannabis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T07:30:58+00:00

Gen Z Americans are drinking significantly less alcohol than previous generations, but that cut back has been replaced with an increase in cannabis use.

## T.J. Holmes-Amy Robach 'gross' podcast announcement brings back bad memories after scandal: former ABC insider
 - [https://www.foxnews.com/media/t-j-holmes-amy-robach-gross-podcast-announcement-brings-back-bad-memories-after-scandal-former-abc-insider](https://www.foxnews.com/media/t-j-holmes-amy-robach-gross-podcast-announcement-brings-back-bad-memories-after-scandal-former-abc-insider)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T07:00:03+00:00

The new podcast coming from former ABC News lovebirds T.J. Holmes and Amy Robach is getting a mixed reaction, with one former network insider calling it &quot;gross.&quot;

## Businesswoman Kathy Ireland on AI: ‘Can’t stress enough’ the need to be alert
 - [https://www.foxnews.com/entertainment/businesswoman-kathy-ireland-on-ai-cant-stress-enough-need-to-be-alert](https://www.foxnews.com/entertainment/businesswoman-kathy-ireland-on-ai-cant-stress-enough-need-to-be-alert)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T06:00:59+00:00

Former model-turned-entrepreneur Kathy Ireland warns that with the rapid advancements in artificial intelligence, it&apos;s important to be &quot;alert&quot; to its impacts.

## How icons Teddy Roosevelt and Booker T. Washington blazed a path for racial equality
 - [https://www.foxnews.com/opinion/how-icons-teddy-roosevelt-booker-washington-blazed-path-racial-equality](https://www.foxnews.com/opinion/how-icons-teddy-roosevelt-booker-washington-blazed-path-racial-equality)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T06:00:54+00:00

American intellectual and former slave Booker T. Washington had a unique partnership with Teddy Roosevelt. The friendship between the two men would change America for the better.

## Biden admin's AI Safety Institute not 'sufficient' to deal with risks, must check user 'procedures': expert
 - [https://www.foxnews.com/us/biden-admins-ai-safety-institute-not-sufficient-deal-risks-check-user-procedures-expert](https://www.foxnews.com/us/biden-admins-ai-safety-institute-not-sufficient-deal-risks-check-user-procedures-expert)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T06:00:49+00:00

President Biden&apos;s executive order aims to test whether AI algorithms pose concerns for national security, but experts say the government needs to examine other factors.

## On this day in history, November 3, 1956, 'The Wizard of Oz' debuts on TV, elevates film to American classic
 - [https://www.foxnews.com/lifestyle/this-day-history-nov-3-1956-wizard-oz-debuts-tv](https://www.foxnews.com/lifestyle/this-day-history-nov-3-1956-wizard-oz-debuts-tv)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T04:02:23+00:00

&quot;The Wizard of Oz&quot; debuted on television on Nov. 3, 1956 — 17 years after it was released on the silver screen. The movie failed to turn a profit, but TV turned it into an American classic.

## Jason Aldean talks release of 11th studio album, controversy over 'Try That In A Small Town'
 - [https://www.foxnews.com/media/jason-aldean-talks-release-11th-studio-album-controversy-over-try-that-in-a-small-town](https://www.foxnews.com/media/jason-aldean-talks-release-11th-studio-album-controversy-over-try-that-in-a-small-town)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T04:00:44+00:00

Country music artist Jason Aldean joins &apos;FOX &amp; Friends&apos; to discuss the release of his album &apos;Highway Desperado,&apos; and more.&apos;

## Diontae Johnson's first touchdown since 2021 lifts Steelers over Titans
 - [https://www.foxnews.com/sports/diontae-johnsons-first-touchdown-since-2021-lifts-steelers-over-titans](https://www.foxnews.com/sports/diontae-johnsons-first-touchdown-since-2021-lifts-steelers-over-titans)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T03:54:18+00:00

Diontae Johnson&apos;s streak without a touchdown is over, and it couldn&apos;t have come at a better time as it lifted the Pittsburgh Steelers over the Tennessee Titans.

## Titans' Treylon Burks carted off field after hitting head on field, laying motionless
 - [https://www.foxnews.com/sports/titans-treylon-burks-carted-off-field-hitting-head-laying-motionless](https://www.foxnews.com/sports/titans-treylon-burks-carted-off-field-hitting-head-laying-motionless)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T03:42:01+00:00

Tennessee Titans second-year wide receiver Treylon Burks was carted off after he lay motionless when he hit his head on the ground trying to make a catch.

## Cornell University cancels classes Friday amid 'extraordinary stress,' following antisemitic threats
 - [https://www.foxnews.com/us/cornell-university-cancels-classes-friday-amid-extraordinary-stress-following-antisemitic-threats](https://www.foxnews.com/us/cornell-university-cancels-classes-friday-amid-extraordinary-stress-following-antisemitic-threats)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T03:35:45+00:00

Cornell University canceled classes on Friday after Patrick Dai was charged with making online antisemitic threats against Jewish people on campus.

## GREG GUTFELD: Elon Musk unleashes on old-Twitter as 'information technology weapon' propagating a 'mind virus'
 - [https://www.foxnews.com/opinion/greg-gutfeld-elon-musk-old-twitter-information-technology-weapon-propagating-mind-virus](https://www.foxnews.com/opinion/greg-gutfeld-elon-musk-old-twitter-information-technology-weapon-propagating-mind-virus)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T03:35:14+00:00

FOX News host Greg Gutfeld reacts to Elon Musk sharing why he bought X, formerly known as Twitter, and criticizing George Soros on &quot;Joe Rogan Experience&quot; podcast on &quot;Gutfeld!&quot;

## Robert De Niro's girlfriend blasts former assistant as 'mean-spirited' and a 'hot mess' during testimony
 - [https://www.foxnews.com/entertainment/robert-de-niros-girlfriend-blasts-former-assistant-mean-spirited-hot-mess-during-trial](https://www.foxnews.com/entertainment/robert-de-niros-girlfriend-blasts-former-assistant-mean-spirited-hot-mess-during-trial)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T03:30:55+00:00

Robert De Niro&apos;s girlfriend Tiffany Chen slammed his former assistant Graham Chase Robinson while testifying in court during the actor&apos;s civil trial on Thursday.

## Illegal immigrant convicted of murder in Venezuela found living in state-funded housing in Massachusetts
 - [https://www.foxnews.com/us/illegal-immigrant-convicted-murder-venezuela-found-living-state-funded-housing-massachusetts](https://www.foxnews.com/us/illegal-immigrant-convicted-murder-venezuela-found-living-state-funded-housing-massachusetts)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T02:27:02+00:00

A migrant convicted of murder in Venezuela was arrested by ICE agents while living in a state-funded migrant shelter housing facility on Cape Cod, Massachusetts.

## Matthew Perry was 'extremely positive, sober' when friend met him day before death, she says
 - [https://www.foxnews.com/entertainment/matthew-perry-extremely-positive-sober-when-she-met-him-day-before-death-friend-says](https://www.foxnews.com/entertainment/matthew-perry-extremely-positive-sober-when-she-met-him-day-before-death-friend-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T02:13:32+00:00

Matthew Perry&apos;s friend, Athenna Crosby, met with the actor the day before he died and said he was &quot;extremely positive&quot; and &quot;acting normal&quot; during lunch.

## Florida child calls 911 to 'hug a deputy': Officials
 - [https://www.foxnews.com/lifestyle/florida-child-calls-hug-deputy-officials](https://www.foxnews.com/lifestyle/florida-child-calls-hug-deputy-officials)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T02:04:58+00:00

A Florida child called 911 because he wanted to hug a deputy on Tuesday, according to video released by the Hillsborough County Sheriff’s Office.

## ICE arrests African illegal immigrant, wanted in Senegal for terrorist offenses, who was released into US
 - [https://www.foxnews.com/politics/ice-arrests-african-illegal-immigrant-wanted-senegal-terrorist-offenses-was-released-us](https://www.foxnews.com/politics/ice-arrests-african-illegal-immigrant-wanted-senegal-terrorist-offenses-was-released-us)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T01:56:54+00:00

Immigration and Customs Enforcement (ICE) says it arrested an illegal immigrant wanted on charges for terrorist offences in Senegal, weeks after he was released into the U.S.

## Priscilla Presley cries as she recalls death of daughter Lisa Marie Presley: 'It was unbearable'
 - [https://www.foxnews.com/entertainment/priscilla-presley-cries-recalls-death-daughter-lisa-marie-presley](https://www.foxnews.com/entertainment/priscilla-presley-cries-recalls-death-daughter-lisa-marie-presley)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T01:52:41+00:00

Priscilla Presley reflected on the &quot;unbearable&quot; loss of her daughter Lisa Marie Presley in a new interview. She also addressed settling her late daughter&apos;s estate.

## Steelers' Cole Holcomb suffers gruesome leg injury that broadcast won't show on replay
 - [https://www.foxnews.com/sports/steelers-cole-holcomb-suffers-gruesome-leg-injury-broadcast-wont-show-on-replay](https://www.foxnews.com/sports/steelers-cole-holcomb-suffers-gruesome-leg-injury-broadcast-wont-show-on-replay)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T01:47:40+00:00

Pittsburgh Steelers linebacker Cole Holcomb suffered a gruesome leg injury as he tried to make a tackle during the team&apos;s game against the Tennessee Titans on Thursday night.

## Pro-Palestinian protesters light Israel flag on fire in New York City, trample flyers for missing Israelis
 - [https://www.foxnews.com/us/pro-palestinian-protesters-light-israel-flag-fire-new-york-city-trample-flyers-hamas-terror-victims](https://www.foxnews.com/us/pro-palestinian-protesters-light-israel-flag-fire-new-york-city-trample-flyers-hamas-terror-victims)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T01:23:49+00:00

Pro-Palestinian protesters lit an Israeli flag on fire as they clashed with pro-Israel protesters defending missing person posters for victims of the Hamas terror attacks.

## Trump appeals reinstated gag order in DC federal election case
 - [https://www.foxnews.com/politics/trump-appeals-gag-order-dc-federal-election-case](https://www.foxnews.com/politics/trump-appeals-gag-order-dc-federal-election-case)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T01:16:16+00:00

Former President Donald Trump&apos;s legal team has filed a motion to appeal the partial gag order imposed by a federal judge in his D.C. election interference case.

## Major law firms warn universities they won't hire students engaging in antisemitism
 - [https://www.foxnews.com/media/major-law-firms-warn-universities-wont-hire-students-engaging-antisemitism](https://www.foxnews.com/media/major-law-firms-warn-universities-wont-hire-students-engaging-antisemitism)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T01:02:45+00:00

Over 20 white shoe law firms signed a letter demanding that major universities like Harvard crack down on rising antisemitism incidents taking place on campuses.

## Russian tennis star Daniil Medvedev appears to make vulgar gesture during meltdown at Paris Masters
 - [https://www.foxnews.com/sports/russian-tennis-player-daniil-medvedev-appears-to-make-vulgar-gesture-during-meltdown-at-paris-masters](https://www.foxnews.com/sports/russian-tennis-player-daniil-medvedev-appears-to-make-vulgar-gesture-during-meltdown-at-paris-masters)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T00:38:55+00:00

The world&apos;s No. 3-ranked player, Daniil Medvedev, was upset at the Paris Masters. Grigor Dimitrov of Bulgaria defeated Medvedev in three sets Wednesday.

## Florida college student arrested in banana costume after allegedly urinating on sidewalk
 - [https://www.foxnews.com/us/florida-college-student-arrested-banana-costume-allegedly-urinating-sidewalk](https://www.foxnews.com/us/florida-college-student-arrested-banana-costume-allegedly-urinating-sidewalk)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T00:33:45+00:00

University of Miami student Kyle Mortimer was wearing a banana costume when police allegedly caught him urinating on a sidewalk across the street from a portable bathroom.

## New Jersey High School girls 'humiliated' after classmates use AI to generate fake nude images: report
 - [https://www.foxnews.com/media/new-jersey-high-school-girls-humiliated-classmates-use-ai-generate-fake-nude-images-report](https://www.foxnews.com/media/new-jersey-high-school-girls-humiliated-classmates-use-ai-generate-fake-nude-images-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-11-03T00:00:45+00:00

Female students at a New Jersey High School were humiliated after fake nude images of themselves were reportedly generated and shared by male classmates.

