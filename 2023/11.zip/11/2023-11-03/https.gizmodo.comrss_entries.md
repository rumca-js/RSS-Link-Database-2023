# Source:Gizmodo, URL:https://gizmodo.com/rss, language:en-US

## SBF Is Headed to Prison But FTX Will Haunt the Crypto Community For Years
 - [https://gizmodo.com/ftx-fbi-sam-bankman-fried-cryptocurrency-data-1850990825](https://gizmodo.com/ftx-fbi-sam-bankman-fried-cryptocurrency-data-1850990825)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-11-03T23:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/0778d137fba854b340de85d35e8b31a6.jpg" /><p>Sam Bankman-Fried <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/sam-bankman-fried-ftx-found-guilty-crypto-trial-1850986588">may be headed to prison</a> but the story of FTX  is far from over. Indeed, like an evil spirit, the exchange seems destined to haunt the crypto community  for the rest of its  days.</p><p><a href="https://gizmodo.com/ftx-fbi-sam-bankman-fried-cryptocurrency-data-1850990825">Read more...</a></p>

## Peter Jackson’s Video for The Beatles’ AI Song Has Some Jump Scares
 - [https://gizmodo.com/peter-jackson-beatles-ai-video-now-and-then-review-1850990474](https://gizmodo.com/peter-jackson-beatles-ai-video-now-and-then-review-1850990474)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-11-03T18:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/309fb4b6a09e3594cb18eedc9fc13922.png" /><p>You have an opportunity. If you turn back now, you can live out the rest of your days without absorbing the cosmic horror that is the music video for “Now and Then,” or as Paul McCartney’s marketing team puts it, “the last Beatles song.”</p><p><a href="https://gizmodo.com/peter-jackson-beatles-ai-video-now-and-then-review-1850990474">Read more...</a></p>

## Legacy Ad-Free Max Subscribers Will Soon Lose Access to 4K Streams
 - [https://gizmodo.com/legacy-ad-free-max-subscribers-losing-4k-access-dec-5-1850990006](https://gizmodo.com/legacy-ad-free-max-subscribers-losing-4k-access-dec-5-1850990006)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-11-03T16:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/590728b3f7d33a5c669c1aa4d1203afb.jpg" /><p><a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/warner-bros-max-streaming-earnings-losing-subscribers-1850703372">Max customers</a> who currently pay $15.99 a month for the “legacy ad-free” plan might have noticed an email this week with an ominous subject line: “Upcoming changes to your Max subscription plan.” For once, the missive wasn’t about <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/how-much-have-streaming-prices-increased-1850661604">an outright price increase</a>—but <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/our-flag-means-death-s2-max-what-to-watch-streaming-1850968302">subscribers</a> <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/netflix-price-increase-announced-9-million-new-customer-1

