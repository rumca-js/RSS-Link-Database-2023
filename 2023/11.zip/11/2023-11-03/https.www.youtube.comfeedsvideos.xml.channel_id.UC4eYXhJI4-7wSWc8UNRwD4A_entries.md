# Source:NPR Music, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A, language:en-US

## Conrad Tao And Caleb Teicher: Tiny Desk Concert
 - [https://www.youtube.com/watch?v=61q6JoGLTc0](https://www.youtube.com/watch?v=61q6JoGLTc0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A
 - date published: 2023-11-03T09:00:04+00:00

Tom Huizenga | November 3, 2023
A tap dancer and a pianist perform Bach and Gershwin behind a desk in our office: What could possibly go wrong? You can't tell by these truly electrifying performances, but an hour before this Tiny Desk began, I was chasing a tow truck to a salvage yard. The person slated to deliver our tap floor was snagged in a multi-car pileup that, thankfully, left nobody injured. I rented a U-Haul, grabbed the floor from the totaled vehicle and floored it back to NPR.

The behind-the-scenes headaches were worth it when we stood in awe of these two artists — pianist Conrad Tao and dancer-choreographer Caleb Teicher — as they created an experience so unexpectedly fresh and suffused with joy, it moved some to tears and others to cheer for more.

Bach and tap dancing might, on the surface, have nothing in common. But here, with ecstatic energy, the artists literally bring out the spirit of dance inherent in Bach's music, as Teicher's artful clicks and clacks weave int

