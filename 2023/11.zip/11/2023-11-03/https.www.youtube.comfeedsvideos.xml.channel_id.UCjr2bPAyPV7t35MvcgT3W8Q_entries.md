# Source:The Hated One, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q, language:en-US

## The Blackrock Conspiracy Debunked
 - [https://www.youtube.com/watch?v=STYgeA9VScc](https://www.youtube.com/watch?v=STYgeA9VScc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCjr2bPAyPV7t35MvcgT3W8Q
 - date published: 2023-11-03T16:19:32+00:00

BlackRock allegedly owns and controls the world. But the investment giant claims they are just impartial shareholders. What is really going on?
Support independent research and analysis by joining my Patreon page: https://www.patreon.com/thehatedone 

According to popular theories on social media BlackRock owns almost all of the biggest corporations around the world. They own the big tech, big pharma, big everything AND the mainstream media. This insinuates their hidden influence and secret agenda they supposedly enforce on the corporate world.

BlackRock is is indeed among the largest shareholders in the biggest corporations across all sectors of the economy. This isn't hidden information. Anyone can pull this up from publicly available sources. But the catch is that BlackRock doesn't legally own anything. The $10,000,000,000 in assets they have are under management on behalf of their clients. 

The issue of BlackRock's power and influence has been well studied and analyzed by econo

