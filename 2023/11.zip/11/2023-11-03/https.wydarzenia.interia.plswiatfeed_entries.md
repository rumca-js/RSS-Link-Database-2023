# Source:Wydarzenia Interia - Świat, URL:https://wydarzenia.interia.pl/swiat/feed, language:pl-PL

## Papież Franciszek rozmawiał z prezydentem Palestyny
 - [https://wydarzenia.interia.pl/raport-wojna-w-izraelu/news-papiez-franciszek-rozmawial-z-prezydentem-palestyny,nId,7126724](https://wydarzenia.interia.pl/raport-wojna-w-izraelu/news-papiez-franciszek-rozmawial-z-prezydentem-palestyny,nId,7126724)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-11-03T13:17:56+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wojna-w-izraelu/news-papiez-franciszek-rozmawial-z-prezydentem-palestyny,nId,7126724"><img align="left" alt="Papież Franciszek rozmawiał z prezydentem Palestyny" src="https://i.iplsc.com/papiez-franciszek-rozmawial-z-prezydentem-palestyny/000HXM4HRTTMRXHI-C321.jpg" /></a>Papież Franciszek rozmawiał w czwartek przez telefon z przewodniczącym władz Autonomii Palestyńskiej Mahmudem Abbasem. Informacje na ten temat przekazała palestyńska agencja informacyjna Wafa, dopiero potem Watykan potwierdził te doniesienia włoskiej agencji prasowej ANSA. </p><br clear="all" />

