# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Leicester City 0-1 Leeds United: Foxes' winning run ended by impressive Leeds
 - [https://www.bbc.co.uk/sport/football/67235729?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67235729?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T22:47:28+00:00

Leeds United end Leicester City's nine-game winning run in the Championship with an impressive victory at the King Power Stadium.

## Man Utd: Marcus Rashford birthday party 'unacceptable' to Erik ten Hag after derby defeat
 - [https://www.bbc.co.uk/sport/football/67314370?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67314370?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T22:43:22+00:00

Marcus Rashford's birthday celebrations after Manchester United's 3-0 derby defeat were "unacceptable" and the forward has apologised, says Erik ten Hag.

## Pep Guardiola: Man City boss denies Roy Keane claim player talks are 'for show'
 - [https://www.bbc.co.uk/sport/football/67314729?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67314729?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T22:32:26+00:00

Manchester City boss Pep Guardiola dismisses Roy Keane's claim that his on-pitch conversations with players is "all for show".

## Sale 24-10 Gloucester: Sharks go top of Premiership with bonus-point home win
 - [https://www.bbc.co.uk/sport/rugby-union/67276533?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/67276533?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T22:30:34+00:00

Sale Sharks go top of the Premiership by beating Gloucester as England fly-half George Ford and captain Ben Curry return for the hosts.

## Emma Hayes: Chelsea boss 'proud' of Fran Kirby for speaking out on body image
 - [https://www.bbc.co.uk/sport/football/67315753?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67315753?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T22:30:09+00:00

Chelsea boss Emma Hayes says she is "proud" of midfielder Fran Kirby for speaking out on body image issues in women's football.

## Paris Masters: Six-time champion Novak Djokovic beats Holger Rune to reach semi-finals
 - [https://www.bbc.co.uk/sport/tennis/67317262?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/67317262?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T22:29:56+00:00

Novak Djokovic continues his bid for a record-extending seventh Paris Masters title by beating Holger Rune to reach the semi-finals.

## Hezbollah steps back from all-out war on Israel over Gaza - for now
 - [https://www.bbc.co.uk/news/world-middle-east-67317454?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-67317454?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T22:29:01+00:00

The group's leader denied prior knowledge of Hamas's attacks in Israel and left out the possibility of joining the war.

## FA Cup: Sheppey United 1-4 Walsall: Sheppey United take the lead with 'magical' goal
 - [https://www.bbc.co.uk/sport/av/football/67300956?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/67300956?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T21:55:32+00:00

James Bessey-Saldanha scores in "magical moment" to give Sheppey United 1-0 lead over Walsall.

## Pentagon acknowledges flying unarmed drones over Gaza
 - [https://www.bbc.co.uk/news/world-us-canada-67317218?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-67317218?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T21:48:46+00:00

The US military said the drones, first spotted by journalists, were searching for hostages.

## Hamas officials say 13 killed in blast outside Gaza City's Al-Shifa hospital
 - [https://www.bbc.co.uk/news/world-middle-east-67316463?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-67316463?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T21:42:18+00:00

Israel said it hit an ambulance it said was carrying Hamas operatives without specifying where.

## Unlikely first Covid lockdown could have been avoided - Johnson
 - [https://www.bbc.co.uk/news/uk-politics-67315910?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-67315910?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T20:29:28+00:00

The former PM says only a vaccine or drugs - unavailable at the time - could have averted the curbs.

## Moment cars swept away by floodwaters as Storm Ciarán hits Italy
 - [https://www.bbc.co.uk/news/world-europe-67317146?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-67317146?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T20:13:58+00:00

Storm Ciarán brought the heaviest rain to hit Tuscany in 50 years, with more forecast for the weekend.

## Sao Paulo Grand Prix: Max Verstappen takes pole position for Sunday's race
 - [https://www.bbc.co.uk/sport/formula1/67315804?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/formula1/67315804?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T19:28:32+00:00

Red Bull’s Max Verstappen beat Ferrari’s Charles Leclerc to pole position in a rain-affected qualifying session at the Sao Paulo Grand Prix.

## Taylor Swift’s 1989 re-recording scores record-breaking UK chart debut
 - [https://www.bbc.co.uk/news/entertainment-arts-67311637?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-67311637?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T18:21:47+00:00

A re-recorded version of Swift’s 2014 pop opus more than doubles the first-week sales of the original.

## Luton airport fire car park to be 'fully demolished'
 - [https://www.bbc.co.uk/news/uk-england-beds-bucks-herts-67313813?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-beds-bucks-herts-67313813?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T18:13:36+00:00

The airport says cars parked inside the burnt-out multi-storey "are not recoverable".

## Gaza reporter removes protective vest after learning of colleague's death
 - [https://www.bbc.co.uk/news/world-middle-east-67314396?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-67314396?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T18:08:24+00:00

A journalist working for Palestine TV was killed in a strike on Gaza, his network said.

## Matthew Perry Foundation set up in late Friends star's name to help addicts
 - [https://www.bbc.co.uk/news/entertainment-arts-67314978?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-67314978?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T17:55:41+00:00

A fund "driven by his passion for making a difference" is set up in the late Friends star's name.

## Four things we learned from Trump sons’ fraud trial testimony
 - [https://www.bbc.co.uk/news/world-us-canada-67314646?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-67314646?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T17:38:55+00:00

Eric and Donald Trump Jr tried to shift blame, while their lawyers feuded with the New York judge.

## Anwar el Ghazi: Dutch winger's Mainz contract terminated over Israel-Gaza post
 - [https://www.bbc.co.uk/sport/football/67312754?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67312754?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T17:37:54+00:00

Former Aston Villa and Everton winger Anwar el Ghazi has his contract terminated at Mainz for a social media post about the Israel-Gaza conflict.

## Conservative MP Bob Stewart guilty of racially abusing activist
 - [https://www.bbc.co.uk/news/uk-england-london-67310954?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-67310954?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T17:18:46+00:00

Conservative MP Bob Stewart has been found guilty of a racially aggravated public order offence.

## Jung Kook's Golden: BTS star crowned 'pop king' by critics thanks to solo album
 - [https://www.bbc.co.uk/news/entertainment-arts-67307109?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-67307109?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T17:08:09+00:00

Critics say the star's solo debut is "pop bliss" and he has "punched his ticket to pop superstardom".

## Planned protest on Armistice Day would be 'disrespectful', says Sunak
 - [https://www.bbc.co.uk/news/uk-england-london-67305535?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-67305535?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T16:50:56+00:00

Rishi Sunak says there is a risk war memorials such as the Cenotaph in London could be "desecrated".

## Scampton asylum plan could cost £260m over 3 years
 - [https://www.bbc.co.uk/news/uk-politics-67313584?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-67313584?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T16:09:59+00:00

A Home Office memo concluded housing asylum seekers on RAF Scampton represented "marginal" value for money.

## Israel rebuffs Blinken's call for Gaza humanitarian pause
 - [https://www.bbc.co.uk/news/world-middle-east-67310632?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-67310632?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T15:49:50+00:00

PM Benjamin Netanyahu says there will be no temporary truce without the release of hostages.

## Sao Paulo Grand Prix: Carlos Sainz fastest in first practice ahead of Charles Leclerc
 - [https://www.bbc.co.uk/sport/formula1/67312962?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/formula1/67312962?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T15:40:07+00:00

Carlos Sainz led a Ferrari one-two ahead of Mercedes' George Russell in practice at the Sao Paulo Grand Prix.

## Sandro Tonali: Newcastle United do not know if AC Milan knew about gambling charges
 - [https://www.bbc.co.uk/sport/football/67313204?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67313204?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T15:37:08+00:00

Newcastle do not know if AC Milan were aware of the gambling charges facing Sandro Tonali when they sold him to the Magpies, says Dan Ashworth.

## Jack Russell in Suffolk has become foster mum to abandoned kittens
 - [https://www.bbc.co.uk/news/uk-england-suffolk-67310766?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-suffolk-67310766?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T15:33:01+00:00

A Jack Russell in Suffolk has taken on six kittens, cleaning and feeding them her own milk.

## Cheshire Police employee who tipped off criminal friend is jailed
 - [https://www.bbc.co.uk/news/uk-england-merseyside-67310315?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-merseyside-67310315?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T15:28:40+00:00

Natalie Mottram told a criminal friend how police had infiltrated the EncroChat messaging platform.

## Cricket World Cup 2023: Afghanistan thrash Netherlands by seven wickets
 - [https://www.bbc.co.uk/sport/av/cricket/67313740?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/67313740?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T15:28:21+00:00

Watch highlights as Afghanistan thrash Netherlands by seven wickets to boost their semi-final World Cup hopes.

## What is Hezbollah in Lebanon and will it go to war with Israel?
 - [https://www.bbc.co.uk/news/world-middle-east-67307858?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-67307858?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T15:20:16+00:00

Hassan Nasrallah, the leader of Hezbollah, has praised the Hamas attacks on Israel.

## Cricket World Cup 2023: Afghanistan beat the Netherlands to boost semi-final hopes
 - [https://www.bbc.co.uk/sport/cricket/67307224?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/67307224?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T15:02:41+00:00

Afghanistan continue their late surge for a place in the World Cup semi-finals with a seven-wicket win over the Netherlands in Lucknow.

## Storm Ciarán: At the scene where a 'tornado' struck Jersey
 - [https://www.bbc.co.uk/news/uk-67312512?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-67312512?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T14:22:40+00:00

The BBC's Dan Johnson surveys the damage after Storm Ciarán struck St Clement.

## Adam Johnson: Inquest opens into death of ice hockey player
 - [https://www.bbc.co.uk/news/uk-england-nottinghamshire-67306896?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-nottinghamshire-67306896?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T13:46:54+00:00

Adam Johnson's partner Ryan Wolfe identified the 29-year-old after he died, an inquest heard.

## Megan Thee Stallion raps about mental health in new song Cobra
 - [https://www.bbc.co.uk/news/entertainment-arts-67308120?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-67308120?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T13:46:38+00:00

The Savage rapper releases her first solo song since Tory Lanez was jailed for shooting her.

## Somerset gardener banned from 'wriggling' in gimp suit
 - [https://www.bbc.co.uk/news/uk-england-somerset-67310389?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-somerset-67310389?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T13:35:13+00:00

A gardener is now banned from wearing a black bodysuit or face covering in public until 2028.

## Man denies alleged plot to kidnap Holly Willoughby
 - [https://www.bbc.co.uk/news/uk-england-essex-67310644?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-essex-67310644?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T12:48:31+00:00

Gavin Plumb is accused of soliciting to murder and incitement to kidnap the TV presenter.

## Everyone got duped by Sam Bankman-Fried's big gamble
 - [https://www.bbc.co.uk/news/world-us-canada-67302950?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-67302950?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T12:45:22+00:00

The dishevelled former wunderkind fooled Silicon Valley and stole billions from customers, a court found.

## Bowen: Five new realities after four weeks of Israel-Gaza war
 - [https://www.bbc.co.uk/news/world-middle-east-67306902?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-67306902?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T12:44:41+00:00

The BBC’s international editor says there are few known quantities after nearly a month of fighting.

## Lisa Marie Presley complained to Sofia Coppola over Priscilla film script
 - [https://www.bbc.co.uk/news/entertainment-arts-67307792?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-67307792?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T12:09:48+00:00

Lisa Marie Presley complained that a new film would make Elvis out as "a predator and manipulative".

## AI risks are unknown even to GCHQ, Anne Keast-Butler tells BBC
 - [https://www.bbc.co.uk/news/uk-67301402?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-67301402?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T11:58:09+00:00

In a first interview since becoming GCHQ's director, Anne Keast-Butler shares her AI concerns.

## Humza Yousaf's family cross Gaza border to safety
 - [https://www.bbc.co.uk/news/uk-scotland-67307843?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-67307843?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T11:54:18+00:00

The first minister's parents-in-law left through the Rafah gate into Egypt, it has been confirmed.

## Sir Bobby Charlton's 1966 semi-final shirt up for auction
 - [https://www.bbc.co.uk/news/uk-england-derbyshire-67308456?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-derbyshire-67308456?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T11:00:30+00:00

The shirt he wore during England's win over Portugal is expected to fetch tens of thousands of pounds.

## Cricket World Cup 2023: Superb Afghanistan fielding takes three Netherlands wickets
 - [https://www.bbc.co.uk/sport/av/cricket/67308164?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/67308164?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T10:57:28+00:00

Watch as some superb fielding from Afghanistan leads to three Netherlands wickets in their World Cup match in Lucknow, India.

## Zara Aleena killer has minimum term reduced
 - [https://www.bbc.co.uk/news/uk-england-london-67307052?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-67307052?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T10:40:56+00:00

Jordan McSweeney wins a challenge at the Court of Appeal over the length of his 38-year sentence.

## Steven Tyler: Woman accuses Aerosmith singer of sexual assault
 - [https://www.bbc.co.uk/news/entertainment-arts-67307102?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-67307102?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T10:26:02+00:00

In a case filed at New York's Supreme Court, the woman says she suffered "severe emotional distress".

## Luis Diaz: Jurgen Klopp says he will allow forward to decide availability after father's kidnapping
 - [https://www.bbc.co.uk/sport/football/67307751?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67307751?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T10:25:31+00:00

Liverpool manager Jurgen Klopp says he will allow Luis Diaz to decide whether he is available this weekend following the kidnapping of his father in Colombia.

## Pablo Escobar's feral hippos face cull in Colombia
 - [https://www.bbc.co.uk/news/67306304?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/67306304?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T10:05:45+00:00

Authorities says they must act to stop a dangerous population explosion among the invasive species.

## Cricket World Cup 2023: A rocket throw from fine leg dismisses O'Dowd for 42
 - [https://www.bbc.co.uk/sport/av/cricket/67308160?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/67308160?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T09:57:35+00:00

Watch as a rocket throw from fine leg dismisses Max O'Dowd for 42 in their World Cup match against Afghanistan.

## King-size creation on display at NEC Cake International
 - [https://www.bbc.co.uk/news/uk-england-birmingham-67301315?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-birmingham-67301315?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T09:17:34+00:00

The snackable sovereign is made from marshmallows and chocolate.

## WTA Finals: WTA accepts responsibility for 'challenging' conditions in Cancun
 - [https://www.bbc.co.uk/sport/tennis/67306970?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/67306970?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T08:57:26+00:00

The Women's Tennis Association says it accepts responsibility for the "challenging conditions" its players are facing at the WTA Finals in Cancun, Mexico.

## Cricket World Cup 2023: England's Ben Stokes to have knee surgery after World Cup
 - [https://www.bbc.co.uk/sport/cricket/67299685?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/67299685?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T08:34:19+00:00

England Test captain Ben Stokes says he will undergo surgery to address his ongoing knee issue after the World Cup.

## Nearly 100 British nationals listed as eligible to leave Gaza via Egypt
 - [https://www.bbc.co.uk/news/uk-67306453?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-67306453?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T08:34:13+00:00

Palestinian authorities list 127 names on the UK section of foreigners who are eligible to leave via Egypt.

## WXV1: Australia 25-19 Wales - wasteful Wales unable to beat 14-player Wallaroos
 - [https://www.bbc.co.uk/sport/rugby-union/67282893?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/67282893?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T08:21:21+00:00

Wasteful Wales end their WXV campaign winless after failing to beat 14-player Australia in Auckland.

## Storm Ciarán: Floods ravage Tuscany leaving three dead
 - [https://www.bbc.co.uk/news/world-europe-67306519?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-67306519?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T08:15:15+00:00

Three people are confirmed dead and six more are missing as heavy winds and rain buffet central Italy.

## Dozens killed in fire at Iranian drug rehab centre
 - [https://www.bbc.co.uk/news/world-middle-east-67306299?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-67306299?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T08:04:10+00:00

At least 32 have died in a blaze that tore through a building in Langarud, north of Tehran.

## FA Cup: Gareth Southgate's best man Andy Woodman targets upset with non-league Bromley
 - [https://www.bbc.co.uk/sport/football/67187939?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67187939?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T07:03:33+00:00

Bromley boss Andy Woodman, who is best friends with England manager Gareth Southgate, is targeting an FA Cup upset when his non-league side host Blackpool.

## Cricket World Cup 2023: England's dismal World Cup is Rob Key's biggest challenge
 - [https://www.bbc.co.uk/sport/cricket/67245159?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/67245159?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T06:37:01+00:00

No one saw England's dismal World Cup coming - now the rebuild of the one-day team is Rob Key's biggest challenge to date, says Stephan Shemilt.

## Thieves cut through museum floor to steal 'priceless' silver antiques
 - [https://www.bbc.co.uk/news/uk-england-nottinghamshire-67303974?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-nottinghamshire-67303974?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T06:35:19+00:00

Detectives say the theft of historical military items was "audacious" and well organised.

## Ilkeston: Woman crochets 6ft soldier to mark Remembrance Day
 - [https://www.bbc.co.uk/news/uk-england-derbyshire-67301240?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-derbyshire-67301240?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T06:27:31+00:00

Jilly Crofts started working on the project in May and it has taken about 200 hours to complete.

## Damien Bendall: Quadruple killer was master manipulator, mum says
 - [https://www.bbc.co.uk/news/uk-england-derbyshire-67300894?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-derbyshire-67300894?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T06:26:20+00:00

Terri Harris' mum says she feared for her daughter when she began a relationship with Damien Bendall.

## Pups put their best paw forward at school for guide dogs
 - [https://www.bbc.co.uk/news/uk-england-manchester-67299114?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-manchester-67299114?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T06:25:46+00:00

Meet the Greater Manchester pooches undergoing intensive training to fulfil their important role.

## Beth Mead: Inside Arsenal and England forward's 'gruelling' 11-month ACL recovery
 - [https://www.bbc.co.uk/sport/football/67296963?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67296963?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T06:18:21+00:00

After 11 months out Beth Mead is back, but it has been a difficult and emotional rehabilitation for the Arsenal and England forward.

## I’ve killed before, said Lawrence suspect in second attack
 - [https://www.bbc.co.uk/news/uk-67227760?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-67227760?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T06:03:03+00:00

Matthew White named his earlier victim as "Stephen" as he tried to stab a black man, the BBC can reveal.

## Germany: Illegal migration rise prompts border crackdown
 - [https://www.bbc.co.uk/news/world-europe-67238144?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-67238144?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T06:00:29+00:00

Soaring numbers of illegal migrants is sharpening a growing debate about migration in Germany.

## Call of Duty: Can the world's favourite shooter game last another 20 years?
 - [https://www.bbc.co.uk/news/newsbeat-67295984?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-67295984?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T04:52:17+00:00

The franchise marks two decades since it launched with a new owner and questions over its future.

## Storm Ciarán eases but flood warnings remain
 - [https://www.bbc.co.uk/news/uk-67305442?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-67305442?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T03:15:03+00:00

The storm brought high winds and torrential rainfall to large parts of the UK on Thursday.

## Boom in unusual jellyfish spotted in UK waters
 - [https://www.bbc.co.uk/news/science-environment-67301074?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-67301074?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T02:42:19+00:00

Climate change is warming the world's oceans, creating good conditions for jellyfish in the UK.

## No targeted mental health support for flood-hit farmers
 - [https://www.bbc.co.uk/news/science-environment-67300354?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-67300354?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T01:43:17+00:00

The government rejects calls to provide new funding for mental health support for farmers in crises.

## Hezbollah chief Nasrallah to break silence on Israel-Gaza war
 - [https://www.bbc.co.uk/news/world-middle-east-67304185?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-67304185?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T01:34:18+00:00

So far its response has been contained, but fears remain its involvement may widen the conflict.

## Suspected mushroom poisoning: Erin Patterson faces Australian court on murder charges
 - [https://www.bbc.co.uk/news/world-australia-67305278?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-australia-67305278?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T01:26:33+00:00

Erin Patterson has maintained she did not poison her former in-laws and others at a lunch in Australia.

## The Papers: 'AI will end work' and 'the wrath of Ciarán'
 - [https://www.bbc.co.uk/news/blogs-the-papers-67305002?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-67305002?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T01:08:28+00:00

A wide range of topics - from AI to the aftermath of Storm Ciarán - are covered by Friday's papers.

## Trump's sons a study in contrasts on witness stand in New York fraud case
 - [https://www.bbc.co.uk/news/world-us-canada-67304547?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-67304547?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T00:47:00+00:00

"Make me look sexy," Donald Trump Jr joked to a court sketch artist. Eric Trump became agitated on the witness stand.

## A doctor, tailor, and bride-to-be: Stories of those killed in Gaza
 - [https://www.bbc.co.uk/news/world-middle-east-67278549?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-67278549?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T00:31:06+00:00

From surgeons to young children, these are some of the people known to have been killed in Gaza.

## Quiz of the week: What did Heidi Klum dress as for her Halloween party?
 - [https://www.bbc.co.uk/news/world-67299262?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-67299262?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T00:23:03+00:00

How closely have you been paying attention to what's been going on over the past seven days?

## 'I thought he was my friend but he was a loan shark’
 - [https://www.bbc.co.uk/news/business-67254009?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-67254009?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T00:11:57+00:00

The body that prosecutes illegal lenders warns people are turning to loan sharks to pay food and energy bills.

## Children's health warning system rolled out by NHS
 - [https://www.bbc.co.uk/news/health-67301778?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-67301778?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T00:07:21+00:00

The concerns of families and carers will be at the heart of a new early-warning system, the NHS says.

## How rap is breaking Belfast barriers brick-by-brick, song-by-song
 - [https://www.bbc.co.uk/news/uk-northern-ireland-67303573?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-northern-ireland-67303573?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-11-03T00:00:46+00:00

Thirty young rappers from Northern Ireland are on a generational journey as they unite for a mixtape.

