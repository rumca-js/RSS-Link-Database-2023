# Source:Mental Outlaw, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7YOGHUfC1Tb6E4pudI9STA, language:en-US

## Twitter Wants to Become a New World Bank
 - [https://www.youtube.com/watch?v=odFWOhJzI84](https://www.youtube.com/watch?v=odFWOhJzI84)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7YOGHUfC1Tb6E4pudI9STA
 - date published: 2023-11-03T00:09:53+00:00

In this video I discuss X (formerly Twitters) plan to become a financial institution that handles as much as half of the global financial system and an everting app like WeChat and why I think that is unlikely to happen.

My merch is available at
https://based.win/

Subscribe to me on Odysee.com
https://odysee.com/@AlphaNerd:8

₿💰💵💲Help Support the Channel by Donating Crypto💲💵💰₿

Monero
45F2bNHVcRzXVBsvZ5giyvKGAgm6LFhMsjUUVPTEtdgJJ5SNyxzSNUmFSBR5qCCWLpjiUjYMkmZoX9b3cChNjvxR7kvh436

Bitcoin
3MMKHXPQrGHEsmdHaAGD59FWhKFGeUsAxV

Ethereum
0xeA4DA3F9BAb091Eb86921CA6E41712438f4E5079

Litecoin
MBfrxLJMuw26hbVi2MjCVDFkkExz8rYvUF

