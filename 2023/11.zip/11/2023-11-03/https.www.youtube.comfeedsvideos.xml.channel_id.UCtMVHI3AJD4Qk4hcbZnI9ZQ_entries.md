# Source:SomeOrdinaryGamers, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCtMVHI3AJD4Qk4hcbZnI9ZQ, language:en-US

## Scumbag of the Year "SBF" Got 110 Years In Prison...
 - [https://www.youtube.com/watch?v=8jo_he2XI7c](https://www.youtube.com/watch?v=8jo_he2XI7c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtMVHI3AJD4Qk4hcbZnI9ZQ
 - date published: 2023-11-03T16:35:14+00:00

Hello guys and gals, it's me Mutahar again! This time we take a look at how Sam Bankman-Fried also known as "SBF" has been found guilty on all charges and faces over 100 years in prison. SBF was once one of the wealthiest in the world and ran one of the largest crypto exchanges until it came out that he defrauded some of the most powerful people in the world. Thanks for watching!
Like, Comment and Subscribe for more videos!

Check out the newest podcast episode: https://youtu.be/on-VS0LVLus

