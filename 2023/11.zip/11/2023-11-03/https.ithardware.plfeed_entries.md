# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## Fortnite cieszy się ogromnym zainteresowaniem. To zasługa nowego, starego sezonu
 - [https://ithardware.pl/aktualnosci/fortnite_cieszy_sie_ogromnym_zainteresowaniem_to_zasluga_nowego_starego_sezonu-30062.html](https://ithardware.pl/aktualnosci/fortnite_cieszy_sie_ogromnym_zainteresowaniem_to_zasluga_nowego_starego_sezonu-30062.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-11-03T22:10:21+00:00

<img src="https://ithardware.pl/artykuly/min/30062_1.jpg" />            Fortnite, niegdyś bardzo popularny battle royale dziś o tamtych wynikach m&oacute;gł jedynie pomarzyć, chociaż też mimo wszystko nie może narzekać na brak zainteresowania. Tym bardziej że ruszył nowy sezon, kt&oacute;ry jest powrotem do...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/fortnite_cieszy_sie_ogromnym_zainteresowaniem_to_zasluga_nowego_starego_sezonu-30062.html">https://ithardware.pl/aktualnosci/fortnite_cieszy_sie_ogromnym_zainteresowaniem_to_zasluga_nowego_starego_sezonu-30062.html</a></p>

## Modern Warfare 3 ma bardzo krótką kampanię. Gracze są zawiedzeni
 - [https://ithardware.pl/aktualnosci/modern_warfare_3_ma_bardzo_krotka_kampanie_gracze_sa_zawiedzeni-30061.html](https://ithardware.pl/aktualnosci/modern_warfare_3_ma_bardzo_krotka_kampanie_gracze_sa_zawiedzeni-30061.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-11-03T20:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/30061_1.jpg" />            Call of Duty: Modern Warfare 3 zadebiutuje 10 listopada, tymczasem przed oficjalnym debiutem dostęp do kampanii fabularnej dostała część graczy. Niestety podtrzymana została tradycja kampanii fabularnych Call of Duty na jedno...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/modern_warfare_3_ma_bardzo_krotka_kampanie_gracze_sa_zawiedzeni-30061.html">https://ithardware.pl/aktualnosci/modern_warfare_3_ma_bardzo_krotka_kampanie_gracze_sa_zawiedzeni-30061.html</a></p>

## Microsoft pozbawia pracowników darmowego abonamentu Game Pass Ultimate
 - [https://ithardware.pl/aktualnosci/microsoft_pozbawia_pracownikow_darmowego_abonamentu_game_pass_ultimate-30060.html](https://ithardware.pl/aktualnosci/microsoft_pozbawia_pracownikow_darmowego_abonamentu_game_pass_ultimate-30060.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-11-03T17:24:47+00:00

<img src="https://ithardware.pl/artykuly/min/30060_1.jpg" />            Pracownikom Microsoftu jeszcze do niedawna przysługiwał darmowy abonament Xbox Game Pass Ultimate, aczkolwiek po podwyżce ceny przyszła pora na cięcia, w wyniku kt&oacute;rych przedstawiciele firmy z Redmond zostali pozbawieni tego...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/microsoft_pozbawia_pracownikow_darmowego_abonamentu_game_pass_ultimate-30060.html">https://ithardware.pl/aktualnosci/microsoft_pozbawia_pracownikow_darmowego_abonamentu_game_pass_ultimate-30060.html</a></p>

## Ubisoft zakończył wsparcie Far Cry 6. Czas na Far Cry 7?
 - [https://ithardware.pl/aktualnosci/ubisoft_zakonczyl_wsparcie_far_cry_6_czas_na_far_cry_7-30059.html](https://ithardware.pl/aktualnosci/ubisoft_zakonczyl_wsparcie_far_cry_6_czas_na_far_cry_7-30059.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-11-03T15:46:58+00:00

<img src="https://ithardware.pl/artykuly/min/30059_1.jpg" />            Ubisoft poinformował o zakończeniu wsparcia Far Cry 6, co oznacza, że gra nie dostanie już żadnej aktualizacji. Podobno studio chce skupić się na następnej części serii.

Far Cry 6 zadebiutował w 2021 roku i od tamtej pory kilka...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/ubisoft_zakonczyl_wsparcie_far_cry_6_czas_na_far_cry_7-30059.html">https://ithardware.pl/aktualnosci/ubisoft_zakonczyl_wsparcie_far_cry_6_czas_na_far_cry_7-30059.html</a></p>

## Ubisoft zakończył wspieranie Far Cry 6. Czas na Far Cry 7?
 - [https://ithardware.pl/aktualnosci/ubisoft_zakonczyl_wspieranie_far_cry_6_czas_na_far_cry_7-30059.html](https://ithardware.pl/aktualnosci/ubisoft_zakonczyl_wspieranie_far_cry_6_czas_na_far_cry_7-30059.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-11-03T15:46:58+00:00

<img src="https://ithardware.pl/artykuly/min/30059_1.jpg" />            Ubisoft poinformował o zakończeniu wsparcia Far Cry 6, co oznacza, że gra nie dostanie już żadnej aktualizacji. Podobno studio chce skupić się na następnych produkcjach z serii.

Far Cry 6 zadebiutował w 2021 roku i od tamtej pory otrzymał...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/ubisoft_zakonczyl_wspieranie_far_cry_6_czas_na_far_cry_7-30059.html">https://ithardware.pl/aktualnosci/ubisoft_zakonczyl_wspieranie_far_cry_6_czas_na_far_cry_7-30059.html</a></p>

## Recenzja pada Scuf Envision Pro. Konsolowcy w końcu będą zazdrościć PC?
 - [https://ithardware.pl/testyirecenzje/recenzja_pada_scuf_envision_pro_konsolowcy_w_koncu_beda_zazdroscic_pc-30045.html](https://ithardware.pl/testyirecenzje/recenzja_pada_scuf_envision_pro_konsolowcy_w_koncu_beda_zazdroscic_pc-30045.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-11-03T14:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/30045_1.jpg" />            

Gracze pecetowi, kt&oacute;rzy odkładają na bok mysz i klawiaturę, wybierając komfort grania na padzie, teoretycznie nie mają powod&oacute;w do narzekania. Teoretycznie, bo chociaż wyb&oacute;r tego typu urządzeń na rynku jest naprawdę...
            <p>Pełna wersja strony <a href="https://ithardware.pl/testyirecenzje/recenzja_pada_scuf_envision_pro_konsolowcy_w_koncu_beda_zazdroscic_pc-30045.html">https://ithardware.pl/testyirecenzje/recenzja_pada_scuf_envision_pro_konsolowcy_w_koncu_beda_zazdroscic_pc-30045.html</a></p>

## Mobilne procesory Intel Meteor Lake i Raptor Lake Refresh dostrzeżone w benchmarku. Zamieszanie z na
 - [https://ithardware.pl/aktualnosci/mobilne_procesory_intel_meteor_lake_i_raptor_lake_refresh_dostrzezone_w_benchmarku_zamieszanie_z_na-30056.html](https://ithardware.pl/aktualnosci/mobilne_procesory_intel_meteor_lake_i_raptor_lake_refresh_dostrzezone_w_benchmarku_zamieszanie_z_na-30056.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-11-03T13:41:01+00:00

<img src="https://ithardware.pl/artykuly/min/30056_1.jpg" />            Momomo_US odkrył w bazie danych BAPCo kilka procesor&oacute;w Intel Meteor Lake i Raptor Lake Refresh dla laptop&oacute;w.

Wspomniane procesory nie są tajemnicą, bo od czasu do czasu pojawiają się w przeciekach. Tym razem dostrzeżono je w bazie...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/mobilne_procesory_intel_meteor_lake_i_raptor_lake_refresh_dostrzezone_w_benchmarku_zamieszanie_z_na-30056.html">https://ithardware.pl/aktualnosci/mobilne_procesory_intel_meteor_lake_i_raptor_lake_refresh_dostrzezone_w_benchmarku_zamieszanie_z_na-30056.html</a></p>

## Przychody Apple wciąż spadają, pomimo rekordowej sprzedaży iPhone'ów
 - [https://ithardware.pl/aktualnosci/przychody_apple_wciaz_spadaja_pomimo_rekordowej_sprzedazy_iphone_ow-30054.html](https://ithardware.pl/aktualnosci/przychody_apple_wciaz_spadaja_pomimo_rekordowej_sprzedazy_iphone_ow-30054.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-11-03T12:19:01+00:00

<img src="https://ithardware.pl/artykuly/min/30054_1.jpg" />            Najnowszy kwartalny raport finansowy Apple przedstawia obraz bardzo dobrej kondycji oprogramowania firmy, a jednocześnie załamanie przychod&oacute;w z hardware'u.&nbsp;

W komunikacie ogłaszającym wyniki finansowe za czwarty kwartał...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/przychody_apple_wciaz_spadaja_pomimo_rekordowej_sprzedazy_iphone_ow-30054.html">https://ithardware.pl/aktualnosci/przychody_apple_wciaz_spadaja_pomimo_rekordowej_sprzedazy_iphone_ow-30054.html</a></p>

## Steam Deck - zmodowana konsola otrzymała SSD o pojemności 61 TB
 - [https://ithardware.pl/aktualnosci/steam_deck_zmodowana_konsola_otrzymala_ssd_o_pojemnosci_61_tb-30053.html](https://ithardware.pl/aktualnosci/steam_deck_zmodowana_konsola_otrzymala_ssd_o_pojemnosci_61_tb-30053.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-11-03T11:17:01+00:00

<img src="https://ithardware.pl/artykuly/min/30053_1.jpg" />            Społeczność moderska Steam Deck prezentuje niezwykle ciekawe (i kosztowne) pomysły na ulepszenie przenośnej konsoli do gier Valve. Najnowszy mod skupia się na rozwiązaniu jednego z największych problem&oacute;w konsoli: miejsca na nasze...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/steam_deck_zmodowana_konsola_otrzymala_ssd_o_pojemnosci_61_tb-30053.html">https://ithardware.pl/aktualnosci/steam_deck_zmodowana_konsola_otrzymala_ssd_o_pojemnosci_61_tb-30053.html</a></p>

## Call of Duty: Modern Warfare III zajmuje aż 234 GB przestrzeni dyskowej
 - [https://ithardware.pl/aktualnosci/call_of_duty_modern_warfare_iii_zajmuje_az_234_gb_przestrzeni_dyskowej-30055.html](https://ithardware.pl/aktualnosci/call_of_duty_modern_warfare_iii_zajmuje_az_234_gb_przestrzeni_dyskowej-30055.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-11-03T11:09:01+00:00

<img src="https://ithardware.pl/artykuly/min/30055_1.jpg" />            Call of Duty: Modern Warfare III wydaje się największym Call of Duty wszech czas&oacute;w i tym razem nie m&oacute;wimy o sprzedaży czy rozmachu gry, ale o jej rozmiarze, bo na PlayStation 5 zajmuje aż 234,9 GB pamięci. To niemal 30% pojemności...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/call_of_duty_modern_warfare_iii_zajmuje_az_234_gb_przestrzeni_dyskowej-30055.html">https://ithardware.pl/aktualnosci/call_of_duty_modern_warfare_iii_zajmuje_az_234_gb_przestrzeni_dyskowej-30055.html</a></p>

## Dell prezentuje pierwsze monitory z panelami IPS Black o odświeżaniu 120 Hz
 - [https://ithardware.pl/aktualnosci/dell_prezentuje_pierwsze_monitory_z_panelami_ips_black_o_odswiezaniu_120_hz-30052.html](https://ithardware.pl/aktualnosci/dell_prezentuje_pierwsze_monitory_z_panelami_ips_black_o_odswiezaniu_120_hz-30052.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-11-03T10:36:01+00:00

<img src="https://ithardware.pl/artykuly/min/30052_1.jpg" />            Dell ogłosiło wprowadzenie dw&oacute;ch nowych 27-calowych monitor&oacute;w z biznesowej rodziny UltraSharp. Modele UltraSharp U2724D i U2724DE mogą jednak zadowolić r&oacute;wnież graczy, bo to pierwsze monitory, jakie znamy, wyposażone w panele...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/dell_prezentuje_pierwsze_monitory_z_panelami_ips_black_o_odswiezaniu_120_hz-30052.html">https://ithardware.pl/aktualnosci/dell_prezentuje_pierwsze_monitory_z_panelami_ips_black_o_odswiezaniu_120_hz-30052.html</a></p>

## Mocna wyprzedaż w Geekbuying. Mnóstwo sprzętu w promocyjnych cenach!
 - [https://ithardware.pl/aktualnosci/mocna_wyprzedaz_w_geekbuying_mnostwo_sprzetu_w_promocyjnych_cenach-30058.html](https://ithardware.pl/aktualnosci/mocna_wyprzedaz_w_geekbuying_mnostwo_sprzetu_w_promocyjnych_cenach-30058.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-11-03T10:20:20+00:00

<img src="https://ithardware.pl/artykuly/min/30058_1.jpg" />            W serwisie Geekbuying znajdziecie aktualnie trwającą promocję na sprzęt, przede wszystkim elektroniczny. Wyprzedaż 11.11 to tylko oczywiście nazwa, ponieważ sama promocja potrwa do 13.11 bieżącego roku. Co można kupić?

W Geekbuying...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/mocna_wyprzedaz_w_geekbuying_mnostwo_sprzetu_w_promocyjnych_cenach-30058.html">https://ithardware.pl/aktualnosci/mocna_wyprzedaz_w_geekbuying_mnostwo_sprzetu_w_promocyjnych_cenach-30058.html</a></p>

## AMD wypuszcza Ryzeny z rdzeniami Zen 4c - Ryzen 5 7545U i Ryzen 3 7440U
 - [https://ithardware.pl/aktualnosci/amd_wypuszcza_ryzeny_z_rdzeniami_zen_4c_ryzen_5_7545u_i_ryzen_3_7440u-30051.html](https://ithardware.pl/aktualnosci/amd_wypuszcza_ryzeny_z_rdzeniami_zen_4c_ryzen_5_7545u_i_ryzen_3_7440u-30051.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-11-03T09:29:01+00:00

<img src="https://ithardware.pl/artykuly/min/30051_1.jpg" />            AMD wreszcie wprowadziło na rynek zupełnie nowe układy APU Ryzen 7040 oparte na rdzeniach Zen 4c. Mowa tu o procesorach Ryzen 5 7545U i Ryzen 3 7440U, kt&oacute;re przeznaczone są do cienkich i lekkich laptop&oacute;w.&nbsp;

Nie jest tajemnicą,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/amd_wypuszcza_ryzeny_z_rdzeniami_zen_4c_ryzen_5_7545u_i_ryzen_3_7440u-30051.html">https://ithardware.pl/aktualnosci/amd_wypuszcza_ryzeny_z_rdzeniami_zen_4c_ryzen_5_7545u_i_ryzen_3_7440u-30051.html</a></p>

## Filmowcy pozywają Polskę na miliony. Domagają się opłat od każdego sprzedanego smartfona czy laptopa
 - [https://ithardware.pl/aktualnosci/filmowcy_pozywaja_polske_na_miliony_domagaja_sie_oplat_od_kazdego_sprzedanego_smartfona_czy_laptopa-30057.html](https://ithardware.pl/aktualnosci/filmowcy_pozywaja_polske_na_miliony_domagaja_sie_oplat_od_kazdego_sprzedanego_smartfona_czy_laptopa-30057.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-11-03T09:05:20+00:00

<img src="https://ithardware.pl/artykuly/min/30057_1.jpg" />            Opłata&nbsp;od czystych nośnik&oacute;w, znana&nbsp;jako opłata reprograficzna, kt&oacute;ra jest formą odszkodowania&nbsp;dla artyst&oacute;w za wykorzystanie ich utwor&oacute;w w ramach dozwolonego użytku osobistego, od dawna nie podoba się samym...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/filmowcy_pozywaja_polske_na_miliony_domagaja_sie_oplat_od_kazdego_sprzedanego_smartfona_czy_laptopa-30057.html">https://ithardware.pl/aktualnosci/filmowcy_pozywaja_polske_na_miliony_domagaja_sie_oplat_od_kazdego_sprzedanego_smartfona_czy_laptopa-30057.html</a></p>

## Hindusi pozostawili bałagan na Księżycu
 - [https://ithardware.pl/aktualnosci/hindusi_pozostawili_balagan_na_ksiezycu-30050.html](https://ithardware.pl/aktualnosci/hindusi_pozostawili_balagan_na_ksiezycu-30050.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-11-03T08:26:40+00:00

<img src="https://ithardware.pl/artykuly/min/30050_1.jpg" />            Indyjska Organizacja Badań Kosmicznych (ISRO) ujawniła wyniki badań, kt&oacute;re rzucają nowe światło na przebieg misji Chandrayaan-3 i jej wpływ na Księżyc, a konkretnie jego zanieczyszczenie.

Lądownik Vikram wylądował bez...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/hindusi_pozostawili_balagan_na_ksiezycu-30050.html">https://ithardware.pl/aktualnosci/hindusi_pozostawili_balagan_na_ksiezycu-30050.html</a></p>

## iiyama G-Master GCB3480WQSU-B1 Red Eagle - ultrapanoramiczny monitor w jeszcze szybszym wydaniu
 - [https://ithardware.pl/aktualnosci/iiyama_g_master_gcb3480wqsu_b1_red_eagle_ultrapanoramiczny_monitor_w_jeszcze_szybszym_wydaniu-30049.html](https://ithardware.pl/aktualnosci/iiyama_g_master_gcb3480wqsu_b1_red_eagle_ultrapanoramiczny_monitor_w_jeszcze_szybszym_wydaniu-30049.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-11-03T08:00:12+00:00

<img src="https://ithardware.pl/artykuly/min/30049_1.jpg" />            iiyama prezentuje następcę modelu G-Master GB3466WQSU-B1 Red Eagle, kt&oacute;ry podbił serca recenzent&oacute;w i graczy na całym świecie. Nowość uznanego japońskiego producenta oferuje jeszcze szybszą matrycę i pozwala zyskać przewagę nad...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/iiyama_g_master_gcb3480wqsu_b1_red_eagle_ultrapanoramiczny_monitor_w_jeszcze_szybszym_wydaniu-30049.html">https://ithardware.pl/aktualnosci/iiyama_g_master_gcb3480wqsu_b1_red_eagle_ultrapanoramiczny_monitor_w_jeszcze_szybszym_wydaniu-30049.html</a></p>

## Pasywne chłodzenie słoną wodą może zwiększyć wydajność procesora o prawie 33%
 - [https://ithardware.pl/aktualnosci/pasywne_chlodzenie_slona_woda_moze_zwiekszyc_wydajnosc_procesora_o_prawie_33-30048.html](https://ithardware.pl/aktualnosci/pasywne_chlodzenie_slona_woda_moze_zwiekszyc_wydajnosc_procesora_o_prawie_33-30048.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-11-03T07:02:09+00:00

<img src="https://ithardware.pl/artykuly/min/30048_1.jpg" />            Niedawno opublikowany artykuł naukowy prezentuje &bdquo;wyjątkową efektywność&rdquo; nowego pasywnego systemu zarządzania temperaturą, kt&oacute;ry może zwiększyć wydajność procesora nawet o 32,65% dzięki chłodzeniu słoną wodą. System...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/pasywne_chlodzenie_slona_woda_moze_zwiekszyc_wydajnosc_procesora_o_prawie_33-30048.html">https://ithardware.pl/aktualnosci/pasywne_chlodzenie_slona_woda_moze_zwiekszyc_wydajnosc_procesora_o_prawie_33-30048.html</a></p>

