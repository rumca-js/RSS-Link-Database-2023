# Source:Sky News, URL:http://feeds.skynews.com/feeds/rss/world.xml, language:en-US

## Briton in Gaza says he can't risk 'being shelled' to get his family to Rafah crossing
 - [https://news.sky.com/story/israel-hamas-war-briton-in-gaza-said-he-cant-risk-being-shelled-to-get-his-family-to-rafah-crossing-12999679](https://news.sky.com/story/israel-hamas-war-briton-in-gaza-said-he-cant-risk-being-shelled-to-get-his-family-to-rafah-crossing-12999679)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-11-03T18:27:00+00:00

A British man trying to leave the Gaza Strip with his family has told Sky News it is too dangerous for them to try to get to the border with Egypt, following two previous attempts.

## 'Scores killed and injured' in Israeli airstrike on ambulance convoy in Gaza
 - [https://news.sky.com/story/israel-hamas-war-scores-killed-and-injured-after-reported-attack-on-ambulance-convoy-in-gaza-12999623](https://news.sky.com/story/israel-hamas-war-scores-killed-and-injured-after-reported-attack-on-ambulance-convoy-in-gaza-12999623)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-11-03T16:57:00+00:00

Scores of people have been killed and injured in an Israeli airstrike on an ambulance convoy near a hospital in Gaza, the Palestinian territory's health ministry has said.

## Colombia to cull hippo population after Pablo Escobar's pets spiral in numbers
 - [https://news.sky.com/story/colombia-to-cull-invasive-hippo-population-after-pablo-escobars-pets-spiral-in-numbers-12999601](https://news.sky.com/story/colombia-to-cull-invasive-hippo-population-after-pablo-escobars-pets-spiral-in-numbers-12999601)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-11-03T16:41:00+00:00

Colombia has announced plans to control its hippo population amid fears it is spiralling out of control after drug kingpin Pablo Escobar introduced them to the country.

## Earthquake in Nepal kills at least 37 people - with more deaths expected to be confirmed
 - [https://news.sky.com/story/earthquake-in-nepal-kills-at-least-37-people-with-more-deaths-expected-to-be-confirmed-12999580](https://news.sky.com/story/earthquake-in-nepal-kills-at-least-37-people-with-more-deaths-expected-to-be-confirmed-12999580)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-11-03T16:07:00+00:00

An earthquake in Nepal has killed at 37 people - with more deaths expected to be confirmed, officials say.

## Liverpool footballer Luis Diaz back in training amid 'hope' for kidnapped dad
 - [https://news.sky.com/story/luis-diaz-liverpool-footballer-back-in-training-amid-hope-for-kidnapped-dad-12999545](https://news.sky.com/story/luis-diaz-liverpool-footballer-back-in-training-amid-hope-for-kidnapped-dad-12999545)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-11-03T15:30:00+00:00

Liverpool forward Luis Diaz has resumed training days after his parents were kidnapped in Colombia.

## What's Russia doing when the world is not looking?
 - [https://news.sky.com/story/whats-russia-doing-when-the-world-is-not-looking-12999490](https://news.sky.com/story/whats-russia-doing-when-the-world-is-not-looking-12999490)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-11-03T14:08:00+00:00

As the world's attention turns to the Israel-Hamas war, Russia is ramping up its offensive in Ukraine.

## Hezbollah leader threatens possible escalation - as Israel warns 'don't test us'
 - [https://news.sky.com/story/hezbollah-leader-threatens-possible-escalation-as-israel-warns-dont-test-us-12999383](https://news.sky.com/story/hezbollah-leader-threatens-possible-escalation-as-israel-warns-dont-test-us-12999383)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-11-03T11:54:00+00:00

The leader of Lebanon's Hezbollah has warned of possible escalation as his militia engages in cross-border fighting with Israel.

## What is Hezbollah, how powerful is its military and what influence does it have in Israel-Hamas war?
 - [https://news.sky.com/story/what-is-hezbollah-how-powerful-is-its-military-and-what-influence-does-it-have-in-israel-hamas-war-12999375](https://news.sky.com/story/what-is-hezbollah-how-powerful-is-its-military-and-what-influence-does-it-have-in-israel-hamas-war-12999375)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-11-03T11:52:00+00:00

Hezbollah has been exchanging fire with Israeli forces on Israel's northern border - leading to fears of a wider conflict.

## Which countries are calling for a ceasefire &#8211; and how is it different to a humanitarian pause?
 - [https://news.sky.com/story/israel-hamas-war-which-countries-are-calling-for-a-ceasefire-8211-and-how-is-it-different-to-a-humanitarian-pause-12999373](https://news.sky.com/story/israel-hamas-war-which-countries-are-calling-for-a-ceasefire-8211-and-how-is-it-different-to-a-humanitarian-pause-12999373)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-11-03T11:48:00+00:00

The UN has failed to adopt a unanimous resolution for a ceasefire between Israel and Hamas.

## King had chance to define vision for Commonwealth on Kenya visit - and it's being hailed a success
 - [https://news.sky.com/story/king-charles-had-chance-to-define-vision-for-commonwealth-on-kenya-visit-and-its-being-hailed-a-success-12999333](https://news.sky.com/story/king-charles-had-chance-to-define-vision-for-commonwealth-on-kenya-visit-and-its-being-hailed-a-success-12999333)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-11-03T10:44:00+00:00

Even with four days there seemed a lot to do in Kenya. This was a moment for the King to define his vision for the Commonwealth.

## A war between Israel and Hezbollah would be far more dangerous than current conflict
 - [https://news.sky.com/story/war-between-israel-and-hezbollah-has-potential-to-be-more-dangerous-than-current-conflict-12999206](https://news.sky.com/story/war-between-israel-and-hezbollah-has-potential-to-be-more-dangerous-than-current-conflict-12999206)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-11-03T07:14:00+00:00

Concern is growing about the risk of the Iran-backed militant group Hezbollah in Lebanon declaring all-out war with Israel.

## Nearly 100 Britons on approved list to cross border to Egypt as Israel 'surrounds Gaza City'
 - [https://news.sky.com/story/israel-hamas-war-nearly-100-britons-on-approved-list-to-reach-egypt-as-israel-surrounds-gaza-city-12999161](https://news.sky.com/story/israel-hamas-war-nearly-100-britons-on-approved-list-to-reach-egypt-as-israel-surrounds-gaza-city-12999161)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-11-03T04:12:00+00:00

Nearly 100 Britons are listed among foreigners and Palestinians who will be allowed to leave Gaza and cross into Egypt on Friday.

## Crypto may never recover after Sam Bankman-Fried's downfall
 - [https://news.sky.com/story/sam-bankman-fried-found-guilty-and-the-crypto-industry-may-never-recover-12999151](https://news.sky.com/story/sam-bankman-fried-found-guilty-and-the-crypto-industry-may-never-recover-12999151)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-11-03T00:43:00+00:00

It took just four hours for a jury to find fallen "crypto king" Sam Bankman-Fried guilty of fraud.

