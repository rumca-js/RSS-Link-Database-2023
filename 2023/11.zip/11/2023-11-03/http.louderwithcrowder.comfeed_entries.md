# Source:Louder With Crowder, URL:http://louderwithcrowder.com/feed/, language:en-US

## Watch: Ohio Woman Identifies As A Vampire But Not One Of The Bad Ones, Says She Follows A “Higher Path”
 - [https://www.louderwithcrowder.com/ohio-woman-vampire](https://www.louderwithcrowder.com/ohio-woman-vampire)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-11-03T19:33:52+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=50392782&amp;width=2000&amp;height=1500&amp;coordinates=97%2C0%2C223%2C0" /><br /><br /><p>This is not some Fang-tasy. </p><p>Hellen Schweizer identifies as a real vampire and Oct. 31, 2023, marked the two-year anniversary of her vampiric epiphany that set her “free”. </p><p>There is no turning back for the 28-year-old woman who identifies as a real vampire, as she wears fangs, red lipstick with a "Phoenix eye," punctuated by red, orange, and yellow, and a beak and a tail. She also wears a white shirt with "flowy sleeves" and a black cape. </p><p>"It's my go-to look,” she <a href="https://www.usatoday.com/story/news/nation/2023/10/31/hellen-schweizer-woman-identifies-as-vampire/71317120007/" rel="noopener noreferrer" target="_blank">told </a>USA Today. </p><p>The Ohio woman has gotten attention on social media and has also been accepted by her hometown of Wooster, where people are more “intrigued” than anything, s

## Watch: Virginia Democrat Posts Video Of Herself Urinating Outdoors In "World's Unsexiest Pee Tape"
 - [https://www.louderwithcrowder.com/virginia-democrat-video](https://www.louderwithcrowder.com/virginia-democrat-video)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-11-03T19:29:15+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=50392760&amp;width=2000&amp;height=1500&amp;coordinates=152%2C0%2C168%2C0" /><br /><br /><p>Stay Classy, Virgina. </p><p>Virginia's political landscape has recently been taken by storm with some unconventional behavior by Democratic candidates, specifically liberal white women. <a href="https://www.washingtonpost.com/dc-md-va/2023/09/11/susanna-gibson-sex-website-virginia-candidate/" rel="noopener noreferrer" target="_blank">Susanna Gibson</a>, a House of Delegates hopeful, was as recently as last year posting as “HotWifeExperience” on a website called Chaturbate, where men use tokens to get her to perform sex acts. </p><p>In one video recorded last year, shortly after she launched her campaign, she told her husband, “I’ll let you f— me in the a– doggy style in a private room if someone wants to pay. That’s the deal.”</p><p>She also talked about forcing unsuspecting hotel staff to take part in her pornographic vid

## Watch: Bearded (Female?) Rabbi Heckling Biden Demands "Ceasefire Now," Cause POTUS To Change Policy And/Or Get Confused
 - [https://www.louderwithcrowder.com/rabbi-heckler-bearded](https://www.louderwithcrowder.com/rabbi-heckler-bearded)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-11-03T19:23:53+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=50392737&amp;width=2000&amp;height=1500&amp;coordinates=0%2C0%2C709%2C0" /><br /><br /><p>On Wednesday Joe Biden <a href="https://www.dailymail.co.uk/news/article-12700127/Biden-heckled-rabbi-Minneapolis-fundraiser-demands-ceasefire-takes-credit-tempering-Benjamin-Netanyahu-calls-pause.html" rel="noopener noreferrer" target="_blank">was confronted</a> by a bearded rabbi at a fundraising event in Minnesota who demanded a ceasefire in Gaza. This left the president claiming he had asked for a “pause.”</p><p>It’s unclear whether the bearded rabbi is trans as the Daily Mail claims the individual deliberately avoids answering that. But “shim” sounds like a woman in the video. </p><p>If it looks like a duck but doesn't talk like a duck, is it a duck? </p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/Evans4WV/status/1720197322129154116"></a>
</bl

## Watch: Warfare Specialist Gives MILITARY INSIGHT Into Everything Going on In Gaza!
 - [https://www.louderwithcrowder.com/gaza-military-insight](https://www.louderwithcrowder.com/gaza-military-insight)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-11-03T19:17:36+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=50392711&amp;width=2000&amp;height=1500&amp;coordinates=366%2C0%2C0%2C0" /><br /><br /><p>John Spencer, Chair of Urban Warfare Studies at the War Institute joined to talk about the conflict in Gaza between Hamas and Israel.</p><p class="shortcode-media shortcode-media-youtube">
<span class="rm-shortcode" style="display: block; padding-top: 56.25%;"></span>
<small class="image-media media-caption">Warfare Specialist Gives MILITARY INSIGHT Into Everything Going on In Gaza!</small>
<small class="image-media media-photo-credit">
<a href="https://www.youtube.com/watch?v=7W33WUPL_Go" target="_blank">www.youtube.com</a>
</small>
</p>

## Watch: Jewish TikToker goes undercover at pro-Palestine rally, exposes antisemitism in NYC (that voted 86% for Joe Biden)
 - [https://www.louderwithcrowder.com/jewish-tiktoker-goes-undercover](https://www.louderwithcrowder.com/jewish-tiktoker-goes-undercover)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-11-03T18:01:49+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=50390846&amp;width=1200&amp;height=600&amp;coordinates=0%2C19%2C0%2C61" /><br /><br /><p>A member of the Israel on Campus Coalition went undercover at one of many pro-Hamas, free-Palestine rallies taking place in New York City. This gathering was in Manhattan, which voted over 86% for Joe Biden in 2020. We are told that the people protesting are NOT antisemitic and DON'T hate the Jews. They are just holding mostly peaceful protests to criticize the Israeli government. </p><p>Though, there are still "critics" who say it's nothing but antisemitism. ICC was determined to find out if this is still about freeing Palestine? Or hating Jews?</p><p>Two points of information. This is a tweet from the ICC:</p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/israelcc/status/1717649352439603480"></a>
</blockquote>
<p>And this is a tweet from <a href="htt

## Jason Aldean breaks silence about feud with woke pop tart Maren Morris, seems unsure what a Maren Morris is
 - [https://www.louderwithcrowder.com/jason-aldean-maren-morris-feud](https://www.louderwithcrowder.com/jason-aldean-maren-morris-feud)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-11-03T17:04:42+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=50390430&amp;width=1200&amp;height=600&amp;coordinates=0%2C46%2C0%2C34" /><br /><br /><p>Jason Aldean is doing press tours for his new album <em>Highway Desperado</em>, and the media is finally getting to ask him about all the Aldean family drama over the past few years. They asked about the controversy over the <em>Try That in a Small Town</em> video. Spoiler: <a href="https://www.louderwithcrowder.com/jason-aldean-new-album" target="_blank">He's still not sorry</a>. Now we get to hear about the feud he and wife Brittany have with Maren Morris. Or the feud Maren has with them. She can't calm down about the Aldeans. They nothing her.</p><p>The drama started last year when Brittany posted the following video to her Instagram page, commenting on the parents who push their own gender-based ideology on their innocent children.</p><div class="rm-embed embed-media"><blockquote class="instagram-media"><div style="padding

## Watch: Target CEO Says Americans Upset Over Trans Merch Being Pushed On Kids More Dangerous Than George Floyd Rioters
 - [https://www.louderwithcrowder.com/target-ceo-lgbt](https://www.louderwithcrowder.com/target-ceo-lgbt)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-11-03T16:00:56+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=50390164&amp;width=1200&amp;height=800&amp;coordinates=79%2C0%2C121%2C0" /><br /><br /><p>“Psychological projection” is a defense mechanism that progressives often suffer from where they subconsciously project undesirable feelings or emotions onto someone else, rather than admitting to or dealing with the unwanted feelings. </p><p>This is what we are about to witness in this interview with Target CEO Brian Cornell. </p><p>Cornell suggested that the blowback over transgender merchandise that generated a boycott came from violent customers who threatened his employees’ safety, which hurt far more people than George Floyd rioters in the <a href="https://thehill.com/homenews/media/513902-cnn-ridiculed-for-fiery-but-mostly-peaceful-caption-with-video-of-burning/" rel="noopener noreferrer" target="_blank">fiery</a>, but mostly peaceful protests in the summer of 2020. </p><blockquote class="rm-embed twitter-tweet">
<div 

## Watch: Target CEO Says Americans Upset Over Trans Merch Being Pushed On Kids More Dangerous Than George Floyd Rioters
 - [https://www.louderwithcrowder.com/target-ceo-speaks](https://www.louderwithcrowder.com/target-ceo-speaks)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-11-03T16:00:56+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=50390164&amp;width=1200&amp;height=600&amp;coordinates=0%2C0%2C0%2C80" /><br /><br /><p>“Psychological projection” is a defense mechanism that progressives often suffer from where they subconsciously project undesirable feelings or emotions onto someone else, rather than admitting to or dealing with the unwanted feelings. </p><p>This is what we are about to witness in this interview with Target CEO Brian Cornell. </p><p>Cornell suggested that the blowback over transgender merchandise that generated a boycott came from violent customers who threatened his employees’ safety, which hurt far more people than George Floyd rioters in the <a href="https://thehill.com/homenews/media/513902-cnn-ridiculed-for-fiery-but-mostly-peaceful-caption-with-video-of-burning/" rel="noopener noreferrer" target="_blank">fiery</a>, but mostly peaceful protests in the summer of 2020. </p><blockquote class="rm-embed twitter-tweet">
<div st

## Police harass man driving "Booty Patrol" truck with citation, driver mistakenly thought this was America
 - [https://www.louderwithcrowder.com/booty-patrol](https://www.louderwithcrowder.com/booty-patrol)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-11-03T13:55:30+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=50380711&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C0" /><br /><br /><p>There is a border crisis in America. Everyone knows that. Lesser known is that America is suffering from a booty crisis. Thankfully, if you live in South Florida, the BOOTY PATROL is on the case. Or, was on the case. Police pulled the Booty Patrol over because they weren't actual officers of the law.</p><p class="shortcode-media shortcode-media-rebelmouse-image">
<img alt="" class="rm-shortcode" id="06fa9" src="https://www.louderwithcrowder.com/media-library/image.gif?id=50381464&amp;width=980" />
</p><p>On November 1, a Florida man was cited for driving a truck that looked just like a Border Patrol truck. Only instead of "border," it said "<a href="https://www.louderwithcrowder.com/big-booty-french-cop" target="_blank">booty</a>." Because my man is also always on patrol <a href="https://www.louderwithcrowder.com/onlyfans-booze-

## Watch: Students stage walkout over policy adults put in place demanding boys be allowed to use the girls' bathroom
 - [https://www.louderwithcrowder.com/loudon-county-walkout](https://www.louderwithcrowder.com/loudon-county-walkout)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-11-03T12:51:18+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=50379097&amp;width=1200&amp;height=800&amp;coordinates=200%2C0%2C0%2C0" /><br /><br /><p>Students are starting to speak out about adult school board members who force girls to share a bathroom with boys. The students are concerned with safety. The school boards are concerned with their radical progressive political agenda. At Woodgrove High School in Loudon County, Virginia, the students staged a walkout to protest a two-year-old policy.</p><p>If Loudon County sounds familiar, it's become Ground Zero for education-related culture wars. It started with father <a href="https://www.louderwithcrowder.com/watch-scott-smith-loudoun-county" target="_blank">Scott Smith</a> being dragged out of a school board meeting by security. He became the poster child for the anger parents were directing at school board members and why <a href="https://www.louderwithcrowder.com/doocy-psaki-crt" target="_blank">the White House</a> cons

## Exclusive Footage: Sketchy Migrants From Everywhere Invade NYC!
 - [https://www.louderwithcrowder.com/migrant-crisis-nyc](https://www.louderwithcrowder.com/migrant-crisis-nyc)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-11-03T12:06:35+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=50379019&amp;width=1200&amp;height=800&amp;coordinates=0%2C0%2C300%2C0" /><br /><br /><p>What is happening to NYC? </p><p class="shortcode-media shortcode-media-youtube">
<span class="rm-shortcode" style="display: block; padding-top: 56.25%;"></span>
<small class="image-media media-caption">Exclusive Footage: Sketchy Migrants From Everywhere Invade NYC!</small>
<small class="image-media media-photo-credit">
<a href="https://www.youtube.com/watch?v=_Bspyvxllts" target="_blank">www.youtube.com</a>
</small>
</p><p><strong>MUG CLUB EXCLUSIVE: ILLEGAL IMMIGRANT TIDAL WAVE</strong></p><ul><li><a href="https://www.seacoastecho.com/news/national/5-000-migrants-traveling-by-foot-to-cross-us-mexico-border/video_7e0539f8-b5c6-5d9c-a669-b1ea757822bc.html" rel="noopener noreferrer" target="_blank">5,000 migrants traveling by foot to cross US-Mexico border</a></li><li><a href="https://www.seacoastecho.com/news/national/5-000-mi

## Dolly Parton still REFUSES to cancel Kid Rock, even though the media keeps trying: "I love Kid Rock"
 - [https://www.louderwithcrowder.com/dolly-parton-kid-rock](https://www.louderwithcrowder.com/dolly-parton-kid-rock)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-11-03T11:52:24+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=50377263&amp;width=1200&amp;height=600&amp;coordinates=0%2C66%2C0%2C22" /><br /><br /><p>Kid Rock is at a point in his career where the media is going to force anyone who works with him to justify it because he has "bad" political opinions. <a href="https://www.louderwithcrowder.com/dolly-parton-super-bowl-ad" target="_blank">Dolly Parton</a> is at a point where she doesn't care and bless the hearts of anyone who asks. Yet because she recorded a song with Rock for her new album, here we are.</p><p>Part of it concerns a controversy I missed a few months ago. Around the time of the <a href="https://www.louderwithcrowder.com/bud-light-plummets-north-america" target="_blank">Bud Light/Dylan Mulvaney brewhaha</a>, Dolly released the details of her <em>Rockstar</em> album that is due out in a few weeks. The album is ridiculous. It's twenty-one songs of Dolly covering rock anthems. I won't list all the artists she worked

