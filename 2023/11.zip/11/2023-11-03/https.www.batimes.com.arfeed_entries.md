# Source:Argentina - Buenos Aires Times, URL:https://www.batimes.com.ar/feed, language:en

## Argentina’s Milei has narrow lead over Massa ahead of run-off
 - [https://www.batimes.com.ar/news/argentina/argentinas-milei-has-narrow-lead-over-massa-ahead-of-run-off.phtml](https://www.batimes.com.ar/news/argentina/argentinas-milei-has-narrow-lead-over-massa-ahead-of-run-off.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2023-11-03T20:27:49+00:00

<p><img alt="Javier Milei closes his presidential campaign at the Movistar Arena." src="https://fotos.perfil.com/2023/10/19/trim/540/304/javier-milei-closes-his-presidential-campaign-at-the-movistar-arena-1678204.jpg" /></p>Brazil-based AtlasIntel puts Milei’s support at 48.5% compared to 44.7% for Massa. <a href="https://www.batimes.com.ar/news/argentina/argentinas-milei-has-narrow-lead-over-massa-ahead-of-run-off.phtml">Leer más</a>

## Argentine soybean processor Vicentin at risk if US$1.3-billion rescue deal rejected
 - [https://www.batimes.com.ar/news/economy/argentine-soybean-processor-vicentin-at-risk-if-us13-billion-rescue-deal-rejected.phtml](https://www.batimes.com.ar/news/economy/argentine-soybean-processor-vicentin-at-risk-if-us13-billion-rescue-deal-rejected.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2023-11-03T20:23:01+00:00

<p><img alt="Vicentin factory entrance in San Lorenzo." src="https://fotos.perfil.com/2023/11/03/trim/540/304/vicentin-factory-entrance-in-san-lorenzo-1690596.jpg" /></p>Vicentin SAIC, which has been battling an Argentine court to get the plan approved, would struggle to survive if its US$1.3-billion rescue deal is rejected. <a href="https://www.batimes.com.ar/news/economy/argentine-soybean-processor-vicentin-at-risk-if-us13-billion-rescue-deal-rejected.phtml">Leer más</a>

## Brazil's Lula and Spain's Sánchez plead for finalising Mercosur-EU agreement
 - [https://www.batimes.com.ar/news/economy/lula-and-sanchez-plead-for-finalising-mercosur-eu-agreement.phtml](https://www.batimes.com.ar/news/economy/lula-and-sanchez-plead-for-finalising-mercosur-eu-agreement.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2023-11-03T19:54:36+00:00

<p><img alt="Luiz Inacio Lula da Silva" src="https://fotos.perfil.com/2023/08/02/trim/540/304/luiz-inacio-lula-da-silva-1622896.jpg" /></p>President of Brazil Luiz Inácio Lula da Silva and Spanish Prime Minister Pedro Sánchez pled in a telephone conversation on Friday for finalising the trade agreement between Mercosur and the European Union as soon as possible. <a href="https://www.batimes.com.ar/news/economy/lula-and-sanchez-plead-for-finalising-mercosur-eu-agreement.phtml">Leer más</a>

## Foreign currency income from agroindustry down 50% so far this year
 - [https://www.batimes.com.ar/news/economy/foreign-currency-from-agroindustry-collapses-by-50-percent-so-far-this-year.phtml](https://www.batimes.com.ar/news/economy/foreign-currency-from-agroindustry-collapses-by-50-percent-so-far-this-year.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2023-11-03T18:40:57+00:00

<p><img alt="AGRO" src="https://fotos.perfil.com/2023/11/03/trim/540/304/agro-1690468.jpg" /></p>Impact of severe drought illustrated by lack of income – as much as US$20 billion might be lost this year. <a href="https://www.batimes.com.ar/news/economy/foreign-currency-from-agroindustry-collapses-by-50-percent-so-far-this-year.phtml">Leer más</a>

## Stories that caught our eye: October 27 to November 3
 - [https://www.batimes.com.ar/news/argentina/stories-that-caught-our-eye-october-27-to-november-3.phtml](https://www.batimes.com.ar/news/argentina/stories-that-caught-our-eye-october-27-to-november-3.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2023-11-03T18:08:00+00:00

<p><img alt="high waters, Iguazú Falls" src="https://fotos.perfil.com/2023/11/03/trim/540/304/high-waters-iguazu-falls-1690192.jpg" /></p>A selection of the stories that caught our eye over the last seven days in Argentina. <a href="https://www.batimes.com.ar/news/argentina/stories-that-caught-our-eye-october-27-to-november-3.phtml">Leer más</a>

## Argentina's Massa planning IMF talks over US$12 billion due next year
 - [https://www.batimes.com.ar/news/economy/massa-prepares-renegotiation-with-imf-to-face-us12-billion-debt.phtml](https://www.batimes.com.ar/news/economy/massa-prepares-renegotiation-with-imf-to-face-us12-billion-debt.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2023-11-03T17:46:29+00:00

<p><img alt="sergio massa, kristalina georgieva, imf" src="https://fotos.perfil.com/2023/03/13/trim/540/304/sergio-massa-kristalina-georgieva-imf-1526813.jpeg" /></p>Argentina's economy minister, if elected in November 19 run-off, will look to open talks with the International Monetary Fund over US$12 billion in maturities due by April 2024.  <a href="https://www.batimes.com.ar/news/economy/massa-prepares-renegotiation-with-imf-to-face-us12-billion-debt.phtml">Leer más</a>

## Anti-Semitism fears grow in Argentina amid Israel-Hamas war
 - [https://www.batimes.com.ar/news/argentina/anti-semitism-fears-grow-in-argentina-amid-israel-hamas-war.phtml](https://www.batimes.com.ar/news/argentina/anti-semitism-fears-grow-in-argentina-amid-israel-hamas-war.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2023-11-03T13:21:20+00:00

<p><img alt="Star of David, Anti-Semitism, Caballito, buenos aires, graffiti" src="https://fotos.perfil.com/2023/11/03/trim/540/304/star-of-david-anti-semitism-caballito-buenos-aires-graffiti-1690204.jpg" /></p>More than 100 complaints of anti-Semitism have been reported to DAIA Jewish organisation since outbreak of war in Middle East; 'Star of David' graffiti on building in Caballito ramps up discrimination fears as Jewish schools issue uniform warning. <a href="https://www.batimes.com.ar/news/argentina/anti-semitism-fears-grow-in-argentina-amid-israel-hamas-war.phtml">Leer más</a>

## When two’s not company but three’s still a crowd
 - [https://www.batimes.com.ar/news/op-ed/when-twos-not-company-but-threes-still-a-crowd.phtml](https://www.batimes.com.ar/news/op-ed/when-twos-not-company-but-threes-still-a-crowd.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2023-11-03T13:03:17+00:00

<p><img alt="Macri chainsaw." src="https://fotos.perfil.com/2023/11/03/trim/540/304/macri-chainsaw-1690191.jpg" /></p>A run-off normally reduces politics to its purest binary logic as a simple either/or proposition but the upcoming showdown between Sergio Massa and Javier Milei is rather more complex. <a href="https://www.batimes.com.ar/news/op-ed/when-twos-not-company-but-threes-still-a-crowd.phtml">Leer más</a>

## The candidates for Sergio Massa’s Cabinet
 - [https://www.batimes.com.ar/news/argentina/the-candidates-for-sergio-massas-cabinet.phtml](https://www.batimes.com.ar/news/argentina/the-candidates-for-sergio-massas-cabinet.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2023-11-03T02:26:44+00:00

<p><img alt="Sergio Massa." src="https://fotos.perfil.com/2023/11/02/trim/540/304/sergio-massa-1690042.jpg" /></p>The names rumoured to occupy the ministries in a future Cabinet led by Sergio Massa – and whether there is a Kirchnerite quota. <a href="https://www.batimes.com.ar/news/argentina/the-candidates-for-sergio-massas-cabinet.phtml">Leer más</a>

## Congress formally opens race to run-off
 - [https://www.batimes.com.ar/news/argentina/congress-formally-opens-race-to-run-off.phtml](https://www.batimes.com.ar/news/argentina/congress-formally-opens-race-to-run-off.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2023-11-03T00:26:55+00:00

<p><img alt="congress session, run-off declared" src="https://fotos.perfil.com/2023/11/02/trim/540/304/congress-session-run-off-declared-1689965.jpeg" /></p>Sergio Massa and Javier Milei go head-to-head for the Presidency on November 19.
 <a href="https://www.batimes.com.ar/news/argentina/congress-formally-opens-race-to-run-off.phtml">Leer más</a>

## Buenos Aires creates its own Spider-Verse in bid to break world record
 - [https://www.batimes.com.ar/news/culture/buenos-aires-creates-its-own-spider-verse-in-bid-to-break-world-record.phtml](https://www.batimes.com.ar/news/culture/buenos-aires-creates-its-own-spider-verse-in-bid-to-break-world-record.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2023-11-03T00:17:53+00:00

<p><img alt="Spider-Man Guinness World Record, Obelisk" src="https://fotos.perfil.com/2023/11/02/trim/540/304/spider-man-guinness-world-record-obelisk-1689962.jpg" /></p>Estimated 3,000 porteños flock to the capital’s iconic Obelisk dressed in Spider-Man costumes in attempt to break Guinness World Record.
 <a href="https://www.batimes.com.ar/news/culture/buenos-aires-creates-its-own-spider-verse-in-bid-to-break-world-record.phtml">Leer más</a>

