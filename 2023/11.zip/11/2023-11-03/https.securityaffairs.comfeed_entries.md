# Source:Security Affairs, URL:https://securityaffairs.com/feed, language:en-US

## Okta customer support system breach impacted 134 customers
 - [https://securityaffairs.com/153581/data-breach/okta-customer-support-system-breach-customers.html](https://securityaffairs.com/153581/data-breach/okta-customer-support-system-breach-customers.html)
 - RSS feed: https://securityaffairs.com/feed
 - date published: 2023-11-03T20:04:23+00:00

<p>Threat actors who breached the Okta customer support system also gained access to files belonging to 134 customers. Threat actors who breached the Okta customer support system in October gained access to files belonging to 134 customers, the company revealed. Some of the files accessed by the attackers are HAR files that contained session tokens. [&#8230;]</p>
<p>The post <a href="https://securityaffairs.com/153581/data-breach/okta-customer-support-system-breach-customers.html">Okta customer support system breach impacted 134 customers</a> appeared first on <a href="https://securityaffairs.com">Security Affairs</a>.</p>

## Multiple WhatsApp mods spotted containing the CanesSpy Spyware
 - [https://securityaffairs.com/153564/mobile-2/whatsapp-mods-canesspy-spyware.html](https://securityaffairs.com/153564/mobile-2/whatsapp-mods-canesspy-spyware.html)
 - RSS feed: https://securityaffairs.com/feed
 - date published: 2023-11-03T15:10:18+00:00

<p>Kaspersky researchers are warning of multiple WhatsApp mods that embed a spyware module dubbed&#160;CanesSpy. Kaspersky researchers discovered multiple WhatsApp mods that embed a spyware module dubbed&#160;CanesSpy. mods are modifications or alterations made to an application, often by third-party developers or users. These modifications can serve various purposes, such as adding new features, customizing the app&#8217;s [&#8230;]</p>
<p>The post <a href="https://securityaffairs.com/153564/mobile-2/whatsapp-mods-canesspy-spyware.html">Multiple WhatsApp mods spotted containing the CanesSpy Spyware</a> appeared first on <a href="https://securityaffairs.com">Security Affairs</a>.</p>

## Russian FSB arrested Russian hackers who supported Ukrainian cyber operations
 - [https://securityaffairs.com/153539/cyber-warfare-2/fsb-arrested-russian-hackers-supported-ukraine.html](https://securityaffairs.com/153539/cyber-warfare-2/fsb-arrested-russian-hackers-supported-ukraine.html)
 - RSS feed: https://securityaffairs.com/feed
 - date published: 2023-11-03T11:21:38+00:00

<p>The FSB arrested two Russian hackers who are accused of having helped Ukrainian entities carry out cyberattacks on critical infrastructure targets. The Russian intelligence agency Federal Security Service (FSB) arrested two individuals who are suspected of supporting Ukrainian entities to carry out cyberattacks to disrupt Russian critical infrastructure. The two men are facing high treason [&#8230;]</p>
<p>The post <a href="https://securityaffairs.com/153539/cyber-warfare-2/fsb-arrested-russian-hackers-supported-ukraine.html">Russian FSB arrested Russian hackers who supported Ukrainian cyber operations</a> appeared first on <a href="https://securityaffairs.com">Security Affairs</a>.</p>

## MuddyWater has been spotted targeting two Israeli entities
 - [https://securityaffairs.com/153475/apt/muddywater-targets-israeli-entities.html](https://securityaffairs.com/153475/apt/muddywater-targets-israeli-entities.html)
 - RSS feed: https://securityaffairs.com/feed
 - date published: 2023-11-03T08:59:29+00:00

<p>Iran-linked cyberespionage group MuddyWater&#160;is targeting Israeli entities in a new spear-phishing campaign. Iran-linked APT group MuddyWater&#160;(aka&#160;SeedWorm,&#160;TEMP.Zagros, and&#160;Static Kitten)&#160;is targeting Israeli entities in a new spear-phishing campaign, Deep Instinct’s Threat Research team reported. The phishing messages were aimed at deploying a legitimate remote administration tool called&#160;Advanced Monitoring Agent. This is the first time that the Iranian [&#8230;]</p>
<p>The post <a href="https://securityaffairs.com/153475/apt/muddywater-targets-israeli-entities.html">MuddyWater has been spotted targeting two Israeli entities</a> appeared first on <a href="https://securityaffairs.com">Security Affairs</a>.</p>

