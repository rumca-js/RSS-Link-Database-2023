# Source:Linux Today News, URL:https://www.linuxtoday.com/news/feed, language:en-US

## Audacity 3.4 Released with Music Workflows, New Exporter & More
 - [https://www.linuxtoday.com/news/audacity-3-4-released-with-music-workflows-new-exporter-more](https://www.linuxtoday.com/news/audacity-3-4-released-with-music-workflows-new-exporter-more)
 - RSS feed: https://www.linuxtoday.com/news/feed
 - date published: 2023-11-03T13:00:48+00:00

<p>Coming more than six months after Audacity 3.3, the Audacity 3.4 release is here to introduce three new features, starting with music workflows, allowing you to switch between hh:mm:ss time and Beats &#38; Measures, as well as to time-stretch clips to align them to a song’s tempo.</p>
<p>The post <a href="https://www.linuxtoday.com/news/audacity-3-4-released-with-music-workflows-new-exporter-more/" rel="nofollow">Audacity 3.4 Released with Music Workflows, New Exporter &#038; More</a> appeared first on <a href="https://www.linuxtoday.com" rel="nofollow">Linux Today</a>.</p>

