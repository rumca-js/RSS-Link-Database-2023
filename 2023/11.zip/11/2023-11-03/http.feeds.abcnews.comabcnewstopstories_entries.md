# Source:ABC News, URL:http://feeds.abcnews.com/abcnews/topstories, language:en-US

## Magnitude 5.6 earthquake hits Nepal: USGS
 - [https://abcnews.go.com/International/magnitude-56-earthquake-hits-nepal-usgs/story?id=104620611](https://abcnews.go.com/International/magnitude-56-earthquake-hits-nepal-usgs/story?id=104620611)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-11-03T22:31:40+00:00

Magnitude 5.6 earthquake hits Nepal.

## Family of US hostages believed to be taken during kibbutz massacre plead for release
 - [https://abcnews.go.com/International/family-us-hostages-believed-israeli-kibbutz-massacre-plead/story?id=104609878](https://abcnews.go.com/International/family-us-hostages-believed-israeli-kibbutz-massacre-plead/story?id=104609878)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-11-03T21:52:40+00:00

The family of Keith and Adrienne Siegel  -- who are believed to have been taken hostage -- speak out in an interview.

## Biden visits Maine to grieve with community in wake of Lewiston mass shooting
 - [https://abcnews.go.com/Politics/biden-lady-visit-maine-grieve-community-wake-mass/story?id=104604334](https://abcnews.go.com/Politics/biden-lady-visit-maine-grieve-community-wake-mass/story?id=104604334)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-11-03T20:33:22+00:00

President Joe Biden and first lady Jill Biden visited Lewiston, Maine, to grieve with a community reeling from a mass shooting that left 18 people dead.

## Ex-Utah county clerk accused of shredding, mishandling 2020 and 2022 ballots
 - [https://abcnews.go.com/US/wireStory/former-utah-county-clerk-accused-shredding-mishandling-2020-104617434](https://abcnews.go.com/US/wireStory/former-utah-county-clerk-accused-shredding-mishandling-2020-104617434)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-11-03T20:01:03+00:00

Utah prosecutors have charged a former county clerk for allegedly shredding and otherwise mishandling ballots from the 2020 and 2022 elections

## Judge gives life in prison for look-out in Florida gang shooting that killed 3
 - [https://abcnews.go.com/US/wireStory/judge-life-prison-florida-gang-shooting-killed-3-104617443](https://abcnews.go.com/US/wireStory/judge-life-prison-florida-gang-shooting-killed-3-104617443)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-11-03T19:49:53+00:00

The man who served as look-out in a South Florida shooting that left three dead and 20 others injured has been sentenced to life in prison

## New gun laws often follow mass shooting tragedies, recent history shows
 - [https://abcnews.go.com/US/mass-shootings-historically-prompted-gun-laws/story?id=104382663](https://abcnews.go.com/US/mass-shootings-historically-prompted-gun-laws/story?id=104382663)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-11-03T19:17:41+00:00

Mass shootings shine a spotlight on the gun laws of the states in which these tragedies happen.

## Supreme Court to hear NRA appeal in dispute with former New York state official
 - [https://abcnews.go.com/US/wireStory/supreme-court-hear-nra-appeal-dispute-former-new-104616143](https://abcnews.go.com/US/wireStory/supreme-court-hear-nra-appeal-dispute-former-new-104616143)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-11-03T19:05:03+00:00

The Supreme Court has agreed to hear an appeal from the National Rifle Association over comments from a former New York state official who urged banks and insurance companies to discontinue their association with gun promoting groups after the deadly s...

## Lebanon's militant Hezbollah leader taunts Israel in first speech since war started
 - [https://abcnews.go.com/International/wireStory/leader-lebanons-militant-hezbollah-group-speaks-time-israel-104604330](https://abcnews.go.com/International/wireStory/leader-lebanons-militant-hezbollah-group-speaks-time-israel-104604330)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-11-03T19:02:28+00:00

Hezbollah leader Hassan Nasrallah says his powerful militia is engaged in unprecedented cross-border fighting with Israel along the Lebanon-Israel border and is threatening a further escalation as the four-week-long Israel-Hamas war rages on

## Virginia teacher shot by 6-year-old can proceed with $40 million lawsuit, judge rules
 - [https://abcnews.go.com/US/wireStory/virginia-teacher-shot-6-year-proceed-40-million-104615677](https://abcnews.go.com/US/wireStory/virginia-teacher-shot-6-year-proceed-40-million-104615677)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-11-03T18:59:38+00:00

A judge in Virginia has ruled that a teacher who was shot by her 6-year-old student in class can press forward with a $40 million lawsuit

## Police entered wrong home, held disabled woman, grandkids for hours, lawsuit alleges
 - [https://abcnews.go.com/US/wireStory/chicago-area-police-entered-wrong-home-held-disabled-104616305](https://abcnews.go.com/US/wireStory/chicago-area-police-entered-wrong-home-held-disabled-104616305)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-11-03T18:49:14+00:00

A federal lawsuit alleges that Chicago-area police entered the wrong home while serving an arrest warrant in 2021 and held a disabled woman, her four young grandchildren and other relatives for hours

## Hunter Biden seeks DOJ probe into former business associate Tony Bobulinski
 - [https://abcnews.go.com/US/hunter-biden-seeks-doj-probe-former-business-associate/story?id=104603506](https://abcnews.go.com/US/hunter-biden-seeks-doj-probe-former-business-associate/story?id=104603506)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-11-03T18:35:29+00:00

Hunter Biden is urging the DOJ to investigate a former business associate over claims that he lied to federal investigators about his family's business dealings.

## How Obama helped President Biden draft the AI executive order
 - [https://abcnews.go.com/Politics/obama-helped-president-biden-draft-ai-executive-order/story?id=104608286](https://abcnews.go.com/Politics/obama-helped-president-biden-draft-ai-executive-order/story?id=104608286)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-11-03T17:19:10+00:00

Former President Barack Obama helped draft the new artificial intelligence policy that President Joe Biden rolled out earlier this week, aides said.

## 2 killed in shooting at graveyard during Mexico's Day of the Dead holiday
 - [https://abcnews.go.com/International/wireStory/2-killed-shooting-graveyard-mexicos-day-dead-holiday-104610052](https://abcnews.go.com/International/wireStory/2-killed-shooting-graveyard-mexicos-day-dead-holiday-104610052)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-11-03T17:06:59+00:00

Two men have been shot to death while visiting a graveyard during Mexico's Day of the Dead holiday

## Stellar women's field takes aim at New York City Marathon record on Sunday
 - [https://abcnews.go.com/Sports/wireStory/stellar-womens-field-takes-aim-new-york-city-104609558](https://abcnews.go.com/Sports/wireStory/stellar-womens-field-takes-aim-new-york-city-104609558)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-11-03T17:05:35+00:00

The New York City Marathon women&rsquo;s record, which has stood for 20 years, could go down Sunday with one of the strongest fields assembled in the history of the race

## Trump State Department appointee sentenced for role in Jan. 6 attack
 - [https://abcnews.go.com/Politics/trump-state-department-appointee-sentenced-6-years-role/story?id=104604054](https://abcnews.go.com/Politics/trump-state-department-appointee-sentenced-6-years-role/story?id=104604054)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-11-03T17:02:23+00:00

A former Trump State Department appointee was sentenced Friday to nearly six years in prison for his role in the Jan. 6 attack on the U.S. Capitol.

## NASA spacecraft discovers tiny moon around asteroid during close flyby
 - [https://abcnews.go.com/Technology/wireStory/nasa-spacecraft-discovers-tiny-moon-asteroid-close-flyby-104608207](https://abcnews.go.com/Technology/wireStory/nasa-spacecraft-discovers-tiny-moon-asteroid-close-flyby-104608207)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-11-03T15:50:23+00:00

The little asteroid visited by NASA's Lucy spacecraft this week had a big surprise for scientists _ a mini moon

## Missouri man who carried pitchfork at Capitol riot pleads guilty to 3 felonies
 - [https://abcnews.go.com/US/wireStory/missouri-man-carried-pitchfork-capitol-riot-pleads-guilty-104608381](https://abcnews.go.com/US/wireStory/missouri-man-carried-pitchfork-capitol-riot-pleads-guilty-104608381)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-11-03T15:42:05+00:00

A Missouri man accused of carrying a pitchfork and assaulting police during the Jan. 6, 2021, riot at the U.S. Capitol has pleaded guilty to three federal felonies

## Incident at South Carolina nuclear plant after car drives through security fences
 - [https://abcnews.go.com/US/police-investigating-incident-south-carolina-nuclear-plant-after/story?id=104598780](https://abcnews.go.com/US/police-investigating-incident-south-carolina-nuclear-plant-after/story?id=104598780)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-11-03T14:18:38+00:00

Police in South Carolina are investigating an incident involving a vehicle that drove through security fences at a nuclear power station on Thursday.

## US employers pulled back on hiring in October, adding 150,000 jobs
 - [https://abcnews.go.com/Business/wireStory/us-jobs-report-october-show-solid-hiring-fed-104595060](https://abcnews.go.com/Business/wireStory/us-jobs-report-october-show-solid-hiring-fed-104595060)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-11-03T12:54:27+00:00

The nation&rsquo;s employers scaled back their hiring in October, adding a modest but still decent 150,000 jobs, a sign that the labor market remains resilient despite economic uncertainties and high interest rates that have made borrowing much costlier for ...

## WATCH:  ABC News gets an up-close look at Israel's air defenses
 - [https://abcnews.go.com/International/video/abc-news-gets-close-israels-air-defenses-104602356](https://abcnews.go.com/International/video/abc-news-gets-close-israels-air-defenses-104602356)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-11-03T12:42:12+00:00

ABC News' Chief Foreign Correspondent Ian Pannell speaks with a senior IDF officer about how Israel defends itself against aerial attack, as the Israel-Hamas conflict continues.

## Iran sentences a woman to death for adultery, state media say
 - [https://abcnews.go.com/International/wireStory/iran-sentences-woman-death-adultery-state-media-104598679](https://abcnews.go.com/International/wireStory/iran-sentences-woman-death-adultery-state-media-104598679)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-11-03T11:49:52+00:00

Iranian state media say a court has sentenced a woman to death for adultery

## A small plane headed from Croatia to Salzburg crashes in Austria, killing 4 people
 - [https://abcnews.go.com/International/wireStory/small-plane-headed-croatia-salzburg-crashes-austria-killing-104598410](https://abcnews.go.com/International/wireStory/small-plane-headed-croatia-salzburg-crashes-austria-killing-104598410)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-11-03T11:38:53+00:00

A small plane flying from Croatia to Salzburg has crashed in Austria, killing four people

## Russia steps up its aerial barrage of Ukraine as Kyiv brace for attacks
 - [https://abcnews.go.com/International/wireStory/russia-steps-aerial-barrage-ukraine-kyiv-officials-brace-104599516](https://abcnews.go.com/International/wireStory/russia-steps-aerial-barrage-ukraine-kyiv-officials-brace-104599516)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-11-03T11:23:03+00:00

Ukrainian authorities say Russia unleashed a wave of nighttime drone and missile attacks across 10 of Ukraine&rsquo;s 24 regions

## Former soldier accused of threatening to kill military personnel
 - [https://abcnews.go.com/US/former-soldier-accused-threatening-kill-military-personnel/story?id=104597145](https://abcnews.go.com/US/former-soldier-accused-threatening-kill-military-personnel/story?id=104597145)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-11-03T10:40:07+00:00

Prosecutors have announced charges against Christian Beyer, who is accused of posting a YouTube video threatening to kill military personnel who he believed wronged him.

## Australian woman on murder charges after guests die from eating poisonous mushrooms
 - [https://abcnews.go.com/International/wireStory/australian-lunch-host-charged-3-murders-poisonous-mushrooms-104597509](https://abcnews.go.com/International/wireStory/australian-lunch-host-charged-3-murders-poisonous-mushrooms-104597509)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-11-03T07:58:19+00:00

A woman is accused of serving her ex-husband&rsquo;s relatives poisonous mushrooms.

## Former nurse now linked to 17 nursing home deaths
 - [https://abcnews.go.com/US/former-nurse-now-linked-17-nursing-home-deaths/story?id=104597514](https://abcnews.go.com/US/former-nurse-now-linked-17-nursing-home-deaths/story?id=104597514)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-11-03T06:43:28+00:00

A former nurse who had been accused of killing two patients with doses of insulin now faces more murder charges and has confessed to trying to kill 19 additional people.

## In the wake of Matthew Perry's death, Chinese fans mourn an old friend
 - [https://abcnews.go.com/Entertainment/wireStory/wake-matthew-perrys-death-chinese-fans-mourn-friend-104596443](https://abcnews.go.com/Entertainment/wireStory/wake-matthew-perrys-death-chinese-fans-mourn-friend-104596443)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-11-03T05:26:25+00:00

Long before &ldquo;Friends&rdquo; made its official debut in China, the show was a word-of-mouth phenomenon in the country

## Biden to host summit that focuses on supply chains, migration, new investment
 - [https://abcnews.go.com/Business/wireStory/biden-host-americas-summit-focuses-supply-chains-migration-104596171](https://abcnews.go.com/Business/wireStory/biden-host-americas-summit-focuses-supply-chains-migration-104596171)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-11-03T05:02:36+00:00

President Joe Biden is gathering leaders from countries across the Americas on Friday in the U.S. capital to discuss the tightening of supply chains and addressing migration issues

## The FBI is investigating a Texas sheriff's office, a woman interviewed by agents says
 - [https://abcnews.go.com/US/wireStory/fbi-investigating-texas-sheriffs-office-woman-interviewed-agents-104595982](https://abcnews.go.com/US/wireStory/fbi-investigating-texas-sheriffs-office-woman-interviewed-agents-104595982)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-11-03T04:58:32+00:00

A woman interviewed by FBI agents says they are investigating allegations of wrongdoing by a Texas sheriff who faced complaints of corruption for years before drawing broader scrutiny for his response to a mass shooting

## Daylight saving 2023: Here’s what a sleep expert says about the time change
 - [https://abcnews.go.com/Health/wireStory/daylight-saving-2023-heres-sleep-expert-time-change-104595983](https://abcnews.go.com/Health/wireStory/daylight-saving-2023-heres-sleep-expert-time-change-104595983)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-11-03T04:57:07+00:00

Brunch dates and flag football games might be a little easier to get to this Sunday, when phones grace early-risers with an extra hour of rest before alarm clocks go off

## After an Israeli airstrike, crowded Gaza hospital struggles to treat wounded children
 - [https://abcnews.go.com/Health/wireStory/israeli-airstrike-crowded-gaza-hospital-struggles-treat-wounded-104592019](https://abcnews.go.com/Health/wireStory/israeli-airstrike-crowded-gaza-hospital-struggles-treat-wounded-104592019)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-11-03T00:54:23+00:00

Airstrikes in the Gaza Strip's Bureij refugee camp have flattened entire apartment buildings, sending scores of injured Palestinians into a hospital unable to grant them bed space

## Baffert and Pletcher take aim at Breeders' Cup Juvenile with 3 horses each
 - [https://abcnews.go.com/Sports/wireStory/baffert-pletcher-aim-breeders-cup-juvenile-3-horses-104591652](https://abcnews.go.com/Sports/wireStory/baffert-pletcher-aim-breeders-cup-juvenile-3-horses-104591652)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-11-03T00:52:20+00:00

Bob Baffert and Todd Pletcher are taking aim at the $2 million Breeders&rsquo; Cup Juvenile with three horses each

## Panama's congress backtracks to preserve controversial Canadian mining contract
 - [https://abcnews.go.com/Business/wireStory/panamas-congress-backtracks-preserve-controversial-canadian-mining-contract-104591943](https://abcnews.go.com/Business/wireStory/panamas-congress-backtracks-preserve-controversial-canadian-mining-contract-104591943)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-11-03T00:50:41+00:00

A bill banning all new mining activities in Panama will go to a third and final vote after another extraordinary session of debate

## FTX founder Sam Bankman-Fried found guilty in federal fraud and conspiracy trial
 - [https://abcnews.go.com/Business/sam-bankman-fried-trial-verdict-reached-federal-fraud/story?id=104520346](https://abcnews.go.com/Business/sam-bankman-fried-trial-verdict-reached-federal-fraud/story?id=104520346)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-11-03T00:06:52+00:00

Sam Bankman-Fried was charged with seven counts of fraud, conspiracy and money laundering centered on his alleged use of customer deposits on FTX.

