# Source:HackRead, URL:https://www.hackread.com/feed, language:en-US

## Lazarus Group uses KandyKorn macOS malware for crypto theft
 - [https://www.hackread.com/lazarus-kandykorn-macos-malware-crypto](https://www.hackread.com/lazarus-kandykorn-macos-malware-crypto)
 - RSS feed: https://www.hackread.com/feed
 - date published: 2023-11-03T20:01:17+00:00

<p>By <a href="https://www.hackread.com/author/deeba/" rel="nofollow">Deeba Ahmed</a></p>
<p>Another day, another malware operation by the infamous Lazarus group targeting blockchain engineers and crypto users.</p>
<p>This is a post from HackRead.com Read the original post: <a href="https://www.hackread.com/lazarus-kandykorn-macos-malware-crypto/" rel="nofollow">Lazarus Group uses KandyKorn macOS malware for crypto theft</a></p>

## Microsoft’s Secure Future Initiative Boosts Cybersecurity Against Advanced Attacks
 - [https://www.hackread.com/microsoft-secure-future-initiative-cybersecurity-attacks](https://www.hackread.com/microsoft-secure-future-initiative-cybersecurity-attacks)
 - RSS feed: https://www.hackread.com/feed
 - date published: 2023-11-03T17:19:12+00:00

<p>By <a href="https://www.hackread.com/author/deeba/" rel="nofollow">Deeba Ahmed</a></p>
<p>Microsoft's new AI-powered Secure Future Initiative aims to assist governments, businesses, and consumers in combatting cybersecurity threats.</p>
<p>This is a post from HackRead.com Read the original post: <a href="https://www.hackread.com/microsoft-secure-future-initiative-cybersecurity-attacks/" rel="nofollow">Microsoft&#8217;s Secure Future Initiative Boosts Cybersecurity Against Advanced Attacks</a></p>

