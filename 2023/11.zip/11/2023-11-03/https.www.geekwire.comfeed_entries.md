# Source:GeekWire, URL:https://www.geekwire.com/feed/, language:en-US

## Jeff Bezos’ move out of Washington state sparks questions about wealth taxes
 - [https://www.geekwire.com/2023/jeff-bezos-move-out-of-washington-state-sparks-questions-about-wealth-taxes](https://www.geekwire.com/2023/jeff-bezos-move-out-of-washington-state-sparks-questions-about-wealth-taxes)
 - RSS feed: https://www.geekwire.com/feed/
 - date published: 2023-11-03T19:36:20+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="664" src="https://cdn.geekwire.com/wp-content/uploads/2021/09/bezos-climate.png" width="1072" /><br />Did Jeff Bezos&#8217; decision to leave Washington state for Miami have anything to do with taxes? That&#8217;s one question to arise in the wake of the Amazon&#8217;s founder announcement Thursday that he&#8217;s taking his talents to South Beach. Washington state lawmakers recently passed a controversial 7% capital gains tax for gains of $250,000 and up to fund early-childhood education programs and school construction. Bezos has sold billions in Amazon stock over the past several years. The state for years has also debated different versions of a wealth tax. With a net worth of $160 billion, Bezos would be impacted as&#8230; <a href="https://www.geekwire.com/2023/jeff-bezos-move-out-of-washington-state-sparks-questions-about-wealth-taxes/">Read More</a>

## Substance over style: Seattle startups facing fewer down rounds than Bay Area, NYC counterparts
 - [https://www.geekwire.com/2023/substance-over-style-seattle-startups-facing-fewer-down-rounds-than-bay-area-nyc-counterparts](https://www.geekwire.com/2023/substance-over-style-seattle-startups-facing-fewer-down-rounds-than-bay-area-nyc-counterparts)
 - RSS feed: https://www.geekwire.com/feed/
 - date published: 2023-11-03T18:05:00+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="817" src="https://cdn.geekwire.com/wp-content/uploads/2019/02/seattleskyline2018-1260x817.jpg" width="1260" /><br />Seattle startups are facing fewer down rounds than companies in the Bay Area and New York City, signaling a slightly more modest retrenchment in the Emerald City amid the broader tech market downturn. Through the nine months ended September, about 12% of funding rounds in Seattle resulted in lower valuations, compared to the Bay Area&#8217;s 17% and New York&#8217;s 24%, according to data provided to GeekWire from equity management company Carta. That compares to a national average of about 17%. Down rounds, which describe funding raised at lower valuations than previous rounds, have plagued many early-stage companies in 2023 amid&#8230; <a href="https://www.geekwire.com/2023/substance-over-style-seattle-startups-facing-fewer-down-rounds-than-bay-area-nyc-counterparts/">Read More</a>

## Seattle cloud giant F5 lays off 120 employees
 - [https://www.geekwire.com/2023/seattle-cloud-giant-f5-lays-off-120-employees](https://www.geekwire.com/2023/seattle-cloud-giant-f5-lays-off-120-employees)
 - RSS feed: https://www.geekwire.com/feed/
 - date published: 2023-11-03T17:29:47+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="473" src="https://cdn.geekwire.com/wp-content/uploads/2020/01/f5.jpg" width="630" /><br />Seattle-based application security and delivery giant F5 this week laid off 120 people, the company confirmed to GeekWire.

## Brinc delivers first Lemur 2 drones to U.S. public safety agencies
 - [https://www.geekwire.com/2023/brinc-delivers-first-lemur-2-drones-to-u-s-public-safety-agencies](https://www.geekwire.com/2023/brinc-delivers-first-lemur-2-drones-to-u-s-public-safety-agencies)
 - RSS feed: https://www.geekwire.com/feed/
 - date published: 2023-11-03T16:22:15+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="489" src="https://cdn.geekwire.com/wp-content/uploads/2023/11/keynote_HD_blue_021523_2-1260x489.jpg" width="1260" /><br />Seattle-based public safety technology startup Brinc this week delivered the first production units of its Lemur 2 drones to police and other emergency responders in the United States. The company, led by CEO Blake Resnick, says it has made a series of upgrades to the Lemur 2 since it was unveiled in March, including improvements in its antenna range, and better self-righting and obstacle avoidance capabilities. Brinc&#8217;s drones are able to see in the dark, communicate through a microphone, and break through glass, among other features. In addition, an onboard sensor on the drone is able to produce 3D maps&#8230; <a href="https://www.geekwire.com/2023/brinc-delivers-first-lemur-2-drones-to-u-s-public-safety-agencies/">Read More</a>

## Swimming from Seattle? Jeff Bezos’ big move brings us full circle from the mid-1990s
 - [https://www.geekwire.com/2023/swimming-from-seattle-jeff-bezos-big-move-brings-us-full-circle-from-the-mid-1990s](https://www.geekwire.com/2023/swimming-from-seattle-jeff-bezos-big-move-brings-us-full-circle-from-the-mid-1990s)
 - RSS feed: https://www.geekwire.com/feed/
 - date published: 2023-11-03T14:22:13+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="1070" src="https://cdn.geekwire.com/wp-content/uploads/2023/11/kinsley-seattle-1260x1070.jpg" width="1260" /><br />The news that Jeff Bezos is leaving Seattle feels like a bookend, of sorts — not a doomsday moment for the city, by any stretch, but perhaps the symbolic end of an era. Maybe even that&#8217;s going too far. But thinking about it this morning did inspire me to dig out this old issue of Newsweek magazine (above) from my storage bins. The cover story by Jerry Adler in the May 20, 1996, issue is like a glossy time capsule. I&#8217;ve kept it over the years because of the way it captures a key moment in time in our corner&#8230; <a href="https://www.geekwire.com/2023/swimming-from-seattle-jeff-bezos-big-move-brings-us-full-circle-from-the-mid-1990s/">Read More</a>

## Redfin ready for a ‘revolution’ after commissions verdict
 - [https://www.geekwire.com/2023/redfin-ready-for-a-revolution-after-commissions-verdict](https://www.geekwire.com/2023/redfin-ready-for-a-revolution-after-commissions-verdict)
 - RSS feed: https://www.geekwire.com/feed/
 - date published: 2023-11-03T05:01:42+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="840" src="https://cdn.geekwire.com/wp-content/uploads/2018/10/0975-Summit-Day-1-2018-1260x840.jpg" width="1260" /><br />[This story originally appeared on&#160;Real Estate News.] Redfin is on the &#8220;right side of history&#8221; in the wake of the verdict against the National Association of Realtors and others in the Sitzer/Burnett commissions lawsuit, CEO Glenn Kelman told investors during the company&#8217;s earnings call Thursday. Kelman said Redfin is uniquely positioned among brokerages to thrive in the face of &#8220;massive disruption,&#8221; in part because of its&#160;decision to break from NAR last month, but also because of its customer focus.&#160; &#8220;Redfin has long counseled our agents to support any fee a listing customer wants to pay a buyer&#8217;s agent,&#8221; Kelman said.&#8230; <a href="https://www.geekwire.com/2023/redfin-ready-for-a-revolution-after-commissions-verdict/">Read More</a>

## ‘Seattle, you will always have a piece of my heart’: Jeff Bezos leaving Amazon’s hometown for Miami
 - [https://www.geekwire.com/2023/seattle-you-will-always-have-a-piece-of-my-heart-jeff-bezos-leaving-amazons-hometown-for-miami](https://www.geekwire.com/2023/seattle-you-will-always-have-a-piece-of-my-heart-jeff-bezos-leaving-amazons-hometown-for-miami)
 - RSS feed: https://www.geekwire.com/feed/
 - date published: 2023-11-03T01:20:18+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="721" src="https://cdn.geekwire.com/wp-content/uploads/2020/06/bezos-close.jpg" width="1082" /><br />Amazon founder Jeff Bezos is moving away from Seattle, the city where he started an online bookseller that grew into a global tech giant. Bezos posted a throwback video on Instagram on Thursday to announce the news, in which he is seen showing off one of Amazon&#8217;s earliest offices. In the caption accompanying the post, Bezos says he wants to be closer to his parents and that as exciting as the move is, he calls it an &#8220;emotional decision,&#8221; adding, &#8220;Seattle, you will always have a piece of my heart.&#8221; Seattle has been my home since 1994 when I started&#8230; <a href="https://www.geekwire.com/2023/seattle-you-will-always-have-a-piece-of-my-heart-jeff-bezos-leaving-amazons-hometown-for-miami/">Read More</a>

