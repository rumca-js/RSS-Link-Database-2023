# Source:Squidmar Miniatures, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCDvZTWvHZPTxJ4K1yTD2a1g, language:en-US

## The most catastrophic success in Games Workshops history
 - [https://www.youtube.com/watch?v=Q2UxK3bvpBs](https://www.youtube.com/watch?v=Q2UxK3bvpBs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCDvZTWvHZPTxJ4K1yTD2a1g
 - date published: 2023-06-16 15:00:26+00:00

Head to https://squarespace.com/squidmar to save 10% off your first purchase of a website or domain using code squidmar

This week, we dive in to the fascinating and exciting history of one of games workshops most Successfull and catastrophic warhammer releases - Cursed City. 
_________________________

🏆 Support me on Patreon: https://www.patreon.com/squidmarminiatures 
🖌️ Squidmar Brushes & Exclusive miniatures: https://www.squidmar.com/latepledge 
👍 Squidmars website for full list of gear I use: https://www.squidmar.com/gear  
👕 Order Squidmar Merch: https://teespring.com/stores/squidmarminiatures

__________________________

🖌️EU/UK hobby store affiliate - Reference code for extra store credit: EMI7383 
https://elementgames.co.uk/paints-hobby-and-scenery/element-essentials/egaps/squidmar-miniatures?d=10425

_____________________

Amazon Affiliate Links to stuff i use(As an Amazon Associate I earn from qualifying purchases you do after following this link - at no cost to you):

Canon M50 (the cameras i use)
USA: https://amzn.to/2MWGIN9
UK: https://amzn.to/2PBlkyT
DE: https://amzn.to/2PA1Nio
CAN: https://amzn.to/2MTqaoT

Anycubic i3 Mega (the FDM printer i use)
USA: https://amzn.to/2FSRDly
UK: https://amzn.to/2xu0Hsz
DEUTSCHLAND: https://amzn.to/2JdquvX
CANADA: https://amzn.to/2YA95CW

HARDER STEENBECK EVOLUTION SILVERLINE (the Airbrush I use)
USA https://amzn.to/2ZO6HrI
UK https://amzn.to/2Ll5LGm
GERMANY https://amzn.to/2LmurOD
CANADA  https://amzn.to/2NGv3S2 

Phrozen Sonic Mini (the Resin printer I use):
Worldwide: https://phrozen3d.com/collections/resin-3d-printer-phrozen/products/phrozen-sonic-mini-resin-3d-printer?aff=43
USA Amazon: https://amzn.to/2FuFsyl 

Phrozen Sonic Mini 4k
Worldwide: https://phrozen3d.com/products/sonic-mini-4k-resin-3d-printer-phrozen?aff=43

_____________________

Emil On 
Instagram http://www.instagram.com/squidmarminiatures
facebook  http://www.facebook.com/ageofsquidmar
Twitter http://www.twitter.com/ageofsquidmar
Lukas instagram: https://www.instagram.com/seth_miniatures/

Videos edited by Maxime Dader & Viktor Westermark

