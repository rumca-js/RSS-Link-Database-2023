# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## Cyberpunk 2077 Phantom Liberty zaoferuje nowe romanse? CD Projekt RED odpowiada
 - [https://ithardware.pl/aktualnosci/cyberpunk_2077_phantom_liberty_zaoferuje_nowe_romanse_cd_projekt_red_odpowiada-27845.html](https://ithardware.pl/aktualnosci/cyberpunk_2077_phantom_liberty_zaoferuje_nowe_romanse_cd_projekt_red_odpowiada-27845.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-06-16 21:16:51+00:00

<img src="https://ithardware.pl/artykuly/min/27845_1.jpg" />            Cyberpunk 2077 oferuje opcję romansowania z kilkoma postaciami i choć może nie są one szczeg&oacute;lnie rozbudowane, to nie są też złe. Zapewne niekt&oacute;rzy zastanawiają się czy w dodatku Phatom Liberty V wda się z kimś w&nbsp;jakąś...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/cyberpunk_2077_phantom_liberty_zaoferuje_nowe_romanse_cd_projekt_red_odpowiada-27845.html">https://ithardware.pl/aktualnosci/cyberpunk_2077_phantom_liberty_zaoferuje_nowe_romanse_cd_projekt_red_odpowiada-27845.html</a></p>

## Alphabet, do którego należy Google przestrzega swoich pracowników przed chatbotami
 - [https://ithardware.pl/aktualnosci/alphabet_do_ktorego_nalezy_google_przestrzega_swoich_pracownikow_przed_chatbotami-27844.html](https://ithardware.pl/aktualnosci/alphabet_do_ktorego_nalezy_google_przestrzega_swoich_pracownikow_przed_chatbotami-27844.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-06-16 19:17:50+00:00

<img src="https://ithardware.pl/artykuly/min/27844_1.jpg" />            Sztuczna inteligencja towarzyszy nam w codziennym życiu i ma zar&oacute;wno zwolennik&oacute;w jak i przeciwnik&oacute;w. Alphabet najwyraźniej dostrzegł ciemniejszą stronę tego rozwiązania, bo wysyła swoim pracownikom e-maile ostrzegające przed...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/alphabet_do_ktorego_nalezy_google_przestrzega_swoich_pracownikow_przed_chatbotami-27844.html">https://ithardware.pl/aktualnosci/alphabet_do_ktorego_nalezy_google_przestrzega_swoich_pracownikow_przed_chatbotami-27844.html</a></p>

## Mercedes-Benz testuje ChatGPT w swoich samochodach. Jest to uzupełnienie asystenta głosowego
 - [https://ithardware.pl/aktualnosci/mercedes_benz_testuje_chatgpt_w_swoich_samochodach_jest_to_uzupelnienie_asystenta_glosowego-27843.html](https://ithardware.pl/aktualnosci/mercedes_benz_testuje_chatgpt_w_swoich_samochodach_jest_to_uzupelnienie_asystenta_glosowego-27843.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-06-16 16:54:01+00:00

<img src="https://ithardware.pl/artykuly/min/27843_1.jpg" />            ChatGPT to popularna technologia bazująca na sztucznej inteligencji mająca zar&oacute;wno zwolennik&oacute;w, jak i przeciwnik&oacute;w. Niezależnie od tego kolejne firmy testują najnowszą zdobycz technologiczną, a jedną z nich jest kultowy...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/mercedes_benz_testuje_chatgpt_w_swoich_samochodach_jest_to_uzupelnienie_asystenta_glosowego-27843.html">https://ithardware.pl/aktualnosci/mercedes_benz_testuje_chatgpt_w_swoich_samochodach_jest_to_uzupelnienie_asystenta_glosowego-27843.html</a></p>

## Microsoft odsyła Xboxa One na emeryturę. Xbox Game Studios przestanie tworzyć gry na starszą konsolę
 - [https://ithardware.pl/aktualnosci/microsoft_odsyla_xboxa_one_na_emeryture_xbox_game_studios_przestanie_tworzyc_gry_na_starsza_konsole-27842.html](https://ithardware.pl/aktualnosci/microsoft_odsyla_xboxa_one_na_emeryture_xbox_game_studios_przestanie_tworzyc_gry_na_starsza_konsole-27842.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-06-16 15:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/27842_1.jpg" />            Xbox Series X i S są dostępne od blisko trzech lat, nic więc dziwnego, że gier na Xboxa One powstaje coraz mniej. Teraz z wydawania produkcji&nbsp;Xbox Game Studios na ten sprzęt rezygnuje Microsoft. Zapewne w ślad za firmą z Redmond podążą...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/microsoft_odsyla_xboxa_one_na_emeryture_xbox_game_studios_przestanie_tworzyc_gry_na_starsza_konsole-27842.html">https://ithardware.pl/aktualnosci/microsoft_odsyla_xboxa_one_na_emeryture_xbox_game_studios_przestanie_tworzyc_gry_na_starsza_konsole-27842.html</a></p>

## Patriot zapowiada VP4300 Lite – wydajny dysk SSD na PCIe 4.0 x4
 - [https://ithardware.pl/aktualnosci/patriot_zapowiada_vp4300_lite_wydajny_dysk_ssd_na_pcie_4_0_x4-27841.html](https://ithardware.pl/aktualnosci/patriot_zapowiada_vp4300_lite_wydajny_dysk_ssd_na_pcie_4_0_x4-27841.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-06-16 14:04:20+00:00

<img src="https://ithardware.pl/artykuly/min/27841_1.jpg" />            Patriot Memory, czyli czołowy producent pamięci RAM, dysk&oacute;w SSD, przenośnych nośnik&oacute;w danych i peryferi&oacute;w komputerowych dla graczy ogłasza, że rozszerza swoją ofertę wysokowydajnych dysk&oacute;w SSD o model VP4300 Lite,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/patriot_zapowiada_vp4300_lite_wydajny_dysk_ssd_na_pcie_4_0_x4-27841.html">https://ithardware.pl/aktualnosci/patriot_zapowiada_vp4300_lite_wydajny_dysk_ssd_na_pcie_4_0_x4-27841.html</a></p>

## MSI przedstawia nowe zasilacze z serii MAG GL w standardzie ATX 3.0
 - [https://ithardware.pl/aktualnosci/msi_przedstawia_nowe_zasilacze_z_serii_mag_gl_w_standardzie_atx_3_0-27839.html](https://ithardware.pl/aktualnosci/msi_przedstawia_nowe_zasilacze_z_serii_mag_gl_w_standardzie_atx_3_0-27839.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-06-16 13:30:20+00:00

<img src="https://ithardware.pl/artykuly/min/27839_1.jpg" />            Standard ATX 3.0 nie jest jeszcze... standardem, ale coraz więcej producent&oacute;w stawia na najnowsze rozwiązanie. Do tej pory byliśmy jednak świadkami nieco droższych, bardziej flagowych modeli, ale jak widać na tym nie koniec, ponieważ MSI...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/msi_przedstawia_nowe_zasilacze_z_serii_mag_gl_w_standardzie_atx_3_0-27839.html">https://ithardware.pl/aktualnosci/msi_przedstawia_nowe_zasilacze_z_serii_mag_gl_w_standardzie_atx_3_0-27839.html</a></p>

## CORSAIR wprowadza nową mysz gamingową DARKSTAR WIRELESS
 - [https://ithardware.pl/aktualnosci/corsair_wprowadza_nowa_mysz_gamingowa_darkstar_wireless-27840.html](https://ithardware.pl/aktualnosci/corsair_wprowadza_nowa_mysz_gamingowa_darkstar_wireless-27840.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-06-16 13:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/27840_1.jpg" />            Firma CORSAIR prezentuje nową myszkę dla graczy z serii&nbsp;DARKSTAR WIRELESS. Urządzenie posiada m.in. 15 programowalnych przycisk&oacute;w, z kolei z boku umieszczono&nbsp;zestaw sześciu przycisk&oacute;w rozmieszczonych wok&oacute;ł centralnego...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/corsair_wprowadza_nowa_mysz_gamingowa_darkstar_wireless-27840.html">https://ithardware.pl/aktualnosci/corsair_wprowadza_nowa_mysz_gamingowa_darkstar_wireless-27840.html</a></p>

## be quiet! Dark Power Pro 13 1600 W -  test cyfrowego zasilacza ATX 3.0
 - [https://ithardware.pl/testyirecenzje/be_quiet_dark_power_pro_13_1600_w_test_cyfrowego_zasilacza_atx_3_0-27787.html](https://ithardware.pl/testyirecenzje/be_quiet_dark_power_pro_13_1600_w_test_cyfrowego_zasilacza_atx_3_0-27787.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-06-16 12:45:10+00:00

<img src="https://ithardware.pl/artykuly/min/27787_1.jpg" />            Test zasilacza be quiet! Dark Power PRO 13 1600 W

be quiet! sukcesywnie wprowadza jednostki w specyfikacji ATX 3.0 i tym razem zapraszam was na test flagowego zasilacza&nbsp;Dark Power Pro 13 o mocy 1600 W.&nbsp;Dark Power Pro 13&nbsp;1600 W to...
            <p>Pełna wersja strony <a href="https://ithardware.pl/testyirecenzje/be_quiet_dark_power_pro_13_1600_w_test_cyfrowego_zasilacza_atx_3_0-27787.html">https://ithardware.pl/testyirecenzje/be_quiet_dark_power_pro_13_1600_w_test_cyfrowego_zasilacza_atx_3_0-27787.html</a></p>

## Unia Europejska dalej męczy producentów smartfonów. I dobrze, bo sami wymienimy sobie baterię
 - [https://ithardware.pl/aktualnosci/unia_europejska_dalej_meczy_producentow_smartfonow_i_dobrze_bo_sami_wymienimy_sobie_baterie-27836.html](https://ithardware.pl/aktualnosci/unia_europejska_dalej_meczy_producentow_smartfonow_i_dobrze_bo_sami_wymienimy_sobie_baterie-27836.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-06-16 11:49:20+00:00

<img src="https://ithardware.pl/artykuly/min/27836_1.jpg" />            Unia Europejska przegłosowała nowe prawo dotyczące baterii. Na liście znalazła się informacja o stosowaniu w urządzeniach mobilnych baterii, kt&oacute;re mogą być łatwo wymienialne przez konsument&oacute;w. Czy oznacza to spore zmiany...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/unia_europejska_dalej_meczy_producentow_smartfonow_i_dobrze_bo_sami_wymienimy_sobie_baterie-27836.html">https://ithardware.pl/aktualnosci/unia_europejska_dalej_meczy_producentow_smartfonow_i_dobrze_bo_sami_wymienimy_sobie_baterie-27836.html</a></p>

## Moore Threads MTT S80 przetestowany. Wyciąga całe... 3 FPS
 - [https://ithardware.pl/aktualnosci/moore_threads_mtt_s80_test_wydajnosci-27835.html](https://ithardware.pl/aktualnosci/moore_threads_mtt_s80_test_wydajnosci-27835.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-06-16 11:11:20+00:00

<img src="https://ithardware.pl/artykuly/min/27835_1.jpg" />            Co się stanie, kiedy do dość dobrego hardware dorzucimy kompletnie niezoptymalizowane oprogramowanie? To, co się wydarzyło z kartą Moore Threads MTT S80. Japońska redakcja PC Watch przetestowała nową kartę graficzną...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/moore_threads_mtt_s80_test_wydajnosci-27835.html">https://ithardware.pl/aktualnosci/moore_threads_mtt_s80_test_wydajnosci-27835.html</a></p>

## Thermaltake przedstawia nowe zasilacze Toughpower z RGB o mocy do 1650 W
 - [https://ithardware.pl/aktualnosci/thermaltake_przedstawia_nowe_zasilacze_toughpower_z_rgb_o_mocy_do_1650_w-27834.html](https://ithardware.pl/aktualnosci/thermaltake_przedstawia_nowe_zasilacze_toughpower_z_rgb_o_mocy_do_1650_w-27834.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-06-16 10:31:00+00:00

<img src="https://ithardware.pl/artykuly/min/27834_1.jpg" />            Firma Thermaltake przygotowała nowe zasilacze dla tych, kt&oacute;rzy nie chcą się martwić, że zabraknie im mocy, a w dodatku lubią&nbsp;RGB. Nowa seria Toughpower składa się z dw&oacute;ch jednostek oferujących&nbsp;standard ATX 3.0 i...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/thermaltake_przedstawia_nowe_zasilacze_toughpower_z_rgb_o_mocy_do_1650_w-27834.html">https://ithardware.pl/aktualnosci/thermaltake_przedstawia_nowe_zasilacze_toughpower_z_rgb_o_mocy_do_1650_w-27834.html</a></p>

## Niemcy odmawiają dodatkowych dotacji dla fabryk Intela
 - [https://ithardware.pl/aktualnosci/niemcy_odmawiaja_dodatkowych_dotacji_dla_fabryk_intela-27838.html](https://ithardware.pl/aktualnosci/niemcy_odmawiaja_dodatkowych_dotacji_dla_fabryk_intela-27838.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-06-16 10:14:00+00:00

<img src="https://ithardware.pl/artykuly/min/27838_1.jpg" />            Intel planuje zbudować fabrykę układ&oacute;w scalonych w Magdeburgu, w Niemczech. Niemiecka agencja prasowa DPA donosi, że Niemcy zadeklarowały pomoc finansową w wysokości 6,8 miliarda euro (7,3 miliarda dolar&oacute;w), podczas gdy Intel domaga...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/niemcy_odmawiaja_dodatkowych_dotacji_dla_fabryk_intela-27838.html">https://ithardware.pl/aktualnosci/niemcy_odmawiaja_dodatkowych_dotacji_dla_fabryk_intela-27838.html</a></p>

## Intel wchodzi do Polski. Inwestycja ma wynieść 4,6 miliarda dolarów
 - [https://ithardware.pl/aktualnosci/intel_wchodzi_do_polski_inwestycja_ma_wyniesc_4_6_miliarda_dolarow-27837.html](https://ithardware.pl/aktualnosci/intel_wchodzi_do_polski_inwestycja_ma_wyniesc_4_6_miliarda_dolarow-27837.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-06-16 09:47:50+00:00

<img src="https://ithardware.pl/artykuly/min/27837_1.jpg" />            Intel zapowiedział właśnie, że planuje wybudować pod Wrocławiem Zakład Integracji i Testowania P&oacute;łprzewodnik&oacute;w. Amerykański gigant ma zamiar wpompować u nas 4,6 miliarda dolar&oacute;w.

Na Dolnym Śląsku, a dokładnie w...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/intel_wchodzi_do_polski_inwestycja_ma_wyniesc_4_6_miliarda_dolarow-27837.html">https://ithardware.pl/aktualnosci/intel_wchodzi_do_polski_inwestycja_ma_wyniesc_4_6_miliarda_dolarow-27837.html</a></p>

## Przyszłe iPhony mogą być znacznie wytrzymalsze. Apple myśli o połączeniu plastiku, ceramiki i metalu
 - [https://ithardware.pl/aktualnosci/przyszle_iphony_moga_byc_znacznie_wytrzymalsze_apple_mysli_o_polaczeniu_plastiku_ceramiki_i_metalu-27832.html](https://ithardware.pl/aktualnosci/przyszle_iphony_moga_byc_znacznie_wytrzymalsze_apple_mysli_o_polaczeniu_plastiku_ceramiki_i_metalu-27832.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-06-16 09:14:10+00:00

<img src="https://ithardware.pl/artykuly/min/27832_1.jpg" />            Firma Apple otrzymała patent na rozwiązanie, kt&oacute;re może znacząco poprawić wytrzymałość obudowy w przyszłych iPhonach. Zamiast wykorzystywać zalety tylko jednego z popularnych surowc&oacute;w i godzić się jednocześnie na jego wady,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/przyszle_iphony_moga_byc_znacznie_wytrzymalsze_apple_mysli_o_polaczeniu_plastiku_ceramiki_i_metalu-27832.html">https://ithardware.pl/aktualnosci/przyszle_iphony_moga_byc_znacznie_wytrzymalsze_apple_mysli_o_polaczeniu_plastiku_ceramiki_i_metalu-27832.html</a></p>

## 12VHPWR to niebezpieczeństwo pożarowe. Teraz również po stronie samego zasilacza
 - [https://ithardware.pl/aktualnosci/12vhpwr_to_niebezpieczenstwo_pozarowe_po_stronie_samego_zasilacza-27833.html](https://ithardware.pl/aktualnosci/12vhpwr_to_niebezpieczenstwo_pozarowe_po_stronie_samego_zasilacza-27833.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-06-16 08:08:40+00:00

<img src="https://ithardware.pl/artykuly/min/27833_1.jpg" />            Wiadomości o palących, a w zasadzie topiących się wtyczkach i gniazdach 12VHPWR było tak wiele, że nam samym już ciężko się w tym wszystkim połapać. Wcześniej dotyczyły one jednak tylko kart graficznych NVIDIA GeForce, ale teraz problem...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/12vhpwr_to_niebezpieczenstwo_pozarowe_po_stronie_samego_zasilacza-27833.html">https://ithardware.pl/aktualnosci/12vhpwr_to_niebezpieczenstwo_pozarowe_po_stronie_samego_zasilacza-27833.html</a></p>

## Starfield to gra Bethesdy z najmniejszą liczbą błędów. Twierdzi Microsoft
 - [https://ithardware.pl/aktualnosci/starfield_to_gra_bethesdy_z_najmniejsza_liczba_bledow_twierdzi_microsoft-27831.html](https://ithardware.pl/aktualnosci/starfield_to_gra_bethesdy_z_najmniejsza_liczba_bledow_twierdzi_microsoft-27831.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-06-16 07:25:10+00:00

<img src="https://ithardware.pl/artykuly/min/27831_1.jpg" />            Na ostatnich gamingowych wydarzeniach poznaliśmy wiele szczeg&oacute;ł&oacute;w odnośnie Starfield. Teraz Microsoft twierdzi, że produkcja ta okraszona jest najmniejszą liczbą błęd&oacute;w ze wszystkich gier Bethesdy.

Bethesda to...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/starfield_to_gra_bethesdy_z_najmniejsza_liczba_bledow_twierdzi_microsoft-27831.html">https://ithardware.pl/aktualnosci/starfield_to_gra_bethesdy_z_najmniejsza_liczba_bledow_twierdzi_microsoft-27831.html</a></p>

