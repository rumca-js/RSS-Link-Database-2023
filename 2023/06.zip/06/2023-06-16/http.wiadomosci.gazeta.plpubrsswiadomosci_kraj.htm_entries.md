# Source:wiadomości.gazeta.pl, URL:http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm, language:pl-PL

## Tajemnicze zaginięcie Polki na greckiej wyspie Kos. W sprawę zamieszanych jest pięciu obcokrajowców
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29878040,27-letnia-polka-zaginela-na-greckiej-wyspie-kos-w-sprawe-zamieszanych.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29878040,27-letnia-polka-zaginela-na-greckiej-wyspie-kos-w-sprawe-zamieszanych.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-06-16 18:57:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/34/7e/1c/z29878324M,27-letnia-Anastazja-Rubinska-zaginela-na-greckiej-.jpg" vspace="2" />Anastazja Rubińska zaginęła w poniedziałek w turystycznej miejscowości Marmari na wyspie Kos. 27-latka pracowała w miejscowym hotelu. Zaginięcie kobiety zgłosił jej chłopak, który jako ostatni kontaktował się z Polką. Grecka policja zatrzymała w sprawie pięciu obcokrajowców. Wśród nich znajdował się 32-letni obywatel Bangladeszu, który został aresztowany pod zarzutem porwania kobiety.

## Burze i intensywne opady deszczu w Polsce. Alerty IMGW, ostrzega też RCB
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29877595,burze-i-intensywne-opady-deszczu-w-polsce-alerty-imgw-ostrzega.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29877595,burze-i-intensywne-opady-deszczu-w-polsce-alerty-imgw-ostrzega.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-06-16 16:05:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/20/7e/1c/z29877792M,Deszcz-w-Polsce-w-ciagu-najblizszych-trzech-dni.jpg" vspace="2" />Nad niektórymi regionami Polski rozwinęły się burze - wynika z informacji IMGW. W wielu regionach możliwe będą też intensywne opady deszczu. Dla których regionów wydano ostrzeżenia pirwszego stopnia?

## Strzelanina w Szczecinie. Ofiara dzwoniła wcześniej na policję. "Mówiła, że jest ścigana"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29877215,strzelanina-w-szczecinie-ofiara-dzwonila-wczesniej-na-policje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29877215,strzelanina-w-szczecinie-ofiara-dzwonila-wczesniej-na-policje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-06-16 14:09:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/9b/7d/1c/z29874587M,Strzelanina-w-jednym-z-domow-wielorodzinnych-przy-.jpg" vspace="2" />Kobieta, która zginęła w czasie strzelaniny w Szczecinie, wcześniej zadzwoniła na policję - poinformował Mariusz Ciarka z KGP. - Wzywała pomocy. Mówiła, że jest ścigana przez mężczyznę - podkreślił funkcjonariusz.

## Luizjana. 28-latka udawała 17-latkę, aby móc chodzić do szkoły. Chciała nauczyć się angielskiego
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29876844,luizjana-28-latka-udawala-17-latke-aby-moc-chodzic-do-szkoly.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29876844,luizjana-28-latka-udawala-17-latke-aby-moc-chodzic-do-szkoly.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-06-16 13:25:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/7c/55/1c/z29709692M,Wolne-od-szkoly--zdjecie-ilustracyjne-.jpg" vspace="2" />Policja z Luizjany aresztowała 28-latkę, która przez cały rok uczęszczała do liceum. Kobieta wraz z matką sfałszowały dokumenty, z którym miało wynikać, że ma ona nie 28, a 17 lat. Zatrzymana zapisała się do szkoły, bo chciała nauczyć się języka angielskiego.

## Lewica z pakietem postulatów "Bezpieczna Polka". Apelują o poparcie opozycji jeszcze przed wyborami
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29876382,lewica-z-pakietem-postulatow-bezpieczna-polka-apeluja-o-poparcie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29876382,lewica-z-pakietem-postulatow-bezpieczna-polka-apeluja-o-poparcie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-06-16 13:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a1/7e/1c/z29876897M,Konferencja-prasowa-w-Senacie-w-sprawie-Pakietu-Le.jpg" vspace="2" />- Polki chcą po prostu normalnie żyć, chcą być bezpieczne - mówiła w piątek na konferencji prasowej w Sejmie Agnieszka Dziemianowicz-Bąk. Razem z innymi posłankami Lewicy przedstawiła pakiet postulatów i ustaw "Bezpieczna Polka" i zaapelowała o poparcie go przez demokratyczną opozycję jeszcze przed wyborami.

## Jedzenie niemytych truskawek może źle się skończyć. Tych kolistych punktów nie powinno być w mózgu
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29876758,jedzenie-niemytych-truskawek-moze-zle-sie-skonczyc-tych-kolistych.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29876758,jedzenie-niemytych-truskawek-moze-zle-sie-skonczyc-tych-kolistych.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-06-16 12:55:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/fc/7e/1c/z29876988M,Rezonans-magnetyczny-mozgu-pacjenta-z-bablowica.jpg" vspace="2" />Sezon na truskawki zaczął się już w pełni, a ceny owoców na straganach są coraz niższe. To wszystko zachęca do spożywania tych zdrowych i smacznych owoców. Zawsze jednak należy pamiętać o wcześniejszym umyciu truskawek. Dlaczego to takie ważne, wyjaśnia zdjęcie udostępnione przez ratownika medycznego.

## Są łyse, skrzydlate i mogą spadać z nieba w upały. Jak zaopiekować się oseskiem nietoperza?
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29876136,sa-lyse-skrzydlate-i-moga-spadac-z-nieba-w-upaly-jak-zaopiekowac.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29876136,sa-lyse-skrzydlate-i-moga-spadac-z-nieba-w-upaly-jak-zaopiekowac.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-06-16 12:53:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c5/7e/1c/z29876677M,Mlode-nietoperzy-moga-spadac-ze-stropow-w-upaly.jpg" vspace="2" />Towarzystwo Ochrony Przyrody "Salamandra" przekazało, że w przyszłym tygodniu w Polsce mogą wystąpić upały, które wpłyną na zachowanie pewnej grupy ssaków. Chodzi o młode nietoperzy, które przez wysoką temperaturę mogą wypadać spod dachów budynków. Jak się zachować w tej sytuacji? Co zrobić ze znalezionym oseskiem?

## Zabójstwo matki sześciorga dzieci. 35-letniego podejrzanego złapano po 19 latach. Po raz drugi
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29876118,podejrzany-o-zabojstwo-zlapany-wypuszczony-i-znow-zlapany.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29876118,podejrzany-o-zabojstwo-zlapany-wypuszczony-i-znow-zlapany.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-06-16 11:49:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ea/7d/1c/z29876202M,Policja-zatrzymala-podejrzanego-o-zabojstwo-sprzed.jpg" vspace="2" />Policja ujęła podejrzanego o morderstwo sprzed 19 lat. To już drugie zatrzymanie 35-latka. Dwa lata temu, decyzją sądu, mężczyznę jednak wypuszczono. Rozwiązanie sprawy było możliwe m.in. dzięki pomocy policjantów z gdańskiego Archiwum X.

## Posłanka KO pomyliła się podczas głosowania przeciwko "paktowi migracyjnemu". Kaleta ją wykpił
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29875518,poslanka-ko-pomylila-sie-podczas-glosowania-przeciwko-paktowi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29875518,poslanka-ko-pomylila-sie-podczas-glosowania-przeciwko-paktowi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-06-16 11:08:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/3f/7e/1c/z29876287M,Kamila-Gasiuk-Pihowicz.jpg" vspace="2" />Kamila Gasiuk-Pihowicz posłanka KO podczas głosowania omyłkowo zagłosowała za sprzeciwem wobec unijnego "paktu migracyjnego", o czym poinformowała w mediach społecznościowych. Z wpisu polityczki w odpowiedzi zadrwił Sebastian Kaleta, wiceminister sprawiedliwości

## Strzelanina w Szczecinie. Sąsiedzi o parze z mieszkania: Pojawiali się od czasu do czasu
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29875576,strzelanina-w-szczecinie-sasiedzi-o-parze-z-mieszkania-pojawiali.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29875576,strzelanina-w-szczecinie-sasiedzi-o-parze-z-mieszkania-pojawiali.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-06-16 10:34:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/08/7d/1c/z29873928M,Akcja-policji-na-ul--Kasjopei-w-Szczecinie--Ktos-s.jpg" vspace="2" />Prokuratura potwierdziła, że w czwartek na ulicy Kasjopei w Szczecinie odkryto ciała trzech dorosłych osób. Joanna Biranowska-Sochalska z Prokuratury Okręgowej w Szczecinie przekazała w rozmowie z TVN24, że zlecono sekcję zwłok ofiar. Poinformowała także, w jakim kierunku prowadzone jest postępowanie w sprawie.

## Rosyjska rakieta pod Bydgoszczą. Błaszczak oskarżał, ale nie zawiadomił służb. "Nie ma potrzeby"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29875727,rosyjska-rakieta-pod-bydgoszcza-blaszczak-oskarzal-ale-nie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29875727,rosyjska-rakieta-pod-bydgoszcza-blaszczak-oskarzal-ale-nie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-06-16 10:05:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/3a/5f/1c/z29752890M,Minister-obrony-w-rzadzie-PiS-Mariusz-Blaszczak-po.jpg" vspace="2" />Mariusz Błaszczak publicznie oskarżył dowódcę operacyjnego rodzajów sił zbrojnych po tym, jak rosyjska rakieta spadła w lesie pod Bydgoszczą. Z ustaleń dziennikarza RMF FM wynika, że do tej pory minister obrony nie powiadomił prokuratury o możliwości popełnienia przestępstwa zaniechania obowiązków.

## Incydent na Okęciu. Delegacja RPA utknęła na lotnisku w Warszawie. Wszystko przez broń
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29875655,niespotykana-sytuacja-na-okeciu-delegacja-rpa-od-kilkunastu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29875655,niespotykana-sytuacja-na-okeciu-delegacja-rpa-od-kilkunastu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-06-16 10:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/4d/7d/1c/z29875789M,Delegacja-RPA-utknela-na-Okeciu.jpg" vspace="2" />Delegacja RPA od kilkunastu godzin tkwi w samolocie na płycie lotniska Chopina w Warszawie. Nie mogą opuścić samolotu, który ma odlecieć z Okęcia dopiero po południu. Pasażerowie mają przy sobie broń bez stosownych pozwoleń, brakuje im też innych dokumentów, które pozwoliłyby opuścić pokład samolotu.

## Radosław M., b. dziennikarz TVP, staje przed sądem oskarżony o czyny pedofilskie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29874553,radoslaw-m-b-dziennikarz-tvp-staje-przed-sadem-oskarzony.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29874553,radoslaw-m-b-dziennikarz-tvp-staje-przed-sadem-oskarzony.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-06-16 08:14:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d8/7d/1c/z29874648M,Sad--zdjecie-ilustracyjne-.jpg" vspace="2" />Radosław M., były dziennikarz TVP, Polskiego Radia, Superstacji, po raz kolejny ma stanąć w piątek przed warszawskim sądem. Jest oskarżony o czyny pedofilskie, m.in. seksualne wykorzystanie osoby poniżej 15 r. ż. i utrwalanie treści pornograficznych z jej udziałem. Mężczyzna od września ubiegłego roku przebywa w areszcie, grozi mu 12 lat więzienia.

## Prokuratura od zadań specjalnych zajmuje się właścicielką Cafe Kulturalna. Zarzuty o defraudację
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29874772,prokuratura-od-zadan-specjalnych-zajmuje-sie-wlascicielka-cafe.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29874772,prokuratura-od-zadan-specjalnych-zajmuje-sie-wlascicielka-cafe.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-06-16 07:52:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/47/fe/1b/z29354567M,Palac-Kultury-i-Nauki.jpg" vspace="2" />Szczecińska prokuratura, która zajmuje się sprawami z politycznym tłem, aresztowała Agnieszkę Ł. właścicielkę Cafe Kulturalna. Zarzuty dotyczą dotacji, które miała zdefraudować fundacja założona przez kobietę w celu pomocy uchodźcom z Ukrainy. Jak przekazuje "Gazeta Wyborcza", chodzi o 7 mln zł.

## Magdalena Ogórek "największą hipokrytką TVP"? PO o tym, że "w sieci nic nie ginie" [WIDEO]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29874599,magdalena-ogorek-najwieksza-hipokrytka-tvp-po-o-prorosyjskich.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29874599,magdalena-ogorek-najwieksza-hipokrytka-tvp-po-o-prorosyjskich.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-06-16 06:41:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/9a/5e/1a/z27649946M,Magdalena-Ogorek.jpg" vspace="2" />Platforma Obywatelska opublikowała nagranie, które ma być odpowiedzią na serial "Reset" TVP. Politycy skupili się na jednej z "twarzy" Telewizji Polskiej - Magdalenie Ogórek. Byłej kandydatce SLD na stanowisko prezydenta wypomniano to, jak nawoływała do dialogu z Rosją. Na jednym z rosyjskich portali można do tej pory znaleźć materiał o tym, dlaczego Ogórek nie udało się wygrać wyborów. Wśród powodów wymieniono, że "jest zbyt atrakcyjna" oraz "odrzuca rusofobiczny kurs w rusofobicznej Polsce".

