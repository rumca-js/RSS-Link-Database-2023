# Source:Forsal.pl, URL:https://forsal.pl/.feed, language:pl-PL

## Wróbel: Zmiany bez dialogu [FELIETON]
 - [https://forsal.pl/gospodarka/polityka/artykuly/8734711,wrobel-zmiany-bez-dialogu-felieton.html](https://forsal.pl/gospodarka/polityka/artykuly/8734711,wrobel-zmiany-bez-dialogu-felieton.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 19:53:46+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ki2ktkuTURBXy8yYTQxMjIwNy04MWY5LTRmMjctYTYyNS1jNjhlNTg2YmQxMDYuanBlZ5GTBc0BHcyg" />Tak, chciałbym Polski, w której opozycja w sprawach edukacji najpierw dogaduje się między sobą, a potem występuje publicznie – a nie najpierw występu je publicznie, a potem wyjaśnia, dlaczego się nie dogaduje. A jeszcze bardziej chciałbym Polski, w której większość sejmowa rozmawia o edukacji z mniejszością sejmową, bez względu na temperaturę konfliktów politycznych na wielu innych polach. Wygląda na to, że na taką Polskę to jeszcze sobie poczekam.

## Kręta droga do autostrad. Budowa najszybszych tras na dobre ruszyła z wejściem Polski do UE
 - [https://forsal.pl/transport/aktualnosci/artykuly/8734687,kreta-droga-do-autostrad-budowa-najszybszych-tras-na-dobre-ruszyla-z.html](https://forsal.pl/transport/aktualnosci/artykuly/8734687,kreta-droga-do-autostrad-budowa-najszybszych-tras-na-dobre-ruszyla-z.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 19:53:13+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/q3RktkuTURBXy80ODhkNjY3NS1iZDAyLTQxZjEtOWUyYy1kODU2YzQxODhiYzIuanBlZ5GTBc0BHcyg" />Budowa najszybszych tras na dobre ruszyła dopiero wraz z wejściem Polski do UE. Wcześniej rządy powierzały ich realizację koncesjonariuszom. Teraz nie wyklucza się ich wywłaszczenia.

## "Frankowicze" kontra banki. Co spowoduje wyrok TSUE?
 - [https://forsal.pl/finanse/aktualnosci/artykuly/8734679,frankowicze-kontra-banki-co-spowoduje-wyrok-tsue.html](https://forsal.pl/finanse/aktualnosci/artykuly/8734679,frankowicze-kontra-banki-co-spowoduje-wyrok-tsue.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 19:52:35+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/CJdktkuTURBXy9kMWM4ZGExNi1iOWYxLTQ5NzQtOTczYi01MjEyNzYzZDYwYzcuanBlZ5GTBc0BHcyg" />Czy banki położą uszy po sobie i będą grzecznie zwracać klientom niesłusznie pobrane odsetki, przy okazji dokładając wynagrodzenie za nienależne korzystanie z kapitału? Oczywiście, że nie.

## Co takiego się stało, że złoty jest tak pewny siebie? [OPINIA]
 - [https://forsal.pl/finanse/waluty/artykuly/8734659,co-takiego-sie-stalo-ze-zloty-jest-tak-pewny-siebie-opinia.html](https://forsal.pl/finanse/waluty/artykuly/8734659,co-takiego-sie-stalo-ze-zloty-jest-tak-pewny-siebie-opinia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 19:52:08+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/-z5ktkuTURBXy8yNDIyY2Q5My1kZTBlLTRjMWItYjA4ZC0yMmFlOTJjZWZmNTQuanBlZ5GTBc0BHcyg" />W maju zeszłego roku polska waluta była jedną z najsłabszych na świecie. Rok później złoty znacząco się umocnił. Cóż takiego się stało, że polski pieniądz jest tak pewny siebie?

## Rosja ma się coraz lepiej na froncie informacyjno-propagandowym [OPINIA]
 - [https://forsal.pl/swiat/rosja/artykuly/8734667,rosja-ma-sie-coraz-lepiej-na-froncie-informacyjno-propagandowym-opini.html](https://forsal.pl/swiat/rosja/artykuly/8734667,rosja-ma-sie-coraz-lepiej-na-froncie-informacyjno-propagandowym-opini.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 19:51:34+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/kISktkuTURBXy8zOWI0ZTIyOC0zYjhiLTRjM2MtOWQ4Zi1hMzkxYjRkYTFkOWUuanBlZ5GTBc0BHcyg" />Rosja przegrywa tam, gdzie do gry wchodzą czołgi, karabiny i żołnierze. Za to na froncie informacyjno -propagandowym po krótkotrwałym załamaniu ma się znów coraz lepiej. Nie bez pomocy Zachodu.

## Tel Awiw w pierwszej piątce najlepszych miejsc dla rozwoju startupów i innowacji
 - [https://forsal.pl/gospodarka/inwestycje/artykuly/8735267,tel-awiw-w-pierwszej-piatce-najlepszych-miejsc-dla-rozwoju-startupow-i.html](https://forsal.pl/gospodarka/inwestycje/artykuly/8735267,tel-awiw-w-pierwszej-piatce-najlepszych-miejsc-dla-rozwoju-startupow-i.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 19:49:25+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/a2-ktkuTURBXy8zNTRlYTAzYi1hNWQ2LTQ2ZDYtOWJlNC05MjgwNTYwNDY0YWQuanBlZ5GTBc0BHcyg" />Tel Awiw awansował o dwa miejsca - na piątą pozycję, w corocznym rankingu najbardziej atrakcyjnych na świecie ekosystemów dla rozwoju startupów i innowacji, przeprowadzanym przez amerykańską firmę badawczą Startup Genome.

## Opozycja apeluje o embargo na rosyjski gaz LPG
 - [https://forsal.pl/biznes/energetyka/artykuly/8735260,opozycja-apeluje-o-embargo-na-rosyjski-gaz-lpg.html](https://forsal.pl/biznes/energetyka/artykuly/8735260,opozycja-apeluje-o-embargo-na-rosyjski-gaz-lpg.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 19:40:05+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/LIDktkuTURBXy83OWZlZDcxYS03NTcxLTQwMDYtOWQxNi0wMzUzYmQ3Y2ZiNzkuanBlZ5GTBc0BHcyg" />Politycy opozycji zaapelowali w piątek do premiera Mateusza Morawieckiego o poparcie ich projektu ws. embarga na rosyjski gaz LPG. Jeśli podlegli panu urzędnicy lekceważą pana deklaracje w ważnych dla Polski sprawach zbudujmy porozumienie ponad podziałami; uwolnijmy Polskę od rosyjskiego gazu - mówili.

## Jastrzębski: Wyrok TSUE nie doprowadzi do upadku banków
 - [https://forsal.pl/biznes/bankowosc/artykuly/8735258,jastrzebski-wyrok-tsue-nie-doprowadzi-do-upadku-bankow.html](https://forsal.pl/biznes/bankowosc/artykuly/8735258,jastrzebski-wyrok-tsue-nie-doprowadzi-do-upadku-bankow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 19:20:14+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/wjSktkuTURBXy9iY2Q4MDUxMy1kMWQzLTQ5MTEtYjA4My0wYTlmMGRhMGU3ZDguanBlZ5GTBc0BHcyg" />Komisja Nadzoru Finansowego nie zakłada scenariusza upadku banku, który byłby wywołany czwartkowymi wyrokami Trybunału Sprawiedliwości Unii Europejskiej dotyczącymi frankowiczów - wynika z piątkowej wypowiedzi przewodniczącego KNF Jacka Jastrzębskiego na antenie RMF FM.

## Biały Dom krytykuje Putina: Nuklearna retoryka jest wysoce nieodpowiedzialna
 - [https://forsal.pl/swiat/usa/artykuly/8735257,bialy-dom-krytykuje-putina-nuklearna-retoryka-jest-wysoce-nieodpowied.html](https://forsal.pl/swiat/usa/artykuly/8735257,bialy-dom-krytykuje-putina-nuklearna-retoryka-jest-wysoce-nieodpowied.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 19:11:50+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/7kQktkuTURBXy8wYjBiMDcyOC1mMDEyLTRiZTYtYjY0NS0wOTliNmRiZDg5NTIuanBlZ5GTBc0BHcyg" />Nuklearna retoryka Władimira Putina jest &quot;wysoce nieodpowiedzialna&quot; - oświadczyła w piątek wicerzeczniczka Białego Domu Olivia Dalton, odnosząc się do słów rosyjskiego prezydenta podczas forum ekonomicznego w Petersburgu. Szef dyplomacji USA Antony Blinken stwierdził natomiast, że nie widzi potrzeby zmiany rozmieszczenia amerykańskiej broni jądrowej.

## MON: 6 kolejnych koreańskich czołgów przypłynęło do kraju
 - [https://forsal.pl/gospodarka/inwestycje/artykuly/8735195,mon-6-kolejnych-koreanskich-czolgow-przyplynelo-do-kraju.html](https://forsal.pl/gospodarka/inwestycje/artykuly/8735195,mon-6-kolejnych-koreanskich-czolgow-przyplynelo-do-kraju.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 18:39:51+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/nfwktkuTURBXy8yOWZjN2U0Mi1iYzZlLTQ1MGItYTQ1YS05YTBiMDlhYzA5NzIuanBlZ5GTBc0BHcyg" />Sześć kolejnych czołgów K2 zostało dostarczonych z Korei Południowej – poinformowało w piątek MON.

## Tama na Dnieprze została zniszczona materiałami wybuchowymi "prawdopodobnie" przez Rosjan
 - [https://forsal.pl/swiat/ukraina/artykuly/8735193,tama-na-dnieprze-zostala-zniszczona-materialami-wybuchowymi-prawdopod.html](https://forsal.pl/swiat/ukraina/artykuly/8735193,tama-na-dnieprze-zostala-zniszczona-materialami-wybuchowymi-prawdopod.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 18:33:03+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/15PktkuTURBXy80NmY4M2I4Zi1hMzRjLTQ2NzAtOWI0OS0xMGEzMzAwYjcyYWQuanBlZ5GTBc0BHcyg" />Jest &quot;wysoce prawdopodobne&quot;, że za wysadzenie tamy na Dnieprze odpowiada Rosja - wynika ze wstępnych ustaleń zespołu międzynarodowych ekspertów prawnych z Global Rights Compliance, wspierających śledztwo ukraińskiego Prokuratora Generalnego. Zawalenie się tamy w Nowej Kachowce &quot;zostało spowodowane przez wcześniej rozmieszczone materiały wybuchowe umieszczone w krytycznych punktach konstrukcji tamy&quot; - ocenili eksperci cytowani przez CNN.

## Skurkiewicz: W 2022 roku wydatki na obronność stanowiły 2,22 proc. PKB
 - [https://forsal.pl/artykuly/8735192,skurkiewicz-w-2022-roku-wydatki-na-obronnosc-stanowily-222-proc-pkb.html](https://forsal.pl/artykuly/8735192,skurkiewicz-w-2022-roku-wydatki-na-obronnosc-stanowily-222-proc-pkb.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 18:29:50+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ddLktkuTURBXy9jYzRlNDY1Zi1mZGRiLTQ2NGUtYjMyNy0yODFiNDgwZDVjZGMuanBlZ5GTBc0BHcyg" />Wydatki obronne w ubiegłym roku wyniosły ponad 57 mld zł, co stanowiło 2,22 proc. PKB – poinformował w piątek sejmową komisję obrony wiceszef MON Wojciech Skurkiewicz.

## Lotnisko Radom odprawiło 15-tysięcznego pasażera. Uruchomiono bezpośrednie połączenie z Grecją
 - [https://forsal.pl/transport/lotnictwo/artykuly/8735189,lotnisko-radom-odprawilo-15-tysiecznego-pasazera-uruchomiono-bezposre.html](https://forsal.pl/transport/lotnictwo/artykuly/8735189,lotnisko-radom-odprawilo-15-tysiecznego-pasazera-uruchomiono-bezposre.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 18:12:36+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/icgktkuTURBXy9mNzkzZmYyYS1mODg1LTRjNmUtYmQxMi1jY2M2NDUxM2U3ZTUuanBlZ5GTBc0BHcyg" />15 tys. pasażerów odprawiło do tej pory lotnisko w Radomiu. W piątek z radomskiego portu wyleciał pierwszy samolot do Grecji. To czwarte, po Rzymie, Paryżu i Tiranie, regularne połączenie z Radomia – poinformowała rzeczniczka Polskich Portów Lotniczych Anna Dermont.

## Brandenburgia i Saksonia chcą walczyć z wewnątrzunijną migracją. Domagają się kontroli na granicy z Polską
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8735187,brandenburgia-i-saksonia-chca-walczyc-z-wewnatrzunijna-migracja-domag.html](https://forsal.pl/swiat/unia-europejska/artykuly/8735187,brandenburgia-i-saksonia-chca-walczyc-z-wewnatrzunijna-migracja-domag.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 17:54:22+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/7DaktkuTURBXy84N2IwOTI0MC1lOGI2LTRmOWMtOWI5ZC1kNGJiY2VkMjI0MTYuanBlZ5GTBc0BHcyg" />Minister spraw wewnętrznych Brandenburgii Michael Stuebgen powtórzył swoje żądanie wprowadzenia kontroli na granicy z Polską. &quot;W ciągu tego roku już ponad 10 000 osób wjechało do Republiki Federalnej bez zezwolenia z Polski. Jest to wzrost o prawie 170 procent w porównaniu z rokiem poprzednim&quot;, stwierdził polityk w piątek.

## Zachód Francji nawiedziło trzęsienie ziemi o magnitudzie 5
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8735185,zachod-francji-nawiedzilo-trzesienie-ziemi-o-magnitudzie-5.html](https://forsal.pl/swiat/unia-europejska/artykuly/8735185,zachod-francji-nawiedzilo-trzesienie-ziemi-o-magnitudzie-5.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 17:43:36+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/XOMktkuTURBXy83NDcwY2RhOC05ZGViLTRlMjAtOTk5MC05ZjlmM2ZkMmVkZGYuanBlZ5GTBc0BHcyg" />Francję nawiedziło w piątek trzęsienie ziemi o magnitudzie 5. Hipocentrum wstrząsu było na głębokości 10 km - poinformowały niemieckie służby geologiczne GFZ.

## Misja afrykańskich polityków w Kijowie. Zełenski: Rozmowy z Kremlem tylko po wycofaniu rosyjskich wojsk z Ukrainy
 - [https://forsal.pl/swiat/ukraina/artykuly/8735182,misja-afrykanskich-politykow-w-kijowie-zelenski-rozmowy-z-kremlem-ty.html](https://forsal.pl/swiat/ukraina/artykuly/8735182,misja-afrykanskich-politykow-w-kijowie-zelenski-rozmowy-z-kremlem-ty.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 17:35:42+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/BVAktkuTURBXy8yMzNkZjliOC1kZmMwLTRhMDAtYWJkYi0yYzk0M2IwOTkxNjEuanBlZ5GTBc0BHcyg" />Rozmowy pokojowe z Rosją są możliwe tylko po całkowitym wycofaniu wojsk agresora z naszego kraju; pozwolenie na jakiekolwiek negocjacje teraz, gdy nasze ziemie są okupowane, skutkowałoby zamrożeniem wojny, czyli bólu i cierpienia - oznajmił prezydent Ukrainy Wołodymyr Zełenski po piątkowym spotkaniu w Kijowie z delegacją siedmiu państw Afryki.

## Michał Fijoł został prezesem spółki PLL LOT
 - [https://forsal.pl/transport/lotnictwo/artykuly/8735180,michal-fijol-zostal-prezesem-spolki-pll-lot.html](https://forsal.pl/transport/lotnictwo/artykuly/8735180,michal-fijol-zostal-prezesem-spolki-pll-lot.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 17:20:12+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/kv5ktkuTURBXy9lM2NhZmYxZC0wZGVmLTQ1ZjYtYjY4MC02ZWFiNDlkMjBjZGYuanBlZ5GTBc0BHcyg" />Rada nadzorcza PLL LOT powołała Michała Fijoła na prezesa spółki; od blisko siedmiu lat odpowiadał w zarządzie za sprawy handlowe - poinformował w piątek PAP narodowy przewoźnik.

## Tusk na poznańskim placu Wolności zaapelował o mocne wsparcie podczas kolejnych marszów i protestów
 - [https://forsal.pl/gospodarka/polityka/artykuly/8735177,tusk-na-poznanskim-placu-wolnosci-zaapelowal-o-mocne-wsparcie-podczas.html](https://forsal.pl/gospodarka/polityka/artykuly/8735177,tusk-na-poznanskim-placu-wolnosci-zaapelowal-o-mocne-wsparcie-podczas.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 17:08:28+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/dl-ktkuTURBXy85MjQ4NWVkMC0zNGEyLTQyNzItOTAxNC1jMDQ0OTBiM2I4YmIuanBlZ5GTBc0BHcyg" />W piątek późnym popołudniem rozpoczął się w Poznaniu wiec lidera PO Donalda Tuska. Spotkanie odbywa się na poznańskim placu Wolności, czyli w miejscu symbolicznym dla mieszkańców, gdzie w ostatnich latach odbywały się najliczniejsze demonstracje m.in. w obronie praw kobiet.

## Deutsche Bahn sprzedał autobusową część Arrivy. Spółka realizuje wiele połączeń w Polsce
 - [https://forsal.pl/transport/artykuly/8735173,deutsche-bahn-sprzedal-autobusowa-czesc-arrivy-spolka-realizuje-wiele-polaczen-w-polsce.html](https://forsal.pl/transport/artykuly/8735173,deutsche-bahn-sprzedal-autobusowa-czesc-arrivy-spolka-realizuje-wiele-polaczen-w-polsce.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 16:43:55+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/4atktkuTURBXy83YjcwM2RmMS1lYWU3LTRkNWQtYTAzZS04ODZhODIyMWI0MmIuanBlZ5GTBc0BHcyg" />Należąca dotychczas do niemieckiego państwowego przewoźnika kolejowego spółka Arriva Bus Transport Polska zmieniła właściciela. Będzie nim teraz fundusz inwestycyjny Mutares

## Gen. Lloyd wezwał Turcję do przyjęcia akcesji Szwecji do NATO
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8735167,gen-lloyd-wezwal-turcje-do-przyjecia-akcesji-szwecji-do-nato.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8735167,gen-lloyd-wezwal-turcje-do-przyjecia-akcesji-szwecji-do-nato.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 16:19:48+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/7P2ktkuTURBXy9jNDg4OGQyMi0zZDUyLTRmNmMtOTc4My1kZGZhMDljMmEzODcuanBlZ5GTBc0BHcyg" />Szef Pentagonu Lloyd Austin podczas swego pierwszego spotkania z nowym ministrem obrony Turcji Yasarem Gulerem, na marginesie sesji ministrów obrony krajów Sojuszu Północnoatlantyckiego w Brukseli, wezwał Ankarę do zaaprobowania akcesji Szwecji do NATO.

## "Washington Post":  USA zmieniły decyzję. Biden jest za skróceniem drogi Ukrainy do NATO
 - [https://forsal.pl/swiat/usa/artykuly/8735160,washington-post-usa-zmienily-decyzje-biden-jest-za-skroceniem-dro.html](https://forsal.pl/swiat/usa/artykuly/8735160,washington-post-usa-zmienily-decyzje-biden-jest-za-skroceniem-dro.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 15:53:06+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/pcLktkuTURBXy9jNjlmNmJlMC0wYWMxLTQ4NmQtODRmZC1mYTc2N2U3Yjg3ODAuanBlZ5GTBc0BHcyg" />Prezydent USA Joe BIden poparł propozycję sekretarza generalnego NATO Jensa Stoltenberga, by zrezygnować z wymogu przejścia przez mechanizm Planu Działań na rzecz Członkostwa (Membership Action Plan; MAP) w ramach akcesji Ukrainy do Sojuszu - podały &quot;Washington Post&quot; i Politico. Ma to potencjalnie skrócić jej drogę do członkostwa.

## O ile podrożała godzina pracy w UE? Dane dla Polski mogą zaskakiwać
 - [https://forsal.pl/praca/wynagrodzenia/artykuly/8735123,o-ile-podrozala-godzina-pracy-w-ue-eurostat-podal-najnowsze-dane.html](https://forsal.pl/praca/wynagrodzenia/artykuly/8735123,o-ile-podrozala-godzina-pracy-w-ue-eurostat-podal-najnowsze-dane.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 14:45:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/mfVktkuTURBXy9iNjY0NTQ3MS1mZjMwLTRkZTUtYTQxMC05NjAzNGVkNTY4OTMuanBlZ5GTBc0BHcyg" />W pierwszym kwartale 2023 r. godzinowe koszty pracy wzrosły o 5,0 proc. w strefie euro i o 5,3 proc. w całej Unii Europejskiej w porównaniu z tym samym kwartałem poprzedniego roku. Wskaźnik dla Polski jest dwa razy wyższy.

## Chiny na krawędzi deflacji. Gospodarcze ożywienie utknęło w martwym punkcie
 - [https://forsal.pl/swiat/chiny/artykuly/8735029,chiny-na-krawedzi-deflacji-gospodarcze-ozywienie-utknelo-w-martwym-pu.html](https://forsal.pl/swiat/chiny/artykuly/8735029,chiny-na-krawedzi-deflacji-gospodarcze-ozywienie-utknelo-w-martwym-pu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 14:30:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/GJkktkuTURBXy9mMTdmZmVmOC1jMThkLTRkYWMtYTMwZS0zNDI4ZTU5YTUxMjQuanBlZ5GTBc0BHcyg" />Chińska gospodarka doświadcza trudnego restartu po spowolnieniu wywołanym pandemią i polityką zero-covid. Słabe dane z maja wzbudziły oczekiwania na bardziej zdecydowaną polityczną interwencję.

## Raport dotyczący Borisa Johnsona problemem dla Partii Konserwatywnej
 - [https://forsal.pl/swiat/brexit/artykuly/8735136,raport-dotyczacy-borisa-johnsona-problemem-dla-partii-konserwatywnej.html](https://forsal.pl/swiat/brexit/artykuly/8735136,raport-dotyczacy-borisa-johnsona-problemem-dla-partii-konserwatywnej.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 14:18:32+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/hg6ktkuTURBXy9jYWVkZWVhMy1mNjdmLTQ2MTgtOTljNS0wNjc1N2MzYmE5YjAuanBlZ5GTBc0BHcyg" />Poselski raport uznający byłego premiera Borisa Johnsona za winnego świadomego wprowadzania w błąd Izby Gmin w kwestii imprez na Downing Street w czasie lockdownu stawia w trudnej sytuacji posłów Partii Konserwatywnej w kontekście głosowania nad nim - oceniają w piątek brytyjskie media.

## Stoltenberg: Sojusznicy zgadzają się, że Ukraina jest bliżej NATO
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8735135,stoltenberg-sojusznicy-zgadzaja-sie-ze-ukraina-jest-blizej-nato.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8735135,stoltenberg-sojusznicy-zgadzaja-sie-ze-ukraina-jest-blizej-nato.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 14:12:03+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/gG-ktkuTURBXy80MTBhM2Q4Ni05N2MyLTQwMDktOWFkNS1mOGRiNmJkYmNiMDguanBlZ5GTBc0BHcyg" />Sojusznicy zgadzają się, że Ukraina zbliżyła się do NATO w ciągu ostatniej dekady - oświadczył sekretarz generalny NATO Jens Stoltenberg w piątek, po zakończeniu dwudniowego spotkania ministrów obrony krajów Sojuszu w Brukseli.

## Tymczasowa ochrona dla Ukraińców. Niemcy numerem jeden w rankingu
 - [https://forsal.pl/gospodarka/demografia/artykuly/8712101,tymczasowa-ochrona-dla-ukraincow-niemcy-numerem-jeden-w-rankingu.html](https://forsal.pl/gospodarka/demografia/artykuly/8712101,tymczasowa-ochrona-dla-ukraincow-niemcy-numerem-jeden-w-rankingu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 14:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Uu7ktkuTURBXy80N2Y0MGNiNS01YWM0LTRjMTYtOGU4My1lNWVjMzNiZjE0YjIuanBlZ5GTBc0BHcyg" />Prawie cztery miliony obywateli spoza UE, którzy uciekli przed wojną w Ukrainie, otrzymało tymczasową ochronę do końca marca 2023 roku - wynika z oficjalnej bazy danych Eurostatu. Najwięcej osób z takim statusem przebywało w Niemczech i Polsce.

## Cieszyński o inwestycji Intela: Polska zyskała wyjątkową okazję, by dołączyć do światowej ligi producentów mikrochipów
 - [https://forsal.pl/gospodarka/inflacja/artykuly/8735131,cieszynski-o-inwestycji-intela-polska-zyskala-wyjatkowa-okazje-by-do.html](https://forsal.pl/gospodarka/inflacja/artykuly/8735131,cieszynski-o-inwestycji-intela-polska-zyskala-wyjatkowa-okazje-by-do.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 13:54:56+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/2p2ktkuTURBXy9jNTkwYjVhYS1lZWEzLTRiNjQtOTY5MC1hNzE2M2RlMTMyYjMuanBlZ5GTBc0BHcyg" />Inwestycja Intela w budowę zakładu integracji i testowania półprzewodników w okolicach Wrocławia to inwestycja w obszar na przemysłowej mapie świata, w którym Polska nie była do tej pory obecna – powiedział PAP minister cyfryzacji Janusz Cieszyński.

## Najlepszy znaczek pocztowy świata został wybrany. To ukraiński znaczek wojenny ze słynnym cytatem
 - [https://forsal.pl/swiat/ukraina/artykuly/8735128,najlepszy-znaczek-pocztowy-swiata-zostal-wybrany-to-ukrainski-znaczek.html](https://forsal.pl/swiat/ukraina/artykuly/8735128,najlepszy-znaczek-pocztowy-swiata-zostal-wybrany-to-ukrainski-znaczek.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 13:40:28+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/8PFktkuTURBXy9hZTNlZjlmYi0xOWYxLTQ5YTYtYmVkNi0yNTUwNDBlNzdkY2QuanBlZ5GTBc0BHcyg" />Wyemitowany przez ukraińską pocztę znaczek z wizerunkiem zatopionego okrętu Moskwa, flagowej jednostki rosyjskiej Floty Czarnomorskiej, oraz fragmentem cytatu &quot;Rosyjski okręcie wojenny, p... się&quot; został uznany za najlepszy znaczek pocztowy na świecie w 2022 roku - poinformował w piątek portal Ukrainska Prawda.

## Zełenski ostrzega w NBC News: Rosjanie mogą wysadzić Zaporoską Elektrownię Atomową
 - [https://forsal.pl/swiat/ukraina/artykuly/8735126,zelenski-ostrzega-w-nbc-news-rosjanie-moga-wysadzic-zaporoska-elektro.html](https://forsal.pl/swiat/ukraina/artykuly/8735126,zelenski-ostrzega-w-nbc-news-rosjanie-moga-wysadzic-zaporoska-elektro.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 13:32:51+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/jh6ktkuTURBXy82Y2I4ZDFiYi03OGI1LTQyM2EtOGUxZS05YjY1NzE1MDk4ZjYuanBlZ5GTBc0BHcyg" />Rosjanie są zainteresowani destabilizacją naszego kraju, dlatego po hydroelektrowni w Nowej Kachowce mogą wysadzić też okupowaną Zaporoską Elektrownię Atomową - oznajmił w opublikowanym w czwartek wywiadzie dla amerykańskiej stacji NBC News prezydent Ukrainy Wołodymyr Zełenski.

## Czy rosyjscy bojownicy walczący po stronie Ukrainy użyli belgijską broń w Rosji? Kijów bada sprawę
 - [https://forsal.pl/swiat/ukraina/artykuly/8735113,czy-rosyjscy-bojownicy-walczacy-po-stronie-ukrainy-uzyli-belgijska-bro.html](https://forsal.pl/swiat/ukraina/artykuly/8735113,czy-rosyjscy-bojownicy-walczacy-po-stronie-ukrainy-uzyli-belgijska-bro.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 13:09:46+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/lCdktkuTURBXy85YzAyODFmMS1jOGNhLTQyMzMtOTE4ZS05MGQ1NjEwMWRkNWMuanBlZ5GTBc0BHcyg" />Kijów bada, czy belgijska broń przekazana Ukrainie mogła być użyta na terytorium Rosji - powiedział minister obrony Ukrainy swojej belgijskiej odpowiedniczce podczas spotkania w Brukseli. O szczegółach informuje agencja Belga.

## Wizz Air skierował 10. samolot typu Airbus do obsługi lotów z Lotnisko Chopina
 - [https://forsal.pl/transport/lotnictwo/artykuly/8735109,wizz-air-skierowal-10-samolot-typu-airbus-do-obslugi-lotow-z-lotnisko.html](https://forsal.pl/transport/lotnictwo/artykuly/8735109,wizz-air-skierowal-10-samolot-typu-airbus-do-obslugi-lotow-z-lotnisko.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 12:50:15+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/4nYktkuTURBXy8yYTVmZTgxNi1lMzUyLTQ2ZmEtYTRmMi1mMDc0NTQ5N2QzYzMuanBlZ5GTBc0BHcyg" />10. samolot typu Airbus A321neo dołączył do floty węgierskiego Wizz Air na Lotnisku Chopina w Warszawie - poinformował w piątek przewoźnik. Nowa maszyna będzie obsługiwała loty ze stolicy Polski do Sewilli w Hiszpanii - dodano.

## Inflacja bazowa w maju spadła. NBP podał dane
 - [https://forsal.pl/gospodarka/inflacja/artykuly/8735082,inflacja-bazowa-w-maju-spadla-nbp-podal-dane.html](https://forsal.pl/gospodarka/inflacja/artykuly/8735082,inflacja-bazowa-w-maju-spadla-nbp-podal-dane.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 12:09:49+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/fNxktkuTURBXy9jNGQyYzc4Ny1mZThmLTRiYzEtOTBjYi0yYjdlMjU1MmExNGUuanBlZ5GTBc0BHcyg" />W maju 2023 r. inflacja po wyłączeniu cen żywności i energii wyniosła 11,5 proc. licząc rok do roku, podczas gdy w kwietniu było to 12,2 proc. – podał w piątek Narodowy Bank Polski. Inflacja konsumencka w maju wyniosła 13 proc.

## Zmotoryzowani mogą odetchnąć z ulgą. Wg analityków nie będzie wakacyjnych podwyżek cen paliw
 - [https://forsal.pl/transport/aktualnosci/artykuly/8735078,zmotoryzowani-moga-odetchnac-z-ulga-wg-analitykow-nie-bedzie-wakacyjn.html](https://forsal.pl/transport/aktualnosci/artykuly/8735078,zmotoryzowani-moga-odetchnac-z-ulga-wg-analitykow-nie-bedzie-wakacyjn.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 12:03:23+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/2soktkuTURBXy9mZGJlOWRkOS00ZDZmLTQ3MDktOWM0ZS00YjI2MmU4ZWNlYWYuanBlZ5GTBc0BHcyg" />Prognozowane obniżki cen hurtowych w rafineriach raczej nie przełożą się na wyraźne obniżki na stacjach paliw w najbliższych dniach, jednak kierowcy nie muszą się obawiać podwyżek na początku wakacji - ocenili w piątkowym komentarzu eksperci portalu e-petrol.pl.

## Bill Gates w Chinach. Spotkał się z Xi Jinpingiem
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8735075,bill-gates-w-chinach-spotkal-sie-z-xi-jinpingiem.html](https://forsal.pl/biznes/aktualnosci/artykuly/8735075,bill-gates-w-chinach-spotkal-sie-z-xi-jinpingiem.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 11:56:01+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Nx_ktkuTURBXy84Mzc1MzczMy1iMzdmLTRjZDEtODNlOS0xOThmZmRjZmE5MTUuanBlZ5GTBc0BHcyg" />Podczas spotkania z miliarderem i filantropem Billem Gatesem w piątek w Pekinie przywódca Chin Xi Jinping wyraził nadzieję na kontynuowanie przyjaźni i prowadzenie wspólnych działań korzystnych dla Chin i USA - podała agencja Reutera.

## Mondelez nie zrezygnuje z biznesu w Rosji. Planuje wydzielić specjalną, rosyjską spółkę
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8735069,mondelez-nie-zrezygnuje-z-biznesu-w-rosji-planuje-wydzielic-specjalna.html](https://forsal.pl/biznes/aktualnosci/artykuly/8735069,mondelez-nie-zrezygnuje-z-biznesu-w-rosji-planuje-wydzielic-specjalna.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 11:49:02+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/o2zktkuTURBXy8wYWEyMGQ0Ny1mOWU2LTQ5NDAtYjlmYi1lNTY1ZjkwOWFiMzIuanBlZ5GTBc0BHcyg" />Działający w Rosji koncern Mondelez International, po mającym miejsce w Szwecji i Norwegii bojkocie jego wyrobów czekoladowych, nie zamierza rezygnować z biznesu w rządzonym przez dyktatora Putina kraju. Zapowiedział jedynie wydzielenie do końca roku rosyjskiej spółki ze swoich struktur międzynarodowych. Poprzez bojkot skandynawscy konsumenci protestują przeciwko niewycofaniu się firmy z działalności w Rosji.

## Sudan potrzebuje pomocy humanitarnej. Miliony dzieci cierpią na skutek konfliktu
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8735063,sudan-potrzebuje-pomocy-humanitarnej-miliony-dzieci-cierpia-na-skutek.html](https://forsal.pl/swiat/aktualnosci/artykuly/8735063,sudan-potrzebuje-pomocy-humanitarnej-miliony-dzieci-cierpia-na-skutek.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 11:38:28+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/AZLktkuTURBXy9iMTRmYmU1OC1jNTM1LTRmOTEtYmYwZC03ZmZmNWI3OTZiNTAuanBlZ5GTBc0BHcyg" />W konflikcie w Sudanie, który wybuchł w kwietniu między armią a paramilitarnymi Jednostkami Szybkiego Wsparcia (RSF), zginęło 330 dzieci, a 13 milionów dzieci potrzebuje pilnej pomocy humanitarnej - ocenił w wydanym w piątek raporcie Fundusz Narodów Zjednoczonych na rzecz dzieci (UNICEF).

## Organ Rady Europy monitorujący korupcję jednym zdaniem skwitował skandal w PE
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8735017,organ-rady-europy-monitorujacy-korupcje-jednym-zdaniem-skwitowal-skand.html](https://forsal.pl/swiat/unia-europejska/artykuly/8735017,organ-rady-europy-monitorujacy-korupcje-jednym-zdaniem-skwitowal-skand.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 10:11:28+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/bjAktkuTURBXy9mZmQ0NzhjOC1lZDBjLTQxZTEtYTQ0Ni05YWUwMzQ3NDI3MzEuanBlZ5GTBc0BHcyg" />Antykorupcyjny organ Rady Europy (GRECO) opublikował w czwartek roczny raport na temat korupcji w państwach członkowskich. Skandal korupcyjny w Parlamencie Europejskim skwitowano w nim jednym zdaniem - podała agencja informacyjna Anadolu.

## Majątek najbogatszego Belga wzrósł o 640 mln euro. W jeden dzień
 - [https://forsal.pl/finanse/finanse-osobiste/artykuly/8735008,majatek-najbogatszego-belga-wzrosl-o-640-mln-euro-w-jeden-dzien.html](https://forsal.pl/finanse/finanse-osobiste/artykuly/8735008,majatek-najbogatszego-belga-wzrosl-o-640-mln-euro-w-jeden-dzien.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 09:38:40+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/1-JktkuTURBXy9iNjIxZTY5ZS0xMjNjLTRmYmMtOWM3NS04ZDMyYTQyYzBhYzMuanBlZ5GTBc0BHcyg" />Majątek najbogatszego Belga, 76-letniego Erica Wittoucka, wzrósł o 640 mln euro w jeden dzień - informuje dziennik „De Tijd”. Magazyn „Forbes” szacuje jego cały majątek na około 8 mld euro.

## Jaka była majowa inflacja? Są dane Eurostatu
 - [https://forsal.pl/gospodarka/inflacja/artykuly/8734991,jaka-byla-majowa-inflacja-sa-dane-eurostatu.html](https://forsal.pl/gospodarka/inflacja/artykuly/8734991,jaka-byla-majowa-inflacja-sa-dane-eurostatu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 09:18:27+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/IHvktkuTURBXy84YjEwMTEzZi1hM2RlLTQxMDAtOGQ3NC1mNDE2OGEwMmE2NDguanBlZ5GTBc0BHcyg" />undefined

## Jaka jest średnia cena mieszkania na rynku pierwotnym?
 - [https://forsal.pl/nieruchomosci/mieszkania/artykuly/8734979,jaka-jest-srednia-cena-mieszkania-na-rynku-pierwotnym.html](https://forsal.pl/nieruchomosci/mieszkania/artykuly/8734979,jaka-jest-srednia-cena-mieszkania-na-rynku-pierwotnym.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 08:56:05+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/PdUktkuTURBXy9kMGJiZDdjMS02MzA1LTRlMGEtODE2Zi02NDE1N2IwYjNlMTAuanBlZ5GTBc0BHcyg" />undefined

## Koronawirus w Polsce: 28 zakażeń, nie było przypadków śmiertelnych [DANE Z 16.06]
 - [https://forsal.pl/artykuly/1458115,koronawirus-w-polsce-28-zakazen-nie-bylo-przypadkow-smiertelnych-da.html](https://forsal.pl/artykuly/1458115,koronawirus-w-polsce-28-zakazen-nie-bylo-przypadkow-smiertelnych-da.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 08:38:55+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/3QYktkuTURBXy9lNjE1ZGFlZC02OTg5LTQzNzItOTg5OS1jZWEzOWVhODg4OWYuanBlZ5GTBc0BHcyg" />Minionej doby badania potwierdziły 28 zakażeń koronawirusem w tym 4 ponowne. Z powodu COVID-19 nie zmarł żaden pacjent – poinformowano w piątek na stronach rządowych. Wykonano 2 tys. testów w kierunku SARS-CoV-2. W ostatnim tygodniu (od 8 do 14 czerwca) było o ponad 30 proc. zakażeń mniej niż tydzień wcześniej.

## W Polsce powstanie fabryka Intela. To największa bezpośrednia inwestycja zagraniczna w historii naszego kraju
 - [https://forsal.pl/biznes/przemysl/artykuly/8734963,w-polsce-powstanie-fabryka-intela-to-najwieksza-bezposrednia-inwestycja-zagraniczna-w-historii-naszego-kraju.html](https://forsal.pl/biznes/przemysl/artykuly/8734963,w-polsce-powstanie-fabryka-intela-to-najwieksza-bezposrednia-inwestycja-zagraniczna-w-historii-naszego-kraju.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 08:29:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/jUiktkuTURBXy80YTk3YmM0NC0yMjA5LTRhOWItOWY5NC04NjVhZmU1MjM3YWEuanBlZ5GTBc0BHcyg" />Gigant technologiczny z Doliny Krzemowej zainwestuje blisko 20 mld zł w Zakład Integracji i Testowania Półprzewodników w Miękini. To największa bezpośrednia inwestycja zagraniczna w historii Polski.

## W Polsce powstanie fabryka Intela. To największa bezpośrednia inwestycja zagraniczna w historii naszego kraju
 - [https://forsal.pl/biznes/przemysl/artykuly/8734963,w-polsce-powstanie-fabryka-intela-to-najwieksza-bezposrednia-inwestyc.html](https://forsal.pl/biznes/przemysl/artykuly/8734963,w-polsce-powstanie-fabryka-intela-to-najwieksza-bezposrednia-inwestyc.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 08:29:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/jUiktkuTURBXy80YTk3YmM0NC0yMjA5LTRhOWItOWY5NC04NjVhZmU1MjM3YWEuanBlZ5GTBc0BHcyg" />Gigant technologiczny z Doliny Krzemowej zainwestuje blisko 20 mld zł w Zakład Integracji i Testowania Półprzewodników w Miękini. To największa bezpośrednia inwestycja zagraniczna w historii Polski.

## Europejska branża motoryzacyjna odżywa. Sprzedaż aut rośnie
 - [https://forsal.pl/motoforsal/motobiznes/artykuly/8717938,europejska-branza-motoryzacyjna-odzywa-sprzedaz-aut-rosnie.html](https://forsal.pl/motoforsal/motobiznes/artykuly/8717938,europejska-branza-motoryzacyjna-odzywa-sprzedaz-aut-rosnie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 07:51:10+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/QmpktkuTURBXy84NzFkODJjMC0zMGVlLTRiZmEtOGMyYy1hMzQzYmMzMWUzM2EuanBlZ5GTBc0BHcyg" />Producenci aut nadrabiają zaległości w zamówieniach dzięki poprawie ciągłości w łańcuchach dostaw, dlatego kwiecień był dziewiątym miesiącem wzrostów sprzedaży.

## Strategia VRG zakłada 62,7 tys. m2 pow. sklepów offline i 6 własnych e-sklepów do 2025 r.
 - [https://forsal.pl/finanse/gielda/artykuly/8734938,strategia-vrg-zaklada-627-tys-m2-pow-sklepow-offline-i-6-wlasnych-e-sklepow-do-2025-r.html](https://forsal.pl/finanse/gielda/artykuly/8734938,strategia-vrg-zaklada-627-tys-m2-pow-sklepow-offline-i-6-wlasnych-e-sklepow-do-2025-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 07:46:50+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/jZUktkuTURBXy81MTFhNDNjNC1kMThlLTQ5NDAtYjUyNS1hNGFiYmE0YjJlY2YuanBlZ5GTBc0BHcyg" />undefined

## Strategia VRG: Ok. 14,5% CAGR sprzedaży Grupy w 2022-2025, wzrost marży brutto do 56-57%
 - [https://forsal.pl/finanse/gielda/artykuly/8734935,strategia-vrg-ok-145-cagr-sprzedazy-grupy-w-2022-2025-wzrost-marzy-brutto-do-56-57-proc.html](https://forsal.pl/finanse/gielda/artykuly/8734935,strategia-vrg-ok-145-cagr-sprzedazy-grupy-w-2022-2025-wzrost-marzy-brutto-do-56-57-proc.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 07:41:25+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/hZ5ktkuTURBXy85ZDYyNDNjYi1mMTQzLTQzZGUtYTQyMS0xNGQ2YWVhNmQ3MTcuanBlZ5GTBc0BHcyg" />undefined

## Gospodarka Chin nie wraca do zdrowia tak szybko, jak myślano. Oto pięć nietypowych wykresów, które to pokazują
 - [https://forsal.pl/swiat/chiny/galeria/8725575,gospodarka-chin-nie-wraca-do-zdrowia-tak-szybko.html](https://forsal.pl/swiat/chiny/galeria/8725575,gospodarka-chin-nie-wraca-do-zdrowia-tak-szybko.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 07:30:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/tGqktkuTURBXy9lNjU4NjI0OS1kNDVhLTQzMTMtODRmNS04ZGI5ZDc4ZmNjNjEuanBlZ5GTBc0BHcyg" />Dla inwestorów analizujących stan chińskiej gospodarki takie towary, jak ropa naftowa czy miedź, zwykle są najważniejszym obiektem zainteresowania. Ale druga co do wielkości gospodarka świata to również szereg rynków, na których handluje się mniej znanymi produktami.

## Ciech zaprosił do sprzedaży maks. 11,78 proc. akcji po 54,25 zł za akcję
 - [https://forsal.pl/finanse/gielda/artykuly/8734927,ciech-zaprosil-do-sprzedazy-maks-1178-proc-akcji-po-5425-zl-za-akcje.html](https://forsal.pl/finanse/gielda/artykuly/8734927,ciech-zaprosil-do-sprzedazy-maks-1178-proc-akcji-po-5425-zl-za-akcje.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 07:26:57+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Xh_ktkuTURBXy8zNjY5ODllOS1lMTVlLTQ5MTMtYjNmZS05MWE0MWYyZmZiOGQuanBlZ5GTBc0BHcyg" />undefined

## Elemental Alu odwołał zaproszenie do składania ofert sprzedaży 45,84 proc. akcji Alumetalu
 - [https://forsal.pl/finanse/gielda/artykuly/8734924,elemental-alu-odwolal-zaproszenie-do-skladania-ofert-sprzedazy-4584-proc-akcji-alumetalu.html](https://forsal.pl/finanse/gielda/artykuly/8734924,elemental-alu-odwolal-zaproszenie-do-skladania-ofert-sprzedazy-4584-proc-akcji-alumetalu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 07:22:26+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/8dUktkuTURBXy9jOTEzYjFiZi05ZDZlLTQ1OTUtOWY4Ni02NjU4MGFkZmRmODMuanBlZ5GTBc0BHcyg" />undefined

## Akcjonariusze Energi zdecydowali o niewypłacaniu dywidendy za 2022 r.
 - [https://forsal.pl/finanse/gielda/artykuly/8734921,akcjonariusze-energi-zdecydowali-o-niewyplacaniu-dywidendy-za-2022-r.html](https://forsal.pl/finanse/gielda/artykuly/8734921,akcjonariusze-energi-zdecydowali-o-niewyplacaniu-dywidendy-za-2022-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 07:17:04+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/oYJktkuTURBXy9lOTc0OTA0Ni05MWI3LTRlZGYtYThlYi1lMjZiMDA1YWU3Y2YuanBlZ5GTBc0BHcyg" />undefined

## Akcjonariusze Grupy Pracuj zdecydowali o wypłacie 1,5 zł dywidendy na akcję za 2022 r.
 - [https://forsal.pl/finanse/gielda/artykuly/8734919,akcjonariusze-grupy-pracuj-zdecydowali-o-wyplacie-15-zl-dywidendy-na-akcje-za-2022-r.html](https://forsal.pl/finanse/gielda/artykuly/8734919,akcjonariusze-grupy-pracuj-zdecydowali-o-wyplacie-15-zl-dywidendy-na-akcje-za-2022-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 07:14:22+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/dk1ktkuTURBXy84ZDM4M2FkNC02OTczLTQ3MjUtYmI5MC00NDk1NjlhNGRiMTguanBlZ5GTBc0BHcyg" />undefined

## Porzuć komputer, złap za łopatę? Wzrasta liczba ogłoszeń związanych z pracą fizyczną [RAPORT]
 - [https://forsal.pl/praca/aktualnosci/artykuly/8734918,porzuc-komputer-zlap-za-lopate-wzrasta-liczba-ogloszen-zwiazanych-z.html](https://forsal.pl/praca/aktualnosci/artykuly/8734918,porzuc-komputer-zlap-za-lopate-wzrasta-liczba-ogloszen-zwiazanych-z.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 07:12:44+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/2mAktkuTURBXy9hMzdmZjhmNS02MjA4LTQwNzUtODMwNy1iODliNjFlNmE1OTAuanBlZ5GTBc0BHcyg" />Choć skala redukcji ofert pracy w maju nie była duża, spadek stanowi kolejne potwierdzenie negatywnej tendencji na rynku wakatów, trwającej już 12 miesiąc – wynika z Barometru Ofert Pracy. Jak przekazano, od początku br. w zawodach związanych z pracą fizyczną liczba ogłoszeń powoli wzrasta.

## Japonia podnosi wiek zgody na czynności seksualne. Od teraz to 16 lat, a jak było wcześniej?
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8734912,japonia-podnosi-wiek-zgody-na-czynnosci-seksualne-od-teraz-to-16-lat.html](https://forsal.pl/swiat/aktualnosci/artykuly/8734912,japonia-podnosi-wiek-zgody-na-czynnosci-seksualne-od-teraz-to-16-lat.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 06:59:24+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/UdCktkuTURBXy81NWVmZDI2Ni1iNzU2LTRmMWEtOGI5OS0yYjA5MTkwMTMzMWUuanBlZ5GTBc0BHcyg" />W Japonii podniesiono w piątek wiek zgody na czynności seksualne z 13 lat - jednego z najniższych takich progów na świecie - do 16 lat w ramach reformy prawa dotyczącego przestępstw o charakterze seksualnym.

## Wiceprezes PKO BP: W związku z wyrokiem TSUE zmienią się poziomy rezerw w bankach
 - [https://forsal.pl/biznes/bankowosc/artykuly/8734899,wiceprezes-pko-bp-w-zwiazku-z-wyrokiem-tsue-zmienia-sie-poziomy-rezer.html](https://forsal.pl/biznes/bankowosc/artykuly/8734899,wiceprezes-pko-bp-w-zwiazku-z-wyrokiem-tsue-zmienia-sie-poziomy-rezer.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 06:16:46+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Ad1ktkuTURBXy8xNmYyZDc3Mi02NzRlLTQzMjctODJkNS1iYjhiYTE5ZTNmMjQuanBlZ5GTBc0BHcyg" />Zmiany poziomu rezerw w bankach, wynikające z czwartkowego wyroku TSUE w sprawie kredytów frankowych, mogą nastąpić w najbliższych tygodniach - powiedział PAP wiceprezes PKO BP Piotr Mazur.

## Elon Musk zaapelował do Włochów: "Miejcie dzieci"
 - [https://forsal.pl/gospodarka/demografia/artykuly/8734897,elon-musk-zaapelowal-do-wlochow-miejcie-dzieci.html](https://forsal.pl/gospodarka/demografia/artykuly/8734897,elon-musk-zaapelowal-do-wlochow-miejcie-dzieci.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 06:09:56+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ESaktkuTURBXy8xZTAzMGE4ZS00NmI2LTQ2N2QtOTZkNi03MTc5NGExYzk0ZTMuanBlZ5GTBc0BHcyg" />„Miejcie dzieci!”: apelował do Włochów Elon Musk podczas czwartkowego, wieczornego wywiadu w głównym wydaniu serwisu informacyjnego Tg1. Wcześniej spotkał się w Rzymie z premier Giorgią Meloni – podaje ANSA.

## Kursy walut: Złoty stracił wobec euro, dolara i franka
 - [https://forsal.pl/finanse/waluty/artykuly/8734896,kursy-walut-zloty-stracil-wobec-euro-dolara-i-franka.html](https://forsal.pl/finanse/waluty/artykuly/8734896,kursy-walut-zloty-stracil-wobec-euro-dolara-i-franka.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 06:09:42+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/cyfktkuTURBXy8wNDEzM2ZlNy1jZTVkLTRhYWYtOWU3OS00NzIzZDI1ZGU3ZTAuanBlZ5GTBc0BHcyg" />W piątek ok. godz. 7.10 polska waluta straciła na wartości wobec euro, dolara amerykańskiego i franka szwajcarskiego. Euro kosztowało ponad 4,45 zł, dolar 4,07 zł, a frank szwajcarski ponad 4,56 zł.

## W Peru epidemia dengi. Tymczasem minister zdrowia podała się do dymisji
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8734893,w-peru-epidemia-dengi-tymczasem-minister-zdrowia-podala-sie-do-dymisj.html](https://forsal.pl/swiat/aktualnosci/artykuly/8734893,w-peru-epidemia-dengi-tymczasem-minister-zdrowia-podala-sie-do-dymisj.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 06:02:52+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/JhkktkuTURBXy8zMWExNWU2ZC0zM2Q2LTQ3ZGMtYmQ3Mi0yZmJkY2FkMWRlZGQuanBlZ5GTBc0BHcyg" />Minister zdrowia Peru Rosa Gutierrez podała się do dymisji w czasie, gdy w jej kraju trwa epidemia gorączki denga, która zbiera rekordowe żniwo - poinformowała w piątek agencja Reutera. Zmarło już prawie 250 osób.

## Mocne wzrosty na Wall Street. Indeksy rosną szósty dzień z rzędu
 - [https://forsal.pl/finanse/gielda/artykuly/8734890,mocne-wzrosty-na-wall-street-indeksy-rosna-szosty-dzien-z-rzedu.html](https://forsal.pl/finanse/gielda/artykuly/8734890,mocne-wzrosty-na-wall-street-indeksy-rosna-szosty-dzien-z-rzedu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 06:00:07+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/DUhktkuTURBXy9mMjc5MzJlMi02YmNiLTQ2NjQtOTFiNS03OTQ3MzU3ODJhZGUuanBlZ5GTBc0BHcyg" />Czwartkowa sesja na Wall Street zakończyła się mocnymi wzrostami głównych indeksów. Nasdaq i S&amp;amp;P 500 zanotowały już szóstą z rzędu wzrostową sesję. W centrum uwagi inwestorów były decyzje banków centralnych oraz najnowsze dane z amerykańskiej gospodarki.

## Amerykańskie agencje rządowe dotknięte globalnym cyberatakiem
 - [https://forsal.pl/lifestyle/technologie/artykuly/8734889,amerykanskie-agencje-rzadowe-dotkniete-globalnym-cyberatakiem.html](https://forsal.pl/lifestyle/technologie/artykuly/8734889,amerykanskie-agencje-rzadowe-dotkniete-globalnym-cyberatakiem.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 05:57:09+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/YNzktkuTURBXy8wYmE3MTUwNi1iOTc5LTRhYjctYjJhOS0wYTdmYmFlYWRkYmQuanBlZ5GTBc0BHcyg" />Kilka amerykańskich agencji rządowych padło ofiarami cyberataku ransomware - poinformowała w czwartek Agencja Cyberbezpieczeństwa i Bezpieczeństwa Infrastruktury (CISA). Jak podaje telewizja MSNBC, sprawcami cyberataku, który wcześniej dotknął instytucje i firmy na całym świecie, był rosyjskojęzyczny gang CLOP.

## "Cyfrowy stres". Dźwięki komunikatorów "zakłócają nasze życie"
 - [https://forsal.pl/lifestyle/technologie/artykuly/8733873,cyfrowy-stres-dzwieki-komunikatorow-zaklocaja-nasze-zycie.html](https://forsal.pl/lifestyle/technologie/artykuly/8733873,cyfrowy-stres-dzwieki-komunikatorow-zaklocaja-nasze-zycie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 04:30:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/tlYktkuTURBXy82ZThkY2I1OC00YTA4LTQ4NzQtOGM1YS1jYmE4NDk3YjAyMGQuanBlZ5GTBc0BHcyg" />Coraz częściej słyszymy dźwięki przychodzących wiadomości od szefa/współpracowników. Dla osób pracujących zdalnie to już stały element codzienności. Według ekspertów ten „cyfrowy szum” zwiększa u ludzi poziom stresu.

## Berlin bez wody pitnej? Odejście od węgla w byłej NRD niemalże wysuszy rzekę Sprewę
 - [https://forsal.pl/biznes/ekologia/artykuly/8734472,berlin-bez-wody-pitnej-odejscie-od-wegla-w-bylej-nrd-niemalze-wysuszy.html](https://forsal.pl/biznes/ekologia/artykuly/8734472,berlin-bez-wody-pitnej-odejscie-od-wegla-w-bylej-nrd-niemalze-wysuszy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 04:30:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/655ktkuTURBXy82NDYzOTBkNS1lZmE2LTQwNmEtOGRhOC0zZmFhZWExMTIwYmQuanBlZ5GTBc0BHcyg" />Niemiecka Federalna Agencja Ochrony Środowiska (Umwelt Bundesamt) ostrzega, że planowane odejście od węgla we wschodnich landach może oznaczać, że poziom wody w rzece Sprewa opadnie nawet o 75 proc. Wraz z nim może spaść poziom w kanałach i jeziorach, co w dalszej kolejności stanowić będzie zagrożenie dla dostaw wody pitnej. Agencja apeluje o podjęcie pilnych działań.

## Kto wybiera, tego era. Seniorzy biją pokolenie alfa o dwie długości. W tle Ukrainki i Filipinki [FELIETON]
 - [https://forsal.pl/gospodarka/demografia/artykuly/8734403,kto-wybiera-tego-era-seniorzy-bija-pokolenie-alfa-o-dwie-dlugosci-w-tle-ukrainki-i-filipinki-felieton.html](https://forsal.pl/gospodarka/demografia/artykuly/8734403,kto-wybiera-tego-era-seniorzy-bija-pokolenie-alfa-o-dwie-dlugosci-w-tle-ukrainki-i-filipinki-felieton.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 04:30:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Q1WktkuTURBXy9jYTU0OTJhNy1iYTY3LTRlZGQtYWMyNS1hMmYxZTc0NzcyMGIuanBlZ5GTBc0BHcyg" />Darmowe autostrady czy leki? Place zabaw czy kluby seniora? Skateparki czy windy w starych blokach? Pytam, bo od początku stulecia populacja Polek i Polaków po 60-ce urosła z 7 do 10 milionów, a grupa wyborców w wieku od 18 do 29 lat stopniała z 10 do 4,5 mln. Pytanie na poziomie podstawówki: kto kogo przegłosuje, zważywszy, że frekwencja wyborcza seniorów sięga 75 proc., a młodych ociera się o 60?

## Netflix wychodzi zwycięsko z walki z nielegalnym współdzieleniem kont. Amazon i HBO Max idą inną drogą
 - [https://forsal.pl/lifestyle/rozrywka/artykuly/8734513,netflix-wychodzi-zwyciesko-z-walki-z-nielegalnym-wspoldzieleniem-kont.html](https://forsal.pl/lifestyle/rozrywka/artykuly/8734513,netflix-wychodzi-zwyciesko-z-walki-z-nielegalnym-wspoldzieleniem-kont.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 04:30:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/IEYktkuTURBXy9jZjgzOGE3NC01ZmZmLTQ2MDYtOGM2Yi1mYWE2NzY3OTc5ODMuanBlZ5GTBc0BHcyg" />Wygląda na to, że co byśmy na ten temat jako subskrybenci nie sądzili, decyzja Netflixa o ograniczeniach dotyczących kont użytkowników wyszła mu na dobre. Od czasu ich wprowadzenia baza subskrybentów wzrosła mu bardziej niż w trakcie pandemicznego boomu. Tymczasem inne serwisy stosują dokładnie odwrotną taktykę.

## Po tych studiach zarabia się najwięcej. Ranking kierunków, po których zarobisz nawet 10 tys. zł
 - [https://forsal.pl/lifestyle/edukacja/galeria/8733311,po-tych-studiach-zarabia-sie-najwiecej-ranking-kierunkow-po-ktorych.html](https://forsal.pl/lifestyle/edukacja/galeria/8733311,po-tych-studiach-zarabia-sie-najwiecej-ranking-kierunkow-po-ktorych.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 04:30:00+00:00



## Popularna aplikacja sportowa udostępnia dane użytkowników? Naukowcy: Na ich podstawie można określić adres
 - [https://forsal.pl/lifestyle/technologie/artykuly/8734531,strava-udostepnia-dane-uzytkownikow-naukowcy-na-ich-podstawie-mozna-okreslic-adres.html](https://forsal.pl/lifestyle/technologie/artykuly/8734531,strava-udostepnia-dane-uzytkownikow-naukowcy-na-ich-podstawie-mozna-okreslic-adres.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 04:30:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/VM8ktkuTURBXy84Y2QzMzRiNS1hMDJjLTQzODMtYWFmZS1iZWQ3N2ExMGIzZDIuanBlZ5GTBc0BHcyg" />Zdaniem amerykańskich badaczy na podstawie ogólnodostępnych informacji można określić miejsce naszego zamieszkania.

## System kaucyjny w Polsce. Na zwrocie butelek będzie można zarobić nawet 8 tys. zł
 - [https://forsal.pl/biznes/ekologia/artykuly/8734387,system-kaucyjny-w-polsce-ile-bedzie-mozna-zarobic-na-butelkach.html](https://forsal.pl/biznes/ekologia/artykuly/8734387,system-kaucyjny-w-polsce-ile-bedzie-mozna-zarobic-na-butelkach.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-16 04:30:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ocnktkuTURBXy9iYWNiYzBjYy1iZjYyLTQ3NTMtYmNiOS01MWIyNTY0YWUzZjMuanBlZ5GTBc0BHcyg" />6 czerwca rząd przyjął projekt ustawy wprowadzającej w Polsce tzw. system kaucyjny. Od 2025 roku do sklepów będziemy mogli oddawać puste szklane i plastikowe butelki oraz puszki. Za każde oddane opakowanie otrzymamy kaucję w wysokości 50 groszy. Jak mówią edukatorzy ekologiczni, ustawa kaucyjna to coś, na co Polska od wielu lat czeka i czego potrzebuje.

