# Source:Reclaim The Net, URL:https://reclaimthenet.org/feed/, language:en-US

## United Nations Policy Brief Talks of a Digital ID Linked To Your Bank Account
 - [https://reclaimthenet.org/un-digital-id-linked-to-bank](https://reclaimthenet.org/un-digital-id-linked-to-bank)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-06-16 19:28:38+00:00

<a href="https://reclaimthenet.org/un-digital-id-linked-to-bank" rel="nofollow" title="United Nations Policy Brief Talks of a Digital ID Linked To Your Bank Account"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/06/un-digital-id-c.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>An increasingly common proposal among unelected global groups.</p>
<p>The post <a href="https://reclaimthenet.org/un-digital-id-linked-to-bank" rel="nofollow">United Nations Policy Brief Talks of a Digital ID Linked To Your Bank Account</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Ireland’s Justice Minister Helen McEntee Tries To Justify “Hate Speech” Law Plans
 - [https://reclaimthenet.org/helen-mcentee-tries-to-justify-hate-speech-law-plans](https://reclaimthenet.org/helen-mcentee-tries-to-justify-hate-speech-law-plans)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-06-16 19:25:15+00:00

<a href="https://reclaimthenet.org/helen-mcentee-tries-to-justify-hate-speech-law-plans" rel="nofollow" title="Ireland&#8217;s Justice Minister Helen McEntee Tries To Justify &#8220;Hate Speech&#8221; Law Plans"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/06/JUSTICE-MINISTER-HELEN-McEntee.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Ireland is one of the several countries moving to further restrict speech.</p>
<p>The post <a href="https://reclaimthenet.org/helen-mcentee-tries-to-justify-hate-speech-law-plans" rel="nofollow">Ireland&#8217;s Justice Minister Helen McEntee Tries To Justify &#8220;Hate Speech&#8221; Law Plans</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Author C.J. Hopkins Is Investigated By Germany Over Swastika on Cover of Anti-Authoritarian Book
 - [https://reclaimthenet.org/author-c-j-hopkins-investigated-by-germany-swastika-book-cover](https://reclaimthenet.org/author-c-j-hopkins-investigated-by-germany-swastika-book-cover)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-06-16 19:24:44+00:00

<a href="https://reclaimthenet.org/author-c-j-hopkins-investigated-by-germany-swastika-book-cover" rel="nofollow" title="Author C.J. Hopkins Is Investigated By Germany Over Swastika on Cover of Anti-Authoritarian Book"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/06/C-J-Hopkins.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>The book is about the rise of authoritarian during the Covid era.</p>
<p>The post <a href="https://reclaimthenet.org/author-c-j-hopkins-investigated-by-germany-swastika-book-cover" rel="nofollow">Author C.J. Hopkins Is Investigated By Germany Over Swastika on Cover of Anti-Authoritarian Book</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Digital Versions of Classic Hollywood Movies Are Being Censored Even After You Purchase Them
 - [https://reclaimthenet.org/hollywood-movies-are-being-censored-even-after-you-purchase-them](https://reclaimthenet.org/hollywood-movies-are-being-censored-even-after-you-purchase-them)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-06-16 19:23:24+00:00

<a href="https://reclaimthenet.org/hollywood-movies-are-being-censored-even-after-you-purchase-them" rel="nofollow" title="Digital Versions of Classic Hollywood Movies Are Being Censored Even After You Purchase Them"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/06/classic.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Stick to physical media if you want authenticity.</p>
<p>The post <a href="https://reclaimthenet.org/hollywood-movies-are-being-censored-even-after-you-purchase-them" rel="nofollow">Digital Versions of Classic Hollywood Movies Are Being Censored Even After You Purchase Them</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Fox News Is Accused of Using AI To Reinforce Diversity and Inclusion Policies on Employees
 - [https://reclaimthenet.org/fox-news-accused-ai-reinforce-diversity-inclusion-policies](https://reclaimthenet.org/fox-news-accused-ai-reinforce-diversity-inclusion-policies)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-06-16 17:13:56+00:00

<a href="https://reclaimthenet.org/fox-news-accused-ai-reinforce-diversity-inclusion-policies" rel="nofollow" title="Fox News Is Accused of Using AI To Reinforce Diversity and Inclusion Policies on Employees"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/06/fox-news-67.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>AI is increasingly being used to monitor or control employees.</p>
<p>The post <a href="https://reclaimthenet.org/fox-news-accused-ai-reinforce-diversity-inclusion-policies" rel="nofollow">Fox News Is Accused of Using AI To Reinforce Diversity and Inclusion Policies on Employees</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Author Elizabeth Gilbert Cancels Herself
 - [https://reclaimthenet.org/elizabeth-gilbert-gilbert-preemptively-withdrew-novel-set-it-in-russia](https://reclaimthenet.org/elizabeth-gilbert-gilbert-preemptively-withdrew-novel-set-it-in-russia)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-06-16 16:17:05+00:00

<a href="https://reclaimthenet.org/elizabeth-gilbert-gilbert-preemptively-withdrew-novel-set-it-in-russia" rel="nofollow" title="Author Elizabeth Gilbert Cancels Herself"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/06/the-snow-forest.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Gilbert preemptively withdrew her latest novel to avoid criticism for setting it in Russia.</p>
<p>The post <a href="https://reclaimthenet.org/elizabeth-gilbert-gilbert-preemptively-withdrew-novel-set-it-in-russia" rel="nofollow">Author Elizabeth Gilbert Cancels Herself</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

