# Source:pcgamer, URL:http://www.pcgamer.com/rss, language:en-US

## xQc scores unbelievable $100 million deal to start streaming on Kick
 - [https://www.pcgamer.com/xqc-scores-unbelievable-dollar100-million-deal-to-start-streaming-on-kick](https://www.pcgamer.com/xqc-scores-unbelievable-dollar100-million-deal-to-start-streaming-on-kick)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-06-16 22:21:58+00:00

And it’s not even an exclusive deal—he’ll still be streaming on Twitch, too.

## Diablo 4 director: 'It is time for the buffs'
 - [https://www.pcgamer.com/diablo-4-director-it-is-time-for-the-buffs](https://www.pcgamer.com/diablo-4-director-it-is-time-for-the-buffs)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-06-16 22:21:56+00:00

An upcoming patch will soon buff "many things across many classes," says Diablo 4's game director.

## Blizzard reveals how it plans to prevent death by disconnect in Diablo 4 Hardcore mode
 - [https://www.pcgamer.com/blizzard-reveals-how-it-plans-to-prevent-death-by-disconnect-in-diablo-4-hardcore-mode](https://www.pcgamer.com/blizzard-reveals-how-it-plans-to-prevent-death-by-disconnect-in-diablo-4-hardcore-mode)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-06-16 21:15:23+00:00

Joe Shely said during today’s livestream that the Scrolls of Escape will be changed to auto-trigger when a disconnection is detected.

## Overwatch 2's bad times continue as it's forced to disable two new maps
 - [https://www.pcgamer.com/overwatch-2s-bad-times-continue-as-its-forced-to-disable-two-new-maps](https://www.pcgamer.com/overwatch-2s-bad-times-continue-as-its-forced-to-disable-two-new-maps)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-06-16 21:13:09+00:00

Bug exists, trolls exploit it, simple as.

## Diablo 4 gems will be moved out of the inventory
 - [https://www.pcgamer.com/diablo-4-gems-will-be-moved-out-of-the-inventory](https://www.pcgamer.com/diablo-4-gems-will-be-moved-out-of-the-inventory)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-06-16 20:26:48+00:00

In a future update, gems will be treated like a resource instead of an inventory item.

## I demand you stop what you're doing and look at this cute Mac-shaped charger
 - [https://www.pcgamer.com/i-demand-you-stop-what-youre-doing-and-look-at-this-cute-mac-shaped-charger](https://www.pcgamer.com/i-demand-you-stop-what-youre-doing-and-look-at-this-cute-mac-shaped-charger)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-06-16 19:33:03+00:00

Power your laptop with a charger that looks like an old-school Mac smiling at you.

## Skyrim Grandma shoots down rumors of Starfield NPC appearance: ‘I’m not in the game’
 - [https://www.pcgamer.com/skyrim-grandma-shoots-down-rumors-of-starfield-npc-appearance-im-not-in-the-game](https://www.pcgamer.com/skyrim-grandma-shoots-down-rumors-of-starfield-npc-appearance-im-not-in-the-game)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-06-16 18:51:21+00:00

Shirley Curry really wants to play The Elder Scrolls 6, but she's not so excited for Starfield.

## I felt like a multitasking monster in front of Samsung's new 49-inch OLED ultrawide gaming monitor
 - [https://www.pcgamer.com/i-felt-like-a-multitasking-monster-in-front-of-samsungs-new-49-inch-oled-ultrawide-gaming-monitor](https://www.pcgamer.com/i-felt-like-a-multitasking-monster-in-front-of-samsungs-new-49-inch-oled-ultrawide-gaming-monitor)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-06-16 17:03:14+00:00

The Samsung Odyssey OLED G9 is looking to become the king of the ultrawide.

## Doom creator John Romero finally plays its most mind-blowing mod
 - [https://www.pcgamer.com/doom-creator-john-romero-finally-plays-its-most-mind-blowing-mod](https://www.pcgamer.com/doom-creator-john-romero-finally-plays-its-most-mind-blowing-mod)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-06-16 16:55:42+00:00

Welcome to OurHouse.wad, John.

## I'm so mad that we have to wait for Final Fantasy 16 to release on PC, because it may be one of the best RPGs of the last decade
 - [https://www.pcgamer.com/im-so-mad-that-we-have-to-wait-for-final-fantasy-16-to-release-on-pc-because-it-may-be-one-of-the-best-rpgs-of-the-last-decade](https://www.pcgamer.com/im-so-mad-that-we-have-to-wait-for-final-fantasy-16-to-release-on-pc-because-it-may-be-one-of-the-best-rpgs-of-the-last-decade)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-06-16 15:49:02+00:00

I'm officially a converted sceptic.

## Xbox boss on Redfall studio Arkane Austin staying open: 'That is the plan right now'
 - [https://www.pcgamer.com/xbox-boss-on-redfall-studio-arkane-austin-staying-open-that-is-the-plan-right-now](https://www.pcgamer.com/xbox-boss-on-redfall-studio-arkane-austin-staying-open-that-is-the-plan-right-now)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-06-16 15:46:03+00:00

Matt Booty said he feels "accountable that [Microsoft] could have done a better job with Arkane" during Redfall's development.

## The son of Playboy's founder started an OnlyFans to afford rare Pokémon cards, and I'm a little jealous it's worked out so well
 - [https://www.pcgamer.com/the-son-of-playboys-founder-started-an-onlyfans-to-afford-rare-pokemon-cards-and-im-a-little-jealous-its-worked-out-so-well](https://www.pcgamer.com/the-son-of-playboys-founder-started-an-onlyfans-to-afford-rare-pokemon-cards-and-im-a-little-jealous-its-worked-out-so-well)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-06-16 14:54:22+00:00

Marston Hefner wanted a Ho-Oh, but found a sex-positive Ho-Ome

## Wave goodbye to yet another Diablo 4 power levelling trick as Blizzard releases a World Tier-focused hotfix
 - [https://www.pcgamer.com/wave-goodbye-to-yet-another-diablo-4-power-levelling-trick-as-blizzard-releases-a-world-tier-focused-hotfix](https://www.pcgamer.com/wave-goodbye-to-yet-another-diablo-4-power-levelling-trick-as-blizzard-releases-a-world-tier-focused-hotfix)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-06-16 14:36:31+00:00

Sorry sport, you're gonna have to beat the game if you want to play on World Tier three and four.

## Google ditches web domain business moments after unleashing .zip websites on unsuspecting grandmothers
 - [https://www.pcgamer.com/google-ditches-web-domain-business-moments-after-unleashing-zip-websites-on-unsuspecting-grandmothers](https://www.pcgamer.com/google-ditches-web-domain-business-moments-after-unleashing-zip-websites-on-unsuspecting-grandmothers)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-06-16 13:34:03+00:00

The whole Google web domain shebang is toast.

## All Diablo 4 Unique items and how to get them
 - [https://www.pcgamer.com/diablo-4-unique-items-how-to-get](https://www.pcgamer.com/diablo-4-unique-items-how-to-get)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-06-16 13:26:18+00:00

Master your class with their most powerful gear.

## New Valheim update brings world modifiers, creative mode, and finally lets you see your hair with a helmet on
 - [https://www.pcgamer.com/new-valheim-update-brings-world-modifiers-creative-mode-and-finally-lets-you-see-your-hair-with-a-helmet-on](https://www.pcgamer.com/new-valheim-update-brings-world-modifiers-creative-mode-and-finally-lets-you-see-your-hair-with-a-helmet-on)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-06-16 13:13:44+00:00

The Vi-King of survival games keeps getting better.

## 21 year-old CS:GO pro dies in defense of Ukraine
 - [https://www.pcgamer.com/21-year-old-csgo-pro-dies-in-defense-of-ukraine](https://www.pcgamer.com/21-year-old-csgo-pro-dies-in-defense-of-ukraine)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-06-16 12:34:15+00:00

Ostap 'Oni' Onistrat described by his peers as a national hero.

## Todd Howard says Starfield's 1000+ planets won't be all boring procgen globes and contain more handcrafted work 'than Skyrim and Fallout 4 combined'
 - [https://www.pcgamer.com/todd-howard-says-starfields-1000-planets-wont-be-all-boring-procgen-globes-and-contain-more-handcrafted-work-than-skyrim-and-fallout-4-combined](https://www.pcgamer.com/todd-howard-says-starfields-1000-planets-wont-be-all-boring-procgen-globes-and-contain-more-handcrafted-work-than-skyrim-and-fallout-4-combined)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-06-16 11:32:26+00:00

Bethesda's spacey opus will be chock-full of authored stuff, promises Todd.

## Get your OLED-everywhere-all-the-time fix with this portable monitor
 - [https://www.pcgamer.com/get-your-oled-everywhere-all-the-time-fix-with-this-portable-monitor](https://www.pcgamer.com/get-your-oled-everywhere-all-the-time-fix-with-this-portable-monitor)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-06-16 11:24:05+00:00

It's only 60Hz, but there's still a lot of want.

## Not the tease! Looks like Nicolas Cage may be in a Hideo Kojima game
 - [https://www.pcgamer.com/not-the-tease-looks-like-nicolas-cage-may-be-in-a-hideo-kojima-game](https://www.pcgamer.com/not-the-tease-looks-like-nicolas-cage-may-be-in-a-hideo-kojima-game)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-06-16 11:10:30+00:00

"Thank you for the incredible tour!"

## Don't Nod's latest game is like opening up Life Is Strange and staring at its guts
 - [https://www.pcgamer.com/dont-nods-new-game-is-like-opening-up-life-is-strange-and-staring-at-its-guts](https://www.pcgamer.com/dont-nods-new-game-is-like-opening-up-life-is-strange-and-staring-at-its-guts)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-06-16 10:54:04+00:00

Harmony: The Fall of Reverie is a fascinatingly transparent take on the narrative adventure genre.

## Apple's game porting tool previews a future where a gaming PC isn't necessarily a PC
 - [https://www.pcgamer.com/apples-game-porting-tool-previews-a-future-where-a-gaming-pc-isnt-necessarily-a-pc](https://www.pcgamer.com/apples-game-porting-tool-previews-a-future-where-a-gaming-pc-isnt-necessarily-a-pc)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-06-16 09:28:45+00:00

A chance for gamers to break free from the stranglehold of overpriced GPUs?

## Next generation quantum computing takes a step forward thanks to Intel's new chip
 - [https://www.pcgamer.com/next-generation-quantum-computing-takes-a-step-forward-thanks-to-intels-new-chip](https://www.pcgamer.com/next-generation-quantum-computing-takes-a-step-forward-thanks-to-intels-new-chip)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-06-16 08:27:15+00:00

The 12-qubit chips will help to advance quantum computing research efforts.

## Today's Wordle hint and answer #727: Friday, June 16
 - [https://www.pcgamer.com/wordle-answer-today-hint-727-june-16](https://www.pcgamer.com/wordle-answer-today-hint-727-june-16)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-06-16 04:06:44+00:00

Get all the help you need with today's Wordle.

## Top Nintendo Switch piracy subreddit banned after 3 years
 - [https://www.pcgamer.com/top-nintendo-switch-piracy-subreddit-banned-after-3-years](https://www.pcgamer.com/top-nintendo-switch-piracy-subreddit-banned-after-3-years)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-06-16 00:16:21+00:00

The r/NewYuzuPiracy subreddit was home to hundreds of Zelda: Tears of the Kingdom modding discussions before it was banned on Tuesday.

