# Source:TVN24 Ze świata, URL:https://tvn24.pl/wiadomosci-ze-swiata,2.xml, language:pl-PL

## Samochód dostawczy zderzył się z osobowym. Jedna osoba nie żyje, cztery ranne
 - [https://tvn24.pl/wroclaw/legnica-wypadek-na-drodze-s3-sa-ranni-i-ofiara-smiertelna-7177750?source=rss](https://tvn24.pl/wroclaw/legnica-wypadek-na-drodze-s3-sa-ranni-i-ofiara-smiertelna-7177750?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-06-16 09:34:03+00:00

<img alt="Samochód dostawczy zderzył się z osobowym. Jedna osoba nie żyje, cztery ranne" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-qr5kly-wypadek-w-miejscowosci-senden-maly-zdjecie-ilustracyjne-7166515/alternates/LANDSCAPE_1280" />
    Nie żyje jedna osoba, a cztery kolejne zostały ranne w wypadku, do którego doszło w piątek na drodze S3 koło Legnicy na Dolnym Śląsku. Na ekspresówce samochód dostawczy zderzył się z osobowym, droga jest zablokowana.

## Chcą powrotu tęczy na plac Zbawiciela. "Będzie niezniszczalna, nie da się jej spalić"
 - [https://tvn24.pl/tvnwarszawa/srodmiescie/warszawa-chca-powrotu-teczy-na-plac-zbawiciela-ma-byc-niezniszczalna-7177557?source=rss](https://tvn24.pl/tvnwarszawa/srodmiescie/warszawa-chca-powrotu-teczy-na-plac-zbawiciela-ma-byc-niezniszczalna-7177557?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-06-16 09:22:32+00:00

<img alt="Chcą powrotu tęczy na plac Zbawiciela. " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-993vlr-projekt-teczy-na-placu-zbawiciela-7177530/alternates/LANDSCAPE_1280" />
    - Brakuje jednego symbolu Warszawy, który już zniknął. Jest to tęcza z placu Zbawiciela - twierdzą aktywiści LGBT+. Ich projekt zakłada stworzenie "niezniszczalnej" instalacji i został zgłoszony do budżetu obywatelskiego.

## Magda Gessler w rankingu najcenniejszych kobiecych marek osobistych w Polsce. Ile jest wart jej wizerunek?
 - [https://tvn24.pl/kultura-i-styl/magda-gessler-ile-wart-jej-wizerunek-ranking-najcenniejszych-kobiecych-marek-osobistych-w-polsce-forbes-women-7177596?source=rss](https://tvn24.pl/kultura-i-styl/magda-gessler-ile-wart-jej-wizerunek-ranking-najcenniejszych-kobiecych-marek-osobistych-w-polsce-forbes-women-7177596?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-06-16 09:21:36+00:00

<img alt="Magda Gessler w rankingu najcenniejszych kobiecych marek osobistych w Polsce. Ile jest wart jej wizerunek?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-uhf4gi-image_1024-2-7114219/alternates/LANDSCAPE_1280" />
    14 gwiazd TVN trafiło do czwartego rankingu najcenniejszych kobiecych marek osobistych w Polsce stworzonego przez "Forbes Women" i firmę analityczną PSMM Monitoring & More. Liderką zestawienia jest Iga Świątek, której wizerunek został wyceniony na 988 mln zł (dwa lata temu było to 380 mln zł). Drugie miejsce zajęła Anna Lewandowska (278 mln zł), a trzecie tenisistka Magda Linette (271 mln zł). Magda Gessler znalazła się w pierwszej dziesiątce zestawienia.

## Dostali zgłoszenie o pijanej matce. W mieszkaniu jej nie było, bo wyjechała z dziećmi samochodem
 - [https://tvn24.pl/krakow/jedrzejow-pijana-matka-wiozla-samochodem-dwoje-dzieci-miala-dwa-promile-w-organizmie-7177500?source=rss](https://tvn24.pl/krakow/jedrzejow-pijana-matka-wiozla-samochodem-dwoje-dzieci-miala-dwa-promile-w-organizmie-7177500?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-06-16 09:14:48+00:00

<img alt="Dostali zgłoszenie o pijanej matce. W mieszkaniu jej nie było, bo wyjechała z dziećmi samochodem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ccogfw-kobieta-miala-dwa-promile-alkoholu-w-organizmie-5548245/alternates/LANDSCAPE_1280" />
    Matka z ponad dwoma promilami w organizmie wiozła samochodem dwoje małych dzieci. Policjanci z Jędrzejowa (woj. świętokrzyskie) zatrzymali kobietę po zgłoszeniu o tym, że nietrzeźwa kobieta opiekuje się potomstwem. Gdy mundurowi nie zastali rodziny w mieszkaniu, zaczęli szukać samochodu, którym się oddaliła. Za kierownicą siedziała pijana 36-latka.

## Kliczko: Rosjanie zaatakowali Kijów, nadlatują kolejne pociski
 - [https://tvn24.pl/swiat/witalij-kliczko-rosjanie-ponownie-zaatakowali-kijow-nadlatuja-kolejne-pociski-7177690?source=rss](https://tvn24.pl/swiat/witalij-kliczko-rosjanie-ponownie-zaatakowali-kijow-nadlatuja-kolejne-pociski-7177690?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-06-16 09:12:55+00:00

<img alt="Kliczko: Rosjanie zaatakowali Kijów, nadlatują kolejne pociski" src="https://tvn24.pl/najnowsze/cdn-zdjecie-a7xgo3-kijow-7150244/alternates/LANDSCAPE_1280" />
    W kijowskiej dzielnicy Padół doszło do eksplozji. Nad ukraińską stolicę nadlatują kolejne rosyjskie rakiety - przekazał w piątek mer Kijowa Witalij Kliczko. Wcześniej w większości regionów Ukrainy ogłoszono alarm przeciwlotniczy. Siły powietrzne Ukrainy poinformowały o rosyjskim ataku rakietami Kalibr wyprowadzonym z Morza Czarnego.

## Kiedyś nazywali je "pekinami" i "slumsami". Dziś potrafią zachwycić i mają swój festiwal
 - [https://tvn24.pl/tvnwarszawa/najnowsze/otwock-jozefow-warszawa-festiwal-swidemajer-2023-program-7177287?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/otwock-jozefow-warszawa-festiwal-swidemajer-2023-program-7177287?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-06-16 09:02:06+00:00

<img alt="Kiedyś nazywali je " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-bkvlni-dwa-swidermajery-w-otwocku-wpisane-do-rejestru-zabytkow-5576518/alternates/LANDSCAPE_1280" />
    W piątek startuje dziesiąta edycja Festiwalu Świdermajer. Wydarzenie jest poświęcone tradycyjnej architekturze drewnianej linii otwockiej. Program jest różnorodny, obejmuje m.in. wizyty w zabytkowych domach, plener fotograficzny, spacery historyczne i przyrodnicze, a także koncerty zespołu Raz, Dwa, Trzy czy Natalii Kukulskiej z kwartetem smyczkowym.

## 28-latka udawała 17-latkę, by uczyć się w liceum. Została aresztowana
 - [https://tvn24.pl/swiat/luizjana-28-latka-udawala-nastolatke-i-zapisala-sie-do-liceum-7176806?source=rss](https://tvn24.pl/swiat/luizjana-28-latka-udawala-nastolatke-i-zapisala-sie-do-liceum-7176806?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-06-16 08:57:44+00:00

<img alt="28-latka udawała 17-latkę, by uczyć się w liceum. Została aresztowana" src="https://tvn24.pl/najnowsze/cdn-zdjecie-uxgy8c-korytarz-szkola-shutterstock_1112561213_1-7176847/alternates/LANDSCAPE_1280" />
    Do jednego z liceów w Luizjanie przez niemal cały rok szkolny uczęszczała 28-letnia kobieta, podająca się za 17-latkę. Gdy dyrekcja dowiedziała się o sprawie, zgłosiła ją policji. Aresztowano kobietę oraz jej matkę, która zapisała córkę do szkoły. Ze wstępnych ustaleń śledczych wynika, że 28-latka poszła do liceum, żeby nauczyć się angielskiego.

## Gigant zainwestuje w Polsce ponad 4,5 miliarda dolarów. Pracę ma znaleźć 2 tysiące osób
 - [https://tvn24.pl/biznes/z-kraju/intel-chce-zainwestowac-w-polsce-ponad-45-miliarda-dolarow-prace-ma-znalezc-2-tysiace-osob-7177640?source=rss](https://tvn24.pl/biznes/z-kraju/intel-chce-zainwestowac-w-polsce-ponad-45-miliarda-dolarow-prace-ma-znalezc-2-tysiace-osob-7177640?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-06-16 08:42:49+00:00

<img alt="Gigant zainwestuje w Polsce ponad 4,5 miliarda dolarów. Pracę ma znaleźć 2 tysiące osób" src="https://tvn24.pl/najnowsze/cdn-zdjecie-iggpty-procesor-komputer-shutterstock_1892823829-7177638/alternates/LANDSCAPE_1280" />
    Amerykański koncern Intel planuje budowę w Polsce zakładu integracji i testowania półprzewodników - poinformował koncern w komunikacie. Planowana inwestycja, o łącznej wartości 4,6 miliarda dolarów, pozwoli stworzyć 2 tysiące miejsc pracy w firmie Intel.

## Zwały skał zsunęły się ze zbocza w Szwajcarii. Porwały budynek
 - [https://tvn24.pl/tvnmeteo/swiat/osuwisko-w-szwajcarii-skalna-lawina-zsunela-sie-ze-zbocza-porwala-budynek-7177480?source=rss](https://tvn24.pl/tvnmeteo/swiat/osuwisko-w-szwajcarii-skalna-lawina-zsunela-sie-ze-zbocza-porwala-budynek-7177480?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-06-16 08:34:46+00:00

<img alt="Zwały skał zsunęły się ze zbocza w Szwajcarii. Porwały budynek" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-jvvfhn-osuwisko-nieopodal-wioski-brienz-7177462/alternates/LANDSCAPE_1280" />
    Skalne osuwisko zeszło tuż przy wiosce Brienz we wschodniej Szwajcarii, porywając ze sobą budynek. Od miesiąca miejscowość jest opuszczona, ponieważ w związku z nadchodzącym niebezpieczeństwem mieszkańcy otrzymali nakaz ewakuacji.

## Przyczepka odłączyła się od auta i wjechała w przystanek. Ranna została 16-latka
 - [https://tvn24.pl/lodz/sedziejowice-wypadek-przyczepka-odlaczyla-sie-od-samochodu-i-wjechala-w-16-latke-na-przystanku-ladowal-smiglowiec-lpr-7177608?source=rss](https://tvn24.pl/lodz/sedziejowice-wypadek-przyczepka-odlaczyla-sie-od-samochodu-i-wjechala-w-16-latke-na-przystanku-ladowal-smiglowiec-lpr-7177608?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-06-16 08:31:24+00:00

<img alt="Przyczepka odłączyła się od auta i wjechała w przystanek. Ranna została 16-latka" src="https://tvn24.pl/najnowsze/cdn-zdjecie-v8xst8-wypadek-w-sedziejowicach-7177592/alternates/LANDSCAPE_1280" />
    16-latka trafiła do szpitala po tym, jak na przystanku autobusowym w Sędziejowicach (woj. łódzkie) wjechała w nią odczepiona od jadącego pojazdu przyczepka. Młoda kobieta prawdopodobnie doznała urazu kręgosłupa. Jak informuje policja, do wypadku doszło w wyniku awarii haka w samochodzie.

## Wigilia dniem wolnym od pracy. Zapowiedź ministra
 - [https://tvn24.pl/biznes/z-kraju/wigilia-2023-dniem-wolnym-od-pracy-zakaz-handlu-7177497?source=rss](https://tvn24.pl/biznes/z-kraju/wigilia-2023-dniem-wolnym-od-pracy-zakaz-handlu-7177497?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-06-16 07:36:57+00:00

<img alt="Wigilia dniem wolnym od pracy. Zapowiedź ministra" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ebma17-inflacja-zakupy-sklep-koszyk-drozyzna-6645013/alternates/LANDSCAPE_1280" />
    W tym roku Wigilia po raz pierwszy nie będzie pracująca, choć przypada w niedzielę handlową - poinformował w piątek minister rozwoju i technologii Waldemar Buda. Zmienimy to w tym roku - dodał.

## Analitycy ISW: Rosjanie wycofują wyspecjalizowane jednostki szturmowe
 - [https://tvn24.pl/swiat/analiza-isw-instytut-badan-nad-wojna-rosjanie-wycofuja-wyspecjalizowane-jednostki-szturmowe-7177279?source=rss](https://tvn24.pl/swiat/analiza-isw-instytut-badan-nad-wojna-rosjanie-wycofuja-wyspecjalizowane-jednostki-szturmowe-7177279?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-06-16 07:34:00+00:00

<img alt="Analitycy ISW: Rosjanie wycofują wyspecjalizowane jednostki szturmowe  " src="https://tvn24.pl/najnowsze/cdn-zdjecie-miyst7-rosyjscy-zolnierze-7172258/alternates/LANDSCAPE_1280" />
    Ukraiński wywiad poinformował, że siły rosyjskie zaczynają wycofywać ze służby wyspecjalizowane jednostki szturmowe wielkości kompanii i przenoszą swój personel do formacji ochotniczych. Jak wyjaśnia w najnowszej analizie Instytut Studiów nad Wojną siły rosyjskie zdecydowały się na ten krok między innymi ze względu na problemy kadrowe. ISW zwraca również uwagę, że ukraińskie kontrnatarcie komplikują rosyjskie systemy walki radioelektronicznej.

## 72-latek był oskarżony o zabicie znajomego sztachetą. Sąd skazał go na 10 lat więzienia
 - [https://tvn24.pl/bialystok/gmina-milejczyce-72-latek-byl-oskarzony-o-zabicie-znajomego-sztacheta-sad-skazal-go-na-10-lat-wiezienia-7177354?source=rss](https://tvn24.pl/bialystok/gmina-milejczyce-72-latek-byl-oskarzony-o-zabicie-znajomego-sztacheta-sad-skazal-go-na-10-lat-wiezienia-7177354?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-06-16 07:25:32+00:00

<img alt="72-latek był oskarżony o zabicie znajomego sztachetą. Sąd skazał go na 10 lat więzienia" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1qwz8p-sad-przyjal-ze-72-latek-dzialal-w-stanie-ograniczonej-poczytalnosci-zdjecie-ilustracyjne-7177408/alternates/LANDSCAPE_1280" />
    Według śledczych 72-latek pchnął znajomego nożem w twarz oraz zadał wiele ciosów sztachetą. Później odjechał, zostawiając nieprzytomnego bez pomocy. Ten zmarł wskutek zachłyśnięcia się krwią. Sąd skazał oskarżonego z gminy Milejczyce (woj. podlaskie) na 10 lat więzienia. Przyjął, że działał w stanie ograniczonej poczytalności, stąd też kara ma być wykonywana w systemie terapeutycznym. Wyrok nie jest prawomocny.

## "Konsumenci będą mogli upomnieć się o dodatkowe świadczenia"
 - [https://tvn24.pl/biznes/z-kraju/kredyty-frankowe-mec-gorski-koncepcja-wynagrodzenia-za-korzystanie-z-kapitalu-kredytu-oznacza-dotkliwe-konsekwencje-dla-bankow-7177395?source=rss](https://tvn24.pl/biznes/z-kraju/kredyty-frankowe-mec-gorski-koncepcja-wynagrodzenia-za-korzystanie-z-kapitalu-kredytu-oznacza-dotkliwe-konsekwencje-dla-bankow-7177395?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-06-16 07:20:18+00:00

<img alt="" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-9z8xue-bank-4901067/alternates/LANDSCAPE_1280" />
    Stworzona przez banki koncepcja wynagrodzenia za korzystanie z kapitału kredytu obraca się przeciwko nim i może teraz spowodować dotkliwe konsekwencje dla tych instytucji - skomentował czwartkowy wyrok Trybunału Sprawiedliwości Unii Europejskiej autor pozwu do Trybunału mecenas Radosław Górski.

## Para pojechała na wakacje. Ich ciała znaleziono w pokoju hotelowym
 - [https://tvn24.pl/swiat/meksyk-para-amerykanow-znaleziona-martwa-w-pokoju-hotelowym-7177347?source=rss](https://tvn24.pl/swiat/meksyk-para-amerykanow-znaleziona-martwa-w-pokoju-hotelowym-7177347?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-06-16 07:15:23+00:00

<img alt="Para pojechała na wakacje. Ich ciała znaleziono w pokoju hotelowym" src="https://tvn24.pl/najnowsze/cdn-zdjecie-nked99-meksyk-plaza-los-cerritos-w-dystrykcie-todos-santos-polwysep-kalifornijski-7177422/alternates/LANDSCAPE_1280" />
    Para Amerykanów została odnaleziona martwa w pokoju hotelowym w Meksyku, gdzie przebywali na wakacjach. Według wstępnych ustaleń przyczyną ich śmierci było zatrucie, najprawdopodobniej tlenkiem węgla. - Myśleli, że to zwykłe zatrucie pokarmowe. Nie mieli pojęcia - mówi rodzina zmarłej kobiety.

## Rosja nie wybuduje ambasady przy parlamencie. Decyzja australijskich władz
 - [https://tvn24.pl/swiat/australia-rosja-nie-wybuduje-nowej-ambasady-w-canberze-przy-parlamencie-7177239?source=rss](https://tvn24.pl/swiat/australia-rosja-nie-wybuduje-nowej-ambasady-w-canberze-przy-parlamencie-7177239?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-06-16 07:10:16+00:00

<img alt="Rosja nie wybuduje ambasady przy parlamencie. Decyzja australijskich władz" src="https://tvn24.pl/najnowsze/cdn-zdjecie-n0x7yq-gmach-parlamentu-australii-7177238/alternates/LANDSCAPE_1280" />
    Australijski parlament nie wyraził zgody na budowę nowej ambasady Rosji w pobliżu gmachu parlamentu. Minister spraw wewnętrznych Clare O'Neil oświadczyła, że jej kraj "nie będzie przepraszać" za podejmowanie działań mających na celu zapewnienie bezpieczeństwa Australijczykom. Kreml uznał tę decyzję za działanie "wrogie" i "rusofobiczne".

## "Biparjoy" znaczy "nieszczęście". Cyklon uderzył w ląd
 - [https://tvn24.pl/tvnmeteo/swiat/indie-pakistan-cyklon-biparjoy-uderzyl-w-lad-7177350?source=rss](https://tvn24.pl/tvnmeteo/swiat/indie-pakistan-cyklon-biparjoy-uderzyl-w-lad-7177350?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-06-16 07:01:32+00:00

<img alt="" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-ldrljo-cyklon-uderzyl-w-indyjski-stan-gudzarat-7177388/alternates/LANDSCAPE_1280" />
    Cyklon tropikalny Biparjoy uderzył w nocy w wybrzeże Indii. Zjawisko przyniosło ze sobą porywisty wiatr, który niszczył domy, drogi i infrastrukturę techniczną w stanie Gudźarat. Chociaż żywioł słabnie, wciąż może spowodować ogromne podtopienia za sprawą niesionych przez siebie ulew.

## Papież Franciszek opuścił szpital po operacji
 - [https://tvn24.pl/swiat/papiez-franciszek-opuscil-szpital-po-operacji-7177413?source=rss](https://tvn24.pl/swiat/papiez-franciszek-opuscil-szpital-po-operacji-7177413?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-06-16 07:00:21+00:00

<img alt="Papież Franciszek opuścił szpital po operacji" src="https://tvn24.pl/najnowsze/cdn-zdjecie-l6qk6m-papiez-franciszek-opuscil-szpital-7177472/alternates/LANDSCAPE_1280" />
    Papież Franciszek w piątek rano wyszedł z rzymskiego szpitala. Przeszedł tam operację jamy brzusznej z powodu przepukliny rozetnej. - Dalej żyję - tak papież odpowiedział na pytanie, jak się czuje.

## Zatonęła łódź, zginęli migranci. Dziewięć osób zatrzymanych
 - [https://tvn24.pl/swiat/grecja-zatonela-lodz-z-migrantami-zatrzymania-osob-podejrzanych-o-przemyt-ludzi-7177216?source=rss](https://tvn24.pl/swiat/grecja-zatonela-lodz-z-migrantami-zatrzymania-osob-podejrzanych-o-przemyt-ludzi-7177216?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-06-16 06:20:00+00:00

<img alt="Zatonęła łódź, zginęli migranci. Dziewięć osób zatrzymanych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-j1ptbr-zatrzymano-dziewieciu-egipcjan-w-zwiazku-z-wypadkiem-lodzi-z-migrantami-7177215/alternates/LANDSCAPE_1280" />
    Greckie służby, w związku z tragicznym zatonięciem łodzi migrantów, zatrzymały podejrzanych o zajmowanie się przemytem ludzi. Międzynarodowa Organizacja do spraw Migracji (IOM) szacuje, że nawet setki ludzi mogły utonąć w tym wypadku. "To jedna z najbardziej śmiercionośnych tragedii na Morzu Śródziemnym od dekady" - oświadczyła IOM.

## "1335 interwencji". Renata Szredzińska o przemocy wobec dzieci
 - [https://tvn24.pl/polska/coraz-wiecej-interwencji-w-sprawie-dzieci-z-rodzin-przemocowych-renata-szredzinska-z-fundacji-dajemy-dzieciom-sile-o-statystykach-7177332?source=rss](https://tvn24.pl/polska/coraz-wiecej-interwencji-w-sprawie-dzieci-z-rodzin-przemocowych-renata-szredzinska-z-fundacji-dajemy-dzieciom-sile-o-statystykach-7177332?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-06-16 06:10:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1cjqip-renata-szredzinska-w-jeden-na-jeden-7177313/alternates/LANDSCAPE_1280" />
    Liczby interwencyjnych odebrań dzieci rosną, a liczba niebieskich kart spada - zwracała uwagę w "Jeden na jeden" Renata Szredzińska z Fundacji Dajemy Dzieciom Siłę. - Ostatnie dane mamy za 2021 rok, to było ponad 1335 interwencji - powiedziała, dodając, że "sądy podjęły osiem tysięcy decyzji o pozbawieniu władzy rodzicielskiej".

## Tornado rozerwało domy na strzępy. "Uderzyło w najwrażliwsze miejsce"
 - [https://tvn24.pl/tvnmeteo/swiat/teksas-stany-zjednoczone-tornado-rozerwalo-miasto-7177280?source=rss](https://tvn24.pl/tvnmeteo/swiat/teksas-stany-zjednoczone-tornado-rozerwalo-miasto-7177280?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-06-16 05:57:16+00:00

<img alt="Tornado rozerwało domy na strzępy. " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-ykj220-zniszczenia-po-przejsciu-tornada-w-perryton-7177297/alternates/LANDSCAPE_1280" />
    Tornado uderzyło w czwartek w miasto Perryton w Teksasie. Żywioł całkowicie zniszczył osiedle domów mobilnych i uszkodził siedziby wielu przedsiębiorstw. Jak poinformowały służby ratunkowe, gwałtowna aura przyczyniła się do śmierci co najmniej trzech osób, zaś kilkadziesiąt mieszkańców odniosło rany.

## Szef MSZ Węgier: bez dostaw z Rosji nie bylibyśmy w stanie zaopatrzyć naszego kraju w energię
 - [https://tvn24.pl/swiat/rosja-szef-msz-wegier-bez-dostaw-z-rosji-nie-bylibysmy-dzis-w-stanie-zaopatrzyc-naszego-kraju-w-energie-7177224?source=rss](https://tvn24.pl/swiat/rosja-szef-msz-wegier-bez-dostaw-z-rosji-nie-bylibysmy-dzis-w-stanie-zaopatrzyc-naszego-kraju-w-energie-7177224?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-06-16 05:52:02+00:00

<img alt="Szef MSZ Węgier: bez dostaw z Rosji nie bylibyśmy w stanie zaopatrzyć naszego kraju w energię" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kmq2zn-peter-szijjarto-5845199/alternates/LANDSCAPE_1280" />
    Minister spraw zagranicznych i handlu Węgier Peter Szijjarto podczas Międzynarodowego Forum Ekonomicznego w Petersburgu przyznał, że władze w Budapeszcie nie byłby w stanie zaopatrzyć kraju w energię bez dostaw z Rosji. W jego ocenie dostawy energii powinny być traktowane "nie jako kwestia ideologiczna, a jako fizyczna".

## Prezydent Duda rozmawiał z przywódcami krajów afrykańskich o sytuacji na Ukrainie
 - [https://tvn24.pl/polska/rpa-zambia-komory-prezydent-duda-rozmawial-z-przywodcami-krajow-afrykanskich-o-sytuacji-na-ukrainie-7177241?source=rss](https://tvn24.pl/polska/rpa-zambia-komory-prezydent-duda-rozmawial-z-przywodcami-krajow-afrykanskich-o-sytuacji-na-ukrainie-7177241?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-06-16 05:45:07+00:00

<img alt="Prezydent Duda rozmawiał z przywódcami krajów afrykańskich o sytuacji na Ukrainie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-nq4dru-prezydent-duda-spotkal-sie-z-przywodcami-republiki-poludniowej-afryki-zambii-i-komorow-7177240/alternates/LANDSCAPE_1280" />
    Sytuacja na Ukrainie, wsparcie Kijowa i rosyjskie zbrodnie wojenne były przedmiotem przeprowadzonych w czwartek rozmów prezydenta Polski z przywódcami Republiki Południowej Afryki, Zambii i Komorów. "Prezydent Andrzej Duda przedstawił naszą perspektywę na rosyjską agresję na Ukrainie" - poinformowała Kancelaria Prezydenta RP.

## Tragiczny wypadek w Kanadzie. Co najmniej 15 osób zginęło
 - [https://tvn24.pl/swiat/kanada-zderzenie-ciezarowki-z-minibusem-zabici-i-ranni-7177257?source=rss](https://tvn24.pl/swiat/kanada-zderzenie-ciezarowki-z-minibusem-zabici-i-ranni-7177257?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-06-16 05:15:52+00:00

<img alt="Tragiczny wypadek w Kanadzie. Co najmniej 15 osób zginęło" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ag9gfp-zderzenie-ciezarowki-z-minibusem-w-kanadzie-7177258/alternates/LANDSCAPE_1280" />
    Co najmniej 15 osób zginęło, a 10 zostało rannych w wypadku w prowincji Manitoba w Kanadzie. Doszło tam do zderzenia ciężarówki z przyczepą z minibusem przewożącym osoby starsze - poinformowała policja.

## Napadli na jego sklep, chwycił za nóż. Prokuratura: działał w obronie koniecznej
 - [https://tvn24.pl/tvnwarszawa/okolice/kobylka-napad-na-sklep-sprawca-ugodzony-nozem-przez-wlasciciela-obrona-konieczna-7176250?source=rss](https://tvn24.pl/tvnwarszawa/okolice/kobylka-napad-na-sklep-sprawca-ugodzony-nozem-przez-wlasciciela-obrona-konieczna-7176250?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-06-16 05:10:19+00:00

<img alt="Napadli na jego sklep, chwycił za nóż. Prokuratura: działał w obronie koniecznej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1n2ejp-napad-na-sklep-w-kobylce-6623248/alternates/LANDSCAPE_1280" />
    Prokuratura zakończyła śledztwo w sprawie napadu na sklep w Kobyłce. Właściciel, który ugodził śmiertelnie nożem jednego z napastników nie zasiądzie na ławie oskarżonych. Według śledczych działał w obronie koniecznej. Postanowienie o umorzeniu sprawy nie jest prawomocne.

## Wyniki Lotto z 15 czerwca 2023. Jakie liczby padły podczas ostatniego losowania?
 - [https://tvn24.pl/biznes/pieniadze/wyniki-lotto-z-dnia150623-liczby-z-ostatniego-losowania-7177271?source=rss](https://tvn24.pl/biznes/pieniadze/wyniki-lotto-z-dnia150623-liczby-z-ostatniego-losowania-7177271?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-06-16 05:02:55+00:00

<img alt="Wyniki Lotto z 15 czerwca 2023. Jakie liczby padły podczas ostatniego losowania?" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjeciedfcd1798e8d43d2929d0e92a28daff32-lotto-16-jpg-3815826/alternates/LANDSCAPE_1280" />
    W czwartek w Lotto padła główna wygrana. Do zwycięzcy trafi aż 2,3 miliona złotych. Oto wyniki Lotto oraz Lotto Plus z dnia 15 czerwca 2023 roku.

## "Flash" od dziś w kinach. Recenzenci chwalą długo oczekiwany film
 - [https://tvn24.pl/kultura-i-styl/flash-kiedy-premiera-o-czym-jest-obsada-recenzje-7174495?source=rss](https://tvn24.pl/kultura-i-styl/flash-kiedy-premiera-o-czym-jest-obsada-recenzje-7174495?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-06-16 05:00:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-sgelb3-flash-trafi-do-kin-16-czerwca-7174541/alternates/LANDSCAPE_1280" />
    W najnowszym filmie DC Studios dochodzi do pokoleniowej wymiany. Dawni superbohaterowie nie stają na wysokości zadania, w ich buty muszą wejść młodsi następcy. Długo oczekiwany "Flash" kilka dni temu miał światową premierę, a od 16 czerwca można go oglądać w kinach, również w Polsce.

## Al Pacino został ojcem po raz czwarty
 - [https://tvn24.pl/kultura-i-styl/al-pacino-zostal-ojcem-po-raz-czwarty-aktorowi-urodzil-sie-syn-7177255?source=rss](https://tvn24.pl/kultura-i-styl/al-pacino-zostal-ojcem-po-raz-czwarty-aktorowi-urodzil-sie-syn-7177255?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-06-16 04:55:49+00:00

<img alt="Al Pacino został ojcem po raz czwarty" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hokdy4-al-pacino-7153054/alternates/LANDSCAPE_1280" />
    Al Pacino po raz czwarty został ojcem - poinformował w czwartek AFP jego agent. Partnerka 83-letniego aktora Noor Alfallah urodziła chłopca.

## Alerty dla 11 województw. IMGW ostrzega przed ulewami i burzami z gradem
 - [https://tvn24.pl/tvnmeteo/prognoza/alerty-imgw-burze-z-gradem-i-intensywny-deszcz-w-piatek-1606-7177261?source=rss](https://tvn24.pl/tvnmeteo/prognoza/alerty-imgw-burze-z-gradem-i-intensywny-deszcz-w-piatek-1606-7177261?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-06-16 04:47:04+00:00

<img alt="Alerty dla 11 województw. IMGW ostrzega przed ulewami i burzami z gradem" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-2mvp47-intensywne-opady-deszczu-z-burzami-5203747/alternates/LANDSCAPE_1280" />
    IMGW wydał alarmy meteorologiczne. W piątek w niektórych regionach towarzyszyć nam będą burze z gradem i silnymi porywami wiatru, lokalnie osiągającymi prędkość do 70 kilometrów na godzinę. Mieszkańcy pięciu województw powinni natomiast przygotować się na intensywne opady deszczu, które potrwają do soboty.

## Arkadiusz Wierzuk zdobył Polsko-Niemiecką Nagrodę Dziennikarską imienia Tadeusza Mazowieckiego
 - [https://tvn24.pl/polska/arkadiusz-wierzuk-zdobyl-polsko-niemiecka-nagrode-dziennikarska-imienia-tadeusza-mazowieckiego-7177220?source=rss](https://tvn24.pl/polska/arkadiusz-wierzuk-zdobyl-polsko-niemiecka-nagrode-dziennikarska-imienia-tadeusza-mazowieckiego-7177220?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-06-16 04:12:00+00:00

<img alt="Arkadiusz Wierzuk zdobył Polsko-Niemiecką Nagrodę Dziennikarską imienia Tadeusza Mazowieckiego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-a4idf5-dziennikarz-tvn24-arkadiusz-wierzuk-zostal-wyrozniony-za-reportaz-niemieckie-dylematy-7177217/alternates/LANDSCAPE_1280" />
    Reporter TVN24 Arkadiusz Wierzuk zdobył Polsko-Niemiecką Nagrodę Dziennikarską im. Tadeusza Mazowieckiego. Gala odbyła się w środę wieczorem w Teatrze Lubuskim w Zielonej Górze.

## Sejm debatował nad obywatelskim projektem o refundacji in vitro
 - [https://tvn24.pl/polska/sejm-debatowal-nad-obywatelskim-projektem-o-refundacji-in-vitro-malgorzata-rozenek-majdan-w-sejmie-7177234?source=rss](https://tvn24.pl/polska/sejm-debatowal-nad-obywatelskim-projektem-o-refundacji-in-vitro-malgorzata-rozenek-majdan-w-sejmie-7177234?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-06-16 04:00:24+00:00

<img alt="Sejm debatował nad obywatelskim projektem o refundacji in vitro" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wdgsgd-malgorzata-rozenek-majdan-wystapila-jako-przedstawicielka-komitetu-inicjatywy-ustawodawczej-7177233/alternates/LANDSCAPE_1280" />
    Obywatelski projekt ustawy o refundacji in vitro trafi do komisji zdrowia. W czwartek późno wieczorem na sali plenarnej podczas pierwszego czytania dyskutowano o jego celowości. Jako przedstawicielka inicjatywy ustawodawczej głos zabrała między innymi Małgorzata Rozenek-Majdan.

## Analitycy ISW: Rosjanie wycofują wyspecjalizowane jednostki szturmowe
 - [https://tvn24.pl/swiat/wojna-rosja-ukraina-relacja-na-zywo-z-16-czerwca-2023-7177251?source=rss](https://tvn24.pl/swiat/wojna-rosja-ukraina-relacja-na-zywo-z-16-czerwca-2023-7177251?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-06-16 03:45:00+00:00

<img alt="Analitycy ISW: Rosjanie wycofują wyspecjalizowane jednostki szturmowe " src="https://tvn24.pl/najnowsze/cdn-zdjecie-miyst7-rosyjscy-zolnierze-7172258/alternates/LANDSCAPE_1280" />
    Inwazja zbrojna Rosji na Ukrainę trwa od 478 dni. Ukraiński wywiad poinformował, że siły rosyjskie zaczynają wycofywać ze służby wyspecjalizowane jednostki szturmowe wielkości kompanii i przenoszą swój personel do formacji ochotniczych - poinformował Instytut Studiów nad Wojną. Amerykański think tank wyjaśnia, że siły rosyjskie zdecydowały się na ten krok między innymi ze względu na problemy kadrowe. W tvn24.pl relacjonujemy wydarzenia z i wokół Ukrainy.

## Ukraina walczy. Najważniejsze wydarzenia ostatnich godzin
 - [https://tvn24.pl/swiat/ukraina-walczy-najwazniejsze-wydarzenia-ostatnich-godzin-15-czerwca-2023-7177250?source=rss](https://tvn24.pl/swiat/ukraina-walczy-najwazniejsze-wydarzenia-ostatnich-godzin-15-czerwca-2023-7177250?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-06-16 03:15:00+00:00

<img alt="Ukraina walczy. Najważniejsze wydarzenia ostatnich godzin" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qaxmof-ukraina-wojsko-7175213/alternates/LANDSCAPE_1280" />
    Rosyjska inwazja na Ukrainę trwa od 478 dni. Specjalna sprawozdawczyni ONZ do spraw tortur, Alice Jill Edwards alarmowała, że rosyjskie wojsko na Ukrainie dopuszcza się "powszechnego "stosowania fizycznych i psychicznych tortur wobec cywilów i jeńców wojennych. Oto najważniejsze wydarzenia ostatnich godzin.

