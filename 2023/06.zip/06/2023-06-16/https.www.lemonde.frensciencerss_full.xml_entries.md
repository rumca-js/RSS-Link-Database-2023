# Source:Le Monde - science, URL:https://www.lemonde.fr/en/science/rss_full.xml, language:en-US

## Final launch of Europe's Ariane 5 rocket postponed
 - [https://www.lemonde.fr/en/science/article/2023/06/16/final-launch-of-europe-s-ariane-5-rocket-postponed_6032495_10.html](https://www.lemonde.fr/en/science/article/2023/06/16/final-launch-of-europe-s-ariane-5-rocket-postponed_6032495_10.html)
 - RSS feed: https://www.lemonde.fr/en/science/rss_full.xml
 - date published: 2023-06-16 01:55:19+00:00

The postponement is due to a technical problem, French firm Arianespace said on Thursday. It comes as Europe struggles to find a way to independently blast heavy-load missions into space due to repeated delays for the next-generation Ariane 6.

