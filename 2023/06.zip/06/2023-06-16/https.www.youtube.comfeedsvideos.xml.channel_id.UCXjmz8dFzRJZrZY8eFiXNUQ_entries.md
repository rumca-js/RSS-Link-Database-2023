# Source:Nerdstalgic, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXjmz8dFzRJZrZY8eFiXNUQ, language:en-US

## Neighbors Changed Everything For Zac Efron
 - [https://www.youtube.com/watch?v=Mh-shm_UMb4](https://www.youtube.com/watch?v=Mh-shm_UMb4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXjmz8dFzRJZrZY8eFiXNUQ
 - date published: 2023-06-16 17:00:11+00:00

Build a team of your favorite characters and explore Middle-earth like never before! Download for free here- https://bit.ly/NLOTR
Thanks to EA for sponsoring!

Zac Efron was once an actor seemingly stuck in the publics image as, that kid from High School Musical.  Though as years progressed, Zac Efron set out to prove he was capable of so much more than playing a teenage heartthrob.  Starring in the comedy Neighbors alongside Seth Rogen, Rose Byrne, and Dave Franco was that start of a major shift in the roles Zac Efron would be offered.  Proving to the movie going public that he was a real talent, and was not about to be typecasted the rest of his life. 

#zacefron #neighbors #nerdstalgic 

SOURCES
https://screenrant.com/zac-efron-career-evolution-high-school-musical-ted-bundy/ 
https://metro.co.uk/2021/08/09/zac-efron-cast-as-ted-bundy-because-hes-beloved-and-trusted-15054594/ 
https://www.usatoday.com/story/life/people/2014/05/06/zac-efron-sends-up-his-image-in-neighbors/8609967/

