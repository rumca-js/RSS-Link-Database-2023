# Source:The Washington Post - Tech, URL:https://feeds.washingtonpost.com/rss/business/technology, language:en-US

## What you should know about the MOVEit ransomware attack
 - [https://www.washingtonpost.com/technology/2023/06/16/moveit-ransomware-attack/](https://www.washingtonpost.com/technology/2023/06/16/moveit-ransomware-attack/)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-06-16 20:59:01+00:00

U.S. officials are still assessing the impact of the attack.

## The do’s and don’ts of posting photos of your kid on social media
 - [https://www.washingtonpost.com/technology/2023/06/16/parents-posting-kids-social-media/](https://www.washingtonpost.com/technology/2023/06/16/parents-posting-kids-social-media/)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-06-16 16:30:00+00:00

Consider asking your child’s permission before you post and other guidelines for parents.

## Reddit CEO compares moderators to aristocracy as blackout stretches on
 - [https://www.washingtonpost.com/technology/2023/06/16/reddit-ceo-blackout-moderators-steve-huffman/](https://www.washingtonpost.com/technology/2023/06/16/reddit-ceo-blackout-moderators-steve-huffman/)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-06-16 16:25:22+00:00

Reddit CEO Steve Huffman slammed the unpaid volunteer moderators leading protests over Reddit's push to charge money to third-party apps.

## In a first, FTC charges genetic testing firm over failure to protect data
 - [https://www.washingtonpost.com/business/2023/06/16/ftc-genetic-testing-vitagene/](https://www.washingtonpost.com/business/2023/06/16/ftc-genetic-testing-vitagene/)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-06-16 15:59:04+00:00

The Federal Trade Commission faulted 1Helath.io, formerly known as Vitagene, with failing to protect consumers' genetic information.

## Anyone can Photoshop now, thanks to AI’s latest leap
 - [https://www.washingtonpost.com/technology/2023/06/16/ai-photoshop-generative-fill-review/](https://www.washingtonpost.com/technology/2023/06/16/ai-photoshop-generative-fill-review/)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-06-16 10:00:00+00:00

A new “generative fill” AI capability can both create joyful Photoshop edits — and frightening deepfakes.

