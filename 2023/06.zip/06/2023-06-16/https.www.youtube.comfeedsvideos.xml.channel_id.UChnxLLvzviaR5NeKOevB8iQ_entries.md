# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## Befaco Pony TZFM
 - [https://www.youtube.com/watch?v=okswIxw9FlQ](https://www.youtube.com/watch?v=okswIxw9FlQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2023-06-16 15:42:51+00:00

Through-zero fm, baby. Learn what it is here: https://youtu.be/84cEaWfP9m8

Befaco Pony TZFM Oscillator with help from SSF Zephyr, going into Endorphines Ghost. Drums by Modbap Trininty into Noise Engineering Ruina and Desmodus Versio.

Join me on Patreon and get access to music, presets, samples, and a great community: http://bit.ly/rmrpatreon

Take a lesson with me: https://rmr.media/education

Find my music here: 
Bandcamp: http://bit.ly/2Kq617o
Spotify: https://spoti.fi/2N40SoX
YouTube Music: https://bit.ly/3PZQ4ol
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

Merch: http://bit.ly/rmrshirts

Connect:
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia

