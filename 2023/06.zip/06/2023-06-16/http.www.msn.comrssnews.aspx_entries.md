# Source:MSN, URL:http://www.msn.com/rss/news.aspx, language:en-US

## Florida squatter arrested after homeowner returns from trip abroad
 - [https://www.msn.com/en-us/news/crime/florida-squatter-arrested-after-homeowner-returns-from-trip-abroad/ar-AA1cENkH?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/crime/florida-squatter-arrested-after-homeowner-returns-from-trip-abroad/ar-AA1cENkH?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 23:50:45.431990+00:00



## Ukraine Calls Russian Missile Attack on Kyiv 'Message to Africa'
 - [https://www.msn.com/en-us/news/world/ukraine-calls-russian-missile-attack-on-kyiv-message-to-africa/ar-AA1cEJSP?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/ukraine-calls-russian-missile-attack-on-kyiv-message-to-africa/ar-AA1cEJSP?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 23:50:45.430097+00:00



## Minneapolis police continued to use neck restrainings after Floyd's death, DOJ finds
 - [https://www.msn.com/en-us/news/us/minneapolis-police-continued-to-use-neck-restrainings-after-floyd-s-death-doj-finds/ar-AA1cDVe5?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/minneapolis-police-continued-to-use-neck-restrainings-after-floyd-s-death-doj-finds/ar-AA1cDVe5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 23:50:45.428257+00:00



## Biden ends speech in Connecticut with ‘God save the queen, man’
 - [https://www.msn.com/en-us/news/politics/biden-ends-speech-in-connecticut-with-god-save-the-queen-man/ar-AA1cELh3?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/biden-ends-speech-in-connecticut-with-god-save-the-queen-man/ar-AA1cELh3?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 23:50:45.426968+00:00



## Health care providers in North Carolina file lawsuit against state over abortion restrictions
 - [https://www.msn.com/en-us/news/politics/health-care-providers-in-north-carolina-file-lawsuit-against-state-over-abortion-restrictions/ar-AA1cEQhQ?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/health-care-providers-in-north-carolina-file-lawsuit-against-state-over-abortion-restrictions/ar-AA1cEQhQ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 23:50:45.425517+00:00



## Pence jabs at GOP opponents, calling promises to pardon Trump 'premature'
 - [https://www.msn.com/en-us/news/politics/pence-jabs-at-gop-opponents-calling-promises-to-pardon-trump-premature/ar-AA1cF0iU?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/pence-jabs-at-gop-opponents-calling-promises-to-pardon-trump-premature/ar-AA1cF0iU?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 23:50:45.423473+00:00



## Mississippi GOP governor and Democratic challenger spar over crime, courts and trans care
 - [https://www.msn.com/en-us/news/politics/mississippi-gop-governor-and-democratic-challenger-spar-over-crime-courts-and-trans-care/ar-AA1cEXNk?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/mississippi-gop-governor-and-democratic-challenger-spar-over-crime-courts-and-trans-care/ar-AA1cEXNk?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 23:50:45.421382+00:00



## Ticketmaster and Airbnb Help White House Effort to End Hidden Fees
 - [https://www.msn.com/en-us/news/technology/ticketmaster-and-airbnb-help-white-house-effort-to-end-hidden-fees/ar-AA17AtQm?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/technology/ticketmaster-and-airbnb-help-white-house-effort-to-end-hidden-fees/ar-AA17AtQm?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 22:35:35.434250+00:00



## Students Protest School's Transgender Bathroom Rules
 - [https://www.msn.com/en-us/news/us/students-protest-school-s-transgender-bathroom-rules/ar-AA1cESEf?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/students-protest-school-s-transgender-bathroom-rules/ar-AA1cESEf?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 22:35:35.432395+00:00



## 'The Big Guy' sure is acting guilty
 - [https://www.msn.com/en-us/news/politics/the-big-guy-sure-is-acting-guilty/ar-AA1cEGqr?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/the-big-guy-sure-is-acting-guilty/ar-AA1cEGqr?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 22:35:35.430587+00:00



## Family Slams School After Dancing Student Denied Diploma
 - [https://www.msn.com/en-us/news/us/family-slams-school-after-dancing-student-denied-diploma/ar-AA1cEJ5s?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/family-slams-school-after-dancing-student-denied-diploma/ar-AA1cEJ5s?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 22:35:35.428746+00:00



## After a pause, Biden and Harris accelerate campaign cash dash
 - [https://www.msn.com/en-us/news/politics/after-a-pause-biden-and-harris-accelerate-campaign-cash-dash/ar-AA1cEBRI?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/after-a-pause-biden-and-harris-accelerate-campaign-cash-dash/ar-AA1cEBRI?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 22:35:35.426850+00:00



## Suarez hints at willingness to consider pardoning Trump if elected president
 - [https://www.msn.com/en-us/news/politics/suarez-hints-at-willingness-to-consider-pardoning-trump-if-elected-president/ar-AA1cENdX?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/suarez-hints-at-willingness-to-consider-pardoning-trump-if-elected-president/ar-AA1cENdX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 22:35:35.424994+00:00



## Special counsel asks judge to keep Trump from disclosing evidence in documents case
 - [https://www.msn.com/en-us/news/politics/special-counsel-asks-judge-to-keep-trump-from-disclosing-evidence-in-documents-case/ar-AA1cEGpl?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/special-counsel-asks-judge-to-keep-trump-from-disclosing-evidence-in-documents-case/ar-AA1cEGpl?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 22:35:35.423133+00:00



## In a warning to the West, Putin says Russian tactical nukes are being put in Belarus to stop a 'strategic defeat'
 - [https://www.msn.com/en-us/news/world/in-a-warning-to-the-west-putin-says-russian-tactical-nukes-are-being-put-in-belarus-to-stop-a-strategic-defeat/ar-AA1cENht?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/in-a-warning-to-the-west-putin-says-russian-tactical-nukes-are-being-put-in-belarus-to-stop-a-strategic-defeat/ar-AA1cENht?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 22:35:35.420910+00:00



## Reddit CEO says app founders who are shutting down in protest over API charges made millions: 'These aren't like side projects or charities'
 - [https://www.msn.com/en-us/news/technology/reddit-ceo-says-app-founders-who-are-shutting-down-in-protest-over-api-charges-made-millions-these-aren-t-like-side-projects-or-charities/ar-AA1cEB6K?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/technology/reddit-ceo-says-app-founders-who-are-shutting-down-in-protest-over-api-charges-made-millions-these-aren-t-like-side-projects-or-charities/ar-AA1cEB6K?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 21:20:28.775811+00:00



## A damning new DOJ report accuses the Minneapolis Police Department of civil rights abuses
 - [https://www.msn.com/en-us/news/us/a-damning-new-doj-report-accuses-the-minneapolis-police-department-of-civil-rights-abuses/ar-AA1cEweQ?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/a-damning-new-doj-report-accuses-the-minneapolis-police-department-of-civil-rights-abuses/ar-AA1cEweQ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 21:20:28.774031+00:00



## Daniel Ellsberg, Pentagon Papers leaker, dies at 92
 - [https://www.msn.com/en-us/news/politics/daniel-ellsberg-pentagon-papers-leaker-dies-at-92/ar-AA1cEzmG?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/daniel-ellsberg-pentagon-papers-leaker-dies-at-92/ar-AA1cEzmG?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 21:20:28.772264+00:00



## Oath Keepers lawyer's trial delayed for competency treatment
 - [https://www.msn.com/en-us/news/crime/oath-keepers-lawyer-s-trial-delayed-for-competency-treatment/ar-AA1cEk5z?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/crime/oath-keepers-lawyer-s-trial-delayed-for-competency-treatment/ar-AA1cEk5z?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 21:20:28.770493+00:00



## Anti-Transgender Boycotts Go International: 'Bud Light Moment'
 - [https://www.msn.com/en-us/news/us/anti-transgender-boycotts-go-international-bud-light-moment/ar-AA1cEIEb?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/anti-transgender-boycotts-go-international-bud-light-moment/ar-AA1cEIEb?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 21:20:28.768640+00:00



## Female GOP voters more likely to support Trump over DeSantis: Poll
 - [https://www.msn.com/en-us/news/politics/female-gop-voters-more-likely-to-support-trump-over-desantis-poll/ar-AA1cEmmV?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/female-gop-voters-more-likely-to-support-trump-over-desantis-poll/ar-AA1cEmmV?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 21:20:28.766898+00:00



## Jamal Khashoggi's widow speaks out
 - [https://www.msn.com/en-us/news/world/jamal-khashoggi-s-widow-speaks-out/ar-AA1cErQD?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/jamal-khashoggi-s-widow-speaks-out/ar-AA1cErQD?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 21:20:28.765427+00:00



## Sununu ‘not leaning towards’ running for governor again
 - [https://www.msn.com/en-us/news/politics/sununu-not-leaning-towards-running-for-governor-again/ar-AA1cEkcb?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/sununu-not-leaning-towards-running-for-governor-again/ar-AA1cEkcb?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 21:20:28.763281+00:00



## Venezuela Opposition Shuns Electoral Authority for Primaries
 - [https://www.msn.com/en-us/news/world/venezuela-opposition-shuns-electoral-authority-for-primaries/ar-AA1cEbgE?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/venezuela-opposition-shuns-electoral-authority-for-primaries/ar-AA1cEbgE?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 20:05:18.899536+00:00



## Meet the drag nuns caught up in the culture war over Pride events
 - [https://www.msn.com/en-us/news/us/meet-the-drag-nuns-caught-up-in-the-culture-war-over-pride-events/ar-AA1cEtky?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/meet-the-drag-nuns-caught-up-in-the-culture-war-over-pride-events/ar-AA1cEtky?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 20:05:18.897618+00:00



## Trump-friendly nomination proposal was bolstered by RNC: Michigan GOP official
 - [https://www.msn.com/en-us/news/politics/trump-friendly-nomination-proposal-was-bolstered-by-rnc-michigan-gop-official/ar-AA1cEder?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/trump-friendly-nomination-proposal-was-bolstered-by-rnc-michigan-gop-official/ar-AA1cEder?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 20:05:18.895811+00:00



## Hunter Biden investigation: President’s son appears for court-ordered deposition in Arkansas
 - [https://www.msn.com/en-us/news/politics/hunter-biden-investigation-president-s-son-appears-for-court-ordered-deposition-in-arkansas/ar-AA1cED9E?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/hunter-biden-investigation-president-s-son-appears-for-court-ordered-deposition-in-arkansas/ar-AA1cED9E?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 20:05:18.893830+00:00



## Georgia and New Hampshire's places in limbo as Democrats hammer out 2024 primary order
 - [https://www.msn.com/en-us/news/politics/georgia-and-new-hampshire-s-places-in-limbo-as-democrats-hammer-out-2024-primary-order/ar-AA1cEI1Q?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/georgia-and-new-hampshire-s-places-in-limbo-as-democrats-hammer-out-2024-primary-order/ar-AA1cEI1Q?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 20:05:18.892079+00:00



## Biden goes quiet on killing off the debt ceiling
 - [https://www.msn.com/en-us/news/politics/biden-goes-quiet-on-killing-off-the-debt-ceiling/ar-AA1cElJ9?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/biden-goes-quiet-on-killing-off-the-debt-ceiling/ar-AA1cElJ9?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 20:05:18.890290+00:00



## Republicans play offense on student loans ahead of SCOTUS decision
 - [https://www.msn.com/en-us/news/politics/republicans-play-offense-on-student-loans-ahead-of-scotus-decision/ar-AA1cE4tZ?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/republicans-play-offense-on-student-loans-ahead-of-scotus-decision/ar-AA1cE4tZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 20:05:18.888312+00:00



## When a school bus shortage made his son late to school, one dad stepped up
 - [https://www.msn.com/en-us/news/us/when-a-school-bus-shortage-made-his-son-late-to-school-one-dad-stepped-up/ar-AA1cEvK7?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/when-a-school-bus-shortage-made-his-son-late-to-school-one-dad-stepped-up/ar-AA1cEvK7?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 20:05:18.886145+00:00



## Japan raises the age of sexual consent to 16 from 13, which was among the world's lowest
 - [https://www.msn.com/en-us/news/world/japan-raises-the-age-of-sexual-consent-to-16-from-13-which-was-among-the-world-s-lowest/ar-AA1cEnnJ?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/japan-raises-the-age-of-sexual-consent-to-16-from-13-which-was-among-the-world-s-lowest/ar-AA1cEnnJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 18:50:43.519939+00:00



## Women Shoved Into Ravine at German Castle ID’d as Recent University Graduates
 - [https://www.msn.com/en-us/news/crime/women-shoved-into-ravine-at-german-castle-id-d-as-recent-university-graduates/ar-AA1cEsqe?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/crime/women-shoved-into-ravine-at-german-castle-id-d-as-recent-university-graduates/ar-AA1cEsqe?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 18:50:43.518127+00:00



## Biden brings back operative who sexually harassed and threatened to 'destroy' female journalist
 - [https://www.msn.com/en-us/news/politics/biden-brings-back-operative-who-sexually-harassed-and-threatened-to-destroy-female-journalist/ar-AA1cExMP?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/biden-brings-back-operative-who-sexually-harassed-and-threatened-to-destroy-female-journalist/ar-AA1cExMP?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 18:50:43.516395+00:00



## Fox Host Rejects Top Republican's 'Impossible' Immigration Plan
 - [https://www.msn.com/en-us/news/politics/fox-host-rejects-top-republican-s-impossible-immigration-plan/ar-AA1cEl9A?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/fox-host-rejects-top-republican-s-impossible-immigration-plan/ar-AA1cEl9A?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 18:50:43.514663+00:00



## As Blinken departs for Beijing, US officials 'clear-eyed' about China
 - [https://www.msn.com/en-us/news/world/as-blinken-departs-for-beijing-us-officials-clear-eyed-about-china/ar-AA1cCw4Y?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/as-blinken-departs-for-beijing-us-officials-clear-eyed-about-china/ar-AA1cCw4Y?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 18:50:43.513233+00:00



## Jayland Walker's family sues officers and city, alleging excessive force
 - [https://www.msn.com/en-us/news/crime/jayland-walker-s-family-sues-officers-and-city-alleging-excessive-force/ar-AA1cEciv?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/crime/jayland-walker-s-family-sues-officers-and-city-alleging-excessive-force/ar-AA1cEciv?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 18:50:43.511520+00:00



## GOP lawmaker says staffer was attacked by armed gunman after congressional baseball game
 - [https://www.msn.com/en-us/news/politics/gop-lawmaker-says-staffer-was-attacked-by-armed-gunman-after-congressional-baseball-game/ar-AA1cEhAK?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/gop-lawmaker-says-staffer-was-attacked-by-armed-gunman-after-congressional-baseball-game/ar-AA1cEhAK?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 18:50:43.510104+00:00



## Daniel Ellsberg, Pentagon Papers whistleblower, dies at 92
 - [https://www.msn.com/en-us/news/us/daniel-ellsberg-pentagon-papers-whistleblower-dies-at-92/ar-AA1cExQ7?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/daniel-ellsberg-pentagon-papers-whistleblower-dies-at-92/ar-AA1cExQ7?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 18:50:43.508434+00:00



## Musk Warns of Artificial Intelligence Risks Without Regulation
 - [https://www.msn.com/en-us/money/other/musk-warns-of-artificial-intelligence-risks-without-regulation/vi-AA1cEaUb?srcref=rss](https://www.msn.com/en-us/money/other/musk-warns-of-artificial-intelligence-risks-without-regulation/vi-AA1cEaUb?srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 17:33:15.959124+00:00



## A Michigan school cut a 7-year-old biracial girl's hair, but she won in the end
 - [https://www.msn.com/en-us/news/us/a-michigan-school-cut-a-7-year-old-biracial-girl-s-hair-but-she-won-in-the-end/ar-AA1cDWE2?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/a-michigan-school-cut-a-7-year-old-biracial-girl-s-hair-but-she-won-in-the-end/ar-AA1cDWE2?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 17:33:15.957253+00:00



## How many people are watching Tucker Carlson’s new show on Twitter?
 - [https://www.msn.com/en-us/news/us/how-many-people-are-watching-tucker-carlson-s-new-show-on-twitter/ar-AA1cDZps?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/how-many-people-are-watching-tucker-carlson-s-new-show-on-twitter/ar-AA1cDZps?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 17:33:15.955554+00:00



## Eric Schmidt Buys Abandoned Alfa Nero Superyacht for $67.6 Million
 - [https://www.msn.com/en-us/money/companies/eric-schmidt-buys-abandoned-alfa-nero-superyacht-for-67-6-million/ar-AA1cE0Lm?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/money/companies/eric-schmidt-buys-abandoned-alfa-nero-superyacht-for-67-6-million/ar-AA1cE0Lm?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 17:33:15.954190+00:00



## I Ditched My Android for an iPhone, and I Don't Regret It
 - [https://www.msn.com/en-us/news/technology/i-ditched-my-android-for-an-iphone-and-i-don-t-regret-it/ar-AA13Cbk5?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/technology/i-ditched-my-android-for-an-iphone-and-i-don-t-regret-it/ar-AA13Cbk5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 17:33:15.952330+00:00



## Earth's Spin Has Shifted—And Humans Are To Blame
 - [https://www.msn.com/en-us/news/technology/earth-s-spin-has-shifted-and-humans-are-to-blame/ar-AA1cDWSl?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/technology/earth-s-spin-has-shifted-and-humans-are-to-blame/ar-AA1cDWSl?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 17:33:15.950512+00:00



## Jayland Walker family files lawsuit against city of Akron, police officers
 - [https://www.msn.com/en-us/news/crime/jayland-walker-family-files-lawsuit-against-city-of-akron-police-officers/ar-AA1cDWNq?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/crime/jayland-walker-family-files-lawsuit-against-city-of-akron-police-officers/ar-AA1cDWNq?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 17:33:15.948635+00:00



## Minneapolis police routinely used excessive force and discriminated against Black, Native American people: DOJ
 - [https://www.msn.com/en-us/news/us/minneapolis-police-routinely-used-excessive-force-and-discriminated-against-black-native-american-people-doj/ar-AA1cEhSX?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/minneapolis-police-routinely-used-excessive-force-and-discriminated-against-black-native-american-people-doj/ar-AA1cEhSX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 17:33:15.941800+00:00



## Colorado woman claims police negligence helped lead to her husband’s death: ‘We thought we could depend on them’
 - [https://www.msn.com/en-us/news/crime/colorado-woman-claims-police-negligence-helped-lead-to-her-husband-s-death-we-thought-we-could-depend-on-them/ar-AA1cE2Rs?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/crime/colorado-woman-claims-police-negligence-helped-lead-to-her-husband-s-death-we-thought-we-could-depend-on-them/ar-AA1cE2Rs?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 16:31:09.756554+00:00



## Tennessee panel suspends former officer's certification for now in Tyre Nichols' death
 - [https://www.msn.com/en-us/news/crime/tennessee-panel-suspends-former-officer-s-certification-for-now-in-tyre-nichols-death/ar-AA1cEcIC?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/crime/tennessee-panel-suspends-former-officer-s-certification-for-now-in-tyre-nichols-death/ar-AA1cEcIC?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 16:31:09.754734+00:00



## Harry and Meghan’s Archewell Audio parts ways with Spotify
 - [https://www.msn.com/en-us/news/politics/harry-and-meghan-s-archewell-audio-parts-ways-with-spotify/ar-AA1cEcPl?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/harry-and-meghan-s-archewell-audio-parts-ways-with-spotify/ar-AA1cEcPl?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 16:31:09.752855+00:00



## The growing Republican crowd
 - [https://www.msn.com/en-us/news/politics/the-growing-republican-crowd/ar-AA1cEd1K?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/the-growing-republican-crowd/ar-AA1cEd1K?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 16:31:09.751009+00:00



## Man found guilty of deadly Pittsburgh synagogue attack
 - [https://www.msn.com/en-us/news/world/man-found-guilty-of-deadly-pittsburgh-synagogue-attack/ar-AA1cDOne?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/man-found-guilty-of-deadly-pittsburgh-synagogue-attack/ar-AA1cDOne?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 16:31:09.749061+00:00



## Trump lawyer who quit classified documents case withdraws from $475 million CNN defamation suit
 - [https://www.msn.com/en-us/news/politics/trump-lawyer-who-quit-classified-documents-case-withdraws-from-475-million-cnn-defamation-suit/ar-AA1cEaja?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/trump-lawyer-who-quit-classified-documents-case-withdraws-from-475-million-cnn-defamation-suit/ar-AA1cEaja?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 16:31:09.747093+00:00



## Ukraine's Counteroffensive Is Underway. How It's Going Isn't Clear
 - [https://www.msn.com/en-us/news/world/ukraine-s-counteroffensive-is-underway-how-it-s-going-isn-t-clear/ar-AA1cEf6f?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/ukraine-s-counteroffensive-is-underway-how-it-s-going-isn-t-clear/ar-AA1cEf6f?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 16:31:09.744970+00:00



## Pattern of unlawful policing in Minneapolis made Floyd murder 'possible,' DOJ finds
 - [https://www.msn.com/en-us/news/us/pattern-of-unlawful-policing-in-minneapolis-made-floyd-murder-possible-doj-finds/ar-AA1cDVe5?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/pattern-of-unlawful-policing-in-minneapolis-made-floyd-murder-possible-doj-finds/ar-AA1cDVe5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 16:31:09.742820+00:00



## A man accused of pushing 2 American women off a cliff in Germany had 'red marks on his face and neck' as though the 'victims clawed into him,' witness says
 - [https://www.msn.com/en-us/news/crime/a-man-accused-of-pushing-2-american-women-off-a-cliff-in-germany-had-red-marks-on-his-face-and-neck-as-though-the-victims-clawed-into-him-witness-says/ar-AA1cDT5v?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/crime/a-man-accused-of-pushing-2-american-women-off-a-cliff-in-germany-had-red-marks-on-his-face-and-neck-as-though-the-victims-clawed-into-him-witness-says/ar-AA1cDT5v?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 15:15:41.396882+00:00



## Trump dominates New Hampshire primary after his latest indictment, poll says
 - [https://www.msn.com/en-us/news/politics/trump-dominates-new-hampshire-primary-after-his-latest-indictment-poll-says/ar-AA1cDBVL?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/trump-dominates-new-hampshire-primary-after-his-latest-indictment-poll-says/ar-AA1cDBVL?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 15:15:41.395558+00:00



## Trump claims he's "exonerated" and demands his boxes back. Experts say he's "confessing to intent"
 - [https://www.msn.com/en-us/news/politics/trump-claims-he-s-exonerated-and-demands-his-boxes-back-experts-say-he-s-confessing-to-intent/ar-AA1cE27d?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/trump-claims-he-s-exonerated-and-demands-his-boxes-back-experts-say-he-s-confessing-to-intent/ar-AA1cE27d?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 15:15:41.393681+00:00



## Trump attorney quits another case, cites ‘irreconcilable differences’
 - [https://www.msn.com/en-us/news/politics/trump-attorney-quits-another-case-cites-irreconcilable-differences/ar-AA1cDBOe?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/trump-attorney-quits-another-case-cites-irreconcilable-differences/ar-AA1cDBOe?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 15:15:41.391960+00:00



## Schwarzenegger: Trump won’t win in 2024
 - [https://www.msn.com/en-us/news/politics/schwarzenegger-trump-won-t-win-in-2024/ar-AA1cDEf6?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/schwarzenegger-trump-won-t-win-in-2024/ar-AA1cDEf6?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 15:15:41.390211+00:00



## After expulsion and reinstatement, Tennessee Reps. Pearson, Jones advance past Democratic primaries
 - [https://www.msn.com/en-us/news/us/after-expulsion-and-reinstatement-tennessee-reps-pearson-jones-advance-past-democratic-primaries/ar-AA1cDEgt?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/after-expulsion-and-reinstatement-tennessee-reps-pearson-jones-advance-past-democratic-primaries/ar-AA1cDEgt?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 15:15:41.388439+00:00



## Former White House aide TJ Ducklo to join Biden's re-election campaign
 - [https://www.msn.com/en-us/news/politics/former-white-house-aide-tj-ducklo-to-join-biden-s-re-election-campaign/ar-AA1cDQ1P?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/former-white-house-aide-tj-ducklo-to-join-biden-s-re-election-campaign/ar-AA1cDQ1P?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 15:15:41.386609+00:00



## Iowa Supreme Court prevents 6-week abortion ban from going into effect
 - [https://www.msn.com/en-us/news/politics/iowa-supreme-court-prevents-6-week-abortion-ban-from-going-into-effect/ar-AA1cDLcM?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/iowa-supreme-court-prevents-6-week-abortion-ban-from-going-into-effect/ar-AA1cDLcM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 15:15:41.384545+00:00



## Republicans plan to capitalize on Trump's criminality for decades
 - [https://www.msn.com/en-us/news/politics/republicans-plan-to-capitalize-on-trump-s-criminality-for-decades/ar-AA1cDlMY?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/republicans-plan-to-capitalize-on-trump-s-criminality-for-decades/ar-AA1cDlMY?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 14:00:27.698327+00:00



## Trump again argues Manhattan hush-money trial should be moved to federal court
 - [https://www.msn.com/en-us/news/politics/trump-again-argues-manhattan-hush-money-trial-should-be-moved-to-federal-court/ar-AA1cDh8A?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/trump-again-argues-manhattan-hush-money-trial-should-be-moved-to-federal-court/ar-AA1cDh8A?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 14:00:27.694084+00:00



## Biden to mark anniversary of gun control law enacted after Uvalde school shooting
 - [https://www.msn.com/en-us/news/us/biden-to-mark-anniversary-of-gun-control-law-enacted-after-uvalde-school-shooting/ar-AA1cDope?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/biden-to-mark-anniversary-of-gun-control-law-enacted-after-uvalde-school-shooting/ar-AA1cDope?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 14:00:27.692281+00:00



## What Does It Mean to Be Latino?
 - [https://www.msn.com/en-us/news/us/what-does-it-mean-to-be-latino/ar-AA1cDhfA?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/what-does-it-mean-to-be-latino/ar-AA1cDhfA?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 14:00:27.687487+00:00



## Cornel West's Presidential Run Could Be Joe Biden's Worst Nightmare
 - [https://www.msn.com/en-us/news/politics/cornel-west-s-presidential-run-could-be-joe-biden-s-worst-nightmare/ar-AA1cDK9m?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/cornel-west-s-presidential-run-could-be-joe-biden-s-worst-nightmare/ar-AA1cDK9m?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 14:00:27.682981+00:00



## 8 great iPhone accessibility tips to make life easier
 - [https://www.msn.com/en-us/news/technology/8-great-iphone-accessibility-tips-to-make-life-easier/ar-AA1cDK5o?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/technology/8-great-iphone-accessibility-tips-to-make-life-easier/ar-AA1cDK5o?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 14:00:27.675713+00:00



## Pennsylvania bridge collapse can be Josh Shapiro’s presidential moment — but he has to earn it
 - [https://www.msn.com/en-us/news/politics/pennsylvania-bridge-collapse-can-be-josh-shapiro-s-presidential-moment-but-he-has-to-earn-it/ar-AA1cDtPu?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/pennsylvania-bridge-collapse-can-be-josh-shapiro-s-presidential-moment-but-he-has-to-earn-it/ar-AA1cDtPu?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 14:00:27.670862+00:00



## Jury resumes deliberating in trial of gunman who killed 11 at Pittsburgh synagogue
 - [https://www.msn.com/en-us/news/crime/jury-resumes-deliberating-in-trial-of-gunman-who-killed-11-at-pittsburgh-synagogue/ar-AA1cDKa4?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/crime/jury-resumes-deliberating-in-trial-of-gunman-who-killed-11-at-pittsburgh-synagogue/ar-AA1cDKa4?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 14:00:27.666076+00:00



## Missiles target Kyiv as African leaders push Ukraine and Russia for peace and grain
 - [https://www.msn.com/en-us/news/world/missiles-target-kyiv-as-african-leaders-push-ukraine-and-russia-for-peace-and-grain/ar-AA1cDnxi?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/missiles-target-kyiv-as-african-leaders-push-ukraine-and-russia-for-peace-and-grain/ar-AA1cDnxi?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 12:58:43.186633+00:00



## Democrats seek redistricting changes in key states to regain House majority
 - [https://www.msn.com/en-us/news/politics/democrats-seek-redistricting-changes-in-key-states-to-regain-house-majority/ar-AA1cDA8j?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/democrats-seek-redistricting-changes-in-key-states-to-regain-house-majority/ar-AA1cDA8j?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 12:58:43.184680+00:00



## Pastors find a role ministering to young men swept up in El Salvador's crackdown on gangs
 - [https://www.msn.com/en-us/news/us/pastors-find-a-role-ministering-to-young-men-swept-up-in-el-salvador-s-crackdown-on-gangs/ar-AA1cDsZ4?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/pastors-find-a-role-ministering-to-young-men-swept-up-in-el-salvador-s-crackdown-on-gangs/ar-AA1cDsZ4?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 12:58:43.181330+00:00



## DHS warns drones could be dangerous along border
 - [https://www.msn.com/en-us/news/us/dhs-warns-drones-could-be-dangerous-along-border/ar-AA1cBsm8?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/dhs-warns-drones-could-be-dangerous-along-border/ar-AA1cBsm8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 12:58:43.180040+00:00



## A 12-year-old might’ve grown your food. In many states, that’s perfectly legal.
 - [https://www.msn.com/en-us/news/world/a-12-year-old-might-ve-grown-your-food-in-many-states-that-s-perfectly-legal/ar-AA1cDvKh?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/a-12-year-old-might-ve-grown-your-food-in-many-states-that-s-perfectly-legal/ar-AA1cDvKh?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 12:58:43.178654+00:00



## Is the Trump circus about to push DeSantis into 2028?
 - [https://www.msn.com/en-us/news/politics/is-the-trump-circus-about-to-push-desantis-into-2028/ar-AA1cDgDk?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/is-the-trump-circus-about-to-push-desantis-into-2028/ar-AA1cDgDk?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 12:58:43.176741+00:00



## A white supremacist took MDMA for a study and it snapped him out of his beliefs: "Why am I doing this?"
 - [https://www.msn.com/en-us/news/us/a-white-supremacist-took-mdma-for-a-study-and-it-snapped-him-out-of-his-beliefs-why-am-i-doing-this/ar-AA1cDEPl?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/a-white-supremacist-took-mdma-for-a-study-and-it-snapped-him-out-of-his-beliefs-why-am-i-doing-this/ar-AA1cDEPl?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 12:58:43.174676+00:00



## How the Democrat Who Lost to Lauren Boebert by 546 Votes Plans to Oust Her in 2024
 - [https://www.msn.com/en-us/news/politics/how-the-democrat-who-lost-to-lauren-boebert-by-546-votes-plans-to-oust-her-in-2024/ar-AA1cD98r?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/how-the-democrat-who-lost-to-lauren-boebert-by-546-votes-plans-to-oust-her-in-2024/ar-AA1cD98r?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 11:56:40.949453+00:00



## House GOP declares war on ‘woke’ in advancing Pentagon budget
 - [https://www.msn.com/en-us/news/politics/house-gop-declares-war-on-woke-in-advancing-pentagon-budget/ar-AA1cDbbI?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/house-gop-declares-war-on-woke-in-advancing-pentagon-budget/ar-AA1cDbbI?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 11:56:40.944900+00:00



## Russian soldiers really did stand still for 2 hours for their commander's speech, leaving them sitting ducks for a HIMARS strike, Ukrainian official says
 - [https://www.msn.com/en-us/news/world/russian-soldiers-really-did-stand-still-for-2-hours-for-their-commander-s-speech-leaving-them-sitting-ducks-for-a-himars-strike-ukrainian-official-says/ar-AA1cDpoK?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/russian-soldiers-really-did-stand-still-for-2-hours-for-their-commander-s-speech-leaving-them-sitting-ducks-for-a-himars-strike-ukrainian-official-says/ar-AA1cDpoK?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 11:56:40.940405+00:00



## A homeowner slept in his closet with a gun in order to confront the man who had been squatting in his house for months
 - [https://www.msn.com/en-us/news/crime/a-homeowner-slept-in-his-closet-with-a-gun-in-order-to-confront-the-man-who-had-been-squatting-in-his-house-for-months/ar-AA1cDkxL?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/crime/a-homeowner-slept-in-his-closet-with-a-gun-in-order-to-confront-the-man-who-had-been-squatting-in-his-house-for-months/ar-AA1cDkxL?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 11:56:40.935756+00:00



## Ukraine To Get More Leopard 2 Tanks As Counteroffensive Heats Up
 - [https://www.msn.com/en-us/news/world/ukraine-to-get-more-leopard-2-tanks-as-counteroffensive-heats-up/ar-AA1cDkJT?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/ukraine-to-get-more-leopard-2-tanks-as-counteroffensive-heats-up/ar-AA1cDkJT?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 11:56:40.931199+00:00



## US, Japan, Philippines agree to strengthen security ties amid tensions over China, North Korea
 - [https://www.msn.com/en-us/news/world/us-japan-philippines-agree-to-strengthen-security-ties-amid-tensions-over-china-north-korea/ar-AA1cDkCF?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/us-japan-philippines-agree-to-strengthen-security-ties-amid-tensions-over-china-north-korea/ar-AA1cDkCF?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 11:56:40.926467+00:00



## Pay a Little Less Attention to Your Friends
 - [https://www.msn.com/en-us/health/other/pay-a-little-less-attention-to-your-friends/ar-AA1cDkPB?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/health/other/pay-a-little-less-attention-to-your-friends/ar-AA1cDkPB?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 11:56:40.922169+00:00



## Japan finally updated its definition of rape so that the crime no longer requires the use of force. Its age of consent is also no longer 13.
 - [https://www.msn.com/en-us/news/world/japan-finally-updated-its-definition-of-rape-so-that-the-crime-no-longer-requires-the-use-of-force-its-age-of-consent-is-also-no-longer-13/ar-AA1cD0PM?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/japan-finally-updated-its-definition-of-rape-so-that-the-crime-no-longer-requires-the-use-of-force-its-age-of-consent-is-also-no-longer-13/ar-AA1cD0PM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 10:54:40.967134+00:00



## Biden’s weakness is a feature not a bug
 - [https://www.msn.com/en-us/news/politics/biden-s-weakness-is-a-feature-not-a-bug/ar-AA1cDax8?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/biden-s-weakness-is-a-feature-not-a-bug/ar-AA1cDax8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 10:54:40.965399+00:00



## Archaeologists Discover Exceptionally Well-Preserved 3,000-Year-Old Sword
 - [https://www.msn.com/en-us/news/world/archaeologists-discover-exceptionally-well-preserved-3-000-year-old-sword/ar-AA1cCWem?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/archaeologists-discover-exceptionally-well-preserved-3-000-year-old-sword/ar-AA1cCWem?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 10:54:40.964003+00:00



## U.S. still expects Sweden's NATO ascension by July despite Turkey tensions, U.S. ambassador says
 - [https://www.msn.com/en-us/news/world/u-s-still-expects-sweden-s-nato-ascension-by-july-despite-turkey-tensions-u-s-ambassador-says/ar-AA1cD1b8?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/u-s-still-expects-sweden-s-nato-ascension-by-july-despite-turkey-tensions-u-s-ambassador-says/ar-AA1cD1b8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 10:54:40.962201+00:00



## Protesters in Senegal accuse police of using armed civilians to quell unrest
 - [https://www.msn.com/en-us/news/world/protesters-in-senegal-accuse-police-of-using-armed-civilians-to-quell-unrest/ar-AA1cCW8G?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/protesters-in-senegal-accuse-police-of-using-armed-civilians-to-quell-unrest/ar-AA1cCW8G?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 10:54:40.960434+00:00



## Space Command's leader is building out his Colorado HQ even as Congress tries to force the HQ to move to Alabama
 - [https://www.msn.com/en-us/news/politics/space-command-s-leader-is-building-out-his-colorado-hq-even-as-congress-tries-to-force-the-hq-to-move-to-alabama/ar-AA1cDaxG?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/space-command-s-leader-is-building-out-his-colorado-hq-even-as-congress-tries-to-force-the-hq-to-move-to-alabama/ar-AA1cDaxG?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 10:54:40.958638+00:00



## Trump rejected his lawyer's effort to propose settlement in docs case
 - [https://www.msn.com/en-us/news/politics/trump-rejected-his-lawyer-s-effort-to-propose-settlement-in-docs-case/ar-AA1cBxg8?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/trump-rejected-his-lawyer-s-effort-to-propose-settlement-in-docs-case/ar-AA1cBxg8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 10:54:40.956821+00:00



## Afghanistan's Taliban needs money so badly they are selling tickets to monuments their own fighters smashed to pieces: report
 - [https://www.msn.com/en-us/news/world/afghanistan-s-taliban-needs-money-so-badly-they-are-selling-tickets-to-monuments-their-own-fighters-smashed-to-pieces-report/ar-AA1cD8o0?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/afghanistan-s-taliban-needs-money-so-badly-they-are-selling-tickets-to-monuments-their-own-fighters-smashed-to-pieces-report/ar-AA1cD8o0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 10:54:40.955231+00:00



## Federal government to give states $930M in grants to expand high-speed internet
 - [https://www.msn.com/en-us/news/politics/federal-government-to-give-states-930m-in-grants-to-expand-high-speed-internet/ar-AA1cCDLy?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/federal-government-to-give-states-930m-in-grants-to-expand-high-speed-internet/ar-AA1cCDLy?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 09:46:39.845573+00:00



## ‘Father was killing everyone’: 3 brothers shot and killed, mother injured in shooting
 - [https://www.msn.com/en-us/news/crime/father-was-killing-everyone-3-brothers-shot-and-killed-mother-injured-in-shooting/ar-AA1cDc8G?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/crime/father-was-killing-everyone-3-brothers-shot-and-killed-mother-injured-in-shooting/ar-AA1cDc8G?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 09:46:39.843622+00:00



## Supreme Court Ethics Questions Reach Far Beyond Clarence Thomas
 - [https://www.msn.com/en-us/news/politics/supreme-court-ethics-questions-reach-far-beyond-clarence-thomas/ar-AA1cCDS2?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/supreme-court-ethics-questions-reach-far-beyond-clarence-thomas/ar-AA1cCDS2?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 09:46:39.841617+00:00



## Prince Harry and Meghan's deal with Spotify ends as they agree to 'part ways'
 - [https://www.msn.com/en-us/news/world/prince-harry-and-meghan-s-deal-with-spotify-ends-as-they-agree-to-part-ways/ar-AA1cD4Qd?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/prince-harry-and-meghan-s-deal-with-spotify-ends-as-they-agree-to-part-ways/ar-AA1cD4Qd?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 09:46:39.839457+00:00



## Deadly Tornado Rips Through Texas Town, Leaving Widespread Damage
 - [https://www.msn.com/en-us/weather/topstories/deadly-tornado-rips-through-texas-town-leaving-widespread-damage/vi-AA1cCXEW?srcref=rss](https://www.msn.com/en-us/weather/topstories/deadly-tornado-rips-through-texas-town-leaving-widespread-damage/vi-AA1cCXEW?srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 09:46:39.837271+00:00



## Six people dead in murder-suicide in Tennessee: Report
 - [https://www.msn.com/en-us/news/crime/six-people-dead-in-murder-suicide-in-tennessee-report/ar-AA1cD2H5?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/crime/six-people-dead-in-murder-suicide-in-tennessee-report/ar-AA1cD2H5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 09:46:39.835125+00:00



## Joe Biden Slammed for Making 'Creepy' Joke About Eva Longoria's Age
 - [https://www.msn.com/en-us/news/politics/joe-biden-slammed-for-making-creepy-joke-about-eva-longoria-s-age/ar-AA1cD2JA?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/joe-biden-slammed-for-making-creepy-joke-about-eva-longoria-s-age/ar-AA1cD2JA?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 09:46:39.833120+00:00



## Biden will mark the anniversary of a gun safety law signed after the Uvalde, Texas, school massacre
 - [https://www.msn.com/en-us/news/us/biden-will-mark-the-anniversary-of-a-gun-safety-law-signed-after-the-uvalde-texas-school-massacre/ar-AA1cCSpa?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/biden-will-mark-the-anniversary-of-a-gun-safety-law-signed-after-the-uvalde-texas-school-massacre/ar-AA1cCSpa?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 09:46:39.831280+00:00



## Mortal Kombat 2 adds four new cast members with Martyn Ford and more
 - [https://www.msn.com/en-us/news/technology/mortal-kombat-2-adds-four-new-cast-members-with-martyn-ford-and-more/ar-AA1cCxel?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/technology/mortal-kombat-2-adds-four-new-cast-members-with-martyn-ford-and-more/ar-AA1cCxel?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 08:45:12.829225+00:00



## Las Vegas police, SWAT respond after man kidnaps female victim at gunpoint, barricades inside home
 - [https://www.msn.com/en-us/news/crime/las-vegas-police-swat-respond-after-man-kidnaps-female-victim-at-gunpoint-barricades-inside-home/ar-AA1cCFVY?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/crime/las-vegas-police-swat-respond-after-man-kidnaps-female-victim-at-gunpoint-barricades-inside-home/ar-AA1cCFVY?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 08:45:12.818668+00:00



## Why everyone loves the '90s
 - [https://www.msn.com/en-us/health/wellness/why-everyone-loves-the-90s/ar-AA1cCUho?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/health/wellness/why-everyone-loves-the-90s/ar-AA1cCUho?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 08:45:12.812714+00:00



## Dad Arrested After Horror Shooting That Killed His Three Kids
 - [https://www.msn.com/en-us/news/crime/dad-arrested-after-horror-shooting-that-killed-his-three-kids/ar-AA1cCr4u?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/crime/dad-arrested-after-horror-shooting-that-killed-his-three-kids/ar-AA1cCr4u?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 08:45:12.809790+00:00



## African leaders set to meet with presidents of Ukraine, Russia in bid to end war
 - [https://www.msn.com/en-us/news/world/african-leaders-set-to-meet-with-presidents-of-ukraine-russia-in-bid-to-end-war/ar-AA1cCUcl?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/african-leaders-set-to-meet-with-presidents-of-ukraine-russia-in-bid-to-end-war/ar-AA1cCUcl?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 08:45:10.675619+00:00



## Buttigieg bets big on 'Vision Zero' to stop traffic deaths — all of them
 - [https://www.msn.com/en-us/news/us/buttigieg-bets-big-on-vision-zero-to-stop-traffic-deaths-all-of-them/ar-AA1cCnwX?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/buttigieg-bets-big-on-vision-zero-to-stop-traffic-deaths-all-of-them/ar-AA1cCnwX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 07:20:02.357717+00:00



## Pope Francis leaves Rome hospital 9 days after surgery
 - [https://www.msn.com/en-us/health/health-news/pope-francis-leaves-rome-hospital-9-days-after-surgery/ar-AA1cCP7d?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/health/health-news/pope-francis-leaves-rome-hospital-9-days-after-surgery/ar-AA1cCP7d?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 07:20:02.351623+00:00



## Once allies, Russia's mercenary boss is now in a more precarious position with Putin
 - [https://www.msn.com/en-us/news/world/once-allies-russia-s-mercenary-boss-is-now-in-a-more-precarious-position-with-putin/ar-AA1cCx3I?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/once-allies-russia-s-mercenary-boss-is-now-in-a-more-precarious-position-with-putin/ar-AA1cCx3I?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 06:08:21.916507+00:00



## Thousands of Sudanese fleeing fighting with no travel documents trapped on the border with Egypt
 - [https://www.msn.com/en-us/news/world/thousands-of-sudanese-fleeing-fighting-with-no-travel-documents-trapped-on-the-border-with-egypt/ar-AA1cCzxj?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/thousands-of-sudanese-fleeing-fighting-with-no-travel-documents-trapped-on-the-border-with-egypt/ar-AA1cCzxj?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 06:08:21.915205+00:00



## You can’t fix faith without fixing marriage
 - [https://www.msn.com/en-us/news/us/you-can-t-fix-faith-without-fixing-marriage/ar-AA1cCsg1?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/you-can-t-fix-faith-without-fixing-marriage/ar-AA1cCsg1?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 06:08:21.913794+00:00



## US, Japan, Philippines Agree to Bolster Defense Cooperation
 - [https://www.msn.com/en-us/news/world/us-japan-philippines-agree-to-bolster-defense-cooperation/ar-AA1cCsfY?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/us-japan-philippines-agree-to-bolster-defense-cooperation/ar-AA1cCsfY?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 06:08:21.912141+00:00



## Micron Vows $600 Million China Investment Weeks After Chip Ban
 - [https://www.msn.com/en-us/news/world/micron-vows-600-million-china-investment-weeks-after-chip-ban/ar-AA1cCfO9?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/micron-vows-600-million-china-investment-weeks-after-chip-ban/ar-AA1cCfO9?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 05:06:38.963105+00:00



## Herschel Walker Is Working on Finishing College Degree After Senate Loss
 - [https://www.msn.com/en-us/news/politics/herschel-walker-is-working-on-finishing-college-degree-after-senate-loss/ar-AA1cCmQQ?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/herschel-walker-is-working-on-finishing-college-degree-after-senate-loss/ar-AA1cCmQQ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 05:06:38.961716+00:00



## Silvio Berlusconi, 1936-2023
 - [https://www.msn.com/en-us/news/world/silvio-berlusconi-1936-2023/ar-AA1cCdpI?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/silvio-berlusconi-1936-2023/ar-AA1cCdpI?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 05:06:38.958543+00:00



## Biden is returning to his union roots as his 2024 campaign gears up
 - [https://www.msn.com/en-us/news/politics/biden-is-returning-to-his-union-roots-as-his-2024-campaign-gears-up/ar-AA1cCg6M?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/biden-is-returning-to-his-union-roots-as-his-2024-campaign-gears-up/ar-AA1cCg6M?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 05:06:38.957182+00:00



## Devastating tornado tears through Texas town, 3 dead, more than 50 injured
 - [https://www.msn.com/en-us/news/us/devastating-tornado-tears-through-texas-town-3-dead-more-than-50-injured/ar-AA1cALWz?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/devastating-tornado-tears-through-texas-town-3-dead-more-than-50-injured/ar-AA1cALWz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 05:06:38.955833+00:00



## ChatGPT Can Now Help Humans Speak to Trees. But Why?
 - [https://www.msn.com/en-us/news/technology/chatgpt-can-now-help-humans-speak-to-trees-but-why/ar-AA1cC6pK?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/technology/chatgpt-can-now-help-humans-speak-to-trees-but-why/ar-AA1cC6pK?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 05:06:38.954175+00:00



## Trump's 'Irrelevant' Indictment Defense Missing Key Elements: Ex-Prosecutor
 - [https://www.msn.com/en-us/news/politics/trump-s-irrelevant-indictment-defense-missing-key-elements-ex-prosecutor/ar-AA1cCl7M?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/trump-s-irrelevant-indictment-defense-missing-key-elements-ex-prosecutor/ar-AA1cCl7M?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 04:05:03.486653+00:00



## US Nuclear Submarine Returns to South Korea as Pyongyang Fires Missiles
 - [https://www.msn.com/en-us/news/world/us-nuclear-submarine-returns-to-south-korea-as-pyongyang-fires-missiles/ar-AA1cCfna?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/us-nuclear-submarine-returns-to-south-korea-as-pyongyang-fires-missiles/ar-AA1cCfna?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 04:05:03.485020+00:00



## Spotify ends podcast deal with Harry and Meghan
 - [https://www.msn.com/en-us/news/world/spotify-ends-podcast-deal-with-harry-and-meghan/ar-AA1cCiiX?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/spotify-ends-podcast-deal-with-harry-and-meghan/ar-AA1cCiiX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 04:05:03.480671+00:00



## Abbott issues state of emergency after multiple tornadoes rip through small Texas town
 - [https://www.msn.com/en-us/news/us/abbott-issues-state-of-emergency-after-multiple-tornadoes-rip-through-small-texas-town/ar-AA1cCkL7?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/abbott-issues-state-of-emergency-after-multiple-tornadoes-rip-through-small-texas-town/ar-AA1cCkL7?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 04:05:03.476920+00:00



## Biden gives Trump the silent treatment on indictment, but for how long?
 - [https://www.msn.com/en-us/news/politics/biden-gives-trump-the-silent-treatment-on-indictment-but-for-how-long/ar-AA1cCmre?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/biden-gives-trump-the-silent-treatment-on-indictment-but-for-how-long/ar-AA1cCmre?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 04:05:03.475128+00:00



## Devastating tornado tears through Texas town, at least 3 dead, 100 injured
 - [https://www.msn.com/en-us/news/us/devastating-tornado-tears-through-texas-town-at-least-3-dead-100-injured/ar-AA1cALWz?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/devastating-tornado-tears-through-texas-town-at-least-3-dead-100-injured/ar-AA1cALWz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 04:05:03.470892+00:00



## 3 dead and dozens injured after tornado hits Texas city
 - [https://www.msn.com/en-us/news/us/3-dead-and-dozens-injured-after-tornado-hits-texas-city/ar-AA1cCeE8?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/3-dead-and-dozens-injured-after-tornado-hits-texas-city/ar-AA1cCeE8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 04:05:03.466750+00:00



## US guided-missile submarine arrives in South Korea, a day after North Korea resumes missile tests
 - [https://www.msn.com/en-us/news/world/us-guided-missile-submarine-arrives-in-south-korea-a-day-after-north-korea-resumes-missile-tests/ar-AA1cCmzi?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/us-guided-missile-submarine-arrives-in-south-korea-a-day-after-north-korea-resumes-missile-tests/ar-AA1cCmzi?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 04:05:03.462446+00:00



## Real estate mogul is indicted on first-degree murder for allegedly shooting football coach's son
 - [https://www.msn.com/en-us/news/crime/real-estate-mogul-is-indicted-on-first-degree-murder-for-allegedly-shooting-football-coach-s-son/ar-AA1cCm2E?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/crime/real-estate-mogul-is-indicted-on-first-degree-murder-for-allegedly-shooting-football-coach-s-son/ar-AA1cCm2E?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 03:03:28.651289+00:00



## Students meet under trees as schools shelter villagers displaced by Philippine volcano
 - [https://www.msn.com/en-us/news/world/students-meet-under-trees-as-schools-shelter-villagers-displaced-by-philippine-volcano/ar-AA1cBXWB?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/students-meet-under-trees-as-schools-shelter-villagers-displaced-by-philippine-volcano/ar-AA1cBXWB?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 03:03:28.649490+00:00



## Blinken to fly to Beijing for high-stakes diplomacy after spy balloon saga
 - [https://www.msn.com/en-us/news/world/blinken-to-fly-to-beijing-for-high-stakes-diplomacy-after-spy-balloon-saga/ar-AA1cBVo5?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/blinken-to-fly-to-beijing-for-high-stakes-diplomacy-after-spy-balloon-saga/ar-AA1cBVo5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 03:03:28.648214+00:00



## Tennessee lawmakers expelled for gun protests victorious in special primary elections
 - [https://www.msn.com/en-us/news/politics/tennessee-lawmakers-expelled-for-gun-protests-victorious-in-special-primary-elections/ar-AA1cC2Mu?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/tennessee-lawmakers-expelled-for-gun-protests-victorious-in-special-primary-elections/ar-AA1cC2Mu?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 03:03:28.646924+00:00



## Suarez touts record as Miami mayor in first speech after launching long-shot presidential bid
 - [https://www.msn.com/en-us/news/politics/suarez-touts-record-as-miami-mayor-in-first-speech-after-launching-long-shot-presidential-bid/ar-AA1cC2N2?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/suarez-touts-record-as-miami-mayor-in-first-speech-after-launching-long-shot-presidential-bid/ar-AA1cC2N2?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 03:03:28.645507+00:00



## Ex-President Donald Trump tops speaker's list at stampede of 2024 GOP cattle calls
 - [https://www.msn.com/en-us/news/politics/ex-president-donald-trump-tops-speaker-s-list-at-stampede-of-2024-gop-cattle-calls/ar-AA1cCm76?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/ex-president-donald-trump-tops-speaker-s-list-at-stampede-of-2024-gop-cattle-calls/ar-AA1cCm76?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 03:03:28.643865+00:00



## Biden announces pledge by ticket sales giants to eliminate hidden fees and show full costs upfront
 - [https://www.msn.com/en-us/news/us/biden-announces-pledge-by-ticket-sales-giants-to-eliminate-hidden-fees-and-show-full-costs-upfront/ar-AA1cABMe?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/biden-announces-pledge-by-ticket-sales-giants-to-eliminate-hidden-fees-and-show-full-costs-upfront/ar-AA1cABMe?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 02:01:53.388508+00:00



## The Making of the Xi Jinping Personality Cult
 - [https://www.msn.com/en-us/news/world/the-making-of-the-xi-jinping-personality-cult/ar-AA1cC7dJ?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/the-making-of-the-xi-jinping-personality-cult/ar-AA1cC7dJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 02:01:53.386871+00:00



## Some of the 30 killer whales captured doing flips and playing near boats in California were the same orcas that attacked a pair of gray whales and tried to eat them alive
 - [https://www.msn.com/en-us/news/us/some-of-the-30-killer-whales-captured-doing-flips-and-playing-near-boats-in-california-were-the-same-orcas-that-attacked-a-pair-of-gray-whales-and-tried-to-eat-them-alive/ar-AA1cCgZw?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/some-of-the-30-killer-whales-captured-doing-flips-and-playing-near-boats-in-california-were-the-same-orcas-that-attacked-a-pair-of-gray-whales-and-tried-to-eat-them-alive/ar-AA1cCgZw?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 02:01:53.384772+00:00



## Democracy Prevails in Texas Town Run by ‘Dictator’ Mayor
 - [https://www.msn.com/en-us/news/us/democracy-prevails-in-texas-town-run-by-dictator-mayor/ar-AA1cBZPm?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/democracy-prevails-in-texas-town-run-by-dictator-mayor/ar-AA1cBZPm?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 02:01:53.382801+00:00



## DeSantis Pushes Newsom to Challenge Biden for 2024 Nomination
 - [https://www.msn.com/en-us/news/politics/desantis-pushes-newsom-to-challenge-biden-for-2024-nomination/ar-AA1cChbj?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/desantis-pushes-newsom-to-challenge-biden-for-2024-nomination/ar-AA1cChbj?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 02:01:53.380910+00:00



## US Presses Taiwan Opposition Candidate Over China Policies
 - [https://www.msn.com/en-us/news/world/us-presses-taiwan-opposition-candidate-over-china-policies/ar-AA1cAQyL?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/us-presses-taiwan-opposition-candidate-over-china-policies/ar-AA1cAQyL?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 02:01:53.379294+00:00



## A's 'excited' as Nevada governor signs Las Vegas stadium funding bill into law
 - [https://www.msn.com/en-us/news/politics/a-s-excited-as-nevada-governor-signs-las-vegas-stadium-funding-bill-into-law/ar-AA1cC55P?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/a-s-excited-as-nevada-governor-signs-las-vegas-stadium-funding-bill-into-law/ar-AA1cC55P?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 02:01:53.377585+00:00



## Alleged Classified-Document Leaker Jack Teixeira Indicted
 - [https://www.msn.com/en-us/video/news/alleged-classified-document-leaker-jack-teixeira-indicted/vi-AA1cCbDi?srcref=rss](https://www.msn.com/en-us/video/news/alleged-classified-document-leaker-jack-teixeira-indicted/vi-AA1cCbDi?srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 01:00:06.158884+00:00



## Suarez backs 15-week federal abortion ban, says he has 'credibility' on immigration conversation
 - [https://www.msn.com/en-us/news/politics/suarez-backs-15-week-federal-abortion-ban-says-he-has-credibility-on-immigration-conversation/ar-AA1cBQ4M?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/suarez-backs-15-week-federal-abortion-ban-says-he-has-credibility-on-immigration-conversation/ar-AA1cBQ4M?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 01:00:06.157163+00:00



## DeSantis' budget vetoes include projects from GOP lawmakers who didn't endorse him
 - [https://www.msn.com/en-us/news/politics/desantis-budget-vetoes-include-projects-from-gop-lawmakers-who-didn-t-endorse-him/ar-AA1cBZm1?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/desantis-budget-vetoes-include-projects-from-gop-lawmakers-who-didn-t-endorse-him/ar-AA1cBZm1?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 01:00:06.153088+00:00



## Francis Suarez joins other 2024 candidates in support of nationwide abortion ban
 - [https://www.msn.com/en-us/news/politics/francis-suarez-joins-other-2024-candidates-in-support-of-nationwide-abortion-ban/ar-AA1cC4tB?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/francis-suarez-joins-other-2024-candidates-in-support-of-nationwide-abortion-ban/ar-AA1cC4tB?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 01:00:06.151164+00:00



## Poker Star Arrested for Drum-Banging Jan. 6 Capitol Incursion
 - [https://www.msn.com/en-us/news/crime/poker-star-arrested-for-drum-banging-jan-6-capitol-incursion/ar-AA1cC9fY?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/crime/poker-star-arrested-for-drum-banging-jan-6-capitol-incursion/ar-AA1cC9fY?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 01:00:06.149143+00:00



## E. Jean Carroll’s defamation case against Trump will head to trial in January
 - [https://www.msn.com/en-us/news/politics/e-jean-carroll-s-defamation-case-against-trump-will-head-to-trial-in-january/ar-AA1cC6XE?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/e-jean-carroll-s-defamation-case-against-trump-will-head-to-trial-in-january/ar-AA1cC6XE?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 01:00:06.147134+00:00



## Ted Cruz Mocked for 'Ridiculous' Pat Benatar Comment
 - [https://www.msn.com/en-us/news/politics/ted-cruz-mocked-for-ridiculous-pat-benatar-comment/ar-AA1cCemF?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/ted-cruz-mocked-for-ridiculous-pat-benatar-comment/ar-AA1cCemF?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-16 01:00:06.144906+00:00



