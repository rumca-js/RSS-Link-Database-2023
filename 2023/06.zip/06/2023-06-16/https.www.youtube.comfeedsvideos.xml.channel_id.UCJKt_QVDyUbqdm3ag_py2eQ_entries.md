# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## SID music: LMan & Sunflower - Pixelated Neon Nights (SIDFX 8580 dual mono bx_🎧)
 - [https://www.youtube.com/watch?v=_v4gjkoLH_4](https://www.youtube.com/watch?v=_v4gjkoLH_4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2023-06-16 16:54:01+00:00

"Pixelated Neon Nights" by LMan & Sunflower/Maniacs of Noise^MultiStyle Labs, 1st at X 2023.
Art from the music release by LMan (assuming). Slightly edited (original image is surrounded by grey borders).

Made using real C64 audio in SIDFX dual mono config (identical audio for both chips):

Left channel: CSG 6582A 2792 25/Philippines NM235N18 1200T
Right channel: CSG 8580R5 0590 25/Hong Kong HH032232 HC-30

Project SIDFX:
http://www.sidfx.dk/

