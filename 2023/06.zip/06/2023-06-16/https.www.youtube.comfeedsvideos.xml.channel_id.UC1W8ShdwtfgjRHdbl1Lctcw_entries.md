# Source:NASS, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC1W8ShdwtfgjRHdbl1Lctcw, language:en-US

## Old New York 30s, 40s in color [60fps, Remastered] w/sound design added
 - [https://www.youtube.com/watch?v=yEnTbEE_6J4](https://www.youtube.com/watch?v=yEnTbEE_6J4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC1W8ShdwtfgjRHdbl1Lctcw
 - date published: 2023-06-16 23:22:13+00:00

I colorized, restored and created a sound design for this video of New York of the 30's and 40's, we have some scenes of downtown and the exit of the train station with lots of people walking and living their daily life, we can see the style of clothes of cars of that time, then we have a long train ride through the city of New York magnificent to see. 

Video Restoration Process:
✔ FPS boosted to 60 frames per second 
✔ Image resolution boosted up to HD 
✔ Improved video sharpness and brightness 
✔ Colorized only for the ambiance (not historically accurate)
✔added sound only for the ambiance
✔restoration:(stabilisation,denoise,cleand,deblur) 

Please, be aware that colorization colors are not real and fake, colorization was made only for the ambiance and do not represent real historical data.

B&amp;W Video Source: Internet Archive, US Archive National

Join this channel to benefit from exclusive advantages and also to support us: https://www.youtube.com/channel/UC1W8ShdwtfgjRHdbl1Lctcw/join

Join this channel to benefit from exclusive advantages and also to support us: https://www.youtube.com/channel/UC1W8ShdwtfgjRHdbl1Lctcw/join

