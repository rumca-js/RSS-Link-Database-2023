# Source:The Intercept, URL:https://theintercept.com/feed/?lang=en, language:en-US

## Daniel Ellsberg Wanted Americans to See the Truth About War
 - [https://theintercept.com/2023/06/16/daniel-ellsberg-pentagon-papers-dead/](https://theintercept.com/2023/06/16/daniel-ellsberg-pentagon-papers-dead/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2023-06-16 18:28:13+00:00

<p>In an interview before his death, the Pentagon Papers whistleblower urged the media and the government to be more honest about America’s bombing of civilians.</p>
<p>The post <a href="https://theintercept.com/2023/06/16/daniel-ellsberg-pentagon-papers-dead/" rel="nofollow">Daniel Ellsberg Wanted Americans to See the Truth About War</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>

## Virginia’s Democratic Party Is Letting Energy Money Back In
 - [https://theintercept.com/2023/06/16/virginia-democratic-primary/](https://theintercept.com/2023/06/16/virginia-democratic-primary/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2023-06-16 15:23:56+00:00

<p>Next week’s primaries will show whether progressive populists can win the same way they did four years ago: by rejecting corporate cash.</p>
<p>The post <a href="https://theintercept.com/2023/06/16/virginia-democratic-primary/" rel="nofollow">Virginia’s Democratic Party Is Letting Energy Money Back In</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>

## Virginia’s Democratic Party Is Letting Energy Money Back In
 - [https://theintercept.com/2023/06/16/virginia-democratic-primary-dominion-energy/](https://theintercept.com/2023/06/16/virginia-democratic-primary-dominion-energy/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2023-06-16 15:23:56+00:00

<p>Next week’s primaries will show whether progressive populists can win the same way they did four years ago: by rejecting corporate cash.</p>
<p>The post <a href="https://theintercept.com/2023/06/16/virginia-democratic-primary-dominion-energy/" rel="nofollow">Virginia’s Democratic Party Is Letting Energy Money Back In</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>

## How Henry Kissinger Paved the Way for Orlando Letelier’s Assassination
 - [https://theintercept.com/2023/06/16/henry-kissinger-assassination-orlando-letelier-chile/](https://theintercept.com/2023/06/16/henry-kissinger-assassination-orlando-letelier-chile/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2023-06-16 14:26:22+00:00

<p>During a visit to Chile in 1976, Kissinger met the dictator Augusto Pinochet and offered no objection to his violent rule.</p>
<p>The post <a href="https://theintercept.com/2023/06/16/henry-kissinger-assassination-orlando-letelier-chile/" rel="nofollow">How Henry Kissinger Paved the Way for Orlando Letelier’s Assassination</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>

## A Conversation With Joe Manchin’s Former Right Hand, Scott Sears
 - [https://theintercept.com/2023/06/16/deconstructed-podcast-joe-manchin-presidential-run-scott-sears/](https://theintercept.com/2023/06/16/deconstructed-podcast-joe-manchin-presidential-run-scott-sears/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2023-06-16 10:00:00+00:00

<p>How seriously is Manchin considering a presidential run?</p>
<p>The post <a href="https://theintercept.com/2023/06/16/deconstructed-podcast-joe-manchin-presidential-run-scott-sears/" rel="nofollow">A Conversation With Joe Manchin’s Former Right Hand, Scott Sears</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>

