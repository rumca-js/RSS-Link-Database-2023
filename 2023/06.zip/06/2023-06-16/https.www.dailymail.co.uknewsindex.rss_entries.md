# Source:Daily Mail, URL:https://www.dailymail.co.uk/news/index.rss, language:en-US

## Civil servants warned against sharing state secrets with AI bot ChatGPT
 - [https://www.dailymail.co.uk/news/article-12204739/Civil-servants-warned-against-sharing-state-secrets-AI-bot-ChatGPT.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12204739/Civil-servants-warned-against-sharing-state-secrets-AI-bot-ChatGPT.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 23:29:22+00:00

Whitehall officials were told to be wary of the answers AI bots might return and to always double check them to avoid being misled, leaked guidance has reportedly revealed.

## Moment Utah officers rescue girl, 12, from submerged van as mom frantically pleads for help
 - [https://www.dailymail.co.uk/news/article-12204447/Moment-Utah-officers-rescue-girl-12-submerged-van-mom-frantically-pleads-help.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12204447/Moment-Utah-officers-rescue-girl-12-submerged-van-mom-frantically-pleads-help.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 23:28:37+00:00

Stunning footage from a police bodycam has revealed the heroic moment two cops scrambled from their vehicle to save a 12-year-old girl from a submerged van.

## Family of Jayland Walker sue Ohio cops for $45 MILLION after his shooting death
 - [https://www.dailymail.co.uk/news/article-12204449/Family-Jayland-Walker-sue-Ohio-cops-45-MILLION-shooting-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12204449/Family-Jayland-Walker-sue-Ohio-cops-45-MILLION-shooting-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 23:25:33+00:00

Attorneys for the family are arguing officers used excessive force when they fired 94 bullets at the the 25-year-old Walker, who is black, during a foot chase. Walker fired one shot at the officers.

## Five US Navy sailors hospitalized watercraft hits jetty near naval base in San Diego in training op
 - [https://www.dailymail.co.uk/news/article-12204509/Five-Navy-sailors-hospitalized-watercraft-hits-jetty-near-naval-base-San-Diego-training-op.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12204509/Five-Navy-sailors-hospitalized-watercraft-hits-jetty-near-naval-base-San-Diego-training-op.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 23:18:43+00:00

Five Navy Sailors were taken to the hospital in the early hours of Friday morning after a boat crash at Naval Base Point Loma, near San Diego. The crash involved a watercraft which slammed into a jetty.

## UK and France to join forces to fly 24/7 surveillance plane over English channel to catch smugglers
 - [https://www.dailymail.co.uk/news/article-12204701/UK-France-join-forces-fly-24-7-surveillance-plane-English-channel-catch-smugglers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12204701/UK-France-join-forces-fly-24-7-surveillance-plane-English-channel-catch-smugglers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 23:12:22+00:00

The new plane will be able to fly in all weathers over the English Channel, track boats more accurately and film crossings for evidence in future cases against people smugglers.

## NYC 'sidewalk shover' Lauren Pazienza was drunk and stoned when she pushed singing coach to death
 - [https://www.dailymail.co.uk/news/article-12204523/NYC-sidewalk-shover-Lauren-Pazienza-drunk-stoned-pushed-singing-coach-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12204523/NYC-sidewalk-shover-Lauren-Pazienza-drunk-stoned-pushed-singing-coach-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 22:59:01+00:00

The attorney for Lauren Pazienza (right) has claimed she was drunk and stoned on the night she allegedly fatally shoved Barbara Gustern (inset), an 87-year-old singing teacher.

## DOMINIC SANDBROOK: How the man who invented the atom bomb was brought down
 - [https://www.dailymail.co.uk/news/article-12204749/DOMINIC-SANDBROOK-man-invented-atom-bomb-brought-down.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12204749/DOMINIC-SANDBROOK-man-invented-atom-bomb-brought-down.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 22:58:19+00:00

The time was 5.29am, the date July 16, 1945. On a sun-scorched plain in the U.S. state of New Mexico, the world was about to change for ever.

## Warden of London garden at wits end after fine-dining chefs rip up community wild garlic
 - [https://www.dailymail.co.uk/news/article-12204683/Warden-London-garden-wits-end-fine-dining-chefs-rip-community-wild-garlic.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12204683/Warden-London-garden-wits-end-fine-dining-chefs-rip-community-wild-garlic.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 22:58:01+00:00

Kenneth Greenway, 47, says he has caught chefs helping themselves to more than their fair share of the leafy green, and that they have not taken kindly to him confronting them about it.

## Anthony Albanese's new housing plan after Greens blocked $10 billion Housing Australia Future Fund
 - [https://www.dailymail.co.uk/news/article-12204741/Anthony-Albaneses-new-housing-plan-Greens-blocked-10-billion-Housing-Australia-Future-Fund.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12204741/Anthony-Albaneses-new-housing-plan-Greens-blocked-10-billion-Housing-Australia-Future-Fund.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 22:48:15+00:00

Prime Minister Anthony Albanese will announced a $2billion 'Social Housing Accelerator' plan on Saturday as the Greens continue to block his election promise on housing in the Senate.

## The great recycling myth: Less than HALF of our rubbish is actually recycled
 - [https://www.dailymail.co.uk/news/article-12204711/The-great-recycling-myth-HALF-rubbish-actually-recycled.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12204711/The-great-recycling-myth-HALF-rubbish-actually-recycled.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 22:41:03+00:00

Human beings have always produced waste, but never on such a scale as now. Take plastic bottles. More than 480 billion are sold worldwide every year.

## Jamie Raskin asks FBI to publicly state Biden bribery allegations are not part of investigation
 - [https://www.dailymail.co.uk/news/article-12204481/Jamie-Raskin-asks-FBI-publicly-state-Biden-bribery-allegations-not-investigation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12204481/Jamie-Raskin-asks-FBI-publicly-state-Biden-bribery-allegations-not-investigation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 22:16:37+00:00

Rep. Jamie Raskin wrote to the FBI  urging them to clarify Biden is not under investigation for bribery and and the agency is no longer looking into the subpoenaed FD-1023 form.

## Trump attorney Jim Trusty resigns from ANOTHER case
 - [https://www.dailymail.co.uk/news/article-12204593/Trump-attorney-Jim-Trusty-resigns-case.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12204593/Trump-attorney-Jim-Trusty-resigns-case.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 22:11:00+00:00

Lawyer Jim Trusty filed a document with a federal court in Florida to withdraw from representing former President Trump in his suit against CNN. The suit sought $475 million in punitive damages.

## Drunk driver Jamie Lee Komoroski, 25, who killed bride waives first court appearance
 - [https://www.dailymail.co.uk/news/article-12204395/Drunk-driver-Jamie-Lee-Komoroski-25-killed-bride-waives-court-appearance.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12204395/Drunk-driver-Jamie-Lee-Komoroski-25-killed-bride-waives-court-appearance.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 22:09:37+00:00

Jamie Lee Komoroski, 25, was expected in court Friday afternoon but waived her first court appearance which was scheduled for 1pm in downtown Charleston.

## Has ultra-woke National Trust been neglecting historic village beloved by Harry Potter fans?
 - [https://www.dailymail.co.uk/news/article-12204637/Has-ultra-woke-National-Trust-neglecting-historic-village-beloved-Harry-Potter-fans.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12204637/Has-ultra-woke-National-Trust-neglecting-historic-village-beloved-Harry-Potter-fans.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 22:00:49+00:00

Locals believe that the National Trust, which owns pretty much every building in Lacock's historic centre, including 88 tenanted houses and the abbey, has lost interest in the village.

## BBC accused of 'revelling' in Boris Johnson's downfall
 - [https://www.dailymail.co.uk/news/article-12204531/BBC-accused-revelling-Boris-Johnsons-downfall.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12204531/BBC-accused-revelling-Boris-Johnsons-downfall.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 21:50:37+00:00

One long-serving Tory politician said that following the former prime minister's decision to quit as an MP, it was clear 'certain presenters and certain producers' were 'very happy' he was going.

## Former hostage and campaigner Terry Waite who was held captive in Lebanon is knighted
 - [https://www.dailymail.co.uk/news/article-12204379/Former-hostage-campaigner-Terry-Waite-held-captive-Lebanon-knighted.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12204379/Former-hostage-campaigner-Terry-Waite-held-captive-Lebanon-knighted.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 21:48:32+00:00

Sir Terry, 84, who spent almost five years in captivity in Lebanon, was appointed a Knight Commander of the Order of St Michael and St George (KCMG) for his services to charity.

## Philadelphia principal refuses to give student 
graduation certificate because of dance across stage
 - [https://www.dailymail.co.uk/news/article-12204271/Philadelphia-principal-refuses-student-graduation-certificate-dance-stage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12204271/Philadelphia-principal-refuses-student-graduation-certificate-dance-stage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 21:46:08+00:00

A high school graduate in Philadelphia has spoken out after the principal refused to give her a graduation certificate because she danced across the stage in celebration.

## Leading Partygate inquisitor effectively in hiding for a third day
 - [https://www.dailymail.co.uk/news/article-12204497/Leading-Partygate-inquisitor-effectively-hiding-day.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12204497/Leading-Partygate-inquisitor-effectively-hiding-day.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 21:39:23+00:00

Sir Bernard Jenkin failed to break his silence again despite repeated requests for comment. Boris Johnson has called for him to resign from the Privileges Committee over a Covid drinks party.

## Labour likened councillor jailed for joining disruptive Just Stop Oil protests to Nelson Mandela
 - [https://www.dailymail.co.uk/news/article-12204419/Labour-likened-councillor-jailed-joining-disruptive-Just-Stop-Oil-protests-Nelson-Mandela.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12204419/Labour-likened-councillor-jailed-joining-disruptive-Just-Stop-Oil-protests-Nelson-Mandela.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 21:38:55+00:00

Richard Morgan was likened to Nelson Mandela by other councillors for being a 'passionate fighter' who was 'jailed for his beliefs'. He has even been appointed to lead the transport portfolio.

## 'A hypocritical joke!' Tory members' fury at verdict of Parliamentary probe into Boris Johnson
 - [https://www.dailymail.co.uk/news/article-12204491/A-hypocritical-joke-Tory-members-fury-verdict-Parliamentary-probe-Boris-Johnson.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12204491/A-hypocritical-joke-Tory-members-fury-verdict-Parliamentary-probe-Boris-Johnson.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 21:35:59+00:00

A grassroots campaign group says it has been 'inundated' with messages from party members and local organisers furious at the privileges committee's heavy-handed treatment of the former prime minister.

## Dame Anna Wintour and author Ian McEwan lead first Birthday Honours of King Charles's reign
 - [https://www.dailymail.co.uk/news/article-12204359/Dame-Anna-Wintour-author-Ian-McEwan-lead-Birthday-Honours-King-Charless-reign.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12204359/Dame-Anna-Wintour-author-Ian-McEwan-lead-Birthday-Honours-King-Charless-reign.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 21:35:53+00:00

Vogue editor Dame Anna Wintour and the prize-winning novelist Ian McEwan have been given the highest awards in an honours list as they were made Companions of Honour.

## Arise, Sir 'Stich-up': Mandarin who gave Boris Johnson's diaries to police is knighted
 - [https://www.dailymail.co.uk/news/article-12204361/Arise-Sir-Stich-Mandarin-gave-Boris-Johnsons-diaries-police-knighted.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12204361/Arise-Sir-Stich-Mandarin-gave-Boris-Johnsons-diaries-police-knighted.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 21:35:47+00:00

Alex Chisholm, permanent secretary in the Cabinet Office, took the decision last month to hand to police Boris Johnson's diaries while they were being examined as part of the Covid inquiry.

## WENDY MITCHELL: I dyed my hair pink and went wing walking...to prove dementia wouldn't beat me
 - [https://www.dailymail.co.uk/news/article-12204161/WENDY-MITCHELL-dyed-hair-pink-went-wing-walking-prove-dementia-wouldnt-beat-me.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12204161/WENDY-MITCHELL-dyed-hair-pink-went-wing-walking-prove-dementia-wouldnt-beat-me.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 21:19:35+00:00

WENDY MITCHELL: I don't fear death; I don't fear anything any more. Pre-dementia, I was afraid of everything: the dark; animals; of dying when my girls were still children.

## Babbling Biden tells Connecticut crowd 'God save the queen, man'
 - [https://www.dailymail.co.uk/news/article-12203923/Babbling-Biden-tells-Connecticut-crowd-God-save-queen-man.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203923/Babbling-Biden-tells-Connecticut-crowd-God-save-queen-man.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 21:02:52+00:00

A babbling President Joe Biden gave a speech Friday where he joked about being 110, told the crowd 'God save the queen' and deployed some of his greatest hits.

## Albanian armed robber who was sent home after using a fake name is back in Britain
 - [https://www.dailymail.co.uk/news/article-12204283/Albanian-armed-robber-sent-home-using-fake-Britain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12204283/Albanian-armed-robber-sent-home-using-fake-Britain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 21:01:20+00:00

EXCLUSIVE Asim Murtati, 46, was involved in the ambush of a minibus in Albania before fleeing to the UK where he gave a different surname to border guards and claimed to be a Kosovan refugee.

## Financier, 54, accused of raping 14-year-old girl and plying her with drugs denies the charges
 - [https://www.dailymail.co.uk/news/article-12204173/Financier-54-accused-raping-14-year-old-girl-plying-drugs-denies-charges.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12204173/Financier-54-accused-raping-14-year-old-girl-plying-drugs-denies-charges.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 20:50:56+00:00

Michael Olson, 54, is accused of targeting young Asian girls on Instagram by specifically seizing on any who posted about not being able to afford clothes, or about self-harm.

## How Harvard morgue manager sold off human body parts through Facebook 'oddities' group
 - [https://www.dailymail.co.uk/news/article-12203975/How-Harvard-morgue-manager-sold-human-body-parts-Facebook-oddities-group.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203975/How-Harvard-morgue-manager-sold-human-body-parts-Facebook-oddities-group.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 20:45:05+00:00

Cedric Lodge (top right) and Candace Chapman Scott (left) are both facing up to ten years in prison for their involvement in the macabre underground network.

## Mother of Bournemouth drowning victim reveals heartbreaking moment she was told her girl had died
 - [https://www.dailymail.co.uk/news/article-12204041/Mother-Bournemouth-drowning-victim-reveals-heartbreaking-moment-told-girl-died.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12204041/Mother-Bournemouth-drowning-victim-reveals-heartbreaking-moment-told-girl-died.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 20:30:25+00:00

Sunnah Khan's mother, Stephanie Williams, has spoken out to warn people of the dangers of riptides, and revealed the devastating moment she found out her little girl's life had been claimed.

## Jeffrey Epstein: US Virgin Islands' Former First Lady email revealed
 - [https://www.dailymail.co.uk/news/article-12203915/Jeffrey-Epstein-Virgin-Islands-Former-Lady-email-revealed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203915/Jeffrey-Epstein-Virgin-Islands-Former-Lady-email-revealed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 20:29:21+00:00

Cecile de Jongh worked for Epstein from 2000, managing his USVI office, and was the First Lady of the territory from 2007-15. JPMorgan has filed against her.

## EXCLUSIVE Nottingham victim Grace O'Malley-Kumar 'died a hero' after trying to save friend Barnaby
 - [https://www.dailymail.co.uk/news/article-12204025/EXCLUSIVE-Nottingham-victim-Grace-OMalley-Kumar-died-hero-trying-save-friend-Barnaby.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12204025/EXCLUSIVE-Nottingham-victim-Grace-OMalley-Kumar-died-hero-trying-save-friend-Barnaby.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 20:18:56+00:00

EXCLUSIVE Grace O'Malley-Kumar (left), 19, had the opportunity to flee the attack after her friend Barnaby Webber (right), also 19, was stabbed from behind by a figure dressed in black on Tuesday.

## Colombia jungle dad admits he DID have affair and says kids are 'delicate and sick' in hospital
 - [https://www.dailymail.co.uk/news/article-12202883/Colombia-jungle-dad-admits-DID-affair-says-kids-delicate-sick-hospital.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202883/Colombia-jungle-dad-admits-DID-affair-says-kids-delicate-sick-hospital.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 20:17:13+00:00

Manuel Ranoque, the father of two of the children who survived  a plane crash says the children, all under 15, are too ill to see visitors as they recuperate in hospital

## Tourist bathing lake invaded by swarm of jellyfish leading to unpleasant surprise for swimmers
 - [https://www.dailymail.co.uk/news/article-12204183/Tourist-bathing-lake-invaded-swarm-jellyfish-leading-unpleasant-surprise-swimmers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12204183/Tourist-bathing-lake-invaded-swarm-jellyfish-leading-unpleasant-surprise-swimmers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 20:06:47+00:00

The creatures were pictured washed up on Clevedon's Marine Lake near Bristol and while experts say people can still swim safely in the area, they have advised them to remain vigilant

## PICTURED: Gunman who killed his wife, her daughter and three kids, in horrific murder-suicide
 - [https://www.dailymail.co.uk/news/article-12204175/PICTURED-Gunman-killed-wife-daughter-three-kids-horrific-murder-suicide.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12204175/PICTURED-Gunman-killed-wife-daughter-three-kids-horrific-murder-suicide.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 19:48:27+00:00

Gary Barnett was Friday named as the gunman who massacred his estranged wife Regina Barnett, her daughter Britney Perez and three kids before torching the home in Marion County.

## Inside house of horrors where couple stored and sold human parts from Harvard Medical School morgue
 - [https://www.dailymail.co.uk/news/article-12202943/Inside-house-horrors-couple-stored-sold-human-parts-Harvard-Medical-School-morgue.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202943/Inside-house-horrors-couple-stored-sold-human-parts-Harvard-Medical-School-morgue.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 19:47:02+00:00

Cedric Lodge, 55, is accused of taking heads, skin, bones and brains from cadavers donated to Harvard's Medical School - which he had access to as morgue manager.

## Fox News producer who resigned over bashing Biden with 'wannabe dictator chyron' breaks his silence
 - [https://www.dailymail.co.uk/news/article-12204011/Fox-News-producer-resigned-bashing-Biden-wannabe-dictator-chyron-breaks-silence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12204011/Fox-News-producer-resigned-bashing-Biden-wannabe-dictator-chyron-breaks-silence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 19:45:18+00:00

A Fox News producer who resigned over a chyron that described Joe Biden as a 'wannabe dictator, has broken his silence.

## Pentagon Papers leaker Daniel Ellsberg dead at 92 from pancreatic cancer
 - [https://www.dailymail.co.uk/news/article-12204139/Pentagon-Papers-leaker-Daniel-Ellsberg-dead-92-pancreatic-cancer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12204139/Pentagon-Papers-leaker-Daniel-Ellsberg-dead-92-pancreatic-cancer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 19:44:28+00:00

The ex-military analyst was once dubbed 'the most dangerous man in America' after he revealed in 1971 how top U.S. officials had misled the public over the conflict.

## Meet the 'magnificent seven': Experts claim these high-flying tech stocks are the ones to watch
 - [https://www.dailymail.co.uk/news/article-12203603/Meet-magnificent-seven-Experts-claim-high-flying-tech-stocks-ones-watch.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203603/Meet-magnificent-seven-Experts-claim-high-flying-tech-stocks-ones-watch.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 19:44:02+00:00

As inflation remains sticky and fears of a recession still loom, experts say a 'magnificent seven' stocks are emerging - and they could be the safest place to invest your money.

## Nearly 50 Spanish tourist beaches given 'Black Flag' status for problems including chemical spills
 - [https://www.dailymail.co.uk/news/article-12204211/Nearly-50-Spanish-tourist-beaches-given-Black-Flag-status-problems-including-chemical-spills.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12204211/Nearly-50-Spanish-tourist-beaches-given-Black-Flag-status-problems-including-chemical-spills.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 19:42:35+00:00

Toxic chemical spills, dog muck and invasive developments are the contributing factors behind the damning report which has looked into 48 beaches.

## Transgender activist Rose Montoya apologizes for flashing her breasts at White House Pride event
 - [https://www.dailymail.co.uk/news/article-12204129/Transgender-activist-Rose-Montoya-apologizes-flashing-breasts-White-House-Pride-event.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12204129/Transgender-activist-Rose-Montoya-apologizes-flashing-breasts-White-House-Pride-event.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 19:40:58+00:00

Transgender activist Rose Montoya has apologized for flashing her breasts at a White House Pride event last week.

## Republican reveals his staffer attacked by armed assailants in DC after Congressional Baseball Game
 - [https://www.dailymail.co.uk/news/article-12203939/Republican-reveals-staffer-attacked-armed-assailants-DC-Congressional-Baseball-Game.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203939/Republican-reveals-staffer-attacked-armed-assailants-DC-Congressional-Baseball-Game.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 19:27:11+00:00

GOP Rep. Brad Finstad revealed that a staffer in his office was attacked by an armed gunman after the annual congressional baseball game blocks away from the Capitol.

## TikTok star Carl Eiswerth dies in crash in Pennsylvania
 - [https://www.dailymail.co.uk/news/article-12203727/TikTok-star-Carl-Eiswerth-dies-crash-Pennsylvania.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203727/TikTok-star-Carl-Eiswerth-dies-crash-Pennsylvania.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 19:22:55+00:00

Carl Eiswerth, 35, was sitting in the passenger seat when another vehicle hit his close friend's car on Tuesday on Route 11 in Monroe Township. He was pronounced dead at the scene.

## Prince Andrew excluded from historic Order of the Garter procession for second year in a row
 - [https://www.dailymail.co.uk/news/article-12204085/Prince-Andrew-excluded-historic-Order-Garter-procession-second-year-row.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12204085/Prince-Andrew-excluded-historic-Order-Garter-procession-second-year-row.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 19:15:16+00:00

Prince Andrew, 63, did not take part in the procession last year but was allowed to wear the lavish robes at the coronation of the King and Queen on May 6. He will attend the investiture and lunch.

## WIGHT OUT: Thousands of revellers at popular UK music festival face a drenching
 - [https://www.dailymail.co.uk/news/article-12203987/WIGHT-Thousands-revellers-popular-UK-music-festival-face-washed-away.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203987/WIGHT-Thousands-revellers-popular-UK-music-festival-face-washed-away.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 19:04:11+00:00

Headliners Robbie Williams and Niall Horan could see their sets interrupted by the bad weather as the Met Office has issued a yellow weather warning for thunderstorms on Sunday.

## 'America's TV Dad' John Amos, 83, accuses daughter of elderly abuse
 - [https://www.dailymail.co.uk/news/article-12203501/Americas-TV-Dad-John-Amos-accuses-daughter-elderly-abuse.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203501/Americas-TV-Dad-John-Amos-accuses-daughter-elderly-abuse.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 18:56:38+00:00

Amos, who starred in Good Times, Coming to America and The West Wing, released a video on his son's TikTok account earlier this week. It shows him lying in a hospital gown.

## AT&T becomes latest San Francisco casualty: Telecommunications giant shuts flagship store
 - [https://www.dailymail.co.uk/news/article-12203637/AT-T-latest-San-Francisco-casualty-Telecommunications-giant-shuts-flagship-store.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203637/AT-T-latest-San-Francisco-casualty-Telecommunications-giant-shuts-flagship-store.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 18:46:05+00:00

AT&amp;T has announced that it will close its flagship store in downtown San Francisco.

## Police to investigate 'hateful behaviour' after several Pride flags are defaced in Gloucestershire
 - [https://www.dailymail.co.uk/news/article-12204057/Police-investigate-hateful-behaviour-Pride-flags-defaced-Gloucestershire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12204057/Police-investigate-hateful-behaviour-Pride-flags-defaced-Gloucestershire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 18:42:01+00:00

Investigating officers from Gloucestershire Police are appealing for information about the attacks which are being treated as suspected hate crimes.

## Woman who's husband was killed by bin lorry says she'll 'never' get over tragedy
 - [https://www.dailymail.co.uk/news/article-12203977/Woman-whos-husband-killed-bin-lorry-says-shell-never-tragedy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203977/Woman-whos-husband-killed-bin-lorry-says-shell-never-tragedy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 18:30:36+00:00

The wife of 37-year-old Steve Bishop, who died in October 2017, has said she and her three sons will never recover from his death as Chelmsford Council were fined £80,000 over the tragedy

## Experienced scuba diver, 73, loses her leg in horrific shark attack in the Bahamas
 - [https://www.dailymail.co.uk/news/article-12203597/Experienced-scuba-diver-73-loses-leg-horrific-shark-attack-Bahamas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203597/Experienced-scuba-diver-73-loses-leg-horrific-shark-attack-Bahamas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 18:29:19+00:00

An experienced diver from Iowa has lost her leg in a shark attack in the Bahamas while climbing into a boat.

## Man, 44, charged with stalking MP and impersonating police officer
 - [https://www.dailymail.co.uk/news/article-12203971/Man-44-charged-stalking-MP-impersonating-police-officer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203971/Man-44-charged-stalking-MP-impersonating-police-officer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 18:28:28+00:00

Simon Parry, 44, was charged with one count of stalking and one count of impersonating a police officer today, police said. He was remanded in police custody to appear in court on Saturday.

## University shuts down its CCP-linked Confucius Institute after scrutiny from top Republican
 - [https://www.dailymail.co.uk/news/article-12202949/University-shuts-CCP-linked-Confucius-Institute-scrutiny-Republican.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202949/University-shuts-CCP-linked-Confucius-Institute-scrutiny-Republican.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 18:27:49+00:00

Alfred University has agreed to close its Confucius Institute following outrage over national security concerns by GOP Chairman Mike Gallagher.

## Father claims Sadiq Khan's will 'rip his life apart' over new ULEZ regulations
 - [https://www.dailymail.co.uk/news/article-12203913/Father-claims-Sadiq-Khans-rip-life-apart-new-ULEZ-regulations.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203913/Father-claims-Sadiq-Khans-rip-life-apart-new-ULEZ-regulations.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 18:13:41+00:00

Paul Bates, 50, says the £12.50 daily fee for non-compliant vehicles is set to cut the amount of time he can spend with his nine-year-old daughter, Kylie.

## MATT PALUMBO: As George Soros heir takes over $25B empire, here's what mainstream media won't say
 - [https://www.dailymail.co.uk/news/article-12203675/MATT-PALUMBO-George-Soros-heir-takes-25B-empire-heres-mainstream-media-wont-say.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203675/MATT-PALUMBO-George-Soros-heir-takes-25B-empire-heres-mainstream-media-wont-say.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 18:13:09+00:00

PALUMBO: Alex Soros is officially taking over his father George's kingdom. Along with more money than God, he inherits an empire of influence rivaling governments and reaching beyond national borders.

## Sadiq Khan's green fund loses £3.2m after electric car firm goes into administration
 - [https://www.dailymail.co.uk/news/article-12203861/Sadiq-Khans-green-fund-loses-3-2m-electric-car-firm-goes-administration.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203861/Sadiq-Khans-green-fund-loses-3-2m-electric-car-firm-goes-administration.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 18:12:59+00:00

The company had £3.2m injected into it by the Mayor of London's Energy Efficiency Fund (MEEF). It supplied electric vehicles to a range of customers and allows them to buy their car after subscribing.

## Georgia Bilham: How did middle-class Cheshire girl become convicted sex offender?
 - [https://www.dailymail.co.uk/news/article-12203441/Georgia-Bilham-did-middle-class-Cheshire-girl-convicted-sex-offender.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203441/Georgia-Bilham-did-middle-class-Cheshire-girl-convicted-sex-offender.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 17:52:10+00:00

Nothing could have prepared the 60-year-old father of Georgia Bilham for the message he received on Facebook - the revealed his daughter had been posing as a boy to kiss another woman.

## Sister of 'Christmas Day killer' describes 'brilliant' relationship with her brother
 - [https://www.dailymail.co.uk/news/article-12203865/Sister-Christmas-Day-killer-describes-brilliant-relationship-brother.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203865/Sister-Christmas-Day-killer-describes-brilliant-relationship-brother.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 17:51:52+00:00

Construction boss Adam Jenkins, 39, killed Simon Birch (pictured), known as 'Birchy', on Christmas Day in 2021. His sister Emma, whose partner was killed, said her relationship with her brother was 'brilliant'.

## Police find body of missing woman, 29, after her car was left abandoned near Trans Pennine Trail
 - [https://www.dailymail.co.uk/news/article-12203655/Police-body-missing-woman-29-car-left-abandoned-near-Trans-Pennine-Trail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203655/Police-body-missing-woman-29-car-left-abandoned-near-Trans-Pennine-Trail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 17:46:26+00:00

Thea Newton, 29, was last seen at around 1.30am today at her home address in Warrington, Cheshire. Cheshire Police has now confirmed they have found a body in their search.

## Elderly Americans are robbed of $20 BILLION a year by friends and family
 - [https://www.dailymail.co.uk/news/article-12203273/Elderly-Americans-robbed-20-BILLION-year-friends-family.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203273/Elderly-Americans-robbed-20-BILLION-year-friends-family.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 17:42:04+00:00

Older Americans are losing $20.3 billion each year to 'financial exploitation' by their friends and family, a shocking new report lays bare.

## Boy, 13, revolts against school's 'no shorts' policy and attends classes wearing skirt
 - [https://www.dailymail.co.uk/news/article-12203789/Boy-13-revolts-against-schools-no-shorts-policy-attends-classes-wearing-skirt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203789/Boy-13-revolts-against-schools-no-shorts-policy-attends-classes-wearing-skirt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 17:36:06+00:00

Bodhi Gillon, 13, instead pulled on a skirt to go to lessons at Marple Hall School in Stockport as his teachers made no allowances for boys despite the sweltering heat.

## Duckworth rips Sinema for proposal that would require pilots to have less training to fly commercial
 - [https://www.dailymail.co.uk/news/article-12203593/Duckworth-rips-Sinema-proposal-require-pilots-training-fly-commercial.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203593/Duckworth-rips-Sinema-proposal-require-pilots-training-fly-commercial.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 17:24:27+00:00

Sen. Tammy Duckworth tore into Sens. Kyrsten Sinema and John Thune for an amendment they proposed that would reduce the number of flying hours pilots would need to fly commercial.

## Woman accused of pushing Army veteran boyfriend into suicide mourned him as a 'great father'
 - [https://www.dailymail.co.uk/news/article-12200459/Woman-accused-pushing-Army-veteran-boyfriend-suicide-mourned-great-father.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12200459/Woman-accused-pushing-Army-veteran-boyfriend-suicide-mourned-great-father.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 17:23:29+00:00

The new lover of the mother accused of driving her estranged Army veteran boyfriend to suicide has revealed how she became a 'martyr' after his death, mourning him as a 'great father.'

## Young black bear is captured after scaling fence at Tampa airport and wandering around the tarmac
 - [https://www.dailymail.co.uk/news/article-12203429/Young-black-bear-captured-scaling-fence-Tampa-airport-wandering-tarmac.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203429/Young-black-bear-captured-scaling-fence-Tampa-airport-wandering-tarmac.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 17:20:57+00:00

One little bear was ready to hop on the next flight out of the Tampa International Airport, but unfortunately the airport said no bears allowed.

## Tesco Clubcard users blast the supermarket giant for leaving them 'hundreds of pounds out of pocket'
 - [https://www.dailymail.co.uk/news/article-12203733/Tesco-Clubcard-users-blast-supermarket-giant-leaving-hundreds-pounds-pocket.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203733/Tesco-Clubcard-users-blast-supermarket-giant-leaving-hundreds-pounds-pocket.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 17:18:13+00:00

Furious Tesco shoppers have blasted the supermarket giant for leaving them 'hundreds of pounds out of pocket' due to new Clubcard rules.

## 'Sadistic' convicted killer caught torturing hedgehog is jailed for three years
 - [https://www.dailymail.co.uk/news/article-12203745/Sadistic-convicted-killer-caught-torturing-hedgehog-jailed-three-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203745/Sadistic-convicted-killer-caught-torturing-hedgehog-jailed-three-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 17:15:27+00:00

Police forced their way into Richard Coyle's barricaded bedroom to find him torturing the hedgehog, whose stomach had been cut open while it was still alive, in September last year in Caerphilly.

## Partygate showdown is set to descend into farce as Rishi Sunak and other MPs may skip vote
 - [https://www.dailymail.co.uk/news/article-12203771/Partygate-showdown-set-descend-farce-Rishi-Sunak-MPs-skip-vote.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203771/Partygate-showdown-set-descend-farce-Rishi-Sunak-MPs-skip-vote.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 17:12:51+00:00

Senior figures now increasingly believe the debate will be a damp squib, likely to end early due to a lack of speakers and attempts under way  to avoid the planned free vote.

## Hunter Biden FINALLY answers questions about shady finances in deposition
 - [https://www.dailymail.co.uk/news/article-12191535/Hunter-Biden-FINALLY-answers-questions-shady-finances-deposition.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12191535/Hunter-Biden-FINALLY-answers-questions-shady-finances-deposition.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 17:09:51+00:00

Hunter Biden was forced to answer questions about his shady finances Friday in Arkansas as part of his bitter paternity battle with baby mama Lunden Roberts.

## 'Person of interest' in death of rapper Young Dolph, is found shot dead
 - [https://www.dailymail.co.uk/news/article-12203415/Person-death-rapper-Young-Dolph-shot-dead.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203415/Person-death-rapper-Young-Dolph-shot-dead.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 17:03:39+00:00

A man named as a 'person of interest' in the murder of rapper Young Dolph, has been found shot dead.

## Poignant moment Barmy Army trumpeter plays Amazing Grace at Ashes in tribute to Nottingham victims
 - [https://www.dailymail.co.uk/news/article-12203605/Poignant-moment-Barmy-Army-trumpeter-plays-Amazing-Grace-Ashes-tribute-Nottingham-victims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203605/Poignant-moment-Barmy-Army-trumpeter-plays-Amazing-Grace-Ashes-tribute-Nottingham-victims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 16:51:53+00:00

This is the moving moment the Barmy Army trumpeter played classic hymn Amazing Grace in tribute to the victims of a shocking attack in Nottingham.

## Family of 19-year-old clubbed to death by Levi Bellfield cannot 'bear to think' about him marrying
 - [https://www.dailymail.co.uk/news/article-12203389/Family-19-year-old-clubbed-death-Levi-Bellfield-bear-think-marrying.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203389/Family-19-year-old-clubbed-death-Levi-Bellfield-bear-think-marrying.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 16:51:10+00:00

Convicted killer Levi Bellfield will be given permission to marry his partner while serving life at Durham's Frankland Prison, devastating the family of one of his victims, Marsha McDonnell

## Trump demands the classified documents indictment is WITHDRAWN and the DOJ apologize
 - [https://www.dailymail.co.uk/news/article-12203635/Trump-demands-classified-documents-indictment-WITHDRAWN-DOJ-apologize.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203635/Trump-demands-classified-documents-indictment-WITHDRAWN-DOJ-apologize.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 16:38:17+00:00

The 77-year-old former president made his demands on his Truth Social platform on which he has lashed out at DOJ officials for bringing the case against him.

## Biden will 'have to deal with' his age on the campaign trail, top Democrat says
 - [https://www.dailymail.co.uk/news/article-12203127/Biden-deal-age-campaign-trail-Democrat-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203127/Biden-deal-age-campaign-trail-Democrat-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 16:28:04+00:00

One of President Joe Biden's Democratic allies, Sen. Sheldon Whitehouse, said this week that the 80-year-old leader's age is something he will 'have to deal with' on the campaign trail.

## Utah anchors 'feel duped' and 'sickened' over interview with Kouri Richins who killed husband
 - [https://www.dailymail.co.uk/news/article-12203103/Utah-anchors-feel-duped-sickened-interview-Kouri-Richins-killed-husband.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203103/Utah-anchors-feel-duped-sickened-interview-Kouri-Richins-killed-husband.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 16:25:55+00:00

Deena Manzanares and Surae Chinn, the hosts of KTVX's 'Good Things Utah', said they felt disturbed by the interview with murder-accused mother Kouri Richins.

## Pittsburgh synagogue gunman facing the death penalty
 - [https://www.dailymail.co.uk/news/article-12203631/Pittsburgh-synagogue-gunman-facing-death-penalty.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203631/Pittsburgh-synagogue-gunman-facing-death-penalty.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 16:25:29+00:00

Robert Bowers', a truck driver, slaughtered his victims at the Tree of Life Synagogue  on October 28, 2018.

## New Spider-Man movie PULLED in Muslim-majority countries because of 'Protect Trans Kids' poster
 - [https://www.dailymail.co.uk/news/article-12203023/New-Spider-Man-movie-PULLED-Muslim-majority-countries-Protect-Trans-Kids-poster.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203023/New-Spider-Man-movie-PULLED-Muslim-majority-countries-Protect-Trans-Kids-poster.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 16:23:36+00:00

The poster was spotted in the character Gwen Stacy's bedroom above her door for a brief moment. Many countries, including the United Arabs Emirates, will not release the movie.

## Four people hospitalized after boat crash on a Navy property in San Diego
 - [https://www.dailymail.co.uk/news/article-12203599/Four-people-hospitalized-boat-crash-Navy-property-San-Diego.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203599/Four-people-hospitalized-boat-crash-Navy-property-San-Diego.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 16:23:35+00:00

Four people have been taken to hospital after a boat crash at a San Diego Naval Base in the early hours of Friday morning.

## BORIS JOHNSON: Wonder drug I hoped would stop my raids for cheddar and chorizo didn't work for me
 - [https://www.dailymail.co.uk/news/article-12203407/BORIS-JOHNSON-Wonder-drug-hoped-stop-raids-cheddar-chorizo-didnt-work-me.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203407/BORIS-JOHNSON-Wonder-drug-hoped-stop-raids-cheddar-chorizo-didnt-work-me.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 16:20:04+00:00

I first thought that something was up when I saw that a certain member of the Cabinet had miraculously changed his appearance. He had acquired a new jawline.

## Anheuser-Busch, Target and Kohls lost a collective $28.7 BILLION in market value amid Pride backlash
 - [https://www.dailymail.co.uk/news/article-12202849/Anheuser-Busch-Target-Kohls-lost-collective-28-7-BILLION-market-value-amid-Pride-backlash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202849/Anheuser-Busch-Target-Kohls-lost-collective-28-7-BILLION-market-value-amid-Pride-backlash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 16:08:16+00:00

Since the beginning of April all three have seen their market value plummet - with only Kohl's starting to recover from the backlash against their Pride campaigns.

## Minneapolis cops used excessive force and targeted racial minorities BEFORE George Floyd death: DOJ
 - [https://www.dailymail.co.uk/news/article-12203487/Minneapolis-cops-used-excessive-force-targeted-racial-minorities-George-Floyd-death-DOJ.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203487/Minneapolis-cops-used-excessive-force-targeted-racial-minorities-George-Floyd-death-DOJ.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 16:07:15+00:00

Minneapolis cops
used excessive force, discriminated against black people, mistreated mentally ill individuals and violated First Amendment rights, the Department of Justice said Friday.

## Moment emergency door bursts open mid-flight after plane takes off in Brazil
 - [https://www.dailymail.co.uk/news/article-12203263/Moment-emergency-door-bursts-open-mid-flight-plane-takes-Brazil.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203263/Moment-emergency-door-bursts-open-mid-flight-plane-takes-Brazil.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 15:53:30+00:00

Passengers were left terrified after an emergency door on their flight in Brazil suddenly burst open thousands of feet in the air.

## Paramedics who entered room at Mexico resort where American couple were found dead felt dizzy
 - [https://www.dailymail.co.uk/news/article-12202793/Paramedics-entered-room-Mexico-resort-American-couple-dead-felt-dizzy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202793/Paramedics-entered-room-Mexico-resort-American-couple-dead-felt-dizzy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 15:47:40+00:00

Paramedics said on entering a room in which  an American couple was found dead, they felt dizzy and feared they would die.

## Aquinas College, Gold Coast: Teachers allegedly caught having sex in classroom
 - [https://www.dailymail.co.uk/news/article-12202851/Aquinas-College-Gold-Coast-Teachers-allegedly-caught-having-sex-classroom.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202851/Aquinas-College-Gold-Coast-Teachers-allegedly-caught-having-sex-classroom.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 15:45:20+00:00

Two teachers at a Gold Coast Catholic private school have been stood down after they were allegedly caught having sex in a classroom by a student.

## 'World's oldest woman' celebrates upcoming '123rd birthday' in Brazil
 - [https://www.dailymail.co.uk/news/article-12203445/Worlds-oldest-woman-celebrates-upcoming-123rd-birthday-Brazil.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203445/Worlds-oldest-woman-celebrates-upcoming-123rd-birthday-Brazil.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 15:41:43+00:00

Amantina dos Santos Duvirgem, 122, has celebrated her upcoming 123rd birthday with cake in Parana State, Brazil, at a party organised by the state's civic officials.

## Indiana man, 20, is charged with raping family dog and threatening to kill his mother
 - [https://www.dailymail.co.uk/news/article-12203141/Indiana-man-20-charged-raping-family-dog-threatening-kill-mother.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203141/Indiana-man-20-charged-raping-family-dog-threatening-kill-mother.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 15:35:24+00:00

Blake Reffett, from Elkhart, was charged with bestiality and intimidation with a deadly weapon on June 9 after his mother allegedly saw him raping the dog while it was pinned to the couch in March last year.

## Australian suburbs that are no longer part of the $1million club following 12 interest rate rises
 - [https://www.dailymail.co.uk/news/article-12201407/Australian-suburbs-no-longer-1million-club-following-12-rate-rises.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201407/Australian-suburbs-no-longer-1million-club-following-12-rate-rises.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 15:18:21+00:00

House prices have fallen below $1million again in idyllic beachside areas from the Gold Coast to Melbourne's Mornington Peninsula and parts of Sydney as interest rates increase.

## Gold Coast gardener left puzzled after finding 'oozing mass' growing in his veggie patch
 - [https://www.dailymail.co.uk/news/article-12202861/Gold-Coast-gardener-left-puzzled-finding-oozing-mass-growing-veggie-patch.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202861/Gold-Coast-gardener-left-puzzled-finding-oozing-mass-growing-veggie-patch.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 15:17:37+00:00

An eagled-eyed gardener has been left puzzled after discovering a mysterious 'oozing mass' growing on his veggie patch this week.

## Trump holds 34 POINT lead over DeSantis in New Hampshire
 - [https://www.dailymail.co.uk/news/article-12203085/Trump-holds-34-POINT-lead-DeSantis-New-Hampshire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203085/Trump-holds-34-POINT-lead-DeSantis-New-Hampshire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 15:10:12+00:00

The former president holds a wide lead over his Republican rivals in the early primary state. His support reaches 47 per cent in a new New Hampshire Journal poll.

## 'Lottery lawyer' who stole $107M from winners  gets 13 years for mobbed-up scheme
 - [https://www.dailymail.co.uk/news/article-12203043/Lottery-lawyer-stole-107M-winners-gets-13-years-mobbed-scheme.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203043/Lottery-lawyer-stole-107M-winners-gets-13-years-mobbed-scheme.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 15:10:06+00:00

A Long Island man dubbed the 'Lottery Lawyer' who conned his lottery winning clients out of $107 million to fuel his lavish lifestyle of yachts, vacations and fancy cars has been jailed for 13 years.

## EXCLUSIVE Pictured: Nottingham triple murder suspect, 31, inside his university halls
 - [https://www.dailymail.co.uk/news/article-12203105/EXCLUSIVE-Pictured-Nottingham-triple-murder-suspect-31-inside-university-halls.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203105/EXCLUSIVE-Pictured-Nottingham-triple-murder-suspect-31-inside-university-halls.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 15:09:56+00:00

Valdo Calocane, 31, was today charged with murdering 19-year-old students Barnaby Webber and Grace O'Malley-Kumar, and school caretaker Ian Coates.

## Murdered student Barnaby Webber's heartbroken family visit the spot where he was killed
 - [https://www.dailymail.co.uk/news/article-12202905/Murdered-student-Barnaby-Webbers-heartbroken-family-visit-spot-killed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202905/Murdered-student-Barnaby-Webbers-heartbroken-family-visit-spot-killed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 15:09:18+00:00

Barnaby's heartbroken parents, David and Emma, alongside his younger brother Charlie, looked down at the touching scene of flowers and cards at Ilkeston Road.

## Another 200 migrants arrive in Dover after five inflatable dinghies are intercepted in the Channel
 - [https://www.dailymail.co.uk/news/article-12203221/Another-200-migrants-arrive-Dover-five-inflatable-dinghies-intercepted-Channel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203221/Another-200-migrants-arrive-Dover-five-inflatable-dinghies-intercepted-Channel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 15:09:06+00:00

The dinghies - which hold between 40 and 50 people on average - were escorted into Dover, Kent, by Border Force officials and the RNLI.

## Fox News is 'on the verge' of settling lawsuit with former producer Abby Grossberg
 - [https://www.dailymail.co.uk/news/article-12202987/Fox-News-verge-settling-lawsuit-former-producer-Abby-Grossberg.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202987/Fox-News-verge-settling-lawsuit-former-producer-Abby-Grossberg.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 15:07:08+00:00

Fox News is finalizing a settlement with Abby Grossberg, after she sued the network over claims Tucker Carlson's team was plagued by 'sexism, bullying and anti-Semitism.

## AO World boss says working from home doesn't work
 - [https://www.dailymail.co.uk/news/article-12202383/AO-World-boss-says-working-home-doesnt-work.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202383/AO-World-boss-says-working-home-doesnt-work.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 15:06:04+00:00

John Roberts said bosses at Bolton-based retailer AO World, which has 3,000 employees, decided in January that staff coming into the office only intermittently 'doesn't work'.

## Heather Mack faces up to 28 years in prison after pleading guilty to conspiracy to kill mom
 - [https://www.dailymail.co.uk/news/article-12203281/Heather-Mack-faces-28-years-prison-pleading-guilty-conspiracy-kill-mom.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203281/Heather-Mack-faces-28-years-prison-pleading-guilty-conspiracy-kill-mom.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 15:05:04+00:00

'Suitcase Killer' Heather Mack pleaded guilty in a Chicago court to conspiring to murder her mother while on vacation in Bali in 2014.

## More than 50 million Americans are under severe storm threat
 - [https://www.dailymail.co.uk/news/article-12202923/More-50-million-Americans-severe-storm-threat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202923/More-50-million-Americans-severe-storm-threat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 15:02:38+00:00

More than 50 million Americans were placed under a severe weather threat on Friday, after a deadly storm killed three in Texas and one in Florida.

## How migration CUT the UK population for a century until the 1990s
 - [https://www.dailymail.co.uk/news/article-12170097/How-migration-CUT-UK-population-century-1990s.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12170097/How-migration-CUT-UK-population-century-1990s.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 14:58:42+00:00

Historical figures compiled by the Bank of England show that between 1850 and the 1980s emigration consistently exceeded arrivals.

## What is Trooping the Colour? Royal parade explained
 - [https://www.dailymail.co.uk/news/article-12195007/What-Trooping-Colour-Royal-parade-explained.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12195007/What-Trooping-Colour-Royal-parade-explained.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 14:57:53+00:00

King Charles III will experience his first Trooping the Colour as King in 2023, with the annual event set to return on Saturday June 17.

## Factory worker fighting for life after Nottingham van and knife attacks is now stable in hospital
 - [https://www.dailymail.co.uk/news/article-12203143/Factory-worker-fighting-life-Nottingham-van-knife-attacks-stable-hospital.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203143/Factory-worker-fighting-life-Nottingham-van-knife-attacks-stable-hospital.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 14:56:55+00:00

Factory worker Wayne Birkett, 58, was struck a stolen car moments after he got off a bus during the Nottingham attacks in the early hours of Tuesday. (Pictured: yesterday's vigil in memory of the victims)

## Man, 31, is charged with murder of three people killed in Nottingham knife and van attack
 - [https://www.dailymail.co.uk/news/article-12203225/Man-31-charged-murder-three-people-killed-Nottingham-knife-van-attack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203225/Man-31-charged-murder-three-people-killed-Nottingham-knife-van-attack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 14:52:56+00:00

Valdo Calocane, 31, has been charged with the murder of three people killed in Nottingham in a knife and van attack. Pictured is victim Grace O'Malley-Kumar.

## Villagers slam plans to light up statue of a naked man at night amid fears it will disract drivers
 - [https://www.dailymail.co.uk/news/article-12203217/Villagers-slam-plans-light-statue-naked-man-night-amid-fears-disract-drivers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203217/Villagers-slam-plans-light-statue-naked-man-night-amid-fears-disract-drivers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 14:51:24+00:00

The 26ft high statue called the Yoxman has already been labelled a danger to traffic by some locals due to drivers staring at it as they drive past.

## Sergeant, 41, is kicked out of Army for punching junior as they were on Nato frontline near Russia
 - [https://www.dailymail.co.uk/news/article-12202771/Sergeant-41-kicked-Army-punching-junior-Nato-frontline-near-Russia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202771/Sergeant-41-kicked-Army-punching-junior-Nato-frontline-near-Russia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 14:50:04+00:00

Sgt Penijamini Qoroya (pictured), 41, who was in charge of ensuring his troops behaved themselves at a pub, was left enraged when Lance Bombardier Robert Carr defied his alcohol rules.

## Albion Park, NSW: Teenage boy, 13, killed in 'high-speed' e-bike crash
 - [https://www.dailymail.co.uk/news/article-12203089/Albion-Park-NSW-Teenage-boy-13-killed-high-speed-e-bike-crash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203089/Albion-Park-NSW-Teenage-boy-13-killed-high-speed-e-bike-crash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 14:47:31+00:00

It's understood the 13-year-old boy was on his way to the shops when he slammed  into a wooden barrier at Di Gorman Oval in Albion Park, in NSW's Illawarra region, at about 6.40pm on Friday night.

## Borrowers spending the most income on mortgages since 2008
 - [https://www.dailymail.co.uk/money/article-12202145/Britons-spending-income-mortgage-time-2008.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/money/article-12202145/Britons-spending-income-mortgage-time-2008.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 14:41:16+00:00

Repayments on new mortgages accounted for an average of 20 per cent of borrowers' gross incomes between January and April, according to trade body UK Finance.

## Porn stars walk out of European Sex Championships, declaring it 'chaos'
 - [https://www.dailymail.co.uk/news/article-12202461/Porn-stars-walk-European-Sex-Championships-declaring-chaos.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202461/Porn-stars-walk-European-Sex-Championships-declaring-chaos.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 14:40:52+00:00

The inaugural tournament was set to begin on June 8, with a reported 20 representatives from a dozen or so nations descending on an undisclosed location in Gothenburg, Sweden.

## Wall Street job cuts hit more than 15,000 as Citigroup gets rid of 5,500 jobs
 - [https://www.dailymail.co.uk/news/article-12202811/Wall-Street-job-cuts-hit-15-000-Citigroup-gets-rid-5-500-jobs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202811/Wall-Street-job-cuts-hit-15-000-Citigroup-gets-rid-5-500-jobs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 14:38:55+00:00

Citigroup has become the latest big US bank to announce layoffs with 5,000 redundancies as Wall Street job cuts have hit 15,000 this year.

## Major crackdown on popular baby products used by millions of Aussie parents
 - [https://www.dailymail.co.uk/news/article-12202463/Crackdown-popular-baby-products-used-millions-Aussie-parents-launched-safety-concerns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202463/Crackdown-popular-baby-products-used-millions-Aussie-parents-launched-safety-concerns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 14:36:59+00:00

The Australian Competition and Consumer Commission (ACCC) has announced infant sleep products will be among their top priorities in 2023-24.

## Greg Norman sued by female student claiming she was sexually assaulted at party at his home
 - [https://www.dailymail.co.uk/news/article-12200413/Greg-Norman-sued-female-student-claiming-sexually-assaulted-party-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12200413/Greg-Norman-sued-female-student-claiming-sexually-assaulted-party-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 14:36:46+00:00

A female high school student who attended a booze-fueled outdoor pool party at Greg Norman's house alleges she was sexually assaulted by two individuals.

## Biden business partner Devon Archer is COOPERATING with Republicans over alleged $10 million payment
 - [https://www.dailymail.co.uk/news/article-12203003/Biden-business-partner-Devon-Archer-COOPERATING-Republicans-alleged-10-million-payment.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203003/Biden-business-partner-Devon-Archer-COOPERATING-Republicans-alleged-10-million-payment.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 14:36:39+00:00

Biden family business associate Devon Archer is cooperating with House Republicans who are investigating an alleged $10 million bribery payment to Joe and Hunter Biden.

## Weekend travel information: Train and tube status, service disruptions and closure for 16-17th June
 - [https://www.dailymail.co.uk/news/article-12203033/Weekend-travel-information-Train-tube-status-service-disruptions-closure-16-17th-June.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203033/Weekend-travel-information-Train-tube-status-service-disruptions-closure-16-17th-June.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 14:26:34+00:00

Transport for London is expecting a busy weekend and various events held in the capital may affect your journey. Which services are affected this weekend? Are London Underground services disrupted?

## Prankster goes swimming in flooded Salford underpass after water bursts from hydrant onto street
 - [https://www.dailymail.co.uk/news/article-12202567/Prankster-goes-swimming-flooded-Salford-underpass-water-bursts-hydrant-street.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202567/Prankster-goes-swimming-flooded-Salford-underpass-water-bursts-hydrant-street.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 14:23:55+00:00

People in Salford have cooled off from the heat by swimming in through a subway that was flooded after a hydrant had been 'tampered with'. One prankster managed to get some front crawl in.

## How family of Hunter Valley bus crash victim Zach Bray found out their loved one had died
 - [https://www.dailymail.co.uk/news/article-12202271/How-family-Hunter-Valley-bus-crash-victim-Zach-Bray-loved-one-died.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202271/How-family-Hunter-Valley-bus-crash-victim-Zach-Bray-loved-one-died.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 14:19:10+00:00

Grief-stricken loved ones of Zachary Bray, one of ten people who died in the horror Hunter Valley bus crash on Sunday, say they knew hope was lost when their frantic phone calls went unanswered.

## Another river tragedy as boy, 14, dies in hospital after drowning accident claimed his friend, 15
 - [https://www.dailymail.co.uk/news/article-12203055/Another-river-tragedy-boy-14-dies-hospital-drowning-accident-claimed-friend-15.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203055/Another-river-tragedy-boy-14-dies-hospital-drowning-accident-claimed-friend-15.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 14:18:43+00:00

The death toll spanning Cumbria, Manchester and St Helens, Merseyside, has reached five teenagers who all lost their lives playing in waterways in the last month.

## Police launch search for mum of newborn baby after receiving 'distressing' phone call from phone box
 - [https://www.dailymail.co.uk/news/article-12202193/Distressed-call-sparks-search-new-mum.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202193/Distressed-call-sparks-search-new-mum.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 14:18:26+00:00

Police are appealing for information after a new mum in South Australia made a call to triple-0 in a 'distressed state'. They believe she is in need of urgent medical attention.

## Boys wear skirts to school in protest at 'no shorts' policies after 'sweltering' in trousers
 - [https://www.dailymail.co.uk/news/article-12202907/Boys-wear-skirts-school-protest-no-shorts-policies-sweltering-trousers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202907/Boys-wear-skirts-school-protest-no-shorts-policies-sweltering-trousers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 13:57:01+00:00

Oscar Ralph (pictured), 13, went into Ysgol Bro Dinefwr, in Llandeilo, wearing one of his sister's grey school uniform skirts yesterday saying no-one minded and it was easier to work.

## Bus driver, 59, charged after killing 67-year-old woman - second death linked to her driving
 - [https://www.dailymail.co.uk/news/article-12202939/Bus-driver-59-charged-killing-67-year-old-woman-second-death-linked-driving.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202939/Bus-driver-59-charged-killing-67-year-old-woman-second-death-linked-driving.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 13:53:51+00:00

Detroit bus driver Geraldine Johnson, 59, has been charged after killing a 67-year-old woman in the second death linked to her driving and the eighth crash since 2015.

## Mia Miller seen punching and spitting at McDonald's staff in CCTV footage of 'drunken rampage'
 - [https://www.dailymail.co.uk/news/article-12202275/Mia-Miller-seen-punching-spitting-McDonalds-staff-CCTV-footage-drunken-rampage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202275/Mia-Miller-seen-punching-spitting-McDonalds-staff-CCTV-footage-drunken-rampage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 13:51:48+00:00

Mia Miller, 19, unleashed on several employees after she was allegedly refused a cup of water in Adelaide's Hindley Street McDonald's in the early hours of October 7, 2022.

## Police officer is in serious condition after being stabbed as 48-year-old man is arrested
 - [https://www.dailymail.co.uk/news/article-12203083/Police-officer-condition-stabbed-48-year-old-man-arrested.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203083/Police-officer-condition-stabbed-48-year-old-man-arrested.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 13:51:06+00:00

A 48-year-old man has been arrested after a police officer was stabbed last night in Maidstone, leaving him in a serious but stable condition, Kent Police said.

## GMA tells their reporter NOT to go to downtown San Francisco because it's 'too dangerous'
 - [https://www.dailymail.co.uk/news/article-12202737/GMA-tells-reporter-NOT-downtown-San-Francisco-dangerous.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202737/GMA-tells-reporter-NOT-downtown-San-Francisco-dangerous.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 13:42:44+00:00

Chief correspondent Matt Gutman told viewers he had been advised against appearing live from Union Square or the mall for Abc's 4am Good Morning America segment

## Fury over South East Water hosepipe ban as fire rips through farm
 - [https://www.dailymail.co.uk/news/article-12202779/Fury-South-East-Water-hosepipe-ban-fire-rips-farm.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202779/Fury-South-East-Water-hosepipe-ban-fire-rips-farm.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 13:33:25+00:00

South East Water was slammed over a fire at a farm in Rotherfield, East Sussex, last night that could not be put out until firefighters arrived because the site had no water supply.

## Trump, DeSantis' teams get into ballsy exchange ahead of Nevada lamb testicle festival
 - [https://www.dailymail.co.uk/news/article-12202723/Trump-DeSantis-teams-ballsy-exchange-ahead-Nevada-lamb-testicle-festival.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202723/Trump-DeSantis-teams-ballsy-exchange-ahead-Nevada-lamb-testicle-festival.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 13:33:04+00:00

Aides for former President Donald Trump and Florida Gov. Ron DeSantis got into a ballsy exchange ahead of Saturday's Nevada lamb testicle festival.

## Six people, including two children, are killed and one is injured in Tennessee murder-suicide
 - [https://www.dailymail.co.uk/news/article-12202685/Six-people-including-two-children-killed-one-injured-Tennessee-murder-suicide.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202685/Six-people-including-two-children-killed-one-injured-Tennessee-murder-suicide.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 13:29:41+00:00

Six people, including two children, are dead in rural Tennessee following an horrific murder suicide that unfolded on Thursday night.

## Stanford prof who vanished before abuse trial claims he slipped on slope and became 'disoriented'
 - [https://www.dailymail.co.uk/news/article-12202787/Stanford-prof-vanished-abuse-trial-claims-slipped-slope-disoriented.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202787/Stanford-prof-vanished-abuse-trial-claims-slipped-slope-disoriented.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 13:25:44+00:00

Hunter Fraser, 44, was accused of slamming a door into his girlfriend , hitting her chest with the handle, and was scheduled to appear in court on June 9.

## British businesses are missing out on billions in overseas trade because of 'negative tropes'
 - [https://www.dailymail.co.uk/news/article-12202929/British-businesses-missing-billions-overseas-trade-negative-tropes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202929/British-businesses-missing-billions-overseas-trade-negative-tropes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 13:18:38+00:00

Business secretary Kemi Badenoch said businesses need to stop talking themselves down and realise there were 'many resources' out there to help with exporting goods to other countries.

## Meghan Markle and Prince Harry's last surviving media deal £81m one with Netflix
 - [https://www.dailymail.co.uk/femail/article-12202437/Meghan-Markle-Prince-Harrys-surviving-media-deal-81m-one-Netflix.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-12202437/Meghan-Markle-Prince-Harrys-surviving-media-deal-81m-one-Netflix.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 12:55:46+00:00

Since quitting their royal duties in 2020 and jetting off to California to live in their new $14million  mansion, the couple have been building a complex network of companies to help promote 'their truth'.

## Anheuser-Busch CEO Brendan Whitworth vows to protect jobs of workers as it drops NEW ad campaign
 - [https://www.dailymail.co.uk/news/article-12202645/Anheuser-Busch-CEO-Brendan-Whitworth-vows-protect-jobs-workers-drops-NEW-ad-campaign.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202645/Anheuser-Busch-CEO-Brendan-Whitworth-vows-protect-jobs-workers-drops-NEW-ad-campaign.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 12:53:24+00:00

Brendan Whitworth (left) Anheuser-Busch CEO, said the company would be 'investing' to protect their jobs for their frontline workers following the major backlash.

## Video shows how US woman thrown into German ravine was only stopped from sheer drop by fallen tree
 - [https://www.dailymail.co.uk/news/article-12202803/Video-shows-woman-thrown-German-ravine-stopped-sheer-drop-fallen-tree.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202803/Video-shows-woman-thrown-German-ravine-stopped-sheer-drop-fallen-tree.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 12:52:19+00:00

Police believe the 22-year-old woman was thrown over the edge after she tried to intervene when her friend was attacked by another US national - a 30-year-old man.

## Texas Governor Greg Abbott announces new ban on transgender college athletes
 - [https://www.dailymail.co.uk/news/article-12202295/Texas-Governor-Greg-Abbott-announces-new-ban-transgender-college-athletes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202295/Texas-Governor-Greg-Abbott-announces-new-ban-transgender-college-athletes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 12:50:55+00:00

Texas Governor Greg Abbott signed a law on Thursday that bans transgender college athletes in the state from competing as the gender with which they identify.

## Glastonbury weather forecast: Is it going to rain in Somerset on festival weekend?
 - [https://www.dailymail.co.uk/news/article-12202367/Glastonbury-weather-forecast-going-rain-Somerset-festival-weekend.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202367/Glastonbury-weather-forecast-going-rain-Somerset-festival-weekend.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 12:49:16+00:00

Whilst festival season is a time of excitement for many, there is one thing that can certainly dampen people's spirits: the dreaded British weather. Is the hot weather set to continue?

## Amanda Stoker blasts David Van after senator claimed to have 'no recollection' of alleged groping
 - [https://www.dailymail.co.uk/news/article-12202667/Amanda-Stoker-blasts-David-Van-senator-claimed-no-recollection-alleged-groping.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202667/Amanda-Stoker-blasts-David-Van-senator-claimed-no-recollection-alleged-groping.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 12:33:42+00:00

Sky News host Amanda Stoker host has blasted Liberal Senator David Van after he claimed to have 'no recollection' of squeezing her bottom twice in a parliamentary office in November 2020.

## Frontline officers hit out after their own chief constable says force is 'institutionally racist'
 - [https://www.dailymail.co.uk/news/article-12202701/Frontline-officers-hit-chief-constable-says-force-institutionally-racist.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202701/Frontline-officers-hit-chief-constable-says-force-institutionally-racist.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 12:06:33+00:00

Sarah Crew (pictured) said she had come to that conclusion about the Avon and Somerset force - which she has led since 2021 - following a series of damning reports into policing.

## Schoolboy lands on RATTLESNAKE after crashing bicycle - before viper sinks its fangs into his chest
 - [https://www.dailymail.co.uk/news/article-12202099/Schoolboy-lands-RATTLESNAKE-crashing-bicycle-viper-sinks-fangs-chest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202099/Schoolboy-lands-RATTLESNAKE-crashing-bicycle-viper-sinks-fangs-chest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 12:05:18+00:00

Ethan Vogel fell onto a rattlesnake just off the trail on North Table Mountain in Golden, Colorado. He has been discharged from hospital and is expected to make a full recovery.

## Mail unveils Boris Johnson as our new columnist
 - [https://www.dailymail.co.uk/news/article-12202525/Mail-unveils-Boris-Johnson-new-columnist.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202525/Mail-unveils-Boris-Johnson-new-columnist.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 12:01:07+00:00

It was the front page tease that got the whole of Britain talking. Who could the 'erudite new columnist' announced on the cover of today's Daily Mail possibly be?

## Manhattan financier charged with targeting 14-year-old girls on Instagram
 - [https://www.dailymail.co.uk/news/article-12202671/Manhattan-financier-charged-targeting-14-year-old-girls-Instagram.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202671/Manhattan-financier-charged-targeting-14-year-old-girls-Instagram.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 11:49:24+00:00

Michael Olson is charged with 17 counts of sexual abuse against one child, but Manhattan prosecutors are asking other victims to come forward.

## Unseen photos of the first transport of Polish citizens to Auschwitz in 1940 discovered
 - [https://www.dailymail.co.uk/news/article-12201985/Unseen-photos-transport-Polish-citizens-Auschwitz-1940-discovered.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201985/Unseen-photos-transport-Polish-citizens-Auschwitz-1940-discovered.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 11:44:13+00:00

The harrowing images, taken on June 14, 1940, show 728 Poles being herded down streets from a prison in the city of Tarnow.

## Perverted GP's 'betrayed' victim blasts his  'devious' nature' after he put his semen in her coffee
 - [https://www.dailymail.co.uk/news/article-12202415/Perverted-GPs-betrayed-victim-blasts-devious-nature-semen-coffee.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202415/Perverted-GPs-betrayed-victim-blasts-devious-nature-semen-coffee.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 11:42:36+00:00

Nicholas Chapman, 55, (pictured) filled up hundreds of 'specimen' samples and was accused of dropping them into his victim's hot drinks on multiple occasions over the course of a year.

## German prosecutors file charges against Arsenal legend after he 'CHAINSAWED neighbour's garage'
 - [https://www.dailymail.co.uk/news/article-12202559/German-prosecutors-file-charges-against-Arsenal-legend-CHAINSAWED-neighbours-garage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202559/German-prosecutors-file-charges-against-Arsenal-legend-CHAINSAWED-neighbours-garage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 11:38:53+00:00

The ex-Arsenal goalkeeper, 53, is being charged for property damage, defamation and two counts of fraud, German newspaper Sueddeutsche Zeitung reports.

## Taking the biscuit: Price of treats soars across every supermarket
 - [https://www.dailymail.co.uk/news/article-12202445/Taking-biscuit-Price-treats-soars-supermarket.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202445/Taking-biscuit-Price-treats-soars-supermarket.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 11:34:05+00:00

Everyday dunkers across Tesco, Sainsbury's, Asda, Morrisons, Waitrose, Aldi and Lidl have risen a shocking 87 per cent since June 2022.

## Locksmith uses 'tricks of the trade' to retrieve driver's keys accidentally locked inside their van
 - [https://www.dailymail.co.uk/news/article-12202311/Locksmith-uses-tricks-trade-retrieve-drivers-keys-accidentally-locked-inside-van.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202311/Locksmith-uses-tricks-trade-retrieve-drivers-keys-accidentally-locked-inside-van.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 11:33:44+00:00

Liam, 42, came to the driver's rescue when he climbed underneath the front seat and made his way into the back of the vehicle to open the rear door.

## Heartbreaking moment mother elephant refuses to give up on its dead calf
 - [https://www.dailymail.co.uk/news/article-12202465/Heartbreaking-moment-mother-elephant-refuses-dead-calf.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202465/Heartbreaking-moment-mother-elephant-refuses-dead-calf.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 11:26:01+00:00

The footage, captured in Assam, India, shows the elephant nudging the dead calf with its feet while trumpeting its trunk as it lies dead in a river.

## Say cheese! Moment gym locker room thief waves to CCTV camera while using stolen credit card
 - [https://www.dailymail.co.uk/news/article-12202503/Say-cheese-Moment-gym-locker-room-thief-waves-CCTV-camera-using-stolen-credit-card.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202503/Say-cheese-Moment-gym-locker-room-thief-waves-CCTV-camera-using-stolen-credit-card.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 11:24:44+00:00

John Fletcher, 50, from Bexhill-on-Sea, raided gym locker rooms, stealing £1,000 in cash before spending a further £2,000 on stolen cards.

## How Richard Curtis put Bernard character in his films in unsubtle dig at Sir Bernard Jenkin
 - [https://www.dailymail.co.uk/news/article-12202149/How-Richard-Curtis-Bernard-character-films-unsubtle-dig-Sir-Bernard-Jenkin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202149/How-Richard-Curtis-Bernard-character-films-unsubtle-dig-Sir-Bernard-Jenkin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 11:19:54+00:00

Curtis dated Anne Jenkin at Oxford University. He later attended her wedding to Sir Bernard. Above: The men named Bernard in Four Weddings and a Funeral, Notting Hill and Bridget Jones's Diary.

## Toowoomba, Queensland: Shocking moment young boy is forced to kiss another teenager's shoes
 - [https://www.dailymail.co.uk/news/article-12202083/Toowoomba-Queensland-Shocking-moment-young-boy-forced-kiss-teenagers-shoes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202083/Toowoomba-Queensland-Shocking-moment-young-boy-forced-kiss-teenagers-shoes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 11:02:20+00:00

In the one-minute video, up to three boys slap, shove and throw punches at their victim before slamming him into a wall in Toowoomba, Queensland. He is then forced to kiss one of the boy's shoes.

## Paranoid Putin guards to disable St Petersburg internet during speech amid assassination fears
 - [https://www.dailymail.co.uk/news/article-12202027/Paranoid-Putin-guards-disable-St-Petersburg-internet-speech-amid-assassination-fears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202027/Paranoid-Putin-guards-disable-St-Petersburg-internet-speech-amid-assassination-fears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 10:51:57+00:00

Putin's guards fear the signals could be used to direct drones in assassination strikes on the warmonger, as has become a common tactic in Ukraine and across the border in Russia.

## Outrage as Wickes boss says trans-critical shoppers 'not welcome in our stores' sparking backlash
 - [https://www.dailymail.co.uk/news/article-12202079/Outrage-Wickes-boss-says-trans-critical-shoppers-not-welcome-stores-sparking-backlash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202079/Outrage-Wickes-boss-says-trans-critical-shoppers-not-welcome-stores-sparking-backlash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 10:51:55+00:00

DIY giant Wickes has been blasted after once again stepping into the debate around trans rights in the UK - labelling those with objections 'bigots' who 'are not welcome in our stores anyway'.

## Chilling CCTV captures student carrying semi-conscious woman back to his flat before raping her
 - [https://www.dailymail.co.uk/news/article-12202115/Chilling-CCTV-captures-student-carrying-semi-conscious-woman-flat-raping-her.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202115/Chilling-CCTV-captures-student-carrying-semi-conscious-woman-flat-raping-her.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 10:50:34+00:00

Preet Vikal, 20, carried the girl back to his room - at points on his shoulders - after he encountered her 'hopelessly intoxicated' outside a music venue in the Welsh capital.

## Train drivers on £60k a year announce new rail strike: Avanti West Coast passengers will be hit
 - [https://www.dailymail.co.uk/news/article-12202435/Train-drivers-60k-year-announce-new-rail-strike-Avanti-West-Coast-passengers-hit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202435/Train-drivers-60k-year-announce-new-rail-strike-Avanti-West-Coast-passengers-hit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 10:48:39+00:00

The announcement comes just days after union barons at Aslef said train drivers have voted overwhelmingly to continue taking strike action for the next six months.

## What NOT to take to Glastonbury 2023: Full list of banned items
 - [https://www.dailymail.co.uk/news/article-12202107/What-NOT-Glastonbury-2023-list-banned-items.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202107/What-NOT-Glastonbury-2023-list-banned-items.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 10:45:59+00:00

The UK festival season is all set, with the biggest music event of the summer - Glastonbury festival - returning for 2023. But what are the banned items at Glastonbury?

## Passenger who held up flight by being late falls onto the runway in bizarre bid to board flight
 - [https://www.dailymail.co.uk/news/article-12202365/Passenger-held-flight-late-falls-runway-bizarre-bid-board-flight.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202365/Passenger-held-flight-late-falls-runway-bizarre-bid-board-flight.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 10:44:06+00:00

The man was filmed pleading with airport workers after getting to the end of the boarding gangway and discovering the plane was getting ready for take-off with a drop to the ground below.

## Tourist horrified by his 'apple and cheese salad' at Big Narstie's Tenerife restaurant
 - [https://www.dailymail.co.uk/news/article-12202285/Tourist-horrified-apple-cheese-salad-Big-Narsties-Tenerife-restaurant.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202285/Tourist-horrified-apple-cheese-salad-Big-Narsties-Tenerife-restaurant.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 10:40:02+00:00

A holidaymaker has slammed comedian Big Narstie's Jamaican restaurant in Tenerife, Spain, for serving him a '2/10' plate of sliced apples and grated cheese.

## Taxi driver who lost £10,000 earnings after breaking ankle says he is ready to take council to court
 - [https://www.dailymail.co.uk/news/article-12202203/Taxi-driver-lost-10-000-earnings-breaking-ankle-says-council-court.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202203/Taxi-driver-lost-10-000-earnings-breaking-ankle-says-council-court.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 10:37:44+00:00

James Tiffoney (pictured), 66, was left in agony after falling into a 'crater' outside Tesco on Busby Road, in Clarkston, in December last year.

## Who is Bear Grylls' wife Shara Cannings Knight and how many children do they have together?
 - [https://www.dailymail.co.uk/news/article-12202033/Who-Bear-Grylls-wife-Shara-Cannings-Knight-children-together.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202033/Who-Bear-Grylls-wife-Shara-Cannings-Knight-children-together.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 10:36:51+00:00

Bear Grylls has been married to his wife Shara Cannings Knight since 2000. Find out what there is to know about Shara here, including how many children she and Mr Grylls have.

## EXCLUSIVE Labour candidate to take Boris Johnson's Commons seat backed £10k trans flag road crossing
 - [https://www.dailymail.co.uk/news/article-12198285/EXCLUSIVE-Labour-candidate-Boris-Johnsons-Commons-seat-backed-10k-trans-flag-road-crossing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12198285/EXCLUSIVE-Labour-candidate-Boris-Johnsons-Commons-seat-backed-10k-trans-flag-road-crossing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 10:35:17+00:00

Danny Beales posed for pictures by the four-way blue, pink and white crossing at the junction of Tavistock Place and Marchmont Street in central London in November 2021.

## Harry and Meghan's brand could come crashing down after end of Spotify deal
 - [https://www.dailymail.co.uk/news/article-12201801/Harry-Meghans-brand-come-crashing-end-Spotify-deal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201801/Harry-Meghans-brand-come-crashing-end-Spotify-deal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 10:33:42+00:00

Meghan Markle's podcast Archetypes will not be renewed for a second season in what has been described as a mutual decision between the Sussexes and the streaming behemoth.

## Dancer who appeared in Labyrinth with David Bowie will 'fight like a tiger' in neighbour row
 - [https://www.dailymail.co.uk/news/article-12202259/Dancer-appeared-Labyrinth-David-Bowie-fight-like-tiger-neighbour-row.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202259/Dancer-appeared-Labyrinth-David-Bowie-fight-like-tiger-neighbour-row.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 10:32:39+00:00

Susan Lee, 71, is at war with her neighbours Vanessa and Andrew McVickers over the brick wall that runs between their gardens in Peckham, south London.

## Myer launches 30 per cent off sale as iconic department store shuts its doors for good
 - [https://www.dailymail.co.uk/news/article-12201997/Myer-launches-30-cent-sale-iconic-department-store-shuts-doors-good.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201997/Myer-launches-30-cent-sale-iconic-department-store-shuts-doors-good.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 10:31:49+00:00

Myer is offering 30 per cent off already discounted sale prices this weekend as a thank you to locals of a store that is shutting down after being there for more than three decades.

## Robert F. Kennedy Jr. claims he is 'aware' he could be assassinated by the CIA
 - [https://www.dailymail.co.uk/news/article-12201973/Robert-F-Kennedy-Jr-claims-aware-assassinated-CIA.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201973/Robert-F-Kennedy-Jr-claims-aware-assassinated-CIA.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 10:19:23+00:00

Anti-vaccine conspiracy theorist and Democratic presidential candidate Robert F. Kennedy Jr. has claimed he is 'aware' that he could be assassinated by the CIA but doesn't 'live in fear' of the possibility.

## Amazing moment jackal cub is dropped by eagle after its mother gives the predator a scare
 - [https://www.dailymail.co.uk/news/article-12202229/Amazing-moment-jackal-cub-dropped-eagle-mother-gives-predator-scare.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202229/Amazing-moment-jackal-cub-dropped-eagle-mother-gives-predator-scare.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 09:58:30+00:00

Photographer Ateeb Hussain, 39, captured the dramatic moment in Masai Mara, Kenya, and said he first spotted the jackal mother with the cub in her mouth moving around frantically.

## Broadbeach, Queensland: Hero tradies perform citizen's arrest on alleged car thief
 - [https://www.dailymail.co.uk/news/article-12201829/Broadbeach-Queensland-Hero-tradies-perform-citizens-arrest-alleged-car-thief.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201829/Broadbeach-Queensland-Hero-tradies-perform-citizens-arrest-alleged-car-thief.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 09:44:48+00:00

Up to three tradies in hi-vis restrained the man, 25, after he crashed into a power pole on Surf Parade in Broadbeach, Queensland in an allegedly stolen car just before 11am on Friday.

## South East Water introduces hosepipe ban as homes across Kent and Sussex battle water shortages
 - [https://www.dailymail.co.uk/news/article-12202219/South-East-Water-introduces-hosepipe-ban-homes-Kent-Sussex-battle-water-shortages.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202219/South-East-Water-introduces-hosepipe-ban-homes-Kent-Sussex-battle-water-shortages.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 09:36:03+00:00

Schools in the region have been forced to close during the warm weather and bottled water stations have been set up as the utility firm said demand for drinking water has reached 'record levels'.

## Ashes cricketers will hold minute's silence for Nottingham victims
 - [https://www.dailymail.co.uk/news/article-12202165/Ashes-cricketers-hold-minutes-silence-Nottingham-victims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202165/Ashes-cricketers-hold-minutes-silence-Nottingham-victims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 09:35:57+00:00

England and Australia will wear black armbands in Birmingham today to pay their respects to Grace O'Malley-Kumar, Barnaby Webber and Ian Coates.

## Ex-chief of the police watchdog is charged sex offences including rape of young girl
 - [https://www.dailymail.co.uk/news/article-12202111/Ex-chief-police-watchdog-charged-sex-offences-including-rape-young-girl.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202111/Ex-chief-police-watchdog-charged-sex-offences-including-rape-young-girl.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 09:29:48+00:00

Independent Office for Police Conduct (IOPC) director general Michael Lockwood stepped down from the £190k-a-year role in December after the allegations emerged.

## Russia offers troops £930 cash bonuses for any US or UK tanks they destroy
 - [https://www.dailymail.co.uk/news/article-12201941/Russia-offers-troops-930-cash-bonuses-UK-tanks-destroy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201941/Russia-offers-troops-930-cash-bonuses-UK-tanks-destroy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 09:25:00+00:00

Russian troops will receive a £930 payment for destroying German-made Leopard tanks and any other armoured vehicles supplied by 'NATO countries'.

## US tourist thrown into ravine at castle miraculously only suffered light injuries, say German police
 - [https://www.dailymail.co.uk/news/article-12201999/US-tourist-thrown-ravine-castle-miraculously-suffered-light-injuries-say-German-police.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201999/US-tourist-thrown-ravine-castle-miraculously-suffered-light-injuries-say-German-police.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 09:19:56+00:00

The horrific attack happened on Wednesday at Neuschwanstein castle, said to have been the inspiration for Disney's 'Cinderella' castle.

## Trucker, 52, stormed out of her houseboat and throttled neighbour's cockerel in a fit of rage
 - [https://www.dailymail.co.uk/news/article-12201995/Trucker-52-stormed-houseboat-throttled-neighbours-cockerel-fit-rage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201995/Trucker-52-stormed-houseboat-throttled-neighbours-cockerel-fit-rage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 09:16:00+00:00

Caroline Smith (pictured), 52, became so frustrated about the bird's crowing she stormed out of the houseboat and seized the cockerel around the neck before throwing it to the floor.

## SECOND shark spotted on Spanish coastline a day after a seven-footer sparked panic
 - [https://www.dailymail.co.uk/news/article-12202071/SECOND-shark-spotted-Spanish-coastline-day-seven-footer-sparked-panic.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202071/SECOND-shark-spotted-Spanish-coastline-day-seven-footer-sparked-panic.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 09:11:04+00:00

The shark, described as a tintoera, was seen swimming in the water inside the Ciutadella Port, Menorca, this morning.

## Nottingham 'killer' 'used to sit out the back of house with his top off, smoking and drinking'
 - [https://www.dailymail.co.uk/news/article-12202119/Nottingham-killer-used-sit-house-smoking-drinking.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202119/Nottingham-killer-used-sit-house-smoking-drinking.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 08:59:34+00:00

Valdo Calocane, who is understood to be from Guinea-Bissau, West Africa, graduated from the University of Nottingham with a degree in mechanical engineering.

## AFP raids seize luxury yacht, Cartier and Rolex jewellery, cash and cocaine in organised crime bust
 - [https://www.dailymail.co.uk/news/article-12201683/AFP-raids-seize-luxury-yacht-Cartier-Rolex-jewellery-cash-cocaine-organised-crime-bust.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201683/AFP-raids-seize-luxury-yacht-Cartier-Rolex-jewellery-cash-cocaine-organised-crime-bust.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 08:50:52+00:00

Victoria Police and the AFP has busted one of Victoria's largest organised crime syndicates, executing more than 60 warrants, seizing almost $50million worth of assets and making 52 arrests.

## Emotional final pictures show Glenda Jackson and Sir Michael Caine filming their last movie together
 - [https://www.dailymail.co.uk/news/article-12201949/Emotional-final-pictures-Glenda-Jackson-Sir-Michael-Caine-filming-movie-together.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201949/Emotional-final-pictures-Glenda-Jackson-Sir-Michael-Caine-filming-movie-together.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 08:26:45+00:00

EXCLUSIVE: The Oscar-winning British actors last acted together 47 years ago. Ms Jackson died at her home in Blackheath, south-east London , after a 'brief illness', her agent said yesterday.

## Just Stop Oil eco-clown cause more misery in London with fresh slow-march
 - [https://www.dailymail.co.uk/news/article-12201971/Just-Stop-Oil-eco-clown-cause-misery-London-fresh-slow-march.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201971/Just-Stop-Oil-eco-clown-cause-misery-London-fresh-slow-march.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 08:26:38+00:00

In scenes today branded 'boring' by frustrated Britons, a group of zealots took to Kensington to stage their latest shambling slow-march, once again frustrating rush-hour commuters.

## Brittany Higgins and David Sharaz launch scathing attack on Crikey
 - [https://www.dailymail.co.uk/news/article-12201403/Brittany-Higgins-David-Sharaz-launch-scathing-attack-Crikey.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201403/Brittany-Higgins-David-Sharaz-launch-scathing-attack-Crikey.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 08:17:07+00:00

Brittany Higgins was granted a $3million compensation payment after lodging a personal injury claim against the Morrison government following her rape allegations.

## Nicola Sturgeon's personal poll ratings turn negative for first time
 - [https://www.dailymail.co.uk/news/article-12201951/Nicola-Sturgeons-personal-poll-ratings-turn-negative-time.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201951/Nicola-Sturgeons-personal-poll-ratings-turn-negative-time.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 07:59:31+00:00

Nicola Sturgeon was arrested and questioned for seven hours last weekend by police probing the SNP's finances, before being released without charge pending further inquiries.

## Britain set for a scorching weekend with 82F temperatures...but South could see a washout on Sunday
 - [https://www.dailymail.co.uk/news/article-12201753/Britain-set-scorching-weekend-82F-temperatures-South-washout-Sunday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201753/Britain-set-scorching-weekend-82F-temperatures-South-washout-Sunday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 07:48:26+00:00

The Met Office said the mercury would remain above average in the UK for the time of year over the coming days but conditions will become more 'unsettled' from later today.

## Families and tourists are warned over 'life threatening' danger at popular beach
 - [https://www.dailymail.co.uk/news/article-12201755/Families-tourists-warned-life-threatening-danger-popular-beach.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201755/Families-tourists-warned-life-threatening-danger-popular-beach.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 07:42:11+00:00

Lifeguards in Crantock, near Newquay, say there is an 'increased danger' of the area's enormous sand dunes collapsing and trapping people.

## CCTV footage captures the shocking moment a brazen thief swipes bag in busy restaurant
 - [https://www.dailymail.co.uk/news/article-12201849/CCTV-footage-captures-shocking-moment-brazen-thief-swipes-bag-busy-restaurant.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201849/CCTV-footage-captures-shocking-moment-brazen-thief-swipes-bag-busy-restaurant.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 07:41:28+00:00

The theft - which happens at the plush Bloomberg arcade in central London - takes just 20 seconds and neither of the two men eating realise the black rucksack has gone.

## The Pope is discharged from hospital nine days after hernia surgery
 - [https://www.dailymail.co.uk/news/article-12201887/The-Pope-discharged-hospital-nine-days-hernia-surgery.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201887/The-Pope-discharged-hospital-nine-days-hernia-surgery.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 07:39:24+00:00

Francis, 86, left Rome's Gemelli hospital in a wheelchair, waving to reporters and well-wishers at the main entrance as he was taken to a waiting car.

## Scores of Tory MPs are set to skip crunch vote on Boris Johnson
 - [https://www.dailymail.co.uk/news/article-12201813/Scores-Tory-MPs-set-skip-crunch-vote-Boris-Johnson.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201813/Scores-Tory-MPs-set-skip-crunch-vote-Boris-Johnson.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 07:38:46+00:00

Westminster is bracing for a showdown on the Privileges Committee's brutal findings into the ex-PM on Monday.

## Brittany Higgins Lidia Thorpe RECAP and Amanda Stoker's David Van allegations
 - [https://www.dailymail.co.uk/news/article-12200975/Brittany-Higgins-Lidia-Thorpe-RECAP-Sex-assault-claims-against-David-Van-Amanda-Stoker-Peter-Dutton.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12200975/Brittany-Higgins-Lidia-Thorpe-RECAP-Sex-assault-claims-against-David-Van-Amanda-Stoker-Peter-Dutton.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 07:11:28+00:00

Peter Dutton revealed he has heard a third allegation about Victorian senator David Van, after he was accused of sexual assault by Lidia Thorpe and Amanda Stoker claimed he groped her.

## Australian mum roasted online for wanting to use Kooshy Kids cushion on a Jetstar flight despite ban
 - [https://www.dailymail.co.uk/news/article-12201523/Australian-mum-roasted-online-wanting-use-Kooshy-Kids-cushion-Jetstar-flight-despite-ban.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201523/Australian-mum-roasted-online-wanting-use-Kooshy-Kids-cushion-Jetstar-flight-despite-ban.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 07:01:19+00:00

Mum Jodie Candice took to Bali Bogans social media on Friday saying she was 'tempted' to sneak a Kooshy Kids inflatable cushion onto a Jetstar flight despite its 'ridiculous' ban.

## £2million farmhouse in the Yorkshire Dales goes up for grabs in Omaze prize draw
 - [https://www.dailymail.co.uk/news/article-12201833/2million-farmhouse-Yorkshire-Dales-goes-grabs-Omaze-prize-draw.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201833/2million-farmhouse-Yorkshire-Dales-goes-grabs-Omaze-prize-draw.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 07:01:02+00:00

One lucky person is guaranteed to win this picturesque sprawling property near Harrogate - along with £100,000 in cash.

## Mother distraught as her family of four is killed after teenage daughter fell asleep at the wheel
 - [https://www.dailymail.co.uk/news/article-12201597/Mother-distraught-family-four-killed-teenage-daughter-fell-asleep-wheel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201597/Mother-distraught-family-four-killed-teenage-daughter-fell-asleep-wheel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 07:00:58+00:00

A father and his three children were found dead on Saturday after their car, being driven by his teenage daughter, crashed off a cliff and fell into a river in Idaho. She fell asleep at the wheel.

## 'The Mediterranean is a mass graveyard': Greek boat tragedy feared to be one of the deadliest
 - [https://www.dailymail.co.uk/news/article-12201781/The-Mediterranean-mass-graveyard-Greek-boat-tragedy-feared-one-deadliest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201781/The-Mediterranean-mass-graveyard-Greek-boat-tragedy-feared-one-deadliest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 06:59:45+00:00

So far, 78 people have been confirmed dead, but with just 104 survivors plucked out the Mediterranean, that that figure is expected to rise significantly.

## Lidia Thorpe: How David Van's comments in the Senate led her to detonate a political bomb
 - [https://www.dailymail.co.uk/news/article-12201175/Lidia-Thorpe-David-Vans-comments-Senate-led-detonate-political-bomb.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201175/Lidia-Thorpe-David-Vans-comments-Senate-led-detonate-political-bomb.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 06:52:27+00:00

Lidia Thorpe did not go to work on Wednesday intending to accuse Victorian Liberal senator David Van of sexually assaulting her.

## Judge REJECTS doomsday mom Lori Vallow's request for a retrial
 - [https://www.dailymail.co.uk/news/article-12201317/Judge-REJECTS-doomsday-mom-Lori-Vallows-request-retrial.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201317/Judge-REJECTS-doomsday-mom-Lori-Vallows-request-retrial.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 06:51:09+00:00

A judge has rejected Lori Vallow's request for a retrial, months after she was found guilty of murdering her two children when she became obsessed by the 'apocalypse'.

## Disney finance chief Christine McCarthy steps down for family medical leave
 - [https://www.dailymail.co.uk/news/article-12201077/Disney-finance-chief-Christine-McCarthy-steps-firm-lost-659-million-Q2.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201077/Disney-finance-chief-Christine-McCarthy-steps-firm-lost-659-million-Q2.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 06:48:18+00:00

McCarthy, 67, has been with the company for more than two decades. She became CFO in 2015, and is viewed as a key ally of Bob Iger, after helping to engineer his return as Disney CEO last year.

## You could earn up to $1,500 a day braiding horses' hair - plus 16 other jobs that make six figures
 - [https://www.dailymail.co.uk/news/article-12201611/You-earn-1-500-day-braiding-horses-hair-plus-16-jobs-make-six-figures.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201611/You-earn-1-500-day-braiding-horses-hair-plus-16-jobs-make-six-figures.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 06:44:33+00:00

If you are in need of a career change, there are some incredibly interesting and odd jobs out there that pay big money, including horse braiding for up to $1500 a day.

## AGL, Origin and Red Energy customers face major power bill increase
 - [https://www.dailymail.co.uk/news/article-12201425/AGL-Origin-Red-Energy-customers-face-major-power-bill-increase.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201425/AGL-Origin-Red-Energy-customers-face-major-power-bill-increase.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 06:28:48+00:00

Millions of Australians will be hit with an increase to their electricity bill of hundreds of dollars a year as the country's two largest providers raise prices.

## Black boy, 10, gives impassioned speech about racism at Oregon city council meeting
 - [https://www.dailymail.co.uk/news/article-12201555/Black-boy-10-gives-impassioned-speech-racism-Oregon-city-council-meeting.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201555/Black-boy-10-gives-impassioned-speech-racism-Oregon-city-council-meeting.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 06:03:08+00:00

Gavin Alston, 10, bravely spoke up in the room full of adults in Redmond, Oregon, and told council members how unfair it was that kids called him a 'monkey' and the N-word in his fourth grade class.

## Simone Holtznagel: Police arrest man outside court moments after he was cleared of stalking model
 - [https://www.dailymail.co.uk/news/article-12201321/Simone-Holtznagel-Police-arrest-man-outside-court-moments-cleared-stalking-model.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201321/Simone-Holtznagel-Police-arrest-man-outside-court-moments-cleared-stalking-model.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 05:41:57+00:00

A man cleared of stalking one of Australia's most high-profile models was charged of breaching a personal protection order against her just minutes after walking from a court hearing.

## Ex Footy Show star Allan Robinson celebrates losing job as Newcastle councillor over comments
 - [https://www.dailymail.co.uk/news/article-12201543/Ex-Footy-star-Allan-Robinson-celebrates-losing-job-Newcastle-councillor-comments.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201543/Ex-Footy-star-Allan-Robinson-celebrates-losing-job-Newcastle-councillor-comments.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 05:40:55+00:00

Ex-Footy Show star and jockey Allan Robinson has welcomed being disqualified from office by the NSW Civil and Administrative Tribunal (NCAT) over homophobic remarks.

## Americans saved less for retirement last year, Vanguard says
 - [https://www.dailymail.co.uk/news/article-12201385/Americans-saved-retirement-year-Vanguard-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201385/Americans-saved-retirement-year-Vanguard-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 05:39:27+00:00

In 2022, the average 401(k) account balance for Vanguard participants was $112,572, down 20 percent from the $141,542 average recorded in 2021, according to a report from the company on Thursday.

## 'There was nothing left': Witnesses describe 'horrific' crash that killed 15 on Canada highway
 - [https://www.dailymail.co.uk/news/article-12201435/There-left-Witnesses-horrific-crash-killed-15-Canada-highway.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201435/There-left-Witnesses-horrific-crash-killed-15-Canada-highway.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 05:35:25+00:00

Witnesses to one of the worst vehicle accidents in Canadian history have described how the 'horrific' crash caused carnage on a Manitoba highway, with one saying she 'almost had a panic attack'.

## How did Mr Lambo Adrian Portelli make his money?
 - [https://www.dailymail.co.uk/news/article-12196683/How-did-Mr-Lambo-Adrian-Portelli-make-money.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12196683/How-did-Mr-Lambo-Adrian-Portelli-make-money.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 05:34:22+00:00

Controversial Melbourne investor Adrian Portelli, also known as 'Mr Lambo' has brought another multi-million-dollar property, as his business continues to boom. This is how he made his money.

## Brittany Higgins warned Lisa Wilkinson to stop wanting a second interview on The Project
 - [https://www.dailymail.co.uk/news/article-12201323/Brittany-Higgins-warned-Lisa-Wilkinson-stop-wanting-second-interview-Project.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201323/Brittany-Higgins-warned-Lisa-Wilkinson-stop-wanting-second-interview-Project.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 04:29:41+00:00

The letter was widely quoted on TV and newspapers in the wake of Bruce Lehrmann finally breaking his public silence in an interview on Seven's Spotlight on June 4.

## The 'painful' Jeopardy! episode producers want fans to pretend never happened
 - [https://www.dailymail.co.uk/news/article-12201253/The-painful-Jeopardy-episode-producers-want-fans-pretend-never-happened.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201253/The-painful-Jeopardy-episode-producers-want-fans-pretend-never-happened.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 04:21:10+00:00

Producers on the long running game show Jeopardy! say they hope an episode of the show will be forgotten in the future after players failed to answer 23 questions.

## Respected Sydney netball coach Peter Albert Crawford walks free despite sexual abuse of four girls
 - [https://www.dailymail.co.uk/news/article-12201479/Respected-Sydney-netball-coach-Peter-Albert-Crawford-walks-free-despite-sexual-abuse-four-girls.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201479/Respected-Sydney-netball-coach-Peter-Albert-Crawford-walks-free-despite-sexual-abuse-four-girls.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 04:16:03+00:00

Peter Albert Crawford, a highly respected netball coach, church member and former president of Sydney's St George District Netball Association, was spared jail despite the abuse.

## At least 3 people are killed and 75 others injured as 'horrific' tornado hits Perryton, Texas
 - [https://www.dailymail.co.uk/news/article-12201391/At-3-people-killed-75-injured-horrific-tornado-hits-Perryton-Texas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201391/At-3-people-killed-75-injured-horrific-tornado-hits-Perryton-Texas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 04:08:28+00:00

At least three people were killed and more than 75 others were injured on Thursday after a tornado struck the Texas city of Perryton.

## Veteran Fox News producer responsible for chyron calling Biden a 'wannabe dictator' resigns
 - [https://www.dailymail.co.uk/news/article-12201309/Veteran-Fox-News-producer-responsible-chyron-calling-Biden-wannabe-dictator-resigns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201309/Veteran-Fox-News-producer-responsible-chyron-calling-Biden-wannabe-dictator-resigns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 03:52:42+00:00

Tucker Carlson on Thursday night said the producer behind Fox News's chyron calling Biden a 'wannabe dictator' had resigned. The Daily Beast named him as Alexander McCaskill.

## Compulsory super guarantee changing
 - [https://www.dailymail.co.uk/news/article-12200907/Compulsory-super-guarantee-changing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12200907/Compulsory-super-guarantee-changing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 03:48:56+00:00

The super guarantee rate will jump to 11 per cent on July 1 this year, meaning employees will have more money tucked away for their retirement.

## Lakes Entrance: Dad Bradley Lyons is killed over rumours he was a paedophile
 - [https://www.dailymail.co.uk/news/article-12201249/Lakes-Entrance-Dad-Bradley-Lyons-killed-rumours-paedophile.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201249/Lakes-Entrance-Dad-Bradley-Lyons-killed-rumours-paedophile.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 03:34:41+00:00

Jury finds Albert Thorn guilty over vigilante murder of Bradley Lyons

## Hunter Valley bus crash: Incredible act of kindness after tragedy
 - [https://www.dailymail.co.uk/news/article-12201063/Hunter-Valley-bus-crash-Incredible-act-kindness-tragedy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201063/Hunter-Valley-bus-crash-Incredible-act-kindness-tragedy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 03:30:11+00:00

Australians are rallying around the heartbroken families and friends of those killed and injured in one of Australia's worst bus crashes.

## Covid-19 rapid testing company Ellume from Brisbane Australia collapses owing $140million
 - [https://www.dailymail.co.uk/news/article-12201295/Covid-19-rapid-testing-company-Ellume-Brisbane-Australia-collapses-owing-140million.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201295/Covid-19-rapid-testing-company-Ellume-Brisbane-Australia-collapses-owing-140million.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 03:24:15+00:00

Brisbane-based Ellume went from announcing a $300million deal for self-testing Covid-19 kits with the US government to winding up operations in the space of three years.

## Jetstar launch huge sale on domestic flights
 - [https://www.dailymail.co.uk/news/article-12201181/Jetstar-launch-huge-sale-domestic-flights.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201181/Jetstar-launch-huge-sale-domestic-flights.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 03:20:39+00:00

Jetstar has launched its Mates' Rates sale with airfares from $35 up for grabs.

## Penn State professor begged cops to shoot him after arrest for 'performing sex acts on his pet dog'
 - [https://www.dailymail.co.uk/news/article-12201263/Penn-State-professor-begged-cops-shoot-arrest-performing-sex-acts-pet-dog.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201263/Penn-State-professor-begged-cops-shoot-arrest-performing-sex-acts-pet-dog.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 02:50:38+00:00

Themis Matsoukas, 64, (inset) allegedly became 'panicked' when police confronted him about the lewd acts, before he asked them: 'What do I have to do to get you to shoot me? I need to die'.

## California couple 'thought they had food poisoning' days before dying in their sleep
 - [https://www.dailymail.co.uk/news/article-12201267/California-couple-thought-food-poisoning-days-dying-sleep.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201267/California-couple-thought-food-poisoning-days-dying-sleep.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 02:49:45+00:00

Abby Lutz, 28, and John Heathco, 40, who died in their luxury Mexico hotel room from carbon monoxide poisoning thought they had food poisoning just days before their deaths.

## JPMorgan claims former First Lady of U.S. Virgin Islands helped Jeffrey Epstein traffic women
 - [https://www.dailymail.co.uk/news/article-12200675/JPMorgan-claims-former-Lady-U-S-Virgin-Islands-helped-Jeffrey-Epstein-traffic-women.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12200675/JPMorgan-claims-former-Lady-U-S-Virgin-Islands-helped-Jeffrey-Epstein-traffic-women.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 02:31:08+00:00

Cecile de Jongh worked for Jeffrey Epstein from 2000, managing his USVI office, and was the First Lady of the territory from 2007-15. On Wednesday, JPMorgan accused her of aiding his crimes.

## Real estate mogul is indicted on first-degree murder for allegedly shooting football coach's son
 - [https://www.dailymail.co.uk/news/article-12200805/Real-estate-mogul-indicted-degree-murder-allegedly-shooting-football-coachs-son.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12200805/Real-estate-mogul-indicted-degree-murder-allegedly-shooting-football-coachs-son.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 01:54:43+00:00

Lloyd Preston Brewer III, 57, was charged with first-degree murder after Garrett Hughes, 21, was shot dead in Key West. Brewer confronted Hughes after he urinated on the side of his building.

## Tucker Carlson ridicules his former Fox bosses for apologizing for Biden 'wannabe dictator' chyron
 - [https://www.dailymail.co.uk/news/article-12201107/Tucker-Carlson-ridicules-former-Fox-bosses-apologizing-Biden-wannabe-dictator-chyron.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201107/Tucker-Carlson-ridicules-former-Fox-bosses-apologizing-Biden-wannabe-dictator-chyron.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 01:49:28+00:00

Tucker Carlson on Thursday night mocked Fox News for apologizing after calling Joe Biden a 'wannabe dictator' - insisting that the president did have dictatorial tendencies.

## Biden makes cringey joke about knowing Eva Longoria a 'long time'
 - [https://www.dailymail.co.uk/news/article-12201027/Biden-makes-cringey-joke-knowing-Eva-Longoria-long-time.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201027/Biden-makes-cringey-joke-knowing-Eva-Longoria-long-time.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 01:49:18+00:00

President Joe Biden made a cringeworthy joke as he told an audience at the White House Thursday night that he'd known actress and director Eva Longoria for 'a long time.'

## Space Force general slams state-level anti-LGBTQ  bills in blistering speech
 - [https://www.dailymail.co.uk/news/article-12200991/Space-Force-general-slams-state-level-anti-LGBTQ-bills-blistering-speech.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12200991/Space-Force-general-slams-state-level-anti-LGBTQ-bills-blistering-speech.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 01:46:44+00:00

Lt. Gen. DeAnna Burt made the remarks in a fiery speech at the 12th Annual DoD LGBTQ+ Pride Event in DC, saying that the laws sometimes forced her to choose 'less qualified' candidates

## How to find rare Australian 20c coin with wavy baseline that is worth up to $4000
 - [https://www.dailymail.co.uk/news/article-12201047/How-rare-Australian-20c-coin-wavy-baseline-worth-4000.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201047/How-rare-Australian-20c-coin-wavy-baseline-worth-4000.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 01:36:40+00:00

A Perth-based TikToker and numismatist has revealed the tiny detail on a rare 20c coin that can fetch eye-watering prices of up to $4000.

## Amanda Stoker's Sky News interview with David Van before groping claims
 - [https://www.dailymail.co.uk/news/article-12201019/Amanda-Stokers-Sky-News-interview-David-Van-groping-claims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201019/Amanda-Stokers-Sky-News-interview-David-Van-groping-claims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 01:32:15+00:00

Amanda Stoker thanked the Victorian Liberal senator for 'sparing her a moment' during the busy estimates hearing period on May 24 when he appeared on her Sky News TV show.

## Young FIFO worker exposes the brutal reality of mining work: 'Feels like jail'
 - [https://www.dailymail.co.uk/news/article-12196325/Young-FIFO-worker-exposes-brutal-reality-mining-work-Feels-like-jail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12196325/Young-FIFO-worker-exposes-brutal-reality-mining-work-Feels-like-jail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 01:19:34+00:00

A young fly-in-fly-out worker has exposed the brutal reality of working for the mining companies as he warns others he's been forced to make some major sacrifices despite the high salary.

## Furious Michigan mom makes horror find in McDonald's Happy Meal
 - [https://www.dailymail.co.uk/news/article-12200949/Furious-Michigan-mom-makes-horror-McDonalds-Happy-Meal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12200949/Furious-Michigan-mom-makes-horror-McDonalds-Happy-Meal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 01:10:16+00:00

A Michigan mom is not 'loving it' after she found a box cutter in her child's Happy Meal from McDonald's as another parent claims the same thing happened to her.

## Robbie Williams accused of 'environmental vandalism' over plans for his mansion amid Jimmy Page row
 - [https://www.dailymail.co.uk/news/article-12201067/Robbie-Williams-accused-environmental-vandalism-plans-mansion-amid-Jimmy-Page-row.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201067/Robbie-Williams-accused-environmental-vandalism-plans-mansion-amid-Jimmy-Page-row.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 01:07:04+00:00

The Take That frontman, 49, and the guitarist, 79, have been embroiled in a bitter feud ever since Williams moved into his Holland Park home in 2013.

## Russian soldiers 'killed in Ukrainian Himars strike' after being ordered to wait hours for pep talk
 - [https://www.dailymail.co.uk/news/article-12201035/Russian-soldiers-killed-Ukrainian-Himars-strike-ordered-wait-hours-pep-talk.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201035/Russian-soldiers-killed-Ukrainian-Himars-strike-ordered-wait-hours-pep-talk.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 00:40:52+00:00

Reports suggest more than 100 Russian soldiers (pictured) may have been killed in a strike after they were instructed to wait for a general to arrive to give them a motivational speech in Luhansk.

## Six African countries warn against banning British game hunters from bringing home souvenir heads
 - [https://www.dailymail.co.uk/news/article-12201033/Six-African-countries-warn-against-banning-British-game-hunters-bringing-home-souvenir-heads.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201033/Six-African-countries-warn-against-banning-British-game-hunters-bringing-home-souvenir-heads.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 00:34:32+00:00

The House of Lords will today debate the Hunting Trophies (Import Prohibition) Bill, which aims to strengthen the conservation of endangered species.

## Warmer weather sees migration of African 'rainbow birds' to UK
 - [https://www.dailymail.co.uk/news/article-12201069/Warmer-weather-sees-migration-African-rainbow-birds-UK.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201069/Warmer-weather-sees-migration-African-rainbow-birds-UK.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 00:28:46+00:00

Eight bee-eaters, distinctive blue, yellow and orange birds, have returned to a Norfolk quarry for the second year running, the first time they have done this.

## ALISON BOSHOFF: The Stones CAN always get what they want from the tax man!
 - [https://www.dailymail.co.uk/tvshowbiz/article-12200979/ALISON-BOSHOFF-Stones-want-tax-man.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-12200979/ALISON-BOSHOFF-Stones-want-tax-man.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 00:13:28+00:00

ALISON BOSHOFF: Everybody knows that Mick Jagger - soon to celebrate his 80th birthday - is canny with money.

## Andrew Tate's accuser tells her story: 'When I came round... he was still having sex with me'
 - [https://www.dailymail.co.uk/news/article-12199875/Andrew-Tates-accuser-tells-story-came-round-having-sex-me.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12199875/Andrew-Tates-accuser-tells-story-came-round-having-sex-me.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 00:08:59+00:00

Evie has become the fourth British woman to make serious accusations of sexual violence against Andrew Tate, the controversial TikTok and ­Instagram influencer and self-styled guru.

## Meghan Markle's Spotify podcast 'set to be axed' as streaming platform 'revamps output'
 - [https://www.dailymail.co.uk/news/article-12200875/Meghan-Markles-Spotify-podcast-set-axed-streaming-platform-revamps-output.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12200875/Meghan-Markles-Spotify-podcast-set-axed-streaming-platform-revamps-output.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 00:04:06+00:00

Meghan Markle's Spotify podcast Archetypes will not be renewed for a second season, as the audio company begins to make changes and revamp its output, it has been reported.

## It's a BOY! Al Pacino, 83, and Noor Alfallah, 29, have welcomed a son and reveal name
 - [https://www.dailymail.co.uk/tvshowbiz/article-12200473/Its-BOY-Al-Pacino-83-Noor-Alfallah-29-welcomed-son-reveal-name.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-12200473/Its-BOY-Al-Pacino-83-Noor-Alfallah-29-welcomed-son-reveal-name.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-16 00:00:18+00:00

Al Pacino, 83, and Noor Alfallah, 29, have welcomed a baby boy together.

