# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## RGG Summit Summer 2023 Full Presentation
 - [https://www.youtube.com/watch?v=kumjks94tWo](https://www.youtube.com/watch?v=kumjks94tWo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2023-06-16 04:36:22+00:00

RGG Summit is a panel featuring character introductions and more details on Like a Dragon Gaiden: The Man Who Erased His Name and Like a Dragon: Infinite Wealth.

#gaming #rggstudio #likeadragon

## RGG Summit Summer 2023
 - [https://www.youtube.com/watch?v=V5-sCjDp5_w](https://www.youtube.com/watch?v=V5-sCjDp5_w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2023-06-16 03:14:08+00:00

RGG Summit Summer 2023. A panel featuring character introductions and more details on Like a Dragon Gaiden: The Man Who Erased His Name and Like a Dragon: Infinite Wealth at the RGG Summit!

