# Source:Mateusz Chrobok, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw, language:pl-PL

## 🎓 Wyciek danych z Uniwersytetu
 - [https://www.youtube.com/watch?v=aHeK_O4gErE](https://www.youtube.com/watch?v=aHeK_O4gErE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw
 - date published: 2023-06-16 04:00:00+00:00

Studiowaliście w ramach Erasmusa na Uniwersytecie w Manchesterze? No, przynajmniej przed Brexitem? To mam dla Was niestety złą wiadomość.
 
Źródła:
https://tinyurl.com/mthamsvp
https://tinyurl.com/bde2hkr6
 
#Manchester #Erasmus #studia #ransomware

