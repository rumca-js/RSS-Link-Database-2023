# Source:Washington Examiner - Tech, URL:https://feeds.feedburner.com/dcexaminer/tech, language:en-US

## Space race: How the US and China are locked in a battle to become superior in space
 - [https://www.washingtonexaminer.com/policy/space/us-china-space-war-explained](https://www.washingtonexaminer.com/policy/space/us-china-space-war-explained)
 - RSS feed: https://feeds.feedburner.com/dcexaminer/tech
 - date published: 2023-06-16 10:00:33+00:00

The United States and China, two of the world's largest superpowers, are locked in a battle to achieve supremacy in the final frontier — space.

## Space race: The latest innovations US agencies have for exploring space
 - [https://www.washingtonexaminer.com/policy/space/space-series-the-latest-innovations-u-s-space-agencies-have-for-exploring-space](https://www.washingtonexaminer.com/policy/space/space-series-the-latest-innovations-u-s-space-agencies-have-for-exploring-space)
 - RSS feed: https://feeds.feedburner.com/dcexaminer/tech
 - date published: 2023-06-16 10:00:08+00:00

Space agencies and organizations continue to innovate as they explore space with sights currently set on the moon, Mars, and beyond.

