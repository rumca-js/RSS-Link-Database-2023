# Source:Wiadomosci - Gazeta.pl, URL:https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml, language:pl-PL

## Tomasz Poręba złożył rezygnację z funkcji szefa sztabu PiS
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29878746,tomasz-poreba-zlozyl-rezygnacje-z-funkcji-szefa-sztabu-pis.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29878746,tomasz-poreba-zlozyl-rezygnacje-z-funkcji-szefa-sztabu-pis.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 22:26:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/2b/7a/1c/z29861931M,Tomasz-Poreba--szef-sztabu-wyborczego-PiS.jpg" vspace="2" />- Złożyłem na ręce prezesa Jarosława Kaczyńskiego dymisję z funkcji szefa sztabu PiS. Mimo że nie została przyjęta, pozostaje ona dla mnie decyzją ostateczną - poinformował w piątek wieczorem na Twitterze europoseł PiS Tomasz Poręba.

## Delegacja RPA utknęła na Okęciu. Pojawiły się oskarżenia o rasizm. Jest komunikat MSZ
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29878624,delegacja-rpa-utknela-na-okeciu-pojawily-sie-oskarzenia-o-rasizm.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29878624,delegacja-rpa-utknela-na-okeciu-pojawily-sie-oskarzenia-o-rasizm.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 20:56:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/4d/7d/1c/z29875789M,Delegacja-RPA-utknela-na-Okeciu.jpg" vspace="2" />Przedstawiciele RPA nie mieli pozwolenia na wwiezienie do Polski niebezpiecznych materiałów - tak Ministerstwo Spraw Zagranicznych tłumaczy incydent, do którego doszło na warszawskim Okęciu. Straż Graniczna zatrzymała tam samolot z członkami ochrony prezydenta RPA Cyrila Ramaphosy.

## Daniel Ellsberg nie żyje. Słynny sygnalista od Pentagon Papers miał 92 lata
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29878534,daniel-ellsberg-nie-zyje-slynny-sygnalista-od-pentagon-papers.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29878534,daniel-ellsberg-nie-zyje-slynny-sygnalista-od-pentagon-papers.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 20:22:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/54/7e/1c/z29878612M,Daniel-Ellsberg.jpg" vspace="2" />Nie żyje Daniel Ellsberg, analityk wojskowy i sygnalista, który ujawnił mediom tajny raport na temat wojny w Wietnamie. Miał 92 lata.

## Jarosław Gowin wystartuje w wyborach? Polityk wydał oświadczenie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29878343,jaroslaw-gowin-przekazal-wazna-wiadomosc-o-nadchodzacych-wyborach.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29878343,jaroslaw-gowin-przekazal-wazna-wiadomosc-o-nadchodzacych-wyborach.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 19:41:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/99/7e/1c/z29878425M,Jaroslaw-Gowin.jpg" vspace="2" />Jarosław Gowin nie będzie kandydował w jesiennych wyborach parlamentarnych - poinformowała Interia, publikując treść oświadczenia byłego lidera Porozumienia. "Obowiązki rządowe traktowałem w kategoriach służby Ojczyźnie i najwyższego zaszczytu" - stwierdził w piśmie polityk, który przez ostatnich 18 lat pracował w Sejmie i Senacie RP.

## Skandaliczny transparent na wiecu Tuska. PiS chce przeprosin. Rzecznik PO pisze o "idiotycznych prowokacjach"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29878318,skandaliczny-transparent-na-wiecu-tuska-oburzeni-politycy-pis.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29878318,skandaliczny-transparent-na-wiecu-tuska-oburzeni-politycy-pis.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 19:24:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c6/7e/1c/z29878470M,Wiec-Donalda-Tuska-w-Poznaniu.jpg" vspace="2" />Napis "Boże, zabrałeś nie tego Kaczyńskiego" i zdjęcie Teda Kaczynskiego, terrorysty znanego jako Unabomber - taki transparent pojawił się na wiecu Donalda Tuska w Poznaniu. Kadry ze spotkania kolportują teraz politycy PiS z Mateuszem Morawieckim na czele. Wpisy opatrują hasłem "Tusk przeproś".

## Tajemnicze zaginięcie Polki na greckiej wyspie Kos. W sprawę zamieszanych jest pięciu obcokrajowców
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29878040,27-letnia-polka-zaginela-na-greckiej-wyspie-kos-w-sprawe-zamieszanych.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29878040,27-letnia-polka-zaginela-na-greckiej-wyspie-kos-w-sprawe-zamieszanych.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 18:57:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/34/7e/1c/z29878324M,27-letnia-Anastazja-Rubinska-zaginela-na-greckiej-.jpg" vspace="2" />Anastazja Rubińska zaginęła w poniedziałek w turystycznej miejscowości Marmari na wyspie Kos. 27-latka pracowała w miejscowym hotelu. Zaginięcie kobiety zgłosił jej chłopak, który jako ostatni kontaktował się z Polką. Grecka policja zatrzymała w sprawie pięciu obcokrajowców. Wśród nich znajdował się 32-letni obywatel Bangladeszu, który został aresztowany pod zarzutem porwania kobiety.

## Putin w Petersburgu rozprawiał o broni jądrowej: NATO chce redukcji? Piep***ć ich
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29878099,putin-w-petersburgu-rozprawial-o-broni-jadrowej-nato-chce-redukcji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29878099,putin-w-petersburgu-rozprawial-o-broni-jadrowej-nato-chce-redukcji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 18:23:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/50/7e/1c/z29877328M,Prezydent-Rosji-Wladimir-Putin-wyglasza-przemowien.jpg" vspace="2" />Rosyjskie głowice jądrowe zostały dostarczone na Białoruś - oświadczył oskarżony o zbrodnie wojenne Władimir Putin. Dyktator mówił o tym w trakcie Międzynarodowego Forum Gospodarczego w Petersburgu. Putin mówił również o redukcji broni jądrowej, której chce Zachód. - Piep***ć ich - skonstatował.

## PiS szykuje polityczne show, jakiego Polska jeszcze nie widziała. Za kulisami aż wrze
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29875245,pis-szykuje-polityczne-show-jakiego-polska-jeszcze-nie-widziala.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29875245,pis-szykuje-polityczne-show-jakiego-polska-jeszcze-nie-widziala.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 17:58:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/b8/7b/1c/z29866168M,Prezes-PiS-Jaroslaw-Kaczynski-podczas-gospodarskie.jpg" vspace="2" />- Na Nowogrodzkiej jest rollercoaster - mówi ważny polityk obozu rządzącego. Szef sztabu PiS Tomasz Poręba jest "poobijany", ale nie wyleciał z wagonika i pozostaje w fotelu. Z kolei Jarosław Kaczyński nie podjął ostatecznej decyzji o swoim wejściu do rządu. W Zjednoczonej Prawicy bardzo rosną oczekiwania wobec restartu kampanii na gigantycznej konwencji 24 czerwca - wtedy prezes PiS może ogłosić, że wraca jako jedyny wicepremier.

## Poznań. Donald Tusk ostro o Jarosławie Kaczyńskim: Prezes naprawdę ma pełne gacie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29878014,poznan-donald-tusk-ostro-o-jaroslawie-kaczynskim-prezes-naprawde.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29878014,poznan-donald-tusk-ostro-o-jaroslawie-kaczynskim-prezes-naprawde.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 17:35:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ac/7e/1c/z29878188M,Donald-Tusk.jpg" vspace="2" />- Głosujesz na partię Kaczyńskiego to znaczy, że albo pozwalasz im kraść, albo chcesz kraść razem z nimi. Nie wierzę w to, żeby w Polsce było tylu chętnych do tych łatwych i nieczystych pieniędzy - mówił Donald Tusk w Poznaniu. Były premier odniósł się również do kwestii referendum ws. przyjęcia migrantów.

## Kaczyński zapowiedział referendum ws. relokacji migrantów. Rzecznik Komisji Europejskiej reaguje
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29878011,referendum-ws-relokacji-migrantow-co-na-to-komisja-europejska.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29878011,referendum-ws-relokacji-migrantow-co-na-to-komisja-europejska.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 17:27:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/81/7e/1c/z29878145M,Jaroslaw-Kaczynski.jpg" vspace="2" />Rzecznik Komisji Europejskiej Eric Mamer przekazał, że kwestia relokacji migrantów "jest w trakcie demokratycznego procesu legislacyjnego". Jak podaje RMF FM, w ten sposób zareagował na zapowiadane przez polskie władze referendum ws. relokacji migrantów.

## "Lex Tusk". Sejm zdecydował ws. prezydenckiej nowelizacji
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29878199,lex-tusk-sejm-zdecydowal-ws-prezydenckiej-nowelizacji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29878199,lex-tusk-sejm-zdecydowal-ws-prezydenckiej-nowelizacji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 17:18:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/5f/82/1b/z28845919M,Pilne.jpg" vspace="2" />Sejm przyjął nowelizację ustawy o powołaniu państwowej komisji ds. badania wpływów rosyjskich. Przepisy przygotowane przez prezydenta poparło 235 posłów, 5 było przeciw, a 9 wstrzymało się od głosu.

## Prezydentka Łodzi nie zabroni PiS-owi konwencji. Wiemy, na co pójdą pieniądze z dochodu
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,187572,29877900,prezydentka-lodzi-nie-zabroni-pis-owi-konwencji-wiemy-na-co.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,187572,29877900,prezydentka-lodzi-nie-zabroni-pis-owi-konwencji-wiemy-na-co.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 16:47:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d9/7e/1c/z29877977M,Prezydentka-Lodzi-Hanna-Zdanowska-i-Donald-Tusk.jpg" vspace="2" />Hanna Zdanowska, prezydentka Łodzi związana z Platformą Obywatelską, rozwiała wątpliwości dotyczące wynajmu Atlas Areny na konwencję Prawa i Sprawiedliwości. Jak przekazała, nie zabroni organizacji wydarzenia, a dochód z wynajmu przeznaczy na miejski program in vitro.

## Burze i intensywne opady deszczu w Polsce. Alerty IMGW, ostrzega też RCB
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29877595,burze-i-intensywne-opady-deszczu-w-polsce-alerty-imgw-ostrzega.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29877595,burze-i-intensywne-opady-deszczu-w-polsce-alerty-imgw-ostrzega.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 16:05:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/20/7e/1c/z29877792M,Deszcz-w-Polsce-w-ciagu-najblizszych-trzech-dni.jpg" vspace="2" />Nad niektórymi regionami Polski rozwinęły się burze - wynika z informacji IMGW. W wielu regionach możliwe będą też intensywne opady deszczu. Dla których regionów wydano ostrzeżenia pirwszego stopnia?

## Śmierć ciężarnej Doroty. Niedzielski mówił o aborcji i zaatakował opozycję. "Bzdury, kłamstwa, manipulacje"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29877554,smierc-ciezarnej-doroty-niedzielski-mowil-o-aborcji-i-zaatakowal.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29877554,smierc-ciezarnej-doroty-niedzielski-mowil-o-aborcji-i-zaatakowal.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 15:57:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/3d/16/1c/z29450813M,Minister-zdrowia-Adam-Niedzielski-na-konferencji-p.jpg" vspace="2" />- To są manipulacje i kłamstwa. Już największym kłamstwem, jest kwestia klauzuli sumienia. Chcę wyraźnie powiedzieć, że klauzula sumienia nie obowiązuje w sytuacji zagrożenia życia - powiedział Adam Niedzielski, pytany o sprawę śmierci ciężarnej Doroty w Nowym Targu. - Przerywanie ciąży w warunkach określonych prawnie jest dopuszczalne - dodał.

## Ekipa Dudy oskarżała urzędników Komorowskiego. Sąd nie dopatrzył się przestępstwa
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29877559,ekipa-dudy-oskarzala-urzednikow-komorowskiego-sad-nie-dopatrzyl.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29877559,ekipa-dudy-oskarzala-urzednikow-komorowskiego-sad-nie-dopatrzyl.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 15:41:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ef/7e/1c/z29877743M,Bronislaw-Komorowski-w-2014-roku.jpg" vspace="2" />Jak donosi "Gazeta Wyborcza", Sąd Okręgowy w Warszawie po czterech latach procesu uniewinnił ministra Dariusza Młotkiewicza i sześciu innych pracowników kancelarii byłego prezydenta Bronisława Komorowskiego. Chodzi o rzekomą kradzież w prezydenckich rezydencjach. Wyrok nie jest prawomocny.

## Partia Marianny Schreiber nie istnieje. Celebrytka miała problem z zebraniem tysiąca podpisów
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,29877256,partia-marianny-schreiber-nie-istnieje-celebrytka-miala-problem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,29877256,partia-marianny-schreiber-nie-istnieje-celebrytka-miala-problem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 15:06:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/cb/72/1c/z29827787M,NKonferencja-zalozycielska-partii-Marianny-Schreib.jpg" vspace="2" />Jak ustaliła "Rzeczpospolita", Mariannie Schreiber nie udało się dotąd zarejestrować partii Mam Dość 2023. Problemem - kilkakrotnie - okazała się konieczność zebrania tysiąca podpisów na liście poparcia.

## Albo Ukraińcom idzie źle, albo dopiero się rozkręcają. Ofensywa trwa, zmiany w terenie niewielkie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29876749,albo-ukraincom-idzie-zle-albo-dopiero-sie-rozkrecaja-ofensywa.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29876749,albo-ukraincom-idzie-zle-albo-dopiero-sie-rozkrecaja-ofensywa.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 14:28:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f7/7e/1c/z29876983M,Ukrainscy-zolnierze-w-rejonie-frontu-na-zachodnich.jpg" vspace="2" />Ukraińcy zaczęli właśnie wywierać presję na nowym kierunku. Rosjanie donoszą o silnym ostrzale i ataku na zachodzie Zaporoża. Wcześniejsze ukraińskie uderzenia dalej na wschód wygasły. Można to interpretować dwojako. Albo jako porażki Ukraińców, albo jako dalsze kształtowanie sytuacji.

## Turcja. Podziemne miasto w Kapadocji. Odkrył je turecki rolnik dzięki znikającym kurczakom
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,187572,29876626,60-lat-temu-turecki-rolnik-odnalazl-podziemne-miasto-wszystko.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,187572,29876626,60-lat-temu-turecki-rolnik-odnalazl-podziemne-miasto-wszystko.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 14:14:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/8f/7e/1c/z29876879M,Podziemne-miasto-Derinkuyu.jpg" vspace="2" />Derinkuyu to położone w tureckiej Kapadocji podziemne miasto, które według ekspertów mogło zamieszkiwać nawet 20 tys. ludzi. Powstało prawdopodobnie w VII wieku p.n.e., jednak świat usłyszał o nim ponownie dopiero w latach 60. za sprawą pewnego rolnika, który zburzył ścianę swojej piwnicy szukając zaginionych kurczaków. Nie wiedział, że zamiast zwierząt odnajdzie podziemną metropolię.

## Strzelanina w Szczecinie. Ofiara dzwoniła wcześniej na policję. "Mówiła, że jest ścigana"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29877215,strzelanina-w-szczecinie-ofiara-dzwonila-wczesniej-na-policje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29877215,strzelanina-w-szczecinie-ofiara-dzwonila-wczesniej-na-policje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 14:09:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/9b/7d/1c/z29874587M,Strzelanina-w-jednym-z-domow-wielorodzinnych-przy-.jpg" vspace="2" />Kobieta, która zginęła w czasie strzelaniny w Szczecinie, wcześniej zadzwoniła na policję - poinformował Mariusz Ciarka z KGP. - Wzywała pomocy. Mówiła, że jest ścigana przez mężczyznę - podkreślił funkcjonariusz.

## Jens Stoltenberg po spotkaniu ministrów w Brukseli: Ukraina będzie członkiem NATO, drzwi są otwarte
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29877116,jens-stoltenberg-po-spotkaniu-ministrow-w-brukseli-ukraina.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29877116,jens-stoltenberg-po-spotkaniu-ministrow-w-brukseli-ukraina.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 14:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/10/7e/1c/z29877264M,Jens-Stoltenberg.jpg" vspace="2" />- Wszyscy zgadzamy się, że Ukraina zbliża się stopniowo do NATO i dzieje się tak już od kilku lat. Zgadzamy się, że drzwi NATO są otwarte, że Ukraina będzie członkiem Sojuszu - powiedział w piątek Jens Stoltenberg, sekretarz generalny Sojuszu Północnoatlantyckiego. Stoltenberg powiedział też o planach przekazania Ukrainie myśliwców F-16.

## Paulina została otruta? Śledczy wracają do sprawy śmierci 25-latki. "1000-krotnie przekroczona dawka"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,187572,29876737,paulina-zostala-otruta-sledczy-wracaja-do-sprawy-smierci-25-latki.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,187572,29876737,paulina-zostala-otruta-sledczy-wracaja-do-sprawy-smierci-25-latki.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 13:59:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/1c/59/1c/z29727772M,Sad--zdjecie-ilustracyjne-.jpg" vspace="2" />Choć minęło niemal dziewięć lat od śmierci Pauliny, do dziś nie jest jasne, dlaczego do niej doszło. Śledczy wskazywali na rzekomy "problem alkoholowy" dziewczyny, ale w momencie śmierci w jej krwi nie było alkoholu. Jej rodzice na własną rękę zebrali dowody, z których wynika, że 25-latka mogła zostać otruta.

## Pracownik Harvardu kradł i sprzedawał ludzkie mózgi, kości i skóry. Proceder trwał kilka lat
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29876421,pracownik-harvardu-kradl-i-sprzedawal-ludzkie-mozgi-kosci-i.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29876421,pracownik-harvardu-kradl-i-sprzedawal-ludzkie-mozgi-kosci-i.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 13:37:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ec/7e/1c/z29876972M,55-letni-Cedric-Lodge-odpowie-za-kradziez-i-sprzed.jpg" vspace="2" />55-letni Cedric Lodge, szef kostnicy wydziału medycznego Uniwersytetu Harvarda, sprzedawał przez internet części ludzkiego ciała, które były przeznaczone do badań. Były wśród nich czaszki, skóra, a nawet mózg. - Niektórych przestępstw nie da się zrozumieć - skomentował prokurator z Pensylwanii Gerard Karam.

## Luizjana. 28-latka udawała 17-latkę, aby móc chodzić do szkoły. Chciała nauczyć się angielskiego
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29876844,luizjana-28-latka-udawala-17-latke-aby-moc-chodzic-do-szkoly.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29876844,luizjana-28-latka-udawala-17-latke-aby-moc-chodzic-do-szkoly.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 13:25:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/7c/55/1c/z29709692M,Wolne-od-szkoly--zdjecie-ilustracyjne-.jpg" vspace="2" />Policja z Luizjany aresztowała 28-latkę, która przez cały rok uczęszczała do liceum. Kobieta wraz z matką sfałszowały dokumenty, z którym miało wynikać, że ma ona nie 28, a 17 lat. Zatrzymana zapisała się do szkoły, bo chciała nauczyć się języka angielskiego.

## Lewica z pakietem postulatów "Bezpieczna Polka". Apelują o poparcie opozycji jeszcze przed wyborami
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29876382,lewica-z-pakietem-postulatow-bezpieczna-polka-apeluja-o-poparcie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29876382,lewica-z-pakietem-postulatow-bezpieczna-polka-apeluja-o-poparcie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 13:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a1/7e/1c/z29876897M,Konferencja-prasowa-w-Senacie-w-sprawie-Pakietu-Le.jpg" vspace="2" />- Polki chcą po prostu normalnie żyć, chcą być bezpieczne - mówiła w piątek na konferencji prasowej w Sejmie Agnieszka Dziemianowicz-Bąk. Razem z innymi posłankami Lewicy przedstawiła pakiet postulatów i ustaw "Bezpieczna Polka" i zaapelowała o poparcie go przez demokratyczną opozycję jeszcze przed wyborami.

## Jedzenie niemytych truskawek może źle się skończyć. Tych kolistych punktów nie powinno być w mózgu
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29876758,jedzenie-niemytych-truskawek-moze-zle-sie-skonczyc-tych-kolistych.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29876758,jedzenie-niemytych-truskawek-moze-zle-sie-skonczyc-tych-kolistych.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 12:55:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/fc/7e/1c/z29876988M,Rezonans-magnetyczny-mozgu-pacjenta-z-bablowica.jpg" vspace="2" />Sezon na truskawki zaczął się już w pełni, a ceny owoców na straganach są coraz niższe. To wszystko zachęca do spożywania tych zdrowych i smacznych owoców. Zawsze jednak należy pamiętać o wcześniejszym umyciu truskawek. Dlaczego to takie ważne, wyjaśnia zdjęcie udostępnione przez ratownika medycznego.

## Są łyse, skrzydlate i mogą spadać z nieba w upały. Jak zaopiekować się oseskiem nietoperza?
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29876136,sa-lyse-skrzydlate-i-moga-spadac-z-nieba-w-upaly-jak-zaopiekowac.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29876136,sa-lyse-skrzydlate-i-moga-spadac-z-nieba-w-upaly-jak-zaopiekowac.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 12:53:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c5/7e/1c/z29876677M,Mlode-nietoperzy-moga-spadac-ze-stropow-w-upaly.jpg" vspace="2" />Towarzystwo Ochrony Przyrody "Salamandra" przekazało, że w przyszłym tygodniu w Polsce mogą wystąpić upały, które wpłyną na zachowanie pewnej grupy ssaków. Chodzi o młode nietoperzy, które przez wysoką temperaturę mogą wypadać spod dachów budynków. Jak się zachować w tej sytuacji? Co zrobić ze znalezionym oseskiem?

## 45-latek przyleciał helikopterem na własny pogrzeb. "Śmierć" miała dać nauczkę jego rodzinie [WIDEO]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29876189,tiktoker-przylecial-helikopterem-na-wlasny-pogrzeb-smierc.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29876189,tiktoker-przylecial-helikopterem-na-wlasny-pogrzeb-smierc.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 12:47:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/b5/7e/1c/z29876661M,Tiktoker-przylecial-na-wlasny-pogrzeb-helikopterem.jpg" vspace="2" />45-letni David Baerten, popularny tiktoker z Belgii, upozorował własną śmierć. Jego bliscy zorganizowali pogrzeb, na który "zmarły" przyleciał helikopterem razem z ekipą filmową. Mężczyzna wyjaśnił, że chciał w ten sposób dać nauczkę rodzinie, przez którą czuł się niedoceniany.

## Przyczepa odłączyła się od jadącego auta i uderzyła w 16-latkę. Do szpitala zabrał ją śmigłowiec LPR
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,187572,29876070,przyczepa-odlaczyla-sie-od-jadacego-auta-i-uderzyla-w-16-latke.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,187572,29876070,przyczepa-odlaczyla-sie-od-jadacego-auta-i-uderzyla-w-16-latke.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 12:20:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/7b/7e/1c/z29876347M,Przyczepa-uderzyla-w-16-latke-w-Sedziejowicach.jpg" vspace="2" />W Sędziejowicach (woj. łódzkie) w czekającą na autobus 16-latkę wjechała przyczepa, która odczepiła się od jadącego drogą samochodu. Z podejrzeniem urazu kręgosłupa nastolatka została przetransportowana śmigłowcem Lotniczego Pogotowia Ratunkowego do szpitala.

## Wynajmował we Wrocławiu mieszkanie młodym kobietom. Później je gwałcił. Prokuratura apeluje do ofiar
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,187572,29875975,wynajmowal-mieszkanie-mlodym-kobietom-pozniej-je-wykorzystywal.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,187572,29875975,wynajmowal-mieszkanie-mlodym-kobietom-pozniej-je-wykorzystywal.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 12:12:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/15/7e/1c/z29876245M,Wroclaw--Wynajmowal-mieszkanie-mlodym-kobietom--Po.jpg" vspace="2" />Młode kobiety, które wynajmowały we Wrocławiu mieszkanie od Radosława D., musiały przeżyć wiele koszmarnych chwil. Prokuratura postawiła mężczyźnie zarzuty m.in. gwałtu, znęcania się i oszustwa. Śledczy wciąż poszukują kobiet, które wynajmowały mieszkanie od podejrzanego. Proceder mógł bowiem trwać wiele lat.

## Afrykańscy przywódcy z "misją pokojową" w Ukrainie. Pojadą też do Putina
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29876289,afrykanscy-przywodcy-z-misja-pokojowa-w-ukrainie-to-nic.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29876289,afrykanscy-przywodcy-z-misja-pokojowa-w-ukrainie-to-nic.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 12:02:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/3a/7e/1c/z29876282M,Prezydent-Republiki-Poludniowej-Afryki-Cyril-Ramap.jpg" vspace="2" />Kilku afrykańskich przywódców przybyło do Europy z "misją pokojową", w celu podjęcia mediacji między Ukrainą a Rosją. Zdaniem ekspertów, poza przedstawieniem im perspektywy Kijowa i Zachodu, ich misja niewiele da.

## Zabójstwo matki sześciorga dzieci. 35-letniego podejrzanego złapano po 19 latach. Po raz drugi
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29876118,podejrzany-o-zabojstwo-zlapany-wypuszczony-i-znow-zlapany.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29876118,podejrzany-o-zabojstwo-zlapany-wypuszczony-i-znow-zlapany.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 11:49:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ea/7d/1c/z29876202M,Policja-zatrzymala-podejrzanego-o-zabojstwo-sprzed.jpg" vspace="2" />Policja ujęła podejrzanego o morderstwo sprzed 19 lat. To już drugie zatrzymanie 35-latka. Dwa lata temu, decyzją sądu, mężczyznę jednak wypuszczono. Rozwiązanie sprawy było możliwe m.in. dzięki pomocy policjantów z gdańskiego Archiwum X.

## Putin wystąpi, by ''przedstawić plany na przyszłość''. Ze względów bezpieczeństwa wyłączono internet
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29875893,putin-wystapi-by-przedstawic-plany-na-przyszlosc-ze-wzgledow.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29875893,putin-wystapi-by-przedstawic-plany-na-przyszlosc-ze-wzgledow.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 11:35:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/25/7d/1c/z29872933M,Wladimir-Putin.jpg" vspace="2" />W piątek Władimir Putin wygłosi przemówienie na forum w Petersburgu. Rosyjska agencja TASS poinformowała, że mobilny internet ma zostać wyłączony z przyczyn technicznych. Według niezależnych mediów chodzi jednak o to, żeby udaremnić potencjalny atak dronów.

## Posłanka KO pomyliła się podczas głosowania przeciwko "paktowi migracyjnemu". Kaleta ją wykpił
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29875518,poslanka-ko-pomylila-sie-podczas-glosowania-przeciwko-paktowi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29875518,poslanka-ko-pomylila-sie-podczas-glosowania-przeciwko-paktowi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 11:08:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/3f/7e/1c/z29876287M,Kamila-Gasiuk-Pihowicz.jpg" vspace="2" />Kamila Gasiuk-Pihowicz posłanka KO podczas głosowania omyłkowo zagłosowała za sprzeciwem wobec unijnego "paktu migracyjnego", o czym poinformowała w mediach społecznościowych. Z wpisu polityczki w odpowiedzi zadrwił Sebastian Kaleta, wiceminister sprawiedliwości

## Białoruś wprowadza prawo, które pozwoli sądzić zmarłych. "Chcą ich obwiniać za problemy rządu"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29875493,bialorus-wprowadzi-prawo-ktore-pozwoli-sadzic-zmarlych-chca.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29875493,bialorus-wprowadzi-prawo-ktore-pozwoli-sadzic-zmarlych-chca.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 11:07:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/98/7d/1c/z29876120M,Prezydent-Bialorusi-Alaksandr-Lukaszenka.jpg" vspace="2" />W Białorusi trwają prace nad przepisami, które pozwolą sądzić zmarłych oskarżanych o przestępstwa, które nie ulegają przedawnieniu. Władze przekonują, że tego rodzaju nowelizacja służy tworzeniu narzędzi pozwalających na ochronę dobrego imienia kraju. Natomiast część komentatorów uważa, że rządzący chcą w ten sposób usprawiedliwić przed społeczeństwem swoje niepowodzenia.

## Pacjentka szpitala, w którym zmarła 33-letnia Dorota: To mogłam być ja. Ta sama noc, to samo zalecenie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,187572,29875390,pacjentka-szpitala-w-ktorym-zmarla-33-letnia-dorota-to-moglam.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,187572,29875390,pacjentka-szpitala-w-ktorym-zmarla-33-letnia-dorota-to-moglam.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 10:51:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c0/7d/1c/z29875648M,Podhalanski-Szpital-Specjalistyczny-imienia-Jana-P.jpg" vspace="2" />- To mogłam być ja. Ten sam szpital, ten sam dzień, ta sama noc. Płakać mi się chce - powiedziała pani Katarzyna w programie "Uwaga!" TVN. Lekarze udzielili jej podobnych zaleceń, do tych, które miała stosować 33-letnia Dorota - leżeć z nogami w górze, by wody mniej odpływały. Ta metoda, zdaniem specjalistki ginekologii, jeszcze zwiększa zagrożenie infekcji.

## Strzelanina w Szczecinie. Sąsiedzi o parze z mieszkania: Pojawiali się od czasu do czasu
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29875576,strzelanina-w-szczecinie-sasiedzi-o-parze-z-mieszkania-pojawiali.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29875576,strzelanina-w-szczecinie-sasiedzi-o-parze-z-mieszkania-pojawiali.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 10:34:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/08/7d/1c/z29873928M,Akcja-policji-na-ul--Kasjopei-w-Szczecinie--Ktos-s.jpg" vspace="2" />Prokuratura potwierdziła, że w czwartek na ulicy Kasjopei w Szczecinie odkryto ciała trzech dorosłych osób. Joanna Biranowska-Sochalska z Prokuratury Okręgowej w Szczecinie przekazała w rozmowie z TVN24, że zlecono sekcję zwłok ofiar. Poinformowała także, w jakim kierunku prowadzone jest postępowanie w sprawie.

## Rosyjska rakieta pod Bydgoszczą. Błaszczak oskarżał, ale nie zawiadomił służb. "Nie ma potrzeby"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29875727,rosyjska-rakieta-pod-bydgoszcza-blaszczak-oskarzal-ale-nie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29875727,rosyjska-rakieta-pod-bydgoszcza-blaszczak-oskarzal-ale-nie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 10:05:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/3a/5f/1c/z29752890M,Minister-obrony-w-rzadzie-PiS-Mariusz-Blaszczak-po.jpg" vspace="2" />Mariusz Błaszczak publicznie oskarżył dowódcę operacyjnego rodzajów sił zbrojnych po tym, jak rosyjska rakieta spadła w lesie pod Bydgoszczą. Z ustaleń dziennikarza RMF FM wynika, że do tej pory minister obrony nie powiadomił prokuratury o możliwości popełnienia przestępstwa zaniechania obowiązków.

## Incydent na Okęciu. Delegacja RPA utknęła na lotnisku w Warszawie. Wszystko przez broń
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29875655,niespotykana-sytuacja-na-okeciu-delegacja-rpa-od-kilkunastu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29875655,niespotykana-sytuacja-na-okeciu-delegacja-rpa-od-kilkunastu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 10:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/4d/7d/1c/z29875789M,Delegacja-RPA-utknela-na-Okeciu.jpg" vspace="2" />Delegacja RPA od kilkunastu godzin tkwi w samolocie na płycie lotniska Chopina w Warszawie. Nie mogą opuścić samolotu, który ma odlecieć z Okęcia dopiero po południu. Pasażerowie mają przy sobie broń bez stosownych pozwoleń, brakuje im też innych dokumentów, które pozwoliłyby opuścić pokład samolotu.

## Hałas, brak wody i światła koparek. Tak żyją Czesi obok Turowa. Autorzy skargi: Morawiecki zawalił sprawę
 - [https://next.gazeta.pl/next/7,172392,29871361,czesi-nie-maja-wody-przez-kopalnie-w-turowie-autorzy-skargi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://next.gazeta.pl/next/7,172392,29871361,czesi-nie-maja-wody-przez-kopalnie-w-turowie-autorzy-skargi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 09:36:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/98/7c/1c/z29871512M,Autorzy-skargi-na-Turow--Polski-rzad-chce-tylko-ek.jpg" vspace="2" />- Decyzja sądu ws. Turowa nie jest bezprawna, wręcz przeciwnie, cały proces rozbudowy kopalni był bezprawny. Ale premier Morawiecki, jego koledzy i PGE nadal odmawiają uznania rzeczywistości i przyznania, że całkowicie zawalili sprawę - grzmi Lukáš Hrábek z czeskiego oddziału Greenpeace. To jego reakcja na słowa premiera Morawieckiego o "bezprawnej" decyzji ws. oceny środowiskowej koncesji Turowa.

## "Prezesie, tutaj!". Pracowniczka TVP naprowadzała Kaczyńskiego. "Tusk pozamykał wszystkie drzwi" [WIDEO]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29875478,pracowniczka-tvp-naprowadzala-kaczynskiego-prezesie-tutaj.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29875478,pracowniczka-tvp-naprowadzala-kaczynskiego-prezesie-tutaj.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 09:32:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e0/7d/1c/z29875680M,Jaroslaw-Kaczynski-w-Sejmie-byl-naprowadzany-przez.jpg" vspace="2" />Jarosław Kaczyński był pytany przez dziennikarzy o komentarz odnośnie śmierci ciężarnej 33-letniej Doroty w Nowym Targu. Prezes PiS próbował przedrzeć się sejmowymi korytarzami, otoczony z każdej ze stron reporterami. Politykowi z pomocą przyszła jednak reporterka TVP, która naprowadziła Kaczyńskiego na inne wyjście. Według reporterów dzięki temu Kaczyński mógł uniknąć odpowiedzi na pytania.

## Adam Szłapka potrącił rowerzystkę, podaje TVP Info. "Nie powiedział policji, że jest posłem"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29875149,tvp-info-szef-nowoczesnej-potracil-rowerzystke-posel-ma.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29875149,tvp-info-szef-nowoczesnej-potracil-rowerzystke-posel-ma.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 09:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f1/7d/1c/z29875441M,Przewodniczacy-Nowoczesnej-Adam-Szlapka.jpg" vspace="2" />TVP Info poinformowało właśnie o kwietniowym wypadku z udziałem przewodniczącego Nowoczesnej. Serwis przekazał, że Adam Szłapka potrącił rowerzystkę, jadąc samochodem i zarzuca mu, że nie przyznał się policjantom, że jest posłem. Adam Szłapka: Zrzeknę się immunitetu.

## W Sejmie dyskusja o ''lex Tusk'' przy niemal pustej sali. ''Infamia'', ''cyrk wyborczy''
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29875407,w-sejmie-dyskusja-o-lex-tusk-przy-niemal-pustej-sali-infamia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29875407,w-sejmie-dyskusja-o-lex-tusk-przy-niemal-pustej-sali-infamia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 09:20:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/77/7b/1c/z29864823M,Posiedzenie-Sejmu-ws--nowelizacji--lex-Tusk-.jpg" vspace="2" />W Sejmie odbyło się drugie czytanie prezydenckiego projektu nowelizacji ustawy o komisji do spraw rosyjskich wpływów w Polsce w latach 2007-2022. Przy niemal pustej sali doszło do burzliwych oświadczeń polityków. Posłowie opozycji nazywali pomysł rządzących mianem ''cyrku wyborczego'' i ''infamią''.

## Policjant zabrał dziecko na lody. Nagle został napadnięty i pobity. "Za to, że jesteś psem"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,187572,29875055,policjant-spacerowal-z-dzieckiem-w-warszawie-zostal-brutalnie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,187572,29875055,policjant-spacerowal-z-dzieckiem-w-warszawie-zostal-brutalnie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 09:06:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/2a/7d/1c/z29875242M,Warszawa--Pobicie-policjanta-z-dzieckiem--zdjecie-.jpg" vspace="2" />Policjant był w cywilu i po służbie, gdy wybrał się ze swoim 5-letnim dzieckiem na spacer i lody. Nagle napadło na niego dwóch młodych mężczyzn i brutalnie go pobili, a gdy próbował dodzwonić się po pomoc - usiłowali najechać na niego samochodem. "Za to, że jesteś psem" - mieli powiedzieć mężczyźnie. Do napaści doszło w Warszawie, śledztwo w tej sprawie wszczęła prokuratura w Mławie.

## Atak rakietowy na Kijów. W stolicy Ukrainy trwa wizyta delegacji pokojowej
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29875496,atak-rakietowy-na-kijow-w-stolicy-ukrainy-trwa-wizyta-delegacji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29875496,atak-rakietowy-na-kijow-w-stolicy-ukrainy-trwa-wizyta-delegacji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 09:04:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/60/82/1b/z28845920M,Pilne.jpg" vspace="2" />Rosjanie rozpoczęli atak rakietowy na Kijów. Miejscowe władze informują, że działa ukraińska ochrona powietrza, która przechwytuje pociski. Zaapelowały do ludności o pozostanie w schronach do czasu zakończenia alarmu przeciwlotniczego.

## Zaginione małżeństwo z Warszawy. Znajomy o tym, co Adam chciał zrobić z "portfelem pełnym pieniędzy"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,187572,29875200,zaginione-malzenstwo-z-warszawy-znajomy-o-tym-co-adam-chcial.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,187572,29875200,zaginione-malzenstwo-z-warszawy-znajomy-o-tym-co-adam-chcial.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 08:40:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f7/68/1c/z29789943M,Mokotowscy-policjanci-poszukuja-zaginionego-malzen.jpg" vspace="2" />Śledczy nadal nie wyjaśnili sprawy zaginionego małżeństwa z Warszawy. Policja nadal poszukuje Anety i Adama Jagłów, którzy zostawili nastoletnich synów i opuścili mieszkanie, znajdujące się na Mokotowie. Nowe informacje w sprawie przedstawił znajomy z pracy Adama.

## Nowe rewelacje Sołowjowa w rosyjskiej tv: Kijów kontroluje USA, bo Biden dostał łapówkę od Ukrainy
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29874761,proklemlowski-dziennikarz-kijow-w-pelni-kontroluje-usa-wg.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29874761,proklemlowski-dziennikarz-kijow-w-pelni-kontroluje-usa-wg.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 08:33:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ab/7d/1c/z29875115M,Wladimir-Putin-i-Wladimir-Solowjow.jpg" vspace="2" />Władimir Sołowjow, znany prokremlowski propagandysta, oświadczył w rosyjskiej telewizji, że Ukraina ma "pełną kontrolę" nad USA, ponieważ Joe Biden dostał łapówkę od władz w Kijowie. Sołowjow stwierdził, że z tego właśnie powodu Stany Zjednoczone wysyłają Ukraińcom broń. I dodał, że Amerykanie powinni wszcząć postępowanie przeciwko Wołodymyrowi Zełenskiemu.

## Polski dziennikarz blisko rosyjskiego ostrzału. Pomagał ewakuować zwierzęta przez Dniepr [WIDEO]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29874758,poruszajace-nagranie-polskiego-korespondenta-w-ukrainie-byl.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29874758,poruszajace-nagranie-polskiego-korespondenta-w-ukrainie-byl.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 08:19:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/fc/7d/1c/z29875196M,Wolontariusze-ewakuuja-zwierzeta-z-zalanych-tereno.jpg" vspace="2" />"W trakcie ewakuacji zwierząt znaleźliśmy się bardzo blisko rosyjskiego ostrzału" - przekazał jeden z polskich korespondentów w Ukrainie. Mateusz Lachowski płynął łodzią po Dnieprze, gdy rozległy się strzały. Dwóch wolontariuszy zostało rannych w wyniku tego ataku.

## Radosław M., b. dziennikarz TVP, staje przed sądem oskarżony o czyny pedofilskie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29874553,radoslaw-m-b-dziennikarz-tvp-staje-przed-sadem-oskarzony.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29874553,radoslaw-m-b-dziennikarz-tvp-staje-przed-sadem-oskarzony.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 08:14:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d8/7d/1c/z29874648M,Sad--zdjecie-ilustracyjne-.jpg" vspace="2" />Radosław M., były dziennikarz TVP, Polskiego Radia, Superstacji, po raz kolejny ma stanąć w piątek przed warszawskim sądem. Jest oskarżony o czyny pedofilskie, m.in. seksualne wykorzystanie osoby poniżej 15 r. ż. i utrwalanie treści pornograficznych z jej udziałem. Mężczyzna od września ubiegłego roku przebywa w areszcie, grozi mu 12 lat więzienia.

## Kanada. Jeden z najtragiczniejszych wypadków drogowych w historii kraju. Wiele ofiar
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29874609,kanada-jeden-z-najtragiczniejszych-wypadkow-drogowych-w-historii.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29874609,kanada-jeden-z-najtragiczniejszych-wypadkow-drogowych-w-historii.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 08:08:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a7/7d/1c/z29875111M,Wypadek-w-Kanadzie.jpg" vspace="2" />W Kanadzie co najmniej 15 osób zginęło w zderzeniu ciężarówki z busem firmy transportowej - przekazała tamtejsza policja. Dziesięciu pasażerów trafiło do szpitala z różnymi obrażeniami. Służby oceniają, że to jeden z najtragiczniejszych wypadków drogowych w historii kraju.

## Mecz Polska-Niemcy. Jak dojechać na Stadion Narodowy? Przewidywane są utrudnienia w ruchu
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,187572,29874675,mecz-polska-niemcy-jak-dojechac-na-stadion-narodowy-przewidywane.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,187572,29874675,mecz-polska-niemcy-jak-dojechac-na-stadion-narodowy-przewidywane.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 08:03:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/5d/74/1c/z29836893M,Jakub-Blaszczykowski-w-barwach-reprezentacji-Polsk.jpg" vspace="2" />Zamknięcia konkretnych obszarów i objazdy to tylko część z utrudnień w ruchu, które nastąpią w piątek. Dojazd na Stadion Narodowy, aby obejrzeć mecz Polska-Niemcy, umożliwi kibicom m.in. komunikacja miejska w Warszawie. Jakie zmiany czekają kierowców?

## Prokuratura od zadań specjalnych zajmuje się właścicielką Cafe Kulturalna. Zarzuty o defraudację
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29874772,prokuratura-od-zadan-specjalnych-zajmuje-sie-wlascicielka-cafe.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29874772,prokuratura-od-zadan-specjalnych-zajmuje-sie-wlascicielka-cafe.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 07:52:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/47/fe/1b/z29354567M,Palac-Kultury-i-Nauki.jpg" vspace="2" />Szczecińska prokuratura, która zajmuje się sprawami z politycznym tłem, aresztowała Agnieszkę Ł. właścicielkę Cafe Kulturalna. Zarzuty dotyczą dotacji, które miała zdefraudować fundacja założona przez kobietę w celu pomocy uchodźcom z Ukrainy. Jak przekazuje "Gazeta Wyborcza", chodzi o 7 mln zł.

## Władimir Putin wybiera się do Turcji mimo nakazu aresztowania. Dwaj prezydenci odwołali wizyty w Rosji
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29874549,wladimir-putin-ma-pojechac-do-turcji-mimo-nakazu-aresztowania.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29874549,wladimir-putin-ma-pojechac-do-turcji-mimo-nakazu-aresztowania.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 07:38:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/29/7d/1c/z29874729M,Wladimir-Putin-i-Recep-Tayyip-Erdogan.jpg" vspace="2" />Władimir Putin zamierza pojechać do Turcji, aby porozmawiać z Recepem Tayyipem Erdoganem. Prezydent Rosji planuje to spotkanie, nie bacząc na to, że Międzynarodowy Trybunał Karny wydał nakaz aresztowania Putina. Z kolei przywódcy dwóch afrykańskich krajów, którzy mieli odwiedzić Rosję, odwołali swoje wizyty.

## Papież Franciszek opuścił szpital. "Jest lepiej niż wcześniej". Audiencje nadal są zawieszone
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29874838,papiez-franciszek-opuscil-szpital-audiencje-nadal-w-zawieszeniu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29874838,papiez-franciszek-opuscil-szpital-audiencje-nadal-w-zawieszeniu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 07:05:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/37/77/1c/z29850167M,Papiez-Franciszek-w-szpitalu.jpg" vspace="2" />Papież w piątek rano opuścił klinikę Gemelli w Rzymie. Franciszek przebywał w niej od operacji, która odbyła się 7 czerwca. Duchowny wróci teraz do Watykanu - przekazała agencja AFP.

## Henry Kissinger: Jeśli Ukraina wytrwa, Putin nie przetrwa. "Rosja musi pozostać częścią Europy"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29874572,henry-kissinger-jesli-ukraina-wytrwa-putin-nie-przetrwa-rosja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29874572,henry-kissinger-jesli-ukraina-wytrwa-putin-nie-przetrwa-rosja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 06:50:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c4/7d/1c/z29874628M,Henry-Kissinger--zdjecie-ilustracyjne.jpg" vspace="2" />Henry Kissinger uważa, że Władimir Putin nie utrzyma władzy, jeśli Rosja przegra wojnę w Ukrainie. Były amerykański sekretarz stanu obawia się też globalnego konfliktu, opartego na rywalizacji militarnych potęg, takich jak Chiny.

## Samochód stoczył się, gdy kierująca odprowadzała dzieci do szkoły. 11-latek w ciężkim stanie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,187572,29874548,zaparkowany-samochod-stoczyl-sie-ze-skarpy-i-potracil-11-latka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,187572,29874548,zaparkowany-samochod-stoczyl-sie-ze-skarpy-i-potracil-11-latka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 06:46:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/cc/7d/1c/z29874636M,Czestochowa--Samochod-stoczyl-sie-ze-skarpy-i-potr.jpg" vspace="2" />11-latek z Częstochowy przechodził chodnikiem, kiedy uderzył w niego samochód. Kobieta, która zaparkowała pojazd, w tym czasie odprowadzała swoje dzieci do szkoły. Chłopiec został przewieziony do szpitala, jest w ciężkim stanie.

## Magdalena Ogórek "największą hipokrytką TVP"? PO o tym, że "w sieci nic nie ginie" [WIDEO]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29874599,magdalena-ogorek-najwieksza-hipokrytka-tvp-po-o-prorosyjskich.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29874599,magdalena-ogorek-najwieksza-hipokrytka-tvp-po-o-prorosyjskich.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 06:41:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/9a/5e/1a/z27649946M,Magdalena-Ogorek.jpg" vspace="2" />Platforma Obywatelska opublikowała nagranie, które ma być odpowiedzią na serial "Reset" TVP. Politycy skupili się na jednej z "twarzy" Telewizji Polskiej - Magdalenie Ogórek. Byłej kandydatce SLD na stanowisko prezydenta wypomniano to, jak nawoływała do dialogu z Rosją. Na jednym z rosyjskich portali można do tej pory znaleźć materiał o tym, dlaczego Ogórek nie udało się wygrać wyborów. Wśród powodów wymieniono, że "jest zbyt atrakcyjna" oraz "odrzuca rusofobiczny kurs w rusofobicznej Polsce".

## PiS ma przedstawić nowe propozycje programowe. "Ludzie będą o nich mówić całe wakacje"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29874547,pis-ma-przedstawic-nowe-propozycje-programowe-ludzie-beda.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29874547,pis-ma-przedstawic-nowe-propozycje-programowe-ludzie-beda.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 06:08:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/b8/7b/1c/z29866168M,Prezes-PiS-Jaroslaw-Kaczynski-podczas-gospodarskie.jpg" vspace="2" />24 czerwca odbędzie się kolejna konwencja organizowana przez PiS. Jak wynika z ustaleń portalu i.pl spotkanie z wyborcami w Łodzi ma przynieść nowe propozycje programowe PiS, o których ''ludzie będą mówić całe wakacje". Ponadto wydarzenie w Łodzi ma być zupełnie ''nową jakością, czymś, czego polska polityka nie widziała''.

## Strzelanina w Szczecinie. Sąsiedzi: "Oboje koło 50, zadbani. To ciche osiedle, oni też tacy byli"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,187572,29874544,strzelanina-w-szczecinie-swiadkowie-oboje-kolo-50-zadbani.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,187572,29874544,strzelanina-w-szczecinie-swiadkowie-oboje-kolo-50-zadbani.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 05:39:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/95/7d/1c/z29874581M,Strzelanina-w-jednym-z-domow-wielorodzinnych-przy-.jpg" vspace="2" />W czwartek wieczorem przy ul. Kasjopei w Szczecinie doszło do strzelaniny, w wyniku której zginęły trzy osoby. Policja prowadzi dochodzenie w tej sprawie. Tymczasem świadkowie opisali, że w momencie, gdy rozległy się strzały, na balkonie jednego z budynków stał mężczyzna ubrany cały na czarno. - W ręce miał pistolet. Strzelał z niego w kierunku mieszkania - relacjonują.

## Nocna debata nad in vitro w Sejmie. Rozenek-Majdan: Prawdopodobnie nigdy nie zostałabym mamą
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29874533,nocna-debata-nad-in-vitro-w-sejmie-rozenek-majdan-prawdopodobnie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29874533,nocna-debata-nad-in-vitro-w-sejmie-rozenek-majdan-prawdopodobnie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 04:59:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/6a/7d/1c/z29874538M,Malgorzata-Rozenek-Majdan-w-Sejmie.jpg" vspace="2" />W nocy z czwartku na piątek w Sejmie dyskutowano nad obywatelskim projektem o in vitro. Posłanka Elżbieta Płonka, która przedstawiała stanowisko partii rządzącej, mówiła o "eugenice", "produktach" i "zabijaniu" zarodków. - Gdyby nie możliwość, którą in vitro mi stworzyło, prawdopodobnie nigdy nie zostałabym mamą, a to najważniejsza rzecz, jaką mogę przeżywać - argumentowała Małgorzata Rozenek-Majdan, przedstawicielka Komitetu Inicjatywy Ustawodawczej. Projekt trafi teraz do komisji zdrowia.

## Bazy na Krymie broni dwa razy więcej delfinów bojowych. "Rosja traktuje zagrożenie poważnie"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29873897,rosja-traktuje-zagrozenie-powaznie-bazy-na-krymie-broni-dwa.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29873897,rosja-traktuje-zagrozenie-powaznie-bazy-na-krymie-broni-dwa.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 04:10:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/37/7d/1c/z29874231M,-Rosja-traktuje-zagrozenie-powaznie---Bazy-na-Krym.jpg" vspace="2" />"Zagrożenie ze strony ukraińskich nurków z elitarnych sił specjalnych musi mieć duże znaczenie dla rosyjskiej marynarki wojennej. Oprócz rozległych sieci przeciwtorpedowych i wyrzutni rakiet Rosja zwiększyła liczbę wyszkolonych delfinów strzegących Sewastopola na Krymie" - podał w środę brytyjski portal Nawal News.

## Raport: Młodzi Polacy nie mają zaufania do rządu. Najgorszy wynik w UE. "Kryzys demokracji"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,127561,29874042,raport-mlodzi-polacy-nie-maja-zaufania-do-rzadu-najgorszy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,127561,29874042,raport-mlodzi-polacy-nie-maja-zaufania-do-rzadu-najgorszy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 04:07:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ee/3a/1b/z28551918M,Szkola--zdjecie-ilustracyjne-.jpg" vspace="2" />Coraz mniej młodych ludzi w Europie wierzy w lepsze jutro. Spada zaufanie do instytucji państwowych i ocena demokracji. Dotyczy to szczególnie młodzieży z Polski.

## Horoskop dzienny - piątek 16 czerwca [Baran, Byk, Bliźnięta, Rak, Lew, Panna, Waga, Skorpion, Strzelec, Koziorożec, Wodnik, Ryby]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,168571,29872212,horoskop-dzienny-piatek-16-czerwca-baran-byk-bliznieta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,168571,29872212,horoskop-dzienny-piatek-16-czerwca-baran-byk-bliznieta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-16 03:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/98/77/1c/z29850008M,Horoskop-dzienny---piatek.jpg" vspace="2" />Horoskop dzienny na piątek 16 czerwca. Czy czekają cię zmiany w życiu osobistym? A może poszczęści ci się w życiu zawodowym? Znajdź swój znak i sprawdź, co zaplanował dla ciebie los.

