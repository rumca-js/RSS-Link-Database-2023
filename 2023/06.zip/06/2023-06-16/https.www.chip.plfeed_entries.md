# Source:Chip.pl, URL:https://www.chip.pl/feed, language:pl-PL

## Szukasz robota odkurzającego? Roborock S7 Max Ultra poleca się w super promocji
 - [https://www.chip.pl/2023/06/roborock-s7-max-ultra-promocja-przedpremierowa](https://www.chip.pl/2023/06/roborock-s7-max-ultra-promocja-przedpremierowa)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-06-16 21:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="563" src="https://konto.chip.pl/wp-content/uploads/2023/06/roborock-s7-max-ultra-2.jpg" style="margin-bottom: 10px;" width="1000" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/06/roborock-s7-max-ultra-2.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Chyba większość z nas latem woli spędzać czas na wypoczynku zamiast na robieniu porządków. A jednak sprzątania nie da się ominąć. Dlatego to świetny moment na kupno robota odkurzającego, który posprząta podłogi za nas. Na geekbuying.pl możemy teraz kupić Roborock S7 Max Ultra, który nie dość, że jest dostępny w świetnej promocji, to na dodatek [&#8230;]</p>

## Ogniwa słoneczne idą po rekord. Nowa technologia klasycznej fotowoltaiki się nie boi
 - [https://www.chip.pl/2023/06/cienkowarstwowe-ogniwa-sloneczne-wysoka-wydajnosc](https://www.chip.pl/2023/06/cienkowarstwowe-ogniwa-sloneczne-wysoka-wydajnosc)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-06-16 19:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1125" src="https://konto.chip.pl/wp-content/uploads/2023/03/swiatlo-sloneczne.jpg" style="margin-bottom: 10px;" width="1500" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/03/swiatlo-sloneczne.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Ogniwa słoneczne 2D to ultracienkie moduły, dzięki którym możliwa jest produkcja energii z gigantyczną wydajnością w przeliczeniu na gram. To z kolei rodzi szereg potencjalnych zastosowań. Ultracienkie ogniwa słoneczne są bowiem wyjątkowo lekkie i elastyczne. Z tego względu mogłyby być stosowane wszędzie tam, gdzie typowe panele, wykonane na przykład z krzemu bądź perowskitów, nie mogą [&#8230;]</p>

## USB-C to wtyczka, która zmieniła rynek
 - [https://www.chip.pl/2023/06/usb-c-jaki-kabel-wybrac-3mk](https://www.chip.pl/2023/06/usb-c-jaki-kabel-wybrac-3mk)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-06-16 17:30:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1067" src="https://konto.chip.pl/wp-content/uploads/2022/11/3mk-hyper-11.jpg" style="margin-bottom: 10px;" width="1600" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/11/3mk-hyper-11.jpg" style="display: block; margin: 1em auto;" /></p>
<p>USB-C to dla niektórych wtyczka, opcjonalnie gniazdko. A ja powiem Wam, że to rewolucja, z której już za chwilę będziemy korzystać wszyscy. A tylko od nas zależy, czy wykorzystamy ją we właściwy sposób. Bo choć dzisiaj USB-C dosłownie nas otacza, to nie zawsze jesteśmy w stanie wykorzystać pełnię możliwości tego standardu, często wyłącznie z własnej [&#8230;]</p>

## NASA przechodzi do historii. Amerykańska agencja kosmiczna powinna zmienić nazwę
 - [https://www.chip.pl/2023/06/nasa-powinna-zmienic-nazwe-na-spacex](https://www.chip.pl/2023/06/nasa-powinna-zmienic-nazwe-na-spacex)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-06-16 17:00:00+00:00

<img alt="nasa" class="attachment-full size-full wp-post-image" height="1185" src="https://konto.chip.pl/wp-content/uploads/2023/06/nasa.jpeg" style="margin-bottom: 10px;" width="2048" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/06/nasa.jpeg" style="display: block; margin: 1em auto;" /></p>
<p>Mam wrażenie, że wszystko wskazuje na to, że jesteśmy kilka lat od momentu, w którym NASA będzie pojawiała się jedynie w podręcznikach opisujących chwalebne początki podboju kosmosu przez mieszkańców Ziemi. Żeby nie było, były to początki fenomenalne. W drugiej połowie XX wieku wraz z Roskosmosem NASA rozbudzała wyobraźnię miliardów ludzi na całej Ziemi. Najpierw z [&#8230;]</p>

## Możesz już edytować wysłane wiadomości na WhatsAppie. O ile będziesz wystarczająco szybki
 - [https://www.chip.pl/2023/06/whatsapp-edycja-wiadomosci](https://www.chip.pl/2023/06/whatsapp-edycja-wiadomosci)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-06-16 16:30:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1252" src="https://konto.chip.pl/wp-content/uploads/2023/06/whatsapp-1.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/06/whatsapp-1.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Meta postanowiła dodać do komunikatora WhatsApp długo wyczekiwaną funkcję – edycję wysłanych wiadomości. Użytkownicy dopraszali się o to już od dawna i w końcu dostają taką możliwość. Na razie nie wszyscy i nie na każdej platformie, ale to już krok w dobrą stronę. WhatsApp pozwoli na edycję wiadomości Opcja edycji wysłanych wiadomości to bardzo przydatna [&#8230;]</p>

## Samsung w końcu dogania konkurencję. Wszystko, co wiemy o Galaxy Z Fold 5 przed premierą
 - [https://www.chip.pl/2023/06/samsung-galaxy-z-fold-5-specyfikacja-cena-data-premiery-wyglad](https://www.chip.pl/2023/06/samsung-galaxy-z-fold-5-specyfikacja-cena-data-premiery-wyglad)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-06-16 16:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1707" src="https://konto.chip.pl/wp-content/uploads/2022/12/galaxy-z-flip4-fold4-odpornosc-zawias-25-scaled.jpg" style="margin-bottom: 10px;" width="2560" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/12/galaxy-z-flip4-fold4-odpornosc-zawias-25-scaled.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Wśród tegorocznych premier smartfonów nie zabraknie kolejnej, piątej już, generacji składanego Galaxy Z Fold od Samsunga. Premiera zbliża się nieuchronnie, dlatego postanowiliśmy zebrać je w jednym miejscu. Artykuł będzie na bieżąco aktualizowany. Wedle raportów rok 2023 będzie należał do składanych smartfonów. Ich sprzedaż ma pójść mocno w górę, a że na rynku konkurencji tylko przybywa, [&#8230;]</p>

## Tani miernik pola elektromagnetycznego? Równie dobrze możesz kupić różdżkę
 - [https://www.chip.pl/2023/06/tani-miernik-pola-elektromagnetycznego-pomiary-wyniki](https://www.chip.pl/2023/06/tani-miernik-pola-elektromagnetycznego-pomiary-wyniki)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-06-16 15:30:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1200" src="https://konto.chip.pl/wp-content/uploads/2023/01/muidita-pure-pomiary-2.jpg" style="margin-bottom: 10px;" width="1800" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/01/muidita-pure-pomiary-2.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Tanie mierniki pola elektromagnetycznego (PEM) są bardzo popularne nie tylko pośród osób tropiących teorie spiskowe. Tylko czy są cokolwiek warte? Pracownicy Instytutu Łączności sprawdzili ich możliwości i nie mamy dobrych informacji. Po co komu amatorski miernik pola elektromagnetycznego? Tani miernik PEM, w teorii, ma pozwolić na skontrolowanie naszego otoczenia pod kątem bezpieczeństwa. Jeśli natężenie pola [&#8230;]</p>

## Widziałem pierwsze smartfony Tecno, które trafią do Polski i jestem ostrożnie optymistyczny
 - [https://www.chip.pl/2023/06/smartfony-tecno-spark-polska](https://www.chip.pl/2023/06/smartfony-tecno-spark-polska)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-06-16 15:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1536" src="https://konto.chip.pl/wp-content/uploads/2023/06/tecno.jpeg" style="margin-bottom: 10px;" width="2048" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/06/tecno.jpeg" style="display: block; margin: 1em auto;" /></p>
<p>Trzy modele z serii Spark 10 pozycjonowane dla pokolenia Z, jako pierwsze produkty marki Tecno zadebiutują jeszcze w tym miesiącu na polskim rynku. Miałem okazję chwilę się nimi pobawić i mam wrażenie, że szczególnie w segmencie niskobudżetowym mają szansę nieco namieszać. Sam producent zapewnia, że w Polsce chce zostać na dłużej, czego potwierdzeniem ma być [&#8230;]</p>

## Test chłodzenia Asus ROG Ryujin III 360 ARGB
 - [https://www.chip.pl/2023/06/asus-rog-ryujin-iii-360-argb-test-recenzja-opinia](https://www.chip.pl/2023/06/asus-rog-ryujin-iii-360-argb-test-recenzja-opinia)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-06-16 14:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="901" src="https://konto.chip.pl/wp-content/uploads/2023/06/Asus-ROG-Ryujin-III-360-ARGB-25.jpg" style="margin-bottom: 10px;" width="1201" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/06/Asus-ROG-Ryujin-III-360-ARGB-25.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Asus ROG Ryujin III 360 ARGB to już trzecia edycja jednego z najdroższych chłodzeń AiO dostępnych w sklepach. Czy taka konstrukcja oprócz świetnego wyglądu oferuje również znakomitą wydajność? Co otrzymujemy wraz z Asus ROG Ryujin III 360 ARGB? W zestawie znajdziemy śrubki i akcesoria niezbędne do montażu, dwa kable ze złączami ARGB i 4-pin PWM, [&#8230;]</p>

## Polskie perowskity wciąż w powijakach, ale są już na nie pieniądze. Kwota jest ogromna
 - [https://www.chip.pl/2023/06/polskie-perowskity-nowy-inwestor-saule-technologies](https://www.chip.pl/2023/06/polskie-perowskity-nowy-inwestor-saule-technologies)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-06-16 13:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="667" src="https://konto.chip.pl/wp-content/uploads/2023/06/DSC08279a-1-1-1.jpg" style="margin-bottom: 10px;" width="1000" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/06/DSC08279a-1-1-1.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Polski startup fotowoltaiczny zajmujący się opracowywaniem technologii perowskitowej zyskał nowe finansowanie. Firma przekazała informację o nowym inwestorze, który wyłoży na rozwój fotowoltaiki przyszłości niebagatelną kwotę. Spółka DC24 zainwestuje w firmy Saule Technologies i Saule. Udzieli ona pożyczki do kwoty 40 milionów złotych, dzięki czemu obejmie nowo wyemitowane akcje fotowoltaicznego startupu – dowiadujemy się z komunikatu [&#8230;]</p>

## Trudno uwierzyć, że Intel to zrobił. Możesz oficjalnie pożegnać procesory Intela
 - [https://www.chip.pl/2023/06/intel-procesory-core-ultra](https://www.chip.pl/2023/06/intel-procesory-core-ultra)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-06-16 10:30:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1440" src="https://konto.chip.pl/wp-content/uploads/2023/02/Intel-Core-procesory.jpg" style="margin-bottom: 10px;" width="2560" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/02/Intel-Core-procesory.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Intel zdecydował się na śmiały ruch z grupy tych, które albo mogą mu zaszkodzić, albo wręcz przeciwnie, na co zresztą firma zapewne liczy. Dowiedzieliśmy się, że w sklepach nie kupimy już procesorów Core i3, i5, i7 oraz i9. Doskonale znane nam procesory Intela pójdą w odstawkę. W ich miejsce wejdą znacznie bardziej &#8220;przejrzyste&#8221; Core Całe [&#8230;]</p>

## Powstanie dolnośląska Dolina Krzemowa? Intel zapowiada kluczową inwestycję pod Wrocławiem
 - [https://www.chip.pl/2023/06/intel-fabryka-wroclaw](https://www.chip.pl/2023/06/intel-fabryka-wroclaw)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-06-16 09:49:08+00:00

<img alt="Fabryka Intela" class="attachment-full size-full wp-post-image" height="1080" src="https://konto.chip.pl/wp-content/uploads/2023/03/Intel-dominacja-procesory-iGPU-1-2.jpg" style="margin-bottom: 10px;" width="1919" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/03/Intel-dominacja-procesory-iGPU-1-2.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Do stolicy Dolnego Śląska przybył dziś nie byle kto, bo sam Pat Gelsinger. Prezes firmy Intel przywozi ważne wieści, dotyczące jednej z kluczowych części europejskiej infrastruktury koncernu, która powstanie w Polsce. Dzięki niej pracę ma znaleźć co najmniej 2 tys. osób, a z punktu widzenia europejskiej wspólnoty, projekt przyczyni się do znacznego skrócenia i poprawy  [&#8230;]</p>

## Crisis na pewno pójdzie. Najnowszy procesor Intela nie ma nic wspólnego z tym, o czym myślicie
 - [https://www.chip.pl/2023/06/kwantowy-procesor-intela-tunnel-falls](https://www.chip.pl/2023/06/kwantowy-procesor-intela-tunnel-falls)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-06-16 09:30:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1080" src="https://konto.chip.pl/wp-content/uploads/2023/06/Intel-Tunnel-Falls-procesor-kwantowy-3.jpg" style="margin-bottom: 10px;" width="1620" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/06/Intel-Tunnel-Falls-procesor-kwantowy-3.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Z takim procesorem każda gra mogłaby radzić sobie z obliczeniami związanymi z najbardziej zaawansowanymi systemami, a wszelkie obciążenia byłyby dla niego pestką. Najnowszy procesor Intela to nie byle co, a coś, co porzuca zero-jedynkowe podejście na rzecz czegoś znacznie bardziej przyszłościowego. Istny Quantum Core, czyli dlaczego Intel Tunnel Falls to przykład procesora przyszłości W ramach [&#8230;]</p>

## Chiny pobiły świat. Latanie będzie szybsze, kosmos jeszcze bliższy, a świat groźniejszy
 - [https://www.chip.pl/2023/06/chiny-lotnictwo-tunel-jf22](https://www.chip.pl/2023/06/chiny-lotnictwo-tunel-jf22)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-06-16 09:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1080" src="https://konto.chip.pl/wp-content/uploads/2023/06/Lotnictwo-Chiny-tunel-aerodynamiczny-3.jpg" style="margin-bottom: 10px;" width="1824" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/06/Lotnictwo-Chiny-tunel-aerodynamiczny-3.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Rozwój lotnictwa trwa i dąży do tego, aby latanie było szybsze, tańsze, a przede wszystkim otwierało nowe możliwości i szkodziło środowisku w mniejszym stopniu. Ostatnio to Chiny dokonały znaczącego przełomu w dążeniu do rozwijania technologii lotniczej i kosmicznej w tym zakresie. Nowy tunel aerodynamiczny ma potencjał odmienić lotnictwo. Rozwinie samoloty i rakiety kosmiczne&#8230; ale też [&#8230;]</p>

## Europejska premiera telewizorów Panasonic &#8211; kilka obiecujących nowości i cukierków za szybką
 - [https://www.chip.pl/2023/06/telewizory-panasonic-2023-europa](https://www.chip.pl/2023/06/telewizory-panasonic-2023-europa)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-06-16 08:03:15+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1280" src="https://konto.chip.pl/wp-content/uploads/2023/06/panasonic-premiera-berlin-2023-01.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/06/panasonic-premiera-berlin-2023-01.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Czego przeciętny konsument oczekuje dziś od nowego telewizora? Wydaje mi się, że aby to lepiej zrozumieć, trzeba najpierw wyjść ze schematu patrzenia na potrzeby mainstreamowego rynku przez pryzmat technologicznego geeka. Uczestnicząc w europejskiej premierze telewizorów Panasonic na 2023 rok miałem okazję przekonać się, w jakim stopniu ambitna wizja producenta pokrywa się z tak przyjętym założeniem. [&#8230;]</p>

## Zagadkowa anomalia w Układzie Słonecznym. Na jego obrzeżach czai się coś nieznanego
 - [https://www.chip.pl/2023/06/anomalia-uklad-sloneczny-dziewiata-planeta](https://www.chip.pl/2023/06/anomalia-uklad-sloneczny-dziewiata-planeta)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-06-16 07:08:41+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1280" src="https://konto.chip.pl/wp-content/uploads/2023/06/dziewiata-planeta.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/06/dziewiata-planeta.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Jeszcze w 2006 roku oficjalnie mówiło się, że Układ Słoneczny składa się z dziewięciu planet. Do zmiany doszło po tym, jak Pluton został zdegradowany do miana planety karłowatej, lecz nie musi to oznaczać, że liczba pełnoprawnych planet jest teraz zgodna z rzeczywistością. Wszystko za sprawą hipotetycznej dziewiątej planety. Obiekt ten miałby się ukrywać daleko poza [&#8230;]</p>

## Rosja twierdzi, że ma najlepsze czołgi na świecie. Wojna poddała dumę Putina próbie
 - [https://www.chip.pl/2023/06/rosja-najlepsze-czolgi-t-90m-ukraina](https://www.chip.pl/2023/06/rosja-najlepsze-czolgi-t-90m-ukraina)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-06-16 03:57:28+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1069" src="https://konto.chip.pl/wp-content/uploads/2022/05/Opisujemy-rosyjski-czolg-T-90-ktory-w-najlepszej-wersji-T-90M-Proryw-3-ulegl-Ukrainie-2.jpg" style="margin-bottom: 10px;" width="1600" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/05/Opisujemy-rosyjski-czolg-T-90-ktory-w-najlepszej-wersji-T-90M-Proryw-3-ulegl-Ukrainie-2.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Rosja, a dokładniej mówiąc jej głowa, czyli Putin, od zawsze powtarzała, że to jej rodzime czołgi nowej generacji są najlepsze. Tyle tylko, że trwający właśnie konflikt, o który Rosja sama się prosiła, poddaje dumę kraju w wątpliwość wraz z rosnącą liczbą zniszczonych egzemplarzy tychże &#8220;rozwiniętych T-72&#8221;. Rosyjskie czołgi T-90M nie są jednak takie najlepsze? Liczba [&#8230;]</p>

