# Source:Wydarzenia Interia - Polska, URL:https://wydarzenia.interia.pl/polska/feed, language:pl-PL

## Mentzen poza podium. Kilka twarzy powróciło na TikToka po długiej przerwie
 - [https://wydarzenia.interia.pl/raport-tiktok-polityczny/news-mentzen-poza-podium-kilka-twarzy-powrocilo-na-tiktoka-po-dlu,nId,6845364](https://wydarzenia.interia.pl/raport-tiktok-polityczny/news-mentzen-poza-podium-kilka-twarzy-powrocilo-na-tiktoka-po-dlu,nId,6845364)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-06-16 13:33:55+00:00

<p><a href="https://wydarzenia.interia.pl/raport-tiktok-polityczny/news-mentzen-poza-podium-kilka-twarzy-powrocilo-na-tiktoka-po-dlu,nId,6845364"><img align="left" alt="Mentzen poza podium. Kilka twarzy powróciło na TikToka po długiej przerwie" src="https://i.iplsc.com/mentzen-poza-podium-kilka-twarzy-powrocilo-na-tiktoka-po-dlu/000HADDI2PFXJSFP-C321.jpg" /></a>Janusz Korwin-Mikke &quot;zmasakrował&quot; konkurencję, publikując najpopularniejszą rolkę na TikToku w mijającym tygodniu. W najnowszym zestawieniu zabrakło regularnych liderów - Sławomira Mentzena i Donalda Tuska. Ostatni pojawił się jednak w rolce Platformy Obywatelskiej, która zgarnęła całą pulę wśród partii politycznych. Pojawili się także po długiej przerwie Wanda Nowicka oraz Młoda Polska. Zapraszamy na najnowszy przegląd politycznego TikToka w Interii.</p><br clear="all" />

## Po tekście Interii skoczyli sobie do gardeł. Znamy kulisy
 - [https://wydarzenia.interia.pl/kraj/news-po-tekscie-interii-skoczyli-sobie-do-gardel-znamy-kulisy,nId,6844943](https://wydarzenia.interia.pl/kraj/news-po-tekscie-interii-skoczyli-sobie-do-gardel-znamy-kulisy,nId,6844943)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-06-16 09:03:38+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-po-tekscie-interii-skoczyli-sobie-do-gardel-znamy-kulisy,nId,6844943"><img align="left" alt="Po tekście Interii skoczyli sobie do gardeł. Znamy kulisy" src="https://i.iplsc.com/po-tekscie-interii-skoczyli-sobie-do-gardel-znamy-kulisy/000HABMRAS7I3V7A-C321.jpg" /></a>Sztab wyborczy PiS ma czas do 24 czerwca na udowodnienie swojej wartości - usłyszała Interia. To wtedy odbędzie się duża konwencja w Łodzi, która ma nadać nową dynamikę kampanii. Nie oznacza to jednak, że strategia wyborcza formacji rządzącej jest pod pełną kontrolą, czego wyraz kilka dni temu dali byli i obecni sztabowcy PiS. </p><br clear="all" />

## Chiny próbowały zablokować wystawę w Polsce. Mamy reakcję MSZ
 - [https://wydarzenia.interia.pl/kraj/news-chiny-probowaly-zablokowac-wystawe-w-polsce-mamy-reakcje-msz,nId,6844992](https://wydarzenia.interia.pl/kraj/news-chiny-probowaly-zablokowac-wystawe-w-polsce-mamy-reakcje-msz,nId,6844992)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-06-16 09:01:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-chiny-probowaly-zablokowac-wystawe-w-polsce-mamy-reakcje-msz,nId,6844992"><img align="left" alt="Chiny próbowały zablokować wystawę w Polsce. Mamy reakcję MSZ" src="https://i.iplsc.com/chiny-probowaly-zablokowac-wystawe-w-polsce-mamy-reakcje-msz/000HABR845CAGGW8-C321.jpg" /></a>Ambasada Chin w Polsce interweniowała w Ministerstwie Spraw Zagranicznych w sprawie wystawy chińskiego dysydenta Badiucao w Centrum Sztuki Współczesnej Zamek Ujazdowski w Warszawie - dowiedziała się Interia. W zeszłym tygodniu wysoki rangą chiński dyplomata pojawił się bez zapowiedzi w galerii sztuki, domagając się odwołania wystawy. </p><br clear="all" />

## "Co się śmiejesz człowieku?". Spięcie Kowalskiego i Rutnickiego w Sejmie
 - [https://wydarzenia.interia.pl/kraj/news-co-sie-smiejesz-czlowieku-spiecie-kowalskiego-i-rutnickiego-,nId,6844996](https://wydarzenia.interia.pl/kraj/news-co-sie-smiejesz-czlowieku-spiecie-kowalskiego-i-rutnickiego-,nId,6844996)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-06-16 09:00:40+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-co-sie-smiejesz-czlowieku-spiecie-kowalskiego-i-rutnickiego-,nId,6844996"><img align="left" alt="&quot;Co się śmiejesz człowieku?&quot;. Spięcie Kowalskiego i Rutnickiego w Sejmie" src="https://i.iplsc.com/co-sie-smiejesz-czlowieku-spiecie-kowalskiego-i-rutnickiego/000HABWA4SNVGO00-C321.jpg" /></a>Polityk Suwerennej Polski Janusz Kowalski podczas posiedzenia Sejmu oskarżył opozycję, że nie reaguje na problem zablokowanych dla Polski środków z KPO. Na jego wystąpienie dobitnie odpowiedział Jakub Rutnicki z Koalicji Obywatelskiej. Wymiana zdań zakończyła się krzykami z sejmowej mównicy. - Co się śmiejesz człowieku? - grzmiał Kowalski. </p><br clear="all" />

## Lider Nowoczesnej Adam Szłapka potrącił rowerzystkę. Teraz się tłumaczy
 - [https://wydarzenia.interia.pl/kraj/news-lider-nowoczesnej-adam-szlapka-potracil-rowerzystke-teraz-si,nId,6844975](https://wydarzenia.interia.pl/kraj/news-lider-nowoczesnej-adam-szlapka-potracil-rowerzystke-teraz-si,nId,6844975)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-06-16 08:29:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-lider-nowoczesnej-adam-szlapka-potracil-rowerzystke-teraz-si,nId,6844975"><img align="left" alt="Lider Nowoczesnej Adam Szłapka potrącił rowerzystkę. Teraz się tłumaczy" src="https://i.iplsc.com/lider-nowoczesnej-adam-szlapka-potracil-rowerzystke-teraz-si/000HABR25MRYIOWK-C321.jpg" /></a>Lider Nowoczesnej i poseł Koalicji Obywatelskiej Adam Szłapka potrącił samochodem 16-letnią rowerzystkę. Jak dowiedziała się Interia, do zdarzenia doszło na Saskiej Kępie w Warszawie. 16-latka doznała licznych obrażeń m.in. urazu głowy i złamania kości nosowych. W momencie zdarzenia polityk był trzeźwy. - Jestem w stałym kontakcie z rodziną - przekazał Interii poseł Szłapka. Sprawa trafiła do Prokuratury Rejonowej Warszawa - Praga Południe, która może wnioskować o uchylenie parlamentarzyście immunitetu.</p><br clear="all" />

## Lider Nowoczesnej Adam Szłapka potrącił samochodem rowerzystkę
 - [https://wydarzenia.interia.pl/kraj/news-lider-nowoczesnej-adam-szlapka-potracil-samochodem-rowerzyst,nId,6844975](https://wydarzenia.interia.pl/kraj/news-lider-nowoczesnej-adam-szlapka-potracil-samochodem-rowerzyst,nId,6844975)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-06-16 08:29:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-lider-nowoczesnej-adam-szlapka-potracil-samochodem-rowerzyst,nId,6844975"><img align="left" alt="Lider Nowoczesnej Adam Szłapka potrącił samochodem rowerzystkę" src="https://i.iplsc.com/lider-nowoczesnej-adam-szlapka-potracil-samochodem-rowerzyst/000HABR25MRYIOWK-C321.jpg" /></a>Lider Nowoczesnej i poseł Koalicji Obywatelskiej Adam Szłapka potrącił samochodem 16-letnią rowerzystkę. Jak dowiedziała się Interia, do zdarzenia doszło na Saskiej Kępie w Warszawie. 16-latka doznała licznych obrażeń m.in. urazu głowy i złamania kości nosowych. W momencie zdarzenia polityk był trzeźwy. Sprawa trafiła do Prokuratury Rejonowej Warszawa - Praga Południe, która może wnioskować o uchylenie parlamentarzyście immunitetu.</p><br clear="all" />

## Zabójstwo sprzed lat na Kaszubach. Niespodziewany zwrot akcji
 - [https://wydarzenia.interia.pl/pomorskie/news-zabojstwo-sprzed-lat-na-kaszubach-niespodziewany-zwrot-akcji,nId,6844959](https://wydarzenia.interia.pl/pomorskie/news-zabojstwo-sprzed-lat-na-kaszubach-niespodziewany-zwrot-akcji,nId,6844959)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-06-16 07:39:00+00:00

<p><a href="https://wydarzenia.interia.pl/pomorskie/news-zabojstwo-sprzed-lat-na-kaszubach-niespodziewany-zwrot-akcji,nId,6844959"><img align="left" alt="Zabójstwo sprzed lat na Kaszubach. Niespodziewany zwrot akcji" src="https://i.iplsc.com/zabojstwo-sprzed-lat-na-kaszubach-niespodziewany-zwrot-akcji/000HABGYG1QMWPV8-C321.jpg" /></a>Policjanci zatrzymali poszukiwanego listem gończym 35-latka. Mężczyzna ukrywał się przed wymiarem sprawiedliwości za zabójstwo, do którego doszło na Kaszubach w 2004 r. Oskarżony już raz był zatrzymany przez policję. Po zwolnieniu z aresztu ukrywał się przed wymiarem sprawiedliwości. W trakcie zatrzymania &quot;nie stawiał oporu i był zaskoczony&quot;.</p><br clear="all" />

## Prezydencka nowelizacja ponownie w Sejmie. "Pałka zamiast siekiery"
 - [https://wydarzenia.interia.pl/kraj/news-prezydencka-nowelizacja-ponownie-w-sejmie-palka-zamiast-siek,nId,6844954](https://wydarzenia.interia.pl/kraj/news-prezydencka-nowelizacja-ponownie-w-sejmie-palka-zamiast-siek,nId,6844954)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-06-16 07:10:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-prezydencka-nowelizacja-ponownie-w-sejmie-palka-zamiast-siek,nId,6844954"><img align="left" alt="Prezydencka nowelizacja ponownie w Sejmie. &quot;Pałka zamiast siekiery&quot;" src="https://i.iplsc.com/prezydencka-nowelizacja-ponownie-w-sejmie-palka-zamiast-siek/000G86IHUI0IKD5K-C321.jpg" /></a>- Ta nowelizacja to zaproponowanie pałki zamiast siekiery i uniemożliwienie Donaldowi Tuskowi sprawowania urzędu premiera - stwierdził poseł Koalicji Obywatelskiej Bartłomiej Sienkiewicz, oceniając zaproponowane przez prezydenta zmiany w ustawie o powołaniu komisji ds. badania rosyjskich wpływów. Zdaniem posła PiS Piotra Kalety intencją rządzących jest natomiast &quot;oczyszczenie Polski ze złogów agentów, zdrajców i tych, którzy byli dla naszej państwowości nieprzyjaźni&quot;.</p><br clear="all" />

## Burze pyłowe, trąby powietrzne i upały. Groźne zjawiska coraz częstsze w Polsce
 - [https://wydarzenia.interia.pl/tylko-w-interii/news-burze-pylowe-traby-powietrzne-i-upaly-grozne-zjawiska-coraz-,nId,6843109](https://wydarzenia.interia.pl/tylko-w-interii/news-burze-pylowe-traby-powietrzne-i-upaly-grozne-zjawiska-coraz-,nId,6843109)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-06-16 05:56:00+00:00

<p><a href="https://wydarzenia.interia.pl/tylko-w-interii/news-burze-pylowe-traby-powietrzne-i-upaly-grozne-zjawiska-coraz-,nId,6843109"><img align="left" alt="Burze pyłowe, trąby powietrzne i upały. Groźne zjawiska coraz częstsze w Polsce" src="https://i.iplsc.com/burze-pylowe-traby-powietrzne-i-upaly-grozne-zjawiska-coraz/000HA7XWPQHAXVLD-C321.jpg" /></a>Ekstremalne zjawiska atmosferyczne w Polsce nasilają się z roku na rok. Upały, burze, trąby powietrzne, noce tropikalne czy huragany, ale też zjawiska nowe dla naszego kraju, jak niebezpieczne i widziane nawet z kosmosu burze pyłowe. Lista zagrożeń jest długa, a prognozy na przyszłość mało optymistyczne. Ale jest coś, co możemy - a wręcz powinniśmy - z tym zrobić. O zmianach klimatu i nowych wyzwaniach mówi w rozmowie z Interią rzecznik IMGW-PIB Grzegorz Walijewski. </p><br clear="all" />

