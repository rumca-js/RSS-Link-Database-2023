# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## Unprovoked Arizona bear mauls, kills man drinking his morning coffee: police
 - [https://www.foxnews.com/us/unprovoked-arizona-bear-mauls-kills-man-drinking-morning-coffee-police](https://www.foxnews.com/us/unprovoked-arizona-bear-mauls-kills-man-drinking-morning-coffee-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 19:10:36+00:00

Tucson, Arizona, resident Steven Jackson was mauled to death by a black bear in a random, unprovoked attack on his property, police say. A neighbor eventually shot the animal dead.

## 2 suspects in 2018 Vermont murder-for-hire plot to stand trial next year
 - [https://www.foxnews.com/us/2-suspects-2018-vermont-murder-hire-plot-stand-trial-next-year](https://www.foxnews.com/us/2-suspects-2018-vermont-murder-hire-plot-stand-trial-next-year)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 19:07:22+00:00

Two men charged in connection with the 2018 abduction and murder of Danville, Vermont, resident Gregory Davis will stand trial next fall.

## Judge blocks Indiana ban on hormone treatments, puberty blockers for minors
 - [https://www.foxnews.com/politics/judge-blocks-indiana-ban-hormone-treatments-puberty-blockers-minors](https://www.foxnews.com/politics/judge-blocks-indiana-ban-hormone-treatments-puberty-blockers-minors)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 19:05:08+00:00

U.S. District Court Judge James Patrick Hanlon on Friday struck down a significant portion of an Indiana law banning transgender procedures for minors.

## Colon cancer cases surge among younger Americans, hits home for one Fox News correspondent
 - [https://www.foxnews.com/media/colon-cancer-cases-surge-younger-americans-hits-home-fox-news-correspondent](https://www.foxnews.com/media/colon-cancer-cases-surge-younger-americans-hits-home-fox-news-correspondent)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 18:44:06+00:00

Colon cancer is being discovered in patients younger than the typical testing threshold of 50 years old, studies are showing, as Fox News reported on Friday.

## FDA approves next round of COVID-19 vaccines targeting omicron variant
 - [https://www.foxnews.com/us/fda-approves-next-round-covid-19-vaccines-targeting-omicron-variant](https://www.foxnews.com/us/fda-approves-next-round-covid-19-vaccines-targeting-omicron-variant)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 18:39:57+00:00

The FDA announced Friday that the upcoming round of COVID-19 vaccines will specifically target one of the latest versions of the coronavirus, the omicron variant.

## Trial delayed for Oath Keepers lawyer as mental competency treatment is recommended
 - [https://www.foxnews.com/us/trial-delayed-oath-keepers-lawyer-mental-competency-treatment-recommended](https://www.foxnews.com/us/trial-delayed-oath-keepers-lawyer-mental-competency-treatment-recommended)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 18:38:36+00:00

A judge granted a delay in the trial of a lawyer associated with the far-right Oath Keepers extremist group, to allow her to receive treatment to restore her mental competency.

## Gay Milwaukee County supervisor claims he was accosted, punched in face at local mall
 - [https://www.foxnews.com/politics/gay-milwaukee-county-supervisor-claims-accosted-punched-face-local-mall](https://www.foxnews.com/politics/gay-milwaukee-county-supervisor-claims-accosted-punched-face-local-mall)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 18:36:38+00:00

Milwaukee County Supervisor Peter Burgelis claims he was called a homophobic slur before being punched in the face at a Wauwatosa mall.

## DOJ files motion to bar Trump from accessing classified documents without lawyer present
 - [https://www.foxnews.com/politics/doj-motion-bar-trump-accessing-classified-documents-without-lawyer-present](https://www.foxnews.com/politics/doj-motion-bar-trump-accessing-classified-documents-without-lawyer-present)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 18:35:07+00:00

The DOJ filed a protective order Friday to prevent former President Donald Trump from releasing classified documents amid his Mar-a-Lago documents indictment, The Hill reported.

## Kansas man jailed for walking into hospital, raping 3 women
 - [https://www.foxnews.com/us/kansas-man-jailed-walking-hospital-raping-3-women](https://www.foxnews.com/us/kansas-man-jailed-walking-hospital-raping-3-women)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 18:22:29+00:00

A 28-year-old Wichita, Kansas man, whose identity has yet to be released, has been arrested for raping three women at Ascension Via Christi St. Francis.

## Serbia bucks US, EU; opens proceedings against arrested Kosovo police officers
 - [https://www.foxnews.com/world/serbia-bucks-us-eu-opens-proceedings-arrested-kosovo-police-officers](https://www.foxnews.com/world/serbia-bucks-us-eu-opens-proceedings-arrested-kosovo-police-officers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 18:21:16+00:00

Serbian prosecutors on Friday began legal proceedings against three Kosovar police officers arrested near the two nations&apos; border, leaving pleas by the international community unheeded.

## Florida squatter arrested after homeowner returns from trip abroad
 - [https://www.foxnews.com/us/florida-squatter-arrested-homeowner-trip-abroad](https://www.foxnews.com/us/florida-squatter-arrested-homeowner-trip-abroad)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 18:16:13+00:00

A Florida homeowner caught a squatter in his home after being away for months, resulting in an arrest.

## The Telo is a teeny tiny electric truck
 - [https://www.foxnews.com/auto/telo-teeny-tiny-electric-truck](https://www.foxnews.com/auto/telo-teeny-tiny-electric-truck)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 18:10:06+00:00

California electric vehicle startup Telo has unveiled a minicompact pickup that has 500 horsepower and can carry items that are 8 feet long.

## Sarah Ferguson says she 'copied' Princess Diana after joining the royal family: 'I mirrored her'
 - [https://www.foxnews.com/entertainment/sarah-ferguson-copied-princess-diana-after-joining-royal-family-mirrored-her](https://www.foxnews.com/entertainment/sarah-ferguson-copied-princess-diana-after-joining-royal-family-mirrored-her)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 18:07:39+00:00

Sarah Ferguson and Princess Diana were childhood friends before Ferguson married Prince Andrew and Diana married Prince Charles. Both marriages ended in divorce.

## Mother sentenced to 4 years in prison for abandoning newborn by South Carolina highway in 2008
 - [https://www.foxnews.com/us/mother-sentenced-4-years-prison-abandoning-newborn-south-carolina-highway-2008](https://www.foxnews.com/us/mother-sentenced-4-years-prison-abandoning-newborn-south-carolina-highway-2008)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 18:02:35+00:00

Jennifer Sahr has been sentenced to four years in prison for the alleged abandonment of her infant, known as &quot;Baby Boy Horry,&quot; beside a South Carolina highway in 2008.

## Cargo plane crash off Hawaii caused by engine misidentification and lack of power
 - [https://www.foxnews.com/us/cargo-plane-crash-hawaii-caused-engine-misidentification-lack-power](https://www.foxnews.com/us/cargo-plane-crash-hawaii-caused-engine-misidentification-lack-power)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 18:01:02+00:00

A cargo plane that crashed into the ocean off Hawaii in 2021 due to the pilots misidentifying the failing engine and not having enough power to stay airborne.

## IN OR OUT? New poll reveals where Republican voters stand in support of Trump after second indictment
 - [https://www.foxnews.com/politics/poll-reveals-republican-voters-stand-support-trump-second-indictment](https://www.foxnews.com/politics/poll-reveals-republican-voters-stand-support-trump-second-indictment)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 17:59:20+00:00

A new Marist Poll found that the majority of Republicans are supporting former President Donald Trump in his 2024 campaign, despite him being under federal investigation.

## Utah demolition crew saves abandoned litter of baby raccoons
 - [https://www.foxnews.com/us/utah-demolition-crew-saves-abandoned-litter-baby-raccoons](https://www.foxnews.com/us/utah-demolition-crew-saves-abandoned-litter-baby-raccoons)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 17:58:22+00:00

A group of abandoned raccoon cubs was discovered at a construction site in northern Utah, prompting the intervention of a construction crew and local authorities.

## Feds indict 3 central Pennsylvania officers for nearly 2 dozen brutality incidents in 3 years
 - [https://www.foxnews.com/us/feds-indict-3-central-pennsylvania-officers-nearly-2-dozen-brutality-incidents-3-years](https://www.foxnews.com/us/feds-indict-3-central-pennsylvania-officers-nearly-2-dozen-brutality-incidents-3-years)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 17:56:40+00:00

Three Mount Carmel, Pennsylvania, police officers are accused in a federal indictment of using excessive force in 22 arrests between 2018 and 2021.

## Maine man indicted, accused of killing parents and 2 others
 - [https://www.foxnews.com/us/maine-man-indicted-accused-killing-parents-2-others](https://www.foxnews.com/us/maine-man-indicted-accused-killing-parents-2-others)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 17:54:53+00:00

Joseph Eaton has been indicted for allegedly killing his parents and two family friends in Bowdoin, Maine; he will face additional charges for firing at cars while fleeing the scene.

## Paul McCartney captures The Beatles' 'innocence,' challenges amid rise to fame in never-before-seen photos
 - [https://www.foxnews.com/entertainment/paul-mccartney-captures-beatles-rise-fame-photos](https://www.foxnews.com/entertainment/paul-mccartney-captures-beatles-rise-fame-photos)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 17:42:45+00:00

Paul McCartney, John Lennon, Ringo Starr and George Harrison are captured in never-before-seen photos during The Beatles&apos; rise to stardom in the 1960s.

## Biden bizarrely ends Connecticut speech with 'God Save the Queen,' sparking uproar: 'Truly incapacitated'
 - [https://www.foxnews.com/media/biden-bizarrely-ends-connecticut-speech-god-save-queen-sparking-uproar-truly-incapacitated](https://www.foxnews.com/media/biden-bizarrely-ends-connecticut-speech-god-save-queen-sparking-uproar-truly-incapacitated)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 17:41:22+00:00

Observers cited Friday how President Biden inexplicably stated &apos;God Save the Queen&apos; as he closed his remarks at a gun control reform event in West Hartford, Connecticut.

## Nike vows to 'continue to support' Grizzlies star Ja Morant despite latest suspension
 - [https://www.foxnews.com/sports/nike-plans-to-continue-to-support-grizzlies-star-ja-morant-despite-latest-suspension](https://www.foxnews.com/sports/nike-plans-to-continue-to-support-grizzlies-star-ja-morant-despite-latest-suspension)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 17:37:04+00:00

Memphis Grizzlies guard Ja Morant has had a professional relationship with Nike for a little over four years and has a signature shoe with the brand.

## Jeffrey Epstein's last girlfriend spotted on Fifth Avenue in New York City
 - [https://www.foxnews.com/us/jeffrey-epstein-last-girlfriend-spotted-fifth-avenue-new-york-city](https://www.foxnews.com/us/jeffrey-epstein-last-girlfriend-spotted-fifth-avenue-new-york-city)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 17:36:48+00:00

The woman who was dating Jeffrey Epstein when he was found hanged in a jail cell in 2019 was spotted Thursday strolling down Fifth Avenue in New York City.

## Maine lobstermen catch big court victory against Biden administration's 'egregious' regulations
 - [https://www.foxnews.com/politics/maine-lobstermen-catch-big-court-victory-against-biden-administrations-egregious-regulations](https://www.foxnews.com/politics/maine-lobstermen-catch-big-court-victory-against-biden-administrations-egregious-regulations)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 17:25:46+00:00

The Maine Lobstermen&apos;s Association won its case against the Biden administration over regulations that threatened to put its memberrs out of business.

## Hunter Biden deposed in Arkansas child support case over 4-year-old daughter
 - [https://www.foxnews.com/politics/hunter-biden-deposed-in-arkansas-child-support-case-over-4-year-old-daughter](https://www.foxnews.com/politics/hunter-biden-deposed-in-arkansas-child-support-case-over-4-year-old-daughter)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 17:24:33+00:00

Hunter Biden showed up at a Little Rock, Arkansas, court Friday morning, attending a deposition about his paternity and child support battle with ex-stripper Lunden Roberts.

## Elizabeth Hurley stars in erotic thriller written and directed by her son, 21
 - [https://www.foxnews.com/entertainment/elizabeth-hurley-stars-erotic-thriller-written-directed-by-son](https://www.foxnews.com/entertainment/elizabeth-hurley-stars-erotic-thriller-written-directed-by-son)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 17:10:25+00:00

Elizabeth Hurley&apos;s latest film is notable not only because it&apos;s an erotic movie full of sex scenes and at least mild nudity. It&apos;s also written and directed by her son.

## Amid fentanyl crisis, Biden says Mexican president is asking US to stop sending guns
 - [https://www.foxnews.com/politics/amid-fentanyl-crisis-biden-says-mexican-president-asking-us-stop-sending-guns](https://www.foxnews.com/politics/amid-fentanyl-crisis-biden-says-mexican-president-asking-us-stop-sending-guns)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 17:10:03+00:00

President Biden on Friday said that Mexican President Andrés Manuel López Obrador has urged him to stop the U.S. from sending guns into Mexico amid talks about fentanyl.

## Officer returning to force 3 years after horrific crash: 'You never think it's going to be you'
 - [https://www.foxnews.com/media/officer-returning-force-years-horrific-crash-never-think-going](https://www.foxnews.com/media/officer-returning-force-years-horrific-crash-never-think-going)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 17:00:27+00:00

Fort Worth, Texas police officer Matt Brazeal detailed the nearly devastating accident where a stolen vehicle struck and dragged him over 100 feet.

## Jayland Walker's family targets city of Akron, police department in excessive force suit
 - [https://www.foxnews.com/us/jayland-walkers-family-targets-city-akron-police-department-excessive-force-suit](https://www.foxnews.com/us/jayland-walkers-family-targets-city-akron-police-department-excessive-force-suit)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 16:49:34+00:00

A lawsuit by Jayland Walker&apos;s family accuses the eight Akron, Ohio, police officers who shot him of excessive force and participating in a &quot;culture of violence and racism.&quot;

## 'Oh s---t': Texas troopers make shocking discoveries in illegal immigrant's pickup truck
 - [https://www.foxnews.com/politics/oh-s-t-texas-troopers-make-shocking-discoveries-illegal-immigrants-pickup-truck](https://www.foxnews.com/politics/oh-s-t-texas-troopers-make-shocking-discoveries-illegal-immigrants-pickup-truck)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 16:47:29+00:00

Texas troopers found multiple people, along with a gun and cocaine, in a pickup truck they pulled over on US-90 in Texas this week -- with migrants stuffed in the bed.

## Florida man sentenced to 4 years, 9 months for attacking officer at US Capitol insurrection
 - [https://www.foxnews.com/us/florida-man-sentenced-4-years-9-months-attacking-officer-us-capitol-insurrection](https://www.foxnews.com/us/florida-man-sentenced-4-years-9-months-attacking-officer-us-capitol-insurrection)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 16:43:34+00:00

On Friday, a man from Florida was sentenced to four years and nine months in federal prison for his involvement in the storming of the U.S. Capitol during Jan. 6 riot.

## Chicago boy, 7, drowns after playing in Lake Michigan under 'hazardous' conditions
 - [https://www.foxnews.com/us/chicago-boy-7-drowns-playing-lake-michigan-hazardous-conditions](https://www.foxnews.com/us/chicago-boy-7-drowns-playing-lake-michigan-hazardous-conditions)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 16:42:01+00:00

A 7-year-old Chicago boy is reported to have drowned in Lake Michigan after being swept away in a powerful current along the Porter County, Indiana shoreline.

## Chicago sergeant fired after woman handcuffed naked during no-knock raid at wrong address
 - [https://www.foxnews.com/us/chicago-sergeant-fired-woman-handcuffed-naked-no-knock-raid-wrong-address](https://www.foxnews.com/us/chicago-sergeant-fired-woman-handcuffed-naked-no-knock-raid-wrong-address)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 16:40:12+00:00

Sgt. Alex Wolinski of Chicago has been fired over his role in a botched 2019 raid, in which a woman residing at an incorrect address was handcuffed while naked.

## New Hampshire appeals dismissal of banner-hanging white nationalists' trespassing charges
 - [https://www.foxnews.com/us/new-hampshire-appeals-dismissal-banner-hanging-white-nationalists-trespassing-charges](https://www.foxnews.com/us/new-hampshire-appeals-dismissal-banner-hanging-white-nationalists-trespassing-charges)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 16:38:55+00:00

The New Hampshire Department of Justice has appealed a judge&apos;s ruling that dismissed trespassing charges against neo-Nazi group NSC-131.

## Trump's GOP opponents test out different responses to his indictment as they jockey for position behind him
 - [https://www.foxnews.com/politics/trumps-gop-opponents-test-out-different-responses-to-his-indictment-they-jockey-position-behind-him](https://www.foxnews.com/politics/trumps-gop-opponents-test-out-different-responses-to-his-indictment-they-jockey-position-behind-him)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 16:38:30+00:00

Republican contenders looking to take the White House have stumbled in their response to former President Trump&apos;s arrest and indictment of 37 federal counts.

## Nikola Jokic’s wife hit with beer can during Nuggets' championship parade
 - [https://www.foxnews.com/sports/nikola-jokics-wife-hit-with-beer-can-at-nuggets-championship-parade](https://www.foxnews.com/sports/nikola-jokics-wife-hit-with-beer-can-at-nuggets-championship-parade)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 16:36:56+00:00

Nikola Jokic’s wife Natalija&apos;s parade experience was not quite as enjoyable as she likely had hoped. At one point during the festivities, she got hit by a beer can.

## Former death row inmate freed after pleading guilty in boy's death
 - [https://www.foxnews.com/us/former-death-row-inmate-freed-pleading-guilty-boys-death](https://www.foxnews.com/us/former-death-row-inmate-freed-pleading-guilty-boys-death)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 16:22:01+00:00

An Ohio man who spent more than 15 years on death row in the death of a 3-year-old in 2006 has been set free after a coroner changed the boy&apos;s cause of death.

## Dem DA's staffer who praised Louis Farrakhan placed on leave after antisemitic remarks uncovered
 - [https://www.foxnews.com/media/dem-das-staffer-praised-louis-farrakhan-placed-leave-antisemitic-remarks-uncovered](https://www.foxnews.com/media/dem-das-staffer-praised-louis-farrakhan-placed-leave-antisemitic-remarks-uncovered)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 16:18:39+00:00

An official in the Suffolk County District Attorney&apos;s office was placed on leave following revelations that he made antisemitic comments in a 2016 podcast interview.

## DC shooting leaves pregnant woman dead, man wounded as manhunt on for gunmen: police
 - [https://www.foxnews.com/us/dc-shooting-pregnant-woman-dead-man-wounded-manhunt-gunmen-police](https://www.foxnews.com/us/dc-shooting-pregnant-woman-dead-man-wounded-manhunt-gunmen-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 16:15:42+00:00

A pregnant woman gave birth before dying from her injuries after being shot while in a vehicle, Washington, D.C., police said

## Swiss cyclist, 26, dies after crashing, falling into ravine during race: 'We are devastated'
 - [https://www.foxnews.com/sports/swiss-cyclist-26-dies-after-crashing-falling-into-ravine-during-race-we-are-devastated](https://www.foxnews.com/sports/swiss-cyclist-26-dies-after-crashing-falling-into-ravine-during-race-we-are-devastated)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 16:08:33+00:00

Swiss cyclist Gino Mäder, 26, died Friday after he succumbed to injuries he sustained in a crash during stage 5 of the Tour de Suisse Thursday, officials said.

## Mali's top diplomat demands UN peacekeepers leave the country after more than 10 years
 - [https://www.foxnews.com/world/malis-top-diplomat-demands-un-peacekeepers-leave-country-more-10-years](https://www.foxnews.com/world/malis-top-diplomat-demands-un-peacekeepers-leave-country-more-10-years)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 16:04:19+00:00

Mali&apos;s Foreign Minister Abdoulaye Diop demanded the immediate departure of UN peacekeepers, stating they had not fulfilled their mission and had created mistrust among the population.

## Environmental activist shot to death in Honduras 6 months after activist brother slain
 - [https://www.foxnews.com/world/environmental-activist-shot-death-honduras-6-months-activist-brother-slain](https://www.foxnews.com/world/environmental-activist-shot-death-honduras-6-months-activist-brother-slain)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 16:02:19+00:00

An environmental activist was fatally shot by two unidentified assailants Thursday at his family&apos;s residence in northern Honduras. The victim&apos;s brother was shot in a similar attack.

## German police appeal for images taken of attack in which Americans were pushed down steep slope
 - [https://www.foxnews.com/world/german-police-appeal-images-taken-attack-which-americans-pushed-steep-slope](https://www.foxnews.com/world/german-police-appeal-images-taken-attack-which-americans-pushed-steep-slope)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 16:00:11+00:00

Police in southern Germany are seeking help from witnesses who may have captured photos of an attack near Neuschwanstein castle. The man allegedly pushed two women down a slope.

## Lebanese man suspected of trafficking stolen antiquities faces Interpol warrant
 - [https://www.foxnews.com/world/lebanese-man-suspected-trafficking-stolen-antiquities-faces-interpol-warrant](https://www.foxnews.com/world/lebanese-man-suspected-trafficking-stolen-antiquities-faces-interpol-warrant)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 15:58:07+00:00

Interpol has issued a global warrant for the arrest of a Lebanese individual suspected of being involved in the trafficking of stolen antiquities, according to judicial officials.

## Florida couple accused of buying boats, businesses in multimillion-dollar COVID relief scam
 - [https://www.foxnews.com/us/florida-couple-accused-buying-boats-businesses-multimillion-dollar-covid-relief-scam](https://www.foxnews.com/us/florida-couple-accused-buying-boats-businesses-multimillion-dollar-covid-relief-scam)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 15:56:00+00:00

Timothy and Lisa Jolloff, both of southwestern Florida, have been charged with stealing over $2 million in federal COVID-19 relief funds to spend on luxury items.

## WATCH: Illegal fireworks warehouse explodes, incident caught on camera rocks neighborhood
 - [https://www.foxnews.com/world/illegal-fireworks-warehouse-explodes-incident-caught-camera-rocks-neighborhood](https://www.foxnews.com/world/illegal-fireworks-warehouse-explodes-incident-caught-camera-rocks-neighborhood)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 15:54:25+00:00

Officials repeatedly stressed that the building should not have contained any fireworks and was illegal due to proximity to residential buildings, prompting a search for the owner.

## New York state trooper shot, wounded on upstate highway
 - [https://www.foxnews.com/us/new-york-state-trooper-shot-wounded-upstate-highway](https://www.foxnews.com/us/new-york-state-trooper-shot-wounded-upstate-highway)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 15:54:02+00:00

A New York state trooper shot Friday is reportedly in stable condition. The trooper was wounded by a suspect fleeing a traffic stop on Interstate 88 in Duanesburg.

## Dem expert puts KJP, Bates on notice, says officials who keep breaking Hatch Act 'should be gone'
 - [https://www.foxnews.com/politics/dem-expert-puts-kjp-bates-notice-officials-who-keep-breaking-hatch-act-should-be-gone](https://www.foxnews.com/politics/dem-expert-puts-kjp-bates-notice-officials-who-keep-breaking-hatch-act-should-be-gone)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 15:46:19+00:00

Former Bush administration ethics chief Richard Painter told Fox News Digital that federal officials who continue to break the Hatch Act should be &quot;fired.&quot;

## Germany returns 600-year-old indigenous masks to Colombia
 - [https://www.foxnews.com/world/germany-returns-600-year-old-indigenous-masks-colombia](https://www.foxnews.com/world/germany-returns-600-year-old-indigenous-masks-colombia)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 15:41:17+00:00

Germany returned two &quot;sun masks&quot; made by Colombia&apos;s Native Kogi people in the 1400s to their home country on Friday, after spending over a century in a Berlin museum&apos;s collection.

## Bipartisan bill would give some female vets combat-related benefits: 'They are so deeply owed'
 - [https://www.foxnews.com/politics/bipartisan-bill-would-give-some-female-vets-combat-related-benefits-they-are-so-deeply-owed](https://www.foxnews.com/politics/bipartisan-bill-would-give-some-female-vets-combat-related-benefits-they-are-so-deeply-owed)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 15:40:27+00:00

The bill will allow female veterans who served in Cultural Support Teams to apply for re-evaluation and receive the benefits of full frontline duty service.

## MLB to move fences back for Cubs-Cardinals game in London
 - [https://www.foxnews.com/sports/mlb-moving-fences-back-when-cubs-cardinals-play-london](https://www.foxnews.com/sports/mlb-moving-fences-back-when-cubs-cardinals-play-london)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 15:33:11+00:00

When the Chicago Cubs and St. Louis Cardinals travel to London, the fences will be a little farther back in center field than when the Yankees and Red Sox played in there in 2019.

## Colorado plastic surgeon convicted after teen dies during breast implant surgery
 - [https://www.foxnews.com/us/colorado-plastic-surgeon-convicted-teen-dies-breast-implant-surgery](https://www.foxnews.com/us/colorado-plastic-surgeon-convicted-teen-dies-breast-implant-surgery)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 15:19:53+00:00

A Colorado plastic surgeon was found guilty Wednesday of attempted reckless manslaughter after his 18-year-old patient had a heart attack, and he didn&apos;t call 911 for five hours.

## Biden's habit of snapping at reporters continues after hitting 'dumb' question from NY Post journalist
 - [https://www.foxnews.com/media/bidens-habit-snapping-reporters-continues-hitting-dumb-question-ny-post-journalist](https://www.foxnews.com/media/bidens-habit-snapping-reporters-continues-hitting-dumb-question-ny-post-journalist)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 15:18:12+00:00

President Joe Biden&apos;s recent snarky response to a journalist&apos;s question he didn&apos;t like, is the latest in a long line of testy answers he has given to the press.

## Vietnam War activist Daniel Ellsberg, who leaked the Pentagon Papers, dies at 92
 - [https://www.foxnews.com/politics/vietnam-war-activist-daniel-ellsberg-who-leaked-the-pentagon-papers-dies-at-92](https://www.foxnews.com/politics/vietnam-war-activist-daniel-ellsberg-who-leaked-the-pentagon-papers-dies-at-92)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 15:07:58+00:00

Daniel Ellsberg, the analyst who leaked the Pentagon Papers exposing government secrets about the Vietnam War, passed away on Friday at the age of 92, surrounded by family.

## Whitmer requests disaster declaration for spring flooding on Upper Peninsula
 - [https://www.foxnews.com/politics/whitmer-requests-disaster-declaration-spring-flooding-upper-peninsula](https://www.foxnews.com/politics/whitmer-requests-disaster-declaration-spring-flooding-upper-peninsula)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 15:05:36+00:00

Democratic Michigan Gov. Gretchen Whitmer has requested a federal disaster declaration over snowmelt-induced floods on the Upper Peninsula earlier this year.

## Ohio man admits to lining up 3 young sons in yard, executing them with rifle: prosecutors
 - [https://www.foxnews.com/us/ohio-man-admits-lining-3-young-sons-yard-executing-rifle-prosecutors](https://www.foxnews.com/us/ohio-man-admits-lining-3-young-sons-yard-executing-rifle-prosecutors)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 15:03:54+00:00

Chad Doerman, 32, of Monroe Township, Ohio, has reportedly admitted to the execution-style shootings of his three young sons, according to prosecutors.

## Pete Davidson charged with reckless driving in connection with crashing vehicle into Beverly Hills home
 - [https://www.foxnews.com/entertainment/pete-davidson-charged-reckless-driving-crashing-vehicle-beverly-hills-home](https://www.foxnews.com/entertainment/pete-davidson-charged-reckless-driving-crashing-vehicle-beverly-hills-home)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 15:02:52+00:00

&quot;Saturday Night Live&quot; alum Pete Davidson has been charged with reckless driving for allegedly crashing into a Beverly Hills home earlier this year.

## LA cable network won't air TV ad slamming Dodgers for anti-Catholic drag troupe: 'Too controversial'
 - [https://www.foxnews.com/politics/la-cable-network-wont-air-tv-ad-slamming-dodgers-anti-catholic-drag-troupe-too-controversial](https://www.foxnews.com/politics/la-cable-network-wont-air-tv-ad-slamming-dodgers-anti-catholic-drag-troupe-too-controversial)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 15:00:34+00:00

CatholicVote says Spectrum SportsNet refused to run its ad about the Los Angeles Dodgers inviting an anti-Catholic drag queen troupe to its Pride Night.

## College Board rejects Florida's request to ‘audit, modify’ AP courses on gender identity, sexual orientation
 - [https://www.foxnews.com/media/college-board-rejects-florida-request-to-audit-modify-ap-courses-on-gender-identity-sexual-orientation](https://www.foxnews.com/media/college-board-rejects-florida-request-to-audit-modify-ap-courses-on-gender-identity-sexual-orientation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 15:00:13+00:00

The College Board rejected the Florida Department of Education Office of Articulation&apos;s request to audit and modify AP courses that discuss sexual orientation.

## Obama suggests 'digital fingerprints' to counter misinformation 'so we know what's true and what's not true'
 - [https://www.foxnews.com/politics/obama-suggests-digital-fingerprints-counter-misinformation-we-know-whats-true-not-true](https://www.foxnews.com/politics/obama-suggests-digital-fingerprints-counter-misinformation-we-know-whats-true-not-true)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 14:57:12+00:00

Former President Barack Obama suggested the development of &quot;digital fingerprints&quot; to combat misinformation and distinguish between true and misleading news for consumers.

## Republican congressional staffer attacked at gunpoint, lawmaker says
 - [https://www.foxnews.com/politics/republican-congressional-staffer-attacked-gunpoint-lawmaker-says](https://www.foxnews.com/politics/republican-congressional-staffer-attacked-gunpoint-lawmaker-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 14:53:17+00:00

A congressional staffer working for Rep. Brad Finstad was attacked at gunpoint near his residence following the Congressional Baseball Game on Wednesday.

## Dodgers prepare to honor Sisters of Perpetual Indulgence during Pride Night amid backlash
 - [https://www.foxnews.com/sports/dodgers-prepare-honor-sisters-perpetual-indulgence-during-pride-night-amid-backlash](https://www.foxnews.com/sports/dodgers-prepare-honor-sisters-perpetual-indulgence-during-pride-night-amid-backlash)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 14:50:45+00:00

The Los Angeles Dodgers will present The Sisters of Perpetual Indulgence with an award Friday night amid heated backlash since the group was first invited May 4.

## 'The fight is not over': GOP slams Iowa Supreme Court's 'lack of action' as abortion remains legal in state
 - [https://www.foxnews.com/politics/fight-not-over-gop-slams-iowa-state-supreme-courts-lack-of-action-abortion-remains-legal](https://www.foxnews.com/politics/fight-not-over-gop-slams-iowa-state-supreme-courts-lack-of-action-abortion-remains-legal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 14:40:02+00:00

Republicans slammed the Iowa Supreme Court decision blocking a ban on abortion after a fetal heartbeat is detected, but assured &apos;the fight is not over.&apos;

## Hilary Knight optimistic over potential formation of women's professional hockey league
 - [https://www.foxnews.com/sports/hilary-knight-optimistic-about-formation-womens-professional-hockey-league](https://www.foxnews.com/sports/hilary-knight-optimistic-about-formation-womens-professional-hockey-league)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 14:35:35+00:00

The Professional Women&apos;s Hockey Players&apos; Association is negotiating the collective bargaining agreement with its corporate sponsors, and Hilary Knight remains optimistic about a deal.

## Warriors name Mike Dunleavy Jr as new general manager to replace Bob Myers
 - [https://www.foxnews.com/sports/warriors-name-mike-dunleavy-jr-new-general-manager-replace-bob-myers](https://www.foxnews.com/sports/warriors-name-mike-dunleavy-jr-new-general-manager-replace-bob-myers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 14:34:43+00:00

The Golden State Warriors are replacing Bob Myers from within, promoting Marcus Dunleavy Jr. from vice president of basketball operations to general manager.

## 3,000-year-old sword so well-preserved it 'almost still shines' found in Germany
 - [https://www.foxnews.com/world/3000-year-old-sword-well-preserved-almost-still-shines-found-germany](https://www.foxnews.com/world/3000-year-old-sword-well-preserved-almost-still-shines-found-germany)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 14:13:53+00:00

German officials report that a sword in a near-pristine state of preservation was uncovered by archaeologists during a Bavarian excavation last week.

## Federal authorities arrest 6 in bust of Guatemalan family smuggling ring
 - [https://www.foxnews.com/us/federal-authorities-arrest-6-bust-guatemalan-family-smuggling-ring](https://www.foxnews.com/us/federal-authorities-arrest-6-bust-guatemalan-family-smuggling-ring)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 14:12:18+00:00

Federal authorities announced Thursday the arrest of six individuals involved in a human smuggling operation that transported migrants from Guatemala to the United States.

## Nusrat Choudhury makes history as first Muslim female federal judge with Senate confirmation
 - [https://www.foxnews.com/us/nusrat-choudhury-makes-history-first-muslim-female-federal-judge-senate-confirmation](https://www.foxnews.com/us/nusrat-choudhury-makes-history-first-muslim-female-federal-judge-senate-confirmation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 14:02:24+00:00

Nusrat Choudhury has made history as the Senate confirmed her as the first Muslim female federal judge in the United States. Advocacy groups praised Chowdhury&apos;s confirmation.

## Greek coast guard defends its response to shipwreck where up to 500 passengers are feared dead
 - [https://www.foxnews.com/world/greek-coast-guard-defends-response-shipwreck-500-passengers-feared-dead](https://www.foxnews.com/world/greek-coast-guard-defends-response-shipwreck-500-passengers-feared-dead)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 14:01:10+00:00

The Greek government has been under renewed pressure to address Europe’s migration issue after a ship carrying hundreds of passengers sank off the country’s south coast.

## Young athlete injured by transgender opponent hits back at Karine Jean-Pierre: 'I expect nothing less'
 - [https://www.foxnews.com/media/young-athlete-injured-transgender-opponent-hits-back-karine-jean-pierre-expect-nothing-less](https://www.foxnews.com/media/young-athlete-injured-transgender-opponent-hits-back-karine-jean-pierre-expect-nothing-less)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 14:00:23+00:00

Payton McNabb criticized White House press secretary Karine Jean-Pierre for claiming it&apos;s &quot;dangerous&quot; to question whether women are safe when competing against trans athletes.

## China condemns EU Parliament resolution addressing Hong Kong’s deteriorating freedoms
 - [https://www.foxnews.com/world/china-condemns-eu-parliament-resolution-addressing-hong-kongs-deteriorating-freedoms](https://www.foxnews.com/world/china-condemns-eu-parliament-resolution-addressing-hong-kongs-deteriorating-freedoms)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 14:00:01+00:00

Beijing is objecting to a resolution adopted by the European Parliament which addresses Hong Kong’s shrinking freedoms of speech. It also calls for the release of pro-democracy activists.

## House Republicans file resolution condemning SPLC for 'disgusting' targeting of parental rights groups
 - [https://www.foxnews.com/politics/house-republicans-file-resolution-condemning-splc-targeting-parental-rights-groups](https://www.foxnews.com/politics/house-republicans-file-resolution-condemning-splc-targeting-parental-rights-groups)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 13:59:51+00:00

A resolution filed by House Republicans on Thursday condemns the Southern Poverty Law Center for calling parental rights groups hateful extremists.

## American woman accused of killing mother on Bali vacation, hiding body in suitcase pleads guilty
 - [https://www.foxnews.com/us/american-woman-accused-killing-mother-bali-vacation-hiding-body-suitcase-pleads-guilty](https://www.foxnews.com/us/american-woman-accused-killing-mother-bali-vacation-hiding-body-suitcase-pleads-guilty)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 13:48:48+00:00

Heather Mack, the woman convicted by an Indonesian court of helping murder her mother and hide the remains in a suitcase, pleaded guilty in U.S. court.

## Shooting, fire at Tennessee home leads to 6 dead including 3 children
 - [https://www.foxnews.com/us/shooting-fire-tennessee-home-leads-6-dead-including-3-children](https://www.foxnews.com/us/shooting-fire-tennessee-home-leads-6-dead-including-3-children)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 13:42:37+00:00

Police in Sequatchie, Tennessee responded to a shooting and arrived at a residence engulfed in flames. Six individuals, including three children, were discovered lifeless inside.

## Bizarre San Francisco Chronicle column compares 'hatred of bicyclists' to racism, sexism, transphobia
 - [https://www.foxnews.com/media/bizarre-san-francisco-chronicle-column-compares-hatred-bicyclists-racism-sexism-transphobia](https://www.foxnews.com/media/bizarre-san-francisco-chronicle-column-compares-hatred-bicyclists-racism-sexism-transphobia)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 13:39:47+00:00

The anger some feel towards cyclists is similar to the rage that drives racism and sexism, according to an opinion piece in the San Francisco Chronicle.

## Brutal attack by extremist rebels kills 7 farmers in northeast Nigeria, heightening food security concerns
 - [https://www.foxnews.com/world/brutal-attack-extremist-rebels-kills-7-farmers-northeast-nigeria-heightening-food-security-concerns](https://www.foxnews.com/world/brutal-attack-extremist-rebels-kills-7-farmers-northeast-nigeria-heightening-food-security-concerns)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 13:39:43+00:00

A group of Islamic extremist rebels carried out a brutal attack in northeast Nigeria, resulting in the death of seven farmers. The assault has worsened the dire food security situation.

## Japan raises age of consent from 13 to 16
 - [https://www.foxnews.com/world/japan-raises-age-consent-13-16](https://www.foxnews.com/world/japan-raises-age-consent-13-16)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 13:37:50+00:00

The Japanese parliament on Friday voted to raise the country&apos;s age of consent to 16 from its longstanding 13, which was among the world&apos;s lowest.

## California police department's racist text scandal forces DA to drop charges in woman's burning
 - [https://www.foxnews.com/us/california-police-departments-racist-text-scandal-forces-da-drop-charges-womans-burning](https://www.foxnews.com/us/california-police-departments-racist-text-scandal-forces-da-drop-charges-womans-burning)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 13:35:07+00:00

Mykaella Elizabeth Sharlman was allegedly mutilated and burned by two men in California, but prosecutors dropped the case because of a scandal in the Antioch Police Department.

## The Mercedes-Benz Vision One-Eleven is a look into the future
 - [https://www.foxnews.com/auto/mercedes-benz-vision-one-eleven-look-into-future](https://www.foxnews.com/auto/mercedes-benz-vision-one-eleven-look-into-future)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 13:30:33+00:00

The Mercedes-Benz Vision One-Eleven is an electric supercar concept that showcases a new type of motor and battery pack that could end up in road cars.

## Mississippi picks new interim state superintendent of education
 - [https://www.foxnews.com/us/mississippi-picks-new-interim-state-superintendent-education](https://www.foxnews.com/us/mississippi-picks-new-interim-state-superintendent-education)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 13:21:50+00:00

The Mississippi State Board of Education has made an announcement regarding the appointment of the next interim state superintendent of education. Ray Morgigno will start on July 1.

## Most of 108 drowning victims in Nigeria boat accident were women and children
 - [https://www.foxnews.com/world/most-108-drowning-victims-nigeria-boat-accident-women-children](https://www.foxnews.com/world/most-108-drowning-victims-nigeria-boat-accident-women-children)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 13:20:35+00:00

An incident in north-central Nigeria killed 108 people, after a boat they were traveling in broke apart in the Niger River. The boat was carrying over 250 passengers.

## Man charged with triple murder in Nottingham knife and van attack
 - [https://www.foxnews.com/world/man-charged-triple-murder-nottingham-knife-van-attack](https://www.foxnews.com/world/man-charged-triple-murder-nottingham-knife-van-attack)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 13:18:48+00:00

Authorities filed charges against a man in connection with a knife and van attack that resulted in the death of two student athletes and a school caretaker in Nottingham, England.

## US nuclear submarine arrives to South Korea a day after North Korea resumes missile tests
 - [https://www.foxnews.com/world/us-nuclear-submarine-arrives-south-korea-day-north-korea-resumes-missile-tests](https://www.foxnews.com/world/us-nuclear-submarine-arrives-south-korea-day-north-korea-resumes-missile-tests)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 13:18:02+00:00

After North Korea launched missiles in protest of the live-fire drills conducted by the U.S. and South Korea, an American nuclear-powered submarine arrived in South Korea.

## 15 dead after Canadian bus full of seniors collides with semi-trailer while heading to casino
 - [https://www.foxnews.com/world/15-dead-canadian-bus-full-seniors-collides-semi-trailer-heading-casino](https://www.foxnews.com/world/15-dead-canadian-bus-full-seniors-collides-semi-trailer-heading-casino)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 13:11:55+00:00

A bus full of senior passengers was heading to a casino when it collided with a semi-trailer in Manitoba, Canada. Fifteen people, mostly seniors, died in the incident.

## Thousands of imposter websites discovered mimicking top brands to steal your banking info
 - [https://www.foxnews.com/tech/thousands-imposter-websites-discovered-mimicking-top-brands-steal-banking-info](https://www.foxnews.com/tech/thousands-imposter-websites-discovered-mimicking-top-brands-steal-banking-info)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 13:09:07+00:00

Imposter websites make you susceptible to bank fraud and information theft unless you check URLs when web browsing.

## Closure of Planned Parenthood clinic leaves Utah with reduced abortion access outside Salt Lake City
 - [https://www.foxnews.com/us/closure-planned-parenthood-clinic-leaves-utah-reduced-abortion-access-salt-lake-city](https://www.foxnews.com/us/closure-planned-parenthood-clinic-leaves-utah-reduced-abortion-access-salt-lake-city)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 13:01:27+00:00

Planned Parenthood closed its only clinic in Logan, Utah, resulting in limited access to abortion services in the state. The closure occurred after the clinic&apos;s sole provider left.

## Rural Nevada house fire kills 3; cause of blaze under investigation
 - [https://www.foxnews.com/us/rural-nevada-house-fire-kills-3-cause-blaze-investigation](https://www.foxnews.com/us/rural-nevada-house-fire-kills-3-cause-blaze-investigation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 12:59:58+00:00

A house fire in rural northern Nevada killed three individuals in Fallon. Nevada State Police reported that firefighters discovered the bodies of one adult and two juveniles.

## Republican governors intensify resistance to plan to sell land leases for conservation
 - [https://www.foxnews.com/us/republican-governors-intensify-resistance-plan-sell-land-leases-conservation](https://www.foxnews.com/us/republican-governors-intensify-resistance-plan-sell-land-leases-conservation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 12:58:38+00:00

Republican governors are pushing back against a proposal by the Biden administration that aims to elevate the importance of conservation on vast government-owned lands.

## RFK Jr tells Joe Rogan he has to ‘be careful’ the CIA doesn’t assassinate him
 - [https://www.foxnews.com/politics/rfk-jr-tells-joe-rogan-careful-cia-doesnt-assassinate-him](https://www.foxnews.com/politics/rfk-jr-tells-joe-rogan-careful-cia-doesnt-assassinate-him)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 12:49:50+00:00

Democrat presidential candidate Robert F. Kennedy, Jr. said he has to be &quot;careful&quot; that the CIA doesn&apos;t assassinate him like he believes his uncle was killed.

## Huge mass of rock slides down Swiss mountainside, narrowly misses small village
 - [https://www.foxnews.com/world/huge-mass-rock-slides-down-swiss-mountainside-narrowly-misses-small-village](https://www.foxnews.com/world/huge-mass-rock-slides-down-swiss-mountainside-narrowly-misses-small-village)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 12:41:27+00:00

A village in Brienz, Switzerland, was left unscathed after a huge mass of Alpine rock slid down a nearby mountainside and stopped short of the settlement.

## Parents' rights groups slam WH over topless trans activists at Pride event: 'I agree with Gov. DeSantis'
 - [https://www.foxnews.com/politics/parents-rights-groups-slam-wh-topless-trans-activists-pride-event-agree-gov-desantis](https://www.foxnews.com/politics/parents-rights-groups-slam-wh-topless-trans-activists-pride-event-agree-gov-desantis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 12:37:22+00:00

Parents&apos; rights groups are sounding off after Gov. Ron DeSantis blasted the Biden White House over its Pride event that included two topless transgender activists.

## Bryson DeChambeau says there's 'not as much tension' between PGA Tour, LIV players following merger
 - [https://www.foxnews.com/sports/bryson-dechambeau-says-theres-not-as-much-tension-between-pga-tour-liv-players-following-merger](https://www.foxnews.com/sports/bryson-dechambeau-says-theres-not-as-much-tension-between-pga-tour-liv-players-following-merger)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 12:20:42+00:00

Bryson DeChambeau says there is &apos;not as much tension&apos; between LIV and PGA Tour players at the U.S. Open following the stunning announcement of a merger between the groups.

## Father's Day quiz! How well do you know the annual celebration of dads?
 - [https://www.foxnews.com/lifestyle/fathers-day-quiz-how-well-know-annual-celebration-dads](https://www.foxnews.com/lifestyle/fathers-day-quiz-how-well-know-annual-celebration-dads)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 12:20:25+00:00

Father&apos;s Day quiz! How well do you know these facts about the annual celebration of dads, plus some fun Hollywood dad facts? Test your knowledge in a fun and original quiz!

## China making 'science fiction' super warship, report claims: 'Big step forward'
 - [https://www.foxnews.com/world/china-making-science-fiction-super-warship-report-claims-big-step-forward](https://www.foxnews.com/world/china-making-science-fiction-super-warship-report-claims-big-step-forward)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 12:20:02+00:00

Chinese officials have not provided any timeline, but Rear Adm. Ma Weiming claimed the PLA has already developed the basic technology or will soon have it.

## Angels' Shohei Ohtani hits 22nd home run, pitches six innings in victory over Rangers
 - [https://www.foxnews.com/sports/angels-shohei-ohtani-hits-22nd-home-run-pitches-six-innings-victory-over-rangers](https://www.foxnews.com/sports/angels-shohei-ohtani-hits-22nd-home-run-pitches-six-innings-victory-over-rangers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 12:16:09+00:00

The Los Angeles Angels beat the Texas Rangers behind Shohei Ohtani&apos;s dominant performance both hitting and pitching, as Ohtani hit a home run while pitching six innings in the victory.

## Blockbuster film 'Spider-Man: Across the Spider-Verse' removed from Middle East cinemas without explanation
 - [https://www.foxnews.com/entertainment/blockbuster-film-spider-man-across-spider-verse-removed-middle-east-cinemas-explanation](https://www.foxnews.com/entertainment/blockbuster-film-spider-man-across-spider-verse-removed-middle-east-cinemas-explanation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 12:15:12+00:00

The film &quot;Spider-Man: Across the Spider-Verse&quot; has been removed from theaters in several Muslim-majority countries, apparently over the inclusion of a transgender poster in the film.

## Man accused of hate crimes in deaths of 11 at Pittsburgh synagogue found guilty
 - [https://www.foxnews.com/us/man-accused-hate-crimes-deaths-11-pittsburgh-synagogue-found-guilty](https://www.foxnews.com/us/man-accused-hate-crimes-deaths-11-pittsburgh-synagogue-found-guilty)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 12:14:59+00:00

Robert Bowers, the man who killed 11 worshippers at a synagogue in Pittsburgh in October 2018, was found guilty Friday on all counts in a federal trial.

## Austrian court rules in favor of Ukrainian businessman in corruption case
 - [https://www.foxnews.com/world/austrian-court-rules-favor-ukrainian-businessman-corruption-case](https://www.foxnews.com/world/austrian-court-rules-favor-ukrainian-businessman-corruption-case)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 12:13:10+00:00

Ukrainian businessman Dymitro Firtash faces a U.S. indictment accusing him of conspiracy. A court in Austria ruled in favor of Firtash, sending the case back to square one.

## Michael Jordan to sell majority share of Charlotte Hornets after 13 seasons
 - [https://www.foxnews.com/sports/michael-jordan-sell-majority-share-charlotte-hornets-after-13-seasons](https://www.foxnews.com/sports/michael-jordan-sell-majority-share-charlotte-hornets-after-13-seasons)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 12:11:22+00:00

Michael Jordan is selling his majority share of the Charlotte Hornets to a group led by Gabe Plotkin and Rick Schnall, ending Jordan&apos;s 13-year run of being the Hornets owner.

## Sami Sheen defends her job as 'sex worker,' Meg Ryan's ex John Mellencamp says he was 'a s---ty boyfriend'
 - [https://www.foxnews.com/entertainment/sami-sheen-defends-job-sex-worker-meg-ryans-ex-john-mellencamp](https://www.foxnews.com/entertainment/sami-sheen-defends-job-sex-worker-meg-ryans-ex-john-mellencamp)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 12:09:43+00:00

The Fox News Entertainment newsletter brings you the latest Hollywood headlines, celebrity interviews and stories from Los Angeles and beyond.

## Elise Stefanik: This is the biggest political corruption scandal of my lifetime and it's not going away
 - [https://www.foxnews.com/media/elise-stefanik-biggest-political-corruption-scandal-lifetime-going-away](https://www.foxnews.com/media/elise-stefanik-biggest-political-corruption-scandal-lifetime-going-away)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 12:00:51+00:00

Rep. Elise Stefanik, R-N.Y., slams mainstream media for failing to cover bribery allegations against the president and reacts to President Biden snapping at reporters.

## Are Hunter Biden's international dealings a fair concern in presidential election? Americans weigh in
 - [https://www.foxnews.com/politics/hunter-bidens-international-dealings-fair-concern-presidential-election-americans-weigh](https://www.foxnews.com/politics/hunter-bidens-international-dealings-fair-concern-presidential-election-americans-weigh)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 12:00:05+00:00

Americans in New York City are torn on whether Hunter Biden&apos;s international dealings should be a fair concern for voters as President Joe Biden seeks re-election.

## Garth Brooks' Bud Light controversy: Country singer refuses to bow down to critics
 - [https://www.foxnews.com/entertainment/garth-brooks-bud-light-controversy-country-singer-refuses-bow-down-critics](https://www.foxnews.com/entertainment/garth-brooks-bud-light-controversy-country-singer-refuses-bow-down-critics)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 11:43:00+00:00

Garth Brooks remained defiant that he will serve Bud Light beer at his bar amid the controversy of the company working with transgender activist Dylan Mulvaney.

## Woke Scooby Doo reboot ‘Velma’ renewed for second season despite dreadful reviews
 - [https://www.foxnews.com/media/woke-scooby-doo-reboot-velma-renewed-second-season-despite-dreadful-reviews](https://www.foxnews.com/media/woke-scooby-doo-reboot-velma-renewed-second-season-despite-dreadful-reviews)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 11:40:37+00:00

&quot;Velma,&quot; the woke Mindy Kaling reboot of the &quot;Scooby Doo&quot; series, has been greenlit for Season 2 on Max despite blistering reviews from critics and fans.

## Newsom's pivot means an epic 2024, kill the zombie tax and more Fox News Opinion
 - [https://www.foxnews.com/opinion/newsoms-pivot-means-epic-2024-kill-zombie-tax](https://www.foxnews.com/opinion/newsoms-pivot-means-epic-2024-kill-zombie-tax)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 11:31:06+00:00

Read the latest Fox News Opinion columns and watch videos from Sean Hannity, Laura Ingraham, Jesse Watters and more.

## Father's Day gift guide: Golf-related gifts dad will love, use on the course
 - [https://www.foxnews.com/lifestyle/best-golf-related-gifts-dad-fathers-day](https://www.foxnews.com/lifestyle/best-golf-related-gifts-dad-fathers-day)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 11:26:32+00:00

Father&apos;s Day is a great time to set your dad up with some new golf gear. There are tons of gifts you can get him for the course and to practice his swing at home.

## DOJ accuses Minneapolis Police Department, city of using excessive force, racial discrimination
 - [https://www.foxnews.com/politics/doj-accuses-minneapolis-police-department-city-using-excessive-force-racial-discrimination](https://www.foxnews.com/politics/doj-accuses-minneapolis-police-department-city-using-excessive-force-racial-discrimination)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 11:22:08+00:00

The DOJ investigation into the Minneapolis police after the death of George Floyd has uncovered evidence of racial discrimination, AG Merrick Garland said.

## Michigan teen convicted of killing father with drain cleaner over hair salon appointment
 - [https://www.foxnews.com/us/michigan-teen-convicted-killing-father-drain-cleaner-hair-salon-appointment](https://www.foxnews.com/us/michigan-teen-convicted-killing-father-drain-cleaner-hair-salon-appointment)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 11:21:58+00:00

Megan Joyce Imirowicz faces up to life in prison for killing her father with drain cleaner after he refused to take her to a hair salon appointment for her 18th birthday.

## Wisconsin's GOP-controlled Legislature votes to end funding for pandemic-era child care program
 - [https://www.foxnews.com/politics/wisconsins-gop-controlled-legislature-votes-end-funding-pandemic-era-child-care-program](https://www.foxnews.com/politics/wisconsins-gop-controlled-legislature-votes-end-funding-pandemic-era-child-care-program)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 11:19:05+00:00

Wisconsin&apos;s GOP-controlled Legislature voted to end funding for a pandemic-era subsidy program for child care. Democrats and childcare providers argued to continue the funding.

## NBA suspends Grizzlies' Ja Morant 25 games after second gun incident online: 'Alarming and disconcerting'
 - [https://www.foxnews.com/sports/nba-suspends-grizzlies-ja-morant-25-games-after-second-gun-incident-online-alarming-disconcerting](https://www.foxnews.com/sports/nba-suspends-grizzlies-ja-morant-25-games-after-second-gun-incident-online-alarming-disconcerting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 11:18:45+00:00

Memphis Grizzlies star Ja Morant was suspended 25 games without pay following two incidents where he flashed a firearm on social media, the NBA announced Friday.

## Russian malware compromises Energy Department, other federal agencies
 - [https://www.foxnews.com/us/russian-malware-compromises-energy-department-other-federal-agencies](https://www.foxnews.com/us/russian-malware-compromises-energy-department-other-federal-agencies)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 11:16:28+00:00

The Department of Energy was compromised in a malware attack that targeted government agencies, Cybersecurity and Infrastructure Security Agency says.

## House Armed Services chairman torches Biden admin's Afghanistan withdrawal memo: ‘propounds outright untruths’
 - [https://www.foxnews.com/politics/house-armed-services-chairman-torches-biden-admins-afghanistan-withdrawal-memo-propounds-outright-untruths](https://www.foxnews.com/politics/house-armed-services-chairman-torches-biden-admins-afghanistan-withdrawal-memo-propounds-outright-untruths)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 11:14:03+00:00

House Armed Services Committee Chairman Mike Rogers torched Defense Secretary Lloyd Austin&apos;s Afghanistan memo as propounding &quot;outright untruths&quot; about the botched and deadly withdrawal.

## USDA sending $320 million boost to agricultural producers, food businesses to improve markets, create jobs
 - [https://www.foxnews.com/us/usda-sending-320-million-boost-agricultural-producers-food-businesses-improve-markets-create-jobs](https://www.foxnews.com/us/usda-sending-320-million-boost-agricultural-producers-food-businesses-improve-markets-create-jobs)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 11:10:41+00:00

Food businesses and agricultural producers across the United States are set to receive a $320 million boost from the U.S. Department of Agriculture.

## Utah officers rescue girl from submerged van as mom frantically pleads for help in bodycam video
 - [https://www.foxnews.com/us/utah-officers-rescue-girl-submerged-van-mom-frantically-pleads-help-bodycam-video](https://www.foxnews.com/us/utah-officers-rescue-girl-submerged-van-mom-frantically-pleads-help-bodycam-video)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 11:07:46+00:00

Video from the Tooele Police Department near Salt Lake City captures the dramatic moments of a water rescue at the Settlement Canyon Reservoir on June 3.

## Top Biden campaign aide's husband gave Hunter Biden rapid response help as Burisma scandal swirled
 - [https://www.foxnews.com/politics/top-biden-campaign-aide-husband-gave-hunter-biden-rapid-response-help-burisma-scandal](https://www.foxnews.com/politics/top-biden-campaign-aide-husband-gave-hunter-biden-rapid-response-help-burisma-scandal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 11:04:25+00:00

A top communications adviser for President Biden’s campaign is married to a consultant who helped advise Hunter Biden on public scrutiny regarding his position on Burisma&apos;s board.

## Lawyer for woman accusing Conor McGregor of sexual assault fires back over ‘shakedown’ claim as video emerges
 - [https://www.foxnews.com/sports/lawyer-for-woman-accusing-conor-mcgregor-sexual-assault-fires-back-over-shakedown-claim-video-emerges](https://www.foxnews.com/sports/lawyer-for-woman-accusing-conor-mcgregor-sexual-assault-fires-back-over-shakedown-claim-video-emerges)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 11:02:10+00:00

An attorney representing the woman accusing Conor McGregor of sexual assault during an NBA Finals game slammed claims that the woman is attempting a &quot;shakedown.&quot;

## North Carolina dad takes a second job at daughter's workplace to spend more time with her
 - [https://www.foxnews.com/lifestyle/north-carolina-dad-takes-job-daughters-workplace-spend-more-time-her](https://www.foxnews.com/lifestyle/north-carolina-dad-takes-job-daughters-workplace-spend-more-time-her)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 11:00:13+00:00

A North Carolina dad and retired Marine, James Culp, has taken on a second job at a local Food Lion Grocery Store in hopes of spending more time with his daughter, Astyn Culp.

## National Republicans wade into 2023's most heated race, launch first attacks in bid to take down red-state Dem
 - [https://www.foxnews.com/politics/national-republicans-wade-2023-most-heated-race-launch-first-attacks-red-state-democrat](https://www.foxnews.com/politics/national-republicans-wade-2023-most-heated-race-launch-first-attacks-red-state-democrat)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 10:57:00+00:00

The Republican Governors Association is launching its first ad in the party&apos;s bid to take down Kentucky Gov. Andy Beshear, one of the nation&apos;s few Democrats leading a red state.

## Border agency reassigns chief medical officer after in-custody death of child
 - [https://www.foxnews.com/us/border-agency-reassigns-chief-medical-officer-after-custody-death-8-year-old-girl](https://www.foxnews.com/us/border-agency-reassigns-chief-medical-officer-after-custody-death-8-year-old-girl)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 10:45:14+00:00

The chief medical officer of the US Customs and Border Protection has been reassigned following the in-custody death of an eight-year-old girl.

## Jury convicts 2 of playing role in 'expansive online fraud schemes' including romance scams, COVID-19 fraud
 - [https://www.foxnews.com/us/jury-convicts-2-of-playing-role-in-expansive-online-fraud-schemes-including-romance-scams-covid-19-fraud](https://www.foxnews.com/us/jury-convicts-2-of-playing-role-in-expansive-online-fraud-schemes-including-romance-scams-covid-19-fraud)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 10:42:50+00:00

Two people were convicted of playing a role in what prosecutors called &quot;expansive online fraud schemes.&quot; The schemes included romance scams and coronavirus unemployment fraud.

## Obese children turning to weight loss drugs, body-altering surgery despite risks
 - [https://www.foxnews.com/us/obese-children-turning-weight-loss-drugs-body-altering-surgery-despite-risks](https://www.foxnews.com/us/obese-children-turning-weight-loss-drugs-body-altering-surgery-despite-risks)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 10:35:51+00:00

Hundreds of thousands of children across the country deal with obesity, and these children are now looking at body-altering surgery and weight loss drugs as a weight loss option.

## US upgrades nation’s only underground nuclear repository in New Mexico with new ventilation shaft
 - [https://www.foxnews.com/us/us-upgrades-nations-only-underground-nuclear-repository-new-mexico-new-ventilation-shaft](https://www.foxnews.com/us/us-upgrades-nations-only-underground-nuclear-repository-new-mexico-new-ventilation-shaft)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 10:31:21+00:00

Contractors for New Mexico’s Waste Isolation Pilot Plant are working to build a much-needed ventilation shaft following a 2014 contamination disaster that led to its three-year closure.

## Media continue to tout doctors defending transgender treatments for children in CBS interview
 - [https://www.foxnews.com/media/media-continue-tout-doctors-defending-transgender-treatments-children-cbs-interview](https://www.foxnews.com/media/media-continue-tout-doctors-defending-transgender-treatments-children-cbs-interview)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 10:31:10+00:00

CBS News interviewed the president of the American Medical Association on his concerns about states banning trangender treatments for youth.

## James Carville calls Vivek Ramaswamy's vow to pardon Trump the 'smartest strategy'
 - [https://www.foxnews.com/media/james-carville-calls-vivek-ramaswamys-vow-pardon-trump-smartest-strategy](https://www.foxnews.com/media/james-carville-calls-vivek-ramaswamys-vow-pardon-trump-smartest-strategy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 10:30:23+00:00

James Carville said that GOP presidential candidate Vivek Ramaswamy has the &quot;smartest strategy&quot; of the Republicans by vowing to pardon Trump if elected.

## Iowa high court refuses to unblock state's strict abortion ban
 - [https://www.foxnews.com/politics/iowa-high-court-refuses-unblock-states-strict-abortion-ban](https://www.foxnews.com/politics/iowa-high-court-refuses-unblock-states-strict-abortion-ban)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 10:27:56+00:00

An Iowa court upheld a 2019 district court ruling to block a strict abortion ban in the state. Gov. Kim Reynolds is looking to limit access to the procedure.

## Professor predicts win for students in affirmative action case, but has warning for how colleges will respond
 - [https://www.foxnews.com/media/professor-predicts-win-students-affirmative-action-case-has-warning-how-colleges-respond](https://www.foxnews.com/media/professor-predicts-win-students-affirmative-action-case-has-warning-how-colleges-respond)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 10:06:00+00:00

Wilfred McClay, a professor of history at Hillsdale College in Michigan, predicted that the Supreme Court would overturn affirmative action but issued a warning as well.

## Megan Fox’s ex Brian Austin Green slams comment he’s a ‘bad father’ after defending star over sons’ dresses
 - [https://www.foxnews.com/entertainment/megan-foxs-ex-brian-austin-green-slams-comment-bad-father-after-defending-star-sons-dresses](https://www.foxnews.com/entertainment/megan-foxs-ex-brian-austin-green-slams-comment-bad-father-after-defending-star-sons-dresses)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 10:00:40+00:00

Brian Austin Green is responding to comments that he is a &quot;bad father&quot; because he came to the defense of Megan Fox, his ex, after she was accused of forcing her sons to wear dresses.

## Department of Commerce announces $930 million in grants for Biden's internet expansion project
 - [https://www.foxnews.com/us/department-commerce-announces-930-million-grants-bidens-internet-expansion-project](https://www.foxnews.com/us/department-commerce-announces-930-million-grants-bidens-internet-expansion-project)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 09:50:44+00:00

The Department of Commerce announced $930 million in grants for Biden&apos;s initiative to improve internet access in the US. The grants will improve internet in Texas, Alaska, and more.

## King Charles vs Meghan Markle: Former actress' 'Suits' show drops on monarch's Trooping the Colour day
 - [https://www.foxnews.com/entertainment/king-charles-vs-meghan-markle-former-actress-suits-show-drops-monarchs-trooping-colour-day](https://www.foxnews.com/entertainment/king-charles-vs-meghan-markle-former-actress-suits-show-drops-monarchs-trooping-colour-day)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 09:32:50+00:00

On June 17, King Charles III&apos;s Trooping the Colour parade will be held on the same day that Meghan Markle&apos;s former legal drama &quot;Suits&quot; becomes available on Netflix for the first time.

## A drag racing Dragonsnake and more autos stories
 - [https://www.foxnews.com/auto/drag-racing-dragonsnake-more-autos-stories](https://www.foxnews.com/auto/drag-racing-dragonsnake-more-autos-stories)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 09:31:12+00:00

The Fox News Autos newsletter brings you the latest developments in the world of cars, trucks, performance vehicles and collectible automobiles.

## 8 great iPhone accessibility tips to make life easier
 - [https://www.foxnews.com/tech/8-great-iphone-accessibility-tips-make-life-easier](https://www.foxnews.com/tech/8-great-iphone-accessibility-tips-make-life-easier)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 09:24:06+00:00

Kurt &quot;The CyberGuy&quot; Knutsson explains how these Apple iPhone accessibility features can make the device more friendly for users who may need assistance.

## Adam Schiff not out of the woodshed yet: GOP will move again to condemn his ‘false accusations’
 - [https://www.foxnews.com/politics/adam-schiff-hasnt-escaped-censure-gop-try-again-condemn-false-accusations](https://www.foxnews.com/politics/adam-schiff-hasnt-escaped-censure-gop-try-again-condemn-false-accusations)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 09:23:25+00:00

House Republicans are expected to try again to censure Rep. Adam Schiff after 20 Republicans voted against a censure resolution on the House floor this week.

## Gregg Berhalter to return as US national team head coach: report
 - [https://www.foxnews.com/sports/gregg-berhalter-return-u-s-national-team-head-coach-report](https://www.foxnews.com/sports/gregg-berhalter-return-u-s-national-team-head-coach-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 09:18:39+00:00

The United States Soccer Federation is likely to make an announcement Friday about Gregg Berhalter returning as coach the U.S. men&apos;s national team through the 2026 World Cup.

## ‘Jeopardy!’ cheers on Pat Sajak after ‘Wheel of Fortune’ retirement announcement
 - [https://www.foxnews.com/entertainment/jeopardy-cheers-pat-sajak-wheel-of-fortune-retirement-announcement](https://www.foxnews.com/entertainment/jeopardy-cheers-pat-sajak-wheel-of-fortune-retirement-announcement)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 09:17:54+00:00

&quot;Wheel of Fortune&apos;s&quot; game show neighbor &quot;Jeopardy!&quot; honored the popular television host Pat Sajak after he made a major announcement that he&apos;s retiring.

## Ford Ranger Dakar Rally raider revealed
 - [https://www.foxnews.com/auto/ford-ranger-dakar-rally-raider-revealed](https://www.foxnews.com/auto/ford-ranger-dakar-rally-raider-revealed)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 09:11:12+00:00

Ford has unveiled the Ranger-based racing truck it will enter in the 2024 Dakar rally. The vehicle will compete in the top T1 class and go for the overall win.

## Rory McIlroy whiffs shot from the rough at US Open, avoids media after 18th hole blunder
 - [https://www.foxnews.com/sports/rory-mcilroy-whiffs-shot-from-rough-us-open-avoids-media-18th-hole-blunder](https://www.foxnews.com/sports/rory-mcilroy-whiffs-shot-from-rough-us-open-avoids-media-18th-hole-blunder)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 09:06:41+00:00

Rory McIlroy did not appear before the media Thursday after suffering an uncharacteristic blunder on the 18th hole at the U.S. Open.

## Man tried to drive into Idaho library employee who defended transgender coworker, pleads guilty to hate crime
 - [https://www.foxnews.com/us/man-tried-drive-idaho-library-employee-defended-transgender-coworker-pleads-guilty-hate-crime](https://www.foxnews.com/us/man-tried-drive-idaho-library-employee-defended-transgender-coworker-pleads-guilty-hate-crime)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 09:03:07+00:00

An Oregon man who threatened to use his car to strike several people believed to be part of the LGBTQI+ community has pleaded guilty to hate crime charges in Idaho.

## UN report shows al Qaeda and Taliban ties remain strong, warns of ISIS threat
 - [https://www.foxnews.com/world/un-report-shows-al-qaeda-taliban-ties-remain-strong-warns-isis-threat](https://www.foxnews.com/world/un-report-shows-al-qaeda-taliban-ties-remain-strong-warns-isis-threat)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 09:01:13+00:00

A new U.N. report outlines how the Taliban are experiencing internal divisions over the competition for power and the group has allowed al Qaeda and other terrorist groups to flourish.

## Dr. Cornel West says he 'hates' Biden's hypocrisy, neoliberalism and vows to take campaign to pro-Trump areas
 - [https://www.foxnews.com/media/dr-cornel-west-hates-bidens-hypocrisy-neoliberalism-vows-take-campaign-pro-trump-areas](https://www.foxnews.com/media/dr-cornel-west-hates-bidens-hypocrisy-neoliberalism-vows-take-campaign-pro-trump-areas)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 09:00:39+00:00

Dr. Cornel West, who has taught at Harvard University and Princeton University, sounded off on his third-party presidential bid in an interview with Laura Ingraham.

## Father's Day ideas: Grilling-related gifts to get dad excited to barbecue all summer long
 - [https://www.foxnews.com/lifestyle/best-grilling-related-gifts-dad-fathers-day](https://www.foxnews.com/lifestyle/best-grilling-related-gifts-dad-fathers-day)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 08:58:29+00:00

Gifts for the grill are a great idea for Father&apos;s Day. This guide includes everything from necessities such as spatulas and spices to fun add-ons like a pizza oven.

## Climate change protestors drop pants at Massachusetts Statehouse during tax relief package debate
 - [https://www.foxnews.com/us/climate-change-protestors-drop-pants-massachusetts-statehouse-during-tax-relief-package-debate](https://www.foxnews.com/us/climate-change-protestors-drop-pants-massachusetts-statehouse-during-tax-relief-package-debate)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 08:55:19+00:00

Demonstrators dropped their pants at the Massachusetts Statehouse to protest climate change during a debate over a proposed tax relief package.

## Seattle woman who was killed while 8 months pregnant was owner of local restaurant near famed market
 - [https://www.foxnews.com/us/seattle-woman-killed-8-months-pregnant-owner-local-restaurant-famed-market](https://www.foxnews.com/us/seattle-woman-killed-8-months-pregnant-owner-local-restaurant-famed-market)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 08:53:24+00:00

An eight months pregnant woman who was killed in a random traffic stop shooting in Seattle, Washington, has been identified as a local sushi restaurant owner.

## Guilty verdict expected in trial for Pittsburgh synagogue shooter who killed 11 worshippers
 - [https://www.foxnews.com/us/guilty-verdict-expected-trial-pittsburgh-synagogue-shooter-killed-11-worshippers](https://www.foxnews.com/us/guilty-verdict-expected-trial-pittsburgh-synagogue-shooter-killed-11-worshippers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 08:42:27+00:00

A guilty verdict is expected in the trial of Robert Bowers. Bower&apos;s lawyers acknowledged he carried out the shooting that killed 11 Jewish worshippers at a Pittsburgh synagogue.

## Caitlyn Jenner wouldn’t advise businesses to go ‘woke’ like Bud Light, Target: ‘Don't go down that road’
 - [https://www.foxnews.com/media/caitlyn-jenner-wouldnt-advise-businesses-go-woke-bud-light-target-down-road](https://www.foxnews.com/media/caitlyn-jenner-wouldnt-advise-businesses-go-woke-bud-light-target-down-road)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 08:36:20+00:00

Caitlyn Jenner believes most Americans don’t have a problem with the LGBTQ community but feels brands like Bud Light and Target caused self-inflicted harm.

## Pope returns to Vatican after hospital stay for abdominal surgery
 - [https://www.foxnews.com/world/pope-returns-vatican-after-hospital-stay-abdominal-surgery](https://www.foxnews.com/world/pope-returns-vatican-after-hospital-stay-abdominal-surgery)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 08:26:25+00:00

Pope Francis was discharged from Gemelli Hospital in Rome, on Friday, after spending more than a week in recovery from his abdominal surgery.

## Scorned woman jailed for 22 years for attacking married lover’s wife with knife hidden behind flowers
 - [https://www.foxnews.com/world/scorned-woman-jailed-22-years-attacking-married-lovers-wife-knife-hidden-behind-flowers](https://www.foxnews.com/world/scorned-woman-jailed-22-years-attacking-married-lovers-wife-knife-hidden-behind-flowers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 08:03:56+00:00

A former teacher in the United Kingdom was convicted and sentenced to 22 years in jail for violently attacking her married lover&apos;s wife. Claire Bailey used a carving knife to attack her victim.

## A bungled response to reports of a China spy station in Cuba signifies Biden’s failed Beijing policy
 - [https://www.foxnews.com/opinion/bungled-response-reports-china-spy-station-cuba-signifies-bidens-failed-beijing-policy](https://www.foxnews.com/opinion/bungled-response-reports-china-spy-station-cuba-signifies-bidens-failed-beijing-policy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 08:00:59+00:00

China’s espionage base in Cuba fits into Beijing’s overall wartime strategy, targeting America, and exposing the Biden administration&apos;s ineptitude at dealing with the China threat.

## Los Angeles diocese to hold day of prayer in response to Dodgers' game event honoring ‘drag nuns’
 - [https://www.foxnews.com/lifestyle/los-angeles-diocese-hold-day-prayer-response-dodgers-game-event-drag-nuns](https://www.foxnews.com/lifestyle/los-angeles-diocese-hold-day-prayer-response-dodgers-game-event-drag-nuns)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 07:55:44+00:00

Archbishop Jose Gomez of Los Angeles will celebrate a special Mass at the city&apos;s cathedral on Friday, June 16, to kick off a day of prayer and reparation of sin, said the archdiocese.

## Irish politician boasts hate speech bill will ‘restrict freedom’ to protect trans people from ‘discomfort’
 - [https://www.foxnews.com/world/irish-politician-boasts-hate-speech-bill-restrict-freedom-protect-trans-people-discomfort](https://www.foxnews.com/world/irish-politician-boasts-hate-speech-bill-restrict-freedom-protect-trans-people-discomfort)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 07:48:20+00:00

An Irish senator defended hate speech legislation moving through the Irish government by arguing it would merely be another law restricting freedom for the greater good.

## Oregon GOP senators end 6-week walkout following new agreements
 - [https://www.foxnews.com/politics/oregon-gop-senators-end-6-week-walkout-new-agreements](https://www.foxnews.com/politics/oregon-gop-senators-end-6-week-walkout-new-agreements)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 07:43:12+00:00

A Republican-led Senate walkout that stalled legislative progress for six weeks in Salem, Oregon, has finally ended following new agreements on abortion and gun rights.

## Rhode Island Senate approves $14 billion budget proposal for 2024 fiscal year
 - [https://www.foxnews.com/politics/rhode-island-senate-approves-14-billion-budget-proposal-2024-fiscal-year](https://www.foxnews.com/politics/rhode-island-senate-approves-14-billion-budget-proposal-2024-fiscal-year)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 07:33:53+00:00

A $14 billion budget was approved by the Rhode Island Senate for the 2024 fiscal year. The spending will be directed toward the housing crisis, education funding, and more.

## GOP candidates condemn Biden for elicit mishap during White House Pride event: 'Very revealing'
 - [https://www.foxnews.com/politics/gop-candidates-condemn-biden-pride-event-elicit-mishap-white-house](https://www.foxnews.com/politics/gop-candidates-condemn-biden-pride-event-elicit-mishap-white-house)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 07:30:12+00:00

Republican presidential candidates are taking aim at the Biden administration over its elicit White House Pride event that included topless trans activists.

## GOP candidates condemn Biden for illicit mishap during White House Pride event: 'Very revealing'
 - [https://www.foxnews.com/politics/gop-candidates-condemn-biden-pride-event-illicit-mishap-white-house](https://www.foxnews.com/politics/gop-candidates-condemn-biden-pride-event-illicit-mishap-white-house)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 07:30:12+00:00

Republican presidential candidates are taking aim at the Biden administration over its illicit White House Pride event that included topless trans activists.

## Rhode Island lawmakers approve bill to replace lead pipes across the state
 - [https://www.foxnews.com/politics/rhode-island-lawmakers-approve-bill-replace-lead-pipes-across-state](https://www.foxnews.com/politics/rhode-island-lawmakers-approve-bill-replace-lead-pipes-across-state)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 07:22:34+00:00

Lawmakers in Rhode Island approved a bill that would require the replacement of lead pipes across the state. The replacements would take place over the next ten years.

## President Biden set to speak at summit to mark anniversary of federal gun safety legislation
 - [https://www.foxnews.com/us/president-biden-set-speak-summit-mark-anniversary-federal-gun-safety-legislation](https://www.foxnews.com/us/president-biden-set-speak-summit-mark-anniversary-federal-gun-safety-legislation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 07:21:57+00:00

President Joe Biden is set to speak at a summit in Connecticut over a year after signing federal gun legislation in the wake of the Uvalde school massacre.

## NY teen pleads guilty to manslaughter after killing 4 passengers in high-speed crash
 - [https://www.foxnews.com/us/ny-teen-pleads-guilty-manslaughter-killing-4-passengers-high-speed-crash](https://www.foxnews.com/us/ny-teen-pleads-guilty-manslaughter-killing-4-passengers-high-speed-crash)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 07:21:09+00:00

The driver of a stolen SUV that killed four passengers during a high-speed chase has pleaded guilty to manslaughter. He is expected to be sentenced to 15 months to four years in prison.

## Arizona death row inmate released after spending 29 years in prison
 - [https://www.foxnews.com/us/arizona-death-row-inmate-released-spending-29-years-prison](https://www.foxnews.com/us/arizona-death-row-inmate-released-spending-29-years-prison)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 07:20:15+00:00

After spending 29 years behind bars, a death row inmate in Arizona has been released from prison. The man’s convictions in the 1994 death of a 4-year-old child was thrown out in a deal.

## 27-year-old Philadelphia subway security guard shot on train
 - [https://www.foxnews.com/us/27-year-old-philadelphia-subway-security-guard-shot-train](https://www.foxnews.com/us/27-year-old-philadelphia-subway-security-guard-shot-train)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 07:18:52+00:00

A 27-year-old employee of Scotlandyard Security Services was shot and wounded on a Philadelphia-area train. It is unclear whether there were any witnesses to the shooting.

## Gift guide for the fisherman dad on Father's Day: Tackle bags, coolers, lures and more
 - [https://www.foxnews.com/lifestyle/fishing-trip-fathers-day-gifts](https://www.foxnews.com/lifestyle/fishing-trip-fathers-day-gifts)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 07:08:30+00:00

There are plenty of fishing-related items you can buy for Father&apos;s Day for the dad who loves a good bite, from the smallest lure to the flashiest kayak and everything in between.

## US Open fan ejected from course after heckling Phil Mickelson
 - [https://www.foxnews.com/sports/us-open-fan-ejected-course-heckling-phil-mickelson](https://www.foxnews.com/sports/us-open-fan-ejected-course-heckling-phil-mickelson)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 07:05:41+00:00

Phil Mickelson faced some LIV Golf heckling on Thursday afternoon during the first round of the U.S. Open at the Los Angeles County Club.

## Experts break down how Bud Light lost its top-selling beer status: 'Betrayal'
 - [https://www.foxnews.com/media/experts-break-down-how-bud-light-reportedly-lost-top-selling-beer-status-betrayal](https://www.foxnews.com/media/experts-break-down-how-bud-light-reportedly-lost-top-selling-beer-status-betrayal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 07:00:05+00:00

Experts are pointing to falling interest in Bud Light spanning decades and broken trust as some of the possible reasons for the beer brand&apos;s falling sales.

## Utah news anchors feel 'duped' by children's book author accused of murdering husband
 - [https://www.foxnews.com/us/utah-news-anchors-feel-duped-childrens-book-author-accused-murdering-husband](https://www.foxnews.com/us/utah-news-anchors-feel-duped-childrens-book-author-accused-murdering-husband)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 07:00:05+00:00

The hosts of &quot;Good Things Utah&quot; discuss their April interview with children&apos;s book author Kouri Richins, who is accused of killing her husband last year.

## Former California cop sends powerful message to Gavin Newsom: There are no words for the horrors I saw
 - [https://www.foxnews.com/media/former-california-cop-sends-powerful-message-gavin-newsom-words-horrors-saw](https://www.foxnews.com/media/former-california-cop-sends-powerful-message-gavin-newsom-words-horrors-saw)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 07:00:02+00:00

Former Oceanside police officer Rick Campbell argues the state is taking the wrong approach to mitigating the homeless crisis as drug use runs rampant.

## San Francisco mayor's rebuke over 'punitive' drug policies, Meghan and Harry shunned and more top headlines
 - [https://www.foxnews.com/us/san-francisco-mayors-rebuke-over-punitive-drug-policies-meghan-and-harry-shunned](https://www.foxnews.com/us/san-francisco-mayors-rebuke-over-punitive-drug-policies-meghan-and-harry-shunned)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 06:59:04+00:00

San Francisco mayor&apos;s rebuke over &apos;punitive&apos; drug policies, Meghan and Harry shunned and more top headlines

## Colorado's Deion Sanders slapped with harsh reality of possibly losing foot
 - [https://www.foxnews.com/sports/colorados-deion-sanders-slapped-harsh-reality-losing-foot](https://www.foxnews.com/sports/colorados-deion-sanders-slapped-harsh-reality-losing-foot)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 06:58:27+00:00

Deion Sanders was faced with the possibility of losing his foot as doctors told him the risks of not relaxing in the offseason. Sanders is the head coach of Colorado.

## Democrat-run Minnesota quietly agrees to stop enforcing 'anti-religious' law in win for Christian schools
 - [https://www.foxnews.com/politics/democrat-run-minnesota-quietly-agrees-stop-enforcing-anti-religious-law-win-christian-schools](https://www.foxnews.com/politics/democrat-run-minnesota-quietly-agrees-stop-enforcing-anti-religious-law-win-christian-schools)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 06:50:38+00:00

Minnesota&apos;s Department of Education agreed to an injunction after Christian parents and schools sued, which the Becket Fund says could be a step toward striking down an &quot;anti-religious law&quot;

## Umpire ejects 3 Rangers members during bizarre altercation following questionable strikeout
 - [https://www.foxnews.com/sports/umpire-ejects-3-rangers-members-bizarre-altercation-questionable-strikeout](https://www.foxnews.com/sports/umpire-ejects-3-rangers-members-bizarre-altercation-questionable-strikeout)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 06:49:36+00:00

Texas Rangers manager Bruce Bochy, pitching coach Mike Maddux and second baseman Marcus Semien were all ejected in the matter of moments in a bizarre situation on Thursday night.

## Rays pitcher Pete Fairbanks returns from the IL with a black eye after his son dunked on him
 - [https://www.foxnews.com/sports/tampa-bay-rays-pitcher-pete-fairbanks-returns-il-black-eye](https://www.foxnews.com/sports/tampa-bay-rays-pitcher-pete-fairbanks-returns-il-black-eye)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 06:42:54+00:00

Rays reliever Pete Fairbanks rejoined the team this week with a welt under his right eye. The injury was a result of his decision to play basketball in a swimming pool.

## Ray Lewis III, son of NFL legend Ray Lewis, dead at 28
 - [https://www.foxnews.com/sports/ray-lewis-iii-son-nfl-legend-ray-lewis-dead](https://www.foxnews.com/sports/ray-lewis-iii-son-nfl-legend-ray-lewis-dead)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 06:33:22+00:00

Ray Lewis III, the son of Pro Football Hall of Famer Ray Lewis, has died, according to his family. The cause of death was unclear. He was 28 years old.

## Denise Austin, 66, shares workouts that are 'under 10 minutes' to get in bikini-ready shape for summer
 - [https://www.foxnews.com/entertainment/denise-austin-workouts-under-10-minutes-bikini-ready-shape-summer](https://www.foxnews.com/entertainment/denise-austin-workouts-under-10-minutes-bikini-ready-shape-summer)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 06:25:23+00:00

Fitness guru Denise Austin, 66, shared several quick workouts this week targeting different areas of the body to get ready for summer bikini season.

## New Supreme Court poll reveals Americans’ clear message to Congress
 - [https://www.foxnews.com/opinion/supreme-court-poll-reveals-americans-clear-message-congress](https://www.foxnews.com/opinion/supreme-court-poll-reveals-americans-clear-message-congress)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 06:00:49+00:00

New Supreme Court poll reveals Americans’ clear message to Congress – leave judiciary alone. Left’s ethics claims and other attacks don’t resonate with voters.

## How to go paperless by turning your phone into a portable scanner
 - [https://www.foxnews.com/tech/paperless-turning-phone-portable-scanner](https://www.foxnews.com/tech/paperless-turning-phone-portable-scanner)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 06:00:17+00:00

Scanning your documents only requires your phone. Kurt &quot;CyberGuy&apos; Knutsson explains how to scan all your important documents on your iOS Notes app or Google Drive.

## US-Mexico semifinals sees 4 red cards, match forced to end early due to crowd's homophobic chants
 - [https://www.foxnews.com/sports/us-mexico-semifinals-sees-red-cards-match-forced-end-early-crowds-homophobic-chants](https://www.foxnews.com/sports/us-mexico-semifinals-sees-red-cards-match-forced-end-early-crowds-homophobic-chants)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 05:35:52+00:00

The United States Men’s National Soccer Team&apos;s 3-0 victory over Mexico was riddled with fouls and four red cards were given in the contest. They will play Canada in the finals.

## 'The View's' outrage over climate activists vandalizing Monet work ridiculed: 'Performance art'
 - [https://www.foxnews.com/media/the-view-outrage-climate-activists-vandalizing-monet-work-performance-art-gutfeld](https://www.foxnews.com/media/the-view-outrage-climate-activists-vandalizing-monet-work-performance-art-gutfeld)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 05:30:55+00:00

The panel on ABC&apos;s &quot;The View&quot; sounded off against global warming protesters who vandalized a priceless 1900 Monet painting to bring awareness to climate change.

## Leading activist slams Dems for dragging feet on reparations: Black vote 'is an exchange, not a gift'
 - [https://www.foxnews.com/politics/leading-activist-slams-dems-dragging-feet-reparations-black-vote-exchange-not-gift](https://www.foxnews.com/politics/leading-activist-slams-dems-dragging-feet-reparations-black-vote-exchange-not-gift)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 05:00:56+00:00

Democrats are letting down Black voters at the federal level with the help of &quot;relic&quot; advocacy groups that refuse to confront them, according to a leading reparations activist.

## ‘Grease’ celebrates 45th anniversary: Behind-the-scenes secrets of iconic musical
 - [https://www.foxnews.com/entertainment/grease-celebrates-45th-anniversary-behind-the-scenes-secrets-iconic-musical](https://www.foxnews.com/entertainment/grease-celebrates-45th-anniversary-behind-the-scenes-secrets-iconic-musical)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 05:00:40+00:00

It’s been 45 years since the musical “Grease&quot; starring Olivia Newton-John as Sandy and John Travolta as Danny stole our hearts.

## Biden torched for 'testy' response on Ukraine FBI informant file: 'Dangerous time to tell the truth'
 - [https://www.foxnews.com/media/biden-torched-testy-response-ukraine-fbi-informant-file-dangerous-time-tell-truth](https://www.foxnews.com/media/biden-torched-testy-response-ukraine-fbi-informant-file-dangerous-time-tell-truth)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 05:00:35+00:00

President Biden was slammed on Thursday after he berated a reporter for asking him about his alleged corrupt business dealings with Ukraine while vice president.

## Police officer crowned Miss Arizona USA hopes to 'bridge the gap' between law enforcement and the public
 - [https://www.foxnews.com/media/police-officer-crowned-miss-arizona-usa-hopes-bridge-gap-law-enforcement-public](https://www.foxnews.com/media/police-officer-crowned-miss-arizona-usa-hopes-bridge-gap-law-enforcement-public)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 05:00:19+00:00

Miss Arizona USA Candace Kanavel hopes her title will empower young women and help rebuild the strained relationship between law enforcement and communities nationwide.

## Mayor’s rebuke could signal end of 'Democratic Socialist, radical politicking' in this city, activist says
 - [https://www.foxnews.com/politics/mayors-rebuke-signal-end-democratic-socialist-radical-politicking-city-activist-says](https://www.foxnews.com/politics/mayors-rebuke-signal-end-democratic-socialist-radical-politicking-city-activist-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 04:00:57+00:00

The San Francisco mayor&apos;s clash with a city official over drug policies could signal a tone shift in the deeply blue city, one cautiously-optimistic activist says.

## The real cause behind Jordan Neely case and it’s not race
 - [https://www.foxnews.com/opinion/real-cause-behind-jordan-neely-case-race](https://www.foxnews.com/opinion/real-cause-behind-jordan-neely-case-race)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 04:00:33+00:00

The real cause behind the Jordan Neely case and it’s not race. Subway strangulation incident reveals divide between elites and ordinary people who must cope with subway crime.

## CNN fact-checks Trump, Republicans overwhelmingly more than Biden
 - [https://www.foxnews.com/media/cnn-fact-checks-trump-republicans-overwhelmingly-biden](https://www.foxnews.com/media/cnn-fact-checks-trump-republicans-overwhelmingly-biden)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 04:00:30+00:00

CNN&apos;s Facts First section is so tilted toward fact-checking Republican claims, every current article under &quot;Biden White House&quot; is about Donald Trump.

## Las Vegas police, SWAT respond after man kidnaps female victim at gunpoint, barricades inside home
 - [https://www.foxnews.com/us/las-vegas-police-swat-respond-man-kidnaps-female-victim-gunpoint-barricades-inside-home](https://www.foxnews.com/us/las-vegas-police-swat-respond-man-kidnaps-female-victim-gunpoint-barricades-inside-home)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 03:23:19+00:00

SWAT and Las Vegas police officers responded to the home where a suspect has barricade himself inside with a female victim, who he allegedly kidnapped at gunpoint.

## Meet the American who founded Father's Day, Sonora Smart Dodd, daughter of Civil War veteran and devoted dad
 - [https://www.foxnews.com/lifestyle/meet-american-founded-fathers-day-sonora-smart-dodd-daughter-civil-war-veteran-dad](https://www.foxnews.com/lifestyle/meet-american-founded-fathers-day-sonora-smart-dodd-daughter-civil-war-veteran-dad)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 03:00:40+00:00

Sonora Smart Dodd, the daughter of a twice-widowed Civil War veteran dad, was inspired by his example to found the first Father&apos;s Day in Spokane, Washington.

## China wants to militarize AI and Big Tech firms might not even be on our side
 - [https://www.foxnews.com/opinion/china-wants-militarize-ai-tech-firms-might-not-side](https://www.foxnews.com/opinion/china-wants-militarize-ai-tech-firms-might-not-side)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 02:00:49+00:00

China wants to militarize AI and Big Tech firms might not even be on our side in case of a confrontation. Tech companies prefer to profit off of Chinese projects.

## AI program flags Chinese products allegedly linked to Uyghur forced labor: 'Not coincidence, it's a strategy'
 - [https://www.foxnews.com/world/ai-program-flags-chinese-products-allegedly-linked-uyghur-forced-labor-not-coincidence-strategy](https://www.foxnews.com/world/ai-program-flags-chinese-products-allegedly-linked-uyghur-forced-labor-not-coincidence-strategy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 02:00:16+00:00

Ultra founder and CEO Ram Ben Tzion flagged Temu as a deliberate effort to bypass trade laws that would refuse Chinese products potentially made by Uyghur forced labor.

## Israel government minister slams George Soros for funding groups 'demonizing' Jewish state
 - [https://www.foxnews.com/world/israel-government-minister-amichai-chikli-slams-george-soros-funding-groups-demonizing-jewish-state](https://www.foxnews.com/world/israel-government-minister-amichai-chikli-slams-george-soros-funding-groups-demonizing-jewish-state)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 02:00:04+00:00

Amid a rise of international antisemitism, the son of George Soros, Alex, is under fire for following his father’s footsteps to fund anti-Israel NGOs that demonize the Jewish state.

## Trooping the Colour: Prince Harry, Meghan Markle shunned by royals after 'litany of attacks,' expert claims
 - [https://www.foxnews.com/entertainment/trooping-colour-prince-harry-meghan-markle-shunned-royals-litany-attacks-expert](https://www.foxnews.com/entertainment/trooping-colour-prince-harry-meghan-markle-shunned-royals-litany-attacks-expert)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 02:00:03+00:00

Prince Harry and Meghan Markle, the Duke and Duchess of Sussex, will reportedly stay in Montecito, California, instead of attending King Charles&apos; birthday parade.

## House Dems will use rare procedural maneuver to force Republicans to vote on abortion rights
 - [https://www.foxnews.com/politics/house-dems-use-rare-procedural-maneuver-force-republicans-vote-abortion-rights](https://www.foxnews.com/politics/house-dems-use-rare-procedural-maneuver-force-republicans-vote-abortion-rights)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 01:57:50+00:00

House Democrats are set to use a procedural maneuver next week that could force a vote on codifying abortion rights after the Supreme Court overturned Roe v. Wade.

## GREG GUTFELD: Democrats' New York City is a criminal safe haven
 - [https://www.foxnews.com/opinion/greg-gutfeld-democrats-new-york-city-criminal-safe-haven](https://www.foxnews.com/opinion/greg-gutfeld-democrats-new-york-city-criminal-safe-haven)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 00:33:32+00:00

Fox News host Greg Gutfeld criticized New York Democrats for the surging crime crisis in Manhattan and gave his take on Marine veteran Daniel Penny on &quot;Gutfeld!&quot;

## SEAN HANNITY: Is Biden in danger of losing the first two primaries?
 - [https://www.foxnews.com/media/sean-hannity-biden-danger-losing-first-two-primaries](https://www.foxnews.com/media/sean-hannity-biden-danger-losing-first-two-primaries)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 00:12:15+00:00

Fox News host Sean Hannity discusses the increasing competition from rival 2024 presidential Democratic candidates on &quot;Hannity&quot; and how they could affect President Biden.

## GOP Senators demand accountability from Biden after China committed 'flagrant violation of US sovereignty'
 - [https://www.foxnews.com/politics/gop-senators-demand-accountability-biden-china-committed-flagrant-violation-us-sovereignty](https://www.foxnews.com/politics/gop-senators-demand-accountability-biden-china-committed-flagrant-violation-us-sovereignty)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 00:03:26+00:00

Sens. Marco Rubio, Roger Wicker and others are demanding President Biden give Congress an assessment on the Chinese spy balloon that floated across the country in Feb.

## On this day in history, June 16, 1884, first American roller coaster opens at Coney Island
 - [https://www.foxnews.com/lifestyle/this-day-history-june-16-1884-first-american-roller-coaster-opens-coney-island](https://www.foxnews.com/lifestyle/this-day-history-june-16-1884-first-american-roller-coaster-opens-coney-island)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-16 00:02:45+00:00

The first roller coaster ride in America opened at Coney Island, in Brooklyn, New York, on this day in history, June 16, 1884. The coaster traveled about six miles an hour and cost just 5 cents.

