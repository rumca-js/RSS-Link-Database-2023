# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## Szef sztabu wyborczego Prawa i Sprawiedliwości rezygnuje
 - [https://tvn24.pl/polska/tomasz-poreba-zrezygnowal-z-funkcji-szefa-sztabu-wyborczego-pis-7178954?source=rss](https://tvn24.pl/polska/tomasz-poreba-zrezygnowal-z-funkcji-szefa-sztabu-wyborczego-pis-7178954?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 21:36:46+00:00

<img alt="Szef sztabu wyborczego Prawa i Sprawiedliwości rezygnuje" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3ecbzj-pap_20230328_0ki-7171927/alternates/LANDSCAPE_1280" />
    Informację przekazał w mediach społecznościowych.

## Oceniamy Polaków za mecz z Niemcami
 - [https://eurosport.tvn24.pl/pilka-nozna/miedzynarodowe-mecze-towarzyskie/2023/polska-niemcy-oceny-polakow-za-mecz-towarzyski-w-warszawie_sto9662233/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/miedzynarodowe-mecze-towarzyskie/2023/polska-niemcy-oceny-polakow-za-mecz-towarzyski-w-warszawie_sto9662233/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 20:59:00+00:00

<img alt="Oceniamy Polaków za mecz z Niemcami" src="https://tvn24.pl/najnowsze/cdn-zdjecie-oi28e4-polska-niemcy-7178951/alternates/LANDSCAPE_1280" />
    Jeden wybitny występ, kilka bardzo dobrych.

## Najpierw łzy, a potem niespodzianka z Niemcami
 - [https://eurosport.tvn24.pl/pilka-nozna/miedzynarodowe-mecze-towarzyskie/2023/polska-niemcy-wynik-meczu-i-relacja_sto9662209/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/miedzynarodowe-mecze-towarzyskie/2023/polska-niemcy-wynik-meczu-i-relacja_sto9662209/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 20:47:00+00:00

<img alt="Najpierw łzy, a potem niespodzianka z Niemcami" src="https://tvn24.pl/najnowsze/cdn-zdjecie-45kyi-polacy-pokonali-niemcow-w-warszawie-7178947/alternates/LANDSCAPE_1280" />
    Wymarzony wieczór na PGE Narodowym.

## Putin szuka sojuszników
 - [https://fakty.tvn24.pl/fakty-o-swiecie/putin-szuka-sojusznikow-goscil-premiera-kuby-a-prezydent-algierii-podpisal-dokument-o-strategicznym-partnerstwie-7178850?source=rss](https://fakty.tvn24.pl/fakty-o-swiecie/putin-szuka-sojusznikow-goscil-premiera-kuby-a-prezydent-algierii-podpisal-dokument-o-strategicznym-partnerstwie-7178850?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 20:14:08+00:00

<img alt="Putin szuka sojuszników" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-3ggr3l-loska-7178855/alternates/LANDSCAPE_1280" />
    Kuba, Algieria, Zambia czy Północna Korea - to państwa, z którymi Rosja chce rozwijać współpracę i dzięki ich poparciu stwarzać wrażenie, że nie jest osamotniona.

## Polacy zaskoczyli Niemców na Narodowym
 - [https://eurosport.tvn24.pl/pilka-nozna/miedzynarodowe-mecze-towarzyskie/2023/live-polska-niemcy_mtc1432467/live.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/miedzynarodowe-mecze-towarzyskie/2023/live-polska-niemcy_mtc1432467/live.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 19:34:00+00:00

<img alt="Polacy zaskoczyli Niemców na Narodowym" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xcgys3-robert-lewandowski-7178866/alternates/LANDSCAPE_1280" />
    Wynik i relacja na żywo w Eurosport.pl.

## Szpaler i morze łez. Kuba zwieńczył reprezentacyjną historię
 - [https://eurosport.tvn24.pl/pilka-nozna/miedzynarodowe-mecze-towarzyskie/2023/jakub-blaszczykowski-ze-lzami-w-oczach-skonczyl-kariere-reprezentacyjna_sto9662166/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/miedzynarodowe-mecze-towarzyskie/2023/jakub-blaszczykowski-ze-lzami-w-oczach-skonczyl-kariere-reprezentacyjna_sto9662166/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 19:24:00+00:00

<img alt="Szpaler i morze łez. Kuba zwieńczył reprezentacyjną historię" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kab42q-jakub-blaszczykowski-zegnany-przez-reprezentacje-polski-te-scene-zapamietamy-na-lata-7178857/alternates/LANDSCAPE_1280" />
    Tak odchodzą tylko legendy.

## "Na skutek tego, co się w Polsce dzieje", jest wniosek "o pełną obserwację OBWE w trakcie wyborów"
 - [https://tvn24.pl/polska/roza-thun-w-parlamencie-europejskim-zlozono-wniosek-o-pelna-obserwacje-obwe-w-polsce-w-trakcie-wyborow-7178787?source=rss](https://tvn24.pl/polska/roza-thun-w-parlamencie-europejskim-zlozono-wniosek-o-pelna-obserwacje-obwe-w-polsce-w-trakcie-wyborow-7178787?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 18:40:59+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-nwmu1h-16-1925-fpf-cl-0029-7178758/alternates/LANDSCAPE_1280" />
    Europosłowie Róża Thun  i  Łukasz Kohut w "Faktach po Faktach"  o "lex Tusk".

## Oficjalny skład Polaków na mecz z Niemcami
 - [https://eurosport.tvn24.pl/pilka-nozna/miedzynarodowe-mecze-towarzyskie/2023/polska-niemcy-oficjalne-sklady-na-mecz-w-warszawie_sto9662118/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/miedzynarodowe-mecze-towarzyskie/2023/polska-niemcy-oficjalne-sklady-na-mecz-w-warszawie_sto9662118/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 17:54:00+00:00

<img alt="Oficjalny skład Polaków na mecz z Niemcami" src="https://tvn24.pl/najnowsze/cdn-zdjecie-sevve9-polscy-pilkarze-zagraja-z-niemcami-7178745/alternates/LANDSCAPE_1280" />
    Jakub Błaszczykowski u boku największych gwiazd.

## Trzęsienie ziemi we Francji. Uszkodzone budynki i drogi, utrudnienia w ruchu pociągów
 - [https://tvn24.pl/tvnmeteo/swiat/francja-trzesienie-ziemi-w-regionie-nowa-akwitania-7178695?source=rss](https://tvn24.pl/tvnmeteo/swiat/francja-trzesienie-ziemi-w-regionie-nowa-akwitania-7178695?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 17:41:15+00:00

<img alt="Trzęsienie ziemi we Francji. Uszkodzone budynki i drogi, utrudnienia w ruchu pociągów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-tbsjnp-mapa-francja-trzesienie-7178753/alternates/LANDSCAPE_1280" />
    Miało magnitudę około 5.

## Kilkadziesiąt osób ewakuowanych, jedna nie żyje po pożarze w bloku
 - [https://tvn24.pl/tvnwarszawa/praga-poludnie/warszawa-kilkadziesiat-osob-ewakuowanych-jedna-nie-zyje-tragiczny-pozar-w-bloku-na-kobielskiej-7178632?source=rss](https://tvn24.pl/tvnwarszawa/praga-poludnie/warszawa-kilkadziesiat-osob-ewakuowanych-jedna-nie-zyje-tragiczny-pozar-w-bloku-na-kobielskiej-7178632?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 17:36:54+00:00

<img alt="Kilkadziesiąt osób ewakuowanych, jedna nie żyje po pożarze w bloku" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6p64en-kilkadziesiat-osob-ewakuowanych-jedna-nie-zyje-tragiczny-pozar-na-kobielskiej-7178731/alternates/LANDSCAPE_1280" />
    Sprawę wyjaśni policja.

## Posłanka PiS na sejmowej trybunie, z sali okrzyki "oddaj mieszkanie!"
 - [https://tvn24.pl/polska/wystapienie-poslanki-pis-anny-paluch-zaklocone-przez-opozycje-krzyczeli-oddaj-mieszkanie-7178674?source=rss](https://tvn24.pl/polska/wystapienie-poslanki-pis-anny-paluch-zaklocone-przez-opozycje-krzyczeli-oddaj-mieszkanie-7178674?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 17:31:00+00:00

<img alt="Posłanka PiS na sejmowej trybunie, z sali okrzyki " src="https://tvn24.pl/najnowsze/cdn-zdjecie-g62q75-wystapienie-anny-paluch-w-sejmie-zaklocone-okrzykami-opozycji-7178671/alternates/LANDSCAPE_1280" />
    Anna Paluch od lat 90. zajmuje mieszkanie komunalne, płaci za nie 116 złotych miesięcznie.

## Kilka lat śledztwa, później proces. Sąd orzekł w sprawie nieprawidłowości w kancelarii prezydenta Komorowskiego
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-sad-orzekl-wsprawie-nieprawidlowosci-wkancelarii-prezydenta-komorowskiego-7178566?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-sad-orzekl-wsprawie-nieprawidlowosci-wkancelarii-prezydenta-komorowskiego-7178566?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 17:11:52+00:00

<img alt="Kilka lat śledztwa, później proces. Sąd orzekł w sprawie nieprawidłowości w kancelarii prezydenta Komorowskiego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-nnqyrz-rezydencja-prezydencka-w-klarysewie-7178624/alternates/LANDSCAPE_1280" />
    Nieprawomocna decyzja.

## LOT ma nowego prezesa
 - [https://tvn24.pl/biznes/z-kraju/lot-ma-nowego-prezesa-7178673?source=rss](https://tvn24.pl/biznes/z-kraju/lot-ma-nowego-prezesa-7178673?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 17:10:03+00:00

<img alt="LOT ma nowego prezesa" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rn80ah-pll-lot-samolot-7164122/alternates/LANDSCAPE_1280" />
    Poinformował w piątek narodowy przewoźnik.

## Sejm zdecydował w sprawie prezydenckiej nowelizacji "lex Tusk"
 - [https://tvn24.pl/polska/lex-tusk-sejm-przyjal-prezydencka-nowelizacje-ustawy-w-sprawie-komisji-do-spraw-badania-wplywow-rosyjskich-7178317?source=rss](https://tvn24.pl/polska/lex-tusk-sejm-przyjal-prezydencka-nowelizacje-ustawy-w-sprawie-komisji-do-spraw-badania-wplywow-rosyjskich-7178317?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 17:06:34+00:00

<img alt="Sejm zdecydował w sprawie prezydenckiej nowelizacji " src="https://tvn24.pl/najnowsze/cdn-zdjecie-afbto-sejm-7178578/alternates/LANDSCAPE_1280" />
    Teraz trafi do Senatu.

## Posłowie za zmianą przepisów dotyczących płatności gotówką
 - [https://tvn24.pl/biznes/dlafirm/limit-platnosci-gotowka-poslowie-za-zmiana-przepisow-7178660?source=rss](https://tvn24.pl/biznes/dlafirm/limit-platnosci-gotowka-poslowie-za-zmiana-przepisow-7178660?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 16:58:15+00:00

<img alt="Posłowie za zmianą przepisów dotyczących płatności gotówką" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hwx9w5-zaklad-ubezpieczen-spolecznych-oglosil-kiedy-rusza-wyplaty-swiadczenia-dobry-start-czyli-tak-zwanego-300-plus-5778252/alternates/LANDSCAPE_1280" />
    Głosowanie w Sejmie.

## "Nikt nas nie zastraszy, nikt nie zagłuszy. Tej siły, tej fali nikt już nie zatrzyma"
 - [https://tvn24.pl/polska/wiec-donalda-tuska-w-poznaniu-lider-po-tej-sily-tej-fali-nikt-juznie-zatrzyma-7178334?source=rss](https://tvn24.pl/polska/wiec-donalda-tuska-w-poznaniu-lider-po-tej-sily-tej-fali-nikt-juznie-zatrzyma-7178334?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 16:55:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hwenem-donald-tusk-7178670/alternates/LANDSCAPE_1280" />
    Donald Tusk, lider PO, na wiecu w Poznaniu.

## Miały powstać słynne promy, ale rezultatów nie ma. "Duży znak zapytania jest po stronie finansowej"
 - [https://fakty.tvn24.pl/fakty-po-poludniu/mialy-powstac-slynne-promy-ale-rezultatow-nadal-nie-ma-duzy-znak-zapytania-jest-po-stronie-finansowej-7178621?source=rss](https://fakty.tvn24.pl/fakty-po-poludniu/mialy-powstac-slynne-promy-ale-rezultatow-nadal-nie-ma-duzy-znak-zapytania-jest-po-stronie-finansowej-7178621?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 16:45:56+00:00

<img alt="Miały powstać słynne promy, ale rezultatów nie ma. " src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-2z12mh-morawiecki-7178627/alternates/LANDSCAPE_1280" />
    Niekończące się problemy ma PiS ze zrealizowaniem obietnicy budowania promów w szczecińskiej stoczni.

## "Dość niewidzialnych dzieci, które krzyczą niemym krzykiem"
 - [https://fakty.tvn24.pl/najnowsze/ustawa-antyprzemocowa-w-sejmie-dosc-niewidzialnych-dzieci-ktore-krzycza-niemym-krzykiem-7178530?source=rss](https://fakty.tvn24.pl/najnowsze/ustawa-antyprzemocowa-w-sejmie-dosc-niewidzialnych-dzieci-ktore-krzycza-niemym-krzykiem-7178530?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 15:51:39+00:00

<img alt="" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-8n8tmv-ustawa-antyprzemocowa-w-sejmie-7178544/alternates/LANDSCAPE_1280" />
    W Sejmie ruszyły prace nad ustawą chroniącą dzieci.

## Trump "przerażony". "Grozi mu kilkaset lat więzienia"
 - [https://tvn24.pl/go/programy,7/rozmowy-na-szczycie-odcinki,692593/odcinek-67,S00E67,1092456?source=rss](https://tvn24.pl/go/programy,7/rozmowy-na-szczycie-odcinki,692593/odcinek-67,S00E67,1092456?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 15:42:45+00:00

<img alt="Trump " src="https://tvn24.pl/najnowsze/cdn-zdjecie-da3psp-trump-enex-7173745/alternates/LANDSCAPE_1280" />
    Donald Trump jest pierwszym byłym prezydentem USA, który został formalnie aresztowany.

## "Kolejna partia nowoczesnego uzbrojenia" w Polsce
 - [https://tvn24.pl/polska/wojsko-polskie-kolejne-czolgi-k2-black-panther-dotarly-dopolski-z-korei-poludniowej-mon-informuje-7178522?source=rss](https://tvn24.pl/polska/wojsko-polskie-kolejne-czolgi-k2-black-panther-dotarly-dopolski-z-korei-poludniowej-mon-informuje-7178522?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 15:29:36+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kw4z8w-czolgi-k2-black-panther-7178532/alternates/LANDSCAPE_1280" />
    Przekazało Ministerstwo Obrony Narodowej.

## Zasnęła za kierownicą, samochód spadł z urwiska. Nie żyją cztery osoby
 - [https://tvn24.pl/swiat/usa-samochod-spadl-z-urwiska-nastolatka-za-kierownica-zasnela-ze-zmeczenia-zginely-cztery-osoby-7178436?source=rss](https://tvn24.pl/swiat/usa-samochod-spadl-z-urwiska-nastolatka-za-kierownica-zasnela-ze-zmeczenia-zginely-cztery-osoby-7178436?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 15:22:02+00:00

<img alt="Zasnęła za kierownicą, samochód spadł z urwiska. Nie żyją cztery osoby" src="https://tvn24.pl/najnowsze/cdn-zdjecie-g1xl20-mundurowi-zatrzymali-kierowce-do-kontroli-zdjecie-ilustracyjne-7158897/alternates/LANDSCAPE_1280" />
    "Zmęczenie za kierownicą zabija".

## Tłum podpalił dom ministra. W tle starcia grup etnicznych
 - [https://tvn24.pl/swiat/indie-podpalono-dom-ministra-w-stanie-manipur-trwajawalki-grup-etnicznych-7178472?source=rss](https://tvn24.pl/swiat/indie-podpalono-dom-ministra-w-stanie-manipur-trwajawalki-grup-etnicznych-7178472?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 15:16:42+00:00

<img alt="Tłum podpalił dom ministra. W tle starcia grup etnicznych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2f60p-tlum-podpalil-dom-indyjskiego-ministra-7178525/alternates/LANDSCAPE_1280" />
    W indyjskim stanie Manipur.

## Prezydent wysłał pierwszą wersję "lex Tusk" do Trybunału Konstytucyjnego
 - [https://tvn24.pl/polska/lex-tusk-prezydent-skierowal-do-trybunalu-konstytucyjnego-wniosek-w-sprawie-ustawy-o-rosyjskich-wplywach-7178500?source=rss](https://tvn24.pl/polska/lex-tusk-prezydent-skierowal-do-trybunalu-konstytucyjnego-wniosek-w-sprawie-ustawy-o-rosyjskich-wplywach-7178500?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 15:05:32+00:00

<img alt="Prezydent wysłał pierwszą wersję " src="https://tvn24.pl/najnowsze/cdn-zdjecie-xnzsz1-andrzej-duda-7146530/alternates/LANDSCAPE_1280" />
    Zgodnie z zapowiedzią.

## Porwanie, brutalne zabójstwo biznesmena i przejażdżka kradzionym samochodem. Ruszył proces
 - [https://tvn24.pl/tvnwarszawa/wawer/warszawa-brutalne-zabojstwo-biznesmena-z-anina-poczatek-procesu-7178487?source=rss](https://tvn24.pl/tvnwarszawa/wawer/warszawa-brutalne-zabojstwo-biznesmena-z-anina-poczatek-procesu-7178487?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 15:04:12+00:00

<img alt="Porwanie, brutalne zabójstwo biznesmena i przejażdżka kradzionym samochodem. Ruszył proces " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-8dm7q-ruszyl-proces-ws-zabojstwa-78-letniego-biznesmena-w-wawrze-7178514/alternates/LANDSCAPE_1280" />
    Pierwsza rozprawa po śmierci biznesmena z Anina.

## "Proszę zobaczyć, wszędzie krew", "to była rzeź". Po zabójstwie dzieci nie wrócą do domu dziecka
 - [https://tvn24.pl/premium/domy-dziecka-mialy-znikac-a-wybuduja-nowy-bo-to-byla-rzez-7175793?source=rss](https://tvn24.pl/premium/domy-dziecka-mialy-znikac-a-wybuduja-nowy-bo-to-byla-rzez-7175793?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 14:50:51+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-s3hmis-zabojca-dostal-sie-do-budynku-przez-jedno-z-okien-7177706/alternates/LANDSCAPE_1280" />
    Na zdjęciach pokazuje mi zakrwawione dzieci w piżamkach. - Proszę zobaczyć, wszędzie krew. Nasza koleżanka Asia ratowała Adama, a on krzyczał, że ma reanimować Tobiasza. Tego, który w szyję dostał. Co te dzieci tam przeżyły… - mówi Alicja, była wychowanka placówki i siostra chłopca, który ucierpiał w ataku nożownika w Tomisławicach.

## Każdy był skazany na dożywocie albo śmierć. "Nie liczyłem na to, że mnie wypuszczą"
 - [https://tvn24.pl/go/programy,7/tylko-w-tvn24-go-odcinki,283316/odcinek-3179,S00E3179,1092451?source=rss](https://tvn24.pl/go/programy,7/tylko-w-tvn24-go-odcinki,283316/odcinek-3179,S00E3179,1092451?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 14:46:11+00:00

<img alt="Każdy był skazany na dożywocie albo śmierć. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-k8qhxe-obronca-azowstalu-7178493/alternates/LANDSCAPE_1280" />
    Ihor Mykhailow to ukraiński bohater, który bronił Azowstalu w Mariupolu. Spędził prawie rok w rosyjskiej niewoli.

## Będzie gorąco, ale to tylko wstęp do żaru, który zbliża się do Polski
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-upaly-ida-do-polski-kiedy-sie-ich-spodziewac-prognoza-na-5-dni-7178387?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-upaly-ida-do-polski-kiedy-sie-ich-spodziewac-prognoza-na-5-dni-7178387?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 14:34:48+00:00

<img alt="Będzie gorąco, ale to tylko wstęp do żaru, który zbliża się do Polski" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-pm8ebo-upal-w-polsce-goraco-7166689/alternates/LANDSCAPE_1280" />
    Prognoza pogody na pięć dni.

## Bank liczy skutki wyroku TSUE. Zarząd spodziewa się zysku
 - [https://tvn24.pl/biznes/z-kraju/wyrok-tsue-w-sprawie-kredytow-frankowych-bank-millennium-szacuje-skutki-7178301?source=rss](https://tvn24.pl/biznes/z-kraju/wyrok-tsue-w-sprawie-kredytow-frankowych-bank-millennium-szacuje-skutki-7178301?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 14:15:02+00:00

<img alt="Bank liczy skutki wyroku TSUE. Zarząd spodziewa się zysku" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5iavlk-shutterstock_1580432215-7178452/alternates/LANDSCAPE_1280" />
    W drugim kwartale 2023 roku.

## Inflacja i efekt cappuccino. Jeden z ulubionych kierunków polskich turystów coraz droższy
 - [https://tvn24.pl/swiat/wakacje-2023-urlop-w-chorwacji-coraz-drozszy-o-ile-wzrosly-ceny-hoteli-uslug-i-jedzenia-7177950?source=rss](https://tvn24.pl/swiat/wakacje-2023-urlop-w-chorwacji-coraz-drozszy-o-ile-wzrosly-ceny-hoteli-uslug-i-jedzenia-7177950?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 14:07:20+00:00

<img alt="Inflacja i efekt cappuccino. Jeden z ulubionych kierunków polskich turystów coraz droższy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ke6b28-chorwacja-6591597/alternates/LANDSCAPE_1280" />
    O ile wzrosły ceny jedzenia, hoteli i usług?

## Dwie osoby ranne w wypadku. Potężny korek na autostradzie A4 pod Krakowem
 - [https://tvn24.pl/krakow/krakow-wypadek-potezny-korek-i-utrudnienia-na-autostradzie-a4-sa-ranni-7178435?source=rss](https://tvn24.pl/krakow/krakow-wypadek-potezny-korek-i-utrudnienia-na-autostradzie-a4-sa-ranni-7178435?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 14:05:40+00:00

<img alt="Dwie osoby ranne w wypadku. Potężny korek na autostradzie A4 pod Krakowem" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-6idn6j-tragiczny-wypadek-pod-ostroleka-zginal-kierowca-zdj-ulustracyjne-7173342/alternates/LANDSCAPE_1280" />
    Według służb drogowych utrudnienia mają potrwać do około godziny 17.30.

## Składka ZUS mocno w górę. Wyliczenia
 - [https://tvn24.pl/biznes/dlafirm/skladka-zus-2024-o-ile-wzrosnie-ile-wyniesie-wyliczenia-7178283?source=rss](https://tvn24.pl/biznes/dlafirm/skladka-zus-2024-o-ile-wzrosnie-ile-wyniesie-wyliczenia-7178283?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 13:36:24+00:00

<img alt="Składka ZUS mocno w górę. Wyliczenia" src="https://tvn24.pl/najnowsze/cdn-zdjecie-njjmmz-doslownie-chwile-po-rozpoczeciu-zakonczyl-sie-w-poniedzialek-nabor-w-konkursie-grant-na-kapital-obrotowy-dla-mikro-i-malych-przedsiebiorstw-z-wojewodztwa-wielkopolskiego-4673016/alternates/LANDSCAPE_1280" />
    Wzrosną zarówno tzw. duży, jak i mały ZUS.

## Córka Przemysława Salety czeka na przeszczep. "Tu nic nie można przewidzieć"
 - [https://eurosport.tvn24.pl/boks/corka-przemyslawa-salety-czeka-na-przeszczep.-tu-nic-nie-mozna-przewidziec_sto9661511/story.shtml?source=rss](https://eurosport.tvn24.pl/boks/corka-przemyslawa-salety-czeka-na-przeszczep.-tu-nic-nie-mozna-przewidziec_sto9661511/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 13:28:21+00:00

<img alt="Córka Przemysława Salety czeka na przeszczep. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-lx697f-przemyslaw-saleta-7178379/alternates/LANDSCAPE_1280" />
    W 2007 roku tą historią żyła niemal cała Polska.

## Mumia sprzed trzech tysięcy lat znaleziona obok boiska. Najpierw zauważono włosy
 - [https://tvn24.pl/swiat/peru-mumia-sprzed-trzech-tysiecy-lat-znaleziona-obok-boiska-najpierw-zauwazono-wlosy-7177989?source=rss](https://tvn24.pl/swiat/peru-mumia-sprzed-trzech-tysiecy-lat-znaleziona-obok-boiska-najpierw-zauwazono-wlosy-7177989?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 13:24:04+00:00

<img alt="Mumia sprzed trzech tysięcy lat znaleziona obok boiska. Najpierw zauważono włosy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-e7q9th-mumia-zostala-odnaleziona-w-peruwianskiej-limie-7178035/alternates/LANDSCAPE_1280" />
    Szczątki należą prawdopodobnie do osoby, która została złożona w ofierze.

## Stoltenberg: Drzwi NATO są otwarte, Ukraina będzie członkiem. Rosja nie ma prawa weta
 - [https://tvn24.pl/swiat/jens-stoltenberg-drzwi-nato-sa-otwarte-ukraina-bedzie-czlonkiem-nato-7178295?source=rss](https://tvn24.pl/swiat/jens-stoltenberg-drzwi-nato-sa-otwarte-ukraina-bedzie-czlonkiem-nato-7178295?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 13:04:19+00:00

<img alt="Stoltenberg: Drzwi NATO są otwarte, Ukraina będzie członkiem. Rosja nie ma prawa weta" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8ql6n5-jens-stoltenberg-7178282/alternates/LANDSCAPE_1280" />
    Konferencja prasowa szefa NATO po spotkaniu ministrów obrony.

## Wybiegł z nożami do sąsiada. Jest nagranie z zajścia. Policja zatrzymała napastnika
 - [https://tvn24.pl/pomorze/chojnice-wybiegl-z-nozami-do-sasiada-zostal-zatrzymany-nagranie-7178063?source=rss](https://tvn24.pl/pomorze/chojnice-wybiegl-z-nozami-do-sasiada-zostal-zatrzymany-nagranie-7178063?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 12:58:20+00:00

<img alt="Wybiegł z nożami do sąsiada. Jest nagranie z zajścia. Policja zatrzymała napastnika" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qeodlu-noz-7178036/alternates/LANDSCAPE_1280" />
    Informację i film otrzymaliśmy na Kontakt 24.

## "Wjechał na rondo, nie stosując się do zasad obowiązujących na nim". 12-latka nie żyje
 - [https://tvn24.pl/tvnwarszawa/okolice/jozefoslaw-zarzuty-dla-kierowcy-autobusu-po-smiertelnym-potraceniu-12-latki-7178149?source=rss](https://tvn24.pl/tvnwarszawa/okolice/jozefoslaw-zarzuty-dla-kierowcy-autobusu-po-smiertelnym-potraceniu-12-latki-7178149?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 12:46:41+00:00

<img alt="" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-frciqp-potracenie-w-jozefoslawiu-7174675/alternates/LANDSCAPE_1280" />
    Zarzuty dla kierowcy autobusu miejskiego po wypadku w Józefosławiu.

## To mogło skończyć się tragicznie. "Nie mógł widzieć, czy z naprzeciwka jedzie inny pojazd". Nagranie
 - [https://tvn24.pl/katowice/sosnowiec-wyprzedzal-na-wzniesieniu-nie-mogl-widziec-czy-z-naprzeciwka-jedzie-inny-pojazd-nagranie-7178184?source=rss](https://tvn24.pl/katowice/sosnowiec-wyprzedzal-na-wzniesieniu-nie-mogl-widziec-czy-z-naprzeciwka-jedzie-inny-pojazd-nagranie-7178184?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 12:40:13+00:00

<img alt="To mogło skończyć się tragicznie. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-e4ic9t-wyprzedanie-na-wzniesieniu-i-podwojnej-ciaglej-7178154/alternates/LANDSCAPE_1280" />
    63-letni kierowca wyprzedzał na wzniesieniu.

## Brytyjka zmorą Polek
 - [https://eurosport.tvn24.pl/tenis/wta-nottingham/2023/turniej-wta-250-w-nottingham.-magdalena-frech-jodie-burrage-wynik-meczu-i-relacja-tenis_sto9661463/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/wta-nottingham/2023/turniej-wta-250-w-nottingham.-magdalena-frech-jodie-burrage-wynik-meczu-i-relacja-tenis_sto9661463/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 12:35:58+00:00

<img alt="Brytyjka zmorą Polek" src="https://tvn24.pl/najnowsze/cdn-zdjecie-e198xk-magdalena-frech-7178258/alternates/LANDSCAPE_1280" />
    Półfinał nie dla Fręch.

## "Rosyjskie rakiety to wiadomość dla Afryki: Rosja chce więcej wojny, a nie pokoju"
 - [https://tvn24.pl/swiat/ukraina-prezydent-rpa-i-inni-afrykanscy-przywodcy-odwiedzili-bucze-7178055?source=rss](https://tvn24.pl/swiat/ukraina-prezydent-rpa-i-inni-afrykanscy-przywodcy-odwiedzili-bucze-7178055?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 12:21:27+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-evw98d-prezydent-rpa-cyril-ramaphosa-w-podkijowskiej-buczy-7177998/alternates/LANDSCAPE_1280" />
    W dniu wizyty afrykańskich państw w Ukrainie Rosjanie dokonali kolejnego ataku rakietowego na Kijów.

## Plaga komarów w Chorwacji. "Ja już nie wychodzę na zewnątrz"
 - [https://tvn24.pl/tvnmeteo/swiat/chorwacja-plaga-komarow-owady-odstraszaja-turystow-7177751?source=rss](https://tvn24.pl/tvnmeteo/swiat/chorwacja-plaga-komarow-owady-odstraszaja-turystow-7177751?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 12:20:39+00:00

<img alt="Plaga komarów w Chorwacji. " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-8jidax-komary-7178004/alternates/LANDSCAPE_1280" />
    Wszystko przez ostatnie intensywne opady deszczu.

## Sfingował własną śmierć, po czym pojawił się na pogrzebie
 - [https://tvn24.pl/swiat/belgia-sfingowal-wlasna-smierc-po-czym-pojawil-sie-na-swoim-pogrzebie-7176780?source=rss](https://tvn24.pl/swiat/belgia-sfingowal-wlasna-smierc-po-czym-pojawil-sie-na-swoim-pogrzebie-7176780?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 12:17:40+00:00

<img alt="Sfingował własną śmierć, po czym pojawił się na pogrzebie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-m1wtt6-pogrzeb-trumna-s-shutterstock1467420857-5020559/alternates/LANDSCAPE_1280" />
    Chciał sprawdzić "kogo naprawdę obchodzi".

## Wyłowili kilkadziesiąt kilogramów śniętych ryb. "Do rzeki mogły spłynąć resztki chemii z pól"
 - [https://tvn24.pl/bialystok/wylowili-kilkadziesiat-kilogramow-snietych-ryb-inspektorzy-ochrony-srodowiska-ustalaja-co-sie-stalo-7178103?source=rss](https://tvn24.pl/bialystok/wylowili-kilkadziesiat-kilogramow-snietych-ryb-inspektorzy-ochrony-srodowiska-ustalaja-co-sie-stalo-7178103?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 12:06:21+00:00

<img alt="Wyłowili kilkadziesiąt kilogramów śniętych ryb. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-lo1ie4-w-rzece-padly-ryby-7178116/alternates/LANDSCAPE_1280" />
    Inspektorzy ochrony środowiska ustalają, co się stało.

## "Kuba był raczej zaskoczony, że go powołuję. Napisał SMS-a: Co ty robisz?"
 - [https://eurosport.tvn24.pl/pilka-nozna/miedzynarodowe-mecze-towarzyskie/2023/jakub-blaszczykowski-zegna-sie-z-reprezentacja.-jerzy-brzeczek-o-jego-najlepszych-i-najtrudniejszych_sto9661165/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/miedzynarodowe-mecze-towarzyskie/2023/jakub-blaszczykowski-zegna-sie-z-reprezentacja.-jerzy-brzeczek-o-jego-najlepszych-i-najtrudniejszych_sto9661165/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 12:04:50+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hqmkcv-brzeczek-powolywal-do-kadry-blaszczykowskiego-7178208/alternates/LANDSCAPE_1280" />
    Jerzy Brzęczek o reprezentacyjnych dokonaniach Kuby Błaszczykowskiego w rozmowie z eurosport.pl.

## Inflacja bazowa w maju. Dane NBP
 - [https://tvn24.pl/biznes/z-kraju/inflacja-bazowa-maj-2023-najnowsze-dane-nbp-7178186?source=rss](https://tvn24.pl/biznes/z-kraju/inflacja-bazowa-maj-2023-najnowsze-dane-nbp-7178186?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 12:01:54+00:00

<img alt="Inflacja bazowa w maju. Dane NBP" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kpym2e-pieniadze-portfel-kamil-zajaczkowski-shutterstock_1983178736-5524910/alternates/LANDSCAPE_1280" />
    Narodowy Bank Polski co miesiąc wylicza cztery wskaźniki inflacji bazowej, co pomaga zrozumieć charakter inflacji w Polsce.

## Legalny seks od 16., a nie od 13. roku życia. Japonia zmienia też definicję gwałtu
 - [https://tvn24.pl/swiat/japonia-wiek-zgody-podniesiony-do-16-lat-zmieniono-tez-definicje-gwaltu-7177837?source=rss](https://tvn24.pl/swiat/japonia-wiek-zgody-podniesiony-do-16-lat-zmieniono-tez-definicje-gwaltu-7177837?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 11:58:16+00:00

<img alt="Legalny seks od 16., a nie od 13. roku życia. Japonia zmienia też definicję gwałtu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-redko5-japonia-mlodzi-ludzie-japonczycy-7178057/alternates/LANDSCAPE_1280" />
    Zmiany wprowadzono w piątek.

## "Cała Wielkopolska na Placu Wolności". Wiec z udziałem Donalda Tuska dziś w Poznaniu
 - [https://tvn24.pl/polska/poznan-wiec-na-placu-wolnosci-zapowiedziany-przez-donalda-tuska-7178111?source=rss](https://tvn24.pl/polska/poznan-wiec-na-placu-wolnosci-zapowiedziany-przez-donalda-tuska-7178111?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 11:49:37+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-njtuyc-sk230602_0314350-7178102/alternates/LANDSCAPE_1280" />
    Zapowiedział go Donald Tusk.

## Minister zdrowia: klauzula sumienia nie obowiązuje w przypadku zagrożenia życia
 - [https://tvn24.pl/polska/minister-zdrowia-powolal-zespol-ds-wytycznych-w-sprawie-przerywania-ciazy-adam-niedzielski-o-dopuszczalnosci-aborcji-7177994?source=rss](https://tvn24.pl/polska/minister-zdrowia-powolal-zespol-ds-wytycznych-w-sprawie-przerywania-ciazy-adam-niedzielski-o-dopuszczalnosci-aborcji-7177994?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 11:43:32+00:00

<img alt="Minister zdrowia: klauzula sumienia nie obowiązuje w przypadku zagrożenia życia" src="https://tvn24.pl/najnowsze/cdn-zdjecie-b4w5lh-adam-niedzielski-7178236/alternates/LANDSCAPE_1280" />
    Adam Niedzielski zainaugurował prace zespołu do spraw opracowania procedur związanych z przerwaniem ciąży.

## Była słynna stępka, są problemy z kredytem i nierealny plan
 - [https://tvn24.pl/biznes/z-kraju/batory-co-z-programem-promow-7177478?source=rss](https://tvn24.pl/biznes/z-kraju/batory-co-z-programem-promow-7177478?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 11:41:35+00:00

<img alt="Była słynna stępka, są problemy z kredytem i nierealny plan" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ccx2n-pap_20170623_0cl-7177560/alternates/LANDSCAPE_1280" />
    Co z promami dla polskich armatorów?

## "Nastroje w Pekinie nie są przyjazne", w USA nie oczekują przełomu
 - [https://tvn24.pl/swiat/usa-antony-blinken-odwiedzi-chiny-7177378?source=rss](https://tvn24.pl/swiat/usa-antony-blinken-odwiedzi-chiny-7177378?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 11:36:23+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rvpi8z-antony-blinken-7177554/alternates/LANDSCAPE_1280" />
    Sekretarz stanu Antony Blinken udaje się w weekend do Chin.

## Szczątki kobiety w torbie porzuconej na odludziu. Dzięki badaniu DNA ustalono jej tożsamość
 - [https://tvn24.pl/swiat/usa-szczatki-kobiety-w-torbie-porzuconej-na-odludziu-dzieki-badaniu-dnaustalono-jej-tozsamosc-7177669?source=rss](https://tvn24.pl/swiat/usa-szczatki-kobiety-w-torbie-porzuconej-na-odludziu-dzieki-badaniu-dnaustalono-jej-tozsamosc-7177669?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 11:17:26+00:00

<img alt="Szczątki kobiety w torbie porzuconej na odludziu. Dzięki badaniu DNA ustalono jej tożsamość" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7ehbbl-nevada-usa-sierra-nevada-gory-pole-plot-shutterstock_1124099747-7177965/alternates/LANDSCAPE_1280" />
    Po 45 latach.

## "Ta inwestycja jest jedną z największych w historii relacji polsko-amerykańskich"
 - [https://tvn24.pl/biznes/z-kraju/intel-chce-zainwestowac-w-polsce-ponad-45-miliarda-dolarow-ambasador-usa-komentuje-7177885?source=rss](https://tvn24.pl/biznes/z-kraju/intel-chce-zainwestowac-w-polsce-ponad-45-miliarda-dolarow-ambasador-usa-komentuje-7177885?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 11:14:08+00:00

<img alt="" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-qtpzuy-ambasador-stanow-zjednoczonych-w-polsce-mark-brzezinski-7178054/alternates/LANDSCAPE_1280" />
    Ambasador USA w Polsce w rozmowie z Olgą Mildyn.

## Tragiczny wypadek podczas wyścigu Dookoła Szwajcarii. Nie żyje jeden z kolarzy
 - [https://eurosport.tvn24.pl/kolarstwo/tour-de-suisse/2023/grozny-wypadek-w-wyscigu-dookola-szwajcarii.-gino-maeder-reanimowany-i-przetransportowany-do-szpital_sto9661223/story.shtml?source=rss](https://eurosport.tvn24.pl/kolarstwo/tour-de-suisse/2023/grozny-wypadek-w-wyscigu-dookola-szwajcarii.-gino-maeder-reanimowany-i-przetransportowany-do-szpital_sto9661223/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 11:05:45+00:00

<img alt="Tragiczny wypadek podczas wyścigu Dookoła Szwajcarii. Nie żyje jeden z kolarzy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2qs1f1-gino-mader-7178084/alternates/LANDSCAPE_1280" />
    O śmierci Gino Maedera poinformował Team Bahrain.

## Zapisy z "lex Czarnek" wracają? Co zakłada nowy projekt PiS
 - [https://tvn24.pl/polska/lex-czarnek-30-co-zaklada-nowy-projekt-pis-7177930?source=rss](https://tvn24.pl/polska/lex-czarnek-30-co-zaklada-nowy-projekt-pis-7177930?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 11:02:48+00:00

<img alt="Zapisy z " src="https://tvn24.pl/najnowsze/cdn-zdjecie-g44swo-przemyslaw-czarnek-w-sejmie-7177964/alternates/LANDSCAPE_1280" />
    Zmiana ustaw w zakresie oświaty to tak naprawdę zmiana aż piętnastu aktów prawnych.

## Lewica proponuje pakiet "Bezpieczna Polka"
 - [https://tvn24.pl/polska/lewica-proponuje-pakiet-bezpieczna-polka-7177774?source=rss](https://tvn24.pl/polska/lewica-proponuje-pakiet-bezpieczna-polka-7177774?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 10:56:00+00:00

<img alt="Lewica proponuje pakiet " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ccpkee-lewica-dziewczyny-7177736/alternates/LANDSCAPE_1280" />
    Założenia pakietu posłanki przedstawiły na konferencji.

## Auto stoczyło się na 11-latka. Jego właścicielka odprowadzała dzieci do szkoły
 - [https://tvn24.pl/katowice/czestochowa-szedl-do-szkoly-stoczyl-sie-na-niego-samochod-bez-kierowcy-przejechalo-po-nim-kolo-ma-zlamane-zebra-7177829?source=rss](https://tvn24.pl/katowice/czestochowa-szedl-do-szkoly-stoczyl-sie-na-niego-samochod-bez-kierowcy-przejechalo-po-nim-kolo-ma-zlamane-zebra-7177829?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 10:55:07+00:00

<img alt="Auto stoczyło się na 11-latka. Jego właścicielka odprowadzała dzieci do szkoły " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-hiidc5-policja-zatrzymala-pijanego-kierowce-karetki-zdj-ilustracyjne-5505916/alternates/LANDSCAPE_1280" />
    Kierująca zaparkowała i poszła zaprowadzić dzieci do szkoły.

## Szef Nowoczesnej potrącił 16-letnią rowerzystkę. Zapowiedział, że zrzeknie się immunitetu
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-przewodniczacy-nowoczesnej-posel-adam-szlapka-potracil-rowerzystke-na-saskiej-kepie-7177969?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-przewodniczacy-nowoczesnej-posel-adam-szlapka-potracil-rowerzystke-na-saskiej-kepie-7177969?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 10:45:38+00:00

<img alt="Szef Nowoczesnej potrącił 16-letnią rowerzystkę. Zapowiedział, że zrzeknie się immunitetu" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-noi310-posel-adam-szlapka-7177978/alternates/LANDSCAPE_1280" />
    Adam Szłapka został przesłuchany.

## Przekaz PiS: "tylko kopalnia w Turowie przeszkadza zielonym działaczom"? To "kompletne kłamstwo"
 - [https://konkret24.tvn24.pl/polska/przekaz-pis-tylko-kopalnia-w-turowie-przeszkadza-zielonym-dzialaczom-to-kompletne-klamstwo-7174562?source=rss](https://konkret24.tvn24.pl/polska/przekaz-pis-tylko-kopalnia-w-turowie-przeszkadza-zielonym-dzialaczom-to-kompletne-klamstwo-7174562?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 10:38:24+00:00

<img alt="Przekaz PiS: " src="https://tvn24.pl/najnowsze/cdn-zdjecie-249cd3-tylko-kopalnia-w-turowie-przeszkadza-zielonym-dzialaczom-7174996/alternates/LANDSCAPE_1280" />
    Według polityków PiS ekolodzy nie protestują przeciw kopalniom w Czechach i Niemczech. To nieprawda.

## Zimny prysznic. Polki przegrały pierwszy mecz w Lidze Narodów
 - [https://eurosport.tvn24.pl/siatkowka/nations-league-league-round-1/2023/polska-holandia-wynik-i-relacja-liga-narodow-siatkarek-2023_sto9661353/story.shtml?source=rss](https://eurosport.tvn24.pl/siatkowka/nations-league-league-round-1/2023/polska-holandia-wynik-i-relacja-liga-narodow-siatkarek-2023_sto9661353/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 10:32:19+00:00

<img alt="Zimny prysznic. Polki przegrały pierwszy mecz w Lidze Narodów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-q7kp2l-polskie-siatkartki-rywalizuja-w-lidze-narodow-7177975/alternates/LANDSCAPE_1280" />
    Po serii sześciu zwycięstw.

## Szóstka w Lotto. Podano, gdzie padła wygrana
 - [https://tvn24.pl/biznes/pieniadze/wyniki-lotto-z-dnia-150623-gdzie-padla-szostka-7177628?source=rss](https://tvn24.pl/biznes/pieniadze/wyniki-lotto-z-dnia-150623-gdzie-padla-szostka-7177628?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 10:27:57+00:00

<img alt="Szóstka w Lotto. Podano, gdzie padła wygrana " src="https://tvn24.pl/najnowsze/cdn-zdjecie-m7iitz-lotto-s-shutterstock_275295956-5128640/alternates/LANDSCAPE_1280" />
    Komunikat Totalizatora Sportowego.

## Na Enceladusie znaleziono cząsteczki niezbędne do życia. "To szokujące odkrycie"
 - [https://tvn24.pl/tvnmeteo/nauka/fosforany-na-enceladusie-to-szokujace-odkrycie-dla-astrobiologii-7177626?source=rss](https://tvn24.pl/tvnmeteo/nauka/fosforany-na-enceladusie-to-szokujace-odkrycie-dla-astrobiologii-7177626?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 10:14:31+00:00

<img alt="Na Enceladusie znaleziono cząsteczki niezbędne do życia. " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-fxw2yc-enceladus-w-obiektywie-sondy-cassini-7177752/alternates/LANDSCAPE_1280" />
    Pochodzą z podpowierzchniowego oceanu.

## 18-latka zapadła w śpiączkę podczas operacji powiększenia biustu. Chirurg uznany winnym jej śmierci
 - [https://tvn24.pl/swiat/usa-18-latka-zapadla-w-spiaczke-podczas-operacji-powiekszenia-biustu-chirurg-uznany-winnym-jej-smierci-7177624?source=rss](https://tvn24.pl/swiat/usa-18-latka-zapadla-w-spiaczke-podczas-operacji-powiekszenia-biustu-chirurg-uznany-winnym-jej-smierci-7177624?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 10:08:42+00:00

<img alt="18-latka zapadła w śpiączkę podczas operacji powiększenia biustu. Chirurg uznany winnym jej śmierci" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2n108l-chirurg-operacja-szpital-7177839/alternates/LANDSCAPE_1280" />
    Nie zadzwonił po pogotowie przez pięć godzin.

## Utrzeć nosa Wałęsie. A 30 lat później Tuskowi
 - [https://tvn24.pl/premium/jaroslaw-kaczynski-kontra-donald-tusk-co-sie-naprawde-wydarzylo-4-czerwca-1992-7176682?source=rss](https://tvn24.pl/premium/jaroslaw-kaczynski-kontra-donald-tusk-co-sie-naprawde-wydarzylo-4-czerwca-1992-7176682?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 10:07:08+00:00

<img alt="Utrzeć nosa Wałęsie. A 30 lat później Tuskowi" src="https://tvn24.pl/najnowsze/cdn-zdjecie-85wire-1992-mn-premium-pap_19920409_003-1-7176515/alternates/LANDSCAPE_1280" />
    Kadr ze zdjęciem Donalda Tuska i podpis: "Panowie, policzmy głosy". Tak polityczni przeciwnicy przewodniczącego Platformy Obywatelskiej wykorzystują w kampanii przedwyborczej ujęcia z filmu Jacka Kurskiego "Nocna zmiana". Przekaz jest prosty i propagandowo atrakcyjny - lider PO wspólnie z agentami komunistycznymi działającymi w Sejmie pierwszej kadencji doprowadził do upadku rządu Jana Olszewskiego i zatrzymania lustracji. Przeciwnicy Tuska karmią tak jeden z mitów, którego ziarno zasiał sam Olszewski.

## Kaliningradu nie ma, jest Królewiec. Trwa wymiana znaków drogowych
 - [https://tvn24.pl/pomorze/kaliningradu-nie-ma-jest-krolewiec-trwa-wymiana-znakow-drogowych-7177789?source=rss](https://tvn24.pl/pomorze/kaliningradu-nie-ma-jest-krolewiec-trwa-wymiana-znakow-drogowych-7177789?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 10:05:07+00:00

<img alt="Kaliningradu nie ma, jest Królewiec. Trwa wymiana znaków drogowych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1pfjo5-kaliningrad-zmienia-sie-w-krolewiec-7177810/alternates/LANDSCAPE_1280" />
    Ministerstwo podkreśla, że to powrót do polskich korzeni nazwy miejscowości.

## Inflacja w Unii Europejskiej. Wyraźny lider, Polska w czołówce
 - [https://tvn24.pl/biznes/ze-swiata/inflacja-w-unii-europejskiej-maj-2023-wegry-liderem-polska-w-czolowce-eurostat-podal-nowe-dane-7177746?source=rss](https://tvn24.pl/biznes/ze-swiata/inflacja-w-unii-europejskiej-maj-2023-wegry-liderem-polska-w-czolowce-eurostat-podal-nowe-dane-7177746?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 10:01:45+00:00

<img alt="Inflacja w Unii Europejskiej. Wyraźny lider, Polska w czołówce" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3phat1-sklep-zakupy-bazar-targowisko-wegry-budapeszt-inflacja-7156903/alternates/LANDSCAPE_1280" />
    Dane Eurostatu za maj.

## Nie żyje 21-letnia turystka zepchnięta w przepaść. Tragedia w pobliżu słynnego zamku
 - [https://tvn24.pl/swiat/niemcy-nie-zyje-21-latka-zepchnieta-w-przepasc-przy-zamku-neuschwanstein-7177723?source=rss](https://tvn24.pl/swiat/niemcy-nie-zyje-21-latka-zepchnieta-w-przepasc-przy-zamku-neuschwanstein-7177723?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 09:59:20+00:00

<img alt="Nie żyje 21-letnia turystka zepchnięta w przepaść. Tragedia w pobliżu słynnego zamku" src="https://tvn24.pl/najnowsze/cdn-zdjecie-yhznti-shutterstock_1542447518-7177741/alternates/LANDSCAPE_1280" />
    Z ustaleń śledczych wynika, że zaatakował ją 30-letni rodak.

## Słychać pierwsze grzmoty. Sprawdź, gdzie jest burza
 - [https://tvn24.pl/tvnmeteo/pogoda/gdzie-jest-burza-burze-w-polsce-w-piatek-1606-mapa-i-radar-burz-sprawdz-gdzie-jest-burza-7177765?source=rss](https://tvn24.pl/tvnmeteo/pogoda/gdzie-jest-burza-burze-w-polsce-w-piatek-1606-mapa-i-radar-burz-sprawdz-gdzie-jest-burza-7177765?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 09:47:40+00:00

<img alt="Słychać pierwsze grzmoty. Sprawdź, gdzie jest burza" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-eko9zc-wyladowania-atmosferyczne-nad-polska-o-godzinie-1210-7177790/alternates/LANDSCAPE_1280" />
    Śledź aktualną sytuację pogodową.

## W Wiśle dryfowało ciało. Wyłowili je strażacy
 - [https://tvn24.pl/tvnwarszawa/najnowsze/jablonna-cialo-dryfujace-na-wisle-7177659?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/jablonna-cialo-dryfujace-na-wisle-7177659?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 09:44:18+00:00

<img alt="W Wiśle dryfowało ciało. Wyłowili je strażacy" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-5jnexr-akcja-strazakow-na-wisle-7177687/alternates/LANDSCAPE_1280" />
    Strażacy prowadzili akcję na łodziach.

## Cztery osoby ranne po wypadku na S3. Policja: kierowca był pod wpływem narkotyków
 - [https://tvn24.pl/wroclaw/legnica-wypadek-na-drodze-s3-sa-ranni-policja-kierowca-byl-pod-wplywem-narkotykow-7177750?source=rss](https://tvn24.pl/wroclaw/legnica-wypadek-na-drodze-s3-sa-ranni-policja-kierowca-byl-pod-wplywem-narkotykow-7177750?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 09:34:03+00:00

<img alt="Cztery osoby ranne po wypadku na S3. Policja: kierowca był pod wpływem narkotyków" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-qr5kly-wypadek-w-miejscowosci-senden-maly-zdjecie-ilustracyjne-7166515/alternates/LANDSCAPE_1280" />
    Zderzyły się trzy pojazdy.

## Niespodzianka. Holenderki lepsze od Polek w pierwszym secie
 - [https://eurosport.tvn24.pl/siatkowka/nations-league-league-round-1/2023/live-polska-holandia_mtc1424201/live.shtml?source=rss](https://eurosport.tvn24.pl/siatkowka/nations-league-league-round-1/2023/live-polska-holandia_mtc1424201/live.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 09:23:00+00:00

<img alt="Niespodzianka. Holenderki lepsze od Polek w pierwszym secie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-47l80g-polskie-siatkarki-w-lidze-narodow-7177597/alternates/LANDSCAPE_1280" />
    Relacja i wynik na żywo w eurosport.pl.

## Zatrzymała ich ulewa, przetrzymali nawałnicę. Nasze bitwy z Niemcami
 - [https://eurosport.tvn24.pl/pilka-nozna/miedzynarodowe-mecze-towarzyskie/2014/polska-niemcy-na-pge-narodowym.-wspominamy-najwazniejsze-mecze-obu-reprezentacji_sto9659758/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/miedzynarodowe-mecze-towarzyskie/2014/polska-niemcy-na-pge-narodowym.-wspominamy-najwazniejsze-mecze-obu-reprezentacji_sto9659758/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 08:40:27+00:00

<img alt="Zatrzymała ich ulewa, przetrzymali nawałnicę. Nasze bitwy z Niemcami" src="https://tvn24.pl/najnowsze/cdn-zdjecie-we3qht-polska-niemcy-1974-2014-7177648/alternates/LANDSCAPE_1280" />
    Spotkania z Niemcami zawsze są wyjątkowe.

## Co po wysadzeniu tamy? Putin "zrobi wszystko, by zakończyć wojnę na jego warunkach"
 - [https://tvn24.pl/swiat/rosyjski-politolog-wladislaw-inoziemcew-putin-chce-rozmow-z-zachodem-zatrzymac-zajete-terytoria-ukrainy-7177208?source=rss](https://tvn24.pl/swiat/rosyjski-politolog-wladislaw-inoziemcew-putin-chce-rozmow-z-zachodem-zatrzymac-zajete-terytoria-ukrainy-7177208?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 08:12:00+00:00

<img alt="Co po wysadzeniu tamy? Putin " src="https://tvn24.pl/najnowsze/cdn-zdjecie-fji0zy-wladimir-putin-7177207/alternates/LANDSCAPE_1280" />
    Rosyjski politolog Władisław Inoziemcew w rozmowie z TVN24 BiS.

## Powrót liderów. Skład Polaków na kolejny turniej Ligi Narodów
 - [https://eurosport.tvn24.pl/siatkowka/nations-league-league-round/2023/liga-narodow-siatkarzy-2023.-sklad-reprezentacji-polski-na-turniej-w-rotterdamie_sto9661186/story.shtml?source=rss](https://eurosport.tvn24.pl/siatkowka/nations-league-league-round/2023/liga-narodow-siatkarzy-2023.-sklad-reprezentacji-polski-na-turniej-w-rotterdamie_sto9661186/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 07:30:44+00:00

<img alt="Powrót liderów. Skład Polaków na kolejny turniej Ligi Narodów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-unfym5-bartosz-kurek-w-reprezentacji-polski-7177502/alternates/LANDSCAPE_1280" />
    Ogłoszono skład reprezentacji Polski siatkarzy na drugi turniej Ligi Narodów.

## Świątek i długo, długo nic. Ranking najcenniejszych kobiecych marek
 - [https://eurosport.tvn24.pl/tenis/iga-swiatek-na-czele-rankingu-magazynu-forbes-na-najcenniejsza-kobieca-marke-2023-roku_sto9661176/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/iga-swiatek-na-czele-rankingu-magazynu-forbes-na-najcenniejsza-kobieca-marke-2023-roku_sto9661176/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 07:11:02+00:00

<img alt="Świątek i długo, długo nic. Ranking najcenniejszych kobiecych marek" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qzbcbw-iga-swiatek-ostatnio-po-raz-trzeci-wygrala-roland-garros-7177447/alternates/LANDSCAPE_1280" />
    Iga Świątek cieszy się ogromną popularnością.

## Ustawa "lex Tusk" wróciła do komisji
 - [https://tvn24.pl/polska/lex-tusk-prace-nad-prezydencka-nowelizacja-w-sejmie-drugie-czytanie-ustawa-wrocila-do-komisji-7177319?source=rss](https://tvn24.pl/polska/lex-tusk-prace-nad-prezydencka-nowelizacja-w-sejmie-drugie-czytanie-ustawa-wrocila-do-komisji-7177319?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 06:38:17+00:00

<img alt="Ustawa " src="https://tvn24.pl/najnowsze/cdn-zdjecie-7sem7p-debata-w-sejmie-7177618/alternates/LANDSCAPE_1280" />
    Posłowie zgłosili poprawki.

## Rekordowy rzut Polaka w Oslo
 - [https://eurosport.tvn24.pl/lekkoatletyka/golden-league-oslo/2009/lekkoatletyczny-mityng-diamentowej-ligi-w-oslo-wyniki.-wojciech-nowicki-wygral-konkurs-rzutu-mlotem_sto9660946/story.shtml?source=rss](https://eurosport.tvn24.pl/lekkoatletyka/golden-league-oslo/2009/lekkoatletyczny-mityng-diamentowej-ligi-w-oslo-wyniki.-wojciech-nowicki-wygral-konkurs-rzutu-mlotem_sto9660946/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 06:35:46+00:00

<img alt="Rekordowy rzut Polaka w Oslo" src="https://tvn24.pl/najnowsze/cdn-zdjecie-95kx1y-wojciech-nowicki-wygral-w-oslo-7177367/alternates/LANDSCAPE_1280" />
    Wygrał konkurs rzutu młotem podczas lekkoatletycznego mityngu Diamentowej Ligi.

## Była IV liga, będzie klasa A. Nietypowych wyzwań Marciniaka ciąg dalszy
 - [https://eurosport.tvn24.pl/pilka-nozna/szymon-marciniak-poprowadzi-mecz-ks-turosnianka-gks-rutki-w-a-klasie-pilka-nozna_sto9660278/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/szymon-marciniak-poprowadzi-mecz-ks-turosnianka-gks-rutki-w-a-klasie-pilka-nozna_sto9660278/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 06:16:47+00:00

<img alt="Była IV liga, będzie klasa A. Nietypowych wyzwań Marciniaka ciąg dalszy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9s62cy-szymon-marciniak-byl-sedzia-ostatniego-finalu-lm-7177348/alternates/LANDSCAPE_1280" />
    Szymon Marciniak nie przestaje zaskakiwać kibiców.

## Były trener Polaków nie dla Napoli. Zaskakujący wybór
 - [https://eurosport.tvn24.pl/pilka-nozna/serie-a/2023-2024/rudi-garcia-trenerem-ssc-napoli_sto9661156/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/serie-a/2023-2024/rudi-garcia-trenerem-ssc-napoli_sto9661156/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 05:49:45+00:00

<img alt="Były trener Polaków nie dla Napoli. Zaskakujący wybór" src="https://tvn24.pl/najnowsze/cdn-zdjecie-v7zfe9-rudi-garcia-byl-ostatnio-trenerem-al-nassr-7177325/alternates/LANDSCAPE_1280" />
    Rudi Garcia niespodziewanie został ogłoszony nowym trenerem mistrza Włoch SSC Napoli.

## Dostał od Polańskiego cenną lekcję. "Zrzucił marynarkę, podwinął rękawy i powiedział: ja kocham kucharki!"
 - [https://tvn24.pl/go/programy,7/monika-olejnik-otwarcie-odcinki,511079/odcinek-44,S00E44,1091643?source=rss](https://tvn24.pl/go/programy,7/monika-olejnik-otwarcie-odcinki,511079/odcinek-44,S00E44,1091643?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 05:43:38+00:00

<img alt="Dostał od Polańskiego cenną lekcję. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-zdxv9b-monika-olejnik-otwarcie-z-mariuszem-trelinskim-7177321/alternates/LANDSCAPE_1280" />
    Reżyser operowy, filmowy i teatralny Mariusz Treliński w rozmowie z Moniką Olejnik.

## Dużo radości, jeszcze więcej cierpienia. Kuba gra ostatni raz
 - [https://eurosport.tvn24.pl/pilka-nozna/miedzynarodowe-mecze-towarzyskie/2023/kuba-blaszczykowski-rozgrywa-ostatni-mecz-w-reprezentacji.-jego-16-momentow-z-zycia_sto9660044/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/miedzynarodowe-mecze-towarzyskie/2023/kuba-blaszczykowski-rozgrywa-ostatni-mecz-w-reprezentacji.-jego-16-momentow-z-zycia_sto9660044/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 05:20:10+00:00

<img alt="Dużo radości, jeszcze więcej cierpienia. Kuba gra ostatni raz" src="https://tvn24.pl/najnowsze/cdn-zdjecie-esqf9g-blaszczykowski-konczy-reprezentacyjna-kariere-zrodlo-getty-imagesnewspix-7177292/alternates/LANDSCAPE_1280" />
    Kariera Kuby Błaszczykowskiego to sukcesy, ale i dużo cierpienia.

## Urazy podstawowych niemieckich piłkarzy. Z Polską nie zagrają
 - [https://eurosport.tvn24.pl/pilka-nozna/miedzynarodowe-mecze-towarzyskie/2023/polska-niemcy.-timo-werner-i-lukas-klostermann-kontuzjowani.-co-z-ich-zdrowiem_sto9660705/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/miedzynarodowe-mecze-towarzyskie/2023/polska-niemcy.-timo-werner-i-lukas-klostermann-kontuzjowani.-co-z-ich-zdrowiem_sto9660705/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 04:34:30+00:00

<img alt="Urazy podstawowych niemieckich piłkarzy. Z Polską nie zagrają" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jduqr1-werner-i-klostermann-nie-zagraja-z-polska-7177273/alternates/LANDSCAPE_1280" />
    Nie przylecieli do Warszawy na spotkanie z Polską.

## Strzały w Szczecinie, wyrok w sprawie śmierci Polaka, tragiczny wypadek w Kanadzie
 - [https://tvn24.pl/swiat/szesc-rzeczy-ktore-warto-wiedziec-16-czerwca-7177249?source=rss](https://tvn24.pl/swiat/szesc-rzeczy-ktore-warto-wiedziec-16-czerwca-7177249?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 03:32:00+00:00

<img alt="Strzały w Szczecinie, wyrok w sprawie śmierci Polaka, tragiczny wypadek w Kanadzie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-i9az3v-smiertelny-wypadek-w-kanadzie-7177246/alternates/LANDSCAPE_1280" />
    Sześć rzeczy, które warto wiedzieć 16 czerwca.

## Wypadli z drogi, dachowali. Czworo nastolatków trafiło do szpitala
 - [https://tvn24.pl/poznan/wielkopolskie-stara-krobia-wypadek-w-starej-krobi-samochod-wpadl-do-rowu-dachowanie-7177245?source=rss](https://tvn24.pl/poznan/wielkopolskie-stara-krobia-wypadek-w-starej-krobi-samochod-wpadl-do-rowu-dachowanie-7177245?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-16 03:24:00+00:00

<img alt="Wypadli z drogi, dachowali. Czworo nastolatków trafiło do szpitala" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kzmufd-wypadek-w-starej-krobi-7177242/alternates/LANDSCAPE_1280" />
    Wypadek w Starej Krobi.

