# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## Intel DOUBLES GPU share. Quietly killing it!
 - [https://www.youtube.com/watch?v=CrNcnkAtL2I](https://www.youtube.com/watch?v=CrNcnkAtL2I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2023-06-16 14:15:11+00:00

Visit https://brilliant.org/TFC/ to get started learning STEM with a 30 day free trial, and the first 200 people will get 20% off their annual premium subscription - Sponsored by Brilliant.

 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  
 
►►► This video ◄◄◄  

This week Microsoft rolled out some Windows updates like Win32 isolation that you'll actually want, Intel doubled its GPU market share & is doing surprisingly well, and a former Samsung executive stole a whole memory chip fab.

Episode 150
 
This video on Nebula: https://nebula.tv/videos/tfc-intel-doubles-gpu-share-quietly-killing-it

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► TechAltar links ◄◄◄  
 
Social media:  
https://mas.to/@techaltar
https://instagram.com/TechAltar 
https://discord.gg/npKQebe  
 
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
 
►►► Attributions & Time stamps◄◄◄
 
Writing & Research: Tristan Rayner
Music by Edemski: https://soundcloud.com/edemski 

0:00 Intro
0:20 The Brief
3:15 Great Windows updates
5:45 Intel's GPU success
6:43 Samsung's chip fab, stolen

