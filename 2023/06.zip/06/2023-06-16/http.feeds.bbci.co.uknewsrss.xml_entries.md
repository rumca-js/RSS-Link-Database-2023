# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## The Papers: Wintour's 'top honour' and 'UK mortgage rip-off'
 - [https://www.bbc.co.uk/news/blogs-the-papers-65936248?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-65936248?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 22:59:48+00:00

Saturday's front pages feature the King's birthday honours list and mortgage rate rises.

## Canadian Grand Prix: Lewis Hamilton leads Mercedes one-two in Friday practice
 - [https://www.bbc.co.uk/sport/formula1/65935962?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/formula1/65935962?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 22:53:14+00:00

Lewis Hamilton leads George Russell in a Mercedes one-two in Friday practice at the Canadian Grand Prix.

## 'It feels natural' - Alexander-Arnold 'comfortable' as number 10
 - [https://www.bbc.co.uk/sport/football/65935420?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65935420?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 22:44:25+00:00

Trent Alexander-Arnold says playing in England's midfield "feels natural" after impressing there in 4-0 win against Malta.

## King's Birthday Honours: Ian Wright, Ken Bruce and Davina McCall on list
 - [https://www.bbc.co.uk/news/uk-65914516?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-65914516?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 21:45:43+00:00

Anna Wintour, Vicky McClure, Terry Waite and Martin Amis are among other big names on the list.

## King's Birthday Honours: Sarah Hunter and Ian Wright among those included
 - [https://www.bbc.co.uk/sport/65889468?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/65889468?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 21:30:37+00:00

Former England rugby union captain Sarah Hunter and ex-footballer Ian Wright are among the sports personalities named in the King's Birthday Honours list.

## Euro 2024 qualifying: Wales humiliated 4-2 at home by Armenia
 - [https://www.bbc.co.uk/sport/football/65852138?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65852138?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 20:45:30+00:00

Wales suffer one of their most embarrassing and damaging defeats in recent memory as they lose 4-2 at home to Armenia in a chaotic Euro 2024 qualifier.

## The Ashes 2023: Opening day lives up to hype and promises more
 - [https://www.bbc.co.uk/sport/cricket/65930121?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/65930121?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 20:42:48+00:00

The opening day of the Ashes was a clash of styles hinting at an instant classic of a series, says chief cricket writer Stephan Shemilt.

## Drag Race star The Vivienne suffers homophobic attack
 - [https://www.bbc.co.uk/news/uk-england-merseyside-65933668?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-merseyside-65933668?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 19:49:58+00:00

Police detain a man after The Vivienne was punched during the assault in a McDonald's in Liverpool.

## Daniel Ellsberg: Pentagon Papers whistleblower dies aged 92
 - [https://www.bbc.co.uk/news/world-us-canada-65932944?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-65932944?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 18:53:43+00:00

His 1971 leak exposed lies about the Vietnam War and saw him dubbed "the most dangerous man in America".

## Canadian Grand Prix first practice ended by CCTV failure at Circuit Gilles Villeneuve
 - [https://www.bbc.co.uk/sport/formula1/65919604?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/formula1/65919604?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 18:36:12+00:00

First practice at the Canadian Grand Prix is abandoned because of a CCTV failure at the Circuit Gilles Villeneuve.

## Man charged with stalking MP and impersonating police officer
 - [https://www.bbc.co.uk/news/uk-65934339?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-65934339?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 18:27:42+00:00

Simon Parry, 44, was arrested on Thursday following an incident with an unnamed MP in Westminster.

## Root's ton steers England in Ashes opener
 - [https://www.bbc.co.uk/sport/cricket/65918845?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/65918845?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 18:13:45+00:00

England stun Edgbaston by declaring against Australia on a first day of an Ashes series that more than lived up to the hype.

## Ashes highlights: England declare on 393-8 after Root century
 - [https://www.bbc.co.uk/sport/av/cricket/65932598?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/65932598?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 17:57:26+00:00

England stun Edgbaston by declaring against Australia after Joe Root's masterful unbeaten 118 on the first day of the Ashes.

## Ukraine war: Putin confirms first nuclear weapons moved to Belarus
 - [https://www.bbc.co.uk/news/world-europe-65932700?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-65932700?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 17:51:35+00:00

Russia's leader says the move is to remind anyone "thinking of inflicting a strategic defeat on us".

## George Floyd: Minneapolis police routinely used excessive force
 - [https://www.bbc.co.uk/news/world-us-canada-65933914?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-65933914?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 16:55:30+00:00

Systemic issues in the force "made what happened to George Floyd possible", an investigation finds.

## Kylie Minogue scores her first top 10 hit since 2010 - but what does Padam Padam mean?
 - [https://www.bbc.co.uk/news/entertainment-arts-65932878?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-65932878?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 16:45:01+00:00

The star ends a decade-long dry spell in the charts - but what does Padam Padam actually mean?

## 'It makes your skin crawl': Mormon crickets invade US town
 - [https://www.bbc.co.uk/news/world-us-canada-65933964?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-65933964?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 16:26:52+00:00

The bugs are in their migratory phase and have taken over some houses and roads in Elko.

## Man found guilty of deadly Pittsburgh synagogue attack
 - [https://www.bbc.co.uk/news/world-us-canada-65933373?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-65933373?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 16:04:47+00:00

Gunman who killed 11 people in a Pittsburgh synagogue in 2018 found guilty of the deadliest antisemitic attack in US history

## Hans Zimmer proposes to partner during O2 Arena live show
 - [https://www.bbc.co.uk/news/uk-england-london-65932091?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-65932091?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 15:34:36+00:00

The conductor popped the question to his partner Dina De Luca on stage at London's O2 Arena

## Covid inquiry: UK's public services were 'depleted' when Covid hit
 - [https://www.bbc.co.uk/news/health-65929516?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-65929516?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 15:34:30+00:00

The nation's health was declining and the NHS was struggling by 2020, the Covid inquiry hears.

## Nottingham attacks: Man charged with three counts of murder
 - [https://www.bbc.co.uk/news/uk-england-nottinghamshire-65912592?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-nottinghamshire-65912592?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 14:51:05+00:00

Barnaby Webber, Grace O'Malley-Kumar and Ian Coates were stabbed to death on Tuesday.

## King appoints Queen Camilla to Scotland's Order of the Thistle
 - [https://www.bbc.co.uk/news/uk-scotland-65932628?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-65932628?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 14:46:32+00:00

Queen Camilla joins the Order of the Thistle, which can only be bestowed by the King.

## Maidstone: Police officer in serious condition after stabbing
 - [https://www.bbc.co.uk/news/uk-england-kent-65929513?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-kent-65929513?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 13:58:07+00:00

A 48-year-old man has been arrested following the assault in Maidstone on Thursday evening.

## Chris Mason: Tories turning against angry version of Johnson
 - [https://www.bbc.co.uk/news/uk-politics-65930485?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-65930485?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 13:56:33+00:00

The former PM's support in Parliament is shrinking, as MPs digest a damning report on his conduct.

## The Ashes 2023: England's Harry Brook out for 32 after 'freakish dismissal'
 - [https://www.bbc.co.uk/sport/av/cricket/65929804?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/65929804?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 13:49:31+00:00

Watch as England's Harry Brook is bowled by Australia's Nathan Lyon for 32 after a "freakish dismissal" on day one of the first Ashes Test.

## The Ashes 2023: Australia's Travis Head drops England's Harry Brook on 24
 - [https://www.bbc.co.uk/sport/av/cricket/65929802?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/65929802?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 13:30:02+00:00

Watch the moment England's Harry Brook is dropped on 24 by Australia's Travis Head as England reach 159-3 in the Ashes.

## Boris Johnson asks allies not to vote against Partygate findings
 - [https://www.bbc.co.uk/news/uk-politics-65930011?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-65930011?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 13:27:22+00:00

Nadine Dorries and other Tories have said they will vote against damning report on ex-PM's conduct.

## Massive Swiss rockfall stops short of evacuated village of Brienz
 - [https://www.bbc.co.uk/news/world-europe-65926381?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-65926381?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 13:08:36+00:00

Brienz was evacuated last month when geologists warned the rockface above it was due to collapse.

## Boris Johnson unveiled as new Daily Mail columnist
 - [https://www.bbc.co.uk/news/uk-politics-65930008?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-65930008?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 12:22:44+00:00

The former PM did not seek clearance from Parliament's ethics watchdog to take up his new job.

## The Ashes 2023: England's Zak Crawley's dismissed for 61
 - [https://www.bbc.co.uk/sport/av/cricket/65929800?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/65929800?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 12:20:04+00:00

England's Zak Crawley's innings come to an end as he is dismissed for 61 and Australia take their third wicket of day one of the first Ashes Test at Edgbaston.

## Ryanair apologises for 'Tel Aviv in Palestine' flight row
 - [https://www.bbc.co.uk/news/business-65927794?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-65927794?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 12:09:36+00:00

Passengers on a flight to Israel reacted angrily after a member of cabin crew made the announcement.

## The Ashes: Best shots of Crawley's half-century for England v Australia
 - [https://www.bbc.co.uk/sport/av/cricket/65928647?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/65928647?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 11:45:27+00:00

Watch the best of Zak Crawley's 50 for England against Australia on day one of the first Ashes Test.

## Brendan Rodgers' Celtic return: Manager would 'have it all to prove' if he returns
 - [https://www.bbc.co.uk/sport/football/65905895?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65905895?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 11:41:49+00:00

With a stronger Rangers to compete with and progress required in Europe, Brendan Rodgers would have plenty to prove if he returns to Celtic, writes Tom English.

## Tour de Suisse: Gino Mader dies aged 26 after stage five crash
 - [https://www.bbc.co.uk/sport/cycling/65926606?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cycling/65926606?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 11:29:55+00:00

Swiss cyclist Gino Mader dies at the age of 26 after crashing heavily on stage five of the Tour de Suisse.

## Plaid Cymru: Rhun ap Iorwerth takes over as party leader
 - [https://www.bbc.co.uk/news/uk-wales-politics-65928575?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-politics-65928575?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 11:22:01+00:00

Rhun ap Iorwerth is elected unopposed after no other candidates challenged him for the job.

## Greece boat disaster: Officials deny coastguard rope led to migrant tragedy
 - [https://www.bbc.co.uk/news/world-europe-65925558?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-65925558?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 11:15:20+00:00

A series of reports suggest the migrant boat went down after it was tied to a coastguard vessel.

## Watch: Rescuer swims through rough seas to save stranded dog
 - [https://www.bbc.co.uk/news/world-us-canada-65929634?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-65929634?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 10:59:14+00:00

The dog's owner says she is doing well after she fell off a cliff and was rescued by the coastguard.

## Doctor Nicholas Chapman put bodily fluid in woman's coffee
 - [https://www.bbc.co.uk/news/uk-england-somerset-65925789?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-somerset-65925789?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 10:58:36+00:00

Dr Nicholas Chapman will be sentenced in July after being found guilty of a sexual offence.

## Average two-year mortgage rate close to 6%
 - [https://www.bbc.co.uk/news/business-65928188?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-65928188?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 10:53:25+00:00

Lenders have been increasing the cost of new fixed-rate deals rapidly during a tumultuous week.

## Serial killer Levi Bellfield can marry in prison
 - [https://www.bbc.co.uk/news/uk-65927538?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-65927538?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 10:37:42+00:00

There are no legal routes currently available to block the marriage, the Ministry of Justice said.

## George Orwell's 1984 returned to Portland library after 65 years
 - [https://www.bbc.co.uk/news/world-us-canada-65926195?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-65926195?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 10:35:46+00:00

Man returns George Orwell's dystopian novel to library decades late because of its relevance today.

## The Ashes 2023: England lose first wicket as Ben Duckett is dismissed for 12
 - [https://www.bbc.co.uk/sport/av/cricket/65928645?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/65928645?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 10:34:29+00:00

England lose their first wicket as batter Ben Duckett is caught out by Australia's Alex Carey for 12 as they face each other on day one of the Ashes 2023.

## The Ashes 2023: England's Zak Crawley smashes first ball of series for four
 - [https://www.bbc.co.uk/sport/av/cricket/65928644?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/65928644?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 10:28:08+00:00

England's Zak Crawley smashes a four off the first ball of the 2023 Ashes between England and Australia at Edgbaston.

## Leicester set to name Man City's Maresca as manager
 - [https://www.bbc.co.uk/sport/football/65888753?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65888753?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 10:21:50+00:00

Treble-winning Manchester City assistant coach Enzo Maresca is set to be appointed Leicester City manager after agreeing terms with the Foxes.

## Kent and Sussex hosepipe ban announced from 26 June
 - [https://www.bbc.co.uk/news/uk-england-65927032?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-65927032?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 09:29:33+00:00

South East Water is restricting water usage from 26 June after demand reached "record levels".

## Nottingham attacks: Suspect named as Valdo Amissão Mendes Calocane
 - [https://www.bbc.co.uk/news/uk-england-nottinghamshire-65927760?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-nottinghamshire-65927760?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 09:24:57+00:00

Valdo Amissão Mendes Calocane is named as the man being questioned by officers.

## Tesco sees early signs inflation is starting to ease
 - [https://www.bbc.co.uk/news/business-65925217?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-65925217?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 09:24:31+00:00

The UK's largest supermarket says there are "encouraging" indications that price rises are slowing.

## Ex-police watchdog chief Lockwood charged with rape
 - [https://www.bbc.co.uk/news/uk-65928045?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-65928045?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 09:22:06+00:00

Ex-police watchdog boss Michael Lockwood is charged with raping a girl under 16 and indecent assault.

## England's Russo to leave Man Utd at end of June
 - [https://www.bbc.co.uk/sport/football/65922930?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65922930?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 09:02:34+00:00

England striker Alessia Russo will leave Manchester United this summer on the expiry of her contract and is closing in on a move to Arsenal.

## How do radio stations choose their playlists?
 - [https://www.bbc.co.uk/news/newsbeat-65914728?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-65914728?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 08:44:53+00:00

One veteran music programmer says it's a blend of factors, but the most important thing is the audience.

## Felix calls for better maternity care for black women after team-mate's death
 - [https://www.bbc.co.uk/sport/athletics/65925398?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/athletics/65925398?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 08:33:06+00:00

Olympic great Allyson Felix calls for better maternity care for black women to ensure the death of team-mate Tori Bowie is "not in vain".

## Climate change: UN to unmask fossil fuel delegates at climate talks
 - [https://www.bbc.co.uk/news/science-environment-65917660?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-65917660?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 08:30:55+00:00

The UN takes steps to ensure that oil and gas industry delegates declare their affiliations at COP28.

## Greece boat disaster: Brothers' tearful reunion through gates
 - [https://www.bbc.co.uk/news/world-europe-65926133?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-65926133?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 08:28:00+00:00

Eighteen-year-old Fedi was among the survivors of a deadly incident, where hundreds could still be missing.

## Alzheimer's: Adjusting to being your parent's parent
 - [https://www.bbc.co.uk/news/uk-england-birmingham-65776775?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-birmingham-65776775?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 08:19:58+00:00

Two brothers describe the changes they've made to care for their father after his diagnosis aged 55.

## Al Pacino welcomes fourth child at 83, with girlfriend Noor Alfallah
 - [https://www.bbc.co.uk/news/entertainment-arts-65925640?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-65925640?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 08:09:44+00:00

The actor star joins his Godfather II co-star Robert De Niro in becoming a dad again later in life.

## Life for a real Ten Pound Pom
 - [https://www.bbc.co.uk/news/uk-england-kent-65560974?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-kent-65560974?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 07:18:33+00:00

A family recall leaving 1960s Kent for Down Under as a drama puts the spotlight on 'ten pound Poms'.

## The Ashes 2023: Australian podcast The Grade Cricketer previews England v Australia
 - [https://www.bbc.co.uk/sport/av/cricket/65907094?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/65907094?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 06:53:07+00:00

Australian podcasters The Grade Cricketer preview the 2023 men's Ashes series between England and Australia.

## Council 'incompetence' to blame for village's shortage of 1,000 primary school places
 - [https://www.bbc.co.uk/news/uk-scotland-glasgow-west-65920931?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-glasgow-west-65920931?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 05:23:36+00:00

A review says Renfrewshire Council's forecast of pupil numbers had "obvious flaws".

## Meet one of Britain’s youngest imams
 - [https://www.bbc.co.uk/news/uk-england-london-65878885?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-65878885?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 05:23:25+00:00

Sabah Ahmedi, 29, is using social media to tackle Islamophobia.

## Bee-eaters make historic return to breeding site in Norfolk
 - [https://www.bbc.co.uk/news/uk-england-norfolk-65910074?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-norfolk-65910074?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 05:20:19+00:00

European bee-eaters, rare to UK shores, are spotted at the same site where they bred last year.

## Watch: Slam dunking otter plays basketball to help with arthritis
 - [https://www.bbc.co.uk/news/world-us-canada-65921265?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-65921265?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 05:17:20+00:00

Zoo staff trained Juno how to slam dunk several years ago so she can exercise her elbow joints.

## Avon and Somerset Police 'institutionally racist', chief constable says
 - [https://www.bbc.co.uk/news/uk-england-bristol-65921150?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-bristol-65921150?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 05:11:45+00:00

Sarah Crew of Avon and Somerset Police says it is "not representative of the community we police".

## Malta v England: How Jodi Jones battled back from three ACL injuries to take on the Three Lions
 - [https://www.bbc.co.uk/sport/football/65876550?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65876550?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 05:07:13+00:00

How winger Jodi Jones resurrected his career and went from supporting England to facing them in a Euro qualifier with Malta.

## Last chance to see Hadrian's Wall Roman bathhouse before it's reburied
 - [https://www.bbc.co.uk/news/uk-england-cumbria-65902075?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-cumbria-65902075?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 05:05:07+00:00

Settlements around Birdoswald fort are being excavated in a major project.

## The Ashes: Relive the best of the 2019 England v Australia series
 - [https://www.bbc.co.uk/sport/av/cricket/65860140?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/65860140?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 05:02:52+00:00

BBC Sport relives standout performances from Stuart Broad, Steve Smith, Ben Stokes and Jofra Archer from the 2019 Ashes series.

## Japan redefines rape and raises age of consent in landmark move
 - [https://www.bbc.co.uk/news/world-asia-65887198?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-65887198?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 04:23:10+00:00

The laws redefine rape and raise the age of consent from 13, after public anger over rape acquittals.

## Isle of Wight: New dinosaur species discovered
 - [https://www.bbc.co.uk/news/uk-65924583?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-65924583?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 03:23:22+00:00

The giant armoured creature, named Vectipelta barretti, dates back between 66 and 145 million years.

## Why South Africa's Cyril Ramaphosa is leading Ukraine peace mission
 - [https://www.bbc.co.uk/news/world-africa-65916196?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-65916196?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 02:47:28+00:00

South Africa's president is spearheading the mediation effort at a time when he is under US pressure.

## Home Office admits asylum plans in doubt
 - [https://www.bbc.co.uk/news/uk-65921888?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-65921888?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 01:59:57+00:00

Plans to improve the asylum system are "in doubt", the Home Office tells the government's spending watchdog.

## Lincolnshire beans could provide British solution to imports
 - [https://www.bbc.co.uk/news/uk-england-lincolnshire-65908618?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-lincolnshire-65908618?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 01:56:08+00:00

Scientists have developed a haricot seed they hope will thrive in the UK after a 12-year project.

## The Aces: US pop band comes of age after a reckoning with Mormonism
 - [https://www.bbc.co.uk/news/entertainment-arts-65819217?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-65819217?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 01:20:58+00:00

Raised in conservative Utah, the Aces faced a challenge when three of its members came out.

## Kedarnath: 'Survivors took refuge in trees - and died of hunger'
 - [https://www.bbc.co.uk/news/world-asia-india-65912680?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-india-65912680?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 01:16:02+00:00

Ten years after devastating floods ravaged India's Uttarakhand state, a survivor looks back.

## Conor McGregor accused of sex assault in US
 - [https://www.bbc.co.uk/news/world-us-canada-65924407?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-65924407?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 01:05:37+00:00

The former UFC champion denies the allegations, which are being investigated by police in Miami.

## AI to stop water pollution before it happens
 - [https://www.bbc.co.uk/news/science-environment-65913940?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-65913940?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 01:01:37+00:00

An innovative AI project in southwest England is using sensors, satellites and data on past spills to try and predict future pollution.

## Five potential outcomes of AI in 99 seconds
 - [https://www.bbc.co.uk/news/world-us-canada-65885899?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-65885899?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-16 00:24:51+00:00

The BBC spoke to various experts about the dangers artificial intelligence could pose.

