# Source:Ign - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw, language:en-US

## Warhaven - Official Combat Trailer
 - [https://www.youtube.com/watch?v=L7qvlSKKjz4](https://www.youtube.com/watch?v=L7qvlSKKjz4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-06-16 23:00:08+00:00

Check out the latest Combat Trailer for Warhaven, a free-to-play 16-on-16 PVP medieval fantasy combat game. Smash, Slice, and Spellbind as you enter the Frey in Fall 2023.

Presented by Warhaven.

#IGN

## Diablo 4 Player Rages After Permadeath in Hardcore Mode - IGN Daily Fix
 - [https://www.youtube.com/watch?v=_czBlGtgv-U](https://www.youtube.com/watch?v=_czBlGtgv-U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-06-16 22:48:19+00:00

In Diablo 4, streamer Quin69 was hit with the Hall of the Fallen Heroes message while he was teleporting upon completing a dungeon crawl. The man finished a keystone, hit the portal, and somehow his character died while the loading screen was up. What’s crazy is #Diablo4 actually reported the death as ‘Slain by Environment’. Quin tweeted this message out to Diablo about #DiabloIV, telling the company to fix its game. Quin’s stats are really impressive. Will the streamer hop back in and grind it out in Diablo IV, we’ll have to wait and see. And Rockstar Games’ co-founder launches his very own gaming studio; will it be able to rival Rockstar’s GTA entries? All this and more in today’s Daily Fix of gaming news with Akeem Lawanson.

## What You Need To Be Ready for Final Fantasy 7 Rebirth and Other Upcoming Video Games
 - [https://www.youtube.com/watch?v=XS1V6XwZDpw](https://www.youtube.com/watch?v=XS1V6XwZDpw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-06-16 22:40:33+00:00

Summer Game Fest has dropped a ton of game announcements this year and we are sharing our personal game plan to get you ready to play our favorite picks and it’s all presented by the Marines. 

Some of our games include
Final Fantasy 7 Rebirth from Square Enix, set to release on the PS5 early 2024.
Marvel’s Spider-Man 2 from Insomniac (starring Spider-Man, Miles Morales, Venom, and Kraven the Hunter) will be released October 20, 2023 on PS5
Palworld is a brand-new, multiplayer, open-world survival crafting game, and will be released on Xbox Series X/S and PC later in 2023
Star Trek Infinite from Paradox Interactive is a grand strategy game that will be available on PC and Mac OS later this Fall.

## Marvel Studios’ Secret Invasion - Official Teaser Trailer (2023) Samuel L. Jackson, Cobie Smulders
 - [https://www.youtube.com/watch?v=0H_EcqxAAEM](https://www.youtube.com/watch?v=0H_EcqxAAEM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-06-16 21:00:00+00:00

Get another look at Marvel Studios’ Secret Invasion in this latest teaser for the upcoming series starring Samuel L. Jackson, Cobie Smulders, Ben Mendelsohn, Olivia Colman, Don Cheadle, Emilia Clarke, and more. Marvel Studios’ Secret Invasion begins streaming on Disney+ on June 21, 2023.

#MCU #IGN

## Arena Breakout - Official Global Pre-registration Trailer
 - [https://www.youtube.com/watch?v=SipHGPJrmr8](https://www.youtube.com/watch?v=SipHGPJrmr8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-06-16 20:09:50+00:00

Set to release globally in July, tactical FPS Arena Breakout is now available for pre-registration on Google Play and iOS.  Each battle is a high risk, winner-takes-all gamble. Eliminate adversaries head-on, with stealth, or bypass the bullets altogether. Players have the freedom to choose how they fight. Escape the combat area alive for a chance to strike it rich, but be prepared to fight for survival.

## Final Fantasy 16's New Game Plus Brings a Whole New Challenge – IGN First
 - [https://www.youtube.com/watch?v=m63uWjgq3rM](https://www.youtube.com/watch?v=m63uWjgq3rM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-06-16 20:00:13+00:00

We asked the game’s developers to talk us through Final Fantasy 16's New Game Plus, where the higher difficulty Final Fantasy Mode offers returning players a whole new challenge. In our exclusive gameplay video (see it above), Director Hiroshi Takai and Combat Director Ryota Suzuki explain how the enemies you fight will change on your second playthrough.

## Stan Lee - Official Trailer (2023) Stan Lee Documentary
 - [https://www.youtube.com/watch?v=pmcyVWfDacU](https://www.youtube.com/watch?v=pmcyVWfDacU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-06-16 19:00:31+00:00

Check out the trailer for Stan Lee, a documentary film about the comic books and pop culture icon.

From Marvel Studios and acclaimed director David Gelb, “Stan Lee” is the official documentary film about Stan “The Man” Lee and his journey to become one of the most influential people in the world of comic books and pop culture. Tracing his life from his challenging upbringing as Stanley Lieber to the meteoric rise of Marvel Comics, “Stan Lee” tells Stan’s story in his own words. Using only archival material—from personal home video, interviews and audio recordings—the film examines Stan’s origin story and what emerged from it: a far-reaching universe of stories with three-dimensional characters that have resonated with people all over the world. In this way, “Stan Lee” is both a story of comics and passion, and an intimate portrait of a man, his philosophy and its lasting impression. 

The executive producers of the documentary are Jeff Redmond, Andy Heyward, Gil Campion, Jamie McBriety, and Sarah Regan. The documentary's producers are David Gelb, Jason Sterman, and Brian McGinn. Lauren Goralski and Andrew McAllister serve as co-producers.

Marvel Studios’ Stan Lee Original Documentary is available now on Disney+.

#IGN #Marvel #Movies

## Gord - Official We Shall Take The North: Cinematic Intro Trailer
 - [https://www.youtube.com/watch?v=oqtFmXMKSkY](https://www.youtube.com/watch?v=oqtFmXMKSkY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-06-16 18:00:30+00:00

Check out the cinematic intro trailer for Gord to learn more about the story of this upcoming settlement-building survival game. Gord will be available on PlayStation 5, Xbox Series X/S, and Steam on August 8, 2023. A demo will be available as part of Steam Next Fest, featuring the first two scenarios of Gord's campaign.

#IGN #Gord #Gaming

## System Shock - Official Accolades Trailer
 - [https://www.youtube.com/watch?v=qELXEoA7iUM](https://www.youtube.com/watch?v=qELXEoA7iUM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-06-16 17:00:34+00:00

Get another look at System Shock in this latest trailer and see what some critics are saying about this remake of the 1994 game, available now on PC.

#IGN #SystemShock #Gaming

## The Freak Brothers: Season 2 Exclusive Red Band Trailer (2023) Woody Harrelson, Pete Davidson
 - [https://www.youtube.com/watch?v=mrzc4zU3aUw](https://www.youtube.com/watch?v=mrzc4zU3aUw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-06-16 16:00:39+00:00

The Freak Brothers" Season Two is set to premiere this summer on Tubi with the first four episodes available on June 25th, and the back four episodes coming to fans for another bingeable viewing experience on September 24.

The adult animated series returns with its all-star voice cast — Woody Harrelson, John Goodman, Pete Davidson, Tiffany Haddish, Adam Devine, Blake Anderson, Andrea Savage, La La Anthony and ScHoolboy Q. The series is produced by WTG Enterprises and by Lionsgate.

The Freak Brothers chronicle the escapades of a trio of stoner anti-establishment characters and their smart-ass cat who wake up from a 50-year nap after smoking a magical strain of weed in 1969 and must adjust to life with a new family in present-day San Francisco.

In the second season, the Freaks and Kitty’s Mary Jane-fueled misadventures will take them from their high school reunion to matching wits with Mark Zuckerberg, settling old scores with Mitch McConnell, and battling Seth Rogen in a Pot Brownie Bake-Off contest.

The Freak Brothers is based on Gilbert Shelton’s cult classic underground comic series and will celebrate its 55th anniversary this year.

#IGN

## Shadow Gambit: The Cursed Crew – Exclusive Mission Walkthrough
 - [https://www.youtube.com/watch?v=XiScNNkN5vE](https://www.youtube.com/watch?v=XiScNNkN5vE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-06-16 16:00:32+00:00

Head of Design Moritz Wagner walks you through a complete mission on one of the biggest islands in Shadow Gambit: The Cursed Crew, the stealth-strategy pirate game from the Desperados 3 developers at Mimimi Games that's due to be released for PC (Steam and Epic Games Store), PS5, and Xbox Series X|S on August 17. But you can play the demo during Steam Next Fest from June 19-26. Learn more on the official Steam page:  https://store.steampowered.com/app/1545560/Shadow_Gambit_The_Cursed_Crew/

## Secret Invasion: Episodes 1 and 2 Review
 - [https://www.youtube.com/watch?v=Re3x9io88MI](https://www.youtube.com/watch?v=Re3x9io88MI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-06-16 15:47:59+00:00

Check out our review of Episode 1 and 2 of Marvel Studio's Secret Invasion, and with what we've seen so far, Secret Invasion is a welcome and solid return for the MCU’s lesser-used gritty espionage template, even if its first two episodes lack the sense of fear that it really needs.

## Back to the Dawn - Official Steam Next Fest Trailer
 - [https://www.youtube.com/watch?v=htJudbXeQhE](https://www.youtube.com/watch?v=htJudbXeQhE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-06-16 15:00:27+00:00

Enjoy the latest trailer for Back to the Dawn, an upcoming prison prison-break RPG about a journalist who's been falsely imprisoned in a maximum security jail. You'll make alliances with gangs, solve puzzles, craft makeshift weapons and tools, and more. Check out the demo during Steam Next Fest.

#IGN #Gaming

## Will Batman Die in the DCU's Chapter One? | Super Debatable
 - [https://www.youtube.com/watch?v=LwbYjFF81w0](https://www.youtube.com/watch?v=LwbYjFF81w0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-06-16 14:15:01+00:00

James Gunn has been busy teasing his plans for Chapter One of DC Studios' ambitious superhero relaunch, and recent hints at the importance of Darwyn Cooke's New Frontier run suggest that not only could the villain of Gods and Monsters be a psychic island, but that Bruce Wayne's Batman may be in line for an Iron Man-esque sacrifice play.

#IGN #DCU

## ARC Raiders - Official Closed Alpha Teaser Trailer
 - [https://www.youtube.com/watch?v=LZNhA_7BH0Q](https://www.youtube.com/watch?v=LZNhA_7BH0Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-06-16 14:00:22+00:00

Check out the latest trailer for ARC Raiders to get a peek at gameplay, formidable foes, and more from this upcoming free-to-play, third-person, PvPvE extraction shooter set in a lethal future earth ravaged by a mechanized threat known as ARC. A Closed Alpha for ARC Raiders will be available on June 29, and signups are open now on Steam.

## The Flash: Every Cameo in the Multiverse Sequence
 - [https://www.youtube.com/watch?v=b26gTV429gg](https://www.youtube.com/watch?v=b26gTV429gg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-06-16 13:15:02+00:00

While cameos from other comic book characters in superhero movies have come to be the norm, there are a couple of factors that make the ones in The Flash particularly notable. 

The Flash is essentially a swan song to the DCEU, aka the Snyderverse. This December’s release of Aquaman and the Lost Kingdom is its final entry before James Gunn and Peter Safran’s DCU officially kicks off with 2025’s Superman: Legacy. The Flash is likely the final time we’ll see these particular incarnations of the Justice League.

Since The Flash is also a multiverse story, it brings in characters from alternate timelines such as Sasha Calle’s Supergirl or from past franchises like Michael Keaton’s Batman. But those two are not the only characters from other DC universes to appear in The Flash.

#IGN #TheFlash

## Halo Infinite - Official Season 4 Launch Trailer
 - [https://www.youtube.com/watch?v=aY6LuahyWRk](https://www.youtube.com/watch?v=aY6LuahyWRk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-06-16 01:00:01+00:00

Watch the launch trailer for Halo Infinite's Season 4: Infection to see what to expect, which features a new 100 tier Battle Pass, new maps, new equipment like the quantum translocator and threat seeker, and the return of the infection game mode. Season 4 of Halo Infinite will be available on June 20, 2023.

