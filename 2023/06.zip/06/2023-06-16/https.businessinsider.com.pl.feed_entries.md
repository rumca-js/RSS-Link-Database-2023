# Source:Business insider, URL:https://businessinsider.com.pl/.feed, language:en-US

## Sejm głosował nad odrzuceniem nowelizacji budżetu na 2023 r.
 - [https://businessinsider.com.pl/gospodarka/nowelizacja-budzetu-na-2023-r-sejm-glosowal-nad-odrzuceniem-projektu/ct3sbwk](https://businessinsider.com.pl/gospodarka/nowelizacja-budzetu-na-2023-r-sejm-glosowal-nad-odrzuceniem-projektu/ct3sbwk)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 20:01:41+00:00

Projekt nowelizacji budżetu na 2023 r. podwyższa limit wydatków i deficyt o ponad 20 mld zł. W piątek Sejm głosował nad odrzuceniem projektu.

## Płatność gotówką. Sejm wykreślił przepisy wprowadzone przez Polski Ład
 - [https://businessinsider.com.pl/wiadomosci/platnosc-gotowka-sejm-odkreca-przepisy-polskiego-ladu/5gxnj9y](https://businessinsider.com.pl/wiadomosci/platnosc-gotowka-sejm-odkreca-przepisy-polskiego-ladu/5gxnj9y)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 18:48:12+00:00

W piątek Sejm wykreślił wprowadzone w ramach Polskiego Ładu ograniczenia w płatnościach gotówką, które miały wejść w życie 1 stycznia 2024 r. Ile ma wynosić limit?

## Lex Tusk. Posłowie przyjęli prezydencki projekt
 - [https://businessinsider.com.pl/wiadomosci/lex-tusk-sejm-zdecydowal-w-sprawie-prezydenckiej-nowelizacji/wyvh3hn](https://businessinsider.com.pl/wiadomosci/lex-tusk-sejm-zdecydowal-w-sprawie-prezydenckiej-nowelizacji/wyvh3hn)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 17:34:36+00:00

W piątek Sejm przyjął zgłoszoną przez prezydenta Andrzeja Dudę nowelizację tzw. lex Tusk, czyli ustawy o komisji ds. badania wpływów rosyjskich na bezpieczeństwo Polski.

## Sejm zdecydował w sprawie emerytur pomostowych
 - [https://businessinsider.com.pl/wiadomosci/emerytury-pomostowe-poslowie-zdecydowali/chqvztl](https://businessinsider.com.pl/wiadomosci/emerytury-pomostowe-poslowie-zdecydowali/chqvztl)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 17:11:07+00:00

Sejm uchwalił w piątek nowelizację ustawy o emeryturach pomostowych uchylającą wygasający charakter tego świadczenia. To jeden z punktów porozumienia rządu z NSZZ "Solidarność".

## Piramida finansowa na fotowoltaikę. Setki oszukanych
 - [https://businessinsider.com.pl/prawo/piramida-finansowa-na-fotowoltaike-setki-oszukanych/cphkwsb](https://businessinsider.com.pl/prawo/piramida-finansowa-na-fotowoltaike-setki-oszukanych/cphkwsb)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 17:10:00+00:00

Spółka Zone Energy oszukała kilkaset osób w całej Polsce. Chodzi o instalacje fotowoltaiki i pomp ciepła. Łódzki oddział "Wyborczej" dotarł do informacji, że stoi za tym człowiek, który za inne oszustwa miał już siedzieć w więzieniu, ale... wykonanie kary zawieszono. To zawieszenie kosztowało wielu ludzi grube pieniądze.

## LOT ma nowego prezesa
 - [https://businessinsider.com.pl/wiadomosci/lot-ma-nowego-prezesa-kim-jest-michal-fijol/1ggdtpg](https://businessinsider.com.pl/wiadomosci/lot-ma-nowego-prezesa-kim-jest-michal-fijol/1ggdtpg)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 17:00:54+00:00

Rada nadzorcza PLL LOT powołała Michała Fijoła na prezesa spółki; od blisko siedmiu lat odpowiadał w zarządzie za sprawy handlowe — poinformował w piątek narodowy przewoźnik.

## LOT ma nowego prezesa
 - [https://businessinsider.com.pl/wiadomosci/michal-fijol-nowym-prezesem-lot/1ggdtpg](https://businessinsider.com.pl/wiadomosci/michal-fijol-nowym-prezesem-lot/1ggdtpg)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 17:00:54+00:00

Rada nadzorcza PLL LOT powołała Michała Fijoła na prezesa spółki; od blisko siedmiu lat odpowiadał w zarządzie za sprawy handlowe — poinformował w piątek narodowy przewoźnik.

## Rząd znowu zwiększa zadłużenie. Czy budżet wytrzyma rosnące wydatki?
 - [https://businessinsider.com.pl/gospodarka/polski-budzet-peka-w-szwach-na-co-trafia-pieniadze-ze-wzrostu-dlugu/4lvqdmm](https://businessinsider.com.pl/gospodarka/polski-budzet-peka-w-szwach-na-co-trafia-pieniadze-ze-wzrostu-dlugu/4lvqdmm)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 16:44:51+00:00

Nawet o 300 mld zł może przez zaledwie kilka miesięcy urosnąć polski dług publiczny i osiągnąć nienotowane w historii ponad 1,8 bln zł. Gospodarka łapie zadyszkę, więc pogarszają się wskaźniki takie jak dług publiczny oraz deficyt finansów publicznych w stosunku do rocznego produktu krajowego brutto. Ekonomiści oceniają, czy to powód do bicia alarm.

## Wcześniejsze emerytury dla nauczycieli. Sejm przyjął zmiany
 - [https://businessinsider.com.pl/wiadomosci/wczesniejsze-emerytury-dla-nauczycieli-poslowie-zdecydowali-kto-skorzysta/9xf6xn6](https://businessinsider.com.pl/wiadomosci/wczesniejsze-emerytury-dla-nauczycieli-poslowie-zdecydowali-kto-skorzysta/9xf6xn6)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 16:21:05+00:00

Sejm uchwał w piątek ustawę dającą prawo do emerytury na szczególnych zasadach nauczycielom, którzy podjęli pracę przed wprowadzeniem reformy emerytalnej z 1999 r.

## Donald Tusk w Poznaniu. "Państwo powinno zapewnić in-vitro"
 - [https://businessinsider.com.pl/polityka/donald-tusk-w-poznaniu-panstwo-powinno-zapewnic-in-vitro/d5zzfxk](https://businessinsider.com.pl/polityka/donald-tusk-w-poznaniu-panstwo-powinno-zapewnic-in-vitro/d5zzfxk)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 16:20:59+00:00

Wiec na planu Wolności w Poznaniu poprzedził występ Małgorzaty Ostrowskiej, byłej wokalistki zespołu Lombard. Na spotkaniu zebrało się kilka tysięcy osób. Przemowę Donalda Tuska poprzedziły wypowiedzi prezydenta miasta oraz kobiet apelujących o równe prawa kobiet i finansowanie in-vitro.

## Putin: Rosja dostarczyła broń jądrową na Białoruś
 - [https://businessinsider.com.pl/wiadomosci/putin-rosyjska-bron-jadrowa-juz-na-bialorusi/c49h137](https://businessinsider.com.pl/wiadomosci/putin-rosyjska-bron-jadrowa-juz-na-bialorusi/c49h137)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 15:26:34+00:00

Władimir Putin powiedział, że Rosja dostarczyła Białorusi pierwszą taktyczną broń nuklearną. Stało się to trzy miesiące po ogłoszeniu planu, który grozi zaostrzeniem napięć ze Stanami Zjednoczonymi i ich sojusznikami w związku z wojną w Ukrainie — podaje Bloomberg. Przywódca Rosji został zapytany o potencjalne użycie broni nuklearnej.

## Twitter przez lata nie płacił za utwory muzyczne. Pozew za 250 mln dol. może to zmienić
 - [https://businessinsider.com.pl/wiadomosci/twitter-od-lat-nie-placil-za-muzyke-chroniona-prawami-pozew-moze-to-zmienic/gqcn91r](https://businessinsider.com.pl/wiadomosci/twitter-od-lat-nie-placil-za-muzyke-chroniona-prawami-pozew-moze-to-zmienic/gqcn91r)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 15:20:28+00:00

Kłopoty prawne Twittera wciąż rosną. Tym razem związane są z nieuprawnionym korzystaniem z utworów muzycznych.

## Sjesta w Polsce. Związkowcy zaczynają batalię o zmianę prawa
 - [https://businessinsider.com.pl/prawo/sjesta-w-polsce-zwiazkowcy-zaczynaja-batalie-o-zmiane-prawa/s6klxv8](https://businessinsider.com.pl/prawo/sjesta-w-polsce-zwiazkowcy-zaczynaja-batalie-o-zmiane-prawa/s6klxv8)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 15:13:45+00:00

Może nie akurat w tym roku, ani nawet w poprzednim, ale związkowcy z OPZZ twierdzą, że w Polsce robi się za gorąco i czas zadbać w ustawie, żeby była przerwa w zależności od temperatury. Polski pracownik powinien według nich zyskać prawo do sjesty jak we Włoszech czy Hiszpanii. Chodzi o to, że w prawie nie ma górnego ograniczenia temperatury, w której można pracować.

## Porównali dwa zdjęcia z Korei Północnej. Zaczęły wyłaniać się miasta
 - [https://businessinsider.com.pl/wiadomosci/porownali-zdjecia-z-korei-polnocnej-kim-dzong-un-podarowal-nieco-swiatla/k2x0k17](https://businessinsider.com.pl/wiadomosci/porownali-zdjecia-z-korei-polnocnej-kim-dzong-un-podarowal-nieco-swiatla/k2x0k17)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 14:52:00+00:00

Problem z dostawami prądu występuje w Korei Północnej od lat. Teraz za sprawą astronautów przebywających na pokładzie Międzynarodowej Stacji Kosmicznej (ISS) mamy możliwość porównać, jak sytuacja zmieniła się przez lata. Wbrew powszechnej opinii o regresie, za rządów Kim Dzong Una państwo nieco się rozświetliło.

## Tyle średnich pensji potrzeba na zakup mieszkania w twoim mieście. Prawdziwy test cierpliwości
 - [https://businessinsider.com.pl/poradnik-finansowy/oszczedzanie/ile-trzeba-oszczedzac-na-zakup-mieszkania-porownanie-16-miast/hcexysj](https://businessinsider.com.pl/poradnik-finansowy/oszczedzanie/ile-trzeba-oszczedzac-na-zakup-mieszkania-porownanie-16-miast/hcexysj)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 14:09:44+00:00

Średnio około 10 lat trzeba oszczędzać wszystkie zarabiane pieniądze, by móc uzbierać kwotę potrzebną na zakup mieszkania za gotówkę. Najbardziej dostępne są lokale dla mieszkańców Katowic, a najgorzej wygląda sytuacja w Białymstoku i Warszawie.

## Oto siedem dróg, które należą do najbardziej niebezpiecznych na świecie
 - [https://businessinsider.com.pl/lifestyle/podroze/bardzo-niebezpieczne-drogi-na-swiecie/xc0esvr](https://businessinsider.com.pl/lifestyle/podroze/bardzo-niebezpieczne-drogi-na-swiecie/xc0esvr)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 13:50:00+00:00

Na wielu drogach na świecie spotkamy spore ograniczenia prędkości, ale tylko nieliczne cechują się bardzo trudnymi warunkami - kierowcy jadą po zamarzniętej powierzchni lub ryzykują śmierć w wyniku upadku z ogromnej wysokości.

## Ćwiczenia uszczęśliwiają bardziej niż pieniądze. Tak mówi badanie Yale i Oxfordu
 - [https://businessinsider.com.pl/lifestyle/cwiczenia-uszczesliwiaja-bardziej-niz-pieniadze/c5v3843](https://businessinsider.com.pl/lifestyle/cwiczenia-uszczesliwiaja-bardziej-niz-pieniadze/c5v3843)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 13:50:00+00:00

Naukowcy z Yale i Oxfordu twierdzą, że ćwiczenia fizyczne są ważniejsze dla zdrowia psychicznego niż status ekonomiczny.

## Inteligentny smartwatch o klasycznym wyglądzie - brzmi jak prezent dla stylowego taty?
 - [https://businessinsider.com.pl/technologie/nowe-technologie/inteligentny-smartwatch-o-klasycznym-wygladzie-brzmi-jak-prezent-dla-stylowego-taty/4ck11p9](https://businessinsider.com.pl/technologie/nowe-technologie/inteligentny-smartwatch-o-klasycznym-wygladzie-brzmi-jak-prezent-dla-stylowego-taty/4ck11p9)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 13:41:00+00:00

Zbliża się 23 czerwca, czyli Dzień Ojca. Jeśli chcesz wprowadzić swojego tatę, który jest fanem klasyki, w klimat nowych technologii, rozważ zakup prezentu w postaci eleganckiego smartwatcha posiadającego w sobie coś ponadczasowego. Korzystanie z funkcji inteligentnych zegarków może okazać się dla rodzica wspaniałą przygodą i wesprzeć go w codziennym monitoringu zdrowia.

## Gigantyczne straty kultowego stadionu. Kosztował setki milionów złotych
 - [https://businessinsider.com.pl/biznes/gigantyczne-straty-kultowego-stadionu-kosztowal-setki-milionow-zlotych/3xvpj50](https://businessinsider.com.pl/biznes/gigantyczne-straty-kultowego-stadionu-kosztowal-setki-milionow-zlotych/3xvpj50)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 13:39:17+00:00

Stadiony piłkarskie w Polsce kosztowały miliardy złotych, są piękne, ale teraz i tak dobrze, jak wychodzą na zero. Nie można tego powiedzieć o kultowym Kotle Czarownic, czyli Stadionie Śląskim w Chorzowie. Spółka zarządzająca obiektem nie chce ujawniać informacji, a te, które podał były członek zarządu województwa, pokazują, że jest coraz gorzej, choć i wcześniej było bardzo źle.

## Olbrzymie straty kultowego stadionu. Kosztował setki milionów złotych
 - [https://businessinsider.com.pl/biznes/olbrzymie-straty-kultowego-stadionu-kosztowal-setki-milionow-zlotych/3xvpj50](https://businessinsider.com.pl/biznes/olbrzymie-straty-kultowego-stadionu-kosztowal-setki-milionow-zlotych/3xvpj50)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 13:39:17+00:00

Stadiony piłkarskie w Polsce kosztowały miliardy złotych, są piękne, ale teraz i tak dobrze, jak wychodzą na zero. Nie można tego powiedzieć o kultowym Kotle Czarownic, czyli Stadionie Śląskim w Chorzowie. Spółka zarządzająca obiektem nie chce ujawniać informacji, a te, które podał były członek zarządu województwa, pokazują, że jest coraz gorzej, choć i wcześniej było bardzo źle.

## Putin przemawia na Forum Ekonomicznym w Petersburgu. Tłumaczy dziurę w rosyjskim budżecie
 - [https://businessinsider.com.pl/gospodarka/putin-przemawia-w-petersburgu-mowi-o-dziurze-budzetowej-i-wydatkach-na-obrone/s4ek01s](https://businessinsider.com.pl/gospodarka/putin-przemawia-w-petersburgu-mowi-o-dziurze-budzetowej-i-wydatkach-na-obrone/s4ek01s)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 13:05:22+00:00

Władimir Putin, podczas przemówienia na Forum Ekonomicznym w Sankt Petersburgu, tłumaczył deficyt budżetowy Rosji przekładaniem wydatków "na wcześniejszy termin". Dodał, że Rosja zwiększyła też wydatki na bezpieczeństwo i obronę. — Jesteśmy do tego zobowiązani w celu ochrony suwerenności naszego kraju — powiedział.

## Nieoceniona pomoc — najpopularniejsze roboty kuchenne
 - [https://businessinsider.com.pl/technologie/nieoceniona-pomoc-najpopularniejsze-roboty-kuchenne/l7s1kge](https://businessinsider.com.pl/technologie/nieoceniona-pomoc-najpopularniejsze-roboty-kuchenne/l7s1kge)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 13:00:09+00:00

Roboty kuchenne stanowią nieocenioną pomoc dla każdego kucharza, nie tylko amatora. Przedstawiamy najnowszy ranking popularności tych urządzeń według danych ze Skąpiec.pl. Jest to cenna wskazówka dla tych, którzy chcą kupić robota dla siebie.

## Ekonomiści o nowej płacy minimalnej: wkroczymy na niezbadany obszar
 - [https://businessinsider.com.pl/gospodarka/placa-minimalna-w-2024-r-mocno-wzrosnie-wkroczymy-na-niezbadany-obszar/9lmrly0](https://businessinsider.com.pl/gospodarka/placa-minimalna-w-2024-r-mocno-wzrosnie-wkroczymy-na-niezbadany-obszar/9lmrly0)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 12:43:17+00:00

W XXI w. tylko w dwóch okresach płaca minimalna rosła w Polsce wyraźnie szybciej od przeciętnego wynagrodzenia. Teraz zapowiada się trzeci taki przypadek. "Jeśli nasze prognozy się sprawdzą, zobaczymy największą rozbieżność między tymi dwoma wielkościami w historii szeregu" — wskazują ekonomiści Pekao. Mówią też o wpływie na ceny.

## Z wierzchu kultowy design, pod maską nowoczesny silnik elektryczny
 - [https://businessinsider.com.pl/technologie/motoryzacja/z-wierzchu-kultowy-design-pod-maska-nowoczesny-silnik-elektryczny/7bn13zy](https://businessinsider.com.pl/technologie/motoryzacja/z-wierzchu-kultowy-design-pod-maska-nowoczesny-silnik-elektryczny/7bn13zy)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 12:24:00+00:00

MINI ma w swojej ofercie auta elektryczne, które dają gokartowe wrażenia z jazdy, jednak w przeciwieństwie do modeli z silnikami benzynowymi, robią to bez generowania spalin. Co ciekawe, elektryczne MINI Cooper SE w 2022 roku odnotowało znaczny wzrost sprzedaży i było najczęściej kupowanym modelem brytyjskiej marki. Poznajmy możliwości zelektryfikowanego napędu zamieszczonego w aucie nawiązującym designem do kultowego klasyka.

## W końcu wyraźna zmiana w cenach. NBP publikuje najnowsze wyliczenia
 - [https://businessinsider.com.pl/gospodarka/inflacja-bazowa-w-koncu-wyrazniej-spadla-zobacz-najnowsze-dane-z-nbp/plq59xp](https://businessinsider.com.pl/gospodarka/inflacja-bazowa-w-koncu-wyrazniej-spadla-zobacz-najnowsze-dane-z-nbp/plq59xp)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 12:00:50+00:00

Zwykła inflacja spada od lutego, ale dopiero teraz wyraźniejsze hamowanie zaliczyła inflacja bazowa. Wskaźnik spadł do 11,5 proc. — poinformował NBP. O tyle w rok średnio zwiększyły się ceny dóbr i usług z wyłączeniem żywności i energii. Na wartość tej inflacji polityka pieniężna ma relatywnie duży wpływ.

## Zaplanuj urlop na jednej z greckich wysp. TOP 5 hoteli przy plaży
 - [https://businessinsider.com.pl/lifestyle/podroze/zaplanuj-urlop-na-greckich-wyspach-top-5-hoteli-przy-plazy/c3qg3wj](https://businessinsider.com.pl/lifestyle/podroze/zaplanuj-urlop-na-greckich-wyspach-top-5-hoteli-przy-plazy/c3qg3wj)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 12:00:00+00:00

Śródziemnomorski klimat, znakomita kuchnia, starożytne zabytki, taniec zorba, oliwki oraz piękne wyspy. Grecja to z pewnością jeden z najbardziej malowniczych krajów i doskonały pomysł na urlop. U jej wybrzeża znajduje się około dwóch i pół tysiąca wysp i wysepek. Wiele z nich jest niezamieszkałych, a część z nich to perły światowej turystyki. Do najpopularniejszych należą: Kreta, Rodos, Korfu, ale równie piękne, choć mniej znane, są: urokliwe Evia i Kos, do których odwiedzenia zachęcamy w artykule. To na tych wyspach znaleźliśmy wolne miejsca noclegowe, w hotelach położonych przy samej plaży i w bardzo atrakcyjnych cenach. Zapraszamy!

## Rosyjscy oligarchowie będą finansować odbudowę Ukrainy. Tego chce Kongres USA
 - [https://businessinsider.com.pl/wiadomosci/fortuny-rosyjskich-oligarchow-pomoga-ukrainie-tego-chca-usa/nch0hy9](https://businessinsider.com.pl/wiadomosci/fortuny-rosyjskich-oligarchow-pomoga-ukrainie-tego-chca-usa/nch0hy9)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 11:46:50+00:00

W amerykańskim Kongresie toczą się prace nad ustawą, która pozwoli finansować pomoc i powojenną odbudowę Ukrainy. Chodzi o zamrożone w USA majątki prawie 500 rosyjskich oligarchów i przedsiębiorców. Wartość majątku tylko 28 z nich to prawie 150 mln dol.

## Zarabiał kilkanaście milionów rocznie. Pieniądze dla Kuby nie są wyznacznikiem
 - [https://businessinsider.com.pl/wiadomosci/ile-blaszczykowski-zarabial-w-trakcie-kariery-ogromne-kwoty/h84v1g6](https://businessinsider.com.pl/wiadomosci/ile-blaszczykowski-zarabial-w-trakcie-kariery-ogromne-kwoty/h84v1g6)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 11:35:01+00:00

— Gram tylko w piłkę nożną, nie powinienem zarabiać więcej niż lekarz czy policjant — mówił Jakub Błaszczykowski w 2016 r. niemieckiej gazecie "Taff". I choć w trakcie kariery zarabiał nawet kilkanaście milionów złotych rocznie, potrafił też pokazać, że pieniądze nie stanowią dla niego największej wartości. W piątkowy wieczór podczas meczu Polska — Niemcy po raz ostatni wybiegnie na boisko w narodowych barwach.

## Szef Ubera ujawnia najczęstszy błąd w karierze, jaki popełniają młodzi ludzie
 - [https://businessinsider.com.pl/poradnik-finansowy/szef-ubera-ujawnia-najczestszy-blad-w-karierze-jaki-popelniaja-mlodzi-ludzie/y7qscsp](https://businessinsider.com.pl/poradnik-finansowy/szef-ubera-ujawnia-najczestszy-blad-w-karierze-jaki-popelniaja-mlodzi-ludzie/y7qscsp)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 11:22:41+00:00

Prezes Ubera Dara Khosrowshahi zwrócił się z radą do osób, które dopiero rozpoczynają swoją karierę na rynku pracy. — Moja rada dla młodych ludzi brzmi: nie przesadzajcie z planowaniem, nigdy nie wiadomo, jakie możliwości się pojawią — stwierdził.

## Trump wszedł do restauracji i obiecał wszystkim jedzenie. Nie zapłacił i wyszedł
 - [https://businessinsider.com.pl/gospodarka/trump-wszedl-i-obiecal-wszystkim-jedzenie-nie-zaplacil-i-wyszedl/b9x70qq](https://businessinsider.com.pl/gospodarka/trump-wszedl-i-obiecal-wszystkim-jedzenie-nie-zaplacil-i-wyszedl/b9x70qq)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 11:14:33+00:00

Trump przyszedł do restauracji w Miami i obiecał wszystkim jedzenie, ale wyszedł, nie płacąc za nic. Restauracja była wypełniona po brzegi sympatykami Trumpa, którzy chętnie składali mu życzenia urodzinowe.

## Trump wszedł do restauracji i obiecał wszystkim jedzenie. Wyszedł i nie zapłacił za nic
 - [https://businessinsider.com.pl/gospodarka/trump-wszedl-i-obiecal-wszystkim-jedzenie-wyszedl-i-nie-zaplacil-za-nic/b9x70qq](https://businessinsider.com.pl/gospodarka/trump-wszedl-i-obiecal-wszystkim-jedzenie-wyszedl-i-nie-zaplacil-za-nic/b9x70qq)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 11:14:33+00:00

Trump przyszedł do restauracji w Miami i obiecał wszystkim jedzenie, ale wyszedł nie płacąc za nic. Restauracja była wypełniona po brzegi sympatykami Trumpa, którzy chętnie składali mu życzenia urodzinowe.

## Mobilne Żabki ruszają w Polskę. Na trasie popularne koncerty
 - [https://businessinsider.com.pl/biznes/mobilne-zabki-ruszaja-w-polske-na-trasie-popularne-koncerty/yd74ybm](https://businessinsider.com.pl/biznes/mobilne-zabki-ruszaja-w-polske-na-trasie-popularne-koncerty/yd74ybm)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 11:13:09+00:00

Jednym z nowszych konceptów Żabki jest "mobilna Żabka". Od kilku lat jest obecna na wydarzeniach w całym kraju. Podobnie będzie w tym roku. W planach jest obsłużenie 10 koncertów.

## Mobilne Żabki ruszają w Polskę. Na trasie wielkie koncerty
 - [https://businessinsider.com.pl/biznes/mobilne-zabki-ruszaja-w-polske-na-trasie-wielkie-koncerty/yd74ybm](https://businessinsider.com.pl/biznes/mobilne-zabki-ruszaja-w-polske-na-trasie-wielkie-koncerty/yd74ybm)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 11:13:09+00:00

Jednym z nowszych konceptów Żabki jest "mobilna Żabka". Od kilku lat jest obecna na wydarzeniach w całym kraju. Podobnie będzie w tym roku. W planach jest obsłużenie 10 koncertów.

## Pięć błędów, których lepiej nie popełnić w czasie telefonicznej rozmowy o pracę
 - [https://businessinsider.com.pl/lifestyle/piec-bledow-ktorych-lepiej-nie-popelnic-w-czasie-telefonicznej-rozmowy-o-prace/1jjefpp](https://businessinsider.com.pl/lifestyle/piec-bledow-ktorych-lepiej-nie-popelnic-w-czasie-telefonicznej-rozmowy-o-prace/1jjefpp)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 11:04:00+00:00

Rozmowa telefoniczna jest jednym z początkowych etapów procesu rekrutacyjnego. Brak kontaktu wzrokowego z przedstawicielem firmy może utrudniać mu zapamiętanie naszej kandydatury, dlatego warto pamiętać o kilku sposobach na odpowiednie zaprezentowanie się podczas rozmowy przez telefon.

## Subiektywny przegląd najładniejszych smartbandów
 - [https://businessinsider.com.pl/technologie/subiektywny-przeglad-najladniejszych-smartbandow/n0q564h](https://businessinsider.com.pl/technologie/subiektywny-przeglad-najladniejszych-smartbandow/n0q564h)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 11:00:30+00:00

Smartbandy w przeszłości nie należały do najładniejszych urządzeń. Z biegiem czasu konkurencja na rynku się zwiększyła i producenci zaczęli wyróżniać swoje produkty nie tylko dodatkowymi funkcjami, ale również pod względem designu. Wybraliśmy pięć naszym zdaniem najładniejszych opasek sportowych.

## Bill Gates w Pekinie. Xi nazwał go "starym przyjacielem"
 - [https://businessinsider.com.pl/wiadomosci/bill-gates-w-pekinie-xi-nazwal-go-starym-przyjacielem/4s7l81w](https://businessinsider.com.pl/wiadomosci/bill-gates-w-pekinie-xi-nazwal-go-starym-przyjacielem/4s7l81w)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 10:41:43+00:00

Współzałożyciel Microsoftu Bill Gates spotkał się w piątek z przywódcą Chin Xi Jinpingiem. To jeden z pierwszych kontaktów między wysoko postawionym amerykańskim biznesmenem a prezydentem Chin w ostatnich latach w obliczu rosnących napięć geopolitycznych — podał "Financial Times".

## Chiny otwierają rynek na polską wołowinę. Embargo trwało 22 lata
 - [https://businessinsider.com.pl/gospodarka/chiny-otwieraja-rynek-na-polska-wolowine-szykujmy-sie-na-wzrost-cen/2qk55gn](https://businessinsider.com.pl/gospodarka/chiny-otwieraja-rynek-na-polska-wolowine-szykujmy-sie-na-wzrost-cen/2qk55gn)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 10:30:40+00:00

Czy ktoś w Polsce pamięta jeszcze chorobę wściekłych krów? W Chinach wciąż pamiętali, że taka u nas była i do niedawna obowiązywało embargo na wołowinę z Polski. Teraz Państwo Środka najwyraźniej potrzebuje żywności, bo nasz kraj odwiedzili chińscy eksperci. I stało się, po 22 latach embargo zostało zniesione. Polscy producenci otwierają szampana, bo otworem stoi przed nimi gigantyczny rynek. Gorzej mogą to odbierać konsumenci.

## Embargo trwało 22 lata. Chiny otwierają swój rynek na polską wołowinę
 - [https://businessinsider.com.pl/gospodarka/embargo-trwalo-22-lata-chiny-otwieraja-swoj-rynek-na-polska-wolowine/2qk55gn](https://businessinsider.com.pl/gospodarka/embargo-trwalo-22-lata-chiny-otwieraja-swoj-rynek-na-polska-wolowine/2qk55gn)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 10:30:40+00:00

Czy ktoś w Polsce pamięta jeszcze chorobę wściekłych krów? W Chinach wciąż pamiętali, że taka u nas była i do niedawna obowiązywało embargo na wołowinę z Polski. Teraz Państwo Środka najwyraźniej potrzebuje żywności, bo nasz kraj odwiedzili chińscy eksperci. I stało się, po 22 latach embargo zostało zniesione. Polscy producenci otwierają szampana, bo otworem stoi przed nimi gigantyczny rynek. Gorzej mogą to odbierać konsumenci.

## Eurostat bardziej łaskawy dla polskiej inflacji. Tak wypadamy na tle Unii Europejskiej
 - [https://businessinsider.com.pl/gospodarka/eurostat-bardziej-laskawy-dla-polskiej-inflacji-jak-wypadamy-na-tle-ue/1pjwfcc](https://businessinsider.com.pl/gospodarka/eurostat-bardziej-laskawy-dla-polskiej-inflacji-jak-wypadamy-na-tle-ue/1pjwfcc)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 10:28:42+00:00

Inflacja w Polsce spada, ale ciągle jest znacznie większa niż w innych krajach UE. Średnią dla strefy euro przebijamy dwukrotnie. Większa drożyzna panuje tylko na Węgrzech. W czterech krajach wskaźniki są na poziomach, które chcielibyśmy osiągnąć, ale będą w naszym zasięgu dopiero w 2025 r.

## Lex Tusk. Wniosek prezydenta do Trybunału Konstytucyjnego w tym tygodniu
 - [https://businessinsider.com.pl/wiadomosci/lex-tusk-wniosek-prezydenta-do-trybunalu-konstytucyjnego-w-tym-tygodniu/87dk0he](https://businessinsider.com.pl/wiadomosci/lex-tusk-wniosek-prezydenta-do-trybunalu-konstytucyjnego-w-tym-tygodniu/87dk0he)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 09:56:16+00:00

W tym tygodniu zostanie skierowany, zapowiadany przez prezydenta Andrzeja Dudę, wniosek do TK w sprawie ustawy o powołaniu komisji ds. wpływów rosyjskich — poinformowała w Sejmie minister Małgorzata Paprocka.

## Czy kobiety stoją za sterami biznesu? Trwa nabór do konkursu Lidl Fair Pay
 - [https://businessinsider.com.pl/biznes/czy-kobiety-stoja-za-sterami-biznesu-trwa-nabor-do-konkursu-lidl-fair-pay/b5ml0gs](https://businessinsider.com.pl/biznes/czy-kobiety-stoja-za-sterami-biznesu-trwa-nabor-do-konkursu-lidl-fair-pay/b5ml0gs)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 09:51:03+00:00

Do 2026 roku kobiety mają zajmować 40 proc. najwyższych stanowisk w spółkach – to cel dyrektywy przyjętej pod koniec 2022 roku przez Parlament Europejski. Na akceptację Rady oczekuje także dyrektywa o równości i przejrzystości wynagrodzeń. Działania na rzecz wzmacniania pozycji kobiet i równości płac podejmowane są również w Polsce. Jednym z nich jest nagroda dla firm Lidl Fair Pay, której celem jest uhonorowanie przedsiębiorstw, gdzie równość jest wartością. Jak można wziąć udział?

## Chińska gospodarka jest w gorszym stanie, niż nam się wydaje
 - [https://businessinsider.com.pl/wiadomosci/chinska-gospodarka-ma-wieksze-problemy-niz-nam-sie-wydaje/debp26d](https://businessinsider.com.pl/wiadomosci/chinska-gospodarka-ma-wieksze-problemy-niz-nam-sie-wydaje/debp26d)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 09:46:43+00:00

Pomimo wielkich nadziei powrotu Chin do gry, gospodarcze ożywienie po COVID-19 w kraju Xi Jinpinga jest dalekie od eksplozji gospodarczej, by nie powiedzieć słabe.

## Co przyniesie spotkanie USA-Chiny? Biały Dom liczy na przełom w relacjach z innym krajem
 - [https://businessinsider.com.pl/wiadomosci/co-przyniesie-spotkanie-usa-chiny-bialy-dom-stawia-na-relacje-z-innym-krajem/hztl6cm](https://businessinsider.com.pl/wiadomosci/co-przyniesie-spotkanie-usa-chiny-bialy-dom-stawia-na-relacje-z-innym-krajem/hztl6cm)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 09:34:16+00:00

Doradca prezydenta USA Jake Sullivan ocenił, że to nie wizyta Antony'ego Blinkena w Chinach będzie najważniejszym wydarzeniem przyszłego tygodnia. Wskazał, że dużo istotniejsze będzie inne spotkanie.

## "Europa może ponownie pogrążyć się w kryzysie gazowym". To sygnał ostrzegawczy
 - [https://businessinsider.com.pl/gielda/wiadomosci/europa-moze-ponownie-pograzyc-sie-w-kryzysie-gazowym-to-sygnal-ostrzegawczy/wjbxxyy](https://businessinsider.com.pl/gielda/wiadomosci/europa-moze-ponownie-pograzyc-sie-w-kryzysie-gazowym-to-sygnal-ostrzegawczy/wjbxxyy)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 09:21:49+00:00

Sytuacja na rynku gazu ciągle nie jest ustabilizowana. Eksperci wskazują na dużą wrażliwość Europy i ostrzegają przed ryzykiem ponownego kryzysu. Ostatnio kontrakty terminowe na surowiec podskoczyły jednego dnia aż o 30 proc. Ten rajd to "przedsmak potencjalnego ryzyka".

## Spotify rezygnuje z gigantycznego kontraktu na podcast. Księżną Meghan ominą miliony
 - [https://businessinsider.com.pl/technologie/nowe-technologie/spotify-rezygnuje-z-gigantycznego-kontraktu-ksiezna-meghan-omina-miliony/lttnwln](https://businessinsider.com.pl/technologie/nowe-technologie/spotify-rezygnuje-z-gigantycznego-kontraktu-ksiezna-meghan-omina-miliony/lttnwln)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 09:01:51+00:00

Firma Spotify zrezygnowała po jednym sezonie z umowy z księżną Meghan, żoną brytyjskiego księcia Harry'ego, na tworzenie przez nią podcastów. Autorka nie stworzyła wystarczającej ilości materiału, by otrzymać pełną kwotę za pierwszy sezon. A był to gigantyczny kontrakt.

## Barometr ofert pracy z najgorszym wynikiem od prawie dwóch lat. Tam są największe problemy
 - [https://businessinsider.com.pl/gospodarka/barometr-ofert-pracy-najnizej-od-prawie-dwoch-lat-tam-najwieksze-problemy/e9yszvm](https://businessinsider.com.pl/gospodarka/barometr-ofert-pracy-najnizej-od-prawie-dwoch-lat-tam-najwieksze-problemy/e9yszvm)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 08:44:57+00:00

W rok wskaźnik ofert pracy wyliczany przez BIEC pogorszył się o blisko jedną trzecią. Za główną przyczynę spadków eksperci uważają czynniki koniunkturalne, spowodowane schłodzeniem gospodarki zarówno krajowej, jak i ogólnoświatowej. W przypadku wybranych zawodów obserwują jednak długofalowe zmiany gospodarcze i społeczne.

## Polska wchodzi do gry o rynek półprzewodników. Intel wybuduje pod Wrocławiem wielki zakład
 - [https://businessinsider.com.pl/biznes/intel-wybuduje-pod-wroclawiem-wielki-zaklad-polska-wchodzi-do-gry-o-rynek/vd7cl3t](https://businessinsider.com.pl/biznes/intel-wybuduje-pod-wroclawiem-wielki-zaklad-polska-wchodzi-do-gry-o-rynek/vd7cl3t)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 08:32:57+00:00

Intel planuje w Polsce inwestycję, która ma pochłonąć 4,6 mld dol. i stworzyć 2 tys. miejsc pracy w samej firmie i kolejne tysiące u jej dostawców. Nowy zakład ma wyjść naprzeciw rosnącemu zapotrzebowaniu na półprzewodnikowe układy scalone i pomóc w realizacji celów UE w tym obszarze.

## Policzyli oferty pracy w maju. "Potwierdzenie negatywnej tendencji"
 - [https://businessinsider.com.pl/gospodarka/policzyli-oferty-pracy-w-maju-potwierdzenie-negatywnej-tendencji/8y2zs7k](https://businessinsider.com.pl/gospodarka/policzyli-oferty-pracy-w-maju-potwierdzenie-negatywnej-tendencji/8y2zs7k)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 08:32:33+00:00

Choć skala redukcji ofert pracy w maju nie była duża, spadek stanowi kolejne potwierdzenie negatywnej tendencji na rynku wakatów, trwającej już 12. miesiąc – wynika z Barometru Ofert Pracy. Od początku tego roku w zawodach związanych z pracą fizyczną liczba ogłoszeń powoli wzrasta.

## Koniec rynku pracownika? Wakaty w Polsce znikają błyskawicznie
 - [https://businessinsider.com.pl/praca/koniec-rynku-pracownika-wakaty-w-polsce-znikaja-blyskawicznie/zl64e53](https://businessinsider.com.pl/praca/koniec-rynku-pracownika-wakaty-w-polsce-znikaja-blyskawicznie/zl64e53)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 08:20:45+00:00

Cała Europa szuka pracowników, którzy zajęliby wolne stanowiska. Jak opisuje "Rzeczpospolita", Polska radzi sobie jednak lepiej z uzupełnieniem wakatów niż wiele innych państw kontynentu. Wolne miejsca pracy bardzo szybko znikają.

## W tym roku Wigilia dniem wolnym od handlu. Jest deklaracja
 - [https://businessinsider.com.pl/praca/w-tym-roku-wigilia-dniem-wolnym-od-handlu-jest-deklaracja/7lb19xv](https://businessinsider.com.pl/praca/w-tym-roku-wigilia-dniem-wolnym-od-handlu-jest-deklaracja/7lb19xv)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 07:51:43+00:00

W tym roku Wigilia po raz pierwszy nie będzie pracująca, choć przypada w niedzielę handlową — poinformował w piątek minister rozwoju i technologii Waldemar Buda. Zmienimy to w tym roku — dodał.

## Zły znak dla kierowców przed weekendem. Takich zmian w cenach ropy nie było od tygodni
 - [https://businessinsider.com.pl/gielda/wiadomosci/zly-znak-dla-kierowcow-ceny-ropy-naftowej-mocno-w-gore-z-dwoch-powodow/32pys6b](https://businessinsider.com.pl/gielda/wiadomosci/zly-znak-dla-kierowcow-ceny-ropy-naftowej-mocno-w-gore-z-dwoch-powodow/32pys6b)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 07:30:48+00:00

Cena ropy naftowej na światowych giełdach podskoczyła w ciągu ostatnich 24 godzin o blisko 3,5 proc. To największy dzienny wzrost notowań od sześciu tygodni. Eksperci wskazują dwa kluczowe powody.

## Odnosisz sukcesy, ale nie jesteś szczęśliwy? Psycholożka z Harvardu mówi, dlaczego tak jest
 - [https://businessinsider.com.pl/firmy/zarzadzanie/nie-jestes-szczesliwy-mimo-sukcesow-psycholog-wyjasnia-dlaczego-tak-jest/1gcb76b](https://businessinsider.com.pl/firmy/zarzadzanie/nie-jestes-szczesliwy-mimo-sukcesow-psycholog-wyjasnia-dlaczego-tak-jest/1gcb76b)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 07:29:00+00:00

Kupiłeś samochód, masz mieszkanie lub dom na kredyt, dzieci, względnie dobrą pracę i... zastanawiasz się, czemu nie odczuwasz satysfakcji, spełnienia, szczęścia? Zdaniem psycholog Susan David z Harvardu mogłeś paść ofiarą zjawiska powszechnego we współczesnych czasach: zarażenia się zachowaniem bądź postawą innych ludzi.

## Kurs dolara 16 czerwca poniżej 4,1 zł
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-dolara-usdpln-notowania-walut-16-czerwca-2023/nbpn5yh](https://businessinsider.com.pl/gielda/kursy-walut/kurs-dolara-usdpln-notowania-walut-16-czerwca-2023/nbpn5yh)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 07:16:21+00:00

Kurs dolara poniżej 4,1 zł. W piątek rano 16 czerwca 2023 r. rano kurs USD/PLN wynosi 4,06.

## Kurs franka 16 czerwca poniżej 4,6 zł
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-franka-frank-szwajcarski-chfpln-16-czerwca-2023/86cec1q](https://businessinsider.com.pl/gielda/kursy-walut/kurs-franka-frank-szwajcarski-chfpln-16-czerwca-2023/86cec1q)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 07:10:10+00:00

Frank szwajcarski poniżej 4,6 zł. W piątek rano 16 czerwca 2023 r. kurs tej waluty wobec polskiego złotego wynosi 4,56.

## Atakowali serwery na całym świecie. Wpadli w ręce policji
 - [https://businessinsider.com.pl/wiadomosci/atakowali-serwery-na-calym-swiecie-wpadli-w-rece-policji/xzbwhkn](https://businessinsider.com.pl/wiadomosci/atakowali-serwery-na-calym-swiecie-wpadli-w-rece-policji/xzbwhkn)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 07:01:09+00:00

Dwie osoby usłyszały zarzuty za oferowanie nielegalnej usługi polegającej na tzw. atakach DDoS zakłócających pracę systemów informatycznych na całym świecie. Grozi im do 5 lat więzienia – poinformowała Prokuratura Okręgowa w Bydgoszczy.

## "Financial Times" o sprawie frankowiczów: "spektakularnie nietrafiony zakład walutowy"
 - [https://businessinsider.com.pl/gospodarka/financial-times-o-sprawie-frankowiczow-nietrafiony-zaklad-walutowy/vlm0r08](https://businessinsider.com.pl/gospodarka/financial-times-o-sprawie-frankowiczow-nietrafiony-zaklad-walutowy/vlm0r08)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 06:23:05+00:00

"Financial Times" opisał na swoich łamach głośne orzeczenie Trybunału Sprawiedliwości UE dotyczące polskich frankowiczów. "Zawarcie zakładu walutowego we franku szwajcarskim okazało się spektakularnie nietrafione" — napisano.

## Jak zapłacić mniej za wakacje za granicą? Oto cztery triki
 - [https://businessinsider.com.pl/lifestyle/podroze/jak-zaplacic-mniej-za-wakacje-za-granica-oto-piec-trikow/y2bp3wf](https://businessinsider.com.pl/lifestyle/podroze/jak-zaplacic-mniej-za-wakacje-za-granica-oto-piec-trikow/y2bp3wf)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 06:12:00+00:00

Nadchodzi czas planowania wakacyjnych podróży. Wyjazd za granicę kojarzy się często z wydaniem wszystkich oszczędności i debetem na karcie kredytowej. A tak nie musi wcale być! Zwiedzanie świata może być całkiem przystępne cenowo, jeśli wykorzystasz cztery triki na zmniejszenie kosztów podróży.

## Amerykański dyplomata rysuje scenariusz dla Putina. "Niespełnione aspiracje"
 - [https://businessinsider.com.pl/wiadomosci/amerykanski-dyplomata-rysuje-scenariusz-dla-putina-niespelnione-aspiracje/qn4qg8k](https://businessinsider.com.pl/wiadomosci/amerykanski-dyplomata-rysuje-scenariusz-dla-putina-niespelnione-aspiracje/qn4qg8k)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 06:09:59+00:00

Prezydent Rosji Władimir Putin może mieć trudności z utrzymaniem władzy, jeśli wojna na Ukrainie zmusi Moskwę do porzucenia agresji militarnej i zaakceptowania porozumienia pokojowego z Europą — stwierdził były sekretarz stanu USA Henry Kissinger w wywiadzie dla Bloomberga.

## Amerykański dyplomata rysuje scenariusz dla Putina. "Niespełnione aspiracje"
 - [https://businessinsider.com.pl/wiadomosci/amerykanski-dyplomata-rysuje-scenariusz-dla-putina-mowimy-o-niespelnieniu/qn4qg8k](https://businessinsider.com.pl/wiadomosci/amerykanski-dyplomata-rysuje-scenariusz-dla-putina-mowimy-o-niespelnieniu/qn4qg8k)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 06:09:59+00:00

Prezydent Rosji Władimir Putin może mieć trudności z utrzymaniem władzy, jeśli wojna na Ukrainie zmusi Moskwę do porzucenia agresji militarnej i zaakceptowania porozumienia pokojowego z Europą — stwierdził były sekretarz stanu USA Henry Kissinger w wywiadzie dla Bloomberga.

## InPost rozszerza działalność. Otworzy publicznie dostępne stacje ładowania
 - [https://businessinsider.com.pl/biznes/inpost-rozszerza-dzialalnosc-otworzy-publicznie-dostepne-stacje-ladowania/kr64w7y](https://businessinsider.com.pl/biznes/inpost-rozszerza-dzialalnosc-otworzy-publicznie-dostepne-stacje-ladowania/kr64w7y)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 05:29:55+00:00

Właściciel paczkomatów InPost i GreenWay do końca tego roku zbudują sieć kilkudziesięciu publicznie dostępnych punktów ładowania aut elektrycznych. InPost ma już ponad 200 ładowarek dostępnych dla swoich kierowców w centrach logistycznych i w pobliżu paczkomatów.

## Elon Musk zaapelował do Włochów: miejcie dzieci
 - [https://businessinsider.com.pl/gospodarka/elon-musk-zaapelowal-do-wlochow-miejcie-dzieci/txlk35z](https://businessinsider.com.pl/gospodarka/elon-musk-zaapelowal-do-wlochow-miejcie-dzieci/txlk35z)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 05:03:00+00:00

Elon Musk, właściciel Twittera, Tesli i SpaceX, spotkał się w Rzymie z premierką Włoch Giorgią Meloni – podała włoska agencja informacyjna ANSA. Podczas czwartkowego, wieczornego wywiadu w głównym wydaniu serwisu informacyjnego Tg1 zaapelował do Włochów: "Miejcie dzieci!".

## Wiceminister finansów zapowiada wzrost zadłużenia w tym roku aż o 300 miliardów złotych
 - [https://businessinsider.com.pl/gospodarka/wiceminister-finansow-zapowiada-wzrost-zadluzenia-w-tym-roku-az-o-300-mld-zl/lff5n39](https://businessinsider.com.pl/gospodarka/wiceminister-finansow-zapowiada-wzrost-zadluzenia-w-tym-roku-az-o-300-mld-zl/lff5n39)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 05:01:59+00:00

Dług publiczny w Polsce ma do końca tego roku rosnąć w piorunującym tempie – wynika ze słów wiceministra finansów. Inflacja za to spada, co potwierdził GUS, chociaż na rynkach finansowych znowu zaczął drożeć gaz ziemny. Stopy procentowe w strefie euro wzrosły i mają dalej rosnąć, zaś TSUE zgodnie z oczekiwaniami wydał kolejne wyroki korzystne dla klientów banków. Oto pięć najciekawszych wydarzeń w gospodarce teraz.

## Wiceminister finansów zapowiada wzrost zadłużenia w tym roku aż o 300 miliardów złotych
 - [https://businessinsider.com.pl/gospodarka/polska-ma-coraz-wiekszy-dlug-wzrost-zadluzenia-w-tym-roku-az-o-300-mld-zl/lff5n39](https://businessinsider.com.pl/gospodarka/polska-ma-coraz-wiekszy-dlug-wzrost-zadluzenia-w-tym-roku-az-o-300-mld-zl/lff5n39)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 05:01:59+00:00

Dług publiczny w Polsce ma do końca tego roku rosnąć w piorunującym tempie – wynika ze słów wiceministra finansów. Inflacja za to spada, co potwierdził GUS, natomiast na rynkach finansowych znowu zaczął drożeć gaz ziemny. Stopy procentowe w strefie euro wzrosły i mają dalej rosnąć, zaś TSUE zgodnie z oczekiwaniami wydał kolejne wyroki korzystne dla klientów banków. Oto pięć najciekawszych wydarzeń w gospodarce teraz.

## Kurs EUR/PLN 2023-6-16.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-eurpln-2023-6-16/zc01lbj](https://businessinsider.com.pl/gielda/kursy-walut/kurs-eurpln-2023-6-16/zc01lbj)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 05:00:01+00:00

Przedstawiamy bieżące notowania kursu waluty EUR oraz zmiany w ujęciu tygodniowym i dzień po dniu na 2023-6-16. Pokazujemy, jak zmienia się kurs euro w stosunku do polskiego złotego. Czy nasza waluta obecnie traci? Wczoraj kurs EUR wynosił: 4.4558 zł. Wszystkiego dowiesz się z poniższego artykułu.

## Firmy w pułapce pracy zdalnej. Uwaga na dyskryminację rodziców
 - [https://businessinsider.com.pl/prawo/praca/kodeks-pracy-2023-czy-odmowa-pracy-zdalnej-dyskryminuje-rodzicow/sr6yy96](https://businessinsider.com.pl/prawo/praca/kodeks-pracy-2023-czy-odmowa-pracy-zdalnej-dyskryminuje-rodzicow/sr6yy96)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 04:50:39+00:00

Dzięki ostatnim zmianom w kodeksie pracy rodzice mogą wnioskować o pracę zdalną na preferencyjnych zasadach. Pracodawcy mają prawo odmawiać, ale obawiają się zarzutów dyskryminacji i konieczności płacenia odszkodowań. Na dodatek nowe przepisy są niejasne i mogą być wykorzystywane np. do utrudniania zwolnień z pracy.

## Firmy w pułapce pracy zdalnej. Uwaga na dyskryminację rodziców
 - [https://businessinsider.com.pl/prawo/praca/czy-odmowa-pracy-zdalnej-dyskryminuje-rodzicow/sr6yy96](https://businessinsider.com.pl/prawo/praca/czy-odmowa-pracy-zdalnej-dyskryminuje-rodzicow/sr6yy96)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 04:50:39+00:00

Dzięki ostatnim zmianom w kodeksie pracy rodzice mogą wnioskować o pracę zdalną na preferencyjnych zasadach. Pracodawcy mają prawo odmawiać, ale obawiają się zarzutów dyskryminacji i konieczności płacenia odszkodowań. Na dodatek nowe przepisy są niejasne i mogą być wykorzystywane np. do utrudniania zwolnień z pracy.

## Prezes ZBP: Droga banków do odzyskania kosztu kapitału nie jest zamknięta
 - [https://businessinsider.com.pl/finanse/banki-zapowiadaja-ze-frankowicze-musza-sie-liczyc-z-nowymi-kontrpozwami/kxh6rmh](https://businessinsider.com.pl/finanse/banki-zapowiadaja-ze-frankowicze-musza-sie-liczyc-z-nowymi-kontrpozwami/kxh6rmh)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 04:49:17+00:00

Tadeusz Białek, prezes Związku Banków Polskich, ocenia skutki negatywnych dla kredytodawców wyroków Trybunału Sprawiedliwości Unii Europejskiej. Jego zdaniem droga banków do odzyskania kosztu kapitału, w przypadku unieważnienia umowy, nie jest zamknięta. — Należy się spodziewać nowych pozwów kierowanych przez banki — mówi szef ZBP, wskazując na konieczność zatrzymania biegu trzyletniego terminu przedawnienia roszczeń banków o zwrot kapitału. Tym razem, zamiast wynagrodzenia za kapitał, mogą zacząć domagać się waloryzacji (np. o wskaźnik inflacji).

## Masz kredyt frankowy? To musisz wiedzieć po wyroku TSUE. Wyjaśniamy pięć ważnych kwestii
 - [https://businessinsider.com.pl/prawo/masz-kredyt-frankowy-to-musisz-wiedziec-po-wyroku-tsue/y3thgpv](https://businessinsider.com.pl/prawo/masz-kredyt-frankowy-to-musisz-wiedziec-po-wyroku-tsue/y3thgpv)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 04:38:33+00:00

Czwartek był ważnym dniem dla osób mających kredyty we frankach. TSUE ogłosił dwa wyroki. W kluczowym dla osób rozważających pójście do sądu stwierdził, że bank po unieważnieniu umowy nie może ich pozwać o dodatkowe wynagrodzenie. W drugim zalecił polskim sądom dokładną analizę wniosków o zawieszenie rat. Eksperci analizują szczegółowo oba wyroki i pokazują, jak zadziałają w praktyce.

## Rząd bez pozytywnej opinii w sprawie budżetu. Jest komentarz Ministerstwa Finansów
 - [https://businessinsider.com.pl/gospodarka/rzad-bez-pozytywnej-opinii-w-sprawie-budzetu-jest-komentarz-ministerstwa-finansow/0d77k5t](https://businessinsider.com.pl/gospodarka/rzad-bez-pozytywnej-opinii-w-sprawie-budzetu-jest-komentarz-ministerstwa-finansow/0d77k5t)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 04:37:28+00:00

Uwagi NIK są ogólnymi uwagami co do zachowania konwencjonalnych, podręcznikowych zasad finansów publicznych, a nie do nieprawidłowej realizacji ustawy budżetowej — poinformowało Ministerstwo Finansów. Jednocześnie MF wskazuje, że NIK w swojej analizie abstrahuje od warunków, w jakich funkcjonowała polska gospodarka w ostatnich latach. To reakcja na brak pozytywnej opinii Izby z wykonania budżetu za miniony rok.

## Prezes największej frankowej kancelarii: banki nie złożą broni
 - [https://businessinsider.com.pl/finanse/prezes-najwiekszej-frankowej-kancelarii-banki-nie-zloza-broni/tp60byk](https://businessinsider.com.pl/finanse/prezes-najwiekszej-frankowej-kancelarii-banki-nie-zloza-broni/tp60byk)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 04:30:28+00:00

Szef największej kancelarii frankowej w Polsce ocenia konsekwencje wyroków Trybunału Sprawiedliwości Unii Europejskiej. Bartłomiej Krupa w rozmowie z Business Insiderem mówi, że spodziewa się zwiększenia świadomości frankowiczów, także tych, którzy już spłacili kredyt. Nie wyklucza, że banki nadal będą walczyć o jakąś formę opłaty za korzystanie z kapitału, na przykład o jego waloryzację.

## Wcześniejsze emerytury i ochrona kobiet w ciąży. Pięć ważnych zmian, które może dziś przyjąć Sejm
 - [https://businessinsider.com.pl/prawo/wczesniejsze-emerytury-i-wyzsza-placa-minimalna-co-jeszcze-przeglosuje-sejm/3x0m876](https://businessinsider.com.pl/prawo/wczesniejsze-emerytury-i-wyzsza-placa-minimalna-co-jeszcze-przeglosuje-sejm/3x0m876)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 04:06:00+00:00

Posłowie mają w piątek przyjąć przepisy istotne m.in. dla nauczycieli, kobiet w ciąży, rodziców małych dzieci, osób zarabiających najniższe pensje i pracujących w szczególnych warunkach. Politycznie uwaga będzie skupiona na korekcie lex Tusk.

## Bomba wybuchła. Krótka historia kredytów frankowych w Polsce [OPINIA]
 - [https://businessinsider.com.pl/finanse/banki-same-zbudowaly-i-zdetonowaly-bombe-krotka-historia-kredytow-frankowych/e331lc3](https://businessinsider.com.pl/finanse/banki-same-zbudowaly-i-zdetonowaly-bombe-krotka-historia-kredytow-frankowych/e331lc3)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-16 04:00:00+00:00

Przez wiele lat nadzór bankowy ostrzegał przed kredytami walutowymi. Nawet banki chciały, żeby zakazać ich oferowania. Jednak pod presją polityków frankowe hipoteki stały się w pewnym momencie podstawową formą finansowania zakupu mieszkań. Kiedy zaczęły się problemy z kursem szwajcarskiej waluty, pojawiły się pomysły, jak rozbroić frankową bombę, która tykała coraz głośniej. Banki jednak skutecznie je blokowały i żyły nadzieją, że do wybuchu nigdy nie dojdzie. Ten właśnie nastąpił.

