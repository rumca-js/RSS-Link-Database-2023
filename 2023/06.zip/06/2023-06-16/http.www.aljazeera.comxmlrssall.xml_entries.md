# Source:Aljazeera, URL:http://www.aljazeera.com/xml/rss/all.xml, language:en-US

## Alleged body part theft by Harvard morgue manager spurs lawsuit
 - [https://www.aljazeera.com/news/2023/6/16/alleged-body-part-theft-by-harvard-morgue-manager-spurs-lawsuit](https://www.aljazeera.com/news/2023/6/16/alleged-body-part-theft-by-harvard-morgue-manager-spurs-lawsuit)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 22:46:58+00:00

The manager allegedly sold body parts on the black market, prompting a lawsuit for negligence and emotional distress.

## Report alleges ‘coup’ documents found on Bolsonaro aide’s phone
 - [https://www.aljazeera.com/news/2023/6/16/report-alleges-coup-documents-found-on-bolsonaro-aides-phone](https://www.aljazeera.com/news/2023/6/16/report-alleges-coup-documents-found-on-bolsonaro-aides-phone)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 22:38:32+00:00

Bolsonaro aide Mauro Cid is accused of having &#039;gathered documents&#039; to support a coup against Brazil&#039;s President Lula.

## US energy dept got two ransom requests in data breach
 - [https://www.aljazeera.com/economy/2023/6/16/us-energy-dept-got-two-ransom-requests-in-data-breach](https://www.aljazeera.com/economy/2023/6/16/us-energy-dept-got-two-ransom-requests-in-data-breach)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 22:05:19+00:00

DoE, which manages US nuclear weapons and nuclear waste sites related to the military, notified Congress of the breach.

## US restricts Ugandan officials travel in wake of anti-LGBTQ law
 - [https://www.aljazeera.com/news/2023/6/16/us-restricts-ugandan-officials-travel-in-wake-of-anti-lgbtq-law](https://www.aljazeera.com/news/2023/6/16/us-restricts-ugandan-officials-travel-in-wake-of-anti-lgbtq-law)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 20:17:18+00:00

US President Biden had previously said said cuts and sanctions were possible in response to the law.

## Will Germany’s security strategy work?
 - [https://www.aljazeera.com/program/inside-story/2023/6/16/will-germanys-security-strategy-work](https://www.aljazeera.com/program/inside-story/2023/6/16/will-germanys-security-strategy-work)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 20:01:36+00:00

Germany unveils its first national security strategy as it juggles relations with China.

## Daniel Ellsberg,  Pentagon Papers whistleblower dies at 92
 - [https://www.aljazeera.com/news/2023/6/16/daniel-ellsberg-pentagon-papers-whistleblower-dies-at-92](https://www.aljazeera.com/news/2023/6/16/daniel-ellsberg-pentagon-papers-whistleblower-dies-at-92)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 19:46:20+00:00

Ellsberg was famous for exposing government deception on the US war in Vietnam and advocated for whistleblower rights.

## Mali asks UN to withdraw its peacekeeping mission ‘without delay’
 - [https://www.aljazeera.com/news/2023/6/16/mali-asks-un-to-withdraw-its-peacekeeping-mission-without-delay](https://www.aljazeera.com/news/2023/6/16/mali-asks-un-to-withdraw-its-peacekeeping-mission-without-delay)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 19:32:27+00:00

The West African nation&#039;s military rulers criticised MINUSMA&#039;s &#039;failure&#039; to respond to security challenges.

## Russia announces opening of consular offices in West Jerusalem
 - [https://www.aljazeera.com/news/2023/6/16/russia-announces-opening-of-consular-section-offices-in-jerusalem](https://www.aljazeera.com/news/2023/6/16/russia-announces-opening-of-consular-section-offices-in-jerusalem)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 18:02:54+00:00

Israel welcomes decision calling the move a diplomatic achievement.

## Man found guilty in Pittsburgh synagogue attack that killed 11
 - [https://www.aljazeera.com/news/2023/6/16/man-found-guilty-in-pittsburgh-synagogue-attack-that-killed-11](https://www.aljazeera.com/news/2023/6/16/man-found-guilty-in-pittsburgh-synagogue-attack-that-killed-11)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 17:49:29+00:00

A jury convicted Robert Bowers of all 63 counts related to a 2018 massacre, the deadliest attack on Jews in US history.

## What did Putin say at Russia’s flagship economic forum?
 - [https://www.aljazeera.com/news/2023/6/16/st-petersburg-forum-what-did-russian-president-putin-say](https://www.aljazeera.com/news/2023/6/16/st-petersburg-forum-what-did-russian-president-putin-say)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 17:40:36+00:00

Russian president touted resilient economy despite sanctions, said Ukraine&#039;s forces stood &#039;no chance&#039; of winning war.

## Search for loved ones, truth in Greece after migrant boat tragedy
 - [https://www.aljazeera.com/features/2023/6/16/search-for-loved-ones-truth-in-greece-after-migrant-boat-tragedy](https://www.aljazeera.com/features/2023/6/16/search-for-loved-ones-truth-in-greece-after-migrant-boat-tragedy)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 17:20:17+00:00

Hundreds of people are missing after a refugee-filled vessel capsizes off Greece&#039;s west coast, killing dozens.

## Chinese President Xi meets Bill Gates, calls him ‘an old friend’
 - [https://www.aljazeera.com/economy/2023/6/16/chinese-president-xi-meets-bill-gates-calls-him-an-old-friend](https://www.aljazeera.com/economy/2023/6/16/chinese-president-xi-meets-bill-gates-calls-him-an-old-friend)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 16:46:32+00:00

Xi stressed US-China cooperation in meeting with Gates saying common development should be the aim, not hegemony.

## Suspect in Nottingham attack charged with three counts of murder
 - [https://www.aljazeera.com/news/2023/6/16/uk-police-charge-man-with-three-counts-of-murder-after-nottingham](https://www.aljazeera.com/news/2023/6/16/uk-police-charge-man-with-three-counts-of-murder-after-nottingham)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 16:30:26+00:00

Police said Valdo Calocane, 31, is also accused of three counts of attempted murder after a stabbing and van attack.

## US DOJ :’systemic’ police problems led to murder of George Floyd
 - [https://www.aljazeera.com/news/2023/6/16/us-doj-systemic-police-problems-led-to-murder-of-george-floyd](https://www.aljazeera.com/news/2023/6/16/us-doj-systemic-police-problems-led-to-murder-of-george-floyd)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 16:11:28+00:00

Report details abuses that targeted Black residents long before the May 2020 murder of Floyd captured world&#039;s attention.

## The real problem with Israel’s ‘collective punishment’
 - [https://www.aljazeera.com/opinions/2023/6/16/the-real-problem-with-israels-collective](https://www.aljazeera.com/opinions/2023/6/16/the-real-problem-with-israels-collective)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 16:08:44+00:00

The use of the term, while well-intended, ends up suggesting that it&#039;s only the &#039;collective&#039; bit that&#039;s the problem.

## Canada’s top court upholds STCA that sends asylum seekers to US
 - [https://www.aljazeera.com/news/2023/6/16/canada-top-court-upholds-scta-that-sends-asylum-seekers-to-us](https://www.aljazeera.com/news/2023/6/16/canada-top-court-upholds-scta-that-sends-asylum-seekers-to-us)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 15:45:47+00:00

The Safe Third Country Agreement allows Canada to turn back most asylum seekers who come from the US.

## Serbian court orders investigation of 3 jailed Kosovo policemen
 - [https://www.aljazeera.com/news/2023/6/16/serbias-court-orders-detention-probe-of-three-kosovo-policemen](https://www.aljazeera.com/news/2023/6/16/serbias-court-orders-detention-probe-of-three-kosovo-policemen)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 15:27:04+00:00

Serbian Public Prosecutor&#039;s Office orders continued detention of policemen arrested this week in disputed circumstances.

## In Russia, UAE leader calls for dialogue to end Ukraine war
 - [https://www.aljazeera.com/news/2023/6/16/in-russia-uae-leader-calls-for-dialogue-to-end-ukraine-war](https://www.aljazeera.com/news/2023/6/16/in-russia-uae-leader-calls-for-dialogue-to-end-ukraine-war)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 14:22:12+00:00

As Putin is isolated by much of the world, Mohammed bin Zayed Al Nahyan meets the Russian president and lauds ties.

## Mali divided before referendum vote to pave way for elections
 - [https://www.aljazeera.com/news/2023/6/16/mali-divided-before-referendum-vote-to-pave-way-for-elections](https://www.aljazeera.com/news/2023/6/16/mali-divided-before-referendum-vote-to-pave-way-for-elections)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 13:43:31+00:00

The June 18 referendum could pave the way for presidential elections to hold in Mali in February 2024.

## Iran’s Raisi secures array of agreements on Latin American tour
 - [https://www.aljazeera.com/news/2023/6/16/iran-president-secures-array-of-agreements-on-latin-american-tour](https://www.aljazeera.com/news/2023/6/16/iran-president-secures-array-of-agreements-on-latin-american-tour)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 13:09:38+00:00

Ebrahim Raisi visits Venezuela, Nicaragua and Cuba, Tehran&#039;s three allies in the region, on five-day trip.

## As Sudan war rages, rival sides accused of looting, diverting aid
 - [https://www.aljazeera.com/news/2023/6/16/as-sudan-war-rages-rival-sides-accused-of-looting-diverting-aid](https://www.aljazeera.com/news/2023/6/16/as-sudan-war-rages-rival-sides-accused-of-looting-diverting-aid)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 13:05:44+00:00

Aid workers, medics and experts say army and RSF both steal aid, restrict access and impose rent-seeking impediments.

## Rights, press bodies slam Pakistan crackdown on ‘critical voices’
 - [https://www.aljazeera.com/news/2023/6/16/rights-press-bodies-slam-pakistan-crackdown-on-critical-voices](https://www.aljazeera.com/news/2023/6/16/rights-press-bodies-slam-pakistan-crackdown-on-critical-voices)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 12:43:19+00:00

At least seven journalists and political commentators charged with sedition and other offences in the past week.

## Fears of environmental disaster mount after Ukraine dam break
 - [https://www.aljazeera.com/news/2023/6/16/fears-of-environmental-disaster-mount-after-ukraine-dam-blast](https://www.aljazeera.com/news/2023/6/16/fears-of-environmental-disaster-mount-after-ukraine-dam-blast)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 12:33:07+00:00

An estimated 700,000 people are in need of clean water around the Nova Kakhovka dam as Kyiv speaks of ‘ecocide’.

## Swiss cyclist dies after fall into ravine during Tour de Suisse
 - [https://www.aljazeera.com/news/2023/6/16/swiss-cyclist-dies-after-fall-into-ravine-during-tour-de-suisse](https://www.aljazeera.com/news/2023/6/16/swiss-cyclist-dies-after-fall-into-ravine-during-tour-de-suisse)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 12:23:57+00:00

Gino Mäder, 26, dies from injuries a day after crashing and falling down a ravine during the Tour de Suisse race.

## India court bars airing of Al Jazeera documentary
 - [https://www.aljazeera.com/news/2023/6/16/india-court-bars-airing-of-al-jazeera-documentary](https://www.aljazeera.com/news/2023/6/16/india-court-bars-airing-of-al-jazeera-documentary)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 11:38:41+00:00

Media network&#039;s film, India ... Who Lit the Fuse?, investigates hate crimes by Hindu nationalist groups against Muslims.

## ‘She clung to the children’: Nigeria boat tragedy survivors mourn
 - [https://www.aljazeera.com/news/2023/6/16/she-clung-to-the-children-nigeria-boat-tragedy-survivors-mourn](https://www.aljazeera.com/news/2023/6/16/she-clung-to-the-children-nigeria-boat-tragedy-survivors-mourn)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 10:42:44+00:00

Survivors and relatives are mourning the deaths of 106 people in a boat tragedy on June 12 after a large wedding party.

## Timeline: How the migrant boat tragedy unfolded off Greece
 - [https://www.aljazeera.com/news/2023/6/16/timeline-how-the-refugee-boat-tragedy-unfolded-off-greece](https://www.aljazeera.com/news/2023/6/16/timeline-how-the-refugee-boat-tragedy-unfolded-off-greece)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 10:37:04+00:00

Greek authorities say they were notified of the boat&#039;s presence but those onboard repeatedly refused offers for help.

## UK ex-police watchdog chief charged with raping teenage girl
 - [https://www.aljazeera.com/news/2023/6/16/uk-charges-ex-police-watchdog-chief-with-raping-teenage-girl](https://www.aljazeera.com/news/2023/6/16/uk-charges-ex-police-watchdog-chief-with-raping-teenage-girl)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 10:35:09+00:00

Michael Lockwood&#039;s charges include six counts of indecent assault and three offences of rape against a girl.

## Explosions hit Kyiv as African leaders begin ‘peace mission’
 - [https://www.aljazeera.com/news/2023/6/16/south-africas-ramaphosa-arrives-in-ukraine-on-african-peace-mission](https://www.aljazeera.com/news/2023/6/16/south-africas-ramaphosa-arrives-in-ukraine-on-african-peace-mission)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 10:17:24+00:00

The leaders also plan to visit Russia, as a diplomatic standoff brews between South African officials and Poland.

## India minister’s house set ablaze in ethnic violence-hit Manipur
 - [https://www.aljazeera.com/news/2023/6/16/india-ministers-house-set-ablaze-in-ethnic-violence-hit-manipur](https://www.aljazeera.com/news/2023/6/16/india-ministers-house-set-ablaze-in-ethnic-violence-hit-manipur)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 09:43:50+00:00

Junior Foreign Minister R K Ranjan Singh&#039;s office confirms a mob vandalised and set fire to his house in capital Imphal.

## Protesters in Lebanon vandalise banks, demand their money back
 - [https://www.aljazeera.com/news/2023/6/16/protesters-in-lebanon-vandalise-banks-demand-their-money-back](https://www.aljazeera.com/news/2023/6/16/protesters-in-lebanon-vandalise-banks-demand-their-money-back)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 09:15:35+00:00

People demand the return of their savings and call for officials involved in corruption to be held accountable.

## Virgin Galactic plans first commercial space flight this month
 - [https://www.aljazeera.com/news/2023/6/16/virgin-galactic-commercial-space-flight](https://www.aljazeera.com/news/2023/6/16/virgin-galactic-commercial-space-flight)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 08:19:52+00:00

Virgin Galactic has sold about 800 tickets over the past decade, with the initial batch going for $200,000 each.

## Pakistan to host Asia Cup cricket with Sri Lanka to placate India
 - [https://www.aljazeera.com/news/2023/6/16/pakistan-to-host-asia-cup-cricket-with-sri-lanka-to-placate-india](https://www.aljazeera.com/news/2023/6/16/pakistan-to-host-asia-cup-cricket-with-sri-lanka-to-placate-india)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 08:12:36+00:00

The compromise is aimed at forestalling a tit-for-tat boycott by India which is hosting the World Cup later this year.

## India police say five ‘foreign’ fighters killed in Kashmir
 - [https://www.aljazeera.com/news/2023/6/16/india-police-say-five-foreign-fighters-killed-in-kashmir](https://www.aljazeera.com/news/2023/6/16/india-police-say-five-foreign-fighters-killed-in-kashmir)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 07:47:12+00:00

Officials claim the fighters were killed in a gunfight along the de facto border with neighbouring Pakistan.

## Cyclone Biparjoy disrupts power, kills two in India and Pakistan
 - [https://www.aljazeera.com/news/2023/6/16/cyclone-biparjoy-disrupts-power-kills-two-in-india-and-pakistan](https://www.aljazeera.com/news/2023/6/16/cyclone-biparjoy-disrupts-power-kills-two-in-india-and-pakistan)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 07:34:55+00:00

Thousands without power as the severe cyclone makes landfall and heavy rains lash both the Indian and Pakistani coasts.

## Protests across Greece as hope to find shipwreck survivors fades
 - [https://www.aljazeera.com/news/2023/6/16/protests-across-greece-as-hope-to-find-shipwreck-survivors-fades](https://www.aljazeera.com/news/2023/6/16/protests-across-greece-as-hope-to-find-shipwreck-survivors-fades)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 07:34:01+00:00

Greek authorities have been criticised for not acting to rescue hundreds as their boat sank off the coast of Pylos.

## Why is US Secretary of State Antony Blinken going to China?
 - [https://www.aljazeera.com/news/2023/6/16/why-is-us-secretary-of-state-antony-blinken-going-to-china](https://www.aljazeera.com/news/2023/6/16/why-is-us-secretary-of-state-antony-blinken-going-to-china)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 07:14:36+00:00

Expectations are modest for Beijing and Washington in attempt to improve relations after a particularly bumpy year.

## FIFA chief wants refs to stop football games when racism occurs
 - [https://www.aljazeera.com/sports/2023/6/16/fifa-chief-wants-refs-to-stop-football-games-when-racism-occurs](https://www.aljazeera.com/sports/2023/6/16/fifa-chief-wants-refs-to-stop-football-games-when-racism-occurs)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 06:51:28+00:00

FIFA chief Gianni Infantino says &#039;zero tolerance&#039; approach must be taken when racism happens in matches at all levels.

## Three dead, dozens hurt as tornado devastates Texas town in US
 - [https://www.aljazeera.com/news/2023/6/16/three-dead-dozens-hurt-as-tornado-devastates-texas-town-in-us](https://www.aljazeera.com/news/2023/6/16/three-dead-dozens-hurt-as-tornado-devastates-texas-town-in-us)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 05:01:42+00:00

The tornado moved through a mobile home park, mangling trailers and uprooting trees, according to a witness.

## World breaks average temperature record for June: EU
 - [https://www.aljazeera.com/news/2023/6/16/world-breaks-average-temperature-record-for-june-eu](https://www.aljazeera.com/news/2023/6/16/world-breaks-average-temperature-record-for-june-eu)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 04:26:56+00:00

EU Copernicus Climate Change Service says start of June saw global surface air temper break heat records for the period.

## Why do US sanctions fail? Because a platypus isn’t a bird
 - [https://www.aljazeera.com/opinions/2023/6/16/why-do-us-sanctions-fail-because-a-platypus-isnt-a-bird](https://www.aljazeera.com/opinions/2023/6/16/why-do-us-sanctions-fail-because-a-platypus-isnt-a-bird)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 04:14:57+00:00

Sanctions mostly cause humanitarian crises, not democratisation. The answer lies in biology.

## US military chief says Ukraine offensive a ‘very difficult fight’
 - [https://www.aljazeera.com/news/2023/6/16/us-military-chief-says-ukraine-offensive-a-very-difficult-fight](https://www.aljazeera.com/news/2023/6/16/us-military-chief-says-ukraine-offensive-a-very-difficult-fight)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 03:19:55+00:00

US General Mark Milley says Ukraine making &#039;steady progress&#039; in counteroffensive that is &#039;very violent&#039; and costly.

## Seoul salvages part of rocket from North Korea’s failed launch
 - [https://www.aljazeera.com/news/2023/6/16/seoul-salvages-part-of-rocket-from-north-koreas-failed-launch](https://www.aljazeera.com/news/2023/6/16/seoul-salvages-part-of-rocket-from-north-koreas-failed-launch)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 02:33:28+00:00

Pyongyang attempted to send its first military spy satellite into orbit last month, but the rocket crashed into the sea.

## Mixed martial arts fighter Conor McGregor in sexual assault claim
 - [https://www.aljazeera.com/news/2023/6/16/mixed-martial-arts-fighter-conor-mcgregor-in-sexual-assault-claim](https://www.aljazeera.com/news/2023/6/16/mixed-martial-arts-fighter-conor-mcgregor-in-sexual-assault-claim)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 02:02:00+00:00

The former UFC star is alleged to have assaulted a woman in a toilet at an NBA final, the woman&#039;s lawyer says.

## At least 15 killed, 10 injured in bus crash in Canada’s Manitoba
 - [https://www.aljazeera.com/news/2023/6/16/at-least-15-killed-10-injured-in-bus-crash-in-canadas-manitoba](https://www.aljazeera.com/news/2023/6/16/at-least-15-killed-10-injured-in-bus-crash-in-canadas-manitoba)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 01:32:52+00:00

The accident happened when a small bus and truck collided at a highway junction and the bus caught fire.

## Russia-Ukraine war: List of key events, day 478
 - [https://www.aljazeera.com/news/2023/6/16/russia-ukraine-war-list-of-key-events-day-478](https://www.aljazeera.com/news/2023/6/16/russia-ukraine-war-list-of-key-events-day-478)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 01:26:30+00:00

As the war enters its 478th day, these are the main developments.

## Torture used by Russian forces in Ukraine may be state policy: UN
 - [https://www.aljazeera.com/news/2023/6/16/torture-used-by-russian-forces-in-ukraine-may-be-state-policy-un](https://www.aljazeera.com/news/2023/6/16/torture-used-by-russian-forces-in-ukraine-may-be-state-policy-un)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 01:18:08+00:00

UN Special Rapporteur on Torture Alice Jill Edwards said widespread use of torture by Russian forces appears deliberate.

## Nine women file Nevada sexual assault lawsuit against Bill Cosby
 - [https://www.aljazeera.com/news/2023/6/16/nine-women-file-nevada-sexual-assault-lawsuit-against-bill-cosby](https://www.aljazeera.com/news/2023/6/16/nine-women-file-nevada-sexual-assault-lawsuit-against-bill-cosby)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-16 00:07:45+00:00

Complaint was filed after Nevada passed a law lifting the statute of limitations for civil cases about sexual assault.

