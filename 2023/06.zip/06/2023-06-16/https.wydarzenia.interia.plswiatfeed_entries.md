# Source:Wydarzenia Interia - Świat, URL:https://wydarzenia.interia.pl/swiat/feed, language:pl-PL

## Włochy: Zakaz w nadmorskiej miejscowości. Kara może sięgać nawet 150 euro
 - [https://wydarzenia.interia.pl/zagranica/news-wlochy-zakaz-w-nadmorskiej-miejscowosci-kara-moze-siegac-naw,nId,6845851](https://wydarzenia.interia.pl/zagranica/news-wlochy-zakaz-w-nadmorskiej-miejscowosci-kara-moze-siegac-naw,nId,6845851)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-06-16 20:41:33+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wlochy-zakaz-w-nadmorskiej-miejscowosci-kara-moze-siegac-naw,nId,6845851"><img align="left" alt="Włochy: Zakaz w nadmorskiej miejscowości. Kara może sięgać nawet 150 euro" src="https://i.iplsc.com/wlochy-zakaz-w-nadmorskiej-miejscowosci-kara-moze-siegac-naw/000HAFS8CYUB3H8L-C321.jpg" /></a>Władze Gallipoli w Apulii na południu Włoch wprowadziły zakaz chodzenia po jej centrum z gołym torsem i w kostiumach kąpielowych. Burmistrz popularnej nadmorskiej miejscowości wakacyjnej zaznaczył, że celem dekretu jest przywrócenie porządku i dobrych manier. Kara za złamanie zakazu będzie sięgać nawet do 150 euro.</p><br clear="all" />

## Trzęsienie ziemi we Francji
 - [https://wydarzenia.interia.pl/zagranica/news-trzesienie-ziemi-we-francji,nId,6845773](https://wydarzenia.interia.pl/zagranica/news-trzesienie-ziemi-we-francji,nId,6845773)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-06-16 17:13:16+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-trzesienie-ziemi-we-francji,nId,6845773"><img align="left" alt="Trzęsienie ziemi we Francji" src="https://i.iplsc.com/trzesienie-ziemi-we-francji/000FZ899M2IC99HN-C321.jpg" /></a>Francję nawiedziło trzęsienie ziemi o magnitudzie 4.9 - donosi EMSC.</p><br clear="all" />

## Chciał okraść sklep. Pokonały go metalowe rolety
 - [https://wydarzenia.interia.pl/zagranica/news-chcial-okrasc-sklep-pokonaly-go-metalowe-rolety,nId,6845556](https://wydarzenia.interia.pl/zagranica/news-chcial-okrasc-sklep-pokonaly-go-metalowe-rolety,nId,6845556)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-06-16 15:54:47+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-chcial-okrasc-sklep-pokonaly-go-metalowe-rolety,nId,6845556"><img align="left" alt="Chciał okraść sklep. Pokonały go metalowe rolety" src="https://i.iplsc.com/chcial-okrasc-sklep-pokonaly-go-metalowe-rolety/000HAEFYO6TMNGB9-C321.jpg" /></a>Złodziej za cel obrał sobie jeden ze sklepów w Anglii. Nie wiedział jednak, że jego plan zostanie udaremniony przez sprzedawcę. Kiedy mężczyzna próbował wydostać się z budynku, pracownik zdążył uciec na zewnątrz i zaczął opuszczać metalowe rolety. Mimo prób złodziejowi nie udało się prześlizgnąć na drugą stronę.</p><br clear="all" />

## Media: Joe Biden poparł skrócenie ścieżki Ukrainy do NATO
 - [https://wydarzenia.interia.pl/zagranica/news-media-joe-biden-poparl-skrocenie-sciezki-ukrainy-do-nato,nId,6845547](https://wydarzenia.interia.pl/zagranica/news-media-joe-biden-poparl-skrocenie-sciezki-ukrainy-do-nato,nId,6845547)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-06-16 15:33:45+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-media-joe-biden-poparl-skrocenie-sciezki-ukrainy-do-nato,nId,6845547"><img align="left" alt="Media: Joe Biden poparł skrócenie ścieżki Ukrainy do NATO" src="https://i.iplsc.com/media-joe-biden-poparl-skrocenie-sciezki-ukrainy-do-nato/000HAEIBMCVFG1QO-C321.jpg" /></a>Joe Biden poparł propozycję sekretarza generalnego NATO Jensa Stoltenberga dotyczącą skrócenia ścieżki Ukrainy do NATO - podaje &quot;Washington Post&quot; i portal Politico. Chodzi o rezygnację z wymogu przejścia przez mechanizm Planu Działań na rzecz Członkostwa (MAP, czyli Membership Action Plan - red). Na pominięcie MAP-u zdecydowano się zapraszając do Sojuszu Finlandię i Szwecję. </p><br clear="all" />

## Chińczycy walczą o prąd. Wrogiem jest piekielny upał
 - [https://wydarzenia.interia.pl/zagranica/news-chinczycy-walcza-o-prad-wrogiem-jest-piekielny-upal,nId,6845331](https://wydarzenia.interia.pl/zagranica/news-chinczycy-walcza-o-prad-wrogiem-jest-piekielny-upal,nId,6845331)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-06-16 13:14:32+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-chinczycy-walcza-o-prad-wrogiem-jest-piekielny-upal,nId,6845331"><img align="left" alt="Chińczycy walczą o prąd. Wrogiem jest piekielny upał" src="https://i.iplsc.com/chinczycy-walcza-o-prad-wrogiem-jest-piekielny-upal/000HACQ5DBGEMXVJ-C321.jpg" /></a>Chiny mierzą się z rekordowo wysokimi temperaturami. Nieopodal Pekinu odnotowano już niemal 40°C. To rekordowo ciepły czerwiec. Z powodu fali upałów tamtejsza sieć energetyczna jest tak obciążona, że służby zaczynają trenować na ewentualność masowych awarii. Państwo Środka przygotowuje się na rekordowo wysokie zużycie prądu.</p><br clear="all" />

## Orban jest pewny: Na Zachodzie jest człowiek, który może zakończyć wojnę
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-orban-jest-pewny-na-zachodzie-jest-czlowiek-ktory-moze-zakon,nId,6845387](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-orban-jest-pewny-na-zachodzie-jest-czlowiek-ktory-moze-zakon,nId,6845387)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-06-16 12:54:47+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-orban-jest-pewny-na-zachodzie-jest-czlowiek-ktory-moze-zakon,nId,6845387"><img align="left" alt="Orban jest pewny: Na Zachodzie jest człowiek, który może zakończyć wojnę" src="https://i.iplsc.com/orban-jest-pewny-na-zachodzie-jest-czlowiek-ktory-moze-zakon/000HAD5EAWNM5UWX-C321.jpg" /></a>Donald Trump może doprowadzić do pokoju w Ukrainie, jeśli wygra wybory prezydenckie w USA - stwierdził węgierski premier Viktor Orban. Podkreślił, że jego kraj jest zainteresowany pojawieniem się &quot;orędownika pokoju u steru Stanów Zjednoczonych&quot;.

</p><br clear="all" />

## Zaginęła Anastazja Rubińska. 27-latka pracowała na wyspie Kos w Grecji
 - [https://wydarzenia.interia.pl/zagranica/news-zaginela-anastazja-rubinska-27-latka-pracowala-na-wyspie-kos,nId,6845346](https://wydarzenia.interia.pl/zagranica/news-zaginela-anastazja-rubinska-27-latka-pracowala-na-wyspie-kos,nId,6845346)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-06-16 12:13:34+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zaginela-anastazja-rubinska-27-latka-pracowala-na-wyspie-kos,nId,6845346"><img align="left" alt="Zaginęła Anastazja Rubińska. 27-latka pracowała na wyspie Kos w Grecji" src="https://i.iplsc.com/zaginela-anastazja-rubinska-27-latka-pracowala-na-wyspie-kos/000HACTTVOSYINPM-C321.jpg" /></a>Na greckiej wyspie Kos zaginęła Anastazja Rubińska. 27-latka pochodzi z Wrocławia, a od miesiąca pracowała w jednym z hoteli. Bliscy stracili z nią kontakt w niedzielę. Matka kobiety twierdzi, że jej córkę porwano.</p><br clear="all" />

## Niezwykłe odkrycie archeologów w Bawarii. Ten ośmiokątny miecz ma 3000 lat
 - [https://wydarzenia.interia.pl/zagranica/news-niezwykle-odkrycie-archeologow-w-bawarii-ten-osmiokatny-miec,nId,6845054](https://wydarzenia.interia.pl/zagranica/news-niezwykle-odkrycie-archeologow-w-bawarii-ten-osmiokatny-miec,nId,6845054)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-06-16 10:53:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niezwykle-odkrycie-archeologow-w-bawarii-ten-osmiokatny-miec,nId,6845054"><img align="left" alt="Niezwykłe odkrycie archeologów w Bawarii. Ten ośmiokątny miecz ma 3000 lat" src="https://i.iplsc.com/niezwykle-odkrycie-archeologow-w-bawarii-ten-osmiokatny-miec/000HACP57Y8APPH9-C321.jpg" /></a>Ma około 3000 lat, a mimo to jest w świetnym stanie i wygląda jak z powieści fantasy. W Bawarii dokonano niezwykłego odkrycia z epoki brązu. Mowa o mieczu, który należy do kultury pól popielnicowych. Jak się dowiadujemy, przedmiot mógł pełnić funkcje ceremonialne lub był symbolem wysokiego statusu. Trwają badania czy broń była wykonana lokalnie, czy też została sprowadzona.</p><br clear="all" />

## Boją się dronów z Ukrainy. Nadzwyczajna ostrożność na czas pobytu Putina
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-boja-sie-dronow-z-ukrainy-nadzwyczajna-ostroznosc-na-czas-po,nId,6845010](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-boja-sie-dronow-z-ukrainy-nadzwyczajna-ostroznosc-na-czas-po,nId,6845010)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-06-16 08:58:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-boja-sie-dronow-z-ukrainy-nadzwyczajna-ostroznosc-na-czas-po,nId,6845010"><img align="left" alt="Boją się dronów z Ukrainy. Nadzwyczajna ostrożność na czas pobytu Putina" src="https://i.iplsc.com/boja-sie-dronow-z-ukrainy-nadzwyczajna-ostroznosc-na-czas-po/000HABU2HB3G45GT-C321.jpg" /></a>Rosjanie obawiają się o bezpieczeństwo Władimira Putina. Organizatorzy Międzynarodowego Forum Ekonomicznego w Petersburgu mają wyłączyć mobilny internet, by drony nie atakowały miejsca forum podczas sesji plenarnej. To nie pierwszy raz w ostatnim czasie, kiedy dochodzi do wyłączenia internetu z powodu obaw o bezpieczeństwo rosyjskiego przywódcy. </p><br clear="all" />

## Papież Franciszek opuścił szpital. Poruszał się na wózku inwalidzkim
 - [https://wydarzenia.interia.pl/zagranica/news-papiez-franciszek-opuscil-szpital-poruszal-sie-na-wozku-inwa,nId,6845021](https://wydarzenia.interia.pl/zagranica/news-papiez-franciszek-opuscil-szpital-poruszal-sie-na-wozku-inwa,nId,6845021)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-06-16 08:53:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-papiez-franciszek-opuscil-szpital-poruszal-sie-na-wozku-inwa,nId,6845021"><img align="left" alt="Papież Franciszek opuścił szpital. Poruszał się na wózku inwalidzkim" src="https://i.iplsc.com/papiez-franciszek-opuscil-szpital-poruszal-sie-na-wozku-inwa/000HABTX0BNBM756-C321.jpg" /></a>Papież Franciszek wyszedł ze szpitala po operacji jamy brzusznej i powrócił do Watykanu. Przed kliniką Gemelli czekały na niego tłumy wiernych oraz dziennikarzy. - Czuje się dobrze, lepiej niż wcześniej - skomentował stan hierarchy prof. Sergio Alfieri, który operował papieża.</p><br clear="all" />

## Japonia zmienia "wiek zgody". Był jednym z najniższych na świecie
 - [https://wydarzenia.interia.pl/zagranica/news-japonia-zmienia-wiek-zgody-byl-jednym-z-najnizszych-na-swiec,nId,6844930](https://wydarzenia.interia.pl/zagranica/news-japonia-zmienia-wiek-zgody-byl-jednym-z-najnizszych-na-swiec,nId,6844930)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-06-16 07:19:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-japonia-zmienia-wiek-zgody-byl-jednym-z-najnizszych-na-swiec,nId,6844930"><img align="left" alt="Japonia zmienia &quot;wiek zgody&quot;. Był jednym z najniższych na świecie" src="https://i.iplsc.com/japonia-zmienia-wiek-zgody-byl-jednym-z-najnizszych-na-swiec/000HABBRII56FO4H-C321.jpg" /></a>Wiek legalnego współżycia seksualnego - jeden z najniższych takich progów na świecie - został decyzją japońskiego parlamentu podniesiony z 13 do 16 lat. To element reformy przepisów dotyczących przestępstw seksualnych w tym kraju.</p><br clear="all" />

## Japonia zmienia "wiek zgody". Część przepisów "kontrowersyjna"
 - [https://wydarzenia.interia.pl/zagranica/news-japonia-zmienia-wiek-zgody-czesc-przepisow-kontrowersyjna,nId,6844930](https://wydarzenia.interia.pl/zagranica/news-japonia-zmienia-wiek-zgody-czesc-przepisow-kontrowersyjna,nId,6844930)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-06-16 07:19:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-japonia-zmienia-wiek-zgody-czesc-przepisow-kontrowersyjna,nId,6844930"><img align="left" alt="Japonia zmienia &quot;wiek zgody&quot;. Część przepisów &quot;kontrowersyjna&quot;" src="https://i.iplsc.com/japonia-zmienia-wiek-zgody-czesc-przepisow-kontrowersyjna/000HABBRII56FO4H-C321.jpg" /></a>Wiek legalnego współżycia seksualnego został decyzją japońskiego parlamentu podniesiony z 13 do 16 lat. To element reformy przepisów dotyczących przestępstw seksualnych w tym kraju. Kontrowersje budzi zmiana dotycząca ścigania za gwałt. Według krytyków ich kształt faktycznie obwinia ofiary.</p><br clear="all" />

## Zaskakujący pomysł w sprawie Rosjan. "Powinni być pod specjalnym nadzorem"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zaskakujacy-pomysl-w-sprawie-rosjan-powinni-byc-pod-specjaln,nId,6844908](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zaskakujacy-pomysl-w-sprawie-rosjan-powinni-byc-pod-specjaln,nId,6844908)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-06-16 05:59:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zaskakujacy-pomysl-w-sprawie-rosjan-powinni-byc-pod-specjaln,nId,6844908"><img align="left" alt="Zaskakujący pomysł w sprawie Rosjan. &quot;Powinni być pod specjalnym nadzorem&quot;" src="https://i.iplsc.com/zaskakujacy-pomysl-w-sprawie-rosjan-powinni-byc-pod-specjaln/000HAB7EMQV7BXVI-C321.jpg" /></a>- Wszyscy Rosjanie mieszkający w krajach zachodnich powinni być pod specjalnym nadzorem - powiedział prezydent Czech Petr Pavel. Nawiązał do japońskich obozów strzeżonych przez amerykańskich żołnierzy. Polityk uznał to za koszt prowadzonej przez Kreml wojny na Ukrainie.
</p><br clear="all" />

## "El Pais": Sukcesja. Komu przypadnie gigantyczny majątek Berlusconiego?
 - [https://wydarzenia.interia.pl/raport-media-zagraniczne/news-el-pais-sukcesja-komu-przypadnie-gigantyczny-majatek-berlusc,nId,6840691](https://wydarzenia.interia.pl/raport-media-zagraniczne/news-el-pais-sukcesja-komu-przypadnie-gigantyczny-majatek-berlusc,nId,6840691)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-06-16 05:56:00+00:00

<p><a href="https://wydarzenia.interia.pl/raport-media-zagraniczne/news-el-pais-sukcesja-komu-przypadnie-gigantyczny-majatek-berlusc,nId,6840691"><img align="left" alt="&quot;El Pais&quot;: Sukcesja. Komu przypadnie gigantyczny majątek Berlusconiego?" src="https://i.iplsc.com/el-pais-sukcesja-komu-przypadnie-gigantyczny-majatek-berlusc/000HA6RF6FMUEH7L-C321.jpg" /></a>Rozpoczęła się gra o majątek po Silvio Berlusconim. Były włoski premier pozostawił pięcioro dzieci i ogromne biznesowe imperium warte miliardy euro. Jest kilkoro kandydatów do przejęcia wielkiego spadku. W tym jego ostatnia, młodsza o 53 lata partnerka.</p><br clear="all" />

## "Le Monde": Nowa, rewolucyjna technologia. Niemcy zacierają ręce
 - [https://wydarzenia.interia.pl/raport-media-zagraniczne/news-le-monde-nowa-rewolucyjna-technologia-niemcy-zacieraja-rece,nId,6840520](https://wydarzenia.interia.pl/raport-media-zagraniczne/news-le-monde-nowa-rewolucyjna-technologia-niemcy-zacieraja-rece,nId,6840520)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-06-16 05:54:00+00:00

<p><a href="https://wydarzenia.interia.pl/raport-media-zagraniczne/news-le-monde-nowa-rewolucyjna-technologia-niemcy-zacieraja-rece,nId,6840520"><img align="left" alt="&quot;Le Monde&quot;: Nowa, rewolucyjna technologia. Niemcy zacierają ręce" src="https://i.iplsc.com/le-monde-nowa-rewolucyjna-technologia-niemcy-zacieraja-rece/000HA0CAQSTSFTW0-C321.jpg" /></a>Fuzja jądrowa może być nowym źródłem energii, które będzie receptą na światowy kryzys energetyczny i zarazem klimatyczny. Nad rozwinięciem rewolucyjnej technologii pracuje około 30 firm na całym świecie. O przewagę w tej dziedzinie rywalizują przede wszystkim Stany Zjednoczone i Niemcy. Nasi zachodni sąsiedzi wprawdzie dopiero co wyłączyli ostatnie elektrownie atomowe, ale w fuzji jądrowej widzą szansę na uzyskanie taniego, czystego i bezpiecznego źródła energii. </p><br clear="all" />

## Wypadek minibusa w Kanadzie. Wielu zabitych i rannych
 - [https://wydarzenia.interia.pl/zagranica/news-wypadek-minibusa-w-kanadzie-wielu-zabitych-i-rannych,nId,6844902](https://wydarzenia.interia.pl/zagranica/news-wypadek-minibusa-w-kanadzie-wielu-zabitych-i-rannych,nId,6844902)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-06-16 05:06:20+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wypadek-minibusa-w-kanadzie-wielu-zabitych-i-rannych,nId,6844902"><img align="left" alt="Wypadek minibusa w Kanadzie. Wielu zabitych i rannych" src="https://i.iplsc.com/wypadek-minibusa-w-kanadzie-wielu-zabitych-i-rannych/000HAB5KHGTQ91EX-C321.jpg" /></a>Co najmniej 15 osób zginęło, a 10 zostało rannych w czwartek w zderzeniu ciężarówki z przyczepą z minibusem przewożącym osoby starsze w środkowej Kanadzie. To jeden z najtragiczniejszych wypadków drogowych w historii kraju. Kondolencje rodzinom ofiar złożył premier Justin Trudeau.</p><br clear="all" />

## Niecodzienna sytuacja podczas lotu. Media obiegło nagranie
 - [https://wydarzenia.interia.pl/zagranica/news-niecodzienna-sytuacja-podczas-lotu-media-obieglo-nagranie,nId,6843545](https://wydarzenia.interia.pl/zagranica/news-niecodzienna-sytuacja-podczas-lotu-media-obieglo-nagranie,nId,6843545)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-06-16 04:10:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niecodzienna-sytuacja-podczas-lotu-media-obieglo-nagranie,nId,6843545"><img align="left" alt="Niecodzienna sytuacja podczas lotu. Media obiegło nagranie" src="https://i.iplsc.com/niecodzienna-sytuacja-podczas-lotu-media-obieglo-nagranie/000HAA9DFDJOSYHJ-C321.jpg" /></a>Podczas lotu treningowego nad Ekwadorem doszło do nieszczęśliwego wypadku. W kokpicie samolotu nagle znalazł się ogromny kondor. Pilot zachował zimną krew i mimo niesprzyjających okoliczności, zdołał bezpiecznie wylądować. Media społecznościowe obiegło nagranie z incydentu.</p><br clear="all" />

