# Source:Nerdrotic, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC5T0tXJN5CrMZUEJuz4oovw, language:en-US

## FLASH Review | Disney Fallout | MCU Allegations: Friday Night Tights 254 w Literature Devil, MauLer
 - [https://www.youtube.com/watch?v=2pdy2z6aA7U](https://www.youtube.com/watch?v=2pdy2z6aA7U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC5T0tXJN5CrMZUEJuz4oovw
 - date published: 2023-06-16 19:24:23+00:00

Welcome to Friday Night Tights: a @nerdrotic and @GeeksandGamers production

With special guest: @LiteratureDevil and @MauLerYT 

1/4 Black and Dave Landau's NEW SHOW Coming June 
Normal World Subscribe!  @NormalWorld  

Jeremy's plushie: https://www.makeship.com/products/commander-jeremy-plush
Ryan's plushie: https://www.makeship.com/products/rk-outpost-plush
Comix's plushie: https://www.makeship.com/products/comix-division-plush
Odin's plushie: https://www.makeship.com/products/crusader-plush

For your copy of Joe Frankenstein Part 2: https://www.indiegogo.com/projects/joe-frankenstein-part-2#/

For your copy of ISOM 2 go to Rippaverse Comics: https://rippaverse.com/product/isom-2-campaign/

Become a Nerdrotic Channel Member
www.youtube.com/c/sutrowatchtower/join

Streamlab Donations LINK: https://streamlabs.com/sutrowatchtower/tip

Nerdrotic Merch Store!
https://mixedtees.com/nerdrotic

FNT T-Shirt!
https://mixedtees.com/nerdrotic/friday-night-tights

Join https://www.geeksandgamers.com/

SPONSORS

sponsored by Meta PCs. 
For a discount, click here: https://Metapcs.com/Nerdrotic/ref

Sponsored by Geek Grind Coffee. 
Nerdrotic Blend Coffee from Geek Grind
Use Promo Code "Nerdrotic" for 20% off:
https://geekgrindcoffee.com/products/nerdrotic-all-hail-blend-private-blend

Nerdrotic Coffee Cup from Geek Grind:
https://geekgrindcoffee.com/products/bm15oz-15-oz-black-mug-2?_pos=2&_sid=b6f535164&_ss=r

The Lads: 
Gary from @nerdrotic @NerdroticLive @NerdroticDaily 
Jeremy from @DDayCobra @GeeksandGamers @ParkHoppin @geeksandgamersplay @GeeksandGamersTabletop @geeksandgamersdaily @geeksandgamerslife 
Odin from @OMBReviews @TheOMBReport 
Ryan from @ryankinel-rkoutpost4989 @rkoutpostlive8385 @rkoutpostgaming8112 @rkoutpostshorts8795 @rkoutpostlive8385 
@ComixDivision 
@QTRBlackGarrett from @NormalWorld 
@shadiversity 
@ChrissieMayr 
Az from @HeelvsBabyface @hawttoys @hvbgaming 

The Terry Gilliam of FNT @PierryChan 

Produced by @XrayGirl_ from @pourchoices_ 

Odysee ►https://odysee.com/@Nerdrotic:3
Instagram ► https://www.instagram.com/nerdrotic
Minds ►https://www.minds.com/nerdrotic/
Twitter ► https://www.twitter.com/nerdrotics
Parler ► https://parler.com/profile/Nerdrotic
Facebook Page ► https://www.facebook.com/nerdroticpodcast
Facebook Group ► https://www.facebook.com/groups/nerdrotic/
iTunes ► https://itunes.apple.com/us/podcast/nerdrotic/id1050496253?mt=2
Android ► https://player.fm/series/nerdrotic-podcast Free Player.FM app required
Spotify ► https://open.spotify.com/show/5WRnB608ocvcZApJw
Discord ► https://discord.gg/AvnFVenTkf

#FridayNightTights #FNT #IronAge

