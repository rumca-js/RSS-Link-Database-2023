# Source:Yuri Wong, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg, language:en-US

## Make Basic Synths Sound Great (featuring Korg Minilogue, Yamaha Reface, Shik-Tech N32B & Logic Pro)
 - [https://www.youtube.com/watch?v=w1d-NzomGSw](https://www.youtube.com/watch?v=w1d-NzomGSw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg
 - date published: 2023-06-16 12:00:56+00:00

00:00 Intro
00:42 A Really Simple Concept
01:24 What is Chorus?
01:49 Hardware Effects Units
04:49 Built-in Effects
06:56 Software Plugins
09:27 Summary

Gear used:
Shik-Tech N32B 32-knob Midi Controller
Strymon Bigsky
Strymon Mobius
Korg Minilogue
Yamaha Reface CP
Logic Pro X (ES2, Compressor and Space Designer plugins)

Even if you have a basic synthesizer, you can still make it sound great without having to purchase anything additional. With this simple technique that I use on almost all my productions, you can get your synths to sound rich and polished.

