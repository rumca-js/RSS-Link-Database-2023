# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## LotR "Exploited"?👑 New GREAT HUNT cover!😐 Phantom Liberty Stuns🗽 | FANTASY NEWS
 - [https://www.youtube.com/watch?v=5Jp3WPv5-sw](https://www.youtube.com/watch?v=5Jp3WPv5-sw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2023-06-16 13:00:07+00:00

Let's jump into the fantasy news! 
Check out Fourth Wall today: https://link.fourthwall.com/DanielGreene 
merch: https://www.danielbgreene.com
My books: 
Breach of Peace: https://tinyurl.com/BoPTLT 
Rebels Creed: https://tinyurl.com/RCTLTDG


New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA 
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

P.O. Box: PO Box 7874 Henrico, VA 23231

00:00 intro 

00:30 Great Hunt Cover: https://www.instagram.com/p/CteZuuDLVQo/?igshid=MzRlODBiNWFlZA%3D%3D 

00:59 Ice and Ivy: https://twitter.com/jdevansbooks/status/1668925082582777856 

01:13 Dead Cells Teaser: https://www.youtube.com/watch?v=LMVH49-VUOc 

01:45 Nimona: https://www.youtube.com/watch?v=f_fuHRyQbOc 

02:14 Silo renewed for season 2: https://variety.com/2023/tv/news/silo-renewed-season-2-apple-1235643158/ 

02:54 Cyberpunk Phantom Liberty: youtube.com/watch?v=reABCMNGM3w 

05:01 Richmond Public Library Convention: https://rvalibrary.libcal.com/event/10519087 

05:44 Exploit Lord Of The Rings: https://kotaku.com/embracer-lotr-kotor-remake-tomb-raider-canceled-layoffs-1850533953

