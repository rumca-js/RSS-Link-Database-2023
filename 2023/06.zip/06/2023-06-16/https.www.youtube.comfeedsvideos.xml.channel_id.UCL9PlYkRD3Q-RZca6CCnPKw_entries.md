# Source:Project Veritas, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCL9PlYkRD3Q-RZca6CCnPKw, language:en-US

## FLASHBACK FRIDAY: DocGo was exposed for administering improper COVID vaccines to NYC kids in 2022
 - [https://www.youtube.com/watch?v=r9L13_fZ4YA](https://www.youtube.com/watch?v=r9L13_fZ4YA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCL9PlYkRD3Q-RZca6CCnPKw
 - date published: 2023-06-16 16:48:13+00:00

Donate: https://www.projectveritas.com/donate

Get emails: https://confirmsubscription.com/h/j/EC8A17570A033FCC

Follow:
Telegram: https://t.me/project_veritas
FB: https://www.facebook.com/ProjectVeritas
IG: https://www.instagram.com/project_veritas/

Mission Statement
Investigate & expose corruption, dishonesty, self-dealing, waste, fraud, and other misconduct in both public and private institutions in order to achieve a more ethical & transparent society.

Core Values
MORAL COURAGE - Courage is the virtue that sustains all others. We choose to overcome our fears.

WE ARE ALL LEADERS - Turning people into leaders. Completed staff work. Ownership.

COLLABORATION - Best not to work in silos. No one individual is as smart as all of us.

RESILIENCE - Persistence and determination alone are omnipotent. Never, ever, ever give up. We don't let mistakes or setbacks discourage us. Pursue perfection, knowing full well you will never attain it.

MISSION DRIVEN - The best people are motivated by purpose. We are passionate and truly believe in our cause. We must be externally focused, not internally focused.

MAKE THE STATUS QUO DO THE IMPOSSIBLE - We move mountains. Failure is not an option. We do whatever it takes.

THE TIP OF THE SPEAR - We are a loss leader. We do not shy away from conflict or litigation.

Ethical Values
Rule #1 – Truth is paramount. Our reporting is fact based with clear and irrefutable video and audio content.  Truth is paramount. We never deceive our audience. We do not distort the facts or the context. We do not “selectively edit.”

Rule #2 – We do not break the law. We maintain one-party consent when recording someone is inherently moral and ethical. We never record when there is zero-party consent. In areas where we are required to have consent from all parties, we seek legal guidance regarding the expectation of privacy’s impact on our right to record.

Rule #3 – We adhere to the 1st Amendment rights of others. During our investigations we do not disrupt the peace. We do not infringe on the 1st Amendment rights of others.

Rule #4 – The Zekman Test. The undercover investigations we pursue are judged by us to be of “vital public interest” and “profound importance.” The Zekman Test is our baseline. Undercover investigative reporting is necessary because, “...there’s no other way to get the story...” Whereas the Society of Professional Journalists allows for undercover techniques, if undercover techniques are necessary to expose issues of vital public importance; we believe they are not only allowed but required.

Rule #5 – We Protect the Innocent When Possible - Embarrassing private details are not to be investigated. We stay away from irrelevant embarrassingly intimate details about private citizens personal lives. We look for individual wrong-doing and judge its public importance. The irrelevant religious or sexual dispositions of our targets are not to be investigated.

Rule #6 – Transparency. Our methods & tactics must be reasonable and defensible. We use the “Twelve Jurors on Our Shoulder” rule. The work has to be done with such a degree of integrity that it can withstand scrutiny in both law & ethics. We are comfortable with transparency. We must be willing to be ready to disclose our methods upon publication.

Rule #7 – Verifying and Corroborate Stories – Evaluate impact on third parties and Newsworthiness of Statements Alone.We consistently consider the probable truth or falsity of statements, examine any reasons to doubt the veracity of underlying assertions and whether the assertions are newsworthy. When possible, we will confirm with our subjects that their statements captured on video are accurate & truthful. At the very least, we will give our subjects an opportunity to elaborate and/or respond. In all matters, we rely on the 1st Amendment to protect our ability to publish newsworthy items after our internal deliberations. On whether there is an obligation to ensure the veracity of statements made on video, 1.) consider whether the remarks may potentially impact an innocent third party. (Factors in support of releasing the content) and 2.)The Newsworthiness of the statement alone by itself. (Factors against releasing the content).

Rule #8 – Raw Video. In certain circumstances we may release the “raw” video to the press and or the public.  But as a rule, we do not.

Rule #9 – Subject Anonymity. We investigate & question sources before promising anonymity. Once we confirm, we will do everything in our power to protect the identity of our confidential sources.

Rule #10 – Being Accountable. Admit mistakes & correct them promptly.

Rule #11 – We do not manufacture content. We do not put words in our investigative subjects' mouths. We do not lead the horse to water. Our purpose is to elicit truth.

Rule #12 – With Great Power comes Great Responsibility.

