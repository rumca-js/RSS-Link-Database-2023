# Source:Moon, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCmFeOdJI3IXgTBDzqBLD8qg, language:en-US

## A Clockwork Orange Tried To Warn You
 - [https://www.youtube.com/watch?v=Whl7UjP39rA](https://www.youtube.com/watch?v=Whl7UjP39rA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmFeOdJI3IXgTBDzqBLD8qg
 - date published: 2023-06-16 01:53:01+00:00

Get a 14-day free trial with my sponsor Aura: http://aura.com/moon and see how many times your information has been leaked

Free weekly essays written by Moon - https://mailchi.mp/3ded12821743/moon

Support the channel here (all money goes straight back into the channel):
►  Become a Patron:  https://www.patreon.com/MoonReal
► Follow my Twitter: https://twitter.com/MoonRealYT

This video explores the message of A Clockwork Orange on modernity and government control through Alex's struggle in the Stanley Kubrick movie and book called a clockwork orange.

