# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## CYBERPUNK 2077'S REDEMPTION BET, ROCKSTAR FOUNDER'S NEW STUDIO & MORE
 - [https://www.youtube.com/watch?v=E8KJAGwnptc](https://www.youtube.com/watch?v=E8KJAGwnptc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2023-06-16 17:32:36+00:00

Sponsored by Witchsong Miniatures. Click https://tinyurl.com/witchsongminis to start your $1 monthly subscription and grab your Welcome Pack.

For every new Witchsongs Miniatures subscription, $1 will be donated to Able Gamers. If you wish to learn more about them: https://ablegamers.org.


podcast: https://linktr.ee/friendspersecond



~~~SOURCES~~~

Cyberpunk
https://www.bnnbloomberg.ca/cd-projekt-aims-to-redeem-cyberpunk-2077-with-major-expansion-1.1933068


Nic Cage Hideo Kojima 
https://www.ign.com/articles/nicolas-cage-met-hideo-kojima-and-now-fans-are-convinced-he-will-cameo-in-death-stranding-2

Armored Core 6 gameplay
https://youtu.be/c2UqRb_aK8M

Activision Blizzard Xbox update
https://www.gamespot.com/articles/judge-grants-restraining-order-temporarily-preventing-microsoft-from-buying-activision/1100-6515204/?ftag=CAD-01-10abi2f&amp;utm_source=dlvr.it&amp;utm_medium=twitter&amp;fbclid=IwAR33E58jZbkkEDMV1aMzBf5KzREfuBRTkoAwuL-GvKqMO-c70Vx-yYcMMjo


Squirrel with a gun trailer
https://youtu.be/hRiRyopVm6Q

Layers of Fear
https://youtu.be/e0QBnez-c6A

Final Fantasy 16 demo

Our Xbox new game announcements breakdown: https://youtu.be/bBwlytqppfs

