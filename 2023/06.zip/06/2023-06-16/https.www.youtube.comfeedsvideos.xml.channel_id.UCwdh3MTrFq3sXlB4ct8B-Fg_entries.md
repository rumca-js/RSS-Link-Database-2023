# Source:Warhammer, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg, language:en-US

## Batch Paint Battle Ready Hive Fleet Gorgon Termagants
 - [https://www.youtube.com/watch?v=0D-DqzLOuwg](https://www.youtube.com/watch?v=0D-DqzLOuwg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg
 - date published: 2023-06-16 11:00:00+00:00

No other hive fleet has been documented to possess the swift and insidious adaptability of Hive Fleet Gorgon. Follow this step-by-step guide to batch paint your Termagants and unleash them on the gaming table, ready to devour their prey in no time at all!  
If you're new to painting - check out our Citadel Colour Painting Essentials videos to learn all about it

## Batch Paint: Battle Ready Hive Fleet Behemoth Termagants
 - [https://www.youtube.com/watch?v=MgVr4U4BnFk](https://www.youtube.com/watch?v=MgVr4U4BnFk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg
 - date published: 2023-06-16 09:00:29+00:00

The splinters of Hive Fleet Behemoth scattered from Macragge continue to bedevil Ultramar and the wider Imperium to this day. Follow this step-by-step guide to batch paint your Termagants and unleash them on the gaming table, ready to devour their prey in no time at all! 

If you're new to painting - check out our Citadel Colour Painting Essentials videos to learn all about it

