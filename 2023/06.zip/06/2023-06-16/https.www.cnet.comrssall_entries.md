# Source:CNET, URL:https://www.cnet.com/rss/all/, language:en-US

## Mercedes Teams Up With ChatGPT To Improve How Drivers Talk to Their Cars     - CNET
 - [https://www.cnet.com/roadshow/news/mercedes-teams-up-with-chatgpt-to-improve-how-drivers-talk-to-their-cars/#ftag=CADf328eec](https://www.cnet.com/roadshow/news/mercedes-teams-up-with-chatgpt-to-improve-how-drivers-talk-to-their-cars/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-16 22:16:21+00:00

The three-month beta program will complement the existing Mercedes-Benz voice feature with more natural dialogue and follow-up questions.

## Samsung Galaxy Z Fold 5 and Flip 5 Could Lie Flat When Folded     - CNET
 - [https://www.cnet.com/tech/mobile/samsung-galaxy-z-fold-5-and-flip-5-could-lie-flat-when-folded/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/samsung-galaxy-z-fold-5-and-flip-5-could-lie-flat-when-folded/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-16 22:07:15+00:00

Samsung's next-gen foldable phones will reportedly eliminate the gap between their screens when folded.

## Ticketmaster and Airbnb Help White House Effort to End Hidden Fees     - CNET
 - [https://www.cnet.com/personal-finance/credit-cards/ticketmaster-and-airbnb-help-white-house-effort-to-end-hidden-fees/#ftag=CADf328eec](https://www.cnet.com/personal-finance/credit-cards/ticketmaster-and-airbnb-help-white-house-effort-to-end-hidden-fees/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-16 21:51:05+00:00

Ticketing and travel companies have announced "all-in pricing" in response to President' Biden's crackdown on junk fees.

## Best Internet Providers in Boston     - CNET
 - [https://www.cnet.com/home/internet/best-internet-providers-in-boston-ma/#ftag=CADf328eec](https://www.cnet.com/home/internet/best-internet-providers-in-boston-ma/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-16 21:20:00+00:00

Searching for broadband in Beantown? Here are the best ISPs that serve the Boston area.

## Meta's Voicebox Generative AI Makes Anyone Speak a Foreign Language     - CNET
 - [https://www.cnet.com/tech/computing/metas-voicebox-generative-ai-makes-anyone-speak-a-foreign-language/#ftag=CADf328eec](https://www.cnet.com/tech/computing/metas-voicebox-generative-ai-makes-anyone-speak-a-foreign-language/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-16 21:02:00+00:00

All the AI needs is a 2-second audio clip to generate speech.

## Are Solar Panels Exempt From Property Taxes and Sales Taxes in Your State?     - CNET
 - [https://www.cnet.com/home/energy-and-utilities/are-solar-panels-exempt-from-property-taxes-and-sales-taxes-in-your-state/#ftag=CADf328eec](https://www.cnet.com/home/energy-and-utilities/are-solar-panels-exempt-from-property-taxes-and-sales-taxes-in-your-state/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-16 20:14:00+00:00

Many states provide tax incentives designed to lessen your overall cost of installing solar panels.

## Review of BistroMD Meal Delivery for Weight Loss     - CNET
 - [https://www.cnet.com/health/nutrition/review-of-bistromd-meal-delivery-for-weight-loss/#ftag=CADf328eec](https://www.cnet.com/health/nutrition/review-of-bistromd-meal-delivery-for-weight-loss/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-16 19:41:00+00:00

BistroMD encourages nutritious food and portion control to achieve various health goals such as weight loss and managing diabetes. We put the popular meal delivery service to the test.

## iOS 16.6 Beta 3: What Could Be Coming to Your iPhone Soon     - CNET
 - [https://www.cnet.com/tech/services-and-software/ios-16-6-beta-3-what-could-be-coming-to-your-iphone-soon/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/ios-16-6-beta-3-what-could-be-coming-to-your-iphone-soon/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-16 19:07:57+00:00

Public beta testers and developers can download the update now.

## Malta vs. England Livestream: How to Watch Euro 2024 Qualifier Soccer From Anywhere     - CNET
 - [https://www.cnet.com/tech/services-and-software/malta-vs-england-livestream-how-to-watch-euro-2024-qualifier-soccer-from-anywhere/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/malta-vs-england-livestream-how-to-watch-euro-2024-qualifier-soccer-from-anywhere/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-16 18:50:00+00:00

Harry Kane and co. look to extend their lead at the top of qualifying Group C with a win over the hosts.

## You Won't See AI-Generated Songs Winning Any Grammy Awards     - CNET
 - [https://www.cnet.com/tech/computing/you-wont-see-ai-generated-songs-winning-any-grammy-awards/#ftag=CADf328eec](https://www.cnet.com/tech/computing/you-wont-see-ai-generated-songs-winning-any-grammy-awards/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-16 18:11:00+00:00

New rules state songs without human authorship won't be eligible.

## How Long Do Hearing Aids Last? 5 Signs You Need a New Pair     - CNET
 - [https://www.cnet.com/health/medical/how-long-do-hearing-aids-last-5-signs-you-need-a-new-pair/#ftag=CADf328eec](https://www.cnet.com/health/medical/how-long-do-hearing-aids-last-5-signs-you-need-a-new-pair/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-16 17:15:05+00:00

Like any health device, a pair of hearing aids won't last forever. Here's how to tell when you may need to get a replacement.

## iOS 17: The New iPhone Features I'm Most Excited About     - CNET
 - [https://www.cnet.com/tech/services-and-software/ios-17-the-iphone-features-im-most-excited-about/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/ios-17-the-iphone-features-im-most-excited-about/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-16 17:05:34+00:00

StandBy mode, a new passcode grace period and more are expected to come to your iPhone in the fall.

## Save On Saatva Mattresses With $500 Off Orders of $1,000 or More     - CNET
 - [https://www.cnet.com/deals/save-on-saatva-mattresses-with-500-off-orders-of-1000-or-more/#ftag=CADf328eec](https://www.cnet.com/deals/save-on-saatva-mattresses-with-500-off-orders-of-1000-or-more/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-16 16:31:46+00:00

Upgrade to one of our favorite premium mattresses right now and get better sleep for less.

## College World Series 2023: How to Watch, Stream Today From Anywhere     - CNET
 - [https://www.cnet.com/tech/services-and-software/college-world-series-2023-how-to-watch-stream-today-from-anywhere/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/college-world-series-2023-how-to-watch-stream-today-from-anywhere/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-16 16:30:06+00:00

You can watch all the college baseball action from Omaha, no cable required.

## Tesla Solar Roof: The Sleekest Solar Option Isn't Your Best One     - CNET
 - [https://www.cnet.com/home/energy-and-utilities/tesla-solar-roof-is-the-sleekest-solar-option-your-best-one/#ftag=CADf328eec](https://www.cnet.com/home/energy-and-utilities/tesla-solar-roof-is-the-sleekest-solar-option-your-best-one/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-16 16:13:37+00:00

It's solar you might not notice from the road, but it comes at a cost. You can get less subtle solar panels for much cheaper.

## Tesla Powerwall Review: A Well-Rounded Solar Battery     - CNET
 - [https://www.cnet.com/home/energy-and-utilities/tesla-powerwall-review/#ftag=CADf328eec](https://www.cnet.com/home/energy-and-utilities/tesla-powerwall-review/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-16 16:09:13+00:00

The Tesla Powerwall has a few strengths and no glaring weaknesses. And it comes at a reasonable price for a solar battery.

## Casper Wave Mattress Review: Casper's Plush Luxury Bed video     - CNET
 - [https://www.cnet.com/videos/casper-wave-mattress-review-caspers-plush-luxury-bed/#ftag=CADf328eec](https://www.cnet.com/videos/casper-wave-mattress-review-caspers-plush-luxury-bed/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-16 16:02:33+00:00

Owen Poole, a certified sleep science coach, reviews Casper's high-end bed, the Casper Wave Hybrid mattress. Owen goes in-depth on the construction, firmness and feel of the mattress. At the end, he gives his verdict on what kind of buyer would be interested in the Casper Wave mattress.

## Skip Microsoft's Monthly Fees With a Lifetime Office License for $40     - CNET
 - [https://www.cnet.com/deals/skip-microsofts-monthly-fees-lifetime-office-license/#ftag=CADf328eec](https://www.cnet.com/deals/skip-microsofts-monthly-fees-lifetime-office-license/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-16 15:40:47+00:00

This popular Microsoft Office 2021 lifetime license deal is back on sale at 81% off.

## Jet Dragon Flies Onto Apple Arcade     - CNET
 - [https://www.cnet.com/tech/gaming/jet-dragon-flies-onto-apple-arcade/#ftag=CADf328eec](https://www.cnet.com/tech/gaming/jet-dragon-flies-onto-apple-arcade/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-16 15:16:00+00:00

You race and train dragons. Need I say more?

## iOS 17 Brings Back Old Habits: Screening Calls and Bumping iPhones     - CNET
 - [https://www.cnet.com/tech/mobile/ios-17-brings-back-old-habits-screening-calls-and-bumping-iphones/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/ios-17-brings-back-old-habits-screening-calls-and-bumping-iphones/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-16 15:14:00+00:00

What's old is new again in iOS 17, which brings some of the biggest changes in years to how we use the iPhone.

## iOS 17 Brings Big Changes to Old Habits: Live Voicemail, AirDrop and Siri video     - CNET
 - [https://www.cnet.com/videos/ios-17-brings-big-changes-to-old-habits-live-voicemail-airdrop-and-siri/#ftag=CADf328eec](https://www.cnet.com/videos/ios-17-brings-big-changes-to-old-habits-live-voicemail-airdrop-and-siri/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-16 14:25:56+00:00

The iOS 17 update means big changes to how you will use your iPhone — and it may bring back some old habits. Bridget Carey explains.

## 13 Mistakes to Avoid With Your Contact Lenses     - CNET
 - [https://www.cnet.com/health/personal-care/13-mistakes-to-avoid-with-your-contact-lenses/#ftag=CADf328eec](https://www.cnet.com/health/personal-care/13-mistakes-to-avoid-with-your-contact-lenses/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-16 14:00:03+00:00

Preserve the longevity and safety of your contact lenses by avoiding these common mistakes.

## New Customers Can Take $70 Off a ButcherBox Subscription and Get Free Ground Beef for a Year     - CNET
 - [https://www.cnet.com/deals/new-customers-can-take-70-off-a-butcherbox-subscription-and-get-free-ground-beef-for-a-year/#ftag=CADf328eec](https://www.cnet.com/deals/new-customers-can-take-70-off-a-butcherbox-subscription-and-get-free-ground-beef-for-a-year/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-16 13:35:32+00:00

ButcherBox is celebrating Father's Day with a great deal that will have you ready for grilling season -- and beyond.

## What's the Price of a Complete Amazon Alexa Smart Home? I Did the Math to Find Out     - CNET
 - [https://www.cnet.com/home/smart-home/whats-the-price-of-a-complete-amazon-alexa-smart-home-i-did-the-math-to-find-out/#ftag=CADf328eec](https://www.cnet.com/home/smart-home/whats-the-price-of-a-complete-amazon-alexa-smart-home-i-did-the-math-to-find-out/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-16 13:30:04+00:00

I did the math to determine the cost of three Amazon smart home setups, from just the Alexa essentials to a full deck of Alexa gadgets.

## Haven't Changed Your AC Unit Filter Recently? You Need to Now     - CNET
 - [https://www.cnet.com/home/kitchen-and-household/havent-changed-your-ac-unit-filter-recently-you-need-to-now/#ftag=CADf328eec](https://www.cnet.com/home/kitchen-and-household/havent-changed-your-ac-unit-filter-recently-you-need-to-now/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-16 13:15:03+00:00

Pro tip: It can save you money.

## Don't Panic: Safely Remove Something Stuck in Your Eye With These Tips     - CNET
 - [https://www.cnet.com/health/personal-care/dont-panic-safely-remove-something-stuck-in-your-eye-with-these-tips/#ftag=CADf328eec](https://www.cnet.com/health/personal-care/dont-panic-safely-remove-something-stuck-in-your-eye-with-these-tips/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-16 13:00:13+00:00

We've all had an eyelash stuck in our eye. Typically it's just a minor annoyance, but it can be more serious if you don't get it out properly.

## Mortgage Rates on June 16, 2023: Rates Ease     - CNET
 - [https://www.cnet.com/personal-finance/mortgages/mortgage-rates-on-june-16-2023-rates-ease/#ftag=CADf328eec](https://www.cnet.com/personal-finance/mortgages/mortgage-rates-on-june-16-2023-rates-ease/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-16 13:00:00+00:00

This week, a couple of notable mortgage rates slid lower, though rates remain high compared to a year ago. As interest rates surge, it's getting more expensive to buy a house.

## Mortgage Refinance Rates on June 16, 2023: 30-Year Rate Rises     - CNET
 - [https://www.cnet.com/personal-finance/mortgages/mortgage-refinance-rates-on-june-16-2023-rate-rises/#ftag=CADf328eec](https://www.cnet.com/personal-finance/mortgages/mortgage-refinance-rates-on-june-16-2023-rate-rises/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-16 13:00:00+00:00

Refinance rates were mixed, but one key rate cruised higher this week. The Fed's interest rate hikes have affected the refinance market.

## Save on Refurbished Wyze Cameras, Smart Locks and More     - CNET
 - [https://www.cnet.com/deals/save-on-refurbished-wyze-cameras-smart-locks-and-more/#ftag=CADf328eec](https://www.cnet.com/deals/save-on-refurbished-wyze-cameras-smart-locks-and-more/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-16 12:51:00+00:00

Snag refurbished smart plugs, smart locks, security cameras and vacuums from Wyze for as little as $9.

## Apple Wants to Make the Apple Watch Your 'Key to the World'     - CNET
 - [https://www.cnet.com/tech/mobile/apple-wants-to-make-the-apple-watch-your-key-to-the-world/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/apple-wants-to-make-the-apple-watch-your-key-to-the-world/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-16 12:00:30+00:00

Apple's vice president of technology, Kevin Lynch, speaks with CNET about WatchOS 10 and the company's approach to new Apple Watch features.

## Free EV Charging Could Soon Be a Thing of the Past     - CNET
 - [https://www.cnet.com/roadshow/news/free-ev-charging-could-soon-be-a-thing-of-the-past/#ftag=CADf328eec](https://www.cnet.com/roadshow/news/free-ev-charging-could-soon-be-a-thing-of-the-past/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-16 12:00:26+00:00

More states are taxing public charging stations, even free ones. Critics say that could lead businesses to stop providing them.

## How Solar Loans Work     - CNET
 - [https://www.cnet.com/home/energy-and-utilities/how-solar-loans-work/#ftag=CADf328eec](https://www.cnet.com/home/energy-and-utilities/how-solar-loans-work/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-16 12:00:18+00:00

Solar panel systems can cost tens of thousands of dollars, but you don't have to pay cash. Here's how to get solar-specific financing.

## Hulu Live vs. Sling TV vs. YouTube TV and More: Top Channels Compared     - CNET
 - [https://www.cnet.com/tech/services-and-software/hulu-live-sling-tv-youtube-tv-more-top-100-channels-compared/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/hulu-live-sling-tv-youtube-tv-more-top-100-channels-compared/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-16 11:15:04+00:00

A look at which live TV streaming service offers the best channel lineup.

## Whisker Litter-Robot 4 Review: An Excellent Robotic Litter Box (Once Your Cats Adjust to It)     - CNET
 - [https://www.cnet.com/home/kitchen-and-household/whisker-litter-robot-4-review/#ftag=CADf328eec](https://www.cnet.com/home/kitchen-and-household/whisker-litter-robot-4-review/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-16 11:00:13+00:00

Whisker's Litter-Robot 4 is a well-designed robotic litter box that eliminates the need to scoop anything -- but it might be too much for scaredy-cats.

## 'Outlander' Season 7: Release Date and How to Watch From Anywhere     - CNET
 - [https://www.cnet.com/tech/services-and-software/outlander-season-7-release-date-and-how-to-watch-from-anywhere/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/outlander-season-7-release-date-and-how-to-watch-from-anywhere/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-16 11:00:09+00:00

Claire and Jamie return with the American Revolution in full swing.

## Electric Vehicle Ranges: Here's What to Consider When Shopping     - CNET
 - [https://www.cnet.com/roadshow/news/electric-vehicle-range-shopping-tips/#ftag=CADf328eec](https://www.cnet.com/roadshow/news/electric-vehicle-range-shopping-tips/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-16 09:09:28+00:00

Check these tips to decide how much range you should target when buying an electric car.

## England vs. Australia Livestream: How to Watch 1st Test Ashes Cricket From Anywhere     - CNET
 - [https://www.cnet.com/tech/services-and-software/england-vs-australia-livestream-how-to-watch-1st-test-ashes-cricket-from-anywhere/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/england-vs-australia-livestream-how-to-watch-1st-test-ashes-cricket-from-anywhere/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-16 08:00:04+00:00

Cricket's two biggest rivals kick off this hotly anticipated series at Edgbaston.

## ChatGPT Can Now Help Humans Speak to Trees. But Why?     - CNET
 - [https://www.cnet.com/news/chatgpt-can-now-help-humans-speak-to-trees-but-why/#ftag=CADf328eec](https://www.cnet.com/news/chatgpt-can-now-help-humans-speak-to-trees-but-why/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-16 04:23:52+00:00

Commentary: The ePlant TreeTag gives your Eucalypt an AI voice. I'm not sure it needed one.

## Best Gifts Under $300 for 2023     - CNET
 - [https://www.cnet.com/tech/mobile/best-gifts-under-300-for-2023/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/best-gifts-under-300-for-2023/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-16 04:00:10+00:00

Not on a strict budget this year? Here are some $300 gift ideas (or less!) that are sure to impress.

