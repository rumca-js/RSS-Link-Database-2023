# Source:Marc Brunet, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCKtu_JtQCY0yryIy6zK4ZCg, language:en-US

## Secret shading cheat pros use
 - [https://www.youtube.com/watch?v=p0NYuaJz0nw](https://www.youtube.com/watch?v=p0NYuaJz0nw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKtu_JtQCY0yryIy6zK4ZCg
 - date published: 2023-06-16 00:31:54+00:00

Full video: https://youtu.be/FnryXXvpesU

🎉 Join the ART School for Digital Artists program here http://artschool.ai 

✅ Learn at your own pace
✅ Grow with your peers on the Art School forums
✅ Carefully crafted exercises
✅ Over 100 hours of videos jam-packed with priceless knowledge

