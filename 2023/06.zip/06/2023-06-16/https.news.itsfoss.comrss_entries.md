# Source:It's FOSS News, URL:https://news.itsfoss.com/rss/, language:en-US

## Open Source Microsoft Office Alternative ONLYOFFICE Releases Version 7.4
 - [https://news.itsfoss.com/onlyoffice-7-4-release/](https://news.itsfoss.com/onlyoffice-7-4-release/)
 - RSS feed: https://news.itsfoss.com/rss/
 - date published: 2023-06-16 03:59:49+00:00

There is a new release of the awesome ONLYOFFICE.

