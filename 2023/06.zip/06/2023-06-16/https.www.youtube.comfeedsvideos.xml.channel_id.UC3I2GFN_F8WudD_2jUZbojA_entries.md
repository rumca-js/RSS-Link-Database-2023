# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Caroline Polachek - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=7XYyDsl14E4](https://www.youtube.com/watch?v=7XYyDsl14E4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-06-16 15:00:05+00:00

http://KEXP.ORG presents Caroline Polachek performing live in the KEXP studio. Recorded May 4, 2023

Songs:
Blood And Butter
Butterfly Net
Sunset

Caroline Polachek - Vocals, Keys
Matthew Horton - Guitar
Maya Roseann Laner - Bass, Vocals
Russell Hozman - Drums

Host: Kevin Cole
Audio Engineers: Julian Martlew, Jon Roberts
Guest Audio Engineer & Audio Mixer: Mikey Weiland
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Scott Holpainen
Editor: Scott Holpainen

https://www.carolinepolachek.com
http://kexp.org

## Caroline Polachek - Blood And Butter (Live on KEXP)
 - [https://www.youtube.com/watch?v=pAcWU_3FDKg](https://www.youtube.com/watch?v=pAcWU_3FDKg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-06-16 11:00:43+00:00

http://KEXP.ORG presents Caroline Polachek performing “Blood And Butter” live in the KEXP studio. Recorded May 4, 2023

Caroline Polachek - Vocals, Keys
Matthew Horton - Guitar
Maya Roseann Laner - Bass, Vocals
Russell Hozman - Drums

Host: Kevin Cole
Audio Engineers: Julian Martlew, Jon Roberts
Guest Audio Engineer & Audio Mixer: Mikey Weiland
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Scott Holpainen
Editor: Scott Holpainen

https://www.carolinepolachek.com
http://kexp.org

## Caroline Polachek - Sunset (Live on KEXP)
 - [https://www.youtube.com/watch?v=oc1faEHF01Q](https://www.youtube.com/watch?v=oc1faEHF01Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-06-16 11:00:39+00:00

http://KEXP.ORG presents Caroline Polachek performing “Sunset” live in the KEXP studio. Recorded May 4, 2023

Caroline Polachek - Vocals, Keys
Matthew Horton - Guitar
Maya Roseann Laner - Bass, Vocals
Russell Hozman - Drums

Host: Kevin Cole
Audio Engineers: Julian Martlew, Jon Roberts
Guest Audio Engineer & Audio Mixer: Mikey Weiland
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Scott Holpainen
Editor: Scott Holpainen

https://www.carolinepolachek.com
http://kexp.org

## Caroline Polachek - Butterfly Net (Live on KEXP)
 - [https://www.youtube.com/watch?v=Sx3pFcBTmRc](https://www.youtube.com/watch?v=Sx3pFcBTmRc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-06-16 11:00:19+00:00

http://KEXP.ORG presents Caroline Polachek performing “Butterfly Net” live in the KEXP studio. Recorded May 4, 2023

Caroline Polachek - Vocals, Keys
Matthew Horton - Guitar
Maya Roseann Laner - Bass, Vocals
Russell Hozman - Drums

Host: Kevin Cole
Audio Engineers: Julian Martlew, Jon Roberts
Guest Audio Engineer & Audio Mixer: Mikey Weiland
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Scott Holpainen
Editor: Scott Holpainen

https://www.carolinepolachek.com
http://kexp.org

