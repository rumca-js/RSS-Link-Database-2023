# Source:Money PL, URL:https://www.money.pl/rss/, language:pl-PL

## Emerytury pomostowe. Sejm zadecydował, co dalej ze świadczeniem
 - [https://www.money.pl/emerytury/emerytury-pomostowe-sejm-zadecydowal-co-dalej-ze-swiadczeniem-6909648132737664a.html](https://www.money.pl/emerytury/emerytury-pomostowe-sejm-zadecydowal-co-dalej-ze-swiadczeniem-6909648132737664a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-16 17:11:37+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cde97d3c-e9ab-4448-ba91-0c8953fb40f3" width="308" /> Sejm przegłosował zmiany w emeryturach pomostowych. Teraz na "pomostówki" mogą przejść nie tylko te osoby, które przed 1 stycznia 1999 r. wykonywały pracę w szczególnych warunkach lub w szczególnym charakterze.

## To sztandarowy program PiS. "Miliony złotych zatopione"
 - [https://www.money.pl/gospodarka/to-sztandarowy-program-pis-miliony-zlotych-zatopione-6909576395778624a.html](https://www.money.pl/gospodarka/to-sztandarowy-program-pis-miliony-zlotych-zatopione-6909576395778624a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-16 16:34:04+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/138a9652-b323-4308-b8b8-681bc564bd0b" width="308" /> - Zapowiedź wielkiego promu okazała się wielkim oszustwem. Przez niekompetencję i dyletanctwo miliony złotych zostały zatopione - tak poseł Platformy Obywatelskiej Arkadiusz Marchewka komentuje informacje money.pl, który dotarł do kilkuset nieznanych dotychczas dokumentów na temat rządowego programu "Batory".

## Prognozy się potwierdziły. Są najnowsze dane o inflacji bazowej
 - [https://www.money.pl/gospodarka/inflacja-bazowa-w-polsce-maj-2023-r-dane-nbp-6909561283000960a.html](https://www.money.pl/gospodarka/inflacja-bazowa-w-polsce-maj-2023-r-dane-nbp-6909561283000960a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-16 12:00:55+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/f8b5b502-8dd9-42a0-bab6-7a7956cb108a" width="308" /> Inflacja bazowa (z wyłączeniem cen energii i żywności) wyniosła w maju 11,5 proc. wobec 12,2 proc. w kwietniu i rekordowych 12,3 proc. odnotowanych w marcu. Odczyt jest zgodny z prognozami.

## Rosyjskie Davos. Putin wygłosi ważne przemówienie. Powie całą prawdę?
 - [https://www.money.pl/gospodarka/rosyjskie-davos-putin-wyglosi-wazne-przemowienie-powie-cala-prawde-6909596526950976a.html](https://www.money.pl/gospodarka/rosyjskie-davos-putin-wyglosi-wazne-przemowienie-powie-cala-prawde-6909596526950976a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-16 11:00:09+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/8224b5bc-a52a-4d49-a97e-7bf109f508ec" width="308" /> Prezydent Rosji Władimir Putin weźmie udział w Międzynarodowym Forum Ekonomicznym w Sankt Petersburgu, nazywanym rosyjskim Davos. Przywódca w piątek wygłosi przemówienie, w którym jak informuje RIA Novosti, poruszy kwestię wpływu wojny na rosyjską gospodarkę.

## "Budżet robiony na serwetce". Ekspert nie miał litości: nic tego nie usprawiedliwia
 - [https://www.money.pl/gospodarka/budzet-robiony-na-serwetce-ekspert-nie-mial-litosci-nic-tego-nie-usprawiedliwia-6909578592777857v.html](https://www.money.pl/gospodarka/budzet-robiony-na-serwetce-ekspert-nie-mial-litosci-nic-tego-nie-usprawiedliwia-6909578592777857v.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-16 09:49:24+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/a72790c0-e15a-4ec5-bdaf-02f23e1168d1" width="308" /> - W styczniu tego roku w Senacie prezentowałem raport pt. "Prawdziwy budżet". Z niego wynika, że prawdziwy deficyt, który powinien się znaleźć w przyzwoitym budżecie ministerstwa finansów, wynosi ponad 200 mld zł - powiedział w programie "Money.pl" dr Sławomir Dudek, szef Instytutu Finansów Publicznych. - Rząd częściowo uaktualnił budżet, zwiększając deficyt do ponad 90 mld zł, ale prawda jest taka, że ta fikcja została zastąpiona inną fikcją. Nadal nie wiemy, jakie jest zadłużenie funduszu zbrojeniowego, bo minister Mariusz Błaszczak dostał kartę kredytową bez limitu. Ostatecznym recenzentem tego, jaki jest budżet, jest rynek finansowy. Pytanie, czy rynek jest w stanie sfinansować taki deficyt. Ministerstwo finansów myli dwie sprawy. Opinia NIK nie jest o stanie finansów publicznych, chodzi o robienie budżetu na serwetce. Ani pandemia, ani wojna nie usprawiedliwiają robienia budżetu na serwetce, czyli wyprowadzania setek miliardów zł poza kontrolę obywatelską. Nie można łamać Konstytucji. Rozdawanie czeków dla wybranych samorządów pokazuje te manipulacje. Pod przykrywką ratowania finansów po pandemii są realizowane obietnice wyborcze, jednoosobowo przez premiera Morawieckiego. To nie jest wynik nagłej sytuacji. Ten fundusz to raj wydatkowy rządu - stwierdził ekspert.

## Benefity pracownicze a zadowolenie i rotacja pracowników
 - [https://www.money.pl/gospodarka/benefity-pracownicze-a-zadowolenie-i-rotacja-pracownikow-6909562892122688a.html](https://www.money.pl/gospodarka/benefity-pracownicze-a-zadowolenie-i-rotacja-pracownikow-6909562892122688a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-16 08:43:18+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/370f0912-8068-447e-9742-c7b7389f1f19" width="308" /> Przedsiębiorstwa zmagające się z dużą rotacją pracowników, powinny zastanowić się nad zahamowaniem tego zjawiska. Owa rotacja może być spowodowana nieskutecznym systemem ich motywowania. Być może wprowadzenie odpowiednich, dopasowanych do potrzeb podwładnych benefitów pracowniczych przyniosłoby oczekiwane skutki w postaci zachowania zatrudnionych.

## Gigant inwestuje w Polsce. Premier: to jest coś bez precedensu
 - [https://www.money.pl/gospodarka/gigant-inwestuje-w-polsce-premier-to-jest-cos-bez-precedensu-6909562703948352a.html](https://www.money.pl/gospodarka/gigant-inwestuje-w-polsce-premier-to-jest-cos-bez-precedensu-6909562703948352a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-16 08:42:32+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e1cf9316-4cb4-44a2-8e8f-1cdb4c0a9586" width="308" /> Intel chce zainwestować 4,6 mld dol. i zatrudnić 2 tys. osób w zakładzie integracji i testowania półprzewodników w okolicach Wrocławia. - Powstanie zupełnie nowy sektor przemysłowy, który wzmocni strategiczne partnerstwo transatlantyckie - powiedział obecny na miejscu inwestycji premier Mateusz Morawiecki.

## Izrael pomoże Polsce w staraniach o reparacje od Niemiec? Wiceszef MSZ zabiera głos
 - [https://www.money.pl/gospodarka/izrael-pomoze-polsce-w-staraniach-o-reparacje-od-niemiec-wiceszef-msz-zabiera-glos-6909549075438208a.html](https://www.money.pl/gospodarka/izrael-pomoze-polsce-w-staraniach-o-reparacje-od-niemiec-wiceszef-msz-zabiera-glos-6909549075438208a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-16 07:47:05+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/1cdb3882-28f9-4c0b-8d0a-76321550f20b" width="308" /> - Narody polski i żydowski mają ze sobą bardzo dużo wspólnego. Powinny działać razem, powinniśmy wspólnie, jako ofiary drugiej wojny światowej, występować o zadośćuczynienie do głównego sprawcy, czyli do Niemiec - powiedział w  wywiadzie dla "Super Expressu" wiceminister spraw zagranicznych Paweł Jabłoński.

## Rząd bez pozytywnej oceny budżetu. "Stosowaliśmy skuteczne narzędzia"
 - [https://www.money.pl/gospodarka/rzad-bez-pozytywnej-oceny-budzetu-stosowalismy-skuteczne-narzedzia-6909532056934976a.html](https://www.money.pl/gospodarka/rzad-bez-pozytywnej-oceny-budzetu-stosowalismy-skuteczne-narzedzia-6909532056934976a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-16 06:37:50+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/9b73f004-4938-46f6-a3bc-efbbc125b0ad" width="308" /> - Rząd zasługuje na absolutorium. Stosowaliśmy narzędzia, które były stosowane przez inne państwa i okazały się skuteczne - powiedział w programie "Tłit" Wirtualnej Polski wiceminister finansów Artur Soboń. W ten sposób odniósł się do informacji money.pl o tym, że NIK nie oceniła budżetu PiS za 2022 r. pozytywnie, co nigdy w historii wolnej Polski nie zdarzyło się.

## Problemy na rynku LPG. Terminal będzie zagrożony?
 - [https://www.money.pl/gospodarka/problemy-na-rynku-lpg-terminal-bedzie-zagrozony-6909517678086784a.html](https://www.money.pl/gospodarka/problemy-na-rynku-lpg-terminal-bedzie-zagrozony-6909517678086784a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-16 05:39:20+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e2dead59-a9e8-4cad-852b-235056cebe91" width="308" /> Kluczowy terminal LPG w Gdyni zagrożony jest wstrzymaniem działalności, a co za tym idzie, możemy spodziewać się potężnych problemów z dostawami - alarmuje biznesowy serwis "Super Expressu". Cytując eksperta, serwis informuje, że sąd umorzył  sanację właścicielowi terminala.

## Ile kosztuje euro? Kurs euro do złotego PLN/EUR 16.06.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-16-06-2023-6909508825524864a.html](https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-16-06-2023-6909508825524864a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-16 05:03:25+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cf3a8300-d9c9-461f-9fbc-2f314332a28c" width="308" /> Kurs euro - 16.06.2023. W piątek za jedno euro (EUR) trzeba zapłacić 4.451 zł.

## Ile kosztuje frank szwajcarski? Kurs franka do złotego PLN/CHF 16.06.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-16-06-2023-6909508825033344a.html](https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-16-06-2023-6909508825033344a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-16 05:03:25+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b1c04e3f-7bce-4c35-b03c-7a8d7b0adc65" width="308" /> Kurs franka szwajcarskiego - 16.06.2023. W piątek za jednego franka (CHF) trzeba zapłacić 4.5601 zł.

## Ile kosztuje dolar? Kurs dolara do złotego PLN/USD 16.06.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-16-06-2023-6909508823685760a.html](https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-16-06-2023-6909508823685760a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-16 05:03:24+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e0ba71a8-9c02-482d-85dd-ebac5362ee3b" width="308" /> Kurs dolara - 16.06.2023. W piątek za jednego dolara (USD) trzeba zapłacić 4.0684 zł.

## Ile kosztuje funt? Kurs funta do złotego PLN/GBP 16.06.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-16-06-2023-6909508822858368a.html](https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-16-06-2023-6909508822858368a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-16 05:03:24+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c374eefc-9e8b-424a-aaa7-91759b47d116" width="308" /> Kurs funta szterlinga - 16.06.2023. W piątek za jednego funta brytyjskiego (GBP) trzeba zapłacić 5.2 zł.

## Europa wypełniona węglem. Te dane mówią wszystko
 - [https://www.money.pl/gospodarka/europa-wypelniona-weglem-te-dane-mowia-wszystko-6909500830796416a.html](https://www.money.pl/gospodarka/europa-wypelniona-weglem-te-dane-mowia-wszystko-6909500830796416a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-16 04:30:46+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/5ab157a6-d6ae-40b7-a5d5-62bf8f7b7d3b" width="308" /> W kwietniu import węgla do Unii Europejskiej i Wielkiej Brytanii wyniósł 4,2 mln ton. To oznacza spadek o 1 mln ton w ciągu roku i najmniej od sierpnia 2020 r. Tempo importu do Europy gwałtownie spadło. To efekt m.in. rosnących temperatur, wyższej produkcja energii z OZE i niższych cen gazu.

