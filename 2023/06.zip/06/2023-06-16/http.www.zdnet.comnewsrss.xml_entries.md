# Source:ZDNET, URL:http://www.zdnet.com/news/rss.xml, language:en-US

## LLMs aren't even as smart as dogs, says Meta's AI chief scientist
 - [https://www.zdnet.com/article/llms-arent-even-as-smart-as-dogs-says-metas-ai-chief-scientist/#ftag=RSSbaffb68](https://www.zdnet.com/article/llms-arent-even-as-smart-as-dogs-says-metas-ai-chief-scientist/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-06-16 20:26:31+00:00

LeCun also said not to fear an AI takeover because 'there is no correlation between being smart and wanting to take over.'

## How to access, install, and use AI ChatGPT-4 plugins (and why you should)
 - [https://www.zdnet.com/article/how-to-access-install-and-use-ai-chatgpt-4-plugins/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-access-install-and-use-ai-chatgpt-4-plugins/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-06-16 20:00:31+00:00

ChatGPT-3.5 is useful. ChatGPT-4 can be very useful. But, for the most useful version of ChatGPT to date, you need to add, implement, and use ChatGPT-4 with plugins.

## Even Google is warning its employees about AI chatbot use
 - [https://www.zdnet.com/article/even-google-is-warning-its-employees-about-ai-chatbot-use/#ftag=RSSbaffb68](https://www.zdnet.com/article/even-google-is-warning-its-employees-about-ai-chatbot-use/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-06-16 18:57:34+00:00

Think before you chat with ChatGPT, Google Bard, Bing Chat, or any other AI chatbot.

## Twitch announces a new program to help streamers make more money
 - [https://www.zdnet.com/article/twitch-announces-a-new-program-to-help-streamers-make-more-money/#ftag=RSSbaffb68](https://www.zdnet.com/article/twitch-announces-a-new-program-to-help-streamers-make-more-money/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-06-16 18:43:45+00:00

Some Twitch streamers could be eligible for a new more favorable revenue split. But there are several things worth noting.

## ChatGPT-powered voice commands are coming to Mercedes-Benz cars
 - [https://www.zdnet.com/article/chatgpt-powered-voice-commands-are-coming-to-mercedes-benz-cars/#ftag=RSSbaffb68](https://www.zdnet.com/article/chatgpt-powered-voice-commands-are-coming-to-mercedes-benz-cars/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-06-16 16:12:00+00:00

If you own a Mercedes-Benz, your ChatGPT usage can now seamlessly expand to your car. Here's how.

## Lenovo Yoga Book 9i review: A dual-screen laptop before its time, and I'm here for it
 - [https://www.zdnet.com/article/lenovos-yoga-book-9i-review/#ftag=RSSbaffb68](https://www.zdnet.com/article/lenovos-yoga-book-9i-review/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-06-16 13:39:00+00:00

The dual-screen laptop goes all-in on touchscreen inputs and packs plenty of performance, but all that innovation comes at a cost - and a learning curve.

## 5 ways to say no to pointless meetings
 - [https://www.zdnet.com/home-and-office/work-life/5-ways-to-say-no-to-pointless-meetings/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/work-life/5-ways-to-say-no-to-pointless-meetings/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-06-16 13:36:32+00:00

There are few things worse than a calendar full of back-to-back meetings. Here's how to make it stop.

## Is humanity really doomed? Consider AI's Achilles heel
 - [https://www.zdnet.com/article/is-humanity-really-doomed-consider-ais-achilles-heel/#ftag=RSSbaffb68](https://www.zdnet.com/article/is-humanity-really-doomed-consider-ais-achilles-heel/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-06-16 10:34:26+00:00

AI is here to stay, but no matter what developers and businesses think, it's not perfect. In fact, it has one glaring inadequacy that it will never surmount.

## How to vastly improve sound on Linux with EasyEffects
 - [https://www.zdnet.com/article/how-to-vastly-improve-sound-on-linux-with-easyeffects/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-vastly-improve-sound-on-linux-with-easyeffects/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-06-16 08:54:30+00:00

If you're looking to enhance the quality of sound you hear on the Linux operating system, EasyEffects is the simplest way to go.

## The US government buys your user data. Here's what it does with it
 - [https://www.zdnet.com/article/the-us-government-purchases-your-user-data-heres-what-it-does-with-it/#ftag=RSSbaffb68](https://www.zdnet.com/article/the-us-government-purchases-your-user-data-heres-what-it-does-with-it/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-06-16 00:00:06+00:00

A declassified report confirms for the first time that the US government purchases Americans' personal information from third-party data brokers. Here's what you need to know about it.

