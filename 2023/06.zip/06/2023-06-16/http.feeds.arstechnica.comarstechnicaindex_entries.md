# Source:ArsTechnica, URL:http://feeds.arstechnica.com/arstechnica/index/, language:en-US

## The US Navy, NATO, and NASA are using a shady Chinese company’s encryption chips
 - [https://arstechnica.com/?p=1948695](https://arstechnica.com/?p=1948695)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-06-16 19:41:17+00:00

US government warns encryption chipmaker Hualan has suspicious ties to China’s military.

## Weirdly, a NASA official says fixed-price contracts do the agency “no good”
 - [https://arstechnica.com/?p=1948558](https://arstechnica.com/?p=1948558)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-06-16 18:22:00+00:00

"What really makes me worried is that I think it shows where the heart of the agency is."

## Valve gives Steam its biggest update and redesign in years
 - [https://arstechnica.com/?p=1948635](https://arstechnica.com/?p=1948635)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-06-16 17:52:10+00:00

It's a night-and-day difference for macOS and Linux users.

## FCC chair to investigate exactly how much everyone hates data caps
 - [https://arstechnica.com/?p=1948619](https://arstechnica.com/?p=1948619)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-06-16 17:37:07+00:00

ISPs clearly have technical ability to offer unlimited data, chair's office says.

## Deadly fungal meningitis cases nearly double as CDC rushes to find exposed
 - [https://arstechnica.com/?p=1948611](https://arstechnica.com/?p=1948611)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-06-16 17:21:16+00:00

The source and fungus are both elusive; officials are aggressively treating exposed.

## Ultra low-cost smartphone attachment measures blood pressure at home
 - [https://arstechnica.com/?p=1948581](https://arstechnica.com/?p=1948581)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-06-16 17:16:43+00:00

Clever use of physics uses pressure on the skin and optics to track blood flow.

## Windows 11 beta fixes major taskbar gripe, removes old File Explorer settings
 - [https://arstechnica.com/?p=1948543](https://arstechnica.com/?p=1948543)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-06-16 16:47:55+00:00

New build also (sort of) removes OS-level Microsoft Teams integration.

## Twitter restricted Democrat’s pro-abortion ad—but platform may backpedal
 - [https://arstechnica.com/?p=1948572](https://arstechnica.com/?p=1948572)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-06-16 16:46:31+00:00

Twitter ad policy restricting abortion advocacy may soon change, employee says.

## Google is “winding down” Google Domains by selling it to Squarespace
 - [https://arstechnica.com/?p=1948540](https://arstechnica.com/?p=1948540)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-06-16 16:41:25+00:00

Transition is automatic, but Squarespace honoring renewal fees for only 1 year.

## Millions of Americans’ personal DMV data exposed in massive MOVEit hack
 - [https://arstechnica.com/?p=1948548](https://arstechnica.com/?p=1948548)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-06-16 16:28:35+00:00

Over 6.5 million residents of two states affected, impact may potentially widen.

## Retro MacOS desktop blanket trades pixels for thread, and it looks Mac-nificent
 - [https://arstechnica.com/?p=1948075](https://arstechnica.com/?p=1948075)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-06-16 14:09:22+00:00

New knit screenshot throw celebrates the Mac's early years. We talk to its creator.

## Dealmaster: Summer savings on laptops, smartphones, and smartwatches
 - [https://arstechnica.com/?p=1948110](https://arstechnica.com/?p=1948110)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-06-16 11:15:28+00:00

With savings on laptops and smartphones, now is a great time to upgrade your gear.

## Rocket Report: China addresses falling rocket debris, Vulcan launch slipping
 - [https://arstechnica.com/?p=1947976](https://arstechnica.com/?p=1947976)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-06-16 11:00:40+00:00

FAA is "taking a finer pencil to the way operations are run and managed."

