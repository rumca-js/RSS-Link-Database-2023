# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## WAIT… Did He REALLY Just Say That?!
 - [https://www.youtube.com/watch?v=8DLf2jZSW80](https://www.youtube.com/watch?v=8DLf2jZSW80)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2023-06-16 17:00:07+00:00

Visit https://www.manscaped.com and use promo code BRAND to save 20%

Meta CEO Mark Zuckerberg ADMITS censoring true information for the establishment. So how did we get into a situation where platforms are censoring information that, as he says “ended up being more debatable or true”, and where is the Censorship Industrial Complex all leading to? 
#facebook #lexfridman #markzuckerberg #censorship 

References
https://public.substack.com/p/why-the-media-is-attacking-free-speech
--------------------------------------------------------------------------------------------------------------------------
Tickets for Censorship Industrial Complex Exposed available here: https://www.musicglue.com/good-faith-productions/events/2023-06-22-censorship-industrial-complex-exposed-westminster-central-hall

My stand up special is premiering on 25th June! You will love it! Go to https://moment.co/russellbrand

WATCH me LIVE weekdays on Rumble: https://bit.ly/russellbrand-rumble

Join Russell Brand Connected over on Locals: https://bit.ly/russellbrand-connected-community

Come COMMUNITY 2023 - https://www.russellbrand.com/community-2023/
NEW MERCH! https://stuff.russellbrand.com/

Keep up to date, Join my mailing list - https://www.russellbrand.com/join-the-community/

## WTF! Lockheed Martin Sponsor Pride March!? Plus, Marianne Williamson - #148 - Stay Free PREVIEW
 - [https://www.youtube.com/watch?v=GsR4E9IuRJE](https://www.youtube.com/watch?v=GsR4E9IuRJE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2023-06-16 14:33:52+00:00

Join us here for a PREVIEW of our daily one-hour RUMBLE show.
To continue watching the show in full, join me live and exclusively over on RUMBLE:
https://bit.ly/stayfree-148-marianne-williamson

TODAY - Why are weapons dealer Lockheed Martin sponsoring a Pride march? Rand Paul’s call to “stop provoking China” and the exposé on the effects of lockdown on heart attack victims. PLUS, presidential candidate MARIANNE WILLIAMSON on how she’ll FIGHT THE SYSTEM!

--------------------------------------------------------------------------------------------------------------------------

FOLLOW and WATCH me LIVE weekdays on Rumble https://rumble.com/russellbrand
5:00PM BST | 12:00 PM EDT | 9:00AM PDT

Join The STAY FREE Community: https://russellbrand.locals.com/

Come to My Festival COMMUNITY - https://www.russellbrand.com/community-2023/

NEW MERCH! https://stuff.russellbrand.com/

