# Source:The Wall Street - Tech, URL:https://feeds.a.dj.com/rss/RSSWSJD.xml, language:en-US

## Commerce Move on Foreign Apps Shows Biden Team Taking Aim at TikTok
 - [https://www.wsj.com/articles/commerce-move-on-foreign-apps-shows-biden-team-taking-aim-at-tiktok-a734d0cf?mod=rss_Technology](https://www.wsj.com/articles/commerce-move-on-foreign-apps-shows-biden-team-taking-aim-at-tiktok-a734d0cf?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-06-16 18:24:00+00:00

The administration likely would need legislation from Congress to further strengthen its position.

## Musk Says Twitter Advertisers Are Coming Back
 - [https://www.wsj.com/articles/elon-musk-says-twitter-advertisers-are-coming-back-287d0ea7?mod=rss_Technology](https://www.wsj.com/articles/elon-musk-says-twitter-advertisers-are-coming-back-287d0ea7?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-06-16 17:00:00+00:00

In Paris, Musk also said he didn’t want to be the cause of an AI apocalypse and lunched with LVMH boss Bernard Arnault.

## Micron, Blacklisted by Beijing, to Pump $600 Million Into China Expansion
 - [https://www.wsj.com/articles/micron-blacklisted-by-beijing-to-pump-600-million-into-china-expansion-6b8d0075?mod=rss_Technology](https://www.wsj.com/articles/micron-blacklisted-by-beijing-to-pump-600-million-into-china-expansion-6b8d0075?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-06-16 07:31:00+00:00

Investment by biggest U.S. maker of memory chips comes about a month after major Chinese firms were banned from buying its products.

