# Source:Solid jj, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCEq_Dr1GHvnNPQNfgOzhZ8Q, language:en-US

## Back to the Past
 - [https://www.youtube.com/watch?v=22WR3SDRYqM](https://www.youtube.com/watch?v=22WR3SDRYqM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCEq_Dr1GHvnNPQNfgOzhZ8Q
 - date published: 2023-06-16 18:55:02+00:00

Marty McFly must go back to the past so he can go back to the future and have 5/10 jokes I make a day be erased from time.

Second channel: @Solidusjj 
Patreon: https://patreon.com/solidjj

