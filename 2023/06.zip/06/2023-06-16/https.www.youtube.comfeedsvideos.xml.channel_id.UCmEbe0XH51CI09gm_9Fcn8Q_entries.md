# Source:Glass Reflection, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCmEbe0XH51CI09gm_9Fcn8Q, language:en-US

## A Slow News Day? What Does That Mean? Also Some Reddit Stuff... | Today's Anime News
 - [https://www.youtube.com/watch?v=fkYTIK3_Yrw](https://www.youtube.com/watch?v=fkYTIK3_Yrw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmEbe0XH51CI09gm_9Fcn8Q
 - date published: 2023-06-16 20:14:37+00:00

► Support me on Patreon: http://www.patreon.com/Arkada
► Follow me on Twitter: http://www.twitter.com/GlassReflection

00:00 - INTRO
00:48 - Things and Stuff!
08:48 - Thanks to Viewers Like You
09:22 - Seasonal Anime Rankings

Sources:
Anime Rankings ►
https://anitrendz.com/charts/top-anime/2023-06-11


#Reddit #glassreflection  #BehindTheScenes #GRTodaysAnimeNews

