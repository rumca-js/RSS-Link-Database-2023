# Source:Epoch times world, URL:https://www.theepochtimes.com/c-world/feed/, language:en-US

## Fight to Repatriate Australian Women, Kids From Syrian Camp
 - [https://www.theepochtimes.com/fight-to-repatriate-australian-women-kids-from-syrian-camp_5337715.html](https://www.theepochtimes.com/fight-to-repatriate-australian-women-kids-from-syrian-camp_5337715.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 23:00:16+00:00

A general view of the al-Hol displaced persons camp is seen in northeastern Syria on Feb. 17, 2019. (Bulent Kilic/AFP/Getty Images)

## Semi Had Right of Way in Horrific Manitoba Crash: RCMP
 - [https://www.theepochtimes.com/semi-had-right-of-way-in-horrific-manitoba-crash-rcmp_5339162.html](https://www.theepochtimes.com/semi-had-right-of-way-in-horrific-manitoba-crash-rcmp_5339162.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 22:46:31+00:00

Flowers are seen on the side of the road where the Trans-Canada highway intersects with Hwy 5 near Carberry, Man., on June 16, 2023, where a semi and a bus collided on June 15. (Darryl Dyck/The Canadian Press)

## Parliament ‘Catering’ to Transgender Visitors by Installing Gender-Neutral Washrooms, Says Senate Opposition Leader
 - [https://www.theepochtimes.com/parliament-catering-to-transgender-visitors-by-installing-gender-neutral-washrooms-says-senate-opposition-leader_5338644.html](https://www.theepochtimes.com/parliament-catering-to-transgender-visitors-by-installing-gender-neutral-washrooms-says-senate-opposition-leader_5338644.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 21:54:38+00:00

Conservative Sen. Don Plett in a file photo. (The Canadian Press/Adrian Wyld)

## Candidates Clash Over Homeless Encampments in Toronto
 - [https://www.theepochtimes.com/candidates-clash-over-homeless-encampments-in-toronto_5338837.html](https://www.theepochtimes.com/candidates-clash-over-homeless-encampments-in-toronto_5338837.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 21:25:13+00:00

Mayoral candidates Anthony Furey (L) and Olivia Chow.  (Courtesy Anthony Furey; The Canadian Press/Chris Young)

## OPP Officer Guilty of Sex Assault Dismissed After Years on Paid Leave
 - [https://www.theepochtimes.com/opp-officer-guilty-of-sex-assault-dismissed-after-years-on-paid-leave_5339012.html](https://www.theepochtimes.com/opp-officer-guilty-of-sex-assault-dismissed-after-years-on-paid-leave_5339012.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 21:05:59+00:00

A file photo of an Ontario Provincial Police logo. (Nathan Denette/The Canadian Press)

## MP Chong Questions Why Still No Arrests Made in Relation to Chinese Police Stations After 8 Months
 - [https://www.theepochtimes.com/mp-chong-questions-why-still-no-arrests-made-in-relation-to-chinese-police-stations-after-8-months_5338305.html](https://www.theepochtimes.com/mp-chong-questions-why-still-no-arrests-made-in-relation-to-chinese-police-stations-after-8-months_5338305.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 21:05:53+00:00

Conservative MP for Wellington-Halton Hills MP Michael Chong appears as a witness at the Standing Committee on Procedure and House Affairs (PROC) regarding foreign election interference on Parliament Hill in Ottawa, on May 16, 2023. (Spencer Colby/The Canadian Press)

## Poor Forest Management to Blame for Canada’s Wildfires, Not Climate Change
 - [https://www.theepochtimes.com/poor-forest-management-to-blame-for-canadas-wildfires-not-climate-change_5337903.html](https://www.theepochtimes.com/poor-forest-management-to-blame-for-canadas-wildfires-not-climate-change_5337903.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 20:57:25+00:00

The Murtle Lake wildfire, located within Wells Gray Provincial Park, is shown in this handout photo provided by the BC Wildfire Service on June 9, 2023. (The Canadian Press/HO-BC Wildfire Service)

## Business Sector Disappointed With South Australia’s Budget
 - [https://www.theepochtimes.com/business-sector-disappointed-with-south-australias-budget_5337461.html](https://www.theepochtimes.com/business-sector-disappointed-with-south-australias-budget_5337461.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 20:53:30+00:00

An employee works at the Multi Slide Industries manufacturing plant in Adelaide, Australia, on Aug. 12, 2013. (Morne de Klerk/Getty Images)

## Cory Morgan: The Mounting ‘Yes Minister’ Moments Are Not So Funny
 - [https://www.theepochtimes.com/cory-morgan-the-mounting-yes-minister-moments-are-not-so-funny_5337839.html](https://www.theepochtimes.com/cory-morgan-the-mounting-yes-minister-moments-are-not-so-funny_5337839.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 20:52:50+00:00

A poster of the 1980s British sitcom comedy "Yes, Minister." (Public Domain)

## RCMP Say No Critical Injuries in Crash of Bus With 30 Aboard Near Prince George, BC
 - [https://www.theepochtimes.com/rcmp-say-no-critical-injuries-in-crash-of-bus-with-30-aboard-near-prince-george-bc_5338961.html](https://www.theepochtimes.com/rcmp-say-no-critical-injuries-in-crash-of-bus-with-30-aboard-near-prince-george-bc_5338961.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 20:51:51+00:00

The RCMP logo in a file photo. (The Canadian Press/Darryl Dyck)

## Manitoba RCMP, Community Leaders Look to Saskatchewan After Deadly Crash
 - [https://www.theepochtimes.com/manitoba-rcmp-community-leaders-look-to-saskatchewan-after-deadly-crash_5338945.html](https://www.theepochtimes.com/manitoba-rcmp-community-leaders-look-to-saskatchewan-after-deadly-crash_5338945.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 20:47:24+00:00

A memorial on the roadside where the deadly Humboldt Broncos bus crash took place is shown on Highway 35 near Armley, Sask., on March 18, 2023. (The Canadian Press/Liam Richards)

## Surrey, BC, to Stay With RCMP Over Independent Force, Costing the City Millions
 - [https://www.theepochtimes.com/surrey-bc-to-stay-with-rcmp-over-independent-force-costing-the-city-millions_5338930.html](https://www.theepochtimes.com/surrey-bc-to-stay-with-rcmp-over-independent-force-costing-the-city-millions_5338930.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 20:43:36+00:00

Surrey Mayor Brenda Locke speaks during a news conference about the city's municipal police force transition, in Surrey, B.C., on April 28, 2023. (The Canadian Press/Darryl Dyck)

## [PREMIERING 6/17, 7:30PM ET] Exposing the Vaccine ‘Military Machinery’ Behind the Global COVID-19 Response: Sasha Latypova
 - [https://www.theepochtimes.com/exposing-the-vaccine-military-machinery-behind-the-global-covid-19-response-sasha-latypova_5335644.html](https://www.theepochtimes.com/exposing-the-vaccine-military-machinery-behind-the-global-covid-19-response-sasha-latypova_5335644.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 20:42:05+00:00



## BC’s Largest Wildfire Still Threatens, as Conditions Elsewhere Ease
 - [https://www.theepochtimes.com/bcs-largest-wildfire-still-threatens-as-conditions-elsewhere-ease_5338918.html](https://www.theepochtimes.com/bcs-largest-wildfire-still-threatens-as-conditions-elsewhere-ease_5338918.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 20:39:41+00:00

The Murtle Lake wildfire, located within Wells Gray Provincial Park, is shown in this handout photo provided by the BC Wildfire Service on June 9, 2023. (The Canadian Press/HO-BC Wildfire Service)

## New Brunswick premier open to leadership test, remains vague on early election call
 - [https://www.theepochtimes.com/new-brunswick-premier-open-to-leadership-test-remains-vague-on-early-election-call_5338844.html](https://www.theepochtimes.com/new-brunswick-premier-open-to-leadership-test-remains-vague-on-early-election-call_5338844.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 20:37:23+00:00

New Brunswick Premier Blaine Higgs speaks in Fredericton, N.B., on Feb. 9, 2023. (Stephen MacGillivray/The Canadian Press)

## ‘Exciting Milestone’: Canada’s Population Hits 40 Million
 - [https://www.theepochtimes.com/exciting-milestone-canadas-population-hits-40-million_5337889.html](https://www.theepochtimes.com/exciting-milestone-canadas-population-hits-40-million_5337889.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 20:06:23+00:00

New Canadians take the Oath of Citizenship in a ceremony at the Canadian Museum of Immigration at Pier 21 in Halifax on Jan. 15, 2020. (The Canadian Press/Riley Smith)

## Gender Dysphoria Growing Because It’s Become ‘Popular and Trendy,’ NB Premier Says
 - [https://www.theepochtimes.com/third-new-brunswick-cabinet-minister-quits-following-vote-on-controversial-policy-713-post_5338486.html](https://www.theepochtimes.com/third-new-brunswick-cabinet-minister-quits-following-vote-on-controversial-policy-713-post_5338486.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 19:57:34+00:00

New Brunswick Premier Blaine Higgs attends a meeting of Canada’s premiers at the Marriott Chateau Champlain in Montreal on Dec. 7, 2018. (Martin Ouellet-Diotte/AFP via Getty Images)

## Gender Critical Professor Forced From Job Raises £160,000 to Sue University
 - [https://www.theepochtimes.com/gender-critical-professor-forced-from-job-raises-160000-to-sue-university_5338118.html](https://www.theepochtimes.com/gender-critical-professor-forced-from-job-raises-160000-to-sue-university_5338118.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 19:48:49+00:00

Undated handout of Professor Jo Phoenix who is suing the Open University. (Courtesy of Jo Phoenix)

## Bill Requiring Federally Registered Companies to Disclose Ownership Structure Approved by Committee
 - [https://www.theepochtimes.com/house-committee-approves-bill-requiring-federally-registered-companies-disclose-ultimate-beneficial-owners_5338548.html](https://www.theepochtimes.com/house-committee-approves-bill-requiring-federally-registered-companies-disclose-ultimate-beneficial-owners_5338548.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 19:22:04+00:00

The Canadian flag flies near the Peace Tower on Parliament Hill in Ottawa on June 17, 2020. (Adrian Wyld/The Canadian Press)

## House of Commons Passes Motion to Permanently Allow Virtual Attendance, Voting
 - [https://www.theepochtimes.com/house-of-commons-passes-motion-to-permanently-allow-virtual-attendance-voting_5338590.html](https://www.theepochtimes.com/house-of-commons-passes-motion-to-permanently-allow-virtual-attendance-voting_5338590.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 18:55:07+00:00

Prime Minister Justin Trudeau rises during question period in the House of Commons on Parliament Hill in Ottawa on May 2, 2023. (The Canadian Press/Sean Kilpatrick)

## Six Seniors Injured in Manitoba Bus Crash That Killed 15 in Critical Condition
 - [https://www.theepochtimes.com/six-seniors-injured-in-manitoba-bus-crash-that-killed-15-in-critical-condition_5338566.html](https://www.theepochtimes.com/six-seniors-injured-in-manitoba-bus-crash-that-killed-15-in-critical-condition_5338566.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 18:48:09+00:00

A scorched patch of ground where a bus carrying seniors ended up after colliding with a transport truck and burning on Thursday is seen on the edge of the Trans-Canada Highway where it intersects with Highway 5, west of Winnipeg near Carberry, June 16, 2023. (The Canadian Press/Darryl Dyck)

## ANALYSIS: West Australia’s New Gun Bans May Have Little Impact on Crime Rates
 - [https://www.theepochtimes.com/analysis-west-australias-new-gun-bans-may-have-little-impact-on-crime-rates_5336981.html](https://www.theepochtimes.com/analysis-west-australias-new-gun-bans-may-have-little-impact-on-crime-rates_5336981.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 18:46:33+00:00

Hunting rifles and shotguns at a gun store in Toronto, in a file photo. (Kevin Frayer/The Canadian Press)

## More Than 17 Million COVID Vaccine Doses Expired, Public Health Agency Reports
 - [https://www.theepochtimes.com/more-than-17-million-covid-vaccine-doses-expired-public-health-agency-reports_5338309.html](https://www.theepochtimes.com/more-than-17-million-covid-vaccine-doses-expired-public-health-agency-reports_5338309.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 18:44:31+00:00

A health-care worker prepares a dose of the Pfizer-BioNTech COVID-19 vaccine at a UHN COVID-19 vaccine clinic in Toronto on Jan. 7, 2021. (The Canadian Press/Nathan Denette)

## Amazon’s $1.7 Billion Deal to Buy Roomba Maker iRobot Gets UK Approval
 - [https://www.theepochtimes.com/amazons-1-7-billion-deal-to-buy-roomba-maker-irobot-gets-uk-approval_5338086.html](https://www.theepochtimes.com/amazons-1-7-billion-deal-to-buy-roomba-maker-irobot-gets-uk-approval_5338086.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 18:27:08+00:00

Roomba robot vacuums made by iRobot are displayed on a shelf at a Bed Bath and Beyond store in Larkspur, Calif., on Aug. 5, 2022. (Justin Sullivan/Getty Images)

## Canada Deploying 15 Tanks and 130 Army Personnel to Latvia: Defence Minister
 - [https://www.theepochtimes.com/canada-deploying-15-tanks-and-130-army-personnel-to-latvia-defence-minister_5337819.html](https://www.theepochtimes.com/canada-deploying-15-tanks-and-130-army-personnel-to-latvia-defence-minister_5337819.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 18:23:18+00:00

Minister of Defence Anita Anand responds to a question during a joint news conference with Polish Deputy Prime Minister and Minister of National Defence Mariusz Błaszczak at National Defence Headquarters, in Ottawa, May 8, 2023. (The Canadian Press/Adrian Wyld)

## Sacked School Worker Who Criticised Trans and LGBT Sex Education Wins Appeal
 - [https://www.theepochtimes.com/sacked-school-worker-who-criticised-trans-and-lgbt-sex-education-wins-appeal_5337995.html](https://www.theepochtimes.com/sacked-school-worker-who-criticised-trans-and-lgbt-sex-education-wins-appeal_5337995.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 18:21:14+00:00

Undated handout of Kirstie Higgs who was sacked from her teaching assistance role for sharing Facebook posts criticising compulsory sex education and transgenderism in schools. (Christian Legal Centre)

## Intel to Invest $4.6 Billion in New Chip Plant in Poland
 - [https://www.theepochtimes.com/intel-to-invest-4-6-billion-in-new-chip-plant-in-poland_5338157.html](https://www.theepochtimes.com/intel-to-invest-4-6-billion-in-new-chip-plant-in-poland_5338157.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 17:41:59+00:00

A smartphone with a displayed Intel logo is placed on a computer motherboard on March 6, 2023. (Dado Ruvic/Illustration/Reuters)

## Conservative MP Introduces Bill to Enhance Canada-Taiwan Ties
 - [https://www.theepochtimes.com/tory-mp-introduces-bill-to-enhance-canada-taiwan-ties_5337904.html](https://www.theepochtimes.com/tory-mp-introduces-bill-to-enhance-canada-taiwan-ties_5337904.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 16:40:18+00:00

Conservative MP Michael Cooper rises during question period on Parliament Hill in Ottawa on April 28, 2023. (Adrian Wyld/The Canadian Press)

## Heather Mack, Convicted in Bali of Killing Mom and Stuffing Body in Suitcase, Pleads Guilty in US
 - [https://www.theepochtimes.com/heather-mack-convicted-in-bali-of-killing-mom-and-stuffing-body-in-suitcase-pleads-guilty-in-us_5338035.html](https://www.theepochtimes.com/heather-mack-convicted-in-bali-of-killing-mom-and-stuffing-body-in-suitcase-pleads-guilty-in-us_5338035.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 16:38:14+00:00

Heather Mack of Chicago (C) is mobbed by reporters as she arrives in the courtroom for her sentencing hearing at a district court in Denpasar, Bali, Indonesia, on April 21, 2015. (Firdia Lisnawati/AP Photo)

## Nottingham University Graduate Charged With 3 Murders in the City
 - [https://www.theepochtimes.com/nottingham-university-graduate-charged-with-3-murders-in-the-city_5338062.html](https://www.theepochtimes.com/nottingham-university-graduate-charged-with-3-murders-in-the-city_5338062.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 16:25:10+00:00

Flowers, balloons, and tributes lay on the steps of Nottingham Council House after three people were killed and another three hurt in Tuesday's attacks, in Nottingham, England, on June 16, 2023. (Christopher Furlong/Getty Images)

## Supreme Court of Canada Upholds Safe Third Country Agreement
 - [https://www.theepochtimes.com/supreme-court-of-canada-upholds-safe-third-country-agreement_5338160.html](https://www.theepochtimes.com/supreme-court-of-canada-upholds-safe-third-country-agreement_5338160.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 16:12:47+00:00

The Supreme Court of Canada in Ottawa on Aug. 10, 2022. (The Canadian Press/Adrian Wyld)

## A Russian Ransomware Gang Breaches the Energy Department and Other Federal Agencies
 - [https://www.theepochtimes.com/a-russian-ransomware-gang-breaches-the-energy-department-and-other-federal-agencies_5337915.html](https://www.theepochtimes.com/a-russian-ransomware-gang-breaches-the-energy-department-and-other-federal-agencies_5337915.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 16:11:04+00:00

Cybersecurity and Infrastructure Security Agency Director Jen Easterly testifies before a House Homeland Security Subcommittee, at the Rayburn House Office Building in Washington on April 28, 2022. (Kevin Dietsch/Getty Images)

## German Police Appeal for Images Taken of an Attack in Which Americans Were Pushed Down a Steep Slope
 - [https://www.theepochtimes.com/german-police-appeal-for-images-taken-of-an-attack-in-which-americans-were-pushed-down-a-steep-slope_5338069.html](https://www.theepochtimes.com/german-police-appeal-for-images-taken-of-an-attack-in-which-americans-were-pushed-down-a-steep-slope_5338069.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 15:49:41+00:00

People watch the Neuschwanstein castle in Schwangau, Germany, on June 15, 2023. (Frank Rumpenhorst/dpa via AP)

## Parole Board Says Double Child Killer Can Go Free but Minister Might Block Freedom Bid
 - [https://www.theepochtimes.com/parole-board-says-double-child-killer-can-go-free-but-minister-might-block-freedom-bid_5337654.html](https://www.theepochtimes.com/parole-board-says-double-child-killer-can-go-free-but-minister-might-block-freedom-bid_5337654.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 15:45:19+00:00

Colin Pitchfork in an undated police handout file photo. (handout/PA)

## LIVE NOW: Blinken, Singapore Foreign Minister Hold Press Availability
 - [https://www.theepochtimes.com/blinken-singapore-foreign-minister-hold-press-availability_5337943.html](https://www.theepochtimes.com/blinken-singapore-foreign-minister-hold-press-availability_5337943.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 15:44:58+00:00

U.S. Secretary of State Antony Blinken attends a press conference at State Department in Washington on April 11, 2023. (Madalina Vasiliu/The Epoch Times)

## Ontario Expanding ‘Strong Mayor’ Powers to 26 More Cities
 - [https://www.theepochtimes.com/ontario-expanding-strong-mayor-powers-to-26-more-cities_5338126.html](https://www.theepochtimes.com/ontario-expanding-strong-mayor-powers-to-26-more-cities_5338126.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 15:39:00+00:00

Steve Clark, Ontario’s Minister of Municipal Affairs and Housing, speaks to journalists at the Queens Park Legislature, in Toronto on Nov. 16, 2022. (Chris Young/The Canadian Press)

## Recent Rain May Not Be Enough to Halt the Shrinking of Canada’s Cattle Herd
 - [https://www.theepochtimes.com/recent-rain-may-not-be-enough-to-halt-the-shrinking-of-canadas-cattle-herd_5338088.html](https://www.theepochtimes.com/recent-rain-may-not-be-enough-to-halt-the-shrinking-of-canadas-cattle-herd_5338088.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 15:22:34+00:00

Smoke billows above cattle on a farm as wildfire burn in Alberta in May 2023. (Courtesy of Grant Taillieu/Facebook)

## Swiss Cyclist Gino Mäder Dies at 26
 - [https://www.theepochtimes.com/26-year-old-swiss-cyclist-gino-mader-dies-from-injuries-suffered-in-crash-during-tour-de-suisse_5337996.html](https://www.theepochtimes.com/26-year-old-swiss-cyclist-gino-mader-dies-from-injuries-suffered-in-crash-during-tour-de-suisse_5337996.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 15:15:59+00:00

Gino Mader waits for the start of the 7th stage of the Tour of Italy cycling race in Notaresco on May 14, 2021. (Massimo Paolone/LaPresse via AP)

## Senator Oh Arranging 50 Buses to Bring Protesters to Ottawa to Oppose Foreign Agent Registry
 - [https://www.theepochtimes.com/senator-oh-arranging-50-buses-to-bring-protesters-to-ottawa-to-oppose-foreign-agent-registry_5333423.html](https://www.theepochtimes.com/senator-oh-arranging-50-buses-to-bring-protesters-to-ottawa-to-oppose-foreign-agent-registry_5333423.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 15:13:07+00:00

Conservative Sen. Victor Oh in a file photo. (Becky Zhou/The Epoch Times)

## Tesco Boss Sees ‘Early Signs’ Food Inflation Starting to Ease
 - [https://www.theepochtimes.com/tesco-boss-sees-early-signs-food-inflation-starting-to-ease_5337798.html](https://www.theepochtimes.com/tesco-boss-sees-early-signs-food-inflation-starting-to-ease_5337798.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 15:07:51+00:00

A customer shops for food items inside a Tesco supermarket store in east London, on Jan. 10, 2022. (Daniel Leal/AFP via Getty Images)

## Inflation, Interest Rates Weighing on Canadians’ Retirement Plans: Survey
 - [https://www.theepochtimes.com/inflation-interest-rates-weighing-on-canadians-retirement-plans-survey_5338033.html](https://www.theepochtimes.com/inflation-interest-rates-weighing-on-canadians-retirement-plans-survey_5338033.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 15:00:02+00:00

Canadian $100 bills are counted in Toronto on Feb. 2, 2016. (Graeme Roy/The Canadian Press)

## Canadians Opting for Shorter Mortgage Terms as They Hope for Declining Interest Rates
 - [https://www.theepochtimes.com/canadians-opting-for-shorter-mortgage-terms-as-they-hope-for-declining-interest-rates_5338023.html](https://www.theepochtimes.com/canadians-opting-for-shorter-mortgage-terms-as-they-hope-for-declining-interest-rates_5338023.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 14:56:42+00:00

A woman walks past the Bank of Canada headquarters in Ottawa, on June 1, 2022. (The Canadian Press/Adrian Wyld)

## Patients to Get Jabbed Again After Storage Uncertainty Compromises Vaccines
 - [https://www.theepochtimes.com/patients-asked-to-get-jabbed-again-after-inadequate-storage-compromises-vaccines_5337432.html](https://www.theepochtimes.com/patients-asked-to-get-jabbed-again-after-inadequate-storage-compromises-vaccines_5337432.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 14:50:29+00:00

A man receives a dose of a COVID-19 vaccine at a newly opened vaccination hub in Dubbo, Australia, on Aug. 21, 2021. (Belinda Soole/Getty Images)

## Expert Calls for South Korea to Strengthen Intellectual Property Protection Against China Theft
 - [https://www.theepochtimes.com/expert-calls-for-south-korea-to-strengthen-intellectual-property-protection-against-china-theft_5337165.html](https://www.theepochtimes.com/expert-calls-for-south-korea-to-strengthen-intellectual-property-protection-against-china-theft_5337165.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 14:45:53+00:00

South Korea and China's flags flutter next to Tiananmen Gate in Beijing on Dec. 15, 2017. (Jason Lee/Reuters)

## Voter Apathy Concerns Loom Over Toronto Election Days Ahead of Vote
 - [https://www.theepochtimes.com/voter-apathy-concerns-loom-over-toronto-election-days-ahead-of-vote_5337875.html](https://www.theepochtimes.com/voter-apathy-concerns-loom-over-toronto-election-days-ahead-of-vote_5337875.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 13:58:15+00:00

Voters line up outside a voting station to cast their ballot in the Toronto's municipal election in Toronto on Oct. 22, 2018. (The Canadian Press/Chris Young)

## RCMP Working to Confirm Identities of 15 Killed on Bus Heading to Manitoba Casino
 - [https://www.theepochtimes.com/rcmp-working-to-confirm-identities-of-15-killed-on-bus-heading-to-manitoba-casino_5337840.html](https://www.theepochtimes.com/rcmp-working-to-confirm-identities-of-15-killed-on-bus-heading-to-manitoba-casino_5337840.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 13:42:47+00:00

Emergency crews respond to the scene of a crash that has closed a section of the Trans-Canada Highway near Carberry, Man. is shown on June 15, 2023. (The Canadian Press/Steve Lambert)

## UN Labor Agency Reports 29 Percent of Domestic Workers in Malaysia Face Forced Labor
 - [https://www.theepochtimes.com/un-labor-agency-reports-29-percent-of-domestic-workers-in-malaysia-face-forced-labor_5337508.html](https://www.theepochtimes.com/un-labor-agency-reports-29-percent-of-domestic-workers-in-malaysia-face-forced-labor_5337508.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 13:31:48+00:00

A view of the Kuala Lumpur city skyline in Malaysia on Feb. 7, 2018. (Lai Seng Sin/Reuters)

## US Guided-Missile Submarine Docks in South Korea for First Time in 6 Years
 - [https://www.theepochtimes.com/us-guided-missile-submarine-docks-in-south-korea-for-first-time-in-6-years_5337645.html](https://www.theepochtimes.com/us-guided-missile-submarine-docks-in-south-korea-for-first-time-in-6-years_5337645.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 13:30:57+00:00

The guided-missile submarine USS Michigan arrives in Busan, South Korea, on April 25, 2017. The USS Michigan is in South Korea for a scheduled port visit while conducting routine patrols throughout the western Pacific. (USN Mass Communication Specialist 2nd Class Jermaine Ralliford via Getty Images)

## Thousands Allowed Back Home, but Officials Say Wildfires Still Leaving Many Displaced
 - [https://www.theepochtimes.com/thousands-allowed-back-home-but-officials-say-wildfires-still-leaving-many-displaced_5337811.html](https://www.theepochtimes.com/thousands-allowed-back-home-but-officials-say-wildfires-still-leaving-many-displaced_5337811.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 13:30:53+00:00

Crews work on a controlled burn near Edson, Alta., on June 13, 2023. (The Canadian Press/HO-Government of Alberta Fire Service)

## Feds Introduce ‘Just Transition’ Sustainable Jobs Act Aimed at Canada’s Energy Sector
 - [https://www.theepochtimes.com/feds-introduce-just-transition-sustainable-jobs-act-aimed-at-canadas-energy-sector_5337704.html](https://www.theepochtimes.com/feds-introduce-just-transition-sustainable-jobs-act-aimed-at-canadas-energy-sector_5337704.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 13:24:03+00:00

Minister of Natural Resources Jonathan Wilkinson rises during question period in the House of Commons on Parliament Hill in Ottawa on Feb. 14, 2023. (Patrick Doyle/The Canadian Press)

## LIVE 9:15 AM ET: Secretary of Defense Austin Holds Press Conference After NATO Meeting
 - [https://www.theepochtimes.com/secretary-of-defense-austin-holds-press-conference-after-nato-meeting_5336480.html](https://www.theepochtimes.com/secretary-of-defense-austin-holds-press-conference-after-nato-meeting_5336480.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 12:43:28+00:00

U.S. Defense Secretary Lloyd Austin speaks during the 155th National Memorial Day Observance at Arlington National Cemetery in Arlington, Va., on May 29, 2023. (Mandel Ngan/AFP via Getty Images)

## Climate Change a Factor in Unveiling of New Roadmap for Basin Review
 - [https://www.theepochtimes.com/climate-change-a-factor-into-unveiling-of-new-roadmap-for-basin-review_5337456.html](https://www.theepochtimes.com/climate-change-a-factor-into-unveiling-of-new-roadmap-for-basin-review_5337456.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 12:36:01+00:00

A veiw of the  Hume Weir at sunrise on February 23, 2007 in Albury, Australia.  (Photo by Robert Cianflone/Getty Images)

## Heavily Prescribed Influenza Medicine Doesn’t Work Well, Study Finds
 - [https://www.theepochtimes.com/health/heavily-prescribed-influenza-medicine-doesnt-work-well-study-finds_5335983.html](https://www.theepochtimes.com/health/heavily-prescribed-influenza-medicine-doesnt-work-well-study-finds_5335983.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 12:18:25+00:00

A package of Tamiflu in a file image. (Mario Tama/Getty Images)

## Government Admits it is Powerless to Stop Milly Dowler Killer Getting Married
 - [https://www.theepochtimes.com/government-admits-it-is-powerless-to-stop-milly-dowler-killer-getting-married_5337554.html](https://www.theepochtimes.com/government-admits-it-is-powerless-to-stop-milly-dowler-killer-getting-married_5337554.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 11:55:47+00:00

An undated image of Levi Bellfield, who was jailed for life for the rape and murder of schoolgirl Milly Dowler in Surrey, England in June 2011. (Metropolitan Police)

## Public Broadcaster’s Decision to Cut Political Editor Roundly Criticised
 - [https://www.theepochtimes.com/public-broadcasters-decision-to-cut-political-editor-roundly-criticised_5337315.html](https://www.theepochtimes.com/public-broadcasters-decision-to-cut-political-editor-roundly-criticised_5337315.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 11:34:55+00:00

The logo for Australia's public broadcaster ABC is seen on its head office building in Sydney, Australia, on Sept. 27, 2018. (Saeed Khan/AFP via Getty Images)

## Criticism Of Boris Johnson Conduct Divides Tory MPs
 - [https://www.theepochtimes.com/criticism-of-boris-johnson-conduct-divides-tory-mps_5337637.html](https://www.theepochtimes.com/criticism-of-boris-johnson-conduct-divides-tory-mps_5337637.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 11:24:46+00:00

Former Prime Minister Boris Johnson looks on during a tour after a meeting with Gov. Greg Abbott at the Texas State Capitol in Austin, Texas, on May 23, 2023. (Brandon Bell/Getty Images)

## IN-DEPTH: Victims Who Became ‘Asexual’ After Anti-Depressants Claim UK Authorities Are Ignoring Them
 - [https://www.theepochtimes.com/in-depth-victims-who-became-asexual-after-anti-depressants-claim-uk-authorities-are-ignoring-them_5332245.html](https://www.theepochtimes.com/in-depth-victims-who-became-asexual-after-anti-depressants-claim-uk-authorities-are-ignoring-them_5332245.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 10:59:40+00:00

A bottle of Effexor antidepressant pills in Miami, Fla., on March 23, 2004. (Joe Raedle/Getty Images)

## Taiwan Eases Restrictions on Canadian Beef Imports
 - [https://www.theepochtimes.com/taiwan-eases-restrictions-on-canadian-beef-imports_5337172.html](https://www.theepochtimes.com/taiwan-eases-restrictions-on-canadian-beef-imports_5337172.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 10:03:39+00:00

An undated file photo of cattle. (Martin Bureau/AFP/Getty Images)

## New Zealand Slips Into Technical Recession
 - [https://www.theepochtimes.com/new-zealand-slips-into-technical-recession_5337382.html](https://www.theepochtimes.com/new-zealand-slips-into-technical-recession_5337382.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 10:01:50+00:00

Pedestrians walk near the main entrance to the Reserve Bank of New Zealand located in central Wellington, New Zealand, on July 3, 2017. (David Gray/Reuters)

## Russian National Charged for Alleged Ransomware Extortion From US, Foreign Businesses
 - [https://www.theepochtimes.com/russian-national-charged-for-alleged-ransomware-extortion-from-us-foreign-businesses_5337415.html](https://www.theepochtimes.com/russian-national-charged-for-alleged-ransomware-extortion-from-us-foreign-businesses_5337415.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 09:48:08+00:00

A man types on a computer keyboard on Feb. 28, 2013. (Kacper Pempel/Reuters)

## Asteroid the Size of Brooklyn Bridge Labeled ‘Potentially Hazardous’ Passes by Earth
 - [https://www.theepochtimes.com/asteroid-the-size-of-brooklyn-bridge-labeled-potentially-hazardous-passes-by-earth_5337427.html](https://www.theepochtimes.com/asteroid-the-size-of-brooklyn-bridge-labeled-potentially-hazardous-passes-by-earth_5337427.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 08:55:31+00:00

The estimated orbit parameters of asteroid 2020 DB5. (NASA/JPL-Caltech /Screenshot via The Epoch Times)

## Qantas Reveals New A350 Cabin Design Including ‘Wellbeing Zone’
 - [https://www.theepochtimes.com/qantas-reveals-new-a350-cabin-design-including-wellbeing-zone_5337398.html](https://www.theepochtimes.com/qantas-reveals-new-a350-cabin-design-including-wellbeing-zone_5337398.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 08:17:58+00:00

Photo showing the Cabin of a Qantas QFA350 plane. (Courtesy of Qantas)

## Australian Energy Giant Sued for Allegedly Manipulating Electricity Prices
 - [https://www.theepochtimes.com/australian-energy-giant-sued-for-allegedly-manipulating-electricity-prices_5337438.html](https://www.theepochtimes.com/australian-energy-giant-sued-for-allegedly-manipulating-electricity-prices_5337438.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 08:02:01+00:00

AGL Power Station at Torrens Island in Adelaide, November 4, 2019. (AAP Image/Kelly Barnes)

## Australia Could End Up With Potentially Inferior US Fighter Jets
 - [https://www.theepochtimes.com/australia-could-end-up-with-potentially-inferior-us-fighter-jets_5335022.html](https://www.theepochtimes.com/australia-could-end-up-with-potentially-inferior-us-fighter-jets_5335022.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 07:54:34+00:00

A pilot assigned to the 61st Fighter Squadron and 61st Aircraft Maintenance Unit crew chiefs prepare an F-35A Lightning II for taxi, Jan. 15, 2019 at Luke Air Force Base, Ariz. Crew chiefs work with pilots to ensure the F-35 takes-off and lands safely. (U.S Air Force photo by Airman 1st Class Jacob Wongwai)

## Australia Reports Surprise Drop in Unemployment Rate in May
 - [https://www.theepochtimes.com/australia-reports-surprise-drop-in-unemployment-rate-in-may_5337281.html](https://www.theepochtimes.com/australia-reports-surprise-drop-in-unemployment-rate-in-may_5337281.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 06:32:15+00:00

Construction workers are seen in Sydney, Australia, on Dec. 1, 2021. (AAP Image/Bianca De Marchi)

## Researchers Identify the 5 Most Common ‘Words’ Newborn Babies Make
 - [https://www.theepochtimes.com/researchers-identify-the-5-most-common-words-newborn-babies-make_5334889.html](https://www.theepochtimes.com/researchers-identify-the-5-most-common-words-newborn-babies-make_5334889.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 05:42:58+00:00

An Australian decodes the main "words" that almost all babies say. (Jonathan Borba/Unsplash)

## Australia Cancels Russian Embassy’s Lease Near Parliament House
 - [https://www.theepochtimes.com/australia-cancels-russian-embassys-lease-near-parliament-house_5337162.html](https://www.theepochtimes.com/australia-cancels-russian-embassys-lease-near-parliament-house_5337162.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 05:13:56+00:00

The site of a planned new Russian embassy is seen in Canberra, on June 15, 2023. (AAP Image/Lukas Coch)

## Over 40 Australian Government Agencies Feared to Be Victims of Russian Cyber Attack
 - [https://www.theepochtimes.com/over-40-australian-government-agencies-feared-to-be-victims-of-russian-cyber-attack_5337259.html](https://www.theepochtimes.com/over-40-australian-government-agencies-feared-to-be-victims-of-russian-cyber-attack_5337259.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 04:58:49+00:00

(Darwin Laganzon/Pixabay)

## Former Conservative Leader Erin O’Toole Steps Into Top Role at Global Strategy Firm
 - [https://www.theepochtimes.com/former-conservative-leader-erin-otoole-steps-into-top-role-at-global-strategy-firm_5337348.html](https://www.theepochtimes.com/former-conservative-leader-erin-otoole-steps-into-top-role-at-global-strategy-firm_5337348.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 04:56:23+00:00

Conservative Leader Erin O'Toole speaks during a media availability in West Block on Parliament Hill in Ottawa, on Jan. 27, 2022. (The Canadian Press/Justin Tang)

## Minister Accuses Opponents of The Voice of ‘Trump Politics’
 - [https://www.theepochtimes.com/minister-accuses-opponents-of-the-voice-of-trump-politics_5337033.html](https://www.theepochtimes.com/minister-accuses-opponents-of-the-voice-of-trump-politics_5337033.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 04:37:25+00:00

Minister for Indigenous Australians Linda Burney and Assistant Minister for Indigenous Health Senator Malarndirri McCarthy announce new renal dialysis units for remote First Nations patients, Darwin, NT on April 13, 2022. (AAP Image/Annette Lin)

## British Actress Glenda Jackson, 2-time Oscar Winner Then Socialist Politician, Dies at 87
 - [https://www.theepochtimes.com/british-actress-glenda-jackson-2-time-oscar-winner-then-socialist-politician-dies-at-87-post_5335481.html](https://www.theepochtimes.com/british-actress-glenda-jackson-2-time-oscar-winner-then-socialist-politician-dies-at-87-post_5335481.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 03:53:42+00:00

Glenda Jackson accepts the award for Best Performance by an Actress in a Leading Role in a Play for "Edward Albee's Three Tall Women" in the 72nd Annual Tony Awards, New York on June 6, 2018. (Lucas Jackson/Reuters)

## Earthquake of Magnitude 7.2 Strikes Near Tonga
 - [https://www.theepochtimes.com/earthquake-of-magnitude-7-2-strikes-near-tonga_5336284.html](https://www.theepochtimes.com/earthquake-of-magnitude-7-2-strikes-near-tonga_5336284.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 03:16:18+00:00

A map shows the location of a magnitude 7.2 earthquake that struck near Tonga on June 15, 2023. (USGS/Screenshot via The Epoch Times)

## Romanian Prosecutors Change Human Trafficking Charge Against Andrew Tate
 - [https://www.theepochtimes.com/romanian-prosecutors-change-human-trafficking-charge-against-andrew-tate_5335113.html](https://www.theepochtimes.com/romanian-prosecutors-change-human-trafficking-charge-against-andrew-tate_5335113.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 02:43:59+00:00

Andrew Tate and Tristan Tate are escorted by police officers outside the headquarters of the Directorate for Investigating Organized Crime and Terrorism in Bucharest (DIICOT) after being detained for 24 hours, in Bucharest, Romania, on Dec. 29, 2022. (Inquam Photos/Octav Ganea via Reuters)

## American Arrested for Pushing 2 US Tourists Into Ravine at Germany’s Neuschwanstein Castle, Leaving One Woman Dead
 - [https://www.theepochtimes.com/american-arrested-for-pushing-2-us-tourists-into-ravine-at-germanys-neuschwanstein-castle-leaving-one-woman-dead_5337038.html](https://www.theepochtimes.com/american-arrested-for-pushing-2-us-tourists-into-ravine-at-germanys-neuschwanstein-castle-leaving-one-woman-dead_5337038.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 02:11:30+00:00

People watch the Neuschwanstein castle in Schwangau, Germany, on June 15, 2023. (Frank Rumpenhorst/dpa via AP)

## Dozens of Ottawa High School Students Stage Walkout to Protest Gender Ideology
 - [https://www.theepochtimes.com/dozens-of-ottawa-high-school-students-stage-walkout-to-protest-gender-ideology_5336335.html](https://www.theepochtimes.com/dozens-of-ottawa-high-school-students-stage-walkout-to-protest-gender-ideology_5336335.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 01:31:14+00:00

Dozens of students gather at Longfields-Davidson Heights Secondary School to protest against gender ideology in Ottawa on June 15, 2023. (Matthew Horwood/The Epoch Times)

## Indigenous Victorians in Custody Enrolled to Vote in First Nations Treaty Negotiations
 - [https://www.theepochtimes.com/indigenous-victorians-in-custody-enrolled-to-vote-in-first-nations-treaty-negotiations_5336984.html](https://www.theepochtimes.com/indigenous-victorians-in-custody-enrolled-to-vote-in-first-nations-treaty-negotiations_5336984.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 01:10:42+00:00

Ronald 'Ringo' Terrick, an elder the Wurundjeri tribe  sits on the steps of Parliment House during Sorry Day May 26, 2007 in Melbourne, Australia. (Simon Fergusson/Getty Images)

## Reviving Engagement With China ‘Counterproductive and Dangerous’: Rep. Gallagher
 - [https://www.theepochtimes.com/reviving-engagement-with-china-counterproductive-and-dangerous-rep-gallagher_5336880.html](https://www.theepochtimes.com/reviving-engagement-with-china-counterproductive-and-dangerous-rep-gallagher_5336880.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 00:21:04+00:00

Rep. Mike Gallagher (R-Wis) speaks at a press conference and rally in front of the America ChangLe Association highlighting Beijing's transnational repression, in New York City on Feb. 25, 2023. A now-closed overseas Chinese police station is located

## Public Service Union Says Recruitment of Government Staff Should be Re-Nationalised
 - [https://www.theepochtimes.com/public-service-union-says-recruitment-of-government-staff-should-be-re-nationalised_5332365.html](https://www.theepochtimes.com/public-service-union-says-recruitment-of-government-staff-should-be-re-nationalised_5332365.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-16 00:03:03+00:00

Prime Minister Anthony Albanese (centre) and ACTU President Michele O'Neil (4th left) take part in the 2021 Labour Day March in Brisbane, Australia, on May 3, 2021. (AAP Image/Dan Peled)

