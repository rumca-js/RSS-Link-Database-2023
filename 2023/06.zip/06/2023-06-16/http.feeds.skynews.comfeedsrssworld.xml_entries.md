# Source:Sky News, URL:http://feeds.skynews.com/feeds/rss/world.xml, language:en-US

## Narrow escape for village as huge rock slide stops just short of school building
 - [https://news.sky.com/story/narrow-escape-for-swiss-village-as-huge-rock-slide-stops-just-short-of-school-building-12903883](https://news.sky.com/story/narrow-escape-for-swiss-village-as-huge-rock-slide-stops-just-short-of-school-building-12903883)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-06-16 18:23:00+00:00

A Swiss village has survived being buried under a huge rock slide by the narrowest of margins.

## Survivors of Greece boat disaster 'swam for hours surrounded by children's bodies'
 - [https://news.sky.com/story/greece-migrant-boat-disaster-survivors-swam-for-hours-surrounded-by-childrens-bodies-12903761](https://news.sky.com/story/greece-migrant-boat-disaster-survivors-swam-for-hours-surrounded-by-childrens-bodies-12903761)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-06-16 15:45:00+00:00

Some of the stories now emerging from the boat disaster off Greece on Wednesday morning create a picture of unthinkably horrific conditions onboard.

## African leaders meet Zelenskyy in Ukraine peace mission - with Putin next
 - [https://news.sky.com/story/african-leaders-meet-volodymyr-zelenskyy-in-ukraine-peace-mission-with-vladimir-putin-next-12903755](https://news.sky.com/story/african-leaders-meet-volodymyr-zelenskyy-in-ukraine-peace-mission-with-vladimir-putin-next-12903755)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-06-16 15:37:00+00:00

South African president Cyril Ramaphosa is among a group of African leaders in Ukraine on a peace mission.

## 'Up to 500' missing after migrant boat sunk off Greek coast - including women and children
 - [https://news.sky.com/story/up-to-500-missing-after-migrant-boat-sunk-off-greek-coast-including-women-and-children-12903697](https://news.sky.com/story/up-to-500-missing-after-migrant-boat-sunk-off-greek-coast-including-women-and-children-12903697)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-06-16 13:58:00+00:00

Up to 500 people are missing after an overcrowded fishing boat carrying migrants capsized in the Mediterranean Sea, the United Nations has said.

## New Spider-Man film abruptly removed from cinema listings in more than a dozen Muslim-majority countries
 - [https://news.sky.com/story/spider-man-across-the-spider-verse-abruptly-removed-from-cinema-listings-in-more-than-a-dozen-muslim-majority-countries-12903671](https://news.sky.com/story/spider-man-across-the-spider-verse-abruptly-removed-from-cinema-listings-in-more-than-a-dozen-muslim-majority-countries-12903671)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-06-16 13:15:00+00:00

The new Spider-Man film has been abruptly removed from cinema listings in more than a dozen Muslim-majority countries.

## Cyclist, 26, dies after Tour de Suisse crash
 - [https://news.sky.com/story/gino-mader-cyclist-26-dies-after-crashing-into-ravine-during-tour-de-suisse-12903651](https://news.sky.com/story/gino-mader-cyclist-26-dies-after-crashing-into-ravine-during-tour-de-suisse-12903651)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-06-16 12:35:00+00:00

A professional cyclist has died after crashing during the Tour de Suisse - as a world champion criticised the decision to "let us finish down this dangerous decent".

## Bill Gates visit to China signals Beijing is open to a thaw in relations with US
 - [https://news.sky.com/story/bill-gates-visit-to-china-signals-beijing-is-open-to-a-thaw-in-relations-with-us-12903593](https://news.sky.com/story/bill-gates-visit-to-china-signals-beijing-is-open-to-a-thaw-in-relations-with-us-12903593)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-06-16 11:03:00+00:00

Bill Gates visited Beijing on Friday and was granted a rare meeting with President Xi Jinping.

## Survivor of migrant boat disaster has emotional reunion with brother
 - [https://news.sky.com/story/greece-migrant-boat-disaster-survivor-has-emotional-reunion-with-brother-12903592](https://news.sky.com/story/greece-migrant-boat-disaster-survivor-has-emotional-reunion-with-brother-12903592)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-06-16 11:00:00+00:00

An 18-year-old teenager who survived after a fishing boat carrying migrants sank off the coast of Greece has been pictured in an emotional reunion with his brother.

## Pope Francis leaves hospital after surgery
 - [https://news.sky.com/story/pope-francis-leaves-hospital-nine-days-after-surgery-12903459](https://news.sky.com/story/pope-francis-leaves-hospital-nine-days-after-surgery-12903459)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-06-16 07:02:00+00:00

Pope Francis has left hospital in Rome nine days after undergoing surgery for a hernia.

## Fifteen dead after bus and lorry collide in rural Canada
 - [https://news.sky.com/story/fifteen-dead-after-bus-and-lorry-collide-in-rural-canada-12903399](https://news.sky.com/story/fifteen-dead-after-bus-and-lorry-collide-in-rural-canada-12903399)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-06-16 00:19:00+00:00

A bus carrying mostly elderly people has collided with a lorry in a rural part of the Canadian province of Manitoba, killing 15 people and injuring 10 more, police have  said.

