# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Terrorist Caught At Southern Border
 - [https://www.youtube.com/watch?v=4kBy0OgjPWw](https://www.youtube.com/watch?v=4kBy0OgjPWw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2023-06-16 19:07:25+00:00

A Border Patrol agent catches a suspicious character trying to blend in with a group of Mexican migrants.

Watch the full video: https://youtu.be/YDDhTqDC9kc

#shorts

