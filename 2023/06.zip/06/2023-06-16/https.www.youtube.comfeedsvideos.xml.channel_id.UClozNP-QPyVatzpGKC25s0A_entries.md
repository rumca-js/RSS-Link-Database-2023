# Source:Brad Colbow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UClozNP-QPyVatzpGKC25s0A, language:en-US

## Lenovo Yoga Book i9 Review
 - [https://www.youtube.com/watch?v=6pT_ooV_riQ](https://www.youtube.com/watch?v=6pT_ooV_riQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UClozNP-QPyVatzpGKC25s0A
 - date published: 2023-06-16 13:00:05+00:00

https://bradsartschool.com - My new courses
Use code: bradsentme to get 25% off Learn to Draw in 60 Days.

Lenovo Yoga Book 9i (affiliate link) https://go.magik.ly/ml/1tutf/

What makes this laptop so unique is it's 2 screens. It's a cool gimmick but what makes it work here is the bluetooth keyboard that gives you a ton of flexibility.

Discounts for my Courses http://brad.site/learn/
Email Newsletter: http://brad.site/signup/

-----------------------------------------------------

Twitter: 
https://twitter.com/bradcolbow

Instagram:
https://www.instagram.com/bcolbow/

Drawing Tech Top 10 lists:
http://brad.site/

My Drawing and video gear: 
http://brad.site/mygear/

