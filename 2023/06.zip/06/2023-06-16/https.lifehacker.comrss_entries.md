# Source:Lifehacker, URL:https://lifehacker.com/rss, language:en-US

## TikTok Myth of the Week: Vibration Plates
 - [https://lifehacker.com/tiktok-myth-of-the-week-vibration-plates-1850548917](https://lifehacker.com/tiktok-myth-of-the-week-vibration-plates-1850548917)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-06-16 21:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--KF4mZOGK--/c_fit,fl_progressive,q_80,w_636/9bfa1eba9d0cb36488c6e75c58a2565e.jpg" /><p>Until this week, my only knowledge of the association between vibration and fitness came from old cartoons. Watch them long enough, and soon you’ll see somebody jiggling their butt or belly with a vibrating machine attached to a cloth belt on it. (<a href="https://www.youtube.com/watch?v=Iet33fqk9OE" rel="noopener noreferrer" target="_blank">You know the ones</a>.) They were supposed to somehow vibrate your fat…</p><p><a href="https://lifehacker.com/tiktok-myth-of-the-week-vibration-plates-1850548917">Read more...</a></p>

## What's New on Hulu in July 2023
 - [https://lifehacker.com/whats-new-on-hulu-in-july-2023-1850548738](https://lifehacker.com/whats-new-on-hulu-in-july-2023-1850548738)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-06-16 20:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--7_PUWgno--/c_fit,fl_progressive,q_80,w_636/11cee6f5f83cc45b4f4bfcd4d241fc6a.jpg" /><p>Has any television show produced as many series finales as <em>Futurama</em>? Matt Groening’s sci-fi followup to<em> The Simpsons</em> aired on Fox for four seasons from 1999-2003 before it was canceled for the first time (series finale #1). A few years later, it was revived as four feature-length movies that aired on Adult Swim from…</p><p><a href="https://lifehacker.com/whats-new-on-hulu-in-july-2023-1850548738">Read more...</a></p>

## Make Super Savory Carrot Fries in Your Air Fryer
 - [https://lifehacker.com/make-super-savory-carrot-fries-in-your-air-fryer-1850548742](https://lifehacker.com/make-super-savory-carrot-fries-in-your-air-fryer-1850548742)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-06-16 20:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--5RuF_QFd--/c_fit,fl_progressive,q_80,w_636/8c7eb81c6760f97567a4507273cfd80d.jpg" /><p>I have a bad habit of taking carrots for granted. They’re everywhere—in lunch boxes with hummus, alongside potatoes and pearl onions under pot roast, chopped or shredded in garden side salads at mid-range chain restaurants. Their ubiquity is a slight disadvantage: The carrot is often <em>included</em>, but rarely considered or…</p><p><a href="https://lifehacker.com/make-super-savory-carrot-fries-in-your-air-fryer-1850548742">Read more...</a></p>

## Three Things That Can Distort Your Blood Pressure Results
 - [https://lifehacker.com/three-things-that-can-distort-your-blood-pressure-resul-1850547887](https://lifehacker.com/three-things-that-can-distort-your-blood-pressure-resul-1850547887)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-06-16 19:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--Hs83m8cF--/c_fit,fl_progressive,q_80,w_636/9cde8efbff1671951443abfef634834b.jpg" /><p>Your blood pressure is a measurement of <a href="https://www.cdc.gov/bloodpressure/about.htm" rel="noopener noreferrer" target="_blank">the pressure your circulating blood is putting on the walls of your arteries</a>, and is expressed as two numbers: Your <em>systolic</em> pressure (the top number, so the “120&quot; in 120/70) is the force exerted on your arteries when your heart beats, and the <em>diastolic</em> pressure (the bottom…</p><p><a href="https://lifehacker.com/three-things-that-can-distort-your-blood-pressure-resul-1850547887">Read more...</a></p>

## When to Use a 'Functional' Resume Instead of a Traditional One
 - [https://lifehacker.com/when-to-use-a-functional-resume-instead-of-a-traditiona-1850548206](https://lifehacker.com/when-to-use-a-functional-resume-instead-of-a-traditiona-1850548206)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-06-16 19:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--avgSCbEO--/c_fit,fl_progressive,q_80,w_636/16fd202013697da1d2e33c579a1993a5.jpg" /><p>When you pull up a resume template, it’s pretty straightforward: Your past jobs are listed in reverse chronological order near the top, dating back about 10 years or so. But you may need a “functional” resume sometimes, even if templates for it are a little harder to find.<br /></p><p><a href="https://lifehacker.com/when-to-use-a-functional-resume-instead-of-a-traditiona-1850548206">Read more...</a></p>

## Use ChatGPT to Prepare for Your Next Job Interview
 - [https://lifehacker.com/use-chatgpt-to-prepare-for-your-next-job-interview-1850547294](https://lifehacker.com/use-chatgpt-to-prepare-for-your-next-job-interview-1850547294)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-06-16 18:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--vvFGl2el--/c_fit,fl_progressive,q_80,w_636/4f6fa56febfe45a1cbd8cbe7d69bbfc6.jpg" /><p>ChatGPT’s impact on our daily lives has likely been overhyped, but it <em>does</em> have some great uses. Students can <a href="https://lifehacker.com/four-of-the-best-ways-to-study-but-not-cheat-with-cha-1850419522" target="_blank">use it to study for tests</a>, for example. And if you’re interviewing for jobs, ChatGPT can help you prepare.<br /></p><p><a href="https://lifehacker.com/use-chatgpt-to-prepare-for-your-next-job-interview-1850547294">Read more...</a></p>

## Think Twice Before Cutting a Pill in Half
 - [https://lifehacker.com/think-twice-before-cutting-a-pill-in-half-1850547388](https://lifehacker.com/think-twice-before-cutting-a-pill-in-half-1850547388)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-06-16 17:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--gq-5JUKT--/c_fit,fl_progressive,q_80,w_636/f0e8ea7445070bcf79d958ef7ef2cbde.jpg" /><p>You may want to cut a pill in half—maybe because you need a smaller dose, are trying to save on prescription costs, or have trouble swallowing larger pills. Cutting pills <em>can</em> be safe and effective, but there are a number of guidelines to make sure that you’re getting an effective dosage with each split pill. As…</p><p><a href="https://lifehacker.com/think-twice-before-cutting-a-pill-in-half-1850547388">Read more...</a></p>

## 35 Netflix Originals You Probably Aren't Watching but Definitely Should Be
 - [https://lifehacker.com/25-netflix-original-shows-you-probably-arent-watching-b-1847429789](https://lifehacker.com/25-netflix-original-shows-you-probably-arent-watching-b-1847429789)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-06-16 17:01:24+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--b4R24xYu--/c_fit,fl_progressive,q_80,w_636/f75cfc4d7b18ac1169addc2b2ac9f944.png" /><p>Netflix has built a subscriber base more than 200 million strongon the backs of some great original TV series, and there’s a fair chance you’re watching (or have already binged) the biggies: <em>Stranger Things</em>, <em>Ozark</em>, <em>The Crown</em>, <em>The Night Agent</em>, <em>Bridgerton</em>, <em>The Witcher</em>, <em>Sandman</em>, <em>Lupin, Beef, Never Have I Ever, </em>etc. Even…</p><p><a href="https://lifehacker.com/25-netflix-original-shows-you-probably-arent-watching-b-1847429789">Read more...</a></p>

## Three Steps to Increase Your Chance of Getting a Raise
 - [https://lifehacker.com/three-steps-to-increase-your-chance-of-getting-a-raise-1850546691](https://lifehacker.com/three-steps-to-increase-your-chance-of-getting-a-raise-1850546691)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-06-16 16:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--1lVc5IGQ--/c_fit,fl_progressive,q_80,w_636/2834014f281cd7cdef4c8b0464746f0b.jpg" /><p>One of the most common career scenarios is feeling like you’re performing well and not being paid enough for it. Maybe you put in extra hours, volunteered for committees, or helped train others. Perhaps you shared new ideas that were implemented, making your company more efficient. It’s natural to think “I deserve a…</p><p><a href="https://lifehacker.com/three-steps-to-increase-your-chance-of-getting-a-raise-1850546691">Read more...</a></p>

## You Can Get a Lifetime Subscription to Rosetta Stone for Almost 40% Off
 - [https://lifehacker.com/you-can-get-a-lifetime-subscription-to-rosetta-stone-fo-1850541124](https://lifehacker.com/you-can-get-a-lifetime-subscription-to-rosetta-stone-fo-1850541124)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-06-16 16:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--UBDJ4n4_--/c_fit,fl_progressive,q_80,w_636/004080f120c1287c2fee296680facb56.jpg" /><p>Rosetta Stone offers beginner to advanced-level instruction for 25 different languages. And with a lifetime subscription (and, obviously, enough motivation), you can learn a new language at your own pace. Until June 20, you can <a href="https://shop.lifehacker.com/sales/rosetta-stone-lifetime-subscription-all-languages?utm_source=lifehacker.com&amp;utm_medium=referral&amp;utm_campaign=rosetta-stone-lifetime-subscription-all-languages&amp;utm_term=scsf-573141&amp;utm_content=a0x1P000004IoEfQAK&amp;scsonar=1">get a lifetime subscription to Rosetta Stone for $159.97</a> with coupon code <strong>VACATION15</strong>.</p><p><a href="https://lifehacker.com/you-can-get-a-lifetime-subscription-to-rosetta-stone-fo-1850541124">Read more...</a></p>

## How to Know If You’re the Toxic One in Your Relationship
 - [https://lifehacker.com/how-to-know-if-you-re-the-toxic-one-in-your-relationshi-1850546193](https://lifehacker.com/how-to-know-if-you-re-the-toxic-one-in-your-relationshi-1850546193)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-06-16 15:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--R3R_RV1h--/c_fit,fl_progressive,q_80,w_636/bdc5e56e890418b07c416edc54a44a8f.jpg" /><p>When you’re unhappy in your relationship, it’s easy to point the finger at your partner and accuse them of being toxic. But what if <em>you’re</em> the one who’s toxic? </p><p><a href="https://lifehacker.com/how-to-know-if-you-re-the-toxic-one-in-your-relationshi-1850546193">Read more...</a></p>

## 15 of the Best Video Game Remakes Ever Made
 - [https://lifehacker.com/15-video-game-remakes-that-actually-deserve-to-exist-1850545901](https://lifehacker.com/15-video-game-remakes-that-actually-deserve-to-exist-1850545901)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-06-16 15:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--1U7mXvrB--/c_fit,fl_progressive,q_80,w_636/ee19bfb2209c8266db1e49158fafdc2e.jpg" /><p>Going back to an old video game can be a great way to relax and recapture the feelings you had when you first played it. However, games take more effort to revisit than movies or books, and, sometimes, they don’t hold up to modern standards.</p><p><a href="https://lifehacker.com/15-video-game-remakes-that-actually-deserve-to-exist-1850545901">Read more...</a></p>

## Why You Should Stop Sending Checks in the Mail, Especially Now
 - [https://lifehacker.com/why-you-should-stop-sending-checks-in-the-mail-especia-1850543113](https://lifehacker.com/why-you-should-stop-sending-checks-in-the-mail-especia-1850543113)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-06-16 14:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--1MUxMjx2--/c_fit,fl_progressive,q_80,w_636/a856f4b35f56ab21997cfad9d5d16ec7.jpg" /><p>If you’re dropping checks in the mail to your landlord or utility provider, it’s time to look for a different way to pay your bills. Check fraud and mail theft <a href="https://apnews.com/article/check-fraud-banks-organized-crime-5f033b93bd87e2cbeb82b4ab4865a916" rel="noopener noreferrer" target="_blank">nearly doubled between 2021 and 2022</a>, affecting hundreds of thousands of Americans, according to reports from both the Financial Crimes Enforcement Network and…</p><p><a href="https://lifehacker.com/why-you-should-stop-sending-checks-in-the-mail-especia-1850543113">Read more...</a></p>

## This Air Purifier With an H13 HEPA Filter Is Over 50% Off Right Now
 - [https://lifehacker.com/this-air-purifier-with-an-h13-hepa-filter-is-over-50-o-1850541106](https://lifehacker.com/this-air-purifier-with-an-h13-hepa-filter-is-over-50-o-1850541106)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-06-16 14:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--dnkiVgIl--/c_fit,fl_progressive,q_80,w_636/6cf83e573c008239175d4416fd561024.jpg" /><p>The Wetie PM2.5 Air Purifier has a three-in-one H13 HEPA filter and can clean a large space with 360-degree air intake. If you’re concerned about pollen, smoke, or your general indoor air quality, you can <a href="https://shop.lifehacker.com/sales/wetie-pm2-5-air-purifier-with-hepa-filter?utm_source=lifehacker.com&amp;utm_medium=referral&amp;utm_campaign=wetie-pm2-5-air-purifier-with-hepa-filter&amp;utm_term=scsf-572782&amp;utm_content=a0x1P000004ImC8QAK&amp;scsonar=1">get a Wetie Air Purifier while they’re on sale for $129.99</a> (reg. $299) until June 18.<br /></p><p><a href="https://lifehacker.com/this-air-purifier-with-an-h13-hepa-filter-is-over-50-o-1850541106">Read more...</a></p>

## The Best Sex Positions When One of You Is Way Taller
 - [https://lifehacker.com/the-best-sex-positions-when-one-of-you-is-way-taller-1850545686](https://lifehacker.com/the-best-sex-positions-when-one-of-you-is-way-taller-1850545686)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-06-16 13:37:39+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--KNHpcaJH--/c_fit,fl_progressive,q_80,w_636/9c21ab32d762a2b2873ca5b809eb92fb.png" /><p>Sex can be awkward even when you’ve got everything going for you, but <a href="https://lifehacker.com/how-to-have-sex-when-one-of-you-is-significantly-taller-1729874737">throw in a significant height difference</a> between you and your partner and you might be facing some whole different level of misalignment. </p><p><a href="https://lifehacker.com/the-best-sex-positions-when-one-of-you-is-way-taller-1850545686">Read more...</a></p>

## The Out-of-Touch Adults' Guide to Kid Culture: Why Is Everyone Obsessed With Grimace?
 - [https://lifehacker.com/the-out-of-touch-adults-guide-to-kid-culture-why-is-ev-1850546375](https://lifehacker.com/the-out-of-touch-adults-guide-to-kid-culture-why-is-ev-1850546375)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-06-16 13:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--twV3H-6H--/c_fit,fl_progressive,q_80,w_636/422500d6a86ea7c290ab153861cd452b.jpg" /><p>This week, kids are eating rat snacks, staying off Reddit, considering their “canon events,” and finally asking important question about Grimace, McDonald’s inexplicable abomination of a mascot.<br /></p><p><a href="https://lifehacker.com/the-out-of-touch-adults-guide-to-kid-culture-why-is-ev-1850546375">Read more...</a></p>

## Koshō is the Citrusy Umami Bomb You’ll Want to Put on Everything
 - [https://lifehacker.com/kosho-is-the-citrusy-umami-bomb-you-ll-want-to-put-on-e-1850545472](https://lifehacker.com/kosho-is-the-citrusy-umami-bomb-you-ll-want-to-put-on-e-1850545472)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-06-16 12:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--1b9DJRjm--/c_fit,fl_progressive,q_80,w_636/168b003d66f9820f6b2a9767b33090f7.jpg" /><p>Yuzu koshō is like sunlight on your tongue. A fermented paste of yuzu, chilies and salt, it brings the umami, but with a brightness you only get from fresh citrus. Some foodie friends and I noticed it in a soy dipping sauce at dinner in New York. It was a completely new and unique taste none of us had experienced…</p><p><a href="https://lifehacker.com/kosho-is-the-citrusy-umami-bomb-you-ll-want-to-put-on-e-1850545472">Read more...</a></p>

## Orzo Is the Pasta of the Summer
 - [https://lifehacker.com/orzo-is-the-pasta-of-the-summer-1850544500](https://lifehacker.com/orzo-is-the-pasta-of-the-summer-1850544500)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-06-16 12:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--zzKrJBWO--/c_fit,fl_progressive,q_80,w_636/0543d9db83b65102d9157c8389e30d26.jpg" /><p>We don’t celebrate orzo enough, but its adorable, small size and shape makes it hardly feel like pasta. It can trick you into believing it’s a grain, or chewy kind of rice, which is fairly benign as far as treachery goes. Don’t think about it too much and just enjoy it.<br /></p><p><a href="https://lifehacker.com/orzo-is-the-pasta-of-the-summer-1850544500">Read more...</a></p>

