# Source:Gizmodo, URL:https://gizmodo.com/rss, language:en-US

## Stellan Skarsgård Explains the Intensity of Filming His Iconic Andor Speech
 - [https://gizmodo.com/luthen-rael-speech-star-wars-andor-stellen-skarsgard-1850549511](https://gizmodo.com/luthen-rael-speech-star-wars-andor-stellen-skarsgard-1850549511)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-16 23:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--iepJ3IPh--/c_fit,fl_progressive,q_80,w_636/be1d52db223558bc42d91112201d1d8f.jpg" /><p>“Calm. Kindness, kinship. Love. I’ve given up all chance at inner peace, I’ve made my mind a sunless space. I share my dreams with ghosts. I wake up every day to an equation I wrote 15 years ago from which there’s only one conclusion: I’m damned for what I do.”</p><p><a href="https://gizmodo.com/luthen-rael-speech-star-wars-andor-stellen-skarsgard-1850549511">Read more...</a></p>

## Emily Blunt Wants That Edge of Tomorrow Sequel Just as Much as We Do
 - [https://gizmodo.com/emily-blunt-wants-edge-of-tomorrow-sequel-tom-cruise-1850549116](https://gizmodo.com/emily-blunt-wants-edge-of-tomorrow-sequel-tom-cruise-1850549116)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-16 22:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--yXODFWVg--/c_fit,fl_progressive,q_80,w_636/34685073d0ae9559da25107e838fe920.jpg" /><p>Emily Blunt has no shortage of gigs—the star of <a href="https://gizmodo.com/jungle-cruise-movie-review-1847368774"><em>Jungle Cruise</em></a>, <em>Mary Poppins Returns</em>, and the first two <em>Quiet Place</em> movies, to name just a few, is currently doing the pre-Emmy nomination rounds for her BBC-Prime Video series <em>The English</em>. But there’s one project many sci-fi fans have been hoping to see: <a href="https://gizmodo.com/the-edge-of-tomorrow-sequel-is-finally-officially-movi-1832992432">that much-teased</a> <a href="https://gizmodo.com/edge-of-tomorrow-is-the-movie-other-action-movies-wish-1586935483"><em></em>…</a></p><p><a href="https://gizmodo.com/emily-blunt-wants-edge-of-tomorrow-sequel-tom-cruise-1850549116">Read more...</a></p>

## This Amazing Star Trek Box Set's Answer to 'How Much Captain Picard Do You Want?' Is 'Yes'
 - [https://gizmodo.com/star-trek-picard-legacy-collection-patrick-stewart-1850548967](https://gizmodo.com/star-trek-picard-legacy-collection-patrick-stewart-1850548967)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-16 22:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--2HLoRSn3--/c_fit,fl_progressive,q_80,w_636/62c61a3eecedd485422bda5d4615d8be.jpg" /><p>From <em>TNG</em> to <em>Picard</em>, Jean-Luc has <a href="https://gizmodo.com/why-we-will-always-love-the-humble-heroism-of-captain-p-1835528332">had a hell of a ride</a> in the <em>Star Trek</em> galaxy—and now, an overwhelming majority of it is going to find itself bundled all into one pricey, but glorious package.</p><p><a href="https://gizmodo.com/star-trek-picard-legacy-collection-patrick-stewart-1850548967">Read more...</a></p>

## How Did Star Wars Outlaws Make a Droid So Hot?
 - [https://gizmodo.com/star-wars-outlaw-ubisoft-hot-droid-video-game-1850545405](https://gizmodo.com/star-wars-outlaw-ubisoft-hot-droid-video-game-1850545405)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-16 21:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--bB3s-jRh--/c_fit,fl_progressive,q_80,w_636/f41b2281e53ca30f38235aeae0eeadcd.jpg" /><p>Earlier this week Ubisoft dazzled  gamers with a surprise <a href="https://gizmodo.com/new-star-wars-game-outlaws-ubisoft-empire-jedi-ps5-xbox-1850529635">fully fledged look at <em>Outlaws</em></a>, its upcoming open-world <a href="https://gizmodo.com/lucasfilms-big-bet-on-star-wars-games-is-the-chance-to-1846050285">action adventure <em>Star Wars</em> game</a>. In what we’ve seen so far, <em>Outlaws</em> wants to play with <em>Star Wars</em> in ways other recent games maybe haven’t so much—an <a href="https://gizmodo.com/star-wars-outlaws-setting-timeline-ubisoft-1850535922">intriguing mid-Trilogy setting</a>, a smuggler protagonist…</p><p><a href="https://gizmodo.com/star-wars-outlaw-ubisoft-hot-droid-video-game-1850545405">Read more...</a></p>

## How Bluesky Is Seizing the Opportunity of Twitter's Decline With Custom Algorithms
 - [https://gizmodo.com/bluesky-engineer-q-a-twitter-alterative-innovation-1850547030](https://gizmodo.com/bluesky-engineer-q-a-twitter-alterative-innovation-1850547030)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-16 20:40:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--TP3zL_Vm--/c_fit,fl_progressive,q_80,w_636/272f05ec357e7e9c1c6c14c69ad261b6.png" /><p>Twitter is in freefall—ad revenue is down more than half since last year, owner Elon Musk is mucking around and firing people left and right, and users (including me) have noticed a steep decline in the quality of their feeds. <a href="https://gizmodo.com/bluesky-invite-jack-dorsey-twitter-coding-livestream-1850451102">Bluesky</a>, a near-clone of Twitter built on a decentralized protocol with the support of…</p><p><a href="https://gizmodo.com/bluesky-engineer-q-a-twitter-alterative-innovation-1850547030">Read more...</a></p>

## Pixar's Leader Talks Balancing Originals and Sequels
 - [https://gizmodo.com/new-pixar-movies-inside-out-2-toy-story-5-elemental-dis-1850548513](https://gizmodo.com/new-pixar-movies-inside-out-2-toy-story-5-elemental-dis-1850548513)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-16 20:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--H2rYQqam--/c_fit,fl_progressive,q_80,w_636/8f5e3831c78621266dbbe0390b6ef28a.jpg" /><p>After years of <a href="https://gizmodo.com/all-the-pixar-movies-ranked-1820549981">being damn near perfect</a>, Pixar has entered a whole new phase. Its past few releases have <a href="https://gizmodo.com/lightyear-box-office-toy-story-pixar-disney-pete-docter-1850140804">failed to live up to</a> the company’s impossible standard, and more and more animation studios seem to have caught up to Pixar in terms of <a href="https://gizmodo.com/pixar-elemental-animated-fire-water-creative-interviews-1850441580">innovation and story</a>. This week, Pixar’s latest film, <a href="https://gizmodo.com/movie-review-pixar-elemental-animation-peter-sohn-1850530272"><em>Elemental</em></a><em>,</em> hits theaters,…</p><p><a href="https://gizmodo.com/new-pixar-movies-inside-out-2-toy-story-5-elemental-dis-1850548513">Read more...</a></p>

## Pediatricians Warn Weighted Baby Sleep Sack May Cause SIDS
 - [https://gizmodo.com/pediatricians-say-weighted-baby-sleep-sack-is-dangerous-1850548848](https://gizmodo.com/pediatricians-say-weighted-baby-sleep-sack-is-dangerous-1850548848)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-16 20:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--PoqBlV-V--/c_fit,fl_progressive,q_80,w_636/44e4f780f928e3c3ee5cdfe844409bbe.jpg" /><p>Doctors are warning parents against buying the baby sleep sack, a weighted swaddle blanket designed for infants. In a major public service announcement, pediatricians say the blanket, which is meant to mimic the sensation of “being held or hugged” could turn deadly.</p><p><a href="https://gizmodo.com/pediatricians-say-weighted-baby-sleep-sack-is-dangerous-1850548848">Read more...</a></p>

## The FTC Is Rewriting the Rules of the Internet, Just in Time for the AI Sea Change
 - [https://gizmodo.com/ftc-complaint-ai-rewriting-privacy-rules-interview-1850545756](https://gizmodo.com/ftc-complaint-ai-rewriting-privacy-rules-interview-1850545756)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-16 19:57:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--PRY5_4_i--/c_fit,fl_progressive,q_80,w_636/53ea4b78957ce1175252f6f184d57063.jpg" /><p>There’s a widespread misconception about whether or not federal law protects your privacy. It doesn’t, at least not explicitly. Congress has managed to squander a decade’s worth of bipartisan agreement about the internet’s data problems. In the absence of legislation, one group of regulators recently stepped in to…</p><p><a href="https://gizmodo.com/ftc-complaint-ai-rewriting-privacy-rules-interview-1850545756">Read more...</a></p>

## On-Orbit Satellite Servicing, New Crew Capsules and Artificial Gravity: NASA's Latest Tech Initiative
 - [https://gizmodo.com/blue-origin-develop-crew-capsule-nasa-tech-initiative-1850548311](https://gizmodo.com/blue-origin-develop-crew-capsule-nasa-tech-initiative-1850548311)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-16 19:50:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--R1kGsP7K--/c_fit,fl_progressive,q_80,w_636/a79d598ba7c49843745e17336dbb1cb3.jpg" /><p>A new Blue Origin crewed spacecraft is in the works as part of a NASA collaboration designed to advance the orbital economy, with the space agency lending its expertise to seven different commercial partners.  </p><p><a href="https://gizmodo.com/blue-origin-develop-crew-capsule-nasa-tech-initiative-1850548311">Read more...</a></p>

## Turtle Power with Star Trek's Melissa Navia | First Fandoms
 - [https://gizmodo.com/turtle-power-with-melissa-navia-first-fandoms-1850546876](https://gizmodo.com/turtle-power-with-melissa-navia-first-fandoms-1850546876)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-16 19:45:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--OVcFO7so--/c_fit,fl_progressive,q_80,w_636/87abeca2bffb3e6d1afb7e90e14ba126.jpg" /><p><a href="https://gizmodo.com/turtle-power-with-melissa-navia-first-fandoms-1850546876">Read more...</a></p>

## El Niño Is Here and It's Taking the Heat for the Death of 300 Wild Birds in Mexico
 - [https://gizmodo.com/el-nino-death-of-300-wild-birds-in-mexico-1850548032](https://gizmodo.com/el-nino-death-of-300-wild-birds-in-mexico-1850548032)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-16 19:40:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--wXpilz3D--/c_fit,fl_progressive,q_80,w_636/cd35f9b19824e9414d40516be8332b06.jpg" /><p>El Niño is here and bringing record temperatures this June. As of this month, the global shift has officially arrived and is “expected to gradually strengthen into the Northern Hemisphere winter 2023-24,” <a href="https://www.cpc.ncep.noaa.gov/products/analysis_monitoring/enso_advisory/ensodisc.shtml" rel="noopener noreferrer" target="_blank">according</a> to a recent announcement from NOAA.</p><p><a href="https://gizmodo.com/el-nino-death-of-300-wild-birds-in-mexico-1850548032">Read more...</a></p>

## UPS Drivers Officially Vote to Authorize a Strike
 - [https://gizmodo.com/ups-drivers-officially-vote-to-authorize-a-strike-1850548199](https://gizmodo.com/ups-drivers-officially-vote-to-authorize-a-strike-1850548199)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-16 19:10:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--48MGTgEq--/c_fit,fl_progressive,q_80,w_636/82dc62cd4fab7de4d44beb31549ec25f.jpg" /><p><a href="https://gizmodo.com/ups-drivers-ac-trucks-contract-strike-union-1850538236">Shortly after officially receiving air conditioning and heat regulation in trucks</a>, UPS drivers have officially voted to go on strike. 97% of drivers in the Teamsters Union voted in favor of the motion.<br /></p><p><a href="https://gizmodo.com/ups-drivers-officially-vote-to-authorize-a-strike-1850548199">Read more...</a></p>

## Watch Margot Robbie Guide You Around the Gorgeous Artificiality of Barbie's Dreamhouse
 - [https://gizmodo.com/barbie-movie-dreamhouse-set-tour-margot-robbie-mattel-1850548479](https://gizmodo.com/barbie-movie-dreamhouse-set-tour-margot-robbie-mattel-1850548479)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-16 19:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--2U6uUc2O--/c_fit,fl_progressive,q_80,w_636/e14fa94641b79d416daeafe07d9aa96a.png" /><p>Part of what has made Greta Gerwig’s <em>Barbie</em> movie look immediately enchanting, aside from <a href="https://gizmodo.com/new-barbie-trailer-margot-robbie-ryan-gosling-gerwig-1850475228">pretty much everything</a>, is how its design has embraced the <a href="https://gizmodo.com/barbie-car-corvette-margot-robbie-mattel-warner-bros-1850541306">retro-classic camp</a> of Barbie’s chintzy aesthetic—nothing in Barbie’s world in the movie feels <em>real</em>, and yet Barbie and her fellow Barbies (and <a href="https://gizmodo.com/ryan-gosling-ken-barbie-movie-margot-robbie-gerwig-1850490717">the occasional Ken</a>) have to…</p><p><a href="https://gizmodo.com/barbie-movie-dreamhouse-set-tour-margot-robbie-mattel-1850548479">Read more...</a></p>

## 8 Things We Liked (and 2 We Didn't) About Black Mirror Season 6
 - [https://gizmodo.com/black-mirror-s6-review-netflix-salma-hayek-aaron-paul-1850538907](https://gizmodo.com/black-mirror-s6-review-netflix-salma-hayek-aaron-paul-1850538907)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-16 18:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--APRWq5N6--/c_fit,fl_progressive,q_80,w_636/6f6749bb12ca871e8c2b6bc3fcd416b7.jpg" /><p><a href="https://gizmodo.com/black-mirror-netflix-s6-trailer-release-date-ben-barnes-1850489212"><em>Black Mirror</em> is back</a>! On June 15, Netflix dropped <a href="https://gizmodo.com/black-mirror-season-6-cast-aaron-paul-zazie-beetz-1849173031">the five-episode sixth season</a> of <a href="https://gizmodo.com/black-mirror-season-6-chatgpt-writers-strike-ai-1850513967">Charlie Brooker</a>’s dystopian anthology series, bringing a new batch of stories that examine humanity’s deepest fears about... well, mostly about ourselves this time around, though <a href="https://gizmodo.com/netflix-black-mirror-best-tech-and-ai-cautionary-tales-1850515657"><em>Black Mirror</em>’s fondness for tech themes</a> is still in…</p><p><a href="https://gizmodo.com/black-mirror-s6-review-netflix-salma-hayek-aaron-paul-1850538907">Read more...</a></p>

## Meta to Help People Craft More Zuck Deepfakes With ‘Voicebox’ AI
 - [https://gizmodo.com/meta-help-people-craft-more-deepfakes-with-voicebox-a-1850548158](https://gizmodo.com/meta-help-people-craft-more-deepfakes-with-voicebox-a-1850548158)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-16 18:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--XjmsLso---/c_fit,fl_progressive,q_80,w_636/745d1465b0029c93b5d64fd23dd0de48.jpg" /><p>Meta has another new AI model on the docket, and this one seems perfectly engineered for the land of tomorrow if that utopian future is filled with nothing but deepfakes and modified audio. Like AI image generators, Voicebox generates synthetic voices based on a simple text prompt from scratch—or, in actuality—sound…</p><p><a href="https://gizmodo.com/meta-help-people-craft-more-deepfakes-with-voicebox-a-1850548158">Read more...</a></p>

## Spider-Man: Across the Spider-Verse Banned in UAE, Probably Because of a Poster
 - [https://gizmodo.com/spiderman-across-spider-verse-uae-ban-protect-trans-kid-1850547764](https://gizmodo.com/spiderman-across-spider-verse-uae-ban-protect-trans-kid-1850547764)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-16 17:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--x_mEMhGC--/c_fit,fl_progressive,q_80,w_636/ddcc4eded47b43edc78d4f4d5605ceca.jpg" /><p>One of the many, many things that rule about <a href="https://gizmodo.com/spiderman-across-spider-verse-review-marvel-sony-animat-1850490027"><em>Spider-Man: Across the Spider-Verse</em></a> is how diverse and inclusive it is. People of every size, shape, color, gender, and more fill every frame of the film, and while most people would s<a href="https://gizmodo.com/spider-man-across-spider-verse-box-office-weekend-1850504686">ee that as a positive thing</a>, at least one place does not.<br /></p><p><a href="https://gizmodo.com/spiderman-across-spider-verse-uae-ban-protect-trans-kid-1850547764">Read more...</a></p>

## Jamal Khashoggi's Widow Says Notorious Spyware Left Her 'Irrevocably Altered'
 - [https://gizmodo.com/jamal-khashoggi-widow-sues-nso-pegasus-spyware-1850547915](https://gizmodo.com/jamal-khashoggi-widow-sues-nso-pegasus-spyware-1850547915)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-16 17:02:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--A-3J__cP--/c_fit,fl_progressive,q_80,w_636/5090bf723f710de1ce74cf029afaf73a.png" /><p>The <a href="https://gizmodo.com/nso-spyware-was-used-to-target-jamal-khashoggis-wife-d-1848251552">widow of Jamal Khashoggi</a>—a Saudi journalist brutally executed by intelligence agents for writing critically about the regime—is suing the <a href="https://gizmodo.com/the-fbi-reportedly-came-very-close-to-deploying-spyware-1849778042">NSO Group</a>, an Israeli surveillance company allegedly responsible for creating malicious spyware surreptitiously installed on her and her late husband’s devices. Hanan Elatr…</p><p><a href="https://gizmodo.com/jamal-khashoggi-widow-sues-nso-pegasus-spyware-1850547915">Read more...</a></p>

## Wrap Yourself Up in a Classic Apple OS While Your Brain Turns to Mush With a Modern One
 - [https://gizmodo.com/apple-blanket-macintosh-throwboy-mac-os-1850547961](https://gizmodo.com/apple-blanket-macintosh-throwboy-mac-os-1850547961)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-16 16:51:45+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--7po2Ez7P--/c_fit,fl_progressive,q_80,w_636/a0164aa70b46cec50ccd543f5461d596.jpg" /><p>Next year marks the 40th anniversary of what’s now considered the second most momentous on-stage reveal by Steve Jobs (after 2007's iPhone debut): the Apple Macintosh. You can get a head start on the festivities with Throwboy’s new blanket featuring a <a href="https://throwboy.com/collections/blankets/products/classic-desktop-knit-cotton-blanket" rel="noopener noreferrer" target="_blank">design that pays homage</a> to several different iterations of the…</p><p><a href="https://gizmodo.com/apple-blanket-macintosh-throwboy-mac-os-1850547961">Read more...</a></p>

## Let's Talk About the Ending and End Credits of The Flash
 - [https://gizmodo.com/flash-ending-credits-explained-dc-films-batman-spoilers-1850535187](https://gizmodo.com/flash-ending-credits-explained-dc-films-batman-spoilers-1850535187)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-16 16:45:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--qxCpI9eJ--/c_fit,fl_progressive,q_80,w_636/06b9249765e50e3024cf1861c1da1974.jpg" /><p>I almost can’t believe I’m typing this next sentence but here goes. <a href="https://gizmodo.com/flash-movie-review-ezra-miller-batman-superman-keaton-1850479834"><em>The Flash</em> is now in theaters</a>. Yes, after years of <a href="https://gizmodo.com/a-not-so-brief-history-of-the-flash-movie-which-is-now-1846714842">delays, scripts, and different filmmakers</a> attempting to tackle the project, Ezra Miller is finally starring as the DC speedster in a theater near you. And we think the movie was worth the wait,…</p><p><a href="https://gizmodo.com/flash-ending-credits-explained-dc-films-batman-spoilers-1850535187">Read more...</a></p>

## Star Trek: Infinite Really Does Just Look Like the Ultimate Stellaris Mod
 - [https://gizmodo.com/star-trek-infinite-gameplay-trailer-details-stellaris-1850547815](https://gizmodo.com/star-trek-infinite-gameplay-trailer-details-stellaris-1850547815)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-16 16:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--LfYrX_hu--/c_fit,fl_progressive,q_80,w_636/d7b157dfae9a30cd21cd9f5e9d8ca4a8.jpg" /><p><em>Stellaris</em> has long had a history of rich and deep total conversion mods, fan-made overhauls that let players take one of the most successful space strategy games of recent history and turn it into everything from <em>Warhammer</em> to <em>Star Wars</em>. <em>Trek</em> mods are no stranger to it either, but now they have new competition: an <a href="https://gizmodo.com/star-trek-resurgence-review-pc-xbox-playstation-1850459723">…</a></p><p><a href="https://gizmodo.com/star-trek-infinite-gameplay-trailer-details-stellaris-1850547815">Read more...</a></p>

## Slightly Lost Bumblebees Use Scent to Find Their Way Home
 - [https://gizmodo.com/slightly-lost-bumblebees-scent-find-way-home-1850547665](https://gizmodo.com/slightly-lost-bumblebees-scent-find-way-home-1850547665)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-16 15:55:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--gafVmOz6--/c_fit,fl_progressive,q_80,w_636/5181cb95d932491fd20a477b5211dcae.jpg" /><p>Researchers have shown that returning foragers of buﬀ-tailed bumblebees use their own passively laid out scent marks, as well as visual information from landmarks, to find their way back to the nest entrance. These results highlight the importance of both vision and odor for guiding the navigation of bumblebees.<br /></p><p><a href="https://gizmodo.com/slightly-lost-bumblebees-scent-find-way-home-1850547665">Read more...</a></p>

## Leaked Renders Show the Samsung Galaxy Z Fold 5 and Flip 5 Finally Shut Flat
 - [https://gizmodo.com/samsung-galaxy-z-fold-5-flip-5-pics-leak-hinge-flat-1850547467](https://gizmodo.com/samsung-galaxy-z-fold-5-flip-5-pics-leak-hinge-flat-1850547467)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-16 15:53:02+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--1976jI4O--/c_fit,fl_progressive,q_80,w_636/4acba190d8155f2f438b028b88a2102c.jpg" /><p>Samsung Unpacked is coming up in a jiffy this July, which means it’s the time of the year for leaked renders to start making their way to the interwebs. The latest leaked renders of the upcoming Galaxy Z Fold 5 and Flip 5 show that it will likely maintain much of the <a href="https://gizmodo.com/samsung-galaxy-z-fold-4-review-price-positive-worth-it-1849449228">same design as the previous year’s iteration</a>, only…</p><p><a href="https://gizmodo.com/samsung-galaxy-z-fold-5-flip-5-pics-leak-hinge-flat-1850547467">Read more...</a></p>

## Virgin Galactic Is Ready to Kick Off Its Commercial Trips to the Edge of Space
 - [https://gizmodo.com/richard-branson-virgin-galactic-commercial-spaceflight-1850547185](https://gizmodo.com/richard-branson-virgin-galactic-commercial-spaceflight-1850547185)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-16 15:40:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--q9obp8dV--/c_fit,fl_progressive,q_80,w_636/691cdc089c6a61b449bda4b48d4f145a.jpg" /><p>Virgin Galactic is officially open for suborbital business. The private space venture is set to launch its first commercial flight in late June, the first in a series of trips to the edge of space.</p><p><a href="https://gizmodo.com/richard-branson-virgin-galactic-commercial-spaceflight-1850547185">Read more...</a></p>

## Some of the Biggest Subreddits Are Retreating From the API War
 - [https://gizmodo.com/subreddits-retreat-api-war-as-ceo-steve-huffman-demands-1850546883](https://gizmodo.com/subreddits-retreat-api-war-as-ceo-steve-huffman-demands-1850546883)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-16 15:34:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--nx3z-ew---/c_fit,fl_progressive,q_80,w_636/92f5d44120570cbb264ccc8242eb09d8.jpg" /><p>In the ongoing civil war between Reddit and its own users, the <a href="https://gizmodo.com/reddits-blackout-api-changes-protest-ceo-going-dark-1850528573">widespread two-day subreddit shutdown protest has come and gone</a>. While some communities have pledged to keep the protest going indefinitely, some of the largest channels have given in while Reddit CEO <a href="https://gizmodo.com/reddit-ceo-steve-huffman-moderators-landed-gentry-1850546737">Steve Huffman throws gas</a> on a smoldering fire.<br /></p><p><a href="https://gizmodo.com/subreddits-retreat-api-war-as-ceo-steve-huffman-demands-1850546883">Read more...</a></p>

## Mortal Kombat 2 Has Found Some of Its Biggest Bads
 - [https://gizmodo.com/mortal-kombat-2-casting-shao-kahn-sindel-quan-chi-1850544791](https://gizmodo.com/mortal-kombat-2-casting-shao-kahn-sindel-quan-chi-1850544791)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-16 14:10:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--ZogKXAw9--/c_fit,fl_progressive,q_80,w_636/e9c4efafa5db866e61ad19559ed9a27a.png" /><p>Check out a veritable smorgasbord of <em>Barbie</em> clips. <em>Doctor Who</em> adds another young hero to its cast. Netflix sets a date for its <em>Chicken Run</em> sequel. Plus, Mads Mikkelsen discusses the chances of ever coming back to <em>Hannibal</em>, and some major <em>Superman &amp; Lois</em> cast shakeups are on the way. To me, my spoilers!<br /></p><p><a href="https://gizmodo.com/mortal-kombat-2-casting-shao-kahn-sindel-quan-chi-1850544791">Read more...</a></p>

## Google Sells Its Databank of More Than 10 Million Domain Names to Squarespace
 - [https://gizmodo.com/google-sells-10-million-domain-names-to-squarespace-1850546969](https://gizmodo.com/google-sells-10-million-domain-names-to-squarespace-1850546969)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-16 13:55:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--M86GmVBv--/c_fit,fl_progressive,q_80,w_636/efe0d15479ec0fb7715eaad18f2af2ce.jpg" /><p>For once, the tech conglomerate that is Google is getting smaller, and by its own volition no less. Google said it is extricating itself from the domain name business. Its massive bank of domain names and the millions of customers who pay for them will soon be placed in the hands of  Squarespace. The webpage creation…</p><p><a href="https://gizmodo.com/google-sells-10-million-domain-names-to-squarespace-1850546969">Read more...</a></p>

## Asthma ER Visits Shot Up in NYC When Wildfire Smoke Choked the Northeast
 - [https://gizmodo.com/asthma-er-visits-increased-in-nyc-amid-wildfire-smoke-1850545235](https://gizmodo.com/asthma-er-visits-increased-in-nyc-amid-wildfire-smoke-1850545235)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-16 13:40:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--42T2qdHm--/c_fit,fl_progressive,q_80,w_636/188c4eac02dfa408e2281c60b3ec5cc4.jpg" /><p>Canadian wildfire <a href="https://gizmodo.com/health-expert-tips-for-dealing-with-wildfire-smoke-1850520976">smoke hunger over the Eastern U.S.</a> and throughout the Midwest last week. It darkened skies over multiple major cities, including New York City. The unhealthy air quality also increased the number of asthma-related emergency room visits throughout the city.</p><p><a href="https://gizmodo.com/asthma-er-visits-increased-in-nyc-amid-wildfire-smoke-1850545235">Read more...</a></p>

## Reddit CEO Flames Protesting Moderators, Calls Them ‘Landed Gentry’
 - [https://gizmodo.com/reddit-ceo-steve-huffman-moderators-landed-gentry-1850546737](https://gizmodo.com/reddit-ceo-steve-huffman-moderators-landed-gentry-1850546737)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-16 12:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--oefAMc2U--/c_fit,fl_progressive,q_80,w_636/b8268ecbf26294e60c3dceddc9660dcc.png" /><p>Reddit CEO Steve Huffman slammed subreddit moderators who continued to push back against the company’s plan to charge for access to its API, a change that would shutter beloved third-party Reddit apps like Apollo, calling them “landed gentry” and saying they weren’t considering the desires of their communities.</p><p><a href="https://gizmodo.com/reddit-ceo-steve-huffman-moderators-landed-gentry-1850546737">Read more...</a></p>

## Parler Is Dead, but Trump Is Still Using Its Newsletter to Raise Cash and Own the Libs
 - [https://gizmodo.com/donald-trump-still-using-parler-email-list-1850543570](https://gizmodo.com/donald-trump-still-using-parler-email-list-1850543570)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-16 11:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--APVdmvc4--/c_fit,fl_progressive,q_80,w_636/89684c62694cff520c1c80210377317d.jpg" /><p>Former users of <a href="https://gizmodo.com/disgruntled-employees-want-to-recreate-original-parler-1850362018">Parler</a>, the defunct right-wing social media app, got an email from Donald Trump on Tuesday.<br /></p><p><a href="https://gizmodo.com/donald-trump-still-using-parler-email-list-1850543570">Read more...</a></p>

## The New Batman Movie Sets Flash Director
 - [https://gizmodo.com/new-batman-movie-director-andy-muschietti-brave-bold-1850546065](https://gizmodo.com/new-batman-movie-director-andy-muschietti-brave-bold-1850546065)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-16 01:40:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--NuvZyGuc--/c_fit,fl_progressive,q_80,w_636/91ac12b7a886d9b9381a702aab57d60a.jpg" /><p>He’s directed a movie with multiple Batmen in it so surely he can handle just one. That’s what Warner Bros. thinks, at least, as it just signed up Andy Muschietti, director of <em>The Flash</em>, to helm one of the biggest movies of its upcoming DC slate, <em>The Brave and the Bold</em> featuring Batman and Robin.</p><p><a href="https://gizmodo.com/new-batman-movie-director-andy-muschietti-brave-bold-1850546065">Read more...</a></p>

## The Legacy of Leah Chase, the Inspiration Behind The Princess and the Frog's Tiana
 - [https://gizmodo.com/tianas-bayou-adventure-leah-chase-disney-parks-nola-1850541225](https://gizmodo.com/tianas-bayou-adventure-leah-chase-disney-parks-nola-1850541225)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-16 00:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--Pnn3mLNu--/c_fit,fl_progressive,q_80,w_636/b7866f489e5f64041e9978823b2f0f41.jpg" /><p>Tiana’s Palace, revealed as the dream-come-true restaurant at the end of Disney’s <em>The Princess and the Frog,</em> actually exists. In New Orleans, African American cuisine pioneer and community builder Leah Chase—Disney’s real-life inspiration for Tiana—ran Dooky Chase’s with her family, leaving a lasting legacy that has …</p><p><a href="https://gizmodo.com/tianas-bayou-adventure-leah-chase-disney-parks-nola-1850541225">Read more...</a></p>

