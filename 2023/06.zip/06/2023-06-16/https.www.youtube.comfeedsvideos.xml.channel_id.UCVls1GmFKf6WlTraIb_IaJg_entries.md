# Source:DistroTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCVls1GmFKf6WlTraIb_IaJg, language:en-US

## Managing AppImages Is Easy With "AM" Application Manager
 - [https://www.youtube.com/watch?v=7SfDlR3vU3I](https://www.youtube.com/watch?v=7SfDlR3vU3I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCVls1GmFKf6WlTraIb_IaJg
 - date published: 2023-06-16 13:00:03+00:00

"AM" (Application Manager) is a script able to install, update and remove thousands of standalone programs (mostly AppImages but also the official versions of Firefox, Thunderbird, Brave, etc).  AM not only installs the AppImage, it also creates the desktop file, adds a link in /usr/local/bin, and downloads the source files to /opt. 

REFERENCED:
► https://github.com/ivan-hc/AM-Application-Manager
► https://portable-linux-apps.github.io/apps.html

WANT TO SUPPORT THE CHANNEL? 
💰 Patreon: https://www.patreon.com/distrotube 
💳 Paypal: https://www.youtube.com/redirect?event=channel_banner&amp;redir_token=QUFFLUhqazNocEhiaGFBT1l1MnRHbnlIcHFKbXJWVnpQd3xBQ3Jtc0tsLVZJc19YeFlwZ2JqbXVOa3g0Skw4TVhTV2otNm1tM3A1bUNnamh3S2V6OGQtLTBnSjBxYTlvUXMxeEVIS3o4US10NENHMUQ3STk2a01FOFBhUnZjZFctMEhFUTg1TVctQmFfVUdxZXJ4TDl0azlYNA&amp;q=https%3A%2F%2Fwww.paypal.com%2Fcgi-bin%2Fwebscr%3Fcmd%3D_donations%26business%3Dderek%2540distrotube%252ecom%26lc%3DUS%26item_name%3DDistroTube%26no_note%3D0%26currency_code%3DUSD%26bn%3DPP%252dDonationsBF%253abtn_donateCC_LG%252egif%253aNonHostedGuest
🛍️ Amazon: https://amzn.to/2RotFFi
👕 Teespring: https://teespring.com/stores/distrotube

DONATE CRYPTO:
💰 Bitcoin: 1Mp6ebz5bNcjNFW7XWHVht36SkiLoxPKoX
🐶 Dogecoin: D5fpRD1JRoBFPDXSBocRTp8W9uKzfwLFAu
📕 LBC: bMfA2c3zmcLxPCpyPcrykLvMhZ7A5mQuhJ

DT ON THE WEB:
🕸️ Website: http://distrotube.com/
📁 GitLab: https://gitlab.com/dwt1  
🗨️ Mastodon: https://fosstodon.org/@distrotube
👫 Reddit: https://www.reddit.com/r/DistroTube/
📽️ LBRY/Odysee: https://odysee.com/@DistroTube:2

FREE AND OPEN SOURCE SOFTWARE THAT I USE:
🌐 Brave Browser - https://brave.com/dis872 
📽️ Open Broadcaster Software: https://obsproject.com/
🎬 Kdenlive: https://kdenlive.org
🎨 GIMP: https://www.gimp.org/
🎵 Tenacity: https://github.com/tenacityteam/tenacity
💻 VirtualBox: https://www.virtualbox.org/
🗒️ Doom Emacs: https://github.com/hlissner/doom-emacs

Your support is very much appreciated. Thanks, guys!

