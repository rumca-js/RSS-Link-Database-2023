# Source:Hacker News - frontpage, URL:https://hnrss.org/frontpage, language:en-US

## De-Dollarization Facts
 - [https://www.de-dollarization.org](https://www.de-dollarization.org)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 22:42:26+00:00

<p>Article URL: <a href="https://www.de-dollarization.org">https://www.de-dollarization.org</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36364967">https://news.ycombinator.com/item?id=36364967</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## Judging LLM-as-a-Judge with MT-Bench and Chatbot Arena
 - [https://twitter.com/lmsysorg/status/1669779889275408385](https://twitter.com/lmsysorg/status/1669779889275408385)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 21:02:35+00:00

<p>Article URL: <a href="https://twitter.com/lmsysorg/status/1669779889275408385">https://twitter.com/lmsysorg/status/1669779889275408385</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36363818">https://news.ycombinator.com/item?id=36363818</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## GMP servers are under DoS attack from Microsoft[-owned IP addresses]
 - [https://gmplib.org/list-archives/gmp-devel/2023-June/006161.html](https://gmplib.org/list-archives/gmp-devel/2023-June/006161.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 20:26:33+00:00

<p>Article URL: <a href="https://gmplib.org/list-archives/gmp-devel/2023-June/006161.html">https://gmplib.org/list-archives/gmp-devel/2023-June/006161.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36363327">https://news.ycombinator.com/item?id=36363327</a></p>
<p>Points: 8</p>
<p># Comments: 3</p>

## Apple subreddit reopens after moderation team threatened with removal
 - [https://appleinsider.com/articles/23/06/16/apple-subreddit-reopens-after-entire-moderation-team-was-threatened-with-removal](https://appleinsider.com/articles/23/06/16/apple-subreddit-reopens-after-entire-moderation-team-was-threatened-with-removal)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 20:15:15+00:00

<p>Article URL: <a href="https://appleinsider.com/articles/23/06/16/apple-subreddit-reopens-after-entire-moderation-team-was-threatened-with-removal">https://appleinsider.com/articles/23/06/16/apple-subreddit-reopens-after-entire-moderation-team-was-threatened-with-removal</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36363192">https://news.ycombinator.com/item?id=36363192</a></p>
<p>Points: 70</p>
<p># Comments: 21</p>

## Miraheze to Shut Down
 - [https://meta.miraheze.org/wiki/Board/Policies/20230615-Statement](https://meta.miraheze.org/wiki/Board/Policies/20230615-Statement)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 19:33:17+00:00

<p>Article URL: <a href="https://meta.miraheze.org/wiki/Board/Policies/20230615-Statement">https://meta.miraheze.org/wiki/Board/Policies/20230615-Statement</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36362547">https://news.ycombinator.com/item?id=36362547</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## Why did Nix introduce Flakes?
 - [https://www.jetpack.io/blog/why-did-nix-adopt-flakes/](https://www.jetpack.io/blog/why-did-nix-adopt-flakes/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 19:12:14+00:00

<p>Article URL: <a href="https://www.jetpack.io/blog/why-did-nix-adopt-flakes/">https://www.jetpack.io/blog/why-did-nix-adopt-flakes/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36362225">https://news.ycombinator.com/item?id=36362225</a></p>
<p>Points: 12</p>
<p># Comments: 10</p>

## Daniel Ellsberg has died
 - [https://www.nytimes.com/2023/06/16/us/daniel-ellsberg-dead.html](https://www.nytimes.com/2023/06/16/us/daniel-ellsberg-dead.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 19:01:47+00:00

<p>Article URL: <a href="https://www.nytimes.com/2023/06/16/us/daniel-ellsberg-dead.html">https://www.nytimes.com/2023/06/16/us/daniel-ellsberg-dead.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36362042">https://news.ycombinator.com/item?id=36362042</a></p>
<p>Points: 148</p>
<p># Comments: 44</p>

## Deep Learning’s Diminishing Returns (2021)
 - [https://spectrum.ieee.org/deep-learning-computational-cost](https://spectrum.ieee.org/deep-learning-computational-cost)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 18:54:44+00:00

<p>Article URL: <a href="https://spectrum.ieee.org/deep-learning-computational-cost">https://spectrum.ieee.org/deep-learning-computational-cost</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36361906">https://news.ycombinator.com/item?id=36361906</a></p>
<p>Points: 17</p>
<p># Comments: 7</p>

## Show HN: Discuit – A Reddit alternative with a clean UI and a sensible vision
 - [https://discuit.net/](https://discuit.net/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 18:33:14+00:00

<p>Hi HN, this is a platform (Discuit, pronounced "diskette") I've been working on for about two years. I initially built it for a niche demographic (my native country). But now with Reddit going dark and people looking for a new place to migrate to, I'm doing a quick launch today.<p>A few quick things:<p>1. I don't believe federated platforms will ever become mainstream. They have a whole host of problems, not the least of which is that they're too complicated for most people to use. This platform is not, therefore, federated.<p>2. I don't know what the best way of monetizing a thing like this is. I see only two options: the Wikipedia model of running on donations, or being advertising supported (along with a paid ad-free tier). The Wikipedia model works quite well for small-scale and bandwidth light projects, but I don't think a large social media platform can ever be funded that way.<p>3. Whichever option of monetization I take (if this takes off, that is) what I can say with certainty is that this will not go down the path of previous platforms. I don't believe the SV grow-fast model has worked very well for the end users. I have no interest in chasing growth for its own sake, or in chasing valuations, or in capturing as much attention from the users as possible. On this platform, therefore, there <i>never</i> will be any dark UI patterns. Avoiding enshittification is a primary goal of mine.<p>4. My vision for this platform, and for social media in general, is about giving users agency; the freedom to choose their social experience to their liking. What this would mean in practice are things like: ability to customize the UI; ability to filter content as one wants; ability to tweak recommendation algorithms; ability to turn on and off things like infinite scroll and suggested posts; and so on. I hate how all the current platforms want to tightly control my experience for me.<p>I go into all this in a bit more detail in my introductory blog post: <a href="https://discuit.substack.com/p/introducing-discuit" rel="nofollow noreferrer">https://discuit.substack.com/p/introducing-discuit</a><p>I know many HN users hate the New Reddit layout, which is what I've based this site on, but don't be bothered by it too much, I will be adding a much more compact layout sometime later.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36361527">https://news.ycombinator.com/item?id=36361527</a></p>
<p>Points: 31</p>
<p># Comments: 41</p>

## European Union votes to bring back replaceable phone batteries
 - [https://www.techspot.com/news/99102-european-union-votes-bring-back-replaceable-phone-batteries.html](https://www.techspot.com/news/99102-european-union-votes-bring-back-replaceable-phone-batteries.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 18:32:06+00:00

<p>Article URL: <a href="https://www.techspot.com/news/99102-european-union-votes-bring-back-replaceable-phone-batteries.html">https://www.techspot.com/news/99102-european-union-votes-bring-back-replaceable-phone-batteries.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36361510">https://news.ycombinator.com/item?id=36361510</a></p>
<p>Points: 165</p>
<p># Comments: 203</p>

## Techmeme now links to Hacker News threads and other “Forums” under its headlines
 - [https://techmeme.com/](https://techmeme.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 18:20:17+00:00

<p>Article URL: <a href="https://techmeme.com/">https://techmeme.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36361283">https://news.ycombinator.com/item?id=36361283</a></p>
<p>Points: 12</p>
<p># Comments: 3</p>

## Statistical correlation between earthquakes and cosmic radiation
 - [https://press.ifj.edu.pl/en/news/2023/06/14/](https://press.ifj.edu.pl/en/news/2023/06/14/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 18:13:03+00:00

<p>Article URL: <a href="https://press.ifj.edu.pl/en/news/2023/06/14/">https://press.ifj.edu.pl/en/news/2023/06/14/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36361162">https://news.ycombinator.com/item?id=36361162</a></p>
<p>Points: 4</p>
<p># Comments: 1</p>

## John Carmack on shorter work weeks (2016)
 - [https://news.ycombinator.com/item?id=10845832](https://news.ycombinator.com/item?id=10845832)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 18:02:31+00:00

<p>Article URL: <a href="https://news.ycombinator.com/item?id=10845832">https://news.ycombinator.com/item?id=10845832</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36360980">https://news.ycombinator.com/item?id=36360980</a></p>
<p>Points: 17</p>
<p># Comments: 14</p>

## Show HN: I made an open-source Notion-style WYSYWIG editor
 - [https://novel.sh/](https://novel.sh/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 17:49:38+00:00

<p>Article URL: <a href="https://novel.sh/">https://novel.sh/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36360789">https://news.ycombinator.com/item?id=36360789</a></p>
<p>Points: 45</p>
<p># Comments: 8</p>

## Meta's plan to offer free commercial AI models puts pressure on Google, OpenAI
 - [https://www.artisana.ai/articles/metas-plan-to-offer-free-commercial-ai-models-puts-pressure-on-google-and](https://www.artisana.ai/articles/metas-plan-to-offer-free-commercial-ai-models-puts-pressure-on-google-and)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 17:26:18+00:00

<p>Article URL: <a href="https://www.artisana.ai/articles/metas-plan-to-offer-free-commercial-ai-models-puts-pressure-on-google-and">https://www.artisana.ai/articles/metas-plan-to-offer-free-commercial-ai-models-puts-pressure-on-google-and</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36360452">https://news.ycombinator.com/item?id=36360452</a></p>
<p>Points: 65</p>
<p># Comments: 21</p>

## Tech vendors have been hiking prices by up to 24% amid inflation
 - [https://www.theregister.com/2023/06/16/tech_vendor_price_hikes/](https://www.theregister.com/2023/06/16/tech_vendor_price_hikes/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 17:02:59+00:00

<p>Article URL: <a href="https://www.theregister.com/2023/06/16/tech_vendor_price_hikes/">https://www.theregister.com/2023/06/16/tech_vendor_price_hikes/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36360035">https://news.ycombinator.com/item?id=36360035</a></p>
<p>Points: 11</p>
<p># Comments: 3</p>

## Gyroflow: An open source advanced gyro-based video stabilization tool
 - [http://gyroflow.xyz/](http://gyroflow.xyz/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 17:01:36+00:00

<p>Article URL: <a href="http://gyroflow.xyz/">http://gyroflow.xyz/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36360018">https://news.ycombinator.com/item?id=36360018</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Hexyl: A command-line hex viewer with colorized output
 - [https://github.com/sharkdp/hexyl](https://github.com/sharkdp/hexyl)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 16:56:21+00:00

<p>Article URL: <a href="https://github.com/sharkdp/hexyl">https://github.com/sharkdp/hexyl</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36359925">https://news.ycombinator.com/item?id=36359925</a></p>
<p>Points: 39</p>
<p># Comments: 5</p>

## Bits about Money Requiem for a bank loan
 - [https://www.bitsaboutmoney.com/archive/requiem-for-a-bank-loan/](https://www.bitsaboutmoney.com/archive/requiem-for-a-bank-loan/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 16:49:56+00:00

<p>Article URL: <a href="https://www.bitsaboutmoney.com/archive/requiem-for-a-bank-loan/">https://www.bitsaboutmoney.com/archive/requiem-for-a-bank-loan/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36359798">https://news.ycombinator.com/item?id=36359798</a></p>
<p>Points: 14</p>
<p># Comments: 1</p>

## 100 Days of Swift – Hacking with Swift
 - [https://www.hackingwithswift.com/100](https://www.hackingwithswift.com/100)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 16:43:26+00:00

<p>Article URL: <a href="https://www.hackingwithswift.com/100">https://www.hackingwithswift.com/100</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36359652">https://news.ycombinator.com/item?id=36359652</a></p>
<p>Points: 15</p>
<p># Comments: 2</p>

## 100 Days of SwiftUI
 - [https://www.hackingwithswift.com/100/swiftui](https://www.hackingwithswift.com/100/swiftui)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 16:43:26+00:00

<p>Article URL: <a href="https://www.hackingwithswift.com/100/swiftui">https://www.hackingwithswift.com/100/swiftui</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36359652">https://news.ycombinator.com/item?id=36359652</a></p>
<p>Points: 44</p>
<p># Comments: 14</p>

## Writing a chat application in Django 4.2 using async StreamingHttpResponse
 - [https://valberg.dk/django-sse-postgresql-listen-notify.html](https://valberg.dk/django-sse-postgresql-listen-notify.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 16:28:40+00:00

<p>Article URL: <a href="https://valberg.dk/django-sse-postgresql-listen-notify.html">https://valberg.dk/django-sse-postgresql-listen-notify.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36359376">https://news.ycombinator.com/item?id=36359376</a></p>
<p>Points: 21</p>
<p># Comments: 3</p>

## Illinois prohibits weapons, facial recognition on police drones
 - [https://ilga.gov/legislation/fulltext.asp?DocName=&SessionId=112&GA=103&DocTypeId=HB&DocNum=3902&GAID=17&LegID=149171&SpecSess=&Session=](https://ilga.gov/legislation/fulltext.asp?DocName=&SessionId=112&GA=103&DocTypeId=HB&DocNum=3902&GAID=17&LegID=149171&SpecSess=&Session=)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 16:24:20+00:00

<p>Article URL: <a href="https://ilga.gov/legislation/fulltext.asp?DocName=&amp;SessionId=112&amp;GA=103&amp;DocTypeId=HB&amp;DocNum=3902&amp;GAID=17&amp;LegID=149171&amp;SpecSess=&amp;Session=">https://ilga.gov/legislation/fulltext.asp?DocName=&amp;SessionId=112&amp;GA=103&amp;DocTypeId=HB&amp;DocNum=3902&amp;GAID=17&amp;LegID=149171&amp;SpecSess=&amp;Session=</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36359296">https://news.ycombinator.com/item?id=36359296</a></p>
<p>Points: 136</p>
<p># Comments: 43</p>

## Product Lessons from Dan Robinson (Ex-CTO of Heap)
 - [https://johnjianwang.medium.com/product-lessons-from-dan-robinson-ex-cto-of-heap-329a00cd6248](https://johnjianwang.medium.com/product-lessons-from-dan-robinson-ex-cto-of-heap-329a00cd6248)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 16:15:15+00:00

<p>Article URL: <a href="https://johnjianwang.medium.com/product-lessons-from-dan-robinson-ex-cto-of-heap-329a00cd6248">https://johnjianwang.medium.com/product-lessons-from-dan-robinson-ex-cto-of-heap-329a00cd6248</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36359119">https://news.ycombinator.com/item?id=36359119</a></p>
<p>Points: 23</p>
<p># Comments: 1</p>

## Pricing Money: A Beginner's Guide to Money, Bonds, Futures and Swaps
 - [http://www.jdawiseman.com/books/pricing-money/Pricing_Money_JDAWiseman.html](http://www.jdawiseman.com/books/pricing-money/Pricing_Money_JDAWiseman.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 15:54:25+00:00

<p>Article URL: <a href="http://www.jdawiseman.com/books/pricing-money/Pricing_Money_JDAWiseman.html">http://www.jdawiseman.com/books/pricing-money/Pricing_Money_JDAWiseman.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36358754">https://news.ycombinator.com/item?id=36358754</a></p>
<p>Points: 20</p>
<p># Comments: 8</p>

## Surges of cosmic radiation from space directly linked to earthquakes
 - [https://www.earth.com/news/breakthrough-surges-of-cosmic-radiation-from-space-directly-linked-to-earthquakes/](https://www.earth.com/news/breakthrough-surges-of-cosmic-radiation-from-space-directly-linked-to-earthquakes/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 15:49:34+00:00

<p>Article URL: <a href="https://www.earth.com/news/breakthrough-surges-of-cosmic-radiation-from-space-directly-linked-to-earthquakes/">https://www.earth.com/news/breakthrough-surges-of-cosmic-radiation-from-space-directly-linked-to-earthquakes/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36358672">https://news.ycombinator.com/item?id=36358672</a></p>
<p>Points: 17</p>
<p># Comments: 4</p>

## Charles Schwab facing internal meltdown after C-level abruptly reverses on RTO
 - [https://old.reddit.com/r/Schwab/comments/14add4y/rto/](https://old.reddit.com/r/Schwab/comments/14add4y/rto/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 15:46:15+00:00

<p>Article URL: <a href="https://old.reddit.com/r/Schwab/comments/14add4y/rto/">https://old.reddit.com/r/Schwab/comments/14add4y/rto/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36358601">https://news.ycombinator.com/item?id=36358601</a></p>
<p>Points: 8</p>
<p># Comments: 4</p>

## Reddit App – Suspicious high number of recent 5 star, one word reviews
 - [https://old.reddit.com/r/Save3rdPartyApps/comments/14at885/the_reddit_app_has_a_suspiciously_high_number_of/](https://old.reddit.com/r/Save3rdPartyApps/comments/14at885/the_reddit_app_has_a_suspiciously_high_number_of/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 15:35:50+00:00

<p>Article URL: <a href="https://old.reddit.com/r/Save3rdPartyApps/comments/14at885/the_reddit_app_has_a_suspiciously_high_number_of/">https://old.reddit.com/r/Save3rdPartyApps/comments/14at885/the_reddit_app_has_a_suspiciously_high_number_of/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36358408">https://news.ycombinator.com/item?id=36358408</a></p>
<p>Points: 213</p>
<p># Comments: 84</p>

## The new US border wall is an app
 - [https://www.technologyreview.com/2023/06/16/1074039/border-wall-app/](https://www.technologyreview.com/2023/06/16/1074039/border-wall-app/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 15:04:48+00:00

<p>Article URL: <a href="https://www.technologyreview.com/2023/06/16/1074039/border-wall-app/">https://www.technologyreview.com/2023/06/16/1074039/border-wall-app/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36357804">https://news.ycombinator.com/item?id=36357804</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## Free unlimited storage, store your files in pi – pi File System
 - [https://github.com/philipl/pifs](https://github.com/philipl/pifs)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 14:49:10+00:00

<p>Article URL: <a href="https://github.com/philipl/pifs">https://github.com/philipl/pifs</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36357466">https://news.ycombinator.com/item?id=36357466</a></p>
<p>Points: 6</p>
<p># Comments: 1</p>

## NHTSA tells automakers not to comply with Massachusetts right-to-repair law
 - [https://www.autoblog.com/2023/06/14/u-s-tells-automakers-not-to-comply-with-massachusetts-independent-repairs-law/](https://www.autoblog.com/2023/06/14/u-s-tells-automakers-not-to-comply-with-massachusetts-independent-repairs-law/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 14:46:40+00:00

<p>Article URL: <a href="https://www.autoblog.com/2023/06/14/u-s-tells-automakers-not-to-comply-with-massachusetts-independent-repairs-law/">https://www.autoblog.com/2023/06/14/u-s-tells-automakers-not-to-comply-with-massachusetts-independent-repairs-law/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36357415">https://news.ycombinator.com/item?id=36357415</a></p>
<p>Points: 26</p>
<p># Comments: 10</p>

## Reddit CEO Says Mods Too Powerful, Plans to Weaken After Blackout
 - [https://www.businessinsider.com/reddit-ceo-will-change-rules-to-make-mods-less-powerful-2023-6](https://www.businessinsider.com/reddit-ceo-will-change-rules-to-make-mods-less-powerful-2023-6)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 14:19:14+00:00

<p>Article URL: <a href="https://www.businessinsider.com/reddit-ceo-will-change-rules-to-make-mods-less-powerful-2023-6">https://www.businessinsider.com/reddit-ceo-will-change-rules-to-make-mods-less-powerful-2023-6</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36356957">https://news.ycombinator.com/item?id=36356957</a></p>
<p>Points: 115</p>
<p># Comments: 101</p>

## Full Time
 - [https://www.marginalia.nu/log/83_full_time/](https://www.marginalia.nu/log/83_full_time/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 14:13:03+00:00

<p>Article URL: <a href="https://www.marginalia.nu/log/83_full_time/">https://www.marginalia.nu/log/83_full_time/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36356876">https://news.ycombinator.com/item?id=36356876</a></p>
<p>Points: 98</p>
<p># Comments: 11</p>

## AI is going to eat itself: Experiment shows people training bots are using bots
 - [https://www.theregister.com/2023/06/16/crowd_workers_bots_ai_training/](https://www.theregister.com/2023/06/16/crowd_workers_bots_ai_training/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 13:49:13+00:00

<p>Article URL: <a href="https://www.theregister.com/2023/06/16/crowd_workers_bots_ai_training/">https://www.theregister.com/2023/06/16/crowd_workers_bots_ai_training/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36356547">https://news.ycombinator.com/item?id=36356547</a></p>
<p>Points: 66</p>
<p># Comments: 41</p>

## Finland's plan to bury spent nuclear fuel for 100k years
 - [https://www.bbc.com/future/article/20230613-onkalo-has-finland-found-the-answer-to-spent-nuclear-fuel-waste-by-burying-it](https://www.bbc.com/future/article/20230613-onkalo-has-finland-found-the-answer-to-spent-nuclear-fuel-waste-by-burying-it)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 13:31:13+00:00

<p>Article URL: <a href="https://www.bbc.com/future/article/20230613-onkalo-has-finland-found-the-answer-to-spent-nuclear-fuel-waste-by-burying-it">https://www.bbc.com/future/article/20230613-onkalo-has-finland-found-the-answer-to-spent-nuclear-fuel-waste-by-burying-it</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36356288">https://news.ycombinator.com/item?id=36356288</a></p>
<p>Points: 49</p>
<p># Comments: 82</p>

## The Riddle of the Well-Paying, Pointless Job (2019)
 - [https://moretothat.com/pointless-job/](https://moretothat.com/pointless-job/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 12:59:54+00:00

<p>Article URL: <a href="https://moretothat.com/pointless-job/">https://moretothat.com/pointless-job/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36355820">https://news.ycombinator.com/item?id=36355820</a></p>
<p>Points: 11</p>
<p># Comments: 0</p>

## Illinois Hospital First to Shut Down After Ransomware Attack
 - [https://www.techdirt.com/2023/06/16/illinois-hospital-first-to-shut-down-completely-after-ransomware-attack/](https://www.techdirt.com/2023/06/16/illinois-hospital-first-to-shut-down-completely-after-ransomware-attack/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 12:37:02+00:00

<p>Article URL: <a href="https://www.techdirt.com/2023/06/16/illinois-hospital-first-to-shut-down-completely-after-ransomware-attack/">https://www.techdirt.com/2023/06/16/illinois-hospital-first-to-shut-down-completely-after-ransomware-attack/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36355551">https://news.ycombinator.com/item?id=36355551</a></p>
<p>Points: 22</p>
<p># Comments: 7</p>

## What I Learned from Two Years of Teaching High School CS
 - [https://blog.charliemeyer.co/what-i-learned-from-two-years-of-teaching-high-school-cs/](https://blog.charliemeyer.co/what-i-learned-from-two-years-of-teaching-high-school-cs/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 12:06:30+00:00

<p>Article URL: <a href="https://blog.charliemeyer.co/what-i-learned-from-two-years-of-teaching-high-school-cs/">https://blog.charliemeyer.co/what-i-learned-from-two-years-of-teaching-high-school-cs/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36355172">https://news.ycombinator.com/item?id=36355172</a></p>
<p>Points: 11</p>
<p># Comments: 0</p>

## Provision (YC S22) Is Hiring a Founding Engineer (Front End)
 - [https://www.notion.so/provision-software/Provision-is-Hiring-8b53cc10bbd04af39bf3d3c7ab181cac?pvs=4](https://www.notion.so/provision-software/Provision-is-Hiring-8b53cc10bbd04af39bf3d3c7ab181cac?pvs=4)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 12:00:34+00:00

<p>Article URL: <a href="https://www.notion.so/provision-software/Provision-is-Hiring-8b53cc10bbd04af39bf3d3c7ab181cac?pvs=4">https://www.notion.so/provision-software/Provision-is-Hiring-8b53cc10bbd04af39bf3d3c7ab181cac?pvs=4</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36355103">https://news.ycombinator.com/item?id=36355103</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

## Building a New Database Management System in Academia
 - [http://www.cs.cmu.edu/~pavlo/blog/2017/03/building-a-new-database-management-system-in-academia.html](http://www.cs.cmu.edu/~pavlo/blog/2017/03/building-a-new-database-management-system-in-academia.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 11:50:50+00:00

<p>Article URL: <a href="http://www.cs.cmu.edu/~pavlo/blog/2017/03/building-a-new-database-management-system-in-academia.html">http://www.cs.cmu.edu/~pavlo/blog/2017/03/building-a-new-database-management-system-in-academia.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36354981">https://news.ycombinator.com/item?id=36354981</a></p>
<p>Points: 10</p>
<p># Comments: 0</p>

## Reddit appears to be restoring edited/deleted comments
 - [https://kbin.social/m/RedditMigration/t/34112/Heads-up-Reddit-is-quietly-restoring-deleted-AND-overwritten-posts-and](https://kbin.social/m/RedditMigration/t/34112/Heads-up-Reddit-is-quietly-restoring-deleted-AND-overwritten-posts-and)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 11:36:40+00:00

<p>Article URL: <a href="https://kbin.social/m/RedditMigration/t/34112/Heads-up-Reddit-is-quietly-restoring-deleted-AND-overwritten-posts-and">https://kbin.social/m/RedditMigration/t/34112/Heads-up-Reddit-is-quietly-restoring-deleted-AND-overwritten-posts-and</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36354850">https://news.ycombinator.com/item?id=36354850</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## PhpBB
 - [https://www.phpbb.com](https://www.phpbb.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 11:00:55+00:00

<p>Article URL: <a href="https://www.phpbb.com">https://www.phpbb.com</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36354540">https://news.ycombinator.com/item?id=36354540</a></p>
<p>Points: 21</p>
<p># Comments: 3</p>

## Stop Calling Each New Disaster “The New Normal”
 - [https://thewalrus.ca/stop-calling-each-new-disaster-the-new-normal/](https://thewalrus.ca/stop-calling-each-new-disaster-the-new-normal/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 10:39:45+00:00

<p>Article URL: <a href="https://thewalrus.ca/stop-calling-each-new-disaster-the-new-normal/">https://thewalrus.ca/stop-calling-each-new-disaster-the-new-normal/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36354358">https://news.ycombinator.com/item?id=36354358</a></p>
<p>Points: 16</p>
<p># Comments: 2</p>

## Annoying A/B testing mistakes every engineer should know
 - [https://posthog.com/blog/ab-testing-mistakes](https://posthog.com/blog/ab-testing-mistakes)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 10:30:41+00:00

<p>Article URL: <a href="https://posthog.com/blog/ab-testing-mistakes">https://posthog.com/blog/ab-testing-mistakes</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36354280">https://news.ycombinator.com/item?id=36354280</a></p>
<p>Points: 28</p>
<p># Comments: 17</p>

## Probability and Markets by Jane Street [pdf]
 - [https://www.janestreet.com/static/pdfs/trading-interview.pdf](https://www.janestreet.com/static/pdfs/trading-interview.pdf)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 10:27:10+00:00

<p>Article URL: <a href="https://www.janestreet.com/static/pdfs/trading-interview.pdf">https://www.janestreet.com/static/pdfs/trading-interview.pdf</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36354259">https://news.ycombinator.com/item?id=36354259</a></p>
<p>Points: 37</p>
<p># Comments: 1</p>

## DevOps Is Bullshit (2022)
 - [https://blog.massdriver.cloud/posts/devops-is-bullshit/](https://blog.massdriver.cloud/posts/devops-is-bullshit/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 10:00:42+00:00

<p>Article URL: <a href="https://blog.massdriver.cloud/posts/devops-is-bullshit/">https://blog.massdriver.cloud/posts/devops-is-bullshit/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36354049">https://news.ycombinator.com/item?id=36354049</a></p>
<p>Points: 18</p>
<p># Comments: 1</p>

## Throwing in the Towel on Mobile Linux
 - [https://drewdevault.com/2023/06/16/Mobile-linux-retrospective.html](https://drewdevault.com/2023/06/16/Mobile-linux-retrospective.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 09:48:08+00:00

<p>Article URL: <a href="https://drewdevault.com/2023/06/16/Mobile-linux-retrospective.html">https://drewdevault.com/2023/06/16/Mobile-linux-retrospective.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36353960">https://news.ycombinator.com/item?id=36353960</a></p>
<p>Points: 11</p>
<p># Comments: 1</p>

## Put an io_uring on it – Exploiting the Linux Kernel
 - [https://chompie.rip/Blog+Posts/Put+an+io_uring+on+it+-+Exploiting+the+Linux+Kernel](https://chompie.rip/Blog+Posts/Put+an+io_uring+on+it+-+Exploiting+the+Linux+Kernel)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 09:35:37+00:00

<p>Article URL: <a href="https://chompie.rip/Blog+Posts/Put+an+io_uring+on+it+-+Exploiting+the+Linux+Kernel">https://chompie.rip/Blog+Posts/Put+an+io_uring+on+it+-+Exploiting+the+Linux+Kernel</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36353845">https://news.ycombinator.com/item?id=36353845</a></p>
<p>Points: 16</p>
<p># Comments: 1</p>

## MD5 (Algorithm) in SQL
 - [https://modern-sql.com/caniuse/MD5-algorithm](https://modern-sql.com/caniuse/MD5-algorithm)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 08:14:23+00:00

<p>Article URL: <a href="https://modern-sql.com/caniuse/MD5-algorithm">https://modern-sql.com/caniuse/MD5-algorithm</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36353147">https://news.ycombinator.com/item?id=36353147</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## The SSL Certificate Issuer Field Is a Lie
 - [https://www.agwa.name/blog/post/the_certificate_issuer_field_is_a_lie](https://www.agwa.name/blog/post/the_certificate_issuer_field_is_a_lie)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 07:47:56+00:00

<p>Article URL: <a href="https://www.agwa.name/blog/post/the_certificate_issuer_field_is_a_lie">https://www.agwa.name/blog/post/the_certificate_issuer_field_is_a_lie</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36352945">https://news.ycombinator.com/item?id=36352945</a></p>
<p>Points: 19</p>
<p># Comments: 0</p>

## MixRank (YC S11) Is Hiring Global Remote Software Engineers
 - [https://news.ycombinator.com/item?id=36352549](https://news.ycombinator.com/item?id=36352549)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 07:00:13+00:00

<p>Programming should be fun. At MixRank, we get to work with distributed systems, databases, data science, and big data. No meetings, no bureaucracy, no office, no time tracking— just challenging technical problems you can put your full focus into.<p>MixRank processes petabytes of data every month from web crawling. We have hundreds of customers using our data products including Google, Amazon, Facebook, Intel, and Adobe, across industries including Recruiting, Finance, Security, Sales, and Marketing.<p>Team is 34 full-time, full-remote from 15+ countries. We're growing, profitable, employee-owned, no dependence on outside funding. Applicants from all geographies and backgrounds are welcome.<p>We are looking for passionate individuals for whom programming is not just a job but it's something they love to do. We're obsessed with computers, programming, big data, databases, compilers, hardware, math, data science, and the internet. Does this sound like you? Please apply to join our team.<p>Our code base is very friendly to new contributors. You'll have a (fully-automated) development environment and be pushing commits on your first day. Deployments to production happen multiple times per day and finish in less than 2 minutes. Effectively all of our codebase is written in Python, SQL, Javascript/TypeScript, Rust, and Nix. The basic technologies you'll need familiarity with to be productive are Python, PostgreSQL, Linux, and Git.<p>We operate at a larger scale than typical startups. We operate two datacenters with high performance servers we've built that are capable of dealing with the volumes of data we process. We've implemented our own distributed file system. We do full-scale web crawls. We download and perform static analysis on the entire universe of Android APKs and iOS IPAs that are published. Unlike a typical startup where you'll spend half of your time in meetings, and the other half fixing bugs from Jira tickets— at MixRank you'll get to direct your entire focus into difficult technical problems that will help you to grow as an individual.<p>--<p>Junior Software Engineer<p>We're looking for remote junior engineers that have 0-3 years of professional experience in software, and 5+ years of curiosity exploring computers, programming, and technical hobby projects. This is an open-ended entry role with mentorship and diverse opportunities to work on all areas of our product: databases, distributed systems, infrastructure and tooling, data analysis, machine learning, frontend/backend web development, APIs, data mining, data modeling, and more. To stand out, please highlight what makes you unique: passion for computing, curiosity and side projects, work ethic, niche research, etc.<p>Ideally you've already finished with school, but if you still have one or more years left please feel free to apply anyway. If you're the right fit for the team we'll figure out a way to accommodate your schedule.<p>--<p>Software Engineer<p>We're hiring generalist software engineers to work on web applications, data mining, machine learning/data science, data transformation/ETL, data modeling, database scaling, infrastructure, devops, and more. We'll customize the role to whatever subset of these areas match your interests.<p>Beneficial experience includes PostgreSQL, Python, Linux, TypeScript, Rust, Nix, frontend/backend web development, and data mining.<p>--<p>Please apply here: <a href="https://www.ycombinator.com/companies/mixrank/jobs">https://www.ycombinator.com/companies/mixrank/jobs</a></p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36352549">https://news.ycombinator.com/item?id=36352549</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

## OpenSSL 1.1.1 End of Life Approaching
 - [https://www.openssl.org/blog/blog/2023/06/15/1.1.1-EOL-Reminder/](https://www.openssl.org/blog/blog/2023/06/15/1.1.1-EOL-Reminder/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 07:00:02+00:00

<p>Article URL: <a href="https://www.openssl.org/blog/blog/2023/06/15/1.1.1-EOL-Reminder/">https://www.openssl.org/blog/blog/2023/06/15/1.1.1-EOL-Reminder/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36352547">https://news.ycombinator.com/item?id=36352547</a></p>
<p>Points: 16</p>
<p># Comments: 1</p>

## Ask HN: Why would Google sell Google domains to Squarespace?
 - [https://news.ycombinator.com/item?id=36352347](https://news.ycombinator.com/item?id=36352347)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 06:34:54+00:00

<p>I’ve been thinking about this all day and it just doesn’t make sense to me. I was hoping someone here would have a well-informed opinion/answer.<p>Google domains seemed like a natural tool in the GCP and Google ecosystem. It provided one-click access to setup website, Google workspace, provided direct verification in Google Search Console and Google Analytics, and just made sense.<p>Unlike some of the other investments like Stadia, domains is also not capital or resource intensive. They never offered discount on domains, they sold them at standard prices. The team working on domains must be small. It’s also a low risk project. Why would they kill it?<p>What next? They’ll sell Google Fi to T-mobile and abandon Google voice?</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36352347">https://news.ycombinator.com/item?id=36352347</a></p>
<p>Points: 51</p>
<p># Comments: 23</p>

## CL0P Ransomware Gang Exploits CVE-2023-34362 MOVEit Vulnerability
 - [https://www.cisa.gov/news-events/cybersecurity-advisories/aa23-158a](https://www.cisa.gov/news-events/cybersecurity-advisories/aa23-158a)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 06:21:28+00:00

<p>Article URL: <a href="https://www.cisa.gov/news-events/cybersecurity-advisories/aa23-158a">https://www.cisa.gov/news-events/cybersecurity-advisories/aa23-158a</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36352224">https://news.ycombinator.com/item?id=36352224</a></p>
<p>Points: 6</p>
<p># Comments: 1</p>

## Do Foundation Model Providers Comply with the EU AI Act?
 - [https://crfm.stanford.edu/2023/06/15/eu-ai-act.html](https://crfm.stanford.edu/2023/06/15/eu-ai-act.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 06:10:21+00:00

<p>Article URL: <a href="https://crfm.stanford.edu/2023/06/15/eu-ai-act.html">https://crfm.stanford.edu/2023/06/15/eu-ai-act.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36352137">https://news.ycombinator.com/item?id=36352137</a></p>
<p>Points: 7</p>
<p># Comments: 1</p>

## The next generation of serverless
 - [https://www.fermyon.com/blog/next-generation-of-serverless-is-happening](https://www.fermyon.com/blog/next-generation-of-serverless-is-happening)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 06:06:10+00:00

<p>Article URL: <a href="https://www.fermyon.com/blog/next-generation-of-serverless-is-happening">https://www.fermyon.com/blog/next-generation-of-serverless-is-happening</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36352103">https://news.ycombinator.com/item?id=36352103</a></p>
<p>Points: 20</p>
<p># Comments: 3</p>

## The Illusion of Moral Decline
 - [https://www.nature.com/articles/s41586-023-06137-x](https://www.nature.com/articles/s41586-023-06137-x)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 04:48:08+00:00

<p>Article URL: <a href="https://www.nature.com/articles/s41586-023-06137-x">https://www.nature.com/articles/s41586-023-06137-x</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36351426">https://news.ycombinator.com/item?id=36351426</a></p>
<p>Points: 7</p>
<p># Comments: 2</p>

## Memory Safety Without Borrow Checking, Reference Counting, or Garbage Collection
 - [https://verdagon.dev/blog/single-ownership-without-borrow-checking-rc-gc](https://verdagon.dev/blog/single-ownership-without-borrow-checking-rc-gc)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 04:47:26+00:00

<p>Article URL: <a href="https://verdagon.dev/blog/single-ownership-without-borrow-checking-rc-gc">https://verdagon.dev/blog/single-ownership-without-borrow-checking-rc-gc</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36351415">https://news.ycombinator.com/item?id=36351415</a></p>
<p>Points: 3</p>
<p># Comments: 1</p>

## Major Louisiana DMV Hack
 - [https://gov.louisiana.gov/index.cfm/newsroom/detail/4158](https://gov.louisiana.gov/index.cfm/newsroom/detail/4158)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 04:20:26+00:00

<p>Article URL: <a href="https://gov.louisiana.gov/index.cfm/newsroom/detail/4158">https://gov.louisiana.gov/index.cfm/newsroom/detail/4158</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36351185">https://news.ycombinator.com/item?id=36351185</a></p>
<p>Points: 14</p>
<p># Comments: 8</p>

## Subreddit Migration Directory
 - [https://redditmigration.com](https://redditmigration.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 04:03:24+00:00

<p>Article URL: <a href="https://redditmigration.com">https://redditmigration.com</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36351065">https://news.ycombinator.com/item?id=36351065</a></p>
<p>Points: 89</p>
<p># Comments: 24</p>

## Detailed miniature models of historic computer
 - [https://www.miniatua.com/](https://www.miniatua.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 04:00:12+00:00

<p>Article URL: <a href="https://www.miniatua.com/">https://www.miniatua.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36351041">https://news.ycombinator.com/item?id=36351041</a></p>
<p>Points: 11</p>
<p># Comments: 1</p>

## Reddit is removing moderators that protest by taking their communities private
 - [https://old.reddit.com/r/ModCoord/comments/14aeq5j/new_admin_post_if_a_moderator_team_unanimously/](https://old.reddit.com/r/ModCoord/comments/14aeq5j/new_admin_post_if_a_moderator_team_unanimously/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 03:49:30+00:00

<p>Article URL: <a href="https://old.reddit.com/r/ModCoord/comments/14aeq5j/new_admin_post_if_a_moderator_team_unanimously/">https://old.reddit.com/r/ModCoord/comments/14aeq5j/new_admin_post_if_a_moderator_team_unanimously/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36350938">https://news.ycombinator.com/item?id=36350938</a></p>
<p>Points: 130</p>
<p># Comments: 49</p>

## Trsvid, a video player for TRS-80 Model 1, 3 and 4
 - [http://48k.ca/trsvid.html](http://48k.ca/trsvid.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 03:31:58+00:00

<p>Article URL: <a href="http://48k.ca/trsvid.html">http://48k.ca/trsvid.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36350789">https://news.ycombinator.com/item?id=36350789</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## io_uring disabled across Google platforms
 - [https://security.googleblog.com/2023/06/learnings-from-kctf-vrps-42-linux.html](https://security.googleblog.com/2023/06/learnings-from-kctf-vrps-42-linux.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 03:16:32+00:00

<p>Article URL: <a href="https://security.googleblog.com/2023/06/learnings-from-kctf-vrps-42-linux.html">https://security.googleblog.com/2023/06/learnings-from-kctf-vrps-42-linux.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36350693">https://news.ycombinator.com/item?id=36350693</a></p>
<p>Points: 3</p>
<p># Comments: 2</p>

## Guidance for Scaling – Reversible vs. Irreversible Decisions
 - [https://www.craigkerstiens.com/2021/12/29/guidance-for-scaling-reversible-vs.-irreversible-decisions/](https://www.craigkerstiens.com/2021/12/29/guidance-for-scaling-reversible-vs.-irreversible-decisions/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 03:12:29+00:00

<p>Article URL: <a href="https://www.craigkerstiens.com/2021/12/29/guidance-for-scaling-reversible-vs.-irreversible-decisions/">https://www.craigkerstiens.com/2021/12/29/guidance-for-scaling-reversible-vs.-irreversible-decisions/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36350668">https://news.ycombinator.com/item?id=36350668</a></p>
<p>Points: 4</p>
<p># Comments: 1</p>

## Show HN: Chronological List of All the James Webb Telescope Discoveries
 - [https://www.jameswebbdiscovery.com](https://www.jameswebbdiscovery.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 02:47:11+00:00

<p>Article URL: <a href="https://www.jameswebbdiscovery.com">https://www.jameswebbdiscovery.com</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36350439">https://news.ycombinator.com/item?id=36350439</a></p>
<p>Points: 13</p>
<p># Comments: 2</p>

## Metformin shown to prevent long Covid
 - [https://www.cidrap.umn.edu/covid-19/common-diabetes-drug-shown-prevent-long-covid](https://www.cidrap.umn.edu/covid-19/common-diabetes-drug-shown-prevent-long-covid)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 02:28:41+00:00

<p>Article URL: <a href="https://www.cidrap.umn.edu/covid-19/common-diabetes-drug-shown-prevent-long-covid">https://www.cidrap.umn.edu/covid-19/common-diabetes-drug-shown-prevent-long-covid</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36350280">https://news.ycombinator.com/item?id=36350280</a></p>
<p>Points: 22</p>
<p># Comments: 1</p>

## Falcon LLM: The Most Powerful Open Source LLM Released to Date
 - [https://thesequence.substack.com/p/edge-300-meet-falcon-llm-the-most](https://thesequence.substack.com/p/edge-300-meet-falcon-llm-the-most)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 02:12:00+00:00

<p>Article URL: <a href="https://thesequence.substack.com/p/edge-300-meet-falcon-llm-the-most">https://thesequence.substack.com/p/edge-300-meet-falcon-llm-the-most</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36350137">https://news.ycombinator.com/item?id=36350137</a></p>
<p>Points: 11</p>
<p># Comments: 2</p>

## CUDA Accelerated Raytracer
 - [https://github.com/maxilevi/raytracer](https://github.com/maxilevi/raytracer)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 01:47:13+00:00

<p>Article URL: <a href="https://github.com/maxilevi/raytracer">https://github.com/maxilevi/raytracer</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36349893">https://news.ycombinator.com/item?id=36349893</a></p>
<p>Points: 12</p>
<p># Comments: 0</p>

## FAA Requires Secondary Flight Deck Barrier
 - [https://www.faa.gov/newsroom/faa-requires-secondary-flight-deck-barrier](https://www.faa.gov/newsroom/faa-requires-secondary-flight-deck-barrier)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 01:12:59+00:00

<p>Article URL: <a href="https://www.faa.gov/newsroom/faa-requires-secondary-flight-deck-barrier">https://www.faa.gov/newsroom/faa-requires-secondary-flight-deck-barrier</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36349559">https://news.ycombinator.com/item?id=36349559</a></p>
<p>Points: 9</p>
<p># Comments: 12</p>

## Lemmy Instances are already blocking each other
 - [https://beehaw.org/post/567170](https://beehaw.org/post/567170)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 01:11:32+00:00

<p>Article URL: <a href="https://beehaw.org/post/567170">https://beehaw.org/post/567170</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36349547">https://news.ycombinator.com/item?id=36349547</a></p>
<p>Points: 23</p>
<p># Comments: 29</p>

## Generating Income from Open Source
 - [https://vadimdemedes.com/posts/generating-income-from-open-source](https://vadimdemedes.com/posts/generating-income-from-open-source)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 00:34:03+00:00

<p>Article URL: <a href="https://vadimdemedes.com/posts/generating-income-from-open-source">https://vadimdemedes.com/posts/generating-income-from-open-source</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36349208">https://news.ycombinator.com/item?id=36349208</a></p>
<p>Points: 17</p>
<p># Comments: 3</p>

## The Distributed Tensor Algebra Compiler (2022)
 - [https://arxiv.org/abs/2203.08069](https://arxiv.org/abs/2203.08069)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 00:22:59+00:00

<p>Article URL: <a href="https://arxiv.org/abs/2203.08069">https://arxiv.org/abs/2203.08069</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36349110">https://news.ycombinator.com/item?id=36349110</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## Squarespace Enters Definitive Agreement to Acquire Google Domains Assets
 - [https://newsroom.squarespace.com/blog/googledomains](https://newsroom.squarespace.com/blog/googledomains)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-16 00:14:36+00:00

<p>Article URL: <a href="https://newsroom.squarespace.com/blog/googledomains">https://newsroom.squarespace.com/blog/googledomains</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36349033">https://news.ycombinator.com/item?id=36349033</a></p>
<p>Points: 47</p>
<p># Comments: 3</p>

