# Source:Call Me Chato, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCL0QSFSUfW8cHua_rDpltTg, language:en-US

## REVIEW: Strange New Worlds, Episode 1 Season 2. Yes it was stupid.
 - [https://www.youtube.com/watch?v=H29Q-7SucIs](https://www.youtube.com/watch?v=H29Q-7SucIs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCL0QSFSUfW8cHua_rDpltTg
 - date published: 2023-06-16 16:30:48+00:00

#FormerNetworkExec #CallMeChato #strangenews 
Didn't the writers from Picard season 3 and Strange New Worlds talk to each other?
Thanks for watching my channel. Please subscribe, SHARE and touch yourselves.

Call Me Chato T-shirt
https://my-store-6121db.creator-spring.com/listing/ppc-cartoon-t-colour

https://twitter.com/PaulChato
http://www.paulchato.com

