# Source:Wired business, URL:https://www.wired.com/feed/category/business/latest/rss, language:en-US

## How to Live Well, Love AI, and Party Like a 6-Year-Old
 - [https://www.wired.com/story/plaintext-how-to-live-well-love-ai-and-party-like-a-6-year-old/](https://www.wired.com/story/plaintext-how-to-live-well-love-ai-and-party-like-a-6-year-old/)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2023-06-16 13:00:00+00:00

WIRED cofounder Kevin Kelly believes tech ultimately bends towards good—you just might have to wait a while. For now, he's got a book of life advice.

## Stack Overflow Didn’t Ask How Bad Its Gender Problem Is This Year
 - [https://www.wired.com/story/stack-overflow-gender-problem/](https://www.wired.com/story/stack-overflow-gender-problem/)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2023-06-16 11:00:00+00:00

The coding hub’s 2022 survey found that 92 percent of its users were men. This time around it simply dropped the question.

