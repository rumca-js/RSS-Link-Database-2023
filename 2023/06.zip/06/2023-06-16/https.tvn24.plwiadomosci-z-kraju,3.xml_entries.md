# Source:TVN24 Z kraju, URL:https://tvn24.pl/wiadomosci-z-kraju,3.xml, language:pl-PL

## 45 stopni i 11 ofiar. "Upał jest znacznie silniejszy niż w ubiegłych latach"
 - [https://tvn24.pl/tvnmeteo/swiat/meksyk-fala-upalow-11-osob-nie-zyje-temperatura-przekracza-45-stopni-celsjusza-7178141?source=rss](https://tvn24.pl/tvnmeteo/swiat/meksyk-fala-upalow-11-osob-nie-zyje-temperatura-przekracza-45-stopni-celsjusza-7178141?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-16 19:44:02+00:00

<img alt="45 stopni i 11 ofiar. " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-jq9k70-fala-upalow-w-meksyku-7178606/alternates/LANDSCAPE_1280" />
    Fala upałów od początku czerwca nie daje wytchnienia Meksykanom. Temperatura sięga ponad 45 stopni Celsjusza. Ministerstwo Zdrowia poinformowało, że na skutek ekstremalnie wysokiej temperatury zmarło 11 osób.

## Jest "lex Tusk", ale nie ma komisji. "PiS się przekonał, że to nie pojedzie. Teraz jest następny temat"
 - [https://tvn24.pl/polska/jest-lex-tusk-ale-nie-ma-komisji-ds-badania-wplywow-rosyjskich-marzena-okla-drewnowicz-i-piotr-krol-komentuja-7178774?source=rss](https://tvn24.pl/polska/jest-lex-tusk-ale-nie-ma-komisji-ds-badania-wplywow-rosyjskich-marzena-okla-drewnowicz-i-piotr-krol-komentuja-7178774?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-16 19:42:33+00:00

<img alt="Jest " src="https://tvn24.pl/najnowsze/cdn-zdjecie-fjan12-16-2000-bez-kitu-cl-0042-7178808/alternates/LANDSCAPE_1280" />
    Nie możemy brać udziału w tej całej farsie, która ma służyć tylko i wyłącznie igrzyskom podczas kampanii wyborczej - mówiła w "Kampanii #BezKitu" Marzena Okła-Drewnowicz, odnosząc się do ustawy "lex Tusk", powołującej komisję do spraw badania wpływów Rosji. Piotr Król (PiS) przekonywał, że "chodzi o to, żeby pokazać ludziom, jak głęboko sięgały te wpływy". - Jeżeli ktoś nie ma czegoś na sumieniu, to czego ma się bać - dodał.

## PiS chce wynająć halę na konwencję, dochód pójdzie na in vitro. "Kaczyński wyda sensownie pieniądze"
 - [https://tvn24.pl/polska/lodz-atlas-arena-pis-zamierza-zrobic-tam-konwencje-hanna-zdanowska-pieniadze-z-najmu-pojda-na-in-vitro-donald-tusk-komentuje-7178764?source=rss](https://tvn24.pl/polska/lodz-atlas-arena-pis-zamierza-zrobic-tam-konwencje-hanna-zdanowska-pieniadze-z-najmu-pojda-na-in-vitro-donald-tusk-komentuje-7178764?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-16 19:29:38+00:00

<img alt="PiS chce wynająć halę na konwencję, dochód pójdzie na in vitro. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-tbxbbs-atlas-arena-7178773/alternates/LANDSCAPE_1280" />
    PiS zamierza zorganizować pod koniec czerwca konwencję w łódzkiej Atlas Arenie. Prezydent miasta Hanna Zdanowska przekazała, że "nie zabroni" partii zrobienia tam konwencji, ale dochód z wynajmu zostanie przekazany na miejski program in vitro. "Cieszę się, że zło możemy przekuć w dobro" - napisała w mediach społecznościowych. Do sprawy odniósł się także przewodniczący PO Donald Tusk, który stwierdził, że to "pierwszy raz od niepamiętnych czasów, kiedy Jarosław Kaczyński wyda sensownie swoje pieniądze".

## Biedronka wycofuje produkt. Komunikat
 - [https://tvn24.pl/biznes/z-kraju/biedronka-wycofuje-produkt-komunikat-7178861?source=rss](https://tvn24.pl/biznes/z-kraju/biedronka-wycofuje-produkt-komunikat-7178861?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-16 19:29:24+00:00

<img alt="Biedronka wycofuje produkt. Komunikat" src="https://tvn24.pl/najnowsze/cdn-zdjecie-h6pemp-sklepy-biedronka-beda-otwarte-dluzej-4716339/alternates/LANDSCAPE_1280" />
    Główny Inspektorat Sanitarny wydał w piątek ostrzeżenie dotyczące wykrycia bakterii Listeria monocytogenes w partii hamburgerów wieprzowo-drobiowych sprzedawanej przez sieć Biedronka. Spożycie zanieczyszczonej nimi żywności może prowadzić do choroby zwanej listeriozą.

## Biało-czerwona ukryła remont ulicy. "Tej, idźcie w pyry"
 - [https://tvn24.pl/poznan/wiec-donalda-tuska-w-poznaniu-relacja-z-tlumu-bialo-czerwona-ukryla-remont-ulicy-byly-wlepki-tej-idzcie-w-pyry-7178740?source=rss](https://tvn24.pl/poznan/wiec-donalda-tuska-w-poznaniu-relacja-z-tlumu-bialo-czerwona-ukryla-remont-ulicy-byly-wlepki-tej-idzcie-w-pyry-7178740?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-16 19:27:25+00:00

<img alt="Biało-czerwona ukryła remont ulicy. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-mq732c-wiec-donalda-tuska-w-poznaniu-7178860/alternates/LANDSCAPE_1280" />
    Rozdawano wlepki "Tej, idźcie w pyry", obok handlowano flagami. Nie brakowało transparentów jak ten nawiązujący do popularnej kiedyś gumy balonowej z kciukiem w górę przy napisie "Donald" i kciukiem w dół przy "Kaczorze". Tysiące poznaniaków zebrało się w piątek na placu Wolności na wiecu z udziałem Donalda Tuska.

## Od wizyty w przychodni do przeszczepu serca. Pan Miłosz miał ogromne szczęście
 - [https://fakty.tvn24.pl/zobacz-fakty/od-wizyty-w-przychodni-do-przeszczepu-serca-pan-milosz-mial-ogromne-szczescie-7178798?source=rss](https://fakty.tvn24.pl/zobacz-fakty/od-wizyty-w-przychodni-do-przeszczepu-serca-pan-milosz-mial-ogromne-szczescie-7178798?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-16 19:20:24+00:00

<img alt="Od wizyty w przychodni do przeszczepu serca. Pan Miłosz miał ogromne szczęście" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-gwxfyt-od-wizyty-w-przychodni-do-przeszczepu-serca-pan-milosz-mial-ogromne-szczescie-7178803/alternates/LANDSCAPE_1280" />
    Każdy z lekarzy, do których trafił pan Miłosz Kadziewicz, przyczynił się do tego, że żyje. Jego historia zaczęła się w przychodni, gdzie badanie wykazało ciężki, masywny zawał serca. Następnie był szpital i przeszczep serca, na który pan Miłosz czekał tylko kilka dni.

## Wyniki Eurojackpot z 16 czerwca 2023. Jakie liczby padły podczas ostatniego losowania? Wysokie wygrane w Polsce
 - [https://tvn24.pl/biznes/pieniadze/eurojackpot-wyniki-z-dnia-160623-liczby-z-ostatniego-losowania-7178819?source=rss](https://tvn24.pl/biznes/pieniadze/eurojackpot-wyniki-z-dnia-160623-liczby-z-ostatniego-losowania-7178819?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-16 19:16:15+00:00

<img alt="Wyniki Eurojackpot z 16 czerwca 2023. Jakie liczby padły podczas ostatniego losowania? Wysokie wygrane w Polsce" src="https://tvn24.pl/najnowsze/cdn-zdjecie-b7a3hv-eurojackpot-shutterstock1603798027-5772919/alternates/LANDSCAPE_1280" />
    W piątkowym losowaniu Eurojackpot nie padła główna wygrana. W Polsce padły jednak dwie wygrane drugiego stopnia. Kumulacja wynosi 500 milionów złotych, a następne losowanie odbędzie się we wtorek. Oto liczby wylosowane w piątek, 16 czerwca 2023 roku.

## Dyskusja wokół refundacji metody in vitro. Posłanka PiS: to przemysł i współczesna enklawa eugeniki
 - [https://fakty.tvn24.pl/zobacz-fakty/dyskusja-wokol-refundacji-metody-in-vitro-poslanka-pis-to-przemysl-i-wspolczesna-enklawa-eugeniki-7178668?source=rss](https://fakty.tvn24.pl/zobacz-fakty/dyskusja-wokol-refundacji-metody-in-vitro-poslanka-pis-to-przemysl-i-wspolczesna-enklawa-eugeniki-7178668?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-16 18:44:09+00:00

<img alt="Dyskusja wokół refundacji metody in vitro. Posłanka PiS: to przemysł i współczesna enklawa eugeniki " src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-tsqvb3-dyskusja-wokol-refundacji-metody-in-vitro-poslanka-pis-to-przemysl-i-wspolczesna-enklawa-eugeniki-7178768/alternates/LANDSCAPE_1280" />
    W Sejmie w czwartek odbyła się debata dotycząca obywatelskiego projektu ustawy o refundacji in vitro. Pod projektem podpisało się pół miliona osób, ale Prawo i Sprawiedliwość tego nie dostrzega i pomysł krytykuje. Tymczasem Polska w rankingu dostępności leczenia niepłodności jest trzecia od końca w całej Europie - wyprzedzamy tylko Armenię i Albanię, a w Unii Europejskiej jesteśmy jedynym krajem bez refundacji lub planu jej wprowadzenia.

## Zmiana przepisów w sprawie faktur. Będzie nowy obowiązek
 - [https://tvn24.pl/biznes/dlafirm/krajowy-systemu-e-faktur-nowy-obowiazek-od-lipca-2024-7178762?source=rss](https://tvn24.pl/biznes/dlafirm/krajowy-systemu-e-faktur-nowy-obowiazek-od-lipca-2024-7178762?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-16 18:40:25+00:00

<img alt="Zmiana przepisów w sprawie faktur. Będzie nowy obowiązek" src="https://tvn24.pl/najnowsze/cdn-zdjecie-g6f2q8-kalkulator-kredyt-pieniadze-rachunki-oplaty-6478492/alternates/LANDSCAPE_1280" />
    W piątek Sejm posłowie zagłosowali za nowelą o podatku od towarów i usług, której celem jest wprowadzenie od połowy przyszłego roku obowiązku stosowania Krajowego Systemu e-Faktur (KSeF) przy wystawianiu faktur.

## Ratusz o konkursie na modernizację Skry. "Dosłownie za kilka dni"
 - [https://tvn24.pl/tvnwarszawa/ochota/warszawa-konkurs-na-modernizacje-skry-drugi-etap-kiedy-poznamy-zwyciezce-7178665?source=rss](https://tvn24.pl/tvnwarszawa/ochota/warszawa-konkurs-na-modernizacje-skry-drugi-etap-kiedy-poznamy-zwyciezce-7178665?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-16 18:12:43+00:00

<img alt="Ratusz o konkursie na modernizację Skry. " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-bjl4du-koncepcja-modernizacji-skry-etap-ii-5740458/alternates/LANDSCAPE_1280" />
    Dosłownie za kilka dni, na pewno do końca czerwca, poznamy zwycięzcę konkursu na projekt etapu drugiego, czyli stadion lekkoatletyczny główny i halę sportową na Skrze - poinformowała Renata Kaznowska, wiceprezydent Warszawy

## Pogoda na jutro - sobota 17.06. Deszcz i burze w wielu miejscach
 - [https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-jutro-sobota-1706-deszcz-i-burze-w-wielu-miejscach-7178557?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-jutro-sobota-1706-deszcz-i-burze-w-wielu-miejscach-7178557?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-16 18:04:54+00:00

<img alt="Pogoda na jutro - sobota 17.06. Deszcz i burze w wielu miejscach" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-kjirzq-burzowy-dzien-5768258/alternates/LANDSCAPE_1280" />
    Pogoda na jutro. Sobota 17.06 przyniesie wielu regionom kraju opady deszczu, Pojawią się też burze, lokalnie z opadami gradu. Termometry pokażą maksymalnie 24 stopnie Celsjusza.

## Teatr Kwadrat z nową dyrektorką
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-teatr-kwadrat-z-nowa-dyrektorka-ewa-wencel-zwyciezyla-w-konkursie-7178542?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-teatr-kwadrat-z-nowa-dyrektorka-ewa-wencel-zwyciezyla-w-konkursie-7178542?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-16 16:20:05+00:00

<img alt="Teatr Kwadrat z nową dyrektorką " src="https://tvn24.pl/najnowsze/cdn-zdjecie-mapwue-ewa-wencel-7178630/alternates/LANDSCAPE_1280" />
    Ewa Wencel zwyciężyła w konkursie na dyrektora Teatru Kwadrat w Warszawie - poinformował w piątek stołeczny ratusz. Stanowisko - na pięć kolejnych sezonów artystycznych - obejmie od września.

## Kilka partii produktu wycofanych z obrotu. Ostrzeżenie
 - [https://tvn24.pl/biznes/z-kraju/gis-pasta-warzywna-allos-wycofana-7178581?source=rss](https://tvn24.pl/biznes/z-kraju/gis-pasta-warzywna-allos-wycofana-7178581?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-16 16:05:51+00:00

<img alt="Kilka partii produktu wycofanych z obrotu. Ostrzeżenie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qqbpe7-30-osobowa-grupa-spladrowala-sklep-policja-szuka-swiadkow-6846092/alternates/LANDSCAPE_1280" />
    Główny Inspektorat Sanitarny wydał w piątek ostrzeżenie dotyczące możliwej obecności metalu w paście warzywnej ze szpinakiem i orzeszkami piniowymi marki Allos.

## Część usług może nie działać. "Za utrudnienia przepraszamy"
 - [https://tvn24.pl/biznes/z-kraju/pko-bp-mbank-ing-alior-bank-i-toyota-bank-przeprowadza-prace-serwisowe-w-weekend-17-18-czerwca-2023-r-7178399?source=rss](https://tvn24.pl/biznes/z-kraju/pko-bp-mbank-ing-alior-bank-i-toyota-bank-przeprowadza-prace-serwisowe-w-weekend-17-18-czerwca-2023-r-7178399?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-16 15:38:50+00:00

<img alt="Część usług może nie działać. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-xtmjgv-banki-odnotowaly-wiecej-zgloszen-4582459/alternates/LANDSCAPE_1280" />
    PKO BP, mBank, ING Bank Śląski, Alior Bank i Toyota Bank - te instytucje finansowe zapowiedziały prace serwisowe w nadchodzący weekend. Ich efektem będą utrudnienia w dostępie do niektórych usług.

## Małpa skoczyła na kobietę z dzieckiem, żeby zabrać mu lody
 - [https://tvn24.pl/tvnmeteo/swiat/tajwan-glodna-malpa-skoczyla-na-kobiete-z-dzieckiem-7178288?source=rss](https://tvn24.pl/tvnmeteo/swiat/tajwan-glodna-malpa-skoczyla-na-kobiete-z-dzieckiem-7178288?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-16 15:35:11+00:00

<img alt="Małpa skoczyła na kobietę z dzieckiem, żeby zabrać mu lody" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-c78k0k-glodna-malpa-skoczyla-na-kobiete-z-dzieckiem-7178523/alternates/LANDSCAPE_1280" />
    Położona w Tajwanie góra Shoushan słynie z zamieszkujących ją małp. Zwierzęta te potrafią być bardzo zuchwałe, o czym przekonała się pewna kobieta, na którą skoczył wygłodniały makak. Całe zajście nagrała kamera.

## Święto ulicy Stalowej, przejazdy rolkarzy, Parada Równości. Weekendowe wydarzenia w stolicy
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-swieto-ulicy-stalowej-przejazdy-rolkarzy-parada-rownosci-weekend-17-18-czerwca-w-stolicy-7177482?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-swieto-ulicy-stalowej-przejazdy-rolkarzy-parada-rownosci-weekend-17-18-czerwca-w-stolicy-7177482?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-16 15:28:06+00:00

<img alt="Święto ulicy Stalowej, przejazdy rolkarzy, Parada Równości. Weekendowe wydarzenia w stolicy" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-dh03n7-rolkarze-na-ulicach-warszawy-7177525/alternates/LANDSCAPE_1280" />
    Na "Święcie ulicy Stalowej" na uczestników czekają spektakle, warsztaty taneczne i plastyczne, spacery historyczne i muzyka. Z kolei rolkarze i wrotkarze zapraszają na dwa przejazdy z cyklu Nightskating Warszawa. Do wyboru są dwie trasy: na dystansie 19 lub 45 kilometrów. W sobotę ulicami przejdzie Parada Równości.

## Kuźmiuk: na Słowacji poziom zamożności spadł po przyjęciu euro. Dane nie potwierdzają
 - [https://konkret24.tvn24.pl/polityka/kuzmiuk-na-slowacji-poziom-zamoznosci-spadl-po-przyjeciu-euro-dane-nie-potwierdzaja-7178219?source=rss](https://konkret24.tvn24.pl/polityka/kuzmiuk-na-slowacji-poziom-zamoznosci-spadl-po-przyjeciu-euro-dane-nie-potwierdzaja-7178219?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-16 14:05:39+00:00

<img alt="Kuźmiuk: na Słowacji poziom zamożności spadł po przyjęciu euro. Dane nie potwierdzają " src="https://tvn24.pl/najnowsze/cdn-zdjecie-dvuodv-zbigniew-kuzmiuk-mowi-o-spadajacej-zamoznosci-slowakow-7178213/alternates/LANDSCAPE_1280" />
    Politycy opcji rządzącej ostrzegają Polaków, że wprowadzenie euro jako waluty w naszym kraju miałoby negatywne skutki. Przekonywał o tym europoseł PiS Zbigniew Kuźmiuk, podając za przykład Słowację jako kraj, który rzekomo stracił na wejściu do strefy euro. Tylko że statystyki tego nie potwierdzają.

## Odnaleźli grób Zbytkowera, upamiętnili Sterna. Na cmentarzu żydowskim na Bródnie
 - [https://tvn24.pl/tvnwarszawa/targowek/warszawa-cmentarz-zydowski-na-brodnie-zakonczono-pierwszy-etap-prac-renowacyjnych-znalezli-grob-szmula-zbytkowera-upamietnili-abrahama-sterna-7178320?source=rss](https://tvn24.pl/tvnwarszawa/targowek/warszawa-cmentarz-zydowski-na-brodnie-zakonczono-pierwszy-etap-prac-renowacyjnych-znalezli-grob-szmula-zbytkowera-upamietnili-abrahama-sterna-7178320?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-16 14:01:42+00:00

<img alt="Odnaleźli grób Zbytkowera, upamiętnili Sterna. Na cmentarzu żydowskim na Bródnie" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-7f4juj-efekt-prac-archeologow-na-cmentarzu-zydowskim-na-brodnie-7178357/alternates/LANDSCAPE_1280" />
    Zniszczony podczas II wojny światowej, dziś badany przez archeologów. Są już pierwsze efekty prac naukowców na terenie cmentarza żydowskiego na warszawskim Bródnie. Badaczom udało się odnaleźć miejsce pochówku założyciela cmentarza Szmula Zbytkowera. W trakcie prac upamiętniono też grób wybitnego wynalazcy Abrahama Sterna.

## Policja: kierowca wjechał w autobus miejski i oddalił się. Pięć osób w szpitalu
 - [https://tvn24.pl/tvnwarszawa/ulice/trasa-lazienkowska-wypadek-z-udzialem-autobusu-ranni-7178392?source=rss](https://tvn24.pl/tvnwarszawa/ulice/trasa-lazienkowska-wypadek-z-udzialem-autobusu-ranni-7178392?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-16 13:45:23+00:00

<img alt="Policja: kierowca wjechał w autobus miejski i oddalił się. Pięć osób w szpitalu " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-vq9qkf-wypadek-zdjecie-ilustracyjne-7145815/alternates/LANDSCAPE_1280" />
    Wypadek z udziałem autobusu miejskiego na Trasie Łazienkowskiej. Jak informuje policja, kilku pasażerów ucierpiało. Kierowcy muszą się liczyć z utrudnieniami.

## Chciała pomocy policji, później nie otwierała mieszkania. "Nie pamiętam, co zgłaszałam", "chcę to odwołać"
 - [https://tvn24.pl/tvnwarszawa/najnowsze/piaseczno-chciala-pomocy-policji-pozniej-nie-otwierala-mieszkania-dostala-mandat-7178293?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/piaseczno-chciala-pomocy-policji-pozniej-nie-otwierala-mieszkania-dostala-mandat-7178293?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-16 13:38:36+00:00

<img alt="Chciała pomocy policji, później nie otwierała mieszkania. " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-1e37f8-zostala-ukarana-mandatem-za-bezpodstawne-wezwanie-policji-7178291/alternates/LANDSCAPE_1280" />
    Młoda kobieta została ukarana mandatem w wysokości 1500 złotych. Powód? 23-latka trzykrotnie zadzwoniła na numer alarmowy 112, twierdząc, że potrzebuje pomocy, ponieważ padła ofiarą przestępstwa. Kiedy policjanci dotarli na miejsce, udawała, że nie ma jej w domu, a ostatecznie stwierdziła, że wcale ich nie wzywała i nie pamięta, dlaczego dzwoniła po pomoc.

## "Chcemy pokazać te materiały opinii publicznej", "co robiły służby przez osiem ostatnich lat?"
 - [https://tvn24.pl/polska/lex-tusk-w-piatek-glosowanie-nad-prezydencka-nowelizacja-w-sejmie-komentarze-politykow-7178215?source=rss](https://tvn24.pl/polska/lex-tusk-w-piatek-glosowanie-nad-prezydencka-nowelizacja-w-sejmie-komentarze-politykow-7178215?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-16 12:56:26+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8ay89-momo-1-0001-7178204/alternates/LANDSCAPE_1280" />
    W piątek po południu zaplanowano kolejne głosowanie nad prezydencką nowelizacją "lex Tusk". Reporter TVN24 Radomir Wit pytał o ustawę posłów partii rządzącej i opozycji. - Polskie służby przez osiem ostatnich lat rządów PiS nie potrafiły znaleźć osób, które były pod wpływem służb rosyjskich - zauważył poseł Lewicy Wiesław Szczepański. - Chcemy na konkretnych dokumentach pokazać, w jaki sposób funkcjonowali funkcjonariusze naszego państwa - twierdził poseł Piotr Kaleta z PiS.

## Ursynów się bawi. Zagrają T.Love, Kaliber 44, Muchy i inni
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-dni-ursynowa-program-koncertow-7177756?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-dni-ursynowa-program-koncertow-7177756?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-16 12:53:14+00:00

<img alt="Ursynów się bawi. Zagrają T.Love, Kaliber 44, Muchy i inni" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-b9yyfi-dni-ursynowa-2022-7177900/alternates/LANDSCAPE_1280" />
    T.Love, Kaliber 44, Muchy i Nocny Kochanek to największe gwiazdy tegorocznych Dni Ursynowa. Na Ursynowie nie może też zabraknąć rapu, który tak mocno kojarzy się z dzielnicą. Lokalna scenę hip hop reprezentować będą: Dixon 37, Polska Wersja i Mor W.A. Koncerty u podnóża Kopy Cwila odbędą się w piątek i sobotę, ale nie są jedynymi atrakcjami wydarzenia.

## 58-latek kierował ruchem i został potrącony. Zginął na miejscu
 - [https://tvn24.pl/pomorze/byslaw-smiertelnie-potracil-58-latek-kierujacego-ruchem-i-uciekl-policja-zatrzymala-go-w-domu-byl-pijany-7178006?source=rss](https://tvn24.pl/pomorze/byslaw-smiertelnie-potracil-58-latek-kierujacego-ruchem-i-uciekl-policja-zatrzymala-go-w-domu-byl-pijany-7178006?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-16 12:47:26+00:00

<img alt="58-latek kierował ruchem i został potrącony. Zginął na miejscu " src="https://tvn24.pl/najnowsze/cdn-zdjecie-649f6e-policja-zatrzymala-47-latka-byl-pijany-zdjecie-ilustracyjne-7178049/alternates/LANDSCAPE_1280" />
    Nie żyje 58-latek, który kierował ruchem na drodze w miejscowości Bysław (woj. kujawsko-pomorskie) i został potrącony przez kierowcę auta osobowego. Ten uciekł z miejsca zdarzenia. W momencie zatrzymania miał w organizmie trzy promile alkoholu.

## Zespół do opracowania wytycznych w sprawie przerywania ciąży rozpoczął pracę
 - [https://tvn24.pl/polska/zespol-do-opracowania-wytycznych-w-sprawie-przerywania-ciazy-rozpoczal-prace-7177994?source=rss](https://tvn24.pl/polska/zespol-do-opracowania-wytycznych-w-sprawie-przerywania-ciazy-rozpoczal-prace-7177994?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-16 11:43:32+00:00

<img alt="Zespół do opracowania wytycznych w sprawie przerywania ciąży rozpoczął pracę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-m7r9g3-adam-niedzielski-7178040/alternates/LANDSCAPE_1280" />
    Minister zdrowia Adam Niedzielski zainaugurował prace zespołu do spraw opracowania procedur związanych z przerwaniem ciąży – przekazał w piątek resort. Dodał, że na ich podstawie odbędą się szkolenia dla zespołów medycznych.

## Wynajmował mieszkanie młodym kobietom. Odpowie za gwałty i inne przestępstwa seksualne
 - [https://tvn24.pl/krakow/wroclaw-zarzuty-i-areszt-dla-podejrzanego-o-gwalty-7178050?source=rss](https://tvn24.pl/krakow/wroclaw-zarzuty-i-areszt-dla-podejrzanego-o-gwalty-7178050?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-16 11:34:44+00:00

<img alt="Wynajmował mieszkanie młodym kobietom. Odpowie za gwałty i inne przestępstwa seksualne" src="https://tvn24.pl/krakow/cdn-zdjecie-410mqj-ofiarami-padaly-kobiety-ktore-wynajmowaly-od-podejrzanego-mieszkanie-7178009/alternates/LANDSCAPE_1280" />
    Mieszkaniec Wrocławia (woj. dolnośląskie) odpowie przed sądem za "serię przestępstw o charakterze seksualnym". Ofiarami padały kobiety, które wynajmowały od podejrzanego mieszkanie. Policja apeluje o zgłaszanie się pokrzywdzonych oraz świadków.

## Zderzenie auta z karetką. "W środku był pacjent"
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-samochod-osobowy-zderzyl-sie-z-karetka-na-zwirki-i-wigury-7177990?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-samochod-osobowy-zderzyl-sie-z-karetka-na-zwirki-i-wigury-7177990?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-16 11:11:29+00:00

<img alt="Zderzenie auta z karetką. " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-gh09vh-zderzenie-w-zwirki-i-wigury-7177997/alternates/LANDSCAPE_1280" />
    W piątek nad ranem na Żwirki i Wigury toyota zderzyła się z karetką pogotowia. Jak przekazała nam policja, wewnątrz ambulansu znajdował się pacjent.

## Wracają "Detektywi". Kiedy nowa seria kultowego paradokumentu?
 - [https://tvn24.pl/kultura-i-styl/tvn-detektywi-kiedy-nowa-seria-kultowego-paradokumentu-7177836?source=rss](https://tvn24.pl/kultura-i-styl/tvn-detektywi-kiedy-nowa-seria-kultowego-paradokumentu-7177836?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-16 11:02:52+00:00

<img alt="Wracają " src="https://tvn24.pl/najnowsze/cdn-zdjecie-bhd0q9-detektywi-anna-potaczek-7177858/alternates/LANDSCAPE_1280" />
    Powstaje nowa, 15. seria serialu "Detektywi". Polski paradokument był emitowany w TVN od 2005 do 2012 roku. Miał 1040 odcinków. Występowali w nim byli policjanci i asystenci detektywów, którzy rozwiązywali śledztwa oparte na prawdziwych historiach. Nowe odcinki lubianej produkcji zobaczymy już jesienią.

## Tatrzański bóbr "ma inwencję twórczą", ale jego nową tamę trzeba będzie rozebrać
 - [https://tvn24.pl/krakow/tatry-bobr-znad-morskiego-oka-buduje-tame-7177671?source=rss](https://tvn24.pl/krakow/tatry-bobr-znad-morskiego-oka-buduje-tame-7177671?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-16 09:59:22+00:00

<img alt="Tatrzański bóbr " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-ccmgsj-bobr-zdjecie-pogladowe-5412661/alternates/LANDSCAPE_1280" />
    Bóbr, który zamieszkał minionego lata nad Morskim Okiem w Tatrach, nie próżnuje. Teraz zwierzę zaczęło budować tamę na Czarnostawiańskiej Siklawie. Jak jednak ocenia leśniczy Grzegorz Bryniarski, konstrukcję trzeba będzie rozebrać, by turyści mogli korzystać ze szlaku

## Na Wiśle dryfowało ciało. Wyłowili je strażacy
 - [https://tvn24.pl/tvnwarszawa/najnowsze/jablonna-cialo-dryfujace-w-wisle-straz-pozarna-w-wodzie-znajdowalo-sie-od-wielu-godzin-7177659?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/jablonna-cialo-dryfujace-w-wisle-straz-pozarna-w-wodzie-znajdowalo-sie-od-wielu-godzin-7177659?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-16 09:44:18+00:00

<img alt="Na Wiśle dryfowało ciało. Wyłowili je strażacy" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-5jnexr-akcja-strazakow-na-wisle-7177687/alternates/LANDSCAPE_1280" />
    W Wiśle na wysokości Jabłonny zauważono dryfujące ciało mężczyzny. Strażacy interweniowali na łodziach i na polecenie policji wyciągnęli je na brzeg.

## Afery w NCBR ciąg dalszy. Szczerba: Bielan nie chce odpuścić tych pieniędzy, układ został zakonserwowany
 - [https://tvn24.pl/polska/afera-w-ncbr-poslowie-jonski-i-szczerba-uklad-bielana-zakonserwowany-pieniadze-wyciekaja-7177656?source=rss](https://tvn24.pl/polska/afera-w-ncbr-poslowie-jonski-i-szczerba-uklad-bielana-zakonserwowany-pieniadze-wyciekaja-7177656?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-16 09:40:35+00:00

<img alt="Afery w NCBR ciąg dalszy. Szczerba: Bielan nie chce odpuścić tych pieniędzy, układ został zakonserwowany" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9ps7di-pap_20211108_0ze-1-7177767/alternates/LANDSCAPE_1280" />
    Byliśmy zapewniani, że ludzie Adama Bielana nie wrócą do Narodowego Centrum Badań i Rozwoju ani do Ministerstwa Funduszy i Polityki Regionalnej. Tymczasem po cichu na funkcję wiceministra funduszy i polityki regionalnej została powołana najwierniejsza asystentka Bielana - mówił w piątek na konferencji poseł Koalicji Obywatelskiej Dariusz Joński. - Dzisiaj możemy powiedzieć z całą stanowczością: mamy do czynienia z konserwacją układu Bielana w NCBR - dodał poseł Michał Szczerba.

## Były policjant podejrzewany o zabójstwa podwładnego i dziennikarza pozostanie w areszcie
 - [https://tvn24.pl/krakow/sanok-krosno-krakow-byly-policjant-podejrzewany-o-zabojstwa-podwladnego-i-dziennikarza-pozostanie-w-areszcie-7172895?source=rss](https://tvn24.pl/krakow/sanok-krosno-krakow-byly-policjant-podejrzewany-o-zabojstwa-podwladnego-i-dziennikarza-pozostanie-w-areszcie-7172895?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-16 09:39:34+00:00

<img alt="Były policjant podejrzewany o zabójstwa podwładnego i dziennikarza pozostanie w areszcie  " src="https://tvn24.pl/najnowsze/cdn-zdjecie-hdlni7-wiezienie-3822351/alternates/LANDSCAPE_1280" />
    Sąd Okręgowy w Krośnie na kolejne cztery miesiące przedłużył areszt dla Tadeusza P., byłego milicjanta, później także policjanta, któremu krakowska prokuratura postawiła zarzut zabójstwa swojego podwładnego milicjanta Krzysztofa Pyki, sanockiego dziennikarza Marka Pomykały oraz usiłowania zabójstwa swojej byłej żony, Ewy P. Byłemu funkcjonariuszowi za popełnione czyny grozi dożywocie.

## Poszukiwany za zabójstwo sprzed 19 lat zatrzymany. Ukrywał się po tym, jak sąd nie zgodził się na areszt
 - [https://tvn24.pl/pomorze/poszukiwany-za-zabojstwo-sprzed-19-lat-zatrzymany-ukrywal-sie-po-tym-jak-sad-nie-zgodzil-sie-na-areszt-7177444?source=rss](https://tvn24.pl/pomorze/poszukiwany-za-zabojstwo-sprzed-19-lat-zatrzymany-ukrywal-sie-po-tym-jak-sad-nie-zgodzil-sie-na-areszt-7177444?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-16 07:52:22+00:00

<img alt="Poszukiwany za zabójstwo sprzed 19 lat zatrzymany. Ukrywał się po tym, jak sąd nie zgodził się na areszt" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3m952d-policja-zatrzymala-podejrzanego-o-zabojstwo-sprzed-lat-7177453/alternates/LANDSCAPE_1280" />
    Pomorska policja informuje o tym, że funkcjonariusze zatrzymali poszukiwanego listem gończym 35-latka. Jest on podejrzany o zabójstwo, do którego doszło na Kaszubach w 2004 roku. Mężczyźnie grozi dożywocie.

## Nie chcą hali sportowej na Polu Mokotowskim. Boją się hałasu, wycinek i parkingowego chaosu
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-hala-do-koszykowki-na-polu-mokotowskim-mjn-chce-konsultacji-spolecznych-7177338?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-hala-do-koszykowki-na-polu-mokotowskim-mjn-chce-konsultacji-spolecznych-7177338?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-16 06:53:56+00:00

<img alt="Nie chcą hali sportowej na Polu Mokotowskim. Boją się hałasu, wycinek i parkingowego chaosu" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-yr90ls-koncepcja-modernizacji-skry-etap-ii-5740457/alternates/LANDSCAPE_1280" />
    Aktywiści ze stowarzyszenia Miasto Jest Nasze chcą przeprowadzenia konsultacji społecznych w sprawie modernizacji Skry. Obawiają się, że planowana na tym terenie hala do koszykówki będzie uciążliwa dla mieszkańców Ochoty.

## Drugie czytanie nowelizacji "lex Tusk". Sejm ma głosować nad poprawkami
 - [https://tvn24.pl/polska/lex-tusk-prace-nad-prezydencka-nowelizacja-w-sejmie-drugie-czytanie-7177319?source=rss](https://tvn24.pl/polska/lex-tusk-prace-nad-prezydencka-nowelizacja-w-sejmie-drugie-czytanie-7177319?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-16 06:38:17+00:00

<img alt="Drugie czytanie nowelizacji " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ccwoix-sejm-7177329/alternates/LANDSCAPE_1280" />
    Sejm w piątek w drugim czytaniu ma rozpatrzyć sprawozdanie sejmowej komisji w sprawie prezydenckiego projektu nowelizacji ustawy powołującej komisję do spraw badania wpływów rosyjskich nazywanej lex Tusk. Komisja przyjęła między innymi poprawkę PiS usuwającą termin publikacji pierwszego raportu komisji, ustalony na 17 września.

## Oskarżenia wobec wokalisty Rammstein. Wytwórnia płytowa zawiesza promocję nagrań zespołu
 - [https://tvn24.pl/kultura-i-styl/zarzuty-wobec-wokalisty-rammstein-co-zrobil-till-lindemann-jest-sledztwo-wytwornia-plytowa-podjela-decyzje-7177235?source=rss](https://tvn24.pl/kultura-i-styl/zarzuty-wobec-wokalisty-rammstein-co-zrobil-till-lindemann-jest-sledztwo-wytwornia-plytowa-podjela-decyzje-7177235?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-16 05:35:56+00:00

<img alt="Oskarżenia wobec wokalisty Rammstein. Wytwórnia płytowa zawiesza promocję nagrań zespołu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-nnc4mh-till-lindemann-4516083/alternates/LANDSCAPE_1280" />
    Wytwórnia płytowa Universal Music, która do tej pory milczała na temat oskarżeń wysuwanych wobec lidera zespołu Rammstein, opublikowała oświadczenie, którym informuje o zawieszeniu działań marketingowych i promocyjnych nagrań zespołu. Prokuratura bada, czy Till Lindemann dopuszczał się przymuszania do czynności seksualnych oraz czy udostępniał narkotyki. "Pełne wyjaśnienie zarzutów, również przez władze, jest absolutnie konieczne i musi leżeć w interesie całego zespołu" - czytamy w oświadczeniu wytwórni.

## Spadnie dużo deszczu. Alerty IMGW
 - [https://tvn24.pl/tvnmeteo/prognoza/alerty-imgw-intensywne-opady-deszczu-piec-wojewodztw-z-ostrzezeniami-synoptykow-7177261?source=rss](https://tvn24.pl/tvnmeteo/prognoza/alerty-imgw-intensywne-opady-deszczu-piec-wojewodztw-z-ostrzezeniami-synoptykow-7177261?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-16 04:47:04+00:00

<img alt="Spadnie dużo deszczu. Alerty IMGW" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-jz2jld-intensywne-opady-deszczu-6116656/alternates/LANDSCAPE_1280" />
    Instytut Meteorologii i Gospodarki Wodnej ostrzega przed intensywnymi opadami deszczu na wschodzie kraju. Alerty obowiązują w pięciu województwach. W niektórych regionach może obficie padać przez całą sobotę.

## Leżała w szpitalu, w którym zmarła 33-letnia Dorota. Relacja z porodówki w Nowym Targu
 - [https://tvn24.pl/polska/katarzyna-lezala-w-szpitalu-w-ktorym-zmarla-33-letnia-dorota-relacja-z-porodowki-w-nowym-targu-7177188?source=rss](https://tvn24.pl/polska/katarzyna-lezala-w-szpitalu-w-ktorym-zmarla-33-letnia-dorota-relacja-z-porodowki-w-nowym-targu-7177188?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-16 04:40:00+00:00

<img alt="Leżała w szpitalu, w którym zmarła 33-letnia Dorota. Relacja z porodówki w Nowym Targu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pvd1hy-podhalanski-szpital-specjalistyczny-w-nowym-targu-7175960/alternates/LANDSCAPE_1280" />
    To mogłam być ja. Ten sam szpital, ten sam dzień, ta sama noc. Płakać mi się chce - wyznaje pani Katarzyna, która podobnie jak pani Dorota trafiła do szpitala w Nowym Targu w piątym miesiącu ciąży, z powodu odejścia wód płodowych. Materiał programu "Uwaga!" TVN.

## Wypadek w Starej Krobi. Czworo nastolatków trafiło do szpitala
 - [https://tvn24.pl/polska/wielkopolskie-stara-krobia-wypadek-w-starej-krobi-samochod-wpadl-do-rowu-dachowanie-7177245?source=rss](https://tvn24.pl/polska/wielkopolskie-stara-krobia-wypadek-w-starej-krobi-samochod-wpadl-do-rowu-dachowanie-7177245?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-16 03:24:00+00:00

<img alt="Wypadek w Starej Krobi. Czworo nastolatków trafiło do szpitala" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5nx2s7-wypadek-w-starej-krobi-7177242/alternates/LANDSCAPE_1280" />
    W miejscowości Stara Krobia w województwie wielkopolskim doszło do poważnego wypadku z udziałem czworga nastolatków. Samochód wypadł z drogi, dachował i wylądował w rowie. Wszyscy uczestnicy zdarzenia zostali przetransportowani do szpitala.

## Pogoda na dziś - piątek 16.06. Pochmurno i deszczowo w wielu regionach. Uwaga na burze
 - [https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-dzis-piatek-1606-pochmurno-i-deszczowo-w-wielu-regionach-uwaga-na-burze-7177041?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-dzis-piatek-1606-pochmurno-i-deszczowo-w-wielu-regionach-uwaga-na-burze-7177041?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-16 00:00:00+00:00

<img alt="Pogoda na dziś - piątek 16.06. Pochmurno i deszczowo w wielu regionach. Uwaga na burze" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cbzzmf-moga-pojawic-sie-burze-7177077/alternates/LANDSCAPE_1280" />
    Pogoda na dziś. W piątek w większości kraju możemy spodziewać się chmur i deszczu. Będą miejsca, w których pojawić się mogą burze z gradem. Będzie ciepło - termometry pokażą maksymalnie od 19 do 25 stopni.

