# Source:The Verge, URL:https://www.theverge.com/rss/index.xml, language:en-US

## Illinois now lets cops fly drones over events — but not with weapons or facial recognition
 - [https://www.theverge.com/2023/6/16/23763885/illinois-drone-weapons-facial-recognition-law](https://www.theverge.com/2023/6/16/23763885/illinois-drone-weapons-facial-recognition-law)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-06-16 20:21:26+00:00

<figure>
      <img alt="UAV Pilot Training In Ukraine" src="https://cdn.vox-cdn.com/thumbor/dDicrjeVg13pHJl3uyxftYnmcvI=/0x0:4096x2731/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72377940/1498885624.0.jpg" />
        <figcaption><em>A Ukrainian drone. Ukraine has been using all manner of weaponized drones to push back Russian troops.</em> | Photo by Andriy Zhyhaylo/Obozrevatel/Global Images Ukraine via Getty Images</figcaption>
    </figure>

  <p id="KDZ8wE">Cops can’t attach weapons to drones in Illinois, starting today — and they can’t use drones for facial recognition unless they’re attempting to counter a terrorist attack, preventing “imminent harm to life,” or making sure a suspect doesn’t get away. </p>
<p id="suXQLZ">But they can do something they couldn’t before in Illinois: fly over public events <em>at all</em>. </p>
<p id="XXuRPm">Today, the state signed the <a href="https://ilga.gov/legislation/fulltext.asp?DocName=10300HB3902enr&amp;GA=103&amp;SessionId=112&amp;DocTypeId=HB&amp;LegID=149171&amp;DocNum=3902&amp;GAID=17&amp;SpecSess=&amp;Session=">Drones as First Responders Act</a> into law (via <a href="https://news.ycombinator.com/item?id=36359296">Hacker News</a>). The new act modifies another one from 2014 — the Freedom from Drone Surveillance Act, which has banned law enforcement from using drones to “gather information” in the state (aside from terrorist or imminent harm situations) for the past seven years. </p>
<p id="3VCv3k">The new bill is designed to prevent shootings like <a href="https://en.wikipedia.org/wiki/Highland_Park_parade_shooting">the one</a> at...</p>
  <p>
    <a href="https://www.theverge.com/2023/6/16/23763885/illinois-drone-weapons-facial-recognition-law">Continue reading&hellip;</a>
  </p>

## Leaked Samsung Galaxy Watch 6 photos herald return of the bezel
 - [https://www.theverge.com/2023/6/16/23763824/samsung-galaxy-watch-6-classic-bezel-smartwatch](https://www.theverge.com/2023/6/16/23763824/samsung-galaxy-watch-6-classic-bezel-smartwatch)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-06-16 20:01:11+00:00

<figure>
      <img alt="Leaked image of Samsung Galaxy Watch 6 Classic" src="https://cdn.vox-cdn.com/thumbor/JAMSH9RvKKAhQEdfXNattFJBzjA=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72377904/Screenshot_2023_06_16_at_3.08.34_PM.0.jpg" />
        <figcaption><em>Bezels are back, baby.</em> | Image: WinFuture</figcaption>
    </figure>

  <p id="piIl5e">Rotating bezels are back, baby. At least, that seems to be the case according to newly <a href="https://winfuture.de/news,136870.html">leaked photos</a> of Samsung’s next-gen Galaxy Watches.</p>
<p id="ptVMUu">The Galaxy Watch 6 and Watch 6 Classic photos come from German tech site <a href="https://winfuture.de/news,136870.html"><em>WinFuture</em></a>, which has a solid track record when it comes to this sort of thing. But aside from the Classic’s return, there isn’t anything too exciting to look at in these leaked marketing stills. Mostly because the Galaxy Watch 6 looks like the <a href="https://www.theverge.com/23310395/samsung-galaxy-watch-5-review-smartwatch-wear-os-3">Galaxy Watch 5</a>, which looks like the <a href="https://www.theverge.com/22629459/galaxy-watch-4-classic-review-bixby-google-wearos">Galaxy Watch 4</a>. Meanwhile, the Watch 6 Classic looks pretty much like the Watch 4 Classic.</p>
<div class="c-float-left c-float-hang">  <figure class="e-image">
        
      <cite>Image: WinFuture</cite>
      <figcaption><em>The Galaxy Watch 6 sure looks like the Galaxy Watch 4 and 5.</em></figcaption>
  </figure>
</div>
<p id="rUhW9L">The vanilla Galaxy Watch 6 will purportedly come in 40mm...</p>
  <p>
    <a href="https://www.theverge.com/2023/6/16/23763824/samsung-galaxy-watch-6-classic-bezel-smartwatch">Continue reading&hellip;</a>
  </p>

## RIF developer counters Reddit CEO’s claims that he didn’t want to work with Reddit
 - [https://www.theverge.com/2023/6/16/23763661/reddit-rif-is-fun-developer-ceo-steve-huffman](https://www.theverge.com/2023/6/16/23763661/reddit-rif-is-fun-developer-ceo-steve-huffman)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-06-16 19:39:53+00:00

<figure>
      <img alt="A landscape screenshot of rif is fun for Reddit." src="https://cdn.vox-cdn.com/thumbor/EA7uaZW5DK-hQzJFFu4nfXLeWY4=/150x0:1770x1080/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72377852/screenshot.0.jpg" />
        <figcaption><em>A screenshot of rif is fun for Reddit.</em> | Image: TalkLittle</figcaption>
    </figure>

  <p id="9YPyh9">On Thursday, Reddit CEO Steve Huffman told me that the developer of rif is fun for Reddit (RIF), a popular third-party Reddit app for Android, did not want to work with Reddit on the company’s planned API pricing changes. However, the developer, Andrew Shu, tells me that’s not the case — and shared emails with <em>The Verge</em> that appear to back him up.</p>
<p id="Z7EUOP">During the interview, I asked Huffman if Reddit could give developers more time to implement the API changes, which Shu has already said are forcing him to shut down RIF at <a href="https://www.theverge.com/2023/6/8/23754616/reddit-third-party-apps-api-shutdown-rif-reddplanet-sync">the end of the month</a>. Here’s exactly <a href="https://www.theverge.com/2023/6/15/23762868/reddit-ceo-steve-huffman-interview">what Huffman said in response</a> (emphasis mine):</p>
<blockquote>
<p id="ipPo8G">I said we are working with everybody who is willing to work with us, which includes many of the other third party apps. The three you...</p>
</blockquote>
  <p>
    <a href="https://www.theverge.com/2023/6/16/23763661/reddit-rif-is-fun-developer-ceo-steve-huffman">Continue reading&hellip;</a>
  </p>

## Meta is lowering the minimum age for the Quest to 10 years old
 - [https://www.theverge.com/2023/6/16/23763812/meta-quest-headset-lower-age-10-years-old](https://www.theverge.com/2023/6/16/23763812/meta-quest-headset-lower-age-10-years-old)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-06-16 18:38:11+00:00

<figure>
      <img alt="A photo of somebody using the Meta Quest 3." src="https://cdn.vox-cdn.com/thumbor/vzfuG9K7l5ORJaWm0-0m-LwSUp8=/268x0:1888x1080/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72377677/06_Lifestyle.0.jpg" />
        <figcaption>The Meta Quest 3 headset ships later this year. | Image: Meta</figcaption>
    </figure>

  <p id="h5Rghj">Government scrutiny of how tech companies handle their underage users is continuing to heat up. <a href="https://www.theverge.com/2023/5/5/23712443/kosa-earn-it-coppa-child-privacy-data-tiktok-blackburn-blumenthal">A flood of bills in Congress</a> on this topic seeks to strengthen the power of regulators and even ban kids under 13 from social media entirely.</p>
<p id="nR0bmI">Enter Meta, which is lowering the minimum age for its Quest headsets from 13 to 10. After I heard about the plan and contacted Meta for comment this week, spokesperson Joe Osborne<strong> </strong>confirmed it and <a href="https://go.redirectingat.com?id=66960X1514734&amp;xs=1&amp;url=https%3A%2F%2Fwww.meta.com%2Fblog%2Fquest%2Fmeta-accounts-parent-managed-families%2F&amp;referrer=theverge.com&amp;sref=https%3A%2F%2Fwww.theverge.com%2F2023%2F6%2F16%2F23763812%2Fmeta-quest-headset-lower-age-10-years-old" rel="sponsored nofollow noopener" target="_blank">shared a blog post about the news</a> that the company is planning to publish soon. It says that parents will have to approve the creation of a kid’s account and that Meta will only recommend apps that are rated safe for that age group. Ads also won’t be shown to kids.</p>
<p id="eBuEyB">Perhaps most importantly, a 10 to...</p>
  <p>
    <a href="https://www.theverge.com/2023/6/16/23763812/meta-quest-headset-lower-age-10-years-old">Continue reading&hellip;</a>
  </p>

## New Samsung Z Flip 5 leak highlights a gloriously big cover screen
 - [https://www.theverge.com/2023/6/16/23763530/samsung-galaxy-z-flip-5-leak-render-cover-screen](https://www.theverge.com/2023/6/16/23763530/samsung-galaxy-z-flip-5-leak-render-cover-screen)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-06-16 17:17:06+00:00

<figure>
      <img alt="Render of Galaxy Z Flip 5 showing large cover screen flowing around the cameras." src="https://cdn.vox-cdn.com/thumbor/XN7to2JylVWQvXPwbCRt4FS4slA=/0x72:1700x1205/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72377409/zflip5_render.0.jpg" />
        <figcaption><em>Hot foldable summer, y’all.</em> | Image: MySmartPrice</figcaption>
    </figure>

  <p id="l5CmQU">Samsung Galaxy Z Flip 5 <a href="https://www.theverge.com/2023/5/4/23710806/samsung-galaxy-z-flip-5-cover-display-size-resolution-3-4-720-748">leaks and rumors</a> have all pointed to a larger cover screen on the upcoming phone, and <a href="https://www.mysmartprice.com/gear/samsung-galaxy-z-flip-5-official-press-render-design-revealed-specifications-exclusive/">a new alleged render published by <em>MySmartPrice</em></a> continues the trend. The image shows the Z Flip 5 with a gloriously big cover screen, which is exactly what we want. And by we, I mean me personally. I want this.</p>
<p id="lxMwh5">The <a href="https://www.theverge.com/23312037/samsung-galaxy-z-flip-4-review-price-specs-screen-camera-battery">Galaxy Z Flip 4’</a>s outer screen measures just 1.9 inches. It’s fine for checking the weather and reading notifications, but the small size limits the kinds of actions you can take with it, like typing out responses to texts. It’s also not ideal for framing up selfies with the outer cameras — one of the benefits of a flip-style phone — because the preview image is literally the size of a postage stamp. I checked. </p>
<div class="c-float-left c-float-hang"><aside id="wnMNHg"><div></div></aside></div>
<p id="jOewlw">That...</p>
  <p>
    <a href="https://www.theverge.com/2023/6/16/23763530/samsung-galaxy-z-flip-5-leak-render-cover-screen">Continue reading&hellip;</a>
  </p>

## Here are more than 75 digital gifts you can still pick up for Father’s Day
 - [https://www.theverge.com/23642026/best-digital-gift-ideas-online-cards-subscriptions](https://www.theverge.com/23642026/best-digital-gift-ideas-online-cards-subscriptions)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-06-16 17:15:04+00:00

<figure>
      <img alt="A man lifting weights during a virtual strength training class." src="https://cdn.vox-cdn.com/thumbor/NUT8hXPCUFPhoKzOwbA1kdBQ_m8=/0x0:920x613/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72377404/pelotonapp.0.jpg" />
        <figcaption><em>A Peloton subscription provides access to thousands of streamable fitness classes, including strength training.</em> | Image: Peloton</figcaption>
    </figure>

  <p id="eOToV9">Yes, Father’s Day is this weekend. But before you have a full-blown panic attack because you forgot to pick up a gift worthy of dad’s admiration, take a deep breath. After all, the internet is filled with a treasure trove of gift cards, subscriptions, and other great digital gifts you can buy today or at any point this weekend.</p>
<div class="c-float-left c-float-hang"><div id="qWHWWF"><div></div></div></div>
<p id="NCvlAs">To help make your life a little easier, we’ve curated a list of some of the best digital gifts we’ve either used ourselves or gifted to our friends and family. We’ve organized the list based on various interests, too, so you can find the perfect present whether your dad is into the arts, exercise, or something else entirely. That way, you’ll be able to gift something more thoughtful than a generic <a href="https://www.amazon.com/dp/B004LLIKVU/?tag=theverge02-20" rel="sponsored nofollow noopener" target="_blank">Amazon gift...</a></p>
  <p>
    <a href="https://www.theverge.com/23642026/best-digital-gift-ideas-online-cards-subscriptions">Continue reading&hellip;</a>
  </p>

## Apple Mac Studio (2023) review: the M2 Ultra rips
 - [https://www.theverge.com/23762570/apple-mac-studio-m2-ultra-2023-review](https://www.theverge.com/23762570/apple-mac-studio-m2-ultra-2023-review)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-06-16 16:44:59+00:00

<p>The Mac Studio remains the top choice for professionals who need a powerful but compact desktop computer.</p>
  <p>
    <a href="https://www.theverge.com/23762570/apple-mac-studio-m2-ultra-2023-review">Continue reading&hellip;</a>
  </p>

## Space-based solar power is having its moment in the sun
 - [https://www.theverge.com/23762445/space-based-solar-power-clean-energy-milestone](https://www.theverge.com/23762445/space-based-solar-power-clean-energy-milestone)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-06-16 16:41:10+00:00

<figure>
      <img alt="Art depicting a satellite with solar panels between the Sun and Earth" src="https://cdn.vox-cdn.com/thumbor/APVTA8B-VjxM3zjZZIexoeLzCRw=/0x0:3000x2000/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72377302/236708_space_based_solar.0.jpg" />
        <figcaption>Photo illustration by Alex Parkin/The Verge; Source: Caltech</figcaption>
    </figure>

  <p id="tTOKgA">Beaming electricity down to Earth from solar panels in space has been a clean energy dream for decades. Even though the technology still has a long way to go before it can keep the lights on at home, there’s more hype than ever that space-based solar power stations could actually work.</p>
<p id="wqzAC4">A major milestone was announced this month when researchers at Caltech said that a prototype launched into space was able to beam a small amount of power to Earth. It was an important first for the nascent technology, and other researchers around the world are racing to make similar progress with funding from governments trying to reach their climate goals. </p>
<div class="c-float-left c-float-hang"><aside id="ntIgdD"><q>“I have a hard time not letting my imagination run wild when I start looking at this.”</q></aside></div>
<p id="1686927648.286279">In space,...</p>
  <p>
    <a href="https://www.theverge.com/23762445/space-based-solar-power-clean-energy-milestone">Continue reading&hellip;</a>
  </p>

## Black Mirror’s ‘Mazey Day’ is a brisk, bloody bite of celebrity crisis
 - [https://www.theverge.com/23763326/black-mirror-mazey-day-review-season-6-netflix](https://www.theverge.com/23763326/black-mirror-mazey-day-review-season-6-netflix)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-06-16 16:35:13+00:00

<figure>
      <img alt="A still photo of Zazie Beetz in Black Mirror." src="https://cdn.vox-cdn.com/thumbor/Ra9Vgv3QcXcb5q5KZHj-5dtk83E=/480x0:3360x1920/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72377292/Black_Mirror_n_S6_E4_00_17_59_07.0.png" />
        <figcaption>Image: Netflix</figcaption>
    </figure>

  <p id="wA3Xs1">As <em>Black Mirror</em> episodes have continued to balloon to <a href="https://www.theverge.com/2023/6/15/23761949/black-mirror-season-six-beyond-the-sea-aaron-paul-josh-hartnett-review">the size of full-blown movies</a>, season 6’s “Mazey Day” is almost refreshing: it’s a compact 40 minutes that rushes by in a fit of flashing lights. It’s a story about celebrities and their unhealthy and often dangerous relationship to the press — the paparazzi, in particular. It’s fun but, because it moves so quickly, its premise ultimately isn’t explored with much nuance.</p>
<p id="SVnvds">“Mazey Day,” from director Uta Briesewitz, is about two characters living in parallel who inevitably clash. To start, there’s Bo (Zazie Beetz), a paparazzi living in LA who is starting to question her place among her seedy and often desperate colleagues, wondering if a more honest living is the better route....</p>
  <p>
    <a href="https://www.theverge.com/23763326/black-mirror-mazey-day-review-season-6-netflix">Continue reading&hellip;</a>
  </p>

## Google sunsets Domains business and shovels it off to Squarespace
 - [https://www.theverge.com/2023/6/16/23763340/google-domains-sunset-sell-squarespace](https://www.theverge.com/2023/6/16/23763340/google-domains-sunset-sell-squarespace)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-06-16 16:22:53+00:00

<figure>
      <img alt="Image of the Google “G” logo on a blue, black, and purple background." src="https://cdn.vox-cdn.com/thumbor/yrkAI1wyOSwZYwlhMUvGtTQOIjI=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72377213/STK093_Google_03.0.jpg" />
        <figcaption>Illustration: The Verge</figcaption>
    </figure>

  <p id="P2CCRW">Google Domains has been <a href="https://www.theverge.com/2015/1/13/7538197/google-domains-now-available-to-everyone-in-united-states">a quick and easy place</a> to buy a dot com (or dot net, or dot studio, even) for your cottage bakery — but the company is now giving up on the registrar business and <a href="https://newsroom.squarespace.com/blog/googledomains">selling the assets to Squarespace</a>. The deal includes handing off 10 million domains owned by Google customers to the popular website builder.</p>
<p id="SsgDgv">In a press statement, Google’s VP and GM of merchant shopping, Matt Madrigal, says the sale is an effort to “sharpen our focus” and that the company plans on “supporting a smooth transition” for its customers being handed off to Squarespace. Madrigal then assures customers that Squarespace, which already has its own domain management plus web building tools, would be the perfect home for customers’ websites. Google...</p>
  <p>
    <a href="https://www.theverge.com/2023/6/16/23763340/google-domains-sunset-sell-squarespace">Continue reading&hellip;</a>
  </p>

## Here’s the note Reddit sent to moderators threatening them if they don’t reopen
 - [https://www.theverge.com/2023/6/16/23763538/reddit-blackout-api-protest-mod-replacement-threat](https://www.theverge.com/2023/6/16/23763538/reddit-blackout-api-protest-mod-replacement-threat)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-06-16 16:02:33+00:00

<figure>
      <img alt="A Reddit logo shown upside down on an orange background." src="https://cdn.vox-cdn.com/thumbor/8p2lbimfYofNABef6NcyMEBKDho=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72377111/acastro_STK024_02.0.jpg" />
        <figcaption>Image by Alex Castro / The Verge</figcaption>
    </figure>

  <p id="rTen30">Some moderators of Reddit communities participating in the <a href="https://www.theverge.com/2023/6/12/23755974/reddit-subreddits-going-dark-private-protest-api-changes">protest</a> against <a href="https://www.theverge.com/2023/5/31/23743993/reddit-apollo-client-api-cost">API changes</a> today got messages from the company: work to reopen your subreddits or else.</p>
<blockquote>
<p id="zP8oO3">If there are mods here who are willing to work towards reopening this community, we are willing to work with you to process a Top Mod Removal request or reorder the mod team to achieve this goal if mods higher up the list are hindering reopening. We would handle this request and any retaliation attempts here in this modmail chain immediately.</p>
<p id="cBvRk9">Our goal is to work with the existing mod team to find a path forward and make sure your subreddit is made available for the community which makes its home here. If you are not able or willing to reopen and maintain the community, please...</p>
</blockquote>
  <p>
    <a href="https://www.theverge.com/2023/6/16/23763538/reddit-blackout-api-protest-mod-replacement-threat">Continue reading&hellip;</a>
  </p>

## Garmin Epix Pro review: smaller size, bigger appeal (and a flashlight!)
 - [https://www.theverge.com/23759824/garmin-epix-2-pro-review-smartwatch](https://www.theverge.com/23759824/garmin-epix-2-pro-review-smartwatch)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-06-16 15:33:24+00:00

<p>I felt kind of meh toward the second-gen Epix, but I really do get the appeal now thanks to the smaller Pro. </p>
  <p>
    <a href="https://www.theverge.com/23759824/garmin-epix-2-pro-review-smartwatch">Continue reading&hellip;</a>
  </p>

## Black Mirror’s ‘Loch Henry’ can’t decide whether to indulge in true crime or critique it
 - [https://www.theverge.com/2023/6/16/23763257/black-mirror-season-6-loch-henry-true-crime-review-netflix](https://www.theverge.com/2023/6/16/23763257/black-mirror-season-6-loch-henry-true-crime-review-netflix)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-06-16 14:34:40+00:00

<figure>
      <img alt="Davis (Samuel Blenkin) and Pia (Myha’la Herrold) standing on a beach using a drone." src="https://cdn.vox-cdn.com/thumbor/WuAqthyt4JYHjfyBfjNLVSFDlQM=/0x0:1725x1150/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72376671/Black_Mirror_n_S6_E2_00_23_14_13.0.jpg" />
        <figcaption><em>Davis (Samuel Blenkin) and Pia (Myha’la Herrold) in “Loch Henry.”</em> | Image: Netflix</figcaption>
    </figure>

  <p id="FaWpFX"><em>Black Mirror</em> is known as a series about the dangers of technology, but it’s often more specifically about the corrupting influence of entertainment. Spectatorship makes us cruel, the show suggests over and over, turning other humans’ real pain into fodder for our own amusement. The sixth season episode “Loch Henry” fits into this dynamic but in a way that feels surprisingly anemic, neither exploring the potential ugliness of its premise nor developing characters who transcend it.</p>
<p id="RXdrDm">At the beginning of “Loch Henry,” Davis (Samuel Blenkin) is a film student returning home with his girlfriend Pia (Myha’la Herrold). It’s supposed to be a brief stopover; they’re planning, to the bemusement of everyone but Davis, a documentary about a man who...</p>
  <p>
    <a href="https://www.theverge.com/2023/6/16/23763257/black-mirror-season-6-loch-henry-true-crime-review-netflix">Continue reading&hellip;</a>
  </p>

## Sony’s comfortable WF-C700N earbuds have fallen to their best price to date
 - [https://www.theverge.com/2023/6/16/23762717/sony-wf-c700n-wireless-earbuds-tears-of-the-kingdom-samsung-a54-phone-deal-sale](https://www.theverge.com/2023/6/16/23762717/sony-wf-c700n-wireless-earbuds-tears-of-the-kingdom-samsung-a54-phone-deal-sale)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-06-16 14:05:00+00:00

<figure>
      <img alt="A photo of Sony’s C700N wireless earbuds." src="https://cdn.vox-cdn.com/thumbor/Xu9TcauYWGKXKViksi_PnzJSf6M=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72376566/DSCF0731.0.jpg" />
        <figcaption><em>The entry-level WF-C700N&nbsp;come in four colors, including two colorful pastel hues.</em> | Photo by Chris Welch / The Verge</figcaption>
    </figure>

  <p id="title">The old “times have changed” applies to a lot of things — the way we consume media, the general office environment, <a href="https://www.theverge.com/2022/6/7/23158666/taco-bell-defy-digital-online-orders-drive-thru">Taco Bell</a>. It also applies to wireless earbuds, which have come down drastically in price since the first pair of Apple’s <a href="https://www.theverge.com/2016/12/20/14016568/apple-airpods-wireless-earpods-earbuds-review">now-iconic AirPods</a> landed in 2016. <strong>Sony’s WF-C700N earbuds</strong> are a prime example of how you can now get a lot of functionality for very little, particularly since they’re available from <a href="https://www.amazon.com/Sony-Canceling-Bluetooth-Headphones-Resistance/dp/B0BYPFNW6T/?tag=theverge02-20" rel="sponsored nofollow noopener" target="_blank">Amazon</a>, <a href="https://howl.me/cjXKkiBPXdw">Best Buy</a>, and <a href="https://www.anrdoezrs.net/links/8532386/type/dlg/sid/verge/https://electronics.sony.com/audio/headphones/truly-wireless-earbuds/p/wfc700n-v" rel="sponsored nofollow noopener" target="_blank">Sony</a> for as little as $98 ($21 off).</p>
<div class="c-float-left c-float-hang"><aside id="1BYT1T"><div></div></aside></div>
<p id="KXxO75">So what does a sub-$100 pair of earbuds look like in 2023? Well, in the case of the entry-level WF-C700N, you get a terrific fit and balanced sound for the price. Sony’s latest pair of noise-canceling earbuds also offer a slew of software features, including...</p>
  <p>
    <a href="https://www.theverge.com/2023/6/16/23762717/sony-wf-c700n-wireless-earbuds-tears-of-the-kingdom-samsung-a54-phone-deal-sale">Continue reading&hellip;</a>
  </p>

## How screen refresh rates work on your phone
 - [https://www.theverge.com/23763320/refresh-phone-iphone-android-samsung-how-to](https://www.theverge.com/23763320/refresh-phone-iphone-android-samsung-how-to)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-06-16 13:53:57+00:00

<figure>
      <img alt="iPhone lock screen" src="https://cdn.vox-cdn.com/thumbor/QzURlTSiUyn4C1qi5xnZIMZqrzQ=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72376480/HT015_S_Haddad_ios_iphone_14_03.0.jpg" />
        <figcaption>Illustration by Samar Haddad / The Verge</figcaption>
    </figure>

  <p id="pyOk74">When you read a review of a smartphone, you will usually be hit with a long list of screen specs: the display type, its dimensions and aspect ratio, its resolution in pixels, its HDR support (or lack of it), and its brightness, for example. Too often, it’s assumed that everyone understands the significance of each of these specs. </p>
<p id="5Y1QtK">So in this article, we’re going to focus on the basics of the refresh rate, which you’ll see in the specs of monitors and TVs as well. It tells you how many times the display is refreshed per second, typically measured in Hz (hertz). In other words, a 90Hz display refreshes itself 90 times a second. Here’s what you need to know about the spec and how to make sure the maximum refresh rate is enabled on your...</p>
  <p>
    <a href="https://www.theverge.com/23763320/refresh-phone-iphone-android-samsung-how-to">Continue reading&hellip;</a>
  </p>

## Elemental’s a periodic table of metaphors that don’t always work the way Pixar wants
 - [https://www.theverge.com/23762155/pixar-elemental-review](https://www.theverge.com/23762155/pixar-elemental-review)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-06-16 13:30:00+00:00

<figure>
      <img alt="A still image from the film Elemental." src="https://cdn.vox-cdn.com/thumbor/PzU7VQdh3905jsTBktjyVy8C4-I=/0x0:4854x3236/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72376419/ELEMENTAL_ONLINE_USE_m355_208g_pub.pub16.228.0.jpg" />
        <figcaption>Image: Pixar</figcaption>
    </figure>


  		 <p>Pixar’s latest animated feature from director Peter Sohn doesn’t want to be another Zootopia, and yet...</p>
  <p>
    <a href="https://www.theverge.com/23762155/pixar-elemental-review">Continue reading&hellip;</a>
  </p>

## Some things you can do if you’re sick of social media
 - [https://www.theverge.com/23762545/social-media-alternatives-outside-touch-grass](https://www.theverge.com/23762545/social-media-alternatives-outside-touch-grass)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-06-16 13:00:00+00:00

<figure>
      <img alt="" src="https://cdn.vox-cdn.com/thumbor/v4eDTOTklBhI8g2eway4AB6KAvw=/0x107:640x534/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72376301/Cast_Iron_Skillet.0.jpg" />
        <figcaption><em>Maybe just one more go-round with the oven to get the seasoning juuuuuust right.</em> | Photo by Amelia Holowaty Krales / The Verge</figcaption>
    </figure>

  <p id="rkWkaR">I never thought of myself as being an especially heavy user of social media, but now that I <a href="https://www.theverge.com/2022/7/26/23279815/instagram-feed-kardashians-criticism-fuck-it-im-out">no longer post on Instagram</a> and barely post on Twitter... I suddenly have a lot of new free time?</p>
<p id="46S2jk">Now some of this is that I don’t care about video; I got bored with TikTok about two years ago and deleted it from my phone. But if you, like me, have discovered that social media has felt a lot less compelling lately, let me make some suggestions for activities:</p>
<ul>
<li id="iYx4uK">
<strong>Season your cast iron skillet</strong>. You’ve already seasoned it? Well, another coat won’t hurt.</li>
<li id="MXLy0O">
<strong>Clean out your closet</strong>. Hey, you should be doing this regularly anyway, right?</li>
<li id="edxr0k">
<strong>Learn to cook a new recipe</strong>. This is also an ideal time to listen to music.</li>
<li id="FOnuoe">
<strong>Go for a walk</strong> <strong>(or just sit outside)</strong>. Joke’s...</li>
</ul>
  <p>
    <a href="https://www.theverge.com/23762545/social-media-alternatives-outside-touch-grass">Continue reading&hellip;</a>
  </p>

## Discord ‘Activities’ for collaborative gaming are now free for everyone
 - [https://www.theverge.com/2023/6/16/23763279/discord-activities-free-nitro-subscription-reddit](https://www.theverge.com/2023/6/16/23763279/discord-activities-free-nitro-subscription-reddit)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-06-16 12:38:51+00:00

<figure>
      <img alt="The Discord logo." src="https://cdn.vox-cdn.com/thumbor/ZvcU65RxNnVuz4vxM--jiBhIlwo=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72376210/acastro_STK062_02.0.jpg" />
        <figcaption>Illustration by Alex Castro / The Verge</figcaption>
    </figure>

  <p id="DMan0N">Discord has announced that Activities — a feature for voice channels that allows members to play games or watch content together — will <a href="https://discord.com/blog/server-activities-games-voice-watch-together">remain free for all Discord users</a>. </p>
<p id="slVbbH">While most <a href="https://www.theverge.com/2022/10/17/23408421/discord-nitro-basic-subscription-price-activities-youtube-integration">Discord Activities</a> were previously locked behind a subscription to Discord Nitro (which starts at $2.99 a month), the communications platform had temporarily removed its paywall as part of its eighth birthday celebrations between May 15th and June 15th. Now, Activities like <em>Sketch Heads</em>, <em>Blazing 8s</em>, and <em>Bobble League</em> will be indefinitely free to use. </p>
<p id="w30EtV">Some Discord activities like YouTube’s “Watch together” integration and the <em>Putt Party</em> golfing game were already available at no additional cost prior to this announcement. If you want to give them a try...</p>
  <p>
    <a href="https://www.theverge.com/2023/6/16/23763279/discord-activities-free-nitro-subscription-reddit">Continue reading&hellip;</a>
  </p>

## Home, smart home
 - [https://www.theverge.com/23751315/smart-home-energy-microgrid-efficiency-independent](https://www.theverge.com/23751315/smart-home-energy-microgrid-efficiency-independent)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-06-16 12:00:00+00:00

<figure>
      <img alt="" src="https://cdn.vox-cdn.com/thumbor/65FI7QfMSD_768UMWLcJfX9E2Uc=/0x0:2550x1700/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72376088/236656_Microgrid_smart_homes_AZaucha_0052.0.jpg" />
        <figcaption><em>KB Home’s Durango at Shadow Mountain is an experimental smart microgrid community that is energy independent. It’s located about 90 miles southeast of Los Angeles, near Menifee, California.</em></figcaption>
    </figure>


  		 <p>One couple’s starter home in a connected community in California shows how smart energy powered by smart home technology could be the future of affordable, energy-independent living.  </p>
  <p>
    <a href="https://www.theverge.com/23751315/smart-home-energy-microgrid-efficiency-independent">Continue reading&hellip;</a>
  </p>

## Uber’s about to stick video ads in its cars, apps, and anywhere else it can
 - [https://www.theverge.com/2023/6/16/23763227/uber-video-advertising-ads-taxi-food-delivery-apps](https://www.theverge.com/2023/6/16/23763227/uber-video-advertising-ads-taxi-food-delivery-apps)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-06-16 11:45:00+00:00

<figure>
      <img alt="The Uber logo on a red, black, and white background" src="https://cdn.vox-cdn.com/thumbor/025I6i0Jl6b5khVSvJSRyUpzq5E=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72376051/acastro_STK106__03.0.jpg" />
        <figcaption><em>Video ads will begin rolling out across Uber services in the US this week.</em> | Illustration by Alex Castro / The Verge</figcaption>
    </figure>

  <p id="bkOxGE">Uber is about to start displaying video ads across its various service apps, including Uber Eats, Drizly (an <a href="https://www.theverge.com/2021/2/2/22262155/uber-drizly-alcohol-delivery-service-eats-postmates">Uber-owned alcohol delivery platform</a>), and its namesake ride-hailing app. Announced via a <a href="https://go.redirectingat.com?id=66960X1514734&amp;xs=1&amp;url=https%3A%2F%2Fwww.uber.com%2Fus%2Fen%2Fadvertising%2Fpress%2F&amp;referrer=theverge.com&amp;sref=https%3A%2F%2Fwww.theverge.com%2F2023%2F6%2F16%2F23763227%2Fuber-video-advertising-ads-taxi-food-delivery-apps" rel="sponsored nofollow noopener" target="_blank">press release</a> on Thursday, full-length video ads — which will play on the main Uber app while users wait for their taxi to arrive — will begin rolling out to users in the US “over the coming weeks.” Uber hopes to entice advertisers with what it knows about its users.</p>
<p id="x8c9yT">“We have two minutes of your attention. We know where you are, we know where you are going to, we know what you have eaten,” said Uber ad exec Mark Grether to <a href="https://www.wsj.com/articles/video-ads-are-coming-to-all-your-uber-apps-cb11d48e?mod=djemalertNEWS"><em>The Wall Street Journal</em></a>. “We can use all of that to then basically target a video ad towards you.” Two minutes is roughly...</p>
  <p>
    <a href="https://www.theverge.com/2023/6/16/23763227/uber-video-advertising-ads-taxi-food-delivery-apps">Continue reading&hellip;</a>
  </p>

## First ‘Designed for Xbox’ projector arrives in the US next month for $1,600
 - [https://www.theverge.com/2023/6/16/23763219/viewsonic-x2-4k-short-throw-led-projector-designed-for-xbox-us-price-release-date](https://www.theverge.com/2023/6/16/23763219/viewsonic-x2-4k-short-throw-led-projector-designed-for-xbox-us-price-release-date)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-06-16 10:02:10+00:00

<figure>
      <img alt="Viewsonic X2-4K LED projector sitting on table." src="https://cdn.vox-cdn.com/thumbor/dTqmihlDiuDmjmn9-q0PvyJ_LxY=/0x0:1182x788/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72375912/Power_On.0.jpg" />
        <figcaption><em>Note the Xbox color scheme.</em> | Image: Viewsonic</figcaption>
    </figure>

  <p id="eQGabj">Viewsonic’s short throw X2-4K LED projector, which it’s billing as the world’s first projector that’s been certified for Xbox, will be <a href="https://www.viewsonic.com/us/x1000-4k-ultra-short-throw-4k-uhd-projector-with-2400-led-lumens-usb-c-bluetooth-speakers-and-wi-fi-1.html">available in the US in July</a> for $1,599.99, <a href="https://www.businesswire.com/news/home/20230615005014/en/ViewSonic-Launches-World">the company has announced</a>. The X2-4K was <a href="https://www.prnewswire.co.uk/news-releases/viewsonic-launches-worlds-first-projectors-designed-for-xbox-301778413.html">originally announced back in March</a> alongside a non-short throw model called the X1-4K, which is yet to be listed on <a href="https://www.viewsonic.com/us/products/shop/projectors/home-theater-projectors.html?cat=1011%2C4077">Viewsonic’s US store</a> as of this writing.</p>
<p id="rqnmmT">Although it’s the first projector with the badge, <a href="https://go.redirectingat.com?id=66960X1514734&amp;xs=1&amp;url=https%3A%2F%2Fwww.xbox.com%2Fen-US%2Fdesigned-for-xbox&amp;referrer=theverge.com&amp;sref=https%3A%2F%2Fwww.theverge.com%2F2023%2F6%2F16%2F23763219%2Fviewsonic-x2-4k-short-throw-led-projector-designed-for-xbox-us-price-release-date" rel="sponsored nofollow noopener" target="_blank">Microsoft’s “Designed for Xbox” program</a> is a pre-existing initiative that’s seen it work with other manufacturers to make sure their accessories are compatible with its consoles. According to Microsoft, the program already covers “more than 15 categories” like headsets, gamepads, and racing wheels, as well as <a href="https://www.theverge.com/2021/6/22/22545193/microsoft-designed-for-xbox-displays-monitors-badge">a series...</a></p>
  <p>
    <a href="https://www.theverge.com/2023/6/16/23763219/viewsonic-x2-4k-short-throw-led-projector-designed-for-xbox-us-price-release-date">Continue reading&hellip;</a>
  </p>

## Google sues alleged scammer over fake business and review scheme
 - [https://www.theverge.com/2023/6/16/23762729/google-lawsuit-scam-fake-business-listings-reviews-search-results](https://www.theverge.com/2023/6/16/23762729/google-lawsuit-scam-fake-business-listings-reviews-search-results)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-06-16 10:00:00+00:00

<figure>
      <img alt="Image of the Google “G” logo on a blue, black, and purple background." src="https://cdn.vox-cdn.com/thumbor/3LEoRsWkLbTvnSIVMYDcArSVasE=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72375874/STK093_Google_03.0.jpg" />
        <figcaption>Illustration: The Verge</figcaption>
    </figure>

  <p id="JBn0tj">Google is suing an alleged scammer for running an elaborate scheme to flood its search product with fake businesses and reviews. </p>
<p id="Wg0sF3"><a href="https://cdn.vox-cdn.com/uploads/chorus_asset/file/24731137/GMBEye___Complaint___DRAFT__1_.pdf">In the complaint filed Friday</a>, Google accuses the defendant, Ethan Hu, of abusing the company’s products “to create fake online listings for businesses that do not exist, and to bolster them with fake reviews from people who do not exist.” After establishing the fake companies, Hu and 20 unnamed co-defendants allegedly sold these fake listings to other businesses looking to promote their own services in Google’s search results. </p>
<p id="sLOHd5">Over the last two years, Google says the defendants created over 350 fake business profiles that received at least 14,000 fake reviews. While Google can automatically create listings...</p>
  <p>
    <a href="https://www.theverge.com/2023/6/16/23762729/google-lawsuit-scam-fake-business-listings-reviews-search-results">Continue reading&hellip;</a>
  </p>

## Mercedes-Benz tests ChatGPT in cars to answer ‘complex questions’ while on the road
 - [https://www.theverge.com/2023/6/16/23763208/mercedes-benz-chatgpt-voice-assistant-beta-test](https://www.theverge.com/2023/6/16/23763208/mercedes-benz-chatgpt-voice-assistant-beta-test)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-06-16 09:25:49+00:00

<figure>
      <img alt="Car Logos In The Rain In Krakow" src="https://cdn.vox-cdn.com/thumbor/ynZfa8TPugUZ5BDpj74jRLRuXKQ=/0x0:3141x2094/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72375848/1258278552.0.jpg" />
        <figcaption>Photo illustration by Klaudia Radecka/NurPhoto via Getty Images</figcaption>
    </figure>

  <p id="lyiMdo">Mercedes-Benz is <a href="https://media.mbusa.com/releases/release-b35d2af89e06f556bbd8fe420412e9c2-mercedes-benz-takes-in-car-voice-control-to-a-new-level-with-chatgpt">beta-testing ChatGPT</a> as a voice assistant in its cars. The company says drivers will be able engage the chatbot in a variety of conversations, asking “for details about their destination, to suggest a new dinner recipe, or to answer a complex question” — all “while keeping their hands on the wheel and eyes on the road.”</p>
<p id="rL8xEk">The beta program will be available to over 900,000 vehicles in the US equipped with Mercedes-Benz’s MBUX infotainment system. Drivers can activate the experimental program from June 16 with the voice command “Hey Mercedes, I want to join the beta program.” The update will then be installed over the air free of charge, expanding the capabilities of the company’s existing voice assistant using ChatGPT. </p>
<div class="c-float-left c-float-hang"><aside id="VV5mM6"><q>I...</q></aside></div>
  <p>
    <a href="https://www.theverge.com/2023/6/16/23763208/mercedes-benz-chatgpt-voice-assistant-beta-test">Continue reading&hellip;</a>
  </p>

## Reddit CEO Steve Huffman isn’t backing down: our full interview
 - [https://www.theverge.com/2023/6/15/23762868/reddit-ceo-steve-huffman-interview](https://www.theverge.com/2023/6/15/23762868/reddit-ceo-steve-huffman-interview)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-06-16 01:00:00+00:00

<figure>
      <img alt="A photo of Reddit CEO Steve Huffman over an orange and white background." src="https://cdn.vox-cdn.com/thumbor/4STVc8dZO0Rp3A7pWnDzTw9V_mM=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72375296/236702_Steve_Huffman_Interview_WJoel.0.jpg" />
        <figcaption>Photo illustration by William Joel / The Verge | Photo by Greg Doherty / Variety via Getty Images</figcaption>
    </figure>

  <p class="p--has-dropcap c-end-para" id="aAhulA">Reddit is fighting for its soul. Many users are <a href="https://www.theverge.com/2023/6/10/23756476/reddit-protest-api-changes-apollo-third-party-apps">in revolt</a> over API pricing changes that will shut down some of the <a href="https://www.theverge.com/2023/6/8/23754183/apollo-reddit-app-shutting-down-api">most popular</a> <a href="https://www.theverge.com/2023/6/8/23754616/reddit-third-party-apps-api-shutdown-rif-reddplanet-sync">third-party Reddit apps</a>, and they’re furious at CEO Steve Huffman after last week’s AMA that made it clear <a href="https://www.theverge.com/2023/6/9/23755640/reddit-api-changes-apps-apollo-shut-down-ama-spez-steve-huffman">the platform wouldn’t budge</a>. Huffman has argued the changes are a business decision to force AI companies training on Reddit’s data to <a href="https://www.theverge.com/2023/4/18/23688463/reddit-developer-api-terms-change-monetization-ai">pony up</a>, but they’re also wiping out some beloved Reddit apps, and thousands of subreddits <a href="https://www.theverge.com/2023/6/15/23762103/reddit-protest-api-changes-indefinite">have gone dark for days in protest</a>.</p>
<p id="VEivvj">On Thursday, Reddit offered me an interview with Huffman. I’ve already published one story from that conversation about how Reddit was apparently <a href="https://www.theverge.com/2023/6/15/23762501/reddit-ceo-steve-huffman-interview-protests-blackout">never designed to support third-party apps</a>. But here is a lightly edited transcript of the entire...</p>
  <p>
    <a href="https://www.theverge.com/2023/6/15/23762868/reddit-ceo-steve-huffman-interview">Continue reading&hellip;</a>
  </p>

