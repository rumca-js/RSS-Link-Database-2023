# Source:Politico, URL:https://rss.politico.com/politics-news.xml, language:en-US

## Why federal prosecutors may have handed Trump a huge gift
 - [https://www.politico.com/news/2023/06/16/federal-prosecutors-trump-indictment-parlatore-00102371](https://www.politico.com/news/2023/06/16/federal-prosecutors-trump-indictment-parlatore-00102371)
 - RSS feed: https://rss.politico.com/politics-news.xml
 - date published: 2023-06-16 04:00:00+00:00

Ex-Trump lawyer Tim Parlatore goes deep on the dynamics dividing Trump’s legal team and why the tactics that federal prosecutors used to secure an indictment in the documents case may be their undoing.

## The nation’s cartoonists on the week in politics
 - [https://www.politico.com/gallery/2023/06/16/the-nations-cartoonists-on-the-week-in-politics-00102193](https://www.politico.com/gallery/2023/06/16/the-nations-cartoonists-on-the-week-in-politics-00102193)
 - RSS feed: https://rss.politico.com/politics-news.xml
 - date published: 2023-06-16 03:30:00+00:00

Every week political cartoonists throughout the country and across the political spectrum apply their ink-stained skills to capture the foibles, memes, hypocrisies and other head-slapping events in the world of politics. The fruits of these labors are hundreds of cartoons that entertain and enrage readers of all political stripes. Here's an offering of the best of this week's crop, picked fresh off the Toonosphere. Edited by Claudine Hellmuth.

