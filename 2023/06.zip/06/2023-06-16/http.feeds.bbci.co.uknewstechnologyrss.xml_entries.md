# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Amazon cleared to buy iRobot vacuum cleaner maker
 - [https://www.bbc.co.uk/news/business-65925221?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-65925221?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-06-16 09:45:21+00:00

The UK competition watchdog says the online giant can buy iRobot, the maker of Roomba cleaners.

## Harry and Meghan: Spotify ends podcast deal with couple
 - [https://www.bbc.co.uk/news/uk-65924584?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-65924584?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-06-16 03:02:27+00:00

The couple's company and the streaming firm say the Duchess's series Archetypes has been cancelled.

