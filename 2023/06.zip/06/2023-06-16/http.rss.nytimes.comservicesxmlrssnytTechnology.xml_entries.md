# Source:NY times technology, URL:http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml, language:en-US

## Meta to Lower Age for Users of Quest VR Headset to 10 From 13
 - [https://www.nytimes.com/2023/06/16/technology/meta-virtual-reality-headset-children-safety.html](https://www.nytimes.com/2023/06/16/technology/meta-virtual-reality-headset-children-safety.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-06-16 21:07:58+00:00

The company has reached out to regulators about its plans, which could set off privacy and safety concerns for parents and watchdogs.

## Twitch Star Signs $100 Million Deal With Rival Platform
 - [https://www.nytimes.com/2023/06/16/business/twitch-kick-xqc.html](https://www.nytimes.com/2023/06/16/business/twitch-kick-xqc.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-06-16 21:00:09+00:00

The deal signed by Félix Lengyel, known as xQc, matches traditional athletes’ contracts, and is another sign of Twitch’s tense relationship with its top streamers.

## Meta to Lower Age for Users of Quest VR Headset to 10 From 13
 - [https://www.nytimes.com/2023/06/16/business/meta-virtual-reality-headset-children-safety.html](https://www.nytimes.com/2023/06/16/business/meta-virtual-reality-headset-children-safety.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-06-16 19:41:28+00:00

The company has reached out to regulators about its plans, which could set off privacy and safety concerns for parents and watchdogs.

## How to Use A.I. as a Shopping Assistant
 - [https://www.nytimes.com/2023/06/16/technology/how-to-use-ai-as-a-shopping-assistant.html](https://www.nytimes.com/2023/06/16/technology/how-to-use-ai-as-a-shopping-assistant.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-06-16 16:15:54+00:00

Doing product research, making grocery lists and booking travel can be easier with tools like ChatGPT.

## The Titanic Truthers of TikTok
 - [https://www.nytimes.com/2023/06/16/business/titanic-tiktok-misinformation.html](https://www.nytimes.com/2023/06/16/business/titanic-tiktok-misinformation.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-06-16 13:00:20+00:00

On the short-form video app, long-established facts about the 1912 disaster at sea are being newly litigated as musty rumors merge with fresh misinformation and manipulated content.

## Bill Gates Meets Xi Jinping in First Visit to China Since 2019
 - [https://www.nytimes.com/2023/06/16/business/bill-gates-xi-jinping.html](https://www.nytimes.com/2023/06/16/business/bill-gates-xi-jinping.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-06-16 11:10:20+00:00

China’s president, Xi Jinping, calls Mr. Gates “the first American friend I met in Beijing this year.”

## Reddit Revolts, MrBeast’s YouTube Empire and Peak Trust and Safety?
 - [https://www.nytimes.com/2023/06/16/podcasts/reddit-revolts-mrbeasts-youtube-empire-and-peak-trust-and-safety.html](https://www.nytimes.com/2023/06/16/podcasts/reddit-revolts-mrbeasts-youtube-empire-and-peak-trust-and-safety.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-06-16 09:06:46+00:00

Social platforms are entering a strange and uncertain future.

