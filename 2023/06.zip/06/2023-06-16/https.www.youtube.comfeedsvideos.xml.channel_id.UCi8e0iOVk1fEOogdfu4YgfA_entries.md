# Source:Rotten Tomatoes Trailers, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCi8e0iOVk1fEOogdfu4YgfA, language:en-US

## Spider-Man: Across the Spider-Verse Trailer - Voice Cast Dubs (2023)
 - [https://www.youtube.com/watch?v=JOvCmGhpGe8](https://www.youtube.com/watch?v=JOvCmGhpGe8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCi8e0iOVk1fEOogdfu4YgfA
 - date published: 2023-06-16 19:37:29+00:00

Check out the official trailer for Spider-Man: Across the Spider-Verse starring Shameik Moore! 

► Sign up for a Fandango FanAlert: https://www.fandango.com/spider-man-across-the-spider-verse-2023-226752/movie-overview?cmp=Trailers_YouTube_Desc

Subscribe to the channel and click the bell icon to be notified of all the hottest trailers: http://bit.ly/2CNniBy 

US Release Date: June 2, 2023
Starring: Hailee Steinfeld, Oscar Isaac, Shameik Moore
Director: Joaquim Dos Santos, Justin K. Thompson, Kemp Powers
Synopsis: The further adventures of Miles Morales, aka Spider-Man.

► Learn more: https://www.rottentomatoes.com/m/spider_man_across_the_spider_verse?cmp=Trailers_YouTube_Desc 

Watch More:  
► Rotten Tomatoes Originals: http://bit.ly/2D3sipV    
► Fresh New Clips: https://bit.ly/3mJePrv    
► Hot New Trailers: http://bit.ly/2qThrsF   
► New TV This Week: https://bit.ly/3Or3I2w   
 
Rotten Tomatoes TRAILERS delivers hot new trailers, exclusive content, and first looks for all the best upcoming movies. Be the first to see everything coming to theaters and your favorite streaming platforms - all in one place!

#SpiderManAcrossTheSpiderVerse #SpiderMan

