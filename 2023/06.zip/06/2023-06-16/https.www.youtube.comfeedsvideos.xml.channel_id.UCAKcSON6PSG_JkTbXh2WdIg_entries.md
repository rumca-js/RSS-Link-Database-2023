# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Robyn Hitchcock – three-song performance (live for The Current)
 - [https://www.youtube.com/watch?v=dmRrsitr1IA](https://www.youtube.com/watch?v=dmRrsitr1IA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2023-06-16 02:00:09+00:00

Prior to the pandemic, Robyn Hitchcock had never spent a protracted time off the road. While at home in Nashville, Hitchcock and his wife, singer-songwriter Emma Swift, started a record label (Tiny Ghost Records), and for a time, Hitchcock immersed himself in painting. But soon, he found he couldn’t stop writing songs. 

One of the results of those efforts is the new album, "Shufflemania!," released in late 2022. Hitchcock, touring once again, visited The Current studio to play songs from that album.

Watch and listen to the full session, including Hitchcock's interview with host Bill DeVille, posted here: https://youtu.be/lBr4iZZonX4 

Video Segments
00:00:00 The Inner Life of Scorpio
00:04:12 The Man Who Loves The Rain
00:08:39 One Day (It’s Being Scheduled)
All songs from Robyn Hitchcock's 2022 album, 'Shufflemania!', available on Tiny Ghost Records. 

Credits
Guest – @robynhitchcockweb 
Host – Bill DeVille
Producer – Derrick Stevens
Video Director – Evan Clark
Camera Operator – Peter Ecklund, Evan Clark
Audio – Eric Xu Romani
Graphics – Natalia Toledo
Digital Producer – Luke Taylor

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube  

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1  

Like/Follow:
https://www.facebook.com/TheCurrent/  
https://twitter.com/TheCurrent  
https://www.instagram.com/thecurrent/
https://www.tiktok.com/@thecurrent.org

#robynhitchcock #acoustic #studio

