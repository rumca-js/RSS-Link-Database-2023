# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## Węgry. Viktor Orban: Donald Trump jest w stanie zakończyć wojnę w Ukrainie i zawrzeć pokój
 - [https://www.polsatnews.pl/wiadomosc/2023-06-16/wegry-viktor-orban-donald-trump-jest-w-stanie-zakonczyc-wojne-i-zawrzec-pokoj/](https://www.polsatnews.pl/wiadomosc/2023-06-16/wegry-viktor-orban-donald-trump-jest-w-stanie-zakonczyc-wojne-i-zawrzec-pokoj/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-06-16 19:55:00+00:00

- Węgry byłyby zainteresowane zobaczeniem orędownika pokoju u steru Stanów Zjednoczonych - twierdzi Viktor Orban. Premier Węgier jest przekonany, że powrót byłego prezydenta USA do Białego Domu oznaczałby zakończenie wojny w Ukrainie.

## Trzęsienie ziemi we Francji. Różne informacje o jego sile
 - [https://www.polsatnews.pl/wiadomosc/2023-06-16/trzesienie-ziemi-we-francji-rozne-informacje-o-jego-sile/](https://www.polsatnews.pl/wiadomosc/2023-06-16/trzesienie-ziemi-we-francji-rozne-informacje-o-jego-sile/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-06-16 17:12:00+00:00

Trzęsienie ziemi o magnitudzie 5 odnotowano w piątek we Francji - przekazały niemieckie służby geologiczne. Inne szacunki mówią, że wstrząsy miały siłę nawet 5,5-5,9. Głębokość hipocentrum wstrząsu oszacowano na 10 km. Na razie nie ma informacji o zniszczeniach lub ofiarach śmiertelnych trzęsienia.

## Władimir Putin nie wyklucza ataków poza Ukrainą. "NATO jest wciągane w konflikt"
 - [https://www.polsatnews.pl/wiadomosc/2023-06-16/wladimir-putin-nie-wyklucza-atakow-poza-ukraina-nato-jest-wciagane-w-konflikt/](https://www.polsatnews.pl/wiadomosc/2023-06-16/wladimir-putin-nie-wyklucza-atakow-poza-ukraina-nato-jest-wciagane-w-konflikt/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-06-16 16:29:00+00:00

- W żadnych z obszarów Ukraina nie osiągnęła swoich celów. Rzeczywiście, ich straty są bardzo duże. Mniej więcej jeden na dziesięć w porównaniu z armią rosyjską - stwierdził Władimir Putin. Prezydent Rosji przemawiał w trakcie sesji plenarnej Międzynarodowego Forum Ekonomicznego w Petersburgu.

## Kryzys na Krymie po eksplozji tamy. Ekspert: Wody nie będzie minimum rok
 - [https://www.polsatnews.pl/wiadomosc/2023-06-16/tragiczna-sytuacja-na-krymie-ekspert-wody-nie-bedzie-minimum-rok/](https://www.polsatnews.pl/wiadomosc/2023-06-16/tragiczna-sytuacja-na-krymie-ekspert-wody-nie-bedzie-minimum-rok/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-06-16 15:01:00+00:00

Wysadzenie w powietrze tamy w Nowej Kachowce niesie za sobą ogromne problemy nie tylko w obwodzie chersońskim, ale także dla Półwyspu Krymskiego. Dostęp do bieżącej wody na zaanektowanym przez Rosję terenie będzie utrudniony co najmniej przez rok.

## Pobił rekord świata w układaniu kostki Rubika. Wystarczyło trzy i pół sekundy [WIDEO]
 - [https://www.polsatnews.pl/wiadomosc/2023-06-16/pobil-rekord-swiata-w-ukladaniu-kostki-rubika-wystarczylo-trzy-i-pol-sekundy-wideo/](https://www.polsatnews.pl/wiadomosc/2023-06-16/pobil-rekord-swiata-w-ukladaniu-kostki-rubika-wystarczylo-trzy-i-pol-sekundy-wideo/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-06-16 14:42:00+00:00

Młody Amerykanin pobił rekord świata w prędkości układania kostki Rubika. Wcześniej zagadkę logiczną w czasie poniżej trzy i pół sekundy udało się rozwiązać zaledwie jednej osobie. Kilka dni temu poprzedni rekordzista został jednak zdetronizowany przez 21-latka z Kalifornii.

## Jewgienij Prigożyn oddał swój samochód żonie zmarłego żołnierza. Kobieta ma poważne problemy
 - [https://www.polsatnews.pl/wiadomosc/2023-06-16/jewgienij-prigozyn-oddal-swoj-samochod-zonie-zmarlego-zolnierza-kobieta-ma-powazne-problemy/](https://www.polsatnews.pl/wiadomosc/2023-06-16/jewgienij-prigozyn-oddal-swoj-samochod-zonie-zmarlego-zolnierza-kobieta-ma-powazne-problemy/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-06-16 14:28:00+00:00

Jewgienij Prigożyn kolejny raz próbuje budować pozytywny PR wśród rodzin najemników grupy Wagnera. Lider prywatnej armii postanowił podarować swój samochód żonie zmarłego bojownika. Nie wziął jednak pod uwagę, że w ten sposób pogłębi finansowe problemy obdarowanej.

## Jens Stoltenberg: Ukraina będzie w NATO, a Rosja nie ma prawa weta
 - [https://www.polsatnews.pl/wiadomosc/2023-06-16/jens-stoltenberg-ukraina-bedzie-w-nato-a-rosja-nie-ma-prawa-weta/](https://www.polsatnews.pl/wiadomosc/2023-06-16/jens-stoltenberg-ukraina-bedzie-w-nato-a-rosja-nie-ma-prawa-weta/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-06-16 13:41:00+00:00

- Pracujemy nad pakietem wieloletnim finansowaniem sektora militarnego Ukrainy, które zapewni jej pełną interoperacyjność z NATO, aby udaremnić jakąkolwiek rosyjską napaść - oświadczył sekretarz generalny NATO Jens Stoltenberg. - Ukraina będzie w NATO, a Rosja nie ma tutaj prawa weta - dodał szef Sojuszu Północnoatlantyckiego.

## Szef ukraińskiego MSZ: Rosyjskie rakiety to wiadomość dla Afryki, że Rosja chce wojny
 - [https://www.polsatnews.pl/wiadomosc/2023-06-16/szef-ukrainskiego-msz-rosyjskie-rakiety-to-wiadomosc-dla-afryki-ze-rosja-chce-wojny/](https://www.polsatnews.pl/wiadomosc/2023-06-16/szef-ukrainskiego-msz-rosyjskie-rakiety-to-wiadomosc-dla-afryki-ze-rosja-chce-wojny/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-06-16 12:48:00+00:00

Rosjanie przeprowadzili największy od wielu dni atak rakietowy na Kijów. - Zbiegł się w czasie z przyjazdem afrykańskiej misji pokojowej do stolicy Ukrainy. Rosyjskie rakiety to wiadomość dla Afryki: Rosja chce wojny, a nie pokoju - skomentował Dmytro Kułeba, minister spraw zagranicznych Ukrainy.

## Rosja. Żołnierze dostają premie za zniszczenie zachodniego sprzętu. Ministerstwo podało kwoty
 - [https://www.polsatnews.pl/wiadomosc/2023-06-16/rosja-zolnierze-dostaja-premie-za-zniszczenie-zachodniego-sprzetu-ministerstwo-podalo-kwoty/](https://www.polsatnews.pl/wiadomosc/2023-06-16/rosja-zolnierze-dostaja-premie-za-zniszczenie-zachodniego-sprzetu-ministerstwo-podalo-kwoty/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-06-16 11:23:00+00:00

Wojska, które zniszczyły niemieckie czołgi Leopard i dostarczone przez USA pojazdy opancerzone używane przez Ukrainę, otrzymają premie - poinformowało w piątek rosyjskie Ministerstwo Obrony. Wiadomo, jakie kwoty otrzymują żołnierze za wyeliminowanie zachodniego sprzętu.

## Katastrofa ekologiczna w Ukrainie. Greta Thunberg wyśmiała działania ONZ
 - [https://www.polsatnews.pl/wiadomosc/2023-06-16/katastrofa-ekologiczna-w-ukrainie-greta-thunberg-wysmiala-dzialania-onz/](https://www.polsatnews.pl/wiadomosc/2023-06-16/katastrofa-ekologiczna-w-ukrainie-greta-thunberg-wysmiala-dzialania-onz/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-06-16 10:41:00+00:00

Greta Thunberg uważa, że działania ONZ po wysadzeniu tamy w Nowej Kachowce, są niewystarczające. Zapytana przez dziennikarzy o ocenę pracy organizacji w Ukrainie, zareagowała śmiechem.

## Niemcy. Niezwykłe odkrycie w grobie. Broń sprzed 3 tysięcy lat
 - [https://www.polsatnews.pl/wiadomosc/2023-06-16/niemcy-niezwykle-odkrycie-w-grobie-bron-sprzed-3-tys-lat/](https://www.polsatnews.pl/wiadomosc/2023-06-16/niemcy-niezwykle-odkrycie-w-grobie-bron-sprzed-3-tys-lat/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-06-16 09:47:00+00:00

Dobrze zachowany miecz sprzed 3000 lat został znaleziony w południowych Niemczech. - Jego stan jest wyjątkowy. Takie znalezisko jest bardzo rzadkie!- powiedział Mathias Pfeil z Urzędu Ochrony Zabytków. Archeolodzy mają hipotezy odnośnie funkcji tej starożytnej broni.

## Pierwszy komercyjny lot w kosmos. Start pod koniec czerwca
 - [https://www.polsatnews.pl/wiadomosc/2023-06-16/pierwszy-komercyjny-lot-w-kosmos-start-pod-koniec-czerwca/](https://www.polsatnews.pl/wiadomosc/2023-06-16/pierwszy-komercyjny-lot-w-kosmos-start-pod-koniec-czerwca/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-06-16 09:36:00+00:00

Jeszcze w tym miesiącu wystartuje pierwszy komercyjny lot w kosmos - zapowiedziała firma Virgin Galactic, która zajmuje się kosmiczną turystyką. Kolejny start przewidywany jest na sierpień, po czym wycieczki w kosmos mają odbywać się co miesiąc.

## Watykan. Papież Franciszek został wypisany ze szpitala
 - [https://www.polsatnews.pl/wiadomosc/2023-06-16/watykan-papiez-franciszek-zostal-wypisany-ze-szpitala/](https://www.polsatnews.pl/wiadomosc/2023-06-16/watykan-papiez-franciszek-zostal-wypisany-ze-szpitala/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-06-16 08:25:00+00:00

Po dziewięciodniowej hospitalizacji papież został wypisany ze szpitala. Lekarz, który operował Franciszka, powiedział, że ojciec święty jest silniejszy niż wcześniej. Papież w ubiegłym tygodniu przeszedł zabieg laparotomii i operację jamy brzusznej.

## USA. Al Pacino został ojcem po raz czwarty w wieku 83 lat
 - [https://www.polsatnews.pl/wiadomosc/2023-06-16/usa-al-pacino-zostal-ojcem-po-raz-czwarty-w-wieku-83-lat/](https://www.polsatnews.pl/wiadomosc/2023-06-16/usa-al-pacino-zostal-ojcem-po-raz-czwarty-w-wieku-83-lat/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-06-16 05:24:00+00:00

Amerykański aktor, 83-letni Al Pacino, został po raz czwarty ojcem. Na świat przyszedł chłopiec, którego matką jest 29-letnia partnerka gwiazdora Noor Alfallah. Para zdradziła, jakie dziecko otrzyma imię.

## Kanada. Tragiczny wypadek na autostradzie. Zginęło 15 osób
 - [https://www.polsatnews.pl/wiadomosc/2023-06-16/kanada-tragiczny-wypadek-na-autostradzie-zginelo-15-osob/](https://www.polsatnews.pl/wiadomosc/2023-06-16/kanada-tragiczny-wypadek-na-autostradzie-zginelo-15-osob/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-06-16 04:35:00+00:00

Co najmniej 15 osób zginęło w zderzeniu ciężarówki z autobusem, przewożącym seniorów w prowincji Manitoba na autostradzie nr 5 w Kanadzie - przekazał na konferencji prasowej Rob Lasson z lokalnej policji.

