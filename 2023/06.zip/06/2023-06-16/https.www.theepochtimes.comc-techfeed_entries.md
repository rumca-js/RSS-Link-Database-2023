# Source:Epoch Times Tech, URL:https://www.theepochtimes.com/c-tech/feed/, language:en-US

## Musk Aims for Twitter to Be a ‘Positive Force for Civilization’
 - [https://www.theepochtimes.com/musk-aims-for-twitter-to-be-a-positive-force-for-civilization_5339106.html](https://www.theepochtimes.com/musk-aims-for-twitter-to-be-a-positive-force-for-civilization_5339106.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2023-06-16 22:32:20+00:00

Elon Musk's Twitter profile on a smartphone placed on printed Twitter logos on April 28, 2022. (Dado Ruvic/Illustration/Reuters)

## Chinese Leader Xi Jinping Meets With Bill Gates Ahead of Blinken Visit
 - [https://www.theepochtimes.com/chinese-leader-xi-jinping-meets-with-bill-gates-ahead-of-blinken-visit_5335036.html](https://www.theepochtimes.com/chinese-leader-xi-jinping-meets-with-bill-gates-ahead-of-blinken-visit_5335036.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2023-06-16 21:56:31+00:00

Bill Gates (L) meets with Chinese leader Xi Jinping in Beijing on June 16, 2023. (Yin Bogu/Xinhua via AP)

## Meta’s Facebook, Instagram Down for Thousands of Users, Says Downdetector
 - [https://www.theepochtimes.com/metas-facebook-instagram-down-for-thousands-of-users-says-downdetector_5338794.html](https://www.theepochtimes.com/metas-facebook-instagram-down-for-thousands-of-users-says-downdetector_5338794.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2023-06-16 20:47:28+00:00

A keyboard is placed in front of a displayed Facebook logo in an illustration taken on Feb. 21, 2023. (Dado Ruvic/Illustration/Reuters)

## TikTok Reveals Everything About Users and Those Around Them: Expert
 - [https://www.theepochtimes.com/tiktok-reveals-everything-about-users-and-those-around-them-expert_5336973.html](https://www.theepochtimes.com/tiktok-reveals-everything-about-users-and-those-around-them-expert_5336973.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2023-06-16 18:50:48+00:00

TikTok logo on an iPhone in London on Feb. 28, 2023. (Dan Kitwood/Getty Images)

## TikTok to Invest Billions of Dollars in Southeast Asia to Boost E-Commerce Business
 - [https://www.theepochtimes.com/tiktok-to-invest-billions-of-dollars-in-southeast-asia-to-boost-e-commerce-business_5335055.html](https://www.theepochtimes.com/tiktok-to-invest-billions-of-dollars-in-southeast-asia-to-boost-e-commerce-business_5335055.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2023-06-16 06:48:03+00:00

TikTok Chief Executive Officer Shou Zi Chew delivers his speech during the launch of TikTok Socio-Economic Impact Report 2023 event at The Ritz Carlton, Pacific Place in Jakarta, Indonesia, on June 15, 2023. (Ajeng Dinar Ulfiana/Reuters)

