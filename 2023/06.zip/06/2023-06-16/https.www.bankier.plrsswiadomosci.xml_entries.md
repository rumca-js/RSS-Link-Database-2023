# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Rodzice żądają od rządu Portugalii zakazu używania smartfonów w szkołach
 - [https://www.bankier.pl/wiadomosc/Rodzice-zadaja-od-rzadu-Portugalii-zakazu-uzywania-smartfonow-w-szkolach-8562100.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rodzice-zadaja-od-rzadu-Portugalii-zakazu-uzywania-smartfonow-w-szkolach-8562100.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 21:05:12.815254+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/f/74487fb7dcdbfc-948-568-0-0-2564-1538.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />17 tys. rodziców gimnazjów w Portugalii podpisało się pod otwartą petycją do rządu Antonia Costy z żądaniem wprowadzenia zakazu wnoszenia przez uczniów smartfonów na teren szkół.</p>

## Wall Street kończy najlepszy tydzień od marca lekkimi spadkami
 - [https://www.bankier.pl/wiadomosc/Wall-Street-konczy-najlepszy-tydzien-od-marca-lekkimi-spadkami-8562096.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wall-Street-konczy-najlepszy-tydzien-od-marca-lekkimi-spadkami-8562096.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 21:05:12.792561+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/f/73f16338479b89-948-568-90-25-1910-1145.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Piątkowa sesja na Wall Street zakończyła się lekkimi spadkami głównych indeksów, ale i tak dla S&amp;P 500 i Nasdaq to był najlepszy tydzień od marca 2023 roku.</p>

## Liczba mieszkańców Kanady przekroczyła 40 mln. Populacja kraju rośnie najszybciej od 65 lat
 - [https://www.bankier.pl/wiadomosc/Liczba-mieszkancow-Kanady-przekroczyla-40-mln-Populacja-kraju-rosnie-najszybciej-od-65-lat-8562087.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Liczba-mieszkancow-Kanady-przekroczyla-40-mln-Populacja-kraju-rosnie-najszybciej-od-65-lat-8562087.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 20:38:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/6/9a38b28071b6dd-948-568-0-48-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Liczba mieszkańców Kanady przekroczyła w piątek 40 mln, populacja kraju rośnie najszybciej od 65 lat – podał w komunikacie kanadyjski urząd statystyczny, Statistics Canada.</p>

## Embargo na rosyjski gaz LPG. Opozycja apeluje do premiera o poparcie ich projektu
 - [https://www.bankier.pl/wiadomosc/Embargo-na-rosyjski-gaz-LPG-Opopzycja-apeluje-do-premiera-o-poparcie-ich-projektu-8562076.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Embargo-na-rosyjski-gaz-LPG-Opopzycja-apeluje-do-premiera-o-poparcie-ich-projektu-8562076.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 20:02:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/1/eb1d1e058055aa-948-568-0-0-1000-600.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Politycy opozycji zaapelowali w piątek do premiera 
Mateusza Morawieckiego o poparcie ich projektu ws. embarga na rosyjski 
gaz LPG. "Jeśli podlegli panu urzędnicy lekceważą pana deklaracje w 
ważnych dla Polski sprawach, zbudujmy porozumienie ponad podziałami; 
uwolnijmy Polskę od rosyjskiego gazu" - mówili.</p>

## Drogie materiały budowlane. To zdrożało najmocniej
 - [https://www.bankier.pl/wiadomosc/Drogie-materialy-budowlane-To-zdrozalo-najmocniej-8562061.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Drogie-materialy-budowlane-To-zdrozalo-najmocniej-8562061.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 19:17:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/e/646f4d6efa79c4-948-567-0-67-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ceny materiałów budowlanych w ciągu pierwszych pięciu miesięcy tego roku wzrosły o 10 proc., w porównaniu z analogicznym okresem 2022 r. - podała w piątek Grupa PSB Handel. Najmocniej, o 35 proc. zdrożały cement i wapno.</p>

## Wybory parlamentarne 2023. Gowin nie będzie kandydował
 - [https://www.bankier.pl/wiadomosc/Wybory-parlamentarne-2023-Gowin-nie-bedzie-kandydowal-8562044.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wybory-parlamentarne-2023-Gowin-nie-bedzie-kandydowal-8562044.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 18:35:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/3/e6b923670ed8b5-948-568-0-43-1732-1039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Jarosław Gowin nie będzie kandydował w zbliżających się wyborach parlamentarnych - donosi Interia. Portal opublikował też treść oświadczenia byłego wicepremiera w tej sprawie.</p>

## Nowelizacja budżetu na 2023 rok i zwiększenie deficytu o 24 mld zł. Sejm zdecydował
 - [https://www.bankier.pl/wiadomosc/Nowelizacja-budzetu-na-2023-rok-i-zwiekszenie-deficytu-o-24-mld-zl-Sejm-zdecydowal-8562043.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nowelizacja-budzetu-na-2023-rok-i-zwiekszenie-deficytu-o-24-mld-zl-Sejm-zdecydowal-8562043.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 18:34:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/b/edeb868e23cc41-948-568-0-180-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W piątek podczas głosowania Sejm opowiedział się przeciw odrzuceniu projektów ustawy budżetowej i ustawy okołobudżetowej i zdecydował o skierowaniu obu tych projektów do komisji.</p>

## KNF: nadal jest przestrzeń na zawieranie ugód pomiędzy frankowcami a bankami
 - [https://www.bankier.pl/wiadomosc/KNF-nadal-jest-przestrzen-na-zawieranie-ugod-pomiedzy-frankowcami-a-bankami-8562032.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/KNF-nadal-jest-przestrzen-na-zawieranie-ugod-pomiedzy-frankowcami-a-bankami-8562032.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 18:22:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/b/ba03872ba3424e-945-560-1181-0-2850-1709.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Czwartkowy wyrok TSUE dotyczący wynagrodzenia za korzystanie z kapitału po unieważnieniu umowy kredytu w CHF może utrudniać poszukiwanie rozwiązań proporcjonalnych w rozliczeniach pomiędzy frankowiczami i bankami — ocenia przewodniczący KNF Jacek Jastrzębski.</p>

## Szwecja ogłosiła 12. pakiet pomocy dla Ukrainy o wartości 250 mln koron
 - [https://www.bankier.pl/wiadomosc/Szwecja-oglosila-12-pakiet-pomocy-dla-Ukrainy-o-wartosci-250-mln-koron-8562034.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Szwecja-oglosila-12-pakiet-pomocy-dla-Ukrainy-o-wartosci-250-mln-koron-8562034.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 18:22:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/a/99ed299cb3dab3-948-568-0-31-1798-1079.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rząd Szwecji ogłosił w piątek 12. pakiet pomocy dla Ukrainy. Darowizna o łącznej wartości 250 mln koron (ok. 21 mln euro) zasili fundusze brytyjski oraz NATO na zakup broni oraz umożliwi szkolenia ukraińskich pilotów na myśliwcach Gripen.</p>

## Emerytury pomostowe zostają i będą przysługiwać większej grupie. Sejm zdecydował
 - [https://www.bankier.pl/wiadomosc/Emerytury-pomostowe-zostaja-i-beda-przyslugiwac-wiekszej-grupie-Sejm-zdecydowal-8562020.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Emerytury-pomostowe-zostaja-i-beda-przyslugiwac-wiekszej-grupie-Sejm-zdecydowal-8562020.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 18:11:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/9/6f83c3e7cf57d2-948-568-0-254-2715-1628.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sejm uchwalił nowelizację ustawy o emeryturach pomostowych uchylającą wygasający charakter tego świadczenia. Będą one przysługiwać również osobom, które nie posiadają stażu pracy w warunkach szczególnych przed 1 stycznia 1999 r.</p>

## Francję nawiedziło trzęsienie ziemi
 - [https://www.bankier.pl/wiadomosc/Francje-nawiedzilo-trzesienie-ziemi-8562018.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Francje-nawiedzilo-trzesienie-ziemi-8562018.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 18:08:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/6/01a8c75fc457e9-948-568-0-270-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Francję nawiedziło w piątek trzęsienie ziemi o magnitudzie 5. Hipocentrum wstrząsu było na głębokości 10 km - poinformowały niemieckie służby geologiczne GFZ.</p>

## Komisja ds. rosyjskich wpływów. Sejm przyjął poprawki zgłoszone przez prezydenta Dudę
 - [https://www.bankier.pl/wiadomosc/Komisja-ds-rosyjskich-wplywow-Sejm-przyjal-poprawki-zgloszone-przez-prezydenta-Dude-8562014.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Komisja-ds-rosyjskich-wplywow-Sejm-przyjal-poprawki-zgloszone-przez-prezydenta-Dude-8562014.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 18:06:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/9/dedeefff2005c4-948-568-0-174-4096-2457.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W piątek Sejm przyjął zgłoszoną przez prezydenta 
Andrzeja Dudę nowelizację ustawy o komisji ds. badania wpływów 
rosyjskich na bezpieczeństwo Polski. Jedna z głównych zmian dot. składu 
komisji, w której nie będą mogli zasiadać parlamentarzyści.</p>

## Już niewielu Polaków obawia się dalszego wzrostu cen
 - [https://www.bankier.pl/wiadomosc/Juz-niewielu-Polakow-obawia-sie-dalszego-wzrostu-cen-8562000.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Juz-niewielu-Polakow-obawia-sie-dalszego-wzrostu-cen-8562000.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 17:32:17.180423+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/a/5cd891286d99f6-948-568-12-0-987-592.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Tylko 14 proc. ankietowanych obawia się dalszego wzrostu cen, utrzymania podobnego tempa cen spodziewa się 45 proc. a spowolnienia a nawet spadku - 41 proc. -  wynika z opublikowanego w piątek badania firmy Ipsos. Jednocześnie 63 proc.  respondentów uważa, że sprawy w kraju idą w złym kierunku.</p>

## Polskie Linie Lotnicze LOT mają nowego prezesa
 - [https://www.bankier.pl/wiadomosc/Polskie-Linie-Lotnicze-LOT-maja-nowego-prezesa-8562007.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polskie-Linie-Lotnicze-LOT-maja-nowego-prezesa-8562007.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 17:32:17.177917+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/9/b441b08a388a52-948-568-40-290-3960-2375.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rada nadzorcza PLL LOT powołała Michała Fijoła na prezesa spółki; od blisko siedmiu lat odpowiadał w zarządzie za sprawy handlowe - poinformował w piątek PAP narodowy przewoźnik.</p>

## Płatności gotówką. Sejm uchwalił ustawę dotyczącą ich ograniczeń
 - [https://www.bankier.pl/wiadomosc/Platnosci-gotowka-Sejm-uchwalil-ustawe-dotyczaca-ich-ograniczen-8561987.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Platnosci-gotowka-Sejm-uchwalil-ustawe-dotyczaca-ich-ograniczen-8561987.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 17:32:17.163444+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/9/c1ce5d3d2ad1ca-948-568-0-119-3976-2385.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W piątek Sejm uchwalił ustawę uchylającą ograniczenia w płatnościach gotówką, dokonywanych przez konsumentów i przedsiębiorców, które miały wejść w życie 1 stycznia 2024 r.</p>

## Szybsza emerytura dla niektórych nauczycieli. Sejm uchwalił nowelizację
 - [https://www.bankier.pl/wiadomosc/Szybsza-emerytura-dla-niektorych-nauczycieli-Sejm-uchwalil-nowelizacje-8561956.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Szybsza-emerytura-dla-niektorych-nauczycieli-Sejm-uchwalil-nowelizacje-8561956.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 16:30:20.485831+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/4/719ad64dcd9969-948-568-0-0-3008-1804.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sejm uchwalił w piątek ustawę dającą prawo do emerytury na szczególnych zasadach nauczycielom, którzy podjęli pracę przed wprowadzeniem reformy emerytalnej z 1999 r. Ustawa wprowadza też zmiany m.in. w systemie szkolnictwa wyższego i instytutów naukowych.</p>

## Trzy wiedźmy i ponad 3 mld zł obrotu na GPW. WIG20 każdego dnia coraz wyżej
 - [https://www.bankier.pl/wiadomosc/Trzy-wiedzmy-i-ponad-3-mld-zl-obrotu-na-GPW-WIG20-kazdego-dnia-coraz-wyzej-8561897.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Trzy-wiedzmy-i-ponad-3-mld-zl-obrotu-na-GPW-WIG20-kazdego-dnia-coraz-wyzej-8561897.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 16:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/3/44f81693ea0cfe-945-567-26-56-1473-884.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Piątek kończy udany tydzień dla inwestujących w indeks największych polskich spółek. Ten pnie się coraz wyżej każdego dnia, ustanawiając nowe maksima hossy trwającej od października. Rozliczenie kontraktów terminowych, a zwłaszcza ostatnia godzina sesji zwana „godziną trzech wiedźm” przyniosły podwyższone obroty i większą aktywność na rynku.</p>

## USA przekażą 205 mln dolarów dodatkowej pomocy humanitarnej dla Ukrainy
 - [https://www.bankier.pl/wiadomosc/USA-przekaza-205-mln-dolarow-dodatkowej-pomocy-humanitarnej-dla-Ukrainy-8561932.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/USA-przekaza-205-mln-dolarow-dodatkowej-pomocy-humanitarnej-dla-Ukrainy-8561932.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 16:26:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/6/7f22c7f419333a-948-568-0-86-1930-1158.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Stany Zjednoczone przekażą 205 mln dolarów dodatkowej pomocy humanitarnej dla Ukrainy - ogłosił w piątek amerykański sekretarz stanu Antony Blinken. Pieniądze mają m.in. pomóc w łączeniu rodzin, rozdzielonych przez wojnę.</p>

## Media: Biden poparł skrócenie ścieżki Ukrainy do NATO
 - [https://www.bankier.pl/wiadomosc/Media-Biden-poparl-skrocenie-sciezki-Ukrainy-do-NATO-8561914.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Media-Biden-poparl-skrocenie-sciezki-Ukrainy-do-NATO-8561914.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 15:14:55.492558+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/d/a0f5ed4b8b7a4f-948-568-0-0-1037-622.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prezydent USA Joe BIden poparł propozycję sekretarza generalnego NATO Jensa Stoltenberga, by zrezygnować z wymogu przejścia przez mechanizm Planu Działań na rzecz Członkostwa (Membership Action Plan; MAP) w ramach akcesji Ukrainy do Sojuszu - podały "Washington Post" i Politico. Ma to potencjalnie skrócić jej drogę do członkostwa.</p>

## Prezydent skierował do TK wniosek ws. ustawy o komisji ds. rosyjskich wpływów
 - [https://www.bankier.pl/wiadomosc/Komisja-ds-rosyjskich-wplywow-Prezydent-Duda-skierowal-do-TK-wniosek-8561875.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Komisja-ds-rosyjskich-wplywow-Prezydent-Duda-skierowal-do-TK-wniosek-8561875.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 15:14:55.489778+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/c/af13e6c58479b8-948-568-0-80-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prezydent Andrzej Duda, zgodnie z zapowiedzią, skierował do Trybunału Konstytucyjnego, w trybie kontroli następczej, wniosek o zbadanie zgodności z konstytucją niektórych przepisów ustawy o komisji do spraw zbadania wpływów rosyjskich - poinformowała w piątek Kancelaria Prezydenta.</p>

## KSF-M widzi spadek realnych cen mieszkań i wzrost popytu na kredyty mieszkaniowe
 - [https://www.bankier.pl/wiadomosc/KSF-M-widzi-spadek-realnych-cen-mieszkan-i-wzrost-popytu-na-kredyty-mieszkaniowe-8561885.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/KSF-M-widzi-spadek-realnych-cen-mieszkan-i-wzrost-popytu-na-kredyty-mieszkaniowe-8561885.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 15:14:55.469488+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/1/eae5789bb736ab-948-568-0-118-1982-1189.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Komitet Stabilności Finansowej dot. nadzoru makroostrożnościowego (KSF-M) widzi wzrost popytu na kredyty mieszkaniowe i spadek cen realnych mieszkań - podał w komunikacie KSF-M.</p>

## Demograficzna zapaść w Japoni. W zeszłym roku roku urodziło się najmniej dzieci od 1899 r.
 - [https://www.bankier.pl/wiadomosc/Demograficzna-zapasc-w-Japoni-W-zeszlym-roku-roku-urodzilo-sie-najmniej-dzieci-od-1899-r-8561913.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Demograficzna-zapasc-w-Japoni-W-zeszlym-roku-roku-urodzilo-sie-najmniej-dzieci-od-1899-r-8561913.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 15:14:55.466764+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/c/dbbd8092775185-948-568-0-51-1732-1039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W ubiegłym roku w Japonii urodziło się zaledwie 770 747 dzieci; to najmniejsza liczba, od kiedy prowadzone są statystyki - wynika z danych Ministerstwa Zdrowia, Pracy i Opieki Społecznej cytowanych przez portal Nippon. Liczba zgonów była największa w okresie powojennym.</p>

## Fitch: wyrok TSUE bez istotnego wpływu na ratingi banków w krótkim terminie
 - [https://www.bankier.pl/wiadomosc/Fitch-wyrok-TSUE-bez-istotnego-wplywu-na-ratingi-bankow-w-krotkim-terminie-8561830.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Fitch-wyrok-TSUE-bez-istotnego-wplywu-na-ratingi-bankow-w-krotkim-terminie-8561830.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 13:59:38.567067+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/5/9c3c18dcd8d49b-945-560-123-416-4312-2587.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W ocenie agencji Fitch wyrok TSUE nie będzie miał istotnego wpływu na ratingi banków w krótkim terminie - podano w raporcie Fitch. Według agencji niektóre banki mogą zanotować przejściowe straty w związku z zawiązywaniem rezerw na kredyty CHF.</p>

## Media a polityka. Czescy posłowie za zaostrzeniem ustawy o konflikcie interesów
 - [https://www.bankier.pl/wiadomosc/Media-a-polityka-Czescy-poslowieza-zaostrzeniem-ustawy-o-konflikcie-interesow-8561823.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Media-a-polityka-Czescy-poslowieza-zaostrzeniem-ustawy-o-konflikcie-interesow-8561823.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 13:59:38.564300+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/9/c6c8c7b4ea6019-916-550-5-2-916-550.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Czescy posłowie przegłosowali w piątek nowelizację ustawy o konflikcie interesów. Nowe przepisy, jeżeli zostaną zaakceptowane przez senat i podpisane przez prezydenta, zakażą politykom i funkcjonariuszom państwowym posiadania lub kontrolowania mediów.</p>

## Reuters: NATO nie udało się uzgodnić pierwszych od zimnej wojny planów obronnych
 - [https://www.bankier.pl/wiadomosc/Reuters-NATO-nie-udalo-sie-uzgodnic-pierwszych-od-zimnej-wojny-planow-obronnych-8561847.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Reuters-NATO-nie-udalo-sie-uzgodnic-pierwszych-od-zimnej-wojny-planow-obronnych-8561847.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 13:59:38.554284+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/c/5e3c33d4f9f75a-948-567-0-67-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Podczas dwudniowego spotkania ministrów obrony krajów Sojuszu Północnoatlantyckiego w Brukseli  nie udało się uzgodnić pierwszych od zimnej wojny planów obronnych NATO - podaje w piątek Reuters, powołując się na źródła. Według jednego z natowskich dyplomatów pewne decyzje zablokowała Turcja.</p>

## Rośnie rynek karmy dla psów i kotów. Polacy wydają setki milionów na jedzenie dla swoich pupili
 - [https://www.bankier.pl/wiadomosc/Rosnie-rynek-karmy-dla-psow-i-kotow-Polacy-wydaja-setki-milionow-na-jedzenie-dla-swoich-pupili-8561766.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rosnie-rynek-karmy-dla-psow-i-kotow-Polacy-wydaja-setki-milionow-na-jedzenie-dla-swoich-pupili-8561766.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 13:16:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/c/6b2997a2145f5b-948-568-0-90-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Od marca ub.r. do lutego 2023 r. właściciele psów i kotów wydali na karmę dla swoich pupili ponad 731 mln zł - wynika z danych pochodzących z Panelu Gospodarstw Domowych GfK Polonia. Pożywienie psa rocznie średnio kosztuje 292 zł, a kotów 393 zł  - dodano.</p>

## Prezydent Ukrainy: Rosjanie mogą wysadzić Zaporoską Elektrownię Atomową
 - [https://www.bankier.pl/wiadomosc/Prezydent-Ukrainy-Rosjanie-moga-wysadzic-Zaporoska-Elektrownie-Atomowa-8561784.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Prezydent-Ukrainy-Rosjanie-moga-wysadzic-Zaporoska-Elektrownie-Atomowa-8561784.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 12:57:55.443291+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/c/1d19f2aa82c372-948-568-0-45-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rosjanie są zainteresowani destabilizacją naszego kraju, dlatego po hydroelektrowni w Nowej Kachowce mogą wysadzić też okupowaną Zaporoską Elektrownię Atomową - oznajmił w opublikowanym w czwartek wywiadzie dla amerykańskiej stacji NBC News prezydent Ukrainy Wołodymyr Zełenski.</p>

## Tym będą żyły rynki: bankierzy centralni w natarciu i wzrost płac Polaków
 - [https://www.bankier.pl/wiadomosc/Tym-beda-zyly-rynki-polska-gospodarka-kontra-bankierzy-centralni-8561710.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tym-beda-zyly-rynki-polska-gospodarka-kontra-bankierzy-centralni-8561710.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 12:57:55.421267+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/b/e378b1c60aa918-948-568-0-17-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nadchodzący tydzień będzie wypełniony najnowszymi danymi z
polskiej gospodarki. Głos zabiorą także bankierzy centralni.</p>

## Producent iPhone'ów ewakuuje się z Chin. Winne napięte relacje między USA a ChRL
 - [https://www.bankier.pl/wiadomosc/Producent-iPhone-ow-ewakuuje-sie-z-Chin-Winne-napiete-relacje-miedzy-USA-a-ChRL-8561539.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Producent-iPhone-ow-ewakuuje-sie-z-Chin-Winne-napiete-relacje-miedzy-USA-a-ChRL-8561539.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 12:57:55.418813+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/e/7019fa2557de2e-948-568-40-290-3400-2040.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nadciąga już nie ochłodzenie, a oblodzenie, stosunków między Chinami a USA? Ruchy Foxconnu, głównego producenta iPhonów, mogą o tym świadczyć. Koncern przerzuca niektóre linie produkcyjne na samochody elektryczne i modyfikuje część ze swoich łańcuchów dostaw. </p>

## Inflacja bazowa wreszcie spadła, ale wciąż jest bardzo wysoka
 - [https://www.bankier.pl/wiadomosc/Inflacja-bazowa-w-Polsce-maj-2023-Maj-przyniosl-upragniony-spadek-inflacji-bazowej-8561746.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Inflacja-bazowa-w-Polsce-maj-2023-Maj-przyniosl-upragniony-spadek-inflacji-bazowej-8561746.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 12:57:55.409583+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/f/f4b0d2674578a0-948-568-0-37-3759-2255.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Maj przyniósł upragniony spadek inflacji bazowej, która przez ostatnie miesiące rosła pomimo spadku cen paliw i energii.</p>

## Xi Jinping spotkał się z Billem Gatesem. Ma nadzieję na kontynuację przyjaźni między USA a Chinami
 - [https://www.bankier.pl/wiadomosc/Xi-Jinping-spotkal-sie-z-Billem-Gatesem-Ma-nadzieje-na-kontynuacje-przyjazni-miedzy-USA-a-Chinami-8561730.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Xi-Jinping-spotkal-sie-z-Billem-Gatesem-Ma-nadzieje-na-kontynuacje-przyjazni-miedzy-USA-a-Chinami-8561730.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 12:43:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/8/4aabfb9283ef19-948-568-0-0-4096-2457.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Podczas spotkania z miliarderem i filantropem Billem Gatesem w piątek w Pekinie przywódca Chin Xi Jinping wyraził nadzieję na kontynuowanie przyjaźni i prowadzenie wspólnych działań korzystnych dla Chin i USA - podała agencja Reutera.</p>

## Producent Milki nie chce zrezygnować z biznesu w Rosji mimo bojkotu swoich słodyczy w Skandynawii
 - [https://www.bankier.pl/wiadomosc/Mondelez-nie-chce-zrezygnowac-z-biznesu-w-Rosji-mimo-bojkotu-w-Skandynawii-8561722.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Mondelez-nie-chce-zrezygnowac-z-biznesu-w-Rosji-mimo-bojkotu-w-Skandynawii-8561722.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 12:38:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/a/2e3a588e2e9c97-948-568-330-0-2416-1450.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Działający w Rosji koncern Mondelez International, po mającym miejsce w Szwecji i Norwegii bojkocie jego wyrobów czekoladowych nie zamierza rezygnować z biznesu w rządzonym przez dyktatora Putina kraju. Zapowiedział jedynie wydzielenie do końca roku rosyjskiej spółki ze swoich struktur międzynarodowych. Poprzez bojkot skandynawscy konsumenci protestują przeciwko niewycofaniu się firmy z działalności w Rosji.</p>

## Goldman Sachs prognozuje inflację w Polsce. Przed NBP trudne zadanie
 - [https://www.bankier.pl/wiadomosc/Goldman-Sachs-prognozuje-inflacje-w-Polsce-Przed-NBP-trudne-zadanie-8561623.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Goldman-Sachs-prognozuje-inflacje-w-Polsce-Przed-NBP-trudne-zadanie-8561623.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 10:53:53.126199+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/8/1eb3fbfb878395-945-560-0-180-1500-899.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Inflacja w Polsce spadnie poniżej 10 proc. rdr we wrześniu, jednak zejście wskaźnika do celu NBP będzie trudne bez znaczącego spowolnienia wzrostu płac - oceniają ekonomiści Goldman Sachs. Inflacja w maju w Polsce wyniosła 13,0 proc. rdr.</p>

## Millennium DM obniżył rekomendację dla Agory, ale podwyższył cenę docelową
 - [https://www.bankier.pl/wiadomosc/Millennium-DM-obnizyl-rekomendacje-dla-Agory-do-akumuluj-ale-podwyzszyl-cene-docelowa-do-9-3-zl-8561645.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Millennium-DM-obnizyl-rekomendacje-dla-Agory-do-akumuluj-ale-podwyzszyl-cene-docelowa-do-9-3-zl-8561645.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 10:53:53.123411+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/0/e068c1b41ef242-948-568-0-53-1765-1059.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Analitycy Millennium DM, w raporcie z 16 czerwca, obniżyli rekomendację dla Agory do "akumuluj" z "kupuj", ale podwyższył cenę docelową do 9,3 zł z 7,7 zł.</p>

## Unijny nadzór miał pilnować korupcji. Tymczasem "przeoczył" aferę w PE
 - [https://www.bankier.pl/wiadomosc/Unijny-nadzor-mial-pilnowac-korupcji-Tymczasem-przeoczyl-afere-w-PE-8561626.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Unijny-nadzor-mial-pilnowac-korupcji-Tymczasem-przeoczyl-afere-w-PE-8561626.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 10:53:53.118592+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/3/c17fca37750db1-945-567-5-51-2038-1223.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Antykorupcyjny organ Rady Europy (GRECO) opublikował w czwartek roczny, 62-stronicowy raport na temat korupcji w państwach członkowskich. Skandal korupcyjny w Parlamencie Europejskim skwitowano w nim jednym zdaniem - podała agencja informacyjna Anadolu. Przypomnijmy, że wiceprzewodnicząca PE, Eva Kaili miała m.in. prać pieniądze.</p>

## Autogaz najtańszy od marca 2022. Ceny ON ciążą ku 6 zł/l
 - [https://www.bankier.pl/wiadomosc/Autogaz-najtanszy-od-marca-2022-Ceny-ON-ciaza-ku-6-zl-l-8561615.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Autogaz-najtanszy-od-marca-2022-Ceny-ON-ciaza-ku-6-zl-l-8561615.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 10:53:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/6/170eb986f55f64-948-567-5-70-995-596.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Autogaz był najtańszy od wybuchu wojny na Ukrainie, a średnie
ceny oleju napędowego ponownie zbliżyły się do 6 zł/l. Wciąż droga była za to
benzyna.</p>

## Mostostal Płock wypłaci dywidendę za 2022 rok. Podano kwotę
 - [https://www.bankier.pl/wiadomosc/Mostostal-Plock-wyplaci-0-8-zl-dywidendy-na-akcje-z-zysku-za-22-8561608.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Mostostal-Plock-wyplaci-0-8-zl-dywidendy-na-akcje-z-zysku-za-22-8561608.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 10:44:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/b/909c2448edd2ee-945-560-0-0-1732-1039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Walne zgromadzenie Mostostalu Płock przyjęło uchwałę, na podstawie której spółka wypłaci w formie dywidendy za 2022 rok łącznie 1,6 mln zł, co daje kwotę 0,8 zł na akcję - poinformowała spółka w komunikacie.</p>

## Nie będzie dywidendy od JSW. Skarb Państwa zdecydował
 - [https://www.bankier.pl/wiadomosc/Nie-bedzie-dywidendy-od-JSW-Skarb-Panstwa-zdecydowal-8561569.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nie-bedzie-dywidendy-od-JSW-Skarb-Panstwa-zdecydowal-8561569.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 10:31:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/b/a8ec395bbe6c7b-948-568-0-119-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Walne zgromadzenie akcjonariuszy Jastrzębskiej Spółki Węglowej podjęło decyzję o przeznaczeniu całości zysku z 2022 r. na kapitał zapasowy, a tym samym braku wypłaty dywidendy. Mniejszościowi akcjonariusze proponowali podczas zebrania przeznaczenie na dywidendę nawet kilkudziesięciu złotych na akcję. Oba wnioski przepadły w głosowaniu. </p>

## Euroinflacja: w UE ubywa krajów z dwucyfrową inflacją
 - [https://www.bankier.pl/wiadomosc/Inflacja-w-krajach-Unii-Europejskiej-maj-2023-8561566.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Inflacja-w-krajach-Unii-Europejskiej-maj-2023-8561566.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 10:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/d/d309eb63dfe50f-948-568-0-142-3360-2015.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Maj przyniósł dalsze wyhamowanie inflacji HICP w większości krajów Unii 
Europejskiej. Polska wraz z Czechami uplasowała się pierwszej trójce 
państw o najszybszym wzroście kosztów życia.</p>

## Wybuchy w Kijowie. Kliczko: W stronę stolicy lecą kolejne rosyjskie rakiety
 - [https://www.bankier.pl/wiadomosc/Wybuchy-w-Kijowie-Kliczko-W-strone-stolicy-leca-kolejne-rosyjskie-rakiety-8561560.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wybuchy-w-Kijowie-Kliczko-W-strone-stolicy-leca-kolejne-rosyjskie-rakiety-8561560.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 09:45:10.493520+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/7/beed54dc1289ae-948-568-0-119-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W kijowskiej dzielnicy Padół doszło do eksplozji, nad ukraińską stolicę nadlatują kolejne rosyjskie rakiety - przekazał w piątek mer Kijowa Witalij Kliczko. Siły Powietrzne wezwały mieszkańców, by ukryli się w schronach.</p>

## Bank Japonii utrzymał ultraluźną politykę. Drukarki jenów nie odpoczną
 - [https://www.bankier.pl/wiadomosc/Bank-Japonii-utrzymal-ultraluzna-polityke-8561549.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Bank-Japonii-utrzymal-ultraluzna-polityke-8561549.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 09:42:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/a/06098ab83df86f-948-568-0-273-4206-2523.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Japończycy pozostają osamotnieniu w ultraluźnym nastawieniu i wciąż
zamierzają „drukować” biliony jenów w celu utrzymania absurdalnie niskich stóp
procentowych.</p>

## Branson wyśle turystów w kosmos. Virgin Galactic wystartuje w czerwcu
 - [https://www.bankier.pl/wiadomosc/Branson-wysle-turystow-w-kosmos-Virgin-Galactik-wystartuje-w-czerwcu-8561509.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Branson-wysle-turystow-w-kosmos-Virgin-Galactik-wystartuje-w-czerwcu-8561509.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 09:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/9/3942beb5e16faf-948-568-96-0-3600-2159.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Firma Sir Richarda Bransona, która zajmuje się komercyjnymi lotami w kosmos, zapowiedziała swój pierwszy turystyczny lot jeszcze przed końcem tego miesiąca. Virgin Galactic celuje w okno startowe od 27 do 30 czerwca. Akcje nie czekały tak długo i poszły w górę o 40 proc. już teraz.</p>

## Intel zainwestuje 4,6 mld dolarów pod Wrocławiem. Otworzy fabrykę półprzewodników
 - [https://www.bankier.pl/wiadomosc/Intel-zainwestuje-4-6-mld-dolarow-pod-Wroclawiem-Otworzy-fabryke-polprzewodnikow-8561514.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Intel-zainwestuje-4-6-mld-dolarow-pod-Wroclawiem-Otworzy-fabryke-polprzewodnikow-8561514.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 09:01:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/e/4ed56e72b07dc9-948-568-0-79-1982-1189.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Blisko 4,6 mld dolarów zainwestuje Intel w podwrocławskiej Miękini. Miejscowość zostanie po niemieckim Magdeburgu drugim miejscem w Europie, w którym Intel zbuduje zakład zajmujący się montażem i testowaniem półprzewodników. Pracę w fabryce znajdzie 2 tys. osób.</p>

## "Lex Tusk". PiS zgłasza poprawkę do prezydenckiej noweli
 - [https://www.bankier.pl/wiadomosc/Lex-Tusk-PiS-zglasza-poprawke-do-prezydenckiej-noweli-8561516.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Lex-Tusk-PiS-zglasza-poprawke-do-prezydenckiej-noweli-8561516.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 08:43:47.432481+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/a/21304c30b582bf-948-568-535-863-1658-995.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sejm debatuje nad prezydenckim projektem nowelizacji "lex Tusk". Poseł Piotr Kaleta (PiS) zgłosił poprawkę, do ustawy powołującej komisję ds. badania wpływów rosyjskich na bezpieczeństwo Polski, która doprecyzowuje, kto może stanąć przed sądem w trybie odwoławczym.</p>

## Nie tylko mieszkania, ale i boisko do krykieta. Miasteczko Orlenu dla pracowników ze Wschodu
 - [https://www.bankier.pl/wiadomosc/Nie-tylko-mieszkania-ale-i-boisko-do-krykieta-Miasteczko-Orlenu-dla-pracownikow-ze-Wschodu-8561461.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nie-tylko-mieszkania-ale-i-boisko-do-krykieta-Miasteczko-Orlenu-dla-pracownikow-ze-Wschodu-8561461.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 08:43:47.373285+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/8/4de9f3734bb18a-948-568-0-52-1101-660.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przy kompleksie Olefin III pod Płockiem powstało drugie miasto - będą w nim mieszkać pracownicy z Azji i Bliskiego Wschodu, którzy zostaną zatrudnieni przez Orlen. Na stałe umieszczono w nim także posterunek policji i zespół pogotowia ratunkowego. </p>

## Kuczyński: Czas ekstremalnej chciwości
 - [https://www.bankier.pl/wiadomosc/Kuczynski-Czas-ekstremalnej-chciwosci-8561507.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kuczynski-Czas-ekstremalnej-chciwosci-8561507.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 08:43:47.324925+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/8/57f0ba2c63248e-948-568-0-0-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Po tygodniowej przerwie 
jest z czego wybierać: Fed trochę chce, a trochę nie chce podwyżek, RPP 
przeprowadza "testy na produkcji", TSUE psuje nastrój bankowcom, a w tle
 - chiński pakiet stymulacyjny. A w wirtualnym studio - Piotr Kuczyński,
 analityk rynków finansowych Domu Inwestycyjnego Xelion - na żywo już o 
10:30.</p>

## Dolar najtańszy od wybuchu wojny. Kurs euro idzie w górę
 - [https://www.bankier.pl/wiadomosc/Dolar-najtanszy-od-wybuchu-wojny-Kurs-euro-idzie-w-gore-8561515.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Dolar-najtanszy-od-wybuchu-wojny-Kurs-euro-idzie-w-gore-8561515.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 08:43:47.300886+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/f/675ca973bdcef1-948-568-8-21-1723-1034.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kurs USD/PLN zbliżył się do „magicznego”
poziomu 4 zł i w ten sposób osiągnął najniższy
poziom od wybuchu wojny na Ukrainie.</p>

## Sklepy w Wigilię będą zamknięte. Minister Buda o szczegółach
 - [https://www.bankier.pl/wiadomosc/Wigilia-2023-a-niedziela-handlowa-Minister-Buda-sklepy-beda-zamkniete-8561497.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wigilia-2023-a-niedziela-handlowa-Minister-Buda-sklepy-beda-zamkniete-8561497.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 08:21:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/3/d84a7e8af89047-945-560-0-15-1500-899.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W tym roku Wigilia po raz pierwszy nie będzie pracująca, choć przypada w niedzielę handlową – poinformował w piątek PAP minister rozwoju i technologii Waldemar Buda. Zmienimy to w tym roku - dodał. Ustawa wprowadzająca stopniowo zakaz handlu w niedziele weszła w życie 1 marca 2018 r. </p>

## Liczba ofert pracy w maju znów spadła. To już 12 miesiąc z rzędu
 - [https://www.bankier.pl/wiadomosc/Liczba-ofert-pracy-w-maju-znow-spadla-To-juz-12-miesiac-z-rzedu-8561483.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Liczba-ofert-pracy-w-maju-znow-spadla-To-juz-12-miesiac-z-rzedu-8561483.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 08:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/b/5a36e9b9790ded-948-568-78-210-2320-1392.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W maju ponownie spadła liczba ofert pracy i choć nie był on duży, to potwierdza negatywną tendencję trwającą już 12 miesiąc – wynika z Barometru Ofert Pracy. Liczba ofert pracy powoli zwiększa się natomiast w zawodach związanych z pracą fizyczną - dodano.</p>

## Ropa drożeje, a rynek liczy na Chiny
 - [https://www.bankier.pl/wiadomosc/Ropa-drozeje-a-rynek-liczy-na-Chiny-8561470.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ropa-drozeje-a-rynek-liczy-na-Chiny-8561470.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 07:18:59.126897+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/e/af26799598de3a-948-568-0-247-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ceny ropy na giełdzie paliw w Nowym Jorku rosną po tym, jak na zakończenie poprzedniej sesji zaliczyły najmocniejszą od 6 tygodni zwyżkę notowań - podają maklerzy.</p>

## Referendum ws. relokacji migrantów. Poseł PiS wskazuje możliwy termin
 - [https://www.bankier.pl/wiadomosc/Referendum-ws-relokacji-migrantow-Posel-PiS-wskazuje-mozliwy-termin-8561449.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Referendum-ws-relokacji-migrantow-Posel-PiS-wskazuje-mozliwy-termin-8561449.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 07:18:59.119392+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/c/ca3f63f07de496-945-567-0-236-4443-2666.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sprawa relokacji imigrantów dzieli Polaków. Można sobie wyobrazić, że referendum ws. relokacji migrantów, mogłoby się odbyć równocześnie z wyborami do Sejmu - powiedział w piątek przewodniczący sejmowej komisji sprawiedliwości Marek Ast (PiS).</p>

## PKO BP: Banki będą tworzyć rezerwy po wyroku TSUE. Koszty "wrzucą" w II kwartał
 - [https://www.bankier.pl/wiadomosc/PKO-BP-Banki-beda-tworzyc-rezerwy-po-wyroku-TSUE-Koszty-wrzuca-w-II-kwartal-8561434.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PKO-BP-Banki-beda-tworzyc-rezerwy-po-wyroku-TSUE-Koszty-wrzuca-w-II-kwartal-8561434.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 06:52:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/b/50ea7e1f7bf709-948-568-12-151-2410-1446.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zmiany poziomu rezerw w bankach, wynikające z czwartkowego wyroku TSUE w sprawie kredytów frankowych, mogą nastąpić w najbliższych tygodniach - powiedział PAP wiceprezes PKO BP Piotr Mazur. Jego zdaniem, zdecydowana większość banków będzie tworzyć dodatkowe rezerwy w ciężar II kwartału br.</p>

## Wakat? W Polsce to nie problem, ale w UE już tak
 - [https://www.bankier.pl/wiadomosc/Wakat-W-Polsce-to-nie-problem-ale-w-UE-juz-tak-8561402.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wakat-W-Polsce-to-nie-problem-ale-w-UE-juz-tak-8561402.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 05:51:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/c/0c798e1cc0d6e9-948-568-0-80-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Polskie firmy znacznie rzadziej niż przedsiębiorstwa z innych krajów Unii Europejskiej mają problem z wypełnieniem wakatów – wskazuje piątkowa "Rzeczpospolita". To m.in. efekt spowolnienia i imigracji zarobkowej – podano.</p>

## NIK krytykuje budżet. MF: Zasługuje na absolutorium
 - [https://www.bankier.pl/wiadomosc/NIK-krytykuje-budzet-MF-Zasluguje-na-absolutorium-8561384.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/NIK-krytykuje-budzet-MF-Zasluguje-na-absolutorium-8561384.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 05:08:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/a/c38fc6a502cd57-945-560-0-0-1500-899.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Uwagi NIK są ogólnymi uwagami, co do zachowania konwencjonalnych, podręcznikowych zasad finansów publicznych, a nie do nieprawidłowej realizacji ustawy budżetowej - poinformowało Ministerstwo Finansów. Jednocześnie MF wskazuje, że NIK w swojej analizie abstrahuje od warunków, w jakich funkcjonowała polska gospodarka w ostatnich latach.</p>

## Ponad połowa MŚP płaci z opóźnieniem. Problemy ma handel i budowlanka
 - [https://www.bankier.pl/wiadomosc/Ponad-polowa-MSP-placi-z-opoznieniem-Problemy-ma-handel-i-budowlanka-8561379.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ponad-polowa-MSP-placi-z-opoznieniem-Problemy-ma-handel-i-budowlanka-8561379.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 04:51:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/3/94ae7964d5c5f7-945-560-19-118-2613-1567.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Z ponad miesięcznym opóźnieniem płatności za usługi, produkt czy towar otrzymuje 56 proc. małych i średnich firm wobec 44 proc. przed rokiem - wskazano w badaniu BIG InfoMonitor. Dodano, że przelewy najbardziej opóźniają kontrahenci budownictwa i handlu.</p>

## Kto oferuje najszybszy internet? Porównanie Orange, T-Mobile, Play, Plus
 - [https://www.bankier.pl/wiadomosc/Kto-oferuje-najszybszy-internet-Porownanie-Orange-T-Mobile-Play-Plus-UPC-Vectra-INEA-8560615.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kto-oferuje-najszybszy-internet-Porownanie-Orange-T-Mobile-Play-Plus-UPC-Vectra-INEA-8560615.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 04:04:20.309147+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/3/3a0acdfec792bb-948-568-0-197-1976-1185.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ostatnie miesiące przyniosły spore przetasowania wśród dostawców internetu mobilnego i domowego – wynika z najnowszego raportu serwisu speedtest.pl. Sprawdziliśmy, kto tuż przed wakacjami oferował najszybszy internet mobilny LTE, 5G i domowy?</p>

## Więcej dziadków niż wnuków. Kryzys demograficzny w Polsce trwa
 - [https://www.bankier.pl/wiadomosc/Demografia-Polski-wyniki-Narodowego-Spisu-Powszechnego-2021-8560717.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Demografia-Polski-wyniki-Narodowego-Spisu-Powszechnego-2021-8560717.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 04:04:20.295682+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/b/27a19078fafd4c-945-560-5-57-2298-1378.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Z danych GUS wyłania się smutny obraz Polski. W ciągu dekady liczba ludności spadła o 476 tys., a społeczeństwo postarzało się średnio o 4 lata - podano w omówieniu wyników spisu powszechnego 2021 r. Już co 5. mieszkaniec Polski ma ponad 60 lat - dodano.</p>

## Boom na obligacje oszczędnościowe minął
 - [https://www.bankier.pl/wiadomosc/Boom-na-obligacje-oszczednosciowe-minal-8560679.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Boom-na-obligacje-oszczednosciowe-minal-8560679.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 04:04:20.292915+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/f/b92a6da5cd8b33-948-568-0-53-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sprzedaż obligacji detalicznych w maju wyniosła 2,437 mld zł wobec 2,370 mld zł w kwietniu - podał resort finansów w komunikacie.</p>

## Branża turystyczna zaskakuje. „Czas na rekordowe wakacje”
 - [https://www.bankier.pl/wiadomosc/Branza-turystyczna-zaskakuje-Czas-na-rekordowe-wakacje-8561006.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Branza-turystyczna-zaskakuje-Czas-na-rekordowe-wakacje-8561006.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 04:04:20.288320+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/c/32dce8d23a61d0-948-568-53-0-1809-1085.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Turystyka zalicza wyraźne odbicie po erze COVID-19 a kursy giełdowych spółek pną się mocno do góry. „Czas na rekordowe wakacje” – głoszą nagłówki analiz ekspertów, a co za tym idzie, na horyzoncie pojawiają się rekordowe wyniki.</p>

## Cenowa sinusoida w hipotekach. Czerwcowe stawki nieco wyższe
 - [https://www.bankier.pl/wiadomosc/Ranking-kredytow-hipotecznych-czerwiec-2023-najlepsze-kredyty-hipoteczne-8561000.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ranking-kredytow-hipotecznych-czerwiec-2023-najlepsze-kredyty-hipoteczne-8561000.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 04:04:20.285223+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/4/092212e9192b39-948-568-1140-1290-2750-1650.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Krok do przodu, krok w tył – tak wyglądają cenowe ruchy w kredytach hipotecznych z okresowo stałym oprocentowaniem w ostatnich miesiącach. W czerwcu stawek z „7” na początku ubyło, ale w zestawieniu witamy po raz pierwszy od lat nowy bank.</p>

## Hiszpania przekaże Ukrainie czołgi i zorganizuje szpital wojskowy
 - [https://www.bankier.pl/wiadomosc/Hiszpania-przekaze-Ukrainie-czolgi-i-zorganizuje-szpital-wojskowy-8561371.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Hiszpania-przekaze-Ukrainie-czolgi-i-zorganizuje-szpital-wojskowy-8561371.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-16 02:34:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/d/243b90705d7ef7-948-567-0-0-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />iszpania przekaże Ukrainie 20 pojazdów opancerzonych i 4 czołgi Leopard 2A4 - oświadczyła minister obrony Hiszpanii Margarita Robles na posiedzeniu Grupy Kontaktowej ds. Obrony Ukrainy w formacie Rammstein, poinformowała w piątek Ukraińska Prawda. Hiszpanie zorganizują także szpital wojskowy dla ukraińskich żołnierzy.</p>

