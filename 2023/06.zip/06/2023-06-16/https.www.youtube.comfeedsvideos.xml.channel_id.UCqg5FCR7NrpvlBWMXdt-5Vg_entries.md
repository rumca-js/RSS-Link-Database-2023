# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## Fall of Porcupine | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=FHXfDnWDSc0](https://www.youtube.com/watch?v=FHXfDnWDSc0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2023-06-16 19:00:06+00:00

Support us on Patreon to get Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.patreon.com/the_escapist

Will Cruz reviews Fall of Porcupine, developed by Critical Rabbit.

Fall of Porcupine on Steam: https://store.steampowered.com/app/1710540/Fall_of_Porcupine/

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Tears of the Kingdom Solves Breath of the Wild's Biggest Design Flaw | Design Delve
 - [https://www.youtube.com/watch?v=feaEp5_HVTA](https://www.youtube.com/watch?v=feaEp5_HVTA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2023-06-16 15:00:35+00:00

Support us on Patreon to get Early Access to new videos, exclusive Discord perks & more for just $2 per month ►► https://www.patreon.com/the_escapist

In today's episode of Design Delve JM8 delves into how Nintendo solved Breath of the Wilds biggest design problem.

If you want to see more game design content a new Design Delve episode will release every other week, or you can subscribe to JM8s personal channel for similar content: https://www.youtube.com/c/JM8GameDesign

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

