# Source:Wydarzenia Interia, URL:https://wydarzenia.interia.pl/feed, language:pl-PL

## Tomasz Poręba zrezygnował ze stanowiska szefa sztabu PiS
 - [https://wydarzenia.interia.pl/kraj/news-tomasz-poreba-zrezygnowal-ze-stanowiska-szefa-sztabu-pis,nId,6845861](https://wydarzenia.interia.pl/kraj/news-tomasz-poreba-zrezygnowal-ze-stanowiska-szefa-sztabu-pis,nId,6845861)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-16 21:28:55+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-tomasz-poreba-zrezygnowal-ze-stanowiska-szefa-sztabu-pis,nId,6845861"><img align="left" alt="Tomasz Poręba zrezygnował ze stanowiska szefa sztabu PiS" src="https://i.iplsc.com/tomasz-poreba-zrezygnowal-ze-stanowiska-szefa-sztabu-pis/000G87D762U532YS-C321.jpg" /></a>Tomasz Poręba zrezygnował ze stanowiska szefa sztabu PiS - o swojej decyzji powiadomił w piątek na Twitterze. &quot;Dziś na tym stanowisku potrzebny jest ktoś z nową emocją i energią. Za którym stanie się murem&quot; - napisał. </p><br clear="all" />

## Naczelny rabin Ukrainy odpowiada Putinowi. "Cały świat jest dumny"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-naczelny-rabin-ukrainy-odpowiada-putinowi-caly-swiat-jest-du,nId,6845857](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-naczelny-rabin-ukrainy-odpowiada-putinowi-caly-swiat-jest-du,nId,6845857)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-16 21:18:27+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-naczelny-rabin-ukrainy-odpowiada-putinowi-caly-swiat-jest-du,nId,6845857"><img align="left" alt="Naczelny rabin Ukrainy odpowiada Putinowi. &quot;Cały świat jest dumny&quot;" src="https://i.iplsc.com/naczelny-rabin-ukrainy-odpowiada-putinowi-caly-swiat-jest-du/000HAFV2HW3QID84-C321.jpg" /></a>- Jestem dumny z prezydenta Ukrainy, że nie uciekł i robi wszystko, aby pomóc narodowi ukraińskiemu - powiedział Mosze Azman, naczelny rabin Ukrainy, odnosząc się do słów Władimira Putina. Rosyjski przywódca w piątek mówił, że Wołodymyr Zełenski &quot;jest hańbą dla narodu żydowskiego&quot;. </p><br clear="all" />

## Echa wystąpienia Tuska. Rusecka: Najbardziej obrzydliwe w dziejach Polski
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-echa-wystapienia-tuska-rusecka-najbardziej-obrzydliwe-w-dzie,nId,6845842](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-echa-wystapienia-tuska-rusecka-najbardziej-obrzydliwe-w-dzie,nId,6845842)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-16 20:15:39+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-echa-wystapienia-tuska-rusecka-najbardziej-obrzydliwe-w-dzie,nId,6845842"><img align="left" alt="Echa wystąpienia Tuska. Rusecka: Najbardziej obrzydliwe w dziejach Polski" src="https://i.iplsc.com/echa-wystapienia-tuska-rusecka-najbardziej-obrzydliwe-w-dzie/000HAFNV3A4TSI57-C321.jpg" /></a>Piątkowe wystąpienie Donalda Tuska na wiecu w Poznaniu wywołało niemałe poruszenie u polityków partii rządzącej. Wicerzeczniczka PiS Urszula Rusecka skomentowała je na Twitterze, oceniła że przejdzie do historii jako &quot;najbardziej obrzydliwe wystąpienie polityczne w dziejach Polski&quot;. Do transparentu &quot;Boże zabrałeś nie tego Kaczyńskiego&quot; krytycznie odnieśli się Mateusz Morawiecki, Piotr Müller, czy Sebastian Kaleta. Z kolei Borys Budka z PO zaznaczył, że &quot;transparent został zdjęty&quot;. &quot;My natychmiast reagujemy&quot; - zauważył. </p><br clear="all" />

## GIS wydał ostrzeżenie. Bakterie w hamburgerach
 - [https://wydarzenia.interia.pl/kraj/news-gis-wydal-ostrzezenie-bakterie-w-hamburgerach,nId,6845831](https://wydarzenia.interia.pl/kraj/news-gis-wydal-ostrzezenie-bakterie-w-hamburgerach,nId,6845831)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-16 19:50:33+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-gis-wydal-ostrzezenie-bakterie-w-hamburgerach,nId,6845831"><img align="left" alt="GIS wydał ostrzeżenie. Bakterie w hamburgerach" src="https://i.iplsc.com/gis-wydal-ostrzezenie-bakterie-w-hamburgerach/000HAFO9O97ATB3I-C321.jpg" /></a>Główny Inspektorat Sanitarny wydał ostrzeżenie dotyczące wykrycia bakterii w partii hamburgerów wieprzowo-drobiowych. Produkt został już wycofany ze sprzedaży, wcześniej można było go kupić w sieci Biedronka. Spożycie żywności zanieczyszczonej bakterią Listeria monocytogenes może prowadzić do choroby zwanej listeriozą.</p><br clear="all" />

## Inwazja świerszczy w USA. Owady pokrywają domy i ulice
 - [https://wydarzenia.interia.pl/zagranica/news-inwazja-swierszczy-w-usa-owady-pokrywaja-domy-i-ulice,nId,6845829](https://wydarzenia.interia.pl/zagranica/news-inwazja-swierszczy-w-usa-owady-pokrywaja-domy-i-ulice,nId,6845829)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-16 19:50:06+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-inwazja-swierszczy-w-usa-owady-pokrywaja-domy-i-ulice,nId,6845829"><img align="left" alt="Inwazja świerszczy w USA. Owady pokrywają domy i ulice" src="https://i.iplsc.com/inwazja-swierszczy-w-usa-owady-pokrywaja-domy-i-ulice/000HAFLQLGJDAAMB-C321.jpg" /></a>Ogromne świerszcze mormońskie przejęły niemal cały stan Nevada w USA. W sieci pojawiły się zdjęcia i nagrania, na których widać inwazję owadów niczym z horroru. Domy i ulice są oblepione przez świerszcze, a mieszkańcy nie mogą z tym nic zrobić. Pozostało im jedynie czekać, aż niechciani goście się przeniosą. </p><br clear="all" />

## Wystąpienie posłanki PiS przerwane. "Oddaj mieszkanie!"
 - [https://wydarzenia.interia.pl/kraj/news-wystapienie-poslanki-pis-przerwane-oddaj-mieszkanie,nId,6845822](https://wydarzenia.interia.pl/kraj/news-wystapienie-poslanki-pis-przerwane-oddaj-mieszkanie,nId,6845822)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-16 19:39:39+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-wystapienie-poslanki-pis-przerwane-oddaj-mieszkanie,nId,6845822"><img align="left" alt="Wystąpienie posłanki PiS przerwane. &quot;Oddaj mieszkanie!&quot;" src="https://i.iplsc.com/wystapienie-poslanki-pis-przerwane-oddaj-mieszkanie/000HAFMILY5RH2V7-C321.jpg" /></a>- Oddaj mieszkanie, oddaj mieszkanie - skandowała grupa posłów, gdy posłanka PiS Anna Paluch pojawiła się na mównicy sejmowej, by przedstawić sprawozdanie komisji. Reakcja parlamentarzystów jest związana z doniesieniami, które pojawiły się w czerwcu. Wynikało z nich, że Paluch zajmuje mieszkanie komunalne w Krościenku nad Dunajcem, za które płaci 116,43 zł miesięcznie.  </p><br clear="all" />

## Putin mówił o możliwym użyciu broni nuklearnej. Biały Dom reaguje
 - [https://wydarzenia.interia.pl/zagranica/news-putin-mowil-o-mozliwym-uzyciu-broni-nuklearnej-bialy-dom-rea,nId,6845799](https://wydarzenia.interia.pl/zagranica/news-putin-mowil-o-mozliwym-uzyciu-broni-nuklearnej-bialy-dom-rea,nId,6845799)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-16 19:00:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-putin-mowil-o-mozliwym-uzyciu-broni-nuklearnej-bialy-dom-rea,nId,6845799"><img align="left" alt="Putin mówił o możliwym użyciu broni nuklearnej. Biały Dom reaguje" src="https://i.iplsc.com/putin-mowil-o-mozliwym-uzyciu-broni-nuklearnej-bialy-dom-rea/000HAFFZNXR36I42-C321.jpg" /></a>- Zachód dokłada wysiłków, aby Rosja podtrzymała strategiczną porażkę - oświadczył w piątek Władimir Putin na Międzynarodowym Forum Ekonomicznym Rosji w Petersburgu. Rosyjski przywódca odniósł się możliwości do użycia przez Rosję broni nuklearnej. Na jego słowa zareagował Biały Dom. </p><br clear="all" />

## Tragedia na pokładzie polskiego samolotu. Pilot musiał awaryjnie lądować
 - [https://wydarzenia.interia.pl/zagranica/news-tragedia-na-pokladzie-polskiego-samolotu-pilot-musial-awaryj,nId,6845804](https://wydarzenia.interia.pl/zagranica/news-tragedia-na-pokladzie-polskiego-samolotu-pilot-musial-awaryj,nId,6845804)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-16 18:49:59+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-tragedia-na-pokladzie-polskiego-samolotu-pilot-musial-awaryj,nId,6845804"><img align="left" alt="Tragedia na pokładzie polskiego samolotu. Pilot musiał awaryjnie lądować" src="https://i.iplsc.com/tragedia-na-pokladzie-polskiego-samolotu-pilot-musial-awaryj/000HAFI2QU40NBL1-C321.jpg" /></a>Dramatyczne sceny na pokładzie samolotu Polskich Linii Lotniczych LOT. Nie żyje pasażer, który w piątek przed południem podróżował z greckiej wyspy Rodos do Katowic - poinformował rzecznik linii Krzysztof Moczulski. Lekarz stwierdził zgon po tym, jak maszyna polskiego przewoźnika wylądowała w Bukareszcie. </p><br clear="all" />

## Kontrowersyjny transparent na wiecu Tuska. Premier: Łajdactwo
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-kontrowersyjny-transparent-na-wiecu-tuska-premier-lajdactwo,nId,6845781](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-kontrowersyjny-transparent-na-wiecu-tuska-premier-lajdactwo,nId,6845781)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-16 17:32:23+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-kontrowersyjny-transparent-na-wiecu-tuska-premier-lajdactwo,nId,6845781"><img align="left" alt="Kontrowersyjny transparent na wiecu Tuska. Premier: Łajdactwo" src="https://i.iplsc.com/kontrowersyjny-transparent-na-wiecu-tuska-premier-lajdactwo/000HAF6ZQ7TH0IKE-C321.jpg" /></a>Łajdactwo! - tak premier Mateusz Morawiecki odniósł się do kontrowersyjnego transparentu, który pojawił się na wiecu w Poznaniu, gdzie występował Donald Tusk. W ocenie rzecznika rządu Piotra  Müllera to &quot;obrzydliwa mowa nienawiści&quot;. Polityk zaapelował też do lidera PO, aby ten przeprosił.
</p><br clear="all" />

## Sejm zdecydował ws. nowelizacji "lex Tusk"
 - [https://wydarzenia.interia.pl/kraj/news-sejm-zdecydowal-ws-nowelizacji-lex-tusk,nId,6845424](https://wydarzenia.interia.pl/kraj/news-sejm-zdecydowal-ws-nowelizacji-lex-tusk,nId,6845424)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-16 17:04:17+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-sejm-zdecydowal-ws-nowelizacji-lex-tusk,nId,6845424"><img align="left" alt="Sejm zdecydował ws. nowelizacji &quot;lex Tusk&quot;" src="https://i.iplsc.com/sejm-zdecydowal-ws-nowelizacji-lex-tusk/000HAF3ZG0L3N2A8-C321.jpg" /></a>Sejm uchwalił nowelizację ustawy o komisji ds. badania wpływów rosyjskich. Potoczna nazwa dla tej ustawy to &quot;lex Tusk&quot;, w związku z oskarżeniami opozycji, która uważa, że komisja jest wymierzona przeciwko liderowi Koalicji Obywatelskiej Donaldowi Tuskowi. Pomysłodawcą poprawek był prezydent Andrzej Duda. </p><br clear="all" />

## Adwokatura apeluje w sprawie wyborów parlamentarnych
 - [https://wydarzenia.interia.pl/kraj/news-adwokatura-apeluje-w-sprawie-wyborow-parlamentarnych,nId,6845755](https://wydarzenia.interia.pl/kraj/news-adwokatura-apeluje-w-sprawie-wyborow-parlamentarnych,nId,6845755)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-16 17:00:09+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-adwokatura-apeluje-w-sprawie-wyborow-parlamentarnych,nId,6845755"><img align="left" alt="Adwokatura apeluje w sprawie wyborów parlamentarnych" src="https://i.iplsc.com/adwokatura-apeluje-w-sprawie-wyborow-parlamentarnych/000FX4HFVD97AR31-C321.jpg" /></a>Adwokatura Polska zachęca obywateli do czynnego udziału w wyborach parlamentarnych. Krajowy Zjazd Adwokatury przyjął przez aklamację uchwałę w tej sprawie. &quot;Adwokaci apelują, by w wyborach obywatele kierowali się troską o dobro wspólne, stabilność prawną państwa, gwarancję rządów prawa i przestrzegania praworządności&quot; - czytamy w komunikacie. </p><br clear="all" />

## Tusk o PiS: Dość mamy brudu, który wylewa się z ich urzędów
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-tusk-o-pis-dosc-mamy-brudu-ktory-wylewa-sie-z-ich-urzedow,nId,6845576](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-tusk-o-pis-dosc-mamy-brudu-ktory-wylewa-sie-z-ich-urzedow,nId,6845576)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-16 16:24:33+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-tusk-o-pis-dosc-mamy-brudu-ktory-wylewa-sie-z-ich-urzedow,nId,6845576"><img align="left" alt="Tusk o PiS: Dość mamy brudu, który wylewa się z ich urzędów" src="https://i.iplsc.com/tusk-o-pis-dosc-mamy-brudu-ktory-wylewa-sie-z-ich-urzedow/000HAEPALXTEIFLO-C321.jpg" /></a>- Dosyć mamy tego brudu, który każdego dnia wylewa się z ich urzędów, z ich mediów - zaznaczył lider PO Donald Tusk podczas przemówienia na wiecu w Poznaniu. Przypomniał także, że na marszu 4 czerwca było pół miliona Polek i Polaków. </p><br clear="all" />

## Jarosław Gowin wydał oświadczenie w sprawie swojej politycznej przyszłości
 - [https://wydarzenia.interia.pl/tylko-w-interii/news-jaroslaw-gowin-wydal-oswiadczenie-w-sprawie-swojej-polityczn,nId,6845330](https://wydarzenia.interia.pl/tylko-w-interii/news-jaroslaw-gowin-wydal-oswiadczenie-w-sprawie-swojej-polityczn,nId,6845330)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-16 16:00:00+00:00

<p><a href="https://wydarzenia.interia.pl/tylko-w-interii/news-jaroslaw-gowin-wydal-oswiadczenie-w-sprawie-swojej-polityczn,nId,6845330"><img align="left" alt="Jarosław Gowin wydał oświadczenie w sprawie swojej politycznej przyszłości" src="https://i.iplsc.com/jaroslaw-gowin-wydal-oswiadczenie-w-sprawie-swojej-polityczn/000HACVJ295XANGC-C321.jpg" /></a>Jarosław Gowin nie będzie kandydował w zbliżających się wyborach parlamentarnych - dowiedziała się Interia. &quot;W poczuciu odpowiedzialności za Polskę zablokowaliśmy niedemokratyczne wybory kopertowe, sprzeciwiliśmy się zawetowaniu unijnego budżetu, wprowadzeniu podatku medialnego, lex TVN czy Polskiego Ładu&quot; - czytamy w oświadczeniu byłego wicepremiera, którego treść Interia poznała jako pierwsza. Publikujemy je w całości.</p><br clear="all" />

## Nowe przepisy. Koniec ekogroszku i ekomiału. O co chodzi?
 - [https://wydarzenia.interia.pl/kraj/news-nowe-przepisy-koniec-ekogroszku-i-ekomialu-o-co-chodzi,nId,6842939](https://wydarzenia.interia.pl/kraj/news-nowe-przepisy-koniec-ekogroszku-i-ekomialu-o-co-chodzi,nId,6842939)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-16 15:45:50+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-nowe-przepisy-koniec-ekogroszku-i-ekomialu-o-co-chodzi,nId,6842939"><img align="left" alt="Nowe przepisy. Koniec ekogroszku i ekomiału. O co chodzi?" src="https://i.iplsc.com/nowe-przepisy-koniec-ekogroszku-i-ekomialu-o-co-chodzi/000FUOSS0RU0F5HX-C321.jpg" /></a>Minister klimatu i środowiska Anna Moskwa ogłosiła plany zakończenia używania terminów &quot;ekogroszek&quot; i &quot;ekomiał&quot; w odniesieniu do popularnych gatunków opału. Polityk zapowiedziała wprowadzenie nowych nazw dla tych produktów, co ma na celu rozwiązanie problemu mylnego postrzegania takich paliw jako ekologicznych. Projekt zmian rozporządzenia trafił na strony sejmowe 12 czerwca. Na razie nie wiadomo, kiedy dokładnie zmiany wejdą w życie.</p><br clear="all" />

## Mam Dość 2023 nie istnieje. Marianna Schreiber miała problem z podpisami
 - [https://wydarzenia.interia.pl/kraj/news-mam-dosc-2023-nie-istnieje-marianna-schreiber-miala-problem-,nId,6845550](https://wydarzenia.interia.pl/kraj/news-mam-dosc-2023-nie-istnieje-marianna-schreiber-miala-problem-,nId,6845550)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-16 15:43:53+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-mam-dosc-2023-nie-istnieje-marianna-schreiber-miala-problem-,nId,6845550"><img align="left" alt="Mam Dość 2023 nie istnieje. Marianna Schreiber miała problem z podpisami" src="https://i.iplsc.com/mam-dosc-2023-nie-istnieje-marianna-schreiber-miala-problem/000HAEIR4B88FH58-C321.jpg" /></a>Partia Marianny Schreiber Mam Dość 2023 nie została zarejestrowana - wynika z ustaleń &quot;Rzeczpospolitej&quot;. Była uczestniczka &quot;Top Model&quot;, prywatnie żona ministra Łukasza Schreibera, zaczęła zajmować się działalnością polityczną w maju 2022 roku. Ogłosiła wówczas założenie ugrupowania. Do zarejestrowania partii zabrakło jednak odpowiedniej liczby podpisów. </p><br clear="all" />

## Apteczka na wakacje. Co ze sobą zabrać, aby wyjazd był bezpieczny?
 - [https://wydarzenia.interia.pl/ciekawostki/news-apteczka-na-wakacje-co-ze-soba-zabrac-aby-wyjazd-byl-bezpiec,nId,6815128](https://wydarzenia.interia.pl/ciekawostki/news-apteczka-na-wakacje-co-ze-soba-zabrac-aby-wyjazd-byl-bezpiec,nId,6815128)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-16 15:15:50+00:00

<p><a href="https://wydarzenia.interia.pl/ciekawostki/news-apteczka-na-wakacje-co-ze-soba-zabrac-aby-wyjazd-byl-bezpiec,nId,6815128"><img align="left" alt="Apteczka na wakacje. Co ze sobą zabrać, aby wyjazd był bezpieczny?" src="https://i.iplsc.com/apteczka-na-wakacje-co-ze-soba-zabrac-aby-wyjazd-byl-bezpiec/00085GXBX8D7VUOR-C321.jpg" /></a>Wakacyjną apteczkę pakuje się na wszelki wypadek. Nie trzeba w niej zabierać dużej ilości leków ani opatrunków. Ważne jest to, aby była uniwersalna i mogła pomóc nam w przypadku drobnych urazów lub nagłego zachorowania. Sprawdź, co warto w niej mieć, aby być gotowym na każdą ewentualność.</p><br clear="all" />

## Zbrodnia w Szczecinie. Nowe ustalenia w sprawie
 - [https://wydarzenia.interia.pl/zachodniopomorskie/news-zbrodnia-w-szczecinie-nowe-ustalenia-w-sprawie,nId,6845514](https://wydarzenia.interia.pl/zachodniopomorskie/news-zbrodnia-w-szczecinie-nowe-ustalenia-w-sprawie,nId,6845514)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-16 14:33:34+00:00

<p><a href="https://wydarzenia.interia.pl/zachodniopomorskie/news-zbrodnia-w-szczecinie-nowe-ustalenia-w-sprawie,nId,6845514"><img align="left" alt="Zbrodnia w Szczecinie. Nowe ustalenia w sprawie" src="https://i.iplsc.com/zbrodnia-w-szczecinie-nowe-ustalenia-w-sprawie/000HAEC8F6NRTX77-C321.jpg" /></a>Mężczyzna zastrzelił swoją byłą partnerkę i jej obecnego partnera, po czym popełnił samobójstwo - wynika z nieoficjalnych ustaleń PAP. Sprawca miał posłużyć się bronią, na którą nie potrzeba pozwolenia. Do tragedii doszło w czwartek na osiedlu Warszewo w Szczecinie (woj. zachodniopomorskie). Policję wezwali świadkowie, którzy usłyszeli huki.</p><br clear="all" />

## Norwegia nie chce iść w ślady Szwecji. Obawy przed masową migracją
 - [https://wydarzenia.interia.pl/zagranica/news-norwegia-nie-chce-isc-w-slady-szwecji-obawy-przed-masowa-mig,nId,6845409](https://wydarzenia.interia.pl/zagranica/news-norwegia-nie-chce-isc-w-slady-szwecji-obawy-przed-masowa-mig,nId,6845409)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-16 14:12:09+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-norwegia-nie-chce-isc-w-slady-szwecji-obawy-przed-masowa-mig,nId,6845409"><img align="left" alt="Norwegia nie chce iść w ślady Szwecji. Obawy przed masową migracją" src="https://i.iplsc.com/norwegia-nie-chce-isc-w-slady-szwecji-obawy-przed-masowa-mig/000HAD7LBXT9UI2Q-C321.jpg" /></a>Norwegia nie chce powtarzać szwedzkich błędów - stwierdził szef wydziału migracyjnego norweskiej policji Arne Jorgen Olafsen w wywiadzie dla &quot;Dagens Nyheter&quot;. Szwecja ma duży problem z przestępczością i strzelaninami. Jako ich przyczynę Olafsen wskazał masową migrację, do której jego kraj nie chce dopuścić. </p><br clear="all" />

## Stoltenberg: Sojusznicy są zgodni. Ukraina jest bliżej NATO
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-stoltenberg-sojusznicy-sa-zgodni-ukraina-jest-blizej-nato,nId,6845464](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-stoltenberg-sojusznicy-sa-zgodni-ukraina-jest-blizej-nato,nId,6845464)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-16 14:08:57+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-stoltenberg-sojusznicy-sa-zgodni-ukraina-jest-blizej-nato,nId,6845464"><img align="left" alt="Stoltenberg: Sojusznicy są zgodni. Ukraina jest bliżej NATO" src="https://i.iplsc.com/stoltenberg-sojusznicy-sa-zgodni-ukraina-jest-blizej-nato/000HADEF60GCAINR-C321.jpg" /></a>- Sojusznicy zgadzają się, że Ukraina zbliżyła się do NATO w ciągu ostatniej dekady - oświadczył w piątek sekretarz generalny NATO Jens Stoltenberg. Słowa padły po zakończeniu dwudniowego spotkania ministrów obrony krajów należących do Sojuszu. Jak dodał, podczas szczytu w Wilnie będą prowadzone dyskusje nad tym, &quot;jak przybliżać Ukrainę do Sojuszu&quot;. Zaznaczył także, że gdyby Ukraina przestała walczyć, to tym samym &quot;przestałaby istnieć jako niepodległe państwo&quot;.</p><br clear="all" />

## Intel inwestuje miliardy dolarów w Polsce. "Mam numer premiera Morawieckiego w ulubionych"
 - [https://wydarzenia.interia.pl/kraj/news-intel-inwestuje-miliardy-dolarow-w-polsce-mam-numer-premiera,nId,6845438](https://wydarzenia.interia.pl/kraj/news-intel-inwestuje-miliardy-dolarow-w-polsce-mam-numer-premiera,nId,6845438)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-16 13:38:34+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-intel-inwestuje-miliardy-dolarow-w-polsce-mam-numer-premiera,nId,6845438"><img align="left" alt="Intel inwestuje miliardy dolarów w Polsce. &quot;Mam numer premiera Morawieckiego w ulubionych&quot;" src="https://i.iplsc.com/intel-inwestuje-miliardy-dolarow-w-polsce-mam-numer-premiera/000HADE8S7MKX1CN-C321.jpg" /></a>2 tys. nowych miejsc pracy i inwestycja sięgająca 4,6 mld dolarów - to nowy plan dla podwrocławskiej miejscowości od amerykańskiej firmy Intel. - Spotkałem się z premierem Morawieckim na Światowym Forum Ekonomicznym i to rozpoczęło ten temat. Później było to kontynuowane przez zespoły z obu stron - komentował dyrektor generalny Intela Pat Gelsinger. Jak zaznaczył, &quot;ma premiera Morawieckiego w ulubionych kontaktach w telefonie&quot;. </p><br clear="all" />

## Janusz Korwin-Mikke z zakazem wjazdu do Wielkiej Brytanii
 - [https://wydarzenia.interia.pl/kraj/news-janusz-korwin-mikke-z-zakazem-wjazdu-do-wielkiej-brytanii,nId,6845326](https://wydarzenia.interia.pl/kraj/news-janusz-korwin-mikke-z-zakazem-wjazdu-do-wielkiej-brytanii,nId,6845326)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-16 12:30:47+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-janusz-korwin-mikke-z-zakazem-wjazdu-do-wielkiej-brytanii,nId,6845326"><img align="left" alt="Janusz Korwin-Mikke z zakazem wjazdu do Wielkiej Brytanii" src="https://i.iplsc.com/janusz-korwin-mikke-z-zakazem-wjazdu-do-wielkiej-brytanii/000HACPJMY02CLVP-C321.jpg" /></a>Jak potwierdził w rozmowie z Interią poseł Konfederacji Janusz Korwin-Mikke, otrzymał on oficjalne z pismo z zakazem wjazdu na terytorium Wielkiej Brytanii. Polityk już wcześniej miał problem z przyjazdem do tego kraju, jakiś czas temu nie wpuszczono go na pokład samolotu linii Ryanair. O możliwych przyczynach decyzji brytyjskiego rządu pisze Ośrodek Monitorowania Zachowań Rasistowskich. </p><br clear="all" />

## Atak rakietowy na Kijów. Jest wstępny raport
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-atak-rakietowy-na-kijow-jest-wstepny-raport,nId,6845134](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-atak-rakietowy-na-kijow-jest-wstepny-raport,nId,6845134)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-16 11:22:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-atak-rakietowy-na-kijow-jest-wstepny-raport,nId,6845134"><img align="left" alt="Atak rakietowy na Kijów. Jest wstępny raport" src="https://i.iplsc.com/atak-rakietowy-na-kijow-jest-wstepny-raport/000HACN9XPSTRDKP-C321.jpg" /></a>Wybuchy, które w piątek słyszano w Kijowie, spowodował systemy obrony powietrznej w pobliżu stolicy Ukrainy - poinformował mer Witalij Kliczko. Przypomnijmy, w mieście przebywa aktualnie prezydent Republiki Południowej Afryki.</p><br clear="all" />

## Miała prawo jazdy trzy tygodnie. Doprowadziła do dwóch kolizji
 - [https://wydarzenia.interia.pl/slaskie/news-miala-prawo-jazdy-trzy-tygodnie-doprowadzila-do-dwoch-kolizj,nId,6845133](https://wydarzenia.interia.pl/slaskie/news-miala-prawo-jazdy-trzy-tygodnie-doprowadzila-do-dwoch-kolizj,nId,6845133)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-16 10:57:00+00:00

<p><a href="https://wydarzenia.interia.pl/slaskie/news-miala-prawo-jazdy-trzy-tygodnie-doprowadzila-do-dwoch-kolizj,nId,6845133"><img align="left" alt="Miała prawo jazdy trzy tygodnie. Doprowadziła do dwóch kolizji" src="https://i.iplsc.com/miala-prawo-jazdy-trzy-tygodnie-doprowadzila-do-dwoch-kolizj/000HACKL9Y3JGNYW-C321.jpg" /></a>W Świętochłowicach na jednym z przejść dla pieszych 18-latka kierująca samochodem osobowym potrąciła pieszą. Następnie odjechała z miejsca zdarzenia. Uderzyła jeszcze w tył innego pojazdu. Kierująca odebrała prawo jazdy zaledwie trzy tygodnie wcześniej. </p><br clear="all" />

## Polacy chcą więcej referendów. Interia dotarła do niepublikowanego sondażu
 - [https://wydarzenia.interia.pl/kraj/news-polacy-chca-wiecej-referendow-interia-dotarla-do-niepublikow,nId,6845046](https://wydarzenia.interia.pl/kraj/news-polacy-chca-wiecej-referendow-interia-dotarla-do-niepublikow,nId,6845046)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-16 10:43:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-polacy-chca-wiecej-referendow-interia-dotarla-do-niepublikow,nId,6845046"><img align="left" alt="Polacy chcą więcej referendów. Interia dotarła do niepublikowanego sondażu" src="https://i.iplsc.com/polacy-chca-wiecej-referendow-interia-dotarla-do-niepublikow/000HACD1H3YNCSXC-C321.jpg" /></a>Większość Polaków chciałoby zmiany prawa, która pozwoliłaby na przeprowadzenie referendum razem z wyborami parlamentarnymi - wynika z niepublikowanego  wcześniej badania IBRiS dla LubBezpośrednio.pl. Interia jako pierwsza dotarła do wyników sondażu, z którego wynika m.in., że większość respondentów chciałaby obligatoryjnych referendów po zebraniu miliona podpisów. W czwartek Jarosław Kaczyński powiedział, że Polacy powinni wypowiedzieć się w sprawie unijnych regulacji dotyczących migrantów. Pomysł lidera PiS popiera Paweł Kukiz. W Polsce nie...</p><br clear="all" />

## Klauzula sumienia. Naczelna Izba Lekarska odpowiada Lewicy
 - [https://wydarzenia.interia.pl/kraj/news-klauzula-sumienia-naczelna-izba-lekarska-odpowiada-lewicy,nId,6845071](https://wydarzenia.interia.pl/kraj/news-klauzula-sumienia-naczelna-izba-lekarska-odpowiada-lewicy,nId,6845071)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-16 10:37:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-klauzula-sumienia-naczelna-izba-lekarska-odpowiada-lewicy,nId,6845071"><img align="left" alt="Klauzula sumienia. Naczelna Izba Lekarska odpowiada Lewicy" src="https://i.iplsc.com/klauzula-sumienia-naczelna-izba-lekarska-odpowiada-lewicy/000HACCE40PJMGH0-C321.jpg" /></a>&quot;Klauzula sumienia wynika m.in z Karty Praw Podstawowych Unii Europejskiej. Jednocześnie pragniemy przypomnieć, że klauzula sumienia nie obowiązuje w przypadku zagrożenia życia lub zdrowia pacjentek&quot; - poinformowała na Twitterze Naczelna Izba Lekarska, odnosząc się do inicjatywy ustawodawczej Lewicy. To kolejna odsłona dyskusji w kontekście prawa do aborcji w Polsce.</p><br clear="all" />

## Dyplomaci przez kilkanaście godzin nie wyszli z samolotu. "Sami podjęli decyzję"
 - [https://wydarzenia.interia.pl/kraj/news-dyplomaci-przez-kilkanascie-godzin-nie-wyszli-z-samolotu-sam,nId,6845099](https://wydarzenia.interia.pl/kraj/news-dyplomaci-przez-kilkanascie-godzin-nie-wyszli-z-samolotu-sam,nId,6845099)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-16 10:21:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-dyplomaci-przez-kilkanascie-godzin-nie-wyszli-z-samolotu-sam,nId,6845099"><img align="left" alt="Dyplomaci przez kilkanaście godzin nie wyszli z samolotu. &quot;Sami podjęli decyzję&quot;" src="https://i.iplsc.com/dyplomaci-przez-kilkanascie-godzin-nie-wyszli-z-samolotu-sam/000HACHTVSA3IFID-C321.jpg" /></a>Delegacja dyplomatyczna RPA nie opuściła pokładu swojego samolotu przez kilkanaście godzin, ponieważ nie miała zgody na wjazd do Polski z bronią, którą posiadała - oświadczyła Straż Graniczna. Służby podkreśliły, że wszystkie osoby same podjęły decyzje o pozostaniu w samolocie - gdyby zostawili broń, mogliby wjechać na terytorium RP. Rzeczniczka lotniska Chopina Anna Dermont przekazała w rozmowie z Interią, że wszyscy mają zapewnione jedzenie i napoje.</p><br clear="all" />

## Donald Tusk idzie za ciosem. Rozpoczyna "wiecowy" etap kampanii
 - [https://wydarzenia.interia.pl/kraj/news-donald-tusk-idzie-za-ciosem-rozpoczyna-wiecowy-etap-kampanii,nId,6845042](https://wydarzenia.interia.pl/kraj/news-donald-tusk-idzie-za-ciosem-rozpoczyna-wiecowy-etap-kampanii,nId,6845042)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-16 09:58:29+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-donald-tusk-idzie-za-ciosem-rozpoczyna-wiecowy-etap-kampanii,nId,6845042"><img align="left" alt="Donald Tusk idzie za ciosem. Rozpoczyna &quot;wiecowy&quot; etap kampanii" src="https://i.iplsc.com/donald-tusk-idzie-za-ciosem-rozpoczyna-wiecowy-etap-kampanii/000HABZX8MJSDG8R-C321.jpg" /></a>Po marszu 4 czerwca Platforma Obywatelska idzie za ciosem i zapowiada dogrywkę. Jej pierwsza część odbędzie się w piątek w Poznaniu, gdzie Donald Tusk ma przemawiać do kilku tysięcy osób. Tym samym rozpocznie &quot;wiecowy&quot; etap kampanii PO. Kolejna odsłona już 24 czerwca we Wrocławiu. - Będzie mnóstwo ludzi. Boimy się, że zainteresowanie nas przerośnie. Szykujemy się na normalne wydarzenie, ale może zrobić się z tego coś wielkiego - słyszymy w PO. Co ciekawe, tego samego dnia konwencje planują PiS i Konfederacja.</p><br clear="all" />

## W wypadku zginęło pięć osób. Sąd podjął decyzję ws. podejrzanego
 - [https://wydarzenia.interia.pl/swietokrzyskie/news-w-wypadku-zginelo-piec-osob-sad-podjal-decyzje-ws-podejrzane,nId,6844979](https://wydarzenia.interia.pl/swietokrzyskie/news-w-wypadku-zginelo-piec-osob-sad-podjal-decyzje-ws-podejrzane,nId,6844979)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-16 08:07:00+00:00

<p><a href="https://wydarzenia.interia.pl/swietokrzyskie/news-w-wypadku-zginelo-piec-osob-sad-podjal-decyzje-ws-podejrzane,nId,6844979"><img align="left" alt="W wypadku zginęło pięć osób. Sąd podjął decyzję ws. podejrzanego" src="https://i.iplsc.com/w-wypadku-zginelo-piec-osob-sad-podjal-decyzje-ws-podejrzane/000HABMURIATEFYM-C321.jpg" /></a>Sąd zdecydował o aresztowaniu na trzy miesiące Piotra M. Mężczyzna jest podejrzany o spowodowanie wypadku, w którym zginęło pięć osób. Do tragedii doszło pod koniec maja w miejscowości Boksycka w województwie świętokrzyskim. Sprawca wypadku był nietrzeźwy i pod wpływem narkotyków.</p><br clear="all" />

## Komisja ds. rosyjskich wpływów. Prezydencka nowelizacja w Sejmie. "Pałka zamiast siekiery"
 - [https://wydarzenia.interia.pl/kraj/news-komisja-ds-rosyjskich-wplywow-prezydencka-nowelizacja-w-sejm,nId,6844954](https://wydarzenia.interia.pl/kraj/news-komisja-ds-rosyjskich-wplywow-prezydencka-nowelizacja-w-sejm,nId,6844954)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-16 07:45:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-komisja-ds-rosyjskich-wplywow-prezydencka-nowelizacja-w-sejm,nId,6844954"><img align="left" alt="Komisja ds. rosyjskich wpływów. Prezydencka nowelizacja w Sejmie. &quot;Pałka zamiast siekiery&quot;" src="https://i.iplsc.com/komisja-ds-rosyjskich-wplywow-prezydencka-nowelizacja-w-sejm/000G86IHUI0IKD5K-C321.jpg" /></a>- Ta nowelizacja to zaproponowanie pałki zamiast siekiery i uniemożliwienie Donaldowi Tuskowi sprawowania urzędu premiera - stwierdził poseł Koalicji Obywatelskiej Bartłomiej Sienkiewicz, oceniając zaproponowane przez prezydenta zmiany w ustawie o powołaniu komisji ds. badania rosyjskich wpływów. Zdaniem posła PiS Piotra Kalety intencją rządzących jest natomiast &quot;oczyszczenie Polski ze złogów agentów, zdrajców i tych, którzy byli dla naszej państwowości nieprzyjaźni&quot;.</p><br clear="all" />

## Relokacja: Prezent Unii dla Prawa i Sprawiedliwości
 - [https://wydarzenia.interia.pl/felietony/news-relokacja-prezent-unii-dla-prawa-i-sprawiedliwosci,nId,6844991](https://wydarzenia.interia.pl/felietony/news-relokacja-prezent-unii-dla-prawa-i-sprawiedliwosci,nId,6844991)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-16 07:40:58+00:00

<p><a href="https://wydarzenia.interia.pl/felietony/news-relokacja-prezent-unii-dla-prawa-i-sprawiedliwosci,nId,6844991"><img align="left" alt="Relokacja: Prezent Unii dla Prawa i Sprawiedliwości" src="https://i.iplsc.com/relokacja-prezent-unii-dla-prawa-i-sprawiedliwosci/000FU3LLJOU8LCVE-C321.jpg" /></a>Można sprowadzać pomysł Jarosława Kaczyńskiego na referendum o relokacji imigrantów do kolejnej sztuczki kampanijnej. Tylko że choć to wyborcze zagranie, piłkę podaje prezesowi PiS szacowna Unia Europejska. Bo w jednym ma on rację: potraktowanie Polski to naprawdę bezczelna dyskryminacja.</p><br clear="all" />

## Rosyjskie systemy walki radioelektronicznej utrudniają kontrofensywę
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosyjskie-systemy-walki-radioelektronicznej-utrudniaja-kontr,nId,6844948](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosyjskie-systemy-walki-radioelektronicznej-utrudniaja-kontr,nId,6844948)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-16 07:26:19+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosyjskie-systemy-walki-radioelektronicznej-utrudniaja-kontr,nId,6844948"><img align="left" alt="Rosyjskie systemy walki radioelektronicznej utrudniają kontrofensywę" src="https://i.iplsc.com/rosyjskie-systemy-walki-radioelektronicznej-utrudniaja-kontr/000HABIN66DFXGI8-C321.jpg" /></a>Rosyjskie systemy walki radioelektronicznej utrudniają ukraińską kontrofensywę - podaje w najnowszym raporcie Instytut Studiów nad Wojną (ISW). Ośrodek cytuje rosyjskich tzw. blogerów wojennych, którzy chwalą systemy Murmansk i Krasucha.</p><br clear="all" />

## Smaczki z gwoździami dla psa. Policja apeluje do mieszkańców
 - [https://wydarzenia.interia.pl/malopolskie/news-smaczki-z-gwozdziami-dla-psa-policja-apeluje-do-mieszkancow,nId,6844945](https://wydarzenia.interia.pl/malopolskie/news-smaczki-z-gwozdziami-dla-psa-policja-apeluje-do-mieszkancow,nId,6844945)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-16 07:23:00+00:00

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-smaczki-z-gwozdziami-dla-psa-policja-apeluje-do-mieszkancow,nId,6844945"><img align="left" alt="Smaczki z gwoździami dla psa. Policja apeluje do mieszkańców" src="https://i.iplsc.com/smaczki-z-gwozdziami-dla-psa-policja-apeluje-do-mieszkancow/000HABNXW0AFA88I-C321.jpg" /></a>Jeden z czworonogów padł ofiarą karygodnego czynu. W Chełmku (woj. małopolskie) ktoś rozrzucił smaczki i parówki dla psów, w których znajdowały się gwoździe. Szybka reakcja właścicielki oraz pomoc weterynarza uratowały życie psa. Policja szuka sprawcy oraz apeluje do mieszkańców i posiadaczy zwierzaków.</p><br clear="all" />

## Pionierski lot komercyjny w kosmos jeszcze w czerwcu. "Nie lada wydatek"
 - [https://wydarzenia.interia.pl/zagranica/news-pionierski-lot-komercyjny-w-kosmos-jeszcze-w-czerwcu-nie-lad,nId,6844918](https://wydarzenia.interia.pl/zagranica/news-pionierski-lot-komercyjny-w-kosmos-jeszcze-w-czerwcu-nie-lad,nId,6844918)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-16 06:54:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-pionierski-lot-komercyjny-w-kosmos-jeszcze-w-czerwcu-nie-lad,nId,6844918"><img align="left" alt="Pionierski lot komercyjny w kosmos jeszcze w czerwcu. &quot;Nie lada wydatek&quot;" src="https://i.iplsc.com/pionierski-lot-komercyjny-w-kosmos-jeszcze-w-czerwcu-nie-lad/000HABCMVTI3XIOV-C321.jpg" /></a>Pod koniec czerwca odbędzie się pierwszy komercyjny lot - zapowiedziała firma Virigin Galactic, której właścicielem jest brytyjski miliarder Richard Branson. Szansa na wzniesienie się na wysokość ponad 80 km i poczucie stanu nieważkości przez kilka minut to jednak nie lada wydatek blisko dwóch milionów złotych. Przedsiębiorstwo przekonuje, że znalazło już 800 chętnych. </p><br clear="all" />

## Policjant próbował połknąć wyłudzone pieniądze. Trafił do szpitala
 - [https://wydarzenia.interia.pl/zagranica/news-policjant-probowal-polknac-wyludzone-pieniadze-trafil-do-szp,nId,6844928](https://wydarzenia.interia.pl/zagranica/news-policjant-probowal-polknac-wyludzone-pieniadze-trafil-do-szp,nId,6844928)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-16 06:47:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-policjant-probowal-polknac-wyludzone-pieniadze-trafil-do-szp,nId,6844928"><img align="left" alt="Policjant próbował połknąć wyłudzone pieniądze. Trafił do szpitala" src="https://i.iplsc.com/policjant-probowal-polknac-wyludzone-pieniadze-trafil-do-szp/000HABB8KGJGLMDX-C321.jpg" /></a>Kolumbijski policjant trafił do szpitala po tym, jak połknął wyłudzone od biznesmena pieniądze. Zwitek banknotów utknął mu w gardle.</p><br clear="all" />

## Amerykanie reagują na działania Kim Dzong Una. Wysłali do sojusznika okręt atomowy
 - [https://wydarzenia.interia.pl/zagranica/news-amerykanie-reaguja-na-dzialania-kim-dzong-una-wyslali-do-soj,nId,6844925](https://wydarzenia.interia.pl/zagranica/news-amerykanie-reaguja-na-dzialania-kim-dzong-una-wyslali-do-soj,nId,6844925)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-16 06:15:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-amerykanie-reaguja-na-dzialania-kim-dzong-una-wyslali-do-soj,nId,6844925"><img align="left" alt="Amerykanie reagują na działania Kim Dzong Una. Wysłali do sojusznika okręt atomowy" src="https://i.iplsc.com/amerykanie-reaguja-na-dzialania-kim-dzong-una-wyslali-do-soj/000HAB842XK2KOQM-C321.jpg" /></a>Stany Zjednoczone uważnie obserwują sytuację na Półwyspie Koreańskim. W południowokoreańskim mieście Busan zacumował amerykański okręt podwodny o napędzie atomowym. To prawdopodobnie reakcja na działania Korei Północnej. Reżim Kim Dzong Una wystrzelił w ramach ćwiczeń dwie rakiety krótkiego zasięgu.</p><br clear="all" />

## "The Spectator": Zaskakujący pomysł na zakończenie wojny. "Nie ma czasu do stracenia"
 - [https://wydarzenia.interia.pl/raport-media-zagraniczne/news-the-spectator-zaskakujacy-pomysl-na-zakonczenie-wojny-nie-ma,nId,6838913](https://wydarzenia.interia.pl/raport-media-zagraniczne/news-the-spectator-zaskakujacy-pomysl-na-zakonczenie-wojny-nie-ma,nId,6838913)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-16 05:50:00+00:00

<p><a href="https://wydarzenia.interia.pl/raport-media-zagraniczne/news-the-spectator-zaskakujacy-pomysl-na-zakonczenie-wojny-nie-ma,nId,6838913"><img align="left" alt="&quot;The Spectator&quot;: Zaskakujący pomysł na zakończenie wojny. &quot;Nie ma czasu do stracenia&quot;" src="https://i.iplsc.com/the-spectator-zaskakujacy-pomysl-na-zakonczenie-wojny-nie-ma/000H9XS85RIATA1B-C321.jpg" /></a>Waszyngton powinien samodzielnie i zakulisowo wynegocjować warunki kapitulacji sił rosyjskich. Jak to zrobić? Podpowiedzią mogą być tajne kontakty Amerykanów z przedstawicielami nazistowskich Niemiec u schyłku II wojny światowej - przekonuje Boris Ryvkin, były doradca ds. bezpieczeństwa narodowego amerykańskiego senatora Teda Cruza. </p><br clear="all" />

## Karaganow proponuje atak jądrowy na Europę. Niepokój po słowach politologa
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-karaganow-proponuje-atak-jadrowy-na-europe-niepokoj-po-slowa,nId,6844891](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-karaganow-proponuje-atak-jadrowy-na-europe-niepokoj-po-slowa,nId,6844891)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-16 05:42:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-karaganow-proponuje-atak-jadrowy-na-europe-niepokoj-po-slowa,nId,6844891"><img align="left" alt="Karaganow proponuje atak jądrowy na Europę. Niepokój po słowach politologa" src="https://i.iplsc.com/karaganow-proponuje-atak-jadrowy-na-europe-niepokoj-po-slowa/000HAB6538Y4O5P3-C321.jpg" /></a>Przyzwyczailiśmy się, że rosyjskie tuby propagandowe co rusz straszą Zachód kolejnymi groźbami. Tym razem pojawił się nowy głos w dyskusji. Politolog Siergiej Karaganow poszedł o krok dalej - zaproponował przeprowadzenie &quot;prewencyjnego ataku nuklearnego na Europę&quot;. Zdaniem &quot;eksperta&quot;, USA nie zareagowałyby w tej sprawie, bo nikt nie poświęci &quot;warunkowego Bostonu dla dobra warunkowego Poznania&quot;. Portal Meduza wskazuje, że głoszone przez Karaganowa tezy mogą wpłynąć na rosyjskie dowództwo.</p><br clear="all" />

## Duma z posłów i senatorów. Kiedyś to było możliwe
 - [https://wydarzenia.interia.pl/raport-historia-w-interii/news-duma-z-poslow-i-senatorow-kiedys-to-bylo-mozliwe,nId,6827982](https://wydarzenia.interia.pl/raport-historia-w-interii/news-duma-z-poslow-i-senatorow-kiedys-to-bylo-mozliwe,nId,6827982)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-16 05:30:00+00:00

<p><a href="https://wydarzenia.interia.pl/raport-historia-w-interii/news-duma-z-poslow-i-senatorow-kiedys-to-bylo-mozliwe,nId,6827982"><img align="left" alt="Duma z posłów i senatorów. Kiedyś to było możliwe" src="https://i.iplsc.com/duma-z-poslow-i-senatorow-kiedys-to-bylo-mozliwe/000H94E141RRIC82-C321.jpg" /></a>Sejm, który w chwili zagrożenia robi wszystko, by uchronić kraj. Honor tak ważny, że hańba na tchórzach zostaje na wieki. Brzmi jak bajka? W najnowszej &quot;Historii w Interii&quot; opowiadamy o wielkich chwilach polskich posłów i senatorów, czasach, kiedy historycy opisywali ich jako &quot;elitę parlamentarną&quot;, która potrafiła poradzić sobie z największymi kryzysami.</p><br clear="all" />

## Zagraniczna wizyta Putina. Dostał zaproszenie z kraju NATO
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zagraniczna-wizyta-putina-dostal-zaproszenie-z-kraju-nato,nId,6844894](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zagraniczna-wizyta-putina-dostal-zaproszenie-z-kraju-nato,nId,6844894)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-16 04:41:05+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zagraniczna-wizyta-putina-dostal-zaproszenie-z-kraju-nato,nId,6844894"><img align="left" alt="Zagraniczna wizyta Putina. Dostał zaproszenie z kraju NATO" src="https://i.iplsc.com/zagraniczna-wizyta-putina-dostal-zaproszenie-z-kraju-nato/000HAB4OE224GXBU-C321.jpg" /></a>Władimir Putin został zaproszony do Turcji przez prezydenta Recepa Tayyipa Erdoğana - podają propagandowe rosyjskie media. Informację o planach zagranicznej wizyty potwierdził doradca przywódcy Rosji Jurji Uszakow. Dodał, że &quot;nie ustalono konkretnych dat&quot;.</p><br clear="all" />

## Wojna w Ukrainie. 478. dzień inwazji Rosji
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-478-dzien-inwazji-rosji,nzId,4355,akt,160551](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-478-dzien-inwazji-rosji,nzId,4355,akt,160551)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-16 03:44:16+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-478-dzien-inwazji-rosji,nzId,4355,akt,160551"><img align="left" alt="Wojna w Ukrainie. 478. dzień inwazji Rosji" src="https://i.iplsc.com/wojna-w-ukrainie-478-dzien-inwazji-rosji/000H960NRI8OQLUH-C321.jpg" /></a>Śledź najnowsze informacje z frontu.</p><br clear="all" />

## Wojna w Ukrainie. 478. dzień inwazji Rosji
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-478-dzien-inwazji-rosji,nzId,4355,akt,160622](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-478-dzien-inwazji-rosji,nzId,4355,akt,160622)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-16 03:44:16+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-478-dzien-inwazji-rosji,nzId,4355,akt,160622"><img align="left" alt="Wojna w Ukrainie. 478. dzień inwazji Rosji" src="https://i.iplsc.com/wojna-w-ukrainie-478-dzien-inwazji-rosji/000H960NRI8OQLUH-C321.jpg" /></a>Śledź najnowsze informacje z frontu.</p><br clear="all" />

## Wojna w Ukrainie. 478. dzień inwazji Rosji
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-478-dzien-inwazji-rosji,nzId,4355,akt,160744](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-478-dzien-inwazji-rosji,nzId,4355,akt,160744)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-16 03:44:16+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-478-dzien-inwazji-rosji,nzId,4355,akt,160744"><img align="left" alt="Wojna w Ukrainie. 478. dzień inwazji Rosji" src="https://i.iplsc.com/wojna-w-ukrainie-478-dzien-inwazji-rosji/000H960NRI8OQLUH-C321.jpg" /></a>Śledź najnowsze informacje z frontu.</p><br clear="all" />

