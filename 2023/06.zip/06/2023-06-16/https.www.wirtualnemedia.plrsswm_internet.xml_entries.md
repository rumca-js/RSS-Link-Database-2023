# Source:Wirtualne Media - Internet, URL:https://www.wirtualnemedia.pl/rss/wm_internet.xml, language:pl-PL

## Sandra Drzymalska i Maria Dębska w obsadzie "Pana Samochodzika i Templariuszy". Poznaliśmy datę premiery
 - [https://www.wirtualnemedia.pl/artykul/sandra-drzymalska-maria-debska-pan-samochodzik-i-templariuszy-netflix-zwiastun-premiera-obsadaa](https://www.wirtualnemedia.pl/artykul/sandra-drzymalska-maria-debska-pan-samochodzik-i-templariuszy-netflix-zwiastun-premiera-obsadaa)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-06-16 12:59:45.985227+00:00

Aktorki Sandra Drzymalska oraz Maria Dębska dołączają do obsady "Pana Samochodzika i Templariuszy".  Premiera filmu z Mateuszem Janickim w roli głównej, już 12 lipca w Netfliksie.

## Sandra Drzymalska i Maria Dębska w obsadzie "Pana Samochodzika i Templariuszy". Poznaliśmy datę premiery
 - [https://www.wirtualnemedia.pl/artykul/sandra-drzymalska-i-maria-debska-w-obsadzie-pana-samochodzika-i-templariuszy-poznalismy-date-premiery](https://www.wirtualnemedia.pl/artykul/sandra-drzymalska-i-maria-debska-w-obsadzie-pana-samochodzika-i-templariuszy-poznalismy-date-premiery)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-06-16 11:57:39.433574+00:00

Aktorki Sandra Drzymalska oraz Maria Dębska dołączają do obsady "Pana Samochodzika i Templariuszy".  Premiera filmu z Mateuszem Janickim w roli głównej, już 12 lipca w Netfliksie.

## Do Viaplay Group szybko wraca szef sportu
 - [https://www.wirtualnemedia.pl/artykul/viaplay-platforma-szybko-wraca-szef-sportu](https://www.wirtualnemedia.pl/artykul/viaplay-platforma-szybko-wraca-szef-sportu)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-06-16 06:03:28.830025+00:00

Stanowisko wiceprezesa wykonawczego oraz szefa sportu i rozwoju biznesu sportowego w Viaplay Group objął Peter Nørrelund, wracając do firmy po kilku miesiącach przerwy. Zastąpił w niej Cecilię Gave.

## Piotr Szlachtowicz zastąpił Marcina Rolę w roli naczelnego wRealu24
 - [https://www.wirtualnemedia.pl/artykul/piotr-szlachtowicz-redaktor-naczelny-wrealu24-koniec-marcin-rola](https://www.wirtualnemedia.pl/artykul/piotr-szlachtowicz-redaktor-naczelny-wrealu24-koniec-marcin-rola)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-06-16 05:01:49.718342+00:00

Piotr Szlachtowicz od 15 czerwca jest redaktorem naczelnym telewizji wRealu24. Zastąpił na stanowisku Marcina Rolę, który objął funkcję dyrektora generalnego spółki Nowe Polskie Media. Będzie jednak w dalszym ciągu prowadził wszystkie swoje dotychczasowe programy.

## Bogusław Wołoszański będzie miał program w „Super Expressie”
 - [https://www.wirtualnemedia.pl/artykul/boguslaw-woloszanski-program-super-express](https://www.wirtualnemedia.pl/artykul/boguslaw-woloszanski-program-super-express)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-06-16 05:01:49.709825+00:00

Dziennikarz i pisarz historyczny Bogusław Wołoszański wkrótce zacznie prowadzić autorski program na portalu i profilach społecznościowych „Super Expressu” (Grupa ZPR Media). Wcześniej Wołoszański współpracował przez lata m.in. z Telewizją Polską i Polsatem.

## Rekordowa oglądalność finału Ligi Mistrzów i Roland Garros w streamingu
 - [https://www.wirtualnemedia.pl/artykul/liga-mistrzow-roland-garros-french-open-serwisy-streamingowe-rekord-ogladalnosci](https://www.wirtualnemedia.pl/artykul/liga-mistrzow-roland-garros-french-open-serwisy-streamingowe-rekord-ogladalnosci)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-06-16 04:00:10.578042+00:00

Sobotnie finały Ligi Mistrzów i Roland Garros przyciągnęły rekordowo dużo widzów do serwisów streamingowych. Z analizy firmy NPAW wynika, że mecz między Manchesterem City a Interem Mediolan oglądało w ten sposób 45 proc. więcej unikalnych użytkowników niż przed rokiem. Do obejrzenia obu wydarzeń najczęściej sięgano po telewizory Smart TV.

## Bogusław Wołoszański będzie miał program w „Super Expressie”
 - [https://www.wirtualnemedia.pl/artykul/boguslaw-woloszanski-nowy-program-super-express](https://www.wirtualnemedia.pl/artykul/boguslaw-woloszanski-nowy-program-super-express)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-06-16 04:00:10.575986+00:00

Dziennikarz i pisarz historyczny Bogusław Wołoszański wkrótce zacznie prowadzić autorski program na portalu i profilach społecznościowych „Super Expressu” (Grupa ZPR Media). Wcześniej Wołoszański współpracował przez lata m.in. z Telewizją Polską i Polsatem.

## Właściciel Reserved i Sinsay stawia na sklepy stacjonarne kosztem e-commerce. Ma już ponad 2000 sklepów
 - [https://www.wirtualnemedia.pl/artykul/lpp-wlasciciel-reserved-sinsay-stawia-na-sklepy-stacjonarne-kosztem-e-commerce-ma-juz-ponad-2000-sklepow](https://www.wirtualnemedia.pl/artykul/lpp-wlasciciel-reserved-sinsay-stawia-na-sklepy-stacjonarne-kosztem-e-commerce-ma-juz-ponad-2000-sklepow)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-06-16 04:00:10.573718+00:00

Spółka odzieżowa LPP, do której należą marki Reserved, Mohito, House, Cropp i Sinsay, w pierwszym kwartale roku finansowego 2023/24 odnotowała wzrost przychodów do 3,64 mld zł z 3,04 mld zł w analogicznym okresie roku ubiegłego (+19,9 proc. rdr.). Najmocniej rosą marki Cropp i Sinsay, notujące odpowiednio wzrosty o 29 proc. i 26,8 proc. Firma stawia na sprzedaż w kanale stacjonarnymi tnie wydatki marketingowe na ecommerce. LPP ma już ponad 2000 sklepów, z czego połowę w Polsce.

