# Source:Wydarzenia Interia - Świat, URL:https://wydarzenia.interia.pl/swiat/feed, language:pl-PL

## Nie żyje kobieta i jej 7-letnie dziecko. Prokuratura wszczęła śledztwo
 - [https://wydarzenia.interia.pl/zagranica/news-nie-zyje-kobieta-i-jej-7-letnie-dziecko-prokuratura-wszczela,nId,6873669](https://wydarzenia.interia.pl/zagranica/news-nie-zyje-kobieta-i-jej-7-letnie-dziecko-prokuratura-wszczela,nId,6873669)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-06-30T09:21:57+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-nie-zyje-kobieta-i-jej-7-letnie-dziecko-prokuratura-wszczela,nId,6873669"><img align="left" alt="Nie żyje kobieta i jej 7-letnie dziecko. Prokuratura wszczęła śledztwo " src="https://i.iplsc.com/nie-zyje-kobieta-i-jej-7-letnie-dziecko-prokuratura-wszczela/000HCH5XO4IAVLAP-C321.jpg" /></a>- Właśnie do Biura Międzynarodowej Współpracy Policji wpłynęła informacja od strony szwedzkiej, aby poinformować najbliższych i rodzinę o śmierci zarówno chłopca, jak i jego matki - powiedział w Polsat News rzecznik Komendanta Głównego Policji inspektor Mariusz Ciarka. Ta dwójka w czwartek wypadła z promu Stena Spirit. Gdańska prokuratura wszczęła śledztwo o czyn z art. 155 Kodeksu karnego, czyli w sprawie nieumyślnego spowodowania śmierci. </p><br clear="all" />

## Wojna w Ukrainie. 492. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-492-dzien-inwazji-rosji-relacja-na-zywo,nzId,4416,akt,300842](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-492-dzien-inwazji-rosji-relacja-na-zywo,nzId,4416,akt,300842)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-06-30T03:46:01+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-492-dzien-inwazji-rosji-relacja-na-zywo,nzId,4416,akt,300842"><img align="left" alt="Wojna w Ukrainie. 492. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-492-dzien-inwazji-rosji-relacja-na-zywo/000HCFWEFNYVJ1LV-C321.jpg" /></a>Zapraszamy do śledzenia relacji z wojny w Ukrainie.</p><br clear="all" />

