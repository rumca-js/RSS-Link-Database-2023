# Source:Hacker News - frontpage, URL:https://hnrss.org/frontpage, language:en-US

## Maximum size of a PDF, version 7: 381 km × 381 km
 - [https://commons.wikimedia.org/wiki/File:Seitengr%C3%B6%C3%9Fe_PDF_7.svg](https://commons.wikimedia.org/wiki/File:Seitengr%C3%B6%C3%9Fe_PDF_7.svg)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T22:46:52+00:00

<p>Article URL: <a href="https://commons.wikimedia.org/wiki/File:Seitengr%C3%B6%C3%9Fe_PDF_7.svg">https://commons.wikimedia.org/wiki/File:Seitengr%C3%B6%C3%9Fe_PDF_7.svg</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36543557">https://news.ycombinator.com/item?id=36543557</a></p>
<p>Points: 8</p>
<p># Comments: 1</p>

## Necessary Illusions: Thought Control in Democratic Societies [pdf]
 - [https://www.cia.gov/library/abbottabad-compound/52/526D2E781AC9EBBB13346BDF7693E1BB_CHOMSKY_Noam_-_Necessary_Illusions.pdf](https://www.cia.gov/library/abbottabad-compound/52/526D2E781AC9EBBB13346BDF7693E1BB_CHOMSKY_Noam_-_Necessary_Illusions.pdf)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T22:22:56+00:00

<p>Article URL: <a href="https://www.cia.gov/library/abbottabad-compound/52/526D2E781AC9EBBB13346BDF7693E1BB_CHOMSKY_Noam_-_Necessary_Illusions.pdf">https://www.cia.gov/library/abbottabad-compound/52/526D2E781AC9EBBB13346BDF7693E1BB_CHOMSKY_Noam_-_Necessary_Illusions.pdf</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36543284">https://news.ycombinator.com/item?id=36543284</a></p>
<p>Points: 8</p>
<p># Comments: 6</p>

## The Liberty Phone
 - [https://puri.sm/posts/introducing-the-liberty-phone/](https://puri.sm/posts/introducing-the-liberty-phone/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T22:02:30+00:00

<p>Article URL: <a href="https://puri.sm/posts/introducing-the-liberty-phone/">https://puri.sm/posts/introducing-the-liberty-phone/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36543018">https://news.ycombinator.com/item?id=36543018</a></p>
<p>Points: 34</p>
<p># Comments: 35</p>

## Boxed types in OCaml, and other thoughts
 - [https://blog.ajour.io/language-choices-do-they-matter-also-whats-this-ocaml/](https://blog.ajour.io/language-choices-do-they-matter-also-whats-this-ocaml/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T21:56:42+00:00

<p>Article URL: <a href="https://blog.ajour.io/language-choices-do-they-matter-also-whats-this-ocaml/">https://blog.ajour.io/language-choices-do-they-matter-also-whats-this-ocaml/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36542937">https://news.ycombinator.com/item?id=36542937</a></p>
<p>Points: 11</p>
<p># Comments: 5</p>

## Time lapse of this week's large sunspot
 - [https://www.astrobin.com/full/qti3dk/0/](https://www.astrobin.com/full/qti3dk/0/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T21:36:59+00:00

<p>Article URL: <a href="https://www.astrobin.com/full/qti3dk/0/">https://www.astrobin.com/full/qti3dk/0/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36542673">https://news.ycombinator.com/item?id=36542673</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## FFE Games
 - [https://farfuture.net/](https://farfuture.net/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T21:36:29+00:00

<p>Article URL: <a href="https://farfuture.net/">https://farfuture.net/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36542664">https://news.ycombinator.com/item?id=36542664</a></p>
<p>Points: 7</p>
<p># Comments: 1</p>

## Brazil's Jair Bolsonaro is barred from office until 2030
 - [https://www.washingtonpost.com/politics/2023/06/30/brazil-bolsonaro-ineligible-court-ruling-vote/465d30ea-175d-11ee-9de3-ba1fa29e9bec_story.html](https://www.washingtonpost.com/politics/2023/06/30/brazil-bolsonaro-ineligible-court-ruling-vote/465d30ea-175d-11ee-9de3-ba1fa29e9bec_story.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T21:33:52+00:00

<p>Article URL: <a href="https://www.washingtonpost.com/politics/2023/06/30/brazil-bolsonaro-ineligible-court-ruling-vote/465d30ea-175d-11ee-9de3-ba1fa29e9bec_story.html">https://www.washingtonpost.com/politics/2023/06/30/brazil-bolsonaro-ineligible-court-ruling-vote/465d30ea-175d-11ee-9de3-ba1fa29e9bec_story.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36542634">https://news.ycombinator.com/item?id=36542634</a></p>
<p>Points: 36</p>
<p># Comments: 11</p>

## FTC Announces Proposed Rule Banning Fake Reviews and Testimonials
 - [https://www.ftc.gov/news-events/news/press-releases/2023/06/federal-trade-commission-announces-proposed-rule-banning-fake-reviews-testimonials](https://www.ftc.gov/news-events/news/press-releases/2023/06/federal-trade-commission-announces-proposed-rule-banning-fake-reviews-testimonials)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T21:23:14+00:00

<p>Article URL: <a href="https://www.ftc.gov/news-events/news/press-releases/2023/06/federal-trade-commission-announces-proposed-rule-banning-fake-reviews-testimonials">https://www.ftc.gov/news-events/news/press-releases/2023/06/federal-trade-commission-announces-proposed-rule-banning-fake-reviews-testimonials</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36542500">https://news.ycombinator.com/item?id=36542500</a></p>
<p>Points: 48</p>
<p># Comments: 18</p>

## To unlock drink verification can
 - [https://gamefaqs.gamespot.com/boards/632877-halo-4/66477630](https://gamefaqs.gamespot.com/boards/632877-halo-4/66477630)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T21:22:31+00:00

<p>Article URL: <a href="https://gamefaqs.gamespot.com/boards/632877-halo-4/66477630">https://gamefaqs.gamespot.com/boards/632877-halo-4/66477630</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36542487">https://news.ycombinator.com/item?id=36542487</a></p>
<p>Points: 12</p>
<p># Comments: 0</p>

## SEC notifies SolarWinds CISO and CFO of possible action in cyber investigation
 - [https://www.cybersecuritydive.com/news/sec-solarwinds-ciso-cfo-orion/653864/](https://www.cybersecuritydive.com/news/sec-solarwinds-ciso-cfo-orion/653864/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T21:08:14+00:00

<p>Article URL: <a href="https://www.cybersecuritydive.com/news/sec-solarwinds-ciso-cfo-orion/653864/">https://www.cybersecuritydive.com/news/sec-solarwinds-ciso-cfo-orion/653864/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36542298">https://news.ycombinator.com/item?id=36542298</a></p>
<p>Points: 22</p>
<p># Comments: 6</p>

## MDN can now automatically lie to people seeking technical information
 - [https://github.com/mdn/yari/issues/9208](https://github.com/mdn/yari/issues/9208)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T21:05:32+00:00

<p>Article URL: <a href="https://github.com/mdn/yari/issues/9208">https://github.com/mdn/yari/issues/9208</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36542267">https://news.ycombinator.com/item?id=36542267</a></p>
<p>Points: 43</p>
<p># Comments: 15</p>

## FBI finally tracks “swatting” incidents as attacks increase nationwide
 - [https://arstechnica.com/tech-policy/2023/06/fbi-finally-tracks-swatting-incidents-as-attacks-increase-nationwide/](https://arstechnica.com/tech-policy/2023/06/fbi-finally-tracks-swatting-incidents-as-attacks-increase-nationwide/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T21:04:15+00:00

<p>Article URL: <a href="https://arstechnica.com/tech-policy/2023/06/fbi-finally-tracks-swatting-incidents-as-attacks-increase-nationwide/">https://arstechnica.com/tech-policy/2023/06/fbi-finally-tracks-swatting-incidents-as-attacks-increase-nationwide/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36542252">https://news.ycombinator.com/item?id=36542252</a></p>
<p>Points: 16</p>
<p># Comments: 2</p>

## RIP Nitter
 - [https://github.com/zedeus/nitter/issues/919](https://github.com/zedeus/nitter/issues/919)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T20:58:09+00:00

<p>Article URL: <a href="https://github.com/zedeus/nitter/issues/919">https://github.com/zedeus/nitter/issues/919</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36542179">https://news.ycombinator.com/item?id=36542179</a></p>
<p>Points: 124</p>
<p># Comments: 46</p>

## Australia legalises psychedelics for mental health
 - [https://www.bbc.co.uk/news/world-australia-66072427](https://www.bbc.co.uk/news/world-australia-66072427)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T20:52:05+00:00

<p>Article URL: <a href="https://www.bbc.co.uk/news/world-australia-66072427">https://www.bbc.co.uk/news/world-australia-66072427</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36542101">https://news.ycombinator.com/item?id=36542101</a></p>
<p>Points: 37</p>
<p># Comments: 10</p>

## Goldman Is Looking for a Way Out of Its Partnership with Apple
 - [https://www.wsj.com/articles/goldman-is-looking-for-a-way-out-of-its-partnership-with-apple-79849a91](https://www.wsj.com/articles/goldman-is-looking-for-a-way-out-of-its-partnership-with-apple-79849a91)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T20:34:27+00:00

<p>Article URL: <a href="https://www.wsj.com/articles/goldman-is-looking-for-a-way-out-of-its-partnership-with-apple-79849a91">https://www.wsj.com/articles/goldman-is-looking-for-a-way-out-of-its-partnership-with-apple-79849a91</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36541836">https://news.ycombinator.com/item?id=36541836</a></p>
<p>Points: 14</p>
<p># Comments: 3</p>

## Briar Mailbox released to improve connectivity
 - [https://briarproject.org/news/2023-briar-mailbox-released/](https://briarproject.org/news/2023-briar-mailbox-released/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T20:30:50+00:00

<p>Article URL: <a href="https://briarproject.org/news/2023-briar-mailbox-released/">https://briarproject.org/news/2023-briar-mailbox-released/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36541798">https://news.ycombinator.com/item?id=36541798</a></p>
<p>Points: 11</p>
<p># Comments: 1</p>

## Racket Frustrates Me
 - [https://blog.winny.tech/posts/racket-frustrates-me/](https://blog.winny.tech/posts/racket-frustrates-me/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T20:27:54+00:00

<p>Article URL: <a href="https://blog.winny.tech/posts/racket-frustrates-me/">https://blog.winny.tech/posts/racket-frustrates-me/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36541758">https://news.ycombinator.com/item?id=36541758</a></p>
<p>Points: 71</p>
<p># Comments: 50</p>

## Dolphins use “baby talk” too
 - [https://www.pnas.org/doi/abs/10.1073/pnas.2300262120](https://www.pnas.org/doi/abs/10.1073/pnas.2300262120)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T19:39:09+00:00

<p>Article URL: <a href="https://www.pnas.org/doi/abs/10.1073/pnas.2300262120">https://www.pnas.org/doi/abs/10.1073/pnas.2300262120</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36540991">https://news.ycombinator.com/item?id=36540991</a></p>
<p>Points: 37</p>
<p># Comments: 14</p>

## Twitter now requires an account to view tweets
 - [https://techcrunch.com/2023/06/30/twitter-now-requires-an-account-to-view-tweets/](https://techcrunch.com/2023/06/30/twitter-now-requires-an-account-to-view-tweets/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T19:36:33+00:00

<p>Article URL: <a href="https://techcrunch.com/2023/06/30/twitter-now-requires-an-account-to-view-tweets/">https://techcrunch.com/2023/06/30/twitter-now-requires-an-account-to-view-tweets/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36540957">https://news.ycombinator.com/item?id=36540957</a></p>
<p>Points: 139</p>
<p># Comments: 52</p>

## US Supreme Court rules website designer can refuse to serve same-sex couples
 - [https://www.bbc.com/news/world-us-canada-66070534](https://www.bbc.com/news/world-us-canada-66070534)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T19:29:08+00:00

<p>Article URL: <a href="https://www.bbc.com/news/world-us-canada-66070534">https://www.bbc.com/news/world-us-canada-66070534</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36540849">https://news.ycombinator.com/item?id=36540849</a></p>
<p>Points: 25</p>
<p># Comments: 10</p>

## Why is there a drink called 手打柠檬鸭屎香 = “hand-made lemon duck-feces fragrance”?
 - [https://chinese.stackexchange.com/questions/54741/why-is-there-a-drink-called-%e6%89%8b%e6%89%93%e6%9f%a0%e6%aa%ac%e9%b8%ad%e5%b1%8e%e9%a6%99-hand-made-lemon-duck-feces-fragrance](https://chinese.stackexchange.com/questions/54741/why-is-there-a-drink-called-%e6%89%8b%e6%89%93%e6%9f%a0%e6%aa%ac%e9%b8%ad%e5%b1%8e%e9%a6%99-hand-made-lemon-duck-feces-fragrance)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T19:25:02+00:00

<p>Article URL: <a href="https://chinese.stackexchange.com/questions/54741/why-is-there-a-drink-called-%e6%89%8b%e6%89%93%e6%9f%a0%e6%aa%ac%e9%b8%ad%e5%b1%8e%e9%a6%99-hand-made-lemon-duck-feces-fragrance">https://chinese.stackexchange.com/questions/54741/why-is-there-a-drink-called-%e6%89%8b%e6%89%93%e6%9f%a0%e6%aa%ac%e9%b8%ad%e5%b1%8e%e9%a6%99-hand-made-lemon-duck-feces-fragrance</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36540787">https://news.ycombinator.com/item?id=36540787</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## All Pocket accounts will be converted to Firefox accounts
 - [https://blog.mozilla.org/en/products/pocket/signing-in-to-pocket-just-got-even-more-secure/](https://blog.mozilla.org/en/products/pocket/signing-in-to-pocket-just-got-even-more-secure/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T18:58:10+00:00

<p>Article URL: <a href="https://blog.mozilla.org/en/products/pocket/signing-in-to-pocket-just-got-even-more-secure/">https://blog.mozilla.org/en/products/pocket/signing-in-to-pocket-just-got-even-more-secure/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36540355">https://news.ycombinator.com/item?id=36540355</a></p>
<p>Points: 28</p>
<p># Comments: 17</p>

## The One Ring card, Magic: The Gathering’s coveted collectible, has been found
 - [https://www.polygon.com/23779892/mtg-the-one-ring-found-how-much-price-spain](https://www.polygon.com/23779892/mtg-the-one-ring-found-how-much-price-spain)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T18:48:21+00:00

<p>Article URL: <a href="https://www.polygon.com/23779892/mtg-the-one-ring-found-how-much-price-spain">https://www.polygon.com/23779892/mtg-the-one-ring-found-how-much-price-spain</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36540208">https://news.ycombinator.com/item?id=36540208</a></p>
<p>Points: 16</p>
<p># Comments: 8</p>

## DMT, Derealization, and Depersonalization
 - [https://www.ecstaticintegration.org/p/dmt-derealization-and-depersonalization](https://www.ecstaticintegration.org/p/dmt-derealization-and-depersonalization)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T18:14:40+00:00

<p>Article URL: <a href="https://www.ecstaticintegration.org/p/dmt-derealization-and-depersonalization">https://www.ecstaticintegration.org/p/dmt-derealization-and-depersonalization</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36539634">https://news.ycombinator.com/item?id=36539634</a></p>
<p>Points: 34</p>
<p># Comments: 30</p>

## Supreme Court Opinion on Student Loan Forgiveness [pdf]
 - [https://www.supremecourt.gov/opinions/22pdf/22-506_nmip.pdf](https://www.supremecourt.gov/opinions/22pdf/22-506_nmip.pdf)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T18:08:54+00:00

<p>Article URL: <a href="https://www.supremecourt.gov/opinions/22pdf/22-506_nmip.pdf">https://www.supremecourt.gov/opinions/22pdf/22-506_nmip.pdf</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36539551">https://news.ycombinator.com/item?id=36539551</a></p>
<p>Points: 26</p>
<p># Comments: 22</p>

## Invidious Instance Yewtu.be Censored
 - [https://yewtu.be/](https://yewtu.be/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T17:53:25+00:00

<p>Article URL: <a href="https://yewtu.be/">https://yewtu.be/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36539306">https://news.ycombinator.com/item?id=36539306</a></p>
<p>Points: 5</p>
<p># Comments: 1</p>

## Static electricity attracts ticks to hosts
 - [https://www.bristol.ac.uk/news/2023/june/static-electricity-attracts-ticks-to-hosts.html](https://www.bristol.ac.uk/news/2023/june/static-electricity-attracts-ticks-to-hosts.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T17:50:59+00:00

<p>Article URL: <a href="https://www.bristol.ac.uk/news/2023/june/static-electricity-attracts-ticks-to-hosts.html">https://www.bristol.ac.uk/news/2023/june/static-electricity-attracts-ticks-to-hosts.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36539253">https://news.ycombinator.com/item?id=36539253</a></p>
<p>Points: 7</p>
<p># Comments: 1</p>

## Algorithmic Trading with Go
 - [https://polygon.io/blog/case-study-algorithmict-trading-with-go/](https://polygon.io/blog/case-study-algorithmict-trading-with-go/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T17:49:52+00:00

<p>Article URL: <a href="https://polygon.io/blog/case-study-algorithmict-trading-with-go/">https://polygon.io/blog/case-study-algorithmict-trading-with-go/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36539235">https://news.ycombinator.com/item?id=36539235</a></p>
<p>Points: 38</p>
<p># Comments: 23</p>

## Crypto for the Homeless (501(C)(3))
 - [https://cryptoforthehomeless.com/](https://cryptoforthehomeless.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T17:45:20+00:00

<p>Article URL: <a href="https://cryptoforthehomeless.com/">https://cryptoforthehomeless.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36539159">https://news.ycombinator.com/item?id=36539159</a></p>
<p>Points: 16</p>
<p># Comments: 4</p>

## Hurl 4.0.0
 - [https://hurl.dev/blog/2023/06/30/announcing-hurl-4.0.0.html](https://hurl.dev/blog/2023/06/30/announcing-hurl-4.0.0.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T17:44:15+00:00

<p>Article URL: <a href="https://hurl.dev/blog/2023/06/30/announcing-hurl-4.0.0.html">https://hurl.dev/blog/2023/06/30/announcing-hurl-4.0.0.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36539144">https://news.ycombinator.com/item?id=36539144</a></p>
<p>Points: 23</p>
<p># Comments: 2</p>

## Linux's Slab Allocator Is Officially Deprecated
 - [https://www.phoronix.com/news/SLAB-Officially-Deprecated](https://www.phoronix.com/news/SLAB-Officially-Deprecated)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T17:24:34+00:00

<p>Article URL: <a href="https://www.phoronix.com/news/SLAB-Officially-Deprecated">https://www.phoronix.com/news/SLAB-Officially-Deprecated</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36538795">https://news.ycombinator.com/item?id=36538795</a></p>
<p>Points: 35</p>
<p># Comments: 3</p>

## A look inside the SNES, PS5, and Xbox controllers with CT scans
 - [https://www.scanofthemonth.com/scans/gamepads](https://www.scanofthemonth.com/scans/gamepads)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T17:10:31+00:00

<p>Article URL: <a href="https://www.scanofthemonth.com/scans/gamepads">https://www.scanofthemonth.com/scans/gamepads</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36538579">https://news.ycombinator.com/item?id=36538579</a></p>
<p>Points: 72</p>
<p># Comments: 25</p>

## The Rise of the AI Engineer
 - [https://www.latent.space/p/ai-engineer](https://www.latent.space/p/ai-engineer)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T17:01:04+00:00

<p>Article URL: <a href="https://www.latent.space/p/ai-engineer">https://www.latent.space/p/ai-engineer</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36538423">https://news.ycombinator.com/item?id=36538423</a></p>
<p>Points: 39</p>
<p># Comments: 8</p>

## Ask HN: LLVM vs. C?
 - [https://news.ycombinator.com/item?id=36538344](https://news.ycombinator.com/item?id=36538344)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T16:56:46+00:00

<p>What does LLVM have that can not be achieved 1 to 1 in C? And what does C have that can not be reproduced 1 to 1 in LLVM?<p>And when I say C I mean tcc, sdcc, gcc, clang and other C compilers.<p>It feels to me like C should be superior to LLVM and allow to do anything that is possible to do with LLVM, but maybe I'm wrong? (asking about it due to all that "fuzz-buzz" about zig going for C as its main target)<p>Would appreciate real down to the ground answers, not a sense of how things work or generalizations - as that will introduce unnecessary noise in judgement of comparison.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36538344">https://news.ycombinator.com/item?id=36538344</a></p>
<p>Points: 26</p>
<p># Comments: 24</p>

## Lawsuit claims OpenAI stole 'massive amounts of personal data'
 - [https://www.businessinsider.com/openai-chatgpt-generative-ai-stole-personal-data-lawsuit-children-medical-2023-6](https://www.businessinsider.com/openai-chatgpt-generative-ai-stole-personal-data-lawsuit-children-medical-2023-6)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T16:12:55+00:00

<p>Article URL: <a href="https://www.businessinsider.com/openai-chatgpt-generative-ai-stole-personal-data-lawsuit-children-medical-2023-6">https://www.businessinsider.com/openai-chatgpt-generative-ai-stole-personal-data-lawsuit-children-medical-2023-6</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36537598">https://news.ycombinator.com/item?id=36537598</a></p>
<p>Points: 18</p>
<p># Comments: 12</p>

## CommonJS Is Hurting JavaScript
 - [https://deno.com/blog/commonjs-is-hurting-javascript](https://deno.com/blog/commonjs-is-hurting-javascript)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T16:09:29+00:00

<p>Article URL: <a href="https://deno.com/blog/commonjs-is-hurting-javascript">https://deno.com/blog/commonjs-is-hurting-javascript</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36537533">https://news.ycombinator.com/item?id=36537533</a></p>
<p>Points: 51</p>
<p># Comments: 24</p>

## AMD AI Software Solved – MI300X Pricing, Perf, PyTorch, FlashAttention, Triton
 - [https://www.semianalysis.com/p/amd-ai-software-solved-mi300x-pricing](https://www.semianalysis.com/p/amd-ai-software-solved-mi300x-pricing)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T15:54:49+00:00

<p>Article URL: <a href="https://www.semianalysis.com/p/amd-ai-software-solved-mi300x-pricing">https://www.semianalysis.com/p/amd-ai-software-solved-mi300x-pricing</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36537250">https://news.ycombinator.com/item?id=36537250</a></p>
<p>Points: 11</p>
<p># Comments: 1</p>

## Niantic lays off 230 employees, cancels NBA and Marvel games
 - [https://techcrunch.com/2023/06/29/niantic-lays-off-230-employees-cancels-nba-and-marvel-games/](https://techcrunch.com/2023/06/29/niantic-lays-off-230-employees-cancels-nba-and-marvel-games/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T15:34:26+00:00

<p>Article URL: <a href="https://techcrunch.com/2023/06/29/niantic-lays-off-230-employees-cancels-nba-and-marvel-games/">https://techcrunch.com/2023/06/29/niantic-lays-off-230-employees-cancels-nba-and-marvel-games/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36536859">https://news.ycombinator.com/item?id=36536859</a></p>
<p>Points: 85</p>
<p># Comments: 75</p>

## AlmaLinux – Our Value Is Our Values
 - [https://almalinux.org/blog/our-value-is-our-values/](https://almalinux.org/blog/our-value-is-our-values/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T14:51:13+00:00

<p>Article URL: <a href="https://almalinux.org/blog/our-value-is-our-values/">https://almalinux.org/blog/our-value-is-our-values/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36535901">https://news.ycombinator.com/item?id=36535901</a></p>
<p>Points: 32</p>
<p># Comments: 4</p>

## Show HN: Halloy – A GUI Application in Rust for IRC
 - [https://github.com/squidowl/halloy](https://github.com/squidowl/halloy)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T14:43:50+00:00

<p>Article URL: <a href="https://github.com/squidowl/halloy">https://github.com/squidowl/halloy</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36535772">https://news.ycombinator.com/item?id=36535772</a></p>
<p>Points: 32</p>
<p># Comments: 10</p>

## Site claims to sell upvotes on Hacker News
 - [https://goorapid.com/product/buy-hacker-news-upvotes/](https://goorapid.com/product/buy-hacker-news-upvotes/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T13:56:35+00:00

<p>Article URL: <a href="https://goorapid.com/product/buy-hacker-news-upvotes/">https://goorapid.com/product/buy-hacker-news-upvotes/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36534979">https://news.ycombinator.com/item?id=36534979</a></p>
<p>Points: 83</p>
<p># Comments: 73</p>

## McMansion Hell
 - [https://mcmansionhell.com](https://mcmansionhell.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T13:41:17+00:00

<p>Article URL: <a href="https://mcmansionhell.com">https://mcmansionhell.com</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36534725">https://news.ycombinator.com/item?id=36534725</a></p>
<p>Points: 49</p>
<p># Comments: 14</p>

## How does Linux handle writes?
 - [https://www.cyberdemon.org/2023/06/27/file-writes.html](https://www.cyberdemon.org/2023/06/27/file-writes.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T13:28:59+00:00

<p>Article URL: <a href="https://www.cyberdemon.org/2023/06/27/file-writes.html">https://www.cyberdemon.org/2023/06/27/file-writes.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36534512">https://news.ycombinator.com/item?id=36534512</a></p>
<p>Points: 14</p>
<p># Comments: 0</p>

## Nineteen new Wolf-Rayet stars discovered in the Andromeda galaxy
 - [https://phys.org/news/2023-06-nineteen-wolf-rayet-stars-andromeda-galaxy.html](https://phys.org/news/2023-06-nineteen-wolf-rayet-stars-andromeda-galaxy.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T13:09:04+00:00

<p>Article URL: <a href="https://phys.org/news/2023-06-nineteen-wolf-rayet-stars-andromeda-galaxy.html">https://phys.org/news/2023-06-nineteen-wolf-rayet-stars-andromeda-galaxy.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36534179">https://news.ycombinator.com/item?id=36534179</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## May inflation (PCE) falls to 1.2% (3.6% Core) / 3.8% YoY (4.6% Core YoY)
 - [https://www.bea.gov/news/2023/personal-income-and-outlays-may-2023](https://www.bea.gov/news/2023/personal-income-and-outlays-may-2023)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T12:53:47+00:00

<p>Article URL: <a href="https://www.bea.gov/news/2023/personal-income-and-outlays-may-2023">https://www.bea.gov/news/2023/personal-income-and-outlays-may-2023</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36533978">https://news.ycombinator.com/item?id=36533978</a></p>
<p>Points: 25</p>
<p># Comments: 18</p>

## Gen Z are turning to delusional thinking to cope
 - [https://fortune.com/2023/06/27/gen-zers-turning-to-radical-rest-delusional-thinking-self-indulgence-late-stage-capitalism-molly-barth/](https://fortune.com/2023/06/27/gen-zers-turning-to-radical-rest-delusional-thinking-self-indulgence-late-stage-capitalism-molly-barth/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T12:49:02+00:00

<p>Article URL: <a href="https://fortune.com/2023/06/27/gen-zers-turning-to-radical-rest-delusional-thinking-self-indulgence-late-stage-capitalism-molly-barth/">https://fortune.com/2023/06/27/gen-zers-turning-to-radical-rest-delusional-thinking-self-indulgence-late-stage-capitalism-molly-barth/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36533916">https://news.ycombinator.com/item?id=36533916</a></p>
<p>Points: 17</p>
<p># Comments: 15</p>

## TSMC Faces $70M Ransom Demand Following LockBit Cyberattack
 - [https://www.thefinalhop.com/tsmc-faces-70m-ransom-demand-following-lockbit-cyberattack-could-this-impact-gpu-prices-80e1d9f90ef3?gi=367614525a9f](https://www.thefinalhop.com/tsmc-faces-70m-ransom-demand-following-lockbit-cyberattack-could-this-impact-gpu-prices-80e1d9f90ef3?gi=367614525a9f)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T12:29:59+00:00

<p>Article URL: <a href="https://www.thefinalhop.com/tsmc-faces-70m-ransom-demand-following-lockbit-cyberattack-could-this-impact-gpu-prices-80e1d9f90ef3?gi=367614525a9f">https://www.thefinalhop.com/tsmc-faces-70m-ransom-demand-following-lockbit-cyberattack-could-this-impact-gpu-prices-80e1d9f90ef3?gi=367614525a9f</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36533712">https://news.ycombinator.com/item?id=36533712</a></p>
<p>Points: 14</p>
<p># Comments: 9</p>

## Rocky Linux Shares How They May Continue to Obtain the RHEL Source Code
 - [https://www.phoronix.com/news/Rocky-Linux-RHEL-Source-Access](https://www.phoronix.com/news/Rocky-Linux-RHEL-Source-Access)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T12:21:57+00:00

<p>Article URL: <a href="https://www.phoronix.com/news/Rocky-Linux-RHEL-Source-Access">https://www.phoronix.com/news/Rocky-Linux-RHEL-Source-Access</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36533604">https://news.ycombinator.com/item?id=36533604</a></p>
<p>Points: 42</p>
<p># Comments: 16</p>

## Show HN: Gamebody, a full-body game controller
 - [https://github.com/everythingishacked/Gamebody](https://github.com/everythingishacked/Gamebody)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T12:11:08+00:00

<p>Article URL: <a href="https://github.com/everythingishacked/Gamebody">https://github.com/everythingishacked/Gamebody</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36533465">https://news.ycombinator.com/item?id=36533465</a></p>
<p>Points: 17</p>
<p># Comments: 4</p>

## The Darwinian argument for worrying about AI
 - [https://time.com/6283958/darwinian-argument-for-worrying-about-ai/](https://time.com/6283958/darwinian-argument-for-worrying-about-ai/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T12:04:18+00:00

<p>Article URL: <a href="https://time.com/6283958/darwinian-argument-for-worrying-about-ai/">https://time.com/6283958/darwinian-argument-for-worrying-about-ai/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36533396">https://news.ycombinator.com/item?id=36533396</a></p>
<p>Points: 11</p>
<p># Comments: 19</p>

## Roboflow (YC S20) Is Hiring Engineers to Democratize Computer Vision
 - [https://roboflow.com/careers?ref=hn723](https://roboflow.com/careers?ref=hn723)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T12:01:03+00:00

<p>Article URL: <a href="https://roboflow.com/careers?ref=hn723">https://roboflow.com/careers?ref=hn723</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36533355">https://news.ycombinator.com/item?id=36533355</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

## Terrible real estate agent photographs
 - [https://terriblerealestateagentphotos.com](https://terriblerealestateagentphotos.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T11:44:31+00:00

<p>Article URL: <a href="https://terriblerealestateagentphotos.com">https://terriblerealestateagentphotos.com</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36533193">https://news.ycombinator.com/item?id=36533193</a></p>
<p>Points: 21</p>
<p># Comments: 3</p>

## Goodreads Has No Incentive to Be Good
 - [https://countercraft.substack.com/p/goodreads-has-no-incentive-to-be](https://countercraft.substack.com/p/goodreads-has-no-incentive-to-be)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T11:39:38+00:00

<p>Article URL: <a href="https://countercraft.substack.com/p/goodreads-has-no-incentive-to-be">https://countercraft.substack.com/p/goodreads-has-no-incentive-to-be</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36533153">https://news.ycombinator.com/item?id=36533153</a></p>
<p>Points: 75</p>
<p># Comments: 47</p>

## Fidelity deepens valuation cut for Reddit and Discord
 - [https://techcrunch.com/2023/06/30/fidelity-deepens-valuation-cut-for-reddit-and-discord/](https://techcrunch.com/2023/06/30/fidelity-deepens-valuation-cut-for-reddit-and-discord/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T11:34:21+00:00

<p>Article URL: <a href="https://techcrunch.com/2023/06/30/fidelity-deepens-valuation-cut-for-reddit-and-discord/">https://techcrunch.com/2023/06/30/fidelity-deepens-valuation-cut-for-reddit-and-discord/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36533108">https://news.ycombinator.com/item?id=36533108</a></p>
<p>Points: 40</p>
<p># Comments: 13</p>

## Fastmail Is Down
 - [https://fastmailstatus.com/](https://fastmailstatus.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T11:26:22+00:00

<p>Article URL: <a href="https://fastmailstatus.com/">https://fastmailstatus.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36533048">https://news.ycombinator.com/item?id=36533048</a></p>
<p>Points: 10</p>
<p># Comments: 0</p>

## The downfall of National Geographic
 - [https://jjpryor.substack.com/p/the-tragic-downfall-of-national-geographic](https://jjpryor.substack.com/p/the-tragic-downfall-of-national-geographic)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T11:20:55+00:00

<p>Article URL: <a href="https://jjpryor.substack.com/p/the-tragic-downfall-of-national-geographic">https://jjpryor.substack.com/p/the-tragic-downfall-of-national-geographic</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36532990">https://news.ycombinator.com/item?id=36532990</a></p>
<p>Points: 37</p>
<p># Comments: 21</p>

## Dynamic bit shuffle using AVX-512
 - [https://lemire.me/blog/2023/06/29/dynamic-bit-shuffle-using-avx-512/](https://lemire.me/blog/2023/06/29/dynamic-bit-shuffle-using-avx-512/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T11:14:39+00:00

<p>Article URL: <a href="https://lemire.me/blog/2023/06/29/dynamic-bit-shuffle-using-avx-512/">https://lemire.me/blog/2023/06/29/dynamic-bit-shuffle-using-avx-512/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36532949">https://news.ycombinator.com/item?id=36532949</a></p>
<p>Points: 19</p>
<p># Comments: 2</p>

## Microwaved plastic containers release microplastics into food
 - [https://pubs.acs.org/doi/10.1021/acs.est.3c01942](https://pubs.acs.org/doi/10.1021/acs.est.3c01942)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T10:56:50+00:00

<p>Article URL: <a href="https://pubs.acs.org/doi/10.1021/acs.est.3c01942">https://pubs.acs.org/doi/10.1021/acs.est.3c01942</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36532812">https://news.ycombinator.com/item?id=36532812</a></p>
<p>Points: 112</p>
<p># Comments: 75</p>

## UK competition regulator finds Adobe’s purchase of Figma could reduce innovation
 - [https://www.gov.uk/government/news/design-software-deal-could-harm-uk-digital-economy](https://www.gov.uk/government/news/design-software-deal-could-harm-uk-digital-economy)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T10:56:37+00:00

<p>Article URL: <a href="https://www.gov.uk/government/news/design-software-deal-could-harm-uk-digital-economy">https://www.gov.uk/government/news/design-software-deal-could-harm-uk-digital-economy</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36532811">https://news.ycombinator.com/item?id=36532811</a></p>
<p>Points: 19</p>
<p># Comments: 1</p>

## The dangers of conditional consistency guarantees
 - [http://dbmsmusings.blogspot.com/2019/07/the-dangers-of-conditional-consistency.html](http://dbmsmusings.blogspot.com/2019/07/the-dangers-of-conditional-consistency.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T10:18:44+00:00

<p>Article URL: <a href="http://dbmsmusings.blogspot.com/2019/07/the-dangers-of-conditional-consistency.html">http://dbmsmusings.blogspot.com/2019/07/the-dangers-of-conditional-consistency.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36532601">https://news.ycombinator.com/item?id=36532601</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## French Gov Wants to Inject Domain Blocking Lists Directly into Web Browsers
 - [https://torrentfreak.com/french-govt-wants-to-inject-domain-blocking-lists-directly-into-web-browsers-230630/](https://torrentfreak.com/french-govt-wants-to-inject-domain-blocking-lists-directly-into-web-browsers-230630/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T09:33:35+00:00

<p>Article URL: <a href="https://torrentfreak.com/french-govt-wants-to-inject-domain-blocking-lists-directly-into-web-browsers-230630/">https://torrentfreak.com/french-govt-wants-to-inject-domain-blocking-lists-directly-into-web-browsers-230630/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36532385">https://news.ycombinator.com/item?id=36532385</a></p>
<p>Points: 36</p>
<p># Comments: 5</p>

## Cheapest Source of x86 Cores?
 - [https://news.ycombinator.com/item?id=36532238](https://news.ycombinator.com/item?id=36532238)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T09:05:48+00:00

<p>I'm doing embarrassingly parallel simulations (think Monte Carlo runs of a legacy scientific binary) and am trying to find the cheapest possible host source of x86 compute, at scale. These are jobs that are single-threaded, use maybe 2-4GB of ram, last an hour, and can be checkpointed if necessary. A c5.18xlarge on AWS has 36 physical (real) cores and on the spot market is $0.74/hr which works out to $0.02/core-hour. Does anyone know of cheaper options?</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36532238">https://news.ycombinator.com/item?id=36532238</a></p>
<p>Points: 16</p>
<p># Comments: 22</p>

## The Atom Feed Format Was Born 20 Years Ago
 - [https://www.rssboard.org/news/213/atom-feed-format-born-20-years-ago](https://www.rssboard.org/news/213/atom-feed-format-born-20-years-ago)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T08:44:41+00:00

<p>Article URL: <a href="https://www.rssboard.org/news/213/atom-feed-format-born-20-years-ago">https://www.rssboard.org/news/213/atom-feed-format-born-20-years-ago</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36532136">https://news.ycombinator.com/item?id=36532136</a></p>
<p>Points: 19</p>
<p># Comments: 3</p>

## BGP.Tools: Browse the Internet Ecosystem
 - [https://bgp.tools/](https://bgp.tools/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T08:18:36+00:00

<p>Article URL: <a href="https://bgp.tools/">https://bgp.tools/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36531988">https://news.ycombinator.com/item?id=36531988</a></p>
<p>Points: 7</p>
<p># Comments: 1</p>

## How the Great Firewall of China Detects and Blocks Fully Encrypted Traffic [pdf]
 - [https://gfw.report/publications/usenixsecurity23/data/paper/paper.pdf](https://gfw.report/publications/usenixsecurity23/data/paper/paper.pdf)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T07:03:50+00:00

<p>Article URL: <a href="https://gfw.report/publications/usenixsecurity23/data/paper/paper.pdf">https://gfw.report/publications/usenixsecurity23/data/paper/paper.pdf</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36531485">https://news.ycombinator.com/item?id=36531485</a></p>
<p>Points: 35</p>
<p># Comments: 11</p>

## Anna’s Archive: The world’s largest open-source open-data library
 - [https://annas-archive.org/](https://annas-archive.org/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T04:55:38+00:00

<p>Article URL: <a href="https://annas-archive.org/">https://annas-archive.org/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36530662">https://news.ycombinator.com/item?id=36530662</a></p>
<p>Points: 59</p>
<p># Comments: 1</p>

## NJ Supreme Court says cops need a wiretap to eavesdrop on your Facebook posts
 - [https://newjerseymonitor.com/2023/06/29/n-j-supreme-court-says-cops-need-a-wiretap-to-eavesdrop-on-your-facebook-posts/](https://newjerseymonitor.com/2023/06/29/n-j-supreme-court-says-cops-need-a-wiretap-to-eavesdrop-on-your-facebook-posts/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T04:51:00+00:00

<p>Article URL: <a href="https://newjerseymonitor.com/2023/06/29/n-j-supreme-court-says-cops-need-a-wiretap-to-eavesdrop-on-your-facebook-posts/">https://newjerseymonitor.com/2023/06/29/n-j-supreme-court-says-cops-need-a-wiretap-to-eavesdrop-on-your-facebook-posts/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36530631">https://news.ycombinator.com/item?id=36530631</a></p>
<p>Points: 47</p>
<p># Comments: 8</p>

## Buying an iPad Pro for coding was a mistake
 - [https://technicallychallenged.substack.com/p/buying-an-ipad-pro-for-coding-was](https://technicallychallenged.substack.com/p/buying-an-ipad-pro-for-coding-was)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T04:46:01+00:00

<p>Article URL: <a href="https://technicallychallenged.substack.com/p/buying-an-ipad-pro-for-coding-was">https://technicallychallenged.substack.com/p/buying-an-ipad-pro-for-coding-was</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36530607">https://news.ycombinator.com/item?id=36530607</a></p>
<p>Points: 56</p>
<p># Comments: 73</p>

## The Man Who Broke Bowling
 - [https://www.gq.com/story/jason-belmonte-bowling-profile](https://www.gq.com/story/jason-belmonte-bowling-profile)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T04:22:36+00:00

<p>Article URL: <a href="https://www.gq.com/story/jason-belmonte-bowling-profile">https://www.gq.com/story/jason-belmonte-bowling-profile</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36530472">https://news.ycombinator.com/item?id=36530472</a></p>
<p>Points: 14</p>
<p># Comments: 3</p>

## The complete guide to publishing free software video games
 - [https://writefreesoftware.org/blog/free-software-games/](https://writefreesoftware.org/blog/free-software-games/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T04:02:54+00:00

<p>Article URL: <a href="https://writefreesoftware.org/blog/free-software-games/">https://writefreesoftware.org/blog/free-software-games/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36530379">https://news.ycombinator.com/item?id=36530379</a></p>
<p>Points: 21</p>
<p># Comments: 6</p>

## Ross Ulbricht Threatens LowEndBox. It's Weird
 - [https://lowendbox.com/blog/ross-ulbricht-threatens-lowendbox-its-weird/](https://lowendbox.com/blog/ross-ulbricht-threatens-lowendbox-its-weird/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T03:58:01+00:00

<p>Article URL: <a href="https://lowendbox.com/blog/ross-ulbricht-threatens-lowendbox-its-weird/">https://lowendbox.com/blog/ross-ulbricht-threatens-lowendbox-its-weird/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36530357">https://news.ycombinator.com/item?id=36530357</a></p>
<p>Points: 22</p>
<p># Comments: 3</p>

## RF Spectrum Mapping
 - [https://www.he360.com/products/rfgeo-radio-frequency-signal-mapping/](https://www.he360.com/products/rfgeo-radio-frequency-signal-mapping/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T03:16:05+00:00

<p>Article URL: <a href="https://www.he360.com/products/rfgeo-radio-frequency-signal-mapping/">https://www.he360.com/products/rfgeo-radio-frequency-signal-mapping/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36530110">https://news.ycombinator.com/item?id=36530110</a></p>
<p>Points: 8</p>
<p># Comments: 2</p>

## Crossword Builder
 - [https://dawnofthe.dad/crossword](https://dawnofthe.dad/crossword)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T03:12:40+00:00

<p>Article URL: <a href="https://dawnofthe.dad/crossword">https://dawnofthe.dad/crossword</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36530096">https://news.ycombinator.com/item?id=36530096</a></p>
<p>Points: 4</p>
<p># Comments: 1</p>

## Ask HN: Stock Android phone free of bloatware?
 - [https://news.ycombinator.com/item?id=36530036](https://news.ycombinator.com/item?id=36530036)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T03:02:53+00:00

<p>Is there an Android phone available that comes without any pre-installed bloatware, offers long-term support, and ensures access to the latest Android versions?</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36530036">https://news.ycombinator.com/item?id=36530036</a></p>
<p>Points: 50</p>
<p># Comments: 67</p>

## Flea market find is medieval hand cannon
 - [http://www.thehistoryblog.com/archives/67580](http://www.thehistoryblog.com/archives/67580)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T02:54:49+00:00

<p>Article URL: <a href="http://www.thehistoryblog.com/archives/67580">http://www.thehistoryblog.com/archives/67580</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36529973">https://news.ycombinator.com/item?id=36529973</a></p>
<p>Points: 12</p>
<p># Comments: 6</p>

## LLM Tech and a Lot More: Version 13.3 of Wolfram Language and Mathematica
 - [https://writings.stephenwolfram.com/2023/06/llm-tech-and-a-lot-more-version-13-3-of-wolfram-language-and-mathematica/#llm-tech-comes-to-wolfram-language](https://writings.stephenwolfram.com/2023/06/llm-tech-and-a-lot-more-version-13-3-of-wolfram-language-and-mathematica/#llm-tech-comes-to-wolfram-language)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T01:57:54+00:00

<p>Article URL: <a href="https://writings.stephenwolfram.com/2023/06/llm-tech-and-a-lot-more-version-13-3-of-wolfram-language-and-mathematica/#llm-tech-comes-to-wolfram-language">https://writings.stephenwolfram.com/2023/06/llm-tech-and-a-lot-more-version-13-3-of-wolfram-language-and-mathematica/#llm-tech-comes-to-wolfram-language</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36529610">https://news.ycombinator.com/item?id=36529610</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## LLM tech comes to Wolfram Language
 - [https://writings.stephenwolfram.com/2023/06/llm-tech-and-a-lot-more-version-13-3-of-wolfram-language-and-mathematica/](https://writings.stephenwolfram.com/2023/06/llm-tech-and-a-lot-more-version-13-3-of-wolfram-language-and-mathematica/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T01:57:54+00:00

<p>Article URL: <a href="https://writings.stephenwolfram.com/2023/06/llm-tech-and-a-lot-more-version-13-3-of-wolfram-language-and-mathematica/">https://writings.stephenwolfram.com/2023/06/llm-tech-and-a-lot-more-version-13-3-of-wolfram-language-and-mathematica/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36529610">https://news.ycombinator.com/item?id=36529610</a></p>
<p>Points: 48</p>
<p># Comments: 7</p>

## File for Divorce from LLVM
 - [https://github.com/ziglang/zig/issues/16270](https://github.com/ziglang/zig/issues/16270)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T01:34:58+00:00

<p>Article URL: <a href="https://github.com/ziglang/zig/issues/16270">https://github.com/ziglang/zig/issues/16270</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36529456">https://news.ycombinator.com/item?id=36529456</a></p>
<p>Points: 18</p>
<p># Comments: 1</p>

## MdBook – Create book from Markdown files. Like Gitbook but implemented in Rust
 - [https://rust-lang.github.io/mdBook/](https://rust-lang.github.io/mdBook/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T00:45:20+00:00

<p>Article URL: <a href="https://rust-lang.github.io/mdBook/">https://rust-lang.github.io/mdBook/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36528984">https://news.ycombinator.com/item?id=36528984</a></p>
<p>Points: 81</p>
<p># Comments: 11</p>

## Disbarment Is Rare in Cases of Attorney-Client Sexual Contact
 - [https://www.law360.com/articles/1693111/disbarment-is-rare-in-cases-of-atty-client-sexual-contact](https://www.law360.com/articles/1693111/disbarment-is-rare-in-cases-of-atty-client-sexual-contact)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T00:08:26+00:00

<p>Article URL: <a href="https://www.law360.com/articles/1693111/disbarment-is-rare-in-cases-of-atty-client-sexual-contact">https://www.law360.com/articles/1693111/disbarment-is-rare-in-cases-of-atty-client-sexual-contact</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36528671">https://news.ycombinator.com/item?id=36528671</a></p>
<p>Points: 16</p>
<p># Comments: 5</p>

## Asus Zenfone 10
 - [https://www.asus.com/mobile-handhelds/phones/zenfone/zenfone-10/](https://www.asus.com/mobile-handhelds/phones/zenfone/zenfone-10/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-30T00:02:07+00:00

<p>Article URL: <a href="https://www.asus.com/mobile-handhelds/phones/zenfone/zenfone-10/">https://www.asus.com/mobile-handhelds/phones/zenfone/zenfone-10/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36528607">https://news.ycombinator.com/item?id=36528607</a></p>
<p>Points: 21</p>
<p># Comments: 17</p>

