# Source:The Telegraph News, URL:https://www.telegraph.co.uk/news/rss.xml, language:en-UK

## Friday evening news briefing: 'Macron's time is up'
 - [https://www.telegraph.co.uk/news/2023/06/30/copy-of-thursday-evening-news-briefing-sunak-to-appeal-to-supreme/](https://www.telegraph.co.uk/news/2023/06/30/copy-of-thursday-evening-news-briefing-sunak-to-appeal-to-supreme/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-06-30T17:58:11+00:00



## Ukraine: The Latest - Belarus implicated in kidnapping of Ukrainian children
 - [https://www.telegraph.co.uk/news/2023/06/30/belarus-implicated-in-kidnapping-of-ukrainian-children/](https://www.telegraph.co.uk/news/2023/06/30/belarus-implicated-in-kidnapping-of-ukrainian-children/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-06-30T16:14:13+00:00



## Bot did you say? AI characters take revenge on cold call scammers
 - [https://www.telegraph.co.uk/news/2023/06/30/ai-characters-revenge-telesales-cold-callers-scammers-phone/](https://www.telegraph.co.uk/news/2023/06/30/ai-characters-revenge-telesales-cold-callers-scammers-phone/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-06-30T15:43:55+00:00



## Kevin Spacey trial live: Oscar-winning actor is a 'sexual bully,' court hears
 - [https://www.telegraph.co.uk/news/2023/06/30/kevin-spacey-trial-live-sexual-assault-old-vic-london/](https://www.telegraph.co.uk/news/2023/06/30/kevin-spacey-trial-live-sexual-assault-old-vic-london/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-06-30T09:56:59+00:00



## Police hunt double murderer after man, 23, and boy, 15, stabbed in Islington
 - [https://www.telegraph.co.uk/news/2023/06/30/police-hunt-killer-man-boy-stabbed-death-islington-london/](https://www.telegraph.co.uk/news/2023/06/30/police-hunt-killer-man-boy-stabbed-death-islington-london/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-06-30T09:48:29+00:00



## BBC weather app forecasts temperatures of 7C in technical glitch
 - [https://www.telegraph.co.uk/news/2023/06/30/bbc-weather-app-forecasts-temperatures-7c-technical-glitch/](https://www.telegraph.co.uk/news/2023/06/30/bbc-weather-app-forecasts-temperatures-7c-technical-glitch/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-06-30T06:36:47+00:00



## Chief superintendent backing campaign to ban trail hunting accused of bias
 - [https://www.telegraph.co.uk/news/2023/06/30/chief-superintendent-support-ban-trail-hunting-accused-bias/](https://www.telegraph.co.uk/news/2023/06/30/chief-superintendent-support-ban-trail-hunting-accused-bias/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-06-30T06:00:00+00:00



## NHS ‘culture of cover-up’ leading to avoidable deaths
 - [https://www.telegraph.co.uk/news/2023/06/30/nhs-avoidable-deaths-cover-up-health-ombudsman/](https://www.telegraph.co.uk/news/2023/06/30/nhs-avoidable-deaths-cover-up-health-ombudsman/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-06-30T06:00:00+00:00



