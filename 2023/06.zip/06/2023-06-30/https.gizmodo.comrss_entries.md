# Source:Gizmodo, URL:https://gizmodo.com/rss, language:en-US

## How Disney Parks Chefs Create Star Wars and Marvel Studios Food
 - [https://gizmodo.com/disney-parks-chefs-star-wars-marvel-studios-themed-food-1850596668](https://gizmodo.com/disney-parks-chefs-star-wars-marvel-studios-themed-food-1850596668)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-30T22:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--YqPUeTQ9--/c_fit,fl_progressive,q_80,w_636/10e04bff1bc0320a65cc111b651a3d87.jpg" /><p>It’s a good time to be <a href="https://gizmodo.com/15-facts-about-tiana-s-bayou-adventure-disney-parks-1850511181">a Disney foodie</a> if you’re <a href="https://gizmodo.com/out-of-this-world-dining-walt-disney-worlds-space-220-1850079839">a <em>Star Wars</em></a> or <a href="https://gizmodo.com/star-wars-guardians-of-the-galaxy-food-disney-parks-1850401858">Marvel Studios fan</a>.</p><p><a href="https://gizmodo.com/disney-parks-chefs-star-wars-marvel-studios-themed-food-1850596668">Read more...</a></p>

## A New Class Action Lawsuit Adds to OpenAI's Growing Legal Troubles
 - [https://gizmodo.com/a-new-class-action-lawsuit-adds-to-openais-growing-lega-1850593431](https://gizmodo.com/a-new-class-action-lawsuit-adds-to-openais-growing-lega-1850593431)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-30T21:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--WnZcxVmq--/c_fit,fl_progressive,q_80,w_636/f4488eef2586c48bdc4a2b2c296b2537.jpg" /><p>A new class action <a href="https://clarksonlawfirm.com/wp-content/uploads/2023/06/0001.-2023.06.28-OpenAI-Complaint.pdf" rel="noopener noreferrer" target="_blank">lawsuit</a> accuses ChatGPT creator OpenAI of criminally scraping data from all over the internet, then using the stolen data to create its popular automated products. The lawsuit, filed this week by the <a href="https://clarksonlawfirm.com/the-ai-arms-race-and-why-we-need-to-come-together-now/" rel="noopener noreferrer" target="_blank">Clarkson Law Firm</a> in a Northern California court, is only the latest in a slew of legal challenges…</p><p><a href="https://gizmodo.com/a-new-class-action-lawsuit-adds-to-openais-growing-lega-1850593431">Read more...</a></p>

## New Nimona Featurette Explains How the Film's Art and Themes Align
 - [https://gizmodo.com/nimona-netflix-animation-featurette-nd-stevenson-1850596056](https://gizmodo.com/nimona-netflix-animation-featurette-nd-stevenson-1850596056)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-30T21:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--6W162Ng0--/c_fit,fl_progressive,q_80,w_636/d2a0835c9d2eec14d57dcfcd832debbc.jpg" /><p><a href="https://gizmodo.com/nimona-animated-netflix-trailer-nd-stevenson-june-30-1850449412"><em>Nimona</em> is now streaming on Netflix</a> and if you’ve seen it, you know <a href="https://gizmodo.com/a-look-inside-nimonas-long-road-to-release-1848777375">the long wait for its arrival</a> <a href="https://gizmodo.com/nimona-netflix-film-nd-stevenson-queer-trans-animation-1850538634">was incredibly worth it</a>. (If you haven’t yet watched, you’re in for a delight.) To celebrate the animated film—adapted from the graphic novel by <a href="https://gizmodo.com/she-ras-noelle-stevenson-tells-us-how-difficult-it-was-1843419358">ND Stevenson</a> <em>(<a href="https://gizmodo.com/rebecca-sugar-and-noelle-stevenson-would-like-to-remind-1844674987">She-Ra and the Princesses of Power</a>)</em>—Netflix shared a featurette…</p><p><a href="https://gizmodo.com/nimona-netflix-animation-featurette-nd-stevenson-1850596056">Read more...</a></p>

## Watch Live: SpaceX to Launch Euclid—Europe's Dark Universe Telescope
 - [https://gizmodo.com/watch-live-spacex-to-launch-euclid-europes-dark-univer-1850596034](https://gizmodo.com/watch-live-spacex-to-launch-euclid-europes-dark-univer-1850596034)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-30T20:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--7ABXtOmP--/c_fit,fl_progressive,q_80,w_636/ca1685cfbf93fc41fd37eb8357ff1e78.jpg" /><p>The European Space Agency (ESA) is gearing up for the launch of its highly anticipated mission to explore the cosmic dark side.</p><p><a href="https://gizmodo.com/watch-live-spacex-to-launch-euclid-europes-dark-univer-1850596034">Read more...</a></p>

## Max's Dune: The Sisterhood Series Builds Its Cast Back Up
 - [https://gizmodo.com/max-dune-sisterhood-series-olivia-williams-jodhi-may-1850597016](https://gizmodo.com/max-dune-sisterhood-series-olivia-williams-jodhi-may-1850597016)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-30T20:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--eNa-gLNE--/c_fit,fl_progressive,q_80,w_636/abb30961f6cdfb802752a88ad3566140.jpg" /><p>With that <a href="https://gizmodo.com/dune-part-2-trailer-breakdown-timothee-chalamet-zendaya-1850591467">exciting new trailer</a> for <a href="https://gizmodo.com/dune-part-2-trailer-timothee-chalamet-zendaya-sandworm-1850591347"><em>Dune: Part II</em></a> arriving this week, there’s no better moment to pile on more good <em>Dune</em> news. This time, it concerns the <a href="https://gizmodo.com/a-dune-the-sisterhood-series-is-coming-from-denis-vill-1835388591">long-in-development</a> <em>Dune</em> streaming series, Max’s <em>Dune: The Sisterhood</em>, which has added new cast members as it moves forward.</p><p><a href="https://gizmodo.com/max-dune-sisterhood-series-olivia-williams-jodhi-may-1850597016">Read more...</a></p>

## NASA Visualization Offers a Disturbing Glimpse of All That Carbon in Our Atmosphere
 - [https://gizmodo.com/nasa-visualization-carbon-atmosphere-1850596834](https://gizmodo.com/nasa-visualization-carbon-atmosphere-1850596834)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-30T20:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--cD-0p04Y--/c_fit,fl_progressive,q_80,w_636/86138cde93b74abfaae455b4fb657ca2.png" /><p>Animations <a href="https://svs.gsfc.nasa.gov/5110" rel="noopener noreferrer" target="_blank">created by NASA</a>’s Scientific Visualization Studio include images and videos showing what carbon emissions would look like if they were visible in our atmosphere. The videos of the swirling emissions were released this month—and it looks like a grosser, creepier version of the Northern Lights.</p><p><a href="https://gizmodo.com/nasa-visualization-carbon-atmosphere-1850596834">Read more...</a></p>

## All the New Sci-Fi, Fantasy, and Horror Books to Put on Your Radar for July
 - [https://gizmodo.com/63-new-sci-fi-fantasy-horror-books-releasing-in-july-1850502141](https://gizmodo.com/63-new-sci-fi-fantasy-horror-books-releasing-in-july-1850502141)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-30T19:45:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--RuRyDSm5--/c_fit,fl_progressive,q_80,w_636/2ba70e488937a9b85b96ed93e54b0e4b.jpg" /><p>July is here, and it’s brought with it an almost overwhelming array of <a href="https://gizmodo.com/42-new-scifi-fantasy-horror-books-june-charles-soule-1850420125">new sci-fi, horror, and fantasy books</a>. Whether you’re in the mood for <a href="https://gizmodo.com/chloe-gong-fantasy-book-excerpt-immortal-longings-1849809292">magic</a>, monsters, or <a href="https://gizmodo.com/with-a-new-developer-framework-building-in-xr-is-easie-1850491958">mysteries</a>—or some combination of all three—io9's monthly list of new releases has you covered.<br /></p><p><a href="https://gizmodo.com/63-new-sci-fi-fantasy-horror-books-releasing-in-july-1850502141">Read more...</a></p>

## Gaze in Wonder at These Stunning Views of the Cosmos
 - [https://gizmodo.com/stunning-views-cosmos-royal-observatory-contest-1850595027](https://gizmodo.com/stunning-views-cosmos-royal-observatory-contest-1850595027)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-30T19:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--2Jol-PNJ--/c_fit,fl_progressive,q_80,w_636/630a15047af33a28136d6e02f8ad9c18.jpg" /><p>The cosmos is a hostile but beautiful place; from Earth, its phenomena—from our Sun and the aurorae it generates to nebulae and distant galaxies—are worth capturing.</p><p><a href="https://gizmodo.com/stunning-views-cosmos-royal-observatory-contest-1850595027">Read more...</a></p>

## Mosquitos Carrying Malaria Found in Florida
 - [https://gizmodo.com/mosquitos-carrying-malaria-found-florida-1850595817](https://gizmodo.com/mosquitos-carrying-malaria-found-florida-1850595817)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-30T19:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--GY_65S02--/c_fit,fl_progressive,q_80,w_636/e4038ed7566dbdda435397140b3cbade.jpg" /><p>A few mosquitos in Florida have tested positive for the the parasite that causes malaria. The finding follows <a href="https://gizmodo.com/malaria-cases-come-back-in-florida-and-texas-1850580502">multiple confirmed human cases</a> of the disease—four in Florida and one in Texas—believed to be the first domestically acquired instances of malaria in the U.S. in 20 years. The newly reported mosquito test…</p><p><a href="https://gizmodo.com/mosquitos-carrying-malaria-found-florida-1850595817">Read more...</a></p>

## The Best Horror, Sci-Fi, and Fantasy Streaming in July 2023
 - [https://gizmodo.com/best-horror-movies-streaming-july-2023-sci-fi-fantasy-1850592184](https://gizmodo.com/best-horror-movies-streaming-july-2023-sci-fi-fantasy-1850592184)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-30T19:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--OAG2bEyx--/c_fit,fl_progressive,q_80,w_636/5ee9915e3a2ef16874b89c01344cf837.jpg" /><p>Let’s get streaming! Welcome to io9's latest edition of the Nerd’s Watch, where we pare down the enormous lists of new films and television shows arriving on all your favorite streaming services into the sci-fi, fantasy, and horror titles we think you’ll like most. (And sometimes, just the ones that we like most.)<br /></p><p><a href="https://gizmodo.com/best-horror-movies-streaming-july-2023-sci-fi-fantasy-1850592184">Read more...</a></p>

## Dolphin Moms Use Baby Talk Around Their Calves, New Research Suggests
 - [https://gizmodo.com/dolphins-use-baby-talk-around-calves-1850596191](https://gizmodo.com/dolphins-use-baby-talk-around-calves-1850596191)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-30T18:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--qU6JEkvR--/c_fit,fl_progressive,q_80,w_636/d870cd02d0af22eccc676c609c639e05.jpg" /><p>It looks like baby talk isn’t just for humans. New research this week suggests that dolphin mothers also adopt a higher-pitched tone during certain forms of communication with their young. </p><p><a href="https://gizmodo.com/dolphins-use-baby-talk-around-calves-1850596191">Read more...</a></p>

## Apple TV+'s Alien Invasion Continues in August
 - [https://gizmodo.com/invasion-season-2-photos-premiere-date-apple-tv-aliens-1850595770](https://gizmodo.com/invasion-season-2-photos-premiere-date-apple-tv-aliens-1850595770)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-30T18:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--YnwW9sNa--/c_fit,fl_progressive,q_80,w_636/daad7085d1488d07e5c3574030df6fe0.jpg" /><p>Apple TV+ viewers are in for a busy summer of sci-fi. In addition to <a href="https://gizmodo.com/silo-premiere-free-twitter-apple-tv-hugh-howey-1850582884"><em>Silo</em></a>, which just wrapped its first season and was renewed for another, <a href="https://gizmodo.com/foundation-s2-trailer-apple-tv-plus-asimov-lee-pace-1850531268"><em>Foundation </em></a><a href="https://gizmodo.com/foundation-s2-trailer-apple-tv-plus-asimov-lee-pace-1850531268">season two</a> arrives July 14—and now we know <a href="https://gizmodo.com/apple-tv-s-alien-invasion-series-looks-suspiciously-inv-1847063039"><em>Invasion</em></a><em> </em>season two (not to be confused with <a href="https://gizmodo.com/secret-invasion-gravik-skrull-kingsley-ben-adir-marvel-1850580930">Marvel’s <em>Secret Invasion</em></a> over on Disney+) will be premiering August 23.</p><p><a href="https://gizmodo.com/invasion-season-2-photos-premiere-date-apple-tv-aliens-1850595770">Read more...</a></p>

## Dylan Mulvaney Speaks Out Against Bud Light for Lack of Support
 - [https://gizmodo.com/dylan-mulvaney-speaks-out-bud-light-lack-support-1850596069](https://gizmodo.com/dylan-mulvaney-speaks-out-bud-light-lack-support-1850596069)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-30T18:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--z_ZO6dSM--/c_fit,fl_progressive,q_80,w_636/ef9a81b801695d483d4abdacf8f94a76.jpg" /><p>Dylan Mulvaney, a trans influencer who was sponsored by Bud Light for two <a href="https://gizmodo.com/instagram-finally-lets-you-post-multiple-in-bio-links-1850348787">Instagram</a> posts, is speaking out after receiving hate mail and threats while reportedly receiving no support from the beer company. The sponsorship garnered a mass anti-trans response and calls for a boycott which has decimated Bud Light’s sales…</p><p><a href="https://gizmodo.com/dylan-mulvaney-speaks-out-bud-light-lack-support-1850596069">Read more...</a></p>

## Tron 3 Continues to Make Its Way Onto the Grid
 - [https://gizmodo.com/tron-3-casting-jodie-turner-smith-greta-lee-jared-leto-1850596192](https://gizmodo.com/tron-3-casting-jodie-turner-smith-greta-lee-jared-leto-1850596192)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-30T17:45:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--MzrxNzPY--/c_fit,fl_progressive,q_80,w_636/a4d3f29e20ab5f66a85dd6f533129f52.jpg" /><p><a href="https://gizmodo.com/evan-peters-joins-jared-leto-in-disneys-tron-3-1850587085">Casting continues</a> for the<a href="https://gizmodo.com/heres-what-tron-3-was-going-to-be-and-may-still-be-ab-1792863604"> long-awaited third <em>Tron</em> film</a> and now, <a href="https://gizmodo.com/tron-3-is-still-totally-in-the-works-says-jared-leto-1848687078">for the first time in a long time</a>, we think this movie might actually be happening. <a href="https://gizmodo.com/tron-3-news-tron-ares-jared-leto-joachim-ronning-disney-1850007148">No, seriously.</a></p><p><a href="https://gizmodo.com/tron-3-casting-jodie-turner-smith-greta-lee-jared-leto-1850596192">Read more...</a></p>

## Reddit's Valuation Has Fallen Even Further, Fidelity Says
 - [https://gizmodo.com/reddits-valuation-has-fallen-even-further-fidelity-1850595638](https://gizmodo.com/reddits-valuation-has-fallen-even-further-fidelity-1850595638)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-30T17:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--KujcJY-t--/c_fit,fl_progressive,q_80,w_636/fcdea74842c6976080fadf7dfd28239c.jpg" /><p>Reddit is facing a crisis both in its user base and its finances. <a href="https://gizmodo.com/reddits-blackout-api-changes-protest-ceo-going-dark-1850528573">After protests and backlashed ravaged the platform in the wake of Reddit opting to charge for access to its API</a>, the company’s valuation has been sliced.<br /></p><p><a href="https://gizmodo.com/reddits-valuation-has-fallen-even-further-fidelity-1850595638">Read more...</a></p>

## Magic: The Gathering's Rarest Lord of the Rings Card Has Been Found
 - [https://gizmodo.com/magic-the-gathering-the-one-ring-card-lord-of-the-rings-1850595558](https://gizmodo.com/magic-the-gathering-the-one-ring-card-lord-of-the-rings-1850595558)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-30T16:45:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--X6ot4VWu--/c_fit,fl_progressive,q_80,w_636/23fb50b30d441c62386c21aad82f9f66.jpg" /><p>Some lucky person just became a millionaire by <a href="https://gizmodo.com/magic-the-gathering-lord-of-the-rings-secret-lair-baksh-1850576938">opening a pack of cards</a>. That’s because it has been revealed that the rarest, most sought-after card in the entire <a href="https://gizmodo.com/magic-the-gathering-lord-of-the-rings-spoilers-1850224269">new <em>Lord of the Rings</em> expansion</a> of <a href="https://gizmodo.com/magic-the-gathering-lord-of-the-rings-all-new-cards-1850485199"><em>Magic: The Gathering</em> has been found.</a></p><p><a href="https://gizmodo.com/magic-the-gathering-the-one-ring-card-lord-of-the-rings-1850595558">Read more...</a></p>

## Seven Now Dead From Fungal Outbreak Tied to Surgery Clinics in Mexico
 - [https://gizmodo.com/seven-dead-fungal-outbreak-tied-mexico-surgery-clinics-1850595819](https://gizmodo.com/seven-dead-fungal-outbreak-tied-mexico-surgery-clinics-1850595819)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-30T16:35:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--YJVakOsb--/c_fit,fl_progressive,q_80,w_636/abb6465aae65867537e7a9e3dd92690c.jpg" /><p>An outbreak of fungal meningitis linked to two surgery clinics in Mexico appears to have claimed more lives. This week, the Centers for Disease and Prevention updated its case tally, reporting seven confirmed or probable deaths linked to the outbreak. Officials are still trying to contact everyone at potential risk…</p><p><a href="https://gizmodo.com/seven-dead-fungal-outbreak-tied-mexico-surgery-clinics-1850595819">Read more...</a></p>

## Lego Celebrates the Fourth of July Early With the Equivalent of America on Wheels: a 1961 Corvette
 - [https://gizmodo.com/lego-celebrates-the-fourth-of-july-early-with-the-equiv-1850595259](https://gizmodo.com/lego-celebrates-the-fourth-of-july-early-with-the-equiv-1850595259)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-30T16:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--T9XNUInm--/c_fit,fl_progressive,q_80,w_636/aed2cd0d16f936527568c2b43ed39e7c.jpg" /><p>Although the Fourth of July isn’t until next Tuesday, most Americans will be lighting up the bbq, setting off fireworks, and heading to the beach this weekend to celebrate early. Lego is getting in on the festivities, too, with the reveal of a new <a href="https://www.lego.com/en-us/product/corvette-10321" rel="noopener noreferrer" target="_blank">bright red 1961 Corvette model</a>: an icon of American automotive design.</p><p><a href="https://gizmodo.com/lego-celebrates-the-fourth-of-july-early-with-the-equiv-1850595259">Read more...</a></p>

## Halloween Comes Early With All the Best Lego Sets You Can Finally Buy in July
 - [https://gizmodo.com/lego-new-july-hocus-pocus-house-disney-castle-pirates-1850575964](https://gizmodo.com/lego-new-july-hocus-pocus-house-disney-castle-pirates-1850575964)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-30T16:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--Ip5GMidi--/c_fit,fl_progressive,q_80,w_636/6a69460519312f3d95e54642d4d2e14d.jpg" /><p>Like the rest of us, <a href="https://gizmodo.com/lego-celebrates-disney100-with-making-wonders-series-1850505341">Lego</a> apparently can’t help but be distracted by thoughts of long weekends, vacations, and trips to the beach. The lineup of new building sets arriving in July is about as lengthy as the amount of work you get done on a July Friday afternoon—there’s just three worth adding to your collection.<br /></p><p><a href="https://gizmodo.com/lego-new-july-hocus-pocus-house-disney-castle-pirates-1850575964">Read more...</a></p>

## To Survive Extreme Heat, Squirrels Go 'Sploot'
 - [https://gizmodo.com/survive-extreme-heat-squirrels-sploot-1850594810](https://gizmodo.com/survive-extreme-heat-squirrels-sploot-1850594810)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-30T15:55:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--LGkCwy9U--/c_fit,fl_progressive,q_80,w_636/64e63f16a075fdcbd4e7c2b453118148.png" /><p>When does a squirrel become a pancake? Answer: Apparently, when the world becomes a griddle. It’s officially sweat season for humans in the U.S., which means it’s sploot season for squirrels. And if you don’t know what that means, keep reading.<br /></p><p><a href="https://gizmodo.com/survive-extreme-heat-squirrels-sploot-1850594810">Read more...</a></p>

## 3 Billion Chrome Users Are About to See This Privacy Sandbox Pop-Up
 - [https://gizmodo.com/3-billion-chrome-users-are-about-to-see-this-privacy-sa-1850595391](https://gizmodo.com/3-billion-chrome-users-are-about-to-see-this-privacy-sa-1850595391)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-30T15:50:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--XS2wKk15--/c_fit,fl_progressive,q_80,w_636/813583810d5b0ccdaf2ae00ebc2de86f.png" /><p>Google Chrome users will see a pop-up in July when they update their browser to version 115 , initiating the first phase of Google’s years-long <a href="https://gizmodo.com/google-android-launches-privacy-sandbox-chrome-cookies-1850112117">Privacy Sandbox</a> project. The prompt, which describes the changes as “Enhanced ad privacy in Chrome,” is the first stage in <a href="https://gizmodo.com/google-chrome-cookie-privacy-sandbox-1850303764">Google’s astonishingly complicated plan</a> to kill…</p><p><a href="https://gizmodo.com/3-billion-chrome-users-are-about-to-see-this-privacy-sa-1850595391">Read more...</a></p>

## Meta Reportedly Wants to Pursue Direct App Downloads Through Facebook Ads in Europe
 - [https://gizmodo.com/meta-reportedly-pursuing-downloading-apps-facebook-ads-1850595383](https://gizmodo.com/meta-reportedly-pursuing-downloading-apps-facebook-ads-1850595383)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-30T15:40:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--MfTBjQos--/c_fit,fl_progressive,q_80,w_636/1e8d6b6024b506350597c6b0d1012801.jpg" /><p>Apple and Google may soon have a new app store competitor to deal with. Meta, the maker of Facebook and Instagram, is reportedly working on a way for users in the European Union to directly download apps through a new type of Facebook ad. If successful, the move could potentially shake up the current <a href="https://gizmodo.com/apple-google-uk-investigation-cma-xbox-cloud-gaming-ios-1849814144">duopoly of app…</a></p><p><a href="https://gizmodo.com/meta-reportedly-pursuing-downloading-apps-facebook-ads-1850595383">Read more...</a></p>

## Google Booed by Employees at Planned Drag Show Event
 - [https://gizmodo.com/google-booed-by-employees-at-planned-drag-show-event-1850595265](https://gizmodo.com/google-booed-by-employees-at-planned-drag-show-event-1850595265)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-30T15:35:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--Qw7rCH2i--/c_fit,fl_progressive,q_80,w_636/c07b058fc33ed6ffc46bac811f8ef2dd.jpg" /><p><a href="https://gizmodo.com/tech/google">Google</a> employees booed the company at its second annual drag show following the company’s decision to reverse its support for the event. Google withdrew its support of the planned drag show after some employees signed a petition saying the event was offensive to their Christian religion.</p><p><a href="https://gizmodo.com/google-booed-by-employees-at-planned-drag-show-event-1850595265">Read more...</a></p>

## This Nonprofit Wants to Catapult Material From Incoming Asteroids to Protect Earth
 - [https://gizmodo.com/nonprofit-aims-catapult-asteroid-materials-earth-defens-1850592844](https://gizmodo.com/nonprofit-aims-catapult-asteroid-materials-earth-defens-1850592844)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-30T15:25:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--MyRH13Id--/c_fit,fl_progressive,q_80,w_636/bd997dff56b09613b95e1bd7118ff3a6.jpg" /><p>In February 2013, an asteroid about the size of a house punched its way through Earth’s atmosphere and broke apart over the city of Chelyabinsk, Russia. The blast was so strong, it left a bright streak in the skies and triggered a powerful shockwave, shattering glass and resulting in the injury of over a 1,000 people.</p><p><a href="https://gizmodo.com/nonprofit-aims-catapult-asteroid-materials-earth-defens-1850592844">Read more...</a></p>

## Tech Companies Sue Arkansas Over Parental Consent Law for Social Media Access
 - [https://gizmodo.com/tech-companies-sue-arkansas-social-media-consent-law-1850594859](https://gizmodo.com/tech-companies-sue-arkansas-social-media-consent-law-1850594859)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-30T15:10:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--xACXllck--/c_fit,fl_progressive,q_80,w_636/126f23287279052391bb8ee8374aaf5f.jpg" /><p>After Arkansas governor Sarah Huckabee Sanders <a href="https://gizmodo.com/utah-and-arkansas-social-media-bans-won-t-protect-us-1850354255">signed a law that requires teens and kids to get parental consent before signing up for social media</a>, that law is now in the crosshairs of a tech trade group called NetChoice, which filed a lawsuit against it.<br /></p><p><a href="https://gizmodo.com/tech-companies-sue-arkansas-social-media-consent-law-1850594859">Read more...</a></p>

## The Spiders of Across the Spider-Verse Come to Life in a New Artbook
 - [https://gizmodo.com/spider-man-across-the-spider-verse-artbook-first-look-1850588278](https://gizmodo.com/spider-man-across-the-spider-verse-artbook-first-look-1850588278)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-30T15:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--g2240Rin--/c_fit,fl_progressive,q_80,w_636/2f94b33c35123a29dd63308420de3cf1.png" /><p>One thing that has enchanted the internet almost as much as <a href="https://gizmodo.com/spider-man-across-the-spider-verse-spoilers-questions-1850496483"><em>Spider-Man: Across the Spider-Verse</em></a> itself has is getting glimpses from artists <a href="https://gizmodo.com/spider-man-across-the-spider-verse-sony-animation-1850569811">into the work</a> that made the movie such a visual treat. Now, some of that work is about to be collected into a sumptuous new artbook, and io9 has your first look inside.</p><p><a href="https://gizmodo.com/spider-man-across-the-spider-verse-artbook-first-look-1850588278">Read more...</a></p>

## Canadian Wildfire Smoke Has Wrecked NYC’s Air Quality...Again
 - [https://gizmodo.com/canadian-wildfire-smoke-wrecked-nyc-air-quality-again-1850595179](https://gizmodo.com/canadian-wildfire-smoke-wrecked-nyc-air-quality-again-1850595179)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-30T14:45:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--BjpWM0Ei--/c_fit,fl_progressive,q_80,w_636/6b5a011c640add1ac69290facc95a38e.jpg" /><p>The Northeast has been hit by another round of wildfire smoke from our neighbor to the North.<br /></p><p><a href="https://gizmodo.com/canadian-wildfire-smoke-wrecked-nyc-air-quality-again-1850595179">Read more...</a></p>

## Supreme Court Says Yes, Sites Can Discriminate Against Gay People
 - [https://gizmodo.com/supreme-court-sites-discriminate-against-gay-people-1850592866](https://gizmodo.com/supreme-court-sites-discriminate-against-gay-people-1850592866)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-30T14:40:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--BYOu9WwP--/c_fit,fl_progressive,q_80,w_636/c04927ec928537ae2c32f52fce09e0ba.jpg" /><p>Time for another round of the Supreme Court’s newest game show: <em>Who Should Be Discriminated Against Next?</em> On Friday, the court decided 6 to 3 in the case of <em>303 Creative v. Aubrey Elenis, </em>agreeing that the First Amendment protects website designers who choose to discriminate based on their clients’ sexual orientation.</p><p><a href="https://gizmodo.com/supreme-court-sites-discriminate-against-gay-people-1850592866">Read more...</a></p>

## Brilliantly Modded Game Boy Camera Is No Bigger Than a Cartridge
 - [https://gizmodo.com/brilliantly-modded-game-boy-camera-is-no-bigger-than-a-1850595045](https://gizmodo.com/brilliantly-modded-game-boy-camera-is-no-bigger-than-a-1850595045)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-30T14:10:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--d8zknT1O--/c_fit,fl_progressive,q_80,w_636/eadb05b1766487515808bafdbdaaa0f3.jpg" /><p>Twenty-five years after the Game Boy Camera first debuted back in 1998,  fans are not only still enjoying lo-fi, black and white, pixelated photography, they’re also re-engineering the camera to make it better, even going so far as to <a href="https://twitter.com/thegameboycam/status/1674482559655321600?s=61&amp;t=npecRpZHFqrCWLY5QgRNUg" rel="noopener noreferrer" target="_blank">shrink it down to the size</a> of a regular Game Boy cartridge.</p><p><a href="https://gizmodo.com/brilliantly-modded-game-boy-camera-is-no-bigger-than-a-1850595045">Read more...</a></p>

## James Mangold Has a Plan for Swamp Thing
 - [https://gizmodo.com/swamp-thing-indiana-jones-dial-destiny-captain-america-1850593243](https://gizmodo.com/swamp-thing-indiana-jones-dial-destiny-captain-america-1850593243)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-30T14:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--tNIioPXG--/c_fit,fl_progressive,q_80,w_636/88bcd6bff9ec37177230205fe1031120.jpg" /><p>Now that <em>Indiana Jones and the Dial of Destiny</em> is almost here, director James Manfold is ready to head to the swamp. Speaking of, Phoebe Waller-Bridge hopes you haven;t seen the last of Helena Shaw. <em>Star Trek: Strange New Worlds</em> explains the niceties of storming a castle. All thus and mch mre, because the spoilers are…</p><p><a href="https://gizmodo.com/swamp-thing-indiana-jones-dial-destiny-captain-america-1850593243">Read more...</a></p>

## YouTube Threatens to Cut Off Ad Blocker Users After Just Three Ad-less Vids
 - [https://gizmodo.com/youtube-threatens-to-cut-off-ad-blocker-users-after-jus-1850594899](https://gizmodo.com/youtube-threatens-to-cut-off-ad-blocker-users-after-jus-1850594899)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-30T13:50:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--LiF4h0-u--/c_fit,fl_progressive,q_80,w_636/1876219035a00d97a728926dab3f05a0.jpg" /><p>Google is trying out a new show of force to keep users from watching YouTube videos without ads. Some users are reporting that  the company will allow access to just three videos before prompting to either disable ad blockers or otherwise pay Google for the privilege of ad-less viewing.</p><p><a href="https://gizmodo.com/youtube-threatens-to-cut-off-ad-blocker-users-after-jus-1850594899">Read more...</a></p>

## What is One Change Mark Zurkerberg Should Make to His Social Platforms? | Gizmodo Interview
 - [https://gizmodo.com/what-is-one-change-mark-zuckerberg-should-make-to-his-1850594774](https://gizmodo.com/what-is-one-change-mark-zuckerberg-should-make-to-his-1850594774)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-30T13:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--KruI84TM--/c_fit,fl_progressive,q_80,w_636/887617b78a70d2843d80aad1e7db10f8.jpg" /><p><a href="https://gizmodo.com/what-is-one-change-mark-zuckerberg-should-make-to-his-1850594774">Read more...</a></p>

## Four Ways Criminals Could Use AI to Target More Victims
 - [https://gizmodo.com/ai-four-ways-criminals-use-ai-target-more-victims-1850585866](https://gizmodo.com/ai-four-ways-criminals-use-ai-target-more-victims-1850585866)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-30T12:45:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--qUOWcqxJ--/c_fit,fl_progressive,q_80,w_636/e542d0bdbc01c11bd588ed24b7142b01.jpg" /><p>Warnings about artificial intelligence (AI) are ubiquitous right now. They have included <a href="https://www.safe.ai/statement-on-ai-risk" rel="noopener noreferrer" target="_blank">fearful messages</a> about AI’s potential to cause the extinction of humans, invoking images of the Terminator movies. The UK Prime Minister Rishi Sunak has even <a href="https://www.gov.uk/government/news/pm-urges-tech-leaders-to-grasp-generational-opportunities-and-challenges-of-ai" rel="noopener noreferrer" target="_blank">set up a summit to discuss AI safety</a>.<br /></p><p><a href="https://gizmodo.com/ai-four-ways-criminals-use-ai-target-more-victims-1850585866">Read more...</a></p>

## Apple’s Vision Pro Head Strap Problem
 - [https://gizmodo.com/apple-s-vision-pro-head-strap-problem-1850590354](https://gizmodo.com/apple-s-vision-pro-head-strap-problem-1850590354)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-06-30T12:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--0Xz41f3U--/c_fit,fl_progressive,q_80,w_636/8031ddc601da9dca247e88958dace28a.png" /><p>When I got a chance to <a href="https://gizmodo.com/apple-vision-pro-wwdc-review-strange-days-1850533500">try out Apple’s Vision Pro headset</a> several weeks ago, there was one big difference between what I wore and the display models shown off by Apple.<br /></p><p><a href="https://gizmodo.com/apple-s-vision-pro-head-strap-problem-1850590354">Read more...</a></p>

