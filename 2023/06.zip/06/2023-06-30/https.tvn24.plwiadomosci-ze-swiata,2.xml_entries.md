# Source:TVN24 Ze świata, URL:https://tvn24.pl/wiadomosci-ze-swiata,2.xml, language:pl-PL

## Broń, amunicja, narkotyki. Operacja austriackich służb przy współpracy z polskim CBŚP
 - [https://tvn24.pl/swiat/austria-operacja-austriackich-sluzb-przy-wspolpracy-z-polskim-cbsp-przejeto-bron-amunicje-i-narkotyki-sa-zatrzymani-7196705?source=rss](https://tvn24.pl/swiat/austria-operacja-austriackich-sluzb-przy-wspolpracy-z-polskim-cbsp-przejeto-bron-amunicje-i-narkotyki-sa-zatrzymani-7196705?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-06-30T07:10:33+00:00

<img alt="Broń, amunicja, narkotyki. Operacja austriackich służb przy współpracy z polskim CBŚP" src="https://tvn24.pl/najnowsze/cdn-zdjecie-aqfy2y-amunicja-i-bron-przejeta-w-austrii-pomagali-policjanci-z-cbsp-7196678/alternates/LANDSCAPE_1280" />
    Austriackie służby, we współpracy z policjantami polskiego CBŚP, w wyniku kilkunastu przeszukań przejęły w Austrii między innymi ponad 150 sztuk broni palnej oraz ponad 10 tysięcy sztuk amunicji. Zatrzymanych zostało sześć osób. W trakcie akcji zabezpieczono również emblematy i flagi o symbolice nazistowskiej oraz narkotyki - podało w komunikacie Centralne Biuro Śledcze Policji.

