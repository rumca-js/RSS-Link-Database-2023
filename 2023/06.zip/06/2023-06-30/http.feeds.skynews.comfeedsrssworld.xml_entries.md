# Source:Sky News, URL:http://feeds.skynews.com/feeds/rss/world.xml, language:en-US

## Cardiff City ordered to pay remainder of Emiliano Sala's transfer fee
 - [https://news.sky.com/story/cardiff-city-ordered-to-pay-remainder-of-emiliano-salas-transfer-fee-by-fifa-12912750](https://news.sky.com/story/cardiff-city-ordered-to-pay-remainder-of-emiliano-salas-transfer-fee-by-fifa-12912750)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-06-30T21:58:00+00:00

Cardiff City have been ordered to make the last two payments to Nantes for Emiliano Sala's transfer by FIFA.

## Roman holiday? Soon you'll have to pay to visit this main attraction
 - [https://news.sky.com/story/italy-to-start-charging-for-entry-to-ancient-roman-pantheon-from-monday-12912691](https://news.sky.com/story/italy-to-start-charging-for-entry-to-ancient-roman-pantheon-from-monday-12912691)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-06-30T19:14:00+00:00

Visitors going to Rome's Pantheon, one of the ancient world's best preserved monuments, will have to pay an entrance fee from Monday.

## Mother and son, 7, die after fall from ferry as murder probe launched
 - [https://news.sky.com/story/polish-mother-and-son-7-die-after-baltic-sea-fall-from-ferry-as-murder-investigation-launched-in-sweden-12912650](https://news.sky.com/story/polish-mother-and-son-7-die-after-baltic-sea-fall-from-ferry-as-murder-investigation-launched-in-sweden-12912650)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-06-30T17:56:00+00:00

A mother and her son have died after plunging off a ferry travelling from Sweden to Poland, police have confirmed.

## Titan debris found 'shortly after' search vessel arrived on seafloor
 - [https://news.sky.com/story/titan-search-team-leader-becomes-emotional-as-he-describes-operation-to-find-submersible-12912441](https://news.sky.com/story/titan-search-team-leader-becomes-emotional-as-he-describes-operation-to-find-submersible-12912441)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-06-30T17:11:00+00:00

The leader of the team which found the remains of the Titan submersible became emotional as he described how a rescue effort turned into a recovery operation.

## Grief and shock on the streets - as France braced for more violence
 - [https://news.sky.com/story/france-rioting-grief-and-shock-on-the-streets-as-country-braces-itself-for-more-violence-12912562](https://news.sky.com/story/france-rioting-grief-and-shock-on-the-streets-as-country-braces-itself-for-more-violence-12912562)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-06-30T16:06:00+00:00

As morning broke in Nanterre, the extent of the damage became evident.

## France to suspend all bus and tram services amid riots over police shooting
 - [https://news.sky.com/story/france-suspends-all-bus-and-tram-services-amid-riots-over-police-shooting-12912490](https://news.sky.com/story/france-suspends-all-bus-and-tram-services-amid-riots-over-police-shooting-12912490)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-06-30T14:15:00+00:00

France will suspend all bus and tram services amid ongoing riots over a police shooting.

## Caroline Wozniacki set to return three years after retirement
 - [https://news.sky.com/story/caroline-wozniacki-former-world-no-1-announces-tennis-return-three-years-after-retirement-12912360](https://news.sky.com/story/caroline-wozniacki-former-world-no-1-announces-tennis-return-three-years-after-retirement-12912360)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-06-30T11:41:00+00:00

Caroline Wozniacki will make a comeback to tennis after the former world No 1 said on Thursday that she was ready to return to the Tour, having retired from the sport in 2020 to start a family.

## Warning Antarctic sea ice at record low for June
 - [https://news.sky.com/story/antarctic-sea-ice-at-record-low-for-end-of-june-warns-met-office-12912329](https://news.sky.com/story/antarctic-sea-ice-at-record-low-for-end-of-june-warns-met-office-12912329)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-06-30T11:14:00+00:00

The amount of sea ice around Antarctica is at a record low for the end of June, the Met Office has said.

## Ukraine charges Russian politician over alleged deportation of orphans
 - [https://news.sky.com/story/ukraine-charges-russian-politician-with-war-crimes-over-alleged-deportation-of-orphans-12912288](https://news.sky.com/story/ukraine-charges-russian-politician-with-war-crimes-over-alleged-deportation-of-orphans-12912288)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-06-30T10:30:00+00:00

Ukraine has charged a Russian politician and two collaborators with war crimes over the alleged deportation of dozens of orphans.

## Israeli PM drops key element from judicial reform plan that has sparked widespread protests
 - [https://news.sky.com/story/israeli-pm-benjamin-netanyahu-drops-key-element-from-judicial-reform-plan-that-has-triggered-widespread-protests-12912270](https://news.sky.com/story/israeli-pm-benjamin-netanyahu-drops-key-element-from-judicial-reform-plan-that-has-triggered-widespread-protests-12912270)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-06-30T10:19:00+00:00

Israel's prime minister says he is dropping one of the most contentious elements of the judicial reforms his government has struggled to push through since it took office at the turn of the year.

## Where are Yevgeny Prigozhin, General Surovikin and Dmitry Medvedev?
 - [https://news.sky.com/story/wagner-rebellion-where-are-yevgeny-prigozhin-general-surovikin-and-dmitry-medvedev-12912246](https://news.sky.com/story/wagner-rebellion-where-are-yevgeny-prigozhin-general-surovikin-and-dmitry-medvedev-12912246)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-06-30T09:54:00+00:00

A week has now passed since Yevgeny Prigozhin's aborted armed rebellion against Moscow erupted. So where is the Wagner chief now? What about Dmitry Medvedev?

## Russia 'cutting numbers' at Zaporizhzhia nuclear plant
 - [https://news.sky.com/story/russia-reducing-personnel-at-zaporizhzhia-nuclear-plant-says-ukraine-12912241](https://news.sky.com/story/russia-reducing-personnel-at-zaporizhzhia-nuclear-plant-says-ukraine-12912241)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-06-30T09:49:00+00:00

The number of Russian personnel at the Zaporizhzhia nuclear power plant is gradually being reduced, according to Ukraine.

## Macron seen dancing at Elton John gig as riots raged across France
 - [https://news.sky.com/story/macron-seen-dancing-at-elton-john-gig-as-riots-raged-across-france-12912193](https://news.sky.com/story/macron-seen-dancing-at-elton-john-gig-as-riots-raged-across-france-12912193)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-06-30T08:45:00+00:00

France's president Emmanuel Macron is facing a backlash after being photographed meeting Elton John at a Paris gig, despite his country being in the grip of riots.

## Florida governor signs bill allowing roads to be built using product linked to cancer
 - [https://news.sky.com/story/ron-desantis-signs-florida-bill-allowing-roads-to-be-built-using-product-linked-to-cancer-12912176](https://news.sky.com/story/ron-desantis-signs-florida-bill-allowing-roads-to-be-built-using-product-linked-to-cancer-12912176)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-06-30T08:23:00+00:00

Glowing neon-yellow roads as from Jacksonville to Miami?

## Rising pig and monkey populations pose risk to humans, research suggests
 - [https://news.sky.com/story/risk-of-human-disease-due-to-rising-pig-and-monkey-populations-research-suggests-12912170](https://news.sky.com/story/risk-of-human-disease-due-to-rising-pig-and-monkey-populations-research-suggests-12912170)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-06-30T08:13:00+00:00

Rising monkey and pig populations pose an increased risk to human health, according to new research.

## Man wanted for Capitol riots arrested after carrying explosives near Obama's home
 - [https://news.sky.com/story/protester-wanted-for-capitol-riots-arrested-after-carrying-explosives-near-obamas-home-12912147](https://news.sky.com/story/protester-wanted-for-capitol-riots-arrested-after-carrying-explosives-near-obamas-home-12912147)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-06-30T07:40:00+00:00

A man who is wanted over his alleged role in the January 6 riots has been arrested after being caught outside the Washington DC home of former president Barack Obama with explosives, police said.

## Teenager taken by Russians considered suicide after solitary confinement
 - [https://news.sky.com/story/ukrainian-teenager-taken-by-russians-considered-suicide-after-solitary-confinement-12912114](https://news.sky.com/story/ukrainian-teenager-taken-by-russians-considered-suicide-after-solitary-confinement-12912114)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-06-30T06:17:00+00:00

In October last year, Tetiana Rudenko was away from her home in southern Ukraine attending her mother's funeral.

## Paris riots: A youth told us, in the most blunt terms possible, that we weren't welcome
 - [https://news.sky.com/story/paris-riots-a-youth-told-us-in-the-most-blunt-terms-possible-that-we-werent-welcome-12912087](https://news.sky.com/story/paris-riots-a-youth-told-us-in-the-most-blunt-terms-possible-that-we-werent-welcome-12912087)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-06-30T02:52:00+00:00

There are the three things that have come to illuminate the night sky in Nanterre - blue lights, orange flames and the starburst of fireworks.

## 'He didn't want to kill him' - Officer who shot teen apologises to family as riots spread across France
 - [https://news.sky.com/story/he-didnt-want-to-kill-him-officer-who-shot-teen-apologises-to-family-as-riots-spread-across-france-12912081](https://news.sky.com/story/he-didnt-want-to-kill-him-officer-who-shot-teen-apologises-to-family-as-riots-spread-across-france-12912081)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-06-30T01:33:00+00:00

The police officer who shot and killed a teenager during a traffic stop in Paris has asked the family of the boy for forgiveness.

## Being lonely may increase risk of heart disease in diabetics
 - [https://news.sky.com/story/being-lonely-may-increase-risk-of-heart-disease-in-diabetics-12912078](https://news.sky.com/story/being-lonely-may-increase-risk-of-heart-disease-in-diabetics-12912078)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-06-30T00:13:00+00:00

Loneliness may the increase risk of heart disease in diabetes patients, according to new research .

