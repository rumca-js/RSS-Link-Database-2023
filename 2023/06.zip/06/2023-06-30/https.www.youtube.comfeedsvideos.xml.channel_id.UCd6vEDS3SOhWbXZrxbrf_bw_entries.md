# Source:SAMTIME, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCd6vEDS3SOhWbXZrxbrf_bw, language:en-US

## I Bought a BlackBerry TABLET in 2023
 - [https://www.youtube.com/watch?v=n_ZGGAcTb8I](https://www.youtube.com/watch?v=n_ZGGAcTb8I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCd6vEDS3SOhWbXZrxbrf_bw
 - date published: 2023-06-30T14:00:38+00:00

Get a 3-month free trial of NordLocker Business here:
https://www.nordlocker.com/creators/ with code SAMTIME

Introducing the BlackBerry PlayBook! Did you know that BlackBerry made a tablet? Neither did I.

SUPPORT: https://funkytime.tv/patriot-signup/
MERCH: https://funkytime.tv/shop/
FUNKY TIME WEBSITE: https://funkytime.tv

FACEBOOK: http://www.facebook.com/SamtimeNews
TWITTER: http://twitter.com/SamtimeNews
INSTAGRAM: http://instagram.com/samtimenews

-----------------------------------

#BlackBerry #BlackBerryPlayBook #BlackBerryWorkBook

'Escape the ordinary. Embrace the FUNKY!'

-----------------------------------

For sponsorship enquiries: samtime@bossmgmtgrp.com
For other business enquiries: business@funkytime.tv
Copyright FUNKY TIME PRODUCTIONS 2023

