# Source:Techradar, URL:https://www.techradar.com/rss, language:en-US

## A free update to WiiM’s cheap wireless high-res music streamer adds a great feature found on expensive streamers
 - [https://www.techradar.com/audio/audio-streaming/a-free-update-to-wiims-cheap-wireless-high-res-music-streamer-adds-a-great-feature-found-on-expensive-streamers](https://www.techradar.com/audio/audio-streaming/a-free-update-to-wiims-cheap-wireless-high-res-music-streamer-adds-a-great-feature-found-on-expensive-streamers)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-06-30T20:15:39+00:00

A free upgrade to the WiiM Pro adds Roon Ready certification, making a great wireless music streamer even better

## WhatsApp just made transferring chat history so easy but there may be one big limit
 - [https://www.techradar.com/computing/software/whatsapp-just-made-transferring-chat-history-so-easy-but-there-may-be-one-big-limit](https://www.techradar.com/computing/software/whatsapp-just-made-transferring-chat-history-so-easy-but-there-may-be-one-big-limit)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-06-30T19:10:02+00:00

This update removes cloud transfer from the equation, but it appears the two phones may need to run the same OS.

## Tom Clancy's The Division Resurgence release date, platforms, everything we know
 - [https://www.techradar.com/gaming/tom-clancys-the-division-resurgence-release-date-platforms-gameplay](https://www.techradar.com/gaming/tom-clancys-the-division-resurgence-release-date-platforms-gameplay)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-06-30T17:45:00+00:00

Tom Clancy's The Division Resurgence is set to release later this year, and there's a lot to learn about its significance.

## We found your AMD mid-range CPU but you better act fast
 - [https://www.techradar.com/computing/cpu/we-found-your-amd-mid-range-cpu-but-you-better-act-fast](https://www.techradar.com/computing/cpu/we-found-your-amd-mid-range-cpu-but-you-better-act-fast)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-06-30T17:26:22+00:00

AMD is offering its mid-range Ryzen 5 5600X3D CPU, but only at a single retailer for a limited time.

## Watching Netflix on your Google TV just got a long-awaited upgrade to match Apple TV
 - [https://www.techradar.com/televisions/streaming-devices/watching-netflix-on-your-google-tv-just-got-a-long-awaited-upgrade-to-match-apple-tv](https://www.techradar.com/televisions/streaming-devices/watching-netflix-on-your-google-tv-just-got-a-long-awaited-upgrade-to-match-apple-tv)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-06-30T17:02:30+00:00

Netflix finally adds support for Google TV's framerate matching

## Google just released a special edition Pixel Fold, but you can't buy it
 - [https://www.techradar.com/phones/google-pixel-phones/google-just-released-a-special-edition-pixel-fold-but-you-cant-buy-it](https://www.techradar.com/phones/google-pixel-phones/google-just-released-a-special-edition-pixel-fold-but-you-cant-buy-it)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-06-30T16:31:08+00:00

Google has introduced a new and stylish variant of the Pixel Fold, but it's only available through the Gift from Google program.

## RIP to the Surface Pro 6 - Microsoft has ended support for the stellar tablet
 - [https://www.techradar.com/tablets/rip-to-the-surface-pro-6-microsoft-has-ended-support-for-the-stellar-tablet](https://www.techradar.com/tablets/rip-to-the-surface-pro-6-microsoft-has-ended-support-for-the-stellar-tablet)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-06-30T16:25:09+00:00

Surface Pro 6 users listen up - Microsoft will no longer support the tablet

## This fake Telegram app is just riddled with malware
 - [https://www.techradar.com/pro/phone-communications/this-fake-telegram-app-is-just-riddled-with-malware](https://www.techradar.com/pro/phone-communications/this-fake-telegram-app-is-just-riddled-with-malware)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-06-30T16:12:08+00:00

Unofficial apps are a good way to get your Android phone infected with malware.

## Internet shutdowns are on the rise, a new tool measures their impact on economies
 - [https://www.techradar.com/computing/internet/internet-shutdowns-are-on-the-rise-a-new-tool-measures-their-impact-on-economies](https://www.techradar.com/computing/internet/internet-shutdowns-are-on-the-rise-a-new-tool-measures-their-impact-on-economies)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-06-30T15:32:53+00:00

NetLoss promises to give "an unprecedented level of rigor and precision" able to go beyond a mere cost evaluation of internet shutdowns. Here's all you need to know.

## Intel is biggest loser as cloud giant splashes billions of dollars on rivals
 - [https://www.techradar.com/pro/intel-is-biggest-loser-as-cloud-giant-splashes-billions-of-dollars-on-rivals](https://www.techradar.com/pro/intel-is-biggest-loser-as-cloud-giant-splashes-billions-of-dollars-on-rivals)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-06-30T15:32:26+00:00

Arm startup emerges as billion dollar winner as cloud giant buys from Intel’s biggest rivals.

## Powerful new Chromebook tablets are coming, and they could finally bridge the gap between laptops and tablets
 - [https://www.techradar.com/computing/chromebooks/powerful-new-chromebook-tablets-are-coming-and-they-could-finally-bridge-the-gap-between-laptops-and-tablets](https://www.techradar.com/computing/chromebooks/powerful-new-chromebook-tablets-are-coming-and-they-could-finally-bridge-the-gap-between-laptops-and-tablets)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-06-30T15:17:09+00:00

A new board for Chrome tablets promises a significant uptick in performance, and I’m excited to see what it's capable of.

## Microsoft Azure might not be quite as profitable as we all thought
 - [https://www.techradar.com/pro/microsoft-azure-might-not-be-quite-as-profitable-as-we-all-thought](https://www.techradar.com/pro/microsoft-azure-might-not-be-quite-as-profitable-as-we-all-thought)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-06-30T14:16:14+00:00

Leaked court document details Microsoft Azure’s $34 billion revenue leading up to June 2022, leading to questions around its profitability.

## 7 new movies and TV shows on Netflix, Max, Prime Video and more this weekend (June 30)
 - [https://www.techradar.com/streaming/7-new-movies-and-tv-shows-on-netflix-max-prime-video-and-more-this-weekend-june-30-2023](https://www.techradar.com/streaming/7-new-movies-and-tv-shows-on-netflix-max-prime-video-and-more-this-weekend-june-30-2023)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-06-30T14:00:00+00:00

From returning fantasy adventures to pulse-racing thriller series, there’s plenty to watch this weekend.

## Tidal plans to rollout another hi-res lossless audio format for HiFi Plus subscribers
 - [https://www.techradar.com/audio/tidal/tidal-plans-to-rollout-another-hi-res-lossless-audio-format-for-hifi-plus-subscribers](https://www.techradar.com/audio/tidal/tidal-plans-to-rollout-another-hi-res-lossless-audio-format-for-hifi-plus-subscribers)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-06-30T13:31:16+00:00

Tidal's kept its promise: Hi-res FLAC is rolling out to its early access subscribers and coming to everybody else soon.

## Businesses are being told to cut hardware spending, but many aren't backing down
 - [https://www.techradar.com/pro/businesses-are-being-told-to-cut-hardware-spending-but-many-arent-backing-down](https://www.techradar.com/pro/businesses-are-being-told-to-cut-hardware-spending-but-many-arent-backing-down)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-06-30T13:08:47+00:00

IT decision-makers are buying higher-end devices in a hope that device refresh lifecycles can be extended.

## Windows 11 gets a cool new look for a feature everyone uses – but nobody loves
 - [https://www.techradar.com/computing/windows/windows-11-gets-a-cool-new-look-for-a-feature-everyone-uses-but-nobody-loves](https://www.techradar.com/computing/windows/windows-11-gets-a-cool-new-look-for-a-feature-everyone-uses-but-nobody-loves)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-06-30T13:04:36+00:00

Microsoft has just introduced Copilot in testing, but a change to the Settings app is almost as interesting (at least for now).

## Windows 11 gets Copilot AI – but Microsoft might be ruining it already
 - [https://www.techradar.com/computing/windows/windows-11-gets-copilot-ai-but-microsoft-might-be-ruining-it-already](https://www.techradar.com/computing/windows/windows-11-gets-copilot-ai-but-microsoft-might-be-ruining-it-already)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-06-30T13:01:11+00:00

Copilot’s initial form is rather unexciting, and also flirts with the idea of piping ads through to the user; please don’t, Microsoft.

## Beats Studio Pro tipped to have the Apple AirPods Max's personalized spatial audio upgrade
 - [https://www.techradar.com/audio/headphones/beats-studio-pro-tipped-to-have-the-apple-airpods-maxs-personalized-spatial-audio-upgrade](https://www.techradar.com/audio/headphones/beats-studio-pro-tipped-to-have-the-apple-airpods-maxs-personalized-spatial-audio-upgrade)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-06-30T12:44:02+00:00

Beats Studio Pro could have all the key features of AirPods Max for considerably less cash.

## Just Dance 2024 release date, platforms, gameplay, songs, and everything we know so far
 - [https://www.techradar.com/gaming/just-dance-2024-release-date-gameplay-songs](https://www.techradar.com/gaming/just-dance-2024-release-date-gameplay-songs)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-06-30T12:10:01+00:00

Just Dance 2024 is scheduled to arrive this October, but outside of a few tunes, there's still a lot to learn.

## Annapurna Interactive is making a new Blade Runner game set between the two movies
 - [https://www.techradar.com/gaming/consoles-pc/annapurna-interactive-is-making-a-new-blade-runner-game-set-between-the-two-movies](https://www.techradar.com/gaming/consoles-pc/annapurna-interactive-is-making-a-new-blade-runner-game-set-between-the-two-movies)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-06-30T11:32:08+00:00

Blade Runner 2033: Labyrinth is a brand new game set in the dystopian Los Angeles, made by Annapurna Interactive.

## Over a million NHS users have data leaked following ransomware attack
 - [https://www.techradar.com/pro/over-a-million-nhs-users-have-data-leaked-following-ransomware-attack](https://www.techradar.com/pro/over-a-million-nhs-users-have-data-leaked-following-ransomware-attack)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-06-30T11:28:03+00:00

Around 11 years of NHS patient data may have just been exposed in a ransomware attack.

## Motorola's iPhone 14-beating comms tech turns any phone into a satellite phone, and you can buy it now
 - [https://www.techradar.com/phones/motorola-phones/motorolas-iphone-14-beating-comms-tech-turns-any-phone-into-a-satellite-phone-and-you-can-buy-it-now](https://www.techradar.com/phones/motorola-phones/motorolas-iphone-14-beating-comms-tech-turns-any-phone-into-a-satellite-phone-and-you-can-buy-it-now)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-06-30T11:26:42+00:00

Motorola has launched its Motorola Defy Smartphone Satellite Link, which can turn any smartphone into a satellite phone.

## Call of Duty introduces 'hallucinations' to mess with cheaters
 - [https://www.techradar.com/gaming/consoles-pc/call-of-duty-introduces-hallucinations-to-mess-with-cheaters](https://www.techradar.com/gaming/consoles-pc/call-of-duty-introduces-hallucinations-to-mess-with-cheaters)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-06-30T11:14:03+00:00

Call of Duty's Ricochet anti-cheat system just got an update that's seriously messing with ill-intentioned players.

## iPhone 15 Pro all but confirmed to get potentially game-changing design feature
 - [https://www.techradar.com/phones/iphone/iphone-15-pro-all-but-confirmed-to-get-potentially-game-changing-design-feature](https://www.techradar.com/phones/iphone/iphone-15-pro-all-but-confirmed-to-get-potentially-game-changing-design-feature)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-06-30T11:08:15+00:00

The iPhone 15 Pro and iPhone 15 Pro Max are now all but confirmed to get titanium frames.

## Meta wants to create a Facebook app store to compete with Apple's App Store and Google Play
 - [https://www.techradar.com/computing/facebook/meta-wants-to-create-a-facebook-app-store-to-compete-with-apples-app-store-and-google-play](https://www.techradar.com/computing/facebook/meta-wants-to-create-a-facebook-app-store-to-compete-with-apples-app-store-and-google-play)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-06-30T10:58:28+00:00

Meta will soon let you download apps straight from within the Facebook app, just by clicking on ads.

## Microsoft Office won't open since updating Windows? This company has fixed it
 - [https://www.techradar.com/pro/microsoft-office-wont-open-since-updating-windows-this-company-has-fixed-it](https://www.techradar.com/pro/microsoft-office-wont-open-since-updating-windows-this-company-has-fixed-it)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-06-30T10:55:04+00:00

Recent Windows updates caused security software to block some Office and other apps.

## Annoying Gmail change rolled back following user outcry
 - [https://www.techradar.com/pro/annoying-gmail-change-rolled-back-following-user-outcry](https://www.techradar.com/pro/annoying-gmail-change-rolled-back-following-user-outcry)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-06-30T10:48:43+00:00

Gmail changes its notifications on Android once again following outcry.

## The hunt for Diablo 4’s secret cow level continues despite setbacks from new patch
 - [https://www.techradar.com/gaming/the-hunt-for-diablo-4s-secret-cow-level-continues-despite-setbacks-from-new-patch](https://www.techradar.com/gaming/the-hunt-for-diablo-4s-secret-cow-level-continues-despite-setbacks-from-new-patch)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-06-30T10:18:21+00:00

Diablo 4 players are continuing to scour the game for a secret cow level, but their search has been held back by a new patch.

## Companies who force workers back to the office are losing a lot of key employees
 - [https://www.techradar.com/pro/companies-who-force-workers-back-to-the-office-are-losing-a-lot-of-key-employees](https://www.techradar.com/pro/companies-who-force-workers-back-to-the-office-are-losing-a-lot-of-key-employees)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-06-30T10:00:39+00:00

RTO mandates are pushing workers away, and putting new talent off, but many companies think things are OK.

## Hunt: Showdown achieves its biggest concurrent player base to date with new expansion
 - [https://www.techradar.com/gaming/consoles-pc/hunt-showdown-achieves-its-biggest-concurrent-player-base-to-date-with-new-expansion](https://www.techradar.com/gaming/consoles-pc/hunt-showdown-achieves-its-biggest-concurrent-player-base-to-date-with-new-expansion)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-06-30T09:40:23+00:00

Hunt: Showdown has just achieved its biggest historic-ever player count as a new expansion has released.

## Apple TV Plus fans can't get enough of Idris Elba's thrilling Hijack series
 - [https://www.techradar.com/streaming/apple-tv-plus/apple-tv-plus-fans-cant-get-enough-of-idris-elbas-thrilling-hijack-series](https://www.techradar.com/streaming/apple-tv-plus/apple-tv-plus-fans-cant-get-enough-of-idris-elbas-thrilling-hijack-series)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-06-30T09:29:56+00:00

Idris Elba's new TV show has become the latest surprise hit for Apple's streaming platform.

## You can register for RoboCop: Rogue City's closed playtest right now
 - [https://www.techradar.com/gaming/consoles-pc/you-can-register-for-robocop-rogue-citys-closed-playtest-right-now](https://www.techradar.com/gaming/consoles-pc/you-can-register-for-robocop-rogue-citys-closed-playtest-right-now)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-06-30T09:19:59+00:00

RoboCop: Rogue City is finally getting a closed playtest that you sign up for right now, but there's no guarantee that you'll be let in.

## Pokémon Go a "top priority" for Niantic as it cancels two games and lays off staff
 - [https://www.techradar.com/gaming/consoles-pc/pokemon-go-a-top-priority-for-niantic-as-it-cancels-two-games-and-lays-off-staff](https://www.techradar.com/gaming/consoles-pc/pokemon-go-a-top-priority-for-niantic-as-it-cancels-two-games-and-lays-off-staff)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-06-30T09:13:31+00:00

Pokémon Go creator Niantic has confirmed it's canceled two games and laid off staff to refocus on the popular mobile title.

## Baldur's Gate 3 will come to Xbox once the devs "overcome" technical hurdles
 - [https://www.techradar.com/gaming/baldurs-gate-3-will-come-to-xbox-once-the-devs-overcome-technical-hurdles](https://www.techradar.com/gaming/baldurs-gate-3-will-come-to-xbox-once-the-devs-overcome-technical-hurdles)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-06-30T08:57:10+00:00

Baldur's Gate 3 will still be coming to Microsoft's consoles, but the developers are facing hardware challenges that'll keep Xbox fans waiting.

## Businesses are set to spend billions on securing their 5G networks
 - [https://www.techradar.com/phones/businesses-are-set-to-spend-billions-on-securing-their-5g-networks](https://www.techradar.com/phones/businesses-are-set-to-spend-billions-on-securing-their-5g-networks)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-06-30T08:04:27+00:00

Private 5G isn't secure by default, despite some companies clearly thinking that it is.

## Microsoft's new AI shopping tools will create a buying guide just for you
 - [https://www.techradar.com/computing/artificial-intelligence/microsofts-new-ai-shopping-tools-will-create-a-buying-guide-just-for-you](https://www.techradar.com/computing/artificial-intelligence/microsofts-new-ai-shopping-tools-will-create-a-buying-guide-just-for-you)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-06-30T04:00:56+00:00

Microsoft aims to make online shopping easier as the new tools will also summarize reviews and keep track of prices.

## Quordle today - hints and answers for Friday, June 30 (game #522)
 - [https://www.techradar.com/computing/websites-apps/quordle-today-answers-clues-30-june-2023](https://www.techradar.com/computing/websites-apps/quordle-today-answers-clues-30-june-2023)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-06-30T04:00:10+00:00

Looking for Quordle clues? We can help. Plus get the answers to Quordle today and past solutions.

