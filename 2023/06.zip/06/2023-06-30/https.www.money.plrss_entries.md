# Source:Money PL, URL:https://www.money.pl/rss/, language:pl-PL

## Prezydent Świnoujścia zwrócił się do prezesa Kaczyńskiego. "Moją radość zakłóca jeden problem"
 - [https://www.money.pl/gospodarka/prezydent-swinoujscia-zwrocil-sie-do-prezesa-kaczynskiego-moja-radosc-zakloca-jeden-problem-6914566323186336a.html](https://www.money.pl/gospodarka/prezydent-swinoujscia-zwrocil-sie-do-prezesa-kaczynskiego-moja-radosc-zakloca-jeden-problem-6914566323186336a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-30T12:02:13+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/347397d8-3e9b-4205-8158-bf17ca4825e5" width="308" /> W piątek rządzący oficjalnie otworzyli tunel pod rzeką Świną łączący wyspy Wolin i Uznam. Na ceremonii wystąpili razem prezes PiS-u i Janusz Żmurkiewicz, prezydent Świnoujścia. – Moją radość zakłóca jeden problem – tak włodarz miasta zwrócił się do Jarosława Kaczyńskiego. A ten mu odpowiedział.

## Widełki płacowe w ogłoszeniu o pracę
 - [https://www.money.pl/pieniadze/widelki-placowe-w-ogloszeniu-o-prace-6914564750301920a.html](https://www.money.pl/pieniadze/widelki-placowe-w-ogloszeniu-o-prace-6914564750301920a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-30T11:55:47+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/3e31c388-6782-4758-a2e5-b4f0815cefc7" width="308" /> Firma, której zależy na stworzeniu dobrej oferty pracy powinna zamieścić w treści informacje o proponowanym wynagrodzeniu. Dlaczego jednak dodanie tej informacji nie powinno być traktowane jak kolejny punkt na liście? Proponowane widełki to istotna kwestia dla kandydatów zaznajamiających się z potencjalnym nowym pracodawcą

## KGHM otworzył najgłębsze w Polsce wyrobisko górnicze
 - [https://www.money.pl/gospodarka/kghm-otworzyl-najglebsze-w-polsce-wyrobisko-gornicze-6914541496478368a.html](https://www.money.pl/gospodarka/kghm-otworzyl-najglebsze-w-polsce-wyrobisko-gornicze-6914541496478368a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-30T10:21:13+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/71b6703d-950d-48b7-969f-4f177832c039" width="308" /> 1348 metrów ma należący do KGHM Polska Miedź szyb GG-1 w Kwielicach na Dolnym Śląsku. Uroczyście otwarte w piątek najgłębsze w Polsce wyrobisko górnicze to jedna z najważniejszych inwestycji w historii spółki oraz największy podziemny projekt w branży metali nieżelaznych w Europie - podał KGHM.

## Sytuacja gospodarstw domowych się pogarsza. GUS przedstawił raport o zasięgu ubóstwa ekonomicznego
 - [https://www.money.pl/gospodarka/sytuacja-gospodarstw-domowych-sie-pogarsza-gus-przedstawil-raport-o-zasiegu-ubostwa-ekonomicznego-6914515864238816a.html](https://www.money.pl/gospodarka/sytuacja-gospodarstw-domowych-sie-pogarsza-gus-przedstawil-raport-o-zasiegu-ubostwa-ekonomicznego-6914515864238816a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-30T10:16:29+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c568bcdf-6d7e-4661-9e39-ed03e6915186" width="308" /> Przeciętna sytuacja materialna gospodarstw realnie się pogarsza – stwierdził Główny Urząd Statystyczny. Wszystko przez wysoką inflację utrzymującą się w Polsce. Mimo to w 2022 r. zasięgi ubóstwa ekonomicznego w gospodarstwach domowych ogółem pozostały na podobnym poziomie jak w 2021 r.

## Nie tak szybko z twierdzeniami, że ceny nie wzrastają. One wciąż rosną, ale wolniej
 - [https://www.money.pl/gospodarka/nie-tak-szybko-z-twierdzeniami-ze-ceny-nie-wzrastaja-one-wciaz-rosna-ale-wolniej-6914524403038880a.html](https://www.money.pl/gospodarka/nie-tak-szybko-z-twierdzeniami-ze-ceny-nie-wzrastaja-one-wciaz-rosna-ale-wolniej-6914524403038880a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-30T09:58:16+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/8c4dabfa-ae51-4e07-9912-54a734fad017" width="308" /> Inflacja w czerwcu była niższa względem tej w maju. To woda na młyn dla mediów prorządowych, które ogłosiły, że ceny usług i towarów "już nie wzrastają". Jednak nie do końca tak jest. Ceny wciąż rosną, ale już w wolniejszym tempie.

## "Milion dziewczyn zabiłoby, żeby dostać tę pracę". Anna Wintour szuka asystentki
 - [https://www.money.pl/gospodarka/milion-dziewczyn-zabilyby-zeby-dostac-te-prace-anna-wintour-szuka-asystentki-6914531095083744a.html](https://www.money.pl/gospodarka/milion-dziewczyn-zabilyby-zeby-dostac-te-prace-anna-wintour-szuka-asystentki-6914531095083744a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-30T09:38:58+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/540ff8db-8ee4-4291-9270-5f8c014667bb" width="308" /> Fani kultowego filmu "Diabeł ubiera się u Prady" mogą wreszcie ubiegać się o pracę, za którą "milion dziewczyn by zabiło", ponieważ szefowa Vogue, Anna Wintour, poszukuje nowej asystentki - informuje portal fortune.com.

## "Miliony dziewczyn zabiłyby, żeby dostać tę pracę". Anna Wintour szuka asystentki
 - [https://www.money.pl/gospodarka/miliony-dziewczyn-zabilyby-zeby-dostac-te-prace-anna-wintour-szuka-asystentki-6914531095083744a.html](https://www.money.pl/gospodarka/miliony-dziewczyn-zabilyby-zeby-dostac-te-prace-anna-wintour-szuka-asystentki-6914531095083744a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-30T09:38:58+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/540ff8db-8ee4-4291-9270-5f8c014667bb" width="308" /> Fani kultowego filmu "Diabeł ubiera się u Prady" mogą wreszcie ubiegać się o pracę, za którą "milion dziewczyn by zabiło", ponieważ szefowa Vogue, Anna Wintour, poszukuje nowej asystentki - informuje portal finance.yahoo.com

## Były bank Czarneckiego na sprzedaż. Rusza procedura
 - [https://www.money.pl/banki/byly-bank-czarneckiego-na-sprzedaz-rusza-procedura-6914525088156384a.html](https://www.money.pl/banki/byly-bank-czarneckiego-na-sprzedaz-rusza-procedura-6914525088156384a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-30T09:14:32+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/98066ffa-39ad-44df-b76e-09dfdd2c4e30" width="308" /> Bankowy Fundusz Gwarancyjny rozpoczął proces sprzedaży 100 proc. akcji VeloBanku, który został założony w 2022 roku jako instytucja pomostowa. Bank powstał w wyniku przymusowej restrukturyzacji Getin Banku.

## VeloBank na sprzedaż. Rusza procedura
 - [https://www.money.pl/banki/velobank-na-sprzedaz-rusza-procedura-6914525088156384a.html](https://www.money.pl/banki/velobank-na-sprzedaz-rusza-procedura-6914525088156384a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-30T09:14:32+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/98066ffa-39ad-44df-b76e-09dfdd2c4e30" width="308" /> Bankowy Fundusz Gwarancyjny rozpoczął proces sprzedaży 100 proc. akcji VeloBanku, który został założony w 2022 roku jako instytucja pomostowa. Bank powstał w wyniku przymusowej restrukturyzacji Getin Banku.

## Są najnowsze dane o inflacji
 - [https://www.money.pl/gospodarka/sa-najnowsze-dane-o-inflacji-6914481693657760a.html](https://www.money.pl/gospodarka/sa-najnowsze-dane-o-inflacji-6914481693657760a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-30T08:01:01+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/899fdf12-0ded-4c23-a04b-c6615a899809" width="308" /> Inflacja w Polsce w czerwcu 2023 r. wyniosła 11,5 proc. porównując rok do roku - podał GUS. To wynik nieco niższy, niż wskazywały prognozy. Miesiąc do miesiąca ceny stały w miejscu. Przypomnijmy, że w maju inflacja wyniosła 13 proc.

## Są najnowsze dane o inflacji. "Na razie dobrze to wygląda"
 - [https://www.money.pl/gospodarka/sa-najnowsze-dane-o-inflacji-na-razie-dobrze-to-wyglada-6914481693657760a.html](https://www.money.pl/gospodarka/sa-najnowsze-dane-o-inflacji-na-razie-dobrze-to-wyglada-6914481693657760a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-30T08:01:01+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/08a78ee7-4dc6-4199-b0e6-44d8f13beffb" width="308" /> Inflacja w Polsce w czerwcu 2023 r. wyniosła 11,5 proc. porównując rok do roku - podał GUS. To wynik nieco niższy, niż wskazywały prognozy. Miesiąc do miesiąca ceny stały w miejscu. Przypomnijmy, że w maju inflacja wyniosła 13 proc.

## Zadłużony jak kurier. Podwykonawcy gigantów toną w długach
 - [https://www.money.pl/gospodarka/zadluzony-jak-kurier-podwykonawcy-gigantow-tona-w-dlugach-6914505380072160a.html](https://www.money.pl/gospodarka/zadluzony-jak-kurier-podwykonawcy-gigantow-tona-w-dlugach-6914505380072160a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-30T07:54:17+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/9c31c0b0-89a6-4eac-9f32-f0ba6cac9db2" width="308" /> Firmy kurierskie są wypłacalne, dopóki trafiają na wiarygodnych kontrahentów. Problemy zaczynają się, gdy zleceniodawcy zaczynają ciąć koszty i np. kwestionują wysokość opłat za przewóz towarów. Efekt? Niemal 1,2 tys. przedsiębiorstw z branży ma długi na średnią kwotę 29 tys. zł.

## Ustawa frankowa. Jest deklaracja rządu
 - [https://www.money.pl/gospodarka/ustawa-frankowa-jest-deklaracja-rzadu-6914502820473504a.html](https://www.money.pl/gospodarka/ustawa-frankowa-jest-deklaracja-rzadu-6914502820473504a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-30T07:43:56+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/a4d0b4f4-fd13-4d12-bce7-f3595af553df" width="308" /> - Nie pracujemy nad ustawą frankową, nie sądzę, żeby powstała jeszcze w tej kadencji. Zachęcam zarówno kredytobiorców, jak i banki do zawierania ugód - powiedział wiceminister finansów Artur Soboń w rozmowie RMF FM.

## Utrata zysków w wyniku złamania umowy – jakie odszkodowanie przysługuje?
 - [https://www.money.pl/gospodarka/utrata-zyskow-w-wyniku-zlamania-umowy-jakie-odszkodowanie-przysluguje-6913836737055456a.html](https://www.money.pl/gospodarka/utrata-zyskow-w-wyniku-zlamania-umowy-jakie-odszkodowanie-przysluguje-6913836737055456a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-30T07:24:00+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/205fbbfc-d870-4e61-8d9f-be554f07a5a8" width="308" /> Umowa zawierana pomiędzy stronami może dotyczyć różnych stosunków prawnych. Może być to umowa sprzedaży, umowa o współpracę, a na mocy Kodeksu pracy może zostać podpisana pomiędzy pracodawcą a pracownikiem umowa o pracę. Złamanie warunków jednej z takich umów może prowadzić do utraty zysków przez przedsiębiorcę. Jakie odszkodowanie będzie mu przysługiwało od pracownika łamiącego np. zakaz konkurencji ujęty w umowie o pracę albo kontrahenta, który nie wykonał umowy lub wykonał ją bez należytej staranności?

## Firmy kończą z podwyżkami cen. To odbije się na inflacji
 - [https://www.money.pl/gospodarka/firmy-koncza-z-podwyzkami-cen-to-odbije-sie-na-inflacji-6914492634770080a.html](https://www.money.pl/gospodarka/firmy-koncza-z-podwyzkami-cen-to-odbije-sie-na-inflacji-6914492634770080a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-30T07:02:27+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/88077b6f-c0f2-4f33-be9f-58e9d72be788" width="308" /> Spada liczba firm przewidujących wzrost cen w ciągu roku. Odsetek czarnowidzów skurczył się o połowę. Dotyczy to zarówno podmiotów handlujących towarami, jak i usług. To dobre wiadomości dla Polaków, gdyż mogą się oni spodziewać wyhamowania inflacji.

## Blisko połowa  Polaków nie planuje wakacyjnego wyjazdu
 - [https://www.money.pl/gospodarka/blisko-polowa-polakow-nie-planuje-wakacyjnego-wyjazdu-6914488879127264a.html](https://www.money.pl/gospodarka/blisko-polowa-polakow-nie-planuje-wakacyjnego-wyjazdu-6914488879127264a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-30T06:47:10+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/a29636cc-ee01-41af-a219-2697c5c10676" width="308" /> Ponad 46 proc. Polaków nie planuje wyjeżdżać na letni urlop, 21,4 proc. zrobi to na nie dłużej niż siedem dni - wynika z opublikowanego w piątek sondażu IBRiS dla Radia ZET. Większość ankietowanych w tym roku wybiera się na wczasy za granicą, nad polskie morze i jezioro - dodano.

## Banki szykują się na inną rzeczywistość. Rezerwują miliardy zł na pozwy
 - [https://www.money.pl/banki/banki-szykuja-sie-na-inna-rzeczywistosc-rezerwuja-miliardy-zl-na-pozwy-6914479243578080a.html](https://www.money.pl/banki/banki-szykuja-sie-na-inna-rzeczywistosc-rezerwuja-miliardy-zl-na-pozwy-6914479243578080a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-30T06:07:46+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/581dc13f-b027-48f8-b314-c0568adfd7ea" width="308" /> Najnowszy wyrok TSUE w sprawie spraw frankowiczów zmienia rzeczywistość banków. Związek Banków Polskich przygotował dwa scenariusze kosztów związanych z kredytami we frankach szwajcarskich: referencyjny i szokowy. Instytucje finansowe będą musiały zabezpieczyć kolejne dziesiątki miliardów zł.

## Można jeszcze kupić tani węgiel od gminy, ale trzeba się spieszyć
 - [https://www.money.pl/gospodarka/mozna-jeszcze-kupic-tani-wegiel-od-gminy-ale-trzeba-sie-spieszyc-6914476814637792a.html](https://www.money.pl/gospodarka/mozna-jeszcze-kupic-tani-wegiel-od-gminy-ale-trzeba-sie-spieszyc-6914476814637792a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-30T05:58:07+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/0a85dbed-22ac-4114-895c-757cced6cb99" width="308" /> Tylko do 30 czerwca można składać wnioski na zakup od gminy węgla po preferencyjnych cenach. Co ważne teraz nie obowiązują limity zakupu ani rejonizacja. Takie zmiany wprowadziła nowelizacja ustawy o zakupie preferencyjnym paliwa stałego.

## Od 1 lipca duże zmiany dla kierowców. Nie wszystkie są przez nich oczekiwane
 - [https://www.money.pl/gospodarka/od-1-lipca-duze-zmiany-dla-kierowcow-nie-wszystkie-sa-przez-nich-oczekiwane-6914467946228384a.html](https://www.money.pl/gospodarka/od-1-lipca-duze-zmiany-dla-kierowcow-nie-wszystkie-sa-przez-nich-oczekiwane-6914467946228384a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-30T05:22:01+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/3d076cf4-79b5-4a4a-b6bb-8d103850442b" width="308" /> Od soboty wchodzą w życie zmiany w prawie, które wpłyną na codzienne funkcjonowanie kierowców. Zmienią się zasady dotyczące m.in. punktów karnych, opłat ewidencyjnych i za przejazdy autostradą. Zmienią się też kary za brak ubezpieczenia OC.

## Ile kosztuje euro? Kurs euro do złotego PLN/EUR 30.06.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-30-06-2023-6914463811750624a.html](https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-30-06-2023-6914463811750624a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-30T05:05:18+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cf3a8300-d9c9-461f-9fbc-2f314332a28c" width="308" /> Kurs euro - 30.06.2023. W piątek za jedno euro (EUR) trzeba zapłacić 4.447 zł.

## Ile kosztuje frank szwajcarski? Kurs franka do złotego PLN/CHF 30.06.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-30-06-2023-6914463812926112a.html](https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-30-06-2023-6914463812926112a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-30T05:05:18+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b1c04e3f-7bce-4c35-b03c-7a8d7b0adc65" width="308" /> Kurs franka szwajcarskiego - 30.06.2023. W piątek za jednego franka (CHF) trzeba zapłacić 4.5525 zł.

## Ile kosztuje dolar? Kurs dolara do złotego PLN/USD 30.06.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-30-06-2023-6914462711061152a.html](https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-30-06-2023-6914462711061152a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-30T05:00:49+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e0ba71a8-9c02-482d-85dd-ebac5362ee3b" width="308" /> Kurs dolara - 30.06.2023. W piątek za jednego dolara (USD) trzeba zapłacić 4.0912 zł.

## Ile kosztuje funt? Kurs funta do złotego PLN/GBP 30.06.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-30-06-2023-6914462710381216a.html](https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-30-06-2023-6914462710381216a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-30T05:00:49+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c374eefc-9e8b-424a-aaa7-91759b47d116" width="308" /> Kurs funta szterlinga - 30.06.2023. W piątek za jednego funta brytyjskiego (GBP) trzeba zapłacić 5.165 zł.

## Kursy walut 30.06.2023. Piątkowy kurs funta, euro, dolara i franka szwajcarskiego
 - [https://www.money.pl/pieniadze/kursy-walut-30-06-2023-piatkowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6914461054851808a.html](https://www.money.pl/pieniadze/kursy-walut-30-06-2023-piatkowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6914461054851808a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-30T04:54:00+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/f25df134-ca5f-469f-b693-7773e001842b" width="308" /> Kursy walut - 30.06.2023. W środę za jednego dolara (USD) zapłacimy 4,0925 zł. Cena jednego funta szterlinga (GBP) to 5,1668 zł, a franka szwajcarskiego (CHF) 4,5544 zł. Z kolei euro (EUR) możemy zakupić za 4,4485 zł.

## Można stracić 500 plus. Trzeba się pospieszyć z wnioskiem
 - [https://www.money.pl/gospodarka/mozna-stracic-500-plus-trzeba-sie-pospieszyc-z-wnioskiem-6914457352862432a.html](https://www.money.pl/gospodarka/mozna-stracic-500-plus-trzeba-sie-pospieszyc-z-wnioskiem-6914457352862432a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-30T04:38:52+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/20f50d74-8dff-44fd-af1d-cd35e27a7f44" width="308" /> Osoby pobierający świadczenie 500 plus mają już raptem kilka dni na złożenie wniosku o wypłaty na kolejny okres świadczeniowy. Rodzice, którzy prześpią termin, muszą się liczyć z faktem, że otrzymają pieniądze później.

## Niższe rachunki za prąd. Zostały ostatnie godziny na złożenie wniosku
 - [https://www.money.pl/gospodarka/nizsze-rachunki-za-prad-zostaly-ostatnie-godziny-na-zlozenie-wniosku-6914456504490656a.html](https://www.money.pl/gospodarka/nizsze-rachunki-za-prad-zostaly-ostatnie-godziny-na-zlozenie-wniosku-6914456504490656a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-30T04:35:28+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/3e0f5f95-7f3a-47f7-8db3-0808abb493d5" width="308" /> 30 czerwca mija termin składania oświadczeń o podniesienie limitu zużycia energii elektrycznej po zamrożonej cenie w 2023 r. Podstawowy limit to 2 MWh, dla uprawnionych odbiorców może wzrosnąć do 2,6 lub 3 MWh.

## Orlen ma wielkie plany. Chodzi o dodatkowe 2 mld złotych zysku
 - [https://www.money.pl/gospodarka/orlen-ma-wielkie-plany-chodzi-o-dodatkowe-2-mld-zlotych-zysku-6914453160110816a.html](https://www.money.pl/gospodarka/orlen-ma-wielkie-plany-chodzi-o-dodatkowe-2-mld-zlotych-zysku-6914453160110816a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-30T04:21:51+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/06225461-5e34-42de-a36d-9321b8c4655f" width="308" /> PKN Orlen ogłosił plany rozbudowy swojego kompleksu Olefin w zakładzie produkcyjnym w Płocku. Według informacji przekazanych przez firmę ta decyzja może przyczynić się do wzrostu zysku operacyjnego grupy Orlen nawet o 2 miliardy złotych rocznie.

