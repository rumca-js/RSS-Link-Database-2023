# Source:Le Monde - science, URL:https://www.lemonde.fr/en/science/rss_full.xml, language:en-US

## Brazil court bars Bolsonaro from public office
 - [https://www.lemonde.fr/en/international/article/2023/06/30/brazil-court-bars-bolsonaro-from-public-office_6040364_4.html](https://www.lemonde.fr/en/international/article/2023/06/30/brazil-court-bars-bolsonaro-from-public-office_6040364_4.html)
 - RSS feed: https://www.lemonde.fr/en/science/rss_full.xml
 - date published: 2023-06-30T18:27:11+00:00

The former Brazilian leader is banned from politics for eight years over making unfounded claims against the country's voting system.

