# Source:Nerdstalgic, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXjmz8dFzRJZrZY8eFiXNUQ, language:en-US

## The Devastating Downfall Of Heroes
 - [https://www.youtube.com/watch?v=EahwGkYb5Mg](https://www.youtube.com/watch?v=EahwGkYb5Mg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXjmz8dFzRJZrZY8eFiXNUQ
 - date published: 2023-06-30T17:00:20+00:00

When NBC's Heroes first debuted in 2006, it was drastically ahead of it's time in the superhero genre.  Airing 2 full years before Iron Man came out, Heroes was a very different look at what superhero stories could be.  Though as the series progressed into season 2, the Writers Guild of America went on strike and Heroes would never recover.  

#heroes #superhero #nerdstalgic 

Sources:
https://www.cbr.com/why-heroes-tv-canceled-finale-explained/
 https://www.looper.com/140462/the-real-reason-heroes-was-canceled/
https://ew.com/article/2007/11/07/heroes-creator-fans-im-super-sorry/
https://screenrant.com/heroes-series-season-2-disappointing-why/ https://www.ign.com/articles/2007/12/14/heroes-creator-tim-kring-talks
https://www.tvinsider.com/gallery/2023-wga-writers-strike-shows-affected-list/
https://www.vulture.com/2023/05/writers-strike-2023-celebrities-support.html
https://web.archive.org/web/20120229223150/http://abcmedianet.com/web/dnr/dispDNR.aspx?id=112806_08
https://apnews.com/article/wga-writers-strike-demands-d403f5b4666f20e2ce3e379bcaef5f2a

