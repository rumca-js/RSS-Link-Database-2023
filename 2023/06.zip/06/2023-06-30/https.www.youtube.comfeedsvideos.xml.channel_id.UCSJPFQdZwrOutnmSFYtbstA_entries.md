# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Indiana Jones And The Destruction Of Legacy
 - [https://www.youtube.com/watch?v=G_k8cDLe-Kk](https://www.youtube.com/watch?v=G_k8cDLe-Kk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2023-06-30T17:30:02+00:00

Its finally here, and its just as terrible as we expected. Join me for my full review of Indiana Jones and the Dial Of Destiny.

