# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Billy Woods & Kenny Segal - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=ZVur7jaIYTc](https://www.youtube.com/watch?v=ZVur7jaIYTc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-06-30T15:00:34+00:00

http://KEXP.ORG presents Billy Woods & Kenny Segal performing live in the KEXP studio. Recorded May 16, 2023

Songs:
Soft Landing
Blue Smoke
Bad Dreams Are Only Dreams
FaceTime

Billy Woods - Vocals
Kenny Segal - Samplers

Host: Larry Mizell, Jr.
Audio Engineers: Kevin Suggs
Audio Mixer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Alaia D’Alessandro, Scott Holpainen, Ettie Wahl
Editor: Scott Holpainen

https://billywoods.bandcamp.com/album/maps
http://kexp.org

## Billy Woods & Kenny Segal - Blue Smoke (Live on KEXP)
 - [https://www.youtube.com/watch?v=wNj075NNJCc](https://www.youtube.com/watch?v=wNj075NNJCc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-06-30T11:00:50+00:00

http://KEXP.ORG presents Billy Woods & Kenny Segal performing “Blue Smoke” live in the KEXP studio. Recorded May 16, 2023

Billy Woods - Vocals
Kenny Segal - Samplers

Host: Larry Mizell, Jr.
Audio Engineers: Kevin Suggs
Audio Mixer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Alaia D’Alessandro, Scott Holpainen, Ettie Wahl
Editor: Scott Holpainen

https://billywoods.bandcamp.com/album/maps
http://kexp.org

## Billy Woods & Kenny Segal - Soft Landing (Live on KEXP)
 - [https://www.youtube.com/watch?v=cFdjE8ipDnE](https://www.youtube.com/watch?v=cFdjE8ipDnE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-06-30T11:00:33+00:00

http://KEXP.ORG presents Billy Woods & Kenny Segal performing “Soft Landing” live in the KEXP studio. Recorded May 16, 2023

Billy Woods - Vocals
Kenny Segal - Samplers

Host: Larry Mizell, Jr.
Audio Engineers: Kevin Suggs
Audio Mixer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Alaia D’Alessandro, Scott Holpainen, Ettie Wahl
Editor: Scott Holpainen

https://billywoods.bandcamp.com/album/maps
http://kexp.org

## Billy Woods & Kenny Segal - FaceTime (Live on KEXP)
 - [https://www.youtube.com/watch?v=D207v0m2oao](https://www.youtube.com/watch?v=D207v0m2oao)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-06-30T11:00:15+00:00

http://KEXP.ORG presents Billy Woods & Kenny Segal performing “FaceTime" live in the KEXP studio. Recorded May 16, 2023

Billy Woods - Vocals
Kenny Segal - Samplers

Host: Larry Mizell, Jr.
Audio Engineers: Kevin Suggs
Audio Mixer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Alaia D’Alessandro, Scott Holpainen, Ettie Wahl
Editor: Scott Holpainen

https://billywoods.bandcamp.com/album/maps
http://kexp.org

## Billy Woods & Kenny Segal - Bad Dreams Are Only Dreams (Live on KEXP)
 - [https://www.youtube.com/watch?v=AdshUHONzl8](https://www.youtube.com/watch?v=AdshUHONzl8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-06-30T11:00:08+00:00

http://KEXP.ORG presents Billy Woods & Kenny Segal performing “Bad Dreams Are Only Dreams” live in the KEXP studio. Recorded May 16, 2023

Billy Woods - Vocals
Kenny Segal - Samplers

Host: Larry Mizell, Jr.
Audio Engineers: Kevin Suggs
Audio Mixer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Alaia D’Alessandro, Scott Holpainen, Ettie Wahl
Editor: Scott Holpainen

https://billywoods.bandcamp.com/album/maps
http://kexp.org

