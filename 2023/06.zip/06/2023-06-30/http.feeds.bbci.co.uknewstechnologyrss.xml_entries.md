# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Sky Mobile and Giffgaff customers suffer outage
 - [https://www.bbc.co.uk/news/business-66071631?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-66071631?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-06-30T16:50:20+00:00

The networks both confirm users reporting problems with their mobile phone connection.

## Dutch to restrict chip equipment exports amid US pressure
 - [https://www.bbc.co.uk/news/business-66063594?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-66063594?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-06-30T10:25:04+00:00

The Dutch government said the decision was taken on "national security grounds".

## Can Canada make big tech pay for news?
 - [https://www.bbc.co.uk/news/world-us-canada-66056742?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-66056742?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-06-30T01:26:44+00:00

The country is the latest front in a fight that analysts say has big stakes for news - and democracy.

