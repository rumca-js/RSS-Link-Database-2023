# Source:Epoch times world, URL:https://www.theepochtimes.com/c-world/feed/, language:en-US

## Nearly 20% of Canadian Small Businesses Risk Closing if COVID Loan Deadline Not Extended: Industry Group
 - [https://www.theepochtimes.com/nearly-20-of-canadian-small-businesses-risk-closing-if-covid-loan-deadline-not-extended-industry-group_5340818.html](https://www.theepochtimes.com/nearly-20-of-canadian-small-businesses-risk-closing-if-covid-loan-deadline-not-extended-industry-group_5340818.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-18 21:54:07+00:00

A storefront on Roncesvalles Avenue displays a "for lease" sign as part of a protest against the Ontario government's pandemic lockdown rules, in Toronto on Nov. 24, 2020. (The Canadian Press/Jody White)

## Mandatory Masking to End in Alberta Hospitals, Health-Care Facilities
 - [https://www.theepochtimes.com/mandatory-masking-to-end-in-alberta-hospitals-health-care-facilities_5340748.html](https://www.theepochtimes.com/mandatory-masking-to-end-in-alberta-hospitals-health-care-facilities_5340748.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-18 20:55:17+00:00

Respiratory therapist Flor Guevara repositions a patient suffering from COVID-19, with the help of other health-care workers, at Humber River Hospital's intensive care unit in Toronto on April 29, 2021. (Cole Burston/AFP via Getty Images)

## Justice Minister Lametti Says Ottawa Open to Outlawing Residential School Denialism
 - [https://www.theepochtimes.com/justice-minister-lametti-says-ottawa-open-to-outlawing-residential-school-denialism_5340655.html](https://www.theepochtimes.com/justice-minister-lametti-says-ottawa-open-to-outlawing-residential-school-denialism_5340655.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-18 19:13:07+00:00

Indigenous artists from across Canada perform at St. Peter's Square in the Vatican City on April 1, 2022. Pope Francis on that day made a historic apology to indigenous peoples for the Catholic-run Indian residential schools in Canada. (AP Photo/Alessandra Tarantino)

## Philippine Ferry Catches Fire at Sea, All 120 People Aboard Rescued
 - [https://www.theepochtimes.com/philippine-ferry-catches-fire-at-sea-all-120-people-aboard-rescued_5340575.html](https://www.theepochtimes.com/philippine-ferry-catches-fire-at-sea-all-120-people-aboard-rescued_5340575.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-18 18:11:10+00:00

Coast guard personnel assist in putting out the fire on Philippine ferry M/V Esperanza Star at the waters off Panglao, Bohol province, central Philippines, on June 18, 2023. (Philippine Coast Guard via AP)

## ‘Begin to Heal’: Manitoba Community Prays for Loved Ones Who Died in Bus Crash
 - [https://www.theepochtimes.com/begin-to-heal-manitoba-community-prays-for-loved-ones-who-died-in-bus-crash_5340659.html](https://www.theepochtimes.com/begin-to-heal-manitoba-community-prays-for-loved-ones-who-died-in-bus-crash_5340659.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-18 17:45:02+00:00

A woman pauses after lighting a candle before Sunday service at St. George's Ukrainian Orthodox Church, in Dauphin, Man., on June 18, 2023. (The Canadian Press/Darryl Dyck)

## Study Reveals Remarkable Reversal of Previously Incurable Heart Failure Condition
 - [https://www.theepochtimes.com/health/study-reveals-remarkable-reversal-of-previously-incurable-heart-failure-condition_5329011.html](https://www.theepochtimes.com/health/study-reveals-remarkable-reversal-of-previously-incurable-heart-failure-condition_5329011.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-18 17:00:31+00:00

New research challenges the conventional belief that heart failure is irreversible. (Unsplash)

## Biden Says Ukraine Can’t Join NATO Unless It Meets ‘Same Standards’
 - [https://www.theepochtimes.com/biden-says-ukraine-cant-join-nato-unless-it-meets-same-standards_5340550.html](https://www.theepochtimes.com/biden-says-ukraine-cant-join-nato-unless-it-meets-same-standards_5340550.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-18 16:22:24+00:00

President Joe Biden speaks during the National Safer Communities Summit at the University of Hartford in West Hartford, Conn., on June 16, 2023. (John Moore/Getty Images)

## While Asian Stock Markets Soar, China’s Stock Market Suffers Losses
 - [https://www.theepochtimes.com/while-asian-stock-markets-soar-chinas-stock-market-suffers-losses_5340388.html](https://www.theepochtimes.com/while-asian-stock-markets-soar-chinas-stock-market-suffers-losses_5340388.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-18 16:02:28+00:00

A Hong Kong resident walks past an electronic display board showing the Hang Seng Index, on June 14, 2023. (Bill Cox/The Epoch Times)

## Suspended Conservative MP Resigns, Triggering Another By-election
 - [https://www.theepochtimes.com/suspended-conservative-mp-resigns-triggering-another-by-election_5340549.html](https://www.theepochtimes.com/suspended-conservative-mp-resigns-triggering-another-by-election_5340549.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-18 15:35:08+00:00

Undated handout file photo of David Warburton. (UK Parliament via PA Media)

## Acupuncture Improves Outcomes for Dialysis Patients: Study
 - [https://www.theepochtimes.com/health/acupuncture-improves-outcomes-for-dialysis-patients-study_5323974.html](https://www.theepochtimes.com/health/acupuncture-improves-outcomes-for-dialysis-patients-study_5323974.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-18 15:00:28+00:00

Acupuncture proved effective for patients receiving dialysis treatment. (NiP STUDIO/Shutterstock)

## Video Emerges of Tories Mocking COVID Rules at Christmas Party During Pandemic
 - [https://www.theepochtimes.com/video-emerges-of-tories-mocking-covid-rules-at-christmas-party-during-pandemic_5340447.html](https://www.theepochtimes.com/video-emerges-of-tories-mocking-covid-rules-at-christmas-party-during-pandemic_5340447.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-18 10:56:46+00:00

The headquarters of the Conservative Party is pictured in London on March 16, 2017. (Daniel Leal /AFP via Getty Images)

## Canadian AIIB Executive’s Resignation Reveals CCP’s Manipulation of Investment Bank, Spread of Toxic Marxist Culture
 - [https://www.theepochtimes.com/canadian-aiib-executives-resignation-reveals-ccps-manipulation-of-investment-bank-spread-of-toxic-marxist-culture_5340373.html](https://www.theepochtimes.com/canadian-aiib-executives-resignation-reveals-ccps-manipulation-of-investment-bank-spread-of-toxic-marxist-culture_5340373.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-18 10:33:51+00:00

General view of the Asian Infrastructure Investment Bank (AIIB) building in Beijing, China, on Jan. 13, 2016. (VCG via Getty Images)

## Australian PM Announces $2 Billion in Social Housing Investments
 - [https://www.theepochtimes.com/australian-pm-announces-2-billion-in-social-housing-investments_5340409.html](https://www.theepochtimes.com/australian-pm-announces-2-billion-in-social-housing-investments_5340409.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-18 09:44:12+00:00

Australian Prime Minister Anthony Albanese speaks to media during a press conference at the Kaarta Gar-up Lookout in Perth, Australia, on May 8, 2023. (AAP Image/Matt Jelonek)

## South Australian Pet Owners Set for Rental Rights Boost
 - [https://www.theepochtimes.com/south-australian-pet-owners-set-for-rental-rights-boost_5340417.html](https://www.theepochtimes.com/south-australian-pet-owners-set-for-rental-rights-boost_5340417.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-18 07:24:53+00:00

A cat waiting to be adopted looks out of its cage at the Royal Society for the Prevention of Cruelty to Animals Shelter and Veterinary Hospital in Sydney, Australia, on April 1, 2020. (Peter Parks/AFP via Getty Images)

## Public Housing in Inner Sydney to Undergo Redevelopment
 - [https://www.theepochtimes.com/public-housing-in-inner-sydney-to-undergo-redevelopment_5340315.html](https://www.theepochtimes.com/public-housing-in-inner-sydney-to-undergo-redevelopment_5340315.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-18 04:29:17+00:00

A general view of residential and business property from the suburb of Kirribilli in Sydney, Australia, on May 8, 2021. (Lisa Maree Williams/Getty Images)

## Military Investigates Sexual Misconduct Allegation Against Snowbirds Pilot
 - [https://www.theepochtimes.com/military-investigates-sexual-misconduct-allegation-against-snowbirds-pilot_5340357.html](https://www.theepochtimes.com/military-investigates-sexual-misconduct-allegation-against-snowbirds-pilot_5340357.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-18 03:41:50+00:00

The Canadian Forces Snowbirds air demonstration team fly over English Bay as part of the Celebration of Light fireworks festival, in Vancouver, on July 27, 2022. (The Canadian Press/Darryl Dyck)

## Residents and Tourists Alike Excited for the Return of the Montreal Grand Prix
 - [https://www.theepochtimes.com/residents-and-tourists-alike-excited-for-the-return-of-the-montreal-grand-prix_5340354.html](https://www.theepochtimes.com/residents-and-tourists-alike-excited-for-the-return-of-the-montreal-grand-prix_5340354.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-18 03:38:58+00:00

Race fans walk through pit lane during the open house at the Canadian Grand Prix June 15, 2023, in Montreal. (The Canadian Press/Ryan Remiorz)

## Unique Kelp Puts Tasmania’s King Island on World Map
 - [https://www.theepochtimes.com/unique-kelp-puts-tasmanias-king-island-on-world-map_5340312.html](https://www.theepochtimes.com/unique-kelp-puts-tasmanias-king-island-on-world-map_5340312.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-18 03:30:24+00:00

A kelp line is hauled up to the boat as it floats on the water in Duxbury, Mass., on May 9, 2023. (Joseph Prezioso/AFP via Getty Images)

## More New Dads Seek Help for Mental Health Concerns
 - [https://www.theepochtimes.com/more-new-dads-seek-help-for-mental-health-concerns_5340310.html](https://www.theepochtimes.com/more-new-dads-seek-help-for-mental-health-concerns_5340310.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-18 02:15:27+00:00

A father and his young son walk past shuttered businesses in the CBD of Lismore, New South Wales in Australia on May 15, 2022. (Dan Peled/Getty Images)

## Sudan Officials Say Airstrike Killed 17 People, Including 5 Children, in Capital Khartoum
 - [https://www.theepochtimes.com/sudan-officials-say-airstrike-killed-17-people-including-5-children-in-capital-khartoum_5339901.html](https://www.theepochtimes.com/sudan-officials-say-airstrike-killed-17-people-including-5-children-in-capital-khartoum_5339901.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-18 01:19:13+00:00

People prepare food in a neighborhood in Khartoum, Sudan, on June 16, 2023. (AP Photo)

## ‘Down but Never Out’: Dutton Rallies Party As Senator Van Resigns
 - [https://www.theepochtimes.com/down-but-never-out-dutton-rallies-party-as-senator-van-resigns_5339534.html](https://www.theepochtimes.com/down-but-never-out-dutton-rallies-party-as-senator-van-resigns_5339534.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-06-18 01:14:47+00:00

Leader of the Opposition Peter Dutton at a press conference at Parliament House in Canberra, Australia, on March 14, 2023. (AAP Image/Mick Tsikas)

