# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Wielki finał! 500+ na hulajnogach #8
 - [https://www.youtube.com/watch?v=VExr2etisOo](https://www.youtube.com/watch?v=VExr2etisOo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2023-06-18 18:04:18+00:00

To już ósmy, ostatni odcinek wielkiej hulajnogowej przygody!

Nasza strona, na której możecie zobaczyć całą trasę hulajnogową: https://www.500plusnahulajnogach.pl
Tutaj dowiecie się więcej o samodzielnej budowie strony - https://www.odoo.com/r/LZAi 

Limitowana przypinka tej serii - https://znosne.pl/

Testowane hulajnogi:
Xiaomi Mi Electric Scooter 3 - https://bit.ly/4371blg
Xiaomi Mi Electric Scooter 4 Pro - https://bit.ly/3X0Lt9k
Tibo Epic+ - https://bit.ly/3X6thv2

Odpadły:
Motus 10 Lite - https://bit.ly/45n95bU
Kugoo Kirin S1 Pro - https://bit.ly/3WrYw3A

