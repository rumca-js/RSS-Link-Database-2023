# Source:The Washington Post - World, URL:https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36, language:en-US

## Deaths rise in India as temperatures also soar in latest heat wave
 - [https://www.washingtonpost.com/world/2023/06/18/india-heat-wave-bihar-uttar-pradesh/](https://www.washingtonpost.com/world/2023/06/18/india-heat-wave-bihar-uttar-pradesh/)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-06-18 22:35:24+00:00

Soaring temperatures in India's northeast brought scorching heat and an influx of patients to local hospitals.

## As Israel seeks West Bank expansion, a controversial outpost is revived
 - [https://www.washingtonpost.com/world/2023/06/17/israel-homesh-west-bank-palestinians/](https://www.washingtonpost.com/world/2023/06/17/israel-homesh-west-bank-palestinians/)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-06-18 06:00:50+00:00

The drive to restore Homesh over U.S. objections is being driven by far-right members of Israel’s new government.

## Ukraine live briefing: Putin meets with African leaders as Kyiv’s counteroffensive presses on in the south
 - [https://www.washingtonpost.com/world/2023/06/18/russia-ukraine-war-news/](https://www.washingtonpost.com/world/2023/06/18/russia-ukraine-war-news/)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-06-18 05:29:21+00:00

The Ukrainian counteroffensive continues to yield small gains, officials say. Russia rebutted a peace proposal by African leaders by blaming Kyiv and the West.

## Russia aims to defeat counteroffensive with mines, artillery and aviation
 - [https://www.washingtonpost.com/world/2023/06/18/russia-counteroffensive-ukraine-war-aviation/](https://www.washingtonpost.com/world/2023/06/18/russia-counteroffensive-ukraine-war-aviation/)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2023-06-18 05:00:03+00:00

Moscow is counting on air superiority, including attack helicopters and self-detonating drones, as well as fortified land defenses to repel Ukraine's counterattack.

