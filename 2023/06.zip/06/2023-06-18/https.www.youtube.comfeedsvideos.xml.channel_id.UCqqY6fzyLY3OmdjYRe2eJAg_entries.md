# Source:Roosevelt, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqqY6fzyLY3OmdjYRe2eJAg, language:en-US

## luna - june 21
 - [https://www.youtube.com/watch?v=8ECyLWyQDaw](https://www.youtube.com/watch?v=8ECyLWyQDaw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqqY6fzyLY3OmdjYRe2eJAg
 - date published: 2023-06-18 15:37:12+00:00



