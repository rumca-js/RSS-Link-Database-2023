# Source:Solid jj, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCEq_Dr1GHvnNPQNfgOzhZ8Q, language:en-US

## Happy Father’s Day, John Lennon
 - [https://www.youtube.com/watch?v=6Ve1JkKsZC8](https://www.youtube.com/watch?v=6Ve1JkKsZC8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCEq_Dr1GHvnNPQNfgOzhZ8Q
 - date published: 2023-06-18 18:49:00+00:00



