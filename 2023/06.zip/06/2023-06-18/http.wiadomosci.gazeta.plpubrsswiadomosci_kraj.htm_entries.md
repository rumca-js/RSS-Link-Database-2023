# Source:wiadomości.gazeta.pl, URL:http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm, language:pl-PL

## Wszedł do kościoła i przebrał się za księdza. Nakrył go proboszcz. 24-latek już w rękach policji
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29882836,przebieraniec-kleptoman-zakradl-sie-do-kosciola-w-zamosciu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29882836,przebieraniec-kleptoman-zakradl-sie-do-kosciola-w-zamosciu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-06-18 20:57:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/fe/7f/1c/z29882878M,Zamosc--Policja-zatrzymala-24-latka--ktory-ukradl-.jpg" vspace="2" />Nietypowa i wielowątkowa historia policyjna z Zamościa - kleptoman, który kradł swoim ofiarom między innymi ubrania, wpadł w ręce policji. O grasującym w mieście mężczyźnie poinformował służby proboszcz miejscowej parafii. Duchownych nakrył bowiem 24-latka w kościele.

## Gdynia. Napad z bronią na salon gier. Policja poszukuje napastników [ZDJĘCIA]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29881855,gdynia-napad-z-bronia-na-salon-gier-policja-poszukuje-napastnikow.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29881855,gdynia-napad-z-bronia-na-salon-gier-policja-poszukuje-napastnikow.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-06-18 14:40:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/b0/7f/1c/z29882032M,Gdynia--Napad-z-bronia-na-salon-gier--Policja-posz.jpg" vspace="2" />Policja opublikowała zdjęcia napastników, którzy napadli na salon gier przy ulicy Wielkopolskiej w Gdyni. Wszystkie osoby, które rozpoznają mężczyzn, mogą zgłaszać się do policji w Trójmieście lub skontaktować się ze służbami pod numerem alarmowym 112.

## Wielkopolskie. Zagryziono sześć reniferów. "Winnych będziemy szukać aż do skutku"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29881561,wielkopolskie-szesc.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29881561,wielkopolskie-szesc.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-06-18 12:59:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e9/7f/1c/z29881577M,Renifer.jpg" vspace="2" />- Kiedy zaalarmowali nas teściowie, którzy spędzali majówkę w jednym z domków, nie spodziewaliśmy się, że to, co zobaczymy za chwilę będzie wyglądało jak sceny z horroru - powiedział w rozmowie z serwisem slupca.pl Aleksander Dyczek, właściciel agroturystyki Arendel.

## Samolot z delegacją RPA odleciał z Warszawy. Stał na Okęciu od czwartku. Wszystko przez broń na pokładzie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29881454,samolot-z-delegacja-rpa-odlecial-z-warszawy-udalo-sie-to-po.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29881454,samolot-z-delegacja-rpa-odlecial-z-warszawy-udalo-sie-to-po.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-06-18 11:57:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/9b/7f/1c/z29881499M,Lotnisko-im--Fryderyka-Chopina-w-Warszawie.jpg" vspace="2" />Samolot wraz z członkami delegacji prezydenta RPA Cyrila Ramaphosy odleciał z warszawskiego lotniska im. Fryderyka Chopina w niedzielę - przekazała w rozmowie z PAP rzeczniczka lotniska Anna Dermont.

## Zaskakujące słowa nowego metropolity katowickiego. Mówił o "dwóch Polskach w Polsce"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29881080,kazanie-nowego-metropolity-katowickiego-zaskoczylo-wiernych.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29881080,kazanie-nowego-metropolity-katowickiego-zaskoczylo-wiernych.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-06-18 10:02:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/06/7f/1c/z29881094M,Abp-Adrian-Galbas.jpg" vspace="2" />Abp Adrian Galbas wygłosił w sobotę swoje pierwsze kazanie, w którym mówił o podzielonym społeczeństwie w Polsce. - Wszyscy pewnie bolejemy z powodu dwóch Polsk w Polsce. Coraz bardziej oddalonych od siebie, coraz bardziej napiętych - mówił nowy metropolita.

## Zaginięcie Polki w Grecji. Opublikowano nagranie, na którym po raz ostatni widać Anastazję
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29880958,sprawa-27-letniej-anastazji-z-kos-opublikowano-nagrania-z-ostatnich.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29880958,sprawa-27-letniej-anastazji-z-kos-opublikowano-nagrania-z-ostatnich.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-06-18 09:04:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e0/7f/1c/z29881056M.jpg" vspace="2" />27-letnia Anastazja Rubińska zaginęła w poniedziałek 12 czerwca i do tej pory nie została odnaleziona. W sieci pojawiły się nagrania z dnia, w którym ostatnio widziano Polkę.

## Ojciec Polki zaginionej w Grecji: Bardzo podejrzane, jakby zrozumiała, że coś jej zagraża
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29880849,ojciec-polki-zaginionej-w-grecji-bardzo-podejrzane-jakby-zrozumiala.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29880849,ojciec-polki-zaginionej-w-grecji-bardzo-podejrzane-jakby-zrozumiala.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-06-18 07:22:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/48/7f/1c/z29880904M,Na-Kos-zaginela-27-letnia-Anastazja.jpg" vspace="2" />Anastazja Rubińska zaginęła w poniedziałek. Poszukiwania kobiety trwają, tymczasem ojciec 27-latki przyznał w rozmowie z "Super Expressem", że cała rodzina bardzo martwi się jej zaginięciem. - Bardzo podejrzane jest, że podczas jazdy dwa razy wysyłała swoją lokalizację do narzeczonego - zwrócił uwagę mężczyzna.

## IMGW ostrzega przed burzami z gradem. Wydano żółte alerty dla ośmiu województw
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29880771,imgw-ostrzega-przed-burzami-z-gradem-wydano-zolte-alerty-dla.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29880771,imgw-ostrzega-przed-burzami-z-gradem-wydano-zolte-alerty-dla.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-06-18 05:42:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e1/7f/1c/z29880801M,Gdzie-jest-burza--Pogoda-na-18-czerwca.jpg" vspace="2" />Instytut Meteorologii i Gospodarki Wodnej ostrzega przed burzami z gradem. Ostrzeżenia pierwszego, najniższego stopnia wydano dla ośmiu województw. Miejscami wystąpią silne opady deszczu, a nawet grad oraz silny wiatr. Sprawdź, gdzie jest burza.

