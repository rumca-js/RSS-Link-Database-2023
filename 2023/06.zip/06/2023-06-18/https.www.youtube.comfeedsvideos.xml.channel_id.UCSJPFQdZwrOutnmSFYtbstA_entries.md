# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## The Flash - A Hot Mess
 - [https://www.youtube.com/watch?v=djvkQBPHWGo](https://www.youtube.com/watch?v=djvkQBPHWGo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2023-06-18 17:15:02+00:00

The Flash, starring Ezra Miller, Michael Keaton and Ben Affleck, was slated to be the biggest DC movie of the year. Now its shaping up to be the biggest flop. 

Want to help support this channel? 
Check out my books on Amazon: https://www.amazon.com/Will-Jordan/e/B00BCO7SA8/ref=dp_byline_cont_pop_ebooks_1
Subscribe on Patreon: https://www.patreon.com/TheCriticalDrinker
Subscribe on Subscribestar: https://www.subscribestar.com/the-critical-drinker

