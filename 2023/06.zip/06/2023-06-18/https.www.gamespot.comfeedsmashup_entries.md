# Source:GameSpot, URL:https://www.gamespot.com/feeds/mashup, language:en-US

## How Street Fighter IV SAVED 2D Fighting Games (Ft. Maximilian Dood)
 - [https://www.gamespot.com/videos/how-street-fighter-iv-saved-2d-fighting-games-ft-maximilian-dood/2300-6461701/](https://www.gamespot.com/videos/how-street-fighter-iv-saved-2d-fighting-games-ft-maximilian-dood/2300-6461701/)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2023-06-18 15:00:00+00:00

<img height="480" src="https://www.gamespot.com/a/uploads/square_medium/1352/13527689/4154261-how-it-saved-streetfighter4.jpg" width="480" /> After Street Fighter II released in in 1991, it caused a fighting game explosion, both in arcades and in home consoles. But, as the decade ended, and arcades were failing, so too were 2D Fighting games. This is how Street Fighter IV completely revitalized the genre.

