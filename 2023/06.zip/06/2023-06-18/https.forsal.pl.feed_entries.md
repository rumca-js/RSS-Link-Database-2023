# Source:Forsal.pl, URL:https://forsal.pl/.feed, language:pl-PL

## Robotyczni policjanci rozpoczęli patrol na lotnisku w Singapurze
 - [https://forsal.pl/lifestyle/technologie/artykuly/8735854,robotyczni-policjanci-rozpoczeli-patrol-na-lotnisku-w-singapurze.html](https://forsal.pl/lifestyle/technologie/artykuly/8735854,robotyczni-policjanci-rozpoczeli-patrol-na-lotnisku-w-singapurze.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-18 20:11:19+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/K33ktkuTURBXy8wMGYxYTgxYi1iNDUzLTRlNDQtYTY1OC03ODE5Yzg4ZDI3MDIuanBlZ5GTBc0BHcyg" />Do patrolowania lotniska Changi w Singapurze - po pięciu latach badań i prób - skierowano dwa policyjne roboty - podała w niedzielę telewizja CNN.

## Podwyżki w budżetówce, legalna aborcja, darmowa antykoncepcja, świeckie państwo. Lewica przedstawia swoje rekomendacje i "Raport o Stanie Państwa"
 - [https://forsal.pl/gospodarka/polityka/artykuly/8735584,podwyzki-w-budzetowce-legalna-aborcja-darmowa-antykoncepcja-swiecki.html](https://forsal.pl/gospodarka/polityka/artykuly/8735584,podwyzki-w-budzetowce-legalna-aborcja-darmowa-antykoncepcja-swiecki.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-18 16:56:03+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/5M-ktkuTURBXy84Nzc5NGIxZS1iZTgzLTQ4MDQtODMwMi05ZTdkYTYzZDRkMzguanBlZ5GTBc0BHcyg" />Politycy Lewicy zaprezentowali w niedzielę w Warszawie &quot;Raport o Stanie Państwa&quot;. Wskazali w nim błędy i zaniechania rządzących oraz mówili o swoich rekomendacjach. Lewica chce m.in. podwyżek w budżetówce, legalnej aborcji do 12 tyg., darmowej antykoncepcji oraz świeckiego państwa. Zapowiedziano także m.in. 35-godzinny tydzień pracy.

## W Wielkiej Brytanii instytucje nie będą mogły bojkotować izraelskich towarów
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8735581,w-wielkiej-brytanii-instytucje-nie-beda-mogly-bojkotowac-izraelskich-t.html](https://forsal.pl/swiat/aktualnosci/artykuly/8735581,w-wielkiej-brytanii-instytucje-nie-beda-mogly-bojkotowac-izraelskich-t.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-18 16:47:49+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/c_zktkuTURBXy80NWFlNzljZS0yODdhLTRiNmUtYTU0Ni1jYzIxMTA4MzdkMzkuanBlZ5GTBc0BHcyg" />Brytyjski rząd przedstawi w poniedziałek projekt ustawy zakazującej wszystkim organom publicznym prowadzenia własnych kampanii bojkotu lub zniechęcania do inwestycji w innych krajach i terytoriach, w tym w Izraelu – zapowiedział w niedzielę minister ds. wyrównywania szans i społeczności Michael Gove.

## Koronawirus w Polsce: 3 zakażenia, nie było przypadków śmiertelnych [DANE Z 18.06]
 - [https://forsal.pl/artykuly/1458115,koronawirus-w-polsce-3-zakazenia-nie-bylo-przypadkow-smiertelnych-d.html](https://forsal.pl/artykuly/1458115,koronawirus-w-polsce-3-zakazenia-nie-bylo-przypadkow-smiertelnych-d.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-18 15:26:55+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/3QYktkuTURBXy9lNjE1ZGFlZC02OTg5LTQzNzItOTg5OS1jZWEzOWVhODg4OWYuanBlZ5GTBc0BHcyg" />Minionej doby badania potwierdziły 3 zakażenia koronawirusem w tym w ponowne. Z powodu COVID-19 nie zmarł żaden pacjent – poinformowano w niedzielę na stronach rządowych. Wykonano 865 testów w kierunku SARS-CoV-2. W ostatnim tygodniu (od 8 do 14 czerwca) było o ponad 30 proc. zakażeń mniej niż tydzień wcześniej.

## AI, ekologia i podatki. Im więcej automatyzacji, tym większa degradacja planety [FELIETON]
 - [https://forsal.pl/biznes/ekologia/artykuly/8734719,ai-ekologia-i-podatki-im-wiecej-automatyzacji-tym-wieksza-degradacj.html](https://forsal.pl/biznes/ekologia/artykuly/8734719,ai-ekologia-i-podatki-im-wiecej-automatyzacji-tym-wieksza-degradacj.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-18 14:03:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/f2YktkuTURBXy8yODM0NGFkMC1iOTBiLTQwNGQtODNiMS00NjQ5ODg0Y2FjZmQuanBlZ5GTBc0BHcyg" />Świat martwi się teraz rozwojem sztucznej inteligencji (AI). To najnowsze wcielenie powracającej obawy przed skutkami robotyzacji oraz automatyzacji. Wśród zagrożeń wymienia się masowe bezrobocie, bunt maszyn, zagładę rasy ludzkiej… Ale w tym zestawie dyżurnych obaw zapomina się zwykle o jednej rzeczy. Jest nią ekologia. A właściwie prosty fakt, że im więcej automatyzacji, tym większa degradacja planety oraz jej zasobów naturalnych.

## Trump uwielbia zdobywać trofea. Kobiety, znajomości, sekrety państwowe...
 - [https://forsal.pl/swiat/usa/artykuly/8734691,trump-uwielbia-zdobywac-trofea-kobiety-znajomosci-sekrety-panstwowe.html](https://forsal.pl/swiat/usa/artykuly/8734691,trump-uwielbia-zdobywac-trofea-kobiety-znajomosci-sekrety-panstwowe.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-18 14:02:21+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/qTVktkuTURBXy80ZTQyNjZiYi1mNTVlLTQ5YWUtOGUyYi0wZGMwZDZkYWVkMWMuanBlZ5GTBc0BHcyg" />Współpracownicy Trumpa mówili, że ich szef uwielbia zdobywać trofea, żeby potem się z nimi obnosić. Mogły to być kobiety, celebryckie znajomości, okładki czasopism. Albo sekrety państwowe.

## W Belgii i Francji firmy obniżają ceny na skutek interwencji rządów. Holandia nie pójdzie w tę stronę
 - [https://forsal.pl/gospodarka/aktualnosci/artykuly/8735504,w-belgii-i-francji-firmy-obnizaja-ceny-na-skutek-interwencji-rzadow-h.html](https://forsal.pl/gospodarka/aktualnosci/artykuly/8735504,w-belgii-i-francji-firmy-obnizaja-ceny-na-skutek-interwencji-rzadow-h.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-18 10:42:05+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/bzuktkuTURBXy9iMTE0N2Y5ZC04OTZhLTRkMzItYWYyMC04YzhlN2M1ZTE0NWMuanBlZ5GTBc0BHcyg" />Holandia nie zamierza iść w ślady Belgii i Francji i nie będzie interweniować w sprawie wysokich cen artykułów spożywczych w supermarketach - poinformował w niedzielę portal NU, cytując rozmowę z holenderską minister gospodarki Micky Adriaansens.

## Francja nie chce, żeby Brytyjczyk został sekretarzem generalnym NATO. "To powinien być ktoś z UE"
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8735503,francja-nie-chce-zeby-brytyjczyk-zostal-sekretarzem-generalnym-nato.html](https://forsal.pl/swiat/unia-europejska/artykuly/8735503,francja-nie-chce-zeby-brytyjczyk-zostal-sekretarzem-generalnym-nato.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-18 10:35:20+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/LsiktkuTURBXy8yMDE4Y2RhYS1jOGIxLTQ2YzctODI3Yi1hYWM0MzUzNmYxZWIuanBlZ5GTBc0BHcyg" />Prezydent Francji Emmanuel Macron próbuje zablokować kandydaturę brytyjskiego ministra obrony Bena Wallace'a na stanowisko nowego sekretarza generalnego NATO, naciskając, by objął je przedstawiciel jakiegoś kraju Unii Europejskiej - podał w niedzielę &quot;The Sunday Telegraph&quot;.

## Po weekendzie szykujmy się na burze i upały
 - [https://forsal.pl/lifestyle/aktualnosci/artykuly/8735481,po-weekendzie-szykujmy-sie-na-burze-i-upaly.html](https://forsal.pl/lifestyle/aktualnosci/artykuly/8735481,po-weekendzie-szykujmy-sie-na-burze-i-upaly.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-18 07:54:47+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ohGktkuTURBXy9kMTc5NWZmYS04ZjZjLTRiZGQtYjNkMC0xOGU0Y2M1Yjc3NmMuanBlZ5GTBc0BHcyg" />Upały wkraczają nad Polskę w poniedziałek. We wtorek będzie już ponad 30 st. Celsjusza. Wytchnienie przyniesie tylko noc. W środę gwałtowne burze – prognozuje synoptyk IMGW Jakub Gawron.

## Rekordowa nadwyżka handlowa w relacji do PKB. Mamy lepszy wynik niż Niemcy
 - [https://forsal.pl/gospodarka/pkb/artykuly/8735480,rekordowa-nadwyzka-handlowa-w-relacji-do-pkb-mamy-lepszy-wynik-niz-ni.html](https://forsal.pl/gospodarka/pkb/artykuly/8735480,rekordowa-nadwyzka-handlowa-w-relacji-do-pkb-mamy-lepszy-wynik-niz-ni.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-18 07:51:03+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/1z2ktkuTURBXy8zNDMwZjU0OS03NjgyLTQ3MzAtYjlkOC04ZGQ1NGNhM2NhNGEuanBlZ5GTBc0BHcyg" />W pierwszym kwartale 2023 r. nadwyżka handlowa w relacji do PKB wzrosła do rekordowego poziomu 6,7 proc. – stwierdził w raporcie główny ekonomista PZU Dawid Pachucki. Ocenił, że to wynik lepszy od notowanego przez Niemcy.

## Od Teksasu do Florydy rekordowe upały. Nawet 44 stopnie Celsjusza
 - [https://forsal.pl/swiat/usa/artykuly/8735477,od-teksasu-do-florydy-rekordowe-upaly-nawet-44-stopnie-celsjusza.html](https://forsal.pl/swiat/usa/artykuly/8735477,od-teksasu-do-florydy-rekordowe-upaly-nawet-44-stopnie-celsjusza.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-18 07:43:52+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/bF8ktkuTURBXy9jYmVjNDY5YS1iMzM3LTQyY2MtODA4NC01MjQ1ZDMzMDk3ZjkuanBlZ5GTBc0BHcyg" />Rekordowo wysokie temperatury utrzymują się w pasie stanów południa USA od Teksasu do Florydy, wzdłuż wybrzeży Zatoki Meksykańskiej. Władze udostępniają specjalne chłodzone pomieszczenia dla osób pozbawionych energii elektrycznej z powodu częstych awarii przeciążonej sieci.

## Sudan: 72-godzinne zawieszenie broni
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8735472,sudan-72-godzinne-zawieszenie-broni.html](https://forsal.pl/swiat/aktualnosci/artykuly/8735472,sudan-72-godzinne-zawieszenie-broni.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-18 07:38:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/mZuktkuTURBXy85MTNkMzJiNy0wYWU0LTQ5ODItYTliNi1hOGRkMGY4N2VmMGEuanBlZ5GTBc0BHcyg" />Sudańska armia rządowa i organizacje paramilitarne skupione w Siłach Szybkiego Wsparcia (RSF) uzgodniły, według mediatorów saudyjskich i amerykańskich, 72-godzinne zawieszenie broni w trwającej od połowy kwietnia wojnie domowej. Ma obowiązywać od niedzieli. Tymczasem w sobotę walki w rejonie Chartumu trwały ze zdwojoną zaciętością.

## Najlepszy od marca tydzień na Wall Street zakończony lekkimi spadkami
 - [https://forsal.pl/finanse/gielda/artykuly/8735469,najlepszy-od-marca-tydzien-na-wall-street-zakonczony-lekkimi-spadkami.html](https://forsal.pl/finanse/gielda/artykuly/8735469,najlepszy-od-marca-tydzien-na-wall-street-zakonczony-lekkimi-spadkami.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-18 07:33:43+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/zC2ktkuTURBXy8wOTYyZjJjNi1mNTU2LTQwOTEtYTBlNy00MGM5OGJjZDcwOTEuanBlZ5GTBc0BHcyg" />Piątkowa sesja na Wall Street zakończyła się lekkimi spadkami głównych indeksów, ale i tak dla S&amp;amp;P 500 i Nasdaq to był najlepszy tydzień od marca 2023 roku.

## Dreamliner PLL LOT: Pierwszy rejs trasą polarną z Tokio do Warszawy wystartował w sobotę
 - [https://forsal.pl/transport/lotnictwo/artykuly/8735467,dreamliner-pll-lot-pierwszy-rejs-trasa-polarna-z-tokio-do-warszawy-wy.html](https://forsal.pl/transport/lotnictwo/artykuly/8735467,dreamliner-pll-lot-pierwszy-rejs-trasa-polarna-z-tokio-do-warszawy-wy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-18 07:28:28+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/kecktkuTURBXy84NDJlMTA0YS02ZGIxLTQ2M2YtODEyZC0xZGVjNTJkOWEyZjguanBlZ5GTBc0BHcyg" />Pierwszy Dreamliner PLL LOT wystartował z Tokio do Warszawy trasą polarną - poinformował w sobotę wieczorem na Twitterze rzecznik prasowy LOT Krzysztof Moczulski. W chwili nadania depeszy samolot LOT-u o numerze SP-LSF minął Cieśninę Beringa i znajduje się nad Morzem Czukockim.

## Rekordowa epidemia dengi w Peru. Zmarło ponad 200 osób
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8735463,rekordowa-epidemia-dengi-w-peru-zmarlo-ponad-200-osob.html](https://forsal.pl/swiat/aktualnosci/artykuly/8735463,rekordowa-epidemia-dengi-w-peru-zmarlo-ponad-200-osob.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-18 07:22:38+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/vcxktkuTURBXy9kNjc1ZDI3ZC0zYTkzLTQxYWItODk2OC02MmM3YzQ3OTAzYTguanBlZ5GTBc0BHcyg" />Peru zmaga się z wielką epidemią dengi - choroby wirusowej przenoszonej przez komary Aedes aegypti zwane komarami tygrysimi. Ministerstwo zdrowia w Limie poinformowało, że od początku br. odnotowano 130 tys. przypadków infekcji i ponad 200 zgonów.

## W Bolonii zdejmij nogę z gazu. Pierwsze duże miasto wprowadza mocne ograniczenie dozwolonych prędkości
 - [https://forsal.pl/transport/aktualnosci/artykuly/8735459,w-bolonii-zdejmij-noge-z-gazu-pierwsze-duze-miasto-wprowadza-mocne-og.html](https://forsal.pl/transport/aktualnosci/artykuly/8735459,w-bolonii-zdejmij-noge-z-gazu-pierwsze-duze-miasto-wprowadza-mocne-og.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-18 07:13:12+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/uuWktkuTURBXy9hODIzZGUxMC1jY2IzLTQ1MGQtOGZhYS1iNTU4NTM5NjQyZTQuanBlZ5GTBc0BHcyg" />Bolonia będzie pierwszym dużym włoskim miastem, w którym zacznie obowiązywać ograniczenie prędkości do 30 kilometrów na godzinę - ogłosiły w sobotę władze, zapowiadając, że nowe przepisy wejdą w życie 1 lipca. Celem, wyjaśniono, jest to, by nikt nie ginął w wypadkach drogowych.

## Składki na ubezpieczenie domu mogą wzrosnąć. Ubezpieczyciele z Niemiec wskakują przyczyny
 - [https://forsal.pl/nieruchomosci/aktualnosci/artykuly/8735183,skladki-na-ubezpieczenie-domu-moga-wzrosnac-ubezpieczyciele-z-niemiec.html](https://forsal.pl/nieruchomosci/aktualnosci/artykuly/8735183,skladki-na-ubezpieczenie-domu-moga-wzrosnac-ubezpieczyciele-z-niemiec.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-18 07:04:45+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/uXuktkuTURBXy80NzhkNTRiNC0wY2Y1LTQ1ZTUtOWI5ZS0wODE0OWUzYmM2MjEuanBlZ5GTBc0BHcyg" />Zmiany klimatu mogą doprowadzić do „gwałtownego wzrostu składek za ubezpieczenie” nieruchomości – pisze niemiecki serwis „Tagesschau”.

## Marzenie o broni ostatecznej. "Już nie żyjesz. Historia bombardowań" [RECENZJA]
 - [https://forsal.pl/swiat/artykuly/8734695,marzenie-o-broni-ostatecznej-juz-nie-zyjesz-historia-bombardowan-.html](https://forsal.pl/swiat/artykuly/8734695,marzenie-o-broni-ostatecznej-juz-nie-zyjesz-historia-bombardowan-.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-18 07:00:17+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/aSUktkuTURBXy83NzExNDM4Yi0wNDAwLTRlNjktYTM4OC1lMmEwZDhhYzFiZjQuanBlZ5GTBc0BHcyg" />Już w XIX w. czekano z nadzieją, aż pojawi się technologiczna możliwość i biała rasa dostanie narzędzie, by wygubić „całe to bydło”.

## UE powinna zwiększyć czujność, by nie dać się ponownie zaskoczyć [OPINIA]
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8734651,ue-powinna-zwiekszyc-czujnosc-by-nie-dac-sie-ponownie-zaskoczyc-opin.html](https://forsal.pl/swiat/unia-europejska/artykuly/8734651,ue-powinna-zwiekszyc-czujnosc-by-nie-dac-sie-ponownie-zaskoczyc-opin.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-18 06:59:54+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/PPRktkuTURBXy8yYzZkMzgyNC05YTJmLTQwYWYtOGI5ZS05ODM2ODQxNTA3MTcuanBlZ5GTBc0BHcyg" />Unii Europejskiej udało się powstrzymać masową migrację. Jednak ostatnio rośnie liczba nielegalnych przekroczeń granic wspólnoty.

## Możliwe, że nastąpią oligarchizacja rynku i przejęcie AI przez grupę koncernów
 - [https://forsal.pl/lifestyle/technologie/artykuly/8734683,mozliwe-ze-nastapia-oligarchizacja-rynku-i-przejecie-ai-przez-grupe-k.html](https://forsal.pl/lifestyle/technologie/artykuly/8734683,mozliwe-ze-nastapia-oligarchizacja-rynku-i-przejecie-ai-przez-grupe-k.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-18 06:59:17+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/TjAktkuTURBXy8xMTlhYWI3OS1lNTAzLTQxZWItYjkwOS00MGRiNGIyODViNDcuanBlZ5GTBc0BHcyg" />Wbrew obawom jednych i nadziejom drugich sztuczna inteligencja jest zbyt ograniczona, by skończyć z kapitalizmem.

## TSUE pozbawia banki złudzeń. Zbliża się fala pozwów od "frankowiczów"?
 - [https://forsal.pl/finanse/aktualnosci/artykuly/8734675,tsue-pozbawia-banki-zludzen-zbliza-sie-fala-pozwow-od-frankowiczow.html](https://forsal.pl/finanse/aktualnosci/artykuly/8734675,tsue-pozbawia-banki-zludzen-zbliza-sie-fala-pozwow-od-frankowiczow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-18 06:58:44+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/XwOktkuTURBXy9lNzIyMjM1OC1jNTE2LTQxMDItYTk4Yy0wOWNjMzQ5ODJjNDcuanBlZ5GTBc0BHcyg" />Możemy się spodziewać kolejnej fali pozwów frankowiczów. A bankom odpada poważny argument za występowaniem z roszczeniami przeciwko klientom.

## Fińska lekcja atomu. Warto wyciągnąć wnioski z kosztownych doświadczeń Helsinek [OPINIA]
 - [https://forsal.pl/biznes/energetyka/artykuly/8734663,finska-lekcja-atomu-warto-wyciagnac-wnioski-z-kosztownych-doswiadczen.html](https://forsal.pl/biznes/energetyka/artykuly/8734663,finska-lekcja-atomu-warto-wyciagnac-wnioski-z-kosztownych-doswiadczen.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-06-18 06:58:14+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/uedktkuTURBXy80YjhmM2JlYS1jMzAwLTQzODMtODQxNy00NzBlM2UxMzAyZGQuanBlZ5GTBc0BHcyg" />Na razie mamy atomowe plany, a nie rozpoczęte inwestycje. Tym bardziej warto wyciągnąć wnioski z kosztownych doświadczeń Helsinek.

