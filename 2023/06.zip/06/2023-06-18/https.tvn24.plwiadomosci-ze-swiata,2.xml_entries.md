# Source:TVN24 Ze świata, URL:https://tvn24.pl/wiadomosci-ze-swiata,2.xml, language:pl-PL

## Poszukiwania 27-letniej Polki w Grecji. Odnaleziono ciało młodej kobiety
 - [https://tvn24.pl/swiat/grecja-kos-zaginiona-polka-odkryto-zwloki-mlodej-kobiety-greckie-media-to-zaginiona-polka-7180710?source=rss](https://tvn24.pl/swiat/grecja-kos-zaginiona-polka-odkryto-zwloki-mlodej-kobiety-greckie-media-to-zaginiona-polka-7180710?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-06-18 17:41:55+00:00

<img alt="Poszukiwania 27-letniej Polki w Grecji. Odnaleziono ciało młodej kobiety " src="https://tvn24.pl/najnowsze/cdn-zdjecie-q24gtm-shutterstock_1853564161-7180750/alternates/LANDSCAPE_1280" />
    Na wyspie Kos w Grecji odnaleziono ciało kobiety, którą według przypuszczeń policji może być 27-letnia Polka - podały greckie media. Zwłoki mają zostać poddane identyfikacji przez partnera kobiety. Anastazja Rubińska z Wrocławia zaginęła na wyspie w nocy z poniedziałku na wtorek, a w sprawie tej zatrzymano 32-letniego obywatela Bangladeszu. Według mediów, zwłoki miały zostać odkryte w bliskiej odległości od domu zatrzymanego.

## Ministerstwo: nie ma pieniędzy dla ratowników wodnych i górskich. "To odbije się na bezpieczeństwie ludzi"
 - [https://tvn24.pl/pomorze/ministerstwo-brak-pieniedzy-dla-ratownikow-wodnych-i-gorskich-nie-bedzie-dofinansowania-do-sprzetu-7166126?source=rss](https://tvn24.pl/pomorze/ministerstwo-brak-pieniedzy-dla-ratownikow-wodnych-i-gorskich-nie-bedzie-dofinansowania-do-sprzetu-7166126?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-06-18 10:12:49+00:00

<img alt="Ministerstwo: nie ma pieniędzy dla ratowników wodnych i górskich. " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-gy0yq9-resort-informuje-ze-nie-ma-pieniedzy-na-sprzet-dla-ratownikow-wodnych-i-gorskich-7168019/alternates/LANDSCAPE_1280" />
    Miały być nowe łodzie, skutery i drony do przeszukiwania dna. Na długiej liście sprzętu, który współfinansować miał Narodowy Fundusz Ochrony Środowiska i Gospodarki Wodnej są też mniej efektowne, ale równie potrzebne ratownikom rzeczy: nowe silniki do motorówek czy bojki pomagające wydostać się topiącym z wody. Zakupów w tym roku jednak nie będzie, bo - jak przekazała minister Anna Moskwa - dla ratowników górskich i wodnych zabrakło pieniędzy. - To odbije się na naszej skuteczności i bezpieczeństwie ludzi - alarmują ratownicy, z którymi rozmawialiśmy.

## Burza przechodzi nad Warszawą
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-burze-z-ulewa-przechodza-nad-miastem-7180245?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-burze-z-ulewa-przechodza-nad-miastem-7180245?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-06-18 10:09:29+00:00

<img alt="Burza przechodzi nad Warszawą" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-4aqewr-ulewa-w-warszawie-7180265/alternates/LANDSCAPE_1280" />
    W niedzielę przed południem Warszawa znalazła się w strefie burz i intensywnych opadów deszczu. Pada na Mokotowie i Ochocie.

