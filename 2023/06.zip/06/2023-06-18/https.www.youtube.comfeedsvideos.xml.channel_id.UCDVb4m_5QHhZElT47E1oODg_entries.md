# Source:The Dave Cullen Show, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCDVb4m_5QHhZElT47E1oODg, language:en-US

## It’s as Bad as We Feared
 - [https://www.youtube.com/watch?v=J1q5zLBb2Uo](https://www.youtube.com/watch?v=J1q5zLBb2Uo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCDVb4m_5QHhZElT47E1oODg
 - date published: 2023-06-18 18:40:14+00:00

Drinker's Chasers - Indiana Jones 5: It's Absolutely Terrible: https://www.youtube.com/watch?v=pW6VCGf2iVA


Support my work on Subscribe Star: https://www.subscribestar.com/dave-cullen
Follow me on Bitchute: https://www.bitchute.com/channel/hybM74uIHJKg/

KEEP UP ON SOCIAL MEDIA:
Gab: https://gab.ai/DaveCullen
Subscribe on Gab TV: https://tv.gab.com/channel/DaveCullen
Minds.com: https://www.minds.com/davecullen
Subscribe on Odysee: https://odysee.com/@TheDaveCullenShow:7

## The Flash Review: Multiverses And Member Berries (Spoilers)
 - [https://www.youtube.com/watch?v=b3MwaDt29gs](https://www.youtube.com/watch?v=b3MwaDt29gs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCDVb4m_5QHhZElT47E1oODg
 - date published: 2023-06-18 12:29:55+00:00

Support my work on Subscribe Star: https://www.subscribestar.com/dave-cullen
Follow me on Bitchute: https://www.bitchute.com/channel/hybM74uIHJKg/

KEEP UP ON SOCIAL MEDIA:
Gab: https://gab.ai/DaveCullen
Subscribe on Gab TV: https://tv.gab.com/channel/DaveCullen
Minds.com: https://www.minds.com/davecullen
Subscribe on Odysee: https://odysee.com/@TheDaveCullenShow:7

