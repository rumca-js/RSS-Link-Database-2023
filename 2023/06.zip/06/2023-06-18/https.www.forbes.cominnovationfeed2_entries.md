# Source:Forbs - innovation, URL:https://www.forbes.com/innovation/feed2, language:en-US

## Should Couples Merge Their Finances? New Research Weighs In
 - [https://www.forbes.com/sites/traversmark/2023/06/18/should-couples-merge-their-finances-new-research-weighs-in/](https://www.forbes.com/sites/traversmark/2023/06/18/should-couples-merge-their-finances-new-research-weighs-in/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-06-18 22:55:55+00:00

Merging your finances may strengthen your relationship bond.

## Is OpenSource AI Threatening The Tech Titans?
 - [https://www.forbes.com/sites/cindygordon/2023/06/18/is-opensource-ai-threatening-the-tech-titans/](https://www.forbes.com/sites/cindygordon/2023/06/18/is-opensource-ai-threatening-the-tech-titans/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-06-18 21:54:16+00:00

This article explores AI in the context of open-sourced alternatives and highlights market dynamics in play.

## ‘Fear The Walking Dead’ Season 8 Midseason Finale Review: Momo No Mo’
 - [https://www.forbes.com/sites/erikkain/2023/06/18/fear-the-walking-dead-season-8-midseason-finale-review-momo-no-mo/](https://www.forbes.com/sites/erikkain/2023/06/18/fear-the-walking-dead-season-8-midseason-finale-review-momo-no-mo/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-06-18 21:44:09+00:00

Fear The Walking Dead wraps up the first half of Season 8 with another massive dud.

## Samsung Galaxy Watch 6 Leaked Photos Show New Design, Return Of Favorite Feature
 - [https://www.forbes.com/sites/davidphelan/2023/06/18/samsung-galaxy-watch-6-leaked-photos-show-new-design-return-of-favorite-feature/](https://www.forbes.com/sites/davidphelan/2023/06/18/samsung-galaxy-watch-6-leaked-photos-show-new-design-return-of-favorite-feature/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-06-18 21:30:47+00:00

The next Samsung smartwatch is expected to be launched in weeks and will come in new colors, with a fan-favorite feature returning, it seems.

## ‘From’ Season 2, Episode 9 Review: Terrifying Revelations And New Mysteries
 - [https://www.forbes.com/sites/erikkain/2023/06/18/from-season-2-episode-9-review-terrifying-revelations-and-new-mysteries/](https://www.forbes.com/sites/erikkain/2023/06/18/from-season-2-episode-9-review-terrifying-revelations-and-new-mysteries/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-06-18 20:10:31+00:00

Another awesome, scary episode of From.

## New MacBook Air Leak Reveals Apple’s Disappointing Decision
 - [https://www.forbes.com/sites/ewanspence/2023/06/18/apple-macbook-pro-15-inch-m2-specs-delay-m3-leak/](https://www.forbes.com/sites/ewanspence/2023/06/18/apple-macbook-pro-15-inch-m2-specs-delay-m3-leak/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-06-18 19:51:54+00:00

The faithful fans have been waiting for Apple’s launch of the 15-inch MacBook Air. It's a disappointing release when you consider what's coming next from the macOS team.

## A Curious Connection Between Juneteenth And The Deadliest U.S. Storm
 - [https://www.forbes.com/sites/marshallshepherd/2023/06/18/a-curious-connection-between-juneteenth-and-the-deadliest-us-storm/](https://www.forbes.com/sites/marshallshepherd/2023/06/18/a-curious-connection-between-juneteenth-and-the-deadliest-us-storm/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-06-18 18:16:49+00:00

On Juneteenth, an African American meteorologist reflects on the significance of the holiday and a curious connection to the deadliest storm in U.S history

## Teaching Social Media—Adding To K-12 Curriculum
 - [https://www.forbes.com/sites/petersuciu/2023/06/18/teaching-social-media-adding-to-k-12-curriculum/](https://www.forbes.com/sites/petersuciu/2023/06/18/teaching-social-media-adding-to-k-12-curriculum/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-06-18 17:49:20+00:00

Along with "reading, writing and arithmetic," the social media 3Rs could perhaps include "research, responsibility and respect."

## AI’s Secret Sauce: Data, Algorithms, Skills, Or Something Else?
 - [https://www.forbes.com/sites/joemckendrick/2023/06/18/ais-secret-sauce-data-algorithms-skills-or-something-else/](https://www.forbes.com/sites/joemckendrick/2023/06/18/ais-secret-sauce-data-algorithms-skills-or-something-else/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-06-18 15:05:57+00:00

All too often, both business and technology executives may be enamored with the shiny objects.

## STANKFACE STANDING SOLDIER: Mato Wayuhi’s Masterpiece That Revolutionizes Indigenous Music ‘Into A New Era’
 - [https://www.forbes.com/sites/victorlopez-carmen/2023/06/18/stankface-standing-soldier-mato-wayuhis-masterpiece-that-revolutionizes-indigenous-music-into-a-new-era/](https://www.forbes.com/sites/victorlopez-carmen/2023/06/18/stankface-standing-soldier-mato-wayuhis-masterpiece-that-revolutionizes-indigenous-music-into-a-new-era/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-06-18 14:30:00+00:00

Leading up to his next album, we delve into the artistry of Mato Wayuhi, an award-winning Oglala Lakota composer, rapper and actor from South Dakota.

## NCAA Committee Recommends Removing Marijuana From Banned Drug List
 - [https://www.forbes.com/sites/brucelee/2023/06/18/ncaa-committee-recommends-removing-marijuana-from-banned-drug-list/](https://www.forbes.com/sites/brucelee/2023/06/18/ncaa-committee-recommends-removing-marijuana-from-banned-drug-list/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-06-18 13:46:58+00:00

The NCAA could act to remove marijuana from its banned drug list and testing protocols for college athletes this Fall.

## FDA Approval Of Topical Gel Eroxon For ED Reinforces Trend Toward More Availability Of OTC Products In Classes Previously Prescription-Only
 - [https://www.forbes.com/sites/joshuacohen/2023/06/18/fda-approval-of-topical-gel-eroxon-for-ed-reinforces-trend-toward-more-availability-of-otc-products-in-classes-previously-prescription-only/](https://www.forbes.com/sites/joshuacohen/2023/06/18/fda-approval-of-topical-gel-eroxon-for-ed-reinforces-trend-toward-more-availability-of-otc-products-in-classes-previously-prescription-only/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-06-18 12:41:41+00:00

Eroxon’s approval as an ED product is part of trend in which OTC availability is increasing in therapeutic classes which were formerly off limits to OTC drugs.

## Mild Hybrids Offer Cheap CO2 Cuts AsICE Ban Reality Looms
 - [https://www.forbes.com/sites/neilwinton/2023/06/18/mild-hybrids-offer-cheap-co2-cuts-asice-ban-reality-looms/](https://www.forbes.com/sites/neilwinton/2023/06/18/mild-hybrids-offer-cheap-co2-cuts-asice-ban-reality-looms/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-06-18 12:38:02+00:00

Mild-hybrids will become more popular as the EU's 2035 ban on new ICE car sales closes in, but the recent e-fuel concession suggests it may be forced to make more.

## Resurrection AI Heralds A New Era For Human Rights But It’s Complicated
 - [https://www.forbes.com/sites/traceyfollows/2023/06/18/resurrection-ai-heralds-a-new-era-for-human-rights-but-its-complicated/](https://www.forbes.com/sites/traceyfollows/2023/06/18/resurrection-ai-heralds-a-new-era-for-human-rights-but-its-complicated/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-06-18 12:07:14+00:00

Issues are arising about how we employ AI to blend together experiences of past, present and future.

## This Is Why Some People Are Upset Over ‘Armored Core VI’, And Why It’s Not Really An Issue
 - [https://www.forbes.com/sites/olliebarder/2023/06/18/this-is-why-some-people-are-upset-over-armored-core-vi-and-why-its-not-really-an-issue/](https://www.forbes.com/sites/olliebarder/2023/06/18/this-is-why-some-people-are-upset-over-armored-core-vi-and-why-its-not-really-an-issue/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-06-18 10:52:41+00:00

Since the new gameplay footage for 'Armored Core VI' was released, some older fans of the series have voiced their disapproval, but this is not at all new for the long running series.

## Nuphy’s Air96 Is The Best Compact Mechanical Keyboard With A Numeric Keypad
 - [https://www.forbes.com/sites/marksparrow/2023/06/18/nuphys-air96-is-the-best-compact-mechanical-keyboard-with-a-numeric-keypad/](https://www.forbes.com/sites/marksparrow/2023/06/18/nuphys-air96-is-the-best-compact-mechanical-keyboard-with-a-numeric-keypad/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-06-18 10:00:00+00:00

The low-profile Nuphy Air96 keyboard is a full 96% ANSI layout and includes a numeric keypad. The Gateron switches are hot swappable. The Air96 is a joy to type on.

## If Your Reddit Feed Is Full Of John Oliver, Here’s Why
 - [https://www.forbes.com/sites/barrycollins/2023/06/18/if-your-reddit-feed-is-full-of-john-oliver-heres-why/](https://www.forbes.com/sites/barrycollins/2023/06/18/if-your-reddit-feed-is-full-of-john-oliver-heres-why/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-06-18 08:54:26+00:00

Two major Reddit communities call off the strike – but now only allow pictures of comedian John Oliver

## Today’s Wordle #729 Hints, Clues And Answer For Sunday, June 18th
 - [https://www.forbes.com/sites/erikkain/2023/06/17/todays-wordle-729-hints-clues-and-answer-for-sunday-june-18th/](https://www.forbes.com/sites/erikkain/2023/06/17/todays-wordle-729-hints-clues-and-answer-for-sunday-june-18th/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-06-18 02:30:34+00:00

How to solve today's Wordle. Hints, clues and the daily Wordle answer. Also, play competitive Wordle and learn more about each day's word.

## Fox News Host Causes Confusion On Facebook By Declaring Trump Was Found Not Guilty
 - [https://www.forbes.com/sites/mattnovak/2023/06/17/fox-news-host-causes-confusion-on-facebook-by-declaring-trump-was-found-not-guilty/](https://www.forbes.com/sites/mattnovak/2023/06/17/fox-news-host-causes-confusion-on-facebook-by-declaring-trump-was-found-not-guilty/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-06-18 01:44:50+00:00

Donald Trump was arraigned on 37 federal charges related to his refusal to hand over classified documents. But Fox News erroneously declared Trump not guilty on Facebook.

## AWS re:Inforce 2023: Navigating The Crossroads Of Security, Diversity, And AI Innovation
 - [https://www.forbes.com/sites/tonybradley/2023/06/17/aws-reinforce-2023-navigating-the-crossroads-of-security-diversity-and-ai-innovation/](https://www.forbes.com/sites/tonybradley/2023/06/17/aws-reinforce-2023-navigating-the-crossroads-of-security-diversity-and-ai-innovation/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-06-18 01:43:47+00:00

AWS announced an array of new services and capabilities—as they typically do at events like this—and there were many informative keynotes and breakout sessions.

## Today’s ‘Quordle’ Answers And Clues For Sunday, June 18
 - [https://www.forbes.com/sites/krisholt/2023/06/17/todays-quordle-answers-and-clues-for-sunday-june-18/](https://www.forbes.com/sites/krisholt/2023/06/17/todays-quordle-answers-and-clues-for-sunday-june-18/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-06-18 00:00:09+00:00

Some hints and the solution for today's 'Quordle' are just ahead.

