# Source:Daily Mail, URL:https://www.dailymail.co.uk/news/index.rss, language:en-US

## T4 Sydney Eastern Suburbs train line closes
 - [https://www.dailymail.co.uk/news/article-12208731/T4-Sydney-Eastern-Suburbs-train-line-closes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12208731/T4-Sydney-Eastern-Suburbs-train-line-closes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 22:55:06+00:00

Trains between Edgecliff and Kings Cross on the T4 Eastern Suburbs to Illawarra line were shut down at about 6am

## British nationals 'will be put at the front of council housing queue'
 - [https://www.dailymail.co.uk/news/article-12208769/British-nationals-council-housing-queue.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12208769/British-nationals-council-housing-queue.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 22:55:04+00:00

Ministers are discussing how they can include legislation in this autumn's King's Speech that would require councils to push British citizens and permanent residents higher up waiting lists.

## Blockade Australia protester Port of Newcastle
 - [https://www.dailymail.co.uk/news/article-12208607/Blockade-Australia-protester-Port-Newcastle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12208607/Blockade-Australia-protester-Port-Newcastle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 22:54:50+00:00

A climate change activist is blocking a coal loading terminal at one of the world's biggest coal ports.

## Ice hidden in tequila bottles in Mexico worth $1billion caught before shipped to NSW
 - [https://www.dailymail.co.uk/news/article-12208581/Ice-hidden-tequila-bottles-Mexico-worth-1billion-caught-shipped-NSW.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12208581/Ice-hidden-tequila-bottles-Mexico-worth-1billion-caught-shipped-NSW.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 22:53:31+00:00

The liquid meth had been concealed in 11,520 bottles before it was uncovered by the Mexican Navy, known as SEMAR, in the port of Manzanillo on April 18.

## Fishing team lose $3.5million prize after 619-pound blue marlin caught is disqualified competition
 - [https://www.dailymail.co.uk/news/article-12208555/Fishing-team-lose-3-5million-prize-619-pound-blue-marlin-caught-disqualified-competition.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12208555/Fishing-team-lose-3-5million-prize-619-pound-blue-marlin-caught-disqualified-competition.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 22:52:11+00:00

A North Carolina fishing team that hauled a 619-pound Blue Marlin aboard their boat were disqualified after the fish was found to have been mutilated. It means they lost $3.5 million in prize money.

## Neighbourhood policing is near extinct: Fewer than one in eight officers are 'bobbies on the beat'
 - [https://www.dailymail.co.uk/news/article-12208755/Neighbourhood-policing-near-extinct-Fewer-one-eight-officers-bobbies-beat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12208755/Neighbourhood-policing-near-extinct-Fewer-one-eight-officers-bobbies-beat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 22:51:17+00:00

House of Commons Library research shows that in 2022, just 17,303 police officers across England and Wales were assigned to neighbourhood policing teams.

## Bernard Jenkin is still silent FIVE DAYS on from claims of Covid party breach
 - [https://www.dailymail.co.uk/news/article-12208723/Bernard-Jenkin-silent-FIVE-DAYS-claims-Covid-party-breach.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12208723/Bernard-Jenkin-silent-FIVE-DAYS-claims-Covid-party-breach.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 22:46:50+00:00

Five days after claims were aired that he attended a lockdown-busting drinks party, one of Boris Johnson's leading Partygate inquisitors is maintaining his silence.

## Boost for Boris as Gove admits he won't vote for the 'excessive' Partygate probe's punishment
 - [https://www.dailymail.co.uk/news/article-12208719/Boost-Boris-Gove-admits-wont-vote-excessive-Partygate-probes-punishment.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12208719/Boost-Boris-Gove-admits-wont-vote-excessive-Partygate-probes-punishment.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 22:32:51+00:00

The Levelling Up Secretary - who ended Mr Johnson's 2016 leadership bid and was sacked by him for disloyalty a year ago - revealed he would not support the privileges committee's report today.

## Borrowers will struggle to make ends meet when they retire because of 35-year mortgages
 - [https://www.dailymail.co.uk/news/article-12208685/Borrowers-struggle-make-ends-meet-retire-35-year-mortgages.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12208685/Borrowers-struggle-make-ends-meet-retire-35-year-mortgages.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 22:23:03+00:00

Home loan repayments that stretch well past working age could mean hundreds of thousands of savers are tempted to raid their retirement pots, Sir Steve Webb said.

## Senior Tories insist they can win all four upcoming by-elections
 - [https://www.dailymail.co.uk/news/article-12208695/Senior-Tories-insist-win-four-upcoming-elections.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12208695/Senior-Tories-insist-win-four-upcoming-elections.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 22:22:50+00:00

David Warburton (pictured) became the fourth MP in little more than a week to announce they were standing down, following Boris Johnson, Nadine Dorries and Nigel Adams.

## Gavin Newsom and wife's recent media blitz spark speculation that Governor could run in 2024
 - [https://www.dailymail.co.uk/news/article-12208511/Gavin-Newsom-wifes-recent-media-blitz-spark-speculation-Governor-run-2024.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12208511/Gavin-Newsom-wifes-recent-media-blitz-spark-speculation-Governor-run-2024.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 22:14:52+00:00

California Gov. Gavin Newsom and his wife Jennifer have been making the rounds on news channels and giving exclusive interviews with print media in recent weeks.

## Golden goodbyes for civil servants cost a whopping £182million in a single year
 - [https://www.dailymail.co.uk/news/article-12208653/Golden-goodbyes-civil-servants-cost-whopping-182million-single-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12208653/Golden-goodbyes-civil-servants-cost-whopping-182million-single-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 22:14:47+00:00

The Treasury last night said it had launched a consultation to look at making the process around severance payments more 'rigorous' amid calls to cap exit packages at £95,000.

## Bank of England told to 'wait' before imposing ANOTHER rate hike
 - [https://www.dailymail.co.uk/news/article-12208657/Bank-England-told-wait-imposing-rate-hike.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12208657/Bank-England-told-wait-imposing-rate-hike.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 22:10:04+00:00

The Bank of England is poised to impose a 13th consecutive increase on Thursday, a strategy one senior broker described as 'insanity'. The base rate might hit its highest level since 2008.

## Man pulled a switchblade to stab a dog to death in Central Park
 - [https://www.dailymail.co.uk/news/article-12208437/Man-pulled-switchblade-stab-dog-death-Central-Park.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12208437/Man-pulled-switchblade-stab-dog-death-Central-Park.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 21:39:07+00:00

A man fatally stabbed a dog in Central Park on Saturday near 106th Street at about 8:30 p.m., after his unleashed pit bulls attacked it.

## Harvard tells husband his wife's remains may have been sold in a body part trafficking operation
 - [https://www.dailymail.co.uk/news/article-12208399/Harvard-tells-husband-wifes-remains-sold-body-trafficking-operation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12208399/Harvard-tells-husband-wifes-remains-sold-body-trafficking-operation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 21:29:46+00:00

A man was horrified last week to receive a letter from Harvard Medical School saying it's possible his wife's remains were sold by a morgue manager.

## More than 1,000 foreign criminals including killers and rapists are on the run from British police
 - [https://www.dailymail.co.uk/news/article-12208473/More-1-000-foreign-criminals-including-killers-rapists-run-British-police.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12208473/More-1-000-foreign-criminals-including-killers-rapists-run-British-police.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 21:19:58+00:00

Shocking figures show that the number either wanted by police or dodging deportation has soared from 169 in 2014 to more than 1,000 today.

## Police are probing a Christmas lockdown party at Tory HQ after Partygate footage emerges
 - [https://www.dailymail.co.uk/news/article-12208447/Police-probing-Christmas-lockdown-party-Tory-HQ-Partygate-footage-emerges.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12208447/Police-probing-Christmas-lockdown-party-Tory-HQ-Partygate-footage-emerges.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 21:11:31+00:00

Michael Gove yesterday apologised for the 'terrible' clip as officers said they were 'considering' the new evidence.

## Brothers of 28-year-old who was raped and murdered on a safari vow to keep searching for justice
 - [https://www.dailymail.co.uk/news/article-12208331/Brothers-28-year-old-raped-murdered-safari-vow-searching-justice.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12208331/Brothers-28-year-old-raped-murdered-safari-vow-searching-justice.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 21:08:51+00:00

The parents of murdered Julie Ward (pictured), who was killed in Kenya 35 years ago, died just weeks apart from each other in May. Now, their sons vow to continue the fight for justice.

## Flat-capped Joe, 11, rents land, breeds sheep, keeps cows and even owns a border collie
 - [https://www.dailymail.co.uk/news/article-12208445/Flat-capped-Joe-11-rents-land-breeds-sheep-keeps-cows-owns-border-collie.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12208445/Flat-capped-Joe-11-rents-land-breeds-sheep-keeps-cows-owns-border-collie.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 21:08:27+00:00

With his flat cap and checked shirt, Joe Trofer-Cook looks every inch the young farmer. But this isn't fancy dress - at the tender age of 11 he already rents land, breeds sheep and owns a border collie.

## How the sultry wartime spy who inspired James Bond's Vesper Lynd hoodwinked the Gestapo
 - [https://www.dailymail.co.uk/news/article-12208415/How-sultry-wartime-spy-inspired-James-Bonds-Vesper-Lynd-hoodwinked-Gestapo.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12208415/How-sultry-wartime-spy-inspired-James-Bonds-Vesper-Lynd-hoodwinked-Gestapo.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 21:07:54+00:00

Flying low over the mountain range dividing wartime Czechoslovakia and Poland, the Luftwaffe fighter pilot trained his machine-gun fire on the beautiful young woman.

## Fury after two innocent people are killed by delivery drivers rushing to meet targets
 - [https://www.dailymail.co.uk/news/article-12208351/Fury-two-innocent-people-killed-delivery-drivers-rushing-meet-targets.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12208351/Fury-two-innocent-people-killed-delivery-drivers-rushing-meet-targets.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 21:04:47+00:00

Milliee-Ann McKellar (pictured), was a three year old girl who was killed when a Hermes delivery van reversed over her as she played in the street on a scooter outside her grandmother's house.

## Parents of Nottingham knife attack victim pay tribute during vigil held at his cricket club
 - [https://www.dailymail.co.uk/news/article-12208335/Parents-Nottingham-knife-attack-victim-pay-tribute-vigil-held-cricket-club.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12208335/Parents-Nottingham-knife-attack-victim-pay-tribute-vigil-held-cricket-club.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 20:24:56+00:00

Bishops Hull Cricket Club honoured Barnaby Webber's 'lovely soul' with a vigil today, his parents have said. His mother hailed the club for its 'outpouring of love and support'.

## Ivanka praises husband Jared on Father's Day in gushing Instagram post
 - [https://www.dailymail.co.uk/news/article-12208287/Ivanka-praises-husband-Jared-Fathers-Day-gushing-Instagram-post.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12208287/Ivanka-praises-husband-Jared-Fathers-Day-gushing-Instagram-post.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 20:23:55+00:00

Ivanka Trump, 41, gushed over her husband Jared Kushner, 42, in a Father's Day tribute post on Instagram, saying 'you fill our lives with joy guidance and boundless love.'

## San Francisco Mayor lashes out at GMA for saying it was 'too dangerous' to film in city's downtown
 - [https://www.dailymail.co.uk/news/article-12208345/San-Francisco-Mayor-lashes-GMA-saying-dangerous-film-citys-downtown.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12208345/San-Francisco-Mayor-lashes-GMA-saying-dangerous-film-citys-downtown.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 20:21:25+00:00

San Francisco Mayor London Breed hit out at Good Morning America for saying it was 'too dangerous' to film in the city's downtown on its program Wednesday.

## Mum reveals how she lost more than $100k to man she met on Tinder in cruel 'pig butchering' scam
 - [https://www.dailymail.co.uk/news/article-12208425/Mum-reveals-lost-100k-man-met-Tinder-cruel-pig-butchering-scam.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12208425/Mum-reveals-lost-100k-man-met-Tinder-cruel-pig-butchering-scam.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 20:20:15+00:00

A recently divorced mum-of-three has revealed how she lost her more than $100,000 to a scammer she met on Tinder.

## McDonald's mascot Grimace becomes LGBTQ+ icon
 - [https://www.dailymail.co.uk/news/article-12208379/McDonalds-mascot-Grimace-LGBTQ-icon.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12208379/McDonalds-mascot-Grimace-LGBTQ-icon.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 20:16:12+00:00

McDonald's mascot Grimace has become a LGBTQ+ icon after being resurrected for a new campaign during Pride month.

## Lawyer for detransitioning woman, 18, who had surgery aged 12 slams doctors for 'mutilating' kids
 - [https://www.dailymail.co.uk/news/article-12208161/Lawyer-detransitioning-woman-18-surgery-aged-12-slams-doctors-mutilating-kids.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12208161/Lawyer-detransitioning-woman-18-surgery-aged-12-slams-doctors-mutilating-kids.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 20:12:16+00:00

Speaking to DailyMail.com Sunday, Charles LiMandri slammed the recent spate of gender-assignment surgeries seen since 2015 as an 'indoctrination' - one that caught up his 18-year-old client Kayla Lovdahl.

## Marjorie Taylor Greene accuses FBI director Christopher Wray of hiding the president's crimes
 - [https://www.dailymail.co.uk/news/article-12208309/Marjorie-Taylor-Greene-accuses-FBI-director-Christopher-Wray-hiding-presidents-crimes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12208309/Marjorie-Taylor-Greene-accuses-FBI-director-Christopher-Wray-hiding-presidents-crimes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 19:59:06+00:00

Rep. Marjorie Taylor Greene, a Republican from Georgia, joined Fox's 'Sunday Morning Futures With Maria Bartiromo' and called out FBI director Christopher Wray for hiding Biden's crimes.

## Graeme Souness swims 21 miles across Channel to raise £1.1m
 - [https://www.dailymail.co.uk/news/article-12208361/Graeme-Souness-swims-21-miles-Channel-raise-1-1m.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12208361/Graeme-Souness-swims-21-miles-Channel-raise-1-1m.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 19:57:28+00:00

Former footballer and TV pundit Graeme Souness has completed a 21-mile charity swim across the English Channel. The 70-year-old has raised more than £1 million for Debra UK.

## Moment Darth Vader is hauled out of Ashes test match in front of bemused fans
 - [https://www.dailymail.co.uk/news/article-12208295/Moment-Darth-Vader-hauled-Ashes-test-match-bemused-fans.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12208295/Moment-Darth-Vader-hauled-Ashes-test-match-bemused-fans.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 19:56:08+00:00

Confused fans watched as a person dressed up as the Star Wars villain was hauled out of Edgbaston Cricket Ground in Birmingham during the third day of the Ashes.

## Italy is gripped by hunt for five-year-old girl who was 'bundled into a suitcase and kidnapped'
 - [https://www.dailymail.co.uk/news/article-12208003/Desperate-search-five-year-old-girl-kidnapped-8-days-ago-hotel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12208003/Desperate-search-five-year-old-girl-kidnapped-8-days-ago-hotel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 19:39:17+00:00

Kataleya Mia Chicillo Alvarez, five, from Peru, went missing on June 10 from the occupied Astor Hotel in Florence, Italy, where she was living with her family and 140 people.

## Melbourne pool company Pools R Us in liquidation as clients unleash on business
 - [https://www.dailymail.co.uk/news/article-12163875/Melbourne-pool-company-Pools-R-liquidation-clients-unleash-business.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12163875/Melbourne-pool-company-Pools-R-liquidation-clients-unleash-business.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 19:25:31+00:00

Nyerse Constructions Pty. Ltd. which trades under the name of Pools R Us, based in Melbourne, went into liquidation on June 1.

## Biden, Jill, Kamala and Doug will hit America's richest cities to beg for campaign cash
 - [https://www.dailymail.co.uk/news/article-12198733/Biden-Jill-Kamala-Doug-hit-Americas-richest-cities-beg-campaign-cash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12198733/Biden-Jill-Kamala-Doug-hit-Americas-richest-cities-beg-campaign-cash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 19:18:38+00:00

It's all hands on deck for Team Biden as Joe, Jill, Kamala and Doug head to America's richest cities in order to rake in much-needed campaign cash ahead of the June 30th's fundraising deadline.

## Blumenthal suggests 'betrayed' golfers might comply with Senate probe into PGA/LIV merger
 - [https://www.dailymail.co.uk/news/article-12208285/Blumenthal-suggests-betrayed-golfers-comply-Senate-probe-PGA-LIV-merger.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12208285/Blumenthal-suggests-betrayed-golfers-comply-Senate-probe-PGA-LIV-merger.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 18:57:32+00:00

Sen. Richard Blumenthal plans to hold in coming weeks a hearing on the merger between the PGA and Saudi-backed LIV Golf - and says he thinks players will participate in the investigation.

## Emma Raducanu says sometimes she wishes she 'never won the US Open'
 - [https://www.dailymail.co.uk/news/article-12208157/Emma-Raducanu-says-wishes-never-won-Open.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12208157/Emma-Raducanu-says-wishes-never-won-Open.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 18:24:56+00:00

Tennis star Emma Radacanu says she was 'extremely naïve' when she won the US Open and that the tour is 'not a nice, trusting and safe space'.

## 'Trump is not the victim!' Bill Barr unloads on former boss and claims he LIED to DOJ
 - [https://www.dailymail.co.uk/news/article-12208191/Trump-not-victim-Bill-Barr-unloads-former-boss-claims-LIED-DOJ.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12208191/Trump-not-victim-Bill-Barr-unloads-former-boss-claims-LIED-DOJ.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 18:14:53+00:00

Trump's former Attorney General Bill Barr had some choice words after the ex-president spent a week unloading on him for saying he's 'toast' if the indictment proves true.

## Moment father climbs up waterslide to rescue his terrified daughter
 - [https://www.dailymail.co.uk/news/article-12208097/Moment-father-climbs-waterslide-rescue-terrified-daughter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12208097/Moment-father-climbs-waterslide-rescue-terrified-daughter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 17:27:11+00:00

Andrew Reece, 38, headed to Gullivers World, in Warrington, on Saturday July 10 with his wife Emma, 41, for their six-year-old daughter Sienna's birthday.

## Eight months pregnant model is shot dead in DC after two men armed with rifles opened fire
 - [https://www.dailymail.co.uk/news/article-12207907/Eight-months-pregnant-model-shot-dead-DC-two-men-armed-rifles-opened-fire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207907/Eight-months-pregnant-model-shot-dead-DC-two-men-armed-rifles-opened-fire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 17:18:20+00:00

An eight-month pregnant model has died after two gunman with rifles opened fire on a parked car she was sitting in with the child's father in Washington DC.

## Man who idolised Agent 47 and stabbed flatmate to death cleared of murder and given hospital order
 - [https://www.dailymail.co.uk/news/article-12208095/Man-idolised-Agent-47-stabbed-flatmate-death-cleared-murder-given-hospital-order.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12208095/Man-idolised-Agent-47-stabbed-flatmate-death-cleared-murder-given-hospital-order.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 17:17:26+00:00

Eugen Coman, 35, stabbed Leonid Laboshin 27 times with a 'blanked stare' before dragging his body into the garden of their home.

## Jocelyn Wildenstein claims she is FLAT BROKE ahead of new HBO documentary series
 - [https://www.dailymail.co.uk/news/article-12207961/Jocelyn-Wildenstein-claims-FLAT-BROKE-ahead-new-HBO-documentary-series.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207961/Jocelyn-Wildenstein-claims-FLAT-BROKE-ahead-new-HBO-documentary-series.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 17:07:37+00:00

Jocelyn Wildenstein, 82, claims she is flat broke and has not had any income for eight years after her ex-husband's family cut her off in 2015.

## Now water firms want you to grass on your neighbours
 - [https://www.dailymail.co.uk/news/article-12208107/Now-water-firms-want-grass-neighbours.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12208107/Now-water-firms-want-grass-neighbours.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 17:01:44+00:00

South East Water announced the ten-day hosepipe ban for 1.3 million customers on Friday but it will be enforced from June 26.

## Students reject replacing Father's Day with gender-neutral Parent's Day
 - [https://www.dailymail.co.uk/news/article-12207957/Students-reject-replacing-Fathers-Day-gender-neutral-Parents-Day.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207957/Students-reject-replacing-Fathers-Day-gender-neutral-Parents-Day.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 16:48:10+00:00

Students in Northern Virginia have rejected the notion of replacing Father's Day with a more gender inclusive one - like Parent's Day - and say it's just more woke nonsense.

## Tim Scott hits back at Obama for attacks on GOP - and insists 'America is NOT a racist country'
 - [https://www.dailymail.co.uk/news/article-12207933/Tim-Scott-hits-Obama-attacks-GOP-insists-America-NOT-racist-country.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207933/Tim-Scott-hits-Obama-attacks-GOP-insists-America-NOT-racist-country.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 16:40:54+00:00

Sen. Tim Scott responded to Barack Obama's attacks on him by claiming it's proof Democrats are 'threatened' by his candidacy in the 2024 Republican presidential primary.

## London's oldest housing estate that's being taken over by Airbnbs
 - [https://www.dailymail.co.uk/news/article-12207501/Londons-oldest-housing-estate-thats-taken-Airbnbs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207501/Londons-oldest-housing-estate-thats-taken-Airbnbs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 16:36:03+00:00

The slum, dubbed the Old Nichol, had become a problem for the city in the late 19th century - renowned for its terrible living conditions and extreme poverty.

## Hundreds of nude cyclists ride around the streets of Bristol for World Naked Bike Ride
 - [https://www.dailymail.co.uk/news/article-12208013/Hundreds-nude-cyclists-ride-streets-Bristol-World-Naked-Bike-Ride.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12208013/Hundreds-nude-cyclists-ride-streets-Bristol-World-Naked-Bike-Ride.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 16:19:54+00:00

The event is billed as a celebration of bicycles and bodies, highlighting the vulnerability of cyclists on our crowded roads in a demonstration against car culture and oil dependency.

## American heroes send $30 million of kit to Ukraine as Kyiv begins counteroffensive against Russia
 - [https://www.dailymail.co.uk/news/article-12195357/American-heroes-send-30-million-kit-Ukraine-Kyiv-begins-counteroffensive-against-Russia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12195357/American-heroes-send-30-million-kit-Ukraine-Kyiv-begins-counteroffensive-against-Russia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 15:58:57+00:00

The Virginia-based nonprofit, which counts several ex-servicemen and women amongst its ranks, tracks down non-lethal military supplies and gets them to the frontlines.

## America's $65bn junk fee economy exposed - and how to avoid sneaky charges
 - [https://www.dailymail.co.uk/news/article-12200537/Americas-65bn-junk-fee-economy-exposed-avoid-sneaky-charges.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12200537/Americas-65bn-junk-fee-economy-exposed-avoid-sneaky-charges.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 15:58:47+00:00

These extra add-ons are rife in the everyday life of Americans, inflating prices and making it difficult for consumers to know exactly how much they will end up paying for a hotel, flight, ticket or banking service.

## Meet the Gen Z dupe hunters: How TikTok is creating a billion-dollar 'knock-off' economy
 - [https://www.dailymail.co.uk/news/article-12199029/Meet-Gen-Z-dupe-hunters-TikTok-creating-billion-dollar-knock-economy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12199029/Meet-Gen-Z-dupe-hunters-TikTok-creating-billion-dollar-knock-economy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 15:58:35+00:00

Content around 'dupes', or duplicates, has blown up in recent years on social media, as the cost of living crunch has taken hold and the appetite for cheaper alternatives has surged.

## Facebook managers 'turned blind eye' to substance abuse if they thought it boosted productivity
 - [https://www.dailymail.co.uk/news/article-12186973/Facebook-managers-turned-blind-eye-substance-abuse-thought-boosted-productivity.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12186973/Facebook-managers-turned-blind-eye-substance-abuse-thought-boosted-productivity.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 15:58:20+00:00

Facebook managers allegedly turned a blind eye to substance abuse. It comes as the alleged killing of Cash App founder Bob Lee (left) by Nima Momeni (right) exposes drug use in Silicon Valley.

## NSA whistleblower Reality Winner refuses to watch new film starring Sydney Sweeney
 - [https://www.dailymail.co.uk/news/article-12144877/NSA-whistleblower-Reality-Winner-refuses-watch-new-film-starring-Sydney-Sweeney.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12144877/NSA-whistleblower-Reality-Winner-refuses-watch-new-film-starring-Sydney-Sweeney.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 15:58:08+00:00

NSA whistleblower Reality Winner has not watched the new HBO Max film starring Sydney Sweeney, which is entirely adapted from her FBI interrogation, and said she refuses to relive the trauma.

## Klaus Julius Andres who murdered wife Li Ping Cao then dissolved her body in acid could be freed
 - [https://www.dailymail.co.uk/news/article-12207889/Klaus-Julius-Andres-murdered-wife-Li-Ping-Cao-dissolved-body-acid-freed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207889/Klaus-Julius-Andres-murdered-wife-Li-Ping-Cao-dissolved-body-acid-freed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 15:58:04+00:00

A convicted killer described as 'evil' and 'a 'psychopath' by police will be given the chance to plead for an early release from a life sentence on grounds of ill health.

## Breanna Tottle: Queensland woman reveals she bled for months after horror miscarriage
 - [https://www.dailymail.co.uk/news/article-12196661/Breanna-Tottle-Queensland-woman-reveals-bled-months-horror-miscarriage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12196661/Breanna-Tottle-Queensland-woman-reveals-bled-months-horror-miscarriage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 15:41:56+00:00

Breanna Tottle, 26, from southeast Queensland, bled for almost the entire summer after she miscarried with her second child at the end of September.

## Details emerge about Brittany Higgins' deal with The Project
 - [https://www.dailymail.co.uk/news/article-12200937/Details-emerge-Brittany-Higgins-deal-Project.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12200937/Details-emerge-Brittany-Higgins-deal-Project.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 15:40:36+00:00

Speculation has raged over whether former political staffer Brittany Higgins was paid for her 2021 interview on The Project when she accused Bruce Lehrmann of raping her in 2019.

## DailyMail.com investigates the booming business of 'Prepping' the Preppers
 - [https://www.dailymail.co.uk/news/article-12200467/DailyMail-com-investigates-booming-business-Prepping-Preppers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12200467/DailyMail-com-investigates-booming-business-Prepping-Preppers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 15:09:30+00:00

In 2020, more than 20 million Americans, nearly 7 percent of all U.S. households, were actively planning for an emergency, according to the latest analysis of FEMA data.

## Moment United plane collides with a Delta aircraft on the tarmac at Boston's Logan Airport
 - [https://www.dailymail.co.uk/news/article-12207861/Moment-United-plane-collides-Delta-aircraft-tarmac-Bostons-Logan-Airport.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207861/Moment-United-plane-collides-Delta-aircraft-tarmac-Bostons-Logan-Airport.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 15:09:10+00:00

Video posted online showed a United Airlines plane backing up into a Delta flight on the tarmac of Boston's Logan Airport Friday afternoon.

## Girlfriend of amateur rugby player, 32, reveals she spoke to him minutes before he was killed
 - [https://www.dailymail.co.uk/news/article-12207871/Girlfriend-amateur-rugby-player-32-reveals-spoke-minutes-killed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207871/Girlfriend-amateur-rugby-player-32-reveals-spoke-minutes-killed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 15:08:59+00:00

Chris Moran, 32, was on a night out with his friends when he was struck in the city at 5am on Friday, June 9. He died instantly. His heartbroken girlfriend, Georgia Cooke, 25, has now paid tribute to him.

## Schwarzenegger says he stands by comparison of January 6th Capitol riots to Kristallnacht
 - [https://www.dailymail.co.uk/news/article-12207765/Schwarzenegger-says-stands-comparison-January-6th-Capitol-riots-Kristallnacht.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207765/Schwarzenegger-says-stands-comparison-January-6th-Capitol-riots-Kristallnacht.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 15:08:20+00:00

Former Governor Arnold Schwarzenegger joined Friday's episode of CNN's 'Who's Talking to Chris Wallace,' and defended his comparison of the January 6th Capitol riots to Kristallnacht violent attack.

## Police rescue HUGE boa constrictor from busy road beside a park amid hunt for reptile's owner
 - [https://www.dailymail.co.uk/news/article-12207863/Police-rescue-HUGE-boa-constrictor-busy-road-park-amid-hunt-reptiles-owner.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207863/Police-rescue-HUGE-boa-constrictor-busy-road-park-amid-hunt-reptiles-owner.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 15:08:02+00:00

Officers were on patrol on the street on Park Lane in Aston in Birmingham when they spotted the animal slithering along the street, and had to stop to capture it

## Mike Pence says Trump could be found INNOCENT - but former VP won't commit to pardoning him
 - [https://www.dailymail.co.uk/news/article-12207865/Mike-Pence-says-Trump-INNOCENT-former-VP-wont-commit-pardoning-him.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207865/Mike-Pence-says-Trump-INNOCENT-former-VP-wont-commit-pardoning-him.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 15:03:41+00:00

Presidential hopeful Mike Pence won't say whether he would pardon Donald Trump, claiming that the former president could still be found innocent in his federal indictment.

## Detransitioning woman, 18, suing Kaiser Permanente for 'pushing her' into gender-changing surgery
 - [https://www.dailymail.co.uk/news/article-12207743/Detransitioning-woman-18-suing-Kaiser-Permanente-pushing-gender-changing-surgery.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207743/Detransitioning-woman-18-suing-Kaiser-Permanente-pushing-gender-changing-surgery.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 15:01:28+00:00

Now 18, Kayla Lovdahl filed the lawsuit last week in California's San Joaquin County Superior Court, accusing multiple Bay Area professionals of fast-tracking her treatment.

## Chinese secret police: Australian Andrew Phelan grilled by cops over fake email threats
 - [https://www.dailymail.co.uk/news/article-12207833/Chinese-secret-police-Australian-Andrew-Phelan-grilled-cops-fake-email-threats.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207833/Chinese-secret-police-Australian-Andrew-Phelan-grilled-cops-fake-email-threats.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 14:58:36+00:00

This is the shocking moment an Australian entrepreneur is grilled by cops over vile threats he supposedly made to 'rape and kill' an Chinese-Australian journalist.

## Kathleen Folbigg spends her first moments of freedom drinking champagne and eating steak
 - [https://www.dailymail.co.uk/news/article-12207773/Kathleen-Folbigg-spends-moments-freedom-drinking-champagne-eating-steak.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207773/Kathleen-Folbigg-spends-moments-freedom-drinking-champagne-eating-steak.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 14:52:57+00:00

After spending 20 years behind bars over the deaths of her four children, Kathleen Folbigg enjoyed her first hours of freedom drinking champagne, eating steak and gazing out at the ocean.

## Biden kicks off Father's Day at his Delaware beach house with daughter Ashley
 - [https://www.dailymail.co.uk/news/article-12207849/Biden-kicks-Fathers-Day-Delaware-beach-house-daughter-Ashley.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207849/Biden-kicks-Fathers-Day-Delaware-beach-house-daughter-Ashley.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 14:41:39+00:00

The president is spending Sunday at his Rehoboth Beach home in Delaware, joined by first lady Jill Biden and daughter Ashley. His granddaughter Natalie also attended Mass with Biden Saturday.

## Ashes are rained off as thunderstorms lash the UK and Met Office issues weather warnings
 - [https://www.dailymail.co.uk/news/article-12207835/Ashes-rained-thunderstorms-lash-UK-Met-Office-issues-weather-warnings.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207835/Ashes-rained-thunderstorms-lash-UK-Met-Office-issues-weather-warnings.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 14:39:34+00:00

The crowd at Edgbaston in Birmingham were seen running for their umbrellas while the players made their way off the pitch to be replaced by the covers when the heavens opened this afternoon.

## Kwinana Freeway crash near Perth, Hyundai rolls at speed, but woman driver 'crawls' from wreck
 - [https://www.dailymail.co.uk/news/article-12207695/Kwinana-Freeway-crash-near-Perth-Hyundai-rolls-speed-woman-driver-crawls-wreck.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207695/Kwinana-Freeway-crash-near-Perth-Hyundai-rolls-speed-woman-driver-crawls-wreck.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 14:38:41+00:00

The crash, which happened on the Kwinana Freeway at Bibra Like, just south of Perth at 5.30pm on Saturday, was captured by another driver's dash cam.

## Pennsylvania state trooper shot dead and another seriously injured
 - [https://www.dailymail.co.uk/news/article-12207753/Pennsylvania-state-trooper-shot-dead-seriously-injured.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207753/Pennsylvania-state-trooper-shot-dead-seriously-injured.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 13:55:17+00:00

A state trooper in Pennsylvania was killed in a shootout with a man hours after he opened fire on another trooper.

## Special service is held for Nottingham attack victims
 - [https://www.dailymail.co.uk/news/article-12207763/Special-service-held-Nottingham-attack-victims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207763/Special-service-held-Nottingham-attack-victims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 13:45:47+00:00

St Peter's Church in the city has become a shrine to the victims of the knife and van attack with hundreds of floral tributes left nearby.

## Met Police are 'considering' new Partygate footage
 - [https://www.dailymail.co.uk/news/article-12207777/Met-Police-considering-new-Partygate-footage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207777/Met-Police-considering-new-Partygate-footage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 13:28:00+00:00

The force said it was aware of the video, which shows a Christmas party involving at least 24 revellers at Conservative Campaign Headquarters in London in December 2020.

## Nicola Sturgeon says she is 'certain' she has done nothing wrong after arrest in SNP finance probe
 - [https://www.dailymail.co.uk/news/article-12207733/Nicola-Sturgeon-says-certain-wrong-arrest-SNP-finance-probe.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207733/Nicola-Sturgeon-says-certain-wrong-arrest-SNP-finance-probe.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 12:42:24+00:00

A defiant Nicola Sturgeon insisted she had 'done nothing wrong' today as she faced the cameras for the first time since being arrested in a police probe into the SNP's finances.

## Prince William reveals he points out homeless people to George Louis and Charlotte on the school run
 - [https://www.dailymail.co.uk/news/article-12207697/Prince-William-reveals-points-homeless-people-George-Louis-Charlotte-school-run.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207697/Prince-William-reveals-points-homeless-people-George-Louis-Charlotte-school-run.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 12:40:29+00:00

The Prince candidly spoke of conversations he has with his own children, George, Charlotte and Louis, to ensure they grow up knowing 'some of us are very fortunate'.

## Thug, 25, who ordered his American XL bully to savage a motorist jailed for eight years
 - [https://www.dailymail.co.uk/news/article-12207627/Thug-25-ordered-American-XL-bully-savage-motorist-jailed-eight-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207627/Thug-25-ordered-American-XL-bully-savage-motorist-jailed-eight-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 12:06:52+00:00

Jepson from Penketh, Warrington, Cheshire, was jailed for eight years on Friday, after admitting causing grievous bodily harm with intent and being in charge of a dangerously out of control dog.

## Fury over the PPE graveyard: Mountain of thousands of unused packs of aprons and masks fly-tipped
 - [https://www.dailymail.co.uk/news/article-12207557/Fury-PPE-graveyard-Mountain-thousands-unused-packs-aprons-masks-fly-tipped.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207557/Fury-PPE-graveyard-Mountain-thousands-unused-packs-aprons-masks-fly-tipped.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 12:06:31+00:00

Shocking pictures show hoards of aprons and suspected face masks left in an enormous heap in the New Forest town of Calmore, bordering Testwood Lakes Nature Reserve.

## Student, 20, claims staff at her accommodation 'threw out all belongings while she was on holiday'
 - [https://www.dailymail.co.uk/news/article-12207655/Student-20-claims-staff-accommodation-threw-belongings-holiday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207655/Student-20-claims-staff-accommodation-threw-belongings-holiday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 12:04:41+00:00

Laoise Murphy, from Stockport, Manchester, burst into tears when she realised her room at Ardcairn House in Dublin had been completely emptied upon returning on June 13 after a trip.

## I'm a Five Guys superfan and my hack can get you a free cheeseburger
 - [https://www.dailymail.co.uk/news/article-12203911/Im-Five-Guys-superfan-hack-free-cheeseburger.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203911/Im-Five-Guys-superfan-hack-free-cheeseburger.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 11:45:38+00:00

TikTok user HellthyJunkFood revealed a hack for how customers can buy one cheeseburger at the beloved fast food chain - and get another thrown in.

## I'm a mom-of-three who lost my entire $401(K) to a scammer I met on Tinder
 - [https://www.dailymail.co.uk/news/article-12199731/Im-mom-three-lost-entire-401-K-scammer-met-Tinder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12199731/Im-mom-three-lost-entire-401-K-scammer-met-Tinder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 11:45:17+00:00

A recently divorced mom-of-three has revealed how she lost her entire 401(K) to a scammer she met on Tinder after he convinced her to invest in bogus cryptocurrency schemes.

## Tourists, workers and shoppers abandon San Francisco leaving it to homeless and drug addled
 - [https://www.dailymail.co.uk/news/article-12185831/Tourists-workers-shoppers-abandon-San-Francisco-leaving-homeless-drug-addled.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12185831/Tourists-workers-shoppers-abandon-San-Francisco-leaving-homeless-drug-addled.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 11:44:49+00:00

San Francisco has been abandoned by tourists, shoppers and office workers alike, leading the Bay City to be taken over by more than 7,000 homeless

## The CIA ran an LSD-fueled brothel - it's a $10m mansion now
 - [https://www.dailymail.co.uk/news/article-12166443/The-CIA-ran-LSD-fueled-brothel-10m-mansion-now.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12166443/The-CIA-ran-LSD-fueled-brothel-10m-mansion-now.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 11:44:27+00:00

The United States set up the illegal experiment a year after reports that the Soviet Union was using mind control techniques on American prisoners during the Korean war in 1953.

## I'm a nurse and thought I'd won $1,000 on the lottery - then I checked again
 - [https://www.dailymail.co.uk/news/article-12200351/Im-nurse-thought-Id-won-1-000-lottery-checked-again.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12200351/Im-nurse-thought-Id-won-1-000-lottery-checked-again.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 11:44:03+00:00

A travel nurse in Iowa described how as she scratched away the letters on her lottery ticket she couldn't believe how the size of her winnings continued to increase.

## Factory worker, 40, who survived Nottingham rampage after being hit by van is released from hospital
 - [https://www.dailymail.co.uk/news/article-12207567/Factory-worker-40-survived-Nottingham-rampage-hit-van-released-hospital.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207567/Factory-worker-40-survived-Nottingham-rampage-hit-van-released-hospital.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 11:43:39+00:00

Marcin Gawronski, 40, miraculously suffered only minor wounds to his head, arm and leg after the vehicle ploughed into him and two other victims, named as Wayne Birkett and Sharon Miller.

## What happened to the people from Anne Frank drama A Small Light?
 - [https://www.dailymail.co.uk/news/article-12203041/What-happened-people-Anne-Frank-drama-Small-Light.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203041/What-happened-people-Anne-Frank-drama-Small-Light.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 11:21:07+00:00

A Small Light tells the story of how Anne Frank was hidden with her mother, father and sister and the van Pels family in Amsterdam. Above: Anne is portrayed by Billie Boullet in the drama.

## Fox News anchor Bret Baier gushes over his family as he gears up to sit down with Donald Trump
 - [https://www.dailymail.co.uk/news/article-12202875/Fox-News-anchor-Bret-Baier-gushes-family-gears-sit-Donald-Trump.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202875/Fox-News-anchor-Bret-Baier-gushes-family-gears-sit-Donald-Trump.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 11:18:40+00:00

Bret Baier, 52, gave DailyMail.com an exclusive interview ahead of Father's Day where he gushed over how his family 'grounds' him.

## Stagecoach billionaire Ann Gloag puts one of her Highland castles up for sale for £7.5m
 - [https://www.dailymail.co.uk/news/article-12207571/Stagecoach-billionaire-Ann-Gloag-puts-one-Highland-castles-sale-7-5m.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207571/Stagecoach-billionaire-Ann-Gloag-puts-one-Highland-castles-sale-7-5m.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 11:15:34+00:00

The 26-bedroom 11th century castle in Inverness-shire is up for sale for £7.5 million, having been bought by Stagecoach tycoon Dame Ann Gloag for around £1.3 million in 1994

## Weather forecast: Sydney, Melbourne, Brisbane, Adelaide, Perth: Aussies to shiver with 'icy blast'
 - [https://www.dailymail.co.uk/news/article-12207479/Weather-forecast-Sydney-Melbourne-Brisbane-Adelaide-Perth-Aussies-shiver-icy-blast.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207479/Weather-forecast-Sydney-Melbourne-Brisbane-Adelaide-Perth-Aussies-shiver-icy-blast.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 11:14:37+00:00

Snow, heavy rain, damaging winds are expected across Australia as winter begins to bite. Even the normally bone dry north west of Western Australia won't escape.

## 60 Minutes reporter Tom Steinfort is bitten by 'assassin bug'
 - [https://www.dailymail.co.uk/news/article-12207573/Watch-painful-moment-60-Minutes-reporter-Tom-Steinfort-bitten-assassin-bug.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207573/Watch-painful-moment-60-Minutes-reporter-Tom-Steinfort-bitten-assassin-bug.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 11:11:44+00:00

A 60 Minutes reporter was left flapping and jerking around in extreme agony after being deliberately bitten on the hand by an assassin bug.

## Police launch appeal to find missing 12-year-old schoolgirl who vanished two days ago
 - [https://www.dailymail.co.uk/news/article-12207621/Police-launch-appeal-missing-12-year-old-schoolgirl-vanished-two-days-ago.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207621/Police-launch-appeal-missing-12-year-old-schoolgirl-vanished-two-days-ago.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 11:05:13+00:00

Schoolgirl Hannah Binns, 12, was last seen at home in Pontefract around 9pm on Friday.

## Most US voters say transgender ideology is being promoted too aggressively
 - [https://www.dailymail.co.uk/news/article-12204105/Most-voters-say-transgender-ideology-promoted-aggressively.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12204105/Most-voters-say-transgender-ideology-promoted-aggressively.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 11:03:20+00:00

The DailyMail.com/J.L. Partners poll suggests that Americans are relatively open to non-traditional lifestyles, but increasingly concerned by the growing prominence of trans ideas in the nation's cultural life.

## Dozens of migrants arrive in Dover just days after more than 200 were intercepted
 - [https://www.dailymail.co.uk/news/article-12207541/Dozens-migrants-arrive-Dover-just-days-200-intercepted.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207541/Dozens-migrants-arrive-Dover-just-days-200-intercepted.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 11:02:56+00:00

The Typhoon cutter was seen bringing the small crowd of people to shore as the number of arrivals into the country continues to increase amid the warmer weather.

## DeSantis has a better chance of beating Biden in 2024 than Trump, according to DailyMail.com poll
 - [https://www.dailymail.co.uk/news/article-12203979/DeSantis-better-chance-beating-Biden-2024-Trump-according-DailyMail-com-poll.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203979/DeSantis-better-chance-beating-Biden-2024-Trump-according-DailyMail-com-poll.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 11:02:54+00:00

With 17 months to go until the general election, a DailyMail.com/J.L. Partners poll show there is still everything to play for with Biden lagging among independent voters.

## Half of all Democrats say Joe Biden is too old to be president, according to DailyMail.com poll
 - [https://www.dailymail.co.uk/news/article-12203995/Half-Democrats-say-Joe-Biden-old-president-according-DailyMail-com-poll.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203995/Half-Democrats-say-Joe-Biden-old-president-according-DailyMail-com-poll.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 11:02:03+00:00

A new poll for DailyMail.com lays bare the challenge facing President Joe Biden as he runs for reelection: Almost three quarters of voters believe he is too old for the job.

## More than half of voters think Trump should have been charged, even if most see politics at work
 - [https://www.dailymail.co.uk/news/article-12204005/More-half-voters-think-Trump-charged-politics-work.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12204005/More-half-voters-think-Trump-charged-politics-work.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 11:00:56+00:00

A majority of voters believe the federal indictment of Donald Trump was justified, according to a new DailyMail.com/JL Partners poll, even though half also believe it was politically motivated.

## Trump is a 'criminal' and Biden is 'old': Voters give one-word verdicts on 2024 candidates
 - [https://www.dailymail.co.uk/news/article-12204007/Trump-criminal-Biden-old-Voters-one-word-verdicts-2024-candidates.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12204007/Trump-criminal-Biden-old-Voters-one-word-verdicts-2024-candidates.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 11:00:14+00:00

Ask voters for the one word that springs to mind when they think of leading Republican and Democratic candidates for the 2024 election and the results are not flattering.

## How a six-year-old in a US primary school shot his teacher, 25, in the chest with his mum's handgun
 - [https://www.dailymail.co.uk/news/article-12202113/How-six-year-old-primary-school-shot-teacher-25-chest-mums-handgun.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12202113/How-six-year-old-primary-school-shot-teacher-25-chest-mums-handgun.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 10:58:56+00:00

First-grade teacher Abigail Zwerner, 25, was shot by the boy at Richneck Elementary School in Newport News, Virginia on January 6 this year while she was trying to protect 20 other pupils.

## Falklands war hero scammed for £20k on holiday denied refund by Barclays is forced to sell medals
 - [https://www.dailymail.co.uk/news/article-12190547/Falklands-war-hero-scammed-20k-holiday-denied-refund-Barclays-forced-sell-medals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12190547/Falklands-war-hero-scammed-20k-holiday-denied-refund-Barclays-forced-sell-medals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 10:50:53+00:00

EXCLUSIVE: Falklands war hero Royal Marine Henry Williams (pictured), 63, who fell victim to a £20,000 card scam while holidaying in Brazil was refused a refund by Barclays bank.

## Multiple people are shot at Illinois shopping mall
 - [https://www.dailymail.co.uk/news/article-12207611/Multiple-people-shot-Illinois-shopping-mall.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207611/Multiple-people-shot-Illinois-shopping-mall.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 10:42:59+00:00

Emergency services have responded to a 'mass casualty' event at Willowbrook Shopping Mall in Illinois after gunfire erupted and 'multiple people' were shot.

## How Meghan Markle could become the highest-paid influencer in the world
 - [https://www.dailymail.co.uk/news/article-12207415/How-Meghan-Markle-highest-paid-influencer-world.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207415/How-Meghan-Markle-highest-paid-influencer-world.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 10:31:50+00:00

EXCLUSIVE: Brand and culture expert Nick Ede said today that 'Meghan could become one of the biggest influencers in the world' and 'could command millions' by becoming the face of Dior.

## Heart-stopping moment reckless women are just seconds away from being hit by a train
 - [https://www.dailymail.co.uk/news/article-12207473/Heart-stopping-moment-reckless-women-just-seconds-away-hit-train.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207473/Heart-stopping-moment-reckless-women-just-seconds-away-hit-train.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 10:21:31+00:00

Two women were caught on CCTV wandering over the level crossing in Elsenham, Essex moments before an oncoming train thundered past.

## Pat Cummins relative allegedly stabbed at Macquarie Park train station and taunted by trolls
 - [https://www.dailymail.co.uk/news/article-12207459/Pat-Cummins-relative-allegedly-stabbed-Macquarie-Park-train-station-taunted-trolls.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207459/Pat-Cummins-relative-allegedly-stabbed-Macquarie-Park-train-station-taunted-trolls.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 10:06:57+00:00

A close teenage relative of Australian cricket captain Pat Cummins was left fighting for his life after allegedly being stabbed by knife-wielding thugs.

## Moment sex offender, 26, who squirted semen over women gave himself up to police
 - [https://www.dailymail.co.uk/news/article-12207345/Moment-sex-offender-26-squirted-semen-women-gave-police.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207345/Moment-sex-offender-26-squirted-semen-women-gave-police.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 09:58:21+00:00

Willbert Mukori, 26, called 101 following a CCTV appeal on social media to admit the images were of him, before demanding that police remove the online appeal and initially denying 16 offences.

## Everyday Aussies reveal how they really feel about the Brittany Higgins saga
 - [https://www.dailymail.co.uk/news/article-12197437/Everyday-Aussies-reveal-really-feel-Brittany-Higgins-saga.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12197437/Everyday-Aussies-reveal-really-feel-Brittany-Higgins-saga.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 09:47:00+00:00

Four years, two explosive interviews, a collapsed trial, a massive compensation payout, ongoing defamation suits and a torrent of leaks later, the case is still dominating the political agenda

## Terrifying photos show orcas try to sink family's 42ft yacht off coast of Gibraltar
 - [https://www.dailymail.co.uk/news/article-12207461/Terrifying-photos-orcas-try-sink-familys-42ft-yacht-coast-Gibraltar.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207461/Terrifying-photos-orcas-try-sink-familys-42ft-yacht-coast-Gibraltar.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 09:27:57+00:00

Dave Duffy felt a strong whack against his 42ft yacht at 3am and found a large orca ramming his rudder. He woke his wife and asked for help to steer the yacht which veered violently in the encounter.

## Farm worker tragically dies in freak accident after being crushed to death by a hay bale
 - [https://www.dailymail.co.uk/news/article-12207487/Farm-worker-tragically-dies-freak-accident-crushed-death-hay-bale.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207487/Farm-worker-tragically-dies-freak-accident-crushed-death-hay-bale.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 08:56:13+00:00

A man has died in a tragic freak accident on a Victorian farm. Paramedics were called to a property at Greendale an hour west of Melbourne to treat a man, 64, who was injured while working on a farm.

## Twelve-year-olds are taught about anal sex in school while nine-year-olds told to 'masturbate'
 - [https://www.dailymail.co.uk/news/article-12189041/Twelve-year-olds-taught-anal-sex-school-nine-year-olds-told-masturbate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12189041/Twelve-year-olds-taught-anal-sex-school-nine-year-olds-told-masturbate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 08:53:05+00:00

EXCLUSIVE: MailOnline has found teaching material - including a sex manual for pre-teens - being used in compulsory classes around the UK.

## Furious Michael Gove blasts 'terrible' video shows Tory staff at lockdown-mocking party
 - [https://www.dailymail.co.uk/news/article-12207405/Furious-Michael-Gove-blasts-terrible-video-shows-Tory-staff-lockdown-mocking-party.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207405/Furious-Michael-Gove-blasts-terrible-video-shows-Tory-staff-lockdown-mocking-party.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 08:52:17+00:00

Speaking to Sky News' Sophy Ridge on Sunday a furious Mr Gove said he hoped all those filmed were 'contrite', adding: 'It is terrible. I think it is completely out of order.'

## Residents locked in row with neighbour as they try to evict her over her pet geese
 - [https://www.dailymail.co.uk/news/article-12207431/Residents-locked-row-neighbour-try-evict-pet-geese.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207431/Residents-locked-row-neighbour-try-evict-pet-geese.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 08:49:56+00:00

Residents claim Sharon Davis is breaching her tenancy agreement by allowing her 'aggressive' pet geese and her horse to roam freely in the small community on land owned by Raymond Hollocks.

## London councils milk motorists for £1.4BN in five years
 - [https://www.dailymail.co.uk/news/article-12203531/London-councils-milk-motorists-1-4BN-five-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203531/London-councils-milk-motorists-1-4BN-five-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 08:47:34+00:00

According to figures supplied to MailOnline from London boroughs, some 5.4 million £160 Penalty Charge Notices (PCNs) have been issued during that period.

## Hollywood director Ridley Scott's former Grade II-listed home goes on the market
 - [https://www.dailymail.co.uk/news/article-12207315/Hollywood-director-Ridley-Scotts-former-Grade-II-listed-home-goes-market.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207315/Hollywood-director-Ridley-Scotts-former-Grade-II-listed-home-goes-market.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 08:43:06+00:00

Old Grove House had been the home of the Oscar-winning director behind box-office hits Gladiator and Alien for 15 years before he oversaw refurbishment in 2006.

## Dog found surrounded by barbed wire in a car at Caves Beach NSW
 - [https://www.dailymail.co.uk/news/article-12207321/Dog-surrounded-barbed-wire-car-Caves-Beach-NSW.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207321/Dog-surrounded-barbed-wire-car-Caves-Beach-NSW.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 08:35:44+00:00

'No excuse for animal cruelty': outrage at the sight of a dog trapped inside a car 'full of barbed wire' at a popular beach.

## SNP voters abandon party after fraud probe arrest of Nicola Sturgeon as poll gives Labour more seats
 - [https://www.dailymail.co.uk/news/article-12207435/SNP-voters-abandon-party-fraud-probe-arrest-Nicola-Sturgeon-poll-gives-Labour-seats.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207435/SNP-voters-abandon-party-fraud-probe-arrest-Nicola-Sturgeon-poll-gives-Labour-seats.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 08:06:59+00:00

A Panelbase survey for the Sunday Times projects that Scottish Labour would win 26 seats at Westminster, up from one currently.

## Fury over council's £50,000 spend on LGBT-friendly rainbow junction
 - [https://www.dailymail.co.uk/news/article-12207351/Fury-councils-50-000-spend-LGBT-friendly-rainbow-junction.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207351/Fury-councils-50-000-spend-LGBT-friendly-rainbow-junction.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 07:53:12+00:00

The four crossings, painted in the coloured stripes of the Progressive Pride flag, was rolled out in Chiswick High Road in February by Labour-run Hounslow council.

## Meet the family renovating ex-footballer Jermaine Pennant's abandoned Cheshire mansion
 - [https://www.dailymail.co.uk/news/article-12203187/Meet-family-renovating-ex-footballer-Jermaine-Pennants-abandoned-Cheshire-mansion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12203187/Meet-family-renovating-ex-footballer-Jermaine-Pennants-abandoned-Cheshire-mansion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 07:49:46+00:00

EXCLUSIVE: Steve Leonard, 47, and his family are set on returning Jermaine Pennant's abandoned mansion (pictured) in Cheshire to its former glory, MailOnline can reveal.

## Primary schools in some London boroughs will be 'left out of pocket'
 - [https://www.dailymail.co.uk/news/article-12207343/Primary-schools-London-boroughs-left-pocket.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207343/Primary-schools-London-boroughs-left-pocket.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 07:35:17+00:00

Under the London Mayor's plan, all primary school children in the capital will receive free school meals for September, but some boroughs have warned there is not enough cash to foot the bill.

## Earthquake: Sydney residents hear a 'huge bang like an explosion
 - [https://www.dailymail.co.uk/news/article-12207383/Earthquake-Sydney-residents-hear-huge-bang-like-explosion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207383/Earthquake-Sydney-residents-hear-huge-bang-like-explosion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 07:33:06+00:00

A magnitude 3.1 earthquake has been recorded in Sydney 's south west.

## Met Office warn floods and thunderstorms could hit the country today with a month's worth of rain
 - [https://www.dailymail.co.uk/news/article-12207305/Met-Office-warn-floods-thunderstorms-hit-country-today-months-worth-rain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207305/Met-Office-warn-floods-thunderstorms-hit-country-today-months-worth-rain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 07:31:00+00:00

Experts are warning more than three inches of rain (80mm) could fall in the space of just three hours in some areas England and Wales this afternoon and evening.

## Earthquake: Sydney residents hear a 'huge bang like an explosion
 - [https://www.dailymail.co.uk/news/article-12207331/Magnitude-3-1-earthquake-rocks-regional-NSW.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207331/Magnitude-3-1-earthquake-rocks-regional-NSW.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 07:26:14+00:00

Magnitude 3.1 earthquake recorded in Appin - 20 kilometres northwest of Wollongong.

## Brisbane truckie relieves himself in a Teak Lane laneway at Victoria Point
 - [https://www.dailymail.co.uk/news/article-12207103/Brisbane-truckie-relieves-Teak-Lane-laneway-Victoria-Point.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207103/Brisbane-truckie-relieves-Teak-Lane-laneway-Victoria-Point.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 07:24:19+00:00

A man's unfortunate toilet time has become part of a state inquest into the safety of a public corridor which the local community has described as a crime hotspot.

## What WILL Just Stop Oil say? Labour's Keir Starmer 'tells energy giants he won't pull plug on oil'
 - [https://www.dailymail.co.uk/news/article-12207327/What-Just-Stop-Oil-say-Labours-Keir-Starmer-tells-energy-giants-wont-pull-plug-oil.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207327/What-Just-Stop-Oil-say-Labours-Keir-Starmer-tells-energy-giants-wont-pull-plug-oil.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 07:14:20+00:00

The Labour leader reportedly spoke to senior executives ahead of the launch of his party's green energy policy tomorrow.

## South Australian real estate agent sends 'threatening' email to tenant
 - [https://www.dailymail.co.uk/news/article-12207153/South-Australian-real-estate-agent-sends-threatening-email-tenant.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207153/South-Australian-real-estate-agent-sends-threatening-email-tenant.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 06:36:42+00:00

A real estate agent has been slammed online after sending a threatening email to a tenant late on their payments.

## Father of man charged with executing his 3 boys said his son 'seemed fine' during visit one week ago
 - [https://www.dailymail.co.uk/news/article-12207169/Father-man-charged-executing-3-boys-said-son-fine-visit-one-week-ago.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207169/Father-man-charged-executing-3-boys-said-son-fine-visit-one-week-ago.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 06:23:38+00:00

The father of the man accused of executing his three sons said something in him must've 'just snapped.'

## Brisbane comedian recalls assault that left him in intensive care, unable to walk or hear
 - [https://www.dailymail.co.uk/news/article-12207219/Brisbane-comedian-recalls-assault-left-intensive-care-unable-walk-hear.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207219/Brisbane-comedian-recalls-assault-left-intensive-care-unable-walk-hear.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 06:22:02+00:00

A young Aussie comedian has recalled his sickening assault where he was left on a road with 'blood coming out of my head'.

## Paul Frost: MasterChef Australia finalist sexually abused 11 children, betrayed IKEA executive wife
 - [https://www.dailymail.co.uk/news/article-12196963/Paul-Frost-MasterChef-Australia-finalist-sexually-abused-11-children-betrayed-IKEA-executive-wife.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12196963/Paul-Frost-MasterChef-Australia-finalist-sexually-abused-11-children-betrayed-IKEA-executive-wife.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 06:21:53+00:00

Ivana Frost was furniture and homeware giant IKEA's national food manager when Paul Douglas Frost was arrested at their Sydney home and charged with child sex offences.

## Anna Sorokin gets testy in first TV interview since release from prison with Chris Cuomo
 - [https://www.dailymail.co.uk/news/article-12207229/Anna-Sorokin-gets-testy-TV-interview-release-prison-Chris-Cuomo.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207229/Anna-Sorokin-gets-testy-TV-interview-release-prison-Chris-Cuomo.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 06:20:58+00:00

Notorious fraud Anna Sorokin was clearly frustrated with NewsNation's Chris Cuomo in her first television interview since her release from prison, as she attempted to move on.

## Joe Rogan challenges furious vaccine researcher to debate anti-vaxxer RFK Jr
 - [https://www.dailymail.co.uk/news/article-12207209/Joe-Rogan-challenges-furious-vaccine-researcher-debate-anti-vaxxer-RFK-Jr.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207209/Joe-Rogan-challenges-furious-vaccine-researcher-debate-anti-vaxxer-RFK-Jr.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 06:18:22+00:00

Dr. Peter Hotez, a pediatrician and dean of the National School of Tropical Medicine at Baylor College of Medicine, on Saturday tweeted his concerns about the RFK interview.

## Heartbreaking photo lays bear toll of Hunter Valley wedding bus crash on AFL team
 - [https://www.dailymail.co.uk/news/article-12200807/Photo-Hunter-Valley-wedding-bus-crash-AFL-team.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12200807/Photo-Hunter-Valley-wedding-bus-crash-AFL-team.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 06:06:01+00:00

An eerie Facebook post reveals the devastation the Hunter Valley bus crash has wrought on the Singleton Roosters AFL football club which lost seven players from the women's and men's sides.

## Embattled MMA star Conor McGregor breaks cover in NYC after footage shows him with accuser
 - [https://www.dailymail.co.uk/news/article-12206965/Embattled-MMA-star-Conor-McGregor-breaks-cover-NYC-footage-shows-accuser.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12206965/Embattled-MMA-star-Conor-McGregor-breaks-cover-NYC-footage-shows-accuser.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 06:03:56+00:00

Days after being accused of sexually assaulting a woman at an NBA Finals game, Conor McGregor broke cover as he stepped out on the streets of New York City and left with gifts and balloons for a party.

## Tragedy as boy, 6, dies a month after lighting strike killed his dad while they were holding hands
 - [https://www.dailymail.co.uk/news/article-12207167/Tragedy-boy-6-dies-month-lighting-strike-killed-dad-holding-hands.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207167/Tragedy-boy-6-dies-month-lighting-strike-killed-dad-holding-hands.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 06:02:28+00:00

Grayson Boggs (pictured) was holding hands with his dad Matthew (right) last month when a lightning strike hit them both, killing Matthew instantly. After a month in a coma, Grayson has tragically died.

## Ted Cruz demands Joe Biden reveal the source of his $10M income in 2017
 - [https://www.dailymail.co.uk/news/article-12207079/Ted-Cruz-demands-Joe-Biden-reveal-source-10M-income-2017.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207079/Ted-Cruz-demands-Joe-Biden-reveal-source-10M-income-2017.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 05:52:04+00:00

After his term in the Obama White House ended, Biden and his wife Jill signed a lucrative multi-book deal valued at $8 million, and launched a speaking tour that brought in millions.

## Teenager dies in Boggabilla crash after car hits power pole south of Queensland border
 - [https://www.dailymail.co.uk/news/article-12207077/Teenager-dies-Boggabilla-crash-car-hits-power-pole-south-Queensland-border.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207077/Teenager-dies-Boggabilla-crash-car-hits-power-pole-south-Queensland-border.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 05:48:47+00:00

NSW Police said the incident occurred in Boggabilla, just south of the Queensland border, at about 1am.

## Teenage girl Lilly Hayes, 16, dies after Queensland Gunalda country road car crash
 - [https://www.dailymail.co.uk/news/article-12207179/Teenage-girl-Lilly-Hayes-16-dies-Queensland-Gunalda-country-road-car-crash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207179/Teenage-girl-Lilly-Hayes-16-dies-Queensland-Gunalda-country-road-car-crash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 05:28:26+00:00

A  devastated family is mourning the loss of their 'sassy' 16-year-old daughter who was caught up in a horror head-on crash on a rural dirt backroad in Queensland a little over a week ago.

## OSHA blames American Airlines subsidiary for death of employee and fines airline $15k
 - [https://www.dailymail.co.uk/news/article-12207093/American-Airlines-fined-15K-woman-violently-sucked-plane-engine-New-Years-Eve.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207093/American-Airlines-fined-15K-woman-violently-sucked-plane-engine-New-Years-Eve.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 05:21:25+00:00

An American Airlines subsidy is facing a $15,000 fine after an airline worker died when she was so violently 'ingested' into the engine of a landed plane it shook the entire aircraft.

## Man, 87, dies after attack on Hastings Street at Noosa Heads in Queensland
 - [https://www.dailymail.co.uk/news/article-12207049/Man-dies-attack-Hastings-Street-Noosa-Heads-Queensland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207049/Man-dies-attack-Hastings-Street-Noosa-Heads-Queensland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 05:18:18+00:00

Police say emergency crews were called to Hastings Street on the tourist strip after reports a man had been assaulted about 6am on Sunday.

## Letter complaining about Cobram man Darren Laffan's car horn put in his postbox
 - [https://www.dailymail.co.uk/news/article-12207009/Letter-complaining-Cobram-man-Darren-Laffans-car-horn-postbox.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207009/Letter-complaining-Cobram-man-Darren-Laffans-car-horn-postbox.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 05:15:15+00:00

A letter urging a well known charity worker stop 'friends and followers' tooting car horns in appreciation as they pass his house is dividing locals in a small town.

## Prisoner charged after inmate found dead in cell at Yatala Labour Prison in Adelaide's Northfield
 - [https://www.dailymail.co.uk/news/article-12207191/Prisoner-charged-inmate-dead-cell-Yatala-Labour-Prison-Adelaides-Northfield.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207191/Prisoner-charged-inmate-dead-cell-Yatala-Labour-Prison-Adelaides-Northfield.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 05:12:24+00:00

At about 5:35 pm on Saturday police and emergency services rushed to the Yatala Labour Prison, in the Adelaide suburb of Northfield.

## Don't look down! Massive bear hangs from side of Colorado home in attempt to make daring escape
 - [https://www.dailymail.co.uk/news/article-12207047/Dont-look-Massive-bear-hangs-Colorado-home-attempt-make-daring-escape.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207047/Dont-look-Massive-bear-hangs-Colorado-home-attempt-make-daring-escape.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 04:59:36+00:00

A Colorado brown bear swung from the window of a house it had broken into for several minutes before deciding there was a better way out.

## Neighbor of NYC financier accused of raping girl, 14, says child was often seen around his apartment
 - [https://www.dailymail.co.uk/news/article-12207065/Neighbor-NYC-financier-accused-raping-girl-14-says-child-seen-apartment.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207065/Neighbor-NYC-financier-accused-raping-girl-14-says-child-seen-apartment.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 04:55:42+00:00

Michael Olson (pictured) was allegedly regularly seen with a young girl outside his Manhattan apartment long before his disturbing indictment over claims he drugged and raped a girl, 14.

## Nationals' Bridget McKenzie 'aware of rumours' before David Van sexual assault allegations
 - [https://www.dailymail.co.uk/news/article-12207011/Nationals-Bridget-McKenzie-aware-rumours-David-Van-sexual-assault-allegations.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12207011/Nationals-Bridget-McKenzie-aware-rumours-David-Van-sexual-assault-allegations.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 04:25:28+00:00

Senator Van resigned from the Liberal Party a day before a committee was due to discuss allegations he inappropriately touched three women.

## Rochedale State High School teacher, Bradley Flavel, pleads guilty after sexually assaulting girl
 - [https://www.dailymail.co.uk/news/article-12206983/Rochedale-State-High-School-teacher-Bradley-Flavel-pleads-guilty-sexually-assaulting-girl.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12206983/Rochedale-State-High-School-teacher-Bradley-Flavel-pleads-guilty-sexually-assaulting-girl.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 03:16:58+00:00

Bradley William Flavel, 31, plead guilty to two counts of indecent treatment of a child under the age of 16 and one count of carnal knowledge with a child under the age of 16 on Friday.

## Registered sex offender Warren 'Wazza' Wright disowned by charities Beyond Blue and R U OK?
 - [https://www.dailymail.co.uk/news/article-12206909/Registered-sex-offender-Warren-Wazza-Wright-disowned-charities-Blue-R-U-OK.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12206909/Registered-sex-offender-Warren-Wazza-Wright-disowned-charities-Blue-R-U-OK.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 02:27:20+00:00

Two charities have denied having any links with a convicted child sex offender who is travelling from town to town in north west Victoria claiming to be raising money for mental health issues.

## Masseuse caught with drugs after leaving Andrew O'Keefe's house is fined
 - [https://www.dailymail.co.uk/news/article-12206915/Masseuse-caught-drugs-leaving-Andrew-OKeefes-house-fined.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12206915/Masseuse-caught-drugs-leaving-Andrew-OKeefes-house-fined.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 02:19:36+00:00

Mitchell Rees Sturt, 52, was stopped by officers moments after exiting Andrew O'Keefe's Vaucluse home in Sydney's eastern suburbs during the early hours of November 24.

## Beloved star of Discovery Channel's Flying Wild Alaska dies in small plane crash above state
 - [https://www.dailymail.co.uk/news/article-12206821/Beloved-star-Discovery-Channels-Flying-Wild-Alaska-dies-small-plane-crash-state.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12206821/Beloved-star-Discovery-Channels-Flying-Wild-Alaska-dies-small-plane-crash-state.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 01:27:04+00:00

Bush pilot Jim Tweto, the star of Discovery Channel's 'Flying Wild Alaska', was killed along with a hunting and fishing guide from Idaho when their small plane crashed shortly after takeoff Friday.

## Wall Street should brace for a big collapse after recent rally, warns Bank of America analyst
 - [https://www.dailymail.co.uk/news/article-12206901/Wall-Street-brace-big-collapse-recent-rally-warns-Bank-America-analyst.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12206901/Wall-Street-brace-big-collapse-recent-rally-warns-Bank-America-analyst.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 01:23:09+00:00

Bank of America Chief Investment Strategist Michael Hartnett doesn't believe it's the start of a 'brand, new shiny bull market' but that stocks are headed for 'big rally before big collapse.'

## NSW police dog bites into teenager's arm after boy fled cops during South Kempsey arrest
 - [https://www.dailymail.co.uk/news/article-12206829/NSW-police-dog-bites-teenagers-arm-boy-fled-cops-South-Kempsey-arrest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12206829/NSW-police-dog-bites-teenagers-arm-boy-fled-cops-South-Kempsey-arrest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 01:15:08+00:00

Police visited a house on Reginald Ward Street in South Kempsey, north of Port Macquarie, just before 1pm on Thursday.

## Antony Blinken in Beijing: Secretary of State lands in China on diplomatic mission
 - [https://www.dailymail.co.uk/news/article-12206973/Antony-Blinken-Beijing-Secretary-State-lands-China-diplomatic-mission.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12206973/Antony-Blinken-Beijing-Secretary-State-lands-China-diplomatic-mission.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 01:07:52+00:00

Blinken was to begin two days of talks with senior Chinese officials in the afternoon. He is the highest-level American official to visit China since President Joe Biden took office.

## Bruce Highway crash: Car flips after being hit by truck on main road into Brisbane
 - [https://www.dailymail.co.uk/news/article-12206899/Bruce-Highway-crash-Car-flips-hit-truck-main-road-Brisbane.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12206899/Bruce-Highway-crash-Car-flips-hit-truck-main-road-Brisbane.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 01:04:10+00:00

Video shared by Dashcam Owners Australia this week stated said the collision occurred on the Bruce Highway coming into Brisbane.

## Kevin Costner's wife looks unbothered as she leaves $145million home she refuses to vacate
 - [https://www.dailymail.co.uk/news/article-12206865/Kevin-Costners-wife-looks-unbothered-leaves-145million-home-refuses-vacate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12206865/Kevin-Costners-wife-looks-unbothered-leaves-145million-home-refuses-vacate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 01:02:58+00:00

Kevin Costner's estranged wife Christine Baumgartner was spotted Saturday, looking crabby as she ran errands near her family home in Carpinteria, California.

## Prince William pledges to 'end homelessness' and plans to build social housing on Duchy of Cornwall
 - [https://www.dailymail.co.uk/news/article-12206891/Prince-William-pledges-end-homelessness-plans-build-social-housing-Duchy-Cornwall.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12206891/Prince-William-pledges-end-homelessness-plans-build-social-housing-Duchy-Cornwall.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 00:58:24+00:00

William spoke in his first interview since becoming the Prince of Wales, and used it to explain that he is determined to 'make a difference... that doesn't set people up that are homeless for another fall'.

## Brittany Higgins and David Sharaz political masterplan before meeting The Project's Lisa Wilkinson
 - [https://www.dailymail.co.uk/news/article-12201545/Brittany-Higgins-David-Sharaz-political-masterplan-meeting-Projects-Lisa-Wilkinson.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12201545/Brittany-Higgins-David-Sharaz-political-masterplan-meeting-Projects-Lisa-Wilkinson.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 00:54:51+00:00

Leaked audio reveals Brittany Higgins and partner David Sharaz had schemed to ensure the explosive allegations would cause the biggest uproar in Canberra before the next federal election.

## Keir Starmer's chief of staff Sue Gray 'could have been sacked from civil service' after Labour move
 - [https://www.dailymail.co.uk/news/article-12206955/Keir-Starmers-chief-staff-Sue-Gray-sacked-civil-service-Labour-move.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12206955/Keir-Starmers-chief-staff-Sue-Gray-sacked-civil-service-Labour-move.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 00:53:40+00:00

Sue Gray (pictured), the top civil servant poached by Sir Keir Starmer to be his new chief of staff did breach Whitehall impartiality rules, an official Cabinet Office inquiry said, it was reported last night.

## Mystery over the condition of Kyiv's 'incredibly ruthless' spy chief
 - [https://www.dailymail.co.uk/news/article-12206895/Mystery-condition-Kyivs-incredibly-ruthless-spy-chief.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12206895/Mystery-condition-Kyivs-incredibly-ruthless-spy-chief.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 00:52:25+00:00

Major-General Kyrylo Budanov, 37, was last seen in early June in a flashy promotional video from the Ukrainian military about their counter-offensive, titled Plans Love Silence.

## Ex-Oasis manager Alan McGee denies two allegations of rape as Metropolitan Police launch probe
 - [https://www.dailymail.co.uk/news/article-12206857/Ex-Oasis-manager-Alan-McGee-denies-two-allegations-rape-Metropolitan-Police-launch-probe.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12206857/Ex-Oasis-manager-Alan-McGee-denies-two-allegations-rape-Metropolitan-Police-launch-probe.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 00:52:04+00:00

Alan McGee, 62, has been accused of two separate rapes in Southwark and Kensington and Chelsea in London, it was revealed last night.

## Is Meghan about to become the mega-bucks Duchess of Dior?
 - [https://www.dailymail.co.uk/news/article-12206159/Is-Meghan-mega-bucks-Duchess-Dior.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12206159/Is-Meghan-mega-bucks-Duchess-Dior.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 00:50:05+00:00

CAROLINE GRAHAM: The Duchess has been immersed in meetings since signing with Emanuel, as Netflix conducts an 'ongoing review' of £80 million deal.

## SNP fraud detectives probe 'cash in envelopes' claims
 - [https://www.dailymail.co.uk/news/article-12206851/SNP-fraud-detectives-probe-cash-envelopes-claims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12206851/SNP-fraud-detectives-probe-cash-envelopes-claims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 00:49:43+00:00

Allegations made by a whistleblower state that senior party figures received tens of thousands of pounds from a Scottish businessman related to a prominent nationalist politician.

## It's click-and-collect... at Glastonbury! Festivalgoers can order shopping to the campsite
 - [https://www.dailymail.co.uk/news/article-12206877/Its-click-collect-Glastonbury-Festivalgoers-order-shopping-campsite.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12206877/Its-click-collect-Glastonbury-Festivalgoers-order-shopping-campsite.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 00:11:05+00:00

Last year, revellers complained about vendors' 'rip-off' prices, with pints of beer costing from £6 and a slice of Margherita pizza priced at £7.

## Woman pressured into breast removal at 13 under 'erroneous belief' she was transgender: lawsuit
 - [https://www.dailymail.co.uk/news/article-12206847/Woman-pressured-breast-removal-13-erroneous-belief-transgender-lawsuit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12206847/Woman-pressured-breast-removal-13-erroneous-belief-transgender-lawsuit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 00:11:05+00:00

Kayla Lovdahl (pictured) slammed the medical industry that pushed her to have a double mastectomy aged just 13 as 'ideological and profit-driven medical abuse' in a bombshell new lawsuit.

## Motorcyclist dies after crashing bike into St Nicholas Anglican Church in Goulburn
 - [https://www.dailymail.co.uk/news/article-12206743/Motorcyclist-dies-crashing-bike-St-Nicholas-Anglican-Church-Goulburn.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12206743/Motorcyclist-dies-crashing-bike-St-Nicholas-Anglican-Church-Goulburn.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 00:10:09+00:00

Emergency services were called to St Nicholas Anglican Church on Kinghorne St in Goulburn after the man was found by a passer-by just before 8.30pm.

## Car smashed into Sydney Guildford front yard after high-speed police chase
 - [https://www.dailymail.co.uk/news/article-12206749/Car-smashed-Sydney-Guildford-yard-high-speed-police-chase.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12206749/Car-smashed-Sydney-Guildford-yard-high-speed-police-chase.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-06-18 00:06:20+00:00

Youseff Rima, 37, allegedly rolled his Hyundai Tucson SUV after reaching speeds of up to 140km/h in Guildford, western Sydney, at 11pm on Friday.

