# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## Missing Chicago man Noah Enos found dead; body pulled from Chicago River near concert venue
 - [https://www.foxnews.com/us/missing-chicago-man-noah-enos-found-dead-body-pulled-chicago-river-near-concert-venue](https://www.foxnews.com/us/missing-chicago-man-noah-enos-found-dead-body-pulled-chicago-river-near-concert-venue)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 18:41:50+00:00

The body of Chicago man Noah Enos, who went missing on Monday night after a concert at the Salt Shed, was pulled from the Chicago River near the venue on Saturday morning.

## Read this before signing up for Amazon Clinic
 - [https://www.foxnews.com/tech/read-this-before-signing-up-amazon-clinic](https://www.foxnews.com/tech/read-this-before-signing-up-amazon-clinic)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 18:38:21+00:00

Looking for a cheaper way to get health care? An affordable option is Amazon Clinic, but can you trust it with your health information?

## Texas mom arrested after dangling infant son out of third-story window: police
 - [https://www.foxnews.com/us/texas-mom-arrested-dangling-infant-son-third-story-window](https://www.foxnews.com/us/texas-mom-arrested-dangling-infant-son-third-story-window)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 18:24:29+00:00

A Houston-area mom is behind bars on child endangerment charges after she was photographed dangling her infant son out of the window of a third-story building.

## Gordon Sargent wraps first US Open appearance with unusual putting issue on 18
 - [https://www.foxnews.com/sports/gordon-sargent-wraps-first-us-open-appearance-unusual-putting-issue](https://www.foxnews.com/sports/gordon-sargent-wraps-first-us-open-appearance-unusual-putting-issue)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 18:21:41+00:00

Amateur golfer Gordon Sargent saw his tap-in on the 18th hole bank out of the cup after it looked like it was going in. He finished with a bogey.

## West Nile virus season: What you must know about spread, symptoms and prevention
 - [https://www.foxnews.com/health/west-nile-virus-season-know-spread-symptoms-prevention](https://www.foxnews.com/health/west-nile-virus-season-know-spread-symptoms-prevention)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 18:09:32+00:00

As reports of the year’s first West Nile virus cases start to trickle in from across the U.S., here’s what you need to know about spread, symptoms and prevention.

## Max Verstappen gives Red Bull its 100th win with victory at Canadian Grand Prix
 - [https://www.foxnews.com/sports/max-verstappen-gives-red-bull-100th-win-victory-canadian-grand-prix](https://www.foxnews.com/sports/max-verstappen-gives-red-bull-100th-win-victory-canadian-grand-prix)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 17:42:47+00:00

Max Verstappen picked up a victory at the Canadian Grand Prix and gave his tea, Red Bull, its 100th career win. Fernando Alonso finished second and Lewis Hamilton in third.

## Patriots' Jack Jones appeared to criticize Ja Morant's gun drama before NFL player's own weapons arrest
 - [https://www.foxnews.com/sports/patriots-jack-jones-appeared-criticize-ja-morants-gun-drama-nfl-players-own-weapons-arrest](https://www.foxnews.com/sports/patriots-jack-jones-appeared-criticize-ja-morants-gun-drama-nfl-players-own-weapons-arrest)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 17:37:10+00:00

New England Patriots cornerback Jack Jones appeared to criticize Memphis Grizzlies star Ja Morant for the NBA player&apos;s gun issues before being arrested on weapons charges himself.

## 'Spreading Satanism': Poland's 666 bus route to Hel gets number change
 - [https://www.foxnews.com/world/spreading-satanism-polands-666-bus-route-hel-gets-number-change](https://www.foxnews.com/world/spreading-satanism-polands-666-bus-route-hel-gets-number-change)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 16:58:20+00:00

The popular Polish 666 bus line to the resort town of Hel is getting a name change after complaints by religious conservatives in the country mounted in recent years.

## Taylor Swift celebrates Father’s Day amid confirmation of ‘Cruel Summer’ single
 - [https://www.foxnews.com/entertainment/taylor-swift-celebrates-fathers-day-amid-confirmation-cruel-summer-single](https://www.foxnews.com/entertainment/taylor-swift-celebrates-fathers-day-amid-confirmation-cruel-summer-single)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 16:52:03+00:00

Taylor Swift gave a shout out to her dad during the Pittsburgh stop of her Eras tour, as she confirmed the news that her 2019 song &quot;Cruel Summer&quot; will be her next single.

## Pennsylvania police rescue 6 ducklings from storm drain
 - [https://www.foxnews.com/lifestyle/pennsylvania-police-ducklings-storm-drain](https://www.foxnews.com/lifestyle/pennsylvania-police-ducklings-storm-drain)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 16:44:45+00:00

Police in Upper Makefield Township, Pennsylvania, rescued six baby ducklings on Saturday that became trapped in a storm drain system near Crimson Leaf Drive and Greenbriar Court.

## Suns to acquire All-Star guard Bradley Beal in blockbuster trade with Wizards: report
 - [https://www.foxnews.com/sports/suns-acquire-all-star-guard-bradley-beal-blockbuster-trade-wizards-report](https://www.foxnews.com/sports/suns-acquire-all-star-guard-bradley-beal-blockbuster-trade-wizards-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 16:39:57+00:00

Bradley Beal is heading to the Phoenix Suns, joining Kevin Durant and Devin Booker in the desert after a blockbuster trade with the Washington Wizards

## Houston rapper Big Pokey dead at 45
 - [https://www.foxnews.com/entertainment/houston-rapper-big-pokey-dead-45](https://www.foxnews.com/entertainment/houston-rapper-big-pokey-dead-45)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 16:38:33+00:00

Big Pokey died in Texas after reportedly collapsing during a show at a rooftop bar on Saturday. The Houston rapper&apos;s cause of death is not immediately known.

## Young Red Sox supporter receives foul ball from generous fan, subsequently fires it back onto field
 - [https://www.foxnews.com/sports/young-red-sox-supporter-receives-foul-ball-generous-fans-subsequently-fires-back-onto-field](https://www.foxnews.com/sports/young-red-sox-supporter-receives-foul-ball-generous-fans-subsequently-fires-back-onto-field)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 16:34:08+00:00

A young Boston Red Sox fan stunned those around him when he took the ball that was gifted to him by a fellow spectator sitting near him and tossed it back onto the field.

## PolitiFact rates Biden's claim gay people are kicked out of restaurants 'mostly true'
 - [https://www.foxnews.com/media/politifact-rates-bidens-claim-gay-people-kicked-restaurants-mostly-true](https://www.foxnews.com/media/politifact-rates-bidens-claim-gay-people-kicked-restaurants-mostly-true)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 16:30:04+00:00

PolitiFact rated President Biden’s statement during Pride Month that gay people can be legally married and thrown out of restaurants as “mostly true.&quot;

## US Open co-leader Wyndham Clark calls late third-round tee times 'a little ridiculous'
 - [https://www.foxnews.com/sports/u-s-open-co-leader-wyndham-clark-calls-late-third-round-tee-times-little-ridiculous](https://www.foxnews.com/sports/u-s-open-co-leader-wyndham-clark-calls-late-third-round-tee-times-little-ridiculous)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 16:07:31+00:00

U.S. Open co-leader Wyndham Clark loves that he&apos;s in the final pairing going into Sunday, but he thought the third round was a &apos;little ridiculous&apos; with how late they teed off.

## Washington state man accidentally fires gun in restaurant, hitting 2 people
 - [https://www.foxnews.com/us/washington-state-man-accidentally-fires-gun-restaurant-hitting-2-people](https://www.foxnews.com/us/washington-state-man-accidentally-fires-gun-restaurant-hitting-2-people)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 15:50:56+00:00

A Washington man surrendered himself and his firearm to police on Saturday after he walked into a restaurant and the gun he was carrying accidentally discharged, striking two people.

## Prince William celebrates Father’s Day with George, Charlotte, and Louis in sweet family photo
 - [https://www.foxnews.com/entertainment/prince-william-celebrates-fathers-day-george-charlotte-louis-sweet-family-photo](https://www.foxnews.com/entertainment/prince-william-celebrates-fathers-day-george-charlotte-louis-sweet-family-photo)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 15:44:07+00:00

Prince William&apos;s social media pages for the Prince and Princess of Wales shared a sweet family photo with his kids, George, Charlotte, and Louis.

## Cardinals' World Series hero David Freese declines invitation to team's Hall of Fame
 - [https://www.foxnews.com/sports/cardinals-world-series-hero-david-freese-declines-invitation-teams-hall-of-fame](https://www.foxnews.com/sports/cardinals-world-series-hero-david-freese-declines-invitation-teams-hall-of-fame)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 15:40:31+00:00

David Freese, who helped the St. Louis Cardinals win the World Series in 2011, declined the invitation to be inducted into the team&apos;s Hall of Fame.

## NASA’s Juno spacecraft captures photo of lightning glow on Jupiter during close fly-by of gas giant world
 - [https://www.foxnews.com/science/nasas-juno-spacecraft-captures-photo-lightning-glow-jupiter-close-fly-by](https://www.foxnews.com/science/nasas-juno-spacecraft-captures-photo-lightning-glow-jupiter-close-fly-by)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 15:24:25+00:00

NASA on Thursday released a photo of lightning on Jupiter&apos;s north pole taken by the spacecraft Juno during an orbiting mission in 2020.

## NCAA panel recommends marijuana be dropped from banned substance list
 - [https://www.foxnews.com/sports/ncaa-panel-recommends-marijuana-dropped-banned-substance-list](https://www.foxnews.com/sports/ncaa-panel-recommends-marijuana-dropped-banned-substance-list)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 15:13:27+00:00

An NCAA panel on Friday recommended the removal of marijuana from the list of banned drugs and that testing should be limited to performance-enhancing substances.

## Sketch artist responds after critics rebuff him for portraying Trump as 'too young,' 'good looking'
 - [https://www.foxnews.com/politics/sketch-artist-william-hennessy-jr-responds-after-critics-rebuff-him-for-portraying-trump-as-too-young-good-looking](https://www.foxnews.com/politics/sketch-artist-william-hennessy-jr-responds-after-critics-rebuff-him-for-portraying-trump-as-too-young-good-looking)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 15:02:05+00:00

Sketch artist William J. Hennessy Jr. responded to criticisms he portrayed former President Donald Trump as younger and more fit than reality during his arraignment in Miami.

## ABC host shocked by post Trump indictment polling showing 'statistical tie': 'What does that say about Biden?'
 - [https://www.foxnews.com/media/abc-host-shocked-by-post-trump-indictment-polling-showing-statistical-tie-what-does-that-say-about-biden](https://www.foxnews.com/media/abc-host-shocked-by-post-trump-indictment-polling-showing-statistical-tie-what-does-that-say-about-biden)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 15:00:39+00:00

Jonathan Karl appeared shocked during ABC&apos;s &quot;This Week&quot; on Sunday while discussing a poll showing Biden and Trump in a &quot;statistical tie&quot; after the indictment.

## A beginner's guide to ordering sushi in honor of International Sushi Day
 - [https://www.foxnews.com/lifestyle/beginners-guide-ordering-sushi-honor-international-sushi-day](https://www.foxnews.com/lifestyle/beginners-guide-ordering-sushi-honor-international-sushi-day)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 14:53:06+00:00

Sushi can be confusing to order if you&apos;ve never gotten it before. If you aren&apos;t sure what kind of sushi to order and what to expect, you can find all the answers in this guide.

## Conor McGregor signs autographs in New York days after rape allegations
 - [https://www.foxnews.com/sports/conor-mcgregor-signs-autographs-new-york-days-after-rape-allegations](https://www.foxnews.com/sports/conor-mcgregor-signs-autographs-new-york-days-after-rape-allegations)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 14:39:25+00:00

Days after rape allegations surfaced, Conor McGregor was spotted in New York City signing autographs for fans waiting outside his hotel.

## When jet ski meets sports car you get this ultimate watercraft
 - [https://www.foxnews.com/tech/jet-ski-meets-sports-car-get-ultimate-watercraft](https://www.foxnews.com/tech/jet-ski-meets-sports-car-get-ultimate-watercraft)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 14:35:24+00:00

JetCar California is a company that is combining jet ski and sports car technology to create a watercraft that has the best of both worlds.

## Top Pence staffer condemns Trump's last-minute pardons for 'cocaine traffickers,' family members
 - [https://www.foxnews.com/politics/top-pence-staffer-condemns-trumps-last-minute-pardons-cocaine-traffickers-family-members](https://www.foxnews.com/politics/top-pence-staffer-condemns-trumps-last-minute-pardons-cocaine-traffickers-family-members)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 14:22:50+00:00

Marc Short, former chief of staff for Vice President Mike Pence, condemned pardons former President Donald Trump handed down at the end of his term.

## Boston mayor responds after lawmakers try to slash police budget, veteran services
 - [https://www.foxnews.com/politics/boston-mayor-michelle-wu-responds-lawmakers-cut-police-budget-veteran-services](https://www.foxnews.com/politics/boston-mayor-michelle-wu-responds-lawmakers-cut-police-budget-veteran-services)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 14:18:45+00:00

Boston Mayor Michelle Wu vetoed a City Council budget proposal that had $31 million in cuts to the police department as well as $900,000 in cuts for veteran services.

## Westchester County DA closes multiyear-long Trump golf course criminal investigation
 - [https://www.foxnews.com/politics/westchester-county-da-closes-multiyear-long-trump-golf-course-criminal-investigation](https://www.foxnews.com/politics/westchester-county-da-closes-multiyear-long-trump-golf-course-criminal-investigation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 14:08:12+00:00

Westchester County DA Mimi Rocah closed a years-long investigation into former President Donald Trump&apos;s National Golf Club in New York.

## Pop-up in Giants-Dodgers game causes mayhem on field in wacky scene of events
 - [https://www.foxnews.com/sports/pop-up-giants-dodgers-game-causes-mayhem-on-field-wacky-scene](https://www.foxnews.com/sports/pop-up-giants-dodgers-game-causes-mayhem-on-field-wacky-scene)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 13:57:01+00:00

An absolute wacky scene occurred in the San Francisco Giants-Los Angeles Dodgers game on Friday night that reminded all baseball fans that even the best in the game can have blunders.

## Central Park dispute between NYC dog walkers ends with pet stabbed to death: reports
 - [https://www.foxnews.com/us/central-park-dispute-nyc-dog-walkers-ends-pet-stabbed-death-reports](https://www.foxnews.com/us/central-park-dispute-nyc-dog-walkers-ends-pet-stabbed-death-reports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 13:48:20+00:00

A German shepherd pit bull mix named Eli died after being stabbed during an argument between dog walkers in New York City&apos;s Central Park, reports said.

## Top Army official blames anti-woke rhetoric of right for severe recruiting crisis
 - [https://www.foxnews.com/us/top-army-official-blames-anti-woke-right-for-severe-recruiting-crisis](https://www.foxnews.com/us/top-army-official-blames-anti-woke-right-for-severe-recruiting-crisis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 13:34:07+00:00

Army Secretary Christine Wormuth hit back at critics who have accused the military of going &quot;woke,&quot; arguing that such critiques have contributed to the recruiting crisis.

## Chris Christie slams RNC over 'useless' presidential nominee pledge
 - [https://www.foxnews.com/politics/chris-christie-slams-rnc-useless-presidential-nominee-pledge](https://www.foxnews.com/politics/chris-christie-slams-rnc-useless-presidential-nominee-pledge)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 13:22:42+00:00

Chris Christie slammed the Republican National Committee’s requirement that candidates pledge support for the GOP’s eventual presidential nominee.

## Tommy Lee's wife says Heather Locklear was 'love of his life' not Pam Anderson
 - [https://www.foxnews.com/entertainment/tommy-lees-wife-says-heather-locklear-love-his-life-not-pam-anderson](https://www.foxnews.com/entertainment/tommy-lees-wife-says-heather-locklear-love-his-life-not-pam-anderson)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 13:00:17+00:00

Tommy Lee has had several failed relationships, but his wife Brittany Furlan says his greatest love was with Heather Locklear, not Pamela Anderson.

## Lou Williams, all-time leading scorer off the bench, retires from NBA
 - [https://www.foxnews.com/sports/lou-williams-all-time-leading-scorer-off-bench-retires-from-nba](https://www.foxnews.com/sports/lou-williams-all-time-leading-scorer-off-bench-retires-from-nba)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 12:44:00+00:00

Lou Williams, who has the most points ever off the bench by a player in league history, has officially announced his retirement from the NBA after 17 seasons.

## Rand Paul rips Bill Gates' alleged tie to gain-of-function research: 'Funding the biggest danger to mankind'
 - [https://www.foxnews.com/media/rand-paul-bill-gates-ties-gain-function-research-funding-danger-mankind](https://www.foxnews.com/media/rand-paul-bill-gates-ties-gain-function-research-funding-danger-mankind)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 12:31:11+00:00

Sen. Rand Paul, R-Ky., expanded his criticism of gain-of-function research on Sunday, calling out Microsoft exec. Bill Gates for allegedly playing a major role in its funding.

## Mike Pence dodges on Trump conviction, says indictment allegations are 'very serious'
 - [https://www.foxnews.com/politics/mike-pence-dodges-trump-conviction-says-allegations-very-serious](https://www.foxnews.com/politics/mike-pence-dodges-trump-conviction-says-allegations-very-serious)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 12:19:21+00:00

Former President Donald Trump deserves the chance to defend himself in court, says former Vice President Mike Pence, who dodged on whether Trump should be convicted.

## Totally free, fun things to do with or for dad on Father's Day if you're on a tight budget
 - [https://www.foxnews.com/lifestyle/free-fun-things-dad-fathers-day](https://www.foxnews.com/lifestyle/free-fun-things-dad-fathers-day)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 12:09:36+00:00

Father&apos;s Day is a time when families across America celebrate their dads and everything they do. It&apos;s a special day — and there are a number of free things you can do with your dad.

## Coast Guard intercepts $186M in cocaine across Atlantic, Caribbean
 - [https://www.foxnews.com/us/coast-guard-intercepts-186m-cocaine-atlantic-caribbean](https://www.foxnews.com/us/coast-guard-intercepts-186m-cocaine-atlantic-caribbean)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 11:52:31+00:00

The U.S. Coast Guard offloaded $186 million worth of cocaine after seizing the drugs in multiple cases across the Caribbean Sea and Atlantic Ocean.

## Tim Scott slams Obama, 'radical left' on education: 'They have failed, they have failed, and they have failed'
 - [https://www.foxnews.com/politics/tim-scott-slams-obama-radical-left-education-they-have-failed-they-have-failed-they-have-failed](https://www.foxnews.com/politics/tim-scott-slams-obama-radical-left-education-they-have-failed-they-have-failed-they-have-failed)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 11:39:29+00:00

Sen. Tim Scott had harsh words for former President Barack Obama during a &quot;Fox News Sunday&quot; appearance, saying Democrats have &quot;failed&quot; on education.

## 'The Good Place' star comes out against gender-neutral award show categories: 'Completely shut out women'
 - [https://www.foxnews.com/media/good-place-star-comes-against-gender-neutral-award-show-categories-completely-shut-out-women](https://www.foxnews.com/media/good-place-star-comes-against-gender-neutral-award-show-categories-completely-shut-out-women)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 11:33:54+00:00

&quot;The Good Place&quot; star Jameela Jamil came out against gender-neutral award show categories on Saturday, suggesting non-binary people get their own category.

## No more 'old thinking;' US needs a military build-up to combat Chinese aggression: Rep. Waltz
 - [https://www.foxnews.com/media/no-more-old-thinking-us-needs-military-build-up-combat-chinese-aggression-rep-waltz](https://www.foxnews.com/media/no-more-old-thinking-us-needs-military-build-up-combat-chinese-aggression-rep-waltz)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 11:22:15+00:00

Rep. Michael Waltz said Antony Blinken&apos;s visit to China &apos;plays into Chinese propaganda and calls for an abandonment of &apos;old thinking.&apos;

## Golden Knights' William Karlsson delivers epic drunk speech, has mic pulled away at Stanley Cup victory parade
 - [https://www.foxnews.com/sports/golden-knights-william-karlsson-delivers-epic-drunk-speech-mic-pulled-away-stanley-cup-victory-parade](https://www.foxnews.com/sports/golden-knights-william-karlsson-delivers-epic-drunk-speech-mic-pulled-away-stanley-cup-victory-parade)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 11:19:29+00:00

The Golden Knights were partying hard on the Las Vegas strip, as they celebrated their Stanley Cup victory. But no player topped William Karlsson&apos;s energy during his epic speech.

## Squatter teacher, family invade luxury home as homeowner faces months-long eviction battle: realtor
 - [https://www.foxnews.com/us/squatter-teacher-family-invade-luxury-home-as-homeowner-faces-months-long-eviction-battle-realtor](https://www.foxnews.com/us/squatter-teacher-family-invade-luxury-home-as-homeowner-faces-months-long-eviction-battle-realtor)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 11:08:24+00:00

A public school teacher in Houston, Texas, finally vacated a home where she and her family were allegedly squatting since January, according to local reports.

## Texas Rangers remain only MLB team without Pride Night: 'Our commitment is to make everyone feel welcome'
 - [https://www.foxnews.com/sports/texas-rangers-remain-only-mlb-team-without-pride-night](https://www.foxnews.com/sports/texas-rangers-remain-only-mlb-team-without-pride-night)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 10:31:17+00:00

All MLB teams have their own Pride Night to celebrate the LGBTQ+ community except one: the Texas Rangers. The organization explained why that is, while its fan base supports it.

## Company offers ‘baby bonus’ for employees in effort to combat ‘anti-family’ push towards abortion
 - [https://www.foxnews.com/media/company-offers-baby-bonus-employees-effort-combat-anti-family-push-towards-abortion](https://www.foxnews.com/media/company-offers-baby-bonus-employees-effort-combat-anti-family-push-towards-abortion)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 10:21:04+00:00

PublicSq. CEO and founder Michael Seifert told &apos;Fox &amp; Friends Weekend&apos; the &apos;baby bonus&apos; is designed to counter the far-left&apos;s &apos;anti-family&apos; business push.

## Why Father's Day reveals an American crisis
 - [https://www.foxnews.com/opinion/fathers-day-reveals-american-crisis](https://www.foxnews.com/opinion/fathers-day-reveals-american-crisis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 10:00:43+00:00

On Father&apos;s Day, we give thanks for these indispensable men.

## DANGEROUS: China expert warns Xi Jinping has set 'time frame' to annex Taiwan
 - [https://www.foxnews.com/media/dangerous-china-expert-warns-xi-jinping-time-frame-annex-taiwan](https://www.foxnews.com/media/dangerous-china-expert-warns-xi-jinping-time-frame-annex-taiwan)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 10:00:22+00:00

China expert Gordon Chang and Former Secretary of State Mike Pompeo lay out the nature of Xi Jinping&apos;s thirst for power and the possibility of an impending Taiwan invasion.

## 'The Chosen' creator Dallas Jenkins looks to counter the decline of religion in America with hit biblical show
 - [https://www.foxnews.com/media/the-chosen-creator-dallas-jenkins-counter-decline-religion-america](https://www.foxnews.com/media/the-chosen-creator-dallas-jenkins-counter-decline-religion-america)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 10:00:16+00:00

&apos;The Chosen&apos; creator and director Dallas Jenkins discusses the success of his hit biblical series and the drop in importance of religion in America on &apos;The Story with Martha MacCallum.&apos;

## Prince Louis goes viral again with hysterical antics on royal balcony for Trooping the Colour ceremony
 - [https://www.foxnews.com/entertainment/prince-louis-goes-viral-again-hysterical-antics-royal-balcony-trooping-colour-ceremony](https://www.foxnews.com/entertainment/prince-louis-goes-viral-again-hysterical-antics-royal-balcony-trooping-colour-ceremony)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 09:56:27+00:00

Prince Louis stole the spotlight again for his viral facial expressions on the balcony of Buckingham Palace after the Trooping the Colour ceremony.

## On Father's Day, let's stop putting down dads and their key roles in kids' lives, say pastor and professor
 - [https://www.foxnews.com/lifestyle/on-fathers-day-lets-stop-putting-down-dads-roles-kids-lives-say-pastor-professor](https://www.foxnews.com/lifestyle/on-fathers-day-lets-stop-putting-down-dads-roles-kids-lives-say-pastor-professor)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 09:52:33+00:00

Lauren Green of Fox News Channel interviewed a Pennsylvania pastor and a Texas-based professor and author to reveal the critical role of fathers today in their children&apos;s lives.

## Tiger Woods' ex-girlfriend going to appeals court as sexual harassment lawsuit continues: report
 - [https://www.foxnews.com/sports/tiger-woods-ex-girlfriend-going-appeals-court-sexual-harassment-lawsuit-continues](https://www.foxnews.com/sports/tiger-woods-ex-girlfriend-going-appeals-court-sexual-harassment-lawsuit-continues)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 09:45:00+00:00

Tiger Woods&apos; ex-girlfriend, Erica Herman, isn&apos;t giving up on her legal battle in which she accuses the golf star of sexual harassment. She is now going to appeals court.

## Massive cyberattack strikes millions: Are you at risk?
 - [https://www.foxnews.com/tech/massive-cyberattack-strikes-millions-risk](https://www.foxnews.com/tech/massive-cyberattack-strikes-millions-risk)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 09:34:57+00:00

A massive cyberattack targeted private information that could affect millions of Americans, Kurt &quot;CyberGuy&quot; Knutsson explains how to keep your info safe.

## Reporter's Notebook: Return to Ukraine where 'tragedy continues to touch all'
 - [https://www.foxnews.com/world/reporters-notebook-return-ukraine-tragedy-continues-to-touch-all](https://www.foxnews.com/world/reporters-notebook-return-ukraine-tragedy-continues-to-touch-all)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 09:10:10+00:00

Greg Palkot Fox News&apos; senior foreign affairs correspondent is back in Kyiv reporting for his sixth stint in 18 months. Palkot returns as Russia&apos;s war against Ukraine continues with no end in sight.

## Florida professor spends 100 days underwater, shares the effects on the human body: 'Pretty impressive'
 - [https://www.foxnews.com/media/florida-professor-spends-100-days-underwater-shares-effects-human-body-pretty-impressive](https://www.foxnews.com/media/florida-professor-spends-100-days-underwater-shares-effects-human-body-pretty-impressive)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 09:00:20+00:00

Florida professor Dr. Joseph Dituri joined &apos;The Story&apos; to discuss the new world record he set for the longest time living underwater.

## Philippine coast guard rescue 120 people from flaming ferry
 - [https://www.foxnews.com/world/philippine-coast-guard-rescue-120-people-flaming-ferry](https://www.foxnews.com/world/philippine-coast-guard-rescue-120-people-flaming-ferry)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 08:52:45+00:00

The Philippine coast guard rescued all 120 people on board a ferry after the craft burst into flames on Sunday while traveling between two islands.

## Texas student graduates high school at 14, just like her sister
 - [https://www.foxnews.com/media/texas-student-graduates-high-school-14-sister](https://www.foxnews.com/media/texas-student-graduates-high-school-14-sister)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 08:30:54+00:00

Oforitsenere Bodunrin graduated high school and is set to graduate college at only 18 years of age, and she is considering a future among tech companies or artificial intelligence.

## Shooting near Washington amphitheatre leaves at least 2 dead, 3 wounded; suspect arrested
 - [https://www.foxnews.com/us/shooting-washington-state-amphitheatre-leaves-dead-wounded-suspect-arrested](https://www.foxnews.com/us/shooting-washington-state-amphitheatre-leaves-dead-wounded-suspect-arrested)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 08:08:54+00:00

Authorities in Washington State said at least two victims were killed Saturday when a suspect fired shots near the Beyond Wonderland music festival.

## Sammy Hagar says he is 'so proud' that son Andrew Hagar is following in his rock star footsteps
 - [https://www.foxnews.com/entertainment/sammy-hagar-proud-son-andrew-hagar-following-rock-star-footsteps](https://www.foxnews.com/entertainment/sammy-hagar-proud-son-andrew-hagar-following-rock-star-footsteps)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 08:00:55+00:00

Sammy Hagar and his son Andrew Hagar sat down for an interview ahead of Father&apos;s Day. The former Van Halen frontman said that he is &quot;so proud&quot; of his son&apos;s music career.

## We can 'trust God's heart' on Father's Day and every day, says Washington faith leader
 - [https://www.foxnews.com/lifestyle/we-trust-gods-heart-fathers-day-day-washington-faith-leader](https://www.foxnews.com/lifestyle/we-trust-gods-heart-fathers-day-day-washington-faith-leader)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 08:00:51+00:00

God the Father protects his people in the same way fathers should be protecting their families, Pastor Jesse Bradley of Washington State told Fox News Digital for the Father&apos;s Day occasion.

## Moon in solar system has elements needed to support life: scientists
 - [https://www.foxnews.com/science/moon-solar-system-has-elements-needed-support-life-scientists](https://www.foxnews.com/science/moon-solar-system-has-elements-needed-support-life-scientists)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 08:00:46+00:00

Scientists studying data collected by NASA&apos;s Cassini mission found Saturn&apos;s moon Enceladus has the necessary materials to make it habitable.

## Joni Ernst says she knows what Iowans want in a 2024 GOP nominee
 - [https://www.foxnews.com/politics/joni-ernst-knows-iowans-want-2024-gop-nominee](https://www.foxnews.com/politics/joni-ernst-knows-iowans-want-2024-gop-nominee)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 08:00:42+00:00

Sen. Joni Ernst said Iowa voters and others across the country want a presidential candidate who can &quot;pull together&quot; a divided country in 2024.

## WATCH: Young Americans reject gender-neutral replacement for Father's Day: ‘Nah, it’s crazy’
 - [https://www.foxnews.com/media/watch-young-americans-reject-gender-neutral-replacement-fathers-day-nah-its-crazy](https://www.foxnews.com/media/watch-young-americans-reject-gender-neutral-replacement-fathers-day-nah-its-crazy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 08:00:35+00:00

When asked, Northern Virginia residents rejected the idea of banning Father&apos;s Day or replacing it with a more &quot;gender inclusive&quot; holiday.

## What military families like mine feel on Father’s Day
 - [https://www.foxnews.com/opinion/what-military-families-like-mine-feel-fathers-day](https://www.foxnews.com/opinion/what-military-families-like-mine-feel-fathers-day)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 08:00:04+00:00

This will be a different Father’s Day for my family and many other military families in South Carolina

## Comedy master Will Ferrell: From SNL sensation to box office king
 - [https://www.foxnews.com/entertainment/comedy-master-will-ferrell-snl-sensatio-box-office-king](https://www.foxnews.com/entertainment/comedy-master-will-ferrell-snl-sensatio-box-office-king)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 07:51:59+00:00

Will Ferrell is an American entertainer renowned for his comedic personalitity across film, television, and the stage. He rose to prominence as a cast member on &quot;Saturday Night Live.&quot;

## Father's Day in Hollywood: Kids who have joined their dads in blockbuster movies and hit TV shows
 - [https://www.foxnews.com/entertainment/hollywood-kids-joined-dads-blockbuster-movies-hit-tv-shows](https://www.foxnews.com/entertainment/hollywood-kids-joined-dads-blockbuster-movies-hit-tv-shows)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 07:21:49+00:00

There are several celebrity dads in Hollywood whose kids have grown and become part of the entertainment business. A number of actors have shared the stage with their real-life kids.

## Docuseries film crew attacked by tiger sharks: 'Like something out of 'Jaws' '
 - [https://www.foxnews.com/us/docuseries-film-crew-attacked-by-tiger-sharks-off-hawaii-coast-like-something-out-of-jaws](https://www.foxnews.com/us/docuseries-film-crew-attacked-by-tiger-sharks-off-hawaii-coast-like-something-out-of-jaws)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 07:00:57+00:00

A film crew working on a docuseries for Netflix off the coast of Hawaiian islands was reportedly attacked by aggressive tiger sharks during a shoot.

## Sweet tri-colored tabby cat named Qwerty is looking for a home in DC
 - [https://www.foxnews.com/lifestyle/sweet-tri-colored-tabby-cat-qwerty-looking-home-dc](https://www.foxnews.com/lifestyle/sweet-tri-colored-tabby-cat-qwerty-looking-home-dc)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 07:00:51+00:00

A &quot;social butterfly&quot; tri-color tabby cat named Qwerty is looking for a home in the Washington, D.C., area after she was rescued from a hoarding situation. Qwerty is medium-sized and playful.

## Comer reveals plans to bring in more witnesses for 'Biden family influence-peddling' probe
 - [https://www.foxnews.com/media/comer-reveals-plans-bring-more-witnesses-biden-family-influence-peddling-probe](https://www.foxnews.com/media/comer-reveals-plans-bring-more-witnesses-biden-family-influence-peddling-probe)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 07:00:15+00:00

House Oversight Committee Chairman James Comer says there are more witnesses to come regarding his panel&apos;s probe of President Biden&apos;s alleged influence peddling.

## Virginia wildlife officials trespassed on man’s land, stole his trail camera, lawsuit alleges
 - [https://www.foxnews.com/us/virginia-wildlife-officials-trespassed-mans-land-stole-trail-camera-lawsuit-alleges](https://www.foxnews.com/us/virginia-wildlife-officials-trespassed-mans-land-stole-trail-camera-lawsuit-alleges)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 06:30:07+00:00

A Virginia homeowner says game wardens trespassed on his property and stole his trail camera without a warrant. Now he&apos;s taking on a century-old Supreme Court decision.

## Multiple casualties in Illinois shooting: reports
 - [https://www.foxnews.com/us/multiple-casualties-illinois-shooting-reports](https://www.foxnews.com/us/multiple-casualties-illinois-shooting-reports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 05:38:29+00:00

Multiple people were reportedly wounded after a shooting near Willowbrook, Illinois, Saturday evening. Shots were fired into a group of at least 200 people.

## Texas boy, 6, dies from same lightning bolt that killed his father weeks earlier
 - [https://www.foxnews.com/us/texas-boy-6-dies-same-lightning-bolt-killed-his-father-weeks-earlier](https://www.foxnews.com/us/texas-boy-6-dies-same-lightning-bolt-killed-his-father-weeks-earlier)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 04:43:46+00:00

A Texas boy died from a lightning bolt that struck him and his father as they were walking home together from school. The boy&apos;s father also died from the lightning.

## Pennsylvania governor says collapsed part of I-95 in Philly will reopen within 2 weeks
 - [https://www.foxnews.com/us/pennsylvania-governor-says-collapsed-part-i-95-philly-reopen-within-2-weeks](https://www.foxnews.com/us/pennsylvania-governor-says-collapsed-part-i-95-philly-reopen-within-2-weeks)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 03:43:23+00:00

Pennsylvania Gov. Josh Shapiro said after touring the collapsed stretch of Interstate 95 in Philadelphia with President Biden that the roadway will reopen within two weeks.

## Man impersonating ICE agent in Maryland forces woman to perform oral sex after threatening deportation
 - [https://www.foxnews.com/us/man-impersonating-ice-agent-maryland-forces-woman-perform-oral-sex-after-threatening-deportation](https://www.foxnews.com/us/man-impersonating-ice-agent-maryland-forces-woman-perform-oral-sex-after-threatening-deportation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 02:06:25+00:00

A man pretending to be an ICE officer allegedly sexually assaulting a woman in a parking lot in Maryland after threatening her with deportation.

## West Virginia coach Bob Huggins steps down just hours after DUI arrest: 'I must do better'
 - [https://www.foxnews.com/sports/west-virginia-coach-bob-huggins-steps-down-in-wake-of-dui-arrest](https://www.foxnews.com/sports/west-virginia-coach-bob-huggins-steps-down-in-wake-of-dui-arrest)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 01:12:08+00:00

Bob Huggins was one of the most successful, yet divisive college basketball coaches of his era. He won 345 games at WVU, but his last few months were stepped in controversy.

## On this day in history, June 18, 1983, astronaut Sally Ride becomes first American woman in space
 - [https://www.foxnews.com/lifestyle/this-day-history-june-18-1983-astronaut-sally-ride-first-american-woman-space](https://www.foxnews.com/lifestyle/this-day-history-june-18-1983-astronaut-sally-ride-first-american-woman-space)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-06-18 00:02:05+00:00

Sally Ride made history as the first American woman in space on this day in history, June 18, 1983. Ride was one of six women picked for the astronaut class of 1978.

