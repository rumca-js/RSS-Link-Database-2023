# Source:MeatCanyon, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC91V6D3nkhP89wUb9f_h17g, language:en-US

## GUTTERBALL | Melvins Macabre
 - [https://www.youtube.com/watch?v=Y_-GmJONl6c](https://www.youtube.com/watch?v=Y_-GmJONl6c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC91V6D3nkhP89wUb9f_h17g
 - date published: 2023-06-18 17:22:20+00:00

MELVIN PLUSH AND MERCH HERE:
https://meatcanyon.store/collections/all


MEATCANYON TRADING CARDS:
https://trdng.shop/products/meatcanyon




Subscribe to my Patreon:
https://www.patreon.com/meatcanyon




Animators:
Jerb: https://twitter.com/jerbjpg?s=20

Vudujin: https://twitter.com/Vudujin

DublyMike: https://twitter.com/dublymike?s=20

Fantishow" https://twitter.com/Fantishow?s=20

Jamie R : https://youtube.com/@JaimeR2D

Awez: https://mobile.twitter.com/aweztube\

Zeurel: https://twitter.com/Zeurel?s=20

RedMinus: https://twitter.com/RedMinus?s=20


3D Animation done by Hoolopee:
https://twitter.com/hoolopee?s=20



BG Artist:
Kuo Yang: https://www.artstation.com/kuoyang

Peatrick: https://twitter.com/thepeeetrick?s=20

OkMichie: https://twitter.com/okmichie_art?s=20

Mrmattzan: https://instagram.com/mrmattzan?igshid=YmMyMTA2M2Y=


COMP FX:
Molly Wright: https://www.youtube.com/c/wollymight


Audio Design:
https://twitter.com/imadeasong?s=20

Composer and additional voice acting:
Alex Walker Smith: https://www.youtube.com/alexwalkersmith

