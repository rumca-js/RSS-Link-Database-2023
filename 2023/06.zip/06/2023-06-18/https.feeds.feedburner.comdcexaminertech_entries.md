# Source:Washington Examiner - Tech, URL:https://feeds.feedburner.com/dcexaminer/tech, language:en-US

## Space race: 40th anniversary of Sally Ride's flight as first American woman in space
 - [https://www.washingtonexaminer.com/policy/space/space-race-40th-anniversary-of-sally-rides-flight-as-first-american-woman-in-space](https://www.washingtonexaminer.com/policy/space/space-race-40th-anniversary-of-sally-rides-flight-as-first-american-woman-in-space)
 - RSS feed: https://feeds.feedburner.com/dcexaminer/tech
 - date published: 2023-06-18 11:00:38+00:00

Sally Ride became the first American woman in space on June 18, 1983, breaking barriers for women to pursue careers in STEM fields.

