# Source:The Intercept, URL:https://theintercept.com/feed/?lang=en, language:en-US

## How Exxon Captured a Country Without Firing a Shot
 - [https://theintercept.com/2023/06/18/guyana-exxon-mobil-oil-drilling/](https://theintercept.com/2023/06/18/guyana-exxon-mobil-oil-drilling/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2023-06-18 10:00:00+00:00

<p>Guyana is poised to become Exxon’s top global oil producer. Where the company ends and the government begins is increasingly unclear.</p>
<p>The post <a href="https://theintercept.com/2023/06/18/guyana-exxon-mobil-oil-drilling/" rel="nofollow">How Exxon Captured a Country Without Firing a Shot</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>

