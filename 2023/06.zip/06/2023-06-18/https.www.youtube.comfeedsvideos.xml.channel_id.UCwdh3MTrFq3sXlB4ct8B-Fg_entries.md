# Source:Warhammer, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg, language:en-US

## This Week in Warhammer – Warhammer 40,000 Essentials
 - [https://www.youtube.com/watch?v=NAnIhZTXSYc](https://www.youtube.com/watch?v=NAnIhZTXSYc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg
 - date published: 2023-06-18 17:00:12+00:00

Rule books, index cards, and more – check out this week's Warhammer highlights. https://bit.ly/465C0lk

