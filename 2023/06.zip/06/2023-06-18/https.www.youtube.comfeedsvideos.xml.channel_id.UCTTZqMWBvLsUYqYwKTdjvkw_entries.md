# Source:Mateusz Chrobok, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw, language:pl-PL

## Blokowanie telemarketerów - czy warto?
 - [https://www.youtube.com/watch?v=730gNLw4JX0](https://www.youtube.com/watch?v=730gNLw4JX0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw
 - date published: 2023-06-18 16:00:10+00:00

📵 Czy Was też denerwują połączenia z nieznanych numerów, które po odebraniu okazują się telemarketerami, wyłudzaczami, albo po prostu robotami?Teoretycznie istnieje proste rozwiązanie tego problemu - aplikacje blokujące niechciane połączenia. Czy jest w tym odrobina magii, czy to tylko technologia?
 
Źródła:
📞 Truecaller
https://tinyurl.com/4uvcz3b5

🤙 Those robocall blocker apps are hanging up on your privacy
https://tinyurl.com/3tbyafne

📵 Exclusive: Truecaller Database hacked by Syrian Electronic Army, webarchive
https://tinyurl.com/mttbrest

☎️ Should I Answer?
https://tinyurl.com/3knay6hm

💸 Dlaczego Androidowcy mają aplikację za darmo, a ajfonowcy (nie)muszą płacić?
https://tinyurl.com/mw23m3d3

🤖 Who’s Calling? Characterizing Robocalls through Audio and Metadata Analysis, S. Prasad et al.
https://tinyurl.com/bdd6av5h

🪛 How PKI and SHAKEN/STIR Will Fix the Global Robocall Problem
https://tinyurl.com/44e98v3z

🍸 A co to takiego ten SHAKEN/STIR?
https://tinyurl.com/nhav83ds

🧑‍🔬 STIR w bazie Internet Engineering Task Force
https://tinyurl.com/ycktmj2z

🛡️ How to block spam calls on Android
https://tinyurl.com/5femejj7
 
Jeżeli nie ufasz skracanym linkom (bardzo dobrze!) to dodaj na ich końcu plusik ‘+’.
W ten sposób podejrzysz na stronie bit.ly/tinyurl dokąd prowadzą.
 
Relevant xkcd: https://xkcd.com/2053/
 
© Wszystkie znaki handlowe należą do ich prawowitych właścicieli.
❤️ Dziękuję za Waszą uwagę.
 
Znajdziecie mnie również na:
Instagramie @mateuszemsi https://www.instagram.com/mateuszemsi/ 
Twitterze @MateuszChrobok https://twitter.com/MateuszChrobok 
Mastodonie https://infosec.exchange/@mateuszchrobok 
LinkedInie @mateuszchrobok https://www.linkedin.com/in/mateuszchrobok/ 
Patronite @MateuszChrobok https://patronite.pl/MateuszChrobok
Podcasty na: 
Anchor https://anchor.fm/mateusz-chrobok 
Spotify https://open.spotify.com/show/6y6oWs20HwRejktOWHTteR 
Apple Podcasts https://apple.co/3OwjvOh
 
Dziękuję za gościnę @rezydencjaluxuryhotel6397 z Piekar Śląskich!
 
Rozdziały:
00:00 Intro
00:56 Działanie
04:54 TrueCaller
07:17 Ośmiorniczka
09:43 Inni
13:01 Inaczej
15:03 Co Robić i Jak Żyć?
 
#telemarketing #spam #telefon #aplikacja #połączenie

