# Source:Louder With Crowder, URL:http://louderwithcrowder.com/feed/, language:en-US

## Watch: Storeowner traps shoplifter UNDER the door shutters until cops show up to arrest him
 - [https://www.louderwithcrowder.com/shoplifter-trapped-door-shutters](https://www.louderwithcrowder.com/shoplifter-trapped-door-shutters)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-06-18 14:31:38+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=34140712&amp;width=1200&amp;height=800&amp;coordinates=100%2C0%2C100%2C0" /><br /><br /><p>"Yeah, that's me. You're probably wondering how I got in this predicament."</p><p class="shortcode-media shortcode-media-rebelmouse-image">
<img alt="" class="rm-shortcode" id="db84d" src="https://www.louderwithcrowder.com/media-library/image.png?id=34140726&amp;width=980" />
</p><p>The man is Martin Trimble. One day last week, <a href="https://www.thenorthernecho.co.uk/news/23592502.durham-city-shopkeeper-traps-armed-robber-shop-shutter/" target="_blank">he walked into a Durgan City convenience store</a> and attempted to steal a four-pack of beer with a knife. Martin didn't think things through, because one of the employees fled the store to hold the door shut. When Martin tried escaping, the store owner lowered the security shutters as Martien attempted his best "Han Solo escaping the Death Star" by sliding under the shutters.<br /></p><p>SPOILER: Harrison Ford utilizes stunt doubles.</p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;">\u201cNow THIS is how you stop shoplifting.\u201d</div> — Louder with Crowder Dot Com (@Louder with Crowder Dot Com)
        <a href="https://twitter.com/LWCnewswire/status/1670431855986786304">1687096964</a>
</blockquote>
<p><a href="https://www.foxnews.com/world/watch-shop-clerk-traps-would-be-thief-store-shutter-police-arrive" target="_blank">Detective Sergeant Paul Mawson</a> arrived on the scene to arrest the epic fail of a thug, but not before dropping an all-time cop pun: "It wasn’t the most difficult arrest we have ever made. To be honest, <strong>it was an open and shut case."</strong></p><p>Martin had nothing left to do but chug the beer he attempted to steal. Might as well, right? He's already charged with attempted robbery. An extra £4.75 for a four-pack on top of that won't hurt. That's a little over six dollars in normal, American money.</p><p class="shortcode-media shortcode-media-rebelmouse-image">
<img alt="" class="rm-shortcode" id="dc6de" src="https://www.louderwithcrowder.com/media-library/image.png?id=34140735&amp;width=980" />
</p><p>It is not a  total loss for Mawson, though. My man has earned the #1 spot in LWC's Favorite Beer Related Arrests and LWC's Favorite Shoplifting fails.</p><p>The previous winner for beer arrests was the dude who got arrested for DUI while <a href="https://www.louderwithcrowder.com/bud-light-kansas-arrest" target="_blank">dressed like a giant can of Bud Light</a>. </p><p>The derpiest shoplifter went to the guy <a href="https://www.louderwithcrowder.com/louis-vuittton-thief-knocked-out" target="_blank">who attempted to steal $18000 worth of Luis Vuitton</a>, but confused a door for a window.</p><p>><p><p><p><p><p><
<p>
<em>Brodigan is Grand Poobah of this here website and when he isn't writing words about things enjoys day drinking, pro-wrestling, and country music. You can find him <a href="https://twitter.com/brodigan" target="_blank">on the Twitter</a> too.</em>
</p>
<p>
<em><strong>Facebook doesn't want you reading this post or any others lately. </strong>Their algorithm hides our stories and shenanigans as best it can. The best way to stick it to Zuckerface? <strong>Bookmark </strong><a href="https://www.louderwithcrowder.com" target="_blank"><strong>LouderWithCrowder.com</strong></a> and check us out throughout the day! </em><em>Also, follow us on <a href="https://www.instagram.com/lwcnewswire/" target="_blank">Instagram</a> and <a href="https://www.twitter.com/lwcnewswire/" target="_blank">Twitter</a>.</em>
</p></p>

## Is Yuengling sponsoring an all-ages drag show? At the very least... not anymore
 - [https://www.louderwithcrowder.com/yuengling-drag-show](https://www.louderwithcrowder.com/yuengling-drag-show)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-06-18 12:31:08+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=34140580&amp;width=1245&amp;height=700&amp;coordinates=0%2C6%2C0%2C6" /><br /><br /><p>When the internationally owned Bud Light let its woke globalism show, Americans turned to the <a href="https://www.louderwithcrowder.com/yuengling-beer-patriotic-can" target="_blank">American-owned Yuengling</a> as their beer of choice. Then it was reported that Yuengling was sponsoring an all ages-drag show. They aren't anymore. And if they ever were, it depends on how you define the word "sponsor."</p><p>Here's the story. A place called the Musikfest Cafe sponsored by Yuengling is hosting Dragging with the Divas, a "family-friendly" drag show. <a href="https://www.outkick.com/yuengling-just-showed-bud-light-how-to-properly-handle-lunacy-with-handling-of-drag-show-sponsorship/" target="_blank">In fairness to Musikfest Cafe sponsored by Yuengling</a>, they did post that it might be unsuitable for children under the age of two. But babies could sit on their parent's lap.</p><p>The problem is that Yuengling isn't sponsoring the show it any of the other shows at the cafe.</p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;">\u201cThis is a garbage story.  Yuengling has sponsored the event called Musikfest broadly since 1984.  These freaks intentionally appropriated the association.  Don\u2019t do this to good people.  We have enough to fight without making it up. @Timcast\u201d</div> — Chris Stigall (@Chris Stigall)
        <a href="https://twitter.com/ChrisStigall/status/1669662836648292356">1686913615</a>
</blockquote>

<p>Yuengling said in a tweet that they only have the naming rights to the venue, Muskifest Cafe. A separate company, ArtsQuest, does the booking of events independently. They worked with the venue to ensure that the drag show was eighteen an over.</p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;">\u201chttps://t.co/9P4bCvqrTx\u201d</div> — Yuengling Brewery (@Yuengling Brewery)
        <a href="https://twitter.com/yuenglingbeer/status/1669831570826338304">1686953845</a>
</blockquote>

<p>The event definitely was all ages. And ArtsQuests definitely sounds like a company that gets off on all-ages drag shows, In their tweet announcing the age restriction, they made it a point to hide the age change in the middle of woke mad-libs.</p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;">\u201chttps://t.co/68WWpGKfK0\u201d</div> — ArtsQuest (@ArtsQuest)
        <a href="https://twitter.com/ArtsQuest/status/1669797263399321600">1686945665</a>
</blockquote>

<p>People jumped the gun it claiming Yuengling was sponsoring the event. It went from an event posted on a website to<a href="https://www.youtube.com/watch?v=AMp-LOE1uGs" target="_blank"> Johnny and the Mothers playing at the Savoy Theatre</a>. While the right is on a roll with cultural wins (battles in the larger war), we need to not me hammers-looking. for nail. If anything, this shows how Yuengling was quick to fix a mistake.</p><p>The question is if the mistake stays fixed. Putting an age restriction on adult entertainment is what we in politics call finding common ground. As opposed to what we in reality call common sense. LGBTQ activists, neither politically nor in reality, care about common ground. <a href="https://www.louderwithcrowder.com/dodgers-pride-night-protest" target="_blank">As we saw with the Los Angles Dodgers</a>, they demand you affirm their every kink always. That goes double during the month of June.</p><p>Let's see what happens when activists try to force the venue and the beer to bend the knee. You know that's coming.</p><p>><p><p><p><p><p><
<p>
<em>Brodigan is Grand Poobah of this here website and when he isn't writing words about things enjoys day drinking, pro-wrestling, and country music. You can find him <a href="https://twitter.com/brodigan" target="_blank">on the Twitter</a> too.</em>
</p>
<p>
<em><strong>Facebook doesn't want you reading this post or any others lately. </strong>Their algorithm hides our stories and shenanigans as best it can. The best way to stick it to Zuckerface? <strong>Bookmark </strong><a href="https://www.louderwithcrowder.com" target="_blank"><strong>LouderWithCrowder.com</strong></a> and check us out throughout the day! </em><em>Also, follow us on <a href="https://www.instagram.com/lwcnewswire/" target="_blank">Instagram</a> and <a href="https://www.twitter.com/lwcnewswire/" target="_blank">Twitter</a>.</em>
</p></p>

## Watch: Joe Biden bombs so bad making a joke about sleeping with his wife, he has to explain it to the press
 - [https://www.louderwithcrowder.com/joe-biden-philadelphia-john-fetterman](https://www.louderwithcrowder.com/joe-biden-philadelphia-john-fetterman)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-06-18 11:44:56+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=34140531&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C0" /><br /><br /><p>Joe Biden held a joint press conference with John Fetterman last week.</p><p class="shortcode-media shortcode-media-rebelmouse-image">
<img alt="" class="rm-shortcode" id="19a09" src="https://www.louderwithcrowder.com/media-library/image.gif?id=34140534&amp;width=980" />
</p><p>A portion of <a href="https://www.foxnews.com/us/pennsylvania-governor-says-collapsed-part-i-95-philly-reopen-within-2-weeks" target="_blank">I-95 collapsed in Philadelphia</a> and Biden was right there to get in front of the camera. He has no problem rushing to areas of tragedy that benefit him politically. As opposed to, you know, <a href="https://www.louderwithcrowder.com/east-palestine-mayor-biden-ukraine" target="_blank">other areas of America that do not</a>. As part of the press conference, Biden said something that made sense in his brain and that he probably thought was funny. The assembled press, many of whom are lapdogs, couldn't even bring themselves to give him a sympathy chuckle. Biden talking about sleeping with his wife? Eww, gross.</p><p>The mayor of Philly thanked Biden for rushing to the site of the tragedy, <a href="https://www.louderwithcrowder.com/joe-biden-rejects-east-palestine" target="_blank">knowing the president doesn't always do that</a>. Biden, confusing the presser with open mic night at Yuk Yuks in Hazelton, said, "I might add if I didn't I'd be sleeping alone."</p><p>Dead silence. He had to explain the joke, which is never a good sign. "My wife's a Philly girl."</p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;">\u201cNailed it.\u201d</div> — Caleb Howe (@Caleb Howe)
        <a href="https://twitter.com/calebhowe/status/1670156068272349187">1687031211</a>
</blockquote>
<p>Get it? If Joey didn't rush aid to the city his wife was born in, she would kick him out of the bed they share as man and wife and make him sleep on the couch. Wocka Wocka!</p><p>Still dead silence from an adoring press. Even John Fetterman was like, "Dude, this guy's an idiot."</p><p class="shortcode-media shortcode-media-rebelmouse-image">
<img alt="" class="rm-shortcode" id="69996" src="https://www.louderwithcrowder.com/media-library/image.png?id=34140548&amp;width=980" />
</p><p>Then John Fetterman was given a chance to string together words to form sentences. Or, at the very least, make a valiant attempt to do so. Dressed in his trademark homeless chic that is<a href="https://www.louderwithcrowder.com/john-fetterman-hoodie-shorts" target="_blank"> redefining how journalismers think about political fashion</a>, it was the junior senator from Pennsylvania's turn to rock the mic. And he rocked the mic DERP.</p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;">\u201cIncredibly well spoken.\u201d</div> — Catch Up (@Catch Up)
        <a href="https://twitter.com/CatchUpFeed/status/1670107200298287104">1687019560</a>
</blockquote>
<p>Joe Biden's had his turn to think, "Dude, this guy's an idiot."</p><p class="shortcode-media shortcode-media-rebelmouse-image">
<img alt="" class="rm-shortcode" id="1df14" src="https://www.louderwithcrowder.com/media-library/image.png?id=34140550&amp;width=980" />
</p><p>Where Biden's joke fails the most? As if Jill Biden needs a transportation calamity as an excuse to not want to sleep with her husband. As it is, she is used to sleeping on the couch herself when that smell and the warm feeling on her leg wake her up again. She tries to get Joe to wear what she calls "special president underpants" to bed. But Biden is concerned if word got out, all of the other world leaders who make fun of him on the group text.</p><p>Little does Biden know the other leaders have a separate group text to make fun of Biden. And an overabundance of other reasons.</p><p>><p><p><p><p><p><
<p>
<em>Brodigan is Grand Poobah of this here website and when he isn't writing words about things enjoys day drinking, pro-wrestling, and country music. You can find him <a href="https://twitter.com/brodigan" target="_blank">on the Twitter</a> too.</em>
</p>
<p>
<em><strong>Facebook doesn't want you reading this post or any others lately. </strong>Their algorithm hides our stories and shenanigans as best it can. The best way to stick it to Zuckerface? <strong>Bookmark </strong><a href="https://www.louderwithcrowder.com" target="_blank"><strong>LouderWithCrowder.com</strong></a> and check us out throughout the day! </em><em>Also, follow us on <a href="https://www.instagram.com/lwcnewswire/" target="_blank">Instagram</a> and <a href="https://www.twitter.com/lwcnewswire/" target="_blank">Twitter</a>.</em>
</p></p>

