# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## Zadecydowały jedenastki. Hiszpania wygrała Ligę Narodów
 - [https://eurosport.tvn24.pl/pilka-nozna/liga-narodow-uefa/2022-2023/chorwacja-hiszpania-wynik-meczu-i-relacja-final-ligi-narodow_sto9665910/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/liga-narodow-uefa/2022-2023/chorwacja-hiszpania-wynik-meczu-i-relacja-final-ligi-narodow_sto9665910/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 21:37:54+00:00

<img alt="Zadecydowały jedenastki. Hiszpania wygrała Ligę Narodów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-85e7yj-luka-modric-l-7180855/alternates/LANDSCAPE_1280" />
    Wcześniej w meczu o złoto bramki nie padły.

## Nie żyje polski dziennikarz. Zasłabł podczas finału Ligi Mistrzów
 - [https://eurosport.tvn24.pl/pilka-reczna/nie-zyje-pawel-kotwica-dziennikarz.-zaslabl-podczas-finalu-ligi-mistrzow-pilkarzy-recznych_sto9665922/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-reczna/nie-zyje-pawel-kotwica-dziennikarz.-zaslabl-podczas-finalu-ligi-mistrzow-pilkarzy-recznych_sto9665922/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 20:22:12+00:00

<img alt="Nie żyje polski dziennikarz. Zasłabł podczas finału Ligi Mistrzów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hj0pyg-zmarl-dziennikarz-pawel-kotwica-7180839/alternates/LANDSCAPE_1280" />
    Nie żyje Paweł Kotwica.

## Mokradła stały się słoną pustynią. "To miejsce było pełne życia"
 - [https://tvn24.pl/tvnmeteo/swiat/hiszpania-mokradla-staly-sie-slona-pustynia-to-miejsce-bylo-pelne-zycia-7180651?source=rss](https://tvn24.pl/tvnmeteo/swiat/hiszpania-mokradla-staly-sie-slona-pustynia-to-miejsce-bylo-pelne-zycia-7180651?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 19:25:08+00:00

<img alt="Mokradła stały się słoną pustynią. " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-yxibdo-susza-dotyka-fuente-de-piedra-7180646/alternates/LANDSCAPE_1280" />
    Susza zagraża Fuente de Piedra w południowej Hiszpanii.

## Rzut rozpaczy kielczan
 - [https://eurosport.tvn24.pl/pilka-reczna/liga-mistrzow/2022-2023/rzut-rozpaczy-kielczan.-pozniej-wielka-radosc-magdeburga_sto9665859/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-reczna/liga-mistrzow/2022-2023/rzut-rozpaczy-kielczan.-pozniej-wielka-radosc-magdeburga_sto9665859/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 19:00:59+00:00

<img alt="Rzut rozpaczy kielczan" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lkc5wr-szymon-sicko-i-rzut-rozpaczy-7180821/alternates/LANDSCAPE_1280" />
    Później wielka radość Magdeburga.

## Wygrał dla zmarłego kolegi
 - [https://eurosport.tvn24.pl/kolarstwo/tour-of-slovenia/2023/wyscig-dookola-slowenii-wynik-i-relacja-z-5.-etapu.-kolarstwo_sto9665563/story.shtml?source=rss](https://eurosport.tvn24.pl/kolarstwo/tour-of-slovenia/2023/wyscig-dookola-slowenii-wynik-i-relacja-z-5.-etapu.-kolarstwo_sto9665563/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 18:45:09+00:00

<img alt="Wygrał dla zmarłego kolegi" src="https://tvn24.pl/najnowsze/cdn-zdjecie-z77kc1-matej-mohoric-wygral-5-etap-tour-of-slovenia-7180812/alternates/LANDSCAPE_1280" />
    Wzruszający koniec wyścigu Dookoła Słowenii.

## Do szczęścia zabrakło niewiele. Drugi rok z rzędu tylko srebro
 - [https://eurosport.tvn24.pl/pilka-reczna/liga-mistrzow/2022-2023/magdeburg-barlinek-industria-kielce-wynik-meczu-i-relacja-final-ligi-mistrzow-pilkarzy-recznych_sto9665680/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-reczna/liga-mistrzow/2022-2023/magdeburg-barlinek-industria-kielce-wynik-meczu-i-relacja-final-ligi-mistrzow-pilkarzy-recznych_sto9665680/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 18:18:32+00:00

<img alt="Do szczęścia zabrakło niewiele. Drugi rok z rzędu tylko srebro" src="https://tvn24.pl/najnowsze/cdn-zdjecie-j0koz2-magdeburg-barlinek-industria-kielce-7180795/alternates/LANDSCAPE_1280" />
     Liga Mistrzów nie dla kielczan.

## Poszukiwania 27-letniej Polki w Grecji. Odnaleziono ciało młodej kobiety
 - [https://tvn24.pl/swiat/grecja-kos-zaginiona-polka-anastazja-odnaleziono-zwloki-mlodej-kobiety-greckie-media-to-zaginiona-polka-7180710?source=rss](https://tvn24.pl/swiat/grecja-kos-zaginiona-polka-anastazja-odnaleziono-zwloki-mlodej-kobiety-greckie-media-to-zaginiona-polka-7180710?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 17:41:55+00:00

<img alt="Poszukiwania 27-letniej Polki w Grecji. Odnaleziono ciało młodej kobiety " src="https://tvn24.pl/najnowsze/cdn-zdjecie-q24gtm-shutterstock_1853564161-7180750/alternates/LANDSCAPE_1280" />
    27-latka zaginęła na wyspie w nocy z poniedziałku na wtorek.

## Dramat na trybunach. Długa przerwa w finale
 - [https://eurosport.tvn24.pl/pilka-reczna/dramat-na-trybunach.-dluga-przerwa-w-finale-barlinek-industria-kielce-sc-magdeburg_sto9665784/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-reczna/dramat-na-trybunach.-dluga-przerwa-w-finale-barlinek-industria-kielce-sc-magdeburg_sto9665784/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 17:40:33+00:00

<img alt="Dramat na trybunach. Długa przerwa w finale" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8dwopj-przerwa-w-finale-7180776/alternates/LANDSCAPE_1280" />
    Na długie minuty wstrzymano finałowe spotkanie Ligi Mistrzów, by udzielić pomocy osobie na trybunach.

## Wyciek gazu, pożar i ewakuacja. Są ranni
 - [https://tvn24.pl/wroclaw/jaworzyna-slaska-wroclaw-wyciek-gazu-sa-ranni-7180712?source=rss](https://tvn24.pl/wroclaw/jaworzyna-slaska-wroclaw-wyciek-gazu-sa-ranni-7180712?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 17:30:58+00:00

<img alt="Wyciek gazu, pożar i ewakuacja. Są ranni" src="https://tvn24.pl/najnowsze/cdn-zdjecie-nrdelh-k-www-7180734/alternates/LANDSCAPE_1280" />
    Do wycieku doszło w pobliżu ogrodów działkowych.

## Kapitalne interwencje. Cuda w kieleckiej bramce
 - [https://eurosport.tvn24.pl/pilka-reczna/liga-mistrzow/2022-2023/andreas-wolff-i-jego-niesamowite-interwencje-na-poczatku-finalu-ligi-mistrzow_sto9665741/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-reczna/liga-mistrzow/2022-2023/andreas-wolff-i-jego-niesamowite-interwencje-na-poczatku-finalu-ligi-mistrzow_sto9665741/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 17:00:49+00:00

<img alt="Kapitalne interwencje. Cuda w kieleckiej bramce" src="https://tvn24.pl/najnowsze/cdn-zdjecie-m1pv4u-interwencje-wolffa-przy-stanie-66-w-finale-ligi-mistrzow-7180706/alternates/LANDSCAPE_1280" />
    Na Andreasie Wolffie można polegać. Gdy kolegom nie szło, niemiecki bramkarz Barlinka Industrii Kielce dokonywał cudów. Obroniony karny, później dwie fantastyczne interwencje w krótkim odstępie czasu w bitwie o triumf w finale Ligi Mistrzów piłkarzy ręcznych.

## Dramaturgia od pierwszych sekund. Kielecki zespół walczy w finale Ligi Mistrzów
 - [https://eurosport.tvn24.pl/pilka-reczna/liga-mistrzow/2022-2023/live-sc-magdeburg-industria-kielce_mtc1429109/live.shtml?source=rss](https://eurosport.tvn24.pl/pilka-reczna/liga-mistrzow/2022-2023/live-sc-magdeburg-industria-kielce_mtc1429109/live.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 16:21:00+00:00

<img alt="Dramaturgia od pierwszych sekund. Kielecki zespół walczy w finale Ligi Mistrzów " src="https://tvn24.pl/najnowsze/cdn-zdjecie-6g0yrb-sc-magdeburg-barlinek-industria-kielce-relacja-7180648/alternates/LANDSCAPE_1280" />
    Relacja i wynik na żywo w eurosport.pl.

## Media: Rosjanie w pośpiechu szczepią ludzi na okupowanych terenach. Nie wiadomo, na co
 - [https://tvn24.pl/swiat/rosja-media-rosjanie-w-pospiechu-szczepia-ludzi-na-okupowanych-terenach-7180631?source=rss](https://tvn24.pl/swiat/rosja-media-rosjanie-w-pospiechu-szczepia-ludzi-na-okupowanych-terenach-7180631?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 15:59:14+00:00

<img alt="Media: Rosjanie w pośpiechu szczepią ludzi na okupowanych terenach. Nie wiadomo, na co" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2ebned-mieszkancy-podtopionych-terenow-7180533/alternates/LANDSCAPE_1280" />
    "Mieszkańcy z ukraińskimi paszportami nie są szczepieni".

## Trwał lockdown, konserwatyści się bawili, teraz media pokazały nagranie. "Nie da się tego obronić"
 - [https://tvn24.pl/swiat/wielka-brytania-przyjecie-w-sztabie-partii-konserwatywnej-w-czasie-lockdownu-media-publikuja-nagranie-7180605?source=rss](https://tvn24.pl/swiat/wielka-brytania-przyjecie-w-sztabie-partii-konserwatywnej-w-czasie-lockdownu-media-publikuja-nagranie-7180605?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 15:53:09+00:00

<img alt="Trwał lockdown, konserwatyści się bawili, teraz media pokazały nagranie. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-pptpek-shaun-bailey-oraz-boris-johnson-7180624/alternates/LANDSCAPE_1280" />
    Impreza odbywała się w sztabie ówczesnego kandydata partii na burmistrza Londynu.

## Koszmarne nastroje w Niemczech. "Alarm"
 - [https://eurosport.tvn24.pl/pilka-nozna/miedzynarodowe-mecze-towarzyskie/2023/w-niemczech-kryzys-zaufania-do-reprezentacji.-kibice-niechetnie-kupuja-bilety-na-kolejny-mecz_sto9665271/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/miedzynarodowe-mecze-towarzyskie/2023/w-niemczech-kryzys-zaufania-do-reprezentacji.-kibice-niechetnie-kupuja-bilety-na-kolejny-mecz_sto9665271/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 15:47:58+00:00

<img alt="Koszmarne nastroje w Niemczech. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-wwid2v-niemiecka-reprezentacja-zawodzi-7180657/alternates/LANDSCAPE_1280" />
    Po porażce z Polską.

## Najpierw ocknęła się w trumnie. Po tygodniu walki o życie zmarła
 - [https://tvn24.pl/swiat/ekwador-bella-montoya-nie-zyje-zmarla-siedem-dni-po-tym-jak-ocknela-sie-w-trumnie-7180612?source=rss](https://tvn24.pl/swiat/ekwador-bella-montoya-nie-zyje-zmarla-siedem-dni-po-tym-jak-ocknela-sie-w-trumnie-7180612?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 15:44:26+00:00

<img alt="Najpierw ocknęła się w trumnie. Po tygodniu walki o życie zmarła" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bjpg61-najpierw-ocknela-sie-w-trumnie-po-tygodniu-walki-o-zycie-zmarla-7173693/alternates/LANDSCAPE_1280" />
    Informację o śmierci mieszkanki Ekwadoru potwierdziło ministerstwo zdrowia.

## "Nauczono go postrzegać Zachód jako wroga". Imperialne ambicje Putina i ich wpływ na relacje z USA
 - [https://tvn24.pl/go/programy,7/filmy-dokumentalne-odcinki,74501/odcinek-1250,S00E1250,1093968?source=rss](https://tvn24.pl/go/programy,7/filmy-dokumentalne-odcinki,74501/odcinek-1250,S00E1250,1093968?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 15:25:56+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-eoyvj4-putin-biden-salma-bashir-motiwala-shutterstock_2286344321-7180403/alternates/LANDSCAPE_1280" />
    Film dokumentalny "Putin i amerykańscy prezydenci".

## "Ciężkie i krwawe bitwy". Co wiadomo o przebiegu kontrofensywy ukraińskiej
 - [https://tvn24.pl/swiat/ukraina-kontrofensywa-sil-ukrainskich-sytuacja-na-froncie-7180563?source=rss](https://tvn24.pl/swiat/ukraina-kontrofensywa-sil-ukrainskich-sytuacja-na-froncie-7180563?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 15:21:36+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6d3tko-ukraina-wojsko-7180574/alternates/LANDSCAPE_1280" />
    Ukraińskie władze informowały, że oficjalnego ogłoszenia kontrofensywy nie będzie. Przedstawiciele armii przyznają jednak, że "ofensywa trwa, i to na kilku kierunkach".

## Kłęby dymu nad Wrocławiem
 - [https://tvn24.pl/wroclaw/wroclaw-pozar-hali-przy-ul-legnickiej-w-srodku-byly-samochody-7180610?source=rss](https://tvn24.pl/wroclaw/wroclaw-pozar-hali-przy-ul-legnickiej-w-srodku-byly-samochody-7180610?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 15:13:02+00:00

<img alt="Kłęby dymu nad Wrocławiem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-d4aod7-pozar-hali-przy-ul-legnickiej-we-wroclawiu-7180606/alternates/LANDSCAPE_1280" />
    Płonęła hala magazynowa, w środku były samochody.

## Barcelona nie dała szans Paris Saint-Germain w starciu o brąz Ligi Mistrzów
 - [https://eurosport.tvn24.pl/pilka-reczna/liga-mistrzow/2022-2023/barcelona-paris-saint-germain-wynik-i-relacja-z-meczu-o-3.-miejsce-liga-mistrzow-pilkarzy-recznych-2_sto9665269/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-reczna/liga-mistrzow/2022-2023/barcelona-paris-saint-germain-wynik-i-relacja-z-meczu-o-3.-miejsce-liga-mistrzow-pilkarzy-recznych-2_sto9665269/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 14:50:12+00:00

<img alt="Barcelona nie dała szans Paris Saint-Germain w starciu o brąz Ligi Mistrzów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-91mmcr-barcelona-paris-saint-germain-7180608/alternates/LANDSCAPE_1280" />
    Drużynie PSG nie pomogło siedem trafień reprezentanta Polski Kamila Syprzaka.

## Wizyta, która ma "zatrzymać wiodącą w dół spiralę"
 - [https://tvn24.pl/swiat/usa-chiny-antony-blinken-amerykanski-sekretarz-stanu-z-wizyta-w-pekinie-rozmowy-miedzy-innymi-o-handlu-i-prawach-czlowieka-7180531?source=rss](https://tvn24.pl/swiat/usa-chiny-antony-blinken-amerykanski-sekretarz-stanu-z-wizyta-w-pekinie-rozmowy-miedzy-innymi-o-handlu-i-prawach-czlowieka-7180531?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 14:49:36+00:00

<img alt="Wizyta, która ma " src="https://tvn24.pl/najnowsze/cdn-zdjecie-imcicw-antony-blinken-przybyl-z-wizyta-do-chin-7180545/alternates/LANDSCAPE_1280" />
    Czego spodziewać się po podróży Blinkena do Chin?

## Wszedł do kościoła i przebrał się za księdza, nakrył go proboszcz
 - [https://tvn24.pl/bialystok/zamosc-wszedl-do-kosciola-i-przebral-sie-za-ksiedza-nakryl-go-proboszcz-wczesniej-ukradl-auto-i-smartwatcha-7180548?source=rss](https://tvn24.pl/bialystok/zamosc-wszedl-do-kosciola-i-przebral-sie-za-ksiedza-nakryl-go-proboszcz-wczesniej-ukradl-auto-i-smartwatcha-7180548?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 14:24:24+00:00

<img alt="Wszedł do kościoła i przebrał się za księdza, nakrył go proboszcz" src="https://tvn24.pl/najnowsze/cdn-zdjecie-sxssoh-mezczyzna-zostal-aresztowany-7180550/alternates/LANDSCAPE_1280" />
    24-latek trafił do aresztu.

## Broń hukowa, petardy i race. Będą płoszyć wilki, które podchodzą pod domy
 - [https://tvn24.pl/krakow/gmina-ustrzyki-dolne-bron-hukowa-petardy-i-race-beda-ploszyc-wilki-ktore-podchodza-pod-domy-7180132?source=rss](https://tvn24.pl/krakow/gmina-ustrzyki-dolne-bron-hukowa-petardy-i-race-beda-ploszyc-wilki-ktore-podchodza-pod-domy-7180132?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 14:16:07+00:00

<img alt="Broń hukowa, petardy i race. Będą płoszyć wilki, które podchodzą pod domy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-h2aix4-wilk-wilki-shutterstock_671376058-6886492/alternates/LANDSCAPE_1280" />
    "Były widziane między blokami, obok placu zabaw, na cmentarzu."

## Szansa na tańszy prąd. Trzeba się jednak pospieszyć
 - [https://tvn24.pl/biznes/pieniadze/ceny-pradu-2023-limity-zuzycia-wnioski-do-firm-energetycznych-termin-7180549?source=rss](https://tvn24.pl/biznes/pieniadze/ceny-pradu-2023-limity-zuzycia-wnioski-do-firm-energetycznych-termin-7180549?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 14:07:57+00:00

<img alt="Szansa na tańszy prąd. Trzeba się jednak pospieszyć" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lmb625-prad-listwa-zasilanie-wlacznik-wylacznik-przedluzacz-wtyczka-shutterstock566836174-5412254/alternates/LANDSCAPE_1280" />
    Ważny termin.

## Zabójstwo właściciela kantoru sprzed lat. Śledczy mają nowe tropy
 - [https://tvn24.pl/krakow/krosno-tajemnicza-zbrodnia-sprzed-lat-sledczy-maja-nowe-tropy-7180430?source=rss](https://tvn24.pl/krakow/krosno-tajemnicza-zbrodnia-sprzed-lat-sledczy-maja-nowe-tropy-7180430?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 14:05:35+00:00

<img alt="Zabójstwo właściciela kantoru sprzed lat. Śledczy mają nowe tropy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7ig5z6-ulica-lenarta-w-krosnie-miejsce-w-ktorym-doszlo-do-rozboju-6816109/alternates/LANDSCAPE_1280" />
    Policja apeluje do świadków.

## "Zwykły chłopak z Warszawy" mistrzem NBA
 - [https://eurosport.tvn24.pl/koszykowka/nba/2022-2023/rafal-juc-z-denver-nuggets-mistrzem-nba_sto9664420/story.shtml?source=rss](https://eurosport.tvn24.pl/koszykowka/nba/2022-2023/rafal-juc-z-denver-nuggets-mistrzem-nba_sto9664420/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 13:56:33+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-v60rw7-rafal-juc-jest-scoutem-denver-nuggets-7180576/alternates/LANDSCAPE_1280" />
     Trwa amerykański sen Rafała Jucia.

## Samochód doszczętnie spłonął na autostradzie. Kierowca zniknął
 - [https://tvn24.pl/tvnwarszawa/najnowsze/baranow-samochod-doszczetnie-splonal-na-autostradzie-kierowca-zniknal-7180473?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/baranow-samochod-doszczetnie-splonal-na-autostradzie-kierowca-zniknal-7180473?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 13:32:41+00:00

<img alt="Samochód doszczętnie spłonął na autostradzie. Kierowca zniknął" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-mr10b1-samochod-splonal-na-autostradzie-a1-7180527/alternates/LANDSCAPE_1280" />
    Na wysokości MOP Baranów.

## "Raport o stanie państwa" Lewicy. "Odkrywa to, co Prawo i Sprawiedliwość chciało ukryć"
 - [https://tvn24.pl/polska/lewica-raport-o-stanie-panstwa-krzysztof-gawkowski-odkrywa-to-co-prawo-i-sprawiedliwosc-chcialo-ukryc-7180502?source=rss](https://tvn24.pl/polska/lewica-raport-o-stanie-panstwa-krzysztof-gawkowski-odkrywa-to-co-prawo-i-sprawiedliwosc-chcialo-ukryc-7180502?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 13:21:23+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3hifjs-raport-o-stanie-panstwa-lewicy-7180506/alternates/LANDSCAPE_1280" />
    Politycy ugrupowania twierdzą, że "Prawo i Sprawiedliwość miało tworzyć państwo dla milionów, a stworzyło państwo dla milionerów".

## Mick Jagger sprzedaje dom
 - [https://tvn24.pl/biznes/ze-swiata/mick-jagger-wystawia-dom-na-sprzedaz-7180454?source=rss](https://tvn24.pl/biznes/ze-swiata/mick-jagger-wystawia-dom-na-sprzedaz-7180454?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 13:05:42+00:00

<img alt="Mick Jagger sprzedaje dom" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1nav0e-mick-jagger-7180462/alternates/LANDSCAPE_1280" />
    Powierzchnia mieszkalna wynosi 529 metrów kwadratowych.

## Tragiczne skutki suszy. Bociany wyrzucają młode z gniazd
 - [https://tvn24.pl/pomorze/tragiczne-skutki-suszy-bociany-wyrzucaja-mlode-z-gniazd-7178374?source=rss](https://tvn24.pl/pomorze/tragiczne-skutki-suszy-bociany-wyrzucaja-mlode-z-gniazd-7178374?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 12:07:27+00:00

<img alt="Tragiczne skutki suszy. Bociany wyrzucają młode z gniazd" src="https://tvn24.pl/najnowsze/cdn-zdjecie-g25nfb-bociany-wyrzucaja-wiecej-mlodych-z-gniazd-7178433/alternates/LANDSCAPE_1280" />
    "To jest znana strategia bocianów na przetrwanie".

## Zamieszanie przed Grand Prix Kanady
 - [https://eurosport.tvn24.pl/formula-1/grand-prix-kanady-2023-wyniki-kwalifikacji-formula-1_sto9664732/story.shtml?source=rss](https://eurosport.tvn24.pl/formula-1/grand-prix-kanady-2023-wyniki-kwalifikacji-formula-1_sto9664732/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 12:03:09+00:00

<img alt="Zamieszanie przed Grand Prix Kanady" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8ify0y-nico-huelkenberg-podczas-kwalifikacji-w-kanadzie-7180444/alternates/LANDSCAPE_1280" />
    Skończyły się kwalifikacje, zaczęły przetasowania.

## Podatek dla najbogatszych. Rząd podaje kwotę
 - [https://tvn24.pl/biznes/z-kraju/podatki-danina-solidarnosciowa-2022-podatek-dla-najbogatszych-artur-sobon-podaje-kwote-7180294?source=rss](https://tvn24.pl/biznes/z-kraju/podatki-danina-solidarnosciowa-2022-podatek-dla-najbogatszych-artur-sobon-podaje-kwote-7180294?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 11:47:13+00:00

<img alt="Podatek dla najbogatszych. Rząd podaje kwotę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ue86cs-mateusz-morawiecki-artur-sobon-7180290/alternates/LANDSCAPE_1280" />
    W odpowiedzi na interpelację poselską.

## 27-letnia Polka zaginęła w Grecji. Opublikowano nagranie z monitoringu
 - [https://tvn24.pl/wroclaw/27-letnia-polka-zaginela-wgrecji-opublikowano-nagranie-z-monitoringu-media-dna-kobiety-w-domu-zatrzymanego-7180193?source=rss](https://tvn24.pl/wroclaw/27-letnia-polka-zaginela-wgrecji-opublikowano-nagranie-z-monitoringu-media-dna-kobiety-w-domu-zatrzymanego-7180193?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 11:43:31+00:00

<img alt="27-letnia Polka zaginęła w Grecji. Opublikowano nagranie z monitoringu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-amkani-greckie-media-opublikowaly-nagranie-na-ktorym-widac-zaginiona-polke-anastazje-rubinska-7180185/alternates/LANDSCAPE_1280" />
    Kolejna doba poszukiwań.

## Projekt Andrzeja Dudy od 32 miesięcy w Sejmie. "To właśnie wyraz szacunku PiS do prezydenta"
 - [https://tvn24.pl/polska/projekt-ustawy-autorstwa-andrzeja-dudy-o-aborcji-od-32-miesiecy-w-sejmie-politycy-komentuja-7180352?source=rss](https://tvn24.pl/polska/projekt-ustawy-autorstwa-andrzeja-dudy-o-aborcji-od-32-miesiecy-w-sejmie-politycy-komentuja-7180352?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 11:28:25+00:00

<img alt="Projekt Andrzeja Dudy od 32 miesięcy w Sejmie. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-6qq5ch-andrzej-duda-7180397/alternates/LANDSCAPE_1280" />
    O prezydenckim projekcie i o obowiązujących przepisach w sprawie aborcji dyskutowali goście "Kawy na ławę".

## Kilkaset ewakuowanych osób, zalane domy i uszkodzone mosty
 - [https://tvn24.pl/tvnmeteo/swiat/serbia-bulgaria-powodzie-kilkaset-ewakuowanych-osob-zalane-domy-i-uszkodzone-mosty-7180119?source=rss](https://tvn24.pl/tvnmeteo/swiat/serbia-bulgaria-powodzie-kilkaset-ewakuowanych-osob-zalane-domy-i-uszkodzone-mosty-7180119?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 11:05:47+00:00

<img alt="Kilkaset ewakuowanych osób, zalane domy i uszkodzone mosty" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-zh85md-powodzie-7180250/alternates/LANDSCAPE_1280" />
    Powodzie w Serbii i Bułgarii.

## Potężny pożar na płynącym promie
 - [https://tvn24.pl/swiat/filipiny-pozar-na-promie-uratowano-wszystkich-pasazerow-7180246?source=rss](https://tvn24.pl/swiat/filipiny-pozar-na-promie-uratowano-wszystkich-pasazerow-7180246?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 10:38:32+00:00

<img alt="Potężny pożar na płynącym promie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1muemk-filipiny-na-promie-przewozacymi-120-osob-wybuchl-pozar-7180248/alternates/LANDSCAPE_1280" />
    120 osób na pokładzie.

## "Wojna nie przeszkadza w miłości". Ukraińcy biorą zdalne śluby
 - [https://tvn24.pl/swiat/ukraina-sluby-zdalne-historia-milosci-w-czasie-wojny-7180241?source=rss](https://tvn24.pl/swiat/ukraina-sluby-zdalne-historia-milosci-w-czasie-wojny-7180241?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 10:31:31+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-od6twf-ukrainska-para-7180251/alternates/LANDSCAPE_1280" />
    Resort sprawiedliwości w Kijowie podał statystyki.

## Pili alkohol, tłukli butelki w pociągu, zaatakowali policjanta. Dostał wsparcie żony
 - [https://tvn24.pl/tvnwarszawa/najnowsze/zielonka-tlukli-butelki-i-pili-alkohol-w-pociagu-zaatakowali-policjanta-uslyszeli-zarzuty-7180178?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/zielonka-tlukli-butelki-i-pili-alkohol-w-pociagu-zaatakowali-policjanta-uslyszeli-zarzuty-7180178?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 10:27:35+00:00

<img alt="Pili alkohol, tłukli butelki w pociągu, zaatakowali policjanta. Dostał wsparcie żony" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-cr41kx-do-zdarzenia-doszlo-w-pociagu-z-warszawy-do-wolomina-7180279/alternates/LANDSCAPE_1280" />
    Dwie osoby zostały aresztowane.

## Burza przeszła nad Warszawą
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-burze-i-ulewa-nad-miastem-podtopienia-7180245?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-burze-i-ulewa-nad-miastem-podtopienia-7180245?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 10:09:29+00:00

<img alt="Burza przeszła nad Warszawą" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-bi10wj-fragment-drogi-s79-znalazl-sie-pod-woda-7180408/alternates/LANDSCAPE_1280" />
     Fragment drogi ekspresowej pod wodą.

## Idzie pierwszy prawdziwy upał. Pogoda na 16 dni
 - [https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-16-dni-dlugoterminowa-prognoza-idzie-pierwszy-prawdziwy-upal-7180203?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-16-dni-dlugoterminowa-prognoza-idzie-pierwszy-prawdziwy-upal-7180203?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 10:01:39+00:00

<img alt="Idzie pierwszy prawdziwy upał. Pogoda na 16 dni" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vqgs86-16-dni-drv-7180255/alternates/LANDSCAPE_1280" />
    Sprawdź prognozę długoterminową.

## Sieć wycofuje produkt ze sklepów. Ostrzeżenie
 - [https://tvn24.pl/biznes/z-kraju/sinsey-wycofuje-produkt-ostrzezenie-komunikat-uokik-7180190?source=rss](https://tvn24.pl/biznes/z-kraju/sinsey-wycofuje-produkt-ostrzezenie-komunikat-uokik-7180190?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 09:51:38+00:00

<img alt="Sieć wycofuje produkt ze sklepów. Ostrzeżenie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-m76vyp-sinsey-sklep-ubrania-maxshotpl-shutterstock_2038192121-7180202/alternates/LANDSCAPE_1280" />
    Komunikat.

## "Dobra robota, chłopcy!".  Ukraiński atak na rosyjski magazyn amunicji
 - [https://tvn24.pl/swiat/ukraina-atak-na-rosyjski-magazyn-amunicji-pod-heniczeskiem-7180154?source=rss](https://tvn24.pl/swiat/ukraina-atak-na-rosyjski-magazyn-amunicji-pod-heniczeskiem-7180154?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 09:40:18+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-f4bzy5-ukr-7180165/alternates/LANDSCAPE_1280" />
    Eksplozje trwały przez kilka godzin.

## Zatrzymać Kaya Smitsa. Zadanie z gatunku tych niemożliwych
 - [https://eurosport.tvn24.pl/pilka-reczna/liga-mistrzow/2022-2023/barlinek-industria-kielce-w-finale-ligi-mistrzow-musi-znalezc-sposob-na-kaya-smitsa_sto9664348/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-reczna/liga-mistrzow/2022-2023/barlinek-industria-kielce-w-finale-ligi-mistrzow-musi-znalezc-sposob-na-kaya-smitsa_sto9664348/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 09:33:00+00:00

<img alt="Zatrzymać Kaya Smitsa. Zadanie z gatunku tych niemożliwych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-dqdn0c-kay-smits-jest-motorem-napedowym-magdeburga-7180204/alternates/LANDSCAPE_1280" />
    To przeciwko niemu kielczanie zagrają w finale Ligi Mistrzów.

## Wędkarze zauważyli, że na brzegu leży ubranie. Strażacy wyłowili z wody ciało mężczyzny
 - [https://tvn24.pl/bialystok/bialystok-wedkarze-zauwazyli-ze-na-brzegu-lezy-ubranie-strazacy-wylowili-z-wody-cialo-47-letniego-mezczyzny-7180114?source=rss](https://tvn24.pl/bialystok/bialystok-wedkarze-zauwazyli-ze-na-brzegu-lezy-ubranie-strazacy-wylowili-z-wody-cialo-47-letniego-mezczyzny-7180114?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 09:22:14+00:00

<img alt="Wędkarze zauważyli, że na brzegu leży ubranie. Strażacy wyłowili z wody ciało mężczyzny" src="https://tvn24.pl/najnowsze/cdn-zdjecie-nzaatt-cialo-zostalo-wylowione-z-zalewu-dojlidy-zdjecie-ilustracyjne-7180197/alternates/LANDSCAPE_1280" />
    Znaleziono je 10 metrów od niestrzeżonej plaży.

## "Co to za debil" i z kim wygrała Polska na Narodowym
 - [https://tvn24.pl/polska/wpis-o-donaldzie-tusku-po-meczu-z-polska-niemcy-spiecie-miedzy-jackiem-ozdoba-a-zbigniewem-bonkiem-7180144?source=rss](https://tvn24.pl/polska/wpis-o-donaldzie-tusku-po-meczu-z-polska-niemcy-spiecie-miedzy-jackiem-ozdoba-a-zbigniewem-bonkiem-7180144?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 09:13:29+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1i9iqc-ozdoba-boniek-7180160/alternates/LANDSCAPE_1280" />
    Boniek kontra polityk Zjednoczonej Prawicy po meczu Polska - Niemcy.

## Ciało kobiety w domu. Na miejscu pijany zięć i zakrwawiony nóż
 - [https://tvn24.pl/krakow/moszczanica-cialo-kobiety-w-domu-ziec-zatrzymany-na-miejscu-znaleziono-zakrwawiony-noz-7180077?source=rss](https://tvn24.pl/krakow/moszczanica-cialo-kobiety-w-domu-ziec-zatrzymany-na-miejscu-znaleziono-zakrwawiony-noz-7180077?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 09:07:56+00:00

<img alt="Ciało kobiety w domu. Na miejscu pijany zięć i zakrwawiony nóż" src="https://tvn24.pl/najnowsze/cdn-zdjecie-iau002-15-latki-hucznie-swietowaly-urodziny-trzy-dziewczeta-byly-pod-wplywem-alkoholu-6555186/alternates/LANDSCAPE_1280" />
    Kobieta miała cztery rany kłute brzucha.

## Polacy tną wydatki. Z tych produktów rezygnujemy najczęściej
 - [https://tvn24.pl/biznes/z-kraju/inflacja-w-polsce-przez-drozyzne-polacy-mocno-tna-wydatki-z-tych-produktow-rezygnujemy-najczesciej-7180057?source=rss](https://tvn24.pl/biznes/z-kraju/inflacja-w-polsce-przez-drozyzne-polacy-mocno-tna-wydatki-z-tych-produktow-rezygnujemy-najczesciej-7180057?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 08:31:00+00:00

<img alt="Polacy tną wydatki. Z tych produktów rezygnujemy najczęściej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bwo94j-do-oszustwa-mialo-dojsc-w-supermarkecie-zdjecie-ilustracyjne-7152576/alternates/LANDSCAPE_1280" />
    Wyniki badania.

## Zginęli dziś rano. Mieli 18 i 20 lat
 - [https://tvn24.pl/krakow/brzozowa-samochod-uderzyl-w-drzewo-w-wypadku-zginelo-dwoch-mlodych-mezczyzn-7180108?source=rss](https://tvn24.pl/krakow/brzozowa-samochod-uderzyl-w-drzewo-w-wypadku-zginelo-dwoch-mlodych-mezczyzn-7180108?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 08:22:27+00:00

<img alt="Zginęli dziś rano. Mieli 18 i 20 lat" src="https://tvn24.pl/najnowsze/cdn-zdjecie-im2ftj-samochod-uderzyl-w-drzewo-w-wypadku-zginelo-dwoch-mlodych-mezczyzn-7180122/alternates/LANDSCAPE_1280" />
    20-letni kierowca stracił panowanie nad autem.

## Policjant i kierowca wessani pod wodę. "Prawie umarłem"
 - [https://tvn24.pl/tvnmeteo/swiat/usa-floryda-policjant-i-kierowca-wessani-pod-wode-prawie-umarlem-7180059?source=rss](https://tvn24.pl/tvnmeteo/swiat/usa-floryda-policjant-i-kierowca-wessani-pod-wode-prawie-umarlem-7180059?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 08:22:06+00:00

<img alt="Policjant i kierowca wessani pod wodę. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-cv0dj3-usa-7180134/alternates/LANDSCAPE_1280" />
    Niemal pół minuty byli pod wodą.

## Rekordowo długie pożary "elektryków", jeden z nich trwał prawie 22 godziny. Dlaczego tak długo?
 - [https://tvn24.pl/pomorze/rekordowo-dlugie-pozary-elektrykow-jeden-z-nich-trwal-prawie-22-godziny-dlaczego-tak-dlugo-7169132?source=rss](https://tvn24.pl/pomorze/rekordowo-dlugie-pozary-elektrykow-jeden-z-nich-trwal-prawie-22-godziny-dlaczego-tak-dlugo-7169132?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 07:57:43+00:00

<img alt="Rekordowo długie pożary " src="https://tvn24.pl/najnowsze/cdn-zdjecie-r0etz3-pozar-samochodu-elektrycznego-7150810/alternates/LANDSCAPE_1280" />
    Straż pożarna wyjaśnia.

## Biznes na wakacjach. "Ludzie nie wiedzą, co ich czeka"
 - [https://tvn24.pl/biznes/dlafirm/wakacje-2023-paragony-grozy-ile-kosztuje-nocleg-ryba-gofry-problemy-nadmorskich-przedsiebiorcow-7173688?source=rss](https://tvn24.pl/biznes/dlafirm/wakacje-2023-paragony-grozy-ile-kosztuje-nocleg-ryba-gofry-problemy-nadmorskich-przedsiebiorcow-7173688?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 07:44:27+00:00

<img alt="Biznes na wakacjach. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-x5btjp-miedzyzdroje-plaza-shutterstock_2015674988-7180080/alternates/LANDSCAPE_1280" />
    Nadmorscy przedsiębiorcy w rozmowie z TVN24 Biznes.

## Córka premiera wyszła za mąż. Na ślubie pojawił się prezes PiS
 - [https://tvn24.pl/polska/corka-premiera-mateusza-morawieckiego-wyszla-za-maz-7180072?source=rss](https://tvn24.pl/polska/corka-premiera-mateusza-morawieckiego-wyszla-za-maz-7180072?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 07:34:23+00:00

<img alt="Córka premiera wyszła za mąż. Na ślubie pojawił się prezes PiS " src="https://tvn24.pl/najnowsze/cdn-zdjecie-998l3e-corka-premiera-wyszla-za-maz-7180069/alternates/LANDSCAPE_1280" />
    "Prawdziwa historia ojcowskiej miłości nigdy się nie kończy" - napisał Mateusz Morawiecki, publikując zdjęcie z żoną i córką.

## Rzecznik Kremla: jeden z celów na Ukrainie w znaczniej mierze osiągnięty
 - [https://tvn24.pl/swiat/wojna-w-ukrainie-rzecznik-kremla-jeden-z-celow-rosji-w-znaczniej-mierze-osiagniety-7180070?source=rss](https://tvn24.pl/swiat/wojna-w-ukrainie-rzecznik-kremla-jeden-z-celow-rosji-w-znaczniej-mierze-osiagniety-7180070?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 07:16:43+00:00

Dmitrij Pieskow udzielił wywiadu stacji RT Arabic.

## Upozorował własną śmierć, posługiwał się dziesięcioma tożsamościami
 - [https://tvn24.pl/swiat/sergio-roberto-de-carvalho-brazylijski-pablo-escobar-przekazany-przez-wegry-do-belgii-7180052?source=rss](https://tvn24.pl/swiat/sergio-roberto-de-carvalho-brazylijski-pablo-escobar-przekazany-przez-wegry-do-belgii-7180052?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 07:07:31+00:00

<img alt="Upozorował własną śmierć, posługiwał się dziesięcioma tożsamościami" src="https://tvn24.pl/najnowsze/cdn-zdjecie-dslld8-baron-narkotykowy-7180029/alternates/LANDSCAPE_1280" />
    Ekstradycja "brazylijskiego Pablo Escobara".

## W trakcie szarpaniny został ranny, zmarł w szpitalu. Dwie osoby zatrzymane
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-w-trakcie-szarpaniny-zostal-ranny-zmarl-w-szpitalu-dwie-osoby-zatrzymane-7180026?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-w-trakcie-szarpaniny-zostal-ranny-zmarl-w-szpitalu-dwie-osoby-zatrzymane-7180026?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 06:58:24+00:00

<img alt="W trakcie szarpaniny został ranny, zmarł w szpitalu. Dwie osoby zatrzymane" src="https://tvn24.pl/najnowsze/cdn-zdjecie-yf6pvp-policja-zdjecie-ilustracyjne-7180033/alternates/LANDSCAPE_1280" />
    Zmarły prawdopodobnie został ugodzony nożem.

## Zabójczy Mister Cydr. Kolejne przypadki śmiertelnego zatrucia, wśród ofiar dzieci
 - [https://tvn24.pl/swiat/rosja-kolejne-zgony-w-wyniku-zatrucia-podrabianym-alkoholem-mister-cydr-7180037?source=rss](https://tvn24.pl/swiat/rosja-kolejne-zgony-w-wyniku-zatrucia-podrabianym-alkoholem-mister-cydr-7180037?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 06:52:57+00:00

<img alt="Zabójczy Mister Cydr. Kolejne przypadki śmiertelnego zatrucia, wśród ofiar dzieci " src="https://tvn24.pl/najnowsze/cdn-zdjecie-6rfuxs-rosja-kolejne-zgony-w-wyniku-zatrucia-podrabianym-alkoholem-mister-cydr-7180047/alternates/LANDSCAPE_1280" />
    W napoju wykryto alkohol metylowy oraz maślan etylu - substancję o woni ananasa, służącą do wytwarzania olejków zapachowych.

## Rozbłysk światła na Jowiszu. Skąd się wziął?
 - [https://tvn24.pl/tvnmeteo/nauka/rozblysk-swiatla-na-jowiszu-blyskawice-na-jowiszu-kosmiczne-burze-7179709?source=rss](https://tvn24.pl/tvnmeteo/nauka/rozblysk-swiatla-na-jowiszu-blyskawice-na-jowiszu-kosmiczne-burze-7179709?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 06:29:36+00:00

<img alt="Rozbłysk światła na Jowiszu. Skąd się wziął?" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-blgc83-blyskawica-na-jowiszu-7179928/alternates/LANDSCAPE_1280" />
    W obiektywie sondy Juno.

## Padła szóstka w Lotto
 - [https://tvn24.pl/biznes/pieniadze/wyniki-lotto-z-dnia170623-liczby-z-ostatniego-losowania-7180020?source=rss](https://tvn24.pl/biznes/pieniadze/wyniki-lotto-z-dnia170623-liczby-z-ostatniego-losowania-7180020?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 06:27:03+00:00

<img alt="Padła szóstka w Lotto" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pkh52t-shutterstock268930547-5432420/alternates/LANDSCAPE_1280" />
    Wyniki losowania.

## Dyrektorka liceum pisze list do uczniów. "Wyobrażam sobie, że nas znienawidzisz"
 - [https://tvn24.pl/swiat/wlochy-dyrektorka-liceum-w-mediolanie-napisala-list-do-uczniow-ktorzy-nie-zdali-7180013?source=rss](https://tvn24.pl/swiat/wlochy-dyrektorka-liceum-w-mediolanie-napisala-list-do-uczniow-ktorzy-nie-zdali-7180013?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 06:21:11+00:00

<img alt="Dyrektorka liceum pisze list do uczniów. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-udo4fa-egzamin-osmoklasisty-7143489/alternates/LANDSCAPE_1280" />
    "Za 10 lat nikt nie będzie o tym pamiętał".

## Z piłą do lodu na pokładzie. Dreamliner LOT poleciał trasą polarną
 - [https://tvn24.pl/polska/dreamliner-pll-lot-przelecial-po-raz-pierwszy-z-tokio-do-warszawy-trasa-polarna-7180011?source=rss](https://tvn24.pl/polska/dreamliner-pll-lot-przelecial-po-raz-pierwszy-z-tokio-do-warszawy-trasa-polarna-7180011?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 06:09:23+00:00

<img alt="Z piłą do lodu na pokładzie. Dreamliner LOT poleciał trasą polarną" src="https://tvn24.pl/najnowsze/cdn-zdjecie-dq0667-boeing-787-9-dreamliner-7180015/alternates/LANDSCAPE_1280" />
    Po raz pierwszy.

## Burza z okna samolotu. Zobacz nagranie
 - [https://tvn24.pl/tvnmeteo/swiat/usa-burza-z-okna-samolotu-zobacz-nagranie-7179994?source=rss](https://tvn24.pl/tvnmeteo/swiat/usa-burza-z-okna-samolotu-zobacz-nagranie-7179994?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 05:56:03+00:00

<img alt="Burza z okna samolotu. Zobacz nagranie" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-suppk9-burza-7180012/alternates/LANDSCAPE_1280" />
    Widok zapiera dech w piersiach.

## Ukraiński ruch oporu: cholera wśród Rosjan, strachy na wróble w okopach
 - [https://tvn24.pl/swiat/ukraina-ruch-oporu-rosyjscy-zolnierze-choruja-na-cholere-7179995?source=rss](https://tvn24.pl/swiat/ukraina-ruch-oporu-rosyjscy-zolnierze-choruja-na-cholere-7179995?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 05:31:06+00:00

<img alt="Ukraiński ruch oporu: cholera wśród Rosjan, strachy na wróble w okopach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-miyst7-rosyjscy-zolnierze-7172258/alternates/LANDSCAPE_1280" />
    Powodem tej fali zachorowań ma być spożywanie nieoczyszczonej wody wskutek wysadzenia tamy w Nowej Kachowce.

## Złagodzenie barier dla przystąpienia Ukrainy do NATO? Biden odpowiada
 - [https://tvn24.pl/swiat/ukraina-chce-do-nato-joe-biden-o-pomysle-zlagodzenia-barier-dla-kijowa-7179945?source=rss](https://tvn24.pl/swiat/ukraina-chce-do-nato-joe-biden-o-pomysle-zlagodzenia-barier-dla-kijowa-7179945?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 04:48:02+00:00

<img alt="Złagodzenie barier dla przystąpienia Ukrainy do NATO? Biden odpowiada " src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-vrm769-joe-biden-7158684/alternates/LANDSCAPE_1280" />
    Podał portal CNN.

## Dania idzie "o krok dalej"
 - [https://tvn24.pl/swiat/dania-jest-gotowa-przekazac-mysliwce-f-16-dla-ukrainy-oswiadczenie-ministera-obrony-danii-troelsa-lund-poulsena-7179940?source=rss](https://tvn24.pl/swiat/dania-jest-gotowa-przekazac-mysliwce-f-16-dla-ukrainy-oswiadczenie-ministera-obrony-danii-troelsa-lund-poulsena-7179940?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 04:36:52+00:00

<img alt="Dania idzie " src="https://tvn24.pl/najnowsze/cdn-zdjecie-cus5m1-dunskie-mysliwce-f-16-7179989/alternates/LANDSCAPE_1280" />
    "Nie wyobrażam sobie, abyśmy nie wsparli Ukrainy myśliwcami".

## Alerty IMGW przed burzami z gradem. Ponad połowa kraju objęta ostrzeżeniami
 - [https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-burze-z-gradem-pogoda-niedziela-1806-zolte-alarmy-w-11-wojewodztwach-7179982?source=rss](https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-burze-z-gradem-pogoda-niedziela-1806-zolte-alarmy-w-11-wojewodztwach-7179982?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 04:32:55+00:00

<img alt="Alerty IMGW przed burzami z gradem. Ponad połowa kraju objęta ostrzeżeniami" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-2q2cu2-burza-piorun-shutterstock420705478-5717845/alternates/LANDSCAPE_1280" />
    Sprawdź, gdzie aura będzie groźna.

## IMGW wydał pomarańczowe alerty
 - [https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-burze-z-gradem-pogoda-niedziela-1806-alerty-drugiego-stopnia-w-czesci-kraju-7179982?source=rss](https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-burze-z-gradem-pogoda-niedziela-1806-alerty-drugiego-stopnia-w-czesci-kraju-7179982?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 04:32:55+00:00

<img alt="IMGW wydał pomarańczowe alerty" src="https://tvn24.pl/najnowsze/cdn-zdjecie-k9tx8n-burza-piorun-blyskawica-6877828/alternates/LANDSCAPE_1280" />
    Uwaga na burze z gradem! I

## Uwaga na burze z gradem. Żółte alarmy w ośmiu województwach
 - [https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-burze-z-gradem-pogoda-niedziela-1806-zolte-alarmy-w-osmiu-wojewodztwach-7179982?source=rss](https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-burze-z-gradem-pogoda-niedziela-1806-zolte-alarmy-w-osmiu-wojewodztwach-7179982?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 04:32:55+00:00

<img alt="Uwaga na burze z gradem. Żółte alarmy w ośmiu województwach " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-szb0cn-burze-6087534/alternates/LANDSCAPE_1280" />
    IMGW ostrzega.

## Królowa Danii po 66 latach rzuciła palenie
 - [https://tvn24.pl/swiat/dania-krolowa-malgorzata-ii-rzucila-palenie-papierosow-ze-wzgledu-na-operacje-7179959?source=rss](https://tvn24.pl/swiat/dania-krolowa-malgorzata-ii-rzucila-palenie-papierosow-ze-wzgledu-na-operacje-7179959?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 04:27:49+00:00

<img alt="Królowa Danii po 66 latach rzuciła palenie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6kio3z-margrethe-ii-of-denmark-7179935/alternates/LANDSCAPE_1280" />
    Do decyzji przyczyniła się operacja kręgosłupa.

## Zapora w Nowej Kachowce miała "piętę Achillesa"
 - [https://tvn24.pl/swiat/ukraina-zniszczenie-zapory-w-nowej-kachowce-wyniki-sledztwa-dziennikarzy-z-new-york-times-7179963?source=rss](https://tvn24.pl/swiat/ukraina-zniszczenie-zapory-w-nowej-kachowce-wyniki-sledztwa-dziennikarzy-z-new-york-times-7179963?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 04:11:28+00:00

<img alt="Zapora w Nowej Kachowce miała " src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-xt755k-rosja-wysadzila-tame-w-nowej-kachowce-to-oburzajacy-akt-ktory-kolejny-raz-pokazuje-brutalnosc-rosyjskiej-wojny-7164128/alternates/LANDSCAPE_1280" />
    Śledztwo dziennika "New York Times".

## Wypalenie i stany depresyjne medalistki olimpijskiej. "Z okularków do pływania wylewałam łzy"
 - [https://tvn24.pl/premium/oktawia-nowacka-o-wypaleniu-i-stanach-depresyjnych-po-zdobyciu-olimpijskiego-brazu-w-rio-de-janeiro-7177838?source=rss](https://tvn24.pl/premium/oktawia-nowacka-o-wypaleniu-i-stanach-depresyjnych-po-zdobyciu-olimpijskiego-brazu-w-rio-de-janeiro-7177838?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 04:05:27+00:00

<img alt="Wypalenie i stany depresyjne medalistki olimpijskiej. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-kr2cm2-o-medalu-olimpijskim-oktawia-nowacka-zaczela-myslec-w-przedszkolu-7178113/alternates/LANDSCAPE_1280" />
    Nie spodziewała się, że kryzys, ten psychiczny, przyjdzie właśnie wtedy, po osiągnięciu życiowego sukcesu. Dość już miała oszukiwania siebie i ludzi, z którymi współpracowała. - Każda komórka mojego ciała krzyczała "nie". Zmuszałam się do treningów, zamiast powiedzieć "dajcie mi święty spokój, choć na chwilę" - opowiada o problemach, z którymi przyszło jej się mierzyć, pięcioboistka nowoczesna Oktawia Nowacka, medalistka olimpijska.

## Ukraina walczy. Najważniejsze wydarzenia ostatnich godzin
 - [https://tvn24.pl/swiat/ukraina-walczy-najwazniejsze-wydarzenia-ostatnich-godzin-17-czerwca-2023-7179966?source=rss](https://tvn24.pl/swiat/ukraina-walczy-najwazniejsze-wydarzenia-ostatnich-godzin-17-czerwca-2023-7179966?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 04:00:54+00:00

<img alt="Ukraina walczy. Najważniejsze wydarzenia ostatnich godzin" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ptyww-ukraina-wojsko-7155911/alternates/LANDSCAPE_1280" />
    Rosyjska inwazja na Ukrainę trwa od 480 dni.

## Parada, pytania o wybory, susza, zaginięcie i śmierć Polaków
 - [https://tvn24.pl/swiat/podsumowanie-dnia-piec-rzeczy-ktore-warto-wiedziec-18-czerwca-7179973?source=rss](https://tvn24.pl/swiat/podsumowanie-dnia-piec-rzeczy-ktore-warto-wiedziec-18-czerwca-7179973?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 03:53:07+00:00

<img alt="Parada, pytania o wybory, susza, zaginięcie i śmierć Polaków" src="https://tvn24.pl/najnowsze/cdn-zdjecie-uof5zx-parada-rownosci-w-warszawie-7179859/alternates/LANDSCAPE_1280" />
    Pięć rzeczy, które warto wiedzieć 18 czerwca.

## Rzecznik Kremla: jeden z celów na Ukrainie w znaczniej mierze osiągnięty
 - [https://tvn24.pl/swiat/atak-rosji-na-ukraine-relacja-na-zywo-18-czerwca-2023-7179976?source=rss](https://tvn24.pl/swiat/atak-rosji-na-ukraine-relacja-na-zywo-18-czerwca-2023-7179976?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 03:41:11+00:00

<img alt="Rzecznik Kremla: jeden z celów na Ukrainie w znaczniej mierze osiągnięty " src="https://tvn24.pl/najnowsze/cdn-zdjecie-xrzeye-dmitrij-pieskow-6974151/alternates/LANDSCAPE_1280" />
    W tvn24.pl relacjonujemy wydarzenia z i wokół Ukrainy.

## Limit miejsc na plaży
 - [https://tvn24.pl/swiat/wlochy-limit-miejsc-na-plazy-portobello-w-sestri-levante-7179957?source=rss](https://tvn24.pl/swiat/wlochy-limit-miejsc-na-plazy-portobello-w-sestri-levante-7179957?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 03:14:11+00:00

<img alt="Limit miejsc na plaży" src="https://tvn24.pl/najnowsze/cdn-zdjecie-847rdp-sestri-levante-7179861/alternates/LANDSCAPE_1280" />
    Maksimum 400 osób.

## Obala mit "jednej lampki wina", nie chce prohibicji. "Chciałbym mówić prawdę"
 - [https://tvn24.pl/go/programy,7/bez-polityki-odcinki,413879/odcinek-137,S00E137,1092452?source=rss](https://tvn24.pl/go/programy,7/bez-polityki-odcinki,413879/odcinek-137,S00E137,1092452?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-06-18 03:10:00+00:00

<img alt="Obala mit " src="https://tvn24.pl/najnowsze/cdn-zdjecie-c8qkvp-robert-rutkowski-piotr-jacon-7179605/alternates/LANDSCAPE_1280" />
    Rozmowa Piotra Jaconia z psychoterapeutą Robertem Rutkowskim.

