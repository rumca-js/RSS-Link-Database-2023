# Source:Ryan Long, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzKFvBRI6VT3jYJq6a820nA, language:en-US

## If America went to Couples Therapy
 - [https://www.youtube.com/watch?v=aZlsVMZVXr0](https://www.youtube.com/watch?v=aZlsVMZVXr0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzKFvBRI6VT3jYJq6a820nA
 - date published: 2023-06-18 22:53:17+00:00



