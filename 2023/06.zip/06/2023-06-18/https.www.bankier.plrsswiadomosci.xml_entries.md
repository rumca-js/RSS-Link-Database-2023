# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Coraz więcej obcokrajowców wśród absolwentów polskich uczelni. Ten kierunek wybierają najczęściej
 - [https://www.bankier.pl/wiadomosc/Coraz-wiecej-obcokrajowcow-wsrod-absolwentow-polskich-uczelni-Ten-kierunek-wybieraja-najczesciej-8558922.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Coraz-wiecej-obcokrajowcow-wsrod-absolwentow-polskich-uczelni-Ten-kierunek-wybieraja-najczesciej-8558922.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-18 17:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/3/879da035d54b01-948-568-90-0-1924-1154.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W 2021 r. wśród absolwentów szkół wyższych w Polsce było blisko 16 tys. osób z zagranicy. Liczba ta wzrasta w ostatnich latach. W 2019 r. było ich ok. 14,7 tys., a w 2017 r - ok. 11,4 tys. - wynika z najnowszych danych Ośrodka Przetwarzania Informacji udostępnionych PAP. Teolodzy zostają w Polsce, medycy - nie.</p>

## Brytyjski rząd forsuje ustawę zakazującą bojkotu izraelskich produktów
 - [https://www.bankier.pl/wiadomosc/Brytyjski-rzad-forsuje-ustawe-zakazujaca-bojkotu-izraelskich-produktow-8562466.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Brytyjski-rzad-forsuje-ustawe-zakazujaca-bojkotu-izraelskich-produktow-8562466.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-18 16:14:40.024076+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/a/a62911304c227d-948-568-0-288-1920-1151.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Brytyjski rząd przedstawi w poniedziałek projekt ustawy zakazującej wszystkim organom publicznym prowadzenia własnych kampanii bojkotu lub zniechęcania do inwestycji w innych krajach i terytoriach, w tym w Izraelu – zapowiedział w niedzielę minister ds. wyrównywania szans i społeczności Michael Gove.</p>

## Jest szansa na złagodzenie konfliktu USA-Chiny? Rozmowy były "szczere, rzeczowe i konstruktywne"
 - [https://www.bankier.pl/wiadomosc/Jest-szansa-na-zlagodzenie-konfliktu-USA-Chiny-Rozmowy-byly-szczere-rzeczowe-i-konstruktywne-8562465.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Jest-szansa-na-zlagodzenie-konfliktu-USA-Chiny-Rozmowy-byly-szczere-rzeczowe-i-konstruktywne-8562465.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-18 16:14:40.017284+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/c/abb3ce79bdce86-948-568-0-160-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rozmowy sekretarza stanu USA Antony'ego Blinkena z Qin Gangiem były "szczere, rzeczowe i konstruktywne" - przekazał w niedzielę w oświadczeniu amerykański Departament Stanu.</p>

## Uchodźcy z Ukrainy. Polacy zmieniają swoje nastawienie przez "roszczeniową postawę" emigrantów
 - [https://www.bankier.pl/wiadomosc/Uchodzcy-z-Ukrainy-Polacy-zmieniaja-swoje-nastawienie-przez-roszczeniowa-postawe-emigrantow-8558635.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Uchodzcy-z-Ukrainy-Polacy-zmieniaja-swoje-nastawienie-przez-roszczeniowa-postawe-emigrantow-8558635.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-18 15:02:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/b/d89e3f1daf3e51-948-568-0-53-4253-2551.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />68 proc. badanych Polaków opowiada się za przyjmowaniem uchodźców z Ukrainy. 55 proc. badanych jest przeciw dodatkowej pomocy – wynika z badania "Społeczna percepcja uchodźców z Ukrainy, migrantów oraz działań podejmowanych przez polskie państwo".</p>

## Włoskie miasto wprowadza zakaz kostiumów i gołych torsów na ulicach
 - [https://www.bankier.pl/wiadomosc/Wloskie-miasto-wprowadza-zakaz-kostiumow-i-golych-torsow-na-ulicach-8562095.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wloskie-miasto-wprowadza-zakaz-kostiumow-i-golych-torsow-na-ulicach-8562095.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-18 14:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/8/dbe55d361aff31-948-568-0-70-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W popularnej nadmorskiej miejscowości wakacyjnej Gallipoli w Apulii na południu Włoch władze wprowadziły zakaz chodzenia po jej centrum z gołym torsem i w kostiumach kąpielowych. Kara za złamanie zakazu, który będzie obowiązywał od 1 lipca do 20 września, wynosić będzie od 25 do 150 euro.</p>

## Mick Jagger wystawilł na sprzedaż dom za 3,5 mln dolarów. Ma 529 mkw. i dzwonnicę
 - [https://www.bankier.pl/wiadomosc/Mick-Jagger-wystawill-na-sprzedaz-dom-za-3-5-mln-dolarow-Ma-529-mkw-i-dzwonnice-8562430.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Mick-Jagger-wystawill-na-sprzedaz-dom-za-3-5-mln-dolarow-Ma-529-mkw-i-dzwonnice-8562430.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-18 13:03:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/2/345e83e50c9073-948-568-0-35-2037-1222.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Lider zespołu The Rolling Stones Mick Jagger i jego partnerka Melanie Hamrick wystawili na sprzedaż swój dom na Florydzie - poinformowała w niedzielę agencja AP. Nieruchomość o powierzchnia mieszkalnej 529 m kwadratowych została wyceniona na 3,5 mln dolarów.</p>

## Opublikowano wideo z imprezy Partii Konserwatywnej w lockdownie
 - [https://www.bankier.pl/wiadomosc/Opublikowano-wideo-z-imprezy-Partii-Konserwatywnej-w-lockdownie-8562429.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Opublikowano-wideo-z-imprezy-Partii-Konserwatywnej-w-lockdownie-8562429.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-18 12:53:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/0/24703e8c27a964-948-568-0-93-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Brytyjski dziennik "Daily Mirror" opublikował na swojej stronie internetowej wideo z imprezy w siedzibie rządzącej Partii Konserwatywnej w grudniu 2020 r., w czasie trwających restrykcji covidowych, na którym uczestnicy tańczą, piją alkohol i jawnie sobie żartują z ograniczeń.</p>

## Rozwój sztucznej inteligencji już się nie zatrzyma. To wymaga zajęcia się jej stroną moralną i etyczną
 - [https://www.bankier.pl/wiadomosc/Rozwoj-sztucznej-inteligencji-juz-sie-nie-zatrzyma-To-wymaga-zajecia-sie-jej-strona-moralna-i-etyczna-8559681.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rozwoj-sztucznej-inteligencji-juz-sie-nie-zatrzyma-To-wymaga-zajecia-sie-jej-strona-moralna-i-etyczna-8559681.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-18 12:44:21.379273+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/8/6099ec4144ccf5-948-568-0-150-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Eksperci 
zauważają, że choć o sztucznej inteligencji mówi się na razie głównie 
w kontekście biznesowym i rozrywkowym, to w debacie coraz częściej 
pojawia się też wątek etyki i społecznej odpowiedzialności AI, która 
może się przyczynić do rozwiązania globalnych problemów.</p>

## Zawód "żona", a pensji brak. Ile zarobiłaby kobieta, dbając o dom i dzieci? Co roku byłoby ją stać na kupno kawalerki
 - [https://www.bankier.pl/wiadomosc/Zawod-zona-a-pensji-brak-Ile-zarobilaby-kobieta-dbajac-o-dom-i-dzieci-Co-roku-byloby-ja-stac-na-kupno-kawalerki-8560078.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zawod-zona-a-pensji-brak-Ile-zarobilaby-kobieta-dbajac-o-dom-i-dzieci-Co-roku-byloby-ja-stac-na-kupno-kawalerki-8560078.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-18 12:44:21.360575+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/a/bf109af59ccdae-948-568-37-52-2912-1747.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />26,9 tys. zł miesięcznie, czyli 322,9 tys. zł rocznie - tyle z szacunków blogerki ekonomicznej (choć nie tylko) Ilony Kosteckiej powinna wynosić szacowana wypłata żony. Wyliczyła ją na podstawie obowiązujących stawek za wykonywanie przez pracowników tych samych obowiązków domowych.  </p>

## Władze Odessy zakazały kąpieli w morzu z powodu zanieczyszczeń po wysadzeniu tamy na Dnieprze
 - [https://www.bankier.pl/wiadomosc/Wladze-Odessy-zakazaly-kapieli-w-morzu-z-powodu-zanieczyszczen-po-wysadzeniu-tamy-na-Dnieprze-8562417.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wladze-Odessy-zakazaly-kapieli-w-morzu-z-powodu-zanieczyszczen-po-wysadzeniu-tamy-na-Dnieprze-8562417.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-18 12:05:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/f/06c8a99c66c941-948-568-0-153-3840-2303.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Plaże w Odessie są zamknięte; kąpiel w morzu jest zabroniona - oświadczyły w niedzielę władze tego trzeciego co do wielkości miasta Ukrainy, ważnego portu nad Morzem Czarnym. Jakość wody na wybrzeżu pogorszyła się gwałtownie po wysadzeniu przez Rosjan zapory na Dnieprze.</p>

## Teorie spiskowe wiecznie żywe. Inflacja to tajny pomysł rządu, a p(l)andemia była oszustwem
 - [https://www.bankier.pl/wiadomosc/Teorie-spiskowe-wiecznie-zywe-Inflacja-to-tajny-pomysl-rzadu-a-p-l-andemia-byla-oszustwem-8559232.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Teorie-spiskowe-wiecznie-zywe-Inflacja-to-tajny-pomysl-rzadu-a-p-l-andemia-byla-oszustwem-8559232.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-18 11:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/5/08e06cf84bd091-948-568-0-175-2928-1756.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Co czwarty mieszkaniec Wielkiej Brytanii wierzy, że pandemia Covid-19 była oszustwem, a co trzeci - że wzrost cen jest spiskiem rząd, którego celem jest zwiększenia kontroli nad społeczeństwem - wynika z badania opisującego wiarę Brytyjczyków w teorie spiskowe, omawianego przez dziennik "The Guardian".</p>

## Życie w sieci. Młodym Polakom trudno jest wyobrazić sobie funkcjonowanie bez smartfona
 - [https://www.bankier.pl/wiadomosc/Zycie-w-sieci-Mlodym-Polakom-trudno-jest-wyobrazic-sobie-funkcjonowanie-bez-smartfona-8559671.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zycie-w-sieci-Mlodym-Polakom-trudno-jest-wyobrazic-sobie-funkcjonowanie-bez-smartfona-8559671.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-18 11:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/2/60122a6d374f04-948-568-0-108-2717-1630.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Co dziesiąty młody Polak mógłby funkcjonować bez telefonu najwyżej godzinę - wynika z raportu "Młodzi vs Mobile". Podczas zakupów w sklepach stacjonarnych z telefonu korzysta 78 proc. najmłodszych, sprawdzając oceny i opinie o produktach - dodano.</p>

## Belgia i Francja interweniują ws. wysokich cen żywności, Holandia nie ma zamiaru
 - [https://www.bankier.pl/wiadomosc/Belgia-i-Francja-interweniuja-ws-wysokich-cen-zywnosci-Holandia-nie-ma-zamiaru-8562402.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Belgia-i-Francja-interweniuja-ws-wysokich-cen-zywnosci-Holandia-nie-ma-zamiaru-8562402.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-18 10:12:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/6/0d963cdcb78af7-948-568-2-42-997-598.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Holandia nie zamierza iść w ślady Belgii i Francji i nie będzie interweniować w sprawie wysokich cen artykułów spożywczych w supermarketach - poinformował w niedzielę portal NU, cytując rozmowę z holenderską minister gospodarki Micky Adriaansens.</p>

## Katastrofy pogodowe w Europie wyrządziły od 1980  straty szacowane na 560 miliardów euro
 - [https://www.bankier.pl/wiadomosc/Katastrofy-pogodowe-w-Europie-wyrzadzily-od-1980-straty-szacowane-na-560-miliardow-euro-8559660.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Katastrofy-pogodowe-w-Europie-wyrzadzily-od-1980-straty-szacowane-na-560-miliardow-euro-8559660.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-18 09:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/3/686dbc3eec4169-948-568-0-0-2546-1527.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ekstremalne zjawiska pogodowe, takie jak fale upałów i powodzie, spowodowały od 1980 roku w Europie śmierć około 195 000 osób i wyrządziły straty szacowane na 560 miliardów euro - poinformowała Europejska Agencja Środowiska (EEA), nawołując do zmiany podejścia w tej kwestii.</p>

## Tokio zacznie wykorzystywać ChatGPT do prac urzędniczych, by "lepiej zarządzać miastem"
 - [https://www.bankier.pl/wiadomosc/Tokio-zacznie-wykorzystywac-ChatGPT-do-prac-urzedniczych-by-lepiej-zarzadzac-miastem-8559543.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tokio-zacznie-wykorzystywac-ChatGPT-do-prac-urzedniczych-by-lepiej-zarzadzac-miastem-8559543.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-18 09:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/a/06098ab83df86f-948-568-0-273-4206-2523.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Gubernator Tokio Yuriko Koike zapowiedziała, że od sierpnia władze miasta zaczną wykorzystywać ChatGPT do pisania tekstów, analizy dokumentów i innych prac urzędniczych, co powinno "znacznie odmienić sposób pracy miejskiej administracji” - podała japońska agencja Kyodo.</p>

## Postpandemiczny kryzys w Ameryce Łacińskiej. Eksploatacja pracy nieletnich coraz powszechniejsza
 - [https://www.bankier.pl/wiadomosc/Postpandemiczny-kryzys-w-Ameryce-Lacinskiej-Eksploatacja-pracy-nieletnich-coraz-powszechniejsza-8558904.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Postpandemiczny-kryzys-w-Ameryce-Lacinskiej-Eksploatacja-pracy-nieletnich-coraz-powszechniejsza-8558904.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-18 06:29:05.190371+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/f/47b49456ddb246-948-568-0-250-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Jak wynika z raportu ogłoszonego w stolicy Peru, 
Limie,  zjawisko to w Ameryce Łacińskiej niezmiernie się rozszerzyło  w 
ostatnich latach wskutek zubożenia regionu w następstwie pandemii 
COVID-19.</p>

## Ekonomista: Wiele krajów Europy jest cenowo dostępnych dla Polaków
 - [https://www.bankier.pl/wiadomosc/Ekonomista-Wiele-krajow-Europy-jest-cenowo-dostepnych-dla-Polakow-8562367.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ekonomista-Wiele-krajow-Europy-jest-cenowo-dostepnych-dla-Polakow-8562367.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-18 06:29:05.187564+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/1/b8fa4b618ef7b5-948-568-37-85-962-577.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wiele krajów Europy jest dostępnych cenowo dla Polaków, co wynika częściowo z inflacji w naszym kraju, a z drugiej - z długofalowego trendu rozwoju gospodarczego Polski - powiedział PAP prof. Paweł Baranowski z Wydziału Ekonomiczno-Socjologicznego Uniwersytetu Łódzkiego.</p>

## Katastrofa demograficzna w Polsce postępuje. Zmiany może odczuć m.in. rynek mieszkaniowy
 - [https://www.bankier.pl/wiadomosc/Katastrofa-demograficzna-w-Polsce-postepuje-Zmiany-moze-odczuc-m-in-rynek-mieszkaniowy-8559100.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Katastrofa-demograficzna-w-Polsce-postepuje-Zmiany-moze-odczuc-m-in-rynek-mieszkaniowy-8559100.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-18 06:29:05.185031+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/b/a3b6ec9274b82c-948-568-10-290-3966-2380.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Liczba ludności w wieku produkcyjnym w Polsce będzie stopniowo spadać i za niespełna 17 lat zmaleje o 8,4 proc. - wskazali eksperci CBRE. Według nich zmiany te może odczuć m.in. sektor biurowy i rynek mieszkaniowy.</p>

## Polacy oszczędzają na zakupach żywności. Najczęściej rezygnujemy z tych rzeczy
 - [https://www.bankier.pl/wiadomosc/Polacy-oszczedzaja-na-zakupach-zywnosci-Najczesciej-rezygnujemy-z-tych-rzeczy-8562342.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polacy-oszczedzaja-na-zakupach-zywnosci-Najczesciej-rezygnujemy-z-tych-rzeczy-8562342.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-18 05:01:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/a/bced96380f9dd4-948-568-4-61-1766-1059.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />91 proc. Polaków oszczędza na  zakupach żywności – wynika z badania  BIG InfoMonitor. Najczęściej rodacy rezygnują z kupna alkoholu, gotowych dań i słodyczy. Jednocześnie 46 proc. badanych  traci pieniądze z powodu marnowania żywności - najczęściej  ok. 100 zł miesięcznie.</p>

## "Avatar 3", "Gwiezdne Wojny" i "Avengersi" z opóźnieniem. Disney musi na nich najpierw zarobić?
 - [https://www.bankier.pl/wiadomosc/Avatar-3-Gwiezdne-Wojny-i-Avengersi-z-opoznieniem-Disney-musi-na-nich-najpierw-zarobic-8559940.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Avatar-3-Gwiezdne-Wojny-i-Avengersi-z-opoznieniem-Disney-musi-na-nich-najpierw-zarobic-8559940.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-18 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/6/6af1de1bddd9b2-948-568-600-427-1642-985.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Fani disneyowskiej franczyzy będą musieli poczekać na
 kolejne części "Avatara", "Gwiezdnych Wojen" i "Avengersów". Koncern 
ogłosił, że musi zrobić "kilka przetasowań w kalendarzy premier", w 
praktyce polegających na ich opóźnieniu.</p>

## Kobiety coraz częściej dołączają do branży IT i Tech. Tu można lepiej zarobić
 - [https://www.bankier.pl/wiadomosc/Kobiety-coraz-czesciej-dolaczaja-do-branzy-IT-i-Tech-Tu-mozna-lepiej-zarobic-8560530.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kobiety-coraz-czesciej-dolaczaja-do-branzy-IT-i-Tech-Tu-mozna-lepiej-zarobic-8560530.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-18 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/a/ac7cb23e608802-948-568-0-180-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Aby technologie się rozwijały, kobiety muszą być obecne w branżach technologicznych - powiedziała PAP Dr Bianka Siwińska, prezes Fundacji Edukacyjnej Perspektywy i twórczyni Pespektyw Women in Tech Summit.</p>

## Polacy zapłacą w tym roku tylko ok. 40 proc. rynkowej ceny energii. Resztę sfinansują spółki
 - [https://www.bankier.pl/wiadomosc/Polacy-zaplaca-w-tym-roku-tylko-ok-40-proc-rynkowej-ceny-energii-Reszte-sfinansuja-spolki-8557263.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polacy-zaplaca-w-tym-roku-tylko-ok-40-proc-rynkowej-ceny-energii-Reszte-sfinansuja-spolki-8557263.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-18 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/8/e9df257cb10820-948-568-0-270-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wprowadzenie tarczy solidarnościowej spowodowało, że 8
 mln polskich gospodarstw domowych zapłaci w tym roku tylko 40 proc. 
rynkowej ceny za energię elektryczną. Resztę sfinansują spółki 
energetyczne, czyli m.in. PGE, Tauron, Enea i Energa, które gromadzą 
środki na ten cel w Funduszu Wypłaty Różnicy Ceny. </p>

## Rynek pracy w Polsce lekko się ożywia. Te branże będą zatrudniać, a zwolnienia grożą tym profesjom
 - [https://www.bankier.pl/wiadomosc/Rynek-pracy-w-Polsce-lekko-sie-ozywia-Te-branze-beda-zatrudniac-a-zwolnienia-groza-tym-profesjom-8559070.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rynek-pracy-w-Polsce-lekko-sie-ozywia-Te-branze-beda-zatrudniac-a-zwolnienia-groza-tym-profesjom-8559070.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-06-18 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/c/0c798e1cc0d6e9-948-568-0-80-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W III kwartale tego roku 31 proc. przedsiębiorców planuje zatrudnić nowych pracowników, a 17 proc. zredukować etaty - wynika z raportu „Barometr ManpowerGroup Perspektyw Zatrudnienia”. 48 proc. firm chce pozostawić zatrudnienie na dotychczasowym poziomie - dodano.</p>

