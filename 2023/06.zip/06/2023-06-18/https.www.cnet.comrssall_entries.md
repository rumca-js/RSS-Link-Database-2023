# Source:CNET, URL:https://www.cnet.com/rss/all/, language:en-US

## Amazon and Best Buy Knock Up to 50% Off Already Affordable Motorola Phones     - CNET
 - [https://www.cnet.com/deals/amazon-and-best-buy-knock-up-to-50-off-already-affordable-motorola-phones/#ftag=CADf328eec](https://www.cnet.com/deals/amazon-and-best-buy-knock-up-to-50-off-already-affordable-motorola-phones/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-18 17:00:06+00:00

Motorola makes some of our favorite budget-friendly phones in 2023, and right now you can snag one for as much as $500 off the usual price.

## Watch UEFA Nations League Final Soccer: Livestream Croatia vs. Spain From Anywhere     - CNET
 - [https://www.cnet.com/tech/services-and-software/watch-uefa-nations-league-final-soccer-livestream-croatia-vs-spain-from-anywhere/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/watch-uefa-nations-league-final-soccer-livestream-croatia-vs-spain-from-anywhere/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-18 16:40:06+00:00

The Croatians aim for their first major international title as they face La Furia Roja in Sunday's final.

## Formula 1 Racing 2023: How to Watch and Livestream the Canadian GP Today     - CNET
 - [https://www.cnet.com/tech/services-and-software/formula-1-racing-2023-how-to-watch-and-livestream-the-canadian-gp-today/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/formula-1-racing-2023-how-to-watch-and-livestream-the-canadian-gp-today/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-18 15:30:06+00:00

Max Verstappen and F1 are back in North America this week, as the Red Bull superstar looks for his fourth straight victory.

## Prime Video: The 36 Absolute Best TV Shows to Watch     - CNET
 - [https://www.cnet.com/culture/entertainment/prime-video-the-36-absolute-best-tv-series-to-watch-june-2023/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/prime-video-the-36-absolute-best-tv-series-to-watch-june-2023/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-18 15:15:07+00:00

Here are some highly rated series you should try, plus a look at what's new in June.

## 'Demon Slayer' Season 3: How to Watch the Finale From Anywhere     - CNET
 - [https://www.cnet.com/tech/services-and-software/demon-slayer-season-3-how-to-watch-finale-from-anywhere/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/demon-slayer-season-3-how-to-watch-finale-from-anywhere/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-18 15:00:00+00:00

The Swordsmith Village Arc is coming to a close.

## Rest Easy With Early Fourth of July Savings on Birch Mattresses and More     - CNET
 - [https://www.cnet.com/deals/rest-easy-with-early-fourth-of-july-savings-on-birch-mattresses-and-more/#ftag=CADf328eec](https://www.cnet.com/deals/rest-easy-with-early-fourth-of-july-savings-on-birch-mattresses-and-more/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-18 14:30:06+00:00

Save hundreds of dollars on mattresses, bases and accessories sitewide, and score two free eco-rest pillows with every mattress purchase.

## Try This Nifty Hack the Next Time You're Out of Dishwasher Detergent     - CNET
 - [https://www.cnet.com/home/kitchen-and-household/try-this-nifty-hack-the-next-time-youre-out-of-dishwasher-detergent/#ftag=CADf328eec](https://www.cnet.com/home/kitchen-and-household/try-this-nifty-hack-the-next-time-youre-out-of-dishwasher-detergent/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-18 13:30:05+00:00

This two-ingredient detergent replacement works just as well as dishwasher pods if you're in a real pinch.

## Pet Safety Checklist: How to Securely Leave Your Pets Home Alone     - CNET
 - [https://www.cnet.com/home/kitchen-and-household/pet-safety-checklist-how-to-securely-leave-your-pets-home-alone/#ftag=CADf328eec](https://www.cnet.com/home/kitchen-and-household/pet-safety-checklist-how-to-securely-leave-your-pets-home-alone/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-18 12:30:06+00:00

Whether you're traveling soon or pulling a long day at the office, consult this ultimate pet safety guide first.

## Beyond Driverless Trucks: Building Infrastructure for Autonomous EV Systems     - CNET
 - [https://www.cnet.com/roadshow/news/beyond-driverless-trucks-building-infrastructure-for-autonomous-ev-systems/#ftag=CADf328eec](https://www.cnet.com/roadshow/news/beyond-driverless-trucks-building-infrastructure-for-autonomous-ev-systems/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-18 12:00:14+00:00

Swedish company Einride says it sees the road ahead for shipping: electric, autonomous vehicles.

## No Driver? No Problem. Building Autonomous EV Systems video     - CNET
 - [https://www.cnet.com/roadshow/videos/no-driver-no-problem-building-autonomous-ev-systems/#ftag=CADf328eec](https://www.cnet.com/roadshow/videos/no-driver-no-problem-building-autonomous-ev-systems/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-18 12:00:03+00:00

A Sweden-based transportation company called Einride aims to make autonomous, electric vehicles the future of shipping.

## Best Internet Providers in Sacramento     - CNET
 - [https://www.cnet.com/home/internet/best-internet-providers-in-sacramento-ca/#ftag=CADf328eec](https://www.cnet.com/home/internet/best-internet-providers-in-sacramento-ca/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-06-18 07:00:00+00:00

The big names versus the rest of the field: Which Sacramento provider fits you best?

