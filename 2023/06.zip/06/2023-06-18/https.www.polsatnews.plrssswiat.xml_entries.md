# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## Wojna w Ukrainie. Pijani rosyjscy żołnierze okaleczyli dwóch ukraińskich jeńców wojennych
 - [https://www.polsatnews.pl/wiadomosc/2023-06-18/wojna-w-ukrainie-pijani-rosyjscy-zolnierze-okaleczyli-dwoch-ukrainskich-jencow-wojennych/](https://www.polsatnews.pl/wiadomosc/2023-06-18/wojna-w-ukrainie-pijani-rosyjscy-zolnierze-okaleczyli-dwoch-ukrainskich-jencow-wojennych/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-06-18 20:09:00+00:00

Rosyjscy żołnierze okaleczyli dwóch ukraińskich jeńców wojennych. Jeden z nich przetrzymywany był przez trzy miesiące. Takie okrucieństwa są powszechne w toczącej się w Ukrainie wojnie - pisze The Sunday Times.

## Grecja. Zaginięcie 27-letniej Polki. Media: Znaleziono ciało kobiety
 - [https://www.polsatnews.pl/wiadomosc/2023-06-18/grecja-zaginiecie-27-letniej-polki-media-znaleziono-cialo/](https://www.polsatnews.pl/wiadomosc/2023-06-18/grecja-zaginiecie-27-letniej-polki-media-znaleziono-cialo/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-06-18 16:51:00+00:00

W pobliżu drogi między Tigaki, a Marmari na wyspie Kos znaleziono ciało młodej kobiety - podają greckie portale informacyjne. Wiele wskazuje na to, że to zaginiona 27-latka z Wrocławia. Kobieta zaginęła 12 czerwca. Nie dotarła na spotkanie ze swoim chłopakiem i od tej pory nie ma z nią kontaktu.

## Rosja: Nieudana operacja plastyczna nosa. 26-latka trafiła pod respirator
 - [https://www.polsatnews.pl/wiadomosc/2023-06-18/rosja-nieudana-operacja-plastyczna-nosa-26-latka-trafila-pod-respirator/](https://www.polsatnews.pl/wiadomosc/2023-06-18/rosja-nieudana-operacja-plastyczna-nosa-26-latka-trafila-pod-respirator/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-06-18 14:44:00+00:00

26-letnia modelka z Moskwy zapadła w śpiączkę po operacji plastycznej nosa. Z elitarnej kliniki estetycznej trafiła do szpitala publicznego, gdzie oddycha dzięki pracy respiratora.

## Rosja: Niedźwiedzica wystraszyła pracowników. Uciekli na wieżę przesyłową
 - [https://www.polsatnews.pl/wiadomosc/2023-06-18/rosja-niedzwiedzica-wystraszyla-pracownikow-uciekli-na-wieze-przesylowa/](https://www.polsatnews.pl/wiadomosc/2023-06-18/rosja-niedzwiedzica-wystraszyla-pracownikow-uciekli-na-wieze-przesylowa/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-06-18 13:36:00+00:00

W rejonie Irkucka doszło do groźnie wyglądającego incydentu, kiedy pracownicy firmy energetycznej musieli schronić się na wieży przesyłowej. Zagrożeniem była niedźwiedzica, która wraz z młodym szukała w okolicy pożywienia.

## Hawaje: Ekipa filmowa Netflixa zaatakowana przez rekiny
 - [https://www.polsatnews.pl/wiadomosc/2023-06-18/hawaje-ekipa-filmowa-netflixa-zaatakowana-przez-rekiny/](https://www.polsatnews.pl/wiadomosc/2023-06-18/hawaje-ekipa-filmowa-netflixa-zaatakowana-przez-rekiny/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-06-18 12:01:00+00:00

Ekipa filmowa Netflixa została zaatakowana przez żarłacze tygrysie w pobliżu Hawajów. Jeden z nich wskoczył na łódź filmowców. – To było coś jak z filmu Szczęki - podkreślił producent Huw Cordey.

## Kazachstan: Uzbrojony mężczyzna wziął zakładników w banku. Służby przeprowadziły szturm
 - [https://www.polsatnews.pl/wiadomosc/2023-06-18/kazachstan-uzbrojony-mezczyzna-wzial-zakladnikow-w-banku-trwa-operacja-sluzb/](https://www.polsatnews.pl/wiadomosc/2023-06-18/kazachstan-uzbrojony-mezczyzna-wzial-zakladnikow-w-banku-trwa-operacja-sluzb/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-06-18 10:44:00+00:00

Uzbrojony mężczyzny wtargnął do oddziału banku w stolicy Kazachstanu Astanie, wziął zakładników i zabarykadował się w budynku. Według lokalnych mediów żądał, by bank przekazał wszystkie swoje środki na niepełnosprawne dzieci i potrzebujących. Służby przeprowadziły szturm i uwolniły zakładników.

## Grecja. Nowe informacje ws. zaginionej 27-letniej Polki. Jest nagranie z monitoringu
 - [https://www.polsatnews.pl/wiadomosc/2023-06-18/grecja-nowe-informacje-ws-zaginionej-27-letniej-polki-jest-nagranie-z-nia-i-jej-telefon/](https://www.polsatnews.pl/wiadomosc/2023-06-18/grecja-nowe-informacje-ws-zaginionej-27-letniej-polki-jest-nagranie-z-nia-i-jej-telefon/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-06-18 10:31:00+00:00

W Grecji trwa śledztwo ws. zaginięcia 27-letniej Polski. Udało się odnaleźć jej telefon komórkowy, a także zidentyfikowano ją na nagraniach w jednym z lokali. Polkę ostatni raz widziano w poniedziałek wieczorem. Kobieta, która pracowała w jednym hoteli na wyspie Kos, nie dotarła na spotkanie ze swoim chłopakiem i od tej pory nie ma z nią kontaktu.

## Odkryto planetę z dwoma słońcami. Jest podobna do tej z "Gwiezdnych wojen"
 - [https://www.polsatnews.pl/wiadomosc/2023-06-18/odkryto-planete-z-dwoma-sloncami-jest-podobna-do-tej-z-gwiezdnych-wojen/](https://www.polsatnews.pl/wiadomosc/2023-06-18/odkryto-planete-z-dwoma-sloncami-jest-podobna-do-tej-z-gwiezdnych-wojen/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-06-18 07:11:00+00:00

Tatooine z Gwiezdnych wojen, czyli fikcyjna planeta mające dwa słońca, może istnieć naprawdę - wynika z obserwacji przedstawionych przez naukowców. Odkrytą planetę nazwano BEBOB-1c i ustalono, że jest ona 65 razy cięższa od Ziemia. Jak dodano, w tym systemie może być więcej takich ciał niebieskich.

## Chiny. Sekretarz stanu USA Anthony Blinken przybył z wizytą do Pekinu
 - [https://www.polsatnews.pl/wiadomosc/2023-06-18/chiny-sekretarz-stanu-usa-anthony-blinken-przybyl-z-wizyta-do-pekinu/](https://www.polsatnews.pl/wiadomosc/2023-06-18/chiny-sekretarz-stanu-usa-anthony-blinken-przybyl-z-wizyta-do-pekinu/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-06-18 04:32:00+00:00

Anthony Blinken odwiedził Pekin jako najwyższy od 5 lat amerykański dyplomata. Sekretarz stanu USA pojawił się w Chinach z misją poprawy wzajemnych kontaktów dyplomatycznych. Wizyta ma przygotować grunt pod spotkanie Xi Jinpinga i Joe Bidena.

## Rosja: "Seryjna donosicielka" znów w akcji. Oskarżyła matkę zabitego żołnierza
 - [https://www.polsatnews.pl/wiadomosc/2023-06-18/rosja-seryjna-donosicielka-znow-w-akcji-oskarzyla-matke-zabitego-zolnierza/](https://www.polsatnews.pl/wiadomosc/2023-06-18/rosja-seryjna-donosicielka-znow-w-akcji-oskarzyla-matke-zabitego-zolnierza/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-06-18 04:05:00+00:00

Ponad 1000 donosów w ciągu roku rozesłała Anna Korobkowa, wielbicielka zbrodniczej polityki Władimira Putina. Kobieta zagląda do rosyjskich mediów opozycyjnych nie po to, by uzyskać informacje inne od propagandy Kremla, lecz wyszukiwać ofiary swoich działań. Tym razem uderzyła w kobietę, która na łamach niezależnej gazety opłakiwała śmierć 18-letniego syna zmobilizowanego pod przymusem do wojny.

