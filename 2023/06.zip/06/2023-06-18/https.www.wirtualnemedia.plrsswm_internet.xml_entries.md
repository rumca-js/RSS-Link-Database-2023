# Source:Wirtualne Media - Internet, URL:https://www.wirtualnemedia.pl/rss/wm_internet.xml, language:pl-PL

## Netflix, Disney+, HBO Max, Canal+ i Viaplay także poza Polską. Jak skorzystać na wakacjach?
 - [https://www.wirtualnemedia.pl/artykul/wspoldzielnie-konta-netflix-jak-zrezygnowac-disney-hbo-max-canal-online-viaplay-skyshowtime-tvp-vod-polsat-box-go-player-ogladanie-za-granica-unia-europejska](https://www.wirtualnemedia.pl/artykul/wspoldzielnie-konta-netflix-jak-zrezygnowac-disney-hbo-max-canal-online-viaplay-skyshowtime-tvp-vod-polsat-box-go-player-ogladanie-za-granica-unia-europejska)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-06-18 19:01:38.046181+00:00

Podczas wakacji w kraju Unii Europejskiej można korzystać z treści wideo na żądanie i kanałów telewizyjnych, dostępnych w serwisach streamingowych, które wykupujemy. Nie zawsze jednak łatwo zainstalujemy pożądaną aplikację na telewizorze wynajmowanego pokoju. W przypadku wyjazdu poza UE, lepiej wcześniej pobrać pożądane treści.

## Netflix, Disney+, HBO Max, Canal+ i Viaplay także poza Polską. Jak skorzystać na wakacjach?
 - [https://www.wirtualnemedia.pl/artykul/wspoldzielnie-konta-netflix-disney-hbo-max-canal-online-viaplay-skyshowtime-tvp-vod-polsat-box-go-player-ogladanie-za-granica-unia-europejska](https://www.wirtualnemedia.pl/artykul/wspoldzielnie-konta-netflix-disney-hbo-max-canal-online-viaplay-skyshowtime-tvp-vod-polsat-box-go-player-ogladanie-za-granica-unia-europejska)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-06-18 06:29:51.908079+00:00

Podczas wakacji w kraju Unii Europejskiej można korzystać z treści wideo na żądanie i kanałów telewizyjnych, dostępnych w serwisach streamingowych, które wykupujemy. Nie zawsze jednak łatwo zainstalujemy pożądaną aplikację na telewizorze wynajmowanego pokoju. W przypadku wyjazdu poza UE, lepiej wcześniej pobrać pożądane treści.

## Dwoje na troje dzieci w Europie doświadczyło krzywdy seksualnej w internecie
 - [https://www.wirtualnemedia.pl/artykul/krzywda-seksualna-dzieci-internet](https://www.wirtualnemedia.pl/artykul/krzywda-seksualna-dzieci-internet)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-06-18 06:29:51.905816+00:00

57 proc. ankietowanych z Polski zaznaczyło w ankiecie WeProtect Global Allience, że doświadczyło spotkania z dorosłym (nieznajomym lub znajomym), które angażowało ich w rozmowy o charakterze jednoznacznie seksualnym lub wysyłano im materiały o charakterze jednoznacznie seksualnym, 27 proc. z nich doświadczyło tego w wieku 12 lat lub młodszym. 81 proc. respondentów w Polsce doświadczyło, że ktoś próbował rozmawiać z nimi na tematy seksualne za pośrednictwem ich telefonów komórkowych, a 58 proc. z tych zdarzeń miało miejsce za pośrednictwem prywatnych wiadomości.

