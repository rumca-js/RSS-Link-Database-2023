# Source:Business insider, URL:https://businessinsider.com.pl/.feed, language:en-US

## Czy stare banknoty euro są ważne? Czy trzeba je wymienić?
 - [https://businessinsider.com.pl/poradnik-finansowy/czy-stare-banknoty-euro-sa-wazne-najwazniejsze-informacje/swqnqmn](https://businessinsider.com.pl/poradnik-finansowy/czy-stare-banknoty-euro-sa-wazne-najwazniejsze-informacje/swqnqmn)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-18 21:45:16+00:00

Waluta euro jest powszechnie obowiązującym środkiem płatniczym w 20. krajach Unii Europejskiej. Emitentem jest Europejski Bank Centralny. W maju 2019 roku EBC zapowiedział całkowicie nowe banknoty o nominale 100 i 200 euro. Weszły one do obiegu 28 maja 2019 roku. Są to kolejne banknoty z serii "Europa", która wprowadzana jest na rynek od 2013 roku. W obrocie są jednak jeszcze starsze banknoty. Czy stare banknoty euro są ważne? Czym różnią się stare od nowych?

## "Mieszkania widma". Nowa plaga w Niemczech
 - [https://businessinsider.com.pl/wiadomosci/mieszkania-widma-nowa-plaga-w-niemczech/psqh6ss](https://businessinsider.com.pl/wiadomosci/mieszkania-widma-nowa-plaga-w-niemczech/psqh6ss)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-18 12:51:54+00:00

Szukając mieszkania za naszą zachodnią granicą, warto zachować wzmożoną czujność. W internecie jest sporo "cudownych pokoi", ale nierzadko okazuje się, że te mieszkania... po prostu nie istnieją.

## Arbuzy będą tańsze tego roku. Wyjaśnienie jest na rynku walutowym
 - [https://businessinsider.com.pl/gielda/wiadomosci/arbuzy-beda-tansze-tego-roku-wyjasnienie-jest-na-rynku-walutowym/8997tzl](https://businessinsider.com.pl/gielda/wiadomosci/arbuzy-beda-tansze-tego-roku-wyjasnienie-jest-na-rynku-walutowym/8997tzl)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-18 12:16:46+00:00

Rok po roku coraz więcej arbuzów sprowadzamy do Polski z Turcji. Jedną z ich zalet jest cena. Podobnie jak greckie i włoskie, są dużo tańsze od arbuzów importowanych z Hiszpanii i Niemiec. A w tym roku nie dość, że zbiory Turkom dopisały, to jeszcze lira spadła na łeb na szyję. A to radykalnie zmniejsza koszty dostarczenia arbuzów przez tureckich rolników.

## Zakupy "złotego prezesa". Adam Glapiński postawił na kruszec i nie przestaje kupować
 - [https://businessinsider.com.pl/gospodarka/makroekonomia/zakupy-zlotego-prezesa-adam-glapinski-postawil-na-kruszec-i-nie-przestaje-kupowac/x4pxcxy](https://businessinsider.com.pl/gospodarka/makroekonomia/zakupy-zlotego-prezesa-adam-glapinski-postawil-na-kruszec-i-nie-przestaje-kupowac/x4pxcxy)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-18 11:22:00+00:00

Narodowy Bank Polski od dwóch miesięcy znów jest aktywny na rynku złota – w kwietniu i maju kupił ok. 34 tony kruszcu. To oznacza, że w zasobach banku centralnego znajduje się ponad 263 tony złota, a majowe zakupy były największe na świecie.

## Dzielę się opieką nad dziećmi z innymi rodzicami. Siedem wskazówek jak to zrobić i zaoszczędzić
 - [https://businessinsider.com.pl/wiadomosci/dziele-sie-opieka-nad-dziecmi-z-innymi-rodzicami-7-wskazowek-jak-to-zrobic-i/qm9ev7r](https://businessinsider.com.pl/wiadomosci/dziele-sie-opieka-nad-dziecmi-z-innymi-rodzicami-7-wskazowek-jak-to-zrobic-i/qm9ev7r)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-18 10:30:00+00:00

Oto trik wychowawczy, który pozwoli ci zaoszczędzić mnóstwo czasu i pieniędzy. Pewna Amerykanka przez rok testowała naprzemienną opieką nad dziećmi z innymi rodzicami. Oto jej wnioski.

## Brytyjczyk mógłby zostać szefem NATO. Francja nie chce o tym słyszeć
 - [https://businessinsider.com.pl/wiadomosci/brytyjczyk-moglby-zostac-szefem-nato-francja-nie-chce-o-tym-slyszec/k465psp](https://businessinsider.com.pl/wiadomosci/brytyjczyk-moglby-zostac-szefem-nato-francja-nie-chce-o-tym-slyszec/k465psp)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-18 10:08:30+00:00

Prezydent Francji Emmanuel Macron próbuje zablokować kandydaturę brytyjskiego ministra obrony Bena Wallace'a na stanowisko nowego sekretarza generalnego NATO – podaje  "The Sunday Telegraph". Polityk tymczasem jest świetnie oceniany ze względu na postawę wobec konfliktu w Ukrainie.

## Lepiej uważaj, co robisz na balkonie
 - [https://businessinsider.com.pl/wiadomosci/lepiej-uwazaj-co-robisz-na-balkonie-co-wolno-a-czego-nie/xx14r8n](https://businessinsider.com.pl/wiadomosci/lepiej-uwazaj-co-robisz-na-balkonie-co-wolno-a-czego-nie/xx14r8n)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-18 09:39:51+00:00

Zakaz trzepania dywanów, wyrzucania niedopałków, trzymania zwierząt i dokarmiania ptaków – spółdzielnie i wspólnoty dają jasne wytyczne, co można, a czego nie można robić na balkonach. Niektóre zakazy mogą nieźle zaskoczyć.

## Izrael przebija Polskę. Tam światowy gigant zainwestuje jeszcze więcej
 - [https://businessinsider.com.pl/gospodarka/izrael-przebija-polske-tam-swiatowy-gigant-zainwestuje-jeszcze-wiecej/452qqzt](https://businessinsider.com.pl/gospodarka/izrael-przebija-polske-tam-swiatowy-gigant-zainwestuje-jeszcze-wiecej/452qqzt)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-18 09:10:11+00:00

Intel buduje wielki zakład pod Wrocławiem – to największa zagraniczna inwestycja w historii Polski. Teraz szef rządu Izraela Benjamin Netanyahu zapowiada największą inwestycję zagraniczną w historii jego kraju. Będzie to... również zakład Intela.

## Samochód przyszłości nie lata, za to chroni przed cyberatakami i dostarcza prąd do domu
 - [https://businessinsider.com.pl/technologie/samochod-przyszlosci-nie-lata-za-to-dostarcza-prad-do-domu/7nqnf1t](https://businessinsider.com.pl/technologie/samochod-przyszlosci-nie-lata-za-to-dostarcza-prad-do-domu/7nqnf1t)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-18 08:43:48+00:00

Jak wyobrażasz sobie samochód przyszłości? Zespół z Renault postanowił odpowiedzieć na to pytanie, a efekty swojej pracy pokazał podczas konferencji VivaTech w Paryżu, która odbyła się w tym miesiącu.

## Trzy najważniejsze lekcje Steve'a Jobsa. Po 18 latach od pamiętnego przemówienia nadal aktualne
 - [https://businessinsider.com.pl/lifestyle/slowa-stevea-jobsa-przeszly-do-historii-18-lat-temu-dal-studentom-3-rady/wb04d61](https://businessinsider.com.pl/lifestyle/slowa-stevea-jobsa-przeszly-do-historii-18-lat-temu-dal-studentom-3-rady/wb04d61)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-18 08:30:00+00:00

"Stay hungry. Stay foolish"! Te słowa, jak i wiele innych kultowych cytatów Steve'a Jobsa, pochodzi z przemówienia inauguracyjnego z 12 czerwca 2005 r., które wygłosił do absolwentów Uniwersytetu Stanforda. Pomimo upływu czasu słowa Jobsa nadal trafiają w punkt.

## Bierzesz tyle urlopu, ile tylko chcesz. Coraz więcej polskich firm to wprowadza
 - [https://businessinsider.com.pl/gospodarka/firmy-coraz-czesciej-mowia-bierz-urlopu-ile-tylko-chcesz/tkw9xv5](https://businessinsider.com.pl/gospodarka/firmy-coraz-czesciej-mowia-bierz-urlopu-ile-tylko-chcesz/tkw9xv5)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-18 08:12:44+00:00

Kodeks pracy ściśle reguluje to, ile pracownik może wziąć wolnego. Coraz więcej polskich pracodawców z limitu rezygnuje. I mówią zatrudnionym – bierzcie tyle urlopu, ile potrzebujecie.

## Cios w gospodarczą politykę rządu. Taką ocenę wystawili Polacy
 - [https://businessinsider.com.pl/gospodarka/cios-w-gospodarcza-polityke-rzadu-taka-ocene-wystawili-polacy/n4nlk8q](https://businessinsider.com.pl/gospodarka/cios-w-gospodarcza-polityke-rzadu-taka-ocene-wystawili-polacy/n4nlk8q)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-18 07:46:31+00:00

Tylko 20 proc. badanych dobrze ocenia stan polskiej gospodarki i finansów publicznych po ośmiu latach rządów PiS – wynika z najnowszego sondażu. Niemal 38 proc. Polaków wystawia z kolei ocenę niedostateczną.

## Dodatkowe kilogramy ciążą w pracy. Nadwaga i otyłość to gorsze zarobki i rzadsze awanse
 - [https://businessinsider.com.pl/praca/nadwaga-i-otylosc-to-gorsze-zarobki-i-rzadsze-awanse-dodatkowe-kilogramy-ciaza-w/fhk2kz3](https://businessinsider.com.pl/praca/nadwaga-i-otylosc-to-gorsze-zarobki-i-rzadsze-awanse-dodatkowe-kilogramy-ciaza-w/fhk2kz3)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-18 07:14:19+00:00

Badania nie pozostawiają złudzeń — osoby z nadwagą i otyłością zarabiają mniej i rzadziej awansują niż ich koledzy i koleżanki o BMI określanym jako prawidłowe. Wraz z rosnącą liczbą osób dotkniętych otyłością, coraz bardziej istotne staje się uregulowanie ich sytuacji w miejscu pracy. Problemem dyskryminacji ze względu na wagę zajmują się sądy. Wyroki wydały m.in. Trybunał Sprawiedliwości Unii Europejskiej i Europejski Trybunał Praw Człowieka.

## Najwyższy wieżowiec poza Warszawą przejdzie wielki remont
 - [https://businessinsider.com.pl/gospodarka/najwyzszy-wiezowiec-poza-warszawa-przejdzie-wielki-remont/cfd13gf](https://businessinsider.com.pl/gospodarka/najwyzszy-wiezowiec-poza-warszawa-przejdzie-wielki-remont/cfd13gf)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-18 07:02:57+00:00

Wrocławski wieżowiec Sky Tower po przeszło dekadzie od otwarcia przechodzi poważny remont. Zupełnie zmienione zostaną wnętrza galerii handlowej wewnątrz budynku – przebudowa dotnie też punkt widokowy.

## Prywatna wyspa na Karaibach na sprzedaż. Kosztuje mniej niż przeciętny dom w USA
 - [https://businessinsider.com.pl/lifestyle/podroze/prywatna-wyspa-na-morzu-karaibskim-kosztuje-mniej-niz-przecietny-dom-w-usa/dsslk67](https://businessinsider.com.pl/lifestyle/podroze/prywatna-wyspa-na-morzu-karaibskim-kosztuje-mniej-niz-przecietny-dom-w-usa/dsslk67)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-18 06:30:00+00:00

Po co kupować dom, skoro możesz mieć całą wyspę dla siebie? Iguana Island to niewielka wyspa na morzu Karaibskim, na której stoi dom, jest pomost, kilkaset palm i... to wszystko. Właśnie trafiła na rynek.

## Na żywności oszczędza już... niemal każdy Polak
 - [https://businessinsider.com.pl/gospodarka/na-zywnosci-oszczedza-juz-niemal-kazdy-polak/28p42jf](https://businessinsider.com.pl/gospodarka/na-zywnosci-oszczedza-juz-niemal-kazdy-polak/28p42jf)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-18 06:28:54+00:00

Aż 91 proc. Polaków oszczędza na zakupach żywności – wynika z badania BIG InfoMonitor. Okazuje się jednak, że takie zaciskanie pasa ma swoje dobre strony.

## Koniec tajemnic. Są już pierwsze "paczkomaty pro"
 - [https://businessinsider.com.pl/gospodarka/koniec-tajemnic-sa-juz-pierwsze-paczkomaty-pro/zs8d1dn](https://businessinsider.com.pl/gospodarka/koniec-tajemnic-sa-juz-pierwsze-paczkomaty-pro/zs8d1dn)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-18 06:18:00+00:00

Rynek długo zastanawiał się, czym będą "paczkomaty pro". InPost tego nie ujawniał, wyraźnie podgrzewając atmosferę. Teraz, jak podaje branżowy serwis, pierwsze maszyny już stoją w Warszawie. Trzeba przyznać, sporo się różnią od "typowych" paczkomatów.

## Państwo zarobi miliardy na podwyżce płacy minimalnej. Tak się łata budżet
 - [https://businessinsider.com.pl/gospodarka/oto-ile-panstwo-zarobi-na-podwyzce-placy-minimalnej-tak-sie-lata-budzet/h1b837x](https://businessinsider.com.pl/gospodarka/oto-ile-panstwo-zarobi-na-podwyzce-placy-minimalnej-tak-sie-lata-budzet/h1b837x)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-18 06:00:00+00:00

Płaca minimalna to wspaniały mechanizm dla rządu, żeby podnieść sobie słupki wyborcze, a nie kosztuje ani złotówki. Nawet odwrotnie, to przysporzy budżetowi grubych miliardów złotych. Policzyliśmy, jak dużo więcej pieniędzy wpłynie z PIT i ZUS po podwyżce minimum do 4 tys. 300 zł, a ile będzie musiał wydać budżet państwa.

## Groźna dla Polski partia staje się potęgą. To wybór "Niemiec B"
 - [https://businessinsider.com.pl/wiadomosci/grozna-dla-polski-partia-staje-sie-potega-to-wybor-niemiec-b/3x0exlk](https://businessinsider.com.pl/wiadomosci/grozna-dla-polski-partia-staje-sie-potega-to-wybor-niemiec-b/3x0exlk)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-18 05:30:00+00:00

Niemcy w obecnym kształcie wchodzą w "wiek chrystusowy". Poprzednie podziały jednak widać doskonale – dawna NRD to ciągle biedna kuzynka dawnego RFN. Niemiecki wschód ciągle nie ma wielkiego biznesu, a jego mieszkańcy czują się wręcz w swoim kraju dyskryminowani. Efekt? W Niemczech rośnie skrajnie prawicowa partia, która wyraźnie flirtuje z antypolską retoryką.

## PiS straszy uchodźcami. Również PiS: tworzy z Polski kraj imigrantów
 - [https://businessinsider.com.pl/gospodarka/pis-straszy-uchodzcami-rowniez-pis-tworzy-z-polski-kraj-imigrantow/5kfrk1j](https://businessinsider.com.pl/gospodarka/pis-straszy-uchodzcami-rowniez-pis-tworzy-z-polski-kraj-imigrantow/5kfrk1j)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-06-18 05:20:00+00:00

Mało kogo, kto śledzi polską politykę, zaskakuje powrót PiS do narracji o zagrożeniu ze strony uchodźców. Jednak biorąc pod uwagę, jak bardzo za rządów Zjednoczonej Prawicy zmieniła się Polska, może to wręcz szokować. Stajemy się państwem imigrantów, a przełom nastąpił właśnie... na początku rządów partii Jarosława Kaczyńskiego.

