# Source:Wiadomosci - Gazeta.pl, URL:https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml, language:pl-PL

## Ukraina naciera i odzyskuje część Zaporoża. Pośpiech Rosjan na okupowanych terenach. Szczepią mieszkańców
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29882588,ukraina-w-natarciu-odzyskuje-czesc-zaporoza-pospiech-rosjan.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29882588,ukraina-w-natarciu-odzyskuje-czesc-zaporoza-pospiech-rosjan.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-18 18:44:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/0a/7f/1c/z29882634M,Ukraina-w-natarciu-odzyskuje-czesc-Zaporoza--Pospi.jpg" vspace="2" />Ukraińska armia wyzwoliła miejscowość Piatichatki w obwodzie zaporoskim. Doniesienia te potwierdzają ukraińskie źródła niezależne, wojskowi blogerzy i szef rosyjskiej administracji okupacyjnej w tamtym regionie. Kijów na razie nie potwierdził tych doniesień.

## Zaginięcie 27-letniej Polki na wsypie Kos. Greckie media: znaleziono ciało kobiety
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29882337,zaginiecie-27-letniej-polki-na-wsypie-kos-greckie-media-znaleziono.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29882337,zaginiecie-27-letniej-polki-na-wsypie-kos-greckie-media-znaleziono.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-18 17:26:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/58/82/1b/z28845912M,Pilne.jpg" vspace="2" />Wiele wskazuje na to, że sprawa zaginięcia 27-letniej Polki na wyspie Kos ma tragiczny finał. Greckie media poinformowały w niedzielę po południu, że w pobliżu miejsca, gdzie zaginęła Anastazja Rubińska, odnaleziono ciało młodej kobiety. Służby badają, czy może należeć do zaginionej Polki.

## Ozdoba brnie w twitterowe kłótnie po swoim absurdalnym wpisie. Teraz zaatakował Cymańskiego
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29882209,ozdoba-brnie-w-twitterowe-klotnie-po-swoim-slynnym-wpisie-zaatakowal.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29882209,ozdoba-brnie-w-twitterowe-klotnie-po-swoim-slynnym-wpisie-zaatakowal.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-18 17:09:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a3/7f/1c/z29882275M,Ozdoba-brnie-w-twitterowe-klotnie-po-swoim-slynnym.jpg" vspace="2" />Jacek Ozdoba, wiceminister w rządzie Prawa i Sprawiedliwości, podając wynik piątkowego meczu na Stadionie Narodowym, w miejsce Niemiec podstawił nazwisko byłego premiera Donalda Tuska. Za ten niewybredny popis na Twitterze przeprosił Tadeusz Cymański. Ozdoba postanowił iść w zaparte i odpowiedział byłemu koledze z partii, że w takim razie on "przeprosi za Tadka".

## Pierwszy efekt wizyty Blinkena w Pekinie. Szef chińskiego MSZ odwiedzi Waszyngton
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29882190,pierwszy-efekt-wizyty-blinkena-w-pekinie-szef-chinskiego-msz.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29882190,pierwszy-efekt-wizyty-blinkena-w-pekinie-szef-chinskiego-msz.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-18 15:55:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/9f/7f/1c/z29880991M,Sekretarz-stanu-USA-Antony-Blinken-podaje-reke-chi.jpg" vspace="2" />Chiński minister spraw zagranicznych Qin Gang zgodził się złożyć wizytę w Waszyngtonie po rozmowach z sekretarzem stanu USA Antonym Blinkenem w Pekinie - poinformował Departament Stanu Stanów Zjednoczonych.

## Tusk złożył Kaczyńskiemu życzenia z okazji urodzin. Z podtekstem i "z całego serca"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29882095,tusk-przeslal-kaczynskiemu-zyczenia-urodzinowe-z-podtekstem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29882095,tusk-przeslal-kaczynskiemu-zyczenia-urodzinowe-z-podtekstem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-18 15:40:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/2b/7f/1c/z29882155M,Tusk-przeslal-Kaczynskiemu-zyczenia-urodzinowe--Z-.jpg" vspace="2" />Niedziela 18 czerwca to dzień urodzin Jarosława Kaczyńskiego W mediach społecznościowych politycy różnych opcji składają prezesowi Prawa i Sprawiedliwości życzenia. Te płynące ze strony opozycji mają wyraźny wyborczy podtekst. Donald Tusk pożyczył Kaczyńskiemu następnych urodzin "w wolnej Polsce". A to nie jedyne złośliwości.

## Gdynia. Napad z bronią na salon gier. Policja poszukuje napastników [ZDJĘCIA]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29881855,gdynia-napad-z-bronia-na-salon-gier-policja-poszukuje-napastnikow.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29881855,gdynia-napad-z-bronia-na-salon-gier-policja-poszukuje-napastnikow.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-18 14:40:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/b0/7f/1c/z29882032M,Gdynia--Napad-z-bronia-na-salon-gier--Policja-posz.jpg" vspace="2" />Policja opublikowała zdjęcia napastników, którzy napadli na salon gier przy ulicy Wielkopolskiej w Gdyni. Wszystkie osoby, które rozpoznają mężczyzn, mogą zgłaszać się do policji w Trójmieście lub skontaktować się ze służbami pod numerem alarmowym 112.

## USA. Strzelanina na festiwalu Beyond Wonderland niedaleko Waszyngtonu. Są ofiary
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29881861,usa-strzelanina-na-festiwalu-beyond-wonderland-niedaleko-waszyngtonu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29881861,usa-strzelanina-na-festiwalu-beyond-wonderland-niedaleko-waszyngtonu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-18 14:01:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/67/7f/1c/z29881959M,USA--Strzelanina-na-festiwalu-Beyond-Wonderland-ni.jpg" vspace="2" />Dwie osoby zginęły w wyniku ataku uzbrojonego napastnika, który strzelał na oślep do tłumu w pobliżu festiwalu muzyki elektronicznej Beyond Wonderland w stanie Waszyngton. Organizatorzy odwołali koncerty zaplanowane na drugi dzień imprezy.

## "Polska 1 - Tusk 0". Boniek ostro o wpisie Ozdoby: Przepraszam, co to za debil?
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29881292,polska-1-tusk-0-boniek-ostro-o-wpisie-ozdoby-przepraszam.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29881292,polska-1-tusk-0-boniek-ostro-o-wpisie-ozdoby-przepraszam.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-18 13:50:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/59/7f/1c/z29881945M,-Polska-1---Tusk-0---Boniek-ostro-o-wpisie-Ozdoby-.jpg" vspace="2" />"Polska 1 - Tusk 0" - tak wiceminister Jacek Ozdoba ogłosił wygraną Polski w towarzyskim meczu z Niemcami. Na jego tweet ostro zareagował Zbigniew Boniek. "Przepraszam, co to za debil?" - zapytał. Do dyskusji włączyli się Tomasz Lis i Roman Giertych. "Boniek kontra debil 1:0" - skwitował ten drugi. "Przyrównywanie Tuska do Niemca to stała, chamska i wykluczająca propaganda PiS" - stwierdził w kolejnym wpisie.

## Urodziny Jarosława Kaczyńskiego. Prezes PiS skończył 74 lata. "Skończę rząd, mając 91 lat"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29881437,urodziny-jaroslawa-kaczynskiego-prezes-pis-skonczyl-74-lata.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,29881437,urodziny-jaroslawa-kaczynskiego-prezes-pis-skonczyl-74-lata.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-18 13:19:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f8/7f/1c/z29881848M,Urodziny-Jaroslawa-Kaczynskiego--Prezes-PiS-skoncz.jpg" vspace="2" />Jarosław Kaczyński skończył 74 lata. Z tej okazji przypominamy życiorys prezesa Prawa i Sprawiedliwości.

## Horoskop na tydzień 19-25 czerwca [Baran, Byk, Bliźnięta, Rak, Lew, Panna, Waga, Skorpion, Strzelec, Koziorożec, Wodnik, Ryby]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,168571,29881641,horoskop-na-tydzien-19-25-czerwca-baran-byk-bliznieta-rak.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,168571,29881641,horoskop-na-tydzien-19-25-czerwca-baran-byk-bliznieta-rak.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-18 13:07:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f2/4f/1c/z29684210M,horoskop---zdjecie-ilustracyjne.jpg" vspace="2" />Horoskop tygodniowy: 19-25 czerwca. Czy czekają cię zmiany w życiu osobistym? A może poszczęści ci się w życiu zawodowym? Znajdź swój znak i sprawdź, co zaplanował dla ciebie los.

## Czy te osoby mogły wziąć udział w tych wydarzeniach? Łatwo się tu pomylić!
 - [https://wiadomosci.gazeta.pl/wiadomosci/13,129662,11328,czy-te-osoby-mogly-wziac-udzial-w-tych-wydarzeniach.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/13,129662,11328,czy-te-osoby-mogly-wziac-udzial-w-tych-wydarzeniach.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-18 13:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/eb/f2/15/z23013867M,walesa-quiz.jpg" vspace="2" />Udowodnij, że dobrze znasz historię!

## Wielkopolskie. Zagryziono sześć reniferów. "Winnych będziemy szukać aż do skutku"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29881561,wielkopolskie-szesc.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29881561,wielkopolskie-szesc.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-18 12:59:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e9/7f/1c/z29881577M,Renifer.jpg" vspace="2" />- Kiedy zaalarmowali nas teściowie, którzy spędzali majówkę w jednym z domków, nie spodziewaliśmy się, że to, co zobaczymy za chwilę będzie wyglądało jak sceny z horroru - powiedział w rozmowie z serwisem slupca.pl Aleksander Dyczek, właściciel agroturystyki Arendel.

## Samolot z delegacją RPA odleciał z Warszawy. Stał na Okęciu od czwartku. Wszystko przez broń na pokładzie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29881454,samolot-z-delegacja-rpa-odlecial-z-warszawy-udalo-sie-to-po.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29881454,samolot-z-delegacja-rpa-odlecial-z-warszawy-udalo-sie-to-po.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-18 11:57:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/9b/7f/1c/z29881499M,Lotnisko-im--Fryderyka-Chopina-w-Warszawie.jpg" vspace="2" />Samolot wraz z członkami delegacji prezydenta RPA Cyrila Ramaphosy odleciał z warszawskiego lotniska im. Fryderyka Chopina w niedzielę - przekazała w rozmowie z PAP rzeczniczka lotniska Anna Dermont.

## Austriacka ministerka tańczyła z Putinem na weselu. Teraz pokieruje rosyjskim think tankiem
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29880887,austriacka-ministerka-tanczyla-z-putinem-na-weselu-teraz-pokieruje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29880887,austriacka-ministerka-tanczyla-z-putinem-na-weselu-teraz-pokieruje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-18 10:19:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c2/7f/1c/z29881282M,Austriacka-ministerka-tanczyla-z-Putinem-na-weselu.jpg" vspace="2" />Karin Kneissl, była ministerka spraw zagranicznych Austrii, pokieruje nowym rosyjskim think tankiem, który ma "określić politykę Kremla na Bliskim Wschodzie". Polityczka już dawno dała znać o swoich prokremlowskich sympatiach - na jej ślubie w 2018 roku jednym z gości był Władimir Putin.

## Sąsiedzi rodziny znalezionej w Londynie: "Byli wspaniali". Wszczęto dochodzenie w kierunku zabójstwa
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29881204,sasiedzi-czteroosobowej-rodziny-znalezionej-w-londynie-to-druzgocace.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29881204,sasiedzi-czteroosobowej-rodziny-znalezionej-w-londynie-to-druzgocace.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-18 10:15:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/77/7f/1c/z29880439M,Wielka-Brytania--Odnalezione-w-Londynie-ciala-nale.jpg" vspace="2" />- Kiedy zobaczyłam wiadomość o znalezieniu ciał, zaczęłam płakać. Pomyślałam, że to nie mogą być oni - przyznała jedna z sąsiadek czteroosobowej rodziny z Polski, która mieszkała w dzielnicy Hounslow w zachodnim Londynie. W piątek policja znalazła ciała małżeństwa i ich dzieci.

## Zaskakujące słowa nowego metropolity katowickiego. Mówił o "dwóch Polskach w Polsce"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29881080,kazanie-nowego-metropolity-katowickiego-zaskoczylo-wiernych.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29881080,kazanie-nowego-metropolity-katowickiego-zaskoczylo-wiernych.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-18 10:02:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/06/7f/1c/z29881094M,Abp-Adrian-Galbas.jpg" vspace="2" />Abp Adrian Galbas wygłosił w sobotę swoje pierwsze kazanie, w którym mówił o podzielonym społeczeństwie w Polsce. - Wszyscy pewnie bolejemy z powodu dwóch Polsk w Polsce. Coraz bardziej oddalonych od siebie, coraz bardziej napiętych - mówił nowy metropolita.

## W quizie kalendarzowym pytamy o urodziny znanych osób. Zdobędziesz 7/7?
 - [https://wiadomosci.gazeta.pl/wiadomosci/13,129662,17423,w-quizie-kalendarzowym-pytamy-o-urodziny-znanych-osob.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/13,129662,17423,w-quizie-kalendarzowym-pytamy-o-urodziny-znanych-osob.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-18 10:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d8/ae/1b/z29024472M,Grafika-do-quizu-kalendarzowego.jpg" vspace="2" />W tym tygodniu pytamy o znane osoby. Jak sobie poradzisz?

## Zaginięcie Polki w Grecji. Opublikowano nagranie, na którym po raz ostatni widać Anastazję
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29880958,sprawa-27-letniej-anastazji-z-kos-opublikowano-nagrania-z-ostatnich.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29880958,sprawa-27-letniej-anastazji-z-kos-opublikowano-nagrania-z-ostatnich.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-18 09:04:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e0/7f/1c/z29881056M.jpg" vspace="2" />27-letnia Anastazja Rubińska zaginęła w poniedziałek 12 czerwca i do tej pory nie została odnaleziona. W sieci pojawiły się nagrania z dnia, w którym ostatnio widziano Polkę.

## Amerykański sekretarz stanu Antony Blinken z wizytą w Pekinie. To pierwsza taka wizyta od lat. "Krytyczny moment"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29880912,amerykanski-sekretarz-stanu-z-wizyta-w-pekinie-to-pierwsza.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29880912,amerykanski-sekretarz-stanu-z-wizyta-w-pekinie-to-pierwsza.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-18 08:45:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/9d/7f/1c/z29880989M,Sekretarz-stanu-USA-Antony-Blinken-podczas-wizyty-.jpg" vspace="2" />Amerykański sekretarz stanu Antony Blinken przybył do Pekinu. To najwyższy rangą przedstawiciel USA, który przyleciał do Chin z oficjalną wizytą, odkąd stery w Białym Domu przejął prezydent Joe Biden. Ostatni raz sekretarz stanu USA w Chinach był pięć lat temu.

## Zaskakujące słowa Pieskowa nt. sytuacji w Ukrainie: Cel "demilitaryzacji" w dużej mierze wykonany
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29880959,zaskakujace-slowa-pieskowa-nt-sytuacji-w-ukrainie-cel-demilitaryzacji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29880959,zaskakujace-slowa-pieskowa-nt-sytuacji-w-ukrainie-cel-demilitaryzacji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-18 08:45:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ed/6a/1c/z29797101M,Dmitrij-Pieskow.jpg" vspace="2" />Rzecznik Władimira Putina Dmitrij Pieskow udzielił zaskakującego wywiadu, w którym stwierdził, że "demilitaryzacja" Ukrainy "w dużej mierze została wykonana". - Ukraina używa coraz mniej swojej broni. I coraz częściej korzysta z systemów uzbrojenia dostarczanych mu przez kraje zachodnie - stwierdził.

## Ukraińskie wojsko wysadziło duży rosyjski skład broni. "Dobra robota, chłopaki! Więcej ognia!"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29880900,ukrainskie-wojsko-wysadzilo-duzy-rosyjski-sklad-broni-dobra.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29880900,ukrainskie-wojsko-wysadzilo-duzy-rosyjski-sklad-broni-dobra.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-18 08:43:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c7/7f/1c/z29881031M,Ukrainskie-wojsko-wysadzilo-duzy-rosyjski-sklad-br.jpg" vspace="2" />Siły ukraińskie zdetonowały duży rosyjski skład broni we wsi Rykowe w obwodzie chersońskim. Od wczesnego rana słychać było wybuchy. Atak został potwierdzony przez Mykołę Ołeszczuka, dowódcę Sił Powietrznych Ukrainy. "Dobra robota, chłopaki!" - napisał w mediach społecznościowych.

## Kontrowersyjny wywiad szefa ukraińskiego IPN. Stawia warunek ws. ekshumacji ofiar rzezi wołyńskiej
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29880852,kontrowersyjny-wywiad-szefa-ukrainskiego-ipn-stawia-warunek.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29880852,kontrowersyjny-wywiad-szefa-ukrainskiego-ipn-stawia-warunek.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-18 08:12:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/29/7f/1c/z29880873M,Anton-Drobowycz.jpg" vspace="2" />- Strona ukraińska uważa, że dopóki ten pomnik [w Monasterzu - red.] nie zostanie odrestaurowany w Polsce, nie możemy wydać zgody na nowe wykopaliska i ekshumacje Polaków pochowanych w Ukrainie, ponieważ ukraińskie groby w Polsce są nadal zagrożone - powiedział Anton Drobowycz, szef ukraińskiego IPN.

## Ojciec Polki zaginionej w Grecji: Bardzo podejrzane, jakby zrozumiała, że coś jej zagraża
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29880849,ojciec-polki-zaginionej-w-grecji-bardzo-podejrzane-jakby-zrozumiala.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29880849,ojciec-polki-zaginionej-w-grecji-bardzo-podejrzane-jakby-zrozumiala.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-18 07:22:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/48/7f/1c/z29880904M,Na-Kos-zaginela-27-letnia-Anastazja.jpg" vspace="2" />Anastazja Rubińska zaginęła w poniedziałek. Poszukiwania kobiety trwają, tymczasem ojciec 27-latki przyznał w rozmowie z "Super Expressem", że cała rodzina bardzo martwi się jej zaginięciem. - Bardzo podejrzane jest, że podczas jazdy dwa razy wysyłała swoją lokalizację do narzeczonego - zwrócił uwagę mężczyzna.

## Pakt migracyjny. W Niemczech podzieleni ws. migrantów. Chcą kontroli na granicy z Polską
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,127561,29880811,pakt-migracyjny-w-niemczech-podzieleni-ws-migrantow-chca.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,127561,29880811,pakt-migracyjny-w-niemczech-podzieleni-ws-migrantow-chca.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-18 06:28:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f6/7f/1c/z29880822M,Migranci-na-granicy--zdjecie-ilustracyjne-.jpg" vspace="2" />Po marszu opozycji w Warszawie rządząca w Polsce partia Prawo i Sprawiedliwość PiS przeszła do kontrataku. Na pole konfliktu wybrano politykę migracyjną. Dyskusja o kompromisie azylowym toczy się także w Niemczech.

## Putin wrobił Łukaszenkę? Nieoficjalnie: Do Białorusi trafiła o wiele potężniejsza broń jądrowa
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29880772,putin-wrobil-lukaszenke-nieoficjalnie-do-bialorusi-trafila.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,29880772,putin-wrobil-lukaszenke-nieoficjalnie-do-bialorusi-trafila.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-18 06:06:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/cd/7f/1c/z29880781M,Wladimir-Putin.jpg" vspace="2" />- Pojawiają się informacje, że do Białorusi trafia nie tylko taktyczna broń jądrowa. Istnieją podejrzenia, że pocisk balistyczny Topol-M o zasięgu 12 tysięcy kilometrów został przywieziony do Białorusi - powiedział Siergiej Bulba, założyciel opozycyjno-militarnej białoruskiej organizacji "Biały Legion" na antenie Espreso TV.

## IMGW ostrzega przed burzami z gradem. Wydano żółte alerty dla ośmiu województw
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29880771,imgw-ostrzega-przed-burzami-z-gradem-wydano-zolte-alerty-dla.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29880771,imgw-ostrzega-przed-burzami-z-gradem-wydano-zolte-alerty-dla.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-18 05:42:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e1/7f/1c/z29880801M,Gdzie-jest-burza--Pogoda-na-18-czerwca.jpg" vspace="2" />Instytut Meteorologii i Gospodarki Wodnej ostrzega przed burzami z gradem. Ostrzeżenia pierwszego, najniższego stopnia wydano dla ośmiu województw. Miejscami wystąpią silne opady deszczu, a nawet grad oraz silny wiatr. Sprawdź, gdzie jest burza.

## Horoskop dzienny - niedziela 18 czerwca [Baran, Byk, Bliźnięta, Rak, Lew, Panna, Waga, Skorpion, Strzelec, Koziorożec, Wodnik, Ryby]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,168571,29879672,horoskop-dzienny-niedziela-18-czerwca-baran-byk-bliznieta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,168571,29879672,horoskop-dzienny-niedziela-18-czerwca-baran-byk-bliznieta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-06-18 03:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/88/2e/1c/z29550216M,Horoskop-dzienny-na-niedziele.jpg" vspace="2" />Horoskop na niedzielę 18 czerwca. Czego spodziewać się po tym dniu? Którym znakom zodiaku dopisze szczęście, a którym passa nie będzie dziś sprzyjać? Przedstawiamy przepowiednie dla wszystkich znaków zodiaku.

