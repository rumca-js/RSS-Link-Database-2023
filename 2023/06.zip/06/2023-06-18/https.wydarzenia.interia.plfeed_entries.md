# Source:Wydarzenia Interia, URL:https://wydarzenia.interia.pl/feed, language:pl-PL

## Efekty wizyty Blinkena w Pekinie. Chiński minister uda się do Waszyngtonu
 - [https://wydarzenia.interia.pl/zagranica/news-efekty-wizyty-blinkena-w-pekinie-chinski-minister-uda-sie-do,nId,6849024](https://wydarzenia.interia.pl/zagranica/news-efekty-wizyty-blinkena-w-pekinie-chinski-minister-uda-sie-do,nId,6849024)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-18 20:56:39+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-efekty-wizyty-blinkena-w-pekinie-chinski-minister-uda-sie-do,nId,6849024"><img align="left" alt="Efekty wizyty Blinkena w Pekinie. Chiński minister uda się do Waszyngtonu" src="https://i.iplsc.com/efekty-wizyty-blinkena-w-pekinie-chinski-minister-uda-sie-do/000HANR0C3H7GRJD-C321.jpg" /></a>Amerykański sekretarz stanu Antony Blinken odbył w niedzielę ponad sześciogodzinną rozmowę i uzgodnił, że chiński minister spraw zagranicznych Qin Gang złoży wizytę w Waszyngtonie - poinformował Departament USA. Brytyjski dziennik &quot;The Independent&quot; ocenia jednak, że przedstawiciele obu państw &quot;nie zdołali przezwyciężyć najpoważniejszych nieporozumień&quot;.</p><br clear="all" />

## Zełenski dementuje doniesienia Rosjan ws. systemów Patriot
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-dementuje-doniesienia-rosjan-ws-systemow-patriot,nId,6849021](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-dementuje-doniesienia-rosjan-ws-systemow-patriot,nId,6849021)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-18 20:49:22+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-dementuje-doniesienia-rosjan-ws-systemow-patriot,nId,6849021"><img align="left" alt="Zełenski dementuje doniesienia Rosjan ws. systemów Patriot" src="https://i.iplsc.com/zelenski-dementuje-doniesienia-rosjan-ws-systemow-patriot/000H4HLCR8TGUUTJ-C321.jpg" /></a>- Ktoś tam w Rosji mówił, że rzekomo nasze systemy Patriot zostały zniszczone. Wszystkie działają, wszystkie pracują, wszystkie zestrzeliwują rosyjskie rakiety - mówił w niedzielę wieczorem Wołodymyr Zełenski. - Żaden Patriot nie został zniszczony - podkreślił. Prezydent Ukrainy na nagraniu mówił także o kontrofensywie i wskazał kierunek, na którym obecnie toczą się najcięższe walki. </p><br clear="all" />

## Kilkanaście ofiar podrobionego alkoholu w Iranie. Zmarłych może być więcej
 - [https://wydarzenia.interia.pl/zagranica/news-kilkanascie-ofiar-podrobionego-alkoholu-w-iranie-zmarlych-mo,nId,6849018](https://wydarzenia.interia.pl/zagranica/news-kilkanascie-ofiar-podrobionego-alkoholu-w-iranie-zmarlych-mo,nId,6849018)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-18 20:12:27+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-kilkanascie-ofiar-podrobionego-alkoholu-w-iranie-zmarlych-mo,nId,6849018"><img align="left" alt="Kilkanaście ofiar podrobionego alkoholu w Iranie. Zmarłych może być więcej" src="https://i.iplsc.com/kilkanascie-ofiar-podrobionego-alkoholu-w-iranie-zmarlych-mo/000HANMJ06URCG6L-C321.jpg" /></a>Co najmniej 14 osób straciło życie po spożyciu przemysłowego alkoholu w Iranie w północnej prowincji Alborz. Ponad sto kolejnych osób trafiło do szpitali. Władze podkreślają, że ofiar śmiertelnych może być zdecydowanie więcej. Warto podkreślić, że alkohol w kraju Persów jest zakazany od ponad 40 lat.</p><br clear="all" />

## Kremlowscy politycy piją coraz więcej. "Butelka zamieniła się na dwie"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-kremlowscy-politycy-pija-coraz-wiecej-butelka-zamienila-sie-,nId,6849014](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-kremlowscy-politycy-pija-coraz-wiecej-butelka-zamienila-sie-,nId,6849014)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-18 20:06:41+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-kremlowscy-politycy-pija-coraz-wiecej-butelka-zamienila-sie-,nId,6849014"><img align="left" alt="Kremlowscy politycy piją coraz więcej. &quot;Butelka zamieniła się na dwie&quot;" src="https://i.iplsc.com/kremlowscy-politycy-pija-coraz-wiecej-butelka-zamienila-sie/000HANKINF7OVFG2-C321.jpg" /></a>Od początku wojny w Ukrainie rosyjscy politycy zaczęli pić coraz więcej alkoholu, na bankietach na jedną osobę zapewniana jest już nie jedna butelka, a dwie - podaje w niedzielę niezależny portal rosyjski Verstka Media. Z zamówień rządowych wynika, że kremlowscy politycy najczęściej sięgają po koniak, szampan, wino i wódkę.</p><br clear="all" />

## Zmarła Jolanta Wadowska-Król. Ceniona lekarka uratowała życie setek dzieci
 - [https://wydarzenia.interia.pl/slaskie/news-zmarla-jolanta-wadowska-krol-ceniona-lekarka-uratowala-zycie,nId,6848999](https://wydarzenia.interia.pl/slaskie/news-zmarla-jolanta-wadowska-krol-ceniona-lekarka-uratowala-zycie,nId,6848999)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-18 19:50:55+00:00

<p><a href="https://wydarzenia.interia.pl/slaskie/news-zmarla-jolanta-wadowska-krol-ceniona-lekarka-uratowala-zycie,nId,6848999"><img align="left" alt="Zmarła Jolanta Wadowska-Król. Ceniona lekarka uratowała życie setek dzieci" src="https://i.iplsc.com/zmarla-jolanta-wadowska-krol-ceniona-lekarka-uratowala-zycie/000HANGHL7AUDBHG-C321.jpg" /></a>Zmarła ceniona lekarka Jolanta Wadowska-Król, która w latach 70. XX wieku uratowała setki dzieci, wykrywając ołowicę i angażując się w realizację szeroko zakrojonych badań. &quot;Żegnamy wspaniałego lekarza i człowieka&quot; - napisano na profilu Śląskiej Izby Lekarskiej w Katowicach. Honorowa obywatelka Katowic 27 czerwca świętowałaby 84. urodziny.</p><br clear="all" />

## Zderzenie samolotów w Bostonie. "Jak trzęsienie ziemi"
 - [https://wydarzenia.interia.pl/zagranica/news-zderzenie-samolotow-w-bostonie-jak-trzesienie-ziemi,nId,6849002](https://wydarzenia.interia.pl/zagranica/news-zderzenie-samolotow-w-bostonie-jak-trzesienie-ziemi,nId,6849002)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-18 19:05:38+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zderzenie-samolotow-w-bostonie-jak-trzesienie-ziemi,nId,6849002"><img align="left" alt="Zderzenie samolotów w Bostonie. &quot;Jak trzęsienie ziemi&quot;" src="https://i.iplsc.com/zderzenie-samolotow-w-bostonie-jak-trzesienie-ziemi/000HAN9S0JQ5H1QL-C321.jpg" /></a>Zdarzenie na lotnisku w Bostonie poważnie zaniepokoiło pasażerów samolotu linii Delta. - Nie było jasne, co się dzieje, ale wydawało się, jakby to było krótkie trzęsienie ziemi - relacjonował CNN jeden z podróżnych. Chodzi o &quot;stłuczkę&quot; wielkich maszyn jeszcze zanim te wzbiły się w powietrze. </p><br clear="all" />

## Macron świętował po finale rugby. W sieci krąży nagranie
 - [https://wydarzenia.interia.pl/zagranica/news-macron-swietowal-po-finale-rugby-w-sieci-krazy-nagranie,nId,6848994](https://wydarzenia.interia.pl/zagranica/news-macron-swietowal-po-finale-rugby-w-sieci-krazy-nagranie,nId,6848994)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-18 18:45:01+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-macron-swietowal-po-finale-rugby-w-sieci-krazy-nagranie,nId,6848994"><img align="left" alt="Macron świętował po finale rugby. W sieci krąży nagranie" src="https://i.iplsc.com/macron-swietowal-po-finale-rugby-w-sieci-krazy-nagranie/000HAN6VQERN02BE-C321.jpg" /></a>Prezydent Francji Emmanuel Macron w sobotę świętował razem z zawodnikami rugby po finale w Paryżu. Jak można zobaczyć na nagraniu krążącym w mediach społecznościowych Macron, dopingowany przez sportowców, duszkiem wypija butelkę piwa. Według francuskich mediów to członkowie drużyny rzucili wyzwanie prezydentowi. </p><br clear="all" />

## Planowali atak na "Tęczową Paradę" w Wiedniu. Aresztowany m.in. 14-latek
 - [https://wydarzenia.interia.pl/zagranica/news-planowali-atak-na-teczowa-parade-w-wiedniu-aresztowany-m-in-,nId,6848972](https://wydarzenia.interia.pl/zagranica/news-planowali-atak-na-teczowa-parade-w-wiedniu-aresztowany-m-in-,nId,6848972)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-18 17:36:31+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-planowali-atak-na-teczowa-parade-w-wiedniu-aresztowany-m-in-,nId,6848972"><img align="left" alt="Planowali atak na &quot;Tęczową Paradę&quot; w Wiedniu. Aresztowany m.in. 14-latek" src="https://i.iplsc.com/planowali-atak-na-teczowa-parade-w-wiedniu-aresztowany-m-in/000HAMT5TTOXPPF3-C321.jpg" /></a>Dwóch nastolatków i dwudziestolatek zostali zatrzymani przez austriackie władze tu przed &quot;Tęczową Paradą&quot;, w której brało udział 300 tys. osób. Śledczy podczas przesłuchania skonfiskowali między innymi szable, siekiery i noże.</p><br clear="all" />

## Ukraina w NATO? Stoltenberg: Broń jądrowa na Białorusi wzmacnia apel Kijowa
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-w-nato-stoltenberg-bron-jadrowa-na-bialorusi-wzmacni,nId,6848980](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-w-nato-stoltenberg-bron-jadrowa-na-bialorusi-wzmacni,nId,6848980)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-18 17:27:43+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-w-nato-stoltenberg-bron-jadrowa-na-bialorusi-wzmacni,nId,6848980"><img align="left" alt="Ukraina w NATO? Stoltenberg: Broń jądrowa na Białorusi wzmacnia apel Kijowa" src="https://i.iplsc.com/ukraina-w-nato-stoltenberg-bron-jadrowa-na-bialorusi-wzmacni/000HAMUP89J0DU9M-C321.jpg" /></a>Rozmieszczenie rosyjskiej broni jądrowej na Białorusi wzmacnia apel Ukrainy w sprawie szybkiego przyjęcia do NATO - ocenił sekretarz Generalny NATO Jens Stoltenberg, cytowany przez agencję Unian. - Przyszłość Ukrainy jest w NATO - dodał. Zgodnie z zapowiedziami Władimira Putina, rosyjska broń jądrowa trafi na Białoruś na początku lipca. </p><br clear="all" />

## Wtargnął do domu i kościoła. Przebrał się za księdza. Wcześniej ukradł auto
 - [https://wydarzenia.interia.pl/lubelskie/news-wtargnal-do-domu-i-kosciola-przebral-sie-za-ksiedza-wczesnie,nId,6848964](https://wydarzenia.interia.pl/lubelskie/news-wtargnal-do-domu-i-kosciola-przebral-sie-za-ksiedza-wczesnie,nId,6848964)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-18 17:13:31+00:00

<p><a href="https://wydarzenia.interia.pl/lubelskie/news-wtargnal-do-domu-i-kosciola-przebral-sie-za-ksiedza-wczesnie,nId,6848964"><img align="left" alt="Wtargnął do domu i kościoła. Przebrał się za księdza. Wcześniej ukradł auto" src="https://i.iplsc.com/wtargnal-do-domu-i-kosciola-przebral-sie-za-ksiedza-wczesnie/000HAMSSD3CGA1AF-C321.jpg" /></a>Zdumiewająca interwencja policji na Zamojszczyźnie. Do jednego z kościołów wszedł obywatel Mołdawii, po czym przebrał się za księdza. Następnie uciekł i wtargnął do jednego z domów. Tam znów się przebrał i ukradł smartwatcha. Aresztowano go w pobliżu świątyni. Później okazało się, że na miejsce przyjechał skradzionym wcześniej autem. 24-latkowi postawiono zarzuty i tymczasowo aresztowano. Grozi mu do pięciu lat więzienia.</p><br clear="all" />

## W Grecji znaleziono ciało kobiety. Wiele wskazuje, że to zaginiona Polka
 - [https://wydarzenia.interia.pl/zagranica/news-w-grecji-znaleziono-cialo-kobiety-wiele-wskazuje-ze-to-zagin,nId,6848979](https://wydarzenia.interia.pl/zagranica/news-w-grecji-znaleziono-cialo-kobiety-wiele-wskazuje-ze-to-zagin,nId,6848979)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-18 16:51:20+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-w-grecji-znaleziono-cialo-kobiety-wiele-wskazuje-ze-to-zagin,nId,6848979"><img align="left" alt="W Grecji znaleziono ciało kobiety. Wiele wskazuje, że to zaginiona Polka" src="https://i.iplsc.com/w-grecji-znaleziono-cialo-kobiety-wiele-wskazuje-ze-to-zagin/000HAMXPY4O3EPCO-C321.jpg" /></a>Greckie media informują, że na wyspie Kos, przy drodze między Tigaki a Marmari, odnaleziono ciało młodej kobiety i wiele wskazuje, że jest to zaginiona Polka. Z medialnych doniesień wynika, że ciało kobiety było nagie i zawinięte w czarną torbę, jednak są to informacje niepotwierdzone przez policję. CNN Greece pisze z kolei o zwłokach w ubraniu i w stanie zaawansowanego rozkładu. Do zaginięcia 27-letniej Anastazji Rubińskiej doszło 12 czerwca. W sprawie aresztowano 32-letniego obywatela Bangladeszu, który przyznał, że odbył z nią stosunek...</p><br clear="all" />

## W Grecji znaleziono ciało zaginionej Polki. Policja czeka na identyfikację
 - [https://wydarzenia.interia.pl/zagranica/news-w-grecji-znaleziono-cialo-zaginionej-polki-policja-czeka-na-,nId,6848979](https://wydarzenia.interia.pl/zagranica/news-w-grecji-znaleziono-cialo-zaginionej-polki-policja-czeka-na-,nId,6848979)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-18 16:51:20+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-w-grecji-znaleziono-cialo-zaginionej-polki-policja-czeka-na-,nId,6848979"><img align="left" alt="W Grecji znaleziono ciało zaginionej Polki. Policja czeka na identyfikację" src="https://i.iplsc.com/w-grecji-znaleziono-cialo-zaginionej-polki-policja-czeka-na/000HAN5TOILGGYJR-C321.jpg" /></a>Greckie media informują, że na wyspie Kos, przy drodze między Tigaki a Marmari, odnaleziono ciało młodej kobiety i wiele wskazuje, że jest to zaginiona Polka. Z medialnych doniesień wynika, że ciało kobiety było nagie i zawinięte w czarną torbę, jednak są to informacje niepotwierdzone przez policję. CNN Greece pisze z kolei o zwłokach w ubraniu i w stanie zaawansowanego rozkładu. Wiele greckich źródeł donosi, że władze zidentyfikowały już 27-latkę, a teraz oczekują, aż zrobi to rodzina. Do zaginięcia młodej kobiety doszło 12 czerwca. W...</p><br clear="all" />

## Obudziła się w trumnie. 76-latka zmarła w szpitalu
 - [https://wydarzenia.interia.pl/zagranica/news-obudzila-sie-w-trumnie-76-latka-zmarla-w-szpitalu,nId,6848966](https://wydarzenia.interia.pl/zagranica/news-obudzila-sie-w-trumnie-76-latka-zmarla-w-szpitalu,nId,6848966)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-18 16:18:23+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-obudzila-sie-w-trumnie-76-latka-zmarla-w-szpitalu,nId,6848966"><img align="left" alt="Obudziła się w trumnie. 76-latka zmarła w szpitalu" src="https://i.iplsc.com/obudzila-sie-w-trumnie-76-latka-zmarla-w-szpitalu/000HAMPJ5GTREPDR-C321.jpg" /></a>76-letnia Bella Montoya z Ekwadoru, która na początku czerwca obudziła się w trumnie na własnym pogrzebie, zmarła w piątek. Kobieta przez ponad tydzień przebywała w szpitalu w Babahoy. Resort zdrowia w sprawie Montoyi powołał specjalną komisję. </p><br clear="all" />

## Pożar hali magazynowej. Płoną garaże z samochodami
 - [https://wydarzenia.interia.pl/dolnoslaskie/news-pozar-hali-magazynowej-plona-garaze-z-samochodami,nId,6848962](https://wydarzenia.interia.pl/dolnoslaskie/news-pozar-hali-magazynowej-plona-garaze-z-samochodami,nId,6848962)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-18 15:40:45+00:00

<p><a href="https://wydarzenia.interia.pl/dolnoslaskie/news-pozar-hali-magazynowej-plona-garaze-z-samochodami,nId,6848962"><img align="left" alt="Pożar hali magazynowej. Płoną garaże z samochodami" src="https://i.iplsc.com/pozar-hali-magazynowej-plona-garaze-z-samochodami/000HAMNM71II2QMT-C321.jpg" /></a>Hala magazynowa i garaże samochodowe przy ulicy Legnickiej we Wrocławiu (woj. dolnośląskie) stanęły w płomieniach. Ogień trawi między innymi auta zaparkowane na zewnątrz budynku. </p><br clear="all" />

## Pożar hali magazynowej. Płonęły garaże z samochodami
 - [https://wydarzenia.interia.pl/dolnoslaskie/news-pozar-hali-magazynowej-plonely-garaze-z-samochodami,nId,6848962](https://wydarzenia.interia.pl/dolnoslaskie/news-pozar-hali-magazynowej-plonely-garaze-z-samochodami,nId,6848962)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-18 15:40:45+00:00

<p><a href="https://wydarzenia.interia.pl/dolnoslaskie/news-pozar-hali-magazynowej-plonely-garaze-z-samochodami,nId,6848962"><img align="left" alt="Pożar hali magazynowej. Płonęły garaże z samochodami" src="https://i.iplsc.com/pozar-hali-magazynowej-plonely-garaze-z-samochodami/000HAMNM71II2QMT-C321.jpg" /></a>Hala magazynowa i garaże samochodowe przy ulicy Legnickiej we Wrocławiu (woj. dolnośląskie) stanęły w płomieniach. Ogień miał objąć ogromną podwójną halę magazynową o rozmiarach 40 na 60 metrów. Na miejscu pracowała policja i dziewięć zastępów straży pożarnej.</p><br clear="all" />

## Spędził blisko 29 lat w celi śmierci. Został niesłusznie skazany
 - [https://wydarzenia.interia.pl/zagranica/news-spedzil-blisko-29-lat-w-celi-smierci-zostal-nieslusznie-skaz,nId,6848948](https://wydarzenia.interia.pl/zagranica/news-spedzil-blisko-29-lat-w-celi-smierci-zostal-nieslusznie-skaz,nId,6848948)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-18 15:40:20+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-spedzil-blisko-29-lat-w-celi-smierci-zostal-nieslusznie-skaz,nId,6848948"><img align="left" alt="Spędził blisko 29 lat w celi śmierci. Został niesłusznie skazany" src="https://i.iplsc.com/spedzil-blisko-29-lat-w-celi-smierci-zostal-nieslusznie-skaz/000HAMH24YINT46J-C321.jpg" /></a>Barry Lee Jones spędził w celi śmierci w Arizonie ponad 28 lat. Mężczyzna, który został niesłusznie skazany za zamordowanie 4-letniej dziewczynki, w czwartek wyszedł na wolność. - Mamy nadzieję, że Barry będzie mógł cieszyć się resztą życia w spokoju, w otoczeniu rodziny i przyjaciół - mówił obrońca 64-latka. </p><br clear="all" />

## Dmytro Kułeba o "dotkliwych sukcesach" Rosji. Kpi z kremlowskiej propagandy
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-dmytro-kuleba-o-dotkliwych-sukcesach-rosji-kpi-z-kremlowskie,nId,6848944](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-dmytro-kuleba-o-dotkliwych-sukcesach-rosji-kpi-z-kremlowskie,nId,6848944)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-18 15:29:56+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-dmytro-kuleba-o-dotkliwych-sukcesach-rosji-kpi-z-kremlowskie,nId,6848944"><img align="left" alt="Dmytro Kułeba o &quot;dotkliwych sukcesach&quot; Rosji. Kpi z kremlowskiej propagandy" src="https://i.iplsc.com/dmytro-kuleba-o-dotkliwych-sukcesach-rosji-kpi-z-kremlowskie/000HAMIXIAUHTOXO-C321.jpg" /></a>Minister Spraw Zagranicznych Ukrainy Dmytro Kułeba stwierdził, że Rosja, posługując się propagandą, jest w stanie wytłumaczyć swoim obywatelom praktycznie wszystko. Napisał prześmiewczo, że utratę Krymu Rosjanie przedstawią jako kolejny sukces, ogłaszając, że nie będzie już obciążeniem dla rosyjskiego budżetu. Prześmiewczy komentarz szefa ukraińskiego MSZ to reakcja na słowa rzecznika Kremla Dmitrija Pieskowa, który ogłosił, że Federacja Rosyjska zdemilitaryzowała Ukrainę, bo ta nie używa już swojej broni, ale przede wszystkim tej z Zachodu.</p><br clear="all" />

## Szedł z tatą za rękę. Wtedy uderzył w nich piorun
 - [https://wydarzenia.interia.pl/zagranica/news-szedl-z-tata-za-reke-wtedy-uderzyl-w-nich-piorun,nId,6848939](https://wydarzenia.interia.pl/zagranica/news-szedl-z-tata-za-reke-wtedy-uderzyl-w-nich-piorun,nId,6848939)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-18 14:48:14+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-szedl-z-tata-za-reke-wtedy-uderzyl-w-nich-piorun,nId,6848939"><img align="left" alt="Szedł z tatą za rękę. Wtedy uderzył w nich piorun " src="https://i.iplsc.com/szedl-z-tata-za-reke-wtedy-uderzyl-w-nich-piorun/000HAMGAQ4ELVK7B-C321.jpg" /></a>Sześcioletni chłopiec zmarł po tym, jak w niego i jego tatę uderzył piorun. 34-letni ojciec właśnie odebrał swojego syna z przedszkola. - Tuż po tym, jak wyznawał mu miłość, uderzył w nich piorun - powiedziała w rozmowie z mediami pogrążona w żałobie babcia dziecka.</p><br clear="all" />

## Lewica zaprezentowała specjalny raport. Treść "obnaża prawdę"
 - [https://wydarzenia.interia.pl/kraj/news-lewica-zaprezentowala-specjalny-raport-tresc-obnaza-prawde,nId,6848931](https://wydarzenia.interia.pl/kraj/news-lewica-zaprezentowala-specjalny-raport-tresc-obnaza-prawde,nId,6848931)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-18 14:23:02+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-lewica-zaprezentowala-specjalny-raport-tresc-obnaza-prawde,nId,6848931"><img align="left" alt="Lewica zaprezentowała specjalny raport. Treść &quot;obnaża prawdę&quot;" src="https://i.iplsc.com/lewica-zaprezentowala-specjalny-raport-tresc-obnaza-prawde/000HAMCVDHEIDCOB-C321.jpg" /></a>Lewica zaprezentowała w niedzielę &quot;Raport o Stanie Państwa&quot;. - Raport to prawda o tym, że PiS ukradło Polskę swoim obywatelom (...). Przygotowaliśmy go, by obnażyć prawdę. Dokument odkrywa to, co PiS chciało ukryć - mówił szef klubu Lewicy Krzysztof Gawkowski, zwracając uwagę m.in. na wysoką inflację, zły stan szkolnictwa, ochrony zdrowia czy finansów publicznych.</p><br clear="all" />

## Plaga fałszywych ogłoszeń w Niemczech. Oszuści zwietrzyli interes
 - [https://wydarzenia.interia.pl/zagranica/news-plaga-falszywych-ogloszen-w-niemczech-oszusci-zwietrzyli-int,nId,6848928](https://wydarzenia.interia.pl/zagranica/news-plaga-falszywych-ogloszen-w-niemczech-oszusci-zwietrzyli-int,nId,6848928)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-18 14:20:40+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-plaga-falszywych-ogloszen-w-niemczech-oszusci-zwietrzyli-int,nId,6848928"><img align="left" alt="Plaga fałszywych ogłoszeń w Niemczech. Oszuści zwietrzyli interes" src="https://i.iplsc.com/plaga-falszywych-ogloszen-w-niemczech-oszusci-zwietrzyli-int/000HAMDSMTB3H6HV-C321.jpg" /></a>W internecie roi się od fikcyjnych adresów. To przynęta dla osób szukających mieszkania na kilka tygodni lub miesięcy. W Berlinie w ciągu zaledwie roku liczba zgłoszonych policji oszustw dotyczących wynajmu kwater wzrosła prawie dwukrotnie. Oszuści zwietrzyli interes.</p><br clear="all" />

## Samochód elektryczny stanął w ogniu. Spłonęły trzy domy
 - [https://wydarzenia.interia.pl/zagranica/news-samochod-elektryczny-stanal-w-ogniu-splonely-trzy-domy,nId,6848918](https://wydarzenia.interia.pl/zagranica/news-samochod-elektryczny-stanal-w-ogniu-splonely-trzy-domy,nId,6848918)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-18 13:50:17+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-samochod-elektryczny-stanal-w-ogniu-splonely-trzy-domy,nId,6848918"><img align="left" alt="Samochód elektryczny stanął w ogniu. Spłonęły trzy domy" src="https://i.iplsc.com/samochod-elektryczny-stanal-w-ogniu-splonely-trzy-domy/000HALPUQSRG1QLU-C321.jpg" /></a>Trzy domy w zabudowie szeregowej doszczętnie spłonęły po tym, jak zapalił się samochód elektryczny. Auto stało przy jednym ze środkowych domów. Akcję gaśniczą utrudniał wiatr, przez pewien czas istniało też zagrożenie dla pobliskiej stacji benzynowej. W zdarzeniu nikt nie ucierpiał. Ogień pojawił się w sobotnie popołudnie w jednej z dzielnic Sztokholmu.</p><br clear="all" />

## Media ujawniły film z imprezy torysów podczas lockdownu. "Nie do obrony"
 - [https://wydarzenia.interia.pl/raport-koronawirus-chiny/news-media-ujawnily-film-z-imprezy-torysow-podczas-lockdownu-nie-,nId,6848904](https://wydarzenia.interia.pl/raport-koronawirus-chiny/news-media-ujawnily-film-z-imprezy-torysow-podczas-lockdownu-nie-,nId,6848904)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-18 13:20:40+00:00

<p><a href="https://wydarzenia.interia.pl/raport-koronawirus-chiny/news-media-ujawnily-film-z-imprezy-torysow-podczas-lockdownu-nie-,nId,6848904"><img align="left" alt="Media ujawniły film z imprezy torysów podczas lockdownu. &quot;Nie do obrony&quot;" src="https://i.iplsc.com/media-ujawnily-film-z-imprezy-torysow-podczas-lockdownu-nie/000HALNVEIFNYVK5-C321.jpg" /></a>Brytyjskie media opublikowały nagranie z jednej z imprez, jakie były organizowane przez członków Partii Konserwatywnej podczas lockdownów. Jedna z osób na filmie kpi, że póki nie jest prowadzony streaming na żywo, &quot; to jakbyśmy przestrzegali reguł&quot;. Zdaniem rzecznika torysów ujawnione taśmy są &quot;nie do obrony&quot;.</p><br clear="all" />

## Gwałtowne burze w całej Polsce. Podtopienia, grad, zalane ulice
 - [https://wydarzenia.interia.pl/kraj/news-gwaltowne-burze-w-calej-polsce-podtopienia-grad-zalane-ulice,nId,6848898](https://wydarzenia.interia.pl/kraj/news-gwaltowne-burze-w-calej-polsce-podtopienia-grad-zalane-ulice,nId,6848898)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-18 13:13:08+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-gwaltowne-burze-w-calej-polsce-podtopienia-grad-zalane-ulice,nId,6848898"><img align="left" alt="Gwałtowne burze w całej Polsce. Podtopienia, grad, zalane ulice" src="https://i.iplsc.com/gwaltowne-burze-w-calej-polsce-podtopienia-grad-zalane-ulice/000HALK8T9SB6W2L-C321.jpg" /></a>Woda stoi już na podwórkach, zalewa garaże i ulice - gwałtowne burze dotarły w niedzielę nad Polskę. Meteorolodzy przestrzegają przed gradobiciem i ulewami, a Rządowe Centrum Bezpieczeństwa wydało najnowsze ostrzeżenia. Mieszkańcy których województw muszą zachować szczególną ostrożność i jak wygląda aktualna sytuacja burzowa w Polsce? </p><br clear="all" />

## Napad na salon gier w Gdynii. Policja oszuka sprawców
 - [https://wydarzenia.interia.pl/pomorskie/news-napad-na-salon-gier-w-gdynii-policja-oszuka-sprawcow,nId,6848888](https://wydarzenia.interia.pl/pomorskie/news-napad-na-salon-gier-w-gdynii-policja-oszuka-sprawcow,nId,6848888)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-18 12:11:23+00:00

<p><a href="https://wydarzenia.interia.pl/pomorskie/news-napad-na-salon-gier-w-gdynii-policja-oszuka-sprawcow,nId,6848888"><img align="left" alt="Napad na salon gier w Gdynii. Policja oszuka sprawców" src="https://i.iplsc.com/napad-na-salon-gier-w-gdynii-policja-oszuka-sprawcow/000HALGYGSO0YWOM-C321.jpg" /></a>Gdyńska policja opublikowała wizerunek dwóch mężczyzn, podejrzanych o napad na salon gier przy ul. Wielkopolskiej w Gdyni. Mundurowi wystosowali prośbę o kontakt do osób, które na podstawie zdjęcia z monitoringu rozpoznają domniemanych napastników. To nie będzie trudne, bo panowie stanęli tuż przed obiektywem.  </p><br clear="all" />

## Tak Władimir Putin wyobrażał sobie rozejm. Wyciekł dokument
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-tak-wladimir-putin-wyobrazal-sobie-rozejm-wyciekl-dokument,nId,6848876](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-tak-wladimir-putin-wyobrazal-sobie-rozejm-wyciekl-dokument,nId,6848876)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-18 11:41:00+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-tak-wladimir-putin-wyobrazal-sobie-rozejm-wyciekl-dokument,nId,6848876"><img align="left" alt="Tak Władimir Putin wyobrażał sobie rozejm. Wyciekł dokument" src="https://i.iplsc.com/tak-wladimir-putin-wyobrazal-sobie-rozejm-wyciekl-dokument/000HAL90YJUNQPF0-C321.jpg" /></a>Władimir Putin podczas sobotniego spotkania z afrykańskimi przywódcami w Petersburgu pokazał projekt traktatu pokojowego, omawiany w marcu 2022 roku w Stambule przez Moskwę i Kijów. Według rosyjskiego prezydenta dokument dotyczy ukraińskich &quot;sił zbrojnych i innych rzeczy&quot;. Zdjęcia fragmentu traktatu za sprawą dziennikarzy trafiły do sieci.</p><br clear="all" />

## Sześć reniferów zagryzionych w Wielkopolsce. Wiele niewiadomych
 - [https://wydarzenia.interia.pl/wielkopolskie/news-szesc-reniferow-zagryzionych-w-wielkopolsce-wiele-niewiadomy,nId,6848811](https://wydarzenia.interia.pl/wielkopolskie/news-szesc-reniferow-zagryzionych-w-wielkopolsce-wiele-niewiadomy,nId,6848811)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-18 10:51:14+00:00

<p><a href="https://wydarzenia.interia.pl/wielkopolskie/news-szesc-reniferow-zagryzionych-w-wielkopolsce-wiele-niewiadomy,nId,6848811"><img align="left" alt="Sześć reniferów zagryzionych w Wielkopolsce. Wiele niewiadomych " src="https://i.iplsc.com/szesc-reniferow-zagryzionych-w-wielkopolsce-wiele-niewiadomy/000HAL53RCDU7HTO-C321.jpg" /></a>Sześć reniferów zostało zagryzionych w wielkopolskim gospodarstwie turystycznym. Policja twierdzi, że do dramatu przyczyniły się bezpańskie psy lub wilki. Poszkodowani uważają jednak, że widzieli agresywne zwierzęta i w ich opinii miały one obrożę, a bezpośrednią odpowiedzialność ponoszą właściciele. - Winnych będziemy szukać, aż do skutku i zrobimy wszystko, co się da, by zostali ukarani z całą możliwą mocą - mówi gospodarz Aleksander Dyczek.</p><br clear="all" />

## Delegacja RPA odleciała z Warszawy. Od czwartku nie opuszczała samolotu
 - [https://wydarzenia.interia.pl/kraj/news-delegacja-rpa-odleciala-z-warszawy-od-czwartku-nie-opuszczal,nId,6848852](https://wydarzenia.interia.pl/kraj/news-delegacja-rpa-odleciala-z-warszawy-od-czwartku-nie-opuszczal,nId,6848852)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-18 10:28:50+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-delegacja-rpa-odleciala-z-warszawy-od-czwartku-nie-opuszczal,nId,6848852"><img align="left" alt="Delegacja RPA odleciała z Warszawy. Od czwartku nie opuszczała samolotu" src="https://i.iplsc.com/delegacja-rpa-odleciala-z-warszawy-od-czwartku-nie-opuszczal/000HAL4AY4QDN6V0-C321.jpg" /></a>Samolot z delegacją południowoafrykańską na pokładzie odleciał w niedzielny poranek z warszawskiego Okęcia - potwierdziła Interii rzeczniczka warszawskiego lotniska Anna Dermont . Maszyna stacjonowała na płycie od czwartku, a przedstawiciele RPA sami podjęli decyzję o tym, by pozostać w samolocie. - Członkowie delegacji mieli ze sobą broń, ale nie mieli pozwolenia na jej wwóz do Polski. Sami mogli opuścić samolot, ale bez broni - przekazała rzeczniczka Straży Granicznej Anna Michalska.</p><br clear="all" />

## Opublikowano nagranie Polki zaginionej w Grecji. "Dramatyczna sytuacja"
 - [https://wydarzenia.interia.pl/zagranica/news-opublikowano-nagranie-polki-zaginionej-w-grecji-dramatyczna-,nId,6848824](https://wydarzenia.interia.pl/zagranica/news-opublikowano-nagranie-polki-zaginionej-w-grecji-dramatyczna-,nId,6848824)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-18 09:46:05+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-opublikowano-nagranie-polki-zaginionej-w-grecji-dramatyczna-,nId,6848824"><img align="left" alt="Opublikowano nagranie Polki zaginionej w Grecji. &quot;Dramatyczna sytuacja&quot;" src="https://i.iplsc.com/opublikowano-nagranie-polki-zaginionej-w-grecji-dramatyczna/000HAL0L91EVBTB4-C321.jpg" /></a>W sieci pojawiło się nagranie, na którym po raz ostatni zarejestrowano zaginioną na greckiej wyspie Kos Anastazję Rubińską. Młoda Polka po raz ostatni widziana była w poniedziałek w towarzystwie grupy mężczyzn z Bangladeszu, po czym ślad po niej zaginął. Na miejsce udała się matka dziewczyny, która wraz z detektywami szuka tropów swojej córki. Ojciec młodej kobiety powiedział, że &quot;sytuacja w rodzinie jest dramatyczna&quot;.</p><br clear="all" />

## Narodowy Marsz dla Życia i Rodziny w Warszawie. "Dzieci przyszłością Polski"
 - [https://wydarzenia.interia.pl/mazowieckie/news-narodowy-marsz-dla-zycia-i-rodziny-w-warszawie-dzieci-przysz,nId,6848829](https://wydarzenia.interia.pl/mazowieckie/news-narodowy-marsz-dla-zycia-i-rodziny-w-warszawie-dzieci-przysz,nId,6848829)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-18 09:20:18+00:00

<p><a href="https://wydarzenia.interia.pl/mazowieckie/news-narodowy-marsz-dla-zycia-i-rodziny-w-warszawie-dzieci-przysz,nId,6848829"><img align="left" alt="Narodowy Marsz dla Życia i Rodziny w Warszawie. &quot;Dzieci przyszłością Polski&quot;" src="https://i.iplsc.com/narodowy-marsz-dla-zycia-i-rodziny-w-warszawie-dzieci-przysz/000HAKXSDF47Q5GX-C321.jpg" /></a>W niedzielę w stolicy po raz 18. odbywa się Narodowy Marsz dla Życia i Rodziny. &quot;Dzieci przyszłością Polski&quot; to tegoroczne hasło marszu. Wydarzenie, trwające od godziny 11. zakończy msza św. w bazylice Świętego Krzyża o godz. 13.</p><br clear="all" />

## Auto uderzyło w drzewo, nie żyje dwóch młodych mężczyzn
 - [https://wydarzenia.interia.pl/swietokrzyskie/news-auto-uderzylo-w-drzewo-nie-zyje-dwoch-mlodych-mezczyzn,nId,6848820](https://wydarzenia.interia.pl/swietokrzyskie/news-auto-uderzylo-w-drzewo-nie-zyje-dwoch-mlodych-mezczyzn,nId,6848820)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-18 09:09:01+00:00

<p><a href="https://wydarzenia.interia.pl/swietokrzyskie/news-auto-uderzylo-w-drzewo-nie-zyje-dwoch-mlodych-mezczyzn,nId,6848820"><img align="left" alt="Auto uderzyło w drzewo, nie żyje dwóch młodych mężczyzn" src="https://i.iplsc.com/auto-uderzylo-w-drzewo-nie-zyje-dwoch-mlodych-mezczyzn/000HAKQWLD4G0KWU-C321.jpg" /></a>Do śmiertelnego wypadku doszło w niedzielę nad ranem w miejscowości Brzozowa w województwie świętokrzyskim. Auto, którym jechało dwóch młodych mężczyzn, uderzyło tam w drzewo. - Po przyjeździe karetki stwierdzono zgon dwóch mężczyzn, kierowcy oraz pasażera w wieku 20 oraz 18 lat - przekazał w Polsat News mł. bryg. Sylwester Kochanowski ze Świętokrzyskiej Straży Pożarnej.</p><br clear="all" />

## Rosja chce deportować niemal 300 ukraińskich dzieci. "Będą jak zakładnicy"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-chce-deportowac-niemal-300-ukrainskich-dzieci-beda-jak,nId,6848774](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-chce-deportowac-niemal-300-ukrainskich-dzieci-beda-jak,nId,6848774)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-18 08:41:25+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-chce-deportowac-niemal-300-ukrainskich-dzieci-beda-jak,nId,6848774"><img align="left" alt="Rosja chce deportować niemal 300 ukraińskich dzieci. &quot;Będą jak zakładnicy&quot;" src="https://i.iplsc.com/rosja-chce-deportowac-niemal-300-ukrainskich-dzieci-beda-jak/000HAKTNONAHML4S-C321.jpg" /></a>Prawie 300 dzieci planują wywieźć Rosjanie z okolic Berdiańska na południu Ukrainy do Czuwaszji nad środkową Wołgą - przekazał w mediach społecznościowych lojalny wobec Kijowa mer Melitopola Iwan Fedorow. Zdaniem samorządowca dzieci wysłane 1600 km od domu w głąb Rosji będą teraz przetrzymywane &quot;jako zakładnicy&quot;.</p><br clear="all" />

## Potężny pożar na filipińskim promie. 120 osób na pokładzie
 - [https://wydarzenia.interia.pl/zagranica/news-potezny-pozar-na-filipinskim-promie-120-osob-na-pokladzie,nId,6848792](https://wydarzenia.interia.pl/zagranica/news-potezny-pozar-na-filipinskim-promie-120-osob-na-pokladzie,nId,6848792)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-18 08:18:43+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-potezny-pozar-na-filipinskim-promie-120-osob-na-pokladzie,nId,6848792"><img align="left" alt="Potężny pożar na filipińskim promie. 120 osób na pokładzie" src="https://i.iplsc.com/potezny-pozar-na-filipinskim-promie-120-osob-na-pokladzie/000HAKGZ6TNRXD00-C321.jpg" /></a>120 osób zostało ewakuowanych z płonącego promu na Morzu Filipińskim nieopodal wysp w centrum kraju - informuje agencja Associated Press. Walka z ogniem trwała kilka godzin, ale nikomu nic się nie stało. Policja i prokuratura wszczęły dochodzenie w sprawie.</p><br clear="all" />

## Nietypowy poród na Śląsku. Kobieta zaczęła rodzić na ulicy
 - [https://wydarzenia.interia.pl/slaskie/news-nietypowy-porod-na-slasku-kobieta-zaczela-rodzic-na-ulicy,nId,6848800](https://wydarzenia.interia.pl/slaskie/news-nietypowy-porod-na-slasku-kobieta-zaczela-rodzic-na-ulicy,nId,6848800)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-18 07:44:03+00:00

<p><a href="https://wydarzenia.interia.pl/slaskie/news-nietypowy-porod-na-slasku-kobieta-zaczela-rodzic-na-ulicy,nId,6848800"><img align="left" alt="Nietypowy poród na Śląsku. Kobieta zaczęła rodzić na ulicy" src="https://i.iplsc.com/nietypowy-porod-na-slasku-kobieta-zaczela-rodzic-na-ulicy/000HAKIDSW5XD111-C321.jpg" /></a>Do bardzo nietypowego porodu doszło w Wiśle Dziechcince w województwie śląskim. Dziecko przyszło tam na świat… na parkingu, tuż przez drzwiami przychodni. Pomocy kobiecie udzielili pielęgniarka, lekarz oraz inna pacjentka przychodni. </p><br clear="all" />

## Nietypowy poród w Wiśle. Kobieta zaczęła rodzić na ulicy
 - [https://wydarzenia.interia.pl/slaskie/news-nietypowy-porod-w-wisle-kobieta-zaczela-rodzic-na-ulicy,nId,6848800](https://wydarzenia.interia.pl/slaskie/news-nietypowy-porod-w-wisle-kobieta-zaczela-rodzic-na-ulicy,nId,6848800)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-18 07:44:03+00:00

<p><a href="https://wydarzenia.interia.pl/slaskie/news-nietypowy-porod-w-wisle-kobieta-zaczela-rodzic-na-ulicy,nId,6848800"><img align="left" alt="Nietypowy poród w Wiśle. Kobieta zaczęła rodzić na ulicy" src="https://i.iplsc.com/nietypowy-porod-w-wisle-kobieta-zaczela-rodzic-na-ulicy/000HAKIDSW5XD111-C321.jpg" /></a>Do bardzo nietypowego porodu doszło w Wiśle w województwie śląskim. Dziecko przyszło tam na świat… na parkingu, tuż przez drzwiami przychodni. Pomocy kobiecie udzielili pielęgniarka, lekarz oraz inna pacjentka przychodni. </p><br clear="all" />

## Pieskow zaskoczył: Cel demilitaryzacji Ukrainy został w dużej mierze osiągnięty
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-pieskow-zaskoczyl-cel-demilitaryzacji-ukrainy-zostal-w-duzej,nId,6848780](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-pieskow-zaskoczyl-cel-demilitaryzacji-ukrainy-zostal-w-duzej,nId,6848780)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-18 07:01:30+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-pieskow-zaskoczyl-cel-demilitaryzacji-ukrainy-zostal-w-duzej,nId,6848780"><img align="left" alt="Pieskow zaskoczył: Cel demilitaryzacji Ukrainy został w dużej mierze osiągnięty" src="https://i.iplsc.com/pieskow-zaskoczyl-cel-demilitaryzacji-ukrainy-zostal-w-duzej/00075RUEK3PCM1DQ-C321.jpg" /></a>- Ukraina używa coraz mniej swojej broni, a coraz więcej broni dostarczanej przez kraje zachodnie - stwierdził rzecznik Kremla Dmitrij Pieskow, cytowany przez rosyjską propagandową agencję TASS. Zgodnie z jego słowami oznacza to, że &quot;cel demilitaryzacji Ukrainy został w dużej mierze osiągnięty&quot;.</p><br clear="all" />

## Ukraina zaatakowała duży magazyn broni Rosjan. Wiele godzin eksplozji
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-zaatakowala-duzy-magazyn-broni-rosjan-wiele-godzin-e,nId,6848788](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-zaatakowala-duzy-magazyn-broni-rosjan-wiele-godzin-e,nId,6848788)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-18 06:42:14+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-zaatakowala-duzy-magazyn-broni-rosjan-wiele-godzin-e,nId,6848788"><img align="left" alt="Ukraina zaatakowała duży magazyn broni Rosjan. Wiele godzin eksplozji" src="https://i.iplsc.com/ukraina-zaatakowala-duzy-magazyn-broni-rosjan-wiele-godzin-e/000HAKAJGH1RPBHF-C321.jpg" /></a>Sukces Ukrainy na froncie. W niedzielę rano wojsko zaatakowało duży skład amunicji zlokalizowany w okupowanym przez Rosjan obwodzie chersońskim. Eksplozje słychać od kilku godzin. &quot;Dobra robota, chłopcy!&quot; - napisał na Telegramie dowódca ukraińskich Sił Powietrznych generał Mykoła Ołeszczuk.</p><br clear="all" />

## Burzowy klin przeszyje Polskę. Do tego grad
 - [https://wydarzenia.interia.pl/kraj/news-burzowy-klin-przeszyje-polske-do-tego-grad,nId,6845492](https://wydarzenia.interia.pl/kraj/news-burzowy-klin-przeszyje-polske-do-tego-grad,nId,6845492)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-18 05:54:40+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-burzowy-klin-przeszyje-polske-do-tego-grad,nId,6845492"><img align="left" alt="Burzowy klin przeszyje Polskę. Do tego grad" src="https://i.iplsc.com/burzowy-klin-przeszyje-polske-do-tego-grad/000HAE3BHEKPRSNY-C321.jpg" /></a>Jak wynika z prognozy pogody przygotowanej przez Instytut Meteorologii i Gospodarki Wodnej, w niedzielę będzie odczuwalnie cieplej niż w sobotę. Trzeba się jednak dalej liczyć z opadami deszczu, lokalnymi burzami i gradem. Wzdłuż wschodniej granicy kraju przebiegnie chłodny front atmosferyczny i tam opady deszczu mogą być najintensywniejsze. </p><br clear="all" />

## Ślub córki Morawieckiego. "Historia ojcowskiej miłości nigdy się nie kończy"
 - [https://wydarzenia.interia.pl/mazowieckie/news-slub-corki-morawieckiego-historia-ojcowskiej-milosci-nigdy-s,nId,6848772](https://wydarzenia.interia.pl/mazowieckie/news-slub-corki-morawieckiego-historia-ojcowskiej-milosci-nigdy-s,nId,6848772)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-18 05:23:29+00:00

<p><a href="https://wydarzenia.interia.pl/mazowieckie/news-slub-corki-morawieckiego-historia-ojcowskiej-milosci-nigdy-s,nId,6848772"><img align="left" alt="Ślub córki Morawieckiego. &quot;Historia ojcowskiej miłości nigdy się nie kończy&quot;" src="https://i.iplsc.com/slub-corki-morawieckiego-historia-ojcowskiej-milosci-nigdy-s/000HAK7N89K6421Y-C321.jpg" /></a>Olga Morawiecka, córka premiera Mateusza Morawieckiego i jego żony Iwony, wzięła w sobotę ślub. Ceremonia odbyła się w sanktuarium św. Andrzeja Boboli na warszawskim Mokotowie. &quot;Prawdziwa historia ojcowskiej miłości nigdy się nie kończy. Moja zaczęła się, gdy pierwszy raz wziąłem Cię w ramiona. Dziś z dumą poprowadziłem do Ołtarza&quot; - napisał w mediach społecznościowych szef rządu.</p><br clear="all" />

## Od 20 lat przeprowadza sekcje zwłok. To zastanawiające, co mówi o śmierci
 - [https://wydarzenia.interia.pl/tylko-w-interii/news-od-20-lat-przeprowadza-sekcje-zwlok-to-zastanawiajace-co-mow,nId,6817454](https://wydarzenia.interia.pl/tylko-w-interii/news-od-20-lat-przeprowadza-sekcje-zwlok-to-zastanawiajace-co-mow,nId,6817454)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-18 05:10:00+00:00

<p><a href="https://wydarzenia.interia.pl/tylko-w-interii/news-od-20-lat-przeprowadza-sekcje-zwlok-to-zastanawiajace-co-mow,nId,6817454"><img align="left" alt="Od 20 lat przeprowadza sekcje zwłok. To zastanawiające, co mówi o śmierci" src="https://i.iplsc.com/od-20-lat-przeprowadza-sekcje-zwlok-to-zastanawiajace-co-mow/000H8BHU8BT9R5GS-C321.jpg" /></a>- Były sekcje, które okazały się dla mnie kompletnym zaskoczeniem. Kilka miesięcy temu mieliśmy przypadek młodego chłopaka, nastolatka. Wszedł na dach wieżowca i skoczył z niego. Jednak drzewo znajdujące się przed blokiem zamortyzowało upadek i chłopak przeżył. Po wszystkim wstał, wyjechał windą na górę raz jeszcze i ponownie skoczył - mówi w rozmowie z Interią dr Filip Bolechała, kierownik pracowni tanatologii i specjalista medycyny sądowej z Zakładu Medycyny Sądowej Collegium Medicum Uniwersytetu Jagiellońskiego w Krakowie. W zawodzie od...</p><br clear="all" />

## Dokąd na zakupy? Czy 18 czerwca jest niedziela handlowa?
 - [https://wydarzenia.interia.pl/ciekawostki/news-dokad-na-zakupy-czy-18-czerwca-jest-niedziela-handlowa,nId,6844999](https://wydarzenia.interia.pl/ciekawostki/news-dokad-na-zakupy-czy-18-czerwca-jest-niedziela-handlowa,nId,6844999)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-06-18 04:32:00+00:00

<p><a href="https://wydarzenia.interia.pl/ciekawostki/news-dokad-na-zakupy-czy-18-czerwca-jest-niedziela-handlowa,nId,6844999"><img align="left" alt="Dokąd na zakupy? Czy 18 czerwca jest niedziela handlowa?" src="https://i.iplsc.com/dokad-na-zakupy-czy-18-czerwca-jest-niedziela-handlowa/000GKEDEVHP5JC17-C321.jpg" /></a>Czy 18 czerwca jest niedzielą handlową? Na kolejną okazję do niedzielnej wizyty w galerii nie będzie trzeba długo czekać. Do następnej daty wyłączonej z zapisów ustawy z 2018 roku pozostał zaledwie tydzień. Gdzie można zrobić zakupy w niedzielę niehandlową? Jaka kara grozi właścicielom, którzy nie respektują zakazów? Wyjaśniamy.</p><br clear="all" />

