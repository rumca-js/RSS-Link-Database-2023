# Source:ArsTechnica, URL:http://feeds.arstechnica.com/arstechnica/index/, language:en-US

## The sleeper hits of Summer Game Fest 2023
 - [https://arstechnica.com/?p=1948256](https://arstechnica.com/?p=1948256)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-06-18 11:00:40+00:00

Games about time travel, foam spraying guns, and... space hospitals?

