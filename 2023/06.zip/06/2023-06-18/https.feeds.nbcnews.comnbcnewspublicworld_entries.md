# Source:NBC world, URL:https://feeds.nbcnews.com/nbcnews/public/world, language:en-US

## Emotional reunion for brothers as hopes fade for survivors of migrant boat shipwreck
 - [https://www.nbcnews.com/news/world/brothers-survivors-migrant-boat-shipwreck-greece-families-rcna89917](https://www.nbcnews.com/news/world/brothers-survivors-migrant-boat-shipwreck-greece-families-rcna89917)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/world
 - date published: 2023-06-18 15:31:39+00:00

It was a brief glimmer of hope in otherwise bleak circumstances.

## Blinken arrives in Beijing on mission to cool U.S.-China tensions
 - [https://www.nbcnews.com/news/world/blinken-arrives-beijing-mission-cool-us-china-tensions-rcna89908](https://www.nbcnews.com/news/world/blinken-arrives-beijing-mission-cool-us-china-tensions-rcna89908)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/world
 - date published: 2023-06-18 01:44:29+00:00

U.S. Secretary of State Antony Blinken arrived in Beijing early Sunday on a high-stakes diplomatic mission to try to cool  U.S.-China tensions

