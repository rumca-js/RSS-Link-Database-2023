# Source:Sky News, URL:http://feeds.skynews.com/feeds/rss/world.xml, language:en-US

## Families begin burying loved ones after Uganda school attack leaves 42 dead
 - [https://news.sky.com/story/uganda-school-attack-families-begin-burying-loved-ones-after-atrocity-leaves-42-dead-12905107](https://news.sky.com/story/uganda-school-attack-families-begin-burying-loved-ones-after-atrocity-leaves-42-dead-12905107)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-06-18 19:28:00+00:00

Families in a Ugandan border town have begun burying their loved ones who died after a school was targeted by suspected extremist rebels.

## Pakistan to hold day of mourning after boat sinks off Greek coast
 - [https://news.sky.com/story/greece-migrant-boat-disaster-pakistan-to-hold-day-of-mourning-after-hundreds-die-in-tragedy-12905034](https://news.sky.com/story/greece-migrant-boat-disaster-pakistan-to-hold-day-of-mourning-after-hundreds-die-in-tragedy-12905034)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-06-18 16:51:00+00:00

Pakistan's prime minister has declared a national day of mourning for those who died when a fishing trawler packed with people sank off the coast of Greece.

## Attack on Pride parade by alleged IS sympathisers is foiled
 - [https://news.sky.com/story/vienna-pride-attack-planned-by-alleged-is-sympathisers-foiled-by-authorities-12904906](https://news.sky.com/story/vienna-pride-attack-planned-by-alleged-is-sympathisers-foiled-by-authorities-12904906)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-06-18 14:29:00+00:00

Authorities in Austria have said they stopped a potential attack on Vienna's Pride parade by three young Islamic State sympathisers.

## Woman who knocked on coffin during her own funeral dies after a week in intensive care
 - [https://news.sky.com/story/woman-who-knocked-on-coffin-during-her-own-funeral-dies-after-a-week-in-intensive-care-12904738](https://news.sky.com/story/woman-who-knocked-on-coffin-during-her-own-funeral-dies-after-a-week-in-intensive-care-12904738)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-06-18 10:02:00+00:00

A 76-year-old woman who was wrongly declared dead and surprised family members by knocking on her coffin has now passed away.

## As Swiss glaciers melt at alarming rate, voters go to polls over ambitious plans to tackle climate change
 - [https://news.sky.com/story/as-swiss-glaciers-melt-at-alarming-rate-voters-go-to-polls-over-ambitious-plans-to-tackle-climate-change-12904670](https://news.sky.com/story/as-swiss-glaciers-melt-at-alarming-rate-voters-go-to-polls-over-ambitious-plans-to-tackle-climate-change-12904670)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-06-18 07:27:00+00:00

A referendum is being held in Switzerland to decide on a climate bill aimed at introducing new measures to save the country's melting glaciers.

## For the first time ever, Brazil's football team wear black shirts during game
 - [https://news.sky.com/story/for-the-first-time-ever-brazils-football-team-wear-black-shirts-during-game-12904653](https://news.sky.com/story/for-the-first-time-ever-brazils-football-team-wear-black-shirts-during-game-12904653)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-06-18 06:21:00+00:00

Brazil's football team wore black shirts instead of yellow for the first time ever in a stand against racism.

## Never seen herbivore! This dinosaur roamed Earth 72 million years ago - we now know what they look like
 - [https://news.sky.com/story/new-species-of-duck-billed-dinosaur-found-in-chile-after-decades-long-investigation-12904649](https://news.sky.com/story/new-species-of-duck-billed-dinosaur-found-in-chile-after-decades-long-investigation-12904649)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-06-18 05:46:00+00:00

Scientists have discovered the fossilised remains of a new species of duck-billed dinosaur that roamed Chile 72 million years ago.

