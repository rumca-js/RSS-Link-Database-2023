# Source:Rotten Tomatoes Trailers, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCi8e0iOVk1fEOogdfu4YgfA, language:en-US

## Asking Fans Who Their Favorite 'Across the Spider-Verse' Character Is
 - [https://www.youtube.com/watch?v=dFtzf20Ix5s](https://www.youtube.com/watch?v=dFtzf20Ix5s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCi8e0iOVk1fEOogdfu4YgfA
 - date published: 2023-06-18 17:00:18+00:00

Who is your favorite Spider-Verse character?

#shorts 

► Watch the full video here: https://youtu.be/3Y4zzxDM5PM
► Buy Tickets: https://www.fandango.com/?cmp=Trailers_YouTube_Desc 
► Learn more: https://www.rottentomatoes.com/?cmp=Trailers_YouTube_Desc

## Rebel Moon Featurette - Behind the Scenes (2023)
 - [https://www.youtube.com/watch?v=HUAcDDZG4Tg](https://www.youtube.com/watch?v=HUAcDDZG4Tg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCi8e0iOVk1fEOogdfu4YgfA
 - date published: 2023-06-18 06:47:53+00:00

Check out the official Rebel Moon Behind the Scenes featurette starring Djimon Hounsou!  
► Learn more: https://www.rottentomatoes.com/m/rebel_moon/?cmp=Trailers_YouTube_Desc 
 
Subscribe to the channel and click the bell icon to be notified of all the latest movies: http://bit.ly/2CNniBy  
 
US Release Date: December 22, 2023
Starring: Simon Boutella, Djimon Hounsou, Ed Skrein
Directed By: Zack Snyder
Synopsis: When a peaceful colony on the edge of the galaxy finds itself threatened by the armies of the tyrannical Regent Balisarius, they dispatch a young woman with a mysterious past named Kora to seek out warriors from neighboring planets to help them take a stand.

Watch More:  
► Rotten Tomatoes Originals: http://bit.ly/2D3sipV    
► Fresh New Clips: https://bit.ly/3mJePrv    
► Hot New Trailers: http://bit.ly/2qThrsF   
► New TV This Week: http://bit.ly/2Cq3wzc  
 
The Rotten Tomatoes TRAILERS channel delivers hot new trailers, teasers, and sneak peeks for all the best upcoming movies. Subscribe to stay up to date on everything coming to theaters and your favorite streaming platform.

