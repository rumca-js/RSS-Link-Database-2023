# Source:China Insights, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwjvvgGX6oby5mZ3gbDe8Ug, language:en-US

## Cities around Beijing: Officials said the massive explosions were due to firecrackers ... impossible
 - [https://www.youtube.com/watch?v=tf_oiCQe1fE](https://www.youtube.com/watch?v=tf_oiCQe1fE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwjvvgGX6oby5mZ3gbDe8Ug
 - date published: 2023-06-18 01:15:07+00:00

#Chinainsights#Chinaexplosion
On the evening of June 13th, 2023, explosions occurred in two neighborhoods in the metropolitan city, Tianjin. According to an official announcement, the explosions damaged at least 26 homes, resulting in three deaths and multiple injuries.
China's news has a trait. That is, what is officially hyped up isn’t necessarily important, and what is officially low-key isn’t necessarily trivial. The party media can make a simple matter so big that everyone knows about it or even engages in it, or they can make a really serious issue so low-key that people don’t even notice it which is quickly forgotten. 

Have questions? Do you have something to share with us about China? We want to hear from you! 
Email: Cinsights.subscription@gmail.com
Facebook www.facebook.com/EyesOnChina.

Your support allows us to produce more high-quality videos. 
Consider donating at https://www.paypal.com/paypalme/ChinaInsights

Copyright @ China Insights 2021. Any illegal reproduction of this content in any form will result in immediate action against the person(s) concerned.

