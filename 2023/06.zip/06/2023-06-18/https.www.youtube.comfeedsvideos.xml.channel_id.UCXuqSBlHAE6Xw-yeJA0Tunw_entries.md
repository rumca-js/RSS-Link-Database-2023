# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## I'm Clearly Out of Touch - Roku Plus Series TV Review
 - [https://www.youtube.com/watch?v=VK6GYwPTcw4](https://www.youtube.com/watch?v=VK6GYwPTcw4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2023-06-18 16:51:59+00:00

Thanks to Mine for sponsoring this video! Discover where your data is, and take it back at https://bit.ly/saymine-personaldata-LTT

Save 10% and Free Worldwide Shipping at Ridge by using offer code LINUS at https://www.ridge.com/LINUS

If you already have a Roku account, should you skip the middle man and buy a Roku TV? The Plus Series QLEDs might have just found the right price bracket if you're looking for an upgrade.

Discuss on the forum: https://linustechtips.com/topic/1514007-im-clearly-out-of-touch-roku-plus-series-tv-review/

Buy a Roku 55R6A5R 55" 4K QLED Smart RokuTV: https://lmg.gg/UQodW
Buy a Roku Ultra 4K Streaming Device: https://geni.us/tPDCNvQ
Buy a TCL 55R646 55" 4K Mini-LED QLED UHD Smart Google TV: https://lmg.gg/z9BPA
Buy a Samsung S95B 55" 4K OLED Smart TV: https://lmg.gg/BTETZ

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► LTX 2023 TICKETS AVAILABLE NOW: https://lmg.gg/ltx23
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► EQUIPMENT WE USE TO FILM LTT: https://lmg.gg/LTTEquipment
► OUR WAN PODCAST GEAR: https://lmg.gg/wanset

FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
2:27 Color Accuracy
4:30 Brightness
6:25 Gaming
7:30 UI
8:55 Conclusion
10:39 Outro

