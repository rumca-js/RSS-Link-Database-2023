# Source:Epoch Times Tech, URL:https://www.theepochtimes.com/c-tech/feed/, language:en-US

## Microsoft Says Early June Disruptions to Outlook, Cloud Platform Were Cyberattacks
 - [https://www.theepochtimes.com/microsoft-says-early-june-disruptions-to-outlook-cloud-platform-were-cyberattacks_5340626.html](https://www.theepochtimes.com/microsoft-says-early-june-disruptions-to-outlook-cloud-platform-were-cyberattacks_5340626.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2023-06-18 19:36:18+00:00

The Microsoft company logo is displayed at their offices in Sydney on Feb. 3, 2021. (Rick Rycroft/AP Photo)

