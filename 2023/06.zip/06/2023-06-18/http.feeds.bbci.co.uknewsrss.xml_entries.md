# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Croatia 0-0 Spain (Pens: 4-5): Spaniards win Nations League for first title in 11 years
 - [https://www.bbc.co.uk/sport/football/65944659?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65944659?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 21:52:20+00:00

Croatia miss out on their first ever international trophy as they lose on penalties against Spain in the Nations League final in Rotterdam.

## Luke Shaw 'would love' England team-mates Harry Kane and Declan Rice to join him at Man Utd
 - [https://www.bbc.co.uk/sport/football/65946365?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65946365?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 21:46:26+00:00

Luke Shaw has been selling Manchester United to his England team-mates and would welcome Harry Kane and Declan Rice to the club "in a heartbeat".

## Canadian Grand Prix: Max Verstappen wins to equal Ayrton Senna victories total
 - [https://www.bbc.co.uk/sport/formula1/65945886?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/formula1/65945886?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 19:55:56+00:00

Red Bull's Max Verstappen equals Ayrton Senna's career total of 41 victories with a dominant win at the Canadian Grand Prix.

## Uganda school attack: 'Gospel songs interrupted by screaming'
 - [https://www.bbc.co.uk/news/world-africa-65945814?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-65945814?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 18:38:13+00:00

Mourners of those killed by Islamist militants describe their shock about the raid's brutality.

## The Ashes 2023: Ollie Robinson 'does not care' about how Usman Khawaja celebration is seen
 - [https://www.bbc.co.uk/sport/cricket/65946176?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/65946176?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 18:37:29+00:00

England's Ollie Robinson says he does not care how his celebration for the wicket of Usman Khawaja was perceived in the Australia dressing room.

## The Ashes 2023: Australia finally arrive in gripping 20-minute spell at Edgbaston
 - [https://www.bbc.co.uk/sport/cricket/65945139?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/65945139?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 17:49:21+00:00

The real Australia arrive at Edgbaston as the tourists capitalise on conditions in a gripping 20-minute spell which leaves England on the back foot.

## Iraq: displays 2,800-year-old stone tablet returned by Italy
 - [https://www.bbc.co.uk/news/world-middle-east-65944282?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-65944282?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 17:33:03+00:00

Italian authorities handed over the ancient tablet to Iraq after more than four decades.

## The Ashes 2023: England struggle as the rain takes over on day three
 - [https://www.bbc.co.uk/sport/av/cricket/65943790?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/65943790?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 17:23:44+00:00

Watch highlights of day three of the Ashes 2023 as Australia lose their last four wickets for 14 runs in 21 balls and England lose two openers before the rain stops play.

## The Ashes 2023: Australia hit England between Edgbaston showers
 - [https://www.bbc.co.uk/sport/cricket/65944876?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/65944876?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 17:16:03+00:00

England are hit by a one-two punch from Australia in a devastating 21-minute break in the rain that ruined the third day of the first Ashes Test.

## Nottingham stabbings: Barnaby Webber's parents honour their 'lovely soul'
 - [https://www.bbc.co.uk/news/uk-england-somerset-65944956?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-somerset-65944956?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 16:36:30+00:00

The parents of a student killed with two others in Nottingham stabbings pay tribute at his cricket club.

## Greece boat disaster: Ship tracking casts doubt on Greek Coastguard's account
 - [https://www.bbc.co.uk/news/world-europe-65942426?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-65942426?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 16:27:51+00:00

The BBC finds evidence an overcrowded fishing vessel was not moving for at least seven hours before it capsized.

## Birmingham police save 'slippery customer' boa constrictor spotted in road
 - [https://www.bbc.co.uk/news/uk-england-birmingham-65943681?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-birmingham-65943681?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 16:01:33+00:00

Officers got an "off-the-scale" shock when they spotted the large snake in Birmingham, police say.

## England v North Macedonia: Players tapping up team-mates, jokes Gareth Southgate
 - [https://www.bbc.co.uk/sport/football/65874634?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65874634?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 15:44:45+00:00

England manager Gareth Southgate jokes his players will be "tapping up" team-mates while on international duty.

## Nottingham Open: Katie Boulter beats Jodie Burrage to win first WTA title
 - [https://www.bbc.co.uk/sport/av/tennis/65944411?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/tennis/65944411?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 15:09:33+00:00

Watch some of the best shots as Katie Boulter beats British compatriot Jodie Burrage to win the Nottingham Open final.

## The Ashes 2023: Australia's Cameron Green removes England's Ben Duckett for 19
 - [https://www.bbc.co.uk/sport/av/cricket/65943630?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/65943630?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 14:53:56+00:00

Watch as Australia's Cameron Green takes an excellent catch to remove England's Ben Duckett on day three of the first Ashes Test.

## Nottingham Open 2023 results: Katie Boulter beats Jodie Burrage to win first WTA title
 - [https://www.bbc.co.uk/sport/tennis/65943414?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/65943414?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 14:32:52+00:00

Katie Boulter wins her first WTA title with a dominant victory in Nottingham over Jodie Burrage in the first all-British tour-level final in 46 years.

## Graeme Souness: Football legend swims Channel for £1m fundraiser
 - [https://www.bbc.co.uk/news/uk-england-dorset-65944866?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-dorset-65944866?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 14:29:43+00:00

The 70-year-old former footballer completes the 21-mile challenge in 12 hours and 17 minutes.

## Woman who knocked on coffin at her funeral dies after week in hospital
 - [https://www.bbc.co.uk/news/world-latin-america-65942430?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-latin-america-65942430?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 14:12:07+00:00

The Ecuadorean woman died days after mourners at her funeral were shocked to find her alive in her coffin.

## Ruben Neves: Wolves captain set to join Saudi Arabia's Al Hilal in £47m deal
 - [https://www.bbc.co.uk/sport/football/65945030?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65945030?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 14:07:53+00:00

Wolves agree a 55m euro (£47m) deal to sell captain Ruben Neves to Saudi Arabia's Al Hilal.

## Emma Raducanu reveals she sometimes wishes she never won US Open
 - [https://www.bbc.co.uk/sport/tennis/65944089?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/65944089?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 13:23:39+00:00

Emma Raducanu says "sometimes I think to myself 'I wish I'd never won the US Open'" as she speaks about her physical and mental struggles since then.

## Murray gets Father's Day surprise
 - [https://www.bbc.co.uk/sport/av/tennis/65944620?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/tennis/65944620?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 12:59:35+00:00

After winning the Nottingham Open, Andy Murray is surprised to discover his children are in the crowd to support him on Father's Day.

## Nicola Sturgeon: I am certain I have done nothing wrong
 - [https://www.bbc.co.uk/news/uk-scotland-scotland-politics-65942728?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-scotland-politics-65942728?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 12:35:53+00:00

Scotland's former first minister returns home for the first time since her arrest.

## Murray wins Nottingham Open for back-to-back titles
 - [https://www.bbc.co.uk/sport/tennis/65943406?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/65943406?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 12:22:24+00:00

Andy Murray wins the Nottingham Open for back-to-back grass-court titles to maintain a perfect Wimbledon build-up.

## Nottingham Open final: Andy Murray beats Arthur Cazaux to win title
 - [https://www.bbc.co.uk/sport/av/tennis/65944408?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/tennis/65944408?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 12:18:07+00:00

Watch the winning moment as Andy Murray makes it back-to-back grass-court titles with victory over Arthur Cazaux in the Nottingham Open final.

## The Ashes 2023: England's Ollie Robinson removes Australia's Usman Khawaja with superb yorker
 - [https://www.bbc.co.uk/sport/av/cricket/65943628?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/65943628?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 11:52:04+00:00

England's Ollie Robinson bowls a superb yorker to finally remove Australia's Usman Khawaja for an impressive 141 on day three of the first Ashes Test.

## Mortgage help 'under review', says Michael Gove
 - [https://www.bbc.co.uk/news/business-65922072?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-65922072?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 11:05:19+00:00

Michael Gove was asked about what whether any help would be given to those struggling with payments.

## Labour has momentum but is not complacent - Sarwar
 - [https://www.bbc.co.uk/news/uk-scotland-scotland-politics-65942723?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-scotland-politics-65942723?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 10:59:00+00:00

The Scottish Labour leader says his party still has work to do despite signs of improved fortunes.

## The Ashes 2023: England's James Anderson picks up his first wicket
 - [https://www.bbc.co.uk/sport/av/cricket/65943626?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/65943626?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 10:33:41+00:00

England's James Anderson picks up the huge wicket of Australia's Alex Carey on day three of the first Ashes Test.

## Michael Gove would not vote for Johnson Partygate report
 - [https://www.bbc.co.uk/news/uk-politics-65942837?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-65942837?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 10:21:26+00:00

The housing secretary says a 90-day Commons suspension for the ex-PM is "not merited".

## The Ashes 2023: England's Jonny Bairstow drops Australia's Alex Carey on 52
 - [https://www.bbc.co.uk/sport/av/cricket/65932601?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/65932601?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 10:18:06+00:00

England wicketkeeper Jonny Bairstow misses a huge opportunity as he drops Australia's Alex Carey on 52 at the start of day three of the first Ashes Test.

## Couple and pets saved after lightning strike house blaze
 - [https://www.bbc.co.uk/news/uk-england-essex-65943092?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-essex-65943092?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 10:00:02+00:00

Neighbours alerted the couple that their home in Corringham was ablaze, the fire service says.

## US Open 2023: Scottie Scheffler makes superb eagle to stay in touch with leaders
 - [https://www.bbc.co.uk/sport/av/golf/65943016?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/golf/65943016?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 08:53:11+00:00

World number one Scottie Scheffler holes from 196 yards for an eagle on the 17th to stay in touch with the leaders at the US Open.

## BTS: Fans celebrate 10 years of 'unstoppable' K-pop group
 - [https://www.bbc.co.uk/news/newsbeat-65931432?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-65931432?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 08:35:25+00:00

The world's biggest boyband have been feeling the love with millions celebrating their 10th birthday.

## US Open 2023: Watch joint leader Rickie Fowler's 'perfectly judged' long-range birdie putt
 - [https://www.bbc.co.uk/sport/av/golf/65943014?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/golf/65943014?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 08:13:57+00:00

Watch Rickie Fowler's "sensational" long-range birdie putt on the 13th, which helped give him a share of the lead after round three of the US Open.

## Sir Mark Rylance: 'Acting used to be more accepting of oddballs'
 - [https://www.bbc.co.uk/news/uk-65942440?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-65942440?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 07:40:07+00:00

The actor is pleased to see "things have improved" for actors from underrepresented backgrounds.

## Philippines passenger ship catches fire at sea
 - [https://www.bbc.co.uk/news/world-asia-65942742?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-65942742?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 07:32:41+00:00

All passengers and crew on board have been accounted for and no casualties were reported.

## Norway 1-2 Scotland: Erling Haaland upstaged by Scotland's act of escapology in Oslo
 - [https://www.bbc.co.uk/sport/football/65941525?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65941525?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 07:21:52+00:00

BBC Scotland's chief sportswriter Tom English pours over a fantastic night for Scotland in Norway.

## Brazil 4-1 Guinea: Brazil wear all-black kit in anti-racism message
 - [https://www.bbc.co.uk/sport/football/65941621?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65941621?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 07:06:25+00:00

Brazil play in an all-black kit for the first half of their win against Guinea in Spain as part of an anti-racism campaign.

## Sunday's gossip: Pickford, Lukaku, Barella, Cucurella, Gallagher, Caicedo, Veiga, Arteta
 - [https://www.bbc.co.uk/sport/65936698?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/65936698?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 06:12:29+00:00

Manchester United to bid for Jordan Pickford, Chelsea ask to swap Romelu Lukaku for Nicolo Barella, Newcastle target Marc Cucurella, plus more.

## Glastonbury fashion: Festival fans turn to second-hand outfits
 - [https://www.bbc.co.uk/news/uk-wales-65908821?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-65908821?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 06:11:21+00:00

Why music lovers turn to second-hand clothes sites as they strive to become more sustainable.

## Cost of living: Mum and daughter in York offer prom dress loan scheme
 - [https://www.bbc.co.uk/news/uk-england-york-north-yorkshire-65915740?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-york-north-yorkshire-65915740?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 05:54:16+00:00

Dani and Megen England say people can borrow a dress at no cost.

## Prince William: Young royals 'will definitely be exposed' to homelessness
 - [https://www.bbc.co.uk/news/uk-65941931?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-65941931?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 05:24:27+00:00

The Prince of Wales has posed with his three children in a portrait released for Father's Day.

## The Ashes 2023: Phil Tufnell says spin will be key on day three at Edgbaston
 - [https://www.bbc.co.uk/sport/av/cricket/65941271?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/65941271?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 05:06:04+00:00

Today at the Test's Phil Tufnell says spin will be key on day three of the first Ashes Test at Edgbaston.

## The Grade Cricketer: Aussies are impressed by Stuart Broad's vibes
 - [https://www.bbc.co.uk/sport/av/cricket/65941277?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/65941277?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 05:05:58+00:00

Australian podcasters from The Grade Cricketer discuss Stuart Broad's vibes and Ben Stokes' funky fields after the second day of the Ashes series against England at Edgbaston.

## US Open 2023: Rickie Fowler & Wyndham Clark lead with Rory McIlroy and Scottie Scheffler firmly in contention
 - [https://www.bbc.co.uk/sport/golf/65941866?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/golf/65941866?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 04:49:05+00:00

Rickie Fowler and Wyndham Clark take a one-shot lead into the final round of the US Open with Rory McIlroy and Scottie Scheffler firmly in contention.

## Blinken arrives in Beijing for high-stakes visit to China
 - [https://www.bbc.co.uk/news/world-us-canada-65941659?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-65941659?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 03:33:15+00:00

The US secretary of state is the first American diplomat to visit China in almost five years.

## Deepfake porn documentary explores its 'life-shattering' impact
 - [https://www.bbc.co.uk/news/entertainment-arts-65854112?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-65854112?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 01:34:32+00:00

The documentary film My Blonde GF explores the trauma and impact of deepfake pornography.

## The Papers: William to end homelessness, and more Partygate revelations
 - [https://www.bbc.co.uk/news/blogs-the-papers-65941581?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-65941581?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 00:28:13+00:00

Sunday's front pages include a Father's Day picture of the Prince of Wales and his children.

## Your pictures on the theme of 'waterfalls'
 - [https://www.bbc.co.uk/news/in-pictures-65876958?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/in-pictures-65876958?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-06-18 00:27:15+00:00

A selection of striking images from our readers around the world.

