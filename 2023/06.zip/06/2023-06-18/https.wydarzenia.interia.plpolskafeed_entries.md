# Source:Wydarzenia Interia - Polska, URL:https://wydarzenia.interia.pl/polska/feed, language:pl-PL

## Prezes Kaczyński obchodzi urodziny. Zareagował Donald Tusk
 - [https://wydarzenia.interia.pl/kraj/news-prezes-kaczynski-obchodzi-urodziny-zareagowal-donald-tusk,nId,6848889](https://wydarzenia.interia.pl/kraj/news-prezes-kaczynski-obchodzi-urodziny-zareagowal-donald-tusk,nId,6848889)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-06-18 12:41:12+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-prezes-kaczynski-obchodzi-urodziny-zareagowal-donald-tusk,nId,6848889"><img align="left" alt="Prezes Kaczyński obchodzi urodziny. Zareagował Donald Tusk " src="https://i.iplsc.com/prezes-kaczynski-obchodzi-urodziny-zareagowal-donald-tusk/000HALIJVVQ5GU0D-C321.jpg" /></a>Swoje 74. urodziny obchodzi w niedzielę Jarosław Kaczyński. Z tej okazji niektórzy politycy z różnych stron sceny postanowili złożyć życzenia prezesowi partii rządzącej, a jednym z nich był przewodniczący Platformy Obywatelskiej. &quot;Zdrowia, szczęścia w życiu osobistym i następnych urodzin w wolnej Polsce. Z całego serca!&quot; - napisał Donald Tusk na Twitterze.</p><br clear="all" />

