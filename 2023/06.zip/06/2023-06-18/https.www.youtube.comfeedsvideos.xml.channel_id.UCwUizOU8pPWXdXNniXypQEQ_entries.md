# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## I DON'T EAT MEAT
 - [https://www.youtube.com/watch?v=KmzLy-h9j74](https://www.youtube.com/watch?v=KmzLy-h9j74)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2023-06-18 16:52:15+00:00

#shorts

