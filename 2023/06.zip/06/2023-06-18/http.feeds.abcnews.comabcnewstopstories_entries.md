# Source:ABC News, URL:http://feeds.abcnews.com/abcnews/topstories, language:en-US

## Mexican authorities destroy 14 homemade armored cars used by drug cartels
 - [https://abcnews.go.com/International/wireStory/mexican-authorities-destroy-14-homemade-armored-cars-drug-100182726](https://abcnews.go.com/International/wireStory/mexican-authorities-destroy-14-homemade-armored-cars-drug-100182726)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-06-18 22:21:52+00:00

The armored vehicles are known in Mexico as &quot;monstruos,&quot; or &quot;Monsters.&quot;

## WATCH:  Strong winds send shopping carts across parking lot
 - [https://abcnews.go.com/US/video/strong-winds-send-shopping-carts-parking-lot-100182305](https://abcnews.go.com/US/video/strong-winds-send-shopping-carts-parking-lot-100182305)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-06-18 21:25:51+00:00

Powerful winds sent carts racing across a shopping center parking lot in Oklahoma.

## 1 dead, 10 injured in shooting at party in St. Louis office building: Police
 - [https://abcnews.go.com/US/1-dead-10-injured-shooting-party-st-louis/story?id=100180581](https://abcnews.go.com/US/1-dead-10-injured-shooting-party-st-louis/story?id=100180581)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-06-18 21:24:45+00:00

A shooting at a party in a downtown St. Louis office building injured at least 10 and killed one person, St. Louis Police Chief Robert Tracy said at a press conference.

## Man stabs pit bull to death in Central Park after argument between dog walkers
 - [https://abcnews.go.com/US/wireStory/man-stabs-pit-bull-death-central-park-after-100181131](https://abcnews.go.com/US/wireStory/man-stabs-pit-bull-death-central-park-after-100181131)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-06-18 19:58:33+00:00

A man stabbed a pit bull to death in New York City&rsquo;s Central Park after a verbal dispute with the dog&rsquo;s owner

## Judge in Trump's federal case has acted like 'Trump advocate in a robe': Whitehouse
 - [https://abcnews.go.com/Politics/whitehouse-unclear-trump-appointed-judge-overseeing-federal-case/story?id=100165584](https://abcnews.go.com/Politics/whitehouse-unclear-trump-appointed-judge-overseeing-federal-case/story?id=100165584)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-06-18 17:17:29+00:00

Sen. Sheldon Whitehouse said it remains to be seen whether Judge Aileen Cannon, assigned to Trump’s federal case, can act independently

## Bus driver arrested on DUI charge while driving Pirates from Chicago to Milwaukee
 - [https://abcnews.go.com/Sports/wireStory/bus-driver-arrested-dui-charge-driving-pirates-chicago-100178978](https://abcnews.go.com/Sports/wireStory/bus-driver-arrested-dui-charge-driving-pirates-chicago-100178978)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-06-18 16:10:49+00:00

A bus driver has been arrested on a charge of driving under the influence while transporting the Pittsburgh Pirates from Chicago to Milwaukee for their weekend series with the Brewers

## State trooper killed, another wounded in shootings that left suspect dead
 - [https://abcnews.go.com/US/state-trooper-killed-wounded-separate-pennsylvania-shootings-left/story?id=100177301](https://abcnews.go.com/US/state-trooper-killed-wounded-separate-pennsylvania-shootings-left/story?id=100177301)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-06-18 15:48:16+00:00

A state trooper was killed and another was critically injured during two violent encounters with the same armed suspect in central Pennsylvania, authorities said.

## David Freese declines induction into the St. Louis Cardinals' Hall of Fame
 - [https://abcnews.go.com/Sports/wireStory/david-freese-declines-induction-st-louis-cardinals-hall-100177687](https://abcnews.go.com/Sports/wireStory/david-freese-declines-induction-st-louis-cardinals-hall-100177687)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-06-18 14:47:04+00:00

David Freese has decided to decline his induction into the St. Louis Cardinals&rsquo; Hall of Fame

## At least 20 people shot, 1 fatally, at Juneteenth celebration near Chicago
 - [https://abcnews.go.com/US/20-people-shot-1-fatally-juneteenth-celebration-chicago/story?id=100177397](https://abcnews.go.com/US/20-people-shot-1-fatally-juneteenth-celebration-chicago/story?id=100177397)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-06-18 13:40:55+00:00

At least 20 people were shot, one fatally, when gunfire erupted early Sunday at a Juneteenth celebration in a suburban Chicago, authorities said.

## Asa Hutchinson predicts Trump may try to pardon himself if reelected
 - [https://abcnews.go.com/Politics/asa-hutchinson-predicts-trump-pardon-reelected/story?id=100165572](https://abcnews.go.com/Politics/asa-hutchinson-predicts-trump-pardon-reelected/story?id=100165572)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-06-18 13:09:59+00:00

Donald Trump may try to pardon himself in the event he is convicted of criminal charges but also reelected, former Arkansas Gov. Asa Hutchinson said Sunday on "This Week"

## Both sides suffer heavy casualties as Ukraine strikes back against Russia, UK assessment says
 - [https://abcnews.go.com/International/wireStory/sides-suffer-heavy-casualties-ukraine-strikes-back-russia-100176360](https://abcnews.go.com/International/wireStory/sides-suffer-heavy-casualties-ukraine-strikes-back-russia-100176360)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-06-18 12:38:25+00:00

British officials say Russia and Ukraine are suffering high numbers of military casualties as Ukraine fights to dislodge the Kremlin&rsquo;s forces from occupied areas in the early stages of its counteroffensive

## The woman who founded Father's Day was a renegade, great-granddaughter says
 - [https://abcnews.go.com/Lifestyle/wireStory/woman-founded-fathers-day-renegade-great-granddaughter-100177304](https://abcnews.go.com/Lifestyle/wireStory/woman-founded-fathers-day-renegade-great-granddaughter-100177304)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-06-18 12:38:24+00:00

You could call her the mother of Father&rsquo;s Day

## Sudan begins a cease-fire ahead of a pledging conference to raise funds for humanitarian assistance
 - [https://abcnews.go.com/International/wireStory/sudan-begins-cease-fire-ahead-pledging-conference-raise-100176175](https://abcnews.go.com/International/wireStory/sudan-begins-cease-fire-ahead-pledging-conference-raise-100176175)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-06-18 08:54:34+00:00

Sudan&rsquo;s warring parties have begun a cease-fire, as two months of fighting pushed the African nation into further chaos

## 5 injured in shooting at Gorge Amphitheatre campground, sheriff says
 - [https://abcnews.go.com/US/suspect-detained-shooting-gorge-amphitheater-sheriff/story?id=100172563](https://abcnews.go.com/US/suspect-detained-shooting-gorge-amphitheater-sheriff/story?id=100172563)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-06-18 06:09:19+00:00

A suspect was detained in an alleged shooting at a campground near the Gorge Amphitheatre in Washington, the sheriff said.

## South Carolina GOP votes to move back their 2024 primary: Sources
 - [https://abcnews.go.com/Politics/south-carolina-gop-votes-move-back-2024-primary/story?id=100167365](https://abcnews.go.com/Politics/south-carolina-gop-votes-move-back-2024-primary/story?id=100167365)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-06-18 05:03:23+00:00

If approved, the move would put the the first-in-the-South presidential primary state front and center in the race for more than two full weeks.

## West Virginia basketball coach Bob Huggins resigns hours after drunken driving arrest
 - [https://abcnews.go.com/Sports/wireStory/west-virginias-bob-huggins-arrested-suspicion-drunken-driving-100165775](https://abcnews.go.com/Sports/wireStory/west-virginias-bob-huggins-arrested-suspicion-drunken-driving-100165775)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-06-18 04:38:25+00:00

The coach was suspended earlier for controversial comments in interview.

## Suspect arrested after FBI uncovers alleged mass shooting plot
 - [https://abcnews.go.com/US/suspect-arrested-after-fbi-uncovers-alleged-mass-shooting/story?id=100155442](https://abcnews.go.com/US/suspect-arrested-after-fbi-uncovers-alleged-mass-shooting/story?id=100155442)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-06-18 02:08:54+00:00

A suspect who allegedly professed neo-Nazi ideologies online was arrested after federal investigators allege he planned a mass shooting.

## Biden holds 1st reelection rally after rolling out major union endorsements
 - [https://abcnews.go.com/Politics/biden-kick-off-reelection-campaign-rally-after-rolling/story?id=100126268](https://abcnews.go.com/Politics/biden-kick-off-reelection-campaign-rally-after-rolling/story?id=100126268)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-06-18 00:41:34+00:00

President Joe Biden kicked off the first reelection campaign rally in Philadelphia after rolling out major union endorsements.

