# Source:The Wall Street - Tech, URL:https://feeds.a.dj.com/rss/RSSWSJD.xml, language:en-US

## Israel's Netanyahu Touts Expanded Investment by Intel
 - [https://www.wsj.com/articles/israels-netanyahu-touts-expanded-investment-by-intel-amid-tech-backlash-e0bdbfe6?mod=rss_Technology](https://www.wsj.com/articles/israels-netanyahu-touts-expanded-investment-by-intel-amid-tech-backlash-e0bdbfe6?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-06-18 18:53:00+00:00

The prime minister’s announcement comes amid protest from the country’s tech industry over his plan to overhaul Israel’s judiciary.

## The Apple Device You Shouldn't Buy Right Now---and the Ones You Should
 - [https://www.wsj.com/articles/the-apple-device-you-shouldnt-buy-right-nowand-the-ones-you-should-be3d6770?mod=rss_Technology](https://www.wsj.com/articles/the-apple-device-you-shouldnt-buy-right-nowand-the-ones-you-should-be3d6770?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-06-18 09:30:00+00:00

Do not buy an iPhone. MacBook Air? Go for it. A guide to which Apple products are in season.

