# Source:The Washington Post - Tech, URL:https://feeds.washingtonpost.com/rss/business/technology, language:en-US

## ChatGPT might kill us all ... with dad jokes
 - [https://www.washingtonpost.com/technology/2023/06/18/comedians-test-chatgpt-humor/](https://www.washingtonpost.com/technology/2023/06/18/comedians-test-chatgpt-humor/)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-06-18 11:00:28+00:00

San Francisco comedians walk into a bar and tell AI-generated punchlines. Are we laughing with the bots or at them?

