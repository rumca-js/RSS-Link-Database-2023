# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 NEW Unreal Engine 5 Games That BLEW US AWAY [4K]
 - [https://www.youtube.com/watch?v=P7eCylI_Axo](https://www.youtube.com/watch?v=P7eCylI_Axo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2023-06-18 14:34:58+00:00

From upcoming AAA big budget game releases to experimental indie experiences, Unreal Engine 5 is serving up the tools to help developers make great looking games. Here are some examples.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 Intro
0:25 Immortals of Aveum 
2:12 Anime Tokyo 
3:18 Unrecord 
5:51 Project RYU 
6:55 Atlas Fallen 
8:07 Chrono Odyssey 
9:35 Project M 
10:51 S.T.A.L.K.E.R. 2: Heart of Chornobyl  
12:15 Black Myth: Wukong 
13:48 Senua's Saga: Hellblade 2

