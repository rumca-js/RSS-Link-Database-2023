# Source:Techlore, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCs6KfncB4OV6Vug4o_bzijg, language:en-US

## YouTube’s Bizarre Comment C̶e̶n̶s̶o̶r̶s̶h̶i̶p̶ Problem
 - [https://www.youtube.com/watch?v=48ObNiT_hpM](https://www.youtube.com/watch?v=48ObNiT_hpM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCs6KfncB4OV6Vug4o_bzijg
 - date published: 2023-06-18 05:32:46+00:00

We receive countless complaints about comments being deleted, here's an inside-look to how YouTube randomly decides which comments to keep or delete - completely keeping us out of the loop. Join our forum for our own independent platform: https://discuss.techlore.tech

🔐 Our Website: https://techlore.tech
🕵 Go Incognito Course - to learn about privacy: https://techlore.tech/goincognito
🏫 Techlore Coaching - to get direct support: https://techlore.tech/coaching
💻 Techlore Forum - to connect with other advocates: https://discuss.techlore.tech
🦣 Mastodon - to stay updated: https://social.lol/@techlore

We cannot provide our content without our Patrons, huge thanks to:
Afonso, Boori, BRIGHTSIDE, Casper, Clark, Cyclops, Eldarix, JohnnyO, Jon, kevin, Larry, love your content, NotSure, Poaclu, x
🧡 Join them on Patreon: https://www.patreon.com/techlore
💖 Our Other Support Methods: https://techlore.tech/support
#youtube #youtubecomments #techlore

