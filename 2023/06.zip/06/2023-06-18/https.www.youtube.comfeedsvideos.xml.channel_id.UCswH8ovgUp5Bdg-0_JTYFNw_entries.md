# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## WHAT'S REALLY IN THE BOXES?! | Matt Taibbi & Michael Shellenberger On Trump Indictment
 - [https://www.youtube.com/watch?v=uv0SBTV0AzA](https://www.youtube.com/watch?v=uv0SBTV0AzA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2023-06-18 17:00:35+00:00

Here is my conversation with journalists Matt Taibbi and Michael Shellenberger as we discuss President Trump's arraignment. Don't miss our upcoming event on June 22 at Central Hall Westminster. #censorship #trump #tech 

My stand up special is premiering on 25th June! You will love it! Go to https://moment.co/russellbrand

Join Me, Matt & Michael In London HERE: https://www.musicglue.com/good-faith-productions/events/2023-06-22-censorship-industrial-complex-exposed-westminster-central-hall
--------------------------------------------------------------------------------------------------------------------------
WATCH me LIVE weekdays on Rumble: https://bit.ly/russellbrand-rumble

Join Russell Brand Connected over on Locals: https://bit.ly/russellbrand-connected-community

Come COMMUNITY 2023 - https://www.russellbrand.com/community-2023/
NEW MERCH! https://stuff.russellbrand.com/

Keep up to date, Join my mailing list - https://www.russellbrand.com/join-the-community/

## YOU Did WHAT In LOCKDOWN?!? | Russell Brand’s Brandemic | FULL CLIP
 - [https://www.youtube.com/watch?v=lEy6IpAESZo](https://www.youtube.com/watch?v=lEy6IpAESZo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2023-06-18 14:00:34+00:00

That was the clip for my comedy special 'Brandemic'. It will be premiering on 25th June so get the early bird tickets before they are GONE! Pre-order your tickets now at @momentworld or go to https://moment.co/russellbrand

DISCLAIMER: This content is not intended to be offensive. The views expressed are not mine but are used solely for comedic purposes. 
--------------------------------------------------------------------------------------------------------------------------
My stand up special is premiering on 25th June! You will love it! Go to https://moment.co/russellbrand

WATCH me LIVE weekdays on Rumble: https://bit.ly/russellbrand-rumble

Join Russell Brand Connected over on Locals: https://bit.ly/russellbrand-connected-community

Come COMMUNITY 2023 - https://www.russellbrand.com/community-2023/
NEW MERCH! https://stuff.russellbrand.com/

Keep up to date, Join my mailing list - https://www.russellbrand.com/join-the-community/

