# Source:MSN, URL:http://www.msn.com/rss/news.aspx, language:en-US

## Republicans Promising Trump Pardon Are Assuming He's Guilty: GOP Strategist
 - [https://www.msn.com/en-us/news/politics/republicans-promising-trump-pardon-are-assuming-he-s-guilty-gop-strategist/ar-AA1cIMLY?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/republicans-promising-trump-pardon-are-assuming-he-s-guilty-gop-strategist/ar-AA1cIMLY?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 22:58:00.668779+00:00



## Patriots' Jack Jones appeared to criticize Ja Morant's gun drama before NFL player's own weapons arrest
 - [https://www.msn.com/en-us/news/us/patriots-jack-jones-appeared-to-criticize-ja-morant-s-gun-drama-before-nfl-player-s-own-weapons-arrest/ar-AA1cIyTn?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/patriots-jack-jones-appeared-to-criticize-ja-morant-s-gun-drama-before-nfl-player-s-own-weapons-arrest/ar-AA1cIyTn?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 22:58:00.667049+00:00



## Gavin Newsom and wife's recent media blitz spark speculation that Governor could run in 2024
 - [https://www.msn.com/en-us/news/politics/gavin-newsom-and-wife-s-recent-media-blitz-spark-speculation-that-governor-could-run-in-2024/ar-AA1cIr3o?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/gavin-newsom-and-wife-s-recent-media-blitz-spark-speculation-that-governor-could-run-in-2024/ar-AA1cIr3o?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 22:58:00.665714+00:00



## Americans mark Juneteenth with parties, events, quiet reflection on end of slavery after Civil War
 - [https://www.msn.com/en-us/news/us/americans-mark-juneteenth-with-parties-events-quiet-reflection-on-end-of-slavery-after-civil-war/ar-AA1cIAHM?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/americans-mark-juneteenth-with-parties-events-quiet-reflection-on-end-of-slavery-after-civil-war/ar-AA1cIAHM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 22:58:00.664328+00:00



## Hogan: Many 2024 GOP presidential challengers are ‘making excuses’ for Trump
 - [https://www.msn.com/en-us/news/politics/hogan-many-2024-gop-presidential-challengers-are-making-excuses-for-trump/ar-AA1cIDp4?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/hogan-many-2024-gop-presidential-challengers-are-making-excuses-for-trump/ar-AA1cIDp4?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 22:58:00.662453+00:00



## 1 dead, 10 injured in shooting at party in St. Louis office building: Police
 - [https://www.msn.com/en-us/news/crime/1-dead-10-injured-in-shooting-at-party-in-st-louis-office-building-police/ar-AA1cID7o?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/crime/1-dead-10-injured-in-shooting-at-party-in-st-louis-office-building-police/ar-AA1cID7o?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 22:58:00.660436+00:00



## Two survivors of a deadly shipwreck describe their ordeal to Greek authorities
 - [https://www.msn.com/en-us/news/world/two-survivors-of-a-deadly-shipwreck-describe-their-ordeal-to-greek-authorities/ar-AA1cIvpL?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/two-survivors-of-a-deadly-shipwreck-describe-their-ordeal-to-greek-authorities/ar-AA1cIvpL?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 21:42:57.256138+00:00



## Chris Christie says RNC loyalty pledge is a 'useless idea'
 - [https://www.msn.com/en-us/news/politics/chris-christie-says-rnc-loyalty-pledge-is-a-useless-idea/ar-AA1cIom0?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/chris-christie-says-rnc-loyalty-pledge-is-a-useless-idea/ar-AA1cIom0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 21:42:57.254265+00:00



## Houston rapper Big Pokey dead at 45
 - [https://www.msn.com/en-us/news/us/houston-rapper-big-pokey-dead-at-45/ar-AA1cIoq3?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/houston-rapper-big-pokey-dead-at-45/ar-AA1cIoq3?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 21:42:57.252568+00:00



## Juneteenth celebration horror: 23 shot, 1 fatally at Illinois event
 - [https://www.msn.com/en-us/news/crime/juneteenth-celebration-horror-23-shot-1-fatally-at-illinois-event/ar-AA1cHPZX?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/crime/juneteenth-celebration-horror-23-shot-1-fatally-at-illinois-event/ar-AA1cHPZX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 21:42:57.250757+00:00



## Reporter's Notebook: Will the factions among House Republicans stall furthering their agenda?
 - [https://www.msn.com/en-us/news/politics/reporter-s-notebook-will-the-factions-among-house-republicans-stall-furthering-their-agenda/ar-AA1cIlur?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/reporter-s-notebook-will-the-factions-among-house-republicans-stall-furthering-their-agenda/ar-AA1cIlur?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 21:42:57.248684+00:00



## Here’s what’s at stake in Blinken’s trip to China
 - [https://www.msn.com/en-us/news/world/here-s-what-s-at-stake-in-blinken-s-trip-to-china/ar-AA1cIJZf?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/here-s-what-s-at-stake-in-blinken-s-trip-to-china/ar-AA1cIJZf?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 21:42:57.246900+00:00



## FBI, airport fights put DC-area senators in spotlight
 - [https://www.msn.com/en-us/news/politics/fbi-airport-fights-put-dc-area-senators-in-spotlight/ar-AA1cIOME?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/fbi-airport-fights-put-dc-area-senators-in-spotlight/ar-AA1cIOME?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 21:42:57.245089+00:00



## A Utah city violated the First Amendment by denying a drag show permit, federal judge rules, marking an LGBTQ victory
 - [https://www.msn.com/en-us/news/us/a-utah-city-violated-the-first-amendment-by-denying-a-drag-show-permit-federal-judge-rules-marking-an-lgbtq-victory/ar-AA1cIyLJ?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/a-utah-city-violated-the-first-amendment-by-denying-a-drag-show-permit-federal-judge-rules-marking-an-lgbtq-victory/ar-AA1cIyLJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 21:42:57.242704+00:00



## Maryland Gov. Wes Moore says he's 'not scared of the gun lobby' after the NRA sued him over the state's new gun-control law
 - [https://www.msn.com/en-us/news/us/maryland-gov-wes-moore-says-he-s-not-scared-of-the-gun-lobby-after-the-nra-sued-him-over-the-state-s-new-gun-control-law/ar-AA1cIuNR?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/maryland-gov-wes-moore-says-he-s-not-scared-of-the-gun-lobby-after-the-nra-sued-him-over-the-state-s-new-gun-control-law/ar-AA1cIuNR?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 20:30:56.225832+00:00



## Wisconsin GOP Targets The University of Wisconsin In Fight Over Diversity
 - [https://www.msn.com/en-us/news/politics/wisconsin-gop-targets-the-university-of-wisconsin-in-fight-over-diversity/ar-AA1cvyIy?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/wisconsin-gop-targets-the-university-of-wisconsin-in-fight-over-diversity/ar-AA1cvyIy?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 20:30:56.224166+00:00



## Bolton says Trump was a 'collector of things' while in office: 'It was very disturbing'
 - [https://www.msn.com/en-us/news/politics/bolton-says-trump-was-a-collector-of-things-while-in-office-it-was-very-disturbing/ar-AA1cIHd7?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/bolton-says-trump-was-a-collector-of-things-while-in-office-it-was-very-disturbing/ar-AA1cIHd7?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 20:30:56.222351+00:00



## There is so much gun violence in one Mississippi neighborhood that a military base piled up shipping containers to defend itself from stray bullets
 - [https://www.msn.com/en-us/news/us/there-is-so-much-gun-violence-in-one-mississippi-neighborhood-that-a-military-base-piled-up-shipping-containers-to-defend-itself-from-stray-bullets/ar-AA1cICfA?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/there-is-so-much-gun-violence-in-one-mississippi-neighborhood-that-a-military-base-piled-up-shipping-containers-to-defend-itself-from-stray-bullets/ar-AA1cICfA?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 20:30:56.221015+00:00



## Pinball is of the body: Why modern tech can't recreate the world under glass
 - [https://www.msn.com/en-us/news/technology/pinball-is-of-the-body-why-modern-tech-can-t-recreate-the-world-under-glass/ar-AA1cIocQ?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/technology/pinball-is-of-the-body-why-modern-tech-can-t-recreate-the-world-under-glass/ar-AA1cIocQ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 20:30:56.219238+00:00



## Blinken reaps “constructive” talks in Beijing; Xi Jinping meeting remains elusive
 - [https://www.msn.com/en-us/news/world/blinken-reaps-constructive-talks-in-beijing-xi-jinping-meeting-remains-elusive/ar-AA1cIsWb?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/blinken-reaps-constructive-talks-in-beijing-xi-jinping-meeting-remains-elusive/ar-AA1cIsWb?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 20:30:56.217893+00:00



## John Bolton: Intelligence officials ‘failed in many cases’ in not getting classified docs back from Trump
 - [https://www.msn.com/en-us/news/politics/john-bolton-intelligence-officials-failed-in-many-cases-in-not-getting-classified-docs-back-from-trump/ar-AA1cIxVV?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/john-bolton-intelligence-officials-failed-in-many-cases-in-not-getting-classified-docs-back-from-trump/ar-AA1cIxVV?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 20:30:56.216439+00:00



## State trooper killed, another wounded in shootings that left suspect dead
 - [https://www.msn.com/en-us/news/crime/state-trooper-killed-another-wounded-in-shootings-that-left-suspect-dead/ar-AA1cHXnw?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/crime/state-trooper-killed-another-wounded-in-shootings-that-left-suspect-dead/ar-AA1cHXnw?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 20:30:56.214383+00:00



## Jacky Oh Shared a Special Relationship With Her Black Father
 - [https://www.msn.com/en-us/news/us/jacky-oh-shared-a-special-relationship-with-her-black-father/ar-AA1cI8Yc?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/jacky-oh-shared-a-special-relationship-with-her-black-father/ar-AA1cI8Yc?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 19:00:37.908021+00:00



## The US health system is not to blame for the decline in our life expectancy
 - [https://www.msn.com/en-us/health/other/the-us-health-system-is-not-to-blame-for-the-decline-in-our-life-expectancy/ar-AA1cHsMQ?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/health/other/the-us-health-system-is-not-to-blame-for-the-decline-in-our-life-expectancy/ar-AA1cHsMQ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 19:00:37.906149+00:00



## How Biden's debt ceiling concessions screwed over folks who need SNAP
 - [https://www.msn.com/en-us/news/politics/how-biden-s-debt-ceiling-concessions-screwed-over-folks-who-need-snap/ar-AA1cIz5p?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/how-biden-s-debt-ceiling-concessions-screwed-over-folks-who-need-snap/ar-AA1cIz5p?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 19:00:37.904461+00:00



## U.S., China remain at odds on numerous issues as Blinken finishes first day of meetings in Beijing
 - [https://www.msn.com/en-us/news/world/u-s-china-remain-at-odds-on-numerous-issues-as-blinken-finishes-first-day-of-meetings-in-beijing/ar-AA1cImVD?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/u-s-china-remain-at-odds-on-numerous-issues-as-blinken-finishes-first-day-of-meetings-in-beijing/ar-AA1cImVD?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 19:00:37.903187+00:00



## Barr says Trump is a 'troubled man' who lied to the Justice Department and deserves to be prosecuted
 - [https://www.msn.com/en-us/news/politics/barr-says-trump-is-a-troubled-man-who-lied-to-the-justice-department-and-deserves-to-be-prosecuted/ar-AA1cIuyZ?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/barr-says-trump-is-a-troubled-man-who-lied-to-the-justice-department-and-deserves-to-be-prosecuted/ar-AA1cIuyZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 19:00:37.901871+00:00



## Rand Paul says he’s ‘glad’ Blinken making trip to China
 - [https://www.msn.com/en-us/news/politics/rand-paul-says-he-s-glad-blinken-making-trip-to-china/ar-AA1cI8ZU?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/rand-paul-says-he-s-glad-blinken-making-trip-to-china/ar-AA1cI8ZU?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 19:00:37.900549+00:00



## Uganda school attack: 'Gospel songs then screaming'
 - [https://www.msn.com/en-us/news/world/uganda-school-attack-gospel-songs-then-screaming/ar-AA1cI90h?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/uganda-school-attack-gospel-songs-then-screaming/ar-AA1cI90h?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 19:00:37.899089+00:00



## Conor McGregor signs autographs in New York days after rape allegations
 - [https://www.msn.com/en-us/news/us/conor-mcgregor-signs-autographs-in-new-york-days-after-rape-allegations/ar-AA1cIdfl?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/conor-mcgregor-signs-autographs-in-new-york-days-after-rape-allegations/ar-AA1cIdfl?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 19:00:37.896960+00:00



## A majority of Republicans now say same-sex relations are immoral after a year of 'groomer' attacks on the LGBTQ community
 - [https://www.msn.com/en-us/news/politics/a-majority-of-republicans-now-say-same-sex-relations-are-immoral-after-a-year-of-groomer-attacks-on-the-lgbtq-community/ar-AA1cHXBV?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/a-majority-of-republicans-now-say-same-sex-relations-are-immoral-after-a-year-of-groomer-attacks-on-the-lgbtq-community/ar-AA1cHXBV?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 17:45:29.496512+00:00



## Netanyahu says Israel will move ahead on contentious judicial overhaul plan after talks crumble
 - [https://www.msn.com/en-us/news/world/netanyahu-says-israel-will-move-ahead-on-contentious-judicial-overhaul-plan-after-talks-crumble/ar-AA1cI13R?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/netanyahu-says-israel-will-move-ahead-on-contentious-judicial-overhaul-plan-after-talks-crumble/ar-AA1cI13R?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 17:45:29.494620+00:00



## Tim Scott hits back at Obama: 'Truth of my life disproves lies of the radical left'
 - [https://www.msn.com/en-us/news/politics/tim-scott-hits-back-at-obama-truth-of-my-life-disproves-lies-of-the-radical-left/ar-AA1cImjd?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/tim-scott-hits-back-at-obama-truth-of-my-life-disproves-lies-of-the-radical-left/ar-AA1cImjd?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 17:45:29.493287+00:00



## Judge in Trump's federal case has acted like 'Trump advocate in a robe': Whitehouse
 - [https://www.msn.com/en-us/news/politics/judge-in-trump-s-federal-case-has-acted-like-trump-advocate-in-a-robe-whitehouse/ar-AA1cHUz1?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/judge-in-trump-s-federal-case-has-acted-like-trump-advocate-in-a-robe-whitehouse/ar-AA1cHUz1?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 17:45:29.491575+00:00



## Mike Pence Doesn’t Know Who a Mike Pence Supporter Is
 - [https://www.msn.com/en-us/news/politics/mike-pence-doesn-t-know-who-a-mike-pence-supporter-is/ar-AA1cI13q?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/mike-pence-doesn-t-know-who-a-mike-pence-supporter-is/ar-AA1cI13q?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 17:45:29.490107+00:00



## US, China remain at odds on numerous issues as Blinken finishes first day of meetings in Beijing
 - [https://www.msn.com/en-us/news/world/us-china-remain-at-odds-on-numerous-issues-as-blinken-finishes-first-day-of-meetings-in-beijing/ar-AA1cIayZ?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/us-china-remain-at-odds-on-numerous-issues-as-blinken-finishes-first-day-of-meetings-in-beijing/ar-AA1cIayZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 17:45:29.488243+00:00



## Donald Trump could try to pardon himself if re-elected, Asa Hutchinson says
 - [https://www.msn.com/en-us/news/politics/donald-trump-could-try-to-pardon-himself-if-re-elected-asa-hutchinson-says/ar-AA1cIijP?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/donald-trump-could-try-to-pardon-himself-if-re-elected-asa-hutchinson-says/ar-AA1cIijP?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 17:45:29.486344+00:00



## Christie: Blinken China trip ‘a day late and a dollar short’
 - [https://www.msn.com/en-us/news/politics/christie-blinken-china-trip-a-day-late-and-a-dollar-short/ar-AA1cIaCA?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/christie-blinken-china-trip-a-day-late-and-a-dollar-short/ar-AA1cIaCA?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 17:45:29.484293+00:00



## Mike Pence calls Trump indictment 'saddening' and 'divisive,' but won't say if he'd pardon the former president
 - [https://www.msn.com/en-us/news/politics/mike-pence-calls-trump-indictment-saddening-and-divisive-but-won-t-say-if-he-d-pardon-the-former-president/ar-AA1cIePJ?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/mike-pence-calls-trump-indictment-saddening-and-divisive-but-won-t-say-if-he-d-pardon-the-former-president/ar-AA1cIePJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 16:30:23.518428+00:00



## Mike Pence Dodges Question if He'd Pardon Donald Trump
 - [https://www.msn.com/en-us/news/politics/mike-pence-dodges-question-if-he-d-pardon-donald-trump/ar-AA1cIfe8?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/mike-pence-dodges-question-if-he-d-pardon-donald-trump/ar-AA1cIfe8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 16:30:23.517104+00:00



## The Debrief with David Mark: Are Chris Christie’s attacks on Trump effective?
 - [https://www.msn.com/en-us/news/politics/the-debrief-with-david-mark-are-chris-christie-s-attacks-on-trump-effective/ar-AA1cI4E3?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/the-debrief-with-david-mark-are-chris-christie-s-attacks-on-trump-effective/ar-AA1cI4E3?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 16:30:23.515318+00:00



## South Carolina GOP sets Feb. 24 date for first-in-the-South presidential primary
 - [https://www.msn.com/en-us/news/politics/south-carolina-gop-sets-feb-24-date-for-first-in-the-south-presidential-primary/ar-AA1cIf41?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/south-carolina-gop-sets-feb-24-date-for-first-in-the-south-presidential-primary/ar-AA1cIf41?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 16:30:23.513550+00:00



## At least 20 people shot, 1 fatally, at Juneteenth celebration near Chicago
 - [https://www.msn.com/en-us/news/crime/at-least-20-people-shot-1-fatally-at-juneteenth-celebration-near-chicago/ar-AA1cHPZX?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/crime/at-least-20-people-shot-1-fatally-at-juneteenth-celebration-near-chicago/ar-AA1cHPZX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 16:30:23.512201+00:00



## GOP presidential hopefuls criticize Trump: 'He's a petulant child'
 - [https://www.msn.com/en-us/news/politics/gop-presidential-hopefuls-criticize-trump-he-s-a-petulant-child/ar-AA1cI9OJ?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/gop-presidential-hopefuls-criticize-trump-he-s-a-petulant-child/ar-AA1cI9OJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 16:30:23.510369+00:00



## Esper: Trump known as ‘hoarder’ of classified documents
 - [https://www.msn.com/en-us/news/politics/esper-trump-known-as-hoarder-of-classified-documents/ar-AA1cI7G6?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/esper-trump-known-as-hoarder-of-classified-documents/ar-AA1cI7G6?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 16:30:23.508485+00:00



## Mike Pence dodges on Trump conviction, says indictment allegations are 'very serious'
 - [https://www.msn.com/en-us/news/politics/mike-pence-dodges-on-trump-conviction-says-indictment-allegations-are-very-serious/ar-AA1cI9V0?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/mike-pence-dodges-on-trump-conviction-says-indictment-allegations-are-very-serious/ar-AA1cI9V0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 16:30:23.506435+00:00



## Attorney General Garland keeps poker face as firestorm erupts after Trump charges
 - [https://www.msn.com/en-us/news/politics/attorney-general-garland-keeps-poker-face-as-firestorm-erupts-after-trump-charges/ar-AA1cHUFG?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/attorney-general-garland-keeps-poker-face-as-firestorm-erupts-after-trump-charges/ar-AA1cHUFG?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 15:15:14.669519+00:00



## A blind man is suing 3 rail companies after he fell onto the tracks just before a train arrived
 - [https://www.msn.com/en-us/news/world/a-blind-man-is-suing-3-rail-companies-after-he-fell-onto-the-tracks-just-before-a-train-arrived/ar-AA1cHUPm?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/a-blind-man-is-suing-3-rail-companies-after-he-fell-onto-the-tracks-just-before-a-train-arrived/ar-AA1cHUPm?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 15:15:14.667947+00:00



## Asa Hutchinson says charges against Trump are 'serious and disqualifying'
 - [https://www.msn.com/en-us/news/politics/asa-hutchinson-says-charges-against-trump-are-serious-and-disqualifying/ar-AA1cHSiV?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/asa-hutchinson-says-charges-against-trump-are-serious-and-disqualifying/ar-AA1cHSiV?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 15:15:14.665989+00:00



## Michigan man charged with threatening synagogue massacre
 - [https://www.msn.com/en-us/news/crime/michigan-man-charged-with-threatening-synagogue-massacre/ar-AA1cIbFX?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/crime/michigan-man-charged-with-threatening-synagogue-massacre/ar-AA1cIbFX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 15:15:14.663979+00:00



## 4 people killed, dozens injured in chaotic night of mass shootings across the country
 - [https://www.msn.com/en-us/news/crime/4-people-killed-dozens-injured-in-chaotic-night-of-mass-shootings-across-the-country/ar-AA1cHIoN?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/crime/4-people-killed-dozens-injured-in-chaotic-night-of-mass-shootings-across-the-country/ar-AA1cHIoN?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 15:15:14.661887+00:00



## ‘Loser, Loser, Loser’: Chris Christie Doubles Down on Plan to Take Down Trump
 - [https://www.msn.com/en-us/news/politics/loser-loser-loser-chris-christie-doubles-down-on-plan-to-take-down-trump/ar-AA1cI4e1?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/loser-loser-loser-chris-christie-doubles-down-on-plan-to-take-down-trump/ar-AA1cI4e1?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 15:15:14.657402+00:00



## The time for talk is over — i’s time for action on data privacy
 - [https://www.msn.com/en-us/news/technology/the-time-for-talk-is-over-i-s-time-for-action-on-data-privacy/ar-AA1cI74e?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/technology/the-time-for-talk-is-over-i-s-time-for-action-on-data-privacy/ar-AA1cI74e?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 15:15:14.655637+00:00



## L.A. Latinos welcome 42 migrants bused from Texas as 'brothers and sisters'
 - [https://www.msn.com/en-us/news/us/l-a-latinos-welcome-42-migrants-bused-from-texas-as-brothers-and-sisters/ar-AA1cHDu0?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/l-a-latinos-welcome-42-migrants-bused-from-texas-as-brothers-and-sisters/ar-AA1cHDu0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 14:00:13.103075+00:00



## Moody honors out-of-state police officers moving to Florida
 - [https://www.msn.com/en-us/news/us/moody-honors-out-of-state-police-officers-moving-to-florida/ar-AA1cHGek?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/moody-honors-out-of-state-police-officers-moving-to-florida/ar-AA1cHGek?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 14:00:13.101297+00:00



## Zelensky’s Top Adviser Explains How Ukraine Built Trust With the U.S.
 - [https://www.msn.com/en-us/news/world/zelensky-s-top-adviser-explains-how-ukraine-built-trust-with-the-u-s/vi-AA1cI1t0?srcref=rss](https://www.msn.com/en-us/news/world/zelensky-s-top-adviser-explains-how-ukraine-built-trust-with-the-u-s/vi-AA1cI1t0?srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 14:00:13.099493+00:00



## Pence says Trump’s indictment ‘sends a terrible message’ to the world
 - [https://www.msn.com/en-us/news/politics/pence-says-trump-s-indictment-sends-a-terrible-message-to-the-world/ar-AA1cHU8z?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/pence-says-trump-s-indictment-sends-a-terrible-message-to-the-world/ar-AA1cHU8z?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 14:00:13.098098+00:00



## Pence pledges changes to Justice Department if elected
 - [https://www.msn.com/en-us/news/politics/pence-pledges-changes-to-justice-department-if-elected/ar-AA1cHDBk?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/pence-pledges-changes-to-justice-department-if-elected/ar-AA1cHDBk?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 14:00:13.096209+00:00



## Blinken Meets China Counterpart on Delayed Trip to Mend Ties
 - [https://www.msn.com/en-us/news/world/blinken-meets-china-counterpart-on-delayed-trip-to-mend-ties/ar-AA1cGsIC?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/blinken-meets-china-counterpart-on-delayed-trip-to-mend-ties/ar-AA1cGsIC?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 14:00:13.094720+00:00



## Unclear if Trump-appointed judge overseeing federal case can be impartial: Whitehouse
 - [https://www.msn.com/en-us/news/politics/unclear-if-trump-appointed-judge-overseeing-federal-case-can-be-impartial-whitehouse/ar-AA1cHUz1?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/unclear-if-trump-appointed-judge-overseeing-federal-case-can-be-impartial-whitehouse/ar-AA1cHUz1?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 14:00:13.092993+00:00



## A failed US Navy experiment during World War II hinted at how exploding drones would change the battlefield 80 years later
 - [https://www.msn.com/en-us/news/world/a-failed-us-navy-experiment-during-world-war-ii-hinted-at-how-exploding-drones-would-change-the-battlefield-80-years-later/ar-AA1cHUvO?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/a-failed-us-navy-experiment-during-world-war-ii-hinted-at-how-exploding-drones-would-change-the-battlefield-80-years-later/ar-AA1cHUvO?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 14:00:13.091355+00:00



## Volvo CEO Jim Rowan on the Toughest Challenge Facing Automakers
 - [https://www.msn.com/en-us/news/technology/volvo-ceo-jim-rowan-on-the-toughest-challenge-facing-automakers/ar-AA1cHCZd?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/technology/volvo-ceo-jim-rowan-on-the-toughest-challenge-facing-automakers/ar-AA1cHCZd?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 12:45:05.901052+00:00



## After escaping the Taliban, hundreds of Afghans languish in Albania in a prolonged U.S. visa process
 - [https://www.msn.com/en-us/news/world/after-escaping-the-taliban-hundreds-of-afghans-languish-in-albania-in-a-prolonged-u-s-visa-process/ar-AA1cHpWZ?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/after-escaping-the-taliban-hundreds-of-afghans-languish-in-albania-in-a-prolonged-u-s-visa-process/ar-AA1cHpWZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 12:45:05.899235+00:00



## Blinken arrives in China for high-stakes meetings
 - [https://www.msn.com/en-us/news/world/blinken-arrives-in-china-for-high-stakes-meetings/ar-AA1cHTup?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/blinken-arrives-in-china-for-high-stakes-meetings/ar-AA1cHTup?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 12:45:05.897837+00:00



## The Summer My Father Was a Cowboy
 - [https://www.msn.com/en-us/news/us/the-summer-my-father-was-a-cowboy/ar-AA1cHDfN?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/the-summer-my-father-was-a-cowboy/ar-AA1cHDfN?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 12:45:05.896058+00:00



## Despite brand boycotts and backlashes, Pride events see solid corporate support
 - [https://www.msn.com/en-us/news/us/despite-brand-boycotts-and-backlashes-pride-events-see-solid-corporate-support/ar-AA1cHHZD?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/despite-brand-boycotts-and-backlashes-pride-events-see-solid-corporate-support/ar-AA1cHHZD?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 12:45:05.893923+00:00



## McCarthy visit to Orange County highlights GOP focus on immigration and crime
 - [https://www.msn.com/en-us/news/politics/mccarthy-visit-to-orange-county-highlights-gop-focus-on-immigration-and-crime/ar-AA1cHDjS?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/mccarthy-visit-to-orange-county-highlights-gop-focus-on-immigration-and-crime/ar-AA1cHDjS?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 12:45:05.892171+00:00



## France, Germany join forces against migration from Tunisia in wake of latest Mediterranean tragedy
 - [https://www.msn.com/en-us/news/world/france-germany-join-forces-against-migration-from-tunisia-in-wake-of-latest-mediterranean-tragedy/ar-AA1cHFNQ?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/france-germany-join-forces-against-migration-from-tunisia-in-wake-of-latest-mediterranean-tragedy/ar-AA1cHFNQ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 12:45:05.890228+00:00



## Russian Losses Highest Since Peak of Bakhmut Battle Amid Counter—U.K. Intel
 - [https://www.msn.com/en-us/news/world/russian-losses-highest-since-peak-of-bakhmut-battle-amid-counter-u-k-intel/ar-AA1cHOdX?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/russian-losses-highest-since-peak-of-bakhmut-battle-amid-counter-u-k-intel/ar-AA1cHOdX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 11:30:08.883396+00:00



## A psychologist says she broke down in tears when she learned the horrors that 2 castrated Ukrainian soldiers endured, says report
 - [https://www.msn.com/en-us/news/world/a-psychologist-says-she-broke-down-in-tears-when-she-learned-the-horrors-that-2-castrated-ukrainian-soldiers-endured-says-report/ar-AA1cHsKI?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/a-psychologist-says-she-broke-down-in-tears-when-she-learned-the-horrors-that-2-castrated-ukrainian-soldiers-endured-says-report/ar-AA1cHsKI?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 11:30:08.881617+00:00



## Ku Klux Klan Flyers Were Reported In Kentucky Neighborhoods
 - [https://www.msn.com/en-us/news/us/ku-klux-klan-flyers-were-reported-in-kentucky-neighborhoods/ar-AA1cuFhx?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/ku-klux-klan-flyers-were-reported-in-kentucky-neighborhoods/ar-AA1cuFhx?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 11:30:08.879827+00:00



## Republicans blast Virginia Democrats for crime approach ahead of 2023 primary
 - [https://www.msn.com/en-us/news/politics/republicans-blast-virginia-democrats-for-crime-approach-ahead-of-2023-primary/ar-AA1cHMex?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/republicans-blast-virginia-democrats-for-crime-approach-ahead-of-2023-primary/ar-AA1cHMex?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 11:30:08.877642+00:00



## House GOP flirts with Jan. 6 extremism
 - [https://www.msn.com/en-us/news/politics/house-gop-flirts-with-jan-6-extremism/ar-AA1cHJuf?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/house-gop-flirts-with-jan-6-extremism/ar-AA1cHJuf?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 11:30:08.875751+00:00



## This Father’s Day, more dads need to step up and fight for families
 - [https://www.msn.com/en-us/news/politics/this-father-s-day-more-dads-need-to-step-up-and-fight-for-families/ar-AA1cHCLy?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/this-father-s-day-more-dads-need-to-step-up-and-fight-for-families/ar-AA1cHCLy?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 11:30:08.873843+00:00



## Ugandan border town prepares to bury victims of rebel massacre that left 42 dead, mostly students
 - [https://www.msn.com/en-us/news/world/ugandan-border-town-prepares-to-bury-victims-of-rebel-massacre-that-left-42-dead-mostly-students/ar-AA1cHt6J?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/ugandan-border-town-prepares-to-bury-victims-of-rebel-massacre-that-left-42-dead-mostly-students/ar-AA1cHt6J?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 11:30:08.871618+00:00



## Blinken Meets Chinese Counterpart on Delayed Trip to Mend Ties
 - [https://www.msn.com/en-us/news/world/blinken-meets-chinese-counterpart-on-delayed-trip-to-mend-ties/ar-AA1cGsIC?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/blinken-meets-chinese-counterpart-on-delayed-trip-to-mend-ties/ar-AA1cGsIC?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 10:14:54.652552+00:00



## Tim Scott's run for president complicates Senate Republican agenda
 - [https://www.msn.com/en-us/news/politics/tim-scott-s-run-for-president-complicates-senate-republican-agenda/ar-AA1cHAaj?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/tim-scott-s-run-for-president-complicates-senate-republican-agenda/ar-AA1cHAaj?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 10:14:54.651192+00:00



## What Is Micro-OLED? Apple Vision Pro's Display Explained
 - [https://www.msn.com/en-us/news/technology/what-is-micro-oled-apple-vision-pro-s-display-explained/ar-AA1cxnjd?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/technology/what-is-micro-oled-apple-vision-pro-s-display-explained/ar-AA1cxnjd?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 10:14:54.648994+00:00



## Arnold Schwarzenegger says he'd 'so clearly' be elected president if he could run: 'It's a no-brainer'
 - [https://www.msn.com/en-us/news/politics/arnold-schwarzenegger-says-he-d-so-clearly-be-elected-president-if-he-could-run-it-s-a-no-brainer/ar-AA1cHH5U?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/arnold-schwarzenegger-says-he-d-so-clearly-be-elected-president-if-he-could-run-it-s-a-no-brainer/ar-AA1cHH5U?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 10:14:54.647190+00:00



## Multiple casualties in Illinois shooting: reports
 - [https://www.msn.com/en-us/news/crime/multiple-casualties-in-illinois-shooting-reports/ar-AA1cHJ2y?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/crime/multiple-casualties-in-illinois-shooting-reports/ar-AA1cHJ2y?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 10:14:54.645432+00:00



## Both sides suffer heavy casualties as Ukraine strikes back against Russia, UK assessment says
 - [https://www.msn.com/en-us/news/world/both-sides-suffer-heavy-casualties-as-ukraine-strikes-back-against-russia-uk-assessment-says/ar-AA1cHsm6?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/both-sides-suffer-heavy-casualties-as-ukraine-strikes-back-against-russia-uk-assessment-says/ar-AA1cHsm6?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 10:14:54.644025+00:00



## Reporter's notebook: Stories of survival and heartbreak in Perryton, Texas
 - [https://www.msn.com/en-us/news/crime/reporter-s-notebook-stories-of-survival-and-heartbreak-in-perryton-texas/ar-AA1cGJpJ?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/crime/reporter-s-notebook-stories-of-survival-and-heartbreak-in-perryton-texas/ar-AA1cGJpJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 10:14:54.642114+00:00



## The Memo: Barr, Bolton, Kelly line up to condemn Trump over alleged crimes
 - [https://www.msn.com/en-us/news/politics/the-memo-barr-bolton-kelly-line-up-to-condemn-trump-over-alleged-crimes/ar-AA1cHHb7?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/the-memo-barr-bolton-kelly-line-up-to-condemn-trump-over-alleged-crimes/ar-AA1cHHb7?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 10:14:54.639708+00:00



## Beyond Wonderland Shooting Leaves Two Dead, More Injured at EDM Festival
 - [https://www.msn.com/en-us/news/crime/beyond-wonderland-shooting-leaves-two-dead-more-injured-at-edm-festival/ar-AA1cHmQi?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/crime/beyond-wonderland-shooting-leaves-two-dead-more-injured-at-edm-festival/ar-AA1cHmQi?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 08:59:51.363729+00:00



## Sudan begins a cease-fire ahead of a pledging conference to raise funds for humanitarian assistance
 - [https://www.msn.com/en-us/news/world/sudan-begins-a-cease-fire-ahead-of-a-pledging-conference-to-raise-funds-for-humanitarian-assistance/ar-AA1cHBDb?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/sudan-begins-a-cease-fire-ahead-of-a-pledging-conference-to-raise-funds-for-humanitarian-assistance/ar-AA1cHBDb?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 08:59:51.361634+00:00



## Anna Sorokin gets testy in first TV interview since release from prison with Chris Cuomo
 - [https://www.msn.com/en-us/news/crime/anna-sorokin-gets-testy-in-first-tv-interview-since-release-from-prison-with-chris-cuomo/ar-AA1cHw5o?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/crime/anna-sorokin-gets-testy-in-first-tv-interview-since-release-from-prison-with-chris-cuomo/ar-AA1cHw5o?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 07:44:47.289043+00:00



## Congress aims to strip 'Trojan horse' Chinese drones from all levels of government
 - [https://www.msn.com/en-us/news/politics/congress-aims-to-strip-trojan-horse-chinese-drones-from-all-levels-of-government/ar-AA1cHtWh?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/congress-aims-to-strip-trojan-horse-chinese-drones-from-all-levels-of-government/ar-AA1cHtWh?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 07:44:47.287211+00:00



## Evidence suggests the Ukrainian dam collapsed due to a controlled explosion set off inside the structure. An international investigative group says it's 'highly likely' Russian forces were behind the attack.
 - [https://www.msn.com/en-us/news/world/evidence-suggests-the-ukrainian-dam-collapsed-due-to-a-controlled-explosion-set-off-inside-the-structure-an-international-investigative-group-says-it-s-highly-likely-russian-forces-were-behind-the-attack/ar-AA1cHtJc?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/evidence-suggests-the-ukrainian-dam-collapsed-due-to-a-controlled-explosion-set-off-inside-the-structure-an-international-investigative-group-says-it-s-highly-likely-russian-forces-were-behind-the-attack/ar-AA1cHtJc?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 07:44:47.285322+00:00



## 2 dead in shooting at Gorge Amphitheatre campground, sheriff says
 - [https://www.msn.com/en-us/news/world/2-dead-in-shooting-at-gorge-amphitheatre-campground-sheriff-says/ar-AA1cH8ev?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/2-dead-in-shooting-at-gorge-amphitheatre-campground-sheriff-says/ar-AA1cH8ev?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 07:44:47.281438+00:00



## Belarus crackdown targets not just political activists but also their lawyers
 - [https://www.msn.com/en-us/news/world/belarus-crackdown-targets-not-just-political-activists-but-also-their-lawyers/ar-AA1cHhFP?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/belarus-crackdown-targets-not-just-political-activists-but-also-their-lawyers/ar-AA1cHhFP?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 07:44:47.278971+00:00



## Jordan Neely Family Reacts to Daniel Penny Indictment
 - [https://www.msn.com/en-us/news/crime/jordan-neely-family-reacts-to-daniel-penny-indictment/ar-AA1b7o6q?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/crime/jordan-neely-family-reacts-to-daniel-penny-indictment/ar-AA1b7o6q?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 06:30:41.564323+00:00



## Why SCOTUS’ Shock Voting Rights Call May Be Window Dressing
 - [https://www.msn.com/en-us/news/politics/why-scotus-shock-voting-rights-call-may-be-window-dressing/ar-AA1cHeen?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/why-scotus-shock-voting-rights-call-may-be-window-dressing/ar-AA1cHeen?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 06:30:41.562525+00:00



## George Conway says there is a ‘substantial possibility’ Trump will go to jail
 - [https://www.msn.com/en-us/news/politics/george-conway-says-there-is-a-substantial-possibility-trump-will-go-to-jail/ar-AA1cGNvD?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/george-conway-says-there-is-a-substantial-possibility-trump-will-go-to-jail/ar-AA1cGNvD?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 06:30:41.560756+00:00



## The American dream needs married fathers
 - [https://www.msn.com/en-us/news/us/the-american-dream-needs-married-fathers/ar-AA1cGQbW?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/the-american-dream-needs-married-fathers/ar-AA1cGQbW?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 06:30:41.558866+00:00



## Ted Cruz demands Joe Biden reveal the source of his $10M income in 2017
 - [https://www.msn.com/en-us/news/politics/ted-cruz-demands-joe-biden-reveal-the-source-of-his-10m-income-in-2017/ar-AA1cHgLW?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/ted-cruz-demands-joe-biden-reveal-the-source-of-his-10m-income-in-2017/ar-AA1cHgLW?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 06:30:41.556778+00:00



## Cruising to Nome: The first U.S. deep water port for the Arctic to host cruise ships, military
 - [https://www.msn.com/en-us/news/us/cruising-to-nome-the-first-u-s-deep-water-port-for-the-arctic-to-host-cruise-ships-military/ar-AA1cH5mz?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/cruising-to-nome-the-first-u-s-deep-water-port-for-the-arctic-to-host-cruise-ships-military/ar-AA1cH5mz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 06:30:41.554612+00:00



## How a George Floyd protest birthed the radical wellness community of WalkGood LA
 - [https://www.msn.com/en-us/news/crime/how-a-george-floyd-protest-birthed-the-radical-wellness-community-of-walkgood-la/ar-AA1cHade?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/crime/how-a-george-floyd-protest-birthed-the-radical-wellness-community-of-walkgood-la/ar-AA1cHade?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 06:30:41.552779+00:00



## 5 injured in shooting at Gorge Amphitheatre campground, sheriff says
 - [https://www.msn.com/en-us/news/world/5-injured-in-shooting-at-gorge-amphitheatre-campground-sheriff-says/ar-AA1cH8ev?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/5-injured-in-shooting-at-gorge-amphitheatre-campground-sheriff-says/ar-AA1cH8ev?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 06:30:41.551192+00:00



## ‘Professional Boxer’ Puts Wagner Mercenary in a Coma
 - [https://www.msn.com/en-us/news/world/professional-boxer-puts-wagner-mercenary-in-a-coma/ar-AA1cGZ5H?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/professional-boxer-puts-wagner-mercenary-in-a-coma/ar-AA1cGZ5H?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 01:33:36.852495+00:00



## After bitter warnings, the U.S. and China are trying to ease hostilities
 - [https://www.msn.com/en-us/news/world/after-bitter-warnings-the-u-s-and-china-are-trying-to-ease-hostilities/ar-AA1cGMR0?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/after-bitter-warnings-the-u-s-and-china-are-trying-to-ease-hostilities/ar-AA1cGMR0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 01:33:36.850339+00:00



## Nikki Haley’s husband begins Africa deployment as she campaigns for 2024 GOP nomination
 - [https://www.msn.com/en-us/news/politics/nikki-haley-s-husband-begins-africa-deployment-as-she-campaigns-for-2024-gop-nomination/ar-AA1cGPiP?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/nikki-haley-s-husband-begins-africa-deployment-as-she-campaigns-for-2024-gop-nomination/ar-AA1cGPiP?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 01:33:36.848146+00:00



## Biden holds 1st reelection rally after rolling out major union endorsements
 - [https://www.msn.com/en-us/news/politics/biden-holds-1st-reelection-rally-after-rolling-out-major-union-endorsements/ar-AA1cGdYA?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/biden-holds-1st-reelection-rally-after-rolling-out-major-union-endorsements/ar-AA1cGdYA?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 01:33:36.845376+00:00



## African leaders issue plea to Putin: ‘We would like this war to be ended’
 - [https://www.msn.com/en-us/news/world/african-leaders-issue-plea-to-putin-we-would-like-this-war-to-be-ended/ar-AA1cGUgE?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/african-leaders-issue-plea-to-putin-we-would-like-this-war-to-be-ended/ar-AA1cGUgE?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 01:33:36.842230+00:00



## Ron DeSantis leverages his Covid response for a foothold in Nevada
 - [https://www.msn.com/en-us/news/politics/ron-desantis-leverages-his-covid-response-for-a-foothold-in-nevada/ar-AA1cH48X?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/ron-desantis-leverages-his-covid-response-for-a-foothold-in-nevada/ar-AA1cH48X?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 01:33:36.838966+00:00



## Utah city violated the 1st Amendment in denying a drag show permit, judge rules
 - [https://www.msn.com/en-us/news/us/utah-city-violated-the-1st-amendment-in-denying-a-drag-show-permit-judge-rules/ar-AA1cGW6O?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/utah-city-violated-the-1st-amendment-in-denying-a-drag-show-permit-judge-rules/ar-AA1cGW6O?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 00:17:17.153007+00:00



## Man Who Mysteriously Vanished After Calling 911 Is Found Dead in Marsh
 - [https://www.msn.com/en-us/news/crime/man-who-mysteriously-vanished-after-calling-911-is-found-dead-in-marsh/ar-AA1cGOMZ?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/crime/man-who-mysteriously-vanished-after-calling-911-is-found-dead-in-marsh/ar-AA1cGOMZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 00:17:17.151650+00:00



## Amid a slow start, Biden hits 2024 campaign trail with a nod to labor support
 - [https://www.msn.com/en-us/news/politics/amid-a-slow-start-biden-hits-2024-campaign-trail-with-a-nod-to-labor-support/ar-AA1cGMsV?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/amid-a-slow-start-biden-hits-2024-campaign-trail-with-a-nod-to-labor-support/ar-AA1cGMsV?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 00:17:17.149859+00:00



## Sam Pang confirmed as host of 2023 Logie Awards
 - [https://www.msn.com/en-us/news/world/sam-pang-confirmed-as-host-of-2023-logie-awards/ar-AA1cGMBV?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/sam-pang-confirmed-as-host-of-2023-logie-awards/ar-AA1cGMBV?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 00:17:17.148557+00:00



## Blinken Lands in China on Delayed Mission to Stabilize Ties
 - [https://www.msn.com/en-us/news/world/blinken-lands-in-china-on-delayed-mission-to-stabilize-ties/ar-AA1cGsIC?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/world/blinken-lands-in-china-on-delayed-mission-to-stabilize-ties/ar-AA1cGsIC?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 00:17:17.147199+00:00



## Remembering the Mother Emanuel Nine eight years after Charleston mass shooting
 - [https://www.msn.com/en-us/news/us/remembering-the-mother-emanuel-nine-eight-years-after-charleston-mass-shooting/ar-AA1cGYVj?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/remembering-the-mother-emanuel-nine-eight-years-after-charleston-mass-shooting/ar-AA1cGYVj?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-06-18 00:17:17.145517+00:00



