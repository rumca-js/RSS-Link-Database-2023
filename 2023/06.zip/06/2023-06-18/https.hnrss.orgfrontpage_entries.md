# Source:Hacker News - frontpage, URL:https://hnrss.org/frontpage, language:en-US

## The Linux Kernel has jiffies
 - [https://github.com/torvalds/linux/blob/45a3e24f65e90a047bef86f927ebdc4c710edaa1/kernel/time/jiffies.c](https://github.com/torvalds/linux/blob/45a3e24f65e90a047bef86f927ebdc4c710edaa1/kernel/time/jiffies.c)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 22:25:10+00:00

<p>Article URL: <a href="https://github.com/torvalds/linux/blob/45a3e24f65e90a047bef86f927ebdc4c710edaa1/kernel/time/jiffies.c">https://github.com/torvalds/linux/blob/45a3e24f65e90a047bef86f927ebdc4c710edaa1/kernel/time/jiffies.c</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36385163">https://news.ycombinator.com/item?id=36385163</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## ChatGPT, Google Bard Generates Generic Windows 11, Windows 10 Pro Keys
 - [https://www.tomshardware.com/news/chatgpt-generates-windows-11-pro-keys](https://www.tomshardware.com/news/chatgpt-generates-windows-11-pro-keys)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 22:07:39+00:00

<p>Article URL: <a href="https://www.tomshardware.com/news/chatgpt-generates-windows-11-pro-keys">https://www.tomshardware.com/news/chatgpt-generates-windows-11-pro-keys</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36385032">https://news.ycombinator.com/item?id=36385032</a></p>
<p>Points: 18</p>
<p># Comments: 5</p>

## Keycloak – Open-Source Identity and Access Management Interview
 - [https://console.substack.com/i/128451029/interview-with-michal-of-keycloak-open-source-identity-and-access-management-for-modern-applications](https://console.substack.com/i/128451029/interview-with-michal-of-keycloak-open-source-identity-and-access-management-for-modern-applications)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 21:23:02+00:00

<p>Article URL: <a href="https://console.substack.com/i/128451029/interview-with-michal-of-keycloak-open-source-identity-and-access-management-for-modern-applications">https://console.substack.com/i/128451029/interview-with-michal-of-keycloak-open-source-identity-and-access-management-for-modern-applications</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36384636">https://news.ycombinator.com/item?id=36384636</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## Sponge spicule
 - [https://en.wikipedia.org/wiki/Sponge_spicule](https://en.wikipedia.org/wiki/Sponge_spicule)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 21:16:15+00:00

<p>Article URL: <a href="https://en.wikipedia.org/wiki/Sponge_spicule">https://en.wikipedia.org/wiki/Sponge_spicule</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36384570">https://news.ycombinator.com/item?id=36384570</a></p>
<p>Points: 10</p>
<p># Comments: 0</p>

## Soviet Union sold titanium to US believing they needed it for pizza ovens
 - [https://theaviationgeekclub.com/in-the-early-1960s-soviet-union-sold-titanium-to-the-us-believing-they-needed-it-for-pizza-ovens-but-instead-they-used-it-to-build-the-iconic-sr-71-blackbird-mach-3-spy-plane/](https://theaviationgeekclub.com/in-the-early-1960s-soviet-union-sold-titanium-to-the-us-believing-they-needed-it-for-pizza-ovens-but-instead-they-used-it-to-build-the-iconic-sr-71-blackbird-mach-3-spy-plane/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 21:13:42+00:00

<p>Article URL: <a href="https://theaviationgeekclub.com/in-the-early-1960s-soviet-union-sold-titanium-to-the-us-believing-they-needed-it-for-pizza-ovens-but-instead-they-used-it-to-build-the-iconic-sr-71-blackbird-mach-3-spy-plane/">https://theaviationgeekclub.com/in-the-early-1960s-soviet-union-sold-titanium-to-the-us-believing-they-needed-it-for-pizza-ovens-but-instead-they-used-it-to-build-the-iconic-sr-71-blackbird-mach-3-spy-plane/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36384548">https://news.ycombinator.com/item?id=36384548</a></p>
<p>Points: 40</p>
<p># Comments: 11</p>

## Scalene: A high-performance, CPU, GPU, and memory profiler for Python
 - [https://github.com/plasma-umass/scalene](https://github.com/plasma-umass/scalene)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 20:35:23+00:00

<p>Article URL: <a href="https://github.com/plasma-umass/scalene">https://github.com/plasma-umass/scalene</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36384185">https://news.ycombinator.com/item?id=36384185</a></p>
<p>Points: 11</p>
<p># Comments: 3</p>

## Redbean Systems
 - [https://redbean.systems/](https://redbean.systems/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 20:02:54+00:00

<p>Article URL: <a href="https://redbean.systems/">https://redbean.systems/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36383875">https://news.ycombinator.com/item?id=36383875</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## Show HN: Answer Overflow  – Indexing Discord content into the web
 - [https://www.answeroverflow.com/](https://www.answeroverflow.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 19:50:46+00:00

<p>Hi!<p>I'm Rhys, I develop Answer Overflow a search engine for Discord channels. Answer Overflow indexes content from channels into Google making them discoverable on the web.<p>I'm sharing this again after seeing a lot of discussion during the Reddit blackout about the inaccessibility of information sent in Discord servers.<p>Answer Overflow is a verified bot in over 100 communities, fully complies with the Discord ToS, and is open source! <a href="https://github.com/AnswerOverflow/AnswerOverflow">https://github.com/AnswerOverflow/AnswerOverflow</a><p>Check out some of the communities here!<p>T3 Community - <a href="https://www.answeroverflow.com/c/966627436387266600" rel="nofollow noreferrer">https://www.answeroverflow.com/c/966627436387266600</a><p>C# - <a href="https://www.answeroverflow.com/c/143867839282020352" rel="nofollow noreferrer">https://www.answeroverflow.com/c/143867839282020352</a><p>Reactiflux - <a href="https://www.answeroverflow.com/c/143867839282020352" rel="nofollow noreferrer">https://www.answeroverflow.com/c/143867839282020352</a><p>All - <a href="https://www.answeroverflow.com/browse" rel="nofollow noreferrer">https://www.answeroverflow.com/browse</a><p>Please let me know what feedback you have, thanks for checking it out!</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36383773">https://news.ycombinator.com/item?id=36383773</a></p>
<p>Points: 45</p>
<p># Comments: 3</p>

## Spectral Contexts in Go
 - [https://hypirion.com/musings/spectral-contexts-in-go](https://hypirion.com/musings/spectral-contexts-in-go)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 19:32:57+00:00

<p>Article URL: <a href="https://hypirion.com/musings/spectral-contexts-in-go">https://hypirion.com/musings/spectral-contexts-in-go</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36383571">https://news.ycombinator.com/item?id=36383571</a></p>
<p>Points: 12</p>
<p># Comments: 5</p>

## Linguists have identified a new English dialect that’s emerging in South Florida
 - [https://theconversation.com/linguists-have-identified-a-new-english-dialect-thats-emerging-in-south-florida-205620](https://theconversation.com/linguists-have-identified-a-new-english-dialect-thats-emerging-in-south-florida-205620)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 19:28:37+00:00

<p>Article URL: <a href="https://theconversation.com/linguists-have-identified-a-new-english-dialect-thats-emerging-in-south-florida-205620">https://theconversation.com/linguists-have-identified-a-new-english-dialect-thats-emerging-in-south-florida-205620</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36383521">https://news.ycombinator.com/item?id=36383521</a></p>
<p>Points: 16</p>
<p># Comments: 1</p>

## Get It Done
 - [https://boz.com/articles/get-it-done](https://boz.com/articles/get-it-done)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 19:10:24+00:00

<p>Article URL: <a href="https://boz.com/articles/get-it-done">https://boz.com/articles/get-it-done</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36383322">https://news.ycombinator.com/item?id=36383322</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## LLM Fine Tuning Guide for Enterprises in 2023
 - [https://research.aimultiple.com/llm-fine-tuning/](https://research.aimultiple.com/llm-fine-tuning/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 19:07:47+00:00

<p>Article URL: <a href="https://research.aimultiple.com/llm-fine-tuning/">https://research.aimultiple.com/llm-fine-tuning/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36383298">https://news.ycombinator.com/item?id=36383298</a></p>
<p>Points: 23</p>
<p># Comments: 2</p>

## Does Lemmy benefit from Rust? Is code execution speed the bottleneck?
 - [https://programming.dev/post/50696](https://programming.dev/post/50696)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 18:48:51+00:00

<p>Article URL: <a href="https://programming.dev/post/50696">https://programming.dev/post/50696</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36383120">https://news.ycombinator.com/item?id=36383120</a></p>
<p>Points: 15</p>
<p># Comments: 4</p>

## The WFH Future Is Destroying Bosses' Brains
 - [https://wheresyoured.at/p/the-work-from-home-future-is-destroying](https://wheresyoured.at/p/the-work-from-home-future-is-destroying)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 18:38:16+00:00

<p>Article URL: <a href="https://wheresyoured.at/p/the-work-from-home-future-is-destroying">https://wheresyoured.at/p/the-work-from-home-future-is-destroying</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36382994">https://news.ycombinator.com/item?id=36382994</a></p>
<p>Points: 147</p>
<p># Comments: 133</p>

## Swing VPN app is a DDoS botnet
 - [https://lecromee.github.io/posts/swing_vpn_ddosing_sites/](https://lecromee.github.io/posts/swing_vpn_ddosing_sites/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 18:09:37+00:00

<p>Article URL: <a href="https://lecromee.github.io/posts/swing_vpn_ddosing_sites/">https://lecromee.github.io/posts/swing_vpn_ddosing_sites/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36382700">https://news.ycombinator.com/item?id=36382700</a></p>
<p>Points: 66</p>
<p># Comments: 2</p>

## I left the startup I founded. This is how I feel
 - [https://www.aquiles.me/how-it-feels-quitting-your-own-startup/](https://www.aquiles.me/how-it-feels-quitting-your-own-startup/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 17:55:23+00:00

<p>Article URL: <a href="https://www.aquiles.me/how-it-feels-quitting-your-own-startup/">https://www.aquiles.me/how-it-feels-quitting-your-own-startup/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36382578">https://news.ycombinator.com/item?id=36382578</a></p>
<p>Points: 32</p>
<p># Comments: 8</p>

## Off-Path Network Traffic Manipulation via Revitalized ICMP Redirect Attacks [pdf]
 - [https://www.usenix.org/system/files/sec22-feng.pdf](https://www.usenix.org/system/files/sec22-feng.pdf)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 17:49:56+00:00

<p>Article URL: <a href="https://www.usenix.org/system/files/sec22-feng.pdf">https://www.usenix.org/system/files/sec22-feng.pdf</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36382514">https://news.ycombinator.com/item?id=36382514</a></p>
<p>Points: 10</p>
<p># Comments: 1</p>

## Examples of Post-Growth Practices
 - [https://postgrowthguide.notion.site/20-cases-of-Post-Growth-Practices-dd67efd4c7304df7b6a5ed59cab4ac8e](https://postgrowthguide.notion.site/20-cases-of-Post-Growth-Practices-dd67efd4c7304df7b6a5ed59cab4ac8e)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 17:44:34+00:00

<p>Article URL: <a href="https://postgrowthguide.notion.site/20-cases-of-Post-Growth-Practices-dd67efd4c7304df7b6a5ed59cab4ac8e">https://postgrowthguide.notion.site/20-cases-of-Post-Growth-Practices-dd67efd4c7304df7b6a5ed59cab4ac8e</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36382462">https://news.ycombinator.com/item?id=36382462</a></p>
<p>Points: 6</p>
<p># Comments: 2</p>

## Our security auditor is an idiot. How do I give him the info he wants? (2011)
 - [https://serverfault.com/questions/293217/our-security-auditor-is-an-idiot-how-do-i-give-him-the-information-he-wants](https://serverfault.com/questions/293217/our-security-auditor-is-an-idiot-how-do-i-give-him-the-information-he-wants)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 17:44:11+00:00

<p>Article URL: <a href="https://serverfault.com/questions/293217/our-security-auditor-is-an-idiot-how-do-i-give-him-the-information-he-wants">https://serverfault.com/questions/293217/our-security-auditor-is-an-idiot-how-do-i-give-him-the-information-he-wants</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36382456">https://news.ycombinator.com/item?id=36382456</a></p>
<p>Points: 73</p>
<p># Comments: 9</p>

## Goodbye, Twilio
 - [https://blog.miguelgrinberg.com/post/goodbye-twilio](https://blog.miguelgrinberg.com/post/goodbye-twilio)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 17:34:01+00:00

<p>Article URL: <a href="https://blog.miguelgrinberg.com/post/goodbye-twilio">https://blog.miguelgrinberg.com/post/goodbye-twilio</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36382361">https://news.ycombinator.com/item?id=36382361</a></p>
<p>Points: 74</p>
<p># Comments: 17</p>

## Apple Earthquake Survival Kit 1986
 - [https://archive.org/details/apple-earthquake-survival-kit-1986](https://archive.org/details/apple-earthquake-survival-kit-1986)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 17:20:32+00:00

<p>Article URL: <a href="https://archive.org/details/apple-earthquake-survival-kit-1986">https://archive.org/details/apple-earthquake-survival-kit-1986</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36382244">https://news.ycombinator.com/item?id=36382244</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## Migrating Netflix to GraphQL Safely
 - [https://netflixtechblog.com/migrating-netflix-to-graphql-safely-8e1e4d4f1e72?gi=4217a3fd9c5c](https://netflixtechblog.com/migrating-netflix-to-graphql-safely-8e1e4d4f1e72?gi=4217a3fd9c5c)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 16:33:22+00:00

<p>Article URL: <a href="https://netflixtechblog.com/migrating-netflix-to-graphql-safely-8e1e4d4f1e72?gi=4217a3fd9c5c">https://netflixtechblog.com/migrating-netflix-to-graphql-safely-8e1e4d4f1e72?gi=4217a3fd9c5c</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36381764">https://news.ycombinator.com/item?id=36381764</a></p>
<p>Points: 30</p>
<p># Comments: 6</p>

## Texas rules requiring water breaks for construction workers will be nullified
 - [https://www.texastribune.org/2023/06/16/texas-heat-wave-water-break-construction-workers/](https://www.texastribune.org/2023/06/16/texas-heat-wave-water-break-construction-workers/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 16:14:52+00:00

<p>Article URL: <a href="https://www.texastribune.org/2023/06/16/texas-heat-wave-water-break-construction-workers/">https://www.texastribune.org/2023/06/16/texas-heat-wave-water-break-construction-workers/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36381556">https://news.ycombinator.com/item?id=36381556</a></p>
<p>Points: 39</p>
<p># Comments: 24</p>

## The Israeli weapons and spyware falling into the hands of despots
 - [https://www.ft.com/content/a70a4460-0267-4a8a-8612-a6f6c187a3c6](https://www.ft.com/content/a70a4460-0267-4a8a-8612-a6f6c187a3c6)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 15:53:55+00:00

<p>Article URL: <a href="https://www.ft.com/content/a70a4460-0267-4a8a-8612-a6f6c187a3c6">https://www.ft.com/content/a70a4460-0267-4a8a-8612-a6f6c187a3c6</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36381358">https://news.ycombinator.com/item?id=36381358</a></p>
<p>Points: 28</p>
<p># Comments: 11</p>

## Archives.design: curated graphic design from Internet Archive
 - [https://archives.design](https://archives.design)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 15:51:18+00:00

<p>Article URL: <a href="https://archives.design">https://archives.design</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36381330">https://news.ycombinator.com/item?id=36381330</a></p>
<p>Points: 13</p>
<p># Comments: 3</p>

## Ask HN: Would more people take public transportation if it had business class?
 - [https://news.ycombinator.com/item?id=36381223](https://news.ycombinator.com/item?id=36381223)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 15:39:44+00:00

<p>Why do airplanes have multiple classes but not public transportation?</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36381223">https://news.ycombinator.com/item?id=36381223</a></p>
<p>Points: 19</p>
<p># Comments: 33</p>

## Gas Stoves Emit Benzene and Increases Indoor Air Pollution
 - [https://pubs.acs.org/doi/10.1021/acs.est.2c09289](https://pubs.acs.org/doi/10.1021/acs.est.2c09289)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 15:35:33+00:00

<p>Article URL: <a href="https://pubs.acs.org/doi/10.1021/acs.est.2c09289">https://pubs.acs.org/doi/10.1021/acs.est.2c09289#</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36381189">https://news.ycombinator.com/item?id=36381189</a></p>
<p>Points: 24</p>
<p># Comments: 8</p>

## AzireVPN now supports port-forwarding (WireGuard)
 - [https://blog.azirevpn.com/port-forwarding/](https://blog.azirevpn.com/port-forwarding/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 15:34:47+00:00

<p>Article URL: <a href="https://blog.azirevpn.com/port-forwarding/">https://blog.azirevpn.com/port-forwarding/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36381181">https://news.ycombinator.com/item?id=36381181</a></p>
<p>Points: 9</p>
<p># Comments: 5</p>

## Hexa Lift: Single person drone
 - [https://www.liftaircraft.com](https://www.liftaircraft.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 15:34:32+00:00

<p>Article URL: <a href="https://www.liftaircraft.com">https://www.liftaircraft.com</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36381177">https://news.ycombinator.com/item?id=36381177</a></p>
<p>Points: 5</p>
<p># Comments: 5</p>

## OpenLLaMA 13B Released
 - [https://huggingface.co/openlm-research/open_llama_13b](https://huggingface.co/openlm-research/open_llama_13b)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 15:29:02+00:00

<p>Article URL: <a href="https://huggingface.co/openlm-research/open_llama_13b">https://huggingface.co/openlm-research/open_llama_13b</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36381136">https://news.ycombinator.com/item?id=36381136</a></p>
<p>Points: 12</p>
<p># Comments: 7</p>

## JavaScript modifying cut and paste can sometimes be a good thing in browsers
 - [https://utcc.utoronto.ca/~cks/space/blog/web/BrowserSmartCutPasteCanBeGood](https://utcc.utoronto.ca/~cks/space/blog/web/BrowserSmartCutPasteCanBeGood)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 15:19:12+00:00

<p>Article URL: <a href="https://utcc.utoronto.ca/~cks/space/blog/web/BrowserSmartCutPasteCanBeGood">https://utcc.utoronto.ca/~cks/space/blog/web/BrowserSmartCutPasteCanBeGood</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36381054">https://news.ycombinator.com/item?id=36381054</a></p>
<p>Points: 15</p>
<p># Comments: 11</p>

## Imaginary Problems Are the Root of Bad Software
 - [https://cerebralab.com/Imaginary_Problems_Are_the_Root_of_Bad_Software](https://cerebralab.com/Imaginary_Problems_Are_the_Root_of_Bad_Software)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 14:42:47+00:00

<p>Article URL: <a href="https://cerebralab.com/Imaginary_Problems_Are_the_Root_of_Bad_Software">https://cerebralab.com/Imaginary_Problems_Are_the_Root_of_Bad_Software</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36380711">https://news.ycombinator.com/item?id=36380711</a></p>
<p>Points: 66</p>
<p># Comments: 21</p>

## Moldable Live Programming for Clojure
 - [https://github.com/nextjournal/clerk](https://github.com/nextjournal/clerk)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 14:35:47+00:00

<p>Article URL: <a href="https://github.com/nextjournal/clerk">https://github.com/nextjournal/clerk</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36380636">https://news.ycombinator.com/item?id=36380636</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## Time-Lock Puzzles in the Random Oracle Model (2011)
 - [https://people.seas.harvard.edu/~salil/research/timelock-abs.html](https://people.seas.harvard.edu/~salil/research/timelock-abs.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 14:31:42+00:00

<p>Article URL: <a href="https://people.seas.harvard.edu/~salil/research/timelock-abs.html">https://people.seas.harvard.edu/~salil/research/timelock-abs.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36380592">https://news.ycombinator.com/item?id=36380592</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## The GMP library's repository is under attack by a single GitHub user
 - [https://gmplib.org/](https://gmplib.org/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 13:53:33+00:00

<p>Article URL: <a href="https://gmplib.org/">https://gmplib.org/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36380325">https://news.ycombinator.com/item?id=36380325</a></p>
<p>Points: 52</p>
<p># Comments: 23</p>

## DIY-Audio-Heaven
 - [https://diyaudioheaven.wordpress.com/](https://diyaudioheaven.wordpress.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 13:44:10+00:00

<p>Article URL: <a href="https://diyaudioheaven.wordpress.com/">https://diyaudioheaven.wordpress.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36380247">https://news.ycombinator.com/item?id=36380247</a></p>
<p>Points: 5</p>
<p># Comments: 1</p>

## A guide for people who want to self-study the basics of computer science
 - [https://github.com/Lesabotsy/bootcamp](https://github.com/Lesabotsy/bootcamp)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 13:43:49+00:00

<p>Article URL: <a href="https://github.com/Lesabotsy/bootcamp">https://github.com/Lesabotsy/bootcamp</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36380240">https://news.ycombinator.com/item?id=36380240</a></p>
<p>Points: 62</p>
<p># Comments: 29</p>

## Shannon’s Source Coding Theorem (Foundations of Information Theory: Part 3)
 - [https://mbernste.github.io/posts/sourcecoding/](https://mbernste.github.io/posts/sourcecoding/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 13:38:47+00:00

<p>Article URL: <a href="https://mbernste.github.io/posts/sourcecoding/">https://mbernste.github.io/posts/sourcecoding/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36380198">https://news.ycombinator.com/item?id=36380198</a></p>
<p>Points: 22</p>
<p># Comments: 5</p>

## The legend of “x86 CPUs decode instructions into RISC form internally”
 - [https://fanael.github.io/is-x86-risc-internally.html](https://fanael.github.io/is-x86-risc-internally.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 13:33:10+00:00

<p>Article URL: <a href="https://fanael.github.io/is-x86-risc-internally.html">https://fanael.github.io/is-x86-risc-internally.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36380149">https://news.ycombinator.com/item?id=36380149</a></p>
<p>Points: 18</p>
<p># Comments: 5</p>

## Most tech content is bullshit (2020)
 - [https://www.aleksandra.codes/tech-content-consumer](https://www.aleksandra.codes/tech-content-consumer)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 13:16:37+00:00

<p>Article URL: <a href="https://www.aleksandra.codes/tech-content-consumer">https://www.aleksandra.codes/tech-content-consumer</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36380024">https://news.ycombinator.com/item?id=36380024</a></p>
<p>Points: 37</p>
<p># Comments: 20</p>

## Bugs – opinionated Jira CLI for those of us who hate Jira
 - [https://github.com/reddit/bugs](https://github.com/reddit/bugs)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 13:03:19+00:00

<p>Article URL: <a href="https://github.com/reddit/bugs">https://github.com/reddit/bugs</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36379930">https://news.ycombinator.com/item?id=36379930</a></p>
<p>Points: 14</p>
<p># Comments: 3</p>

## Police got called to an overcrowded presentation on “rejuvenation” technology
 - [https://www.technologyreview.com/2023/06/17/1075097/got-rejuvenation-better-call-security/](https://www.technologyreview.com/2023/06/17/1075097/got-rejuvenation-better-call-security/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 12:42:40+00:00

<p>Article URL: <a href="https://www.technologyreview.com/2023/06/17/1075097/got-rejuvenation-better-call-security/">https://www.technologyreview.com/2023/06/17/1075097/got-rejuvenation-better-call-security/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36379767">https://news.ycombinator.com/item?id=36379767</a></p>
<p>Points: 14</p>
<p># Comments: 8</p>

## Follow up to “I booted Linux 293k times”
 - [https://rwmj.wordpress.com/2023/06/18/follow-up-to-i-booted-linux-292612-times/](https://rwmj.wordpress.com/2023/06/18/follow-up-to-i-booted-linux-292612-times/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 12:26:09+00:00

<p>Article URL: <a href="https://rwmj.wordpress.com/2023/06/18/follow-up-to-i-booted-linux-292612-times/">https://rwmj.wordpress.com/2023/06/18/follow-up-to-i-booted-linux-292612-times/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36379615">https://news.ycombinator.com/item?id=36379615</a></p>
<p>Points: 92</p>
<p># Comments: 6</p>

## The Difference Between Root Certificate Authorities, Intermediates and Resellers
 - [https://www.agwa.name/blog/post/roots_intermediates_and_resellers](https://www.agwa.name/blog/post/roots_intermediates_and_resellers)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 11:42:16+00:00

<p>Article URL: <a href="https://www.agwa.name/blog/post/roots_intermediates_and_resellers">https://www.agwa.name/blog/post/roots_intermediates_and_resellers</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36379265">https://news.ycombinator.com/item?id=36379265</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## BlackCat claims they hacked Reddit and will leak the data
 - [https://www.databreaches.net/blackcat-claims-they-hacked-reddit-and-will-leak-the-data/](https://www.databreaches.net/blackcat-claims-they-hacked-reddit-and-will-leak-the-data/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 11:03:42+00:00

<p>Article URL: <a href="https://www.databreaches.net/blackcat-claims-they-hacked-reddit-and-will-leak-the-data/">https://www.databreaches.net/blackcat-claims-they-hacked-reddit-and-will-leak-the-data/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36379094">https://news.ycombinator.com/item?id=36379094</a></p>
<p>Points: 15</p>
<p># Comments: 3</p>

## A complete guide to getting what you want (2018)
 - [https://www.raptitude.com/2018/06/getting-what-you-want/](https://www.raptitude.com/2018/06/getting-what-you-want/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 10:23:31+00:00

<p>Article URL: <a href="https://www.raptitude.com/2018/06/getting-what-you-want/">https://www.raptitude.com/2018/06/getting-what-you-want/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36378896">https://news.ycombinator.com/item?id=36378896</a></p>
<p>Points: 16</p>
<p># Comments: 2</p>

## Fruit-Bat/Pico-Zxspectrum: ZX Spectrum for Raspberry Pico Pi RP2040
 - [https://github.com/fruit-bat/pico-zxspectrum](https://github.com/fruit-bat/pico-zxspectrum)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 10:10:59+00:00

<p>Article URL: <a href="https://github.com/fruit-bat/pico-zxspectrum">https://github.com/fruit-bat/pico-zxspectrum</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36378829">https://news.ycombinator.com/item?id=36378829</a></p>
<p>Points: 10</p>
<p># Comments: 0</p>

## Jellyfin: The Free Software Media System
 - [https://github.com/jellyfin/jellyfin](https://github.com/jellyfin/jellyfin)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 09:43:24+00:00

<p>Article URL: <a href="https://github.com/jellyfin/jellyfin">https://github.com/jellyfin/jellyfin</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36378689">https://news.ycombinator.com/item?id=36378689</a></p>
<p>Points: 34</p>
<p># Comments: 6</p>

## Go: Execution Tracer Overhaul
 - [https://go.googlesource.com/proposal/+/ac09a140c3d26f8bb62cbad8969c8b154f93ead6/design/60773-execution-tracer-overhaul.md](https://go.googlesource.com/proposal/+/ac09a140c3d26f8bb62cbad8969c8b154f93ead6/design/60773-execution-tracer-overhaul.md)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 07:49:45+00:00

<p>Article URL: <a href="https://go.googlesource.com/proposal/+/ac09a140c3d26f8bb62cbad8969c8b154f93ead6/design/60773-execution-tracer-overhaul.md">https://go.googlesource.com/proposal/+/ac09a140c3d26f8bb62cbad8969c8b154f93ead6/design/60773-execution-tracer-overhaul.md</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36378167">https://news.ycombinator.com/item?id=36378167</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## Keygen Library Player (4504 tracks)
 - [https://cable.ayra.ch/webxmp/](https://cable.ayra.ch/webxmp/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 07:42:02+00:00

<p>Article URL: <a href="https://cable.ayra.ch/webxmp/">https://cable.ayra.ch/webxmp/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36378137">https://news.ycombinator.com/item?id=36378137</a></p>
<p>Points: 7</p>
<p># Comments: 1</p>

## Finite and Infinite Games [pdf]
 - [https://wtf.tw/ref/carse.pdf](https://wtf.tw/ref/carse.pdf)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 07:15:28+00:00

<p>Article URL: <a href="https://wtf.tw/ref/carse.pdf">https://wtf.tw/ref/carse.pdf</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36378032">https://news.ycombinator.com/item?id=36378032</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## What I’ve learned from 35 years of wearing computerized eyewear
 - [https://spectrum.ieee.org/steve-mann-my-augmediated-life](https://spectrum.ieee.org/steve-mann-my-augmediated-life)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 07:06:36+00:00

<p>Article URL: <a href="https://spectrum.ieee.org/steve-mann-my-augmediated-life">https://spectrum.ieee.org/steve-mann-my-augmediated-life</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36378003">https://news.ycombinator.com/item?id=36378003</a></p>
<p>Points: 5</p>
<p># Comments: 1</p>

## How to Read and Organize Online Articles (Without Driving Yourself Crazy)
 - [https://www.gregoryciotti.com/reading-organization/](https://www.gregoryciotti.com/reading-organization/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 07:04:08+00:00

<p>Article URL: <a href="https://www.gregoryciotti.com/reading-organization/">https://www.gregoryciotti.com/reading-organization/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36377995">https://news.ycombinator.com/item?id=36377995</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Color Space Experiments
 - [https://jlongster.com/color-space-experiments](https://jlongster.com/color-space-experiments)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 07:00:20+00:00

<p>Article URL: <a href="https://jlongster.com/color-space-experiments">https://jlongster.com/color-space-experiments</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36377979">https://news.ycombinator.com/item?id=36377979</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## Apple Vision Pro – Hardware Issues
 - [https://kguttag.com/2023/06/16/apple-vision-pro-part-2-hardware-issues/](https://kguttag.com/2023/06/16/apple-vision-pro-part-2-hardware-issues/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 06:55:27+00:00

<p>Article URL: <a href="https://kguttag.com/2023/06/16/apple-vision-pro-part-2-hardware-issues/">https://kguttag.com/2023/06/16/apple-vision-pro-part-2-hardware-issues/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36377954">https://news.ycombinator.com/item?id=36377954</a></p>
<p>Points: 37</p>
<p># Comments: 33</p>

## Show HN: Dots and Boxes in Elm
 - [https://www.martincapodici.com/elm/dotsandboxes/](https://www.martincapodici.com/elm/dotsandboxes/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 06:46:34+00:00

<p>Article URL: <a href="https://www.martincapodici.com/elm/dotsandboxes/">https://www.martincapodici.com/elm/dotsandboxes/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36377920">https://news.ycombinator.com/item?id=36377920</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## Sennheiser HD 555 to HD 595 Mod
 - [http://mikebeauchamp.com/misc/sennheiser-hd-555-to-hd-595-mod/](http://mikebeauchamp.com/misc/sennheiser-hd-555-to-hd-595-mod/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 06:35:51+00:00

<p>Article URL: <a href="http://mikebeauchamp.com/misc/sennheiser-hd-555-to-hd-595-mod/">http://mikebeauchamp.com/misc/sennheiser-hd-555-to-hd-595-mod/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36377875">https://news.ycombinator.com/item?id=36377875</a></p>
<p>Points: 127</p>
<p># Comments: 37</p>

## I have received a $100k sponsorship for Ladybird browser
 - [https://twitter.com/awesomekling/status/1670298370550779905](https://twitter.com/awesomekling/status/1670298370550779905)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 06:21:24+00:00

<p>Article URL: <a href="https://twitter.com/awesomekling/status/1670298370550779905">https://twitter.com/awesomekling/status/1670298370550779905</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36377805">https://news.ycombinator.com/item?id=36377805</a></p>
<p>Points: 92</p>
<p># Comments: 7</p>

## Milk-V Duo: A $9 RISC-V COMPUTER
 - [https://milkv.io/duo](https://milkv.io/duo)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 04:54:06+00:00

<p>Article URL: <a href="https://milkv.io/duo">https://milkv.io/duo</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36377439">https://news.ycombinator.com/item?id=36377439</a></p>
<p>Points: 28</p>
<p># Comments: 8</p>

## Squeezing a Little More Performance Out of Bytecode Interpreters
 - [https://stefan-marr.de/2023/06/squeezing-a-little-more-performance-out-of-bytecode-interpreters/](https://stefan-marr.de/2023/06/squeezing-a-little-more-performance-out-of-bytecode-interpreters/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 04:19:32+00:00

<p>Article URL: <a href="https://stefan-marr.de/2023/06/squeezing-a-little-more-performance-out-of-bytecode-interpreters/">https://stefan-marr.de/2023/06/squeezing-a-little-more-performance-out-of-bytecode-interpreters/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36377280">https://news.ycombinator.com/item?id=36377280</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## Hybrid SDF-Voxel Traversal
 - [https://www.shadertoy.com/view/dtVSzw](https://www.shadertoy.com/view/dtVSzw)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 03:16:42+00:00

<p>Article URL: <a href="https://www.shadertoy.com/view/dtVSzw">https://www.shadertoy.com/view/dtVSzw</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36376982">https://news.ycombinator.com/item?id=36376982</a></p>
<p>Points: 30</p>
<p># Comments: 3</p>

## Scientists create contained ball of turbulence in a tank
 - [https://news.uchicago.edu/story/tempest-teacup-uchicago-physicists-make-breakthrough-creating-turbulence](https://news.uchicago.edu/story/tempest-teacup-uchicago-physicists-make-breakthrough-creating-turbulence)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 02:49:28+00:00

<p>Article URL: <a href="https://news.uchicago.edu/story/tempest-teacup-uchicago-physicists-make-breakthrough-creating-turbulence">https://news.uchicago.edu/story/tempest-teacup-uchicago-physicists-make-breakthrough-creating-turbulence</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36376875">https://news.ycombinator.com/item?id=36376875</a></p>
<p>Points: 82</p>
<p># Comments: 11</p>

## A History Of Nvidia Stream Multiprocessor
 - [https://fabiensanglard.net/cuda/index.html](https://fabiensanglard.net/cuda/index.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 02:49:17+00:00

<p>Article URL: <a href="https://fabiensanglard.net/cuda/index.html">https://fabiensanglard.net/cuda/index.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36376872">https://news.ycombinator.com/item?id=36376872</a></p>
<p>Points: 15</p>
<p># Comments: 0</p>

## Show HN: Follow every MLB game. Real time. New score alerts
 - [https://mlb.watchbotapp.com](https://mlb.watchbotapp.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 02:11:30+00:00

<p>Article URL: <a href="https://mlb.watchbotapp.com">https://mlb.watchbotapp.com</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36376687">https://news.ycombinator.com/item?id=36376687</a></p>
<p>Points: 25</p>
<p># Comments: 6</p>

## How a Single Line of Code Made a 24-Core Server Slower Than a Laptop (2021)
 - [https://pkolaczk.github.io/server-slower-than-a-laptop/](https://pkolaczk.github.io/server-slower-than-a-laptop/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 02:08:10+00:00

<p>Article URL: <a href="https://pkolaczk.github.io/server-slower-than-a-laptop/">https://pkolaczk.github.io/server-slower-than-a-laptop/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36376669">https://news.ycombinator.com/item?id=36376669</a></p>
<p>Points: 152</p>
<p># Comments: 37</p>

## Falcon LLM – A 40B Model
 - [https://falconllm.tii.ae/](https://falconllm.tii.ae/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 00:19:41+00:00

<p>Article URL: <a href="https://falconllm.tii.ae/">https://falconllm.tii.ae/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36376111">https://news.ycombinator.com/item?id=36376111</a></p>
<p>Points: 65</p>
<p># Comments: 19</p>

## Infinite Photorealistic Worlds Using Procedural Generation
 - [https://arxiv.org/abs/2306.09310](https://arxiv.org/abs/2306.09310)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-06-18 00:11:38+00:00

<p>Article URL: <a href="https://arxiv.org/abs/2306.09310">https://arxiv.org/abs/2306.09310</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=36376071">https://news.ycombinator.com/item?id=36376071</a></p>
<p>Points: 136</p>
<p># Comments: 27</p>

