# Source:Wydarzenia Interia - Świat, URL:https://wydarzenia.interia.pl/swiat/feed, language:pl-PL

## Sudan: Uzgodniono 72-godzinne zawieszenie broni
 - [https://wydarzenia.interia.pl/zagranica/news-sudan-uzgodniono-72-godzinne-zawieszenie-broni,nId,6848767](https://wydarzenia.interia.pl/zagranica/news-sudan-uzgodniono-72-godzinne-zawieszenie-broni,nId,6848767)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-06-18 04:38:59+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-sudan-uzgodniono-72-godzinne-zawieszenie-broni,nId,6848767"><img align="left" alt="Sudan: Uzgodniono 72-godzinne zawieszenie broni" src="https://i.iplsc.com/sudan-uzgodniono-72-godzinne-zawieszenie-broni/000HAK5X6I4YKY6W-C321.jpg" /></a>Walki w rejonie Chartumu nie ustają. W sobotę trwały one z wyjątkową intensywnością. Według mediatorów saudyjskich i amerykańskich, sudańska armia rządowa i organizacje paramilitarne skupione w Siłach Szybkiego Wsparcia (RSF) uzgodniły 72-godzinne zawieszenie broni w trwającej od połowy kwietnia wojnie domowej, które ma obowiązywać od niedzieli. Obserwatorzy wskazują jednak, że poprzednie porozumienia były szybko zrywane.</p><br clear="all" />

## Antony Blinken w Pekinie. Pierwsza taka wizyta od pięciu lat
 - [https://wydarzenia.interia.pl/zagranica/news-antony-blinken-w-pekinie-pierwsza-taka-wizyta-od-pieciu-lat,nId,6848766](https://wydarzenia.interia.pl/zagranica/news-antony-blinken-w-pekinie-pierwsza-taka-wizyta-od-pieciu-lat,nId,6848766)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-06-18 04:16:58+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-antony-blinken-w-pekinie-pierwsza-taka-wizyta-od-pieciu-lat,nId,6848766"><img align="left" alt="Antony Blinken w Pekinie. Pierwsza taka wizyta od pięciu lat" src="https://i.iplsc.com/antony-blinken-w-pekinie-pierwsza-taka-wizyta-od-pieciu-lat/000HAK57DCM60IJ6-C321.jpg" /></a>Antony Blinken, sekretarz stanu USA, dotarł w niedzielę do Pekinu. Jak podkreśla amerykański Departament Stanu, to pierwszy od pięciu lat amerykański dyplomata wysokiej rangi z misją podjęcia próby &quot;odpowiedzialnego dialogu&quot; i poprawy wzajemnych kontaktów dyplomatycznych.</p><br clear="all" />

