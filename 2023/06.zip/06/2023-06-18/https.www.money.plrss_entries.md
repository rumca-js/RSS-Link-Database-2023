# Source:Money PL, URL:https://www.money.pl/rss/, language:pl-PL

## Skaner w rękę i na zakupy. Kaufland daje klientom sprytny gadżet
 - [https://www.money.pl/gospodarka/skaner-w-reke-i-na-zakupy-kaufland-daje-klientom-sprytny-gadzet-6909367853202048a.html](https://www.money.pl/gospodarka/skaner-w-reke-i-na-zakupy-kaufland-daje-klientom-sprytny-gadzet-6909367853202048a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-18 15:16:18+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/898eeac0-ae49-4b7b-b19b-2b6865ebd160" width="308" /> Przedstawiciele branży handlowej prześcigają się w pomysłach na przyciągnięcie klientów. Rozszerzają zakres usług w aplikacjach, zmniejszają formaty sklepów czy oferują dostawę pod dom. Kaufland z kolei stawia na skanery, które pozwalają klientom nabijać towary w trakcie zakupów.

## Inflacja, brak inwestycji i katastrofa służby zdrowia. "To PiS chciało ukryć"
 - [https://www.money.pl/gospodarka/inflacja-brak-inwestycji-i-katastrofa-sluzby-zdrowia-to-pis-chcialo-ukryc-6910355546487456a.html](https://www.money.pl/gospodarka/inflacja-brak-inwestycji-i-katastrofa-sluzby-zdrowia-to-pis-chcialo-ukryc-6910355546487456a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-18 14:28:38+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/677340bd-15b6-42ed-a37f-275aa1895132" width="308" /> W niedzielę politycy Lewicy prezentują przygotowany przez to ugrupowanie "Raport o Stanie Państwa". Szef klubu Lewicy Krzysztof Gawkowski podkreślił, że raport ten "to prawda o tym, że Prawo i Sprawiedliwość ukradło Polskę swoim obywatelom i zrobiło to z pełną premedytacją".

## Znaczenie marki osobistej dla rozwoju kariery zawodowej
 - [https://www.money.pl/gospodarka/znaczenie-marki-osobistej-dla-rozwoju-kariery-zawodowej-6909571144239744a.html](https://www.money.pl/gospodarka/znaczenie-marki-osobistej-dla-rozwoju-kariery-zawodowej-6909571144239744a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-18 10:06:44+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/9810b96d-6a36-4867-88a8-2ecb206a01e5" width="308" /> Apple, Microsoft, Coca-Cola, a może Amazon czy Google? Która marka ma największą wartość? Według opublikowanego pod koniec 2022 roku rankingu Interbrand najcenniejszą jest Apple, oszacowana na 482,2 mld dolarów. Na kolejnych miejscach znalazły się Microsoft, Amazon, Google czy Facebook i Intel. Marki osobiste nie są tak wysoko wyceniane, ale mogą mieć niebagatelne znaczenie dla rozwoju kariery zawodowej. O co chodzi? Na co wpływa marka osobista, jak ją świadomie i celowo budować?

## Więcej osób będzie mogło przejść na wcześniejszą emeryturę. To będzie miało swoje konsekwencje
 - [https://www.money.pl/emerytury/wiecej-osob-bedzie-moglo-przejsc-na-wczesniejsza-emeryture-to-bedzie-mialo-swoje-konsekwencje-6910280886721088a.html](https://www.money.pl/emerytury/wiecej-osob-bedzie-moglo-przejsc-na-wczesniejsza-emeryture-to-bedzie-mialo-swoje-konsekwencje-6910280886721088a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-18 09:24:50+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/0365a501-e4ca-4ef0-9554-8797776a6fa3" width="308" /> Sejm uchwalił nowelizację ustawy o emeryturach pomostowych uchylającą wygasający charakter tego świadczenia. Będą one przysługiwać również osobom, które nie posiadają stażu pracy w warunkach szczególnych przed 1 stycznia 1999 r. To będzie jednak sporo kosztować budżet państwa.

## Pensja minimalna w górę od lipca. Takie będą wypłaty "na rękę"
 - [https://www.money.pl/pieniadze/pensja-minimalna-w-gore-od-lipca-takie-beda-wyplaty-na-reke-6910253864168000a.html](https://www.money.pl/pieniadze/pensja-minimalna-w-gore-od-lipca-takie-beda-wyplaty-na-reke-6910253864168000a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-18 07:34:48+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/6cae63c6-0f86-4f23-995e-ac13c8caec66" width="308" /> W tym roku, ze względu na wysoką inflację, przewidziano dwie podwyżki pensji minimalnej. Druga podwyżka wejdzie w życie 1 lipca. Wtedy najniższa pensja minimalna zostanie podniesiona do 3600 zł brutto. oznacza to, że osobom pracującym na umowie o pracę pracodawcy nie będą mogli zapłacić mniej.

## Jest najnowszy sondaż ws. stanu polskiej gospodarki. PiS nie może być zadowolony
 - [https://www.money.pl/gospodarka/jest-najnowszy-sondaz-ws-stanu-polskiej-gospodarki-pis-nie-moze-byc-zadowolony-6910247062645312a.html](https://www.money.pl/gospodarka/jest-najnowszy-sondaz-ws-stanu-polskiej-gospodarki-pis-nie-moze-byc-zadowolony-6910247062645312a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-18 07:07:12+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/2226757b-ef51-4a46-97b4-cbab8438c60f" width="308" /> 20,6 proc. badanych dobrze ocenia stan polskiej gospodarki i finansów publicznych po ośmiu latach rządów PiS, w tym 7,2 proc. - bardzo dobrze. 14,8 proc. ocenia je dostatecznie, 22 proc. miernie, a 37,8 proc. - niedostatecznie - wynika z sondażu SW Research przeprowadzonego dla rp.pl.

## "Workation" nie zastąpi porządnego urlopu. Na dłuższą metę może to być zgubne
 - [https://www.money.pl/gospodarka/workation-nie-zastapi-porzadnego-urlopu-na-dluzsza-mete-moze-to-byc-zgubne-6908253827111552a.html](https://www.money.pl/gospodarka/workation-nie-zastapi-porzadnego-urlopu-na-dluzsza-mete-moze-to-byc-zgubne-6908253827111552a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-18 05:14:03+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/9fe7d371-b4a6-4281-84c9-3b4bcea298f5" width="308" /> Wraz z upowszechnieniem się pracy hybrydowej pojawiła się też nowa forma wypoczynku. "Workation", bo o nim mowa, polega na pracy z dowolnego miejsca na świecie. Po zamknięciu laptopa pracownik zmienia się w turystę i zwiedza region. Problem w tym, że taki wypoczynek na dłuższą metę może być zgubny.

## Zmieniliśmy nawyki. Na tym zdecydowana większość oszczędza
 - [https://www.money.pl/gospodarka/zmienilismy-nawyki-na-tym-zdecydowana-wiekszosc-oszczedza-6910217616353856a.html](https://www.money.pl/gospodarka/zmienilismy-nawyki-na-tym-zdecydowana-wiekszosc-oszczedza-6910217616353856a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-18 05:07:23+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/6eb6b685-cb6a-4879-b584-2074b585dbb3" width="308" /> 91 proc. Polaków oszczędza na zakupach żywności - wynika z badania BIG InfoMonitor. Najczęściej rodacy rezygnują z kupna alkoholu, gotowych dań i słodyczy. Jednocześnie 46 proc. badanych traci pieniądze z powodu marnowania żywności - najczęściej ok. 100 zł miesięcznie.

## Polski port coraz ważniejszy dla Niemców. Korzystamy na tym
 - [https://www.money.pl/gielda/polski-port-coraz-wazniejszy-dla-niemcow-korzystamy-na-tym-6908564441000576a.html](https://www.money.pl/gielda/polski-port-coraz-wazniejszy-dla-niemcow-korzystamy-na-tym-6908564441000576a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-06-18 04:41:34+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/2cfe6f14-7b37-4bea-9bbe-f9e20675048f" width="308" /> Tylko w maju przez gdański Naftoport przetoczono rekordowe 3,4 mln ton ropy naftowej i paliw z 41 zbiornikowców. Część tego ładunku to dostawy dla zagranicznych klientów, w tym niemieckich rafinerii. Po odcięciu dostaw ropociągiem z Rosji, Polska stała się dla nich najważniejszą bramą.

