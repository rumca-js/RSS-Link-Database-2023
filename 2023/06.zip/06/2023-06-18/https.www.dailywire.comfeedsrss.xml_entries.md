# Source:Daily Wire, URL:https://www.dailywire.com/feeds/rss.xml, language:en-US

## WATCH: British PM Mocks Politician Who Claimed Women Can Have Penises
 - [https://www.dailywire.com/news/watch-british-pm-mocks-politician-who-claimed-women-can-have-penises](https://www.dailywire.com/news/watch-british-pm-mocks-politician-who-claimed-women-can-have-penises)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-06-18 18:11:22+00:00

British Prime Minister Rishi Sunak was reportedly caught on video mocking radical gender theory — and a political opponent who subscribed to it wholesale — at a recent event with the 1922 Committee, a group of conservative members of Parliament. The video was released by LGBTQ+ outlet PinkNews — where it was reported that Sunak, ...

## U.S. Relationship With China ‘Worse’ Than With Soviet Union During Cold War, Former National Security Adviser Says
 - [https://www.dailywire.com/news/u-s-relationship-with-china-worse-than-with-soviet-union-during-cold-war-former-national-security-adviser-says](https://www.dailywire.com/news/u-s-relationship-with-china-worse-than-with-soviet-union-during-cold-war-former-national-security-adviser-says)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-06-18 16:51:48+00:00

Former Trump National Security Adviser H.R. McMaster believes American relations with China today are “worse” than they were with the Soviet Union during the Cold War.  McMaster made the remarks during an interview with Margaret Brennan on CBS News’ “Face The Nation” Sunday. He told the host that U.S.-China relations are more complex than they ...

## WATCH: Democrat Corrects Herself After Saying Trump Should Be Shot
 - [https://www.dailywire.com/news/watch-democrat-corrects-herself-after-saying-trump-should-be-shot](https://www.dailywire.com/news/watch-democrat-corrects-herself-after-saying-trump-should-be-shot)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-06-18 16:45:54+00:00

Congressional Delegate Stacey Plaskett (D-USVI) had to correct herself on Sunday after she said during a live television interview that former President Donald Trump should be &#8220;shot.&#8221; Plaskett made the comment during an appearance on MSNBC, during which she discussed the federal charges against Trump relating to his alleged mishandling of classified documents following his ...

## Comer Plans To Bring In ‘Key Witnesses’ In Biden Family Probe
 - [https://www.dailywire.com/news/comer-plans-to-bring-in-key-witnesses-in-biden-family-probe](https://www.dailywire.com/news/comer-plans-to-bring-in-key-witnesses-in-biden-family-probe)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-06-18 16:30:09+00:00

Congressional investigators will have &#8220;key figures&#8221; appear for depositions in an investigation into allegations of influence peddling levied against President Joe Biden and his family, according to a top Republican lawmaker. During an interview with Fox News, House Oversight Chairman James Comer (R-KY) shared insight into what steps his panel will take as it ramps ...

## Joe Rogan Challenges Vaccine ‘Champion’ To Debate Robert Kennedy Jr.
 - [https://www.dailywire.com/news/joe-rogan-challenges-vaccine-champion-to-debate-robert-kennedy-jr](https://www.dailywire.com/news/joe-rogan-challenges-vaccine-champion-to-debate-robert-kennedy-jr)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-06-18 14:41:17+00:00

UFC commentator and comedian Joe Rogan invited a health expert to debate Robert Kennedy Jr., a Democratic Party candidate for president, about vaccines on his popular podcast in exchange for a $100,000 donation to charity. Dr. Peter Hotez, dean at the National School of Tropical Medicine at Baylor College of Medicine in Houston, Texas, lashed ...

## 2024 Candidates Weigh In On Whether They Would Pardon Trump
 - [https://www.dailywire.com/news/2024-candidates-weigh-in-on-whether-they-would-pardon-trump](https://www.dailywire.com/news/2024-candidates-weigh-in-on-whether-they-would-pardon-trump)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-06-18 14:11:33+00:00

Several 2024 contenders hoping to replace President Joe Biden in the White House have answered questions about pardoning former President Trump. Last week Trump appeared in a federal courtroom in Miami and pleaded not guilty to 37 charges, including 31 alleged violations of the Espionage Act for “willful retention” of national defense information, as well ...

## Asa Hutchinson Says GOP Should ‘Back Off’ Claim That DOJ Has Been Weaponized Against Trump
 - [https://www.dailywire.com/news/asa-hutchinson-says-gop-should-back-off-claim-that-doj-has-been-weaponized-against-trump](https://www.dailywire.com/news/asa-hutchinson-says-gop-should-back-off-claim-that-doj-has-been-weaponized-against-trump)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-06-18 13:59:11+00:00

GOP presidential candidate Asa Hutchinson says that members of the Republican Party who claim the Department of Justice has been weaponized against former President Donald Trump should “back off.&#8221;  During an appearance on ABC News’s “This Week” with host Jonathan Karl, the former Arkansas governor said arguing that the Justice Department has been unfairly targeting ...

## Tim Scott Fires Back At Obama Over Race Comments
 - [https://www.dailywire.com/news/tim-scott-fires-back-at-obama-over-race-comments](https://www.dailywire.com/news/tim-scott-fires-back-at-obama-over-race-comments)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-06-18 12:23:50+00:00

Sen. Tim Scott (R-SC), a 2024 presidential candidate, rejected former President Barack Obama&#8216;s critique of his view on race relations. Obama, the first black American to be elected president, said during a recent CNN podcast that voters should be skeptical of GOP candidates who lack a plan to address the consequences of hundreds of years ...

## Vivek Ramaswamy Counters Mark Cuban’s Claim That ‘Woke’ Capitalism Is ‘Good Business’
 - [https://www.dailywire.com/news/vivek-ramaswamy-counters-mark-cubans-claim-that-woke-capitalism-is-good-business](https://www.dailywire.com/news/vivek-ramaswamy-counters-mark-cubans-claim-that-woke-capitalism-is-good-business)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-06-18 11:23:34+00:00

Republican presidential candidate Vivek Ramaswamy pushed back on billionaire Mark Cuban’s claim that pushing “woke” capitalism is “good business.”  During an appearance on “Fox News Sunday” with host Shannon Bream, Ramaswamy, author of “Woke, Inc.: Inside Corporate America&#8217;s Social Justice Scam,” blasted Cuban&#8217;s comments and pointed to brands like Bud Light and companies like Target ...

## Man Arrested For Attempting To Burn Down Mary Todd Lincoln’s Childhood Home: Police
 - [https://www.dailywire.com/news/man-arrested-for-attempting-to-burn-down-mary-todd-lincolns-childhood-home-police](https://www.dailywire.com/news/man-arrested-for-attempting-to-burn-down-mary-todd-lincolns-childhood-home-police)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-06-18 10:08:12+00:00

A man was arrested late last week after authorities said he attempted to burn down the childhood home of former first lady Mary Todd Lincoln, according to Fox 56.  On Thursday, a Lexington, Kentucky, police officer spotted 29-year-old Santosh Sharma pouring gasoline on the back of the Mary Todd Lincoln House in downtown Lexington, according ...

## AMC Theatres Cancels De-Transitioner Film Following Trans Group’s De-Platforming Campaign
 - [https://www.dailywire.com/news/amc-theatres-cancels-de-transitioner-film-following-trans-groups-de-platforming-campaign](https://www.dailywire.com/news/amc-theatres-cancels-de-transitioner-film-following-trans-groups-de-platforming-campaign)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-06-18 08:52:03+00:00

AMC Theatres abruptly canceled a film showcasing the voices of young people who have de-transitioned after having hormone therapy and surgeries to purportedly &#8220;affirm&#8221; their &#8220;gender identity.&#8221; &#8220;No Way Back: The Reality of Gender-Affirming Care&#8221; was set for initial release on June 21 in dozens of theaters across the country. Producers of the film say ...

