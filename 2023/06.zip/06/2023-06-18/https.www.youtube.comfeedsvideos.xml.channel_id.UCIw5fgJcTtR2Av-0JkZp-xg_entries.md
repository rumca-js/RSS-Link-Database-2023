# Source:Yuri Wong, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg, language:en-US

## "YOU DONE MESSED UP A-A-RON!" / Remixing Key & Peele "Substitute Teacher" Sketch on SmplTrek
 - [https://www.youtube.com/watch?v=VoORfpMRfIU](https://www.youtube.com/watch?v=VoORfpMRfIU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg
 - date published: 2023-06-18 12:00:32+00:00

Support my music on Patreon: https://patreon.com/yuriwong
SmplTrek skin by Cremacaffe: https://cremacaffe.shop
Remixed on the Sonicware SmplTrek
Completed in Logic Pro
0:00 Making-of
3:30 Full Song

Mr. Garvey
All right, listen up y’all. I’m your substitute teacher Mr. Garvey, I taught school for 20 years in the inner city, so don’t even think about messing with me. You all feel me?
Okay, let’s take the roll here. Jakequaline, where’s Jakequaline at? No Jakequaline here? Yeah?

[Jacqueline]
Uh, do you mean, Jacqueline?

[Mr. Garvey]
Okay, so that’s how it’s going to be, you all want to play, okay then; I got my eye on you Jakequaline. Balakay, where is Balakay at? No, Balakay here today? Yes, sir?

[Blake]
My name is Blake.

[Mr. Garvey]
Are you out of your God damn mind? Blake? What? Do you want to go to war Balakay?

[Blake]
No.

[Mr. Garvey]
Because we couldn’t go to war?

[Blake]
No.

[Mr. Garvey]
I’m for real, I’m for real, so you better check yourself.
De-nice, is there a De-nice? If one of y’all say some silly ass name, this whole class is going to feel my wrath, now De-nice?
[Denise]
Do you mean Denise?

[Mr. Garvey]
Son of a bitch!
You say your name right, right now?

[Denise]
Denise.

[Mr. Garvey]
Say it right?

[Denise]
Denise.

[Mr. Garvey]
Correctly.

[Denise]
Denise.

[Mr. Garvey]
Right.

[Denise]
Denise.
[Mr. Garvey]
Right.

[Denise]
De-nice?

[Mr. Garvey]
That’s better, thank you.
Now a Ay-Ay-ron, where are you, where is a Ay-Ay-ron right now, no Ay-Ay-ron, huh? Oh, you better be sick, dead or mute, Ay-Ay-ron?

[Aaron]
Here. Oh man.

[Mr. Garvey]
Why didn’t you answer me the first time I said?

[Aaron]
Huh

[Mr. Garvey]
I’m just asking, I said it like four times, so why didn’t you say it the first time I said Ay-Ay-ron?

[Aaron]
Because it’s pronounced Aaron.

[Mr. Garvey]
Son of a bitch, you done messed up Ay-Ay-ron, now take your ass on down to O. Shag Hennessy’s office right now, and tell him exactly what you did.
[Aaron]
Who?

[Mr. Garvey]
O. Shag Hennessy.

[Aaron]
Principle O’Shaughnessy?

[Mr. Garvey]
Get out of my God damn classroom before I break my foot up in your ass.
Insubordinate and churlish.
Tim-mothy?

[Timothy]
Pre-sent.

[Mr. Garvey]
Thank you.

