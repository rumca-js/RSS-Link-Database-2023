# Source:Matt Walsh, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ, language:en-US

## Rolling Stone's Hit Piece Is My Favorite To Date
 - [https://www.youtube.com/watch?v=zL_bmA-Kvic](https://www.youtube.com/watch?v=zL_bmA-Kvic)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2023-06-18 15:00:47+00:00

Try Hallow for 3 months FREE: https://hallow.com/mattwalsh

Become a DailyWire+ member and watch the full show: https://bit.ly/3xI9PZL

LIKE & SUBSCRIBE for new videos every day. https://www.youtube.com/c/MattWalsh?sub_confirmation=1

Rolling Stone finally released their hit piece on me, and it's great.

Watch the full episode here: Ep.1181 - https://bit.ly/43IcxwL

Stop giving your money to woke corporations that hate you. Get your Jeremy’s Razors today at https://bit.ly/3lSGpWa

Watch my hit documentary, “What Is A Woman?” here: https://utm.io/ueSdV

Represent the Sweet Baby Gang by shopping my merch: https://tinyurl.com/y5dscrmm

All the cool kids have newsletters, so I made one too. Sign up to get it every Friday here. Click here: http://www.mattwalshreport.com/

#MattWalsh #TheMattWalshShow #News #Politics #DailyWire #WhatIsAWoman

