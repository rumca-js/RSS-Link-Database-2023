# Source:Techaltar, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCtZO3K2p8mqFwiKWb9k7fXA, language:en-US

## What Marques Brownlee missed about Apple
 - [https://www.youtube.com/watch?v=KbX5Lrk_wrY](https://www.youtube.com/watch?v=KbX5Lrk_wrY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtZO3K2p8mqFwiKWb9k7fXA
 - date published: 2023-06-18 11:22:01+00:00

Marques' video: https://www.youtube.com/watch?v=kvN5_GXlg2Y

I agree about Apple not mentioning Virtual Reality due to a wish to differentiate from the competiton and to control the narrative. But I think there's more!

This video on Nebula: https://nebula.tv/videos/techaltar-what-marques-brownlee-missed-about-apple

 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► TechAltar links ◄◄◄  

Merch:  
http://enthusiast.store   

Social media:  
https://twitter.com/TechAltar  
https://instagram.com/TechAltar 
https://facebook.com/TechAltar  
https://discord.gg/npKQebe  

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► Attributions ◄◄◄  

Channel Music by Edemski: https://soundcloud.com/edemski
Other music by Epidemic Sound: http://epidemicsound.com/creator
Stock photos & videos from AP Archive, Getty & Storyblocks.

