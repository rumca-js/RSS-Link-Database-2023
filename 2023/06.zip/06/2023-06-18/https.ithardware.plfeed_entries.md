# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## Square Enix zapowiada premierową aktualizację do Final Fantasy XVI. Co wniesie?
 - [https://ithardware.pl/aktualnosci/square_enix_zapowiada_premierowa_aktualizacje_do_final_fantasy_xvi_co_wniesie-27870.html](https://ithardware.pl/aktualnosci/square_enix_zapowiada_premierowa_aktualizacje_do_final_fantasy_xvi_co_wniesie-27870.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-06-18 21:50:00+00:00

<img src="https://ithardware.pl/artykuly/min/27870_1.jpg" />            Square Enix początkowo nie zamierzało udostępniać premierowej aktualizacji do&nbsp;Final Fantasy XVI, aczkolwiek deweloperzy zmienili zdanie i jednak wydadzą pierwszą łatkę w dniu debiutu. Ma ona wyeliminować najpoważniejsze błędy, a także...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/square_enix_zapowiada_premierowa_aktualizacje_do_final_fantasy_xvi_co_wniesie-27870.html">https://ithardware.pl/aktualnosci/square_enix_zapowiada_premierowa_aktualizacje_do_final_fantasy_xvi_co_wniesie-27870.html</a></p>

## Google pozywa oszusta, który wystawiał fałszywe recenzje
 - [https://ithardware.pl/aktualnosci/google_pozywa_oszusta_ktory_wystawial_falszywe_recenzje-27869.html](https://ithardware.pl/aktualnosci/google_pozywa_oszusta_ktory_wystawial_falszywe_recenzje-27869.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-06-18 20:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/27869_1.jpg" />            Google walczy z osobą, kt&oacute;ra miała wprowadzać w błąd użytkownik&oacute;w platformy, publikując fałszywe recenzje. Oszust wykonywał konkretny plan zalania platformy wieloma nieprawdziwymi opiniami, co robił podszywając się pod...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/google_pozywa_oszusta_ktory_wystawial_falszywe_recenzje-27869.html">https://ithardware.pl/aktualnosci/google_pozywa_oszusta_ktory_wystawial_falszywe_recenzje-27869.html</a></p>

## Usługi Microsoftu padły ofiarą cyberataku
 - [https://ithardware.pl/aktualnosci/uslugi_microsoftu_padly_ofiara_cyberataku-27868.html](https://ithardware.pl/aktualnosci/uslugi_microsoftu_padly_ofiara_cyberataku-27868.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-06-18 18:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/27868_1.jpg" />            Microsoft na początku czerwca doznał poważnej awarii, kt&oacute;ra wpłynęła na usługi firmy takie jak&nbsp;Azure, Outlook i Teams. Korporacja z Redmond&nbsp;ujawniła teraz, że za globalną awarią stał cyberatak. Złagodzenie jego...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/uslugi_microsoftu_padly_ofiara_cyberataku-27868.html">https://ithardware.pl/aktualnosci/uslugi_microsoftu_padly_ofiara_cyberataku-27868.html</a></p>

## Obama i Microsoft chcą cyfrowych odcisków palców. Ma to pomóc w walce z dezinformacją
 - [https://ithardware.pl/aktualnosci/obama_i_microsoft_chca_cyfrowych_odciskow_palcow_ma_to_pomoc_w_walce_z_dezinformacja-27867.html](https://ithardware.pl/aktualnosci/obama_i_microsoft_chca_cyfrowych_odciskow_palcow_ma_to_pomoc_w_walce_z_dezinformacja-27867.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-06-18 17:35:00+00:00

<img src="https://ithardware.pl/artykuly/min/27867_1.jpg" />            Były prezydent Barack Obama wpadł na pomysł wprowadzenia &bdquo;cyfrowych odcisk&oacute;w palc&oacute;w&rdquo;, aby pom&oacute;c opinii publicznej rozr&oacute;żnić prawdziwe i fałszywe treści online.&nbsp;To ten sam pomysł, za kt&oacute;rym...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/obama_i_microsoft_chca_cyfrowych_odciskow_palcow_ma_to_pomoc_w_walce_z_dezinformacja-27867.html">https://ithardware.pl/aktualnosci/obama_i_microsoft_chca_cyfrowych_odciskow_palcow_ma_to_pomoc_w_walce_z_dezinformacja-27867.html</a></p>

## Dlaczego Elon Musk kupił Twittera? Jego odpowiedź może zaskoczyć
 - [https://ithardware.pl/aktualnosci/dlaczego_elon_musk_kupil_twittera_jego_odpowiedz_moze_zaskoczyc-27863.html](https://ithardware.pl/aktualnosci/dlaczego_elon_musk_kupil_twittera_jego_odpowiedz_moze_zaskoczyc-27863.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-06-18 16:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/27863_1.jpg" />            Elon Musk długo wahał się, czy kupić Twittera, jednak ostatecznie miliarder zdołał się przekonać i stał się właścicielem niebieskiej platformy społecznościowej. Szef SpaceX oraz Tesli wprowadził w serwisie swoje porządki i zaliczył kilka...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/dlaczego_elon_musk_kupil_twittera_jego_odpowiedz_moze_zaskoczyc-27863.html">https://ithardware.pl/aktualnosci/dlaczego_elon_musk_kupil_twittera_jego_odpowiedz_moze_zaskoczyc-27863.html</a></p>

## ChatGPT wygenerował mu klucze do Windowsa 10 Pro z nadzieją, że "pomoże to zasnąć"
 - [https://ithardware.pl/aktualnosci/chatgpt_wygenerowal_mu_klucze_do_windowsa_10_pro_z_nadzieja_ze_pomoze_to_zasnac-27865.html](https://ithardware.pl/aktualnosci/chatgpt_wygenerowal_mu_klucze_do_windowsa_10_pro_z_nadzieja_ze_pomoze_to_zasnac-27865.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-06-18 16:12:40+00:00

<img src="https://ithardware.pl/artykuly/min/27865_1.jpg" />            Microsoft raczej nie będzie zadowolony z tego odkrycia. Użytkownikom&nbsp;Twittera udało się wygenerować za pomocą ChatGPT oraz Google Bard og&oacute;lne klucze do system&oacute;w Windows 10 i Windows 11. Wiąże się z tym dość komiczne...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/chatgpt_wygenerowal_mu_klucze_do_windowsa_10_pro_z_nadzieja_ze_pomoze_to_zasnac-27865.html">https://ithardware.pl/aktualnosci/chatgpt_wygenerowal_mu_klucze_do_windowsa_10_pro_z_nadzieja_ze_pomoze_to_zasnac-27865.html</a></p>

## Pożar auta elektrycznego w Szwecji. Spłonęły 3 domy...
 - [https://ithardware.pl/aktualnosci/pozar_auta_elektrycznego_w_szwecji_splonely_3_domy-27866.html](https://ithardware.pl/aktualnosci/pozar_auta_elektrycznego_w_szwecji_splonely_3_domy-27866.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-06-18 15:30:40+00:00

<img src="https://ithardware.pl/artykuly/min/27866_1.jpg" />            O ile według statystyk auta elektryczne nie palą się częściej niż ich spalinowe odpowiedniki, to jednak właśnie EV są częstym gościem nagł&oacute;wk&oacute;w związanych z pożarami. Wszystko przez trudność w ich ugaszeniu oraz często...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/pozar_auta_elektrycznego_w_szwecji_splonely_3_domy-27866.html">https://ithardware.pl/aktualnosci/pozar_auta_elektrycznego_w_szwecji_splonely_3_domy-27866.html</a></p>

## Następna generacja procesorów Intela bliżej niż nam się wydaje? ASRock już zapewnił wsparcie
 - [https://ithardware.pl/aktualnosci/nastepna_generacja_procesorow_intela_blizej_niz_nam_sie_wydaje_asrock_juz_zapewnil_wsparcie-27861.html](https://ithardware.pl/aktualnosci/nastepna_generacja_procesorow_intela_blizej_niz_nam_sie_wydaje_asrock_juz_zapewnil_wsparcie-27861.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-06-18 15:23:10+00:00

<img src="https://ithardware.pl/artykuly/min/27861_1.jpg" />            Albo ASRock się pospieszył, albo premiera 14. generacji desktopowych procesor&oacute;w Intela jest bliżej niż nam się wydawało. Firma właśnie wypuściła aktualizację BIOS dla jednej ze swoich płyt gł&oacute;wnych. W opisie zmian możemy...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nastepna_generacja_procesorow_intela_blizej_niz_nam_sie_wydaje_asrock_juz_zapewnil_wsparcie-27861.html">https://ithardware.pl/aktualnosci/nastepna_generacja_procesorow_intela_blizej_niz_nam_sie_wydaje_asrock_juz_zapewnil_wsparcie-27861.html</a></p>

## Hasło do BIOS można ominąć... śrubokrętem
 - [https://ithardware.pl/aktualnosci/haslo_do_bios_mozna_ominac_srubokretem-27864.html](https://ithardware.pl/aktualnosci/haslo_do_bios_mozna_ominac_srubokretem-27864.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-06-18 14:50:50+00:00

<img src="https://ithardware.pl/artykuly/min/27864_1.jpg" />            Kiedy coś trzeba naprawić, pierwszym narzędziem po kt&oacute;re sięgamy, jest bardzo często śrubokręt. Z pewnością nie spodziewaliście się, że może on też posłużyć do... pominięcia hasła w BIOS.

Śrubokręt dokręci śrubkę i...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/haslo_do_bios_mozna_ominac_srubokretem-27864.html">https://ithardware.pl/aktualnosci/haslo_do_bios_mozna_ominac_srubokretem-27864.html</a></p>

## GeForce RTX 4090 z zegarem prawie 4,0 GHz. To absolutny rekord!
 - [https://ithardware.pl/aktualnosci/geforce_rtx_4090_z_zegarem_prawie_4_0_ghz_to_absolutny_rekord-27859.html](https://ithardware.pl/aktualnosci/geforce_rtx_4090_z_zegarem_prawie_4_0_ghz_to_absolutny_rekord-27859.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-06-18 14:40:00+00:00

<img src="https://ithardware.pl/artykuly/min/27859_1.jpg" />            CENS po raz kolejny pobił rekord. Niemiecki overclocker zn&oacute;w podjął się ekstremalnego podkręcenia topowej karty graficznej NVIDII. Tym razem GeForce'a RTX 4090 udało się zmusić do pracy z zegarem blisko 4,0 GHz. Aby przekroczyć tę...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/geforce_rtx_4090_z_zegarem_prawie_4_0_ghz_to_absolutny_rekord-27859.html">https://ithardware.pl/aktualnosci/geforce_rtx_4090_z_zegarem_prawie_4_0_ghz_to_absolutny_rekord-27859.html</a></p>

## Czy na Chromebooku da się pograć? Tak i to nie tylko w produkcje mobilne!
 - [https://ithardware.pl/artykuly/czy_na_chromebooku_da_sie_pograc_tak_i_to_nie_tylko_w_produkcje_mobilne-27862.html](https://ithardware.pl/artykuly/czy_na_chromebooku_da_sie_pograc_tak_i_to_nie_tylko_w_produkcje_mobilne-27862.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-06-18 14:05:54+00:00

<img src="https://ithardware.pl/artykuly/min/27862_1.jpg" />            Złożenie komputera do gier lub zakup gamingowego laptopa w sensownych pieniądzach to dziś nie lada sztuka. Jeszcze kilka lat temu mogliśmy bowiem zakupić naprawdę dobry komputer za ok. 2500 zł i cieszyć się świetną wydajnością w tym...
            <p>Pełna wersja strony <a href="https://ithardware.pl/artykuly/czy_na_chromebooku_da_sie_pograc_tak_i_to_nie_tylko_w_produkcje_mobilne-27862.html">https://ithardware.pl/artykuly/czy_na_chromebooku_da_sie_pograc_tak_i_to_nie_tylko_w_produkcje_mobilne-27862.html</a></p>

## Elon Musk i Neuralink w tym roku rozpoczną wszczepianie chipów ludziom
 - [https://ithardware.pl/aktualnosci/elon_musk_i_neuralink_w_tym_roku_rozpoczna_wszczepianie_chipow_ludziom-27860.html](https://ithardware.pl/aktualnosci/elon_musk_i_neuralink_w_tym_roku_rozpoczna_wszczepianie_chipow_ludziom-27860.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-06-18 13:40:50+00:00

<img src="https://ithardware.pl/artykuly/min/27860_1.jpg" />            Elon Musk oświadczył w piątek we Francji, że jego startup Neuralink, zajmujący się wszczepianiem chip&oacute;w do m&oacute;zgu, planuje rozpocząć w tym roku pierwsze testy na ludziach.

Neuralink chce rozpocząć testy na ludziach.

Podczas...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/elon_musk_i_neuralink_w_tym_roku_rozpoczna_wszczepianie_chipow_ludziom-27860.html">https://ithardware.pl/aktualnosci/elon_musk_i_neuralink_w_tym_roku_rozpoczna_wszczepianie_chipow_ludziom-27860.html</a></p>

## Apple M2 Ultra oskalpowany. Zobaczcie, co kryje się w środku
 - [https://ithardware.pl/aktualnosci/apple_m2_ultra_oskalpowany_zobaczcie_co_kryje_sie_w_srodku-27858.html](https://ithardware.pl/aktualnosci/apple_m2_ultra_oskalpowany_zobaczcie_co_kryje_sie_w_srodku-27858.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-06-18 13:09:10+00:00

<img src="https://ithardware.pl/artykuly/min/27858_1.jpg" />            Samo skalpowanie procesor&oacute;w to nie nowość. Nowością jest skalpowanie procesor&oacute;w Apple. Jeden z użytkownik&oacute;w Twittera podjął się tego zadania biorąc sobie za cel najnowszy i zarazem najmocniejszy chip Apple - M2 Ultra. Pod...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/apple_m2_ultra_oskalpowany_zobaczcie_co_kryje_sie_w_srodku-27858.html">https://ithardware.pl/aktualnosci/apple_m2_ultra_oskalpowany_zobaczcie_co_kryje_sie_w_srodku-27858.html</a></p>

## Binance podejrzewane o pranie brudnych pieniędzy. Fransuska prokuratura prowadzi śledztwo
 - [https://ithardware.pl/aktualnosci/binance_podejrzewane_o_pranie_brudnych_pieniedzy_fransuska_prokuratura_prowadzi_sledztwo-27857.html](https://ithardware.pl/aktualnosci/binance_podejrzewane_o_pranie_brudnych_pieniedzy_fransuska_prokuratura_prowadzi_sledztwo-27857.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-06-18 09:28:40+00:00

<img src="https://ithardware.pl/artykuly/min/27857_1.jpg" />            Największa giełda kryptowalut na świecie, Binance, jest przedmiotem dochodzenia prowadzonego przez paryską prokuraturę ze względu na podejrzenia nielegalnego pozyskiwania klient&oacute;w oraz prania brudnych pieniędzy.

Binance przeżywa...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/binance_podejrzewane_o_pranie_brudnych_pieniedzy_fransuska_prokuratura_prowadzi_sledztwo-27857.html">https://ithardware.pl/aktualnosci/binance_podejrzewane_o_pranie_brudnych_pieniedzy_fransuska_prokuratura_prowadzi_sledztwo-27857.html</a></p>

## Ktoś stworzył kartę GeForce RTX 2080 Ti z 44 GB pamięci GDDR6
 - [https://ithardware.pl/aktualnosci/ktos_stworzyl_karte_geforce_rtx_2080_ti_z_44_gb_pamieci_gddr6-27856.html](https://ithardware.pl/aktualnosci/ktos_stworzyl_karte_geforce_rtx_2080_ti_z_44_gb_pamieci_gddr6-27856.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-06-18 09:10:20+00:00

<img src="https://ithardware.pl/artykuly/min/27856_1.jpg" />            Niekt&oacute;rzy nie obawiają się eksperymentować i podejmować karkołomnych wyzwać, co często przynosi oszałamiające rezultaty. Jednym z takich śmiałk&oacute;w jest pasjonat, kt&oacute;ry podjął wyzwanie stworzenia karty graficznej GeForce...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/ktos_stworzyl_karte_geforce_rtx_2080_ti_z_44_gb_pamieci_gddr6-27856.html">https://ithardware.pl/aktualnosci/ktos_stworzyl_karte_geforce_rtx_2080_ti_z_44_gb_pamieci_gddr6-27856.html</a></p>

