# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Maygen and the Birdwatcher – three-song performance (live for The Current)
 - [https://www.youtube.com/watch?v=5U7PU6JkvvU](https://www.youtube.com/watch?v=5U7PU6JkvvU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2023-06-18 16:00:02+00:00

Maygen Lacey and Noah Neumann were playing in different bands when they met each other not long before the COVID-19 pandemic shut everything down. Each musician was looking to do something different, so they availed themselves of the downtime during the early part of the pandemic to write songs and put together a band.

That band — Maygen and the Birdwatcher — is the result. Their debut album, Moonshine, released in 2021, almost instantly earning the band accolades from the Midwest Country Music Awards for Album of the Year and Americana Artist of the Year).

Last October, Maygen and the Birdwatcher released the follow-up album, Bootleggin’ At The Flower Shoppe. The band visited The Current studio to play three songs for Radio Heartland. Watch the three-song performance above.

You can watch the full session, including the band's interview with host Mike Pengra, here: https://youtu.be/9cngC77KfZw 

Video Segments
00:00:00 Take It To The Garden
00:03:36 He Ain’t Me
00:07:45 Gunflint Lake

Credits
Guests – Maygen and the Birdwatcher
Host and Producer – Mike Pengra
Video Director – Derek Ramirez
Camera Operators – Derek Ramirez, Guillermo Bonilla
Audio – Evan Clark
Graphics – Natalia Toledo
Digital Producer – Luke Taylor

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube  

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1  

Like/Follow:
https://www.facebook.com/TheCurrent/  
https://twitter.com/TheCurrent  
https://www.instagram.com/thecurrent/
https://www.tiktok.com/@thecurrent.org

This activity is made possible in part by the Minnesota Legacy Amendment's Arts & Cultural Heritage Fund.

#maygenandthebirdwatcher #americana

