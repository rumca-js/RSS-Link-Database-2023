# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## Man cancelled by Amazon for racist doorbell gets account back, but no apology; DUMP ALEXA CRAP!
 - [https://www.youtube.com/watch?v=SyEgD-5GK9c](https://www.youtube.com/watch?v=SyEgD-5GK9c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2023-06-18 20:51:07+00:00

👉 https://www.home-assistant.io/
👉 https://medium.com/@bjax_/a-tale-of-unwanted-disruption-my-week-without-amazon-df1074e3818b
https://youtu.be/NfiIXooD77s
👉  https://medium.com/@bjax_/amazon-smart-home-lockout-update-the-dangers-of-dependence-infighting-and-narratives-hampering-2f11b329776e
🔵 Cheesy mugs & t-shirts: https://bit.ly/rossmannstore
👉 Rossmann chat: https://tinyurl.com/rossmatrix

## EU votes to mandate removable batteries in smartphones in a landslide; no more glued together junk!
 - [https://www.youtube.com/watch?v=Yn-R39-dtc0](https://www.youtube.com/watch?v=Yn-R39-dtc0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2023-06-18 15:52:31+00:00

https://www.europarl.europa.eu/RegData/docs_autres_institutions/commission_europeenne/com/2020/0798/COM_COM(2020)0798_EN.pdf

https://wccftech.com/new-eu-law-demands-replaceable-smartphone-batteries/

https://en.wikipedia.org/wiki/Samsung_Galaxy_S5#:~:text=The%20S5%20is%20IP67%20certified,for%20up%20to%2030%20minutes.

https://www.sonimtech.com/products/devices/xp10/#specifications

https://youtu.be/jfwKXjl5vJU
https://youtu.be/AUaJ8pDlxi8

🔵 Cheesy mugs & t-shirts: https://bit.ly/rossmannstore

👉 Rossmann chat: https://tinyurl.com/rossmatrix

👉 Equipment used:
🔵 Chair: https://amzn.to/3MjLrnT
🔵 Microphone: https://amzn.to/3g1hsok
🔵 Mic stand: https://amzn.to/3Vg47ZI
🔵 Audio interface: https://amzn.to/3VuKihx
🔵 Camera: https://amzn.to/3CTk1Av 
🔵 Lighting: https://amzn.to/3RSriGC

👉 Stream FAQ: https://store.rossmanngroup.com/faq.txt

👉 Affiliate:
› Buying on eBay? Support us while you shop! https://www.rossmanngroup.com/ebay
› Rossmann Repair Group Inc is a participant in the Amazon Services LLC Associates Program, an affiliate advertising program designed to provide a means for sites to earn advertising fees by advertising and linking to amazon.com

👉 Leave a tip for us via cryptocurrency if we've helped you out:
› Credit card: http://bit.ly/postamessage
› Bitcoin: 1EaEv8DBeFfg6fE6BimEmvEFbYLkhpcvhj
› Bitcoin Cash: qzwtptwa8h0wjjawr5fsm0ku8kf40amgqgm6lx4jxh
› Dash: XwQpZuvMvU44JT7C7Uh6xHvkSadzJw9fMN
› Dogecoin: DKetsoCvwa2hF29ssgUA4Wz4hxT4kj3KLU
› Ethereum: 0x6f6870feb48f08388ee345cf0261e2f03d2fa310
› Ethereum classic: 0x671bfd61ba87edf6365c97cea33d66ba73645510
› Litecoin: LWnbTTAjojZQt68ihFJFgQq3cYHUsTcyd7
› Verge: DFumZ5sMhi3JktLQpsTVtV9xUt3zKDrcZV
› Zcash: t1Ko3FkphQYoQroQc8k2DVk4WKMAbmNR8PH
› Zcoin: a8QdvArHmdRYe1MjiqtP6jDNe6Z4JgnRKZ

