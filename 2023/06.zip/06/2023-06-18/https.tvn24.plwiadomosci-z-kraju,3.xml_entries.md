# Source:TVN24 Z kraju, URL:https://tvn24.pl/wiadomosci-z-kraju,3.xml, language:pl-PL

## Rozłam w Trzeciej Drodze? Kosiniak-Kamysz: ci, którzy takie bajki tworzą, po prostu się nas boją
 - [https://tvn24.pl/polska/rozlam-w-trzeciej-drodze-wladyslaw-kosiniak-kamysz-o-wspolpracy-z-szymonem-holownia-i-polska-2050-7180826?source=rss](https://tvn24.pl/polska/rozlam-w-trzeciej-drodze-wladyslaw-kosiniak-kamysz-o-wspolpracy-z-szymonem-holownia-i-polska-2050-7180826?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-18 20:13:14+00:00

<img alt="Rozłam w Trzeciej Drodze? Kosiniak-Kamysz: ci, którzy takie bajki tworzą, po prostu się nas boją " src="https://tvn24.pl/najnowsze/cdn-zdjecie-sly0n4-wladyslaw-kosiniak-kamysz-podczas-uroczystego-odsloniecia-pomnika-wincentego-witosa-w-blaszkach-7180828/alternates/LANDSCAPE_1280" />
    Władysław Kosiniak-Kamysz, prezes PSL, odpowiedział na pojawiające się doniesienia o rozłamie w koalicji z Polską 2050. - Ci, którzy takie bajki tworzą, po prostu się nas boją. Strach przed Trzecią drogą, jak widać, ma ogromne oczy - stwierdził. - Nie szukajmy dziury w całym, bo jej nie ma - dodał.

## Niemiecki komisarz wzywa do wyciągnięcia konsekwencji. Co z koncertami Rammstein na Stadionie Olimpijskim?
 - [https://tvn24.pl/kultura-i-styl/zarzuty-wobec-wokalisty-rammstein-tilla-lindemanna-7180695?source=rss](https://tvn24.pl/kultura-i-styl/zarzuty-wobec-wokalisty-rammstein-tilla-lindemanna-7180695?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-18 19:28:35+00:00

<img alt="Niemiecki komisarz wzywa do wyciągnięcia konsekwencji. Co z koncertami Rammstein na Stadionie Olimpijskim?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lalunr-fani-przybywaja-na-koncert-niemieckiego-zespolu-rammstein-w-bernie-w-szwajcarii-zdjecie-z-17-czerwca-7180680/alternates/LANDSCAPE_1280" />
    Kolejne ciemne chmury nad zespołem Rammstein. Po tym, jak niemiecka prokuratura wszczęła śledztwo wobec wokalisty grupy Tilla Lindemanna Felix Klein, komisarz rządu federalnego Niemiec do spraw antysemityzmu, wezwał do wyciągnięcia konsekwencji w związku z zaplanowanymi koncertami zespołu. Ocenił za "wątpliwe, czy planowane koncerty Rammstein w Berlinie powinny odbywać się na Stadionie Olimpijskim".

## Wyborcze starcie PiS i PO. "Jacht, który w tej kampanii wyborczej coraz bardziej traci w żaglach"
 - [https://tvn24.pl/polska/wybory-parlamentarne-2023-rywalizacja-pis-u-i-platformy-obywatelskiej-tomasz-nalecz-i-krzysztof-lapinski-komentuja-7180721?source=rss](https://tvn24.pl/polska/wybory-parlamentarne-2023-rywalizacja-pis-u-i-platformy-obywatelskiej-tomasz-nalecz-i-krzysztof-lapinski-komentuja-7180721?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-18 18:37:23+00:00

<img alt="Wyborcze starcie PiS i PO. " src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-upy5gn-zrobimy-wszystko-aby-ta-palka-polityczna-na-koncu-uderzyla-tych-co-tak-haniebna-bronia-walcza-7146340/alternates/LANDSCAPE_1280" />
    Musimy przywyknąć, że ta kampania będzie ostra. To będzie kampania o wszystko, w cieniu starcia dwóch gigantów - tak o wyborczej rywalizacji, głównie między PiS-em a Platformą Obywatelską, mówił w "Faktach po Faktach" w TVN24 Krzysztof Łapiński, były rzecznik prezydenta Andrzeja Dudy. - PiS jest w sposób oczywisty w defensywie. To jest taki jacht, który w tej kampanii wyborczej coraz bardziej traci w żaglach - ocenił profesor Tomasz Nałęcz, były doradca prezydenta Bronisława Komorowskiego.

## Co tydzień rozdają potrzebującym ciepłe posiłki. "Często słyszymy, że to jest pierwszy posiłek tego dnia"
 - [https://fakty.tvn24.pl/zobacz-fakty/co-tydzien-rozdaja-potrzebujacym-cieple-posilki-czesto-slyszymy-ze-to-jest-pierwszy-posilek-tego-dnia-7180791?source=rss](https://fakty.tvn24.pl/zobacz-fakty/co-tydzien-rozdaja-potrzebujacym-cieple-posilki-czesto-slyszymy-ze-to-jest-pierwszy-posilek-tego-dnia-7180791?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-18 18:37:22+00:00

<img alt="Co tydzień rozdają potrzebującym ciepłe posiłki. " src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-unp1aw-co-tydzien-rozdaja-potrzebujacym-cieple-posilki-czesto-slyszymy-ze-to-jest-pierwszy-posilek-tego-dnia-7180803/alternates/LANDSCAPE_1280" />
    "Zupa na Głównym" - to akcja charytatywna w Poznaniu. Co tydzień - nie tylko po darmowy posiłek - ustawia się kolejka, a w niej osoby z problemami bezdomności samotności i biedy. Wzrost cen i inflacja jednak sprawiają, że z tygodnia na tydzień potrzebujących jest coraz więcej, a darczyńców mniej, więc pomagać jest trudniej.

## Choroba odbiera jej mowę i sprawność. Pomóc 2-letniej Lenie może kosztowny lek
 - [https://fakty.tvn24.pl/zobacz-fakty/choroba-odbiera-jej-mowe-i-sprawnosc-pomoc-2-letniej-lenie-moze-kosztowny-lek-7180703?source=rss](https://fakty.tvn24.pl/zobacz-fakty/choroba-odbiera-jej-mowe-i-sprawnosc-pomoc-2-letniej-lenie-moze-kosztowny-lek-7180703?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-18 18:15:20+00:00

<img alt="Choroba odbiera jej mowę i sprawność. Pomóc 2-letniej Lenie może kosztowny lek" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-vkcx3d-choroba-odbiera-jej-mowe-i-sprawnosc-pomoc-2-letniej-lenie-moze-kosztowny-lek-7180758/alternates/LANDSCAPE_1280" />
    Dwuletniej Lence choroba odbiera mowę i sprawność. Dziewczynka cierpi na Zespół Retta, czyli rzadką chorobę genetyczną, która dotyka wyłącznie dziewczynki. Choć choroba jest nieuleczalna, to w Stanach Zjednoczonych dopuszczono do stosowania lek spowalniający jej rozwój i Lenka może być pierwszym dzieckiem w Polsce, które go otrzyma. Dlatego liczy się każdy dzień i każda złotówka.

## Pogoda na jutro - poniedziałek 19.06. Po mglistej nocy przyjdzie gorący dzień
 - [https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-jutro-poniedzialek-1906-po-mglistej-nocy-przyjdzie-goracy-dzien-7180704?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-jutro-poniedzialek-1906-po-mglistej-nocy-przyjdzie-goracy-dzien-7180704?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-18 17:09:06+00:00

<img alt="Pogoda na jutro - poniedziałek 19.06. Po mglistej nocy przyjdzie gorący dzień" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qi9ciw-noc-chlodno-zimno-mgly-5400602/alternates/LANDSCAPE_1280" />
    Pogoda na jutro, czyli na poniedziałek 19.06. Nocą niebo nad Polską będzie się rozpogadzać, jednak miejscami wciąż wystąpią lokalne opady deszczu, a nad ranem również zamglenia. Dzień przyniesie nam na ogół pogodną aurę, ale nie wszędzie - w części kraju powrócą burze. Na termometrach zobaczymy nawet 29 stopni Celsjusza.

## Czy resort środowiska zrobił wszystko, by zapobiec katastrofie na Odrze? Ścieki wciąż są zrzucane do rzeki
 - [https://fakty.tvn24.pl/fakty-po-poludniu/czy-resort-srodowiska-zrobil-wszystko-by-zapobiec-katastrofie-na-odrze-scieki-wciaz-sa-zrzucane-do-rzeki-7180625?source=rss](https://fakty.tvn24.pl/fakty-po-poludniu/czy-resort-srodowiska-zrobil-wszystko-by-zapobiec-katastrofie-na-odrze-scieki-wciaz-sa-zrzucane-do-rzeki-7180625?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-18 16:01:46+00:00

<img alt="Czy resort środowiska zrobił wszystko, by zapobiec katastrofie na Odrze? Ścieki wciąż są zrzucane do rzeki" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-mk8uvb-pupiec-7180643/alternates/LANDSCAPE_1280" />
    Odra znowu jest zagrożona. Odławianych jest coraz więcej śniętych ryb i wszystko coraz bardziej przypomina sytuację z zeszłego roku, bo ścieki i zasolona woda wciąż lądują w rzece. Minister środowiska Anna Moskwa zapewnia, że jej resort zrobił wszystko, co się da, a tematem Odry zajmował się bardzo długo. Jednak zdaniem ekspertów zrobiono niewiele, by zapobiec kolejnej katastrofie.

## Zalążek tornada wirował nad miastem
 - [https://tvn24.pl/tvnmeteo/swiat/oklahoma-stany-zjednoczone-zalazek-tornada-wirowal-nad-miastem-7180575?source=rss](https://tvn24.pl/tvnmeteo/swiat/oklahoma-stany-zjednoczone-zalazek-tornada-wirowal-nad-miastem-7180575?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-18 15:25:40+00:00

<img alt="Zalążek tornada wirował nad miastem" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-5vsr8l-lej-kondensacyjny-nad-oklahoma-7180568/alternates/LANDSCAPE_1280" />
    Lej kondensacyjny pojawił się w sobotę nad zachodnią Oklahomą. Region od kilku dni nawiedzają gwałtowne burze, którym towarzyszą także tornada. Na skutek gwałtownej aury ponad 120 tysięcy mieszkańców stanu zostało bez dostępu do prądu.

## Łańcuch solidarności z więźniami politycznymi na Białorusi. "Przypominamy światu, że walka nadal trwa"
 - [https://tvn24.pl/bialystok/bialystok-zrobili-lancuch-solidarnosci-z-wiezniami-politycznymi-na-bialorusi-7180611?source=rss](https://tvn24.pl/bialystok/bialystok-zrobili-lancuch-solidarnosci-z-wiezniami-politycznymi-na-bialorusi-7180611?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-18 15:19:54+00:00

<img alt="Łańcuch solidarności z więźniami politycznymi na Białorusi. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-3849bc-zrobili-lancuch-solidarnosci-7180601/alternates/LANDSCAPE_1280" />
    Mieszkający w Białymstoku Białorusini zebrali się, aby przypomnieć o więźniach politycznych więzionych przez reżim Alaksandra Łukaszenki. Mówili, że za kratki można trafić na Białorusi nawet za kubek termiczny z symbolem Pogoni.

## Na tym przejściu autobus potrącił 10-latka. Mieszkańcy upominają się o poprawę bezpieczeństwa
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-na-przejsciu-na-ulicy-malborskiej-autobus-potracil-10-latka-beda-progi-spowalniajace-7177663?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-na-przejsciu-na-ulicy-malborskiej-autobus-potracil-10-latka-beda-progi-spowalniajace-7177663?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-18 14:50:52+00:00

<img alt="Na tym przejściu autobus potrącił 10-latka. Mieszkańcy upominają się o poprawę bezpieczeństwa" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-3ohtdn-na-przejsciu-przy-malborskiej-powstana-progi-spowalniajace-7177698/alternates/LANDSCAPE_1280" />
    Mieszkańcy pytają o dodatkowe zabezpieczenia na przejściu dla pieszych na ulicy Malborskiej, gdzie pod koniec marca autobus miejski potrącił 10-latka. - Chyba się nie spieszą - zarzuca urzędnikom rodzic, który codziennie odprowadza dziecko do pobliskiej szkoły. Władze dzielnicy tłumaczą: projekt jest, będą progi spowalniające, ale w nowym roku szkolnym.

## Całe miasta znalazły się pod wodą. Nie żyje 11 osób
 - [https://tvn24.pl/tvnmeteo/swiat/powodzie-w-brazylii-cale-miasta-znalazly-sie-pod-woda-nie-zyje-11-osob-7180508?source=rss](https://tvn24.pl/tvnmeteo/swiat/powodzie-w-brazylii-cale-miasta-znalazly-sie-pod-woda-nie-zyje-11-osob-7180508?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-18 14:00:24+00:00

<img alt="Całe miasta znalazły się pod wodą. Nie żyje 11 osób" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-t04vt8-po-ulewach-w-rio-grande-do-sul-7180554/alternates/LANDSCAPE_1280" />
    Cyklon pozatropikalny uderzył w południe Brazylii. Tereny prowincji Rio Grande do Sul zostały w piątek zalane przez ulewny deszcz, który spowodował podtopienia w wielu miastach. W powodziach zginęło co najmniej 11 osób, a 20 wciąż jest poszukiwanych.

## Hongkong. Uroczystości pogrzebowe zamordowanej modelki Abby Choi
 - [https://tvn24.pl/swiat/hongkong-morderstwo-modelki-abby-choi-uroczystosci-pogrzebowe-7180464?source=rss](https://tvn24.pl/swiat/hongkong-morderstwo-modelki-abby-choi-uroczystosci-pogrzebowe-7180464?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-18 13:56:19+00:00

<img alt="Hongkong. Uroczystości pogrzebowe zamordowanej modelki Abby Choi" src="https://tvn24.pl/najnowsze/cdn-zdjecie-epjf0p-uroczystosci-pogrzebowe-abby-choi-7180461/alternates/LANDSCAPE_1280" />
    Bliscy Abby Choi, modelki, której rozczłonkowane ciało znaleziono w lutym w domu na obrzeżach Hongkongu, zgromadzili się w niedzielę na czuwaniu poprzedzającym zaplanowane na kolejny dzień uroczystości pogrzebowe. O makabryczne morderstwo 28-letniej kobiety oskarżono jej byłego męża, jego ojca i brata.

## Obrazy łukaszowców wróciły do Polski z USA po 83 latach. Teraz obejrzymy je w mieście, w którym powstały
 - [https://tvn24.pl/bialystok/kazimierz-dolny-obrazy-lukaszowcow-wrocily-do-polski-z-usa-po-83-latach-teraz-obejrzymy-tam-gdzie-powstaly-7180243?source=rss](https://tvn24.pl/bialystok/kazimierz-dolny-obrazy-lukaszowcow-wrocily-do-polski-z-usa-po-83-latach-teraz-obejrzymy-tam-gdzie-powstaly-7180243?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-18 13:35:55+00:00

<img alt="Obrazy łukaszowców wróciły do Polski z USA po 83 latach. Teraz obejrzymy je w mieście, w którym powstały " src="https://tvn24.pl/najnowsze/cdn-zdjecie-qr2rk5-wystawa-zostanie-otwarta-w-poniedzialek-19-czerwca-mozna-bedzie-ja-ogladac-do-6-sierpnia-7180382/alternates/LANDSCAPE_1280" />
    Każdy z siedmiu obrazów, które stworzyli, przedstawia ważne wydarzenie z dziejów Polski. Pracowali po 10-12 godzin dziennie. Malowali wspólnie. Mowa o tzw. łukaszowcach, czyli artystach związanych z Bractwem św. Łukasza, których prace były w 1939 roku prezentowane w pawilonie polskim na nowojorskiej Wystawie Światowej. Obrazy wróciły do Polski po 83 latach. Teraz obejrzymy je w Muzeum Nadwiślańskim w Kazimierzu Dolnym (woj. lubelskie), czyli w mieście, w którym powstały.

## Światowe Forum Ekonomiczne chce "przepisania na nowo Biblii"? Co powiedział Harari
 - [https://konkret24.tvn24.pl/swiat/swiatowe-forum-ekonomiczne-chce-przepisania-na-nowo-biblii-co-powiedzial-harari-7175003?source=rss](https://konkret24.tvn24.pl/swiat/swiatowe-forum-ekonomiczne-chce-przepisania-na-nowo-biblii-co-powiedzial-harari-7175003?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-18 13:23:21+00:00

<img alt="Światowe Forum Ekonomiczne chce " src="https://tvn24.pl/najnowsze/cdn-zdjecie-nk95jb-wef-rzekomo-chce-przepisania-na-nowo-biblii-7175005/alternates/LANDSCAPE_1280" />
    Światowe Forum Ekonomiczne ma rzekomo wzywać do przepisania Biblii przez sztuczną inteligencję, żeby stworzyć "poprawne religie". Dowodem na te plany ma być niedawny wywiad z profesorem Yuvalem Noah Hararim. Tylko że cała ta teoria powstała z przeinaczenia wypowiedzi izraelskiego filozofa.

## "SOS dla psychiatrii dzieci i młodzieży". Ulicami Warszawy przeszedł Marsz Żółtej Wstążki
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-sos-dla-psychiatrii-dzieci-i-mlodziezy-ulicami-stolicy-przeszedl-marsz-zoltej-wstazki-7180358?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-sos-dla-psychiatrii-dzieci-i-mlodziezy-ulicami-stolicy-przeszedl-marsz-zoltej-wstazki-7180358?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-18 12:34:56+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-uyorny-marsz-zoltej-wstazki-w-warszawie-7180450/alternates/LANDSCAPE_1280" />
    Przez stolicę po raz siódmy przeszedł Marsz Żółtej Wstążki. Jego uczestnicy domagają się poprawy w zakresie opieki psychiatrycznej i psychologicznej dzieci i młodzieży. Demonstracja przeszła sprzed budynku Ministerstwa Zdrowia do siedziby resortu edukacji.

## Z zoo uciekł lampart. "Ewakuowano wszystkich odwiedzających"
 - [https://tvn24.pl/tvnmeteo/swiat/bulgaria-z-zoo-uciekl-lampart-ewakuowano-wszystkich-odwiedzajacych-7180400?source=rss](https://tvn24.pl/tvnmeteo/swiat/bulgaria-z-zoo-uciekl-lampart-ewakuowano-wszystkich-odwiedzajacych-7180400?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-18 12:32:38+00:00

<img alt="Z zoo uciekł lampart. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-lthgfj-lampart-shutterstock_119994838-7180465/alternates/LANDSCAPE_1280" />
    Lampart o imieniu Dante uciekł w niedzielę podczas karmienia z zoo położonego w bułgarskim mieście Stara Zagora. Zwierzęcia poszukiwała policja i straż pożarna, a na czas akcji konieczne było zamknięcie obiektu.

## Napadli na salon gier, mieli przedmiot przypominający broń. Sprawcy zatrzymani
 - [https://tvn24.pl/pomorze/gdynia-napadli-na-salon-gier-sprawcy-zatrzymani-7180423?source=rss](https://tvn24.pl/pomorze/gdynia-napadli-na-salon-gier-sprawcy-zatrzymani-7180423?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-18 12:21:30+00:00

<img alt="Napadli na salon gier, mieli przedmiot przypominający broń. Sprawcy zatrzymani" src="https://tvn24.pl/najnowsze/cdn-zdjecie-m4b5to-policja-7180841/alternates/LANDSCAPE_1280" />
    Z przedmiotem przypominającym broń dwóch mężczyzn napadło na jeden z gdyńskich salonów gier. Sprawców uwiecznił monitoring, a w niedzielny wieczór zatrzymała ich policja. Na razie nie ujawniono okoliczności ujęcia podejrzanych.

## Napadli na salon gier, mieli przedmiot przypominający broń. Są poszukiwani przez policję
 - [https://tvn24.pl/pomorze/gdynia-napadli-na-salon-gier-sprawcy-poszukiwani-przez-policje-7180423?source=rss](https://tvn24.pl/pomorze/gdynia-napadli-na-salon-gier-sprawcy-poszukiwani-przez-policje-7180423?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-18 12:21:30+00:00

<img alt="Napadli na salon gier, mieli przedmiot przypominający broń. Są poszukiwani przez policję" src="https://tvn24.pl/pomorze/cdn-zdjecie-hkqkv6-napadli-na-salon-gier-sprawcy-poszukiwani-przez-policje-7180414/alternates/LANDSCAPE_1280" />
    Z przedmiotem przypominającym broń dwóch mężczyzn napadło na jeden z gdyńskich salonów gier. Sprawców uwiecznił monitoring. Policja publikuje zdjęcie i prosi o pomoc w rozpoznaniu poszukiwanych.

## W zagrodzie pokazowej w Mucznem urodziła się żubrza dziewczynka. To trzecie narodziny w tym roku
 - [https://tvn24.pl/krakow/stuposiany-w-zagrodzie-pokazowej-w-mucznem-urodzila-sie-zubrza-dziewczynka-7180377?source=rss](https://tvn24.pl/krakow/stuposiany-w-zagrodzie-pokazowej-w-mucznem-urodzila-sie-zubrza-dziewczynka-7180377?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-18 12:02:34+00:00

<img alt="W zagrodzie pokazowej w Mucznem urodziła się żubrza dziewczynka. To trzecie narodziny w tym roku" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2pxmx5-w-zagrodzie-pokazowej-w-mucznem-na-swiat-przyszla-zubrzyca-7180396/alternates/LANDSCAPE_1280" />
    W zagrodzie pokazowej w Mucznem w Nadleśnictwie Stuposiany (woj. podkarpackie) przyszła na świat żubrza dziewczynka. To trzecie narodziny w tym roku. Imiona dla młodych żubrów leśnicy wybiorą w konkursie.

## Wyciek amoniaku na Ursynowie
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-wyciek-amoniaku-na-ursynowie-7180411?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-wyciek-amoniaku-na-ursynowie-7180411?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-18 11:57:10+00:00

<img alt="Wyciek amoniaku na Ursynowie" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-bi59q4-wyciek-amoniaku-na-ursynowie-7180428/alternates/LANDSCAPE_1280" />
    W niedzielę w południe straż pożarna, w tym grupa chemiczna, interweniowała na Ursynowie. Doszło do wycieku amoniaku ze starej instalacji przy lodowisku.

## Pandka ruda uciekła z wybiegu. "Ponzu postanowił pozwiedzać okoliczne drzewa". Pomogli strażacy
 - [https://tvn24.pl/pomorze/gdansk-pandka-ruda-uciekla-ze-swojego-wybiegu-w-zoo-do-akcji-zaangazowano-strazakow-7180107?source=rss](https://tvn24.pl/pomorze/gdansk-pandka-ruda-uciekla-ze-swojego-wybiegu-w-zoo-do-akcji-zaangazowano-strazakow-7180107?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-18 11:12:35+00:00

<img alt="Pandka ruda uciekła z wybiegu. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-a5egc4-pandka-ruda-zdjecie-ilustracyjne-7180098/alternates/LANDSCAPE_1280" />
    Samiec pandki rudej z Gdańskiego Ogrodu Zoologicznego podjął drugą w tym roku próbę ucieczki. Uciekł ze swojego wybiegu i wspiął się na pobliskie drzewo. W akcji ratunkowej musiał pomóc strażacki podnośnik.

## Kilkaset ewakuowanych, zalane domy i uszkodzone mosty
 - [https://tvn24.pl/tvnmeteo/swiat/serbia-bulgaria-powodzie-kilkaset-ewakuowanych-zalane-domy-i-uszkodzone-mosty-7180119?source=rss](https://tvn24.pl/tvnmeteo/swiat/serbia-bulgaria-powodzie-kilkaset-ewakuowanych-zalane-domy-i-uszkodzone-mosty-7180119?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-18 11:05:47+00:00

<img alt="Kilkaset ewakuowanych, zalane domy i uszkodzone mosty" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-zh85md-powodzie-7180250/alternates/LANDSCAPE_1280" />
    Powodzie, które były następstwem ulewnych deszczy, zmusiły serbskie władze do ogłoszenia w kilkudziesięciu gminach stanu nadzwyczajnego. Żywioł doprowadził do zerwania się dwóch mostów, ewakuowano ponad 200 osób. Gwałtowana aura daje się we znaki również w Bułgarii. W Sofii zalanych zostało setki domów i piwnic.

## "Zatrzymany" na Lotnisku Chopina samolot z południowoafrykańską delegacją odleciał do RPA
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-zatrzymany-na-lotnisku-chopina-samolot-z-poludniowoafrykanska-delegacja-odlecial-do-pretorii-7180295?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-zatrzymany-na-lotnisku-chopina-samolot-z-poludniowoafrykanska-delegacja-odlecial-do-pretorii-7180295?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-18 11:04:47+00:00

<img alt="" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-vvn6gf-lotnisko-chopina-zdjecie-ilustracyjne-6884239/alternates/LANDSCAPE_1280" />
    W niedzielę przed południem z Lotniska Chopina odleciał do Pretorii samolot z członkami delegacji prezydenta Republiki Południowej Afryki. Maszyna przyleciała do Warszawy w czwartek. - Członkowie delegacji mieli ze sobą broń, ale nie mieli pozwolenia na jej wwóz do Polski - informowała rzeczniczka prasowa Straży Granicznej.

## Słychać pierwsze grzmoty. Sprawdź, gdzie jest burza
 - [https://tvn24.pl/tvnmeteo/pogoda/gdzie-jest-burza-burze-w-polsce-w-niedziele-1806-mapa-i-radar-burz-sprawdz-gdzie-jest-burza-7180191?source=rss](https://tvn24.pl/tvnmeteo/pogoda/gdzie-jest-burza-burze-w-polsce-w-niedziele-1806-mapa-i-radar-burz-sprawdz-gdzie-jest-burza-7180191?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-18 09:17:19+00:00

<img alt="Słychać pierwsze grzmoty. Sprawdź, gdzie jest burza" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-v639i4-wyladowania-atmosferyczne-nad-polska-o-godzinie-1105-7180196/alternates/LANDSCAPE_1280" />
    Gdzie jest burza? W niedzielę nad częścią Polski pojawiają się wyładowania atmosferyczne. Zjawiskom towarzyszą porywy wiatru osiągające prędkość do 40-50 kilometrów na godzinę. Sprawdź, gdzie jest burza, i śledź aktualną sytuację pogodową w kraju na tvnmeteo.pl.

## Ranking najpiękniejszych plaż. Lider utrzymał swoją pozycję
 - [https://tvn24.pl/biznes/turystyka/wakacje-2023-wlochy-najpiekniejsze-plaze-najwiecej-lokalizacji-na-sardynii-7180113?source=rss](https://tvn24.pl/biznes/turystyka/wakacje-2023-wlochy-najpiekniejsze-plaze-najwiecej-lokalizacji-na-sardynii-7180113?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-18 08:48:44+00:00

<img alt="Ranking najpiękniejszych plaż. Lider utrzymał swoją pozycję" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qzqeaf-sardynia-wlochy-plaza-shutterstock_2212251853-7180130/alternates/LANDSCAPE_1280" />
    Włoskie stowarzyszenie ekologów Legambiente i Włoski Klub Turystyczny potwierdziły w tym roku prymat Sardynii w rankingu na najpiękniejsze kurorty nadmorskie. W czołówce są też Toskania, Apulia, Kampania i Sycylia. Nagrodzono też 12 ośrodków nad jeziorami. Najczęściej nagradzanym regionem jest Trydent-Górna Adyga. Ale jest też nowa lokalizacja - jezioro Scanno w Abruzji.

## Wjechał w sygnalizator, który przewrócił się na inne auto
 - [https://tvn24.pl/tvnwarszawa/najnowsze/lomianki-uderzyl-w-sygnalizator-ktory-przewrocil-sie-na-inny-pojazd-kierowca-byl-pijany-7180131?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/lomianki-uderzyl-w-sygnalizator-ktory-przewrocil-sie-na-inny-pojazd-kierowca-byl-pijany-7180131?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-18 08:30:29+00:00

<img alt="Wjechał w sygnalizator, który przewrócił się na inne auto" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9nmlcq-do-wypadku-doszlo-w-lomiankach-7180138/alternates/LANDSCAPE_1280" />
    W niedzielę rano na drodze krajowej nr 7 w Łomiankach doszło do wypadku. Kierowca auta osobowego uderzył sygnalizator, który przewrócił się na inny pojazd. Mężczyzna był pijany. Trafił do szpitala. Są utrudnienia w ruchu.

## Remont wiaduktów Trasy Łazienkowskiej coraz bliżej. Zaczną od wyłączenia wewnętrznych pasów
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-remont-wiaduktow-trasy-lazienkowskiej-od-poniedzialku-19-czerwca-zmiany-w-ruchu-7178255?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-remont-wiaduktow-trasy-lazienkowskiej-od-poniedzialku-19-czerwca-zmiany-w-ruchu-7178255?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-18 08:17:39+00:00

<img alt="Remont wiaduktów Trasy Łazienkowskiej coraz bliżej. Zaczną od wyłączenia wewnętrznych pasów" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-b1sbyh-wyremontuja-wiadukty-trasy-lazienkowskiej-7178252/alternates/LANDSCAPE_1280" />
    W poniedziałek, 19 czerwca rozpoczną się prace, które umożliwią rozpoczęcie przebudowy wiaduktów Trasy Łazienkowskiej na Saskiej Kępie. Spowoduje to wyłączenie - na około dwa tygodnie - wewnętrznych pasów jezdni nad ulicami Bajońską i Paryską - zapowiadają drogowcy.

## Przyszły tydzień przyniesie upał i burze. Prognoza alertów IMGW
 - [https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-burze-z-gradem-upal-prognoza-alertow-7179982?source=rss](https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-burze-z-gradem-upal-prognoza-alertow-7179982?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-18 04:32:55+00:00

<img alt="Przyszły tydzień przyniesie upał i burze. Prognoza alertów IMGW" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-1rgna1-upal-w-polsce-goraco-7166691/alternates/LANDSCAPE_1280" />
    IMGW wydał prognozę zagrożeń meteorologicznych. W przyszłym tygodniu w części kraju zapanuje upał - alerty przed nim mogą obowiązywać nawet w siedmiu województwach. Niebezpieczeństwo mogą stanowić także burze z gradem.

## Pogoda na dziś - niedziela 18.06. W części kraju powrócą burze
 - [https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-dzis-niedziela-1806-w-czesci-kraju-powroca-burze-7179914?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-dzis-niedziela-1806-w-czesci-kraju-powroca-burze-7179914?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-06-18 00:00:00+00:00

<img alt="Pogoda na dziś - niedziela 18.06. W części kraju powrócą burze" src="https://tvn24.pl/najnowsze/cdn-zdjecie-v2jmrv-burze-7161766/alternates/LANDSCAPE_1280" />
    Pogoda na dziś. Niedziela 18.06 w całym kraju zapowiada się pochmurno. Miejscami przydadzą się parasole, a w niektórych regionach będziemy musieli uważać na burze z gradem. Warunki biometeorologiczne okażą się przeważnie neutralne, niekorzystne jedynie w wąskim pasie wschodniej Polski.

