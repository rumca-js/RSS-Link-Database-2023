# Source:pcgamer, URL:http://www.pcgamer.com/rss, language:en-US

## One of Rockstar's cofounders is finally teasing what's next with a music video and a big ole' creepy eyeball
 - [https://www.pcgamer.com/one-of-rockstars-cofounders-is-finally-teasing-whats-next-with-a-music-video-and-a-big-ole-creepy-eyeball](https://www.pcgamer.com/one-of-rockstars-cofounders-is-finally-teasing-whats-next-with-a-music-video-and-a-big-ole-creepy-eyeball)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-06-18 21:40:55+00:00

The ventures are certainly absurd.

## I'm hoping against hope that Cyberpunk 2077's expansion overhaul will finally fix the game's lingering mechanics malaise
 - [https://www.pcgamer.com/im-hoping-against-hope-that-cyberpunk-2077s-expansion-overhaul-will-finally-fix-the-games-lingering-mechanics-malaise](https://www.pcgamer.com/im-hoping-against-hope-that-cyberpunk-2077s-expansion-overhaul-will-finally-fix-the-games-lingering-mechanics-malaise)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-06-18 19:56:44+00:00

I've always loved this game, but it's never felt quite right.

## Here's space corporations doing things they shouldn't in the Aliens: Dark Descent story trailer
 - [https://www.pcgamer.com/heres-space-corporations-doing-things-they-shouldnt-in-the-aliens-dark-descent-story-trailer](https://www.pcgamer.com/heres-space-corporations-doing-things-they-shouldnt-in-the-aliens-dark-descent-story-trailer)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-06-18 19:25:51+00:00

Up to their usual tricks in this Aliens squad RTS.

## Gunpowder soulslike Flintlock delayed into 2024
 - [https://www.pcgamer.com/gunpowder-soulslike-flintlock-delayed-into-2024](https://www.pcgamer.com/gunpowder-soulslike-flintlock-delayed-into-2024)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-06-18 17:34:04+00:00

You'll have to wait longer to shoot the gods.

## Humble is offering the motherlode of Destiny lore ebooks for just $9
 - [https://www.pcgamer.com/humble-is-offering-the-motherlode-of-destiny-lore-ebooks-for-just-dollar9](https://www.pcgamer.com/humble-is-offering-the-motherlode-of-destiny-lore-ebooks-for-just-dollar9)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-06-18 17:31:27+00:00

Hey, this stuff is pretty neat.

## World of Horror will actually finally release in October
 - [https://www.pcgamer.com/world-of-horror-will-actually-finally-release-in-october](https://www.pcgamer.com/world-of-horror-will-actually-finally-release-in-october)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-06-18 16:33:27+00:00

The cult horror roguelike RPG will be done. Finally.

## Skyrim mod gives you a fully voiced ex-Thalmor companion
 - [https://www.pcgamer.com/skyrim-mod-gives-you-a-fully-voiced-ex-thalmor-companion](https://www.pcgamer.com/skyrim-mod-gives-you-a-fully-voiced-ex-thalmor-companion)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-06-18 07:19:52+00:00

Maybe don't put an arrow in this one immediately.

## Great moments in PC gaming: Transforming a hero into something bizarre in Wildermyth
 - [https://www.pcgamer.com/great-moments-in-pc-gaming-transforming-a-hero-into-something-bizarre-in-wildermyth](https://www.pcgamer.com/great-moments-in-pc-gaming-transforming-a-hero-into-something-bizarre-in-wildermyth)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-06-18 05:35:00+00:00

Sylvan leg? Crow head? Yes to these and more.

## Today's Wordle hint and answer #729: Sunday, June 18
 - [https://www.pcgamer.com/wordle-answer-today-hint-729-june-18](https://www.pcgamer.com/wordle-answer-today-hint-729-june-18)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-06-18 04:07:44+00:00

A hint to help you out and today's Wordle answer if you need it.

## Get sci-fi spy sim Sigma Theory free this weekend
 - [https://www.pcgamer.com/get-sci-fi-spy-sim-sigma-theory-free-this-weekend](https://www.pcgamer.com/get-sci-fi-spy-sim-sigma-theory-free-this-weekend)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-06-18 02:49:29+00:00

Add it to your account for zero dollars for a limited time.

## The best sex games to play in 2023
 - [https://www.pcgamer.com/best-sex-games](https://www.pcgamer.com/best-sex-games)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-06-18 00:25:27+00:00

Sex games that aren't garbage.

## One of the OG System Shock's devs is streaming the remake: 'We see our feet,  never coulda done that in 1994'
 - [https://www.pcgamer.com/one-of-the-og-system-shocks-devs-is-streaming-the-remake-we-see-our-feet-never-coulda-done-that-in-1994](https://www.pcgamer.com/one-of-the-og-system-shocks-devs-is-streaming-the-remake-we-see-our-feet-never-coulda-done-that-in-1994)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-06-18 00:07:59+00:00

Marc LeBlanc was a longtime Looking Glass employee who worked on System Shock and Thief.

