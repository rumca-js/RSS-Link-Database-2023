# Source:penguinz0, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg, language:en-US

## I Speedran Only Up! and It Was Awful
 - [https://www.youtube.com/watch?v=CvNBYKXge9s](https://www.youtube.com/watch?v=CvNBYKXge9s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg
 - date published: 2023-06-18 20:00:02+00:00

This is the greatest upwards speedrun of All Time
Merch https://moistglobal.com/

## The Official Podcast Episode #341: Our Biggest Argument Yet
 - [https://www.youtube.com/watch?v=BZsk6kC3GRc](https://www.youtube.com/watch?v=BZsk6kC3GRc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg
 - date published: 2023-06-18 16:00:10+00:00

Four close man friends gather around to talk about Fred Weasley.

This is the Official Podcast. Every Monday at 7pm EST. Links Below.

---

Get additional episodes and bonus content with early access:
go to https://www.PATREON.com/THEOFFICIALPODCAST

Brought to you by the following sponsors:

GET THE HARRYS CRAFT HANDLE STARTER SET FOR $10:
go to https://www.HARRYS.com/OFFICIAL

GET 20% OFF YOUR FITBOD SUBSCRIPTION:
go to https://www.FITBOD.me/OFFICIAL

GET 2O% OFF ALL HELIX MATTRESSES AND TWO FREE PILLOWS:
go to https://www.HELIXSLEEP.com/OFFICIAL

GET GODSLAP AND PLAGUE SEEKER RIGHT NOW:
go to https://www.BADEGG.co

---

Timestamps:

00:00 - Intro
00:30 - Jackson is Sick / More About the UK
13:17 - English Food
19:02 - Advertisements
25:27 - Getting Sick
26:24 - Haunted Houses & Ghosts
33:27 - New Transformers Film / Toys
38:02 - The Great Harry Potter Debate 
01:04:39 - Reddit Going Dark 
01:12:31 - r/truerateme 
01:21:07 - Dream’s Reverse Face Reveal
01:28:45 - WrapUp

---

Hosts: 

Jackson: https://twitter.com/zealotonpc 
Andrew: https://twitter.com/huggbeestv 
Charlie: https://twitter.com/moistcr1tikal 
Kaya: https://twitter.com/kayaorsan

---

The Official Podcast Links: 

SubReddit: https://reddit.com/r/theofficialpodcast 
Google Play: https://play.google.com/music/m/Iv4af... 
Google Podcasts: https://www.google.com/podcasts?feed=... 
Spotify: https://open.spotify.com/show/6TXzjtM... 
iTunes: https://itunes.apple.com/au/podcast/t... 
Patreon: https://www.patreon.com/theofficialpo...
Intro by: derpmii  
Music by: https://soundcloud.com/inst1nctive
Thumbnail by: https://www.instagram.com/nook_eilyk/

## Redditors Gave Up
 - [https://www.youtube.com/watch?v=sNFkHWsGM4Y](https://www.youtube.com/watch?v=sNFkHWsGM4Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg
 - date published: 2023-06-18 00:00:31+00:00

This is the greatest reddit outcome of All Time
Merch https://moistglobal.com/

