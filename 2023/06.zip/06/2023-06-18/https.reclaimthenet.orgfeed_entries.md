# Source:Reclaim The Net, URL:https://reclaimthenet.org/feed/, language:en-US

## London Food Bank Users Face Biometric Face Scanning
 - [https://reclaimthenet.org/london-food-bank-users-face-biometric-face-scanning](https://reclaimthenet.org/london-food-bank-users-face-biometric-face-scanning)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-06-18 16:03:56+00:00

<a href="https://reclaimthenet.org/london-food-bank-users-face-biometric-face-scanning" rel="nofollow" title="London Food Bank Users Face Biometric Face Scanning"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/06/food-bank-uk-face-scan.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Invasive.</p>
<p>The post <a href="https://reclaimthenet.org/london-food-bank-users-face-biometric-face-scanning" rel="nofollow">London Food Bank Users Face Biometric Face Scanning</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Mike Tyson Posts Censored Interview With RFK JR. On Rumble After YouTube Censorship
 - [https://reclaimthenet.org/mike-tyson-rumble](https://reclaimthenet.org/mike-tyson-rumble)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-06-18 02:33:15+00:00

<a href="https://reclaimthenet.org/mike-tyson-rumble" rel="nofollow" title="Mike Tyson Posts Censored Interview With RFK JR. On Rumble After YouTube Censorship"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/06/rfk-tyson-rumble.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Big names are making the switch.</p>
<p>The post <a href="https://reclaimthenet.org/mike-tyson-rumble" rel="nofollow">Mike Tyson Posts Censored Interview With RFK JR. On Rumble After YouTube Censorship</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

