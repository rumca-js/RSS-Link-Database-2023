# Source:Wirtualne Media, URL:https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml, language:pl-PL

## Polacy mają coraz większe problemy ze zdrowiem psychicznym
 - [https://www.wirtualnemedia.pl/artykul/polacy-maja-coraz-wieksze-problemy-ze-zdrowiem-psychicznym](https://www.wirtualnemedia.pl/artykul/polacy-maja-coraz-wieksze-problemy-ze-zdrowiem-psychicznym)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-06-18 06:29:51.447623+00:00

Statystycznie przyjmuje się, że około 25 proc. społeczeństwa miało, ma lub będzie mieć problemy emocjonalne, które wymagają wsparcia ze strony profesjonalistów - powiedział prezes fundacji eFkropka, terapeuta środowiskowy Polskiego Towarzystwa Psychiatrycznego i psychoterapeuta Jerzy Kłoskowski.

