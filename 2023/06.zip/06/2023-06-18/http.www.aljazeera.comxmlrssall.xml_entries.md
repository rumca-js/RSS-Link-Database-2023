# Source:Aljazeera, URL:http://www.aljazeera.com/xml/rss/all.xml, language:en-US

## Qatari companies partner with Iraq on $9.5bn worth of projects
 - [https://www.aljazeera.com/news/2023/6/18/qatari-companies-partner-with-iraq-on-9-5bn-worth-of-projects](https://www.aljazeera.com/news/2023/6/18/qatari-companies-partner-with-iraq-on-9-5bn-worth-of-projects)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-18 20:25:55+00:00

Projects include the construction of power plants that will reduce Iraq&#039;s reliance on Iran for its energy needs.

## Russia and Ukraine suffer heavy losses as front-line battles rage
 - [https://www.aljazeera.com/news/2023/6/18/russia-and-ukraine-suffer-heavy-losses-as-front-line-battles-rage](https://www.aljazeera.com/news/2023/6/18/russia-and-ukraine-suffer-heavy-losses-as-front-line-battles-rage)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-18 20:20:19+00:00

Ukraine&#039;s counteroffensive continues with small advances as Russia conducts &#039;effective&#039; defensive operations.

## Tunisia protesters demand release of ‘political prisoners’
 - [https://www.aljazeera.com/news/2023/6/18/tunisia-protesters-demand-the-release-of-political-prisoners](https://www.aljazeera.com/news/2023/6/18/tunisia-protesters-demand-the-release-of-political-prisoners)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-18 19:39:19+00:00

Some 300 demonstrators in Tunis demanded freedom for former ministers, businessmen and other opposition members.

## Can China and the US mend their troubled relations?
 - [https://www.aljazeera.com/program/inside-story/2023/6/18/can-china-and-the-us-mend-their-troubled-relations](https://www.aljazeera.com/program/inside-story/2023/6/18/can-china-and-the-us-mend-their-troubled-relations)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-18 18:46:28+00:00

The United States&#039; top diplomat flew to Beijing aiming to ease months of tension.

## Israel to ramp up settlement expansion in occupied West Bank
 - [https://www.aljazeera.com/news/2023/6/18/israeli-minister-given-sweeping-settlement-building-powers](https://www.aljazeera.com/news/2023/6/18/israeli-minister-given-sweeping-settlement-building-powers)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-18 15:47:06+00:00

The finance minister was granted sweeping powers to expedite construction, bypassing measures in place for 27 years.

## My imprisoned father is the freest man I know
 - [https://www.aljazeera.com/opinions/2023/6/18/my-imprisoned-father-is-the-freest-man-i-know](https://www.aljazeera.com/opinions/2023/6/18/my-imprisoned-father-is-the-freest-man-i-know)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-18 14:29:59+00:00

My father was detained in the crackdown on dissent in Tunisia. He could have fled but chose to stand up to dictatorship.

## Pakistan arrests suspected traffickers after refugee boat tragedy
 - [https://www.aljazeera.com/news/2023/6/18/pakistan-arrests-suspected-traffickers-after-refugee-boat-tragedy](https://www.aljazeera.com/news/2023/6/18/pakistan-arrests-suspected-traffickers-after-refugee-boat-tragedy)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-18 12:13:21+00:00

Authorities vowed the 10 suspected human traffickers they arrested would be &#039;severely punished&#039;.

## Grieving families mourn for Uganda school attack victims
 - [https://www.aljazeera.com/gallery/2023/6/18/grieving-families-mourn-for-uganda-school-attack-victims](https://www.aljazeera.com/gallery/2023/6/18/grieving-families-mourn-for-uganda-school-attack-victims)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-18 12:12:45+00:00

At least 41 people, mostly students, killed in suspect rebel attack at a school in a town close to DRC border.

## Uganda school attack: What we know so far
 - [https://www.aljazeera.com/news/2023/6/18/uganda-school-attack-what-we-know-so-far](https://www.aljazeera.com/news/2023/6/18/uganda-school-attack-what-we-know-so-far)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-18 11:51:23+00:00

Uganda reels from its worse attack in more than 10 years after a rebel group killed 41 civilians, mostly students.

## In Gabes, Tunisia’s artisanal fishers are watching fish die
 - [https://www.aljazeera.com/news/2023/6/18/in-gabes-tunisias-artisanal-fishers-are-watching-fish-die](https://www.aljazeera.com/news/2023/6/18/in-gabes-tunisias-artisanal-fishers-are-watching-fish-die)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-18 11:19:35+00:00

Between encroachments by big trawlers, lethal pollution levels and a cost-of-living crisis, life is harder than ever.

## Why are the US and Iran holding talks and why does it matter?
 - [https://www.aljazeera.com/news/2023/6/18/why-are-the-us-and-iran-holding-talks-and-why-does-it-matter](https://www.aljazeera.com/news/2023/6/18/why-are-the-us-and-iran-holding-talks-and-why-does-it-matter)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-18 10:26:16+00:00

A deal could see Iran free US prisoners in return for the release of billions of dollars worth of Iranian assets.

## Why is the Turkish lira’s value still falling?
 - [https://www.aljazeera.com/news/2023/6/18/why-is-the-turkish-lira-still-falling-in-value](https://www.aljazeera.com/news/2023/6/18/why-is-the-turkish-lira-still-falling-in-value)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-18 10:13:14+00:00

Experts say the &#039;suppressed&#039; lira is reaching its true value as they forecast a continued fall against the dollar.

## Mali’s military rulers hold constitutional referendum vote
 - [https://www.aljazeera.com/news/2023/6/18/malis-military-rulers-hold-constitutional-referendum-vote](https://www.aljazeera.com/news/2023/6/18/malis-military-rulers-hold-constitutional-referendum-vote)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-18 09:09:11+00:00

The military gov&#039;t promises a return to civilian rule, but opponents argue changes would give president excessive power.

## Yemenis embark on first direct flight to Saudi Arabia since 2016
 - [https://www.aljazeera.com/news/2023/6/18/yemenis-embark-on-first-direct-flight-to-saudi-arabia-since-2016](https://www.aljazeera.com/news/2023/6/18/yemenis-embark-on-first-direct-flight-to-saudi-arabia-since-2016)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-18 08:48:37+00:00

The flight carried Yemeni Muslims heading to Hajj and signals easing tensions between the two countries.

## Tunisia bars TV, radio reports of opposition conspiracy cases
 - [https://www.aljazeera.com/news/2023/6/18/tunisia-bars-tv-radio-reports-of-opposition-conspiracy-cases](https://www.aljazeera.com/news/2023/6/18/tunisia-bars-tv-radio-reports-of-opposition-conspiracy-cases)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-18 08:32:56+00:00

The cases banned from being covered involve at least 21 dissidents under investigation on accusations of ‘conspiracy&#039;.

## Biden holds first campaign rally for 2024 re-election bid
 - [https://www.aljazeera.com/news/2023/6/18/biden-holds-first-campaign-rally-for-2024-re-election-bid](https://www.aljazeera.com/news/2023/6/18/biden-holds-first-campaign-rally-for-2024-re-election-bid)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-18 08:22:59+00:00

Biden addresses members of the AFL-CIO, which represents more than 12.5 million workers, as he kicks off campaign rally.

## Philippine ferry with 120 people on board catches fire at sea
 - [https://www.aljazeera.com/news/2023/6/18/philippine-ferry-with-120-people-onboard-catches-fire-at-sea](https://www.aljazeera.com/news/2023/6/18/philippine-ferry-with-120-people-onboard-catches-fire-at-sea)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-18 05:03:13+00:00

Rescue under way after M/V Esperanza Star catches fires while travelling from Siquijor province to Bohol province.

## Russia-Ukraine war: List of key events, day 480
 - [https://www.aljazeera.com/news/2023/6/18/russia-ukraine-war-list-of-key-events-day-480](https://www.aljazeera.com/news/2023/6/18/russia-ukraine-war-list-of-key-events-day-480)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-18 04:50:17+00:00

as the war enters its 480th day, these are the main developments.

## US’s Blinken lands in China but hopes for breakthrough low
 - [https://www.aljazeera.com/news/2023/6/18/uss-blinken-lands-in-china-but-hopes-for-breakthrough-low](https://www.aljazeera.com/news/2023/6/18/uss-blinken-lands-in-china-but-hopes-for-breakthrough-low)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-06-18 04:34:05+00:00

US&#039;s top diplomat aiming to keep lines of communication open amid heightened tensions between two countries.

