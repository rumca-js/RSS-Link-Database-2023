# Source:Nerdstalgic, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXjmz8dFzRJZrZY8eFiXNUQ, language:en-US

## everything wrong with the hobbit #shorts
 - [https://www.youtube.com/watch?v=6cnE4j9syGA](https://www.youtube.com/watch?v=6cnE4j9syGA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXjmz8dFzRJZrZY8eFiXNUQ
 - date published: 2023-06-18 15:00:09+00:00

Check Out the Full Video: https://youtu.be/B5Q-TjOsU3E

Subscribe to Nerdstalgic! https://www.youtube.com/@UCXjmz8dFzRJZrZY8eFiXNUQ 

#thehobbit #lordoftherings #lotr #hobbit #peterjackson #frodo #ringsofpower #middleearth

