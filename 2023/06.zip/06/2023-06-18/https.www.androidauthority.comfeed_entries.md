# Source:Android Authority, URL:https://www.androidauthority.com/feed/, language:en-US

## Garmin Epix Pro review: Should you buy it?
 - [https://www.androidauthority.com/garmin-epix-pro-review-3335722/](https://www.androidauthority.com/garmin-epix-pro-review-3335722/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2023-06-18 18:00:03+00:00

Three feature-packed sizes to choose from, for the goldilocks in all of us.

## Don’t judge all of Android by the worst of Android
 - [https://www.androidauthority.com/worst-of-android-3334814/](https://www.androidauthority.com/worst-of-android-3334814/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2023-06-18 16:00:48+00:00

If you buy a $100 Android phone, you're going to have a bad time. That doesn't (and shouldn't) represent Android as a whole.

## For the first time, I am excited about Sony’s WF-1000XM5 buds
 - [https://www.androidauthority.com/sony-wf-1000xm5-size-comfort-3335459/](https://www.androidauthority.com/sony-wf-1000xm5-size-comfort-3335459/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2023-06-18 14:00:57+00:00

A smaller size and a more ergonomic design are exactly what was missing from this formula.

