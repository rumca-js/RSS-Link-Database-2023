# Source:Techradar, URL:https://www.techradar.com/rss, language:en-US

## 7 awesome Reddit alternatives you should try right now
 - [https://www.techradar.com/news/7-awesome-reddit-alternatives-you-should-try-right-now](https://www.techradar.com/news/7-awesome-reddit-alternatives-you-should-try-right-now)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-06-18 17:00:21+00:00

If you're looking to spend your online time somewhere other than Reddit, these are the sites you should be looking at.

## The Google Pixel 8 is tipped to get a major upgrade to its display
 - [https://www.techradar.com/news/the-google-pixel-8-is-tipped-to-get-a-major-upgrade-to-its-display](https://www.techradar.com/news/the-google-pixel-8-is-tipped-to-get-a-major-upgrade-to-its-display)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-06-18 11:30:19+00:00

Changes are coming to the displays of the Google Pixel 8 and Pixel 8 Pro, and we've got all the details.

## Berlin is the Money Heist spin-off you've been waiting for, but it's not in Berlin
 - [https://www.techradar.com/news/berlin-is-the-money-heist-spin-off-youve-been-waiting-for-but-its-not-in-berlin](https://www.techradar.com/news/berlin-is-the-money-heist-spin-off-youve-been-waiting-for-but-its-not-in-berlin)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-06-18 08:03:47+00:00

The super-stylish Money Heist has a new spin-off, and it looks like it's going to be tons of fun

## Netflix's Heart of Stone trailer is here, and Gal Gadot could be the new Bourne or Bond
 - [https://www.techradar.com/news/netflixs-heart-of-stone-trailer-is-here-and-gal-gadot-could-be-the-new-bourne-or-bond](https://www.techradar.com/news/netflixs-heart-of-stone-trailer-is-here-and-gal-gadot-could-be-the-new-bourne-or-bond)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-06-18 07:43:37+00:00

Gal Gadot doesn't need an invisible plane to kick ass in this new action epic

## Quordle today - hints and answers for Sunday, June 18 (game #510)
 - [https://www.techradar.com/news/quordle-today-answers-clues-18-june-2023](https://www.techradar.com/news/quordle-today-answers-clues-18-june-2023)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-06-18 07:06:09+00:00

Looking for Quordle clues? We can help. Plus get the answers to Quordle today and past solutions.

