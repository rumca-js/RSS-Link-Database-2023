# Source:MSN, URL:http://www.msn.com/rss/news.aspx, language:en-US

## Trump likely won't attend trial over rape claim, lawyer says
 - [http://www.msn.com/en-us/news/us/trump-likely-won-t-attend-trial-over-rape-claim-lawyer-says/ar-AA1a4x3b?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/trump-likely-won-t-attend-trial-over-rape-claim-lawyer-says/ar-AA1a4x3b?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 23:33:53.827999+00:00



## Bob Lee killing suspect Nima Momeni is being monitored while in jail, but suspect's lawyer says calling it 'suicide watch' is 'dramatic'
 - [http://www.msn.com/en-us/news/crime/bob-lee-killing-suspect-nima-momeni-is-being-monitored-while-in-jail-but-suspect-s-lawyer-says-calling-it-suicide-watch-is-dramatic/ar-AA1a4yPd?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/bob-lee-killing-suspect-nima-momeni-is-being-monitored-while-in-jail-but-suspect-s-lawyer-says-calling-it-suicide-watch-is-dramatic/ar-AA1a4yPd?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 23:33:53.820197+00:00



## Potential GOP presidential candidate Mike Pence urges continued American aide to Ukraine in O.C. speech
 - [http://www.msn.com/en-us/news/politics/potential-gop-presidential-candidate-mike-pence-urges-continued-american-aide-to-ukraine-in-o-c-speech/ar-AA1a4Oie?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/potential-gop-presidential-candidate-mike-pence-urges-continued-american-aide-to-ukraine-in-o-c-speech/ar-AA1a4Oie?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 23:33:53.812491+00:00



## Challenging the failed status quo in American politics
 - [http://www.msn.com/en-us/news/politics/challenging-the-failed-status-quo-in-american-politics/ar-AA1a4OdE?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/challenging-the-failed-status-quo-in-american-politics/ar-AA1a4OdE?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 23:33:53.804799+00:00



## New York woman sentenced for cheesecake murder plot
 - [http://www.msn.com/en-us/news/world/new-york-woman-sentenced-for-cheesecake-murder-plot/ar-AA1a4QAc?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/new-york-woman-sentenced-for-cheesecake-murder-plot/ar-AA1a4QAc?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 23:33:53.797083+00:00



## In win for Jordan, judge denies Bragg's request to block GOP congressional subpoena
 - [http://www.msn.com/en-us/news/politics/in-win-for-jordan-judge-denies-bragg-s-request-to-block-gop-congressional-subpoena/ar-AA1a4C7o?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/in-win-for-jordan-judge-denies-bragg-s-request-to-block-gop-congressional-subpoena/ar-AA1a4C7o?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 23:33:53.789600+00:00



## Lawyers for House GOP and Manhattan DA Alvin Bragg to face off in court over Trump probe
 - [http://www.msn.com/en-us/news/politics/lawyers-for-house-gop-and-manhattan-da-alvin-bragg-to-face-off-in-court-over-trump-probe/ar-AA1a4dQb?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/lawyers-for-house-gop-and-manhattan-da-alvin-bragg-to-face-off-in-court-over-trump-probe/ar-AA1a4dQb?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 23:33:53.780236+00:00



## Virginia suspect hid face with bonnet during 7-Eleven robbery: police
 - [http://www.msn.com/en-us/news/crime/virginia-suspect-hid-face-with-bonnet-during-7-eleven-robbery-police/ar-AA1a4QD0?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/virginia-suspect-hid-face-with-bonnet-during-7-eleven-robbery-police/ar-AA1a4QD0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 23:33:53.772075+00:00



## DeSantis' "Florida blueprint" wipes the LGBTQ community off the map
 - [http://www.msn.com/en-us/news/us/desantis-florida-blueprint-wipes-the-lgbtq-community-off-the-map/ar-AA1a4GCY?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/desantis-florida-blueprint-wipes-the-lgbtq-community-off-the-map/ar-AA1a4GCY?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 22:34:10.377439+00:00



## Russia Threatens South Korea Against Providing Weapons to Ukraine
 - [http://www.msn.com/en-us/news/world/russia-threatens-south-korea-against-providing-weapons-to-ukraine/ar-AA1a4uls?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russia-threatens-south-korea-against-providing-weapons-to-ukraine/ar-AA1a4uls?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 22:34:10.368975+00:00



## A 1960s-era cannon is 'kicking ass' against Russia's drones, but the country that makes ammo for it won't send more to Ukraine
 - [http://www.msn.com/en-us/news/world/a-1960s-era-cannon-is-kicking-ass-against-russia-s-drones-but-the-country-that-makes-ammo-for-it-won-t-send-more-to-ukraine/ar-AA1a4rP9?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/a-1960s-era-cannon-is-kicking-ass-against-russia-s-drones-but-the-country-that-makes-ammo-for-it-won-t-send-more-to-ukraine/ar-AA1a4rP9?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 22:34:10.360271+00:00



## House GOP debt limit plan would block Biden’s student loan agenda, prohibit future relief
 - [http://www.msn.com/en-us/news/politics/house-gop-debt-limit-plan-would-block-biden-s-student-loan-agenda-prohibit-future-relief/ar-AA1a4IP7?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/house-gop-debt-limit-plan-would-block-biden-s-student-loan-agenda-prohibit-future-relief/ar-AA1a4IP7?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 22:34:10.352311+00:00



## Watchdog warns US money could be flowing to Taliban
 - [http://www.msn.com/en-us/news/politics/watchdog-warns-us-money-could-be-flowing-to-taliban/ar-AA1a4rS0?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/watchdog-warns-us-money-could-be-flowing-to-taliban/ar-AA1a4rS0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 22:34:10.343219+00:00



## Afghanistan watchdog can’t guarantee US tax dollars ‘not currently funding the Taliban’
 - [http://www.msn.com/en-us/news/politics/afghanistan-watchdog-can-t-guarantee-us-tax-dollars-not-currently-funding-the-taliban/ar-AA1a4urM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/afghanistan-watchdog-can-t-guarantee-us-tax-dollars-not-currently-funding-the-taliban/ar-AA1a4urM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 22:34:10.333804+00:00



## Capitol rioter who was armed with a gun on Jan. 6 is found guilty on all charges
 - [http://www.msn.com/en-us/news/crime/capitol-rioter-who-was-armed-with-a-gun-on-jan-6-is-found-guilty-on-all-charges/ar-AA1a4NTm?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/capitol-rioter-who-was-armed-with-a-gun-on-jan-6-is-found-guilty-on-all-charges/ar-AA1a4NTm?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 22:34:10.326337+00:00



## 3 arrested in birthday party shooting that left 4 killed, 32 injured
 - [http://www.msn.com/en-us/news/crime/3-arrested-in-birthday-party-shooting-that-left-4-killed-32-injured/ar-AA1a3XD1?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/3-arrested-in-birthday-party-shooting-that-left-4-killed-32-injured/ar-AA1a3XD1?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 22:34:10.318295+00:00



## Republicans finally have a debt ceiling plan. Will Democrats blink?
 - [http://www.msn.com/en-us/news/politics/republicans-finally-have-a-debt-ceiling-plan-will-democrats-blink/ar-AA1a4tE8?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/republicans-finally-have-a-debt-ceiling-plan-will-democrats-blink/ar-AA1a4tE8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 21:33:40.758766+00:00



## Biden slams McCarthy, tells him to 'take default off the table' in debt ceiling fight
 - [http://www.msn.com/en-us/news/politics/biden-slams-mccarthy-tells-him-to-take-default-off-the-table-in-debt-ceiling-fight/ar-AA1a4cy5?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-slams-mccarthy-tells-him-to-take-default-off-the-table-in-debt-ceiling-fight/ar-AA1a4cy5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 21:33:40.750170+00:00



## Utah Tycoon Blasts His Staff in Unhinged Speech on New Return-to-Office Policy
 - [http://www.msn.com/en-us/news/us/utah-tycoon-blasts-his-staff-in-unhinged-speech-on-new-return-to-office-policy/ar-AA1a4kEl?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/utah-tycoon-blasts-his-staff-in-unhinged-speech-on-new-return-to-office-policy/ar-AA1a4kEl?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 21:33:40.741336+00:00



## John Fetterman 'Struggles' Through First Hearing Speech After Hospital Stay
 - [http://www.msn.com/en-us/news/politics/john-fetterman-struggles-through-first-hearing-speech-after-hospital-stay/ar-AA1a4cGf?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/john-fetterman-struggles-through-first-hearing-speech-after-hospital-stay/ar-AA1a4cGf?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 21:33:40.732280+00:00



## Massachusetts fire that destroyed church on Easter being investigated as arson, FBI says
 - [http://www.msn.com/en-us/news/us/massachusetts-fire-that-destroyed-church-on-easter-being-investigated-as-arson-fbi-says/ar-AA1a4wfo?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/massachusetts-fire-that-destroyed-church-on-easter-being-investigated-as-arson-fbi-says/ar-AA1a4wfo?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 21:33:40.723112+00:00



## House votes to block DC police accountability bill
 - [http://www.msn.com/en-us/news/politics/house-votes-to-block-dc-police-accountability-bill/ar-AA1a4yfy?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/house-votes-to-block-dc-police-accountability-bill/ar-AA1a4yfy?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 21:33:40.714968+00:00



## Home Depot employee fatally shot while confronting alleged shoplifter
 - [http://www.msn.com/en-us/news/crime/home-depot-employee-fatally-shot-while-confronting-alleged-shoplifter/ar-AA1a4pQC?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/home-depot-employee-fatally-shot-while-confronting-alleged-shoplifter/ar-AA1a4pQC?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 21:33:40.706836+00:00



## US judge orders Peru ex-leader detained for extradition
 - [http://www.msn.com/en-us/news/crime/us-judge-orders-peru-ex-leader-detained-for-extradition/ar-AA1a4G5p?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/us-judge-orders-peru-ex-leader-detained-for-extradition/ar-AA1a4G5p?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 21:33:40.697806+00:00



## Dad of 20-Year-Old Shot Dead in New York Driveway Has Fiery Words for Her Accused Killer
 - [http://www.msn.com/en-us/news/crime/dad-of-20-year-old-shot-dead-in-new-york-driveway-has-fiery-words-for-her-accused-killer/ar-AA1a3ZL9?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/dad-of-20-year-old-shot-dead-in-new-york-driveway-has-fiery-words-for-her-accused-killer/ar-AA1a3ZL9?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 20:34:01.635492+00:00



## DeSantis and allies ramp up Disney fight as more Republicans criticize his tactics
 - [http://www.msn.com/en-us/news/politics/desantis-and-allies-ramp-up-disney-fight-as-more-republicans-criticize-his-tactics/ar-AA1a4c8M?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/desantis-and-allies-ramp-up-disney-fight-as-more-republicans-criticize-his-tactics/ar-AA1a4c8M?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 20:34:01.625495+00:00



## Montana’s TikTok Ban Won’t Work
 - [http://www.msn.com/en-us/news/technology/montana-s-tiktok-ban-won-t-work/ar-AA1a4vyJ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/montana-s-tiktok-ban-won-t-work/ar-AA1a4vyJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 20:34:01.589703+00:00



## What the Supreme Court's decision in the fight over abortion pills means for mifepristone access
 - [http://www.msn.com/en-us/news/us/what-the-supreme-court-s-decision-in-the-fight-over-abortion-pills-means-for-mifepristone-access/ar-AA19MVcI?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/what-the-supreme-court-s-decision-in-the-fight-over-abortion-pills-means-for-mifepristone-access/ar-AA19MVcI?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 20:34:01.579887+00:00



## Mississippi governor touts 'culture of life' with new laws
 - [http://www.msn.com/en-us/news/politics/mississippi-governor-touts-culture-of-life-with-new-laws/ar-AA1a4pmO?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/mississippi-governor-touts-culture-of-life-with-new-laws/ar-AA1a4pmO?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 20:34:01.571304+00:00



## Nearly two-thirds of Democrats say Feinstein should resign over absence: poll
 - [http://www.msn.com/en-us/news/politics/nearly-two-thirds-of-democrats-say-feinstein-should-resign-over-absence-poll/ar-AA1a4y0r?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/nearly-two-thirds-of-democrats-say-feinstein-should-resign-over-absence-poll/ar-AA1a4y0r?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 20:34:01.560725+00:00



## Pentagon's 'UFO' tracking efforts still find no alien origins
 - [http://www.msn.com/en-us/news/technology/pentagon-s-ufo-tracking-efforts-still-find-no-alien-origins/ar-AA1a3GgJ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/pentagon-s-ufo-tracking-efforts-still-find-no-alien-origins/ar-AA1a3GgJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 20:34:01.552478+00:00



## Elon Musk Sells Tucker Carlson His Conservative Vision of Progress
 - [http://www.msn.com/en-us/news/technology/elon-musk-sells-tucker-carlson-his-conservative-vision-of-progress/ar-AA1a4kay?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/elon-musk-sells-tucker-carlson-his-conservative-vision-of-progress/ar-AA1a4kay?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 20:34:01.543608+00:00



## ‘I’m in the KKK’: ‘Reprehensible’ N-Word Videos Roil Ohio High School
 - [http://www.msn.com/en-us/news/us/i-m-in-the-kkk-reprehensible-n-word-videos-roil-ohio-high-school/ar-AA1a4abs?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/i-m-in-the-kkk-reprehensible-n-word-videos-roil-ohio-high-school/ar-AA1a4abs?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 19:33:50.280230+00:00



## Avoid Concert and Sports Ticket Scams With These Expert-Approved Tips
 - [http://www.msn.com/en-us/news/technology/avoid-concert-and-sports-ticket-scams-with-these-expert-approved-tips/ar-AA19j7Al?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/avoid-concert-and-sports-ticket-scams-with-these-expert-approved-tips/ar-AA19j7Al?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 19:33:50.271657+00:00



## How to apply for your share of Facebook's $725 million settlement in privacy suit
 - [http://www.msn.com/en-us/news/technology/how-to-apply-for-your-share-of-facebook-s-725-million-settlement-in-privacy-suit/ar-AA1a4a8Y?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/how-to-apply-for-your-share-of-facebook-s-725-million-settlement-in-privacy-suit/ar-AA1a4a8Y?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 19:33:50.263903+00:00



## Tragic twist in death of 5-year-old boy whose parents blamed black mold
 - [http://www.msn.com/en-us/news/crime/tragic-twist-in-death-of-5-year-old-boy-whose-parents-blamed-black-mold/ar-AA1a45iw?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/tragic-twist-in-death-of-5-year-old-boy-whose-parents-blamed-black-mold/ar-AA1a45iw?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 19:33:50.255672+00:00



## Supreme Court extends brief pause on abortion pill ruling
 - [http://www.msn.com/en-us/news/politics/supreme-court-extends-brief-pause-on-abortion-pill-ruling/ar-AA1a3Zqk?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/supreme-court-extends-brief-pause-on-abortion-pill-ruling/ar-AA1a3Zqk?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 19:33:50.248430+00:00



## Supreme Court extends stay on Texas abortion pill ruling until Friday
 - [http://www.msn.com/en-us/news/politics/supreme-court-extends-stay-on-texas-abortion-pill-ruling-until-friday/ar-AA1a42bZ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/supreme-court-extends-stay-on-texas-abortion-pill-ruling-until-friday/ar-AA1a42bZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 19:33:50.240498+00:00



## House GOP plows ahead on risky immigration plan
 - [http://www.msn.com/en-us/news/politics/house-gop-plows-ahead-on-risky-immigration-plan/ar-AA1a4bOF?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/house-gop-plows-ahead-on-risky-immigration-plan/ar-AA1a4bOF?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 19:33:50.232268+00:00



## New propellers with looped blades could help make the oceans quiet again, sparing both marine life and the climate
 - [http://www.msn.com/en-us/news/technology/new-propellers-with-looped-blades-could-help-make-the-oceans-quiet-again-sparing-both-marine-life-and-the-climate/ar-AA1a47MY?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/new-propellers-with-looped-blades-could-help-make-the-oceans-quiet-again-sparing-both-marine-life-and-the-climate/ar-AA1a47MY?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 19:33:50.222160+00:00



## Mysterious glowing 'SpaceX spirals' in the night sky seem to be linked to rocket launches
 - [https://www.msn.com/en-us/news/technology/mysterious-glowing-spacex-spirals-in-the-night-sky-seem-to-be-linked-to-rocket-launches/ar-AA1a3YVY?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/technology/mysterious-glowing-spacex-spirals-in-the-night-sky-seem-to-be-linked-to-rocket-launches/ar-AA1a3YVY?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 18:33:56.959735+00:00



## Oklahoma official who discussed killing reporters resigns
 - [https://www.msn.com/en-us/news/crime/oklahoma-official-who-discussed-killing-reporters-resigns/ar-AA1a4iKR?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/crime/oklahoma-official-who-discussed-killing-reporters-resigns/ar-AA1a4iKR?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 18:33:56.951112+00:00



## University backtracks on quiz question claiming ‘wealthy White men’ are more violent, lack remorse
 - [https://www.msn.com/en-us/news/us/university-backtracks-on-quiz-question-claiming-wealthy-white-men-are-more-violent-lack-remorse/ar-AA1a49wl?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/university-backtracks-on-quiz-question-claiming-wealthy-white-men-are-more-violent-lack-remorse/ar-AA1a49wl?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 18:33:56.944208+00:00



## What we know about the Dadeville, Alabama, mass shooting
 - [https://www.msn.com/en-us/news/crime/what-we-know-about-the-dadeville-alabama-mass-shooting/ar-AA19XVMM?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/crime/what-we-know-about-the-dadeville-alabama-mass-shooting/ar-AA19XVMM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 18:33:56.937293+00:00



## Montana GOP caucus calls for censure of legislature’s only openly transgender member
 - [https://www.msn.com/en-us/news/politics/montana-gop-caucus-calls-for-censure-of-legislature-s-only-openly-transgender-member/ar-AA1a4iTx?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/politics/montana-gop-caucus-calls-for-censure-of-legislature-s-only-openly-transgender-member/ar-AA1a4iTx?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 18:33:56.930338+00:00



## Pentagon's 'UFO' tracking efforts still find no alien origins
 - [https://www.msn.com/en-us/news/technology/pentagon-s-ufo-tracking-efforts-still-find-no-alien-origins/ar-AA1a3GgJ?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/technology/pentagon-s-ufo-tracking-efforts-still-find-no-alien-origins/ar-AA1a3GgJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 18:33:56.922475+00:00



## Mystery solved: Scientists ID Caribbean sea urchin killer
 - [https://www.msn.com/en-us/news/us/mystery-solved-scientists-id-caribbean-sea-urchin-killer/ar-AA1a3Ujm?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/us/mystery-solved-scientists-id-caribbean-sea-urchin-killer/ar-AA1a3Ujm?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 18:33:56.914521+00:00



## 2 teens arrested in Alabama Sweet 16 shooting that killed 4 and injured 32
 - [https://www.msn.com/en-us/news/crime/2-teens-arrested-in-alabama-sweet-16-shooting-that-killed-4-and-injured-32/ar-AA1a3Xzy?li=BBnbcA1&srcref=rss](https://www.msn.com/en-us/news/crime/2-teens-arrested-in-alabama-sweet-16-shooting-that-killed-4-and-injured-32/ar-AA1a3Xzy?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 18:33:56.905341+00:00



## What this Utah community is doing about its water crisis
 - [http://www.msn.com/en-us/news/us/what-this-utah-community-is-doing-about-its-water-crisis/ar-AA1a4dBU?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/what-this-utah-community-is-doing-about-its-water-crisis/ar-AA1a4dBU?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 17:33:49.813855+00:00



## What's happening in Sudan? Country on brink of civil war as armed forces and paramilitary group battle for control
 - [http://www.msn.com/en-us/news/world/what-s-happening-in-sudan-country-on-brink-of-civil-war-as-armed-forces-and-paramilitary-group-battle-for-control/ar-AA1a3TPl?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/what-s-happening-in-sudan-country-on-brink-of-civil-war-as-armed-forces-and-paramilitary-group-battle-for-control/ar-AA1a3TPl?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 17:33:49.805338+00:00



## Supreme Court weighs 'true threats' in online stalking case
 - [http://www.msn.com/en-us/news/us/supreme-court-weighs-true-threats-in-online-stalking-case/ar-AA1a44cf?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/supreme-court-weighs-true-threats-in-online-stalking-case/ar-AA1a44cf?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 17:33:49.797677+00:00



## US Army analyzing metal canisters found in Fort Totten Park in Washington, DC
 - [http://www.msn.com/en-us/news/us/us-army-analyzing-metal-canisters-found-in-fort-totten-park-in-washington-dc/ar-AA1a4dKC?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/us-army-analyzing-metal-canisters-found-in-fort-totten-park-in-washington-dc/ar-AA1a4dKC?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 17:33:49.788174+00:00



## US sending $325 million in more military aid to Ukraine
 - [http://www.msn.com/en-us/news/politics/us-sending-325-million-in-more-military-aid-to-ukraine/ar-AA1a3TRL?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/us-sending-325-million-in-more-military-aid-to-ukraine/ar-AA1a3TRL?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 17:33:49.781177+00:00



## Two teens arrested in Alabama birthday shooting
 - [http://www.msn.com/en-us/news/crime/two-teens-arrested-in-alabama-birthday-shooting/ar-AA1a3Xwa?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/two-teens-arrested-in-alabama-birthday-shooting/ar-AA1a3Xwa?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 17:33:49.771767+00:00



## ‘Tennessee 3’ will meet with Biden at White House next week
 - [http://www.msn.com/en-us/news/politics/tennessee-3-will-meet-with-biden-at-white-house-next-week/ar-AA1a3TSy?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/tennessee-3-will-meet-with-biden-at-white-house-next-week/ar-AA1a3TSy?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 17:33:49.763997+00:00



## Dadeville shooting: Two arrests made in connection to shooting at Alabama birthday party
 - [http://www.msn.com/en-us/news/crime/dadeville-shooting-two-arrests-made-in-connection-to-shooting-at-alabama-birthday-party/ar-AA1a3JIZ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/dadeville-shooting-two-arrests-made-in-connection-to-shooting-at-alabama-birthday-party/ar-AA1a3JIZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 16:33:52.146490+00:00



## Attorney warns Fox: Dominion "exposed some of the misconduct" — Smartmatic "will expose the rest"
 - [http://www.msn.com/en-us/news/technology/attorney-warns-fox-dominion-exposed-some-of-the-misconduct-smartmatic-will-expose-the-rest/ar-AA1a3WEU?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/attorney-warns-fox-dominion-exposed-some-of-the-misconduct-smartmatic-will-expose-the-rest/ar-AA1a3WEU?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 16:33:52.138101+00:00



## Air Force Strips Teixeira’s Unit of Intelligence Duties Amid Service-Wide Review
 - [http://www.msn.com/en-us/news/us/air-force-strips-teixeira-s-unit-of-intelligence-duties-amid-service-wide-review/ar-AA1a3Y0x?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/air-force-strips-teixeira-s-unit-of-intelligence-duties-amid-service-wide-review/ar-AA1a3Y0x?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 16:33:52.130035+00:00



## Dad of cheerleader shot after her friend got into the wrong car says suspect fired immediately
 - [http://www.msn.com/en-us/news/us/dad-of-cheerleader-shot-after-her-friend-got-into-the-wrong-car-says-suspect-fired-immediately/ar-AA1a3WGx?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/dad-of-cheerleader-shot-after-her-friend-got-into-the-wrong-car-says-suspect-fired-immediately/ar-AA1a3WGx?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 16:33:52.120600+00:00



## Anti-vaccine activist RFK Jr. launches 2024 primary challenge against Biden
 - [http://www.msn.com/en-us/news/politics/anti-vaccine-activist-rfk-jr-launches-2024-primary-challenge-against-biden/ar-AA1a3RRM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/anti-vaccine-activist-rfk-jr-launches-2024-primary-challenge-against-biden/ar-AA1a3RRM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 16:33:52.112641+00:00



## Trump's former financial chief Weisselberg gets out of jail
 - [http://www.msn.com/en-us/news/politics/trump-s-former-financial-chief-weisselberg-gets-out-of-jail/ar-AA1a3PrP?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/trump-s-former-financial-chief-weisselberg-gets-out-of-jail/ar-AA1a3PrP?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 16:33:52.104474+00:00



## Robert F. Kennedy Jr. launches Democratic challenge against Biden, vows to fight 'corporate feudalism'
 - [http://www.msn.com/en-us/news/politics/robert-f-kennedy-jr-launches-democratic-challenge-against-biden-vows-to-fight-corporate-feudalism/ar-AA1a45AN?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/robert-f-kennedy-jr-launches-democratic-challenge-against-biden-vows-to-fight-corporate-feudalism/ar-AA1a45AN?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 16:33:52.096970+00:00



## Robert F. Kennedy Jr. launches long shot presidential bid as a Democrat
 - [http://www.msn.com/en-us/news/politics/robert-f-kennedy-jr-launches-long-shot-presidential-bid-as-a-democrat/ar-AA1a3Tl0?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/robert-f-kennedy-jr-launches-long-shot-presidential-bid-as-a-democrat/ar-AA1a3Tl0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 16:33:52.087535+00:00



## Air Force halts intelligence mission of suspected classified document leaker's unit
 - [http://www.msn.com/en-us/news/us/air-force-halts-intelligence-mission-of-suspected-classified-document-leaker-s-unit/ar-AA1a3G4W?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/air-force-halts-intelligence-mission-of-suspected-classified-document-leaker-s-unit/ar-AA1a3G4W?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 15:34:06.431592+00:00



## Will Biden’s zigzag strategy work?
 - [http://www.msn.com/en-us/news/politics/will-biden-s-zigzag-strategy-work/ar-AA1a3A0M?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/will-biden-s-zigzag-strategy-work/ar-AA1a3A0M?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 15:34:06.423515+00:00



## Utah elementary school cancels slavery reenactment after parent outrage
 - [http://www.msn.com/en-us/news/us/utah-elementary-school-cancels-slavery-reenactment-after-parent-outrage/ar-AA1a3Mcf?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/utah-elementary-school-cancels-slavery-reenactment-after-parent-outrage/ar-AA1a3Mcf?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 15:34:06.415072+00:00



## "Accountability is coming": Dominion turns focus on TrumpWorld after scoring Fox News payout
 - [http://www.msn.com/en-us/news/politics/accountability-is-coming-dominion-turns-focus-on-trumpworld-after-scoring-fox-news-payout/ar-AA1a3A47?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/accountability-is-coming-dominion-turns-focus-on-trumpworld-after-scoring-fox-news-payout/ar-AA1a3A47?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 15:34:06.405727+00:00



## Elon Musk said he hasn't talked to his former friend Larry Page in years: 'He got very upset with me about OpenAI'
 - [http://www.msn.com/en-us/news/technology/elon-musk-said-he-hasn-t-talked-to-his-former-friend-larry-page-in-years-he-got-very-upset-with-me-about-openai/ar-AA1a3VO0?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/elon-musk-said-he-hasn-t-talked-to-his-former-friend-larry-page-in-years-he-got-very-upset-with-me-about-openai/ar-AA1a3VO0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 15:34:06.397923+00:00



## Do Not Allow Even One Fruit Fly Into Your Kitchen Compost
 - [http://www.msn.com/en-us/news/us/do-not-allow-even-one-fruit-fly-into-your-kitchen-compost/ar-AA1a3wAI?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/do-not-allow-even-one-fruit-fly-into-your-kitchen-compost/ar-AA1a3wAI?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 15:34:06.388869+00:00



## Teenagers charged with murder over Alabama shooting
 - [http://www.msn.com/en-us/news/world/teenagers-charged-with-murder-over-alabama-shooting/ar-AA1a40cS?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/teenagers-charged-with-murder-over-alabama-shooting/ar-AA1a40cS?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 15:34:06.379587+00:00



## France's Macron heckled by crowd angry over pensions
 - [http://www.msn.com/en-us/news/world/france-s-macron-heckled-by-crowd-angry-over-pensions/ar-AA1a42JH?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/france-s-macron-heckled-by-crowd-angry-over-pensions/ar-AA1a42JH?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 15:34:06.371399+00:00



## Why People Are Shooting Cats in New Zealand
 - [http://www.msn.com/en-us/news/world/why-people-are-shooting-cats-in-new-zealand/ar-AA1a3Gp3?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/why-people-are-shooting-cats-in-new-zealand/ar-AA1a3Gp3?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 14:33:48.666882+00:00



## Inside McCarthy’s controversial plan to shrink food aid
 - [http://www.msn.com/en-us/news/politics/inside-mccarthy-s-controversial-plan-to-shrink-food-aid/ar-AA1a3Ifu?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/inside-mccarthy-s-controversial-plan-to-shrink-food-aid/ar-AA1a3Ifu?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 14:33:48.659473+00:00



## Watch live: Oversight panel holds hearing on Biden’s handling of Afghan withdrawal
 - [http://www.msn.com/en-us/news/politics/watch-live-oversight-panel-holds-hearing-on-biden-s-handling-of-afghan-withdrawal/ar-AA1a3Ea6?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/watch-live-oversight-panel-holds-hearing-on-biden-s-handling-of-afghan-withdrawal/ar-AA1a3Ea6?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 14:33:48.651453+00:00



## If you want to journey into the Deep West, you'll need a guide like Wanda Coleman
 - [http://www.msn.com/en-us/news/us/if-you-want-to-journey-into-the-deep-west-you-ll-need-a-guide-like-wanda-coleman/ar-AA1a3PVX?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/if-you-want-to-journey-into-the-deep-west-you-ll-need-a-guide-like-wanda-coleman/ar-AA1a3PVX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 14:33:48.641592+00:00



## Europe approves its $47 billion answer to Biden’s CHIPS Act
 - [http://www.msn.com/en-us/news/technology/europe-approves-its-47-billion-answer-to-biden-s-chips-act/ar-AA1a3u6x?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/europe-approves-its-47-billion-answer-to-biden-s-chips-act/ar-AA1a3u6x?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 14:33:48.634121+00:00



## 2 Texas cheerleaders were shot after one of them accidentally got into the wrong car after practice
 - [http://www.msn.com/en-us/news/crime/2-texas-cheerleaders-were-shot-after-one-of-them-accidentally-got-into-the-wrong-car-after-practice/ar-AA1a3Lgs?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/2-texas-cheerleaders-were-shot-after-one-of-them-accidentally-got-into-the-wrong-car-after-practice/ar-AA1a3Lgs?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 14:33:48.627238+00:00



## Pentagon's 'UFO' tracking efforts focus of Senate hearing
 - [http://www.msn.com/en-us/news/politics/pentagon-s-ufo-tracking-efforts-focus-of-senate-hearing/ar-AA1a3GgJ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/pentagon-s-ufo-tracking-efforts-focus-of-senate-hearing/ar-AA1a3GgJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 14:33:48.618475+00:00



## Retired spacecraft will reenter Earth's atmosphere with some risk to humans, NASA says
 - [http://www.msn.com/en-us/news/technology/retired-spacecraft-will-reenter-earth-s-atmosphere-with-some-risk-to-humans-nasa-says/ar-AA1a3PZ6?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/retired-spacecraft-will-reenter-earth-s-atmosphere-with-some-risk-to-humans-nasa-says/ar-AA1a3PZ6?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 14:33:48.610710+00:00



## James Webb captures stunning moment two spiral galaxies collide
 - [http://www.msn.com/en-us/news/technology/james-webb-captures-stunning-moment-two-spiral-galaxies-collide/ar-AA1a3f3c?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/james-webb-captures-stunning-moment-two-spiral-galaxies-collide/ar-AA1a3f3c?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 13:33:52.925501+00:00



## Warsaw Ghetto uprising's 80th anniversary marked by Holocaust survivors, political leaders
 - [http://www.msn.com/en-us/news/world/warsaw-ghetto-uprising-s-80th-anniversary-marked-by-holocaust-survivors-political-leaders/ar-AA1a3eWP?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/warsaw-ghetto-uprising-s-80th-anniversary-marked-by-holocaust-survivors-political-leaders/ar-AA1a3eWP?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 13:33:52.918435+00:00



## 2 cheerleaders shot after trying to get into the wrong car in grocery store parking lot
 - [http://www.msn.com/en-us/news/crime/2-cheerleaders-shot-after-trying-to-get-into-the-wrong-car-in-grocery-store-parking-lot/ar-AA1a3yiC?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/2-cheerleaders-shot-after-trying-to-get-into-the-wrong-car-in-grocery-store-parking-lot/ar-AA1a3yiC?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 13:33:52.910720+00:00



## US should step up to make sure President Lasso can finish his term
 - [http://www.msn.com/en-us/news/politics/us-should-step-up-to-make-sure-president-lasso-can-finish-his-term/ar-AA1a3mCC?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/us-should-step-up-to-make-sure-president-lasso-can-finish-his-term/ar-AA1a3mCC?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 13:33:52.902649+00:00



## Elon Musk joked that if aliens came to earth he would get the most-liked tweet of all time, and that he's 'very familiar with space stuff'
 - [http://www.msn.com/en-us/news/technology/elon-musk-joked-that-if-aliens-came-to-earth-he-would-get-the-most-liked-tweet-of-all-time-and-that-he-s-very-familiar-with-space-stuff/ar-AA1a3eXV?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/elon-musk-joked-that-if-aliens-came-to-earth-he-would-get-the-most-liked-tweet-of-all-time-and-that-he-s-very-familiar-with-space-stuff/ar-AA1a3eXV?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 13:33:52.895399+00:00



## Madagascar faces 'catastrophic' hunger after 3 cyclones
 - [http://www.msn.com/en-us/news/world/madagascar-faces-catastrophic-hunger-after-3-cyclones/ar-AA1a3f2v?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/madagascar-faces-catastrophic-hunger-after-3-cyclones/ar-AA1a3f2v?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 13:33:52.887047+00:00



## Donalds grills Biden SEC commissioner on Steele dossier payment
 - [http://www.msn.com/en-us/news/politics/donalds-grills-biden-sec-commissioner-on-steele-dossier-payment/ar-AA1a3mN4?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/donalds-grills-biden-sec-commissioner-on-steele-dossier-payment/ar-AA1a3mN4?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 13:33:52.877862+00:00



## Judge delays hearing for suspect in classified document leak
 - [http://www.msn.com/en-us/news/us/judge-delays-hearing-for-suspect-in-classified-document-leak/ar-AA1a2VjO?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/judge-delays-hearing-for-suspect-in-classified-document-leak/ar-AA1a2VjO?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 13:33:52.869506+00:00



## China celebrates Macron as U.S. and Europe fret over divisions
 - [http://www.msn.com/en-us/news/world/china-celebrates-macron-as-u-s-and-europe-fret-over-divisions/ar-AA1a3azz?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/china-celebrates-macron-as-u-s-and-europe-fret-over-divisions/ar-AA1a3azz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 11:05:51.773725+00:00



## Supreme Court to decide whether to jump into abortion debate, again
 - [http://www.msn.com/en-us/news/us/supreme-court-to-decide-whether-to-jump-into-abortion-debate-again/ar-AA1a302D?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/supreme-court-to-decide-whether-to-jump-into-abortion-debate-again/ar-AA1a302D?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 11:05:51.765980+00:00



## Ukraine Set To Unleash France's AMX-10 Tanks: 'Sniper On Wheels'
 - [http://www.msn.com/en-us/news/world/ukraine-set-to-unleash-france-s-amx-10-tanks-sniper-on-wheels/ar-AA1a3aYy?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/ukraine-set-to-unleash-france-s-amx-10-tanks-sniper-on-wheels/ar-AA1a3aYy?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 11:05:51.757790+00:00



## Suspected documents leaker due in court for hearing on whether he stays in jail
 - [http://www.msn.com/en-us/news/us/suspected-documents-leaker-due-in-court-for-hearing-on-whether-he-stays-in-jail/ar-AA1a36z8?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/suspected-documents-leaker-due-in-court-for-hearing-on-whether-he-stays-in-jail/ar-AA1a36z8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 11:05:51.750094+00:00



## Man extradited from UK over alleged war crimes
 - [http://www.msn.com/en-us/news/world/man-extradited-from-uk-over-alleged-war-crimes/ar-AA1a2YAz?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/man-extradited-from-uk-over-alleged-war-crimes/ar-AA1a2YAz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 11:05:51.742478+00:00



## Air quality is getting better and worse at the same time
 - [http://www.msn.com/en-us/news/us/air-quality-is-getting-better-and-worse-at-the-same-time/ar-AA1a3cZS?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/air-quality-is-getting-better-and-worse-at-the-same-time/ar-AA1a3cZS?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 11:05:51.733661+00:00



## Germany, Poland and others are pushing for new sanctions on Russia's nuclear energy
 - [http://www.msn.com/en-us/news/world/germany-poland-and-others-are-pushing-for-new-sanctions-on-russia-s-nuclear-energy/ar-AA1a36ud?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/germany-poland-and-others-are-pushing-for-new-sanctions-on-russia-s-nuclear-energy/ar-AA1a36ud?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 11:05:51.725450+00:00



## I trained SpaceX astronauts for a NASA mission. Being responsible for their safety was stressful, but preparing my friends for space was an honor.
 - [http://www.msn.com/en-us/news/technology/i-trained-spacex-astronauts-for-a-nasa-mission-being-responsible-for-their-safety-was-stressful-but-preparing-my-friends-for-space-was-an-honor/ar-AA1a3fxR?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/i-trained-spacex-astronauts-for-a-nasa-mission-being-responsible-for-their-safety-was-stressful-but-preparing-my-friends-for-space-was-an-honor/ar-AA1a3fxR?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 11:05:51.716098+00:00



## I was a teenage evangelical missionary
 - [http://www.msn.com/en-us/news/world/i-was-a-teenage-evangelical-missionary/ar-AA1a2Em4?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/i-was-a-teenage-evangelical-missionary/ar-AA1a2Em4?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 10:05:31.689703+00:00



## Suspect in classified document leak due back in court
 - [http://www.msn.com/en-us/news/crime/suspect-in-classified-document-leak-due-back-in-court/ar-AA1a2VjO?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/suspect-in-classified-document-leak-due-back-in-court/ar-AA1a2VjO?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 10:05:31.681677+00:00



## Children's cat killing contest axed in New Zealand
 - [http://www.msn.com/en-us/news/world/children-s-cat-killing-contest-axed-in-new-zealand/ar-AA1a2Ew2?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/children-s-cat-killing-contest-axed-in-new-zealand/ar-AA1a2Ew2?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 10:05:31.672453+00:00



## The Hidden iPhone Setting Thieves Use to Lock People Out of Apple Accounts
 - [http://www.msn.com/en-us/news/technology/the-hidden-iphone-setting-thieves-use-to-lock-people-out-of-apple-accounts/vi-AA1a358x?srcref=rss](http://www.msn.com/en-us/news/technology/the-hidden-iphone-setting-thieves-use-to-lock-people-out-of-apple-accounts/vi-AA1a358x?srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 10:05:31.664563+00:00



## Jim Rossman: Plex can serve up your media and record live TV
 - [http://www.msn.com/en-us/news/technology/jim-rossman-plex-can-serve-up-your-media-and-record-live-tv/ar-AA1a336p?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/jim-rossman-plex-can-serve-up-your-media-and-record-live-tv/ar-AA1a336p?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 10:05:31.656805+00:00



## Putin Ally Suggests Russia Can't Win Without 'General Mobilization'
 - [http://www.msn.com/en-us/news/world/putin-ally-suggests-russia-can-t-win-without-general-mobilization/ar-AA1a2JlI?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/putin-ally-suggests-russia-can-t-win-without-general-mobilization/ar-AA1a2JlI?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 10:05:31.648697+00:00



## South Carolina teacher fired for giving students 'inappropriate' LGBTQ+ article during class
 - [http://www.msn.com/en-us/news/us/south-carolina-teacher-fired-for-giving-students-inappropriate-lgbtq-article-during-class/ar-AA1a2T3m?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/south-carolina-teacher-fired-for-giving-students-inappropriate-lgbtq-article-during-class/ar-AA1a2T3m?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 10:05:31.639748+00:00



## German unions to hit railway, airports with new strikes
 - [http://www.msn.com/en-us/money/companies/german-unions-to-hit-railway-airports-with-new-strikes/ar-AA1a2JtI?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/money/companies/german-unions-to-hit-railway-airports-with-new-strikes/ar-AA1a2JtI?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 10:05:31.631899+00:00



## CBP seizes $21.1 million worth of fentanyl pills concealed within tractor-trailer carrying green beans
 - [http://www.msn.com/en-us/news/us/cbp-seizes-21-1-million-worth-of-fentanyl-pills-concealed-within-tractor-trailer-carrying-green-beans/ar-AA1a2Dqk?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/cbp-seizes-21-1-million-worth-of-fentanyl-pills-concealed-within-tractor-trailer-carrying-green-beans/ar-AA1a2Dqk?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 09:05:24.325377+00:00



## No respite in Sudan as truce falls apart, rivals battle
 - [http://www.msn.com/en-us/news/world/no-respite-in-sudan-as-truce-falls-apart-rivals-battle/ar-AA1a2PD9?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/no-respite-in-sudan-as-truce-falls-apart-rivals-battle/ar-AA1a2PD9?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 09:05:24.317133+00:00



## Death toll in Beijing hospital fire rises to 29; cause under investigation
 - [http://www.msn.com/en-us/news/world/death-toll-in-beijing-hospital-fire-rises-to-29-cause-under-investigation/ar-AA1a2PVN?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/death-toll-in-beijing-hospital-fire-rises-to-29-cause-under-investigation/ar-AA1a2PVN?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 09:05:24.307706+00:00



## Lindsey Graham Blocks 'Harmful' Move to Replace Dianne Feinstein
 - [http://www.msn.com/en-us/news/politics/lindsey-graham-blocks-harmful-move-to-replace-dianne-feinstein/ar-AA1a2SqP?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/lindsey-graham-blocks-harmful-move-to-replace-dianne-feinstein/ar-AA1a2SqP?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 09:05:24.297910+00:00



## North Carolina Republicans file bill to ban drag shows
 - [http://www.msn.com/en-us/news/us/north-carolina-republicans-file-bill-to-ban-drag-shows/ar-AA1a2NyM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/north-carolina-republicans-file-bill-to-ban-drag-shows/ar-AA1a2NyM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 09:05:24.290027+00:00



## Emergency alert will be 'perfect opportunity' for scams, experts warn
 - [http://www.msn.com/en-us/news/technology/emergency-alert-will-be-perfect-opportunity-for-scams-experts-warn/ar-AA1a2C6k?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/emergency-alert-will-be-perfect-opportunity-for-scams-experts-warn/ar-AA1a2C6k?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 09:05:24.282319+00:00



## How a GOP mega-donor is trying to buy the Kentucky governorship
 - [http://www.msn.com/en-us/news/politics/how-a-gop-mega-donor-is-trying-to-buy-the-kentucky-governorship/ar-AA1a2Q70?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/how-a-gop-mega-donor-is-trying-to-buy-the-kentucky-governorship/ar-AA1a2Q70?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 09:05:24.274164+00:00



## A Ukrainian drone commander said Russian troops would sit around and get shot at the start of the war, but have learned from their mistakes
 - [http://www.msn.com/en-us/news/world/a-ukrainian-drone-commander-said-russian-troops-would-sit-around-and-get-shot-at-the-start-of-the-war-but-have-learned-from-their-mistakes/ar-AA1a2u5j?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/a-ukrainian-drone-commander-said-russian-troops-would-sit-around-and-get-shot-at-the-start-of-the-war-but-have-learned-from-their-mistakes/ar-AA1a2u5j?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 09:05:24.264571+00:00



## NATO Should 'Beg' Ukraine to Join After Russia War: Diplomat
 - [http://www.msn.com/en-us/news/world/nato-should-beg-ukraine-to-join-after-russia-war-diplomat/ar-AA1a2CO9?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/nato-should-beg-ukraine-to-join-after-russia-war-diplomat/ar-AA1a2CO9?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 08:05:27.402003+00:00



## India Surpasses China as World’s Most Populous Nation, UN Says
 - [http://www.msn.com/en-us/news/world/india-surpasses-china-as-world-s-most-populous-nation-un-says/ar-AA1a2RTt?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/india-surpasses-china-as-world-s-most-populous-nation-un-says/ar-AA1a2RTt?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 08:05:27.392267+00:00



## Warsaw Ghetto Uprising commemorated on 80th anniversary
 - [http://www.msn.com/en-us/news/world/warsaw-ghetto-uprising-commemorated-on-80th-anniversary/ar-AA1a2wYh?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/warsaw-ghetto-uprising-commemorated-on-80th-anniversary/ar-AA1a2wYh?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 08:05:27.384480+00:00



## North Carolina family of California college student who went missing in 2020 'baffled' by disappearance
 - [http://www.msn.com/en-us/news/us/north-carolina-family-of-california-college-student-who-went-missing-in-2020-baffled-by-disappearance/ar-AA1a1GWB?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/north-carolina-family-of-california-college-student-who-went-missing-in-2020-baffled-by-disappearance/ar-AA1a1GWB?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 07:05:30.282502+00:00



## 2 Texas cheerleaders shot after getting into wrong car in parking lot
 - [http://www.msn.com/en-us/news/crime/2-texas-cheerleaders-shot-after-getting-into-wrong-car-in-parking-lot/ar-AA1a2t57?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/2-texas-cheerleaders-shot-after-getting-into-wrong-car-in-parking-lot/ar-AA1a2t57?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 07:05:30.274512+00:00



## Twelve held after Beijing hospital fire kills dozens
 - [http://www.msn.com/en-us/news/world/twelve-held-after-beijing-hospital-fire-kills-dozens/ar-AA1a2vRr?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/twelve-held-after-beijing-hospital-fire-kills-dozens/ar-AA1a2vRr?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 07:05:30.266295+00:00



## Donald Trump got back on Instagram after 2 years and the first thing he did was sell NFTs
 - [http://www.msn.com/en-us/news/politics/donald-trump-got-back-on-instagram-after-2-years-and-the-first-thing-he-did-was-sell-nfts/ar-AA1a2oUt?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/donald-trump-got-back-on-instagram-after-2-years-and-the-first-thing-he-did-was-sell-nfts/ar-AA1a2oUt?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 07:05:30.256908+00:00



## In grim drought, Tunisians ration water in state-ordered ban
 - [http://www.msn.com/en-us/news/world/in-grim-drought-tunisians-ration-water-in-state-ordered-ban/ar-AA1a24op?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/in-grim-drought-tunisians-ration-water-in-state-ordered-ban/ar-AA1a24op?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 07:05:30.248820+00:00



## Be vigilant ahead of Eurovision, police warn
 - [http://www.msn.com/en-us/news/world/be-vigilant-ahead-of-eurovision-police-warn/ar-AA1a2xup?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/be-vigilant-ahead-of-eurovision-police-warn/ar-AA1a2xup?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 06:05:32.730847+00:00



## Kaylin Gillis' parents say they are 'lost' after 'senseless' death of 20-year-old daughter
 - [http://www.msn.com/en-us/news/crime/kaylin-gillis-parents-say-they-are-lost-after-senseless-death-of-20-year-old-daughter/ar-AA1a2okW?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/kaylin-gillis-parents-say-they-are-lost-after-senseless-death-of-20-year-old-daughter/ar-AA1a2okW?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 06:05:32.723106+00:00



## Death toll in Beijing hospital fire rises to 29
 - [http://www.msn.com/en-us/news/world/death-toll-in-beijing-hospital-fire-rises-to-29/ar-AA1a1GEW?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/death-toll-in-beijing-hospital-fire-rises-to-29/ar-AA1a1GEW?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 06:05:32.715432+00:00



## US citizens and Russian nationals accused of interfering with elections and being 'illegal agents'
 - [http://www.msn.com/en-us/news/world/us-citizens-and-russian-nationals-accused-of-interfering-with-elections-and-being-illegal-agents/ar-AA1a2iXN?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/us-citizens-and-russian-nationals-accused-of-interfering-with-elections-and-being-illegal-agents/ar-AA1a2iXN?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 06:05:32.707156+00:00



## Top Biden Aide Speaks to Brazilian Official After Lula Scolds US
 - [http://www.msn.com/en-us/news/world/top-biden-aide-speaks-to-brazilian-official-after-lula-scolds-us/ar-AA1a2nMI?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/top-biden-aide-speaks-to-brazilian-official-after-lula-scolds-us/ar-AA1a2nMI?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 05:05:41.049537+00:00



## House Republicans ready border enforcement push after delays
 - [http://www.msn.com/en-us/news/politics/house-republicans-ready-border-enforcement-push-after-delays/ar-AA1a23qI?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/house-republicans-ready-border-enforcement-push-after-delays/ar-AA1a23qI?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 05:05:41.040794+00:00



## Fetterman makes a video pretending to have a body double to address the conspiracy that has reached everyone from Melania Trump to Russian President Vladimir Putin
 - [http://www.msn.com/en-us/news/politics/fetterman-makes-a-video-pretending-to-have-a-body-double-to-address-the-conspiracy-that-has-reached-everyone-from-melania-trump-to-russian-president-vladimir-putin/ar-AA1a2pvk?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/fetterman-makes-a-video-pretending-to-have-a-body-double-to-address-the-conspiracy-that-has-reached-everyone-from-melania-trump-to-russian-president-vladimir-putin/ar-AA1a2pvk?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 05:05:41.032909+00:00



## Trump wins 2024 endorsement from Texas Republican that met with DeSantis
 - [http://www.msn.com/en-us/news/politics/trump-wins-2024-endorsement-from-texas-republican-that-met-with-desantis/ar-AA1a2s7w?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/trump-wins-2024-endorsement-from-texas-republican-that-met-with-desantis/ar-AA1a2s7w?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 05:05:41.025203+00:00



## DOJ arrests businessman for evading sanction scheme
 - [http://www.msn.com/en-us/news/world/doj-arrests-businessman-for-evading-sanction-scheme/ar-AA1a24NJ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/doj-arrests-businessman-for-evading-sanction-scheme/ar-AA1a24NJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 05:05:41.015453+00:00



## Rep. Lee endorses DeSantis, bringing Capitol Hill supporters to 3 while Trump has backing of over 50 lawmakers
 - [http://www.msn.com/en-us/news/politics/rep-lee-endorses-desantis-bringing-capitol-hill-supporters-to-3-while-trump-has-backing-of-over-50-lawmakers/ar-AA1a2s1y?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/rep-lee-endorses-desantis-bringing-capitol-hill-supporters-to-3-while-trump-has-backing-of-over-50-lawmakers/ar-AA1a2s1y?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 05:05:41.007661+00:00



## 'Lone gunman,' 34, killed four people inside Maine home before opening fire on nearby highway
 - [http://www.msn.com/en-us/news/crime/lone-gunman-34-killed-four-people-inside-maine-home-before-opening-fire-on-nearby-highway/ar-AA1a2ehS?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/lone-gunman-34-killed-four-people-inside-maine-home-before-opening-fire-on-nearby-highway/ar-AA1a2ehS?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 05:05:41.000392+00:00



## Idaho Republicans Auction ‘Trigger Time’ With Kyle Rittenhouse
 - [http://www.msn.com/en-us/news/crime/idaho-republicans-auction-trigger-time-with-kyle-rittenhouse/ar-AA1a2s6W?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/idaho-republicans-auction-trigger-time-with-kyle-rittenhouse/ar-AA1a2s6W?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 05:05:40.992487+00:00



## Elon Musk reveals whether he's seen evidence of alien life
 - [http://www.msn.com/en-us/news/technology/elon-musk-reveals-whether-he-s-seen-evidence-of-alien-life/ar-AA1a2d04?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/elon-musk-reveals-whether-he-s-seen-evidence-of-alien-life/ar-AA1a2d04?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 04:05:31.201721+00:00



## How the Media Trial of the Century Ended Before It Even Began
 - [http://www.msn.com/en-us/news/us/how-the-media-trial-of-the-century-ended-before-it-even-began/ar-AA1a1Tup?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/how-the-media-trial-of-the-century-ended-before-it-even-began/ar-AA1a1Tup?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 04:05:31.193410+00:00



## Torch-carrying marchers indicted in Charlottesville rally
 - [http://www.msn.com/en-us/news/politics/torch-carrying-marchers-indicted-in-charlottesville-rally/ar-AA1a2eS6?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/torch-carrying-marchers-indicted-in-charlottesville-rally/ar-AA1a2eS6?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 04:05:31.185551+00:00



## The Secret Service apprehended an intruder at the White House. It turned out to be a 2-year-old boy.
 - [http://www.msn.com/en-us/news/us/the-secret-service-apprehended-an-intruder-at-the-white-house-it-turned-out-to-be-a-2-year-old-boy/ar-AA1a1Rhx?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/the-secret-service-apprehended-an-intruder-at-the-white-house-it-turned-out-to-be-a-2-year-old-boy/ar-AA1a1Rhx?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 04:05:31.177803+00:00



## Chip Roy says Democrats can 'choke' on 'responsible' GOP debt plan
 - [http://www.msn.com/en-us/news/politics/chip-roy-says-democrats-can-choke-on-responsible-gop-debt-plan/ar-AA1a1TJX?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/chip-roy-says-democrats-can-choke-on-responsible-gop-debt-plan/ar-AA1a1TJX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 04:05:31.168696+00:00



## Driveway shooting suspect shows no remorse - police
 - [http://www.msn.com/en-us/news/crime/driveway-shooting-suspect-shows-no-remorse-police/ar-AA1a2hKo?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/driveway-shooting-suspect-shows-no-remorse-police/ar-AA1a2hKo?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 04:05:31.161370+00:00



## Boyfriend of N.Y. woman who was gunned down in the wrong driveway recalls her final moments
 - [http://www.msn.com/en-us/news/crime/boyfriend-of-n-y-woman-who-was-gunned-down-in-the-wrong-driveway-recalls-her-final-moments/ar-AA1a29iB?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/boyfriend-of-n-y-woman-who-was-gunned-down-in-the-wrong-driveway-recalls-her-final-moments/ar-AA1a29iB?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 04:05:31.153580+00:00



## 9 Indonesian fishermen feared dead, 11 rescued off Australia
 - [http://www.msn.com/en-us/news/world/9-indonesian-fishermen-feared-dead-11-rescued-off-australia/ar-AA1a2hRF?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/9-indonesian-fishermen-feared-dead-11-rescued-off-australia/ar-AA1a2hRF?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 04:05:31.145512+00:00



## Joe Biden and first lady release 2022 tax returns showing joint income of $579K
 - [http://www.msn.com/en-us/news/politics/joe-biden-and-first-lady-release-2022-tax-returns-showing-joint-income-of-579k/ar-AA1a2ant?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/joe-biden-and-first-lady-release-2022-tax-returns-showing-joint-income-of-579k/ar-AA1a2ant?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 03:05:18.549468+00:00



## Mayor Karen Bass' first budget: more cops, more hotel rooms for L.A.'s homeless
 - [http://www.msn.com/en-us/news/us/mayor-karen-bass-first-budget-more-cops-more-hotel-rooms-for-l-a-s-homeless/ar-AA1a1Tlk?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/mayor-karen-bass-first-budget-more-cops-more-hotel-rooms-for-l-a-s-homeless/ar-AA1a1Tlk?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 03:05:18.541518+00:00



## Elon Musk warns of AI's impact on elections, calls for US oversight: 'Things are getting weird... fast'
 - [http://www.msn.com/en-us/news/technology/elon-musk-warns-of-ai-s-impact-on-elections-calls-for-us-oversight-things-are-getting-weird-fast/ar-AA1a1QS6?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/elon-musk-warns-of-ai-s-impact-on-elections-calls-for-us-oversight-things-are-getting-weird-fast/ar-AA1a1QS6?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 03:05:18.534445+00:00



## Republicans block temporary replacement for Feinstein on Judiciary Committee
 - [http://www.msn.com/en-us/news/politics/republicans-block-temporary-replacement-for-feinstein-on-judiciary-committee/ar-AA1a14Ul?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/republicans-block-temporary-replacement-for-feinstein-on-judiciary-committee/ar-AA1a14Ul?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 03:05:18.526643+00:00



## Elon Musk says the government needs 'some sort of contingency plan' to shutdown AI if it gets too powerful
 - [http://www.msn.com/en-us/news/technology/elon-musk-says-the-government-needs-some-sort-of-contingency-plan-to-shutdown-ai-if-it-gets-too-powerful/ar-AA1a1Tmq?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/elon-musk-says-the-government-needs-some-sort-of-contingency-plan-to-shutdown-ai-if-it-gets-too-powerful/ar-AA1a1Tmq?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 03:05:18.519383+00:00



## Panel: Seattle police should apologize for protest violence
 - [http://www.msn.com/en-us/news/politics/panel-seattle-police-should-apologize-for-protest-violence/ar-AA1a26tR?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/panel-seattle-police-should-apologize-for-protest-violence/ar-AA1a26tR?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 03:05:18.511222+00:00



## Elon Musk: If I Knew There Were Aliens, I Would’ve Already Tweeted It
 - [http://www.msn.com/en-us/news/technology/elon-musk-if-i-knew-there-were-aliens-i-would-ve-already-tweeted-it/ar-AA1a2cQ3?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/elon-musk-if-i-knew-there-were-aliens-i-would-ve-already-tweeted-it/ar-AA1a2cQ3?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 03:05:18.503977+00:00



## Republicans grill Biden’s refugee resettlement chief on migrant child labor
 - [http://www.msn.com/en-us/news/politics/republicans-grill-biden-s-refugee-resettlement-chief-on-migrant-child-labor/ar-AA1a22So?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/republicans-grill-biden-s-refugee-resettlement-chief-on-migrant-child-labor/ar-AA1a22So?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 03:05:18.495913+00:00



## Trump Gets Speedy Endorsement After Congressman Meets With Ron DeSantis
 - [http://www.msn.com/en-us/news/politics/trump-gets-speedy-endorsement-after-congressman-meets-with-ron-desantis/ar-AA1a1SVF?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/trump-gets-speedy-endorsement-after-congressman-meets-with-ron-desantis/ar-AA1a1SVF?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 02:05:40.815648+00:00



## Democrats’ Complaint About Thomas Forwarded to Judicial Panel
 - [http://www.msn.com/en-us/news/politics/democrats-complaint-about-thomas-forwarded-to-judicial-panel/ar-AA1a2a87?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/democrats-complaint-about-thomas-forwarded-to-judicial-panel/ar-AA1a2a87?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 02:05:40.807989+00:00



## Kim says N Korea finishes development of 1st spy satellite
 - [http://www.msn.com/en-us/news/world/kim-says-n-korea-finishes-development-of-1st-spy-satellite/ar-AA1a29NV?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/kim-says-n-korea-finishes-development-of-1st-spy-satellite/ar-AA1a29NV?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 02:05:40.800373+00:00



## Watch: Witness Describes Parking Garage Collapse in New York
 - [http://www.msn.com/en-us/video/news/watch-witness-describes-parking-garage-collapse-in-new-york/vi-AA1a1DW3?srcref=rss](http://www.msn.com/en-us/video/news/watch-witness-describes-parking-garage-collapse-in-new-york/vi-AA1a1DW3?srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 02:05:40.792489+00:00



## Asa Hutchinson says Donald Trump has taken GOP 'back to bitterness'
 - [http://www.msn.com/en-us/news/politics/asa-hutchinson-says-donald-trump-has-taken-gop-back-to-bitterness/ar-AA1a27Gc?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/asa-hutchinson-says-donald-trump-has-taken-gop-back-to-bitterness/ar-AA1a27Gc?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 02:05:40.784777+00:00



## Trump is running up the score in DeSantis' backyard with endorsements
 - [http://www.msn.com/en-us/news/politics/trump-is-running-up-the-score-in-desantis-backyard-with-endorsements/ar-AA1a1OwM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/trump-is-running-up-the-score-in-desantis-backyard-with-endorsements/ar-AA1a1OwM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 02:05:40.776499+00:00



## Arrest made after 4 found dead at home, 3 shot on interstate in connected incidents
 - [http://www.msn.com/en-us/news/crime/arrest-made-after-4-found-dead-at-home-3-shot-on-interstate-in-connected-incidents/ar-AA1a1znk?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/arrest-made-after-4-found-dead-at-home-3-shot-on-interstate-in-connected-incidents/ar-AA1a1znk?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 02:05:40.769209+00:00



## GOP critics pile on DeSantis over Disney feud: 'I don't think Ron DeSantis is a conservative'
 - [http://www.msn.com/en-us/news/politics/gop-critics-pile-on-desantis-over-disney-feud-i-don-t-think-ron-desantis-is-a-conservative/ar-AA1a1ONU?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/gop-critics-pile-on-desantis-over-disney-feud-i-don-t-think-ron-desantis-is-a-conservative/ar-AA1a1ONU?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 02:05:40.759689+00:00



## Bidens report nearly $580K in income, Harris and husband report $457K
 - [http://www.msn.com/en-us/news/politics/bidens-report-nearly-580k-in-income-harris-and-husband-report-457k/ar-AA1a1ZCX?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/bidens-report-nearly-580k-in-income-harris-and-husband-report-457k/ar-AA1a1ZCX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 01:00:49.120066+00:00



## 1 person is dead in parking garage collapse in downtown New York City; multiple people injured
 - [http://www.msn.com/en-us/news/us/1-person-is-dead-in-parking-garage-collapse-in-downtown-new-york-city-multiple-people-injured/ar-AA1a1ypn?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/1-person-is-dead-in-parking-garage-collapse-in-downtown-new-york-city-multiple-people-injured/ar-AA1a1ypn?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 01:00:49.112235+00:00



## Bidens paid 23.8% in taxes on $579,514 in earnings, returns show
 - [http://www.msn.com/en-us/news/politics/bidens-paid-23-8-in-taxes-on-579-514-in-earnings-returns-show/ar-AA1a1BFR?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/bidens-paid-23-8-in-taxes-on-579-514-in-earnings-returns-show/ar-AA1a1BFR?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 01:00:49.103218+00:00



## SpaceX's Starship May Finally Be Ready to Fly to the Moon—If It Doesn’t Blow Up
 - [http://www.msn.com/en-us/news/technology/spacex-s-starship-may-finally-be-ready-to-fly-to-the-moon-if-it-doesn-t-blow-up/ar-AA1a1Sqt?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/spacex-s-starship-may-finally-be-ready-to-fly-to-the-moon-if-it-doesn-t-blow-up/ar-AA1a1Sqt?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 01:00:49.092563+00:00



## Biden labor secretary pick asked to appear before House panel before June to prevent 'undue delay'
 - [http://www.msn.com/en-us/news/politics/biden-labor-secretary-pick-asked-to-appear-before-house-panel-before-june-to-prevent-undue-delay/ar-AA1a1XIu?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-labor-secretary-pick-asked-to-appear-before-house-panel-before-june-to-prevent-undue-delay/ar-AA1a1XIu?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 01:00:49.082055+00:00



## Businessman charged with conspiracy to evade sanctions for aiding Ukrainian oligarch
 - [http://www.msn.com/en-us/news/world/businessman-charged-with-conspiracy-to-evade-sanctions-for-aiding-ukrainian-oligarch/ar-AA1a24NJ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/businessman-charged-with-conspiracy-to-evade-sanctions-for-aiding-ukrainian-oligarch/ar-AA1a24NJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 01:00:49.073355+00:00



## Austin police chief touts partnership with state law enforcement, city council members skeptical
 - [http://www.msn.com/en-us/news/us/austin-police-chief-touts-partnership-with-state-law-enforcement-city-council-members-skeptical/ar-AA1a1Szl?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/austin-police-chief-touts-partnership-with-state-law-enforcement-city-council-members-skeptical/ar-AA1a1Szl?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 01:00:49.063970+00:00



## Ralph Yarl: What we know about the Missouri shooting
 - [http://www.msn.com/en-us/news/world/ralph-yarl-what-we-know-about-the-missouri-shooting/ar-AA1a1DLk?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/ralph-yarl-what-we-know-about-the-missouri-shooting/ar-AA1a1DLk?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-19 01:00:49.053570+00:00



