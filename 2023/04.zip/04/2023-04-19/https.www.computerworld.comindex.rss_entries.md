# Source:ComputerWorld, URL:https://www.computerworld.com/index.rss, language:en-US

## EU Chips Act to drive $47 billion investments in semiconductor manufacturing
 - [https://www.computerworld.com/article/3693953/eu-chips-act-to-drive-47-billion-investments-in-semiconductor-manufacturing.html#tk.rss_all](https://www.computerworld.com/article/3693953/eu-chips-act-to-drive-47-billion-investments-in-semiconductor-manufacturing.html#tk.rss_all)
 - RSS feed: https://www.computerworld.com/index.rss
 - date published: 2023-04-19 17:37:00+00:00

<article>
	<section class="page">
<p>The European Council and the European Parliament has reached an agreement on a deal that will invest $3.6 billion in EU funds — with the aim of attracting a further $43.7 billion in private investment — to build out the continent’s semiconductor manufacturing capabilities.</p><p>Europe, like the U.S., is grappling with a fast-changing semiconductor marketplace, as governments around the world increasingly adopt more restrictive policies on the import and use of chips from overseas.</p><p>The EU's Chips Act is broadly similar in its goals to the <a href="https://www.computerworld.com/article/3669258/chips-and-science-act-becomes-law-as-us-chipmaking-investments-rise.html">US CHIPS and Science Act, which was signed into law by President Joe Biden in August 2022</a>. Both the US and EU measures are meant as a response to post-pandemic supply chain issues that the semiconductor market has faced in recent years and to the <a href="https://www.computerworld.com/article/3683790/us-china-chip-war-puts-global-enterprises-in-the-crosshairs.html">US' ongoing "chip war" with China,</a> over security concerns posed by close governmental oversight of major silicon manufacturers in that country.</p><p class="jumpTag"><a href="https://www.computerworld.com/article/3693953/eu-chips-act-to-drive-47-billion-investments-in-semiconductor-manufacturing.html#jump">To read this article in full, please click here</a></p></section></article>

## Atlassian adds generative AI to its cloud workforce management offerings
 - [https://www.computerworld.com/article/3693949/atlassian-adds-generative-ai-to-its-cloud-workforce-management-offerings.html#tk.rss_all](https://www.computerworld.com/article/3693949/atlassian-adds-generative-ai-to-its-cloud-workforce-management-offerings.html#tk.rss_all)
 - RSS feed: https://www.computerworld.com/index.rss
 - date published: 2023-04-19 16:01:00+00:00

<article>
	<section class="page">
<p>Atlassian is rolling out new <a href="https://www.infoworld.com/article/3689973/what-is-generative-ai-the-evolution-of-artificial-intelligence.html">generative AI</a> capabilities that will be embedded in the company’s entire portfolio of workforce management cloud products and are designed to help both service-based and project-based work teams be more efficient.</p><p>The technology, dubbed Atlassian Intelligence, was announced Wednesday and is built on in-house AI models gained through the company’s acquisition of Perceptive AI in 2022, and a collaboration with Microsoft-back OpenAI — the creator of <a href="https://www.computerworld.com/article/3682143/chatgpt-finally-an-ai-chatbot-worth-talking-to.html">ChatGPT,</a> whose launch last year sparked a virtual AI arms race among top tech companies including Google and Meta.</p><p class="jumpTag"><a href="https://www.computerworld.com/article/3693949/atlassian-adds-generative-ai-to-its-cloud-workforce-management-offerings.html#jump">To read this article in full, please click here</a></p></section></article>

## Global cloud spending expected to jump 21.7% as IaaS leads the way
 - [https://www.computerworld.com/article/3693951/global-cloud-spending-expected-to-jump-217-as-iaas-leads-the-way.html#tk.rss_all](https://www.computerworld.com/article/3693951/global-cloud-spending-expected-to-jump-217-as-iaas-leads-the-way.html#tk.rss_all)
 - RSS feed: https://www.computerworld.com/index.rss
 - date published: 2023-04-19 15:53:00+00:00

<article>
	<section class="page">
<p>Global end-user spending on public cloud services is forecast to grow 21.7% to total $597.3 billion in 2023, up from $491 billion in 2022, according to analyst firm Gartner.</p><p>While all segments of the cloud market are expected to see spending growth in 2023, infrastructure-as-a-service (IaaS) spending is forecast to experience the highest rise, increasing by 30.9%, followed by platform-as-a-service (PaaS) at 24.1%.</p><p>While software-as-a-service (SaaS) spending is projected to grow at a slower rate, 17.9%, it will total  $197 billion in 2023 and remain\s the largest segment of the cloud market by total end-user spending.</p><p>“Organizations today view cloud as a highly strategic platform for digital transformation, which is requiring cloud providers to offer more sophisticated capabilities as the competition for digital services heats up,” said Sid Nag, a vice president and analyst at Gartner, in the company's report. He added that in the current market, hyperscale cloud providers are driving the cloud agenda.</p><p class="jumpTag"><a href="https://www.computerworld.com/article/3693951/global-cloud-spending-expected-to-jump-217-as-iaas-leads-the-way.html#jump">To read this article in full, please click here</a></p></section></article>

## 7 tips for better hybrid workplaces
 - [https://www.computerworld.com/article/3693869/7-tips-for-better-hybrid-workplaces.html#tk.rss_all](https://www.computerworld.com/article/3693869/7-tips-for-better-hybrid-workplaces.html#tk.rss_all)
 - RSS feed: https://www.computerworld.com/index.rss
 - date published: 2023-04-19 15:45:00+00:00

<article>
	<section class="page">
<p>While many employees are being <a href="https://www.applemust.com/no-we-dont-want-to-go-back-to-the-office-future-forum/" rel="nofollow noopener" target="_blank">frog-marched back to the office</a>, future-focused companies continue to explore the opportunities remote working provides. In the Apple space, device management and security vendor <a href="http://www.jamf.com/" rel="noopener nofollow" target="_blank">Jamf</a> has been enjoying a lot of success as it embraces new working practices.</p><h2><strong>Work is a choice, so make it a good one</strong></h2>
<p>Writing about how his company has <a href="https://www.forbes.com/sites/forbestechcouncil/2023/04/14/reflection-three-years-of-successful-remote-work/?sh=3d3630092223" rel="noopener nofollow" target="_blank">approached the challenges of the new workplace</a> over the last three years, Jamf CEO Dean Hager more or less observed that while the pandemic forced companies to move to remote fast, optimizing how it is done should be a continual process guided by employee empowerment and trust.</p><p class="jumpTag"><a href="https://www.computerworld.com/article/3693869/7-tips-for-better-hybrid-workplaces.html#jump">To read this article in full, please click here</a></p></section></article>

## Atlassian's Confluence adds whiteboards, databases, boosts external collaboration
 - [https://www.computerworld.com/article/3693910/atlassians-confluence-adds-whiteboards-databases-boosts-external-collaboration.html#tk.rss_all](https://www.computerworld.com/article/3693910/atlassians-confluence-adds-whiteboards-databases-boosts-external-collaboration.html#tk.rss_all)
 - RSS feed: https://www.computerworld.com/index.rss
 - date published: 2023-04-19 12:43:00+00:00

<article>
	<section class="page">
<p>Atlassian unveiled a host of new features for its Confluence workplace management platform Wednesday, offering new ways of working with additional types of content.</p><p>The key announcement is the addition of native whiteboards to Confluence, alongside new databases resulting from the company’s recent acquisition of Orderly Databases from solution partner K15t. Confluence is also allowing users to broaden their ability to work with external partners, by providing guest spots and public links.</p><p>Atlassian’s partnership with portfolio company Hypothesis is also yielding results, with the launch of a new Chrome Extension app that enables Confluence users to comment and mention team members on web pages just as they would on Confluence pages.</p><p class="jumpTag"><a href="https://www.computerworld.com/article/3693910/atlassians-confluence-adds-whiteboards-databases-boosts-external-collaboration.html#jump">To read this article in full, please click here</a></p></section></article>

## Think Android 14 seems boring? Think about this.
 - [https://www.computerworld.com/article/3693574/google-android-14-boring.html#tk.rss_all](https://www.computerworld.com/article/3693574/google-android-14-boring.html#tk.rss_all)
 - RSS feed: https://www.computerworld.com/index.rss
 - date published: 2023-04-19 10:00:00+00:00

<article>
	<section class="page">
<p>Look, I'll be honest: When I first got my grubby gorilla paws on Google's latest and great <a href="https://www.computerworld.com/article/3235946/android-versions-a-living-history-from-1-0-to-today.html">Android version</a> — the hot-off-the-griddle <a href="https://android-developers.googleblog.com/2023/04/android-14-beta-1.html" rel="nofollow noopener" target="_blank">first beta</a> of this year's Android 14 update — two terse words kept ringing in my head:</p><p><em>That's it?</em></p><p>Also: <em>Mmm, pancakes.</em> But that's just because of the griddle reference I'd already cooked up in my deeply demented man-brain.</p><p>All flapjackery aside, there's no way around it: On the surface, the inaugural beta of Android 14 isn't exactly exciting. In fact, in most day-to-day use at the moment, you'd be hard-pressed to notice much difference between it and the <a href="https://www.computerworld.com/article/3685491/advanced-tips-for-android-13.html">Android 13 update</a> that came before it.</p><p class="jumpTag"><a href="https://www.computerworld.com/article/3693574/google-android-14-boring.html#jump">To read this article in full, please click here</a></p></section></article>

