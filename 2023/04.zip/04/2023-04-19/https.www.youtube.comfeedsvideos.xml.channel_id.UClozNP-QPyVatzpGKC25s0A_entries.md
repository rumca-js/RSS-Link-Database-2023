# Source:Brad Colbow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UClozNP-QPyVatzpGKC25s0A, language:en-US

## Testing out the new Pen Tips 2
 - [https://www.youtube.com/watch?v=yddcTQ4ewOs](https://www.youtube.com/watch?v=yddcTQ4ewOs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UClozNP-QPyVatzpGKC25s0A
 - date published: 2023-04-19 13:00:48+00:00

Check out http://www.squarespace.com for a free trial or go to  http://www.squarespace.com/bradcolbow to save 10% off your first purchase of a website or domain.
And thank you Squarespace for sponsoring this video.

The original pen tips had some problems. This latest version goes a long way to fixing those, but are they worth the $50 price tag?

Discounts for my Courses http://brad.site/learn/
Email Newsletter: http://brad.site/signup/

-----------------------------------------------------

Twitter: 
https://twitter.com/bradcolbow

Instagram:
https://www.instagram.com/bcolbow/

Drawing Tech Top 10 lists:
http://brad.site/

My Drawing and video gear: 
http://brad.site/mygear/

