# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Nintendo’s Lawyers are Ready This Time
 - [https://www.youtube.com/watch?v=2veVw8eEQPE](https://www.youtube.com/watch?v=2veVw8eEQPE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2023-04-19 19:11:58+00:00

Remove your personal information from the web at http://joindeleteme.com/LinusTechTips and use code LTT for 20% off

Check out UGREEN’s 9-in-1 USB-C Docking Station at https://lmg.gg/UGREENDS9IN1

The Nintendo NDev is the Wii that Nintendo doesn’t want you to have. What sets it apart from the default bog standard Wii? Is it filled with the usual hardware and software or is it stuffed with beta quirks and Miyamoto’s secret poetry?

Discuss on the forum: https://linustechtips.com/topic/1501859-nintendo%E2%80%99s-lawyers-are-ready-this-time/

► GET MERCH: https://lttstore.com
► LTX 2023 TICKETS AVAILABLE NOW: https://lmg.gg/ltx23
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► OUR WAN PODCAST GEAR: https://lmg.gg/wanset

FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 The first Wii was fake
0:30 All the Wii dev kits
1:40 Teardown
2:05 JK, here's the outside first
3:24 Ok, NOW we look at the insides
7:10 Turning it on (feat. Windows XP)
8:15 The Simpsons game demo
9:50 Heat & power draw
10:56 GoldenEye game demo
13:22 Naruto game demo

