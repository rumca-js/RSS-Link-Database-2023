# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## Ukraińska kontrofensywa. Wiceminister Malar: Żołnierze szykują się do całkowitego wyzwolenia ziem
 - [https://www.polsatnews.pl/wiadomosc/2023-04-19/ukrainska-kontrofensywa-wiceminister-malar-zolnierze-szykuja-sie-do-calkowitego-wyzwolenia-ziem/](https://www.polsatnews.pl/wiadomosc/2023-04-19/ukrainska-kontrofensywa-wiceminister-malar-zolnierze-szykuja-sie-do-calkowitego-wyzwolenia-ziem/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-04-19 19:52:00+00:00

Władze w Kijowie przekazały, że armia Ukrainy rozpoczęła kontrofensywę przeciw Rosji. - Żołnierze przygotowują się do całkowitego wyzwolenia terytoriów - powiedziała wiceminister obrony Hanna Malar. Jak wyjaśniła, nie może być jednego kierunku działania wojsk.

## Niemcy: Strajk na lotniskach i kolei. Utrudnienia w czwartek i piątek
 - [https://www.polsatnews.pl/wiadomosc/2023-04-19/niemcy-strajk-na-lotniskach-i-kolei-utrudnienia-w-czwartek-i-piatek/](https://www.polsatnews.pl/wiadomosc/2023-04-19/niemcy-strajk-na-lotniskach-i-kolei-utrudnienia-w-czwartek-i-piatek/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-04-19 19:40:00+00:00

Niemiecki związek zawodowy Verdi wezwał pracowników lotniskowych stref kontroli bezpieczeństwa do odejścia od pracy w czwartek i piątek. Utrudnienia mają dotyczyć portów lotniczych Düsseldorf, Kolonia/Bonn i Hamburg. Również w piątek chcą strajkować niemieccy kolejarze.

## Fox News zapłaci za kłamstwa o wyborach w USA. Ugoda na 787,5 mln dolarów
 - [https://www.polsatnews.pl/wiadomosc/2023-04-19/fox-news-zaplaci-za-klamstwa-o-wyborach-w-usa-ugoda-na-7875-mln-dolarow/](https://www.polsatnews.pl/wiadomosc/2023-04-19/fox-news-zaplaci-za-klamstwa-o-wyborach-w-usa-ugoda-na-7875-mln-dolarow/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-04-19 19:09:00+00:00

Sympatyzująca z Republikanami amerykańska telewizja informacyjna Fox News zapłaci niemal 790 mln dolarów firmie Dominion, która produkuje maszyny do liczenia głosów w wyborach. To wynik ugody zawartej po tym, jak stacja szerzyła kłamstwa o rzekomych fałszerstwach. Fox News alarmowało o spisku przeciw Donaldowi Trumpowi, w którym miało uczestniczyć przedsiębiorstwo.

## Nie poszedł do toalety, choć powinien. Samolot awaryjnie lądował
 - [https://www.polsatnews.pl/wiadomosc/2023-04-19/nie-poszedl-do-toalety-choc-powinien-samolot-awaryjnie-ladowal/](https://www.polsatnews.pl/wiadomosc/2023-04-19/nie-poszedl-do-toalety-choc-powinien-samolot-awaryjnie-ladowal/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-04-19 17:42:00+00:00

Lecący samolotem linii Jet2 mężczyzna oddał mocz na pokładzie samolotu. Nie zrobił tego jednak w toalecie, a w kabinie pasażerskiej na oczach innych podróżnych, wśród których były dzieci. Ponieważ 55-latek był pijany i zachowywał się agresywnie pilot podjął decyzję o awaryjnym lądowaniu maszyny.

## USA: Nastolatka pomyliła samochód. 25-latek zaczął strzelać do cheerleaderek
 - [https://www.polsatnews.pl/wiadomosc/2023-04-19/usa-nastolatka-pomylila-samochod-25-latek-zaczal-strzelac-do-cheerleaderek/](https://www.polsatnews.pl/wiadomosc/2023-04-19/usa-nastolatka-pomylila-samochod-25-latek-zaczal-strzelac-do-cheerleaderek/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-04-19 15:15:00+00:00

Nastolatka z Teksasu myślała, że stojące na parkingu auto należy do niej. Okazało się jednak, że wewnątrz siedzi nieznajomy mężczyzna. Chwilę później 25-latek zaczął strzelać do dziewczyny, która się pomyliła, jak i do jej koleżanki. Jedna z nich jest w stanie krytycznym. Napastnik został zatrzymany w swoim domu. Był wtedy ubrany tak samo, jak w chwili ataku na cheerleaderki.

## USA: Szwajcarski bank, a w nim pieniądze nazistów? Reaguje Senat USA
 - [https://www.polsatnews.pl/wiadomosc/2023-04-19/usa-szwajcarski-bank-a-w-nim-pieniadze-nazistow-reaguje-senat-usa/](https://www.polsatnews.pl/wiadomosc/2023-04-19/usa-szwajcarski-bank-a-w-nim-pieniadze-nazistow-reaguje-senat-usa/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-04-19 14:49:00+00:00

Szwajcarski bank Credit Suisse jest w ogniu krytyku po wszczęciu dochodzenia przez komisję senacką w Stanach Zjednoczonych. Chodzi o ukrywanie kont bankowych, na których miały znajdować się pieniądze nazistów. Część środków właściciele rachunków mogli zdobyć, wykorzystując ofiary Holokaustu.

## Rosja: Płonie fabryka z niebezpiecznymi  materiałami. Wezwano pociąg strażacki
 - [https://www.polsatnews.pl/wiadomosc/2023-04-19/rosja-plonie-fabryka-z-niebezpiecznymi-materialami-wezwano-pociag-strazacki/](https://www.polsatnews.pl/wiadomosc/2023-04-19/rosja-plonie-fabryka-z-niebezpiecznymi-materialami-wezwano-pociag-strazacki/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-04-19 14:46:00+00:00

W rosyjskim Dzierżyńsku płonie fabryka z materiałami niebezpiecznymi. Służby podniosły stopień złożoności akcji gaśniczej. Na miejsce wezwano m.in. śmigłowiec i pociąg strażacki.

## Na szyi Putina zauważono tajemniczą "bliznę". Przywódca Rosjan przeszedł operację?
 - [https://www.polsatnews.pl/wiadomosc/2023-04-19/blizna-putina/](https://www.polsatnews.pl/wiadomosc/2023-04-19/blizna-putina/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-04-19 12:29:00+00:00

Mnożą się spekulacje dotyczące zauważonej podczas ostatniej publicznej aktywności Władimira Putina blizny. Zdjęcie wykonane na prawosławnym wielkanocnym nabożeństwie w moskiewskim soborze Chrystusa Zbawiciela pokazuje dziwny ślad na szyi rosyjskiego dyktatora. Wyraźna ukośna linia rodzi sugestie, że prezydent może być chory na raka.

## Rosja: Wagnerowiec przyznał się do zabijania dzieci. Teraz obawia się Rosjan
 - [https://www.polsatnews.pl/wiadomosc/2023-04-19/rosja-wagnerowiec-przyznal-sie-do-zabijania-dzieci-teraz-obawia-sie-rosjan/](https://www.polsatnews.pl/wiadomosc/2023-04-19/rosja-wagnerowiec-przyznal-sie-do-zabijania-dzieci-teraz-obawia-sie-rosjan/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-04-19 11:51:00+00:00

Były członek Grupy Wagnera Azamat Uldarow, który przyznał się do zabijania cywilów, w tym dzieci podczas działań prowadzonych w Ukrainie boi się o swoje życie - podaje ukraińska agencja Unian. Według Uldarowa, w Rosji urządzono polowanie na niego, a ludzie Jewgienija Prigożyna nieustannie się z nim kontaktują i nalegają na spotkanie.

## USA. Teresa uwielbia kamienie. Je prawie kilogram dziennie
 - [https://www.polsatnews.pl/wiadomosc/2023-04-19/kobieta-je-kamienie/](https://www.polsatnews.pl/wiadomosc/2023-04-19/kobieta-je-kamienie/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-04-19 11:08:00+00:00

Teresa Widener ma 55 lat i od ponad trzech dekad zmaga się z nietypowym uzależnieniem. O swojej przypadłości o opowiedziała telewizji TLC. Przed kamerą wyznała, że w ciągu dnia jest w stanie zjeść blisko kilogram kamieni. Pociąga ją, że pachną ziemią. Uwielbia też ich chrupkość. Po ten twardy przysmak sięga najczęściej wtedy, by poprawić sobie nastrój. Takie zachowanie należy do zespołu Pica.

## Prezydent Brazylii zmienił zdanie ws. wojny w Ukrainie
 - [https://www.polsatnews.pl/wiadomosc/2023-04-19/prezydent-brazylii-zmienil-zdanie-ws-wojny-w-ukrainie/](https://www.polsatnews.pl/wiadomosc/2023-04-19/prezydent-brazylii-zmienil-zdanie-ws-wojny-w-ukrainie/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-04-19 09:41:00+00:00

Prezydent Brazylii po krytyce za słowa o Ukrainie oświadczył, że popiera jej integralność terytorialną - przekazała w środę ukraińska agencja Unian. We wcześniejszych wypowiedziach Luiz Inacio Lula da Silva zaproponował m.in. oddanie Rosji Krymu w celu zakończenia wojny.

## USA: Policja nie mogła złapać złodzieja. Pomógł dostawca pizzy
 - [https://www.polsatnews.pl/wiadomosc/2023-04-19/usa-policja-nie-mogla-zlapac-zlodzieja-pomogl-dostawca-pizzy/](https://www.polsatnews.pl/wiadomosc/2023-04-19/usa-policja-nie-mogla-zlapac-zlodzieja-pomogl-dostawca-pizzy/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-04-19 08:12:00+00:00

Dostawca pizzy podłożył nogę złodziejowi, który uciekał przed policją, czym umożliwił schwytanie - powiadomił portal NBC News. Zdarzenie zostało nagrane i opublikowane w mediach społecznościowych. Funkcjonariusze mimo wdzięczności dla dostawcy, apelują, by powstrzymywać się od działania na własną rękę podczas policyjnych interwencji.

## USA. Odkrycie nastolatków ma blisko 1000 lat. Myśleli, że to zwykła kłoda
 - [https://www.polsatnews.pl/wiadomosc/2023-04-19/usa-odkrycie-nastolatkow-ma-blisko-1000-lat-mysleli-ze-to-zwykla-kloda/](https://www.polsatnews.pl/wiadomosc/2023-04-19/usa-odkrycie-nastolatkow-ma-blisko-1000-lat-mysleli-ze-to-zwykla-kloda/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-04-19 07:51:00+00:00

Prawie tysiącletnie kanoe rdzennych Amerykanów zostało wyłowione z jeziora w Północnej Karolinie (USA) po tym, jak dosłownie potknęli się o niego bawiący przy brzegu nastolatkowie. Początkowo myślano, że to zwykła, długa kłoda częściowo zakopana w dnie. Do wyciągnięcia zabytkowej łodzi potrzebnych było kilka osób, a nagranie z akcji udostępniono w sieci.

## USA: Śmierć Aarona Cartera. Są wyniki sekcji zwłok
 - [https://www.polsatnews.pl/wiadomosc/2023-04-19/wyniki-sekcji-zwlok-aarona-cartera-okazalo-sie-ze-utonal-w-wannie/](https://www.polsatnews.pl/wiadomosc/2023-04-19/wyniki-sekcji-zwlok-aarona-cartera-okazalo-sie-ze-utonal-w-wannie/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-04-19 07:18:00+00:00

Aaron Carter utonął w wannie po wdychaniu difluoroetanu i spożyciu alprazolamu - wykazała sekcja zwłok amerykańskiego wokalisty popowego, który zmarł 5 listopada 2022 roku.

## Wielka Brytania: Ataków psów w Birmingham. Dzieci zamknięto w szkole
 - [https://www.polsatnews.pl/wiadomosc/2023-04-19/psy-wtargnely-do-szkoly-6-osob-w-szpitalu/](https://www.polsatnews.pl/wiadomosc/2023-04-19/psy-wtargnely-do-szkoly-6-osob-w-szpitalu/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-04-19 06:23:00+00:00

Rodzice przez ponad godzinę nie mogli odebrać swoich dzieci ze szkoły podstawowej Barford w Birmingham. W pobliżu krążyły dwa psy, które zaatakowały przynajmniej sześć osób.

## Nowy Jork: Katastrofa budowlana. Zawalił się parking
 - [https://www.polsatnews.pl/wiadomosc/2023-04-19/nowy-jork-katastrofa-budowlana-zawalil-sie-parking/](https://www.polsatnews.pl/wiadomosc/2023-04-19/nowy-jork-katastrofa-budowlana-zawalil-sie-parking/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-04-19 04:36:00+00:00

Co najmniej jedna osoba zginęła, kilka jest rannych po zawaleniu się piętrowego parkingu w Nowym Jorku - powiadomił portal BBC. Jak przekazano, po zdarzeniu ewakuowano osoby z kilku pobliskich budynków.

