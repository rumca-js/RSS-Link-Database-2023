# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## Alabama police arrest third suspect in connection to Dadeville Sweet 16 shooting
 - [https://www.foxnews.com/us/alabama-police-arrest-third-suspect-connection-dadeville-sweet-shooting](https://www.foxnews.com/us/alabama-police-arrest-third-suspect-connection-dadeville-sweet-shooting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 19:25:06+00:00

Auburn resident Wilson LaMar Hill Jr. was arrested in connection to the Dadeville shooting that killed four people at a Sweet 16 party. Travis and Ty Reik McCullough were also arrested.

## New York woman who tried to kill doppelganger with poisoned cheesecake, sentenced to 21 years
 - [https://www.foxnews.com/us/new-york-woman-tried-kill-doppelganger-poisoned-cheesecake-sentenced](https://www.foxnews.com/us/new-york-woman-tried-kill-doppelganger-poisoned-cheesecake-sentenced)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 19:20:25+00:00

A New York City woman convicted in February of second-degree murder by way of poisoned cheesecake, was sentenced to 21 years in prison followed by five years of supervision.

## Kansas City homeowner accused of shooting teen on his front porch turns himself in, makes plea
 - [https://www.foxnews.com/us/kansas-city-homeowner-accused-shooting-teen-front-porch-turns-himself-makes-plea](https://www.foxnews.com/us/kansas-city-homeowner-accused-shooting-teen-front-porch-turns-himself-makes-plea)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 19:17:41+00:00

A Kansas City man accused of shooting a teen on his front porch last week after the minor rang his doorbell pleaded not guilty to two felony charges on Wednesday.

## Virginia suspect hid face with bonnet during 7-Eleven robbery: police
 - [https://www.foxnews.com/us/virginia-suspect-hid-face-bonnet-7-eleven-robbery-police](https://www.foxnews.com/us/virginia-suspect-hid-face-bonnet-7-eleven-robbery-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 19:17:30+00:00

Fairfax County Police Department officials are searching for a suspect who allegedly robbed a 7-Eleven store in Alexandria while concealing his face with a bonnet on Saturday.

## Bruins legend Zdeno Chara finishes Boston Marathon in impressive time: 'That guy's an animal'
 - [https://www.foxnews.com/sports/bruins-legend-zdeno-chara-finishes-boston-marathon-impressive-time-that-guys-animal](https://www.foxnews.com/sports/bruins-legend-zdeno-chara-finishes-boston-marathon-impressive-time-that-guys-animal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 19:08:28+00:00

Former Boston Bruins captain Zdeno Chara ran the 127th Boston Marathon Monday and finished with a time of 3:38:23. It was his first-ever marathon.

## Over 200 inactive oil, gas wells plugged in New Mexico
 - [https://www.foxnews.com/us/over-200-inactive-oil-gas-wells-plugged-new-mexico](https://www.foxnews.com/us/over-200-inactive-oil-gas-wells-plugged-new-mexico)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 19:06:03+00:00

Land managers in oil and gas producing states have plugged over 200 inactive oil and gas wells in New Mexico. State trust lands have seen a 20% decrease in the number of abandoned wells.

## Aaron Rodgers appears to support Democrat presidential challenger with one emoji
 - [https://www.foxnews.com/sports/aaron-rodgers-appears-support-democrat-presidential-challenger-one-emoji](https://www.foxnews.com/sports/aaron-rodgers-appears-support-democrat-presidential-challenger-one-emoji)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 19:04:29+00:00

Aaron Rodgers appeared to double down on his support for Robert F. Kennedy Jr. on Wednesday as he quote-tweeted the Democrat presidential challenger.

## Ohio GOP's constitutional amendment reform bid clears legislative committees
 - [https://www.foxnews.com/politics/ohio-gops-constitutional-amendment-reform-bid-clears-legislative-committees](https://www.foxnews.com/politics/ohio-gops-constitutional-amendment-reform-bid-clears-legislative-committees)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 19:03:51+00:00

Ohio Republicans&apos; proposal to complicate passing new constitutional amendments by raising the vote threshold has passed committees in both the House and Senate.

## Soda-fountain pharmacies still have fizz despite decrease in numbers
 - [https://www.foxnews.com/us/soda-fountain-pharmacies-still-have-fizz-despite-decrease-numbers](https://www.foxnews.com/us/soda-fountain-pharmacies-still-have-fizz-despite-decrease-numbers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 19:01:51+00:00

Soda fountains in pharmacies were popular gathering spots a century ago, and in some places they still are. At Griffith and Feil Drug in Kenova, WV soda jerks still prepare phosphate drinks.

## Mayorkas takes heat for repeating border is 'secure' claim during House hearing: 'This is nonsense'
 - [https://www.foxnews.com/media/mayorkas-takes-heat-repeating-border-secure-claim-house-hearing](https://www.foxnews.com/media/mayorkas-takes-heat-repeating-border-secure-claim-house-hearing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 19:00:00+00:00

DHS Secretary Alejandro Mayorkas reiterated his claim that the southern border was secure during his testimony to the House Homeland Security Committee on Wednesday.

## New Mexico State basketball players, former head coach, school's board of regents named in hazing lawsuit
 - [https://www.foxnews.com/sports/new-mexico-state-basketball-players-former-head-coach-board-regents-named-hazing-lawsuit](https://www.foxnews.com/sports/new-mexico-state-basketball-players-former-head-coach-board-regents-named-hazing-lawsuit)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 18:53:29+00:00

Three players, two coaches — one current and one former — and the NMSU board of regents have been named in a lawsuit stemming from an alleged hazing incident.

## Grizzlies' Ja Morant out Game 2 vs Lakers with hand injury
 - [https://www.foxnews.com/sports/grizzlies-ja-morant-out-game-2-lakers-hand-injury](https://www.foxnews.com/sports/grizzlies-ja-morant-out-game-2-lakers-hand-injury)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 18:50:17+00:00

The Memphis Grizzlies will be without Ja Morant in Game 2 after the star guard injured his hand in gruesome fashion in Game 1, which they lost 128-112.

## Scottish ultra-marathon runner disqualified for using car in third place finish, blames 'miscommunication'
 - [https://www.foxnews.com/sports/scottish-ultra-marathon-runner-disqualified-using-car-third-place-finish-blames-miscommunication](https://www.foxnews.com/sports/scottish-ultra-marathon-runner-disqualified-using-car-third-place-finish-blames-miscommunication)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 18:49:43+00:00

Joasia Zakrzewski was disqualified from the 2023 GB Ultras Manchester to Liverpool 50-mile where she placed third after officials said she used a car for part of the race.

## Cardinals’ Willson Contreras flips bat on walk after heated exchange with Diamondbacks' Madison Bumgarner
 - [https://www.foxnews.com/sports/cardinals-willson-contreras-bat-flips-walk-heated-exchange-diamondbacks-madison-bumgarner](https://www.foxnews.com/sports/cardinals-willson-contreras-bat-flips-walk-heated-exchange-diamondbacks-madison-bumgarner)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 18:37:06+00:00

Arizona Diamondbacks pitcher Madison Bumgarner and St. Louis Cardinal Willson Contreras exchanged words in the third inning before Contreras walked, flipping his bat in the process.

## Anna Nicole Smith's ex Larry Birkhead has issues with new documentary, making his own with daughter Dannielynn
 - [https://www.foxnews.com/entertainment/anna-nicole-smiths-ex-larry-birkhead-issues-new-documentary-making-own-daughter-dannielynn](https://www.foxnews.com/entertainment/anna-nicole-smiths-ex-larry-birkhead-issues-new-documentary-making-own-daughter-dannielynn)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 18:29:03+00:00

Anna Nicole Smith&apos;s ex and her daughter are making their own documentary about the late model after having concerns with Netflix&apos;s &quot;You Don&apos;t Know Me.&quot;

## Civil rights activist slams concept of reparations and 'Blacks can only benefit if Whites lose' mentality
 - [https://www.foxnews.com/media/civil-rights-activist-slams-concept-reparations-blacks-benefit-whites-lose-mentality](https://www.foxnews.com/media/civil-rights-activist-slams-concept-reparations-blacks-benefit-whites-lose-mentality)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 18:25:23+00:00

Civil rights activist and author Bob Woodson argued that America&apos;s key crisis is not racial, but spiritual decay across its various demographic groups.

## Ryan Leaf claps back at ex-NFL exec, says pre-draft meeting never happened
 - [https://www.foxnews.com/sports/ryan-leaf-claps-back-ex-nfl-exec-says-pre-draft-meeting-never-happened](https://www.foxnews.com/sports/ryan-leaf-claps-back-ex-nfl-exec-says-pre-draft-meeting-never-happened)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 18:25:20+00:00

Ryan Leaf, the former NFL quarterback and second overall pick of the 1998 NFL Draft, disputed a story by former Indianapolis Colts executive Bill Polian.

## Caribbean leaders agree to introduce nationwide bans on assault weapons
 - [https://www.foxnews.com/world/caribbean-leaders-agree-introduce-nationwide-bans-assault-weapons](https://www.foxnews.com/world/caribbean-leaders-agree-introduce-nationwide-bans-assault-weapons)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 18:23:10+00:00

Caribbean leaders have agreed to introduce bans on so-called &quot;assault weapons&quot; in their respective countries, blaming illegal gun imports for unprecedented spikes in gang violence.

## Migrant accidentally shot, killed by North Macedonian police during border struggle
 - [https://www.foxnews.com/world/migrant-accidentally-shot-killed-north-macedonian-police-border-struggle](https://www.foxnews.com/world/migrant-accidentally-shot-killed-north-macedonian-police-border-struggle)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 18:21:41+00:00

Police in North Macedonia accidentally shot and killed a migrant woman in the Greek border town of Gevgelija while attempting to arrest a suspected smuggler.

## Louisiana energy company, feds reach tentative $3.1M settlement over 2017 oil leak
 - [https://www.foxnews.com/us/louisiana-energy-company-feds-reach-tentative-3-1m-settlement-2017-oil-leak](https://www.foxnews.com/us/louisiana-energy-company-feds-reach-tentative-3-1m-settlement-2017-oil-leak)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 18:20:23+00:00

Louisiana-based energy company LLOG Exploration has reached a tentative $3.1 million settlement with the federal government over a 2017 oil leak in the Gulf of Mexico.

## Kelly Clarkson moved to tears after revealing her daughter was bullied
 - [https://www.foxnews.com/entertainment/kelly-clarkson-moved-tears-after-revealing-daughter-bullied](https://www.foxnews.com/entertainment/kelly-clarkson-moved-tears-after-revealing-daughter-bullied)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 18:13:15+00:00

Kelly Clarkson opened up about her daughter&apos;s struggles with dyslexia, revealing she was bullied in school for &quot;not being able to read like all the other kids.&quot;

## Federal judge rules Jim Jordan can subpoena ex-Manhattan prosecutor who investigated Trump
 - [https://www.foxnews.com/politics/federal-judge-rules-jordans-subpoena-of-ex-manhattan-prosecutor-is-valid-bragg-has-no-legal-basis-to-block](https://www.foxnews.com/politics/federal-judge-rules-jordans-subpoena-of-ex-manhattan-prosecutor-is-valid-bragg-has-no-legal-basis-to-block)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 18:05:13+00:00

A federal judge ruled Wednesday that House Judiciary Committee Republicans can question a former Manhattan prosecutor about the criminal case against former President Trump, saying Manhattan District Attorney Alvin Bragg does not have a legal basis to block the congressional subpoena.

## Dems ask for Greene’s words to be stricken from record after she brings up Swalwell’s Chinese spy scandal
 - [https://www.foxnews.com/politics/dems-ask-greenes-words-stricken-record-she-brings-up-swalwells-chinese-spy-scandal](https://www.foxnews.com/politics/dems-ask-greenes-words-stricken-record-she-brings-up-swalwells-chinese-spy-scandal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 18:04:03+00:00

Wednesday&apos;s hearing came to a halt after Rep. Marjorie Taylor Greene, R-Ga., mentioned allegations of Rep. Eric Swalwell’s, D-Calif., past relationship with a Chinese spy.

## NIH study recruiting 18-year-olds to learn 'unknown' side effects of testicle removal for gender dysphoria
 - [https://www.foxnews.com/media/nih-recruiting-18-year-olds-study-unknown-side-effects-castration-surgery-gender-dysphoria](https://www.foxnews.com/media/nih-recruiting-18-year-olds-study-unknown-side-effects-castration-surgery-gender-dysphoria)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 18:00:29+00:00

The National Institutes of Health is funding a study via a women&apos;s health grant that is looking into the &apos;unknown&apos; side effects of gender-affirming surgeries on cardiovascular health.

## Sudan conflict: US conducts 'prudent planning' as violence escalates
 - [https://www.foxnews.com/world/sudan-conflict-us-conducts-prudent-planning-violence-escalates](https://www.foxnews.com/world/sudan-conflict-us-conducts-prudent-planning-violence-escalates)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 17:58:46+00:00

The U.S. Department of Defense is monitoring the conflict in Sudan and “conducting prudent planning&quot; as violence between the Sudanese Armed Forces and Rapid Support Forces continues.

## Fetterman says he 'wasn't functional' after election win: 'I literally stopped eating and drinking'
 - [https://www.foxnews.com/politics/fetterman-wasnt-functional-election-win-stopped-eating-drinking](https://www.foxnews.com/politics/fetterman-wasnt-functional-election-win-stopped-eating-drinking)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 17:57:52+00:00

Sen. John Fetterman of Pennsylvania described his depression as being so severe he &quot;stopped eating and drinking&quot; after winning his Senate race.

## Hunter Biden investigation being mishandled, 'clear conflicts of interest': IRS whistleblower
 - [https://www.foxnews.com/politics/hunter-biden-investigation-mishandled-clear-conflicts-interest-irs-whistleblower](https://www.foxnews.com/politics/hunter-biden-investigation-mishandled-clear-conflicts-interest-irs-whistleblower)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 17:56:43+00:00

A Criminal Supervisory Agent with the IRS overseeing the investigation into Hunter Biden seeks whistleblower protection to tell Congress the case is being mishandled.

## Disney's 'back room deal' to stop DeSantis ripped by legal expert: 'Worthy of Scrooge McDuck’
 - [https://www.foxnews.com/politics/disneys-back-room-deal-stop-desantis-ripped-legal-expert-worthy-scrooge-mcduck](https://www.foxnews.com/politics/disneys-back-room-deal-stop-desantis-ripped-legal-expert-worthy-scrooge-mcduck)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 17:53:56+00:00

A legal expert says that Disney World&apos;s last ditch efforts to keep out from under Ron DeSantis&apos; control is a &apos;blatant effort to subvert&apos; Floridians.

## The ugly truth about modern 'anti-fascism'
 - [https://www.foxnews.com/opinion/ugly-truth-modern-anti-fascism](https://www.foxnews.com/opinion/ugly-truth-modern-anti-fascism)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 17:52:03+00:00

In contemporary American politics, the American left does not just disagree with conservatives, they believe they are pure evil. And that means that anything goes in interactions.

## No evidence of structural failure in northern Mississippi plane crash
 - [https://www.foxnews.com/us/no-evidence-structural-failure-northern-mississippi-plane-crash](https://www.foxnews.com/us/no-evidence-structural-failure-northern-mississippi-plane-crash)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 17:50:51+00:00

There is no evidence of structural failure in a plane crash in north Mississippi that killed a man. The small private plane did not return to the airport after taking off.

## Arizona governor sets veto record in 1st legislative session
 - [https://www.foxnews.com/politics/arizona-governor-sets-veto-record-1st-legislative-session](https://www.foxnews.com/politics/arizona-governor-sets-veto-record-1st-legislative-session)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 17:49:34+00:00

Arizona Governor Katie Hobbs has set the veto record in the first legislative session. Hobbs topped Janet Napolitano’s record of 58 vetoes set in 158 days during 2005.

## NC assault charge against German rapper dismissed
 - [https://www.foxnews.com/us/nc-assault-charge-against-german-rapper-dismissed](https://www.foxnews.com/us/nc-assault-charge-against-german-rapper-dismissed)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 17:48:02+00:00

A defense attorney says an assault charge against German rapper Marteria has been dismissed. 41-year-old rapper and his accuser were in Charlotte for a basketball game.

## George Mason University names Marvin Lewis as athletic director
 - [https://www.foxnews.com/sports/george-mason-university-names-marvin-lewis-athletic-director](https://www.foxnews.com/sports/george-mason-university-names-marvin-lewis-athletic-director)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 17:46:33+00:00

George Mason University has named Marvin Lewis as their new athletic director starting July 1. The university was searching for months to find a replacement for Bradford Edwards.

## North Carolina bill would criminalize drag shows after viral lap dance video
 - [https://www.foxnews.com/politics/north-carolina-bill-would-criminalize-drag-shows-after-viral-lap-dance-video](https://www.foxnews.com/politics/north-carolina-bill-would-criminalize-drag-shows-after-viral-lap-dance-video)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 17:45:08+00:00

A bill introduced Tuesday in the North Carolina General Assembly would criminalize drag shows on public property and in the presence of minors in the state.

## Former Maryland aide made no plans to travel for fraud trial in Baltimore
 - [https://www.foxnews.com/us/former-maryland-aide-made-plans-travel-fraud-trial-baltimore](https://www.foxnews.com/us/former-maryland-aide-made-plans-travel-fraud-trial-baltimore)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 17:44:41+00:00

A former Maryland aide charged with corruption made no plans to travel for his fraud trial in Baltimore. Roy McGrath missed the first day of his trial on March 13.

## Rural PA county sanctioned by state Supreme Court over copied voting machine data
 - [https://www.foxnews.com/politics/rural-pa-county-sanctioned-state-supreme-court-copied-voting-machine-data](https://www.foxnews.com/politics/rural-pa-county-sanctioned-state-supreme-court-copied-voting-machine-data)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 17:42:57+00:00

Fulton County, Pennsylvania, was sanctioned by the state Supreme Court on Wednesday after two officials were found to have allowed a third party to copy 2020 voting machine data.

## Minnesota braces for major flooding following snowy winter
 - [https://www.foxnews.com/us/minnesota-braces-major-flooding-following-snowy-winter](https://www.foxnews.com/us/minnesota-braces-major-flooding-following-snowy-winter)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 17:41:31+00:00

While authorities expect most of Minnesota to remain clear of severe flooding conditions, they still warn that above-average rainfall and snowmelt may still pose a significant risk.

## Biden ripped for meeting protesting TN Dems, not shooting victims' families
 - [https://www.foxnews.com/media/biden-meeting-protesting-tn-dems-shooting-victims-families-situational-ethics](https://www.foxnews.com/media/biden-meeting-protesting-tn-dems-shooting-victims-families-situational-ethics)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 17:39:40+00:00

President Biden and the Democrats have &apos;situational ethics&apos; when it comes to infractions like storming capitol buildings, after the White House neglected to invite victims families.

## Fetterman raises eyebrows with choppy opening statement in Senate return: 'Frightening’
 - [https://www.foxnews.com/politics/fetterman-raises-eyebrows-choppy-opening-statement-senate-return-frightening](https://www.foxnews.com/politics/fetterman-raises-eyebrows-choppy-opening-statement-senate-return-frightening)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 17:39:14+00:00

Pennsylvania Senator John Fetterman raised eyebrows with his choppy opening statement as he chaired his first subcommittee hearing since returning from the hospital.

## Good Samaritan who stepped in to save Chicago couple being brutally beaten sends message to Lightfoot
 - [https://www.foxnews.com/us/good-samaritan-who-stepped-save-chicago-couple-being-brutally-beaten-sends-message-lightfoot](https://www.foxnews.com/us/good-samaritan-who-stepped-save-chicago-couple-being-brutally-beaten-sends-message-lightfoot)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 17:34:23+00:00

A Good Samaritan who stepped in to help a couple that was being brutally beaten during the weekend&apos;s Chicago &quot;Teen Takeover&quot; of downtown spoke out about the events.

## Maine man murdered his parents and their two friends just days after his mom picked him up from prison: police
 - [https://www.foxnews.com/us/maine-man-murdered-parents-two-friends-just-days-his-mom-picked-prison](https://www.foxnews.com/us/maine-man-murdered-parents-two-friends-just-days-his-mom-picked-prison)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 17:26:12+00:00

A man shot and killed his parents and two of their friends on Tuesday morning, just days after his mother picked him up from prison, according to Maine State Police.

## Tiger Woods undergoes procedure to treat foot injury; PGA Championship status unknown
 - [https://www.foxnews.com/sports/tiger-woods-undergoes-procedure-treat-foot-injury-pga-championship-status-unknown](https://www.foxnews.com/sports/tiger-woods-undergoes-procedure-treat-foot-injury-pga-championship-status-unknown)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 17:20:55+00:00

A little over a week after withdrawing from the Masters due to reaggravating his plantar fasciitis, Tiger Woods underwent a procedure in New York.

## Kristin Cavallari says she can ‘be a little threatening’ for men who ‘want to be needed’
 - [https://www.foxnews.com/entertainment/kristin-cavallari-says-can-be-little-threatening-men-who-want-needed](https://www.foxnews.com/entertainment/kristin-cavallari-says-can-be-little-threatening-men-who-want-needed)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 17:20:37+00:00

Kristin Cavallari was candid on not needing a man in her life, despite being an &quot;active dater.&quot; She also opened up on how having children has changed her dating habits.

## ‘80s supermodel Carol Alt, 62, shows off fit figure in curve-hugging dress
 - [https://www.foxnews.com/entertainment/80s-supermodel-carol-alt-62-shows-off-fit-figure-curve-hugging-dress](https://www.foxnews.com/entertainment/80s-supermodel-carol-alt-62-shows-off-fit-figure-curve-hugging-dress)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 17:17:27+00:00

Carol Alt, 62, showed off her fit figure while attending Canneseries to promote her new TV show. The model launched her career at 18 years old.

## Biden rule will redistribute high-risk loan costs to homeowners with good credit
 - [https://www.foxnews.com/us/biden-rule-redistribute-high-risk-loan-costs-homeowners-good-credit](https://www.foxnews.com/us/biden-rule-redistribute-high-risk-loan-costs-homeowners-good-credit)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 17:11:02+00:00

A new federal rule would make borrowing for a home more expensive for those with high credit scores to subsidize those with lowers qualify for better interest rates.

## Millionaires asking Congress for 90% top tax rate confronted with pledge to pay more voluntarily
 - [https://www.foxnews.com/politics/millionaires-asking-congress-90-top-tax-rate-confronted-pledge-pay-more-voluntarily](https://www.foxnews.com/politics/millionaires-asking-congress-90-top-tax-rate-confronted-pledge-pay-more-voluntarily)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 17:07:45+00:00

Members of Patriotic Millionaires were confronted with a pledge asking them to voluntarily pay a 90% tax rate during their own press conference calling for higher taxes on the rich.

## Credit Suisse lodges $440 million London claim against SoftBank
 - [https://www.foxnews.com/world/credit-suisse-lodges-440-million-london-claim-against-softbank](https://www.foxnews.com/world/credit-suisse-lodges-440-million-london-claim-against-softbank)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 17:06:54+00:00

Credit Suisse lodged a $440 million London claim against Japan&apos;s SoftBank Group Corp. A SoftBank official accused Suisse of shifting blame for its own poor investment decision.

## Massachusetts fire that destroyed church on Easter being investigated as arson, FBI says
 - [https://www.foxnews.com/us/massachusetts-fire-destroyed-church-easter-being-investigated-arson-fbi-says](https://www.foxnews.com/us/massachusetts-fire-destroyed-church-easter-being-investigated-arson-fbi-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 17:04:41+00:00

Authorities are asking the public for help in a suspect arson that destroyed a Massachusetts church.

## Mets' Max Scherzer ejected after heated conversation during substance check
 - [https://www.foxnews.com/sports/mets-max-scherzer-ejected-heated-conversation-substance-check](https://www.foxnews.com/sports/mets-max-scherzer-ejected-heated-conversation-substance-check)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 17:04:22+00:00

New York Mets pitcher Max Scherzer was bounced from Wednesday&apos;s game against the Los Angeles Dodgers over an argument during a substance check.

## 14 Dems join GOP in House vote to kill DC police reform law inspired by George Floyd’s death
 - [https://www.foxnews.com/politics/dems-join-gop-house-vote-kill-dc-police-reform-law-inspired-george-floyds-death](https://www.foxnews.com/politics/dems-join-gop-house-vote-kill-dc-police-reform-law-inspired-george-floyds-death)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 17:03:18+00:00

The House voted Wednesday to take down a DC law that Republicans say makes it harder and more dangerous for police to do their jobs in the District of Columbia.

## Video shows NYC Bodega owner beaten by four suspects in violent, possible hate crime attack
 - [https://www.foxnews.com/us/video-shows-nyc-bodega-owner-beaten-four-suspects-violent-possible-hate-crime-attack](https://www.foxnews.com/us/video-shows-nyc-bodega-owner-beaten-four-suspects-violent-possible-hate-crime-attack)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 17:02:00+00:00

A Coney Island Bodega owner was attacked Saturday by four unknown suspects and rushed to the hospital after being beaten with a metal pipe.

## Devils coach Andrew Brunette mentions Panthers’ head coaching gig to officers during DUI arrest, video shows
 - [https://www.foxnews.com/sports/devils-coach-andrew-brunette-mentions-panthers-head-coaching-gig-officers-during-dui-arrest-video-shows](https://www.foxnews.com/sports/devils-coach-andrew-brunette-mentions-panthers-head-coaching-gig-officers-during-dui-arrest-video-shows)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 17:00:58+00:00

Devils coach Andrew Brunette told officers during a DUI arrest in February about his previous head coaching gig with the Florida Panthers, newly released body cam footage shows.

## Washington State middle school blasted for ‘highly vile’ licking game between staff and students
 - [https://www.foxnews.com/media/washington-state-middle-school-blasted-highly-vile-licking-game-between-staff-students](https://www.foxnews.com/media/washington-state-middle-school-blasted-highly-vile-licking-game-between-staff-students)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 17:00:49+00:00

In a video recorded by students, kids and teachers are shown licking marshmallow cream off of either side of two clear plexiglass panes at the same time.

## Wisconsin Senate moves to reverse Supreme Court open records ruling
 - [https://www.foxnews.com/politics/wisconsin-senate-moves-reverse-supreme-court-open-records-ruling](https://www.foxnews.com/politics/wisconsin-senate-moves-reverse-supreme-court-open-records-ruling)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 16:59:59+00:00

The Wisconsin Senate on Wednesday moved to undo a state Supreme Court ruling that allowed state agencies to delay fulfillment of open records requests.

## Wisconsin bill doubling reckless driving penalties heads to Gov. Evers' desk
 - [https://www.foxnews.com/politics/wisconsin-bill-doubling-reckless-driving-penalties-heads-gov-evers-desk](https://www.foxnews.com/politics/wisconsin-bill-doubling-reckless-driving-penalties-heads-gov-evers-desk)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 16:58:31+00:00

A bipartisan Wisconsin bill doubling fines and forfeitures for reckless driving has passed the state Senate, with Democratic Gov. Tony Evers expected to sign it into law.

## Conflict-ravaged Sudan attempts 24-hour ceasefire after failed truce
 - [https://www.foxnews.com/world/conflict-ravaged-sudan-attempts-24-hour-ceasefire-failed-truce](https://www.foxnews.com/world/conflict-ravaged-sudan-attempts-24-hour-ceasefire-failed-truce)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 16:56:22+00:00

Rival Sudanese forces are attempting a 24-hour ceasefire, just a day after an internationally-brokered peace deal fell through within hours.

## Arizona man arrested for baptizing himself naked in church fountain
 - [https://www.foxnews.com/us/arizona-man-arrested-baptizing-naked-church-fountain](https://www.foxnews.com/us/arizona-man-arrested-baptizing-naked-church-fountain)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 16:49:05+00:00

Arizona suspect Jeremiah Sykes was arrested on April 15 for allegedly bathing himself naked in the fountain of One Life Church in Mesa, and later assaulting two police officers.

## Beijing cash: Businessman faces charges after allegedly trying to make 'quick buck' spying for China
 - [https://www.foxnews.com/world/beijing-cash-businessman-faces-charges-allegedly-trying-make-quick-buck-spying-china](https://www.foxnews.com/world/beijing-cash-businessman-faces-charges-allegedly-trying-make-quick-buck-spying-china)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 16:45:48+00:00

The magistrate argued Alexander Csergo did not alert Australian officials or authorities to the Chinese request and invited one of the alleged security agents to visit Australia.

## Texas Gov. Greg Abbott mobilizes specialized units on Mexico border as Title 42 end approaches
 - [https://www.foxnews.com/politics/texas-gov-greg-abbott-mobilizes-specialized-units-mexico-border-title-42-end-approaches](https://www.foxnews.com/politics/texas-gov-greg-abbott-mobilizes-specialized-units-mexico-border-title-42-end-approaches)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 16:44:53+00:00

Texas Gov. Greg Abbott has mobilized special units to the southern border in anticipation of the ending of Title 42 and a fresh migrant surge

## Illinois Gov. J.B. Pritzker draws White House speculation as Chicago preps for 2024 Democratic convention
 - [https://www.foxnews.com/politics/illinois-gov-j-b-pritzker-draws-white-house-speculation-chicago-preps-for-2024-democratic-convention](https://www.foxnews.com/politics/illinois-gov-j-b-pritzker-draws-white-house-speculation-chicago-preps-for-2024-democratic-convention)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 16:39:51+00:00

llinois Gov. J.B. Pritzker is sparking speculation he has eyes on a higher office, potentially the White House, after bringing the 2024 Democratic convention to Chicago.

## Georgia motel shut down for having stripper poles in rooms, other violations
 - [https://www.foxnews.com/us/georgia-motel-shut-down-having-stripper-poles-rooms-other-violations](https://www.foxnews.com/us/georgia-motel-shut-down-having-stripper-poles-rooms-other-violations)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 16:36:24+00:00

An Atlanta area hotel was shut down by the Fulton County Board of Health after inspectors found a plethora of issues with many rooms, according to police.

## Garlic: Planting, roasting and understanding the health benefits of the plant
 - [https://www.foxnews.com/lifestyle/garlic-planting-roasting-cooking-health-benefits](https://www.foxnews.com/lifestyle/garlic-planting-roasting-cooking-health-benefits)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 16:31:56+00:00

Garlic is an ingredient that brings out the flavor in large or small meals while providing several health benefits if consumed daily. Include fresh garlic cloves in your meals.

## Can companies come back from woke publicity stunt flops? 'Woke, Inc' author says yes
 - [https://www.foxnews.com/politics/companies-come-back-woke-publicity-stunt-flops-woke-inc-author-says](https://www.foxnews.com/politics/companies-come-back-woke-publicity-stunt-flops-woke-inc-author-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 16:30:13+00:00

Republican presidential contender and former businessman Vivek Ramaswamy says companies that go woke can can learn from their mistakes and exit the culture war conversations.

## Florida Gov. DeSantis dedicates millions to fighting harmful blue-green algae blooms
 - [https://www.foxnews.com/science/florida-gov-desantis-dedicates-millions-fighting-harmful-blue-green-algae-blooms](https://www.foxnews.com/science/florida-gov-desantis-dedicates-millions-fighting-harmful-blue-green-algae-blooms)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 16:25:09+00:00

Florida Gov. Ron DeSantis announced the awarding of over $13 million toward 10 projects aimed at preventing and cleaning up harmful blue-green algae blooms.

## A's pitcher Trevor May placed on IL to deal with anxiety
 - [https://www.foxnews.com/sports/as-pitcher-trevor-may-placed-il-deal-anxiety](https://www.foxnews.com/sports/as-pitcher-trevor-may-placed-il-deal-anxiety)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 16:23:57+00:00

Oakland Athletics right-handed reliever Trevor May is the third person this season to hit the injured list to deal with his mental health.

## ESPN personalities slam Biden's Title IX proposal amid uproar over transgender athletes in women's sports
 - [https://www.foxnews.com/sports/espn-personalities-slam-bidens-title-ix-proposal-uproar-transgender-athletes-womens-sports](https://www.foxnews.com/sports/espn-personalities-slam-bidens-title-ix-proposal-uproar-transgender-athletes-womens-sports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 16:23:27+00:00

ESPN personalities Sage Steele and Samantha Ponder tweeted their displeasure with the Biden administration over its plan on new Title IX rules.

## Left-wing nonprofit leads charge against Justice Clarence Thomas: 'Political drive-by shooting'
 - [https://www.foxnews.com/politics/left-wing-nonprofit-leads-charge-against-justice-clarence-thomas-political-drive-by-shooting](https://www.foxnews.com/politics/left-wing-nonprofit-leads-charge-against-justice-clarence-thomas-political-drive-by-shooting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 16:15:30+00:00

CREW, a D.C.-based group that filed an ethics complaint against Supreme Court Justice Clarence Thomas, was quoted in the ProPublica report the group used last week as rationale for its grievance.

## Dolphins’ Tua Tagovailoa considered retirement 'for a time' after his multiple concussions
 - [https://www.foxnews.com/sports/dolphins-tua-tagovailoa-considered-retirement-for-time-multiple-concussions](https://www.foxnews.com/sports/dolphins-tua-tagovailoa-considered-retirement-for-time-multiple-concussions)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 16:13:16+00:00

Miami Dolphins quarterback Tua Tagovailoa told reporters Wednesday he considered walking away from football &quot;for a time&quot; after suffering multiple concussions in 2022.

## Texas cheerleader shot after getting in wrong car speaks out as friend remains in critical condition
 - [https://www.foxnews.com/us/texas-cheerleader-shot-after-getting-wrong-car-speaks-out-friends-remains-critical-condition](https://www.foxnews.com/us/texas-cheerleader-shot-after-getting-wrong-car-speaks-out-friends-remains-critical-condition)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 16:07:35+00:00

One of two Texas cheerleaders who were shot after allegedly getting in the wrong vehicle at a carpool on Monday is speaking out as her friend remains in critical condition.

## Generic drugmaker sues FDA to keep abortion pill on market
 - [https://www.foxnews.com/us/generic-drugmaker-sues-fda-keep-abortion-pill-market](https://www.foxnews.com/us/generic-drugmaker-sues-fda-keep-abortion-pill-market)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 16:04:50+00:00

A generic drugmaker GenBioPro Inc sued the U.S. Food and Drug Administration Wednesday to keep the abortion pill on the market amidst ongoing legal challenges.

## Drunk ex-con kills 54-year-old New York man in road rage attack: cops
 - [https://www.foxnews.com/us/drunk-ex-con-kills-54-year-old-new-york-man-road-rage-attack-cops](https://www.foxnews.com/us/drunk-ex-con-kills-54-year-old-new-york-man-road-rage-attack-cops)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 16:00:55+00:00

A 26-year-old New York felon is back behind bars this week after Nassau County police say he beat another man to death in a road rage assault Saturday.

## Rosie O’Donnell blasts ex-‘View’ colleagues, vows to never return as host: ‘Not the best use of my talent’
 - [https://www.foxnews.com/media/rosie-odonnell-blasts-ex-view-colleagues-vows-to-never-return-as-host-not-the-best-use-of-my-talent](https://www.foxnews.com/media/rosie-odonnell-blasts-ex-view-colleagues-vows-to-never-return-as-host-not-the-best-use-of-my-talent)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 16:00:12+00:00

Actress and former co-host of &quot;The View&quot; Rosie O&apos;Donnell revealed during a podcast that while she had no regrets about her time on the show, she would never do it again.

## Jayapal criticized for saying immigrants 'needed' in America to 'pick the food we eat' and 'clean our homes'
 - [https://www.foxnews.com/politics/jayapal-criticized-saying-immigrants-needed-america-to-pick-the-food-we-eat-clean-our-homes](https://www.foxnews.com/politics/jayapal-criticized-saying-immigrants-needed-america-to-pick-the-food-we-eat-clean-our-homes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 15:59:14+00:00

Democrat Rep. Pramila Jayapal said immigrants are needed in America because they, among other things, &quot;pick the food we eat,&quot; &quot;clean our homes,&quot; and &quot;rebuild our communities after climate disasters.&quot;

## Microsoft land buy outside Milwaukee slated to become $1B data center
 - [https://www.foxnews.com/us/microsoft-land-buy-outside-milwaukee-slated-become-1b-data-center](https://www.foxnews.com/us/microsoft-land-buy-outside-milwaukee-slated-become-1b-data-center)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 15:58:45+00:00

Microsoft has agreed to purchase a $50 million land parcel in Racine County, Wisconsin, to build a data center at a site originally meant for Foxconn.

## Puppy thrown from moving truck in Los Angeles could find new home soon
 - [https://www.foxnews.com/lifestyle/puppy-thrown-moving-truck-los-angeles-find-new-home-soon](https://www.foxnews.com/lifestyle/puppy-thrown-moving-truck-los-angeles-find-new-home-soon)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 15:57:35+00:00

The Los Angeles Police Department in California, rescued a puppy that had been thrown from a truck during a high-speed chase. The animal could soon be put up for adoption.

## Soros-backed prosecutor's office under fire for murder case no-show as trial set for potential removal
 - [https://www.foxnews.com/politics/soros-backed-prosecutors-office-under-fire-murder-case-no-show-trial-set-potential-removal](https://www.foxnews.com/politics/soros-backed-prosecutors-office-under-fire-murder-case-no-show-trial-set-potential-removal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 15:48:22+00:00

A George Soros-backed prosecutor in St. Louis already facing a legal effort by Missouri&apos;s attorney general to fire her may also be held in criminal contempt of court.

## Bob Lee murder suspect Nima Momeni on suicide watch in San Francisco jail
 - [https://www.foxnews.com/us/bob-lee-murder-suspect-nima-momeni-suicide-watch-san-francisco-jail](https://www.foxnews.com/us/bob-lee-murder-suspect-nima-momeni-suicide-watch-san-francisco-jail)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 15:47:48+00:00

Nima Momeni, the Bay Area tech entrepreneur accused of fatally stabbing Cash App founder Bob Lee in San Francisco, is being held on suicide watch.

## Ukraine's top prosecutor speaks of 'evil' Russian atrocities
 - [https://www.foxnews.com/world/ukraines-top-prosecutor-speaks-evil-russian-atrocities](https://www.foxnews.com/world/ukraines-top-prosecutor-speaks-evil-russian-atrocities)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 15:43:36+00:00

Ukraine’s top prosecutor described for U.S. lawmakers examples of war atrocities that he says are deliberately orchestrated by Russian forces to spread terror among civilians.

## Supreme Court puts off any decision on access to medical abortion pill mifepristone until Friday
 - [https://www.foxnews.com/politics/supreme-court-decision-access-medical-abortion-pill-mifepristone-friday](https://www.foxnews.com/politics/supreme-court-decision-access-medical-abortion-pill-mifepristone-friday)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 15:41:00+00:00

The U.S. Supreme Court temporarily extended the pause placed on mifepristone, a controversial abortion drug, until Friday, April 21 at 11:59 p.m. ET.

## Texas-born princess facing imminent eviction from Rome villa
 - [https://www.foxnews.com/world/texas-born-princess-facing-imminent-eviction-rome-villa](https://www.foxnews.com/world/texas-born-princess-facing-imminent-eviction-rome-villa)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 15:38:35+00:00

A Texas-born princess is facing a court-ordered eviction from a Rome villa containing the a ceiling painted by Caravaggio. The eviction order marked the peak of an inheritance saga.

## Otis Redding III, who followed father into music, dies at 59
 - [https://www.foxnews.com/us/otis-redding-iii-followed-father-music-dies-59](https://www.foxnews.com/us/otis-redding-iii-followed-father-music-dies-59)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 15:30:31+00:00

Otis Redding III, who followed his father into the music industry, died at the age of 59 after losing a battle with cancer. Redding was 3 years old when his father died in a 1967 plane crash

## Ancient ring adorned with Roman emperor image sells for nearly 600 times its expected price at auction
 - [https://www.foxnews.com/lifestyle/ancient-ring-adorned-roman-emperor-image-sells-nearly-600-times-expected-price-auction](https://www.foxnews.com/lifestyle/ancient-ring-adorned-roman-emperor-image-sells-nearly-600-times-expected-price-auction)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 15:30:09+00:00

A ring believed to contain an image of Augustus Caesar, the first emperor of Rome, sold for $145,000 in a recent auction in Birmingham, England. The initial estimate was well below that figure.

## 'Elitist' AOC lambasted for objecting to NYPD raises: 'Her facts are wrong'
 - [https://www.foxnews.com/media/elitist-aoc-lambasted-objecting-nypd-raises-facts-wrong](https://www.foxnews.com/media/elitist-aoc-lambasted-objecting-nypd-raises-facts-wrong)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 15:30:02+00:00

&apos;Outnumbered&apos; panelists ripped Rep. Alexandria Ocasio-Cortez after she falsely claimed NYPD officers earn more money than teachers who have a master&apos;s degree.

## Indiana man pleads guilty to killing ex-girlfriend, grandmother outside factory
 - [https://www.foxnews.com/us/indiana-man-pleads-guilty-killing-ex-girlfriend-grandmother-factory](https://www.foxnews.com/us/indiana-man-pleads-guilty-killing-ex-girlfriend-grandmother-factory)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 15:25:10+00:00

Gary Ferrell II has pleaded guilty to the 2021 shooting deaths of ex-girlfriend Promise Mays and her grandmother, Pamela Sledd, outside a Frankfort, Indiana factory.

## Reddit to charge AI companies for use of its API
 - [https://www.foxnews.com/tech/reddit-ai-companies-pay-use-of-api](https://www.foxnews.com/tech/reddit-ai-companies-pay-use-of-api)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 15:25:08+00:00

Reddit is planning to charge tech giants that are making strides in the artificial intelligence sector for the use of its application programming interface.

## Canada’s federal workers go on strike over wages, delaying some services
 - [https://www.foxnews.com/world/canadas-federal-workers-strike-wages-delaying-some-services](https://www.foxnews.com/world/canadas-federal-workers-strike-wages-delaying-some-services)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 15:23:01+00:00

Some 155,000 workers — or roughly a third of those in Canda&apos;s public sector — went on strike Wednesday after failing to reach a deal to increase wages.

## McCarthy mocks ‘missing in action’ Dems on debt ceiling in floor speech: ‘Maple syrup month’
 - [https://www.foxnews.com/politics/mccarthy-mocks-missing-action-dems-debt-ceiling-floor-speech-maple-syrup-month](https://www.foxnews.com/politics/mccarthy-mocks-missing-action-dems-debt-ceiling-floor-speech-maple-syrup-month)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 15:20:46+00:00

The House Speaker said the Limit, Save, Grow Act would save $4.5 trillion for American taxpayers by capping spending and limiting it for the next 10 years

## Matthew McConaughey and Woody Harrelson plan to take DNA test to see if they're actually brothers
 - [https://www.foxnews.com/entertainment/matthew-mcconaughey-woody-harrelson-dna-test-actually-brothers](https://www.foxnews.com/entertainment/matthew-mcconaughey-woody-harrelson-dna-test-actually-brothers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 15:17:23+00:00

Hollywood actors Matthew McConaughey and Woody Harrelson made the decision to participate in a DNA test after a family revelation that the two may actually be related.

## Tragic twist in death of 5-year-old boy whose parents blamed black mold
 - [https://www.foxnews.com/us/tragic-twist-death-5-year-old-boy-whose-parents-blamed-black-mold](https://www.foxnews.com/us/tragic-twist-death-5-year-old-boy-whose-parents-blamed-black-mold)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 15:16:32+00:00

The stepfather and mother of a 5-year-old Mississippi boy are being charged in the child&apos;s death, with the stepfather facing capital murder charges in the case.

## Former UConn student gets 55 years for shooting classmate, kidnapping girlfriend
 - [https://www.foxnews.com/us/former-uconn-student-gets-55-years-shooting-classmate-kidnapping-girlfriend](https://www.foxnews.com/us/former-uconn-student-gets-55-years-shooting-classmate-kidnapping-girlfriend)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 15:13:05+00:00

Peter Manfredonia, 26, of Connecticut, was sentenced to 55 years in prison Wednesday for killing Nicholas Eisele and kidnapping his girlfriend, transporting her across state lines.

## Oklahoma county commissioner resigns after leak of audio discussing killing journalists, lynchings
 - [https://www.foxnews.com/us/oklahoma-county-commissioner-resigns-leak-audio-discussing-killing-journalists-lynchings](https://www.foxnews.com/us/oklahoma-county-commissioner-resigns-leak-audio-discussing-killing-journalists-lynchings)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 15:05:52+00:00

McCurtain County Commissioner Mark Jennings has resigned Wednesday following the leak of controversial audio, the office of Oklahoma Gov. Kevin Stitt says.

## California homeless man who plowed into teens, killing 1, wanted for other crimes, including stabbing: police
 - [https://www.foxnews.com/us/california-homeless-man-who-plowed-into-teens-killing-1-wanted-for-other-crimes-including-stabbing-police](https://www.foxnews.com/us/california-homeless-man-who-plowed-into-teens-killing-1-wanted-for-other-crimes-including-stabbing-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 15:05:05+00:00

A homeless man in California is charged with killing a teenager and injuring three others when he intentionally hit them with his car, police said

## Inspector general slams 'unprecedented' lack of cooperation from state department on Afghanistan oversight
 - [https://www.foxnews.com/politics/inspector-general-slams-unprecedented-uncooperation-biden-state-department-afghanistan-oversight](https://www.foxnews.com/politics/inspector-general-slams-unprecedented-uncooperation-biden-state-department-afghanistan-oversight)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 15:04:30+00:00

Special Inspector General for Afghanistan Reconstruction John Sopko told lawmakers the State Department has failed to comply with its legal obligations to turn over information.

## White House dodges on when Biden will confront Xi Jinping over alleged secret police stations, spy balloons
 - [https://www.foxnews.com/politics/white-house-dodges-when-biden-confront-xi-jinping-alleged-secret-police-stations-spy-balloons](https://www.foxnews.com/politics/white-house-dodges-when-biden-confront-xi-jinping-alleged-secret-police-stations-spy-balloons)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 15:02:28+00:00

White House press secretary Karine Jean-Pierre refused to say when President Biden will confront China&apos;s Xi Jinping over recent actions against the U.S.

## WA bill to let shelters house runaway trans kids without notifying parents: 'Government-sanctioned kidnapping'
 - [https://www.foxnews.com/media/washington-bill-shelters-house-runaway-trans-kids-notifying-parents-government-sanctioned-kidnapping](https://www.foxnews.com/media/washington-bill-shelters-house-runaway-trans-kids-notifying-parents-government-sanctioned-kidnapping)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 15:00:57+00:00

Former Washington Senate candidate Tiffany Smiley and podcast host Brandi Kruse ripped a state bill that would let kids get gender-affirming care without parental consent.

## Connecticut man given 55-year prison sentence for murdering friend, kidnapping woman
 - [https://www.foxnews.com/us/connecticut-man-given-55-year-prison-sentence-murdering-friend-kidnapping-woman](https://www.foxnews.com/us/connecticut-man-given-55-year-prison-sentence-murdering-friend-kidnapping-woman)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 14:56:10+00:00

A Connecticut man was sentenced to 55 years in prison Wednesday for the murder of his friend and the kidnappings of a woman, and will face another sentencing hearing Thursday.

## Nebraska lawmakers pass permitless concealed carry gun bill
 - [https://www.foxnews.com/us/nebraska-lawmakers-pass-permitless-concealed-carry-gun-bill](https://www.foxnews.com/us/nebraska-lawmakers-pass-permitless-concealed-carry-gun-bill)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 14:50:35+00:00

Lawmakers in Nebraska passed a bill that will allow people to carry concealed guns without a permit. The Nebraska bill does not eliminate the requirement for a background check to buy a gun.

## Quentin Tarantino admits he owns a gun for 'protection' while calling for stricter laws
 - [https://www.foxnews.com/media/quentin-tarantino-admits-he-owns-gun-protection-while-calling-stricter-laws](https://www.foxnews.com/media/quentin-tarantino-admits-he-owns-gun-protection-while-calling-stricter-laws)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 14:50:31+00:00

In a recent interview, &quot;Pulp Fiction&quot; director Quentin Tarantino admitted he owned a gun for &quot;protection,&quot; despite supporting more gun control in the U.S.

## Dartmouth football coach Buddy Teevens has leg amputated, suffered spinal cord injury following bicycle crash
 - [https://www.foxnews.com/sports/dartmouth-football-coach-buddy-teevens-leg-amputated-suffered-spinal-cord-injury-following-bicycle-crash](https://www.foxnews.com/sports/dartmouth-football-coach-buddy-teevens-leg-amputated-suffered-spinal-cord-injury-following-bicycle-crash)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 14:48:50+00:00

Dartmouth head football coach Buddy Teevens was in bicycle crash involving a truck last month and had his right leg amputated as a result, the university revealed Tuesday.

## Seattle apartments evacuated after firework goes off, sending man to hospital
 - [https://www.foxnews.com/us/seattle-apartments-evacuated-firework-goes-off-sending-man-hospital](https://www.foxnews.com/us/seattle-apartments-evacuated-firework-goes-off-sending-man-hospital)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 14:48:40+00:00

Seattle authorities said an apartment building on 1st Avenue North was evacuated Wednesay morning following 911 calls about an explosion in abasement unit. One victim was treated for a non-life-threatening injury at the scene.

## New box jellyfish found near Hong Kong in 1st discover of the venomous species in China’s waters
 - [https://www.foxnews.com/world/new-box-jellyfish-found-near-hong-kong-1st-discover-venomous-species-chinas-waters](https://www.foxnews.com/world/new-box-jellyfish-found-near-hong-kong-1st-discover-venomous-species-chinas-waters)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 14:44:23+00:00

A new jellyfish named Tripedalia maipoensis was found in China’s waters near Hong Kong. The species is colorless, cube-shaped, and can swim faster than other kinds of jellyfish.

## US jets intercept Russian Tu-95 bombers near Alaska; first encounter there since US drone taken down
 - [https://www.foxnews.com/politics/us-jets-intercept-russian-tu-95-bombers-near-alaska-first-encounter-there-since-us-drone-taken-down](https://www.foxnews.com/politics/us-jets-intercept-russian-tu-95-bombers-near-alaska-first-encounter-there-since-us-drone-taken-down)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 14:41:21+00:00

The Alaskan Region of North American Aerospace Defense Command announced Wednesday that U.S. fighter jets intercepted Russian bombers near Alaska Monday.

## Mayorkas comes face to face with family of grandmother, 7-year-old girl killed by human smuggler near border
 - [https://www.foxnews.com/politics/mayorkas-comes-face-face-family-grandmother-7-year-old-girl-killed-human-smuggler-border](https://www.foxnews.com/politics/mayorkas-comes-face-face-family-grandmother-7-year-old-girl-killed-human-smuggler-border)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 14:33:19+00:00

Homeland Security Secretary Alejandro Mayorkas was asked to apologize to the Tambunga family Wednesday after two of their kin were killed in a traffic accident.

## UFO Senate hearing: Pentagon official 'concerned' about China and Russia's 'advanced tech'
 - [https://www.foxnews.com/us/ufo-senate-hearing-pentagon-official-concerned-about-chinas-and-russias-advanced-tech](https://www.foxnews.com/us/ufo-senate-hearing-pentagon-official-concerned-about-chinas-and-russias-advanced-tech)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 14:28:43+00:00

Sean Kirkpatrick, director of the All-domain Anomaly Resolution Office, said he&apos;s &quot;concerned&quot; about U.S. adversaries&apos; technological capabilities to attack and surveil U.S. interests

## US Federal Trade Commission leaders plan to pursue companies that misuse AI to violate civil rights
 - [https://www.foxnews.com/tech/us-federal-trade-commission-leaders-plan-pursue-companies-misuse-ai-violate-civil-rights](https://www.foxnews.com/tech/us-federal-trade-commission-leaders-plan-pursue-companies-misuse-ai-violate-civil-rights)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 14:22:12+00:00

The U.S. Federal Trade Commission leaders said the agency plans to target artificial intelligence used to violate laws against discrimination or create deceptive acts.

## Tennessee mother, son who brought zip-ties into Senate gallery on Jan. 6 convicted
 - [https://www.foxnews.com/us/tennessee-mother-son-convicted-bringing-plastic-zip-tie-handcuffs-capitol-protest](https://www.foxnews.com/us/tennessee-mother-son-convicted-bringing-plastic-zip-tie-handcuffs-capitol-protest)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 14:19:45+00:00

A mother and son from Tennessee were convicted for bringing plastic zip-tie handcuffs to the Senate chamber during the Jan. 6 Capitol protest that opposed Biden’s presidential victory.

## French hecklers call for President Emmanuel Macron's resignation during 'crowd bath'
 - [https://www.foxnews.com/world/french-hecklers-call-president-emmanuel-macrons-resignation-crowd-bath](https://www.foxnews.com/world/french-hecklers-call-president-emmanuel-macrons-resignation-crowd-bath)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 14:17:08+00:00

As French President Emmanuel Macron visited eastern France, hecklers shouted for him to resign. The president is still largely disliked after pushing through unpopular pension reforms.

## Insurance losses from Mississippi tornado nearing $100M
 - [https://www.foxnews.com/us/insurance-losses-mississippi-tornado-nearing-100m](https://www.foxnews.com/us/insurance-losses-mississippi-tornado-nearing-100m)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 14:15:09+00:00

The Mississippi Insurance Department said insurance losses from the March tornado that wreaked havoc throughout the state are approaching $100 million.

## Tesla factory where worker died had safety issues
 - [https://www.foxnews.com/world/tesla-factory-where-worker-died-had-safety-issues](https://www.foxnews.com/world/tesla-factory-where-worker-died-had-safety-issues)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 14:12:52+00:00

Tesla’s Shanghai factory where a worker died in February was reported for safety weaknesses. Tesla employees complained their bonuses were cut due to the fatality.

## Family of man who died in jail from inadequate medical care files lawsuit
 - [https://www.foxnews.com/us/family-man-died-jail-inadequate-medical-care-files-lawsuit](https://www.foxnews.com/us/family-man-died-jail-inadequate-medical-care-files-lawsuit)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 14:11:08+00:00

The family of a man who died in jail from inadequate medical care filed a malpractice lawsuit on Friday. The suit claims the inmate died from an ulcer that caused internal bleeding.

## DC Health Link data breach blamed on basic human error
 - [https://www.foxnews.com/us/dc-health-link-data-breach-blamed-basic-human-error](https://www.foxnews.com/us/dc-health-link-data-breach-blamed-basic-human-error)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 14:08:31+00:00

The Washington D.C. Health Link data breach was blamed on basic human error. The recent data breach exposed information on thousands of users of D.C.’s health insurance exchange.

## Filing seeks to force National Archives to tap DOJ to recover lost Secret Service, DHS texts around Jan. 6
 - [https://www.foxnews.com/politics/filing-seeks-force-national-archives-tap-doj-recover-lost-secret-service-dhs-texts-jan-6](https://www.foxnews.com/politics/filing-seeks-force-national-archives-tap-doj-recover-lost-secret-service-dhs-texts-jan-6)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 14:07:19+00:00

A lawsuit seeks to implore the National Archives to ask the U.S. attorney general for help recovering Secret Service, DHS messages lost during the Trump-Biden transition.

## ‘French Spiderman’ free climbs Paris skyscraper to protest pension law
 - [https://www.foxnews.com/world/french-spiderman-free-climbs-paris-skyscraper-protest-pension-law](https://www.foxnews.com/world/french-spiderman-free-climbs-paris-skyscraper-protest-pension-law)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 14:03:52+00:00

&quot;French Spiderman&quot; Alain Robert scaled a 38-story skyscraper without a harness to protest President Macron’s pension law that changed the country’s retirement age from 62 to 64.

## Spain's prime minister says drought has become one of country's leading concerns
 - [https://www.foxnews.com/world/spains-prime-minister-says-drought-become-one-countrys-leading-concerns](https://www.foxnews.com/world/spains-prime-minister-says-drought-become-one-countrys-leading-concerns)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 14:03:09+00:00

Spanish Prime Minister Pedro Sánchez claims the long-term drought that has plagued the country has become one of its leading concerns. The drought will be a central political topic.

## University backtracks on quiz question claiming ‘wealthy White men’ are more violent, lack remorse
 - [https://www.foxnews.com/media/university-backtracks-quiz-question-wealthy-white-men-violent-lack-remorse](https://www.foxnews.com/media/university-backtracks-quiz-question-wealthy-white-men-violent-lack-remorse)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 14:00:56+00:00

A psychology professor at The University of Texas at Austin reportedly apologized after a quiz question labeling wealthy White men as more likely to be violent raised concerns.

## Rand Paul torches Dr. Fauci: 'One of the worst judgment errors' in history of public health
 - [https://www.foxnews.com/media/rand-paul-torches-dr-fauci-one-worst-judgment-errors-history-public-health](https://www.foxnews.com/media/rand-paul-torches-dr-fauci-one-worst-judgment-errors-history-public-health)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 14:00:48+00:00

Sen. Rand Paul ripped Fauci for going &apos;around the system&apos; with research funding in China as a bombshell report reveals new evidence on the origins of the pandemic

## Teixeira leaked classified docs demanded by Senate Intel panel
 - [https://www.foxnews.com/politics/senate-intelligence-committee-classified-pentagon-documents](https://www.foxnews.com/politics/senate-intelligence-committee-classified-pentagon-documents)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 14:00:32+00:00

Senate Intelligence Committee Chair Mark Warner and ranking member Marco Rubio sent a letter to Defense Secretary Lloyd Austin on Wednesday

## Robert F. Kennedy Jr. gains sizable chunk of Biden voters at presidential launch: poll
 - [https://www.foxnews.com/politics/robert-f-kennedy-jr-gains-sizable-chunk-biden-voters-presidential-launch-poll](https://www.foxnews.com/politics/robert-f-kennedy-jr-gains-sizable-chunk-biden-voters-presidential-launch-poll)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 13:58:19+00:00

A new poll showed that Democrat presidential challenger Robert F. Kennedy, Jr. took 14 percent of President Biden&apos;s 2020 voters after Kennedy announced his candidacy earlier this month.

## 'Serial liar' GOP rep's re-election bid sets social media ablaze: 'funniest primaries'
 - [https://www.foxnews.com/politics/serial-liar-gop-reps-re-election-bid-sets-social-media-ablaze-funniest-primaries](https://www.foxnews.com/politics/serial-liar-gop-reps-re-election-bid-sets-social-media-ablaze-funniest-primaries)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 13:57:35+00:00

Rep. George Santos was met with jokes in response to his announced bid for re-election, with social media users poking fun at the lawmaker&apos;s relationship with the truth.

## Florida education board expands limitations on gender identity lessons in public schools
 - [https://www.foxnews.com/politics/florida-education-board-expands-limitations-gender-identity-lessons-in-public-schools](https://www.foxnews.com/politics/florida-education-board-expands-limitations-gender-identity-lessons-in-public-schools)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 13:56:33+00:00

The Florida Board of Education on Wednesday approved Republican Gov. Ron DeSantis’ request to expand his Parental Rights in Education law from K-3 to all grades.

## Cattlemen roast vegan NYC mayor for cracking down on food as part of climate agenda
 - [https://www.foxnews.com/politics/cattlemen-roast-vegan-nyc-mayor-cracking-down-food-part-climate-agenda](https://www.foxnews.com/politics/cattlemen-roast-vegan-nyc-mayor-cracking-down-food-part-climate-agenda)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 13:54:02+00:00

Democratic New York City Mayor Eric Adams announced a citywide effort to reduce carbon emissions and fight climate change by targeting food production and consumption.

## 9 men connected to Jehovah's Witnesses were accused of child sexual abuse in Pennsylvania in recent months
 - [https://www.foxnews.com/us/9-men-connected-jehovahs-witnesses-accused-child-sexual-abuse-pennsylvania-recent-months](https://www.foxnews.com/us/9-men-connected-jehovahs-witnesses-accused-child-sexual-abuse-pennsylvania-recent-months)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 13:51:36+00:00

Multiple people connected to Jehovah&apos;s Witnesses were recently accused of child sexual abuse in Pennsylvania. Some defendants allegedly used their positions to prey upon victims.

## Mexican government says California police shooting represents 'unreasonable' use of lethal force
 - [https://www.foxnews.com/us/mexican-government-says-california-police-shooting-represented-unreasonable-use-lethal-force](https://www.foxnews.com/us/mexican-government-says-california-police-shooting-represented-unreasonable-use-lethal-force)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 13:51:29+00:00

Police in Oxnard, California, fatally shot Cristian Baltazar Torres earlier in the month. Mexico&apos;s government believes the shooting represents &quot;unreasonable&quot; use of lethal force.

## Rachel McAdams turned down ‘Iron Man,’ ‘Casino Royale’ roles for this reason
 - [https://www.foxnews.com/entertainment/rachel-mcadams-turned-down-iron-man-casino-royale-roles-this-reason](https://www.foxnews.com/entertainment/rachel-mcadams-turned-down-iron-man-casino-royale-roles-this-reason)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 13:40:35+00:00

Rachel McAdams explained why she turned down films such as &quot;The Devil Wears Prada&quot; and &quot;Iron Man&quot; during a two-year break in her career in a new interview.

## Suspect in Japan PM pipe bomb attack wanted to be a politician, angry he was blocked from running, report says
 - [https://www.foxnews.com/world/suspect-japan-pm-pipe-bomb-attack-politician-angry-blocked-running-report-says](https://www.foxnews.com/world/suspect-japan-pm-pipe-bomb-attack-politician-angry-blocked-running-report-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 13:38:55+00:00

The man who allegedly threw an explosive at the Japanese prime minister may have been holding a grudge. The suspect was earlier blocked from running for Japan’s parliament.

## Alexandria Ocasio-Cortez blasts Biden over 'lurch to the Right': 'It's quite dangerous'
 - [https://www.foxnews.com/media/rep-alexandria-ocasio-cortez-blasts-biden-over-lurch-right-quite-dangerous](https://www.foxnews.com/media/rep-alexandria-ocasio-cortez-blasts-biden-over-lurch-right-quite-dangerous)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 13:37:52+00:00

Rep. Alexandria Ocasio-Cortez blasted President Biden during an interview this month over his &quot;lurch to the right&quot; and warned it was a &quot;profound miscalculation.&quot;

## India to become world’s most populous country by mid-2023, according to UN
 - [https://www.foxnews.com/world/india-become-worlds-populous-country-mid-2023-according-un](https://www.foxnews.com/world/india-become-worlds-populous-country-mid-2023-according-un)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 13:36:45+00:00

While China has been the world’s most populous country since 1950, India is expected to take the title by mid-2023 as the country&apos;s young population soars.

## Officer injured in shootout outside Florida hospital, suspect dead at scene: Sheriff's office
 - [https://www.foxnews.com/us/officer-injured-shootout-outside-florida-hospital-suspect-dead-scene-sheriffs-office](https://www.foxnews.com/us/officer-injured-shootout-outside-florida-hospital-suspect-dead-scene-sheriffs-office)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 13:36:32+00:00

A shootout in the parking lot of a hospital in Jacksonville, Florida resulted in an injured officer and a dead suspect, the local sheriff&apos;s office said.

## Maine gunman accused of killing 4, wounding 3 has violent criminal history, released from prison days earlier
 - [https://www.foxnews.com/us/maine-gunman-accused-killing-4-wounding-3-violent-criminal-history-could-not-legally-own-firearms](https://www.foxnews.com/us/maine-gunman-accused-killing-4-wounding-3-violent-criminal-history-could-not-legally-own-firearms)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 13:33:14+00:00

Joseph Eaton, 34, is accused of killing four people at a home in Bowdoin, Maine, and wounding three others in a highway shooting 25 miles away on Tuesday.

## Colorado DA accused of 'ethical violations' in missing Susan Morphew case
 - [https://www.foxnews.com/us/colorado-da-accused-ethical-violations-barry-morphew-missing-wife-case](https://www.foxnews.com/us/colorado-da-accused-ethical-violations-barry-morphew-missing-wife-case)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 13:29:51+00:00

Barry Morphew&apos;s lawyer, Iris Eytan, is accusing Colorado District Attorney Linda Stanley of ethical violations in the 2020 case of Morphew&apos;s missing wife, Suzanne.

## Stephen A. Smith 'disgusted with the NBA' suspending Warriors' Draymond Green over stomp
 - [https://www.foxnews.com/sports/stephen-a-smith-disgusted-nba-suspending-warriors-draymond-green-stomp](https://www.foxnews.com/sports/stephen-a-smith-disgusted-nba-suspending-warriors-draymond-green-stomp)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 13:21:19+00:00

ESPN analyst Stephen A. Smith responded to the NBA&apos;s suspension of Draymond Green for Game 3 of the playoff series against the Sacramento Kings.

## Texas best friends, age 81, go viral for traveling to 7 continents in 80 days: 'Make some plans and live'
 - [https://www.foxnews.com/lifestyle/texas-best-friends-age-81-go-viral-traveling-7-continents-80-days-make-plans-live](https://www.foxnews.com/lifestyle/texas-best-friends-age-81-go-viral-traveling-7-continents-80-days-make-plans-live)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 13:19:48+00:00

Two women from Texas who have been friends for 23 years, recently went viral on TikTok as they traveled to seven continents, and &quot;around the world in 80 days.&quot;

## Liz Cheney unveils book deal focused on 'the threat posed by Trump'
 - [https://www.foxnews.com/politics/liz-cheney-unveils-book-deal-focused-threat-posed-trump](https://www.foxnews.com/politics/liz-cheney-unveils-book-deal-focused-threat-posed-trump)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 13:17:07+00:00

Liz Cheney is coming out with a new book, &quot;Oath and Honor,&quot; that promises to reveal the inner workings of the congressional January 6 investigation.

## AOC's campaign obscured thousands of dollars in expenditures, FEC complaint claims
 - [https://www.foxnews.com/politics/aoc-obscured-thousands-dollars-campaign-expenditures-fec-complaint-claims](https://www.foxnews.com/politics/aoc-obscured-thousands-dollars-campaign-expenditures-fec-complaint-claims)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 13:15:55+00:00

Democratic Rep. Alexandria Ocasio-Cortez&apos;s campaign failed to properly disclose where nearly $10,000 of its card payments went, according to an FEC complaint.

## US Army analyzing metal canisters found in Fort Totten Park in Washington, DC
 - [https://www.foxnews.com/us/us-army-analyzing-metal-canisters-found-fort-totten-park-washington-dc](https://www.foxnews.com/us/us-army-analyzing-metal-canisters-found-fort-totten-park-washington-dc)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 13:14:04+00:00

Part of Fort Totten Park in Washington, D.C., was closed after a National Parks worker found canisters in a mound of soil, prompting an Army investigation.

## Top Senate Republicans coalesce around McCarthy after he unveils debt limit proposal
 - [https://www.foxnews.com/politics/top-senate-republicans-coalesce-mccarthy-unveils-debt-limit-proposal](https://www.foxnews.com/politics/top-senate-republicans-coalesce-mccarthy-unveils-debt-limit-proposal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 13:08:12+00:00

Both moderate and conservative Republican senators praised House Speaker Kevin McCarthy for having a debt limit plan and said President Biden needs to start talking to his GOP opponents.

## Republican KY gubernatorial candidate Daniel Cameron supports work requirement for some Medicaid recipients
 - [https://www.foxnews.com/politics/republican-ky-gubernatorial-candidate-cameron-supports-imposing-work-rules-medicaid-recipients](https://www.foxnews.com/politics/republican-ky-gubernatorial-candidate-cameron-supports-imposing-work-rules-medicaid-recipients)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 13:06:58+00:00

Daniel Cameron, a Republican gubernatorial candidate in Kentucky, wants to create work requirements for some Medicaid recipients, a measure that Biden’s team has previously opposed.

## Wisconsin officer charged after striking man with his car at traffic stop in 2021
 - [https://www.foxnews.com/us/wisconsin-officer-charged-striking-man-car-following-traffic-stop-2021](https://www.foxnews.com/us/wisconsin-officer-charged-striking-man-car-following-traffic-stop-2021)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 13:01:15+00:00

A Wisconsin police officer struck a man with his car following a traffic stop in 2021. The police officer was charged with felony misconduct on April 19, 2023.

## 60 top Google Play apps infected with Android malware affecting millions
 - [https://www.foxnews.com/tech/60-top-google-play-apps-infected-android-malware-affecting-millions](https://www.foxnews.com/tech/60-top-google-play-apps-infected-android-malware-affecting-millions)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 12:53:25+00:00

McAfee has discovered a number of apps that has been infected with a new Android malware, which has led to the infection of Android phones.

## Ray Romano reveals unexpected way 'Everybody Loves Raymond' got it's name: 'I was so petrified'
 - [https://www.foxnews.com/entertainment/ray-romano-reveals-unexpected-way-everybody-loves-raymond-got-name](https://www.foxnews.com/entertainment/ray-romano-reveals-unexpected-way-everybody-loves-raymond-got-name)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 12:46:27+00:00

Ray Romano was the star of the hit sitcom &quot;Everybody Loves Raymond,&quot; and just revealed the unexpected origin of the show&apos;s name. The CBS sitcom ran from 1996 to 2005 and won 15 Emmys.

## 11 Indonesian fishermen rescued after spending nearly a week without food, water off Australia
 - [https://www.foxnews.com/world/11-indonesian-fishermen-rescued-spending-nearly-week-food-water-australia](https://www.foxnews.com/world/11-indonesian-fishermen-rescued-spending-nearly-week-food-water-australia)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 12:44:13+00:00

After two boats were caught in a cyclone, Australian rescue teams were able to save 11 Indonesian fishermen. Another eight men are feared to have drowned.

## Prime minister of Luxembourg stands up for LGBTQ rights in the EU, chastises Hungary
 - [https://www.foxnews.com/world/prime-minister-luxembourg-stands-lgbtq-rights-eu-chastises-hungary](https://www.foxnews.com/world/prime-minister-luxembourg-stands-lgbtq-rights-eu-chastises-hungary)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 12:43:38+00:00

Prime Minister Xavier Bettel of Luxembourg, who is gay, is standing up for LGBTQ rights in the European Union. Bettel chastised Hungary for anti-LGBTQ policy sugestions.

## 49ers receiving calls for 2021 third-overall pick Trey Lance: report
 - [https://www.foxnews.com/sports/49ers-receiving-calls-2021-third-overall-pick-trey-lance-report](https://www.foxnews.com/sports/49ers-receiving-calls-2021-third-overall-pick-trey-lance-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 12:43:15+00:00

NFL teams have made calls to the San Francisco 49ers regarding a potential trade for quarterback Trey Lance, who is coming off a broken ankle in 2022.

## Bulgaria becomes latest EU country to ban Ukrainian grain imports following protests from local farmers
 - [https://www.foxnews.com/world/bulgaria-becomes-latest-eu-country-ban-ukrainian-grain-imports-protests-local-farmers](https://www.foxnews.com/world/bulgaria-becomes-latest-eu-country-ban-ukrainian-grain-imports-protests-local-farmers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 12:41:50+00:00

Ukrainian grain imports have been temporarily banned in Bulgaria. Multiple European Union countries have already banned grain imports from Ukraine.

## Long-time Texas death row inmate can pursue DNA testing following decision by Supreme Court
 - [https://www.foxnews.com/us/long-time-texas-death-row-inmate-can-pursue-dna-testing-following-decision-supreme-court](https://www.foxnews.com/us/long-time-texas-death-row-inmate-can-pursue-dna-testing-following-decision-supreme-court)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 12:41:11+00:00

Rodney Reed, a long-time Texas death row inmate, will be able to test DNA that he believes will clear him, following a decision by the Supreme Court.

## Madagascar suffering 'catastrophic' hunger in remote, inaccessible areas due to recent cyclones
 - [https://www.foxnews.com/world/madagascar-suffering-catastrophic-hunger-remote-inaccessible-areas-recent-cyclones](https://www.foxnews.com/world/madagascar-suffering-catastrophic-hunger-remote-inaccessible-areas-recent-cyclones)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 12:38:31+00:00

Madagascar is experiencing &quot;catastrophic&quot; hunger in inaccessible and remote areas of the country. The country has suffered through three cyclones since the year began.

## US trade envoy visits Tokyo, suggests country needs to deepen trade ties with Japan
 - [https://www.foxnews.com/world/us-trade-envoy-visits-tokyo-suggests-country-deepen-trade-ties-japan](https://www.foxnews.com/world/us-trade-envoy-visits-tokyo-suggests-country-deepen-trade-ties-japan)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 12:37:30+00:00

Katherine Tai, a top United States trade envoy, believes the U.S. has to deepen trade ties with Japan. Tai met with Japan&apos;s foreign minister to discuss making supply chains.

## Former Ohio vice squad officer found not guilty of murder after shooting woman while undercover
 - [https://www.foxnews.com/us/former-ohio-vice-squad-officer-not-guilty-murder-shooting-woman-undercover](https://www.foxnews.com/us/former-ohio-vice-squad-officer-not-guilty-murder-shooting-woman-undercover)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 12:36:43+00:00

Andrew Mitchell, a 59-year-old former vice squad officer, has been found not guilty in the fatal shooting of a woman from five years ago. Mitchell was undercover when he shot the woman.

## North Korea claims first-ever military spy satellite ready for launch, which would violate UN resolutions
 - [https://www.foxnews.com/world/north-korea-claims-military-spy-satellite-ready-launch-violate-un-resolutions](https://www.foxnews.com/world/north-korea-claims-military-spy-satellite-ready-launch-violate-un-resolutions)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 12:36:11+00:00

China has accused the U.S. and South Korea for flaring tensions with North Korea with military drills, prompting Pyongyang to launch a ballistic missile and spy satellite.

## ElectraMeccanica buying back all of 3-wheel Solo EVs and discontinuing the vehicle
 - [https://www.foxnews.com/auto/electrameccanica-buying-back-solo-evs-discontinuing](https://www.foxnews.com/auto/electrameccanica-buying-back-solo-evs-discontinuing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 12:34:14+00:00

ElectraMeccanica is discontinuing its Solo single-seat vehicle and buying back all of the existing models as it develops a new two-seat vehicle.

## India’s religious divide continues to widen between Muslim, Hindu community
 - [https://www.foxnews.com/world/indias-religious-divide-continues-widen-muslim-hindu-community](https://www.foxnews.com/world/indias-religious-divide-continues-widen-muslim-hindu-community)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 12:33:48+00:00

Ayodhya has become a religious microcosm of India. The country&apos;s Muslim minority is trying to safeguard its freedoms as the Hindu community is aiming to redeem its religious past.

## Trump criminal defense attorney in Alvin Bragg crosshairs over possible conflict of interest
 - [https://www.foxnews.com/us/trump-criminal-defense-attorney-alvin-bragg-crosshairs-over-possible-conflict-interest](https://www.foxnews.com/us/trump-criminal-defense-attorney-alvin-bragg-crosshairs-over-possible-conflict-interest)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 12:28:18+00:00

Manhattan prosecutors target one of Donald Trump&apos;s lawyers, Joe Tacopina, for possible removal over potential conflict of interest involving porn star Stormy Daniels.

## Sen. Kennedy roasts Biden's unqualified judicial nominees from 'the loon wing' of the Democratic Party
 - [https://www.foxnews.com/media/sen-kennedy-roasts-biden-unqualified-judicial-nominees-loon-wing-democratic-party](https://www.foxnews.com/media/sen-kennedy-roasts-biden-unqualified-judicial-nominees-loon-wing-democratic-party)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 12:25:50+00:00

Sen. John Kennedy, R-La., said Democrats are trying to replace Sen. Dianne Feinstein on the Senate Judiciary Committee so far-left judges can be &quot;rammed through.&apos;

## Tyre Nichols’ family files ‘landmark’ civil lawsuit against Memphis following death after police encounter
 - [https://www.foxnews.com/us/tyre-nichols-family-files-landmark-civil-lawsuit-against-memphis-death-police-encounter](https://www.foxnews.com/us/tyre-nichols-family-files-landmark-civil-lawsuit-against-memphis-death-police-encounter)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 12:24:00+00:00

The family of Tyre Nichols has filed a lawsuit against the city of Memphis, its police department and several officers following his January 2023 death.

## House Republicans take on Empire state of mind amid debt ceiling standoff, Trump indictment
 - [https://www.foxnews.com/politics/house-republicans-take-empire-state-mind-amid-debt-ceiling-standoff-trump-indictment](https://www.foxnews.com/politics/house-republicans-take-empire-state-mind-amid-debt-ceiling-standoff-trump-indictment)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 12:20:51+00:00

House Republicans turn to Manhattan as the debt ceiling fight drags on and the GOP leads field hearings focused on crime

## Robert F. Kennedy Jr. launches Democratic challenge against Biden, vows to fight 'corporate feudalism'
 - [https://www.foxnews.com/politics/robert-f-kennedy-jr-launches-democratic-challenge-biden-vows-fight-corporate-feudalism](https://www.foxnews.com/politics/robert-f-kennedy-jr-launches-democratic-challenge-biden-vows-fight-corporate-feudalism)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 12:11:50+00:00

Environmental lawyer and anti-vaccine advocate Robert F. Kennedy, Jr. on Wednesday formally launched a 2024 Democratic presidential primary challenge against President Biden

## Crisis comms expert who helped Hunter Biden with subpoena visited WH over 30 times when Biden was VP
 - [https://www.foxnews.com/politics/crisis-comms-expert-who-helped-hunter-biden-subpoena-visited-wh-over-30-times-biden-vp](https://www.foxnews.com/politics/crisis-comms-expert-who-helped-hunter-biden-subpoena-visited-wh-over-30-times-biden-vp)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 12:05:46+00:00

A current President Biden appointee with close ties to Hunter Biden visited the White House more than 30 times when Biden was vice president.

## Should Biden dump Kamala Harris as his vice president? Americans weigh in
 - [https://www.foxnews.com/politics/biden-dump-kamala-harris-vice-president-americans-weigh](https://www.foxnews.com/politics/biden-dump-kamala-harris-vice-president-americans-weigh)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 12:00:38+00:00

Americans share whether they think President Biden should keep Kamala Harris as his vice president in 2024 or if the Democrats need fresh faces on the ticket.

## Disney lawyers worried about ‘optics,’ disguised their input in last-ditch development deal, emails show
 - [https://www.foxnews.com/politics/disney-lawyers-worried-optics-disguised-input-last-ditch-development-deal-emails-show](https://www.foxnews.com/politics/disney-lawyers-worried-optics-disguised-input-last-ditch-development-deal-emails-show)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 11:54:33+00:00

Disney lawyers were concerned about the &quot;optics&quot; of their involvement in drafting development agreements that would insulate the company from state oversight, according to emails.

## New service keeps you from making a mistake on your next Apple purchase
 - [https://www.foxnews.com/tech/new-service-keeps-you-making-mistake-your-next-apple-purchase](https://www.foxnews.com/tech/new-service-keeps-you-making-mistake-your-next-apple-purchase)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 11:51:45+00:00

Apple&apos;s newest web service helps you navigate the various Apple iPhone models available for purchase to ensure you purchase the best option for your needs.

## Byron Donalds introduces 'Big Biden Blunder Act' demanding accountability for botched Afghanistan withdrawal
 - [https://www.foxnews.com/politics/byron-donalds-big-biden-blunder-act-accountability-botched-afghanistan-withdrawal](https://www.foxnews.com/politics/byron-donalds-big-biden-blunder-act-accountability-botched-afghanistan-withdrawal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 11:49:53+00:00

Florida Republican Congressman Byron Donalds is introducing the Big Biden Blunder Act that would hold the Biden administration accountable for its botched withdrawal from Afghanistan.

## Woman's seductive pose at Auschwitz prompts outrage, response from museum demanding respect
 - [https://www.foxnews.com/media/womans-seductive-pose-auschwitz-outrage-response-museum-demanding-respect](https://www.foxnews.com/media/womans-seductive-pose-auschwitz-outrage-response-museum-demanding-respect)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 11:45:47+00:00

A British producer&apos;s tweet containing a photo of an anonymous woman posing on the train tracks at Auschwitz, letting an unnamed man snap a photo of her, went viral on Twitter.

## Congress gears up to smack down President Biden's Chinese solar handout
 - [https://www.foxnews.com/politics/congress-gears-up-smack-down-president-bidens-solar-handout](https://www.foxnews.com/politics/congress-gears-up-smack-down-president-bidens-solar-handout)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 11:45:44+00:00

Congress is gearing up to vote on bipartisan legislation that would repeal President Biden&apos;s executive action suspending tariffs designed to protect the U.S. solar industry.

## Two teens charged in Dadeville, Alabama, mass shooting at Sweet 16 birthday party
 - [https://www.foxnews.com/us/two-teens-charged-dadeville-alabama-mass-shooting-sweet-16-birthday-party](https://www.foxnews.com/us/two-teens-charged-dadeville-alabama-mass-shooting-sweet-16-birthday-party)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 11:44:17+00:00

Two teen suspects were arrested and charged with four counts of murder in a mass shooting at a Sweet 16 birthday party in Alabama that left 32 others hurt.

## Alec Baldwin will return to 'Rust' set this week as filming resumes after fatal shooting
 - [https://www.foxnews.com/entertainment/alec-baldwin-will-return-rust-set-this-week-filming-resumes-after-fatal-shooting](https://www.foxnews.com/entertainment/alec-baldwin-will-return-rust-set-this-week-filming-resumes-after-fatal-shooting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 11:43:29+00:00

Alec Baldwin will be on the set of &quot;Rust&quot; for the first day of filming following the death of Halyna Hutchins, Fox News Digital can confirm.

## China preparing supersonic spy drone unit, leaked US military assessment reportedly says
 - [https://www.foxnews.com/world/china-preparing-supersonic-spy-drone-unit-leaked-us-military-assessment-reportedly-says](https://www.foxnews.com/world/china-preparing-supersonic-spy-drone-unit-leaked-us-military-assessment-reportedly-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 11:40:43+00:00

The Washington Post reported that a leaked document posted on Discord shows the Chinese military is readying a supersonic high altitude spy drone unit.

## Former Minneapolis Gophers player shot at by retired firefighter who hurled racial slur: police
 - [https://www.foxnews.com/us/former-minneapolis-gophers-player-shot-retired-firefighter-hurled-racial-slur-police](https://www.foxnews.com/us/former-minneapolis-gophers-player-shot-retired-firefighter-hurled-racial-slur-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 11:39:10+00:00

A retired Minneapolis firefighter has been charged after allegedly attacking and using a racial slur against former Gophers running back Tellis Redmon.

## Astros announcer appears to take subtle dig at Blue Jays’ Anthony Bass following popcorn fiasco
 - [https://www.foxnews.com/sports/astros-announcer-appears-take-subtle-dig-blue-jays-anthony-bass-popcorn-fiasco](https://www.foxnews.com/sports/astros-announcer-appears-take-subtle-dig-blue-jays-anthony-bass-popcorn-fiasco)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 11:30:53+00:00

Astros announcer Geoff Blum appeared to take a jab at Blue Jays reliever Anthony Bass during Monday game over an incident involving his pregnant wife and daughter on a United flight.

## Reporter says he filmed hundreds of military-age Chinese men heading toward US in migrant groups
 - [https://www.foxnews.com/media/reporter-says-filmed-hundreds-military-age-chinese-men-heading-toward-us-migrant-groups](https://www.foxnews.com/media/reporter-says-filmed-hundreds-military-age-chinese-men-heading-toward-us-migrant-groups)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 11:30:13+00:00

Muckraker.com founder Anthony Rubin joined &quot;Fox &amp; Friends First&quot; to describe footage showing Chinese nationals lining up in Panama to head toward the United States.

## Electric vehicles may be too heavy for old parking garages: report
 - [https://www.foxnews.com/auto/electric-vehicles-heavy-parking-garages-report](https://www.foxnews.com/auto/electric-vehicles-heavy-parking-garages-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 11:29:33+00:00

A report from the British Parking Association raises concerns that some older parking structures may not be strong enough to accommodate heavy electric vehicles.

## Suspected Mara Salvatrucha gang leader arrested in Mexico City
 - [https://www.foxnews.com/world/suspected-mara-salvatrucha-gang-leader-arrested-mexico-city](https://www.foxnews.com/world/suspected-mara-salvatrucha-gang-leader-arrested-mexico-city)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 11:28:25+00:00

José Wilfredo Ayala-Alcántara, an allegedly MS-13 gang leader, was arrested in Mexico City. The suspect was wanted for terrorism, extortion, and drug distribution in the United States.

## Kaylin Gillis driveway shooting death: Boyfriend details wrong turn in New York woods, immediate aftermath
 - [https://www.foxnews.com/us/kaylin-gillis-driveway-shooting-death-boyfriend-details-wrong-turn-new-york-woods-immediate-aftermath](https://www.foxnews.com/us/kaylin-gillis-driveway-shooting-death-boyfriend-details-wrong-turn-new-york-woods-immediate-aftermath)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 11:20:56+00:00

New details emerge in the shooting death of a 20-year-old New York woman killed after her boyfriend drove down the wrong rural driveway Saturday night.

## George Clooney rips Johnny Depp, Mark Wahlberg for denying ‘Ocean’s Eleven’ role: ‘Told us to 'f--- right off'
 - [https://www.foxnews.com/entertainment/george-clooney-johnny-depp-mark-wahlberg-denying-oceans-eleven-role](https://www.foxnews.com/entertainment/george-clooney-johnny-depp-mark-wahlberg-denying-oceans-eleven-role)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 11:20:26+00:00

61-year-old Hollywood actor George Clooney revealed that Johnny Depp and Mark Wahlberg denied the role of Linus, played by Matt Damon, in &quot;Ocean&apos;s Eleven.&quot;

## Russian, Chinese defense officials agree to strengthen defense ties
 - [https://www.foxnews.com/world/russian-chinese-defense-officials-agree-strengthen-defense-ties](https://www.foxnews.com/world/russian-chinese-defense-officials-agree-strengthen-defense-ties)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 11:16:34+00:00

The Russian and Chinese militaries will commit to greater cooperation in the future after a successful meeting between the two countries&apos; defense ministers.

## Trans Montana lawmaker lashes out at GOP colleagues during House floor debate: 'Blood on your hands'
 - [https://www.foxnews.com/politics/trans-montana-lawmaker-lashes-gop-colleagues-house-floor-debate-blood-hands](https://www.foxnews.com/politics/trans-montana-lawmaker-lashes-gop-colleagues-house-floor-debate-blood-hands)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 11:07:07+00:00

A transgender state lawmaker in Montana is facing calls to be censured over comments made amid the legislature&apos;s efforts to pass amendments to a bill that would prohibit sex change treatments for minors.

## Jamie Foxx is 'healing' after suffering 'medical complication': report
 - [https://www.foxnews.com/entertainment/jamie-foxx-healing-suffering-medical-complication-report](https://www.foxnews.com/entertainment/jamie-foxx-healing-suffering-medical-complication-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 11:01:21+00:00

Jamie Foxx is said to be &quot;healing&quot; after suffering from a &quot;medical complication&quot; last week. The actor currently remains hospitalized in Georgia.

## Utah elementary school cancels slavery reenactment after parent outrage
 - [https://www.foxnews.com/media/utah-elementary-school-cancels-slavery-reenactment-parent-outrage](https://www.foxnews.com/media/utah-elementary-school-cancels-slavery-reenactment-parent-outrage)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 11:00:24+00:00

A Utah primary school apologized after asking fifth grade students to participate in a Civil War simulation of the Underground Railroad for a history lesson.

## Vivek Ramaswamy angers Don Lemon in debate over civil war, Second Amendment: 'It's infuriating'
 - [https://www.foxnews.com/media/vivek-ramaswamy-angers-don-lemon-debate-civil-war-second-amendment-its-infuriating](https://www.foxnews.com/media/vivek-ramaswamy-angers-don-lemon-debate-civil-war-second-amendment-its-infuriating)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 11:00:22+00:00

2024 presidential hopeful Vivek Ramaswamy angered CNN anchor Don Lemon during a debate over the Civil War and Second Amendment on &quot;CNN This Morning.&quot;

## Cloud seeding on the rise as Rocky Mountain region tackles two-decade drought
 - [https://www.foxnews.com/us/cloud-seeding-rise-rocky-mountain-region-tackles-two-decade-drought](https://www.foxnews.com/us/cloud-seeding-rise-rocky-mountain-region-tackles-two-decade-drought)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 10:55:45+00:00

States near the Rocky Mountains, such as Utah, Colorado, and Wyoming, have expanded its cloud-seeding programs to combat the region’s drought and produce more precipitation.

## GOP senators, led by Hagerty, re-introduce bill to expand Title 42 as order’s end approaches
 - [https://www.foxnews.com/politics/gop-senators-led-hagerty-re-introduce-bill-expand-title-42-orders-end-approaches](https://www.foxnews.com/politics/gop-senators-led-hagerty-re-introduce-bill-expand-title-42-orders-end-approaches)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 10:55:21+00:00

Republican lawmakers led by Sen. Bill Hagerty are giving another push to legislation to rescue Title 42 from expiring at the beginning of next month on May 11.

## Ukraine receives US-made Patriot guided missile systems to help shield from Russian airstrikes
 - [https://www.foxnews.com/world/ukraine-receives-us-patriot-guided-missile-systems-help-shield-russian-airstrikes](https://www.foxnews.com/world/ukraine-receives-us-patriot-guided-missile-systems-help-shield-russian-airstrikes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 10:53:36+00:00

Ukraine received US-made Patriot guided missile systems on April 19, 2023. The country&apos;s defense minister claimed &quot;Ukrainian sky becomes more secure&quot; after the systems arrived.

## Florida sheriff sends warning to 'sick, perverted, scum' after pastor busted using church Wi-Fi for child porn
 - [https://www.foxnews.com/us/florida-sheriff-sends-warning-to-sick-perverted-scum-after-pastor-busted-using-church-wifi-for-child-porn](https://www.foxnews.com/us/florida-sheriff-sends-warning-to-sick-perverted-scum-after-pastor-busted-using-church-wifi-for-child-porn)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 10:52:33+00:00

A Florida youth pastor and elementary school teacher has been arrested and charged with possession of child pornography, some of which police say he downloaded at church.

## Body burned in Florida field 'unrecognizable' as police ID person of interest
 - [https://www.foxnews.com/us/body-burned-in-florida-field-unrecognizable-as-police-id-person-of-interest](https://www.foxnews.com/us/body-burned-in-florida-field-unrecognizable-as-police-id-person-of-interest)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 10:47:47+00:00

Police in Hillsborough County, Florida are searching for a suspect who&apos;s wanted in connection with setting a man on fire in Ruskin field Saturday, which the sheriff called a &quot;jarring scene&quot;

## Hunter Greene, Reds agree to six-year contract extension
 - [https://www.foxnews.com/sports/hunter-greene-reds-agree-six-year-contract-extension](https://www.foxnews.com/sports/hunter-greene-reds-agree-six-year-contract-extension)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 10:36:44+00:00

The Cincinnati Reds and Hunter Greene agreed to a six-year contract on Tuesday to keep the fireball pitcher in the red and white for years to come.

## Dodgers honor legendary broadcaster Vin Scully with tribute before Mets game
 - [https://www.foxnews.com/sports/dodgers-honor-legendary-broadcaster-vin-scully-tribute-before-mets-game](https://www.foxnews.com/sports/dodgers-honor-legendary-broadcaster-vin-scully-tribute-before-mets-game)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 10:35:13+00:00

The Los Angeles Dodgers honored the late Vin Scully on Tuesday before a game against the New York Mets. Scully called Dodgers games for 67 years.

## Alex Berenson says lawsuit against Biden, Pfizer could reveal internal communications about COVID vaccine
 - [https://www.foxnews.com/media/alex-berenson-lawsuit-against-biden-pfizer-could-reveal-internal-communications-about-covid-vaccine](https://www.foxnews.com/media/alex-berenson-lawsuit-against-biden-pfizer-could-reveal-internal-communications-about-covid-vaccine)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 10:34:57+00:00

Alex Berenson believes his lawsuit against President Biden and Pfizer officials who allegedly pushed for his removal from Twitter could expose internal communications about the COVID vaccine.

## Moscow court dismisses Russian opposition figure's appeal of 8 1/2 year prison sentence
 - [https://www.foxnews.com/world/moscow-court-dismisses-russian-opposition-figures-appeal-8-1/2-year-prison-sentence](https://www.foxnews.com/world/moscow-court-dismisses-russian-opposition-figures-appeal-8-1/2-year-prison-sentence)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 10:24:50+00:00

Ilya Yashin, a prominent Russian opposition figure, is in prison for eight and a half years for his criticizing Russia&apos;s actions in Ukraine. Yashin&apos;s appeal was dismissed in court.

## Afghanistan IG report hammers Biden administration for 'dysfunction' days after White House blames Trump
 - [https://www.foxnews.com/politics/afghanistan-ig-report-hammers-biden-administration-dysfunction-days-white-house-blames-trump](https://www.foxnews.com/politics/afghanistan-ig-report-hammers-biden-administration-dysfunction-days-white-house-blames-trump)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 10:23:00+00:00

A government watchdog blasted President Biden&apos;s administration for failing to keep its promises to Afghan allies, noting that refugee resettlement is undermined by &quot;dysfunction and understaffing.&quot;

## Ro Khanna predicts far-left will be 'dominating presidential elections for next 15 years'
 - [https://www.foxnews.com/media/ro-khanna-predicts-far-left-dominating-presidential-elections-next-15-years](https://www.foxnews.com/media/ro-khanna-predicts-far-left-dominating-presidential-elections-next-15-years)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 10:15:49+00:00

Some moderate Democrats believe their party is heading towards a &quot;reckoning&quot; as the progressive wing continues to build power and both sides debate the direction of the party.

## Retired spacecraft will reenter Earth's atmosphere with some risk to humans, NASA says
 - [https://www.foxnews.com/us/retired-spacecraft-will-reenter-earths-atmosphere-with-some-risk-to-humans-nasa-says](https://www.foxnews.com/us/retired-spacecraft-will-reenter-earths-atmosphere-with-some-risk-to-humans-nasa-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 10:15:48+00:00

NASA&apos;s retired Reuven Ramaty High Energy Solar Spectroscopic Imager spacecraft is predicted to reenter Earth&apos;s atmosphere sometime Wednesday night with minimal yet possible risk.

## Washington inmate on the loose after impersonating cellmate set for release
 - [https://www.foxnews.com/us/washington-inmate-loose-impersonating-cellmate-set-release](https://www.foxnews.com/us/washington-inmate-loose-impersonating-cellmate-set-release)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 10:15:44+00:00

Brian Roman is at large after escaping from jail in Cowlitz County, Washington, by impersonating his cellmate who was due to be released, authorities said.

## Judge delays Pentagon leak suspect Jack Teixeira detention hearing after defense asks for more time
 - [https://www.foxnews.com/politics/judge-delays-pentagon-leak-suspect-jack-teixeira-detention-hearing-defense-asks-more-time](https://www.foxnews.com/politics/judge-delays-pentagon-leak-suspect-jack-teixeira-detention-hearing-defense-asks-more-time)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 10:07:08+00:00

An attorney for Pentagon leak suspect Jack Douglas Teixeira asked a federal judge to delay Wednesday&apos;s detention hearing, and the judge agreed.

## Pablo López, Twins agree to four-year contract extension: reports
 - [https://www.foxnews.com/sports/pablo-lopez-twins-agree-four-year-contract-extension-reports](https://www.foxnews.com/sports/pablo-lopez-twins-agree-four-year-contract-extension-reports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 10:04:54+00:00

The Minnesota Twins and Pablo López agreed to a four-year contract extension on Monday, according to multiple reports. He is set to be the anchor in the rotation for several years.

## Many House Republicans urge Biden administration to support 'a free Taiwan' as China tensions mount
 - [https://www.foxnews.com/politics/many-house-republicans-urge-biden-administration-support-free-taiwan-china-tensions-mount](https://www.foxnews.com/politics/many-house-republicans-urge-biden-administration-support-free-taiwan-china-tensions-mount)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 10:00:09+00:00

House Republicans want the State Department to offer stronger support to Taiwan by inviting them to a key Asian-Pacific summit later this year.

## Here's how to hold our rogue FDA accountable
 - [https://www.foxnews.com/opinion/hold-rogue-fda-accountable](https://www.foxnews.com/opinion/hold-rogue-fda-accountable)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 10:00:05+00:00

Americans should be able to trust the Food and Drug Administration. But the agency has long betrayed that trust when it comes to chemical abortion drugs.

## Heritage recommends DOJ, FBI overhaul for next GOP president to end ‘radical liberal agenda’
 - [https://www.foxnews.com/politics/heritage-recommends-doj-fbi-overhaul-gop-president-end-radical-liberal-agenda](https://www.foxnews.com/politics/heritage-recommends-doj-fbi-overhaul-gop-president-end-radical-liberal-agenda)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 10:00:01+00:00

The Heritage Foundation is publishing a blueprint for the next conservative administration on how to overhaul the FBI and Department of Justice.

## Virginia dad rips embattled school district's $11 million all-gender bathroom renovation plan: 'Insulting'
 - [https://www.foxnews.com/media/virginia-dad-school-district-11-million-gender-bathroom-renovation-plan-insulting](https://www.foxnews.com/media/virginia-dad-school-district-11-million-gender-bathroom-renovation-plan-insulting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 09:59:00+00:00

Loudoun County, Virginia dad and school board candidate Michael Rivera weighed in on the school&apos;s pilot plan to spend $11 million on co-ed bathrooms in a number of schools.

## Seattle panel: Police needs to offer sincere apologize for violent protest response
 - [https://www.foxnews.com/us/seattle-police-needs-offer-sincere-apologize-violent-protest-response-panel](https://www.foxnews.com/us/seattle-police-needs-offer-sincere-apologize-violent-protest-response-panel)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 09:54:37+00:00

A panel said that Washington’s Seattle Police Department needs to apologize for its violent treatment towards the demonstrators protesting the 2020 killing of George Floyd.

## Arizona inmate receives second death sentence for castrating, killing cellmate with razor blade
 - [https://www.foxnews.com/us/arizona-inmate-receives-second-death-sentence-castrating-killing-cellmate-razor-blade](https://www.foxnews.com/us/arizona-inmate-receives-second-death-sentence-castrating-killing-cellmate-razor-blade)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 09:47:03+00:00

An Arizona inmate who was sentenced to death for the murder of a 40-year-old woman received the same sentence again after castrating and murdering his cellmate.

## North Carolina students catch up academically post-COVID
 - [https://www.foxnews.com/us/north-carolina-students-catch-school-post-covid](https://www.foxnews.com/us/north-carolina-students-catch-school-post-covid)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 09:43:28+00:00

Students in North Carolina are catching up academically post-pandemic. An analysis reported that the students were months behind due to closed schools and limited in-person teaching.

## German police release description of knife attack suspect that seriously wounded 4 men
 - [https://www.foxnews.com/world/german-police-release-description-knife-attack-suspect-seriously-wounded-4-men](https://www.foxnews.com/world/german-police-release-description-knife-attack-suspect-seriously-wounded-4-men)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 09:42:58+00:00

The description of a man who is suspected of wounding four people with a knife at a gym in Duisburg, Germany, has been released. Investigators are looking into a possible motive.

## US Navy sails first drone boat through Strait of Hormuz between Iran, Oman
 - [https://www.foxnews.com/world/us-navy-sails-first-drone-boat-strait-hormuz-between-iran-oman](https://www.foxnews.com/world/us-navy-sails-first-drone-boat-strait-hormuz-between-iran-oman)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 09:37:03+00:00

A Navy drone boat safely passed through the Strait of Hormuz between Iran and Oman. The mission was successful even though American sailors often face tension in the area.

## Home Depot worker fatally shot in California was trying to stop shoplifting, witnesses say
 - [https://www.foxnews.com/us/home-depot-worker-fatally-shot-california-trying-stop-shoplifting-witnesses-say](https://www.foxnews.com/us/home-depot-worker-fatally-shot-california-trying-stop-shoplifting-witnesses-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 09:27:45+00:00

Witnesses at a Home Depot in Pleasanton, California, told cops that an employee was shot during a struggle with alleged shoplifters on Tuesday afternoon.

## ‘Jeopardy!’ host Ken Jennings slams fans for complaining about ‘incorrect’ clue: ‘Buy a dictionary’
 - [https://www.foxnews.com/entertainment/jeopardy-host-ken-jennings-slams-fans-complaining-incorrect-clue](https://www.foxnews.com/entertainment/jeopardy-host-ken-jennings-slams-fans-complaining-incorrect-clue)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 09:23:39+00:00

A &quot;Jeopardy!&quot; fan argued with game show host Ken Jennings on Twitter over a puzzle in the rhyming category. The two disputed whether the words &quot;sake&quot; and &quot;jockey&quot; rhymed.

## NYC deadly parking garage collapse: Building had 4 active violations, cause of 'pancaked' structure unclear
 - [https://www.foxnews.com/us/nyc-deadly-parking-garage-collapse-building-4-active-violations-cause-pancaked-structure-unclear](https://www.foxnews.com/us/nyc-deadly-parking-garage-collapse-building-4-active-violations-cause-pancaked-structure-unclear)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 09:20:31+00:00

The cause of a parking garage collapse in Lower Manhattan remains unclear as investigations continue. Reports indicate the building had active violations.

## Texas Tech cheerleader dubbed 'Masters girl' wows fans with golf skills: 'That’s a heck of a swing'
 - [https://www.foxnews.com/sports/texas-tech-cheerleader-dubbed-masters-girl-wows-fans-golf-skills-thats-heck-of-swing](https://www.foxnews.com/sports/texas-tech-cheerleader-dubbed-masters-girl-wows-fans-golf-skills-thats-heck-of-swing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 09:18:43+00:00

Texas Tech cheerleader Aaliyah Kikumoto wowed her new-found fans in her latest TikTok video showing off her golf swing at a range.

## Donalds grills Biden SEC commissioner on Steele dossier payment
 - [https://www.foxnews.com/politics/donalds-grills-biden-sec-commissioner-steele-dossier-payment](https://www.foxnews.com/politics/donalds-grills-biden-sec-commissioner-steele-dossier-payment)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 09:13:39+00:00

Securities and Exchange Commission Chair Gary Gensler butted heads with Republican Byron Donalds at a House Appropriations Subcommittee hearing on Tuesday.

## In Oregon, magic mushroom 'facilitators' receive licenses in step forward for regulated use of psilocybin
 - [https://www.foxnews.com/us/oregon-magic-mushroom-facilitators-receive-licenses-step-forward-regulated-use-psilocybin](https://www.foxnews.com/us/oregon-magic-mushroom-facilitators-receive-licenses-step-forward-regulated-use-psilocybin)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 09:09:03+00:00

A service center that would accompany clients taking magic mushrooms in Oregon has received its state licenses. Anticipation has been building for those wanting to take the psilocybin.

## Russian influence peddling adds to fears after election of untested president in European nation
 - [https://www.foxnews.com/world/russian-influence-peddling-adds-fears-after-election-untested-president-european-nation](https://www.foxnews.com/world/russian-influence-peddling-adds-fears-after-election-untested-president-european-nation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 09:07:54+00:00

Montenegro is a NATO member and EU aspirant, but internal pro-Serbian and pro-Russian elements are making things tougher for further integration in Europe.

## Vermont's capital city celebrates poetry with parade, display of poems
 - [https://www.foxnews.com/us/vermonts-capital-city-celebrates-poetry-parade-display-poems](https://www.foxnews.com/us/vermonts-capital-city-celebrates-poetry-parade-display-poems)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 09:00:40+00:00

The capitol city of Vermont is celebrating poetry with a parade and other festivities. Restaurant in the city&apos;s downtown have poems in their windows and poetry workshops are being held

## New Mexico, Texas rivers seeing benefits of record snowpack, spring runoff
 - [https://www.foxnews.com/us/new-mexico-texas-rivers-drinking-water-being-benefitted-boost-winter-snowpack](https://www.foxnews.com/us/new-mexico-texas-rivers-drinking-water-being-benefitted-boost-winter-snowpack)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 08:53:10+00:00

Two different rivers that are used for drinking water in New Mexico and Texas are seeing the benefits of the winter snowpack and spring runoff.

## Nonbinary Biden official was still paid government salary while facing felony charge: Report
 - [https://www.foxnews.com/media/nonbinary-biden-official-was-paid-government-salary-facing-felony-charge-report](https://www.foxnews.com/media/nonbinary-biden-official-was-paid-government-salary-facing-felony-charge-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 08:49:02+00:00

Former Biden official Sam Brinton was still paid a six-figure government salary while facing a felony charge for stealing airport luggage, a report from Townhall said.

## Colorado's Democratic-controlled Legislature passes package of gun control measures
 - [https://www.foxnews.com/politics/colorados-democratic-controlled-legislature-passes-package-gun-control-measures](https://www.foxnews.com/politics/colorados-democratic-controlled-legislature-passes-package-gun-control-measures)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 08:39:12+00:00

The Democratic-controlled Legislature in Colorado passed a package of gun control measures. The state&apos;s governor is expected to sign the bills into law.

## Baltimore schools accused of covering up low test scores: 'Treating us like we're stupid'
 - [https://www.foxnews.com/media/baltimore-schools-accused-covering-low-test-scores-treating-us-like-stupid](https://www.foxnews.com/media/baltimore-schools-accused-covering-low-test-scores-treating-us-like-stupid)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 08:38:46+00:00

Baltimore city officials are accused of being involved in a &apos;cover-up&apos; after students&apos; failing test scores were redacted from an online database

## McCaul says Blinken trying to ‘stonewall’ Afghanistan subpoena for key withdrawal doc as hearings begin
 - [https://www.foxnews.com/politics/mccaul-says-blinken-trying-stonewall-afghanistan-subpoena-key-withdrawal-doc-hearings-begin](https://www.foxnews.com/politics/mccaul-says-blinken-trying-stonewall-afghanistan-subpoena-key-withdrawal-doc-hearings-begin)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 08:38:08+00:00

Secretary of State Antony Blinken has not complied with a congressional subpoena for documents relating to President Biden&apos;s withdrawal from Afghanistan.

## Jets' Morgan Barron receives 75 stitches after skate cuts face: 'It was an unlucky play'
 - [https://www.foxnews.com/sports/jets-morgan-barron-receives-75-stitches-skate-cuts-face-it-was-unlucky-play](https://www.foxnews.com/sports/jets-morgan-barron-receives-75-stitches-skate-cuts-face-it-was-unlucky-play)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 08:34:24+00:00

Winnipeg Jets forward Morgan Barron needed 75 stitches after he received a cut to his forehead in the Stanley Cup playoff game against the Vegas Golden Knights.

## Jane Seymour, 72, shows off enviable body in skintight dress
 - [https://www.foxnews.com/entertainment/jane-seymour-72-shows-enviable-body-skintight-dress](https://www.foxnews.com/entertainment/jane-seymour-72-shows-enviable-body-skintight-dress)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 08:23:06+00:00

Jane Seymour rocked a bodycon dress on the red carpet Tuesday night for the AMC Networks Upfront Event. Seymour stars in and executive produces &quot;Harry Wild.&quot;

## Black Republican launches campaign against 'Squad'-backed Summer Lee in Pennsylvania: 'We're falling apart'
 - [https://www.foxnews.com/politics/black-republican-launches-campaign-squad-backed-summer-lee-pennsylvania-falling-apart](https://www.foxnews.com/politics/black-republican-launches-campaign-squad-backed-summer-lee-pennsylvania-falling-apart)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 08:06:53+00:00

A Pennsylvania Republican is looking to clean up the streets of Pittsburgh and restore law and order by launching a campaign to represent one of the state&apos;s more progressive districts in the U.S. House.

## Physicists, victims contradict feds' report on 'Havana Syndrome' attacks on US diplomats
 - [https://www.foxnews.com/media/physicists-victims-contradict-feds-havana-syndrome-attacks-diplomats](https://www.foxnews.com/media/physicists-victims-contradict-feds-havana-syndrome-attacks-diplomats)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 08:00:55+00:00

Fox News chief political anchor and host of &apos;Special Report&apos; Bret Baier aired a report on the current state of the investigation into Havana Syndrome.

## EPA is out of control. Here’s our plan to stop its illegal actions
 - [https://www.foxnews.com/opinion/epa-out-control-heres-our-plan-stop-illegal-actions](https://www.foxnews.com/opinion/epa-out-control-heres-our-plan-stop-illegal-actions)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 08:00:42+00:00

EPA is out of control. Here’s our plan to stop its illegal actions. Biden wants to force drivers into electric vehicles despite pollution that would cause.

## Church leaders mostly silent after teen who opposed transgender ideology suspended from Catholic school
 - [https://www.foxnews.com/world/church-leaders-mostly-silent-after-teen-who-opposed-transgender-ideology-suspended-from-catholic-school](https://www.foxnews.com/world/church-leaders-mostly-silent-after-teen-who-opposed-transgender-ideology-suspended-from-catholic-school)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 08:00:11+00:00

Church leaders did not respond to request for comment regarding Josh Alexander, a junior who was suspended from St. Joseph&apos;s Catholic High School for opposing transgenderism.

## Victim of ex-UFC fighter Karl Roberson's alleged burglary was childhood friend, Army vet: 'I feel betrayed'
 - [https://www.foxnews.com/sports/victim-ex-ufc-fighter-karl-robersons-alleged-burglary-childhood-friend-army-vet-feel-betrayed](https://www.foxnews.com/sports/victim-ex-ufc-fighter-karl-robersons-alleged-burglary-childhood-friend-army-vet-feel-betrayed)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 07:55:39+00:00

The alleged victim of a home burglary that ex-UFC fighter Karl Roberson was arrested for in March told Fox News Digital exclusively how they were childhood friends that he trusted.

## Hawaii police promises to crack down on illegal cockfighting, gambling
 - [https://www.foxnews.com/us/hawaii-police-promises-crack-down-illegal-cockfighting-gambling](https://www.foxnews.com/us/hawaii-police-promises-crack-down-illegal-cockfighting-gambling)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 07:51:49+00:00

Authorities in Hawaii have promised to step up its illegal gambling enforcement and crack down on the island’s cockfighting, a popular practice that was brought from the Philippines.

## Detroit police lieutenant sentenced to 2 1/2 years for accepting bribes
 - [https://www.foxnews.com/us/detroit-police-lieutenant-sentenced-2-1/2-year-accepting-bribes](https://www.foxnews.com/us/detroit-police-lieutenant-sentenced-2-1/2-year-accepting-bribes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 07:50:09+00:00

John F. Kennedy, a former Detroit police lieutenant, was sentenced to two and a half years in prison for accepting bribes. Kennedy pleaded guilty under an agreement with prosecutors.

## Judge orders Detroit man, who previously was found incompetent, to stand trial on kidnapping charge
 - [https://www.foxnews.com/us/judge-orders-detroit-man-previously-found-incompetent-stand-trial-kidnapping-charge](https://www.foxnews.com/us/judge-orders-detroit-man-previously-found-incompetent-stand-trial-kidnapping-charge)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 07:47:55+00:00

Gerald Bennett has been ordered to stand trial on a kidnapping charge. Bennett was previously found incompetent but evidence revealed he was faking symptoms to avoid trial.

## Tesla Cybertruck gets competition from China's Cyberp!ckup
 - [https://www.foxnews.com/auto/tesla-cybertruck-competition-chinas-cyberpckup](https://www.foxnews.com/auto/tesla-cybertruck-competition-chinas-cyberpckup)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 07:46:15+00:00

The Great Wall Motor Cyberp!ckup unveiled at the Shanghai Auto Show is a 6x6 plug-in hybrid pickup that&apos;s set to go on sale in the region soon.

## Adam Lowry, Blake Wheeler lead Jets to Game 1 win over Golden Knights
 - [https://www.foxnews.com/sports/adam-lowry-blake-wheeler-lead-jets-game-1-win-golden-knights](https://www.foxnews.com/sports/adam-lowry-blake-wheeler-lead-jets-game-1-win-golden-knights)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 06:51:45+00:00

Adam Lowry scored two goals and Blake Wheeler had three points as the Winnipeg Jets defeated the Vegas Golden Knights 5-1 in Game 1.

## Mike Tyson says he 'could be persuaded' to return to ring
 - [https://www.foxnews.com/sports/mike-tyson-says-he-could-be-persuaded-return-ring](https://www.foxnews.com/sports/mike-tyson-says-he-could-be-persuaded-return-ring)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 06:50:19+00:00

Mike Tyson has not been in the boxing ring in almost two-and-a-half years. He probably is finished, but did not exactly rule out a return.

## Police identify gunman in Maine massacre, Musk warns of AI being 'trained to lie' and more top headlines
 - [https://www.foxnews.com/us/police-identify-gunman-maine-massacre-musk-warns-ai-trained-to-lie-more-top-headlines](https://www.foxnews.com/us/police-identify-gunman-maine-massacre-musk-warns-ai-trained-to-lie-more-top-headlines)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 06:49:54+00:00

Police identify gunman in Maine massacre, Musk warns of AI being &apos;trained to lie&apos; and more top headlines.

## Submarine wreckage discovered in Long Island Sound
 - [https://www.foxnews.com/us/submarine-wreckage-discovered-long-island-sound](https://www.foxnews.com/us/submarine-wreckage-discovered-long-island-sound)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 06:47:59+00:00

A team of divers discovered the wreckage of the Defender, a 92-foot-boat built in 1907. The divers&apos; leader had been interested in the Defender for years.

## Knicks fans skewer Cavs' Jarrett Allen for flagrant foul in blowout
 - [https://www.foxnews.com/sports/knicks-fans-skewer-cavs-jarrett-allen-flagrant-foul-blowout](https://www.foxnews.com/sports/knicks-fans-skewer-cavs-jarrett-allen-flagrant-foul-blowout)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 06:44:59+00:00

Cleveland Cavaliers center Jarrett Allen caught flak from New York Knicks after his hard foul on Julius Randle late in their blowout win in Game 2.

## Mexico soccer team could face strict punishment if fans use anti-gay chant: reports
 - [https://www.foxnews.com/sports/mexico-soccer-team-could-face-strict-punishment-fans-use-anti-gay-chant-reports](https://www.foxnews.com/sports/mexico-soccer-team-could-face-strict-punishment-fans-use-anti-gay-chant-reports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 06:40:25+00:00

The Mexico national soccer team could face heavy discipline if fans are heard using an anti-gay chant during matches against the United States.

## Antonio Brown reveals why friendship with Tom Brady went sour
 - [https://www.foxnews.com/sports/antonio-brown-reveals-why-friendship-tom-brady-went-sour](https://www.foxnews.com/sports/antonio-brown-reveals-why-friendship-tom-brady-went-sour)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 06:36:25+00:00

Antonio Brown says his friendship with his former quarterback Tom Brady took a huge decline after the seven-time Super Bowl champ &quot;cursed out&quot; his agent.

## Former Menudo member alleges he was drugged and raped by father of Menendez brothers at 14-years-old
 - [https://www.foxnews.com/entertainment/former-menudo-member-alleges-drugged-raped-father-menendez-brothers-14-years-old](https://www.foxnews.com/entertainment/former-menudo-member-alleges-drugged-raped-father-menendez-brothers-14-years-old)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 06:31:21+00:00

Ex-Menudo member Roy Rosselló has accused Jose Menendez of raping him when he was 14. Jose was the father of Erik and Lyle Menendez, who were convicted in 1996 of murdering him and their mother.

## Carol Locatell, 'Friday the 13th Part V: A New Beginning’ actress, dead at 82
 - [https://www.foxnews.com/entertainment/carol-locatell-friday-the-13th-part-v-a-new-beginning-actress-dead-82](https://www.foxnews.com/entertainment/carol-locatell-friday-the-13th-part-v-a-new-beginning-actress-dead-82)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 06:21:13+00:00

Carol Locatell, who acted alongside Burt Reynolds in three films and starred on Broadway several times, died last week at the age of 82 from cancer.

## Japan to evacuate citizens from Sudan as infighting escalates
 - [https://www.foxnews.com/world/japan-evacuate-citizens-sudan-infighting-escalates](https://www.foxnews.com/world/japan-evacuate-citizens-sudan-infighting-escalates)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 06:10:40+00:00

Japan&apos;s foreign ministry said the country has begun the process of evacuating its nationals from Sudan amid persistent violence that has left at least 270 dead.

## 'Explosion' at University of Pittsburgh transgender debate causes 'safety emergency' as protestors yell, chant
 - [https://www.foxnews.com/media/explosion-university-pittsburgh-transgender-debate-causes-safety-emergency-protestors-yell-chant](https://www.foxnews.com/media/explosion-university-pittsburgh-transgender-debate-causes-safety-emergency-protestors-yell-chant)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 06:08:00+00:00

Protests at the University of Pittsburgh broke out after students reportedly chanted, yelled and displayed LGBT signs to protest a debate on transgenderism.

## Kevin McCarthy to become second House Speaker to address Israel's Knesset
 - [https://www.foxnews.com/politics/kevin-mccarthy-become-second-house-speaker-address-israels-knesset](https://www.foxnews.com/politics/kevin-mccarthy-become-second-house-speaker-address-israels-knesset)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 06:01:51+00:00

Kevin McCarthy will become the second House speaker to give an address before Israel&apos;s Knesset since 1998, after he was invited to do so by Knesset Speaker Amir Ohana.

## Biden broke our welfare system. He needs to stop paying people for not working
 - [https://www.foxnews.com/opinion/biden-broke-our-welfare-system-he-needs-stop-paying-people-not-working](https://www.foxnews.com/opinion/biden-broke-our-welfare-system-he-needs-stop-paying-people-not-working)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 06:00:57+00:00

Biden broke our welfare system. He needs to stop paying people for not working. Getting Americans back into jobs is good for them and the US economy.

## Michael Landon's daughter is 'Yellowstone' star: What to know about Jennifer Landon
 - [https://www.foxnews.com/entertainment/michael-landons-daughter-yellowstone-star-what-know-jennifer-landon](https://www.foxnews.com/entertainment/michael-landons-daughter-yellowstone-star-what-know-jennifer-landon)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 06:00:45+00:00

Michael Landon&apos;s daughter, Jennifer, made her debut as Teeter on &quot;Yellowstone&quot; in season three and quickly became a fan favorite, but she made her acting debut alongside her father decades ago.

## Florida prep school principal allegedly sexually abused student who viewed her as 'mother figure': report
 - [https://www.foxnews.com/us/florida-prep-school-principal-allegedly-sexually-abused-student-who-viewed-her-as-mother-figure-report](https://www.foxnews.com/us/florida-prep-school-principal-allegedly-sexually-abused-student-who-viewed-her-as-mother-figure-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 06:00:40+00:00

Authorities accuse Tracy Smith, 43, of sexual misconduct with a student while she was the principal of a Coral Spring, Florida, prep school

## South Carolina teacher fired for giving students 'inappropriate' LGBTQ+ article during class
 - [https://www.foxnews.com/us/south-carolina-teacher-fired-giving-students-inappropriate-lgbtq-article-during-class](https://www.foxnews.com/us/south-carolina-teacher-fired-giving-students-inappropriate-lgbtq-article-during-class)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 05:44:10+00:00

A South Carolina teacher was fired after she handed out an unapproved article to her 10th-grade Language Arts students for a class discussion.

## Texas cheerleaders shot after one allegedly mistook suspect’s car for her own
 - [https://www.foxnews.com/us/texas-cheerleaders-shot-after-one-allegedly-mistook-suspects-car-for-her-own](https://www.foxnews.com/us/texas-cheerleaders-shot-after-one-allegedly-mistook-suspects-car-for-her-own)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 05:38:20+00:00

A high school cheerleader from Texas is in critical condition after police say she and another cheerleader were shot during an altercation with a man in a grocery store parking lot.

## Duke University professor calls for $14 trillion reparation program for Black Americans: $350k per person
 - [https://www.foxnews.com/media/duke-university-professor-proposes-14-trillion-reparations-program-black-americans-350k-person](https://www.foxnews.com/media/duke-university-professor-proposes-14-trillion-reparations-program-black-americans-350k-person)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 05:00:38+00:00

Guests on Dr. Phil&apos;s show debated over the morality and economic practicality of sending reparations to the Black descendants of the American slave trade.

## On-duty NYPD officer randomly hit in head with bottle by attacker with 11 prior arrests
 - [https://www.foxnews.com/us/on-duty-nypd-officer-randomly-hit-head-with-bottle-by-attacker-with-11-prior-arrests](https://www.foxnews.com/us/on-duty-nypd-officer-randomly-hit-head-with-bottle-by-attacker-with-11-prior-arrests)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 05:00:11+00:00

A New York police officer is in stable condition after police say she was struck on the back of the head with a bottle by a 45-year-old man who was arrested at the scene.

## Utah has best economic climate in country, New York worst: report
 - [https://www.foxnews.com/politics/utah-best-economic-climate-country-new-york-worst-report](https://www.foxnews.com/politics/utah-best-economic-climate-country-new-york-worst-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 05:00:09+00:00

Republican-led red states are overall in a much better economic situation than Democrat-led blue states, according to a new report that ranks the economic outlook of all 50 states.

## Michigan man reached 100 mph in road rage incident before crashing into motorcyclists
 - [https://www.foxnews.com/us/michigan-man-reached-100-mph-road-rage-incident-before-crashing-into-motorcyclists](https://www.foxnews.com/us/michigan-man-reached-100-mph-road-rage-incident-before-crashing-into-motorcyclists)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 04:28:23+00:00

A Michigan man collided with a motorcyclist he was allegedly chasing in a road rage incident where he was reportedly going 100 miles per hour.

## CBP seizes $21.1 million worth of fentanyl pills concealed within tractor-trailer carrying green beans
 - [https://www.foxnews.com/us/cbp-seizes-21-1-million-worth-fentanyl-pills-concealed-tractor-trailer-carrying-green-beans](https://www.foxnews.com/us/cbp-seizes-21-1-million-worth-fentanyl-pills-concealed-tractor-trailer-carrying-green-beans)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 04:01:57+00:00

The U.S. Customs and Border Protection said officers detained a tractor-trailer driver who attempted to smuggle more than 3.5 million fentanyl pills into California.

## Guardian Angels' Sliwa calls for moderates to unite with GOP after AOC dubs Astoria 'The People's Republic'
 - [https://www.foxnews.com/media/guardian-angels-sliwa-moderates-unite-with-gop-aoc-dubs-astoria-peoples-republic](https://www.foxnews.com/media/guardian-angels-sliwa-moderates-unite-with-gop-aoc-dubs-astoria-peoples-republic)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 04:00:36+00:00

Former Republican New York mayoral candidate Curtis Sliwa sounded off on the importance of recruiting moderate Democrats in areas taken over by socialist politicians.

## This is the huge threat to American survival that no one talks about
 - [https://www.foxnews.com/opinion/huge-threat-american-survival-no-one-talks-about](https://www.foxnews.com/opinion/huge-threat-american-survival-no-one-talks-about)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 04:00:26+00:00

This is the huge threat to American survival that no one talks about. US replaced achievement and success with decay and dishonesty as our systems crumble.

## Pat Boone's concern for America: ‘We’re going down the tubes morally'
 - [https://www.foxnews.com/entertainment/pat-boones-concern-america-going-down-the-tubes-morally](https://www.foxnews.com/entertainment/pat-boones-concern-america-going-down-the-tubes-morally)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 04:00:23+00:00

Pat Boone, who is celebrating his 70th year in show business, reflected on moral decay in America. He slammed Hollywood for glorifying immoral behavior.

## Gov. Kemp urges Republicans to support a candidate who can win in 2024, move past previous elections
 - [https://www.foxnews.com/politics/gov-kemp-urges-republicans-support-candidate-who-can-win-2024-move-past-previous-elections](https://www.foxnews.com/politics/gov-kemp-urges-republicans-support-candidate-who-can-win-2024-move-past-previous-elections)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 03:44:36+00:00

Georgia Gov. Kemp said it is important Republicans nominate a candidate who can win the presidential election in 2024. He recently ruled out running for president.

## Two-time 'Survivor' contestant Keith Nale dies at 62
 - [https://www.foxnews.com/entertainment/two-time-survivor-contestant-keith-nale-dies-62](https://www.foxnews.com/entertainment/two-time-survivor-contestant-keith-nale-dies-62)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 03:02:06+00:00

Fan-favorite &apos;Survivor&apos; contestant Keith Nale, who starred in the San Juan del Sur and Cambodia spin-offs, has died at 62 following a battle with cancer.

## Florida swim instructor's viral TikTok warns parents to avoid buying blue bathing suits for kids: Here's why
 - [https://www.foxnews.com/lifestyle/florida-swim-instructors-viral-tiktok-warns-parents-avoid-buying-blue-bathing-suits-kids-why](https://www.foxnews.com/lifestyle/florida-swim-instructors-viral-tiktok-warns-parents-avoid-buying-blue-bathing-suits-kids-why)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 03:00:19+00:00

A mother and swim instructor from Spring Hill, Florida, has gone viral on TikTok with her water safety advice to never buy blue-colored bathing suits for kids.

## Illinois assault weapons ban still in effect after appeals court denies injunction
 - [https://www.foxnews.com/politics/illinois-assault-weapons-ban-effect-appeals-court-denies-injunction](https://www.foxnews.com/politics/illinois-assault-weapons-ban-effect-appeals-court-denies-injunction)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 02:33:38+00:00

The 7th U.S. Circuit Court of Appeals ruled against an injunction that would have blocked Illinois&apos; statewide &apos;assault weapons&apos; ban that was signed into law by Gov. J.B. Pritzker.

## AI can 'kill us,' but some in Congress dont even know how to log in to Facebook, lawmakers say
 - [https://www.foxnews.com/politics/ai-kill-us-some-congress-dont-even-know-log-facebook-lawmakers-say](https://www.foxnews.com/politics/ai-kill-us-some-congress-dont-even-know-log-facebook-lawmakers-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 02:00:47+00:00

AI developments from generating videos, voices, pictures and human-like conversations are growing rapidly, lawmakers say they are trying to keep up.

## GOP open to talking about AI regulations after Schumer pushes for guardrails
 - [https://www.foxnews.com/politics/gop-open-talking-regulations-schumer-pushes-guardrails](https://www.foxnews.com/politics/gop-open-talking-regulations-schumer-pushes-guardrails)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 02:00:38+00:00

Republican senators told Fox News Digital that they are interested in the idea of regulating AI, though some warned about moving too quickly.

## North Carolina family of California college student who went missing in 2020 'baffled' by disappearance
 - [https://www.foxnews.com/us/north-carolina-family-california-college-student-who-went-missing-2020-baffled-disappearance](https://www.foxnews.com/us/north-carolina-family-california-college-student-who-went-missing-2020-baffled-disappearance)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 02:00:36+00:00

Missing UC Berkeley student Sydney West, 19, was last seen on the Golden Gate Bridge in San Francisco on Sept. 30, 2020. Her family is baffled but hopeful for answers.

## AI chatbot 'hallucinations' perpetuate political falsehoods, biases that have rewritten American history
 - [https://www.foxnews.com/lifestyle/ai-chatbot-hallucinations-perpetuate-political-falsehoods-biases-rewritten-american-history](https://www.foxnews.com/lifestyle/ai-chatbot-hallucinations-perpetuate-political-falsehoods-biases-rewritten-american-history)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 02:00:19+00:00

Artificial intelligence platforms such as ChatGPT from OpenAI often provide inaccurate information that reflect dominant leftist political biases and narratives.

## AI health care platform predicts diabetes with high accuracy but 'won't replace patient care'
 - [https://www.foxnews.com/health/ai-health-care-platform-predicts-diabetes-with-high-accuracy-wont-replace-patient-care](https://www.foxnews.com/health/ai-health-care-platform-predicts-diabetes-with-high-accuracy-wont-replace-patient-care)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 02:00:10+00:00

Cedar Gate Technologies announced an artificial intelligence-based solution for health care providers said to predict diabetes risk with 80% accuracy. Fox News Digital spoke to company executives.

## AI vs. cancer: Mount Sinai scientist says breakthrough tech has ‘drastic impact’ on diagnosis, treatment
 - [https://www.foxnews.com/media/ai-vs-cancer-mount-sinai-scientist-breakthrough-tech-drastic-impact-diagnosis-treatment](https://www.foxnews.com/media/ai-vs-cancer-mount-sinai-scientist-breakthrough-tech-drastic-impact-diagnosis-treatment)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 02:00:09+00:00

A Mount Sinai computational pathologist detailed a new artificial intelligence and how the tech is helping to improve the speed and accuracy of cancer diagnosis.

## Yes, AI is a cybersecurity 'nuclear' threat. That's why companies have to dare to do this
 - [https://www.foxnews.com/opinion/ai-cybersecurity-nuclear-threat-companies-dare](https://www.foxnews.com/opinion/ai-cybersecurity-nuclear-threat-companies-dare)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 02:00:06+00:00

Using AI in organizations brings potential benefits that far outweigh the risks of not using this technology. Companies can&apos;t postpone authorization out of fear of hackers.

## UK proposes ban on large and serrated knives, seizure if police suspect they will be in crime
 - [https://www.foxnews.com/world/uk-proposes-ban-large-serrated-knives-seizure-police-suspect-crime](https://www.foxnews.com/world/uk-proposes-ban-large-serrated-knives-seizure-police-suspect-crime)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 01:42:38+00:00

Machetes and zombie knives could be banned in England and Wales, with people selling them facing up to two years in jail, under a proposed law in the UK.

## Three Maryland elementary school students hospitalized after mistaking controlled substance for candy
 - [https://www.foxnews.com/us/three-maryland-elementary-school-students-hospitalized-mistaking-controlled-substance-candy](https://www.foxnews.com/us/three-maryland-elementary-school-students-hospitalized-mistaking-controlled-substance-candy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 01:13:38+00:00

Three elementary school students in Rockville, Maryland, were hospitalized after they ingested a controlled substance they believed to be candy.

## Suns come back from 13-point deficit to knot series against Clippers at one apiece
 - [https://www.foxnews.com/sports/suns-come-back-13-point-deficit-knot-series-clippers-one-apiece](https://www.foxnews.com/sports/suns-come-back-13-point-deficit-knot-series-clippers-one-apiece)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 01:02:18+00:00

The Phoenix Suns were about 30 minutes of game play away from being in serious trouble, but Devin Booker&apos;s 38 points propelled a comeback to tie their series.

## GREG GUTFELD: More Americans are feeling disillusioned with our political system
 - [https://www.foxnews.com/opinion/greg-gutfeld-more-americans-feeling-disillusioned-our-political-system](https://www.foxnews.com/opinion/greg-gutfeld-more-americans-feeling-disillusioned-our-political-system)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 00:59:08+00:00

&apos;Gutfeld!&apos; panelists discuss why almost half of Americans identify as politically independent and why they are growing frustrated with political leaders.

## Paramedic reveals horror of Jeremy Renner snowplow accident in bodycam video: 'Never seen anything like this'
 - [https://www.foxnews.com/entertainment/paramedic-reveals-horror-jeremy-renner-snowplow-accident-bodycam-video](https://www.foxnews.com/entertainment/paramedic-reveals-horror-jeremy-renner-snowplow-accident-bodycam-video)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 00:40:19+00:00

Jeremy Renner&apos;s harrowing rescue on a snowy mountain road was seen in body camera footage from sheriffs. The actor suffered 30 broken bones from snowplow incident.

## Rare desert waterfalls still flowing a month after record snowfall awakened them
 - [https://www.foxnews.com/us/rare-desert-waterfalls-still-flowing-month-after-record-snowfall](https://www.foxnews.com/us/rare-desert-waterfalls-still-flowing-month-after-record-snowfall)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 00:29:48+00:00

Rare waterfalls have emerged after record rainfall and snowfall in the southwest, attracting a larger than usual crowd to Gunlock State Park in Gunlock, Utah.

## Lightning dominate Maple Leafs in Toronto to take Game 1
 - [https://www.foxnews.com/sports/lightning-dominate-maple-leafs-toronto-take-game-1](https://www.foxnews.com/sports/lightning-dominate-maple-leafs-toronto-take-game-1)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 00:29:11+00:00

The Toronto Maple Leafs are looking to get past the first round of the playoffs for the first time in 19 years, but Tuesday&apos;s blowout wasn&apos;t a good start.

## Rep. Lee endorses DeSantis, bringing Capitol Hill supporters to 3 while Trump has backing of over 50 lawmakers
 - [https://www.foxnews.com/politics/rep-lee-endorses-desantis-bringing-capitol-hill-supporters-3-trump-backing-50-lawmakers](https://www.foxnews.com/politics/rep-lee-endorses-desantis-bringing-capitol-hill-supporters-3-trump-backing-50-lawmakers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 00:27:16+00:00

Florida Governor Ron DeSantis has picked up his third endorsement from Capitol Hill, as Rep. Laurel Lee of Florida has thrown her support behind him.

## Warriors' Draymond Green suspended for Game 3 after stepping on Kings' Domantas Sabonis' chest
 - [https://www.foxnews.com/sports/warriors-draymond-green-suspended-game-3-after-stepping-kings-domantas-sabonis-chest](https://www.foxnews.com/sports/warriors-draymond-green-suspended-game-3-after-stepping-kings-domantas-sabonis-chest)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 00:15:52+00:00

The NBA has suspended Golden State Warriors&apos; Draymond Green for Game 3 of their series against the Sacramento Kings - the defending champs trail two games to nothing.

## SEAN HANNITY: Your tax dollars are hard at work in this Biden administration dumpster fire
 - [https://www.foxnews.com/media/sean-hannity-your-tax-dollars-are-hard-at-work-amid-the-biden-administrations-dumpster-fire](https://www.foxnews.com/media/sean-hannity-your-tax-dollars-are-hard-at-work-amid-the-biden-administrations-dumpster-fire)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 00:06:28+00:00

Fox News host Sean Hannity reacts to the hearings on Capitol Hill today as Biden administration officials were questioned on multiple crises in Tuesday&apos;s opening monologue.

## On this day in history, April 19, 1951, Gen. MacArthur delivers 'Old soldiers never die' speech to Congress
 - [https://www.foxnews.com/lifestyle/this-day-history-april-19-1951-gen-macarthur-delivers-old-soldiers-never-die-speech-congress](https://www.foxnews.com/lifestyle/this-day-history-april-19-1951-gen-macarthur-delivers-old-soldiers-never-die-speech-congress)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 00:02:18+00:00

Gen. Douglas MacArthur delivered his &quot;Old soldiers never die&quot; speech to a joint session of Congress on this day in history, April 19, 1951. Earlier, MacArthur was relieved of his military duties.

## Illinois man hit, killed by van while trying to help goose out of traffic
 - [https://www.foxnews.com/us/illinois-man-hit-killed-van-while-trying-help-goose-out-traffic](https://www.foxnews.com/us/illinois-man-hit-killed-van-while-trying-help-goose-out-traffic)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-19 00:02:10+00:00

An Illinois man was hit and killed after attempting to assist a goose out of busy rush hour traffic early Tuesday morning.

