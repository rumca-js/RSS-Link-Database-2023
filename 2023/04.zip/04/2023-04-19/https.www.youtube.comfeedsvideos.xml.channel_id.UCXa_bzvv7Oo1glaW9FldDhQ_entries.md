# Source:GamingBolt, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXa_bzvv7Oo1glaW9FldDhQ, language:en-US

## 15 Most Mind-Bending Video Games That Will Mess With Your Head
 - [https://www.youtube.com/watch?v=msnRFCiopNk](https://www.youtube.com/watch?v=msnRFCiopNk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXa_bzvv7Oo1glaW9FldDhQ
 - date published: 2023-04-19 15:30:18+00:00

More than any other form of media, video games possess a profound power to mess with your head. 

Whether it’s rewiring your brain to solve puzzles, to forcibly shift imaginations to fresh perspectives, or stuff eyes with kaleidoscopic colour and flow, the games on this rundown demonstrate mind altering power unmatched by any other form of media.

## Suicide Squad: Kill The Justice League's Delay And The Live Service Fad
 - [https://www.youtube.com/watch?v=HOfoKOgCeXU](https://www.youtube.com/watch?v=HOfoKOgCeXU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXa_bzvv7Oo1glaW9FldDhQ
 - date published: 2023-04-19 13:30:07+00:00

Suicide Squad: Kill The Justice League got delayed into next year. Why? Its live service elements were not received well by the community.

The lesson: Publishers need to stop chasing after the live service trend.

But will they learn anything from this lesson?

