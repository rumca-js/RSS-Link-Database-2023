# Source:wiadomości.gazeta.pl, URL:http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm, language:pl-PL

## Minister zdrowia zapowiada zniesienie stanu zagrożenia epidemicznego. Niedzielski podał datę
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29680191,minister-zdrowia-zapowiada-zniesienie-stanu-zagrozenia-epidemicznego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29680191,minister-zdrowia-zapowiada-zniesienie-stanu-zagrozenia-epidemicznego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-19 20:16:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f7/4a/1c/z29664503M,Porazka-PiS-u-w-Sejmie-przez-dwie-poslanki-partii-.jpg" vspace="2" />Pod koniec czerwca w Polsce ma zostać zniesiony stan zagrożenia epidemicznego. Oznacza to także zniesienie kolejnych obostrzeń, które nadal obowiązują w Polsce - wynika z zapowiedzi ministra zdrowia Adama Niedzielskiego.

## Wielkopolska. Wybuch gazu w powiecie pilskim. Zawalił się budynek mieszkalny. Są ranni
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29680246,wielkopolska-wybuch-gazu-w-powiecie-pilskim-zawalil-sie-blok.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29680246,wielkopolska-wybuch-gazu-w-powiecie-pilskim-zawalil-sie-blok.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-19 19:12:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f8/4e/1c/z29680376M,Wielkopolska--Wybuch-gazu-w-powiecie-pilskim--Zawa.jpg" vspace="2" />W miejscowości Sędziniec w powiecie pilskim w Wielkopolsce doszło do wybuchu gazu w budynku mieszkalnym. Część budynku się zawaliła. Do zdarzenia doszło w środę po godzinie 20:00. Strażacy wyciągnęli spod gruzów wszystkie uwięzione osoby. Na miejsce wezwano około 20 zastępów straży pożarnej.

## 7-letnia dziewczynka wypadła z krzesełka wyciągu narciarskiego. Zakopiańska policja prosi o pomoc
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29680124,7-letnia-dziewczynka-wypadla-z-krzeselka-wyciagu-narciarskiego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29680124,7-letnia-dziewczynka-wypadla-z-krzeselka-wyciagu-narciarskiego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-19 18:36:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/06/4e/1c/z29680134M,Swiadkowie-wypadku-poszukiwani-przez-policje.jpg" vspace="2" />Zakopiańska policja wciąż wyjaśnia okoliczności wypadku, do którego doszło w połowie stycznia na stacji narciarskiej w Bukowinie Tatrzańskiej. 7-latka wypadła z krzesełka wyciągu. Funkcjonariusze wydali nowy komunikat w tej sprawie.

## Wypadek w markecie budowlanym w Sierpcu. Winda towarowa przygniotła dwie osoby
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29679895,wypadek-w-markecie-budowlanym-w-sierpcu-winda-towarowa-przygniotla.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29679895,wypadek-w-markecie-budowlanym-w-sierpcu-winda-towarowa-przygniotla.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-19 16:26:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/58/82/1b/z28845912M,Pilne.jpg" vspace="2" />Jedna osoba zginęła w wyniku wypadku, do którego doszło w środę po południu w markecie budowlanym w Sierpcu - podało RMF FM. Dwie osoby zostały przygniecione przez windę towarową.

## Radni PiS z Wadowic chcą pozwać autorów reportażu TVN "Franciszkańska 3". Przyjęli uchwałę
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29679606,radni-pis-z-wadowic-chca-pozwac-autorow-reportazu-tvn-franciszkanska.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29679606,radni-pis-z-wadowic-chca-pozwac-autorow-reportazu-tvn-franciszkanska.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-19 16:19:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/bc/40/1c/z29625276M.jpg" vspace="2" />Uchwała "o zachowaniu dobrej pamięci o wadowiczaninie św. Janie Pawle II" przyjęta przez radnych Wadowic. Dokument przygotowali samorządowcy Prawa i Sprawiedliwości. Główny punkt: zobowiązanie burmistrza miasta do pozwania autorów materiału "Franciszkańska 3". Były włodarz miasta jednoznacznie skrytykował ustawę: Pod hasłem obrony Jana Pawła II zamieniacie Wadowice w Białoruś - mówił radny Mateusz Klinowskia.

## 37-latek gromadził w garażu materiały wybuchowe. Śledczy zbadają, dlaczego
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29679523,37-latek-gromadzil-w-garazu-materialy-wybuchowe-sledczy-zbadaja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29679523,37-latek-gromadzil-w-garazu-materialy-wybuchowe-sledczy-zbadaja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-19 15:13:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e4/4d/1c/z29679588M,Zdjecie-ilustracyjne.jpg" vspace="2" />37-letni mieszkaniec Koszalina przechowywał w wynajmowanym garażu materiały wybuchowe - potwierdziła tamtejsza policja. Mężczyzna został zatrzymany. Na razie nie wiadomo, czym się kierował i jakie miał zamiary.

## Wywiercili dziurę w skarbcu i ukradli ponad 6,4 mln euro. Złodzieje z Dolnego Śląska staną przed sądem
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29679343,wywiercili-dziure-w-skarbcu-i-ukradli-ponad-6-4-mln-euro-zlodzieje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29679343,wywiercili-dziure-w-skarbcu-i-ukradli-ponad-6-4-mln-euro-zlodzieje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-19 14:47:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/5f/4d/1c/z29679455M,Zdjecie-ilustracyjne.jpg" vspace="2" />Do sądu trafił akt oskarżenia przeciwko siedmiu osobom, które brały udział w zuchwałej kradzieży ponad 6,4 miliona euro z Głównego Urzędu Celnego w Duisburgu. Do zdarzenia doszło przed trzema laty. Złodzieje pochodzący z Dolnego Śląska wykorzystali specjalistyczny sprzęt, który umożliwił im dostanie się do wnętrza skarbca.

## Do prokuratury wpłynęło zawiadomienie na Daniela Obajtka. Autorem jest wydawca tygodnika "NIE"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29679124,do-prokuratury-wplynelo-zawiadomienie-na-daniela-obajtka-autorem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29679124,do-prokuratury-wplynelo-zawiadomienie-na-daniela-obajtka-autorem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-19 13:59:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/28/4d/1c/z29679144M,Daniel-Obajtek.jpg" vspace="2" />- Złożyliśmy zawiadomienia do prokuratury o uzasadnionym podejrzeniu popełnienia przestępstw tłumienia krytyki prasowej oraz ograniczeniu kolportażu prasy przez władze Orlenu i Poczty Polskiej - powiedziała w rozmowie z Wirtualnymi Mediami Marta Miecińska, prezeska spółki Urma, która jest wydawcą tygodnika "NIE".

## Uczniowie obrażali nauczycielkę i wszystko transmitowali na TikToku. Sąd w Malborku ukarał nastolatków
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29678669,uczniowie-obrazali-nauczycielke-i-wszystko-transmitowali-na.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29678669,uczniowie-obrazali-nauczycielke-i-wszystko-transmitowali-na.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-19 13:27:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/77/48/1c/z29656183M,Szkola--zdjecie-ilustracyjne-.jpg" vspace="2" />Malborski sąd ukarał pięciu nastolatków, którzy przed kilkoma tygodniami obrażali nauczycielkę podczas lekcji w szkole w Lisewie Malborskim i transmitowali to w sieci. Uczniowie ponieśli też konsekwencje przewidziane w statucie placówki.

## Nowe informacje na temat stanu zdrowia 8-letniego Kamila z Częstochowy. "Nie ma mowy o wybudzaniu ze śpiączki"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29678143,nowe-informacje-na-temat-stanu-zdrowia-8-letniego-kamila-z-czestochowy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29678143,nowe-informacje-na-temat-stanu-zdrowia-8-letniego-kamila-z-czestochowy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-19 12:54:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/1f/4c/1c/z29672735M,8-letni-Kamil-w-ciezkim-stanie-trafil-do-szpitala-.jpg" vspace="2" />Na początku kwietnia informowaliśmy o skatowanym 8-latku z Częstochowy. Nad chłopcem znęcał się ojczym. Przypalał dziecko papierosami, polewał wrzątkiem i rzucał na rozgrzany piec. Chłopiec od 16 dni przebywa w Górnośląskim Centrum Zdrowia Dziecka. Szpital podał informacje na temat aktualnego stanu zdrowia chłopca.

## Strażnicy miejscy i 500 zł brutto "nagrody pocieszenia". Radny PiS: premie ich szefów to 15 tys. zł
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29677951,straznicy-miejscy-i-500-zl-brutto-nagrody-pocieszenia-radny.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29677951,straznicy-miejscy-i-500-zl-brutto-nagrody-pocieszenia-radny.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-19 12:47:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/bc/4d/1c/z29678012M,Straz-miejska---zdjecie-ilustracyjne.jpg" vspace="2" />Strażnicy miejscy, pracujący na terenie Gdańska, otrzymują dużo niższe premie, niż ich przełożeni - uważa Przemysław Majewski. Radny PiS wystosował w tej sprawie interpelację do prezydent miasta. Przedstawiciel Straży Miejskiej w tym mieście podkreśla natomiast, że premie mają "charakter uznaniowy" i "trudno mówić o dyskryminacji, czy niesprawiedliwych dysproporcjach w kwotach przyznawanych nagród".

## Jak terrorystka to w hidżabie? I co tam robią mnisi? Dziwne obrazki z ćwiczeń antyterrorystów. Jest tłumaczenie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29678250,kuriozalne-sceny-podczas-cwiczen-poznanskiej-policji-sluzby.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29678250,kuriozalne-sceny-podczas-cwiczen-poznanskiej-policji-sluzby.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-19 12:17:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/b4/4d/1c/z29678260M,Cwiczenia-Wolf-Ram-23.jpg" vspace="2" />Zdjęcia z ćwiczeń Wolf-Ram-23 udostępnione przez poznańską policję wywołały burzę w sieci. Na fotografiach znajduje się m.in. kobieta w hidżabie, ale także zakonnicy czy osoby z niepełnosprawnością. Internauci zarzucają policji pogłębianie stereotypów. Policja odbija piłeczkę, twierdząc, że odpowiedzialni za te wybory są przedstawiciele FBI.

## Prezydent Niemiec na obchodach rocznicy powstania w getcie: Proszę o przebaczenie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29678358,prezydent-niemiec-na-obchodach-rocznicy-powstania-w-getcie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29678358,prezydent-niemiec-na-obchodach-rocznicy-powstania-w-getcie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-19 11:34:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/2a/4d/1c/z29678378M,Uroczystosci-80--rocznicy-wybuchu-powstania-w-Getc.jpg" vspace="2" />- Straszliwe zbrodnie, które Niemcy tutaj popełnili, napawają mnie głębokim wstydem - podkreślił niemiecki prezydent Frank-Walter Steinmeier podczas uroczystości związanych z 80. rocznicą powstania w getcie warszawskim. - Proszę o przebaczenie - powiedział.

## Andrzej Bryjok nie żyje. Lekarz wyszedł do kościoła i już nie wrócił. Jego ciało znaleziono w potoku
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29677499,andrzej-bryjok-nie-zyje-lekarz-wyszedl-do-kosciola-i-juz-nie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29677499,andrzej-bryjok-nie-zyje-lekarz-wyszedl-do-kosciola-i-juz-nie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-19 11:03:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/05/4d/1c/z29678085M,Nie-zyje-Andrzej-Bryjok.jpg" vspace="2" />W wieku 59 lat zmarł Andrzej Bryjok, ceniony lekarz i były radny powiatu bieruńsko-lędzińskiego. Zwłoki mężczyzny znaleziono w potoku Goławieckim w Lędzinach. Dotychczas nie ustalono okoliczności jego śmierci.

## 80. rocznica powstania w getcie warszawskim. W Warszawie zabiły dzwony i zawyły syreny
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29677633,80-rocznica-powstania-w-getcie-warszawskim-w-warszawie-zabily.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29677633,80-rocznica-powstania-w-getcie-warszawskim-w-warszawie-zabily.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-19 10:20:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/99/4d/1c/z29677977M,Oficjalne-obchody-80--rocznicy-Powstania-w-getcie-.jpg" vspace="2" />W południe rozpoczęły się obchody 80. rocznicy powstania w getcie warszawskim. Uroczystość rozpoczęto od uruchomienia syren i dzwonów kościelnych. Główne uroczystości odbywają się na placu Bohaterów Getta Warszawskiego - tam też pojawią się prezydenci Polski, Izraela i Niemiec.

## Jedyny taki na świecie. Zrekonstruowano wagon, który jeździł w getcie w czasie II wojny światowej
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29677179,jedyny-taki-na-swiecie-zrekonstruowano-wagon-ktory-jezdzil.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29677179,jedyny-taki-na-swiecie-zrekonstruowano-wagon-ktory-jezdzil.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-19 10:07:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/12/4b/1c/z29669138M,Rocznica-powstania-w-getcie-warszawskim--Prezentac.jpg" vspace="2" />Tramwaje Warszawskie zrekonstruowały wagon, który jeździł w getcie. Jest on niezwykle cenny, ponieważ to jedyny taki zabytek na świecie. Pojazd pochodzi z 1907 roku i ma trafić na wystawę do Muzeum Getta Warszawskiego.

## Zaprojektowała kwiaty do Akcji Żonkile. Czernek: To symbol rozkwitania pamięci o powstaniu w getcie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29676696,zaprojektowala-kwiaty-do-akcji-zonkile-czernek-to-symbol-rozkwitania.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29676696,zaprojektowala-kwiaty-do-akcji-zonkile-czernek-to-symbol-rozkwitania.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-19 09:54:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f2/4d/1c/z29677554M,Helena-Czernek.jpg" vspace="2" />Akcja Żonkile upamiętniająca rocznicę powstania w getcie warszawskim w tym roku odbywa się po raz jedenasty. - Nie podejrzewałam, że akcja aż tak się rozrośnie. Jestem pod wrażeniem, jak taki symbol i działania towarzyszące akcji mogą wpłynąć na społeczeństwo - powiedziała w rozmowie z Gazeta.pl Helena Czernek, pomysłodawczyni całej koncepcji. Zapytaliśmy także, co kierowało nią przy tworzeniu projektu.

## Syreny zawyją w południe. 19 kwietnia przypada 80. rocznica powstania w getcie warszawskim
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29674031,syreny-zawyja-w-poludnie-19-kwietnia-przypada-80-rocznica.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29674031,syreny-zawyja-w-poludnie-19-kwietnia-przypada-80-rocznica.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-19 09:50:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/45/d2/1b/z29173317M,Syrena-alarmowa--zdjecie-ilustracyjne-.jpg" vspace="2" />19 kwietnia 2023 roku rozpoczęły się obchody w ramach 80. rocznica wybuchu powstania w getcie warszawskim. O godz. 12 w stolicy zawyją syreny alarmowe. Na ulicach sześciu polskich miast wolonatriusze akcji "Żonkil" rozdadzą przechodniom papierowe kwiaty. Z kolei Muzeum POLIN przygotowało wystawę "Wokół nas morze ognia". - Zależało nam, by przez wystawę przywrócić pamięć o losach blisko 50 tysięcy ludzi - powiedziała jej kuratorka Zuzanna Schnepf-Kołacz.

## Po dzielnicy żydowskiej zostały tony gruzu i podziemne miasto. Na powierzchni nie ma po niej śladu
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29676257,po-dzielnicy-zydowskiej-zostaly-tony-gruzu-i-podziemne-miasto.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29676257,po-dzielnicy-zydowskiej-zostaly-tony-gruzu-i-podziemne-miasto.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-19 09:46:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/32/4d/1c/z29676338M,Dzielnica-zydowska-w-Warszawie--Nalewki.jpg" vspace="2" />Dzielnica północna, a zwłaszcza jej główna ulica - Nalewki - była przed wojną głośna i tłoczna, z tłumem, jakiego "nie znajdziesz nigdzie indziej w Warszawie". Pozostał po niej bezkres gruzów, kilka ostańców i podziemne miasto z tuneli i piwnic.

## 80. rocznica powstania w getcie warszawskim. "To było kilka pistoletów maszynowych"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29677324,80-rocznica-powstania-w-getcie-warszawskim-to-bylo-kilka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29677324,80-rocznica-powstania-w-getcie-warszawskim-to-bylo-kilka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-19 09:41:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/b9/4c/1c/z29674937M.jpg" vspace="2" />Dokładnie 80 lat temu polscy Żydzi w Warszawie podjęli walkę zbrojną z Niemcami. Powstanie w getcie warszawskim było pierwszym powstaniem miejskim w okupowanej przez hitlerowców Europie.

## Radom. Pijana pani prokurator wjechała autem do rowu? Prokuratura wszczęła śledztwo
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29676698,radom-pijana-pani-prokurator-wjechala-autem-do-rowu-prokuratura.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29676698,radom-pijana-pani-prokurator-wjechala-autem-do-rowu-prokuratura.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-19 08:04:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/2b/47/1c/z29650987M.jpg" vspace="2" />W nocy z soboty na niedzielę policja zatrzymała pijaną kobietę, po tym jak wjechała ona autem do rowu. Według dziennikarza TVP była to prokurator z Radomia. Prokuratura wszczęła śledztwo w jej sprawie.

## 80. rocznica wybuchu powstania w getcie warszawskim. W stolicy zawyją syreny alarmowe
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29676475,80-rocznica-wybuchu-powstania-w-getcie-warszawskim-w-warszawie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29676475,80-rocznica-wybuchu-powstania-w-getcie-warszawskim-w-warszawie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-19 07:01:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/2a/4c/1c/z29674538M,Akcja-Zonkile---zdjecie-ilustracyjne.jpg" vspace="2" />Warszawa odda dzisiaj hołd Żydom, którzy zginęli w powstaniu w Getcie Warszawskim. Mija właśnie 80 lat od największego żydowskiego zrywu przeciwko niemieckiemu okupantowi w czasie II wojny światowej. Centralne uroczystości zaplanowane są na placu Bohaterów Getta w stolicy. Wezmą w niej udział prezydenci Polski, Izraela i Niemiec.

## Ciało mężczyzny w lesie przy granicy z Białorusią. Ochojska oskarża PiS. "Ofiara polityki"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29676487,cialo-mezczyzny-w-lesie-przy-granicy-z-bialorusia-ochojska.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29676487,cialo-mezczyzny-w-lesie-przy-granicy-z-bialorusia-ochojska.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-19 06:38:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/0c/39/1a/z27497228M.jpg" vspace="2" />W lesie przy granicy polsko-białoruskiej znaleziono zwłoki mężczyzny. To ciało 41. osoby znalezione przez Podlaskie Ochotnicze Pogotowie Humanitarne. Janina Ochojska oskarżyła o to władze. "Kolejna ofiara polityki migracyjnej PiS i jej wykonawców: Mariusza Kamińskiego i Macieja Wąsika" - napisała i dodała, że "ochrona granicy nie stoi w sprzeczności z humanitaryzmem".

## Alert RCB dla ośmiu województw. "Działania antyterrorystyczne i pościgowe, możliwe utrudnienia w ruchu"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29676417,na-terenie-polski-odbywaja-sie-cwiczenia-sluzb-wyjasniamy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29676417,na-terenie-polski-odbywaja-sie-cwiczenia-sluzb-wyjasniamy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-19 06:25:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/b0/4d/1c/z29676464M,Alert-RCB.jpg" vspace="2" />Ponad 2600 osób, w tym policjanci, strażacy, ratownicy medyczni oraz funkcjonariusze ABW i FBI uczestniczą w ćwiczeniach antyterrorystycznych na terenie Polski. "Wolf-Ram-23" bo tak właśnie nazywają się trwające od poniedziałku ćwiczenia służb, jak podkreśla MSWiA, są historyczne, ponieważ policja nigdy nie prowadziła ich na tak dużą skalę.

## Abp Jędraszewski odprawił mszę za ofiary katastrofy smoleńskiej. Mówił o "pomordowanych"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29676391,abp-jedraszewski-odprawil-msze-za-ofiary-katastrofy-smolenskiej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29676391,abp-jedraszewski-odprawil-msze-za-ofiary-katastrofy-smolenskiej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-19 05:48:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/92/4d/1c/z29676434M,Abp-Marek-Jedraszewski.jpg" vspace="2" />- Dziś wiemy, że musimy pomodlić się także nad grobami pomordowanych 13 lat temu pod Smoleńskiem - mówił abp Marek Jędraszewski podczas mszy w intencji ofiar katastrofy smoleńskiej. - Tak jak polskiemu społeczeństwu potrzebna była prawda o Katyniu, tak teraz Polsce i światu potrzebna jest pełna prawda o Smoleńsku - stwierdził hierarcha.

## Gdzie będą rozdawane papierowe żonkile? Akcja Żonkile 2023 nie tylko w Warszawie [LISTA]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29673833,gdzie-beda-rozdawane-papierowe-zonkile-akcja-zonkile-2023-nie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29673833,gdzie-beda-rozdawane-papierowe-zonkile-akcja-zonkile-2023-nie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-19 05:45:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/2a/4c/1c/z29674538M,Akcja-Zonkile---zdjecie-ilustracyjne.jpg" vspace="2" />W środę w Warszawie i w kilku miastach w Polsce rozpoczną się uroczystości w ramach 80. rocznicy wybuchu powstania w getcie warszawskim. Tego dnia na ulice miast wyruszą wolontariusze, którzy w ramach Akcji Żonkil będą rozdawali papierowe, żółte kwiaty. Gdzie w Warszawie, Łodzi czy Krakowie będzie można otrzymać tę przypinkę?

