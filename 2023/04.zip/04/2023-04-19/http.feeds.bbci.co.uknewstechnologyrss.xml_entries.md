# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Facebook owner Meta sees latest layoffs begin
 - [https://www.bbc.co.uk/news/business-65330301?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-65330301?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-04-19 19:40:09+00:00

The social media giant is under pressure after a sharp slowdown in its ads business last year.

## Criminal Records Service still disrupted 4 weeks after hack
 - [https://www.bbc.co.uk/news/technology-65324125?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-65324125?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-04-19 12:43:37+00:00

People wishing to work with children or gain emigration visas are still facing long delays.

