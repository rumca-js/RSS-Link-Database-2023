# Source:The Intercept, URL:https://theintercept.com/feed/?lang=en, language:en-US

## Supreme Court Allows Rodney Reed to Keep Up His Fight for DNA Testing
 - [https://theintercept.com/2023/04/19/supreme-court-dna-testing-rodney-reed/](https://theintercept.com/2023/04/19/supreme-court-dna-testing-rodney-reed/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2023-04-19 23:20:23+00:00

<p>Texas has gone to great lengths to prevent DNA testing of crime scene evidence that Reed says could exonerate him.</p>
<p>The post <a href="https://theintercept.com/2023/04/19/supreme-court-dna-testing-rodney-reed/" rel="nofollow">Supreme Court Allows Rodney Reed to Keep Up His Fight for DNA Testing</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>

## Who’s Paying Fox’s $787.5 Million Settlement With Dominion? You Are!
 - [https://theintercept.com/2023/04/19/fox-news-dominion-settlement/](https://theintercept.com/2023/04/19/fox-news-dominion-settlement/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2023-04-19 21:53:16+00:00

<p>If you pay for cable or satellite TV, you’re subsidizing Fox News, whether you watch it or not.</p>
<p>The post <a href="https://theintercept.com/2023/04/19/fox-news-dominion-settlement/" rel="nofollow">Who’s Paying Fox’s $787.5 Million Settlement With Dominion? You Are!</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>

## Politics, Not Science, Will Win the Battle for Mifepristone
 - [https://theintercept.com/2023/04/19/mifepristone-fda-abortion/](https://theintercept.com/2023/04/19/mifepristone-fda-abortion/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2023-04-19 11:00:46+00:00

<p>From AIDS to Covid, the history of regulation shows that we need facts — but also direct action.</p>
<p>The post <a href="https://theintercept.com/2023/04/19/mifepristone-fda-abortion/" rel="nofollow">Politics, Not Science, Will Win the Battle for Mifepristone</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>

## The Discord Leaker: The Case of the Most Unorthodox National Security Leaks in History
 - [https://theintercept.com/2023/04/19/intercepted-podcast-pentagon-discord-leaks-national-security/](https://theintercept.com/2023/04/19/intercepted-podcast-pentagon-discord-leaks-national-security/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2023-04-19 10:01:56+00:00

<p>Jeremy Scahill, Murtaza Hussain, and Vanessa Gezari analyze the leaked top secret Pentagon documents and the Air National Guardsman alleged to have taken them.</p>
<p>The post <a href="https://theintercept.com/2023/04/19/intercepted-podcast-pentagon-discord-leaks-national-security/" rel="nofollow">The Discord Leaker: The Case of the Most Unorthodox National Security Leaks in History</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>

