# Source:Washington Examiner - politics, URL:https://feeds.feedburner.com/dcexaminer/Politics, language:en-US

## WATCH: MTG laughs in hearing after claiming Swalwell had sexual affair with Chinese spy
 - [https://www.washingtonexaminer.com/news/house/mtg-swalwell-sexual-affair-chinese-spy](https://www.washingtonexaminer.com/news/house/mtg-swalwell-sexual-affair-chinese-spy)
 - RSS feed: https://feeds.feedburner.com/dcexaminer/Politics
 - date published: 2023-04-19 19:43:08+00:00

A House hearing meant to debate funding levels for the Department of Homeland Security went off the rails Wednesday after a right-wing firebrand member accused a Democrat of having an affair with a Chinese spy.

