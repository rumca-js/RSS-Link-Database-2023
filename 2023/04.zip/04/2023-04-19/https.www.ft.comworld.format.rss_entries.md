# Source:Financial Times World, URL:https://www.ft.com/world?format=rss, language:en-US

## McCarthy sets out Republican demands for averting debt ceiling crisis
 - [https://www.ft.com/content/5a60eab9-de78-47c4-a736-8ea52e391170](https://www.ft.com/content/5a60eab9-de78-47c4-a736-8ea52e391170)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 21:44:12+00:00

House speaker’s bill would raise US borrowing limit but require Democrats to roll back White House priorities

## Sunak did not register details of some of wife’s company holdings
 - [https://www.ft.com/content/a93dcb4c-9f77-4406-bbf4-28b2daedd073](https://www.ft.com/content/a93dcb4c-9f77-4406-bbf4-28b2daedd073)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 21:37:10+00:00

Updated log of ministerial interests notes that Akshata Murty is ‘venture capital investor’

## Tesla’s profit margin slips after it cuts prices to boost demand
 - [https://www.ft.com/content/94f6a47c-42ad-4749-8e31-8d568270cf57](https://www.ft.com/content/94f6a47c-42ad-4749-8e31-8d568270cf57)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 20:40:18+00:00

Shares of Elon Musk’s electric-car maker fall in after-hours trading

## EU prepares emergency curbs on grain imports from Ukraine
 - [https://www.ft.com/content/bfd41b2b-ac1b-45d7-b6b4-19da0c615f9d](https://www.ft.com/content/bfd41b2b-ac1b-45d7-b6b4-19da0c615f9d)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 20:00:46+00:00

Bloc bows to pressure from Poland and other eastern European states over influx of cheap foodstuffs

## US Supreme Court leaves abortion pill ruling on hold
 - [https://www.ft.com/content/d20d1c88-c15d-44ab-af25-f32b8d094dc5](https://www.ft.com/content/d20d1c88-c15d-44ab-af25-f32b8d094dc5)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 19:47:12+00:00

Justice Samuel Alito extends deadline for further action until Friday

## Sunak set to rule on whether to fire UK deputy prime minister Raab
 - [https://www.ft.com/content/ec89937f-334f-4c40-99df-db947196b4ab](https://www.ft.com/content/ec89937f-334f-4c40-99df-db947196b4ab)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 18:55:17+00:00

Official report into allegations of bullying by ally of prime minister expected to be published as early as Thursday

## UK must cut chip imports from risky parts of world, review finds
 - [https://www.ft.com/content/fdad86bf-61aa-4567-b9a0-40fbe4f6baa3](https://www.ft.com/content/fdad86bf-61aa-4567-b9a0-40fbe4f6baa3)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 18:39:03+00:00

Long-delayed plan for semiconductor sector will also include targeted financial support for  industry

## SNP treasurer ‘stepping back’ amid probe into party finances
 - [https://www.ft.com/content/be176f71-aa52-461d-a2a0-90b79352f605](https://www.ft.com/content/be176f71-aa52-461d-a2a0-90b79352f605)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 18:28:33+00:00

Scottish deputy first minister Shona Robison says organisation has to ‘get our house in order’

## UK pension funds urge Hunt not to force them to invest in riskier assets
 - [https://www.ft.com/content/2b1a4e9f-f639-416f-92e8-4d69921813d1](https://www.ft.com/content/2b1a4e9f-f639-416f-92e8-4d69921813d1)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 18:20:52+00:00

Retirement schemes fear chancellor is considering ways to compel them to put money into fast-growing British companies

## Stubborn UK inflation rate forecast to lose energy in months ahead
 - [https://www.ft.com/content/ea066246-98de-41c6-b1aa-0259744a6120](https://www.ft.com/content/ea066246-98de-41c6-b1aa-0259744a6120)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 17:43:48+00:00

Underlying data indicate Britain not the global outlier on price rises it might appear to be

## New South African party hopes to capitalise on discontent with ANC
 - [https://www.ft.com/content/a14b6cc9-a709-4b0f-a027-6839fb7505bd](https://www.ft.com/content/a14b6cc9-a709-4b0f-a027-6839fb7505bd)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 17:43:21+00:00

Rise Mzansi emerges as a force to take on the former liberation movement as electricity blackouts and a struggling economy hit hard

## EU gas usage falls 18% after price shock caused by Russian supply cuts
 - [https://www.ft.com/content/a4d4e1ce-5444-42c7-bda6-6fda77cc2fe7](https://www.ft.com/content/a4d4e1ce-5444-42c7-bda6-6fda77cc2fe7)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 17:26:20+00:00

Large drop in consumption by households and businesses beats Brussels target and eases fears of energy crisis

## India to overtake China in the population race
 - [https://www.ft.com/content/15e01d29-c3a3-4eb3-b509-1845646da452](https://www.ft.com/content/15e01d29-c3a3-4eb3-b509-1845646da452)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 17:15:46+00:00

Also in this newsletter: London house prices fall and how to repair a toxic workplace culture

## Threats to the dollar’s dominance are overblown
 - [https://www.ft.com/content/0ab31d6c-7b08-4af7-acee-c27d8496e909](https://www.ft.com/content/0ab31d6c-7b08-4af7-acee-c27d8496e909)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 17:10:43+00:00

There are no viable alternatives to the greenback, but the US must avoid self-harm

## Heathrow airport and airlines launch rival appeals over landing fee ruling
 - [https://www.ft.com/content/d19c578f-ccd7-484f-98c6-68e47b5d4819](https://www.ft.com/content/d19c578f-ccd7-484f-98c6-68e47b5d4819)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 17:08:27+00:00

Virgin and BA seek larger cut to charges while UK hub claims regulator’s decision will hit investment

## Stability in N Ireland will lead to US investment, says envoy
 - [https://www.ft.com/content/17c4437d-d407-4488-9d0c-cfcec7f6110e](https://www.ft.com/content/17c4437d-d407-4488-9d0c-cfcec7f6110e)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 16:42:44+00:00

American companies value region’s unique access to both UK and EU markets

## HSBC hits back at top investor’s bid to split bank
 - [https://www.ft.com/content/2adc3259-71dc-45c8-ae78-eeadb614fa98](https://www.ft.com/content/2adc3259-71dc-45c8-ae78-eeadb614fa98)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 16:34:22+00:00

Response to Ping An’s rare public statement says spinning off Asia operations would erode value

## Germany to ban new gas and oil heating from next year
 - [https://www.ft.com/content/fbb800a9-5c6e-4781-943b-a6235f4149c9](https://www.ft.com/content/fbb800a9-5c6e-4781-943b-a6235f4149c9)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 16:18:02+00:00

Greens steer governing coalition into pushing ahead with transition to renewables but opposition parties criticise cost to consumers

## Jaguar Land Rover pledges £15bn investment in electric vehicles
 - [https://www.ft.com/content/0b6d287d-8266-46fa-b82b-b63ea61da5b1](https://www.ft.com/content/0b6d287d-8266-46fa-b82b-b63ea61da5b1)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 14:09:37+00:00

Chief Adrian Mardell says decision to build battery factory in UK or Spain is ‘imminent’

## Grand Delusion — America’s imposition on incompatible Middle East realities
 - [https://www.ft.com/content/31955e08-101d-4e82-adad-b8f69b27abbe](https://www.ft.com/content/31955e08-101d-4e82-adad-b8f69b27abbe)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 14:00:46+00:00

Steven Simon presents a brilliantly written critique of 45 years of US foreign policy in the Mideast

## Mega-banks in small states spell danger
 - [https://www.ft.com/content/76dd2968-9e03-4151-bad9-62624e9fc779](https://www.ft.com/content/76dd2968-9e03-4151-bad9-62624e9fc779)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 13:53:09+00:00

There are stark lessons to be drawn from the history of previous lender failures

## Lidl wins battle with Tesco over Clubcard logo
 - [https://www.ft.com/content/8e71eee3-677f-4e4f-870d-fefa589ff185](https://www.ft.com/content/8e71eee3-677f-4e4f-870d-fefa589ff185)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 12:45:12+00:00

UK’s largest supermarket may have to cease using current design after it was judged too similar to that of rival

## The Lex Newsletter: Beijing’s dreams of a global investment bank get a wake-up call
 - [https://www.ft.com/content/c65084aa-fc48-40d3-a3d6-ead1cfbdc35d](https://www.ft.com/content/c65084aa-fc48-40d3-a3d6-ead1cfbdc35d)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 11:59:27+00:00

International expansion has been hit but outlook for deals and stock performance within China is more encouraging

## Germany to bolster army with upgrade of 143 Puma infantry fighting vehicles
 - [https://www.ft.com/content/4486c9f4-e801-4c61-82e4-ff959dd56f79](https://www.ft.com/content/4486c9f4-e801-4c61-82e4-ff959dd56f79)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 11:41:05+00:00

Berlin seeks to boost under-equipped armed forces in response to Ukraine conflict

## The new Washington consensus
 - [https://www.ft.com/content/42922712-cd33-4de0-8763-1cc271331a32](https://www.ft.com/content/42922712-cd33-4de0-8763-1cc271331a32)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 11:40:29+00:00

Yesterday’s US economic orthodoxy is today’s heresy

## Britain’s tiny Tea Party casts a big shadow
 - [https://www.ft.com/content/2a8a0254-7bb4-4245-9ab1-77e0a082bdd3](https://www.ft.com/content/2a8a0254-7bb4-4245-9ab1-77e0a082bdd3)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 11:38:34+00:00

Reform UK’s populist rhetoric both scares and tempts the Conservatives as they try not to be outflanked on the right

## CBI and ousted director-general in war of words over his dismissal
 - [https://www.ft.com/content/aecd2fb1-86f7-4d25-ac15-92c42dfa4096](https://www.ft.com/content/aecd2fb1-86f7-4d25-ac15-92c42dfa4096)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 11:24:42+00:00

Business organisation says Tony Danker’s account of his sacking is ‘selective’

## Dollar :-(
 - [https://www.ft.com/content/72c27c26-f1d6-4a4b-be50-d6bf70c3546f](https://www.ft.com/content/72c27c26-f1d6-4a4b-be50-d6bf70c3546f)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 11:14:43+00:00

The greenback might now account for less than half of global reserves

## The taxman cometh
 - [https://www.ft.com/content/ff6a4e58-2d13-4452-8c09-72dd1e50d269](https://www.ft.com/content/ff6a4e58-2d13-4452-8c09-72dd1e50d269)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 11:00:36+00:00

Inside the mission to persuade companies to be more transparent about tax

## Shares in China metals miner CMOC surge as Congo impasse clears
 - [https://www.ft.com/content/3d33eed1-4358-40ed-a399-58480bbb7601](https://www.ft.com/content/3d33eed1-4358-40ed-a399-58480bbb7601)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 10:28:35+00:00

Deal between Chinese group and Gécamines threatens to put downward pressure on cobalt prices

## India overtakes China as world’s most populous country
 - [https://www.ft.com/content/82bf9d2a-95da-4ff7-abfc-8316073a274f](https://www.ft.com/content/82bf9d2a-95da-4ff7-abfc-8316073a274f)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 08:38:31+00:00

UN data marks a historic crossover moment for the two neighbours and geopolitical rivals

## SNP revelations also expose those who sat idly by
 - [https://www.ft.com/content/3c711d43-e7ec-40b1-9186-0c8b44151de4](https://www.ft.com/content/3c711d43-e7ec-40b1-9186-0c8b44151de4)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 08:30:36+00:00

Plus, Starmer and Sunak’s ideas and values are little known among most voters

## Japan’s SMFG resumes AT1 bond sales in first big issuance since Credit Suisse wipeout
 - [https://www.ft.com/content/2e7b7482-6734-46c8-a024-8ea60d424e0f](https://www.ft.com/content/2e7b7482-6734-46c8-a024-8ea60d424e0f)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 07:53:17+00:00

$1bn offering comes as investors ease fears that Swiss regulators’ decision to write down debt will set precedent

## North Korea claims success in building first spy satellite
 - [https://www.ft.com/content/e1330221-35e4-4773-9345-247f744b0981](https://www.ft.com/content/e1330221-35e4-4773-9345-247f744b0981)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 07:47:36+00:00

Pyongyang says satellite will strengthen country’s ability to conduct pre-emptive strike and monitor US and South Korean activity

## European shares slip as investors await economic data and US earnings
 - [https://www.ft.com/content/89da1e8f-6054-424e-a729-8abd3822b01f](https://www.ft.com/content/89da1e8f-6054-424e-a729-8abd3822b01f)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 07:40:20+00:00

Sterling rises against dollar after higher than expected UK inflation

## UK inflation remains in double digits as food prices stay high
 - [https://www.ft.com/content/e1978f6e-3051-443b-8681-f6d84e4362b6](https://www.ft.com/content/e1978f6e-3051-443b-8681-f6d84e4362b6)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 06:51:54+00:00

Rate of 10.1% in March is higher than expected

## Ukraine and baseball put Japan’s Kishida back in the game
 - [https://www.ft.com/content/489750cc-85c6-4499-b7b3-72610c45112f](https://www.ft.com/content/489750cc-85c6-4499-b7b3-72610c45112f)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 05:31:46+00:00

Prime minister receives approval rating boost from foreign diplomacy push ahead of local by-elections

## Belgium PM De Croo proposes nitrogen flexibility for farmers
 - [https://www.ft.com/content/7df8512c-c1cc-4d5c-822b-4a86933ff9eb](https://www.ft.com/content/7df8512c-c1cc-4d5c-822b-4a86933ff9eb)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 05:00:36+00:00

Also in this newsletter: Europe’s looming AI battles

## Warsaw ghetto commemoration seeks to overcome post-Holocaust politics
 - [https://www.ft.com/content/470c1f2a-4d6f-4a5a-95f3-abf87f575af8](https://www.ft.com/content/470c1f2a-4d6f-4a5a-95f3-abf87f575af8)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 04:05:36+00:00

German and Israeli heads of state set aside disputes with Poland to mark second world war uprising

## The race for bank deposits
 - [https://www.ft.com/content/01ca8f43-e44b-42c6-b3a0-ef4c490384a3](https://www.ft.com/content/01ca8f43-e44b-42c6-b3a0-ef4c490384a3)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 04:01:36+00:00

Plus, biotech deals make a comeback and Singapore keeps its investment boom on the down low

## America’s dollar stores get a makeover for the age of inflation
 - [https://www.ft.com/content/32c7a2b9-0e0b-46e5-9777-891e6d82df4c](https://www.ft.com/content/32c7a2b9-0e0b-46e5-9777-891e6d82df4c)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 04:00:37+00:00

No-frills retailers step up investment to attract middle-income shoppers in search of cheaper groceries

## Beijing’s rise leaves Paris Club of creditors struggling to find forum
 - [https://www.ft.com/content/6681e843-d0bb-4031-9ee6-43c2af4d2204](https://www.ft.com/content/6681e843-d0bb-4031-9ee6-43c2af4d2204)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 04:00:37+00:00

Breaking the debt deadlock will require China to adopt a more collegial approach

## Britain’s ‘capitalism without capital’: the pension funds that shun risk
 - [https://www.ft.com/content/03280cd7-8013-4212-a98e-e0c35194d009](https://www.ft.com/content/03280cd7-8013-4212-a98e-e0c35194d009)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 04:00:37+00:00

The first part of a series on the crisis in European equities explores how a rush into safer assets has left the UK listing market moribund and is driving companies overseas

## Italy hopes for EU concession on biofuels
 - [https://www.ft.com/content/99458dad-2ed6-4bc8-9458-f160da59f471](https://www.ft.com/content/99458dad-2ed6-4bc8-9458-f160da59f471)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 04:00:37+00:00

G7 statement raises hopes for exception to emissions legislation

## Military briefing: Ukraine pleads for missiles as air defence stocks run low
 - [https://www.ft.com/content/9e68f9d6-0c0e-4d71-adc0-9a95fc57ad4d](https://www.ft.com/content/9e68f9d6-0c0e-4d71-adc0-9a95fc57ad4d)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 04:00:37+00:00

Some allies fear Kyiv’s planned counter-offensive will falter if Russian air power is left unchecked

## Risk of regional powers picking sides raises stakes in battle for Sudan
 - [https://www.ft.com/content/228f929d-a73f-4bb3-83b0-70707ee48348](https://www.ft.com/content/228f929d-a73f-4bb3-83b0-70707ee48348)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 04:00:37+00:00

Regional powers have all sought to influence a country now being fought over by its most powerful forces

## The Pentagon leak: how a low-ranked 21-year-old accessed top US secrets
 - [https://www.ft.com/content/fc72d277-7fa8-4b29-9231-4feb34f43b0c](https://www.ft.com/content/fc72d277-7fa8-4b29-9231-4feb34f43b0c)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 04:00:36+00:00

Charges against Jack Teixeira spark reckoning on country’s intelligence handling

## The new chroniclers of street style
 - [https://www.ft.com/content/e8fd1585-b133-43b9-b319-7e271c062ce5](https://www.ft.com/content/e8fd1585-b133-43b9-b319-7e271c062ce5)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 04:00:36+00:00

Photographers and vloggers are pulling back the curtain on the pieces people actually buy and wear

## The TikTok divide
 - [https://www.ft.com/content/f8c27645-1e1a-4453-a867-ba4e8c2f6a69](https://www.ft.com/content/f8c27645-1e1a-4453-a867-ba4e8c2f6a69)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 04:00:30+00:00

Rupert Murdoch’s Fox agrees $787.5mn settlement in Dominion defamation case

## Why Apple can’t leave China
 - [https://www.ft.com/content/254a0baf-dcd7-42b6-b577-8af96fcfc166](https://www.ft.com/content/254a0baf-dcd7-42b6-b577-8af96fcfc166)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 04:00:00+00:00

Is the tech behemoth trapped? The FT’s Patrick McGee explains

## Why 3D printing is vital to success of US manufacturing | FT Film
 - [https://www.ft.com/video/444caf78-0c1d-4e9e-8388-fffb55faf6f8](https://www.ft.com/video/444caf78-0c1d-4e9e-8388-fffb55faf6f8)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-04-19 03:59:47+00:00

New additive manufacturing technology can boost innovation and jobs in a de-globalising world

