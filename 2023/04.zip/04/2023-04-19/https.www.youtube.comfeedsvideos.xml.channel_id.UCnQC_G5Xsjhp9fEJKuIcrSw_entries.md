# Source:Ben Shapiro, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw, language:en-US

## Matt Walsh's Phone HACKED
 - [https://www.youtube.com/watch?v=sq0UgjFqkD0](https://www.youtube.com/watch?v=sq0UgjFqkD0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-04-19 22:08:12+00:00

Get 3 Months FREE of ExpressVPN: https://www.expressvpn.com/shapiroshorts

Watch the member-only portion of my show on DailyWire+: bit.ly/3SUaXn3

LIKE & SUBSCRIBE for new videos every day. https://www.youtube.com/@BenShapiro?sub_confirmation=1

[CUSTOM DESCRIPTION]

Watch the full episode here:

Stop giving your money to woke corporations that hate you. Get your Jeremy's Razors today at https://bit.ly/3IfCVEI

Grab your Ben Shapiro merch here: https://bit.ly/3IgkGig

#shorts #BenShapiro #TheBenShapiroShow #News #Politics #DailyWire #shortsfeed #shortsreaction #dailynews #twitternews #mattwalsh #mattwalshhacked #lgbtq #gender

## Ben REACTS to The Marvels Trailer
 - [https://www.youtube.com/watch?v=t88LT_QnIHg](https://www.youtube.com/watch?v=t88LT_QnIHg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-04-19 22:05:08+00:00

Everything Disney touches turns woke. The Marvels movie seems like a feminist version of Ghostbusters. The only thing funnier than the trailer itself is the comments on the video from Breitbart. 

Get your free life insurance quote & see how much you could save: http://policygenius.com/SHAPIRO

Head to https://BenforTheFellowship.org or call 800-331-3737 to rush an emergency food box today.

Watch the member-only portion of my show on DailyWire+: bit.ly/3SUaXn3

LIKE & SUBSCRIBE for new videos every day. https://www.youtube.com/@BenShapiro?sub_confirmation=1

Watch the full episode here: https://youtu.be/5YuBOffco4g

Stop giving your money to woke corporations that hate you. Get your Jeremy's Razors today at https://bit.ly/3IfCVEI

Grab your Ben Shapiro merch here: https://bit.ly/3IgkGig

#BenShapiro #TheBenShapiroShow #News #Politics #dailywire  #themarvels #marvelcomics #moviereaction #moviereview #reaction #breitbart #disney #disneymovies

## THEY'RE TURNING THE MICKEYS GAY
 - [https://www.youtube.com/watch?v=5YuBOffco4g](https://www.youtube.com/watch?v=5YuBOffco4g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-04-19 17:00:07+00:00

Matt Walsh’s phone is hacked, and the tolerant Left celebrates; Fox News signs a $787 million check to Dominion voting systems to avoid a trial; and Disney puts Mickey and Minnie in rainbow LGBTQ+ uniforms.

- - - 

Click here to join the member exclusive portion of my show: https://utm.io/ueSEj

- - - 

DailyWire+:

Become a DailyWire+ member to watch brand new episodes of the series “Exodus” by Dr. Jordan B. Peterson: https://bit.ly/3lfVtwK 
Shop all Jeremy’s Razors products here: https://bit.ly/3xuFD43 

Get your Ben Shapiro merch here: https://bit.ly/3TAu2cw

 - - - 


Today’s Sponsors:

ExpressVPN - Get 3 Months FREE of ExpressVPN: https://expressvpn.com/ben

Birch Gold - Text "BEN" to 989898, or go to https://birchgold.com/ben, to claim your free infokit today!

Good Ranchers - Use code "BEN" at checkout and get $20 off your order: https://www.goodranchers.com/Ben?utm_source=DailyWire&amp;utm_medium=referral&amp;utm_campaign=BenShapiro

IFCJ - Head to BenforTheFellowship.org or call 800-331-3737 to rush a Passover Food Box.

Policygenius - Get your free life insurance quote & see how much you could save: http://policygenius.com/SHAPIRO 

Ruff Greens - Get a free Jumpstart Trial Bag at http://www.FreeRuffGreens.com/Ben, or call 833-MY DOG 33

- - -

Socials:

Follow on Twitter: https://bit.ly/3cXUn53 

Follow on Instagram: https://bit.ly/3QtuibJ 

Follow on Facebook: https://bit.ly/3TTirqd 

Subscribe on YouTube: https://bit.ly/3RPyBiB

#BenShapiro #TheBenShapiroShow #News #Politics #DailyWire

## THEY'RE TURNING THE MICKEYS GAY
 - [https://www.youtube.com/watch?v=zFDR2hLu98I](https://www.youtube.com/watch?v=zFDR2hLu98I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-04-19 16:06:25+00:00

Matt Walsh’s phone is hacked, and the tolerant Left celebrates; Fox News signs a $787 million check to Dominion voting systems to avoid a trial; and Disney puts Mickey and Minnie in rainbow LGBTQ+ uniforms.

- - - 

Click here to join the member exclusive portion of my show: https://utm.io/ueSEj

- - - 

DailyWire+:

Become a DailyWire+ member to watch brand new episodes of the series “Exodus” by Dr. Jordan B. Peterson: https://bit.ly/3lfVtwK 
Shop all Jeremy’s Razors products here: https://bit.ly/3xuFD43 

Get your Ben Shapiro merch here: https://bit.ly/3TAu2cw

 - - - 


Today’s Sponsors:

ExpressVPN - Get 3 Months FREE of ExpressVPN: https://expressvpn.com/ben

Birch Gold - Text "BEN" to 989898, or go to https://birchgold.com/ben, to claim your free infokit today!

Good Ranchers - Use code "BEN" at checkout and get $20 off your order: https://www.goodranchers.com/Ben?utm_source=DailyWire&amp;utm_medium=referral&amp;utm_campaign=BenShapiro

IFCJ - Head to BenforTheFellowship.org or call 800-331-3737 to rush a Passover Food Box.

Policygenius - Get your free life insurance quote & see how much you could save: http://policygenius.com/SHAPIRO 

Ruff Greens - Get a free Jumpstart Trial Bag at http://www.FreeRuffGreens.com/Ben, or call 833-MY DOG 33

- - -

Socials:

Follow on Twitter: https://bit.ly/3cXUn53 

Follow on Instagram: https://bit.ly/3QtuibJ 

Follow on Facebook: https://bit.ly/3TTirqd 

Subscribe on YouTube: https://bit.ly/3RPyBiB

#BenShapiro #TheBenShapiroShow #News #Politics #DailyWire

## Mt. Everest 🗻
 - [https://www.youtube.com/watch?v=YxexX77Rqh0](https://www.youtube.com/watch?v=YxexX77Rqh0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-04-19 02:30:11+00:00

Watch the member-only portion of my show on DailyWire+: bit.ly/3SUaXn3

LIKE & SUBSCRIBE for new videos every day. https://www.youtube.com/@BenShapiro?sub_confirmation=1

Stop giving your money to woke corporations that hate you. Get your Jeremy's Razors today at https://bit.ly/3IfCVEI

Grab your Ben Shapiro merch here: https://bit.ly/3IgkGig

#shorts #BenShapiro #TheBenShapiroShow #News #Politics #DailyWire #shortsfeed #shortsreaction #immigration #border #bordercrossing #southernborder

## Feminists in 2023
 - [https://www.youtube.com/watch?v=8R81ClS0M28](https://www.youtube.com/watch?v=8R81ClS0M28)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-04-19 01:30:02+00:00

Watch the member-only portion of my show on DailyWire+: bit.ly/3SUaXn3

LIKE & SUBSCRIBE for new videos every day. https://www.youtube.com/@BenShapiro?sub_confirmation=1

Stop giving your money to woke corporations that hate you. Get your Jeremy's Razors today at https://bit.ly/3IfCVEI

Grab your Ben Shapiro merch here: https://bit.ly/3IgkGig

#shorts #BenShapiro #TheBenShapiroShow #News #Politics #DailyWire #shortsfeed #shortsreaction #reaction #feminism #toxicfemininity #tiktok

## Trans-Ballerina 🩰
 - [https://www.youtube.com/watch?v=gxdKAy-YtWU](https://www.youtube.com/watch?v=gxdKAy-YtWU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-04-19 00:30:30+00:00

Watch the member-only portion of my show on DailyWire+: bit.ly/3SUaXn3

LIKE & SUBSCRIBE for new videos every day. https://www.youtube.com/@BenShapiro?sub_confirmation=1

Stop giving your money to woke corporations that hate you. Get your Jeremy's Razors today at https://bit.ly/3IfCVEI

Grab your Ben Shapiro merch here: https://bit.ly/3IgkGig

#shorts #BenShapiro #TheBenShapiroShow #News #Politics #DailyWire #shortsfeed #shortsreaction #lgbtq #trans #reaction

## MAYHEM and LOOTING in Chicago Goes Viral
 - [https://www.youtube.com/watch?v=WRIQ_OrkW44](https://www.youtube.com/watch?v=WRIQ_OrkW44)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-04-19 00:30:21+00:00

This is the looting and mayhem that the mainstream media doesn't want you to see. Why is that? It doesn't fit their narrative because the people causing the mayhem are black.

Learn more about Innovation Refunds at https://getrefunds.com/.

Save 70% off the Most Popular Package, + FREE SHIPPING! https://genucel.com/shapiro

Watch the member-only portion of my show on DailyWire+: bit.ly/3SUaXn3

LIKE & SUBSCRIBE for new videos every day. https://www.youtube.com/@BenShapiro?sub_confirmation=1

Watch the full episode here: https://youtu.be/WOdJx2sAxn4

Stop giving your money to woke corporations that hate you. Get your Jeremy's Razors today at https://bit.ly/3IfCVEI

Grab your Ben Shapiro merch here: https://bit.ly/3IgkGig

#BenShapiro #TheBenShapiroShow #News #Politics #DailyWire #chicago #looting #chicagonews #crime

