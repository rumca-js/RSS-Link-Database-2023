# Source:Nerdstalgic, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXjmz8dFzRJZrZY8eFiXNUQ, language:en-US

## How A Low Budget Alien Film Changed Visual Effects Forever
 - [https://www.youtube.com/watch?v=5cXaZCr8-2c](https://www.youtube.com/watch?v=5cXaZCr8-2c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXjmz8dFzRJZrZY8eFiXNUQ
 - date published: 2023-04-19 17:00:05+00:00

District 9 was far beyond it's years when released in 2009.  Utilizing a hand held documentary style of camera work, District 9 was able to seamlessly incorporate the alien characters into the footage with a pain staking VFX process.  This slow process was the key to making District 9 feel alive and countless big budget features began to rethink their approach to visual effects. 

#district9 #vfx #nerdstalgic 

Written by Dave Baker
Edited by Nick Murphy

