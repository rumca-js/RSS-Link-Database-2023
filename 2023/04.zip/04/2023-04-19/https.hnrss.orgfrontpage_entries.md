# Source:Hacker News - frontpage, URL:https://hnrss.org/frontpage, language:en-US

## Uncleftish Beholding (1989)
 - [https://www.ling.upenn.edu/~beatrice/110/docs/uncleftish_beholding.html](https://www.ling.upenn.edu/~beatrice/110/docs/uncleftish_beholding.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 21:59:23+00:00

<p>Article URL: <a href="https://www.ling.upenn.edu/~beatrice/110/docs/uncleftish_beholding.html">https://www.ling.upenn.edu/~beatrice/110/docs/uncleftish_beholding.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35633840">https://news.ycombinator.com/item?id=35633840</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Building telescopes on the Moon could transform astronomy
 - [https://theconversation.com/building-telescopes-on-the-moon-could-transform-astronomy-and-its-becoming-an-achievable-goal-203308](https://theconversation.com/building-telescopes-on-the-moon-could-transform-astronomy-and-its-becoming-an-achievable-goal-203308)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 21:23:12+00:00

<p>Article URL: <a href="https://theconversation.com/building-telescopes-on-the-moon-could-transform-astronomy-and-its-becoming-an-achievable-goal-203308">https://theconversation.com/building-telescopes-on-the-moon-could-transform-astronomy-and-its-becoming-an-achievable-goal-203308</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35633490">https://news.ycombinator.com/item?id=35633490</a></p>
<p>Points: 43</p>
<p># Comments: 12</p>

## The days are long but the decades are short
 - [https://blog.samaltman.com/the-days-are-long-but-the-decades-are-short](https://blog.samaltman.com/the-days-are-long-but-the-decades-are-short)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 21:12:56+00:00

<p>Article URL: <a href="https://blog.samaltman.com/the-days-are-long-but-the-decades-are-short">https://blog.samaltman.com/the-days-are-long-but-the-decades-are-short</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35633398">https://news.ycombinator.com/item?id=35633398</a></p>
<p>Points: 9</p>
<p># Comments: 4</p>

## GPT-3 Creative Fiction
 - [https://gwern.net/gpt-3](https://gwern.net/gpt-3)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 21:04:49+00:00

<p>Article URL: <a href="https://gwern.net/gpt-3">https://gwern.net/gpt-3</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35633316">https://news.ycombinator.com/item?id=35633316</a></p>
<p>Points: 14</p>
<p># Comments: 3</p>

## Intranasal vaccine confers broad mucosal and systemic immunity against SARS-CoV2
 - [https://www.nature.com/articles/s41392-023-01423-6](https://www.nature.com/articles/s41392-023-01423-6)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 20:48:47+00:00

<p>Article URL: <a href="https://www.nature.com/articles/s41392-023-01423-6">https://www.nature.com/articles/s41392-023-01423-6</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35633152">https://news.ycombinator.com/item?id=35633152</a></p>
<p>Points: 25</p>
<p># Comments: 5</p>

## How can some infinities be bigger than others?
 - [https://www.quantamagazine.org/how-can-some-infinities-be-bigger-than-others-20230419/](https://www.quantamagazine.org/how-can-some-infinities-be-bigger-than-others-20230419/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 20:47:49+00:00

<p>Article URL: <a href="https://www.quantamagazine.org/how-can-some-infinities-be-bigger-than-others-20230419/">https://www.quantamagazine.org/how-can-some-infinities-be-bigger-than-others-20230419/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35633137">https://news.ycombinator.com/item?id=35633137</a></p>
<p>Points: 3</p>
<p># Comments: 2</p>

## Satellite Takes Image of Another Satellite
 - [https://twitter.com/NASA_Landsat/status/1642954595377750027](https://twitter.com/NASA_Landsat/status/1642954595377750027)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 20:10:27+00:00

<p>Article URL: <a href="https://twitter.com/NASA_Landsat/status/1642954595377750027">https://twitter.com/NASA_Landsat/status/1642954595377750027</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35632721">https://news.ycombinator.com/item?id=35632721</a></p>
<p>Points: 8</p>
<p># Comments: 2</p>

## Qantas is bringing back Airbus A380s from the California desert
 - [https://www.smh.com.au/business/companies/california-to-sydney-how-do-you-wake-an-a380-after-1000-days-in-the-desert-20221227-p5c8zp.html](https://www.smh.com.au/business/companies/california-to-sydney-how-do-you-wake-an-a380-after-1000-days-in-the-desert-20221227-p5c8zp.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 19:10:02+00:00

<p>Article URL: <a href="https://www.smh.com.au/business/companies/california-to-sydney-how-do-you-wake-an-a380-after-1000-days-in-the-desert-20221227-p5c8zp.html">https://www.smh.com.au/business/companies/california-to-sydney-how-do-you-wake-an-a380-after-1000-days-in-the-desert-20221227-p5c8zp.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35632058">https://news.ycombinator.com/item?id=35632058</a></p>
<p>Points: 22</p>
<p># Comments: 4</p>

## Farouk Al Kasim Saved Norway from Its Oil
 - [https://psmag.com/environment/iraqi-vikings-farouk-al-kasim-norway-oil-72715](https://psmag.com/environment/iraqi-vikings-farouk-al-kasim-norway-oil-72715)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 18:36:45+00:00

<p>Article URL: <a href="https://psmag.com/environment/iraqi-vikings-farouk-al-kasim-norway-oil-72715">https://psmag.com/environment/iraqi-vikings-farouk-al-kasim-norway-oil-72715</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35631717">https://news.ycombinator.com/item?id=35631717</a></p>
<p>Points: 15</p>
<p># Comments: 1</p>

## Basic math related to computation and memory usage for transformers
 - [https://blog.eleuther.ai/transformer-math/](https://blog.eleuther.ai/transformer-math/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 18:23:59+00:00

<p>Article URL: <a href="https://blog.eleuther.ai/transformer-math/">https://blog.eleuther.ai/transformer-math/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35631546">https://news.ycombinator.com/item?id=35631546</a></p>
<p>Points: 32</p>
<p># Comments: 0</p>

## Show HN: GoGoBrowse – A Peer to Peer Web Browser
 - [https://gogobrowse.com](https://gogobrowse.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 18:20:52+00:00

<p>Hi HN!<p>GoGoBrowse is a side project I've been working on that allows 2 users to browse the web together while voice chatting.<p>It's a proof of concept for a new model of browsing the web I've been thinking about. My thought is that before a leap to a 3D Metaverse, we need a 2D Metaverse, which is simply social web browsing. I wrote more about it here: <a href="https://gogobrowse.com/before-the-metaverse-we-need-a-new-web-browser" rel="nofollow">https://gogobrowse.com/before-the-metaverse-we-need-a-new-we...</a><p>Though the goal of an entirely social web browser is still quite a ways off, I think of this as a small first step in that direction.<p>I'd love any feedback on the app itself, and the general concept of social web browsing.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35631499">https://news.ycombinator.com/item?id=35631499</a></p>
<p>Points: 11</p>
<p># Comments: 8</p>

## I Quit Reddit in 1 Day
 - [https://nitinpassa.com/how-i-quit-reddit-in-1-day/](https://nitinpassa.com/how-i-quit-reddit-in-1-day/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 17:55:56+00:00

<p>Article URL: <a href="https://nitinpassa.com/how-i-quit-reddit-in-1-day/">https://nitinpassa.com/how-i-quit-reddit-in-1-day/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35631200">https://news.ycombinator.com/item?id=35631200</a></p>
<p>Points: 22</p>
<p># Comments: 15</p>

## Pop-shoot: Synthwave styled space shooter, inspired by 80s arcades
 - [https://github.com/kiwphi/pop-shoot](https://github.com/kiwphi/pop-shoot)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 17:52:06+00:00

<p>Article URL: <a href="https://github.com/kiwphi/pop-shoot">https://github.com/kiwphi/pop-shoot</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35631151">https://news.ycombinator.com/item?id=35631151</a></p>
<p>Points: 25</p>
<p># Comments: 2</p>

## JEP Draft: Integrity and Strong Encapsulation
 - [https://openjdk.org/jeps/8305968](https://openjdk.org/jeps/8305968)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 17:44:50+00:00

<p>Article URL: <a href="https://openjdk.org/jeps/8305968">https://openjdk.org/jeps/8305968</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35631072">https://news.ycombinator.com/item?id=35631072</a></p>
<p>Points: 5</p>
<p># Comments: 1</p>

## The GTK+3 port of GIMP is officially finished
 - [https://twitter.com/zemarmot/status/1646272510701236229](https://twitter.com/zemarmot/status/1646272510701236229)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 17:11:04+00:00

<p>Article URL: <a href="https://twitter.com/zemarmot/status/1646272510701236229">https://twitter.com/zemarmot/status/1646272510701236229</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35630681">https://news.ycombinator.com/item?id=35630681</a></p>
<p>Points: 14</p>
<p># Comments: 5</p>

## Community Phone Is Hiring Engineers to manage VoLTE and low latency systems
 - [https://www.ycombinator.com/companies/community-phone-company/jobs/QpIGSM1-product-engineer](https://www.ycombinator.com/companies/community-phone-company/jobs/QpIGSM1-product-engineer)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 17:00:45+00:00

<p>Article URL: <a href="https://www.ycombinator.com/companies/community-phone-company/jobs/QpIGSM1-product-engineer">https://www.ycombinator.com/companies/community-phone-company/jobs/QpIGSM1-product-engineer</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35630550">https://news.ycombinator.com/item?id=35630550</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

## Why universities should return to oral exams in the AI and ChatGPT era
 - [https://theconversation.com/why-universities-should-return-to-oral-exams-in-the-ai-and-chatgpt-era-203429](https://theconversation.com/why-universities-should-return-to-oral-exams-in-the-ai-and-chatgpt-era-203429)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 16:52:32+00:00

<p>Article URL: <a href="https://theconversation.com/why-universities-should-return-to-oral-exams-in-the-ai-and-chatgpt-era-203429">https://theconversation.com/why-universities-should-return-to-oral-exams-in-the-ai-and-chatgpt-era-203429</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35630449">https://news.ycombinator.com/item?id=35630449</a></p>
<p>Points: 9</p>
<p># Comments: 1</p>

## User: Junnn11
 - [https://en.wikipedia.org/wiki/User:Junnn11](https://en.wikipedia.org/wiki/User:Junnn11)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 16:50:38+00:00

<p>Article URL: <a href="https://en.wikipedia.org/wiki/User:Junnn11">https://en.wikipedia.org/wiki/User:Junnn11</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35630423">https://news.ycombinator.com/item?id=35630423</a></p>
<p>Points: 26</p>
<p># Comments: 1</p>

## NPM Provenance Public Beta
 - [https://github.blog/changelog/2023-04-19-npm-provenance-public-beta/](https://github.blog/changelog/2023-04-19-npm-provenance-public-beta/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 16:36:16+00:00

<p>Article URL: <a href="https://github.blog/changelog/2023-04-19-npm-provenance-public-beta/">https://github.blog/changelog/2023-04-19-npm-provenance-public-beta/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35630241">https://news.ycombinator.com/item?id=35630241</a></p>
<p>Points: 17</p>
<p># Comments: 4</p>

## Street Votes: A proposed response to Ireland's housing crisis
 - [https://www.thefitzwilliam.com/p/a-simple-and-elegant-response-to](https://www.thefitzwilliam.com/p/a-simple-and-elegant-response-to)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 15:34:09+00:00

<p>Article URL: <a href="https://www.thefitzwilliam.com/p/a-simple-and-elegant-response-to">https://www.thefitzwilliam.com/p/a-simple-and-elegant-response-to</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35629474">https://news.ycombinator.com/item?id=35629474</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## Physics Advanced Generative AI
 - [https://www.assemblyai.com/blog/how-physics-advanced-generative-ai/](https://www.assemblyai.com/blog/how-physics-advanced-generative-ai/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 15:26:49+00:00

<p>Article URL: <a href="https://www.assemblyai.com/blog/how-physics-advanced-generative-ai/">https://www.assemblyai.com/blog/how-physics-advanced-generative-ai/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35629370">https://news.ycombinator.com/item?id=35629370</a></p>
<p>Points: 18</p>
<p># Comments: 5</p>

## Ask HN: AI to study my DSL and then output it?
 - [https://news.ycombinator.com/item?id=35629351](https://news.ycombinator.com/item?id=35629351)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 15:26:00+00:00

<p>Ideally I want to contain and run LLM output of my domain-specific language, but it seems that I would need to fine-tune existing models.  What’s the easiest online or local solution?<p>How to automatically generate:
    a broad array of security tests;
    the most efficient code;
    the most readable and extensible code</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35629351">https://news.ycombinator.com/item?id=35629351</a></p>
<p>Points: 7</p>
<p># Comments: 2</p>

## Stability AI Launches StableLM: A New Open-Source Language Model
 - [https://github.com/Stability-AI/StableLM](https://github.com/Stability-AI/StableLM)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 15:11:47+00:00

<p>Article URL: <a href="https://github.com/Stability-AI/StableLM">https://github.com/Stability-AI/StableLM</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35629141">https://news.ycombinator.com/item?id=35629141</a></p>
<p>Points: 27</p>
<p># Comments: 2</p>

## Stability AI Launches the First of Its StableLM Suite of Language Models
 - [https://stability.ai/blog/stability-ai-launches-the-first-of-its-stablelm-suite-of-language-models](https://stability.ai/blog/stability-ai-launches-the-first-of-its-stablelm-suite-of-language-models)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 15:10:47+00:00

<p>Article URL: <a href="https://stability.ai/blog/stability-ai-launches-the-first-of-its-stablelm-suite-of-language-models">https://stability.ai/blog/stability-ai-launches-the-first-of-its-stablelm-suite-of-language-models</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35629127">https://news.ycombinator.com/item?id=35629127</a></p>
<p>Points: 62</p>
<p># Comments: 11</p>

## DIY Neurotech:Making BCI open-source thrusts brain-signal into a maker’s world
 - [https://spectrum.ieee.org/neurotechnology-diy](https://spectrum.ieee.org/neurotechnology-diy)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 15:09:48+00:00

<p>Article URL: <a href="https://spectrum.ieee.org/neurotechnology-diy">https://spectrum.ieee.org/neurotechnology-diy</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35629114">https://news.ycombinator.com/item?id=35629114</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Show HN: Checksum – generate and maintain end-to-end tests using AI
 - [https://news.ycombinator.com/item?id=35629050](https://news.ycombinator.com/item?id=35629050)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 15:05:14+00:00

<p>Hey HN!<p>I’m Gal, co-founder at Checksum (https://checksum.ai). Checksum is a tool for automatically generating and maintaining end-to-end tests using AI.<p>I cut my teeth in applied ML in 2016 at a maritime tech company called TSG, based in Israel. When I was there, I worked on a cool product that used machine learning to detect suspicious vehicles. Radar data is pretty tough for humans to parse, but a great fit for AI – and it worked very well for detecting smugglers, terrorist activity, and that sort of thing.<p>In 2021, after a few years working in big tech (Lyft, Google), I joined a YC company, seer W21, as CTO. This is where I experienced the unique pain of trying to keep end-to-end tests in a good state. The app was quite featureful, and it was a struggle to get and maintain good test coverage.<p>Like the suspicious maritime vehicle problem I had previously encountered, building and maintaining E2E tests had all the markings of a problem where machines could outperform humans. Also, in the early user interviews, it became clear that this problem wasn’t one that just went away as organizations grew past the startup phase, but one that got even more tangled up and unpleasant.<p>We’ve been building the product for a little over a year now, and it’s been interesting to learn that some problems were surprisingly easy, and others unusually tough. To get the data we need to train our models, we use the same underlying technology that tools like Fullstory and Hotjar use, and it works quite well. Also, we’re able to get good tests from relatively few user sessions (in most cases, fewer than 200 sessions).<p>Right now, the models are really good at improving test coverage for featureful web-apps that don’t have much coverage (ie; generating and maintaining a bunch of new tests), but making existing tests better has been a tougher nut to crack. We don’t have as much of a place in organizations where test coverage is great and test quality is medium-to-poor, but we’re keen to develop in that direction.<p>We’re still early, and spend basically all of our time working with a small handful of design partners (mostly medium-sized startups struggling with test coverage), but it felt like time to share with the HN community.<p>Thanks so much, happy to answer any questions, and excited to hear your thoughts!</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35629050">https://news.ycombinator.com/item?id=35629050</a></p>
<p>Points: 13</p>
<p># Comments: 7</p>

## The Anatomy of Autonomy: Why Agents Are the Next AI Killer App
 - [https://www.latent.space/p/agents](https://www.latent.space/p/agents)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 15:04:08+00:00

<p>Article URL: <a href="https://www.latent.space/p/agents">https://www.latent.space/p/agents</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35629033">https://news.ycombinator.com/item?id=35629033</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Show HN: Open-source Auth0 alternative Ory Kratos v0.13 released – nearing v1.0
 - [https://github.com/ory/kratos/releases/tag/v0.13.0](https://github.com/ory/kratos/releases/tag/v0.13.0)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 14:30:09+00:00

<p>Article URL: <a href="https://github.com/ory/kratos/releases/tag/v0.13.0">https://github.com/ory/kratos/releases/tag/v0.13.0</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35628642">https://news.ycombinator.com/item?id=35628642</a></p>
<p>Points: 22</p>
<p># Comments: 5</p>

## When Interfaces Kill: What Happened to John Denver (1999)
 - [https://www.asktog.com/columns/027InterfacesThatKill.html](https://www.asktog.com/columns/027InterfacesThatKill.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 14:18:21+00:00

<p>Article URL: <a href="https://www.asktog.com/columns/027InterfacesThatKill.html">https://www.asktog.com/columns/027InterfacesThatKill.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35628485">https://news.ycombinator.com/item?id=35628485</a></p>
<p>Points: 58</p>
<p># Comments: 11</p>

## AI Incident Database
 - [https://incidentdatabase.ai/](https://incidentdatabase.ai/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 14:08:36+00:00

<p>Article URL: <a href="https://incidentdatabase.ai/">https://incidentdatabase.ai/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35628345">https://news.ycombinator.com/item?id=35628345</a></p>
<p>Points: 41</p>
<p># Comments: 16</p>

## Latent Diffusion Models Are Zero-Shot Speech and Singing Synthesizers
 - [https://speechresearch.github.io/naturalspeech2/](https://speechresearch.github.io/naturalspeech2/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 13:20:56+00:00

<p>Article URL: <a href="https://speechresearch.github.io/naturalspeech2/">https://speechresearch.github.io/naturalspeech2/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35627790">https://news.ycombinator.com/item?id=35627790</a></p>
<p>Points: 50</p>
<p># Comments: 6</p>

## Most of my skills are now worth nothing, but 10% are worth 1000x
 - [https://tidyfirst.substack.com/p/90-of-my-skills-are-now-worth-0](https://tidyfirst.substack.com/p/90-of-my-skills-are-now-worth-0)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 13:19:43+00:00

<p>Article URL: <a href="https://tidyfirst.substack.com/p/90-of-my-skills-are-now-worth-0">https://tidyfirst.substack.com/p/90-of-my-skills-are-now-worth-0</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35627779">https://news.ycombinator.com/item?id=35627779</a></p>
<p>Points: 107</p>
<p># Comments: 132</p>

## Vivaldi 6.0 Web Browser Introduces Tab Workspaces and Custom Icons
 - [https://www.macrumors.com/2023/04/19/vivaldi-6-mac-tab-workspaces-custom-icons/](https://www.macrumors.com/2023/04/19/vivaldi-6-mac-tab-workspaces-custom-icons/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 12:12:02+00:00

<p>Article URL: <a href="https://www.macrumors.com/2023/04/19/vivaldi-6-mac-tab-workspaces-custom-icons/">https://www.macrumors.com/2023/04/19/vivaldi-6-mac-tab-workspaces-custom-icons/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35627167">https://news.ycombinator.com/item?id=35627167</a></p>
<p>Points: 18</p>
<p># Comments: 6</p>

## Making a Linux home server sleep on idle and wake on demand – the simple way
 - [https://dgross.ca/blog/linux-home-server-auto-sleep/](https://dgross.ca/blog/linux-home-server-auto-sleep/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 12:05:50+00:00

<p>Article URL: <a href="https://dgross.ca/blog/linux-home-server-auto-sleep/">https://dgross.ca/blog/linux-home-server-auto-sleep/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35627107">https://news.ycombinator.com/item?id=35627107</a></p>
<p>Points: 83</p>
<p># Comments: 31</p>

## The secret list of websites that make AI chatbots sound smart
 - [https://www.washingtonpost.com/technology/interactive/2023/ai-chatbot-learning/](https://www.washingtonpost.com/technology/interactive/2023/ai-chatbot-learning/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 12:05:12+00:00

<p>Article URL: <a href="https://www.washingtonpost.com/technology/interactive/2023/ai-chatbot-learning/">https://www.washingtonpost.com/technology/interactive/2023/ai-chatbot-learning/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35627102">https://news.ycombinator.com/item?id=35627102</a></p>
<p>Points: 25</p>
<p># Comments: 20</p>

## In 1930, the 22M-pound Indiana Bell building was rotated 90 degrees
 - [https://mastodon.social/@Miriamm/110221714996508234](https://mastodon.social/@Miriamm/110221714996508234)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 11:52:15+00:00

<p>Article URL: <a href="https://mastodon.social/@Miriamm/110221714996508234">https://mastodon.social/@Miriamm/110221714996508234</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35627005">https://news.ycombinator.com/item?id=35627005</a></p>
<p>Points: 13</p>
<p># Comments: 2</p>

## Gezellig – a word that encompasses the heart of Dutch Culture
 - [https://www.dutchamsterdam.nl/155-gezellig](https://www.dutchamsterdam.nl/155-gezellig)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 11:15:02+00:00

<p>Article URL: <a href="https://www.dutchamsterdam.nl/155-gezellig">https://www.dutchamsterdam.nl/155-gezellig</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35626783">https://news.ycombinator.com/item?id=35626783</a></p>
<p>Points: 31</p>
<p># Comments: 26</p>

## Why Some Researchers Think I’m Wrong About Social Media and Mental Illness
 - [https://jonathanhaidt.substack.com/p/why-some-researchers-think-im-wrong](https://jonathanhaidt.substack.com/p/why-some-researchers-think-im-wrong)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 11:11:32+00:00

<p>Article URL: <a href="https://jonathanhaidt.substack.com/p/why-some-researchers-think-im-wrong">https://jonathanhaidt.substack.com/p/why-some-researchers-think-im-wrong</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35626755">https://news.ycombinator.com/item?id=35626755</a></p>
<p>Points: 120</p>
<p># Comments: 141</p>

## ChatPDF – Chat with Any PDF
 - [https://www.chatpdf.com](https://www.chatpdf.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 09:59:41+00:00

<p>Article URL: <a href="https://www.chatpdf.com">https://www.chatpdf.com</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35626312">https://news.ycombinator.com/item?id=35626312</a></p>
<p>Points: 8</p>
<p># Comments: 2</p>

## The iPhone Setting Thieves Use to Lock You Out of Your Apple Account
 - [https://www.wsj.com/articles/the-iphone-setting-thieves-use-to-lock-you-out-of-your-apple-account-716d350d](https://www.wsj.com/articles/the-iphone-setting-thieves-use-to-lock-you-out-of-your-apple-account-716d350d)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 09:41:25+00:00

<p>Article URL: <a href="https://www.wsj.com/articles/the-iphone-setting-thieves-use-to-lock-you-out-of-your-apple-account-716d350d">https://www.wsj.com/articles/the-iphone-setting-thieves-use-to-lock-you-out-of-your-apple-account-716d350d</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35626214">https://news.ycombinator.com/item?id=35626214</a></p>
<p>Points: 4</p>
<p># Comments: 1</p>

## Offline Is Just Online with Extreme Latency
 - [https://blog.jim-nielsen.com/2023/offline-is-online-with-extreme-latency/](https://blog.jim-nielsen.com/2023/offline-is-online-with-extreme-latency/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 09:09:07+00:00

<p>Article URL: <a href="https://blog.jim-nielsen.com/2023/offline-is-online-with-extreme-latency/">https://blog.jim-nielsen.com/2023/offline-is-online-with-extreme-latency/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35626015">https://news.ycombinator.com/item?id=35626015</a></p>
<p>Points: 5</p>
<p># Comments: 1</p>

## Origin Of The Abbreviation I18n: Jan Scherpenhuizen => S12n @ DEC (2002)
 - [http://www.i18nguy.com/origini18n.html](http://www.i18nguy.com/origini18n.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 09:07:24+00:00

<p>Article URL: <a href="http://www.i18nguy.com/origini18n.html">http://www.i18nguy.com/origini18n.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35626005">https://news.ycombinator.com/item?id=35626005</a></p>
<p>Points: 12</p>
<p># Comments: 3</p>

## How to Make Good Small Games
 - [http://farawaytimes.blogspot.com/2023/02/how-to-make-good-small-games.html](http://farawaytimes.blogspot.com/2023/02/how-to-make-good-small-games.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 07:54:46+00:00

<p>Article URL: <a href="http://farawaytimes.blogspot.com/2023/02/how-to-make-good-small-games.html">http://farawaytimes.blogspot.com/2023/02/how-to-make-good-small-games.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35625543">https://news.ycombinator.com/item?id=35625543</a></p>
<p>Points: 31</p>
<p># Comments: 4</p>

## Yubico is merging with ACQ Bure and intends to go public
 - [https://www.yubico.com/blog/yubico-is-merging-with-acq-bure/](https://www.yubico.com/blog/yubico-is-merging-with-acq-bure/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 06:49:34+00:00

<p>Article URL: <a href="https://www.yubico.com/blog/yubico-is-merging-with-acq-bure/">https://www.yubico.com/blog/yubico-is-merging-with-acq-bure/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35625065">https://news.ycombinator.com/item?id=35625065</a></p>
<p>Points: 62</p>
<p># Comments: 48</p>

## Defining interfaces in C++ with ‘concepts’ (C++20)
 - [https://lemire.me/blog/2023/04/18/defining-interfaces-in-c-with-concepts-c20/](https://lemire.me/blog/2023/04/18/defining-interfaces-in-c-with-concepts-c20/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 06:26:27+00:00

<p>Article URL: <a href="https://lemire.me/blog/2023/04/18/defining-interfaces-in-c-with-concepts-c20/">https://lemire.me/blog/2023/04/18/defining-interfaces-in-c-with-concepts-c20/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35624899">https://news.ycombinator.com/item?id=35624899</a></p>
<p>Points: 29</p>
<p># Comments: 24</p>

## Align Your Latents: High-Resolution Video Synthesis with Latent Diffusion Models
 - [https://research.nvidia.com/labs/toronto-ai/VideoLDM/](https://research.nvidia.com/labs/toronto-ai/VideoLDM/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 05:22:50+00:00

<p>Article URL: <a href="https://research.nvidia.com/labs/toronto-ai/VideoLDM/">https://research.nvidia.com/labs/toronto-ai/VideoLDM/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35624544">https://news.ycombinator.com/item?id=35624544</a></p>
<p>Points: 14</p>
<p># Comments: 2</p>

## Show HN: Kinde – auth, feature flags and billing (Q3) in one integration
 - [https://kinde.com/](https://kinde.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 04:41:14+00:00

<p>Article URL: <a href="https://kinde.com/">https://kinde.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35624300">https://news.ycombinator.com/item?id=35624300</a></p>
<p>Points: 8</p>
<p># Comments: 3</p>

## Nintendo Hacker Freed, Now Owes Them 25-30% of Salary for Life
 - [https://www.dexerto.com/tech/nintendo-hacker-forced-to-pay-them-for-life-after-being-released-from-prison-2117382/](https://www.dexerto.com/tech/nintendo-hacker-forced-to-pay-them-for-life-after-being-released-from-prison-2117382/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 04:22:17+00:00

<p>Article URL: <a href="https://www.dexerto.com/tech/nintendo-hacker-forced-to-pay-them-for-life-after-being-released-from-prison-2117382/">https://www.dexerto.com/tech/nintendo-hacker-forced-to-pay-them-for-life-after-being-released-from-prison-2117382/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35624210">https://news.ycombinator.com/item?id=35624210</a></p>
<p>Points: 22</p>
<p># Comments: 11</p>

## Understanding Everything
 - [https://shimmeringvoid.substack.com/p/understanding-everything](https://shimmeringvoid.substack.com/p/understanding-everything)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 03:21:15+00:00

<p>Article URL: <a href="https://shimmeringvoid.substack.com/p/understanding-everything">https://shimmeringvoid.substack.com/p/understanding-everything</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35623891">https://news.ycombinator.com/item?id=35623891</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## Raspberry Pi Receives Strategic Investment from Sony Semiconductor Solutions
 - [https://www.sony.co.uk/presscentre/news/raspberry-pi-receives-strategic-investment-from-sony-semiconductor-solutions-corporation](https://www.sony.co.uk/presscentre/news/raspberry-pi-receives-strategic-investment-from-sony-semiconductor-solutions-corporation)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 03:02:32+00:00

<p>Article URL: <a href="https://www.sony.co.uk/presscentre/news/raspberry-pi-receives-strategic-investment-from-sony-semiconductor-solutions-corporation">https://www.sony.co.uk/presscentre/news/raspberry-pi-receives-strategic-investment-from-sony-semiconductor-solutions-corporation</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35623783">https://news.ycombinator.com/item?id=35623783</a></p>
<p>Points: 27</p>
<p># Comments: 6</p>

## Why did Prolog lose steam? (2010)
 - [https://www.kmjn.org/notes/prolog_lost_steam.html](https://www.kmjn.org/notes/prolog_lost_steam.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 02:37:52+00:00

<p>Article URL: <a href="https://www.kmjn.org/notes/prolog_lost_steam.html">https://www.kmjn.org/notes/prolog_lost_steam.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35623625">https://news.ycombinator.com/item?id=35623625</a></p>
<p>Points: 22</p>
<p># Comments: 9</p>

## The Age of the Crisis of Work
 - [https://harpers.org/archive/2023/05/the-age-of-the-crisis-of-work-quiet-quitting-great-resignation/](https://harpers.org/archive/2023/05/the-age-of-the-crisis-of-work-quiet-quitting-great-resignation/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 02:04:46+00:00

<p>Article URL: <a href="https://harpers.org/archive/2023/05/the-age-of-the-crisis-of-work-quiet-quitting-great-resignation/">https://harpers.org/archive/2023/05/the-age-of-the-crisis-of-work-quiet-quitting-great-resignation/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35623366">https://news.ycombinator.com/item?id=35623366</a></p>
<p>Points: 11</p>
<p># Comments: 1</p>

## Explore Washington DC through the eyes of a spy – an IRL scavenger hunt
 - [https://secretmissiondc.com/](https://secretmissiondc.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 02:03:28+00:00

<p>Article URL: <a href="https://secretmissiondc.com/">https://secretmissiondc.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35623361">https://news.ycombinator.com/item?id=35623361</a></p>
<p>Points: 17</p>
<p># Comments: 7</p>

## Google search partial outage while rolling out new search?
 - [https://news.ycombinator.com/item?id=35622847](https://news.ycombinator.com/item?id=35622847)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 01:03:45+00:00

<p>Currently performing searches. Sometimes doesn't work at all. Searches now seem to display cards when it works properly instead of urls with text.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35622847">https://news.ycombinator.com/item?id=35622847</a></p>
<p>Points: 73</p>
<p># Comments: 27</p>

## Meta to unveil fresh round of job cuts among highly skilled staff
 - [https://www.washingtonpost.com/technology/2023/04/18/meta-layoffs-tech/](https://www.washingtonpost.com/technology/2023/04/18/meta-layoffs-tech/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 00:54:43+00:00

<p>Article URL: <a href="https://www.washingtonpost.com/technology/2023/04/18/meta-layoffs-tech/">https://www.washingtonpost.com/technology/2023/04/18/meta-layoffs-tech/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35622761">https://news.ycombinator.com/item?id=35622761</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## Orb weaver spider glue properties evolve faster than their glue genes
 - [https://phys.org/news/2023-04-orb-weaver-spider-properties-evolve.html](https://phys.org/news/2023-04-orb-weaver-spider-properties-evolve.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 00:39:14+00:00

<p>Article URL: <a href="https://phys.org/news/2023-04-orb-weaver-spider-properties-evolve.html">https://phys.org/news/2023-04-orb-weaver-spider-properties-evolve.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35622629">https://news.ycombinator.com/item?id=35622629</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## Firefly – A new compiler and runtime for BEAM languages
 - [https://github.com/GetFirefly/firefly](https://github.com/GetFirefly/firefly)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-19 00:38:40+00:00

<p>Article URL: <a href="https://github.com/GetFirefly/firefly">https://github.com/GetFirefly/firefly</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35622622">https://news.ycombinator.com/item?id=35622622</a></p>
<p>Points: 16</p>
<p># Comments: 4</p>

