# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## Why Do We Choke On Our Spit?
 - [https://www.youtube.com/watch?v=pEDlFb-LNYk](https://www.youtube.com/watch?v=pEDlFb-LNYk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2023-04-19 22:18:49+00:00

Visit https://brilliant.org/scishow/ to get started learning STEM for free. The first 200 people will get 20% off their annual premium subscription and a 30-day free trial.

When's the last time you choked on your own spit? Probably pretty recently, right? As it turns out, the reason we are so prone to coughing fits over nothing has a lot more to do with human evolution than you might think, and the features in our throats that let us embarrass ourselves during a big speech also set us apart from all the other apes out there!

Hosted by: Savannah Geary (They/Them)
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever: Matt Curls, Alisa Sherbow, Dr. Melvin Sanicas, Harrison Mills, Adam Brainard, Chris Peters, charles george, Piya Shedden, Alex Hackman, Christopher R, Boucher, Jeffrey Mckishen, Ash, Silas Emrys, Eric Jensen, Kevin Bealer, Jason A Saslow, Tom Mosner, Tomás Lagos González, Jacob, Christoph Schwanke, Sam Lutfi, Bryan Cloer
----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents Podcast: https://scishow-tangents.simplecast.com/
TikTok: https://www.tiktok.com/@scishow 
Twitter: http://www.twitter.com/scishow
Instagram: http://instagram.com/thescishowFacebook: http://www.facebook.com/scishow

#SciShow #science #education #learning #complexly
----------
Sources:
https://www.science.org/doi/abs/10.1126/science.abm1574 https://www.sciencedirect.com/science/article/pii/004724849090003T https://www.sciencedirect.com/science/article/pii/S0047248406000546 https://www.sciencedirect.com/science/article/pii/004724849290046C https://www.youtube.com/watch?v=YQm5RCz9Pxchttps://sci-hub.ru/
https://sci-hub.ru/https://doi.org/10.1016/B978-0-12-374593-4.00034-6

Image Sources:
https://www.frontiersin.org/files/Articles/452213/fnins-13-00558-HTML/image_m/fnins-13-00558-g002.jpg
https://commons.wikimedia.org/wiki/File:The_Skulls_of_the_gorilla,chimpanzee_and_humans_-_Kaiwei_Zhang.jpg
https://www.gettyimages.com/detail/video/saudi-women-enjoying-weekend-leisure-stock-footage/1395471076?adppopup=true
https://www.gettyimages.com/detail/photo/xray-image-of-epiglottis-3d-rendering-illustration-royalty-free-image/1460840524?phrase=epiglottis&amp;adppopup=true
https://www.gettyimages.com/detail/video/portrait-of-attractive-man-watching-film-on-tv-at-night-stock-footage/1166012674?adppopup=true
https://www.gettyimages.com/detail/illustration/anatomy-of-the-mouth-and-tongue-medical-royalty-free-illustration/1141280498?phrase=throat%20anatomy&amp;adppopup=true
https://www.gettyimages.com/detail/video/self-confident-woman-driver-starting-coughing-holding-stock-footage/1419855790?adppopup=true
https://www.gettyimages.com/detail/video/young-man-putting-mayonaise-and-dipping-french-fries-stock-footage/1392584576?adppopup=true
https://www.gettyimages.com/detail/video/smiling-professional-mature-bald-bearded-man-video-stock-footage/1451386454?adppopup=true
https://www.gettyimages.com/detail/video/chimpanzees-stock-footage/183077550?adppopup=true
https://www.gettyimages.com/detail/illustration/seamless-green-field-planting-agriculture-royalty-free-illustration/1385204442?phrase=background%20texture&amp;adppopup=true
https://www.gettyimages.com/detail/photo/woman-with-thyroid-gland-problem-royalty-free-image/1354577409?phrase=throat&amp;adppopup=true
https://commons.wikimedia.org/wiki/File:Hyoid_in_throat.jpg
https://www.youtube.com/watch?v=vOzH8Cfagng

