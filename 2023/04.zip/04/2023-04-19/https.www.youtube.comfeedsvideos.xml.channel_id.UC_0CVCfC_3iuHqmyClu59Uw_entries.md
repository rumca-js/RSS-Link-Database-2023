# Source:ETA PRIME, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_0CVCfC_3iuHqmyClu59Uw, language:en-US

## The All-New Radeon 780M Is The Fastest iGPU Ever! RYZEN 9 7940HS RDNA3 APU Hands On
 - [https://www.youtube.com/watch?v=Yqrw9cGA6QU](https://www.youtube.com/watch?v=Yqrw9cGA6QU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_0CVCfC_3iuHqmyClu59Uw
 - date published: 2023-04-19 14:06:00+00:00

The all New AMD Ryzen 9 7940HS RDNA3 APU is crazy fast and in this video we test out the built in radeon 780M RDNA3 Based iGPU! 
The New AMD Ryzen RDNA3 APUs are amazing and the new Radeon 780M Is the most Powerful iGPU On the market right now! Integrated graphics have never been so good!
In this video, we run some benchmarks and test out some AAA PC games using the new AMD RYZEN 9 7940HS Phoenix Point APU using only the built-in Radeon 780M RDNA3 based iGPU with 12CUs at 2800MHz and 56000MHz DDR5 Ram! It rocks at 1080P these new RDNA3 APUs are going to change the game for Mini PCs and thin laptops! 

We used the 2023 ASUS TUF A15 Ryzen 9 7940HS With RTX 4060 graphics disabled laptop for these tests: https://amzn.to/3KR7m5t

Follow Me On Twitter: https://twitter.com/theetaprime
Follow Me On Instagram: https://www.instagram.com/etaprime/

25% Code for software: ETA
Windows 10 Pro OEM Key($15): https://biitt.ly/KpEmf
Windows10 Home Key($14): https://biitt.ly/2tPi1
Windows 11 Pro Key($22): https://biitt.ly/RUZiX
Office 2019 pro key($49): https://biitt.ly/o0OQT

Equipment I Use:
Monitor: Pixio 277 Pro On Amazon: https://amzn.to/3PGUBwe
Elgato HD60 X Screen Capture Device: https://amzn.to/3GkP2AL
Tool Kit: https://amzn.to/3Wo8bpX
Camera: https://amzn.to/3XJfFoI

DISCLAIMER: This video and description contains affiliate links, which means that if you click on one of the product links, I’ll receive a small commission at no extra cost to you!
Under section 107 of the Copyright Act 1976, allowance is made for “fair use” for purposes such as criticism, comment, news reporting, teaching, scholarship, education, and research.
No Games Are Included Or Added

This video and Channel and Video are for viewers 14 years older and up. This video is not made for viewers under the age of 14. 

00:00 Introduction
00:26 Ryzen 9 7940HS laptop Overview
01:41 Ryzen 9 7940HS Specs
02:49 Ryzen 7940hs Radeon 780M TDP and Clocks
04:33 Ryzen  9 7940hs Radeon 780M Benchmarks
05:59 CSGO Ryzen 9 7940hs Radeon 780M
06:31 GTA5 Ryzen 9 7940hs Radeon 780M
06:57 Forza Horizon 5 Ryzen 9 7940hs Radeon 780M
07:24 Fortnite Ryzen 9 7940hs Radeon 780M
07:55 Doom Eternal Ryzen 9 7940hs Radeon 780M
08:19 Horizon Zero Dawn Ryzen 9 7940hs Radeon 780M
08:40 COD Moden Warfare 2 Ryzen 9 7940hs Radeon 780M
09:21 Cyberpunk 2077 Radeon 780M Overclocked 3000Mhz
10:00 Ryzen 9 7940hs Radeon 780M First Impressions

Want to send me something?
ETAPRIME 
12520 Capital Blvd Ste 401 Number 108
Wake Forest, NC 27587 US

THIS VIDEO IS FOR EDUCATIONAL PURPOSES ONLY!

#780M #Ryzen7940hs #7940hs #etaprime

