# Source:Wydarzenia Interia, URL:https://wydarzenia.interia.pl/feed, language:pl-PL

## Ukraińskie MSW opublikowało dane 56 tys. poległych żołnierzy rosyjskich
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukrainskie-msw-opublikowalo-dane-56-tys-poleglych-zolnierzy-,nId,6727490](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukrainskie-msw-opublikowalo-dane-56-tys-poleglych-zolnierzy-,nId,6727490)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 21:38:28+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukrainskie-msw-opublikowalo-dane-56-tys-poleglych-zolnierzy-,nId,6727490"><img align="left" alt="Ukraińskie MSW opublikowało dane 56 tys. poległych żołnierzy rosyjskich" src="https://i.iplsc.com/ukrainskie-msw-opublikowalo-dane-56-tys-poleglych-zolnierzy/000H1V3JYPM183SR-C321.jpg" /></a>MSW Ukrainy uruchomiło stronę internetową z danymi ponad 56 tys. rosyjskich żołnierzy, którzy zginęli w trakcie agresji na Ukrainę. Informacje pochodzą z publicznie dostępnych źródeł. Wiceminister spraw wewnętrznych tłumaczy, że celem stworzenia tej strony było pokazanie &quot;realnych strat przeciwnika&quot;. </p><br clear="all" />

## Wadowice: Radni zobowiązali burmistrza do pozwania autorów filmu o papieżu
 - [https://wydarzenia.interia.pl/malopolskie/news-wadowice-radni-zobowiazali-burmistrza-do-pozwania-autorow-fi,nId,6727466](https://wydarzenia.interia.pl/malopolskie/news-wadowice-radni-zobowiazali-burmistrza-do-pozwania-autorow-fi,nId,6727466)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 20:07:49+00:00

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-wadowice-radni-zobowiazali-burmistrza-do-pozwania-autorow-fi,nId,6727466"><img align="left" alt="Wadowice: Radni zobowiązali burmistrza do pozwania autorów filmu o papieżu" src="https://i.iplsc.com/wadowice-radni-zobowiazali-burmistrza-do-pozwania-autorow-fi/000H1UUYD7WWVNM8-C321.jpg" /></a>Burmistrz Wadowic Bartosz Kaliński został zobowiązany przez radnych do wystąpienia na drogę sądową przeciw autorom reportażu &quot;Franciszkańska 3&quot;. Uchwała w tej sprawie została przyjęta na środowej sesji. Zdaniem radnych materiał &quot;narusza kult pamięci&quot; o św. Janie Pawle II. </p><br clear="all" />

## Został uznany za zmarłego. 16-latek nagle wrócił do żywych
 - [https://wydarzenia.interia.pl/zagranica/news-zostal-uznany-za-zmarlego-16-latek-nagle-wrocil-do-zywych,nId,6727461](https://wydarzenia.interia.pl/zagranica/news-zostal-uznany-za-zmarlego-16-latek-nagle-wrocil-do-zywych,nId,6727461)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 19:45:30+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zostal-uznany-za-zmarlego-16-latek-nagle-wrocil-do-zywych,nId,6727461"><img align="left" alt="Został uznany za zmarłego. 16-latek nagle wrócił do żywych" src="https://i.iplsc.com/zostal-uznany-za-zmarlego-16-latek-nagle-wrocil-do-zywych/000H1UP81VB14H6F-C321.jpg" /></a>Nastolatek z Teksasu stracił przytomność na ściance wspinaczkowej. Po dwóch godzinach reanimacji lekarze stwierdzili zgon chłopca. Jednak po pięciu minutach od śmierci klinicznej 16-latek nagle odzyskał przytomność. &quot;To prawdziwy cud&quot; - ocenili medycy.</p><br clear="all" />

## Szczeniak żuł palec swojego właściciela. Połamał kość, ale uratował życie
 - [https://wydarzenia.interia.pl/zagranica/news-szczeniak-zul-palec-swojego-wlasciciela-polamal-kosc-ale-ura,nId,6727431](https://wydarzenia.interia.pl/zagranica/news-szczeniak-zul-palec-swojego-wlasciciela-polamal-kosc-ale-ura,nId,6727431)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 19:32:59+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-szczeniak-zul-palec-swojego-wlasciciela-polamal-kosc-ale-ura,nId,6727431"><img align="left" alt="Szczeniak żuł palec swojego właściciela. Połamał kość, ale uratował życie" src="https://i.iplsc.com/szczeniak-zul-palec-swojego-wlasciciela-polamal-kosc-ale-ura/000H1UNOF6KCYT8P-C321.jpg" /></a>Mężczyzna z Cambridge w Wielkiej Brytanii odpoczywał na kanapie w towarzystwie swojego psa, siedmiomiesięcznego bulldoga. Gdy zasnął, szczeniak zaczął bawić się jego dużym palcem od stopy. Żuł go tak mocno, aż doszło do złamania. Właściciel czworonoga trafił do szpitala, gdzie okazało się, że z powodu zatoru tętniczego tracił czucie w stopie. </p><br clear="all" />

## Potężna eksplozja w Sędzińcu. Zmiotło pół budynku
 - [https://wydarzenia.interia.pl/wielkopolskie/news-potezna-eksplozja-w-sedzincu-zmiotlo-pol-budynku,nId,6727450](https://wydarzenia.interia.pl/wielkopolskie/news-potezna-eksplozja-w-sedzincu-zmiotlo-pol-budynku,nId,6727450)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 19:06:53+00:00

<p><a href="https://wydarzenia.interia.pl/wielkopolskie/news-potezna-eksplozja-w-sedzincu-zmiotlo-pol-budynku,nId,6727450"><img align="left" alt="Potężna eksplozja w Sędzińcu. Zmiotło pół budynku" src="https://i.iplsc.com/potezna-eksplozja-w-sedzincu-zmiotlo-pol-budynku/000H1UNQHV0BL2G6-C321.jpg" /></a>Niebezpieczne zdarzenie w miejscowości Sędziniec. Jak informują służby, doszło tam do eksplozji gazu w budynku mieszkalnym. Są informacje o osobach poszkodowanych.</p><br clear="all" />

## Niezwykłe odkrycie w Starachowicach. Miecz i grot sprzed 2000 lat
 - [https://wydarzenia.interia.pl/swietokrzyskie/news-niezwykle-odkrycie-w-starachowicach-miecz-i-grot-sprzed-2000,nId,6727427](https://wydarzenia.interia.pl/swietokrzyskie/news-niezwykle-odkrycie-w-starachowicach-miecz-i-grot-sprzed-2000,nId,6727427)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 18:39:20+00:00

<p><a href="https://wydarzenia.interia.pl/swietokrzyskie/news-niezwykle-odkrycie-w-starachowicach-miecz-i-grot-sprzed-2000,nId,6727427"><img align="left" alt="Niezwykłe odkrycie w Starachowicach. Miecz i grot sprzed 2000 lat" src="https://i.iplsc.com/niezwykle-odkrycie-w-starachowicach-miecz-i-grot-sprzed-2000/000H1UFXW1DT0JP1-C321.jpg" /></a>Na terenie Nadleśnictwa Starachowice miłośnicy historii dokonali nietypowego odkrycia. Poszukiwacze natknęli się w lesie na wczesnośredniowieczny miecz i grot sprzed dwóch tysięcy lat. &quot;To kolejne tego typu odkrycie na tym terenie&quot; - poinformowali leśnicy.</p><br clear="all" />

## Awantura w samolocie. "Uspokój dziecko! Chcesz, żebym ja też krzyczał?"
 - [https://wydarzenia.interia.pl/zagranica/news-awantura-w-samolocie-uspokoj-dziecko-chcesz-zebym-ja-tez-krz,nId,6727191](https://wydarzenia.interia.pl/zagranica/news-awantura-w-samolocie-uspokoj-dziecko-chcesz-zebym-ja-tez-krz,nId,6727191)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 18:32:30+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-awantura-w-samolocie-uspokoj-dziecko-chcesz-zebym-ja-tez-krz,nId,6727191"><img align="left" alt="Awantura w samolocie. &quot;Uspokój dziecko! Chcesz, żebym ja też krzyczał?&quot;" src="https://i.iplsc.com/awantura-w-samolocie-uspokoj-dziecko-chcesz-zebym-ja-tez-krz/000H1TOZ1U9NKWVM-C321.jpg" /></a>Z powodu płaczącego dziecka jeden z pasażerów samolotu krzyczał i ubliżał rodzicom dziecka i obsłudze lotu. Sytuację nagrał podróżny, który siedział blisko awanturującego się mężczyzny. </p><br clear="all" />

## Szefowa MSZ Niemiec Annalena Baerbock o wizycie w Chinach: To bardziej niż szokujące
 - [https://wydarzenia.interia.pl/zagranica/news-szefowa-msz-niemiec-annalena-baerbock-o-wizycie-w-chinach-to,nId,6727410](https://wydarzenia.interia.pl/zagranica/news-szefowa-msz-niemiec-annalena-baerbock-o-wizycie-w-chinach-to,nId,6727410)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 18:18:12+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-szefowa-msz-niemiec-annalena-baerbock-o-wizycie-w-chinach-to,nId,6727410"><img align="left" alt="Szefowa MSZ Niemiec Annalena Baerbock o wizycie w Chinach: To bardziej niż szokujące" src="https://i.iplsc.com/szefowa-msz-niemiec-annalena-baerbock-o-wizycie-w-chinach-to/000H1UF77X3MWNM7-C321.jpg" /></a>- To było częściowo naprawdę bardziej niż szokujące - tak minister spraw zagranicznych Niemiec Annalena Baerbock oceniła swoje wrażenia z wizyty w Chinach i to jak &quot;ofensywnie&quot; i &quot;coraz bardziej agresywnie&quot; Chiny zachowują się w stosunku do innych krajów.</p><br clear="all" />

## Deklaracja Adama Niedzielskiego. Chodzi o stan zagrożenia epidemicznego
 - [https://wydarzenia.interia.pl/raport-koronawirus-chiny/news-deklaracja-adama-niedzielskiego-chodzi-o-stan-zagrozenia-epi,nId,6727418](https://wydarzenia.interia.pl/raport-koronawirus-chiny/news-deklaracja-adama-niedzielskiego-chodzi-o-stan-zagrozenia-epi,nId,6727418)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 18:04:04+00:00

<p><a href="https://wydarzenia.interia.pl/raport-koronawirus-chiny/news-deklaracja-adama-niedzielskiego-chodzi-o-stan-zagrozenia-epi,nId,6727418"><img align="left" alt="Deklaracja Adama Niedzielskiego. Chodzi o stan zagrożenia epidemicznego" src="https://i.iplsc.com/deklaracja-adama-niedzielskiego-chodzi-o-stan-zagrozenia-epi/000AOSFTSXANGA2F-C321.jpg" /></a>Jest zapowiedź ministra zdrowia Adama Nedzielskiego w sprawe stanu epidemicznego w Polsce, który obowiązuje od początku epidemii koronawirusa. Jak podkreślił polityk, jest wstępna data zniesiena obowiązywania tego stanu. Jednocześnie minister Niedzielski przyznał, że resort &quot;przymierza się&quot; do zakończenia obowiązku noszenia maseczek w aptekach.</p><br clear="all" />

## Nowatorskie rozwiązanie w Polsce. WizzAir wprowadza abonament na loty
 - [https://wydarzenia.interia.pl/kraj/news-nowatorskie-rozwiazanie-w-polsce-wizzair-wprowadza-abonament,nId,6727375](https://wydarzenia.interia.pl/kraj/news-nowatorskie-rozwiazanie-w-polsce-wizzair-wprowadza-abonament,nId,6727375)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 17:45:40+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-nowatorskie-rozwiazanie-w-polsce-wizzair-wprowadza-abonament,nId,6727375"><img align="left" alt="Nowatorskie rozwiązanie w Polsce. WizzAir wprowadza abonament na loty" src="https://i.iplsc.com/nowatorskie-rozwiazanie-w-polsce-wizzair-wprowadza-abonament/000H1UAAXTEIB4LO-C321.jpg" /></a>Pasażerów czeka rewolucja. Linia lotnicza WizzAir zapowiedziała wprowadzenie rozwiązania znanego m.in. z platform streamingowych. Od maja możliwe będzie wykupienie abonamentu na loty. Polska weźmie udział w pilotażu tego programu. Subskrypcja ma ułatwić podróże osobom, które często latają z jednego miasta. </p><br clear="all" />

## Kontrowersyjny ksiądz grzmi z ambony. Zaatakował ludzi z tatuażami
 - [https://wydarzenia.interia.pl/kraj/news-kontrowersyjny-ksiadz-grzmi-z-ambony-zaatakowal-ludzi-z-tatu,nId,6727381](https://wydarzenia.interia.pl/kraj/news-kontrowersyjny-ksiadz-grzmi-z-ambony-zaatakowal-ludzi-z-tatu,nId,6727381)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 17:29:55+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-kontrowersyjny-ksiadz-grzmi-z-ambony-zaatakowal-ludzi-z-tatu,nId,6727381"><img align="left" alt="Kontrowersyjny ksiądz grzmi z ambony. Zaatakował ludzi z tatuażami" src="https://i.iplsc.com/kontrowersyjny-ksiadz-grzmi-z-ambony-zaatakowal-ludzi-z-tatu/000H1U3RYE6OWIVV-C321.jpg" /></a>Ksiądz Michał Woźnicki zaatakował z ambony policjantów, których spotkał ostatnio w budynku sądu. Kontrowersyjny duchowny podczas kazania skrytykował także ludzi z tatuażami i kolczykami. - To wstęp do samookaleczania się. Chcą nas oswoić ze złą praktyką - ocenił.</p><br clear="all" />

## Winda spadła na pracowników w markecie. Jest ofiara śmiertelna
 - [https://wydarzenia.interia.pl/mazowieckie/news-winda-spadla-na-pracownikow-w-markecie-jest-ofiara-smierteln,nId,6727385](https://wydarzenia.interia.pl/mazowieckie/news-winda-spadla-na-pracownikow-w-markecie-jest-ofiara-smierteln,nId,6727385)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 16:51:16+00:00

<p><a href="https://wydarzenia.interia.pl/mazowieckie/news-winda-spadla-na-pracownikow-w-markecie-jest-ofiara-smierteln,nId,6727385"><img align="left" alt="Winda spadła na pracowników w markecie. Jest ofiara śmiertelna" src="https://i.iplsc.com/winda-spadla-na-pracownikow-w-markecie-jest-ofiara-smierteln/000H1U4LKEDM183Q-C321.jpg" /></a>Nie żyje pracownik marketu budowlanego w Sierpcu, który został przygnieciony przez windę. Urządzenie oberwało się na głowy dwóch mężczyzn znajdujących się w szybie. Dochodzenie na miejscu wszczęła policja pod nadzorem prokuratury.</p><br clear="all" />

## Niemiec rzucił się z nożem na Polaka. Strażnik miejski usłyszał zarzuty
 - [https://wydarzenia.interia.pl/zagranica/news-niemiec-rzucil-sie-z-nozem-na-polaka-straznik-miejski-uslysz,nId,6727203](https://wydarzenia.interia.pl/zagranica/news-niemiec-rzucil-sie-z-nozem-na-polaka-straznik-miejski-uslysz,nId,6727203)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 16:48:50+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niemiec-rzucil-sie-z-nozem-na-polaka-straznik-miejski-uslysz,nId,6727203"><img align="left" alt="Niemiec rzucił się z nożem na Polaka. Strażnik miejski usłyszał zarzuty" src="https://i.iplsc.com/niemiec-rzucil-sie-z-nozem-na-polaka-straznik-miejski-uslysz/000H1TP97GMT7J6A-C321.jpg" /></a>36-letni Polak został zaatakowany nożem przez strażnika miejskiego w Szlezwiku-Holsztynie. Funkcjonariusz publiczny został błyskawicznie ujęty przez policję federalną. 64-letni Niemiec usłyszał zarzut usiłowania ciężkiego uszkodzenia ciała.</p><br clear="all" />

## Policja podatkowa weszła do siedziby firmy Gucci. Trwa unijne dochodzenie
 - [https://wydarzenia.interia.pl/zagranica/news-policja-podatkowa-weszla-do-siedziby-firmy-gucci-trwa-unijne,nId,6727209](https://wydarzenia.interia.pl/zagranica/news-policja-podatkowa-weszla-do-siedziby-firmy-gucci-trwa-unijne,nId,6727209)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 16:24:29+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-policja-podatkowa-weszla-do-siedziby-firmy-gucci-trwa-unijne,nId,6727209"><img align="left" alt="Policja podatkowa weszła do siedziby firmy Gucci. Trwa unijne dochodzenie" src="https://i.iplsc.com/policja-podatkowa-weszla-do-siedziby-firmy-gucci-trwa-unijne/000H1U01K2KQ2228-C321.jpg" /></a>Niezapowiedziana kontrola miała miejsce w siedzibie Gucci w Mediolanie. Do budynku, w ramach dochodzenia prowadzonego przez Unię Europejską, weszła policja podatkowa. </p><br clear="all" />

## Dziewięć w cenie trzech. Sprawdź, jak wydłużyć urlop na majówkę
 - [https://wydarzenia.interia.pl/kraj/news-dziewiec-w-cenie-trzech-sprawdz-jak-wydluzyc-urlop-na-majowk,nId,6717193](https://wydarzenia.interia.pl/kraj/news-dziewiec-w-cenie-trzech-sprawdz-jak-wydluzyc-urlop-na-majowk,nId,6717193)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 16:00:31+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-dziewiec-w-cenie-trzech-sprawdz-jak-wydluzyc-urlop-na-majowk,nId,6717193"><img align="left" alt="Dziewięć w cenie trzech. Sprawdź, jak wydłużyć urlop na majówkę" src="https://i.iplsc.com/dziewiec-w-cenie-trzech-sprawdz-jak-wydluzyc-urlop-na-majowk/000H1T9HRH3224FQ-C321.jpg" /></a>Majówka to może być wyjątkowo długi weekend, który warto maksymalnie wykorzystać, biorąc dodatkowe dni wolne. By możliwie najpełniej wykorzystać okazję do przerwy od pracy, wystarczy wziąć trzy dni wolnego i odpoczywać przez prawie półtora tygodnia. Sprawdź, kiedy wziąć urlop na majówkę, by maksymalnie przedłużyć wypoczynek.</p><br clear="all" />

## Walenie zaatakowane przez gromadę orek. "Pierwszy raz od 30 lat"
 - [https://wydarzenia.interia.pl/zagranica/news-walenie-zaatakowane-przez-gromade-orek-pierwszy-raz-od-30-la,nId,6727178](https://wydarzenia.interia.pl/zagranica/news-walenie-zaatakowane-przez-gromade-orek-pierwszy-raz-od-30-la,nId,6727178)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 15:55:40+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-walenie-zaatakowane-przez-gromade-orek-pierwszy-raz-od-30-la,nId,6727178"><img align="left" alt="Walenie zaatakowane przez gromadę orek. &quot;Pierwszy raz od 30 lat&quot; " src="https://i.iplsc.com/walenie-zaatakowane-przez-gromade-orek-pierwszy-raz-od-30-la/000H1TORMUGMVK7A-C321.jpg" /></a>Dwa walenie zostały zaatakowane przez gromadę orek. Moment ataku zarejestrowała kamera umieszczona na dronie. Nagranie zostało opublikowane w mediach społecznościowych firmy, która zajmuje się obserwacją morskich zwierząt. Zdaniem ekspertów przypadek, w którym orki atakują pływacze szare, to pierwszy taki w tym miejscu od 30 lat. </p><br clear="all" />

## Rolnikowi zarekwirowano zaniedbane bydło. "Trzeba było uśpić pięć sztuk"
 - [https://wydarzenia.interia.pl/zagranica/news-rolnikowi-zarekwirowano-zaniedbane-bydlo-trzeba-bylo-uspic-p,nId,6727137](https://wydarzenia.interia.pl/zagranica/news-rolnikowi-zarekwirowano-zaniedbane-bydlo-trzeba-bylo-uspic-p,nId,6727137)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 15:18:55+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-rolnikowi-zarekwirowano-zaniedbane-bydlo-trzeba-bylo-uspic-p,nId,6727137"><img align="left" alt="Rolnikowi zarekwirowano zaniedbane bydło. &quot;Trzeba było uśpić pięć sztuk&quot;" src="https://i.iplsc.com/rolnikowi-zarekwirowano-zaniedbane-bydlo-trzeba-bylo-uspic-p/000H1TDYHLL76D97-C321.jpg" /></a>128 sztuk zaniedbanego bydła zabrano holenderskiemu hodowcy. Jak przekazały służby, zwierzęta były w tak złym stanie, że weterynarz musiał uśpić pięć sztuk bydła na miejscu. Policja aresztowała rolnika, ponieważ opluł i groził inspektorowi.</p><br clear="all" />

## Polka od lat znęcała się nad mężem. Mężczyzna zgłosił się na policję
 - [https://wydarzenia.interia.pl/zagranica/news-polka-od-lat-znecala-sie-nad-mezem-mezczyzna-zglosil-sie-na-,nId,6727165](https://wydarzenia.interia.pl/zagranica/news-polka-od-lat-znecala-sie-nad-mezem-mezczyzna-zglosil-sie-na-,nId,6727165)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 14:51:40+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-polka-od-lat-znecala-sie-nad-mezem-mezczyzna-zglosil-sie-na-,nId,6727165"><img align="left" alt="Polka od lat znęcała się nad mężem. Mężczyzna zgłosił się na policję" src="https://i.iplsc.com/polka-od-lat-znecala-sie-nad-mezem-mezczyzna-zglosil-sie-na/000H1TH2JNL4SNTA-C321.jpg" /></a>Włoska policja zatrzymała 53-letnią Polkę, która miała od dłuższego czasu znęcać się nad swoim partnerem. Mężczyzna opisał, że biła go na oczach sąsiadów i rzucała w niego przedmiotami. Kiedy wręczył jej kwiaty na Dzień Kobiet, pijana agresorka w odpowiedzi uderzyła go kijem w krocze.</p><br clear="all" />

## Zełenski na granicy z Polską i Białorusią. Trwa budowa fortyfikacji
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-na-granicy-z-polska-i-bialorusia-trwa-budowa-fortyf,nId,6727089](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-na-granicy-z-polska-i-bialorusia-trwa-budowa-fortyf,nId,6727089)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 14:17:30+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-na-granicy-z-polska-i-bialorusia-trwa-budowa-fortyf,nId,6727089"><img align="left" alt="Zełenski na granicy z Polską i Białorusią. Trwa budowa fortyfikacji" src="https://i.iplsc.com/zelenski-na-granicy-z-polska-i-bialorusia-trwa-budowa-fortyf/000H1SKTW4XCUB2B-C321.jpg" /></a>Prezydent Ukrainy Wołodymyr Zełenski pojawił się na Wołyniu, na granicy z Białorusią i Polską. Głowa ukraińskiego państwa odwiedziła strażników granicznych i podziękowała za ich służbę. Zełenski podczas wizyty roboczej zapoznał się z prowadzonymi na tym terenie działaniami, wręczył odznaczenia i uczcił pamięć poległych strażników.</p><br clear="all" />

## "Człowiek-Pająk" wspiął się na wieżowiec. "Marcon, czas zejść na ziemię"
 - [https://wydarzenia.interia.pl/zagranica/news-czlowiek-pajak-wspial-sie-na-wiezowiec-marcon-czas-zejsc-na-,nId,6727092](https://wydarzenia.interia.pl/zagranica/news-czlowiek-pajak-wspial-sie-na-wiezowiec-marcon-czas-zejsc-na-,nId,6727092)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 14:11:35+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-czlowiek-pajak-wspial-sie-na-wiezowiec-marcon-czas-zejsc-na-,nId,6727092"><img align="left" alt="&quot;Człowiek-Pająk&quot; wspiął się na wieżowiec. &quot;Marcon, czas zejść na ziemię&quot;" src="https://i.iplsc.com/czlowiek-pajak-wspial-sie-na-wiezowiec-marcon-czas-zejsc-na/000H1SH8FA88HTMO-C321.jpg" /></a>Słynny francuski wspinacz Alain Robert wdrapał się bez zabezpieczenia na 38-piętrowy budynek w Paryżu. W ten sposób przekazał Emmanuelowi Macronowi, by ten &quot;zszedł na ziemię&quot;. Chodzi o decyzję prezydenta Francji ws. podniesienia wieku emerytalnego nad Sekwaną.</p><br clear="all" />

## Wsiadła do samochodu 25-latka. Cheerleaderki postrzelone na parkingu
 - [https://wydarzenia.interia.pl/zagranica/news-wsiadla-do-samochodu-25-latka-cheerleaderki-postrzelone-na-p,nId,6727095](https://wydarzenia.interia.pl/zagranica/news-wsiadla-do-samochodu-25-latka-cheerleaderki-postrzelone-na-p,nId,6727095)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 13:44:35+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wsiadla-do-samochodu-25-latka-cheerleaderki-postrzelone-na-p,nId,6727095"><img align="left" alt="Wsiadła do samochodu 25-latka. Cheerleaderki postrzelone na parkingu" src="https://i.iplsc.com/wsiadla-do-samochodu-25-latka-cheerleaderki-postrzelone-na-p/000H1SKWLHMQRO5O-C321.jpg" /></a>Dwie cheerleaderki zostały postrzelone na parkingu w Teksasie. Do brutalnego incydentu doszło po tym, jak jedna z nich chciała przez pomyłkę wsiąść do niewłaściwego auta. Policja aresztowała w sprawie 25-letniego napastnika.</p><br clear="all" />

## W czwartek na niebie rzadkie zjawisko. Jak obejrzeć zaćmienie Słońca?
 - [https://wydarzenia.interia.pl/nauka/news-w-czwartek-na-niebie-rzadkie-zjawisko-jak-obejrzec-zacmienie,nId,6724465](https://wydarzenia.interia.pl/nauka/news-w-czwartek-na-niebie-rzadkie-zjawisko-jak-obejrzec-zacmienie,nId,6724465)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 13:30:49+00:00

<p><a href="https://wydarzenia.interia.pl/nauka/news-w-czwartek-na-niebie-rzadkie-zjawisko-jak-obejrzec-zacmienie,nId,6724465"><img align="left" alt="W czwartek na niebie rzadkie zjawisko. Jak obejrzeć zaćmienie Słońca?" src="https://i.iplsc.com/w-czwartek-na-niebie-rzadkie-zjawisko-jak-obejrzec-zacmienie/000H1JNP34B9E94Q-C321.jpg" /></a>Hybrydowe zaćmienie Słońca będzie można obserwować na niebie już w czwartek 20 kwietnia. Niestety nie z każdego miejsca na świecie będzie widoczne. To spora gratka dla fanów astronomii, bo w tym stuleciu takie zjawisko ma wystąpić siedem razy. Wyjaśniamy, czym jest hybrydowe zaćmienie Słońca, czy będzie widoczne z Polski i jak je obejrzeć.</p><br clear="all" />

## Sprawa Kamila z Częstochowy. Kolejna osoba z zarzutami
 - [https://wydarzenia.interia.pl/slaskie/news-sprawa-kamila-z-czestochowy-kolejna-osoba-z-zarzutami,nId,6727096](https://wydarzenia.interia.pl/slaskie/news-sprawa-kamila-z-czestochowy-kolejna-osoba-z-zarzutami,nId,6727096)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 13:26:03+00:00

<p><a href="https://wydarzenia.interia.pl/slaskie/news-sprawa-kamila-z-czestochowy-kolejna-osoba-z-zarzutami,nId,6727096"><img align="left" alt="Sprawa Kamila z Częstochowy. Kolejna osoba z zarzutami " src="https://i.iplsc.com/sprawa-kamila-z-czestochowy-kolejna-osoba-z-zarzutami/000H1SK26REMXVJ5-C321.jpg" /></a>Prokuratura postawiła w środę zarzut nieudzielenia pomocy wujkowi ośmioletniego Kamila, który z ciężkimi poparzeniami trafił do szpitala. Według śledczych chłopiec został skatowany przez ojczyma, a matka nie reagowała. Opiekunowie są w areszcie. </p><br clear="all" />

## Zamieszkał w szałasie. Od kilku miesięcy ukrywał się przed policją
 - [https://wydarzenia.interia.pl/lodzkie/news-zamieszkal-w-szalasie-od-kilku-miesiecy-ukrywal-sie-przed-po,nId,6727067](https://wydarzenia.interia.pl/lodzkie/news-zamieszkal-w-szalasie-od-kilku-miesiecy-ukrywal-sie-przed-po,nId,6727067)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 12:55:48+00:00

<p><a href="https://wydarzenia.interia.pl/lodzkie/news-zamieszkal-w-szalasie-od-kilku-miesiecy-ukrywal-sie-przed-po,nId,6727067"><img align="left" alt="Zamieszkał w szałasie. Od kilku miesięcy ukrywał się przed policją" src="https://i.iplsc.com/zamieszkal-w-szalasie-od-kilku-miesiecy-ukrywal-sie-przed-po/000H1SCAS0L1DQLU-C321.jpg" /></a>Poszukiwany listem gończym 44-latek miesiącami unikał zatrzymania. Jeden z tropów ostatecznie doprowadził policjantów z grupy poszukiwawczej do niewielkiego lasku znajdującego się na terenie jednej z łódzkich dzielnic. W prowizorycznym szałasie znaleźli śpiącego mężczyznę.</p><br clear="all" />

## Prognoza średnioterminowa na majówkę. Pogoda na południu kraju zaskoczy?
 - [https://wydarzenia.interia.pl/kraj/news-prognoza-srednioterminowa-na-majowke-pogoda-na-poludniu-kraj,nId,6726804](https://wydarzenia.interia.pl/kraj/news-prognoza-srednioterminowa-na-majowke-pogoda-na-poludniu-kraj,nId,6726804)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 12:49:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-prognoza-srednioterminowa-na-majowke-pogoda-na-poludniu-kraj,nId,6726804"><img align="left" alt="Prognoza średnioterminowa na majówkę. Pogoda na południu kraju zaskoczy?" src="https://i.iplsc.com/prognoza-srednioterminowa-na-majowke-pogoda-na-poludniu-kraj/00069COT5P94U0CP-C321.jpg" /></a>Długi weekend już za pasem, jaka będzie pogoda na majówkę? Sprawdzamy najnowsze prognozy synoptyków. Czy w długi weekend majowy możemy spodziewać się słońca i wysokich temperatur? A może w majówkę nadejdzie ulewny deszcz?</p><br clear="all" />

## USA: Troje dzieci trafiło do szpitala po zażyciu narkotyków. Myślały, że to cukierki
 - [https://wydarzenia.interia.pl/zagranica/news-usa-troje-dzieci-trafilo-do-szpitala-po-zazyciu-narkotykow-m,nId,6727029](https://wydarzenia.interia.pl/zagranica/news-usa-troje-dzieci-trafilo-do-szpitala-po-zazyciu-narkotykow-m,nId,6727029)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 12:46:18+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-usa-troje-dzieci-trafilo-do-szpitala-po-zazyciu-narkotykow-m,nId,6727029"><img align="left" alt="USA: Troje dzieci trafiło do szpitala po zażyciu narkotyków. Myślały, że to cukierki" src="https://i.iplsc.com/usa-troje-dzieci-trafilo-do-szpitala-po-zazyciu-narkotykow-m/000EE5QHPIIYE0WI-C321.jpg" /></a>Troje siedmiolatków znalazło w szkole pudełko z &quot;niebieskimi cukierkami&quot;. Po ich zjedzeniu dzieci miały zawroty głowy i trafiły do szpitala. Okazało się, że &quot;cukierki&quot; były tak naprawdę narkotykami. Policja prowadzi śledztwo w tej sprawie. </p><br clear="all" />

## Strach wśród rosyjskich propagandystów. Powodem przesyłka
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-strach-wsrod-rosyjskich-propagandystow-powodem-przesylka,nId,6727013](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-strach-wsrod-rosyjskich-propagandystow-powodem-przesylka,nId,6727013)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 12:33:59+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-strach-wsrod-rosyjskich-propagandystow-powodem-przesylka,nId,6727013"><img align="left" alt="Strach wśród rosyjskich propagandystów. Powodem przesyłka" src="https://i.iplsc.com/strach-wsrod-rosyjskich-propagandystow-powodem-przesylka/000H1S5LAKY74YIO-C321.jpg" /></a>Rosyjscy propagandyści i dziennikarze, zajmujący się wojskowością, zaczęli otrzymywać prezenty, które wywołały w ich szeregach panikę. Okazuje się, że w przesyłach znajdowały się popiersia, wyglądające dokładnie jak to, w którym umieszczono bombę, która zabiła blogera Władlena Tatarskiego. </p><br clear="all" />

## Zabity i rozpuszczony w kwasie "przez pomyłkę". Mafia zaproponowała odszkodowanie
 - [https://wydarzenia.interia.pl/zagranica/news-zabity-i-rozpuszczony-w-kwasie-przez-pomylke-mafia-zapropono,nId,6727032](https://wydarzenia.interia.pl/zagranica/news-zabity-i-rozpuszczony-w-kwasie-przez-pomylke-mafia-zapropono,nId,6727032)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 12:21:04+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zabity-i-rozpuszczony-w-kwasie-przez-pomylke-mafia-zapropono,nId,6727032"><img align="left" alt="Zabity i rozpuszczony w kwasie &quot;przez pomyłkę&quot;. Mafia zaproponowała odszkodowanie" src="https://i.iplsc.com/zabity-i-rozpuszczony-w-kwasie-przez-pomylke-mafia-zapropono/000H1S5YVVTH0IML-C321.jpg" /></a>Giulio Giaccio nie miał problemów z prawem, ani żadnych powiązań z neapolitańską mafią. Jego jedynym &quot;grzechem&quot; było podobieństwo do człowieka, z którym członkowie klanu Polverino postanowili &quot;wyrównać rachunki&quot;. 26-latek zginął od strzału w głowę, a jego zwłoki rozpuszczono w kwasie. Gdy po kilkudziesięciu latach podejrzani w sprawie stanęli przed wymiarem sprawiedliwości, złożyli rodzinie propozycję. Okazuje się, że nie była ona &quot;nie do odrzucenia&quot;.</p><br clear="all" />

## Niemcy: Strajki w całym kraju. Możliwy paraliż Berlina
 - [https://wydarzenia.interia.pl/zagranica/news-niemcy-strajki-w-calym-kraju-mozliwy-paraliz-berlina,nId,6726982](https://wydarzenia.interia.pl/zagranica/news-niemcy-strajki-w-calym-kraju-mozliwy-paraliz-berlina,nId,6726982)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 12:13:10+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niemcy-strajki-w-calym-kraju-mozliwy-paraliz-berlina,nId,6726982"><img align="left" alt="Niemcy: Strajki w całym kraju. Możliwy paraliż Berlina" src="https://i.iplsc.com/niemcy-strajki-w-calym-kraju-mozliwy-paraliz-berlina/000H1S4F1DRQETYB-C321.jpg" /></a>Cierpliwość niemieckich pasażerów znów zostanie wystawiona na próbę. Na piątek związki zawodowe zapowiadają strajki w całym kraju. Staną pociągi, ale nie tylko, bo pracę ma przerwać również personel na kilku lotniskach. Jakby tego było mało, w najbliższych dniach klimatyczni aktywiści z tzw. ostatniego pokolenia zapowiadają paraliż Berlina. W przyklejaniu się do asfaltu na wielu ulicach stolicy Niemiec ma wziąć nawet do 800 osób.</p><br clear="all" />

## Burza po ćwiczeniach służb w Poznaniu. "Terrorystka" w hidżabie
 - [https://wydarzenia.interia.pl/kraj/news-burza-po-cwiczeniach-sluzb-w-poznaniu-terrorystka-w-hidzabie,nId,6726912](https://wydarzenia.interia.pl/kraj/news-burza-po-cwiczeniach-sluzb-w-poznaniu-terrorystka-w-hidzabie,nId,6726912)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 11:48:22+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-burza-po-cwiczeniach-sluzb-w-poznaniu-terrorystka-w-hidzabie,nId,6726912"><img align="left" alt="Burza po ćwiczeniach służb w Poznaniu. &quot;Terrorystka&quot; w hidżabie " src="https://i.iplsc.com/burza-po-cwiczeniach-sluzb-w-poznaniu-terrorystka-w-hidzabie/000H1RTFA4MVK643-C321.jpg" /></a>Internet obiegają zdjęcia z ćwiczeń kontterrorystów pod kryptonimem &quot;Wolf-Ram-23&quot; w Poznaniu, gdzie testowano współpracę służb na wypadek zamachu. Chodzi o klęczącą na ziemi kobietę w hidżabie, z której oczu płyną &quot;czerwone łzy&quot;. Według policyjnego scenariusza &quot;trzyma ona w ręce zapalnik do ładunku wybuchowego i zachowuje się irracjonalnie, głośno krzycząc do ludzi w pobliżu&quot;. &quot;Kseno- i islamofobiczna natura scenariusza&quot; - komentują internauci. Policja odpowiada, że &quot;sytuacja w Poznaniu wiernie odtwarzała zamach dokonany w Turcji.&quot;</p><br clear="all" />

## Niemowlę ominęło zabezpieczenia Białego Domu. Służby w akcji
 - [https://wydarzenia.interia.pl/zagranica/news-niemowle-ominelo-zabezpieczenia-bialego-domu-sluzby-w-akcji,nId,6726956](https://wydarzenia.interia.pl/zagranica/news-niemowle-ominelo-zabezpieczenia-bialego-domu-sluzby-w-akcji,nId,6726956)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 11:03:35+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niemowle-ominelo-zabezpieczenia-bialego-domu-sluzby-w-akcji,nId,6726956"><img align="left" alt="Niemowlę ominęło zabezpieczenia Białego Domu. Służby w akcji" src="https://i.iplsc.com/niemowle-ominelo-zabezpieczenia-bialego-domu-sluzby-w-akcji/000H1RSHN0XS6FO4-C321.jpg" /></a>&quot;Najmniejszy intruz w Białym Domu&quot; - taki zaszczytny tytuł otrzymał mały chłopiec, który przecisnął się przez ogrodzenie otaczające rezydencję prezydenta USA. Ciekawski malec postawił na nogi agentów Secret Service, a dostęp do kompleksu musiał zostać tymczasowo ograniczony.</p><br clear="all" />

## Wypadek na wyciągu narciarskim. Policja szuka świadków
 - [https://wydarzenia.interia.pl/malopolskie/news-wypadek-na-wyciagu-narciarskim-policja-szuka-swiadkow,nId,6726910](https://wydarzenia.interia.pl/malopolskie/news-wypadek-na-wyciagu-narciarskim-policja-szuka-swiadkow,nId,6726910)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 11:00:47+00:00

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-wypadek-na-wyciagu-narciarskim-policja-szuka-swiadkow,nId,6726910"><img align="left" alt="Wypadek na wyciągu narciarskim. Policja szuka świadków" src="https://i.iplsc.com/wypadek-na-wyciagu-narciarskim-policja-szuka-swiadkow/000H1RQM5XCT7J4V-C321.jpg" /></a>Zakopiańska policja szuka świadków wypadku, do którego doszło na stacji narciarskiej &quot;Rusin-Ski&quot; w Bukowinie Tatrzańskiej. Siedmioletnia dziewczynka spadła tam z wyciągu krzesełkowego i doznała obrażeń. </p><br clear="all" />

## Zdobyła brązowy medal w maratonie. Na jaw wyszło oszustwo
 - [https://wydarzenia.interia.pl/zagranica/news-zdobyla-brazowy-medal-w-maratonie-na-jaw-wyszlo-oszustwo,nId,6726814](https://wydarzenia.interia.pl/zagranica/news-zdobyla-brazowy-medal-w-maratonie-na-jaw-wyszlo-oszustwo,nId,6726814)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 11:00:23+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zdobyla-brazowy-medal-w-maratonie-na-jaw-wyszlo-oszustwo,nId,6726814"><img align="left" alt="Zdobyła brązowy medal w maratonie. Na jaw wyszło oszustwo" src="https://i.iplsc.com/zdobyla-brazowy-medal-w-maratonie-na-jaw-wyszlo-oszustwo/000H1RCP73RP8Y73-C321.jpg" /></a>Jedna z uczestniczek maratonu, który miał miejsce w kwietniu w Wielkiej Brytanii, mogła cieszyć się trzecim miejscem i brązowym medalem. Nie trwało to zbyt długo, ponieważ uwagę przyciągnął czas, w jakim kobieta dotarła do mety. Okazało się, że część trasy pokonała samochodem, dzięki czemu zyskała około 25 minut.</p><br clear="all" />

## Amerykańskie technologie w Zaporożu. Waszyngton ostrzega Kreml
 - [https://wydarzenia.interia.pl/zagranica/news-amerykanskie-technologie-w-zaporozu-waszyngton-ostrzega-krem,nId,6726886](https://wydarzenia.interia.pl/zagranica/news-amerykanskie-technologie-w-zaporozu-waszyngton-ostrzega-krem,nId,6726886)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 10:50:56+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-amerykanskie-technologie-w-zaporozu-waszyngton-ostrzega-krem,nId,6726886"><img align="left" alt="Amerykańskie technologie w Zaporożu. Waszyngton ostrzega Kreml" src="https://i.iplsc.com/amerykanskie-technologie-w-zaporozu-waszyngton-ostrzega-krem/000G689I1013EOCL-C321.jpg" /></a>Waszyngton ostrzegł Moskwę przed wykorzystaniem amerykańskich technologii, które znajdują się w Zaporoskiej Elektrowni Jądrowej w Enerhodarze. O liście Departamentu USA do Rosatomu jako pierwszy poinformował serwis RBC Ukraine. W środę informacja została potwierdzona przez CNN. </p><br clear="all" />

## Rocznica powstania w getcie warszawskim. Marian Turski: Tych, którzy sieją nienawiść oskarżam
 - [https://wydarzenia.interia.pl/kraj/news-rocznica-powstania-w-getcie-warszawskim-marian-turski-tych-k,nId,6726920](https://wydarzenia.interia.pl/kraj/news-rocznica-powstania-w-getcie-warszawskim-marian-turski-tych-k,nId,6726920)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 10:28:54+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-rocznica-powstania-w-getcie-warszawskim-marian-turski-tych-k,nId,6726920"><img align="left" alt="Rocznica powstania w getcie warszawskim. Marian Turski: Tych, którzy sieją nienawiść oskarżam" src="https://i.iplsc.com/rocznica-powstania-w-getcie-warszawskim-marian-turski-tych-k/000H1RJT6LFEOABR-C321.jpg" /></a>W Warszawie trwają uroczystości 80. rocznicy wybuchu powstania w getcie warszawskim. Uroczystości rozpoczął były więzień Auschwitz Marian Turski. - Tych, którzy sieją nienawiść oskarżam - mówił. Jego przemówienie zakończyło się owacjami na stojąco. Prezydent Polski Andrzej Duda stwierdził, że powstanie w getcie jest dla niego symbolem &quot;męstwa, determinacji i odwagi&quot;.</p><br clear="all" />

## Ukraińskie zboże. Komisja Europejska zabrała głos
 - [https://wydarzenia.interia.pl/zagranica/news-ukrainskie-zboze-komisja-europejska-zabrala-glos,nId,6726915](https://wydarzenia.interia.pl/zagranica/news-ukrainskie-zboze-komisja-europejska-zabrala-glos,nId,6726915)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 10:23:35+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-ukrainskie-zboze-komisja-europejska-zabrala-glos,nId,6726915"><img align="left" alt="Ukraińskie zboże. Komisja Europejska zabrała głos" src="https://i.iplsc.com/ukrainskie-zboze-komisja-europejska-zabrala-glos/000H1RLGKBWJ3RKK-C321.jpg" /></a>- Szefowa KE w odpowiedzi na list pięciu przywódców państw UE przedstawiła propozycje ws. ukraińskiego zboża. Przygotowujemy drugi pakiet pomocy dla rolników o wartości 100 mln euro - poinformowała rzeczniczka Komisji Europejskiej Dana Spinant. Jak podkreśliła, &quot;potrzebne jest wspólne europejskie podejście w tej sprawie&quot;. Poinformowała także, że Komisja rozpoczyna dochodzenie w sprawie innych &quot;wrażliwych produktów&quot;, które trafiają z Ukrainy do UE. </p><br clear="all" />

## Dmitrij Miedwiediew o Korei Płd.: Są nowe kraje pomagające naszym wrogom
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-dmitrij-miedwiediew-o-korei-pld-sa-nowe-kraje-pomagajace-nas,nId,6726899](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-dmitrij-miedwiediew-o-korei-pld-sa-nowe-kraje-pomagajace-nas,nId,6726899)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 10:11:30+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-dmitrij-miedwiediew-o-korei-pld-sa-nowe-kraje-pomagajace-nas,nId,6726899"><img align="left" alt="Dmitrij Miedwiediew o Korei Płd.: Są nowe kraje pomagające naszym wrogom" src="https://i.iplsc.com/dmitrij-miedwiediew-o-korei-pld-sa-nowe-kraje-pomagajace-nas/000H1RJOH0N741PK-C321.jpg" /></a>Są nowe kraje, które zaczynają pomagać naszym wrogom - tak Dmitrij Miedwiediew zareagował na deklarację władz Korei Południowej, która po raz pierwszy dopuściła możliwość pomocy wojskowej Ukrainie. Były prezydent Rosji zagroził, że Moskwa może otrzymać broń od Korei Północnej.</p><br clear="all" />

## Andrzej Bryjok nie żyje. Tragiczny finał poszukiwań lekarza i byłego radnego
 - [https://wydarzenia.interia.pl/slaskie/news-andrzej-bryjok-nie-zyje-tragiczny-final-poszukiwan-lekarza-i,nId,6726855](https://wydarzenia.interia.pl/slaskie/news-andrzej-bryjok-nie-zyje-tragiczny-final-poszukiwan-lekarza-i,nId,6726855)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 09:48:51+00:00

<p><a href="https://wydarzenia.interia.pl/slaskie/news-andrzej-bryjok-nie-zyje-tragiczny-final-poszukiwan-lekarza-i,nId,6726855"><img align="left" alt="Andrzej Bryjok nie żyje. Tragiczny finał poszukiwań lekarza i byłego radnego   " src="https://i.iplsc.com/andrzej-bryjok-nie-zyje-tragiczny-final-poszukiwan-lekarza-i/000H1REFSH0L2EVA-C321.jpg" /></a>Tragiczny finał poszukiwań Andrzeja Bryjoka z Lędzin na Górnym Śląsku. Ciało znanego w powiecie lekarza i byłego radnego znaleziono w potoku Goławieckim. Był poszukiwany od niedzieli. </p><br clear="all" />

## Zmiana przepisów dotknie pracowników. Rząd chce wykorzystać nowe informacje
 - [https://wydarzenia.interia.pl/kraj/news-zmiana-przepisow-dotknie-pracownikow-rzad-chce-wykorzystac-n,nId,6714889](https://wydarzenia.interia.pl/kraj/news-zmiana-przepisow-dotknie-pracownikow-rzad-chce-wykorzystac-n,nId,6714889)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 09:21:32+00:00

<p>Ministerstwo Rodziny i Polityki Społecznej pracuje nad zmianą rozporządzenia w sprawie nowego wzoru świadectwa pracy. Resort chce wprowadzić m.in. obowiązek podawania w dokumencie liczby dni wykorzystanych na pracę zdalną. W dokumentach ma także znaleźć się informacja o nowych urlopach, które przysługują pracownikom.</p><br clear="all" />

## Ulewy nad Polską. Nadchodzi zmiana w pogodzie
 - [https://wydarzenia.interia.pl/kraj/news-ulewy-nad-polska-nadchodzi-zmiana-w-pogodzie,nId,6726801](https://wydarzenia.interia.pl/kraj/news-ulewy-nad-polska-nadchodzi-zmiana-w-pogodzie,nId,6726801)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 09:15:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-ulewy-nad-polska-nadchodzi-zmiana-w-pogodzie,nId,6726801"><img align="left" alt="Ulewy nad Polską. Nadchodzi zmiana w pogodzie" src="https://i.iplsc.com/ulewy-nad-polska-nadchodzi-zmiana-w-pogodzie/000H1R7UBE4CEYPN-C321.jpg" /></a>W środę na terenie całego kraju występują obfite opady deszczu. Najmocniej będzie padać w zachodnio-centralnej części Polski: w woj. lubuskim, wielkopolskim i łódzkim oraz częściowo w kujawsko-pomorskim i mazowieckim. Spadnie tam nawet do 30 mm deszczu. W czwartek nastąpi przełom, deszczowe chmury zastąpi słońce, a termometry pokażą nawet 18 stopni Celsjusza.</p><br clear="all" />

## Strażacy zginęli w zakładach koksowniczych. Szef MSWiA reaguje
 - [https://wydarzenia.interia.pl/dolnoslaskie/news-strazacy-zgineli-w-zakladach-koksowniczych-szef-mswia-reaguj,nId,6726837](https://wydarzenia.interia.pl/dolnoslaskie/news-strazacy-zgineli-w-zakladach-koksowniczych-szef-mswia-reaguj,nId,6726837)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 09:07:12+00:00

<p><a href="https://wydarzenia.interia.pl/dolnoslaskie/news-strazacy-zgineli-w-zakladach-koksowniczych-szef-mswia-reaguj,nId,6726837"><img align="left" alt="Strażacy zginęli w zakładach koksowniczych. Szef MSWiA reaguje" src="https://i.iplsc.com/strazacy-zgineli-w-zakladach-koksowniczych-szef-mswia-reaguj/000H1R914A2EU6AU-C321.jpg" /></a>Dwóch strażaków Komendy Miejskiej PSP w Wałbrzychu w czasie wolnym od służby zginęło w wypadku w Zakładach Koksowniczych &quot;Victoria&quot;. Ze wstępnych ustaleń wynika, że mężczyzn podczas czyszczenia komina przysypał miał koksowniczy. Kondolencje rodzinom ofiar złożył szef MSWiA Mariusz Kamiński.</p><br clear="all" />

## USA: Dostawca pizzy pomógł policji w schwytaniu przestępcy
 - [https://wydarzenia.interia.pl/zagranica/news-usa-dostawca-pizzy-pomogl-policji-w-schwytaniu-przestepcy,nId,6726796](https://wydarzenia.interia.pl/zagranica/news-usa-dostawca-pizzy-pomogl-policji-w-schwytaniu-przestepcy,nId,6726796)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 08:58:58+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-usa-dostawca-pizzy-pomogl-policji-w-schwytaniu-przestepcy,nId,6726796"><img align="left" alt="USA: Dostawca pizzy pomógł policji w schwytaniu przestępcy" src="https://i.iplsc.com/usa-dostawca-pizzy-pomogl-policji-w-schwytaniu-przestepcy/000H1R8KPKSA06TM-C321.jpg" /></a>Do sieci trafiło wideo, na którym widać, jak dostawca pizzy podkłada nogę uciekającemu przed policją mężczyźnie. Przestępca się przewraca i zostaje schwytany. &quot;Dziękujemy za pomoc&quot; - napisali funkcjonariusze pod nagraniem umieszczonym na Facebooku. </p><br clear="all" />

## Płaczący 11-latek na stacji paliw. Policja ruszyła za autokarem
 - [https://wydarzenia.interia.pl/dolnoslaskie/news-placzacy-11-latek-na-stacji-paliw-policja-ruszyla-za-autokar,nId,6726806](https://wydarzenia.interia.pl/dolnoslaskie/news-placzacy-11-latek-na-stacji-paliw-policja-ruszyla-za-autokar,nId,6726806)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 08:43:35+00:00

<p><a href="https://wydarzenia.interia.pl/dolnoslaskie/news-placzacy-11-latek-na-stacji-paliw-policja-ruszyla-za-autokar,nId,6726806"><img align="left" alt="Płaczący 11-latek na stacji paliw. Policja ruszyła za autokarem" src="https://i.iplsc.com/placzacy-11-latek-na-stacji-paliw-policja-ruszyla-za-autokar/000H1R7Y8ORTTNT6-C321.jpg" /></a>Wrocławscy policjanci wykonali niecodzienne zadanie. Po tym, jak znaleźli na stacji paliw 11-latka, który zgubił się zagranicznej wycieczce, ustalili odpowiedni autokar i ruszyli za pojazdem. Niedługo później chłopiec był już ze swoimi znajomymi. </p><br clear="all" />

## Polacy boją się inflacji i ufają bardziej UE niż rządowi. Sondaż
 - [https://wydarzenia.interia.pl/kraj/news-polacy-boja-sie-inflacji-i-ufaja-bardziej-ue-niz-rzadowi-son,nId,6726714](https://wydarzenia.interia.pl/kraj/news-polacy-boja-sie-inflacji-i-ufaja-bardziej-ue-niz-rzadowi-son,nId,6726714)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 08:37:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-polacy-boja-sie-inflacji-i-ufaja-bardziej-ue-niz-rzadowi-son,nId,6726714"><img align="left" alt="Polacy boją się inflacji i ufają bardziej UE niż rządowi. Sondaż" src="https://i.iplsc.com/polacy-boja-sie-inflacji-i-ufaja-bardziej-ue-niz-rzadowi-son/000H1R51OII0HH0I-C321.jpg" /></a>70 proc. Polaków źle ocenia sytuację w naszym kraju, 69 proc. nie ufa rządowi, a 60 proc. za największe obecnie wyzwanie dla Polski uważa inflację i rosnące ceny - wynika z cyklicznego badania Eurobarometr przeprowadzanego na zlecenie Komisji Europejskiej dwa razy w roku. Co więcej, prawie dwie trzecie Polaków chciałoby, żeby więcej decyzji dotyczących naszego kraju było podejmowanych na szczeblu europejskim.</p><br clear="all" />

## W Tatrach zeszła ogromna lawina. W sieci pojawiło się niesamowite nagranie
 - [https://wydarzenia.interia.pl/zagranica/news-w-tatrach-zeszla-ogromna-lawina-w-sieci-pojawilo-sie-niesamo,nId,6726780](https://wydarzenia.interia.pl/zagranica/news-w-tatrach-zeszla-ogromna-lawina-w-sieci-pojawilo-sie-niesamo,nId,6726780)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 08:32:47+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-w-tatrach-zeszla-ogromna-lawina-w-sieci-pojawilo-sie-niesamo,nId,6726780"><img align="left" alt="W Tatrach zeszła ogromna lawina. W sieci pojawiło się niesamowite nagranie" src="https://i.iplsc.com/w-tatrach-zeszla-ogromna-lawina-w-sieci-pojawilo-sie-niesamo/000H1R13THV0BNDT-C321.jpg" /></a>W Dolinie Żarskiej w Tatrach Zachodnich zeszła lawina dużych rozmiarów. Śnieg spadł na drogę prowadzącą do Schroniska Żarskiego. Na szczęście w okolicy nie było turystów, nikt nie został poszkodowany. </p><br clear="all" />

## Porwał ją, gdy roznosiła gazety. Nastolatka przeżyła horror
 - [https://wydarzenia.interia.pl/zagranica/news-porwal-ja-gdy-roznosila-gazety-nastolatka-przezyla-horror,nId,6726795](https://wydarzenia.interia.pl/zagranica/news-porwal-ja-gdy-roznosila-gazety-nastolatka-przezyla-horror,nId,6726795)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 08:26:27+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-porwal-ja-gdy-roznosila-gazety-nastolatka-przezyla-horror,nId,6726795"><img align="left" alt="Porwał ją, gdy roznosiła gazety. Nastolatka przeżyła horror" src="https://i.iplsc.com/porwal-ja-gdy-roznosila-gazety-nastolatka-przezyla-horror/000H1R3TLNJNPN3H-C321.jpg" /></a>Porwanie 13-letniej Filippy wstrząsnęło Danią. Dziewczynka zaginęła w niewielkiej miejscowości Kirkerup, gdy roznosiła gazety. Koszmar trwał 27 godzin, ostatecznie została odnaleziona przez policję. Zatrzymany 32-letni mężczyzna miał dopuścić się wielokrotnych gwałtów na nastolatce.</p><br clear="all" />

## Seul gotowy przekazać Ukrainie uzbrojenie. Jest warunek
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-seul-gotowy-przekazac-ukrainie-uzbrojenie-jest-warunek,nId,6726784](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-seul-gotowy-przekazac-ukrainie-uzbrojenie-jest-warunek,nId,6726784)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 08:06:28+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-seul-gotowy-przekazac-ukrainie-uzbrojenie-jest-warunek,nId,6726784"><img align="left" alt="Seul gotowy przekazać Ukrainie uzbrojenie. Jest warunek" src="https://i.iplsc.com/seul-gotowy-przekazac-ukrainie-uzbrojenie-jest-warunek/000G1V6GFYHKGJD7-C321.jpg" /></a>&quot;Duży rosyjski atak na ludność cywilną&quot; może stać się powodem rozszerzenia wsparcia dla Ukrainy przez Koreę Południową. Słowa prezydenta Jun Suk Jeola sygnalizują zmianę stanowiska Seulu, który do tej pory ograniczał się do pomocy humanitarnej i finansowej.</p><br clear="all" />

## Seul gotów przekazać Kijowowi uzbrojenie. Jest warunek
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-seul-gotow-przekazac-kijowowi-uzbrojenie-jest-warunek,nId,6726784](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-seul-gotow-przekazac-kijowowi-uzbrojenie-jest-warunek,nId,6726784)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 08:06:28+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-seul-gotow-przekazac-kijowowi-uzbrojenie-jest-warunek,nId,6726784"><img align="left" alt="Seul gotów przekazać Kijowowi uzbrojenie. Jest warunek" src="https://i.iplsc.com/seul-gotow-przekazac-kijowowi-uzbrojenie-jest-warunek/000G1V6GFYHKGJD7-C321.jpg" /></a>&quot;Duży rosyjski atak na ludność cywilną&quot; może stać się powodem rozszerzenia wsparcia dla Ukrainy przez Koreę Południową. Słowa prezydenta Jun Suk Jeola sygnalizują zmianę stanowiska Seulu, który do tej pory ograniczał się do pomocy humanitarnej i finansowej.</p><br clear="all" />

## 80. rocznica wybuchu powstania w getcie. Morawiecki: To była otchłań piekła
 - [https://wydarzenia.interia.pl/kraj/news-80-rocznica-wybuchu-powstania-w-getcie-morawiecki-to-byla-ot,nId,6726778](https://wydarzenia.interia.pl/kraj/news-80-rocznica-wybuchu-powstania-w-getcie-morawiecki-to-byla-ot,nId,6726778)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 07:58:37+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-80-rocznica-wybuchu-powstania-w-getcie-morawiecki-to-byla-ot,nId,6726778"><img align="left" alt="80. rocznica wybuchu powstania w getcie. Morawiecki: To była otchłań piekła" src="https://i.iplsc.com/80-rocznica-wybuchu-powstania-w-getcie-morawiecki-to-byla-ot/000H1QXPK9MBQQIC-C321.jpg" /></a>- Składamy hołd heroicznej walce powstańców żydowskich, chłopców i dziewcząt, którzy w beznadziejnej sytuacji chwycili za broń, by tak naprawdę wybrać sposób śmieci. Tak można powiedzieć o ich szansach, o braku jakiejkolwiek proporcji sił między nimi a niemieckimi zbrodniarzami - powiedział premier Mateusz Morawiecki w 80. rocznicę wybuchu powstania w getcie warszawskim. </p><br clear="all" />

## USA: Śmierć 13-latka po wyzwaniu na TikToku. Przedawkował leki
 - [https://wydarzenia.interia.pl/zagranica/news-usa-smierc-13-latka-po-wyzwaniu-na-tiktoku-przedawkowal-leki,nId,6726722](https://wydarzenia.interia.pl/zagranica/news-usa-smierc-13-latka-po-wyzwaniu-na-tiktoku-przedawkowal-leki,nId,6726722)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 07:31:51+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-usa-smierc-13-latka-po-wyzwaniu-na-tiktoku-przedawkowal-leki,nId,6726722"><img align="left" alt="USA: Śmierć 13-latka po wyzwaniu na TikToku. Przedawkował leki" src="https://i.iplsc.com/usa-smierc-13-latka-po-wyzwaniu-na-tiktoku-przedawkowal-leki/000H1QNJ93MVK9J1-C321.jpg" /></a>13-letni Jacob z Ohio zmarł po wzięciu udziału w wyzwaniu &quot;Benadryl Challenge&quot; na TikToku. Zadanie polegało na zażyciu dużych dawek leku na alergię, które miały wywołać halucynacje. Nastolatek spędził prawie tydzień w szpitalu, niestety nie udało się go uratować. Lekarze stwierdzili śmierć mózgu.</p><br clear="all" />

## Walki w Sudanie. Zerwano zawieszenie broni
 - [https://wydarzenia.interia.pl/zagranica/news-walki-w-sudanie-zerwano-zawieszenie-broni,nId,6726757](https://wydarzenia.interia.pl/zagranica/news-walki-w-sudanie-zerwano-zawieszenie-broni,nId,6726757)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 07:28:36+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-walki-w-sudanie-zerwano-zawieszenie-broni,nId,6726757"><img align="left" alt="Walki w Sudanie. Zerwano zawieszenie broni" src="https://i.iplsc.com/walki-w-sudanie-zerwano-zawieszenie-broni/000H1QYKADYUAVMI-C321.jpg" /></a>Co najmniej 270 ofiar i ponad 2600 rannych - to bilans trwających od soboty walk w stolicy Sudanu Chartum. Codziennie widać dym unoszący się z budynków i słychać eksplozje. Nie zadziałało również zawieszenie broni, które zostało zerwane po kilku godzinach od jego ogłoszenia.</p><br clear="all" />

## O Boże! Zboże. Czyli Polska polityka w pigułce
 - [https://wydarzenia.interia.pl/felietony/news-o-boze-zboze-czyli-polska-polityka-w-pigulce,nId,6726734](https://wydarzenia.interia.pl/felietony/news-o-boze-zboze-czyli-polska-polityka-w-pigulce,nId,6726734)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 07:24:47+00:00

<p><a href="https://wydarzenia.interia.pl/felietony/news-o-boze-zboze-czyli-polska-polityka-w-pigulce,nId,6726734"><img align="left" alt="O Boże! Zboże. Czyli Polska polityka w pigułce" src="https://i.iplsc.com/o-boze-zboze-czyli-polska-polityka-w-pigulce/000H1QNF2WEA756H-C321.jpg" /></a>Było to do przewidzenia. W aferze zbożowej sympatie społeczne zaczynają dzielić się według sympatii partyjnych. Formacje polityczne perfekcyjnie odegrały swoją rolę, każda z nich pokazując się od jak najgorszej strony.</p><br clear="all" />

## Rosyjskie "statki widmo" pływają po Bałtyku. Zbierają dane do sabotażu
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosyjskie-statki-widmo-plywaja-po-baltyku-zbieraja-dane-do-s,nId,6726747](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosyjskie-statki-widmo-plywaja-po-baltyku-zbieraja-dane-do-s,nId,6726747)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 07:19:48+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosyjskie-statki-widmo-plywaja-po-baltyku-zbieraja-dane-do-s,nId,6726747"><img align="left" alt="Rosyjskie &quot;statki widmo&quot; pływają po Bałtyku. Zbierają dane do sabotażu" src="https://i.iplsc.com/rosyjskie-statki-widmo-plywaja-po-baltyku-zbieraja-dane-do-s/000H1QLC87BYXT9W-C321.jpg" /></a>Rosyjskie wojskowe i cywilne &quot;statki widmo&quot; poruszają się po Morzu Bałtyckim i Morzu Północnym, zbierając dane, które można wykorzystać do ewentualnego sabotażu - wynika ze wspólnego dochodzenia nadawców publicznych w Danii, Norwegii, Szwecji i Finlandii. Celem jednostek jest obserwacja m.in. morskich farm wiatrowych i gazociągów.</p><br clear="all" />

## Dramatyczne sceny w Pekinie. Ludzie uciekali przez okna
 - [https://wydarzenia.interia.pl/zagranica/news-dramatyczne-sceny-w-pekinie-ludzie-uciekali-przez-okna,nId,6726730](https://wydarzenia.interia.pl/zagranica/news-dramatyczne-sceny-w-pekinie-ludzie-uciekali-przez-okna,nId,6726730)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 06:57:26+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-dramatyczne-sceny-w-pekinie-ludzie-uciekali-przez-okna,nId,6726730"><img align="left" alt="Dramatyczne sceny w Pekinie. Ludzie uciekali przez okna" src="https://i.iplsc.com/dramatyczne-sceny-w-pekinie-ludzie-uciekali-przez-okna/000H1QO672QLOPJK-C321.jpg" /></a>Liczba ofiar śmiertelnych pożaru w szpitalu Changfeng w Pekinie wzrosła do 29 - podaje Reuters, powołując się na komunikat przedstawicieli władz miasta. W mediach społecznościowych pojawiły się nagrania, na których widać, jak ludzie przez okna próbują uciec przed płomieniami i gęstym dymem. </p><br clear="all" />

## Chiny mają superdrona. Jest trzy razy szybszy niż prędkość dźwięku
 - [https://wydarzenia.interia.pl/zagranica/news-chiny-maja-superdrona-jest-trzy-razy-szybszy-niz-predkosc-dz,nId,6726726](https://wydarzenia.interia.pl/zagranica/news-chiny-maja-superdrona-jest-trzy-razy-szybszy-niz-predkosc-dz,nId,6726726)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 06:52:33+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-chiny-maja-superdrona-jest-trzy-razy-szybszy-niz-predkosc-dz,nId,6726726"><img align="left" alt="Chiny mają superdrona. Jest trzy razy szybszy niż prędkość dźwięku" src="https://i.iplsc.com/chiny-maja-superdrona-jest-trzy-razy-szybszy-niz-predkosc-dz/000H1QJ9O81HC9BQ-C321.jpg" /></a>Chińska armia wkrótce może zacząć używać superdrona szpiegowskiego, który zdolny jest poruszać się trzy razy szybciej niż prędkość dźwięku - informuje &quot;Washington Post&quot;, publikując tajny dokument amerykańskiej Agencji Wywiadu Geoprzestrzennego. Dron radykalnie wzmocniłby zdolność Chin do prowadzenia operacji obserwacyjnych.

</p><br clear="all" />

## Chiny: Tragedia podczas występu. Akrobatka zmarła po upadku z wysokości
 - [https://wydarzenia.interia.pl/zagranica/news-chiny-tragedia-podczas-wystepu-akrobatka-zmarla-po-upadku-z-,nId,6726724](https://wydarzenia.interia.pl/zagranica/news-chiny-tragedia-podczas-wystepu-akrobatka-zmarla-po-upadku-z-,nId,6726724)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 06:51:11+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-chiny-tragedia-podczas-wystepu-akrobatka-zmarla-po-upadku-z-,nId,6726724"><img align="left" alt="Chiny: Tragedia podczas występu. Akrobatka zmarła po upadku z wysokości" src="https://i.iplsc.com/chiny-tragedia-podczas-wystepu-akrobatka-zmarla-po-upadku-z/000H1QHX7FKMD27R-C321.jpg" /></a>Podczas występu artystycznego w Chinach doszło do tragedii. Akrobatka, która wraz ze swoim mężem wykonywała figury w powietrzu, w pewnym momencie spadła na twarde, niezabezpieczone podłoże. Kobieta trafiła do szpitala, jednak w wyniku odniesionych obrażeń zmarła.</p><br clear="all" />

## Psy sterroryzowały okolicę Birmingham. Wiele osób rannych
 - [https://wydarzenia.interia.pl/zagranica/news-psy-sterroryzowaly-okolice-birmingham-wiele-osob-rannych,nId,6726700](https://wydarzenia.interia.pl/zagranica/news-psy-sterroryzowaly-okolice-birmingham-wiele-osob-rannych,nId,6726700)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 06:20:37+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-psy-sterroryzowaly-okolice-birmingham-wiele-osob-rannych,nId,6726700"><img align="left" alt="Psy sterroryzowały okolicę Birmingham. Wiele osób rannych" src="https://i.iplsc.com/psy-sterroryzowaly-okolice-birmingham-wiele-osob-rannych/000H1Q93CJQ4BBKW-C321.jpg" /></a>Dwa psy uciekły właścicielowi z brytyjskiego osiedla Winsow Green w Birmingham i atakowały przechodniów. Sześć osób zostało rannych, a nauczyciele pobliskiej szkoły przedłużyli zajęcia, by dzieci nie wychodziły na ulicę.</p><br clear="all" />

## Nowe zasady urlopów. Od 26 kwietnia ważne zmiany dla pracowników
 - [https://wydarzenia.interia.pl/kraj/news-nowe-zasady-urlopow-od-26-kwietnia-wazne-zmiany-dla-pracowni,nId,6722655](https://wydarzenia.interia.pl/kraj/news-nowe-zasady-urlopow-od-26-kwietnia-wazne-zmiany-dla-pracowni,nId,6722655)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 06:00:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-nowe-zasady-urlopow-od-26-kwietnia-wazne-zmiany-dla-pracowni,nId,6722655"><img align="left" alt="Nowe zasady urlopów. Od 26 kwietnia ważne zmiany dla pracowników" src="https://i.iplsc.com/nowe-zasady-urlopow-od-26-kwietnia-wazne-zmiany-dla-pracowni/000H1FON5P8WWVPX-C321.jpg" /></a>Osobom zatrudnionym na umowę o pracę jeszcze w tym roku zaczną przysługiwać dodatkowe dni wolne od pracy. Wielu Polaków będzie mogło skorzystać z nowych urlopów dzięki ostatniej nowelizacji Kodeksu pracy, która wejdzie w życie 26 kwietnia. W przepisach można się jednak łatwo pogubić. Dlatego przypominamy nowe zasady dotyczące urlopów w 2023 roku. Sprawdź, jakie istotne zmiany wchodzą w życie w przyszłym tygodniu.</p><br clear="all" />

## Ważne zmiany dla pracowników. Nowe przepisy wejdą w życie już 26 kwietnia
 - [https://wydarzenia.interia.pl/kraj/news-wazne-zmiany-dla-pracownikow-nowe-przepisy-wejda-w-zycie-juz,nId,6722655](https://wydarzenia.interia.pl/kraj/news-wazne-zmiany-dla-pracownikow-nowe-przepisy-wejda-w-zycie-juz,nId,6722655)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 06:00:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-wazne-zmiany-dla-pracownikow-nowe-przepisy-wejda-w-zycie-juz,nId,6722655"><img align="left" alt="Ważne zmiany dla pracowników. Nowe przepisy wejdą w życie już 26 kwietnia" src="https://i.iplsc.com/wazne-zmiany-dla-pracownikow-nowe-przepisy-wejda-w-zycie-juz/000H1FON5P8WWVPX-C321.jpg" /></a>Osobom zatrudnionym na umowę o pracę jeszcze w tym roku zaczną przysługiwać dodatkowe dni wolne od pracy. Wielu Polaków będzie mogło skorzystać z nowych urlopów dzięki ostatniej nowelizacji Kodeksu pracy, która wejdzie w życie 26 kwietnia. W przepisach można się jednak łatwo pogubić. Dlatego przypominamy nowe zasady dotyczące urlopów w 2023 roku. Sprawdź, jakie istotne zmiany wchodzą w życie w przyszłym tygodniu.</p><br clear="all" />

## 16-latek przyszedł po braci, został postrzelony. Podejrzany zwolniony za kaucją
 - [https://wydarzenia.interia.pl/zagranica/news-16-latek-przyszedl-po-braci-zostal-postrzelony-podejrzany-zw,nId,6726681](https://wydarzenia.interia.pl/zagranica/news-16-latek-przyszedl-po-braci-zostal-postrzelony-podejrzany-zw,nId,6726681)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 05:54:15+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-16-latek-przyszedl-po-braci-zostal-postrzelony-podejrzany-zw,nId,6726681"><img align="left" alt="16-latek przyszedł po braci, został postrzelony. Podejrzany zwolniony za kaucją" src="https://i.iplsc.com/16-latek-przyszedl-po-braci-zostal-postrzelony-podejrzany-zw/000H1Q7RDN99JWY5-C321.jpg" /></a>84-letni Andrew Lester został oskarżony o dokonanie napaści pierwszego stopnia i napaści z bronią w ręku - przekazał prokurator hrabstwa Clay Zachary Thompson. To kontynuacja szokującej sprawy postrzelania 16-letniego Ralpha Yarla, który chcąc odebrać młodsze rodzeństwo, pomylił domy. 84-latek - jak podaje &quot;Independent&quot; - miał tłumaczyć się, że był przekonany o &quot;próbie włamania&quot; i w obawie przed konfrontacją fizyczną postanowił użyć broni. Lester we wtorek opuścił areszt, co wywołało lokalne protesty.</p><br clear="all" />

## Małopolskie: Dwuletni Wiktor Matejko poszukiwany. Policja prosi o informacje
 - [https://wydarzenia.interia.pl/malopolskie/news-malopolskie-dwuletni-wiktor-matejko-poszukiwany-policja-pros,nId,6726680](https://wydarzenia.interia.pl/malopolskie/news-malopolskie-dwuletni-wiktor-matejko-poszukiwany-policja-pros,nId,6726680)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 05:53:44+00:00

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-malopolskie-dwuletni-wiktor-matejko-poszukiwany-policja-pros,nId,6726680"><img align="left" alt="Małopolskie: Dwuletni Wiktor Matejko poszukiwany. Policja prosi o informacje" src="https://i.iplsc.com/malopolskie-dwuletni-wiktor-matejko-poszukiwany-policja-pros/000H1Q4RJP0UAVMH-C321.jpg" /></a>Siedmiomiesięczny wówczas Wiktor Matejko zaginął 28 czerwca 2021 roku. Nastoletnia matka wyszła z dzieckiem z domu wczasowego w Owieczkach (pow. limanowski) i udała się w nieznanym kierunku. Funkcjonariusze proszą o kontakt wszystkich, którzy mogą mieć jakiekolwiek informacje dotyczące miejsca pobytu chłopca.</p><br clear="all" />

## Plaga "hybrydowych superkrólików" w Hiszpanii. Setki milionów euro strat
 - [https://wydarzenia.interia.pl/zagranica/news-plaga-hybrydowych-superkrolikow-w-hiszpanii-setki-milionow-e,nId,6726664](https://wydarzenia.interia.pl/zagranica/news-plaga-hybrydowych-superkrolikow-w-hiszpanii-setki-milionow-e,nId,6726664)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 05:25:41+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-plaga-hybrydowych-superkrolikow-w-hiszpanii-setki-milionow-e,nId,6726664"><img align="left" alt="Plaga &quot;hybrydowych superkrólików&quot; w Hiszpanii. Setki milionów euro strat" src="https://i.iplsc.com/plaga-hybrydowych-superkrolikow-w-hiszpanii-setki-milionow-e/000H1Q3T6KFDO84U-C321.jpg" /></a>Szybko się rozmnażają, potrafią wspinać się na drzewa i są żarłoczne, przez co niszczą okoliczne uprawy. Rolnicy w Hiszpanii alarmują o pladze &quot;hybrydowych superkrólików&quot;, które mają zagrażać milionowi hektarów pól. Wyrządzone przez nie szkody szacuje się dotąd na setki milionów euro. W dramatyczne historie rolników nie wierzy jednak hiszpańskie ministerstwo, które oskarża ich o chęć uzyskania subwencji za straty spowodowane suszą.</p><br clear="all" />

## Jeden rachunek za prąd, aż 9 różnych opłat! Za co tak naprawdę płacisz?
 - [https://wydarzenia.interia.pl/kraj/news-jeden-rachunek-za-prad-az-9-roznych-oplat-za-co-tak-naprawde,nId,6722585](https://wydarzenia.interia.pl/kraj/news-jeden-rachunek-za-prad-az-9-roznych-oplat-za-co-tak-naprawde,nId,6722585)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 05:20:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-jeden-rachunek-za-prad-az-9-roznych-oplat-za-co-tak-naprawde,nId,6722585"><img align="left" alt="Jeden rachunek za prąd, aż 9 różnych opłat! Za co tak naprawdę płacisz?" src="https://i.iplsc.com/jeden-rachunek-za-prad-az-9-roznych-oplat-za-co-tak-naprawde/000DBA3K0KVS9Y1A-C321.jpg" /></a>Jak czytać rachunek za prąd? Co oznaczają poszczególne pozycje? Zwykle nie zastanawiamy się nad tym szczególnie i po prostu robimy przelew na kwotę podaną w podsumowaniu. Warto jednak wiedzieć, jaki wpływ na całkowity koszt energii mają poszczególne pozycje na rachunku i na czym możemy zaoszczędzić, ograniczając zużycie prądu w domu. W tym roku jedna z pozycji zmalała do zera, ale to nie przełoży się na spadek cen energii.</p><br clear="all" />

## Nowy rachunek za prąd cię zaskoczył? Wysokość tej opłaty wzrosła
 - [https://wydarzenia.interia.pl/kraj/news-nowy-rachunek-za-prad-cie-zaskoczyl-wysokosc-tej-oplaty-wzro,nId,6722585](https://wydarzenia.interia.pl/kraj/news-nowy-rachunek-za-prad-cie-zaskoczyl-wysokosc-tej-oplaty-wzro,nId,6722585)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 05:20:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-nowy-rachunek-za-prad-cie-zaskoczyl-wysokosc-tej-oplaty-wzro,nId,6722585"><img align="left" alt="Nowy rachunek za prąd cię zaskoczył? Wysokość tej opłaty wzrosła " src="https://i.iplsc.com/nowy-rachunek-za-prad-cie-zaskoczyl-wysokosc-tej-oplaty-wzro/000DBA3K0KVS9Y1A-C321.jpg" /></a>Jak czytać rachunek za prąd? Co oznaczają poszczególne pozycje? Zwykle nie zastanawiamy się nad tym szczególnie i po prostu robimy przelew na kwotę podaną w podsumowaniu. Warto jednak wiedzieć, jaki wpływ na całkowity koszt energii mają poszczególne pozycje na rachunku i na czym możemy zaoszczędzić, ograniczając zużycie prądu w domu. W tym roku jedna z pozycji zmalała do zera, a inna wzrosła.</p><br clear="all" />

## Dziś rocznica powstania w getcie warszawskim. Jak do niego doszło?
 - [https://wydarzenia.interia.pl/historia/news-dzis-rocznica-powstania-w-getcie-warszawskim-jak-do-niego-do,nId,6722699](https://wydarzenia.interia.pl/historia/news-dzis-rocznica-powstania-w-getcie-warszawskim-jak-do-niego-do,nId,6722699)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 04:57:19+00:00

<p><a href="https://wydarzenia.interia.pl/historia/news-dzis-rocznica-powstania-w-getcie-warszawskim-jak-do-niego-do,nId,6722699"><img align="left" alt="Dziś rocznica powstania w getcie warszawskim. Jak do niego doszło?" src="https://i.iplsc.com/dzis-rocznica-powstania-w-getcie-warszawskim-jak-do-niego-do/000H1FS65349X197-C321.jpg" /></a>Dziś przypada 80. rocznica wybuchu powstania w getcie warszawskim. Zdarzenie zapisało się na kartach historii Warszawy jako jeden z najbardziej bohaterskich przejawów oporu wobec niemieckiego okupanta podczas II wojny światowej. Kiedy wybuchło powstanie i dlaczego do niego doszło?</p><br clear="all" />

## Szef MSZ Węgier o wojnie w Ukrainie: Są tylko przegrani
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-szef-msz-wegier-o-wojnie-w-ukrainie-sa-tylko-przegrani,nId,6726652](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-szef-msz-wegier-o-wojnie-w-ukrainie-sa-tylko-przegrani,nId,6726652)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 04:45:05+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-szef-msz-wegier-o-wojnie-w-ukrainie-sa-tylko-przegrani,nId,6726652"><img align="left" alt="Szef MSZ Węgier o wojnie w Ukrainie: Są tylko przegrani" src="https://i.iplsc.com/szef-msz-wegier-o-wojnie-w-ukrainie-sa-tylko-przegrani/000H1Q1LQ227SGX9-C321.jpg" /></a>- Mówienie o zwycięzcach w tym konflikcie nie ma sensu - powiedział we wtorek minister spraw zagranicznych Węgier Peter Szijjarto w programie publicystycznym BBC HARDtalk. Jak dodał, jego zdaniem &quot;w tej wojnie są tylko przegrani&quot;. Wcześniej podkreślał, że ma nadzieję na jak najszybsze podjęcie rozmów pokojowych między Kijowem a Moskwą.</p><br clear="all" />

## Nowy Jork: Zawalił się piętrowy parking. Zginęła jedna osoba
 - [https://wydarzenia.interia.pl/zagranica/news-nowy-jork-zawalil-sie-pietrowy-parking-zginela-jedna-osoba,nId,6726649](https://wydarzenia.interia.pl/zagranica/news-nowy-jork-zawalil-sie-pietrowy-parking-zginela-jedna-osoba,nId,6726649)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 04:29:11+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-nowy-jork-zawalil-sie-pietrowy-parking-zginela-jedna-osoba,nId,6726649"><img align="left" alt="Nowy Jork: Zawalił się piętrowy parking. Zginęła jedna osoba" src="https://i.iplsc.com/nowy-jork-zawalil-sie-pietrowy-parking-zginela-jedna-osoba/000H1Q1C8MHJ8K4W-C321.jpg" /></a>Co najmniej jedna osoba zginęła, a kilka zostało rannych, kiedy we wtorek po południu na dolnym Manhattanie zawalił się piętrowy parking. Ewakuowano pobliskie budynki. Media przypominają, że dwa lata temu inspektorzy budowlani zauważyli naruszenia struktury budynku, w którym znajdował się garaż. Zawiadomienia jednak oddalono.
</p><br clear="all" />

## Wielka akcja Interpolu. Ponad 14 tys. aresztowanych
 - [https://wydarzenia.interia.pl/zagranica/news-wielka-akcja-interpolu-ponad-14-tys-aresztowanych,nId,6726645](https://wydarzenia.interia.pl/zagranica/news-wielka-akcja-interpolu-ponad-14-tys-aresztowanych,nId,6726645)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 04:14:08+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wielka-akcja-interpolu-ponad-14-tys-aresztowanych,nId,6726645"><img align="left" alt="Wielka akcja Interpolu. Ponad 14 tys. aresztowanych" src="https://i.iplsc.com/wielka-akcja-interpolu-ponad-14-tys-aresztowanych/000H1Q0CMD0T8PT2-C321.jpg" /></a>Akcja bez precedensu - tak funkcjonariusze Interpolu opisują jedną z największych w skali światowej operacji przeprowadzonej w 15 krajach Ameryki Łacińskiej. Podczas działań pod kryptonimem Trigger IX aresztowano 14 260 osób, skonfiskowano ponad 8 200 sztuk nielegalnej broni palnej i ponad 300 tys. sztuk amunicji.</p><br clear="all" />

## Wojna w Ukrainie. 420. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-420-dzien-inwazji-rosji-relacja-na-zywo,nzId,4074,akt,190548](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-420-dzien-inwazji-rosji-relacja-na-zywo,nzId,4074,akt,190548)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 03:48:14+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-420-dzien-inwazji-rosji-relacja-na-zywo,nzId,4074,akt,190548"><img align="left" alt="Wojna w Ukrainie. 420. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-420-dzien-inwazji-rosji-relacja-na-zywo/000H1PZLY9EBAKX1-C321.jpg" /></a>Zachęcamy do śledzenia najnowszych informacji z wojny w Ukrainie.</p><br clear="all" />

## Wojna w Ukrainie. 420. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-420-dzien-inwazji-rosji-relacja-na-zywo,nzId,4074,akt,190703](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-420-dzien-inwazji-rosji-relacja-na-zywo,nzId,4074,akt,190703)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 03:48:14+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-420-dzien-inwazji-rosji-relacja-na-zywo,nzId,4074,akt,190703"><img align="left" alt="Wojna w Ukrainie. 420. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-420-dzien-inwazji-rosji-relacja-na-zywo/000H1PZLY9EBAKX1-C321.jpg" /></a>Zachęcamy do śledzenia najnowszych informacji z wojny w Ukrainie.</p><br clear="all" />

## Wojna w Ukrainie. 420. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-420-dzien-inwazji-rosji-relacja-na-zywo,nzId,4074,akt,190802](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-420-dzien-inwazji-rosji-relacja-na-zywo,nzId,4074,akt,190802)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-19 03:48:14+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-420-dzien-inwazji-rosji-relacja-na-zywo,nzId,4074,akt,190802"><img align="left" alt="Wojna w Ukrainie. 420. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-420-dzien-inwazji-rosji-relacja-na-zywo/000H1PZLY9EBAKX1-C321.jpg" /></a>Zachęcamy do śledzenia najnowszych informacji z wojny w Ukrainie.</p><br clear="all" />

