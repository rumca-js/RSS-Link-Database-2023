# Source:LaterClips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCtVGGeUqfVHOK4Q6nAwYO3g, language:en-US

## Shocking Photograph Left Everyone Baffled
 - [https://www.youtube.com/watch?v=ucrJKYXZHxg](https://www.youtube.com/watch?v=ucrJKYXZHxg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtVGGeUqfVHOK4Q6nAwYO3g
 - date published: 2023-04-19 22:00:24+00:00

Latercase - https://latercase.com/lewlater

Clip from Lew Later (Google is Showing Alarming Signs...) - https://youtube.com/live/BNOqUx3KpzU

## Drake's New AI Single Changes Everything... (Heart on My Sleeve)
 - [https://www.youtube.com/watch?v=NXwADjCAzq8](https://www.youtube.com/watch?v=NXwADjCAzq8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtVGGeUqfVHOK4Q6nAwYO3g
 - date published: 2023-04-19 19:00:09+00:00

Latercase - https://latercase.com/lewlater

Clip from Lew Later (Apple Loses Ground...) - https://youtube.com/live/sEW_R9sbnNM

## Google Pixel 7a Alleged Price Is Strange...
 - [https://www.youtube.com/watch?v=DOBwFFhd1x0](https://www.youtube.com/watch?v=DOBwFFhd1x0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtVGGeUqfVHOK4Q6nAwYO3g
 - date published: 2023-04-19 16:00:08+00:00

Latercase - https://latercase.com/lewlater

Clip from Lew Later (Google is Showing Alarming Signs...) - https://youtube.com/live/BNOqUx3KpzU

## Apple's Major Launch Should Worry Banks
 - [https://www.youtube.com/watch?v=1QQqa4x4Jr0](https://www.youtube.com/watch?v=1QQqa4x4Jr0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtVGGeUqfVHOK4Q6nAwYO3g
 - date published: 2023-04-19 13:00:02+00:00

Latercase - https://latercase.com/lewlater

Clip from Lew Later (Google is Showing Alarming Signs...) - https://youtube.com/live/BNOqUx3KpzU

## Google Panics Over Samsung's Decision
 - [https://www.youtube.com/watch?v=kIKqIkdy8b4](https://www.youtube.com/watch?v=kIKqIkdy8b4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtVGGeUqfVHOK4Q6nAwYO3g
 - date published: 2023-04-19 11:00:26+00:00

Latercase - https://latercase.com/lewlater

Clip from Lew Later (Google is Showing Alarming Signs...) - https://youtube.com/live/BNOqUx3KpzU

## Tim Cook Makes An Appearance In India
 - [https://www.youtube.com/watch?v=zaFUjkhb0bY](https://www.youtube.com/watch?v=zaFUjkhb0bY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtVGGeUqfVHOK4Q6nAwYO3g
 - date published: 2023-04-19 09:00:42+00:00

Latercase - https://latercase.com/lewlater

Clip from Lew Later (Google is Showing Alarming Signs...) - https://youtube.com/live/BNOqUx3KpzU

## Apple's tim Cook Finally Makes It
 - [https://www.youtube.com/watch?v=Rqkia4Ad7wM](https://www.youtube.com/watch?v=Rqkia4Ad7wM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtVGGeUqfVHOK4Q6nAwYO3g
 - date published: 2023-04-19 07:00:10+00:00

Latercase - https://latercase.com/lewlater

Clip from Lew Later (Apple Isn't Growing Much Further...) - https://youtube.com/live/Hmhw-iBaqoM

## Bioshock Concept Trailer Blow Fans Away
 - [https://www.youtube.com/watch?v=zAopK35m_VY](https://www.youtube.com/watch?v=zAopK35m_VY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtVGGeUqfVHOK4Q6nAwYO3g
 - date published: 2023-04-19 05:00:23+00:00

Latercase - https://latercase.com/lewlater

Clip from Lew Later (Google is Showing Alarming Signs...) - https://youtube.com/live/BNOqUx3KpzU

## Elon Musk Launches a New Project
 - [https://www.youtube.com/watch?v=GK40RxThZjc](https://www.youtube.com/watch?v=GK40RxThZjc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtVGGeUqfVHOK4Q6nAwYO3g
 - date published: 2023-04-19 04:00:06+00:00

Latercase - https://latercase.com/lewlater

Clip from Lew Later (Apple Isn't Growing Much Further...) - https://youtube.com/live/Hmhw-iBaqoM

## Is This The Tesla Model 3 Killer?
 - [https://www.youtube.com/watch?v=YH93lMZs1Pw](https://www.youtube.com/watch?v=YH93lMZs1Pw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtVGGeUqfVHOK4Q6nAwYO3g
 - date published: 2023-04-19 03:00:23+00:00

Latercase - https://latercase.com/lewlater

Clip from Lew Later (Google is Showing Alarming Signs...) - https://youtube.com/live/BNOqUx3KpzU

## Elon Musk Gets Serious About His Promise
 - [https://www.youtube.com/watch?v=X_MqRx5CDGk](https://www.youtube.com/watch?v=X_MqRx5CDGk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtVGGeUqfVHOK4Q6nAwYO3g
 - date published: 2023-04-19 01:00:09+00:00

Latercase - https://latercase.com/lewlater

Clip from Lew Later (Google is Showing Alarming Signs...) - https://youtube.com/live/BNOqUx3KpzU

