# Source:ForrestKnight, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2WHjPDvbE6O328n17ZGcfg, language:en-US

## How Nvidia is Powering the Entire AI Industry
 - [https://www.youtube.com/watch?v=dgmQ-IAANAc](https://www.youtube.com/watch?v=dgmQ-IAANAc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2WHjPDvbE6O328n17ZGcfg
 - date published: 2023-04-19 13:00:25+00:00

While everyone's focused on @OpenAI's #chatgpt, I'm looking at a bigger AI breakthrough happening right now. A couple weeks ago, @NVIDIA held Spring GTC 2023, where they talked about their involvement in the #ai industry, powering all of your favorite AI tools from ChatGPT to Adobe Firefly and just about everything else in between.

------------------------

🐱‍🚀 GitHub: https://github.com/forrestknight
🐦 Twitter: https://www.twitter.com/forrestpknight
💼 LinkedIn: https://www.linkedin.com/in/forrestpknight
📸 Instagram: https://www.instagram.com/forrestpknight
 
📓 Learning Resources: 
My Favorite Machine Learning Course:  https://imp.i384100.net/YgYEBJ
Open Source Computer Science Degree:  https://bit.ly/open-source-forrest
Python Open Source Computer Science Degree:  https://bit.ly/python-open-source
Udacity to Learn Any Coding Skill: http://bit.ly/udacity-forrest

👨‍💻 My Coding Gear:
My NAS Server: https://amzn.to/3brqO7b
My Hard Drives: https://amzn.to/3aKetMi
My Main Monitor: https://amzn.to/3siQfPa
My Second Monitor: https://amzn.to/3keHT84
My Standing Desk: https://amzn.to/3boAcbC
My PC Build:  https://bit.ly/my-coding-gear
My AI GPU: https://amzn.to/3uvmUmz

