# Source:Wired business, URL:https://www.wired.com/feed/category/business/latest/rss, language:en-US

## Did Instagram Just Kill Linktree?
 - [https://www.wired.com/story/did-instagram-just-kill-linktree/](https://www.wired.com/story/did-instagram-just-kill-linktree/)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2023-04-19 14:45:00+00:00

Meta is finally allowing people to add more links to their Instagram profiles. It’s an existential threat to link-in-bio companies.

## How ChatGPT—and Bots Like It—Can Spread Malware
 - [https://www.wired.com/story/chatgpt-ai-bots-spread-malware/](https://www.wired.com/story/chatgpt-ai-bots-spread-malware/)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2023-04-19 11:00:00+00:00

Generative AI is a tool, which means it can be used by cybercriminals, too. Here’s how to protect yourself.

## Max Levchin on How AI Will—and Won’t—Shape the Way You Pay
 - [https://www.wired.com/story/have-a-nice-future-podcast-2/](https://www.wired.com/story/have-a-nice-future-podcast-2/)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2023-04-19 11:00:00+00:00

We sat down with the CEO of Affirm to talk about the “buy now, pay later” model and just what makes him an “unabashed techno-utopian.”

