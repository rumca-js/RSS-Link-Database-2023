# Source:Sydney Watson, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSFy-1JrpZf0tFlRZfo-Rvw, language:en-US

## Some personal news...
 - [https://www.youtube.com/watch?v=VyAxkAeYDJE](https://www.youtube.com/watch?v=VyAxkAeYDJE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSFy-1JrpZf0tFlRZfo-Rvw
 - date published: 2023-04-19 22:22:48+00:00

Sign-up and join The Publica as a member here: https://www.thepublica.com/become-a-member/
Read our goals: https://www.thepublica.com/goals/

Thanks for always being supportive. It feels so cool to be able to do something more. I have extremely high hopes and I'm excited about the future. Thanks for coming along for the ride.

Find me:
Subscribestar: https://www.subscribestar.com/sydney-watson
Facebook: https://www.facebook.com/sydneywatsonofficial 
Twitter: https://twitter.com/sydneylwatson 
Instagram: https://www.instagram.com/sydneywatson__ 

Sign up to my email list (I promise not to harass you haha): https://www.sydneywatson.com

## When your husband says he's a woman...
 - [https://www.youtube.com/watch?v=7RHp_N_iVmE](https://www.youtube.com/watch?v=7RHp_N_iVmE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSFy-1JrpZf0tFlRZfo-Rvw
 - date published: 2023-04-19 01:05:02+00:00

Thank you to META PCs for sponsoring this video! Head over to https://metapcs.com/ref/sydney and use code SYD to save money on a new custom PC!

Links:
Links can now get you in trouble with our YouTube overlords. So, this probably ain't the topic for me to link a bunch of stuff. And honestly, because of the scarcity of information ON this topic, there isn't much to link anyway. Sorry, frens.

Find me:
Subscribestar: https://www.subscribestar.com/sydney-watson
Facebook: https://www.facebook.com/sydneywatsonofficial 
Twitter: https://twitter.com/sydneylwatson 
Instagram: https://www.instagram.com/sydneywatson__ 

Sign up to my email list (I promise not to harass you haha): https://www.sydneywatson.com

