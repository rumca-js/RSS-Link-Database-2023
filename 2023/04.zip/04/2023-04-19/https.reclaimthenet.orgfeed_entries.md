# Source:Reclaim The Net, URL:https://reclaimthenet.org/feed/, language:en-US

## Big Tech companies are scooping up former DOJ-employees as antitrust fight continues
 - [https://reclaimthenet.org/big-tech-companies-are-scooping-up-former-doj-employees-as-antitrust-fight-continues](https://reclaimthenet.org/big-tech-companies-are-scooping-up-former-doj-employees-as-antitrust-fight-continues)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-04-19 16:53:30+00:00

<a href="https://reclaimthenet.org/big-tech-companies-are-scooping-up-former-doj-employees-as-antitrust-fight-continues" rel="nofollow" title="Big Tech companies are scooping up former DOJ-employees as antitrust fight continues"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/04/cap-build-2.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Revolving door.</p>
<p>The post <a href="https://reclaimthenet.org/big-tech-companies-are-scooping-up-former-doj-employees-as-antitrust-fight-continues" rel="nofollow">Big Tech companies are scooping up former DOJ-employees as antitrust fight continues</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Netflix’s Beef actor David Choe uses copyright strikes in an attempt to kill criticism
 - [https://reclaimthenet.org/choe-uses-copyright-strikes-in-an-attempt-to-kill-criticism](https://reclaimthenet.org/choe-uses-copyright-strikes-in-an-attempt-to-kill-criticism)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-04-19 15:31:14+00:00

<a href="https://reclaimthenet.org/choe-uses-copyright-strikes-in-an-attempt-to-kill-criticism" rel="nofollow" title="Netflix&#8217;s Beef actor David Choe uses copyright strikes in an attempt to kill criticism"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/04/david-choe.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>The DMCA is sometimes abused as a censorship tool.</p>
<p>The post <a href="https://reclaimthenet.org/choe-uses-copyright-strikes-in-an-attempt-to-kill-criticism" rel="nofollow">Netflix&#8217;s Beef actor David Choe uses copyright strikes in an attempt to kill criticism</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## SEC commissioner Hester Peirce says proposed Exchange Act changes threaten free speech
 - [https://reclaimthenet.org/sec-commissioner-says-exchange-act-changes-threaten-free-speech](https://reclaimthenet.org/sec-commissioner-says-exchange-act-changes-threaten-free-speech)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-04-19 15:18:38+00:00

<a href="https://reclaimthenet.org/sec-commissioner-says-exchange-act-changes-threaten-free-speech" rel="nofollow" title="SEC commissioner Hester Peirce says proposed Exchange Act changes threaten free speech"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/04/hester-pierce.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Ambiguous definitions.</p>
<p>The post <a href="https://reclaimthenet.org/sec-commissioner-says-exchange-act-changes-threaten-free-speech" rel="nofollow">SEC commissioner Hester Peirce says proposed Exchange Act changes threaten free speech</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Texas State University is sued over speech restrictions
 - [https://reclaimthenet.org/texas-state-university-is-sued-over-speech-restrictions](https://reclaimthenet.org/texas-state-university-is-sued-over-speech-restrictions)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-04-19 14:36:51+00:00

<a href="https://reclaimthenet.org/texas-state-university-is-sued-over-speech-restrictions" rel="nofollow" title="Texas State University is sued over speech restrictions"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/04/tex-schools-2.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Publicly funded universities are bound by The First Amendment.</p>
<p>The post <a href="https://reclaimthenet.org/texas-state-university-is-sued-over-speech-restrictions" rel="nofollow">Texas State University is sued over speech restrictions</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Canada’s Liberals shut down debate over online censorship plans
 - [https://reclaimthenet.org/canadas-liberals-shut-down-debate-over-online-censorship-plans](https://reclaimthenet.org/canadas-liberals-shut-down-debate-over-online-censorship-plans)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-04-19 14:19:07+00:00

<a href="https://reclaimthenet.org/canadas-liberals-shut-down-debate-over-online-censorship-plans" rel="nofollow" title="Canada&#8217;s Liberals shut down debate over online censorship plans"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/04/MP-Rachel-Thomas.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Plowing ahead and ignoring censorship concerns.</p>
<p>The post <a href="https://reclaimthenet.org/canadas-liberals-shut-down-debate-over-online-censorship-plans" rel="nofollow">Canada&#8217;s Liberals shut down debate over online censorship plans</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Private messaging apps push back against UK snooping proposals
 - [https://reclaimthenet.org/private-messaging-apps-push-back-against-uk-snooping-proposals](https://reclaimthenet.org/private-messaging-apps-push-back-against-uk-snooping-proposals)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-04-19 14:05:31+00:00

<a href="https://reclaimthenet.org/private-messaging-apps-push-back-against-uk-snooping-proposals" rel="nofollow" title="Private messaging apps push back against UK snooping proposals"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/04/signal-whats.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>The British Government wants to end private messaging.</p>
<p>The post <a href="https://reclaimthenet.org/private-messaging-apps-push-back-against-uk-snooping-proposals" rel="nofollow">Private messaging apps push back against UK snooping proposals</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

