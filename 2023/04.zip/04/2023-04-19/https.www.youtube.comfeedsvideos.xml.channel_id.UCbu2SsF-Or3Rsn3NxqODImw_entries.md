# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Bomb Rush Cyberfunk - Official Release Date Announcement Trailer
 - [https://www.youtube.com/watch?v=grWYPEdFB3Y](https://www.youtube.com/watch?v=grWYPEdFB3Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2023-04-19 16:44:06+00:00

Bomb Rush Cyberfunk is coming out on Steam & Nintendo Switch at 18 August 2023. 

Footage from this trailer has been captured on a Nintendo Switch 

The game will be available at other platforms at a later date.

music: kidkanevil - Big City Life ft OV (written by G. Roberts and P. Mukhi)

## LEGO Sonic the Hedgehog Sets - Announcement Trailer
 - [https://www.youtube.com/watch?v=cAG49lPdJTk](https://www.youtube.com/watch?v=cAG49lPdJTk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2023-04-19 13:41:26+00:00

A new adventure is building! Get ready for the all-new LEGO sets celebrating Sonic and his fast friends! From speeding along with the new Speed Sphere to slowing down and relaxing with a delicious chili dog, the opportunities are endless. With so many different possibilities, fun truly is infinite!

Wait...was that...?

## Advance Wars 1+2: Re-Boot Camp Review
 - [https://www.youtube.com/watch?v=g46lPRXIvoc](https://www.youtube.com/watch?v=g46lPRXIvoc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2023-04-19 13:00:36+00:00

Advance Wars 1+2: Re-Boot Camp's uneven campaigns are held up by rock-solid gameplay and a great presentation.

Advance Wars 1+2: Re-Boot Camp is a remake of 2001's Advance Wars and 2003's Advance Wars 2: Black Hole Rising. While the first Advance Wars hasn't aged as well as its sequel, both games are nevertheless elevated by Re-Boot Camp's robust suite of game modes, the local and online multiplayer, and an intuitive map editor. As a package, there is plenty to do, see, and unlock, and it's all held together by a fantastic presentation that evokes Saturday morning cartoons and colorful board games.

Advance Wars 1+2: Re-Boot Camp comes to Nintendo Switch on April 20, 2023.

#gamespot #gaming #advancewars

