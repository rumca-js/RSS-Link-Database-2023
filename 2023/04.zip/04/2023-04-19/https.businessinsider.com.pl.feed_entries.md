# Source:Business insider, URL:https://businessinsider.com.pl/.feed, language:en-US

## Kolejny pakiet broni dla Ukrainy od Amerykanów
 - [https://businessinsider.com.pl/wiadomosci/kolejny-pakiet-broni-dla-ukrainy-od-amerykanow/82q4d1b](https://businessinsider.com.pl/wiadomosci/kolejny-pakiet-broni-dla-ukrainy-od-amerykanow/82q4d1b)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 19:41:26+00:00

Biały Dom ogłosił w środę kolejny, 36. pakiet pomocy wojskowej dla Ukrainy. Jak zapowiedziała rzeczniczka Białego Domu Karine Jean-Pierre, będzie on zawierać m.in. amunicję do systemów HIMARS, amunicję artyleryjską i "systemy przeciwpancerne".

## Będzie dalszy ciąg rozmów z KE o imporcie z Ukrainy
 - [https://businessinsider.com.pl/biznes/bedzie-dalszy-ciag-rozmow-z-ke-o-imporcie-z-ukrainy/fns6g1m](https://businessinsider.com.pl/biznes/bedzie-dalszy-ciag-rozmow-z-ke-o-imporcie-z-ukrainy/fns6g1m)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 19:15:30+00:00

Rozmowy na temat importu produktów rolnych z Ukrainy, jakie prowadzili w środę z unijnymi komisarzami ds. rolnictwa i ds. handlu ministrowie z pięciu krajów UE, będą kontynuowane w przyszłym tygodniu — zapowiedział w środę w TVP1 minister rolnictwa Robert Telus.

## Ukraińska gospodarka w dramatycznej sytuacji. Tylko jeden sektor jakoś się trzyma
 - [https://businessinsider.com.pl/wiadomosci/ukrainska-gospodarka-w-dramatycznej-sytuacji-tylko-jeden-sektor-sie-trzyma/xlcjvf7](https://businessinsider.com.pl/wiadomosci/ukrainska-gospodarka-w-dramatycznej-sytuacji-tylko-jeden-sektor-sie-trzyma/xlcjvf7)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 18:14:35+00:00

Według danych Ministerstwa Gospodarki Ukrainy gospodarka dotkniętego wojną kraju skurczyła się w ciągu ostatniego roku o co najmniej 30 proc. Nawet 70 proc. mieszkańców żyje obecnie w ubóstwie, a według prognoz ministerstwa wkrótce kolejni Ukraińcy stracą pracę. Z opublikowanego w środę raportu fundacji World For Ukraine płyną pesymistyczne wnioski.

## Ekspert mówi o "cudzie nad Wisłą". Deweloperzy z rekordowymi zyskami, mimo kryzysu
 - [https://businessinsider.com.pl/gielda/wiadomosci/kryzys-w-mieszkaniowce-deweloperzy-z-rekordowymi-zyskami/rk8xxyz](https://businessinsider.com.pl/gielda/wiadomosci/kryzys-w-mieszkaniowce-deweloperzy-z-rekordowymi-zyskami/rk8xxyz)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 18:10:18+00:00

W mieszkaniówce był kryzys, ale nie w wynikach deweloperów. Czołówka firm notowanych na giełdzie pobiła rekord. Razem zarobili ponad 1,7 mld zł. Po rocznej przerwie na czoło stawki najbardziej dochodowych spółek powrócił Dom Development.

## Heineken coraz bliżej sprzedaży rosyjskiego biznesu
 - [https://businessinsider.com.pl/biznes/heineken-coraz-blizej-sprzedazy-rosyjskiego-biznesu/66gv396](https://businessinsider.com.pl/biznes/heineken-coraz-blizej-sprzedazy-rosyjskiego-biznesu/66gv396)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 17:58:34+00:00

Holenderski producent piwa Heineken zwrócił się do rosyjskich organów regulacyjnych o zgodę na sprzedaż swojego biznesu w Rosji. Spółka poinformowała o tym przy okazji publikacji wyników za I kwartał 2023 r.

## Tego elektrycznego malucha dostaniesz złożonego w paczce do samodzielnego złożenia
 - [https://businessinsider.com.pl/technologie/elektryczny-samochod-nie-musi-byc-drogi-luvly-dostaniesz-w-paczce-i-sam-zlozysz/hfbwqr5](https://businessinsider.com.pl/technologie/elektryczny-samochod-nie-musi-byc-drogi-luvly-dostaniesz-w-paczce-i-sam-zlozysz/hfbwqr5)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 17:32:47+00:00

Szwedzka Ikea rozpromowała meble do samodzielnego składania. Być może w przyszłości ulicami miast będą jeździły składane samochody elektryczne. Szedzki Luvly O ma kosztować 10 tys. euro i pozwalać na przejechanie do 100 km na jednym ładowaniu.

## Rosyjski import chipów się odrodził. Moskwa pozyskuje je okrężną drogą
 - [https://businessinsider.com.pl/biznes/rosyjski-import-chipow-sie-odrodzil-moskwa-pozyskuje-je-okrezna-droga/wxxcfrr](https://businessinsider.com.pl/biznes/rosyjski-import-chipow-sie-odrodzil-moskwa-pozyskuje-je-okrezna-droga/wxxcfrr)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 17:27:39+00:00

Instytucje handlowe w Stanach Zjednoczonych i Unii Europejskiej odnotowały gwałtowny wzrost ilości chipów i innych komponentów elektronicznych wysyłanych do Rosji przede wszystkim przez Armenię, Kazachstan i kilka innych krajów — podał "New York Times".

## Szalejące ceny materiałów budowlanych. Wiadomo, co odnotowało najwyższy wzrost
 - [https://businessinsider.com.pl/gospodarka/szalejace-ceny-materialow-budowlanych-wiadomo-co-odnotowalo-najwyzszy-wzrost/646f1cx](https://businessinsider.com.pl/gospodarka/szalejace-ceny-materialow-budowlanych-wiadomo-co-odnotowalo-najwyzszy-wzrost/646f1cx)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 16:44:16+00:00

Planujesz remont lub budowę? Przygotuj się na duże wydatki. Inflacja szaleje, a z nią ceny materiałów budowlanych. Średnie podwyżki wynoszą 14 proc., ale są produkty, których ceny podskoczyły w rok o 44 proc. Jest za to jedna grupa, w której jest taniej.

## Oto najdroższe i najtańsze miejsca do odwiedzin w 2023 r.
 - [https://businessinsider.com.pl/wiadomosci/gdzie-jechac-na-wakacje-oto-najdrozsze-i-najtansze-miejsca-w-2023-r/kwr3ksf](https://businessinsider.com.pl/wiadomosci/gdzie-jechac-na-wakacje-oto-najdrozsze-i-najtansze-miejsca-w-2023-r/kwr3ksf)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 16:31:16+00:00

Planujących najbliższe wakacje może zainteresować najnowszy ranking "Traveller’s Elixir", o którym informuje belgijski dziennik "Le Soir". Portal dokonał zestawienia najtańszych i najdroższych miejsc do odwiedzenia w tym roku.

## USA wprowadzają nowe sankcje przeciwko producentom irańskich dronów
 - [https://businessinsider.com.pl/wiadomosci/usa-wprowadzaja-nowe-sankcje-przeciwko-producentom-iranskich-dronow/pr54kxp](https://businessinsider.com.pl/wiadomosci/usa-wprowadzaja-nowe-sankcje-przeciwko-producentom-iranskich-dronow/pr54kxp)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 16:12:13+00:00

Amerykański resort finansów ogłosił w środę kolejny pakiet sankcji przeciwko Iranowi, wymierzonych w sieć irańskich podmiotów zaopatrujących wbrew dotychczasowym ograniczeniom irański przemysł zbrojeniowy i program budowy dronów. Na czarną listę trafiły firmy sprowadzające elektronikę z Chin, Hongkongu i Malezji.

## Niemiecki gigant zbuduje fabrykę w Polsce. To setki miejsc pracy
 - [https://businessinsider.com.pl/biznes/niemiecki-gigant-zbuduje-fabryke-w-polsce-zobacz-ile-powstanie-nowych-miejsc-pracy/dgg6xgq](https://businessinsider.com.pl/biznes/niemiecki-gigant-zbuduje-fabryke-w-polsce-zobacz-ile-powstanie-nowych-miejsc-pracy/dgg6xgq)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 16:07:28+00:00

Niemiecki koncern Bosch zainwestuje 1,2 mld zł w budowę fabryki pomp ciepła w Dobromierzu (Dolnośląskie). W nowym zakładzie do 2027 r. ma być zatrudnionych 500 osób. Premier Mateusz Morawiecki wskazał, że ta inwestycja to nie tylko szansa dla regionu wałbrzyskiego, ale też dla całego kraju.

## Młodzi Polacy chcą otwierać firmy. Mają jednak duże obawy o dwa ważne czynniki
 - [https://businessinsider.com.pl/biznes/mlodzi-polacy-chca-otwierac-firmy-maja-jednak-duze-obawy-o-dwa-wazne-czynniki/qtefdq0](https://businessinsider.com.pl/biznes/mlodzi-polacy-chca-otwierac-firmy-maja-jednak-duze-obawy-o-dwa-wazne-czynniki/qtefdq0)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 15:50:33+00:00

Ponad połowa młodych Polaków chce mieć własną firmę, ale tylko mała część z nich podejmuje w tej sprawie konkretne działania — mówi w rozmowie z Interią dr Artur Domurat z Instytutu Psychologii Wydziału Nauk Społecznych Uniwersytetu Śląskiego.

## "Bank szpiegów" wynosi się z Budapesztu. Znamy miejsce nowej siedziby
 - [https://businessinsider.com.pl/wiadomosci/bank-szpiegow-wynosi-sie-z-budapesztu-znamy-nowe-miejsce/mxq14z4](https://businessinsider.com.pl/wiadomosci/bank-szpiegow-wynosi-sie-z-budapesztu-znamy-nowe-miejsce/mxq14z4)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 15:16:29+00:00

W związku z objęciem przez USA sankcjami Międzynarodowego Banku Inwestycyjnego (IIB), nazywanego często rosyjskim "bankiem szpiegów", instytucja rozpoczęła proces przenosin swojej siedziby z Budapesztu do Rosji — poinformował bank na swojej stronie internetowej.

## Rusza sezon wycieczkowców w Porcie Gdańsk. Oto plany na ten rok
 - [https://businessinsider.com.pl/wiadomosci/rusza-sezon-wycieczkowcow-w-porcie-gdansk-oto-plany-na-ten-rok/4gt9cy0](https://businessinsider.com.pl/wiadomosci/rusza-sezon-wycieczkowcow-w-porcie-gdansk-oto-plany-na-ten-rok/4gt9cy0)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 14:54:28+00:00

W czwartek rozpocznie się sezon wycieczkowców w Porcie Gdańsk. W tym roku planujemy 46 zawinięć jednostek wycieczkowych — zapowiedział Michał Stupak z Portu Gdańsk.

## Polski bank przyznaje, że od wielu godzin odpiera ataki hakerów
 - [https://businessinsider.com.pl/technologie/masz-problem-z-dostepem-do-konta-polski-bank-na-celowniku-hakerow/48tnl88](https://businessinsider.com.pl/technologie/masz-problem-z-dostepem-do-konta-polski-bank-na-celowniku-hakerow/48tnl88)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 14:46:18+00:00

Bank Ochrony Środowiska od godzin porannych identyfikuje różnego rodzaju ataki hakerskie na usługi bankowości elektronicznej — przyznają przedstawiciele banku. Z tego względu czasowo klienci mogą mieć problemy z dostępem do niektórych usług. Podpowiadamy, co w takiej sytuacji można zrobić.

## Kreml obawia się uzależnienia od Chin. Wyciekła notatka
 - [https://businessinsider.com.pl/wiadomosci/kreml-obawia-sie-uzaleznienia-od-chin-wyciekla-notatka/ppp8qkg](https://businessinsider.com.pl/wiadomosci/kreml-obawia-sie-uzaleznienia-od-chin-wyciekla-notatka/ppp8qkg)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 14:40:10+00:00

Rosja zapędziła się w kozi róg — twierdzą europejscy urzędnicy, którzy mieli dostęp do niepublikowanego raportu rosyjskiego rządu. Wynika z niego, że Rosja starała się pozyskać z Chin technologie, a jednocześnie zauważała, że przy sankcjach nie może już skorzystać z innej oferty. Sama nie produkuje przy tym urządzeń zaawansowanych technologii. Urzędnicy na Kremlu obawiają się, że Chiny zdominują rosyjski rynek i staną się w przyszłości zagrożeniem bezpieczeństwa Federacji.

## Wśród śmieci w oceanach żyją bezkręgowce. Wiele z nich to gatunki przybrzeżne
 - [https://businessinsider.com.pl/wiadomosci/wsrod-smieci-w-oceanach-zyja-bezkregowce-wiele-z-nich-to-gatunki-przybrzezne/d2q015b](https://businessinsider.com.pl/wiadomosci/wsrod-smieci-w-oceanach-zyja-bezkregowce-wiele-z-nich-to-gatunki-przybrzezne/d2q015b)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 14:13:26+00:00

Wielka Pacyficzna Plama Śmieci to tak naprawdę wyjątkowy oceaniczny ekosystem pełen stworzeń, które przywierają do plastikowych odpadów. Według najnowszych badań wiele gatunków przybrzeżnych żyje tam obok zwierząt, które funkcjonują na otwartym oceanie. W ten sposób śmieci połączyły gatunki, które w przeszłości raczej się nie spotykały.

## Ten laptop może trafić za darmo do uczniów. Minister podał koszt jednego komputera
 - [https://businessinsider.com.pl/wiadomosci/darmowy-laptop-dla-uczniow-oto-parametry-i-cena/1j4fsm1](https://businessinsider.com.pl/wiadomosci/darmowy-laptop-dla-uczniow-oto-parametry-i-cena/1j4fsm1)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 14:05:59+00:00

Prawie 3 tys. zł brutto będzie kosztował podatników jeden laptop, który prawdopodobnie otrzymają uczniowie czwartych klas w tym roku. Łączny koszt około 370 tys. komputerów przekroczy 1 mld zł. Z danych ujawnionych przez ministra cyfryzacji wiadomo, jaki dokładniej sprzęt dostaną dzieci.

## Gwałtowny spadek cen ropy i gazu. Rynek zmienił kierunek
 - [https://businessinsider.com.pl/gielda/wiadomosci/gwaltowny-spadek-cen-ropy-i-gazu-rynek-zmienil-kierunek/xts6s7e](https://businessinsider.com.pl/gielda/wiadomosci/gwaltowny-spadek-cen-ropy-i-gazu-rynek-zmienil-kierunek/xts6s7e)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 13:44:28+00:00

Słowa członka grona decyzyjnego amerykańskiej Rezerwy Federalnej wpłynęły na znaczące spadki cen ropy. To zniwelowało efekt cięcia produkcji przez kraje OPEC+. Wkrótce możemy mieć taniej na stacjach. W podobnym stopniu staniał też gaz.

## Minister Moskwa krytycznie o "Fit for 55": Polska nie poprze żadnego z przyjętych we wtorek aktów prawnych
 - [https://businessinsider.com.pl/wiadomosci/moskwa-o-fit-for-55-polska-nie-poprze-zadnego-z-aktow-przyjetych-we-wtorek-przez-pe/76kyhe5](https://businessinsider.com.pl/wiadomosci/moskwa-o-fit-for-55-polska-nie-poprze-zadnego-z-aktow-przyjetych-we-wtorek-przez-pe/76kyhe5)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 13:32:30+00:00

Polska nie poprze w Radzie UE żadnego z aktów prawnych, które zostały we wtorek przyjęte przez Parlament Europejski w związku z pakietem "Fit for 55" — zapowiedziała w rozmowie z portalem i.pl minister klimatu i środowiska Anna Moskwa.

## Są cechy osobowości, które sprzyjają długowieczności. To wnioski m.in. z badania, które trwało 70 lat
 - [https://businessinsider.com.pl/rozwoj-osobisty/zdrowie/dlugowiecznosc-jak-zachowac-zdrowie-i-dlugo-zyc/tmk45qm](https://businessinsider.com.pl/rozwoj-osobisty/zdrowie/dlugowiecznosc-jak-zachowac-zdrowie-i-dlugo-zyc/tmk45qm)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 13:16:00+00:00

Jesteś przyjacielski? Otwarty? Stabilny emocjonalnie? Liczne badania, w których wzięli udział starsi ludzie na całym świecie, pokazują, że właśnie te cechy osobowości związane są z dłuższym życie.

## Istnieją trzy typy złych szefów. Oto jak sobie z nimi radzić
 - [https://businessinsider.com.pl/rozwoj-osobisty/kariera/trzy-typy-zlych-szefow-oto-jak-sobie-z-nimi-radzic/3g4k31c](https://businessinsider.com.pl/rozwoj-osobisty/kariera/trzy-typy-zlych-szefow-oto-jak-sobie-z-nimi-radzic/3g4k31c)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 13:15:00+00:00

Często nie wiemy, co robić, gdy szef, dla którego pracujemy, okazuje się nie grzeszyć inteligencją. Ignorowanie go i kontakt z wyższym w hierarchii przełożonym może wywołać niechciane konsekwencje, a bezpośrednia konfrontacja nie zawsze się opłaca. Jak sobie więc z nimi radzić?

## Fox News zapłaci za kłamstwa na temat wyborów. Ugoda warta setki milionów dolarów
 - [https://businessinsider.com.pl/wiadomosci/fox-news-zaplaci-za-klamstwa-na-temat-falszerstw-wyborczych-ugoda-warta-setki/kvzejx3](https://businessinsider.com.pl/wiadomosci/fox-news-zaplaci-za-klamstwa-na-temat-falszerstw-wyborczych-ugoda-warta-setki/kvzejx3)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 13:13:48+00:00

Fox News tuż przed procesem zawarł ugodę z Dominion Voting Systems. Stacja przyznała się do powielania teorii spiskowych na temat fałszerstw wyborczych i zgodziła się zapłacić ponad 787 mln dol.

## Wizz Air wprowadza innowacyjną usługę. Płacisz raz, latasz do woli
 - [https://businessinsider.com.pl/technologie/wizz-air-wprowadza-innowacyjna-usluge-bedzie-abonament-na-loty/m8grg13](https://businessinsider.com.pl/technologie/wizz-air-wprowadza-innowacyjna-usluge-bedzie-abonament-na-loty/m8grg13)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 13:08:38+00:00

Wizz Air stara się zachęcić klientów do wybierania właśnie tej linii lotniczej i wprowadza abonament, dzięki któremu będzie można za stałą miesięczną opłatą podróżować. Polska będzie pierwszym krajem, w którym zostanie przetestowana ta opcja.

## Można negocjować zniżkę na mieszkanie. Ta sytuacja zwiększa różnice w cenach
 - [https://businessinsider.com.pl/nieruchomosci/przerazaja-cie-ceny-mieszkan-zobacz-ile-mozna-wynegocjowac/9n0f7vq](https://businessinsider.com.pl/nieruchomosci/przerazaja-cie-ceny-mieszkan-zobacz-ile-mozna-wynegocjowac/9n0f7vq)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 13:05:52+00:00

Spowolnienie gospodarcze zwiększy różnice między cenami mieszkań w ofertach i ostatecznymi stawkami, po których można kupić własne "M" — wskazują ekonomiści. To zjawisko ma być widoczne zarówno w przypadku nowych lokali od deweloperów, jak i mieszkań z drugiej ręki.

## Ekspert wskazuje największy błąd mowy ciała, jaki można popełnić
 - [https://businessinsider.com.pl/rozwoj-osobisty/mowa-ciala-i-kontakt-wzrokowy-jak-ja-odczytac/jtx7qem](https://businessinsider.com.pl/rozwoj-osobisty/mowa-ciala-i-kontakt-wzrokowy-jak-ja-odczytac/jtx7qem)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 12:55:00+00:00

Jeśli chodzi o język mowy ciała, istnieje kilka poważnych błędów, które możemy popełnić nawet nieświadomie. Niektóre z nich mogą nas sporo kosztować, zwłaszcza gdy chcemy wywrzeć dobre wrażenie. Amerykański Business Insider zapytał dr Lillian Glass, specjalistkę od komunikacji i mowy ciała oraz autorkę książki "Toksyczni ludzie" ("Toxic People"), aby dowiedzieć się, który błąd może najbardziej zaszkodzić.

## Gazprom straszy Europę. "Niebanalne zadanie dla europejskich firm"
 - [https://businessinsider.com.pl/wiadomosci/gazprom-straszy-europe-niebanalne-zadanie-dla-europejskich-firm/n9bn0z3](https://businessinsider.com.pl/wiadomosci/gazprom-straszy-europe-niebanalne-zadanie-dla-europejskich-firm/n9bn0z3)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 12:54:31+00:00

Gazprom kreśli czarny scenariusz dla Europy, zgodnie z którym w kolejnym sezonie zimowym miałoby zabraknąć gazu. Według informacji rosyjskiego koncernu w europejskich magazynach jest zbyt mały zapas, a brak możliwości uzupełnienia go o gaz z Rosji może okazać się sporym problemem.

## Fiskus może zainteresować się prezentami na pierwszą komunię. O tych limitach warto pamiętać
 - [https://businessinsider.com.pl/poradnik-finansowy/prezenty-na-pierwsza-komunie-pod-lupa-fiskusa-o-tych-limitach-warto-pamietac/2c0smcd](https://businessinsider.com.pl/poradnik-finansowy/prezenty-na-pierwsza-komunie-pod-lupa-fiskusa-o-tych-limitach-warto-pamietac/2c0smcd)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 12:15:31+00:00

Drogi prezent na pierwszą komunię ucieszy dziecko, ale może być problematyczny dla rodziców. Może z nim wiązać się obowiązek podatkowy i konieczność zgłoszenia do fiskusa. Kogo dotyczy i co zrobić? Podpowiadamy.

## W tej miejscowości mieszkania nad Bałtykiem są najdroższe. To nie Sopot
 - [https://businessinsider.com.pl/poradnik-finansowy/ceny-mieszkan-nad-morzem-baltyckim-wcale-nie-sopot/7hg3j8z](https://businessinsider.com.pl/poradnik-finansowy/ceny-mieszkan-nad-morzem-baltyckim-wcale-nie-sopot/7hg3j8z)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 11:53:00+00:00

Ocieplenie klimatu, wysoki kurs euro i doświadczenia z pandemii sprawiły, że coraz więcej Polaków wybiera odpoczynek nad Bałtykiem. Dla wielu wypoczynek w urokliwym miejscu staje się inspiracją do zmian i kupna własnego lokum w ulubionym, nadmorskim kurorcie. Sprawdziliśmy, jak kształtują się ceny używanych mieszkań i apartamentów w najpopularniejszych miejscowościach wypoczynkowych nad Bałtykiem.

## Gigantyczna kara dla Biedronki. Sieć reaguje [TYLKO U NAS]
 - [https://businessinsider.com.pl/gospodarka/gigantyczna-kara-dla-biedronki-siec-reaguje/xppxy3d](https://businessinsider.com.pl/gospodarka/gigantyczna-kara-dla-biedronki-siec-reaguje/xppxy3d)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 11:48:06+00:00

Sąd Ochrony Konkurencji i Konsumentów podtrzymał 60 mln zł kary dla Biedronki. Mamy odpowiedź firmy na tę decyzję i wiemy, jakie kroki teraz planuje.

## Wyciekły chińskie plany. Chcą stworzyć niezwykły sprzęt szpiegowski
 - [https://businessinsider.com.pl/technologie/wyciekly-chinskie-plany-chca-stworzyc-niezwykly-sprzet-szpiegowski/wfhls0x](https://businessinsider.com.pl/technologie/wyciekly-chinskie-plany-chca-stworzyc-niezwykly-sprzet-szpiegowski/wfhls0x)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 11:46:22+00:00

Wyciekły dokumenty, które ujawniają plany Chin dotyczące drona szpiegowskiego. Mógłby lecieć z prędkością trzykrotnie wyższą od prędkości dźwięku.

## Elon Musk uważa, że rząd musi mieć "jakiś plan awaryjny", by wyłączyć AI, jeśli stanie się zbyt potężna
 - [https://businessinsider.com.pl/technologie/nowe-technologie/elon-musk-uwaza-ze-rzad-musi-miec-jakis-plan-awaryjny-by-wylaczyc-ai-jesli-stanie-sie/sn7m3m0](https://businessinsider.com.pl/technologie/nowe-technologie/elon-musk-uwaza-ze-rzad-musi-miec-jakis-plan-awaryjny-by-wylaczyc-ai-jesli-stanie-sie/sn7m3m0)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 11:38:24+00:00

Elon Musk stwierdził, że rząd musi być przygotowany na interwencję, jeśli sztuczna inteligencja wymknie się spod kontroli.

## Rząd Węgier zakazuje importu nie tylko zboża, ale także mięsa i jaj z Ukrainy
 - [https://businessinsider.com.pl/gospodarka/rzad-wegier-zakazuje-importu-nie-tylko-zboza-ale-takze-miesa-i-jaj-z-ukrainy/jm87pkc](https://businessinsider.com.pl/gospodarka/rzad-wegier-zakazuje-importu-nie-tylko-zboza-ale-takze-miesa-i-jaj-z-ukrainy/jm87pkc)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 11:23:12+00:00

Rząd Węgier wprowadził zakaz importu szeregu produktów rolno-spożywczych z Ukrainy — wynika z dekretu opublikowanego w dzienniku urzędowym "Magyar Kozlony".  Na liście znalazły się m.in. mięso, jaja, chleb i wino.

## KE reaguje na kryzys zbożowy. Cztery produkty pod szczególną obserwacją
 - [https://businessinsider.com.pl/wiadomosci/ke-bierze-sie-za-kryzys-zbozowy-cztery-produkty-pod-szczegolna-obserwacja/0dpxxg7](https://businessinsider.com.pl/wiadomosci/ke-bierze-sie-za-kryzys-zbozowy-cztery-produkty-pod-szczegolna-obserwacja/0dpxxg7)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 11:12:05+00:00

Szefowa KE Ursula von der Leyen odpowiedziała w środę na list pięciu przywódców państw UE w sprawie ukraińskiego zboża. Podkreśliła, że potrzebne jest wspólne europejskie podejście w tej sprawie — przekazała dziennikarzom w Brukseli rzeczniczka KE Dana Spinant.

## Te dwie opaski potrafią wiele. Możne je kupić w cenach do 150 zł
 - [https://businessinsider.com.pl/technologie/nowe-technologie/te-dwie-opaski-potrafia-wiele-mozne-je-kupic-w-cenach-do-150-zl/4gjsp9x](https://businessinsider.com.pl/technologie/nowe-technologie/te-dwie-opaski-potrafia-wiele-mozne-je-kupic-w-cenach-do-150-zl/4gjsp9x)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 10:44:00+00:00

Nie trzeba wydawać setek lub nawet tysięcy złotych, aby zaopatrzyć się w urządzenie monitorujące codzienne aktywności, tętno, sen, a nawet natlenienie krwi. Te dwa produkty typu smartband posiadają wiele ciekawych funkcji. W dodatku opisane modele można nabyć w cenach do 150 zł.

## Związek Banków Polskich po 20 latach rządów Krzysztofa Pietraszkiewicza ma nowego prezesa
 - [https://businessinsider.com.pl/finanse/po-20-latach-zmienil-sie-prezes-zwiazku-bankow-polski-wybrano-nastepce-krzysztofa/z8nc8dy](https://businessinsider.com.pl/finanse/po-20-latach-zmienil-sie-prezes-zwiazku-bankow-polski-wybrano-nastepce-krzysztofa/z8nc8dy)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 10:26:59+00:00

Krzysztof Pietraszkiewicz po 20 latach bycia prezesem i 32 latach pracy w Związku Banków Polskich przechodzi na emeryturę. W środę rozszerzono zarząd do czterech osób, powołano dwóch nowych przedstawicieli i wybrano prezesa.

## Nie działa strona kolejnego dużego banku
 - [https://businessinsider.com.pl/wiadomosci/nie-dziala-strona-kolejnego-duzego-banku/ywb4np5](https://businessinsider.com.pl/wiadomosci/nie-dziala-strona-kolejnego-duzego-banku/ywb4np5)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 09:57:22+00:00

W środę 19 kwietnia w godzinach przedpołudniowych przestała działać strona internetowa Raiffeisen Banku. Po wejściu na nią internauci otrzymują komunikat o przerwie technicznej bądź też całkowitej niedostępności serwisu.

## Nie działa strona kolejnego dużego banku
 - [https://businessinsider.com.pl/wiadomosci/nie-dziala-strona-kolejnego-duzego-banku-klientom-wyswietla-sie-komunikat/ywb4np5](https://businessinsider.com.pl/wiadomosci/nie-dziala-strona-kolejnego-duzego-banku-klientom-wyswietla-sie-komunikat/ywb4np5)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 09:57:22+00:00

W środę 19 kwietnia w godzinach przedpołudniowych przestała działać strona internetowa Raiffeisen Banku. Po wejściu na nią internauci otrzymują komunikat o przerwie technicznej bądź też całkowitej niedostępności serwisu.

## Szef wywiadu Ukrainy powiedział, kiedy skończy się wojna. Zaskakująca deklaracja
 - [https://businessinsider.com.pl/wiadomosci/szef-wywiadu-ukrainy-powiedzial-kiedy-skonczy-sie-wojna-zaskakujaca-deklaracja/77gsg7j](https://businessinsider.com.pl/wiadomosci/szef-wywiadu-ukrainy-powiedzial-kiedy-skonczy-sie-wojna-zaskakujaca-deklaracja/77gsg7j)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 09:54:30+00:00

Szef wywiadu Ukrainy Kyryło Budanow już przed atakiem Rosji ostrzegał przed wojną, a w trakcie jej trwania trafnie przewidywał niektóre jej etapy. Tym razem zabrał głos w sprawie końca walk.

## Polska spada w rankingu najwyższej inflacji w Unii. Węgry liderem
 - [https://businessinsider.com.pl/gospodarka/polska-coraz-nizej-w-rankingu-najwyzszej-inflacji-w-unii-wegry-liderem/r8kcw1x](https://businessinsider.com.pl/gospodarka/polska-coraz-nizej-w-rankingu-najwyzszej-inflacji-w-unii-wegry-liderem/r8kcw1x)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 09:41:39+00:00

Ceny wciąż rosną u nas szybko, ale pojawiły się dane, które mogą dać jakieś pocieszenie. Okazuje się, że postępem drożyzny wyprzedza nas coraz więcej państw. W marcu spadliśmy na ósme miejsce w Europie i szóste w Unii pod względem najwyższej inflacji.

## Polska spada w rankingu najwyższej inflacji w Unii. Węgry liderem
 - [https://businessinsider.com.pl/gospodarka/najwyzsza-inflacja-w-unii-polska-coraz-dalej-w-rankingu/r8kcw1x](https://businessinsider.com.pl/gospodarka/najwyzsza-inflacja-w-unii-polska-coraz-dalej-w-rankingu/r8kcw1x)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 09:41:39+00:00

Ceny wciąż rosną u nas szybko, ale pojawiły się dane, które mogą dać jakieś pocieszenie. Okazuje się, że postępem drożyzny wyprzedza nas coraz więcej państw. W marcu spadliśmy na ósme miejsce w Europie i szóste w Unii pod względem najwyższej inflacji.

## Polska wyżej w rankingu inflacji w Europie. Turcja i Węgry negatywnymi liderami
 - [https://businessinsider.com.pl/gospodarka/najwyzsza-inflacja-w-europie-polska-coraz-wyzej-w-rankingu/r8kcw1x](https://businessinsider.com.pl/gospodarka/najwyzsza-inflacja-w-europie-polska-coraz-wyzej-w-rankingu/r8kcw1x)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 09:41:39+00:00

Ceny wciąż rosną u nas szybko, ale pojawiły się dane, które mogą dać jakieś pocieszenie. Okazuje się, że postępem drożyzny wyprzedza nas coraz więcej państw. W marcu awansowaliśmy na ósme miejsce od końca w Europie i szóste od końca w Unii pod względem inflacji.

## Rosyjskie "statki widma" krążą po Bałtyku. Co knują ludzie Putina?
 - [https://businessinsider.com.pl/wiadomosci/rosyjskie-statki-widma-kraza-po-baltyku-co-knuja-ludzie-putina/d273ney](https://businessinsider.com.pl/wiadomosci/rosyjskie-statki-widma-kraza-po-baltyku-co-knuja-ludzie-putina/d273ney)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 09:17:52+00:00

Na wodach wokół Danii, Szwecji, Norwegii oraz Finlandii — w tym na Morzu Bałtyckim — rosyjskie "statki widma" przygotowują możliwe działania sabotażowe wymierzone w morskie elektrownie wiatrowe, podwodne rurociągi i kable energetyczne — ujawniły w środę telewizje publiczne państw nordyckich.

## Złe wieści dla polskich imigrantów. Inflacja w Wielkiej Brytanii najwyższa w zachodniej Europie
 - [https://businessinsider.com.pl/gospodarka/inflacja-w-wielkiej-brytanii-najwyzsza-w-zachodniej-europie-zle-wiesci-dla-polskich/66vwl4y](https://businessinsider.com.pl/gospodarka/inflacja-w-wielkiej-brytanii-najwyzsza-w-zachodniej-europie-zle-wiesci-dla-polskich/66vwl4y)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 09:11:03+00:00

Ekonomiści prognozowali, że od marca w Wielkiej Brytanii roczna inflacja będzie już jednocyfrowa. Rozczarowali się. Dane biura statystycznego pokazują tylko lekki ruch w dół. Inflacja wyniosła 10,1 proc. rok do roku. Prognozy były dokładnie tak samo nietrafione jak w przypadku Polski. Płace rosną dużo wolniej od inflacji i siła nabywcza m.in. polskich imigrantów jest coraz niższa. Bardzo szybko drożała żywność.

## Nowy kosmiczny biznes. Balonem do stratosfery
 - [https://businessinsider.com.pl/technologie/nowe-technologie/nowy-kosmiczny-biznes-balonem-do-stratosfery/8ytmj93](https://businessinsider.com.pl/technologie/nowe-technologie/nowy-kosmiczny-biznes-balonem-do-stratosfery/8ytmj93)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 09:03:22+00:00

Wyścig kosmiczny właśnie zyskał nowego uczestnika. Francuska firma Zephalto oferuje pasażerom możliwość podróży balonem do stratosfery — pisze w środę Bloomberg. Ceny zaczynają się od 120 tys. euro za osobę w 2025 r., a pasażerowie lotu zostaną uraczeni doskonałym francuskim winem i jedzeniem.

## Kiedy rolnicy dostaną dopłaty za zboże? Minister odpowiada
 - [https://businessinsider.com.pl/wiadomosci/program-doplat-za-zboze-kiedy-rolnicy-dostana-pieniadze-minister-odpowiada/9txsjs2](https://businessinsider.com.pl/wiadomosci/program-doplat-za-zboze-kiedy-rolnicy-dostana-pieniadze-minister-odpowiada/9txsjs2)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 08:31:29+00:00

Minister rolnictwa i rozwoju wsi Robert Telus zapytany został w Radiu Zet o to, kiedy do rolników popłynął pierwsze dopłaty za zboże.— Chciałbym, żeby na najbliższej Radzie Ministrów, a może nawet i wcześniej, ale we wtorek, program był przygotowany — odpowiedział.

## Jak zboże przejedzie przez Polskę? Minister rozwoju tłumaczy, kto zabezpieczy konwój
 - [https://businessinsider.com.pl/prawo/jak-zboze-przejedzie-przez-polske-minister-rozwoju-tlumaczy-kto-zabezpieczy-konwoj/l1yv24y](https://businessinsider.com.pl/prawo/jak-zboze-przejedzie-przez-polske-minister-rozwoju-tlumaczy-kto-zabezpieczy-konwoj/l1yv24y)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 08:27:39+00:00

Przez pierwszy tydzień od wznowienia tranzytu, funkcjonariusze KAS będą konwojować pojazdy do miejsca docelowego — mówi Waldemar Buda, minister rozwoju i technologii w rozmowie z Business Insider. Jego zdaniem oprócz wprowadzenia do prawa UE wypracowanych przez Polskę mechanizmów, trzeba stworzyć system, który równomiernie rozprowadza towary po całej Unii.

## Nieoficjalnie: zamiast zakazów wwozu zboża rozwiązanie na poziomie UE
 - [https://businessinsider.com.pl/wiadomosci/zboze-z-ukrainy-komisja-europejska-szykuje-rozwiazanie-chodzi-min-o-polske/z9lk89x](https://businessinsider.com.pl/wiadomosci/zboze-z-ukrainy-komisja-europejska-szykuje-rozwiazanie-chodzi-min-o-polske/z9lk89x)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 08:09:00+00:00

Komisja Europejska jest gotowa wprowadzić zakaz importu pszenicy, kukurydzy, słonecznika i rzepaku — dowiedziała się brukselska korespondentka Polskiego Radia Beata Płomecka.

## Użytkowników już sześć razy więcej niż mieszkańców Polski. Netflix zaskoczył wynikami
 - [https://businessinsider.com.pl/gielda/wiadomosci/netflix-zaskoczyl-wynikami-uzytkownikow-szesc-razy-wiecej-niz-mieszkancow-polski/9lh4h99](https://businessinsider.com.pl/gielda/wiadomosci/netflix-zaskoczyl-wynikami-uzytkownikow-szesc-razy-wiecej-niz-mieszkancow-polski/9lh4h99)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 07:58:43+00:00

Rynek nie oczekiwał niczego dobrego po wynikach Netfliksa za pierwszy kwartał, ale największa platforma streamingowa pozytywnie zaskoczyła. Mimo zaostrzającej się konkurencji, klientów przybyło prawie dwa miliony, głównie w Europie i Azji. Przed publikacją danych trwała wyprzedaż akcji, ale zaraz po niej nastąpił zwrot o 180 stopni.

## Będą inne oznaczenia na butelkach i puszkach z piwem. W tym zupełna nowość
 - [https://businessinsider.com.pl/wiadomosci/beda-inne-oznaczenia-na-butelkach-i-puszkach-z-piwem-w-tym-zupelna-nowosc/07cepxh](https://businessinsider.com.pl/wiadomosci/beda-inne-oznaczenia-na-butelkach-i-puszkach-z-piwem-w-tym-zupelna-nowosc/07cepxh)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 07:51:25+00:00

Po raz pierwszy od 2013 r. zmienią się oznaczenia na opakowaniach piw. Zarówno tych z alkoholem, jak i bezalkoholowych. "Zdecydowaliśmy się na uproszczenie znaków oraz jednoczesne stosowanie wszystkich trzech ikon na każdym opakowaniu piwa alkoholowego" — mówi cytowany w komunikacie Bartłomiej Morzycki, dyrektor generalny Związku.

## To będzie nowy najludniejszy kraj na świecie. "Symbol postępu, rozwoju i aspiracji"
 - [https://businessinsider.com.pl/wiadomosci/indie-wyprzedza-chiny-i-beda-najludniejszym-krajem-swiata-symbol-postepu-rozwoju-i/21n2z6k](https://businessinsider.com.pl/wiadomosci/indie-wyprzedza-chiny-i-beda-najludniejszym-krajem-swiata-symbol-postepu-rozwoju-i/21n2z6k)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 07:46:17+00:00

Indie mają wyprzedzić Chiny o 2,9 mln osób w połowie 2023 r. Fundusz Ludnościowy Narodów Zjednoczonych (UNFPA) oszacował, że populacja Indii wkrótce wyniesie 1,4286 mld osób, a Chin — 1,4257 mld.

## Reckitt ze świetnymi wynikami w obszarze równości płci wobec płac
 - [https://businessinsider.com.pl/firmy/dla-firm/reckitt-ze-swietnymi-wynikami-w-obszarze-rownosci-plci-wobec-plac/jw8fd58](https://businessinsider.com.pl/firmy/dla-firm/reckitt-ze-swietnymi-wynikami-w-obszarze-rownosci-plci-wobec-plac/jw8fd58)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 07:44:55+00:00

W roku 2022 na rynku polskim mediana różnic w wynagrodzeniu kobiet i mężczyzn w Reckitt wyniosła -4.6% (-4.7% w 2021 r.) na korzyść kobiet, podczas gdy różnica luki premiowej osiągnęła poziom -0.5% na korzyść kobiet (-0.6% w 2021 r.). Tym samym Reckitt zadaje kłam przewidywaniom, mówiącym o tym, że pod kątem równości płac mężczyźni zostaną dogonieni przez kobiety dopiero za 132 lata.

## Tak Rosja zakłócała transmisje ze Starlinków w Ukrainie. Wyciekły dokumenty wywiadu
 - [https://businessinsider.com.pl/wiadomosci/rosja-zaklocala-transmisje-ze-starlinkow-w-ukrainie-wyciekly-dokumenty-wywiadu/q7yy683](https://businessinsider.com.pl/wiadomosci/rosja-zaklocala-transmisje-ze-starlinkow-w-ukrainie-wyciekly-dokumenty-wywiadu/q7yy683)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 07:31:43+00:00

Rosja dąży do zakłócenia działania satelitów Starlink, wykorzystywanych przez ukraińską armię. W tym celu przez kilka miesięcy eksperymentowała z systemem walki elektronicznej Toboł - pisze "Washington Post" omawiając kolejne dokumenty amerykańskiego wywiadu, które wyciekły do sieci.

## Złap oddech w polskich górach. Polecamy trzy hotele ze SPA przy szlakach
 - [https://businessinsider.com.pl/lifestyle/podroze/zlap-oddech-w-polskich-gorach-polecamy-trzy-hotele-ze-spa-przy-szlakach/zym2qm7](https://businessinsider.com.pl/lifestyle/podroze/zlap-oddech-w-polskich-gorach-polecamy-trzy-hotele-ze-spa-przy-szlakach/zym2qm7)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 07:28:00+00:00

Jeśli planujesz wiosenny wyjazd, chcesz odpocząć i „naładować baterie” lub wręcz przeciwnie, chcesz aktywnie spędzić czas na długich górskich wędrówkach, ten artykuł jest dla ciebie. Polecamy w nim — malowniczo położone w górach, w niedalekiej odległości od szlaków i doceniane przez gości — hotele ze SPA. Wszystkie prezentowane obiekty oferują piękny widok z okien, liczne atrakcje, wyśmienitą kuchnię i SPA na najwyższym poziomie. Warto podkreślić, że cena rezerwacji za pośrednictwem serwisu Triverna jest szczególnie atrakcyjna. Wybierz hotel, który spełni twoje oczekiwania i spędź niezapomniany czas w górach. Zapraszamy!

## Kurs euro 19 kwietnia poniżej 4,65 zł
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-euro-eurpln-dzisiejsze-notowania-walut-19-kwietnia-2023/qsbh7sg](https://businessinsider.com.pl/gielda/kursy-walut/kurs-euro-eurpln-dzisiejsze-notowania-walut-19-kwietnia-2023/qsbh7sg)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 07:20:56+00:00

Kurs euro poniżej 4,65 zł. W środę rano 19 kwietnia 2023 r. kurs EUR/PLN wynosił 4,6275 zł. Jak to wyglądało wcześniej?

## Kurs dolara 19 kwietnia powyżej 4,2 zł
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-dolara-usdpln-notowania-walut-19-kwietnia-2023/xldlvq9](https://businessinsider.com.pl/gielda/kursy-walut/kurs-dolara-usdpln-notowania-walut-19-kwietnia-2023/xldlvq9)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 07:18:56+00:00

Kurs dolara powyżej 4,2 zł. W środę rano 19 kwietnia 2023 r. kurs USD/PLN wynosi 4,2199.

## Kurs franka 19 kwietnia w okolicy 4,7 zł
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-franka-frank-szwajcarski-chfpln-19-kwietnia-2023/cl9p71g](https://businessinsider.com.pl/gielda/kursy-walut/kurs-franka-frank-szwajcarski-chfpln-19-kwietnia-2023/cl9p71g)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 07:17:22+00:00

Frank szwajcarski w okolicy 4,7 zł. W środę rano 19 kwietnia 2023 r. kurs tej waluty wobec polskiego złotego wynosi 4,7049.

## Pięć popularnych hulajnóg elektrycznych, które możesz kupować w ciemno
 - [https://businessinsider.com.pl/technologie/piec-popularnych-hulajnog-elektrycznych-ktore-mozesz-kupowac-w-ciemno/0nls9kj](https://businessinsider.com.pl/technologie/piec-popularnych-hulajnog-elektrycznych-ktore-mozesz-kupowac-w-ciemno/0nls9kj)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 07:07:00+00:00

Wybraliśmy dla was pięć hulajnóg elektrycznych, które warto kupić. Korzystaliśmy z najnowszego rankingu najpopularniejszych pojazdów według danych z porównywarki cen Skąpiec.pl. Są to modele w różnych przedziałach cenowych, więc każdy znajdzie coś dla siebie.

## Krytyka zrobiła swoje. Zwrot w sprawie wódki Absolut w Rosji
 - [https://businessinsider.com.pl/wiadomosci/zwrot-w-sprawie-wodki-absolut-w-rosji-jest-nowe-stanowisko/1czvjds](https://businessinsider.com.pl/wiadomosci/zwrot-w-sprawie-wodki-absolut-w-rosji-jest-nowe-stanowisko/1czvjds)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 06:57:17+00:00

Należący do francuskiego koncernu Pernod Ricard producent szwedzkiej wódki Absolut poinformował we wtorek o wstrzymaniu eksportu do Rosji. Firma w ubiegłym tygodniu ogłosiła powrót na rynek rosyjski. W Szwecji decyzję skrytykowali politycy, a bojkot alkoholi tej marki rozpoczęli restauratorzy.

## Alert RCB na terenie ośmiu województw. "Działania antyterrorystyczne i pościgowe"
 - [https://businessinsider.com.pl/wiadomosci/alert-rcb-na-terenie-osmiu-wojewodztw-dzialania-antyterrorystyczne-i-poscigowe/pvgygm0](https://businessinsider.com.pl/wiadomosci/alert-rcb-na-terenie-osmiu-wojewodztw-dzialania-antyterrorystyczne-i-poscigowe/pvgygm0)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 06:16:22+00:00

Rządowe Centrum Bezpieczeństwa wystosowało kolejny alert, tym razem dla mieszkańców ośmiu województw. Chodzi o ćwiczenia antyterrorystyczne, zaplanowane na 19 kwietnia.

## Polski Ład to nie koniec. Będą kolejne zmiany w podatkach
 - [https://businessinsider.com.pl/wiadomosci/polski-lad-to-nie-koniec-beda-kolejne-zmiany-w-podatkach-oto-priorytet/xms0t91](https://businessinsider.com.pl/wiadomosci/polski-lad-to-nie-koniec-beda-kolejne-zmiany-w-podatkach-oto-priorytet/xms0t91)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 06:14:12+00:00

Premier Morawiecki powiedział o potrzebie upraszczania systemu podatkowego. W tym kierunku będę proponował kolejne rozwiązania. Jednym z priorytetów – największa od lat nowelizacja ordynacji podatkowej – powiedział wiceszef Ministerstwa Finansów Artur Soboń w rozmowie z "Gazetą Polską".

## Rząd szykuje plan na wypadek wojny. Więcej władzy dla premiera
 - [https://businessinsider.com.pl/wiadomosci/rzad-szykuje-plan-na-wypadek-wojny-wiecej-wladzy-dla-premiera/em4c41c](https://businessinsider.com.pl/wiadomosci/rzad-szykuje-plan-na-wypadek-wojny-wiecej-wladzy-dla-premiera/em4c41c)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 05:52:10+00:00

Rząd pracuje nad planem zarządzania państwem m.in. na wypadek wojny w Polsce — informuje portal internetowy Radia Zet. W rozporządzeniu, które w poniedziałek opublikowano na stronach rządowych, określono organizację i tryb przygotowania systemu kierowania bezpieczeństwem narodowym, w tym obroną państwa.

## Pijąc codziennie kawę, jesteś mniej narażony na przedwczesną śmierć niż osoby niepijące kawy wcale
 - [https://businessinsider.com.pl/lifestyle/pijac-kawe-jestes-mniej-narazony-na-przedwczesna-smierc-badania/qkn5hhn](https://businessinsider.com.pl/lifestyle/pijac-kawe-jestes-mniej-narazony-na-przedwczesna-smierc-badania/qkn5hhn)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 05:46:00+00:00

Pojawia się coraz więcej dowodów na to, że picie kawy pomaga zapobiec przewlekłym chorobom i przedwczesnej śmierci. Jak wynika z badań opublikowanych ostatnio w Annals of Internal Medicine, codzienne picie małej czarnej może wspomóc dłuższe i zdrowsze życie, nawet jeśli dodamy do niej cukier.

## Miliony na ekspertyzy dla ministerstw. Kto wydaje najwięcej?
 - [https://businessinsider.com.pl/wiadomosci/miliony-na-ekspertyzy-dla-ministerstw-kto-wydaje-najwiecej/pnwbxbz](https://businessinsider.com.pl/wiadomosci/miliony-na-ekspertyzy-dla-ministerstw-kto-wydaje-najwiecej/pnwbxbz)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 05:12:43+00:00

Ministerstwa wydają miliony na ekspertyzy sporządzane przez fachowców z zewnętrznych organizacji. Najwięcej za usługi doradcze płaci minister aktywów państwowych — pisze w środę "Rzeczpospolita".

## Mamy wyraźny spadek cen mąki na rynkach hurtowych
 - [https://businessinsider.com.pl/gospodarka/mamy-wyrazny-spadek-cen-maki-na-rynkach-hurtowych/7xdy19e](https://businessinsider.com.pl/gospodarka/mamy-wyrazny-spadek-cen-maki-na-rynkach-hurtowych/7xdy19e)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 04:56:46+00:00

W samym środku zamieszania wokół ukraińskiego zboża zaczęła nam wyraźnie tanieć mąka, jest więc szansa na tańsze pieczywo. Wspomniane zboże od soboty znowu ma jechać przez Polskę tranzytem, ale ma być konwojowane. Ukraińcy tymczasem zarabiają w Polsce wyraźnie więcej, niż wydają, czyli mogą trochę zaoszczędzić. Złoty się umacnia – euro jest najtańsze od czerwca, a na polskim rynku wkrótce obok IKE, IKZE i PPE mają się pojawić także OIPE – to kolejny produkt związany z oszczędzaniem na emeryturę. Oto pięć najciekawszych wydarzeń w gospodarce teraz.

## Tak będą kształtować się opłaty na lotnisku w Radomiu. Nowy cennik zatwierdzony
 - [https://businessinsider.com.pl/biznes/lotnisko-warszawa-radom-tak-beda-wygladac-oplaty/2jz2f4n](https://businessinsider.com.pl/biznes/lotnisko-warszawa-radom-tak-beda-wygladac-oplaty/2jz2f4n)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 04:41:47+00:00

60 zł opłaty za lądowanie samolotu do 2 ton, 30 zł od większych maszyn jak np. airbusy czy boeingi; 40 zł opłaty pasażerskiej za każdego podróżnego wylatującego z portu. Tak będą kształtowały się koszty przewoźników na lotnisku Warszawa-Radom — wynika z podpisanego przez prezesa Polskich Portów Lotniczych (PPL) cennika.

## Pięć faktów o imporcie zbóż z Ukrainy. Kto dopilnuje tranzytu?
 - [https://businessinsider.com.pl/prawo/piec-faktow-o-imporcie-z-ukrainy-kto-dopilnuje-tranzytu/w56e3bq](https://businessinsider.com.pl/prawo/piec-faktow-o-imporcie-z-ukrainy-kto-dopilnuje-tranzytu/w56e3bq)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 04:38:15+00:00

Rozmowy z Ukrainą w sprawie transportu zboża zakończyły się sukcesem – cieszy się Robert Telus, minister rolnictwa. Wtorkowe porozumienie jest nie tylko mocno spóźnione, ale wciąż budzi wątpliwości prawne. Polska uspokoiła nieco rozgniewaną Ukrainę, ale nie rozwiązała problemów z łamaniem unijnych i polskich przepisów.

## Płaca minimalna wyższa o dodatkowe 600 zł? Nie w tym roku
 - [https://businessinsider.com.pl/prawo/praca/unijna-placa-minimalna-podwyzka-bedzie-ale-nie-w-tym-roku/ss0pldx](https://businessinsider.com.pl/prawo/praca/unijna-placa-minimalna-podwyzka-bedzie-ale-nie-w-tym-roku/ss0pldx)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 04:27:28+00:00

W roku wyborczym trzeba liczyć się z rekordowym wzrostem minimalnego wynagrodzenia. Okazją do podwyżki będzie konieczność wdrożenia unijnej dyrektywy w sprawie adekwatnych wynagrodzeń w UE. Czy rząd przebije Brukselę? — Będziemy starali się utrzymać minimalną pensję na poziomie co najmniej połowy średniej płacy — odpowiada Stanisław Szwed, wiceminister rodziny i polityki społecznej.

## Płaca minimalna wyższa o dodatkowe 600 zł? Nie w tym roku
 - [https://businessinsider.com.pl/1681878614921/4/businessinsider_com_pl__prawo_praca_unijna_placa_minimalna_podwyzka_bedzie_ale_nie_w_tym_roku_ss0pldx](https://businessinsider.com.pl/1681878614921/4/businessinsider_com_pl__prawo_praca_unijna_placa_minimalna_podwyzka_bedzie_ale_nie_w_tym_roku_ss0pldx)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 04:27:28+00:00

W roku wyborczym trzeba liczyć się z rekordowym wzrostem minimalnego wynagrodzenia. Okazją do podwyżki będzie konieczność wdrożenia unijnej dyrektywy w sprawie adekwatnych wynagrodzeń w UE. Czy rząd przebije Brukselę? — Będziemy starali się utrzymać minimalną pensję na poziomie co najmniej połowy średniej płacy — odpowiada Stanisław Szwed, wiceminister rodziny i polityki społecznej.

## Dwa samochody w jednoosobowej działalności? Fiskus stawia warunek
 - [https://businessinsider.com.pl/prawo/podatki/dwa-samochody-w-jednoosobowej-dzialalnosci-fiskus-stawia-warunek/23yf6pd](https://businessinsider.com.pl/prawo/podatki/dwa-samochody-w-jednoosobowej-dzialalnosci-fiskus-stawia-warunek/23yf6pd)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 04:21:30+00:00

Masz działalność, prowadzisz ją sam i chcesz mieć więcej niż jeden samochód? Jeśli wydatki na oba auta chcesz wrzucać w koszty, musisz uważać na fiskusa. Sprawdź, co zrobić, aby uniknąć problemów w przyszłości. Pokazujemy praktyczne problemy, jakie mogą się pojawić i wyjaśniamy, co zrobić.

## Dwa samochody w jednoosobowej działalności? Fiskus stawia warunek
 - [https://businessinsider.com.pl/1681878614921/4/businessinsider_com_pl__prawo_podatki_dwa_samochody_w_jednoosobowej_dzialalnosci_fiskus_stawia_warunek_23yf6pd](https://businessinsider.com.pl/1681878614921/4/businessinsider_com_pl__prawo_podatki_dwa_samochody_w_jednoosobowej_dzialalnosci_fiskus_stawia_warunek_23yf6pd)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 04:21:30+00:00

Masz działalność, prowadzisz ją sam i chcesz mieć więcej niż jeden samochód? Jeśli wydatki na oba auta chcesz wrzucać w koszty, musisz uważać na fiskusa. Sprawdź, co zrobić, aby uniknąć problemów w przyszłości. Pokazujemy praktyczne problemy, jakie mogą się pojawić i wyjaśniamy, co zrobić.

## Tyle zarobiła pierwsza para Ameryki. Jest deklaracja podatkowa Bidenów
 - [https://businessinsider.com.pl/wiadomosci/zarobki-joe-i-jill-bidenow-pierwsza-para-ameryki-publikuje-deklaracje-podatkowe/384jpn3](https://businessinsider.com.pl/wiadomosci/zarobki-joe-i-jill-bidenow-pierwsza-para-ameryki-publikuje-deklaracje-podatkowe/384jpn3)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 04:18:54+00:00

Prezydent USA Joe Biden i jego małżonka Jill, która jest profesorem uniwersyteckim, zarobili w ub. roku 579 tys. 514 dol. i zapłacili podatek federalny w wysokości 169 tys. 820 dol. (23,8 proc.) — wynika z ich deklaracji podatkowych, które zostały opublikowane we wtorek. Poprzednik Bidena, Donald Trump, nigdy nie zdecydował się ujawnić wysokości swoich przychodów.

## Tyle zarobiła pierwsza para Ameryki. Jest deklaracja podatkowa Bidenów
 - [https://businessinsider.com.pl/1681878614921/4/businessinsider_com_pl__wiadomosci_zarobki_joe_i_jill_bidenow_pierwsza_para_ameryki_publikuje_deklaracje_podatkowe_384jpn3](https://businessinsider.com.pl/1681878614921/4/businessinsider_com_pl__wiadomosci_zarobki_joe_i_jill_bidenow_pierwsza_para_ameryki_publikuje_deklaracje_podatkowe_384jpn3)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 04:18:54+00:00

Prezydent USA Joe Biden i jego małżonka Jill, która jest profesorem uniwersyteckim, zarobili w ub. roku 579 tys. 514 dol. i zapłacili podatek federalny w wysokości 169 tys. 820 dol. (23,8 proc.) — wynika z ich deklaracji podatkowych, które zostały opublikowane we wtorek. Poprzednik Bidena, Donald Trump, nigdy nie zdecydował się ujawnić wysokości swoich przychodów.

## PiS chciało łatwo skosić zbożowy problem. Będzie lawina kolejnych
 - [https://businessinsider.com.pl/gospodarka/pis-chcialo-latwo-skosic-zbozowy-problem-moze-spowodowac-lawine-kolejnych/3gk7t3e](https://businessinsider.com.pl/gospodarka/pis-chcialo-latwo-skosic-zbozowy-problem-moze-spowodowac-lawine-kolejnych/3gk7t3e)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 04:05:00+00:00

– To wygląda jak leczenie zawału lewatywą – tak Janusz Piechociński komentuje próby rozwiązania zbożowego problemu przez rząd i PiS. Polska zakazała importu artykułów z Ukrainy oraz rusza ze skupem zbóż. Eksperci podkreślają, że konsekwencje tego mogą być bardzo ponure.

## PiS chciało łatwo skosić zbożowy problem. Będzie lawina kolejnych
 - [https://businessinsider.com.pl/1681878614921/4/businessinsider_com_pl__gospodarka_pis_chcialo_latwo_skosic_zbozowy_problem_moze_spowodowac_lawine_kolejnych_3gk7t3e](https://businessinsider.com.pl/1681878614921/4/businessinsider_com_pl__gospodarka_pis_chcialo_latwo_skosic_zbozowy_problem_moze_spowodowac_lawine_kolejnych_3gk7t3e)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 04:05:00+00:00

– To wygląda jak leczenie zawału lewatywą – tak Janusz Piechociński komentuje próby rozwiązania zbożowego problemu przez rząd i PiS. Polska zakazała importu artykułów z Ukrainy oraz rusza ze skupem zbóż. Eksperci podkreślają, że konsekwencje tego mogą być bardzo ponure.

## Współczesna wyrocznia przepowiada lepszy czas dla polskiej gospodarki. Mijamy dno
 - [https://businessinsider.com.pl/gielda/wiadomosci/gielda-wspolczesna-wyrocznia-przepowiada-lepszy-czas-dla-polskiej-gospodarki/hdytylh](https://businessinsider.com.pl/gielda/wiadomosci/gielda-wspolczesna-wyrocznia-przepowiada-lepszy-czas-dla-polskiej-gospodarki/hdytylh)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 04:00:00+00:00

Pół roku temu warszawska giełda była na dnie. Od tamtej pory urosła o kilkadziesiąt proc. To sugeruje, że polska gospodarka w perspektywie kolejnych miesięcy też będzie wychodziła na prostą. Wzrost apetytu na ryzyko widoczny jest głównie w odniesieniu do branży budowlanej i motoryzacyjnej. Szerokim łukiem jest omijana energetyka i sektor uzależniony w dużej mierze od spółek technologicznych z USA.

## Współczesna wyrocznia przepowiada lepszy czas dla polskiej gospodarki. Mijamy dno
 - [https://businessinsider.com.pl/1681878614921/4/businessinsider_com_pl__gielda_wiadomosci_gielda_wspolczesna_wyrocznia_przepowiada_lepszy_czas_dla_polskiej_gospodarki_hdytylh](https://businessinsider.com.pl/1681878614921/4/businessinsider_com_pl__gielda_wiadomosci_gielda_wspolczesna_wyrocznia_przepowiada_lepszy_czas_dla_polskiej_gospodarki_hdytylh)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-19 04:00:00+00:00

Pół roku temu warszawska giełda była na dnie. Od tamtej pory urosła o kilkadziesiąt proc. To sugeruje, że polska gospodarka w perspektywie kolejnych miesięcy też będzie wychodziła na prostą. Wzrost apetytu na ryzyko widoczny jest głównie w odniesieniu do branży budowlanej i motoryzacyjnej. Szerokim łukiem jest omijana energetyka i sektor uzależniony w dużej mierze od spółek technologicznych z USA.

