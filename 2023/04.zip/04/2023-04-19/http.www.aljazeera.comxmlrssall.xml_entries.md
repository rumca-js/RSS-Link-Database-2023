# Source:Aljazeera, URL:http://www.aljazeera.com/xml/rss/all.xml, language:en-US

## Malaysia’s Ramadan bazaars draw crowds, but some tighten belts
 - [https://www.aljazeera.com/news/2023/4/19/malaysias-ramadan-bazaars-draw-crowds-but-some-tighten-belts](https://www.aljazeera.com/news/2023/4/19/malaysias-ramadan-bazaars-draw-crowds-but-some-tighten-belts)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 23:37:09+00:00

The nightly markets are popular with Muslims and non-Muslims alike but there are concerns of food going to waste.

## What’s in US House Speaker Kevin McCarthy’s debt-limit package?
 - [https://www.aljazeera.com/news/2023/4/19/whats-in-us-house-speaker-mccarthys-debt-limit-package](https://www.aljazeera.com/news/2023/4/19/whats-in-us-house-speaker-mccarthys-debt-limit-package)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 23:11:17+00:00

The Republican leader has introduced proposal to slash government spending along with increasing the federal debt limit.

## US watchdog ‘cannot assure’ Afghanistan aid not going to Taliban
 - [https://www.aljazeera.com/news/2023/4/19/us-watchdog-cannot-assure-afghanistan-aid-not-going-to-taliban](https://www.aljazeera.com/news/2023/4/19/us-watchdog-cannot-assure-afghanistan-aid-not-going-to-taliban)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 22:45:53+00:00

Special inspector says oversight has been hindered by State Department&#039;s &#039;persistent refusal&#039; to provide information.

## US ignored own security warnings to ground Chinese drones
 - [https://www.aljazeera.com/economy/2023/4/19/us-ignored-own-security-warnings-to-ground-chinese-drones](https://www.aljazeera.com/economy/2023/4/19/us-ignored-own-security-warnings-to-ground-chinese-drones)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 22:38:27+00:00

Trump-era briefing obtained by Al Jazeera shows that officials feared drone ban would increase cybersecurity risks.

## Tesla’s profit margins drop on aggressive discounts, shares fall
 - [https://www.aljazeera.com/economy/2023/4/19/teslas-profit-margins-drop-on-aggressive-discounts-shares-fall](https://www.aljazeera.com/economy/2023/4/19/teslas-profit-margins-drop-on-aggressive-discounts-shares-fall)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 21:31:31+00:00

The Elon Musk-led EV maker has slashed prices several times since last year, sacrificing profit margins to drive sales.

## US man charged with shooting Black teen pleads not guilty
 - [https://www.aljazeera.com/news/2023/4/19/us-man-charged-with-shooting-black-teen-pleads-not-guilty](https://www.aljazeera.com/news/2023/4/19/us-man-charged-with-shooting-black-teen-pleads-not-guilty)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 21:27:07+00:00

Andrew Lester, 84, faces first-degree assault and armed criminal action charges for shooting 16-year-old Ralph Yarl.

## Thousands flee as new ceasefire attempt fails in Sudan
 - [https://www.aljazeera.com/news/2023/4/19/thousands-try-to-flee-sudan-as-truce-fails](https://www.aljazeera.com/news/2023/4/19/thousands-try-to-flee-sudan-as-truce-fails)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 21:03:25+00:00

Khartoum residents struggle with power cuts, water shortage as fighting rages for fifth day.

## US sanctions Nicaraguan judges who removed dissident citizenship
 - [https://www.aljazeera.com/news/2023/4/19/us-sanctions-nicaraguan-judges-who-stripped-dissident-citizenship](https://www.aljazeera.com/news/2023/4/19/us-sanctions-nicaraguan-judges-who-stripped-dissident-citizenship)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 19:48:44+00:00

The sanctions come as the government of President Daniel Ortega faces ongoing allegations of silencing dissent.

## US Supreme Court upholds temporary access to abortion pill
 - [https://www.aljazeera.com/news/2023/4/19/us-supreme-court-upholds-temporary-restrictions-on-abortion-pill](https://www.aljazeera.com/news/2023/4/19/us-supreme-court-upholds-temporary-restrictions-on-abortion-pill)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 19:44:49+00:00

The decision keeps in place a number of restrictions on access to abortion pill, used in about half of all US abortions.

## What to know about this week’s rare hybrid eclipse
 - [https://www.aljazeera.com/news/2023/4/19/what-to-know-about-this-weeks-rare-hybrid-eclipse](https://www.aljazeera.com/news/2023/4/19/what-to-know-about-this-weeks-rare-hybrid-eclipse)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 19:06:01+00:00

A rare hybrid solar eclipse will be visible on Thursday in some areas. The next one will take place in 2031.

## In another round of cuts, Facebook parent Meta sacks tech teams
 - [https://www.aljazeera.com/economy/2023/4/19/in-another-round-of-cuts-facebook-parent-meta-sacks-tech-teams](https://www.aljazeera.com/economy/2023/4/19/in-another-round-of-cuts-facebook-parent-meta-sacks-tech-teams)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 18:54:07+00:00

Wednesday cuts have prompted expressions of frustration from employees who say it has &#039;shattered&#039; morale.

## What the Dominion lawsuit revealed about Fox News and what’s next
 - [https://www.aljazeera.com/news/2023/4/19/what-the-dominion-lawsuit-revealed-about-fox-news-and-whats-next](https://www.aljazeera.com/news/2023/4/19/what-the-dominion-lawsuit-revealed-about-fox-news-and-whats-next)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 18:42:58+00:00

Fox settled with polling machine maker for $787m, but not before the case revealed embarrassing details about network.

## Family of Tyre Nichols sues Memphis officials, police officers
 - [https://www.aljazeera.com/news/2023/4/19/family-of-tyre-nichols-sue-city-officials-police-officers](https://www.aljazeera.com/news/2023/4/19/family-of-tyre-nichols-sue-city-officials-police-officers)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 18:20:09+00:00

The $550-million lawsuit in the US compares the Nichols beating to that of Emmett Till, a Black boy murdered in 1955.

## Alleged US Pentagon document leaker Teixeira to remain in jail
 - [https://www.aljazeera.com/news/2023/4/19/alleged-us-pentagon-document-leaker-teixeira-to-remain-in-jail](https://www.aljazeera.com/news/2023/4/19/alleged-us-pentagon-document-leaker-teixeira-to-remain-in-jail)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 17:51:52+00:00

Jack Teixeira, 21, makes second court appearance, as his lawyers ask for more time before hearing on his detention.

## What’s happening in Sudan? | Start Here
 - [https://www.aljazeera.com/program/start-here/2023/4/19/whats-happening-in-sudan-start-here](https://www.aljazeera.com/program/start-here/2023/4/19/whats-happening-in-sudan-start-here)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 17:41:07+00:00

Once they were allies, now they’re enemies. How two military men are fighting for control over Sudan.

## Ukraine faces grain export problems despite ship checks resuming
 - [https://www.aljazeera.com/news/2023/4/19/ukraine-faces-grain-export-problems-despite-ship-checks-resuming](https://www.aljazeera.com/news/2023/4/19/ukraine-faces-grain-export-problems-despite-ship-checks-resuming)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 17:06:07+00:00

Several EU member countries have restricted imports of Ukrainian grain and food products to protect local farmers.

## Florida expands ‘Don’t Say Gay’ education ban to all grades
 - [https://www.aljazeera.com/news/2023/4/19/florida-expands-dont-say-gay-education-ban-to-all-grades](https://www.aljazeera.com/news/2023/4/19/florida-expands-dont-say-gay-education-ban-to-all-grades)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 17:05:27+00:00

Ban in US state bars classroom discussion of gender identity and sexual orientation through high school.

## Moscow court rejects Kremlin critic’s appeal of prison term
 - [https://www.aljazeera.com/news/2023/4/19/moscow-court-rejects-kremlin-critics-appeal-of-prison-term](https://www.aljazeera.com/news/2023/4/19/moscow-court-rejects-kremlin-critics-appeal-of-prison-term)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 17:03:58+00:00

Ilya Yashin, convicted in December for comments critical of Russia&#039;s invasion of Ukraine, says his conscience is clear.

## China Tesla plant where worker died had safety weakness: Reports
 - [https://www.aljazeera.com/economy/2023/4/19/china-tesla-plant-where-worked-died-had-safety-weakness-reports](https://www.aljazeera.com/economy/2023/4/19/china-tesla-plant-where-worked-died-had-safety-weakness-reports)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 16:46:07+00:00

The emergency bureau of Shanghai’s Pudong district recommended an unspecified penalty for Tesla, news outlets reported.

## Photos: Yazidis ring in the year 6773 at temple in Iraq
 - [https://www.aljazeera.com/gallery/2023/4/19/photos-yazidis-ring-in-the-year-6773-at-temple-in-iraq](https://www.aljazeera.com/gallery/2023/4/19/photos-yazidis-ring-in-the-year-6773-at-temple-in-iraq)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 16:43:36+00:00

Thousands of worshippers light candles at Lalish Temple to celebrate the start of the New Year.

## Residents flee Khartoum as fighting continues
 - [https://www.aljazeera.com/news/2023/4/19/residents-flee-khartoum-as-fighting-continues](https://www.aljazeera.com/news/2023/4/19/residents-flee-khartoum-as-fighting-continues)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 16:29:50+00:00

Bodies on the streets of the Sudanese capital as fighting enters fifth day despite ceasefire claims.

## Can the international community stop the fighting in Sudan?
 - [https://www.aljazeera.com/news/2023/4/19/can-the-international-community-stop-the-fighting-in-sudan](https://www.aljazeera.com/news/2023/4/19/can-the-international-community-stop-the-fighting-in-sudan)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 16:07:22+00:00

The warring generals show little interest in ending hostilities amid what could be an existential threat to them.

## Why is Ukrainian grain suddenly so divisive in Europe?
 - [https://www.aljazeera.com/news/2023/4/19/why-is-ukrainian-grain-suddenly-so-divisive-in-europe](https://www.aljazeera.com/news/2023/4/19/why-is-ukrainian-grain-suddenly-so-divisive-in-europe)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 15:15:07+00:00

Top European Union officials are racing to appease a handful of countries that have temporarily banned imports.

## Murabitat: The Palestinian women defending Al-Aqsa
 - [https://www.aljazeera.com/news/2023/4/19/murabitat-the-palestinian-women-defending-al-aqsa](https://www.aljazeera.com/news/2023/4/19/murabitat-the-palestinian-women-defending-al-aqsa)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 15:09:31+00:00

Murabitat remain dedicated to defending Al-Aqsa against Israeli incursions, despite repeated banning orders.

## CAR authorities accuse rebels of killing nine Chinese miners
 - [https://www.aljazeera.com/news/2023/4/19/car-authorities-accuse-rebels-of-killing-nine-chinese-miners](https://www.aljazeera.com/news/2023/4/19/car-authorities-accuse-rebels-of-killing-nine-chinese-miners)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 15:09:04+00:00

The government has blamed an alliance of rebel groups formed to overthrow President Touadéra, for the killings.

## UK warns China against intimidating foreign nationals in Britain
 - [https://www.aljazeera.com/news/2023/4/19/uk-warns-china-against-intimidating-foreign-nationals-in-britain](https://www.aljazeera.com/news/2023/4/19/uk-warns-china-against-intimidating-foreign-nationals-in-britain)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 15:03:42+00:00

Warning issued after media reports about a Chinese businessman linked to a &#039;secret police station&#039; in London.

## The soldier who became president of Lebanon: Fouad Chehab
 - [https://www.aljazeera.com/program/al-jazeera-world/2023/4/19/the-soldier-who-became-president-of-lebanon-fouad-chehab](https://www.aljazeera.com/program/al-jazeera-world/2023/4/19/the-soldier-who-became-president-of-lebanon-fouad-chehab)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 14:53:21+00:00

Fouad Chehab, who died 50 years ago, was an army chief-turned-president and the architect of modern Lebanon.

## Diplomats, aid workers under attack in ‘nightmare’ Sudan violence
 - [https://www.aljazeera.com/news/2023/4/19/diplomats-aid-workers-under-attack-in-nightmare-sudan-violence](https://www.aljazeera.com/news/2023/4/19/diplomats-aid-workers-under-attack-in-nightmare-sudan-violence)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 14:43:57+00:00

Endre Stiansen, the Norwegian ambassador to Sudan, said the &#039;urban warfare&#039; in Khartoum is unprecedented.

## Sudan’s paramilitary RSF to move Egyptian troops to Khartoum
 - [https://www.aljazeera.com/news/2023/4/19/sudans-paramilitary-rsf-to-move-egyptian-troops-to-khartoum](https://www.aljazeera.com/news/2023/4/19/sudans-paramilitary-rsf-to-move-egyptian-troops-to-khartoum)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 13:30:16+00:00

The RSF says in a statement that Egyptian forces would be handed over to Cairo &#039;once the situation allows it&#039;.

## ‘They have to win’: Canadian women footballers fight for equality
 - [https://www.aljazeera.com/sports/2023/4/19/canadian-women-footballers-fight-for-equality](https://www.aljazeera.com/sports/2023/4/19/canadian-women-footballers-fight-for-equality)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 13:04:02+00:00

The national team&#039;s push for equal opportunity and support ahead of the World Cup is long overdue, ex-players say.

## Israeli firm NSO’s spyware again hacking iPhones: Report
 - [https://www.aljazeera.com/news/2023/4/19/israeli-firm-nsos-spyware-again-hacking-iphones-report](https://www.aljazeera.com/news/2023/4/19/israeli-firm-nsos-spyware-again-hacking-iphones-report)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 12:50:58+00:00

University of Toronto&#039;s Citizen Lab releases findings after detecting infiltration of Mexican human rights defenders.

## People crossing into Latvia allege torture by security services
 - [https://www.aljazeera.com/news/2023/4/19/people-crossing-into-latvia-allege-torture-by-security-services](https://www.aljazeera.com/news/2023/4/19/people-crossing-into-latvia-allege-torture-by-security-services)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 12:42:25+00:00

A Syrian refugee who fled from Belarus says border guards extinguished cigarettes on his war wounds.

## Ramadan Mubarak, Guantanamo
 - [https://www.aljazeera.com/opinions/2023/4/19/ramadan-mubarak-guantanamo](https://www.aljazeera.com/opinions/2023/4/19/ramadan-mubarak-guantanamo)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 12:29:37+00:00

As I mark my seventh Ramadan as a free man, I look back at the holy months I spent in Guantanamo with mixed feelings.

## Son of Iran’s last shah gets mixed reactions to visit to Israel
 - [https://www.aljazeera.com/news/2023/4/19/son-of-toppled-irans-shahs-israel-visit-draws-mixed-reactions](https://www.aljazeera.com/news/2023/4/19/son-of-toppled-irans-shahs-israel-visit-draws-mixed-reactions)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 12:16:58+00:00

Reza Pahlavi has tried to fashion himself as the leader of Iran&#039;s opposition and a key personality in its future.

## Swiss charge ex-Gambian minister with crimes against humanity
 - [https://www.aljazeera.com/news/2023/4/19/swiss-charge-ex-gambian-minister-with-crimes-against-humanity](https://www.aljazeera.com/news/2023/4/19/swiss-charge-ex-gambian-minister-with-crimes-against-humanity)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 12:00:13+00:00

Sonko was interior minister from 2006 to 2016 when he fled to Sweden and on to Switzerland, where he applied for asylum.

## Football coach John Yems’s racism ban extended to 2026
 - [https://www.aljazeera.com/sports/2023/4/19/football-ex-crawley-coach-john-yems-racism-ban-extended-to-2026](https://www.aljazeera.com/sports/2023/4/19/football-ex-crawley-coach-john-yems-racism-ban-extended-to-2026)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 11:53:56+00:00

Crawley suspended Yems in 2022 over accusations that he used discriminatory language and behaviour towards his players.

## It’s time to break the silence on childhood sexual violence
 - [https://www.aljazeera.com/opinions/2023/4/19/its-time-to-break-the-silence-on-childhood-sexual-violence](https://www.aljazeera.com/opinions/2023/4/19/its-time-to-break-the-silence-on-childhood-sexual-violence)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 11:46:43+00:00

If we fail to do so, millions of children will suffer.

## Sudan fighting enters day 5: What to know
 - [https://www.aljazeera.com/news/2023/4/19/sudan-fighting-enters-day-5-what-to-know](https://www.aljazeera.com/news/2023/4/19/sudan-fighting-enters-day-5-what-to-know)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 11:42:04+00:00

As fighting rages in Khartoum and other cities in Sudan, we take a look at the main developments.

## For Japan’s ageing football players, 80 is the new 50
 - [https://www.aljazeera.com/gallery/2023/4/19/photos-for-japans-ageing-football-players-80-is-the-new-50](https://www.aljazeera.com/gallery/2023/4/19/photos-for-japans-ageing-football-players-80-is-the-new-50)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 11:16:50+00:00

In Japan&#039;s ageing society, senior footballers can now show off their skills in a new over-80s division in Tokyo.

## Chinese man accused of blasphemy in Pakistan taken into custody
 - [https://www.aljazeera.com/news/2023/4/19/chinese-man-accused-of-blasphemy-in-pakistan-taken-into-custody](https://www.aljazeera.com/news/2023/4/19/chinese-man-accused-of-blasphemy-in-pakistan-taken-into-custody)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 11:09:19+00:00

The Chinese national working at a hydropower project denies the allegation levelled by his co-workers.

## Stitches for Sapmi: A Sami artist’s fight against climate change
 - [https://www.aljazeera.com/program/witness/2023/4/19/stitches-for-sapmi-a-sami-artists-fight-against-climate-change](https://www.aljazeera.com/program/witness/2023/4/19/stitches-for-sapmi-a-sami-artists-fight-against-climate-change)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 11:04:53+00:00

Climate change as seen through the eyes of world-renowned Sami artist and activist Britta Marakatt-Labba.

## How Ayodhya city reflects India’s widening religious divide
 - [https://www.aljazeera.com/gallery/2023/4/19/how-ayodhya-town-reflects-indias-widening-religious-divide](https://www.aljazeera.com/gallery/2023/4/19/how-ayodhya-town-reflects-indias-widening-religious-divide)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 10:55:19+00:00

Ayodhya is a microcosm of India, where a diverse past has been overrun by ruptured relations between Hindus and Muslims.

## Another Pakistani film tackling patriarchy to premier in France
 - [https://www.aljazeera.com/news/2023/4/19/another-pakistani-film-tackling-patriarchy-to-premier-in-france](https://www.aljazeera.com/news/2023/4/19/another-pakistani-film-tackling-patriarchy-to-premier-in-france)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 10:44:32+00:00

Zarrar Kahn’s debut In Flames set to premiere next month at Directors&#039; Fortnight, an event that runs parallel to Cannes.

## In Chad, freed rebel prisoners call for leader’s release
 - [https://www.aljazeera.com/news/2023/4/19/in-chad-freed-rebel-prisoners-call-for-leaders-release](https://www.aljazeera.com/news/2023/4/19/in-chad-freed-rebel-prisoners-call-for-leaders-release)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 09:52:34+00:00

In March, Chad&#039;s interim president pardoned 380 jailed members of a rebel group accused of killing his father in 2021.

## UK police under fire for arresting French publisher
 - [https://www.aljazeera.com/news/2023/4/19/uk-police-under-fire-for-arresting-french-publisher](https://www.aljazeera.com/news/2023/4/19/uk-police-under-fire-for-arresting-french-publisher)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 09:29:10+00:00

Journalist unions, writers and publishing houses condemn the arrest of Ernest Moret under the UK&#039;s Terrorism Act.

## ‘Each house is mourning’: Ramadan for a Turkish farmer and widow
 - [https://www.aljazeera.com/features/longform/2023/4/19/each-house-is-mourning-ramadan-for-a-turkish-farmer-and-widow](https://www.aljazeera.com/features/longform/2023/4/19/each-house-is-mourning-ramadan-for-a-turkish-farmer-and-widow)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 08:53:33+00:00

Sevim cooks iftars using limited means as she copes with the death of her husband to cancer, and surviving earthquakes.

## The new US-Canada border deal is inhumane — and deadly
 - [https://www.aljazeera.com/opinions/2023/4/19/the-new-us-canada-border-deal-is-inhumane-and](https://www.aljazeera.com/opinions/2023/4/19/the-new-us-canada-border-deal-is-inhumane-and)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 08:53:24+00:00

It won&#039;t stop undocumented migrants. But it will kill many more families trying to cross the frigid border.

## Mexico’s top court limits army’s role in public security
 - [https://www.aljazeera.com/news/2023/4/19/mexicos-top-court-limits-armys-role-in-public-security](https://www.aljazeera.com/news/2023/4/19/mexicos-top-court-limits-armys-role-in-public-security)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 08:22:03+00:00

Supreme Court annuls law granting the defence ministry operational and administrative control of the National Guard.

## Real Madrid and AC Milan reach Champions League semifinals
 - [https://www.aljazeera.com/sports/2023/4/19/real-madrid-and-ac-milan-reach-champions-league-semifinals](https://www.aljazeera.com/sports/2023/4/19/real-madrid-and-ac-milan-reach-champions-league-semifinals)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 08:13:23+00:00

Real Madrid beat Chelsea while AC Milan move past Napoli in Tuesday&#039;s quarterfinal matches.

## What’s the social impact of Africa’s sports betting boom?
 - [https://www.aljazeera.com/program/the-stream/2023/4/19/whats-the-social-impact-of-africas-sports-betting-boom](https://www.aljazeera.com/program/the-stream/2023/4/19/whats-the-social-impact-of-africas-sports-betting-boom)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 07:50:24+00:00

Expansion of betting shops and online gambling platforms is outpacing government regulation, researchers say.

## Will Sudan’s violence cause a wave of refugees?
 - [https://www.aljazeera.com/news/2023/4/19/will-sudans-violence-cause-a-wave-of-refugees](https://www.aljazeera.com/news/2023/4/19/will-sudans-violence-cause-a-wave-of-refugees)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 07:23:29+00:00

Humanitarian organisations say they&#039;re ready to respond to looming refugee crisis - but conflict has halted operations.

## ‘I am not scared’: Palestinians observe Ramadan in wartime Kyiv
 - [https://www.aljazeera.com/features/longform/2023/4/19/i-am-not-scared-palestinians-ramadan-wartime-kyiv](https://www.aljazeera.com/features/longform/2023/4/19/i-am-not-scared-palestinians-ramadan-wartime-kyiv)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 06:51:12+00:00

Despite feelings of homesickness, many Arabs living in Ukraine feel a sense of community in the war-wracked country.

## India to have 2.9 million more people than China by mid-2023: UN
 - [https://www.aljazeera.com/news/2023/4/19/india-to-have-2-9-million-more-people-than-china-by-mid-2023-un](https://www.aljazeera.com/news/2023/4/19/india-to-have-2-9-million-more-people-than-china-by-mid-2023-un)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 05:47:50+00:00

UNFPA data estimates India’s population at 1.4286 billion against 1.4257 billion for China by the middle of the year.

## Refugees claim gas flaring cancer link in northern Iraq
 - [https://www.aljazeera.com/features/2023/4/19/refugees-claim-gas-flaring-cancer-link-northern-iraq](https://www.aljazeera.com/features/2023/4/19/refugees-claim-gas-flaring-cancer-link-northern-iraq)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 05:25:38+00:00

Cancer rates double in affected provinces after facilities resume production in recent years.

## China making plans to boost consumption amid demand concerns
 - [https://www.aljazeera.com/economy/2023/4/19/china-making-plans-to-boost-consumption-amid-demand-concerns](https://www.aljazeera.com/economy/2023/4/19/china-making-plans-to-boost-consumption-amid-demand-concerns)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 05:00:39+00:00

National Development and Reform Commission says it is drafting plans to boost recovery through &#039;big-ticket&#039; consumption.

## Indonesian fishermen saved after Australia shipwreck; 9 missing
 - [https://www.aljazeera.com/news/2023/4/19/indonesian-fishermen-saved-after-australia-shipwreck-9-missing](https://www.aljazeera.com/news/2023/4/19/indonesian-fishermen-saved-after-australia-shipwreck-9-missing)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 04:41:28+00:00

The group spent six days without food or water on a remote island where they were shipwrecked by Cyclone Ilsa.

## Renowned Irish climber dies, Indian missing on Nepal’s Annapurna
 - [https://www.aljazeera.com/news/2023/4/19/renowned-irish-climber-dies-indian-missing-on-nepals-annapurna](https://www.aljazeera.com/news/2023/4/19/renowned-irish-climber-dies-indian-missing-on-nepals-annapurna)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 04:28:09+00:00

Noel Hanna died while returning from summit while Indian climber Anurag Maloo fell into crevasse on the same mountain.

## Chinese-Australians report less racism, greater belonging: Poll
 - [https://www.aljazeera.com/news/2023/4/19/chinese-australians-report-less-racism-greater-belonging-poll](https://www.aljazeera.com/news/2023/4/19/chinese-australians-report-less-racism-greater-belonging-poll)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 04:07:43+00:00

Experiences of racist abuse have fallen by one-third since 2020, according to poll by the Sydney-based Lowy Institute.

## Russia-Ukraine war: List of key events, day 420
 - [https://www.aljazeera.com/news/2023/4/19/russia-ukraine-war-list-of-key-events-day-420](https://www.aljazeera.com/news/2023/4/19/russia-ukraine-war-list-of-key-events-day-420)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 02:55:47+00:00

As the conflict enters its 420th day, we take a look at the main developments.

## Kim Jong Un orders launch of spy satellite to proceed
 - [https://www.aljazeera.com/news/2023/4/19/kim-jong-un-orders-launch-of-spy-satellite-to-proceed](https://www.aljazeera.com/news/2023/4/19/kim-jong-un-orders-launch-of-spy-satellite-to-proceed)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 02:09:31+00:00

Putting a surveillance satellite into orbit is a key goal of North Korean leader&#039;s military strategy.

## Fugees star says money from Malaysia’s Jho Low was for Obama pic
 - [https://www.aljazeera.com/economy/2023/4/19/fugees-star-says-money-from-malaysias-jho-low-was-for-obama-pic](https://www.aljazeera.com/economy/2023/4/19/fugees-star-says-money-from-malaysias-jho-low-was-for-obama-pic)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 01:24:08+00:00

US Rapper Prakazrel Michel is accused of plotting with financier Jho Low to influence Obama and Trump administrations.

## Brazil condemns ‘violation’ of Ukraine’s territory amid criticism
 - [https://www.aljazeera.com/news/2023/4/19/brazil-condemns-violation-of-ukraines-territory-amid-criticism](https://www.aljazeera.com/news/2023/4/19/brazil-condemns-violation-of-ukraines-territory-amid-criticism)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-19 00:54:27+00:00

Brazilian President Luiz Inácio Lula da Silva also reiterated calls for a negotiated peace between Russian and Ukraine.

