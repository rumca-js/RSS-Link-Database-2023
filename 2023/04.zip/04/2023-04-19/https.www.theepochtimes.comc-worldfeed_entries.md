# Source:Epoch times world, URL:https://www.theepochtimes.com/c-world/feed/, language:en-US

## IN-DEPTH: Trudeau Foundation and the Chinese Donation: What’s All the Controversy About?
 - [https://www.theepochtimes.com/in-depth-trudeau-foundation-and-the-chinese-donation-whats-all-the-controversy-about_5205704.html](https://www.theepochtimes.com/in-depth-trudeau-foundation-and-the-chinese-donation-whats-all-the-controversy-about_5205704.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 23:10:55+00:00

A Trudeau Foundation sign at its office in Montreal on April 19, 2023. (Noé Chartier/The Epoch Times)

## House Advances Resolution to Restore Solar Panel Tariffs Targeting China
 - [https://www.theepochtimes.com/house-advances-resolution-to-restore-solar-panel-tariffs-targeting-china_5206898.html](https://www.theepochtimes.com/house-advances-resolution-to-restore-solar-panel-tariffs-targeting-china_5206898.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 23:08:56+00:00

Joe Biden walks past solar panels while touring the Plymouth Area Renewable Energy Initiative in Plymouth, New Hampshire, on June 4, 2019. (Brian Snyder/Reuters)

## ‘We’re Just Fighting for Fair Wages’: Workers Gather on Parliament Hill for First Day of PSAC Strike
 - [https://www.theepochtimes.com/were-just-fighting-for-fair-wages-workers-gather-on-parliament-hill-for-first-day-of-psac-strike_5206722.html](https://www.theepochtimes.com/were-just-fighting-for-fair-wages-workers-gather-on-parliament-hill-for-first-day-of-psac-strike_5206722.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 22:36:25+00:00

Hundreds of striking workers with the Public Service Alliance of Canada gather on Parliament Hill on April 19, 2023. (Matthew Horwood/The Epoch Times)

## Canada Is on ‘Race Toward Financial Shipwreck’: Report
 - [https://www.theepochtimes.com/canada-is-on-race-toward-financial-shipwreck-report_5207624.html](https://www.theepochtimes.com/canada-is-on-race-toward-financial-shipwreck-report_5207624.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 22:11:14+00:00

Prime Minister Justin Trudeau rises during question period in the House of Commons on Parliament Hill in Ottawa on March 28, 2023. (Sean Kilpatrick/The Canadian Press)

## Former Top Officials Can’t Recall 2017 Memo on Chinese Regime Interference
 - [https://www.theepochtimes.com/former-top-officials-cant-recall-2017-memo-on-chinese-regime-interference_5207441.html](https://www.theepochtimes.com/former-top-officials-cant-recall-2017-memo-on-chinese-regime-interference_5207441.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 21:43:51+00:00

Michael Wernick, Jarislowsky Chair in Public Sector Management at the University of Ottawa, waits to appear as a witness at the Standing Committee on Procedure and House Affairs investigating foreign election inference on Parliament Hill in Ottawa on April 18, 2023. (Spencer Colby/The Canadian Press)

## Opposition MPs Criticize Liberals for Failing to Negotiate Deal With Federal Workers
 - [https://www.theepochtimes.com/opposition-mps-criticize-liberals-for-failing-to-negotiate-deal-with-federal-workers_5206744.html](https://www.theepochtimes.com/opposition-mps-criticize-liberals-for-failing-to-negotiate-deal-with-federal-workers_5206744.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 21:28:32+00:00

PSAC workers and supporters picket outside the Canada Revenue Agency office in Sudbury, Ont. on April 19, 2023. More than 155,000 federal public servants are on strike after the federal government and the Public Service Alliance of Canada (PSAC) failed to reach a deal before a Tuesday evening deadline. (THE CANADIAN PRESS/Gino Donato)

## Fuel Campaigner and Lobbyist Says Ban on Petrol and Diesel Cars ‘Doesn’t Make Sense’
 - [https://www.theepochtimes.com/fuel-campaigner-and-lobbyist-says-ban-on-petrol-and-diesel-cars-doesnt-make-sense_5206044.html](https://www.theepochtimes.com/fuel-campaigner-and-lobbyist-says-ban-on-petrol-and-diesel-cars-doesnt-make-sense_5206044.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 21:21:35+00:00

Howard Cox, founder of the FairFuel UK campaign, sits for a photograph in London, England on April 5, 2023. (NTD)

## Testimony From Convicted Father of Teen in Malnourishment Death Delayed Until June
 - [https://www.theepochtimes.com/testimony-from-convicted-father-of-teen-in-malnourishment-death-delayed-until-june_5207517.html](https://www.theepochtimes.com/testimony-from-convicted-father-of-teen-in-malnourishment-death-delayed-until-june_5207517.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 21:11:04+00:00

Alexandru Radita is shown in a photo from his 15th birthday party, three months before his death, in this handout photo. (The Canadian Press/Government of Alberta)

## Minister’s Sister-in-Law Steps Down as Ethics Watchdog After Committee Launches Probe
 - [https://www.theepochtimes.com/ministers-sister-in-law-steps-down-as-ethics-watchdog-after-committee-launches-probe_5207508.html](https://www.theepochtimes.com/ministers-sister-in-law-steps-down-as-ethics-watchdog-after-committee-launches-probe_5207508.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 21:07:33+00:00

Minister of Intergovernmental Affairs Dominic LeBlanc, whose sister-in-law Martine Richard, in a file photo. (Justin Tang/The Canadian Press)

## UK Government Urged to Shut Chinese Police Outposts Following Report of Conservative Party Connection
 - [https://www.theepochtimes.com/uk-government-urged-to-shut-chinese-police-outposts-following-report-of-conservative-party-connection_5206394.html](https://www.theepochtimes.com/uk-government-urged-to-shut-chinese-police-outposts-following-report-of-conservative-party-connection_5206394.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 21:02:00+00:00

Undated file photo of former Conservative Party leader, MP Sir Iain Duncan Smith. (Daniel Leal-Olivas/PA Media)

## China Visit ‘More Than Shocking’, Says German Foreign Minister
 - [https://www.theepochtimes.com/china-visit-more-than-shocking-says-german-foreign-minister_5205183.html](https://www.theepochtimes.com/china-visit-more-than-shocking-says-german-foreign-minister_5205183.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 20:58:59+00:00

This Nov. 10, 1989 file photo shows Berliners singing and dancing on top of The Berlin Wall in celebration of the opening of the East German-West German border. (AP Photo/Thomas Kienzle)

## Trudeau Calls on Unions to ‘Get Back to the Bargaining Table,’ as Federal Workers Strike
 - [https://www.theepochtimes.com/trudeau-calls-on-unions-to-get-back-to-the-bargaining-table-as-federal-workers-strike_5206356.html](https://www.theepochtimes.com/trudeau-calls-on-unions-to-get-back-to-the-bargaining-table-as-federal-workers-strike_5206356.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 20:29:50+00:00

Prime Minister Justin Trudeau speaks to reporters ahead of a caucus meeting on Parliament Hill in Ottawa, on April 19, 2023. (THE CANADIAN PRESS/Spencer Colby)

## Coroner Confirms Earliest Known UK Death From AstraZeneca Vaccine
 - [https://www.theepochtimes.com/coroner-confirms-earliest-known-uk-death-from-astrazeneca-vaccine_5205586.html](https://www.theepochtimes.com/coroner-confirms-earliest-known-uk-death-from-astrazeneca-vaccine_5205586.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 20:26:08+00:00

AstraZeneca COVID-19 Coronavirus Vaccine and a syringe are seen in front of a displayed AstraZeneca logo, in this illustration photo taken on March 14, 2021. (Dado Ruvic/Reuters)

## ANALYSIS: ’Vague Promises’: Ontarians Try to Read Between the Lines of New School Legislation
 - [https://www.theepochtimes.com/vague-promises-ontarians-try-to-read-between-the-lines-of-new-school-legislation_5206155.html](https://www.theepochtimes.com/vague-promises-ontarians-try-to-read-between-the-lines-of-new-school-legislation_5206155.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 20:08:58+00:00

Ontario Minister of Education Stephen Lecce makes an announcement at St. Robert Catholic High School in Toronto on Aug. 4, 2021. (The Canadian Press/Tijana Martin)

## US Military Failed in Training, Advising, Equipping Afghan Forces: Pentagon Watchdog
 - [https://www.theepochtimes.com/us-military-failed-in-training-advising-equipping-afghan-forces-pentagon-watchdog_5206519.html](https://www.theepochtimes.com/us-military-failed-in-training-advising-equipping-afghan-forces-pentagon-watchdog_5206519.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 20:01:42+00:00

Members of the Taliban wait to enter the former U.S. military base to celebrate the first anniversary of the withdrawal of U.S.-led troops from Afghanistan, in Bagram, Afghanistan, on Aug. 31, 2022. (Ahmad Sahel Arman/AFP via Getty Images)

## Inmates Sue Prison Service for Failing to Protect Them From Islamist Prison Gangs
 - [https://www.theepochtimes.com/inmates-sue-prison-service-for-failing-to-protect-them-from-islamist-prison-gangs_5203221.html](https://www.theepochtimes.com/inmates-sue-prison-service-for-failing-to-protect-them-from-islamist-prison-gangs_5203221.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 19:51:31+00:00

In this file image, two people walk alongside the curtain wall of HMP Liverpool, northwest England, on Nov. 15, 2016 (Paul Ellis/AFP/Getty Images)

## Wagner-Like Russian Hacker Groups Want to ‘Destroy’ UK Infrastructure, Minister Warns
 - [https://www.theepochtimes.com/wagner-like-russian-hacker-groups-want-to-destroy-uk-infrastructure-minister-warns_5205679.html](https://www.theepochtimes.com/wagner-like-russian-hacker-groups-want-to-destroy-uk-infrastructure-minister-warns_5205679.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 19:36:27+00:00

A woman using a laptop in an unspecified location on Aug. 6, 2013. (PA Media)

## Google Ordered to Pay $500,000 to Montrealer Over Links to Post Calling Him Pedophile
 - [https://www.theepochtimes.com/google-ordered-to-pay-500000-to-montrealer-over-links-to-post-calling-him-pedophile_5207046.html](https://www.theepochtimes.com/google-ordered-to-pay-500000-to-montrealer-over-links-to-post-calling-him-pedophile_5207046.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 19:20:36+00:00

The Google app logo is seen on a smartphone in this picture illustration taken on Sept. 15, 2017. (Dado Ruvic/Reuters)

## Alberta Funds Edmonton Police to Offer Addiction Supports to People in Custody
 - [https://www.theepochtimes.com/alberta-funds-edmonton-police-to-offer-addiction-supports-to-people-in-custody_5207033.html](https://www.theepochtimes.com/alberta-funds-edmonton-police-to-offer-addiction-supports-to-people-in-custody_5207033.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 19:17:36+00:00

An Edmonton Police Service logo is shown on a lectern at a press conference in Edmonton, Oct. 2, 2017. (The Canadian Press/Jason Franson)

## BC Enacts Regulation to Ensure Protection of Ozempic Supply for Diabetes Patients
 - [https://www.theepochtimes.com/bc-enacts-regulation-to-ensure-protection-of-ozempic-supply-for-diabetes-patients_5206990.html](https://www.theepochtimes.com/bc-enacts-regulation-to-ensure-protection-of-ozempic-supply-for-diabetes-patients_5206990.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 19:14:54+00:00

Diabetes drug Ozempic is shown at a pharmacy in Toronto on April 19, 2023. (The Canadian Press/Joe O'Connal)

## Nearly 1,900 Ontario Nurses Commuting to Work in Michigan: Report
 - [https://www.theepochtimes.com/nearly-1900-ontario-nurses-commuting-to-work-in-michigan-report_5206116.html](https://www.theepochtimes.com/nearly-1900-ontario-nurses-commuting-to-work-in-michigan-report_5206116.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 18:55:32+00:00

A nurse tends to a patient on a ventilator at Beaumont Hospital in Dearborn, Michigan, on Dec. 17, 2021. (JEFF KOWALSKY/AFP via Getty Images)

## UK Food Prices Surge at Fastest Rate for 45 Years Despite Slowing Inflation
 - [https://www.theepochtimes.com/uk-food-prices-surge-at-fastest-rate-for-45-years-despite-slowing-inflation_5206043.html](https://www.theepochtimes.com/uk-food-prices-surge-at-fastest-rate-for-45-years-despite-slowing-inflation_5206043.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 18:47:23+00:00

Shoppers in a supermarket in the UK on Oct. 15, 2021. (Aaron Chown/PA Media)

## ‘Highly Unusual’ That Government Can Appoint Directors to Trudeau Foundation Board: Charity Expert
 - [https://www.theepochtimes.com/highly-unusual-that-government-can-appoint-directors-to-trudeau-foundation-board-charity-expert_5203235.html](https://www.theepochtimes.com/highly-unusual-that-government-can-appoint-directors-to-trudeau-foundation-board-charity-expert_5203235.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 17:44:18+00:00

The West Block of Parliament Hill is pictured through the window of the Sir John A Macdonald building in Ottawa on May 11, 2022. (Sean Kilpatrick/The Canadian Press)

## LIVE 2:30 PM ET: East-West Center Roundtable on Indo-Pacific Outlook
 - [https://www.theepochtimes.com/east-west-center-roundtable-on-indo-pacific-outlook_5206555.html](https://www.theepochtimes.com/east-west-center-roundtable-on-indo-pacific-outlook_5206555.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 17:40:02+00:00

The Virginia-class fast-attack submarine USS Missouri (SSN 780) departs Joint Base Pearl Harbor-Hickam for a scheduled deployment in the 7th Fleet area of responsibility, Sept. 1, 2021. Australia will purchase U.S.-manufactured, Virginia-class nuclear-powered attack submarines to modernize its fleet, a European official and a person familiar with the matter said Thursday, March 9, 2023, amid growing concerns about China's influence in the Indo-Pacific region. (Amanda R. Gray/U.S. Navy via AP)

## Military Procurement Chief Wants Defence Firms to Stop Overpromising, Underdelivering
 - [https://www.theepochtimes.com/military-procurement-chief-wants-defence-firms-to-stop-overpromising-underdelivering_5206598.html](https://www.theepochtimes.com/military-procurement-chief-wants-defence-firms-to-stop-overpromising-underdelivering_5206598.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 17:18:27+00:00

Troy Crosby, Assistant Deputy Minister of the Materiel Group at the Department of National Defence, is shown in Ottawa, on April 18, 2023. (The Canadian Press/Justin Tang)

## Allies Must Balance ‘Friendshoring’ With Opening Trade: US Chamber of Commerce Head
 - [https://www.theepochtimes.com/allies-must-balance-friendshoring-with-opening-trade-us-chamber-of-commerce-head_5206581.html](https://www.theepochtimes.com/allies-must-balance-friendshoring-with-opening-trade-us-chamber-of-commerce-head_5206581.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 17:14:25+00:00

U.S. Chamber of Commerce President and CEO Suzanne Clark delivers a speech in Ottawa on April 19, 2023. (The Canadian Press/Sean Kilpatrick)

## US Government Watchdog Blames Both Biden and Trump for Afghanistan Collapse
 - [https://www.theepochtimes.com/us-government-watchdog-blames-both-biden-and-trump-for-afghanistan-collapse_5206045.html](https://www.theepochtimes.com/us-government-watchdog-blames-both-biden-and-trump-for-afghanistan-collapse_5206045.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 17:13:15+00:00

Taliban extremists stand guard at the site of an explosion, near the Interior Ministry, in Kabul, Afghanistan, on Jan. 1, 2023. (Ebrahim Noroozi/AP Photo)

## Quebec Government Moves to Ban Flavoured Vape Products, Limit Nicotine Content
 - [https://www.theepochtimes.com/quebec-government-moves-to-ban-flavoured-vape-products-limit-nicotine-content_5206561.html](https://www.theepochtimes.com/quebec-government-moves-to-ban-flavoured-vape-products-limit-nicotine-content_5206561.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 17:11:04+00:00

A construction worker exhales after using a vaping device while eating lunch on the steps at Robson Square, in Vancouver, on Mar. 8, 2021. (The Canadian Press/Darryl Dyck)

## Real Madrid Sails Into Champions League SF, Chelsea Adrift
 - [https://www.theepochtimes.com/real-madrid-sails-into-champions-league-sf-chelsea-adrift_5206456.html](https://www.theepochtimes.com/real-madrid-sails-into-champions-league-sf-chelsea-adrift_5206456.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 17:01:45+00:00

Real Madrid's players celebrates after Rodrygo scored the opening goal during the Champions League quarterfinal second leg soccer match between Chelsea and Real Madrid at Stamford Bridge stadium in London on April 18, 2023. (Kirsty Wigglesworth/AP Photo)

## Public Service Strikers’ Demands Will Cost $1B if Met by Ottawa: Report
 - [https://www.theepochtimes.com/public-service-strikers-demands-will-cost-1b-if-met-by-ottawa-report_5205879.html](https://www.theepochtimes.com/public-service-strikers-demands-will-cost-1b-if-met-by-ottawa-report_5205879.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 16:40:17+00:00

PSAC workers and supporters picket outside the Canada Revenue Agency office in Sudbury, Ont. on April 19, 2023. More than 155,000 federal public servants are on strike after the federal government and the Public Service Alliance of Canada (PSAC) failed to reach a deal before a Tuesday evening deadline. (THE CANADIAN PRESS/Gino Donato)

## Kyiv Cries Foul After Minsk Hosts Moscow-Backed Leader of Donetsk Region
 - [https://www.theepochtimes.com/kyiv-cries-foul-after-minsk-hosts-moscow-backed-leader-of-donetsk-region_5206336.html](https://www.theepochtimes.com/kyiv-cries-foul-after-minsk-hosts-moscow-backed-leader-of-donetsk-region_5206336.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 16:37:51+00:00

Head of the separatist self-proclaimed Donetsk People's Republic Denis Pushilin speaks during a news conference in Donetsk, Ukraine Feb. 23, 2022. (Alexander Ermochenko/Reuters)

## North Korean Leader Orders Launch of 1st Spy Satellite Amid Regional Tensions: State Media
 - [https://www.theepochtimes.com/north-korean-leader-orders-launch-of-1st-spy-satellite-amid-regional-tensions-state-media_5205301.html](https://www.theepochtimes.com/north-korean-leader-orders-launch-of-1st-spy-satellite-amid-regional-tensions-state-media_5205301.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 16:25:35+00:00

People watch a television screen showing a news broadcast with file footage of a North Korean missile test, at a railway station in Seoul, on April 13, 2023. - North Korea fired a ballistic missile on April 13, Seoul's military said, prompting Japan to briefly issue a seek shelter warning to residents of the northern Hokkaido region. (Jung Yeon-je/AFP via Getty Images)

## Government at Loggerheads With Critics Over Emergency Alerts as Test Looms
 - [https://www.theepochtimes.com/government-at-loggerheads-with-critics-over-emergency-alerts-as-test-looms_5205464.html](https://www.theepochtimes.com/government-at-loggerheads-with-critics-over-emergency-alerts-as-test-looms_5205464.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 16:12:39+00:00

An emergency alert regarding a stay-at-home order during the COVID-19 pandemic is viewed on a mobile phone in Eastern Ontario, Canada, on Jan. 14, 2021. (Sean Kilpatric/The Canadian Press)

## 155,000 Public Service Alliance of Canada Members Begin Strike
 - [https://www.theepochtimes.com/155000-public-service-alliance-of-canada-members-begin-strike_5205944.html](https://www.theepochtimes.com/155000-public-service-alliance-of-canada-members-begin-strike_5205944.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 16:00:00+00:00

Canada Revenue Agency workers form a picket line as over 150,000 Public Service Alliance of Canada federal employees go on strike across the country, in Montreal on April 19, 2023. (The Canadian Press/Ryan Remiorz)

## Radio-Canada Should Get Back to Core Mandate, Says Conservative Quebec Senator
 - [https://www.theepochtimes.com/radio-canada-should-get-back-to-core-mandate-says-conservative-quebec-senator_5206295.html](https://www.theepochtimes.com/radio-canada-should-get-back-to-core-mandate-says-conservative-quebec-senator_5206295.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 15:53:00+00:00

People walk toward the CBC building in Toronto, in a file photo. (The Canadian Press/Nathan Denette)

## Nearly 70 Percent of UK Drivers Want All Smart Motorways Axed, Poll Finds
 - [https://www.theepochtimes.com/nearly-70-percent-of-uk-drivers-want-all-smart-motorways-axed-poll-finds_5205605.html](https://www.theepochtimes.com/nearly-70-percent-of-uk-drivers-want-all-smart-motorways-axed-poll-finds_5205605.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 15:49:01+00:00

Traffic passes an Emergency Refuge Area on a smart motorway section in the UK on Jan. 19, 2021. (Martin Rickett/PA)

## Vietnamese Blogger Found in Police Custody After Reported Missing in Thailand
 - [https://www.theepochtimes.com/vietnamese-blogger-found-in-police-custody-after-reported-missing-in-thailand_5205543.html](https://www.theepochtimes.com/vietnamese-blogger-found-in-police-custody-after-reported-missing-in-thailand_5205543.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 15:48:23+00:00

A Vietnamese policeman stands watch outside the Phuoc Co jail on the outskirts of the southern coastal town of Vung Tau, Vietnam, in 2006. (Hoang Dinh Nam/AFP via Getty Images)

## India Surpasses China as World’s Most Populous Country
 - [https://www.theepochtimes.com/india-surpasses-china-as-worlds-most-populous-country_5205368.html](https://www.theepochtimes.com/india-surpasses-china-as-worlds-most-populous-country_5205368.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 15:05:35+00:00

People walk through a market in Bangalore, India, on Nov. 15, 2022. (Manjunath Kiran/AFP via Getty Images)

## Jihadist Attacks Kill More Than 80 People in Burkina Faso’s Worsening Security Situation
 - [https://www.theepochtimes.com/jihadist-attacks-kill-more-than-80-people-in-burkina-fasos-worsening-security-situation_5203697.html](https://www.theepochtimes.com/jihadist-attacks-kill-more-than-80-people-in-burkina-fasos-worsening-security-situation_5203697.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 15:04:10+00:00

A demonstrator holds a placard during a march called by the opposition to protest against the security situation worsening and asking for a response to jihadist attacks, in Ouagadougou, Burkina Faso, on July 3, 2021. (Olympia de Maismont/AFP via Getty Images)

## Bank of England Could Sell Bonds Faster, Former Monetary Policy Committee Member Says
 - [https://www.theepochtimes.com/bank-of-england-could-sell-bonds-faster-former-monetary-policy-committee-member-says_5202981.html](https://www.theepochtimes.com/bank-of-england-could-sell-bonds-faster-former-monetary-policy-committee-member-says_5202981.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 14:19:27+00:00

A general view of the Bank of England, in London, on Nov. 11, 2022. (Dan Kitwood/Getty Images)

## Recession Likelihood: Watch for How Much Banks Restrict Lending
 - [https://www.theepochtimes.com/recession-likelihood-watch-for-how-much-banks-restrict-lending_5205846.html](https://www.theepochtimes.com/recession-likelihood-watch-for-how-much-banks-restrict-lending_5205846.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 14:07:22+00:00

Bay Street in Canada's financial district in Toronto in a file photo. (The Canadian Press/Nathan Denette)

## ‘Slap in the Face’: Freeland’s Disney Plus Comment Made Her a Villain, Records Show
 - [https://www.theepochtimes.com/slap-in-the-face-freelands-disney-plus-comment-made-her-a-villain-records-show_5205804.html](https://www.theepochtimes.com/slap-in-the-face-freelands-disney-plus-comment-made-her-a-villain-records-show_5205804.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 13:31:09+00:00

Deputy Prime Minister and Minister of Finance Chrystia Freeland arrives to a cabinet meeting on Parliament Hill in Ottawa on April 18, 2023. (The Canadian Press/Sean Kilpatrick)

## Trillions Needed to Scale up Future of Renewable Energy
 - [https://www.theepochtimes.com/trillions-needed-to-scale-up-future-of-renewable-energy_5205396.html](https://www.theepochtimes.com/trillions-needed-to-scale-up-future-of-renewable-energy_5205396.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 13:25:21+00:00

A wind turbine is seen set amongst trees at the Taralga Wind Farm in Taralga, New South Wales, Australia on Aug. 31, 2015 in Taralga, Australia. (Photo by Mark Kolbe/Getty Images)

## MPs Urge Transport Minister to Introduce Stricter Air Passenger Protection Regulations
 - [https://www.theepochtimes.com/mps-urge-transport-minister-to-introduce-stricter-air-passenger-protection-regulations_5205661.html](https://www.theepochtimes.com/mps-urge-transport-minister-to-introduce-stricter-air-passenger-protection-regulations_5205661.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 13:04:30+00:00

Federal Transport Minister Omar Alghabra speaks with reporters before appearing as a witness at a House of Commons Standing Committee on Transport, Infrastructure, and Communities in Ottawa on Jan. 12, 2023. (The Canadian Press/Spencer Colby)

## NSW Government’s Legislative Agenda in Shambles After Last Minute Coalition Win
 - [https://www.theepochtimes.com/nsw-governments-legislative-agenda-in-shambles-after-last-minute-coalition-win_5205345.html](https://www.theepochtimes.com/nsw-governments-legislative-agenda-in-shambles-after-last-minute-coalition-win_5205345.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 10:20:00+00:00

NSW Labor Leader Chris Minns speaks to media the during a press conference at NSW Parliament, Sydney, Australia, on Sept. 23, 2022. Bankstown MP Tania Mihailuk made sensational claims against a selected candidate and was been booted from NSW Labor leader Chris Minns' shadow cabinet. (AAP Image/Bianca De Marchi)

## Transport Canada Says Hyundai Auto Canada Guilty of Safety Violation
 - [https://www.theepochtimes.com/transport-canada-says-hyundai-auto-canada-guilty-of-safety-violation_5204711.html](https://www.theepochtimes.com/transport-canada-says-hyundai-auto-canada-guilty-of-safety-violation_5204711.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 09:53:46+00:00

The Hyundai Vision T electric concept vehicle is displayed at the Canadian International Auto Show in Toronto on Feb. 18, 2020. (Chris Helgren/Reuters)

## ANZAC Spirit Gets an Upgrade as Australia and New Zealand Armies Expand Cooperation
 - [https://www.theepochtimes.com/anzac-spirit-gets-an-upgrade-as-australia-and-new-zealand-armies-expand-cooperation_5205304.html](https://www.theepochtimes.com/anzac-spirit-gets-an-upgrade-as-australia-and-new-zealand-armies-expand-cooperation_5205304.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 07:57:10+00:00

Chief of Army Lieutenant General Simon Stuart inspects the parade at Pukeahu National War Memorial during his visit to Wellington, New Zealand, on April 17, 2023. (CPL Cameron Pegg/Australian Department of Defence)

## Australian Universities Bans Indian Students as Fraudulent Visa Applications Soar
 - [https://www.theepochtimes.com/australian-universities-bans-indian-students-as-fraudulent-visa-applications-soar_5205241.html](https://www.theepochtimes.com/australian-universities-bans-indian-students-as-fraudulent-visa-applications-soar_5205241.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 07:26:59+00:00

Hundreds of vaccinated international students can return to NSW by 2022. (Brendon Thorne/Getty Images)

## Greens Lock Horns With Labor Again Over Aussie Battlers
 - [https://www.theepochtimes.com/greens-lock-horns-with-labor-again-over-aussie-battlers_5205016.html](https://www.theepochtimes.com/greens-lock-horns-with-labor-again-over-aussie-battlers_5205016.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 06:56:57+00:00

Party leader of the Australian Greens Adam Bandt addresses the media after the resignation of Senator Lidia Thorpe from the Australian Greens Party at Parliament House in Canberra, Australia on Feb. 6, 2023. Martin Ollman/Getty Images)

## Beijing’s Antartica Land Gab: China Continues Constructing 5th Base Near South Pole
 - [https://www.theepochtimes.com/beijings-antartica-land-gab-china-continues-constructing-5th-base-near-south-pole_5205085.html](https://www.theepochtimes.com/beijings-antartica-land-gab-china-continues-constructing-5th-base-near-south-pole_5205085.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 04:32:06+00:00

A satellite view with overlays shows areas to be developed at the new Chinese station under construction, on Inexpressible Island, Antarctica, January 2, 2023.  Center for Strategic and International Studies (CSIS)/Hidden Reach/Maxar Technologies 2023/Handout via REUTERS

## Alberta’s UCP, NDP Launch Media Access Battles Ahead of Provincial Election
 - [https://www.theepochtimes.com/albertas-ucp-ndp-launch-media-access-battles-ahead-of-provincial-election_5204463.html](https://www.theepochtimes.com/albertas-ucp-ndp-launch-media-access-battles-ahead-of-provincial-election_5204463.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 04:21:14+00:00

Alberta NDP Leader Rachel Notley (L) and UCP Leader Danielle Smith. (The Canadian Press/Jason Franson; Jeff McIntosh)

## With No Deal With Feds in Hand, Union Says Federal Workers Will Strike
 - [https://www.theepochtimes.com/with-no-deal-with-feds-in-hand-union-says-federal-workers-will-strike_5205168.html](https://www.theepochtimes.com/with-no-deal-with-feds-in-hand-union-says-federal-workers-will-strike_5205168.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 04:16:05+00:00

Public Service Alliance of Canada National President Chris Aylward speaks during a news conference at union headquarters, April 17, 2023 in Ottawa. (The Canadian Press/Adrian Wyld)

## The Winning Price for the Coalition’s Voice
 - [https://www.theepochtimes.com/the-winning-price-for-the-coalitions-voice_5204968.html](https://www.theepochtimes.com/the-winning-price-for-the-coalitions-voice_5204968.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 03:06:33+00:00

Shadow Minister for Child Protection and the Prevention of Family Violence Kerrynne Liddle (L) and Shadow Minister for Indigenous Australians Jacinta Nampijinpa Price (R) look on as Australian Opposition Leader Peter Dutton speaks to media during a press conference in Adelaide, Australia, on April 18, 2023. (AAP Image/Michael Errey)

## Government Jobs Compensate More, Offer Earlier Retirement, Says Canadian Study
 - [https://www.theepochtimes.com/government-jobs-compensate-more-offer-earlier-retirement-says-canadian-study_5205071.html](https://www.theepochtimes.com/government-jobs-compensate-more-offer-earlier-retirement-says-canadian-study_5205071.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 02:43:09+00:00

A Canada Post employee delivers mail to a community mailbox in Dartmouth, N.S., on June 30, 2016. (Andrew Vaughan/The Canadian Press)

## As US Makes Arrests Related to Chinese Police Stations, Canadian Senator Urges Fast-Tracking His Foreign Agent Registry Bill
 - [https://www.theepochtimes.com/as-us-australia-arrest-ccp-agents-canadian-senator-urges-fast-tracking-his-foreign-agent-registry-bill_5201111.html](https://www.theepochtimes.com/as-us-australia-arrest-ccp-agents-canadian-senator-urges-fast-tracking-his-foreign-agent-registry-bill_5201111.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 02:35:42+00:00

A Chinese paramilitary police officer stands guard on the Bund waterfront during China's National Day celebrations in Shanghai on Oct. 1, 2022. (Hector Retamal/AFP via Getty Images)

## Feds Resist Disclosing Government Subsidies Given to Volkswagen for New Battery Plant
 - [https://www.theepochtimes.com/feds-resist-disclosing-government-subsidies-given-to-volkswagen-for-new-battery-plant_5205039.html](https://www.theepochtimes.com/feds-resist-disclosing-government-subsidies-given-to-volkswagen-for-new-battery-plant_5205039.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 02:18:56+00:00

A new Volkswagen ID.3 electric car in a fully automatic high-bay-rack for delivery by the German automaker at the "Autostadt" in Wolfsburg, Germany, on Sept. 11, 2020. (Annegret Hilse/Reuters)

## Australia Not an Easy Cyber Target: Home Affairs Minister
 - [https://www.theepochtimes.com/australia-not-an-easy-cyber-target-home-affairs-minister_5202155.html](https://www.theepochtimes.com/australia-not-an-easy-cyber-target-home-affairs-minister_5202155.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 01:40:43+00:00

Clare Ellen O'Neil Minister for Home Affairs and Minister for Cyber Security at Parliament House on September 1, 2022 in Canberra, Australia. (Martin Ollman/Getty Images)

## Intelligence Committee Laments Difficulty in Obtaining Documents From Feds
 - [https://www.theepochtimes.com/intelligence-committee-laments-difficulty-in-obtaining-documents-from-feds_5204744.html](https://www.theepochtimes.com/intelligence-committee-laments-difficulty-in-obtaining-documents-from-feds_5204744.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 01:32:24+00:00

David McGuinty, chair of the National Security and Intelligence Committee of Parliamentarians, holds a new conference to release the committee's annual report, in Ottawa on March 12, 2020. (The Canadian Press/Fred Chartrand)

## Nearly 600 Drug Deaths in BC During First Three Months of 2023, Says Coroner
 - [https://www.theepochtimes.com/nearly-600-drug-deaths-in-bc-during-first-three-months-of-2023-says-coroner_5204881.html](https://www.theepochtimes.com/nearly-600-drug-deaths-in-bc-during-first-three-months-of-2023-says-coroner_5204881.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 01:29:27+00:00

A man sits in an alleyway in Vancouver's Downtown Eastside, Canada, on Feb. 6, 2019. (Jonathan Hayward/The Canadian Press)

## Anti-Corruption Investigation Finds Daniel Andrews Staff Exerted Pressure Over Union Grant
 - [https://www.theepochtimes.com/anti-corruption-investigation-finds-daniel-andrews-staff-exerted-pressure-over-union-grant_5204900.html](https://www.theepochtimes.com/anti-corruption-investigation-finds-daniel-andrews-staff-exerted-pressure-over-union-grant_5204900.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 00:23:23+00:00

Victorian Premier Daniel Andrews speaks to media during a press conference in Melbourne, Australia, on March 7, 2023. (AAP Image/Joel Carrett)

## Woman in Court Over $7M Chinese Cigarette Money Laundering Scheme
 - [https://www.theepochtimes.com/woman-in-court-over-7m-chinese-cigarette-money-laundering-scheme_5204879.html](https://www.theepochtimes.com/woman-in-court-over-7m-chinese-cigarette-money-laundering-scheme_5204879.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-19 00:16:37+00:00

A new review has called for the age limit for buying cigarettes to rise every year. (Martin Rickett/PA Media)

