# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Should We Be Fearful of Artificial Intelligence?
 - [https://www.youtube.com/watch?v=YaJ_K2ie3OI](https://www.youtube.com/watch?v=YaJ_K2ie3OI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2023-04-19 17:56:44+00:00

Taken from JRE #1971 w/Howie Mandel:
https://open.spotify.com/episode/0B3z7R0D0R311251roEoIo?si=4a0e830cbe694355

## Howie Mandel on Managing His OCD
 - [https://www.youtube.com/watch?v=IcZMGRrYTak](https://www.youtube.com/watch?v=IcZMGRrYTak)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2023-04-19 17:55:57+00:00

Taken from JRE #1971 w/Howie Mandel:
https://open.spotify.com/episode/0B3z7R0D0R311251roEoIo?si=4a0e830cbe694355

