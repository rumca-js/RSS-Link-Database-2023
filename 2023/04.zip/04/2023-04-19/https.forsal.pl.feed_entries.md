# Source:Forsal.pl, URL:https://forsal.pl/.feed, language:pl-PL

## "Washington post": Trudeau: Kanada nigdy nie wypełni zobowiązań NATO ws. wydatków na obronę
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8702422,trudeau-kanada-nie-wypelni-zobowiazan-wydatki-na-obrone.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8702422,trudeau-kanada-nie-wypelni-zobowiazan-wydatki-na-obrone.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 19:52:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/d5ektkuTURBXy9jZTM4NTM4Zi1lZjQzLTRjNmEtYWQ4Ny1lZmQ2YTdiNzFmM2QuanBlZ5GTBc0BHcyg" />Premier Kanady Justin Trudeau miał powiedzieć w prywatnej rozmowie, że Kanada nigdy nie sprosta NATO-wskiemu celowi wydatków 2 proc. PKB na obronność - podał w środę &quot;Washington Post&quot;, powołując się na tajne dokumenty amerykańskich służb, zamieszczone w sieci przez Jacka Teixeirę.

## KE o imporcie ukraińskich produktów rolnych: Kluczowe jest wypracowanie od jednolitego stanowiska
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8702409,ke-o-ukrainskich-produktach-rolnych-kluczowe-jednolite-stanowisko.html](https://forsal.pl/swiat/unia-europejska/artykuly/8702409,ke-o-ukrainskich-produktach-rolnych-kluczowe-jednolite-stanowisko.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 19:41:34+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/aGsktkuTURBXy9hMWZhZjM0Ny0wZDUwLTRjZmQtOWJhZS02MjRlNTY2MzFjM2IuanBlZ5GTBc0BHcyg" />W sprawie problemu importu ukraińskich produktów rolnych kluczowe jest szybkie przyjęcie wspólnego unijnego podejścia zamiast stosowania jednostronnych rozwiązań - czytamy we wspólnym oświadczeniu wiceprzewodniczącego KE Valdisa Dombrovskisa i unijnego komisarz ds. rolnictwa Janusza Wojciechowskiego po wideokonferencji z przedstawicielami pięciu państw członkowskich graniczących z Ukrainą.

## Ustawa legalizująca eutanazję w Portugalii zawetowana przez prezydenta
 - [https://forsal.pl/gospodarka/prawo/artykuly/8702406,ustawa-legalizujaca-eutanazje-w-portugalii-zawetowana-przez-prezydenta.html](https://forsal.pl/gospodarka/prawo/artykuly/8702406,ustawa-legalizujaca-eutanazje-w-portugalii-zawetowana-przez-prezydenta.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 19:35:09+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/bxektkuTURBXy8zYzM2MmYzMy1kNGJjLTQ0NDEtOGRmMC02YjQzYjI5MDBiZmQuanBlZ5GTBc0BHcyg" />Prezydent Portugalii Marcelo Rebelo de Sousa zawetował w środę ustawę legalizującą w tym kraju eutanazję. Została ona przyjęta przez jednoizbowy parlament Portugalii 31 marca br.

## Telus: W przyszłym tygodniu będziemy kontynuować rozmowy z KE o imporcie żywności z Ukrainy
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8702404,telus-bedziemy-kontynuowac-rozmowy-z-ke-o-imporcie-zywnosci-z-ukrainy.html](https://forsal.pl/swiat/unia-europejska/artykuly/8702404,telus-bedziemy-kontynuowac-rozmowy-z-ke-o-imporcie-zywnosci-z-ukrainy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 19:23:58+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/JsektkuTURBXy80YTEwYjJhNy0xNDRjLTQzM2ItOWQ3Ni0xYWNhMTlmYWI5YzYuanBlZ5GTBc0BHcyg" />Rozmowy na temat importu produktów rolnych z Ukrainy, jakie prowadzili w środę z unijnymi komisarzami ds. rolnictwa i ds. handlu ministrowie z pięciu krajów UE, będą kontynuowane w przyszłym tygodniu - zapowiedział w środę w TVP1 minister rolnictwa Robert Telus.

## Niedzielski: Stan zagrożenia epidemicznego może zostać odwołany pod koniec czerwca
 - [https://forsal.pl/gospodarka/prawo/artykuly/8702365,niedzielski-stan-zagrozenia-epidemicznego-do-konca-czerwca.html](https://forsal.pl/gospodarka/prawo/artykuly/8702365,niedzielski-stan-zagrozenia-epidemicznego-do-konca-czerwca.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 19:16:01+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/AROktkuTURBXy9jMDE1MmFiNi1kMTY0LTRiMmUtODFlNC01NWVhODdlZjA0OGEuanBlZ5GTBc0BHcyg" />Wstępną, planowaną datą zniesienia stanu zagrożenia epidemicznego jest koniec czerwca tego roku - powiedział w środę w Pile (woj. wielkopolskie) minister zdrowia Adam Niedzielski. Dodał, że resort &quot;przymierza się&quot; do zniesienia obowiązku noszenia maseczek w aptekach.

## Brytyjscy eksperci: Chiny dzięki przewadze technologicznej chcą zdominować świat
 - [https://forsal.pl/swiat/chiny/artykuly/8702097,brytyjscy-ekspercihjyuyj23-chiny-przewaga-technologiczna-chca-zdominowac-swiat.html](https://forsal.pl/swiat/chiny/artykuly/8702097,brytyjscy-ekspercihjyuyj23-chiny-przewaga-technologiczna-chca-zdominowac-swiat.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 18:39:51+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Sn3ktkuTURBXy80OWJjYzcyMy1hZDViLTQ5YjEtOTYxMS03NzE2ODBkZWQ1MjYuanBlZ5GTBc0BHcyg" />Chiny dążą nie do technologicznego parytetu z Zachodem, lecz do technologicznej supremacji, aby poprzez nią osiągnąć dominującą roli we wszystkich sprawach globalnych – ostrzegła w środę szefowa brytyjskiego Narodowego Centrum Cyberbezpieczeństwa (NSCS) Lindy Cameron.

## Biały Dom: USA przekaże kolejny pakiet broni i amunicji artyleryjskiej na Ukrainę
 - [https://forsal.pl/swiat/usa/artykuly/8702095,usa-przekaze-kolejny-pakiet-broni-i-amunicji-artyleryjskiej-na-ukraine.html](https://forsal.pl/swiat/usa/artykuly/8702095,usa-przekaze-kolejny-pakiet-broni-i-amunicji-artyleryjskiej-na-ukraine.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 18:30:37+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/nBOktkuTURBXy84NDU1OTIyNS1mNTdlLTQyMWMtOTJjMi02MTk4YTU5YjU5ZjQuanBlZ5GTBc0BHcyg" />Biały Dom ogłosił w środę kolejny, 36. pakiet pomocy wojskowej dla Ukrainy. Jak zapowiedziała rzeczniczka Białego Domu Karine Jean-Pierre, będzie on zawierać m.in. amunicję do systemów HIMARS, amunicję artyleryjską i &quot;systemy przeciwpancerne&quot;.

## Sudan: Armia i siły paramilitarne porozumiały się w kwestii zawieszenia broni
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8702093,sudan-armia-i-sily-paramilitarne-porozumialy-sie-zawieszenie-broni.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8702093,sudan-armia-i-sily-paramilitarne-porozumialy-sie-zawieszenie-broni.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 18:23:39+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/mgZktkuTURBXy8wY2MxYTgyNS1lM2U0LTRmYmUtYjJlYy0wYjEyNjY4YjMzYzcuanBlZ5GTBc0BHcyg" />Sudańska armia i paramilitarne Siły Szybkiego Wsparcia (RSF) zgodziły się w środę na kolejne 24-godzinne zawieszenie broni, które obowiązuje od godziny 18.00. Wcześniej już trzykrotnie ogłaszano rozejm, ale za każdym razem działania zbrojne między obiema stronami były szybko wznawiane.

## BBC: Rosja wie jak zakłócić pracę farm wiatrowych na Morzu Północnym i przerwać dostawy energii
 - [https://forsal.pl/swiat/brexit/artykuly/8702092,rosja-wie-jak-zaklocic-prace-farm-wiatrowych-na-morzu-polnocnym.html](https://forsal.pl/swiat/brexit/artykuly/8702092,rosja-wie-jak-zaklocic-prace-farm-wiatrowych-na-morzu-polnocnym.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 18:04:36+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/mfwktkuTURBXy8yNjM5MWZhNi1iYmQ5LTQ4YzEtODFjMi1lYmIzZWY3YmU0OGUuanBlZ5GTBc0BHcyg" />Rosja opracowała program sabotażu farm wiatrowych i kabli komunikacyjnych na Morzu Północnym - podała w środę BBC, przytaczając szczegóły śledztwa, przeprowadzonego przez publicznych nadawców w Danii, Norwegii, Szwecji i Finlandii.

## Egipski prawnik pozwał Netflix. Powodem jest "afrocentryzm" i zagrożenie dla egipskiej tożsamości
 - [https://forsal.pl/lifestyle/rozrywka/artykuly/8702085,egipski-prawnik-pozwal-netflix-o-afrocentryzm-i-egipska-tozsamosc.html](https://forsal.pl/lifestyle/rozrywka/artykuly/8702085,egipski-prawnik-pozwal-netflix-o-afrocentryzm-i-egipska-tozsamosc.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 17:36:15+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/iVLktkuTURBXy8zMzQzMWZmYS1kNGFjLTRlZGUtODU3Zi1hMTBkMGEzOTQ2ZjYuanBlZ5GTBc0BHcyg" />Egipski prawnik wniósł pozew przeciwko platformie Netflix. Przeszkadza mu to, że rolę Kleopatry w nowym serialu gra czarnoskóra aktorka, Adele James, co - zdaniem skarżącego - stanowi zamach na egipską tożsamość, podał we wtorek portal Egypt Independent.

## Cyrus Reza Pahlawi w Tel Awiwie: Obywatele Iranu są gotowi do normalizacji relacji z Izraelem
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8702073,pahlawi-w-tel-awiwie-obywatele-iranu-gotowi-do-normalizacji-relacji.html](https://forsal.pl/swiat/aktualnosci/artykuly/8702073,pahlawi-w-tel-awiwie-obywatele-iranu-gotowi-do-normalizacji-relacji.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 16:52:32+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/F5FktkuTURBXy9jZjNhNzQyYS0wZWY4LTQ4OTAtOWQ2OC1hN2RjZDI2M2IxM2QuanBlZ5GTBc0BHcyg" />Cyrus Reza Pahlawi, syn ostatniego władcy Iranu, stwierdził, goszcząc w Tel Awiwie, że Republika Islamska nie reprezentuje narodu irańskiego, który jest &quot;absolutnie gotów&quot; do normalizacji relacji z Izraelem, podał w środę Times of Israel.

## "NYT": Rosja omija sankcje. Importuje duże ilości chipów przez Armenię i Kazachstan
 - [https://forsal.pl/swiat/rosja/artykuly/8702071,nyt-rosja-omija-sankcje-import-chipow-przez-armenie-i-kazachstan.html](https://forsal.pl/swiat/rosja/artykuly/8702071,nyt-rosja-omija-sankcje-import-chipow-przez-armenie-i-kazachstan.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 16:43:31+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/2vsktkuTURBXy9hYzRiNWUxNi1iMDVmLTQzOGUtODllZi1lOGI1MDQ3NzMyZDcuanBlZ5GTBc0BHcyg" />Instytucje handlowe w Stanach Zjednoczonych i Unii Europejskiej odnotowały gwałtowny wzrost ilości chipów i innych komponentów elektronicznych wysyłanych do Rosji przede wszystkim przez Armenię, Kazachstan i kilka innych krajów - podał &quot;New York Times&quot;.

## Najdroższe destynacje turystyczne w 2023 roku? Ranking otwiera Monako
 - [https://forsal.pl/lifestyle/turystyka/artykuly/8702068,najdrozsze-destynacje-turystyczne-w-2023-roku-ranking-otwiera-monako.html](https://forsal.pl/lifestyle/turystyka/artykuly/8702068,najdrozsze-destynacje-turystyczne-w-2023-roku-ranking-otwiera-monako.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 16:23:43+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/UmxktkuTURBXy8xM2E0NGIwMS1iMzU3LTRmZGQtYmMwNS00MWE0ODEyODYzMTIuanBlZ5GTBc0BHcyg" />Delhi w Indiach, Phnom Penh w Kambodży i Katmandu w Nepalu, to najtańsze miejsca na świecie do odwiedzenia w 2023 r. - wynika z rankingu portalu Traveller’s Elixir. Najdroższymi są natomiast Monako, Saint-Barthelemy w Małych Antylach i Gstaad w Szwajcarii.

## Amerykańskie sankcje zadziałały. Rosyjski MBI wycofuje się z Węgier
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8702066,amerykanskie-sankcje-zadzialaly-rosyjski-mbi-wycofuje-sie-z-wegier.html](https://forsal.pl/swiat/unia-europejska/artykuly/8702066,amerykanskie-sankcje-zadzialaly-rosyjski-mbi-wycofuje-sie-z-wegier.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 16:17:25+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/AaIktkuTURBXy8xZDJlZjEyNC0zYTQzLTQzNDYtYThjOS1lMjExMDI2Y2ZkNjAuanBlZ5GTBc0BHcyg" />W związku z objęciem przez USA sankcjami Międzynarodowego Banku Inwestycyjnego (IIB), nazywanego często rosyjskim „bankiem szpiegów”, instytucja rozpoczęła proces przenosin swojej siedziby z Budapesztu do Rosji - poinformował bank na swojej stronie internetowej.

## Irańscy producenci dronów z nowymi amerykańskimi sankcjami
 - [https://forsal.pl/swiat/usa/artykuly/8702062,iranscy-producenci-dronow-z-nowymi-amerykanskimi-sankcjami.html](https://forsal.pl/swiat/usa/artykuly/8702062,iranscy-producenci-dronow-z-nowymi-amerykanskimi-sankcjami.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 16:04:53+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Sl1ktkuTURBXy8xMDQyZjE3Yy03MzExLTRkMTUtOTkzNC05OTA4MWQ4ZjIwNWUuanBlZ5GTBc0BHcyg" />Amerykański resort finansów ogłosił w środę kolejny pakiet sankcji przeciwko Iranowi, wymierzonych w sieć irańskich podmiotów zaopatrujących wbrew dotychczasowym ograniczeniom irański przemysł zbrojeniowy i program budowy dronów. Na czarną listę trafiły firmy sprowadzające elektronikę z Chin, Hongkongu i Malezji.

## Stoltenberg o Putinie: Rosyjski prezydent chce przeczekać Ukrainę i Zachód. To mu się nie uda
 - [https://forsal.pl/swiat/rosja/artykuly/8702053,stoltenberg-putin-chce-przeczekac-ukraine-i-zachod-to-bledne-zalozenia.html](https://forsal.pl/swiat/rosja/artykuly/8702053,stoltenberg-putin-chce-przeczekac-ukraine-i-zachod-to-bledne-zalozenia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 15:59:12+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/NzpktkuTURBXy82YjY2MWRmZC05YzlmLTQ5N2ItYTA1My00ZDg0ZDk5MWQ4YWEuanBlZ5GTBc0BHcyg" />Władimir Putin myśli, że weźmie Ukraińców i Zachód na przeczekanie; trzeba mu udowodnić, że się myli - powiedział w środę sekretarz generalny NATO Jens Stoltenberg na konferencji prasowej w Brukseli.

## MRiT o tranzycie ukraińskiego zboża: Akcja zostanie wznowiona w nocy z czwartku na piątek
 - [https://forsal.pl/biznes/rolnictwo/artykuly/8702049,mrit-tranzyt-ukrainskiego-zboza-ruszy-w-nocy-z-czwartku-na-piatek.html](https://forsal.pl/biznes/rolnictwo/artykuly/8702049,mrit-tranzyt-ukrainskiego-zboza-ruszy-w-nocy-z-czwartku-na-piatek.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 15:52:15+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Oq_ktkuTURBXy8xYTE2YWMxNy1jMDU1LTQxN2UtYmQ5Yy1kZjZmYjBmNDNkZjIuanBlZ5GTBc0BHcyg" />Tranzyt produktów rolnych z Ukrainy zostanie wznowiony 21 kwietnia o północy, czyli w nocy z czwartku na piątek - wynika z odpowiedzi resortu rozwoju i technologii przekazanej PAP. Dodano, że trwają prace nad nowelizacją odpowiedniego rozporządzenia.

## Rumunia będzie plombować i monitorować transporty z ukraińskim zbożem
 - [https://forsal.pl/biznes/rolnictwo/artykuly/8702035,rumunia-bedzie-plombowac-i-monitorowac-transporty-z-ukrainskim-zbozem.html](https://forsal.pl/biznes/rolnictwo/artykuly/8702035,rumunia-bedzie-plombowac-i-monitorowac-transporty-z-ukrainskim-zbozem.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 15:26:28+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/pWXktkuTURBXy80YjVlZWE0YS04NTUxLTQ5ZDMtYmEwMC1lM2M2NWE5MmM4MTMuanBlZ5GTBc0BHcyg" />Rumunia będzie kontrolować tranzyt ukraińskiego zboża, plombując przekraczające granicę ładunki oraz monitorując ich przemieszczanie się po swoim terytorium, ogłosił w środę po południu rząd kierowany przez premiera Nicolae Ciucę.

## Węgierska prezydent studzi oczekiwania Ukrainy co do akcesji do UE. W tle sprawa Węgrów z Zakarpacia
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8702032,novak-studzi-oczekiwania-ukrainy-ajcesja-do-ue-wegrzy-z-zakarpacia.html](https://forsal.pl/swiat/unia-europejska/artykuly/8702032,novak-studzi-oczekiwania-ukrainy-ajcesja-do-ue-wegrzy-z-zakarpacia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 15:16:45+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/P0WktkuTURBXy8wY2Y4ZTYwNy05MTdhLTQyMTktOTVkMy1kMGUyMTliY2NkMTguanBlZ5GTBc0BHcyg" />Nie wolno zachęcać Ukrainy do nierealistycznych oczekiwań co do pomocy. Nie będziemy wysyłać naszych mężów i synów na pole bitwy – powiedziała cytowana przez agencję MTI prezydent Węgier Katalin Novak po spotkaniu z prezydent Słowenii Nataszą Pirc Musar w środę w Budapeszcie.

## Pracownik ambasady Rosji zostanie wydalony z Mołdawii
 - [https://forsal.pl/swiat/rosja/artykuly/8702025,pracownik-ambasady-rosji-zostanie-wydalony-z-moldawii.html](https://forsal.pl/swiat/rosja/artykuly/8702025,pracownik-ambasady-rosji-zostanie-wydalony-z-moldawii.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 14:48:54+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/FkzktkuTURBXy9jMWE3ZjA3Yy04NGRmLTRiZDQtYmZjOC04NWI0YTRjMDkxNzQuanBlZ5GTBc0BHcyg" />Władze Mołdawii wezwały ambasadora Rosji w Kiszyniowie, aby poinformować go, że jeden z pracowników ambasady został uznany za osobę niepożądaną - powiadomił w środę rzecznik rządu mołdawskiego Daniel Voda.

## Rynek walutowy: EUR/PLN może zmierzać do 4,56-4,58
 - [https://forsal.pl/finanse/waluty/artykuly/8702022,rynek-walutowy-eurpln-moze-zmierzac-do-456-458.html](https://forsal.pl/finanse/waluty/artykuly/8702022,rynek-walutowy-eurpln-moze-zmierzac-do-456-458.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 14:29:14+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/xnyktkuTURBXy9lMmFkNzVlYy02ODJjLTRmOTAtOWE1Yy03MTdkMjI1YjllNzYuanBlZ5GTBc0BHcyg" />Przy wsparciu globalnych nastrojów i krajowych danych makro kurs EUR/PLN wybija się dołem ze średnioterminowej konsolidacji, co otwiera drogę w kierunku strefy 4,56-4,58 - wskazał Mirosław Budzicki z PKO BP. W jego opinii, w najbliższym czasie rentowności SPW mogą zmierzać w kierunku 6 proc.

## Belgia: Wolność słowa kontra bezpieczeństwo. Neonazistowski polityk wygłosi wykład na uniwersytecie
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8702019,belgia-neonazistowski-polityk-wyglosi-wyklad-na-uniwersytecie.html](https://forsal.pl/swiat/unia-europejska/artykuly/8702019,belgia-neonazistowski-polityk-wyglosi-wyklad-na-uniwersytecie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 14:25:36+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ZOHktkuTURBXy9lYWQ1NTdlNi02NGUyLTRkM2MtODQ3OS01OThhYjczYWJlNTAuanBlZ5GTBc0BHcyg" />Sąd nakazał katolickiemu uniwersytetowi KU Leuven, by zezwolił neonazistowskiemu i antysemickiemu politykowi z Austrii Martinowi Sellnerowi wygłosić na uczelni wykład. Wcześniej uniwersytet odrzucił wniosek Nacjonalistycznego Stowarzyszenia Studentów (NSV) w tej sprawie, powołując się na względy bezpieczeństwa.

## Moskwa: Polska nie poprze żadnego przyjętego dziś przez PE aktu prawnego
 - [https://forsal.pl/biznes/energetyka/artykuly/8702010,moskwa-polska-nie-poprze-zadnego-przyjetego-dzis-przez-pe-aktu-prawnego.html](https://forsal.pl/biznes/energetyka/artykuly/8702010,moskwa-polska-nie-poprze-zadnego-przyjetego-dzis-przez-pe-aktu-prawnego.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 14:11:21+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/JHRktkuTURBXy85MTU2N2Q4Ni1iNTc5LTQyYzgtODdhYS1iMjZjN2E1OTI3YmQuanBlZ5GTBc0BHcyg" />Polska nie poprze w Radzie UE żadnego z aktów prawnych, które zostały we wtorek przyjęte przez Parlament Europejski wz. z &quot;Fit for 55&quot; - zapowiedziała w rozmowie z portalem i.pl minister klimatu i środowiska Anna Moskwa.

## Puda o programie Dostępność Plus: W ciągu pięciu lat wartość inwestycji wyniosła 16,7 mld zł
 - [https://forsal.pl/gospodarka/finanse-publiczne/artykuly/8701994,puda-program-dostepnosc-plus-przez-5-lat-zainwestowano-167-mld-zl.html](https://forsal.pl/gospodarka/finanse-publiczne/artykuly/8701994,puda-program-dostepnosc-plus-przez-5-lat-zainwestowano-167-mld-zl.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 13:17:54+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/1nWktkuTURBXy9kNDRhMGU2Ni00ODhmLTQ0NDktYTgxZi1hMTVlNjUxYWVlYzMuanBlZ5GTBc0BHcyg" />Najważniejsze cele programu Dostępność Plus to skuteczna likwidacja barier w normalnym życiu osób z niepełnosprawnościami. Bilans pięciu lat programu to inwestycje o wartości 16,7 mld zł - powiedział w środę minister funduszy i polityki regionalnej Grzegorz Puda.

## Telus: Wciąż brakuje narzędzi by ukraińskie zboże nie zostawało w Polsce i innych krajach przyfrontowych
 - [https://forsal.pl/biznes/rolnictwo/artykuly/8701984,telus-brakuje-narzedzi-by-ukrainskie-zboze-nie-zostawalo-w-polsce.html](https://forsal.pl/biznes/rolnictwo/artykuly/8701984,telus-brakuje-narzedzi-by-ukrainskie-zboze-nie-zostawalo-w-polsce.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 12:48:10+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/4zoktkuTURBXy82M2RjN2RkYS1kZDE1LTQ5OTgtYmExZS1lMDA5MGUxMWI0MzUuanBlZ5GTBc0BHcyg" />Choć zgadzamy się z decyzją UE o bezcłowym i bez kontyngentów handlu z Ukrainą, spowodowało to napływ ukraińskich produktów do Polski i nadal brakuje narzędzi, by były rozdysponowane w całej Europie. Otworzyliśmy oczy UE, że jest problem - powiedział w środę minister rolnictwa Robert Telus.

## UE: PE chce rozpocząć negocjacje akcesyjne z Mołdawią do końca 2023 r.
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8701968,ue-pe-chce-rozpoczac-negocjacje-akcesyjne-z-moldawia-do-konca-2023-r.html](https://forsal.pl/swiat/unia-europejska/artykuly/8701968,ue-pe-chce-rozpoczac-negocjacje-akcesyjne-z-moldawia-do-konca-2023-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 12:31:09+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/q4qktkuTURBXy8zNDZhNTVjYS1mZDExLTRiODAtOTEwMi1iNmJhNWJhNjkyODEuanBlZ5GTBc0BHcyg" />Parlament Europejski wezwał do rozpoczęcia rozmów o przystąpieniu Mołdawii do Unii Europejskiej do końca 2023 r., po spełnieniu przez ten kraj wstępnych warunków określonych przez Komisję Europejską, podał Parlament.

## Poparcie dla Bidena dołuje. To prawie najgorszy wynik w czasie jego prezydentury
 - [https://forsal.pl/swiat/usa/artykuly/8701962,poparcie-dla-bidena-doluje-to-prawie-najgorszy-wynik-w-czasie-jego-prezydentury.html](https://forsal.pl/swiat/usa/artykuly/8701962,poparcie-dla-bidena-doluje-to-prawie-najgorszy-wynik-w-czasie-jego-prezydentury.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 12:20:08+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/qYBktkuTURBXy9lNmQxY2FkNS1hOWM2LTRkOGUtOWVkZi0yMDE1ZTAxMWE3NzYuanBlZ5GTBc0BHcyg" />Politykę prezydenta USA Joe Bidena popiera 39 proc. Amerykanów - informuje w środę Reuters, przedstawiając sondaż przeprowadzony przez Ipsos. W marcu ten wskaźnik wynosił 42 proc., w połowie 2022 r. - 36 proc. i było to najniższe poparcie dla Bidena za czasów jego prezydentury.

## PIE: Spowolnienie gospodarcze zwiększy różnice między cenami ofertowymi a transakcyjnymi mieszkań
 - [https://forsal.pl/nieruchomosci/mieszkania/artykuly/8701960,pie-spowolnienie-gospodarcze-zwiekszy-roznice-miedzy-cenami-ofertowymi-a-transakcyjnymi-mieszkan.html](https://forsal.pl/nieruchomosci/mieszkania/artykuly/8701960,pie-spowolnienie-gospodarcze-zwiekszy-roznice-miedzy-cenami-ofertowymi-a-transakcyjnymi-mieszkan.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 12:18:08+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/w46ktkuTURBXy8zYzM3MDQ4Mi0zMGZkLTRiMDItYjFmNS1iMzU0ZmQ2NjgyMzEuanBlZ5GTBc0BHcyg" />Spowolnienie gospodarcze zwiększy różnice między cenami ofertowymi i transakcyjnymi na mieszkaniowym rynku pierwotnym i wtórnym - wskazano w raporcie PIE. Dodano, że w II kwartale ub.r. nieruchomości na rynku pierwotnym osiągały przeciętnie wyższe ceny niż te na rynku wtórnym.

## Urteste wydłużyło zapisy w ofercie publicznej akcji serii E do 4 maja
 - [https://forsal.pl/finanse/gielda/artykuly/8701951,urteste-wydluzylo-zapisy-w-ofercie-publicznej-akcji-serii-e-do-4-maja.html](https://forsal.pl/finanse/gielda/artykuly/8701951,urteste-wydluzylo-zapisy-w-ofercie-publicznej-akcji-serii-e-do-4-maja.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 11:59:54+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/E-ZktkuTURBXy8yMzE5ODk3MS00NDNiLTRkOWYtYjhmMS1jMmRlN2ExMzdkNjQuanBlZ5GTBc0BHcyg" />undefined

## Redan miał 0,7 mln zł zysku netto, 72 tys. zł straty EBITDA w 2022 r.
 - [https://forsal.pl/finanse/gielda/artykuly/8701950,redan-mial-07-mln-zl-zysku-netto-72-tys-zl-straty-ebitda-w-2022-r.html](https://forsal.pl/finanse/gielda/artykuly/8701950,redan-mial-07-mln-zl-zysku-netto-72-tys-zl-straty-ebitda-w-2022-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 11:56:02+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/jZUktkuTURBXy81MTFhNDNjNC1kMThlLTQ5NDAtYjUyNS1hNGFiYmE0YjJlY2YuanBlZ5GTBc0BHcyg" />undefined

## Vigo Photonics miało 7,22 mln zł zysku netto, 14,9 mln zł skoryg. zysku EBITDA w 2022 r.
 - [https://forsal.pl/finanse/gielda/artykuly/8701949,vigo-photonics-mialo-722-mln-zl-zysku-netto-149-mln-zl-skoryg-zysku-ebitda-w-2022-r.html](https://forsal.pl/finanse/gielda/artykuly/8701949,vigo-photonics-mialo-722-mln-zl-zysku-netto-149-mln-zl-skoryg-zysku-ebitda-w-2022-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 11:52:29+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Xh_ktkuTURBXy8zNjY5ODllOS1lMTVlLTQ5MTMtYjNmZS05MWE0MWYyZmZiOGQuanBlZ5GTBc0BHcyg" />undefined

## Atende rekomenduje niewypłacanie dywidendy z zysku za 2022 r i z kapitału zapasowego
 - [https://forsal.pl/finanse/gielda/artykuly/8701948,atende-rekomenduje-niewyplacanie-dywidendy-z-zysku-za-2022-r-i-z-kapitalu-zapasowego.html](https://forsal.pl/finanse/gielda/artykuly/8701948,atende-rekomenduje-niewyplacanie-dywidendy-z-zysku-za-2022-r-i-z-kapitalu-zapasowego.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 11:47:12+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/OCpktkuTURBXy9kNTZlOGE1Yy00OTEyLTQ1YjktYTZiNS1lN2Y2YTk1YzIzNDYuanBlZ5GTBc0BHcyg" />undefined

## Asseco Poland rekomenduje wypłatę 3,5 zł dywidendy na akcję z zysku za 2022 r.
 - [https://forsal.pl/finanse/gielda/artykuly/8701947,asseco-poland-rekomenduje-wyplate-35-zl-dywidendy-na-akcje-z-zysku-za-2022-r.html](https://forsal.pl/finanse/gielda/artykuly/8701947,asseco-poland-rekomenduje-wyplate-35-zl-dywidendy-na-akcje-z-zysku-za-2022-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 11:45:11+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/vY6ktkuTURBXy81OTk1NTUzYy00MmNlLTQ4M2QtYjUyZi1jNGQ4OWY2NzMyMzkuanBlZ5GTBc0BHcyg" />undefined

## Asseco Poland miało 126,4 mln zł zysku netto, 703,7 mln zł zysku EBITDA non-IFRS w IV kw.
 - [https://forsal.pl/finanse/gielda/artykuly/8701946,asseco-poland-mialo-1264-mln-zl-zysku-netto-7037-mln-zl-zysku-ebitda-non-ifrs-w-iv-kw.html](https://forsal.pl/finanse/gielda/artykuly/8701946,asseco-poland-mialo-1264-mln-zl-zysku-netto-7037-mln-zl-zysku-ebitda-non-ifrs-w-iv-kw.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 11:43:47+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/zn1ktkuTURBXy8yN2U3OTYxYS0wNWVmLTRmYzctOTgwNC1mZjkyOWJkYjkyZTkuanBlZ5GTBc0BHcyg" />undefined

## Newag miał wstępnie 22,7 mln zł zysku netto w 2022 r.
 - [https://forsal.pl/finanse/gielda/artykuly/8701945,newag-mial-wstepnie-227-mln-zl-zysku-netto-w-2022-r.html](https://forsal.pl/finanse/gielda/artykuly/8701945,newag-mial-wstepnie-227-mln-zl-zysku-netto-w-2022-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 11:41:53+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/72dktkuTURBXy9iZTE3Nzk4Yi01MmVlLTQ1YjctOWQzYi01ZGFjMDU1ZWZmZGUuanBlZ5GTBc0BHcyg" />undefined

## Boryszew rekomenduje 0,74 zł dywidendy na akcję z kapitału zapasowego
 - [https://forsal.pl/finanse/gielda/artykuly/8701944,boryszew-rekomenduje-074-zl-dywidendy-na-akcje-z-kapitalu-zapasowego.html](https://forsal.pl/finanse/gielda/artykuly/8701944,boryszew-rekomenduje-074-zl-dywidendy-na-akcje-z-kapitalu-zapasowego.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 11:39:44+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/bfEktkuTURBXy81MTY0NTc4MS01MDE0LTRjYjMtOTk0MS1kYjRiNDVjN2E3MjYuanBlZ5GTBc0BHcyg" />undefined

## Boryszew miał 111,72 mln zł zysku netto z dz.kont., 387,4 mln zł znorm. EBITDA w 2022 r.
 - [https://forsal.pl/finanse/gielda/artykuly/8701942,boryszew-mial-11172-mln-zl-zysku-netto-z-dzkont-3874-mln-zl-znorm-ebitda-w-2022-r.html](https://forsal.pl/finanse/gielda/artykuly/8701942,boryszew-mial-11172-mln-zl-zysku-netto-z-dzkont-3874-mln-zl-znorm-ebitda-w-2022-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 11:38:31+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/1z2ktkuTURBXy8zNDMwZjU0OS03NjgyLTQ3MzAtYjlkOC04ZGQ1NGNhM2NhNGEuanBlZ5GTBc0BHcyg" />undefined

## Torpol rekomenduje niewypłacanie dywidendy z zysku za 2022 r.
 - [https://forsal.pl/finanse/gielda/artykuly/8701939,torpol-rekomenduje-niewyplacanie-dywidendy-z-zysku-za-2022-r.html](https://forsal.pl/finanse/gielda/artykuly/8701939,torpol-rekomenduje-niewyplacanie-dywidendy-z-zysku-za-2022-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 11:37:06+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/MuektkuTURBXy9lNzg1MzY3MC1kZTg0LTQzYWQtYWIyNi0zZDVlY2I3MGUwMzkuanBlZ5GTBc0BHcyg" />undefined

## "The Spectator": Spór o zboże z Ukrainy dowodzi, jak bardzo UE nie rozumie Europy Wschodniej
 - [https://forsal.pl/gospodarka/polityka/artykuly/8701937,the-spectator-spor-o-zboze-z-ukrainy-dowodzi-jak-bardzo-ue-nie-rozumie-europy-wschodniej.html](https://forsal.pl/gospodarka/polityka/artykuly/8701937,the-spectator-spor-o-zboze-z-ukrainy-dowodzi-jak-bardzo-ue-nie-rozumie-europy-wschodniej.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 11:34:53+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/CJ_ktkuTURBXy9iNzk2Zjk2ZS0zZjEzLTQ1MTAtOWFiMi04NzBlMDk3ZmU4MGIuanBlZ5GTBc0BHcyg" />Spór o ukraińskie zboże pokazuje, jak bardzo brukselska eurokracja nie rozumie państw członkowskich z Europy Wschodniej i to, że jeśli nie zmieni tego podejścia, grozi to nawet rozpadem Unii Europejskiej - pisze na portalu brytyjskiego tygodnika &quot;The Spectator&quot; prof. Andrew Tettenborn z Uniwersytetu w Swansea.

## Wczoraj Bombaj, jutro Delhi. Apple otwiera sklepy stacjonarne w Indiach
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8701936,wczoraj-bombaj-jutro-delhi-apple-otwiera-sklepy-stacjonarne-w-indiach.html](https://forsal.pl/biznes/aktualnosci/artykuly/8701936,wczoraj-bombaj-jutro-delhi-apple-otwiera-sklepy-stacjonarne-w-indiach.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 11:33:26+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ROmktkuTURBXy84ZGJjZjkxNS1mZjdlLTRhNWItYjJhYS05ZjY0OWNhNDEwYzMuanBlZ5GTBc0BHcyg" />To wielkie wydarzenie dla firmy – Indie są drugim co do wielkości rynkiem smarfonów na świecie. Dyrektor generalny Apple, Tim Cook, osobiście witał klientów pierwszego, świeżo otworzonego stacjonarnego sklepu w Bombaju. Oczekuje się, że w czwartek pojawi się również na otwarciu w Delhi.

## Chiny dążą do samowystarczalności w branży czipów. Zapowiadają inwestycje warte 74 mld dol.
 - [https://forsal.pl/swiat/chiny/artykuly/8701935,chiny-daza-do-samowystarczalnosci-w-branzy-czipow-zapowiadaja-inwestycje-warte-74-mld-dol.html](https://forsal.pl/swiat/chiny/artykuly/8701935,chiny-daza-do-samowystarczalnosci-w-branzy-czipow-zapowiadaja-inwestycje-warte-74-mld-dol.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 11:32:06+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/rrtktkuTURBXy9kZGMxNDFmMS1mNGUyLTQxNjYtYjlkMC03MGNjM2M2M2EyZTUuanBlZ5GTBc0BHcyg" />W obliczu wojny technologicznej z USA Chiny dążą do samowystarczalności w branży układów scalonych. Władze prowincji Guangdong zapowiadają inwestycje warte 74 mld dolarów w sektor produkcji czipów – podał w środę dziennik „South China Morning Post”.

## Von der Leyen odpowiada na list przywódców państw UE w sprawie ukraińskiego zboża
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8701917,von-der-leyen-odpowiada-na-list-przywodcow-panstw-ue-w-sprawie-ukrainskiego-zboza.html](https://forsal.pl/swiat/unia-europejska/artykuly/8701917,von-der-leyen-odpowiada-na-list-przywodcow-panstw-ue-w-sprawie-ukrainskiego-zboza.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 10:46:57+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/yx7ktkuTURBXy8wNzg3NjUzMC05NjI2LTQyYTAtODJhZS01YTQ0ZWMzZjAxODkuanBlZ5GTBc0BHcyg" />Szefowa KE Ursula von der Leyen odpowiedziała w środę na list pięciu przywódców państw UE w sprawie ukraińskiego zboża. Podkreśliła, że potrzebne jest wspólne europejskie podejście w tej sprawie - przekazała dziennikarzom w Brukseli rzeczniczka KE Dana Spinant.

## Elektryki nie zwalniają w Polsce. Imponujący wzrost liczby rejestracji
 - [https://forsal.pl/motoforsal/artykuly/8701902,elektryki-nie-zwalniaja-w-polsce-imponujacy-wzrost-liczby-rejestracji.html](https://forsal.pl/motoforsal/artykuly/8701902,elektryki-nie-zwalniaja-w-polsce-imponujacy-wzrost-liczby-rejestracji.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 10:14:11+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/jaXktkuTURBXy8xODVlZGE1NC0yNGFjLTQ0NDctOGVmMC0yNTFiMDBlOGVkYTIuanBlZ5GTBc0BHcyg" />Liczba pojazdów elektrycznych wzrosła w I kw. 2023 o 84 proc. w porównaniu z podobnym okresem 2022 r. - wynika z danych Licznika Elektromobilności. W raporcie poinformowano też, że w marcu br. uruchomiono 19 nowych, ogólnodostępnych stacji ładowania - 39 punktów.

## PE przyjął dyrektywy i rozporządzenia z pakietu "Fit for 55"
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8701901,pe-przyjal-dyrektywy-i-rozporzadzenia-z-pakietu-fit-for-55.html](https://forsal.pl/swiat/unia-europejska/artykuly/8701901,pe-przyjal-dyrektywy-i-rozporzadzenia-z-pakietu-fit-for-55.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 10:11:41+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/nlYktkuTURBXy81MDhhZDJiYi0zMDBhLTRmNDMtOWZiOC0zMTQzNDE4M2IwM2UuanBlZ5GTBc0BHcyg" />Parlament Europejski przyjął we wtorek dyrektywy i rozporządzenia z pakietu &quot;Fit for 55&quot;, które mają prowadzić do ograniczenia emisji gazów cieplarnianych o co najmniej 55 proc. do 2030 r. (w porównaniu z 1990 r.) i osiągnięcia neutralności klimatycznej do 2050 r.

## Rosja szykuje się na długą wojnę. Dowody? Silne poparcie dla władz i charakter naboru
 - [https://forsal.pl/swiat/rosja/artykuly/8701880,rosja-szykuje-sie-na-dluga-wojne-dowody-silne-poparcie-dla-wladz-i-charakter-naboru.html](https://forsal.pl/swiat/rosja/artykuly/8701880,rosja-szykuje-sie-na-dluga-wojne-dowody-silne-poparcie-dla-wladz-i-charakter-naboru.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 09:23:02+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/CCNktkuTURBXy8xMWM5ODc1ZC02NzkxLTRkOTgtODhhZS1hMjIyYjcyMGY0Y2EuanBlZ5GTBc0BHcyg" />Silne poparcie dla władz utrzymujące się wśród Rosjan i poparcie dla agresji wobec Ukrainy, a także rozbudowany system promocji i naboru do armii wskazują, że ten kraj przygotowuje się na długą wojnę - ocenił minister w kancelarii premiera Stanisław Żaryn.

## Ceny konsumpcyjne w strefie euro w marcu w górę
 - [https://forsal.pl/gospodarka/inflacja/artykuly/8701879,ceny-konsumpcyjne-w-strefie-euro-w-marcu-w-gore.html](https://forsal.pl/gospodarka/inflacja/artykuly/8701879,ceny-konsumpcyjne-w-strefie-euro-w-marcu-w-gore.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 09:20:56+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/r97ktkuTURBXy9hZjdkN2RiOS1lZmQxLTQ3YjktODEwNS03MGY1YWE5ZGFkZjYuanBlZ5GTBc0BHcyg" />Ceny konsumpcyjne w strefie euro wzrosły o 6,9 proc. w marcu w ujęciu rdr - podał w komunikacie Eurostat, biuro statystyczne Unii Europejskiej, w II wyliczeniu. Wstępnie szacowano wzrost o 6,9 proc.

## Inflacja w Polsce według Eurostatu. Sytuacja nadal jest bardzo trudna
 - [https://forsal.pl/gospodarka/inflacja/artykuly/8701877,inflacja-w-polsce-wedlug-eurostatu-sytuacja-nadal-jest-bardzo-trudna.html](https://forsal.pl/gospodarka/inflacja/artykuly/8701877,inflacja-w-polsce-wedlug-eurostatu-sytuacja-nadal-jest-bardzo-trudna.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 09:19:38+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/IwOktkuTURBXy9kNjlmMzQ0MS1iZDQyLTRkNjgtYjBhOS04MWZjYmFmOWU5YTkuanBlZ5GTBc0BHcyg" />Ceny liczone według HICP w Polsce w marcu 2023 r. w ujęciu rocznym wzrosły o 15,2 proc. wobec 17,2 proc. w lutym - podał Eurostat. Miesięcznie ceny wzrosły o 1,1 proc.

## Nadwyżka na rachunku obrotów bieżących eurolandu. EBC podało najnowsze dane
 - [https://forsal.pl/gospodarka/finanse-publiczne/artykuly/8701875,nadwyzka-na-rachunku-obrotow-biezacych-eurolandu-ebc-podalo-najnowsze-dane.html](https://forsal.pl/gospodarka/finanse-publiczne/artykuly/8701875,nadwyzka-na-rachunku-obrotow-biezacych-eurolandu-ebc-podalo-najnowsze-dane.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 09:17:30+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/6M1ktkuTURBXy84YjUwNDIxNi1lYmM5LTQzZjgtOWRjMi1lOGIzM2Q4NzBjYTAuanBlZ5GTBc0BHcyg" />Na rachunku obrotów bieżących eurolandu nadwyżka (sa) w lutym wyniosła 24,3 mld euro - podał Europejski Bank Centralny w komunikacie.

## Ukraińska kontrofensywa: to zadecyduje o jej fiasku lub powodzeniu
 - [https://forsal.pl/swiat/ukraina/artykuly/8701861,czy-ukrainska-kontrofensywa-bedzie-skuteczna.html](https://forsal.pl/swiat/ukraina/artykuly/8701861,czy-ukrainska-kontrofensywa-bedzie-skuteczna.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 08:50:53+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/cZlktkuTURBXy9hZjRjOGVjMC0zMjcxLTRhNDQtYmEwOS0xYjU3YmNmNWEwZTAuanBlZ5GTBc0BHcyg" />Pierwsze 24 godziny ukraińskiej kontrofensywy przeciwko rosyjskim wojskom będą miały decydujące znaczenie dla powodzenia całej operacji; niezbędny warunek sukcesu to wykorzystanie elementu zaskoczenia i wywołanie paniki w szeregach przeciwnika - ocenił we wtorkowej analizie amerykański magazyn &quot;Foreign Policy&quot;.

## ISW: Putin przyjechał na front, by wskazać winnych w razie sukcesu kontrofensywy ukraińskiej
 - [https://forsal.pl/swiat/rosja/artykuly/8701833,isw-putin-przyjechal-na-front-by-wskazac-winnych-w-razie-sukcesu-kontrofensywy-ukrainskiej.html](https://forsal.pl/swiat/rosja/artykuly/8701833,isw-putin-przyjechal-na-front-by-wskazac-winnych-w-razie-sukcesu-kontrofensywy-ukrainskiej.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 07:54:08+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/q5GktkuTURBXy80NGUxNWQ1MS1mYmIwLTQwNGQtOWNiOS0wNmUzNTVhNWNjNzEuanBlZ5GTBc0BHcyg" />Celem domniemanej wizyty Władimira Putina na froncie było przedstawienie go jako rosyjskiego lidera wojennego oraz publiczne wskazanie &quot;potencjalnych kozłów ofiarnych&quot; przed planowaną kontrofensywą ukraińską - ocenia amerykański Instytut Studiów nad Wojną (ISW).

## "Washington Post": Rosja używała systemu walki elektronicznej, by zakłócać transmisje Starlinków na Ukrainie
 - [https://forsal.pl/swiat/ukraina/artykuly/8701799,washington-post-rosja-uzywala-systemu-walki-elektronicznej-by-zaklocac-transmisje-starlinkow-na-ukrainie.html](https://forsal.pl/swiat/ukraina/artykuly/8701799,washington-post-rosja-uzywala-systemu-walki-elektronicznej-by-zaklocac-transmisje-starlinkow-na-ukrainie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 07:02:18+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/pvLktkuTURBXy8yNjc4NjZhYy1kMjRjLTQ2YzMtYTZhZS1jNTI4ODczNzU0ZjAuanBlZ5GTBc0BHcyg" />Rosja przez kilka miesięcy eksperymentowała z systemem walki elektronicznej Toboł, aby zakłócać transmisje satelitów Starlink, wykorzystywanych przez Ukrainę - pisze &quot;Washington Post&quot; omawiając kolejne dokumenty amerykańskiego wywiadu, które wyciekły do internetu.

## Które regiony Polski mają największe trudności w zrekrutowaniu pracowników?
 - [https://forsal.pl/praca/artykuly/8701798,ktore-regiony-polski-maja-najwieksze-trudnosci-w-zrekrutowaniu-pracownikow.html](https://forsal.pl/praca/artykuly/8701798,ktore-regiony-polski-maja-najwieksze-trudnosci-w-zrekrutowaniu-pracownikow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 06:58:58+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/0xFktkuTURBXy8zM2ZjM2MxYi1jMjFjLTQzZDItOTE3Yi1iNGM0ZTQ0YTU5MTYuanBlZ5GTBc0BHcyg" />Największe trudności w zrekrutowaniu pracowników o pożądanych umiejętnościach mają firmy z południowej i centralnej Polski - wynika z raportu ManpowerGroup. Aby poradzić sobie z niedoborem kandydatów o określonych kompetencjach, pracodawcy najczęściej inwestują w rozwój obecnych pracowników.

## Jak napisać testament? Wyrok SN: Wola spadkodawców ważniejsza niż poprawna forma testamentu
 - [https://forsal.pl/finanse/artykuly/8701789,jak-napisac-testament-wyrok-sn-wola-spadkodawcow-wazniejsza-niz-poprawna-forma-testamentu.html](https://forsal.pl/finanse/artykuly/8701789,jak-napisac-testament-wyrok-sn-wola-spadkodawcow-wazniejsza-niz-poprawna-forma-testamentu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 06:52:19+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ZAlktkuTURBXy80OGZmZTQwYi1kODQ0LTQ1NmYtOWFhMS02OTI2N2ZhNjUyYTguanBlZ5GTBc0BHcyg" />Niezachowanie poprawnej formy testamentu przez sekretarza urzędu gminy w 1980 r. nie powinno niweczyć woli spadkodawców. Prymat przede wszystkim należy przyznać woli spadkodawców - wynika z wyroku Sądu Najwyższego uwzględniającego skargę nadzwyczajną Prokuratora Generalnego.

## Indie wyprzedzą Chiny i w połowie 2023 roku staną się najludniejszym krajem świata
 - [https://forsal.pl/gospodarka/demografia/artykuly/8701786,indie-wyprzedza-chiny-i-w-polowie-2023-roku-stana-sie-najludniejszym-krajem-swiata.html](https://forsal.pl/gospodarka/demografia/artykuly/8701786,indie-wyprzedza-chiny-i-w-polowie-2023-roku-stana-sie-najludniejszym-krajem-swiata.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 06:49:18+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/XIgktkuTURBXy9jNjgzODJjOC1mNzZhLTQzZTItOWI4ZC01ZDI4NGJiYTM5MjYuanBlZ5GTBc0BHcyg" />Indie są na drodze do stania się najludniejszym krajem świata, mają wyprzedzić Chiny o 2,9 miliona osób w połowie 2023 roku - wynika z danych opublikowanych w środę przez ONZ.

## Gdzie w Polsce najchętniej pracują Ukraińcy? [BADANIE]
 - [https://forsal.pl/praca/artykuly/8701783,gdzie-w-polsce-najchetniej-pracuja-ukraincy-badanie.html](https://forsal.pl/praca/artykuly/8701783,gdzie-w-polsce-najchetniej-pracuja-ukraincy-badanie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 06:45:30+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/yUrktkuTURBXy82ZjM3MDYwYS04ZmNhLTQ4ZGQtYTk3OC00Y2Q4NWY1NjM4ODAuanBlZ5GTBc0BHcyg" />Ukraińcy nie trafiają tam, gdzie jest na nich zapotrzebowanie – stwierdzono w raporcie &quot;Przestrzenne niedopasowanie Ukraińców na rynku pracy&quot;. Zauważono, że po wybuchu wojny przyjechało dużo Ukraińców z wyższym wykształceniem, którzy wkrótce będą pracować w usługach, finansach czy bankowości.

## Kolejna spokojna sesja na Wall Street
 - [https://forsal.pl/finanse/artykuly/8701776,kolejna-spokojna-sesja-na-wall-street.html](https://forsal.pl/finanse/artykuly/8701776,kolejna-spokojna-sesja-na-wall-street.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 06:36:27+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/WSbktkuTURBXy8yYzk0Yjg0Yi0yOTUzLTQyMGEtYTRjNi0yYjkyYzUwZWQ2MTguanBlZ5GTBc0BHcyg" />Wtorkowa sesja na Wall Street zakończyła się niewielkimi zmianami głównych indeksów. W centrum uwagi inwestorów znajdują się raporty największych banków i spółek za pierwszy kwartał 2023 roku.

## KGHM chce inwestować w wydobycie litu w Chile
 - [https://forsal.pl/biznes/energetyka/artykuly/8701775,kghm-chce-inwestowac-w-wydobycie-litu-w-chile.html](https://forsal.pl/biznes/energetyka/artykuly/8701775,kghm-chce-inwestowac-w-wydobycie-litu-w-chile.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 06:34:49+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/xRcktkuTURBXy9iZmM2MTUyZS1lNzUxLTRjMmEtOWNkMC02NTMxMTY1OThlMjEuanBlZ5GTBc0BHcyg" />Spółka KGHM jest zainteresowana inwestowaniem w wydobycie litu w Chile - przekazał we wtorek wicepremier Jacek Sasin. Dodał, że inwestycje w tym zakresie miałyby być prowadzone na zasadzie partnerstwa publiczno-prywatnego, czyli współpracy zagranicznych firm z podmiotami chilijskimi.

## Oto największe na świecie skupisko milionerów
 - [https://forsal.pl/finanse/artykuly/8701769,nowy-jork-najwieksze-na-swiecie-skupisko-milionerow.html](https://forsal.pl/finanse/artykuly/8701769,nowy-jork-najwieksze-na-swiecie-skupisko-milionerow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 06:22:49+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/MFIktkuTURBXy8xZDZhODZlNi03MDBlLTQyZmQtOGMyNS1jMDk4NTViZjY3NzQuanBlZ5GTBc0BHcyg" />W Nowym Jorku jest największe na świecie skupisko milionerów. Z 340 tys. amerykańskie miasto wyprzedza Tokio (290 300) oraz rejon Zatoki San Francisco (285 tys.).

## Koniec McDonald's na Białorusi. Wiadomo, jaka firma go zastąpi
 - [https://forsal.pl/biznes/artykuly/8701766,koniec-mcdonalds-na-bialorusi-wiadomo-jaka-firma-go-zastapi.html](https://forsal.pl/biznes/artykuly/8701766,koniec-mcdonalds-na-bialorusi-wiadomo-jaka-firma-go-zastapi.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 06:19:09+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/HgQktkuTURBXy82Yzk2ODE5My00ZDhjLTQzMTUtYjE2NS0xZjdkYmU5MTIxZWUuanBlZ5GTBc0BHcyg" />Białoruski McDonald's będzie działał jako Mak.by, podała we wtorek agencja Reutera, powołując się na białoruskiego operatora fast-foodu.

## Rusza lotnisko w Radomiu. Jak dotrzemy do nowego portu i dokąd polecimy?
 - [https://forsal.pl/transport/lotnictwo/artykuly/8701489,rusza-lotnisko-w-radomiu-jak-dotrzemy-do-nowego-portu-i-dokad-polecimy.html](https://forsal.pl/transport/lotnictwo/artykuly/8701489,rusza-lotnisko-w-radomiu-jak-dotrzemy-do-nowego-portu-i-dokad-polecimy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 05:56:59+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/icgktkuTURBXy9mNzkzZmYyYS1mODg1LTRjNmUtYmQxMi1jY2M2NDUxM2U3ZTUuanBlZ5GTBc0BHcyg" />Do uruchamianego 27 kwietnia lotniska dotrze z Warszawy wahadłowa linia autobusowa.

## Jakie obietnice wyborcze dadzą zwycięstwo? Polacy zabrali głos [SONDAŻ DGP I RMF]
 - [https://forsal.pl/gospodarka/polityka/artykuly/8701481,jakie-obietnice-wyborcze-dadza-zwyciestwo-polacy-zabrali-glos-sondaz-dgp-i-rmf.html](https://forsal.pl/gospodarka/polityka/artykuly/8701481,jakie-obietnice-wyborcze-dadza-zwyciestwo-polacy-zabrali-glos-sondaz-dgp-i-rmf.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 05:47:37+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/PaCktkuTURBXy81ZWEzMTE2MC05MzRkLTRkMTUtYjEyMy03MGQwMDAzMTQ5ZjAuanBlZ5GTBc0BHcyg" />Transfery, usługi publiczne i kwestie bezpieczeństwa – tak wygląda podium spraw, którymi wygrywa się kampanię wyborczą. To wyniki najnowszego sondażu United Surveys dla DGP i RMF FM.

## Jak wygląda polska kontrola zboża z Ukrainy na granicy?
 - [https://forsal.pl/biznes/rolnictwo/artykuly/8701505,jak-wyglada-polska-kontrola-zboza-z-ukrainy-na-granicy.html](https://forsal.pl/biznes/rolnictwo/artykuly/8701505,jak-wyglada-polska-kontrola-zboza-z-ukrainy-na-granicy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 05:41:28+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/aGsktkuTURBXy9hMWZhZjM0Ny0wZDUwLTRjZmQtOWJhZS02MjRlNTY2MzFjM2IuanBlZ5GTBc0BHcyg" />Kontrola miała rozwiązać problem ziarna z Ukrainy na polskim rynku. Tyle że nasze służby nieprawidłowości wykrywały incydentalnie.

## Zboże wjeżdża na salony UE. Otwiera się okno możliwości rozwiązania sporu?
 - [https://forsal.pl/biznes/rolnictwo/artykuly/8701509,zboze-wjezdza-na-salony-ue-otwiera-sie-okno-mozliwosci-rozwiazania-sporu.html](https://forsal.pl/biznes/rolnictwo/artykuly/8701509,zboze-wjezdza-na-salony-ue-otwiera-sie-okno-mozliwosci-rozwiazania-sporu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 05:29:18+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/b6dktkuTURBXy83YTEwNjk0My1jN2I0LTQ0MDYtYTU1ZS1lYWE0ZWQ3NDY2YjUuanBlZ5GTBc0BHcyg" />W sprawie problemu ukraińskiego zboża zalegającego w Polsce rząd z jednej strony próbuje przeforsować własne pomysły na forum UE, a z drugiej – porozumieć się z Ukrainą.

## Inwestorzy farm słonecznych szturmują urzędy. Rząd szykuje im ograniczenia
 - [https://forsal.pl/biznes/energetyka/artykuly/8700343,inwestorzy-farm-slonecznych-szturmuja-urzedy-rzad-szykuje-im-ograniczenia.html](https://forsal.pl/biznes/energetyka/artykuly/8700343,inwestorzy-farm-slonecznych-szturmuja-urzedy-rzad-szykuje-im-ograniczenia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 04:48:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/oqQktkuTURBXy9hMzYxOTY0MC1lNzkzLTQyZDEtYWZiYi1hYjMyOGY3NmM3YWUuanBlZ5GTBc0BHcyg" />Nawet pięć lat luki inwestycyjnej czeka rynek elektrowni słonecznych, jeśli planowane zmiany w ustawie o planowaniu i zagospodarowaniu przestrzennym wejdą w życie.

## Pracujesz w nocy? Przysługuje ci dodatek
 - [https://forsal.pl/praca/wynagrodzenia/artykuly/8699728,pracujesz-w-nocy-przysluguje-ci-dodatek.html](https://forsal.pl/praca/wynagrodzenia/artykuly/8699728,pracujesz-w-nocy-przysluguje-ci-dodatek.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 04:40:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/-FlktkuTURBXy9hMjIyNGFkYS0zNDRlLTQ2NTUtYWZjNC1iNzk1OGM3NWI2MDcuanBlZ5GTBc0BHcyg" />Dwukrotne (w styczniu i w lipcu) podniesienie wynagrodzenia minimalnego wiąże się także z większym dodatkiem za pracę w nocy. Zgodnie z Kodeksem pracy musi on wynosić nie mniej niż 20 proc. stawki godzinowej, która wynika z minimalnego wynagrodzenia.

## Adidas kontra Nike. Król butów sportowych jest tylko jeden
 - [https://forsal.pl/biznes/handel/artykuly/8700227,adidas-kontra-nike-oto-najwieksi-producenci-butow-sportowych-na-swiecie.html](https://forsal.pl/biznes/handel/artykuly/8700227,adidas-kontra-nike-oto-najwieksi-producenci-butow-sportowych-na-swiecie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 04:33:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/7g4ktkuTURBXy85ZDg4M2NjYS04YjQzLTQxNzUtODliYi01M2NlZWRlNTZjMWEuanBlZ5GTBc0BHcyg" />Nike jest zdecydowanym globalnym liderem w sprzedaży sportowych butów. Korzysta na ogromnej popularności tego typu obuwia, które zdobyło szturmem nie tylko korty i boiska, ale także ulice i wnętrza.

## Rynek gier stoi Millenialsami. Grają więcej niż Zetki i nastolatki
 - [https://forsal.pl/lifestyle/rozrywka/artykuly/8699724,rynek-gier-stoi-millenialsami-graja-wiecej-niz-zetki-i-nastolatki.html](https://forsal.pl/lifestyle/rozrywka/artykuly/8699724,rynek-gier-stoi-millenialsami-graja-wiecej-niz-zetki-i-nastolatki.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 04:21:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/mAHktkuTURBXy83YzI5NDY0NC1kN2Y2LTQyMjItYTBiMC00ZTE0ZmRlODMxYTYuanBlZ5GTBc0BHcyg" />Wybierają gry typu MMO (rozgrywki odbywające się przez Internet), strategiczne i RPG. Jak wynika z raportu Inside Gaming, przedstawionego przez firmę Fandom, grają więcej niż zetki i nastolatki. Millenialsi – to właśnie nimi stoi rynek gier wideo.

## Śmiertelne zagrożenie na drogach? Autopilot Tesli na celowniku
 - [https://forsal.pl/motoforsal/motobiznes/artykuly/8701159,smiertelne-zagrozenie-na-drogach-autopilot-tesli-na-celowniku.html](https://forsal.pl/motoforsal/motobiznes/artykuly/8701159,smiertelne-zagrozenie-na-drogach-autopilot-tesli-na-celowniku.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 04:10:05+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/0dzktkuTURBXy9iNGI4YzgzOC00Y2Q4LTRjMmYtYTE3ZS1jODIwZWJkNjc1ZGQuanBlZ5GTBc0BHcyg" />Tesla ujawniła amerykańskim organom regulacyjnym kolejną, tragiczną w skutkach awarię z udziałem zautomatyzowanych systemów wspomagania kierowcy. Od czerwca 2021 r., kiedy zażądano od producentów samochodów informacji o takich wypadkach, ich liczba wzrosła do 17 przypadków.

## Zapaść na rynku smartfonów. Samsung wyprzedził Apple
 - [https://forsal.pl/lifestyle/technologie/artykuly/8701198,zapasc-na-rynku-smartfonow-samsung-wyprzedzil-apple.html](https://forsal.pl/lifestyle/technologie/artykuly/8701198,zapasc-na-rynku-smartfonow-samsung-wyprzedzil-apple.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 04:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/2jAktkuTURBXy81ZTc0ZjM2OS0zZDIwLTQ4YjgtOTlhNC0wMDU2YmE0MWJlNmUuanBlZ5GTBc0BHcyg" />Spadek sprzedaży trwa już od pięciu kwartałów. W ujęciu rok do roku wynosi 12 proc. Pomimo poprawy głównych czynników makroekonomicznych, rynek jeszcze się nie odbudował.

## Koniec historii Credit Suisse
 - [https://forsal.pl/gospodarka/artykuly/8700302,koniec-historii-credit-suisse.html](https://forsal.pl/gospodarka/artykuly/8700302,koniec-historii-credit-suisse.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-19 03:45:04+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/BDWktkuTURBXy8zZmZhZGJhYy0wNzZmLTQyMjAtOGE1OC1mYzMzYmJhMDhmZjIuanBlZ5GTBc0BHcyg" />Z krajobrazu szwajcarskiego i globalnego sektora bankowego znika Credit Suisse – bank ze 167-letnią tradycją. Jak to się stało, że systemowo istotny bank w skali globalnej kończy tak nagle swoją działalność?

