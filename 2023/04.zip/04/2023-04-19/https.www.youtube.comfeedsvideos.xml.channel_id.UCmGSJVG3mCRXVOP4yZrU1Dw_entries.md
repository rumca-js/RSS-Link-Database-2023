# Source:John Harris, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCmGSJVG3mCRXVOP4yZrU1Dw, language:en-US

## Kim Jong-Il Kidnapped Filmmakers to Make a Monster Movie
 - [https://www.youtube.com/watch?v=chAcK_3zBSY](https://www.youtube.com/watch?v=chAcK_3zBSY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmGSJVG3mCRXVOP4yZrU1Dw
 - date published: 2023-04-19 15:00:24+00:00

Why Kim Jong-Il Kidnapped Filmmakers
Use code JOHNNYHARRIS at the link below to get an exclusive 60% off an annual Incogni plan: https://incogni.com/johnnyharris

We watched a ton of North Korean films. Here’s what we learned about propaganda from them.

My next video is live on Nebula NOW! It's about how the discovery of the North Pole was faked. Watch now: https://nebula.tv/videos/johnnyharris-the-american-who-faked-discovering-the-north-pole

Check out all my sources for this video here: https://docs.google.com/document/d/1WU-33qP1yVpSZeo-Kds52l0EEJchoBhf79139mV7WpA/edit?usp=sharing

Get access to behind-the-scenes vlogs, my scripts, and extended interviews over at https://www.patreon.com/johnnyharris

I made a poster about maps - check it out: https://store.dftba.com/products/all-maps-are-wrong-poster

Custom Presets & LUTs [what we use]: https://store.dftba.com/products/johnny-iz-luts-and-presets

About: 
Johnny Harris is an Emmy-winning independent journalist and contributor to the New York Times. Based in Washington, DC, Harris reports on interesting trends and stories domestically and around the globe, publishing to his audience of over 3.5 million on Youtube.  Harris produced and hosted the twice Emmy-nominated series Borders for Vox Media. His visual style blends motion graphics with cinematic videography to create content that explains complex issues in relatable ways.

- press - 
NYTimes: https://www.nytimes.com/2021/11/09/opinion/democrats-blue-states-legislation.html
NYTimes: https://www.nytimes.com/video/opinion/100000007358968/covid-pandemic-us-response.html
Vox Borders: https://www.youtube.com/watch?v=hLrFyjGZ9NU
NPR Planet Money: https://www.npr.org/transcripts/1072164745


- where to find me -
Instagram: https://www.instagram.com/johnny.harris/
Tiktok: https://www.tiktok.com/@johnny.harris
Facebook: https://www.facebook.com/JohnnyHarrisVox
Iz's (my wife’s) channel: https://www.youtube.com/iz-harris

- how i make my videos -
Tom Fox makes my music, work with him here: https://tfbeats.com/
I make maps using this AE Plugin: https://aescripts.com/geolayers/?aff=77
All the gear I use: https://www.izharris.com/gear-guide
 
- my courses - 
Learn a language: https://brighttrip.com/course/language/
Visual storytelling: https://www.brighttrip.com/courses/visual-storytelling

