# Source:The Wall Street - Tech, URL:https://feeds.a.dj.com/rss/RSSWSJD.xml, language:en-US

## Your Share of the $725M Facebook Settlement Will Be Tiny
 - [https://www.wsj.com/articles/your-share-of-the-725m-facebook-settlement-will-be-tiny-93265db0?mod=rss_Technology](https://www.wsj.com/articles/your-share-of-the-725m-facebook-settlement-will-be-tiny-93265db0?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-04-19 20:53:00+00:00

If you used Facebook in the U.S. between 2007 and 2022, you can get a cut of the settlement of the suit accusing the social-media company of allowing third parties to access private information.

## What Does Your iPhone Color Say About You? Red Is for Attention-Seekers and 5 More Insights from a Color Theorist
 - [https://www.wsj.com/articles/what-does-your-iphone-color-say-about-you-8e7da320?mod=rss_Technology](https://www.wsj.com/articles/what-does-your-iphone-color-say-about-you-8e7da320?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-04-19 20:00:00+00:00

We use our phones to communicate almost everything but pay little heed to what their pigment broadcasts about us. Here, a psychologist weighs in on our choices.

## Apple's Tim Cook Meets India Prime Minister Modi, in Move to Diversify Supply Chain
 - [https://www.wsj.com/articles/apple-ceo-tim-cook-meets-india-prime-minister-modi-in-move-to-diversify-supply-chain-76fefebd?mod=rss_Technology](https://www.wsj.com/articles/apple-ceo-tim-cook-meets-india-prime-minister-modi-in-move-to-diversify-supply-chain-76fefebd?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-04-19 16:48:00+00:00

Apple chief executive met with India’s Narendra Modi, visiting the country where the iPhone maker wants to expand its manufacturing footprint and smartphone sales.

## The iPhone Setting Thieves Use to Lock You Out of Your Apple Account
 - [https://www.wsj.com/articles/the-iphone-setting-thieves-use-to-lock-you-out-of-your-apple-account-716d350d?mod=rss_Technology](https://www.wsj.com/articles/the-iphone-setting-thieves-use-to-lock-you-out-of-your-apple-account-716d350d?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-04-19 09:30:00+00:00

The recovery key was designed to make Apple IDs safer. Instead, these victims permanently lost family photos and other precious digital possessions.

## TSMC Seeks Up to $15 Billion From U.S. for Chip Plants but Objects to Conditions
 - [https://www.wsj.com/articles/tsmc-seeks-up-to-15-billion-from-u-s-for-chip-plants-but-objects-to-conditions-3bf6cfc1?mod=rss_Technology](https://www.wsj.com/articles/tsmc-seeks-up-to-15-billion-from-u-s-for-chip-plants-but-objects-to-conditions-3bf6cfc1?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-04-19 09:00:00+00:00

The world’s biggest contract chip maker is pushing back on some of the conditions Washington has attached to chip-factory subsidies as it looks for up to $15 billion in government money.

