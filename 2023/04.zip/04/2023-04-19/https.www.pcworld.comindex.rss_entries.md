# Source:PC world, URL:https://www.pcworld.com/index.rss, language:en-US

## Chrome gets its second emergency patch this week
 - [https://www.pcworld.com/article/1791506/chrome-gets-its-second-emergency-patch-this-week.html](https://www.pcworld.com/article/1791506/chrome-gets-its-second-emergency-patch-this-week.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-04-19 15:36:51+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>Hey Chrome, are you feeling okay? Because this is <a href="https://www.pcworld.com/article/1788808/update-chrome-now-to-protect-yourself-from-this-zero-day-exploit.html" rel="noreferrer noopener" target="_blank">the second time in just five days</a> that you&rsquo;ve been patched for a zero-day vulnerability. Last Friday Google released a patch that fixed an issue in the browser&rsquo;s JavaScript engine, but today&rsquo;s bug is in the Skia graphics library. Chrome users on Windows and Mac can download and apply the update right now, while Linux and other platforms should see the update in the next few days. </p>



<p>Resist the urge to push that update back, because this isn&rsquo;t something that you should ignore. Like last week&rsquo;s bug, it&rsquo;s being actively exploited &ldquo;in the wild,&rdquo; according to <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://chromereleases.googleblog.com/2023/04/stable-channel-update-for-desktop_18.html&amp;xcust=2-1-1791506-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow" target="_blank">Google&rsquo;s post on the Chrome Releases page</a>. (via <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.bleepingcomputer.com/news/security/google-patches-another-actively-exploited-chrome-zero-day/&amp;xcust=2-1-1791506-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow" target="_blank">Bleeping Computer</a>). Unlike the other security bugs fixed in this update, which were reported by members of the Vulnerability Research Institute and paid out in $20,000 of total bug bounties, the critical flaw was discovered by Cl&eacute;ment Lecigne of Google&rsquo;s Threat Analysis Group. </p>



<p>It&rsquo;s been exactly one week since the CVE-2023-2136 bug was identified, which is a pretty good turnaround for a company that&rsquo;s larger in dollar terms than several countries. Details on exactly how the bug is being exploited aren&rsquo;t available &mdash; presumably Google doesn&rsquo;t want anyone else joining in on whatever they&rsquo;ve seen happening in the wild. </p>

Security</div>

## Score this pixel-packed 4K Dell monitor for just $250
 - [https://www.pcworld.com/article/1791468/1791468.html](https://www.pcworld.com/article/1791468/1791468.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-04-19 14:47:42+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>Whether you&rsquo;re watching movies or doing office work, there&rsquo;s nothing quite like the sharpness of a 4K IPS monitor. If you&rsquo;re in the market for such a monitor, then you better hold onto your seat, as we&rsquo;ve got a killer deal for you today. Dell&rsquo;s selling the <a href="https://www.anrdoezrs.net/click-8200811-12839518?url=https://www.dell.com/en-us/shop/dell-27-4k-uhd-monitor-s2721qs/apd/210-axlg/monitors-monitor-accessories&amp;sid=2-1-1791468-1-0-0" rel="nofollow">Dell S2721QS 4K IPS monitor for just $249.99</a>, which is a savings of $80. That&rsquo;s a ridiculously good price for an IPS monitor with a 4K resolution, especially given Dell&rsquo;s pedigree of excellent displays.  </p>



<p>The 27-inch Dell S2721QS has a resolution of 3840&times;2160, a refresh rate of 60Hz, and a response time of 4ms. This specific monitor has a high pixel-per-inch density of 163, so images and text should be nice and crisp, with the IPS panel providing wide viewing angles from almost any perspective. The 99% sRGB color gamut is insane, too. That means you&rsquo;re in for a pretty color accurate picture. Thanks IPS! Other features include AMD FreeSync, which syncs up the monitor&rsquo;s refresh rate with your PC&rsquo;s graphics card. This is useful when gaming, as it helps reduce any screen tearing issues. </p>



<p>Overall, this is a fantastic deal. You don&rsquo;t see many 4K monitors for under $300, much less Dell models. Nab it now before it&rsquo;s gone forever.</p>


<p class="cta wp-block wp-block-button"><a class="cta__btn" href="https://www.anrdoezrs.net/click-8200811-12839518?url=https://www.dell.com/en-us/shop/dell-27-4k-uhd-monitor-s2721qs/apd/210-axlg/monitors-monitor-accessories&amp;sid=2-1-1791468-7-0-0" rel="nofollow" target="_blank">Get the Dell S2721QS monitor for $249.99 at Dell</a></p>
Monitors</div>

## How to factory reset your Windows 11 laptop
 - [https://www.pcworld.com/article/1784013/how-to-factory-reset-your-windows-11-laptop.html](https://www.pcworld.com/article/1784013/how-to-factory-reset-your-windows-11-laptop.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-04-19 14:30:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>If your laptop is running slower than usual, a factory reset may be in order. It&rsquo;s an effective way to remove malware or your personal files if you plan on reselling your device. Whatever the reason may be, the process is fairly simple and straightforward. Let&rsquo;s get right into it.</p>



<blockquote class="wp-block-quote"><p>Are you on the prowl for a brand new laptop? If so, you should check out our roundup of the <a href="https://www.pcworld.com/article/436674/the-best-pc-laptops-of-the-year.html">best laptops</a> available today.</p></blockquote>



<h2 id="how-to-factory-reset-your-laptop">How to factory reset your laptop</h2>



<p>To find the reset options, open the Windows menu on the task bar and click the &ldquo;Settings&rdquo; gear icon.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-full"><img alt="Click the &quot;Settings&quot; icon from the Windows menu on the task bar." class="wp-image-1784028" height="683" src="https://b2c-contenthub.com/wp-content/uploads/2023/04/press-windows-button-and-select-settings-icon.jpg?quality=50&amp;strip=all" width="1024" /></figure><p class="imageCredit">IDG / Alex Huebner</p></div>



<p>In the Settings menu, left click the &ldquo;Recovery&rdquo; option toward the bottom of the page.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-full"><img alt="Left click on the Recovery option towards the bottom." class="wp-image-1784029" height="683" src="https://b2c-contenthub.com/wp-content/uploads/2023/04/how-to-factory-reset-your-laptop-open-recovery-settings.jpg?quality=50&amp;strip=all" width="1024" /></figure><p class="imageCredit">IDG / Alex Huebner</p></div>



<p>In the Recovery menu, click the &ldquo;Reset PC&rdquo; button on the right side of the screen. A new window will pop up as a result.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-full"><img alt="Click the &quot;Reset PC&quot; button on the right side of the screen." class="wp-image-1784040" height="683" src="https://b2c-contenthub.com/wp-content/uploads/2023/04/how-to-factory-reset-your-laptop-reset-pc.jpg?quality=50&amp;strip=all" width="1024" /></figure><p class="imageCredit">IDG / Alex Huebner</p></div>



<p>In the Reset this PC window, you&rsquo;ll see two options: &ldquo;Keep my files&rdquo; or &ldquo;Remove everything.&rdquo; </p>



<p>If you choose to keep the files, it&rsquo;ll direct you to your Windows account. where you can download all of your apps and personal files. Removing everything will wipe the slate clean, so to speak. There&rsquo;s also a &ldquo;Help me choose&rdquo; button on the bottom right of the window that will walk you through which option is best.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-full"><img alt="How to factory set your Windows 11 laptop" class="wp-image-1784023" height="683" src="https://b2c-contenthub.com/wp-content/uploads/2023/04/how-to-factory-reset-your-laptop-choose-keep-files-or-complete-reset.jpg?quality=50&amp;strip=all" width="1024" /></figure><p class="imageCredit">IDG / Alex Huebner</p></div>



<p>Once you make your decision, your Windows 11 laptop will begin the factory reset and remove old downloads, apps, etc. You&rsquo;ll just have to follow the Windows prompts to complete the process. Make sure <a href="https://www.pcworld.com/article/407021/best-windows-backup-software.html">you have everything you need backed up</a> before you begin, though!</p>

Laptops</div>

## I don’t want to live in Apple’s world, but I sure envy it
 - [https://www.pcworld.com/article/1788067/i-dont-want-to-live-in-apples-world-but-i-sure-envy-it.html](https://www.pcworld.com/article/1788067/i-dont-want-to-live-in-apples-world-but-i-sure-envy-it.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-04-19 13:21:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>Despite having Apple products, I don&rsquo;t self-identify as an Apple user. I&rsquo;m happy to be on Team Windows and Team Android. I like Windows&rsquo; broader support for applications, and I have a tethering app for Android you&rsquo;ll need a crowbar to separate me from.</p>



<p>And yet, life can be awkward as a non-Apple fan. The reason I have an old <a href="https://www.macworld.com/article/669997/best-macbook-apple-laptop.html">Macbook</a> and iPhone is because so many people around me do, and it&rsquo;s often the fastest way to get photos and video transferred from between us. Asking someone to upload to iCloud or Google Photos and send me a link can spark a befuddled glance. In contrast, requesting an AirDrop transfer will always go off without a hitch.</p>



<p>You know how long it took for Windows to finally have a similar-ish equivalent? It didn&rsquo;t happen until <em>this month</em>, when Google launched a beta feature for its Nearby Share service that allows <a href="https://www.pcworld.com/article/1680736/androids-airdrop-alternative-nearby-share-now-works-on-windows.html">Android phones to share files with a Windows PC</a>. Before then, you could transfer files over Nearby Share within Google&rsquo;s ecosystem only. Meanwhile, Windows machines have only had a sharing feature for other Windows machines&mdash;and for truly quick transfers, you need Windows 11 for Wi-Fi support. Windows 10 machines share over Bluetooth, which is slower. It&rsquo;s also been glitchy in my experience, with file transfers inexplicably dropping out midway.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="" class="wp-image-1788073" height="766" src="https://b2c-contenthub.com/wp-content/uploads/2023/04/image-13.png?w=1200" width="1200" /><figcaption>Windows has built-in sharing features, but file transfers can be unstable over Bluetooth connections.</figcaption></figure></div>



<p>This patchwork, half-baked experience does not exist in Apple&rsquo;s world. To riff off the cliche line, file transfers just work. Which annoys me, because why don&rsquo;t they in Windows? Why shouldn&rsquo;t Windows simply work with other Windows devices as seamlessly, much less the biggest phone operating system? And why did it take a decade after AirDrop&rsquo;s release to get a duct-taped equivalent?</p>



		<div class="wp-block-product-widget-block product-widget is-half-width is-float-right">
			<div class="product-widget__block-title-wrapper">
				<h4 class="product-widget__block-title" id="samsung-comes-closest-to-apples-seamless-sharing">
					Samsung comes closest to apple's seamless sharing				</h4>
			</div>

			<div class="product-widget__content-wrapper">
									<div class="product-widget__title-wrapper">
						<h3 class="product-widget__title" id="samsung-galaxy-tab-s8">Samsung Galaxy Tab S8+</h3>
					</div>
				
									<div class="product-widget__image-outer-wrapper">
						<div class="product-widget__image-wrapper">
							<img alt="Samsung Galaxy Tab S8+" class="product-widget__image" height="4160" src="https://b2c-contenthub.com/wp-content/uploads/2022/02/DSCF0664.jpg?quality=50&amp;strip=all" width="6240" />
						</div>
					</div>
				
				
				<div class="product-widget__information">
												<div class="product-widget__information--rrp-wrapper">
									<span class="product-widget__information--rrp-label">
																	</span>
									<span class="product-widget__information--rrp-value">
																		</span>
								</div>
								
											<div class="product-widget__pricing-details  ">
															<span class="product-widget__pricing-details--label">
									Best Prices Today:
								</span>
														<span class="product-widget__pricing-details--links-wrapper">
								<a class="product-widget__pricing-details--link" href="https://www.anrdoezrs.net/click-8200811-12839518?url=https://www.tkqlhce.com/click-8200811-13513947?url=https%3A%2F%2Fwww.dell.com%2Fen-us%2Fshop%2Fsamsung-galaxy-tab-s8-tablet-android-128-gb-124-super-amoled-2800-x-1752-microsd-slot-pink-gold%2Fapd%2Fab981276%2Fhandhelds-tablet-pcs&amp;sid=2-1-1788067-5-790023-11290" rel="nofollow" target="_blank">$699.99 at  Dell Small Business</a>											<span class="amp-bar"> | </span>
																		<a class="product-widget__pricing-details--link" href="https://bestbuy.7tiv.net/c/321564/633495/10014?prodsku=6494229&amp;u=https%3A%2F%2Fapi.bestbuy.com%2Fclick%2F-%2F6494229%2Fpdp&amp;intsrc=CATF_4831&amp;subid1=2-1-1788067-5-790023-11290" rel="nofollow" target="_blank">$819.99 at  Best Buy</a>											<span class="amp-bar"> | </span>
																		<a class="product-widget__pricing-details--link" href="https://adorama.rfvk.net/c/321564/1175784/1036?prodsku=SSGSMX8NXAR&amp;u=https%3A%2F%2Fwww.adorama.com%2Fssgsmx8nxar.html&amp;intsrc=CATF_9102&amp;subid1=2-1-1788067-5-790023-11290" rel="nofollow" target="_blank">$899.99 at  Adorama</a>							</span>
						</div>
									</div>
			</div>
		</div>

		


<p>Apple trounces Windows (and Android) in other areas, too&mdash;like text messaging. In the Apple ecosystem, you don&rsquo;t need to be chained to your phone. You can access iMessages on Macs and iPads signed into the same account. The closest we get on Android is using <a href="https://www.pcworld.com/article/1679491/messages-for-web-helps-me-hate-text-messaging-a-little-less.html">Messages for Web</a> (which I adore, but isn&rsquo;t quite the same), or using <a href="https://www.pcworld.com/article/628261/microsoft-is-updating-your-phone-and-calling-it-phone-link.html">Phone Link</a> on Windows, which is okay, but lacks polish and requires you to have a Microsoft account to use. If you own Samsung devices, you can get closer to the iMessages experience on <a href="https://www.pcworld.com/article/1536118/samsungs-pc.html">Samsung phones and tablets</a>, and then use Phone Link for access on Windows. To me that&rsquo;s no less duct-taped a solution, though. It&rsquo;s merely done with neater strips.</p>



<p>I recognize I want the polish of walled ecosystem outside its gates, but in 2023, this doesn&rsquo;t feel like as big of an ask as it was even ten years ago. I don&rsquo;t know what goes on behind closed doors, but is not the enemy of one&rsquo;s enemy a friend? You&rsquo;d think Microsoft and Google would want to partner more strongly (and more quickly).</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-full"><img alt="iphone_home_screen_ios_16.jpg" class="wp-image-1458717" src="https://images.macworld.co.uk/cmsdata/features/3817236/iphone_home_screen_ios_16.jpg?quality=50&amp;strip=all" /><figcaption>As long as iOS prevents me from customizing my icons (and icon placement), an iPhone will never become my daily driver.</figcaption></figure><p class="imageCredit">Macworld</p></div>



<p>Third-party software has filled the void until now, but I haven&rsquo;t always liked the options. (Or the security and privacy concerns of trusting them with my data.) On occasion, I&rsquo;ve even momentarily been <a href="https://www.macworld.com/article/228816/best-iphone-pro-mini-max.html">tempted into switching to Apple gear</a>. (Then I remember I can&rsquo;t change my default map app on iPhone, and I put down my wallet.)</p>



		<div class="wp-block-product-widget-block product-widget is-half-width is-float-right">
			<div class="product-widget__block-title-wrapper">
				<h4 class="product-widget__block-title" id="">
									</h4>
			</div>

			<div class="product-widget__content-wrapper">
									<div class="product-widget__title-wrapper">
						<h3 class="product-widget__title" id="apple-13-inch-macbook-pro-m2-2022">Apple 13-inch MacBook Pro (M2, 2022)</h3>
					</div>
				
									<div class="product-widget__image-outer-wrapper">
						<div class="product-widget__image-wrapper">
							<img alt="Apple 13-inch MacBook Pro (M2, 2022)" class="product-widget__image" src="https://images.macworld.co.uk/cmsdata/deal/3701475/apple_macbook_pro-13-inch-with-retina-display_screen_05042020.jpg?quality=50&amp;strip=all" />
						</div>
					</div>
				
				
				<div class="product-widget__information">
											<div class="product-widget__information--rrp-wrapper">
								<span class="product-widget__information--rrp-label">
															</span>
								<span class="product-widget__information--rrp-value">
																</span>
							</div>
						
									</div>
			</div>
		</div>

		


<p>Mostly, I&rsquo;ve reached a point in life where I feel stretched thin between obligations. The mental overhead of juggling extra software and settings for what feels like should be basic functionality adds more straws to the camel&rsquo;s back.</p>



<p>Maybe one day I&rsquo;ll be okay with never being able to change the look of my icons on my phone, or having an icon anywhere I dang please on my home screen. But in the mean time, I just want to know: There are so many of us who use Windows and Android. Why isn&rsquo;t the relationship between them (and among them) better?</p>

Android, Apple, Windows</div>

## I switched from Photoshop to Canva and I don’t regret one second of it
 - [https://www.pcworld.com/article/1682580/i-switched-from-photoshop-to-canva-and-i-dont-regret-one-second-of-it.html](https://www.pcworld.com/article/1682580/i-switched-from-photoshop-to-canva-and-i-dont-regret-one-second-of-it.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-04-19 10:45:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>Before I begin, I should preface this article with a disclaimer: I&rsquo;m not out here trying to shade Adobe Photoshop <em>or</em> its fans (I&rsquo;m speaking directly to my colleague Michael Crider here). <a href="https://www.pcworld.com/article/1680257/is-adobe-photoshop-worth-it-5-pros-5-cons-and-5-alternative-image-editors.html">Photoshop is a wonderful graphic design tool for many folks</a>. That said, I prefer to use <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.canva.com/&amp;xcust=2-1-1682580-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow">Canva</a>, a free-to-use program that&rsquo;s meant to be used in a web browser. It&rsquo;s definitely more straightforward and user-friendly than Photoshop. I like software that&rsquo;s intuitive and convenient, and that&rsquo;s exactly what Canva is. From the drag-and-drop interface to the easy-to-use editing tools, I use this program every single day for work, especially when I&rsquo;m resizing images for the PCWorld site. </p>



<blockquote class="wp-block-quote"><p>Looking for more Photoshop alternatives? Check out these <a href="https://www.pcworld.com/article/551303/5-free-alternatives-to-photoshop-for-windows.html">free graphic design programs for Windows</a>.</p></blockquote>



<h2 id="no-training-or-experience-required">No training or experience required</h2>



<p>Photoshop is designed for complex image editing and doesn&rsquo;t offer you ready-to-use templates as well as graphic elements. It&rsquo;s a mighty piece of software that takes a good amount of time and patience to learn given all the features and functionality it offers. Canva, on the other hand, requires no training or experience to use. In fact, when I first made a Canva account back in 2020, I jumped right in and learned the various functions on the fly. The tools are clearly labeled and easy to comprehend. </p>



<p>As you can see in the screenshot of Canva below, you can do all kinds of things to your image, from adding text and graphics to creating collages and more. Me? I decided to load up a goofy picture of my greyhound with a bunch of animated dogs because why not. The interface is straightforward and it&rsquo;s easy to remove your mistakes thanks to the left arrow button on the bluish bar above your image. Canva even offers templates for social media posts, presentations, flyers, and more. The possibilities are endless&hellip;almost.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Canva screenshot" class="wp-image-1684340" height="675" src="https://b2c-contenthub.com/wp-content/uploads/2023/04/Screenshot-2023-04-05-2.39.54-PM.png?w=1200" width="1200" /></figure><p class="imageCredit">IDG / Ashley Biancuzzo</p></div>



<h2 id="its-simpler-than-photoshop">It&rsquo;s simpler than Photoshop</h2>



		<div class="wp-block-product-widget-block product-widget is-half-width is-float-right">
			<div class="product-widget__block-title-wrapper">
				<h4 class="product-widget__block-title" id="photoshop-offers-more-customization">
					Photoshop offers more customization				</h4>
			</div>

			<div class="product-widget__content-wrapper">
									<div class="product-widget__title-wrapper">
						<h3 class="product-widget__title" id="adobe-creative-cloud">Adobe Creative Cloud</h3>
					</div>
				
									<div class="product-widget__image-outer-wrapper">
						<div class="product-widget__image-wrapper">
							<img alt="Adobe Creative Cloud" class="product-widget__image" src="https://images.techadvisor.com/cmsdata/features/3790974/adove-creative-cloud_1.jpg?quality=50&amp;strip=all" />
						</div>
					</div>
				
				
				<div class="product-widget__information">
												<div class="product-widget__information--rrp-wrapper">
									<span class="product-widget__information--rrp-label">
																	</span>
									<span class="product-widget__information--rrp-value">
																		</span>
								</div>
								
									</div>
			</div>
		</div>

		


<p>With Canva, you&rsquo;re stuck with basic editing and adjustment tools. You can&rsquo;t do things like brighten up an image or edit a selected part. You definitely get more customization options with Photoshop. However, that&rsquo;s not necessarily a bad thing. I&rsquo;m a writer and editor by profession, so I don&rsquo;t need the complex editing tools that Photoshop offers. My day-to-day consists of writing, editing, and resizing images. Occasionally, if I&rsquo;m feeling particularly feisty, I may add a weird graphic or two to the images I&rsquo;m resizing. Other than that, I don&rsquo;t need many tools or features to get the job done. Just the barebones for me, thanks. Most people will probably find it more than capable as well.</p>



<h2 id="you-dont-need-a-powerful-computer-to-use-it">You don&rsquo;t need a powerful computer to use it</h2>



<p>Photoshop is a resource-heavy program that requires the hardware of a relatively powerful computer. According to <a href="https://adobe.prf.hn/click/camref:1011lroIY/pubref:2-1-1682580-1-0-0/destination:https://helpx.adobe.com/photoshop/system-requirements.html" rel="nofollow">Adobe</a>, the recommended system requirements for a Windows machine are as follows: an Intel or AMD CPU, 16GB of RAM, a 1080p display, a 50GB hard drive, and a recent graphics card&mdash;and the more powerful, the better. If you&rsquo;re a photographer, you may want a higher resolution display for those smaller details and a bigger SSD for all of those files. That&rsquo;s not exactly a cheap purchase.</p>



<p>Fortunately, Canva doesn&rsquo;t require a powerful machine to use because it&rsquo;s web-based. All you need is a solid Wi-Fi connection and you&rsquo;re in. I regularly use Canva <a href="https://www.pcworld.com/article/608636/best-chromebooks.html">on my Chromebook</a>, which isn&rsquo;t very powerful at all, and I&rsquo;ve experienced hardly any problems with that. </p>



<h2 id="canvas-free-to-use">Canva&rsquo;s free to use</h2>



<p>Photoshop alone costs $250 a year, and that&rsquo;s not even counting the additional costs of other Adobe apps. That said, <a href="https://adobe.prf.hn/click/camref:1011lroIY/pubref:2-1-1682580-1-0-0/destination:https://www.adobe.com/products/photoshop-elements/buy-elements.html?utm_campaign=cv-nwmp-ae2023&amp;utm_medium=cpc&amp;utm_source=google&amp;utm_content=AE2023-RSA02-LP1&amp;utm_term=adobe%20elements&amp;gclid=Cj0KCQjwuLShBhC_ARIsAFod4fKD8kTeljVInK_2dR69nRBz4acfWudrZJqKeX1ngpgCIOTiEcnrHcYaAoSQEALw_wcB" rel="nofollow">Photoshop Elements</a> is a one-time purchase of $99.99, if you&rsquo;re so inclined. I&rsquo;ve only ever used the free version of Canva and I&rsquo;ve got no qualms with it. Like I said earlier, the interface is intuitive and it has all the basic image editing tools I need for work. The free version includes 5GB of cloud storage, one million free photos and graphics, a drag-and-drop editor, and more. That&rsquo;s more than enough for me.</p>



<p>If you&rsquo;re curious and want to check out Canva&rsquo;s <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.canva.com/pricing/&amp;xcust=2-1-1682580-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow">subscription services</a>, the Pro model with additional capabilities costs $119.99 a year. It&rsquo;s designed for one person to use and it&rsquo;s a better price than traditional Photoshop. This model bumps up the cloud storage to 1TB (from 5GB), offers 24/7 customer support, unlocks a ton of new professional-focused features, and so on. Canva also has a top-tier subscription that costs $149.90 a year. It&rsquo;s designed for multiple people to use and it&rsquo;s more work-focused in the sense that it focuses on collaboration between teams. </p>

Personal Software</div>

## Asus ROG Swift OLED PG27AQDM review: It isn’t perfect, but gamers will fall in love
 - [https://www.pcworld.com/article/1785865/asus-rog-swift-oled-pg27aqdm-review.html](https://www.pcworld.com/article/1785865/asus-rog-swift-oled-pg27aqdm-review.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-04-19 10:30:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>


<div class="review" id="review-body"><span class="review-title">At a glance</span><h3 class="review-subTitle" id="experts-rating">Expert's Rating</h3><div class="starRating"></div>
<div><div class="review-columns"><div class="review-column"><h3 class="review-subTitle" id="pros">Pros</h3><ul class="pros review-list"><li>Excellent contrast ratio</li><li>Superb motion clarity&nbsp;</li><li>Good luminance stability in SDR</li><li>Extensive menu options</li></ul></div><div class="review-column"><h3 class="review-subTitle" id="cons">Cons</h3><ul class="cons review-list"><li>Out-of-box color performance isn&rsquo;t great</li><li>Limited connectivity and no USB-C</li><li>HDR brightness falls well behind Mini-LED</li></ul></div></div></div><h3 class="review-subTitle review-subTitle--borderTop" id="our-verdict">Our Verdict</h3><p class="verdict">The Asus ROG Strix PG27AQDM stumbles in some tests, but gamers will love its superb motion clarity and top-notch contrast.</p>
</div>
				<h3 class="review-best-price" id="best-prices-today-asus-rog-swift-oled-pg27aqdm">
			Best Prices Today: Asus ROG Swift OLED PG27AQDM		</h3>
				<div class="wp-block-price-comparison price-comparison ">
			<div class="price-comparison__record price-comparison__record--header">
				<div>
					<span>Retailer</span>
				</div>
				<div class="price-comparison__price">
					<span>Price</span>
				</div>
			</div>

														<div class="price-comparison__record">
							<div class="price-comparison__image">
																	<span>Asus</span>
															</div>
							<div class="price-comparison__price">
								<span>$999.00</span>
							</div>
							<div>
								<a class="price-comparison__view-button" href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://rog.asus.com/us/monitors/27-to-31-5-inches/rog-swift-oled-pg27aqdm/&amp;xcust=2-1-1785865-2-1785885-11291&amp;sref=https://www.pcworld.com/feed" rel="nofollow" target="_blank">View Deal</a>							</div>
						</div>
												<div class="price-comparison__record price-comparison__record--footer">
					<span class="price-comparison__footer-text">
													Price comparison from over 24,000 stores worldwide												</span>
									</div>
						</div>
		


<p><a href="https://www.pcworld.com/article/1450209/the-year-of-the-oled-monitor-has-finally-arrived.html">2023 is the year of the OLED monitor</a>, unleashing numerous monitors into a space that once included just a couple viable options. Asus&rsquo; ROG Swift OLED PG27AQDM is among the fresh options, delivering a 240Hz refresh rate, high build quality, and excellent image quality at $1,000. However, a few shortcomings limit its appeal to gamers.&nbsp;</p>



<blockquote class="wp-block-quote"><p><strong>Further reading: </strong>See our roundup of the <a href="https://www.pcworld.com/article/813301/best-gaming-monitors.html">best gaming monitors</a> to learn about competing products.</p></blockquote>



<h2 id="what-are-the-asus-rog-swift-oled-pg27aqdm-specs">What are the Asus ROG Swift OLED PG27AQDM specs?</h2>



<p>The Asus ROG Swift OLED PG27AQDM&rsquo;s most notable feature is its most obvious: the 27-inch (well, 26.5-inch) OLED panel. This is the second-most popular monitor size on the market today, and it&rsquo;s suitable for use as a primary monitor on any desk. QD-OLED ultrawides are great, but a 27-inch widescreen is a far more practical choice when space is tight.</p>



<ul><li>Display size: 26.5-inch widescreen</li><li>Native resolution: 2,560 x 1,440</li><li>Panel type: OLED</li><li>Refresh rate: 240Hz</li><li>Adaptive-Sync: Yes, FreeSync and G-Sync Compatible</li><li>HDR: HDR 10</li><li>Ports: 2x HDMI 2.0, 1x DisplayPort 1.4, 2x USB-A, 1x 3.5mm audio</li><li>Stand adjustment: Height, swivel, tilt, pivot</li><li>VESA mount: Yes, 100mm x 100mm</li><li>Speakers: None</li><li>Price: $999</li></ul>



<p>Asus asks almost $1,000, which, though expensive, is in line with other OLED monitors such as the LG Ultragear 27GR95QE-B and Acer X27U. Demand seems to be strong, so I doubt prices will dip until fall of 2023.</p>



<h2 id="asus-rog-swift-oled-pg27aqdm-design">Asus ROG Swift OLED PG27AQDM design&nbsp;</h2>



<p>The Asus ROG Swift OLED PG27AQDM is immediately identifiable as part of the Republic of Gamers brand, for better or worse. The brand&rsquo;s sharp lines and muscular patterns do little for me, personally. Still, I&rsquo;ll give Asus credit for building a distinctive presence, and I&rsquo;m sure it will appeal to the brand&rsquo;s fans.&nbsp;</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Asus ROG Swift OLED PG27AQDM" class="wp-image-1785875" height="800" src="https://b2c-contenthub.com/wp-content/uploads/2023/04/asus-rog-swift-oled-pg27aqdm-5.jpg?quality=50&amp;strip=all&amp;w=1200" width="1200" /><figcaption><p>The rear of the Asus ROG Swift OLED PG27AQDM houses all of the electronics, which keeps the main panel itself thin.</p> </figcaption></figure><p class="imageCredit">Matt Smith</p></div>



<p>Asus highlights the thin OLED panel by consolidating the monitor&rsquo;s electronics into a box that takes up about half the rear panel. The rest is ultra-thin metal and glass. It&rsquo;s a striking profile that telegraphs the OLED panel&rsquo;s presence to PC geeks in the know.&nbsp;</p>



<p>A broad, angular stand keeps the PG27AQDM planted on your desk. It&rsquo;s a handsome and beefy unit with built-in customizable LED lighting. I found the lights too bright for my taste&mdash;fortunately, they can be turned off if desired. The stand takes up significant desk space and might interfere with your established desk layout. An included adapter provides a 100x100mm VESA mount for use with third-party monitor stands and arms.&nbsp;</p>



<h2 id="asus-rog-swift-oled-pg27aqdm-features-and-menus">Asus ROG Swift OLED PG27AQDM features and menus&nbsp;</h2>



<p>The ROG Swift OLED PG27AQDM&rsquo;s connectivity is a bit disappointing. It has just two HDMI 2.0 ports and one DisplayPort 1.4. The HDMI ports are limited to 120Hz. That&rsquo;s not a problem when the monitor is used with an Xbox Series X/S or PlayStation 5 game console, as they can only output up to 120Hz. However, gamers and creators with multiple PCs should keep this limitation in mind.</p>



<p>USB connectivity is lacking as well. The monitor has just two USB-A downstream ports driven by a USB-B upstream port. USB-C is not available. This isn&rsquo;t a deal breaker but, given the monitor&rsquo;s price, Asus should&rsquo;ve gone the extra mile and tossed in USB-C.&nbsp;</p>



<figure class="wp-block-pullquote"><blockquote><p>The Asus ROG Swift OLED PG27AQDM has a striking profile that telegraphs the OLED panel&rsquo;s presence to PC geeks in the know.&nbsp;</p></blockquote></figure>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Asus ROG Swift OLED PG27AQDM" class="wp-image-1785876" height="800" src="https://b2c-contenthub.com/wp-content/uploads/2023/04/asus-rog-swift-oled-pg27aqdm-4.jpg?quality=50&amp;strip=all&amp;w=1200" width="1200" /><figcaption><p>Asus provides a ton of customization options in the menu for the ROG Swift OLED PG27AQDM.</p>
</figcaption></figure><p class="imageCredit">Matt Smith</p></div>



<p>While connectivity is limited, Asus goes all-in on the menu system. It offers a wide variety of color modes, including an sRGB mode, and color customization options such as color temperature, gamma, and six-axis color calibration. There&rsquo;s also a range of gamer-centric features such as a black stablizer, which increases the brightness of dark areas to reveal hidden foes, and an on-screen crosshair.&nbsp;</p>



<p>Asus tosses in two extremely handy features that I&rsquo;ve yet to see on a competitive monitor. The first is a &ldquo;uniform brightness&rdquo; setting that can be used to override the standard brightness setting in SDR content. It lowers the panel&rsquo;s overall brightness but keeps luminance stable. Most OLED monitors have problems maintaining a stable level of brightness when bright objects appear on-screen, but this setting eliminates the problem.</p>



<p>There&rsquo;s also an HDR brightness override that allows user brightness adjustments in HDR mode. Readers who&rsquo;ve yet to buy an HDR monitor might be surprised to hear this isn&rsquo;t possible on most HDR monitors. Brightness is often controlled by the device and content rather than the monitor, which can lead to undesirable swings in brightness. The HDR brightness override can eliminate this issue, though at the expense of image quality.</p>



<p>What about speakers? There aren&rsquo;t any. This isn&rsquo;t a surprise, despite the price: If anything, high-end monitors are less likely to include speakers than less expensive models. You&rsquo;ll have to use a headset or standalone desktop speakers.&nbsp;</p>



<h2 id="asus-rog-swift-oled-pg27aqdm-sdr-image-quality">Asus ROG Swift OLED PG27AQDM SDR image quality</h2>



<p>The Asus ROG Swift OLED PG27AQDM&rsquo;s OLED panel, which is provided by LG, has all the makings of an excellent SDR monitor. But it&rsquo;s up against stiff competition. QD-OLED widescreen monitors are available from multiple brands and Mini-LED monitors are going mainstream. Can Asus fend off the alternatives?&nbsp;</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Asus ROG Swift OLED PG27AQDM" class="wp-image-1785878" height="836" src="https://b2c-contenthub.com/wp-content/uploads/2023/04/asus-rog-swift-oled-brightness.png?w=1200" width="1200" /></figure><p class="imageCredit">Matt Smith</p></div>



<p>Our first test, brightness, is a predictable weak spot for the PG27AQDM. OLED monitors have trouble reaching and maintaining high levels of brightness. LED and Mini-LED monitors, by contrast, can blast brightness all day long with no issue.&nbsp;</p>



<p>With that said, however, the PG27AQDM&rsquo;s peak SDR brightness of 291 nits is perfectly usable in most situations. I typically used the monitor at less than half its maximum brightness in my office. The Asus also notches a win over the <a href="https://www.pcworld.com/article/1440675/alienware-aw3423dwf-review.html">Alienware AW3423DWF</a>, which has Samsung&rsquo;s QD-OLED panel.&nbsp;</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Asus ROG Swift OLED PG27AQDM" class="wp-image-1785879" height="827" src="https://b2c-contenthub.com/wp-content/uploads/2023/04/asus-rog-swift-oled-contrast.png?w=1200" width="1200" /></figure><p class="imageCredit">Matt Smith</p></div>



<p>Contrast, on the other hand, is a win for the PG27AQDM. The monitor can achieve perfect dark, which means it emits no zero in dark scenes. This hugely improves the monitor&rsquo;s ability to display dark scenes with convincing detail, eliminates the hazy &ldquo;IPS glow&rdquo; that plagues most computer monitors sold in the past 20 years, and provides an outstanding sense of depth and dimension in bright content. High-quality content takes on a rich, three-dimensional quality you won&rsquo;t find on most monitors.&nbsp;</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Asus ROG Swift OLED PG27AQDM" class="wp-image-1785880" height="833" src="https://b2c-contenthub.com/wp-content/uploads/2023/04/asus-rog-swift-oled-color-gamut.png?w=1200" width="1200" /></figure><p class="imageCredit">Matt Smith</p></div>



<p>Asus falls behind the pack in color gamut, providing only 90 percent of DCI-P3 and 87 percent of AdobeRGB. That&rsquo;s not a bad showing, but today&rsquo;s best monitors can deliver an incredible color gamut straight out of the box. Many exceed 100 percent of AdobeRGB and render almost the entire DCI-P3 gamut.&nbsp;</p>



<p>Whether this matters depends on your use. Gamers shouldn&rsquo;t be concerned, as the range of color offered here is more than enough to provide a lifelike and detailed image in modern titles. Creators, however, should be wary. The PG27AQDM will still work in most situations but won&rsquo;t be able to display as broad a range of color as its competitors. That could be an issue if you&rsquo;re trying to color grade video or edit a photograph.&nbsp;</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Asus ROG Swift OLED PG27AQDM" class="wp-image-1785881" height="875" src="https://b2c-contenthub.com/wp-content/uploads/2023/04/asus-rog-swift-oled-color-accuracy.png?w=1200" width="1200" /></figure><p class="imageCredit">Matt Smith</p></div>



<p>Asus&rsquo; color woes continue in color accuracy, where the PG27AQDM turned in a much wider color error than its peers. This level of color accuracy is enough to be noticeable in some situations. I felt that the monitor had issues with skin tones of individuals with lighter skin hues, which looked a bit dull or sickly. These problems are still minor enough that I doubt most users would notice them, but let&rsquo;s not forget: This is a $1,000 monitor. It&rsquo;s surprising to see Asus ship out a flagship OLED monitor with underwhelming color accuracy.</p>



<p>I noticed lackluster results in color temperature and gamma, as well. The monitor turned in an out-of-the-box color temperature of 7100K, which is a bit cooler and more clinical than the target of 6500K. The gamma curve was 2.0 off a target of 2.2, which means content appeared a bit brighter than it should. I noticed the color temperature issue most, as there was a distinct blue push in bright white objects and scenes, such as a snow-capped mountain.&nbsp;</p>



<p>Sharpness is disappointing despite the monitor&rsquo;s 2560&times;1440 resolution. The PG27AQDM, like most OLED monitors, uses a subpixel layout that differs from RGB. That causes sub-pixel presentation issues that appear as color fringing. When I type the number 1,000 in 12-point font in Microsoft Excel for example, I notice what appears to be a slight blue and yellow hue spanning the gap between the zeros. I think it&rsquo;s a tad less noticeable than with QD-OLED monitors, such as the Alienware AW3423DWF, but it&rsquo;s still an issue.</p>



<p>The PG27AQDM&rsquo;s SDR image quality results are mixed, so I&rsquo;d like to put my finger on the scale. Numbers aside, it&rsquo;s a beautiful monitor in real-world gameplay and also looks fine in general use. The monitor&rsquo;s outstanding contrast ratio is stunning in dark, gritty games like <em>Diablo 2: Resurrected</em>, but there&rsquo;s still enough brightness and a wide enough color gamut to provide a vivid look to titles such as <em>Valorant</em> or <em>Borderlands 3</em>.&nbsp;</p>



<h2 id="asus-rog-swift-oled-pg27aqdm-hdr-image-quality">Asus ROG Swift OLED PG27AQDM HDR image quality</h2>



<p>The Asus ROG Swift OLED PG27AQDM is capable of HDR, though, strangely, it doesn&rsquo;t boast a VESA DisplayHDR 400 True Black certification. Overall HDR performance is good but suffers the pitfalls typical of the current generation of OLED monitors.&nbsp;</p>



<p>I measured a maximum full-screen, sustained HDR brightness of just 186 nits. The reason this is lower than SDR is due to a difference in the test images used and the length of time displayed. I measured a maximum HDR brightness of up to 611 nits in a 10 percent window, meaning that only 10 percent of the display was lit (the rest was dark).&nbsp;</p>



		<div class="wp-block-product-widget-block product-widget is-half-width is-float-right">
			<div class="product-widget__block-title-wrapper">
				<h4 class="product-widget__block-title" id="mentioned-in-this-article">
					Mentioned in this article				</h4>
			</div>

			<div class="product-widget__content-wrapper">
									<div class="product-widget__title-wrapper">
						<h3 class="product-widget__title" id="aoc-agon-pro-ag274qzm">AOC Agon Pro AG274QZM</h3>
					</div>
				
									<div class="product-widget__image-outer-wrapper">
						<div class="product-widget__image-wrapper">
							<img alt="AOC Agon Pro AG274QZM" class="product-widget__image" height="1000" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/aoc-agon-pro-ag274qzm-5.jpg?quality=50&amp;strip=all" width="1500" />
						</div>
					</div>
				
									<div class="review product-widget__review-details">
													<div class="product-widget__rating-and-review-link">
								<div class="product-widget__review-details--rating">
											<div class="starRating"></div>
										</div>									<a class="product-widget__review-link" href="https://www.pcworld.com/article/1528866/aoc-agon-pro-ag274qzm-monitor-review.html" target="_blank">Read our review</a>
									
							</div>
											</div>
				
				<div class="product-widget__information">
												<div class="product-widget__information--rrp-wrapper">
									<span class="product-widget__information--rrp-label">
																	</span>
									<span class="product-widget__information--rrp-value">
																		</span>
								</div>
								
									</div>
			</div>
		</div>

		


<p>A brightness of 611 nits within a 10 percent window is a good result for an OLED monitor. I measured a maximum of 453 nits from the Alienware AW3423DWF and 509 nits from the Corsair Xeneon Flex. However, this remains far behind Mini-LED monitors such as the <a href="https://www.pcworld.com/article/1528866/aoc-agon-pro-ag274qzm-monitor-review.html">AOC Agon Pro AG274QZM</a>, which can reach and sustain nearly 1,000 nits. Mediocre brightness means you won&rsquo;t see the full range of luminance detail that&rsquo;s often available in HDR content. Bright lights, flames, or glare will appear a bit washed-out and uniform, though some additional detail is available compared to SDR.&nbsp;</p>



<p>This is balanced by the monitor&rsquo;s excellent contrast. The ability to deliver a perfect black level helps amplify the brightness that&rsquo;s on tap and increases the perceived vibrance and punch of the image. OLED also avoids the &ldquo;blooming&rdquo; problem found on Mini-LED monitors, which can appear as a halo surrounding small, bright details. OLED avoids this problem because each pixel is lit independently of those around it.&nbsp;</p>



<p>The PG27AQDM has issues in the Windows desktop environment. This is often true of HDR monitors, but particularly so here. Colors are noticeably off-kilter and luminance detail is lacking. Asus has a firmware update to improve color in HDR, and it did provide some improvement, but there&rsquo;s room for Asus to do better. At the moment, I recommend leaving HDR off in Windows&rsquo; settings and selectively turning it on within apps when possible.&nbsp;</p>



<p>Although the PG27AQDM&rsquo;s HDR performance isn&rsquo;t stellar, it provides an advantage over SDR and is a tad better than the QD-OLED monitors I&rsquo;ve tested, including the Alienware AW3423DWF and <a href="https://www.pcworld.com/article/1677744/corsair-xeneon-flex-monitor-review.html">Corsair Xeneon Flex</a>. Mini-LED monitors are superior for bright HDR content and better for HDR overall, and I recommend going Mini-LED if HDR is your priority. Still, the PG27AQDM holds its own in darker games and movies.&nbsp;</p>



<h2 id="asus-rog-swift-oled-pg27aqdm-motion-performance">Asus ROG Swift OLED PG27AQDM motion performance</h2>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Asus ROG Swift OLED PG27AQDM" class="wp-image-1785883" height="800" src="https://b2c-contenthub.com/wp-content/uploads/2023/04/asus-rog-swift-oled-pg27aqdm-2.jpg?quality=50&amp;strip=all&amp;w=1200" width="1200" /><figcaption><p>The Asus ROG Swift OLED PG27AQDM comes with a 240Hz refresh rate, which is buttery smooth on an OLED.</p> </figcaption></figure><p class="imageCredit">Matt Smith</p></div>



<p>The Asus ROG Swift OLED PG27AQDM is a 240Hz monitor (though only over DisplayPort) and offers support for Adaptive Sync, AMD FreeSync, and Nvidia G-Sync. It provides smooth, stutter-free motion in a wide range of situations and with most graphics hardware currently on the market. A handful of 360Hz and 500Hz monitors are now available, such as the <a href="https://www.pcworld.com/article/1478644/acer-predator-xb273u-f-monitor-review.html">Acer XB273U F</a> and <a href="https://www.pcworld.com/article/1665236/alienware-aw2524h-monitor-review.html">Alienware AW2524H</a>, and they feel a tad smoother in real-world use. Still, the PG27AQDM is a real treat to see in motion.</p>



		<div class="wp-block-product-widget-block product-widget is-half-width is-float-right">
			<div class="product-widget__block-title-wrapper">
				<h4 class="product-widget__block-title" id="lightning-fast-500hz-refresh-rate-monitor">
					lightning-fast 500Hz Refresh rate monitor				</h4>
			</div>

			<div class="product-widget__content-wrapper">
									<div class="product-widget__title-wrapper">
						<h3 class="product-widget__title" id="alienware-aw2524h">Alienware AW2524H</h3>
					</div>
				
									<div class="product-widget__image-outer-wrapper">
						<div class="product-widget__image-wrapper">
							<img alt="Alienware AW2524H" class="product-widget__image" height="1000" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/alienwareaw2524h-1.jpg?quality=50&amp;strip=all" width="1500" />
						</div>
					</div>
				
									<div class="review product-widget__review-details">
													<div class="product-widget__rating-and-review-link">
								<div class="product-widget__review-details--rating">
											<div class="starRating"></div>
										</div>									<a class="product-widget__review-link" href="https://www.pcworld.com/article/1665236/alienware-aw2524h-monitor-review.html" target="_blank">Read our review</a>
									
							</div>
											</div>
				
				<div class="product-widget__information">
												<div class="product-widget__information--rrp-wrapper">
									<span class="product-widget__information--rrp-label">
																	</span>
									<span class="product-widget__information--rrp-value">
																		</span>
								</div>
								
									</div>
			</div>
		</div>

		


<p>It helps that the PG27AQDM, like most OLED monitors, has an extremely fast pixel response time (Asus quotes .03 milliseconds). That means pixels can quickly transition between colors when needed, which reduces blur and provides excellent clarity. Fast-moving objects are well defined with nearly all details visible. Test images from <em>League of Legends</em> show that character silhouettes, names, and health bars are visible, though the individual tick marks within each health bar remain hard to make out. Motion clarity is better than QD-OLED monitors with a lower refresh rate, such as the Alienware AW3423DWF, and a tad better than a 240Hz IPS monitor, such as the Gigabyte M27Q-X.&nbsp;</p>



<p>Low pixel-response times also improve motion clarity across a wide range of refresh rates, so motion continues to look rather crisp down to, and a bit below, 120Hz. This versatility is important because you won&rsquo;t see the full benefits provided by a high refresh rate if the game you are playing can&rsquo;t achieve a similar frame rate, and even high-end gaming PCs will struggle to play many titles at up to 240 frames per second. Fortunately, the PG27AQDM remains enjoyable even when frame rates take a dive towards the double-digits.&nbsp;&nbsp;</p>



<h2 id="is-the-asus-rog-swift-oled-pg27aqdm-worth-it">Is the Asus ROG Swift OLED PG27AQDM worth it?</h2>



<p>The Asus ROG Swift OLED PG27AQDM is a mixed bag of features and performance. It delivers an incredible contrast ratio, thin design, and impressive 240Hz refresh rate, all of which make it a drop-dead gorgeous option for gamers. Unfortunately, the monitor&rsquo;s lackluster brightness, mediocre color performance, and so-so sharpness won&rsquo;t be ideal for those in creative professions who require precise color. Asus also fails to offer useful extras such as USB-C. These downsides limit the monitor&rsquo;s appeal&mdash;but if you just want to kick back, relax, and enjoy a top-tier gaming experience, the PG27AQDM is a wonderful choice.</p>

Monitors</div>

## Microsoft Office Pro can help you achieve both personal and professional goals, now only $39.99
 - [https://www.pcworld.com/article/1790416/microsoft-office-pro-can-help-you-achieve-both-personal-and-professional-goals-now-only-39-99.html](https://www.pcworld.com/article/1790416/microsoft-office-pro-can-help-you-achieve-both-personal-and-professional-goals-now-only-39-99.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-04-19 08:00:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>If any software could be considered a &ldquo;must-know&rdquo; for any professional, it&rsquo;s Microsoft Office. The&nbsp;<a href="https://shop.pcworld.com/sales/microsoft-office-pro-plus-2021-for-windows-lifetime-license-email-only?utm_source=pcworld.com&amp;utm_medium=referral&amp;utm_campaign=microsoft-office-pro-plus-2021-for-windows-lifetime-license-email-only&amp;utm_term=scsf-568445&amp;utm_content=a0x1P0000058bTcQAI&amp;scsonar=1" rel="noreferrer noopener" target="_blank">world&rsquo;s most ubiquitous office software</a>, MS Office is trusted in almost every industry for its ability to simplify functions and increase productivity, per E-Careers.</p>



<p>However, it&rsquo;s not the most affordable program on the market. That&rsquo;s why it&rsquo;s a great time to take advantage of this limited-time deal. You can now get a lifetime license to Microsoft Office Pro 2021 for Windows for only $39.99.</p>



<p>Made for&nbsp;<a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.pcmag.com/reviews/microsoft-surface-laptop-go-2&amp;xcust=2-3-1790416-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow" target="_blank">Windows 10</a>&nbsp;and later, this powerful suite includes classics like Word, Excel, PowerPoint, and Outlook, as well as Teams, OneNote, Publisher, and Access. It&rsquo;s a comprehensive offering to help you manage any business task, communication, data management, and more.</p>



<p>With MS Office&rsquo;s apps, you can&nbsp;<a href="https://shop.pcworld.com/sales/microsoft-office-pro-plus-2021-for-windows-lifetime-license-email-only?utm_source=pcworld.com&amp;utm_medium=referral&amp;utm_campaign=microsoft-office-pro-plus-2021-for-windows-lifetime-license-email-only&amp;utm_term=scsf-568445&amp;utm_content=a0x1P0000058bTcQAI&amp;scsonar=1" rel="noreferrer noopener" target="_blank">create powerful and sleek work presentations</a>, develop personal budgeting spreadsheets, communicate with colleagues via video calls, and so much more. No matter what your goals are, this suite can help you achieve them.</p>



<p>Ready to enjoy the innovative features of the world&rsquo;s most popular software?</p>



<p>Grab a lifetime license to&nbsp;<a href="https://shop.pcworld.com/sales/microsoft-office-pro-plus-2021-for-windows-lifetime-license-email-only?utm_source=pcworld.com&amp;utm_medium=referral&amp;utm_campaign=microsoft-office-pro-plus-2021-for-windows-lifetime-license-email-only&amp;utm_term=scsf-568445&amp;utm_content=a0x1P0000058bTcQAI&amp;scsonar=1" rel="noreferrer noopener" target="_blank">Microsoft Office Pro 2021 for Windows</a>&nbsp;now for just $39.99.</p>



<p><a href="https://shop.pcworld.com/sales/microsoft-office-pro-plus-2021-for-windows-lifetime-license-email-only?utm_source=pcworld.com&amp;utm_medium=referral-cta&amp;utm_campaign=microsoft-office-pro-plus-2021-for-windows-lifetime-license-email-only&amp;utm_term=scsf-568445&amp;utm_content=a0x1P0000058bTcQAI&amp;scsonar=1" rel="noreferrer noopener" target="_blank">&nbsp;</a></p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image"><img alt="" src="https://cdnp3.stackassets.com/254ce2996e3f9e89bd1448ed06f02f1bc3eb7a28/store/15a8fe47c3afefe2a4ad5aa05b7e1db145fd85e34a75109de77a632dd2bf/sale_xxxxx_primary_image.jpg" /></figure></div>



<p><strong>Microsoft Office Pro 2021 for Windows: Lifetime License &ndash; $39.99</strong></p>



<p><a href="https://shop.pcworld.com/sales/microsoft-office-pro-plus-2021-for-windows-lifetime-license-email-only?utm_source=pcworld.com&amp;utm_medium=referral-cta&amp;utm_campaign=microsoft-office-pro-plus-2021-for-windows-lifetime-license-email-only&amp;utm_term=scsf-568445&amp;utm_content=a0x1P0000058bTcQAI&amp;scsonar=1" rel="noreferrer noopener" target="_blank">See Deal</a></p>



<p><em>Prices subject to change.</em></p>

Computer Accessories</div>

