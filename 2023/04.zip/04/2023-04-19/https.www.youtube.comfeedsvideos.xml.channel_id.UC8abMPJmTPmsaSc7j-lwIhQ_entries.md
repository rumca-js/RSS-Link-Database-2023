# Source:Nineteenth century videos. Back to life., URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC8abMPJmTPmsaSc7j-lwIhQ, language:en-US

## [4K, 60 fps, color] (1942) U.S. daily life scenes in WWII. Nazi salutes in Gastonia, NC?
 - [https://www.youtube.com/watch?v=AzqiqLzHqMo](https://www.youtube.com/watch?v=AzqiqLzHqMo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC8abMPJmTPmsaSc7j-lwIhQ
 - date published: 2023-04-19 19:13:06+00:00

But, wait! Didn't we say U.S. daily life?  Why are those young ladies doing the nazi salute? Did Hitler invade North Carolina and we didn't notice?
No way. 
The girls are doing the Bellamy salute which is a palm-out salute  that was to accompany the American Pledge of Allegiance. Later, during the 1920s and 1930s, Italian fascists and Nazi Germans adopted a salute which was very similar, attributed to the Roman salute, a gesture that was popularly believed to have been used in ancient Rome.
This resulted in controversy over the use of the Bellamy salute in the United States. It was officially replaced by the hand-over-heart salute when Congress amended the Flag Code on December 22, 1942, so this must be one of the last films showing the Bellamy salute.

Join as a member to support this channel:
https://www.youtube.com/channel/UC8abMPJmTPmsaSc7j-lwIhQ/join

Music: Cypresses (Dvořák; quartet version).

