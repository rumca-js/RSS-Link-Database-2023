# Source:penguinz0, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg, language:en-US

## Goofiest Reddit Argument Ever
 - [https://www.youtube.com/watch?v=7pCaSDwKKGQ](https://www.youtube.com/watch?v=7pCaSDwKKGQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg
 - date published: 2023-04-19 18:00:03+00:00

This is the greatest marathon moment of All Time
Merch https://moistglobal.com/
I stream every day https://www.twitch.tv/moistcr1tikal

