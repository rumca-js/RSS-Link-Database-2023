# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## the nightmare begins.
 - [https://www.youtube.com/watch?v=lv-g-haiZXg](https://www.youtube.com/watch?v=lv-g-haiZXg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2023-04-19 17:00:34+00:00

Visit https://www.expressvpn.com/BRAND to get three extra months free.

As New York’s major reintroduces the Digidog despite it being previously retired for aggressive policing, is increased police militarisation about keeping us safe from the bad guys or preventing the population from revolting against the powerful? #robot #dog #police 

References
https://reclaimthenet.org/new-york-mayor-eric-adams-introduces-nypd-robots
https://caitlinjohnstone.com/2023/04/12/today-in-empire-copbots-msm-compliance-and-mccauls-embarrassing-taiwan-admission/
https://consortiumnews.com/2022/12/08/caitlin-johnstone-normalizing-police-robot-murder/
--------------------------------------------------------------------------------------------------------------------------
WATCH me LIVE weekdays on Rumble: https://bit.ly/russellbrand-rumble
Join Russell Brand Connected over on Locals: https://bit.ly/russellbrand-connected-community
Come COMMUNITY 2023 - https://www.russellbrand.com/community-2023/
NEW MERCH! https://stuff.russellbrand.com/
Keep up to date, Join my mailing list - https://www.russellbrand.com/join-the-community/

## FOX News To Pay WHAT?! The End Of Democracy?! - #111 - Stay Free With Russell Brand PREVIEW
 - [https://www.youtube.com/watch?v=DtwB7ScnFZ0](https://www.youtube.com/watch?v=DtwB7ScnFZ0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2023-04-19 13:21:51+00:00

Join us here for a PREVIEW of our daily one-hour RUMBLE show.
To continue watching the show in full, join me live and exclusively over on RUMBLE:
https://bit.ly/stayfree-111-fox-news

With guest Kat Timpf. 
Kat is a comedian, political commentator on Fox and the author of ‘You Can’t Joke About That - Why Everything Is Funny, Nothing Is Sacred, and We’re All in This Together’.
Insta: kattimpf 
Twitter: KatTimpf

--------------------------------------------------------------------------------------------------------------------------

FOLLOW and WATCH me LIVE weekdays on Rumble https://rumble.com/russellbrand
5:00PM BST | 12:00 PM EDT | 9:00AM PDT

Get My New Stand Up Special 'Brandemic' NOW https://rumble.com/v2d09w8-brandemic.html

Join The STAY FREE Community: https://russellbrand.locals.com/

Come to My Festival COMMUNITY - https://www.russellbrand.com/community-2023/

NEW MERCH! https://stuff.russellbrand.com/

