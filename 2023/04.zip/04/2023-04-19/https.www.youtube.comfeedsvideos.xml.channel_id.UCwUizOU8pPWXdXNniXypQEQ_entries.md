# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## If you ain’t prepping, you’re prepping to die!
 - [https://www.youtube.com/watch?v=3XWVPy-gkBk](https://www.youtube.com/watch?v=3XWVPy-gkBk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2023-04-19 14:47:08+00:00

#shorts

