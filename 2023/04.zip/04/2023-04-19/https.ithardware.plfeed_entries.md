# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## Netflix ze wzrostem abonentów i przychodów. Firma prezentuje wyniki za pierwszy kwartał
 - [https://ithardware.pl/aktualnosci/netflix_ze_wzrostem_abonentow_i_przychodow_firma_prezentuje_wyniki_za_pierwszy_kwartal-26885.html](https://ithardware.pl/aktualnosci/netflix_ze_wzrostem_abonentow_i_przychodow_firma_prezentuje_wyniki_za_pierwszy_kwartal-26885.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-19 17:41:22+00:00

<img src="https://ithardware.pl/artykuly/min/26885_1.jpg" />            Netflix opublikował swoje najnowsze wyniki finansowe za pierwszy kwartał 2023 roku. Popularna platforma streamingowa w minionych trzech miesiącach zanotowała wzrost liczby abonent&oacute;w, nie może także narzekać na wygenerowane...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/netflix_ze_wzrostem_abonentow_i_przychodow_firma_prezentuje_wyniki_za_pierwszy_kwartal-26885.html">https://ithardware.pl/aktualnosci/netflix_ze_wzrostem_abonentow_i_przychodow_firma_prezentuje_wyniki_za_pierwszy_kwartal-26885.html</a></p>

## Największa kradzież kart Pokemon w historii? Złodziej wpadł, bo próbował sprzedać kolekcję
 - [https://ithardware.pl/aktualnosci/najwieksza_kradziez_kart_pokemon_w_historii_zlodziej_wpadl_bo_probowal_sprzedac_kolekcje-26884.html](https://ithardware.pl/aktualnosci/najwieksza_kradziez_kart_pokemon_w_historii_zlodziej_wpadl_bo_probowal_sprzedac_kolekcje-26884.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-19 16:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/26884_1.jpg" />            Pokemon to jedna z największych i najbardziej dochodowych marek rozrywkowych na świecie, wliczając do tego karciankę&nbsp;Pokemon Trading Card Game. Warto wspomnieć o pewnej karcie przedstawiającej Pikachu rozdawanej w konkursie w 1997 roku w...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/najwieksza_kradziez_kart_pokemon_w_historii_zlodziej_wpadl_bo_probowal_sprzedac_kolekcje-26884.html">https://ithardware.pl/aktualnosci/najwieksza_kradziez_kart_pokemon_w_historii_zlodziej_wpadl_bo_probowal_sprzedac_kolekcje-26884.html</a></p>

## Wykorzystał wentylator z RTX 4090 Founders Edition do chłodzenia CPU. Różnice są naprawdę duże
 - [https://ithardware.pl/aktualnosci/wykorzystal_wentylator_z_rtx_4090_founders_edition_do_chlodzenia_cpu_roznice_sa_naprawde_duze-26883.html](https://ithardware.pl/aktualnosci/wykorzystal_wentylator_z_rtx_4090_founders_edition_do_chlodzenia_cpu_roznice_sa_naprawde_duze-26883.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-19 15:53:10+00:00

<img src="https://ithardware.pl/artykuly/min/26883_1.jpg" />            Wygląda na to, że członkom forum Chiphell spodobały się możliwości oferowane przez wentylatory montowane w kartach GeForce RTX 4090 Founders Edition. Jeden z nich postanowił zamontować taki wentylator na radiatorze odprowadzającym ciepło z...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/wykorzystal_wentylator_z_rtx_4090_founders_edition_do_chlodzenia_cpu_roznice_sa_naprawde_duze-26883.html">https://ithardware.pl/aktualnosci/wykorzystal_wentylator_z_rtx_4090_founders_edition_do_chlodzenia_cpu_roznice_sa_naprawde_duze-26883.html</a></p>

## Multiplayer Call of Duty: Modern Warfare 2 za darmo przez tydzień
 - [https://ithardware.pl/aktualnosci/multiplayer_call_of_duty_modern_warfare_2_za_darmo_przez_tydzien-26882.html](https://ithardware.pl/aktualnosci/multiplayer_call_of_duty_modern_warfare_2_za_darmo_przez_tydzien-26882.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-19 14:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/26882_1.jpg" />            Activision Blizzard przygotował&nbsp;darmowy tydzień z grą Call of Duty: Modern Warfare 2, kt&oacute;ry startuje już dziś. Bezpłatny będzie tryb wieloosobowy, w ramach kt&oacute;rego odblokowane zostaną wybrane mapy oraz warianty...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/multiplayer_call_of_duty_modern_warfare_2_za_darmo_przez_tydzien-26882.html">https://ithardware.pl/aktualnosci/multiplayer_call_of_duty_modern_warfare_2_za_darmo_przez_tydzien-26882.html</a></p>

## Test iiyama G-Master GB2770HSU-B5 Red Eagle. Nowa wersja popularnego monitora IPS Full HD 165 Hz
 - [https://ithardware.pl/testyirecenzje/test_iiyama_g_master_gb2770hsu_b5_red_eagle_nowa_wersja_popularnego_monitora_ips_full_hd_165_hz-26879.html](https://ithardware.pl/testyirecenzje/test_iiyama_g_master_gb2770hsu_b5_red_eagle_nowa_wersja_popularnego_monitora_ips_full_hd_165_hz-26879.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-19 13:58:10+00:00

<img src="https://ithardware.pl/artykuly/min/26879_1.jpg" />            Test iiyama G-Master GB2770HSU-B5 Red Eagle. Nowa wersja popularnego monitora IPS Full HD 165 Hz

Dwa i p&oacute;ł roku temu mieliśmy okazję przetestować monitor G-Master GB2770HSU-B1 Red Eagle od iiyamy, kt&oacute;ry okazał się świetną...
            <p>Pełna wersja strony <a href="https://ithardware.pl/testyirecenzje/test_iiyama_g_master_gb2770hsu_b5_red_eagle_nowa_wersja_popularnego_monitora_ips_full_hd_165_hz-26879.html">https://ithardware.pl/testyirecenzje/test_iiyama_g_master_gb2770hsu_b5_red_eagle_nowa_wersja_popularnego_monitora_ips_full_hd_165_hz-26879.html</a></p>

## Wykorzystali AI do sfingowania porwania. Sklonowali głos nastolatki i zadzwonili do rodziców
 - [https://ithardware.pl/aktualnosci/wykorzystali_ai_do_sfingowania_porwania_sklonowali_glos_nastolatki_i_zadzwonili_do_rodzicow-26881.html](https://ithardware.pl/aktualnosci/wykorzystali_ai_do_sfingowania_porwania_sklonowali_glos_nastolatki_i_zadzwonili_do_rodzicow-26881.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-19 12:24:30+00:00

<img src="https://ithardware.pl/artykuly/min/26881_1.jpg" />            Kobieta z Arizony prawie padłą ofiarą oszust&oacute;w, kt&oacute;rzy wykorzystali algorytmy sztucznej inteligencji do sfingowania porwania jej c&oacute;rki.

Jennifer DeStefano odebrała połączenie z nieznanego numeru i usłyszała płacz swojej...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/wykorzystali_ai_do_sfingowania_porwania_sklonowali_glos_nastolatki_i_zadzwonili_do_rodzicow-26881.html">https://ithardware.pl/aktualnosci/wykorzystali_ai_do_sfingowania_porwania_sklonowali_glos_nastolatki_i_zadzwonili_do_rodzicow-26881.html</a></p>

## Firmament przetestuje wasze PC. Gra wymaga nawet 32 GB pamięci RAM
 - [https://ithardware.pl/aktualnosci/firmament_przetestuje_wasze_pc_gra_wymaga_nawet_32_gb_pamieci_ram-26872.html](https://ithardware.pl/aktualnosci/firmament_przetestuje_wasze_pc_gra_wymaga_nawet_32_gb_pamieci_ram-26872.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-19 12:12:01+00:00

<img src="https://ithardware.pl/artykuly/min/26872_1.jpg" />            Cyan, czyli studio odpowiedzialne za takie tytuły jak Myst and Riven, pracuje nad nową steampunkową grę logiczną z perspektywy pierwszej osoby o nazwie Firmament, kt&oacute;ra najwyraźniej przetestuje gamingowe pecety. Produkcja ma niezwykle...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/firmament_przetestuje_wasze_pc_gra_wymaga_nawet_32_gb_pamieci_ram-26872.html">https://ithardware.pl/aktualnosci/firmament_przetestuje_wasze_pc_gra_wymaga_nawet_32_gb_pamieci_ram-26872.html</a></p>

## To miała być przystań "wolnościowców". Platforma Parler zamknięta
 - [https://ithardware.pl/aktualnosci/to_miala_byc_przystan_wolnosciowcow_platforma_parler_zamknieta-26880.html](https://ithardware.pl/aktualnosci/to_miala_byc_przystan_wolnosciowcow_platforma_parler_zamknieta-26880.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-19 11:44:00+00:00

<img src="https://ithardware.pl/artykuly/min/26880_1.jpg" />            Nastawiona na swobodną mowę platforma Parler została zamknięta przez nowego właściciela Starboard Media.&nbsp;To prawdopodobnie koniec aplikacji, kt&oacute;ra miała&nbsp;być klonem Twittera dla konserwatyst&oacute;w.

Parler miało być...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/to_miala_byc_przystan_wolnosciowcow_platforma_parler_zamknieta-26880.html">https://ithardware.pl/aktualnosci/to_miala_byc_przystan_wolnosciowcow_platforma_parler_zamknieta-26880.html</a></p>

## Unia Europejska przyjęła Chips Act. Ogromne pieniądze na lokalną produkcję chipów
 - [https://ithardware.pl/aktualnosci/unia_europejska_przyjela_chips_act_ogromne_pieniadze_na_lokalna_produkcje_chipow-26871.html](https://ithardware.pl/aktualnosci/unia_europejska_przyjela_chips_act_ogromne_pieniadze_na_lokalna_produkcje_chipow-26871.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-19 11:06:01+00:00

<img src="https://ithardware.pl/artykuly/min/26871_1.jpg" />            Unia Europejska zgodziła się na plan zainwestowania 43 miliard&oacute;w euro w sektor p&oacute;łprzewodnik&oacute;w w celu znacznego zwiększenia lokalnej produkcji chip&oacute;w i wprowadzenia zaawansowanych proces&oacute;w produkcyjnych do...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/unia_europejska_przyjela_chips_act_ogromne_pieniadze_na_lokalna_produkcje_chipow-26871.html">https://ithardware.pl/aktualnosci/unia_europejska_przyjela_chips_act_ogromne_pieniadze_na_lokalna_produkcje_chipow-26871.html</a></p>

## Podkręcony Intel Xeon Sapphire Rapids potrzebuje blisko 1000 W energii elektrycznej
 - [https://ithardware.pl/aktualnosci/podkrecony_intel_xeon_sapphire_rapids_potrzebuje_blisko_1000_w_energii_elektrycznej-26877.html](https://ithardware.pl/aktualnosci/podkrecony_intel_xeon_sapphire_rapids_potrzebuje_blisko_1000_w_energii_elektrycznej-26877.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-19 10:49:30+00:00

<img src="https://ithardware.pl/artykuly/min/26877_1.jpg" />            Procesory Intel z wieloma rdzeniami mogą generować ogromne zużycie energii. Przykładowo, 56-rdzeniowy procesor Xeon w9-3495X ma wartość PBP (moc pobierana przez procesor w trybie podstawowym) wynoszącą 350 W, a wartość MTP (moc maksymalna...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/podkrecony_intel_xeon_sapphire_rapids_potrzebuje_blisko_1000_w_energii_elektrycznej-26877.html">https://ithardware.pl/aktualnosci/podkrecony_intel_xeon_sapphire_rapids_potrzebuje_blisko_1000_w_energii_elektrycznej-26877.html</a></p>

## Twitter nie chroni już osób transpłciowych. Platforma po cichu zmienia regulamin
 - [https://ithardware.pl/aktualnosci/twitter_nie_chroni_juz_osob_transplciowych_platforma_po_cichu_zmienia_regulamin-26870.html](https://ithardware.pl/aktualnosci/twitter_nie_chroni_juz_osob_transplciowych_platforma_po_cichu_zmienia_regulamin-26870.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-19 10:42:01+00:00

<img src="https://ithardware.pl/artykuly/min/26870_1.jpg" />            Twitter po raz kolejny po cichu zaktualizował swoją politykę w istotnej sprawie, bez podawania wyjaśnienia, co zostało dostrzeżone przez GLAAD (największa na świecie organizacja wspierająca LGBTQ+) i szybko wywołało reakcję środowisk...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/twitter_nie_chroni_juz_osob_transplciowych_platforma_po_cichu_zmienia_regulamin-26870.html">https://ithardware.pl/aktualnosci/twitter_nie_chroni_juz_osob_transplciowych_platforma_po_cichu_zmienia_regulamin-26870.html</a></p>

## To musiało kiedyś się stać. Netflix rezygnuje z wypożyczania płyt DVD
 - [https://ithardware.pl/aktualnosci/to_musialo_kiedys_sie_stac_netflix_rezygnuje_z_wypozyczania_plyt_dvd-26876.html](https://ithardware.pl/aktualnosci/to_musialo_kiedys_sie_stac_netflix_rezygnuje_z_wypozyczania_plyt_dvd-26876.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-19 10:23:00+00:00

<img src="https://ithardware.pl/artykuly/min/26876_1.jpg" />            Po 25 latach&nbsp;Netflix postanowił zakończyć działalność, od kt&oacute;rej zaczynał swoją drogę z udostępnianiem film&oacute;w. Jak czytamy w oficjalnym komunikacie, firma planuje wysłać ostatnie płyty pod koniec września. To z...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/to_musialo_kiedys_sie_stac_netflix_rezygnuje_z_wypozyczania_plyt_dvd-26876.html">https://ithardware.pl/aktualnosci/to_musialo_kiedys_sie_stac_netflix_rezygnuje_z_wypozyczania_plyt_dvd-26876.html</a></p>

## GeForce RTX 4070 może szybko potanieć. NVIDIA proponuje partnerom rabaty
 - [https://ithardware.pl/aktualnosci/geforce_rtx_4070_moze_szybko_potaniec_nvidia_proponuje_partnerom_rabaty-26869.html](https://ithardware.pl/aktualnosci/geforce_rtx_4070_moze_szybko_potaniec_nvidia_proponuje_partnerom_rabaty-26869.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-19 09:29:01+00:00

<img src="https://ithardware.pl/artykuly/min/26869_1.jpg" />            Igor's Lab postanowił om&oacute;wić premierę karty GeForce RTX 4070 z przedstawicielami branży. Z informacji jakie uzyskał wynika, że sprzedaż na starcie jest tak słaba, że NVIDIA przedstawiła partnerom pomysł 50-dolarowej obniżki...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/geforce_rtx_4070_moze_szybko_potaniec_nvidia_proponuje_partnerom_rabaty-26869.html">https://ithardware.pl/aktualnosci/geforce_rtx_4070_moze_szybko_potaniec_nvidia_proponuje_partnerom_rabaty-26869.html</a></p>

## MediaTek szykuje rywala dla Snapdragona 8 gen 3. Tak może wyglądać jego specyfikacja
 - [https://ithardware.pl/aktualnosci/mediatek_szykuje_rywala_dla_snapdragona_8_gen_3_tak_moze_wygladac_jego_specyfikacja-26874.html](https://ithardware.pl/aktualnosci/mediatek_szykuje_rywala_dla_snapdragona_8_gen_3_tak_moze_wygladac_jego_specyfikacja-26874.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-19 09:24:00+00:00

<img src="https://ithardware.pl/artykuly/min/26874_1.jpg" />            MediaTek będzie rywalizował z Qualcommem w segmencie najwydajniejszych chip&oacute;w dla urządzeń mobilnych. Według najnowszych informacji, firma przygotowuje następcę układu Dimensity 9200, kt&oacute;ry ma rywalizować z nadchodzącym...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/mediatek_szykuje_rywala_dla_snapdragona_8_gen_3_tak_moze_wygladac_jego_specyfikacja-26874.html">https://ithardware.pl/aktualnosci/mediatek_szykuje_rywala_dla_snapdragona_8_gen_3_tak_moze_wygladac_jego_specyfikacja-26874.html</a></p>

## Najdroższa skórka CS:GO z 4 hologramami Titan z Katowic 2014 sprzedana. Ta cena to szaleństwo
 - [https://ithardware.pl/aktualnosci/najdrozsza_skorka_cs_go_z_4_hologramami_titan_z_katowic_2014_sprzedana_ta_cena_to_szalenstwo-26875.html](https://ithardware.pl/aktualnosci/najdrozsza_skorka_cs_go_z_4_hologramami_titan_z_katowic_2014_sprzedana_ta_cena_to_szalenstwo-26875.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-19 08:44:50+00:00

<img src="https://ithardware.pl/artykuly/min/26875_1.jpg" />            Sk&oacute;rka broni AK-47 Case Hardened z czterema hologramami Titan z Katowic 2014 została sprzedana za kwotę prawie p&oacute;ł miliona dolar&oacute;w, co czyni ją jedną z najdroższych sk&oacute;rek w grze Counter-Strike: Global...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/najdrozsza_skorka_cs_go_z_4_hologramami_titan_z_katowic_2014_sprzedana_ta_cena_to_szalenstwo-26875.html">https://ithardware.pl/aktualnosci/najdrozsza_skorka_cs_go_z_4_hologramami_titan_z_katowic_2014_sprzedana_ta_cena_to_szalenstwo-26875.html</a></p>

## Poznaj zwycięzców plebiscytu ITHardware For Gamers 2023!
 - [https://ithardware.pl/aktualnosci/poznaj_zwyciezcow_plebiscytu_ithardware_for_gamers_2023-26858.html](https://ithardware.pl/aktualnosci/poznaj_zwyciezcow_plebiscytu_ithardware_for_gamers_2023-26858.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-19 08:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/26858_1.jpg" />            No i stało się. Dokładnie miesiąc temu wystartował nasz kolejny plebiscyt For Gamers, kt&oacute;ry został przez nas przygotowany po dłuższej przerwie. Dziś wiemy, jakie produkty i marki zwyciężyły w swoich kategoriach i jak kształtowały...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/poznaj_zwyciezcow_plebiscytu_ithardware_for_gamers_2023-26858.html">https://ithardware.pl/aktualnosci/poznaj_zwyciezcow_plebiscytu_ithardware_for_gamers_2023-26858.html</a></p>

## AMD EPYC 9V84 - serwerowe CPU Zen 4 z imponującym wynikiem w benchmarku
 - [https://ithardware.pl/aktualnosci/amd_epyc_9v84_serwerowe_cpu_zen_4_z_imponujacym_wynikiem_w_benchmarku-26867.html](https://ithardware.pl/aktualnosci/amd_epyc_9v84_serwerowe_cpu_zen_4_z_imponujacym_wynikiem_w_benchmarku-26867.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-19 08:09:01+00:00

<img src="https://ithardware.pl/artykuly/min/26867_1.jpg" />            W tym tygodniu procesor AMD EPYC 9684X z rodziny Genoa-X został zauważony na chińskiej platformie sprzedażowej Goofish, gdzie często pojawia się niewydany sprzęt od AMD i Intela. Pr&oacute;bki inżynieryjne sprzedawane na tej platformie nie są...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/amd_epyc_9v84_serwerowe_cpu_zen_4_z_imponujacym_wynikiem_w_benchmarku-26867.html">https://ithardware.pl/aktualnosci/amd_epyc_9v84_serwerowe_cpu_zen_4_z_imponujacym_wynikiem_w_benchmarku-26867.html</a></p>

## Netflix zapowiada blokowanie bezpłatnego dzielenia się kontem na największym rynku. Co z Polską?
 - [https://ithardware.pl/aktualnosci/netflix_zapowiada_blokowanie_bezplatnego_dzielenia_sie_kontem_na_najwiekszym_rynku_co_z_polska-26873.html](https://ithardware.pl/aktualnosci/netflix_zapowiada_blokowanie_bezplatnego_dzielenia_sie_kontem_na_najwiekszym_rynku_co_z_polska-26873.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-19 07:42:00+00:00

<img src="https://ithardware.pl/artykuly/min/26873_1.jpg" />            Netflix bierze się za blokowanie udostępniania kont na swoim największym rynku, czyli w Stanach Zjednoczonych. &bdquo;W pierwszym kwartale uruchomiliśmy płatne udostępnianie w czterech krajach i jesteśmy zadowoleni z wynik&oacute;w&rdquo; &ndash;...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/netflix_zapowiada_blokowanie_bezplatnego_dzielenia_sie_kontem_na_najwiekszym_rynku_co_z_polska-26873.html">https://ithardware.pl/aktualnosci/netflix_zapowiada_blokowanie_bezplatnego_dzielenia_sie_kontem_na_najwiekszym_rynku_co_z_polska-26873.html</a></p>

## Zerkajcie w górę! Satelita NASA rozbije się dziś o Ziemię. Nie wiadomo tylko... gdzie
 - [https://ithardware.pl/aktualnosci/zerkajcie_w_gore_satelita_nasa_rozbije_sie_dzis_o_ziemie_nie_wiadomo_tylko_gdzie-26868.html](https://ithardware.pl/aktualnosci/zerkajcie_w_gore_satelita_nasa_rozbije_sie_dzis_o_ziemie_nie_wiadomo_tylko_gdzie-26868.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-19 07:15:50+00:00

<img src="https://ithardware.pl/artykuly/min/26868_1.jpg" />            W ciągu najbliższych godzin na niebie może pojawić się jasna &quot;spadająca gwiazda&quot;. To emerytowany satelita, kt&oacute;ry kończy swoją kosmiczną podr&oacute;ż.

Satelita NASA, kt&oacute;ry był wykorzystywany do badań Słońca -...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/zerkajcie_w_gore_satelita_nasa_rozbije_sie_dzis_o_ziemie_nie_wiadomo_tylko_gdzie-26868.html">https://ithardware.pl/aktualnosci/zerkajcie_w_gore_satelita_nasa_rozbije_sie_dzis_o_ziemie_nie_wiadomo_tylko_gdzie-26868.html</a></p>

## Wyciekł GeForce RTX 3060 z pełnym układem GA106
 - [https://ithardware.pl/aktualnosci/wyciekl_geforce_rtx_3060_z_pelnym_ukladem_ga106-26866.html](https://ithardware.pl/aktualnosci/wyciekl_geforce_rtx_3060_z_pelnym_ukladem_ga106-26866.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-19 07:05:04+00:00

<img src="https://ithardware.pl/artykuly/min/26866_1.jpg" />            Wszystko wskazuje na to, że NVIDIA miała w planach jeszcze jeden wariant stacjonarnej karty graficznej GeForce RTX 3060, ale ten nigdy nie ujrzał światła dziennego. Właśnie odkryto jego BIOS, kt&oacute;ry ujawnia, że ta wersja miała otrzymać w...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/wyciekl_geforce_rtx_3060_z_pelnym_ukladem_ga106-26866.html">https://ithardware.pl/aktualnosci/wyciekl_geforce_rtx_3060_z_pelnym_ukladem_ga106-26866.html</a></p>

## Memory Week z rabatami do 48% i sprzęt do gamingu taniej nawet o 3100 zł w promocjach x-komu
 - [https://ithardware.pl/aktualnosci/memory_week_z_rabatami_do_48_i_sprzet_do_gamingu_taniej_nawet_o_3100_zl_w_promocjach_x_komu-26865.html](https://ithardware.pl/aktualnosci/memory_week_z_rabatami_do_48_i_sprzet_do_gamingu_taniej_nawet_o_3100_zl_w_promocjach_x_komu-26865.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-19 06:00:02+00:00

<img src="https://ithardware.pl/artykuly/min/26865_1.jpg" />            Zapewnij sobie szybki dostęp do swoich wspomnień dzięki dyskom, pendrive-om i pamięciom RAM, kt&oacute;re teraz kupisz w x-komie nawet do 45% taniej. Opr&oacute;cz tego właśnie ruszyła promocja gamingowa, w kt&oacute;rej sprzęty można kupić...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/memory_week_z_rabatami_do_48_i_sprzet_do_gamingu_taniej_nawet_o_3100_zl_w_promocjach_x_komu-26865.html">https://ithardware.pl/aktualnosci/memory_week_z_rabatami_do_48_i_sprzet_do_gamingu_taniej_nawet_o_3100_zl_w_promocjach_x_komu-26865.html</a></p>

