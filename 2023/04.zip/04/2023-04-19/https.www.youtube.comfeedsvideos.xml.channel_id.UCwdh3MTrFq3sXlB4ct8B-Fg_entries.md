# Source:Warhammer, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg, language:en-US

## 40 Years of Warhammer – Orc Shaman
 - [https://www.youtube.com/watch?v=MSAHLE3UrUE](https://www.youtube.com/watch?v=MSAHLE3UrUE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg
 - date published: 2023-04-19 15:00:16+00:00

Join us as we cast some Orcy magic to head back into the dim-and-distant past and cast a nostalgic eye on the Orc Shaman. https://bit.ly/3A9Kb15

