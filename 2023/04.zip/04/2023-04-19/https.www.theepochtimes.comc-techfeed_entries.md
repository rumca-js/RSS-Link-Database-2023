# Source:Epoch Times Tech, URL:https://www.theepochtimes.com/c-tech/feed/, language:en-US

## Ban on TikTok Faces Hurdle as Top Officials Still on Platform: Cybersecurity Expert
 - [https://www.theepochtimes.com/ban-on-tiktok-faces-hurdle-as-top-officials-still-on-platform-cybersecurity-expert_5206553.html](https://www.theepochtimes.com/ban-on-tiktok-faces-hurdle-as-top-officials-still-on-platform-cybersecurity-expert_5206553.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2023-04-19 22:54:57+00:00

TikTok CEO Shou Zi Chew testifies before the House Energy and Commerce Committee in the Rayburn House Office Building on Capitol Hill in Washington on March 23, 2023. (Chip Somodevilla/Getty Images)

## AI Will Eventually Be ‘As Good a Tutor as Any Human’: Bill Gates
 - [https://www.theepochtimes.com/ai-will-eventually-be-as-good-a-tutor-as-any-human-bill-gates_5207460.html](https://www.theepochtimes.com/ai-will-eventually-be-as-good-a-tutor-as-any-human-bill-gates_5207460.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2023-04-19 22:00:28+00:00

Bill Gates speaks onstage at the TIME100 Summit 2022 in New York City on June 7, 2022. (Jemal Countess/Getty Images for TIME)

## American Facebook Users Can Now Apply for Their Share of a $725 Million Facebook Settlement: Here’s How
 - [https://www.theepochtimes.com/american-facebook-users-can-now-apply-for-their-share-of-a-725-million-facebook-ettlement-heres-how_5206433.html](https://www.theepochtimes.com/american-facebook-users-can-now-apply-for-their-share-of-a-725-million-facebook-ettlement-heres-how_5206433.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2023-04-19 17:27:30+00:00

A woman uses her mobile phone to check Facebook. (STR/AFP via Getty Images)

