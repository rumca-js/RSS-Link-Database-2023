# Source:Glink, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNTqu16j3F6RbtHZI-3untg, language:en-US

## Bike day in Kyoto Japan
 - [https://www.youtube.com/watch?v=xk4wYZjC6lE](https://www.youtube.com/watch?v=xk4wYZjC6lE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNTqu16j3F6RbtHZI-3untg
 - date published: 2023-04-19 17:04:22+00:00



