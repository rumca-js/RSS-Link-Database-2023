# Source:Le Monde - science, URL:https://www.lemonde.fr/en/science/rss_full.xml, language:en-US

## After childbirth, women's brains are not quite the same
 - [https://www.lemonde.fr/en/opinion/article/2023/04/19/after-childbirth-women-s-brains-are-not-quite-the-same_6023524_23.html](https://www.lemonde.fr/en/opinion/article/2023/04/19/after-childbirth-women-s-brains-are-not-quite-the-same_6023524_23.html)
 - RSS feed: https://www.lemonde.fr/en/science/rss_full.xml
 - date published: 2023-04-19 18:00:08+00:00

New research shows women's brains change in the days following childbirth and these changes are permanent.

