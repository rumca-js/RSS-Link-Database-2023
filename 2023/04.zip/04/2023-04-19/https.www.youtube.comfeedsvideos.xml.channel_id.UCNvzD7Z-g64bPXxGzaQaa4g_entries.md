# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Horizon: Burning Shores DLC - Before You Buy
 - [https://www.youtube.com/watch?v=YmLikINs2BQ](https://www.youtube.com/watch?v=YmLikINs2BQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2023-04-19 21:40:04+00:00

Horizon: Forbidden West's expansion DLC Burning Shores (PS5) is here! How is it? Let's talk.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

