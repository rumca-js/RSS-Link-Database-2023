# Source:Sky News, URL:http://feeds.skynews.com/feeds/rss/world.xml, language:en-US

## Trump breaks silence on Instagram to promote his NFTs - but critics say the art is 'cringey'
 - [https://news.sky.com/story/donald-trump-breaks-silence-on-instagram-to-promote-his-nfts-but-critics-say-the-art-is-cringey-12861384](https://news.sky.com/story/donald-trump-breaks-silence-on-instagram-to-promote-his-nfts-but-critics-say-the-art-is-cringey-12861384)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-04-19 20:40:00+00:00

Donald Trump has released a second collection of non-fungible tokens (NFTs) as the 2024 presidential race heats up.

## K-pop star Moonbin dies aged 25
 - [https://news.sky.com/story/moonbin-member-of-k-pop-band-astro-dies-aged-25-12861339](https://news.sky.com/story/moonbin-member-of-k-pop-band-astro-dies-aged-25-12861339)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-04-19 20:20:00+00:00

Moonbin, a member of the K-pop band Astro, has died aged 25, according to a statement from the group's label.

## 84-year-old white man pleads not guilty over shooting of black teen who knocked on wrong door
 - [https://news.sky.com/story/ralph-yarl-84-year-old-white-man-andrew-lester-pleads-not-guilty-to-shooting-black-teen-who-knocked-on-wrong-door-12861323](https://news.sky.com/story/ralph-yarl-84-year-old-white-man-andrew-lester-pleads-not-guilty-to-shooting-black-teen-who-knocked-on-wrong-door-12861323)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-04-19 19:44:00+00:00

An 84-year-old white man accused of shooting a black teenager has pleaded not guilty in a US court.

## Missing rugby player feared to have drowned
 - [https://news.sky.com/story/levi-davis-rugby-player-who-went-missing-in-barcelona-last-year-is-feared-to-have-drowned-12861239](https://news.sky.com/story/levi-davis-rugby-player-who-went-missing-in-barcelona-last-year-is-feared-to-have-drowned-12861239)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-04-19 18:02:00+00:00

A British rugby player who went missing in Barcelona last year is feared to have drowned.

## Russian ship 'spying' around wind farms off UK coast in possible sabotage plot
 - [https://news.sky.com/story/russian-ship-spying-around-wind-farms-off-uk-coast-in-possible-sabotage-plot-12861217](https://news.sky.com/story/russian-ship-spying-around-wind-farms-off-uk-coast-in-possible-sabotage-plot-12861217)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-04-19 17:27:00+00:00

A Russian "spy" ship stopped at sites around wind farms off the Scottish coast in order to gather intelligence, an investigation has claimed.

## Cat killing competition for children cancelled after backlash
 - [https://news.sky.com/story/cat-killing-competition-for-children-cancelled-in-new-zealand-after-backlash-12861107](https://news.sky.com/story/cat-killing-competition-for-children-cancelled-in-new-zealand-after-backlash-12861107)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-04-19 15:19:00+00:00

A competition encouraging children to kill as many cats as possible has been cancelled following a backlash.

## TikTok to crack down on climate change denial
 - [https://news.sky.com/story/tiktok-to-remove-climate-change-denial-videos-and-direct-users-to-authoritative-information-12860971](https://news.sky.com/story/tiktok-to-remove-climate-change-denial-videos-and-direct-users-to-authoritative-information-12860971)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-04-19 12:46:00+00:00

TikTok is to start removing videos that deny the existence of climate change.

## Alleged former Wagner commanders admit killing children in Ukraine
 - [https://news.sky.com/story/alleged-former-wagner-commanders-admit-killing-children-in-ukraine-12860939](https://news.sky.com/story/alleged-former-wagner-commanders-admit-killing-children-in-ukraine-12860939)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-04-19 12:03:00+00:00

Two men, who claim to be former commanders in the Russian paramilitary mercenary group Wagner, have told an exiled human rights group they killed children and civilians in eastern Ukraine.

## Baby blue-coloured spiral resembling a galaxy appears amid Northern Lights
 - [https://news.sky.com/story/rare-baby-blue-spiral-in-alaska-skies-leaves-northern-lights-enthusiasts-bewildered-12860898](https://news.sky.com/story/rare-baby-blue-spiral-in-alaska-skies-leaves-northern-lights-enthusiasts-bewildered-12860898)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-04-19 11:30:00+00:00

Northern Lights enthusiasts were left "bewildered" after a baby blue-coloured spiral resembling a galaxy appeared amid the aroura in the skies of Alaska.

## India to surpass China as the most populated country in world
 - [https://news.sky.com/story/india-to-surpass-china-as-the-most-populated-country-in-world-un-figures-show-12860794](https://news.sky.com/story/india-to-surpass-china-as-the-most-populated-country-in-world-un-figures-show-12860794)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-04-19 09:09:00+00:00

India is on track to surpass China as the most populated country in the world, according to United Nations data.

## Eight fishermen feared dead, as others survive without food or water, after tropical cyclone
 - [https://news.sky.com/story/cyclone-ilsa-eight-fishermen-feared-dead-11-survive-without-food-or-water-for-nearly-a-week-12860796](https://news.sky.com/story/cyclone-ilsa-eight-fishermen-feared-dead-11-survive-without-food-or-water-for-nearly-a-week-12860796)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-04-19 09:05:00+00:00

Eight fishermen are feared to have drowned and another 11 have been rescued from an island off the Australian coast after they were caught in the path of a tropical cyclone.

## At least 29 killed in Beijing hospital fire
 - [https://news.sky.com/story/at-least-29-killed-in-beijing-hospital-fire-12860644](https://news.sky.com/story/at-least-29-killed-in-beijing-hospital-fire-12860644)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-04-19 04:55:00+00:00

A fire at a hospital in China has killed at least 29 people, authorities said.

