# Source:Brodie Robertson, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCld68syR8Wi-GY_n4CaoJGA, language:en-US

## uBlue Linux: Immutable Fedora With Batteries Included
 - [https://www.youtube.com/watch?v=HsKKh3WS1q0](https://www.youtube.com/watch?v=HsKKh3WS1q0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCld68syR8Wi-GY_n4CaoJGA
 - date published: 2023-04-19 21:00:12+00:00

The use of immutable Linux distros is growing and people keep telling me about one in particular uBlue or Universal Blue which isn't really a distro in the traditional sense.

==========Support The Channel==========
► $100 Linode Credit: https://brodierobertson.xyz/linode
► Patreon: https://brodierobertson.xyz/patreon
► Paypal: https://brodierobertson.xyz/paypal
► Liberapay: https://brodierobertson.xyz/liberapay
► Amazon USA: https://brodierobertson.xyz/amazonusa

==========Resources==========
uBlue Website: https://ublue.it/
Original uBlue Repo: https://github.com/castrojo/ublue
uBlue Org: https://github.com/ublue-os
Systemd Units and Udev: https://github.com/ublue-os/config
Bluefin: https://ublue.it/images/bluefin/?h=gnome
Make Your Own: https://ublue.it/making-your-own/

=========Video Platforms==========
🎥 Odysee: https://brodierobertson.xyz/odysee
🎥 Podcast: https://techovertea.xyz/youtube
🎮 Gaming: https://brodierobertson.xyz/gaming

==========Social Media==========
🎤 Discord: https://brodierobertson.xyz/discord
🎤 Matrix Space: https://brodierobertson.xyz/matrix
🐦 Twitter: https://brodierobertson.xyz/twitter
🌐 Mastodon: https://brodierobertson.xyz/mastodon
🖥️ GitHub: https://brodierobertson.xyz/github

==========Credits==========
🎨 Channel Art:
Profile Picture:
https://www.instagram.com/supercozman_draws/

🎵 Ending music
Music from https://filmmusic.io
"Basic Implosion" by Kevin MacLeod (https://incompetech.com)
License: CC BY (http://creativecommons.org/licenses/by/4.0/)

#Linux #Fedora #Silverblue #LinuxDesktop #LinuxDistro

DISCLOSURE: Wherever possible I use referral links, which means if you click one of the links in this video or description and make a purchase I may receive a small commission or other compensation.

