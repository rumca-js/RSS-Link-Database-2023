# Source:Daily Mail, URL:https://www.dailymail.co.uk/news/index.rss, language:en-US

## Brisbane plumber's toilet act caught on camera
 - [https://www.dailymail.co.uk/news/article-11992303/Brisbane-plumbers-sickening-act-caught-camera-charged-incident.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11992303/Brisbane-plumbers-sickening-act-caught-camera-charged-incident.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 23:29:42+00:00

A Brisbane homeowner was left distraught after footage showed the plumber, who had been recommended by a friend, allegedly using a kitchen utensil on her toilet before returning it unwashed.

## Darcey-Helen Conley's dad breaks silence after she and her sister were left to die in a hot car by
 - [https://www.dailymail.co.uk/news/article-11992107/Darcey-Helen-Conleys-dad-breaks-silence-sister-left-die-hot-car-by.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11992107/Darcey-Helen-Conleys-dad-breaks-silence-sister-left-die-hot-car-by.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 23:29:20+00:00

Darcey-Helen Conley was just two-and-a-half when she and 18-month Chloe-Ann were left in a car by their mother outside their Brisbane home in November 2019.

## RFK Jr's offspring join him and wife Cheryl Hines on stage to launch 2024 White House bid
 - [https://www.dailymail.co.uk/news/article-11992545/RFK-Jrs-offspring-join-wife-Cheryl-Hines-stage-launch-2024-White-House-bid.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11992545/RFK-Jrs-offspring-join-wife-Cheryl-Hines-stage-launch-2024-White-House-bid.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 23:27:08+00:00

The 69-year-old appeared at his opening campaign event in Boston with some of his family members on stage. But others inside the Kennedy clan have been critical of his views on vaccines.

## LA Sheriff's deputies 'wrongfully arrested' children in their own home, kids' mother says
 - [https://www.dailymail.co.uk/news/article-11992297/LA-Sheriffs-deputies-wrongfully-arrested-children-home-kids-mother-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11992297/LA-Sheriffs-deputies-wrongfully-arrested-children-home-kids-mother-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 23:21:36+00:00

A mom says her teenagers were wrongfully detained by the Los Angeles County Sheriff's Office inside their own home after deputies entered following reports of fighting inside the house.

## Yeppoon alleged carjacking: Two people charged after woman took off in car with baby inside
 - [https://www.dailymail.co.uk/news/article-11992447/Yeppoon-alleged-carjacking-Two-people-charged-woman-took-car-baby-inside.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11992447/Yeppoon-alleged-carjacking-Two-people-charged-woman-took-car-baby-inside.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 23:18:12+00:00

A 24-year-old woman and a 36-year-old man have been charged after a car was allegedly stolen with a four-month old baby in the back seat in a car park in Yeppoon, QLD on Wednesday afternoon.

## Republican forces Alejandro Mayorkas to confront family of granddaughter killed by human smuggler
 - [https://www.dailymail.co.uk/news/article-11992055/Republican-forces-Alejandro-Mayorkas-confront-family-granddaughter-killed-human-smuggler.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11992055/Republican-forces-Alejandro-Mayorkas-confront-family-granddaughter-killed-human-smuggler.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 23:18:04+00:00

Secretary of Homeland Security Alejandro Mayorkas offered his condolences Wednesday to the family of a grandmother and seven-year-old granddaughter who died in a car crash.

## Traditional brews now represent less than half of what Britons spend on teabags
 - [https://www.dailymail.co.uk/news/article-11992339/Traditional-brews-represent-half-Britons-spend-teabags.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11992339/Traditional-brews-represent-half-Britons-spend-teabags.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 23:16:12+00:00

Traditional brews now represent less than half of what we spend on teas, as the nation looks to more exotic herbal and fruit alternatives.

## 'Level up towns with universities': New institutions should be created in Britain's 'cold spots'
 - [https://www.dailymail.co.uk/news/article-11992407/Level-towns-universities-New-institutions-created-Britains-cold-spots.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11992407/Level-towns-universities-New-institutions-created-Britains-cold-spots.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 23:10:39+00:00

Lord Willetts, (pictured) a former universities minister, has suggested that new institutions could be set up in 'cold spots' across the UK to cope with the soaring demand.

## The 'astonishing' music maestro born without arms who plays the French horn with his toes
 - [https://www.dailymail.co.uk/news/article-11992301/The-astonishing-music-maestro-born-without-arms-plays-French-horn-toes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11992301/The-astonishing-music-maestro-born-without-arms-plays-French-horn-toes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 23:08:44+00:00

Felix Klieser, 32, (pictured) from Germany, whose musical talent is described as 'astonishing', will take part in two performances during the classical music season, which starts in July.

## Just Stop Oil drop 'hint' about Coronation protest on Twitter
 - [https://www.dailymail.co.uk/news/article-11992639/Just-Stop-Oil-drop-hint-Coronation-protest-Twitter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11992639/Just-Stop-Oil-drop-hint-Coronation-protest-Twitter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 23:08:12+00:00

Just Stop Oil, which was behind the protest at the snooker in Sheffield this week, never discloses its stunts in advance but dropped a cryptic hint that the event on May 6 may be in its sights.

## NSW Police launch search for missing girl who vanished from Warrimoo, Blue Mountains
 - [https://www.dailymail.co.uk/news/article-11992519/NSW-Police-launch-search-missing-girl-vanished-Warrimoo-Blue-Mountains.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11992519/NSW-Police-launch-search-missing-girl-vanished-Warrimoo-Blue-Mountains.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 22:50:51+00:00

Emily Humphries, 13, was last seen in Spurwood Road, Warrimoo west of Sydney around 11.30am on Wednesday and hasn't been spotted or heard from since.

## Elon Musk adorably plays with his 2-year-old son 'X AE A-XII' in a rare outing
 - [https://www.dailymail.co.uk/news/article-11992319/Elon-Musk-adorably-plays-Grimes-2-year-old-son-X-AE-XII-rare-outing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11992319/Elon-Musk-adorably-plays-Grimes-2-year-old-son-X-AE-XII-rare-outing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 22:25:57+00:00

Elon Musk was seen adorably playing with his 2-year-old son in a rare outing with the youngster at a Miami event Tuesday evening.

## Logan lockdown: Exclusion zone in Logan Reserve as police negotiate with potentially armed man
 - [https://www.dailymail.co.uk/news/article-11992363/Emergency-declared-Logan-Reserve-armed-man-holds-police-streets-locked-down.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11992363/Emergency-declared-Logan-Reserve-armed-man-holds-police-streets-locked-down.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 22:19:35+00:00

A man believed to be armed is holed up at a home in Logan in Queensland's southeast, with police imposing an exclusion zone as officers try to negotiate with him.

## Watch hair-raising moment police officer armed with massive machine gun busts weapons factory gang
 - [https://www.dailymail.co.uk/news/article-11990977/Watch-hair-raising-moment-police-officer-armed-massive-machine-gun-busts-weapons-factory-gang.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990977/Watch-hair-raising-moment-police-officer-armed-massive-machine-gun-busts-weapons-factory-gang.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 22:14:14+00:00

The organised crime group, who flooded Britain's streets with deadly guns converted at a weapons factory hidden inside a garage, would turn blank-firing guns  into live firearms.

## Widowed Texas Playboy model turned Italian PRINCESS, 73, faces eviction from $533m Roman villa
 - [https://www.dailymail.co.uk/news/article-11991871/Widowed-Texas-Playboy-model-turned-Italian-PRINCESS-73-faces-eviction-533m-Roman-villa.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991871/Widowed-Texas-Playboy-model-turned-Italian-PRINCESS-73-faces-eviction-533m-Roman-villa.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 22:10:03+00:00

A former Playboy model  turned Italian princess faces imminent eviction from her $533m villa in Rome.

## RFK Jr. addresses his past and outlines plans to deal with big pharma, Ukraine
 - [https://www.dailymail.co.uk/news/article-11991887/RFK-Jr-addresses-past-outlines-plans-deal-big-pharma-Ukraine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991887/RFK-Jr-addresses-past-outlines-plans-deal-big-pharma-Ukraine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 22:02:30+00:00

Robert F. Kennedy Jr. kicked off his longshot bid for the White House by being honest about his past, as he revealed plans to get big pharma out of the  government and create peace in Ukraine.

## DAILY MAIL COMMENT: Clock is ticking on PM's inflation target
 - [https://www.dailymail.co.uk/news/article-11992379/DAILY-MAIL-COMMENT-Clock-ticking-PMs-inflation-target.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11992379/DAILY-MAIL-COMMENT-Clock-ticking-PMs-inflation-target.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 22:00:21+00:00

DAILY MAIL COMMENT: For the second month in a row, consumer prices defied the optimism of most economists and, instead of tumbling into single figures, stayed above 10 per cent.

## Female Tory and Labour MPs warn 'extremist activists' must not be allowed to erode women's rights
 - [https://www.dailymail.co.uk/news/article-11992261/Female-Tory-Labour-MPs-warn-extremist-activists-not-allowed-erode-womens-rights.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11992261/Female-Tory-Labour-MPs-warn-extremist-activists-not-allowed-erode-womens-rights.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 21:59:55+00:00

Labour's Rosie Duffield (pictured) and the Conservatives' Miriam Cates warned last night that 'extremist activists' must not be allowed to erode hard-won protections.

## Junior doctors call for co-ordinated strikes with nurses minutes after rejecting government offer
 - [https://www.dailymail.co.uk/news/article-11992253/Junior-doctors-call-ordinated-strikes-nurses-minutes-rejecting-government-offer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11992253/Junior-doctors-call-ordinated-strikes-nurses-minutes-rejecting-government-offer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 21:46:15+00:00

Medics expressed their desire for joint walkouts on an online forum - with one post from a junior doctor claiming co-ordinated action would 'really disrupt' life.

## Now trans activist who boasts of her violence joins Women's Institute
 - [https://www.dailymail.co.uk/news/article-11992271/Now-trans-activist-boasts-violence-joins-Womens-Institute.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11992271/Now-trans-activist-boasts-violence-joins-Womens-Institute.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 21:42:31+00:00

Shanu Varma, who has described herself as 'violent and cruel' and purports to be a martial arts champion, said she had signed up to the organisation.

## Leonardo DiCaprio could be called to give evidence in German's cousin fraud trial
 - [https://www.dailymail.co.uk/news/article-11992041/Leonardo-DiCaprio-called-evidence-Germans-cousin-fraud-trial.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11992041/Leonardo-DiCaprio-called-evidence-Germans-cousin-fraud-trial.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 21:27:14+00:00

Niklas In den Birken allegedly provided the firm with fake updates on his efforts to bring Leonardo DiCaprio on board - including claims they went to Harry and Meghan's wedding together.

## Tony Danker accuses CBI of 'throwing me under the bus - then reversing back over me'
 - [https://www.dailymail.co.uk/news/article-11992181/Tony-Danker-accuses-CBI-throwing-bus-reversing-me.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11992181/Tony-Danker-accuses-CBI-throwing-bus-reversing-me.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 21:25:49+00:00

Sacked CBI boss Tony Danker could be heard delivering a very different public message via a BBC interview. His subject: how a series of events has cost him his job and reputation.

## IRS whistleblower claims he has PROOF Biden administration is 'improperly handling' Hunter probe
 - [https://www.dailymail.co.uk/news/article-11992009/IRS-whistleblower-claims-PROOF-Biden-administration-improperly-handling-Hunter-probe.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11992009/IRS-whistleblower-claims-PROOF-Biden-administration-improperly-handling-Hunter-probe.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 21:24:23+00:00

A supervisory tax agent for a criminal probe has come forward seeking whistleblower protections in an inquiry dealing with the president's son, Hunter Biden.

## Alec Baldwin gives wife Hilaria a tender kiss goodbye in front of a camera crew
 - [https://www.dailymail.co.uk/news/article-11991215/Alec-Baldwin-gives-wife-Hilaria-tender-kiss-goodbye-camera-crew.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991215/Alec-Baldwin-gives-wife-Hilaria-tender-kiss-goodbye-camera-crew.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 21:24:17+00:00

A camera crew showed up to Baldwins' Manhattan apartment Wednesday morning, captured the family's goodbyes and then went along to the airport with Alec.

## Elon Musk says he'll SUE Microsoft for 'training illegally using Twitter data' in row over ads
 - [https://www.dailymail.co.uk/news/article-11992185/Elon-Musk-says-hell-SUE-Microsoft-training-illegally-using-Twitter-data-row-ads.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11992185/Elon-Musk-says-hell-SUE-Microsoft-training-illegally-using-Twitter-data-row-ads.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 21:24:14+00:00

Elon Musk says he'll sue Microsoft after claiming the software giant 'trained illegally' using the social networking site's data.

## Anti-monarchists planning protest for coronation say they won't copy Extinction Rebellion
 - [https://www.dailymail.co.uk/news/article-11991957/Anti-monarchists-planning-protest-coronation-say-wont-copy-Extinction-Rebellion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991957/Anti-monarchists-planning-protest-coronation-say-wont-copy-Extinction-Rebellion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 21:22:35+00:00

Graham Smith, chief executive of Republic, said more than 1,350 activists have pledged to gather in London.

## Did Michelangelo paint himself onto the CEILING of the Sistine Chapel - portraying himself as GOD?
 - [https://www.dailymail.co.uk/news/article-11991045/Did-Michelangelo-paint-CEILING-Sistine-Chapel-portraying-GOD.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991045/Did-Michelangelo-paint-CEILING-Sistine-Chapel-portraying-GOD.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 21:17:39+00:00

The theory centres around one of the most iconic paintings in the world - 'The Creation of Adam', the arm of a gentle, bearded God reaching out to give life to Adam.

## Deadly NYC garage collapse likely caused by building's age and number of cars parked on roof deck
 - [https://www.dailymail.co.uk/news/article-11991943/Deadly-NYC-garage-collapse-likely-caused-buildings-age-number-cars-parked-roof-deck.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991943/Deadly-NYC-garage-collapse-likely-caused-buildings-age-number-cars-parked-roof-deck.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 21:11:21+00:00

Mayor Eric Adams said during a press conference on Wednesday that there were more than 50 cars on the top level of the roof - blaming heavy SUV's and electric vehicles.

## Keir Starmer opposed deportation of criminal jailed for vile sex attacks on teenage girls
 - [https://www.dailymail.co.uk/news/article-11992213/Keir-Starmer-opposed-deportation-criminal-jailed-vile-sex-attacks-teenage-girls.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11992213/Keir-Starmer-opposed-deportation-criminal-jailed-vile-sex-attacks-teenage-girls.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 21:07:57+00:00

Fabian Henry (pictured) was jailed for two vile attacks on a girl of 17 and for abducting and having sex with a 15-year-old.

## Elizabeth Holmes again pleads with judge to reverse her conviction or reduce her 11-year sentence
 - [https://www.dailymail.co.uk/news/article-11991327/Elizabeth-Holmes-pleads-judge-reverse-conviction-reduce-11-year-sentence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991327/Elizabeth-Holmes-pleads-judge-reverse-conviction-reduce-11-year-sentence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 21:02:25+00:00

Elizabeth Holmes. 39. accused the court of giving her too much time for her crimes after it tacked on 10 more years for 'enhancement' for the 'number of victims.'

## MPs demand a global summit on dangers of AI's rapid development - despite Hunt's assurances
 - [https://www.dailymail.co.uk/news/article-11992087/MPs-demand-global-summit-dangers-AIs-rapid-development-despite-Hunts-assurances.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11992087/MPs-demand-global-summit-dangers-AIs-rapid-development-despite-Hunts-assurances.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 21:02:14+00:00

The Chancellor spoke to Politico, urging that AI could help reverse trends of slowing productivity and growth, as Britain invests millions in new tech to make Britain a science 'superpower' by 2030.

## My mother created the Wombles - then used them to take revenge on my cheating, blackmailing father
 - [https://www.dailymail.co.uk/news/article-11992065/My-mother-created-Wombles-used-revenge-cheating-blackmailing-father.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11992065/My-mother-created-Wombles-used-revenge-cheating-blackmailing-father.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 21:01:06+00:00

Elizabeth Beresford (pictured with Great Uncle Bulgaria) created The Wombles and based Cairngorm MacWomble the Terrible on her blackmailing ex-husband Max.

## AAA won't pay to repair elderly couple's home after car flew off road and destroyed it
 - [https://www.dailymail.co.uk/news/article-11991899/AAA-wont-pay-repair-elderly-couples-home-car-flew-road-destroyed-it.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991899/AAA-wont-pay-repair-elderly-couples-home-car-flew-road-destroyed-it.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 21:00:28+00:00

An elderly couple are homeless after a car flew off the road and landed on the second story of their home - with their insurer refusing to pay.

## Biden claims Kevin McCarthy is giving into 'wacko' demands from his party
 - [https://www.dailymail.co.uk/news/article-11991975/Biden-claims-Kevin-McCarthy-giving-wacko-demands-party.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991975/Biden-claims-Kevin-McCarthy-giving-wacko-demands-party.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 20:50:17+00:00

President Joe Biden slammed Speaker Kevin McCarthy and the 'MAGA Republicans' for the 'wacko notions' they want him to agree to in order to raise the debt ceiling.

## Southwest Airlines passenger screams at parents of child that won't stop crying on flight
 - [https://www.dailymail.co.uk/news/article-11992089/Southwest-Airlines-passenger-screams-parents-child-wont-stop-crying-flight.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11992089/Southwest-Airlines-passenger-screams-parents-child-wont-stop-crying-flight.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 20:26:10+00:00

A passenger on a commercial plane has been recorded in midair screaming and swearing at the parents of a child that would not stop crying.

## Home Depot worker is shot and killed inside the store while trying to stop shoplifter
 - [https://www.dailymail.co.uk/news/article-11991801/Home-Depot-worker-shot-killed-inside-store-trying-stop-shoplifter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991801/Home-Depot-worker-shot-killed-inside-store-trying-stop-shoplifter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 20:20:49+00:00

A young man was fatally shot while attempting to stop a robbery at Home Depot in Pleasanton, California.

## Duke University professor says US needs to enact $14 TRILLION reparations program
 - [https://www.dailymail.co.uk/news/article-11991447/Duke-University-professor-says-needs-enact-14-TRILLION-reparations-program.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991447/Duke-University-professor-says-needs-enact-14-TRILLION-reparations-program.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 20:20:17+00:00

Duke University professor William Darity said that each black American should receive $350,000 of taxpayer money in a massive reparations programs.

## Uvalde shooter Salvador Ramos wrote 'LOL' using the blood of his elementary school victims
 - [https://www.dailymail.co.uk/news/article-11991673/Uvalde-shooter-Salvador-Ramos-wrote-LOL-using-blood-elementary-school-victims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991673/Uvalde-shooter-Salvador-Ramos-wrote-LOL-using-blood-elementary-school-victims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 20:19:14+00:00

Rep. Joe Moody made the revelation about Uvalde shooter Salvador Ramos in front of the victims' horrified family members during a House committee.

## French publisher arrested over Macron protests was 'quizzed on political opinions' by British police
 - [https://www.dailymail.co.uk/news/article-11991597/French-publisher-arrested-Macron-protests-quizzed-political-opinions-British-police.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991597/French-publisher-arrested-Macron-protests-quizzed-political-opinions-British-police.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 20:16:47+00:00

Ernest Moret's publishers said that he was detained and questioned in London without a lawyer present, held for nearly 24 hours, and had his personal devices seized by counter-terrorism police.

## MEGHAN MCCAIN: Mobs are destroying Chicago - but gutless far-left lunatics are defending the thugs
 - [https://www.dailymail.co.uk/news/article-11991591/MEGHAN-MCCAIN-Mobs-destroying-Chicago-gutless-far-left-lunatics-defending-thugs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991591/MEGHAN-MCCAIN-Mobs-destroying-Chicago-gutless-far-left-lunatics-defending-thugs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 20:10:05+00:00

MCCAIN: At this point in the decline of America's cities, I don't expect city leaders to be appalled. Today, violence, destruction, and nihilism is accepted. It's the new normal.

## Joseph Eaton, 34, killed his parents and two of their friends in Maine, police say
 - [https://www.dailymail.co.uk/news/article-11991905/Joseph-Eaton-32-killed-parents-two-friends-Maine-police-say.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991905/Joseph-Eaton-32-killed-parents-two-friends-Maine-police-say.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 20:08:52+00:00

Lone gunman Joseph Eaton, 32, killed his parents and two of their friends before opening fire on a Maine highway, days after he was released from prison on assault charges, police said.

## Elton John tells Congress to keep funding Biden's battle to end AIDS and thanks lawmakers
 - [https://www.dailymail.co.uk/news/article-11991699/Elton-John-tells-Congress-funding-Bidens-battle-end-AIDS-thanks-lawmakers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991699/Elton-John-tells-Congress-funding-Bidens-battle-end-AIDS-thanks-lawmakers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 20:02:39+00:00

Elton John urged senators on Wednesday not to let up in the battle against AIDS, as Congress approaches a deadline for reauthorizing the multi-billion-dollar U.S. program to fight the disease.

## Married Royal Marine who climbed naked into bed with female colleague cleared of sexual assault
 - [https://www.dailymail.co.uk/news/article-11991629/Married-Royal-Marine-climbed-naked-bed-female-colleague-cleared-sexual-assault.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991629/Married-Royal-Marine-climbed-naked-bed-female-colleague-cleared-sexual-assault.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 20:01:21+00:00

'Exceptionally drunk' Corporal Brook Hirst clambered into bed with the woman at which point she woke up to him repeatedly 'tugging' at her jeans as he attempted to take them off.

## Kevin Monahan, suspect in the killing of 20-year-old Kaylin Gillis, held without bail
 - [https://www.dailymail.co.uk/news/article-11991669/Kevin-Monahan-suspect-killing-20-year-old-Kaylin-Gillis-held-without-bail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991669/Kevin-Monahan-suspect-killing-20-year-old-Kaylin-Gillis-held-without-bail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 19:29:28+00:00

The father of Kaylin Gillis, the 20-year-old who was killed when her boyfriend drove up the wrong driveway in rural upstate New York, told the media he hopes the suspect in the shooting 'dies in jail.'

## Travelers race to airline website after cheap fares error
 - [https://www.dailymail.co.uk/news/article-11991169/Travelers-buy-10-000-flights-just-300-airline-glitch-cash-similar-gaffes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991169/Travelers-buy-10-000-flights-just-300-airline-glitch-cash-similar-gaffes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 19:29:21+00:00

A Japanese airline accidentally sold dozens of business class Asia-US flights for just a fraction of their price due to a currency exchange rate blunder.

## Kevin McCarthy proposes raising the debt limit by $1.5T to save $4.5T
 - [https://www.dailymail.co.uk/news/article-11991533/Kevin-McCarthy-proposes-raising-debt-limit-1-5T-save-4-5T.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991533/Kevin-McCarthy-proposes-raising-debt-limit-1-5T-save-4-5T.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 19:29:02+00:00

House Republicans are proposing to lift the debt ceiling by $1.5 trillion or extend borrowing until March 31, 2024 and Speaker Kevin McCarthy plans to hold a vote on the package by next week.

## Supreme Court extends access to abortion pills until Friday
 - [https://www.dailymail.co.uk/news/article-11991853/Supreme-Court-extends-access-abortion-pills-Friday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991853/Supreme-Court-extends-access-abortion-pills-Friday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 19:27:22+00:00

Justice Samuel Alito imposed an administrative stay that extended the block on a Texas judge's controversial mifepristone ruling.

## Rosie O'Donnell slams The View and says she will NEVER co-host on the show again
 - [https://www.dailymail.co.uk/news/article-11991439/Rosie-ODonnell-slams-View-says-NEVER-host-again.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991439/Rosie-ODonnell-slams-View-says-NEVER-host-again.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 19:24:00+00:00

Rosie O'Donnell, 61, first joined the show in 2006 before leaving a year later after she felt that she was 'thrown under the bus' by co-host Elisabeth Hasselbeck.

## Retired white aircraft technician pleads NOT GUILTY to two felony assault charges
 - [https://www.dailymail.co.uk/news/article-11991741/Retired-white-aircraft-technician-pleads-NOT-GUILTY-two-felony-assault-charges.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991741/Retired-white-aircraft-technician-pleads-NOT-GUILTY-two-felony-assault-charges.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 19:23:08+00:00

Andrew Lester, 84, entered his pleas during a first appearance at Clay County Courthouse on Wednesday.,

## Now THAT'S a blocked drain!: Water company extracts mass of wet wipes from 400-metresewer
 - [https://www.dailymail.co.uk/news/article-11991085/Now-THATS-blocked-drain-Water-company-extracts-mass-wet-wipes-400-yard-sewer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991085/Now-THATS-blocked-drain-Water-company-extracts-mass-wet-wipes-400-yard-sewer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 19:23:04+00:00

Wessex Water said the drain-dwelling monster was from only a 'handful of properties' flushing the wipes down their toilets in Highbridge, Somerset.

## British holidaymaker who threatened cabin staff is jailed for 20 weeks
 - [https://www.dailymail.co.uk/news/article-11991127/British-holidaymaker-threatened-cabin-staff-jailed-20-weeks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991127/British-holidaymaker-threatened-cabin-staff-jailed-20-weeks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 19:15:19+00:00

Wesley Haining, 45, (pictured) admitted being drunk on an aircraft and using threatening and abusive words to cause distress and alarm and was jailed for 20 weeks.

## Florida accuses Disney of acting like 'Scrooge McDuck' with plot to keep power
 - [https://www.dailymail.co.uk/news/article-11991517/Florida-accuses-Disney-acting-like-Scrooge-McDuck-plot-power.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991517/Florida-accuses-Disney-acting-like-Scrooge-McDuck-plot-power.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 19:05:11+00:00

Ron DeSantis' new board  warned Disney they could surround it with affordable housing and demand it pay its back taxes as the state continues to seek payback against the theme park.

## Jeremy Hunt warns Britain can't 'opt out' of AI race and needs to 'win' the battle over new tech
 - [https://www.dailymail.co.uk/news/article-11991779/Jeremy-Hunt-insists-Britain-opt-AI-race-needs-win-battle-new-tech.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991779/Jeremy-Hunt-insists-Britain-opt-AI-race-needs-win-battle-new-tech.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 18:58:29+00:00

The Chancellor admitted there was scope for AI to be 'used in a bad way' but he rejected recent calls - including from billionaire Elon Musk - for a pause on research.

## Incredible video shows Russian soldiers hurling grenades into trenches and Ukrainian counter
 - [https://www.dailymail.co.uk/news/article-11991307/Incredible-video-shows-Russian-soldiers-hurling-grenades-trenches-Ukrainian-counter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991307/Incredible-video-shows-Russian-soldiers-hurling-grenades-trenches-Ukrainian-counter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 18:57:12+00:00

New video footage shows intense clashes between Ukrainian and Russian forces around a dug out on the 'last road out of Bakhmut'. The city has endured more than eight months of bitter fighting.

## Chucky actor Ed Gale, 59, under investigation by the LAPD after he admitted to sexting minors
 - [https://www.dailymail.co.uk/news/article-11990447/Chucky-actor-Ed-Gale-59-investigation-LAPD-admitted-sexting-minors.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990447/Chucky-actor-Ed-Gale-59-investigation-LAPD-admitted-sexting-minors.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 18:53:46+00:00

A group calling themselves 'Creep Catcher Unit' posed as a 14-year-old boy online and allegedly received lewd texts from actor Ed Gale, 59.

## Rotherham sex abuse victim recalls moment she told her son that she was raped by gang ringleader
 - [https://www.dailymail.co.uk/news/article-11991655/Rotherham-sex-abuse-victim-tells-moment-told-son-raped-gang-ringleader.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991655/Rotherham-sex-abuse-victim-tells-moment-told-son-raped-gang-ringleader.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 18:49:18+00:00

Sammy Woodhouse (pictured), 37, became pregnant at the age of 15 after being raped by violent ringleader Arshid Hussain, who was 25 at the time.

## Is Discord the most dangerous place online? Site hosted killers, child abusers and Pentagon leaker
 - [https://www.dailymail.co.uk/news/article-11987701/Is-Discord-dangerous-place-online-Site-hosted-killers-child-abusers-Pentagon-leaker.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11987701/Is-Discord-dangerous-place-online-Site-hosted-killers-child-abusers-Pentagon-leaker.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 18:28:20+00:00

The destructive power of an individual armed with nothing but a computer and a Wi-Fi connection is remarkable in the modern world. And in this case, Discord was the weapon of choice.

## 'We are a clean couple with no kids': Lori Vallow Hawaii property inquiry after children's deaths
 - [https://www.dailymail.co.uk/news/article-11991379/We-clean-couple-no-kids-Lori-Vallow-Hawaii-property-inquiry-childrens-deaths.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991379/We-clean-couple-no-kids-Lori-Vallow-Hawaii-property-inquiry-childrens-deaths.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 18:27:26+00:00

Daybell, 54, emailed the Hawaii realtor on November 8, 2019, stating: 'Would the owners be interested in leasing this property to a clean couple with no pets or children?'

## Rare mysterious beast is spotted roaming towns in Wales as animal rescuers hatch plan to capture it
 - [https://www.dailymail.co.uk/news/article-11991505/Rare-mysterious-beast-spotted-roaming-towns-Wales-animal-rescuers-hatch-plan-capture-it.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991505/Rare-mysterious-beast-spotted-roaming-towns-Wales-animal-rescuers-hatch-plan-capture-it.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 18:24:18+00:00

The black-coloured creature (pictured) was spotted by several shocked onlookers in Barry, South Wales.

## Three-year-old boy is rushed to hospital after being mauled by XL Bully dog
 - [https://www.dailymail.co.uk/news/article-11991565/Three-year-old-boy-rushed-hospital-mauled-XL-Bully-dog.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991565/Three-year-old-boy-rushed-hospital-mauled-XL-Bully-dog.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 18:23:49+00:00

The boy was attacked by a family pet in  Rotherham, 
south Yorkshire, on Monday. A  woman was arrested on suspicion of allowing a dog to be dangerously out of control.

## Prime Minister Rishi Sunak meets the Clintons at 25th anniversary of Good Friday Agreement
 - [https://www.dailymail.co.uk/news/article-11991303/Prime-Minister-Rishi-Sunak-meets-Clintons-25th-anniversary-Good-Friday-Agreement.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991303/Prime-Minister-Rishi-Sunak-meets-Clintons-25th-anniversary-Good-Friday-Agreement.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 18:22:04+00:00

Mr Sunak posed for photographs alongside his wife Akshata Murthy, the Clintons and Irish Taoiseach Leo Varadkar in Belfast this afternoon.

## Florida school principal charged with sexually abusing male student who viewed her as MOTHER FIGURE
 - [https://www.dailymail.co.uk/news/article-11991209/Florida-school-principal-charged-sexually-abusing-male-student-viewed-MOTHER-FIGURE.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991209/Florida-school-principal-charged-sexually-abusing-male-student-viewed-MOTHER-FIGURE.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 18:21:12+00:00

Tracy Smith, 43, head of Xceed Preparatory Academy in Coral Springs was arrested on Monday for the alleged sexual misconduct with a16-year-old student.

## Pete Buttigieg faces claim he's 'asleep at the wheel' after Southwest grounded all flights
 - [https://www.dailymail.co.uk/news/article-11990993/Pete-Buttigieg-faces-claim-hes-asleep-wheel-Southwest-grounded-flights.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990993/Pete-Buttigieg-faces-claim-hes-asleep-wheel-Southwest-grounded-flights.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 18:20:17+00:00

Department of Transportation Sec. Pete Buttigieg is under increased scrutiny by Republicans in Congress, who are accusing him of being 'asleep at the wheel.'

## Three people 'including 16-year-old boy' die in Cornwall horror crash
 - [https://www.dailymail.co.uk/news/article-11991593/Three-people-including-16-year-old-boy-die-Cornwall-horror-crash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991593/Three-people-including-16-year-old-boy-die-Cornwall-horror-crash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 18:13:20+00:00

Police were called at 11.50pm last night to the A390 near St Ive, to reports that a vehicle had left the road and was on fire.

## Furious taxpayers blast Britain's biggest council fat cat who pocketed £607K last year
 - [https://www.dailymail.co.uk/news/article-11991325/Furious-taxpayers-blast-Britains-biggest-council-fat-cat-pocketed-607K-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991325/Furious-taxpayers-blast-Britains-biggest-council-fat-cat-pocketed-607K-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 18:06:57+00:00

James Whiteman, 57, received the huge pay package after taking voluntary redundancy from Guildford Borough Council. Taxpayers have blasted the payment as a 'joke'.

## Sharecropper who learned to build igloos, speak Inuit told white explorer they were in right spot
 - [https://www.dailymail.co.uk/news/article-11990827/Sharecropper-learned-build-igloos-speak-Inuit-told-white-explorer-right-spot.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990827/Sharecropper-learned-build-igloos-speak-Inuit-told-white-explorer-right-spot.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 18:06:43+00:00

A black sharecropper accompanied Robert Peary to the North Pole in 1909.

## Taylor Swift didn't sign $100 million FTX sponsorship because of one question
 - [https://www.dailymail.co.uk/news/article-11990967/Taylor-Swift-didnt-sign-100-million-FTX-sponsorship-one-question.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990967/Taylor-Swift-didnt-sign-100-million-FTX-sponsorship-one-question.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 17:44:22+00:00

Taylor Swift sidestepped the FTX disaster by asking one simple question when approached by the disgraced crypto exchange about a $100 million sponsorship deal.

## Chicago woman flips SUV after gas station rampage
 - [https://www.dailymail.co.uk/news/article-11990899/Chicago-woman-flips-SUV-gas-station-rampage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990899/Chicago-woman-flips-SUV-gas-station-rampage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 17:30:27+00:00

A woman with several prior felonies rammed through a gas station, hitting several cars, in her Ford Explorer after getting into a fight with her boyfriend.

## Veteran manager of NYC garage was killed and trapped on second floor after building collapsed on him
 - [https://www.dailymail.co.uk/news/article-11991457/Veteran-manager-NYC-garage-killed-trapped-second-floor-building-collapsed-him.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991457/Veteran-manager-NYC-garage-killed-trapped-second-floor-building-collapsed-him.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 17:27:43+00:00

Willis Moore, 59, was working in the building when it collapsed on Ann Street in the Financial District on Tuesday at 4pm.

## Dominion is suing six others for defamation including Rudy Giuliani, Newsmax, and OANN
 - [https://www.dailymail.co.uk/news/article-11990417/Dominion-suing-six-defamation-including-Rudy-Giuliani-Newsmax-OANN.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990417/Dominion-suing-six-defamation-including-Rudy-Giuliani-Newsmax-OANN.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 17:27:35+00:00

In addition to the nearly $800M promised to Dominion by Fox, the voting tech company is also suing Newsmax, OANN, Rudy Giuliani, Sidney Powell, Mike Lindell, and Patrick Byrne.

## Florida bans lessons on gender identity and sexual orientation in ALL public school grades
 - [https://www.dailymail.co.uk/news/article-11991343/Florida-bans-lessons-gender-identity-sexual-orientation-public-school-grades.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991343/Florida-bans-lessons-gender-identity-sexual-orientation-public-school-grades.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 17:27:07+00:00

The Florida Board of Education approved on Wednesday an expansion of Gov. Ron DeSantis' rule prohibiting the teaching of gender identity and sexual orientation in all grade levels.

## 'Tummy tuck four' survivor is ARRESTED 'for taking her child to a fight the youngster'
 - [https://www.dailymail.co.uk/news/article-11990869/Tummy-tuck-four-survivor-ARRESTED-taking-child-fight-youngster.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990869/Tummy-tuck-four-survivor-ARRESTED-taking-child-fight-youngster.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 17:27:01+00:00

Latavia Washington McGee, 34, has been charged for crime which happened on February 17 - just weeks before her kidnapping in Mexico.

## Flight delays soar to a decade-high: The 10 worst offenders
 - [https://www.dailymail.co.uk/news/article-11986939/Flight-delays-soar-decade-high-10-worst-offenders.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11986939/Flight-delays-soar-decade-high-10-worst-offenders.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 17:26:52+00:00

Exclusive data from flight tracking platform FlightAware shows that a shocking 21.4% of flights in the last year have been delayed by an average of 50 minutes.

## Channel 4's 'body positive' Naked Education is branded 'dangerously disingenuous'
 - [https://www.dailymail.co.uk/news/article-11990947/Channel-4s-body-positive-Naked-Education-branded-dangerously-disingenuous.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990947/Channel-4s-body-positive-Naked-Education-branded-dangerously-disingenuous.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 17:26:12+00:00

Naked Education has been branded 'dangerously disingenuous' for portraying trans adults 'as the epitome of self-acceptance' while 'sidestepping' other issues

## K-POP star Moonbin 'is found dead at his apartment', police in South Korea say
 - [https://www.dailymail.co.uk/news/article-11991467/K-POP-star-Moonbin-dead-apartment-police-South-Korea-say.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991467/K-POP-star-Moonbin-dead-apartment-police-South-Korea-say.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 17:26:10+00:00

The singer, actor, dancer and model was best known as a member of boy band Astro and its sub-unit Moonbin and Sanha.

## Devoted husband and wife in their 80s died after plunging from vertical cliffs in Devon
 - [https://www.dailymail.co.uk/news/article-11991061/Devoted-husband-wife-80s-died-plunging-vertical-cliffs-Devon.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991061/Devoted-husband-wife-80s-died-plunging-vertical-cliffs-Devon.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 17:13:46+00:00

A coroner heard nature loving couple John and Imogen Kesteven may have slipped or tripped along a cliff path over the vertical cliffs which rise to nearly 1,000 feet at their highest point at Lynton.

## Kim Kardashian's ex business partner who created 'Kimoji' app says she ruined his life
 - [https://www.dailymail.co.uk/news/article-11965701/Kim-Kardashians-ex-business-partner-created-Kimoji-app-says-ruined-life.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11965701/Kim-Kardashians-ex-business-partner-created-Kimoji-app-says-ruined-life.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 17:08:30+00:00

David Liebensohn developed a Kardashian-themed emoji range called 'Kimoji' - an app that generated $1million a minute - but he didn't see a cent of its profits.

## Levi Davis feared to have drowned off Barcelona, as ship crew recount trying to save man seen at sea
 - [https://www.dailymail.co.uk/news/article-11991359/Levi-Davis-feared-drowned-Barcelona-ship-crew-recount-trying-save-man-seen-sea.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991359/Levi-Davis-feared-drowned-Barcelona-ship-crew-recount-trying-save-man-seen-sea.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 17:05:55+00:00

Bath rugby player and X Factor Levi Davis (pictured) star went missing on 29 October in Barcelona. A ship's crew said they saw a man at sea matching his description the day after.

## 'Why are we arming our enemies?' Mexico's drug cartels source 80% of their guns from the US
 - [https://www.dailymail.co.uk/news/article-11990563/Why-arming-enemies-Mexicos-drug-cartels-source-80-guns-US.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990563/Why-arming-enemies-Mexicos-drug-cartels-source-80-guns-US.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 16:59:15+00:00

Experts decry an 'iron river' of thousands of firearms being sourced from US dealers that end up in the hands of criminals in Mexico, Central America, and much of Latin America.

## Keir Starmer gets free football tickets from firm forced to pay out £10.8m over defective cladding
 - [https://www.dailymail.co.uk/news/article-11990939/Keir-Starmer-gets-free-football-tickets-firm-forced-pay-10-8m-defective-cladding.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990939/Keir-Starmer-gets-free-football-tickets-firm-forced-pay-10-8m-defective-cladding.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 16:27:10+00:00

The Labour leader has declared a donation of hospitality match tickets, valued at £1,070, from Mulalley & Co Limited for Arsenal's match with West Ham this weekend.

## Star high school cheerleaders are shot after one accidentally got into the wrong car
 - [https://www.dailymail.co.uk/news/article-11991059/Cheerleader-shot-accidentally-getting-wrong-car.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991059/Cheerleader-shot-accidentally-getting-wrong-car.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 16:27:09+00:00

Payton Washington and Heather Roth were shot multiple times by a man sitting in a vehicle they mistakenly got into as they tried to carpool home from practice in Elgin, Texas.

## RFK Jr. announces he is running for PRESIDENT against Biden
 - [https://www.dailymail.co.uk/news/article-11990771/RFK-Jr-announces-running-PRESIDENT-against-Biden.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990771/RFK-Jr-announces-running-PRESIDENT-against-Biden.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 16:26:10+00:00

The scion of America's political 'royal family' has become better known in recent years for parroting conspiracy theories about vaccines.

## Joseph Eaton, who police say killed four people in a Maine home, asked for forgiveness on Facebook
 - [https://www.dailymail.co.uk/news/article-11991107/Joseph-Eaton-police-say-killed-four-people-Maine-home-asked-forgiveness-Facebook.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991107/Joseph-Eaton-police-say-killed-four-people-Maine-home-asked-forgiveness-Facebook.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 16:25:48+00:00

The suspect in the murders of four people in a home in Maine on Monday tearfully begged for forgiveness a day before in a Facebook video.

## Senate Armed Services Committee gets testimony from Pentagon's office tracking UFOs
 - [https://www.dailymail.co.uk/news/article-11990825/Senate-Armed-Services-Committee-gets-testimony-Pentagons-office-tracking-UFOs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990825/Senate-Armed-Services-Committee-gets-testimony-Pentagons-office-tracking-UFOs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 16:23:08+00:00

The head of the Pentagon's All-Domain Anomaly Resolution Office, which tracks UFOs, testified before the Senate Armed Services Committee Wednesday.

## Ralph Yarl, 16, smiles as he recovers at home after being shot in head by white homeowner, 84
 - [https://www.dailymail.co.uk/news/article-11991239/Ralph-Yarl-16-smiles-recovers-home-shot-head-white-homeowner-84.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991239/Ralph-Yarl-16-smiles-recovers-home-shot-head-white-homeowner-84.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 16:22:31+00:00

The 16-year-old old looked relaxed and smiled with his lawyer Lee Merritt on Wednesday, ahead of Andrew Lester, 84, appearing in court for the first time.

## DeSantis tears into 'ridiculous' Bud Light, warns Disney it will be kept 'in its pen'
 - [https://www.dailymail.co.uk/news/article-11990903/DeSantis-tears-ridiculous-Bud-Light-warns-Disney-kept-pen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990903/DeSantis-tears-ridiculous-Bud-Light-warns-Disney-kept-pen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 16:21:24+00:00

Ron DeSantis railed against the 'woke mind virus' as he promised to 'keep Disney in its pen' and pushed back on Bud Light's decision to use a transgender social media star as a spokesperson.

## American taxpayers could be funding the TALIBAN: SIGAR makes startling admission
 - [https://www.dailymail.co.uk/news/article-11990841/American-taxpayers-funding-TALIBAN-SIGAR-makes-startling-admission.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990841/American-taxpayers-funding-TALIBAN-SIGAR-makes-startling-admission.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 16:19:33+00:00

John Sopko said the Taliban is likely stealing US aid intended for the Afghan people as he knocked the Defense, State and USAID for an 'unprecedented' lack of cooperation.

## SNP's Colin Beattie QUITS as party treasurer after being arrested by police probing party accounts
 - [https://www.dailymail.co.uk/news/article-11991153/SNPs-Colin-Beattie-QUITS-party-treasurer-arrested-police-probing-party-accounts.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991153/SNPs-Colin-Beattie-QUITS-party-treasurer-arrested-police-probing-party-accounts.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 16:17:09+00:00

MSP Colin Beattie is stepping back as SNP treasurer and from Holyrood's Public Audit Committee until the police investigation into the party's finance is concluded, he said in a statement.

## Leonardo da Inky! Artist recreates Mona Lisa using just a typewriter
 - [https://www.dailymail.co.uk/news/article-11990853/Leonardo-da-Inky-Artist-recreates-Mona-Lisa-using-just-typewriter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990853/Leonardo-da-Inky-Artist-recreates-Mona-Lisa-using-just-typewriter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 16:10:24+00:00

James Cook, 26, has amassed a collection of 70 typewriters that he uses to create recreate masterpieces.

## Heathrow security staff will strike for another eight days next month in fresh blow to passengers
 - [https://www.dailymail.co.uk/news/article-11991155/Heathrow-security-staff-strike-eight-days-month-fresh-blow-passengers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991155/Heathrow-security-staff-strike-eight-days-month-fresh-blow-passengers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 16:10:16+00:00

Security officers at Heathrow Airport will strike for eight more days next month amid their ongoing dispute over pay, union Unite has announced.

## Incredible moment canoeists find themselves feet from breaching whale in Antarctica
 - [https://www.dailymail.co.uk/news/article-11990755/Incredible-moment-canoeists-feet-breaching-whale-Antarctica.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990755/Incredible-moment-canoeists-feet-breaching-whale-Antarctica.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 16:08:41+00:00

The photograph shows the humongous tail of the creature arching out above the sea in ultra-high definition as birds circle in front of the frozen blue caps in Antarctica.

## Labour's Peter Kyle apologises to Humza Yousaf after calling First Minister 'Mohammad' on live  TV
 - [https://www.dailymail.co.uk/news/article-11991131/Labours-Peter-Kyle-apologises-Humza-Yousaf-calling-Minister-Mohammad-live-TV.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991131/Labours-Peter-Kyle-apologises-Humza-Yousaf-calling-Minister-Mohammad-live-TV.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 16:07:04+00:00

The shadow Northern Ireland secretary was attacking the SNP when he made the gaffe about Scotland's first Muslim leader.

## Female PC tells court there are 'no words' to express how sorry she is after hitting boy with car
 - [https://www.dailymail.co.uk/news/article-11991123/Female-PC-tells-court-no-words-express-sorry-hitting-boy-car.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11991123/Female-PC-tells-court-no-words-express-sorry-hitting-boy-car.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 16:06:56+00:00

Khia Whitehead was 15 when he was struck by a speeding police patrol car being driven by constable Sarah De Meulemeester, 26, on the wrong side of the road

## King will host pre-Coronation party at Buckingham Palace on the eve of historic ceremony
 - [https://www.dailymail.co.uk/news/article-11990935/King-host-pre-Coronation-party-Buckingham-Palace-eve-historic-ceremony.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990935/King-host-pre-Coronation-party-Buckingham-Palace-eve-historic-ceremony.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 16:04:07+00:00

Guest numbers for the King's Coronation are so tight that many foreign royals and British aristocrats have missed out on invitations to the Westminster Abbey ceremony.

## Boy who crashed into cyclist to steal £15,000 bike jailed after walking into cafe where police were
 - [https://www.dailymail.co.uk/news/article-11990855/Boy-crashed-cyclist-steal-15-000-bike-jailed-walking-cafe-police-were.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990855/Boy-crashed-cyclist-steal-15-000-bike-jailed-walking-cafe-police-were.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 16:03:45+00:00

A 15-year-old boy who was part of a gang that stole Alex Richardson's one-of-a-kind £15,000 bike on October 7 2021 in Richmond Park, London, has been jailed.

## What is the Coronation Big Lunch for King Charles III?
 - [https://www.dailymail.co.uk/news/article-11990857/What-Coronation-Big-Lunch-King-Charles-III.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990857/What-Coronation-Big-Lunch-King-Charles-III.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 16:00:50+00:00

As the official coronation ceremony of King Charles III draws closer, preparations are well under way for the event. A Coronation Big Lunch will be held on 7 May to bring communities together.

## Man murdered at a plumber's warehouse before his body was burnt and dumped in woodland, court hears
 - [https://www.dailymail.co.uk/news/article-11990627/Man-murdered-plumbers-warehouse-body-burnt-dumped-woodland-court-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990627/Man-murdered-plumbers-warehouse-body-burnt-dumped-woodland-court-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 15:59:35+00:00

Mohammed Shah Subhani, 27, known as Little Man, was allegedly murdered when he visited R & J Plumbing in Hounslow in 2019 with his body later being burned and dumped in woods.

## Texas boy, 16, died suddenly at climbing wall, comes back to live after TWO HOURS of CPR
 - [https://www.dailymail.co.uk/news/article-11990519/Texas-boy-16-died-suddenly-climbing-wall-comes-live-TWO-HOURS-CPR.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990519/Texas-boy-16-died-suddenly-climbing-wall-comes-live-TWO-HOURS-CPR.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 15:53:05+00:00

A Texas teen suffered a cardiac arrest at a rock climbing gym and died - but miraculously two hours later he was revived after continuous CPR.

## Meta is set to lay off Facebook, Instagram, WhatsApp and Reality Labs workers TODAY
 - [https://www.dailymail.co.uk/news/article-11990543/Meta-set-lay-Facebook-Instagram-WhatsApp-Reality-Labs-workers-TODAY.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990543/Meta-set-lay-Facebook-Instagram-WhatsApp-Reality-Labs-workers-TODAY.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 15:51:25+00:00

The latest round of firings is part of a cost-cutting push announced by the CEO in March, which aims to eventually cull 10,000 jobs at the company.

## Kendall Roy's $29m three-story NYC penthouse from Succession hits the market
 - [https://www.dailymail.co.uk/news/article-11990549/Kendall-Roys-29m-three-story-NYC-penthouse-Succession-hits-market.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990549/Kendall-Roys-29m-three-story-NYC-penthouse-Succession-hits-market.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 15:45:04+00:00

The three-story Manhattan apartment, located at 180 E 88th Street, boasts five bedrooms and four bathrooms, but nothing beats the stunning skyline views as can be seen on the show.

## Suspected felons walk free in half of cases since Alvin Bragg took office - DOUBLE the rate in 2018
 - [https://www.dailymail.co.uk/news/article-11986217/Suspected-felons-walk-free-half-cases-Alvin-Bragg-took-office-DOUBLE-rate-2018.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11986217/Suspected-felons-walk-free-half-cases-Alvin-Bragg-took-office-DOUBLE-rate-2018.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 15:40:52+00:00

Manhattan DA Alvin Bragg (left) has asked for felony suspects to be held on bail in just half of cases this year, sparking fears more will be free to reoffend.

## Rishi Sunak turns up the heat on DUP in Belfast speech
 - [https://www.dailymail.co.uk/news/article-11990997/Rishi-Sunak-turns-heat-DUP-Belfast-speech.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990997/Rishi-Sunak-turns-heat-DUP-Belfast-speech.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 15:28:21+00:00

In a speech in Belfast to mark the 25th anniversary of the Good Friday Agreement, Rishi Sunak praised the 'courage and imagination' of those who negotiated the deal.

## Fox News still faces $2.7B defamation lawsuit from another voting machine firm
 - [https://www.dailymail.co.uk/news/article-11990691/Fox-News-faces-2-7B-defamation-lawsuit-voting-machine-firm.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990691/Fox-News-faces-2-7B-defamation-lawsuit-voting-machine-firm.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 15:28:13+00:00

Lawyers for the Rupert Murdoch-owned network are now gearing up for what could be an even more costly suit brought by Smartmatic which alleges Fox aired false claims about election rigging.

## Sperm Donation Australia: Brooke Withington talks about finding sperm donor on Facebook
 - [https://www.dailymail.co.uk/news/article-11989865/Sperm-Donation-Australia-Brooke-Withington-talks-finding-sperm-donor-Facebook.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989865/Sperm-Donation-Australia-Brooke-Withington-talks-finding-sperm-donor-Facebook.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 15:27:43+00:00

Brooke Withington, 28, was told by a friend about the Sperm Donation Australia Facebook group where hopeful mothers and willing donors informally meet up.

## Anti-vaxxer RFK to kick off his White House run with support of 14% of Biden voters
 - [https://www.dailymail.co.uk/news/article-11990737/Anti-vaxxer-RFK-kick-White-House-run-support-14-Biden-voters.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990737/Anti-vaxxer-RFK-kick-White-House-run-support-14-Biden-voters.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 15:27:35+00:00

Robert F. Kennedy Jr. kicks off his presidential campaign Wednesday with the support of 14 percent of President Joe Biden's voters, according to a USA TODAY/Suffolk University Poll .

## Boyfriend of Kaylin Gillis, 20, describes panic as gunman with fired on them with SHOTGUN
 - [https://www.dailymail.co.uk/news/article-11990355/Boyfriend-Kaylin-Gillis-20-describes-panic-gunman-fired-SHOTGUN.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990355/Boyfriend-Kaylin-Gillis-20-describes-panic-gunman-fired-SHOTGUN.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 15:26:21+00:00

Kaylin Gillis' boyfriend has spoken about the moment his girlfriend was shot dead by a homeowner in rural upstate New York on Saturday night after their group mistakenly went on to his property.

## Lady Pamela Hicks has not been invited to King Charles's coronation
 - [https://www.dailymail.co.uk/news/article-11990793/Lady-Pamela-Hicks-not-invited-King-Charless-coronation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990793/Lady-Pamela-Hicks-not-invited-King-Charless-coronation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 15:26:00+00:00

Lady Pamela Hicks - whose father, the 1st Earl Mountbatten of Burma was Prince Philip's uncle - attended the Queen's funeral at Westminster Abbey in a wheelchair last September.

## Two teenagers charged with reckless murder after shooting dead four people at a Sweet 16
 - [https://www.dailymail.co.uk/news/article-11990981/Two-teenagers-charged-reckless-murder-shooting-dead-four-people-Sweet-16.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990981/Two-teenagers-charged-reckless-murder-shooting-dead-four-people-Sweet-16.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 15:23:38+00:00

Travis McCullough, 16, and Ty Reik McCullough, 17, both from Tuskegee, have been charged with reckless murder after four people were shot dead last week.

## Mortgage rates climb to 6.43% - the biggest rise in two months - as home loan applications stall
 - [https://www.dailymail.co.uk/news/article-11990647/Mortgage-rates-climb-6-43-biggest-rise-two-months-home-loan-applications-stall.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990647/Mortgage-rates-climb-6-43-biggest-rise-two-months-home-loan-applications-stall.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 15:21:19+00:00

Mortgage rates have risen at their fastest pace in nearly two months as they climbed to 6.43 percent - wiping out demand for new properties.

## The Voice referendum: Everyday Indigenous Australians who will vote 'No'
 - [https://www.dailymail.co.uk/news/article-11990623/The-Voice-referendum-Everyday-Indigenous-Australians-vote-No.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990623/The-Voice-referendum-Everyday-Indigenous-Australians-vote-No.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 15:20:33+00:00

Australians will vote in the referendum between October and December - after Prime Minster Anthony Albanese revealed the wording of the proposal last month.

## British father-of-two relives ordeal of being hospitalised with 'food poisoning' at Tui hotel
 - [https://www.dailymail.co.uk/news/article-11990655/British-father-two-relives-ordeal-hospitalised-food-poisoning-Tui-hotel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990655/British-father-two-relives-ordeal-hospitalised-food-poisoning-Tui-hotel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 15:15:16+00:00

Mr Garnett, a site manager, is now among dozens of holidaymakers contemplating taking legal action against holiday firm TUI for the nightmare break at the Rixos Sungate hotel.

## Cost of living crisis, Centrelink: How young Australian students are surviving on Youth Allowance
 - [https://www.dailymail.co.uk/news/article-11987989/Cost-living-crisis-Centrelink-young-Australian-students-surviving-Youth-Allowance.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11987989/Cost-living-crisis-Centrelink-young-Australian-students-surviving-Youth-Allowance.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 15:09:36+00:00

Young Australians are being forced to choose between paying rent and feeding themselves as the nation's cost of living crisis continues, with peak bodies urging the government to step in.

## Yeppoon alleged car theft: Young mum opens up about terrifying ordeal after car taken with baby
 - [https://www.dailymail.co.uk/news/article-11990459/Yeppoon-alleged-car-theft-Young-mum-opens-terrifying-ordeal-car-taken-baby.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990459/Yeppoon-alleged-car-theft-Young-mum-opens-terrifying-ordeal-car-taken-baby.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 15:02:35+00:00

A young mother whose four-month-old baby was briefly stolen in an alleged carjacking has opened up about the 'horrific' experience.

## Photographer goes beyond the ring to reveal reality of pro-wrestling
 - [https://www.dailymail.co.uk/news/article-11990399/Photographer-goes-ring-reveal-reality-pro-wrestling.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990399/Photographer-goes-ring-reveal-reality-pro-wrestling.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 14:50:16+00:00

Iowa native Michael Watson left behind an enviable job as a music photographer after becoming 'burnt out,' and instead perused another lifelong interest: pro-wrestling.

## Great news for Wetherspoons fans: Pub chain will extend opening hours to mark Charles' coronation
 - [https://www.dailymail.co.uk/news/article-11990617/Great-news-Wetherspoons-fans-Pub-chain-extend-opening-hours-mark-Charles-coronation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990617/Great-news-Wetherspoons-fans-Pub-chain-extend-opening-hours-mark-Charles-coronation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 14:46:20+00:00

The hugely popular pub chain Wetherspoons will stay open for an extra hour on Sunday, 7 May to allow visitors to celebrate the coronation of King Charles III with an extra drink.

## Cellmate of baby rapist Jason Mizner to give evidence in his bid for special jail treatment
 - [https://www.dailymail.co.uk/news/article-11988419/Cellmate-baby-rapist-Jason-Mizner-evidence-bid-special-jail-treatment.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988419/Cellmate-baby-rapist-Jason-Mizner-evidence-bid-special-jail-treatment.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 14:36:55+00:00

A depraved baby rapist who filmed himself repeatedly sexually assaulting a two-year-old girl will have a cellmate give evidence in support of his claim he needs special jail privileges.

## Disney's 'bloodbath' layoffs are set to hit thousands of workers across every division in the US
 - [https://www.dailymail.co.uk/news/article-11990387/Disneys-bloodbath-layoffs-set-hit-thousands-workers-division-US.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990387/Disneys-bloodbath-layoffs-set-hit-thousands-workers-division-US.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 14:34:49+00:00

The Walt Disney Company is going to cut thousands of staff next week - including 15 percent of its entertainment division.

## Japanese man who bought £12,000 animal costume settles into his new life as a collie
 - [https://www.dailymail.co.uk/news/article-11990411/Japanese-man-bought-12-000-animal-costume-settles-new-life-collie.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990411/Japanese-man-bought-12-000-animal-costume-settles-new-life-collie.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 14:26:21+00:00

The man, who goes by the name Toco, spent two million Yen (around £12,000) on the ultra-realistic costume to fulfil his lifelong fantasy of becoming one of man's best friend.

## How saving $12 extra a week into your 401K could make you $85,492 richer in retirement
 - [https://www.dailymail.co.uk/news/article-11987389/How-saving-12-extra-week-401K-make-85-492-richer-retirement.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11987389/How-saving-12-extra-week-401K-make-85-492-richer-retirement.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 14:24:21+00:00

America is in the grips of a retirement crisis - but experts urge caution. Here we reveal how you can transform your 401K by upping your contributions by just 1 percent.

## Family of girl who was seen walking the Golden Gate Bridge before VANISHING offering $250k reward
 - [https://www.dailymail.co.uk/news/article-11990279/Family-girl-seen-walking-Golden-Gate-Bridge-VANISHING-offering-250k-reward.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990279/Family-girl-seen-walking-Golden-Gate-Bridge-VANISHING-offering-250k-reward.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 14:22:28+00:00

Sydney West, 19, of Chapel Hill, North Carolina, disappeared on September 30, 2020, to the confusion of her family, who she had spoken to the night before.

## Biden's approval rating at a dire 39% as he plans another attack on MAGA Republicans
 - [https://www.dailymail.co.uk/news/article-11990379/Bidens-approval-rating-dire-39-plans-attack-MAGA-Republicans.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990379/Bidens-approval-rating-dire-39-plans-attack-MAGA-Republicans.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 14:21:26+00:00

President Joe Biden on Wednesday will launch another attack on MAGA Republicans as he struggles to make a debt deal with Speaker Kevin McCarthy.

## Insulate Britain protester admits it was 's***' woman couldn't get to hospital as they blockaded M25
 - [https://www.dailymail.co.uk/news/article-11990339/Insulate-Britain-protester-admits-s-woman-hospital-blockaded-M25.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990339/Insulate-Britain-protester-admits-s-woman-hospital-blockaded-M25.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 14:14:35+00:00

Jury at Hove Crown Court  was told one distraught woman could not visit a dying 'loved one' in hospital as she pleaded to go through the blockade at Junction 3 Swanley on September 13 2021.

## Drinker who tried to murder a man by burying an axe in his head is jailed for 24 years
 - [https://www.dailymail.co.uk/news/article-11990327/Drinker-tried-murder-man-burying-axe-head-jailed-24-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990327/Drinker-tried-murder-man-burying-axe-head-jailed-24-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 14:09:12+00:00

David Perry, 40,  'took exception' to a group including married father-of-three Matthew Cutts as they 'joked and laughed about' at the Bell Hotel in Clare, Suffolk, on March 19, 2022.

## Rishi Sunak jibes at Keir Starmer over Welsh Government plans to give asylum seekers £1,600 a month
 - [https://www.dailymail.co.uk/news/article-11990389/Rishi-Sunak-jibes-Keir-Starmer-Welsh-Government-plans-asylum-seekers-1-600-month.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990389/Rishi-Sunak-jibes-Keir-Starmer-Welsh-Government-plans-asylum-seekers-1-600-month.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 13:44:35+00:00

The Prime Minister claimed he was 'stopping the boats' while 'Labour is paying for them' as he highlighted his pledge to end the Channel migrant crisis.

## TikTok influencer and her mother arrive at court to stand trial for double murder
 - [https://www.dailymail.co.uk/news/article-11990261/TikTok-influencer-mother-arrive-court-stand-trial-double-murder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990261/TikTok-influencer-mother-arrive-court-stand-trial-double-murder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 13:32:13+00:00

TikTok influencer Mahek Bukhari is pictured arriving at court today with her mother Ansreen Bukhari to stand trial for double murder.

## Reserve Bank of Australia set to undergo a major shake up
 - [https://www.dailymail.co.uk/news/article-11990383/Reserve-Bank-Australia-set-undergo-major-shake-up.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990383/Reserve-Bank-Australia-set-undergo-major-shake-up.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 13:27:06+00:00

The Reserve Bank is set to be split into two boards, with one solely focused on interest rates, in a major shake-up idea expected to be adopted by the government.

## Parking garage that caved in killing one was 'hazardous' with FOUR open building violations
 - [https://www.dailymail.co.uk/news/article-11989987/Parking-garage-caved-killing-one-hazardous-FOUR-open-building-violations.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989987/Parking-garage-caved-killing-one-hazardous-FOUR-open-building-violations.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 13:26:56+00:00

Officials have not yet named the victim who died in the incident, but a neighbor claimed it was the site's manager who was on his way home.

## Merseyside Police hit back at Animal Rebellion's claims over Grand National
 - [https://www.dailymail.co.uk/news/article-11990517/Merseyside-Police-hit-Animal-Rebellions-claims-Grand-National.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990517/Merseyside-Police-hit-Animal-Rebellions-claims-Grand-National.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 13:26:22+00:00

Protesters from XR offshoot Animal Rising, formerly named Animal Rebellion, attempted to cancel the races at Aintree but were halted by Merseyside Police officers and G4S security guards.

## Southwest passenger screams at parents of child that won't stop crying in epic tantrum
 - [https://www.dailymail.co.uk/news/article-11990325/Southwest-passenger-screams-parents-child-wont-stop-crying-epic-tantrum.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990325/Southwest-passenger-screams-parents-child-wont-stop-crying-epic-tantrum.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 13:25:36+00:00

The epic tantrum - thrown by the grown man - left Southwest passengers in hysterics as he screamed about the baby's crying for 45 minutes, before being apprehended by authorities at the airport.

## Dominion CEO says $787.5M Fox News settlement is a 'big step forward in democracy'
 - [https://www.dailymail.co.uk/news/article-11990287/Dominion-CEO-says-787-5M-Fox-News-settlement-big-step-forward-democracy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990287/Dominion-CEO-says-787-5M-Fox-News-settlement-big-step-forward-democracy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 13:25:32+00:00

John Poulos said it was important for the political system to 'send a signal that if media companies lie ... and they do so knowingly, they will be prepared to pay a very, very high price.'

## Australian woman Prakash Sharita Devi died in horror smash in Sri Lanka after taxi crashed off cliff
 - [https://www.dailymail.co.uk/news/article-11989745/Australian-woman-Prakash-Sharita-Devi-died-horror-smash-Sri-Lanka-taxi-crashed-cliff.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989745/Australian-woman-Prakash-Sharita-Devi-died-horror-smash-Sri-Lanka-taxi-crashed-cliff.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 13:24:53+00:00

An Australian woman has been killed and her daughter injured in a horror smash after a car they were travelling in plunged off a cliff in Sri Lanka.

## Two Iowa teenagers plead guilty to ambushing and beating their Spanish teacher to death
 - [https://www.dailymail.co.uk/news/article-11990335/Two-Iowa-teenagers-plead-guilty-ambushing-beating-Spanish-teacher-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990335/Two-Iowa-teenagers-plead-guilty-ambushing-beating-Spanish-teacher-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 13:22:18+00:00

Two teenagers pleaded guilty Tuesday to the killing of high school Spanish teacher Nohema Graber, whom they are accused of bludgeoning to death with a baseball bat.

## Russia is using 'ghost' spy ships off UK coast to map out North Sea wind farms for sabotage attacks
 - [https://www.dailymail.co.uk/news/article-11989871/Russia-using-ghost-spy-ships-UK-coast-map-North-Sea-wind-farms-sabotage-attacks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989871/Russia-using-ghost-spy-ships-UK-coast-map-North-Sea-wind-farms-sabotage-attacks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 13:21:19+00:00

Russian ships, disguised as fishing trawlers and research vessels, are sailing through the North Sea to collect data on where wind farms, gas pipelines and power cables are, it is claimed.

## IT consultant accused of murdering CashApp founder Bob Lee is on SUICIDE WATCH
 - [https://www.dailymail.co.uk/news/article-11990477/IT-consultant-accused-murdering-CashApp-founder-Bob-Lee-SUICIDE-WATCH.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990477/IT-consultant-accused-murdering-CashApp-founder-Bob-Lee-SUICIDE-WATCH.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 13:20:00+00:00

An IT consultant accused of stabbing CashApp founder Bob Lee to death in San Francisco is now on suicide watch in the city's jail, his lawyer said.

## Britain's biggest council fatcat who was paid £607,000 in a year
 - [https://www.dailymail.co.uk/news/article-11990165/Britains-biggest-council-fatcat-paid-607-000-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990165/Britains-biggest-council-fatcat-paid-607-000-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 13:18:13+00:00

EXCLUSIVE: James Whiteman, 57, received the huge sum after taking voluntary redundancy from Guildford Borough Council in Surrey, where he had been managing director, in 2021.

## Heat lovers enjoy 16C temperatures but showers are on the way as Met Office slams 40C summer claims
 - [https://www.dailymail.co.uk/news/article-11990197/Heat-lovers-enjoy-16C-temperatures-showers-way-Met-Office-slams-40C-summer-claims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990197/Heat-lovers-enjoy-16C-temperatures-showers-way-Met-Office-slams-40C-summer-claims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 13:16:14+00:00

Current warm temperatures will be replaced by 'increasingly unsettled and cooler' conditions from Friday 'with showers or longer spells of rain for many.'

## Villagers' fury as housing developer chops down 200ft long hedgerow in middle of nesting season
 - [https://www.dailymail.co.uk/news/article-11990141/Villagers-fury-housing-developer-chops-200ft-long-hedgerow-middle-nesting-season.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990141/Villagers-fury-housing-developer-chops-200ft-long-hedgerow-middle-nesting-season.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 13:15:09+00:00

Locals from Sawston, Cambridgeshire, have reacted with fury after housing developer Redrow razed a 200ft hedgerow almost to the ground citing 'safety' reasons

## Tradie binds and gags boss' wife, kidnaps his kids and demands $1million ransom
 - [https://www.dailymail.co.uk/news/article-11989699/Tradie-binds-gags-boss-wife-kidnaps-kids-demands-1million-ransom.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989699/Tradie-binds-gags-boss-wife-kidnaps-kids-demands-1million-ransom.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 13:14:38+00:00

Jiangang Ji, a construction worker, faced the first day of a trial in the County Court on Wednesday over charges including assault at a home in Melbourne's east in August 2021.

## Raunchy Texas 911 dispatcher has a history of sexting lovers
 - [https://www.dailymail.co.uk/news/article-11982597/Raunchy-Texas-911-dispatcher-history-sexting-lovers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11982597/Raunchy-Texas-911-dispatcher-history-sexting-lovers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 13:13:36+00:00

DailyMail.com can now reveal that dispatcher Krystle Perez has been dogged by cheating allegations since her previous marriage to San Antonio officer Todd Tackitt in 2012.

## Theatre director, 68, who broke her back before Agatha Christie sues for £3.2m
 - [https://www.dailymail.co.uk/news/article-11990103/Theatre-director-68-broke-Agatha-Christie-sues-3-2m.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990103/Theatre-director-68-broke-Agatha-Christie-sues-3-2m.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 13:13:27+00:00

Cheryl Palmer, 68, was preparing to direct a production of 'And Then There Were None' at the Archway Theatre, in Horley, Surrey, when she fell six feet into a tunnel used by stage staff.

## 'I made a massive error', says ultra-marathon runner disqualified for using a car
 - [https://www.dailymail.co.uk/news/article-11989925/I-massive-error-says-ultra-marathon-runner-disqualified-using-car.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989925/I-massive-error-says-ultra-marathon-runner-disqualified-using-car.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 13:12:19+00:00

Ultra-marathon runner Joasia Zakrzewski, 47, from Dumfries, who was disqualified from a race for riding in a car said she made a 'massive error' when she accepted medal

## Ron DeSantis heads to South Carolina as he loses more endorsements to Trump
 - [https://www.dailymail.co.uk/news/article-11990203/Ron-DeSantis-heads-South-Carolina-loses-endorsements-Trump.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990203/Ron-DeSantis-heads-South-Carolina-loses-endorsements-Trump.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 13:12:00+00:00

Ron DeSantis is making his first swing through South Carolina as he continues to lose the endorsement battle with Donald Trump despite a visit to the Capitol to meet with lawmakers Tuesday.

## Will Nicola Sturgeon be the next SNP grandee to be arrested by police probing party finances?
 - [https://www.dailymail.co.uk/news/article-11989767/Will-Nicola-Sturgeon-SNP-grandee-arrested-police-probing-party-finances.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989767/Will-Nicola-Sturgeon-SNP-grandee-arrested-police-probing-party-finances.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 13:11:54+00:00

Following the questioning of treasurer Colin Beattie yesterday and Ms Sturgeon's husband Peter Murrell, last week, sources believe it is 'inevitable' she will also be grilled by detectives.

## Father Bob Maguire's disturbing final post before his death is revealed
 - [https://www.dailymail.co.uk/news/article-11989743/Father-Bob-Maguires-disturbing-final-post-death-revealed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989743/Father-Bob-Maguires-disturbing-final-post-death-revealed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 13:10:50+00:00

Much-loved Catholic priest Father Bob Maguire claimed he was being 'ambushed by treacherous enemies' in his final post before his death.

## Tragedy as father-of-one Royal Marine sergeant dies in 165ft plunge in the Scottish Highlands
 - [https://www.dailymail.co.uk/news/article-11990109/Tragedy-father-one-Royal-Marine-sergeant-dies-165ft-plunge-Scottish-Highlands.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990109/Tragedy-father-one-Royal-Marine-sergeant-dies-165ft-plunge-Scottish-Highlands.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 13:09:36+00:00

Colour Sgt Richard Melia, 40, was with a climbing companion ascending Stob Dearg's Crowberry Ridge,  Buachaille Etive Mòr in Glencoe, Scotland when he slipped at around 11.15am on April 8, 2023.

## Fly-tippers use boltcutters to open site and dump tons of rubbish in quiet cul-de-sac
 - [https://www.dailymail.co.uk/news/article-11990157/Fly-tippers-use-boltcutters-open-site-dump-tons-rubbish-quiet-cul-sac.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990157/Fly-tippers-use-boltcutters-open-site-dump-tons-rubbish-quiet-cul-sac.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 13:04:19+00:00

Residents in New Southgate were left horrified after watching trucks packed sky-high with rubbish pull into the quiet street to dump their loads in less than four days.

## Mother weeps in court before trial of man, 55, accused of murdering Nikki Allan
 - [https://www.dailymail.co.uk/news/article-11990295/Mother-weeps-court-trial-man-55-accused-murdering-Nikki-Allan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990295/Mother-weeps-court-trial-man-55-accused-murdering-Nikki-Allan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 13:01:38+00:00

Sharon Henderson, 56, struggled to contain her emotions in court in Newcastle today as she faced the man accused of murdering her seven-year-old daughter 30 years ago.

## Pictured: Man hunted by police after man 'forced his way into toilet and raped 16-year-old'
 - [https://www.dailymail.co.uk/news/article-11990289/Pictured-Man-hunted-police-man-forced-way-toilet-raped-16-year-old.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990289/Pictured-Man-hunted-police-man-forced-way-toilet-raped-16-year-old.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 12:52:04+00:00

A man who is being hunted by police after a 16-year-old girl was raped in a nightclub toilet in Liverpool has been pictured, as police also search for a woman who helped the victim.

## London Marathon organisers urge spectators to watch race from home due to Extinction Rebellion plots
 - [https://www.dailymail.co.uk/news/article-11990181/London-Marathon-organisers-urge-spectators-watch-race-home-Extinction-Rebellion-plots.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990181/London-Marathon-organisers-urge-spectators-watch-race-home-Extinction-Rebellion-plots.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 12:48:04+00:00

The eco-mob is plotting a huge protest in the capital from Friday to Monday, as fears grow  as many as 30,000 supporters could be in the Westminster area for the 'final stretch' of the marathon on Sunday.

## Andrew Lester's grandson makes claim about Ralph Yarl shooting
 - [https://www.dailymail.co.uk/news/article-11989897/Andrew-Lesters-grandson-makes-claim-Ralph-Yarl-shooting.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989897/Andrew-Lesters-grandson-makes-claim-Ralph-Yarl-shooting.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 12:42:11+00:00

Andrew Lester, who was accused of shooting teenager Ralph Yarl (pictured), has been released on bail after handing himself in. He faces arraignment today.

## Revealed: Woman who died in sea during Storm Noa was 24-year-old space scientist
 - [https://www.dailymail.co.uk/news/article-11990145/Woman-died-sea-Storm-Noa-24-year-old-space-scientist.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990145/Woman-died-sea-Storm-Noa-24-year-old-space-scientist.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 12:36:40+00:00

Sai Tejaswi Kommareddy, 24, died at the Royal Sussex County Hospital, Brighton, after a huge emergency response was triggered following reports of a person in the water on April 11.

## Family's hope for justice as arrests are made over death of Brit at Polish strip club
 - [https://www.dailymail.co.uk/news/article-11990125/Familys-hope-justice-arrests-death-Brit-Polish-strip-club.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990125/Familys-hope-justice-arrests-death-Brit-Polish-strip-club.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 12:35:56+00:00

Mark Cocks, 36, died of alcohol poisoning in October 2017 after being plied with scores of shots at the Wild Night club in Krakow, leaving his parents Graham and Pat devastated.

## Dance troupe for pensioners banned from wearing Egyptian pharaoh outfits
 - [https://www.dailymail.co.uk/news/article-11990191/Dance-troupe-pensioners-banned-wearing-Egyptian-pharaoh-outfits.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990191/Dance-troupe-pensioners-banned-wearing-Egyptian-pharaoh-outfits.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 12:32:07+00:00

The group's performance 'world cruise on the dream ship' at today's garden show in Mannheim was planned with 14 costumes the women would change into during the show.

## Water company must throw away 160,000 litres of bottled water that was left in unsafe storage
 - [https://www.dailymail.co.uk/news/article-11990139/Water-company-throw-away-160-000-litres-bottled-water-left-unsafe-storage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990139/Water-company-throw-away-160-000-litres-bottled-water-left-unsafe-storage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 12:17:39+00:00

Bournemouth Water in Dorset is being forced to chuck thousands of litres of bottled water down the drain, as it is 'no longer suitable' for human consumption due to being left outside for too long.

## Masterchef winner's Mexican restaurant Wahaca ditches steak from its menu
 - [https://www.dailymail.co.uk/news/article-11990163/Masterchef-winners-Mexican-restaurant-Wahaca-ditches-steak-menu.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990163/Masterchef-winners-Mexican-restaurant-Wahaca-ditches-steak-menu.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 12:09:04+00:00

Wahaca, owned by Masterchef champion Thomasina Miers, 47, hopes to go as green as possible by ditching any dish that contains the red meat item.

## Prince Harry will skip King Charles's coronation concert, say sources
 - [https://www.dailymail.co.uk/news/article-11989953/Prince-Harry-skip-King-Charless-coronation-concert-say-sources.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989953/Prince-Harry-skip-King-Charless-coronation-concert-say-sources.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 12:07:16+00:00

It is now believed that Harry has told the King that he will not stay in Britain for the star-studded concert at Windsor Castle the following day - and will instead fly back to the US after the ceremony.

## Rishi Sunak brands Keir Starmer 'Sir Softy' in spicy Prime Minister's Questions clash
 - [https://www.dailymail.co.uk/news/article-11990155/Rishi-Sunak-brands-Keir-Starmer-Sir-Softy-spicy-Prime-Ministers-Questions-clash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990155/Rishi-Sunak-brands-Keir-Starmer-Sir-Softy-spicy-Prime-Ministers-Questions-clash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 12:04:49+00:00

They squared off in the Commons amid an ongoing furore over attack adverts targeting the PM personally, including accusing him of being weak on tackling sex attackers.

## Dominic Raab revealed to be paying for his own lawyers as he faces bullying probe
 - [https://www.dailymail.co.uk/news/article-11990221/Dominic-Raab-revealed-paying-lawyers-faces-bullying-probe.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990221/Dominic-Raab-revealed-paying-lawyers-faces-bullying-probe.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 11:55:04+00:00

The Deputy Prime Minister is continuing to be probed by top barrister Adam Tolley KC over his treatment of Whitehall officials.

## TfL plans to scrap the Day Travelcard - here's how it will affect you
 - [https://www.dailymail.co.uk/news/article-11989493/TfL-plans-scrap-Day-Travelcard-heres-affect-you.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989493/TfL-plans-scrap-Day-Travelcard-heres-affect-you.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 11:40:03+00:00

London Mayor Sadiq Khan wants to get rid of the paper Travelcards including those added onto National Rail tickets for those journeying into the capital from outside the Oyster zone.

## Alice in Wonderland creator Lewis Carroll's photos he took of young girl found in house clearance
 - [https://www.dailymail.co.uk/news/article-11989849/Alice-Wonderland-creator-Lewis-Carrolls-photos-took-young-girl-house-clearance.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989849/Alice-Wonderland-creator-Lewis-Carrolls-photos-took-young-girl-house-clearance.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 11:24:37+00:00

A bizarre set of never-before-seen images taken by Lewis Carroll have been unearthed during a house clearance in Essex, showing a girl - who was snapped by the author 50 times - in various outfits.

## Rishi Sunak FINALLY publishes new register of ministerial interests
 - [https://www.dailymail.co.uk/news/article-11990017/Rishi-Sunak-FINALLY-publishes-new-register-ministerial-interests.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11990017/Rishi-Sunak-FINALLY-publishes-new-register-ministerial-interests.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 11:23:37+00:00

The government has issued an update to the register for the first time since May last year, when Boris Johnson was premier

## Jailed Stephen Bear's revenge porn victim Georgia Harrison calls for better protections
 - [https://www.dailymail.co.uk/news/article-11989751/Jailed-Stephen-Bears-revenge-porn-victim-Georgia-Harrison-calls-better-protections.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989751/Jailed-Stephen-Bears-revenge-porn-victim-Georgia-Harrison-calls-better-protections.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 11:22:19+00:00

Reality TV star Georgia Harrison, who battled to get her ex jailed after he shared a video of them having sex, has urged peers debating the Online Safety Bill to 'completely and utterly change history'.

## Tragedy as aspiring doctor, 17, died after suffering allergic reaction to drug during tonsil surgery
 - [https://www.dailymail.co.uk/news/article-11989651/Tragedy-aspiring-doctor-17-died-suffering-allergic-reaction-drug-tonsil-surgery.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989651/Tragedy-aspiring-doctor-17-died-suffering-allergic-reaction-drug-tonsil-surgery.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 10:56:37+00:00

Alexandra Briess suffered an 'unpredictable' fatal anaphylactic reaction to Rocuronium after she was given the drug following a routine procedure to remove her tonsils with the NHS in Reading.

## 'ISIS-linked crooks beat British couple to death and fed their bodies to crocodiles in South Africa'
 - [https://www.dailymail.co.uk/news/article-11989955/ISIS-linked-crooks-beat-British-couple-death-fed-bodies-crocodiles-South-Africa.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989955/ISIS-linked-crooks-beat-British-couple-death-fed-bodies-crocodiles-South-Africa.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 10:56:11+00:00

World-renowned botanists Rod Saunders, 74, and wife Rachel, 63, were pounced upon as 'a good hunt' as they scoured a mountain region in South Africa for rare seeds for their business.

## Why is inflation still high? Will it make interest rates rise? Will it affect my mortgage?
 - [https://www.dailymail.co.uk/news/article-11989439/Why-inflation-high-make-rates-rise-affect-mortgage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989439/Why-inflation-high-make-rates-rise-affect-mortgage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 10:55:39+00:00

Struggling Brits are facing more financial pain after inflation defied predictions by staying in double-figures. And the news means interest rate in the UK could hit 5% by the autumn of 2023.

## Every Lidl helps! Discount supermarket wins High Court claim that Tesco ripped off its yellow logo
 - [https://www.dailymail.co.uk/news/article-11989911/Every-Lidl-helps-Discount-supermarket-wins-High-Court-claim-Tesco-ripped-yellow-logo.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989911/Every-Lidl-helps-Discount-supermarket-wins-High-Court-claim-Tesco-ripped-yellow-logo.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 10:55:29+00:00

Tesco's Clubcard scheme and Lidl's main logo feature a yellow circle and a blue background, leading the latter to accuse the former of infringing on their copyright and trademark

## One of Britain's last surviving D-Day veterans, Joe Cattini, dies aged 100
 - [https://www.dailymail.co.uk/news/article-11989939/One-Britains-surviving-D-Day-veterans-Joe-Cattini-dies-aged-100.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989939/One-Britains-surviving-D-Day-veterans-Joe-Cattini-dies-aged-100.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 10:55:26+00:00

The granddaughter of Joe Cattini, 100, announced in a statement that her 'beloved granddad' passed away on the evening of Tuesday 18 April. She wrote: 'A life so well lived.'

## Titanic survivor's letter describes earlier near miss that could have saved everyone if it had hit
 - [https://www.dailymail.co.uk/news/article-11989695/Titanic-survivors-letter-describes-earlier-near-miss-saved-hit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989695/Titanic-survivors-letter-describes-earlier-near-miss-saved-hit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 10:55:07+00:00

Had the Titanic and smaller passenger liner hit,  the Titanic's departure would have been delayed and it would never have struck the iceberg that caused her to sink.

## Coles mud cake is latest victim of inflation, with shoppers furious at massive price jump
 - [https://www.dailymail.co.uk/news/article-11989461/Coles-mud-cake-latest-victim-inflation-shoppers-furious-massive-price-jump.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989461/Coles-mud-cake-latest-victim-inflation-shoppers-furious-massive-price-jump.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 10:34:13+00:00

Australia's rampant inflation has claimed another victim, with the beloved Coles mud cake's price hiking by a massive 33 per cent in little over a year, outraging shoppers.

## Inside Britain's deepest pothole! 5ft crater has wrecked a BMW and sent a Deliveroo rider flying
 - [https://www.dailymail.co.uk/news/article-11989641/Inside-Britains-deepest-pothole-5ft-crater-wrecked-BMW-sent-Deliveroo-rider-flying.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989641/Inside-Britains-deepest-pothole-5ft-crater-wrecked-BMW-sent-Deliveroo-rider-flying.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 10:08:49+00:00

The pothole in Canning Town, London, became famous after a 41-year-old man was pictured inside the hole with only his head peeking out from the road.

## Queensland dog owners could be thrown in jail if their pet kills or injures someone
 - [https://www.dailymail.co.uk/news/article-11989159/Queensland-dog-owners-thrown-jail-pet-kills-injures-someone.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989159/Queensland-dog-owners-thrown-jail-pet-kills-injures-someone.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 10:01:57+00:00

On Wednesday, Queensland's Agriculture Minister Mark Furner convened an emergency meeting of the dangerous dog task force before confirming several new penalties for pet owners.

## Man stabbed to death after his car was rammed and he was attacked by 'number of people'
 - [https://www.dailymail.co.uk/news/article-11989525/Man-stabbed-death-car-rammed-attacked-number-people.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989525/Man-stabbed-death-car-rammed-attacked-number-people.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 10:00:04+00:00

A man was stabbed to death last night in Castle Bromwich, West Midlands, after a car he was in was rammed by another vehicle allowing a 'number of people' to attack him

## Ex-Formula One supremo Bernie Ecclestone arrives at court for £400million tax fraud trial
 - [https://www.dailymail.co.uk/news/article-11989559/Ex-Formula-One-supremo-Bernie-Ecclestone-arrives-court-400million-tax-fraud-trial.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989559/Ex-Formula-One-supremo-Bernie-Ecclestone-arrives-court-400million-tax-fraud-trial.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 09:58:04+00:00

The 92-year-old motor-racing tycoon is accused of falsely claiming he had only set up a single trust for his daughters in an alleged failure to declare overseas assets to the tax authorities.

## Lidia Thorpe blasts Anthony Albanese after the PM criticised her over strip club stoush
 - [https://www.dailymail.co.uk/news/article-11989653/Lidia-Thorpe-blasts-Anthony-Albanese-PM-criticised-strip-club-stoush.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989653/Lidia-Thorpe-blasts-Anthony-Albanese-PM-criticised-strip-club-stoush.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 09:56:57+00:00

Lidia Thorpe has hit back at Anthony Albanese's suggestions she needs to get 'some support', claiming his comments are 'insulting' and 'another day in the colony'.

## Snooker star whose game was halted by Just Stop Oil fanatic demands tougher jail terms for activists
 - [https://www.dailymail.co.uk/news/article-11988995/Snooker-star-game-halted-Just-Stop-Oil-fanatic-demands-tougher-jail-terms-activists.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988995/Snooker-star-game-halted-Just-Stop-Oil-fanatic-demands-tougher-jail-terms-activists.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 09:56:10+00:00

This year's Snooker World Championships were interrupted when a Just Stop Oil activist got on the table in the Rob Milkins against Joe Perry first-round match in Sheffield.

## Eco-protesters who tried to disrupt the Grand National claim police broke bones and set dogs on them
 - [https://www.dailymail.co.uk/news/article-11989203/Eco-protesters-tried-disrupt-Grand-National-claim-police-broke-bones-set-dogs-them.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989203/Eco-protesters-tried-disrupt-Grand-National-claim-police-broke-bones-set-dogs-them.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 09:55:31+00:00

Eco-zealots who tried to stop Saturday's Grand National at Aintree have accused police and G4S security of hurting them while they detained them outside the race perimeter.

## Seven people are arrested over death of British tourist who was forced to drink 22 shots
 - [https://www.dailymail.co.uk/news/article-11989511/Seven-people-arrested-killing-British-tourist-forcing-drink-22-shots.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989511/Seven-people-arrested-killing-British-tourist-forcing-drink-22-shots.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 09:54:40+00:00

Mark Cocks, from Yorkshire, died of alcohol poisoning in 2017 after being plied with scores of shots at the Wild Night club in Krakow.

## Two shameless yobs are caught dancing and laughing outside court
 - [https://www.dailymail.co.uk/news/article-11989217/Two-shameless-yobs-caught-dancing-laughing-outside-court.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989217/Two-shameless-yobs-caught-dancing-laughing-outside-court.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 09:53:18+00:00

Thugs Sophie Sutton, 32, and Jonathan Meredith, 33, laughed and danced outside a courthouse where they went on to appear over an attack on a policeman during a drunken late night scuffle.

## Workers will be given paid leave to support loved ones feeling suicidal under new laws in Spain
 - [https://www.dailymail.co.uk/news/article-11989585/Workers-given-paid-leave-support-loved-ones-feeling-suicidal-new-laws-Spain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989585/Workers-given-paid-leave-support-loved-ones-feeling-suicidal-new-laws-Spain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 09:51:05+00:00

A nominated individual will be signed off work by a doctor for up to two weeks to act as a companion for their struggling at-risk loved one, according to proposed plans by Spain's government.

## Dog attack survivor tells how two dogs came 'bounding' towards him before biting him four times
 - [https://www.dailymail.co.uk/news/article-11989429/Dog-attack-survivor-tells-two-dogs-came-bounding-biting-four-times.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989429/Dog-attack-survivor-tells-two-dogs-came-bounding-biting-four-times.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 09:50:42+00:00

Simon Edge has recalled the horror incident he was savaged by two dogs at Willow Gardens, Winson Green, Birmingham, yesterday afternoon around 2.30pm.

## Groom-to-be fighting for his life after being punched by stranger at his stag party
 - [https://www.dailymail.co.uk/news/article-11989575/Groom-fighting-life-punched-stranger-stag-party.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989575/Groom-fighting-life-punched-stranger-stag-party.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 09:49:42+00:00

Lee Burns, 41, was struck outside a bar in Poulton-le-Fylde, Blackpool, at around 1.15am on Sunday after returning from The Grand National at Aintree.

## Keir Starmer channels Tony Blair with warning the NHS 'won't survive' a Tory election victory
 - [https://www.dailymail.co.uk/news/article-11989599/Keir-Starmer-channels-Tony-Blair-warning-NHS-wont-survive-Tory-election-victory.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989599/Keir-Starmer-channels-Tony-Blair-warning-NHS-wont-survive-Tory-election-victory.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 09:49:39+00:00

The Labour leader claimed the health service was 'broken' and accused the Conservatives of overseeing a 'cycle of decline' during their 13 years in power.

## Megyn Kelly claps back after she's branded 'transphobic'
 - [https://www.dailymail.co.uk/news/article-11989467/Megyn-Kelly-claps-shes-branded-transphobic.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989467/Megyn-Kelly-claps-shes-branded-transphobic.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 09:48:36+00:00

In angry comments on Sirius XM's 'The Megyn Kelly Show,' the host had slammed the maker of Bud Light, telling it: 'Screw you and your stupid empty platitudes.'

## Child rapist who sparked national manhunt after fleeing jail still too dangerous to be released
 - [https://www.dailymail.co.uk/news/article-11989315/Child-rapist-sparked-national-manhunt-fleeing-jail-dangerous-released.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989315/Child-rapist-sparked-national-manhunt-fleeing-jail-dangerous-released.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 09:44:02+00:00

EXCLUSIVE Lee Cyrus is currently serving two life sentences. In October 2012, he sparked a nationwide manhunt after walking out of HMP North Sea Camp in Boston, Lincolnshire.

## Net Zero guru says he has switched from beef to VENISON to help save the planet
 - [https://www.dailymail.co.uk/news/article-11989589/Net-Zero-guru-says-switched-beef-VENISON-help-save-planet.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989589/Net-Zero-guru-says-switched-beef-VENISON-help-save-planet.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 09:43:38+00:00

Lord Adair Turner spoke about changing his own habits as he warned people must cut down on red meat to stop deforestation.

## English-speaking councillor living in Wales is suspended for replying to emails in German
 - [https://www.dailymail.co.uk/news/article-11989583/English-speaking-councillor-living-Wales-suspended-replying-emails-German.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989583/English-speaking-councillor-living-Wales-suspended-replying-emails-German.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 09:21:40+00:00

Louise Hughes was trying to be 'light-hearted' by replying to both emails in German - to highlight her frustration at being unable to understand the text in Welsh.

## Pregnant woman killed by teens who shot into her car in case of mistaken identity
 - [https://www.dailymail.co.uk/news/article-11989343/Pregnant-woman-killed-teens-shot-car-case-mistaken-identity.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989343/Pregnant-woman-killed-teens-shot-car-case-mistaken-identity.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 08:48:43+00:00

Kerisha Johnson (pictured) was shot on Sunday in Baton Rouge, Louisiana. Johnson, who was nine months pregnant and 'due to give birth within several days,' was found dead inside her car by officers.

## Unseen photos published to mark Warsaw Ghetto Uprising's 80th anniversary show Nazis' brutality
 - [https://www.dailymail.co.uk/news/article-11989107/Unseen-photos-published-mark-Warsaw-Ghetto-Uprisings-80th-anniversary-Nazis-brutality.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989107/Unseen-photos-published-mark-Warsaw-Ghetto-Uprisings-80th-anniversary-Nazis-brutality.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 08:44:14+00:00

The images were taken by Polish engineer Rudolf Damec, who hid a Jewish woman in his apartment in Warsaw as the Nazis crushed the Warsaw Ghetto Uprising, which began 80 years ago today.

## Bizarre moment British tourist clinging to a buoy two miles off the Thai coast flags down a boat
 - [https://www.dailymail.co.uk/news/article-11989301/Bizarre-moment-British-tourist-clinging-buoy-two-miles-Thai-coast-flags-boat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989301/Bizarre-moment-British-tourist-clinging-buoy-two-miles-Thai-coast-flags-boat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 08:43:06+00:00

Video shows the apparently intoxicated holidaymaker standing on the yellow float in his swimming shorts near the party city of Pattaya at around 7am on March 29.

## George Marrogi: Video shows Melbourne underworld killer chasing victim, as appeal bid fails
 - [https://www.dailymail.co.uk/news/article-11989175/George-Marrogi-Video-shows-Melbourne-underworld-killer-chasing-victim-appeal-bid-fails.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989175/George-Marrogi-Video-shows-Melbourne-underworld-killer-chasing-victim-appeal-bid-fails.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 08:34:57+00:00

Melbourne underworld figure George Marrogi will remain in prison for more than three decades after a bid to overturn his murder conviction was dismissed.

## Family's costly battle after interest rate mistake by their St George left them out of pocket
 - [https://www.dailymail.co.uk/news/article-11989149/Familys-costly-battle-rate-mistake-St-George-left-pocket.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989149/Familys-costly-battle-rate-mistake-St-George-left-pocket.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 08:24:02+00:00

A Brisbane family have been locked in a 'ridiculous' battle with their bank over a major interest mistake which saw them charged almost $20,000.

## Van driver who killed grandmother, 71, after taking speed to stop himself falling asleep jailed
 - [https://www.dailymail.co.uk/news/article-11989277/Van-driver-killed-grandmother-71-taking-speed-stop-falling-asleep-jailed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989277/Van-driver-killed-grandmother-71-taking-speed-stop-falling-asleep-jailed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 08:22:47+00:00

Marcin Szewczyk, 43, had been driving for almost 12 hours out of the previous 22-and-a half hours when he ploughed into the back of a car which had pulled up in heavy traffic on the M6 in Cheshire.

## 'Scar' spotted on Putin's neck heightens speculation over possible cancer treatment
 - [https://www.dailymail.co.uk/news/article-11989171/Scar-spotted-Putins-neck-heightens-speculation-possible-cancer-treatment.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989171/Scar-spotted-Putins-neck-heightens-speculation-possible-cancer-treatment.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 07:58:45+00:00

The 'scar' marking on Vladimir Putin's neck was seen as he clasped a candle at a midnight Orthodox Easter cathedral service in Moscow at the weekend.

## Osman Shaptafaj jailed over killing his daughter Lindita Musai and her husband Venton Musai
 - [https://www.dailymail.co.uk/news/article-11989235/Osman-Shaptafaj-jailed-killing-daughter-Lindita-Musai-husband-Venton-Musai.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989235/Osman-Shaptafaj-jailed-killing-daughter-Lindita-Musai-husband-Venton-Musai.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 07:56:33+00:00

The then-55-year-old Melbourne father had become enraged after learning his estranged daughter, Lindita Musai, 25, had married her husband Venton Musai, 29, a year earlier.

## 'Hit-and-run driver' caught on dash cam allegedly mowing down a cyclist to be charged
 - [https://www.dailymail.co.uk/news/article-11989177/Hit-run-driver-caught-dash-cam-allegedly-mowing-cyclist-charged.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989177/Hit-run-driver-caught-dash-cam-allegedly-mowing-cyclist-charged.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 07:56:05+00:00

A woman accused of mowing down a cyclist in a savage hit-and-run caught on camera to be hit with seven charges.

## Prince Harry appears via videolink at Invictus Games event in Germany
 - [https://www.dailymail.co.uk/news/article-11989089/Prince-Harry-appears-videolink-Invictus-Games-event-Germany.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989089/Prince-Harry-appears-videolink-Invictus-Games-event-Germany.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 07:55:26+00:00

The Duke of Sussex appeared in a video shown at an Invictus Games event in Berlin yesterday to mark 150 days until the competition begins in Düsseldorf in September.

## Elsa Pataky founded Purely Byron lost $3.6million since 2020 and was never profitable
 - [https://www.dailymail.co.uk/news/article-11988909/Elsa-Pataky-founded-Purely-Byron-lost-3-6million-2020-never-profitable.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988909/Elsa-Pataky-founded-Purely-Byron-lost-3-6million-2020-never-profitable.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 07:55:22+00:00

The report on Purely Byron, released on April 17, showed the company lost about $3.6million since it was founded in 2020 and was 'never profitable'.

## Mark McGowan's Andrew Hastie jibes caught on hot mic during China trip
 - [https://www.dailymail.co.uk/news/article-11988823/Mark-McGowans-Andrew-Hastie-jibes-caught-hot-mic-China-trip.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988823/Mark-McGowans-Andrew-Hastie-jibes-caught-hot-mic-China-trip.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 07:49:51+00:00

The WA Premier is seen chatting with Australian Ambassador to China, Graham Fletcher and China-Australia Chamber of Commerce chair, Vaughn Barber.

## From Dame Edna Everage to befriending the Royal Family: How Barry Humphries conquered the world
 - [https://www.dailymail.co.uk/news/article-11988265/From-Dame-Edna-Everage-befriending-Royal-Family-Barry-Humphries-conquered-world.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988265/From-Dame-Edna-Everage-befriending-Royal-Family-Barry-Humphries-conquered-world.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 07:47:35+00:00

Barry Humphries - comedian, stage actor, film producer, screenwriter, novelist, landscape painter, husband and father-of four - is much more than the creator of Dame Edna Everage.

## Goulburn sexual assault: CCTV captures final moments before woman attacked
 - [https://www.dailymail.co.uk/news/article-11989031/Goulburn-sexual-assault-CCTV-captures-final-moments-woman-attacked.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989031/Goulburn-sexual-assault-CCTV-captures-final-moments-woman-attacked.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 07:46:46+00:00

CCTV showing two ghostly figures could be the key to finding a sex attacker who brutally bashed a teenage girl until she was unconscious before raping her in the NSW town of Goulburn.

## Two children found unconscious rushed to hospital suffering an 'overdose' after consuming tablets
 - [https://www.dailymail.co.uk/news/article-11989167/Two-children-unconscious-rushed-hospital-suffering-overdose-consuming-tablets.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989167/Two-children-unconscious-rushed-hospital-suffering-overdose-consuming-tablets.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 07:46:18+00:00

A boy and a girl believed to be aged four and five, were found unconscious inside a house in Airds, Sydney's southwest and were transported to Westmead Children's Hospital for treatment.

## RAF develops unmanned mini-helicopter 'Jackal' drone which can fire laser-guided missiles
 - [https://www.dailymail.co.uk/news/article-11989295/RAF-develops-unmanned-mini-helicopter-Jackal-drone-fire-laser-guided-missiles.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989295/RAF-develops-unmanned-mini-helicopter-Jackal-drone-fire-laser-guided-missiles.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 07:44:34+00:00

British air chiefs had demanded a lightweight 'attack drone' after seeing the effectiveness of such technology in the Ukraine war.

## Buddhists protest over Dalai Lama joke at Lewis Spears' Melbourne comedy festival pub show
 - [https://www.dailymail.co.uk/news/article-11988685/Buddhists-protest-Dalai-Lama-joke-Lewis-Spears-Melbourne-comedy-festival-pub-show.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988685/Buddhists-protest-Dalai-Lama-joke-Lewis-Spears-Melbourne-comedy-festival-pub-show.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 06:56:12+00:00

The crowd of 150 men, women and children surrounded the entrance of the Rubber Chicken Comedy Pub in Melbourne on Tuesday where comedian Lewis Spears was taking to the stage

## Yeppoon alleged car theft: Woman caught driving car while four-month-old in backseat
 - [https://www.dailymail.co.uk/news/article-11988857/Yeppoon-alleged-car-theft-Woman-caught-driving-car-four-month-old-backseat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988857/Yeppoon-alleged-car-theft-Woman-caught-driving-car-four-month-old-backseat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 06:55:53+00:00

Police are on the hunt for a brazen thief who stole a family car from a shopping centre carpark in Queensland while a four-month-old baby girl was still strapped inside.

## Tragic last phone call between TOWIE restaurant bouncer and his wife before his death is revealed
 - [https://www.dailymail.co.uk/news/article-11989069/Tragic-phone-call-TOWIE-restaurant-bouncer-wife-death-revealed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11989069/Tragic-phone-call-TOWIE-restaurant-bouncer-wife-death-revealed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 06:50:44+00:00

Romina Acuna says she took the call from her Venezuelan-born husband Jose Rafael Pisani Pardo, 55, on Saturday evening just half an hour before he suffered devastating head injuries that killed him

## Father Bob's long-time triple j radio co-host John Safran reveals what he was REALLY like
 - [https://www.dailymail.co.uk/news/article-11988961/Father-Bobs-long-time-triple-j-radio-host-John-Safran-reveals-REALLY-like.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988961/Father-Bobs-long-time-triple-j-radio-host-John-Safran-reveals-REALLY-like.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 06:49:28+00:00

Father Bob's long-time radio co-host said 'Bob was wise as Buddha' and shared one of his mottos for life in a moving statement.

## Mother crushed at the Grand National says she could not leave area because eco-protesters stormed
 - [https://www.dailymail.co.uk/news/article-11988869/Mother-crushed-Grand-National-says-not-leave-area-eco-protesters-stormed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988869/Mother-crushed-Grand-National-says-not-leave-area-eco-protesters-stormed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 06:43:58+00:00

Jo Nagra, 44, from Birmingham, West Midlands, had been at Aintree Racecourse in Merseyside on Saturday 15 April with her husband Harj, 53, to celebrate his birthday.

## Steven Tougher's family visit tribute site after paramedic stabbed outside Campbelltown McDonald's
 - [https://www.dailymail.co.uk/news/article-11988803/Steven-Toughers-family-visit-tribute-site-paramedic-stabbed-outside-Campbelltown-McDonalds.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988803/Steven-Toughers-family-visit-tribute-site-paramedic-stabbed-outside-Campbelltown-McDonalds.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 06:37:59+00:00

The family of paramedic Steven Tougher who was killed in a McDonald's carpark have visited the site where he died for the first time as they call for Steven's law to be introduced.

## Tragic reason nursing student photographed slumped in the gutter at Randwick
 - [https://www.dailymail.co.uk/news/article-11988951/Tragic-reason-nursing-student-photographed-slumped-gutter-Randwick.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988951/Tragic-reason-nursing-student-photographed-slumped-gutter-Randwick.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 06:34:49+00:00

Mariam Deng, 20, was arrested by undercover cops while dropping drugs to a customer in Randwick, in Sydney's eastern suburbs, on December 9 last year.

## China may have up to six more illegal police stations in the US
 - [https://www.dailymail.co.uk/news/article-11988889/China-six-illegal-police-stations-US.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988889/China-six-illegal-police-stations-US.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 06:33:27+00:00

After the FBI arrested two men in connection with a Chinese 'secret police station' in New York, activists say there may be as many as six other similar illegal outposts across the US.

## Porter Davis Homes Group owes $33million to Commonwealth Bank
 - [https://www.dailymail.co.uk/news/article-11988709/Porter-Davis-Homes-Group-owes-33million-Commonwealth-Bank.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988709/Porter-Davis-Homes-Group-owes-33million-Commonwealth-Bank.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 06:29:00+00:00

Liquidators have found Porter Davis Homes Group, formerly one of Australia's biggest home builders, owes an astonishing amount to banks.

## Aldi shopper is left shocked after she makes a disgusting find in her groceries
 - [https://www.dailymail.co.uk/news/article-11988437/Aldi-shopper-left-shocked-makes-disgusting-groceries.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988437/Aldi-shopper-left-shocked-makes-disgusting-groceries.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 06:26:07+00:00

A shopper out for some dip gave one stores concoction an 'avo-nope' after opening the lid and finding a disgusting blob inside.

## Penthouse on Tiffany's building in Palm Beach sells for a staggering $18M
 - [https://www.dailymail.co.uk/news/article-11988907/Penthouse-Tiffanys-building-Palm-Beach-sells-staggering-18M.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988907/Penthouse-Tiffanys-building-Palm-Beach-sells-staggering-18M.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 06:05:34+00:00

An unfinished penthouse on top of the Tiffany's building in Palm Beach, Fla., has sold for $18 million just five months after it was originally listed for $24 million.

## Victorian Premier Daniel Andrews slammed by corruption watchdog
 - [https://www.dailymail.co.uk/news/article-11988415/Victorian-Premier-Daniel-Andrews-slammed-corruption-watchdog.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988415/Victorian-Premier-Daniel-Andrews-slammed-corruption-watchdog.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 05:58:11+00:00

The Victorian Premier has responded to the corruption probe shortly after IBAC's 'educational' report was handed

## Chicago couple battered by violent mob condemn 'random' attack - as state senator DEFENDS rioters
 - [https://www.dailymail.co.uk/news/article-11988761/Chicago-couple-battered-violent-mob-condemn-random-attack-state-senator-DEFENDS-rioters.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988761/Chicago-couple-battered-violent-mob-condemn-random-attack-state-senator-DEFENDS-rioters.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 05:56:15+00:00

Despite chaotic scenes over the weekend in Chicago that led a young couple to be attacked alongside two shootings and 15 arrests, state senator Robert Peters defended the rioters.

## China positions high-altitude spy drone that travels 'at least three times the speed of sound'
 - [https://www.dailymail.co.uk/news/article-11988843/China-positions-high-altitude-spy-drone-travels-three-times-speed-sound.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988843/China-positions-high-altitude-spy-drone-travels-three-times-speed-sound.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 05:55:56+00:00

China has positioned two WZ-8 rocket-propelled reconnaissance drones at an air base in eastern China, about 350 miles inland from Shanghai, according to a leaked Pentagon document.

## 'Chinese police car' spotted in NSW after one is seen in Melbourne
 - [https://www.dailymail.co.uk/news/article-11988649/Chinese-police-car-spotted-NSW-one-seen-Melbourne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988649/Chinese-police-car-spotted-NSW-one-seen-Melbourne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 05:51:54+00:00

Another 'Chinese police car' has been spotted in Australia, with the symbols and markings of a law enforcement vehicle from China, but some eagle-eyed Twitter users said it also sported a toy logo.

## How much Covid PCR test clinics cost as they are shut down across NSW
 - [https://www.dailymail.co.uk/news/article-11988953/How-Covid-PCR-test-clinics-cost-shut-NSW.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988953/How-Covid-PCR-test-clinics-cost-shut-NSW.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 05:51:40+00:00

Newly elected NSW premier Chris Minns swiftly moved to scrap the 165 clinics less than 48 hours after Daily Mail Australia revealed how underused they were.

## Ex-CBI boss Tony Danker insists his reputation has been 'totally trashed' by sex misconduct claims
 - [https://www.dailymail.co.uk/news/article-11988847/Ex-CBI-boss-Tony-Danker-insists-reputation-totally-trashed-sex-misconduct-claims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988847/Ex-CBI-boss-Tony-Danker-insists-reputation-totally-trashed-sex-misconduct-claims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 05:44:23+00:00

The board of the CBI said Mr Danker's conduct 'fell short' of what was expected of him and said there had been 'serious failings' in how it acted as an organisation.

## You weren't allowed to know about 'Witness J' -  inside the most 'secret' court case in Australia
 - [https://www.dailymail.co.uk/news/article-11988835/You-werent-allowed-know-Witness-J-inside-secret-court-case-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988835/You-werent-allowed-know-Witness-J-inside-secret-court-case-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 05:40:46+00:00

Just what a judge said when a former Australian intelligence officer was jailed three years ago - in a court case cloaked in an unprecedented level of secrecy - has finally been revealed.

## Britain's biggest council fatcats who made MORE than £100,000 last year revealed
 - [https://www.dailymail.co.uk/news/article-11988959/Britains-biggest-council-fatcats-100-000-year-revealed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988959/Britains-biggest-council-fatcats-100-000-year-revealed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 05:40:23+00:00

Research by the TaxPayers' Alliance reveals that dozens of employees are paid six-figure sums a year in council buildings where desks are empty as staff are still allowed to WFH.

## Yusuf Nazlioglu: Man accused of murder allegedly escaped on an e-scooter
 - [https://www.dailymail.co.uk/news/article-11988811/Yusuf-Nazlioglu-Man-accused-murder-allegedly-escaped-e-scooter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988811/Yusuf-Nazlioglu-Man-accused-murder-allegedly-escaped-e-scooter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 05:39:19+00:00

A man charged over the execution-style murder of former Lone Wolf bikie Yusuf Nazlioglu in Sydney's west allegedly used e-scooters to cover his tracks.

## Sydney Secondary College Balmain and Leichhardt campuses broken into with hundreds of animals killed
 - [https://www.dailymail.co.uk/news/article-11988355/Sydney-Secondary-College-Balmain-Leichhardt-campuses-broken-hundreds-animals-killed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988355/Sydney-Secondary-College-Balmain-Leichhardt-campuses-broken-hundreds-animals-killed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 05:38:30+00:00

Police are investigating a school break-in after three teenagers broke into the building and killed hundreds of animals in the marine lab.

## Southwest Airlines blames firewall failure for nationwide grounding
 - [https://www.dailymail.co.uk/news/article-11988741/Southwest-Airlines-blames-firewall-failure-nationwide-grounding.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988741/Southwest-Airlines-blames-firewall-failure-nationwide-grounding.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 05:29:51+00:00

Southwest Airlines took another reputational hit on Tuesday, after technical issues forced the company to briefly ground all flights nationwide, leading to more than 2,400 delayed flights.

## Kaylin Gillis' parents say they are 'lost' after 'senseless' death of 20-year-old daughter
 - [https://www.dailymail.co.uk/news/article-11988683/Kaylin-Gillis-parents-say-lost-senseless-death-20-year-old-daughter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988683/Kaylin-Gillis-parents-say-lost-senseless-death-20-year-old-daughter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 05:21:46+00:00

The parents of Kaylin Gillis, 20, who fatally shot after the car she was in drove into the wrong driveway, say they are 'lost' and 'devastated' by their daughter's 'senseless' death.

## Aussie basketballer Andrew Bogut slams Oakleigh Library Melbourne for drag-queen story-time
 - [https://www.dailymail.co.uk/news/article-11983995/Aussie-basketballer-Andrew-Bogut-slams-Oakleigh-Library-Melbourne-drag-queen-story-time.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11983995/Aussie-basketballer-Andrew-Bogut-slams-Oakleigh-Library-Melbourne-drag-queen-story-time.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 05:07:49+00:00

The triple Australian Olympian weighed into an upcoming story-time event to be held at Oakleigh Library in Melbourne's south-east hosted by drag queen performer Sam B.

## Australia post head office jobs axed by July to try and modernise amid downturn in revenue
 - [https://www.dailymail.co.uk/news/article-11988465/Australia-post-head-office-jobs-axed-July-try-modernise-amid-downturn-revenue.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988465/Australia-post-head-office-jobs-axed-July-try-modernise-amid-downturn-revenue.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 04:57:45+00:00

A total of about 400 head office jobs will be cut - some of which have already been announced - by the postal service by the end of this  financial year in an attempt to streamline.

## Brooke and Ollie Carter reveal 11-week old Hugo's ATRT brain cancer diagnosis and brutal fight
 - [https://www.dailymail.co.uk/news/article-11987973/Brooke-Ollie-Carter-reveal-11-week-old-Hugos-ATRT-brain-cancer-diagnosis-brutal-fight.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11987973/Brooke-Ollie-Carter-reveal-11-week-old-Hugos-ATRT-brain-cancer-diagnosis-brutal-fight.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 04:56:31+00:00

A couple has revealed how a routine check-up on their baby led to a mammoth battle with an aggressive cancer where he was put through months of chemo and now their hope lies in an experimental drug.

## 'Lone gunman,' 34, killed four people inside Maine home before opening fire on nearby highway
 - [https://www.dailymail.co.uk/news/article-11988801/Lone-gunman-34-killed-four-people-inside-Maine-home-opening-fire-nearby-highway.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988801/Lone-gunman-34-killed-four-people-inside-Maine-home-opening-fire-nearby-highway.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 04:55:44+00:00

Joseph Eaton, 34, pictured left, was arrested hours after allegedly killing four people in a home before shooting three others on a nearby interstate shortly afterward.

## Riley Gaines claims Megan Rapinoe would have STABBED a trans woman if they took her spot in the team
 - [https://www.dailymail.co.uk/news/article-11988589/Riley-Gaines-claims-Megan-Rapinoe-STABBED-trans-woman-took-spot-team.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988589/Riley-Gaines-claims-Megan-Rapinoe-STABBED-trans-woman-took-spot-team.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 04:44:49+00:00

Riley Gaines, who swam for the University of Kentucky against Lia Thomas and now campaigns against trans women in sport, attacked Megan Rapinoe for saying it was not an issue.

## Salim Mehajer says allegations he punched a woman and threatened her mother are bizarre and lies
 - [https://www.dailymail.co.uk/news/article-11988663/Salim-Mehajer-says-allegations-punched-woman-threatened-mother-bizarre-lies.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988663/Salim-Mehajer-says-allegations-punched-woman-threatened-mother-bizarre-lies.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 04:32:16+00:00

Salim Mehajer (pictured) has rubbished claims he punched a woman and threatened to put a bullet in her mother's head in court, labelling the allegations bizarre and lies.

## ABC under fire for lack of coverage over Lidia Thorpe's vile outburst outside Melbourne strip club
 - [https://www.dailymail.co.uk/news/article-11988261/ABC-fire-lack-coverage-Lidia-Thorpes-vile-outburst-outside-Melbourne-strip-club.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988261/ABC-fire-lack-coverage-Lidia-Thorpes-vile-outburst-outside-Melbourne-strip-club.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 03:51:43+00:00

Australia's national broadcaster is under fire for its lack of coverage of Senator Lidia Thorpe after she was filmed screaming vile insults at patrons outside a strip club in Melbourne.

## Brisbane train driver uses a broom to remove a python snake from the tracks at Roma St station
 - [https://www.dailymail.co.uk/news/article-11988343/Brisbane-train-driver-uses-broom-remove-python-snake-tracks-Roma-St-station.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988343/Brisbane-train-driver-uses-broom-remove-python-snake-tracks-Roma-St-station.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 03:37:42+00:00

The train driver was caught on film kneeling on a platform at Roma Street station in Brisbane's CBD before gingerly hoisting the 2.3metre python away with the broom on Monday.

## Terrifying footage reveals the moment a Manhattan parking garage collapses in on itself
 - [https://www.dailymail.co.uk/news/article-11988491/Terrifying-footage-reveals-moment-Manhattan-parking-garage-collapses-itself.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988491/Terrifying-footage-reveals-moment-Manhattan-parking-garage-collapses-itself.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 03:30:59+00:00

Shocking surveillance video revealed how vehicles on the lower level of a Manhattan parking garage were crushed after the upper floor caved in and vehicles fell through the broken concrete.

## Sex worker Clayton Palmer fights to stay in Australia after giving client HIV
 - [https://www.dailymail.co.uk/news/article-11988477/Sex-worker-Clayton-Palmer-fights-stay-Australia-giving-client-HIV.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988477/Sex-worker-Clayton-Palmer-fights-stay-Australia-giving-client-HIV.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 03:09:23+00:00

A transgender sex worker who was jailed for infecting a client with HIV is fighting to stop being permanently deported to New Zealand.

## Norfolk Southern CEO apologizes for East Palestine derailment
 - [https://www.dailymail.co.uk/news/article-11988541/Norfolk-Southern-CEO-apologizes-East-Palestine-derailment.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988541/Norfolk-Southern-CEO-apologizes-East-Palestine-derailment.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 03:06:58+00:00

CEO Alan Shaw testified on Tuesday before an Ohio Senate rail safety panel, where he faced wide-ranging questions about the derailment and subsequent controlled chemical burn.

## Beloved Catholic priest Father Bob Maguire dies aged 88: Tributes pour in for much-loved priest
 - [https://www.dailymail.co.uk/news/article-11988583/Beloved-Catholic-priest-Father-Bob-Maguire-dies-aged-88-Tributes-pour-loved-priest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988583/Beloved-Catholic-priest-Father-Bob-Maguire-dies-aged-88-Tributes-pour-loved-priest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 02:55:12+00:00

Father Bob Maguire has died aged 88, his foundation has confirmed.

## Ally's last laugh: Langdon's ACA win
 - [https://www.dailymail.co.uk/news/article-11914041/Allys-laugh-Langdons-ACA-win.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11914041/Allys-laugh-Langdons-ACA-win.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 02:50:49+00:00

It was the gig that didn't come easily for Ali Langdon.

## Netflix cuts DVD-rental business 25 years after it launched the company
 - [https://www.dailymail.co.uk/news/article-11988397/Netflix-cuts-DVD-rental-business-25-years-launched-company.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988397/Netflix-cuts-DVD-rental-business-25-years-launched-company.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 02:46:53+00:00

After 25 years, Netflix is saying goodbye to the feature that made it famous: the mailed DVD-rental service that once had 20 million subscribers receiving physical copies of TV shows and movies.

## Perth mother-of-two Emmerick Lasakar allegedly stabbed to death with partner investigated
 - [https://www.dailymail.co.uk/news/article-11988533/Perth-mother-two-Emmerick-Lasakar-allegedly-stabbed-death-partner-investigated.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988533/Perth-mother-two-Emmerick-Lasakar-allegedly-stabbed-death-partner-investigated.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 02:45:39+00:00

Mother-of-two Emmerick Lasakar, 35, died in Royal Perth Hospital on Monday night after being found with multiple injuries at her home on Knutsford Avenue in Kewdale.

## Sunrise host Natalie Barr's brutal question to Candice Warner about 'toilet tryst'
 - [https://www.dailymail.co.uk/news/article-11987991/Sunrise-host-Natalie-Barrs-question-Candice-Warner-toilet-tryst.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11987991/Sunrise-host-Natalie-Barrs-question-Candice-Warner-toilet-tryst.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 02:44:14+00:00

Speaking to Sunrise on Wednesday morning doing publicity rounds for her memoir, Ms Warner stated the media attention on the incident was due to women not having a 'voice' at the time.

## Florida man who shot road rage rival's daughter has attempted murder charge DROPPED
 - [https://www.dailymail.co.uk/news/article-11988395/Florida-man-shot-road-rage-rivals-daughter-attempted-murder-charge-DROPPED.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988395/Florida-man-shot-road-rage-rivals-daughter-attempted-murder-charge-DROPPED.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 02:42:30+00:00

Frank Allison, right, has seen attempted murder charges against him dropped after he shot the daughter of William Hale, left, in a road rage incident last year, where Allison's daughter was also shot.

## Commonwealth Bank quietly slashes its fixed mortgage rates by 40 basis points
 - [https://www.dailymail.co.uk/news/article-11988299/Commonwealth-Bank-quietly-slashes-fixed-mortgage-rates-40-basis-points.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988299/Commonwealth-Bank-quietly-slashes-fixed-mortgage-rates-40-basis-points.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 02:28:56+00:00

The Commonwealth Bank, Australia's biggest home lender, has slashed its three-year fixed rate by 0.4 percentage points to 5.59 per cent. This is a sign the banks are expecting rate cuts in 2023.

## Albanese Treasurer Jim Chalmers warns Centrelink JobSeeker payments are unlikely to get boost
 - [https://www.dailymail.co.uk/news/article-11988139/Albanese-Treasurer-Jim-Chalmers-warns-Centrelink-JobSeeker-payments-unlikely-boost.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988139/Albanese-Treasurer-Jim-Chalmers-warns-Centrelink-JobSeeker-payments-unlikely-boost.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 02:26:02+00:00

Despite his ministerial colleague Bill Shorten admitting he couldn't live on the meagre amount JobSeeker gives to the unemployed Treasurer Jim Chalmers has batted away cries for an increase.

## Australian rental crisis: Geelong dad living with his family in caravan in his parents' from yard
 - [https://www.dailymail.co.uk/news/article-11987365/Australian-rental-crisis-Geelong-dad-living-family-caravan-parents-yard.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11987365/Australian-rental-crisis-Geelong-dad-living-family-caravan-parents-yard.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 02:24:13+00:00

The father-of-two from Geelong spends every spare moment applying for rentals while juggling family commitments and commuting to Melbourne for work.

## Ring doorbell captures moment armed robber impersonating a delivery driver pulls gun on homeowner
 - [https://www.dailymail.co.uk/news/article-11988211/Ring-doorbell-captures-moment-armed-robber-impersonating-delivery-driver-pulls-gun-homeowner.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988211/Ring-doorbell-captures-moment-armed-robber-impersonating-delivery-driver-pulls-gun-homeowner.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 01:55:25+00:00

Xavier Otero, 37, was caught on a Ring camera attempting to rob a homeowner in East Haven on Friday morning. His accomplice Jean Carrasquillo-Torres, 26, has also been charged.

## Star Casino to slash 500 jobs and freeze on salaries
 - [https://www.dailymail.co.uk/news/article-11988385/Star-Casino-slash-500-jobs-freeze-salaries.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988385/Star-Casino-slash-500-jobs-freeze-salaries.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 01:55:17+00:00

Star Casino is set to slash 500 jobs and freeze salaries following an $80million plunge in its revenues, which the group blames on tighter gaming regulations and decreased consumer spending.

## Candice Warner opens up on tryst with Sonny Bill Williams at the Clovelly Hotel Sydney in 2007
 - [https://www.dailymail.co.uk/news/article-11987991/Candice-Warner-opens-tryst-Sonny-Bill-Williams-Clovelly-Hotel-Sydney-2007.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11987991/Candice-Warner-opens-tryst-Sonny-Bill-Williams-Clovelly-Hotel-Sydney-2007.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 01:54:30+00:00

Speaking to Sunrise on Wednesday morning doing publicity rounds for her memoir, Ms Warner stated the media attention on the incident was due to women not having a 'voice' at the time.

## Danny Lim is rushed to hospital after security guard confronted sandwich board icon in Barangaroo
 - [https://www.dailymail.co.uk/news/article-11988305/Danny-Lim-rushed-hospital-security-guard-confronted-sandwich-board-icon-Barangaroo.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988305/Danny-Lim-rushed-hospital-security-guard-confronted-sandwich-board-icon-Barangaroo.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 01:54:26+00:00

Danny Lim, who is famous for travelling around Sydney wearing sandwich boards with peaceful political slogans, became distressed when he was approached by a security officer on Wednesday.

## Netflix delays its password-sharing crackdown as it ends DVD-by-mail service for good
 - [https://www.dailymail.co.uk/news/article-11988209/Netflix-delays-password-sharing-crackdown-ends-DVD-mail-service-good.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988209/Netflix-delays-password-sharing-crackdown-ends-DVD-mail-service-good.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 01:39:54+00:00

Netflix has delayed its long-touted crackdown on password sharing, and will permanently shutter the DVD-mail-service that originally defined the company when it launched about 25 years ago.

## Horror home of Austrian rapist Josef Fritzl is split into flats and rented out to young people
 - [https://www.dailymail.co.uk/news/article-11988353/Horror-home-Austrian-rapist-Josef-Fritzl-split-flats-rented-young-people.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988353/Horror-home-Austrian-rapist-Josef-Fritzl-split-flats-rented-young-people.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 01:35:01+00:00

Austrian sex beast Josef Fritzl trapped and raped his 18-year-old daughter, Elisabeth, in his basement dungeon after drugging her with a rag soaked in ether.

## Sophie Delezio - Australia survived gruesome crash - getting married to high school sweetheart
 - [https://www.dailymail.co.uk/news/article-11988031/Sophie-Delezio-Australia-survived-gruesome-crash-getting-married-high-school-sweetheart.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988031/Sophie-Delezio-Australia-survived-gruesome-crash-getting-married-high-school-sweetheart.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 01:31:28+00:00

A miracle survivor announced  her engagement to her high school sweetheart and 'best friend'.

## Australian town auctioning off 16 properties for as little as $5000
 - [https://www.dailymail.co.uk/news/article-11987741/Australian-town-auctioning-16-properties-little-5000.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11987741/Australian-town-auctioning-16-properties-little-5000.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 01:28:53+00:00

Sixteen properties in varying states of condition will go under the hammer in the famous outback opal mining town 850km north of Adelaide next month

## Sydney mum, 67, tragically killed and daughter injured after taxi plunges off cliff in Sri Lanka
 - [https://www.dailymail.co.uk/news/article-11988001/Sydney-mum-67-tragically-killed-daughter-injured-taxi-plunges-cliff-Sri-Lanka.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988001/Sydney-mum-67-tragically-killed-daughter-injured-taxi-plunges-cliff-Sri-Lanka.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 01:21:32+00:00

An Australian mum has tragically died and her daughter injured after the hire taxi they were in plunged off a cliff while travelling through a village in Sri Lanka.

## GCHQ boss Jeremy Fleming warns of potential 'explosion' in fake news from AI developments
 - [https://www.dailymail.co.uk/news/article-11988335/GCHQ-boss-Jeremy-Fleming-warns-potential-explosion-fake-news-AI-developments.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988335/GCHQ-boss-Jeremy-Fleming-warns-potential-explosion-fake-news-AI-developments.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 01:15:36+00:00

GCHQ boss Sir Jeremy Fleming (pictured) said emerging AI technology created a number of 'potential applications and risks' for Britain, as it invests in becoming a science superpower

## Keir Starmer pledges to bring back NHS targets introduced by Tony Blair's government
 - [https://www.dailymail.co.uk/news/article-11988387/Keir-Starmer-pledges-bring-NHS-targets-introduced-Tony-Blairs-government.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988387/Keir-Starmer-pledges-bring-NHS-targets-introduced-Tony-Blairs-government.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 01:13:40+00:00

Keir Starmer said Labour would put ambulance response and A&amp;E waiting times at the centre of its healthcare policy if it wins the next general election.

## Neighbour shames dog walker who let the animal poo on lawns in Malpas Street Preston in Melbourne
 - [https://www.dailymail.co.uk/news/article-11987941/Neighbour-shames-dog-walker-let-animal-poo-lawns-Malpas-Street-Preston-Melbourne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11987941/Neighbour-shames-dog-walker-let-animal-poo-lawns-Malpas-Street-Preston-Melbourne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 01:01:49+00:00

The resident pasted up a large colour photo of the man and the dog onto a  pole with a doggie bag  underneath to get the message across in Malpas Street, Preston in Melbourne's north.

## Daniel Andrews' government staff pressured health officials, anti-corruption investigation reveals
 - [https://www.dailymail.co.uk/news/article-11988293/Daniel-Andrews-government-staff-pressured-health-officials-anti-corruption-investigation-reveals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988293/Daniel-Andrews-government-staff-pressured-health-officials-anti-corruption-investigation-reveals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 00:55:26+00:00

The Independent Broad-based Anti-corruption Commission released its Operation Daintree report after investigating the awarding of the contract in the lead-up to the 2018 Victorian state election.

## Kent police only had five staff to deal with an Insulate Britain M25 protest in 2021, court hears
 - [https://www.dailymail.co.uk/news/article-11988313/Kent-police-five-staff-deal-Insulate-Britain-M25-protest-2021-court-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988313/Kent-police-five-staff-deal-Insulate-Britain-M25-protest-2021-court-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 00:52:48+00:00

Insulate Britain organised protests in late 2021, blocking roads around the UK in an effort to pressure the government to make significant legislative changes that would lower nationwide emissions.

## Type 2 diabetes really can be REVERSED by losing weight: Effects last five years, trial confirms
 - [https://www.dailymail.co.uk/health/article-11986747/Type-2-diabetes-really-REVERSED-losing-weight-Effects-five-years-trial-confirms.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-11986747/Type-2-diabetes-really-REVERSED-losing-weight-Effects-five-years-trial-confirms.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 00:50:16+00:00

Almost a quarter of people in remission from type 2 diabetes two years after starting a low-calorie soup and shake diet were still free of the condition three years later.

## Yusuf Nazlioglu, Rhodes shooting: Man charged with the murder of lone wolf bikie
 - [https://www.dailymail.co.uk/news/article-11988357/Yusuf-Nazlioglu-Rhodes-shooting-Man-charged-murder-lone-wolf-bikie.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988357/Yusuf-Nazlioglu-Rhodes-shooting-Man-charged-murder-lone-wolf-bikie.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 00:50:08+00:00

A man has been charged with murder over the execution shooting of bikie Yusuf Nazlioglu in front of his wife in his apartment block carpark.

## White homeowner, 84, is RELEASED on $200k bail charged with shooting black 16-year-old Ralph Yarl
 - [https://www.dailymail.co.uk/news/article-11988351/White-homeowner-84-RELEASED-200k-bail-charged-shooting-black-16-year-old-Ralph-Yarl.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988351/White-homeowner-84-RELEASED-200k-bail-charged-shooting-black-16-year-old-Ralph-Yarl.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 00:50:01+00:00

Andrew Lester, 84, was released on bail on Tuesday night following the shooting last week in Kansas City of Ralph Yarl, a 16-year-old boy who mistakenly knocked on his door.

## Economists blame UK's double-digit inflation spiral on the Bank of England's money-printing spree
 - [https://www.dailymail.co.uk/news/article-11988329/Economists-blame-UKs-double-digit-inflation-spiral-Bank-Englands-money-printing-spree.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988329/Economists-blame-UKs-double-digit-inflation-spiral-Bank-Englands-money-printing-spree.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 00:46:39+00:00

The Bank pumped £450billion into the economy to help steer Britain through the pandemic but experts told MPs that helped to create the price spiral that it is now battling contain.

## Courtney Mills: DJ and OnlyFans star asks fans for donations after falling down stairs in Bali
 - [https://www.dailymail.co.uk/news/article-11987711/Courtney-Mills-DJ-OnlyFans-star-asks-fans-donations-falling-stairs-Bali.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11987711/Courtney-Mills-DJ-OnlyFans-star-asks-fans-donations-falling-stairs-Bali.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 00:46:19+00:00

DJ and OnlyFans star Courtney Mills was concussed after suffering a 'terrible' fall down stairs in Bali with a GoFundMe page now asking fans for donations that could 'potentially save her life'.

## Former Tory ministers brand Government's upcoming corporation tax rise a 'historic mistake'
 - [https://www.dailymail.co.uk/news/article-11988295/Former-Tory-ministers-brand-Governments-upcoming-corporation-tax-rise-historic-mistake.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988295/Former-Tory-ministers-brand-Governments-upcoming-corporation-tax-rise-historic-mistake.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 00:45:14+00:00

Jacob Rees-Mogg, who briefly held the post of business secretary under Liz Truss, branded the tax rise the 'most damaging' part of Chancellor Jeremy Hunt's Budget.

## Anthony Albanese shares message for Lidia Thorpe after her strip-club meltdown in Melbourne
 - [https://www.dailymail.co.uk/news/article-11988035/Anthony-Albanese-shares-message-Lidia-Thorpe-strip-club-meltdown-Melbourne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988035/Anthony-Albanese-shares-message-Lidia-Thorpe-strip-club-meltdown-Melbourne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 00:43:53+00:00

Prime Minister Anthony Albanese has urged Senator Lidia Thorpe to 'get some support' in the wake of her explosive strip club meltdown.

## Fury over Met's 'assault on freedom of expression' as officers arrest French protester in London
 - [https://www.dailymail.co.uk/news/article-11988275/Fury-Mets-assault-freedom-expression-officers-arrest-French-protester-London.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988275/Fury-Mets-assault-freedom-expression-officers-arrest-French-protester-London.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 00:42:46+00:00

Ernest Moret, the foreign rights manager for Éditions La Fabrique in Paris, was stopped by ports officers and questioned for six hours when he arrived at St Pancras Station on Monday.

## Rishi Sunak to pledge to 'give everything' to preserve the legacy of the Good Friday Agreement
 - [https://www.dailymail.co.uk/news/article-11988223/Rishi-Sunak-pledge-preserve-legacy-Good-Friday-Agreement.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988223/Rishi-Sunak-pledge-preserve-legacy-Good-Friday-Agreement.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 00:42:16+00:00

In a speech in Belfast to mark the 25th anniversary of the peace pact, the Prime Minister will praise the 'courage, imagination and perseverance' of those who negotiated the deal.

## Strong women are the raison d'etre of the Women's Institute
 - [https://www.dailymail.co.uk/debate/article-11987807/Strong-women-raison-detre-Womens-Institute.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/debate/article-11987807/Strong-women-raison-detre-Womens-Institute.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 00:37:47+00:00

The WI's Keynsham branch had invited me to give a talk about my long and varied career as a writer.

## The Crown will end with Charles and Camilla's wedding after criticism over re-enacting Diana crash
 - [https://www.dailymail.co.uk/tvshowbiz/article-11988127/The-Crown-end-Charles-Camillas-wedding-criticism-enacting-Diana-crash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-11988127/The-Crown-end-Charles-Camillas-wedding-criticism-enacting-Diana-crash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 00:34:29+00:00

The streaming giant has come under scrutiny for remaking the Paris car crash that killed Diana, and the funeral that took place afterwards.

## Colin Beattie SNP: The globetrotting international banker arrested and released without charge
 - [https://www.dailymail.co.uk/news/article-11988229/Colin-Beattie-SNP-globetrotting-international-banker-arrested-released-without-charge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988229/Colin-Beattie-SNP-globetrotting-international-banker-arrested-released-without-charge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 00:31:40+00:00

(Pictured left) He has served twice as the party's national treasurer, with his first stint in 2004. It only ended in 2020 when he lost out to Dunfermline and West Fife MP Douglas Chapman in a ballot.

## Rebekah Vardy hits back after Wagatha Christie legal battle as she trademarks phrase to 'cash in'
 - [https://www.dailymail.co.uk/tvshowbiz/article-11988009/Rebekah-Vardy-hits-Wagatha-Christie-legal-battle-trademarks-phrase-cash-in.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-11988009/Rebekah-Vardy-hits-Wagatha-Christie-legal-battle-trademarks-phrase-cash-in.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 00:31:36+00:00

The media personality, 42, took Coleen Rooney to High Court for libel - and lost - after Coleen claimed that Rebekah's social media account was leaking stories about her to the Press.

## EPHRAIM HARDCASTLE: David Dimbleby might heave sigh of relief after being excluded from Coronation
 - [https://www.dailymail.co.uk/debate/article-11988171/EPHRAIM-HARDCASTLE-David-Dimbleby-heave-sigh-relief-excluded-Coronation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/debate/article-11988171/EPHRAIM-HARDCASTLE-David-Dimbleby-heave-sigh-relief-excluded-Coronation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 00:27:34+00:00

EPHRAIM HARDCASTLE: Having been assured of involvement, official dithering means final decisions on the processional route are still to be made.

## Conclusion of probe into Dominic Raab's conduct will be handed to Rishi Sunak within days
 - [https://www.dailymail.co.uk/news/article-11988203/Conclusion-probe-Dominic-Raabs-conduct-handed-Rishi-Sunak-days.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988203/Conclusion-probe-Dominic-Raabs-conduct-handed-Rishi-Sunak-days.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 00:26:06+00:00

Mr Raab is facing a string of historic complaints from officials, who claim they felt bullied by his overbearing manner. He has said he will stand down if the investigation upholds the allegations.

## NYC gay club robbery 'ringleader' arrested and indicted
 - [https://www.dailymail.co.uk/news/article-11987871/NYC-gay-club-robbery-ringleader-arrested-indicted.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11987871/NYC-gay-club-robbery-ringleader-arrested-indicted.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 00:25:52+00:00

The man who is suspected to be the ringleader of a group who carried out a series of druggings and robberies at NYC  gay bars has been arrested and arraigned on murder and conspiracy charges.

## Six-year-old boy who faced never being able to walk or talk again takes his first steps
 - [https://www.dailymail.co.uk/news/article-11988193/Six-year-old-boy-faced-never-able-walk-talk-takes-steps.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988193/Six-year-old-boy-faced-never-able-walk-talk-takes-steps.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 00:22:07+00:00

Reggie Aslin, who is now 6, was born with hypoplastic left heart syndrome, meaning he only has half a heart due to complications with his blood flow.

## Australian businessman Damien Carew arrested over alleged attempted murder of his wife near Monaco
 - [https://www.dailymail.co.uk/news/article-11988033/Australian-businessman-Damien-Carew-arrested-alleged-attempted-murder-wife-near-Monaco.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988033/Australian-businessman-Damien-Carew-arrested-alleged-attempted-murder-wife-near-Monaco.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 00:19:12+00:00

Damien Carew had been living with Anna Polianskaya-Carew and their two children at a rented villa in La Turbie, near the wealthy city-state of Monaco on the French Riviera.

## NSW Central Coast bus driver praises student Brock Keena for checking in after racial attack
 - [https://www.dailymail.co.uk/news/article-11987765/NSW-Central-Coast-bus-driver-praises-student-Brock-Keena-checking-racial-attack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11987765/NSW-Central-Coast-bus-driver-praises-student-Brock-Keena-checking-racial-attack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 00:18:01+00:00

NSW Central Coast bus driver Sanjay Patel has applauded 11-year-old student Brock Keena for checking he was alright following a racial attack.

## Three are fighting for life and another is injured after man launches stabbing attack at German gym
 - [https://www.dailymail.co.uk/news/article-11988177/Three-fighting-life-injured-man-launches-stabbing-attack-German-gym.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988177/Three-fighting-life-injured-man-launches-stabbing-attack-German-gym.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 00:17:11+00:00

Three people were in life-threatening condition, and one person was less severely injured following the attack in Duisburg. No arrests were announced, and officers claim they are seeking one suspect.

## Former software developer created 'national security risk' taking top secret data home, court hears
 - [https://www.dailymail.co.uk/news/article-11988189/Former-software-developer-created-national-security-risk-taking-secret-data-home-court-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11988189/Former-software-developer-created-national-security-risk-taking-secret-data-home-court-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 00:13:31+00:00

Prosecutors allege that before leaving his job on 24 August, 23-year-old Hasaan Arshad took his work mobile phone into a top secret area and connected the device to a top secret work station.

## Barry Humphries rushed to hospital after major health setback
 - [https://www.dailymail.co.uk/tvshowbiz/article-11987769/Barry-Humphries-rushed-hospital-major-health-setback-Dame-Edna.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-11987769/Barry-Humphries-rushed-hospital-major-health-setback-Dame-Edna.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-19 00:11:07+00:00

Iconic Australian comedian Barry Humphries, 89, has been rushed to hospital just days after being discharged.

