# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## 'I had a feeling we would see them' - Man City eye Real revenge
 - [https://www.bbc.co.uk/sport/football/65331833?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65331833?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 22:52:50+00:00

Can Manchester City get revenge against Real Madrid in the Champions League semi-finals, a year after their heartbreak against the Spanish side?

## Chris Mason: Raab bullying inquiry nears judgement day
 - [https://www.bbc.co.uk/news/uk-politics-65331277?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-65331277?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 22:23:37+00:00

Rishi Sunak's deputy is braced for the outcome of a report that could seal his political fate.

## Two Texas cheerleaders shot after getting into wrong car
 - [https://www.bbc.co.uk/news/world-us-canada-65330696?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-65330696?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 21:54:02+00:00

It follows a string of recent shootings apparently sparked by someone showing up at the wrong place.

## Eurovision 2023: Alesha Dixon, Hannah Waddingham and Julia Sanina's responsibility to Ukraine
 - [https://www.bbc.co.uk/news/entertainment-arts-65331587?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-65331587?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 21:49:51+00:00

The presenters say it's "so much more than a competition", as Liverpool hosts on behalf of Ukraine.

## Mystery white flash lights up skies over Kyiv
 - [https://www.bbc.co.uk/news/world-europe-65328794?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-65328794?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 21:29:35+00:00

Videos from four angles shows the flash in Ukraine's capital - although it's not known what caused it.

## Tiger Woods: 15-time major champion undergoes 'successful' ankle surgery after withdrawing from Masters
 - [https://www.bbc.co.uk/sport/golf/65330817?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/golf/65330817?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 21:24:27+00:00

Tiger Woods undergoes "successful" ankle fusion surgery following his recent withdrawal from the Masters.

## KitKat maker Nestle urged to cut unhealthy food sales
 - [https://www.bbc.co.uk/news/business-65328763?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-65328763?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 21:19:00+00:00

An activist shareholder group is calling on the food company to 'play its part' in global health.

## WSL highlights: Alessia Russo scores as Manchester United claim key win over Arsenal
 - [https://www.bbc.co.uk/sport/av/football/65331168?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/65331168?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 21:15:08+00:00

Watch highlights as Alessia Russo scores for Manchester United as they earn an important 1-0 win over Arsenal in the Women's Super League title race.

## Bayern Munich 1-1 Manchester City (agg 1-4): Haaland books Champions League semi spot
 - [https://www.bbc.co.uk/sport/football/65317810?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65317810?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 21:13:55+00:00

Manchester City set up a Champions League semi-final clash with holders Real Madrid as Erling Haaland's goal ends Bayern Munich's hopes.

## Migration bill: Tories say Rishi Sunak will toughen deportation powers
 - [https://www.bbc.co.uk/news/uk-politics-65331272?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-65331272?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 20:41:09+00:00

The bill is expected to be changed to make it harder for European judges to stop deportations.

## Manchester United 1-0 Arsenal: United go four points clear at top of Women's Super League
 - [https://www.bbc.co.uk/sport/football/65247474?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65247474?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 20:15:36+00:00

Manchester United beat Arsenal to go four points clear in the Women's Super League in a game overshadowed by an injury to England captain Leah Williamson.

## IPL 2023: Lucknow Super Giants beat Rajasthan Royals by 10 runs
 - [https://www.bbc.co.uk/sport/cricket/65330675?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/65330675?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 18:32:53+00:00

Avesh Khan defends 18 in the final over as Lucknow Super Giants beat Rajasthan Royals in the Indian Premier League.

## Is VAR working better than some pundits, fans and players think in the Premier League?
 - [https://www.bbc.co.uk/sport/football/65320917?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65320917?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 18:09:24+00:00

Every week brings more controversy around the Video Assistant Referee (VAR) system, but is it actually working better than some fans, players and pundits think?

## Charlottesville torch marchers face criminal charges six years later
 - [https://www.bbc.co.uk/news/world-us-canada-65307774?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-65307774?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 17:54:30+00:00

Nearly six years after the notorious far-right rally, three torch-bearers have been indicted.

## Heathrow security staff and passport workers announce May strikes
 - [https://www.bbc.co.uk/news/uk-65329441?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-65329441?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 17:46:52+00:00

It comes amid a wave of industrial action by hundreds of thousands of workers in different sectors.

## Tyre Nichols' family sues Memphis Police Department
 - [https://www.bbc.co.uk/news/world-us-canada-65328965?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-65328965?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 17:18:05+00:00

Mr Nichols died after being brutally beaten by police during a traffic stop in January.

## Megan Thee Stallion says she fell into depression after shooting
 - [https://www.bbc.co.uk/news/entertainment-arts-65324379?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-65324379?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 17:03:25+00:00

The Grammy Award-winning rapper says her trauma was "treated like a running joke" on social media.

## Dominic Raab pays own legal fees for bullying probe
 - [https://www.bbc.co.uk/news/uk-politics-65327753?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-65327753?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 17:02:47+00:00

Downing Street is being asked why taxpayers are footing the bill for Boris Johnson's legal team.

## Good Friday Agreement: Get Stormont up and running, Sunak tells unionists
 - [https://www.bbc.co.uk/news/uk-northern-ireland-65312954?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-northern-ireland-65312954?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 17:02:16+00:00

The prime minister praises the Good Friday Agreement's legacy during a speech in Belfast.

## Warsaw Ghetto Uprising: German president draws Putin-Nazi parallels
 - [https://www.bbc.co.uk/news/world-europe-65326738?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-65326738?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 16:46:17+00:00

Frank-Walter Steinmeier regrets Nazi crimes in the Warsaw Ghetto, and condemns Russia's war on Ukraine.

## Egyptians complain over Netflix depiction of Cleopatra as black
 - [https://www.bbc.co.uk/news/world-middle-east-65322821?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-65322821?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 16:45:47+00:00

A lawyer files a suit against Netflix, saying its docudrama aims to "distort the Egyptian identity".

## Ralph Yarl: GoFundMe for teenager shot in Kansas City tops $3.2m
 - [https://www.bbc.co.uk/news/world-us-canada-65327890?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-65327890?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 16:40:15+00:00

Andrew Lester, 84, is accused of shooting the teenager after he mistakenly rang the wrong doorbell.

## Herpes deaths: Doctor did not think rash was due to virus, inquest hears
 - [https://www.bbc.co.uk/news/uk-england-kent-65328632?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-kent-65328632?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 16:28:55+00:00

Kimberly Sampson and Samantha Mulcahy died from herpes infections six weeks apart, an inquest hears.

## Barry Humphries: Dame Edna Everage star in hospital for 'health issues'
 - [https://www.bbc.co.uk/news/entertainment-arts-65320731?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-65320731?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 16:28:14+00:00

Known for his comic character Dame Edna Everage, he reportedly had complications after hip surgery.

## London Marathon 2023: Organisers receive 'unique' assurances over planned protests
 - [https://www.bbc.co.uk/sport/athletics/65326353?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/athletics/65326353?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 16:20:26+00:00

London Marathon organisers have been given "unique" assurances by Extinction Rebellion over Sunday's planned protest.

## Colin Beattie resigns as SNP treasurer after arrest
 - [https://www.bbc.co.uk/news/uk-scotland-65327953?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-65327953?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 16:19:20+00:00

He said he would also be stepping back from his role on the public audit committee.

## Rupert Murdoch: Will he be damaged by the Fox News and Dominion case?
 - [https://www.bbc.co.uk/news/entertainment-arts-65324382?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-65324382?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 16:13:34+00:00

Truth took a back seat on the mogul's US network, which must now pay the price, Katie Razzall says.

## Dide: Who is the masked Premier League rapper?
 - [https://www.bbc.co.uk/news/newsbeat-65322327?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-65322327?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 16:03:32+00:00

Everyone is guessing who the mystery artist might be so Newsbeat asked some experts for help.

## Teenagers charged with murder over Alabama shooting
 - [https://www.bbc.co.uk/news/world-us-canada-65328736?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-65328736?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 15:21:53+00:00

Two teenage boys charged with murder after shooting at 16th birthday party in Alabama that killed four and injured 32

## Gwent Police: Nine officers investigated over offensive messages
 - [https://www.bbc.co.uk/news/uk-wales-65324637?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-65324637?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 15:09:36+00:00

An investigation was launched after offensive messages were found on a retired officer's phone.

## Cause of grey hair may be 'stuck' cells, say scientists
 - [https://www.bbc.co.uk/news/health-65309374?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-65309374?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 15:07:05+00:00

As people age, pigment-making cells lose their ability to mature and maintain hair colour, research suggests.

## Dyscalculia: Do Rishi Sunak's maths plans add up for everyone?
 - [https://www.bbc.co.uk/news/uk-65303368?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-65303368?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 15:02:19+00:00

Some people with dyscalculia say Rishi Sunak’s plans for maths to 18 would have held them back.

## Women’s Six Nations 2023: Tournament cannot continue in this guise, says Simon Middleton
 - [https://www.bbc.co.uk/sport/rugby-union/65326791?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/65326791?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 14:09:25+00:00

England head coach Simon Middleton calls for change to avoid the Women's Six Nations always being decided between the Red Roses and France.

## Police sergeant David Stansbury in court charged with rape on duty
 - [https://www.bbc.co.uk/news/uk-england-devon-65325460?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-devon-65325460?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 13:57:33+00:00

Sgt David Stansbury faces three counts of raping a woman while on duty in Plymouth.

## Sudan conflict: 'We're expecting to get shot at any time,' doctor says
 - [https://www.bbc.co.uk/news/world-africa-65324718?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-65324718?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 13:52:59+00:00

A Sudanese doctor tells the BBC he fears for his life treating patients at a Khartoum hospital.

## Italian outcry over Lollobrigida 'ethnic replacement' remarks
 - [https://www.bbc.co.uk/news/world-europe-65324319?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-65324319?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 13:51:34+00:00

In a speech about birth rates, the agriculture minister uses a phrase linked to white supremacists.

## Milenko Maric: Man extradited from UK over alleged war crimes
 - [https://www.bbc.co.uk/news/uk-england-derbyshire-65323629?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-derbyshire-65323629?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 13:40:00+00:00

Milenko Maric, who was living in Derby, has been extradited to Croatia, police say.

## Sudan conflict: Residents flee capital Khartoum as fighting continues
 - [https://www.bbc.co.uk/news/world-africa-65325382?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-65325382?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 13:21:23+00:00

Thousands of civilians have fled the capital Khartoum as foreign nations prepare evacuation missions.

## Premier League parachute payments gap 'a major concern' says EFL
 - [https://www.bbc.co.uk/sport/football/65323385?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65323385?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 13:18:15+00:00

A widening gap between clubs receiving parachute payments and the rest of the Championship is a "major concern", English Football League chief Rick Parry says.

## Women's Six Nations 2023: Key players return in much-changed England side
 - [https://www.bbc.co.uk/sport/rugby-union/65323587?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/65323587?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 13:15:42+00:00

England scrum-half Natasha Hunt, wing Claudia MacDonald and back Helena Rowland are included for Saturday's Women's Six Nations trip to Ireland.

## Men admit removing man's body parts including penis
 - [https://www.bbc.co.uk/news/uk-england-london-65323609?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-65323609?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 12:59:59+00:00

The man whose body parts were removed is accused of broadcasting castrations on a website.

## Jonny Bairstow says request to keep wicket for Yorkshire is a 'non-story'
 - [https://www.bbc.co.uk/sport/cricket/65325342?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/65325342?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 12:56:02+00:00

Jonny Bairstow says his request to keep wicket for Yorkshire on his return from injury is a "non-story".

## Lidl wins logo lawsuit against Tesco
 - [https://www.bbc.co.uk/news/business-65322972?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-65322972?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 12:34:04+00:00

The High Court finds Tesco copied Lidl's logo for its Clubcard customer discount scheme.

## Rishi Sunak declares wife's shares after financial interests row
 - [https://www.bbc.co.uk/news/uk-politics-65324307?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-65324307?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 12:17:04+00:00

The prime minister has faced questions over Akshata Murty's shares in a firm that could benefit from the Budget.

## London Marathon 2023: Radio 1's Adele Roberts targets world record following 'second chance' after cancer
 - [https://www.bbc.co.uk/sport/athletics/65309940?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/athletics/65309940?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 12:01:12+00:00

Radio 1 presenter and DJ Adele Roberts is targeting a world record at the London Marathon as she aims to make the most of her "second chance at life" after cancer.

## World Snooker Championship: Kyren Wilson makes 147 maximum break against Ryan Day
 - [https://www.bbc.co.uk/sport/av/snooker/65325801?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/snooker/65325801?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 12:00:19+00:00

Watch as Kyren Wilson makes a 147 maximum break during his first-round match against Ryan Day at the World Snooker Championship.

## PrettyLittleThing Eid shop: Young Muslims criticise fashion brand
 - [https://www.bbc.co.uk/news/newsbeat-65269127?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-65269127?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 11:47:00+00:00

Young Muslims say the brand have missed the mark with their edit of clothes meant to celebrate the end of Ramadan.

## Rebekah Vardy trademarks the phrase Wagatha Christie
 - [https://www.bbc.co.uk/news/entertainment-arts-65320724?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-65320724?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 11:40:22+00:00

She had to pay substantial legal costs after losing her High Court libel case against Coleen Rooney.

## Doctor's death due to AstraZeneca Covid vaccine reaction - inquest
 - [https://www.bbc.co.uk/news/uk-england-london-65321937?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-65321937?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 10:47:27+00:00

The coroner at Stephen Wright's inquest described it as a "very unusual and deeply tragic case".

## Overdraft changes saved borrowers £1bn, says watchdog
 - [https://www.bbc.co.uk/news/business-65322915?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-65322915?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 10:46:44+00:00

Simpler overdraft rates have helped borrowers but some still miss out on support, the FCA says.

## More ambulance workers to strike after early May bank holiday
 - [https://www.bbc.co.uk/news/health-65323143?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-65323143?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 10:30:43+00:00

Unite union announces industrial action across the south of England and West Midlands.

## Chelsea: Didier Drogba says he does not recognise his former club
 - [https://www.bbc.co.uk/sport/football/65320642?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65320642?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 10:25:11+00:00

Former Chelsea striker Didier Drogba says he does not "recognise the club" as their poor season continues with defeat by Real Madrid in the Champions League.

## Joasia Zakrzewski: Ultrarunner who used car says it was a massive error
 - [https://www.bbc.co.uk/news/uk-scotland-65322631?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-65322631?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 10:10:31+00:00

Joasia Zakrzewski said her actions were not malicious and she made a massive error accepting a trophy.

## India population to surpass China by mid-2023 - UN
 - [https://www.bbc.co.uk/news/world-asia-india-65320690?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-india-65320690?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 09:59:35+00:00

India is expected to have 2.9 million more people than its neighbour by mid-2023, according to UN data.

## Ellis Genge: England and Bristol prop given three-week ban for dangerous tackle
 - [https://www.bbc.co.uk/sport/rugby-union/65323407?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/65323407?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 09:52:31+00:00

England prop Ellis Genge is banned for three weeks for a dangerous tackle on Tom Curry during Bristol's defeat by Sale.

## People perch on aircon units as hospital burns
 - [https://www.bbc.co.uk/news/world-asia-china-65323119?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-china-65323119?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 09:23:04+00:00

Harrowing video shows people trying to escape a fire in Beijing that killed 29 people.

## New Zealand cat-killing competition for children axed after backlash
 - [https://www.bbc.co.uk/news/world-asia-65320162?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-65320162?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 09:15:04+00:00

Organisers said the fundraising event for a local school had been aimed at protecting native birds.

## John Yems: Former Crawley boss ban extended until 2026 after FA appeal
 - [https://www.bbc.co.uk/sport/football/65321514?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65321514?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 08:48:16+00:00

Former Crawley manager John Yems has his suspension from football for making racist comments extended until 2026.

## Australia: David Warner in squad for World Test Championship and first two Ashes Tests
 - [https://www.bbc.co.uk/sport/cricket/65320637?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/65320637?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 06:51:23+00:00

Opening batter David Warner is in the Australia squad for the World Test Championship final against India and the first two Ashes Tests with England.

## UK inflation dips but remains above 10%
 - [https://www.bbc.co.uk/news/business-65312127?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-65312127?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 06:48:42+00:00

Inflation, which measures the rate of price rises, fell to 10.1% in the year to March.

## Beijing: Twelve held after Beijing hospital fire kills 29
 - [https://www.bbc.co.uk/news/world-asia-china-65320160?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-china-65320160?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 06:20:59+00:00

The director and deputy director of the hospital are among those being questioned by police.

## Women's Super League: How do title rivals fare against each other?
 - [https://www.bbc.co.uk/sport/football/65298347?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65298347?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 05:41:12+00:00

How have the top four performed when they have been pitted against each other this season? BBC Sport takes a closer look.

## Manchester City: Why statistics don’t tell the real story of Ederson's 'worst' season
 - [https://www.bbc.co.uk/sport/football/65309985?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/65309985?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 05:23:36+00:00

Former England goalkeeper Karen Bardsley takes a deeper look at Ederson's season to explore if Manchester City's number one really has declined the way his statistics suggest.

## How Ramadan fasting and fitness can run together
 - [https://www.bbc.co.uk/news/uk-wales-65302600?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-65302600?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 05:16:10+00:00

How some Muslims maintain the same commitment towards exercise and fasting during Ramadan.

## 24 hours as a Bayern fan: White sausages, Lederhosen & a football fan's paradise
 - [https://www.bbc.co.uk/sport/av/football/65314775?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/65314775?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 05:07:47+00:00

BBC Sport's Liam Loftus travels across Europe to sample the fan culture in four of the continent's finest football cities - his second stop is Munich, where he meets Bayern fan Cedrik,

## 'I was Emma Watson's body double in Harry Potter'
 - [https://www.bbc.co.uk/news/uk-england-beds-bucks-herts-65314277?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-beds-bucks-herts-65314277?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 05:07:01+00:00

Flick explains how she featured in three of the movies but has mixed feelings about a TV adaptation.

## Cost of living: Large rent rise causes 66-year-old to live in a van
 - [https://www.bbc.co.uk/news/uk-england-kent-65274902?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-kent-65274902?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 05:06:28+00:00

Lyn Pearman is living in a converted airport transport vehicle after selling her possessions.

## Ukraine war: The Russian ships accused of North Sea sabotage
 - [https://www.bbc.co.uk/news/world-europe-65309687?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-65309687?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 04:00:04+00:00

Disguised Russian ships are said to be preparing sabotage plans in case of war with Western powers.

## Russia-linked hacking threat to infrastructure, says UK minister
 - [https://www.bbc.co.uk/news/uk-65319771?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-65319771?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 04:00:01+00:00

Officials are urging organisations to "act now" to defend themselves against the cyber threat.

## Can Fox News afford the $787.5m Dominion settlement?
 - [https://www.bbc.co.uk/news/business-65320001?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-65320001?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 03:49:39+00:00

The network still faces a second, similar defamation lawsuit from another election technology firm.

## Kaylin Gillis: Driveway shooting suspect shows no remorse - police
 - [https://www.bbc.co.uk/news/world-us-canada-65319833?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-65319833?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 03:30:22+00:00

A young woman was killed in New York state when her car pulled up in the wrong driveway.

## Singer Aaron Carter drowned after taking drugs
 - [https://www.bbc.co.uk/news/world-us-canada-65319830?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-65319830?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 00:20:50+00:00

The US rapper was found dead in a bathtub at his Californian home in November aged 34.

## Nobody holds 'brutal' police to account - Doreen Lawrence
 - [https://www.bbc.co.uk/news/uk-65277940?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-65277940?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-04-19 00:02:19+00:00

The Met Police still haven’t changed, says Stephen Lawrence’s mother, 30 years after his racist murder.

