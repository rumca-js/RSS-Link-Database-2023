# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Na Wall Street ponownie bez zmian
 - [https://www.bankier.pl/wiadomosc/Na-Wall-Street-ponownie-bez-zmian-8526065.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Na-Wall-Street-ponownie-bez-zmian-8526065.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 21:10:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/6/28cbf19f47fa55-948-568-45-30-1910-1145.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Środowa sesja na Wall Street trzeci raz z rzędu zakończyła się niewielkimi zmianami głównych indeksów. Inwestorzy śledzą wyniki za I kw., aby ocenić, jak spółki radzą sobie z trudnościami, takimi jak spowolnienie popytu i wyższe stopy procentowe.</p>

## Jest wstępne porozumienie w sprawie rozporządzenia metanowego
 - [https://www.bankier.pl/wiadomosc/Jest-wstepne-porozumienie-w-sprawie-rozporzadzenia-metanowego-8526003.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Jest-wstepne-porozumienie-w-sprawie-rozporzadzenia-metanowego-8526003.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 18:33:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/7/8a0638d2eba1e7-948-568-20-10-3980-2387.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Mamy wstępne umiarkowane porozumienie w sprawie rozporządzenia metanowego. To ważny krok na drodze do uniknięcia katastrofy polskich kopalń – przekazała PAP europosłanka Izabela Kloc (PiS), która brała udział w negocjacjach w PE w Strasburgu.</p>

## Minister zdrowia zapowiada zniesienie stanu zagrożenia epidemicznego. Podał termin
 - [https://www.bankier.pl/wiadomosc/Minister-zdrowia-zapowiada-zniesienie-stanu-zagrozenia-epidemicznego-8525995.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Minister-zdrowia-zapowiada-zniesienie-stanu-zagrozenia-epidemicznego-8525995.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 18:23:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/e/c2fc204dd02da5-948-568-316-100-1579-947.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wstępną, planowaną datą zniesienia stanu zagrożenia epidemicznego jest koniec czerwca tego roku - powiedział w środę w Pile (woj. wielkopolskie) minister zdrowia Adam Niedzielski. Dodał, że resort "przymierza się" do zniesienia obowiązku noszenia maseczek w aptekach.</p>

## Ruszyły największe na świecie ćwiczenia z cyberobrony
 - [https://www.bankier.pl/wiadomosc/Ruszyly-najwieksze-na-swiecie-cwiczenia-z-cyberobrony-8525938.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ruszyly-najwieksze-na-swiecie-cwiczenia-z-cyberobrony-8525938.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 16:58:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/c/0d9f49c83ff050-948-568-20-80-3980-2387.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W stolicy Estonii rozpoczęto największe na świecie ćwiczenia z cyberobrony skupiające ponad 3 tys. specjalistów z 38 krajów - poinformowała w środę telewizja ERR.</p>

## Schrony w Polsce. Nowe przepisy regulują, gdzie powstaną
 - [https://www.bankier.pl/wiadomosc/Schrony-w-Polsce-Nowe-przepisy-reguluja-gdzie-powstana-8525929.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Schrony-w-Polsce-Nowe-przepisy-reguluja-gdzie-powstana-8525929.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 16:42:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/4/6d2a934c46d2d8-948-568-0-0-4428-2656.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />MSWiA przygotowało rozporządzenie dotyczące obiektów zbiorowej ochrony, w tym schronów. Regulacja określa m.in. warunki techniczne takich obiektów oraz zasady ich projektowania i budowy. Według założeń schrony i ukrycia zapewnią ochronę dla 50 proc. ludności kraju.</p>

## Bosch zainwestuje w fabrykę pomp ciepła na Dolnym Śląsku
 - [https://www.bankier.pl/wiadomosc/Bosch-zainwestuje-w-fabryke-pomp-ciepla-na-Dolnym-Slasku-8525925.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Bosch-zainwestuje-w-fabryke-pomp-ciepla-na-Dolnym-Slasku-8525925.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 16:37:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/e/7d0811efad70a7-948-568-0-95-1732-1039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Niemiecki koncern Bosch zainwestuje 1,2 mld zł w budowę fabryki pomp ciepła w Dobromierzu (Dolnośląskie). W nowej fabryce do 2027 r. ma być zatrudnionych 500 osób – podała w środę w komunikacie Grupa Bosch.</p>

## Gas Storage Poland: część magazynów gazu gromadzi już zapasy
 - [https://www.bankier.pl/wiadomosc/Gas-Storage-Poland-czesc-magazynow-gazu-gromadzi-juz-zapasy-8525916.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Gas-Storage-Poland-czesc-magazynow-gazu-gromadzi-juz-zapasy-8525916.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 16:27:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/d/63745a430a707a-948-568-0-131-2510-1505.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Stan napełnienia polskich magazynów gazu zarządzanych przez spółkę Gas Storage Poland z Grupy Orlen wynosi ok. 50 proc., część instalacji magazynowych gromadzi już gaz na kolejny sezon - poinformowało w środę GSP.</p>

## Zysk netto j.d. Grupy Kęty w I kw. '23 wyniósł 135,8 mln zł
 - [https://www.bankier.pl/wiadomosc/Zysk-netto-j-d-Grupy-Kety-w-I-kw-23-wyniosl-135-8-mln-zl-powyzej-szacunkow-8525905.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zysk-netto-j-d-Grupy-Kety-w-I-kw-23-wyniosl-135-8-mln-zl-powyzej-szacunkow-8525905.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 16:20:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/c/86784cbaebdc58-948-568-14-9-1965-1179.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Grupa Kęty miała w pierwszym kwartale 2023 r. 1,37 mld zł skonsolidowanych przychodów ze sprzedaży, 200,55 mln zł zysku EBITDA, 156,8 mln zł EBIT oraz 136,1 mln zł zysku netto - podała spółka w raporcie. Zysk netto j.d. wyniósł 135,8 mln zł. Wyniki są wyższe od wcześniejszych szacunków.</p>

## Efektowne starcie byków i niedźwiedzi na WIG20. Kurs Allegro najwyżej od roku
 - [https://www.bankier.pl/wiadomosc/Efektowne-starcie-bykow-i-niedzwiedzi-na-WIG20-Kurs-Allegro-najwyzej-od-roku-8525895.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Efektowne-starcie-bykow-i-niedzwiedzi-na-WIG20-Kurs-Allegro-najwyzej-od-roku-8525895.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 16:14:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/9/490f5bb7a2ceca-948-568-105-135-1895-1136.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W środę na WIG20 panowała spora zmienność, a początkowe spadki indeks największych spółek dynamiczne odrobił i wyszedł nawet na plus za sprawą poprawy nastrojów na spółkach z sektora bankowego. Ostatecznie dzień skończył się na konsolidacji ostatnich zwyżek przy nieco niższych obrotach.</p>

## Dopłaty do sprzedanego zboża. Resort rolnictwa szykuje rozporządzenie
 - [https://www.bankier.pl/wiadomosc/Doplaty-do-sprzedanego-zboza-Resort-rolnictwa-szykuje-rozporzadzenie-8525869.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Doplaty-do-sprzedanego-zboza-Resort-rolnictwa-szykuje-rozporzadzenie-8525869.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 15:55:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/b/9382db82a736f6-948-568-0-105-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Dopłaty dla producentów zbóż do sprzedaży tony pszenicy, żyta, jęczmienia, owsa, kukurydzy, pszenżyta, mieszanek zbożowych, rzepaku lub rzepiku - zakłada projekt rozporządzenia, o którym poinformowano w środę a wykazie prac legislacyjnych i programowych Rady Ministrów.</p>

## KGHM ponownie największą kopalnią srebra na świecie
 - [https://www.bankier.pl/wiadomosc/KGHM-najwieksza-kopalnia-srebra-na-swiecie-8525841.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/KGHM-najwieksza-kopalnia-srebra-na-swiecie-8525841.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 15:12:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/6/fe660f8bc6ba16-945-560-0-60-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />KGHM utrzymał pierwsze miejsce w zestawieniu "największych kopalń srebra na świecie" w rankingu World Silver Survey 2023 - poinformowała w środę miedziowa spółka. Dodano, że w kategorii "największych producentów srebra" KGHM uplasował się na drugim miejscu.</p>

## Sankcje na rosyjski gaz LPG. Posłowie opozycji złożyli w Sejmie projekt ustawy
 - [https://www.bankier.pl/wiadomosc/Sankcje-na-rosyjski-gaz-LPG-Poslowie-opozycji-zlozyli-w-Sejmie-projekt-ustawy-8525804.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sankcje-na-rosyjski-gaz-LPG-Poslowie-opozycji-zlozyli-w-Sejmie-projekt-ustawy-8525804.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 14:38:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/c/73eadbb0ddd6da-948-568-465-326-1104-662.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Posłowie klubów opozycyjnych: Lewicy, KO, KP-PSL oraz Polski 2050 poinformowali w środę o złożeniu w Sejmie projektu, która wprowadza sankcje na rosyjski gaz LPG. Zwrócili się do posłów pozostałych ugrupowań, szczególnie Zjednoczonej Prawicy o jego poparcie.</p>

## Czekają nas masowe kontrole domów? Nadzór budowlany dementuje
 - [https://www.bankier.pl/wiadomosc/Czekaja-nas-masowe-kontrole-domow-Nadzor-budowlany-dementuje-8525795.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Czekaja-nas-masowe-kontrole-domow-Nadzor-budowlany-dementuje-8525795.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 14:33:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/e/4943b4727880a8-948-568-0-133-1971-1182.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W drugiej połowie roku ma zostać wdrożony kolejny etap rozwoju Centralnej Ewidencji Emisyjności Budynków; będzie można zamówić przegląd przewodów kominowych i inwentaryzację budynku, w wyniku których otrzyma się tzw. uproszczony audyt energetyczny - przekazał Główny Urząd Nadzoru Budowlanego.</p>

## TK: zasady wynagrodzenia radców prawnych z urzędu - niekonstytucyjne
 - [https://www.bankier.pl/wiadomosc/TK-zasady-wynagrodzenia-radcow-prawnych-z-urzedu-niekonstytucyjne-8525755.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/TK-zasady-wynagrodzenia-radcow-prawnych-z-urzedu-niekonstytucyjne-8525755.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 13:43:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/2/8d18d38e90d5ed-948-568-0-770-3395-2037.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ustalenie stawek wynagrodzenia radców prawnych z urzędu na znacznie niższym poziomie od minimalnych stawek przysługujących radcom prawnym z wyboru jest niezgodne z konstytucją - orzekł w środę Trybunał Konstytucyjny.</p>

## Ustawa o jakości w ochronie zdrowia trafiła do kosza, ale minister zapewnia, że niebawem powróci
 - [https://www.bankier.pl/wiadomosc/Ustawa-o-jakosci-w-ochronie-zdrowia-trafila-do-kosza-ale-minister-zapewnia-ze-niebawem-powroci-8525730.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ustawa-o-jakosci-w-ochronie-zdrowia-trafila-do-kosza-ale-minister-zapewnia-ze-niebawem-powroci-8525730.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 13:23:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/0/b1d92df152f876-948-568-11-0-4759-2855.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prawa pacjenta są zbyt ważne, by jedno głosowanie mogło je przekreślić – stwierdził w środę minister zdrowia Adam Niedzielski, komentując odrzucenie ustawy o jakości w opiece zdrowotnej.</p>

## Awaria linii energetycznej łączącej Finlandię ze Szwecją
 - [https://www.bankier.pl/wiadomosc/Awaria-linii-energetycznej-laczacej-Finlandie-ze-Szwecja-8525709.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Awaria-linii-energetycznej-laczacej-Finlandie-ze-Szwecja-8525709.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 13:07:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/f/574f4d4254de01-948-568-0-105-3525-2115.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W środę po południu doszło do awarii kabla energetycznego, łączącego zachodnie wybrzeże Finlandii ze wschodnim wybrzeżem Szwecji; linia obecnie nie przesyła prądu - przekazał fiński operator sieci energetycznej Fingrid.</p>

## Wojewoda skarży się na uchwałę o Strefie Czystego Transportu do WSA
 - [https://www.bankier.pl/wiadomosc/Wojewoda-skarzy-sie-na-uchwale-o-Strefie-Czystego-Transportu-do-WSA-8525663.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wojewoda-skarzy-sie-na-uchwale-o-Strefie-Czystego-Transportu-do-WSA-8525663.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 12:22:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/e/3603e8c837dbf5-948-568-0-0-3990-2393.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wojewoda małopolski skierował do Wojewódzkiego Sądu Administracyjnego w Krakowie skargę na uchwałę rady miasta dotyczącą Strefy Czystego Transportu - poinformował dyrektor Wydziału Prawnego i Nadzoru Małopolskiego Urzędu Wojewódzkiego w Krakowie.</p>

## Zmiana po 20 latach. Związek Banków Polskich ma nowego prezesa
 - [https://www.bankier.pl/wiadomosc/Tadeusz-Bialek-nowym-prezesem-Zwiazku-Bankow-Polskich-8525615.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tadeusz-Bialek-nowym-prezesem-Zwiazku-Bankow-Polskich-8525615.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 11:36:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/b/923b98f1b67d2f-948-568-45-6-1115-669.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Walne Zgromadzenie Związku Banków Polskich powołało na prezesa Tadeusza Białka, dotychczasowego wiceprezesa Związku - poinformował w środę ZBP w komunikacie.</p>

## UE odpowiada na niekontrolowany import zboża z Ukrainy. "Będziemy chronić nasz rynek"
 - [https://www.bankier.pl/wiadomosc/UE-odpowiada-na-niekontrolowany-import-zboza-z-Ukrainy-Bedziemy-chronic-nasz-rynek-8525611.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/UE-odpowiada-na-niekontrolowany-import-zboza-z-Ukrainy-Bedziemy-chronic-nasz-rynek-8525611.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 11:32:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/5/da9a79a73d107d-948-569-455-240-1291-775.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Szefowa KE Ursula von der Leyen odpowiedziała w środę na list pięciu przywódców państw UE w sprawie ukraińskiego zboża. Podkreśliła, że potrzebne jest wspólne europejskie podejście w tej sprawie - przekazała dziennikarzom w Brukseli rzeczniczka KE Dana Spinant.</p>

## Prokuratura prześwietla byłego premiera. Chodzi o przywłaszczenie mienia
 - [https://www.bankier.pl/wiadomosc/Prokuratura-przeswietla-bylego-premiera-K-Marcinkiewicza-Chodzi-o-przywlaszczenie-mienia-8525609.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Prokuratura-przeswietla-bylego-premiera-K-Marcinkiewicza-Chodzi-o-przywlaszczenie-mienia-8525609.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 11:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/8/bed570e03eb7a8-945-567-0-21-1730-1038.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Telefon, komputer i samochód - to o nie toczy się spór. W śródmiejskiej prokuraturze prowadzone jest postępowanie dotyczące przywłaszczenia mienia powierzonego przez byłego premiera Kazimierza Marcinkiewicza.</p>

## Podejrzany rzepak z Ukrainy. Prokuratura bada sprawę
 - [https://www.bankier.pl/wiadomosc/Podejrzany-rzepak-z-Ukrainy-Prokuratura-bada-sprawe-8525593.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Podejrzany-rzepak-z-Ukrainy-Prokuratura-bada-sprawe-8525593.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 11:13:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/0/290b437de905d1-948-568-52-15-2787-1672.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prokuratura Rejonowa Kraków-Śródmieście Wschód bada, czy 3 grudnia w tym mieście nie doszło do poświadczenia nieprawdy przy wydawaniu oświadczenia dotyczącego przeznaczenia ziaren rzepaku transportowanego z Ukrainy do Polski.</p>

## Podróżni zyskają nowe połączenie do Turcji. Na początek linie kuszą niższymi cenami
 - [https://www.bankier.pl/wiadomosc/Podrozni-zyskaja-nowe-polaczenie-do-Turcji-Na-poczatek-linie-kusza-nizszymi-cenami-8525441.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Podrozni-zyskaja-nowe-polaczenie-do-Turcji-Na-poczatek-linie-kusza-nizszymi-cenami-8525441.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 11:01:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/1/0aaf641d40a147-948-568-0-110-2000-1199.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Pegasus Airlines, tania linia lotnicza z Turcji, uruchomi wkrótce regularne połączenie między Ankarą a lotniskiem Chopina w Warszawie. Podróżni, którym uda się wykupić bilety na pierwsze rejsy, będą mogli liczyć na spore zniżki. zdążą



</p>

## Strefy zakazane dla lotów. Rząd proponuje ich aktualizację
 - [https://www.bankier.pl/wiadomosc/Strefy-zakazane-dla-lotow-Rzad-proponuje-ich-aktualizacje-8525558.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Strefy-zakazane-dla-lotow-Rzad-proponuje-ich-aktualizacje-8525558.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 10:39:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/b/5519ad672b0fb6-948-568-0-123-1768-1060.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nowe tereny zostaną dodane do wykazu stref zakazanych i ograniczonych dla ruchu lotniczego oraz ich granic - taką aktualizację zakłada rozporządzenia ministra infrastruktury. Rząd zmiany motywuje dostosowaniem przepisów do aktualnego stanu potrzeb i wymagań zapewnienia bezpieczeństwa. </p>

## Węgry zakazały importu produktów rolno-spożywczych z Ukrainy.To długa lista
 - [https://www.bankier.pl/wiadomosc/Wegry-zakazaly-importu-produktow-rolno-spozywczych-z-Ukrainy-To-dluga-lista-8525550.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wegry-zakazaly-importu-produktow-rolno-spozywczych-z-Ukrainy-To-dluga-lista-8525550.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 10:32:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/3/8318524eba7dc8-945-560-67-13-2651-1590.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Oprócz zbóż, Węgry zakazały także importu z Ukrainy m.in. mięsa, jaj i miód. Łącznie jest to około 20 produktów, których lista została opublikowana w formie rządowego dekretu w dzienniku urzędowym „Magyar Kozlony”. </p>

## Europa Środkowa pozostaje inflacyjnym epicentrum
 - [https://www.bankier.pl/wiadomosc/Inflacja-w-Unii-Europejskiej-marzec-2023-8525546.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Inflacja-w-Unii-Europejskiej-marzec-2023-8525546.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 10:29:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/a/6f31f198b51618-948-567-0-67-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />To w krajach Europy Środkowej panuje najwyższa inflacja cenowa na 
kontynencie - wynika z najnowszych danych Eurostatu. </p>

## Cztery największe banki sfinansują program atomowy Orlenu
 - [https://www.bankier.pl/wiadomosc/Cztery-banki-sfinansuja-program-atomowy-Orlenu-8525522.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Cztery-banki-sfinansuja-program-atomowy-Orlenu-8525522.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 10:09:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/4/aecaa25a6de998-948-567-0-130-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Bank Gospodarstwa Krajowego, Pekao, PKO Bank Polski i Santander Bank Polska będą współpracować przy zapewnieniu finasowania na budowę małych reaktorów jądrowych, tzw. SMR-ów, która została zaplanowana przez ORLEN Synthos Green Energy. Będą wspólnie pracować nad przygotowaniem optymalnego modelu finansowania i zabezpieczeniem środków na ten projekt.</p>

## Rosyjskie "statki-widmo" na Bałtyku i Morzu Północnym. Przygotowują sabotaż?
 - [https://www.bankier.pl/wiadomosc/Rosyjskie-statki-widmo-przygotowuja-sabotaz-na-wodach-wokol-Danii-Szwecji-Norwegii-i-Finlandii-8525504.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rosyjskie-statki-widmo-przygotowuja-sabotaz-na-wodach-wokol-Danii-Szwecji-Norwegii-i-Finlandii-8525504.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 09:48:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/f/99476d6de933f2-945-567-93-236-1268-761.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Na wodach wokół Danii, Szwecji, Norwegii oraz Finlandii rosyjskie "statki widma" przygotowują możliwe działania sabotażowe wymierzone w morskie elektrownie wiatrowe, podwodne rurociągi i kable energetyczne - ujawniły w środę telewizje publiczne państw nordyckich.</p>

## Produkujemy coraz mniej wódki. Tak źle nie było od dekady
 - [https://www.bankier.pl/wiadomosc/Produkujemy-coraz-mniej-wodki-Tak-zle-nie-bylo-od-dekady-8525477.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Produkujemy-coraz-mniej-wodki-Tak-zle-nie-bylo-od-dekady-8525477.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 09:13:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/a/896d682a97eee9-948-568-0-526-3290-1974.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W styczniu i w lutym 2023 r. w naszym kraju wyprodukowano 112 tys. hektolitrów wódki. To o 6 proc. mniej niż przed rokiem. Według producentów tak złej
sytuacji w branży nie było od co najmniej 10 lat.</p>

## Katastrofa ekologiczna na Odrze może się powtórzyć. GIOŚ: Alert wydamy w godzinę
 - [https://www.bankier.pl/wiadomosc/Katastrofa-ekologiczna-na-Odrze-moze-sie-powtorzyc-GIOS-Alert-wydamy-w-godzine-8525471.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Katastrofa-ekologiczna-na-Odrze-moze-sie-powtorzyc-GIOS-Alert-wydamy-w-godzine-8525471.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 09:03:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/4/b25fcc46cf6f95-948-568-0-180-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Już teraz służby zakładają, że katastrofa ekologiczna, do której doszło w Odrze w zeszłym roku, może się powtórzyć. - Jednak jesteśmy lepiej do tego przygotowani, a w przypadku zagrożenia toksyną ze strony złotej algi powiadomimy o tym odpowiednie służby w ciągu godziny - mówi Główny Inspektor Ochrony Środowiska Krzysztof Gołębiewski.</p>

## Wiosenna siła złotego. Kurs euro blisko tegorocznego dołka
 - [https://www.bankier.pl/wiadomosc/Kurs-euro-blisko-tegorocznego-dolka-Wiosenna-sila-zlotego-8525467.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kurs-euro-blisko-tegorocznego-dolka-Wiosenna-sila-zlotego-8525467.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 08:55:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/f/675ca973bdcef1-948-568-8-21-1723-1034.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Środowy poranek przyniósł stabilizację kursu euro blisko
najniższych poziomów od 10 miesięcy.</p>

## Akcjonariusze Kernel Holding apelują do KNF i GPW ws. delistingu spółki
 - [https://www.bankier.pl/wiadomosc/Akcjonariusze-Kernel-Holding-apeluja-do-KNF-i-GPW-ws-delistingu-spolki-8525458.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Akcjonariusze-Kernel-Holding-apeluja-do-KNF-i-GPW-ws-delistingu-spolki-8525458.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 08:34:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/7/21962a2a835f62-945-567-30-21-1701-1021.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Akcjonariusze Kernel Holding domagają się respektowania przewidzianego prawem standardu ochrony w związku z planowanym delistingiem. Apelują do KNF i GPW o przeprowadzenie analiz i podjęcie adekwatnych kroków - napisali w komunikacie prasowym akcjonariusze spółki, którzy zawarli porozumienie.</p>

## Santander Bank Polska zmienia cennik dla kont
 - [https://www.bankier.pl/wiadomosc/Santander-Bank-Polska-zmienia-cennik-dla-kont-8525447.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Santander-Bank-Polska-zmienia-cennik-dla-kont-8525447.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 08:07:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/9/c191535cdf08d5-948-568-0-53-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Santander Bank Polska zmienia ofertę rachunków osobistych. Zmiany będą dotyczyły m.in. flagowego rachunku, czyli Konta Jakie Chcę oraz kilku innych produktów. W ofercie pojawi się nowy rachunek Max, a opłaty w ramach pakietu Select wzrosną.</p>

## "Polskie porty mogą rozładować ukraińskie zboże". Gróbarczyk zapewnia, że jest przygotowany
 - [https://www.bankier.pl/wiadomosc/Polskie-porty-moga-rozladowac-ukrainskie-zboze-Grobarczyk-zapewnia-ze-jest-przygotowany-8525411.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polskie-porty-moga-rozladowac-ukrainskie-zboze-Grobarczyk-zapewnia-ze-jest-przygotowany-8525411.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 07:18:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/b/9382db82a736f6-948-568-0-105-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Polskie porty są w stanie rozładować zboże przywożone z Ukrainy - zapewnia wiceminister infrastruktury Marek Gróbarczyk w środę w Polskim Radiu 24. Choć przyznaje, że ustanowienie stałego połączenia będzie wyzwaniem, wymagającym inwestycji np. w silosy.</p>

## Premier dostanie więcej uprawnień. Rząd pracuje nad projektem rozporządzenia ws. obrony kraju
 - [https://www.bankier.pl/wiadomosc/Premier-dostanie-wiecej-uprawnien-Rzad-pracuje-nad-projektem-rozporzadzenia-ws-obrony-kraju-8525392.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Premier-dostanie-wiecej-uprawnien-Rzad-pracuje-nad-projektem-rozporzadzenia-ws-obrony-kraju-8525392.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 06:24:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/5/7b70487fe8cee2-948-568-0-72-1912-1147.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Jedną z najistotniejszych zmian jest poszerzenie kompetencji premiera – informuje w środę Radio Zet. Rząd opublikował rozporządzenie, w który określono organizację i tryb przygotowania systemu kierowania bezpieczeństwem narodowym, w tym obroną państwa na wypadek wojny.</p>

## Koniec z oszczędzaniem? Perkowski: Zużycie gazu będzie miało tendencję wzrostową
 - [https://www.bankier.pl/wiadomosc/Koniec-z-oszczedzaniem-Perkowski-Zuzycie-gazu-bedzie-mialo-tendencje-wzrostowa-8525387.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Koniec-z-oszczedzaniem-Perkowski-Zuzycie-gazu-bedzie-mialo-tendencje-wzrostowa-8525387.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 06:14:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/f/9f0e5ce0b55b04-948-568-2-32-997-598.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zużycie gazu będzie miało tendencję wzrostową, rosnący udział OZE będzie wymagać bilansowania systemu energetycznego elastycznym, niskoemisyjnym paliwem - powiedział PAP wiceprezes PKN Orlen ds. wydobycia, prezes Izby Gospodarczej Gazownictwa Robert Perkowski.</p>

## Psuje się portfel kredytów frankowych. Udział tych "złych" to ponad 8 proc.
 - [https://www.bankier.pl/wiadomosc/Psuje-sie-portfel-kredytow-frankowych-Udzial-tych-zlych-to-ponad-8-proc-8525384.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Psuje-sie-portfel-kredytow-frankowych-Udzial-tych-zlych-to-ponad-8-proc-8525384.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 06:11:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/7/0ea6a2bcdb9c93-948-568-32-10-967-580.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Część frankowiczów może przestać spłacać zobowiązania w oczekiwaniu na rozstrzygnięcie sądowe. Udział kredytów zagrożonych w puli hipotek w CHF wzrósł do bardzo wysokiego poziomu 8,4 proc. Słowem psuje się portfel kredytów frankowych. – pisze środowa "Rzeczpospolita".</p>

## Rekrutacje pod górkę. Praca czeka w firmach z południowej i centralnej Polski
 - [https://www.bankier.pl/wiadomosc/Rekrutacje-pod-gorke-Praca-czeka-w-firmach-z-poludniowej-i-centralnej-Polski-8525377.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rekrutacje-pod-gorke-Praca-czeka-w-firmach-z-poludniowej-i-centralnej-Polski-8525377.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 06:04:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/b/5a36e9b9790ded-948-568-78-210-2320-1392.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Poszukiwanie pracowników jest najtrudniejsze dla firm z południowej i centralnej Polski - wynika z raportu ManpowerGroup. Aby poradzić sobie z niedoborem pracowników o pożądanych umiejętnościach, pracodawcy inwestują w szkolenia. </p>

## Okradli Główny Urząd Celny w Niemczech. Wynieśli stamtąd ponad 6,4 mln euro
 - [https://www.bankier.pl/wiadomosc/Okradli-Glowny-Urzad-Celny-w-Niemczech-Wyniesli-stamtad-ponad-6-4-mln-euro-8525372.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Okradli-Glowny-Urzad-Celny-w-Niemczech-Wyniesli-stamtad-ponad-6-4-mln-euro-8525372.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 06:01:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/e/db45e9482888e7-948-567-0-32-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Dolnośląski wydział Prokuratury Krajowej skierował do sądu akt oskarżenia przeciwko siedmiu osobom, w tym Rafałowi C., w śledztwie dotyczącym kradzieży ponad 6,4 miliona euro z Głównego Urzędu Celnego w Duisburgu Ekspozytury w Emmerich w Niemczech.</p>

## Ekonomiści konta ekonomiści. "Jeśli giełda jest wyrocznią, to nadchodzi lepszy czas dla polskiej gospodarki"
 - [https://www.bankier.pl/wiadomosc/Ekonomisci-konta-ekonomisci-Jesli-gielda-jest-wyrocznia-to-nadchodzi-lepszy-czas-dla-polskiej-gospodarki-8525369.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ekonomisci-konta-ekonomisci-Jesli-gielda-jest-wyrocznia-to-nadchodzi-lepszy-czas-dla-polskiej-gospodarki-8525369.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 06:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/e/16fd0ca3cefbc4-948-568-427-222-3131-1879.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Pół roku temu warszawska giełda była na dnie. Od tamtej pory urosła o kilkadziesiąt procent. To sugeruje, że polska gospodarka w perspektywie kolejnych miesięcy też będzie wychodziła na prostą - pisze w środę "Business Insider".</p>

## Testament na pierwszym miejscu? Sąd Najwyższy uwzględnił skargę nadzwyczają
 - [https://www.bankier.pl/wiadomosc/Testament-na-pierwszym-miejscu-Sad-Najwyzszy-uwzglednil-skarge-nadzwyczaja-8525367.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Testament-na-pierwszym-miejscu-Sad-Najwyzszy-uwzglednil-skarge-nadzwyczaja-8525367.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 05:56:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/a/7d86c44c252aeb-948-568-0-62-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wola spadkodawców ma prymat nad formą testamentu - tak stwierdził Sąd Najwyższy rozpatrując skargę nadzwyczajną Prokuratora Generalnego odnoszącą się do sprawy, w której sekretarz gminy w 1980 roku niepoprawnie sporządził testament.</p>

## Soboń potwierdza słowa premiera. "Będziemy upraszczać system podatkowy"
 - [https://www.bankier.pl/wiadomosc/Sobon-potwierdza-slowa-premiera-Bedziemy-upraszczac-system-podatkowy-8525366.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sobon-potwierdza-slowa-premiera-Bedziemy-upraszczac-system-podatkowy-8525366.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 05:55:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/1/d0dbd8661ce27d-948-568-0-66-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wiceminister finansów Artur Soboń zapowiedział uproszczenie systemu podatkowego, zgodnie z wcześniejszymi zapowiedziami premiera Mateusza Morawieckiego. Jak zaznacza, jednym z priorytetów jest nowelizacja ordynacji podatkowej. </p>

## Branża cementowa obawia się konsekwencji kryzysu w mieszkaniówce
 - [https://www.bankier.pl/wiadomosc/Branza-cementowa-obawia-sie-konsekwencji-kryzysu-w-mieszkaniowce-8525363.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Branza-cementowa-obawia-sie-konsekwencji-kryzysu-w-mieszkaniowce-8525363.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 05:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/0/0fe31c5d3fb422-948-568-0-119-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Pomimo ubiegłorocznego, bezprecedensowego wzrostu kosztów produkcji branża cementowa w Polsce wciąż pozostaje w dobrej kondycji i jest przygotowana do sezonu budowlanego. - Duże obawy dotyczą budownictwa...</p>

## Lotnisko Warszawa-Radom. Jest cennik opłat lotniskowych - tyle zapłacą przewoźnicy
 - [https://www.bankier.pl/wiadomosc/Lotnisko-Warszawa-Radom-Jest-cennik-oplat-lotniskowych-tyle-zaplaca-przewoznicy-8525341.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Lotnisko-Warszawa-Radom-Jest-cennik-oplat-lotniskowych-tyle-zaplaca-przewoznicy-8525341.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 05:02:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/1/9b660bc54a861c-948-568-5-0-1018-611.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Na lotnisku Warszawa-Radom samoloty do 2 ton będą płacić 60 zł opłaty za lądowanie, większe maszyny jak np. airbusy, czy boeingi - 30 zł; opłata pasażerska za każdego podróżnego wylatującego z portu wyniesie 40 zł - wynika z podpisanego przez prezesa Polskich Portów Lotniczych (PPL) cennika opłat.</p>

## Branża IT. Tak jak dobrze płaci, tak ma problem z zadłużeniem
 - [https://www.bankier.pl/wiadomosc/Branza-IT-Tak-jak-dobrze-placi-tak-ma-problem-z-zadluzeniem-8525338.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Branza-IT-Tak-jak-dobrze-placi-tak-ma-problem-z-zadluzeniem-8525338.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 05:01:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/2/a4d8c9221144e6-948-568-0-0-3861-2317.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zaległości branży IT wzrosły o niemal 22 proc. rdr i wynoszą obecnie ponad 230 mln zł - wynika z danych Krajowego Rejestru Długów Biura Informacji Gospodarczej. Największe trudności finansowe mają firmy działające na Mazowszu.</p>

## Chwila stabilizacji w bankach. Czy to oznacza, że pracuje się lepiej?
 - [https://www.bankier.pl/wiadomosc/Chwila-stabilizacji-w-bankach-Czy-to-oznacza-ze-pracuje-sie-lepiej-8524894.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Chwila-stabilizacji-w-bankach-Czy-to-oznacza-ze-pracuje-sie-lepiej-8524894.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/4/6d0b4d9899a82c-948-568-840-1575-1862-1117.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Najnowsze dane o liczbie pracowników w bankach ponownie pokazują, że etatów ubywa. Zmiany nie są jednak już tak gwałtowne jak przed kilkoma laty. W dłuższym okresie bilans jest zdecydowanie ujemny – w ciągu dekady liczba zatrudnionych spadła o ponad 30 tys.</p>

## Karta Nauczyciela do likwidacji? Nauczyciele przeciwni
 - [https://www.bankier.pl/wiadomosc/Karta-Nauczyciela-do-likwidacji-Nauczyciele-przeciwni-8525232.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Karta-Nauczyciela-do-likwidacji-Nauczyciele-przeciwni-8525232.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/1/a22933dab2243b-948-568-7-209-2987-1792.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Minister edukacji i nauki Przemysław Czarnek zapowiedział likwidację Karty Nauczyciela. Ma to nastąpić jesienią tego roku. Zaskoczone są tym organizacje nauczycieli, które nie spodziewały się takich zmian i są im przeciwne.</p>

## Branża fitness odbija się po lockdownach. Długi spadły
 - [https://www.bankier.pl/wiadomosc/Branza-fitness-odbija-sie-po-lockdownach-Ich-dlugi-spadly-8525336.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Branza-fitness-odbija-sie-po-lockdownach-Ich-dlugi-spadly-8525336.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 04:51:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/b/3a8cdeded1c8a7-948-568-0-99-1732-1039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kluby sportowe, fitness czy inne miejsca, które poprawiają kondycję fizyczną Polaków, zanotowały spadek długów o około 5 mln zł, do poziomu niespełna 63 mln zł. To dobry wynik przy malejących wydatkach na sport, spowodowanych m.in. rosnącą inflacją. 
 </p>

## Bidenowie pokazali swoje zarobki za 2022 rok. I opłacili podatki
 - [https://www.bankier.pl/wiadomosc/Bidenowie-pokazali-swoje-zarobki-za-2022-rok-I-oplacili-podatki-8525328.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Bidenowie-pokazali-swoje-zarobki-za-2022-rok-I-oplacili-podatki-8525328.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 02:20:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/9/7cedc16d44f0ef-948-568-0-47-1732-1039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prezydent USA Joe Biden i jego małżonka Jill, która jest profesorem uniwersyteckim, zarobili w 2022 roku 579 514 dolarów i zapłacili podatek federalny w wysokości 169 820 dol. (co stanowi 23,8 proc.). To wynika z opublikowanych we wtorek ich deklaracji podatkowych.</p>

## Operacja Interpolu w 15 krajach Ameryki Łacińskiej. Ponad 15 tys. aresztowanych
 - [https://www.bankier.pl/wiadomosc/Operacja-Interpolu-w-15-krajach-Ameryki-Lacinskiej-Ponad-15-tys-aresztowanych-8525326.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Operacja-Interpolu-w-15-krajach-Ameryki-Lacinskiej-Ponad-15-tys-aresztowanych-8525326.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-19 00:24:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/d/326e6b15bf4594-945-560-0-60-1500-899.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />14 260 osób aresztowanych , konfiskata 8 263 sztuk nielegalnie posiadanej broni palnej oraz ponad 300 000  sztuk amunicji -  to rezultat jednej z największych w skali światowej operacji Interpolu przeprowadzonej w 15 krajach Ameryki Łacińskiej pod kryptonimem  Trigger IX w dniach  12 marca - 2 kwietnia.</p>

