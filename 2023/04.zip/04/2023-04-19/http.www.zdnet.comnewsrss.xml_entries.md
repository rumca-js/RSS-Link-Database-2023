# Source:ZDNET, URL:http://www.zdnet.com/news/rss.xml, language:en-US

## Google Fi gets a new name, tweaked pricing, and a new focus on family plans
 - [https://www.zdnet.com/home-and-office/networking/google-fi-gets-a-new-name-tweaked-pricing-and-a-new-focus-on-family-plans/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/networking/google-fi-gets-a-new-name-tweaked-pricing-and-a-new-focus-on-family-plans/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-04-19 21:23:45+00:00

There's no shortage of changes coming to Google's wireless carrier.

## Reddit will start charging some users for API access -- bad news for AI companies
 - [https://www.zdnet.com/article/reddit-will-start-charging-some-users-for-api-access-bad-news-for-ai-companies/#ftag=RSSbaffb68](https://www.zdnet.com/article/reddit-will-start-charging-some-users-for-api-access-bad-news-for-ai-companies/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-04-19 20:20:19+00:00

After being used by multiple AI companies to train their AI systems for free, Reddit is ready to cash in.

## Is your iPhone overheating and crashing since installing iOS 16.4.1? Here's what to do
 - [https://www.zdnet.com/article/is-your-iphone-overheating-and-crashing-since-installing-ios-16-4-1-heres-what-to-do/#ftag=RSSbaffb68](https://www.zdnet.com/article/is-your-iphone-overheating-and-crashing-since-installing-ios-16-4-1-heres-what-to-do/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-04-19 19:02:05+00:00

Here are a few things you can do to minimize the iOS battery drama while we wait for the update to the update.

## How to kill a process in Linux
 - [https://www.zdnet.com/article/how-to-kill-a-process-in-linux/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-kill-a-process-in-linux/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-04-19 16:51:00+00:00

Sometimes a process or application can cause problems on a Linux machine. When that happens, you'll need to know how to kill the wayward process.

## Netflix to charge for password sharing in the U.S. as soon as this summer
 - [https://www.zdnet.com/home-and-office/home-entertainment/netflix-to-charge-for-password-sharing-in-the-u-s-as-soon-as-this-summer/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/home-entertainment/netflix-to-charge-for-password-sharing-in-the-u-s-as-soon-as-this-summer/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-04-19 16:40:47+00:00

The decision comes after the company tested out password-sharing fees in Canada and three other countries worldwide.

## Want a Flipper Zero without paying inflated prices? Now's your chance
 - [https://www.zdnet.com/article/want-a-flipper-zero-without-paying-inflated-prices-nows-your-chance/#ftag=RSSbaffb68](https://www.zdnet.com/article/want-a-flipper-zero-without-paying-inflated-prices-nows-your-chance/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-04-19 16:40:00+00:00

The Flipper Zero is a powerful, multi-functional, cybersecurity tool, and you can now pick one up for less than usual.

## This $30 USB hub finally ended my MacBook port struggle
 - [https://www.zdnet.com/home-and-office/smart-office/this-30-usb-hub-finally-ended-my-macbook-port-struggle/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/smart-office/this-30-usb-hub-finally-ended-my-macbook-port-struggle/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-04-19 16:32:11+00:00

The Plugable 5-in-1 adapter gives the latest MacBooks extra ports without blocking the one that matters the most.

## The Kubuntu Focus Ir14 is an upcoming Linux laptop worthy of powering the KDE Plasma desktop
 - [https://www.zdnet.com/article/the-kubuntu-focus-ir14-is-an-upcoming-linux-laptop-worthy-of-powering-the-kde-plasma-desktop/#ftag=RSSbaffb68](https://www.zdnet.com/article/the-kubuntu-focus-ir14-is-an-upcoming-linux-laptop-worthy-of-powering-the-kde-plasma-desktop/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-04-19 16:07:00+00:00

The latest Kabuntu laptop marries security-first hardware with its Linux-based operating system. Here are three features in particular that stand out.

## If you have a tell-a-friend feature on your website, disable it right now
 - [https://www.zdnet.com/article/if-you-have-a-tell-a-friend-feature-on-your-website-disable-it-right-now/#ftag=RSSbaffb68](https://www.zdnet.com/article/if-you-have-a-tell-a-friend-feature-on-your-website-disable-it-right-now/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-04-19 15:50:17+00:00

Despite all the best efforts, bad things can happen. Read our cautionary tale.

## Galaxy Watch 5 finally gets temperature-based cycle tracking update
 - [https://www.zdnet.com/article/galaxy-watch-5-finally-gets-temperature-based-cycle-tracking-update/#ftag=RSSbaffb68](https://www.zdnet.com/article/galaxy-watch-5-finally-gets-temperature-based-cycle-tracking-update/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-04-19 15:43:41+00:00

Samsung enabled skin temperature tracking on its Watch 5 series. Here's what you need to know.

## Your HomePod can now alert you if you're smoke alarm is going off
 - [https://www.zdnet.com/home-and-office/smart-home/your-homepod-can-now-alert-you-if-youre-smoke-alarm-is-going-off/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/smart-home/your-homepod-can-now-alert-you-if-youre-smoke-alarm-is-going-off/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-04-19 15:32:32+00:00

Apple HomeKit users just got a new Sound Recognition feature to make their smart homes safer. Here's how to enable it.

## Millions of Facebook users are entitled to a settlement payout. How to file a claim
 - [https://www.zdnet.com/article/millions-of-facebook-users-are-entitled-to-a-settlement-payout-heres-how-to-file-a-claim/#ftag=RSSbaffb68](https://www.zdnet.com/article/millions-of-facebook-users-are-entitled-to-a-settlement-payout-heres-how-to-file-a-claim/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-04-19 15:15:08+00:00

Meta settled its lawsuit that alleged the company allowed a political marketing firm to improperly access user data. You might be owed some money.

## You'll never guess how many tech repair tools this little bag can fit
 - [https://www.zdnet.com/home-and-office/youll-never-guess-how-many-tech-repair-tools-this-little-bag-can-fit/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/youll-never-guess-how-many-tech-repair-tools-this-little-bag-can-fit/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-04-19 15:02:00+00:00

The iFixit Repair Business Toolkit just got a 2023 refresh. Here's everything included.

## This AI-powered app lets you chat with historical and fictional characters
 - [https://www.zdnet.com/article/this-ai-powered-app-lets-you-chat-with-historical-and-fictional-characters/#ftag=RSSbaffb68](https://www.zdnet.com/article/this-ai-powered-app-lets-you-chat-with-historical-and-fictional-characters/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-04-19 13:46:27+00:00

With this new chat app, you can talk to AI versions of Leonardo DaVinci, Shakespeare, Hercules, Dracula, and many other famous and infamous characters.

## The best Mother's Day gifts for 2023
 - [https://www.zdnet.com/article/everything-id-get-my-mom-for-mothers-day/#ftag=RSSbaffb68](https://www.zdnet.com/article/everything-id-get-my-mom-for-mothers-day/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-04-19 13:34:42+00:00

Stuck on what to get your mother, caregiver, or mother figure? I compiled a list of various tech gadgets I know my mom is sure to love  (and actually use) to give you some inspiration.

## How to enable markdown in Google Docs (and what it can do for you)
 - [https://www.zdnet.com/home-and-office/work-life/how-to-enable-markdown-in-google-docs/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/work-life/how-to-enable-markdown-in-google-docs/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-04-19 09:40:00+00:00

Looking for a way to use Google Docs even more efficiently? This can help.

## China wants to use supercomputing to accelerate digital transformation
 - [https://www.zdnet.com/article/china-wants-to-use-supercomputing-to-accelerate-digital-transformation/#ftag=RSSbaffb68](https://www.zdnet.com/article/china-wants-to-use-supercomputing-to-accelerate-digital-transformation/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-04-19 08:23:43+00:00

China's national supercomputing framework will pull together computing resources across the country to drive the development of emerging technologies, such as artificial intelligence.

## These medical IoT devices carry biggest security risks
 - [https://www.zdnet.com/article/these-medical-iot-devices-carry-biggest-security-risks/#ftag=RSSbaffb68](https://www.zdnet.com/article/these-medical-iot-devices-carry-biggest-security-risks/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-04-19 07:35:32+00:00

Unpatched and running on operating systems that are no longer supported, these connected healthcare devices carry significant security risks for a sector that's already a top target for cyber criminals.

