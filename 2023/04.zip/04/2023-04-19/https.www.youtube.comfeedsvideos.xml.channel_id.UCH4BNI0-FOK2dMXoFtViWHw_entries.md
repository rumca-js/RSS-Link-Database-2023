# Source:Be Smart, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw, language:en-US

## Earth’s Greatest Game of Hide and Seek
 - [https://www.youtube.com/watch?v=U7qF0_SyFAY](https://www.youtube.com/watch?v=U7qF0_SyFAY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw
 - date published: 2023-04-19 15:06:36+00:00

Check out Untold Earth and the PBS Earth Month Playlist: https://www.youtube.com/watch?v=-BVHSUMAWR4&amp;list=PLzkQfVIJun2J5q9CIXPAlL95FSb0tJul7&amp;index=2
We’re on PATREON! Join the community https://www.patreon.com/itsokaytobesmart
↓↓↓ More info and sources below ↓↓↓

The biggest (and most mysterious!) migration in the world happens every night in the ocean as 10 billion tons of zooplankton swim to the surface to feed. This undersea journey is known as Diel vertical migration, and it occurs in every ocean in the world. By learning more about why this happens, science can unlock the secrets behind other phenomena, like our biological clocks…and even climate change.

SUBSCRIBE so you don’t miss a video! ►► http://bit.ly/iotbs_sub 

References: https://sites.google.com/view/earths-greatest-migration-refs/home

-----------

High fives to all our Brain Trust Patrons:

Millennial Glacier
paul andre bouis
Mark Littlehale
Ali Freiburger
Mehdi Damou
Barbora Bei
Burt Humburg
dani bowman
David Johnston
Salih Arslan
Baerbel Winkler
Robert Young
Eric Meer
Dustin
Karen Haskell


Join us on Patreon! 
https://patreon.com/itsokaytobesmart

Twitter 
http://www.twitter.com/DrJoeHanson
http://www.twitter.com/okaytobesmart 

Instagram 
http://www.instagram.com/DrJoeHanson 
http://www.instagram.com/okaytobesmart 

Merch
https://store.dftba.com/collections/its-okay-to-be-smart

Facebook
https://www.facebook.com/itsokaytobesmartpbs/

