# Source:Daily Wire, URL:https://www.dailywire.com/feeds/rss.xml, language:en-US

## Heather Mac Donald On Mass Acts Of Lawlessness: This Is What Happens When Leftists Call Police ‘Racist’
 - [https://www.dailywire.com/news/heather-mac-donald-on-mass-acts-of-lawlessness-this-is-what-happens-when-leftists-call-police-racist](https://www.dailywire.com/news/heather-mac-donald-on-mass-acts-of-lawlessness-this-is-what-happens-when-leftists-call-police-racist)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 19:06:04+00:00

Author and crime expert Heather Mac Donald said during an interview Tuesday night that recent acts of mass lawlessness in inner cities that have gone viral on social media are the direct result of the political Left&#8217;s demonization of law enforcement as &#8220;racist.&#8221; Mac Donald made the remarks during an interview with Fox News host ...

## Daily Wire Co-CEO Reveals Secret Cancel Blitz Against Matt Walsh, Brett Cooper, Michael Knowles
 - [https://www.dailywire.com/news/daily-wire-co-ceo-reveals-secret-cancel-blitz-against-matt-walsh-brett-cooper-michael-knowles](https://www.dailywire.com/news/daily-wire-co-ceo-reveals-secret-cancel-blitz-against-matt-walsh-brett-cooper-michael-knowles)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 18:52:10+00:00

Daily Wire co-CEO Jeremy Boreing shot back at Big Tech and the Left Wednesday, revealing an onslaught of cancellation campaigns targeting Daily Wire hosts Matt Walsh, Brett Cooper, and Michael Knowles. Boreing called out tech giants YouTube, Facebook, and TikTok for “capricious” fact-checks, demonetizations, and bans against the Daily Wire hosts. He also revealed that ...

## IRS Whistleblower Alleges Hunter Biden Probe Misconduct
 - [https://www.dailywire.com/news/irs-whistleblower-alleges-hunter-biden-probe-misconduct](https://www.dailywire.com/news/irs-whistleblower-alleges-hunter-biden-probe-misconduct)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 18:49:03+00:00

An Internal Revenue Service (IRS) agent claims the federal government&#8217;s criminal investigation into Hunter Biden is being corrupted by lies and politics. The allegations appeared Wednesday in a letter that the agent&#8217;s lawyer, Mark Lytle, sent to leaders of both parties in Congress. Though the letter only says the agent is overseeing the &#8220;ongoing and ...

## ‘Find Your Voices, Ladies’: Megyn Kelly Gets Fired Up, Issues Dire Warning To Women Over Allowing Trans-Identifying Men Into Their Spaces
 - [https://www.dailywire.com/news/find-your-voices-ladies-megyn-kelly-gets-fired-up-issues-dire-warning-to-women-over-allowing-trans-identifying-men-into-their-spaces](https://www.dailywire.com/news/find-your-voices-ladies-megyn-kelly-gets-fired-up-issues-dire-warning-to-women-over-allowing-trans-identifying-men-into-their-spaces)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 18:32:37+00:00

Megyn Kelly got fired up on her show Wednesday and said very loudly, &#8220;find your voices, ladies&#8221; as she warned women to defend their spaces from trans-identifying males. During Sirius XM’s “The Megyn Kelly Show&#8221; podcast, the host was speaking with her guests about an insane case involving a chapter of Kappa Kappa Gamma suing ...

## ESPN’s Samantha Ponder Bucks Network, Joins Those Slamming Men In Women’s Sports
 - [https://www.dailywire.com/news/espns-samantha-ponder-bucks-network-joins-those-slamming-men-in-womens-sports](https://www.dailywire.com/news/espns-samantha-ponder-bucks-network-joins-those-slamming-men-in-womens-sports)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 18:16:25+00:00

ESPN’s Samantha Ponder, bucking the trend at her network, spoke out against the inclusion of biological men in women’s sports. ESPN — which included Thomas in its celebration of Women’s History Month in March —  has been supportive of the transgender movement for years, firing baseball legend Curt Schilling in 2016 after he slammed critics ...

## FDNY Unleashes Robotic Dog On Search And Rescue Mission After Parking Garage Collapses In Lower Manhattan
 - [https://www.dailywire.com/news/fdny-unleashes-robotic-dog-on-search-and-rescue-mission-after-parking-garage-collapses-in-lower-manhattan](https://www.dailywire.com/news/fdny-unleashes-robotic-dog-on-search-and-rescue-mission-after-parking-garage-collapses-in-lower-manhattan)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 18:01:01+00:00

New York City firefighters unleashed a robotic K-9 unit named &#8220;Spot&#8221; to search for survivors covered in debris from the collapsed Lower Manhattan parking garage that killed one person and injured five others. Around 4:00 p.m. on Tuesday, the second floor of the five-story parking structure gave way and collapsed onto the ground floor on ...

## White House Will Host ‘Tennessee Three,’ But Has No Plans To Invite Covenant Victims
 - [https://www.dailywire.com/news/white-house-will-host-tennessee-three-but-has-no-plans-to-invite-covenant-victims](https://www.dailywire.com/news/white-house-will-host-tennessee-three-but-has-no-plans-to-invite-covenant-victims)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 17:50:32+00:00

White House Press Secretary Karine Jean-Pierre confirmed on Wednesday that President Joe Biden planned to meet with three Tennessee lawmakers who led an anti-gun protest inside the State House — but had no plans to meet with the victims of the Covenant School shooting that sparked the protest. Fox News White House correspondent Peter Doocy ...

## Wednesday Afternoon Update: Taxpayers Funding Taliban? Plus, GOP Debt Ceiling Offer And Alabama Shooting Update
 - [https://www.dailywire.com/news/wednesday-afternoon-update-taxpayers-funding-taliban-plus-gop-debt-ceiling-offer-and-alabama-shooting-update](https://www.dailywire.com/news/wednesday-afternoon-update-taxpayers-funding-taliban-plus-gop-debt-ceiling-offer-and-alabama-shooting-update)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 17:40:54+00:00

This article is adapted from today’s Morning Wire Afternoon Update. To listen to the podcast version, click here. Taxpayers Funding Taliban? On Wednesday, Special Inspector General for Afghanistan Reconstruction John Sopko warned before a House hearing that U.S. taxpayers may be aiding the Taliban in Afghanistan. Here with more is Daily Wire reporter Tim Pearce. Sopko ...

## 69% Of Americans Hold Negative View Of Economy
 - [https://www.dailywire.com/news/69-of-americans-hold-negative-view-of-economy](https://www.dailywire.com/news/69-of-americans-hold-negative-view-of-economy)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 17:28:24+00:00

A record 69% of Americans have a negative view of the economy, according to one poll. On Tuesday, CNBC released its All-America Economic Survey, revealing that nearly seven out of 10 Americans have a dour view of the economy. Two-thirds also believe that the U.S. is heading for a recession, and a similar amount of ...

## Kevin McCarthy Unveils Plan To ‘Responsibly’ Raise Debt Limit
 - [https://www.dailywire.com/news/kevin-mccarthy-unveils-plan-to-responsibly-raise-debt-limit](https://www.dailywire.com/news/kevin-mccarthy-unveils-plan-to-responsibly-raise-debt-limit)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 17:09:40+00:00

House Republicans released their long-awaited proposal to avert a debt ceiling crisis in a bid to end a standoff with the White House. The 320-page &#8220;Limit, Save, Grow Act of 2023,&#8221; introduced by GOP leadership on Wednesday, would lift the U.S. debt limit by $1.5 trillion or until March 31, 2024 — whichever comes first. ...

## A ‘Tsunami’ Of Commercial Pilot Retirements Is Coming, Experts Warn Congress
 - [https://www.dailywire.com/news/a-tsunami-of-commercial-pilot-retirements-is-coming-experts-warn-congress](https://www.dailywire.com/news/a-tsunami-of-commercial-pilot-retirements-is-coming-experts-warn-congress)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 17:06:43+00:00

The airline industry in the United States will see a worsening pilot shortage in the coming years as airmen retire and insufficient numbers of trainees are available to replace them, experts told members of the House Transportation and Infrastructure Committee on Wednesday. Commercial pilots were encouraged by their employers to retire as worldwide lockdowns and ...

## Young Chicago Couple Attacked By Teenage Mob Describes Altercation As ‘Very Random’ While Illinois Sen. Calls Violence ‘A Political Act’
 - [https://www.dailywire.com/news/young-chicago-couple-attacked-by-teenage-mob-describes-altercation-as-very-random-while-illinois-sen-calls-violence-a-political-act](https://www.dailywire.com/news/young-chicago-couple-attacked-by-teenage-mob-describes-altercation-as-very-random-while-illinois-sen-calls-violence-a-political-act)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 17:01:04+00:00

Unruly teenage crowds in downtown Chicago attacked and robbed a young couple last weekend — who called the unprovoked assault &#8220;very random” — as more than 100 teenagers rioted throughout the Windy City. The &#8220;Teen Takeover&#8221; produced several online videos showing young Chicagoans jumping on cars and buses, setting fires, and engaging in disruptive conduct ...

## Biden Now Punishing Americans With High Credit Scores To Subsidize Certain Homebuyers
 - [https://www.dailywire.com/news/biden-now-punishing-americans-with-high-credit-scores-to-subsidize-certain-homebuyers](https://www.dailywire.com/news/biden-now-punishing-americans-with-high-credit-scores-to-subsidize-certain-homebuyers)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 16:55:08+00:00

Just when you think the Biden administration can&#8217;t possibly have any more awful ideas, his team rolls out a plan to punish Americans with high credit scores to subsidize high-risk homebuyers. On Wednesday, The Washington Times reported that starting May 1, Americans purchasing a new home or refinancing their existing mortgage can expect to pay ...

## Civil War Enthusiast Pleads Guilty To Planting Bomb During Battle Reenactment
 - [https://www.dailywire.com/news/civil-war-enthusiast-pleads-guilty-to-planting-bomb-during-battle-reenactment](https://www.dailywire.com/news/civil-war-enthusiast-pleads-guilty-to-planting-bomb-during-battle-reenactment)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 16:52:07+00:00

A Civil War reenactor and self-identified member of Antifa pleaded guilty Tuesday to planting a bomb at a Virginia battlefield and to mailing threatening letters. Gerald Leonard Drake, of Winchester, Virginia, pleaded guilty to placing a pipe bomb at the Cedar Creek battlefield in Middletown, Virginia, back in 2017, according to the U.S. Attorney’s Office ...

## The Left’s Favorite Lie: Widespread White-On-Black Violence
 - [https://www.dailywire.com/news/the-lefts-favorite-lie-widespread-white-on-black-violence](https://www.dailywire.com/news/the-lefts-favorite-lie-widespread-white-on-black-violence)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 16:19:10+00:00

This week, a 16-year-old boy named Ralph Yarl – black – accidentally rang the doorbell of an 84-year-old white man, Andrew Lester. According to reports, Lester then shot Yarl twice through the door, wounding him in the head and the arm. According to Clay County prosecutor Zachary Thompson, “I can tell you there was a ...

## Project Veritas Releases ‘Disturbing’ Undercover Footage From Gender Clinics Offering Advice For Children
 - [https://www.dailywire.com/news/project-veritas-releases-disturbing-undercover-footage-from-gender-clinics-advising-10-year-old](https://www.dailywire.com/news/project-veritas-releases-disturbing-undercover-footage-from-gender-clinics-advising-10-year-old)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 15:56:52+00:00

Investigative journalist group Project Veritas on Wednesday released Part 1 of its series on the practices of gender clinics in the U.S., obtained via undercover video. Medical professionals appear to admit to treating children as young as eight years old for gender confusion they claim is transgenderism, recommending life-altering puberty blockers for a 10-year-old, and ...

## WATCH: Illinois Youth Wrestler Sucker Punched After Match While Going For Handshake
 - [https://www.dailywire.com/news/watch-illinois-youth-wrestler-sucker-punched-after-match-while-going-for-handshake](https://www.dailywire.com/news/watch-illinois-youth-wrestler-sucker-punched-after-match-while-going-for-handshake)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 15:53:01+00:00

Shocking video of a youth wrestler getting sucker punched after a wrestling match in Illinois started making the rounds on social media this week. The incident took place at the &#8220;Beat The Streets&#8221; tournament on April 8 at Oak Park River Forest High School in Oak Park, Illinois, per TMZ. This wrestling tournament included athletes ...

## ‘The Media Doesn’t Give A Damn About Most Black Victims’: Heather Mac Donald Talks New Equity Book On Ben Shapiro Show
 - [https://www.dailywire.com/news/the-media-doesnt-give-a-damn-about-most-black-victims-heather-mac-donald-talks-new-equity-book-on-ben-shapiro-show](https://www.dailywire.com/news/the-media-doesnt-give-a-damn-about-most-black-victims-heather-mac-donald-talks-new-equity-book-on-ben-shapiro-show)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 15:51:34+00:00

Heather Mac Donald ripped into how the media covers crime on The Ben Shapiro Show on Tuesday as she discussed her new book on equity. Mac Donald&#8217;s book, titled &#8220;When Race Trumps Merit: How the Pursuit of Equity Sacrifices Excellence, Destroys Beauty, and Threatens Lives,” is published by DW Books and came out on Tuesday. Mac ...

## Country Star’s Wife Shares Heartbreaking Post About Importance Of Teaching Babies To Swim After Losing 3-Year-Old Son
 - [https://www.dailywire.com/news/country-stars-wife-shares-heartbreaking-post-about-importance-of-teaching-babies-to-swim-after-losing-3-year-old-son](https://www.dailywire.com/news/country-stars-wife-shares-heartbreaking-post-about-importance-of-teaching-babies-to-swim-after-losing-3-year-old-son)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 15:19:01+00:00

Country star Granger Smith&#8217;s wife, Amber Smith, shared a heartbreaking post about the importance of teaching babies to swim after the couple lost their 3-year-old son to drowning in 2019. In a lengthy post shared on Instagram on Tuesday, Amber wrote that before she and the 43-year-old singer lost their son River in their backyard ...

## California’s Retirement Fund Once Pushed For Federal ESG Rules. Now They Say Fossil Fuel Divestment Hurts Retirees.
 - [https://www.dailywire.com/news/californias-retirement-fund-once-pushed-for-federal-esg-rules-now-they-say-fossil-fuel-divestment-hurts-retirees](https://www.dailywire.com/news/californias-retirement-fund-once-pushed-for-federal-esg-rules-now-they-say-fossil-fuel-divestment-hurts-retirees)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 15:10:24+00:00

The California Public Employees&#8217; Retirement System (CalPERS) recently opposed legislation that would require divestment from fossil fuel companies despite the agency’s support of the environmental, social, and corporate governance movement, also known as ESG. A bill submitted earlier this year by three California Democrats asserts that “efforts to obstruct climate stabilization policies” from fossil fuel ...

## ‘Reacher’ Star Talks Importance Of Faith-Based Films, Calls Theaters A New ‘Pulpit’
 - [https://www.dailywire.com/news/reacher-star-talks-importance-of-faith-based-films-calls-theaters-a-new-pulpit](https://www.dailywire.com/news/reacher-star-talks-importance-of-faith-based-films-calls-theaters-a-new-pulpit)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 14:51:37+00:00

&#8220;Reacher&#8221; and &#8220;The Hunger Games: Catching Fire&#8221; star Alan Ritchson talked about being a Christian in Hollywood and said it&#8217;s important that faith-based films are supported, calling movie theaters a new &#8220;pulpit.&#8221; The 40-year-old actor has been involved in the entertainment industry for the last 19 years and said he definitely wants to be &#8220;part of ...

## One Of Hollywood’s Original Nepo Babies Says She’ll Never Go Back To Acting
 - [https://www.dailywire.com/news/one-of-hollywoods-original-nepo-babies-says-shell-never-go-back-to-acting](https://www.dailywire.com/news/one-of-hollywoods-original-nepo-babies-says-shell-never-go-back-to-acting)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 14:48:42+00:00

Actress Bridget Fonda was born into one of the most well-established Hollywood dynasties, but after 21 years away from the film industry, the &#8220;Single White Female&#8221; actress and bona fide &#8220;nepo baby&#8221; says she has no intention of ever going back. Fonda is the daughter of Oscar-nominated actor Peter Fonda and Susan Brewer, the niece ...

## Jurors Hear Jailhouse Phone Call Between Lori Vallow Daybell And Son: ‘You Ripped My Heart Out’
 - [https://www.dailywire.com/news/jurors-hear-jailhouse-phone-call-between-lori-vallow-daybell-and-son-you-ripped-my-heart-out](https://www.dailywire.com/news/jurors-hear-jailhouse-phone-call-between-lori-vallow-daybell-and-son-you-ripped-my-heart-out)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 14:42:18+00:00

Jurors deciding the fate of Lori Vallow Daybell, the Idaho mom accused of killing her two children and fifth husband’s first wife, on Tuesday heard a jailhouse phone call between the accused murderer and her surviving son. The call, which was recorded in 2020 between Vallow Daybell and her oldest son Colby Ryan from her ...

## Katy Perry Gets Booed On ‘American Idol’ Over Her Criticism Of Another Contestant
 - [https://www.dailywire.com/news/katy-perry-gets-booed-on-american-idol-over-her-criticism-of-another-contestant](https://www.dailywire.com/news/katy-perry-gets-booed-on-american-idol-over-her-criticism-of-another-contestant)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 14:41:57+00:00

Katy Perry got loudly booed by the audience on the latest episode of  &#8220;American Idol&#8221; after she criticized another contestant, making it the first time in her tenure on the show that it happened to the celebrity judge. In clips of Monday&#8217;s show, the 38-year-old pop singer seemed less impressed with contestant Nutsa Buzaladze&#8217;s attire ...

## Woody Harrelson Throws Gasoline On The Fire: ‘There Is Some Veracity’ To Claims He And Matthew McConaughey Could Be Brothers
 - [https://www.dailywire.com/news/woody-harrelson-throws-gasoline-on-the-fire-there-is-some-veracity-to-claims-he-and-matthew-mcconaughey-could-be-brothers](https://www.dailywire.com/news/woody-harrelson-throws-gasoline-on-the-fire-there-is-some-veracity-to-claims-he-and-matthew-mcconaughey-could-be-brothers)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 14:23:44+00:00

Actor Woody Harrelson confirmed that there was &#8220;some veracity&#8221; to fellow actor and friend Matthew McConaughey&#8217;s claim that the two could be half-brothers — possibly sharing the same father – during a Tuesday interview. Harrelson appeared on Tuesday&#8217;s broadcast of &#8220;The Late Show with Stephen Colbert&#8221; and he told the host that McConaughey&#8217;s recent suggestion ...

## 2 Teenagers Arrested And Charged Over Deadly Alabama Sweet 16 Party Shooting
 - [https://www.dailywire.com/news/2-teenagers-arrested-and-charged-over-deadly-alabama-sweet-16-party-shooting](https://www.dailywire.com/news/2-teenagers-arrested-and-charged-over-deadly-alabama-sweet-16-party-shooting)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 14:19:14+00:00

Two teenagers have been arrested and charged in connection to the shooting over the weekend at a Sweet 16 party in a small Alabama town that killed four people and injured 32 others, authorities announced on Wednesday. A 17-year-old and 16-year-old, both of whom have the same last name and are from Tuskegee, Alabama, are charged ...

## Robert Kennedy Jr. Formally Announces 2024 Presidential Campaign, Vows To End The ‘Corrupt Merger Of State And Corporate Power’
 - [https://www.dailywire.com/news/robert-kennedy-jr-formally-announces-2024-presidential-campaign-vows-to-end-the-corrupt-merger-of-state-and-corporate-power](https://www.dailywire.com/news/robert-kennedy-jr-formally-announces-2024-presidential-campaign-vows-to-end-the-corrupt-merger-of-state-and-corporate-power)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 14:09:33+00:00

Robbert F. Kennedy Jr., the nephew of the late President John F. Kennedy, on Wednesday formally launched his 2024 Democratic presidential campaign, vowing to end the merger of state and corporate power. Kennedy is the son of Robert F. Kennedy, a former U.S. attorney general and U.S. senator assassinated while running for president in 1968. ...

## One-Third Of Canadian Government Employees Are On Strike, Causing Nationwide Headaches
 - [https://www.dailywire.com/news/one-third-of-canadian-government-employees-are-on-strike-causing-nationwide-headaches](https://www.dailywire.com/news/one-third-of-canadian-government-employees-are-on-strike-causing-nationwide-headaches)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 13:57:48+00:00

More than one-third of Canadian federal employees went on strike as the nation’s public sector union failed to reach an agreement with government officials on wage increases. Some 155,000 members of the Public Service Alliance of Canada started to strike across the country on Wednesday, inducing fears of disrupted government services such as passports and ...

## Candace Cameron Bure Shares Details About Upcoming Film That Honors U.S. Veterans
 - [https://www.dailywire.com/news/candace-cameron-bure-shares-details-about-upcoming-film-that-honors-u-s-veterans](https://www.dailywire.com/news/candace-cameron-bure-shares-details-about-upcoming-film-that-honors-u-s-veterans)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 13:47:43+00:00

Candace Cameron Bure told her followers on Tuesday that her upcoming film, &#8220;My Christmas Hero,&#8221; will honor U.S. veterans. The 47-year-old actress posted a screenshot of a headline from Deadline magazine that read, &#8220;Candace Cameron Bure To Play U.S. Army Reservist In Next Great American Family Holiday Movie.&#8221; She captioned her post, &#8220;Very excited to ...

## Biden Admin Internal Email Warned Trans People Face ‘Increasing Attacks’ Days After Nashville Shooting
 - [https://www.dailywire.com/news/biden-admin-internal-email-warned-trans-people-face-increasing-attacks-days-after-nashville-shooting](https://www.dailywire.com/news/biden-admin-internal-email-warned-trans-people-face-increasing-attacks-days-after-nashville-shooting)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 13:41:20+00:00

The Biden administration sent an internal email warning that transgender people face &#8220;increasing attacks&#8221; just days after a trans-identified shooter killed six people at a Christian school in Nashville. The email was sent by the Equal Employment Opportunity Commission (EEOC), a federal agency that works to enforce federal civil rights laws against workplace discrimination. The communication ...

## ‘I’ll Never Do That Again’: Nicolas Cage Admits He Ate A Real Cockroach On Film
 - [https://www.dailywire.com/news/ill-never-do-that-again-nicolas-cage-admits-he-ate-a-real-cockroach-on-film](https://www.dailywire.com/news/ill-never-do-that-again-nicolas-cage-admits-he-ate-a-real-cockroach-on-film)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 13:21:57+00:00

Actor Nicolas Cage recently admitted that the cockroach he ate in 1988&#8217;s &#8220;Vampire&#8217;s Kiss&#8221; was real — and that director Robert Bierman had made him do a second take, in which he had to eat a second cockroach, as a sort of prank. Cage, who stars as the infamous Count Dracula in the recently-released horror ...

## ‘Alarming’: Lawyer For California Church Responds After Million Dollar COVID Fine Handed Down
 - [https://www.dailywire.com/news/alarming-lawyer-for-california-church-responds-after-million-dollar-covid-fine-handed-down](https://www.dailywire.com/news/alarming-lawyer-for-california-church-responds-after-million-dollar-covid-fine-handed-down)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 13:18:48+00:00

A lawyer representing a California church recently ordered to pay $1.2 million in COVID fines responded to the ruling this week, saying that the case has major First Amendment ramifications. Mariah Gondeiro, a lawyer with Advocates for Faith and Freedom representing Calvary Chapel San Jose, told The Daily Wire on Tuesday that she believed the church ...

## European Lawmakers Strike A Deal For Their Own Semiconductor Bill After Criticizing American Version
 - [https://www.dailywire.com/news/european-lawmakers-strike-a-deal-for-their-own-semiconductor-bill-after-criticizing-american-version](https://www.dailywire.com/news/european-lawmakers-strike-a-deal-for-their-own-semiconductor-bill-after-criticizing-american-version)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 12:50:50+00:00

European lawmakers reached a deal Tuesday on a semiconductor stimulus bill meant as an answer to the CHIPS and Science Act, a similar package enacted in the United States that prioritized domestic semiconductor firms. The European Chips Act will mobilize some $47 billion of public and private investments into semiconductors such that the European Union ...

## Afghanistan Inspector General Warns U.S. May Be Funding Taliban
 - [https://www.dailywire.com/news/afghanistan-inspector-general-warns-u-s-may-be-funding-taliban](https://www.dailywire.com/news/afghanistan-inspector-general-warns-u-s-may-be-funding-taliban)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 12:29:09+00:00

A government watchdog told Congress on Wednesday the Taliban may be stealing money from the billions of dollars from U.S. taxpayers meant to help the people of Afghanistan. Special Inspector General for Afghanistan Reconstruction (SIGAR) John Sopko issued the warning during a hearing before the House Oversight Committee alongside other inspectors general. &#8220;Unfortunately, as I ...

## Biden’s Labor Secretary Nominee Supported California Law Gutting Independent Work
 - [https://www.dailywire.com/news/bidens-labor-secretary-nominee-supported-california-law-gutting-independent-work](https://www.dailywire.com/news/bidens-labor-secretary-nominee-supported-california-law-gutting-independent-work)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 11:59:42+00:00

Deputy Labor Secretary Julie Su, who President Joe Biden nominated to replace Labor Secretary Marty Walsh, will defend her previous support of a controversial law in California that cracked down on freelancers as she seeks confirmation in the Senate. California Assembly Bill 5 entered into effect last year after a prolonged series of court battles, ...

## Former Teen Reality Star Kristin Cavallari Forbid Children From Acting Until 18: ‘I Just Want Them To Be Kids’
 - [https://www.dailywire.com/news/former-teen-reality-star-kristin-cavallari-forbid-children-from-acting-until-18-i-just-want-them-to-be-kids](https://www.dailywire.com/news/former-teen-reality-star-kristin-cavallari-forbid-children-from-acting-until-18-i-just-want-them-to-be-kids)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 11:53:31+00:00

Former reality star Kristin Cavallari said her kids aren’t allowed to pursue fame, even through YouTube channels, until they’re 18. The star of MTV’s “Laguna Beach” and “The Hills” made the comments during an episode of “The Jennifer Hudson Show” on Wednesday, per The Daily Mail.  Cavallari said her three kids, 10-year-old son Camden, 8-year-old ...

## ‘Just Nasty’: Rachel McAdams Draws Criticism For Body Hair In Unretouched Photos
 - [https://www.dailywire.com/news/just-nasty-rachel-mcadams-draws-criticism-for-body-hair-in-unretouched-photos](https://www.dailywire.com/news/just-nasty-rachel-mcadams-draws-criticism-for-body-hair-in-unretouched-photos)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 11:25:23+00:00

Fans of Hollywood A-lister Rachel McAdams were a bit taken aback by images from her photoshoot published Tuesday.  The 44-year-old actress posed for Bustle while promoting her new movie, “Are You There God? It’s Me, Margaret,” which is based on the classic Judy Blume novel of the same name. McAdams appeared in the images with ...

## BlackRock Hit With Federal Civil Rights Complaint Over Alleged Racist Hiring
 - [https://www.dailywire.com/news/blackrock-hit-with-federal-civil-rights-complaint-over-alleged-racist-hiring](https://www.dailywire.com/news/blackrock-hit-with-federal-civil-rights-complaint-over-alleged-racist-hiring)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 11:16:14+00:00

BlackRock was hit with a federal civil rights complaint on Tuesday in response to the asset management behemoth’s diversity, equity, and inclusion commitments, also known as DEI. America First Legal, a conservative advocacy organization launched by former Trump administration senior adviser Stephen Miller, filed the complaint with the Equal Employment Opportunity Commission, which is charged ...

## Jake Gyllenhaal On Why He’s Drawn To Military Roles Like ‘The Covenant’: ‘So Much Pride And Love’
 - [https://www.dailywire.com/news/jake-gyllenhaal-on-why-hes-drawn-to-military-roles-like-the-covenant-so-much-pride-and-love](https://www.dailywire.com/news/jake-gyllenhaal-on-why-hes-drawn-to-military-roles-like-the-covenant-so-much-pride-and-love)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 10:22:45+00:00

Actor Jake Gyllenhaal recently discussed why he’s drawn to military roles ahead of the release of his new film, “The Covenant.” &#8220;At the beginning of my career, I played a Marine, a recruit, and I got to know a lot of people in the military and learned from them,&#8221; the 42-year-old actor told the Associated ...

## Studies On Transgenderism In Kids Show Pressure, Social Contagion The Main Cause
 - [https://www.dailywire.com/news/studies-on-transgenderism-in-kids-show-pressure-social-contagion-the-main-cause](https://www.dailywire.com/news/studies-on-transgenderism-in-kids-show-pressure-social-contagion-the-main-cause)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 10:19:24+00:00

Indiana and Idaho recently became the latest states to sign laws banning transgender surgeries and treatments for minors. They join 10 other red states to pass such bills this year alone, while at least a dozen more are considering them. The issue has sparked fierce debate throughout the medical community, with some hospital directors and ...

## No, Nancy, It’s Not Sexist To Ask An 89-Year-Old Senator We Pay $174,000 For Doing Nothing To Resign
 - [https://www.dailywire.com/news/no-nancy-its-not-sexist-to-ask-an-89-year-old-senator-we-pay-174000-for-doing-nothing-to-resign](https://www.dailywire.com/news/no-nancy-its-not-sexist-to-ask-an-89-year-old-senator-we-pay-174000-for-doing-nothing-to-resign)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 10:09:58+00:00

Sen. Dianne Feinstein (D-CA) entered politics in 1970 when she was 37. Ever since then, she&#8217;s nursed off the public teat, paid by taxpayers. She&#8217;s been in the U.S. Senate for more than 30 years and is set to serve until 2025. This past February, Feinstein, 89, decided to retire after finishing her term. &#8220;The ...

## Elon Musk: ‘Abortions’ Are A Threat To Mankind’s Existence
 - [https://www.dailywire.com/news/elon-musk-abortions-are-a-threat-to-mankinds-existence](https://www.dailywire.com/news/elon-musk-abortions-are-a-threat-to-mankinds-existence)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 10:04:33+00:00

Twitter CEO Elon Musk told Fox News host Tucker Carlson this week that birth control and abortions are keeping humans from reproducing, and warned that civilization could end &#8220;with a whimper in adult diapers.&#8221; Musk, who has warned for years about declining birth rates, said that &#8220;there&#8217;s sort of a life cycle arc to civilizations, just as ...

## Riley Gaines Skewers Lia Thomas Over Trans Swimmer’s Latest ‘Heartbreaking’ Claim
 - [https://www.dailywire.com/news/riley-gaines-skewers-lia-thomas-over-trans-swimmers-latest-heartbreaking-claim](https://www.dailywire.com/news/riley-gaines-skewers-lia-thomas-over-trans-swimmers-latest-heartbreaking-claim)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 09:26:36+00:00

Former All-American swimmer Riley Gaines lashed out at rival Lia Thomas after the transgender-identifying athlete complained that &#8220;trans kids lose out on opportunities” because many states and athletic bodies have barred biological males from competing against females. In an appearance on “Piers Morgan Uncensored,” Gaines, a former University of Kentucky star, cited the words of ...

## ‘Should Transgenderism Be Regulated By Law?’: Michael Knowles Debates Trans Issues At Pitt
 - [https://www.dailywire.com/news/should-transgenderism-be-regulated-by-law-michael-knowles-debates-trans-issues-at-pitt](https://www.dailywire.com/news/should-transgenderism-be-regulated-by-law-michael-knowles-debates-trans-issues-at-pitt)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 09:06:29+00:00

Daily Wire host Michael Knowles faced off Tuesday night against libertarian journalist Brad Polumbo at the University of Pittsburgh in a debate about the proper extent of the state’s power to regulate transgenderism. Polumbo was a last-minute substitute — Knowles&#8217; previously scheduled opponent, Deirdre McCloskey, a professor of economics at the University of Illinois-Chicago who ...

## Elon Musk Gives Surprising Answer On Evidence Of Alien Life
 - [https://www.dailywire.com/news/elon-musk-gives-surprising-answer-on-evidence-of-alien-life](https://www.dailywire.com/news/elon-musk-gives-surprising-answer-on-evidence-of-alien-life)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 08:48:48+00:00

SpaceX CEO Elon Musk said during an interview this week that he has seen no evidence anywhere in the universe that suggests that aliens are real. Musk told Fox News host Tucker Carlson that &#8220;if anyone would know about aliens on Earth it would probably be me.&#8221; &#8220;To the best of my knowledge, we see ...

## Disgraced Ex-Biden Official Sam Brinton Could Avoid Jail In Second Felony Theft Case: Report
 - [https://www.dailywire.com/news/disgraced-ex-biden-official-sam-brinton-could-avoid-jail-in-second-felony-theft-case-report](https://www.dailywire.com/news/disgraced-ex-biden-official-sam-brinton-could-avoid-jail-in-second-felony-theft-case-report)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 07:36:09+00:00

Disgraced former Biden Energy Department official Samuel Brinton reportedly agreed in court this week to undergo a mental health evaluation as part of an adult diversion program in the felony baggage theft case that he faces in Minnesota. Brinton was originally charged with felony theft in two separate cases late last year for allegedly stealing ...

## Knowles Unfazed As Pro-Trans Protesters Bid To Disrupt Pitt Debate
 - [https://www.dailywire.com/news/knowles-unfazed-as-pro-trans-protesters-bid-to-disrupt-pitt-debate](https://www.dailywire.com/news/knowles-unfazed-as-pro-trans-protesters-bid-to-disrupt-pitt-debate)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 07:35:57+00:00

Hundreds of pro-transgenderism protesters tried to disrupt a Tuesday night debate featuring Daily Wire host Michael Knowles at the University of Pittsburgh, setting off smoke bombs and chanting in an effort to derail the event. Knowles was at the school’s O’Hara Student Center to debate journalist Brad Polumbo in an event sponsored by the Pitt ...

## Elon Musk Predicts Dire Financial Situation For U.S. Later This Year
 - [https://www.dailywire.com/news/elon-musk-predicts-dire-financial-situation-for-u-s-later-this-year](https://www.dailywire.com/news/elon-musk-predicts-dire-financial-situation-for-u-s-later-this-year)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-19 00:08:41+00:00

Twitter CEO Elon Musk said during an interview Tuesday night that he believes that the U.S. might be on the verge of serious financial issues later this year due to a variety of factors. Speaking to Fox News host Tucker Carlson, Musk said that the collapse of some major banking institutions like Silicon Valley Bank ...

