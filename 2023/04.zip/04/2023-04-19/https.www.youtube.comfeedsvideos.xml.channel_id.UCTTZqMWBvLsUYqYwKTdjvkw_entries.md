# Source:Mateusz Chrobok, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw, language:pl-PL

## 🚰 Zatruta woda: hakerzy czy wpadka?
 - [https://www.youtube.com/watch?v=o0QTJV5cR9k](https://www.youtube.com/watch?v=o0QTJV5cR9k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw
 - date published: 2023-04-19 04:00:31+00:00

W lutym dwa tysiące dwudziestego pierwszego roku media obiegła sensacyjna wiadomość o hakerach, którzy próbowali zmienić parametry wody w zakładzie jej uzdatniania na Florydzie. Nic dziwnego, że sprawa odbiła się szerokim echem, bo to niesie za sobą potencjalnie znacznie większe konsekwencje niż zaatakowanie oprogramowaniem ransomware jakiejś korporacji.


Źródło:
http://bit.ly/3UsNgCM


#oldsmar #hackowanie #cyberprzestępczość #badactor

