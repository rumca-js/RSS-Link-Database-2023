# Source:Eliminate, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCI7kKmUuSQOHUvSWIYFDf1Q, language:en-US

## Let Him Cook
 - [https://www.youtube.com/watch?v=e6McW4TNRSI](https://www.youtube.com/watch?v=e6McW4TNRSI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCI7kKmUuSQOHUvSWIYFDf1Q
 - date published: 2023-04-19 19:30:59+00:00

bassline gonna make man ______

AtRysk:
https://soundcloud.com/atrysk

sample credit: https: https://twitter.com/itsmewnz/status/1644707350618701827

I stream every Tuesday/Wednesday/Thursday 1pm PST

• TWITCH: https://www.twitch.tv/eliminatehq
• DISCORD: https://discord.gg/eliminatehq
• MY SAMPLE PACK: https://splice.com/sounds/disciple-samples/eliminate-cyber-trap-vol-1?sound_type=sample
• INSTAGRAM: https://www.instagram.com/eliminatemusic/
• TWITTER: https://twitter.com/eliminatemusic
• SUBREDDIT: https://www.reddit.com/r/EliminateHQ/


top secret burner account:
https://soundcloud.com/dubsteptractor

