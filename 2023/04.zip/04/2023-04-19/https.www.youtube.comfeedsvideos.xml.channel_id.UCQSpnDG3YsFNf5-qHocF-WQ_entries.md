# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## ⚠️ ANOTHER Urgent Video ⚠️ A SECOND Chromium Exploit  - UPDATE NOW!
 - [https://www.youtube.com/watch?v=qJ08sst7kco](https://www.youtube.com/watch?v=qJ08sst7kco)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2023-04-19 20:02:34+00:00

No this isn't Deja vu, there is yet another Chrome browser zero-day exploit that needs to be patched!

• The Previous Video: https://www.youtube.com/watch?v=v8t4R-8KAKM
▼ Time Stamps: ▼
0:00 - What to Do
1:04 - About the Exploit
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Merch ⇨ https://teespring.com/stores/thiojoe
⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV
My Gear & Equipment ⇨ https://kit.co/ThioJoe
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

