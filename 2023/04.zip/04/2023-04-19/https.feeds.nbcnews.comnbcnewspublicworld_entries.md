# Source:NBC world, URL:https://feeds.nbcnews.com/nbcnews/public/world, language:en-US

## Warsaw Ghetto Uprising commemorated on 80th anniversary
 - [https://www.nbcnews.com/news/world/warsaw-ghetto-uprising-commemorated-80th-anniversary-rcna80392](https://www.nbcnews.com/news/world/warsaw-ghetto-uprising-commemorated-80th-anniversary-rcna80392)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/world
 - date published: 2023-04-19 13:55:12+00:00

Presidents and Holocaust survivors and their descendants commemorated the 80th anniversary of the Warsaw Ghetto Uprising on Wednesday with a poignant sense that the responsibility for carrying on the memory of the Holocaust is passing from the witnesses to younger generations.

## Stranded fishermen rescued after days without food or water off Australia but 8 feared dead
 - [https://www.nbcnews.com/news/world/indonesian-fishermen-rescued-cyclone-ilsa-australia-rcna80383](https://www.nbcnews.com/news/world/indonesian-fishermen-rescued-cyclone-ilsa-australia-rcna80383)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/world
 - date published: 2023-04-19 12:31:10+00:00

Eight Indonesian fishermen are feared drowned and another 11 have been rescued after spending almost a week without food or water on a barren island off the northwest Australian coast in the wake of a powerful tropical cyclone, authorities said Wednesday.

## Fighting erupts in Khartoum despite planned cease-fire
 - [https://www.nbcnews.com/video/fighting-erupts-in-khartoum-despite-planned-cease-fire-170666565625](https://www.nbcnews.com/video/fighting-erupts-in-khartoum-despite-planned-cease-fire-170666565625)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/world
 - date published: 2023-04-19 12:02:44+00:00

Fighting between forces loyal to dueling generals raged for a fifth day in Sudan, hours after a truce was supposed to have come into effect. The one-day humanitarian cease-fire was planned to bring a period of relief to millions of Sudanese trapped at home with dwindling supplies.

## Video shows people using tied bedsheets to escape from a Beijing hospital fire
 - [https://www.nbcnews.com/video/video-shows-people-using-tied-bedsheets-to-escape-beijing-hospital-fire-170661445735](https://www.nbcnews.com/video/video-shows-people-using-tied-bedsheets-to-escape-beijing-hospital-fire-170661445735)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/world
 - date published: 2023-04-19 10:13:30+00:00

Dramatic cellphone video showed people using tied bedsheets to climb down the walls to escape smoke and flames after a fire broke out at a Beijing hospital.

## Fishermen rescued after being stranded for six days on a barren island off Australia
 - [https://www.nbcnews.com/video/fishermen-rescued-after-being-stranded-for-six-days-on-a-barren-island-170660421635](https://www.nbcnews.com/video/fishermen-rescued-after-being-stranded-for-six-days-on-a-barren-island-170660421635)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/world
 - date published: 2023-04-19 09:17:09+00:00

A group of 11  Indonesian fishermen were rescued from a remote island off Western Australia after two fishing vessels were caught in a tropical cyclone. According to a statement from Australian Maritime Safety Authority, an aircraft was diverted to rescue the fishermen from Bedwell Island. They had been stranded for six days without food and water.

## Fire kills more than two dozen patients in Beijing hospital
 - [https://www.nbcnews.com/news/world/fire-kills-two-dozen-patients-beijing-hospital-rcna80363](https://www.nbcnews.com/news/world/fire-kills-two-dozen-patients-beijing-hospital-rcna80363)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/world
 - date published: 2023-04-19 08:36:09+00:00

The death toll rose to 29 on Wednesday from a fire at a Beijing hospital that was one of the Chinese capital’s deadliest in at least two decades.

## Kim Jong Un says North Korea’s 1st spy satellite is ready for launch
 - [https://www.nbcnews.com/news/world/kim-jong-un-says-north-koreas-1st-spy-satellite-ready-launch-rcna80365](https://www.nbcnews.com/news/world/kim-jong-un-says-north-koreas-1st-spy-satellite-ready-launch-rcna80365)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/world
 - date published: 2023-04-19 08:29:59+00:00

North Korean leader Kim Jong Un said his country has built its first-ever military spy satellite and that he planned to launch it on an undisclosed date, state media reported Wednesday.

## India to overtake China as the world’s most populous country by mid-2023, U.N. says
 - [https://www.nbcnews.com/news/world/india-overtakes-china-worlds-most-populous-country-rcna80364](https://www.nbcnews.com/news/world/india-overtakes-china-worlds-most-populous-country-rcna80364)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/world
 - date published: 2023-04-19 08:25:54+00:00

India is on its way to become the world’s most populous country, overtaking China with almost 3 million more people in the middle of this year, data released on Wednesday by the United Nations showed.

