# Source:LMG Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFLFc8Lpbwt4jPtY1_Ai5yA, language:en-US

## Good Luck Stopping AI
 - [https://www.youtube.com/watch?v=rF_MktZK3PM](https://www.youtube.com/watch?v=rF_MktZK3PM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFLFc8Lpbwt4jPtY1_Ai5yA
 - date published: 2023-04-19 16:00:38+00:00

Universal Music Group tells streaming platforms to block AI scraping. 

Watch the full WAN Show: https://www.youtube.com/watch?v=T5PNAeE6fOY

► GET MERCH: https://lttstore.com
► LTX 2023 TICKETS AVAILABLE NOW: https://lmg.gg/ltx23
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► OUR WAN PODCAST GEAR: https://lmg.gg/wanset
 
FOLLOW US ON SOCIAL
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
TikTok (LMG Clips): www.tiktok.com/@_lmgclips_
Twitch: https://www.twitch.tv/linustech

## Linus gets sticker shock
 - [https://www.youtube.com/watch?v=rXeYl75jROU](https://www.youtube.com/watch?v=rXeYl75jROU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFLFc8Lpbwt4jPtY1_Ai5yA
 - date published: 2023-04-19 16:00:30+00:00

Question: in what niche market have you encountered serious sticker shock?

Watch the full WAN Show: https://www.youtube.com/watch?v=T5PNAeE6fOY

► GET MERCH: https://lttstore.com
► LTX 2023 TICKETS AVAILABLE NOW: https://lmg.gg/ltx23
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► OUR WAN PODCAST GEAR: https://lmg.gg/wanset
 
FOLLOW US ON SOCIAL
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
TikTok (LMG Clips): www.tiktok.com/@_lmgclips_
Twitch: https://www.twitch.tv/linustech

## Are GPUs Even Worth it Anymore?
 - [https://www.youtube.com/watch?v=94SLImnYYRQ](https://www.youtube.com/watch?v=94SLImnYYRQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFLFc8Lpbwt4jPtY1_Ai5yA
 - date published: 2023-04-19 16:00:06+00:00

The RTX 4070 has been released – what’s the future of GPUs?

Watch the full WAN Show: https://www.youtube.com/watch?v=T5PNAeE6fOY

► GET MERCH: https://lttstore.com
► LTX 2023 TICKETS AVAILABLE NOW: https://lmg.gg/ltx23
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► OUR WAN PODCAST GEAR: https://lmg.gg/wanset
 
FOLLOW US ON SOCIAL
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
TikTok (LMG Clips): www.tiktok.com/@_lmgclips_
Twitch: https://www.twitch.tv/linustech

