# Source:TVN24 Z kraju, URL:https://tvn24.pl/wiadomosci-z-kraju,3.xml, language:pl-PL

## Dwa zjawiska w jednym. Do hybrydowego zaćmienia Słońca zostało kilka godzin
 - [https://tvn24.pl/tvnmeteo/swiat/hybrydowe-zacmienie-slonca-2023-dwa-zjawiska-w-jednym-szczegoly-6950119?source=rss](https://tvn24.pl/tvnmeteo/swiat/hybrydowe-zacmienie-slonca-2023-dwa-zjawiska-w-jednym-szczegoly-6950119?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 19:47:23+00:00

<img alt="Dwa zjawiska w jednym. Do hybrydowego zaćmienia Słońca zostało kilka godzin " src="https://tvn24.pl/najnowsze/cdn-zdjecie-kl56cl-zacmienie-slonca-zdjecie-pogladowe-6950125/alternates/LANDSCAPE_1280" />
    Już niebawem hybrydowe zaćmienie Słońca. To niezwykle rzadkie zjawisko pojawi się w niektórych częściach świata. Kiedy i gdzie będzie można je podziwiać? Sprawdź szczegóły.

## Wielka Synagoga pojawiła się na błękitnym wieżowcu
 - [https://tvn24.pl/tvnwarszawa/srodmiescie/warszawska-projekcja-wielkiej-synagogi-na-placu-bankowym-6950074?source=rss](https://tvn24.pl/tvnwarszawa/srodmiescie/warszawska-projekcja-wielkiej-synagogi-na-placu-bankowym-6950074?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 19:45:16+00:00

<img alt="Wielka Synagoga pojawiła się na błękitnym wieżowcu" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-44j627-warszawska-wielka-synagoga-na-placu-bankowym-6950121/alternates/LANDSCAPE_1280" />
    W środę wieczorem na ścianie błękitnego wieżowca przy placu Bankowym pojawił się obraz Wielkiej Synagogi. Ten wirtualny pomnik przypomina o przedwojennej żydowskiej społeczności oraz o nieistniejącej części miasta.

## Najstarsze osobniki mamuta włochatego mogły wyglądać inaczej, niż sobie wyobrażamy
 - [https://tvn24.pl/tvnmeteo/nauka/najstarsze-osobniki-mamuta-wlochatego-mogly-wygladac-inaczej-niz-sobie-wyobrazamy-6949858?source=rss](https://tvn24.pl/tvnmeteo/nauka/najstarsze-osobniki-mamuta-wlochatego-mogly-wygladac-inaczej-niz-sobie-wyobrazamy-6949858?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 18:24:15+00:00

<img alt="Najstarsze osobniki mamuta włochatego mogły wyglądać inaczej, niż sobie wyobrażamy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-g6ac5r-mamut-wlochaty-6949965/alternates/LANDSCAPE_1280" />
    Nowe badania podają w wątpliwość nasze wyobrażenia o pierwszych mamutach włochatych (Mammuthus primigenius). Najstarsze osobniki mogły wyglądać zupełnie inaczej - miały mniej puszyste futro, mniejsze pokłady tłuszczu i większe uszy. Niektóre z tych cech zmieniły się na drodze ewolucji i przystosowań do trudnego klimatu Syberii.

## Mają ochronić połowę ludności Polski. Jest projekt rozporządzenia
 - [https://tvn24.pl/biznes/nieruchomosci/schrony-i-obiekty-ochrony-zbiorowej-projekt-rozporzadzenia-mswia-6950023?source=rss](https://tvn24.pl/biznes/nieruchomosci/schrony-i-obiekty-ochrony-zbiorowej-projekt-rozporzadzenia-mswia-6950023?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 18:08:22+00:00

<img alt="Mają ochronić połowę ludności Polski. Jest projekt rozporządzenia" src="https://tvn24.pl/najnowsze/cdn-zdjecie-35w7nl-shutterstock_2095367044-6949948/alternates/LANDSCAPE_1280" />
    Ministerstwo Spraw Wewnętrznych i Administracji przygotowało projekt rozporządzenia dotyczącego obiektów zbiorowej ochrony, w tym schronów. W proponowanych przepisach określono między innymi warunki techniczne takich obiektów oraz zasady ich projektowania i budowy. Według założeń schrony i ukrycia zapewnią ochronę dla 50 procent ludności kraju.

## Satelita NASA spadnie na Ziemię. Niektóre części mogą nie spłonąć w atmosferze
 - [https://tvn24.pl/tvnmeteo/swiat/nasa-satelita-rhessi-spadnie-na-ziemie-niektore-czesci-moga-nie-splonac-w-atmosferze-6949278?source=rss](https://tvn24.pl/tvnmeteo/swiat/nasa-satelita-rhessi-spadnie-na-ziemie-niektore-czesci-moga-nie-splonac-w-atmosferze-6949278?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 17:45:38+00:00

<img alt="Satelita NASA spadnie na Ziemię. Niektóre części mogą nie spłonąć w atmosferze" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-j0y3p0-rhessi-nad-ziemia-wizualizacja-6949350/alternates/LANDSCAPE_1280" />
    Wycofany z eksploatacji satelita NASA spadnie w nocy ze środy na czwartek na Ziemię. Wstępne prognozy wskazują, że nie wszystkie elementy urządzenia spłoną podczas wejścia w atmosferę, jednak specjaliści są przekonani, że prawdopodobieństwo, iż wyrządzą one komukolwiek krzywdę, jest bardzo małe.

## Skuterzysta zderzył się z autem, śmigłowiec zabrał go do szpitala
 - [https://tvn24.pl/tvnwarszawa/ulice/nowy-prazmow-na-mazowszu-skuterzysta-w-szpitalu-po-zderzeniu-z-autem-6949913?source=rss](https://tvn24.pl/tvnwarszawa/ulice/nowy-prazmow-na-mazowszu-skuterzysta-w-szpitalu-po-zderzeniu-z-autem-6949913?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 17:01:42+00:00

<img alt="Skuterzysta zderzył się z autem, śmigłowiec zabrał go do szpitala" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-me2q0n-poszkodowany-zostal-zabrany-smiglowcem-do-szpitala-6949914/alternates/LANDSCAPE_1280" />
    W Nowym Prażmowie niedaleko Piaseczna kierujący jednośladem zderzył się z autem osobowym. Do szpitala zabrał go śmigłowiec Lotniczego Pogotowia Ratunkowego.

## Pogoda na jutro - czwartek 20.04. Deszcz popada tylko lokalnie, od 14 do 18 stopni
 - [https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-jutro-czwartek-2004-deszcz-popada-tylko-lokalnie-od-14-do-18-stopni-6949906?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-jutro-czwartek-2004-deszcz-popada-tylko-lokalnie-od-14-do-18-stopni-6949906?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 17:00:00+00:00

<img alt="Pogoda na jutro - czwartek 20.04. Deszcz popada tylko lokalnie, od 14 do 18 stopni" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-jutqdd-pogodnie-slonecznie-cieplo-6949953/alternates/LANDSCAPE_1280" />
    Pogoda na jutro. W czwartek 20.04 czeka nas sporo chwil ze słońcem. Słabe i przelotne opady deszczu prognozowane są jedynie w zachodniej części kraju. Termometry wskażą od 14 do 18 stopni Celsjusza, a biomet będzie korzystny.

## Gdzie jest burza? Wieczór pod znakiem wyładowań
 - [https://tvn24.pl/tvnmeteo/pogoda/gdzie-jest-burza-burze-w-polsce-w-srode-1904-sprawdz-gdzie-jest-burza-mapa-i-radar-burz-6949907?source=rss](https://tvn24.pl/tvnmeteo/pogoda/gdzie-jest-burza-burze-w-polsce-w-srode-1904-sprawdz-gdzie-jest-burza-mapa-i-radar-burz-6949907?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 16:31:32+00:00

<img alt="Gdzie jest burza? Wieczór pod znakiem wyładowań" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-uaivkm-burze-w-polsce-19042023-6949911/alternates/LANDSCAPE_1280" />
    Gdzie jest burza? W środę wieczorem do naszego kraju dotarły wyładowania atmosferyczne. Sprawdź, gdzie jest burza, i śledź aktualną sytuację pogodową w kraju na tvnmeteo.pl.

## Polsko-izraelsko spotkania młodzieży. "Dwustronne i partnerskie" porozumienie
 - [https://tvn24.pl/polska/polska-izrael-ministrowie-edukacji-i-nauki-przemyslaw-czarnek-i-joaw-kisz-podpisali-deklaracje-w-sprawie-spotkan-mlodziez-6949831?source=rss](https://tvn24.pl/polska/polska-izrael-ministrowie-edukacji-i-nauki-przemyslaw-czarnek-i-joaw-kisz-podpisali-deklaracje-w-sprawie-spotkan-mlodziez-6949831?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 16:26:36+00:00

<img alt="Polsko-izraelsko spotkania młodzieży. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-u535x1-ministrowie-edukacji-i-nauki-izraela-i-polski-joaw-kisz-i-przemyslaw-czarnek-podczas-spotkania-w-gmachu-mein-w-warszawie-6949850/alternates/LANDSCAPE_1280" />
    Ministrowie edukacji i nauki Polski i Izraela podpisali deklarację w sprawie spotkań młodzieży. - Potrzebujemy znakomitych relacji pomiędzy Polską i Izraelem, ale relacji, które będą przyszłościowe, a te muszą budować nasi młodzi mieszkańcy Polski i Izraela - powiedział minister Czarnek. Jego izraelski odpowiednik Jo'aw Kisz dodał, że porozumienie dotyczy tego, aby oba narody "uczyły się od siebie wzajemnie o wspólnej historii, przeszłości i wspólnie działały".

## Samochód uderzył w drzewo na krajowej "50"
 - [https://tvn24.pl/tvnwarszawa/ulice/zyrow-dk-50-samochod-uderzyl-w-drzewo-6949777?source=rss](https://tvn24.pl/tvnwarszawa/ulice/zyrow-dk-50-samochod-uderzyl-w-drzewo-6949777?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 15:35:33+00:00

<img alt="Samochód uderzył w drzewo na krajowej " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-vpw4f3-samochod-uderzyl-w-drzewo-6949767/alternates/LANDSCAPE_1280" />
    W miejscowości Żyrów, na trasie pomiędzy Grójcem i Górą Kalwarią, samochód uderzył w drzewo. Nikomu nic się nie stało, ale policja wprowadziła ruch wahadłowy.

## Buciki najmłodszych ofiar w Auschwitz przejdą konserwację
 - [https://tvn24.pl/krakow/oswiecim-rozpoczela-sie-konserwacja-bucikow-najmlodszych-ofiar-holocaustu-w-muzeum-auschwitz-birkenau-6949714?source=rss](https://tvn24.pl/krakow/oswiecim-rozpoczela-sie-konserwacja-bucikow-najmlodszych-ofiar-holocaustu-w-muzeum-auschwitz-birkenau-6949714?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 15:32:05+00:00

<img alt="Buciki najmłodszych ofiar w Auschwitz przejdą konserwację" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ew7ip1-konserwacja-dzieciecych-bucikow-w-muzeum-auschwitz-birkenau-6949698/alternates/LANDSCAPE_1280" />
    Około ośmiu tysięcy dziecięcych bucików należących do ofiar niemieckiego obozu koncentracyjnego Auschwitz zostanie poddanych konserwacji. W ramach dwuletniego projektu muzealnicy chcą opisać i spowolnić proces starzenia się obuwia. - Buciki dziecięce są jednym z najbardziej poruszających świadectw zbrodni dokonanej w obozie Auschwitz - ocenił wicedyrektor Muzeum Auschwitz-Birkenau Rafał Pióro.

## Ma 24 oczy i zabójczych kuzynów. Odkryto nowy gatunek meduzy
 - [https://tvn24.pl/tvnmeteo/swiat/hongkong-ma-24-oczy-i-zabojczych-kuzynow-odkryto-nowy-gatunek-meduzy-6949018?source=rss](https://tvn24.pl/tvnmeteo/swiat/hongkong-ma-24-oczy-i-zabojczych-kuzynow-odkryto-nowy-gatunek-meduzy-6949018?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 15:31:14+00:00

<img alt="Ma 24 oczy i zabójczych kuzynów. Odkryto nowy gatunek meduzy" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-2r93nl-nowy-gatunek-meduzy-odnaleziony-w-miejskim-parku-6949179/alternates/LANDSCAPE_1280" />
    Nowy gatunek kostkowca - meduzy o sześciennym ciele - został odkryty w miejskim rezerwacie przyrody w Hongkongu. Tripedalia maipoensis to zwierzę o sześciennym, przezroczystym ciele i długich ramionach umożliwiających szybkie pływanie. Bezkręgowiec ma aż 24 oczy, jednak nie wszystkie z nich potrafią rejestrować obraz.

## Trzynastolatek utknął w automacie z pluszakami. Zarzucono mu próbę kradzieży
 - [https://tvn24.pl/swiat/usa-13-latek-utknal-w-automatu-z-zabawkami-w-parku-rozrywki-carowinds-6949776?source=rss](https://tvn24.pl/swiat/usa-13-latek-utknal-w-automatu-z-zabawkami-w-parku-rozrywki-carowinds-6949776?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 15:27:46+00:00

<img alt="Trzynastolatek utknął w automacie z pluszakami. Zarzucono mu próbę kradzieży " src="https://tvn24.pl/najnowsze/cdn-zdjecie-gyfq4c-13-latek-wszedl-do-srodka-maszyny-do-wylawiania-zabawek-w-parku-rozrywki-carowinds-6949749/alternates/LANDSCAPE_1280" />
    13-letni chłopiec otrzymał roczny zakaz wstępu do parku rozrywki Carowinds w Karolinie Północnej, po tym jak 16 kwietnia wszedł do środka maszyny do wyławiania zabawek. Władze parku zarzucają mu usiłowanie kradzieży.

## Maczety i "noże zombie" pod lupą brytyjskiego rządu. "Służą jedynie gloryfikacji przemocy"
 - [https://tvn24.pl/swiat/wielka-brytania-maczety-i-noze-zombie-maja-zostac-zakazane-home-office-rozpoczal-konsultacje-spoleczne-6949709?source=rss](https://tvn24.pl/swiat/wielka-brytania-maczety-i-noze-zombie-maja-zostac-zakazane-home-office-rozpoczal-konsultacje-spoleczne-6949709?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 15:22:12+00:00

<img alt="Maczety i " src="https://tvn24.pl/najnowsze/cdn-zdjecie-10xrib-maczety-i-noze-zombie-pod-lupa-brytyjskiego-rzadu-6949619/alternates/LANDSCAPE_1280" />
    18 kwietnia brytyjski Home Office, urząd będący odpowiednikiem ministerstwa spraw wewnętrznych, rozpoczął konsultacje społeczne w sprawie uregulowania statusu prawnego maczet i tzw. noży zombie. Plany zakładają wdrożenie zakazu ich sprzedaży, posiadania, importu i dostaw. Obecnie niemal 40 procent wszystkich zabójstw w Anglii i Walii jest popełnianych przy użyciu noży lub broni z ostrzem.

## Prokuratura sprawdza, czy były premier przywłaszczył mienie firmy. Marcinkiewicz: to kolejna nagonka
 - [https://tvn24.pl/tvnwarszawa/srodmiescie/prokuratura-warszawa-srodmiescie-sledztwo-ws-przywlaszczenia-mienia-przez-kazimierza-marcinkiewicza-byly-premier-mowi-o-nagonce-6949616?source=rss](https://tvn24.pl/tvnwarszawa/srodmiescie/prokuratura-warszawa-srodmiescie-sledztwo-ws-przywlaszczenia-mienia-przez-kazimierza-marcinkiewicza-byly-premier-mowi-o-nagonce-6949616?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 15:20:17+00:00

<img alt="Prokuratura sprawdza, czy były premier przywłaszczył mienie firmy. Marcinkiewicz: to kolejna nagonka" src="https://tvn24.pl/najnowsze/cdn-zdjecie-f8pzmh-kazimierz-marcinkiewicz-6949678/alternates/LANDSCAPE_1280" />
    Prokuratura Rejonowa Warszawa Śródmieście prowadzi śledztwo w sprawie przywłaszczenia mienia przez byłego premiera Kazimierza Marcinkiewicza. - Na obecnym etapie nikomu nie przedstawiono zarzutów - przekazuje Aleksandra Skrzyniarz, rzeczniczka warszawskiej prokuratury. Były premier działania śledczych nazywa "kolejną nagonką Zbigniewa Ziobry" na jego osobę.

## "Opór cywilny, ludzi którzy nie mieli broni, jest dowodem skrajnego bohaterstwa"
 - [https://tvn24.pl/tvnwarszawa/najnowsze/80-rocznica-powstania-w-getcie-warszawskim-dyrektor-muzeum-polin-komentuje-uroczystosci-6949592?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/80-rocznica-powstania-w-getcie-warszawskim-dyrektor-muzeum-polin-komentuje-uroczystosci-6949592?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 15:09:15+00:00

<img alt="" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-t87hc8-zygmunt-stepinski-dyrektor-muzeum-historii-zydow-polskich-polin-6949615/alternates/LANDSCAPE_1280" />
    Przed wybuchem powstania w getcie przebywało około 50 tysięcy cywilów, którzy nie mieli szans na przeżycie. - Podjęli decyzję, że nie opuszczą getta. Nie dadzą się zapędzić na Umschlagplatz, wywieźć do obozu zagłady w Treblince, tylko stawią opór. I ten ich opór cywilny, ludzi, którzy nie mieli broni, którzy chowali się w bunkrach, jest dowodem skrajnego bohaterstwa - ocenił dyrektor Muzeum Historii Żydów Polskich POLIN Zygmunt Stępiński.

## Sześciolatka wykorzystała nieuwagę personelu i sama wyszła z przedszkola. Policja bada sprawę
 - [https://tvn24.pl/pomorze/wloclawek-szesciolatka-wykorzystala-nieuwage-personelu-i-sama-wyszla-z-przedszkola-6949570?source=rss](https://tvn24.pl/pomorze/wloclawek-szesciolatka-wykorzystala-nieuwage-personelu-i-sama-wyszla-z-przedszkola-6949570?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 15:03:18+00:00

<img alt="Sześciolatka wykorzystała nieuwagę personelu i sama wyszła z przedszkola. Policja bada sprawę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-niba9e-dziewczynka-sama-wyszla-z-przedszkola-6949726/alternates/LANDSCAPE_1280" />
    We Włocławku (woj. kujawsko-pomorskie) sześciolatka wykorzystała nieuwagę personelu i sama wyszła z przedszkola. Dziewczynka samodzielnie dotarła do domu, przechodząc przez kilka ruchliwych ulic. Nic jej się nie stało. Policja zbada jednak, czy personel miejskiego przedszkola nie dopuścił się przestępstwa bezpośredniego narażenia dziecka na utratę życia lub na uszczerbek na zdrowiu.

## Zderzenie trzech aut, w tym ciężarówki. Korek na obwodnicy miał kilka kilometrów
 - [https://tvn24.pl/tvnwarszawa/ulice/pow-s2-zderzenie-na-moscie-poludniowym-korek-6949669?source=rss](https://tvn24.pl/tvnwarszawa/ulice/pow-s2-zderzenie-na-moscie-poludniowym-korek-6949669?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 14:30:57+00:00

<img alt="Zderzenie trzech aut, w tym ciężarówki. Korek na obwodnicy miał kilka kilometrów" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-jdk7ta-zderzenie-na-s2-6949673/alternates/LANDSCAPE_1280" />
    Na moście południowym w ciągu trasy S2 ciężarówka zderzyła się z dwoma autami osobowymi. Artur Węgrzynowicz z tvnwarszawa.pl informował o dużych utrudnieniach w kierunku Wilanowa.

## Wyszedł do kościoła i nie wrócił. Dzień później znaleziono ciało lekarza i byłego radnego
 - [https://tvn24.pl/katowice/ledziny-andrzej-bryjok-nie-zyje-byl-radnym-i-lekarzem-prokuratura-bada-przyczyny-smierci-6949520?source=rss](https://tvn24.pl/katowice/ledziny-andrzej-bryjok-nie-zyje-byl-radnym-i-lekarzem-prokuratura-bada-przyczyny-smierci-6949520?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 14:24:13+00:00

<img alt="Wyszedł do kościoła i nie wrócił. Dzień później znaleziono ciało lekarza i byłego radnego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wucuvj-andrzej-bryjok-mial-59-lat-6949464/alternates/LANDSCAPE_1280" />
    W wieku 59 lat zmarł Andrzej Bryjok, lekarz i były radny powiatu bieruńsko-lędzińskiego (woj. śląskie). Wcześniej o jego zaginięciu poinformowała za pośrednictwem mediów społecznościowych żona. Przyczyny jego śmierci bada prokuratura.

## Nevado del Ruiz grozi erupcją. Wulkan wyrzucił z siebie kolumnę dymu
 - [https://tvn24.pl/tvnmeteo/swiat/kolumbia-wulkan-nevado-del-ruiz-grozi-erupcja-wyrzucil-z-siebie-kolumne-dymu-6949606?source=rss](https://tvn24.pl/tvnmeteo/swiat/kolumbia-wulkan-nevado-del-ruiz-grozi-erupcja-wyrzucil-z-siebie-kolumne-dymu-6949606?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 14:23:25+00:00

<img alt="Nevado del Ruiz grozi erupcją. Wulkan wyrzucił z siebie kolumnę dymu" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-i3ht7a-przebudzenie-wulkanu-nevado-del-ruiz-6949517/alternates/LANDSCAPE_1280" />
    Wulkan Nevado del Ruiz w Kolumbii grozi erupcją. We wtorek zaczął wyrzucać z siebie masy dymu i popiołu. Wojsko przy pomocy radia przez cały dzień informowało mieszkańców o możliwym niebezpieczeństwie.

## W rowie znaleźli granat moździerzowy. Policja: ktoś go tam podrzucił
 - [https://tvn24.pl/lodz/cieladz-woj-lodzkie-niewybuch-w-rowie-przy-drodze-wojewodzkiej-707-policja-ktos-go-wykopal-i-porzucil-w-rowie-6949588?source=rss](https://tvn24.pl/lodz/cieladz-woj-lodzkie-niewybuch-w-rowie-przy-drodze-wojewodzkiej-707-policja-ktos-go-wykopal-i-porzucil-w-rowie-6949588?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 14:08:01+00:00

<img alt="W rowie znaleźli granat moździerzowy. Policja: ktoś go tam podrzucił" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ciupgu-pocisk-zostal-znaleziony-w-przydroznym-rowie-6949590/alternates/LANDSCAPE_1280" />
    - Ktoś musiał znaleźć pocisk i wrzucić go do rowu - przekazują policjanci, którzy we wtorek zostali zaalarmowani, że przy drodze wojewódzkiej 707 w Cielądzu (woj. łódzkie) leży granat moździerzowy. Według policyjnych pirotechników ma on kaliber 81 milimetrów i najpewniej pochodzi z czasów drugiej wojny światowej.

## Autobus uderzył w dom. Wcześniej zderzył się z autem osobowym
 - [https://tvn24.pl/pomorze/chmielniki-autobus-uderzyl-w-dom-wczesniej-zderzyl-sie-czolowo-z-autem-osobowym-6949485?source=rss](https://tvn24.pl/pomorze/chmielniki-autobus-uderzyl-w-dom-wczesniej-zderzyl-sie-czolowo-z-autem-osobowym-6949485?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 13:35:15+00:00

<img alt="Autobus uderzył w dom. Wcześniej zderzył się z autem osobowym" src="https://tvn24.pl/najnowsze/cdn-zdjecie-epva29-do-wypadku-doszlo-niedaleko-bydgoszczy-6949503/alternates/LANDSCAPE_1280" />
    Czołowe zderzenie samochodu osobowego z autobusem PKS na drodze krajowej nr 25 w Chmielnikach (woj. kujawsko-pomorskie). W wyniku zderzenia autobus zjechał z drogi i uderzył w budynek mieszkalny. Dwie osoby trafiły do szpitala - to kierująca samochodem osobowym oraz jedna osoba z autobusu.

## Zderzenie dwóch samochodów. Jedna osoba ranna
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-wirazowanarkiewicza-zderzenie-dwoch-samochodow-jedna-osoba-ranna-6949363?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-wirazowanarkiewicza-zderzenie-dwoch-samochodow-jedna-osoba-ranna-6949363?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 13:34:19+00:00

<img alt="Zderzenie dwóch samochodów. Jedna osoba ranna" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-1p8q0c-zderzenie-na-skrzyzowaniu-wirazowej-i-wiktora-narkiewicza-6949369/alternates/LANDSCAPE_1280" />
    Na skrzyżowaniu Wirażowej i Wiktora Narkiewicza zderzyły się dwa samochody. Jedna osoba trafiła do szpitala. Na jezdni jest dużo elementów karoserii, z pojazdów wyciekły też płyny.

## Koszalin. Wynajmował garaż, w środku znaleźli materiały wybuchowe
 - [https://tvn24.pl/pomorze/koszalin-ul-4-marca-materialy-wybuchowe-w-wynajmowanym-garazu-zatrzymali-37-latka-6949582?source=rss](https://tvn24.pl/pomorze/koszalin-ul-4-marca-materialy-wybuchowe-w-wynajmowanym-garazu-zatrzymali-37-latka-6949582?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 13:32:45+00:00

<img alt="Koszalin. Wynajmował garaż, w środku znaleźli materiały wybuchowe" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pllb1c-koszalin-akcja-sluzb-na-miejscu-znaleziska-6949563/alternates/LANDSCAPE_1280" />
    Koszalińska policja zatrzymała 37-letniego najemcę jednego z garaży przy ul. 4 Marca, w którym znaleziono podejrzane substancje niewiadomego pochodzenia. Funkcjonariusze potwierdzili, że były to materiały wybuchowe. - Zostaną poddane kontrolowanej detonacji na terenie wojskowym - przekazano.

## Pieśń partyzantów żydowskich w jidysz wybrzmiała na obchodach rocznicy
 - [https://tvn24.pl/polska/80-rocznica-powstania-w-getcie-warszawskim-piesn-partyzantow-zydowskich-w-jidysz-wykonana-przez-trzy-chory-6949475?source=rss](https://tvn24.pl/polska/80-rocznica-powstania-w-getcie-warszawskim-piesn-partyzantow-zydowskich-w-jidysz-wykonana-przez-trzy-chory-6949475?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 13:26:27+00:00

<img alt="Pieśń partyzantów żydowskich w jidysz wybrzmiała na obchodach rocznicy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-yzqqci-piesn-w-jidysz-podczas-obchodow-rocznicy-6949494/alternates/LANDSCAPE_1280" />
    Pieśń partyzantów żydowskich "Zog nit kejn mol" wybrzmiała w czasie głównych obchodów 80. rocznicy powstania w warszawskim getcie. Wykonana została przez trzy chóry - dwa z Polski i jeden z Izraela. Wokaliści odśpiewali kilka wersów w języku jidysz, a następnie ich polski przekład.

## Przed nami bardzo ciepły weekend
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-weekend-do-polski-naplynie-bardzo-cieple-powietrze-potem-pojawia-sie-burze-6949351?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-weekend-do-polski-naplynie-bardzo-cieple-powietrze-potem-pojawia-sie-burze-6949351?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 13:16:00+00:00

<img alt="Przed nami bardzo ciepły weekend" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-scmi0w-przed-nami-bardzo-cieply-weekend-6949534/alternates/LANDSCAPE_1280" />
    Druga połowa tygodnia zapowiada się ciepło i z dużą ilością słońca. W weekend temperatura na terenie części Polski przekroczy 20 stopni Celsjusza. Takich samych wartości możemy spodziewać się również w poniedziałek, ale wtedy w większości kraju pojawi się deszcz, a w niektórych miejscach może zagrzmieć.

## Austin: liczymy, że Szwecja stanie się członkiem NATO jeszcze przed lipcowym szczytem Sojuszu
 - [https://tvn24.pl/swiat/lloyd-austin-sekretarz-obrony-usa-liczymy-na-to-ze-szwecja-stanie-sie-czlonkiem-nato-jeszcze-przed-lipcowym-szczytem-sojuszuw-wilnie-6949445?source=rss](https://tvn24.pl/swiat/lloyd-austin-sekretarz-obrony-usa-liczymy-na-to-ze-szwecja-stanie-sie-czlonkiem-nato-jeszcze-przed-lipcowym-szczytem-sojuszuw-wilnie-6949445?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 13:07:49+00:00

<img alt="Austin: liczymy, że Szwecja stanie się członkiem NATO jeszcze przed lipcowym szczytem Sojuszu " src="https://tvn24.pl/najnowsze/cdn-zdjecie-26ut6u-lloyd-austin-podczas-wizyty-w-sztokholmie-6949463/alternates/LANDSCAPE_1280" />
    Stany Zjednoczone nie mogą się doczekać przyjęcia Szwecji jako członka NATO, liczmy, że stanie się to jeszcze przed zbliżającym się lipcowym szczytem Sojuszu w Wilnie - powiedział w środę podczas wizyty w tym kraju sekretarz obrony USA Lloyd Austin.

## Orangutanica nie potrafiła karmić piersią. Nauczyła się, patrząc na karmiącą kobietę
 - [https://tvn24.pl/tvnmeteo/ciekawostki/usa-orangutanica-zoey-nauczyla-sie-karmic-piersia-obserwujac-pracownice-zoo-6949108?source=rss](https://tvn24.pl/tvnmeteo/ciekawostki/usa-orangutanica-zoey-nauczyla-sie-karmic-piersia-obserwujac-pracownice-zoo-6949108?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 13:06:22+00:00

<img alt="Orangutanica nie potrafiła karmić piersią. Nauczyła się, patrząc na karmiącą kobietę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ekh7vs-1904n055x-cnn-mama-i-orangutan-bs-05-6949222/alternates/LANDSCAPE_1280" />
    Gdy patrzyła mi w oczy w trakcie karmienia, wiedziałam, że rozumie, o co mi chodzi - mówi pracownica zoo w Wirginii, Whitlee Turner, która nauczyła orangutanicę Zoey jak karmić piersią własne dziecko. Zdaniem pracowników zoo Zoey nie miała instynktu macierzyńskiego, ponieważ została osierocona w wieku dziewięciu miesięcy.

## Miał rozpowszechniać "fake newsy" o rosyjskiej armii. Znany opozycjonista skazany przez sąd wyższej instancji
 - [https://tvn24.pl/swiat/rosja-ilja-jaszyn-mial-rozpowszechniac-fake-newsy-zostal-skazany-apelacja-od-wyroku-zostala-odrzucona-6949416?source=rss](https://tvn24.pl/swiat/rosja-ilja-jaszyn-mial-rozpowszechniac-fake-newsy-zostal-skazany-apelacja-od-wyroku-zostala-odrzucona-6949416?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 13:06:10+00:00

<img alt="Miał rozpowszechniać " src="https://tvn24.pl/najnowsze/cdn-zdjecie-o8q54f-jaszyn-6949417/alternates/LANDSCAPE_1280" />
    Sąd wyższej instancji w Moskwie odrzucił apelację od wyroku dla znanego opozycjonisty Ilji Jaszyna. Krytyk władz na Kremlu został skazany na 8,5 roku kolonii karnej za rzekome "fake newsy" o działaniach sił zbrojnych Rosji.

## Uroczystości koronacyjne Karola III potrwają trzy dni. Co się wydarzy
 - [https://tvn24.pl/swiat/koronacja-karola-iii-kalendarium-wydarzen-6-8-maja-6948709?source=rss](https://tvn24.pl/swiat/koronacja-karola-iii-kalendarium-wydarzen-6-8-maja-6948709?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 13:02:49+00:00

<img alt="Uroczystości koronacyjne Karola III potrwają trzy dni. Co się wydarzy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ffpli0-ksiaze-karol-2008-6949337/alternates/LANDSCAPE_1280" />
    Koronacji króla Karola będą towarzyszyć trwające trzy dni obchody i uroczystości. Od procesji do Opactwa Westminsterskiego po święto państwowe The Big Help Out - oto kalendarium wydarzeń wraz z podpowiedziami, skąd najlepiej będzie oglądać brytyjską rodzinę królewską.

## Zatrzasnęła drzwi i nie mogła wejść do mieszkania. Wymyśliła historię, teraz ma kłopoty
 - [https://tvn24.pl/bialystok/bielsk-podlaski-wezwala-sluzby-bo-nie-mogla-wejsc-do-mieszkania-wymyslila-historie-ze-w-srodku-jest-dziecko-poniesie-kare-6948741?source=rss](https://tvn24.pl/bialystok/bielsk-podlaski-wezwala-sluzby-bo-nie-mogla-wejsc-do-mieszkania-wymyslila-historie-ze-w-srodku-jest-dziecko-poniesie-kare-6948741?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 12:38:58+00:00

<img alt="Zatrzasnęła drzwi i nie mogła wejść do mieszkania. Wymyśliła historię, teraz ma kłopoty" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kur24m-policja-przestrzega-przed-konsekwencjami-bezpodstawnego-wezwania-sluzb-6948985/alternates/LANDSCAPE_1280" />
    Za bezpodstawne wezwanie służb odpowie 43-latka, która zadzwoniła na numer alarmowy, twierdząc, że nie może wejść do mieszkania, a w środku przebywa półtoraroczne dziecko bez opieki. Kiedy strażacy wyważyli drzwi, okazało się, że dziecka tam nie ma, a kobieta wymyśliła całą historię.

## Bocian wypadł z gniazda i zaplątał się w gałęzie. Pomogli mu strażacy
 - [https://tvn24.pl/bialystok/potasznia-bocian-wypadl-z-gniazda-i-zaplatal-sie-w-galezie-pomogli-mu-strazacy-6949295?source=rss](https://tvn24.pl/bialystok/potasznia-bocian-wypadl-z-gniazda-i-zaplatal-sie-w-galezie-pomogli-mu-strazacy-6949295?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 12:09:55+00:00

<img alt="Bocian wypadł z gniazda i zaplątał się w gałęzie. Pomogli mu strażacy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ccyk1z-zaplatal-sie-w-galezie-6949300/alternates/LANDSCAPE_1280" />
    Strażacy ochotnicy zostali wezwani na jedną z posesji w Potaszni (woj. podlaskie), gdzie bocian wypadł z gniazda i zaplątał się w gałęzie. Ptak wisiał na wysokości około pięciu-sześciu metrów. Druhowie ściągnęli go bezpiecznie na ziemię. Nic mu się nie stało. - Odleciał, gdy usłyszał, że chcemy go zabrać do weterynarza - mówią ratownicy.

## Na widok policjantów zamknął się w aucie. Był poszukiwany listem gończym
 - [https://tvn24.pl/pomorze/olsztyn-na-widok-policjantow-zamknal-sie-w-aucie-byl-poszukiwany-listem-gonczym-6948737?source=rss](https://tvn24.pl/pomorze/olsztyn-na-widok-policjantow-zamknal-sie-w-aucie-byl-poszukiwany-listem-gonczym-6948737?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 12:02:09+00:00

<img alt="Na widok policjantów zamknął się w aucie. Był poszukiwany listem gończym" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7fy01g-na-widok-policjantow-zamknal-sie-w-aucie-byl-poszukiwany-listem-gonczym-6949345/alternates/LANDSCAPE_1280" />
    40-letni mieszkaniec Olsztyna, poszukiwany listem gończym, próbował schronić się przed policjantami w aucie. Musieli wybić szybę w pojeździe, żeby dostać się do mężczyzny. Teraz czeka go, odwlekana od ubiegłego roku, kara pozbawienia wolności.

## Korea Południowa rozważa militarną pomoc dla Ukrainy. Kreml odpowiada groźbą
 - [https://tvn24.pl/swiat/inwazja-zbrojna-rosji-na-ukraine-korea-poludniowa-rozwaza-militarna-pomoc-dla-kijowa-6949197?source=rss](https://tvn24.pl/swiat/inwazja-zbrojna-rosji-na-ukraine-korea-poludniowa-rozwaza-militarna-pomoc-dla-kijowa-6949197?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 11:52:07+00:00

<img alt="Korea Południowa rozważa militarną pomoc dla Ukrainy. Kreml odpowiada groźbą" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-j8b4x0-moskwa-rosja-kreml-6858529/alternates/LANDSCAPE_1280" />
    Kreml zagroził Korei Południowej, że dostarczenie przez Seul pomocy militarnej na Ukrainę byłoby "w pewnym stopniu zaangażowaniem się w konflikt". Wcześniej prezydent Jun Suk Jeol oznajmił, że jego kraj może rozszerzyć swoje wsparcie dla Ukrainy ponad pomoc humanitarną i finansową w przypadku dużego rosyjskiego ataku na ludność cywilną. Tym samym zasygnalizował zmianę stanowiska Seulu w sprawie wsparcia wojskowego.

## W trakcie jazdy w ciężarówce zapaliła się opona. Kierowca chwycił za gaśnicę, opona wystrzeliła
 - [https://tvn24.pl/bialystok/biala-w-trakcie-jazdy-w-ciezarowce-zapalila-sie-opona-kierowca-chwycil-za-gasnice-wtedy-opona-wystrzelila-6948617?source=rss](https://tvn24.pl/bialystok/biala-w-trakcie-jazdy-w-ciezarowce-zapalila-sie-opona-kierowca-chwycil-za-gasnice-wtedy-opona-wystrzelila-6948617?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 10:55:15+00:00

<img alt="W trakcie jazdy w ciężarówce zapaliła się opona. Kierowca chwycił za gaśnicę, opona wystrzeliła" src="https://tvn24.pl/najnowsze/cdn-zdjecie-20ibt6-pozar-ugasili-strazacy-6948621/alternates/LANDSCAPE_1280" />
    Kierowca ciężarówki jechał przez miejscowość Biała (woj. lubelskie), gdy zauważył, że w jego pojeździe zapłonęła opona. Pożar próbował ugasić, ale w pewnym momencie opona wystrzeliła. Mężczyzna doznał lekkich obrażeń. Pożar ugasili strażacy.

## Chiny zwiększają swoją obecność na Antarktydzie. W Waszyngtonie rosną obawy
 - [https://tvn24.pl/swiat/chiny-pekin-zwieksza-obecnosc-na-antartydzie-obawy-o-dzialalnosc-szpiegowska-6948928?source=rss](https://tvn24.pl/swiat/chiny-pekin-zwieksza-obecnosc-na-antartydzie-obawy-o-dzialalnosc-szpiegowska-6948928?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 10:43:53+00:00

<img alt="Chiny zwiększają swoją obecność na Antarktydzie. W Waszyngtonie rosną obawy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9tljp4-chinska-stacja-zhongshan-na-antarktydzie-6948946/alternates/LANDSCAPE_1280" />
    Pekin zwiększa swoją obecność na Antarktydzie i wznawia zawieszoną w 2018 roku budowę nowej, piątej chińskiej stacji na kontynencie. Centrum Studiów Strategicznych i Międzynarodowych w Waszyngtonie napisało, że wzbudza to obawy o możliwość wykorzystywania jej do przechwytywania komunikatów satelitarnych innych krajów.

## Prezydenci Niemiec i Izraela na obchodach w Warszawie. "Jest cudem, że Żydzi i Polacy w ogóle uścisnęli ręce z nami"
 - [https://tvn24.pl/polska/80-rocznica-powstania-w-warszawskim-getcie-prezydent-niemiec-frank-walter-steinmeier-i-prezydent-izraela-isaac-herzog-na-obchodach-6948943?source=rss](https://tvn24.pl/polska/80-rocznica-powstania-w-warszawskim-getcie-prezydent-niemiec-frank-walter-steinmeier-i-prezydent-izraela-isaac-herzog-na-obchodach-6948943?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 10:30:19+00:00

<img alt="Prezydenci Niemiec i Izraela na obchodach w Warszawie. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-qa0wgw-polin-prezydenci_02-6949032/alternates/LANDSCAPE_1280" />
    Prezydent Niemiec Frank-Walter Steinmeier i prezydent Izraela Isaac Herzog biorą w środę udział w oficjalnych, centralnych obchodach 80. rocznicy powstania w getcie warszawskim. Niemiecki przywódca podziękował Polsce i Izraelowi za "cud pojednania".

## "Ludzie nie bądźcie obojętni na zło". Uroczystości przed Pomnikiem Bohaterów Getta
 - [https://tvn24.pl/tvnwarszawa/srodmiescie/warszawa-zawyly-syreny-rozpoczely-sie-glowne-uroczystosci-przed-pomnikiem-bohaterow-getta-6948958?source=rss](https://tvn24.pl/tvnwarszawa/srodmiescie/warszawa-zawyly-syreny-rozpoczely-sie-glowne-uroczystosci-przed-pomnikiem-bohaterow-getta-6948958?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 10:15:27+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-uwe45j-centralna-czesc-obchodow-80-rocznicy-wybuchu-powstania-w-getcie-warszawskim-6949002/alternates/LANDSCAPE_1280" />
    Trwają uroczystości przed pomnikiem Bohaterów Getta. To centralna część obchodów 80. rocznicy wybuchu powstania w getcie warszawskim.

## Jacek Nowakowski, kustosz Muzeum Holokaustu w Waszyngtonie w rozmowie z Marcinem Wroną
 - [https://tvn24.pl/polska/80-rocznica-powstania-w-getcie-warszawskimjacek-nowakowski-starszy-kustosz-muzeum-holokaustu-w-waszyngtonie-o-zrywie-z-1943-roku-6948805?source=rss](https://tvn24.pl/polska/80-rocznica-powstania-w-getcie-warszawskimjacek-nowakowski-starszy-kustosz-muzeum-holokaustu-w-waszyngtonie-o-zrywie-z-1943-roku-6948805?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 10:14:38+00:00

<img alt="Jacek Nowakowski, kustosz Muzeum Holokaustu w Waszyngtonie w rozmowie z Marcinem Wroną" src="https://tvn24.pl/najnowsze/cdn-zdjecie-odqy20-jacek-nowakowski-starszy-kustosz-muzeum-holokaustu-w-waszyngtonie-6948880/alternates/LANDSCAPE_1280" />
    W związku z 80. rocznicą powstania w getcie warszawskim, korespondent "Faktów" TVN Marcin Wrona rozmawiał z Jackiem Nowakowskim, starszym kustoszem Muzeum Holokaustu w Waszyngtonie. Kustosz mówił między innymi o sposobach upamiętnienia powstania, a także związanej z tym historii samego muzeum, ponieważ w tym roku mija 30 lat od jego otwarcia. Nowakowski wyliczał, że wystawa poświęcona powstaniu w getcie prezentuje między innymi kawałki gruzu z placu, gdzie obecnie stoi Pomnik Bohaterów Getta, a także fragmenty broni, które zostały odnalezione w ruinach getta. - To zawsze było miejsce, które dostarczało ogromnych emocji - dodał.

## Przyjechała z córką do Polski. Pierwszy raz po podjęciu ważnej życiowej decyzji
 - [https://tvn24.pl/kultura-i-styl/joanna-krupa-przyjechala-z-corka-do-polski-pierwszy-raz-po-podjeciu-waznej-zyciowej-decyzji-6948920?source=rss](https://tvn24.pl/kultura-i-styl/joanna-krupa-przyjechala-z-corka-do-polski-pierwszy-raz-po-podjeciu-waznej-zyciowej-decyzji-6948920?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 10:01:02+00:00

<img alt="Przyjechała z córką do Polski. Pierwszy raz po podjęciu ważnej życiowej decyzji" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ztsfj2-joanna-krupa-wracala-do-stanow-dreamliner-awaryjnie-ladowal-5673842/alternates/LANDSCAPE_1280" />
    Joanna Krupa jest w trakcie rozwodu. Pod koniec marca jurorka "Top Model" ogłosiła, że po pięciu latach małżeństwa podjęli z Douglasem Nunesem decyzję o rozstaniu. Córkę Ashę-Leigh chcą wychowywać wspólnie.

## Aleksander Edelman: Empatia musi być aktywna. Uratować jednej osobie życie, to czasami jak uratować świat
 - [https://tvn24.pl/polska/80-rocznica-powstania-w-getcie-warszawskim-aleksander-edelman-w-rozmowie-z-agata-adamek-6948857?source=rss](https://tvn24.pl/polska/80-rocznica-powstania-w-getcie-warszawskim-aleksander-edelman-w-rozmowie-z-agata-adamek-6948857?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 09:58:08+00:00

<img alt="Aleksander Edelman: Empatia musi być aktywna. Uratować jednej osobie życie, to czasami jak uratować świat" src="https://tvn24.pl/najnowsze/cdn-zdjecie-z9j7wt-aleksander-edelman-6948647/alternates/LANDSCAPE_1280" />
    Ludzie się umówili, że muszą być rocznice, to myślą o tym tylko, kiedy są rocznice. Ale tak naprawdę to człowiek jest tym przesiąknięty. Ludzie może są nieświadomi, że są przesiąknięci, ale są. Szczególnie ci, którzy mieszkają tu, w Polsce. Bo ten dramat stał się w Polsce - powiedział w rozmowie z Agatą Adamek reżyser i biofizyk Aleksander Edelman, syn powstańców w getcie warszawskim.

## Inflacja w Unii Europejskiej hamuje. Dwa kraje na liście wyjątków
 - [https://tvn24.pl/biznes/pieniadze/inflacja-w-unii-europejskiej-marzec-2023-wegry-przed-lotwa-polska-w-czolowce-eurostat-podal-nowe-dane-6948870?source=rss](https://tvn24.pl/biznes/pieniadze/inflacja-w-unii-europejskiej-marzec-2023-wegry-przed-lotwa-polska-w-czolowce-eurostat-podal-nowe-dane-6948870?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 09:57:05+00:00

<img alt="Inflacja w Unii Europejskiej hamuje. Dwa kraje na liście wyjątków" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-hnpsuj-w-grudniu-2021-roku-inflacja-w-wielkiej-brytanii-ustanowila-30-letni-rekord-5565142/alternates/LANDSCAPE_1280" />
    Inflacja w Unii Europejskiej w marcu 2023 roku spadła do 8,3 procent rok do roku wobec 9,9 procent w lutym. Najmocniej ceny wzrosły na Węgrzech, które w niechlubnej klasyfikacji wyprzedzają Łotwę - wynika z najnowszych danych unijnego urzędu statystycznego Eurostat. Polska znalazła się tuż za podium tego zestawienia. Tempo wzrostu cen przyspieszyło jedynie w przypadku dwóch krajów.

## Był poszukiwany listem gończym. Ukrywał się w szałasie
 - [https://tvn24.pl/lodz/lodz-byl-poszukiwany-listem-gonczym-przed-policja-ukrywal-sie-w-szalasie-6948883?source=rss](https://tvn24.pl/lodz/lodz-byl-poszukiwany-listem-gonczym-przed-policja-ukrywal-sie-w-szalasie-6948883?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 09:47:26+00:00

<img alt="Był poszukiwany listem gończym. Ukrywał się w szałasie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cddopx-byl-poszukiwany-listem-gonczy-przed-policja-ukryl-sie-w-szalasie-6948854/alternates/LANDSCAPE_1280" />
    Policjanci z Łodzi zatrzymali poszukiwanego listem gończym mężczyznę. 44-latek przed wymiarem sprawiedliwości ukrywał się w lesie w szałasie. Podejrzany po zakończonych przez policję czynnościach trafił do aresztu śledczego.

## Błękitny dywan w zaczarowanym lesie. Piękny, ale ulotny
 - [https://tvn24.pl/tvnmeteo/swiat/belgia-blekitne-dzwonki-w-lesie-hallerbos-6948743?source=rss](https://tvn24.pl/tvnmeteo/swiat/belgia-blekitne-dzwonki-w-lesie-hallerbos-6948743?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 09:42:14+00:00

<img alt="Błękitny dywan w zaczarowanym lesie. Piękny, ale ulotny" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-cetdqp-blekitny-dywan-z-kwiatow-w-lesie-hallerbos-6948893/alternates/LANDSCAPE_1280" />
    Hallerbos, słynny "zaczarowany las" w Belgii, we wtorek pokrył się błękitem - rozpoczął się okres kwitnienia hiacyntowców zwyczajnych (Hyacinthoides non-scripta). Na miejsce natychmiast przybyli fotografowie z wielu stron świata, ponieważ zjawiskowy krajobraz zniknie w ciągu kilku dni.

## "Rozkład będzie ulegał częstym modyfikacjom". Kilkumiesięczne utrudnienia na linii R2
 - [https://tvn24.pl/tvnwarszawa/komunikacja/utrudnienia-na-linii-r2-odwolane-kursy-i-ograniczenie-liczby-pociagow-6948797?source=rss](https://tvn24.pl/tvnwarszawa/komunikacja/utrudnienia-na-linii-r2-odwolane-kursy-i-ograniczenie-liczby-pociagow-6948797?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 09:34:30+00:00

<img alt="" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-7vcezs-utrudnienia-na-linii-r2-6948863/alternates/LANDSCAPE_1280" />
    Pasażerów podróżujących podróżujących na trasie Warszawa – Siedlce czekają duże utrudnienia. Spowodowane będą wymianą systemu sterowania ruchem kolejowym. Odwołane zostaną pociągi rozpoczynające i kończące bieg na stacji Mrozy. Mniej pociągów przyjedzie też na stacje w Mińsku Mazowieckim.

## Utrudnienia w metrze, kilka stacji zamkniętych
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-utrudnienia-w-metrze-kilka-stacji-zamknietych-awaria-hamulcow-6948814?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-utrudnienia-w-metrze-kilka-stacji-zamknietych-awaria-hamulcow-6948814?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 09:09:42+00:00

<img alt="Utrudnienia w metrze, kilka stacji zamkniętych" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-uzfzz-utrudnienia-w-metrze-zdjecie-ilustracyjne-1223266/alternates/LANDSCAPE_1280" />
    Zepsuty pociąg w metrze przyczyną utrudnień na drugiej linii podziemnej kolejki. Składy kursują w dwóch pętlach. Uruchomiono linię zastępczą.

## Chciał zarobić na kryptowalutach. Stracił pieniądze swoje oraz matki i "zyskał" kredyty
 - [https://tvn24.pl/tvnwarszawa/okolice/ciechanow-mezczyzna-padl-ofiara-oszusta-rozmowca-namawial-do-inwestowania-w-kryptowaluty-6948371?source=rss](https://tvn24.pl/tvnwarszawa/okolice/ciechanow-mezczyzna-padl-ofiara-oszusta-rozmowca-namawial-do-inwestowania-w-kryptowaluty-6948371?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 09:01:06+00:00

<img alt="Chciał zarobić na kryptowalutach. Stracił pieniądze swoje oraz matki i " src="https://tvn24.pl/najnowsze/cdn-zdjecie-wnsn8u-mezczyzna-padl-ofiara-oszusta-zdjecie-ilustracyjne-6948766/alternates/LANDSCAPE_1280" />
    Do 36-latka zadzwonił mężczyzna z atrakcyjną ofertą inwestowania w kryptowaluty. Oferował szybki zarobek i polecił zainstalowanie oprogramowania, przydatnego podczas inwestycji. 36-latek przystał na propozycję. Stracił 50 tysięcy złotych i "zyskał" kredyty.

## "Obroniliście godność człowieka, w tym prawo do godnego umierania"
 - [https://tvn24.pl/tvnwarszawa/najnowsze/przewodniczacy-komitetu-ds-dialogu-z-judaizmem-abp-grzegorz-rys-obroniliscie-godnosc-czlowieka-w-tym-prawo-do-godnego-umierania-6948699?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/przewodniczacy-komitetu-ds-dialogu-z-judaizmem-abp-grzegorz-rys-obroniliscie-godnosc-czlowieka-w-tym-prawo-do-godnego-umierania-6948699?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 08:44:33+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-y6vp1o-arcybiskup-grzegorz-rys-4620205/alternates/LANDSCAPE_1280" />
    Do wydarzeń sprzed 80 lat, czyli powstania w getcie warszawskim odniósł się  przewodniczący komitetu ds. dialogu z judaizmem abp Grzegorz Ryś. - Obroniliście godność człowieka, ludzkiego prawa do godnego życia, w tym prawa do godnego umierania - zaznaczył.

## Władze Izraela: w 2022 roku do ojczyzny wróciło 551 osób, które przeżyły Holokaust
 - [https://tvn24.pl/swiat/izrael-wladze-w-2022-roku-do-ojczyzny-wrocilo-551-osob-ktore-przezyly-holokaust-6947862?source=rss](https://tvn24.pl/swiat/izrael-wladze-w-2022-roku-do-ojczyzny-wrocilo-551-osob-ktore-przezyly-holokaust-6947862?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 08:40:51+00:00

<img alt="Władze Izraela: w 2022 roku do ojczyzny wróciło 551 osób, które przeżyły Holokaust" src="https://tvn24.pl/najnowsze/cdn-zdjecie-q139to-w-2022-roku-do-ojczyzny-wrocilo-na-stale-551-osob-ktore-przezyly-holokaust-6947520/alternates/LANDSCAPE_1280" />
    Izraelskie Ministerstwo Alii i Integracji informuje, że w 2022 roku do kraju wróciło na stałe 551 osób, które przeżyły Holokaust. Przyjechali głównie z Ukrainy, Rosji i Francji, a także z Maroka i Niemiec.

## Pracowali "na czarno", granicę przekroczyli nielegalnie
 - [https://tvn24.pl/tvnwarszawa/okolice/raszyn-pracowali-na-czarno-granice-przekroczyli-nielegalnie-6948715?source=rss](https://tvn24.pl/tvnwarszawa/okolice/raszyn-pracowali-na-czarno-granice-przekroczyli-nielegalnie-6948715?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 08:23:05+00:00

<img alt="Pracowali " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-l6ft5p-wietnamczyk-musi-wrocic-do-ojczyzny-6898166/alternates/LANDSCAPE_1280" />
    Przebywali i pracowali w Polsce nielegalnie. Podczas kontroli okazało się, że również nielegalnie przekroczyli granicę. Dwie osoby otrzymały nakaz opuszczenia Polski, mają też zakazy ponownego wjazdu. Trzecia osoba, która nie miała dokumentów tożsamości, została skierowana do ośrodka dla cudzoziemców.

## Spiralna "galaktyka" przecięła zorzę polarną
 - [https://tvn24.pl/tvnmeteo/swiat/alaska-stany-zjednoczone-tajemnicza-spirala-na-niebie-tuz-obok-zorzy-polarnej-6948517?source=rss](https://tvn24.pl/tvnmeteo/swiat/alaska-stany-zjednoczone-tajemnicza-spirala-na-niebie-tuz-obok-zorzy-polarnej-6948517?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 08:00:48+00:00

<img alt="Spiralna " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-sjlpun-spirala-na-niebie-nad-alaska-6948514/alternates/LANDSCAPE_1280" />
    Spiralny kształt pojawił się na niebie nad Alaską w nocy z piątku na sobotę. Zjawisko nałożyło się na zorzę polarną, tworząc niesamowite widowisko. Chociaż użytkownicy mediów społecznościowych żartowali, że wywołali je przybysze z obcej planety, spirala ma znacznie bardziej prozaiczną genezę.

## Wielka Brytania niechlubnym liderem Europy Zachodniej. Nowe dane o inflacji
 - [https://tvn24.pl/biznes/ze-swiata/wielka-brytania-inflacja-marzec-2023-inflacja-w-wielkiej-brytanii-spadla-mniej-niz-oczekiwano-ons-podal-nowe-dane-6948594?source=rss](https://tvn24.pl/biznes/ze-swiata/wielka-brytania-inflacja-marzec-2023-inflacja-w-wielkiej-brytanii-spadla-mniej-niz-oczekiwano-ons-podal-nowe-dane-6948594?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 07:59:58+00:00

<img alt="Wielka Brytania niechlubnym liderem Europy Zachodniej. Nowe dane o inflacji" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3fzmcb-londyn-shutterstock71283253-6771520/alternates/LANDSCAPE_1280" />
    Wielka Brytania ma obecnie najwyższą inflację w Europie Zachodniej - napisała agencja Reuters. Z środowych danych brytyjskiego urzędu statystycznego (ONS) wynika, że ceny konsumpcyjne na Wyspach spadły w marcu mniej niż oczekiwano. Ceny żywności i napojów bezalkoholowych wzrosły o blisko jedną piątą, najmocniej od sierpnia 1977 roku.

## ONZ: widmo głodu w Afryce Zachodniej największe od 10 lat
 - [https://tvn24.pl/swiat/onz-widmo-glodu-w-afryce-zachodniej-najwieksze-od-10-lat-6948329?source=rss](https://tvn24.pl/swiat/onz-widmo-glodu-w-afryce-zachodniej-najwieksze-od-10-lat-6948329?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 07:58:29+00:00

<img alt="ONZ: widmo głodu w Afryce Zachodniej największe od 10 lat" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hd4vk0-onz-alarmuje-w-sprawie-niedozywionych-dzieci-6628897/alternates/LANDSCAPE_1280" />
    Przedstawiciele ONZ ostrzegają przed głodem zagrażającym 45 milionom obywateli Burkina Faso, Mali, Nigru, północnej Nigerii i Mauretanii. W ostatnim roku liczba dzieci przyjętych do szpitali w rejonie Sahelu z powodu niedożywienia wzrosła o 31 procent - przekazała ekspertka UNICEF.

## Koszalin. Uciekała przed policjantami z psem w aucie, uderzyła w radiowóz, a na końcu zabarykadowała się w środku
 - [https://tvn24.pl/pomorze/koszalin-uciekala-przed-policjantami-z-psem-w-aucie-uderzyla-w-radiowoz-a-na-koncu-zabarykadowala-sie-w-srodku-6948539?source=rss](https://tvn24.pl/pomorze/koszalin-uciekala-przed-policjantami-z-psem-w-aucie-uderzyla-w-radiowoz-a-na-koncu-zabarykadowala-sie-w-srodku-6948539?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 07:25:32+00:00

<img alt="Koszalin. Uciekała przed policjantami z psem w aucie, uderzyła w radiowóz, a na końcu zabarykadowała się w środku" src="https://tvn24.pl/najnowsze/cdn-zdjecie-zayazq-nocny-poscig-za-kierujaca-opla-w-koszalinie-6948549/alternates/LANDSCAPE_1280" />
    Policjanci z Koszalina (Zachodniopomorskie) zatrzymali kobietę, która wcześniej nie zatrzymała się do kontroli. W trakcie pościgu 59-latka spowodowała stłuczkę z radiowozem, a - gdy już była w rękach funkcjonariuszy - odmówiła badania alkomatem. Pobrano jej krew do badań.

## Wjechał w zaparkowane auto, dociskał je swoim samochodem do elewacji. Był pijany
 - [https://tvn24.pl/bialystok/radzyn-podlaski-wjechal-w-zaparkowane-auto-dociskal-je-swoim-samochodem-do-elewacji-byl-pijany-6948442?source=rss](https://tvn24.pl/bialystok/radzyn-podlaski-wjechal-w-zaparkowane-auto-dociskal-je-swoim-samochodem-do-elewacji-byl-pijany-6948442?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 07:00:08+00:00

<img alt="Wjechał w zaparkowane auto, dociskał je swoim samochodem do elewacji. Był pijany" src="https://tvn24.pl/najnowsze/cdn-zdjecie-uusao7-zatrzymano-go-gdy-siedzial-za-kierownica-6948458/alternates/LANDSCAPE_1280" />
    Blisko 2,5 promila alkoholu miał w organizmie 57-letni mieszkaniec Radzynia Podlaskiego (woj. lubelskie), który został zatrzymany, gdy siedział w aucie z nogą na pedale gazu. Jak podaje policja, mężczyzna wjechał w zaparkowane auto i dociskał je swoim samochodem do elewacji bloku.

## Media: były premier Francji Francois Fillon będzie przesłuchiwany w sprawie związków z Rosją
 - [https://tvn24.pl/swiat/francja-media-byly-premier-francois-fillon-bedzie-przesluchiwany-ws-swoich-zwiazkow-z-rosja-6948328?source=rss](https://tvn24.pl/swiat/francja-media-byly-premier-francois-fillon-bedzie-przesluchiwany-ws-swoich-zwiazkow-z-rosja-6948328?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 06:59:34+00:00

<img alt="Media: były premier Francji Francois Fillon będzie przesłuchiwany w sprawie związków z Rosją" src="https://tvn24.pl/najnowsze/cdn-zdjecie29769ce0da8e58b52b7ea0cb727445dc-na-zdjeciu-spotkanie-fillona-z-wladimirem-putinem-w-czerwcu-2015-roku-4338793/alternates/LANDSCAPE_1280" />
    Francuskie media podają, że były premier i kandydat na prezydenta kraju Francois Fillon będzie odpowiadał na pytania o swoje związki z Rosją przed komisją śledczą Zgromadzenia Narodowego.

## Prezydent Brazylii zmienił zdanie w sprawie wojny w Ukrainie
 - [https://tvn24.pl/swiat/brazylia-prezydent-lula-zmienil-zdanie-w-sprawie-wojny-juz-nie-popiera-agresji-rosji-na-ukrainie-6948321?source=rss](https://tvn24.pl/swiat/brazylia-prezydent-lula-zmienil-zdanie-w-sprawie-wojny-juz-nie-popiera-agresji-rosji-na-ukrainie-6948321?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 06:05:07+00:00

<img alt="Prezydent Brazylii zmienił zdanie w sprawie wojny w Ukrainie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8v0aih-prezydent-brazylii-luiz-inacio-lula-da-silva-6948320/alternates/LANDSCAPE_1280" />
    Luiz Inacio Lula da Silva zapewnia, że jego rząd potępia naruszenie terytorium Ukrainy. Wtorkowa wypowiedź prezydenta Brazylii była zaskoczeniem. Wcześniej twierdził bowiem, że "wojna wybuchła w wyniku decyzji podjętych przez dwa państwa", wzywał Unię i USA, by "przestały zachęcać Ukrainę do wojny".

## 81-latek stracił prawo jazdy za zbyt szybką jazdę
 - [https://tvn24.pl/tvnwarszawa/ulice/81-latek-stracil-prawo-jazdy-za-zbyt-szybka-jazde-6948395?source=rss](https://tvn24.pl/tvnwarszawa/ulice/81-latek-stracil-prawo-jazdy-za-zbyt-szybka-jazde-6948395?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 05:24:37+00:00

<img alt="81-latek stracił prawo jazdy za zbyt szybką jazdę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-siwlb8-mezczyzna-trabil-na-policjantow-drogowki-i-gwaltownie-przyspieszyl-zdjecie-ilustracyjne-6938118/alternates/LANDSCAPE_1280" />
    Policjanci wchodzący w skład mazowieckiej grupy Speed zatrzymali 81-latka, który w obszarze zabudowanym jechał z prędkością 106 kilometrów na godzinę. Stracił prawo jazdy na trzy miesiące.

## Joe Biden rozmawiał z Ralphem Yarlem, 16-latkiem, który został postrzelony w głowę, bo pomylił domy
 - [https://tvn24.pl/swiat/usa-prezydent-biden-rozmawial-z-16-latkiem-ktory-zostal-postrzelony-w-glowe-gdy-zapukal-do-niewlasciwych-drzwi-6948275?source=rss](https://tvn24.pl/swiat/usa-prezydent-biden-rozmawial-z-16-latkiem-ktory-zostal-postrzelony-w-glowe-gdy-zapukal-do-niewlasciwych-drzwi-6948275?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 05:01:41+00:00

<img alt="Joe Biden rozmawiał z Ralphem Yarlem, 16-latkiem, który został postrzelony w głowę, bo pomylił domy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-gw7d29-ralph-yarl-w-szpitalu-6930777/alternates/LANDSCAPE_1280" />
    Prezydent USA rozmawiał z czarnoskórym 16-latkiem, który został postrzelony w głowę w Kansas City po tym, jak pomylił się i zapukał do złych drzwi. Mężczyzna, który zaatakował chłopca, usłyszał zarzuty.

## Reforma emerytalna we Francji. Te wyliczenia pokazują, o co walczą Francuzi
 - [https://tvn24.pl/biznes/ze-swiata/reforma-emerytalna-we-francji-dlaczego-francuzi-protestuja-6948363?source=rss](https://tvn24.pl/biznes/ze-swiata/reforma-emerytalna-we-francji-dlaczego-francuzi-protestuja-6948363?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 04:55:34+00:00

<img alt="Reforma emerytalna we Francji. Te wyliczenia pokazują, o co walczą Francuzi" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-mwv9v9-francja-protesty-po-oredziu-prezydenta-macrona-w-sprawie-emerytur-6948370/alternates/LANDSCAPE_1280" />
    Skala protestów we Francji po wprowadzeniu reformy emerytalnej zaskakuje zagranicznych komentatorów, ponieważ tylko częściowo zrównuje wiek emerytalny z normami sąsiednich krajów - wskazuje agencja Reutera przytaczając przy tym dane OECD na temat emerytur Francuzów. Według nich francuscy emeryci spędzają na emeryturze 23,5 roku i otrzymują netto blisko trzy czwarte ostatniego wynagrodzenia.

## Niebezpieczna pogoda w części kraju. Alerty IMGW przed przymrozkami
 - [https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-przymrozki-gdzie-obowiazuja-ostrzezenia-meteo-6948359?source=rss](https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-przymrozki-gdzie-obowiazuja-ostrzezenia-meteo-6948359?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 04:28:25+00:00

<img alt="Niebezpieczna pogoda w części kraju. Alerty IMGW przed przymrozkami" src="https://tvn24.pl/najnowsze/cdn-zdjecie-e3263e-moga-pojawic-sie-przymrozki/alternates/LANDSCAPE_1280" />
    IMGW wydał ostrzeżenia meteorologiczne pierwszego stopnia. W nadchodzących godzinach zagrożeniem będą przymrozki. Sprawdź, gdzie obowiązują alarmy.

## Zakaz zatrzymywania się i postoju na kilku ulicach. Autobusy linii 111 i 180 pojadą zmienionymi trasami
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-zakaz-zatrzymywania-sie-i-postoju-na-kilku-ulicach-autobusy-linii-111-i-180-pojada-zmienionymi-trasami-6936889?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-zakaz-zatrzymywania-sie-i-postoju-na-kilku-ulicach-autobusy-linii-111-i-180-pojada-zmienionymi-trasami-6936889?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 04:08:00+00:00

<img alt="Zakaz zatrzymywania się i postoju na kilku ulicach. Autobusy linii 111 i 180 pojadą zmienionymi trasami " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-37xuoa-rocznica-wybuchu-powstania-w-getcie-warszawskim-zdjecie-ilustracyjne-6761151/alternates/LANDSCAPE_1280" />
    W środę przypada 80. rocznica powstania w getcie warszawskim. Główne uroczystości odbędą się w Muzeum Historii Żydów Polskich POLIN i jego bezpośredniej okolicy, dlatego na Anielewicza, Karmelickiej, Lewartowskiego, Nalewki i Zamenhofa będzie obowiązywał zakaz zatrzymywania się i postoju. Linie autobusowe 111 i 180 pojadą zmienionymi trasami.

## W samo południe zawyły syreny i zabiły dzwony
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-syreny-zawyly-w-samo-poludnie-6948349?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-syreny-zawyly-w-samo-poludnie-6948349?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 04:07:00+00:00

<img alt="W samo południe zawyły syreny i zabiły dzwony" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-c45k3w-uroczystosci-z-okazji-80-rocznicy-wybuchu-powstania-w-getcie-warszawskim-przed-pomnikiem-bohaterow-getta-w-warszawie-6948921/alternates/LANDSCAPE_1280" />
    Dziś w samo południe na 60 sekund uruchomione zostały na minutę syreny alarmowe w stolicy. Zabiły też dzwony. Dla upamiętnienia 80. rocznicy powstania w warszawskim getcie. Rozpoczęły główne obchody.

## 80 lat temu wybuchło powstanie w warszawskim getcie
 - [https://tvn24.pl/tvnwarszawa/najnowsze/80-lat-temu-wybuchlo-powstanie-w-warszawskim-getcie-6938477?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/80-lat-temu-wybuchlo-powstanie-w-warszawskim-getcie-6938477?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 04:04:59+00:00

<img alt="80 lat temu wybuchło powstanie w warszawskim getcie" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-c6ej5s-powstanie-w-warszawskim-getcie-zdjecia-z-raportu-jurgena-stroopa-przygotowanego-dla-heinricha-himmlera-w-1943-roku-84840/alternates/LANDSCAPE_1280" />
    Wystawa "Wokół nas morze ognia" w Muzeum POLIN, akcja społeczno-edukacyjna Żonkile, sadzenie Drzewa Pamięci, koncerty, spektakle, spotkania i spacery. 19 kwietnia przypada 80. rocznica wybuchu powstania w getcie warszawskim.

## Tajemnica skrzyni numer cztery
 - [https://tvn24.pl/premium/tajemnica-skrzyni-numer-cztery-6930395?source=rss](https://tvn24.pl/premium/tajemnica-skrzyni-numer-cztery-6930395?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 04:02:41+00:00

<img alt="Tajemnica skrzyni numer cztery" src="https://tvn24.pl/najnowsze/cdn-zdjecie-u6u3o9-pierwsza-czesc-ukryto-wlasnie-w-piwnicy-szkoly-na-nowolipkach-68-6930492/alternates/LANDSCAPE_1280" />
    Skrzynia jest wielkości pudełka na buty. Co byś do niej włożył, gdybyś chciał opowiedzieć innym o swoim życiu? Gdybyś wiedział, że jutro możesz się nie obudzić?

## Operacja Interpolu w 15 krajach Ameryki Łacińskiej, ponad 14 tysięcy aresztowanych
 - [https://tvn24.pl/swiat/operacja-interpolu-w-15-krajach-ameryki-lacinskiej-ponad-14-tysiecy-aresztowanych-6948344?source=rss](https://tvn24.pl/swiat/operacja-interpolu-w-15-krajach-ameryki-lacinskiej-ponad-14-tysiecy-aresztowanych-6948344?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 03:58:59+00:00

<img alt="Operacja Interpolu w 15 krajach Ameryki Łacińskiej, ponad 14 tysięcy aresztowanych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-tcqon2-interpol-przeprowadzil-jedna-z-najwiekszych-w-skali-swiatowej-operacji-6948336/alternates/LANDSCAPE_1280" />
    Ponad 14 tysięcy osób zostało aresztowanych w jednej z największych w skali światowej operacji Interpolu przeprowadzonej w 15 krajach Ameryki Łacińskiej pod kryptonimem Trigger IX. Oprócz tego służby skonfiskowały ponad osiem tysięcy sztuk broni palnej i 300 tysięcy sztuk amunicji.

## Pogoda na dziś - środa 19.04. Śnieg z deszczem możliwy w części kraju
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-dzis-sroda-1904-snieg-z-deszczem-mozliwy-w-czesci-kraju-6938499?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-dzis-sroda-1904-snieg-z-deszczem-mozliwy-w-czesci-kraju-6938499?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-19 00:00:00+00:00

<img alt="Pogoda na dziś - środa 19.04. Śnieg z deszczem możliwy w części kraju" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-wjw5ow-snieg-z-deszczem-6774206/alternates/LANDSCAPE_1280" />
    Pogoda na dziś. W środę 19.04 front atmosferyczny przyniesie opady deszczu w całej Polsce, a lokalnie na zachodzie może popadać również śnieg z deszczem. Tamta część kraju będzie najchłodniejsza. Wiatr chwilami mocno powieje, w porywach na Wybrzeżu osiągnie prędkość nawet do 80 kilometrów na godzinę.

