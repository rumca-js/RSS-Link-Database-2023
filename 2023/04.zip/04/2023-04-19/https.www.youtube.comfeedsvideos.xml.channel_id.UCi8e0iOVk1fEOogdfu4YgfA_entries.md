# Source:Rotten Tomatoes Trailers, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCi8e0iOVk1fEOogdfu4YgfA, language:en-US

## Fast X Trailer #2 (2023)
 - [https://www.youtube.com/watch?v=OkVq7zoLi_U](https://www.youtube.com/watch?v=OkVq7zoLi_U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCi8e0iOVk1fEOogdfu4YgfA
 - date published: 2023-04-19 21:59:52+00:00

Check out the official trailer for Fast X starring Jason Momoa! 
► Buy Tickets on Fandango: https://www.fandango.com/fast-x-2023-230799/movie-overview?cmp=Trailers_YouTube_Desc

Subscribe to the channel and click the bell icon to be notified of all the hottest trailers: http://bit.ly/2CNniBy 

US Release Date: May 19, 2023
Starring:  Vin Diesel, Jason Statham, Michelle Rodriguez, Tyrese Gibson, Chris "Ludacris" Bridges, John Cena, Jason Momoa, Jordana Brewster, Brie Larson, Nathalie Emmanuel, Sung Kang, Scott Eastwood, Michael Rooker, Daniela Melchior, Alan Ritchson, Helen Mirren, Cardi B, Rita Moreno, and Charlize Theron
Director: Louis Leterrier
Synopsis: Over many missions and against impossible odds, Dom Toretto (Vin Diesel) and his family have outsmarted, out-nerved and outdriven every foe in their path. Now, they confront the most lethal opponent they’ve ever faced: A terrifying threat emerging from the shadows of the past who’s fueled by blood revenge, and who is determined to shatter this family and destroy everything—and everyone—that Dom loves, forever. In 2011’s Fast Five, Dom and his crew took out nefarious Brazilian drug kingpin Hernan Reyes and decapitated his empire on a bridge in Rio De Janeiro. What they didn’t know was that Reyes’ son, Dante (Aquaman’s Jason Momoa), witnessed it all and has spent the last 12 years masterminding a plan to make Dom pay the ultimate price. Dante’s plot will scatter Dom’s family from Los Angeles to the catacombs of Rome, from Brazil to London and from Portugal to Antarctica. New allies will be forged and old enemies will resurface. But everything changes when Dom discovers that his own 8-year-old son (Leo Abelo Perry, Black-ish) is the ultimate target of Dante’s vengeance. 

► Learn more: https://www.rottentomatoes.com/m/fast_x?cmp=Trailers_YouTube_Desc 

Watch More:  
► Rotten Tomatoes Originals: http://bit.ly/2D3sipV    
► Fresh New Clips: https://bit.ly/3mJePrv    
► Hot New Trailers: http://bit.ly/2qThrsF   
► New TV This Week: https://bit.ly/3Or3I2w   
 
Rotten Tomatoes TRAILERS delivers hot new trailers, exclusive content, and first looks for all the best upcoming movies. Be the first to see everything coming to theaters and your favorite streaming platforms - all in one place!

#FastX #TheFastSaga #UniversalPictures

## Guardians of the Galaxy Vol. 3 Featurette - One Last Ride (2023)
 - [https://www.youtube.com/watch?v=547sVvdZEKY](https://www.youtube.com/watch?v=547sVvdZEKY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCi8e0iOVk1fEOogdfu4YgfA
 - date published: 2023-04-19 18:12:42+00:00

Check out a Guardians of the Galaxy Volume 3 featurette starring Dave Bautista and Pom Klementieff!

► Buy Tickets on Fandango: https://www.fandango.com/guardians-of-the-galaxy-vol-3-2023-228959/movie-overview?cmp=Trailers_YouTube_Desc

Subscribe to the channel and click the bell icon to be notified of all the hottest trailers: http://bit.ly/2CNniBy 

US Release Date: May 5, 2023
Starring: Zoe Saldana, Chris Pratt, Bradley Cooper, Dave Bautista, Vin Diesel, Karen Gillan, Pom Klementieff
Director: James Gunn
Synopsis: In Marvel Studios "Guardians of the Galaxy Vol. 3" our beloved band of misfits are looking a bit different these days. Peter Quill, still reeling from the loss of Gamora, must rally his team around him to defend the universe along with protecting one of their own. A mission that, if not completed successfully, could quite possibly lead to the end of the Guardians as we know them.


► Learn more: https://www.rottentomatoes.com/m/guardians_of_the_galaxy_vol_3?cmp=Trailers_YouTube_Desc 

Watch More:  
► Rotten Tomatoes Originals: http://bit.ly/2D3sipV    
► Fresh New Clips: https://bit.ly/3mJePrv    
► Hot New Trailers: http://bit.ly/2qThrsF   
► New TV This Week: https://bit.ly/3Or3I2w   
 
Rotten Tomatoes TRAILERS delivers hot new trailers, exclusive content, and first looks for all the best upcoming movies. Be the first to see everything coming to theaters and your favorite streaming platforms - all in one place!

#GuardiansOfTheGalaxy #GuardiansOfTheGalaxy3 #Disney #Marvel #GotGVol3

## Godzilla x Kong: The New Empire Title Announcement (2024)
 - [https://www.youtube.com/watch?v=_ALzubCN-e4](https://www.youtube.com/watch?v=_ALzubCN-e4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCi8e0iOVk1fEOogdfu4YgfA
 - date published: 2023-04-19 16:46:41+00:00

Check out the official title announcement for Godzilla x Kong: The New Empire! 
► Visit Fandango: http://www.fandango.com/?cmp=Trailers_YouTube_Desc

Subscribe to the channel and click the bell icon to be notified of all the hottest trailers: http://bit.ly/2CNniBy 

► Shop Rotten Tomatoes: http://bit.ly/3KvCU1M

US Release Date: March 15, 2024
Starring: Rebecca Hall, Brian Tyree Henry, Kaylee Hottle
Director: Adam Wingard
Synopsis: This latest entry in the Monsterverse franchise follows up the explosive showdown of Godzilla vs. Kong with an all-new cinematic adventure, pitting the almighty Kong and the fearsome Godzilla against a colossal undiscovered threat hidden within our world, challenging their very existence – and our own. The epic new film will delve further into the histories of these Titans, their origins, and the mysteries of Skull Island and beyond, while uncovering the mythic battle that helped forge these extraordinary beings and tied them to humankind forever.

► Learn more: https://www.rottentomatoes.com/?cmp=Trailers_YouTube_Desc 

Watch More:  
► Rotten Tomatoes Originals: http://bit.ly/2D3sipV    
► Fresh New Clips: https://bit.ly/3mJePrv    
► Hot New Trailers: http://bit.ly/2qThrsF   
► New TV This Week: https://bit.ly/3Or3I2w   
 
Rotten Tomatoes TRAILERS delivers hot new trailers, exclusive content, and first looks for all the best upcoming movies. Be the first to see everything coming to theaters and your favorite streaming platforms - all in one place!

#GodzillaxKong #WarnerBros

## Reality Teaser #1 (2023)
 - [https://www.youtube.com/watch?v=6F1zeaqXds4](https://www.youtube.com/watch?v=6F1zeaqXds4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCi8e0iOVk1fEOogdfu4YgfA
 - date published: 2023-04-19 14:55:14+00:00

Check out the official teaser for Reality starring Sydney Sweeney! 
► Visit Fandango: http://www.fandango.com/?cmp=Trailers_YouTube_Desc

Subscribe to the channel and click the bell icon to be notified of all the hottest trailers: http://bit.ly/2CNniBy 

► Shop Rotten Tomatoes: http://bit.ly/3KvCU1M

US Release Date: May 29, 2023
Starring: Sydney Sweeney, Marchánt Davis, Josh Hamilton
Director: Tina Satter
Synopsis: On a Saturday afternoon, in June 2017, Reality Winner, a 25-year-old in cut-off jeans, is confronted at her Georgia home by the FBI. A cryptic conversation begins and Reality's life quickly begins to unravel.
► Learn more: https://www.rottentomatoes.com/m/reality_2023?cmp=Trailers_YouTube_Desc 

Watch More:  
► Rotten Tomatoes Originals: http://bit.ly/2D3sipV    
► Fresh New Clips: https://bit.ly/3mJePrv    
► Hot New Trailers: http://bit.ly/2qThrsF   
► New TV This Week: https://bit.ly/3Or3I2w   
 
Rotten Tomatoes TRAILERS delivers hot new trailers, exclusive content, and first looks for all the best upcoming movies. Be the first to see everything coming to theaters and your favorite streaming platforms - all in one place!

#Reality #HBOMax #SydneySweeney

## Insidious: The Red Door Trailer #1 (2023)
 - [https://www.youtube.com/watch?v=naWC6PCPXoY](https://www.youtube.com/watch?v=naWC6PCPXoY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCi8e0iOVk1fEOogdfu4YgfA
 - date published: 2023-04-19 14:27:41+00:00

Check out the official trailer for Insidious: The Red Door starring Patrick Wilson! 
► Sign up for a Fandango FanAlert for Insidious: The Red Door: https://www.fandango.com/insidious-the-red-door-2023-231697/movie-overview?cmp=Trailers_YouTube_Desc

Subscribe to the channel and click the bell icon to be notified of all the hottest trailers: http://bit.ly/2CNniBy 

► Shop Rotten Tomatoes: http://bit.ly/3KvCU1M

US Release Date: July 7, 2023
Starring: Patrick Wilson, Rose Byrne, Ty Simpkins
Director: Patrick Wilson
Synopsis: Josh Lambert heads east to drop his son, Dalton, off at school. However, Dalton's college dream soon becomes a living nightmare when the repressed demons of his past suddenly return to haunt them both.
► Learn more: https://www.rottentomatoes.com/m/insidious_fear_the_dark?cmp=Trailers_YouTube_Desc 

Watch More:  
► Rotten Tomatoes Originals: http://bit.ly/2D3sipV    
► Fresh New Clips: https://bit.ly/3mJePrv    
► Hot New Trailers: http://bit.ly/2qThrsF   
► New TV This Week: https://bit.ly/3Or3I2w   
 
Rotten Tomatoes TRAILERS delivers hot new trailers, exclusive content, and first looks for all the best upcoming movies. Be the first to see everything coming to theaters and your favorite streaming platforms - all in one place!

#Insidious5 #InsidiousTheRedDoor #SonyPictures

## Love Again - Tickets on Sale (2023)
 - [https://www.youtube.com/watch?v=gV6f_M_45o0](https://www.youtube.com/watch?v=gV6f_M_45o0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCi8e0iOVk1fEOogdfu4YgfA
 - date published: 2023-04-19 13:00:28+00:00

Check out a TV spot for Love Again starring Nick Jonas! 

► Buy Tickets for Love Again: https://www.fandango.com/love-again-2023-231097/movie-overview?cmp=Trailers_YouTube_Desc

Subscribe to the channel and click the bell icon to be notified of all the hottest trailers: http://bit.ly/2CNniBy 

US Release Date: May 12, 2023
Starring: Priyanka Chopra Jonas, Sam Heughan, Céline Dion, Nick Jonas
Director: James C. Strouse
Synopsis: What if a random text message led to the love of your life? In this romantic comedy, dealing with the loss of her fiancé, Mira Ray sends a series of romantic texts to his old cell phone number... not realizing the number was reassigned to Rob Burns' new work phone. A journalist, Rob is captivated by the honesty in the beautifully confessional texts. When he's assigned to write a profile of megastar Celine Dion (playing herself in her first film role), he enlists her help in figuring out how to meet Mira in person... and win her heart.

► Learn more: https://www.rottentomatoes.com/m/its_all_coming_back_to_me?cmp=Trailers_YouTube_Desc 

Watch More:  
► Rotten Tomatoes Originals: http://bit.ly/2D3sipV    
► Fresh New Clips: https://bit.ly/3mJePrv    
► Hot New Trailers: http://bit.ly/2qThrsF   
► New TV This Week: https://bit.ly/3Or3I2w   
 
Rotten Tomatoes TRAILERS delivers hot new trailers, exclusive content, and first looks for all the best upcoming movies. Be the first to see everything coming to theaters and your favorite streaming platforms - all in one place!

#LoveAgain #NickJonas #SonyPictures

