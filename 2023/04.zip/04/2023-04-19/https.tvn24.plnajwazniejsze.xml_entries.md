# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## Starania Bayernu na nic. Manchester City w półfinale LM
 - [https://eurosport.tvn24.pl/starania-bayernu-na-nic--manchester-city-w-p--finale-ligi-mistrz-w,1143402.html?source=rss](https://eurosport.tvn24.pl/starania-bayernu-na-nic--manchester-city-w-p--finale-ligi-mistrz-w,1143402.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 21:00:00+00:00

<img alt="Starania Bayernu na nic. Manchester City w półfinale LM" src="https://tvn24.pl/najnowsze/cdn-zdjecie-nqp3sa-haaland-strzelil-pieknego-gola-6950638/alternates/LANDSCAPE_1280" />
    Monachijczyków stać było tylko na remis.

## Grad goli w Mediolanie. Inter nie zmarnował szansy
 - [https://eurosport.tvn24.pl/grad-goli-w-mediolanie--inter-w-p--finale-ligi-mistrz-w,1143423.html?source=rss](https://eurosport.tvn24.pl/grad-goli-w-mediolanie--inter-w-p--finale-ligi-mistrz-w,1143423.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 20:59:01+00:00

<img alt="Grad goli w Mediolanie. Inter nie zmarnował szansy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ioldlv-inter-moze-cieszyc-sie-z-awansu-6950640/alternates/LANDSCAPE_1280" />
    Benfica walczyła do końca.

## Anulowana czerwona kartka. Uratowały go centymetry
 - [https://eurosport.tvn24.pl/anulowana-czerwona-kartka--obro-c--bayernu-uratowa-y-centymetry,1143413.html?source=rss](https://eurosport.tvn24.pl/anulowana-czerwona-kartka--obro-c--bayernu-uratowa-y-centymetry,1143413.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 19:59:00+00:00

<img alt="Anulowana czerwona kartka. Uratowały go centymetry" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qisnpc-obronce-bayernu-uratowal-var-6950192/alternates/LANDSCAPE_1280" />
    Obrońca Bayernu mógł mówić o sporym szczęściu.

## Wybuch w domu wielorodzinnym. "Budynek częściowo uległ zawaleniu"
 - [https://tvn24.pl/poznan/sedziniec-wielkopolska-wybuch-w-domu-wielorodzinnym-6950117?source=rss](https://tvn24.pl/poznan/sedziniec-wielkopolska-wybuch-w-domu-wielorodzinnym-6950117?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 19:18:55+00:00

<img alt="Wybuch w domu wielorodzinnym. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-7ivg41-gaz-drv-www-6950128/alternates/LANDSCAPE_1280" />
    Cztery osoby zostały przewiezione do szpitala.

## Bayern nie składa broni. Ostatnie ćwierćfinały w Lidze Mistrzów
 - [https://eurosport.tvn24.pl/bayern-monachium---manchester-city--wynik-na--ywo-i-relacja-live-z-meczu-1-4-fina-u-ligi-mistrz-w,1143374.html?source=rss](https://eurosport.tvn24.pl/bayern-monachium---manchester-city--wynik-na--ywo-i-relacja-live-z-meczu-1-4-fina-u-ligi-mistrz-w,1143374.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 19:18:00+00:00

<img alt="Bayern nie składa broni. Ostatnie ćwierćfinały w Lidze Mistrzów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-b8b03s-bayern-city-6950123/alternates/LANDSCAPE_1280" />
    Relacja w eurosport.pl.

## Pytanie w "Milionerach" o zoofaga wśród fitofagów za pięć tysięcy złotych
 - [https://tvn24.pl/toteraz/milionerzy-tvn-wskaz-zoofaga-wsrod-fitofagow-pytanie-i-prawidlowa-odpowiedz-6949510?source=rss](https://tvn24.pl/toteraz/milionerzy-tvn-wskaz-zoofaga-wsrod-fitofagow-pytanie-i-prawidlowa-odpowiedz-6949510?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 19:15:00+00:00

<img alt="Pytanie w " src="https://tvn24.pl/najnowsze/cdn-zdjecie-wlwpkb-pytanie-w-milionerach-o-zoofaga-wsrod-fitofagow-6949442/alternates/LANDSCAPE_1280" />
    Koala, zebra, orka czy krowa?

## Wodorosty, wosk pszczeli, witamina B2. Stworzyli jadalną baterię
 - [https://tvn24.pl/tvnmeteo/nauka/wloscy-naukowcy-zbudowali-jadalna-baterie-6949676?source=rss](https://tvn24.pl/tvnmeteo/nauka/wloscy-naukowcy-zbudowali-jadalna-baterie-6949676?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 19:08:45+00:00

<img alt="Wodorosty, wosk pszczeli, witamina B2. Stworzyli jadalną baterię" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-dp0zfb-wloscy-naukowcy-zbudowali-jadalna-baterie-6949844/alternates/LANDSCAPE_1280" />
    "Nadająca się do spożycia elektronika może mieć ogromny wpływ na diagnostykę i leczenie chorób".

## "Nienawiść, która kończy się ludobójstwem, niestety istnieje"
 - [https://tvn24.pl/80-rocznica-powstania-w-getcie-warszawskim/powstanie-w-getcie-warszawskim-80-rocznica-wybuchu-profesor-barbara-engelking-o-holokauscie-i-wystawie-wokol-nas-morze-ognia-w-muzeum-polin-6950061?source=rss](https://tvn24.pl/80-rocznica-powstania-w-getcie-warszawskim/powstanie-w-getcie-warszawskim-80-rocznica-wybuchu-profesor-barbara-engelking-o-holokauscie-i-wystawie-wokol-nas-morze-ognia-w-muzeum-polin-6950061?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 19:02:49+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4x43qi-specjalne-wydanie-kropki-nad-i-z-muzeum-polin-6950040/alternates/LANDSCAPE_1280" />
    Barbara Engelking w specjalnym wydaniu "Kropki nad i".

## "O Zagładzie można opowiedzieć do pewnego momentu, a później jest cisza"
 - [https://tvn24.pl/go/programy,7/opinie-i-wydarzenia-odcinki,16593/odcinek-3188,S00E3188,1047614?source=rss](https://tvn24.pl/go/programy,7/opinie-i-wydarzenia-odcinki,16593/odcinek-3188,S00E3188,1047614?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 18:48:33+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ovwxsh-hanna-krall-6950079/alternates/LANDSCAPE_1280" />
    Hanna Krall o Zagładzie, Marku Edelmanie i pisaniu "Zdążyć przed Panem Bogiem".

## "W getcie trzeba było mieć kogoś, kogo się kochało"
 - [https://tvn24.pl/polska/80-rocznica-wybuchu-powstania-w-warszawskim-getcie-paula-sawicka-w-getcie-trzeba-bylo-miec-kogos-kogo-sie-kochalo-6950058?source=rss](https://tvn24.pl/polska/80-rocznica-wybuchu-powstania-w-warszawskim-getcie-paula-sawicka-w-getcie-trzeba-bylo-miec-kogos-kogo-sie-kochalo-6950058?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 18:38:41+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1tzysi-19-1925-fpf-gosc-0001-6950063/alternates/LANDSCAPE_1280" />
    80. rocznica wybuchu w warszawskim getcie.

## Stoltenberg: trzeba nadal mu udowadniać, że się myli
 - [https://tvn24.pl/swiat/inwazja-zbrojna-na-ukraine-jens-stoltenberg-trzeba-udowodnic-wladimirowi-putinowi-ze-sie-myli-6949878?source=rss](https://tvn24.pl/swiat/inwazja-zbrojna-na-ukraine-jens-stoltenberg-trzeba-udowodnic-wladimirowi-putinowi-ze-sie-myli-6949878?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 17:54:13+00:00

<img alt="Stoltenberg: trzeba nadal mu udowadniać, że się myli  " src="https://tvn24.pl/najnowsze/cdn-zdjecie-gsskt1-wladimir-putin-6897890/alternates/LANDSCAPE_1280" />
    Sekretarz generalny NATO o Władimirze Putinie.

## Spadła winda. Jeden mężczyzna nie żyje, drugi został ranny
 - [https://tvn24.pl/tvnwarszawa/okolice/sierpc-wypadek-w-markecie-budowlanym-spadla-winda-jeden-mezczyzna-zginal-6949970?source=rss](https://tvn24.pl/tvnwarszawa/okolice/sierpc-wypadek-w-markecie-budowlanym-spadla-winda-jeden-mezczyzna-zginal-6949970?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 17:51:31+00:00

<img alt="Spadła winda. Jeden mężczyzna nie żyje, drugi został ranny" src="https://tvn24.pl/najnowsze/cdn-zdjecie-z1qqur-wypadek-w-markecie-budowlanym-w-sierpcu-nie-zyje-mezczyzna-zdjecie-ilustracyjne-6949972/alternates/LANDSCAPE_1280" />
    Wypadek w Sierpcu (Mazowieckie).

## "To był początek powstania przeciwko nienawiści"
 - [https://tvn24.pl/polska/80-rocznica-wybuchu-powstania-w-getcie-warszawskim-to-byl-poczatek-powstania-przeciwko-nienawisci-6949987?source=rss](https://tvn24.pl/polska/80-rocznica-wybuchu-powstania-w-getcie-warszawskim-to-byl-poczatek-powstania-przeciwko-nienawisci-6949987?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 17:39:50+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-k5fif2-dana-bash-i-wolf-blitzer-w-rozmowie-z-marcinem-wrona-6949996/alternates/LANDSCAPE_1280" />
    Dziennikarze CNN Dana Bash i i Wolf Blitzer w Warszawie wzięli udział w obchodach 80. rocznicy powstania w getcie warszawskim.

## Biedronka wycofuje partię produktu. "Nie należy spożywać"
 - [https://tvn24.pl/biznes/z-kraju/rolada-ze-szpinakiem-wycofywana-z-obrotu-ostrzezenie-gis-6949951?source=rss](https://tvn24.pl/biznes/z-kraju/rolada-ze-szpinakiem-wycofywana-z-obrotu-ostrzezenie-gis-6949951?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 17:35:05+00:00

<img alt="Biedronka wycofuje partię produktu. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-cgp0xx-sklep-zakupy-koszyk-shutterstock1474739102-5754031/alternates/LANDSCAPE_1280" />
    Ostrzeżenie.

## "Wybór prawdziwych mężczyzn!". Rosjanie werbują na kontach przedszkoli
 - [https://tvn24.pl/swiat/rosja-nowaja-gazieta-jewropa-rosjanie-werbuja-na-wojne-kontach-przedszkoli-6949889?source=rss](https://tvn24.pl/swiat/rosja-nowaja-gazieta-jewropa-rosjanie-werbuja-na-wojne-kontach-przedszkoli-6949889?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 17:34:53+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-s6nd2k-propagandowy-plakat-z-rosyjskim-zolnierzem-6930992/alternates/LANDSCAPE_1280" />
    Chodzi o dziesiątki tysięcy ogłoszeń i jest ich coraz więcej - pisze niezależna "Nowaja Gazieta Jewropa".

## Mistrz świata sprzed czterech lat wyeliminowany
 - [https://eurosport.tvn24.pl/niespodzianka-w-sheffield--mistrz--wiata-sprzed-czterech-lat-wyeliminowany,1143376.html?source=rss](https://eurosport.tvn24.pl/niespodzianka-w-sheffield--mistrz--wiata-sprzed-czterech-lat-wyeliminowany,1143376.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 17:16:00+00:00

<img alt="Mistrz świata sprzed czterech lat wyeliminowany" src="https://tvn24.pl/najnowsze/cdn-zdjecie-u2vgbw-judd-trump-odpadl-w-pierwszej-rundzie-6949988/alternates/LANDSCAPE_1280" />
    Judd Trump odpadł już w pierwszej rundzie.

## Uciekł z transportu do Treblinki i wstąpił do AK. "Moim dzieciom tego nigdy nie opowiadałem"
 - [https://fakty.tvn24.pl/uciek--z-transportu-do-treblinki-i-wst-pi--do-ak---moim-dzieciom-tego-nigdy-nie-opowiada-em-,1143381.html?source=rss](https://fakty.tvn24.pl/uciek--z-transportu-do-treblinki-i-wst-pi--do-ak---moim-dzieciom-tego-nigdy-nie-opowiada-em-,1143381.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 17:14:00+00:00

<img alt="Uciekł z transportu do Treblinki i wstąpił do AK. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-rxnxwg-uciekl-z-transportu-do-treblinki-i-wstapil-do-ak-6950034/alternates/LANDSCAPE_1280" />
    Stanisław Aronson wrócił do Warszawy na kilka miesięcy przed wybuchem powstania w getcie.

## "Krytyka tych rozwiązań była po prostu miażdżąca"
 - [https://fakty.tvn24.pl/rz-d-wycofa--si--z-ustawy-lex-pilot---krytyka-tych-rozwi-za--by-a-po-prostu-mia-d--ca-,1143386.html?source=rss](https://fakty.tvn24.pl/rz-d-wycofa--si--z-ustawy-lex-pilot---krytyka-tych-rozwi-za--by-a-po-prostu-mia-d--ca-,1143386.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 17:11:08+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6z7ism-rzad-wycofal-sie-z-ustawy-lex-pilot-6950072/alternates/LANDSCAPE_1280" />
    Rząd wycofał się z ustawy lex pilot.

## "Kłamstwa mają konsekwencje". Fox News za nie zapłaci
 - [https://tvn24.pl/swiat/usa-fox-news-zawarl-ugode-musi-zaplacic-za-rozpowszechnianie-klamstw-o-falszerstwach-wyborczych-6949788?source=rss](https://tvn24.pl/swiat/usa-fox-news-zawarl-ugode-musi-zaplacic-za-rozpowszechnianie-klamstw-o-falszerstwach-wyborczych-6949788?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 16:42:07+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6emgey-fox-news-6949933/alternates/LANDSCAPE_1280" />
    Ugoda na 787,5 milionów dolarów z Dominion Voting Systems.

## Młody polski zawodnik rezygnuje ze skakania
 - [https://eurosport.tvn24.pl/m-ody-polski-zawodnik-rezygnuje-ze-skakania,1143363.html?source=rss](https://eurosport.tvn24.pl/m-ody-polski-zawodnik-rezygnuje-ze-skakania,1143363.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 16:02:00+00:00

<img alt="Młody polski zawodnik rezygnuje ze skakania" src="https://tvn24.pl/najnowsze/cdn-zdjecie-v6syac-szymon-zapotoczny-byl-podopiecznym-w-klubie-kamila-stocha-6949864/alternates/LANDSCAPE_1280" />
    "Koniec kariery, przygody w skokach".

## Niemiecki gigant zainwestuje ponad miliard w budowę fabryki w Polsce
 - [https://tvn24.pl/biznes/z-kraju/bosch-zainwestuje-12-mld-zl-w-budowe-fabryki-pompo-ciepla-w-polsce-6949836?source=rss](https://tvn24.pl/biznes/z-kraju/bosch-zainwestuje-12-mld-zl-w-budowe-fabryki-pompo-ciepla-w-polsce-6949836?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 15:54:51+00:00

<img alt="Niemiecki gigant zainwestuje ponad miliard w budowę fabryki w Polsce" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pd99n8-bosch-shutterstock1731511594-5641280/alternates/LANDSCAPE_1280" />
    Pracę ma znaleźć 500 osób.

## Niemiecki gigant zainwestuje ponad miliard w budowę fabryki w Polsce
 - [https://tvn24.pl/biznes/z-kraju/bosch-zainwestuje-12-mld-zl-w-budowe-fabryki-pomp-ciepla-w-polsce-6949836?source=rss](https://tvn24.pl/biznes/z-kraju/bosch-zainwestuje-12-mld-zl-w-budowe-fabryki-pomp-ciepla-w-polsce-6949836?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 15:54:51+00:00

<img alt="Niemiecki gigant zainwestuje ponad miliard w budowę fabryki w Polsce" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pd99n8-bosch-shutterstock1731511594-5641280/alternates/LANDSCAPE_1280" />
    Pracę ma znaleźć 500 osób.

## 17-latka uratowana po dobie spędzonej na wodach oceanu
 - [https://tvn24.pl/swiat/portugalia-wiatr-porwal-17-latke-w-glab-oceanu-uratowano-ja-po-22-godzinach-6949769?source=rss](https://tvn24.pl/swiat/portugalia-wiatr-porwal-17-latke-w-glab-oceanu-uratowano-ja-po-22-godzinach-6949769?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 15:49:45+00:00

<img alt="17-latka uratowana po dobie spędzonej na wodach oceanu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9lsk2g-17-letnia-erica-uratowana-po-dobie-spedzonej-na-oceanie-6949866/alternates/LANDSCAPE_1280" />
    Unosiła się na desce, miała na sobie tylko bikini.

## Jechali z trzech stron, zderzyli się na skrzyżowaniu. Nagranie
 - [https://tvn24.pl/lodz/aleksandrow-lodzki-zderzenie-trzech-samochodow-jedna-osoba-ranna-nagranie-6949775?source=rss](https://tvn24.pl/lodz/aleksandrow-lodzki-zderzenie-trzech-samochodow-jedna-osoba-ranna-nagranie-6949775?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 15:47:06+00:00

<img alt="Jechali z trzech stron, zderzyli się na skrzyżowaniu. Nagranie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mhf8jh-zderzenie-trzech-samochodow-w-aleksandrowie-lodzkim-6949674/alternates/LANDSCAPE_1280" />
    Utrudnienia trwały blisko trzy godziny.

## Koniec lex pilot
 - [https://tvn24.pl/biznes/z-kraju/koniec-lex-pilot-rzad-rezygnuje-z-kontrowersyjnych-zapisow-6949734?source=rss](https://tvn24.pl/biznes/z-kraju/koniec-lex-pilot-rzad-rezygnuje-z-kontrowersyjnych-zapisow-6949734?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 15:46:46+00:00

<img alt="Koniec lex pilot" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jkdf3i-telewizor-telewizja-media-5720676/alternates/LANDSCAPE_1280" />
    Rządowe propozycje budziły kontrowersje.

## Biała stała i nagle wpadła do kieszeni, faulu nie było. "Bardzo rzadka sytuacja"
 - [https://eurosport.tvn24.pl/bia-a-sta-a-i-nagle-wpad-a-do-kieszeni--faulu-nie-by-o---bardzo-rzadka-sytuacja-,1143352.html?source=rss](https://eurosport.tvn24.pl/bia-a-sta-a-i-nagle-wpad-a-do-kieszeni--faulu-nie-by-o---bardzo-rzadka-sytuacja-,1143352.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 15:45:00+00:00

<img alt="Biała stała i nagle wpadła do kieszeni, faulu nie było. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-d9she3-nietypowa-sytuacja-podczas-1-6949847/alternates/LANDSCAPE_1280" />
    Arbiter zachował się jak najbardziej prawidłowo.

## Mogła być rywalką Świątek, błyskawicznie odpadła
 - [https://eurosport.tvn24.pl/mog-a-by--rywalk---wi-tek--b-yskawicznie-odpad-a,1143359.html?source=rss](https://eurosport.tvn24.pl/mog-a-by--rywalk---wi-tek--b-yskawicznie-odpad-a,1143359.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 15:30:00+00:00

<img alt="Mogła być rywalką Świątek, błyskawicznie odpadła" src="https://tvn24.pl/najnowsze/cdn-zdjecie-c39n30-maria-sakkari-6949820/alternates/LANDSCAPE_1280" />
    Niespodzianka w Stuttgarcie.

## Przeżyła getto jako kilkulatka. Roma Ligocka: Błagam, walczcie o zjednoczoną Europę. Głosujcie
 - [https://fakty.tvn24.pl/prze-y-a-getto-jako-kilkulatka--roma-ligocka--wybierajmy-liberalnych--m-drych--odpowiedzialnych-ludzi,1143373.html?source=rss](https://fakty.tvn24.pl/prze-y-a-getto-jako-kilkulatka--roma-ligocka--wybierajmy-liberalnych--m-drych--odpowiedzialnych-ludzi,1143373.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 15:29:21+00:00

<img alt="Przeżyła getto jako kilkulatka. Roma Ligocka: Błagam, walczcie o zjednoczoną Europę. Głosujcie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jfdup1-przezyla-getto-jako-kilkulatka-6950002/alternates/LANDSCAPE_1280" />
    19 kwietnia przypada 80. rocznica wybuchu powstania w getcie warszawskim. - Błagam was, walczcie o zjednoczoną Europę - mówi dziś Roma Ligocka, która przeżyła getto krakowskie jako kilkuletnia dziewczynka. Dziś ma poczucie, że nienawiść znowu rośnie w siłę. - Wybierajcie dobrych, mądrych ludzi, wybierajcie Europejczyków - dodała.

## Mają przechwycone komunikaty rosyjskich "statków widmo". Ostrzegają
 - [https://tvn24.pl/swiat/rosja-rosyjskie-statki-przygotowuja-sabotaz-sledztwo-nordyckich-mediow-6949654?source=rss](https://tvn24.pl/swiat/rosja-rosyjskie-statki-przygotowuja-sabotaz-sledztwo-nordyckich-mediow-6949654?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 15:20:33+00:00

<img alt="Mają przechwycone komunikaty rosyjskich " src="https://tvn24.pl/najnowsze/cdn-zdjecie-6mefky-admiral-wladimirski-6949696/alternates/LANDSCAPE_1280" />
    Rosjanie przygotowują możliwe działania sabotażowe na wodach wokół Danii, Szwecji, Norwegii oraz Finlandii - wynika ze śledztwa kilku telewizji.

## Świątek: nie mam zbyt wielkich oczekiwań
 - [https://eurosport.tvn24.pl/-wi-tek--nie-mam-zbyt-wielkich-oczekiwa-,1143354.html?source=rss](https://eurosport.tvn24.pl/-wi-tek--nie-mam-zbyt-wielkich-oczekiwa-,1143354.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 15:03:00+00:00

<img alt="Świątek: nie mam zbyt wielkich oczekiwań" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ccwsv1-swiatek-zaczyna-sezon-na-kortach-ziemnych-6949754/alternates/LANDSCAPE_1280" />
    W czwartek zagra pierwszy mecz po dłuższej przerwie.

## Pobili i skopali 17-latka, maczetą złamali mu rękę
 - [https://tvn24.pl/krakow/wieliczka-brutalne-pobicie-17-latka-z-uzyciem-maczety-areszt-dla-19-latka-trwaja-poszukiwania-pozostalych-sprawcow-6949596?source=rss](https://tvn24.pl/krakow/wieliczka-brutalne-pobicie-17-latka-z-uzyciem-maczety-areszt-dla-19-latka-trwaja-poszukiwania-pozostalych-sprawcow-6949596?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 14:57:38+00:00

<img alt="Pobili i skopali 17-latka, maczetą złamali mu rękę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pefq1j-policja-zdjecie-ilustracyjne-6856822/alternates/LANDSCAPE_1280" />
    Do aresztu trafił 19-latek. Trwają poszukiwania pozostałych napastników.

## Zaczął strzelać do grupy cheerleaderek
 - [https://tvn24.pl/swiat/teksas-przez-pomylke-wsiadla-do-cudzego-auta-padly-strzaly-2-osoby-ranne-6949378?source=rss](https://tvn24.pl/swiat/teksas-przez-pomylke-wsiadla-do-cudzego-auta-padly-strzaly-2-osoby-ranne-6949378?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 14:53:54+00:00

<img alt="Zaczął strzelać do grupy cheerleaderek" src="https://tvn24.pl/najnowsze/cdn-zdjecie-g10o4b-pedro-tello-rodriguez-jr-6949642/alternates/LANDSCAPE_1280" />
    Policja zatrzymała podejrzanego.

## "Uratujmy twarz panów Morawieckiego i Sasina". Jest projekt ustawy
 - [https://tvn24.pl/biznes/najnowsze/lpg-z-rosji-jest-projekt-w-sprawie-zakazu-importu-uratujmy-twarz-panow-morawieckiego-i-sasina-6949648?source=rss](https://tvn24.pl/biznes/najnowsze/lpg-z-rosji-jest-projekt-w-sprawie-zakazu-importu-uratujmy-twarz-panow-morawieckiego-i-sasina-6949648?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 14:45:50+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wl0lrc-pap_20221011_0zn-6949686/alternates/LANDSCAPE_1280" />
    Ma to być realizacja wcześniejszych zapowiedzi przedstawicieli rządu.

## Tajemnicza śmierć byłego gracza NFL. Miał 31 lat
 - [https://eurosport.tvn24.pl/tajemnicza--mier--by-ego-gracza-nfl--mia--31-lat,1143337.html?source=rss](https://eurosport.tvn24.pl/tajemnicza--mier--by-ego-gracza-nfl--mia--31-lat,1143337.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 14:38:00+00:00

<img alt="Tajemnicza śmierć byłego gracza NFL. Miał 31 lat" src="https://tvn24.pl/najnowsze/cdn-zdjecie-t72gmz-chris-smith-mial-31-lat-6949705/alternates/LANDSCAPE_1280" />
    Chris Smith nie żyje.

## Ukraina ma upragnioną broń. "Nasze piękne niebo staje się bezpieczniejsze"
 - [https://tvn24.pl/swiat/ukraina-systemy-patriot-przybyly-na-ukraine-6949395?source=rss](https://tvn24.pl/swiat/ukraina-systemy-patriot-przybyly-na-ukraine-6949395?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 14:18:45+00:00

<img alt="Ukraina ma upragnioną broń. " src="https://tvn24.pl/polska/cdn-zdjecie-9o8rtg-patrioty-6949145/alternates/LANDSCAPE_1280" />
    Na Ukrainę zostały dostarczone systemy przeciwrakietowe Patriot - potwierdził minister obrony tego kraju Ołeksij Reznikow.

## Czy będą masowe kontrole domów? Jest odpowiedź urzędu
 - [https://tvn24.pl/biznes/z-kraju/czy-beda-kontrole-w-domach-glowny-urzad-nadzoru-budowlanego-gunb-wyjasnia-6949636?source=rss](https://tvn24.pl/biznes/z-kraju/czy-beda-kontrole-w-domach-glowny-urzad-nadzoru-budowlanego-gunb-wyjasnia-6949636?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 14:17:12+00:00

<img alt="Czy będą masowe kontrole domów? Jest odpowiedź urzędu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-i08z98-jaczew-wies-budynki-miasteczko-domy-6112443/alternates/LANDSCAPE_1280" />
    Wyjaśnienia GUNB.

## Neymar podzielił się radosną nowiną. "Zostaniesz członkiem pięknej rodziny"
 - [https://eurosport.tvn24.pl/neymar-spodziewa-si--kolejnego-syna,1143348.html?source=rss](https://eurosport.tvn24.pl/neymar-spodziewa-si--kolejnego-syna,1143348.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 14:17:00+00:00

<img alt="Neymar podzielił się radosną nowiną. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-a76tl7-neymar-po-raz-drugi-zostanie-ojcem-6949671/alternates/LANDSCAPE_1280" />
    Słynny brazylijski piłkarz ma powody do radości.

## Odwiedziła w zeszłym tygodniu Pekin. Niektóre rzeczy były "więcej niż szokujące"
 - [https://tvn24.pl/swiat/niemcy-szefowa-msz-chiny-coraz-bardziej-staja-sie-systemowym-rywalem-6949578?source=rss](https://tvn24.pl/swiat/niemcy-szefowa-msz-chiny-coraz-bardziej-staja-sie-systemowym-rywalem-6949578?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 14:12:42+00:00

<img alt="Odwiedziła w zeszłym tygodniu Pekin. Niektóre rzeczy były " src="https://tvn24.pl/najnowsze/cdn-zdjecie-cczdxg-szefowa-msz-niemiec-6949594/alternates/LANDSCAPE_1280" />
    Opisała swoją niedawną wizytę w Chinach jako "więcej niż szokującą".

## Nie ustąpiła pierwszeństwa. Sześć osób rannych, wśród nich dziecko
 - [https://tvn24.pl/lodz/jastrzebie-gorne-nie-ustapila-pierwszenstwa-i-doprowadzila-do-zderzenia-szesc-osob-rannych-wsrod-nich-dziecko-6949579?source=rss](https://tvn24.pl/lodz/jastrzebie-gorne-nie-ustapila-pierwszenstwa-i-doprowadzila-do-zderzenia-szesc-osob-rannych-wsrod-nich-dziecko-6949579?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 13:58:19+00:00

<img alt="Nie ustąpiła pierwszeństwa. Sześć osób rannych, wśród nich dziecko" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qs732g-nie-ustapila-pierwszenstwa-i-doprowadzila-do-zderzenia-szesc-osob-rannych-wsrod-nich-dziecko-6949564/alternates/LANDSCAPE_1280" />
    Wypadek w miejscowości Jastrzębie Górne pod Zgierzem (woj. łódzkie).

## Krok w stronę męskiej antykoncepcji. Innowacyjna metoda
 - [https://tvn24.pl/ciekawostki/nauka-meska-antykoncepcja-naukowcy-opracowali-metode-oparta-o-gen-arrdc5-6949218?source=rss](https://tvn24.pl/ciekawostki/nauka-meska-antykoncepcja-naukowcy-opracowali-metode-oparta-o-gen-arrdc5-6949218?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 13:43:46+00:00

<img alt="Krok w stronę męskiej antykoncepcji. Innowacyjna metoda" src="https://tvn24.pl/najnowsze/cdn-zdjecie-y7klbj-naukowcy-sa-coraz-blizej-opracowania-antykoncepcji-dla-mezczyzn-6949209/alternates/LANDSCAPE_1280" />
    Nie wymagałaby ingerencji hormonalnej.

## Świętował jej zwycięstwo. Sabalenka komentuje słowa Łukaszenki
 - [https://eurosport.tvn24.pl/-ukaszenka--wi-towa--jej-zwyci-stwo--sabalenka-komentuje-jego-s-owa,1143347.html?source=rss](https://eurosport.tvn24.pl/-ukaszenka--wi-towa--jej-zwyci-stwo--sabalenka-komentuje-jego-s-owa,1143347.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 13:40:00+00:00

<img alt="Świętował jej zwycięstwo. Sabalenka komentuje słowa Łukaszenki" src="https://tvn24.pl/najnowsze/cdn-zdjecie-s9tsac-aryna-sabalenka-6949600/alternates/LANDSCAPE_1280" />
    Białorusinka to druga rakieta świata.

## Laptopy dla czwartoklasistów. Minister wskazał "najkorzystniejszą ofertę"
 - [https://tvn24.pl/biznes/z-kraju/laptopy-dla-czwartoklasistow-minister-cyfryzacji-janusz-cieszynski-o-najkorzystniejszej-ofercie-6949458?source=rss](https://tvn24.pl/biznes/z-kraju/laptopy-dla-czwartoklasistow-minister-cyfryzacji-janusz-cieszynski-o-najkorzystniejszej-ofercie-6949458?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 13:35:12+00:00

<img alt="Laptopy dla czwartoklasistów. Minister wskazał " src="https://tvn24.pl/najnowsze/cdn-zdjecie-rc5q2j-shutterstock_695764720-6949585/alternates/LANDSCAPE_1280" />
    Wpis na Twitterze.

## "Wybrali sobie drogę do śmierci"
 - [https://tvn24.pl/go/programy,7/czarno-na-bialym-odcinki,11367/odcinek-2397,S00E2397,1046698?source=rss](https://tvn24.pl/go/programy,7/czarno-na-bialym-odcinki,11367/odcinek-2397,S00E2397,1046698?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 13:31:54+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9ohyh6-mapa-warszawskiego-getta-6949581/alternates/LANDSCAPE_1280" />
    Materiał Artura Warcholińskiego o historii powstania w największym getcie żydowskim w dziejach.

## Nie żyje aktor Roman Garbowski
 - [https://tvn24.pl/kultura-i-styl/roman-garbowski-nie-zyje-aktor-wystapil-min-w-pianiscie-polanskiego-mial-87-lat-6949511?source=rss](https://tvn24.pl/kultura-i-styl/roman-garbowski-nie-zyje-aktor-wystapil-min-w-pianiscie-polanskiego-mial-87-lat-6949511?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 13:17:31+00:00

<img alt="Nie żyje aktor Roman Garbowski" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5cdli1-roman-garbowski-6949515/alternates/LANDSCAPE_1280" />
    Grał w "Pianiście" i popularnych serialach.

## Jedyne takie maszyny na świecie. Unikalny V-22 Osprey nad Warszawą
 - [https://tvn24.pl/polska/warszawa-v-22-osprey-widziany-podczas-cwiczen-jedyne-takie-maszyny-na-swiecie-6949189?source=rss](https://tvn24.pl/polska/warszawa-v-22-osprey-widziany-podczas-cwiczen-jedyne-takie-maszyny-na-swiecie-6949189?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 13:11:24+00:00

<img alt="Jedyne takie maszyny na świecie. Unikalny V-22 Osprey nad Warszawą" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ede0l4-v22-osprey-5641151/alternates/LANDSCAPE_1280" />
    Niezwykłe maszyny widziane były nad kilkoma dzielnicami miasta.

## Siedmiolatka spadła z wyciągu, policja szuka świadków
 - [https://tvn24.pl/krakow/bukowina-tatrzanska-wypadek-na-stoku-narciarskim-siedmiolatka-spadla-z-wyciagu-policja-szuka-swiadkow-6949287?source=rss](https://tvn24.pl/krakow/bukowina-tatrzanska-wypadek-na-stoku-narciarskim-siedmiolatka-spadla-z-wyciagu-policja-szuka-swiadkow-6949287?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 13:09:51+00:00

<img alt="Siedmiolatka spadła z wyciągu, policja szuka świadków" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7s54du-policja-szuka-swiadkow-wypadku-na-stacji-narciarskiej-6949263/alternates/LANDSCAPE_1280" />
    Dziewczynka wypadła z krzesełka kolejki.

## W tym polskim mieście szczury panoszą się w samym centrum. Sąd ma dużo do powiedzenia
 - [https://tvn24.pl/krakow/rzeszow-miasto-walczy-z-plaga-szczurow-i-prosi-o-pomoc-sad-6949335?source=rss](https://tvn24.pl/krakow/rzeszow-miasto-walczy-z-plaga-szczurow-i-prosi-o-pomoc-sad-6949335?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 13:03:12+00:00

<img alt="W tym polskim mieście szczury panoszą się w samym centrum. Sąd ma dużo do powiedzenia" src="https://tvn24.pl/najnowsze/cdn-zdjecie-v01qsp-rzeszow-zamek-shutterstock_2275562639-6949254/alternates/LANDSCAPE_1280" />
    Ratusz prosi o pomoc.

## Pomylił przejścia graniczne. Stracił samochód za 900 tysięcy złotych
 - [https://tvn24.pl/pomorze/gronowo-pomylil-przejscia-graniczne-obywatel-niemiec-stracil-samochod-za-900-tysiecy-zlotych-6948563?source=rss](https://tvn24.pl/pomorze/gronowo-pomylil-przejscia-graniczne-obywatel-niemiec-stracil-samochod-za-900-tysiecy-zlotych-6948563?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 12:50:00+00:00

<img alt="Pomylił przejścia graniczne. Stracił samochód za 900 tysięcy złotych" src="https://tvn24.pl/pomorze/cdn-zdjecie-wj0glt-skontrolowany-kamper-okazal-sie-kradziony-6948607/alternates/LANDSCAPE_1280" />
    43-letni Niemiec zamiast do Rosji pojechał do komisariatu policji.

## Piruety na drodze dojazdowej do autostrady. Jest nagranie
 - [https://tvn24.pl/katowice/katowice-piruety-na-drodze-dojazdowej-do-autostrady-a4-kierowcy-grozi-wysoki-mandat-nagranie-6949444?source=rss](https://tvn24.pl/katowice/katowice-piruety-na-drodze-dojazdowej-do-autostrady-a4-kierowcy-grozi-wysoki-mandat-nagranie-6949444?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 12:47:41+00:00

<img alt="Piruety na drodze dojazdowej do autostrady. Jest nagranie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-d68gpu-piruety-bmw-na-drodze-dojazdowej-do-autostrady-a1-6949457/alternates/LANDSCAPE_1280" />
    Kierowcy grozi wysoki mandat.

## Trzaskowski: podwórko domu, w którym się wychowałem, było przedzielone murem getta
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-obchody-wybuchu-powstania-w-getcie-warszawskim-przemowienie-rafala-trzaskowskiego-6949332?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-obchody-wybuchu-powstania-w-getcie-warszawskim-przemowienie-rafala-trzaskowskiego-6949332?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 12:35:21+00:00

<img alt="Trzaskowski: podwórko domu, w którym się wychowałem, było przedzielone murem getta" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-ah4da5-rafal-trzaskowski-podczas-uroczystosci-z-okazji-80-rocznicy-wybuchu-powstania-w-getcie-warszawskim-6949399/alternates/LANDSCAPE_1280" />
    Przemówienie prezydenta Warszawy.

## Sąd nakazał przywrócenie sędziego Waldemara Żurka półtora miesiąca temu. Jak jest?
 - [https://tvn24.pl/krakow/sedzia-waldemar-zurek-mial-wrocic-do-dawnego-wydzialu-w-sadzie-okregowym-w-krakowie-ciagle-do-tego-nie-doszlo-6948853?source=rss](https://tvn24.pl/krakow/sedzia-waldemar-zurek-mial-wrocic-do-dawnego-wydzialu-w-sadzie-okregowym-w-krakowie-ciagle-do-tego-nie-doszlo-6948853?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 12:27:26+00:00

<img alt="Sąd nakazał przywrócenie sędziego Waldemara Żurka półtora miesiąca temu. Jak jest?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-dfmsc7-waldemar-zurek-6822695/alternates/LANDSCAPE_1280" />
    "W Polsce funkcjonują rozwiązania, które pozwalają na szykanowanie osób".

## Steinmeier: Ciężko przyjść tu jako Niemiec. Proszę o przebaczenie
 - [https://tvn24.pl/polska/prezydent-niemiec-frank-walter-steinmeier-w-80-rocznice-powstania-w-getcie-warszawskim-6949308?source=rss](https://tvn24.pl/polska/prezydent-niemiec-frank-walter-steinmeier-w-80-rocznice-powstania-w-getcie-warszawskim-6949308?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 12:01:43+00:00

<img alt="Steinmeier: Ciężko przyjść tu jako Niemiec. Proszę o przebaczenie " src="https://tvn24.pl/najnowsze/cdn-zdjecie-v6tg3i-frank-walter-steinmeier-6949228/alternates/LANDSCAPE_1280" />
    Prezydent Niemiec w Warszawie.

## Niewiadoma walczyła jak lwica, ale to nie ona się cieszy
 - [https://eurosport.tvn24.pl/niewiadoma-walczy-a-jak-lwica--ale-to-nie-ona-si--cieszy--walo-ska-strza-a-dla-vollering,1143341.html?source=rss](https://eurosport.tvn24.pl/niewiadoma-walczy-a-jak-lwica--ale-to-nie-ona-si--cieszy--walo-ska-strza-a-dla-vollering,1143341.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 11:57:00+00:00

<img alt="Niewiadoma walczyła jak lwica, ale to nie ona się cieszy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-u9s0o5-demi-vollering-wygrala-walonska-strzale-6949355/alternates/LANDSCAPE_1280" />
    Walońska Strzała dla Vollering.

## Prezydent Izraela: duch ludzki zwyciężył tutaj, na tej ziemi uświęconej krwią
 - [https://tvn24.pl/polska/80-rocznica-powstania-w-getcie-warszawskim-przemowienie-prezydenta-izraela-izaaka-herzoga-6949297?source=rss](https://tvn24.pl/polska/80-rocznica-powstania-w-getcie-warszawskim-przemowienie-prezydenta-izraela-izaaka-herzoga-6949297?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 11:56:05+00:00

<img alt="Prezydent Izraela: duch ludzki zwyciężył tutaj, na tej ziemi uświęconej krwią " src="https://tvn24.pl/najnowsze/cdn-zdjecie-enqc2e-19-1225-polin-tvp-pl-0040-6949227/alternates/LANDSCAPE_1280" />
    Obchody 80. rocznicy powstania w getcie warszawskim.

## Ciężarówka zawisła na krawędzi wiaduktu pięć pięter nad ziemią. Kierowca mówi o cudzie
 - [https://tvn24.pl/swiat/usa-wypadek-ciezarowki-dachowala-i-zwisala-z-wiaduktu-kierowca-przezyl-6949105?source=rss](https://tvn24.pl/swiat/usa-wypadek-ciezarowki-dachowala-i-zwisala-z-wiaduktu-kierowca-przezyl-6949105?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 11:53:50+00:00

<img alt="Ciężarówka zawisła na krawędzi wiaduktu pięć pięter nad ziemią. Kierowca mówi o cudzie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-82y3fq-wypadek-ciezarowki-w-pensylwanii-6949199/alternates/LANDSCAPE_1280" />
    "Jestem wdzięczny, że żyję".

## 16-latka wsiadła z nieznajomym do samochodu i pojechała do Niemiec
 - [https://tvn24.pl/krakow/zabno-nastolatka-uciekla-z-domu-pojechala-do-niemiec-kierowca-sie-dowiedzial-i-odwiozl-ja-do-niemieckich-policjantow-6948656?source=rss](https://tvn24.pl/krakow/zabno-nastolatka-uciekla-z-domu-pojechala-do-niemiec-kierowca-sie-dowiedzial-i-odwiozl-ja-do-niemieckich-policjantow-6948656?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 11:36:44+00:00

<img alt="16-latka wsiadła z nieznajomym do samochodu i pojechała do Niemiec" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xgv88p-niemiecka-policja-6949259/alternates/LANDSCAPE_1280" />
    Na przejazd umówili się poprzez aplikację.

## Miały być sposobem na ukraińskie zboże. Obietnica wraca jak bumerang
 - [https://tvn24.pl/biznes/najnowsze/plomby-na-transporcie-ukrainskiego-zboza-obiecywal-juz-minister-kowalczyk-3-marca-2023-r-6948910?source=rss](https://tvn24.pl/biznes/najnowsze/plomby-na-transporcie-ukrainskiego-zboza-obiecywal-juz-minister-kowalczyk-3-marca-2023-r-6948910?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 11:34:42+00:00

<img alt="Miały być sposobem na ukraińskie zboże. Obietnica wraca jak bumerang" src="https://tvn24.pl/najnowsze/cdn-zdjecie-axmd4f-robert-telus-mateusz-morawiecki-henryk-kowalczyk-6928745/alternates/LANDSCAPE_1280" />
    Nowy minister, stare zapowiedzi.

## Asteroida większa od wieży Eiffla zbliża się do Ziemi
 - [https://tvn24.pl/tvnmeteo/najnowsze/asteroida-2006-hv5-zbliza-sie-do-ziemi-jest-wieksza-od-wiezy-eiffla-6949140?source=rss](https://tvn24.pl/tvnmeteo/najnowsze/asteroida-2006-hv5-zbliza-sie-do-ziemi-jest-wieksza-od-wiezy-eiffla-6949140?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 11:30:02+00:00

<img alt="Asteroida większa od wieży Eiffla zbliża się do Ziemi " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-wok45e-asteroida-5633987/alternates/LANDSCAPE_1280" />
    2006 HV5 to obiekt zaliczany do potencjalnie niebezpiecznych.

## Przyznali, że zamordowali nauczycielkę z powodu złych ocen
 - [https://tvn24.pl/swiat/usa-willard-miller-i-jeremy-goodale-przyznali-ze-zamordowali-nauczycielke-z-powodu-zlych-ocen-6949147?source=rss](https://tvn24.pl/swiat/usa-willard-miller-i-jeremy-goodale-przyznali-ze-zamordowali-nauczycielke-z-powodu-zlych-ocen-6949147?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 11:28:34+00:00

<img alt="Przyznali, że zamordowali nauczycielkę z powodu złych ocen" src="https://tvn24.pl/najnowsze/cdn-zdjecie-valn8w-willard-miller-i-jeremy-goodale-przyznali-sie-do-zamordowania-nohemy-graber-6949022/alternates/LANDSCAPE_1280" />
    Nastolatkom grozi dożywocie.

## Włoski sędzia zszokowany błędem, ale nie wini tylko Marciniaka
 - [https://eurosport.tvn24.pl/w-oski-s-dzia-zszokowany-b--dem--ale-nie-wini-tylko-marciniaka---nie-wiem--co-tam-si--sta-o-,1143338.html?source=rss](https://eurosport.tvn24.pl/w-oski-s-dzia-zszokowany-b--dem--ale-nie-wini-tylko-marciniaka---nie-wiem--co-tam-si--sta-o-,1143338.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 11:27:00+00:00

<img alt="Włoski sędzia zszokowany błędem, ale nie wini tylko Marciniaka" src="https://tvn24.pl/najnowsze/cdn-zdjecie-p0yi4-marciniak-6949268/alternates/LANDSCAPE_1280" />
    "Nie wiem, co tam się stało".

## Prezydent: każdy, kto sieje nienawiść, depcze po grobach bohaterów powstania w getcie
 - [https://tvn24.pl/polska/80-rocznica-powstania-w-getcie-warszawskim-przemowienie-prezydenta-andrzeja-dudy-6949096?source=rss](https://tvn24.pl/polska/80-rocznica-powstania-w-getcie-warszawskim-przemowienie-prezydenta-andrzeja-dudy-6949096?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 11:16:35+00:00

<img alt="Prezydent: każdy, kto sieje nienawiść, depcze po grobach bohaterów powstania w getcie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-uwdle7-andrzej-duda-6949112/alternates/LANDSCAPE_1280" />
    Wystąpienie Andrzeja Dudy w czasie obchodów 80. rocznicy powstania w getcie warszawskim.

## Zagrożone głosy Polaków za granicą. "Są dwa możliwe rozwiązania"
 - [https://tvn24.pl/swiat/kodeks-wyborczy-ograniczenie-czasowe-liczenia-glosow-za-granica-i-na-statkach-maciej-woroch-o-obawach-polakow-w-wielkiej-brytanii-6948980?source=rss](https://tvn24.pl/swiat/kodeks-wyborczy-ograniczenie-czasowe-liczenia-glosow-za-granica-i-na-statkach-maciej-woroch-o-obawach-polakow-w-wielkiej-brytanii-6948980?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 11:13:36+00:00

<img alt="Zagrożone głosy Polaków za granicą. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-q0j0z9-urna-wybory-shutterstock_1490322299-6549711/alternates/LANDSCAPE_1280" />
    Małgorzata Hallewell z organizacji "Polonia głosuje" w rozmowie z korespondentem "Faktów" TVN Maciejem Worochem.

## Kolejny kraj wprowadza zakaz importu ukraińskiego zboża
 - [https://tvn24.pl/biznes/ze-swiata/zboza-z-ukrainy-bulgaria-wprowadzila-zakaz-importu-ukrainskiego-zboza-nowe-przepisy-na-wegrzech-6949117?source=rss](https://tvn24.pl/biznes/ze-swiata/zboza-z-ukrainy-bulgaria-wprowadzila-zakaz-importu-ukrainskiego-zboza-nowe-przepisy-na-wegrzech-6949117?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 11:13:00+00:00

<img alt="Kolejny kraj wprowadza zakaz importu ukraińskiego zboża" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hen7jc-ukraina-to-jeden-z-najwiekszych-swiatowych-eksporterow-zboza-5731508/alternates/LANDSCAPE_1280" />
    Wypowiedź tymczasowego premiera.

## "Mam obowiązek powtórzyć wezwanie: Ludzie, nie bądźcie obojętni na zło. Ludzie, bądźcie czujni"
 - [https://tvn24.pl/polska/marian-turski-mam-obowiazek-powtorzyc-wezwanie-ludzie-nie-badzcie-obojetni-na-zlo-6949063?source=rss](https://tvn24.pl/polska/marian-turski-mam-obowiazek-powtorzyc-wezwanie-ludzie-nie-badzcie-obojetni-na-zlo-6949063?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 10:56:59+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-s75en8-marian-turski-6949059/alternates/LANDSCAPE_1280" />
    Marian Turski, były więzień Auschwitz i historyk przemawiał na oficjalnych obchodach 80. rocznicy powstania w getcie warszawskim.

## Biegła w ultramaratonie, podjechała samochodem. Znana zawodniczka przyłapana na oszustwie
 - [https://eurosport.tvn24.pl/bieg-a-w-ultramaratonie--podjecha-a-samochodem--znana-zawodniczka-przy-apana-na-oszustwie,1143340.html?source=rss](https://eurosport.tvn24.pl/bieg-a-w-ultramaratonie--podjecha-a-samochodem--znana-zawodniczka-przy-apana-na-oszustwie,1143340.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 10:45:00+00:00

<img alt="Biegła w ultramaratonie, podjechała samochodem. Znana zawodniczka przyłapana na oszustwie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6yhcdz-joasia-zakrzewski-6949138/alternates/LANDSCAPE_1280" />
    W tym przypadku jak ulał pasuje powiedzenie, że kłamstwo ma krótkie nogi.

## Chłopczyk "wcisnął się" na teren Białego Domu
 - [https://tvn24.pl/swiat/usa-dziecko-dostalo-sie-na-teren-bialego-domu-interweniowalo-secret-service-6948731?source=rss](https://tvn24.pl/swiat/usa-dziecko-dostalo-sie-na-teren-bialego-domu-interweniowalo-secret-service-6948731?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 10:44:00+00:00

<img alt="Chłopczyk " src="https://tvn24.pl/najnowsze/cdn-zdjecie-7u86zg-umundurowany-funkcjonariusz-secret-service-z-dzieckiem-ktore-wtargnelo-na-teren-bialego-domu-6948781/alternates/LANDSCAPE_1280" />
    Natychmiastowa interwencja Secret Service.

## W Hrubieszowie wciąż protestują. Rolników nie przekonują propozycje rządu
 - [https://tvn24.pl/bialystok/hrubieszow-protest-trwa-rolnikow-nie-przekonuja-propozycje-rzadu-6948947?source=rss](https://tvn24.pl/bialystok/hrubieszow-protest-trwa-rolnikow-nie-przekonuja-propozycje-rzadu-6948947?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 10:43:31+00:00

<img alt="W Hrubieszowie wciąż protestują. Rolników nie przekonują propozycje rządu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pya7cp-w-hrubieszowie-juz-od-tygodnia-trwa-protest-rolnikow-6948954/alternates/LANDSCAPE_1280" />
    Mają postulaty.

## Trzej prezydenci pokłonili się przed Pomnikiem Bohaterów Getta
 - [https://tvn24.pl/polska/80-rocznica-powstania-w-getcie-warszawskimprezydenci-polski-niemiec-i-izraela-andrzej-duda-frank-walter-steinmeier-i-izaak-herzog-poklonili-sie-przed-pomnikiem-bohaterow-getta-w-warszawie-6948735?source=rss](https://tvn24.pl/polska/80-rocznica-powstania-w-getcie-warszawskimprezydenci-polski-niemiec-i-izraela-andrzej-duda-frank-walter-steinmeier-i-izaak-herzog-poklonili-sie-przed-pomnikiem-bohaterow-getta-w-warszawie-6948735?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 10:39:47+00:00

<img alt="Trzej prezydenci pokłonili się przed Pomnikiem Bohaterów Getta " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ak92p-prezydenci-polski-niemiec-i-izraela-poklonili-sie-przed-pomnikiem-bohaterow-getta-w-warszawie-6949033/alternates/LANDSCAPE_1280" />
    W czasie centralnych obchodów 80. rocznicy powstania w getcie warszawskim.

## Szefowa KE odpowiedziała na list pięciu krajów, w tym Polski. Padły trzy propozycje
 - [https://tvn24.pl/biznes/ze-swiata/produkty-rolne-z-ukrainy-szefowa-komisji-europejskiej-ursula-von-der-leyen-odpowiedziala-na-list-pieciu-krajow-w-tym-polski-6949055?source=rss](https://tvn24.pl/biznes/ze-swiata/produkty-rolne-z-ukrainy-szefowa-komisji-europejskiej-ursula-von-der-leyen-odpowiedziala-na-list-pieciu-krajow-w-tym-polski-6949055?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 10:37:49+00:00

<img alt="Szefowa KE odpowiedziała na list pięciu krajów, w tym Polski. Padły trzy propozycje" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-erjvob-von-der-leyen-6949093/alternates/LANDSCAPE_1280" />
    Lista w sprawie importu produktów rolnych z Ukrainy.

## To nie były słodycze. Siedmiolatkowie w szpitalu
 - [https://tvn24.pl/swiat/usa-dzieci-zazyly-metamfetamine-myslaly-ze-to-cukierki-trafily-do-szpitala-6948807?source=rss](https://tvn24.pl/swiat/usa-dzieci-zazyly-metamfetamine-myslaly-ze-to-cukierki-trafily-do-szpitala-6948807?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 10:35:18+00:00

<img alt="To nie były słodycze. Siedmiolatkowie w szpitalu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-v069df-college-gardens-elementary-school-w-rockville-6948885/alternates/LANDSCAPE_1280" />
    Dzieci zażyły metamfetaminę.

## Kamil nadal w ciężkim stanie. Cztery osoby odpowiedzą za jego cierpienie
 - [https://tvn24.pl/katowice/czestochowa-kamil-nadal-w-ciezkim-stanie-zarzuty-dla-wujka-chlopca-mieszkal-w-tym-samym-domu-6948936?source=rss](https://tvn24.pl/katowice/czestochowa-kamil-nadal-w-ciezkim-stanie-zarzuty-dla-wujka-chlopca-mieszkal-w-tym-samym-domu-6948936?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 10:32:45+00:00

<img alt="Kamil nadal w ciężkim stanie. Cztery osoby odpowiedzą za jego cierpienie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mog6bw-maltretowany-osmiolatek-mieszkal-w-czestochowie-6891279/alternates/LANDSCAPE_1280" />
    Kolejna osoba z zarzutami po tym, jak ośmiolatek z Częstochowy trafił do szpitala.

## Chiny nie będą już najludniejszym krajem świata. Niebawem wyprzedzi je sąsiednie państwo
 - [https://tvn24.pl/swiat/demografia-indie-zostana-najludniejszym-krajem-swiata-wyprzedza-chiny-6948898?source=rss](https://tvn24.pl/swiat/demografia-indie-zostana-najludniejszym-krajem-swiata-wyprzedza-chiny-6948898?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 10:24:25+00:00

<img alt="Chiny nie będą już najludniejszym krajem świata. Niebawem wyprzedzi je sąsiednie państwo " src="https://tvn24.pl/najnowsze/cdn-zdjecie-d7aowt-indie-zostana-najludniejszym-panstwem-swiata-6948787/alternates/LANDSCAPE_1280" />
    "To okazja do świętowania naszej różnorodności".

## "Prosimy Cię, Boże, o walkę krwawą…"
 - [https://tvn24.pl/tvnwarszawa/najnowsze/80-rocznica-powstanie-w-getcie-warszawskim-wystawa-ipn-prosimy-cie-boze-o-walke-krwawa-6949023?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/80-rocznica-powstanie-w-getcie-warszawskim-wystawa-ipn-prosimy-cie-boze-o-walke-krwawa-6949023?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 10:20:06+00:00

<img alt="" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-ohq83v-otwarcie-wystawy-plenerowej-ipn-%E2%80%9Eprosimy-cie-boze-o-walke-krwawa-na-skwerze-hoovera-w-warszawie-6948964/alternates/LANDSCAPE_1280" />
    Wystawa IPN na stołecznym skwerze Hoovera.

## Spłonęło miejskie archiwum i kilometry akt. Prokuratura o siódmej podejrzanej osobie
 - [https://tvn24.pl/krakow/krakow-pozar-miejskiego-archiwum-siodma-osoba-z-zarzutami-to-kierownik-robot-elektrycznych-6948925?source=rss](https://tvn24.pl/krakow/krakow-pozar-miejskiego-archiwum-siodma-osoba-z-zarzutami-to-kierownik-robot-elektrycznych-6948925?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 10:15:13+00:00

<img alt="Spłonęło miejskie archiwum i kilometry akt. Prokuratura o siódmej podejrzanej osobie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-j2azpj-pozar-archiwum-w-krakowie-zdjecie-z-lutego-2021-roku-6720055/alternates/LANDSCAPE_1280" />
    Do pożaru doszło w lutym 2021 roku.

## Czołowe zderzenie na drodze krajowej. Dwie osoby zginęły na miejscu
 - [https://tvn24.pl/wroclaw/sidzina-wypadek-smiertelny-czolowe-zderzenie-na-drodze-krajowej-46-dwie-osoby-zginely-na-miejscu-6948962?source=rss](https://tvn24.pl/wroclaw/sidzina-wypadek-smiertelny-czolowe-zderzenie-na-drodze-krajowej-46-dwie-osoby-zginely-na-miejscu-6948962?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 10:14:26+00:00

<img alt="Czołowe zderzenie na drodze krajowej. Dwie osoby zginęły na miejscu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xvckte-smiertelny-wypadek-na-dk-46-6948914/alternates/LANDSCAPE_1280" />
    Jedna została przetransportowana do szpitala

## Uznany trener na ratunek polskich skoków
 - [https://eurosport.tvn24.pl/uznany-trener-na-ratunek-polskich-skok-w---rozmowy-trwaj--,1143237.html?source=rss](https://eurosport.tvn24.pl/uznany-trener-na-ratunek-polskich-skok-w---rozmowy-trwaj--,1143237.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 10:00:00+00:00

<img alt="Uznany trener na ratunek polskich skoków" src="https://tvn24.pl/najnowsze/cdn-zdjecie-73qruo-harald-rodlauer-6948981/alternates/LANDSCAPE_1280" />
    Austriak ostatnio odnosił spore sukcesy w ojczyźnie.

## "Kogo pani tam ma? Wszystkich. Wszyscy, którzy tam są, są moi"
 - [https://tvn24.pl/premium/kogo-pani-tam-ma-wszystkich-wszyscy-ktorzy-tam-sa-sa-moi-6948453?source=rss](https://tvn24.pl/premium/kogo-pani-tam-ma-wszystkich-wszyscy-ktorzy-tam-sa-sa-moi-6948453?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 09:58:51+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ixkybz-rudolf-damec-widok-na-mur-getta-u-zbiegu-ul-swietojerskiej-i-bonifraterskiej-oraz-pl-krasinskich-za-murem-budynki-szopu-szczotkarzy-kwiecien-%E2%80%93-maj-1943-r-_q5a9693_kb-1-6894850/alternates/LANDSCAPE_1280" />
    Znamienne jest to, w jaki sposób historia ludności cywilnej i bojowców łączy się. Kiedy powstanie dobiegło końca, jego uczestnicy dzielą los z cywilami. Poza niewielką grupą, która przedostaje się poza mury getta. Ci, którzy przeżyli, są wywiezieni do Treblinki i obozów na Lubelszczyźnie. Bojowcy mieli niewiele broni, granica pomiędzy powstańcami i cywilami szybko się zatarła - mówi dr Katarzyna Person z Żydowskiego Instytutu Historycznego.

## Obietnice minus. Bonu na kulturę dla młodzieży nie ma i raczej już nie będzie
 - [https://konkret24.tvn24.pl/obietnice-minus/obietnice-minus-bonu-na-kulture-dla-mlodziezy-nie-ma-i-raczej-juz-nie-bedzie-6948706?source=rss](https://konkret24.tvn24.pl/obietnice-minus/obietnice-minus-bonu-na-kulture-dla-mlodziezy-nie-ma-i-raczej-juz-nie-bedzie-6948706?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 09:54:09+00:00

<img alt="Obietnice minus. Bonu na kulturę dla młodzieży nie ma i raczej już nie będzie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3vpyq3-bonu-na-kulture-dla-mlodziezy-nie-ma-i-raczej-juz-nie-bedzie-6930536/alternates/LANDSCAPE_1280" />
    Beata Szydło i Jarosław Kaczyński obiecali, że PiS wprowadzi bon 500 zł na sport i kulturę dla młodzieży. Pięć lat później bonu wciąż nie ma.

## Wielkie gwiazdy na koncercie z okazji koronacji Karola III. Podano pierwsze nazwiska
 - [https://tvn24.pl/kultura-i-styl/koronacja-karola-iii-wiadomo-kto-wystapi-na-koncercie-koronacyjnym-6938552?source=rss](https://tvn24.pl/kultura-i-styl/koronacja-karola-iii-wiadomo-kto-wystapi-na-koncercie-koronacyjnym-6938552?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 09:46:26+00:00

<img alt="Wielkie gwiazdy na koncercie z okazji koronacji Karola III. Podano pierwsze nazwiska" src="https://tvn24.pl/najnowsze/cdn-zdjecie-h3duop-katy-perry-6948903/alternates/LANDSCAPE_1280" />
    Wydarzenie odbędzie się 7 maja.

## Jeden dzień urlopu, pięć dni wolnego
 - [https://tvn24.pl/biznes/dla-pracownika/majowka-2023-jeden-dzien-urlopu-piec-dni-wolnego-6948694?source=rss](https://tvn24.pl/biznes/dla-pracownika/majowka-2023-jeden-dzien-urlopu-piec-dni-wolnego-6948694?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 09:34:46+00:00

<img alt="Jeden dzień urlopu, pięć dni wolnego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-zdmaoe-praca-biuro-shutterstock_321793040-4672779/alternates/LANDSCAPE_1280" />
    Już niedługo.

## Piłkarz Bayernu uderzył kolegę z zespołu. Rekordowa kara
 - [https://eurosport.tvn24.pl/pi-karz-bayernu-uderzy--koleg--z-zespo-u--dosta--rekordow--kar-,1143330.html?source=rss](https://eurosport.tvn24.pl/pi-karz-bayernu-uderzy--koleg--z-zespo-u--dosta--rekordow--kar-,1143330.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 09:31:00+00:00

<img alt="Piłkarz Bayernu uderzył kolegę z zespołu. Rekordowa kara" src="https://tvn24.pl/najnowsze/cdn-zdjecie-g7dfue-sadio-mane-6948901/alternates/LANDSCAPE_1280" />
    Sadio Mane będzie musiał sięgnąć głęboko do kieszeni.

## "Ufam, że pomożecie rzucić dalsze światło na plagę nadużyć, aby wykorzenić to głębokie zło"
 - [https://tvn24.pl/swiat/papiez-franciszek-do-dziennikarzy-ufam-ze-pomozecie-rzucic-dalsze-swiatlo-na-plage-naduzyc-aby-wykorzenic-to-glebokie-zlo-6948652?source=rss](https://tvn24.pl/swiat/papiez-franciszek-do-dziennikarzy-ufam-ze-pomozecie-rzucic-dalsze-swiatlo-na-plage-naduzyc-aby-wykorzenic-to-glebokie-zlo-6948652?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 09:29:29+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mvsz7q-papiez-franciszek-6948744/alternates/LANDSCAPE_1280" />
    Przesłanie papieża Franciszka do dziennikarzy.

## Widmo paraliżu na niemieckiej kolei
 - [https://tvn24.pl/biznes/turystyka/niemcy-evg-zapowiada-ogolnokrajowy-strajk-na-kolei-21-kwietnia-deutsche-bahn-komentuje-6948760?source=rss](https://tvn24.pl/biznes/turystyka/niemcy-evg-zapowiada-ogolnokrajowy-strajk-na-kolei-21-kwietnia-deutsche-bahn-komentuje-6948760?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 09:29:00+00:00

<img alt="Widmo paraliżu na niemieckiej kolei" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7sfw1j-niemcy-kolej-shutterstock_1327531277-6948856/alternates/LANDSCAPE_1280" />
    Utrudnienia mogą też dotknąć pasażerów trzech niemieckich lotnisk.

## Awantura podczas rodzinnego spotkania. Wstrzymano ruch tramwajowy
 - [https://tvn24.pl/poznan/poznan-podgorna-awantura-podczas-rodzinnego-spotkania-dwie-osoby-trafily-do-szpitala-wstrzymano-ruch-tramwajowy-6948838?source=rss](https://tvn24.pl/poznan/poznan-podgorna-awantura-podczas-rodzinnego-spotkania-dwie-osoby-trafily-do-szpitala-wstrzymano-ruch-tramwajowy-6948838?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 09:25:16+00:00

<img alt="Awantura podczas rodzinnego spotkania. Wstrzymano ruch tramwajowy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5660v3-sprawa-zajmuje-sie-policja-zdjecie-ilustracyjne-6894839/alternates/LANDSCAPE_1280" />
    Dwie osoby trafiły do szpitala.

## Padła ofiarą oszustwa. Dowiedziała się o tym dzięki fanom
 - [https://tvn24.pl/kultura-i-styl/malgorzata-rozenek-majdan-padla-ofiara-oszustwa-dowiedziala-sie-o-tym-dzieki-fanom-6948676?source=rss](https://tvn24.pl/kultura-i-styl/malgorzata-rozenek-majdan-padla-ofiara-oszustwa-dowiedziala-sie-o-tym-dzieki-fanom-6948676?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 09:09:43+00:00

<img alt="Padła ofiarą oszustwa. Dowiedziała się o tym dzięki fanom" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3y7duo-malgorzata-rozenek-majdan-wydala-oswiadczenie-6948722/alternates/LANDSCAPE_1280" />
    Ktoś wykorzystał jej wizerunek, by reklamować w sieci szczególną aplikację.

## Sensacyjne rozstanie. Raków pędzi po mistrzostwo, żegna się z trenerem
 - [https://eurosport.tvn24.pl/sensacyjne-rozstanie--rak-w-p-dzi-po-mistrzostwo---egna-si--z-trenerem,1143334.html?source=rss](https://eurosport.tvn24.pl/sensacyjne-rozstanie--rak-w-p-dzi-po-mistrzostwo---egna-si--z-trenerem,1143334.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 09:09:00+00:00

<img alt="Sensacyjne rozstanie. Raków pędzi po mistrzostwo, żegna się z trenerem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-nznody-marek-papszun-odchodzi-z-rakowa-6948844/alternates/LANDSCAPE_1280" />
    Marek Papszun po sezonie przestanie być trenerem Rakowa Częstochowa.

## Strzelał do nastolatka, który zapukał do jego drzwi. 84-latek oddał się w ręce policji
 - [https://tvn24.pl/swiat/usa-nastolatek-postrzelony-bo-zapukal-do-zlych-drzwi-andrew-lester-oddal-sie-w-rece-policji-6948586?source=rss](https://tvn24.pl/swiat/usa-nastolatek-postrzelony-bo-zapukal-do-zlych-drzwi-andrew-lester-oddal-sie-w-rece-policji-6948586?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 08:55:32+00:00

<img alt="Strzelał do nastolatka, który zapukał do jego drzwi. 84-latek oddał się w ręce policji" src="https://tvn24.pl/najnowsze/cdn-zdjecie-gw7d29-ralph-yarl-w-szpitalu-6930777/alternates/LANDSCAPE_1280" />
    Andrew Lester usłyszał zarzuty.

## Zwłoki mężczyzny znalezione w podwoziu samolotu. Maszyna przyleciała z Kanady
 - [https://tvn24.pl/swiat/holandia-zwloki-mezczyzny-znalezione-w-podwoziu-samolotu-maszyna-przyleciala-z-kanady-6948695?source=rss](https://tvn24.pl/swiat/holandia-zwloki-mezczyzny-znalezione-w-podwoziu-samolotu-maszyna-przyleciala-z-kanady-6948695?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 08:46:47+00:00

<img alt="Zwłoki mężczyzny znalezione w podwoziu samolotu. Maszyna przyleciała z Kanady" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-os9v47-od-45-tysiaca-do-5-tysiecy-osob-straci-w-tym-roku-prace-w-holenderskich-liniach-lotniczych-klm-4654142/alternates/LANDSCAPE_1280" />
    Trwa śledztwo.

## Gwałtowna zmiana w kredytach frankowych
 - [https://tvn24.pl/biznes/pieniadze/kredyty-frankowe-pogarsza-sie-jakosc-ich-portfela-6948650?source=rss](https://tvn24.pl/biznes/pieniadze/kredyty-frankowe-pogarsza-sie-jakosc-ich-portfela-6948650?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 08:46:38+00:00

<img alt="Gwałtowna zmiana w kredytach frankowych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pne9oq-pap_20201003_0sr-1-6719594/alternates/LANDSCAPE_1280" />
    "Teoretycznie to mógłby być powód do alarmu".

## "Oddajmy hołd heroicznej walce żydowskich powstańców, którzy w beznadziejnej sytuacji chwycili za broń"
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-premier-mateusz-morawiecki-zlozyl-kwiaty-przed-tablica-pamieci-zolnierzy-okregu-armii-krajowej-warszawa-miasto-przemowienie-6948683?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-premier-mateusz-morawiecki-zlozyl-kwiaty-przed-tablica-pamieci-zolnierzy-okregu-armii-krajowej-warszawa-miasto-przemowienie-6948683?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 08:39:23+00:00

<img alt="" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-iqwjs7-premier-mateusz-morawiecki-podczas-zlozenia-kwiatow-przed-tablica-pamieci-zolnierzy-okregu-armii-krajowej-warszawa-miasto-6948732/alternates/LANDSCAPE_1280" />
    Premier w 80. rocznicę powstania w getcie warszawskim.

## Młody łoś ugrzązł w bagnie. Akcji ratunkowej przyglądała się klępa z drugim łoszakiem
 - [https://tvn24.pl/pomorze/lesnictwo-debrzno-mlody-los-ugrzazl-w-bagnie-pomogli-mysliwi-i-strazacy-6948469?source=rss](https://tvn24.pl/pomorze/lesnictwo-debrzno-mlody-los-ugrzazl-w-bagnie-pomogli-mysliwi-i-strazacy-6948469?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 08:39:06+00:00

<img alt="Młody łoś ugrzązł w bagnie. Akcji ratunkowej przyglądała się klępa z drugim łoszakiem" src="https://tvn24.pl/pomorze/cdn-zdjecie-kfqzwr-mlody-los-ugrzazl-w-bagnie-uratowali-go-mysliwi-i-strazacy-6948475/alternates/LANDSCAPE_1280" />
    Zwierzę uratowali myśliwi i strażacy.

## Sześciolatek błąkał się po mieście
 - [https://tvn24.pl/wroclaw/zlotoryja-szesciolatek-blakal-sie-po-miescie-babcia-nie-byla-w-stanie-za-nim-nadazyc-6948616?source=rss](https://tvn24.pl/wroclaw/zlotoryja-szesciolatek-blakal-sie-po-miescie-babcia-nie-byla-w-stanie-za-nim-nadazyc-6948616?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 08:35:43+00:00

<img alt="Sześciolatek błąkał się po mieście" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cpmduj-policja-zdjecie-ilustracyjne-6885161/alternates/LANDSCAPE_1280" />
    Oddalił się od babci w trakcie spaceru. A ta nie była w stanie za nim nadążyć.

## Chcieli wysadzić muru getta. Akcja "Chwackiego"
 - [https://tvn24.pl/polska/80-lat-temu-wybuchlo-powstanie-w-getcie-warszawskim-oddzial-jozefa-pszennego-chwackiego-probowal-wysadzic-mur-6948574?source=rss](https://tvn24.pl/polska/80-lat-temu-wybuchlo-powstanie-w-getcie-warszawskim-oddzial-jozefa-pszennego-chwackiego-probowal-wysadzic-mur-6948574?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 08:35:03+00:00

<img alt="Chcieli wysadzić muru getta. Akcja " src="https://tvn24.pl/najnowsze/cdn-zdjecie-jka958-ipn-warszawskie-getto-6894707/alternates/LANDSCAPE_1280" />
    "Okazało się to znacznie trudniejsze niż przypuszczano".

## Ponad 9 milionów złotych w Lotto. Wiemy, w którym mieście padła wygrana
 - [https://tvn24.pl/biznes/pieniadze/rzeszow-szostka-w-lotto-padla-w-rzeszowie-wyniki-lotto-z-dnia-180423-6948657?source=rss](https://tvn24.pl/biznes/pieniadze/rzeszow-szostka-w-lotto-padla-w-rzeszowie-wyniki-lotto-z-dnia-180423-6948657?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 08:08:29+00:00

<img alt="Ponad 9 milionów złotych w Lotto. Wiemy, w którym mieście padła wygrana" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ufsgdq-rzeszow-shutterstock_1968523948-6948681/alternates/LANDSCAPE_1280" />
    Jedna szóstka we wtorkowym losowaniu.

## Bez broni i bez szans stanęli naprzeciw hitlerowskiej machiny zagłady. Trwa program specjalny w TVN24 GO
 - [https://tvn24.pl/go/live,1/80-rocznica-wybuchu-powstania-w-getcie-warszawskim,93478?source=rss](https://tvn24.pl/go/live,1/80-rocznica-wybuchu-powstania-w-getcie-warszawskim,93478?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 08:00:48+00:00

<img alt="Bez broni i bez szans stanęli naprzeciw hitlerowskiej machiny zagłady. Trwa program specjalny w TVN24 GO" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wk8by3-ogladaj-getto-go-bez-godziny-6948513/alternates/LANDSCAPE_1280" />
    W 80. rocznicę wybuchu powstania w getcie warszawskim.

## Ważny wyrok Sądu Najwyższego w sprawie testamentów
 - [https://tvn24.pl/biznes/pieniadze/testament-kiedy-jest-wazny-wazny-wyrok-sadu-najwyzszego-6948533?source=rss](https://tvn24.pl/biznes/pieniadze/testament-kiedy-jest-wazny-wazny-wyrok-sadu-najwyzszego-6948533?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 07:49:45+00:00

<img alt="Ważny wyrok Sądu Najwyższego w sprawie testamentów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9nw3ik-sad-najwyzszy-shutterstock_2280091059-6948637/alternates/LANDSCAPE_1280" />
    Uwzględniono skargę nadzwyczajną Prokuratora Generalnego.

## Przejechał na czerwonym, zauważyli go policjanci. Na sumieniu miał coś jeszcze
 - [https://tvn24.pl/bialystok/suwalki-jechal-hulajnoga-elektryczna-byl-pijany-zwrocil-na-siebie-uwage-bo-przejechal-na-czerwonym-6948485?source=rss](https://tvn24.pl/bialystok/suwalki-jechal-hulajnoga-elektryczna-byl-pijany-zwrocil-na-siebie-uwage-bo-przejechal-na-czerwonym-6948485?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 07:45:31+00:00

<img alt="Przejechał na czerwonym, zauważyli go policjanci. Na sumieniu miał coś jeszcze" src="https://tvn24.pl/najnowsze/cdn-zdjecie-okxstx-zwrocil-na-siebie-uwage-bo-przejechal-na-czerwonym-6948417/alternates/LANDSCAPE_1280" />
    Jechał hulajnogą elektryczną.

## Lotnisko w Radomiu coraz bliżej startu. Wiemy, ile zapłacą linie lotnicze
 - [https://tvn24.pl/biznes/turystyka/lotnisko-warszawa-radom-opublikowano-cennik-oplat-lotniskowych-6948377?source=rss](https://tvn24.pl/biznes/turystyka/lotnisko-warszawa-radom-opublikowano-cennik-oplat-lotniskowych-6948377?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 07:45:10+00:00

<img alt="Lotnisko w Radomiu coraz bliżej startu. Wiemy, ile zapłacą linie lotnicze" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-jlxyvl-otwarcie-lotniska-w-radomiu-coraz-blizej-6458113/alternates/LANDSCAPE_1280" />
    W przyszłym tygodniu na lotnisku na południu Mazowsza ma wylądować pierwszy samolot pasażerski.

## Recydywista na parkiecie NBA. Zapłacił już niemal 1,3 miliona dolarów, znów został zawieszony
 - [https://eurosport.tvn24.pl/recydywista-na-parkiecie-nba--zap-aci--ju--niemal-1-3-miliona-dolar-w--zn-w-zosta--zawieszony,1143328.html?source=rss](https://eurosport.tvn24.pl/recydywista-na-parkiecie-nba--zap-aci--ju--niemal-1-3-miliona-dolar-w--zn-w-zosta--zawieszony,1143328.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 07:35:00+00:00

<img alt="Recydywista na parkiecie NBA. Zapłacił już niemal 1,3 miliona dolarów, znów został zawieszony" src="https://tvn24.pl/najnowsze/cdn-zdjecie-87l9tv-draymond-green-jest-koszykarzem-golden-state-warriors-6948611/alternates/LANDSCAPE_1280" />
    Draymond Green znów zapłaci za gorącą głowę.

## Podano przyczynę śmierci wokalisty Aarona Cartera
 - [https://tvn24.pl/kultura-i-styl/usa-podano-przyczyne-smierci-aarona-cartera-wokalisty-i-brata-nicka-cartera-z-backstreet-boys-6948425?source=rss](https://tvn24.pl/kultura-i-styl/usa-podano-przyczyne-smierci-aarona-cartera-wokalisty-i-brata-nicka-cartera-z-backstreet-boys-6948425?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 07:33:36+00:00

<img alt="Podano przyczynę śmierci wokalisty Aarona Cartera" src="https://tvn24.pl/najnowsze/cdn-zdjecie-65sjfo-aaron-carter-zmarl-w-wieku-34-lat-6948446/alternates/LANDSCAPE_1280" />
    Był młodszym bratem Nicka Cartera z zespołu Backstreet Boys.

## Ta substancja "była bardzo szkodliwa". Władze o problemie wiedziały już w lutym
 - [https://tvn24.pl/polska/wladze-juz-w-lutym-wiedzialy-o-problemie-z-jakoscia-ukrainskich-zboz-6946982?source=rss](https://tvn24.pl/polska/wladze-juz-w-lutym-wiedzialy-o-problemie-z-jakoscia-ukrainskich-zboz-6946982?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 07:28:09+00:00

<img alt="Ta substancja " src="https://tvn24.pl/najnowsze/cdn-zdjecie-s3f05j-ukraina-zboze-6929911/alternates/LANDSCAPE_1280" />
    Materiał magazynu "Polska i Świat".

## Kobieta w dziewiątym miesiącu ciąży zastrzelona przez nastolatków. "Myśleli, że autem jedzie ktoś inny"
 - [https://tvn24.pl/swiat/usa-36-latka-w-dziewiatym-miesiacu-ciazy-zastrzelona-w-samochodzie-przez-trzech-nastolatkow-6948519?source=rss](https://tvn24.pl/swiat/usa-36-latka-w-dziewiatym-miesiacu-ciazy-zastrzelona-w-samochodzie-przez-trzech-nastolatkow-6948519?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 07:26:36+00:00

<img alt="Kobieta w dziewiątym miesiącu ciąży zastrzelona przez nastolatków. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-tqjmp5-usa-zatrzymana-20-latka-siedziala-w-radiowozie-uderzyl-w-niego-jadacy-pociag-6122194/alternates/LANDSCAPE_1280" />
    36-letnia Kerisha Johnson odbierała znajomych z imprezy.

## "Wystarczy liczyć w zakresie do 20, by wiedzieć, że to ukraińskie zboże nam się nie zmieści"
 - [https://tvn24.pl/biznes/z-kraju/ukrainskie-zboze-w-polsce-problemy-z-tranzytem-maciej-samcik-komentuje-6948427?source=rss](https://tvn24.pl/biznes/z-kraju/ukrainskie-zboze-w-polsce-problemy-z-tranzytem-maciej-samcik-komentuje-6948427?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 07:20:57+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ksqovq-ukraina-elewator-zbozowy-podczas-zniw-w-obwodzie-odeskim-6894316/alternates/LANDSCAPE_1280" />
    Maciej Samcik był gościem we "Wstajesz i wiesz" w TVN24.

## Osiem rosyjskich bombowców nad neutralnymi wodami
 - [https://tvn24.pl/swiat/rosja-resort-obrony-w-moskwie-osiem-rosyjskich-bombowcow-przelecialo-nad-morzem-ochockim-i-morzem-japonskim-6948437?source=rss](https://tvn24.pl/swiat/rosja-resort-obrony-w-moskwie-osiem-rosyjskich-bombowcow-przelecialo-nad-morzem-ochockim-i-morzem-japonskim-6948437?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 07:14:18+00:00

<img alt="Osiem rosyjskich bombowców nad neutralnymi wodami" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pb1pby-rosyjskie-bombowce-nad-wodami-morza-ochockiego-i-morza-japonskiego-kadry-z-wideo-rosyjskiego-resortu-6948481/alternates/LANDSCAPE_1280" />
    Komunikat resortu obrony Rosji.

## Tabliczka z napisem "Teren prywatny. Wstęp wzbroniony" na chodniku
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-wlochy-chodnik-z-zakazem-wstepu-dzielnica-bedzie-wyjasniac-sprawe-6879727?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-wlochy-chodnik-z-zakazem-wstepu-dzielnica-bedzie-wyjasniac-sprawe-6879727?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 07:09:15+00:00

<img alt="Tabliczka z napisem " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-rghhow-chodnik-z-zakazem-wstepu-przy-ulicy-jutrzenki-6879681/alternates/LANDSCAPE_1280" />
    W Warszawie.

## Za to najbardziej dostało się Marciniakowi
 - [https://eurosport.tvn24.pl/za-to-najbardziej-dosta-o-si--marciniakowi---co-za-b--d-polskiego-s-dziego--,1143326.html?source=rss](https://eurosport.tvn24.pl/za-to-najbardziej-dosta-o-si--marciniakowi---co-za-b--d-polskiego-s-dziego--,1143326.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 07:07:00+00:00

<img alt="Za to najbardziej dostało się Marciniakowi" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2gkkrv-dyskusyjna-interwencja-pilkarza-milanu-6948556/alternates/LANDSCAPE_1280" />
    Ocenia "Corriere dello Sport".

## E-papierosy niespełniające standardów wykryte w brytyjskich sklepach. W Polsce ich popularność rośnie
 - [https://tvn24.pl/swiat/e-papierosy-a-zdrowie-niespelniajace-standardow-e-papierosy-wykryte-w-brytyjskich-sklepach-w-polsce-ich-popularnosc-rosnie-6930334?source=rss](https://tvn24.pl/swiat/e-papierosy-a-zdrowie-niespelniajace-standardow-e-papierosy-wykryte-w-brytyjskich-sklepach-w-polsce-ich-popularnosc-rosnie-6930334?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 07:05:39+00:00

<img alt="E-papierosy niespełniające standardów wykryte w brytyjskich sklepach. W Polsce ich popularność rośnie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ocdwk3-popularnosc-e-papierosow-rosnie-6937805/alternates/LANDSCAPE_1280" />
    Eksperci przestrzegają.

## "Działania antyterrorystyczne i pościgowe". RCB ostrzega mieszkańców ośmiu województw
 - [https://tvn24.pl/pomorze/wolf-ram-23-policjanci-cwicza-z-fbi-alert-rcb-dla-mieszkancow-osmiu-wojewodztw-6948518?source=rss](https://tvn24.pl/pomorze/wolf-ram-23-policjanci-cwicza-z-fbi-alert-rcb-dla-mieszkancow-osmiu-wojewodztw-6948518?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 06:54:13+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-c3c7t6-cwiczenia-wolf-ram-23-w-lodzi-6948501/alternates/LANDSCAPE_1280" />
    Kolejny dzień ćwiczeń policji i FBI.

## "Działania antyterrorystyczne i pościgowe". RCB ostrzega mieszkańców ośmiu województw
 - [https://tvn24.pl/pomorze/alert-rcb-dla-mieszkancow-osmiu-wojewodztw-policjanci-cwicza-z-fbi-wolf-ram-23-6948518?source=rss](https://tvn24.pl/pomorze/alert-rcb-dla-mieszkancow-osmiu-wojewodztw-policjanci-cwicza-z-fbi-wolf-ram-23-6948518?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 06:54:13+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-c3c7t6-cwiczenia-wolf-ram-23-w-lodzi-6948501/alternates/LANDSCAPE_1280" />
    Kolejny dzień ćwiczeń policji i FBI.

## Miała być blokada, trafiły miliony ton produktów z Ukrainy. Dane
 - [https://tvn24.pl/biznes/z-kraju/ukraina-polska-miliony-ton-zboza-paszy-i-nasion-oleistych-z-ukrainy-w-polsce-6948429?source=rss](https://tvn24.pl/biznes/z-kraju/ukraina-polska-miliony-ton-zboza-paszy-i-nasion-oleistych-z-ukrainy-w-polsce-6948429?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 06:45:43+00:00

<img alt="Miała być blokada, trafiły miliony ton produktów z Ukrainy. Dane" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cdourm-zboze-silos-shutterstock_2199876665-6948493/alternates/LANDSCAPE_1280" />
    Dotarła do nich Wirtualna Polska.

## Miała być blokada, trafiły miliony ton produktów z Ukrainy. Dane
 - [https://tvn24.pl/biznes/z-kraju/zboze-z-ukrainy-ile-trafilo-go-do-polski-import-produktow-rolnych-z-ukrainy-do-polski-6948429?source=rss](https://tvn24.pl/biznes/z-kraju/zboze-z-ukrainy-ile-trafilo-go-do-polski-import-produktow-rolnych-z-ukrainy-do-polski-6948429?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 06:45:43+00:00

<img alt="Miała być blokada, trafiły miliony ton produktów z Ukrainy. Dane" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cdourm-zboze-silos-shutterstock_2199876665-6948493/alternates/LANDSCAPE_1280" />
    Dotarła do nich Wirtualna Polska.

## ISW o domniemanej podróży Putina: pojechał szukać kozłów ofiarnych
 - [https://tvn24.pl/swiat/wojna-w-ukrainie-isw-odomniemanej-podrozy-wladimira-putina-pojechal-szukac-kozlow-ofiarnych-6948434?source=rss](https://tvn24.pl/swiat/wojna-w-ukrainie-isw-odomniemanej-podrozy-wladimira-putina-pojechal-szukac-kozlow-ofiarnych-6948434?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 06:44:27+00:00

<img alt="ISW o domniemanej podróży Putina: pojechał szukać kozłów ofiarnych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-gacon3-kadr-z-materialu-udostepnionego-przez-kreml-opisanego-jako-wizyta-wladimira-putina-w-obwodach-chersonskim-i-luganskim-6937153/alternates/LANDSCAPE_1280" />
    Analiza.

## Fale chmur otuliły niebo. W jaki sposób powstały?
 - [https://tvn24.pl/tvnmeteo/swiat/ocean-indyjski-chmury-orograficzne-na-niebie-w-jaki-sposob-powstaly-6938548?source=rss](https://tvn24.pl/tvnmeteo/swiat/ocean-indyjski-chmury-orograficzne-na-niebie-w-jaki-sposob-powstaly-6938548?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 06:39:23+00:00

<img alt="Fale chmur otuliły niebo. W jaki sposób powstały? " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-pll7fj-chmury-orograficzne-nad-wyspami-crozeta-6948387/alternates/LANDSCAPE_1280" />
    Uchwycone z Międzynarodowej Stacji Kosmicznej.

## Kilka tysięcy wolontariuszy rozdaje papierowe żonkile. 450 tysięcy w sześciu miastach
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-papierowe-zonkile-upamietniaja-powstanie-w-getcie-warszawskim-rozdawane-sa-w-wielu-miejscach-6948393?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-papierowe-zonkile-upamietniaja-powstanie-w-getcie-warszawskim-rozdawane-sa-w-wielu-miejscach-6948393?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 06:39:03+00:00

<img alt="Kilka tysięcy wolontariuszy rozdaje papierowe żonkile. 450 tysięcy w sześciu miastach" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-fygs8z-ruszyla-akcja-spoleczno-edukacyjna-zonkile-6948412/alternates/LANDSCAPE_1280" />
    W Warszawie, Łodzi, Krakowie, Białymstoku, Lublinie i Wrocławiu.

## Nowy kontrakt Vingegaarda
 - [https://eurosport.tvn24.pl/triumfator-tour-de-france-nigdzie-si--nie-wybiera--nowy-kontrakt-vingegaarda,1143239.html?source=rss](https://eurosport.tvn24.pl/triumfator-tour-de-france-nigdzie-si--nie-wybiera--nowy-kontrakt-vingegaarda,1143239.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 06:34:00+00:00

<img alt=" Nowy kontrakt Vingegaarda" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ufncg7-vingegaard-ostatnio-wygral-wyscig-dookola-kraju-baskow-6948486/alternates/LANDSCAPE_1280" />
    Triumfator Tour de France nigdzie się nie wybiera.

## "Opowiadanie o plombach i konwojach to zwyczajne bajdurzenie"
 - [https://tvn24.pl/polska/marek-sawicki-opowiadanie-o-plombach-i-konwojach-to-zwyczajne-bajdurzenie-6948433?source=rss](https://tvn24.pl/polska/marek-sawicki-opowiadanie-o-plombach-i-konwojach-to-zwyczajne-bajdurzenie-6948433?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 06:09:34+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mj8svp-19-0730-piasek-cl-0001-6948406/alternates/LANDSCAPE_1280" />
    Były minister rolnictwa, poseł PSL Marek Sawicki w "Rozmowie Piaseckiego".

## Marciniak i VAR na językach. Trener Napoli grzmi
 - [https://eurosport.tvn24.pl/marciniak-i-var-na-j-zykach--trener-napoli-grzmi--ewidentny-rzut-karny,1143324.html?source=rss](https://eurosport.tvn24.pl/marciniak-i-var-na-j-zykach--trener-napoli-grzmi--ewidentny-rzut-karny,1143324.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 06:03:00+00:00

<img alt="Marciniak i VAR na językach. Trener Napoli grzmi" src="https://tvn24.pl/najnowsze/cdn-zdjecie-dhdm2x-napoli-odpadlo-z-ligi-mistrzow-6948435/alternates/LANDSCAPE_1280" />
    Kontrowersyjna decyzja Szymona Marciniaka i jego asystentów VAR.

## Komisja Europejska o polsko-ukraińskim porozumieniu: pierwszy krok do rozwiązania obecnej sytuacji
 - [https://tvn24.pl/biznes/ze-swiata/komisja-europejska-zadowolona-z-porozumienia-polski-i-ukrainy-w-sprawie-zboza-6948383?source=rss](https://tvn24.pl/biznes/ze-swiata/komisja-europejska-zadowolona-z-porozumienia-polski-i-ukrainy-w-sprawie-zboza-6948383?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 05:54:27+00:00

<img alt="Komisja Europejska o polsko-ukraińskim porozumieniu: pierwszy krok do rozwiązania obecnej sytuacji" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9y0r60-zboze-ukraina-6877778/alternates/LANDSCAPE_1280" />
    Komentarz rzeczniczki KE.

## Rozbitkowie uratowani po sześciu dniach bez jedzenia i picia
 - [https://tvn24.pl/tvnmeteo/swiat/australia-rozbitkowie-uratowani-po-szesciu-dniach-bez-jedzenia-i-picia-ich-lodz-rozbila-sie-podczas-cyklonu-ilsa-6938605?source=rss](https://tvn24.pl/tvnmeteo/swiat/australia-rozbitkowie-uratowani-po-szesciu-dniach-bez-jedzenia-i-picia-ich-lodz-rozbila-sie-podczas-cyklonu-ilsa-6938605?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 05:45:27+00:00

<img alt="Rozbitkowie uratowani po sześciu dniach bez jedzenia i picia" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-pqze09-rybacy-uwiezieni-po-cyklonie-ilsa-6948367/alternates/LANDSCAPE_1280" />
    Los niektórych rybaków pozostaje nieznany.

## "Mama nigdy nic nie mówiła, chciała nas ochronić"
 - [https://tvn24.pl/programy/80-rocznica-powstania-w-getcie-warszawskim-muzeum-polin-przygotowalo-specjalna-wystawe-6940198?source=rss](https://tvn24.pl/programy/80-rocznica-powstania-w-getcie-warszawskim-muzeum-polin-przygotowalo-specjalna-wystawe-6940198?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 05:29:13+00:00

<img alt="" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-dfaoxn-wokol-nas-morze-ognia-losy-zydowskich-cywilow-podczas-powstania-w-getcie-warszawskim-6898848/alternates/LANDSCAPE_1280" />
    Muzeum POLIN przygotowało wystawę na 80. rocznicę powstania w warszawskim getcie.

## W tym mieście jest najwięcej milionerów na świecie. Nowy raport
 - [https://tvn24.pl/biznes/ze-swiata/miasta-z-najwieksza-liczba-milionerow-nowy-jork-przed-tokio-londyn-najwyzej-z-europy-raport-henley-and-partners-6948365?source=rss](https://tvn24.pl/biznes/ze-swiata/miasta-z-najwieksza-liczba-milionerow-nowy-jork-przed-tokio-londyn-najwyzej-z-europy-raport-henley-and-partners-6948365?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 05:27:01+00:00

<img alt="W tym mieście jest najwięcej milionerów na świecie. Nowy raport" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7d6fv8-nowy-jork-samochody-shutterstock_693636631-6948374/alternates/LANDSCAPE_1280" />
    Jeden przedstawiciel Europy w pierwszej dziesiątce.

## 79 sekund perfekcyjnej akcji. "Tak się bawi Real"
 - [https://eurosport.tvn24.pl/79-sekund-perfekcyjnej-akcji---tak-si--bawi-real-,1143322.html?source=rss](https://eurosport.tvn24.pl/79-sekund-perfekcyjnej-akcji---tak-si--bawi-real-,1143322.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 05:13:00+00:00

<img alt="79 sekund perfekcyjnej akcji. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-hzieup-gettyimages-1251960283-6948385/alternates/LANDSCAPE_1280" />
    Real pokazał Chelsea, jak grać i wygrywać, ale też jak po mistrzowsku rozegrać bramkową akcję.

## W pobliżu granicy z Białorusią znaleziono zwłoki mężczyzny
 - [https://tvn24.pl/bialystok/janowo-w-poblizu-granicy-z-bialorusia-znaleziono-zwloki-mezczyzny-6948331?source=rss](https://tvn24.pl/bialystok/janowo-w-poblizu-granicy-z-bialorusia-znaleziono-zwloki-mezczyzny-6948331?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 05:10:20+00:00

<img alt="W pobliżu granicy z Białorusią znaleziono zwłoki mężczyzny" src="https://tvn24.pl/najnowsze/cdn-zdjecie-c8nx5i-w-poblizu-granicy-z-bialorusia-znaleziono-zwloki-mezczyzny-6948330/alternates/LANDSCAPE_1280" />
    Jego tożsamość nie jest na razie znana.

## Ocalili setki osób, bo tak nakazywała przyzwoitość. "Największym zagrożeniem byli rodacy, Polacy"
 - [https://tvn24.pl/go/programy,7/czarno-na-bialym-odcinki,11367/odcinek-2396,S00E2396,1046670?source=rss](https://tvn24.pl/go/programy,7/czarno-na-bialym-odcinki,11367/odcinek-2396,S00E2396,1046670?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 05:00:00+00:00

<img alt="Ocalili setki osób, bo tak nakazywała przyzwoitość. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-otogls-antonina-i-jan-zabinscy-6940377/alternates/LANDSCAPE_1280" />
    Niezwykła historia Antoniny i Jana Żabińskich we wspomnieniach ich córki i jednego z ocalonych.

## Jednego dnia dwa razy zatrzymali go ci sami policjanci
 - [https://tvn24.pl/tvnwarszawa/ulice/tczow-byl-pijany-jednego-dnia-dwa-razy-zatrzymali-go-ci-sami-policjanci-6938120?source=rss](https://tvn24.pl/tvnwarszawa/ulice/tczow-byl-pijany-jednego-dnia-dwa-razy-zatrzymali-go-ci-sami-policjanci-6938120?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 04:44:57+00:00

<img alt="Jednego dnia dwa razy zatrzymali go ci sami policjanci" src="https://tvn24.pl/najnowsze/cdn-zdjecie-v6v8zs-12-latek-kierowal-ciagnikiem-obok-siedzial-33-latek-zdjecie-ilustracyjne-4688321/alternates/LANDSCAPE_1280" />
    Teraz grozi mu nawet pięć lat więzienia.

## Ukraina. Najważniejsze wydarzenia ostatnich godzin
 - [https://tvn24.pl/swiat/ukraina-walczy-najwazniejsze-wydarzenia-ostatnich-godzin-19-kwietnia-2023-6948338?source=rss](https://tvn24.pl/swiat/ukraina-walczy-najwazniejsze-wydarzenia-ostatnich-godzin-19-kwietnia-2023-6948338?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 04:42:38+00:00

<img alt="Ukraina. Najważniejsze wydarzenia ostatnich godzin" src="https://tvn24.pl/najnowsze/cdn-zdjecie-23igao-zniszczone-po-rosyjskim-ataku-magazyny-z-ukrainskim-zbozem-w-kupiansku-w-obwodzie-charkowskim-6883722/alternates/LANDSCAPE_1280" />
    Rosyjska inwazja na Ukrainę trwa od 420 dni.

## Przebijali się z pustostanu do kantoru. Jeden wpadł podczas wiercenia, dwaj po próbie ucieczki
 - [https://tvn24.pl/tvnwarszawa/zoliborz/warszawa-zoliborz-planowali-przebic-sie-z-pustostanu-do-kantoru-jeden-wpadl-podczas-wiercenia-dwaj-po-probie-ucieczki-6948364?source=rss](https://tvn24.pl/tvnwarszawa/zoliborz/warszawa-zoliborz-planowali-przebic-sie-z-pustostanu-do-kantoru-jeden-wpadl-podczas-wiercenia-dwaj-po-probie-ucieczki-6948364?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 04:35:43+00:00

<img alt="Przebijali się z pustostanu do kantoru. Jeden wpadł podczas wiercenia, dwaj po próbie ucieczki" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-73objp-policja-zatrzymala-podejrzanych-o-probe-wlamania-do-kantoru-6155188/alternates/LANDSCAPE_1280" />
    Nie wiedzieli, że od jakiegoś czasu byli pod obserwacją policji.

## Wysoka wygrana w Lotto. Padła szóstka
 - [https://tvn24.pl/biznes/z-kraju/wyniki-lotto-z-dnia180423-liczby-z-ostatniego-losowania-padla-jedna-szostka-6948354?source=rss](https://tvn24.pl/biznes/z-kraju/wyniki-lotto-z-dnia180423-liczby-z-ostatniego-losowania-padla-jedna-szostka-6948354?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 04:28:53+00:00

<img alt="Wysoka wygrana w Lotto. Padła szóstka" src="https://tvn24.pl/najnowsze/cdn-zdjecie-oslmyw-lotto-s-shutterstock275295956-5128640/alternates/LANDSCAPE_1280" />
    Wyniki losowania.

## IMGW ostrzega. Silny wiatr w dwóch województwach
 - [https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-silny-wiatr-w-polsce-6948359?source=rss](https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-silny-wiatr-w-polsce-6948359?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 04:28:25+00:00

<img alt="IMGW ostrzega. Silny wiatr w dwóch województwach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-y5e89u-silny-wiatr-moze-dac-sie-we-znaki-5727243/alternates/LANDSCAPE_1280" />
    Sprawdź, gdzie pogoda może być niebezpieczna.

## Silny wiatr, sztorm i nie tylko. Alerty IMGW
 - [https://tvn24.pl/tvnmeteo/prognoza/alerty-imgw-silny-wiatr-sztorm-przymrozki-gdzie-obowiazuja-ostrzezenia-meteo-6948359?source=rss](https://tvn24.pl/tvnmeteo/prognoza/alerty-imgw-silny-wiatr-sztorm-przymrozki-gdzie-obowiazuja-ostrzezenia-meteo-6948359?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 04:28:25+00:00

<img alt="Silny wiatr, sztorm i nie tylko. Alerty IMGW" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wyk3j6-silny-wiatr-5075548/alternates/LANDSCAPE_1280" />
    Sprawdź, gdzie pogoda może być niebezpieczna.

## Kim chce poznać scenariusze przeciwników. Wydał rozkaz
 - [https://tvn24.pl/swiat/korea-polnocna-kim-dzong-un-nakazal-rozmiescic-siec-satelitow-szpiegowskich-6948353?source=rss](https://tvn24.pl/swiat/korea-polnocna-kim-dzong-un-nakazal-rozmiescic-siec-satelitow-szpiegowskich-6948353?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 04:22:08+00:00

<img alt="Kim chce poznać scenariusze przeciwników. Wydał rozkaz" src="https://tvn24.pl/najnowsze/cdn-zdjecie-e3ww6c-kim-dzong-un-przywodca-korei-polnocnej-6877714/alternates/LANDSCAPE_1280" />
    Poinformowała państwowa agencja prasowa KCNA.

## Świątek nominowana do prestiżowej nagrody
 - [https://eurosport.tvn24.pl/iga--wi-tek-nominowana-do-presti-owej-nagrody,1143276.html?source=rss](https://eurosport.tvn24.pl/iga--wi-tek-nominowana-do-presti-owej-nagrody,1143276.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 04:10:05+00:00

<img alt="Świątek nominowana do prestiżowej nagrody" src="https://tvn24.pl/najnowsze/cdn-zdjecie-e6iqy8-iga-swiatek-6948357/alternates/LANDSCAPE_1280" />
    W kategorii "Sportsmenka Roku".

## W samo południe zawyją syreny
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-w-samo-poludnie-w-stolicy-zawyja-syreny-6948349?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-w-samo-poludnie-w-stolicy-zawyja-syreny-6948349?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 04:07:00+00:00

<img alt="W samo południe zawyją syreny" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-c03zpd-syreny-alarmowe-zdjecie-ilustracyjne-6101936/alternates/LANDSCAPE_1280" />
    Dla upamiętnienia 80. rocznicy powstania w warszawskim getcie

## Rocznica powstania. Co wydarzy się w stolicy
 - [https://tvn24.pl/tvnwarszawa/najnowsze/80-rocznica-wybuchu-powstania-w-getcie-w-warszawie-plan-obchodow-6938477?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/80-rocznica-wybuchu-powstania-w-getcie-w-warszawie-plan-obchodow-6938477?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 04:04:59+00:00

<img alt="Rocznica powstania. Co wydarzy się w stolicy" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-c6ej5s-powstanie-w-warszawskim-getcie-zdjecia-z-raportu-jurgena-stroopa-przygotowanego-dla-heinricha-himmlera-w-1943-roku-84840/alternates/LANDSCAPE_1280" />
    Wizyta prezydentów, koncerty, spektakle, spotkania.

## Sześć rzeczy, które warto dziś wiedzieć: rocznica powstania, operacja Interpolu, plany Kim Dzong Una
 - [https://tvn24.pl/swiat/6-rzeczy-ktore-warto-wiedziec-19-kwietnia-operacja-interpolu-plany-kim-dzong-una-hybrydowe-kroliki-w-hiszpanii-6948337?source=rss](https://tvn24.pl/swiat/6-rzeczy-ktore-warto-wiedziec-19-kwietnia-operacja-interpolu-plany-kim-dzong-una-hybrydowe-kroliki-w-hiszpanii-6948337?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 03:40:22+00:00

<img alt="Sześć rzeczy, które warto dziś wiedzieć: rocznica powstania, operacja Interpolu, plany Kim Dzong Una" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4bohzn-proba-pocisku-balistycznego-z-udzialem-kim-dzong-una-6899695/alternates/LANDSCAPE_1280" />
    Podsumowanie.

## Zawalił się piętrowy parking. Ofiara i ranni
 - [https://tvn24.pl/swiat/usa-co-najmniej-jedna-ofiara-smiertelna-zawalenia-sie-parkingu-w-nowym-jorku-6948335?source=rss](https://tvn24.pl/swiat/usa-co-najmniej-jedna-ofiara-smiertelna-zawalenia-sie-parkingu-w-nowym-jorku-6948335?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 03:18:28+00:00

<img alt="Zawalił się piętrowy parking. Ofiara i ranni" src="https://tvn24.pl/polska/cdn-zdjecie-ivmsoy-parking-6948350/alternates/LANDSCAPE_1280" />
    Na nowojorskim dolnym Manhattanie.

## Przechodzimy obok i nawet nie wiemy, co mijamy. "Cała Warszawa kryje takie tajemnice"
 - [https://tvn24.pl/go/programy,7/tylko-w-tvn24-go-odcinki,283316/odcinek-3169,S00E3169,1046691?source=rss](https://tvn24.pl/go/programy,7/tylko-w-tvn24-go-odcinki,283316/odcinek-3169,S00E3169,1046691?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 03:15:00+00:00

<img alt="Przechodzimy obok i nawet nie wiemy, co mijamy. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-2fmlnd-kamienica-w-warszawie-6938631/alternates/LANDSCAPE_1280" />
    Mariusz Nowik odwiedził w Warszawie miejsca, które 80 lat temu były świadkami druzgocących scen.

## Siły powietrzne Ukrainy: zestrzeliliśmy siedem dronów
 - [https://tvn24.pl/swiat/wojna-w-ukrainie-relacja-na-zywo-19-kwietnia-2023-6948339?source=rss](https://tvn24.pl/swiat/wojna-w-ukrainie-relacja-na-zywo-19-kwietnia-2023-6948339?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-19 03:08:50+00:00

<img alt="Siły powietrzne Ukrainy: zestrzeliliśmy siedem dronów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xj1tzy-ukrainski-zolnierz-w-poblizu-bachmutu-6891710/alternates/LANDSCAPE_1280" />
    W tvn24.pl relacjonujemy wydarzenia z i wokół Ukrainy.

