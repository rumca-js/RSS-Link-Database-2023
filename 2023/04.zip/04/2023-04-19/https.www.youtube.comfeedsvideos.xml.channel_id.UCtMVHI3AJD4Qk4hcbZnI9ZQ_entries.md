# Source:SomeOrdinaryGamers, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCtMVHI3AJD4Qk4hcbZnI9ZQ, language:en-US

## Nintendo Is Insanely Cruel...
 - [https://www.youtube.com/watch?v=dI0x4SED7HU](https://www.youtube.com/watch?v=dI0x4SED7HU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtMVHI3AJD4Qk4hcbZnI9ZQ
 - date published: 2023-04-19 22:28:51+00:00

Hello guys and gals, it's me Mutahar again! This time we take a look at Nintendo once again in a very recent span of time in regards to Gary Bowser. Gary was once a member of the notorious Team Xecuter and after serving jailtime and receiving a multi-million dollar fine, Gary is finally on his way out only to realize he'll have to pay back Nintendo every dime throughout the rest of his natural life. Thanks for watching!
Like, Comment and Subscribe for more videos!

Check out the newest podcast episode: https://youtu.be/7fzk-QmDkvo

