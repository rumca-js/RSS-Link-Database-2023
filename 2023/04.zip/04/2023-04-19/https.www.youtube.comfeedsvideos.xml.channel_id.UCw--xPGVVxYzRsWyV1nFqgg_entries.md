# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## *Hits Blunt*... Going Postal is Pretty Good!
 - [https://www.youtube.com/watch?v=G9ed0gOIbmM](https://www.youtube.com/watch?v=G9ed0gOIbmM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2023-04-19 21:46:37+00:00

Let's Discuss one of Discworld's BEST books, Going Postal! 
Check out the Going Postal and support local bookstores: https://bookshop.org/a/89948/9780062334978 

Merch: https://www.danielbgreene.com 

New Channel: https://www.youtube.com/channel/UC9tQc_K_LtoCiVGx7_R3FRA 
Patreon: https://www.patreon.com/DanielBGreene 
All the Me Social Links: https://linktr.ee/DanielGreene

Lawful Times Series: 
Breach of Peace: https://tinyurl.com/BoPTLT 
Rebels Creed: https://tinyurl.com/RCTLTDG

P.O. Box: PO Box 7874 Henrico, VA 23231

00:00 Spoiler Free

10:06 Spoilers

