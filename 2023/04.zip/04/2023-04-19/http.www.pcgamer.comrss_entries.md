# Source:pcgamer, URL:http://www.pcgamer.com/rss, language:en-US

## Big update this week on future of The Division, including Heartland and Resurgence
 - [https://www.pcgamer.com/big-update-this-week-on-future-of-the-division-including-heartland-and-resurgence](https://www.pcgamer.com/big-update-this-week-on-future-of-the-division-including-heartland-and-resurgence)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-04-19 22:56:57+00:00

A reddish storm of Division games.

## The balls on this guy: An author is suing Amazon and JRR Tolkien's grandson claiming they infringed on his Lord of the Rings fanfiction
 - [https://www.pcgamer.com/rings-of-power-lawsuit](https://www.pcgamer.com/rings-of-power-lawsuit)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-04-19 21:56:02+00:00

The author of "The Fellowship Of The King" wants $250M because he says Amazon and The Tolkien Estate stole his ideas for The Rings of Power.

## Google employees reportedly begged it not to release 'pathological liar' AI chatbot Bard
 - [https://www.pcgamer.com/google-employees-reportedly-begged-it-not-to-release-pathological-liar-ai-chatbot-bard](https://www.pcgamer.com/google-employees-reportedly-begged-it-not-to-release-pathological-liar-ai-chatbot-bard)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-04-19 21:45:01+00:00

One employee called the chatbot "worse than useless."

## Ubisoft's MouseTrap works, and console players are dancing on cheat hardware's grave
 - [https://www.pcgamer.com/ubisofts-mousetrap-works-and-console-players-are-dancing-on-cheat-hardwares-grave](https://www.pcgamer.com/ubisofts-mousetrap-works-and-console-players-are-dancing-on-cheat-hardwares-grave)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-04-19 21:29:35+00:00

Input spoofers beware: Cheating sucks.

## Dark and Darker devs apologize for buggy playtest, but I for one am glad I torrented it
 - [https://www.pcgamer.com/dark-and-darker-devs-apologize-for-buggy-playtest-but-i-for-one-am-glad-i-torrented-it](https://www.pcgamer.com/dark-and-darker-devs-apologize-for-buggy-playtest-but-i-for-one-am-glad-i-torrented-it)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-04-19 20:46:33+00:00

It was a rocky test, for sure, but I had a grand time with the newest map.

## Here's another e-waste crisis for the e-waste crisis pile: 'Chromebook churn'
 - [https://www.pcgamer.com/heres-another-e-waste-crisis-for-the-e-waste-crisis-pile-chromebook-churn](https://www.pcgamer.com/heres-another-e-waste-crisis-for-the-e-waste-crisis-pile-chromebook-churn)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-04-19 19:37:47+00:00

Report shows that the lack of sustainability of Chromebooks provided for schools is hurting the environment.

## Thank the dark ones: Cult of the Lamb is getting a big free DLC update this month
 - [https://www.pcgamer.com/thank-the-dark-ones-cult-of-the-lamb-is-getting-a-big-free-dlc-update-this-month](https://www.pcgamer.com/thank-the-dark-ones-cult-of-the-lamb-is-getting-a-big-free-dlc-update-this-month)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-04-19 19:00:05+00:00

Relics of the Old Faith will enable you to outsource cooking, among many other new things.

## Netflix will finally stop mailing people DVDs this year
 - [https://www.pcgamer.com/netflix-will-finally-stop-mailing-people-dvds-this-year](https://www.pcgamer.com/netflix-will-finally-stop-mailing-people-dvds-this-year)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-04-19 18:23:49+00:00

No more little red envelopes.

## The best-named game of the year finally has a release date, and it's just 4 months away
 - [https://www.pcgamer.com/the-best-named-game-of-the-year-finally-has-a-release-date-and-its-just-4-months-away](https://www.pcgamer.com/the-best-named-game-of-the-year-finally-has-a-release-date-and-its-just-4-months-away)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-04-19 17:58:33+00:00

Jet Set Radio's indie successor has been in the works since 2020.

## Where to find the Lock On Pistol in Fortnite
 - [https://www.pcgamer.com/fortnite-lock-on-pistol](https://www.pcgamer.com/fortnite-lock-on-pistol)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-04-19 17:26:05+00:00

Drop in and snag a new Lock On Pistol to home in on your next victory royale.

## Where to find Attack on Titan's ODM gear in Fortnite
 - [https://www.pcgamer.com/fortnite-odm-gear](https://www.pcgamer.com/fortnite-odm-gear)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-04-19 17:24:50+00:00

Grab Eren Jaeger's iconic ODM gear to start grappling your way to victory royale.

## OK things are getting silly now: This streamer beat Elden Ring with her brain
 - [https://www.pcgamer.com/ok-things-are-getting-silly-now-this-streamer-beat-elden-ring-with-her-brain](https://www.pcgamer.com/ok-things-are-getting-silly-now-this-streamer-beat-elden-ring-with-her-brain)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-04-19 17:01:06+00:00

The Minds Between.

## More people have played The Sims 4 than live in France
 - [https://www.pcgamer.com/more-people-have-played-the-sims-4-than-live-in-france](https://www.pcgamer.com/more-people-have-played-the-sims-4-than-live-in-france)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-04-19 16:53:16+00:00

But which would win in a fight?

## Rogue Trader shows off one of Warhammer 40K's most interesting locations for the first time in a videogame
 - [https://www.pcgamer.com/rogue-trader-shows-off-one-of-warhammer-40ks-most-interesting-locations-for-the-first-time-in-a-videogame](https://www.pcgamer.com/rogue-trader-shows-off-one-of-warhammer-40ks-most-interesting-locations-for-the-first-time-in-a-videogame)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-04-19 16:30:09+00:00

Welcome to the Dark City.

## Should you side with Berthram or the Captain in Wartales?
 - [https://www.pcgamer.com/wartales-berthram-or-captain-choice](https://www.pcgamer.com/wartales-berthram-or-captain-choice)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-04-19 16:24:52+00:00

You'll get a Golden Key either way.

## A fan favorite is returning as Darkest Dungeon 2's final launch character, and he's looking worse than ever
 - [https://www.pcgamer.com/a-fan-favorite-is-returning-as-darkest-dungeon-2s-final-launch-character-and-hes-looking-worse-than-ever](https://www.pcgamer.com/a-fan-favorite-is-returning-as-darkest-dungeon-2s-final-launch-character-and-hes-looking-worse-than-ever)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-04-19 16:00:45+00:00

The Flagellant may have been flagellating a bit too much in the intervening years.

## The Day Before announces a beta test and pledges a return to Steam
 - [https://www.pcgamer.com/the-day-before-announces-a-beta-test-and-pledges-a-return-to-steam](https://www.pcgamer.com/the-day-before-announces-a-beta-test-and-pledges-a-return-to-steam)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-04-19 15:42:23+00:00

The devs seem confident the game will hit its November release date, but who can be sure at this point?

## Sean 'Day9' Plott launches his own game studio to make a 'multiplayer PC strategy game'
 - [https://www.pcgamer.com/sean-day9-plott-launches-his-own-game-studio-to-make-a-multiplayer-pc-strategy-game](https://www.pcgamer.com/sean-day9-plott-launches-his-own-game-studio-to-make-a-multiplayer-pc-strategy-game)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-04-19 15:36:26+00:00

Apparently his responsibilities as PC Gaming Show host weren't enough to keep him sufficiently busy

## MSI's Afterburner graphics overclocking app gets its first proper update in years
 - [https://www.pcgamer.com/msis-afterburner-graphics-overclocking-app-gets-its-first-proper-update-in-years](https://www.pcgamer.com/msis-afterburner-graphics-overclocking-app-gets-its-first-proper-update-in-years)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-04-19 15:32:44+00:00

All the latest GPUs supported, set your clock speeds to stun...

## Age of Empires 2 gets some all-timer patch notes as it finally stops monks hiding in relics and dying when they drop them
 - [https://www.pcgamer.com/age-of-empires-2-gets-some-all-timer-patch-notes-as-it-finally-stops-monks-hiding-in-relics-and-dying-when-they-drop-them](https://www.pcgamer.com/age-of-empires-2-gets-some-all-timer-patch-notes-as-it-finally-stops-monks-hiding-in-relics-and-dying-when-they-drop-them)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-04-19 14:56:39+00:00

A holy unforeseen problem.

## PUBG developer's NFT metaverse platform is coming this year and still sounds like nonsense
 - [https://www.pcgamer.com/pubg-developers-nft-metaverse-platform-is-coming-this-year-and-still-sounds-like-nonsense](https://www.pcgamer.com/pubg-developers-nft-metaverse-platform-is-coming-this-year-and-still-sounds-like-nonsense)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-04-19 14:13:16+00:00

Oh great.

## You've got one week to try Modern Warfare 2's multiplayer for free
 - [https://www.pcgamer.com/youve-got-one-week-to-try-modern-warfare-2s-multiplayer-for-free](https://www.pcgamer.com/youve-got-one-week-to-try-modern-warfare-2s-multiplayer-for-free)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-04-19 13:36:37+00:00

Activision is opening some (but not all) of the game's multiplayer modes up to the non-paying public.

## Dev makes classic game free to celebrate release of remake, accidentally does it early and almost gives away the new one, before Valve saves the day
 - [https://www.pcgamer.com/dev-makes-classic-game-free-to-celebrate-release-of-remake-accidentally-does-it-early-and-almost-gives-away-the-new-one-before-valve-saves-the-day](https://www.pcgamer.com/dev-makes-classic-game-free-to-celebrate-release-of-remake-accidentally-does-it-early-and-almost-gives-away-the-new-one-before-valve-saves-the-day)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-04-19 13:24:10+00:00

Desktop Dungeons certainly needed a rewind.

## Techland wants to know who you'd like to play as in Dying Light 3
 - [https://www.pcgamer.com/techland-wants-to-know-who-youd-like-to-play-as-in-dying-light-3](https://www.pcgamer.com/techland-wants-to-know-who-youd-like-to-play-as-in-dying-light-3)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-04-19 13:02:05+00:00

Even though it hasn't announced the sequel.

## Asus ROG Strix Scar 16
 - [https://www.pcgamer.com/asus-rog-strix-scar-16-2023-review-benchmarks](https://www.pcgamer.com/asus-rog-strix-scar-16-2023-review-benchmarks)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-04-19 13:01:27+00:00

Asus packs a fantastic core spec into a 16-inch gaming laptop, with a few compromises.

## Gollum dev says it's charging for the precious Elvish-language DLC because it had to train voice actors in how to speak it
 - [https://www.pcgamer.com/gollum-dev-says-its-charging-for-the-precious-elvish-language-dlc-because-it-had-to-train-voice-actors-in-how-to-speak-it](https://www.pcgamer.com/gollum-dev-says-its-charging-for-the-precious-elvish-language-dlc-because-it-had-to-train-voice-actors-in-how-to-speak-it)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-04-19 11:20:18+00:00

We wants the Sindarin.

## Capcom promises the return of Resident Evil 2 and 3's vanished graphics and audio options
 - [https://www.pcgamer.com/capcom-promises-the-return-of-resident-evil-2-and-3s-vanished-graphics-and-audio-options](https://www.pcgamer.com/capcom-promises-the-return-of-resident-evil-2-and-3s-vanished-graphics-and-audio-options)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-04-19 11:05:22+00:00

Sorry, sorry, I'm trying to undelete it.

## Intel quietly ditches its Bitcoin mining chips
 - [https://www.pcgamer.com/intel-quietly-ditches-its-bitcoin-mining-chips](https://www.pcgamer.com/intel-quietly-ditches-its-bitcoin-mining-chips)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-04-19 10:37:02+00:00

So long, Blockscale, we hardly knew ye.

## Wordle hint and answer #669: Wednesday, April 19
 - [https://www.pcgamer.com/wordle-hint-answer-today-669-april-19](https://www.pcgamer.com/wordle-hint-answer-today-669-april-19)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-04-19 04:07:44+00:00

Today's Wordle: Help with the #669 puzzle.

