# Source:Wydarzenia Interia - Świat, URL:https://wydarzenia.interia.pl/swiat/feed, language:pl-PL

## Kontrowersyjne zawody łowieckie dla dzieci w Nowej Zelandii
 - [https://wydarzenia.interia.pl/zagranica/news-kontrowersyjne-zawody-lowieckie-dla-dzieci-w-nowej-zelandii,nId,6726900](https://wydarzenia.interia.pl/zagranica/news-kontrowersyjne-zawody-lowieckie-dla-dzieci-w-nowej-zelandii,nId,6726900)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-04-19 11:27:44+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-kontrowersyjne-zawody-lowieckie-dla-dzieci-w-nowej-zelandii,nId,6726900"><img align="left" alt="Kontrowersyjne zawody łowieckie dla dzieci w Nowej Zelandii" src="https://i.iplsc.com/kontrowersyjne-zawody-lowieckie-dla-dzieci-w-nowej-zelandii/000H1RPCRFWBT8OQ-C321.jpg" /></a>Kto zastrzeli więcej dzikich kotów, ten zgarnie nagrodę - taką propozycję wystosowała w stosunku do dzieci nowozelandzka grupa łowiecka The North Centerbury Hunting Competition. Do wygrania było 250 dolarów nowozelandzkich. Organizacja szybko wycofała się z pomysłu, bo ten spotkał się z ostrą reakcją społeczeństwa, naukowców i organizacji prozwierzęcych. Cała sytuacja stała się też przyczynkiem do dyskusji na temat krajowej sytuacji dotyczącej populacji dzikich kotów.</p><br clear="all" />

## Zastrzel kota i wygraj. Zawody łowieckie dla dzieci w Nowej Zelandii
 - [https://wydarzenia.interia.pl/zagranica/news-zastrzel-kota-i-wygraj-zawody-lowieckie-dla-dzieci-w-nowej-z,nId,6726900](https://wydarzenia.interia.pl/zagranica/news-zastrzel-kota-i-wygraj-zawody-lowieckie-dla-dzieci-w-nowej-z,nId,6726900)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-04-19 11:27:44+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zastrzel-kota-i-wygraj-zawody-lowieckie-dla-dzieci-w-nowej-z,nId,6726900"><img align="left" alt="Zastrzel kota i wygraj. Zawody łowieckie dla dzieci w Nowej Zelandii" src="https://i.iplsc.com/zastrzel-kota-i-wygraj-zawody-lowieckie-dla-dzieci-w-nowej-z/000H1RPCRFWBT8OQ-C321.jpg" /></a>Kto zastrzeli więcej dzikich kotów, ten zgarnie nagrodę - taką propozycję wystosowała w stosunku do dzieci nowozelandzka grupa łowiecka The North Centerbury Hunting Competition. Do wygrania było 250 dolarów nowozelandzkich. Organizacja szybko wycofała się z pomysłu, bo ten spotkał się z ostrą reakcją społeczeństwa, naukowców i organizacji prozwierzęcych. Cała sytuacja stała się też przyczynkiem do dyskusji na temat krajowej sytuacji dotyczącej populacji dzikich kotów.</p><br clear="all" />

## Dziecko ominęło zabezpieczenia Białego Domu. Służby w akcji
 - [https://wydarzenia.interia.pl/zagranica/news-dziecko-ominelo-zabezpieczenia-bialego-domu-sluzby-w-akcji,nId,6726956](https://wydarzenia.interia.pl/zagranica/news-dziecko-ominelo-zabezpieczenia-bialego-domu-sluzby-w-akcji,nId,6726956)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-04-19 11:03:35+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-dziecko-ominelo-zabezpieczenia-bialego-domu-sluzby-w-akcji,nId,6726956"><img align="left" alt="Dziecko ominęło zabezpieczenia Białego Domu. Służby w akcji" src="https://i.iplsc.com/dziecko-ominelo-zabezpieczenia-bialego-domu-sluzby-w-akcji/000H1RSHN0XS6FO4-C321.jpg" /></a>&quot;Najmniejszy intruz w Białym Domu&quot; - taki zaszczytny tytuł otrzymał mały chłopiec, który przecisnął się przez ogrodzenie otaczające rezydencję prezydenta USA. Ciekawski malec postawił na nogi agentów Secret Service, a dostęp do kompleksu musiał zostać tymczasowo ograniczony.</p><br clear="all" />

