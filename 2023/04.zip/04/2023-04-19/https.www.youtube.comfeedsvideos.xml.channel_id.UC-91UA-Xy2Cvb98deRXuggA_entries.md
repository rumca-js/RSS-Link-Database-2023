# Source:Joshua Fluke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-91UA-Xy2Cvb98deRXuggA, language:en-US

## WTF! CEO Honors Employee For SELLING THEIR DOG To Return To Office
 - [https://www.youtube.com/watch?v=xEek505-6EM](https://www.youtube.com/watch?v=xEek505-6EM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-91UA-Xy2Cvb98deRXuggA
 - date published: 2023-04-19 14:53:04+00:00

❤️ Support my content because corporate sponsors rarely do! 
 https://www.patreon.com/joshuafluke

🔥 Need a resume/cover letter? Check out my templates!  
https://grindreel.com/

👊 Join the community! 
https://discord.gg/Joshuafluke

Socials🤳
https://www.tiktok.com/@joshua_fluke
https://www.instagram.com/joshuafluke/  📸
https://twitter.com/joshuafluke  🐦

📧 Email me directly!: grindreel@gmail.com
📧 Business inquiries: Joshuafluke@thoughtleaders.io  

My Gear ⚙️:  https://kit.co/JoshuaFluke

CEO praises a worker for getting rid of their dog to return to the office, an absolutely heartbreaking sacrifice which then turns into emphasizing the importance of sacrifices for success. The video covers various topics including remote work, child care challenges for single and working mothers, working mothers' struggles during the pandemic, Clearlink's values of diversity, equity, and inclusion, verbal assaults in the workplace, and the importance of constructive communication. The CEO

