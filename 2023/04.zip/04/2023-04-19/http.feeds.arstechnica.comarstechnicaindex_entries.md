# Source:ArsTechnica, URL:http://feeds.arstechnica.com/arstechnica/index/, language:en-US

## Twitter quietly edited its hateful conduct policy to drop transgender protections
 - [https://arstechnica.com/?p=1933162](https://arstechnica.com/?p=1933162)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-04-19 22:40:16+00:00

Musk says his own tweets might be labeled under new hateful conduct policy.

## Google Fi gets third rebrand in 8 years, adds free trial for eSim phones
 - [https://arstechnica.com/?p=1933098](https://arstechnica.com/?p=1933098)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-04-19 21:13:13+00:00

There's a new app coming and an option for a free phone after 24 months of service.

## Reddit will start charging AI models learning from its extremely human archives
 - [https://arstechnica.com/?p=1933080](https://arstechnica.com/?p=1933080)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-04-19 20:32:25+00:00

LLMs can no longer lurk, learn, and profit from 18 years of links and chatter.

## First teaser for Star Trek: Strange New Worlds S2 is giving us all the feels
 - [https://arstechnica.com/?p=1933065](https://arstechnica.com/?p=1933065)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-04-19 20:27:54+00:00

"The next great Age of Exploration starts with us."

## Quantum effects of D-Wave’s hardware boost its performance
 - [https://arstechnica.com/?p=1933111](https://arstechnica.com/?p=1933111)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-04-19 19:52:44+00:00

A clear performance edge, though the relevance to practical problems remains unclear.

## Meta plan to make Facebook messages more secure faces law enforcement backlash
 - [https://arstechnica.com/?p=1933073](https://arstechnica.com/?p=1933073)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-04-19 19:12:19+00:00

Global task force claims tech firms "blindfold themselves to child sexual abuse."

## Archaeologists are unlocking the secrets of Maya lime plasters and mortars
 - [https://arstechnica.com/?p=1932932](https://arstechnica.com/?p=1932932)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-04-19 18:35:56+00:00

Organic additives produced plasters with similar properties to sea urchin spines, mollusk shells.

## Dealmaster: Ars Technica readers’ favorite kitchen appliance is 25% off
 - [https://arstechnica.com/?p=1932989](https://arstechnica.com/?p=1932989)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-04-19 17:36:08+00:00

Savings on Instant Pot cookers, coffee machines, and waffle makers.

## CNBC says the Pixel Fold will launch in June for $1,700+
 - [https://arstechnica.com/?p=1932991](https://arstechnica.com/?p=1932991)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-04-19 17:32:39+00:00

We have a price and release window, so when do the live pictures start leaking?

## So long, red envelopes: DVDs-in-the-mail version of Netflix ends in September
 - [https://arstechnica.com/?p=1932979](https://arstechnica.com/?p=1932979)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-04-19 15:06:07+00:00

The company has delivered "over 5 billion" red envelopes since 1997.

## Used routers often come loaded with corporate secrets
 - [https://arstechnica.com/?p=1932973](https://arstechnica.com/?p=1932973)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-04-19 13:28:33+00:00

Over half of enterprise routers researchers bought secondhand hadn’t been wiped.

## Can an e-bike’s fat tires be offset by a fat battery?
 - [https://arstechnica.com/?p=1931954](https://arstechnica.com/?p=1931954)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-04-19 11:30:11+00:00

A well-implemented electric boost handles some of the worst of ultra-fat tires.

## Building telescopes on the Moon is becoming an achievable goal
 - [https://arstechnica.com/?p=1932920](https://arstechnica.com/?p=1932920)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-04-19 11:22:15+00:00

The current race to the Moon is opening up opportunities for lunar astronomy.

## Dealmaster: New low on 55-inch LG C2 TV and 2021 iPad Pro, and more
 - [https://arstechnica.com/?p=1932287](https://arstechnica.com/?p=1932287)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-04-19 00:26:07+00:00

These are the lowest prices we've seen on LG's 55-inch C2 and Apple's 2021 iPad Pro

