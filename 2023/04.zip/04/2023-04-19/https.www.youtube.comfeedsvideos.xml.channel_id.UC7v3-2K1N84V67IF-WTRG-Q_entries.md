# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Chevalier - Movie Review
 - [https://www.youtube.com/watch?v=9akhuvxEpXw](https://www.youtube.com/watch?v=9akhuvxEpXw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2023-04-19 13:00:08+00:00

A biopic about Joseph Bologne; the less talked about, yet more talented historical musician/swordsman prodigy. Here's my review of CHEVALIER!

#Chevalier

