# Source:InsiderBusiness, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCcyq283he07B7_KUX07mmtA, language:en-US

## Icelandic sea salt is all harvested by hand in one remote region. #Iceland #SeaSalt #SoExpensive
 - [https://www.youtube.com/watch?v=XJgfAltePqQ](https://www.youtube.com/watch?v=XJgfAltePqQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCcyq283he07B7_KUX07mmtA
 - date published: 2023-04-19 21:02:56+00:00

------------------------------------------------------

Business Insider tells you all you need to know about business, finance, tech, retail, and more.

Visit our homepage for the top stories of the day: https://www.businessinsider.com
Insider Business on Facebook: https://www.facebook.com/businessinsider
Insider Business on Instagram: https://www.instagram.com/insiderbusiness
Insider Business on Twitter: https://www.twitter.com/businessinsider
Insider Business on Snapchat: https://www.snapchat.com/discover/Business_Insider/5319643143
Insider Business on TikTok: https://www.tiktok.com/@businessinsider

## How People Profit Off Invasive Species | World Wide Waste | Insider Business
 - [https://www.youtube.com/watch?v=WEMoo1NW8d8](https://www.youtube.com/watch?v=WEMoo1NW8d8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCcyq283he07B7_KUX07mmtA
 - date published: 2023-04-19 20:40:06+00:00

Every year, invasive species cause up to $1.4 trillion worth of damage in places they weren't meant to live. Now, people are hunting harmful crabs, snakes, fish, and plants to make whiskey, wallets, and dinner. 

Intro 00:00
Pythons  00:51
Sargassum 11:22
Water Hyacinth 12:23
Green Crabs: 16:58
Lionfish 26:47
Typha 29:25
Credits 32:48

MORE WORLD WIDE WASTE VIDEOS: 
10 Surprising Things You Can Recycle | World Wide Waste | Insider Business
https://youtu.be/fakIBrTIOqI
Can Pineapple Skins Replace Soap? | World Wide Waste | Insider Business
https://youtu.be/v8QnB5q9aGo
How Mushroom Startups Use Fungi To Fight Waste | World Wide Waste | Insider Business
https://youtu.be/dtZehr9KsmM

------------------------------------------------------

#InvasiveSpecies #WorldWideWaste #InsiderBusiness 

Business Insider tells you all you need to know about business, finance, tech, retail, and more.

Visit our homepage for the top stories of the day: https://www.businessinsider.com
Insider Business on Facebook: https://www.facebook.com/businessinsider
Insider Business on Instagram: https://www.instagram.com/insiderbusiness
Insider Business on Twitter: https://www.twitter.com/businessinsider
Insider Business on Snapchat: https://www.snapchat.com/discover/Business_Insider/5319643143
Insider Business on TikTok: https://www.tiktok.com/@businessinsider

How People Profit Off Invasive Species | World Wide Waste | Insider Business

## Harvesting “mad honey” is a high-risk job. #Nepal #MadHoney #HoneyHunting
 - [https://www.youtube.com/watch?v=bZRnVKe5mxA](https://www.youtube.com/watch?v=bZRnVKe5mxA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCcyq283he07B7_KUX07mmtA
 - date published: 2023-04-19 17:02:19+00:00

------------------------------------------------------

Business Insider tells you all you need to know about business, finance, tech, retail, and more.

Visit our homepage for the top stories of the day: https://www.businessinsider.com
Insider Business on Facebook: https://www.facebook.com/businessinsider
Insider Business on Instagram: https://www.instagram.com/insiderbusiness
Insider Business on Twitter: https://www.twitter.com/businessinsider
Insider Business on Snapchat: https://www.snapchat.com/discover/Business_Insider/5319643143
Insider Business on TikTok: https://www.tiktok.com/@businessinsider

