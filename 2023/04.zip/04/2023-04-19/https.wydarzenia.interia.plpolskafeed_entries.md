# Source:Wydarzenia Interia - Polska, URL:https://wydarzenia.interia.pl/polska/feed, language:pl-PL

## "Ze zbożem będzie jak z węglem". PiS liczy, że opozycja przegrzeje temat
 - [https://wydarzenia.interia.pl/kraj/news-ze-zbozem-bedzie-jak-z-weglem-pis-liczy-ze-opozycja-przegrze,nId,6726868](https://wydarzenia.interia.pl/kraj/news-ze-zbozem-bedzie-jak-z-weglem-pis-liczy-ze-opozycja-przegrze,nId,6726868)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-04-19 11:12:28+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-ze-zbozem-bedzie-jak-z-weglem-pis-liczy-ze-opozycja-przegrze,nId,6726868"><img align="left" alt="&quot;Ze zbożem będzie jak z węglem&quot;. PiS liczy, że opozycja przegrzeje temat" src="https://i.iplsc.com/ze-zbozem-bedzie-jak-z-weglem-pis-liczy-ze-opozycja-przegrze/000H1RITB04JD964-C321.jpg" /></a>- Sytuacja jest poważna i kierownictwo partii o tym wie - mówi Interii polityk PiS, gdy pytamy o ukraińskie zboże. Rządzącym chwilowo udało się ugasić pożar. Ale opozycja grzmi, że kryzys wybuchnie na nowo, jeśli zalegające w magazynach zboże nie zostanie wywiezione przed żniwami. Tymczasem z PiS-u słychać: zobaczycie, będzie jak z węglem.</p><br clear="all" />

