# Source:Ign - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw, language:en-US

## Five Nights at Freddy's: Security Breach - Official Launch Trailer
 - [https://www.youtube.com/watch?v=ke8cYgkhVl8](https://www.youtube.com/watch?v=ke8cYgkhVl8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-04-19 23:00:18+00:00

Five Nights at Freddy's: Security Breach is available now on Nintendo Switch. Watch the trailer for a look at the creepy world of this game.

In Five Nights at Freddy’s: Security Breach, play as Gregory, a young boy who’s been trapped overnight inside of Freddy Fazbear’s Mega Pizzaplex. With the help of Freddy himself, Gregory must uncover the secrets of the Pizzaplex, learn the truth, and survive until dawn.

#IGN #FNAF #Gaming

## Call of Duty: Season 3 - Official Operator and Weapons Trailer (Modern Warfare 2 & Warzone 2.0)
 - [https://www.youtube.com/watch?v=5TXLAKvTo9g](https://www.youtube.com/watch?v=5TXLAKvTo9g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-04-19 22:30:00+00:00

Watch the latest trailer for Call of Duty: Modern Warfare 2 & Warzone 2.0 to see what to expect in Season 3, which brings a new operator, weapon blueprint bundles, and more. Season 3 is available now.

#IGN #Gaming

## The Mageseeker: A League of Legends Story Review
 - [https://www.youtube.com/watch?v=f-1vwH-AcAQ](https://www.youtube.com/watch?v=f-1vwH-AcAQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-04-19 22:02:05+00:00

The Mageseeker: A League of Legends Story reviewed by Jada Griffin on PlayStation 5. Also available on PS4, Xbox, PC, and Nintendo Switch.

The Mageseeker: A League of Legends story is another solid example of Riot Forge partnering with talented developers to bring League’s rich list of champions to life in new genres to showcase more sides of their characters. The story goes to some interesting places after a slow start, picking up steam in the second half and leading to a momentous finale. Levels are fairly straightforward and could have benefitted from additional content, like optional puzzles or bonus objectives, but the bosses and variety of abilities is enough to keep you on your toes despite some of the repetition.

#IGN #Gaming

## Cult of the Lamb - Official Relics of the Old Faith Update Trailer
 - [https://www.youtube.com/watch?v=3H5G1o-s284](https://www.youtube.com/watch?v=3H5G1o-s284)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-04-19 22:00:03+00:00

The Cult of the Lamb: Relics of the Old Faith update brings dozens of new items and relics scattered across remixed dungeons, as well as a post-game storyline, and new characters. The Cult of the Lamb: Relics of the Old Faith is available on April 24, 2023.

#IGN #Gaming

## Fast X - Official Trailer #2 (2023) Vin Diesel, Jason Mamoa, John Cena
 - [https://www.youtube.com/watch?v=crOW2SOCqaA](https://www.youtube.com/watch?v=crOW2SOCqaA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-04-19 21:33:28+00:00

Check out the new trailer for Fast X, the tenth film in the Fast & Furious saga, starring Vin Diesel, Michelle Rodriguez, Tyrese Gibson, Chris “Ludacris” Bridges, Jason Momoa, Nathalie Emmanuel, Jordana Brewster, John Cena, Jason Statham, Sung Kang, Alan Ritchson, Daniela Melchior, Scott Eastwood, with Helen Mirren, Charlize Theron, Brie Larson, and Rita Moreno.

Over many missions and against impossible odds, Dom Toretto (Vin Diesel) and his family have outsmarted, out-nerved and outdriven every foe in their path. Now, they confront the most lethal opponent they’ve ever faced: A terrifying threat emerging from the shadows of the past who’s fueled by blood revenge, and who is determined to shatter this family and destroy everything—and everyone—that Dom loves, forever. 

In 2011’s Fast Five, Dom and his crew took out nefarious Brazilian drug kingpin Hernan Reyes and decapitated his empire on a bridge in Rio De Janeiro. What they didn’t know was that Reyes’ son, Dante (Aquaman’s Jason Momoa), witnessed it all and has spent the last 12 years masterminding a plan to make Dom pay the ultimate price. 

Dante’s plot will scatter Dom’s family from Los Angeles to the catacombs of Rome, from Brazil to London and from Portugal to Antarctica. New allies will be forged and old enemies will resurface. But everything changes when Dom discovers that his own 8-year-old son (Leo Abelo Perry, Black-ish) is the ultimate target of Dante’s vengeance. 

Fast X is produced by Neal H. Moritz, Vin Diesel, Justin Lin, Jeff Kirschenbaum and Samantha Vincent. The executive producers are Joseph M. Caracciolo, Jr., David Cain, Chris Morgan, Amanda Lewis and Mark Bomback.

Fast X, directed by Louis Leterrier, opens in theaters on May 19, 2023.

#IGN #Movies #FastX

## Bomb Rush Cyberfunk - Official Release Date Announcement Trailer
 - [https://www.youtube.com/watch?v=45iSONCqMU8](https://www.youtube.com/watch?v=45iSONCqMU8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-04-19 21:00:02+00:00

Bomb Rush Cyberfunk will be available on Steam and Nintendo Switch on August 18, 2023. Watch the latest trailer to see skateboarding and more of this stylish world of the upcoming game.

#IGN #Gaming

## Animal Well - Official Nintendo Switch Trailer
 - [https://www.youtube.com/watch?v=5DiES3AjeLo](https://www.youtube.com/watch?v=5DiES3AjeLo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-04-19 20:00:02+00:00

Dive into the atmospheric pixelated world of Animal Well in this latest look at the upcoming platformer game, where you solve puzzles, escape hostile animals, and more. Animal Well will be available on Nintendo Switch in early 2024.

#IGN #Gaming

## Unrecord - Official Early Gameplay Trailer
 - [https://www.youtube.com/watch?v=IK76q13Aqt0](https://www.youtube.com/watch?v=IK76q13Aqt0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-04-19 19:00:04+00:00

Here's your look at early gameplay from Unrecord, an upcoming single-player FPS that tells the story of a tactical police officer from the perspective of his body camera. Unrecord is coming to PC. 

In Unrecord, as you work to solve a complex case, you'll need to use your tactical and detective skills to succeed.

#IGN #Unrecord #Gaming

## Godzilla x Kong: The New Empire - Official Title Reveal Teaser Trailer (2024)
 - [https://www.youtube.com/watch?v=gBMLxJfD_qI](https://www.youtube.com/watch?v=gBMLxJfD_qI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-04-19 18:20:59+00:00

Godzilla x Kong: The New Empire will transport audiences into the unexplored depths of a brave new world of spectacular new monsters, heroic adventurers, and awe-inspiring set pieces on a scale unlike anything ever seen before. This promises to be a true cinematic spectacle that demands to be seen on the biggest screens possible.
 
Godzilla x Kong: The New Empire opens in theaters and IMAX on March 15, 2024.

#IGN #Movies #Godzilla

## Zombie Apocalypse is Coming! Presented by Dead Island 2 #deadisland2 #zombies #shorts
 - [https://www.youtube.com/watch?v=4rHkT3ELsCY](https://www.youtube.com/watch?v=4rHkT3ELsCY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-04-19 18:08:07+00:00



## Final Fantasy Pixel Remaster - Official PS4 and Nintendo Switch Launch Trailer
 - [https://www.youtube.com/watch?v=zoNQcfuc4k8](https://www.youtube.com/watch?v=zoNQcfuc4k8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-04-19 17:00:37+00:00

The Final Fantasy 2D pixel remasters are available now on PlayStation 4 and Nintendo Switch. The remasters feature updated 2D pixel graphics and more.

#IGN #Gaming #FinalFantasy

## Zombie Apocalypse is Coming! Presented by Dead Island 2 #ad #deadisland2 #zombies #shorts
 - [https://www.youtube.com/watch?v=6aqJbS7VLqQ](https://www.youtube.com/watch?v=6aqJbS7VLqQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-04-19 17:00:06+00:00



## Blasphemous 2 - Official Announcement Trailer
 - [https://www.youtube.com/watch?v=_JDW-10FnrE](https://www.youtube.com/watch?v=_JDW-10FnrE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-04-19 16:59:38+00:00

The Penitent One returns in upcoming action platformer game, Blasphemous 2. Watch the announcement trailer for a peek at Blasphemous 2's unsettling world, enemies, and get ready to discover new weapons, abilities, and more when Blasphemous 2 arrives in Summer 2023 on PC, PS5, Xbox Series X/S, and Nintendo Switch.

#IGN #Gaming

## Justice League x RWBY: Super Heroes & Huntsmen, Part One - Exclusive Official Clip (2023) Nat Wolff
 - [https://www.youtube.com/watch?v=QpnYIar9EoM](https://www.youtube.com/watch?v=QpnYIar9EoM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-04-19 16:00:16+00:00

Justice League x RWBY: Super Heroes & Huntsmen, Part One finds the Justice League facing off against a new horror: adolescence! Superman, Batman, Wonder Woman, Flash, Cyborg, Green Lantern, and Vixen are surprised to find that not only have they materialized on a strange world called Remnant, but they’ve also been transformed into teenagers.

Meanwhile, the heroes of Remnant – Ruby, Weiss, Blake and Yang – find their world has been mysteriously altered. Can the combined forces of the Justice League and Team RWBY return Remnant to normal before a superpowered Grimm destroys everything they know?

In this exclusive clip, Batman (voiced by Nat Wolff) attempts to master the newfound powers that have transformed him into a literal bat-man.

Produced by Warner Bros. Animation, Rooster Teeth Animation, DC and Warner Bros. Discovery Home Entertainment, Justice League x RWBY: Super Heroes & Huntsmen, Part One, available to purchase Digitally and on 4K Ultra HD Blu-ray Combo Pack and Blu-ray on April 25, 2023.

#IGN #DC #RWBY

## Why is ChatGPT Everywhere? A Guide to the Burgeoning AI Wars
 - [https://www.youtube.com/watch?v=72CiLY-MtjY](https://www.youtube.com/watch?v=72CiLY-MtjY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-04-19 16:00:05+00:00

AI Week is still going strong, and now we're exploring why ChatGPT is taking over and how it's ignited an AI battle among big players like Microsoft and Google. Discover how these incredible AI models are transforming the way we interact with technology and how they're being integrated into Bing search and Google's Bard AI chatbot. 

But this tech isn't all sunshine and rainbows. AI comes with its own set of challenges, like accuracy and ethical concerns. We'll uncover the potential risks and discuss the current debate around AI development and its future impact on our society.

## IGN Inside Stories New Season - Official Trailer
 - [https://www.youtube.com/watch?v=5PghgYKS3dE](https://www.youtube.com/watch?v=5PghgYKS3dE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-04-19 16:00:03+00:00

Check out the trailer for the new season of IGN Inside Stories, featuring episodes about the infamous Dead Island 2 development, the NieR: Automata mod that fooled the world, and the Final Fantasy 7 fans obsessed with resurrecting Aerith. 

How Dead Island 2 Was Brought Back From the Dead - April 29 
The Nier: Automata Mod That Fooled the World - May 20
Resurrecting Aerith: The Final Fantasy 7 Fans Who Re-Wrote Fate - June 10

#IGN #Gaming #DeadIsland2

## Redfall: How Devinder Found Himself in the Middle of a Vampire Invasion | IGN First
 - [https://www.youtube.com/watch?v=KODl8JSzgQ0](https://www.youtube.com/watch?v=KODl8JSzgQ0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-04-19 15:00:21+00:00

Devinder finally gets the camera turned on him to tell his story of how he ended up in the mess of Redfall in the final of four Redfall character profiles. It turns out for him, this was a "right place at the right time" sort of situation. See that and more about how his kit can be used in this exclusive trailer. Head over to IGN.com to get a breakdown of his kit for even more backstory and details on his abilities. Stay tuned to IGN throughout the rest of the month for more exclusive looks at Redfall.

#IGN #Gaming #Redfall

## The Legend of Zelda: Tears of the Kingdom vs. Breath of the Wild Map Comparison
 - [https://www.youtube.com/watch?v=DXRFCQnJwBY](https://www.youtube.com/watch?v=DXRFCQnJwBY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-04-19 15:00:15+00:00

The Legend of Zelda: Tears of the Kingdom is just a few short weeks away, and we've seen a ton of the game at this point. Given that both games are on the same map, we took every trailer for Tears of the Kingdom and found those same locations on Breath of the Wild's map. So enjoy this huge comparison of all the known locations for Tears of the Kingdom, alongside exactly where to find them in Breath of the Wild.

## Frog and Toad - Official Trailer (2023) Nat Faxon, Kevin Michael Richardson
 - [https://www.youtube.com/watch?v=zl7r1qLG9aA](https://www.youtube.com/watch?v=zl7r1qLG9aA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-04-19 14:28:11+00:00

Check out the Frog and Toad trailer for the upcoming animated series based on the four-book series by Arnold Lobel. The voice cast includes Nat Faxon ("Our Flag Means Death," "The Connors") and Kevin Michael Richardson ("The Simpsons," "Family Guy") as Frog and Toad, as well as appearances by Ron Funches ("Trolls"), Fortune Feimster ("Good Fortune," “Kenan”), Cole Escola ("At Home with Amy Sedaris"), Aparna Nancherla ("The Great North"), John Hodgman ("Up Here"), Yvette Nicole Brown ("Disenchanted," “Act Your Age”), Stephen Tobolowsky ("The Goldbergs"), Tom Kenny ("SpongeBob SquarePants"), Selene Luna ("Coco"), Margaret Cho (“Fire Island”) and Betsy Sodaro ("Duncanville"). 

Frog is a frog. Toad is a toad. They have a lot in common… but they are also very different. Frog and Toad are best friends who know that the true secret to friendship is not only enjoying the things you have in common, but embracing the things that make you different. Since our differences are what makes us special, Frog and Toad celebrate what makes them unique! 

Rob Hoegee ("Stillwater," "Niko & the Sword of Light") serves as showrunner for the series and studio Titmouse (“Big Mouth,” “Star Trek: Lower Decks,” “The Legend of Vox Machina”) produces the animation. Hoegee executive produces alongside Adrianne Lobel, Adam Lobel and Titmouse’s Chris Prynoski (“The Legend of Vox Machina”), Shannon Prynoski (“Fairfax”), Antonio Canobbio (“Arlo the Alligator Boy”), and Ben Kalina (“Big Mouth”). 

Frog and Toad will premiere on Apple TV+ on April 28, 2023.

#IGN #TV #FrogAndToad

## Bramble: The Mountain King - The First 15 Minutes
 - [https://www.youtube.com/watch?v=ypsuYFuB5u0](https://www.youtube.com/watch?v=ypsuYFuB5u0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-04-19 14:00:41+00:00

Check out the first 15 minutes of gameplay from Bramble: The Mountain King, the grim horror adventure that's out on April 27 for PC, Nintendo Switch, PlayStation platforms, and Xbox platforms.

#IGN #Gaming

## Dying Light 2 - Exclusive 'Gut Feeling' Update Trailer
 - [https://www.youtube.com/watch?v=gyfaNs6hIQY](https://www.youtube.com/watch?v=gyfaNs6hIQY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-04-19 14:00:33+00:00

Check out the brutal trailer for the upcoming Dying Light 2 update, Gut Feeling. Featuring major combat and physics improvements, Dying Light 2 Gut Feeling introduces bloody new ways to dismember the limbs of foes, gear transmog, a new weapon crafting system, and the Viral Rush event, which runs from April 20 to May 4.

The update also launches with the new Pilgrim Outpost, where players can track community events, activate bounties, and receive Pilgrim tokens. Watch the Dying Light 2 Gut Feeling Update trailer for a look at what to expect.
 
Dying Light 2's Gut Feeling update arrives on April 20, 2023.

#IGN #Gaming #DyingLight2

## LEGO Sonic the Hedgehog Sets - Official Announcement Trailer
 - [https://www.youtube.com/watch?v=q3wQOxUwZ70](https://www.youtube.com/watch?v=q3wQOxUwZ70)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-04-19 13:23:46+00:00

Watch the trailer to see the reveal of new LEGO Sonic the Hedgehog sets, including the new Speed Sphere, Tails' workshop and the Tornado plane, and more.

#IGN #LEGO #Sonic

## Insidious: The Red Door - Exclusive Official Trailer (2023) Patrick Wilson, Rose Byrne, Ty Simpkins
 - [https://www.youtube.com/watch?v=Qu91qpYSC3A](https://www.youtube.com/watch?v=Qu91qpYSC3A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-04-19 13:00:19+00:00

In Insidious: The Red Door, the horror franchise’s original cast returns for the final chapter of the Lambert family’s terrifying saga. To put their demons to rest once and for all, Josh (Patrick Wilson) and a college-aged Dalton (Ty Simpkins) must go deeper into The Further than ever before, facing their family’s dark past and a host of new and more horrifying terrors that lurk behind the red door.

The original cast from Insidious is back with Patrick Wilson (also making his directorial debut), Ty Simpkins, Rose Byrne, Andrew Astor, and Lin Shaye. Also starring Sinclair Daniel and Hiam Abbass. Produced by Jason Blum, Oren Peli, James Wan and Leigh Whannell. The screenplay is written by Scott Teems from a story by Leigh Whannell, based on characters created by Leigh Whannell.

Insidious: The Red Door opens July 7, 2023.

#IGN #Horror

## Xenoblade Chronicles 3 Expansion Pass Vol. 4: Future Redeemed - Official Trailer
 - [https://www.youtube.com/watch?v=nQAaARICXjI](https://www.youtube.com/watch?v=nQAaARICXjI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-04-19 10:21:51+00:00

Watch the Xenoblade Chronicles 3 Future Redeemed trailer for the new original story scenario available exclusively via Wave 4 of the Xenoblade Chronicles 3 Expansion Pass. Set before the events of Xenoblade Chronicles 3, prepare to join a cast of new and familiar characters, discover fresh battle mechanics such as Unity Combo, and more.
 
Xenoblade Chronicles 3: Future Redeemed will be released on Nintendo Switch on April 25, 2023.

#IGN #Gaming #XenobladeChronicles3

## Guardians of the Galaxy Vol. 3 - Official 'I Miss You' Clip (2023) Chris Pratt, Zoe Saldana
 - [https://www.youtube.com/watch?v=lZoAhy8233M](https://www.youtube.com/watch?v=lZoAhy8233M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-04-19 04:00:30+00:00

A tender moment is interrupted in this funny clip from Marvel Studios’ Guardians of the Galaxy Vol. 3, an upcoming movie starring Chris Pratt, Zoe Saldana, Dave Bautista, Chukwudi Iwuji, Karen Gillan, Pom Klementieff, Vin Diesel, Bradley Cooper, Maria Bakalova, Sean Gunn, and Will Poulter. 

Marvel Studios’ Guardians of the Galaxy Vol. 3, written and directed by James Gunn, opens in theaters on May 5, 2023.

#IGN #Marvel #GuardiansOfTheGalaxy

## Disney Speedstorm - Official Launch Trailer
 - [https://www.youtube.com/watch?v=bXOd3Pue-NA](https://www.youtube.com/watch?v=bXOd3Pue-NA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-04-19 03:00:14+00:00

Disney Speedstorm is available now on PC and consoles. Watch the launch trailer for a peek at iconic Disney and Pixar characters, tracks, and more from this combat racing game.

#IGN #Gaming #Disney

## Peter Pan & Wendy - Official Teaser Trailer (2023) Jude Law, Ever Anderson
 - [https://www.youtube.com/watch?v=UkQj_ICAOeQ](https://www.youtube.com/watch?v=UkQj_ICAOeQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-04-19 02:00:15+00:00

Get another look at Peter Pan & Wendy in this latest teaser for the upcoming live-action film reimagining of the J. M. Barrie novel and the 1953 animated classic. The film stars Jude Law, Alexander Molony, Ever Anderson, Yara Shahidi, Alyssa Wapanatâhk, Joshua Pickering, Jacobi Jupe, Molly Parker, Alan Tudyk, and Jim Gaffigan. 

Peter Pan & Wendy introduces Wendy Darling, a young girl afraid to leave her childhood home behind, who meets Peter Pan, a boy who refuses to grow up. Alongside her brothers and a tiny fairy, Tinker Bell, she travels with Peter to the magical world of Never Land. There, she encounters an evil pirate captain, Captain Hook, and embarks on a thrilling and dangerous adventure that will change her life forever. 

Peter Pan & Wendy is directed by David Lowery from a screenplay by David Lowery & Toby Halbrooks based on the novel by J. M. Barrie and the animated film Peter Pan. The producer is Jim Whitaker, with Adam Borba, Thomas M. Hammel, and Toby Halbrooks serving as executive producers.

Peter Pan & Wendy will be available on Disney+ on April 28, 2023.

## Guardians of the Galaxy Vol. 3 - Official 'Gist of It' Clip (2023) Chris Pratt, Zoe Saldana
 - [https://www.youtube.com/watch?v=uTNdM-_NTiQ](https://www.youtube.com/watch?v=uTNdM-_NTiQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-04-19 01:30:27+00:00

Quill gives a brief history of his relationship with Gamora in this clip from Marvel Studios’ Guardians of the Galaxy Vol. 3, an upcoming movie starring Chris Pratt, Zoe Saldana, Dave Bautista, Chukwudi Iwuji, Karen Gillan, Pom Klementieff, Vin Diesel, Bradley Cooper, Maria Bakalova, Sean Gunn, and Will Poulter. 

Marvel Studios’ Guardians of the Galaxy Vol. 3, written and directed by James Gunn, opens in theaters on May 5, 2023.

#IGN #Marvel #GuardiansOfTheGalaxy

## Ant-Man and the Wasp Quantumania - Official "Making M.O.D.O.K." Behind the Scenes Clip (2023)
 - [https://www.youtube.com/watch?v=LcnX5p7-X1M](https://www.youtube.com/watch?v=LcnX5p7-X1M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-04-19 01:00:10+00:00

Check out this behind-the-scenes look at M.O.D.O.K. actor Corey Stoll as he explains the unique acting process he went through to bring his character to life for Marvel Studios' Ant-Man and the Wasp: Quantumania.

#IGN #Marvel #AntMan

## The Super Mario Bros. Movie - Official "Mario" Behind the Scenes Clip (2023) Chris Pratt
 - [https://www.youtube.com/watch?v=6iU17DcxIps](https://www.youtube.com/watch?v=6iU17DcxIps)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-04-19 00:00:02+00:00

Join star Chris Pratt for a discussion about his character, Mario, in this featurette for The Super Mario Bros. Movie.

Directed by Aaron Horvath and Michael Jelenic (collaborators on Teen Titans Go!, Teen Titans Go! To the Movies) from a screenplay by Matthew Fogel (The LEGO Movie 2: The Second Part, Minions: The Rise of Gru), The Super Mario Bros. Movie stars Chris Pratt as Mario, Anya Taylor-Joy as Princess Peach, Charlie Day as Luigi, Jack Black as Bowser, Keegan-Michael Key as Toad, Seth Rogen as Donkey Kong, Fred Armisen as Cranky Kong, Kevin Michael Richardson as Kamek and Sebastian Maniscalco as Spike.

The film is produced by Illumination founder and CEO Chris Meledandri and by Shigeru Miyamoto for Nintendo. The film is co-financed by Universal Pictures and Nintendo and released worldwide by Universal Pictures.

The Super Mario Bros. Movie is playing now in theaters.

#IGN #SuperMario

