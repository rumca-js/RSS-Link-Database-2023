# Source:Money PL, URL:https://www.money.pl/rss/, language:pl-PL

## Inwestycje w kryptowaluty. Ministerstwo Finansów ostrzega przed manipulacją
 - [https://www.money.pl/pieniadze/inwestycje-w-kryptowaluty-ministerstwo-finansow-ostrzega-przed-manipulacja-6889130068040288a.html](https://www.money.pl/pieniadze/inwestycje-w-kryptowaluty-ministerstwo-finansow-ostrzega-przed-manipulacja-6889130068040288a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-04-19 18:29:19+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/72ff7936-6e95-449d-8388-9d1cfa395ebe" width="308" /> Uwaga na oszustów, którzy wykorzystują wizerunek urzędników publicznych i zachęcają do inwestowania w kryptowaluty - ostrzegło w środę Ministerstwo Finansów. I podkreśliło, że nikt z resortu nie doradza i nie zachęca do inwestycji ani w kryptoaktywa, ani inne instrumenty finansowe.

## Polska i Chiny liderami w handlu z Ukrainą. Obroty handlowe jednak spadają
 - [https://www.money.pl/gospodarka/polska-i-chiny-liderami-w-handlu-z-ukraina-obroty-handlowe-jednak-spadaja-6889134416931424a.html](https://www.money.pl/gospodarka/polska-i-chiny-liderami-w-handlu-z-ukraina-obroty-handlowe-jednak-spadaja-6889134416931424a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-04-19 16:12:27+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/74abb23e-1bbb-4713-9c8c-104ed81c8d03" width="308" /> Polska jest największym importerem ukraińskich towarów, a Chiny najwięcej eksportują do Kijowa. Sam bilans handlowego zagranicznego Ukrainy po rosyjskiej inwazji zmniejszył się o 7 proc. - czytamy w "Rzeczpospolitej".

## Bosch zainwestuje w Polsce 1,2 mld zł. Wybuduje fabrykę pomp ciepła
 - [https://www.money.pl/gospodarka/bosch-zainwestuje-1-2-mld-zl-wybuduje-fabryke-pomp-ciepla-w-dobromierzu-6889139204594240a.html](https://www.money.pl/gospodarka/bosch-zainwestuje-1-2-mld-zl-wybuduje-fabryke-pomp-ciepla-w-dobromierzu-6889139204594240a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-04-19 15:46:08+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/f7dda55a-e5b7-4b9f-bba6-387e920cfd05" width="308" /> Niemiecki koncern Bosch zainwestuje 1,2 mld zł w budowę fabryki pomp ciepła w Dobromierzu (woj. dolnośląskie). W nowej fabryce do 2027 r. ma być zatrudnionych 500 osób – podała Grupa Bosch.

## Joe Biden i jego żona Jill ujawnili, ile zarabiają. Jest nowe zeznanie podatkowe
 - [https://www.money.pl/podatki/joe-biden-i-jego-zona-jill-ujawnili-ile-zarabiaja-jest-nowe-zeznanie-podatkowe-6889078199196224a.html](https://www.money.pl/podatki/joe-biden-i-jego-zona-jill-ujawnili-ile-zarabiaja-jest-nowe-zeznanie-podatkowe-6889078199196224a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-04-19 12:20:46+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/914ab5e0-9b14-4406-85e6-0f8c2c1bf52b" width="308" /> Joe i Jill Biden zarobili w 2022 roku w sumie 579,5 tysiąca dolarów brutto i zapłacili podatek federalny w wysokości 169,8 tysiąca dolarów - wynika z najnowszego zeznania podatkowego pary prezydenckiej.

## Związek Banków Polskich ma nowego prezesa. Krzysztof Pietraszkiewicz odchodzi po 20 latach
 - [https://www.money.pl/banki/zwiazek-bankow-polskich-ma-nowego-prezesa-krzysztof-pietraszkiewicz-odchodzi-po-20-latach-6889068033894976a.html](https://www.money.pl/banki/zwiazek-bankow-polskich-ma-nowego-prezesa-krzysztof-pietraszkiewicz-odchodzi-po-20-latach-6889068033894976a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-04-19 10:49:26+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/652dde19-c841-452d-a26e-4cdf140f13d9" width="308" /> Krzysztof Pietraszkiewicz po 20 latach przestał być prezesem Związku Banków Polskich. Jego następcą będzie Tadeusz Białek, dotychczasowy wiceprezes związku - poinformował ZBP w opublikowanym w środę komunikacie.

## Jak działa sąd arbitrażowy?
 - [https://www.money.pl/gospodarka/jak-dziala-sad-arbitrazowy-6889026016754208a.html](https://www.money.pl/gospodarka/jak-dziala-sad-arbitrazowy-6889026016754208a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-04-19 08:25:57+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/56c5f54f-fd46-4de4-a6fe-36a930afee42" width="308" /> Nad przestrzeganiem prawa w Polsce czuwa wymiar sprawiedliwości, który sprawują poszczególne sądy, w tym Sąd Najwyższy, sądy powszechne czy administracyjne i okręgowe. Istnieje również sąd arbitrażowy. Co to jest? Jak działają tego rodzaju sądy i jakie postępowania prowadzą?

## Kursy walut 19.04.2023. Środowy kurs funta, euro, dolara i franka szwajcarskiego
 - [https://www.money.pl/pieniadze/kursy-walut-19-04-2023-srodowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6888987134179872a.html](https://www.money.pl/pieniadze/kursy-walut-19-04-2023-srodowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6888987134179872a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-04-19 05:20:21+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/f25df134-ca5f-469f-b693-7773e001842b" width="308" /> Kursy walut - 19.04.2023. W środę za jednego dolara (USD) zapłacimy 4,22 zł. Cena jednego funta szterlinga (GBP) to 5,24 zł, a franka szwajcarskiego (CHF) 4,71 zł. Z kolei euro (EUR) możemy zakupić za 4,63 zł.

## Ile kosztuje funt? Kurs funta do złotego PLN/GBP 19.04.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-19-04-2023-6888982948264480a.html](https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-19-04-2023-6888982948264480a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-04-19 05:03:24+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c374eefc-9e8b-424a-aaa7-91759b47d116" width="308" /> Kurs funta szterlinga - 19.04.2023. W środę za jednego funta brytyjskiego (GBP) trzeba zapłacić 5.2409 zł.

## Ile kosztuje dolar? Kurs dolara do złotego PLN/USD 19.04.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-19-04-2023-6888982941391392a.html](https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-19-04-2023-6888982941391392a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-04-19 05:03:23+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e0ba71a8-9c02-482d-85dd-ebac5362ee3b" width="308" /> Kurs dolara - 19.04.2023. W środę za jednego dolara (USD) trzeba zapłacić 4.2196 zł.

## Ile kosztuje frank szwajcarski? Kurs franka do złotego PLN/CHF 19.04.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-19-04-2023-6888982940461568a.html](https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-19-04-2023-6888982940461568a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-04-19 05:03:22+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b1c04e3f-7bce-4c35-b03c-7a8d7b0adc65" width="308" /> Kurs franka szwajcarskiego - 19.04.2023. W środę za jednego franka (CHF) trzeba zapłacić 4.7041 zł.

## Ile kosztuje euro? Kurs euro do złotego PLN/EUR 19.04.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-19-04-2023-6888982938118656a.html](https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-19-04-2023-6888982938118656a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-04-19 05:03:21+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cf3a8300-d9c9-461f-9fbc-2f314332a28c" width="308" /> Kurs euro - 19.04.2023. W środę za jedno euro (EUR) trzeba zapłacić 4.6287 zł.

