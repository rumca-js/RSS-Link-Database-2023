# Source:Coldfusion, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A, language:en-US

## The Truth About YouTube's New CEO (Neal Mohan)
 - [https://www.youtube.com/watch?v=yOtlSM9eehc](https://www.youtube.com/watch?v=yOtlSM9eehc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4QZ_LsYcvcq7qOsOhpAX4A
 - date published: 2023-04-09 18:05:58+00:00

Get Nebula using my link for 40% off an annual subscription: https://go.nebula.tv/coldfusion

Watch the early Nebula video about the iPod here: https://nebula.tv/videos/coldfusion-the-history-of-the-ipod

