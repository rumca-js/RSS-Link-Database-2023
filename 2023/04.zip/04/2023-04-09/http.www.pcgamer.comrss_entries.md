# Source:pcgamer, URL:http://www.pcgamer.com/rss, language:en-US

## Get ready for a culinary throwdown when Cook Serve Forever launches in May
 - [https://www.pcgamer.com/get-ready-for-a-culinary-throwdown-when-cook-serve-forever-launches-in-may](https://www.pcgamer.com/get-ready-for-a-culinary-throwdown-when-cook-serve-forever-launches-in-may)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-04-09 20:40:43+00:00

A new trailer shows off the story and gives Cook Serve Forever an early access launch date.

## Here's the final gameplay trailer for Star Wars Jedi: Survivor
 - [https://www.pcgamer.com/heres-the-final-gameplay-trailer-for-star-wars-jedi-survivor](https://www.pcgamer.com/heres-the-final-gameplay-trailer-for-star-wars-jedi-survivor)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-04-09 18:35:31+00:00

Plus, a breakdown from Respawn's Stig Asmussen on Survivor's last trailer.

## Tekken 8 will have cross-play, a series first
 - [https://www.pcgamer.com/tekken-8-will-have-cross-play-a-series-first](https://www.pcgamer.com/tekken-8-will-have-cross-play-a-series-first)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-04-09 17:23:44+00:00

It'll also have rollback netcode.

## Wordle hint and answer #659: Sunday, April 9
 - [https://www.pcgamer.com/wordle-hint-answer-today-659-april-9](https://www.pcgamer.com/wordle-hint-answer-today-659-april-9)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-04-09 04:07:44+00:00

Here's a Wordle hint to help you out and the full answer if you need it.

## This immersive sim will be set in a gas station that might also be Hell
 - [https://www.pcgamer.com/this-immersive-sim-will-be-set-in-a-gas-station-that-might-also-be-hell](https://www.pcgamer.com/this-immersive-sim-will-be-set-in-a-gas-station-that-might-also-be-hell)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-04-09 00:48:41+00:00

Survival Horror plus Immersive Sim equals Ad Infernum.

