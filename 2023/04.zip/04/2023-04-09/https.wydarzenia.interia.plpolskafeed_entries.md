# Source:Wydarzenia Interia - Polska, URL:https://wydarzenia.interia.pl/polska/feed, language:pl-PL

## Premier opublikował świąteczny mem. "Internet skomentuje najlepiej"
 - [https://wydarzenia.interia.pl/kraj/news-premier-opublikowal-swiateczny-mem-internet-skomentuje-najle,nId,6707352](https://wydarzenia.interia.pl/kraj/news-premier-opublikowal-swiateczny-mem-internet-skomentuje-najle,nId,6707352)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-04-09 12:13:28+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-premier-opublikowal-swiateczny-mem-internet-skomentuje-najle,nId,6707352"><img align="left" alt="Premier opublikował świąteczny mem. &quot;Internet skomentuje najlepiej&quot;" src="https://i.iplsc.com/premier-opublikowal-swiateczny-mem-internet-skomentuje-najle/000867I9TDEV9L7B-C321.jpg" /></a>W Wielką Sobotę premier Mateusz Morawiecki opublikował na Instagramie... świąteczny mem. To dialog na jednym z internetowych komunikatorów między Jezusem a dwunastoma apostołami odnoszący się do wydarzeń sprzed dwóch tysięcy lat i Ostatniej Wieczerzy.</p><br clear="all" />

## Najdroższa Wielkanoc od 30 lat. Ogromny wzrost cen cukru, cebuli i jaj
 - [https://wydarzenia.interia.pl/kraj/news-najdrozsza-wielkanoc-od-30-lat-ogromny-wzrost-cen-cukru-cebu,nId,6699458](https://wydarzenia.interia.pl/kraj/news-najdrozsza-wielkanoc-od-30-lat-ogromny-wzrost-cen-cukru-cebu,nId,6699458)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-04-09 09:30:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-najdrozsza-wielkanoc-od-30-lat-ogromny-wzrost-cen-cukru-cebu,nId,6699458"><img align="left" alt="Najdroższa Wielkanoc od 30 lat. Ogromny wzrost cen cukru, cebuli i jaj" src="https://i.iplsc.com/najdrozsza-wielkanoc-od-30-lat-ogromny-wzrost-cen-cukru-cebu/000GZOBLKQ2YQUYE-C321.jpg" /></a>Bardzo drogie jajka, majonez i kosztowne wypieki za sprawą rosnących w zastraszającym tempie cen cukru. Za wielkanocny koszyk produktów wybranych przez Interię trzeba zapłacić 25 proc. więcej niż rok temu. - Ceny wszystkiego, co widujemy w Wielkanoc na stole, mocno poszły w górę. To będą najdroższe święta od 30 lat - zapowiadał w rozmowie z Interią Andrzej Gantner, dyrektor generalny Polskiej Federacji Producentów Żywności. Konsumenci powinni też uważać na coraz powszechniejsze zjawisko downsizingu.</p><br clear="all" />

## Przymrozki, burze, a nawet grad. Wielkanoc nie rozpieszcza
 - [https://wydarzenia.interia.pl/kraj/news-przymrozki-burze-a-nawet-grad-wielkanoc-nie-rozpieszcza,nId,6707281](https://wydarzenia.interia.pl/kraj/news-przymrozki-burze-a-nawet-grad-wielkanoc-nie-rozpieszcza,nId,6707281)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-04-09 08:01:22+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-przymrozki-burze-a-nawet-grad-wielkanoc-nie-rozpieszcza,nId,6707281"><img align="left" alt="Przymrozki, burze, a nawet grad. Wielkanoc nie rozpieszcza" src="https://i.iplsc.com/przymrozki-burze-a-nawet-grad-wielkanoc-nie-rozpieszcza/000H07S1OYRXGEM1-C321.jpg" /></a>Zachmurzenie, opady, burze, a nawet przymrozki - to czeka nas w niedzielę wielkanocną. IMGW wydał również ostrzeżenia meteorologiczne przed tymi ostatnimi. Burze możliwe są w północno-wschodniej i centralnej części Polski. Porywami wiatru punktowo mogą sięgać 50-60 km/h. Możliwy jest także drobny grad. Ostrzeżenia wysłali również drogowcy.</p><br clear="all" />

## Święta wielkanocne. Para prezydencka złożyła życzenia
 - [https://wydarzenia.interia.pl/kraj/news-swieta-wielkanocne-para-prezydencka-zlozyla-zyczenia,nId,6707290](https://wydarzenia.interia.pl/kraj/news-swieta-wielkanocne-para-prezydencka-zlozyla-zyczenia,nId,6707290)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-04-09 07:26:26+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-swieta-wielkanocne-para-prezydencka-zlozyla-zyczenia,nId,6707290"><img align="left" alt="Święta wielkanocne. Para prezydencka złożyła życzenia" src="https://i.iplsc.com/swieta-wielkanocne-para-prezydencka-zlozyla-zyczenia/000H07Y3XGGYFB89-C321.jpg" /></a>- Jak co roku, szczególnie serdeczne życzenia przekazujemy żołnierzom, funkcjonariuszom oraz pracownikom wszystkich służb i instytucji, a także przedsiębiorstw, dzięki którym święta upływają nam spokojnie - przekazał prezydent Andrzej Duda w życzeniach z okazji świąt wielkanocnych, które złożył wraz z pierwszą damą Agatą Kornhauser-Dudą.</p><br clear="all" />

## Hospicjum to nie "umieralnia". To dom, w którym się żyje
 - [https://wydarzenia.interia.pl/kraj/news-hospicjum-to-nie-umieralnia-to-dom-w-ktorym-sie-zyje,nId,6702174](https://wydarzenia.interia.pl/kraj/news-hospicjum-to-nie-umieralnia-to-dom-w-ktorym-sie-zyje,nId,6702174)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-04-09 07:00:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-hospicjum-to-nie-umieralnia-to-dom-w-ktorym-sie-zyje,nId,6702174"><img align="left" alt="Hospicjum to nie &quot;umieralnia&quot;. To dom, w którym się żyje" src="https://i.iplsc.com/hospicjum-to-nie-umieralnia-to-dom-w-ktorym-sie-zyje/000GZY3KUDCJORW6-C321.jpg" /></a>O czym marzą osoby umierające, czy można przygotować się na śmierć i jak praca w hospicjum zmienia człowieka? Na te niezwykle trudne pytania odpowiada w rozmowie z Interią Jolanta Stokłosa, prezes Towarzystwa Przyjaciół Chorych „Hospicjum im. Św. Łazarza” w Krakowie. - Rozmawiam z rodzinami osieroconymi i one mówią, że zabrakło im odwagi, żeby powiedzieć żonie czy mężowi, że ich choroba jest nieuleczalna i zapytać czego potrzebują, co jeszcze chcieliby zrobić. Na kursach dla wolontariuszy zawsze o tym mówię i proszę: jeśli za 30, 40 lat sami...</p><br clear="all" />

## Wielkanoc 2023. Jak są otwarte sklepy w Wielką Niedzielę i Poniedziałek Wielkanocny?
 - [https://wydarzenia.interia.pl/kraj/news-wielkanoc-2023-jak-sa-otwarte-sklepy-w-wielka-niedziele-i-po,nId,6699653](https://wydarzenia.interia.pl/kraj/news-wielkanoc-2023-jak-sa-otwarte-sklepy-w-wielka-niedziele-i-po,nId,6699653)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-04-09 04:30:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-wielkanoc-2023-jak-sa-otwarte-sklepy-w-wielka-niedziele-i-po,nId,6699653"><img align="left" alt="Wielkanoc 2023. Jak są otwarte sklepy w Wielką Niedzielę i Poniedziałek Wielkanocny?" src="https://i.iplsc.com/wielkanoc-2023-jak-sa-otwarte-sklepy-w-wielka-niedziele-i-po/000B0JAF48VPYPM1-C321.jpg" /></a>Wielkanoc to czas spędzany w gronie najbliższych - przy świątecznym stole oraz na spotkaniach i rodzinnych rozmowach. Co zrobić, kiedy zabraknie niektórych produktów? Które sklepy są otwarte w Niedzielę Wielkanocną? Które sklepy są otwarte w Poniedziałek Wielkanocny?</p><br clear="all" />

