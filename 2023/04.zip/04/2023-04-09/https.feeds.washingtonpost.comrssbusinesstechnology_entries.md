# Source:The Washington Post - Tech, URL:https://feeds.washingtonpost.com/rss/business/technology, language:en-US

## Amid backlash, Twitter changes NPR’s account to ‘government funded media’
 - [https://www.washingtonpost.com/media/2023/04/09/npr-musk-twitter/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/media/2023/04/09/npr-musk-twitter/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-04-09 16:12:29+00:00

Amid backlash, Twitter changes NPR’s account to ‘government funded media’.

## Doomsday to utopia: Meet AI’s rival factions
 - [https://www.washingtonpost.com/technology/2023/04/09/ai-safety-openai/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2023/04/09/ai-safety-openai/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-04-09 07:00:11+00:00

Inside Silicon Valley’s insular AI sector, a small group of strange but influential subcultures have clashed in recent months.

## The man who unleashed AI on an unsuspecting Silicon Valley
 - [https://www.washingtonpost.com/technology/2023/04/09/sam-altman-openai-chatgpt/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2023/04/09/sam-altman-openai-chatgpt/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-04-09 06:00:03+00:00

OpenAI CEO Sam Altman took the artificial intelligence company from nonprofit to kingmaker. Not everyone is happy with him.

