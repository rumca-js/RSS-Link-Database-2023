# Source:Hacker News - frontpage, URL:https://hnrss.org/frontpage, language:en-US

## Fine-tuning with LoRA: create your own avatars and styles
 - [https://www.kix.in/2023/04/07/sd-lora-finetuning/](https://www.kix.in/2023/04/07/sd-lora-finetuning/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-09 22:14:37+00:00

<p>Article URL: <a href="https://www.kix.in/2023/04/07/sd-lora-finetuning/">https://www.kix.in/2023/04/07/sd-lora-finetuning/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35506983">https://news.ycombinator.com/item?id=35506983</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## NIST AI Risk Management Framework
 - [https://www.nist.gov/itl/ai-risk-management-framework](https://www.nist.gov/itl/ai-risk-management-framework)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-09 21:08:55+00:00

<p>Article URL: <a href="https://www.nist.gov/itl/ai-risk-management-framework">https://www.nist.gov/itl/ai-risk-management-framework</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35506485">https://news.ycombinator.com/item?id=35506485</a></p>
<p>Points: 33</p>
<p># Comments: 9</p>

## Large Language Models Are Human-Level Prompt Engineers
 - [https://openreview.net/forum?id=92gvk82DE-](https://openreview.net/forum?id=92gvk82DE-)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-09 21:07:21+00:00

<p>Article URL: <a href="https://openreview.net/forum?id=92gvk82DE-">https://openreview.net/forum?id=92gvk82DE-</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35506472">https://news.ycombinator.com/item?id=35506472</a></p>
<p>Points: 21</p>
<p># Comments: 6</p>

## I think faster than light travel is possible
 - [http://backreaction.blogspot.com/2023/04/i-think-faster-than-light-travel-is.html](http://backreaction.blogspot.com/2023/04/i-think-faster-than-light-travel-is.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-09 21:02:49+00:00

<p>Article URL: <a href="http://backreaction.blogspot.com/2023/04/i-think-faster-than-light-travel-is.html">http://backreaction.blogspot.com/2023/04/i-think-faster-than-light-travel-is.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35506448">https://news.ycombinator.com/item?id=35506448</a></p>
<p>Points: 42</p>
<p># Comments: 13</p>

## Australia Is Quitting Coal in Record Time Thanks to Tesla
 - [https://www.bloomberg.com/news/features/2023-04-04/how-tesla-tsla-elon-musk-are-helping-australia-quit-coal-power](https://www.bloomberg.com/news/features/2023-04-04/how-tesla-tsla-elon-musk-are-helping-australia-quit-coal-power)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-09 20:56:42+00:00

<p>Article URL: <a href="https://www.bloomberg.com/news/features/2023-04-04/how-tesla-tsla-elon-musk-are-helping-australia-quit-coal-power">https://www.bloomberg.com/news/features/2023-04-04/how-tesla-tsla-elon-musk-are-helping-australia-quit-coal-power</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35506401">https://news.ycombinator.com/item?id=35506401</a></p>
<p>Points: 14</p>
<p># Comments: 1</p>

## OpenVMS 9.2 for x86 is finally available for hobbyists
 - [https://raymii.org/s/blog/OpenVMS_9.2_for_x86_is_finally_available_for_hobbyists.html](https://raymii.org/s/blog/OpenVMS_9.2_for_x86_is_finally_available_for_hobbyists.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-09 20:43:47+00:00

<p>Article URL: <a href="https://raymii.org/s/blog/OpenVMS_9.2_for_x86_is_finally_available_for_hobbyists.html">https://raymii.org/s/blog/OpenVMS_9.2_for_x86_is_finally_available_for_hobbyists.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35506304">https://news.ycombinator.com/item?id=35506304</a></p>
<p>Points: 19</p>
<p># Comments: 4</p>

## Who Invented Vector Clocks?
 - [https://decomposition.al/blog/2023/04/08/who-invented-vector-clocks/](https://decomposition.al/blog/2023/04/08/who-invented-vector-clocks/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-09 20:35:33+00:00

<p>Article URL: <a href="https://decomposition.al/blog/2023/04/08/who-invented-vector-clocks/">https://decomposition.al/blog/2023/04/08/who-invented-vector-clocks/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35506236">https://news.ycombinator.com/item?id=35506236</a></p>
<p>Points: 7</p>
<p># Comments: 1</p>

## A Baby GPT
 - [https://twitter.com/karpathy/status/1645115622517542913](https://twitter.com/karpathy/status/1645115622517542913)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-09 20:17:10+00:00

<p>Article URL: <a href="https://twitter.com/karpathy/status/1645115622517542913">https://twitter.com/karpathy/status/1645115622517542913</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35506069">https://news.ycombinator.com/item?id=35506069</a></p>
<p>Points: 26</p>
<p># Comments: 0</p>

## What does a research grant pay for?
 - [https://austinhenley.com/blog/grantbudget.html](https://austinhenley.com/blog/grantbudget.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-09 20:10:49+00:00

<p>Article URL: <a href="https://austinhenley.com/blog/grantbudget.html">https://austinhenley.com/blog/grantbudget.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35506009">https://news.ycombinator.com/item?id=35506009</a></p>
<p>Points: 17</p>
<p># Comments: 5</p>

## Tesla Model 2 will have 53kWh LFP battery pack
 - [https://www.arenaev.com/tesla_model_2_will_have_53_kwh_lfp_battery_pack-news-1648.php](https://www.arenaev.com/tesla_model_2_will_have_53_kwh_lfp_battery_pack-news-1648.php)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-09 20:03:08+00:00

<p>Article URL: <a href="https://www.arenaev.com/tesla_model_2_will_have_53_kwh_lfp_battery_pack-news-1648.php">https://www.arenaev.com/tesla_model_2_will_have_53_kwh_lfp_battery_pack-news-1648.php</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35505953">https://news.ycombinator.com/item?id=35505953</a></p>
<p>Points: 31</p>
<p># Comments: 16</p>

## Ambry: LinkedIn’s Scalable Geo-Distributed Object Store
 - [https://www.micahlerner.com/2023/03/28/ambry-linkedins-scalable-geo-distributed-object-store.html](https://www.micahlerner.com/2023/03/28/ambry-linkedins-scalable-geo-distributed-object-store.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-09 19:44:12+00:00

<p>Article URL: <a href="https://www.micahlerner.com/2023/03/28/ambry-linkedins-scalable-geo-distributed-object-store.html">https://www.micahlerner.com/2023/03/28/ambry-linkedins-scalable-geo-distributed-object-store.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35505778">https://news.ycombinator.com/item?id=35505778</a></p>
<p>Points: 12</p>
<p># Comments: 3</p>

## Godaddy does not allow logins from Firefox and Linux
 - [https://imgur.com/a/8Hx39hy](https://imgur.com/a/8Hx39hy)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-09 19:42:54+00:00

<p>Article URL: <a href="https://imgur.com/a/8Hx39hy">https://imgur.com/a/8Hx39hy</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35505766">https://news.ycombinator.com/item?id=35505766</a></p>
<p>Points: 10</p>
<p># Comments: 8</p>

## Sailcargo
 - [https://www.sailcargo.inc](https://www.sailcargo.inc)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-09 19:28:34+00:00

<p>Article URL: <a href="https://www.sailcargo.inc">https://www.sailcargo.inc</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35505647">https://news.ycombinator.com/item?id=35505647</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## UnicodePlots
 - [https://github.com/JuliaPlots/UnicodePlots.jl](https://github.com/JuliaPlots/UnicodePlots.jl)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-09 19:22:07+00:00

<p>Article URL: <a href="https://github.com/JuliaPlots/UnicodePlots.jl">https://github.com/JuliaPlots/UnicodePlots.jl</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35505591">https://news.ycombinator.com/item?id=35505591</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## Street Fighting Engineers vs Martial Arts Engineers
 - [https://ravitejakanta.substack.com/p/the-2-breeds-of-10x-engineers](https://ravitejakanta.substack.com/p/the-2-breeds-of-10x-engineers)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-09 19:10:54+00:00

<p>Article URL: <a href="https://ravitejakanta.substack.com/p/the-2-breeds-of-10x-engineers">https://ravitejakanta.substack.com/p/the-2-breeds-of-10x-engineers</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35505518">https://news.ycombinator.com/item?id=35505518</a></p>
<p>Points: 5</p>
<p># Comments: 1</p>

## Spherical Tokamak Achieves Crucial Plasma Temperatures
 - [https://www.eetimes.com/spherical-tokamak-achieves-crucial-plasma-temperatures/](https://www.eetimes.com/spherical-tokamak-achieves-crucial-plasma-temperatures/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-09 18:49:48+00:00

<p>Article URL: <a href="https://www.eetimes.com/spherical-tokamak-achieves-crucial-plasma-temperatures/">https://www.eetimes.com/spherical-tokamak-achieves-crucial-plasma-temperatures/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35505342">https://news.ycombinator.com/item?id=35505342</a></p>
<p>Points: 9</p>
<p># Comments: 2</p>

## The One Thing I Can’t Stand About Teaching English in Japan (2019)
 - [https://geekstravelinjapan.wordpress.com/2019/03/10/the-one-thing-i-cant-stand-about-teaching-english-in-japan/](https://geekstravelinjapan.wordpress.com/2019/03/10/the-one-thing-i-cant-stand-about-teaching-english-in-japan/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-09 18:02:22+00:00

<p>Article URL: <a href="https://geekstravelinjapan.wordpress.com/2019/03/10/the-one-thing-i-cant-stand-about-teaching-english-in-japan/">https://geekstravelinjapan.wordpress.com/2019/03/10/the-one-thing-i-cant-stand-about-teaching-english-in-japan/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35504989">https://news.ycombinator.com/item?id=35504989</a></p>
<p>Points: 15</p>
<p># Comments: 3</p>

## The Interoperable Europe Act Needs a “Free Software First” Approach
 - [https://fsfe.org/news/2023/news-20230323-02.en.html](https://fsfe.org/news/2023/news-20230323-02.en.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-09 17:37:56+00:00

<p>Article URL: <a href="https://fsfe.org/news/2023/news-20230323-02.en.html">https://fsfe.org/news/2023/news-20230323-02.en.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35504786">https://news.ycombinator.com/item?id=35504786</a></p>
<p>Points: 27</p>
<p># Comments: 0</p>

## Of the top cloud companies, 48 have laid off staff
 - [https://yarn.warntracker.com/cloud-100](https://yarn.warntracker.com/cloud-100)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-09 17:15:23+00:00

<p>Article URL: <a href="https://yarn.warntracker.com/cloud-100">https://yarn.warntracker.com/cloud-100</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35504590">https://news.ycombinator.com/item?id=35504590</a></p>
<p>Points: 7</p>
<p># Comments: 3</p>

## C Rival 'Zig' Cracks Tiobe Index Top
 - [https://developers.slashdot.org/story/23/04/09/008243/c-rival-zig-cracks-tiobe-index-top-50-go-remains-in-top-10](https://developers.slashdot.org/story/23/04/09/008243/c-rival-zig-cracks-tiobe-index-top-50-go-remains-in-top-10)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-09 17:12:04+00:00

<p>Article URL: <a href="https://developers.slashdot.org/story/23/04/09/008243/c-rival-zig-cracks-tiobe-index-top-50-go-remains-in-top-10">https://developers.slashdot.org/story/23/04/09/008243/c-rival-zig-cracks-tiobe-index-top-50-go-remains-in-top-10</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35504558">https://news.ycombinator.com/item?id=35504558</a></p>
<p>Points: 20</p>
<p># Comments: 9</p>

## The LLama Effect: Leak Sparked a Series of Open Source Alternatives to ChatGPT
 - [https://thesequence.substack.com/p/the-llama-effect-how-an-accidental](https://thesequence.substack.com/p/the-llama-effect-how-an-accidental)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-09 16:57:31+00:00

<p>Article URL: <a href="https://thesequence.substack.com/p/the-llama-effect-how-an-accidental">https://thesequence.substack.com/p/the-llama-effect-how-an-accidental</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35504428">https://news.ycombinator.com/item?id=35504428</a></p>
<p>Points: 46</p>
<p># Comments: 5</p>

## Closing a Stale SSH Connection
 - [https://davidisaksson.dev/posts/closing-stale-ssh-connections/](https://davidisaksson.dev/posts/closing-stale-ssh-connections/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-09 16:54:04+00:00

<p>Article URL: <a href="https://davidisaksson.dev/posts/closing-stale-ssh-connections/">https://davidisaksson.dev/posts/closing-stale-ssh-connections/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35504402">https://news.ycombinator.com/item?id=35504402</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## Inline in Rust
 - [https://matklad.github.io/2021/07/09/inline-in-rust.html](https://matklad.github.io/2021/07/09/inline-in-rust.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-09 16:48:15+00:00

<p>Article URL: <a href="https://matklad.github.io/2021/07/09/inline-in-rust.html">https://matklad.github.io/2021/07/09/inline-in-rust.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35504351">https://news.ycombinator.com/item?id=35504351</a></p>
<p>Points: 19</p>
<p># Comments: 0</p>

## Lawyers cough up $200k after health data stolen in Microsoft Exchange pillaging
 - [https://www.theregister.com/2023/03/27/nyc_lawyers_security_data/](https://www.theregister.com/2023/03/27/nyc_lawyers_security_data/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-09 16:34:57+00:00

<p>Article URL: <a href="https://www.theregister.com/2023/03/27/nyc_lawyers_security_data/">https://www.theregister.com/2023/03/27/nyc_lawyers_security_data/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35504249">https://news.ycombinator.com/item?id=35504249</a></p>
<p>Points: 12</p>
<p># Comments: 4</p>

## Permafrost engine – An OpenGL RTS game engine written in C
 - [https://github.com/eduard-permyakov/permafrost-engine](https://github.com/eduard-permyakov/permafrost-engine)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-09 16:12:19+00:00

<p>Article URL: <a href="https://github.com/eduard-permyakov/permafrost-engine">https://github.com/eduard-permyakov/permafrost-engine</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35504053">https://news.ycombinator.com/item?id=35504053</a></p>
<p>Points: 11</p>
<p># Comments: 1</p>

## Swin Transformer: Hierarchical Vision Transformer Using Shifted Windows
 - [https://arxiv.org/abs/2103.14030](https://arxiv.org/abs/2103.14030)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-09 16:12:18+00:00

<p>Article URL: <a href="https://arxiv.org/abs/2103.14030">https://arxiv.org/abs/2103.14030</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35504052">https://news.ycombinator.com/item?id=35504052</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## Flatcar Container Linux
 - [https://www.flatcar.org/](https://www.flatcar.org/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-09 15:57:24+00:00

<p>Article URL: <a href="https://www.flatcar.org/">https://www.flatcar.org/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35503928">https://news.ycombinator.com/item?id=35503928</a></p>
<p>Points: 33</p>
<p># Comments: 8</p>

## When should a decision be fast, or slow?
 - [https://longform.asmartbear.com/decisions-fast-slow/](https://longform.asmartbear.com/decisions-fast-slow/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-09 15:56:18+00:00

<p>Article URL: <a href="https://longform.asmartbear.com/decisions-fast-slow/">https://longform.asmartbear.com/decisions-fast-slow/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35503916">https://news.ycombinator.com/item?id=35503916</a></p>
<p>Points: 24</p>
<p># Comments: 0</p>

## RISC-V Bytes: Exploring a Custom ESP32 Bootloader
 - [https://danielmangum.com/posts/risc-v-bytes-exploring-custom-esp32-bootloader/](https://danielmangum.com/posts/risc-v-bytes-exploring-custom-esp32-bootloader/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-09 15:50:03+00:00

<p>Article URL: <a href="https://danielmangum.com/posts/risc-v-bytes-exploring-custom-esp32-bootloader/">https://danielmangum.com/posts/risc-v-bytes-exploring-custom-esp32-bootloader/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35503855">https://news.ycombinator.com/item?id=35503855</a></p>
<p>Points: 25</p>
<p># Comments: 1</p>

## Two Types of Software Engineers
 - [https://registerspill.thorstenball.com/p/two-types-of-software-engineers](https://registerspill.thorstenball.com/p/two-types-of-software-engineers)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-09 15:43:01+00:00

<p>Article URL: <a href="https://registerspill.thorstenball.com/p/two-types-of-software-engineers">https://registerspill.thorstenball.com/p/two-types-of-software-engineers</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35503784">https://news.ycombinator.com/item?id=35503784</a></p>
<p>Points: 86</p>
<p># Comments: 65</p>

## Russia’s New Mystery Shortwave Station
 - [https://hackaday.com/2023/04/08/russias-new-mystery-shortwave-station/](https://hackaday.com/2023/04/08/russias-new-mystery-shortwave-station/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-09 15:38:16+00:00

<p>Article URL: <a href="https://hackaday.com/2023/04/08/russias-new-mystery-shortwave-station/">https://hackaday.com/2023/04/08/russias-new-mystery-shortwave-station/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35503743">https://news.ycombinator.com/item?id=35503743</a></p>
<p>Points: 25</p>
<p># Comments: 3</p>

## The first game ‘Easter eggs’ were an act of corporate rebellion
 - [https://thehustle.co/the-first-easter-eggs-were-an-act-of-corporate-rebellion/](https://thehustle.co/the-first-easter-eggs-were-an-act-of-corporate-rebellion/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-09 14:52:16+00:00

<p>Article URL: <a href="https://thehustle.co/the-first-easter-eggs-were-an-act-of-corporate-rebellion/">https://thehustle.co/the-first-easter-eggs-were-an-act-of-corporate-rebellion/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35503260">https://news.ycombinator.com/item?id=35503260</a></p>
<p>Points: 18</p>
<p># Comments: 3</p>

## Exploring the Gameboy Memory Bank Controller (2020)
 - [https://b13rg.github.io/Gameboy-MBC-Analysis/](https://b13rg.github.io/Gameboy-MBC-Analysis/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-09 14:50:16+00:00

<p>Article URL: <a href="https://b13rg.github.io/Gameboy-MBC-Analysis/">https://b13rg.github.io/Gameboy-MBC-Analysis/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35503236">https://news.ycombinator.com/item?id=35503236</a></p>
<p>Points: 10</p>
<p># Comments: 0</p>

## Apple Continues Efforts to Keep Retail Stores from Unionizing
 - [https://www.bloomberg.com/news/newsletters/2023-04-09/apple-aapl-continues-efforts-to-keep-retail-stores-from-unionizing-lg9gjdx2](https://www.bloomberg.com/news/newsletters/2023-04-09/apple-aapl-continues-efforts-to-keep-retail-stores-from-unionizing-lg9gjdx2)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-09 14:47:55+00:00

<p>Article URL: <a href="https://www.bloomberg.com/news/newsletters/2023-04-09/apple-aapl-continues-efforts-to-keep-retail-stores-from-unionizing-lg9gjdx2">https://www.bloomberg.com/news/newsletters/2023-04-09/apple-aapl-continues-efforts-to-keep-retail-stores-from-unionizing-lg9gjdx2</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35503210">https://news.ycombinator.com/item?id=35503210</a></p>
<p>Points: 105</p>
<p># Comments: 23</p>

## Irregular Expressions
 - [https://tavianator.com/2023/irregex.html](https://tavianator.com/2023/irregex.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-09 14:35:19+00:00

<p>Article URL: <a href="https://tavianator.com/2023/irregex.html">https://tavianator.com/2023/irregex.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35503089">https://news.ycombinator.com/item?id=35503089</a></p>
<p>Points: 33</p>
<p># Comments: 11</p>

## When do you need Chain-of-Thought Prompting for ChatGPT?
 - [https://arxiv.org/abs/2304.03262](https://arxiv.org/abs/2304.03262)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-09 14:30:13+00:00

<p>Article URL: <a href="https://arxiv.org/abs/2304.03262">https://arxiv.org/abs/2304.03262</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35503044">https://news.ycombinator.com/item?id=35503044</a></p>
<p>Points: 18</p>
<p># Comments: 1</p>

## TIWiFiModem: Take your TI-83 Plus online [video]
 - [https://www.youtube.com/watch?v=eg_J6N9MSCY](https://www.youtube.com/watch?v=eg_J6N9MSCY)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-09 14:20:41+00:00

<p>Article URL: <a href="https://www.youtube.com/watch?v=eg_J6N9MSCY">https://www.youtube.com/watch?v=eg_J6N9MSCY</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35502956">https://news.ycombinator.com/item?id=35502956</a></p>
<p>Points: 24</p>
<p># Comments: 7</p>

## Modular Errors in Rust
 - [https://sabrinajewson.org/blog/errors](https://sabrinajewson.org/blog/errors)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-09 14:09:19+00:00

<p>Article URL: <a href="https://sabrinajewson.org/blog/errors">https://sabrinajewson.org/blog/errors</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35502874">https://news.ycombinator.com/item?id=35502874</a></p>
<p>Points: 57</p>
<p># Comments: 15</p>

## From Deep to Long Learning
 - [https://hazyresearch.stanford.edu/blog/2023-03-27-long-learning](https://hazyresearch.stanford.edu/blog/2023-03-27-long-learning)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-09 12:41:38+00:00

<p>Article URL: <a href="https://hazyresearch.stanford.edu/blog/2023-03-27-long-learning">https://hazyresearch.stanford.edu/blog/2023-03-27-long-learning</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35502187">https://news.ycombinator.com/item?id=35502187</a></p>
<p>Points: 244</p>
<p># Comments: 71</p>

## Interview with Andrew Kelley (Zig Creator) (2021)
 - [https://corecursive.com/067-zig-with-andrew-kelley/](https://corecursive.com/067-zig-with-andrew-kelley/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-09 12:36:17+00:00

<p>Article URL: <a href="https://corecursive.com/067-zig-with-andrew-kelley/">https://corecursive.com/067-zig-with-andrew-kelley/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35502151">https://news.ycombinator.com/item?id=35502151</a></p>
<p>Points: 89</p>
<p># Comments: 8</p>

## EY gets banned from new audit business in Germany
 - [https://www.economist.com/business/2023/04/05/ey-gets-banned-from-new-audit-business-in-germany](https://www.economist.com/business/2023/04/05/ey-gets-banned-from-new-audit-business-in-germany)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-09 12:04:37+00:00

<p>Article URL: <a href="https://www.economist.com/business/2023/04/05/ey-gets-banned-from-new-audit-business-in-germany">https://www.economist.com/business/2023/04/05/ey-gets-banned-from-new-audit-business-in-germany</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35501937">https://news.ycombinator.com/item?id=35501937</a></p>
<p>Points: 201</p>
<p># Comments: 138</p>

## Float Health (YC W22) Is Hiring UI/UX Designer
 - [https://news.ycombinator.com/item?id=35501918](https://news.ycombinator.com/item?id=35501918)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-04-09 12:01:56+00:00

<p>About Float<p>Float Health is a YC W22 alum, seed stage, health-tech startup looking for a UI/UX Designer. Float brings a nurse to your home when you're sick. We are building a marketplace to move more healthcare from the hospital to the home, where it is easier, safer and cheaper.<p>We are currently seeking a UI/UX Designer. If you can design beautiful mobile and web applications, we'd love to hear from you. Ultimately, you’ll create both functional and appealing features that address our company and user needs.<p>You would have a lot of responsibility and also an amazing opportunity at a fast-growing YC-backed company.<p>About you
-Experience in creating design systems from scratch
-Experience with responsive design
-Attention to detail that's borderline OCD
-Keen eye for clean and consistent UI elements
-High level of understanding of HTML, CSS, JavaScript and front-end design
-Growth mindset to execute quickly
-Excellent communication, problem-solving and prioritizing skills
-Self-driven, ability to lead various product initiatives
-Strong sense of ownership and accountability
-Quick learner and adaptable to a fast-growing startup
-Excited to join a team that’s changing the healthcare industry<p>Responsibilities
-Defining, maintaining and developing the design and user experience across mobile and desktop
-Crafting well-polished, efficient and functional user experiences from early concept to final delivery
-Working with the founding team to ensure the design aligns with the company's brand voice and tone
-Working with cross-functional teams to specify the strategic direction of the product experience and ensure user needs are supported throughout
-Championing user-centric design culture, values and principles
-Creating illustrations and iconography as needed to enhance the user experience<p>Requirements
-An online portfolio showcasing abilities across user experience, user interface, graphic design, web design and responsive design
-BS or MS in Graphic or Web Design
-3+ years of professional work experience<p>Interested? Send your CV & link to portfolio to lauren@float.health</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=35501918">https://news.ycombinator.com/item?id=35501918</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

