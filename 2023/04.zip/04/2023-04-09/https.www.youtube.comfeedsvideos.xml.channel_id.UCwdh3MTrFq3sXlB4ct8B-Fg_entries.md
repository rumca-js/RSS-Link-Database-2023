# Source:Warhammer, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg, language:en-US

## This Week In Warhammer – The Lion is Back
 - [https://www.youtube.com/watch?v=k-AbhRYQBLE](https://www.youtube.com/watch?v=k-AbhRYQBLE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg
 - date published: 2023-04-09 17:00:24+00:00

The Lion is back, Arks of Omen reaches its epic conclusion, and more – check out this week's Warhammer highlights. https://bit.ly/3mfohGE

Don't forget to like, share and subscribe and to ring the bell to make sure you keep up to date with all our latest videos!

