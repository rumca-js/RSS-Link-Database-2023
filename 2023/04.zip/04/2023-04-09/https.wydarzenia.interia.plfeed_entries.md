# Source:Wydarzenia Interia, URL:https://wydarzenia.interia.pl/feed, language:pl-PL

## Niemcy: Zwłoki rodzeństwa w mieszkaniu. Aresztowano kobietę
 - [https://wydarzenia.interia.pl/zagranica/news-niemcy-zwloki-rodzenstwa-w-mieszkaniu-aresztowano-kobiete,nId,6707469](https://wydarzenia.interia.pl/zagranica/news-niemcy-zwloki-rodzenstwa-w-mieszkaniu-aresztowano-kobiete,nId,6707469)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-09 20:52:23+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niemcy-zwloki-rodzenstwa-w-mieszkaniu-aresztowano-kobiete,nId,6707469"><img align="left" alt="Niemcy: Zwłoki rodzeństwa w mieszkaniu. Aresztowano kobietę " src="https://i.iplsc.com/niemcy-zwloki-rodzenstwa-w-mieszkaniu-aresztowano-kobiete/000FNQ0HIX77GLPS-C321.jpg" /></a>Makabryczne odkrycie w miejscowości  Hockenheim (Badenia-Wirtembergia). W mieszkaniu znaleziono ciała dwóch martwych chłopców. Prokuratura potwierdziła, że dzieci to bracia w wieku siedmiu i dziewięciu lat. Aresztowano jedną osobę. 


</p><br clear="all" />

## "Popisy" Miedwiediewa doczekały się odpowiedzi z Polski. "Jak zdarta płyta"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-popisy-miedwiediewa-doczekaly-sie-odpowiedzi-z-polski-jak-zd,nId,6707450](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-popisy-miedwiediewa-doczekaly-sie-odpowiedzi-z-polski-jak-zd,nId,6707450)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-09 20:45:39+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-popisy-miedwiediewa-doczekaly-sie-odpowiedzi-z-polski-jak-zd,nId,6707450"><img align="left" alt="&quot;Popisy&quot; Miedwiediewa doczekały się odpowiedzi z Polski. &quot;Jak zdarta płyta&quot;" src="https://i.iplsc.com/popisy-miedwiediewa-doczekaly-sie-odpowiedzi-z-polski-jak-zd/000GPOKIB5SKEDM3-C321.jpg" /></a>Stanisław Żaryn, pełnomocnik polskiego rządu ds. bezpieczeństwa przestrzeni informacyjnej, odniósł się na Twitterze do tekstu Dmitrija Miedwiediewa. Były prezydent Rosji stwierdził, że &quot;Ukraina nie jest nikomu potrzebna&quot; i przedstawiał argumenty, które miały udowodnić jego tezę. Pisał również o tym, że Polska &quot;planuje Anschluss zachodniej Ukrainy&quot;. &quot;On jest jak zdarta płyta&quot; - napisał Żaryn. </p><br clear="all" />

## Tajemnicze interesy Grupy Wagnera w Turcji. Rząd odmawia komentarza
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-tajemnicze-interesy-grupy-wagnera-w-turcji-rzad-odmawia-kome,nId,6707462](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-tajemnicze-interesy-grupy-wagnera-w-turcji-rzad-odmawia-kome,nId,6707462)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-09 20:20:26+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-tajemnicze-interesy-grupy-wagnera-w-turcji-rzad-odmawia-kome,nId,6707462"><img align="left" alt="Tajemnicze interesy Grupy Wagnera w Turcji. Rząd odmawia komentarza" src="https://i.iplsc.com/tajemnicze-interesy-grupy-wagnera-w-turcji-rzad-odmawia-kome/000H0A0DIP27VSCA-C321.jpg" /></a>Najemnicy Grupy Wagnera próbowali kupić broń w Turcji - informuje &quot;Washington Post&quot;, powołując się na dokumenty wywiadu USA, których treść została ujawniona w mediach społecznościowych. 
</p><br clear="all" />

## Nowa fala migracyjna. Niemal tysiąc osób dotarło w ciągu jednego dnia na włoską wyspę
 - [https://wydarzenia.interia.pl/zagranica/news-nowa-fala-migracyjna-niemal-tysiac-osob-dotarlo-w-ciagu-jedn,nId,6707463](https://wydarzenia.interia.pl/zagranica/news-nowa-fala-migracyjna-niemal-tysiac-osob-dotarlo-w-ciagu-jedn,nId,6707463)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-09 20:05:41+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-nowa-fala-migracyjna-niemal-tysiac-osob-dotarlo-w-ciagu-jedn,nId,6707463"><img align="left" alt="Nowa fala migracyjna. Niemal tysiąc osób dotarło w ciągu jednego dnia na włoską wyspę" src="https://i.iplsc.com/nowa-fala-migracyjna-niemal-tysiac-osob-dotarlo-w-ciagu-jedn/000H09ZRRO6SI7HV-C321.jpg" /></a>Prawie tysiąc migrantów dotarło w niedzielę na włoską wyspę Lampedusa. Przybyli oni na pokładzie 26 łodzi. Całkowicie przepełniony jest tamtejszy tymczasowy ośrodek dla migrantów.</p><br clear="all" />

## USA: Uczeń umierał w czasie przerwy. Nauczyciele myśleli, że udaje martwego. Rodzice składają pozew
 - [https://wydarzenia.interia.pl/zagranica/news-usa-uczen-umieral-w-czasie-przerwy-nauczyciele-mysleli-ze-ud,nId,6707431](https://wydarzenia.interia.pl/zagranica/news-usa-uczen-umieral-w-czasie-przerwy-nauczyciele-mysleli-ze-ud,nId,6707431)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-09 19:17:15+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-usa-uczen-umieral-w-czasie-przerwy-nauczyciele-mysleli-ze-ud,nId,6707431"><img align="left" alt="USA: Uczeń umierał w czasie przerwy. Nauczyciele myśleli, że udaje martwego. Rodzice składają pozew" src="https://i.iplsc.com/usa-uczen-umieral-w-czasie-przerwy-nauczyciele-mysleli-ze-ud/000H09SQ8NL5UW0A-C321.jpg" /></a>Pięcioletni Romeo zmarł podczas zabawy na szkolnym placu zabaw. Dziecko leżało na ziemi przez prawie 10 minut. W tym czasie nauczyciele nie reagowali, ponieważ myśleli, że chłopiec udaje martwego. Rodzice zmarłego pięciolatka oskarżają szkołę i miasto o zaniedbania. </p><br clear="all" />

## "Gwałciciel z Facebooka" w rękach policji. Czeka go ekstradycja
 - [https://wydarzenia.interia.pl/zagranica/news-gwalciciel-z-facebooka-w-rekach-policji-czeka-go-ekstradycja,nId,6707420](https://wydarzenia.interia.pl/zagranica/news-gwalciciel-z-facebooka-w-rekach-policji-czeka-go-ekstradycja,nId,6707420)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-09 18:42:48+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-gwalciciel-z-facebooka-w-rekach-policji-czeka-go-ekstradycja,nId,6707420"><img align="left" alt="&quot;Gwałciciel z Facebooka&quot; w rękach policji. Czeka go ekstradycja " src="https://i.iplsc.com/gwalciciel-z-facebooka-w-rekach-policji-czeka-go-ekstradycja/000H09MN9MCWHO01-C321.jpg" /></a>35-letni morderca znany jako &quot;gwałciciel z Facebooka&quot;, który sfingował swoją śmierć, aby uciec z więzienia, został aresztowany w Tanzanii. Obława na mężczyznę trwała dwa tygodnie. Teraz rozpoczęto procedurę ekstradycji. W niedzielę do Tanzanii udali się południowoafrykańscy urzędnicy, aby przejąć Thaba Bestera. </p><br clear="all" />

## Macron wbija szpilkę USA. "Europa musi się uniezależnić i nie dać się wciągnąć w konflikt"
 - [https://wydarzenia.interia.pl/zagranica/news-macron-wbija-szpilke-usa-europa-musi-sie-uniezaleznic-i-nie-,nId,6707425](https://wydarzenia.interia.pl/zagranica/news-macron-wbija-szpilke-usa-europa-musi-sie-uniezaleznic-i-nie-,nId,6707425)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-09 18:26:29+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-macron-wbija-szpilke-usa-europa-musi-sie-uniezaleznic-i-nie-,nId,6707425"><img align="left" alt="Macron wbija szpilkę USA. &quot;Europa musi się uniezależnić i nie dać się wciągnąć w konflikt&quot;" src="https://i.iplsc.com/macron-wbija-szpilke-usa-europa-musi-sie-uniezaleznic-i-nie/000H09QHC70DXMBQ-C321.jpg" /></a>Prezydent Francji Emmanuel Macron w drodze powrotnej z Chin powiedział, że Europa musi się oprzeć presji, by stać się &quot;naśladowcą Ameryki&quot;. Stwierdził także, że Europa nie powinna dawać się wciągać w konflikty, które &quot;nie są nasze&quot;. Macron rozmawiał na pokładzie samolotu z dziennikarzami, między innymi Politico.</p><br clear="all" />

## Bild: Wołodymyr Zełenski w maju odwiedzi Niemcy. Scholz wręczy mu nagrodę
 - [https://wydarzenia.interia.pl/zagranica/news-bild-wolodymyr-zelenski-w-maju-odwiedzi-niemcy-scholz-wreczy,nId,6707418](https://wydarzenia.interia.pl/zagranica/news-bild-wolodymyr-zelenski-w-maju-odwiedzi-niemcy-scholz-wreczy,nId,6707418)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-09 17:29:44+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-bild-wolodymyr-zelenski-w-maju-odwiedzi-niemcy-scholz-wreczy,nId,6707418"><img align="left" alt="Bild: Wołodymyr Zełenski w maju odwiedzi Niemcy. Scholz wręczy mu nagrodę" src="https://i.iplsc.com/bild-wolodymyr-zelenski-w-maju-odwiedzi-niemcy-scholz-wreczy/000H09LLXAKY87D7-C321.jpg" /></a>Prezydent Ukrainy Wołodymyr Zełenski w maju przyjedzie z wizytą do Niemiec. W Akwizgranie kanclerz Niemiec Olaf Scholz wręczy mu Nagrodę Karola Wielkiego, czyli prestiżową niemiecką nagrodę, za zasługi na rzecz pokoju - informuje &quot;Bild&quot;. Wizyta prezydenta Ukrainy ma &quot;otworzyć nowy rozdział w przyjaźni między krajami&quot;. Tymczasem, w Niemczech wrze po protestach, w których demonstranci domagali się wstrzymania dostaw broni do Ukrainy. </p><br clear="all" />

## USA: Po 17 latach małżeństwa dowiedzieli się, że są kuzynami. "Chciałam rozwodu"
 - [https://wydarzenia.interia.pl/zagranica/news-usa-po-17-latach-malzenstwa-dowiedzieli-sie-ze-sa-kuzynami-c,nId,6707411](https://wydarzenia.interia.pl/zagranica/news-usa-po-17-latach-malzenstwa-dowiedzieli-sie-ze-sa-kuzynami-c,nId,6707411)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-09 17:05:08+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-usa-po-17-latach-malzenstwa-dowiedzieli-sie-ze-sa-kuzynami-c,nId,6707411"><img align="left" alt="USA: Po 17 latach małżeństwa dowiedzieli się, że są kuzynami. &quot;Chciałam rozwodu&quot; " src="https://i.iplsc.com/usa-po-17-latach-malzenstwa-dowiedzieli-sie-ze-sa-kuzynami-c/000H09I7UBYWOQN4-C321.jpg" /></a>Małżeństwo z Kolorado w USA przypadkiem dowiedziało się, że jest... kuzynostwem. Celina Quinones razem ze swoim mężem wychowują trojkę dzieci. Para, chcąc dowiedzieć się więcej o swoim drzewie genealogicznym zdecydowała się na wykonanie testów DNA. Wynik badań zaskoczył małżonków.  </p><br clear="all" />

## Trzebinia: Powstało kolejne zapadlisko. Ma osiem metrów głębokości
 - [https://wydarzenia.interia.pl/malopolskie/news-trzebinia-powstalo-kolejne-zapadlisko-ma-osiem-metrow-glebok,nId,6707415](https://wydarzenia.interia.pl/malopolskie/news-trzebinia-powstalo-kolejne-zapadlisko-ma-osiem-metrow-glebok,nId,6707415)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-09 16:48:37+00:00

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-trzebinia-powstalo-kolejne-zapadlisko-ma-osiem-metrow-glebok,nId,6707415"><img align="left" alt="Trzebinia: Powstało kolejne zapadlisko. Ma osiem metrów głębokości" src="https://i.iplsc.com/trzebinia-powstalo-kolejne-zapadlisko-ma-osiem-metrow-glebok/000H09JF58PVBXQY-C321.jpg" /></a>Nowe zapadlisko na terenie małopolskiej Trzebini. Tym razem dziura w ziemi znajduje się na terenach leśnych, przy ul. Kopalnianej - wskazują strażacy. Zapadlisko ma 10 metrów średnicy i osiem metrów głębokości. </p><br clear="all" />

## Dokumentował groby rosyjskich żołnierzy. Musiał uciekać z kraju
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-dokumentowal-groby-rosyjskich-zolnierzy-musial-uciekac-z-kra,nId,6707397](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-dokumentowal-groby-rosyjskich-zolnierzy-musial-uciekac-z-kra,nId,6707397)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-09 16:24:07+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-dokumentowal-groby-rosyjskich-zolnierzy-musial-uciekac-z-kra,nId,6707397"><img align="left" alt="Dokumentował groby rosyjskich żołnierzy. Musiał uciekać z kraju" src="https://i.iplsc.com/dokumentowal-groby-rosyjskich-zolnierzy-musial-uciekac-z-kra/000H09H0HQA62PIE-C321.jpg" /></a>Aktywista Witalij Wotanowski, który dokumentował sprawę śmierci rosyjskich żołnierzy walczących w Ukrainie uciekł z kraju. Mężczyzna otrzymywał liczne groźby śmierci. Wcześniej Wotanowski mówił m.in o siedmiokrotnie większej liczbie ofiar w grupie Wagnera, niż jest to podawane. </p><br clear="all" />

## Konfrontacja na morzu. Tajwan wysłał wymowny komunikat chińskiemu okrętowi
 - [https://wydarzenia.interia.pl/zagranica/news-konfrontacja-na-morzu-tajwan-wyslal-wymowny-komunikat-chinsk,nId,6707393](https://wydarzenia.interia.pl/zagranica/news-konfrontacja-na-morzu-tajwan-wyslal-wymowny-komunikat-chinsk,nId,6707393)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-09 16:00:03+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-konfrontacja-na-morzu-tajwan-wyslal-wymowny-komunikat-chinsk,nId,6707393"><img align="left" alt="Konfrontacja na morzu. Tajwan wysłał wymowny komunikat chińskiemu okrętowi " src="https://i.iplsc.com/konfrontacja-na-morzu-tajwan-wyslal-wymowny-komunikat-chinsk/000H09F5P26MQRP6-C321.jpg" /></a>W niedzielę po południu &quot;około 10 chińskich i 10 tajwańskich&quot; okrętów wypłynęło naprzeciwko siebie w Cieśninie Tajwańskiej, blisko tzw. linii mediany - przekazała agencja Reutersa. Z kolei w mediach społecznościowych pojawiło się wideo Straży Przybrzeżnej Tajwanu, na którym widać, jak chiński okręt wojskowy zbliża się do newralgicznego punktu. To kolejna w ostatnich dniach prowokacja chińskiego reżimu. </p><br clear="all" />

## Zajęcia z techniki przetrwania i tropienia zwierząt. Pierwszy taki kierunek w Polsce
 - [https://wydarzenia.interia.pl/kraj/news-zajecia-z-techniki-przetrwania-i-tropienia-zwierzat-pierwszy,nId,6707400](https://wydarzenia.interia.pl/kraj/news-zajecia-z-techniki-przetrwania-i-tropienia-zwierzat-pierwszy,nId,6707400)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-09 15:39:13+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-zajecia-z-techniki-przetrwania-i-tropienia-zwierzat-pierwszy,nId,6707400"><img align="left" alt="Zajęcia z techniki przetrwania i tropienia zwierząt. Pierwszy taki kierunek w Polsce " src="https://i.iplsc.com/zajecia-z-techniki-przetrwania-i-tropienia-zwierzat-pierwszy/000H09EVIOXNGB61-C321.jpg" /></a>Zajęcia z techniki przetrwania, anatomii człowieka, zwierząt jadowitych i toksycznych, roślin jadalnych, czy też sztuki tropienia zwierząt. Tego będą uczyć się studenci na pierwszym kierunku z survivalu i animacji przyrodniczej w Polsce. Nowy kierunek zapowiedział Uniwersytet Przyrodnicy w Lublinie.</p><br clear="all" />

## Barłożno: 83-latek wpadł do zbiornika przeciwpożarowego. Mężczyzna nie żyje
 - [https://wydarzenia.interia.pl/pomorskie/news-barlozno-83-latek-wpadl-do-zbiornika-przeciwpozarowego-mezcz,nId,6707390](https://wydarzenia.interia.pl/pomorskie/news-barlozno-83-latek-wpadl-do-zbiornika-przeciwpozarowego-mezcz,nId,6707390)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-09 15:25:40+00:00

<p><a href="https://wydarzenia.interia.pl/pomorskie/news-barlozno-83-latek-wpadl-do-zbiornika-przeciwpozarowego-mezcz,nId,6707390"><img align="left" alt="Barłożno: 83-latek wpadł do zbiornika przeciwpożarowego. Mężczyzna nie żyje" src="https://i.iplsc.com/barlozno-83-latek-wpadl-do-zbiornika-przeciwpozarowego-mezcz/0005Y2LGHGSMR1U7-C321.jpg" /></a>Tragiczny wypadek we wsi Barłożno na Pomorzu. 83-letni mężczyzna wpadł do zbiornika przeciwpożarowego. Senior nie przeżył upadku. </p><br clear="all" />

## Rosja szykuje się do ewakuacji ludności. Wywieszono komunikaty
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-szykuje-sie-do-ewakuacji-ludnosci-wywieszono-komunikat,nId,6707385](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-szykuje-sie-do-ewakuacji-ludnosci-wywieszono-komunikat,nId,6707385)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-09 14:32:44+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-szykuje-sie-do-ewakuacji-ludnosci-wywieszono-komunikat,nId,6707385"><img align="left" alt="Rosja szykuje się do ewakuacji ludności. Wywieszono komunikaty" src="https://i.iplsc.com/rosja-szykuje-sie-do-ewakuacji-ludnosci-wywieszono-komunikat/000H099L0CPKR5CE-C321.jpg" /></a>W miejscowościach rosyjskiego obwodu biełgorodzkiego, znajdującego się przy granicy z Ukrainą, pojawiły się instrukcje dotyczące możliwej ewakuacji - informuje portal Ukraińska Prawda. W sobotę ukraiński sztab generalny poinformował, że część Rosjan z okupowanych regionów Ukrainy ewakuowana jest na Krym. </p><br clear="all" />

## Lawina w Alpach: Cztery osoby nie żyją, jedna ciężko ranna
 - [https://wydarzenia.interia.pl/zagranica/news-lawina-w-alpach-cztery-osoby-nie-zyja-jedna-ciezko-ranna,nId,6707383](https://wydarzenia.interia.pl/zagranica/news-lawina-w-alpach-cztery-osoby-nie-zyja-jedna-ciezko-ranna,nId,6707383)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-09 14:28:41+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-lawina-w-alpach-cztery-osoby-nie-zyja-jedna-ciezko-ranna,nId,6707383"><img align="left" alt="Lawina w Alpach: Cztery osoby nie żyją, jedna ciężko ranna" src="https://i.iplsc.com/lawina-w-alpach-cztery-osoby-nie-zyja-jedna-ciezko-ranna/000H098DL62U2QLP-C321.jpg" /></a>Cztery osoby zginęły w wyniku zejścia lawiny w rejonie Les Contamines-Montjoie na lodowcu Armancette. Jeden z turystów jest ciężko ranny. Ośmiu alpinistów nie odniosło żadnych obrażeń. Trwa ustalanie tożsamości ofiar.
</p><br clear="all" />

## Filadelfia: Kolejne szkoły tymczasowo wyłączone z użytku. Powodem azbest
 - [https://wydarzenia.interia.pl/zagranica/news-filadelfia-kolejne-szkoly-tymczasowo-wylaczone-z-uzytku-powo,nId,6707378](https://wydarzenia.interia.pl/zagranica/news-filadelfia-kolejne-szkoly-tymczasowo-wylaczone-z-uzytku-powo,nId,6707378)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-09 14:09:40+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-filadelfia-kolejne-szkoly-tymczasowo-wylaczone-z-uzytku-powo,nId,6707378"><img align="left" alt="Filadelfia: Kolejne szkoły tymczasowo wyłączone z użytku. Powodem azbest" src="https://i.iplsc.com/filadelfia-kolejne-szkoly-tymczasowo-wylaczone-z-uzytku-powo/000H08K5TDCODRSM-C321.jpg" /></a>Dwie kolejne szkoły w Filadelfii zostały tymczasowo zamknięte. Wyłączone z użytku zostały szkoła średnia i podstawowa. To wynik przeprowadzonej kontroli, która wykazała niebezpieczne stężenie azbestu. Wcześniej włókna wykryto w dwóch innych placówkach okręgowych.
</p><br clear="all" />

## Pogrzeb rosyjskiego propagandysty. Prigożyn z nietypowym "podarunkiem"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-pogrzeb-rosyjskiego-propagandysty-prigozyn-z-nietypowym-poda,nId,6707361](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-pogrzeb-rosyjskiego-propagandysty-prigozyn-z-nietypowym-poda,nId,6707361)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-04-09 13:26:21+00:00

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-pogrzeb-rosyjskiego-propagandysty-prigozyn-z-nietypowym-poda,nId,6707361"><img align="left" alt="Pogrzeb rosyjskiego propagandysty. Prigożyn z nietypowym &quot;podarunkiem&quot;" src="https://i.iplsc.com/pogrzeb-rosyjskiego-propagandysty-prigozyn-z-nietypowym-poda/000H08HRLTCBILGK-C321.jpg" /></a>W sobotę odbył się pogrzeb Władlena Tatarskiego. Rosyjski bloger wojskowy i propagandysta zginął w wyniku eksplozji, do której doszło w ubiegłym tygodniu w Petersburgu. Uczcić jego pamięć postanowił szef Grupy Wagnera Jewgienij Prigożyn. Przy trumnie złożył on młot kowalski ze specjalną dedykacją. Część żałobników miała na swoich ubraniach litery &quot;V&quot; i &quot;Z&quot; związane z napaścią na Ukrainę.</p><br clear="all" />

