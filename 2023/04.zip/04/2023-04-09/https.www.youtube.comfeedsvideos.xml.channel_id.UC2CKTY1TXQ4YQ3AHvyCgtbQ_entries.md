# Source:Tabletop Miniatures, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2CKTY1TXQ4YQ3AHvyCgtbQ, language:en-US

## Early Thoughts About the NEW 40k EDITION - The Every Other Sunday Show
 - [https://www.youtube.com/watch?v=UzkclvQ4Fxc](https://www.youtube.com/watch?v=UzkclvQ4Fxc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2CKTY1TXQ4YQ3AHvyCgtbQ
 - date published: 2023-04-09 16:14:48+00:00

The new edition of Warhammer 40k was announced a few weeks ago - and it seems like pretty major changes. What does that mean for the hobby - and will I start playing it again? Combat Patrol? Hmm? We'll talk about all this and, of course, I'll answer your wargaming-related questions. Come have fun!

Vince Venturella and I made another game! Check out Space Station Zero at http://www.spacestationzerogame.com

I'm now a partner on Twitch! I paint minis every Friday morning and Monday night, and sometimes take paint breaks (play video games poorly). Follow me: http://www.twitch.tv/tabletopminions

Official Tabletop Minions t-shirts: http://bit.ly/merchbunker

Help support the channel on Patreon, and get access to the Discord: http://www.patreon.com/tabletopminions

Twitter: http://www.twitter.com/tabletopminions
Instagram: http://www.instagram.com/tabletopminions

