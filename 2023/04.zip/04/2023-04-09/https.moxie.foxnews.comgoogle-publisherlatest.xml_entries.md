# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## Arizona woman wanted for February shooting, also charged with January shooting: reports
 - [https://www.foxnews.com/us/arizona-woman-wanted-february-shooting-charged-january-shooting-reports](https://www.foxnews.com/us/arizona-woman-wanted-february-shooting-charged-january-shooting-reports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 19:29:54+00:00

Phoenix, Arizona police arrested a woman on Friday who was wanted in Mesa, Arizona as a suspect in a fatal shooting, and later linked to an earlier fatal shooting in Phoenix.

## Michael Lerner, 'Barton Fink' actor, dead at 81
 - [https://www.foxnews.com/entertainment/michael-lerner-barton-fink-actor-dead-81](https://www.foxnews.com/entertainment/michael-lerner-barton-fink-actor-dead-81)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 19:27:38+00:00

Oscar-nominated star Michael Lerner died Saturday at 81. He was known for &quot;Eight Men Out,&quot; &quot;Godzilla,&quot; and TV roles, including &quot;Clueless,&quot; &quot;Courthouse&quot; and &quot;Glee.&quot;

## Jon Rahm wins Masters as strong Sunday helps him outlast Brooks Koepka
 - [https://www.foxnews.com/sports/jon-rahm-wins-masters-strong-sunday-helps-him-outlast-brooks-koepka](https://www.foxnews.com/sports/jon-rahm-wins-masters-strong-sunday-helps-him-outlast-brooks-koepka)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 19:25:38+00:00

Jon Rahm stayed strong through his Sunday marathon to secure the 87th Masters at Augusta National Golf Club for his first career green jacket.

## Iran installs cameras to crack down on women not wearing hijab
 - [https://www.foxnews.com/world/iran-installs-cameras-crack-down-women-not-wearing-hijab](https://www.foxnews.com/world/iran-installs-cameras-crack-down-women-not-wearing-hijab)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 19:17:39+00:00

Iran has started installing cameras in public places so that authorities can rein women who aren&apos;t wearing their hijabs in violation of the country&apos;s religious laws.

## Crime reporter's viral TikTok video shares what to do if you are home alone: 'Don't get quiet, make noise'
 - [https://www.foxnews.com/media/crime-reporter-shares-what-home-alone-dont-get-quiet-make-noise](https://www.foxnews.com/media/crime-reporter-shares-what-home-alone-dont-get-quiet-make-noise)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 19:00:48+00:00

News on 6 crime reporter Lori Fullbright shares what you should and should not do if you are home alone and someone knocks on your door in a viral TikTok video.

## Odell Beckham Jr agrees to deal with Ravens after missing 2022 season recovering from Super Bowl injury
 - [https://www.foxnews.com/sports/odell-beckham-jr-agrees-to-deal-ravens-missing-2022-season-recovering-super-bowl-injury](https://www.foxnews.com/sports/odell-beckham-jr-agrees-to-deal-ravens-missing-2022-season-recovering-super-bowl-injury)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 18:57:47+00:00

Odell Beckham Jr. will be playing for the Baltimore Ravens during the 2023 season as he appeared to announce his deal with the team on social media.

## NASCAR star Kyle Larson ahead of Bristol race: 'We don’t need to be racing on dirt'
 - [https://www.foxnews.com/sports/nascar-star-kyle-larson-ahead-bristol-race-we-dont-need-racing-dirt](https://www.foxnews.com/sports/nascar-star-kyle-larson-ahead-bristol-race-we-dont-need-racing-dirt)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 18:51:52+00:00

NASCAR champion Kyle Larson didn&apos;t appear to be too happy with having to race on dirt at Bristol as he gets ready to start the race on the pole.

## 'Super Mario Bros. Movie' breaks 2023 box office records
 - [https://www.foxnews.com/entertainment/super-mario-bros-movie-breaks-2023-box-office-records](https://www.foxnews.com/entertainment/super-mario-bros-movie-breaks-2023-box-office-records)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 18:43:21+00:00

The animated film from Universal adapted from the video game garnered $146 million over the weekend, with another $173 million in international earnings.

## Oregon paper laments homeless crisis, high taxes, violence driving citizens to other states
 - [https://www.foxnews.com/media/oregon-paper-laments-homeless-crisis-high-taxes-violence-driving-citizens-other-states](https://www.foxnews.com/media/oregon-paper-laments-homeless-crisis-high-taxes-violence-driving-citizens-other-states)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 18:30:00+00:00

A newspaper from Oregon lamented that people are moving away from the state and its most famous city by the thousands, theorizing on some of the chief reasons.

## Timberwolves' Jaden McDaniels punches wall, injures hand moments after Rudy Gobert punched teammate
 - [https://www.foxnews.com/sports/timberwolves-jaden-mcdaniels-punches-wall-injures-hand-moments-rudy-gobert-punched-teammate](https://www.foxnews.com/sports/timberwolves-jaden-mcdaniels-punches-wall-injures-hand-moments-rudy-gobert-punched-teammate)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 18:18:10+00:00

Things are not going well for the Minnesota Timberwolves in their final regular-season game against the New Orleans Pelicans on Sunday.

## Delaware duo arrested for allegedly murdering man in March: police
 - [https://www.foxnews.com/us/delaware-duo-arrested-allegedly-murdering-man-march-police](https://www.foxnews.com/us/delaware-duo-arrested-allegedly-murdering-man-march-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 18:15:48+00:00

Delaware State Police arrested a man and a woman on Saturday for allegedly shooting and killing a man during the early morning hours on March 19.

## Sahith Theegala nails incredible chip-in for birdie at Masters
 - [https://www.foxnews.com/sports/sahith-theegala-nails-incredible-chip-in-birdie-masters](https://www.foxnews.com/sports/sahith-theegala-nails-incredible-chip-in-birdie-masters)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 18:07:33+00:00

Sahith Theegala finished the first Masters tournament of his career on Sunday and had an epic moment in the fourth round of the event.

## Northern Ireland police disrupt alleged New IRA bomb plot ahead of Biden's visit: report
 - [https://www.foxnews.com/world/northern-ireland-police-disrupt-alleged-new-ira-bomb-plot-ahead-bidens-visit-report](https://www.foxnews.com/world/northern-ireland-police-disrupt-alleged-new-ira-bomb-plot-ahead-bidens-visit-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 18:06:08+00:00

The Police Service of Northern Ireland reportedly disrupted a bomb plot by members of the New IRA ahead of a visit by President Joe Biden next week.

## Rudy Gobert punches Timberwolves teammate during timeout, gets sent home
 - [https://www.foxnews.com/sports/rudy-gobert-punches-timberwolves-teammate-timeout-gets-sent-home](https://www.foxnews.com/sports/rudy-gobert-punches-timberwolves-teammate-timeout-gets-sent-home)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 18:01:29+00:00

The Minnesota Timberwolves sent Rudy Gobert home after he punched teammate Kyle Anderson during a timeout in the final regular-season game against the New Orleans Pelicans.

## Washington state crews responding to boat fire in Tacoma Tideflats, residents receive smoke warning
 - [https://www.foxnews.com/us/washington-state-crews-responding-boat-fire-tacoma-tideflats-residents-receive-smoke-warning](https://www.foxnews.com/us/washington-state-crews-responding-boat-fire-tacoma-tideflats-residents-receive-smoke-warning)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 17:56:55+00:00

Multiple agencies are responding to a fire that broke out aboard the Kodiak Enterprise Saturday, prompting officials to issue a warning for surrounding residents.

## Spurs' Gregg Popovich makes plea for tighter gun control, likens Second Amendment to 'myth'
 - [https://www.foxnews.com/sports/spurs-gregg-popovich-makes-plea-tighter-gun-control-likens-second-amendment-myth](https://www.foxnews.com/sports/spurs-gregg-popovich-makes-plea-tighter-gun-control-likens-second-amendment-myth)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 17:48:00+00:00

San Antonio Spurs coach Gregg Popovich used his pregame press conference to call for tighter gun measures, call out Republican lawmakers and dismiss the Second Amendment.

## King Charles' coronation details revealed
 - [https://www.foxnews.com/entertainment/king-charles-coronation-details-revealed](https://www.foxnews.com/entertainment/king-charles-coronation-details-revealed)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 17:30:02+00:00

Coronation plans for King Charles and Queen Consort were announced by Buckingham Palace on Easter. Armed forces will salute royals in parade post ceremony.

## Los Angeles suspect throws puppy out of moving car during police chase
 - [https://www.foxnews.com/us/los-angeles-suspect-throws-puppy-out-moving-car-police-chase](https://www.foxnews.com/us/los-angeles-suspect-throws-puppy-out-moving-car-police-chase)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 17:08:32+00:00

An 8-week-old mixed-breed puppy was thrown in a Michael Kors bag and tossed onto the street during a police chase in Los Angeles on Friday, culminating in three arrests, the LAPD said.

## California driver, 13, charged in deadly vehicle crash involving stolen vehicle
 - [https://www.foxnews.com/us/california-driver-13-charged-deadly-vehicle-crash-involving-stolen-vehicle](https://www.foxnews.com/us/california-driver-13-charged-deadly-vehicle-crash-involving-stolen-vehicle)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 17:06:41+00:00

A 13-year-old California boy is accused of stealing a car and leading police on a chase before colliding with other vehicles, killing one person and injuring nearly a dozen others.

## Massachusetts man found dead on side of Cohasset road: police
 - [https://www.foxnews.com/us/massachusetts-man-found-dead-side-cohasset-road-police](https://www.foxnews.com/us/massachusetts-man-found-dead-side-cohasset-road-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 17:04:02+00:00

Massachusetts police officials found a 40-year-old deceased man on the side of a road in the seaside town. Detectives and state troopers are investigating the incident.

## Chicago police find two bodies near O’Hare Airport hours apart
 - [https://www.foxnews.com/us/chicago-police-find-two-bodies-near-ohare-airport-hours-apart](https://www.foxnews.com/us/chicago-police-find-two-bodies-near-ohare-airport-hours-apart)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 17:01:49+00:00

Chicago Police Department (CPD) officials reported that they found two dead bodies hours apart near O’Hare International Airport on Saturday. They believe one was an overdose death.

## HHS Secretary says Biden administration ignoring federal judge’s abortion pill ruling is ‘on the table’
 - [https://www.foxnews.com/media/hhs-secretary-biden-administration-ignoring-federal-judges-abortion-pill-ruling-table](https://www.foxnews.com/media/hhs-secretary-biden-administration-ignoring-federal-judges-abortion-pill-ruling-table)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 17:00:37+00:00

HHS secretary Xavier Becerra condemned the ruling against an abortion pill on Sunday, warning that all manner of options are being considered to combat it.

## Colorado Home Depot customer gets attacked by dog, owner flees store
 - [https://www.foxnews.com/us/colorado-home-depot-customer-gets-attacked-dog-owner-flees-store](https://www.foxnews.com/us/colorado-home-depot-customer-gets-attacked-dog-owner-flees-store)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 17:00:00+00:00

A Home Depot shopper in Evergreen, Colorado, was bitten in the face by a dog after the dog owner approached them and asked them to give the canine a treat as part of its training.

## Benches clear in White Sox-Pirates game after scary collision leaves Oneil Cruz with broken ankle
 - [https://www.foxnews.com/sports/benches-clear-white-sox-pirates-scary-collision-oneil-cruz-broken-ankle](https://www.foxnews.com/sports/benches-clear-white-sox-pirates-scary-collision-oneil-cruz-broken-ankle)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 16:59:16+00:00

Pittsburgh Pirates shortstop Oneil Cruz suffered a broken ankle in a scary home-plate collision against the Chicago White Sox, which led to a benches-clearing scuffle.

## Woman with tuberculosis faces jail and forced treatment after she refused isolation and visited a casino
 - [https://www.foxnews.com/us/woman-with-tuberculosis-faces-jail-and-forced-treatment-after-refusing-medication-isolation](https://www.foxnews.com/us/woman-with-tuberculosis-faces-jail-and-forced-treatment-after-refusing-medication-isolation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 16:54:18+00:00

An unidentified woman in Washington state who was diagnosed with tuberculosis was found in contempt of court after refusing to isolate and pursue treatment despite warnings.

## Pastor spends Easter in jail after another arrest at drag queen event
 - [https://www.foxnews.com/world/pastor-spends-easter-jail-after-another-arrest-drag-queen-event](https://www.foxnews.com/world/pastor-spends-easter-jail-after-another-arrest-drag-queen-event)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 16:20:49+00:00

Canadian pastor Derek Reimer, 36, was arrested for the third time in five weeks and spent Easter weekend behind bars after protesting a drag queen story time for children.

## Royal family attends first Easter service since Queen Elizabeth’s death
 - [https://www.foxnews.com/entertainment/royal-family-attends-first-easter-service-since-queen-elizabeths-death](https://www.foxnews.com/entertainment/royal-family-attends-first-easter-service-since-queen-elizabeths-death)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 15:51:50+00:00

The royal family stepped out together to celebrate their first Easter service since the passing of Queen Elizabeth II last year.

## Israel Adesanya gives iconic celebration after knocking out Alex Pereira to win back UFC belt
 - [https://www.foxnews.com/sports/israel-adesanya-gives-iconic-celebration-knocking-out-alex-pereira-win-back-ufc-belt](https://www.foxnews.com/sports/israel-adesanya-gives-iconic-celebration-knocking-out-alex-pereira-win-back-ufc-belt)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 15:49:57+00:00

Israel Adesanya called it &quot;sweet revenge&quot; when he knocked out Alex Pereira to win the middleweight belt back at UFC 287 on Saturday night in Miami.

## China conducts second day of military drills around Taiwan, simulates strikes on the island
 - [https://www.foxnews.com/world/china-conducts-second-day-military-drills-taiwan-simulates-strikes-island](https://www.foxnews.com/world/china-conducts-second-day-military-drills-taiwan-simulates-strikes-island)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 15:39:14+00:00

Several dozen Chinese military aircraft and nine naval vessels conducted military exercises around Taiwan and simulated strikes on the island on Sunday.

## French Alps avalanche kills four hikers, injures others
 - [https://www.foxnews.com/world/french-alps-avalanche-kills-four-hikers-injures-others](https://www.foxnews.com/world/french-alps-avalanche-kills-four-hikers-injures-others)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 15:36:24+00:00

An avalanche near the ski resort of Contamines-Montjoie in the French Alps killed at least four people and injured others Sunday afternoon, officials say.

## Dolphins' Tyreek Hill left in the dust by young football player at Miami camp
 - [https://www.foxnews.com/sports/dolphins-tyreek-hill-left-dust-young-football-player-miami-camp](https://www.foxnews.com/sports/dolphins-tyreek-hill-left-dust-young-football-player-miami-camp)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 15:22:09+00:00

Dolphins wide receiver Tyreek Hill was giving back to the youth with his football camp in Miami on Saturday, but he didn&apos;t expect one camper to embarrass him on the field.

## Imam stabbed during prayers at New Jersey Omar Mosque: reports
 - [https://www.foxnews.com/us/imam-stabbed-during-prayers-at-new-jersey-omar-mosque](https://www.foxnews.com/us/imam-stabbed-during-prayers-at-new-jersey-omar-mosque)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 15:20:35+00:00

A prayer leader, known as an imam, was stabbed twice Sunday at a mosque in Paterson, New Jersey. The suspect&apos;s name has not been released, nor a motive.

## Social media secret profiles: Does Facebook have your info?
 - [https://www.foxnews.com/tech/social-media-secret-profiles-does-facebook-have-your-info](https://www.foxnews.com/tech/social-media-secret-profiles-does-facebook-have-your-info)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 15:16:30+00:00

If you use social media, it&apos;s worth clearing out all the things you&apos;ve looked up. Here are easy steps to save yourself some potential embarrassment later.

## Senate chaplain doubles down after saying 'thoughts and prayers' are not enough after Nashville shooting
 - [https://www.foxnews.com/politics/senate-chaplain-barry-black-doubles-down-after-saying-thoughts-and-prayers-are-not-enough-after-nashville-shooting](https://www.foxnews.com/politics/senate-chaplain-barry-black-doubles-down-after-saying-thoughts-and-prayers-are-not-enough-after-nashville-shooting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 15:15:36+00:00

Senate Chaplain the Rev. Barry Black said there is &quot;a time when action is required&quot; after calls from Democrats to reintroduce gun control legislation after Nashville school shooting.

## Florida police arrest third juvenile suspect in triple homicide
 - [https://www.foxnews.com/us/florida-police-arrest-third-juvenile-suspect-triple-homicide](https://www.foxnews.com/us/florida-police-arrest-third-juvenile-suspect-triple-homicide)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 15:07:29+00:00

The Marion County, Florida sheriff&apos;s office, with the help of U.S. Marshals and the Lake County Sheriff&apos;s Office arrested a third suspect in connection to a triple homicide.

## Gov. Gavin Newsom offers DeSantis political advice, says he will get 'rolled by Trump': 'Pack up and wait'
 - [https://www.foxnews.com/media/gov-gavin-newsom-desantis-political-advice-rolled-trump-pack-up-wait](https://www.foxnews.com/media/gov-gavin-newsom-desantis-political-advice-rolled-trump-pack-up-wait)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 15:00:19+00:00

Gov. Gavin Newsom offered Gov. Ron DeSantis some political advice during an interview on Sunday and said he would get &quot;rolled&quot; by Donald Trump in an election.

## Soros-backed policy group notches victory with Biden's transgender Title IX rules
 - [https://www.foxnews.com/politics/soros-backed-policy-group-notches-victory-with-bidens-transgender-title-ix-rules](https://www.foxnews.com/politics/soros-backed-policy-group-notches-victory-with-bidens-transgender-title-ix-rules)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 14:30:21+00:00

A group bankrolled with nearly $10 million from a George Soros nonprofit notched a victory from the Biden administration&apos;s proposed Title IX rule, which brings in gender identity.

## Former AG issues chilling warning that left's agenda is 'leading to horrific crimes'
 - [https://www.foxnews.com/media/former-ag-issues-chilling-warning-lefts-agenda-leading-horrific-crimes](https://www.foxnews.com/media/former-ag-issues-chilling-warning-lefts-agenda-leading-horrific-crimes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 14:30:03+00:00

Former acting U.S. Attorney General Matthew Whitaker shared his concerns for the left&apos;s push for gun control amid rising crime.

## LSU star Angel Reese receives support from Tony Yayo, creator of 'You Can't See Me' taunt
 - [https://www.foxnews.com/sports/lsu-star-angel-reese-receives-support-tony-yayo-creator-you-cant-see-me-taunt](https://www.foxnews.com/sports/lsu-star-angel-reese-receives-support-tony-yayo-creator-you-cant-see-me-taunt)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 14:20:15+00:00

LSU star Angel Reese received support from the originator of the &quot;You Can&apos;t See Me&quot; taunt in the wake of the backlash she received from doing the celebratory gestures.

## Dem senator accuses Trump of leaving Biden with ‘bad options’ for disastrous Afghanistan withdrawal
 - [https://www.foxnews.com/politics/dem-senator-accuses-trump-leaving-biden-bad-options-disastrous-afghanistan-withdrawal](https://www.foxnews.com/politics/dem-senator-accuses-trump-leaving-biden-bad-options-disastrous-afghanistan-withdrawal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 14:10:12+00:00

Sen. Ben Cardin appeared on &quot;FOX News Sunday&quot; and said that President Biden was not left with any good options concerning the Afghanistan withdrawal in 2021 because of Trump.

## UFC star praises Trump, DeSantis, leads crowd in ‘Let’s go, Brandon' chant
 - [https://www.foxnews.com/us/ufc-star-praises-trump-desantis-leads-crowd-lets-go-brandon-chant](https://www.foxnews.com/us/ufc-star-praises-trump-desantis-leads-crowd-lets-go-brandon-chant)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 14:03:44+00:00

UFC Star Jorge Masvidal praised former President Trump and Florida Gov. Ron DeSantis after the final fight of his career, going on to lead a &apos;Let&apos;s go, Brandon&apos; chant.

## 'Fox News Sunday' on April 9, 2023
 - [https://www.foxnews.com/transcript/fox-news-sunday-april-9-2023](https://www.foxnews.com/transcript/fox-news-sunday-april-9-2023)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 14:02:05+00:00

This week on &apos;Fox News Sunday,&apos; host Shannon Bream welcomed Sen. Ben Cardin, Sen. Lindsey Graham, and more to discuss the week&apos;s top political headlines.

## Julian Assange's family grills government's 'over-classification' of documents: 'A problem for democracy'
 - [https://www.foxnews.com/media/julian-assange-family-government-classification-documents-problem-democracy](https://www.foxnews.com/media/julian-assange-family-government-classification-documents-problem-democracy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 14:00:59+00:00

Julian Assange&apos;s father and brother defended his actions of leaking military information during a recent appearance on Fox Nation&apos;s &apos;Piers Morgan: Uncensored.&apos;

## Trump attorney pushes back after NBC host asks if Trump is holding classified docs for payout: 'Cheap shot'
 - [https://www.foxnews.com/politics/trump-attorney-pushes-back-after-nbc-host-trump-holding-classified-docs-payout-cheap-shot](https://www.foxnews.com/politics/trump-attorney-pushes-back-after-nbc-host-trump-holding-classified-docs-payout-cheap-shot)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 13:43:20+00:00

James Trusty, an attorney representing Donald Trump, called accusations that Trump was looking for a financial settlement over classified documents a &quot;cheap shot.&quot;

## Leaked Pentagon documents claim Israel’s Mossad encouraged protests against Netanyahu
 - [https://www.foxnews.com/world/leaked-pentagon-documents-claim-israels-mossad-encouraged-protests-netanyahu](https://www.foxnews.com/world/leaked-pentagon-documents-claim-israels-mossad-encouraged-protests-netanyahu)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 13:31:56+00:00

Prime Minister Benjamin Netanyahu and the Mossad denied reports Sunday that Israel&apos;s intelligence agency had encouraged protests against Netanyahu&apos;s judicial reform efforts.

## CNN presses Rep. Ocasio-Cortez over claims Biden admin should 'ignore' abortion ruling: 'Stunning position'
 - [https://www.foxnews.com/media/cnn-presses-rep-ocasio-cortez-over-claims-biden-admin-should-ignore-abortion-ruling-stunning-position](https://www.foxnews.com/media/cnn-presses-rep-ocasio-cortez-over-claims-biden-admin-should-ignore-abortion-ruling-stunning-position)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 13:30:13+00:00

Rep. Alexandria Ocasio-Cortez was pressed by CNN&apos;s Dana Bash on Sunday about her call for the Biden administration to ignore the ruling on the abortion pill.

## Barr slams Trump as weak candidate, makes bold prediction for 2024 election
 - [https://www.foxnews.com/politics/barr-slams-trump-weak-candidate-makes-bold-prediction-2024-election](https://www.foxnews.com/politics/barr-slams-trump-weak-candidate-makes-bold-prediction-2024-election)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 13:24:16+00:00

Former Attorney General Bill Barr said he views former President Trump as the &quot;weakest of the Republican candidates,&quot; expecting him to lose to President Biden in the 2024 general election.

## Religious liberty nonprofit blasts bill banning protests near drag shows: 'Deranged parody of public law'
 - [https://www.foxnews.com/world/religious-liberty-nonprofit-blasts-bill-banning-protests-drag-shows-deranged-parody-public-law](https://www.foxnews.com/world/religious-liberty-nonprofit-blasts-bill-banning-protests-drag-shows-deranged-parody-public-law)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 13:12:13+00:00

Liberty Coalition Canada founder Michael Thiessen blasted a recent provincial bill in Ontario that would criminalize protests and &quot;offensive remarks&quot; around drag shows.

## Two Florida women arrested after taunting, abusing elderly woman on live stream 'pieces of crap,' sheriff says
 - [https://www.foxnews.com/us/two-florida-women-arrested-taunting-abusing-elderly-women-live-stream-deputies-say](https://www.foxnews.com/us/two-florida-women-arrested-taunting-abusing-elderly-women-live-stream-deputies-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 13:10:14+00:00

Two healthcare workers in Florida have been arrested after allegedly taunting, abusing an elderly woman with dementia and live streaming it, Sheriff Wayne Ivey says.

## Lindsey Graham lambasts Biden White House's review of botched Afghanistan exodus: 'Political white-wash'
 - [https://www.foxnews.com/media/lindsey-graham-biden-white-houses-review-afghanistan-exodus-political-white-wash](https://www.foxnews.com/media/lindsey-graham-biden-white-houses-review-afghanistan-exodus-political-white-wash)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 12:48:03+00:00

Sen. Lindsey Graham, R-S.C. grilled the Biden administration&apos;s report on the Afghanistan withdrawal Sunday, criticizing claims that Trump created conditions for the catastrophe.

## AOC claims there is 'crime wave' within GOP after saying officials should ignore court rulings
 - [https://www.foxnews.com/politics/aoc-claims-crime-wave-gop-saying-officials-should-ignore-court-rulings](https://www.foxnews.com/politics/aoc-claims-crime-wave-gop-saying-officials-should-ignore-court-rulings)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 12:32:19+00:00

New York Democratic Rep. Alexandria Ocasio-Cortez argued there is a crime wave within the Republican Party, and cited Trump and Supreme Court Justice Clarence Thomas.

## Norfolk Southern train cars derail, spilling diesel and oil; 2 taken to hospital
 - [https://www.foxnews.com/us/norfolk-southern-train-cars-derail-spilling-diesel-oil-2-taken-hospital](https://www.foxnews.com/us/norfolk-southern-train-cars-derail-spilling-diesel-oil-2-taken-hospital)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 12:19:55+00:00

Two crew members were briefly hospitalized after a Norfolk Southern train derailed in Alabama on Easter Sunday. Officials say there is no hazardous materials threat.

## Five empty Norfolk Southern train cars derail in Pittsburgh
 - [https://www.foxnews.com/us/five-empty-norfolk-southern-train-cars-derail-pittsburgh](https://www.foxnews.com/us/five-empty-norfolk-southern-train-cars-derail-pittsburgh)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 12:19:18+00:00

It was not immediately clear what caused five empty Norfolk Southern train cars to derail in Pittsburgh, Pennsylvania, on Saturday. No injuries were reported.

## Jim Nantz appears to make LIV Golf crack as Brooks Koepka finishes up third round of Masters
 - [https://www.foxnews.com/sports/jim-nantz-appears-make-liv-golf-crack-brooks-koepka-finishes-up-third-round-masters](https://www.foxnews.com/sports/jim-nantz-appears-make-liv-golf-crack-brooks-koepka-finishes-up-third-round-masters)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 11:59:19+00:00

Jim Nantz appeared to make a LIV Golf joke at the expense of Brooks Koepka on Sunday as players finished up the third round of the Masters.

## Missouri boy delivers hundreds of Easter baskets to children in need: 'Helping kids smile'
 - [https://www.foxnews.com/lifestyle/missouri-boy-delivers-hundreds-easter-baskets-children-need-helping-kids-smile](https://www.foxnews.com/lifestyle/missouri-boy-delivers-hundreds-easter-baskets-children-need-helping-kids-smile)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 11:51:03+00:00

Since he was three years old, Luke Flerlage has been volunteering with Alleluia Baskets in O&apos;Fallon, Missouri, providing Easter baskets for the under privileged community.

## Sprint car driver Justin Owen, 26, dies from injuries suffered in crash at track
 - [https://www.foxnews.com/sports/sprint-car-driver-justin-owen-26-dies-injuries-suffered-crash-track](https://www.foxnews.com/sports/sprint-car-driver-justin-owen-26-dies-injuries-suffered-crash-track)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 11:41:54+00:00

The U.S. Auto Club on Sunday announced Justin Owen died from the injuries he suffered in a crash at an Indiana racetrack on Saturday night.

## Louisville's Hailey Van Lith enters transfer portal after tournament run
 - [https://www.foxnews.com/sports/louisvilles-hailey-van-lith-enters-transfer-portal-tournament-run](https://www.foxnews.com/sports/louisvilles-hailey-van-lith-enters-transfer-portal-tournament-run)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 11:23:41+00:00

Louisville women&apos;s basketball star Hailey Van Lith announced she will transfer from the school after three stellar years playing for the Cardinals.

## Body discovered in submerged car of Florida teacher missing since 2020, sheriff says
 - [https://www.foxnews.com/us/body-discovered-submerged-car-florida-teacher-missing-since-2020-sheriff-says](https://www.foxnews.com/us/body-discovered-submerged-car-florida-teacher-missing-since-2020-sheriff-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 11:16:52+00:00

A body was discovered inside a vehicle that belongs to Robert Heikka, a teacher in Port Orange, Florida, who went missing in 2020, after the car was pulled from a canal.

## Police are using invasive facial recognition software to put every American in a perpetual lineup
 - [https://www.foxnews.com/tech/police-using-invasive-facial-recognition-software-put-every-american-in-perpetual-lineup](https://www.foxnews.com/tech/police-using-invasive-facial-recognition-software-put-every-american-in-perpetual-lineup)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 11:08:16+00:00

AI tech company Clearview AI is coming under fire after providing facial recognition software to law enforcement agencies, private companies and other organizations.

## Former drug dealer on mission to prevent overdose deaths after harrowing past: Rebellion ‘led me to crime'
 - [https://www.foxnews.com/media/former-drug-dealer-mission-prevent-overdose-deaths-harrowing-past-rebellion-crime](https://www.foxnews.com/media/former-drug-dealer-mission-prevent-overdose-deaths-harrowing-past-rebellion-crime)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 11:00:53+00:00

Former drug dealer Pancho Mercado shares the metamorphic moment that he decided to leave a life of crime, making it his mission to save lives.

## 2 arrested in Isle of Palms shooting police say began with high school ‘skip day’
 - [https://www.foxnews.com/us/2-arrested-isle-palms-shooting-police-say-began-high-school-skip-day](https://www.foxnews.com/us/2-arrested-isle-palms-shooting-police-say-began-high-school-skip-day)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 10:58:56+00:00

Police have arrested two teenagers in relation to an Isle of Palms shooting in South Carolina that left six people injured, most of them high schoolers, on Friday.

## NASCAR legend Cale Yarborough 'is not doing well': report
 - [https://www.foxnews.com/sports/nascar-legend-cale-yarborough-not-doing-well-report](https://www.foxnews.com/sports/nascar-legend-cale-yarborough-not-doing-well-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 10:51:00+00:00

Cale Yarborough is in need of prayers as he is &quot;not doing well,&quot; according to John Dodson, the vice president of business alliances and NASCAR at Universal Technical Institute.

## Jonas Brothers say they don't give each other parenting advice: 'Unspoken Rule'
 - [https://www.foxnews.com/entertainment/jonas-brothers-dont-give-each-other-parenting-advice-unspoken-rule](https://www.foxnews.com/entertainment/jonas-brothers-dont-give-each-other-parenting-advice-unspoken-rule)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 10:31:53+00:00

The Jonas Brothers revealed they avoid giving each other parenting advice, saying it is an &quot;unspoken rule&quot; between the three as the brothers continue to grow their musical careers and families.

## GOP rep. raises questions, calls for investigation into leaked US documents: 'It's a huge deal'
 - [https://www.foxnews.com/media/gop-rep-raises-questions-calls-investigation-into-leaked-documents-huge-deal](https://www.foxnews.com/media/gop-rep-raises-questions-calls-investigation-into-leaked-documents-huge-deal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 10:30:34+00:00

Rep. Brad Wenstrup, R-Ohio, raises questions concerning the leaking of classified U.S. intelligence and stresses the need to investigate.

## Riley Gaines rejects SFSU's statement suggesting students protested 'peacefully': 'I was assaulted'
 - [https://www.foxnews.com/media/riley-gaines-rejects-sfsus-statement-suggesting-students-protested-peacefully-assaulted](https://www.foxnews.com/media/riley-gaines-rejects-sfsus-statement-suggesting-students-protested-peacefully-assaulted)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 10:30:13+00:00

Riley Gaines reacted to an email sent to San Francisco State University students after protests erupted at an event Gaines spoke at on campus on Saturday.

## One of America’s top tourist destinations ranked as least neighborly city in country
 - [https://www.foxnews.com/us/one-americas-top-tourist-destinations-ranked-least-neighborly-city-country](https://www.foxnews.com/us/one-americas-top-tourist-destinations-ranked-least-neighborly-city-country)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 10:18:38+00:00

Miami, Florida, is the least neighborly city in America, according to an AmeriCorps study, with veterans and people with kids taking top spots for informally helping.

## Report on Clarence Thomas' travel habits is 'politics plain and simple': expert
 - [https://www.foxnews.com/politics/report-clarence-thomas-travel-habits-politics-plain-simple-expert](https://www.foxnews.com/politics/report-clarence-thomas-travel-habits-politics-plain-simple-expert)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 10:07:27+00:00

Calls for the resignation of Justice Clarence Thomas are unfounded, an expert told Fox News Digital, and there is no &quot;there there&quot; when it comes to a report on his travels.

## Soros-backed DA behind Army veteran's murder conviction accused of witness tampering, withholding evidence
 - [https://www.foxnews.com/media/soros-da-army-veteran-murder-conviction-witness-tampering-withholding-evidence](https://www.foxnews.com/media/soros-da-army-veteran-murder-conviction-witness-tampering-withholding-evidence)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 10:00:25+00:00

Texas Lt. Gov. Dan Patrick, R., criticized Soros-backed DA Jose Garza for bringing charges against an Army veteran who allegedly acted in self-defense against a BLM rioter.

## Never forget another appointment again with this ultimate scheduling tech
 - [https://www.foxnews.com/tech/never-forget-appointment-ultimate-scheduling-tech](https://www.foxnews.com/tech/never-forget-appointment-ultimate-scheduling-tech)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 09:51:21+00:00

Kurt &quot;CyberGuy&quot; Knutsson explains how to add and customize events in your iPhone or Android calendars so that you will never miss another appointment again.

## Rumer Willis says Bruce Willis, Demi Moore are 'so excited' over first grandchild, offering plenty of advice
 - [https://www.foxnews.com/entertainment/rumer-willis-bruce-willis-demi-moore-so-excited-first-grandchild-offering-plenty-advice](https://www.foxnews.com/entertainment/rumer-willis-bruce-willis-demi-moore-so-excited-first-grandchild-offering-plenty-advice)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 09:48:29+00:00

Bruce Willis and Demi Moore&apos;s daughter, Rumer, shared how both her parents are &quot;so excited&quot; to welcome their first grandchild after Rumer announced the news back in December.

## Los Angeles LGBT Center to host drag queen march Easter Sunday
 - [https://www.foxnews.com/us/los-angeles-lgbt-center-host-drag-queen-march-easter-sunday](https://www.foxnews.com/us/los-angeles-lgbt-center-host-drag-queen-march-easter-sunday)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-09 09:22:12+00:00

Los Angeles LGBT Center plans to host a drag march, Easter Sunday, to protest legislation that protects children from drag performances and gender reassignment surgery.

