# Source:Daily Wire, URL:https://www.dailywire.com/feeds/rss.xml, language:en-US

## Former GOP Governor Chris Christie: Trump Is The Only Republican Biden Can Beat
 - [https://www.dailywire.com/news/former-gop-governor-chris-christie-trump-is-the-only-republican-biden-can-beat](https://www.dailywire.com/news/former-gop-governor-chris-christie-trump-is-the-only-republican-biden-can-beat)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-09 19:31:16+00:00

Former New Jersey Governor Chris Christie said during an interview on Sunday that former President Donald Trump was the only Republican that President Joe Biden can beat in a general election and that the president would lose to any other Republican. Christie made the remarks during an roundtable discussion on ABC News&#8217; &#8220;This Week&#8221; when ...

## Top House Republican Warns: U.S. Needs To Arm Taiwan Fast, Beef Up U.S. Military Presence To Avoid War
 - [https://www.dailywire.com/news/top-house-republican-warns-u-s-needs-to-arm-taiwan-fast-beef-up-u-s-military-presence-to-avoid-war](https://www.dailywire.com/news/top-house-republican-warns-u-s-needs-to-arm-taiwan-fast-beef-up-u-s-military-presence-to-avoid-war)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-09 19:15:11+00:00

Rep. Mike Gallagher (R-WI) warned during an interview over the weekend that China is using all means of warfare available to try to take over Taiwan. Gallagher, chairman of the House Select Committee on China, told Fox News’ “Sunday Morning Futures” that the Chinese Communist Party was trying to intimidate the U.S. with their recent ...

## Senator Graham Warns About War With China: U.S. Must Boost Military Now Or Face War
 - [https://www.dailywire.com/news/senator-graham-warns-about-war-with-china-u-s-must-boost-military-now-or-face-war](https://www.dailywire.com/news/senator-graham-warns-about-war-with-china-u-s-must-boost-military-now-or-face-war)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-09 19:09:54+00:00

Sen. Lindsey Graham (R-SC) warned over the weekend that the United States must increase its overall military preparedness or face an almost certain war with communist China in the near future. Graham made the remarks during an interview on Fox News&#8217; &#8220;Fox News Sunday&#8221; on Easter while talking about U.S. national security. Graham&#8217;s remarks come ...

## Trump AG Bill Barr: Prosecutors Likely Have ‘Very Good Evidence’ Trump Obstructed Justice
 - [https://www.dailywire.com/news/trump-ag-bill-barr-prosecutors-likely-have-very-good-evidence-trump-obstructed-justice](https://www.dailywire.com/news/trump-ag-bill-barr-prosecutors-likely-have-very-good-evidence-trump-obstructed-justice)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-09 18:03:46+00:00

Former Trump Attorney General William Barr said over the weekend that he believes that federal prosecutors likely have &#8220;very good evidence&#8221; that the former president committed obstruction of justice in the criminal investigation into his handling of classified material. Barr made the remarks on Easter Sunday during an interview on ABC News&#8217; &#8220;This Week&#8221; while ...

## ‘Boy Meets Congress’: Ben Savage’s Former Castmates Weigh In On His Campaign
 - [https://www.dailywire.com/news/boy-meets-congress-ben-savages-former-castmates-weigh-in-on-his-campaign](https://www.dailywire.com/news/boy-meets-congress-ben-savages-former-castmates-weigh-in-on-his-campaign)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-09 17:56:31+00:00

Actor Ben Savage has announced a run for Congress in California — and now his former &#8220;Boy Meets World&#8221; cast mates have revealed what they think about his political future. During last Wednesday&#8217;s episode of the &#8220;Pod Meets World&#8221; podcast, actors Will Friedle, Rider Strong, and Danielle Fishel began with a discussion about an episode ...

## Hundreds Of Social Media ‘Influencers’ To Tout Biden’s Record Ahead Of 2024 Election: Report
 - [https://www.dailywire.com/news/hundreds-of-social-media-influencers-to-tout-bidens-record-ahead-of-2024-election-report](https://www.dailywire.com/news/hundreds-of-social-media-influencers-to-tout-bidens-record-ahead-of-2024-election-report)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-09 17:13:50+00:00

The White House digital strategy team will seek out hundreds of social media &#8220;influencers&#8221; nationwide to tout the Biden administration&#8217;s record, potentially designating a briefing room for the content creators at the presidential mansion. Biden officials told Axios that four staffers for the White House, not the president&#8217;s unofficial campaign, would focus their attempts on ...

## San Francisco State Offers Counseling To Trans Activists Who Attacked Riley Gaines
 - [https://www.dailywire.com/news/san-francisco-state-offers-counseling-to-trans-activists-who-attacked-riley-gaines](https://www.dailywire.com/news/san-francisco-state-offers-counseling-to-trans-activists-who-attacked-riley-gaines)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-09 16:53:19+00:00

San Francisco State University responded to an on-campus protest — during which trans activists assaulted former NCAA swimmer Riley Gaines and held her hostage — by praising the protesters and offering them access to counseling. Turning Point USA&#8217;s Bay Area college field representative David Llamas shared a copy of the email, which was sent out ...

## Two Wisconsin Cops Fatally Shot During Traffic Stop
 - [https://www.dailywire.com/news/two-wisconsin-cops-fatally-shot-during-traffic-stop](https://www.dailywire.com/news/two-wisconsin-cops-fatally-shot-during-traffic-stop)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-09 15:49:19+00:00

An exchange of gunfire during a traffic stop in Wisconsin resulted in the deaths of two police officers on Saturday, according to authorities. The deadly incident took place at around 3:38 p.m. in the village of Cameron, which is located in the western part of the state in Barron County, the Wisconsin Department of Justice ...

## Texas Lawmaker Suggests House Republicans Defund FDA Programs If Biden Admin Ignores State Abortion Pill Ruling
 - [https://www.dailywire.com/news/texas-lawmaker-suggests-house-republicans-defund-fda-programs-if-biden-admin-ignores-state-abortion-pill-ruling](https://www.dailywire.com/news/texas-lawmaker-suggests-house-republicans-defund-fda-programs-if-biden-admin-ignores-state-abortion-pill-ruling)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-09 15:37:58+00:00

Rep. Tony Gonzales (R-TX) suggested House Republicans could reach a point where they vote to defund Food and Drug Administration programs after President Joe Biden threatened to fight a federal ruling to suspend the agency&#8217;s approval of the abortion pill mifepristone. Last week, U.S. District Judge Matthew Kacsmaryk moved to suspend the FDA&#8217;s approval of ...

## Lindsey Graham: Biden Admin Afghanistan Report ‘A Political Whitewash … To Shift Blame’ For Failures
 - [https://www.dailywire.com/news/lindsey-graham-biden-admin-afghanistan-report-a-political-whitewash-to-shift-blame-for-failures](https://www.dailywire.com/news/lindsey-graham-biden-admin-afghanistan-report-a-political-whitewash-to-shift-blame-for-failures)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-09 14:14:20+00:00

Sen. Lindsey Graham (R-SC) described the Biden administration&#8217;s report on the Afghanistan withdrawal as &#8220;a political whitewash.&#8221; Appearing on &#8220;Fox News Sunday,&#8221; Graham blasted the 12-page summary report that blamed problems on the Trump administration, claiming that it hampered the withdrawal efforts. He accused the Biden administration of deflecting, adding that its weak pull-out exposed ...

## GOP Lawmaker Says Trump Drama Is Like ‘A Spanish Soap Opera’
 - [https://www.dailywire.com/news/gop-lawmaker-says-trump-drama-is-like-a-spanish-soap-opera](https://www.dailywire.com/news/gop-lawmaker-says-trump-drama-is-like-a-spanish-soap-opera)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-09 13:51:22+00:00

People are too addicted to the legal drama surrounding former President Donald Trump, a Texas GOP congressman suggested on Sunday. &#8220;It&#8217;s like watching a novella, a Spanish soap opera,&#8221; Rep. Tony Gonzales (R-TX), who represents a district along the U.S.-Mexico border, said on CNN. &#8220;You can&#8217;t look away. I get it. I want to know what ...

## Expelled Tennessee Democrat Says His Constituents Are Now ‘Disenfranchised’
 - [https://www.dailywire.com/news/expelled-tennessee-democrat-says-his-constituents-are-now-disenfranchised](https://www.dailywire.com/news/expelled-tennessee-democrat-says-his-constituents-are-now-disenfranchised)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-09 13:03:55+00:00

Ousted Tennessee Democratic State Representative Justin Pearson claimed that voters in his district were &#8220;disenfranchised&#8221; by his expulsion. Pearson made the comments in an appearance on ABC&#8217;s &#8220;This Week.&#8221; Pearson and fellow Democratic State Rep. Justin Jones were expelled from the Tennessee House last week after they used a bullhorn to lead chants on the ...

## Former Bartender AOC Says Biden Should Ignore Court Ruling, Do What She Says
 - [https://www.dailywire.com/news/former-bartender-aoc-says-biden-should-ignore-court-ruling-do-what-she-says](https://www.dailywire.com/news/former-bartender-aoc-says-biden-should-ignore-court-ruling-do-what-she-says)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-09 12:51:00+00:00

Rep. Alexandria Ocasio-Cortez (D-NY) graduated from Boston University in 2011 with a Bachelor of Arts degree in both international relations and economics. Maybe she should have taken Law 101. The bartender-turned-lawmaker on Sunday said President Joe Biden should ignore the ruling of a federal judge who on Friday suspended the two-decade-old approval of the so-called ...

## Fans Go Wild As Trump Appears At UFC, Fighter Leads ‘Let’s Go Brandon’ Chant
 - [https://www.dailywire.com/news/fans-go-wild-as-trump-appears-at-ufc-fighter-leads-lets-go-brandon-chant](https://www.dailywire.com/news/fans-go-wild-as-trump-appears-at-ufc-fighter-leads-lets-go-brandon-chant)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-09 12:30:42+00:00

Days after pleading not guilty to criminal charges, former President Donald Trump received a warm welcome after he showed up Saturday evening at UFC 287 in Miami. Videos posted to social media showed Trump walking through the Kaseya Center, packed with cheering attendees. Trump himself is a fan of UFC, attending various fights over the ...

## Northern Ireland Terror Attack Fears Rise Ahead Of Biden Visit
 - [https://www.dailywire.com/news/northern-ireland-terror-attack-fears-rise-ahead-of-biden-visit](https://www.dailywire.com/news/northern-ireland-terror-attack-fears-rise-ahead-of-biden-visit)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-09 11:46:33+00:00

Authorities in Northern Ireland uncovered what could be evidence of a dissident plan for violence ahead of a visit by President Joe Biden, according to local reports. Leaders, including Biden, are expected to gather in Northern Ireland this week to celebrate the 25th anniversary of the Good Friday Agreement, an accord which effectively put an ...

## China Simulates ‘Precision Strikes’ On ‘Key’ Targets In Taiwan After President’s U.S. Visit
 - [https://www.dailywire.com/news/china-simulates-precision-strikes-on-key-targets-in-taiwan-after-presidents-u-s-visit](https://www.dailywire.com/news/china-simulates-precision-strikes-on-key-targets-in-taiwan-after-presidents-u-s-visit)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-04-09 11:23:52+00:00

Following Taiwan President Tsai Ing-wen’s trip to the United States last week, the Chinese military is simulating attacks on “key targets” in Taiwan in a second day of drills many experts believe are intended to intimidate the small island nation.  On Friday, Tsai returned from her visit to America, during which she met with House ...

