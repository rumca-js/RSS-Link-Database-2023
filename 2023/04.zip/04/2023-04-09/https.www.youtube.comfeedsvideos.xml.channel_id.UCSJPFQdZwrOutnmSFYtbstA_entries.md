# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Star Wars - Somehow... Rey Palpatine Returned
 - [https://www.youtube.com/watch?v=fGdiXChH02o](https://www.youtube.com/watch?v=fGdiXChH02o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2023-04-09 17:30:20+00:00

Great news, everyone! As announced by Kathleen Kennedy at Star Wars Celebration 2023, Rey Skywalker is back in Star Wars! I bet you were all looking forward to that one, eh? 

Want to help support this channel? 
Check out my books on Amazon: https://www.amazon.com/Will-Jordan/e/B00BCO7SA8/ref=dp_byline_cont_pop_ebooks_1
Subscribe on Patreon: https://www.patreon.com/TheCriticalDrinker
Subscribe on Subscribestar: https://www.subscribestar.com/the-critical-drinker

