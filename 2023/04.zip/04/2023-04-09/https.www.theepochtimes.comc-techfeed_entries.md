# Source:Epoch Times Tech, URL:https://www.theepochtimes.com/c-tech/feed/, language:en-US

## Apple Issues Emergency Updates to IPhones After Exploits Found
 - [https://www.theepochtimes.com/apple-issues-emergency-updates-to-iphones-after-exploits-found_5182255.html](https://www.theepochtimes.com/apple-issues-emergency-updates-to-iphones-after-exploits-found_5182255.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2023-04-09 19:29:10+00:00

A woman uses her iPhone in a file photo) JACK GUEZ/AFP via Getty Images)

