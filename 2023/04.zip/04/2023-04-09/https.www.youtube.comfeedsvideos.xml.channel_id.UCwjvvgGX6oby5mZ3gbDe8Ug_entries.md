# Source:China Insights, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwjvvgGX6oby5mZ3gbDe8Ug, language:en-US

## Unfortunately, his actress ex-girlfriend has top powerful connections/What’s Behind the Scandal?
 - [https://www.youtube.com/watch?v=dDDVSPA3w_A](https://www.youtube.com/watch?v=dDDVSPA3w_A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwjvvgGX6oby5mZ3gbDe8Ug
 - date published: 2023-04-09 17:30:08+00:00

#chinainsights 
Since the weekend of April 2nd, the buzz in China has been about Zhang Jike, a leading table tennis player in China's sporting circles. His scandal has continued to unfold, and there is no sign of it cooling down. 
In China, when a celebrity scandal suddenly becomes a social phenomenon, and the highest political and legal authorities start to intervene, it has gone well beyond a mere scandal in the ordinary sense and must be linked to some bigger operations in society. 

Have questions? Do you have something to share with us about China? We want to hear from you! 
Email: Cinsights.subscription@gmail.com
Facebook www.facebook.com/EyesOnChina.

Your support allows us to produce more high-quality videos. 
Consider donating at https://www.paypal.com/paypalme/ChinaInsights

Copyright @ China Insights 2021. Any illegal reproduction of this content in any form will result in immediate action against the person(s) concerned.

