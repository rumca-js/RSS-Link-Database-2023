# Source:Instalki.pl, URL:https://www.instalki.pl, language:pl-PL

## Coś, co wygląda jak głośnik JBL pozwala ukraść auto w 2 minuty - Instalki.pl
 - [https://www.instalki.pl/aktualnosci/bezpieczenstwo/58739-cos-co-wyglada-jak-glosnik-jbl-pozwala-ukrasc-auto-w-2-minuty.html](https://www.instalki.pl/aktualnosci/bezpieczenstwo/58739-cos-co-wyglada-jak-glosnik-jbl-pozwala-ukrasc-auto-w-2-minuty.html)
 - RSS feed: https://www.instalki.pl
 - date published: 2023-04-09 19:40:31.015974+00:00

Coś, co wygląda jak głośnik JBL pozwala ukraść auto w 2 minuty - Instalki.pl

## Aplikacje do rozpoznawania roślin mogą być niebezpieczne - Instalki.pl
 - [https://www.instalki.pl/aktualnosci/software/58740-aplikacje-do-rozpoznawania-roslin.html](https://www.instalki.pl/aktualnosci/software/58740-aplikacje-do-rozpoznawania-roslin.html)
 - RSS feed: https://www.instalki.pl
 - date published: 2023-04-09 17:32:10.079845+00:00

Aplikacje do rozpoznawania roślin mogą być niebezpieczne - Instalki.pl

## 5 nowych easter eggów w Google. Sprawdź ukryte funkcje - Instalki.pl
 - [https://www.instalki.pl/aktualnosci/internet/58735-5-nowych-easter-eggow-google-triki.html](https://www.instalki.pl/aktualnosci/internet/58735-5-nowych-easter-eggow-google-triki.html)
 - RSS feed: https://www.instalki.pl
 - date published: 2023-04-09 17:32:09.808203+00:00

5 nowych easter eggów w Google. Sprawdź ukryte funkcje - Instalki.pl

## Microsoft sprzedawał oprogramowanie rosyjskim firmom objętym sankcjami - Instalki.pl
 - [https://www.instalki.pl/aktualnosci/software/58741-microsoft-sprzedawal-oprogramowanie-rosyjskim-firmom-objetym-sankcjami.html](https://www.instalki.pl/aktualnosci/software/58741-microsoft-sprzedawal-oprogramowanie-rosyjskim-firmom-objetym-sankcjami.html)
 - RSS feed: https://www.instalki.pl
 - date published: 2023-04-09 17:32:09.555453+00:00

Microsoft sprzedawał oprogramowanie rosyjskim firmom objętym sankcjami - Instalki.pl

## Google przez przypadek wysyłało pieniądze użytkownikom - Instalki.pl
 - [https://www.instalki.pl/aktualnosci/rozrywka/58742-google-pay-blad-wysylanie-pieniedzy.html](https://www.instalki.pl/aktualnosci/rozrywka/58742-google-pay-blad-wysylanie-pieniedzy.html)
 - RSS feed: https://www.instalki.pl
 - date published: 2023-04-09 17:32:07.151011+00:00

Google przez przypadek wysyłało pieniądze użytkownikom - Instalki.pl

## 82-latka odebrała telefon. Chwilę później wyrzuciła 160 tys. złotych przez balkon - Instalki.pl
 - [https://www.instalki.pl/aktualnosci/bezpieczenstwo/58738-82-latka-odebrala-telefon-potem-wyrzucila-160-tys-zlotych-przez-balkon.html](https://www.instalki.pl/aktualnosci/bezpieczenstwo/58738-82-latka-odebrala-telefon-potem-wyrzucila-160-tys-zlotych-przez-balkon.html)
 - RSS feed: https://www.instalki.pl
 - date published: 2023-04-09 17:32:06.847995+00:00

82-latka odebrała telefon. Chwilę później wyrzuciła 160 tys. złotych przez balkon - Instalki.pl

## Activision trolluje oszustów w grach w cudowny sposób - Instalki.pl
 - [https://www.instalki.pl/aktualnosci/gry/58737-activision-trolluje-oszustow-w-grach-w-cudowny-sposob.html](https://www.instalki.pl/aktualnosci/gry/58737-activision-trolluje-oszustow-w-grach-w-cudowny-sposob.html)
 - RSS feed: https://www.instalki.pl
 - date published: 2023-04-09 17:32:06.499313+00:00

Activision trolluje oszustów w grach w cudowny sposób - Instalki.pl

## Złodzieje wycięli dziurę w toalecie. Ukradli iPhone'y za 2 miliony złotych - Instalki.pl
 - [https://www.instalki.pl/aktualnosci/hardware/58736-zlodzieje-wycieli-dziure-w-toalecie-ukradli-iphone-y-za-2-miliony-zlotych.html](https://www.instalki.pl/aktualnosci/hardware/58736-zlodzieje-wycieli-dziure-w-toalecie-ukradli-iphone-y-za-2-miliony-zlotych.html)
 - RSS feed: https://www.instalki.pl
 - date published: 2023-04-09 17:32:06.168604+00:00

Złodzieje wycięli dziurę w toalecie. Ukradli iPhone'y za 2 miliony złotych - Instalki.pl

