# Source:Money PL, URL:https://www.money.pl/rss/, language:pl-PL

## System handlu emisjami. Samorządy mają propozycje dla rządu. "Miliony są przejadane"
 - [https://www.money.pl/gospodarka/system-handlu-emisjami-samorzady-maja-propozycje-dla-rzadu-miliony-sa-przejadane-6884780278586272a.html](https://www.money.pl/gospodarka/system-handlu-emisjami-samorzady-maja-propozycje-dla-rzadu-miliony-sa-przejadane-6884780278586272a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-04-09 10:12:54+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/56b15305-bff3-4399-a226-13b94869bf37" width="308" /> Samorządy w sprawie transformacji energetycznej miast stawiają sprawę jasno - to się nie uda bez konkretnych działań rządu. Związek Miast Polskich chce m.in. zmian dotyczących cen energii czy gazu oraz przeznaczenia na energetykę lokalną przynajmniej połowy dochodów z tytułu sprzedaży uprawnień do emisji CO2.

## Miara sukcesu według Warrena Buffetta. Bez tego "twoje życie jest katastrofą"
 - [https://www.money.pl/pieniadze/miara-sukcesu-wedlug-warrena-buffetta-bez-tego-twoje-zycie-jest-katastrofa-6884877155113888a.html](https://www.money.pl/pieniadze/miara-sukcesu-wedlug-warrena-buffetta-bez-tego-twoje-zycie-jest-katastrofa-6884877155113888a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-04-09 07:15:21+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/23c15115-de44-4501-b058-48bdd99b2197" width="308" /> Warren Buffett, znany, podziwiany i naśladowany na całym świecie inwestor, chętnie dzieli się nie tylko swoimi poradami dotyczącymi finansów. Podczas wystąpienia na Uniwersytecie Georgii Buffett przedstawił własną definicję tego, czym jest prawdziwy życiowy sukces.

## ChatGPT zablokowany, kolejne kraje myślą o podobnym kroku. "Włosi dali sygnał"
 - [https://www.money.pl/gospodarka/chatgpt-zablokowany-kolejne-kraje-mysla-o-podobnym-kroku-wlosi-dali-sygnal-6884970980604832a.html](https://www.money.pl/gospodarka/chatgpt-zablokowany-kolejne-kraje-mysla-o-podobnym-kroku-wlosi-dali-sygnal-6884970980604832a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-04-09 06:56:28+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/9171c3bd-8657-42f0-b641-0b3cb74af1d0" width="308" /> Włochy mają wątpliwości co do przetwarzania danych osobowych przez ChatGPT. Dopóki OpenAI ich nie wyjaśni, to mieszkańcy Półwyspu Apenińskiego nie mogą korzystać z chatbota. Inne kraje też rozważają taką decyzję, choć nie należy do nich Polska. Zdaniem eksperta Włosi pokazali, że AI podlega pod prawo UE.

## Niebieska Karta – najczęściej zadawane pytania
 - [https://www.money.pl/gospodarka/niebieska-karta-najczesciej-zadawane-pytania-6884812504906656a.html](https://www.money.pl/gospodarka/niebieska-karta-najczesciej-zadawane-pytania-6884812504906656a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-04-09 06:50:38+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/6ced1d0e-66c0-45ee-9061-e83e12ea4c72" width="308" /> Kilkadziesiąt tysięcy Polaków na co dzień doświadcza przemocy w rodzinie. Jak wskazują statystyki policyjne, ponad 71 tys. osób znajduje się w grupie, wobec której funkcjonariusze podejrzewają, że są dotknięte taką sytuacją. W przypadku tych, którzy są ofiarą znęcania się w swoim domu, można uruchomić procedurę Niebieskiej Karty. W 2022 roku założono ich 61 tys. Sprawdź najczęściej zadawane pytania dotyczące Niebieskiej Karty i odpowiedzi ekspertów.

## Alarmujące dane z Niemiec. Co trzy dni na budowie ginie pracownik
 - [https://www.money.pl/gospodarka/alarmujace-dane-z-niemiec-co-trzy-dni-na-budowie-ginie-pracownik-6885454175108000a.html](https://www.money.pl/gospodarka/alarmujace-dane-z-niemiec-co-trzy-dni-na-budowie-ginie-pracownik-6885454175108000a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-04-09 05:44:38+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/5fe6cfa7-c748-456e-883f-d638f061c85f" width="308" /> 74 pracowników budowlanych zostało śmiertelnie rannych w 2022 roku. Związkowcy alarmują i skarżą się na braki w bezpieczeństwie pracy - informuje Deutsche Welle, dodając, że łącznie odnotowano 99 380 wypadków w budownictwie.

## Import zboża z Ukrainy wstrzymany co najmniej do lipca
 - [https://www.money.pl/gospodarka/import-zboza-z-ukrainy-wstrzymany-co-najmniej-do-lipca-6885437451639712a.html](https://www.money.pl/gospodarka/import-zboza-z-ukrainy-wstrzymany-co-najmniej-do-lipca-6885437451639712a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-04-09 04:36:39+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/29b5a4d7-bddc-4189-b1ca-78e33362b59a" width="308" /> Import zboża z Ukrainy będzie czasowo wstrzymany co najmniej do lipca - poinformował  w TVP Info wiceminister rolnictwa Janusz Kowalski. Poinformował także, że we wtorek minister rolnictwa Robert Telus "spotka się na granicy ze związkami z pięciu innych państw".

