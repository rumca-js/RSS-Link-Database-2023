# Source:Forsal.pl, URL:https://forsal.pl/.feed, language:pl-PL

## Macron: To nie czas na negocjacje pokojowe w wojnie na Ukrainie
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8696658,macron-to-nie-czas-na-negocjacje-pokojowe-w-wojnie-na-ukrainie.html](https://forsal.pl/swiat/unia-europejska/artykuly/8696658,macron-to-nie-czas-na-negocjacje-pokojowe-w-wojnie-na-ukrainie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-09 19:40:49+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/eo0ktkuTURBXy85NmI4OTliMy1lNGFiLTRjMzUtOTEzYi04YjM3ODQwNDQ2ZDguanBlZ5GTBc0BHcyg" />Prezydent Francji Emmanuel Macron, wypowiadając się w niedzielę dla francuskich mediów, powiedział, że biorąc pod uwagę obecny rozwój wydarzeń, jest za wcześnie na rozmowy pokojowe.

## "Washington Post": Wywiad USA odkrył, że Grupa Wagnera próbowała kupować broń w Turcji
 - [https://forsal.pl/swiat/rosja/artykuly/8696657,wp-wywiad-usa-odkryl-ze-grupa-wagnera-probowala-kupowac-bron-w-turcji.html](https://forsal.pl/swiat/rosja/artykuly/8696657,wp-wywiad-usa-odkryl-ze-grupa-wagnera-probowala-kupowac-bron-w-turcji.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-09 19:36:36+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/HhmktkuTURBXy82MDgwYmEwNi02NTJmLTQxNjYtOTViZC01MTg2NjEzNzg0ODQuanBlZ5GTBc0BHcyg" />Niektóre z dokumentów wywiadu USA, które zostały ujawnione w ostatnich dniach w mediach społecznościowych, zawierają informacje, z których wynika, że najemnicy Grupy Wagnera próbowali kupić broń w Turcji - informuje w sobotę &quot;Washington Post&quot; (WP).

## Dwóch policjantów z Wisconsin zabitych w strzelaninie
 - [https://forsal.pl/swiat/usa/artykuly/8696582,dwoch-policjantow-z-wisconsin-zabitych-w-strzelaninie.html](https://forsal.pl/swiat/usa/artykuly/8696582,dwoch-policjantow-z-wisconsin-zabitych-w-strzelaninie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-09 18:24:33+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/3LbktkuTURBXy9hNmFlNmRiNS04ZmYyLTRmYjgtYjE5ZS04ZTdhMjQ1ZDVlNWMuanBlZ5GTBc0BHcyg" />Dwóch policjantów z Wisconsin zginęło w trakcie strzelaniny, do której doszło w trakcie kontroli drogowej. Zabity został też napastnik – podał w niedzielę „Milwaukee Journal Sentinel”.

## Łotwa dobuduje kolejne  kilkadziesiąt kilometrów ogrodzenia na granicy z Białorusią
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8696580,lotwa-dobuduje-kolejne-kilkadziesiat-kilometrow-ogrodzenia-na-granicy-z-bialorusia.html](https://forsal.pl/swiat/unia-europejska/artykuly/8696580,lotwa-dobuduje-kolejne-kilkadziesiat-kilometrow-ogrodzenia-na-granicy-z-bialorusia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-09 18:17:16+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ejxktkuTURBXy9hNzg3NzA0ZS0wMjhiLTRkMzctOGZiNS1iODdhZGEyMWMyNjIuanBlZ5GTBc0BHcyg" />W kwietniu na Łotwie ruszy kolejny etap budowy ogrodzenia na granicy z Białorusią, który przewiduje postawienie ok. 64 km zabezpieczeń - informuje w niedzielę portal Delfi. Dotychczas zbudowano 54 km płotu.

## Macron dla Politico: Europa powinna unikać międzynarodowych kryzysów i nie dać wciągać w konflikt o Tajwan
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8696574,macron-dla-politico-europa-bez-miedzynarodowych-kryzysow.html](https://forsal.pl/swiat/unia-europejska/artykuly/8696574,macron-dla-politico-europa-bez-miedzynarodowych-kryzysow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-09 17:17:40+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Y7nktkuTURBXy9kZDhmOTM5OC0yNTg4LTQ5YmYtYjg1Yy1kZjgzNjBiYmZhY2YuanBlZ5GTBc0BHcyg" />Prezydent Francji Emmanuel Macron w drodze powrotnej z wizyty w Chinach, powiedział, że Europa musi się oprzeć presji, by stać się &quot;naśladowcą Ameryki&quot;. Odnosząc się do napięć między Państwem Środka a USA w sprawie statusu Tajwanu, ostrzegł, że wielkim ryzykiem dla Europy jest &quot;uwikłanie się w kryzysy, które nie są nasze&quot;. Macron rozmawiał na pokładzie samolotu z dziennikarzami, między innymi Politico.

## Estonia będzie mieć nowy rząd. Politycy zawarli umowę koalicyjną
 - [https://forsal.pl/artykuly/8696571,estonia-bedzie-miec-nowy-rzad-politycy-zawarli-umowe-koalicyjna.html](https://forsal.pl/artykuly/8696571,estonia-bedzie-miec-nowy-rzad-politycy-zawarli-umowe-koalicyjna.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-09 17:06:42+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/CByktkuTURBXy80YjE1ZjIyMS00MzI1LTQ2OWUtOWYwOS00Nzc2ODM2YzQ1ZjAuanBlZ5GTBc0BHcyg" />Negocjujące nowy rząd Estonii ugrupowania, Estońska Partia Reform, Eesti 200 i Partia Socjaldemokratyczna, zawarły umowę koalicyjną, w ramach której przewidziane jest m.in. podniesienie podatków VAT i dochodowego oraz pogłębienie współpracy regionalnej.

## Dr Węgrzyn: Wojna w Ukrainie może zniszczyć wszystkie populacje delfinów w Morzu Czarnym
 - [https://forsal.pl/lifestyle/nauka/artykuly/8696569,wegrzyn-wojna-w-ukrainie-delfinom-z-morza-czarnego-grozi-wyginiecie.html](https://forsal.pl/lifestyle/nauka/artykuly/8696569,wegrzyn-wojna-w-ukrainie-delfinom-z-morza-czarnego-grozi-wyginiecie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-09 16:37:11+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/6TGktkuTURBXy8wNjFhNjE1ZS1mZmIzLTRkYjMtOGNlMi03ZjAzZGEyN2I4MWMuanBlZ5GTBc0BHcyg" />Delfiny i morświny z Morza Czarnego to kolejne ofiary wojny w Ukrainie. Szacujemy, że tylko w ciągu trzech miesięcy zginęło pomiędzy 37 a 48 tys. tych morskich ssaków, wyniki naszych badań są porażające – powiedziała PAP dr hab. Ewa Węgrzyn, profesor Uniwersytetu Rzeszowskiego.

## Hezbollah i Hamas na drodze do porozumienia. Jednoczą się w związku z eskalacją działań Izraela
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8696567,hezbollah-i-hamas-na-drodze-do-porozumienia-przeciw-izraelowi.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8696567,hezbollah-i-hamas-na-drodze-do-porozumienia-przeciw-izraelowi.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-09 16:23:07+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/8ZdktkuTURBXy85Njc4N2Y0My0zYTczLTRhMjctOTdkOC03M2E4NmVkYThkNDcuanBlZ5GTBc0BHcyg" />Przywódca libańskiego Hezbollahu Sajed Hassan Nasrallah spotkał się w niedzielę w Bejrucie z delegacją Hamasu, której przewodniczył Ismail Haniyeh, aby przedyskutować współpracę, w obliczu eskalacji przemocy w Izraelu - podał portal The Times of Israel.

## Marsylia: Od 4 do 10 osób może się znajdować pod gruzami zawalonego budynku
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8696563,marsylia-od-4-do-10-osob-moze-byc-pod-gruzami-zawalonego-budynku.html](https://forsal.pl/swiat/unia-europejska/artykuly/8696563,marsylia-od-4-do-10-osob-moze-byc-pod-gruzami-zawalonego-budynku.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-09 15:36:07+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/OQ6ktkuTURBXy9hOGZiZWUzNi0zZmRmLTRkNDUtYTU1OS01ZGIyNjgwZmJjZjIuanBlZ5GTBc0BHcyg" />W Marsylii zawalił się w nocy z soboty na niedzielę budynek mieszkalny, w którym wybuchł pożar uniemożliwiający ratownikom dotarcie do ofiar. Na miejsce katastrofy przybył szef MSW Francji Gerald Darmanin, który przekazał, że pod gruzami jest od czterech do 10 osób.

## Plac zabaw dla superbogaczy. Ile kosztuje życie w Dubaju?
 - [https://forsal.pl/gospodarka/inflacja/artykuly/8694210,ile-kosztuje-zycie-w-dubaju-ceny-wynajmu-mieszkan-ceny-zywnosci.html](https://forsal.pl/gospodarka/inflacja/artykuly/8694210,ile-kosztuje-zycie-w-dubaju-ceny-wynajmu-mieszkan-ceny-zywnosci.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-09 12:09:29+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/6uYktkuTURBXy81OTQ0NGIxZC1lOTRjLTRhMjktOTZkZS1hMWYzYTNmZDc2NmQuanBlZ5GTBc0BHcyg" />Gdy miliarderzy kupowali wille w Dubaju, a miasto pękało w szwach od nowych bankierów i dyrektorów, Ghida została eksmitowana, bo właściciel znalazł sposób na podwojenie czynszu za lokal, za który ona i jej mąż płacili około 3000 dolarów miesięcznie.

## Sprawdziliśmy, na jak długo wystarczy bateria elektryka w upale i mrozie
 - [https://forsal.pl/motoforsal/aktualnosci/artykuly/8696128,bateria-auto-elektryczne-upal-mroz-zuzycie-energii.html](https://forsal.pl/motoforsal/aktualnosci/artykuly/8696128,bateria-auto-elektryczne-upal-mroz-zuzycie-energii.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-09 10:22:05+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/MdxktktTURBXy83YmU2NWVkZS01NmRhLTRkNGYtYmVmYy1iOGE5MTViYzZhODMucG5nkZMFzQEdzKA" />Wielogodzinny korek w upale +40 st. C lub długie oczekiwanie w aucie na pomoc przy -20 st. C. Takie scenariusze snują osoby obawiające się przesiadki do elektryka. Sprawdziliśmy na ile wystarczy baterii w takich warunkach. Z artykułu dowiecie się też ile mocy pobiera silnik, klimatyzacja, ogrzewanie, radio, światła czy komputer samochodu elektrycznego.

## Giles zChatham House: Rosja coraz bardziej przypomina ZSRR
 - [https://forsal.pl/swiat/rosja/artykuly/8696542,giles-z-chatham-house-rosja-coraz-bardziej-przypomina-zsrr.html](https://forsal.pl/swiat/rosja/artykuly/8696542,giles-z-chatham-house-rosja-coraz-bardziej-przypomina-zsrr.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-09 10:21:48+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/GQgktkuTURBXy85YTY1NGI2Ni1jMmViLTQxM2ItOTQxMS0zYmU2ZmQzMzZhZTEuanBlZ5GTBc0BHcyg" />Upodabnianie putinowskiej Rosji do Związku Sowieckiego nie jest niczym zaskakującym, patrząc na całą historię Rosji jest to raczej powrót do typowego stanu – mówi PAP Keir Giles, ekspert z Królewskiego Instytutu Spraw Międzynarodowych (Chatham House) w Londynie.

## Murowany spadek zamówień w budownictwie. Którym sektorom grozi zapaść?
 - [https://forsal.pl/nieruchomosci/aktualnosci/artykuly/8695701,spadek-zamowien-w-budownictwie-ktorym-sektorom-grozi-zapasc.html](https://forsal.pl/nieruchomosci/aktualnosci/artykuly/8695701,spadek-zamowien-w-budownictwie-ktorym-sektorom-grozi-zapasc.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-09 10:11:38+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/rJlktkuTURBXy8wZmFkMDkyZS0zZDE1LTQ2NzEtODAzNy04MDEyZTMyMzhhYTYuanBlZ5GTBc0BHcyg" />Pozwoleń na budowę wydanych w 2022 r. było o ponad jedną czwartą mniej niż rok wcześniej – podał Główny Urząd Nadzoru Budowlanego. Eksperci GetHome.pl sprawdzili, którym sektorom budownictwa może grozić zapaść.

## Smartfony są drogie. Z czego to wynika i czy kiedyś się zmieni?
 - [https://forsal.pl/lifestyle/technologie/artykuly/8696186,smartfony-sa-drogie-z-czego-to-wynika-i-czy-kiedys-sie-zmieni.html](https://forsal.pl/lifestyle/technologie/artykuly/8696186,smartfony-sa-drogie-z-czego-to-wynika-i-czy-kiedys-sie-zmieni.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-09 10:11:10+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Gj8ktkuTURBXy9iOTNiODg2NC01ZjM3LTQ3MTUtODdiZC1iNWIzMTFlNmQ0M2YuanBlZ5GTBc0BHcyg" />Ceny elektroniki wystrzeliły i doskonale widać to na przykładzie telefonów. Za kwoty które rok czy dwa lata temu trzeba było wydać na dobrego średniaka, dziś kupimy budżetowe urządzenie.

## Demencja – czy jest nieunikniona? Oto kilka rad, jak można jej zapobiec
 - [https://forsal.pl/lifestyle/zdrowie/artykuly/8696113,demencja-czy-jest-nieunikniona-jak-jej-zapobiec.html](https://forsal.pl/lifestyle/zdrowie/artykuly/8696113,demencja-czy-jest-nieunikniona-jak-jej-zapobiec.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-09 10:10:18+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/9NektkuTURBXy8xZDdlYTA4Yy1lMjI2LTQ1NGItYmM2OC05ZWJhNzNkZjYzZGMuanBlZ5GTBc0BHcyg" />Wraz z wiekiem wzrasta ryzyko rozwoju demencji, jednak wprowadzając kilka prostych nawyków, możemy znacznie zmniejszyć prawdopodobieństwo, że schorzenie dotknie również nas.

## 9 chińskich okrętów i 58 samolotów prowadzi ćwiczenia wojskowe wokół Tajwanu
 - [https://forsal.pl/swiat/chiny/artykuly/8696534,9-chinskich-okretow-i-58-samolotow-wojskowych-cwiczy-wokol-tajwanu.html](https://forsal.pl/swiat/chiny/artykuly/8696534,9-chinskich-okretow-i-58-samolotow-wojskowych-cwiczy-wokol-tajwanu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-09 09:03:16+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/b7JktkuTURBXy8wZGIxN2NjNS02MzE2LTQxNjgtYTY0ZS05YjQ1NjI5NGM5YWIuanBlZ5GTBc0BHcyg" />W ramach trzydniowych ćwiczeń wojskowych w niedzielę wokół Tajwanu manewry prowadzi 9 chińskich okrętów i 58 samolotów, w tym myśliwce i bombowce - poinformowało tajwańskie ministerstwo obrony. USA zapewniły, że mają wystarczające środki i siły, by zapewnić pokój i stabilność w regionie.

## ISW: Rosyjski atak słabnie. Ostrzał artyleryjski maskuje brak żołnierzy piechoty
 - [https://forsal.pl/swiat/ukraina/artykuly/8696533,isw-rosyjski-atak-slabnie-artyleria-maskuje-brak-piechoty.html](https://forsal.pl/swiat/ukraina/artykuly/8696533,isw-rosyjski-atak-slabnie-artyleria-maskuje-brak-piechoty.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-09 08:54:49+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/G58ktkuTURBXy82YWQ3OGE0MS05ZWNlLTQxMWMtYThkNC1jM2RhOGExNDUwZjEuanBlZ5GTBc0BHcyg" />Armia rosyjska używa artylerii, by zrekompensować zmniejszenie potencjału ofensywnego na froncie, a sama ofensywa najwyraźniej wygasa – ocenia w niedzielę Instytut Badań nad Wojną (ISW), analizując doniesienia z pola walki na Ukrainie.

## The Telegraph: Putin wrócił na Twittera. Czy Musk zaczął popierać Rosję?
 - [https://forsal.pl/biznes/media/artykuly/8696530,the-telegraph-putin-wrocil-na-twittera-czy-musk-zaczal-popierac-rosje.html](https://forsal.pl/biznes/media/artykuly/8696530,the-telegraph-putin-wrocil-na-twittera-czy-musk-zaczal-popierac-rosje.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-09 08:40:49+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/gpsktkuTURBXy8yMGU5NWQ4Ni1jODYyLTQ2NzQtOGQ5MS01NmM4OWYyNDY5ODcuanBlZ5GTBc0BHcyg" />Twitter usunął ograniczenia dotyczące kont powiązanych z Kremlem wprowadzone po rozpoczęciu przez Rosję inwazji na Ukrainę. Badania przeprowadzone przez The Telegraph w ubiegłym tygodniu wskazują, że firma Elona Muska nie ogranicza już zasięgu rosyjskim władzom i organizacjom medialnym.

## W centrum Marsylii zawalił się budynek mieszkalny. W ruinach wybuchł pożar
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8696520,w-centrum-marsylii-zawalil-sie-budynek-mieszkalny-pozar-w-ruinach.html](https://forsal.pl/swiat/unia-europejska/artykuly/8696520,w-centrum-marsylii-zawalil-sie-budynek-mieszkalny-pozar-w-ruinach.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-09 06:44:19+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/AxektkuTURBXy8xZjNhMDNiNS1kMWY4LTQwZjMtYWJhNC1kNWE4MTc1MGU3MDguanBlZ5GTBc0BHcyg" />W centrum Marsylii zawalił się w nocy z soboty na niedzielę czteropiętrowy budynek mieszkalny. Wybuchł pożar, który uniemożliwia służbom ratunkowym dotarcie do ewentualnych ofiar - poinformował mer miasta Benoit Payan.

## Izrael odpowiedział na atak rakietowy z terytorium Syrii
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8696519,izrael-odpowiedzial-na-atak-rakietowy-z-terytorium-syrii.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8696519,izrael-odpowiedzial-na-atak-rakietowy-z-terytorium-syrii.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-09 06:32:29+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/UuLktkuTURBXy82N2M1ZmUwNy1mZWQ3LTQzYTgtODNlMy1jYzhjZmVkNzE0ODEuanBlZ5GTBc0BHcyg" />Izraelski rzecznik wojskowy poinformował w ncy z soboty na niedzielę, że z Syrii wystrzelono 3 rakiety w kierunku Izraela, z których tylko jedna zdołała osiągnąć terytorium izraelskie. Atak, rzadki z tego kierunku, nastąpił po serii aktów przemocy w Jerozolimie, Tel Awiwie i w rejonie Strefy Gazy. W ślad za artylerią, izraelskie lotnictwo zaatakowało w niedzielę cele wojskowe w Syrii w odpowiedzi na ataki rakietowe z terytorium syryjskiego dokonane w nocy z soboty na niedzielę - poinformował izraelski rzecznik wojskowy.

## PIE: Polacy wolą mieć własne mieszkania i domy. Większość z nich powstała na początku lat 90-tych
 - [https://forsal.pl/nieruchomosci/mieszkania/artykuly/8696518,pie-polacy-wola-miec-wlasne-mieszkania-i-domy-wiekszosc-z-nich-powstala-na-poczatku-lat-90-tych.html](https://forsal.pl/nieruchomosci/mieszkania/artykuly/8696518,pie-polacy-wola-miec-wlasne-mieszkania-i-domy-wiekszosc-z-nich-powstala-na-poczatku-lat-90-tych.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-09 06:24:14+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/np3ktkuTURBXy8yNWU2MzM1OC1mODc4LTRmYWQtOWY1OC1iNWE2OGZjN2Y4YzcuanBlZ5GTBc0BHcyg" />Polska ma jeden z największych w Europie i większy niż średnia unijna odsetek własności mieszkań i domów - wskazał Polski Instytut Ekonomiczny. Analitycy PIE zwrócili uwagę na duży udział mieszkań wybudowanych do lat 90. oraz wysoki odsetek ludzi młodych mieszkających z rodzicami.

## PKP PLK przeznaczy 3 mld złotych z Krajowego Planu Kolejowego na inwestycje na Podkarpaciu
 - [https://forsal.pl/transport/kolej/artykuly/8696513,krajowy-plan-kolejowy-3-mld-zlotych-na-inwestycje-na-podkarpaciu.html](https://forsal.pl/transport/kolej/artykuly/8696513,krajowy-plan-kolejowy-3-mld-zlotych-na-inwestycje-na-podkarpaciu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-09 06:09:30+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/sg-ktkuTURBXy8yYjlmYzFmMy05MDcxLTQ5MjItYTJiOC04ZjZmN2U2YzJhNTcuanBlZ5GTBc0BHcyg" />Na Podkarpaciu w ramach Krajowego Planu Kolejowego wydatkowanych będzie na inwestycje w sumie 3 mld zł. Kluczowym punktem była zakończona już modernizacja stacji Rzeszów Główny – powiedział PAP dyr. Regionu Południowego Centrum Realizacji Inwestycji PKP PLK Mateusz Wanat.

## Czy Ukrainę czeka kryzys demograficzny? Jak to wpłynie na wysiłki na rzecz jej odbudowy?
 - [https://forsal.pl/swiat/ukraina/artykuly/8695870,czy-ukraine-czeka-kryzys-demograficzny-jak-to-wplynie-na-wysilki-na-rzecz-jej-odbudowy.html](https://forsal.pl/swiat/ukraina/artykuly/8695870,czy-ukraine-czeka-kryzys-demograficzny-jak-to-wplynie-na-wysilki-na-rzecz-jej-odbudowy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-09 05:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/7urktkuTURBXy85NzZhOWM5MC03ZjYyLTRjMjctODA4NC1iYzliMjc1MTc2OWUuanBlZ5GTBc0BHcyg" />Kryzys demograficzny w Ukrainie może sparaliżować wysiłki na rzecz powojennej odbudowy tego kraju. A to zagroziłoby także Europie.

## Dlaczego ostracyzm to taki skuteczny mechanizm? Nawet socjopaci nie są na niego odporni
 - [https://forsal.pl/lifestyle/psychologia/artykuly/8695894,dlaczego-ostracyzm-to-taki-skuteczny-mechanizm-nawet-socjopaci-nie-sa-na-niego-odporni.html](https://forsal.pl/lifestyle/psychologia/artykuly/8695894,dlaczego-ostracyzm-to-taki-skuteczny-mechanizm-nawet-socjopaci-nie-sa-na-niego-odporni.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-09 05:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/lClktkuTURBXy80ZTY4NDFmZC1hMmY1LTQ3ZmEtOTljNC0yNGU5NWE3NjFhNWQuanBlZ5GTBc0BHcyg" />Nikt nie jest odporny na ostracyzm, nawet socjopaci. Właśnie dlatego jest to mechanizm tak potężny i skuteczny.

## Dusza ChatGPT zaprzedana wielkiej korporacji
 - [https://forsal.pl/lifestyle/technologie/artykuly/8695858,dusza-chatgpt-zaprzedana-wielkiej-korporacji.html](https://forsal.pl/lifestyle/technologie/artykuly/8695858,dusza-chatgpt-zaprzedana-wielkiej-korporacji.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-09 05:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/sRqktkuTURBXy80MzM4ZmZhMC1mOTI5LTQ2NzEtYTRkOC1kMDU2YTIwMTM5ODMuanBlZ5GTBc0BHcyg" />Sam Altman chciał rozwinąć technologię potężnej sztucznej inteligencji tak bardzo, że zaprzedał duszę ChatGPT wielkiej korporacji.

## No to mamy Nowy Świat. A czy jest on wspaniały? [OPINIA]
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8695833,no-to-mamy-nowy-swiat-a-czy-jest-on-wspanialy-opinia.html](https://forsal.pl/swiat/aktualnosci/artykuly/8695833,no-to-mamy-nowy-swiat-a-czy-jest-on-wspanialy-opinia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-09 05:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/MLrktkuTURBXy9hODI1MjNkZi03NTY4LTQ3MjEtOWFiZi1hMWY2YzhmMTNjYWEuanBlZ5GTBc0BHcyg" />No to mamy Nowy Świat. A czy jest on wspaniały? Na to pytanie niech każdy sam sobie odpowie. Ja tylko dodam, że jest inny. Świat stał się bardziej wielobiegunowy, niż był przez ostatnie pół wieku. USA nie są już jedynym supermocarstwem. Nie ma także dwóch rywalizujących bloków. Mamy Zachód, który nie jest – vide polityka względem Rosji – jednością. Na Wschodzie Chiny i Rosję wiąże taktyczny, ale jednak bardzo nierówny sojusz. A przecież są w tym wszystkim jeszcze kraje Zatoki Perskiej. Jest Ameryka Łacińska. Są Indie.

## Przyjaźń Moskwy z Pekinem jak przyjaźń Mao z ZSSR
 - [https://forsal.pl/swiat/chiny/artykuly/8695849,przyjazn-moskwy-z-pekinem-jak-przyjazn-mao-z-zssr.html](https://forsal.pl/swiat/chiny/artykuly/8695849,przyjazn-moskwy-z-pekinem-jak-przyjazn-mao-z-zssr.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-04-09 05:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/IrTktkuTURBXy9lZTNjZmJjZS1hNGFmLTQyMmItYjI0NS0yZTY0OTk4ZDE3YzguanBlZ5GTBc0BHcyg" />Obecna przyjaźń Moskwy z Pekinem układa się tak, jak spotkania Mao z liderami ZSRR. Miłe bywały one tylko przez chwilę, po czym silniejszy próbował zagarnąć wszystkie korzyści.

