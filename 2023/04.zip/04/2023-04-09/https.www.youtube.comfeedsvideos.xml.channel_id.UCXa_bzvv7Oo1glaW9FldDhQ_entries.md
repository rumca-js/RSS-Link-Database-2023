# Source:GamingBolt, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXa_bzvv7Oo1glaW9FldDhQ, language:en-US

## What Made Star Wars Jedi: Fallen Order One Hell of A Game
 - [https://www.youtube.com/watch?v=IWYo7PvF53I](https://www.youtube.com/watch?v=IWYo7PvF53I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXa_bzvv7Oo1glaW9FldDhQ
 - date published: 2023-04-09 15:30:04+00:00

Even if you're generally on the fence about Star Wars, it's a great way to jump into the franchise before playing Jedi: Survivor, and just an excellent action-adventure game in its own right.

## Redfall - 10 Ways It's DIFFERENT From Arkane's Previous Games
 - [https://www.youtube.com/watch?v=9Wj8jwoMCw8](https://www.youtube.com/watch?v=9Wj8jwoMCw8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXa_bzvv7Oo1glaW9FldDhQ
 - date published: 2023-04-09 13:30:03+00:00

With games like Dishonored and Prey under its belt, Arkane Studios has, by now, firmly established itself as one of the best developers of immersive sims in the industry. The studio has a very distinct style and flavour to all of its outings that set them apart from almost anything else we see these days, and it's continued to build on those design sensibilities with each of its new games. 

With the upcoming Redfall, Arkane says it's still doing a lot of what it's always been known for, but while it looks like player expression and emergent mechanics will still be at the center of the experience in the upcoming vampire shooter, it's also clear that it's going to be probably the most different game Arkane has made to date when compared to its past outings. 

Here, we're going to talk about a few things that look like they're going to set it apart from past titles by the developer.

