# Source:The Intercept, URL:https://theintercept.com/feed/?lang=en, language:en-US

## Elon Musk Wants to Cut Your Social Security Because He Doesn’t Understand Math
 - [https://theintercept.com/2023/04/09/elon-musk-social-security-cuts/](https://theintercept.com/2023/04/09/elon-musk-social-security-cuts/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2023-04-09 10:00:49+00:00

<p>No, Elon, Japan is not a “leading indicator” just because of your billionaire vibes.</p>
<p>The post <a href="https://theintercept.com/2023/04/09/elon-musk-social-security-cuts/" rel="nofollow">Elon Musk Wants to Cut Your Social Security Because He Doesn’t Understand Math</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>

