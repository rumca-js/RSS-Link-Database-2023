# Source:LaterClips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCtVGGeUqfVHOK4Q6nAwYO3g, language:en-US

## This Futuristic Building is Impossible
 - [https://www.youtube.com/watch?v=sah1L8gBjpw](https://www.youtube.com/watch?v=sah1L8gBjpw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtVGGeUqfVHOK4Q6nAwYO3g
 - date published: 2023-04-09 22:00:31+00:00

Latercase - https://latercase.com/lewlater 

Clip from Lew Later (Tesla Did What?!) - https://youtube.com/live/xyHsW2BciJM

## Tesla Really Messed Up
 - [https://www.youtube.com/watch?v=Vha4P-T7PVo](https://www.youtube.com/watch?v=Vha4P-T7PVo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtVGGeUqfVHOK4Q6nAwYO3g
 - date published: 2023-04-09 20:00:14+00:00

Latercase - https://latercase.com/lewlater 

Clip from Lew Later (Tesla Did What?!) - https://youtube.com/live/xyHsW2BciJM

## Tim Cook's Simple Solution To Your Problems
 - [https://www.youtube.com/watch?v=iRXrNQQuSYA](https://www.youtube.com/watch?v=iRXrNQQuSYA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtVGGeUqfVHOK4Q6nAwYO3g
 - date published: 2023-04-09 18:00:18+00:00

Latercase - https://latercase.com/lewlater

Clip from Lew Later (Apple's TikTok Strategy is Working...) - https://youtube.com/live/tsSAweoJlWM

## GTA 6's New Mode Is Unreal...
 - [https://www.youtube.com/watch?v=77-KVi4l8NY](https://www.youtube.com/watch?v=77-KVi4l8NY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtVGGeUqfVHOK4Q6nAwYO3g
 - date published: 2023-04-09 16:00:04+00:00

Clip from Lew Later (iPhone 15's Extreme Decision Will Change Everything) - https://youtube.com/live/MP9cVHZVaMc

## The Tri-Fold Smartphone Is Coming Sooner Than We Thought
 - [https://www.youtube.com/watch?v=hNzOsA9Y5Zo](https://www.youtube.com/watch?v=hNzOsA9Y5Zo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtVGGeUqfVHOK4Q6nAwYO3g
 - date published: 2023-04-09 14:00:23+00:00

Clip from Lew Later (Will Elon Musk's Twitter Recover?) - https://youtube.com/live/wdP5FgJO2Vs

## Cybertruck Easter Egg Was Hidden in Plain Sight
 - [https://www.youtube.com/watch?v=MlJvdhZpc4w](https://www.youtube.com/watch?v=MlJvdhZpc4w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtVGGeUqfVHOK4Q6nAwYO3g
 - date published: 2023-04-09 12:00:23+00:00

Clip from Lew Later (Will Elon Musk's Twitter Recover?) - https://youtube.com/live/wdP5FgJO2Vs

## Twitter's Stunning New Valuation Puts Everything Into Question
 - [https://www.youtube.com/watch?v=cmu_UkaUMDM](https://www.youtube.com/watch?v=cmu_UkaUMDM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtVGGeUqfVHOK4Q6nAwYO3g
 - date published: 2023-04-09 10:00:33+00:00

Clip from Lew Later (Will Elon Musk's Twitter Recover?) - https://youtube.com/live/wdP5FgJO2Vs

## Spotify's New AI Feature Is Cringe
 - [https://www.youtube.com/watch?v=qzhWhZhkHaI](https://www.youtube.com/watch?v=qzhWhZhkHaI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtVGGeUqfVHOK4Q6nAwYO3g
 - date published: 2023-04-09 08:00:24+00:00

Clip from Lew Later (iPhone 15's Extreme Decision Will Change Everything) - https://youtube.com/live/MP9cVHZVaMc

## Giant Meatball From An Extinct Species...
 - [https://www.youtube.com/watch?v=FTAAnsGBdlQ](https://www.youtube.com/watch?v=FTAAnsGBdlQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtVGGeUqfVHOK4Q6nAwYO3g
 - date published: 2023-04-09 06:00:09+00:00

Clip from Lew Later (iPhone 15's Extreme Decision Will Change Everything) - https://youtube.com/live/MP9cVHZVaMc

## AirTag Found In An Unusual Circumstance
 - [https://www.youtube.com/watch?v=usCV2v76m6s](https://www.youtube.com/watch?v=usCV2v76m6s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtVGGeUqfVHOK4Q6nAwYO3g
 - date published: 2023-04-09 04:00:32+00:00

Clip from Lew Later (iPhone 15's Extreme Decision Will Change Everything) - https://youtube.com/live/MP9cVHZVaMc

## Samsung Used ChatGPT...
 - [https://www.youtube.com/watch?v=nARNNm_-XAU](https://www.youtube.com/watch?v=nARNNm_-XAU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtVGGeUqfVHOK4Q6nAwYO3g
 - date published: 2023-04-09 02:00:17+00:00

Clip from Lew Later (What Did Elon Just Do?) - https://www.youtube.com/live/7iOjTFIHSCg

## YouTuber Paid The Price...
 - [https://www.youtube.com/watch?v=wwXM2D5ZK_Q](https://www.youtube.com/watch?v=wwXM2D5ZK_Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtVGGeUqfVHOK4Q6nAwYO3g
 - date published: 2023-04-09 00:00:17+00:00

Clip from Lew Later (What Did Elon Just Do?) - https://www.youtube.com/live/7iOjTFIHSCg

