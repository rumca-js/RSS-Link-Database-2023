# Source:penguinz0, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg, language:en-US

## WWE and UFC Merger Is Nuts
 - [https://www.youtube.com/watch?v=OjjddzBeJv4](https://www.youtube.com/watch?v=OjjddzBeJv4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg
 - date published: 2023-04-09 19:00:17+00:00

This is the greatest wrestling merger of All Time
Merch https://moistglobal.com/
I stream every day https://www.twitch.tv/moistcr1tikal

