# Source:MSN, URL:http://www.msn.com/rss/news.aspx, language:en-US

## Sen. Richard Blumenthal injured during basketball parade
 - [http://www.msn.com/en-us/news/politics/sen-richard-blumenthal-injured-during-basketball-parade/ar-AA19EYbH?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/sen-richard-blumenthal-injured-during-basketball-parade/ar-AA19EYbH?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 23:41:26.214353+00:00



## Caitlyn Jenner, Gay Republican Leader Vow to Take On 'Rainbow Mafia'
 - [http://www.msn.com/en-us/news/world/caitlyn-jenner-gay-republican-leader-vow-to-take-on-rainbow-mafia/ar-AA19EGJ5?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/caitlyn-jenner-gay-republican-leader-vow-to-take-on-rainbow-mafia/ar-AA19EGJ5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 23:41:26.202900+00:00



## Security concerns mount as Biden's Northern Ireland visit nears
 - [http://www.msn.com/en-us/news/world/security-concerns-mount-as-biden-s-northern-ireland-visit-nears/ar-AA19EGEE?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/security-concerns-mount-as-biden-s-northern-ireland-visit-nears/ar-AA19EGEE?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 23:41:26.193516+00:00



## Crime reporter's viral TikTok video shares what to do if you are home alone: 'Don't get quiet, make noise'
 - [http://www.msn.com/en-us/news/us/crime-reporter-s-viral-tiktok-video-shares-what-to-do-if-you-are-home-alone-don-t-get-quiet-make-noise/ar-AA19EOGt?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/crime-reporter-s-viral-tiktok-video-shares-what-to-do-if-you-are-home-alone-don-t-get-quiet-make-noise/ar-AA19EOGt?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 23:41:26.185756+00:00



## Why the ousted Tennessee lawmakers could be back in the statehouse soon
 - [http://www.msn.com/en-us/news/politics/why-the-ousted-tennessee-lawmakers-could-be-back-in-the-statehouse-soon/ar-AA19EOIV?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/why-the-ousted-tennessee-lawmakers-could-be-back-in-the-statehouse-soon/ar-AA19EOIV?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 23:41:26.177811+00:00



## Fox News settles 2020 election-related defamation suit with Venezuelan businessman
 - [http://www.msn.com/en-us/news/world/fox-news-settles-2020-election-related-defamation-suit-with-venezuelan-businessman/ar-AA19EVse?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/fox-news-settles-2020-election-related-defamation-suit-with-venezuelan-businessman/ar-AA19EVse?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 23:41:26.167895+00:00



## Chris Christie Slams Trump as 'Only Republican' Biden Can Beat
 - [http://www.msn.com/en-us/news/politics/chris-christie-slams-trump-as-only-republican-biden-can-beat/ar-AA19ET1Z?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/chris-christie-slams-trump-as-only-republican-biden-can-beat/ar-AA19ET1Z?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 22:41:40.400750+00:00



## King's coronation: 3 crowns, 2 carriages and a shorter route
 - [http://www.msn.com/en-us/news/world/king-s-coronation-3-crowns-2-carriages-and-a-shorter-route/ar-AA19EQbo?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/king-s-coronation-3-crowns-2-carriages-and-a-shorter-route/ar-AA19EQbo?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 22:41:40.393062+00:00



## 2 police officers, suspect killed during shootout in Wisconsin
 - [http://www.msn.com/en-us/news/crime/2-police-officers-suspect-killed-during-shootout-in-wisconsin/ar-AA19ESUn?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/2-police-officers-suspect-killed-during-shootout-in-wisconsin/ar-AA19ESUn?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 22:41:40.383690+00:00



## Lindsey Graham, warning of Russian and Chinese expansionism, says he'd be 'very much open to using US forces to defend Taiwan'
 - [http://www.msn.com/en-us/news/world/lindsey-graham-warning-of-russian-and-chinese-expansionism-says-he-d-be-very-much-open-to-using-us-forces-to-defend-taiwan/ar-AA19EV5P?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/lindsey-graham-warning-of-russian-and-chinese-expansionism-says-he-d-be-very-much-open-to-using-us-forces-to-defend-taiwan/ar-AA19EV5P?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 22:41:40.375978+00:00



## Texan declared innocent in slaying now is arrested in another
 - [http://www.msn.com/en-us/news/crime/texan-declared-innocent-in-slaying-now-is-arrested-in-another/ar-AA19EXWW?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/texan-declared-innocent-in-slaying-now-is-arrested-in-another/ar-AA19EXWW?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 22:41:40.368204+00:00



## Christie: Trump’s post-arrest speech like a guy ‘griping about his bad divorce’
 - [http://www.msn.com/en-us/news/politics/christie-trump-s-post-arrest-speech-like-a-guy-griping-about-his-bad-divorce/ar-AA19ELtD?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/christie-trump-s-post-arrest-speech-like-a-guy-griping-about-his-bad-divorce/ar-AA19ELtD?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 22:41:40.360518+00:00



## White, Pink, Blue or Brown Noise: Which Is Best for Your Sleep?
 - [http://www.msn.com/en-us/news/technology/white-pink-blue-or-brown-noise-which-is-best-for-your-sleep/ar-AA19Apvh?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/white-pink-blue-or-brown-noise-which-is-best-for-your-sleep/ar-AA19Apvh?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 22:41:40.351610+00:00



## Northern Ireland police disrupt alleged New IRA bomb plot ahead of Biden's visit: report
 - [http://www.msn.com/en-us/news/world/northern-ireland-police-disrupt-alleged-new-ira-bomb-plot-ahead-of-biden-s-visit-report/ar-AA19EV9b?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/northern-ireland-police-disrupt-alleged-new-ira-bomb-plot-ahead-of-biden-s-visit-report/ar-AA19EV9b?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 22:41:40.341809+00:00



## Taiwan legislative leader highlights China's 'horrendous' human rights record
 - [http://www.msn.com/en-us/news/world/taiwan-legislative-leader-highlights-china-s-horrendous-human-rights-record/ar-AA19EBnb?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/taiwan-legislative-leader-highlights-china-s-horrendous-human-rights-record/ar-AA19EBnb?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 21:41:35.318660+00:00



## 4 dead, including child, in 'domestic violence incident' in Orlando, police say
 - [http://www.msn.com/en-us/news/us/4-dead-including-child-in-domestic-violence-incident-in-orlando-police-say/ar-AA19EPTw?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/4-dead-including-child-in-domestic-violence-incident-in-orlando-police-say/ar-AA19EPTw?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 21:41:35.309566+00:00



## Video Shows Teenage Girl Wrangle 11-Foot Python Snake
 - [http://www.msn.com/en-us/news/world/video-shows-teenage-girl-wrangle-11-foot-python-snake/ar-AA19EzcM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/video-shows-teenage-girl-wrangle-11-foot-python-snake/ar-AA19EzcM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 21:41:35.299598+00:00



## How to understand competing medication abortion rulings
 - [http://www.msn.com/en-us/news/us/how-to-understand-competing-medication-abortion-rulings/ar-AA19DcgP?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/how-to-understand-competing-medication-abortion-rulings/ar-AA19DcgP?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 21:41:35.290637+00:00



## Los Angeles suspect throws puppy out of moving car during police chase
 - [http://www.msn.com/en-us/news/crime/los-angeles-suspect-throws-puppy-out-of-moving-car-during-police-chase/ar-AA19EO5I?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/los-angeles-suspect-throws-puppy-out-of-moving-car-during-police-chase/ar-AA19EO5I?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 21:41:35.279853+00:00



## East Palestine isn’t alone: Communities around the country grapple with toxic chemical exposure
 - [http://www.msn.com/en-us/news/politics/east-palestine-isn-t-alone-communities-around-the-country-grapple-with-toxic-chemical-exposure/ar-AA19EJ6o?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/east-palestine-isn-t-alone-communities-around-the-country-grapple-with-toxic-chemical-exposure/ar-AA19EJ6o?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 21:41:35.270317+00:00



## China conducts second day of military drills around Taiwan, simulates strikes on the island
 - [http://www.msn.com/en-us/news/world/china-conducts-second-day-of-military-drills-around-taiwan-simulates-strikes-on-the-island/ar-AA19ES6U?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/china-conducts-second-day-of-military-drills-around-taiwan-simulates-strikes-on-the-island/ar-AA19ES6U?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 20:42:02.727335+00:00



## Trial date set for John Carter, suspect in fiancee Katelyn Markham's murder
 - [http://www.msn.com/en-us/news/crime/trial-date-set-for-john-carter-suspect-in-fiancee-katelyn-markham-s-murder/ar-AA19DTlo?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/trial-date-set-for-john-carter-suspect-in-fiancee-katelyn-markham-s-murder/ar-AA19DTlo?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 20:42:02.717861+00:00



## Who else has Donald Trump's legal team defended?
 - [http://www.msn.com/en-us/news/crime/who-else-has-donald-trump-s-legal-team-defended/ar-AA19EUJQ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/who-else-has-donald-trump-s-legal-team-defended/ar-AA19EUJQ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 20:42:02.710108+00:00



## What does the huge leak of Ukraine war documents tell us?
 - [http://www.msn.com/en-us/news/world/what-does-the-huge-leak-of-ukraine-war-documents-tell-us/ar-AA19EPJq?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/what-does-the-huge-leak-of-ukraine-war-documents-tell-us/ar-AA19EPJq?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 20:42:02.700821+00:00



## A Tennessee RNC member says vote to expel 2 Democratic lawmakers over a gun control protest hurt the GOP brand: 'You've energized young voters against us'
 - [http://www.msn.com/en-us/news/politics/a-tennessee-rnc-member-says-vote-to-expel-2-democratic-lawmakers-over-a-gun-control-protest-hurt-the-gop-brand-you-ve-energized-young-voters-against-us/ar-AA19EXhq?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/a-tennessee-rnc-member-says-vote-to-expel-2-democratic-lawmakers-over-a-gun-control-protest-hurt-the-gop-brand-you-ve-energized-young-voters-against-us/ar-AA19EXhq?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 20:42:02.692817+00:00



## Ukraine suggests Russia altered leaked US intelligence documents
 - [http://www.msn.com/en-us/news/politics/ukraine-suggests-russia-altered-leaked-us-intelligence-documents/ar-AA19EXlx?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/ukraine-suggests-russia-altered-leaked-us-intelligence-documents/ar-AA19EXlx?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 20:42:02.684571+00:00



## Out of Dishwasher Detergent? Use These Kitchen Staples as an Alternative
 - [http://www.msn.com/en-us/news/technology/out-of-dishwasher-detergent-use-these-kitchen-staples-as-an-alternative/ar-AA19AIDS?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/out-of-dishwasher-detergent-use-these-kitchen-staples-as-an-alternative/ar-AA19AIDS?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 20:42:02.676157+00:00



## Mansplaining GOP Rep Thinks It’s Time to ‘Get Off’ the Abortion Issue
 - [http://www.msn.com/en-us/news/politics/mansplaining-gop-rep-thinks-it-s-time-to-get-off-the-abortion-issue/ar-AA19EAQE?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/mansplaining-gop-rep-thinks-it-s-time-to-get-off-the-abortion-issue/ar-AA19EAQE?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 19:42:00.185086+00:00



## As tiger count grows, India's Indigenous demand land rights
 - [http://www.msn.com/en-us/news/world/as-tiger-count-grows-india-s-indigenous-demand-land-rights/ar-AA19EwQa?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/as-tiger-count-grows-india-s-indigenous-demand-land-rights/ar-AA19EwQa?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 19:42:00.175137+00:00



## Tenn. lawmaker Justin Pearson expects to be reappointed after unprecedented expulsion
 - [http://www.msn.com/en-us/news/politics/tenn-lawmaker-justin-pearson-expects-to-be-reappointed-after-unprecedented-expulsion/ar-AA19Ej5a?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/tenn-lawmaker-justin-pearson-expects-to-be-reappointed-after-unprecedented-expulsion/ar-AA19Ej5a?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 19:42:00.164151+00:00



## Iowa won’t pay for rape victims’ abortions or contraceptives
 - [http://www.msn.com/en-us/news/us/iowa-won-t-pay-for-rape-victims-abortions-or-contraceptives/ar-AA19Ec3e?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/iowa-won-t-pay-for-rape-victims-abortions-or-contraceptives/ar-AA19Ec3e?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 19:42:00.153926+00:00



## Criminal case tests Trump's commitment to campaign as never before
 - [http://www.msn.com/en-us/news/politics/criminal-case-tests-trump-s-commitment-to-campaign-as-never-before/ar-AA19EX55?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/criminal-case-tests-trump-s-commitment-to-campaign-as-never-before/ar-AA19EX55?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 19:42:00.144053+00:00



## SNL parody features Trump comparing himself to Jesus on Easter
 - [http://www.msn.com/en-us/news/politics/snl-parody-features-trump-comparing-himself-to-jesus-on-easter/ar-AA19EFIQ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/snl-parody-features-trump-comparing-himself-to-jesus-on-easter/ar-AA19EFIQ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 19:42:00.132319+00:00



## 'Our vote doesn’t matter': Black Tennessee residents frustrated over expulsion of legislators
 - [http://www.msn.com/en-us/news/politics/our-vote-doesn-t-matter-black-tennessee-residents-frustrated-over-expulsion-of-legislators/ar-AA19EIw8?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/our-vote-doesn-t-matter-black-tennessee-residents-frustrated-over-expulsion-of-legislators/ar-AA19EIw8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 19:42:00.121312+00:00



## Imam stabbed during prayers at New Jersey Omar Mosque: reports
 - [http://www.msn.com/en-us/news/us/imam-stabbed-during-prayers-at-new-jersey-omar-mosque-reports/ar-AA19ES4l?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/imam-stabbed-during-prayers-at-new-jersey-omar-mosque-reports/ar-AA19ES4l?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 19:42:00.110896+00:00



## This Hidden iPhone Setting Makes Your FaceTimes Sound Clearer
 - [http://www.msn.com/en-us/news/technology/this-hidden-iphone-setting-makes-your-facetimes-sound-clearer/ar-AA195O0u?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/this-hidden-iphone-setting-makes-your-facetimes-sound-clearer/ar-AA195O0u?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 18:37:39.195208+00:00



## CNN presses Rep. Ocasio-Cortez over claims Biden admin should 'ignore' abortion ruling: 'Stunning position'
 - [http://www.msn.com/en-us/news/politics/cnn-presses-rep-ocasio-cortez-over-claims-biden-admin-should-ignore-abortion-ruling-stunning-position/ar-AA19ECLI?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/cnn-presses-rep-ocasio-cortez-over-claims-biden-admin-should-ignore-abortion-ruling-stunning-position/ar-AA19ECLI?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 18:37:39.186350+00:00



## Senate chaplain says he reached ‘tipping point’ on gun violence in addressing Nashville shooting
 - [http://www.msn.com/en-us/news/politics/senate-chaplain-says-he-reached-tipping-point-on-gun-violence-in-addressing-nashville-shooting/ar-AA19Eu1b?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/senate-chaplain-says-he-reached-tipping-point-on-gun-violence-in-addressing-nashville-shooting/ar-AA19Eu1b?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 18:37:39.177168+00:00



## Health secretary slams abortion pill ruling as 'not America'
 - [http://www.msn.com/en-us/news/politics/health-secretary-slams-abortion-pill-ruling-as-not-america/ar-AA19EbNV?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/health-secretary-slams-abortion-pill-ruling-as-not-america/ar-AA19EbNV?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 18:37:39.167354+00:00



## Eight missing as explosion destroys Marseille building
 - [http://www.msn.com/en-us/news/world/eight-missing-as-explosion-destroys-marseille-building/ar-AA19EAG4?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/eight-missing-as-explosion-destroys-marseille-building/ar-AA19EAG4?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 18:37:39.156045+00:00



## Guyana's Rupununi Rodeo celebrates local cowboy culture
 - [http://www.msn.com/en-us/news/us/guyana-s-rupununi-rodeo-celebrates-local-cowboy-culture/ar-AA19EMW3?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/guyana-s-rupununi-rodeo-celebrates-local-cowboy-culture/ar-AA19EMW3?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 18:37:39.146848+00:00



## Michael McCaul warns that China could takeover Taiwan 'without a shot fired'
 - [http://www.msn.com/en-us/news/world/michael-mccaul-warns-that-china-could-takeover-taiwan-without-a-shot-fired/ar-AA19EIbi?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/michael-mccaul-warns-that-china-could-takeover-taiwan-without-a-shot-fired/ar-AA19EIbi?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 18:37:37.800551+00:00



## Donald Trump's Shouty Easter Message
 - [http://www.msn.com/en-us/news/politics/donald-trump-s-shouty-easter-message/ar-AA19EhqT?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/donald-trump-s-shouty-easter-message/ar-AA19EhqT?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 17:33:28.279683+00:00



## Expelled Tennessee lawmakers both seeking seats again
 - [http://www.msn.com/en-us/news/politics/expelled-tennessee-lawmakers-both-seeking-seats-again/ar-AA19EA4o?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/expelled-tennessee-lawmakers-both-seeking-seats-again/ar-AA19EA4o?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 17:33:28.264986+00:00



## Trump Lawyer Tries Desperately to Make Trump’s Docs Scandal All About Biden
 - [http://www.msn.com/en-us/news/politics/trump-lawyer-tries-desperately-to-make-trump-s-docs-scandal-all-about-biden/ar-AA19EecW?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/trump-lawyer-tries-desperately-to-make-trump-s-docs-scandal-all-about-biden/ar-AA19EecW?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 17:33:28.252053+00:00



## Ousted Tennessee State Rep. Justin Jones calls expulsion 'unconstitutional'
 - [http://www.msn.com/en-us/news/politics/ousted-tennessee-state-rep-justin-jones-calls-expulsion-unconstitutional/ar-AA19DuqR?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/ousted-tennessee-state-rep-justin-jones-calls-expulsion-unconstitutional/ar-AA19DuqR?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 17:33:28.238724+00:00



## AOC says Clarence Thomas's statement on lavish trips 'raises more serious questions'
 - [http://www.msn.com/en-us/news/us/aoc-says-clarence-thomas-s-statement-on-lavish-trips-raises-more-serious-questions/ar-AA19EegP?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/aoc-says-clarence-thomas-s-statement-on-lavish-trips-raises-more-serious-questions/ar-AA19EegP?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 17:33:28.223752+00:00



## China Holds a Second Day of Military Exercises Around Taiwan
 - [http://www.msn.com/en-us/news/world/china-holds-a-second-day-of-military-exercises-around-taiwan/ar-AA19BrRc?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/china-holds-a-second-day-of-military-exercises-around-taiwan/ar-AA19BrRc?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 17:33:28.208574+00:00



## Two Florida women arrested after taunting, abusing elderly woman on live stream 'pieces of crap,' sheriff says
 - [http://www.msn.com/en-us/news/crime/two-florida-women-arrested-after-taunting-abusing-elderly-woman-on-live-stream-pieces-of-crap-sheriff-says/ar-AA19EAq4?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/two-florida-women-arrested-after-taunting-abusing-elderly-woman-on-live-stream-pieces-of-crap-sheriff-says/ar-AA19EAq4?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 17:33:28.188011+00:00



## Ocasio-Cortez: If Supreme Court upholds abortion pill block, it could ‘institute a national abortion ban’
 - [http://www.msn.com/en-us/news/politics/ocasio-cortez-if-supreme-court-upholds-abortion-pill-block-it-could-institute-a-national-abortion-ban/ar-AA19EoMK?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/ocasio-cortez-if-supreme-court-upholds-abortion-pill-block-it-could-institute-a-national-abortion-ban/ar-AA19EoMK?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-09 17:33:28.158325+00:00



