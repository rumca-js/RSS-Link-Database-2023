# Source:Ben Shapiro, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw, language:en-US

## Man Enters Women Powerlifting Comp 💪🏻
 - [https://www.youtube.com/watch?v=YfOlMz9_yB0](https://www.youtube.com/watch?v=YfOlMz9_yB0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-04-09 23:45:03+00:00

Watch the member-only portion of my show on DailyWire+: bit.ly/3SUaXn3

LIKE & SUBSCRIBE for new videos every day. https://www.youtube.com/@BenShapiro?sub_confirmation=1

Stop giving your money to woke corporations that hate you. Get your Jeremy's Razors today at https://bit.ly/3IfCVEI

Grab your Ben Shapiro merch here: https://bit.ly/3IgkGig

#shorts #BenShapiro #TheBenShapiroShow #News #Politics #DailyWire #shortsfeed #shortsnews #lgbtq #gender #powerlifting #pride #trans #reaction

## Ben & Russell Brand Uncover Shocking Biblical Truths
 - [https://www.youtube.com/watch?v=imgI08FJwX8](https://www.youtube.com/watch?v=imgI08FJwX8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-04-09 13:00:35+00:00

Ben Shapiro sits down with actor, comedian, and cultural thought leader, Russell Brand, to discuss the state of our culture today. They also analyze what the Bible says about slavery and the contrasts between Christian and Judeo beliefs. 

Watch the full version of The Search on DailyWire+: https://tinyurl.com/458jcdt5

LIKE & SUBSCRIBE for new videos every day. https://www.youtube.com/@BenShapiro?sub_confirmation=1

Stop giving your money to woke corporations that hate you. Get your Jeremy's Razors today at https://bit.ly/3IfCVEI

Grab your Ben Shapiro merch here: https://bit.ly/3IgkGig

#BenShapiro #TheBenShapiroShow #News #Politics #DailyWire #russelbrand #christianity #religion #theology #christian #bible #bibleexplained

