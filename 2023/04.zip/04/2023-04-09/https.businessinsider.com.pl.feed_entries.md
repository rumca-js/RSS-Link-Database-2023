# Source:Business insider, URL:https://businessinsider.com.pl/.feed, language:en-US

## Trojan — co to jest? Jak działa ten wirus?
 - [https://businessinsider.com.pl/technologie/trojan-co-to-jest-jak-dziala-ten-wirus/1s3slhh](https://businessinsider.com.pl/technologie/trojan-co-to-jest-jak-dziala-ten-wirus/1s3slhh)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-09 19:29:00+00:00

Rozwój technologiczny, a wraz z nim coraz sprawniejsze urządzenia cyfrowe sprawiają, że żyje nam się coraz lepiej. Ma to jednak także negatywne konsekwencje, a w internecie możemy natknąć się na szereg zagrożeń, które mogą skutecznie uprzykrzyć nam codzienność, m.in. poprzez uszkodzenie lub wykradnięcie danych. Jednym z takich zagrożeń jest trojan, czyli jeden z wirusów, jakimi mogą zostać zainfekowane nasze urządzenia. Co to jest trojan i jak działa?

## Uwaga na fałszywe maile. Bądźcie czujni
 - [https://businessinsider.com.pl/technologie/uwaga-na-falszywe-maile-badzcie-czujni/fzp232r](https://businessinsider.com.pl/technologie/uwaga-na-falszywe-maile-badzcie-czujni/fzp232r)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-09 16:03:00+00:00

W internecie, chociaż czujemy się swobodnie, nigdy nie jesteśmy bezpieczni. Jednym z najpopularniejszych zagrożeń w sieci jest phishing, który może doprowadzić do utraty danych i pieniędzy. Dowiedz się, jak go rozpoznawać i jak się przed nim skutecznie chronić.

## Szefowie zapomnieli, jak chwalić pracowników. Teraz ich tracą
 - [https://businessinsider.com.pl/poradnik-finansowy/dwa-proste-slowa-tyle-wystarczy-by-nie-stracic-dobrego-prcownika/40p3n7j](https://businessinsider.com.pl/poradnik-finansowy/dwa-proste-slowa-tyle-wystarczy-by-nie-stracic-dobrego-prcownika/40p3n7j)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-09 14:41:15+00:00

Kiedy ostatni raz usłyszałeś od szefa "dobra robota" i wiedziałeś, że naprawdę miał to na myśli? Jak wynika z badań Gallupa, zaledwie 30 proc. amerykańskich pracowników potwierdziło, że w ciągu ostatniego tygodnia "otrzymało wyraz uznania lub pochwałę za dobrze wykonaną pracę".

## Tesla ogłasza nowy plan. Zbuduje fabrykę w Szanghaju
 - [https://businessinsider.com.pl/biznes/tesla-oglasza-nowy-plan-zbuduje-fabryke-w-szanghaju/1penf37](https://businessinsider.com.pl/biznes/tesla-oglasza-nowy-plan-zbuduje-fabryke-w-szanghaju/1penf37)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-09 13:58:23+00:00

Tesla zbuduje w Szanghaju nową fabrykę produkującą wielkie magazyny energii — donosi Bloomberg. Amerykański gigant ma już w tym chińskim mieście fabrykę samochodów.

## Jest umowa koalicyjna w sprawie powołania nowego rządu w Estonii. Podatek samochodowy i budynki z drewna
 - [https://businessinsider.com.pl/wiadomosci/jest-umowa-koalicyjna-w-sprawie-powolania-nowego-rzadu-w-estonii-podatek-samochodowy/6fd731h](https://businessinsider.com.pl/wiadomosci/jest-umowa-koalicyjna-w-sprawie-powolania-nowego-rzadu-w-estonii-podatek-samochodowy/6fd731h)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-09 13:02:06+00:00

Negocjujące nowy rząd Estonii ugrupowania — Estońska Partia Reform, Eesti 200 i Partia Socjaldemokratyczna — zawarły umowę koalicyjną, w ramach której przewidziane jest m.in. podniesienie podatków VAT i dochodowego oraz pogłębienie współpracy regionalnej.

## Tworzy tradycyjne tajskie maski. Do jednej potrzeba 1000 arkuszy czystego złota
 - [https://businessinsider.com.pl/wideo/tworzy-tradycyjne-tajskie-maski-do-jednej-potrzeba-1000-arkuszy-czystego-zlota/6y0yycw](https://businessinsider.com.pl/wideo/tworzy-tradycyjne-tajskie-maski-do-jednej-potrzeba-1000-arkuszy-czystego-zlota/6y0yycw)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-09 12:50:00+00:00

Prateep nauczył się robić tradycyjne tajskie maski od swojego wuja, kiedy miał 14 lat. Dziś walczy o przetrwanie tego rzemiosła, które mocno podupadło m.in. przez pandemię.

## Tak wydajemy swoje pieniądze. Na używki jak Francuzi, na restauracje i hotele jak Włosi
 - [https://businessinsider.com.pl/gospodarka/jak-wydajemy-swoje-pieniadze-na-uzywki-jak-francuzi-na-restauracje-i-hotele-jak-wlosi/34kt2lr](https://businessinsider.com.pl/gospodarka/jak-wydajemy-swoje-pieniadze-na-uzywki-jak-francuzi-na-restauracje-i-hotele-jak-wlosi/34kt2lr)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-09 12:14:26+00:00

Dystans cywilizacyjny nadrobiliśmy, mamy wszelkie nowoczesne sprzęty elektroniczne, samochodów nawet najwięcej w Europie na mieszkańca. Czy strukturą wydatków upodabniamy się do najbogatszych? Względnie dużo więcej wydajemy na żywność, za to mniej nas kosztuje mieszkanie. Podstawowe trzy rodzaje wydatków kosztują nas znacząco mniej niż średnia unijna.

## 10 sposobów na przyspieszenie kariery. Najważniejszy jest ten aspekt
 - [https://businessinsider.com.pl/rozwoj-osobisty/kariera/10-sposobow-na-przyspieszenie-kariery-najwazniejszy-jest-ten-aspekt/r0vh376](https://businessinsider.com.pl/rozwoj-osobisty/kariera/10-sposobow-na-przyspieszenie-kariery-najwazniejszy-jest-ten-aspekt/r0vh376)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-09 11:50:19+00:00

Jak to się dzieje, że spośród tak wielu osób nastawionych na sukces w pracy, cel osiągają tylko nieliczni? Być może byli do tego lepiej przygotowani mentalnie od tych, którzy stanęli w miejscu. Nie popełnij tego samego błędu i dowiedz się, jak nadać rozpędu swojej karierze.

## Wybierz się w rejs najpiękniejszymi rzekami Europy — Rodan, Ren, Dunaj
 - [https://businessinsider.com.pl/lifestyle/podroze/wybierz-sie-w-rejs-najpiekniejszymi-rzekami-europy-ren-dunaj-rodan/ntc0m7k](https://businessinsider.com.pl/lifestyle/podroze/wybierz-sie-w-rejs-najpiekniejszymi-rzekami-europy-ren-dunaj-rodan/ntc0m7k)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-09 11:47:00+00:00

Rejs jedną z najpiękniejszych europejskich rzek może być doskonałą alternatywą dla urlopu, podczas którego większość czasu spędzamy na plaży, opuszczając ją jedynie na posiłki w bogatej formule all inclusive. Rzeczne rejsy pasażerskie to interesująca forma wypoczynku dla wszystkich, którym znudziły się tradycyjne urlopy i potrzebują przeżyć coś nowego. Rejsy wycieczkowe to połączenie innej perspektyw zwiedzania, poznawania zabytków, architektury, historii, kultury z jednoczesną wygodą i relaksem. Widok kameralnych wiosek położonych wzdłuż Renu, wspaniałej architektury Wiednia, Budapesztu i Bratysławy, który towarzyszy podczas rejsu Dunajem to tylko część atrakcji, jakie można podziwiać z pokładu statku. W artykule polecamy sprawdzone i docenione przez klientów rejsy wycieczkowe biura podróży Albatros. Zapraszamy!

## Oto przypadki, w których można bez straty wypłacić środki z PPK
 - [https://businessinsider.com.pl/poradnik-finansowy/oszczedzanie/kiedy-mozna-wyplacic-srodki-z-ppk-bez-straty/5fep8vb](https://businessinsider.com.pl/poradnik-finansowy/oszczedzanie/kiedy-mozna-wyplacic-srodki-z-ppk-bez-straty/5fep8vb)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-09 10:58:39+00:00

Pracownicze Plany Kapitałowe (PPK) zostały uruchomione w 2019 r. Jest to program dobrowolnego, dodatkowego oszczędzania emerytalnego, w którym to zarówno pracownik, jak i pracodawca odprowadzają składkę. Wcześniejsza wypłata środków z PPK wiąże się z potrąceniami. Są jednak przypadki, w których można wypłacić całość środków.

## Pracuje 30 godzin tygodniowo i zarabia rocznie siedmiocyfrową kwotę. Zdradza swój sposób
 - [https://businessinsider.com.pl/praca/pracuje-30-h-tygodniowo-i-zarabia-rocznie-siedmiocyfrowa-kwote-zdradza-swoj-sposob/rhlz6yg](https://businessinsider.com.pl/praca/pracuje-30-h-tygodniowo-i-zarabia-rocznie-siedmiocyfrowa-kwote-zdradza-swoj-sposob/rhlz6yg)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-09 10:25:00+00:00

Przedsiębiorca korzysta z narzędzi wykorzystujących sztuczną inteligencję, dzięki czemu pracuje 30 godzin tygodniowo i zarabia rocznie siedmiocyfrową kwotę. To szczególnie ważne dla niego teraz, gdy w domu ma noworodka. Jak mówi, pracuje około sześciu godzin dziennie i nie odbiera więcej niż dwa telefony w tym czasie. W rozmowie z Insiderem zdradza, jak doszedł do tego miejsca.

## Wabbit, czyli nietypowy rodzaj zagrożenia w komputerze
 - [https://businessinsider.com.pl/technologie/wabbit-czyli-nietypowy-rodzaj-zagrozenia-w-komputerze/l2x5jdb](https://businessinsider.com.pl/technologie/wabbit-czyli-nietypowy-rodzaj-zagrozenia-w-komputerze/l2x5jdb)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-09 10:22:00+00:00

Korzystając na co dzień z internetu, musimy liczyć się z licznymi zagrożeniami czyhającymi na nas tak samo, jak na każdego innego użytkownika sieci. Jednym z nich jest szkodliwe oprogramowanie, stworzone po to, by niszczyć systemy i sprzęt oraz wykradać dane z urządzeń, na których zostaną zainstalowane. Wśród takich programów można wyróżnić wabbit, czyli stosunkowo nietypowy rodzaj zagrożenia dla komputera. Co to jest wabbit, jak działa i w jaki sposób się przed nim uchronić?

## Przed nami okres szczytu na kolei. Rząd spodziewa się rekordowej liczby pasażerów
 - [https://businessinsider.com.pl/wiadomosci/przed-nami-okres-szczytu-na-kolei-rzad-spodziewa-sie-rekordowej-liczby-pasazerow/h93tjhf](https://businessinsider.com.pl/wiadomosci/przed-nami-okres-szczytu-na-kolei-rzad-spodziewa-sie-rekordowej-liczby-pasazerow/h93tjhf)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-09 10:09:54+00:00

Liczba przewiezionych pasażerów na kolei powinna rosnąć w kolejnych miesiącach — uważa wiceminister infrastruktury Andrzej Bittel. Skomentował on w ten sposób informację, że pierwszy kwartał był rekordowy pod względem przewozów dla PKP Intercity.

## Prezydent Gdańska o budżecie miasta: mamy dziurę na 600 mln zł
 - [https://businessinsider.com.pl/wiadomosci/prezydent-gdanska-o-budzecie-miasta-mamy-dziure-na-600-mln-zl/es0jmpp](https://businessinsider.com.pl/wiadomosci/prezydent-gdanska-o-budzecie-miasta-mamy-dziure-na-600-mln-zl/es0jmpp)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-09 09:50:15+00:00

W ubiegłym roku zmienił się sposób wpływu podatków do budżetu miasta i gminy. Zgodnie z nowymi zasadami pieniądze trafiają do miasta na podstawie sumy wpływów z PIT, przewidywanej we wrześniu poprzedniego roku. Zmiany te związane są z wprowadzeniem "Polskiego Ładu".

## Rosjanie chwalą się rekordami eksportu mięsa i zboża. Ile z tego ukradli Ukrainie?
 - [https://businessinsider.com.pl/gospodarka/rosjanie-chwala-sie-wzrostem-eksportu-miesa-i-zboza-ile-z-tego-ukradli-ukrainie/9n0d6h9](https://businessinsider.com.pl/gospodarka/rosjanie-chwala-sie-wzrostem-eksportu-miesa-i-zboza-ile-z-tego-ukradli-ukrainie/9n0d6h9)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-09 09:35:53+00:00

Sukces za sukcesem. Szef nadzoru weterynaryjnego i fitosanitarnego Rosji poinformował o rewelacyjnych ubiegłorocznych wynikach eksportu mięsa, którego jeszcze kilka lat temu Rosja była jednym z wiodących w świecie importerów. Pochwalił się też, że Rosja została największym eksporterem zbóż na świecie. To musiał być skok bez precedensu, bo rok temu od lidera, Stanów Zjednoczonych, dzieliła ją przepaść. Pytanie, ile z tego zboża zrabowano Ukrainie? I kto je kupuje?

## Wyciek ściśle tajnych dokumentów. USA wszczynają śledztwo
 - [https://businessinsider.com.pl/wiadomosci/wyciek-scisle-tajnych-dokumentow-usa-wszczynaja-sledztwo/pcm0y6b](https://businessinsider.com.pl/wiadomosci/wyciek-scisle-tajnych-dokumentow-usa-wszczynaja-sledztwo/pcm0y6b)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-09 08:51:17+00:00

Resort sprawiedliwości USA wszczyna śledztwo w sprawie wycieku ściśle tajnych dokumentów pochodzących z różnych amerykańskich agencji i zamieszczonych mediach społecznościowych. Wcześniej własne dochodzenie rozpoczął Pentagon — informuje w niedzielę "Le Figaro".

## Polacy chcą mieć mieszkania na własność. Tak wypadamy na tle Europy
 - [https://businessinsider.com.pl/poradnik-finansowy/polacy-chca-miec-mieszkania-na-wlasnosc-tak-wypadamy-na-tle-europy/n49tqrb](https://businessinsider.com.pl/poradnik-finansowy/polacy-chca-miec-mieszkania-na-wlasnosc-tak-wypadamy-na-tle-europy/n49tqrb)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-09 08:22:39+00:00

Polska ma jeden z największych w Europie i większy niż średnia unijna odsetek własności mieszkań i domów — wskazał Polski Instytut Ekonomiczny. Analitycy PIE zwrócili uwagę na duży udział mieszkań wybudowanych do lat 90. oraz wysoki odsetek ludzi młodych mieszkających z rodzicami.

## Chcesz przekazać majątek konkretnej osobie? Zrób zapis
 - [https://businessinsider.com.pl/prawo/chcesz-przekazac-majatek-konkretnej-osobie-zrob-zapis-windykacyjny/s962wqs](https://businessinsider.com.pl/prawo/chcesz-przekazac-majatek-konkretnej-osobie-zrob-zapis-windykacyjny/s962wqs)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-09 07:35:01+00:00

Jeśli za życia ktoś nie zadba o podzielnie swojego majątku, to po śmierci odziedziczy go najbliższa rodzina zgodnie z zasadami kodeksu cywilnego. Każdy może jednak zdecydować, co i komu chce przekazać. W tym celu trzeba jednak zrobić zapis testamentowy, a najlepiej windykacyjny Wyjaśniamy, co one oznaczają w praktyce i czym się różnią.

## Wielu Polaków myśli, że to raj. "A ludzie żyją jak my w XV wieku"
 - [https://businessinsider.com.pl/wiadomosci/druga-twarz-madagaskaru-ludzie-zyja-niczym-w-xv-wieku/63ee1by](https://businessinsider.com.pl/wiadomosci/druga-twarz-madagaskaru-ludzie-zyja-niczym-w-xv-wieku/63ee1by)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-09 07:19:38+00:00

Madagaskar kojarzy nam się trochę z plakatami, promującymi rajski wypoczynek – a trochę pewnie z filmem pod tym tytułem. Prawda jest natomiast taka, że jest to kraj ubóstwa. Niesamowitego wręcz ubóstwa – opowiadają nam pracownicy Polskiej Akcji Humanitarnej. I przekonują, że z Polskiej perspektywy pomóc niezwykle łatwo. Wystarczy dosłownie kilka złotych, by nakarmić kilkoro dzieci.

## Brodzą w ciemnościach, by je zdobyć. 3 tys. sztuk waży kilogram
 - [https://businessinsider.com.pl/wideo/brodza-w-ciemnosciach-by-je-zdobyc-3-tys-sztuk-wazy-kilogram/0x51pws](https://businessinsider.com.pl/wideo/brodza-w-ciemnosciach-by-je-zdobyc-3-tys-sztuk-wazy-kilogram/0x51pws)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-09 07:05:00+00:00

Maleńkie węgorze to przysmak, który skłania szefów kuchni do sięgnięcia głęboko do kieszeni. Zwłaszcza gdy chodzi o pierwszy połów w sezonie.

## Oni mają najwięcej farm fotowoltaicznych w Polsce. To wcale nie państwowe koncerny
 - [https://businessinsider.com.pl/biznes/oni-maja-najwiecej-farm-fotowoltaicznych-w-polsce-to-wcale-nie-panstwowe-koncerny/yjhkqmb](https://businessinsider.com.pl/biznes/oni-maja-najwiecej-farm-fotowoltaicznych-w-polsce-to-wcale-nie-panstwowe-koncerny/yjhkqmb)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-04-09 07:00:00+00:00

W Polsce działa już ponad 3,4 tys. farm fotowoltaicznych i ponad 1,3 tys. wiatrowych — wynika z najnowszej analizy Instytutu Energetyki Odnawialnej. Ostatnie lata to przede wszystkim szybki rozkwit energetyki słonecznej, ale liderami w tej branży wcale nie są państwowe koncerny. — Niestety, spółki z udziałem Skarbu Państwa w ostatnich kilku latach nie wzięły aktywnego udziału w transformacji energetycznej i rozwoju OZE — twierdzi w rozmowie z Business Insiderem Grzegorz Wiśniewski, prezes IEO.

