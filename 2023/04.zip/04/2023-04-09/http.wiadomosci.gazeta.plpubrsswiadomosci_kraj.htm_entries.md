# Source:wiadomości.gazeta.pl, URL:http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm, language:pl-PL

## Postulator beatyfikacji Jana Pawła II: Za co niektóre środowiska chcą sponiewierać pamięć o nim?
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29648088,biskup-slawomir-oder-za-co-niektore-srodowiska-chca-sponiewierac.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29648088,biskup-slawomir-oder-za-co-niektore-srodowiska-chca-sponiewierac.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-09 20:45:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/da/46/1c/z29648090M,Biskup-Slawomir-Oder.jpg" vspace="2" />- Ja w tej rzeczywistości pytam: za co niektóre środowiska chcą ukamienować pamięć o Janie Pawle II, sponiewierać tę pamięć? Czy za to, że przyniósł nam przesłanie wolności? - zastanawiał się w rozmowie z TVP Info bp Sławomir Oder, postulator procesu beatyfikacyjnego Jana Pawła II.

## Życie polskiego imigranta w Szwajcarii. Parafia rozlicza się z pieniędzy, urząd przesyła talony na tabletki z jodem
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29638709,parafia-rozlicza-sie-z-pieniedzy-urzad-przesyla-talony-na-tabletki.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29638709,parafia-rozlicza-sie-z-pieniedzy-urzad-przesyla-talony-na-tabletki.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-09 18:06:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/3a/44/1c/z29638970M,Krowy-to-rzeczywiscie-staly-element-krajobrazu--Sz.jpg" vspace="2" />Góry, zegarki, banki, czekolada i neutralność. To chyba standardowy zestaw skojarzeń ze słowem "Szwajcaria". Kiedy pół roku temu się tu przeprowadzałem, nie wiedziałem wiele więcej. Poczytałem, popytałem znajomych, ale i tak od pierwszych dni byłem zaskakiwany.

## W Pruchniku znów zawisła kukła Żyda. Szybko zniknęła. W 2019 r. "sąd nad Judaszem" wywołał skandal
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29647960,w-pruchniku-znow-zawisla-kukla-zyda-szybko-zniknela-w-2019.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29647960,w-pruchniku-znow-zawisla-kukla-zyda-szybko-zniknela-w-2019.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-09 17:38:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/5b/46/1c/z29647963M,Kukla-Judasza-w-Pruchniku.jpg" vspace="2" />W Pruchniku ktoś zawiesił na słupie kukłę z karykaturą Żyda. Ma długi czerwony nos, brodę i charakterystyczne nakrycie głowy. "Judasz 2023" - napisano na korpusie. Cztery lata temu w tej samej podkarpackiej miejscowości dokonano "sądu nad Judaszem", co wywołało międzynarodową aferę. Tego rodzaju wydarzenia były tam organizowane jeszcze przed wojną.

## Nietypowy gość grobu pańskiego w Wyszynie. Strażacy musieli wyprosić go z kościoła
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29647938,nietypowy-gosc-grobu-panskiego-w-wyszynie-strazacy-musieli.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29647938,nietypowy-gosc-grobu-panskiego-w-wyszynie-strazacy-musieli.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-09 16:59:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/43/46/1c/z29647939M,Wiewiorka-w-grobie-panskim.jpg" vspace="2" />Do nietypowej interwencji straży pożarnej doszło w sobotę w kościele Narodzenia NMP w Wyszynie (woj. wielkopolskie). Grób pański odwiedziła niesforna wiewiórka, którą strażacy musieli delikatnie wyprosić z budynku.

## Zwłoki 44-letniego mężczyzny przy drodze w województwie pomorskim. Policja szuka świadków
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29647927,zwloki-44-letniego-mezczyzny-przy-drodze-w-wojewodztwie-pomorskim.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29647927,zwloki-44-letniego-mezczyzny-przy-drodze-w-wojewodztwie-pomorskim.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-09 16:31:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d5/22/1c/z29502677M,Policja--zdjecie-ilustracyjne-.jpg" vspace="2" />Na poboczu drogi nr 212 między miejscowościami Udorpie i Rekowo (województwo pomorskie) policjanci odnaleźli zwłoki 44-latka. Mężczyzna został potrącony przez samochód. Trwa ustalanie okoliczności zdarzenia.

## Strażnicy wyciągnęli z rzeki tonącą 16-letnią suczkę. Kilka dni wcześniej zniknęła z podwórka
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29647847,straznicy-wyciagneli-z-rzeki-tonaca-16-letnia-suczke-kilka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29647847,straznicy-wyciagneli-z-rzeki-tonaca-16-letnia-suczke-kilka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-09 15:53:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ed/46/1c/z29647853M,Uratowana-suczka.jpg" vspace="2" />Funkcjonariusze z kaszubskiej Straży Granicznej uratowali suczkę tonącą w rzece Pasłęka, zwierzę walczyło o utrzymanie się na powierzchni wody. Na 16-letnią i ledwo widzącą suczkę oczekiwała jej opiekunka, która traciła już nadzieję na odnalezienie zwierzęcia.

## Nie żyje Maciej Prus. Wybitny reżyser teatralny miał 85 lat
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29647830,nie-zyje-maciej-prus-wybitny-rezyser-teatralny-mial-85-lat.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29647830,nie-zyje-maciej-prus-wybitny-rezyser-teatralny-mial-85-lat.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-09 15:36:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/06/46/1c/z29647878M,Maciej-Prus.jpg" vspace="2" />W wieku 85 lat zmarł Maciej Prus, wybitny aktor i reżyser teatralny - poinformowało Polskie Radio. Artysta był laureatem wielu nagród i odznaczeń.

## Ostrzeżenia przed przymrozkami na północy i południu kraju. Temperatura spadnie poniżej zera
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29647807,ostrzezenia-przed-przymrozkami-na-polnocy-i-poludniu-kraju.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29647807,ostrzezenia-przed-przymrozkami-na-polnocy-i-poludniu-kraju.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-09 14:49:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d6/c9/1b/z29136598M,Przymrozek--Zdjecie-ilustracyjne.jpg" vspace="2" />Instytut Meteorologii i Gospodarki Wodnej wydał ostrzeżenia przed przymrozkami na północy i na południu kraju. W woj. zachodniopomorskim i w górach temperatura spadnie poniżej zera. W lany poniedziałek należy spodziewać się deszczu, a gdzieniegdzie mogą wystąpić burze.

## Lubelskie. Matka wskoczyła do rzeki, aby uratować synka. Strażacy wyłowili ciało
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29647617,lubelskie-z-rzeki-wylowiono-zwloki-kobiety-policja-to-poszukiwana.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29647617,lubelskie-z-rzeki-wylowiono-zwloki-kobiety-policja-to-poszukiwana.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-09 12:38:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/25/46/1c/z29647653M,Lubelskie--Z-rzeki-wylowiono-zwloki-kobiety--Polic.jpg" vspace="2" />Tragiczny finał poszukiwań 36-latki z Lubelszczyzny. W niedzielę służby wyłowiły z wody w pobliżu miejscowości Szczekarków zwłoki kobiety, najprawdopodobniej poszukiwanej od grudnia 2022 r. mieszkanki województwa. Kobieta wskoczyła do rzeki, bo chciała uratować 10-letniego syna, który wpadł do rzeki Wieprz.

## Młody strażak zginął w tragicznym wypadku. OSP Sękowo: "Nasze serca pękają z żalu"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29647582,mlody-strazak-zginal-w-tragicznym-wypadku-osp-sekowo-nasze.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29647582,mlody-strazak-zginal-w-tragicznym-wypadku-osp-sekowo-nasze.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-09 11:20:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e3/46/1c/z29647587M,Sebastian-Gluchy.jpg" vspace="2" />26-letni strażak z OSP Sękowo Sebastian Głuchy zginął w sobotę w tragicznym wypadku samochodowym. "Zawsze gotowy do akcji i do niesienia pomocy innym. Nasze serca pękają z żalu. Wyrazy współczucia dla najbliższych Sebastiana" - żegnają swojego kolegę strażacy.

## Lubuskie. BMW zderzyło się z sarną, 21-latek z Mołdawii nie przeżył wypadku. "Przerażający widok"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29647291,lubuskie-osobowe-bmw-zderzylo-sie-z-sarna-kierowca-nie-przezyl.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29647291,lubuskie-osobowe-bmw-zderzylo-sie-z-sarna-kierowca-nie-przezyl.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-09 07:43:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f2/46/1c/z29647346M,Lubuskie--Osobowe-BMW-zderzylo-sie-z-sarna--kierow.jpg" vspace="2" />Do tragicznego wypadku doszło w województwie lubuskim. Nie żyje kierowca osobowego BMW pod koła którego wbiegła sarna. - Kierowca pojazdu po zderzeniu ze zwierzęciem zjechał z drogi i uderzył w drzewo - relacjonował w rozmowie z Gazeta.pl kom. Maciej Kimet z zespołu prasowego Komendy Wojewódzkiej Policji w Gorzowie Wielkopolskim.

