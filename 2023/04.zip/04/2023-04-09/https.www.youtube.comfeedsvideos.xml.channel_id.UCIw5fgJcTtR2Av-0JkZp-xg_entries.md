# Source:Yuri Wong, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg, language:en-US

## "Funny How?" (Full Song)
 - [https://www.youtube.com/watch?v=FYGVLABbFJw](https://www.youtube.com/watch?v=FYGVLABbFJw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg
 - date published: 2023-04-09 12:30:06+00:00

Watch the remix: https://youtu.be/aNWWfcRA0L0
Support my music on Patreon: https://patreon.com/yuriwong

