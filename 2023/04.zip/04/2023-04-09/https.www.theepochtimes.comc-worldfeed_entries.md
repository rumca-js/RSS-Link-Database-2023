# Source:Epoch times world, URL:https://www.theepochtimes.com/c-world/feed/, language:en-US

## Germany: Hamburg Fire Smoke Halts Trains, Generates Warning
 - [https://www.theepochtimes.com/germany-hamburg-fire-smoke-halts-trains-generates-warning_5181965.html](https://www.theepochtimes.com/germany-hamburg-fire-smoke-halts-trains-generates-warning_5181965.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-09 22:55:26+00:00

Huge flames rise from a fire in Hamburg, Germany, on April 9, 2023. (Jonas Walzberg/dpa via AP)

## Uni Chief to Lead AUKUS Partnership Talks in Washington
 - [https://www.theepochtimes.com/uni-chief-to-lead-aukus-partnership-talks-in-washington_5182517.html](https://www.theepochtimes.com/uni-chief-to-lead-aukus-partnership-talks-in-washington_5182517.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-09 22:52:16+00:00

An undated visualisation of what an SSN-AUKUS submarine might look like at sea, issued on March 13, 2023. (BAE)

## Melbourne Leads the Way in Global ‘Rewilding’ Push
 - [https://www.theepochtimes.com/melbourne-leads-the-way-in-global-rewilding-push_5182467.html](https://www.theepochtimes.com/melbourne-leads-the-way-in-global-rewilding-push_5182467.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-09 22:22:18+00:00

People enjoy a picnic in Carlton Gardens in Melbourne, Australia, on Oct. 9, 2021. (Darrian Traynor/Getty Images)

## Avalanche in French Alps Kills at Least 4 People
 - [https://www.theepochtimes.com/avalanche-in-french-alps-kills-at-least-4-people_5182195.html](https://www.theepochtimes.com/avalanche-in-french-alps-kills-at-least-4-people_5182195.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-09 21:55:53+00:00

The aftermath of an avalanche near the Armancette glacier in the French Alps, as seen from Mont Joux, France, on April 9, 2023. (Twitter @jpclement38 via Reuters)

## Macron Says Europe Should Reduce Dependence on US Dollar After Meeting With China’s Xi
 - [https://www.theepochtimes.com/macron-says-europe-should-reduce-dependence-on-us-dollar-after-meeting-with-chinas-xi_5182353.html](https://www.theepochtimes.com/macron-says-europe-should-reduce-dependence-on-us-dollar-after-meeting-with-chinas-xi_5182353.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-09 21:43:40+00:00

French President Emmanuel Macron (L) and Chinese leader Xi Jinping take part in a Franco-Chinese business council meeting in Beijing on April 6, 2023. (Photo by Ludovic Marin/Pool/AFP via Getty Images)

## CRA ‘Confident’ It Can Find Compromise With Workers as Threat of Tax Season Strike Looms
 - [https://www.theepochtimes.com/cra-confident-it-can-find-compromise-with-workers-as-threat-of-tax-season-strike-looms_5182226.html](https://www.theepochtimes.com/cra-confident-it-can-find-compromise-with-workers-as-threat-of-tax-season-strike-looms_5182226.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-09 20:25:23+00:00

The Canada Revenue Agency (CRA) headquarters Connaught Building in Ottawa on Aug. 17, 2020. (The Canadian Press/Sean Kilpatrick)

## 8 People Missing in Fiery Collapse of Marseille Building
 - [https://www.theepochtimes.com/8-people-missing-in-fiery-collapse-of-marseille-building_5181954.html](https://www.theepochtimes.com/8-people-missing-in-fiery-collapse-of-marseille-building_5181954.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-09 20:06:09+00:00

Firefighters work after building collapsed in Marseille, southern France, early on April 9, 2023. (AP Photo)

## US Deploys Guided-Missile Submarine to Gulf Amid Iran Tensions, Heightened Russia Presence
 - [https://www.theepochtimes.com/us-deploys-guided-missile-submarine-to-gulf-amid-iran-tensions-heightened-russia-presence_5182215.html](https://www.theepochtimes.com/us-deploys-guided-missile-submarine-to-gulf-amid-iran-tensions-heightened-russia-presence_5182215.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-09 18:45:42+00:00

A nuclear propulsion Ohio class submarine, the USS Florida sails  on Jan. 22, 2003 off the coast of the Bahamas.  Australia as part of the AUKUS deal will get the tech for nuclear powered subs.  (David Nagle/U.S. Navy/Getty Images)

## Review of Democratic Processes Needed as Ministerial Responsibility Changes: Experts
 - [https://www.theepochtimes.com/review-of-democratic-processes-needed-as-ministerial-responsibility-changes-experts_5182218.html](https://www.theepochtimes.com/review-of-democratic-processes-needed-as-ministerial-responsibility-changes-experts_5182218.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-09 18:31:58+00:00

Katie Telford, Chief of Staff to Prime Minister Justin Trudeau, leaves after a meeting of the Liberal Caucus on Parliament Hill in Ottawa on Mar. 8, 2023. (The Canadian Press/Justin Tang)

## Special Rapporteur on Foreign Interference: Mandate, Remuneration Made Public
 - [https://www.theepochtimes.com/special-rapporteur-on-foreign-interference-mandate-salary-made-public_5182113.html](https://www.theepochtimes.com/special-rapporteur-on-foreign-interference-mandate-salary-made-public_5182113.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-09 18:10:58+00:00

Then-governor general David Johnston and Prime Minister Justin Trudeau embrace during a farewell reception at the end of Johnston's term of office, in Ottawa on Sept. 28, 2017. (The Canadian Press/Sean Kilpatrick)

## China Jails Man for 9 Years in ‘Chained Woman’ Scandal
 - [https://www.theepochtimes.com/china-jails-man-for-9-years-in-chained-woman-scandal_5181758.html](https://www.theepochtimes.com/china-jails-man-for-9-years-in-chained-woman-scandal_5181758.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-09 17:57:28+00:00

Video screenshots of a mother of eight shackled in a village hut in Xuzhou city, Jiangsu, China, in January 2022.  (Screenshots via Douyin)

## Ben Ferencz, Last Surviving Nuremberg Prosecutor, Dies at 103
 - [https://www.theepochtimes.com/ben-ferencz-last-surviving-nuremberg-prosecutor-dies-at-103_5181403.html](https://www.theepochtimes.com/ben-ferencz-last-surviving-nuremberg-prosecutor-dies-at-103_5181403.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-09 17:36:36+00:00

Benjamin Ferencz, former chief prosecutor in the Nuremberg trials, speaks during a video interview from his home in Delray Beach, Fla., on Nov. 18, 2020, in a still image obtained from a video. (Reuters TV via Reuters)

## More Than 130,000 Still Without Power in Quebec Following Deadly Ice Storm
 - [https://www.theepochtimes.com/more-than-130000-still-without-power-in-quebec-following-deadly-ice-storm_5181985.html](https://www.theepochtimes.com/more-than-130000-still-without-power-in-quebec-following-deadly-ice-storm_5181985.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-09 14:19:05+00:00

City workers clear fallen branches in Montreal on April 6, 2023, after an ice storm which initially left over a million customers without power.  (Ryan Remiorz/The Canadian Press)

## British-Israeli Sisters Killed in West Bank Terrorist Shooting Named
 - [https://www.theepochtimes.com/british-israeli-sisters-killed-in-west-bank-terrorist-shooting-named_5181927.html](https://www.theepochtimes.com/british-israeli-sisters-killed-in-west-bank-terrorist-shooting-named_5181927.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-09 13:56:22+00:00

Undated handout photo of Maia (left) and Rina Dee, the two British-Israeli sisters who were killed in a gun attack in the West Bank on April 7, issued by the Office of Israeli Prime Minister Benjamin Netanyahu on April 8, 2023. (Office of Israeli Prime Minister Benjamin Netanyahu via PA Media)

## ‘It’s Been Awesome’: Aussies Still Enjoying Their Fresh Seafood Over Easter Amid Cost of Living Pressures
 - [https://www.theepochtimes.com/its-been-awesome-aussies-still-enjoying-their-fresh-seafood-over-easter-amid-cost-of-living-pressures_5180687.html](https://www.theepochtimes.com/its-been-awesome-aussies-still-enjoying-their-fresh-seafood-over-easter-amid-cost-of-living-pressures_5180687.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-09 08:43:32+00:00

Customers line up to order seafood at Sydney Fish Market in Sydney, Australia,  on Dec. 24, 2022. (Jenny Evans/Getty Images)

## Low- to Middle-Income Australians to Feel the Pinch as Tax Offset Meets Its End
 - [https://www.theepochtimes.com/low-to-middle-income-australians-to-feel-the-pinch-as-tax-offset-meets-its-end_5181790.html](https://www.theepochtimes.com/low-to-middle-income-australians-to-feel-the-pinch-as-tax-offset-meets-its-end_5181790.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-09 08:25:18+00:00

Australian Treasurer Jim Chalmers speaks to the media during a press conference inside the Budget lockup at Parliament House in Canberra, Australia, on Oct. 25, 2022. (AAP Image/Lukas Coch)

## Easter a Celebration of Faith, Hope and Renewal: Australian Prime Minister
 - [https://www.theepochtimes.com/easter-a-celebration-of-faith-hope-and-renewal-australian-prime-minister_5181760.html](https://www.theepochtimes.com/easter-a-celebration-of-faith-hope-and-renewal-australian-prime-minister_5181760.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-09 07:41:25+00:00

Australian Prime Minister Anthony Albanese visits Tritium in Brisbane, Australia, on March 31, 2023. (AAP Image/Jono Searle)

## ‘Easter Treat’ as Chill Brings Snow to Ski Resorts in Australia
 - [https://www.theepochtimes.com/easter-treat-as-chill-brings-snow-to-ski-resorts-in-australia_5181815.html](https://www.theepochtimes.com/easter-treat-as-chill-brings-snow-to-ski-resorts-in-australia_5181815.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-09 06:52:59+00:00

Children take photo with the Easter Bunny at the annual PBA Easter Egg hunt at Winstanley Park in Warwick, N.Y., on April 8, 2023. (Chung I Ho/The Epoch Times)

## Teen Charged Over Sexual Assault and Robbery in Western Australia
 - [https://www.theepochtimes.com/teen-charged-over-sexual-assault-and-robbery-in-western-australia_5181820.html](https://www.theepochtimes.com/teen-charged-over-sexual-assault-and-robbery-in-western-australia_5181820.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-09 06:47:17+00:00

Crime figure Bilal Hamze was gunned down in a hail of bullets in Sydney CBD by multiple persons in a black Audi on June 17, 2021 in Sydney, Australia. (Photo by Saeed KHAN / AFP via Getty Image)

## Hunt for ‘Unpredictable’ Man After Alleged Crime Spree in Brisbane
 - [https://www.theepochtimes.com/hunt-for-unpredictable-man-after-alleged-crime-spree-in-brisbane_5181816.html](https://www.theepochtimes.com/hunt-for-unpredictable-man-after-alleged-crime-spree-in-brisbane_5181816.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-09 06:41:27+00:00

A police tape in Australia on Nov. 9, 2018. (Robert Cianflone/Getty Images)

## Ukraine Returns 31 Children From Russia After Alleged Deportation
 - [https://www.theepochtimes.com/ukraine-returns-31-children-from-russia-after-alleged-deportation_5181197.html](https://www.theepochtimes.com/ukraine-returns-31-children-from-russia-after-alleged-deportation_5181197.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-09 03:59:42+00:00

Valeriia, who went to a Russian-organised summer camp from non-government controlled territories and was then taken to Russia, embraces her mother Anastasiia after returning via the Ukraine-Belarus border, in Kyiv, Ukraine, on April 8, 2023. (Valentyn Ogirenko/Reuters)

## US Deploys Guided-Missile Submarine Amid Tensions With Iran
 - [https://www.theepochtimes.com/us-deploys-guided-missile-submarine-amid-tensions-with-iran_5181230.html](https://www.theepochtimes.com/us-deploys-guided-missile-submarine-amid-tensions-with-iran_5181230.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-04-09 02:24:24+00:00

The Navy said nuclear-powered submarine, based out of Kings Bay, Georgia, passed through the Suez Canal, on April 7, 2023. (US Navy via AP)

