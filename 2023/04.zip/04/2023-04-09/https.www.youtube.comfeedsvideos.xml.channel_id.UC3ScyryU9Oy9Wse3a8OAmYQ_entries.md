# Source:FRONTLINE PBS | Official, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3ScyryU9Oy9Wse3a8OAmYQ, language:en-US

## How will AI change the job market? 🤖
 - [https://www.youtube.com/watch?v=ByEqczA5qjs](https://www.youtube.com/watch?v=ByEqczA5qjs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3ScyryU9Oy9Wse3a8OAmYQ
 - date published: 2023-04-09 11:30:08+00:00



