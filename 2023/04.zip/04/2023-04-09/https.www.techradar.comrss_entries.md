# Source:Techradar, URL:https://www.techradar.com/rss, language:en-US

## The Samsung Galaxy Tab S9 series could include two FE editions
 - [https://www.techradar.com/news/the-samsung-galaxy-tab-s9-series-could-include-two-fe-editions](https://www.techradar.com/news/the-samsung-galaxy-tab-s9-series-could-include-two-fe-editions)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-04-09 13:30:48+00:00

Based on benchmarks posted to the web, we could get as many as five Tab S9 tablets in the coming months.

## Microsoft Teams wants to make its weirdest feature actually worth using
 - [https://www.techradar.com/news/microsoft-teams-wants-to-make-its-lamest-feature-actually-worth-using](https://www.techradar.com/news/microsoft-teams-wants-to-make-its-lamest-feature-actually-worth-using)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-04-09 12:46:35+00:00

Virtual backgrounds in Microsoft Teams are getting a green screen boost.

## iPhone 15 Pro display leak shows off its super-thin bezels
 - [https://www.techradar.com/news/iphone-15-pro-display-leak-shows-off-its-super-thin-bezels](https://www.techradar.com/news/iphone-15-pro-display-leak-shows-off-its-super-thin-bezels)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-04-09 09:30:23+00:00

Newly leaked glass screens for the iPhone 15 series show how the display bezels are set to shrink further.

## Quordle today - hints and answers for Sunday, April 9 (game #440)
 - [https://www.techradar.com/news/quordle-today-answers-clues-9-april-2023](https://www.techradar.com/news/quordle-today-answers-clues-9-april-2023)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-04-09 06:45:20+00:00

Looking for Quordle clues? We can help. Plus get the answers to Quordle today and past solutions.

## Worried about AI and ChatGPT taking your job? You're not alone...
 - [https://www.techradar.com/news/search-for-jobs-most-vulnerable-to-ai-skyrockets-after-chatgpt-launch](https://www.techradar.com/news/search-for-jobs-most-vulnerable-to-ai-skyrockets-after-chatgpt-launch)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-04-09 03:01:58+00:00

Will AI replace my job becomes an existential question for millions worldwide.

