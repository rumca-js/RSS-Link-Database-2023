# Source:Le Monde - science, URL:https://www.lemonde.fr/en/science/rss_full.xml, language:en-US

## Basilica of Saint-Denis: Newly discovered graves bring back the past
 - [https://www.lemonde.fr/en/science/article/2023/04/09/basilica-of-saint-denis-newly-discovered-graves-bring-back-the-past_6022294_10.html](https://www.lemonde.fr/en/science/article/2023/04/09/basilica-of-saint-denis-newly-discovered-graves-bring-back-the-past_6022294_10.html)
 - RSS feed: https://www.lemonde.fr/en/science/rss_full.xml
 - date published: 2023-04-09 16:01:11+00:00

Excavations prior to the reconstruction of the Gothic building's north tower and spire have uncovered hundreds of anonymous graves dating from the 5th to the 14th century.

## Examining MRIs of the brains of bilingual people reading
 - [https://www.lemonde.fr/en/science/article/2023/04/09/reading-examining-mris-of-the-brains-of-bilingual-people_6022228_10.html](https://www.lemonde.fr/en/science/article/2023/04/09/reading-examining-mris-of-the-brains-of-bilingual-people_6022228_10.html)
 - RSS feed: https://www.lemonde.fr/en/science/rss_full.xml
 - date published: 2023-04-09 02:29:52+00:00

In English-Chinese bilinguals, some very small brain areas are only activated when reading Chinese words. This specialization does not exist in the brain of English-French bilinguals, according to a French team.

