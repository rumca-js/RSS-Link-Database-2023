# Source:Daily Mail, URL:https://www.dailymail.co.uk/news/index.rss, language:en-US

## Jeremy Renner is snapped enjoying scooter outing with daughter Ava
 - [https://www.dailymail.co.uk/news/article-11955095/Jeremy-Renner-snapped-enjoying-scooter-outing-daughter-Ava.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11955095/Jeremy-Renner-snapped-enjoying-scooter-outing-daughter-Ava.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 23:31:09+00:00

The sighting comes days after the pair were seen during a family outing at Six Flags - which itself came hours after the airing of a bombshell interview between the 52-year-old and Diane Sawyer.

## Wizz Air revealed as worst major airline for flight delays from UK airports
 - [https://www.dailymail.co.uk/news/article-11955381/Wizz-Air-revealed-worst-major-airline-flight-delays-UK-airports.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11955381/Wizz-Air-revealed-worst-major-airline-flight-delays-UK-airports.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 23:28:34+00:00

Hungarian carrier Wizz Air's departures were an average of 46 minutes and six seconds behind schedule in 2022, according to Civil Aviation Authority (CAA) data by the Press Association.

## Olivia Pratt-Korbel's killer Thomas Cashman 'will turn supergrass' to save his own skin
 - [https://www.dailymail.co.uk/news/article-11955337/Olivia-Pratt-Korbels-killer-Thomas-Cashman-turn-supergrass-save-skin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11955337/Olivia-Pratt-Korbels-killer-Thomas-Cashman-turn-supergrass-save-skin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 23:23:20+00:00

Child killer Thomas Cashman, 34, is currently being kept in isolation in prison for his 'own protection' after his abhorrent crime made him 'public enemy number one in Strangeways Prison.

## Ron DeSantis 'won't be bullied' by Donald Trump
 - [https://www.dailymail.co.uk/news/article-11955101/Ron-DeSantis-wont-bullied-Donald-Trump.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11955101/Ron-DeSantis-wont-bullied-Donald-Trump.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 23:18:34+00:00

Ron DeSantis has been taken aback by how quickly Trump has started attacking him and is furious the former president expects fealty while hurling slurs.

## Rishi Sunak calls on Northern Ireland parties to 'redouble' efforts to break Stormont deadlock
 - [https://www.dailymail.co.uk/news/article-11955065/Rishi-Sunak-calls-Northern-Ireland-parties-redouble-efforts-break-Stormont-deadlock.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11955065/Rishi-Sunak-calls-Northern-Ireland-parties-redouble-efforts-break-Stormont-deadlock.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 23:15:54+00:00

Rishi Sunak has urged Northern Ireland's political parties to redouble their efforts to break the Stormont deadlock on the 25th anniversary of the Good Friday Agreement.

## Labour's VAT levy on annual fees for private schools could spark exodus of students, survey says
 - [https://www.dailymail.co.uk/news/article-11955335/Labours-VAT-levy-annual-fees-private-schools-spark-exodus-students-survey-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11955335/Labours-VAT-levy-annual-fees-private-schools-spark-exodus-students-survey-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 22:50:55+00:00

Private schools will lose a fifth of pupils if Labour's plan to levy VAT on annual fees is enacted in government, a survey has found.

## Cost-of-living crisis will wipe out £972 rise in state pension which comes into force this week
 - [https://www.dailymail.co.uk/news/article-11955285/Cost-living-crisis-wipe-972-rise-state-pension-comes-force-week.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11955285/Cost-living-crisis-wipe-972-rise-state-pension-comes-force-week.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 22:50:11+00:00

Pensioners will see their payments rise by nearly £19 a week, the equivalent of around £972 a year. But campaigners say the rising cost of food, energy, fuel, and accommodation has wiped out the boost.

## Afghan refugees rescued brought to US accused of being racist sexist towards those tasked helping
 - [https://www.dailymail.co.uk/news/article-11955155/Afghan-refugees-rescued-brought-accused-racist-sexist-tasked-helping.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11955155/Afghan-refugees-rescued-brought-accused-racist-sexist-tasked-helping.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 22:33:16+00:00

U.S. agencies  tasked with assisting the resettlement of approximately 72,000 Afghan evacuees brought to the US in 2021 faced racist, sexist, and verbal abuse.

## Nuremberg prosecutor Ben Ferencz revealed why he believed vengeance was NEVER the answer
 - [https://www.dailymail.co.uk/news/article-11955237/Nuremberg-prosecutor-Ben-Ferencz-revealed-believed-vengeance-NEVER-answer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11955237/Nuremberg-prosecutor-Ben-Ferencz-revealed-believed-vengeance-NEVER-answer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 22:28:56+00:00

Nearly 80 years later, Ben Ferencz could still recall watching in horror as concentration-camp prisoners, days after their liberation, captured an SS guard and burned him alive.

## Texas man, 46, exonerated for 2010 murder is now accused of shooting man dead
 - [https://www.dailymail.co.uk/news/article-11955205/Texas-man-46-exonerated-2010-murder-accused-shooting-man-dead.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11955205/Texas-man-46-exonerated-2010-murder-accused-shooting-man-dead.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 22:27:40+00:00

Lydell Grant, 46, was arrested on Friday for allegedly shooting 33-year-old Edwin Arevalo in a Houston road rage incident the night before. He was previously arrested for stabbing a man to death.

## Suella Braverman scolds police force for sending officers to seize collection of golliwog dolls
 - [https://www.dailymail.co.uk/news/article-11954929/Suella-Braverman-scolds-police-force-sending-officers-seize-collection-golliwog-dolls.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954929/Suella-Braverman-scolds-police-force-sending-officers-seize-collection-golliwog-dolls.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 22:21:21+00:00

A complaint was made about the White Hart Inn in Essex, and 15 golliwog dolls were seized because their presence was a suspected 'hate crime'. Suella Braverman is said to have been furious.

## Worshipper is stabbed outside church on Easter Sunday after attending service
 - [https://www.dailymail.co.uk/news/article-11954973/Worshipper-stabbed-outside-church-Easter-Sunday-attending-service.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954973/Worshipper-stabbed-outside-church-Easter-Sunday-attending-service.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 22:21:19+00:00

Police were called to St Stephen's Church in Sneinton, Nottinghamshire following reports a worshipper had been stabbed outside the church where he had attended the service.

## Third and final suspect, 16, arrested over 'gang related' triple murders of Central Florida teens
 - [https://www.dailymail.co.uk/news/article-11954969/Third-final-suspect-16-arrested-gang-related-triple-murders-Central-Florida-teens.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954969/Third-final-suspect-16-arrested-gang-related-triple-murders-Central-Florida-teens.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 21:45:55+00:00

Police vowed to find Tahj Brewton, 16, after his suspected accomplices Christopher Atkins, 12, and Robert Robinson, 17, were arrested on Friday in connection to the triple teen murders in Florida.

## Caitlyn Jenner blasts trans activists who 'attacked' swimmer Riley Gaines as the 'Rainbow Mafia'
 - [https://www.dailymail.co.uk/news/article-11954357/They-domestic-terrorists-Caitlyn-Jenner-blasts-trans-activists-attacked-swimmer-Riley-Gaines.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954357/They-domestic-terrorists-Caitlyn-Jenner-blasts-trans-activists-attacked-swimmer-Riley-Gaines.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 21:36:22+00:00

Caitlyn Jenner, 73, defended swimmer Riley Gaines after she was 'attacked' by the 'Radical Rainbow Mafia' following her saving women's rights speech last week.

## SIR KEIR STARMER: Rishi Sunak and the Tories have let criminals get away with it
 - [https://www.dailymail.co.uk/news/article-11955043/SIR-KEIR-STARMER-Rishi-Sunak-Tories-let-criminals-away-it.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11955043/SIR-KEIR-STARMER-Rishi-Sunak-Tories-let-criminals-away-it.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 21:32:35+00:00

SIR KEIR STARMER: Over the last decade, we have become a country where thugs, gangs and monsters mock our justice system and make decent people's lives a misery.

## Billionaire David Geffen's new 'husband' is a former go-go dancer with 'super secretive' past
 - [https://www.dailymail.co.uk/news/article-11954831/Billionaire-David-Geffens-new-husband-former-dancer-super-secretive-past.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954831/Billionaire-David-Geffens-new-husband-former-dancer-super-secretive-past.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 21:19:49+00:00

Donovan Michaels, 30, has gone by several names since he was born in a small town in Michigan. One of 13 kids, he moved to Florida in 2014 where he changed his name.

## Tory fury at attack advert claiming Rishi Sunak does not think child sex abusers should go to prison
 - [https://www.dailymail.co.uk/news/article-11954989/Tory-fury-attack-advert-claiming-Rishi-Sunak-does-not-think-child-sex-abusers-prison.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954989/Tory-fury-attack-advert-claiming-Rishi-Sunak-does-not-think-child-sex-abusers-prison.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 21:03:58+00:00

Labour provoked Tory fury with posters which claimed the PM doesn't think child sex abusers or thieves should go to prison. Critics including some in his party described it as gutter politics.

## Downing Street drops support for bill that would let staff sue employers if they were offended
 - [https://www.dailymail.co.uk/news/article-11955021/Downing-Street-drops-support-bill-let-staff-sue-employers-offended.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11955021/Downing-Street-drops-support-bill-let-staff-sue-employers-offended.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 21:03:46+00:00

MPs have previously said that the 'draconian' Worker Protection Bill could be abused by business owners seeking to damage rivals.

## 'He did everything right and still lost his life': Widow of Derek Jacobs slams smart motorway scheme
 - [https://www.dailymail.co.uk/news/article-11955023/He-did-right-lost-life-Widow-Derek-Jacobs-slams-smart-motorway-scheme.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11955023/He-did-right-lost-life-Widow-Derek-Jacobs-slams-smart-motorway-scheme.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 20:45:47+00:00

One Friday lunchtime, in March 2019, on a stretch of the M1 just outside Sheffield, Derek, 83, was killed in a horrific crash.

## Trump lawyer guarantees ex-president doesn't have copies of classified documents
 - [https://www.dailymail.co.uk/news/article-11954879/Trump-lawyer-guarantees-ex-president-doesnt-copies-classified-documents.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954879/Trump-lawyer-guarantees-ex-president-doesnt-copies-classified-documents.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 20:35:34+00:00

Donald Trump's lawyer James Trusty guaranteed on Sunday that the ex-president does not have any copies of the classified materials taken from his Mar-a-Lago home in the FBI raid last year.

## Spirit Airlines flight attendant goes viral after hitting out at employer
 - [https://www.dailymail.co.uk/news/article-11954853/Spirit-Airlines-flight-attendant-goes-viral-hitting-employer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954853/Spirit-Airlines-flight-attendant-goes-viral-hitting-employer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 20:35:32+00:00

Video posted to TikTok shows an unnamed Spirit Airlines flight attendant informing customers they would have to pay for any extra items, like blankets, ear plugs or even an outlet to charge their phones.

## Melania is seen for the first time in TEN DAYS as she attends Easter Brunch with Trump
 - [https://www.dailymail.co.uk/news/article-11954873/Melania-seen-time-TEN-DAYS-attends-Easter-Brunch-Trump.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954873/Melania-seen-time-TEN-DAYS-attends-Easter-Brunch-Trump.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 20:34:48+00:00

Melania Trump has stepped out of hiding, appearing with her husband at an Easter brunch at Mar-a-Lago on Sunday.

## Eight people feared trapped under rubble after explosion in the south of France, officials say
 - [https://www.dailymail.co.uk/news/article-11954849/Eight-people-feared-trapped-rubble-explosion-south-France-officials-say.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954849/Eight-people-feared-trapped-rubble-explosion-south-France-officials-say.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 19:32:57+00:00

More than 100 firefighters worked to extinguish flames deep within the rubble of the five-storey building, but more than 17 hours later 'the situation is not yet stabilised', French authorities say.

## Christ, not colonial guilt, inspired CoE fund to help victims of historic slavery, Justin Welby says
 - [https://www.dailymail.co.uk/news/article-11954823/Christ-not-colonial-guilt-inspired-CoE-fund-help-victims-historic-slavery-Justin-Welby-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954823/Christ-not-colonial-guilt-inspired-CoE-fund-help-victims-historic-slavery-Justin-Welby-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 19:28:26+00:00

Rev Welby, 67, (pictured) told the congregation at Canterbury Cathedral he received a 'large' volume of complaints regarding the Church Commissioner's decision to start the fund.

## Twin sisters who married identical brothers and had babies will introduce them to their family
 - [https://www.dailymail.co.uk/news/article-11954713/Twin-sisters-married-identical-brothers-babies-introduce-family.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954713/Twin-sisters-married-identical-brothers-babies-introduce-family.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 19:21:53+00:00

Brittany and Briana Salyers, both 37, packed up their family for an Easter celebration in Delaware for a holiday extravaganza with their mom's side of the family on Sunday.

## Ex-coal miner who built 6ft wall around his house is told by council to knock it down
 - [https://www.dailymail.co.uk/news/article-11954773/Ex-coal-miner-built-6ft-wall-house-told-council-knock-down.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954773/Ex-coal-miner-built-6ft-wall-house-told-council-knock-down.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 18:58:57+00:00

Mark Roberts, from Caerphilly, Wales, paid £5,000 in 2020 to build the wall after complaining about antisocial behaviour in the area, including missing items and 'syringes'.

## Incredible EIGHTY brides get married during single ceremony in South African church on Easter Sunday
 - [https://www.dailymail.co.uk/news/article-11954731/Incredible-EIGHTY-brides-married-single-ceremony-South-African-church-Easter-Sunday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954731/Incredible-EIGHTY-brides-married-single-ceremony-South-African-church-Easter-Sunday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 18:48:10+00:00

The International Pentecost Holiness Church in Zuurbekom, south of Johannesburg, witnessed a sea of white during the country's biggest mass wedding ceremony.

## Chinese teapot made especially for Ming Dynasty ruler 600 years ago sells for £11million
 - [https://www.dailymail.co.uk/news/article-11954673/Chinese-teapot-especially-Ming-Dynasty-ruler-600-years-ago-sells-11million.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954673/Chinese-teapot-especially-Ming-Dynasty-ruler-600-years-ago-sells-11million.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 18:38:37+00:00

The nine-inch imperial blue and white ewer was made for Yongle Emperor Zhu Di during his reign between 1402 and 1424 and has sold for £11million  in Hong Kong.

## Parents of schoolgirl killed in 'arson attack' going through 'unimaginable pain', mayor says
 - [https://www.dailymail.co.uk/news/article-11954697/Parents-schoolgirl-killed-arson-attack-going-unimaginable-pain-mayor-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954697/Parents-schoolgirl-killed-arson-attack-going-unimaginable-pain-mayor-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 18:25:31+00:00

Tiffany Regis died in Beckton, East London , when a blaze started at around 5.30pm on Thursday. A 16-year-old boy who was arrested on suspicion of murder has been released on bail.

## Elon Musk risks row with the BBC by labelling it as 'government-funded media' on Twitter
 - [https://www.dailymail.co.uk/news/article-11954631/Elon-Musk-risks-row-BBC-labelling-government-funded-media-Twitter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954631/Elon-Musk-risks-row-BBC-labelling-government-funded-media-Twitter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 18:24:21+00:00

Elon Musk has risked a row with the BBC by labelling it as 'government-funded media' on Twitter. The Corporation is mainly funded by British taxpayers, who pay a £159-a-year licence fee.

## Incredulous Riley Gaines slams statement from SF State PRAISING students for 'peaceful' protests
 - [https://www.dailymail.co.uk/news/article-11954485/Incredulous-Riley-Gaines-slams-statement-SF-State-PRAISING-students-peaceful-protests.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954485/Incredulous-Riley-Gaines-slams-statement-SF-State-PRAISING-students-peaceful-protests.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 18:18:21+00:00

Gaines, 23, was forced to barricade inside a room for three hours at the San Francisco State University campus last night after a group of activists ambushed her. The school claimed it was 'peaceful.'

## Missing mom Madeline Kingsbury, 26, was laughing with her sister in texts before she disappeared
 - [https://www.dailymail.co.uk/news/article-11954541/Missing-mom-Madeline-Kingsbury-26-laughing-sister-texts-disappeared.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954541/Missing-mom-Madeline-Kingsbury-26-laughing-sister-texts-disappeared.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 18:04:22+00:00

Missing mom Madeline Kingsbury, 36, was last seen on March 31 at around 10am at her house on Kerry Drive in Winona by the father of her kids. She didn't show up to work of pick her kids up.

## Eurovision fans claim Airbnb landlords are trying to hike prices on stays they've already let out
 - [https://www.dailymail.co.uk/news/article-11954579/Eurovision-fans-claim-Airbnb-landlords-trying-hike-prices-stays-theyve-let-out.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954579/Eurovision-fans-claim-Airbnb-landlords-trying-hike-prices-stays-theyve-let-out.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 18:00:29+00:00

Some hosts have been accused of quadrupling prices when they realised people were coming for the musical competition - with one guest saying his landlord wanted a whooping £2,046.

## Ex-Tennessee state lawmaker ousted for protesting gun violence calls state Speaker an 'autocrat'
 - [https://www.dailymail.co.uk/news/article-11954619/Ex-Tennessee-state-lawmaker-ousted-protesting-gun-violence-calls-state-Speaker-autocrat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954619/Ex-Tennessee-state-lawmaker-ousted-protesting-gun-violence-calls-state-Speaker-autocrat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 17:55:04+00:00

Two ousted Tennessee lawmakers who protested gun violence on the state's House floor accused legislature of being toxic' and said Republican Speaker treats it like his 'personal palace.'

## Melania breaks radio silence with Happy Easter tweet - her first social media post for a MONTH
 - [https://www.dailymail.co.uk/news/article-11954593/Melania-breaks-radio-silence-Happy-Easter-tweet-social-media-post-MONTH.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954593/Melania-breaks-radio-silence-Happy-Easter-tweet-social-media-post-MONTH.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 17:27:04+00:00

Melania Trump broke radio silence with a simple 'Happy Easter!' tweet on Sunday, her first social media post in a month.

## Did Taylor Swift hint at split from Joe Alwyn more than a WEEK ago?
 - [https://www.dailymail.co.uk/news/article-11954439/Did-Taylor-Swift-hint-split-Joe-Alwyn-WEEK-ago.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954439/Did-Taylor-Swift-hint-split-Joe-Alwyn-WEEK-ago.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 17:24:50+00:00

Fans think Taylor Swift hinted about her break up with Joe Alwyn during one of her concerts on March 31 when she switched out 'Invisible String' for 'The 1.'

## Heartbroken father of British sisters murdered in West Bank breaks down in tears at funeral
 - [https://www.dailymail.co.uk/news/article-11954453/Heartbroken-father-British-sisters-murdered-West-Bank-breaks-tears-funeral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954453/Heartbroken-father-British-sisters-murdered-West-Bank-breaks-tears-funeral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 17:23:49+00:00

Sisters Rina and Maya Dee, aged 15 and 20, were killed in a car as they travelled to the Sea of Galilee for a family holiday from their home near Jerusalem.

## Worried police launch urgent hunt for missing schoolboy, 14, who vanished over Easter weekend
 - [https://www.dailymail.co.uk/news/article-11954671/Worried-police-launch-urgent-hunt-missing-schoolboy-14-vanished-Easter-weekend.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954671/Worried-police-launch-urgent-hunt-missing-schoolboy-14-vanished-Easter-weekend.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 17:21:34+00:00

Lewis from Selby, North Yorkshire, was last seen last night (Saturday, April 8) at around 8.35pm when he went into the town centre.

## More than 1,000 revellers attend huge illegal rave at industrial site over Easter weekend
 - [https://www.dailymail.co.uk/news/article-11954581/More-1-000-revellers-attend-huge-illegal-rave-industrial-site-Easter-weekend.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954581/More-1-000-revellers-attend-huge-illegal-rave-industrial-site-Easter-weekend.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 17:05:20+00:00

Police said they were called to reports of a loud event in Bridgend, South Wales, on Saturday night and ordered the crowds to disperse. By lunchtime today there were still hundreds at the site.

## 'I married my cousin': jaw-dropping family secrets exposed by DNA tests
 - [https://www.dailymail.co.uk/news/article-11939177/I-married-cousin-jaw-dropping-family-secrets-exposed-DNA-tests.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11939177/I-married-cousin-jaw-dropping-family-secrets-exposed-DNA-tests.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 16:53:51+00:00

The explosion in popularity of at-home DNA testing kits has led to dozens of Americans uncovering shocking family secrets - including a woman who found out her husband was actually a relative.

## Bill Barr: Democrats emboldening Trump's base 'because he is weakest Republican candidate'
 - [https://www.dailymail.co.uk/news/article-11954473/Bill-Barr-Democrats-emboldening-Trumps-base-weakest-Republican-candidate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954473/Bill-Barr-Democrats-emboldening-Trumps-base-weakest-Republican-candidate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 16:46:42+00:00

Bill Barr said Democrats' want to use the judicial system to get involved with the GOP primary by ensuring that Trump wins because they think they can beat him again in 2024.

## Little girl is rushed to hospital after her face is mauled in dog attack - as police launch probe
 - [https://www.dailymail.co.uk/news/article-11954569/Little-girl-rushed-hospital-face-mauled-dog-attack-police-launch-probe.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954569/Little-girl-rushed-hospital-face-mauled-dog-attack-police-launch-probe.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 16:43:32+00:00

The young girl from Nuneaton, Warwickshire, was left in need of surgery to her face following the vicious attack.

## Missing teenager, 14, who went missing in Cornwall two days ago has been found safe
 - [https://www.dailymail.co.uk/news/article-11954109/Teenage-girl-14-goes-missing-Cornwall-Easter-weekend-prompting-large-police-searches.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954109/Teenage-girl-14-goes-missing-Cornwall-Easter-weekend-prompting-large-police-searches.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 16:31:01+00:00

Katie Clementson, 14, (pictured) was reported missing in the town of Bodmin at 10pm on Good Friday. She was found safe and well by police on Easter Sunday.

## Just 215 of the 45,728 Channel migrants who arrived by small boat last year were deported
 - [https://www.dailymail.co.uk/news/article-11954159/Just-215-45-728-Channel-migrants-arrived-small-boat-year-deported.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954159/Just-215-45-728-Channel-migrants-arrived-small-boat-year-deported.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 16:20:48+00:00

Of the 45,755 migrants who crossed the Channel by small boat last year, 215 have been deported. More than 25,000 of those were also found to be refugees.

## Archdiocese accuses Walter Reed of violating First Amendment right to freedom of religion
 - [https://www.dailymail.co.uk/news/article-11954507/Archdiocese-accuses-Walter-Reed-violating-Amendment-right-freedom-religion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954507/Archdiocese-accuses-Walter-Reed-violating-Amendment-right-freedom-religion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 16:17:48+00:00

The Catholic Archdiocese for the Military Services is accusing Walter Reed National Military Medical Center of violating patients' First Amendment rights by issuing a cease and desist order against priests.

## Warning issued to Australians about facial recognition on phones to make digital payments
 - [https://www.dailymail.co.uk/news/article-11939813/Warning-issued-Australians-facial-recognition-phones-make-digital-payments.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11939813/Warning-issued-Australians-facial-recognition-phones-make-digital-payments.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 16:16:03+00:00

A cyber security expert is warning about the dangers of facial recognition software, arguing artificial intelligence could one day have the potential to hack into digital wallets containing a credit card.

## Lola James's grandmother tells of her guilt at being unable to babysit the night she was killed
 - [https://www.dailymail.co.uk/news/article-11954435/Lola-Jamess-grandmother-tells-guilt-unable-babysit-night-killed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954435/Lola-Jamess-grandmother-tells-guilt-unable-babysit-night-killed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 16:15:49+00:00

The grandmother of toddler Lola James, who was murdered by her mother's boyfriend in Haverfordwest, said she feels guilty for being too unwell to babysit Lola the night she was murdered.

## Met Police failed teenager who took own life after officers assumed threats were 'attention seeking'
 - [https://www.dailymail.co.uk/news/article-11954511/Met-Police-failed-teenager-took-life-officers-assumed-threats-attention-seeking.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954511/Met-Police-failed-teenager-took-life-officers-assumed-threats-attention-seeking.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 16:13:01+00:00

Samuel Howes, the youngest of four siblings, died after being struck by a train at South Croydon station on September 2, 2020.

## New York woman says a police traffic stop caused her miscarriage
 - [https://www.dailymail.co.uk/news/article-11954369/New-York-woman-says-police-traffic-stop-caused-miscarriage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954369/New-York-woman-says-police-traffic-stop-caused-miscarriage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 16:11:31+00:00

Quashaia Oranchak claimed that a March traffic stop caused her to have a miscarriage, saying that she was body slammed against the hood of her car as she was taken into custody.

## Family of British soldier part of 1879 Battle of Rorke's Drift try to buy back his lost medals
 - [https://www.dailymail.co.uk/news/article-11954421/Family-British-soldier-1879-Battle-Rorkes-Drift-try-buy-lost-medals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954421/Family-British-soldier-1879-Battle-Rorkes-Drift-try-buy-lost-medals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 15:57:34+00:00

At just 20 years of age Alfred Saxty was one of 150 British and colonial troops who defended the station of Rorke's Drift in South Africa against 4,000 Zulu warriors.

## Neighbours star Kate Keltie reveals stage four breast cancer 'completely gone' after $37,000 appeal
 - [https://www.dailymail.co.uk/news/article-11879807/Neighbours-star-Kate-Keltie-reveals-stage-four-breast-cancer-completely-gone-37-000-appeal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11879807/Neighbours-star-Kate-Keltie-reveals-stage-four-breast-cancer-completely-gone-37-000-appeal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 15:50:22+00:00

Kate Keltie - who played Michelle Scully on the soap from 1999 - revealed her shock diagnosis in November - but declared she was cancer-free just four months later.

## Perth Northbridge gay man bashed in alleged homophobic attack
 - [https://www.dailymail.co.uk/news/article-11954349/Perth-Northbridge-gay-man-bashed-alleged-homophobic-attack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954349/Perth-Northbridge-gay-man-bashed-alleged-homophobic-attack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 15:50:15+00:00

A gay man has recounted the vicious homophobic assault he suffered at the hands of two strangers in the heart of Perth's nightlife district, which left him nursing a fractured nose.

## Caitlyn Jenner blasts trans activists who attacked swimmer Riley Gaines as the 'Rainbow Mafia'
 - [https://www.dailymail.co.uk/news/article-11954357/Caitlyn-Jenner-blasts-trans-activists-attacked-swimmer-Riley-Gaines-Rainbow-Mafia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954357/Caitlyn-Jenner-blasts-trans-activists-attacked-swimmer-Riley-Gaines-Rainbow-Mafia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 15:43:52+00:00

Caitlyn Jenner, 73, defended swimmer Riley Gaines after she was attacked by the 'Radical Rainbow Mafia' following her saving women's rights speech in San Francisco last week.

## Judges down South are softer on criminals than in the North
 - [https://www.dailymail.co.uk/news/article-11954397/Judges-South-softer-criminals-North.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954397/Judges-South-softer-criminals-North.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 15:41:54+00:00

Convicted offenders in the south are nearly a third more likely to have their cases referred to the Court of Appeal.

## Bud Light has not posted on social media for more than a WEEK amid Dylan Mulvaney partnership
 - [https://www.dailymail.co.uk/news/article-11954285/Bud-Light-not-posted-social-media-WEEK-amid-Dylan-Mulvaney-partnership.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954285/Bud-Light-not-posted-social-media-WEEK-amid-Dylan-Mulvaney-partnership.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 15:28:43+00:00

A week after causing outrage and controversy over their sponsorship deal with transgender activist Dylan Mulvaney, Bud Light has yet to post anything new on social media.

## Fire pit explodes in Sydney's Newport leaving a young woman in a coma
 - [https://www.dailymail.co.uk/news/article-11954183/Fire-pit-explodes-Sydneys-Newport-leaving-young-woman-coma.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954183/Fire-pit-explodes-Sydneys-Newport-leaving-young-woman-coma.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 15:12:59+00:00

A 26-year-old woman suffered severe burns and was one of five people rushed to hospital when a fire pit exploded during a backyard Easter gathering at a luxury beachside home in Sydney.

## Rapist cop David Carrick is accused of carrying out sex attack when he was 13-years-old
 - [https://www.dailymail.co.uk/news/article-11954133/Rapist-cop-David-Carrick-accused-carrying-sex-attack-13-years-old.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954133/Rapist-cop-David-Carrick-accused-carrying-sex-attack-13-years-old.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 15:12:56+00:00

Carrick, 48, was jailed for life with a minimum term of 30 years in February after carrying out a string of 'violent and brutal' sex attacks against at least a dozen women over more than two decades.

## Worshippers gather around the world to mark Easter Sunday as Pope Francis delivers mass
 - [https://www.dailymail.co.uk/news/article-11953937/Worshippers-gather-world-mark-Easter-Sunday-Pope-Francis-delivers-mass.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11953937/Worshippers-gather-world-mark-Easter-Sunday-Pope-Francis-delivers-mass.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 15:00:50+00:00

Members of the Swiss Guard have arrived a to attend the event as devotees await he Pope's mass before the bi-annual 'Urbi et Orbi' - his papal address and apostolic blessing.

## Botox empire Injectable Institute Australia goes into liquidation after sudden death of its founder
 - [https://www.dailymail.co.uk/news/article-11954291/Botox-empire-Injectable-Institute-Australia-goes-liquidation-sudden-death-founder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954291/Botox-empire-Injectable-Institute-Australia-goes-liquidation-sudden-death-founder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 14:53:39+00:00

Sydney company Injectable Institute Australia has gone into liquidation following the sudden death of owner Michael Zillig, leaving a string of angry customers.

## How British con artist scammed the world into thinking he was a millionaire whisky investor
 - [https://www.dailymail.co.uk/news/article-11942319/How-British-artist-scammed-world-thinking-millionaire-whisky-investor.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11942319/How-British-artist-scammed-world-thinking-millionaire-whisky-investor.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 14:52:20+00:00

A British man is facing up to 20 years in US jail after admitting a $13m (£10.5m) scam to dupe elderly Americans into investing in rare Scotch whisky.

## Health secretary accuses 'militant' unions of 'unrealistic' demands ahead of junior doctors strike
 - [https://www.dailymail.co.uk/news/article-11953927/Health-secretary-accuses-militant-unions-unrealistic-demands-ahead-junior-doctors-strike.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11953927/Health-secretary-accuses-militant-unions-unrealistic-demands-ahead-junior-doctors-strike.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 14:37:48+00:00

Junior doctors in England are preparing to take industrial action from Tuesday amid demands for a 35 per cent pay rise to make up for 15 years of below-inflation salary rises.

## Sinister 'incest farm' in Australia's outback where patriarch oversaw generations of interbreeding
 - [https://www.dailymail.co.uk/news/article-11946779/Sinister-incest-farm-Australias-outback-patriarch-oversaw-generations-interbreeding.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11946779/Sinister-incest-farm-Australias-outback-patriarch-oversaw-generations-interbreeding.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 14:37:42+00:00

The 40-strong Colt family, a pseudonym surname, enjoyed being socially remote and were extremely difficult to access - often moving location to avoid detection.

## The seaside towns where house prices are soaring thanks to rising popularity of the Staycation
 - [https://www.dailymail.co.uk/news/article-11942493/The-seaside-towns-house-prices-soaring-thanks-rising-popularity-Staycation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11942493/The-seaside-towns-house-prices-soaring-thanks-rising-popularity-Staycation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 14:36:10+00:00

What can you get for your money in Britain's priciest seaside towns? MailOnline takes a look inside the averagely priced homes at the UK's coastal resorts.

## Police launch murder probe after man in his 20s dies from gunshot wounds in shooting in Sheffield
 - [https://www.dailymail.co.uk/news/article-11954283/Police-launch-murder-probe-man-20s-dies-gunshot-wounds-shooting-Sheffield.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954283/Police-launch-murder-probe-man-20s-dies-gunshot-wounds-shooting-Sheffield.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 14:35:15+00:00

The victim was found with serious gunshot injuries and pronounced dead at the scene. His family have been told but formal identification has yet to take place.

## Sophie Winkleman pulled daughters out of school after pupils are told they'll get iPads in class
 - [https://www.dailymail.co.uk/news/article-11953429/Sophie-Winkleman-pulled-daughters-school-pupils-told-theyll-iPads-class.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11953429/Sophie-Winkleman-pulled-daughters-school-pupils-told-theyll-iPads-class.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 14:34:09+00:00

The Peep Show actor, married to Lord Frederick Windsor, also said that she supported a parents group lobbying to outlaw smartphones for under-16s as use in UK schools is 'normalised'.

## New figures show South East pays HALF of UK's £173bn tax...and to face Chancellor's stealth rises
 - [https://www.dailymail.co.uk/news/article-11953351/New-figures-South-East-pays-HALF-UKs-173bn-tax-face-Chancellors-stealth-rises.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11953351/New-figures-South-East-pays-HALF-UKs-173bn-tax-face-Chancellors-stealth-rises.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 14:33:41+00:00

HMRC statistics show that families in London and the South East are paying a combined £87 billion bill - more than the rest of England put together.

## Up to 40 cars are towed away by police in Snowdonia after 'irresponsible and dangerous' parking
 - [https://www.dailymail.co.uk/news/article-11954269/Up-40-cars-towed-away-police-Snowdonia-irresponsible-dangerous-parking.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954269/Up-40-cars-towed-away-police-Snowdonia-irresponsible-dangerous-parking.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 14:32:32+00:00

North Wales Police said 29 vehicles parked dangerously on narrow mountain roads near Llyn Ogwen, while another nine in Pen y Pass at the bottom of Snowdon were removed on Good Friday.

## How well do YOU know your local area? Try this 2021 Census quiz
 - [https://www.dailymail.co.uk/news/article-11941009/How-know-local-area-Try-2021-Census-quiz.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11941009/How-know-local-area-Try-2021-Census-quiz.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 14:29:23+00:00

How well do you know your area? That's the question the Office for National Statistics (ONS) are challenging Britons in their 2021 Census quiz.

## Tasmanian Medico is fighting for life after allegedly being attacked by a youth  in hospital
 - [https://www.dailymail.co.uk/news/article-11954377/Tasmanian-Medico-fighting-life-allegedly-attacked-youth-hospital.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954377/Tasmanian-Medico-fighting-life-allegedly-attacked-youth-hospital.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 14:25:19+00:00

A youth has been arrested after a medical professional was critically injured at a Tasmanian hospital.

## Northern Ireland police disrupt plan for terror attack to overshadow Biden's visit
 - [https://www.dailymail.co.uk/news/article-11954031/Northern-Ireland-police-disrupt-plan-terror-attack-overshadow-Bidens-visit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954031/Northern-Ireland-police-disrupt-plan-terror-attack-overshadow-Bidens-visit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 14:21:45+00:00

A dissident republican terror group in Northern Ireland has been plotting a major attack to overshadow President Joe Biden's visit to the region this week, according to local reports.

## Britain set to enjoy hottest day of the year today with 18C highs before bank holiday ends in rain
 - [https://www.dailymail.co.uk/news/article-11953923/Britain-set-enjoy-hottest-day-year-today-18C-highs-bank-holiday-ends-rain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11953923/Britain-set-enjoy-hottest-day-year-today-18C-highs-bank-holiday-ends-rain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 14:13:55+00:00

Forecasters expect glorious sunshine due to a high pressure system moving across the country that has 'timed itself nicely' for Easter Sunday.

## Texas AG Paxton slams 'Soros backed' prosecutor after soldier convicted of murdering BLM protester
 - [https://www.dailymail.co.uk/news/article-11954243/Texas-AG-Paxton-slams-Soros-backed-prosecutor-soldier-convicted-murdering-BLM-protester.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954243/Texas-AG-Paxton-slams-Soros-backed-prosecutor-soldier-convicted-murdering-BLM-protester.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 14:11:40+00:00

Texas attorney General Ken Paxton said Travis County District Attorney José Garza had 'weaponized the judicial system' to follow liberal agendas.

## Cyclist goes berserk and smashes the front window of a packed bus in Sydney
 - [https://www.dailymail.co.uk/news/article-11954267/Cyclist-goes-berserk-smashes-window-packed-bus-Sydney.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954267/Cyclist-goes-berserk-smashes-window-packed-bus-Sydney.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 14:03:33+00:00

Footage on Easter Sunday in Sydney shows the man repeatedly strike the windscreen until it shattered with the terrified driver and his passengers watching on.

## Youth crime wave in Townsville sparks fears of vigilante attacks
 - [https://www.dailymail.co.uk/news/article-11954103/Youth-crime-wave-Townsville-sparks-fears-vigilante-attacks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954103/Youth-crime-wave-Townsville-sparks-fears-vigilante-attacks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 13:52:30+00:00

Roaming youth gangs have become increasingly brazen in the town, with a surging number of violent crimes, thefts, break-ins and acts of vandalism.

## The man who sells you LION for dinner: Exotic meat vendor offers everything from 'A to Zebra'
 - [https://www.dailymail.co.uk/news/article-11942435/The-man-sells-LION-dinner-Exotic-meat-vendor-offers-Zebra.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11942435/The-man-sells-LION-dinner-Exotic-meat-vendor-offers-Zebra.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 13:34:32+00:00

An exotic meat producer who prides himself on selling everything from 'A to Zebra' is offering lion meat for $50,000/lb - a decade after restaurants came under fire for serving up the vulnerable species.

## Police find $1.8million stowed away in Toyota HiAce in Sydney
 - [https://www.dailymail.co.uk/news/article-11954247/Police-1-8million-stowed-away-Toyota-HiAce-Sydney.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954247/Police-1-8million-stowed-away-Toyota-HiAce-Sydney.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 13:33:21+00:00

Sydney police nabbed a Toyota HiAce with $1.8million in cash stashed in vacuum-sealed plastic bags and are looking for the owner of the money after making five arrests on drugs charges.

## Passengers in £1m legal fight with TUI after dream Caribbean cruise was cut short after three stops
 - [https://www.dailymail.co.uk/news/article-11954205/Passengers-1m-legal-fight-TUI-dream-Caribbean-cruise-cut-short-three-stops.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954205/Passengers-1m-legal-fight-TUI-dream-Caribbean-cruise-cut-short-three-stops.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 13:29:36+00:00

The legal action involves customers from all over the UK including at least 35 groups from Scotland and 80 families from England including Keith Palmer and his wife Nicki from Cornwall.

## Trump sends bitter Easter message less than one week after being arraigned in Manhattan
 - [https://www.dailymail.co.uk/news/article-11954335/Trump-sends-bitter-Easter-message-one-week-arraigned-Manhattan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954335/Trump-sends-bitter-Easter-message-one-week-arraigned-Manhattan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 13:27:55+00:00

Trump's Easter Day message railed against those who 'dream' of 'destroying' the U.S., including 'RINOS' and 'radical left Democrats' - less than a week after he was arraigned.

## Young Adelaide mum issues warning after buying dodgy used Holden on Facebook Marketplace
 - [https://www.dailymail.co.uk/news/article-11954187/Young-Adelaide-mum-issues-warning-buying-dodgy-used-Holden-Facebook-Marketplace.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954187/Young-Adelaide-mum-issues-warning-buying-dodgy-used-Holden-Facebook-Marketplace.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 13:17:26+00:00

Two days after Andy Hansen spent $4,000 on a serviced Holden Commodore in the Adelaide Hills, the motor conked out and she  
discovered it's paperwork had been fabricated.

## Parents sue school teachers ignored their son as he collapsed lay dying in playground NINE MINUTES
 - [https://www.dailymail.co.uk/news/article-11953749/Parents-sue-school-teachers-ignored-son-collapsed-lay-dying-playground-NINE-MINUTES.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11953749/Parents-sue-school-teachers-ignored-son-collapsed-lay-dying-playground-NINE-MINUTES.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 12:43:00+00:00

Parents of a five-year-old boy who died after collapsing on the playground of a school have filed a wrongful death lawsuit against the Connecticut school and its teachers.

## HMP Frankland prisoners including Wayne Couzens 'will get phones installed in their cells'
 - [https://www.dailymail.co.uk/news/article-11954139/HMP-Frankland-prisoners-including-Wayne-Couzens-phones-installed-cells.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954139/HMP-Frankland-prisoners-including-Wayne-Couzens-phones-installed-cells.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 12:25:54+00:00

The Category A prison in Durham, which is regarded as one of the UK's toughest jails, is where the likes of Sarah Everard's killer Couzens and Soham murderer Huntley are incarcerated.

## Raoul Moat's daughter says new ITV drama about crazed gun killer will 'bring the horror back'
 - [https://www.dailymail.co.uk/news/article-11954129/Raoul-Moats-daughter-says-new-ITV-drama-crazed-gun-killer-bring-horror-back.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954129/Raoul-Moats-daughter-says-new-ITV-drama-crazed-gun-killer-bring-horror-back.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 12:19:01+00:00

The ITV three-parter about one of the most infamous man-hunts in UK history means Ms Fitzpatrick will relive the horror of summer 2010, in which Moat shot three people in the hunt for police officers.

## 'This isn't the retirement I'd planned': More than 2.4 million grandparents are raising grandkids
 - [https://www.dailymail.co.uk/news/consumer-finance/article-11943413/This-isnt-retirement-Id-planned-2-4-million-grandparents-raising-grandkids.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/consumer-finance/article-11943413/This-isnt-retirement-Id-planned-2-4-million-grandparents-raising-grandkids.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 12:12:10+00:00

Grandparents are thrust into the role for many reasons. In some cases, parents have died, become incapacitated by illness or injury, overdosed on opioids, or been locked in prison for a crime.

## Is the old interview question about manhole covers narcissistic or revealing?
 - [https://www.dailymail.co.uk/news/article-11943475/Is-old-interview-question-manhole-covers-narcissistic-revealing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11943475/Is-old-interview-question-manhole-covers-narcissistic-revealing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 12:11:43+00:00

'Why are manhole covers round?' was allegedly made famous as a question Microsoft would ask job candidates, along with others like 'why are tennis balls fuzzy?' to test lateral thinking.

## Intimate portraits of residents in the Bronx gives a glimpse into family life in NYC borough
 - [https://www.dailymail.co.uk/news/article-11946433/Intimate-portraits-residents-Bronx-gives-glimpse-family-life-NYC-borough.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11946433/Intimate-portraits-residents-Bronx-gives-glimpse-family-life-NYC-borough.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 12:11:21+00:00

The intimate portraits appear as part of an exhibtion prepared by the founder of the Instagram account, 'Everyday Bronx', who wants to break down idea that it is riddled with crime - even as it rises.

## Boy is left an orphan after his mother is killed in a car crash in Melbourne
 - [https://www.dailymail.co.uk/news/article-11953911/Boy-left-orphan-mother-killed-car-crash-Melbourne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11953911/Boy-left-orphan-mother-killed-car-crash-Melbourne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 12:05:14+00:00

Having already lost his father and grandmother, the grieving family has now turned to the community to help protect the future of 14-year-old Bailey.

## China sends dozens of jets and eight warships towards Taiwan as they encircle island
 - [https://www.dailymail.co.uk/news/article-11953993/China-sends-dozens-jets-eight-warships-Taiwan-encircle-island.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11953993/China-sends-dozens-jets-eight-warships-Taiwan-encircle-island.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 12:00:11+00:00

Dubbed 'Joint Sword', the three-day operation - which includes rehearsing an encirclement of Taiwan - will run until Monday, the People's Liberation Army's (PLA) Eastern Theatre Command said.

## Experts reveal amount of superannuation Aussies need for comfortable retirement
 - [https://www.dailymail.co.uk/news/article-11953877/Experts-reveal-superannuation-Aussies-need-comfortable-retirement.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11953877/Experts-reveal-superannuation-Aussies-need-comfortable-retirement.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 11:56:50+00:00

The Australian Super Funds Alliance's (ASFA) latest retirement standard has suggested Aussie singles need at least $595,000, and couples $690,000, to comfortably retire.

## Mascot apartment block stabbing: Woman allegedly killed in domestic-related incident
 - [https://www.dailymail.co.uk/news/article-11954221/Mascot-apartment-block-stabbing-Woman-allegedly-killed-domestic-related-incident.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954221/Mascot-apartment-block-stabbing-Woman-allegedly-killed-domestic-related-incident.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 11:48:47+00:00

Police were called to an unit block on Church Avenue in Sydney's Mascot about 6.10pm on Easter Sunday, where a woman believed to be in her 50s was found with knife wounds.

## Keir Starmer told to BACK gender change at 16 by Scottish party boss
 - [https://www.dailymail.co.uk/news/article-11954173/Keir-Starmer-told-gender-change-16-Scottish-party-boss.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954173/Keir-Starmer-told-gender-change-16-Scottish-party-boss.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 11:23:34+00:00

Anas Sarwar, the leader of the Scottish arm of the party, said the Westminster leader should 'learn the lesson' from the law introduced by the SNP last year.

## L-plater teen boy, 16, dies in horror crash on country road in South Australia
 - [https://www.dailymail.co.uk/news/article-11953961/L-plater-teen-boy-16-dies-horror-crash-country-road-South-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11953961/L-plater-teen-boy-16-dies-horror-crash-country-road-South-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 10:56:34+00:00

Johnny Howieson, 16, was tragically killed early on Sunday morning after his Honda station wagon crashed into a tree near Langhorne Creek, about 64km southeast of Adelaide.

## Leaked documents suggest US knows more about Putin's war operations than Zelensky's
 - [https://www.dailymail.co.uk/news/article-11953691/Leaked-documents-suggest-knows-Putins-war-operations-Zelenskys.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11953691/Leaked-documents-suggest-knows-Putins-war-operations-Zelenskys.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 10:52:23+00:00

A huge trove of leaked Pentagon documents suggests the US knows far more about Russia's war campaign than Ukraine's - despite funding the latter to the tune of $200 billion.

## Israel strikes military targets in Syria after six rockets were launched from Syrian territory
 - [https://www.dailymail.co.uk/news/article-11954025/Israel-strikes-military-targets-Syria-six-rockets-launched-Syrian-territory.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954025/Israel-strikes-military-targets-Syria-six-rockets-launched-Syrian-territory.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 10:35:29+00:00

Six rockets were launched in two batches from Syria but only three of the missiles fell within Israeli territory and no one is believed to have been injured.

## Fire erupts at the Park Apartments building at the corner of Oxford and Liverpool Streets in Sydney
 - [https://www.dailymail.co.uk/news/article-11954015/City-tower-block-ablaze-one-firefighter-injured.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954015/City-tower-block-ablaze-one-firefighter-injured.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 10:31:52+00:00

Firefighers were forced to use a huge cherry-picker to combat the exterior of the blaze that broke out in the Park Apartments building at the corner of Oxford and Liverpool Streets in Sydney.

## Mystery surrounds suspected drowning of toddler rushed to hospital after found near SA creek creek
 - [https://www.dailymail.co.uk/news/article-11954035/Mystery-surrounds-suspected-drowning-toddler-rushed-hospital-near-SA-creek-creek.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954035/Mystery-surrounds-suspected-drowning-toddler-rushed-hospital-near-SA-creek-creek.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 10:03:23+00:00

SA Police have confirmed officers and paramedics were called to the scene at Paralowie, about 21km north of Adelaide's CBD, about 9am Sunday to reports of a possible drowning.

## Shoppers forced to abandon cars after being stuck in three-hour car park queues
 - [https://www.dailymail.co.uk/news/article-11953947/Shoppers-forced-abandon-cars-stuck-three-hour-car-park-queues.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11953947/Shoppers-forced-abandon-cars-stuck-three-hour-car-park-queues.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 09:54:42+00:00

Hundreds of drivers were trapped for up to three hours in a Cardiff multi-storey car park amid Easter bank holiday chaos yesterday. Some shoppers even abandoned cars at St Davids Shopping Centre.

## Britain's Chief Rabbi pays tribute to two British sisters murdered in West Bank shooting
 - [https://www.dailymail.co.uk/news/article-11953951/Britains-Chief-Rabbi-pays-tribute-two-British-sisters-murdered-West-Bank-shooting.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11953951/Britains-Chief-Rabbi-pays-tribute-two-British-sisters-murdered-West-Bank-shooting.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 09:53:28+00:00

Sisters Maya, 20, and Rina, 16, were fatally shot as they drove to the Sea of Galilee for a family holiday from their home near Jerusalem. Their mother is in a critical condition.

## London boroughs could be given Brexit-style in-out votes over Ulez
 - [https://www.dailymail.co.uk/news/article-11954061/London-boroughs-given-Brexit-style-votes-Ulez.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954061/London-boroughs-given-Brexit-style-votes-Ulez.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 09:48:38+00:00

Samuel Kasumu, a former adviser to Boris Johnson who wants to be the Tory candidate at the next mayoral election, has said he would allow outer boroughs to hold referenda.

## Brit arrested on suspicion of attempted murder after wife falls six floors from hotel balcony
 - [https://www.dailymail.co.uk/news/article-11954033/Brit-arrested-suspicion-attempted-murder-wife-falls-six-floors-hotel-balcony.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11954033/Brit-arrested-suspicion-attempted-murder-wife-falls-six-floors-hotel-balcony.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 09:48:35+00:00

The 36-year-old woman, who is also British, is said to be in critical condition in hospital. The tourists were staying at the four-star Rio Park hotel (pictured), which is part of the Medplaya chain.

## Frank Skinner announces tribute podcast to co-star Gareth Richards, 41, who died after horror crash
 - [https://www.dailymail.co.uk/news/article-11953895/Frank-Skinner-announces-tribute-podcast-star-Gareth-Richards-41-died-horror-crash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11953895/Frank-Skinner-announces-tribute-podcast-star-Gareth-Richards-41-died-horror-crash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 09:46:29+00:00

Comedian Richards passed away on Good Friday after being in hospital for two weeks, with his injuries so severe that his supportive medications had to be removed.

## Video expose bikers on Sadiq Khan's cycle highways REFUSING to stop for pedestrians at bus stop
 - [https://www.dailymail.co.uk/news/article-11941229/Video-expose-bikers-Sadiq-Khans-cycle-highways-REFUSING-stop-pedestrians-bus-stop.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11941229/Video-expose-bikers-Sadiq-Khans-cycle-highways-REFUSING-stop-pedestrians-bus-stop.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 09:37:04+00:00

Selfish bikers have been caught on video bombing  past pedestrians at one of London's many 'dangerous' bus stops, which force passengers to take a 'leap of faith' through a cycle highway.

## Guy Sebastian argument with Phillip Hanslow captured on video as footage leaks
 - [https://www.dailymail.co.uk/news/article-11953695/Guy-Sebastian-argument-Phillip-Hanslow-captured-video-footage-leaks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11953695/Guy-Sebastian-argument-Phillip-Hanslow-captured-video-footage-leaks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 09:34:29+00:00

Footage of the verbal dispute between Sebastian and Phillip Hanslow outside their homes in Sydney's eastern suburbs was published on Sunday but it only shows part of their conversation.

## Ant and Dec's Saturday Night Takeaway under environmental fire for flying EMPTY planes to the US
 - [https://www.dailymail.co.uk/tvshowbiz/article-11953265/Ant-Decs-Saturday-Night-Takeaway-environmental-fire-flying-planes-US.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-11953265/Ant-Decs-Saturday-Night-Takeaway-environmental-fire-flying-planes-US.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 09:32:35+00:00

ITV and British Airways have been embroiled in an environmental storm after flying empty planes across the Atlantic for the final of Ant and Dec's Saturday Night Takeaway  this weekend.

## Prime Minister Anthony Albanese recruiting sports stars to push a 'yes' vote for Voice referendum
 - [https://www.dailymail.co.uk/news/article-11953909/Prime-Minister-Anthony-Albanese-recruiting-sports-stars-push-yes-vote-Voice-referendum.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11953909/Prime-Minister-Anthony-Albanese-recruiting-sports-stars-push-yes-vote-Voice-referendum.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 09:27:31+00:00

Prime Minister Anthony Albanese has spoken to NRL and AFL players past and present as he looks for sports stars to back the proposed Indigenous Voice to Parliament.

## Prince William enjoys mini me moments with his Prince George as they watch Aston Villa
 - [https://www.dailymail.co.uk/femail/article-11952317/Prince-William-enjoys-mini-moments-Prince-George-watch-Aston-Villa.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-11952317/Prince-William-enjoys-mini-moments-Prince-George-watch-Aston-Villa.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 09:16:37+00:00

Prince George, nine, showed he is a chip off the old block during Aston Villa's fixture against Nottingham Forest today, where he was snapped pulling the same faces as his father Prince William.

## Harry Styles is most happy at home in Cheshire, in a rare interview, his proud mother says
 - [https://www.dailymail.co.uk/femail/article-11952883/Harry-Styles-happy-home-Cheshire-rare-interview-proud-mother-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-11952883/Harry-Styles-happy-home-Cheshire-rare-interview-proud-mother-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 09:16:31+00:00

At one point in her son's journey through the X Factor talent machine, Simon Cowell pointed out to Anne Twist that mums can be a bit biased when it comes to their children's talents.

## Hannibal Lecter obsessed student led hacked off teacher's head in 'self-improvement plan'
 - [https://www.dailymail.co.uk/news/article-11940959/Hannibal-Lecter-obsessed-student-led-hacked-teachers-head-self-improvement-plan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11940959/Hannibal-Lecter-obsessed-student-led-hacked-teachers-head-self-improvement-plan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 08:50:47+00:00

In a crime that sent shock waves across Poland, Kajetan Poznanski (pictured) was jailed in 2021 after telling judges he murdered the woman as part of a 'self-improvement plan'.

## Donald Trump attends UFC Miami fight with Kid Rock - but there's still NO sign of Melania!
 - [https://www.dailymail.co.uk/news/article-11953729/Donald-Trump-attends-UFC-Miami-fight-Kid-Rock-theres-NO-sign-Melania.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11953729/Donald-Trump-attends-UFC-Miami-fight-Kid-Rock-theres-NO-sign-Melania.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 08:34:54+00:00

The former president was met with cheers from the audience Saturday night at a UFC fight in Miami with Dana White, Kid Rock and Mike Tyson.

## Labour accuses Sunak of going soft on RAPISTS as Yvette Cooper joins ad campaign sceptics
 - [https://www.dailymail.co.uk/news/article-11953959/Labour-accuses-Sunak-going-soft-RAPISTS-Yvette-Cooper-joins-ad-campaign-sceptics.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11953959/Labour-accuses-Sunak-going-soft-RAPISTS-Yvette-Cooper-joins-ad-campaign-sceptics.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 08:24:10+00:00

Yvette Cooper, the shadow home secretary, was blindsided by a Twitter ad campaign accursing the PM of personally going easy on paedophiles, it was reported today.

## Cancer-stricken scientist who created first antibiotic type in 40 years may die before Nobel Prize
 - [https://www.dailymail.co.uk/health/article-11952247/Cancer-stricken-scientist-created-antibiotic-type-40-years-die-Nobel-Prize.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-11952247/Cancer-stricken-scientist-created-antibiotic-type-40-years-die-Nobel-Prize.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 08:21:09+00:00

Kirsty Smitten (pictured), 28, harbours fantasies of one day collecting a Nobel Prize for her scientific work - and rightly so, given that it could save millions of lives and avert a medical catastrophe.

## Malka Leifer: Bombshell video and story behind three sister's 15-year-fight to bring her to justic
 - [https://www.dailymail.co.uk/news/article-11953809/Malka-Leifer-Bombshell-video-story-three-sisters-15-year-fight-bring-justic.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11953809/Malka-Leifer-Bombshell-video-story-three-sisters-15-year-fight-bring-justic.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 08:20:18+00:00

Last Monday, after 31 hours of deliberation over nine days, former Jewish school principal Malka Leifer was  found guilty of raping two of her female students.

## Victorian MPs could be paid almost $300k as they search for a new job - with taxpayers footing bill
 - [https://www.dailymail.co.uk/news/article-11953791/Victorian-MPs-paid-300k-search-new-job-taxpayers-footing-bill.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11953791/Victorian-MPs-paid-300k-search-new-job-taxpayers-footing-bill.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 08:09:45+00:00

A new payment scheme could see departing state politicians be paid up to $300,000 as they search for a new job.

## Phillip Schofield will return to This Morning after the Easter break
 - [https://www.dailymail.co.uk/tvshowbiz/article-11952955/Phillip-Schofields-Morning-break-extended-brothers-trial.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-11952955/Phillip-Schofields-Morning-break-extended-brothers-trial.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 08:06:42+00:00

Phillip Schofield will return to his presenting job on This morning following claims he held crisis talks with bosses over his break from the show.

## 'Donald Trump' likens himself to Jesus at Last Supper in SNL skit parodying his indictment
 - [https://www.dailymail.co.uk/news/article-11953739/Donald-Trump-likens-Jesus-Supper-SNL-skit-parodying-indictment.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11953739/Donald-Trump-likens-Jesus-Supper-SNL-skit-parodying-indictment.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 08:05:34+00:00

Saturday Night Live opened with The Last Supper and an appearance by Donald Trump, played by James Austin Johnson, who likened himself to Jesus.

## Police hunt for Bartholemew Griffth who allegedly doused woman in petrol in Melbourne
 - [https://www.dailymail.co.uk/news/article-11953811/Police-hunt-Bartholemew-Griffth-allegedly-doused-woman-petrol-Melbourne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11953811/Police-hunt-Bartholemew-Griffth-allegedly-doused-woman-petrol-Melbourne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 07:57:53+00:00

A manhunt is underway in Melbourne for an escaped patient, Bartholemew Griffith, from Austin Hospital who allegedly tried to set fire to a Northcote wellness centre and a woman inside.

## Nayland Colege student secretly records teacher's extraordinarily swearword-riddled meltdown
 - [https://www.dailymail.co.uk/news/article-11937141/Nayland-Colege-student-secretly-records-teachers-extraordinarily-swearword-riddled-meltdown.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11937141/Nayland-Colege-student-secretly-records-teachers-extraordinarily-swearword-riddled-meltdown.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 07:45:37+00:00

A teacher has been secretly recorded unleashing a foul-mouthed tirade at his stunned class. Bizarrely the teacher, at New Zealand's Nayland College was allowed to keep teaching.

## Donald Trump hits golf course in Miami for relaxing game as his poll numbers rocket past DeSantis
 - [https://www.dailymail.co.uk/news/article-11953115/Donald-Trump-hits-golf-course-Miami-relaxing-game-poll-numbers-rocket-past-DeSantis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11953115/Donald-Trump-hits-golf-course-Miami-relaxing-game-poll-numbers-rocket-past-DeSantis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 07:09:51+00:00

Donald Trump played a calm round of golf Saturday morning at his hotel in Miami after the chaos of the indictment earlier this week.

## Fix now or hold out: What are the options if you need to remortgage?
 - [https://www.dailymail.co.uk/money/mortgageshome/article-11952795/Fixed-five-years-Two-tracker-mortgage-gamble-million-families-dont-want-take.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/money/mortgageshome/article-11952795/Fixed-five-years-Two-tracker-mortgage-gamble-million-families-dont-want-take.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 07:07:06+00:00

Families looking to remortgage are facing a tough choice over whether to lock into a long-term deal or hold out in the hope that rates will come down in the near future.

## Barnaby Joyce mispronounces Anthony Albanese's name, lists reasons Aussies should vote 'No' on Voice
 - [https://www.dailymail.co.uk/news/article-11953651/Barnaby-Joyce-mispronounces-Anthony-Albaneses-lists-reasons-Aussies-vote-No-Voice.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11953651/Barnaby-Joyce-mispronounces-Anthony-Albaneses-lists-reasons-Aussies-vote-No-Voice.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 06:49:17+00:00

Barnaby Joyce  mispronounced Anthony Albanese's name yet again as he listed five reasons why Australians should vote 'No' to an Indigenous Voice to Parliament.

## Texas Gov. Greg Abbott says he's working to 'swiftly' pardon Fort Hood soldier convicted of murder
 - [https://www.dailymail.co.uk/news/article-11953427/Texas-Gov-Greg-Abbott-says-hes-working-swiftly-pardon-Fort-Hood-soldier-convicted-murder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11953427/Texas-Gov-Greg-Abbott-says-hes-working-swiftly-pardon-Fort-Hood-soldier-convicted-murder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 06:37:10+00:00

Texas Gov. Greg Abbott said that he is working to pardon a U.S. Army sergeant, Sgt. Daniel Perry, convicted of murder for fatally shooting an armed protester at a 2020 riot in Austin.

## Police manhunt underway for Brisbane fugitive Mitchell Wilson after alleged gunpoint crime spree
 - [https://www.dailymail.co.uk/news/article-11953725/Police-manhunt-underway-Brisbane-fugitive-Mitchell-Wilson-alleged-gunpoint-crime-spree.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11953725/Police-manhunt-underway-Brisbane-fugitive-Mitchell-Wilson-alleged-gunpoint-crime-spree.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 06:18:56+00:00

A manhunt is underway in Queensland for an accused drug trafficker who allegedly fired a gun at three separate incidents on Thursday, one of which was involved a 'life or death' struggle for the gun.

## Prince Harry being stripped of his Duke of Sussex title 'has been discussed at the highest level'
 - [https://www.dailymail.co.uk/news/article-11953129/Prince-Harry-stripped-Duke-Sussex-title-discussed-highest-level.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11953129/Prince-Harry-stripped-Duke-Sussex-title-discussed-highest-level.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 06:17:47+00:00

Palace insiders made jokes about Harry being a 'victim of Stockholm syndrome' as they blamed Meghan for the 'fallout' with the Royal Family. Others say he is the 'driving force' in the row.

## Ron DeSantis' stalling 2024 campaign faces fresh woes as top GOP figures voice doubts over abilities
 - [https://www.dailymail.co.uk/news/article-11951607/Ron-DeSantis-stalling-2024-campaign-faces-fresh-woes-GOP-figures-voice-doubts-abilities.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11951607/Ron-DeSantis-stalling-2024-campaign-faces-fresh-woes-GOP-figures-voice-doubts-abilities.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 05:10:20+00:00

As Florida Governor Ron DeSantis ponders a 2024 presidential campaign his ability to raise money from wealthy donors is seen as one of his main strengths. He raised $110m but it is not a guarantee of success

## Warsaw to enjoy tourism boost after visit from Prince William
 - [https://www.dailymail.co.uk/news/article-11904495/Warsaw-enjoy-tourism-boost-visit-Prince-William.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11904495/Warsaw-enjoy-tourism-boost-visit-Prince-William.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 05:01:11+00:00

Warsaw - the vibrant Polish capital often overlooked by UK tourists for Krakow - is set to enjoy a  tourism boost after getting the royal seal of approval from Prince William.

## Las Vegas woman arrested 'after she let boy hold on to side of her moving car while skateboarding'
 - [https://www.dailymail.co.uk/news/article-11953529/Las-Vegas-woman-arrested-let-boy-hold-moving-car-skateboarding.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11953529/Las-Vegas-woman-arrested-let-boy-hold-moving-car-skateboarding.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 04:47:15+00:00

Anais Hernandez of Las Vegas has been arrested months after Anthony De La Torre, 15, was crushed to death when she let him ride his skateboard while holding onto the side of her car.

## Fingal Spit at Port Stephens tragedy as man drowns trying to save girl on Easter Sunday
 - [https://www.dailymail.co.uk/news/article-11953595/Fingal-Spit-Port-Stephens-tragedy-man-drowns-trying-save-girl-Easter-Sunday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11953595/Fingal-Spit-Port-Stephens-tragedy-man-drowns-trying-save-girl-Easter-Sunday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 04:34:18+00:00

A man has tragically drowned while trying to rescue a girl in the surf at a popular beach.

## Texas grandmas become internet stars after traveling around the world in 80 days
 - [https://www.dailymail.co.uk/news/article-11953553/Texas-grandmas-internet-stars-traveling-world-80-days.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11953553/Texas-grandmas-internet-stars-traveling-world-80-days.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 04:26:49+00:00

Two Texan grandmothers became internet sensations when they documented their journey around the world in 80 days for their eightieth birthdays.

## Barefoot Investor shares advice for Aussie homeowners after building company Porter Davis collapse
 - [https://www.dailymail.co.uk/news/article-11953433/Barefoot-Investor-shares-advice-Aussie-homeowners-building-company-Porter-Davis-collapse.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11953433/Barefoot-Investor-shares-advice-Aussie-homeowners-building-company-Porter-Davis-collapse.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 03:27:20+00:00

Scott Pape, known as the Barefoot Investor, has given advice to homeowners deserted after the collapse of major building firm Porter Davis - before warning future buyers.

## Alice McCall financial controller accused of stealing more than $340,000 from brand
 - [https://www.dailymail.co.uk/news/article-11953399/Alice-McCall-financial-controller-accused-stealing-340-000-brand.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11953399/Alice-McCall-financial-controller-accused-stealing-340-000-brand.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 02:50:27+00:00

The former financial controller of the now liquidated Australian fashion brand Alice McCall allegedly stole around $340,000 from the company.

## Pub-goer outraged after a schooner of beer set him back $15.70 on Good Friday at Merivale's El Loco
 - [https://www.dailymail.co.uk/news/article-11953167/Pub-goer-outraged-schooner-beer-set-15-70-Good-Friday-Merivales-El-Loco.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11953167/Pub-goer-outraged-schooner-beer-set-15-70-Good-Friday-Merivales-El-Loco.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 02:00:08+00:00

Sydney man in shock after paying a couple of beers at a pub on Good Friday as Easter rates bite consumers.

## Is it wise for the Christianity of the Coronation to be so diluted in the name of diversity?
 - [https://www.dailymail.co.uk/debate/article-11952949/Is-wise-Christianity-Coronation-diluted-diversity.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/debate/article-11952949/Is-wise-Christianity-Coronation-diluted-diversity.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 01:14:30+00:00

Almost 30 years ago, the then Prince Charles sparked a firestorm by signalling that, as King, he'd want a fundamental shift in the relationship between Church and Crown.

## Mother of murdered Olivia Pratt-Korbel vows to crackdown on gangs and gun crime
 - [https://www.dailymail.co.uk/news/article-11953221/Mother-murdered-Olivia-Pratt-Korbel-vows-crackdown-gangs-gun-crime.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11953221/Mother-murdered-Olivia-Pratt-Korbel-vows-crackdown-gangs-gun-crime.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 01:10:38+00:00

Cheryl Korbel, 46, today outlined her vision to get 'guns off the streets' and 'get rid of gangs' following the murder of her nine-year-old daughter Olivia Pratt-Korbel.

## As the Queen's life gently ebbed away, Charles foraged for mushrooms at Birkhall
 - [https://www.dailymail.co.uk/debate/article-11952959/As-Queens-life-gently-ebbed-away-Charles-foraged-mushrooms-Birkhall.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/debate/article-11952959/As-Queens-life-gently-ebbed-away-Charles-foraged-mushrooms-Birkhall.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-04-09 00:49:48+00:00

King Charles (pictured in Windsor Great Park) has become accustomed to being mocked for talking to plants or otherwise communing with nature. However, such carping doesn't matter to him.

