# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Ludzie vs Maszyny Podcast
 - [https://www.youtube.com/watch?v=Bu-Kq8pjtMM](https://www.youtube.com/watch?v=Bu-Kq8pjtMM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2023-04-09 17:00:08+00:00

Czy chat GPT zabierze nam prace? Rozmowa z Mateuszem Chrobokiem z kanału @MateuszChrobok  
Grafikę do podcastu stworzył DALL·E 2

