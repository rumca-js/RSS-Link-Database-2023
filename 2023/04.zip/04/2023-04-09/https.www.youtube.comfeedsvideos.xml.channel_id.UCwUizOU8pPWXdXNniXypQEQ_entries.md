# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## Toxic Masculinity is unsafe!
 - [https://www.youtube.com/watch?v=rdLLfRyZY80](https://www.youtube.com/watch?v=rdLLfRyZY80)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2023-04-09 18:33:20+00:00

#shorts

