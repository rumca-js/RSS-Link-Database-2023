# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## Polskie szpadzistki mistrzyniami świata juniorek
 - [https://eurosport.tvn24.pl/polskie-szpadzistki-mistrzyniami--wiata-junior-w,1142444.html?source=rss](https://eurosport.tvn24.pl/polskie-szpadzistki-mistrzyniami--wiata-junior-w,1142444.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 20:10:49+00:00

<img alt="Polskie szpadzistki mistrzyniami świata juniorek" src="https://tvn24.pl/najnowsze/cdn-zdjecie-85opyg-polskie-szpadzistki-wywalczyly-zloty-medal-msj-6893325/alternates/LANDSCAPE_1280" />
    Złoty medal w rywalizacji drużynowej.

## Gigantyczna wpadka bramkarza. Pomylił piłkę z punktem do karnego
 - [https://eurosport.tvn24.pl/gigantyczna-wpadka-bramkarza--pomyli--pi-k--z-punktem-do-karnego,1142443.html?source=rss](https://eurosport.tvn24.pl/gigantyczna-wpadka-bramkarza--pomyli--pi-k--z-punktem-do-karnego,1142443.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 19:22:00+00:00

<img alt="Gigantyczna wpadka bramkarza. Pomylił piłkę z punktem do karnego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-b8uplw-fatalny-blad-oliviera-dovina-w-meczu-szwedzkiej-ekstraklasy-6893306/alternates/LANDSCAPE_1280" />
    Piłkarskie jaja na Wielkanoc.

## Dwóch policjantów i kontrola drogowa motocyklisty. Wszyscy nie żyją
 - [https://tvn24.pl/swiat/usa-wisconsin-dwoch-policjantow-zastrzelonych-w-trakcie-kontroli-drogowej-6893281?source=rss](https://tvn24.pl/swiat/usa-wisconsin-dwoch-policjantow-zastrzelonych-w-trakcie-kontroli-drogowej-6893281?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 19:20:36+00:00

<img alt="Dwóch policjantów i kontrola drogowa motocyklisty. Wszyscy nie żyją " src="https://tvn24.pl/najnowsze/cdn-zdjecie-6c9deo-policja-usa-6148574/alternates/LANDSCAPE_1280" />
    W Wisconsin.

## Ponad trzygodzinny thriller dla Hurkacza
 - [https://eurosport.tvn24.pl/thriller-w-monte-carlo-dla-hurkacza,1142421.html?source=rss](https://eurosport.tvn24.pl/thriller-w-monte-carlo-dla-hurkacza,1142421.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 18:50:00+00:00

<img alt="Ponad trzygodzinny thriller dla Hurkacza" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wx6jf5-hubert-hurkacz-doprowadzil-do-remisu-w-meczu-z-laslo-djere-6893289/alternates/LANDSCAPE_1280" />
    Już wydawało się, że odpadnie z turnieju.

## Wyspy kluczowe dla bezpieczeństwa Finlandii i petycja w sprawie rosyjskiego konsulatu
 - [https://tvn24.pl/swiat/finlandia-wyspy-alandzkie-petycja-o-likwidacje-konsulatu-rosji-6892938?source=rss](https://tvn24.pl/swiat/finlandia-wyspy-alandzkie-petycja-o-likwidacje-konsulatu-rosji-6892938?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 18:49:35+00:00

<img alt="Wyspy kluczowe dla bezpieczeństwa Finlandii i petycja w sprawie rosyjskiego konsulatu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3b0p9c-wyspy-alandzkie-6096358/alternates/LANDSCAPE_1280" />
    Placówka utrzymywana jest na Wyspach Alandzkich od czasów II wojny światowej.

## "Osoby te zostały zepchnięte. Nie myślimy o nich w kategoriach systemowych"
 - [https://tvn24.pl/polska/wykluczenie-spoleczne-wiceprzewodniczaca-monar-nie-myslimy-o-tych-osobach-w-kategoriach-systemowych-6893251?source=rss](https://tvn24.pl/polska/wykluczenie-spoleczne-wiceprzewodniczaca-monar-nie-myslimy-o-tych-osobach-w-kategoriach-systemowych-6893251?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 18:13:27+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hhp9k5-fakty-po-faktach-6893252/alternates/LANDSCAPE_1280" />
    Goście "Faktów po Faktach" o wykluczeniu społecznym.

## Emocje do końca w angielskim hicie
 - [https://eurosport.tvn24.pl/emocje-do-ko-ca-w-angielskim-hicie--lidera-uratowa--bramkarz,1142434.html?source=rss](https://eurosport.tvn24.pl/emocje-do-ko-ca-w-angielskim-hicie--lidera-uratowa--bramkarz,1142434.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 18:10:23+00:00

<img alt="Emocje do końca w angielskim hicie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bp1mwi-ramsdale-mial-co-robic-6893254/alternates/LANDSCAPE_1280" />
    Lidera uratował bramkarz.

## Ledwo zasypali jedną dziurę, już mają kolejną. Nowa ma 10 metrów szerokości
 - [https://tvn24.pl/polska/trzebinia-kolejne-zapadlisko-dziura-powstala-przy-ulicy-kopalnianej-6893227?source=rss](https://tvn24.pl/polska/trzebinia-kolejne-zapadlisko-dziura-powstala-przy-ulicy-kopalnianej-6893227?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 17:01:29+00:00

<img alt="Ledwo zasypali jedną dziurę, już mają kolejną. Nowa ma 10 metrów szerokości " src="https://tvn24.pl/najnowsze/cdn-zdjecie-zcgs5l-trzebinia-zapadliwsko-lukasz-michalik-_005-6891196/alternates/LANDSCAPE_1280" />
    Kolejny taki incydent w Trzebini.

## Rosyjska tenisistka przyrzeka: drugi raz to się nie wydarzy
 - [https://eurosport.tvn24.pl/rosyjska-tenisistka-przyrzeka--drugi-raz-to-si--nie-wydarzy,1142426.html?source=rss](https://eurosport.tvn24.pl/rosyjska-tenisistka-przyrzeka--drugi-raz-to-si--nie-wydarzy,1142426.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 16:59:00+00:00

<img alt="Rosyjska tenisistka przyrzeka: drugi raz to się nie wydarzy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-221lp6-anastazja-potapowa-6893231/alternates/LANDSCAPE_1280" />
    Wcześniej była krytykowana przez Igę Świątek.

## Delfiny z Morza Czarnego ofiarami rosyjskiej inwazji. "Cierpią i czują ból. Umierały długie godziny"
 - [https://tvn24.pl/tvnmeteo/swiat/delfiny-z-morza-czarnego-ofiarami-rosyjskiej-inwazji-moga-wyginac-badania-polskich-i-ukrainskich-naukowcow-6893158?source=rss](https://tvn24.pl/tvnmeteo/swiat/delfiny-z-morza-czarnego-ofiarami-rosyjskiej-inwazji-moga-wyginac-badania-polskich-i-ukrainskich-naukowcow-6893158?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 16:24:00+00:00

<img alt="Delfiny z Morza Czarnego ofiarami rosyjskiej inwazji. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-tdp4gz-delfin-z-morza-czarnego-5705512/alternates/LANDSCAPE_1280" />
    Naukowcy z Uniwersytetu Rzeszowskiego i z Ukrainy informują o "porażających" wynikach swoich badań.

## "To będzie koalicja, która naprawi Estonię"
 - [https://tvn24.pl/swiat/estonia-zawarto-umowe-koalicyjna-w-sprawie-powolania-nowego-rzadu-6893177?source=rss](https://tvn24.pl/swiat/estonia-zawarto-umowe-koalicyjna-w-sprawie-powolania-nowego-rzadu-6893177?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 16:22:06+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-73xxyp-kaja-kallas-6857451/alternates/LANDSCAPE_1280" />
    Zawarto umowę koalicyjną.

## Samochód wjechał w sarnę, później roztrzaskał się o drzewo. Kierowca nie żyje
 - [https://tvn24.pl/poznan/skwierzyna-samochod-wjechal-w-sarne-pozniej-roztrzaskal-sie-o-drzewo-nie-zyje-kierowca-6893190?source=rss](https://tvn24.pl/poznan/skwierzyna-samochod-wjechal-w-sarne-pozniej-roztrzaskal-sie-o-drzewo-nie-zyje-kierowca-6893190?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 16:00:51+00:00

<img alt="Samochód wjechał w sarnę, później roztrzaskał się o drzewo. Kierowca nie żyje" src="https://tvn24.pl/najnowsze/cdn-zdjecie-tb7685-nie-zyje-kierowca-bmw-ktory-roztrzaskal-sie-o-drzewo-6893183/alternates/LANDSCAPE_1280" />
    Pasażerowie wyszli z auta o własnych siłach.

## Prowadził 5:1. Seta przegrał, potem cały mecz
 - [https://eurosport.tvn24.pl/zaskakuj-ce-rozstrzygni-cie-w-monte-carlo--paire-przegra--niemal-wygrany-mecz,1142418.html?source=rss](https://eurosport.tvn24.pl/zaskakuj-ce-rozstrzygni-cie-w-monte-carlo--paire-przegra--niemal-wygrany-mecz,1142418.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 15:57:00+00:00

<img alt="Prowadził 5:1. Seta przegrał, potem cały mecz" src="https://tvn24.pl/najnowsze/cdn-zdjecie-yy82c4-benoit-paire-nie-zagra-w-turnieju-atp-1000-w-monte-carlo-6893196/alternates/LANDSCAPE_1280" />
    Cuda w Monte Carlo.

## Nie żyje Maciej Prus
 - [https://tvn24.pl/kultura-i-styl/maciej-prus-nie-zyje-aktor-i-rezyser-mial-85-lat-6893185?source=rss](https://tvn24.pl/kultura-i-styl/maciej-prus-nie-zyje-aktor-i-rezyser-mial-85-lat-6893185?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 15:45:47+00:00

<img alt="Nie żyje Maciej Prus" src="https://tvn24.pl/najnowsze/cdn-zdjecie-eoft6y-maciej-prus-6893111/alternates/LANDSCAPE_1280" />
    Aktor i reżyser miał 85 lat.

## Wielkie zwycięstwo Holendra w Piekle Północy
 - [https://eurosport.tvn24.pl/mathieu-van-der-poel-triumfuje-w-pary----roubaix--dublet-alpecin-deceuninck-w-piekle-p--nocy,1142417.html?source=rss](https://eurosport.tvn24.pl/mathieu-van-der-poel-triumfuje-w-pary----roubaix--dublet-alpecin-deceuninck-w-piekle-p--nocy,1142417.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 15:19:00+00:00

<img alt="Wielkie zwycięstwo Holendra w Piekle Północy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-evy2kx-mathieu-van-der-poel-wygral-wyscig-paryz-roubaix-2023-6893171/alternates/LANDSCAPE_1280" />
    Słynny wyścig Paryż - Roubaix dla Mathieu van der Poela.

## Zajęcia z technik przetrwania, roślin jadalnych i zwierząt jadowitych. Pierwszy taki kierunek studiów w Polsce
 - [https://tvn24.pl/bialystok/lublin-uniwerystet-przyrodniczy-survival-i-animacja-przyrodnicza-to-pierwszy-taki-kierunek-studiow-w-polsce-6893060?source=rss](https://tvn24.pl/bialystok/lublin-uniwerystet-przyrodniczy-survival-i-animacja-przyrodnicza-to-pierwszy-taki-kierunek-studiow-w-polsce-6893060?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 14:57:44+00:00

<img alt="Zajęcia z technik przetrwania, roślin jadalnych i zwierząt jadowitych. Pierwszy taki kierunek studiów w Polsce" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bbh1jc-beda-mieli-zajecia-chociazby-z-technik-przetrwania-6893066/alternates/LANDSCAPE_1280" />
    Survival i animacja przyrodnicza na Uniwersytecie Przyrodniczym w Lublinie.

## Lawina zeszła w Alpach, są zabici. "Najtragiczniejszy wypadek w tym sezonie"
 - [https://tvn24.pl/tvnmeteo/swiat/francja-lawina-zeszla-w-alpach-na-lodowcu-armancette-zabici-i-ranni-6893051?source=rss](https://tvn24.pl/tvnmeteo/swiat/francja-lawina-zeszla-w-alpach-na-lodowcu-armancette-zabici-i-ranni-6893051?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 14:11:54+00:00

<img alt="Lawina zeszła w Alpach, są zabici. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-85kjg7-lawina-na-lodowcu-armancette-6893165/alternates/LANDSCAPE_1280" />
    Do tragedii doszło we Francji.

## Tiger Woods wycofał się z The Masters
 - [https://eurosport.tvn24.pl/tiger-woods-wycofa--si--z-the-masters,1142412.html?source=rss](https://eurosport.tvn24.pl/tiger-woods-wycofa--si--z-the-masters,1142412.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 14:08:00+00:00

<img alt="Tiger Woods wycofał się z The Masters" src="https://tvn24.pl/najnowsze/cdn-zdjecie-r8smn0-tiger-woods-wycofal-sie-z-the-masters-2023-6893052/alternates/LANDSCAPE_1280" />
    - Dziękuję kibicom i organizatorom - napisał w mediach społecznościowych.

## Smutne pożegnanie Sagana ze znanym wyścigiem
 - [https://eurosport.tvn24.pl/smutne-po-egnanie-sagana-z-pary--roubaix,1142413.html?source=rss](https://eurosport.tvn24.pl/smutne-po-egnanie-sagana-z-pary--roubaix,1142413.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 13:55:00+00:00

<img alt="Smutne pożegnanie Sagana ze znanym wyścigiem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-akrdw5-peter-sagan-po-kraksie-wycofal-sie-z-wyscigu-paryz-roubaix-6893032/alternates/LANDSCAPE_1280" />
    Upadek na 151 km przed metą.

## Polacy odsunięci od prowadzenia meczu w Grecji. "Zostałem opluty i uderzony"
 - [https://eurosport.tvn24.pl/polacy-odsuni-ci-od-prowadzenia-meczu-w-grecji---zosta-em-opluty-i-uderzony-,1142411.html?source=rss](https://eurosport.tvn24.pl/polacy-odsuni-ci-od-prowadzenia-meczu-w-grecji---zosta-em-opluty-i-uderzony-,1142411.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 13:45:32+00:00

<img alt="Polacy odsunięci od prowadzenia meczu w Grecji. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-jr9hgc-pawel-raczkowski-ostatnio-nie-ma-najlepszego-momentu-w-karierze-6893027/alternates/LANDSCAPE_1280" />
    Zaskakujące stanowisko zajął potentat tamtejszej ligi Olympiakos.

## W spadku z Francji miał dostać "sporą sumę gotówki", najpierw sam musiał zapłacić
 - [https://tvn24.pl/wroclaw/jawor-oszukany-metoda-na-spadek-z-francji-mial-dostac-spora-sume-gotowki-najpierw-sam-musial-zaplacic-6892719?source=rss](https://tvn24.pl/wroclaw/jawor-oszukany-metoda-na-spadek-z-francji-mial-dostac-spora-sume-gotowki-najpierw-sam-musial-zaplacic-6892719?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 13:29:00+00:00

<img alt="W spadku z Francji miał dostać " src="https://tvn24.pl/najnowsze/cdn-zdjecie-gbqyyj-kobieta-uwierzyla-ze-rozmawia-z-pracownikiem-banku-zdj-ilustracyjne-6770909/alternates/LANDSCAPE_1280" />
    Oszustwo metodą "na spadek".

## "Kiedy ich zapraszamy, wkracza radość i nadzieja"
 - [https://tvn24.pl/tvnwarszawa/wola/warszawa-wielkanocne-sniadanie-dla-samotnych-i-potrzebujacych-6892982?source=rss](https://tvn24.pl/tvnwarszawa/wola/warszawa-wielkanocne-sniadanie-dla-samotnych-i-potrzebujacych-6892982?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 13:11:24+00:00

<img alt="" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-9c2yt0-sniadanie-wielkanocne-dla-osob-samotnych-i-potrzebujacych-6892985/alternates/LANDSCAPE_1280" />
    Wielkanocne śniadanie dla samotnych i potrzebujących.

## Msze rezurekcyjne w polskich miastach. "Potrzebujemy odnowienia"
 - [https://tvn24.pl/poznan/gniezno-msza-rezurekcyjna-w-katedrze-gnieznienskiej-potrzebujemy-odnowienia-6892958?source=rss](https://tvn24.pl/poznan/gniezno-msza-rezurekcyjna-w-katedrze-gnieznienskiej-potrzebujemy-odnowienia-6892958?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 13:08:52+00:00

<img alt="Msze rezurekcyjne w polskich miastach. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-aou3yk-gniezno-09042023-niedziela-zmartwychwstania-panskiego-msza-rezurekcyjna-6892939/alternates/LANDSCAPE_1280" />
    W katedrze gnieźnieńskiej - pod przewodnictwem prymasa Polski arcybiskupa Wojciecha Polaka - odbyła się msza rezurekcyjna.

## Ciało 44-latka leżało na poboczu. Policja szuka kierowcy i świadków wypadku
 - [https://tvn24.pl/pomorze/udorpie-rekowo-cialo-44-latka-lezalo-na-poboczu-policja-szuka-kierowcy-i-swiadkow-wypadku-6892805?source=rss](https://tvn24.pl/pomorze/udorpie-rekowo-cialo-44-latka-lezalo-na-poboczu-policja-szuka-kierowcy-i-swiadkow-wypadku-6892805?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 12:45:43+00:00

<img alt="Ciało 44-latka leżało na poboczu. Policja szuka kierowcy i świadków wypadku" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-m4kxup-policja-zdjecie-ilustracyjne-6890125/alternates/LANDSCAPE_1280" />
    "Osoby, które posiadają wideorejestratory, na których został zapisany moment zdarzenia oraz chwile go poprzedzające, proszone są o kontakt".

## Przepytał ponad 1400 pacjentów. Kiedy człowiek zaczyna umierać?
 - [https://tvn24.pl/go/programy,7/filmy-dokumentalne-odcinki,74501/odcinek-1138,S00E1138,750575?source=rss](https://tvn24.pl/go/programy,7/filmy-dokumentalne-odcinki,74501/odcinek-1138,S00E1138,750575?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 12:26:03+00:00

<img alt="Przepytał ponad 1400 pacjentów. Kiedy człowiek zaczyna umierać? " src="https://tvn24.pl/najnowsze/cdn-zdjecie-pf9lvr-smierc-to-tylko-sen-dokument-w-tvn24-go-6892944/alternates/LANDSCAPE_1280" />
    Christopher Kerr jest lekarzem i dyrektorem Hospicjum i Ośrodka Opieki Paliatywnej w Buffalo.

## Przetrwał wojny, "załatwił go PiS"? Gdzie ścięto ten stary dąb
 - [https://konkret24.tvn24.pl/swiat/przetrwal-wojny-zalatwil-go-pis-gdzie-scieto-ten-stary-dab-6883282?source=rss](https://konkret24.tvn24.pl/swiat/przetrwal-wojny-zalatwil-go-pis-gdzie-scieto-ten-stary-dab-6883282?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 12:20:45+00:00

<img alt="Przetrwał wojny, " src="https://tvn24.pl/najnowsze/cdn-zdjecie-xal859-przetrwal-wojny-zalatwil-go-pis-gdzie-scieto-ten-wielki-dab-6886333/alternates/LANDSCAPE_1280" />
    Zdjęcie wywołuje emocje i dyskusje w sieci.

## Pogoda na 16 dni: 20 stopni coraz bliżej
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-16-dni-coraz-blizej-do-20-stopni-prognoza-dlugoterminowa-prognoza-pogody-tomasz-wasilewskiego-6892761?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-16-dni-coraz-blizej-do-20-stopni-prognoza-dlugoterminowa-prognoza-pogody-tomasz-wasilewskiego-6892761?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 12:01:00+00:00

<img alt="Pogoda na 16 dni: 20 stopni coraz bliżej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-70ohyn-pogoda-na-16-dni-drv-6892796/alternates/LANDSCAPE_1280" />
    Sprawdź autorską prognozę Tomasza Wasilewskiego.

## Przechodziła z rodzicami przez pasy. 9-latka potrącona
 - [https://tvn24.pl/lodz/ozorkow-dziewieciolatka-potracona-na-przejsciu-dla-pieszych-na-miejscu-ladowal-smiglowiec-lpr-6892866?source=rss](https://tvn24.pl/lodz/ozorkow-dziewieciolatka-potracona-na-przejsciu-dla-pieszych-na-miejscu-ladowal-smiglowiec-lpr-6892866?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 11:45:39+00:00

<img alt="Przechodziła z rodzicami przez pasy. 9-latka potrącona" src="https://tvn24.pl/najnowsze/cdn-zdjecie-u9plry-potracenie-ozorkow-6892855/alternates/LANDSCAPE_1280" />
    Na miejscu lądował śmigłowiec Lotniczego Pogotowia Ratunkowego.

## Kredyty frankowe. Sąd Najwyższy oddalił jedną ze skarg nadzwyczajnych
 - [https://tvn24.pl/biznes/z-kraju/kredyty-we-frankach-sad-najwyzszy-oddalil-jedna-ze-skarg-nadzwyczajnych-6892827?source=rss](https://tvn24.pl/biznes/z-kraju/kredyty-we-frankach-sad-najwyzszy-oddalil-jedna-ze-skarg-nadzwyczajnych-6892827?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 11:11:26+00:00

<img alt="Kredyty frankowe. Sąd Najwyższy oddalił jedną ze skarg nadzwyczajnych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-gr4sjf-frank-szwajcarski-chf-6841703/alternates/LANDSCAPE_1280" />
    Uzasadnienie orzeczenia.

## Wielkanocne orędzie Franciszka. "Naród rosyjski obdarz światłem paschalnym"
 - [https://tvn24.pl/swiat/watykan-papiez-franciszek-wielkanocne-oredzie-modlitwa-o-pokoj-dla-narodu-ukrainskiego-i-braterstwo-na-swiecie-6892806?source=rss](https://tvn24.pl/swiat/watykan-papiez-franciszek-wielkanocne-oredzie-modlitwa-o-pokoj-dla-narodu-ukrainskiego-i-braterstwo-na-swiecie-6892806?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 11:07:24+00:00

<img alt="Wielkanocne orędzie Franciszka. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-4qbj8r-plac-sw-piotra-podczas-niedzieli-wielkanocnej-6892812/alternates/LANDSCAPE_1280" />
    Papież apelował o przezwyciężanie podziałów i braterstwo.

## Oparł się o płytę i wpadł do grobu swojej matki
 - [https://tvn24.pl/bialystok/lublin-oparl-sie-o-plyte-i-wpadl-do-grobu-swojej-matki-akcja-sluzb-na-cmentarzu-6892728?source=rss](https://tvn24.pl/bialystok/lublin-oparl-sie-o-plyte-i-wpadl-do-grobu-swojej-matki-akcja-sluzb-na-cmentarzu-6892728?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 10:38:10+00:00

<img alt="Oparł się o płytę i wpadł do grobu swojej matki" src="https://tvn24.pl/najnowsze/cdn-zdjecie-10m4ie-aby-wyciagnac-go-z-grobowca-uzyli-pasow-klinowych-6892744/alternates/LANDSCAPE_1280" />
    Akcja służb na cmentarzu w Lublinie.

## Kiełki wycofywane z obrotu
 - [https://tvn24.pl/biznes/z-kraju/kielki-z-brokulu-wycofywane-z-obrotu-ostrzezenie-gis-6892718?source=rss](https://tvn24.pl/biznes/z-kraju/kielki-z-brokulu-wycofywane-z-obrotu-ostrzezenie-gis-6892718?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 10:25:36+00:00

<img alt="Kiełki wycofywane z obrotu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kuqyi0-kielki-shutterstock_2145701571-6892753/alternates/LANDSCAPE_1280" />
    "Wykryto obecność bakterii".

## Co się dzieje w mózgu, gdy jemy słodko i tłusto?
 - [https://tvn24.pl/tvnmeteo/nauka/slodkie-i-tluste-potrawy-zmieniaja-nasz-mozg-badania-naukowe-6884690?source=rss](https://tvn24.pl/tvnmeteo/nauka/slodkie-i-tluste-potrawy-zmieniaja-nasz-mozg-badania-naukowe-6884690?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 10:11:00+00:00

<img alt="Co się dzieje w mózgu, gdy jemy słodko i tłusto?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-x8qh1e-slodycze-moga-zmieniac-nasz-mozg-6884692/alternates/LANDSCAPE_1280" />
    Ustalenia warto wziąć pod uwagę przy wielkanocnym stole.

## "Całkowite fiasko" ataków na infrastrukturę energetyczną.
 - [https://tvn24.pl/swiat/wojna-w-ukrainie-calkowite-fiasko-atakow-na-infrastrukture-energetyczna-rosja-najwyrazniej-zrezygnowala-z-tych-wysilkow-6892683?source=rss](https://tvn24.pl/swiat/wojna-w-ukrainie-calkowite-fiasko-atakow-na-infrastrukture-energetyczna-rosja-najwyrazniej-zrezygnowala-z-tych-wysilkow-6892683?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 09:44:21+00:00

<img alt=" " src="https://tvn24.pl/najnowsze/cdn-zdjecie-t6bn02-zniszczona-przez-rosyjski-pocisk-elektrownia-w-charkowie-20112022-6892722/alternates/LANDSCAPE_1280" />
    Analiza ISW.

## Samochód rozpadł się na kawałki. Nie żyje młody strażak ochotnik
 - [https://tvn24.pl/poznan/sekowo-po-zderzeniu-czolowym-auto-rozerwalo-sie-na-kawalki-nie-zyje-mlody-strazak-ochotnik-dwie-osoby-ranne-6892691?source=rss](https://tvn24.pl/poznan/sekowo-po-zderzeniu-czolowym-auto-rozerwalo-sie-na-kawalki-nie-zyje-mlody-strazak-ochotnik-dwie-osoby-ranne-6892691?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 09:40:47+00:00

<img alt="Samochód rozpadł się na kawałki. Nie żyje młody strażak ochotnik " src="https://tvn24.pl/najnowsze/cdn-zdjecie-2uswge-w-tragicznym-wypadku-zginal-26-letni-strazak-ochotnik-6892696/alternates/LANDSCAPE_1280" />
    Dwie osoby zostały ranne.

## Płoną magazyny. Policja ostrzega przed możliwym toksynami
 - [https://tvn24.pl/swiat/hamburg-niemcy-pozar-i-chmura-dymu-nad-miastem-policja-ostrzega-przed-mozliwym-toksynami-6892714?source=rss](https://tvn24.pl/swiat/hamburg-niemcy-pozar-i-chmura-dymu-nad-miastem-policja-ostrzega-przed-mozliwym-toksynami-6892714?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 09:25:48+00:00

<img alt="Płoną magazyny. Policja ostrzega przed możliwym toksynami" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8610w0-hamburg-pozar-magazynow-i-akcja-gasnicza-6892833/alternates/LANDSCAPE_1280" />
    Zaapelowano do mieszkańców o pozostanie w domach.

## "Najniższa prognoza wzrostu od 1990 roku"
 - [https://tvn24.pl/biznes/ze-swiata/globalny-wzrost-gospodarczy-nowa-prognoza-mfw-najnizsza-sredniookresowa-prognoza-wzrostu-od-1990-roku-6892698?source=rss](https://tvn24.pl/biznes/ze-swiata/globalny-wzrost-gospodarczy-nowa-prognoza-mfw-najnizsza-sredniookresowa-prognoza-wzrostu-od-1990-roku-6892698?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 09:23:15+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-nk5mxm-rekord-ciepla-w-warszawie-6576516/alternates/LANDSCAPE_1280" />
    Światowa gospodarka na hamulcu.

## Ginie jeden z najpiękniejszych gatunków w Polsce
 - [https://tvn24.pl/tvnmeteo/nauka/kraska-na-granicy-wyginiecia-kiedys-ten-barwny-ptak-w-polsce-wystepowal-czesto-6892602?source=rss](https://tvn24.pl/tvnmeteo/nauka/kraska-na-granicy-wyginiecia-kiedys-ten-barwny-ptak-w-polsce-wystepowal-czesto-6892602?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 08:26:38+00:00

<img alt="Ginie jeden z najpiękniejszych gatunków w Polsce" src="https://tvn24.pl/najnowsze/cdn-zdjecie-gpt4x5-kraska-zwyczajna-adobestock_179597026-6892612/alternates/LANDSCAPE_1280" />
    Zostało już tylko około 10 par - ostrzegają ornitolodzy.

## Usłyszeli od lekarza: "Jaśko będzie warzywem". To dało im kopa, może dlatego syn chodzi
 - [https://tvn24.pl/premium/osoby-z-niepelnosprawnosciami-zespol-angelmana-wywrocil-zycie-rodziny-z-lowicza-6889179?source=rss](https://tvn24.pl/premium/osoby-z-niepelnosprawnosciami-zespol-angelmana-wywrocil-zycie-rodziny-z-lowicza-6889179?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 07:00:35+00:00

<img alt="Usłyszeli od lekarza: " src="https://tvn24.pl/najnowsze/cdn-zdjecie-syh43v-jasiek-lazinski-ma-13-lat-6889284/alternates/LANDSCAPE_1280" />
    Drugi syn, duma i radość, ogromne. O zdrowie Jaśka, najpierw o jego wzrok, zaczęli niepokoić się w wakacje, na urlopach. Diagnoza była ciosem. - Od lekarza usłyszeliśmy, że teraz, w takiej sytuacji, dumę musimy schować do kieszeni - opowiadają Agnieszka i Zbigniew Łazińscy, rodzice niepełnosprawnego syna.

## Polska powyżej europejskiej średniej
 - [https://tvn24.pl/biznes/nieruchomosci/mieszkania-i-domy-na-wlasnosc-odsetek-ludnosci-polska-z-jednym-z-najwyzszych-wskaznikow-6892538?source=rss](https://tvn24.pl/biznes/nieruchomosci/mieszkania-i-domy-na-wlasnosc-odsetek-ludnosci-polska-z-jednym-z-najwyzszych-wskaznikow-6892538?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 05:52:11+00:00

<img alt="Polska powyżej europejskiej średniej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kwagbp-mieszkanie-blok-warszawa-nieruchomosc-5668227/alternates/LANDSCAPE_1280" />
    Właściciele mieszkań nad Wisłą. Analiza.

## Termometry wskażą ujemne wartości. Alerty
 - [https://tvn24.pl/tvnmeteo/prognoza/alerty-imgw-przymrozki-pogoda-na-poniedzialek-wielkanocny-6892530?source=rss](https://tvn24.pl/tvnmeteo/prognoza/alerty-imgw-przymrozki-pogoda-na-poniedzialek-wielkanocny-6892530?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 04:29:31+00:00

<img alt="Termometry wskażą ujemne wartości. Alerty" src="https://tvn24.pl/najnowsze/cdn-zdjecie-sygz0q-przymrozki-w-polsce-5692869/alternates/LANDSCAPE_1280" />
    IMGW ostrzega przed przymrozkami.

## Ponad 10 tysięcy sztuk uzbrojenia i sprzętu
 - [https://tvn24.pl/swiat/udokumentowane-straty-rosji-w-ukrainie-przekroczyly-10-tysiecy-sztuk-uzbrojenia-i-sprzetu-6892417?source=rss](https://tvn24.pl/swiat/udokumentowane-straty-rosji-w-ukrainie-przekroczyly-10-tysiecy-sztuk-uzbrojenia-i-sprzetu-6892417?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 04:04:45+00:00

<img alt="Ponad 10 tysięcy sztuk uzbrojenia i sprzętu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7aytnt-zniszczony-rosyjski-czolg-6592194/alternates/LANDSCAPE_1280" />
    Udokumentowane straty Rosji w Ukrainie.

## Komunikat do okrętu wojennego. Konfrontacja na morzu. Nagranie
 - [https://tvn24.pl/swiat/tajwan-chinskie-sily-zbrojne-cwicza-okrazenie-wyspy-trwaja-manewry-wojskowe-6892461?source=rss](https://tvn24.pl/swiat/tajwan-chinskie-sily-zbrojne-cwicza-okrazenie-wyspy-trwaja-manewry-wojskowe-6892461?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 03:43:13+00:00

<img alt="Komunikat do okrętu wojennego. Konfrontacja na morzu. Nagranie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7car6c-tajwan-sklej-6892903/alternates/LANDSCAPE_1280" />
    Chiny ćwiczą od piątku okrążenie Tajwanu.

## Eksplozja i budynek w gruzach
 - [https://tvn24.pl/swiat/marsylia-francja-w-centrum-miasta-zawalil-sie-budynek-mieszkalny-6892526?source=rss](https://tvn24.pl/swiat/marsylia-francja-w-centrum-miasta-zawalil-sie-budynek-mieszkalny-6892526?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 03:38:20+00:00

<img alt="Eksplozja i budynek w gruzach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-f5f0mb-marsylia-akcja-ratunkowa-po-zawaleniu-sie-kamienicy-6892583/alternates/LANDSCAPE_1280" />
    Tragedia w Marsylii.

## "Mięsne fale". Doniesienia z frontu w Bachmucie
 - [https://tvn24.pl/swiat/wojna-w-ukrainie-relacja-na-zywo-9-kwietnia-2023-6892524?source=rss](https://tvn24.pl/swiat/wojna-w-ukrainie-relacja-na-zywo-9-kwietnia-2023-6892524?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 03:14:36+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jq6qgs-bachmut-6893240/alternates/LANDSCAPE_1280" />
    W tvn24.pl relacjonujemy wydarzenia z i wokół Ukrainy.

## "Macierzyństwo jest cudowne, ale potrafi pokazać swoją brzydką stronę"
 - [https://tvn24.pl/go/programy,7/bez-polityki-odcinki,413879/odcinek-127,S00E127,1038838?source=rss](https://tvn24.pl/go/programy,7/bez-polityki-odcinki,413879/odcinek-127,S00E127,1038838?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-04-09 03:10:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1xnk0h-bez-polityki-tatiana-okupnik-6890067/alternates/LANDSCAPE_1280" />
    Rozmowa Piotra Jaconia z Tatianą Okupnik, wokalistką i autorką tekstów.

