# Source:Wydarzenia Interia - Świat, URL:https://wydarzenia.interia.pl/swiat/feed, language:pl-PL

## Wielkanocne orędzie papieża. Mówił o wojnie
 - [https://wydarzenia.interia.pl/zagranica/news-wielkanocne-oredzie-papieza-mowil-o-wojnie,nId,6707308](https://wydarzenia.interia.pl/zagranica/news-wielkanocne-oredzie-papieza-mowil-o-wojnie,nId,6707308)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-04-09 10:12:28+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wielkanocne-oredzie-papieza-mowil-o-wojnie,nId,6707308"><img align="left" alt="Wielkanocne orędzie papieża. Mówił o wojnie" src="https://i.iplsc.com/wielkanocne-oredzie-papieza-mowil-o-wojnie/000H087THTNVHSJC-C321.jpg" /></a>- Jezu, pomóż umiłowanemu ukraińskiemu narodowi w drodze do pokoju, a naród rosyjski obdarz światłem paschalnym. Pociesz rannych i tych, którzy stracili w wojnie swoich bliskich. Spraw, by jeńcy mogli zdrowi i cali powrócić do rodzin, otwórz serca całej wspólnoty międzynarodowej, by podjęła działania zmierzające do zakończenia tej wojny, jak i innych konfliktów, jak choćby w Syrii, która wciąż czeka na pokój - powiedział papież Franciszek w wielkanocnym orędziu. Pobłogosławił też wszystkich zgromadzonych.</p><br clear="all" />

## Ogromny pożar w Hamburgu. Toksyczna chmura nad miastem
 - [https://wydarzenia.interia.pl/zagranica/news-ogromny-pozar-w-hamburgu-toksyczna-chmura-nad-miastem,nId,6707331](https://wydarzenia.interia.pl/zagranica/news-ogromny-pozar-w-hamburgu-toksyczna-chmura-nad-miastem,nId,6707331)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-04-09 09:38:54+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-ogromny-pozar-w-hamburgu-toksyczna-chmura-nad-miastem,nId,6707331"><img align="left" alt="Ogromny pożar w Hamburgu. Toksyczna chmura nad miastem" src="https://i.iplsc.com/ogromny-pozar-w-hamburgu-toksyczna-chmura-nad-miastem/000H088IETYCUATA-C321.jpg" /></a>Ogromny pożar w Hamburgu. Tamtejsza policja poinformowała, że nad okolicą mogą unosić się szkodliwe dla zdrowia chemikalia oraz, że chmura czarnego dymu przesuwa się w kierunku centrum miasta. Strażacy apelują o zamykanie okien i unikanie zanieczyszczonego powietrza. </p><br clear="all" />

## Påskekrim, Semana Santa, palenie Judasza. Tak wygląda Wielkanoc na świecie
 - [https://wydarzenia.interia.pl/ciekawostki/news-paskekrim-semana-santa-palenie-judasza-tak-wyglada-wielkanoc,nId,6701760](https://wydarzenia.interia.pl/ciekawostki/news-paskekrim-semana-santa-palenie-judasza-tak-wyglada-wielkanoc,nId,6701760)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-04-09 07:21:15+00:00

<p><a href="https://wydarzenia.interia.pl/ciekawostki/news-paskekrim-semana-santa-palenie-judasza-tak-wyglada-wielkanoc,nId,6701760"><img align="left" alt="Påskekrim, Semana Santa, palenie Judasza. Tak wygląda Wielkanoc na świecie" src="https://i.iplsc.com/paskekrim-semana-santa-palenie-judasza-tak-wyglada-wielkanoc/000GZVZO4A3JK68K-C321.jpg" /></a>Mówi się, że kto podróżuje, ten widzi więcej. Ale czasem są takie sytuacje, które na pierwszy rzut oka mogą nam się wydawać dziwne. Szczególnie, kiedy odwiedzamy nowy kraj i dopiero poznajemy nową kulturę. Zrzucanie z okien glinianych garnków może być dla wielu osób szokujące... Lepiej nie przechodzić pod oknem mieszkańca pewnej greckiej wyspy w sobotę wielkanocną. </p><br clear="all" />

