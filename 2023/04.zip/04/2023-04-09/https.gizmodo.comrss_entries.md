# Source:Gizmodo, URL:https://gizmodo.com/rss, language:en-US

## Monster Energy Tried to Make Pokémon Change Its Name Because of the Word ‘Monster’
 - [https://gizmodo.com/monster-energy-drinks-pokemon-games-glowstick-battle-1850317655](https://gizmodo.com/monster-energy-drinks-pokemon-games-glowstick-battle-1850317655)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-09 22:45:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--3_BNs2BD--/c_fit,fl_progressive,q_80,w_636/d1b21bcd45c087c349edff23e0ba3972.jpg" /><p><a href="https://es.gizmodo.com/monster-energy-marca-registrada-pokemon-pocket-monsters-1850317317?asdasdadsdaddd"><em>Leer en español</em></a>.</p><p><a href="https://gizmodo.com/monster-energy-drinks-pokemon-games-glowstick-battle-1850317655">Read more...</a></p>

## Super Mario Bros. Comes Out, Breaks Box Office Milestones Right Away
 - [https://gizmodo.com/super-mario-bros-movie-illumination-box-office-1850315813](https://gizmodo.com/super-mario-bros-movie-illumination-box-office-1850315813)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-09 19:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--E3v2lA7Z--/c_fit,fl_progressive,q_80,w_636/9485cc26faad86370937f010497333a3.jpg" /><p>Illumination’s <a href="https://gizmodo.com/super-mario-movie-review-nintendo-illumination-luigi-pe-1850285728"><em>Super Mario Bros.</em></a><em> </em>movie i now in theaters, and not unlike with the games themselves, is doing really well at the box office.<br /></p><p><a href="https://gizmodo.com/super-mario-bros-movie-illumination-box-office-1850315813">Read more...</a></p>

## Star Tours Is Adding Mystery Destinations From Star Wars' Future
 - [https://gizmodo.com/star-tours-new-destinations-star-wars-disneyland-disney-1850317269](https://gizmodo.com/star-tours-new-destinations-star-wars-disneyland-disney-1850317269)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-09 19:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--_C3P6NaY--/c_fit,fl_progressive,q_80,w_636/39ea977f5a9de95ef4b8781f28da837b.jpg" /><p>Before there was <a href="https://gizmodo.com/star-wars-galaxys-edge-is-here-the-good-the-bad-and-1835129231">Star Wars Galaxy’s Edge</a>, before there was <a href="https://gizmodo.com/disney-world-star-wars-galactic-starcruiser-impressions-1848592932">Galactic Starcruiser,</a> heck, even before there were prequel movies, <a href="https://gizmodo.com/admiral-ackbar-makes-light-of-the-massacre-of-alderaan-5803936">there was Star Tours</a>. The first collaboration between Lucasfilm and Disney theme parks debuted in 1987 and in the decades since, has always <a href="https://gizmodo.com/disneys-star-tours-just-told-us-the-name-of-the-rise-of-1839295533">attempted to stay current</a>. On Sunday at Star Wars…</p><p><a href="https://gizmodo.com/star-tours-new-destinations-star-wars-disneyland-disney-1850317269">Read more...</a></p>

## Paizo Releases First Draft for Its Universal RPG License to the Public
 - [https://gizmodo.com/paizo-open-rpg-license-first-draft-1850317255](https://gizmodo.com/paizo-open-rpg-license-first-draft-1850317255)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-09 18:25:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--CShAFWN_--/c_fit,fl_progressive,q_80,w_636/175d83cca6f3241a6f9f39ae9b4c9aa7.jpg" /><p>Just as the weekend started, TTRPG company Paizo has published the <a href="https://paizo.com/community/blog/v5748dyo6si9y?First-Draft-of-the-ORC-License-Ready-for" rel="noopener noreferrer" target="_blank">first draft</a> of its Open RPG Creative License (ORC).<br /></p><p><a href="https://gizmodo.com/paizo-open-rpg-license-first-draft-1850317255">Read more...</a></p>

## All the Star Wars and Indiana Jones Toys Hasbro Revealed at Star Wars Celebration
 - [https://gizmodo.com/star-wars-celebration-hasbro-star-wars-indiana-jones-1850316998](https://gizmodo.com/star-wars-celebration-hasbro-star-wars-indiana-jones-1850316998)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-09 17:35:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--ZeilyhtI--/c_fit,fl_progressive,q_80,w_636/8d0f2c44acb8fe1278735dfee88bd220.png" /><p><em>Star Wars</em> Celebration brings <a href="https://gizmodo.com/thrawn-actor-ahsoka-star-wars-disney-plus-sith-villain-1850315377">plenty of news</a> with it from the galaxy far, far away, but it also brings future opportunities to <a href="https://gizmodo.com/star-wars-celebration-may-the-4th-merch-baby-yoda-1850310430">drain your wallet</a>. Hasbro understood this more than anyone else at their panel at the London convention, and they brought out big announcements from <em>Star Wars</em> and <a href="https://gizmodo.com/indiana-jones-5-chase-scene-dial-of-destiny-harrison-fo-1850311616"><em>Indiana Jones</em></a> to whet fans…</p><p><a href="https://gizmodo.com/star-wars-celebration-hasbro-star-wars-indiana-jones-1850316998">Read more...</a></p>

## Lawmakers Ask DOJ to Investigate "Hollowed Out" Warner Bros. Discovery
 - [https://gizmodo.com/warner-bros-discovery-doj-investigate-1850317192](https://gizmodo.com/warner-bros-discovery-doj-investigate-1850317192)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-09 17:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--tFG2Fy-z--/c_fit,fl_progressive,q_80,w_636/1c91c97cc219e78e5c0bba99dd757938.jpg" /><p>Last year, Warner Bros. was acquired by the Discovery Channel, and the resulting merger has been more than a little chaotic. Things got off to a rough start with the sudden <a href="https://gizmodo.com/brendan-fraser-on-batgirl-cancellation-wb-discovery-1849649065">cancellation of </a><a href="https://gizmodo.com/brendan-fraser-on-batgirl-cancellation-wb-discovery-1849649065"><em>Batgirl</em></a><em>, </em>and has since spiraled into multiple shows getting canceled (some of them not even <a href="https://gizmodo.com/snowpiercer-tnt-season-4-wont-air-1849990298">getting to air</a>) and series getting <a href="https://gizmodo.com/hbo-max-discovery-roku-westworld-1850303038">…</a></p><p><a href="https://gizmodo.com/warner-bros-discovery-doj-investigate-1850317192">Read more...</a></p>

## Ewan McGregor and Hayden Christensen Get Emotional Over Their Obi-Wan Kenobi Showdown
 - [https://gizmodo.com/obi-wan-kenobi-darth-vader-ewan-mcgregor-christensen-1850317103](https://gizmodo.com/obi-wan-kenobi-darth-vader-ewan-mcgregor-christensen-1850317103)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-09 16:20:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--Sq3yWkN4--/c_fit,fl_progressive,q_80,w_636/2e6704036951184d60de37c932fea109.jpg" /><p>Though <a href="https://gizmodo.com/obi-wan-kenobi-recap-star-wars-princess-leia-grand-inqu-1848985099">the look back at</a><em> Obi-Wan Kenob</em>i panel at Star Wars Celebration didn’t have any news <a href="https://gizmodo.com/obi-wan-kenobi-not-about-conflict-darth-vader-disney-st-1849105514">about a second season</a> of the show, it did give fans in attendance a <a href="https://gizmodo.com/obi-wan-kenobi-qui-gon-jinn-star-wars-lucasfilm-disney-1849099144">new found appreciation</a> for what the show meant to the cast and crew who worked on it.</p><p><a href="https://gizmodo.com/obi-wan-kenobi-darth-vader-ewan-mcgregor-christensen-1850317103">Read more...</a></p>

## Andor Never Had An Opposition to Using Mandalorian’s VFX Tech
 - [https://gizmodo.com/star-wars-celebration-andor-vfx-panel-stagecraft-volume-1850317113](https://gizmodo.com/star-wars-celebration-andor-vfx-panel-stagecraft-volume-1850317113)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-09 15:45:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--Mtgi9E86--/c_fit,fl_progressive,q_80,w_636/08fb6b459bd7ae591d03ef1c33cdc65a.jpg" /><p><a href="https://gizmodo.com/andor-season-1-best-moments-star-wars-disney-plus-1849818726"><em>Andor</em> was lauded</a> for its grounded approach to <em>Star Wars</em>, leaning on a physicality to its production <a href="https://gizmodo.com/star-wars-andor-interviews-writer-producer-disney-1849763876">that rooted the audience</a> in its grittier take on the galaxy far, far away—which also meant a different approach to VFX that contrasted with the recent rise of <a href="https://gizmodo.com/the-mandalorian-season-2-was-made-with-the-most-powerfu-1846599244">Stagecraft</a> and “The Volume,” the screen-based set <a href="https://gizmodo.com/the-mandalorian-had-its-entire-season-pre-visualized-be-1843924384">that…</a></p><p><a href="https://gizmodo.com/star-wars-celebration-andor-vfx-panel-stagecraft-volume-1850317113">Read more...</a></p>

## Kasparov vs. Deep Blue: the Chess Match That Changed Our Minds About AI
 - [https://gizmodo.com/kasparov-ibm-deep-blue-ai-chess-match-changed-minds-1850270696](https://gizmodo.com/kasparov-ibm-deep-blue-ai-chess-match-changed-minds-1850270696)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-09 15:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--O2VAIgmE--/c_fit,fl_progressive,q_80,w_636/f927f91306fa69f0ad0e31d0658e187f.jpg" /><p>In May of 1997, Garry Kasparov sat down at a chess board in a Manhattan skyscraper. Kasparov, considered the best chess player of all time, wasn’t challenging another grandmaster. He was playing with an AI called Deep Blue. Deep Blue was one of the world’s most powerful supercomputers, built by IBM with a specific…</p><p><a href="https://gizmodo.com/kasparov-ibm-deep-blue-ai-chess-match-changed-minds-1850270696">Read more...</a></p>

## Open Channel: What'd You Think of the Super Mario Bros. Movie?
 - [https://gizmodo.com/open-channel-super-mario-bros-movie-1850316539](https://gizmodo.com/open-channel-super-mario-bros-movie-1850316539)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-09 15:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--X59fwOjE--/c_fit,fl_progressive,q_80,w_636/a0ccdb391d964106df643d1344c6b2d3.jpg" /><p>Just a few months in, and 2023 is already shaping up to be a <a href="https://gizmodo.com/dungeons-dragons-honor-among-thieves-what-we-loved-1850298152">fairly impressive year</a> for movies. After a little bit of a delay, Illumination and Nintendo released their CG <a href="https://gizmodo.com/super-mario-movie-review-nintendo-illumination-luigi-pe-1850285728"><em>Super Mario Bros. </em>movie</a> earlier in the week.<br /></p><p><a href="https://gizmodo.com/open-channel-super-mario-bros-movie-1850316539">Read more...</a></p>

## Elon Musk Decides NPR Is Not State Propaganda After All
 - [https://gizmodo.com/elon-musk-npr-new-twitter-label-government-funded-media-1850317011](https://gizmodo.com/elon-musk-npr-new-twitter-label-government-funded-media-1850317011)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-09 14:05:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--ILP-RvCq--/c_fit,fl_progressive,q_80,w_636/06840b2d7d81ecb696666cef7fc701ce.png" /><p>Twitter CEO Elon Musk has decided that <a href="https://gizmodo.com/elon-musk-backtracks-npr-state-affiliated-media-label-1850311413">NPR is not the same as media outlets like China’s Xinhua News</a>, which is a well-known state propaganda machine, after all, even though he classified them both as “state-affiliated media” on the social media network this past Wednesday. After receiving pushback from NPR, Musk…</p><p><a href="https://gizmodo.com/elon-musk-npr-new-twitter-label-government-funded-media-1850317011">Read more...</a></p>

## Don't Play Poker With ChatGPT
 - [https://gizmodo.com/chatgpt-ai-poker-online-betting-do-not-play-with-ai-1850313363](https://gizmodo.com/chatgpt-ai-poker-online-betting-do-not-play-with-ai-1850313363)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-09 13:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--bLcpm0pe--/c_fit,fl_progressive,q_80,w_636/92d531c5beb6d3e08e49089ee820e547.jpg" /><p>The past few years have seen an explosion of progress in large language model artificial intelligence systems that can do things like <a href="https://computationalcreativity.net/iccc21/wp-content/uploads/2021/09/ICCC_2021_paper_31.pdf" rel="noopener noreferrer" target="_blank">write poetry</a>, <a href="https://openai.com/blog/chatgpt" rel="noopener noreferrer" target="_blank">conduct humanlike conversations</a> and <a href="https://www.ama-assn.org/practice-management/digital/chatgpt-passed-usmle-what-does-it-mean-med-ed" rel="noopener noreferrer" target="_blank">pass medical school exams</a>. This progress has yielded models like <a href="https://gizmodo.com/chat-gpt-openai-ai-finance-ai-everything-we-know-1850018307">ChatGPT</a> that could have major social and economic ramifications…</p><p><a href="https://gizmodo.com/chatgpt-ai-poker-online-betting-do-not-play-with-ai-1850313363">Read more...</a></p>

## Ian McDiarmid Has the Best Perspective On Palpatine's Star Wars Journey
 - [https://gizmodo.com/star-wars-emperor-palpatine-ian-mcdiarmid-darth-sidious-1850317032](https://gizmodo.com/star-wars-emperor-palpatine-ian-mcdiarmid-darth-sidious-1850317032)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-09 12:45:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--YxVX3mSA--/c_fit,fl_progressive,q_80,w_636/db8ff7d73228d545b7aff74c3cba4447.jpg" /><p>The dead speak! Three times, in fact. At <a href="https://gizmodo.com/star-wars-celebration-2023-news-trailers-expectations-1850285930">Star Wars Celebration 2023</a>, three deceased Star Wars villains came back from the dead (and on Easter no less) to chat about their experiences playing baddies in a galaxy far, far, away. There was Gwendoline Christie who played Captain Phasma, Andy Serkis who played Supreme…</p><p><a href="https://gizmodo.com/star-wars-emperor-palpatine-ian-mcdiarmid-darth-sidious-1850317032">Read more...</a></p>

## New Jedi Survivor Trailer Puts Cal in the Fight of His Life
 - [https://gizmodo.com/star-wars-jedi-survivor-respawn-trailer-1850316495](https://gizmodo.com/star-wars-jedi-survivor-respawn-trailer-1850316495)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-09 11:22:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--KY7yQqoU--/c_fit,fl_progressive,q_80,w_636/ae66a2cc7872b6a4a73b0d9e70977522.jpg" /><p>This weekend is Star Wars Celebration 2023, and even <a href="https://gizmodo.com/star-wars-jedi-survivor-trailer-video-game-cal-kestis-1850243026"><em>Star Wars Jedi: Survivor</em></a><em> </em>is getting a little bit of love. Respawn’s sequel to its <a href="https://gizmodo.com/star-wars-jedi-fallen-order-sequel-respawn-1848975790">2019 breakout</a> releases at the end of the month, and while it doesn’t have a panel to itself, the game got a new trailer during the annual event.<br /></p><p><a href="https://gizmodo.com/star-wars-jedi-survivor-respawn-trailer-1850316495">Read more...</a></p>

## Without a Body, ChatGPT Will Never Understand What It's Saying
 - [https://gizmodo.com/chatgpt-ai-openai-no-body-no-understanding-1850313233](https://gizmodo.com/chatgpt-ai-openai-no-body-no-understanding-1850313233)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-09 11:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--xDvJDpRj--/c_fit,fl_progressive,q_80,w_636/2785788177a688a1d67426a89a33ad39.jpg" /><p>When we asked <a href="https://openai.com/blog/gpt-3-apps/" rel="noopener noreferrer" target="_blank">GPT-3</a>, an extremely powerful and popular artificial intelligence language system, whether you’d be more likely to use a paper map or a stone to fan life into coals for a barbecue, it preferred the stone.</p><p><a href="https://gizmodo.com/chatgpt-ai-openai-no-body-no-understanding-1850313233">Read more...</a></p>

