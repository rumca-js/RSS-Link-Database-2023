# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## USA: Nauczyciele myśleli, że się bawi. Pięciolatek zmarł
 - [https://www.polsatnews.pl/wiadomosc/2023-04-09/usa-nauczyciele-mysleli-ze-sie-bawi-pieciolatek-zmarl/](https://www.polsatnews.pl/wiadomosc/2023-04-09/usa-nauczyciele-mysleli-ze-sie-bawi-pieciolatek-zmarl/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-04-09 19:29:00+00:00

Pięciolatek z Connecticut upadł na ziemię podczas przerwy w szkole. Nauczyciele, którzy myśleli, że chłopiec bawi się i udaje martwego, nie udzielili mu pomocy. Jak się okazało, chłopiec nie żył. Rodzina w sprawie śmierci złożyła pozew sądowy, oskarżając miasto i szkołę o zaniedbanie.

## RPA: Sfingował swoją śmierć i uciekł z więzienia. Rok był na wolności
 - [https://www.polsatnews.pl/wiadomosc/2023-04-09/rpa-sfingowal-swoja-smierc-i-uciekl-z-wiezienia-rok-byl-na-wolnosci/](https://www.polsatnews.pl/wiadomosc/2023-04-09/rpa-sfingowal-swoja-smierc-i-uciekl-z-wiezienia-rok-byl-na-wolnosci/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-04-09 18:37:00+00:00

Gwałciciel i morderca, który sfingował własną śmierć i uciekł z południowoafrykańskiego więzienia został zatrzymany w Tanzanii - podał portal BBC. Thabo Bester, znany jako Facebookowy gwałciciel, na wolności przebywał rok.

## Francja: Tragedia w Alpach. Lawina porwała turystów
 - [https://www.polsatnews.pl/wiadomosc/2023-04-09/francja-tragedia-w-alpach-lawina-porwala-turystow/](https://www.polsatnews.pl/wiadomosc/2023-04-09/francja-tragedia-w-alpach-lawina-porwala-turystow/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-04-09 18:07:00+00:00

Cztery osoby zginęły, a dziewięć innych zostało rannych po zejściu lawiny we francuskich Alpach. Tożsamość ofiar wciąż jest potwierdzana - ze wstępnych ustaleń wynika, że grupa uprawiała tzw. narciarstwo śladowe. Do tragedii odniósł się prezydent Francji Emmanuel Macron.

## USA: Nauczyciel kazał pisać uczniom własne nekrologi. Został zwolniony po kilku godzinach
 - [https://www.polsatnews.pl/wiadomosc/2023-04-09/usa-nauczyciel-kazal-pisac-uczniom-wlasne-nekrologi-zostal-zwolniony-po-kilku-godzinach/](https://www.polsatnews.pl/wiadomosc/2023-04-09/usa-nauczyciel-kazal-pisac-uczniom-wlasne-nekrologi-zostal-zwolniony-po-kilku-godzinach/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-04-09 15:36:00+00:00

Dla uczniów jednej ze szkół średnich w Orlando zorganizowano ćwiczenia na wypadek strzelaniny. Sytuację postanowił wykorzystać nauczyciel psychologii Jeffrey Keene, który polecił nastolatkom, by ci napisali swoje własne nekrologii. Dyrekcja zareagowała natychmiast i zwolniła mężczyznę kilka godzin później. Keene rozmowie z mediami twierdzi, że nie zrobił nic złego.

## Ukraina. Wołodymyr Zełenski dziękuje Polakom. Pokazał nagranie: Krok ku zwycięstwu
 - [https://www.polsatnews.pl/wiadomosc/2023-04-09/zelenski-dziekuje-pokazal-nagranie-z-polski-krok-ku-zwyciestwu/](https://www.polsatnews.pl/wiadomosc/2023-04-09/zelenski-dziekuje-pokazal-nagranie-z-polski-krok-ku-zwyciestwu/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-04-09 15:25:00+00:00

Moja wizyta i negocjacje w Warszawie stały się jeszcze jednym krokiem ku zwycięstwu - napisał na Telegramie Wołodymyr Zełenski. Prezydent Ukrainy opublikował nagranie ze swojej wizyty w Polsce. Dziękuję za uzgodnione decyzje, za silny pakiet obronny. Dziękuję za życia, które ratujemy dzięki naszej solidarności - podkreślił.

## Rosja: Pogrzeb Tatarskiego w Moskwie. Ochrona, "tajemnicza kobieta" i Jewgienij Prigożyn
 - [https://www.polsatnews.pl/wiadomosc/2023-04-09/rosja-pogrzeb-tatarskiego-w-moskwie-ochrona-tajemnicza-kobieta-i-jewgienij-prigozyn/](https://www.polsatnews.pl/wiadomosc/2023-04-09/rosja-pogrzeb-tatarskiego-w-moskwie-ochrona-tajemnicza-kobieta-i-jewgienij-prigozyn/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-04-09 15:02:00+00:00

Tajemnicza kobieta w otoczeniu uzbrojonych ochroniarzy pojawiła się na pogrzebie rosyjskiego blogera wojennego Władlena Tatarskiego - donoszą rosyjskie media. Podczas ceremonii pożegnania podjęto niezbędne środki ostrożności, by zminimalizować ryzyko ataku terrorystycznego - podał jeden z portali. Zmarłego przyszedł pożegnać również szef Grupy Wagnera Jewgienij Prigożyn.

## USA: Uczeń uderzył nauczyciela, bo skonfiskował mu telefon. "Widzimy zbyt wiele takich sytuacji"
 - [https://www.polsatnews.pl/wiadomosc/2023-04-09/usa-uczen-uderzyl-nauczyciela-bo-skonfiskowal-mu-telefon-widzimy-zbyt-wiele-takich-sytuacji/](https://www.polsatnews.pl/wiadomosc/2023-04-09/usa-uczen-uderzyl-nauczyciela-bo-skonfiskowal-mu-telefon-widzimy-zbyt-wiele-takich-sytuacji/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-04-09 11:40:00+00:00

Nastolatek z Houston uderzył nauczyciela w twarz po tym, jak skonfiskowano mu telefon komórkowy. W mediach społecznościowych zamieszczono nagranie ze zdarzenia.

## Francja: Katastrofa budowlana w Marsylii. Trudna akcja
 - [https://www.polsatnews.pl/wiadomosc/2023-04-09/francja-katastrofa-budowlana-w-marsylii-trudna-akcja/](https://www.polsatnews.pl/wiadomosc/2023-04-09/francja-katastrofa-budowlana-w-marsylii-trudna-akcja/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-04-09 11:03:00+00:00

Czteropiętrowy budynek mieszkalny zawalił się w nocy z soboty na niedzielę w centrum Marsylii. Rozpoczęcie akcji służb ratunkowych uniemożliwił pożar - poinformował burmistrz Benoit Payan. Częściowo zawaliły się także sąsiednie budynki. Na miejsce katastrofy przybył szef MSW Francji Gerald Darmanin, który przekazał, że pod gruzami jest od czterech do 10 osób.

## Urbi et Orbi. Papież modlił się o pokój dla Ukrainy
 - [https://www.polsatnews.pl/wiadomosc/2023-04-09/urbi-et-orbi-papiez-modlil-sie-o-pokoj-dla-ukrainy/](https://www.polsatnews.pl/wiadomosc/2023-04-09/urbi-et-orbi-papiez-modlil-sie-o-pokoj-dla-ukrainy/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-04-09 11:03:00+00:00

W Wielkanoc Franciszek udzielił błogosławieństwa Urbi et Orbi. Wcześniej wygłosił orędzie, w którym wzywał do zakończenia wojny w Ukrainie. - Pomóż umiłowanemu narodowi ukraińskiemu na drodze do pokoju, a naród rosyjski obdarz światłem paschalnym - modlił się papież.

## Hamburg: Pożar magazynu. Chmura toksycznego dymu przemieszcza się w stronę centrum miasta
 - [https://www.polsatnews.pl/wiadomosc/2023-04-09/hamburg-pozar-magazynu-chmura-toksycznego-dymu-przemieszcza-sie-w-strone-centrum-miasta/](https://www.polsatnews.pl/wiadomosc/2023-04-09/hamburg-pozar-magazynu-chmura-toksycznego-dymu-przemieszcza-sie-w-strone-centrum-miasta/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-04-09 09:46:00+00:00

Straż pożarna w Hamburgu ostrzega mieszkańców przed toksycznym dymem po dużym pożarze w dzielnicy Rothenburgsort.

## Święta w czasie wojny. "Najważniejsze, że ktoś o ludziach z Ukrainy pamięta"
 - [https://www.polsatnews.pl/wiadomosc/2023-04-09/swieta-w-czasie-wojny-najwazniejsze-ze-ktos-o-ludziach-z-ukrainy-pamieta/](https://www.polsatnews.pl/wiadomosc/2023-04-09/swieta-w-czasie-wojny-najwazniejsze-ze-ktos-o-ludziach-z-ukrainy-pamieta/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-04-09 09:28:00+00:00

- Staramy się w sposób bezpieczny przeżywać te święta. To już trzecie święta w cieniu dramatu tej wojny - mówi przebywający w Charkowie ks. Wojciech Stasiewicz. - W tej pomocy humanitarnej najważniejsze jest to, że ktoś o tych ludziach pamięta - dodaje. - Sytuacja jest naprawdę trudna. Pomoc z Polski ciągle płynie i ona jest bardzo potrzebna na miejscu - podkreśla z kolei ks. Leszek Kryża.

## Włochy: Pies rozszarpał opiekującą się nim kobietę
 - [https://www.polsatnews.pl/wiadomosc/2023-04-09/wlochy-pies-rozszarpal-kobiete/](https://www.polsatnews.pl/wiadomosc/2023-04-09/wlochy-pies-rozszarpal-kobiete/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-04-09 07:39:00+00:00

We Włoszech kobieta została rozszarpana i śmiertelnie okaleczona przez psa swojego brata. Kobieta próbowała nakarmić zwierzę.

## Izrael: Atak rakietowy z terytorium Syrii. Jest odpowiedź izraelskiego lotnictwa
 - [https://www.polsatnews.pl/wiadomosc/2023-04-09/izrael-atak-rakietowy-z-terytorium-syrii-jest-odpowiedz/](https://www.polsatnews.pl/wiadomosc/2023-04-09/izrael-atak-rakietowy-z-terytorium-syrii-jest-odpowiedz/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-04-09 05:29:00+00:00

Izraelski rzecznik wojskowy poinformował w nocy z soboty na niedzielę, że z Syrii wystrzelono rakiety w kierunku Izraela. W odpowiedzi izraelskie lotnictwo zaatakowało w niedzielę cele wojskowe w Syrii.

