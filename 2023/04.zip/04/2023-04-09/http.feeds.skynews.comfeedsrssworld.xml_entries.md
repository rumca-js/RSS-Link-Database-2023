# Source:Sky News, URL:http://feeds.skynews.com/feeds/rss/world.xml, language:en-US

## 'Imminent danger of death' for about 400 people on boat between Greece and Malta
 - [https://news.sky.com/story/boat-between-greece-and-malta-carrying-about-400-people-in-distress-is-taking-on-water-12853953](https://news.sky.com/story/boat-between-greece-and-malta-carrying-about-400-people-in-distress-is-taking-on-water-12853953)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-04-09 19:20:00+00:00

A boat carrying about 400 people "in distress" has been spotted adrift between Greece and Malta and is taking on water, support services have said.

## Eight people missing after explosion and collapse of two buildings in Marseille
 - [https://news.sky.com/story/marseille-explosion-eight-people-missing-after-two-buildings-collapse-12853914](https://news.sky.com/story/marseille-explosion-eight-people-missing-after-two-buildings-collapse-12853914)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-04-09 18:23:00+00:00

Eight people are feared to be trapped under the rubble of two buildings that collapsed following an explosion in the south of France.

## British woman in critical condition after fall from sixth-floor hotel balcony in Benidorm
 - [https://news.sky.com/story/benidorm-british-woman-in-critical-condition-after-falling-from-sixth-floor-hotel-balcony-12853695](https://news.sky.com/story/benidorm-british-woman-in-critical-condition-after-falling-from-sixth-floor-hotel-balcony-12853695)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-04-09 15:09:00+00:00

A British woman is in a critical condition in hospital after falling from a sixth-floor hotel balcony in Benidorm.

## 'A shell exploded and shrapnel hit my face': An injured Ukrainian's journey from the war to Dublin
 - [https://news.sky.com/story/how-an-injured-ukrainian-could-get-back-the-face-he-had-before-thanks-to-eu-organised-care-in-dublin-12853654](https://news.sky.com/story/how-an-injured-ukrainian-could-get-back-the-face-he-had-before-thanks-to-eu-organised-care-in-dublin-12853654)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-04-09 14:26:00+00:00

After one year of fighting, no one holds any illusions about the war in Ukraine.

## Injured Tiger Woods withdraws from The Masters after 'struggling to walk'
 - [https://news.sky.com/story/injured-tiger-woods-withdraws-from-the-masters-at-augusta-national-after-struggling-to-walk-12853619](https://news.sky.com/story/injured-tiger-woods-withdraws-from-the-masters-at-augusta-national-after-struggling-to-walk-12853619)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-04-09 13:58:00+00:00

Tiger Woods has withdrawn from The Masters due to injury.

## Father of killed British-Israeli sisters asks 'how will I explain to their mother what has happened?'
 - [https://news.sky.com/story/london-rabbi-absolutely-devastated-after-british-israeli-sisters-killed-in-west-bank-shooting-12853501](https://news.sky.com/story/london-rabbi-absolutely-devastated-after-british-israeli-sisters-killed-in-west-bank-shooting-12853501)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-04-09 12:04:00+00:00

The father of two&#160;British-Israeli sisters shot dead in the occupied West Bank has broken down at their funeral as he paid tribute to his "beautiful angels" while their grief-stricken siblings sobbed as they clutched their bodies.

## 'Hazard' warning in Hamburg as cloud with possible 'chemical components' drifts towards city centre
 - [https://news.sky.com/story/extreme-danger-warning-in-hamburg-as-cloud-with-possible-chemical-components-drifts-towards-city-centre-12853423](https://news.sky.com/story/extreme-danger-warning-in-hamburg-as-cloud-with-possible-chemical-components-drifts-towards-city-centre-12853423)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-04-09 09:44:00+00:00

Hamburg's fire brigade has issued a "hazard" warning as a cloud possibly containing "chemical components" drifts towards the city centre.

## China and Taiwan ships in stand-off near sensitive buffer zone
 - [https://news.sky.com/story/china-and-taiwan-ships-stand-off-near-sensitive-buffer-zone-12853403](https://news.sky.com/story/china-and-taiwan-ships-stand-off-near-sensitive-buffer-zone-12853403)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-04-09 09:07:00+00:00

About 20 military ships - half from China and half from Taiwan - are involved in a stand-off near the Taiwan Strait's sensitive median line, according to Reuters.

## Saudi delegation arrives in Yemen to negotiate permanent ceasefire with Houthi rebels
 - [https://news.sky.com/story/saudi-omani-delegation-arrives-in-yemen-to-negotiate-permanent-ceasefire-12853336](https://news.sky.com/story/saudi-omani-delegation-arrives-in-yemen-to-negotiate-permanent-ceasefire-12853336)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-04-09 07:30:00+00:00

Saudi officials are in Yemen's capital for peace talks it is hoped could end the country's eight year conflict.

## At least 44 killed in 'despicable and barbaric' attacks in Burkina Faso
 - [https://news.sky.com/story/burkina-faso-at-least-44-killed-in-despicable-and-barbaric-attacks-12853304](https://news.sky.com/story/burkina-faso-at-least-44-killed-in-despicable-and-barbaric-attacks-12853304)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-04-09 05:46:00+00:00

At least 44 people have been killed by Islamic extremists in attacks in northern Burkina Faso, the government has said.

## Israel retaliates after six missiles fired from Syria towards Golan Heights
 - [https://news.sky.com/story/israel-retaliates-after-six-missiles-fired-from-syria-towards-golan-heights-12853298](https://news.sky.com/story/israel-retaliates-after-six-missiles-fired-from-syria-towards-golan-heights-12853298)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-04-09 03:47:00+00:00

Six rockets have been fired from Syria towards Israel overnight, according to the Israeli military.

## Last surviving Nuremberg trials prosecutor dies aged 103
 - [https://news.sky.com/story/ben-ferencz-last-surviving-nuremberg-trials-prosecutor-dies-aged-103-12853289](https://news.sky.com/story/ben-ferencz-last-surviving-nuremberg-trials-prosecutor-dies-aged-103-12853289)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-04-09 00:40:00+00:00

Ben Ferencz, the last surviving prosecutor from the Nuremberg trials in Germany, has died at the age of 103.

