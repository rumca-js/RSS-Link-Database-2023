# Source:Nerdstalgic, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXjmz8dFzRJZrZY8eFiXNUQ, language:en-US

## this ending almost ruined titanic #shorts
 - [https://www.youtube.com/watch?v=eb_LBPenWd4](https://www.youtube.com/watch?v=eb_LBPenWd4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXjmz8dFzRJZrZY8eFiXNUQ
 - date published: 2023-04-09 15:00:25+00:00

Check Out the Full Video Here: https://youtu.be/bzfP1ZsYnWQ

Subscribe to Nerdstalgic! https://www.youtube.com/@UCXjmz8dFzRJZrZY8eFiXNUQ 

#titanic #titanicsinking #titanicmovie #jamescameron #leonardodicaprio #katewinslet #movie #nerdstalgic

