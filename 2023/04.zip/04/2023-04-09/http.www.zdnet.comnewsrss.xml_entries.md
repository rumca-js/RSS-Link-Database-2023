# Source:ZDNET, URL:http://www.zdnet.com/news/rss.xml, language:en-US

## How to find your followers and friends on Mastodon
 - [https://www.zdnet.com/article/how-to-find-your-followers-and-friends-on-mastodon/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-find-your-followers-and-friends-on-mastodon/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-04-09 13:00:23+00:00

People leaving Twitter for Mastodon may find it harder to find friends and followers there. Here's what you need to know to simplify the process.

## I bought this plastic-welding tool that TikTok suggested. Did the algorithm get it right?
 - [https://www.zdnet.com/home-and-office/i-bought-this-plastic-welding-tool-that-tiktok-suggested-did-the-algorithm-get-it-right/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/i-bought-this-plastic-welding-tool-that-tiktok-suggested-did-the-algorithm-get-it-right/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-04-09 12:30:00+00:00

Social media has been bombarding me with videos of welders that promise to fix broken plastic, so I bit. Here's what I learned after doing so.

## Photoshop free trial: How to get it and what to know
 - [https://www.zdnet.com/article/how-to-get-photoshop-for-free/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-get-photoshop-for-free/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-04-09 12:00:00+00:00

Adobe Photoshop is the go-to photo-editing program for many, but membership can be expensive. Here's the one (and only) way to use the service for free.

## Siphon-brewing coffee looks like alchemy, but it makes the best cup of joe
 - [https://www.zdnet.com/home-and-office/kitchen-household/siphon-brewing-coffee-looks-like-alchemy-but-it-makes-the-best-cup-of-joe/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/kitchen-household/siphon-brewing-coffee-looks-like-alchemy-but-it-makes-the-best-cup-of-joe/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-04-09 11:30:00+00:00

The Tiger Siphonysta makes siphon-brewing easy, and my coffee-loving wife couldn't be happier with it.

