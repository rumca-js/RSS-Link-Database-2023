# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Macron: Europa musi się uniezależnić od USA. Nie możemy dać sią wciągać w konflikt o Tajwan
 - [https://www.bankier.pl/wiadomosc/Xi-przekrecil-Macrona-Prezydent-Francji-o-Europie-USA-i-Tajwanie-8520347.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Xi-przekrecil-Macrona-Prezydent-Francji-o-Europie-USA-i-Tajwanie-8520347.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-09 17:49:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/d/517103d9bc0332-948-568-0-18-2509-1505.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prezydent Francji Emmanuel Macron w drodze powrotnej z wizyty w Chinach, powiedział, że Europa musi się oprzeć presji, by stać się "naśladowcą Ameryki". Ostrzegł też, że wielkim ryzykiem dla Europy jest "uwikłanie się w kryzysy, które nie są nasze" - chodzi oczywiście o napięcia pomiędzy Państwem Środka a USA w sprawie statusu Tajwanu.</p>

## Rzym bierze się na hulajnogi elektryczne i drastycznie ograniczy ich liczbę
 - [https://www.bankier.pl/wiadomosc/Rzym-bierze-sie-na-hulajnogi-elektryczne-i-drastycznie-ograniczy-ich-liczbe-8517941.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rzym-bierze-sie-na-hulajnogi-elektryczne-i-drastycznie-ograniczy-ich-liczbe-8517941.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-09 14:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/6/221bc8fc5ee44f-948-567-0-0-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W Rzymie będzie znacznie mniej hulajnóg elektrycznych i więcej reguł- ogłosił burmistrz Roberto Gualtieri. Jak wyjaśnił, władze Wiecznego Miasta wybrały inną drogę niż w Paryżu, gdzie mieszkańcy zdecydowali w referendum, że nie chcą wynajmu tych pojazdów.</p>

## Partie dogadały się i Estonia będzie mieć nowy rząd. Ceną są wyższe podatki
 - [https://www.bankier.pl/wiadomosc/Partie-dogadaly-sie-i-Estonia-bedzie-miec-nowy-rzad-Cena-sa-wyzsze-podatki-8520323.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Partie-dogadaly-sie-i-Estonia-bedzie-miec-nowy-rzad-Cena-sa-wyzsze-podatki-8520323.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-09 13:11:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/2/f2eb7650d107f0-948-568-0-337-3852-2311.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Negocjujące nowy rząd Estonii ugrupowania, Estońska Partia Reform, Eesti 200 i Partia Socjaldemokratyczna, zawarły umowę koalicyjną, w ramach której przewidziane jest m.in. podniesienie podatków VAT i dochodowego oraz pogłębienie współpracy regionalnej.</p>

## Do 172 razy sztuka - hiszpański rekordzista zatrzymań. Przestępca ma na koncie kradzieże milionów euro
 - [https://www.bankier.pl/wiadomosc/Do-172-razy-sztuka-hiszpanski-rekordzista-zatrzyman-Przestepca-ma-na-koncie-kradzieze-milionow-euro-8517066.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Do-172-razy-sztuka-hiszpanski-rekordzista-zatrzyman-Przestepca-ma-na-koncie-kradzieze-milionow-euro-8517066.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-09 13:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/0/507f296fdbfd57-948-568-0-340-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Hiszpańska policja rozbiła jedną z najgroźniejszych grup przestępczych okradających bankomaty oraz oddziały bankowe. Jej przywódcą był rekordzista pod względem zatrzymań – Jose Lopez Sanchez. Jak twierdzą służby, mężczyzna “przez całe życie utrzymywał się z kradzieży” i został zatrzymany po raz 172.</p>

## Coraz więcej Polaków pali. Eksperci apelują o wyższy podatek od wyrobów tytoniowych i zakaz ich reklamy
 - [https://www.bankier.pl/wiadomosc/Coraz-wiecej-Polakow-pali-Eksperci-apeluja-o-wyzszy-podatek-od-wyrobow-tytoniowych-i-zakaz-ich-reklamy-8517837.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Coraz-wiecej-Polakow-pali-Eksperci-apeluja-o-wyzszy-podatek-od-wyrobow-tytoniowych-i-zakaz-ich-reklamy-8517837.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-09 11:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/3/0ec358137e189d-948-568-0-253-3750-2249.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Blisko 29 proc. Polaków pali papierosy codziennie. Wynik ten ma tendencję zwyżkową względem lat poprzednich, dlatego eksperci z Polskiej Akademii Nauk apelują m.in. o zwiększenie podatku od wyrobów tytoniowych oraz eliminację ich reklamy i promocji.</p>

## Pokolenie Z wymusi liczne zmiany, też w branży turystycznej. Sztuczna inteligencja ułatwiłaby planowanie podróży
 - [https://www.bankier.pl/wiadomosc/Pokolenie-Z-wymusi-liczne-zmiany-tez-w-branzy-turystycznej-Sztuczna-inteligencja-ulatwilaby-planowanie-podrozy-8517962.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Pokolenie-Z-wymusi-liczne-zmiany-tez-w-branzy-turystycznej-Sztuczna-inteligencja-ulatwilaby-planowanie-podrozy-8517962.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-09 11:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/1/30eadf79a5ba4a-948-568-0-800-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Turystyka wciąż jest branżą o niskim poziomie cyfryzacji w porównaniu z innymi sektorami takimi jak telekomunikacja, finanse, bankowość czy e-commerce. Przyczyną takiego stanu rzeczy w dużej mierze może...</p>

## Polacy chętnie spędzają Wielkanoc poza domem. Wzrost o 50 proc. rdr
 - [https://www.bankier.pl/wiadomosc/Polacy-chetnie-spedzaja-Wielkanoc-poza-domem-Wzrost-o-50-proc-rdr-8520299.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polacy-chetnie-spedzaja-Wielkanoc-poza-domem-Wzrost-o-50-proc-rdr-8520299.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-09 10:34:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/2/a5627f94a7f6c4-948-568-0-116-3327-1996.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Poza domem tegoroczną Wielkanoc spędzi o 51 proc. więcej Polaków niż w ubiegłym roku – wynika z danych portalu Nocowanie.pl. Jak podał, przyczyną wzrostu był kończący się bon turystyczny, którym do końca marca można było płacić za usługi hotelarskie.</p>

## Ukraina pozbywa się starych oligarchów, ale obawia się nowych. Odbudowie kraju może przeszkodzić kleptokracja
 - [https://www.bankier.pl/wiadomosc/Ukraina-pozbywa-sie-starych-oligarchow-ale-obawia-sie-nowych-Odbudowie-kraju-moze-przeszkodzic-kleptokracja-8518883.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ukraina-pozbywa-sie-starych-oligarchow-ale-obawia-sie-nowych-Odbudowie-kraju-moze-przeszkodzic-kleptokracja-8518883.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-09 09:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/4/3f6dcbbbc8e958-948-568-0-180-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ukraina pozbywa się dawnych oligarchów, a jednocześnie obawia się nowych. Finansowanie odbudowy kraju po zakończeniu wojny będzie zależało od postępów w wykorzenianiu korupcji i postsowieckiej kleptokracji - napisała w czwartek agencja Bloomberg.</p>

## Warszawa w europejskiej czołówce miast z największą liczbą wieżowców
 - [https://www.bankier.pl/wiadomosc/Warszawa-w-europejskiej-czolowce-miast-z-najwieksza-liczba-wiezowcow-8517369.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Warszawa-w-europejskiej-czolowce-miast-z-najwieksza-liczba-wiezowcow-8517369.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-09 08:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/0/d3959e3690e3ce-948-568-0-338-3982-2389.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W Warszawie w 2022 r. oddano do użytku o prawie 30 proc. mniej powierzchni biurowych niż w rekordowym 2021 r. - podano w raporcie firmy doradczej Deloitte. 27 biurowców w stolicy ma ponad 100 m wysokości, co plasuje ją w europejskiej czołówce miast z największą liczbą wieżowców - dodano.</p>

## Idą zmiany w budowlance. Żółta kartka od nadzoru ma być ułatwieniem dla inwestora
 - [https://www.bankier.pl/wiadomosc/Ida-zmiany-w-budowlance-Zolta-kartka-od-nadzoru-ma-byc-ulatwieniem-dla-inwestora-8519051.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ida-zmiany-w-budowlance-Zolta-kartka-od-nadzoru-ma-byc-ulatwieniem-dla-inwestora-8519051.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-09 07:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/5/fe90881286926d-948-568-0-50-2506-1503.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rząd wraca do pomysłu żółtej kartki w prawie budowlanym. Otrzyma ją inwestor, który dopuści się istotnego odstąpienia od projektu lub przepisów. Inspektor nadzoru budowalnego nie będzie wtedy wstrzymywać budowy, tylko pouczy inwestora. Dopiero gdy ten zlekceważy zalecenia, nadzór zastosuje ostrzejsze środki - czytamy na łamach Prawo.pl.</p>

## Polacy kochają własne nieruchomości. Ale nie ma się z czego cieszyć
 - [https://www.bankier.pl/wiadomosc/Polacy-kochaja-wlasne-nieruchomosci-Ale-nie-ma-sie-z-czego-cieszyc-8520243.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polacy-kochaja-wlasne-nieruchomosci-Ale-nie-ma-sie-z-czego-cieszyc-8520243.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-09 05:46:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/5/6c792ce68dffbd-948-568-0-0-1773-1064.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Polska ma jeden z największych w Europie i większy niż średnia unijna odsetek własności mieszkań i domów - wskazał Polski Instytut Ekonomiczny. Analitycy PIE zwrócili uwagę na duży udział mieszkań wybudowanych do lat 90. oraz wysoki odsetek ludzi młodych mieszkających z rodzicami.</p>

## Avada kedavra Netflixie. Czyli HBO wraca z Harrym Potterem
 - [https://www.bankier.pl/wiadomosc/Avada-kedavra-Netflixie-Czyli-HBO-wraca-z-Harrym-Potterem-8519773.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Avada-kedavra-Netflixie-Czyli-HBO-wraca-z-Harrym-Potterem-8519773.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-09 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/3/bb350ec7144d2f-948-568-24-367-3239-1943.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Czarodziej w okularach z charakterystyczną blizną na czole przykrytą niesforną grzywką stał się symbolem. Ten, którego imienia nie trzeba nawet wymawiać, by było wiadomo, o kogo chodzi powróci do telewizji dzięki Warner Bros., grupy do której należy HBO. Finalizowane są właśnie rozmowy z twórczynią Harry'ego Pottera J.K. Rowling. </p>

## Nie dawaj księdzu pieniędzy do ręki. Nie będziesz mógł odliczyć darowizny w PIT
 - [https://www.bankier.pl/wiadomosc/Darowizna-pieniezna-przekazana-na-rachunek-bankowy-podlega-odliczeniu-w-PIT-8519781.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Darowizna-pieniezna-przekazana-na-rachunek-bankowy-podlega-odliczeniu-w-PIT-8519781.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-09 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/a/dd08b257285f21-945-567-0-135-1275-765.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Podatnicy
 mają możliwość odliczenia darowizny - także na kościół - od podatku. Warto zadbać o to, aby 
przekazać je we właściwy sposób i zmniejszyć podatek do zapłaty. 
Dlaczego nie opłaca się wkładać pieniędzy do koperty w trakcie kolędy 
czy przekazywać gotówki? Wyjaśniamy.</p>

## Oto 10 najdroższych jaj Fabergé. Cudowne, a ceny jeszcze piękniejsze
 - [https://www.bankier.pl/wiadomosc/Najdrozsze-pisanki-swiata-Jaja-Faberge-warte-miliony-8517591.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Najdrozsze-pisanki-swiata-Jaja-Faberge-warte-miliony-8517591.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-09 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/6/cc757cfcf7c82b-948-568-0-48-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wielkanocne jaja Fabergé rozpalają wyobraźnię wielu miłośników błyskotek. Uważane za arcydzieła sztuki jubilerskiej, wykonane z najcenniejszych materiałów, niejednokrotnie pomimo burzliwej historii - zachwycają do dziś. Na ile wycenia się najcenniejsze okazy? Kwoty idą w grube miliony dolarów...</p>

## Potrzebni informatycy i marketingowcy. Najlepiej odporni na stres
 - [https://www.bankier.pl/wiadomosc/Potrzebni-informatycy-i-marketingowcy-Najlepiej-odporni-na-stres-8519930.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Potrzebni-informatycy-i-marketingowcy-Najlepiej-odporni-na-stres-8519930.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-09 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/a/26c4584e6addae-948-568-0-0-3311-1987.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ponad 70 proc. polskich pracodawców
ma problem z zatrudnieniem pracowników z niezbędnymi umiejętnościami.
Najtrudniej znaleźć kandydatów z obszaru IT i analizy danych, a także sprzedaży
i marketingu – wynika z najnowszego raportu ManpowerGroup „Niedobór talentów”.</p>

## Rosnąca popularność "elektryków" podbije ceny OC. Na co mogą liczyć posiadacze takich aut w ramach ubezpieczenia?
 - [https://www.bankier.pl/wiadomosc/Rosnaca-popularnosc-elektrykow-podbije-ceny-OC-Na-co-moga-liczyc-posiadacze-takich-aut-w-ramach-ubezpieczenia-8514740.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rosnaca-popularnosc-elektrykow-podbije-ceny-OC-Na-co-moga-liczyc-posiadacze-takich-aut-w-ramach-ubezpieczenia-8514740.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-09 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/d/2929d57a7fa35a-948-568-0-270-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wzrost
popularności samochodów elektrycznych motywuje ubezpieczycieli do modyfikacji oferty
AC i assistance. Ciekawe zmiany można zaobserwować również w Polsce. </p>

## Izrael i Syria dokonały ataków rakietowych
 - [https://www.bankier.pl/wiadomosc/Izrael-i-Syria-dokonaly-atakow-rakietowych-8520221.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Izrael-i-Syria-dokonaly-atakow-rakietowych-8520221.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-09 00:19:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/e/1f614cadd0422a-948-569-0-228-1576-946.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Izraelski rzecznik wojskowy poinformował w nocy z soboty na niedzielę, że z Syrii wystrzelono 3 rakiety w kierunku Izraela, z których tylko jedna zdołała osiągnąć terytorium izraelskie. Atak, rzadki z tego kierunku, nastąpił po serii aktów przemocy w Jerozolimie, Tel Awiwie i w rejonie Strefy Gazy.</p>

