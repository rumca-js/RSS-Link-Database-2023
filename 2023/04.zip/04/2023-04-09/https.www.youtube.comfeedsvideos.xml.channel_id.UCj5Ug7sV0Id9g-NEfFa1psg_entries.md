# Source:Tomasz Samołyk, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCj5Ug7sV0Id9g-NEfFa1psg, language:en-US

## Jak bronić i atakować Jana Pawła II przy wielkanocnym stole [poradnik]
 - [https://www.youtube.com/watch?v=gAGagjG3a9w](https://www.youtube.com/watch?v=gAGagjG3a9w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCj5Ug7sV0Id9g-NEfFa1psg
 - date published: 2023-04-09 08:00:19+00:00

W dzisiejszym specjalnym odcinku zapraszam na wykład mojego wujka w sprawie ataku/obrony Jana Pawła II

Abp Ryś o zdewastowaniu pomnika św. Jana Pawła II: https://youtu.be/JLEunrYrnyU

"Zwycięzca śmierci" w wykonaniu scholi dominikańskiej ze Służewa: https://youtu.be/QHhNZPvk_z8

