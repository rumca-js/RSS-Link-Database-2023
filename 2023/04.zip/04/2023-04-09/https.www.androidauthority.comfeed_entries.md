# Source:Android Authority, URL:https://www.androidauthority.com/feed/, language:en-US

## What is Snapdragon Satellite? Everything you need to know
 - [https://www.androidauthority.com/what-is-snapdragon-satellite-3310908/](https://www.androidauthority.com/what-is-snapdragon-satellite-3310908/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2023-04-09 21:36:39+00:00

Android phones across price tiers are about to get satellite connectivity.

## I use my Galaxy Watch in all the dumb ways
 - [https://www.androidauthority.com/galaxy-watch-smart-dumb-use-3309283/](https://www.androidauthority.com/galaxy-watch-smart-dumb-use-3309283/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2023-04-09 16:00:51+00:00

For everything the smartwatch could do, it could barely last through the day.

## The Samsung Galaxy S23 Ultra is king of the hill, but the small S23 has my heart
 - [https://www.androidauthority.com/samsung-galaxy-s23-vs-galaxy-s23-ultra-3307282/](https://www.androidauthority.com/samsung-galaxy-s23-vs-galaxy-s23-ultra-3307282/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2023-04-09 14:00:32+00:00

Striking that near-perfect balance between portability, performance and value.

## I really miss phones with pop-up selfie cameras
 - [https://www.androidauthority.com/miss-pop-up-selfie-cameras-opinion-3308151/](https://www.androidauthority.com/miss-pop-up-selfie-cameras-opinion-3308151/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2023-04-09 12:00:51+00:00

Under-display and punch-hole cameras are interesting innovations, but pop-up cameras were way cooler.

## Does ChatGPT save your data? Here’s what you need to know
 - [https://www.androidauthority.com/does-chatgpt-save-data-conversations-3310883/](https://www.androidauthority.com/does-chatgpt-save-data-conversations-3310883/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2023-04-09 00:26:22+00:00

ChatGPT keeps a record of everything you tell it, but is that a problem?

