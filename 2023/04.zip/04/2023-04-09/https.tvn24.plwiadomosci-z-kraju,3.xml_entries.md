# Source:TVN24 Z kraju, URL:https://tvn24.pl/wiadomosci-z-kraju,3.xml, language:pl-PL

## Pogoda na jutro - poniedziałek 10.04. Noc mglista, dzień w części kraju z deszczem i burzami
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-jutro-poniedzialek-1004-noc-mglista-dzien-w-czesci-kraju-z-deszczem-i-burzami-6893244?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-jutro-poniedzialek-1004-noc-mglista-dzien-w-czesci-kraju-z-deszczem-i-burzami-6893244?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-09 17:52:26+00:00

<img alt="Pogoda na jutro - poniedziałek 10.04. Noc mglista, dzień w części kraju z deszczem i burzami" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3ug6lr-mgly-beda-geste-6154691/alternates/LANDSCAPE_1280" />
    Noc z niedzieli na poniedziałek w całej Polsce będzie mglista. Widzialność w niektórych miejscach może być ograniczona do 200 metrów. W prognozie pogody na Poniedziałek Wielkanocny widać dużo regionów z pogodnym niebem, ale będą też miejsca, w których popada deszcz i zagrzmi.

## Podczas prac na polu znalazł kamienny grot. Mógł służyć do pracy albo stanowić symbol władzy
 - [https://tvn24.pl/bialystok/czestoborowice-podczas-prac-na-polu-znalazl-kamienny-grot-zabytek-trafil-do-sluzb-konserwatorskich-6893166?source=rss](https://tvn24.pl/bialystok/czestoborowice-podczas-prac-na-polu-znalazl-kamienny-grot-zabytek-trafil-do-sluzb-konserwatorskich-6893166?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-09 15:40:14+00:00

<img alt="Podczas prac na polu znalazł kamienny grot. Mógł służyć do pracy albo stanowić symbol władzy " src="https://tvn24.pl/najnowsze/cdn-zdjecie-5t6lxq-ostrze-jest-zblizone-ksztaltem-do-form-lisciowatych-6893167/alternates/LANDSCAPE_1280" />
    Mógł służyć do pracy albo do walki, a nawet stanowić symbol władzy. Mowa o kamiennym grocie, który został znaleziony przez rolnika z okolic miejscowości Częstoborowice (woj. lubelskie). Artefakt trafił do służb konserwatorskich. Datowany jest na lata 2200-1650 przed naszą erą.

## Zderzenie dwóch aut, w jednym było dziecko
 - [https://tvn24.pl/tvnwarszawa/ulice/zderzenie-dwoch-aut-w-jednym-bylo-dziecko-6893161?source=rss](https://tvn24.pl/tvnwarszawa/ulice/zderzenie-dwoch-aut-w-jednym-bylo-dziecko-6893161?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-09 15:14:29+00:00

<img alt="Zderzenie dwóch aut, w jednym było dziecko" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-am0j0n-zderzenie-na-trasie-torunskiej-6893141/alternates/LANDSCAPE_1280" />
    W alei Prymasa Tysiąclecia, na wysokości Lasku na Kole, zderzyły się dwa auta, w jednym z nich było dziecko. Ratownicy przebadali uczestników zdarzenia. Informację dostaliśmy na Kontakt 24.

## Królik został policjantem w Kalifornii. Odpowiada za dobrostan innych funkcjonariuszy
 - [https://tvn24.pl/tvnmeteo/swiat/kalifornia-yuba-city-krolik-percy-zostal-policjantem-ma-mundur-i-zakres-obowiazkow-6892584?source=rss](https://tvn24.pl/tvnmeteo/swiat/kalifornia-yuba-city-krolik-percy-zostal-policjantem-ma-mundur-i-zakres-obowiazkow-6892584?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-09 14:37:54+00:00

<img alt="Królik został policjantem w Kalifornii. Odpowiada za dobrostan innych funkcjonariuszy " src="https://tvn24.pl/najnowsze/cdn-zdjecie-2uexom-krolik-percy-zostal-policjantem-w-kalifornii-6893056/alternates/LANDSCAPE_1280" />
    Percy to królik, który został policjantem. Można go spotkać w Kalifornii, w komisariacie policji miasta Yuba w hrabstwie Sutter. I jego obecność tam wcale nie jest przypadkowa.

## Tonąca suczka uratowana przez strażników granicznych. "To najpiękniejszy prezent na Wielkanoc"
 - [https://tvn24.pl/pomorze/stara-pasleka-16-letnia-suczka-tonela-w-paslece-uratowali-ja-straznicy-graniczni-6892887?source=rss](https://tvn24.pl/pomorze/stara-pasleka-16-letnia-suczka-tonela-w-paslece-uratowali-ja-straznicy-graniczni-6892887?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-09 14:35:39+00:00

<img alt="Tonąca suczka uratowana przez strażników granicznych. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-m5wt8x-tonela-w-paslece-uratowali-ja-straznicy-graniczni-6893020/alternates/LANDSCAPE_1280" />
    Funkcjonariusze z Kaszubskiego Dywizjonu Straży Granicznej uratowali 16-letnią suczkę tonącą w rzece Pasłęka (woj. warmińsko-mazurskie). Kilka dni wcześniej właścicielka zgłosiła animalsom zaginięcie zwierzęcia.

## Protest rolników trwa mimo Wielkanocy. Odwiedzają ich rodziny i mieszkańcy Szczecina
 - [https://tvn24.pl/pomorze/szczecin-protest-rolnikow-trwa-mimo-wielkanocy-odwiedzaja-ich-rodziny-i-mieszkancy-miasta-6892935?source=rss](https://tvn24.pl/pomorze/szczecin-protest-rolnikow-trwa-mimo-wielkanocy-odwiedzaja-ich-rodziny-i-mieszkancy-miasta-6892935?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-09 14:33:28+00:00

<img alt="Protest rolników trwa mimo Wielkanocy. Odwiedzają ich rodziny i mieszkańcy Szczecina" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9s27eb-wielkanoc-rolnikow-w-zielonym-miasteczku-6893084/alternates/LANDSCAPE_1280" />
    Na czas świąt rolnicy zawiesili blokady ulic w centrum Szczecina. Nie opuszczają jednak "zielonego miasteczka". Wspierają ich rodziny i mieszkańcy miasta, którzy składają im życzenia i przynoszą smakołyki ze świątecznego stołu. - Wolelibyśmy być na święta w domach, ale trzeba walczyć o swoje sprawy - mówią protestujący. Rolnicy czekają na spotkanie z nowym ministrem rolnictwa. We wtorek odbędą się rozmowy techniczne, podczas których ma zostać ustalony termin przyjazdu do Szczecina ministra Roberta Telusa.

## Zabytkowy kampus zamienił się w parking. Studenci chcą usunąć część aut
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-parkowanie-w-kampusie-glownym-uw-6891485?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-parkowanie-w-kampusie-glownym-uw-6891485?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-09 14:24:00+00:00

<img alt="Zabytkowy kampus zamienił się w parking. Studenci chcą usunąć część aut" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-9b3xy-parkowanie-przed-budynkiem-starego-buw-6891275/alternates/LANDSCAPE_1280" />
    Prawie 200 aut może parkować na terenie zabytkowego kampusu Uniwersytetu Warszawskiego. Studenci chcieliby usunąć miejsca parkingowe z najbardziej reprezentacyjnej części - dziedzińca przed biblioteką. Uczelnia nie mówi "nie".

## Po telefonie z "banku" zainstalował aplikację i podał dane karty kredytowej. Stracił 100 tysięcy złotych
 - [https://tvn24.pl/tvnwarszawa/najnowsze/oszustwa-po-telefonie-z-banku-zainstalowal-aplikacje-i-podal-dane-karty-kredytowej-stracil-100-tysiecy-zlotych-6893030?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/oszustwa-po-telefonie-z-banku-zainstalowal-aplikacje-i-podal-dane-karty-kredytowej-stracil-100-tysiecy-zlotych-6893030?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-09 14:02:42+00:00

<img alt="Po telefonie z " src="https://tvn24.pl/najnowsze/cdn-zdjecie-crrx7q-komputer-telefon-5558747/alternates/LANDSCAPE_1280" />
    Odebrał telefon, na ekranie wyświetlił się numer banku. Dzwoniący powiedział, że pieniądze mężczyzny są zagrożone. I polecił zainstalować aplikację do zdalnego pulpitu. Potem był drugi telefon w sprawie karty kredytowej. Mężczyzna wykonał wszystkie polecenia. Stracił 100 tysięcy złotych.

## Ktoś strzelał do kota jak do żywej tarczy. Rudy Elvis stracił wzrok, znalazł nowy dom
 - [https://tvn24.pl/krakow/debica-warszawa-ktos-strzelal-do-kota-jak-do-zywej-tarczy-rudy-elvis-stracil-wzrok-znalazl-nowy-dom-6892844?source=rss](https://tvn24.pl/krakow/debica-warszawa-ktos-strzelal-do-kota-jak-do-zywej-tarczy-rudy-elvis-stracil-wzrok-znalazl-nowy-dom-6892844?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-09 13:29:46+00:00

<img alt="Ktoś strzelał do kota jak do żywej tarczy. Rudy Elvis stracił wzrok, znalazł nowy dom" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2ttnxl-elvis-6892873/alternates/LANDSCAPE_1280" />
    Historia rudego kota Elvisa z Dębicy (woj. podkarpackie), bestialsko potraktowanego przez człowieka, ma szczęśliwe zakończenie. Zwierzak, do którego ktoś strzelał śrutem jak do żywej tarczy, nie wróci już na ulicę. Trafił do Warszawy, do ludzi, którzy dali mu dom. - To jest najlepsze co mu się przydarzyło - cieszy się Irena Nowak, szefowa Fundacji Psi Azylek, do której trafił ciężko ranny kot.

## Ptasie pisanki. Jakiego koloru jest jajko? Dlaczego jajo to symbol Wielkanocy?
 - [https://tvn24.pl/tvnmeteo/polska/ptasie-pisanki-jakiego-koloru-jest-jajko-dlaczego-jajo-to-symbol-wielkanocy-6892848?source=rss](https://tvn24.pl/tvnmeteo/polska/ptasie-pisanki-jakiego-koloru-jest-jajko-dlaczego-jajo-to-symbol-wielkanocy-6892848?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-09 13:17:00+00:00

<img alt="Ptasie pisanki. Jakiego koloru jest jajko? Dlaczego jajo to symbol Wielkanocy?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pe3thp-ptasie-pisanki-na-wystawie-w-bialymstoku-6892884/alternates/LANDSCAPE_1280" />
    Jajka ptasie to cud przyrody, wytwór samej matki natury. Są zadziwiające pod względem wielkości, kształtu, ubarwienia - opowiadała w rozmowie z TVN24  dr Anna Matwiejuk, kierownik Uniwersyteckiego Centrum Przyrodniczego im. prof. Andrzeja Myrchy w Białymstoku. To prawdziwe "ptasie pisanki", i tak właśnie zatytułowano poświęconą im wystawę.

## "Co roku do stołecznej pieczy zastępczej trafia średnio 500 dzieci"
 - [https://tvn24.pl/tvnwarszawa/srodmiescie/co-roku-do-stolecznej-pieczy-zastepczej-trafia-srednio-500-dzieci-6892915?source=rss](https://tvn24.pl/tvnwarszawa/srodmiescie/co-roku-do-stolecznej-pieczy-zastepczej-trafia-srednio-500-dzieci-6892915?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-09 12:31:20+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-je6t7w-plac-5023814/alternates/LANDSCAPE_1280" />
    Każde dziecko ma prawo do wychowywania się w rodzinie. W przypadku gdy rodzice nie mogą lub nie są w stanie sprawować opieki i wychowywać swojego dziecka, miasto zapewnia mu opiekę w ramach systemu pieczy zastępczej - przypomina stołeczny ratusz. Co roku, trafia tam średnio 500 dzieci. Do 11 kwietnia tego roku trwają konsultacje programu rozwoju pieczy zastępczej w Warszawie na lata 2023-2025.

## Sprawdź, gdzie jest burza. W Niedzielę Wielkanocną zagrzmiało w części kraju
 - [https://tvn24.pl/tvnmeteo/pogoda/gdzie-jest-burza-burze-w-polsce-w-niedziele-904-sprawdz-gdzie-jest-burza-mapa-i-radar-burz-6892835?source=rss](https://tvn24.pl/tvnmeteo/pogoda/gdzie-jest-burza-burze-w-polsce-w-niedziele-904-sprawdz-gdzie-jest-burza-mapa-i-radar-burz-6892835?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-04-09 11:32:32+00:00

<img alt="Sprawdź, gdzie jest burza. W Niedzielę Wielkanocną zagrzmiało w części kraju" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-tol2np-wyladowania-atmosferyczne-nad-polska-w-niedziele-godz-1810-6892932/alternates/LANDSCAPE_1280" />
    Gdzie jest burza? W Niedzielę Wielkanocną pojawiają się nad Polską wyładowania atmosferyczne. Grzmi na północnym wschodzie kraju. Sprawdź, gdzie jest burza, i śledź na tvnmeteo.pl aktualną sytuację pogodową w Polsce.

