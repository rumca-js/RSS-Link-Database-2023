# Source:Nineteenth century videos. Back to life., URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC8abMPJmTPmsaSc7j-lwIhQ, language:en-US

## [4K, 60 fps, colorized] (1935) Only known footage of Roosevelt walking. White House Easter Egg Roll.
 - [https://www.youtube.com/watch?v=vPEguASMaoI](https://www.youtube.com/watch?v=vPEguASMaoI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC8abMPJmTPmsaSc7j-lwIhQ
 - date published: 2023-04-09 16:17:36+00:00

FDR contracted polio at the age of 39, which left his legs partially paralyzed. Fearing this would impact his bid for presidency, he came to an agreement with the press: no photos of him walking or getting in and out of cars.

Music: U.S. Marine Band.
Join as a member to support this channel:
https://www.youtube.com/channel/UC8abMPJmTPmsaSc7j-lwIhQ/join

