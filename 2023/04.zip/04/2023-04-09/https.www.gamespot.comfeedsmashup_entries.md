# Source:GameSpot, URL:https://www.gamespot.com/feeds/mashup, language:en-US

## Star Wars Jedi: Survivor Official Final Gameplay Trailer
 - [https://www.gamespot.com/videos/star-wars-jedi-survivor-official-final-gameplay-trailer/2300-6461098/](https://www.gamespot.com/videos/star-wars-jedi-survivor-official-final-gameplay-trailer/2300-6461098/)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2023-04-09 14:24:00+00:00

<img height="480" src="https://www.gamespot.com/a/uploads/square_medium/1352/13527689/4123508-jedisite.jpg" width="480" /> The story of Cal Kestis continues in Star Wars Jedi: Survivor, an epic new adventure that will push Cal further than ever as he fights to protect the galaxy from descending into darkness. Picking up five years after the events of Star Wars Jedi: Fallen Order, the game is a third person, narrative-driven action-adventure game from Respawn Entertainment, developed in collaboration with Lucasfilm Games. Star Wars Jedi: Survivor will be available on PlayStation 5, Xbox Series X|S and Windows PC on April 28, 202

## Disney Dreamlight Valley Eggstravaganza: New Items, Seasonal Challenges, And More
 - [https://www.gamespot.com/articles/disney-dreamlight-valley-eggstravaganza-new-items-seasonal-challenges-and-more/1100-6513015/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/disney-dreamlight-valley-eggstravaganza-new-items-seasonal-challenges-and-more/1100-6513015/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2023-04-09 14:19:00+00:00

<p>Despite being in early access, <a href="https://www.gamespot.com/games/disney-dreamlight-valley/">Disney Dreamlight Valley</a> has had some fun holiday events filled with limited-time challenges and cosmetics, and that trend is continuing with the Eggstravaganza Event. With some fresh holiday-themed Dreamlight tasks to knock out, additional furniture to craft, and even some new cooking recipes, there's a lot to keep you busy during the event. Here's everything you need to know.</p><h2>Event dates</h2><p>The Eggstravaganza Event runs from <strong>Saturday, April 8 through Saturday, April 29</strong>. There are some new additions to the game during this time period that must be completed before the event ends or you'll lose out on the opportunity, so be sure to make the most of your time.</p><h2>New items</h2><p>There are some new event-exclusive items to get your hands on if you want to craft and cook all of the new recipes.</p><a href="https://www.gamespot.com/articles/disney-dreamlight-valley-eggstravaganza-new-items-seasonal-challenges-and-more/1100-6513015/?ftag=CAD-01-10abi2f/">Continue Reading at GameSpot</a>

