# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## Elektryczny RAM 1500 REV zaoferuje akumulator o pojemności do 229 kWh i imponujący zasięg
 - [https://ithardware.pl/aktualnosci/elektryczny_ram_1500_rev_zaoferuje_akumulator_o_pojemnosci_do_229_kwh_i_imponujacy_zasieg-26730.html](https://ithardware.pl/aktualnosci/elektryczny_ram_1500_rev_zaoferuje_akumulator_o_pojemnosci_do_229_kwh_i_imponujacy_zasieg-26730.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-09 22:15:47+00:00

<img src="https://ithardware.pl/artykuly/min/26730_1.jpg" />            Koncern motoryzacyjny Stellantis zaprezentował samoch&oacute;d&nbsp;RAM 1500 REV, kt&oacute;ry ma trafić na coraz popularniejszy rynek elektrycznych pickup&oacute;w. Nowość będzie miała zasięg ponad 800 km, co jest możliwe dzięki gigantycznej...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/elektryczny_ram_1500_rev_zaoferuje_akumulator_o_pojemnosci_do_229_kwh_i_imponujacy_zasieg-26730.html">https://ithardware.pl/aktualnosci/elektryczny_ram_1500_rev_zaoferuje_akumulator_o_pojemnosci_do_229_kwh_i_imponujacy_zasieg-26730.html</a></p>

## Samsung zaliczy najgorszy kwartał od lat. Kryzys dotknął producenta smartfonów
 - [https://ithardware.pl/aktualnosci/samsung_zaliczy_najgorszy_kwartal_od_lat_kryzys_dotknal_producenta_smartfonow-26729.html](https://ithardware.pl/aktualnosci/samsung_zaliczy_najgorszy_kwartal_od_lat_kryzys_dotknal_producenta_smartfonow-26729.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-09 21:38:17+00:00

<img src="https://ithardware.pl/artykuly/min/26729_1.jpg" />            Samsung nie może zaliczyć minionych miesięcy do udanych. Gigant technologiczny odpowiadający za popularną serię smartfon&oacute;w Galaxy ma osiągnąć&nbsp;w pierwszym kwartale 2023 roku najgorszy rezultat od przeszło dekady. Światowy kryzys...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/samsung_zaliczy_najgorszy_kwartal_od_lat_kryzys_dotknal_producenta_smartfonow-26729.html">https://ithardware.pl/aktualnosci/samsung_zaliczy_najgorszy_kwartal_od_lat_kryzys_dotknal_producenta_smartfonow-26729.html</a></p>

## Czy płyta główna może mieć wpływ na wydajność komputera? Okazuje się, że... tak
 - [https://ithardware.pl/aktualnosci/czy_plyta_glowna_moze_miec_wplyw_na_wydajnosc_komputera_okazuje_sie_ze_tak-26727.html](https://ithardware.pl/aktualnosci/czy_plyta_glowna_moze_miec_wplyw_na_wydajnosc_komputera_okazuje_sie_ze_tak-26727.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-09 19:51:10+00:00

<img src="https://ithardware.pl/artykuly/min/26727_1.jpg" />            Czy płyta gł&oacute;wna&nbsp;wpływa na wydajność komputera?&nbsp;Jak wynika z&nbsp;opublikowanych w sieci test&oacute;w, w niekt&oacute;rych przypadkach odpowiedź na to pytanie może być twierdząca. Jeden z Youtuber&oacute;w postanowił...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/czy_plyta_glowna_moze_miec_wplyw_na_wydajnosc_komputera_okazuje_sie_ze_tak-26727.html">https://ithardware.pl/aktualnosci/czy_plyta_glowna_moze_miec_wplyw_na_wydajnosc_komputera_okazuje_sie_ze_tak-26727.html</a></p>

## Nie będzie nowej części American McGee's Alice. EA blokuje realizację projektu
 - [https://ithardware.pl/aktualnosci/nie_bedzie_nowej_czesci_american_mcgee_s_alice_ea_blokuje_realizacje_projektu-26728.html](https://ithardware.pl/aktualnosci/nie_bedzie_nowej_czesci_american_mcgee_s_alice_ea_blokuje_realizacje_projektu-26728.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-09 18:50:39+00:00

<img src="https://ithardware.pl/artykuly/min/26728_1.jpg" />            American McGee's Alice to nietypowe, mroczne podejście do Alicji&nbsp;w Krainie Czar&oacute;w, w kt&oacute;rej gł&oacute;wna bohaterka rozprawia się ze złą Kr&oacute;lową Kier przy pomocy krwiożerczego arsenału. Seria zadebiutowała 23 lata...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nie_bedzie_nowej_czesci_american_mcgee_s_alice_ea_blokuje_realizacje_projektu-26728.html">https://ithardware.pl/aktualnosci/nie_bedzie_nowej_czesci_american_mcgee_s_alice_ea_blokuje_realizacje_projektu-26728.html</a></p>

## Microsoft blokuje emulatory gier na konsolach Xbox Series
 - [https://ithardware.pl/aktualnosci/microsoft_blokuje_emulatory_gier_na_konsolach_xbox_series-26726.html](https://ithardware.pl/aktualnosci/microsoft_blokuje_emulatory_gier_na_konsolach_xbox_series-26726.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-09 17:45:24+00:00

<img src="https://ithardware.pl/artykuly/min/26726_1.jpg" />            Microsoft przez trzy lata przymykał oko na emulowanie gier na konsolach Xbox Series X/S, ale najwyraźniej te czasy minęły. Wskazują na to zrzuty ekranu udostępniane przez graczy. Jest jednak pewien wyjątek.

Po premierze konsol Xbox Series X/S w...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/microsoft_blokuje_emulatory_gier_na_konsolach_xbox_series-26726.html">https://ithardware.pl/aktualnosci/microsoft_blokuje_emulatory_gier_na_konsolach_xbox_series-26726.html</a></p>

## Microsoft blokuje emulatory gier na konsolach Xbox Series. Jest jednak wyjątek
 - [https://ithardware.pl/aktualnosci/microsoft_blokuje_emulatory_gier_na_konsolach_xbox_series_jest_jednak_wyjatek-26726.html](https://ithardware.pl/aktualnosci/microsoft_blokuje_emulatory_gier_na_konsolach_xbox_series_jest_jednak_wyjatek-26726.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-09 17:45:24+00:00

<img src="https://ithardware.pl/artykuly/min/26726_1.jpg" />            Microsoft przez trzy lata przymykał oko na emulowanie gier na konsolach Xbox Series X/S, ale najwyraźniej te czasy minęły. Wskazują na to zrzuty ekranu udostępniane przez graczy. Jest jednak pewien wyjątek.

Po premierze konsol Xbox Series X/S w...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/microsoft_blokuje_emulatory_gier_na_konsolach_xbox_series_jest_jednak_wyjatek-26726.html">https://ithardware.pl/aktualnosci/microsoft_blokuje_emulatory_gier_na_konsolach_xbox_series_jest_jednak_wyjatek-26726.html</a></p>

## Microsoft handlował z firmami i osobami objętymi sankcjami. USA ukarały giganta
 - [https://ithardware.pl/aktualnosci/microsoft_handlowal_z_rosja_i_krajami_objetymi_sankcjami_usa_ukaraly_giganta-26725.html](https://ithardware.pl/aktualnosci/microsoft_handlowal_z_rosja_i_krajami_objetymi_sankcjami_usa_ukaraly_giganta-26725.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-09 16:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/26725_1.jpg" />            Microsoft tak jak wiele innych korporacji&nbsp;technologicznych wycofał&nbsp;się z rosyjskiego rynku po inwazji Rosji na Ukrainę. Kilka miesięcy temu pojawiła się informacja jakoby producent wznowił&nbsp;wsparcie dla tamtejszych...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/microsoft_handlowal_z_rosja_i_krajami_objetymi_sankcjami_usa_ukaraly_giganta-26725.html">https://ithardware.pl/aktualnosci/microsoft_handlowal_z_rosja_i_krajami_objetymi_sankcjami_usa_ukaraly_giganta-26725.html</a></p>

## Cudowny termopad z Chin Honeywell PTM7950 czy Thermal Grizzly Kryonaut
 - [https://ithardware.pl/testyirecenzje/kupilismy_termopad_z_chin_honeywell_ptm7950_czy_thermal_grizzly_kryonaut-26655.html](https://ithardware.pl/testyirecenzje/kupilismy_termopad_z_chin_honeywell_ptm7950_czy_thermal_grizzly_kryonaut-26655.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-09 14:20:10+00:00

<img src="https://ithardware.pl/artykuly/min/26655_1.jpg" />            Cudowny termopad Honeywell PTM7950 - testujemy fenomen z Chin

Tym razem nietypowy test, ponieważ sprawdzam&nbsp;hit z chińskiego serwisu aukcyjnego, czyli termopad&nbsp;Honeywell PTM7950.&nbsp;Czy podkładka termiczna będzie lepsza od popularnej...
            <p>Pełna wersja strony <a href="https://ithardware.pl/testyirecenzje/kupilismy_termopad_z_chin_honeywell_ptm7950_czy_thermal_grizzly_kryonaut-26655.html">https://ithardware.pl/testyirecenzje/kupilismy_termopad_z_chin_honeywell_ptm7950_czy_thermal_grizzly_kryonaut-26655.html</a></p>

## Australijski pilotaż łączy CBDC z kredytami węglowymi
 - [https://ithardware.pl/aktualnosci/australijski_pilotaz_laczy_cbdc_z_kredytami_weglowymi-26724.html](https://ithardware.pl/aktualnosci/australijski_pilotaz_laczy_cbdc_z_kredytami_weglowymi-26724.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-09 10:52:10+00:00

<img src="https://ithardware.pl/artykuly/min/26724_1.jpg" />            Australijska i Nowozelandzka Grupa Bankowa (ANZ)&nbsp;oraz Grollo Carbon Ventures (GCV) podjęły wsp&oacute;łpracę w celu umożliwienia handlu australijskimi jednostkami kredytu węglowego (ACCU).

Projekt był jednym z 14 pilotowanych przez Reserve...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/australijski_pilotaz_laczy_cbdc_z_kredytami_weglowymi-26724.html">https://ithardware.pl/aktualnosci/australijski_pilotaz_laczy_cbdc_z_kredytami_weglowymi-26724.html</a></p>

## Pracownicy Tesli przekazują sobie najciekawsze filmiki z kamer klientów
 - [https://ithardware.pl/aktualnosci/pracownicy_tesli_przekazuja_sobie_najciekawsze_filmiki_z_kamer_klientow-26723.html](https://ithardware.pl/aktualnosci/pracownicy_tesli_przekazuja_sobie_najciekawsze_filmiki_z_kamer_klientow-26723.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-09 10:30:40+00:00

<img src="https://ithardware.pl/artykuly/min/26723_1.jpg" />            Kamery w samochodach Tesli stały się przedmiotem kolejnej kontrowersji związaną z tą firmą samochodową. Okazuje się, że pracownicy pomagający w rozwoju systemu autonomicznej jazdy często udostępniali między sobą wrażliwe obrazy...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/pracownicy_tesli_przekazuja_sobie_najciekawsze_filmiki_z_kamer_klientow-26723.html">https://ithardware.pl/aktualnosci/pracownicy_tesli_przekazuja_sobie_najciekawsze_filmiki_z_kamer_klientow-26723.html</a></p>

## Rosja stała się drugim co do wielkości wydobywcą kryptowalut na świecie
 - [https://ithardware.pl/aktualnosci/rosja_stala_sie_drugim_co_do_wielkosci_wydobywca_kryptowalut_na_swiecie-26722.html](https://ithardware.pl/aktualnosci/rosja_stala_sie_drugim_co_do_wielkosci_wydobywca_kryptowalut_na_swiecie-26722.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-09 09:50:50+00:00

<img src="https://ithardware.pl/artykuly/min/26722_1.jpg" />            Rosja przez długi czas występowała przeciwko kryptowalutom, ale obecnie sytuacja uległa zmianie i kraj stał się drugim pod względem wielkości wydobycia cyfrowych token&oacute;w&nbsp;na świecie.

Rosja zmieniła nastawienie do kryptowalut,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/rosja_stala_sie_drugim_co_do_wielkosci_wydobywca_kryptowalut_na_swiecie-26722.html">https://ithardware.pl/aktualnosci/rosja_stala_sie_drugim_co_do_wielkosci_wydobywca_kryptowalut_na_swiecie-26722.html</a></p>

