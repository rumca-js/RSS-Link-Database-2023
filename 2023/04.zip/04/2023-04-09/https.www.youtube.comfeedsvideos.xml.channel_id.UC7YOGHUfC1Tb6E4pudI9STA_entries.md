# Source:Mental Outlaw, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7YOGHUfC1Tb6E4pudI9STA, language:en-US

## The RESTRICT Act Would Be Impossible To Enforce
 - [https://www.youtube.com/watch?v=hdJ4CV524ls](https://www.youtube.com/watch?v=hdJ4CV524ls)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7YOGHUfC1Tb6E4pudI9STA
 - date published: 2023-04-09 01:49:48+00:00

In this video I explain how the RESTRICT act would be impossible to enforce, even with store now decrypt later policies being in place by all major governments and quantum computers capable of breaking RSA being a couple decades away there are already quantum resistant VPNs available for mitigation. 

Watch my other video about the restrict act https://www.youtube.com/watch?v=Hq-nNSyGH1U

Buy my merch
https://based.win/

₿💰💵💲Help Support the Channel by Donating Crypto💲💵💰₿

Monero
45F2bNHVcRzXVBsvZ5giyvKGAgm6LFhMsjUUVPTEtdgJJ5SNyxzSNUmFSBR5qCCWLpjiUjYMkmZoX9b3cChNjvxR7kvh436

Bitcoin
3MMKHXPQrGHEsmdHaAGD59FWhKFGeUsAxV

Ethereum
0xeA4DA3F9BAb091Eb86921CA6E41712438f4E5079

Litecoin
MBfrxLJMuw26hbVi2MjCVDFkkExz8rYvUF

Dash
Xh9PXPEy5RoLJgFDGYCDjrbXdjshMaYerz

Zcash
t1aWtU5SBpxuUWBSwDKy4gTkT2T1ZwtFvrr

Chainlink
0x0f7f21D267d2C9dbae17fd8c20012eFEA3678F14

Bitcoin Cash
qz2st00dtu9e79zrq5wshsgaxsjw299n7c69th8ryp

Etherum Classic
0xeA641e59913960f578ad39A6B4d02051A5556BfC

USD Coin
0x0B045f743A693b225630862a3464B52fefE79FdB

Subscribe to my YouTube channel http://goo.gl/9U10Wz
and be sure to click that notification bell so you know when new videos are released.

