# Source:ArsTechnica, URL:http://feeds.arstechnica.com/arstechnica/index/, language:en-US

## Musk admits NPR isn’t state-affiliated after asking questions he could have Googled
 - [https://arstechnica.com/?p=1930327](https://arstechnica.com/?p=1930327)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-04-09 18:23:38+00:00

NPR now labeled "Government Funded" despite getting under 1% of funds from US.

## Black hole is soaring between galaxies, leaving stars in its wake
 - [https://arstechnica.com/?p=1930219](https://arstechnica.com/?p=1930219)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-04-09 11:15:35+00:00

A galaxy merger may have set a supermassive black hole free.

