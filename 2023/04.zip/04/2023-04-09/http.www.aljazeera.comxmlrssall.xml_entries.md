# Source:Aljazeera, URL:http://www.aljazeera.com/xml/rss/all.xml, language:en-US

## Where does Taiwan’s future lie in the US-China tug-of-war?
 - [https://www.aljazeera.com/program/inside-story/2023/4/9/where-does-taiwans-future-lie-in-the-us-china-tug-of-war](https://www.aljazeera.com/program/inside-story/2023/4/9/where-does-taiwans-future-lie-in-the-us-china-tug-of-war)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-09 19:48:27+00:00

Chinese military simulates strikes on Taiwan in response to its president&#039;s visit to the US.

## Eight missing after buildings collapse in France’s Marseille
 - [https://www.aljazeera.com/news/2023/4/9/eight-people-missing-after-buildings-collapse-in-marseille](https://www.aljazeera.com/news/2023/4/9/eight-people-missing-after-buildings-collapse-in-marseille)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-09 19:42:36+00:00

Residents are believed to be buried under the rubble, as firefighters work to extinguish flames following an explosion.

## As Russia continues shelling, Pope Francis urges peace in Ukraine
 - [https://www.aljazeera.com/news/2023/4/9/pope-francis-appeals-to-russians-on-ukraine-calls-for-peace](https://www.aljazeera.com/news/2023/4/9/pope-francis-appeals-to-russians-on-ukraine-calls-for-peace)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-09 19:29:48+00:00

Over the weekend, Russian forces reportedly launched dozens of attacks on various parts of Ukraine.

## Ukraine likely to face bloody Crimea fight, satellite images show
 - [https://www.aljazeera.com/news/2023/4/9/ukraine-likely-to-face-bloody-crimea-fight-satellite-images-show](https://www.aljazeera.com/news/2023/4/9/ukraine-likely-to-face-bloody-crimea-fight-satellite-images-show)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-09 17:33:57+00:00

Russian forces have been digging defensive fortifications and trenches in preparation of a Ukrainian offensive.

## Saudi, Omani envoys in Yemen for peace talks with Houthi leaders
 - [https://www.aljazeera.com/news/2023/4/9/saudi-omani-envoys-in-yemen-for-peace-talks-with-houthi-leaders](https://www.aljazeera.com/news/2023/4/9/saudi-omani-envoys-in-yemen-for-peace-talks-with-houthi-leaders)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-09 16:16:46+00:00

The visit displays progress in the Oman-mediated dialogue between Saudi Arabia and Yemen&#039;s Houthi rebels.

## Israel rejects claims that Mossad backed nationwide protests
 - [https://www.aljazeera.com/news/2023/4/9/israel-rejects-claim-mossad-backed-judiciary-overhaul-protests](https://www.aljazeera.com/news/2023/4/9/israel-rejects-claim-mossad-backed-judiciary-overhaul-protests)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-09 15:20:09+00:00

Government denies claims in leaked documents that its intelligence service encouraged Israelis to join demonstrations.

## Tiger Woods withdraws from Augusta Masters due to injury
 - [https://www.aljazeera.com/sports/2023/4/9/tiger-woods-withdraws-from-augusta-masters-due-to-injury](https://www.aljazeera.com/sports/2023/4/9/tiger-woods-withdraws-from-augusta-masters-due-to-injury)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-09 13:04:16+00:00

Five-time champion announces withdrawal after playing through pain and limping through the third round a day earlier.

## Dozens evacuated as smoke from Hamburg fire halts trains
 - [https://www.aljazeera.com/news/2023/4/9/dozens-evacuated-as-smoke-from-hamburg-fire-halts-trains](https://www.aljazeera.com/news/2023/4/9/dozens-evacuated-as-smoke-from-hamburg-fire-halts-trains)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-09 12:34:23+00:00

Blaze engulfs toxic chemicals, sending black smoke over the German city, as residents warned to close their windows.

## Under Netanyahu, violence against Christians is being normalised
 - [https://www.aljazeera.com/features/2023/4/9/under-netanyahu-violence-against-christians-is-being-normalised](https://www.aljazeera.com/features/2023/4/9/under-netanyahu-violence-against-christians-is-being-normalised)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-09 11:24:32+00:00

Never have Israeli attackers felt more emboldened than under the new government, Christian leaders say.

## India’s Indigenous people pay price of tiger conservation
 - [https://www.aljazeera.com/news/2023/4/9/indias-indigenous-people-pay-price-of-tiger-conservation](https://www.aljazeera.com/news/2023/4/9/indias-indigenous-people-pay-price-of-tiger-conservation)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-09 11:17:53+00:00

Several Adivasi groups say the conservation strategies mean uprooting numerous communities from forests.

## India’s tiger population tops 3,000, survey finds
 - [https://www.aljazeera.com/news/2023/4/9/indias-tiger-population-tops-3000-survey-finds](https://www.aljazeera.com/news/2023/4/9/indias-tiger-population-tops-3000-survey-finds)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-09 11:16:23+00:00

Efforts to revive India&#039;s tiger population began 50 years ago over fears the big cats were going extinct.

## Adesanya gets ‘sweet revenge’ with knockout UFC win over Pereira
 - [https://www.aljazeera.com/sports/2023/4/9/mma-ufc-adesanya-knockout-win-over-pereira](https://www.aljazeera.com/sports/2023/4/9/mma-ufc-adesanya-knockout-win-over-pereira)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-09 10:51:30+00:00

Israel Adesanya reclaims middleweight championship from Alex Pereira at UFC 287 in Miami.

## Ukraine’s coal miners dig deep to power a nation at war
 - [https://www.aljazeera.com/gallery/2023/4/9/ukraines-coal-miners-dig-deep-to-power-a-nation-at-war](https://www.aljazeera.com/gallery/2023/4/9/ukraines-coal-miners-dig-deep-to-power-a-nation-at-war)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-09 10:11:54+00:00

Ukrainian miners work around the clock extracting coal to power the country&#039;s war effort.

## Q&A: Noam Chomsky on Palestine, Israel and the state of the world
 - [https://www.aljazeera.com/features/2023/4/9/qa-noam-chomsky-on-palestine-israel-and-the-state-of-the-world](https://www.aljazeera.com/features/2023/4/9/qa-noam-chomsky-on-palestine-israel-and-the-state-of-the-world)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-09 09:05:22+00:00

The renowned US academic also spoke to Al Jazeera about his career and positions he regrets not taking in the past.

## Russia-Ukraine war: List of key events, day 410
 - [https://www.aljazeera.com/news/2023/4/9/russia-ukraine-war-list-of-key-events-day-410](https://www.aljazeera.com/news/2023/4/9/russia-ukraine-war-list-of-key-events-day-410)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-09 08:46:59+00:00

As the Russia-Ukraine war enters its 410th day, we take a look at the main developments.

## How death and despair haunt Pakistan’s Christian minority
 - [https://www.aljazeera.com/features/2023/4/9/how-death-and-despair-haunt-pakistans-christian-minority](https://www.aljazeera.com/features/2023/4/9/how-death-and-despair-haunt-pakistans-christian-minority)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-09 08:23:48+00:00

Pakistan&#039;s Christians have long been marginalised and pushed into sewer cleaning work. Now, some are fighting back.

## The US should not worry about China-Gulf relations
 - [https://www.aljazeera.com/opinions/2023/4/9/the-us-should-not-worry-about-china-gulf-relations](https://www.aljazeera.com/opinions/2023/4/9/the-us-should-not-worry-about-china-gulf-relations)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-09 08:21:18+00:00

But it should be nervous about how close Israel has grown to Beijing.

## China simulates ‘strikes on targets in Taiwan’ as drills continue
 - [https://www.aljazeera.com/news/2023/4/9/china-simulates-strikes-on-targets-in-taiwan-as-drills-continue](https://www.aljazeera.com/news/2023/4/9/china-simulates-strikes-on-targets-in-taiwan-as-drills-continue)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-09 06:53:41+00:00

Taiwan&#039;s defence ministry says it spotted 70 Chinese aircraft and 11 warships on second day of drills around the island.

## The Deir Yassin massacre: Why it still matters 75 years later
 - [https://www.aljazeera.com/news/2023/4/9/the-deir-yassin-massacre-why-it-still-matters-75-years-later](https://www.aljazeera.com/news/2023/4/9/the-deir-yassin-massacre-why-it-still-matters-75-years-later)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-09 06:22:04+00:00

Brutal attacks by Zionist militias on Deir Yassin killed at least 107 Palestinians and made thousands flee other towns.

## Iraq demands Turkey apologise over attack on Sulaimaniyah airport
 - [https://www.aljazeera.com/news/2023/4/9/iraq-demands-turkey-apologise-over-attack-on-sulaymaniyah-airport](https://www.aljazeera.com/news/2023/4/9/iraq-demands-turkey-apologise-over-attack-on-sulaymaniyah-airport)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-09 05:00:15+00:00

SDF commander Mazloum Abdi says he was in a convoy with US troops at the Sulaimaniyah airport at time of attack.

## Saudi Arabia frees 13 Houthis as Oman tries to broker new truce
 - [https://www.aljazeera.com/news/2023/4/9/saudi-arabia-frees-13-houthis-as-oman-tries-to-broker-new-truce](https://www.aljazeera.com/news/2023/4/9/saudi-arabia-frees-13-houthis-as-oman-tries-to-broker-new-truce)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-09 03:28:52+00:00

Saudi Arabia, Houthis exchange prisoners as Omani officials arrive in Sanaa for talks to end Yemen&#039;s years-long war.

## Israel launches artillery attacks on Syria after rocket fire
 - [https://www.aljazeera.com/news/2023/4/9/israel-launches-artillery-attacks-on-syria-after-rocket-fire](https://www.aljazeera.com/news/2023/4/9/israel-launches-artillery-attacks-on-syria-after-rocket-fire)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-09 01:21:01+00:00

Israeli army says six rockets were fired from Syria towards Israel, one of which landed in the annexed Golan Heights.

