# Source:Mateusz Chrobok, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw, language:pl-PL

## Dziel i rządź swoim Internetem!
 - [https://www.youtube.com/watch?v=jK7y76OOKqs](https://www.youtube.com/watch?v=jK7y76OOKqs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw
 - date published: 2023-04-09 16:00:34+00:00

📺 Nigdy do końca nie wiemy co w niektórych urządzeniach niejako od siebie i w gratisie dodali ich projektanci. Jak można się przed szpiegowaniem w ten sposób przez różne odkurzacze, piloty i inne bronić? Można im po prostu odciąć całkowicie lub tylko częściowo dostęp do sieci. Porozmawiamy więc sobie dzisiaj trochę o tym, w jaki sposób wykonać segmentację logiczną Waszych urządzeń sieciowych. Oraz o tym, jak bezpiecznie wpuszczać gości do swojej sieci Wi-Fi.
 
Źródła:
✂️ Problem z urządzeniem Broadlink po odcięciu dostępu do Internetu
https://bit.ly/3Gh80Yg  &  https://bit.ly/2Scvuqy

🦘 Ktoś kradnie Twój Internet? Odwróć mu obrazy do góry nogami!
https://bit.ly/436yaXw

🎩 Hacking Layer 2: Fun with Ethernet Switches, S. Convery, Cisco Systems - Black Hat
https://bit.ly/40E4y2a

❔ Jak ustawić sieć gościa na routerach;
DLinka https://bit.ly/3nOhpjV
tp-linka https://bit.ly/41kVYFJ
Linksysa https://bit.ly/3zz7L7l

🔗 Źródło grafiki Broadlinka RM Mini 3, Komputronik
https://bit.ly/3GjBu7Q

🔗 Źródło zdjęcia szuflady z pilotami
https://bit.ly/438q0hh

🔗 Źródło zdjęcia plastra na kamerze
https://bit.ly/3ZKgzC3

🔗 Źródło zdjęcia naklejki na routerze z loginem i hasłem
https://bit.ly/3KzlukV
 
Jeżeli nie ufasz skracanym linkom (bardzo dobrze!) to dodaj na ich końcu plusik ‘+’.
W ten sposób podejrzysz na stronie bit.ly dokąd prowadzą.
 
Relevant xkcd: https://xkcd.com/341/
 
© Wszystkie znaki handlowe należą do ich prawowitych właścicieli.
❤️ Dziękuję za Waszą uwagę.
 
Znajdziecie mnie również na:
Instagramie @mateuszemsi https://www.instagram.com/mateuszemsi/ 
Twitterze @MateuszChrobok https://twitter.com/MateuszChrobok 
Mastodonie https://infosec.exchange/@mateuszchrobok 
LinkedInie @mateuszchrobok https://www.linkedin.com/in/mateuszchrobok/ 
Patronite @MateuszChrobok https://patronite.pl/MateuszChrobok
Podcasty na: 
Anchor https://anchor.fm/mateusz-chrobok 
Spotify https://open.spotify.com/show/6y6oWs20HwRejktOWHTteR 
Apple Podcasts https://apple.co/3OwjvOh
 
Rozdziały:
00:00 Intro
01:26 Pilot
04:05 WiFi
12:07 VLAN
14:50 Co Robić i Jak Żyć?
 
#WiFi #VLAN #Internet #Wi-Fi #cyberbezpieczeństwo

