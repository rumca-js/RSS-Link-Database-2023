# Source:NBC tech, URL:https://feeds.nbcnews.com/nbcnews/public/tech, language:en-US

## 'Our vote doesn’t matter': Black Tennessee residents frustrated over expulsion of legislators
 - [https://www.nbcnews.com/politics/politics-news/black-tennessee-residents-frustrated-expulsion-legislators-rcna78787](https://www.nbcnews.com/politics/politics-news/black-tennessee-residents-frustrated-expulsion-legislators-rcna78787)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2023-04-09 19:20:21+00:00

Democratic residents in the former districts of Justin Jones and Justin Pearson expressed outrage at Republicans for ousting the lawmakers they had voted for.

## Trump lawyer says there are no more classified documents at Mar-a-Lago
 - [https://www.nbcnews.com/politics/donald-trump/trump-lawyer-says-are-no-classified-docs-mar-lago-rcna78855](https://www.nbcnews.com/politics/donald-trump/trump-lawyer-says-are-no-classified-docs-mar-lago-rcna78855)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2023-04-09 18:36:31+00:00

Trump lawyer James Trusty said Sunday that there are no more classified documents at former President Donald Trump’s Mar-a-Lago residence in Florida.

## What does a 19th-century 'anti-vice' law have to do with the abortion pill ruling?
 - [https://www.nbcnews.com/news/crime-courts/19th-century-anti-law-abortion-pill-ruling-rcna78849](https://www.nbcnews.com/news/crime-courts/19th-century-anti-law-abortion-pill-ruling-rcna78849)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2023-04-09 15:51:46+00:00

A 19th century “anti-vice” law is at the center of a new court ruling that threatens access to the leading abortion drug in the U.S.

## Ousted Tennessee lawmakers say they felt targeted by GOP since Day 1
 - [https://www.nbcnews.com/politics/politics-news/ousted-tennessee-state-lawmakers-say-was-target-us-rcna78843](https://www.nbcnews.com/politics/politics-news/ousted-tennessee-state-lawmakers-say-was-target-us-rcna78843)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2023-04-09 15:30:08+00:00

The two Black Democrats who were ousted from the Tn. state House said that GOP legislators had "put a target" on their backs the day they entered the chambers.

## Tensions simmer in Jerusalem after Israel responds to rocket attacks with strikes on targets in Syria
 - [https://www.nbcnews.com/news/world/tensions-simmer-jerusalem-israel-responds-rocket-attacks-strikes-targe-rcna78829](https://www.nbcnews.com/news/world/tensions-simmer-jerusalem-israel-responds-rocket-attacks-strikes-targe-rcna78829)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2023-04-09 12:36:36+00:00

JERUSALEM — Israel's military said it struck targets in Syria Sunday after rare rocket fire from its northeastern neighbor as tensions simmered at a volatile Jerusalem shrine important to both Jewish and Muslim worshippers.

## Deadly bacteria linked to eyedrops has grown resistant to nearly all treatments, CDC says
 - [https://www.nbcnews.com/health/health-news/recalled-eyedrops-causing-blindness-know-drug-resistant-bacteria-rcna78541](https://www.nbcnews.com/health/health-news/recalled-eyedrops-causing-blindness-know-drug-resistant-bacteria-rcna78541)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2023-04-09 10:00:40+00:00

The bacteria linked to recalled eyedrops causing infection and blindness had never been seen in the U.S. until 2022, the CDC says Almost 70 infections have been linked to the recalled eyedrops in 16 states.

