# Source:Jake Tran, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ, language:en-US

## Local reporter BRUTALLY DESTROYS Chicago mayor in confrontation
 - [https://www.youtube.com/watch?v=V_-tSiBqmmg](https://www.youtube.com/watch?v=V_-tSiBqmmg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ
 - date published: 2023-04-09 15:00:18+00:00

✅ Buy our flagship masterclass ✅ Click here ➡️ https://evil.university/war 
😳 Learn the ONE SECRET that has made every giant corporation and government successful 
🤝 Make around $100 per referral! Click here ➡️ https://evil.university/war 

😈 Watch exclusive documentaries that are too controversial to ever be released to the public: https://jake.yt/join 
Updated refund policy: Email us within your first month of joining and we'll refund you for your first month. There is no refund if you cancel at a later time.

📹 Take a peak at all the private documentaries here: https://jake.yt/hidden-vids

📸 Follow me on IG: @jaketran // http://bit.ly/jt-ig
Please watch out for fake accounts. I will never message you asking for money or to invest. As of right now, it's spelled exactly like this: @jaketran

🎥 About this channel: We make free premium documentaries on money, power, and crime to expose how the world really works. Subscribe for more: https://jake.yt/watch-now

🍔 Subscribe to our other channel @EvilFoodSupply, where we expose all the evils of our modern diet ➡️ https://jake.yt/evilfood

Support this channel monetarily:
💻 𝗟𝗮𝗽𝘁𝗼𝗽 𝗟𝗶𝗳𝗲𝘀𝘁𝘆𝗹𝗲 𝗔𝗰𝗮𝗱𝗲𝗺𝘆: Learn exactly how I landed my $40/hr work from home job ($83k/yr) at 19 years old: https://jake.yt/LLAd
📜 The exact resume I used to get my $40/hr remote web dev job + a lot of bonuses: https://jake.yt/DRBd

🍿 OUR MOST VIRAL VIDEOS: 
Nestlé: The Most Evil Business in the World https://youtu.be/rj6JOKrL_vg
BlackRock: The Company that Owns the World https://youtu.be/1n4zkdfKUAE
Recycling is literally a scam https://youtu.be/LELvVUIz5pY
Why do Chinese Billionaires Keep Disappearing? https://youtu.be/qyMsrgI7-_s

✉️ Email me: jake@jaketran.io

📰 Sources & visuals: 

-----------------------

-----------------------

All materials in these videos are used for educational purposes and fall within the guidelines of fair use. No copyright infringement intended. If you are or represent the copyright owner of materials used in this video and have a problem with the use of said material, please send me an email, jake@jaketran.io, and we can sort it out.

Copyright © 2023 Transcend Visuals, LLC. All rights reserved.

DISCLAIMER:

This video does not provide investment or economic advice and is not professional advice (legal, accounting, tax).  The owner of this content is not an investment advisor.  Discussion of any securities, trading, or markets is incidental and solely for entertainment purposes.  Nothing herein shall constitute a recommendation, investment advice, or an opinion on suitability.  The information in this video is provided as of the date of its initial release.  The owner of this video expressly disclaims all representations or warranties of accuracy.  The owner of this video claims all intellectual property rights, including copyrights, of and related to, this video.

AFFILIATE DISCLOSURE: Some of the links in this video's description are affiliate links, meaning, at no additional cost to you, the owner may earn a commission if you click through, make a purchase, and/or opt-in.

## 9 warships and 71 jets ENCIRCLE TAIWAN 😳
 - [https://www.youtube.com/watch?v=7heS1F6xLsc](https://www.youtube.com/watch?v=7heS1F6xLsc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ
 - date published: 2023-04-09 08:11:09+00:00

✅ Buy our flagship masterclass ✅ Click here ➡️ https://evil.university/war 
😳 Learn the ONE SECRET that has made every giant corporation and government successful 
🤝 Make around $100 per referral! Click here ➡️ https://evil.university/war 

😈 Watch exclusive documentaries that are too controversial to ever be released to the public: https://jake.yt/join 
Updated refund policy: Email us within your first month of joining and we'll refund you for your first month. There is no refund if you cancel at a later time.

📹 Take a peak at all the private documentaries here: https://jake.yt/hidden-vids

📸 Follow me on IG: @jaketran // http://bit.ly/jt-ig
Please watch out for fake accounts. I will never message you asking for money or to invest. As of right now, it's spelled exactly like this: @jaketran

🎥 About this channel: We make free premium documentaries on money, power, and crime to expose how the world really works. Subscribe for more: https://jake.yt/watch-now

🍔 Subscribe to our other channel @EvilFoodSupply, where we expose all the evils of our modern diet ➡️ https://jake.yt/evilfood

Support this channel monetarily:
💻 𝗟𝗮𝗽𝘁𝗼𝗽 𝗟𝗶𝗳𝗲𝘀𝘁𝘆𝗹𝗲 𝗔𝗰𝗮𝗱𝗲𝗺𝘆: Learn exactly how I landed my $40/hr work from home job ($83k/yr) at 19 years old: https://jake.yt/LLAd
📜 The exact resume I used to get my $40/hr remote web dev job + a lot of bonuses: https://jake.yt/DRBd

🍿 OUR MOST VIRAL VIDEOS: 
Nestlé: The Most Evil Business in the World https://youtu.be/rj6JOKrL_vg
BlackRock: The Company that Owns the World https://youtu.be/1n4zkdfKUAE
Recycling is literally a scam https://youtu.be/LELvVUIz5pY
Why do Chinese Billionaires Keep Disappearing? https://youtu.be/qyMsrgI7-_s

✉️ Email me: jake@jaketran.io

📰 Sources & visuals: 

-----------------------

-----------------------

All materials in these videos are used for educational purposes and fall within the guidelines of fair use. No copyright infringement intended. If you are or represent the copyright owner of materials used in this video and have a problem with the use of said material, please send me an email, jake@jaketran.io, and we can sort it out.

Copyright © 2023 Transcend Visuals, LLC. All rights reserved.

DISCLAIMER:

This video does not provide investment or economic advice and is not professional advice (legal, accounting, tax).  The owner of this content is not an investment advisor.  Discussion of any securities, trading, or markets is incidental and solely for entertainment purposes.  Nothing herein shall constitute a recommendation, investment advice, or an opinion on suitability.  The information in this video is provided as of the date of its initial release.  The owner of this video expressly disclaims all representations or warranties of accuracy.  The owner of this video claims all intellectual property rights, including copyrights, of and related to, this video.

AFFILIATE DISCLOSURE: Some of the links in this video's description are affiliate links, meaning, at no additional cost to you, the owner may earn a commission if you click through, make a purchase, and/or opt-in.

## WW3 getting REAL CLOSE 💣
 - [https://www.youtube.com/watch?v=iYvCsV3791o](https://www.youtube.com/watch?v=iYvCsV3791o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ
 - date published: 2023-04-09 01:52:00+00:00

✅ Buy our flagship masterclass ✅ Click here ➡️ https://evil.university/war 
😳 Learn the ONE SECRET that has made every giant corporation and government successful 
🤝 Make around $100 per referral! Click here ➡️ https://evil.university/war 

😈 Watch exclusive documentaries that are too controversial to ever be released to the public: https://jake.yt/join 
Updated refund policy: Email us within your first month of joining and we'll refund you for your first month. There is no refund if you cancel at a later time.

📹 Take a peak at all the private documentaries here: https://jake.yt/hidden-vids

📸 Follow me on IG: @jaketran // http://bit.ly/jt-ig
Please watch out for fake accounts. I will never message you asking for money or to invest. As of right now, it's spelled exactly like this: @jaketran

🎥 About this channel: We make free premium documentaries on money, power, and crime to expose how the world really works. Subscribe for more: https://jake.yt/watch-now

🍔 Subscribe to our other channel @EvilFoodSupply, where we expose all the evils of our modern diet ➡️ https://jake.yt/evilfood

Support this channel monetarily:
💻 𝗟𝗮𝗽𝘁𝗼𝗽 𝗟𝗶𝗳𝗲𝘀𝘁𝘆𝗹𝗲 𝗔𝗰𝗮𝗱𝗲𝗺𝘆: Learn exactly how I landed my $40/hr work from home job ($83k/yr) at 19 years old: https://jake.yt/LLAd
📜 The exact resume I used to get my $40/hr remote web dev job + a lot of bonuses: https://jake.yt/DRBd

🍿 OUR MOST VIRAL VIDEOS: 
Nestlé: The Most Evil Business in the World https://youtu.be/rj6JOKrL_vg
BlackRock: The Company that Owns the World https://youtu.be/1n4zkdfKUAE
Recycling is literally a scam https://youtu.be/LELvVUIz5pY
Why do Chinese Billionaires Keep Disappearing? https://youtu.be/qyMsrgI7-_s

✉️ Email me: jake@jaketran.io

📰 Sources & visuals: 

-----------------------

-----------------------

All materials in these videos are used for educational purposes and fall within the guidelines of fair use. No copyright infringement intended. If you are or represent the copyright owner of materials used in this video and have a problem with the use of said material, please send me an email, jake@jaketran.io, and we can sort it out.

Copyright © 2023 Transcend Visuals, LLC. All rights reserved.

DISCLAIMER:

This video does not provide investment or economic advice and is not professional advice (legal, accounting, tax).  The owner of this content is not an investment advisor.  Discussion of any securities, trading, or markets is incidental and solely for entertainment purposes.  Nothing herein shall constitute a recommendation, investment advice, or an opinion on suitability.  The information in this video is provided as of the date of its initial release.  The owner of this video expressly disclaims all representations or warranties of accuracy.  The owner of this video claims all intellectual property rights, including copyrights, of and related to, this video.

AFFILIATE DISCLOSURE: Some of the links in this video's description are affiliate links, meaning, at no additional cost to you, the owner may earn a commission if you click through, make a purchase, and/or opt-in.

