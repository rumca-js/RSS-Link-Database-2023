# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Oh SH*T! NATO Expands! | Aaron Maté On What’s Next To Come…
 - [https://www.youtube.com/watch?v=GpI09cg8Fa4](https://www.youtube.com/watch?v=GpI09cg8Fa4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2023-04-09 17:00:18+00:00

Here's my conversation with Aaron Maté, who is independent journalist at the Grayzone. We spoke about Finland joining NATO, Trump, war in Ukraine & more! #trump #ukraine #war 
--------------------------------------------------------------------------------------------------------------------------
Get My New Stand Up Special 'Brandemic' NOW for a Limited Time Over on RUMBLE https://bit.ly/brandemic-rumble

OR 

Get Access Through My Community To Have It For Longer PLUS Extra Ad Free Content! https://bit.ly/brandemic-locals-trailer
--------------------------------------------------------------------------------------------------------------------------
WATCH me LIVE weekdays on Rumble: https://bit.ly/russellbrand-rumble
Join Russell Brand Connected over on Locals: https://bit.ly/russellbrand-connected-community
Come COMMUNITY 2023 - https://www.russellbrand.com/community-2023/
NEW MERCH! https://stuff.russellbrand.com/
Keep up to date, Join my mailing list - https://www.russellbrand.com/join-the-community/

