# Source:CNBC, URL:https://www.cnbc.com/id/100727362/device/rss/rss.html, language:en-US

## Russian travelers say they fear one question: ‘Where are you from?’
 - [https://www.cnbc.com/2023/04/10/russians-talk-about-how-travel-changed-after-the-ukraine-invasion.html](https://www.cnbc.com/2023/04/10/russians-talk-about-how-travel-changed-after-the-ukraine-invasion.html)
 - RSS feed: https://www.cnbc.com/id/100727362/device/rss/rss.html
 - date published: 2023-04-09 22:54:01+00:00

CNBC Travel spoke with Russians about how traveling has changed for them — including how they've been treated — since the outbreak of the war in Ukraine.

## Tesla to open a new Megafactory in Shanghai, China, company says
 - [https://www.cnbc.com/2023/04/09/tesla-to-open-a-new-megafactory-in-shanghai-china-company-says.html](https://www.cnbc.com/2023/04/09/tesla-to-open-a-new-megafactory-in-shanghai-china-company-says.html)
 - RSS feed: https://www.cnbc.com/id/100727362/device/rss/rss.html
 - date published: 2023-04-09 18:19:51+00:00

Tesla will open a new Megafactory in Shanghai, China, that is capable of producing 10,000 Megapacks a year.

## The top 3 countries where it’s easy to settle into a new life abroad, according to expats
 - [https://www.cnbc.com/2023/04/09/top-places-to-start-a-new-life-abroad-according-to-expats.html](https://www.cnbc.com/2023/04/09/top-places-to-start-a-new-life-abroad-according-to-expats.html)
 - RSS feed: https://www.cnbc.com/id/100727362/device/rss/rss.html
 - date published: 2023-04-09 14:00:02+00:00

Expats who've moved abroad rate how easy it is to settle in based on digital infrastructure, housing, access to administrative agencies and more.

