# Source:CNN World, URL:http://rss.cnn.com/rss/cnn_world.rss, language:en-US

## Up to 10 people trapped after building collapses in Marseille
 - [https://www.cnn.com/2023/04/09/europe/marseilles-france-building-collapse-intl/index.html](https://www.cnn.com/2023/04/09/europe/marseilles-france-building-collapse-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2023-04-09 15:35:41+00:00

Between four and 10 people are believed to be trapped under rubble in the southern French port city of Marseilles after a building collapsed early on Sunday, according to French authorities.

## This 73-year-old Ukrainian woman and her cat are some of the only ones left in a town east of Bakhmut
 - [https://www.cnn.com/2023/04/09/europe/ukraine-konstantinivka-fighting-elderly-intl/index.html](https://www.cnn.com/2023/04/09/europe/ukraine-konstantinivka-fighting-elderly-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2023-04-09 13:47:33+00:00

"God protects me," says 73-year-old Tamara. She's one of the few people who have stayed in the town of Konstantinivka, eastern Ukraine.

## Toxic fume warning after fire breaks out at Hamburg warehouse
 - [https://www.cnn.com/2023/04/09/europe/hamburg-warehouse-fire-intl/index.html](https://www.cnn.com/2023/04/09/europe/hamburg-warehouse-fire-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2023-04-09 12:35:56+00:00

Residents in the German city of Hamburg have been warned of heavy smoke and possible toxins in the air after a major fire broke out at a warehouse.

## At least 44 killed in Burkina Faso attacks
 - [https://www.cnn.com/2023/04/09/africa/burkina-faso-civilians-killed-intl/index.html](https://www.cnn.com/2023/04/09/africa/burkina-faso-civilians-killed-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2023-04-09 10:47:04+00:00

At least 44 civilians were killed in two separate attacks on villages in northern Burkina Faso, authorities there said.

