# Source:wiadomości.gazeta.pl, URL:http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm, language:pl-PL

## Nie żyje Maria Kiszczak. Żona Czesława Kiszczaka miała 89 lat
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29672070,nie-zyje-maria-kiszczak-zona-szefa-sluzb-komunistycznych-odeszla.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29672070,nie-zyje-maria-kiszczak-zona-szefa-sluzb-komunistycznych-odeszla.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-17 20:54:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/96/4c/1c/z29672086M,Czeslaw-i-Maria-Kiszczak.jpg" vspace="2" />Maria Kiszczak zmarła w poniedziałek 17 kwietnia w wieku 89 lat. Była żoną Czesława Kiszczaka, długoletniego szefa MSWiA w okresie PRL. Informację o jej śmierci przekazała córka Ewa.

## Śmierć żołnierza na terenie bazy w Radomiu. Prokuratura wszczęła dochodzenie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29672005,smierc-zolnierza-na-terenie-bazy-w-radomiu-prokuratura-wszczela.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29672005,smierc-zolnierza-na-terenie-bazy-w-radomiu-prokuratura-wszczela.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-17 19:45:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/50/bf/13/z20706128M,Wojsko--Zdjecie-ilustracyjne.jpg" vspace="2" />Trwa wyjaśnianie okoliczności śmierci żołnierza, którego ciało znaleziono w jednym z kontenerów mieszkalnych na terenie 42. Bazy Lotnictwa Szkolnego w Radomiu. Dochodzenie wszczął Wydział ds. Wojskowych Prokuratury Rejonowej Warszawa-Ursynów.

## Odliczyli do trzech i zaczęli mordować. Kamil poderżnął mamie gardło, Zuzanna walczyła z jego ojcem
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29625355,odliczyli-do-trzech-i-zaczeli-mordowac-kamil-poderznal-mamie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29625355,odliczyli-do-trzech-i-zaczeli-mordowac-kamil-poderznal-mamie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-17 17:03:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ba/41/1c/z29629370M,Kamil-N--i-Zuzanna-M---dom-w-Rakowiskach.jpg" vspace="2" />To miała być zbrodnia jak z amerykańskiego filmu. Kamil i Zuzanna zaplanowali każdy szczegół. Ubrali się nawet w stroje z "American Psycho", by nadać temu morderstwu większe znaczenie. Nie przewidzieli jednak, że rodzice będą walczyć o swoje życie i bronić się przed ciosami syna.

## Zmiany w kierownictwie CBA i ABW. Mateusz Morawiecki powołał dwóch nowych wiceszefów
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29671095,zmiany-w-kierownictwie-cba-i-abw-mateusz-morawiecki-powolal.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29671095,zmiany-w-kierownictwie-cba-i-abw-mateusz-morawiecki-powolal.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-17 16:32:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f1/4b/1c/z29671153M,Mateusz-Morawiecki.jpg" vspace="2" />Biuro Ministra Koordynatora Służb Specjalnych przekazało, że w poniedziałek Mateusz Morawiecki odwołał Bogdana Sakowicza z funkcji zastępcy szefa Centralnego Biura Antykorupcyjnego. Jego stanowisko zajmie teraz Marcin Stec. Premier powołał także Radosława Żebrowskiego na wiceszefa Agencji Bezpieczeństwa Wewnętrznego.

## Nie żyje mężczyzna, który podpalił się przed krakowskim konsulatem Ukrainy
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29671258,nie-zyje-mezczyzna-ktory-podpalil-sie-przed-krakowskim-konsulatem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29671258,nie-zyje-mezczyzna-ktory-podpalil-sie-przed-krakowskim-konsulatem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-17 15:13:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/5e/4b/1c/z29671262M.jpg" vspace="2" />63-letni obywatel Ukrainy podpalił się przed konsulatem generalnym Ukrainy w Krakowie w ubiegły czwartek. O śmierci mężczyzny poinformowała rzeczniczka szpitala, w którym był hospitalizowany.

## Tajemnica śmierci trzech mężczyzn i psa w Unisławiu rozwikłana. Są wyniki sekcji zwłok
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29670386,tajemnica-smierci-trzech-mezczyzn-i-psa-w-unislawiu-rozwiklana.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29670386,tajemnica-smierci-trzech-mezczyzn-i-psa-w-unislawiu-rozwiklana.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-17 12:55:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/3c/41/1c/z29627964M,Strazacy--zdjecie-ilustracyjne-.jpg" vspace="2" />Są wstępne wyniki sekcji zwłok trzech mężczyzn, których ciała znaleziono w domu jednorodzinnym w Unisławiu w województwie kujawsko-pomorskim. Urządzenia pomiarowe strażaków nie wykryły tlenku węgla w pomieszczeniach. Jednak pierwsze wyniki sekcji zwłok wskazują, że to właśnie zatrucie czadem spowodowało śmierć mężczyzn.

## Dolnośląskie. Atak nożownika w Legnicy. Zabił matkę i ranił jej córkę
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29670159,dolnoslaskie-atak-nozownika-w-legnicy-zabil-matke-i-ranil.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29670159,dolnoslaskie-atak-nozownika-w-legnicy-zabil-matke-i-ranil.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-17 12:18:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e5/4b/1c/z29670629M,Dolnoslaskie--Atak-nozownika-w-Legnicy--Zabil-matk.jpg" vspace="2" />Dramatyczne sceny w jednym z domów w Legnicy. Do środka wtargnął mężczyzna, który nożem zaatakował 37-letnią kobietę, ranił jej 14-letnią córkę, po czym uciekł. Kobieta zmarła przed przyjazdem na miejsce policji i pogotowia ratunkowego. Napastnika złapano, jeszcze w poniedziałek może usłyszeć zarzut zabójstwa.

## Majówka 2023. Pięć dni wolnych od pracy, nawet dziesięć od lekcji [HARMONOGRAM]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29669904,majowka-2023-piec-dni-wolnych-od-pracy-nawet-dziesiec-od-lekcji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29669904,majowka-2023-piec-dni-wolnych-od-pracy-nawet-dziesiec-od-lekcji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-17 12:13:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/2d/30/1c/z29559085M,Majowka--zdjecie-ilustracyjne-.jpg" vspace="2" />Majówka w tym roku rozpocznie się już 29 kwietnia. Tegoroczny kalendarz szczególnie korzystny jest dla uczniów niższych szkół średnich. Ich wolne może potrwać nawet dziesięć dni.

## Kaczyński składa zawiadomienie do prokuratury w sprawie katastrofy smoleńskiej. "Odleciał jak Antoni"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29669722,kaczynski-sklada-zawiadomienie-do-prokuratury-w-sprawie-katastrofy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29669722,kaczynski-sklada-zawiadomienie-do-prokuratury-w-sprawie-katastrofy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-17 12:06:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ea/4b/1c/z29669866M,Obchody-13--rocznicy-katastrofy-smolenskiej.jpg" vspace="2" />Prezes PiS Jarosław Kaczyński zapowiedział złożenie zawiadomienia do prokuratury o przestępstwie zamordowania prezydenta RP. Mowa tu o katastrofie smoleńskiej i śmierci Lecha Kaczyńskiego. "Nieustające danse macabre", "Prezes PiS się jeszcze nie natańczył na trumnach" - komentują politycy.

## Pogoda na kwiecień i maj. IMGW: Idzie fala ciepła. A w maju nawet 30 stopni C.
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29668491,pogoda-na-kwiecien-i-maj-imgw-idzie-fala-ciepla-a-w-maju.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29668491,pogoda-na-kwiecien-i-maj-imgw-idzie-fala-ciepla-a-w-maju.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-17 07:44:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/b8/4b/1c/z29668536M,Prognoza-dlugoterminowa-na-kwiecien-i-maj.jpg" vspace="2" />Kwiecień plecień wciąż przeplata. Najnowsze prognozy wskazują jednak na ocieplenie, a zbliżający się maj, zdaniem klimatologów, może przynieść nam temperaturę nawet 30 st. C. "Można już zmieniać opony na letnie" - radzą eksperci.

## Alert RCB dla Warszawy. Ćwiczenia antyterrorystyczne policji
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29668572,alert-rcb-dla-warszawy-cwiczenia-antyterrorystyczne-policji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29668572,alert-rcb-dla-warszawy-cwiczenia-antyterrorystyczne-policji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-17 06:25:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/15/4b/1c/z29668629M,Alert-RCB-dla-Warszawy--Cwiczenia-antyterrorystycz.jpg" vspace="2" />W poniedziałek w Warszawie zaplanowano ćwiczenia antyterrorystyczne. Rządowe Centrum Bezpieczeństwa ostrzega mieszkańców stolicy przed działaniami, wysyłając SMS-a z alertem. Trzeba przygotować się na utrudnienia w komunikacji i stosować się do poleceń służb.

## Kwalifikacja wojskowa rusza. Wezwanie dostanie blisko 230 tys. Polaków
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29668476,kwalifikacja-wojskowa-rusza-wezwanie-dostanie-blisko-230-tys.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29668476,kwalifikacja-wojskowa-rusza-wezwanie-dostanie-blisko-230-tys.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-17 06:04:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/01/e2/1b/z29238785M,Wojsko-Polskie--zdjecie-ilustracyjne-.jpg" vspace="2" />Kwalifikacja wojskowa ruszyła. Do 21 lipca przed komisjami w całym kraju stanie 230 tysięcy osób - dziewiętnastolatków zdolnych do podjęcia służby w armii w razie wybuchu wojny. Resort obrony przypomina, że jest to konstytucyjny obowiązek.

## Katastrofalne wyniki badania stanu psychicznego młodzieży. 40 proc. uczniów myślało o samobójstwie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29668386,katastrofalne-wyniki-badania-stanu-psychicznego-mlodziezy-40.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29668386,katastrofalne-wyniki-badania-stanu-psychicznego-mlodziezy-40.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-04-17 05:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/56/4b/1c/z29668438M,Mlode-glowy--Otwarcie-o-zdrowiu-psychicznym.jpg" vspace="2" />Fundacja UNAWEZA w ramach projektu Młode Głowy opublikowała raport z badania dotyczącego m.in. tanu psychicznego dzieci i młodzieży w wieku 10-19 lat. To pierwsze tego typu badanie na taką skalę, udział w nim wzięło ponad 180 tys. uczniów z całej Polski. Wnioski z raportu są dramatyczne - prawie połowa uczniów ma skrajnie niską samoocenę, stres dnia codziennego przerasta ponad 80 proc. badanych, co trzecie dziecko nie ma chęci do życia, a 8,8 proc. dzieci w Polsce deklaruje, że podjęło próbę samobójczą.

