# Source:Luetin09, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC8RfCCzWsMgNspTI-GTFenQ, language:en-US

## 40K - I DID NOT WANT TO MAKE THIS VIDEO | Warhammer 40,000 News / Minis
 - [https://www.youtube.com/watch?v=aSsKoJ0u27o](https://www.youtube.com/watch?v=aSsKoJ0u27o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC8RfCCzWsMgNspTI-GTFenQ
 - date published: 2023-04-17 00:58:43+00:00

► Subscribe: http://goo.gl/oeZMBS 
► Siege Studios: https://siegestudios.co.uk/
► Crystal Fortress Premium Storage: http://bit.ly/3oFuDf7
► Patreon: https://www.patreon.com/Luetin 
► Twitch: http://www.twitch.tv/Luetin
► Twitter: http://twitter.com/luetin09

Timestamps:
0:00 General Issue Overview
5:59 Website problems
8:07 Price subjective value
9:33 Price - game systems
10:27 FOMO Limited Books
14:04 Mini Stock - Shortages
16:28 Box Sets - Production
19:00 Production Strategy?
21:00 Too little too late?
22:26 New Distribution center
24:01 Website traffic - stability
26:47 Solutions for Limited Items
28:32 10th Edition Concerns
32:36 Community Comments
40:02 The Experience
41:37 Final Thoughts

► BGM Credits:
► Kevin MacLeod (Royalty Free Music): http://incompetech.com/music/
► https://epidemicsound.com

This video is an opinion editorial commentary.
Copyright Disclaimer Under Section 107 of the Copyright Act 1976, allowance is made for fair use purposes such as criticism, commentary, parody, news reporting, teaching, scholarship, and research.

All works used in this video (Images, audio etc) belong to their respective authors
(This does not include the audio commentary or licensed BGM).

Games workshop, Warhammer 40,000, Warhammer, 40k, Space Marine Etc are all Trademarks of Games Workshop Ltd. Games Workshop does not endorse or support the 'Lore' videos. All views and opinions expressed in this video belong to Luetin09 and in no way reflect the views or opinions of Games Workshop Ltd.

