# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## Harry Potter: Quidditch Champions. Nowa gra z popularnego uniwersum zapowiedziana
 - [https://ithardware.pl/aktualnosci/harry_potter_quidditch_champions_nowa_gra_z_popularnego_uniwersum_zapowiedziana-26847.html](https://ithardware.pl/aktualnosci/harry_potter_quidditch_champions_nowa_gra_z_popularnego_uniwersum_zapowiedziana-26847.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-17 20:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/26847_1.jpg" />            O Harrym Potterze zn&oacute;w jest głośno, najpierw za sprawą udanego Hogwarts Legacy, a ostatnio za sprawą serialu opowiadającego o losach młodego czarodzieja oraz jego przyjaci&oacute;ł. Teraz z kolei przyszła pora na kolejną grę osadzoną w...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/harry_potter_quidditch_champions_nowa_gra_z_popularnego_uniwersum_zapowiedziana-26847.html">https://ithardware.pl/aktualnosci/harry_potter_quidditch_champions_nowa_gra_z_popularnego_uniwersum_zapowiedziana-26847.html</a></p>

## Blizzard usprawnia Diablo 4. Twórcy wyciągają wnioski po becie i prezentują dużą listę poprawek
 - [https://ithardware.pl/aktualnosci/blizzard_usprawnia_diablo_4_tworcy_wyciagaja_wnioski_po_becie_i_prezentuja_duza_liste_poprawek-26846.html](https://ithardware.pl/aktualnosci/blizzard_usprawnia_diablo_4_tworcy_wyciagaja_wnioski_po_becie_i_prezentuja_duza_liste_poprawek-26846.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-17 18:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/26846_1.jpg" />            Beta Diablo 4 przyciągnęła wielu graczy, a Blizzardowi pomogła wyłapać błędy i rzeczy wymagające usprawnienia, kt&oacute;re zostaną wprowadzone w finalnej wersji gry w czerwcu. Studio ujawniło czego należy się spodziewać.

Beta Diablo 4...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/blizzard_usprawnia_diablo_4_tworcy_wyciagaja_wnioski_po_becie_i_prezentuja_duza_liste_poprawek-26846.html">https://ithardware.pl/aktualnosci/blizzard_usprawnia_diablo_4_tworcy_wyciagaja_wnioski_po_becie_i_prezentuja_duza_liste_poprawek-26846.html</a></p>

## Steam zbanował graczy za negatywną recenzję? Valve wyjaśnia sprawę
 - [https://ithardware.pl/aktualnosci/steam_zbanowal_graczy_za_negatywna_recenzje_valve_wyjasnia_sprawe-26845.html](https://ithardware.pl/aktualnosci/steam_zbanowal_graczy_za_negatywna_recenzje_valve_wyjasnia_sprawe-26845.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-17 15:48:35+00:00

<img src="https://ithardware.pl/artykuly/min/26845_1.jpg" />            Recenzje na Steam są bardzo pomocne i mogą wpłynąć na decyzję o zakupie danej gry. Dotychczas byliśmy świadkami wykorzystywania tego mechanizmu przez graczy obrażonych na wydawc&oacute;w i celowo zaniżających oceny np. taki los spotkał serię...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/steam_zbanowal_graczy_za_negatywna_recenzje_valve_wyjasnia_sprawe-26845.html">https://ithardware.pl/aktualnosci/steam_zbanowal_graczy_za_negatywna_recenzje_valve_wyjasnia_sprawe-26845.html</a></p>

## LipIO to kontroler, który obsługiwany jest językiem
 - [https://ithardware.pl/aktualnosci/lipio_to_kontroler_ktory_obslugiwany_jest_jezykiem-26835.html](https://ithardware.pl/aktualnosci/lipio_to_kontroler_ktory_obslugiwany_jest_jezykiem-26835.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-17 15:23:01+00:00

<img src="https://ithardware.pl/artykuly/min/26835_1.jpg" />            Naukowcy z University of Chicago zaprezentowali alternatywny interfejs użytkownika o nazwie LipIO, kt&oacute;ry odbiera i przesyła informacje cyfrowe za pomocą niewielkich ruch&oacute;w ust i języka. Jest to oczywiście rozwiązanie skierowane do...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/lipio_to_kontroler_ktory_obslugiwany_jest_jezykiem-26835.html">https://ithardware.pl/aktualnosci/lipio_to_kontroler_ktory_obslugiwany_jest_jezykiem-26835.html</a></p>

## Sega przejmuje autorów gry, w którą zagrywało się wielu graczy
 - [https://ithardware.pl/aktualnosci/sega_przejmuje_autorow_gry_w_ktora_zagrywalo_sie_wielu_graczy-26844.html](https://ithardware.pl/aktualnosci/sega_przejmuje_autorow_gry_w_ktora_zagrywalo_sie_wielu_graczy-26844.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-17 15:20:00+00:00

<img src="https://ithardware.pl/artykuly/min/26844_1.jpg" />            W ostatnim czasie pojawiły się spekulacje jakoby Sega zamierzała przejąć tw&oacute;rc&oacute;w bardzo popularnej niegdyś gry&nbsp;Angry Birds. Plotki znalazły pokrycie w rzeczywistości, a studio&nbsp;Rovio ma nowego właściciela.

Rovio jest...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/sega_przejmuje_autorow_gry_w_ktora_zagrywalo_sie_wielu_graczy-26844.html">https://ithardware.pl/aktualnosci/sega_przejmuje_autorow_gry_w_ktora_zagrywalo_sie_wielu_graczy-26844.html</a></p>

## AMD EPYC 9684X - zobaczcie 96-rdzeniowy procesor z ponad 1 GB pamięci cache
 - [https://ithardware.pl/aktualnosci/amd_epyc_9684x_zobaczcie_96_rdzeniowy_procesor_z_ponad_1_gb_pamieci_cache-26834.html](https://ithardware.pl/aktualnosci/amd_epyc_9684x_zobaczcie_96_rdzeniowy_procesor_z_ponad_1_gb_pamieci_cache-26834.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-17 14:57:01+00:00

<img src="https://ithardware.pl/artykuly/min/26834_1.jpg" />            Pierwsza pr&oacute;bka inżynieryjna masywnego procesora AMD Genoa-X, EPYC 9684X, została zauważona u chińskiego sprzedawcy (Goofish). To CPU oferuje 96 rdzeni Zen 4 i aż 1152 MB pamięci podręcznej.

EPYC 9684X w sprzedaży w Chinach

Chociaż...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/amd_epyc_9684x_zobaczcie_96_rdzeniowy_procesor_z_ponad_1_gb_pamieci_cache-26834.html">https://ithardware.pl/aktualnosci/amd_epyc_9684x_zobaczcie_96_rdzeniowy_procesor_z_ponad_1_gb_pamieci_cache-26834.html</a></p>

## Sprytnie ukryty AirTag pozowlił policji szybko namierzyć skradziony samochód
 - [https://ithardware.pl/aktualnosci/sprytnie_ukryty_airtag_pozowlil_policji_szybko_namierzyc_skradziony_samochod-26836.html](https://ithardware.pl/aktualnosci/sprytnie_ukryty_airtag_pozowlil_policji_szybko_namierzyc_skradziony_samochod-26836.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-17 14:25:50+00:00

<img src="https://ithardware.pl/artykuly/min/26836_1.jpg" />            Trackery pokroju AirTag&oacute;w od Apple potrafią być bardzo przydatne, szczeg&oacute;lnie w przypadku zgubienia naszych rzeczy (np. walizek przez linie lotnicze), ale też ich kradzieży, czego świetnym przykładem jest opisywana dalej sytuacja....
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/sprytnie_ukryty_airtag_pozowlil_policji_szybko_namierzyc_skradziony_samochod-26836.html">https://ithardware.pl/aktualnosci/sprytnie_ukryty_airtag_pozowlil_policji_szybko_namierzyc_skradziony_samochod-26836.html</a></p>

## Premiera wentylatora Genesis Oxal 120
 - [https://ithardware.pl/aktualnosci/premiera_wentylatora_genesis_oxal_120-26843.html](https://ithardware.pl/aktualnosci/premiera_wentylatora_genesis_oxal_120-26843.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-17 14:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/26843_1.jpg" />            Genesis Oxal 120 to nowy wentylator, kt&oacute;rego przygotowano go z myślą o standardowych obudowach, ale i wyposażonych w zagęszczone filtry, kt&oacute;rych gł&oacute;wnym zadaniem jest ograniczenie ilości pyłu dostającego się do...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/premiera_wentylatora_genesis_oxal_120-26843.html">https://ithardware.pl/aktualnosci/premiera_wentylatora_genesis_oxal_120-26843.html</a></p>

## Gigabyte Aero 16 (2023) - test laptopa dla kreatywnych. Core i9-13900H + GeForce RTX 4070
 - [https://ithardware.pl/testyirecenzje/gigabyte_aero_16_2023_test_laptopa_dla_kreatywnych_core_i9_13900h_geforce_rtx_4070-26839.html](https://ithardware.pl/testyirecenzje/gigabyte_aero_16_2023_test_laptopa_dla_kreatywnych_core_i9_13900h_geforce_rtx_4070-26839.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-17 13:30:20+00:00

<img src="https://ithardware.pl/artykuly/min/26839_1.jpg" />            Gigabyte Aero 16 (2023) - test laptopa dla kreatywnych.&nbsp;Core i9-13900H +&nbsp;GeForce RTX 4070

Gigabyte kontynuuje ekspansję na rynku laptop&oacute;w i podobnie jak konkurenci wprowadziło do sprzedaży modele napędzane nową generacją CPU i...
            <p>Pełna wersja strony <a href="https://ithardware.pl/testyirecenzje/gigabyte_aero_16_2023_test_laptopa_dla_kreatywnych_core_i9_13900h_geforce_rtx_4070-26839.html">https://ithardware.pl/testyirecenzje/gigabyte_aero_16_2023_test_laptopa_dla_kreatywnych_core_i9_13900h_geforce_rtx_4070-26839.html</a></p>

## Alarm w Google. Samsung chce zmienić wyszukiwarkę na Bing od Microsoftu
 - [https://ithardware.pl/aktualnosci/alarm_w_google_samsung_chce_sie_dogadac_z_microsoftem-26842.html](https://ithardware.pl/aktualnosci/alarm_w_google_samsung_chce_sie_dogadac_z_microsoftem-26842.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-17 12:15:30+00:00

<img src="https://ithardware.pl/artykuly/min/26842_1.jpg" />            Choć jeszcze niedawno dla większości os&oacute;b to Google było niemalże synonimem wyszukiwania w internecie, to&nbsp;ChatGPT i intensywne prace nad wyszukiwarką Bing sprawiły, że Microsoft zaczyna nadrabiać zaległości.

Bing może...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/alarm_w_google_samsung_chce_sie_dogadac_z_microsoftem-26842.html">https://ithardware.pl/aktualnosci/alarm_w_google_samsung_chce_sie_dogadac_z_microsoftem-26842.html</a></p>

## Miało być kryptowalutowe eldorado. Wykorzystanie Bitcoina w Salwadorze leci na łeb...
 - [https://ithardware.pl/aktualnosci/mialo_byc_kryptowalutowe_eldorado_wykorzystanie_bitcoina_w_salwadorze_leci_na_leb-26841.html](https://ithardware.pl/aktualnosci/mialo_byc_kryptowalutowe_eldorado_wykorzystanie_bitcoina_w_salwadorze_leci_na_leb-26841.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-17 11:35:50+00:00

<img src="https://ithardware.pl/artykuly/min/26841_1.jpg" />            Salwador, kt&oacute;ry został skrytykowany przez Międzynarodowy Fundusz Walutowy za legalizację Bitcoina jako opcji płatności, doświadcza spadku wykorzystania kryptowaluty.

Gospodarka kraju, kt&oacute;ra w dużej mierze opiera się na dochodach...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/mialo_byc_kryptowalutowe_eldorado_wykorzystanie_bitcoina_w_salwadorze_leci_na_leb-26841.html">https://ithardware.pl/aktualnosci/mialo_byc_kryptowalutowe_eldorado_wykorzystanie_bitcoina_w_salwadorze_leci_na_leb-26841.html</a></p>

## BYD Dolphin trafi do Europy. Hatchback może namieszać kategorii tańszych elektryków
 - [https://ithardware.pl/aktualnosci/byd_dolphin_trafi_do_europy_hatchback_moze_namieszac_kategorii_tanszych_elektrykow-26840.html](https://ithardware.pl/aktualnosci/byd_dolphin_trafi_do_europy_hatchback_moze_namieszac_kategorii_tanszych_elektrykow-26840.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-17 10:52:20+00:00

<img src="https://ithardware.pl/artykuly/min/26840_1.jpg" />            Hatchback BYD Dolphin ma ogromny potencjał, aby stać się najpopularniejszym modelem elektrycznym chińskiego producenta samochod&oacute;w w Europie. Model ten w tym roku wejdzie na gł&oacute;wne rynki zagraniczne w cenie początkowej około 33 000...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/byd_dolphin_trafi_do_europy_hatchback_moze_namieszac_kategorii_tanszych_elektrykow-26840.html">https://ithardware.pl/aktualnosci/byd_dolphin_trafi_do_europy_hatchback_moze_namieszac_kategorii_tanszych_elektrykow-26840.html</a></p>

## Duża firma już zastępuje pracowników generatywną sztuczną inteligencją
 - [https://ithardware.pl/aktualnosci/duza_firma_juz_zastepuje_pracownikow_generatywna_sztuczna_inteligencja-26833.html](https://ithardware.pl/aktualnosci/duza_firma_juz_zastepuje_pracownikow_generatywna_sztuczna_inteligencja-26833.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-17 09:19:10+00:00

<img src="https://ithardware.pl/artykuly/min/26833_1.jpg" />            Obawy, że generatywne AI mogą zastąpić nasze miejsca pracy, stały się rzeczywistością w jednej z największych chińskich firm medialnych i public relations. Bluefocus Intelligent Communications Group Co. planuje zastąpić swoich zewnętrznych...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/duza_firma_juz_zastepuje_pracownikow_generatywna_sztuczna_inteligencja-26833.html">https://ithardware.pl/aktualnosci/duza_firma_juz_zastepuje_pracownikow_generatywna_sztuczna_inteligencja-26833.html</a></p>

## Czechy: Wyłączyli elektrownię fotowoltaiczną. Wytworzyła więcej energii, niż mogła obsłużyć sieć
 - [https://ithardware.pl/aktualnosci/czeska_firma_zamyka_elektrownie_fotowoltaiczna_wytworzyla_wiecej_energii_niz_mogla_obsluzyc_siec-26838.html](https://ithardware.pl/aktualnosci/czeska_firma_zamyka_elektrownie_fotowoltaiczna_wytworzyla_wiecej_energii_niz_mogla_obsluzyc_siec-26838.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-17 09:15:50+00:00

<img src="https://ithardware.pl/artykuly/min/26838_1.jpg" />            Podobno nie można mieć zbyt wiele dobrego, ale jak się okazuje, czasem stwarza to spore problemy, zwłaszcza bez odpowiednio przygotowanego zaplecza, o czym przekonała się czeska firma energetyczna. W Poniedziałek Wielkanocny została ona zmuszona...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/czeska_firma_zamyka_elektrownie_fotowoltaiczna_wytworzyla_wiecej_energii_niz_mogla_obsluzyc_siec-26838.html">https://ithardware.pl/aktualnosci/czeska_firma_zamyka_elektrownie_fotowoltaiczna_wytworzyla_wiecej_energii_niz_mogla_obsluzyc_siec-26838.html</a></p>

## NVIDIA podobno ogranicza produkcję kart RTX 4000. Nie chce spadku cen poprzedniej generacji
 - [https://ithardware.pl/aktualnosci/nvidia_podobno_ogranicza_produkcje_kart_rtx_4000_nie_chce_spadku_cen_poprzedniej_generacji-26837.html](https://ithardware.pl/aktualnosci/nvidia_podobno_ogranicza_produkcje_kart_rtx_4000_nie_chce_spadku_cen_poprzedniej_generacji-26837.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-17 08:53:20+00:00

<img src="https://ithardware.pl/artykuly/min/26837_1.jpg" />            Nvidia wprowadziła niedawno na rynek sw&oacute;j nieco tańszy&nbsp;model RTX 4070, ale jak donoszą media i sami użytkownicy, pojawiają się trudności z odnalezieniem sklep&oacute;w, kt&oacute;re faktycznie mają towar na stanie. Sytuacja powoduje,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nvidia_podobno_ogranicza_produkcje_kart_rtx_4000_nie_chce_spadku_cen_poprzedniej_generacji-26837.html">https://ithardware.pl/aktualnosci/nvidia_podobno_ogranicza_produkcje_kart_rtx_4000_nie_chce_spadku_cen_poprzedniej_generacji-26837.html</a></p>

## Radeon RX 6800 mocno potaniał. GeForce RTX 4070 nie wypada już tak korzystnie
 - [https://ithardware.pl/aktualnosci/radeon_rx_6800_mocno_potanial_geforce_rtx_4070_nie_wypada_juz_tak_korzystnie-26832.html](https://ithardware.pl/aktualnosci/radeon_rx_6800_mocno_potanial_geforce_rtx_4070_nie_wypada_juz_tak_korzystnie-26832.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-17 08:51:20+00:00

<img src="https://ithardware.pl/artykuly/min/26832_1.jpg" />            Zdaje się, że AMD i jej partnerzy obniżyli ceny kart graficznych Radeon RX 6800, dzięki czemu temu są znacznie bardziej konkurencyjne w zestawieniu ze świeżynką NVIDII, czyli GeForcem RTX 4070.&nbsp;

Radeon RX 6800&nbsp;już od&nbsp;2369...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/radeon_rx_6800_mocno_potanial_geforce_rtx_4070_nie_wypada_juz_tak_korzystnie-26832.html">https://ithardware.pl/aktualnosci/radeon_rx_6800_mocno_potanial_geforce_rtx_4070_nie_wypada_juz_tak_korzystnie-26832.html</a></p>

## GeForce RTX 4060 Ti - przecieki ujawniają szczegóły specyfikacji
 - [https://ithardware.pl/aktualnosci/geforce_rtx_4060_ti_przecieki_ujawniaja_szczegoly_specyfikacji-26831.html](https://ithardware.pl/aktualnosci/geforce_rtx_4060_ti_przecieki_ujawniaja_szczegoly_specyfikacji-26831.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-17 07:02:30+00:00

<img src="https://ithardware.pl/artykuly/min/26831_1.jpg" />            Wiele wskazuje na to, że po premierze GeForce'a RTX 4070 w zeszłym tygodniu (sprawdź naszą recenzję modelu Founders Edition i autorskiego modelu Gigabyte), kolejną kartą NVIDII z rodziny Ada Lovelace będzie GeForce RTX 4060 Ti. Do sieci...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/geforce_rtx_4060_ti_przecieki_ujawniaja_szczegoly_specyfikacji-26831.html">https://ithardware.pl/aktualnosci/geforce_rtx_4060_ti_przecieki_ujawniaja_szczegoly_specyfikacji-26831.html</a></p>

## Szczoteczka soniczna Xiaomi Nandme NX 7000 od teraz 50% taniej!
 - [https://ithardware.pl/aktualnosci/szczoteczka_soniczna_xiaomi_nandme_nx_7000_od_teraz_50_taniej-26830.html](https://ithardware.pl/aktualnosci/szczoteczka_soniczna_xiaomi_nandme_nx_7000_od_teraz_50_taniej-26830.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-17 06:41:10+00:00

<img src="https://ithardware.pl/artykuly/min/26830_1.jpg" />            Szczoteczki soniczne są niczym autonomiczne roboty sprzątające. Coraz częściej pojawiają się w naszych domach. W sumie wcale się nie dziwimy, ponieważ bezpośrednio przyczyniając się do poprawy higieny osobistej, gwarantują zdrowe i białe...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/szczoteczka_soniczna_xiaomi_nandme_nx_7000_od_teraz_50_taniej-26830.html">https://ithardware.pl/aktualnosci/szczoteczka_soniczna_xiaomi_nandme_nx_7000_od_teraz_50_taniej-26830.html</a></p>

## Google podobno szykuje całkowicie nową wyszukiwarkę napędzaną AI
 - [https://ithardware.pl/aktualnosci/google_podobno_szykuje_calkowicie_nowa_wyszukiwarke_napedzana_ai-26829.html](https://ithardware.pl/aktualnosci/google_podobno_szykuje_calkowicie_nowa_wyszukiwarke_napedzana_ai-26829.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-04-17 06:14:33+00:00

<img src="https://ithardware.pl/artykuly/min/26829_1.jpg" />            W obliczu wsp&oacute;łpracy Microsoftu i OpenAI, Google podobno &bdquo;spieszy się&rdquo;, aby stworzyć &bdquo;całkowicie nową&rdquo; wyszukiwarkę opartą na sztucznej inteligencji. Według The New York Times firma jest na wczesnym etapie tworzenia...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/google_podobno_szykuje_calkowicie_nowa_wyszukiwarke_napedzana_ai-26829.html">https://ithardware.pl/aktualnosci/google_podobno_szykuje_calkowicie_nowa_wyszukiwarke_napedzana_ai-26829.html</a></p>

