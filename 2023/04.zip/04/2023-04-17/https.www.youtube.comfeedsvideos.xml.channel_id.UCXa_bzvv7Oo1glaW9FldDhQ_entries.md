# Source:GamingBolt, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXa_bzvv7Oo1glaW9FldDhQ, language:en-US

## Star Wars Jedi: Survivor - All Confirmed And Potential Characters
 - [https://www.youtube.com/watch?v=6j0nvSXAuVk](https://www.youtube.com/watch?v=6j0nvSXAuVk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXa_bzvv7Oo1glaW9FldDhQ
 - date published: 2023-04-17 15:30:02+00:00

Star Wars Jedi: Survivor is one of the more anticipated sequels in the Star Wars franchise in a long time. Cal Kestis returns five years later, still battling the Empire alongside old friends and new ones. We know some characters that appear, but what about the newcomers? 

Who could potentially appear based on everything we know about the franchise? Let's take a closer look ahead of its launch on April 28th for Xbox Series X/S, PS5 and PC.

## Final Fantasy 16 - 10 MORE NEW Things You NEED TO KNOW
 - [https://www.youtube.com/watch?v=-HXBky9YB3o](https://www.youtube.com/watch?v=-HXBky9YB3o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXa_bzvv7Oo1glaW9FldDhQ
 - date published: 2023-04-17 13:30:00+00:00

The developer has already shown off quite a bit of Final Fantasy 16 over the last couple of months, but clearly, it's not even close to being done yet. Recently, Sony premiered a State of Play presentation dedicated entirely to the highly anticipated action RPG, and showcased over 20 minutes of new gameplay footage. 

A lot of what we got to see expanded further on mechanics and features that have been previously confirmed, fleshed out further with additional gameplay and a flood of gameplay footage. Here, we're going to parse through some of the most crucial new details that were revealed.

## EA Sports PGA Tour Review - The Final Verdict
 - [https://www.youtube.com/watch?v=8O58H3h9TUc](https://www.youtube.com/watch?v=8O58H3h9TUc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXa_bzvv7Oo1glaW9FldDhQ
 - date published: 2023-04-17 12:15:00+00:00

EA Sports PGA Tour is probably the best golf game on the market right now, though that might not be as bold of a statement as it sounds. With the exception of a few important players and courses, this return to golf for EA provides virtually everything you would want in a golf sports game in 2023, including some of the greatest courses and best players in the world, as well as a chance to play alongside them in a career. 

The updated gameplay system works great the majority of the time, and it feels like a step forward in golf gameplay, especially compared to EA’s past golf games. Knowing that there are now two PGA Tour licensed games on the market, you’re not going to see enormous differences between the two, but if you’re looking for a golf game to play and haven’t picked one up in a while, EA Sports PGA Tour will do just fine.

