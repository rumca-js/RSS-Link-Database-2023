# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## The Super Mario Bros. Movie - A Game Changer
 - [https://www.youtube.com/watch?v=pw-THtE42aM](https://www.youtube.com/watch?v=pw-THtE42aM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2023-04-17 17:00:33+00:00

Mario Bros. The Movie is poised to be the first videogame adaptation to hit over $1 Billion, at a time when Star Wars and superhero movies are struggling. Let's find out why its been so successful.

