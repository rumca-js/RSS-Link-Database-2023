# Source:Vlog Casha, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLsnJt_eyqkGZ4ZEM__xCOg, language:en-US

## KOREA POŁUDNIOWA - PIERWSZE WRAŻENIA
 - [https://www.youtube.com/watch?v=6_8tYWe5lng](https://www.youtube.com/watch?v=6_8tYWe5lng)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLsnJt_eyqkGZ4ZEM__xCOg
 - date published: 2023-04-17 15:00:04+00:00

🗺️ Korea Południowa #1. Pierwszy vlog z Korei Południowej. Spędzimy go w stolicy tego kraju, czyli w Seulu. Standardowo - pokręcimy się bez celu po mieście :)

Jeśli nie jesteś jeszcze klientem mBanku, sprawdź konto i moje cele w promocji: https://www.mbank.pl/cash
Jeśli jesteś klientem mBanku, sprawdź jakie są warunki moich celów na 8%: https://www.mbank.pl/indywidualny/inwestycje-i-oszczednosci/regularne-odkladanie/cele-promocja/?kampania=cash

❗ Zostań Patronem kanału!
https://patronite.pl/vlogcasha

Instagram Mateusza: https://www.instagram.com/mateuszg94/

Playlisty filmów z moich podróży:
Kambodża (2022): http://bit.ly/3mVA9xv
Indie (2022): http://bit.ly/3viDgAg
USA (2022): https://bit.ly/3uGVdbd
Kuba (2021): https://bit.ly/3dhLIqK
USA (2021): https://bit.ly/35J0zKd
Meksyk (2021): http://bit.ly/3c7Jycf
Turcja (2019-2020): https://bit.ly/31VPCR3
Kolumbia (2020): https://bit.ly/36tqlhH
Tajlandia, Laos, Wietnam (2019): https://bit.ly/2wrM9t2
Australia (2018): https://bit.ly/2OJWYOy
USA (2017): https://bit.ly/2ya73NV
Autostop (2018): https://bit.ly/2NbHzos

Mój sprzęt:
Aparat/Obiektywy: Sony A7IV / FE 16-35mm F2.8 / FE 24-105mm F4
Plecak zielony: https://bit.ly/3y9cX1Y
Dron: http://bit.ly/3Lpih8t

(Linki afiliacyjne. Jeśli dokonacie zakupów po wejściu w mój link, otrzymam prowizję za polecenie.)

Muzyka z vloga pochodzi z serwisu Artlist. Skorzystaj z mojej promocji i odbierz 2 miesiące gratis!
Artlist: https://bit.ly/3mWjQwo

▸ Instagram: https://www.instagram.com/vlogcasha
▸ Facebook: https://www.facebook.com/vlogcasha/

#PodróżeCasha #Korea

