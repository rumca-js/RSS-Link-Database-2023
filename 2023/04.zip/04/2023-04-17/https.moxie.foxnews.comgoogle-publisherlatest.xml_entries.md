# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## 2024 Lincoln Nautilus SUV has giant dashboard screen  you can't unsee
 - [https://www.foxnews.com/auto/lincoln-nautilus-suv-giant-dashboard-screen](https://www.foxnews.com/auto/lincoln-nautilus-suv-giant-dashboard-screen)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 19:52:45+00:00

The 2024 Lincoln Nautilus will be the brand&apos;s first model made in China that&apos;s exported to the U.S. and features a widescreen display across its dashboard.

## Texas museum to return stolen Roman bust after woman bought it at Goodwill for $35
 - [https://www.foxnews.com/lifestyle/texas-museum-return-stolen-roman-bust-woman-bought-goodwill-35](https://www.foxnews.com/lifestyle/texas-museum-return-stolen-roman-bust-woman-bought-goodwill-35)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 19:44:26+00:00

A centuries-old Roman bust that was once part of a German monarch&apos;s art collection will soon be returned home after first making headlines as a $35 Goodwill find in Texas.

## Man shot in head in drive-by shooting on NYC street outside office of soft-on-crime state lawmaker
 - [https://www.foxnews.com/us/man-shot-head-drive-by-shooting-nyc-street-office-soft-crime-lawmaker](https://www.foxnews.com/us/man-shot-head-drive-by-shooting-nyc-street-office-soft-crime-lawmaker)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 19:37:59+00:00

A man was shot in the head outside the New York City office of a state lawmaker who has been criticized as soft on crime.

## Bryce Young appears to be consensus No 1 pick to Panthers after bold move before NFL Draft
 - [https://www.foxnews.com/sports/bryce-young-appears-consensus-no-1-pick-panthers-bold-move-nfl-draft](https://www.foxnews.com/sports/bryce-young-appears-consensus-no-1-pick-panthers-bold-move-nfl-draft)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 19:32:40+00:00

Bryce Young was already considered to be the Carolina Panthers&apos; target with the first overall pick in the 2023 NFL Draft, but his move on Monday made it almost certain.

## California Democratic lawmakers roasted for Bud Light photo op: 'Worst party ever'
 - [https://www.foxnews.com/media/california-democratic-lawmakers-roasted-bud-light-photo-op-worst-party-ever](https://www.foxnews.com/media/california-democratic-lawmakers-roasted-bud-light-photo-op-worst-party-ever)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 19:30:38+00:00

Rep. Ted Lieu and some of his fellow Democratic lawmakers were made fun of after posing in a photo drinking Bud Light, following conservatives boycotting the company.

## Olivia Culpo says attending Coachella without ring after Christian McCaffrey engagement led to 'trouble'
 - [https://www.foxnews.com/sports/olivia-culpo-says-attending-coachella-without-ring-christian-mccaffrey-engagement-led-trouble](https://www.foxnews.com/sports/olivia-culpo-says-attending-coachella-without-ring-christian-mccaffrey-engagement-led-trouble)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 19:29:19+00:00

Model and former Miss USA Olivia Culpo revealed on social media that not wearing her engagement ring from 49ers star Christian McCaffrey led to some unwanted attention at Coachella.

## Vermont man accused of kidnapping woman, 4-year-old son admits to vehicle thefts in court
 - [https://www.foxnews.com/us/vermont-man-accused-kidnapping-woman-4-year-old-son-admits-vehicle-thefts-court](https://www.foxnews.com/us/vermont-man-accused-kidnapping-woman-4-year-old-son-admits-vehicle-thefts-court)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 19:27:35+00:00

Standing trial for kidnapping a New Hampshire woman and her son, Everett Simpson admitted to transporting two stolen cars across state lines, but denied abducting the victims.

## 13-year-old boy gets stuck climbing into claw machine to steal prize
 - [https://www.foxnews.com/us/13-year-old-boy-gets-stuck-climbing-claw-machine-steal-prize](https://www.foxnews.com/us/13-year-old-boy-gets-stuck-climbing-claw-machine-steal-prize)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 19:26:11+00:00

A 13-year-old boy got stuck while climbing into a claw machine to steal a prize. The boy was able to get out, was treated and released to his guardian.

## Georgia top jail staff forced out amid probe into death of man in bedbug-infested cell
 - [https://www.foxnews.com/us/georgia-top-jail-staff-forced-amid-probe-death-man-bedbug-infested-cell](https://www.foxnews.com/us/georgia-top-jail-staff-forced-amid-probe-death-man-bedbug-infested-cell)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 19:24:26+00:00

A Georgia sheriff announced the resignations of top jail staff during a probe into the death of a man whose cell was infested with bedbugs in the jail’s psychiatric wing.

## New York lawmakers pass third budget extension as stalemate continues
 - [https://www.foxnews.com/politics/new-york-lawmakers-pass-third-budget-extension-stalemate-continues](https://www.foxnews.com/politics/new-york-lawmakers-pass-third-budget-extension-stalemate-continues)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 19:21:54+00:00

New York legislators passed a three-day budget extension Monday to ensure state operations remain funded as negotiations over this year&apos;s budget proposal continue.

## Biden admin sees progress in tackling border crisis as March’s numbers down from last year
 - [https://www.foxnews.com/politics/biden-admin-sees-progress-tackling-border-crisis-marchs-numbers-down-prior-year](https://www.foxnews.com/politics/biden-admin-sees-progress-tackling-border-crisis-marchs-numbers-down-prior-year)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 19:20:55+00:00

The Biden administration is tying relatively lower numbers at the southern border encountered in March to measures it rolled out earlier this year to tackle the crisis.

## WV state lawmaker Elliott Pritt switches from Dem to GOP
 - [https://www.foxnews.com/politics/wv-state-lawmaker-elliott-pritt-switches-dem-gop](https://www.foxnews.com/politics/wv-state-lawmaker-elliott-pritt-switches-dem-gop)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 19:06:46+00:00

Elliott Pritt, a West Virginia state lawmaker, switched from the Democratic party to the Republican party. The 34-member state Senate also has a GOP supermajority.

## Tunisian Islamist leader, ex-parliament speaker, detained after police search
 - [https://www.foxnews.com/world/tunisian-islamist-leader-ex-parliament-speaker-detained-police-search](https://www.foxnews.com/world/tunisian-islamist-leader-ex-parliament-speaker-detained-police-search)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 19:04:54+00:00

Prominent Tunisian Islamist leader and opposition politician Rached Ghannouchi was detained Monday after being searched by police, according to his lawyer.

## Alabama town mourns after 4 killed at Sweet 16 birthday party
 - [https://www.foxnews.com/us/alabama-town-mourns-4-killed-sweet-16-birthday-party](https://www.foxnews.com/us/alabama-town-mourns-4-killed-sweet-16-birthday-party)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 19:02:54+00:00

The Alabama town of Dadeville is mourning after four people were killed at a Sweet 16 birthday party. Less than six weeks from graduation, two seniors were among four teens fatally shot.

## Misdemeanors filed in case of severely intoxicated teen
 - [https://www.foxnews.com/us/misdemeanors-filed-case-severely-intoxicated-teen](https://www.foxnews.com/us/misdemeanors-filed-case-severely-intoxicated-teen)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 18:57:49+00:00

Misdemeanor charges were filed Monday against two juveniles and two adults for a case involving an intoxicated teenager. The teen ended up in the hospital after blacking out.

## Typo forces Pennsylvania county to replace over 18K ballots
 - [https://www.foxnews.com/politics/typo-forces-pennsylvania-county-replace-18k-ballots](https://www.foxnews.com/politics/typo-forces-pennsylvania-county-replace-18k-ballots)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 18:56:35+00:00

A printing error on over 18,000 Lancaster County, Pennsylvania primary ballots instructed voters to pick an incorrect number of Supreme Court candidates.

## If AI 'spins out of control,' will the bots reflect values from China or the US?
 - [https://www.foxnews.com/media/ai-spins-control-bots-reflect-values-china-us](https://www.foxnews.com/media/ai-spins-control-bots-reflect-values-china-us)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 18:55:07+00:00

Stanford Institute for Human-Centered Artificial Intelligence director of policy and society Russell Wald sounded off on the issues arising from the current form of AI.

## Florida's Jac Caglianone trolls umpire for ejecting teammate with hilarious home run celebration
 - [https://www.foxnews.com/sports/floridas-jac-caglianone-trolls-umpire-ejecting-teammate-hilarious-home-run-celebration](https://www.foxnews.com/sports/floridas-jac-caglianone-trolls-umpire-ejecting-teammate-hilarious-home-run-celebration)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 18:49:54+00:00

Florida sophomore Jac Caglianone went viral on social media Sunday after protesting teammate Brandon Neely’s ejection by not celebrating hitting a grand slam.

## Florida house fire kills father, young children; mother, son survive
 - [https://www.foxnews.com/us/florida-house-fire-kills-father-young-children-mother-son-survive](https://www.foxnews.com/us/florida-house-fire-kills-father-young-children-mother-son-survive)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 18:35:49+00:00

A Florida man and his two children were killed Monday during a house fire in which his wife and son survived.

## 'Just Stop Oil' protester cancels world snooker championship after pouring orange dye on table
 - [https://www.foxnews.com/sports/just-stop-oil-protester-cancels-world-snooker-championship-pouring-orange-dye-table](https://www.foxnews.com/sports/just-stop-oil-protester-cancels-world-snooker-championship-pouring-orange-dye-table)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 18:26:09+00:00

A protester with &quot;Just Stop Oil&quot; canceled the world snooker championship on Monday after leaping onto the green baize and pouring an orange powder on it.

## North Carolina theme park crews rescue teenager from claw game
 - [https://www.foxnews.com/us/north-carolina-theme-park-crews-rescue-teenager-claw-game-reports](https://www.foxnews.com/us/north-carolina-theme-park-crews-rescue-teenager-claw-game-reports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 18:17:49+00:00

Crews at the Charlotte, North Carolina theme Carowinds rescued a teenager from a Cosmic XL Bonus Game claw machine, who got stuck inside after attempting to steal a prize.

## Oklahoma Gov. Stitt demands officials resign after remarks about killing journalists leak
 - [https://www.foxnews.com/politics/oklahoma-gov-stitt-demands-officials-resign-remarks-killing-journalists-leak](https://www.foxnews.com/politics/oklahoma-gov-stitt-demands-officials-resign-remarks-killing-journalists-leak)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 18:04:36+00:00

Republican Oklahoma Gov. Kevin Stitt is calling on four McCurtain County officials to resign after being recorded making racist comments and talking about knowing hitmen.

## New York woman shot, killed after being driven to wrong address
 - [https://www.foxnews.com/us/new-york-woman-shot-killed-driven-wrong-address](https://www.foxnews.com/us/new-york-woman-shot-killed-driven-wrong-address)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 18:01:14+00:00

Kevin Monahan, 65, of Hebron, New York, was arrested for second-degree murder after shooting and killing Kaylin Gillis, who was looking for a friend&apos;s house.

## Arkansas teen catches 12-pound bass while fishing for crappie: 'Didn't do too shabby'
 - [https://www.foxnews.com/lifestyle/arkansas-teen-catches-12-pound-bass-fishing-crappie-didnt-do-too-shabby](https://www.foxnews.com/lifestyle/arkansas-teen-catches-12-pound-bass-fishing-crappie-didnt-do-too-shabby)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 18:00:46+00:00

A teenager from northeast Arkansas caught and released a 12-pound, 4-ounce largemouth bass in Randolph County while fishing for crappie with a friend.

## WATCH: GOP voters weigh in on 2024 choice for president, shred 'bogus' Trump charges
 - [https://www.foxnews.com/politics/gop-voters-weigh-in-2024-choice-president-shred-trump-charges](https://www.foxnews.com/politics/gop-voters-weigh-in-2024-choice-president-shred-trump-charges)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 17:59:45+00:00

Voters attending the NRA&apos;s annual convention in Indianapolis shared with Fox News Digital their first choice for president in 2024, and slammed the charges brought against Donald Trump.

## Ugandan finance minister charged in scandal implicating 22 top officials
 - [https://www.foxnews.com/world/ugandan-finance-minister-charged-scandal-implicating-22-top-officials](https://www.foxnews.com/world/ugandan-finance-minister-charged-scandal-implicating-22-top-officials)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 17:58:35+00:00

Ugandan finance minister Amos Lugoloobi has been charged in a corruption scandal implicating many of the African nation&apos;s top officials.

## Soros-funded DA Pamela Price calls for rally to condemn ‘anti-Price’ news outlet that criticized her
 - [https://www.foxnews.com/media/soros-funded-da-pam-price-calls-rally-condemn-anti-price-news-outlet-criticized-her](https://www.foxnews.com/media/soros-funded-da-pam-price-calls-rally-condemn-anti-price-news-outlet-criticized-her)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 17:58:34+00:00

Alameda County District Attorney Pamela Price is participating in a rally calling out news outlets for the critical coverage of her and her office.

## Senate GOP hopes to block Schumer from naming a temporary committee replacement for Feinstein
 - [https://www.foxnews.com/politics/senate-gop-hopes-block-schumer-naming-temporary-committee-replacement-feinstein](https://www.foxnews.com/politics/senate-gop-hopes-block-schumer-naming-temporary-committee-replacement-feinstein)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 17:47:30+00:00

Schumer will likely need 10 Republican senators to temporarily replace Feinstein on the Senate Judiciary Committee, which has been unable to consider Biden&apos;s judicial nominees.

## Ohio grand jury declines to indict officers in Jayland Walker shooting
 - [https://www.foxnews.com/us/ohio-grand-jury-declines-indict-officers-jayland-walker-shooting](https://www.foxnews.com/us/ohio-grand-jury-declines-indict-officers-jayland-walker-shooting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 17:46:36+00:00

Ohio Attorney General Dave Yost announced on Monday that a grand jury declined to indict eight officers involved in the shooting death last summer of Jayland Walker.

## Ohio grand jury declines to indict police officers in Jayland Walker shooting
 - [https://www.foxnews.com/us/ohio-grand-jury-declines-indict-police-officers-jayland-walker-shooting](https://www.foxnews.com/us/ohio-grand-jury-declines-indict-police-officers-jayland-walker-shooting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 17:46:36+00:00

Ohio Attorney General Dave Yost announced Monday that a grand jury declined to indict eight officers involved in the shooting death last summer of Jayland Walker.

## Missouri bald eagle becomes proud foster dad to eaglet chick after taking care of a rock
 - [https://www.foxnews.com/lifestyle/missouri-bald-eagle-becomes-proud-foster-dad-eaglet-chick-taking-care-rock](https://www.foxnews.com/lifestyle/missouri-bald-eagle-becomes-proud-foster-dad-eaglet-chick-taking-care-rock)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 17:42:06+00:00

An older bald eagle named Murphy tried to incubate a rock at the World Bird Sanctuary in Valley Park, Missouri — now, CEO Dawn Griffard said the sanctuary paired the wannabe dad with an eaglet chick.

## Blue Jays’ Anthony Bass takes shot at United Airlines after pregnant wife forced to pick up child’s mess
 - [https://www.foxnews.com/sports/blue-jays-anthony-bass-takes-shot-united-airlines-pregnant-wife-forced-pick-up-childs-mess](https://www.foxnews.com/sports/blue-jays-anthony-bass-takes-shot-united-airlines-pregnant-wife-forced-pick-up-childs-mess)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 17:38:53+00:00

Toronto Blue Jays reliever Anthony Bass was irate with United Airlines because he said a fight attendant made his pregnant wife pick up their child&apos;s popcorn mess.

## DCCC, Marc Elias' firm accused of 'apparent civil violations' of federal election law
 - [https://www.foxnews.com/politics/dccc-marc-elias-firm-accused-apparent-civil-violations-federal-election-law](https://www.foxnews.com/politics/dccc-marc-elias-firm-accused-apparent-civil-violations-federal-election-law)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 17:31:11+00:00

An anti-Biden political action committee alleged &quot;apparent civil violations&quot; of election law by the DCCC and Clinton-linked attorney Marc Elias.

## Connecticut judge ends 50 years of federal oversight of Hartford police
 - [https://www.foxnews.com/us/connecticut-judge-ends-50-years-federal-oversight-hartford-police](https://www.foxnews.com/us/connecticut-judge-ends-50-years-federal-oversight-hartford-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 17:27:27+00:00

U.S. District Judge Kari Dooley of Bridgeport, Connecticut, ruled in favor of dissolving a nearly half-century-old consent decree that resulted in federal oversight of the Hartford police.

## China to conduct ‘major military activity’ in Yellow Sea amid heightened tensions in region
 - [https://www.foxnews.com/world/china-conduct-major-military-activity-yellow-sea-amid-heightened-tensions-region](https://www.foxnews.com/world/china-conduct-major-military-activity-yellow-sea-amid-heightened-tensions-region)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 17:26:58+00:00

China&apos;s Maritime Safety Administration says Chinese naval ships will conduct a &quot;major military activity&quot; in the Yellow Sea on Tuesday amid heightened tensions in the region.

## Texas man arrested in connection to 1981 cold-case murder of teen girl freed on bond
 - [https://www.foxnews.com/us/texas-man-larry-allen-west-arrested-1981-cold-case-murder-teen-girl-carol-joyce-deleon-freed-bond](https://www.foxnews.com/us/texas-man-larry-allen-west-arrested-1981-cold-case-murder-teen-girl-carol-joyce-deleon-freed-bond)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 17:25:47+00:00

A Texas man was charged last week with shooting a teenage woman in the head six times more than four decades ago after his DNA matched samples found on her body, officials said.

## Former politician known for feces protest killed in South Africa
 - [https://www.foxnews.com/world/former-politician-known-feces-protest-killed-south-africa](https://www.foxnews.com/world/former-politician-known-feces-protest-killed-south-africa)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 17:25:14+00:00

An ex-politician known for dumping human feces in public places as an act of protest was killed in South Africa. The protests called attention to the living conditions in the country.

## Florida first responders describe 'jarring' fire scene in open field: 'horrific'
 - [https://www.foxnews.com/us/florida-first-responders-describe-jarring-fire-scene-in-open-field](https://www.foxnews.com/us/florida-first-responders-describe-jarring-fire-scene-in-open-field)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 17:18:29+00:00

Hillsborough County deputies and fire crews responded to reports of a mannequin on fire in a field in Ruskin, Florida, but instead found this.

## Six additional Biden family members 'may have benefited' from Hunter business dealings
 - [https://www.foxnews.com/politics/six-additional-biden-family-members-may-have-benefited-from-hunter-business-dealings-comer-says](https://www.foxnews.com/politics/six-additional-biden-family-members-may-have-benefited-from-hunter-business-dealings-comer-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 17:16:16+00:00

House Oversight Committee Chairman James Comer said Monday he has identified “six additional members&quot; of the Biden family who “may have benefited&quot; from Biden family business dealings and vowed to continue to investigate whether those dealings pose a “national security threat.&quot;

## Heidi Klum soaks up sun in yellow bikini on Instagram: 'Finally some sunshine'
 - [https://www.foxnews.com/entertainment/heidi-klum-soaks-up-sun-yellow-bikini-instagram](https://www.foxnews.com/entertainment/heidi-klum-soaks-up-sun-yellow-bikini-instagram)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 17:13:22+00:00

Heidi Klum shows off bikini body in yellow swimsuit on Instagram as she &quot;finally&quot; gets &quot;some sunshine.&quot; The model often shares moments from her life on social media.

## US Department of Energy to use $15M to build 'living labs' for tribal colleges
 - [https://www.foxnews.com/us/us-department-energy-use-15m-build-living-labs-tribal-colleges](https://www.foxnews.com/us/us-department-energy-use-15m-build-living-labs-tribal-colleges)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 17:11:27+00:00

The U.S. Department of Energy will use $15 million in grants to build &quot;living labs&quot; for tribal colleges and universities. The new funding opportunity will boost clean energy development.

## Armie Hammer sex assault case under review in Los Angeles, prosecutors say
 - [https://www.foxnews.com/entertainment/armie-hammer-sex-assault-case-under-review-los-angeles-prosecutors-say](https://www.foxnews.com/entertainment/armie-hammer-sex-assault-case-under-review-los-angeles-prosecutors-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 17:10:49+00:00

California prosecutors are reviewing a sexual assault case against embattled Hollywood star Armie Hammer more than two years after public accusations of rape.

## Judge rules Maine ICE facility must release more records in ACLU suit
 - [https://www.foxnews.com/us/judge-rules-maine-ice-facility-release-records-aclu-suit](https://www.foxnews.com/us/judge-rules-maine-ice-facility-release-records-aclu-suit)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 17:10:11+00:00

Immigration and Customs Enforcement must release additional records regarding the agency&apos;s detention practices in a Scarborough, Maine facility, a federal judge ruled.

## Florida tornado damages dozens of homes after week of heavy rain: NWS
 - [https://www.foxnews.com/us/florida-tornado-damages-dozens-homes-week-heavy-rain-nws](https://www.foxnews.com/us/florida-tornado-damages-dozens-homes-week-heavy-rain-nws)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 17:02:21+00:00

A small Florida community was slammed by a Tornado over the weekend that destroyed dozens of homes, and more storm warnings were in effect Monday.

## Texas serial killer fears rise as lake deaths climb to 4
 - [https://www.foxnews.com/us/texas-serial-killer-fears-lake-deaths-climb-4](https://www.foxnews.com/us/texas-serial-killer-fears-lake-deaths-climb-4)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 17:01:54+00:00

A fourth person has been found dead in an Austin lake amid public fears over a potential serial killer, but police said they haven&apos;t seen evidence of foul play in any of the cases.

## McConnell rips Biden's 'extreme position' on debt limit in first speech back after concussion
 - [https://www.foxnews.com/politics/mcconnell-rips-bidens-extreme-position-debt-limit-first-speech-back-concussion](https://www.foxnews.com/politics/mcconnell-rips-bidens-extreme-position-debt-limit-first-speech-back-concussion)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 17:00:02+00:00

The longtime Senate GOP Leader returned to Congress on Monday after a severe fall last month saw him hospitalized and then in physical therapy.

## Federal appeals court strikes down Democratic city's natural gas ban backed by Biden admin
 - [https://www.foxnews.com/politics/federal-appeals-court-strikes-down-democratic-citys-natural-gas-ban-backed-biden-admin](https://www.foxnews.com/politics/federal-appeals-court-strikes-down-democratic-citys-natural-gas-ban-backed-biden-admin)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 16:54:13+00:00

A federal appeals panel struck down a ban on natural gas piping in new buildings passed by the City of Berkeley, California, ruling that the ordinance violated federal law.

## Biden White House blasted for 9 a.m. press lid after president's Ireland trip: 'A case of the Monday’s'
 - [https://www.foxnews.com/politics/biden-white-house-blasted-9-a-m-press-lid-after-presidents-ireland-trip-case-mondays](https://www.foxnews.com/politics/biden-white-house-blasted-9-a-m-press-lid-after-presidents-ireland-trip-case-mondays)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 16:49:44+00:00

People blasted President Biden online after the White House called a 9 a.m. press lid after the president&apos;s trip to Ireland, with one user quipping he had &quot;a case of the Monday&apos;s.&quot;

## Rep. George Santos announces re-election bid in New York's 3rd Congressional District
 - [https://www.foxnews.com/politics/rep-george-santos-announces-reelection-bid-new-yorks-3rd-district](https://www.foxnews.com/politics/rep-george-santos-announces-reelection-bid-new-yorks-3rd-district)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 16:44:10+00:00

U.S. Rep. George Santos, R-N.Y., announced his re-election bid Monday despite a House Ethics Committee investigation into numerous scandals surrounding the freshman lawmaker.

## PHOTOS: Fetterman returns to Senate in sweatshirt, shorts after months-long hospital stay
 - [https://www.foxnews.com/politics/photos-fetterman-returns-senate-sweatshirt-shorts-months-long-hospital-stay](https://www.foxnews.com/politics/photos-fetterman-returns-senate-sweatshirt-shorts-months-long-hospital-stay)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 16:42:52+00:00

Sen. John Fetterman returned to the Senate on Monday, after admitting himself into the hospital to be treated for clinical depression for six weeks.

## Gavin Newsom slashes funding for foster care program amid California budget crunch
 - [https://www.foxnews.com/politics/gavin-newsom-slashes-funding-foster-care-program-california-budget-crunch](https://www.foxnews.com/politics/gavin-newsom-slashes-funding-foster-care-program-california-budget-crunch)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 16:39:06+00:00

Republicans and Democrats have found themselves in rare agreement over a proposal by Calif. Gov. Gavin Newsom to slash his budget commitment for foster care services.

## Think our kids can't be responsible with money? Surprising insights from a children's book author
 - [https://www.foxnews.com/lifestyle/think-kids-cant-responsible-money-surprising-insights-children-book-author](https://www.foxnews.com/lifestyle/think-kids-cant-responsible-money-surprising-insights-children-book-author)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 16:38:36+00:00

Money management can be a discussion for children. Here&apos;s why this might be crucial for kids and how parents can play a role in teaching financial literacy at home.

## Israel president urges unity on Holocaust Remembrance Day
 - [https://www.foxnews.com/world/israel-president-urges-unity-holocaust-remembrance-day](https://www.foxnews.com/world/israel-president-urges-unity-holocaust-remembrance-day)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 16:31:50+00:00

The president of Israel is urging for unity as the country marks the beginning of Holocaust Remembrance Day. The day serves as a memorial for the 6 million Jews killed in the Holocaust.

## Small plane attempts to land on Georgia runway covered in fog, ex-Navy SEAL pilot killed
 - [https://www.foxnews.com/us/small-plane-attempts-land-georgia-runway-covered-fog-ex-navy-seal-pilot-killed](https://www.foxnews.com/us/small-plane-attempts-land-georgia-runway-covered-fog-ex-navy-seal-pilot-killed)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 16:30:08+00:00

Federal investigators said there was fog on the ground at a Georgia airport when a small plane attempted to land before crashing and killing its pilot, a former Navy SEAL.

## Chinese Embassy urges House Republican to stop 'targeting China,' focus on 'own failure' in COVID origins hunt
 - [https://www.foxnews.com/politics/chinese-embassy-urges-house-republican-respect-science-stop-targeting-china-covid-origins-search](https://www.foxnews.com/politics/chinese-embassy-urges-house-republican-respect-science-stop-targeting-china-covid-origins-search)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 16:26:06+00:00

The Chinese Embassy&apos;s liaison to Congress telling a House Republican to &quot;respect science&quot; and stop &quot;targeting China&quot; in an email exclusively obtained by Fox News Digital.

## UCF football star plays baseball game, runs to field for spring game: 'This is a dream for me'
 - [https://www.foxnews.com/sports/ucf-football-star-plays-baseball-game-runs-spring-game](https://www.foxnews.com/sports/ucf-football-star-plays-baseball-game-runs-spring-game)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 16:16:52+00:00

UCF&apos;s John Rhys Plumlee was in a wild scene this past Friday, as he went from playing baseball to suiting up for the Knights&apos; spring football game.

## AI-generated song using Drake and The Weeknd vocals goes viral, raising legal concerns
 - [https://www.foxnews.com/entertainment/ai-generated-song-using-drake-the-weeknd-vocals-goes-viral-legal-concerns](https://www.foxnews.com/entertainment/ai-generated-song-using-drake-the-weeknd-vocals-goes-viral-legal-concerns)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 16:16:26+00:00

An AI-generated song using vocals from Drake and The Weekend has gone viral on TikTok.

## Indiana man gets over 150 years for senior citizen rape spree
 - [https://www.foxnews.com/us/indiana-man-gets-150-years-senior-citizen-rape-spree](https://www.foxnews.com/us/indiana-man-gets-150-years-senior-citizen-rape-spree)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 16:06:20+00:00

An Indiana judge has sentenced Darrell Goodlow to 156 1/2 years in prison for a yearlong rape spree that began in 2020 on the outskirts of Indianapolis.

## Former Intelligence chief to say a lab leak is the 'only explanation' for COVID
 - [https://www.foxnews.com/politics/ratcliffe-to-say-a-lab-leak-is-the-only-explanation-for-covid-during-unclassified-overview-of-pandemic](https://www.foxnews.com/politics/ratcliffe-to-say-a-lab-leak-is-the-only-explanation-for-covid-during-unclassified-overview-of-pandemic)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 16:03:21+00:00

EXCLUSIVE: Former Director of National Intelligence John Ratcliffe says the “only explanation&quot; and “plausible assessment&quot; for the COVID-19 global pandemic is a leak from a Chinese Communist Party-controlled lab, citing U.S. intelligence and “numerous, diverse and unassailable&quot; sources for the information.

## UPenn group hosts 'radical playdate' event 'programming' 5-9-year-olds to explore their race, gender identity
 - [https://www.foxnews.com/media/upenn-radical-playdate-event-programming-5-9-year-olds-explore-race-gender-identity](https://www.foxnews.com/media/upenn-radical-playdate-event-programming-5-9-year-olds-explore-race-gender-identity)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 16:00:29+00:00

The University of Pennsylvania’s Gender, Sexuality and Women’s Studies program hosted an event for kids aged five to nine to explore their &apos;gender identity&apos; on Saturday.

## Trent Lehrkamp case: Georgia authorities announce charges against parents, teens
 - [https://www.foxnews.com/us/trent-lehrkamp-case-georgia-authorities-announce-charges-against-parents-teens](https://www.foxnews.com/us/trent-lehrkamp-case-georgia-authorities-announce-charges-against-parents-teens)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 16:00:00+00:00

Georgia police Monday announced charges against three teens as well as the owners of the home where 19-year-old Trent Lehrkamp drank so much booze he had to be hospitalized.

## New Jersey mall to implement chaperone policy for visitors under age 18: 'disruptive behavior'
 - [https://www.foxnews.com/us/new-jersey-mall-implement-chaperone-policy-visitors-under-age-18](https://www.foxnews.com/us/new-jersey-mall-implement-chaperone-policy-visitors-under-age-18)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 15:58:04+00:00

Teenage visitors will be required to be accompanied by an adult in a New Jersey shopping mall

## Jamie Foxx remains 'hospitalized' after 'medical complication' in Atlanta: report
 - [https://www.foxnews.com/entertainment/jamie-foxx-remains-hospitalized-medical-complication-atlanta-report](https://www.foxnews.com/entertainment/jamie-foxx-remains-hospitalized-medical-complication-atlanta-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 15:56:55+00:00

Jamie Foxx is &quot;having tests run&quot; and still recovering from a &quot;medical complication&quot; last week in Atlanta. His daughter Corinne updated fans on his health.

## John Rich slams Bud Light’s reactions to controversy: ‘It's too late for that’
 - [https://www.foxnews.com/entertainment/john-rich-slams-bud-lights-reactions-controversy](https://www.foxnews.com/entertainment/john-rich-slams-bud-lights-reactions-controversy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 15:49:42+00:00

John Rich talked to Fox News Digital about his thoughts on the massive controversy surrounding Bud Light&apos;s decision to hire trans activist Dylan Mulvaney for a sponsorship.

## Brittany Matthews defends Jackson Mahomes, Chiefs star’s brother, amid scrutiny: ‘It’s best to just shut up'
 - [https://www.foxnews.com/sports/brittany-matthews-defends-jackson-mahomes-chiefs-stars-brother-amid-scrutiny-its-best-just-shut-up](https://www.foxnews.com/sports/brittany-matthews-defends-jackson-mahomes-chiefs-stars-brother-amid-scrutiny-its-best-just-shut-up)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 15:46:00+00:00

The wife of Kansas City Chiefs quarterback Patrick Mahomes, Brittany Matthews, is speaking up against the critics again, this time in defense of her brother-in-law, Jackson Mahomes.

## 180 dead, almost 2K injured as Sudan conflict rages on
 - [https://www.foxnews.com/world/180-dead-almost-2k-injured-sudan-conflict-rages](https://www.foxnews.com/world/180-dead-almost-2k-injured-sudan-conflict-rages)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 15:39:43+00:00

A political power struggle between two rival Sudanese generals has taken to the nation&apos;s crowded streets, with 180 people reportedly killed and another 1,800 injured.

## Los Angeles convicted felon out on probation accused of gunning down 60-year-old man removing gang graffiti
 - [https://www.foxnews.com/us/los-angeles-convicted-felon-accused-gunning-down-60-year-old-man-removing-gang-graffiti](https://www.foxnews.com/us/los-angeles-convicted-felon-accused-gunning-down-60-year-old-man-removing-gang-graffiti)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 15:35:26+00:00

Los Angeles murder suspect Jamal Jackson was out on probation for a firearm charge when he was accused of gunning down a 60-year-old man painting over gang graffiti on Sunday.

## Mississippi to require consumption-based water billing
 - [https://www.foxnews.com/us/mississippi-require-consumption-based-water-billing](https://www.foxnews.com/us/mississippi-require-consumption-based-water-billing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 15:35:25+00:00

Mississippi will require localities to base their water bills on personal consumption. The bill was signed into legislation on Friday by Gov. Tate Reeves.

## Disgraced ex-Cardinal McCarrick charged in 1977 Wisconsin sex abuse case
 - [https://www.foxnews.com/us/disgraced-ex-cardinal-mccarrick-charged-1977-wisconsin-sex-abuse-case](https://www.foxnews.com/us/disgraced-ex-cardinal-mccarrick-charged-1977-wisconsin-sex-abuse-case)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 15:32:16+00:00

Defrocked Roman Catholic Cardinal Theodore McCarrick has been charged in Wisconsin for an alleged sexual assault that occurred over 45 years ago.

## Wife of Moroccan soccer star loses divorce settlement as fortune is in his mother's name
 - [https://www.foxnews.com/sports/wife-moroccan-soccer-star-loses-divorce-settlement-fortune-mothers-name](https://www.foxnews.com/sports/wife-moroccan-soccer-star-loses-divorce-settlement-fortune-mothers-name)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 15:31:00+00:00

Hiba Abouk, the wife of Paris Saint-Germain&apos;s Achraf Hakimi, wanted half of the Moroccan star&apos;s fortune in their divorce, but almost all of his fortune is in his mother&apos;s name.

## Olympic gold medal-winning swimmer voices support for Riley Gaines: 'A lot of us veterans are behind her'
 - [https://www.foxnews.com/media/olympic-gold-medalist-donna-de-varona-support-riley-gaines-veterans-behind](https://www.foxnews.com/media/olympic-gold-medalist-donna-de-varona-support-riley-gaines-veterans-behind)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 15:30:55+00:00

Former Olympic swimmer Donna de Varona called on parents to &quot;speak up&quot; in support of Riley Gaines and her fight to keep transgender athletes out of women&apos;s sports.

## Katie Porter blames sexism when pressed on 'The View' about staff mistreatment allegations
 - [https://www.foxnews.com/media/katie-porter-blames-sexism-pressed-view-about-staff-mistreatment-allegations](https://www.foxnews.com/media/katie-porter-blames-sexism-pressed-view-about-staff-mistreatment-allegations)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 15:26:19+00:00

&quot;The View&apos; co-hosts asked Rep. Katie Porter about domestic abuse and staff mistreatment allegations against her during Monday&apos;s episode of the show.

## DeSantis fires back at Disney as company tries to 'usurp' state oversight
 - [https://www.foxnews.com/politics/desantis-fires-back-disney-company-tries-usurp-state-oversight](https://www.foxnews.com/politics/desantis-fires-back-disney-company-tries-usurp-state-oversight)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 15:08:38+00:00

Florida Gov. Ron DeSantis announced a bill that would revoke Disney&apos;s Reedy Creek Improvement district, giving the state control of the area.

## Houston-area suspect shoots, kills girlfriend, dies in house fire
 - [https://www.foxnews.com/us/houston-area-suspect-shoots-kills-girlfriend-dies-house-fire](https://www.foxnews.com/us/houston-area-suspect-shoots-kills-girlfriend-dies-house-fire)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 15:07:05+00:00

A Houston-area man believed to have shot and killed his girlfriend died after a house fire at the crime scene, police said.

## Pennsylvania court tosses out ex-Gov. Tom Wolf's suit against GOP lawmakers
 - [https://www.foxnews.com/politics/pennsylvania-court-tosses-ex-gov-tom-wolfs-suit-gop-lawmakers](https://www.foxnews.com/politics/pennsylvania-court-tosses-ex-gov-tom-wolfs-suit-gop-lawmakers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 15:02:14+00:00

A five-judge panel has ruled against former Pennsylvania Gov. Tom Wolf, who sued the Legislature for bundling constitutional amendments in a way that allegedly ran afoul of state rules.

## Prince William expected to 'tolerate' Prince Harry during coronation, expert claims: 'Bad blood and betrayal'
 - [https://www.foxnews.com/entertainment/prince-william-expected-tolerate-prince-harry-during-coronation-expert-claims-bad-blood](https://www.foxnews.com/entertainment/prince-william-expected-tolerate-prince-harry-during-coronation-expert-claims-bad-blood)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 14:54:34+00:00

Several royal experts claimed that Prince William and Prince Harry&apos;s relationship continues to be fractured following the publication of &quot;Spare,&quot; the Duke of Sussex&apos;s memoir.

## Educators are exploring AI systems to keep students honest in the age of ChatGPT
 - [https://www.foxnews.com/tech/educators-turning-ai-systems-keep-students-honest-age-chatgpt](https://www.foxnews.com/tech/educators-turning-ai-systems-keep-students-honest-age-chatgpt)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 14:53:04+00:00

Turn It In, a plagiarism detection company, has developed an AI program that can help educators determine whether students used AI to create essays.

## Biden to veto GOP bill protecting women's sports, calls it 'discrimination' against transgender students
 - [https://www.foxnews.com/politics/biden-veto-gop-bill-protecting-womens-sports-discrimination-transgender-students](https://www.foxnews.com/politics/biden-veto-gop-bill-protecting-womens-sports-discrimination-transgender-students)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 14:45:41+00:00

The White House announced that President Biden will veto the Protection of Women and Girls in Sports Act should it pass through Congress.

## Suspect arrested in killing of Oregon reserve police officer
 - [https://www.foxnews.com/us/suspect-arrested-killing-oregon-reserve-police-officer](https://www.foxnews.com/us/suspect-arrested-killing-oregon-reserve-police-officer)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 14:42:03+00:00

Authorities arrested a man who is suspected of killing an eastern Oregon police officer on Saturday night. The officer was pursing the man in a car when he was shot.

## North Carolina researchers make predictions for 2023 hurricane season
 - [https://www.foxnews.com/us/north-carolina-researchers-make-predictions-2023-hurricane-season](https://www.foxnews.com/us/north-carolina-researchers-make-predictions-2023-hurricane-season)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 14:40:16+00:00

North Carolina State University&apos;s researchers predicted the upcoming hurricane season could create over a dozen storms. They estimated 11 to 15 storms will occur in the Atlantic basin.

## South Carolina trooper shot in face during traffic stop
 - [https://www.foxnews.com/us/south-carolina-trooper-shot-face-traffic-stop](https://www.foxnews.com/us/south-carolina-trooper-shot-face-traffic-stop)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 14:38:09+00:00

A South Carolina trooper was shot in the face during a traffic stop in which he pulled over a vehicle for speeding. The Highway Patrol says the trooper&apos;s condition is not life threatening.

## During Nevada trip, Haaland celebrates ‘new era’ of environmental conservation
 - [https://www.foxnews.com/us/during-nevada-trip-haaland-celebrates-new-era-environmental-conservation](https://www.foxnews.com/us/during-nevada-trip-haaland-celebrates-new-era-environmental-conservation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 14:35:40+00:00

U.S. Interior Secretary Deb Haaland announced Friday in Las Vegas that the newly designated Avi Kwa Ame National Monument in southern Nevada marks a new era of conservation.

## Former home of convict in notorious German cannibal case destroyed
 - [https://www.foxnews.com/world/former-home-convict-notorious-german-cannibal-case-destroyed](https://www.foxnews.com/world/former-home-convict-notorious-german-cannibal-case-destroyed)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 14:34:24+00:00

Police said the former home of a convict in a notorious German cannibal case has been destroyed. The man is serving a life sentence for killing and eating an acquaintance.

## Danny Masterson's rape retrial begins with jury selection process in LA courtroom
 - [https://www.foxnews.com/entertainment/danny-mastersons-rape-retrial-begins-jury-selection-process-la-courtroom](https://www.foxnews.com/entertainment/danny-mastersons-rape-retrial-begins-jury-selection-process-la-courtroom)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 14:33:47+00:00

Danny Masterson faces new trial on rape charges filed by LA District Attorney from alleged assaults between 2001-03. He was arrested in 2020 and pleaded not guilty.

## Spain PM apologizes to sexual assault victims after law inadvertently reduces hundreds of convicts’ sentences
 - [https://www.foxnews.com/world/spain-pm-apologizes-sexual-assault-victims-law-inadvertently-reduces-hundreds-convicts-sentences](https://www.foxnews.com/world/spain-pm-apologizes-sexual-assault-victims-law-inadvertently-reduces-hundreds-convicts-sentences)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 14:33:07+00:00

Pedro Sánchez, the prime minister of Spain, apologized for a sexual freedom law that inadvertently reduced the sentences of hundreds of sex offenders.

## Switzerland man Marcel Hug, American woman Susannah Scaroni take Boston Marathon wheelchair titles
 - [https://www.foxnews.com/sports/switzerland-man-marcel-hug-american-woman-susannah-scaroni-boston-marathon-wheelchair-titles](https://www.foxnews.com/sports/switzerland-man-marcel-hug-american-woman-susannah-scaroni-boston-marathon-wheelchair-titles)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 14:32:42+00:00

A Switzerland man claimed his sixth victory at the wheelchair division of the 127th Boston Marathon in record time. American Susannah Scaroni won her first title for the women’s race.

## 16 killed, 9 injured in Dubai apartment fire
 - [https://www.foxnews.com/world/16-killed-9-injured-dubai-apartment-fire](https://www.foxnews.com/world/16-killed-9-injured-dubai-apartment-fire)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 14:31:46+00:00

A fire broke out at an apartment building in Dubai, United Arab Emirates. 16 people from India, Pakistan, Egypt, and other countries were killed in the blaze.

## Muslims across the world practice ‘Green Ramadan’ to become more environmentally friendly
 - [https://www.foxnews.com/world/muslims-across-the-world-practice-green-ramadan-to-become-more-environmentally-friendly](https://www.foxnews.com/world/muslims-across-the-world-practice-green-ramadan-to-become-more-environmentally-friendly)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 14:30:55+00:00

In a month that emphasizes restraint, Muslims across the world are pushing one step further by practicing “Green Ramadan&quot; where they make more eco-friendly habits.

## Kayleigh McEnany calls out Lori Lightfoot, progressive mayor-elect after Chicago's 'Teen Takeover' chaos
 - [https://www.foxnews.com/media/kayleigh-mcenany-calls-lori-lightfoot-progressive-mayor-elect-chicago-teen-takeover-chaos](https://www.foxnews.com/media/kayleigh-mcenany-calls-lori-lightfoot-progressive-mayor-elect-chicago-teen-takeover-chaos)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 14:30:27+00:00

&apos;Outnumbered&apos; co-host Kayleigh McEnany reacted to Chicago mayor-elect Brandon Johnson&apos;s statements about teenagers causing chaos in the city.

## Lack of security around Japanese prime minister surprises many following smoke bomb attack
 - [https://www.foxnews.com/world/lack-security-japanese-prime-minister-surprises-following-smoke-bomb-attack](https://www.foxnews.com/world/lack-security-japanese-prime-minister-surprises-following-smoke-bomb-attack)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 14:26:37+00:00

After a Japanese suspect threw a smoke bomb at Prime Minister Fumio Kishida, many residents were surprised by Kishida’s lack of security.

## Indiana firefighters rescue dozens of people from fatal, multi-level apartment building fire
 - [https://www.foxnews.com/us/indiana-firefighters-rescue-dozens-people-fatal-multi-level-apartment-building-fire](https://www.foxnews.com/us/indiana-firefighters-rescue-dozens-people-fatal-multi-level-apartment-building-fire)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 14:25:28+00:00

Dozens of people were rescued from a multilevel fire that took place at an apartment building in Indianapolis. Firefighters used ground ladders to rescue people from the building.

## A better mousetrap? What DeSantis is proposing for Disney’s land after latest barb with ‘corporate kingdom’
 - [https://www.foxnews.com/politics/better-mousetrap-desantis-proposing-disneys-land-latest-barb-coporate-kingdom](https://www.foxnews.com/politics/better-mousetrap-desantis-proposing-disneys-land-latest-barb-coporate-kingdom)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 14:23:51+00:00

Florida Gov. Ron DeSantis struck back at Disney World after the corporate giant tried to enshrine its self-governing power, announcing forthcoming legislative action.

## ‘Missing’ cancer cases: New diagnoses dropped more than 14% early in pandemic
 - [https://www.foxnews.com/health/missing-cancer-cases-diagnoses-dropped-early-pandemic](https://www.foxnews.com/health/missing-cancer-cases-diagnoses-dropped-early-pandemic)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 14:23:40+00:00

Amid stay-at-home orders early in the pandemic, some 200,000 people who had cancer did not receive diagnoses or treatment when the pandemic began in 2020, researchers found.

## Eric Swalwell's campaign rolls on with luxury spending, including in Germany
 - [https://www.foxnews.com/politics/eric-swalwells-campaign-rolls-luxury-spending-including-germany](https://www.foxnews.com/politics/eric-swalwells-campaign-rolls-luxury-spending-including-germany)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 14:23:34+00:00

California Democratic Rep. Eric Swalwell has continued his luxurious campaign spending, including on upscale hotels in Germany and several cities in the United States.

## Florida Keys inundated with 5,000-mile-wide blob of sargassum seaweed, aerial video shows
 - [https://www.foxnews.com/us/florida-keys-inundated-5000-mile-wide-blob-sargassum-seaweed-aerial-video-shows](https://www.foxnews.com/us/florida-keys-inundated-5000-mile-wide-blob-sargassum-seaweed-aerial-video-shows)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 14:18:08+00:00

The sargassum bloom, a toxic red tide algae, that washed up in the Florida Keys on Easter Sunday was 5,000 miles wide and can smell like rotten eggs.

## Alvin Bragg protester booted from House Judiciary hearing: ‘You are utterly disgraceful’
 - [https://www.foxnews.com/politics/alvin-bragg-protester-booted-house-judiciary-hearing-you-utterly-disgraceful](https://www.foxnews.com/politics/alvin-bragg-protester-booted-house-judiciary-hearing-you-utterly-disgraceful)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 14:13:09+00:00

A New York man protesting Democrats&apos; &quot;disgraceful&quot; policies was escorted out of a House Judiciary Committee field hearing in Manhattan Monday.

## German and British fighter jets intercept Russian plane near NATO border
 - [https://www.foxnews.com/world/german-abritish-fighter-jets-intercept-russian-plane-near-nato-border](https://www.foxnews.com/world/german-abritish-fighter-jets-intercept-russian-plane-near-nato-border)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 14:00:53+00:00

The German Air Force and U.K.&apos;s Royal Air Force worked together to intercept a Russian military aircraft that was flying close to NATO airspace over the Baltic Sea.

## MSNBC’s Jen Psaki called out for not booking Republican guests: ‘What’s the problem?’
 - [https://www.foxnews.com/media/msnbcs-jen-psaki-called-not-booking-republican-guests-whats-problem](https://www.foxnews.com/media/msnbcs-jen-psaki-called-not-booking-republican-guests-whats-problem)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 13:58:36+00:00

Kara Swisher called out MSNBC’s Jen Psaki for not having any Republicans on her recently launched program after four weeks of booking only like-minded Democrats.

## Former president of International Biathlon Union indicted in Norway on bribery accusations
 - [https://www.foxnews.com/world/former-president-international-biathlon-union-indicted-norway-bribe-accusations](https://www.foxnews.com/world/former-president-international-biathlon-union-indicted-norway-bribe-accusations)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 13:56:31+00:00

Anders Besseberg has been indicted in his home country of Norway on bribery accusations. Besseberg is the former president of the International Biathlon Union.

## Russia's foreign minister visits Brazil as President Luiz Inácio Lula da Silva pushes for peace in Ukraine
 - [https://www.foxnews.com/us/russias-foreign-minister-visits-brazil-president-luiz-inacio-lula-da-silva-pushes-peace-ukraine](https://www.foxnews.com/us/russias-foreign-minister-visits-brazil-president-luiz-inacio-lula-da-silva-pushes-peace-ukraine)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 13:55:58+00:00

Brazil&apos;s foreign minister welcomed his Russian counterpart into his country&apos;s capital on April 17, 2023. Brazil&apos;s president is pushing for a diplomatic approach for peace in Ukraine.

## Young Lions star eyes playoffs following ‘strong’ finish in 2022: ‘We’re not no walk-over team now’
 - [https://www.foxnews.com/sports/young-lions-star-eyes-playoffs-following-strong-finish-2022-were-not-no-walk-over-team-now](https://www.foxnews.com/sports/young-lions-star-eyes-playoffs-following-strong-finish-2022-were-not-no-walk-over-team-now)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 13:53:43+00:00

The Detroit Lions had their first winning record since 2017, and third-year receiver Amon-Ra St. Brown is hungry for a playoff appearance next season.

## Maryland efforts to legalize ‘human composting’ face pushback as burial alternatives grow in popularity
 - [https://www.foxnews.com/politics/maryland-efforts-legalize-human-composting-face-pushback-burial-alternatives-grow-popularity](https://www.foxnews.com/politics/maryland-efforts-legalize-human-composting-face-pushback-burial-alternatives-grow-popularity)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 13:51:56+00:00

People are showing more interest towards eco-friendly burial practices such as human composting and green burials. However, efforts to legalize it have stalled.

## Lionel Richie shares plans for King Charles III coronation concert: 'the grandiose of grandiose'
 - [https://www.foxnews.com/entertainment/lionel-richie-shares-plans-king-charles-iii-coronation-concert-grandiose](https://www.foxnews.com/entertainment/lionel-richie-shares-plans-king-charles-iii-coronation-concert-grandiose)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 13:48:42+00:00

Lionel Richie spoke about his upcoming performance at King Charles&apos; coronation concert, saying it&apos;s an &quot;honor.&quot; The palace also announced the official souvenir program is available in stores.

## Huge mob ransacks California gas station; police 'outnumbered': video
 - [https://www.foxnews.com/us/huge-mob-ransacks-california-gas-station-police-outnumbered-video](https://www.foxnews.com/us/huge-mob-ransacks-california-gas-station-police-outnumbered-video)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 13:41:03+00:00

Video emerged showing a mob of California youth ransacking an Arco gas station in the Los Angeles area. Police were &quot;outnumbered&quot; and unable to intervene.

## Nebraska reveals new Herbie Husker logo after old one was accused of having White supremacy link
 - [https://www.foxnews.com/sports/nebraska-reveals-new-herbie-husker-logo-old-one-was-accused-having-white-supremacy-link](https://www.foxnews.com/sports/nebraska-reveals-new-herbie-husker-logo-old-one-was-accused-having-white-supremacy-link)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 13:37:35+00:00

The University of Nebraska revealed its new Herbie Husker logo on Monday after the old logo was accused of having a White supremacy link.

## ‘Hero’ Louisville police officer remains 'critical but stable' a week after bank shooting
 - [https://www.foxnews.com/us/hero-louisville-police-officer-remains-critical-stable-week-bank-shooting](https://www.foxnews.com/us/hero-louisville-police-officer-remains-critical-stable-week-bank-shooting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 13:30:09+00:00

Louisville Police Officer Nickolas Wilt, 26, was shot in the head within minutes of arriving at Old National Bank to stop a gunman during a mass shooting on April 10.

## Mother of NYC murder victim shouts down Democrat lawmaker: 'Don't insult my intelligence'
 - [https://www.foxnews.com/politics/mother-nyc-murder-victim-shouts-democrat-lamwaker-dont-insult-my-intelligence](https://www.foxnews.com/politics/mother-nyc-murder-victim-shouts-democrat-lamwaker-dont-insult-my-intelligence)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 13:22:55+00:00

Rep. Dan Goldman, D-N.Y., faced angry shouts from a witness at a field hearing in Manhattan as he attempted to use his time to accuse Republicans of protecting Donald Trump.

## 'The View' co-host Whoopi Goldberg flips out over Bud Light boycotts: 'IT'S JUST BEER'
 - [https://www.foxnews.com/media/the-view-co-host-whoopi-goldberg-flips-out-over-bud-light-boycotts-just-beer](https://www.foxnews.com/media/the-view-co-host-whoopi-goldberg-flips-out-over-bud-light-boycotts-just-beer)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 13:17:42+00:00

Whoopi Goldberg fumed over the Bud Light boycotts and backlash towards the beer company during Monday&apos;s &quot;The View,&quot; wondering what everyone was so mad about.

## Illinois state senator defends Chicago teens' rioting, looting: 'It's a mass protest'
 - [https://www.foxnews.com/politics/illinois-state-senator-defends-chicago-teens-rioting-looting-mass-protest](https://www.foxnews.com/politics/illinois-state-senator-defends-chicago-teens-rioting-looting-mass-protest)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 13:14:48+00:00

Illinois state Sen. Robert Peters claimed the Chicago &quot;Teen Takeover&quot; was to protest &quot;poverty and segregation,&quot; after several teens were arrested while storming the city streets.

## As US college enrollment declines, trade programs are booming
 - [https://www.foxnews.com/us/us-college-enrollment-declines-trade-programs-booming](https://www.foxnews.com/us/us-college-enrollment-declines-trade-programs-booming)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 13:10:39+00:00

Colleges are seeing few students register for classes across America. Instead, many students are opting into trade schools that offer more affordable and promising paths to a job.

## Ex-NBA star Jalen Rose comes to E-40's defense after ejection: Security 'totally fumbled this scenario'
 - [https://www.foxnews.com/sports/ex-nba-star-jalen-rose-comes-e-40s-defense-ejection-security-totally-fumbled-this-scenario](https://www.foxnews.com/sports/ex-nba-star-jalen-rose-comes-e-40s-defense-ejection-security-totally-fumbled-this-scenario)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 13:07:20+00:00

Former NBA star Jalen Rose came to the defense of E-40 after the rapper was ejected from the Golden State Warriors-Sacramento Kings&apos; playoff game Sunday.

## These high-tech glasses will subtitle real-life conversations
 - [https://www.foxnews.com/tech/high-tech-glasses-subtitle-real-life-conversations](https://www.foxnews.com/tech/high-tech-glasses-subtitle-real-life-conversations)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 13:02:06+00:00

A pair of glasses with augmented reality connects to your phone and can transcribe conversations as you have them, generate closed captioning and more.

## Animal activists downplay city's rat infestation, blame 'disgusting' human behavior
 - [https://www.foxnews.com/us/animal-activists-downplay-citys-rat-infestation-blame-disgusting-human-behavior](https://www.foxnews.com/us/animal-activists-downplay-citys-rat-infestation-blame-disgusting-human-behavior)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 13:00:46+00:00

The communications director for PETA acknowledged New York City&apos;s increasing rat problem but called on city leadership to reduce the number of rodents in the city humanely.

## Google CEO admits he, experts 'don't fully understand' how AI works
 - [https://www.foxnews.com/media/google-ceo-admits-experts-dont-fully-understand-ai-works](https://www.foxnews.com/media/google-ceo-admits-experts-dont-fully-understand-ai-works)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 13:00:40+00:00

Google CEP Sundar Pichai said he, nor other experts in the field, fully understand how artificial intelligence chatbots like ChatGPT or Google&apos;s Bard work.

## Piers Morgan calls out Democrat Katie Porter's woke 'nonsense' about Riley Gaines, women's sports
 - [https://www.foxnews.com/media/piers-morgan-calls-democrat-katie-porters-woke-nonsense-riley-gaines-womens-sports](https://www.foxnews.com/media/piers-morgan-calls-democrat-katie-porters-woke-nonsense-riley-gaines-womens-sports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 13:00:09+00:00

Piers Morgan discussed being on Bill Maher&apos;s show with Rep. Katie Porter, who claimed Riley Gaines was only defending girls in sports for &quot;clicks.&quot;

## Two NY residents arrested for running secret Chinese police station: 'Significant national security matter'
 - [https://www.foxnews.com/politics/two-ny-residents-arrested-running-secret-chinese-police-station-significant-national-security-matter](https://www.foxnews.com/politics/two-ny-residents-arrested-running-secret-chinese-police-station-significant-national-security-matter)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 12:59:34+00:00

Federal prosecutors and the FBI announced Monday the arrest of two people accused of running a secret police station for the Chinese government.

## 'We're doomed': Americans grade Biden's handling of China
 - [https://www.foxnews.com/politics/doomed-americans-grade-bidens-handling-china](https://www.foxnews.com/politics/doomed-americans-grade-bidens-handling-china)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 12:57:09+00:00

Americans gave poor marks on Biden&apos;s handling of China, America&apos;s standing in the world and if the U.S. should intervene in a Chinese invasion of Taiwan.

## Chicago police encourage people to enjoy what city 'has to offer' day after 'Teen Takeover' chaos
 - [https://www.foxnews.com/us/chicago-police-encourage-people-enjoy-city-has-offer-day-after-downtown-teen-riot](https://www.foxnews.com/us/chicago-police-encourage-people-enjoy-city-has-offer-day-after-downtown-teen-riot)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 12:55:20+00:00

The Chicago Police Department said it encourages people to &quot;enjoy everything the city has to offer&quot; after hundreds of teens caused chaos in the city&apos;s downtown Saturday.

## Texas man allegedly killed girlfriend for refusing to have his baby: report
 - [https://www.foxnews.com/us/texas-man-allegedly-killed-girlfriend-refusing-have-his-baby-report](https://www.foxnews.com/us/texas-man-allegedly-killed-girlfriend-refusing-have-his-baby-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 12:55:10+00:00

Adam Byrd allegedly killed his girlfriend, Jade Alyssa Alvarez, for her refusal to have his baby. He was charged with two counts of robbery days before the alleged murder.

## Derek Chauvin's murder conviction upheld in Minnesota Court of Appeals
 - [https://www.foxnews.com/us/derek-chauvins-murder-conviction-upheld-minnesota-court-appeals](https://www.foxnews.com/us/derek-chauvins-murder-conviction-upheld-minnesota-court-appeals)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 12:54:51+00:00

Derek Chauvin&apos;s murder conviction has been upheld in the Minnesota Court of Appeals. Chauvin was involved in the 2020 killing of George Floyd that sparked national protests.

## Alec Baldwin slams Halyna Hutchins' family as 'misguided' in request to dismiss wrongful death lawsuit
 - [https://www.foxnews.com/entertainment/alec-baldwin-slams-halyna-hutchins-family-misguided-request-dismiss-wrongful-death-lawsuit](https://www.foxnews.com/entertainment/alec-baldwin-slams-halyna-hutchins-family-misguided-request-dismiss-wrongful-death-lawsuit)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 12:46:29+00:00

Alec Baldwin and the production of &quot;Rust&quot; were sued by Halyna Hutchins&apos; family in February following the fatal 2021 shooting. Baldwin has asked for the lawsuit to be dismissed.

## Slovakia, Poland, Hungary ban food imports from Ukraine leading to objections from EU
 - [https://www.foxnews.com/world/slovakia-poland-hungary-ban-food-imports-ukraine-leading-objections-eu](https://www.foxnews.com/world/slovakia-poland-hungary-ban-food-imports-ukraine-leading-objections-eu)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 12:45:22+00:00

Three countries have announced they are banning grain imports from Ukraine. The bans came in response to anger from farmers who say the grain imports are causing economic hardships.

## Chinese Basketball Association teams booted from playoffs after match-fixing probe
 - [https://www.foxnews.com/sports/chinese-basketball-association-teams-booted-playoffs-match-fixing-probe](https://www.foxnews.com/sports/chinese-basketball-association-teams-booted-playoffs-match-fixing-probe)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 12:44:39+00:00

The Chinese Basketball Association announced discipline for two teams that were under investigation for match-fixing during the playoffs.

## Father-daughter duo qualify for Boston Marathon together
 - [https://www.foxnews.com/us/father-daughter-duo-qualify-boston-marathon-together](https://www.foxnews.com/us/father-daughter-duo-qualify-boston-marathon-together)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 12:44:04+00:00

A West Virginia father and his Washington daughter both qualified for the Boston Marathon together after finishing the Philadelphia Marathon in 2021.

## Climate change, disease, habitat loss killing bats across North America, according to scientists
 - [https://www.foxnews.com/us/climate-change-disease-habitat-loss-killing-bats-across-north-america-according-scientists](https://www.foxnews.com/us/climate-change-disease-habitat-loss-killing-bats-across-north-america-according-scientists)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 12:39:46+00:00

Bat species across North America are expected to diminish significantly due to climate change, disease, and habitat loss. Eight species of bats in the U.S. are listed as endangered.

## Spanish hospital carries out lung transplant using 4-armed robot dubbed 'Da Vinci'
 - [https://www.foxnews.com/world/spanish-hospital-carries-lung-transplant-using-4-armed-robot-dubbed-da-vinci](https://www.foxnews.com/world/spanish-hospital-carries-lung-transplant-using-4-armed-robot-dubbed-da-vinci)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 12:37:07+00:00

A lung transplant was carried out at a Spanish hospital using a four-armed robot that is known as &quot;Da Vinci.&quot; The new procedure is allegedly less painful for the patient.

## Rockies' Noah Davis narrowly avoids screaming comebacker, hat gets knocked off
 - [https://www.foxnews.com/sports/rockies-noah-davis-narrowly-avoids-screaming-comebacker-hat-gets-knocked-off](https://www.foxnews.com/sports/rockies-noah-davis-narrowly-avoids-screaming-comebacker-hat-gets-knocked-off)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 12:36:49+00:00

Colorado Rockies pitcher Noah Davis had his head nearly knocked off on a screamer back to the pitcher&apos;s mound against the Seattle Mariners on Sunday.

## LIV golfer Jed Morgan wants more events, calls time off 'frustrating'
 - [https://www.foxnews.com/sports/liv-golfer-jed-morgan-wants-more-events-calls-time-off-frustrating](https://www.foxnews.com/sports/liv-golfer-jed-morgan-wants-more-events-calls-time-off-frustrating)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 12:36:22+00:00

LIV Golf competitor Jed Morgan wants the Saud-funded league to schedule more tournaments in the future. He called the time off &quot;frustrating.&quot;

## California Democrat admits ban on state travel to red states didn't work: 'It separates us'
 - [https://www.foxnews.com/media/california-democrat-admits-ban-state-travel-red-states-didnt-work-seperates-us](https://www.foxnews.com/media/california-democrat-admits-ban-state-travel-red-states-didnt-work-seperates-us)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 12:33:20+00:00

California Democrat Toni Atkins admitted to the LA Times that the travel ban against 23 states she voted for in 2016 was &apos;polarizing&apos; and a turn-off to everyday Americans.

## Alabama hospital received over a dozen teens wounded in mass shooting
 - [https://www.foxnews.com/us/alabama-hospital-received-dozen-teens-wounded-mass-shooting](https://www.foxnews.com/us/alabama-hospital-received-dozen-teens-wounded-mass-shooting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 12:32:15+00:00

Heidi Smith, director of marketing for Ivy Creek Healthcare, said that Lake Martin Community Hospital received 15 teen patients after a shooting Saturday night.

## NYC mother says Alvin Bragg's office treated her 'like garbage' after 'brutal slaughter' of her veteran son
 - [https://www.foxnews.com/politics/nyc-mother-says-alvin-braggs-office-treated-her-like-garbage-brutal-slaughter-her-veteran-son](https://www.foxnews.com/politics/nyc-mother-says-alvin-braggs-office-treated-her-like-garbage-brutal-slaughter-her-veteran-son)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 12:26:36+00:00

Madeline Brame blasted Manhattan District Attorney Alvin Bragg for treating her family &quot;like garbage&quot; and botching the prosecution of her son&apos;s killers.

## Father of antisemitic hate crime victim rips Schumer, Nadler for their silence: ‘I call you out’
 - [https://www.foxnews.com/politics/father-antisemitic-hate-crime-victim-rips-schumer-nadler-silence-call-you-out](https://www.foxnews.com/politics/father-antisemitic-hate-crime-victim-rips-schumer-nadler-silence-call-you-out)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 12:25:28+00:00

A witness at a House Judiciary Committee hearing in New York accused Jewish Democrats of being silent on antisemitic violence that took place in the city.

## Rep. Hank Johnson accuses relatives of crime victims of being 'props in a MAGA Broadway production'
 - [https://www.foxnews.com/politics/rep-hank-johnson-accuses-relatives-crime-victims-being-props-maga-broadway-production](https://www.foxnews.com/politics/rep-hank-johnson-accuses-relatives-crime-victims-being-props-maga-broadway-production)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 12:09:18+00:00

Rep. Hank Johnson, D-Ga., accused the family members of New York City crime victims testifying before Congress Monday of being &quot;props in a MAGA Broadway production.&quot;

## Tom Brady’s ex Gisele Bündchen gives inspirational message after divorce
 - [https://www.foxnews.com/entertainment/tom-bradys-ex-gisele-bundchen-inspirational-message-after-divorce](https://www.foxnews.com/entertainment/tom-bradys-ex-gisele-bundchen-inspirational-message-after-divorce)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 12:08:09+00:00

Gisele Bündchen talks about how &quot;nothing is permanent&quot; in an intimate message she shared to Instagram in the wake of her divorce from Tom Brady.

## Massachusetts woman accused of killing cop boyfriend could be exonerated with new evidence: defense
 - [https://www.foxnews.com/us/massachusetts-woman-accused-killing-cop-boyfriend-could-exonerated-new-evidence-defense](https://www.foxnews.com/us/massachusetts-woman-accused-killing-cop-boyfriend-could-exonerated-new-evidence-defense)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 12:03:29+00:00

Defense attorneys for Massachusetts professor Karen Read, who is accused of killing her cop boyfriend in a drunk driving incident, say new evidence could exonerate her.

## California DA who floated keeping gang members accused of killing toddler out of jail faces recall backlash
 - [https://www.foxnews.com/us/california-da-who-floated-keeping-gang-members-accused-killing-toddler-out-jail-faces-recall-backlash](https://www.foxnews.com/us/california-da-who-floated-keeping-gang-members-accused-killing-toddler-out-jail-faces-recall-backlash)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 12:02:31+00:00

DA Pamela Price of Alameda County is facing backlash for suggesting no prison time in a toddler&apos;s shooting death in a suspected gang-related crossfire.

## Wall Street Journal reporter imprisoned in Russia says he’s ‘not losing hope’ in handwritten letter to family
 - [https://www.foxnews.com/media/wall-street-journal-reporter-imprisoned-russia-losing-hope-handwritten-letter-family](https://www.foxnews.com/media/wall-street-journal-reporter-imprisoned-russia-losing-hope-handwritten-letter-family)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 12:00:43+00:00

Evan Gershkovich, detained in Russia since last month on dubious espionage charges, said he’s &quot;not losing hope&quot; in a hand-written letter to his parents.

## Biden's green energy plans pose national security risk, Pentagon warns
 - [https://www.foxnews.com/politics/bidens-green-energy-plans-pose-national-security-risk-pentagon-warns](https://www.foxnews.com/politics/bidens-green-energy-plans-pose-national-security-risk-pentagon-warns)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 12:00:36+00:00

The Pentagon is warning wind energy developers and other key stakeholders that massive offshore leasing areas could significantly conflict with military operations.

## Stunning indoor houseplants to brighten any space in your home this spring
 - [https://www.foxnews.com/lifestyle/indoor-plants-spring-season](https://www.foxnews.com/lifestyle/indoor-plants-spring-season)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 11:56:49+00:00

If you&apos;re looking to brighten your space for the spring season, indoor houseplants are often easy to care for an a pretty accent piece to add to any room.

## Former Navy NCO running pro-Russian social account under investigation for helping spread classified documents
 - [https://www.foxnews.com/us/former-navy-nco-running-pro-russian-social-account-under-investigation-helping-spread-classified-documents](https://www.foxnews.com/us/former-navy-nco-running-pro-russian-social-account-under-investigation-helping-spread-classified-documents)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 11:51:26+00:00

A former sailor in the U.S. Navy is being investigated for her role in helping spread classified documents originally leaked by Massachusetts Air Guardsman Jack Teixeira.

## Air Force veteran in Virginia breaks Guinness World Record for dumbbell curls
 - [https://www.foxnews.com/us/air-force-veteran-virginia-breaks-guinness-world-record-dumbbell-curls](https://www.foxnews.com/us/air-force-veteran-virginia-breaks-guinness-world-record-dumbbell-curls)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 11:47:29+00:00

An Air Force veteran has broken the Guinness World Record by curling dumbbells. The Virginia Beach resident lifted over two tons in one minute.

## 49ers’ Brock Purdy to report to offseason workouts amid elbow rehab: report
 - [https://www.foxnews.com/sports/49ers-brock-purdy-report-offseason-workouts-amid-elbow-rehab-report](https://www.foxnews.com/sports/49ers-brock-purdy-report-offseason-workouts-amid-elbow-rehab-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 11:45:59+00:00

San Francisco 49ers quarterback Brock Purdy said Friday he plans to report to the voluntary offseason program on Monday, just over a month after undergoing elbow surgery.

## Cancer claims bride's life just five days after wedding: Wife looked 'absolutely gorgeous,' says widower
 - [https://www.foxnews.com/lifestyle/cancer-claims-brides-life-five-days-wedding-wife-gorgeous-widower](https://www.foxnews.com/lifestyle/cancer-claims-brides-life-five-days-wedding-wife-gorgeous-widower)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 11:45:08+00:00

A couple from Ireland married just days before the bride passed away of breast cancer. The couple has two children together and were engaged for seven years.

## Hong Kong's Catholic bishop arrives in China, first visit in nearly 3 decades
 - [https://www.foxnews.com/world/hong-kongs-catholic-bishop-arrives-china-first-visit-nearly-3-decades](https://www.foxnews.com/world/hong-kongs-catholic-bishop-arrives-china-first-visit-nearly-3-decades)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 11:44:15+00:00

Bishop Stephen Chow, the Roman Catholic Bishop of Hong Kong, has arrived in Beijing, China. This is Chow&apos;s first visit to China in three decades.

## Alex Murdaugh says prison conditions make it hard to defend against Satterfield lawsuit
 - [https://www.foxnews.com/us/alex-murdaugh-says-prison-conditions-make-hard-defend-against-satterfield-lawsuit](https://www.foxnews.com/us/alex-murdaugh-says-prison-conditions-make-hard-defend-against-satterfield-lawsuit)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 11:43:12+00:00

Convicted murderer Alex Murdaugh says he needs more time to fight a federal insurance fraud lawsuit due to restrictive conditions at his maximum security prison.

## House will vote soon to cap federal spending at 2022 level, raise debt limit for one year: McCarthy
 - [https://www.foxnews.com/politics/house-vote-soon-cap-federal-spending-2022-level-raise-debt-limit-one-year-mccarthy](https://www.foxnews.com/politics/house-vote-soon-cap-federal-spending-2022-level-raise-debt-limit-one-year-mccarthy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 11:37:02+00:00

House Speaker Kevin McCarthy was at the New York Stock Exchange on Monday morning to discuss the status of debt limit talks with the country&apos;s business leaders

## UFC champ Israel Adesanya praises Andrew Tate, Jordan Peterson for 'pushing men to be accountable'
 - [https://www.foxnews.com/sports/ufc-champ-israel-adesanya-praises-andrew-tate-jordan-peterson-pushing-men-accountable](https://www.foxnews.com/sports/ufc-champ-israel-adesanya-praises-andrew-tate-jordan-peterson-pushing-men-accountable)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 11:35:54+00:00

UFC champion Israel Adesanya praised Andrew Tate, Jordan Peterson and Dave Goggins in a recent podcast interview talking about the development of men.

## Jalen Hurts, Eagles agree to historic contract extension after Super Bowl run: reports
 - [https://www.foxnews.com/sports/jalen-hurts-eagles-agree-historic-contract-extension-super-bowl-run-reports](https://www.foxnews.com/sports/jalen-hurts-eagles-agree-historic-contract-extension-super-bowl-run-reports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 11:30:43+00:00

The Eagles and Jalen Hurts agreed to a lucrative contract extension on Monday that will make him one of the highest-paid players in the NFL, according to multiple reports.

## Jimmy Butler pokes fun at Bucks after Heat win in Game 1
 - [https://www.foxnews.com/sports/jimmy-butler-pokes-fun-bucks-heat-win-game-1](https://www.foxnews.com/sports/jimmy-butler-pokes-fun-bucks-heat-win-game-1)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 11:30:24+00:00

Miami Heat star Jimmy Butler led the team to a Game 1 victory over the Milwaukee Bucks and poked fun at his opponents after the matchup.

## LA business owner closes stores after 12th break-in: 'Can't do it anymore'
 - [https://www.foxnews.com/media/la-business-close-doors-12th-break-cant-anymore](https://www.foxnews.com/media/la-business-close-doors-12th-break-cant-anymore)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 11:30:16+00:00

Los Angeles-based business owner Evette Ingram is closing her beauty business after her stores were hit a dozen times by thieves, citing the toll on her mental health.

## Brain teaser: Remember PEMDAS? Try solving this math equation
 - [https://www.foxnews.com/lifestyle/brain-teaser-remember-pemdas-try-solving-math-equation](https://www.foxnews.com/lifestyle/brain-teaser-remember-pemdas-try-solving-math-equation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 11:28:07+00:00

Test your knowledge of algebra along with your spot-the-difference skills with this food-themed math problem that uses fruits in place of numbers.

## Female teacher fired, forced to apologize after saying ‘good afternoon, girls’ to students: report
 - [https://www.foxnews.com/media/female-teacher-fired-forced-apologize-saying-good-afternoon-girls-students-report](https://www.foxnews.com/media/female-teacher-fired-forced-apologize-saying-good-afternoon-girls-students-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 11:26:41+00:00

A teacher in the U.K. was reportedly forced to apologize and fired after she misgendered some of her 11-year-old students at an expensive private school.

## Major law firms funneling money from state, local governments to Dem candidates, watchdog says
 - [https://www.foxnews.com/politics/major-law-firms-funneling-money-state-local-governments-dem-candidates-watchdog-says](https://www.foxnews.com/politics/major-law-firms-funneling-money-state-local-governments-dem-candidates-watchdog-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 11:26:41+00:00

Several of the country&apos;s most prestigious law firms are siphoning taxpayer money from state and local governments through public contracts, according to a watchdog group.

## Taliban closes education centers, institutes supported by non-government groups in southern Afghanistan
 - [https://www.foxnews.com/world/taliban-closes-education-centers-institutes-supported-non-government-groups-southern-afghanistan](https://www.foxnews.com/world/taliban-closes-education-centers-institutes-supported-non-government-groups-southern-afghanistan)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 11:19:58+00:00

The Taliban is closing institutes that aren&apos;t supported by government groups and education centers in the southern part of Afghanistan.

## Chinese defense ministers' tour of top Russian military academy underscores close ties between Moscow, Beijing
 - [https://www.foxnews.com/world/chinese-defense-ministers-tour-top-russian-military-academy-close-ties-between-moscow-beijing](https://www.foxnews.com/world/chinese-defense-ministers-tour-top-russian-military-academy-close-ties-between-moscow-beijing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 11:19:02+00:00

Vladimir Putin hosted China&apos;s Defense Minister Gen. Li Shangfu in the Kremlin on Sunday. Shangfu&apos;s tour of a Russian military academy highlighted the ties between the countries.

## Court rejects Trump's request for month-long delay in defamation trial
 - [https://www.foxnews.com/politics/court-rejects-trumps-request-month-long-delay-defamation-trial](https://www.foxnews.com/politics/court-rejects-trumps-request-month-long-delay-defamation-trial)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 11:08:24+00:00

Former President Donald Trump&apos;s defamation trial against rape accusder E. Jean Carroll will move forward as planned on April 25 after a federal judge denied his request for a delay.

## The 2024 Buick Envista is the brand's new 'cheap' SUV
 - [https://www.foxnews.com/auto/2024-buick-envista-suv-cheap-model](https://www.foxnews.com/auto/2024-buick-envista-suv-cheap-model)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 11:01:34+00:00

The 2024 Buick Envista will be the brand&apos;s lowest-priced model when it goes on sale this summer. The subcompact SUV will have a starting price of $23,495.

## Be well: Take smart steps to reduce the stress of caregiving
 - [https://www.foxnews.com/health/be-well-take-smart-steps-reduce-stress-caregiving](https://www.foxnews.com/health/be-well-take-smart-steps-reduce-stress-caregiving)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 10:58:46+00:00

While caring for loved ones can be personally rewarding, it can also be a source of significant stress. A registered nurse offers tips on preventing exhausting and burnout.

## Kamala Harris ally knocks Biden on abortion issue: 'She is far more comfortable on this topic'
 - [https://www.foxnews.com/media/kamala-harris-ally-knocks-biden-abortion-issue-she-far-more-comfortable-topic](https://www.foxnews.com/media/kamala-harris-ally-knocks-biden-abortion-issue-she-far-more-comfortable-topic)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 10:56:47+00:00

President Biden is reportedly hoping Vice President Harris can deliver on abortion messaging and that the issue will give her a &quot;fresh look&quot; ahead of 2024.

## NC House Speaker Tim Moore spends legislative break visiting Ukraine, helping humanitarian workers
 - [https://www.foxnews.com/politics/nc-house-speaker-tim-moore-spends-legislative-break-visiting-ukraine-helping-humanitarian-workers](https://www.foxnews.com/politics/nc-house-speaker-tim-moore-spends-legislative-break-visiting-ukraine-helping-humanitarian-workers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 10:56:28+00:00

During North Carolina’s legislative break, House Speaker Tim Moore visited Ukraine to help humanitarian workers and observe the country as it battles against Russia.

## How this new banking trojan can steal your financial information
 - [https://www.foxnews.com/tech/new-banking-trojan-steal-financial-information](https://www.foxnews.com/tech/new-banking-trojan-steal-financial-information)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 10:55:41+00:00

Kurt &quot;CyberGuy&quot; Knutsson explains what a banking trojan is, and how this kind of app can disguise itself as a familiar app to steal your sensitive information.

## German Chancellor Olaf Scholz's wife steps down as Brandenburg education minister
 - [https://www.foxnews.com/world/german-chancellor-olaf-scholzs-wife-steps-down-brandenburg-education-minister](https://www.foxnews.com/world/german-chancellor-olaf-scholzs-wife-steps-down-brandenburg-education-minister)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 10:54:59+00:00

Britta Ernst, the wife of German Chancellor Olaf Scholz, is stepping down as the Brandenburg education minister. She has served as the education minister since 2017.

## Republican states targeting diversity, inclusion efforts in higher education
 - [https://www.foxnews.com/politics/republican-states-targeting-diversity-inclusion-efforts-higher-education](https://www.foxnews.com/politics/republican-states-targeting-diversity-inclusion-efforts-higher-education)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 10:53:09+00:00

Republican states, including Texas, are targeting diversity, equity, and inclusion efforts in higher education. The bills are part of a recent GOP efforts to limit critical race theory.

## Mother in ‘pure agony’ as search continues for Americans who vanished off Mexico coast
 - [https://www.foxnews.com/world/mother-pure-agony-search-continues-americans-who-vanished-mexico-coast](https://www.foxnews.com/world/mother-pure-agony-search-continues-americans-who-vanished-mexico-coast)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 10:52:13+00:00

The mother of one of the three missing Americans who went missing off the coast of Mexico earlier this month during a sailing trip said her daughter and her daughter&apos;s husband were experienced sailors.

## Yuengling appears to take shot at Bud Light with 'perfectly timed' tweet
 - [https://www.foxnews.com/media/yuengling-appears-take-shot-bud-light-perfectly-timed-tweet](https://www.foxnews.com/media/yuengling-appears-take-shot-bud-light-perfectly-timed-tweet)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 10:35:08+00:00

Beer company Yuengling sent out a curiously timed tweet after competitor Bud Light put out a lengthy statement admist the Dylan Mulvaney controversy.

## Elon Musk to develop 'TruthGPT' as he warns about 'civilizational destruction' from AI
 - [https://www.foxnews.com/media/elon-musk-develop-truthgpt-warns-civilizational-destruction-ai](https://www.foxnews.com/media/elon-musk-develop-truthgpt-warns-civilizational-destruction-ai)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 10:25:54+00:00

Tech mogul Elon Musk broke the news to Tucker Carlson during an exclusive sit-down interview citing safety concerns over the alleged left-wing AI app ChatGPT

## Fetterman will chair first subcommittee hearing days after returning from weeks-long absence
 - [https://www.foxnews.com/politics/fetterman-chair-first-subcommittee-hearing-days-returning-weeks-long-absence](https://www.foxnews.com/politics/fetterman-chair-first-subcommittee-hearing-days-returning-weeks-long-absence)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 10:22:56+00:00

Sen. John Fetterman is expected to return to Capitol Hill on Monday after checking himself in to Walter Reed Medical Center in February for depression.

## Gunman opens fire in LA at volunteers who offered to paint over graffiti at ice cream shop
 - [https://www.foxnews.com/us/gunman-opens-fire-la-volunteers-offered-paint-graffiti-ice-cream-shop](https://www.foxnews.com/us/gunman-opens-fire-la-volunteers-offered-paint-graffiti-ice-cream-shop)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 10:17:15+00:00

Several people were injured and one person was killed after a shooter opened fire at a neighborhood ice cream shop in Los Angeles, California.

## Freak storm in southern Thailand capsizes a dozen fishing boats, kills at least 3
 - [https://www.foxnews.com/us/freak-storm-southern-thailand-capsizes-dozen-fishing-boats-kills-least-3](https://www.foxnews.com/us/freak-storm-southern-thailand-capsizes-dozen-fishing-boats-kills-least-3)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 10:06:07+00:00

Thailand was hit by a freak storm that killed at least three people and capsized a dozen fishing boats. Over 100 others who were also at sea have been accounted for.

## Divers off Seattle inspect grounded ferry after it loses power, runs aground
 - [https://www.foxnews.com/us/divers-seattle-inspect-grounded-ferry-loses-power-runs-aground](https://www.foxnews.com/us/divers-seattle-inspect-grounded-ferry-loses-power-runs-aground)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 10:05:38+00:00

Divers off Seattle, Washington, have begun investigating the hull of a ferry that ran aground after losing power. The incident affected 600 people.

## Shooting of Black teen who went to wrong house investigated
 - [https://www.foxnews.com/us/shooting-black-teen-went-wrong-house-investigated](https://www.foxnews.com/us/shooting-black-teen-went-wrong-house-investigated)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 10:05:12+00:00

An investigation is currently underway after a Black teenager was shot by a homeowner after entering the wrong house attempting to pick up his younger brothers.

## Suspect who killed hostage at California park wore body-armor vest, report says
 - [https://www.foxnews.com/us/suspect-killed-hostage-california-park-wore-body-armor-vest-report](https://www.foxnews.com/us/suspect-killed-hostage-california-park-wore-body-armor-vest-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 10:05:08+00:00

The suspect accused of killing one hostage, injuring another, and shooting at officers at a Roseville, California, public park was wearing a body-armor vest, according to authorities.

## Ohio pro-life pregnancy center attacked by radical 'Jane's Revenge' group: 'Abort God'
 - [https://www.foxnews.com/politics/ohio-pro-life-pregnancy-center-attacked-radical-janes-revenge-abort-god](https://www.foxnews.com/politics/ohio-pro-life-pregnancy-center-attacked-radical-janes-revenge-abort-god)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 10:01:46+00:00

A pro-life pregnancy center in Ohio was attacked by the radical pro-choice group &quot;Jane&apos;s Revenge&quot; and was hit with anti-Christian and pro-abortion graffiti.

## America’s State Department was seized by one political party. Here’s how to stop them
 - [https://www.foxnews.com/opinion/americas-state-department-seized-one-political-party-heres-how-stop-them](https://www.foxnews.com/opinion/americas-state-department-seized-one-political-party-heres-how-stop-them)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 10:00:49+00:00

America’s State Department was seized by one political party. Here’s how to stop them. Federal workers use foreign-policy operations to push leftist causes.

## Narcan administered to save 2-year-old in Virginia, police say
 - [https://www.foxnews.com/us/narcan-administered-save-2-year-old-virginia-police-say](https://www.foxnews.com/us/narcan-administered-save-2-year-old-virginia-police-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 09:57:08+00:00

Police in Manassas Park, Virginia, have arrested two women after Narcan was used to save the life of a 2-year-old child whom law enforcement found “unresponsive.&quot;

## House, Senate Republicans push for rules change to ban use of TikTok
 - [https://www.foxnews.com/politics/house-senate-republicans-push-rules-change-ban-use-tiktok](https://www.foxnews.com/politics/house-senate-republicans-push-rules-change-ban-use-tiktok)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 09:36:10+00:00

GOP lawmakers in the House and Senate called for rules committee leaders to ban their colleagues from using the Chinese-owned app TikTok for communications on Monday.

## Crime victims unload on NYC mayor, DA: 'I don't understand how anybody can feel safe here'
 - [https://www.foxnews.com/media/crime-victims-unload-nyc-mayor-da-dont-understand-anybody-feel-safe](https://www.foxnews.com/media/crime-victims-unload-nyc-mayor-da-dont-understand-anybody-feel-safe)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 09:31:59+00:00

Crime victims will testify before the House Judiciary Committee in NYC on Monday as Alvin Bragg and Eric Adams remain under fire for progressive policies.

## Alternative Inventor? Biden admin opens door to non-human, AI patent holders
 - [https://www.foxnews.com/politics/ai-credit-inventor-biden-administration-opens-door-non-human-patent-holders](https://www.foxnews.com/politics/ai-credit-inventor-biden-administration-opens-door-non-human-patent-holders)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 09:27:26+00:00

The U.S. Patent and Trademark Office is asking for comment on whether AI systems should somehow be given credit for patentable inventions, instead of just humans.

## Gwyneth Paltrow reflects on ski crash trial for the first time
 - [https://www.foxnews.com/entertainment/gwyneth-paltrow-reflects-ski-crash-trial-first-time](https://www.foxnews.com/entertainment/gwyneth-paltrow-reflects-ski-crash-trial-first-time)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 09:23:56+00:00

Gwyneth Paltrow won her ski crash trial on March 30 when a jury decided she was not guilty of hitting her plaintiff on a slope in Deer Valley. Now, she is opening up about the experience.

## Europe’s most powerful nuclear reactor kicks off in Finland, helping country cut off energy ties from Russia
 - [https://www.foxnews.com/world/europes-powerful-nuclear-reactor-kicks-finland-helping-country-cut-energy-ties-russia](https://www.foxnews.com/world/europes-powerful-nuclear-reactor-kicks-finland-helping-country-cut-energy-ties-russia)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 09:22:50+00:00

Olkiluoto 3, Europe’s most powerful nuclear reactor, finally began regular production in Finland after a delay of 14 years. The reactor will help the country reach carbon neutrality.

## United States agrees to help finance Poland's nuclear energy plan
 - [https://www.foxnews.com/world/united-states-agrees-help-finance-polands-nuclear-energy](https://www.foxnews.com/world/united-states-agrees-help-finance-polands-nuclear-energy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 09:20:56+00:00

Two United States financial institutions agreed to help finance a nuclear energy plan in Poland. Poland is moving toward renewable and noncarbon energy.

## French President Emmanuel Macron to address nation in attempt to calm public anger regarding pension reform
 - [https://www.foxnews.com/world/french-president-emmanuel-macron-address-nation-attempt-calm-public-anger-regarding-pension-reform](https://www.foxnews.com/world/french-president-emmanuel-macron-address-nation-attempt-calm-public-anger-regarding-pension-reform)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 09:18:20+00:00

Emmanuel Macron, the president of France, is set to address the nation on April 17, 2023, in an attempt to calm public anger regarding his pension reform plans.

## Jaguars' Doug Pederson praises USFL as way to get 'meaningful reps'
 - [https://www.foxnews.com/sports/jaguars-doug-pederson-praises-usfl-way-get-meaningful-reps](https://www.foxnews.com/sports/jaguars-doug-pederson-praises-usfl-way-get-meaningful-reps)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 09:16:39+00:00

Jacksonville Jaguars coach Doug Pederson had nothing but praise for the USFL as he watched his son Josh play for the Houston Gamblers on Sunday.

## LSU's Angel Reese latest Tigers athlete to ink NIL deal with Caktus AI
 - [https://www.foxnews.com/sports/lsus-angel-reese-latest-tigers-athlete-ink-nil-deal-caktus-ai](https://www.foxnews.com/sports/lsus-angel-reese-latest-tigers-athlete-ink-nil-deal-caktus-ai)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 09:15:03+00:00

LSU star Angel Reese was the latest to ink a name, image and likeness deal with the AI company Caktus AI. Olivia Dunne had also partnered with the brand.

## Midwest, Great Lakes facing wintry weather and blizzard conditions
 - [https://www.foxnews.com/weather/midwest-great-lakes-facing-wintry-weather-blizzard-conditions](https://www.foxnews.com/weather/midwest-great-lakes-facing-wintry-weather-blizzard-conditions)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 09:10:46+00:00

A storm system bringing snow and blizzard conditions is impacting the Upper Midwest and Great Lakes on Monday, making travel difficult.

## Suspected gang members in California charged in killing of 5-year-old girl after targeting wrong vehicle
 - [https://www.foxnews.com/us/suspected-gang-members-california-charged-killing-5-year-old-girl-targeting-wrong-vehicle](https://www.foxnews.com/us/suspected-gang-members-california-charged-killing-5-year-old-girl-targeting-wrong-vehicle)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 09:09:27+00:00

Several alleged gang members in San Francisco, California, are charged with killing a child in a drive-by shooting. The members allegedly mistook the target as a rival gang’s vehicle.

## US sails warship in Taiwan Strait following China's drills in region
 - [https://www.foxnews.com/world/us-sails-warship-taiwan-strait-chinas-drills-region](https://www.foxnews.com/world/us-sails-warship-taiwan-strait-chinas-drills-region)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 09:08:51+00:00

The U.S. Navy deployed a warship to the Taiwan Strait on Sunday, the first such maneuver since China ended its military operations surrounding the self-governed island.

## Gates funds millions to NGO claiming kids born sexual, 10-year-olds should learn about 'commercial sex work'
 - [https://www.foxnews.com/media/gates-funded-ngo-claims-children-born-sexual-10-year-olds-should-learn-about-commercial-sex-work](https://www.foxnews.com/media/gates-funded-ngo-claims-children-born-sexual-10-year-olds-should-learn-about-commercial-sex-work)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 09:00:35+00:00

The Bill &amp; Melinda Gates Foundation donated millions to organization claiming children are born sexual and should learn about sexual attraction to different gender identities.

## Pizza delivery man trips suspect on the run from police: video
 - [https://www.foxnews.com/us/pizza-delivery-man-trips-suspect-run-police-video](https://www.foxnews.com/us/pizza-delivery-man-trips-suspect-run-police-video)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 08:54:19+00:00

Tyler Morrell, a pizza delivery driver for Cocco&apos;s Pizza in Aston, Pennsylvania, lent a hand -- or in this case, a foot -- to help trip up a suspect who was fleeing police.

## Blackburn endorses Trump for president: 'Can't wait until he's back'
 - [https://www.foxnews.com/politics/blackburn-endorses-trump-president-cant-wait-back](https://www.foxnews.com/politics/blackburn-endorses-trump-president-cant-wait-back)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 08:51:35+00:00

Tennessee Republican Senator Marsha Blackburn on Monday endorsed Donald Trump for president in 2024, adding to the growing list of Republicans in Trump&apos;s column.

## 2 dead, 5 injured in Hawaii after gunman opens fire at illegal cockfight
 - [https://www.foxnews.com/us/2-dead-5-injured-hawaii-gunman-opens-fire-illegal-cockfight](https://www.foxnews.com/us/2-dead-5-injured-hawaii-gunman-opens-fire-illegal-cockfight)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 08:47:22+00:00

A couple of people were fatally shot at a late-night cockfight in Honolulu, Hawaii, on Friday. Five other people also sustained gunshot injuries and were taken to the hospital.

## Hundreds of French firefighters battle country's biggest forest fire so far this year
 - [https://www.foxnews.com/world/hundreds-french-firefighters-battle-countrys-biggest-forest-fire-year](https://www.foxnews.com/world/hundreds-french-firefighters-battle-countrys-biggest-forest-fire-year)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 08:44:02+00:00

Hundreds of firefighters in France are battling the country&apos;s largest wildfire this year. The fire burned over 2,500 acres of land along the Mediterranean coast.

## House Homeland Republicans mark 100 days of ‘well overdue’ oversight on border crisis, China
 - [https://www.foxnews.com/politics/house-homeland-republicans-mark-100-days-well-overdue-oversight-border-crisis-china](https://www.foxnews.com/politics/house-homeland-republicans-mark-100-days-well-overdue-oversight-border-crisis-china)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 08:40:50+00:00

House Homeland Republicand are marking 100 days of what they say is &quot;well overdue&quot; oversight of DHS on issues including the migrant crisis at the southern border and China.

## MSNBC host complains pro-life abortion laws are 'Christian Shariah'
 - [https://www.foxnews.com/media/msnbc-host-complains-pro-life-abortion-laws-christian-shariah](https://www.foxnews.com/media/msnbc-host-complains-pro-life-abortion-laws-christian-shariah)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 08:39:10+00:00

MSNBC host Ali Velshi compared GOP pro-life laws to a Christian fundamentalist version of Islamic &apos;shariah&apos; laws during a podcast appearance this week.

## Chinese national arrested in Pakistan after allegedly insulting Islam, Prophet Muhammad
 - [https://www.foxnews.com/world/chinese-national-arrested-pakistan-allegedly-insulting-islam-prophet-muhammad](https://www.foxnews.com/world/chinese-national-arrested-pakistan-allegedly-insulting-islam-prophet-muhammad)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 08:39:02+00:00

A Chinese national was arrested in Pakistan for allegedly insulting Islam and the Prophet Mohammad. The offenses carry the death penalty under Pakistan&apos;s controversial blasphemy laws.

## Alabama house that was safe haven for Martin Luther King Jr. moving to Michigan museum
 - [https://www.foxnews.com/us/alabama-house-safe-haven-martin-luther-king-jr-moving-michiga-museum](https://www.foxnews.com/us/alabama-house-safe-haven-martin-luther-king-jr-moving-michiga-museum)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 08:33:33+00:00

The house that was a safe haven to Rev. Martin Luther King Jr. in Alabama is being moved to Michigan. It will be opened to the public as part of the history museum.

## The Ford Mustang was the world's most popular sports car of the past decade with 1 million sales
 - [https://www.foxnews.com/auto/ford-mustang-worlds-most-popular-sports-car-decade-million-sales](https://www.foxnews.com/auto/ford-mustang-worlds-most-popular-sports-car-decade-million-sales)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 08:30:29+00:00

The Ford Mustang was the best-selling sports car in the world over the past decade and has also been the top model in the U.S. so far this year.

## USFL Week 1 recap: Stallions begin repeat pursuit on high note, Stars spoil Showboats' debut
 - [https://www.foxnews.com/sports/usfl-week-1-recap-stallions-begin-repeat-pursuit-high-note-stars-spoil-showboats-debut](https://www.foxnews.com/sports/usfl-week-1-recap-stallions-begin-repeat-pursuit-high-note-stars-spoil-showboats-debut)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 08:27:12+00:00

Each of the USFL&apos;s eight teams were in action over the weekend as the spring league&apos;s second season kicked off with the Birmingham Stallions looking to repeat as champions.

## LSU's Jared Jones appears to hurl profanities at Kentucky pitcher after home run
 - [https://www.foxnews.com/sports/lsus-jared-jones-appears-hurl-profanities-kentucky-pitcher-home-run](https://www.foxnews.com/sports/lsus-jared-jones-appears-hurl-profanities-kentucky-pitcher-home-run)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 08:20:40+00:00

LSU first baseman Jared Jones hit a home run off Kentucky&apos;s Austin Strickland and had some choice words for the pitcher before he trotted around the bases.

## China criticizes US sanctions on fentanyl trade, say they 'undermine' Washington-Beijing relations: report
 - [https://www.foxnews.com/world/china-criticizes-us-sanctions-fentanyl-trade-say-undermine-washington-beijing-relations-report](https://www.foxnews.com/world/china-criticizes-us-sanctions-fentanyl-trade-say-undermine-washington-beijing-relations-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 08:17:56+00:00

A Chinese Foreign Ministry spokesperson says Beijing has filed a complaint with Washington after the Treasury Department announced sanctions to crack down on the fentanyl trade.

## 'Little old granny' bus driver who reamed out unruly kids shocked by outpouring of support: 'I'm nobody'
 - [https://www.foxnews.com/us/little-old-granny-bus-driver-who-reamed-out-unruly-kids-shocked-by-outpouring-of-support-im-nobody](https://www.foxnews.com/us/little-old-granny-bus-driver-who-reamed-out-unruly-kids-shocked-by-outpouring-of-support-im-nobody)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 08:00:52+00:00

A former Ohio school bus driver who went viral for yelling at a group of unruly kids says she is floored by the more than $100,000 raised for her to retire.

## Ohio school district allows staff to be armed: 'Our schools will no longer be soft targets'
 - [https://www.foxnews.com/us/ohio-school-district-allows-staff-to-pack-heat-our-schools-will-no-longer-be-soft-targets](https://www.foxnews.com/us/ohio-school-district-allows-staff-to-pack-heat-our-schools-will-no-longer-be-soft-targets)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 08:00:48+00:00

The River Valley Local School District in Marion County, Ohio, implemented a policy that allows teachers and school staff to be armed amid concerns over emergency response time.

## Biden needs to clarify his Taiwan policy ASAP
 - [https://www.foxnews.com/opinion/biden-needs-clarify-taiwan-policy-asap](https://www.foxnews.com/opinion/biden-needs-clarify-taiwan-policy-asap)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 08:00:17+00:00

If you think the U.S. should remain ambiguous about defending Taiwan so as not to &quot;provoke&quot; China doesn’t understand the Chinese Communist Party and Xi Jinping.

## Indiana inmate whose death sentence was revoked years ago still stuck in solitary confinement
 - [https://www.foxnews.com/us/indiana-inmate-ath-sentence-revoked-years-ago-still-stuck-solitary-confinement](https://www.foxnews.com/us/indiana-inmate-ath-sentence-revoked-years-ago-still-stuck-solitary-confinement)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 07:54:48+00:00

A man who was convicted of kidnapping, raping, and killing a teenage girl has been on death row for years. His death sentence was vacated due to a severe intellectual disability.

## Former OR Secretary of State Bill Bradbury dies at age 73
 - [https://www.foxnews.com/politics/former-secretary-state-bill-bradbury-dies-age-73](https://www.foxnews.com/politics/former-secretary-state-bill-bradbury-dies-age-73)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 07:40:56+00:00

Bill Bradbury, Oregon’s former secretary of state who established America’s first system of voting by mail, died from medical complications on Friday at 73 years old.

## Texas train collision, derailment injures 2 rail employees
 - [https://www.foxnews.com/us/texas-train-collision-derailment-injures-2-rail-employees](https://www.foxnews.com/us/texas-train-collision-derailment-injures-2-rail-employees)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 07:36:19+00:00

Two Texas rail employees were injured when a train derailed in Chico, Texas. Three locomotive cars and about 15 grain cars derailed. The train wasn&apos;t carrying any hazardous material.

## Police prepare Missouri case where teenage boy was shot after going to the wrong house
 - [https://www.foxnews.com/us/police-prepare-missouri-case-teenage-boy-shot-going-wrong-house](https://www.foxnews.com/us/police-prepare-missouri-case-teenage-boy-shot-going-wrong-house)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 07:32:22+00:00

A 16-year-old Black teenager was shot when he went to the wrong house to pick up his siblings in Kansas City, Missouri. Police are working quickly to prepare evidence for the case.

## Trump Jr, GOP under fire for going soft on Bud Light boycotts: No interest in 'pushing back'
 - [https://www.foxnews.com/politics/trump-jr-gop-fire-going-soft-bud-light-boycotts-no-interest-pushing-back](https://www.foxnews.com/politics/trump-jr-gop-fire-going-soft-bud-light-boycotts-no-interest-pushing-back)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 07:30:59+00:00

Donald Trump Jr. and the NRCC are coming under fire from critics for going soft on Bud Light boycotts following the beer company&apos;s Dylan Mulvaney partnership.

## Morgan Freeman tears apart Black History Month as an 'insult': 'Going to relegate my history to a month?'
 - [https://www.foxnews.com/media/morgan-freeman-tears-apart-black-history-month-insult-going-relegate-history-month](https://www.foxnews.com/media/morgan-freeman-tears-apart-black-history-month-insult-going-relegate-history-month)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 07:30:53+00:00

Freeman said that Black History Month was an &quot;insult&quot; and objected to the term &quot;African-American,&quot; pointing out that Africa is a continent, not a country.

## Ohio State offensive coordinator Brian Hartline injured in ATV crash
 - [https://www.foxnews.com/sports/ohio-state-offensive-coordinator-brian-hartline-injured-atv-crash](https://www.foxnews.com/sports/ohio-state-offensive-coordinator-brian-hartline-injured-atv-crash)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 07:24:01+00:00

Ohio State offensive coordinator Brian Hartline was hospitalized following an ATV crash on his property in Ohio on Sunday. He wrote on Twitter he was &quot;doing well.&quot;

## New UN-backed legal recommendations normalize sex with minors, outraged critics say
 - [https://www.foxnews.com/lifestyle/un-backed-legal-recommendations-normalize-sex-minors-critics-say](https://www.foxnews.com/lifestyle/un-backed-legal-recommendations-normalize-sex-minors-critics-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 07:22:16+00:00

A report by the Geneva-based International Commission of Jurists with the UN&apos;s backing recommends decriminalizing the age of sexual consent, opening the floodgates for sex with minors, say critics.

## Male chess player dresses as female to compete in women's tournament
 - [https://www.foxnews.com/sports/male-chess-player-dresses-female-compete-womens-tournament](https://www.foxnews.com/sports/male-chess-player-dresses-female-compete-womens-tournament)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 07:19:07+00:00

A chess tournament in Kenya was rocked with a scandal as a man dressed as a female competitor to try and win but was stopped during his run.

## Chicago mayor-elect reacts to 'Teen Takeover,' squatter victims fed up being landlords and more top headlines
 - [https://www.foxnews.com/us/chicago-mayor-elect-condemns-teen-takeover-squatter-victims-fed-up-being-landlords](https://www.foxnews.com/us/chicago-mayor-elect-condemns-teen-takeover-squatter-victims-fed-up-being-landlords)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 07:17:53+00:00

Chicago mayor-elect reacts to &apos;Teen Takeover,&apos; squatter victims fed up being landlords and more top headlines.

## Indiana officials lift evacuation order for area near plastics fire
 - [https://www.foxnews.com/us/indiana-officials-lift-evacuation-order-area-near-plastics-fire](https://www.foxnews.com/us/indiana-officials-lift-evacuation-order-area-near-plastics-fire)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 07:10:17+00:00

The evacuation order in Wayne County, Michigan, has been lifted after air quality was deemed safe. The evacuation order was implemented due to a fire at a former factory.

## Man involved in murder of Ohio police detective, informant sentenced to 50 years to life
 - [https://www.foxnews.com/us/man-involved-murder-ohio-police-detective-informant-sentenced-50-years-life](https://www.foxnews.com/us/man-involved-murder-ohio-police-detective-informant-sentenced-50-years-life)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 07:09:41+00:00

David McDaniel, a man who was involved in the murder of a police detective and informant, was sentenced to 50 years to life in prison. McDaniel apologized multiple times in court.

## Teen fatally shot by Ohio police officers following robbery
 - [https://www.foxnews.com/us/teen-fatally-shot-ohio-police-officers-robbery](https://www.foxnews.com/us/teen-fatally-shot-ohio-police-officers-robbery)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 07:05:31+00:00

Ohio police officers fatally shot a teen who pointed a gun at them. The officers were responding to a gunpoint robbery when the shooting occurred.

## California man arrested for allegedly smashing church windows with baseball bat
 - [https://www.foxnews.com/us/california-man-arrested-smashing-church-windows-baseball-bat](https://www.foxnews.com/us/california-man-arrested-smashing-church-windows-baseball-bat)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 07:04:33+00:00

Police in California arrested a 27-year-old man on suspicion of vandalizing a Southern California church. The man is accused of smashing its windows with a baseball bat.

## First on Fox: House Democratic campaign committee shatters fundraising record with huge haul
 - [https://www.foxnews.com/politics/first-on-fox-house-democratic-campaign-committee-shatters-fundraising-record-37-7-million-haul](https://www.foxnews.com/politics/first-on-fox-house-democratic-campaign-committee-shatters-fundraising-record-37-7-million-haul)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 07:00:54+00:00

The Democratic Congressional Campaign Committee raised nearly $38 million in fundraising in the first quarter as it aims to regain the House majority in next year’s elections

## Mayorkas held calls with ACLU nearly two dozen times in five-month period in 2021, documents show
 - [https://www.foxnews.com/politics/mayorkas-held-calls-aclu-nearly-two-dozen-times-five-month-period-2021-documents-show](https://www.foxnews.com/politics/mayorkas-held-calls-aclu-nearly-two-dozen-times-five-month-period-2021-documents-show)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 07:00:30+00:00

DHS Secretary Alejandro Mayorkas held 23 calls with the American Civil Liberties Union in the first six months of the Biden administration, newly-released records show.

## Jeremy Renner joins Sharon Osbourne, Ellen DeGeneres as stars who dabble in renovations
 - [https://www.foxnews.com/entertainment/jeremy-renner-joins-sharon-osbourne-ellen-degeneres-stars-dominate-renovations](https://www.foxnews.com/entertainment/jeremy-renner-joins-sharon-osbourne-ellen-degeneres-stars-dominate-renovations)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 07:00:19+00:00

Jeremy Renner is on the list of Hollywood stars who dabble in the world of renovations. Ellen DeGeneres has had a passion for flipping homes for years.

## Mexican kidnappers targeting American tourists have 'no code' curbing ruthlessness: expert
 - [https://www.foxnews.com/us/mexican-kidnappers-targeting-american-tourists-have-no-code-curbing-ruthlessness-expert](https://www.foxnews.com/us/mexican-kidnappers-targeting-american-tourists-have-no-code-curbing-ruthlessness-expert)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 07:00:11+00:00

Private investigator Jay Armes III, who&apos;s been working kidnappings in Mexico for more than three decades, told Fox News Digital that kidnapping was a business &quot;with a code&quot; that&apos;s been erased by today&apos;s criminals

## Burnout fears grow as overseas Army deployments match highs not seen since War on Terror: report
 - [https://www.foxnews.com/us/burnout-fears-grow-as-army-deployments-match-highs-not-seen-since-war-on-terror-report](https://www.foxnews.com/us/burnout-fears-grow-as-army-deployments-match-highs-not-seen-since-war-on-terror-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 07:00:08+00:00

Fears of burnout in the Army ranks are growing amid an operational tempo and deployments that rival the height of the War on Terror in Iraq and Afghanistan.

## Budweiser's new pro-America ad sets social media ablaze: Can't put the 'genie back in the bottle, guys'
 - [https://www.foxnews.com/media/budweisers-new-pro-america-ad-social-media-ablaze-cant-put-genie-back-bottle-guys](https://www.foxnews.com/media/budweisers-new-pro-america-ad-social-media-ablaze-cant-put-genie-back-bottle-guys)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 07:00:02+00:00

Critics laid into Budweiser on Twitter after the brand released a new pro-America ad in an effort to move past the fallout prompted by its partnership with Dylan Mulvaney.

## 'SNL' 'first non-binary' comedian speaks to children about their 'crotch,' genitalia in anti-Republican rant
 - [https://www.foxnews.com/media/snl-first-non-binary-comedian-speaks-children-crotch-genitalia-anti-republican-rant](https://www.foxnews.com/media/snl-first-non-binary-comedian-speaks-children-crotch-genitalia-anti-republican-rant)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 06:12:35+00:00

SNL cast member Molly Kearney, who identifies as non-binary, slammed Republicans for &quot;making trans kids grow up too fast&quot; and opposing transgender surgeries for minors.

## Texas Tech cheerleader lands modeling gig following viral Masters video
 - [https://www.foxnews.com/sports/texas-tech-cheerleader-lands-modeling-gig-viral-masters-video](https://www.foxnews.com/sports/texas-tech-cheerleader-lands-modeling-gig-viral-masters-video)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 06:07:15+00:00

Aaliyah Kikumoto, the Texas Tech cheerleader who went viral during the Masters, landed a new gig in the wake of her fame. She is a model with BSX.

## New York Times staffers are whining again and you won't believe why
 - [https://www.foxnews.com/opinion/new-york-times-staffers-whining-believe](https://www.foxnews.com/opinion/new-york-times-staffers-whining-believe)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 06:00:55+00:00

The employee argument is that the most pro-LGBTQ newspaper in the country is somehow against the LGBTQ community. In reality, it’s hard to find issues that the Times isn’t leftist on.

## Clippers' Russell Westbrook, Suns fan have intense exchange at halftime: 'Watch your mouth motherf---er'
 - [https://www.foxnews.com/sports/clippers-russell-westbrook-suns-fan-intense-exchange-halftime-watch-mouth-motherf-er](https://www.foxnews.com/sports/clippers-russell-westbrook-suns-fan-intense-exchange-halftime-watch-mouth-motherf-er)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 06:00:25+00:00

Los Angeles Clippers star Russell Westbrook had an intense interaction with a Phoenix Suns fan at halftime of their Game 1 matchup on Sunday night.

## Russell Westbrook's physique inspires Charles Barkley to do crunches live on air
 - [https://www.foxnews.com/sports/russell-westbrooks-physique-inspires-charles-barkley-crunches-live-on-air](https://www.foxnews.com/sports/russell-westbrooks-physique-inspires-charles-barkley-crunches-live-on-air)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 05:54:40+00:00

Russell Westbrook&apos;s six-pack had Hall of Famer Charles Barkley doing crunches live on air during TNT&apos;s pre-game show for the Los Angeles Clippers and Phoenix Suns

## Tennessee Air National Guardsman arrested for applying to be hitman on parody website
 - [https://www.foxnews.com/us/tennessee-air-national-guardsman-arrested-applying-hitman-parody-website](https://www.foxnews.com/us/tennessee-air-national-guardsman-arrested-applying-hitman-parody-website)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 05:53:12+00:00

A Tennessee Air National Guardsman was arrested after applying to be a hitman on a parody website. He could face up to 10 years in prison if convicted.

## US CENTCOM launches helicopter raid in northern Syria resulting in 'probable death' of ISIS senior leader
 - [https://www.foxnews.com/world/us-centcom-launches-helicopter-raid-northern-syria-resulting-probable-death-isis-senior-leader](https://www.foxnews.com/world/us-centcom-launches-helicopter-raid-northern-syria-resulting-probable-death-isis-senior-leader)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 05:23:49+00:00

U.S. Central Command said in a statement Monday morning that its forces conducted a successful helicopter raid on a senior leader and operational planner of ISIS.

## Children's author Judy Blume declares support for trans rights after defending J.K. Rowling
 - [https://www.foxnews.com/media/author-judy-blume-declares-support-trans-rights-defending-jk-rowling](https://www.foxnews.com/media/author-judy-blume-declares-support-trans-rights-defending-jk-rowling)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 05:00:55+00:00

Author Judy Blume revealed in an interview for The Times that she supported J.K. Rowling in the middle of the controversy surrounding the “Harry Potter&quot; author.

## Biden admin receives backlash from nearly two dozen groups for move cracking down on gas stoves
 - [https://www.foxnews.com/politics/biden-admin-receives-backlash-nearly-two-dozen-groups-cracking-down-gas-stoves](https://www.foxnews.com/politics/biden-admin-receives-backlash-nearly-two-dozen-groups-cracking-down-gas-stoves)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 05:00:07+00:00

Nearly two dozen energy and consumer advocacy groups are planning to file comments Monday strongly opposing the Biden administration&apos;s proposal cracking down on gas stoves.

## Squatter victims fed up with being landlords after feeling wronged by legal system
 - [https://www.foxnews.com/us/squatter-victims-fed-up-being-landlords-after-feeling-wronged-legal-system](https://www.foxnews.com/us/squatter-victims-fed-up-being-landlords-after-feeling-wronged-legal-system)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 04:30:30+00:00

Property owners are fed up with laws regarding squatters, choosing to opt out of being landlords to avoid the headache of keeping control of their houses.

## Democrat lawmakers demand Biden address 'extreme right-wing Israeli government' after West Bank violence
 - [https://www.foxnews.com/politics/democrat-lawmakers-demand-biden-address-extreme-right-wing-israeli-government-west-bank-violence](https://www.foxnews.com/politics/democrat-lawmakers-demand-biden-address-extreme-right-wing-israeli-government-west-bank-violence)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 04:26:35+00:00

Democratic lawmakers wrote a letter to President Biden to urge action in Israel in response to recent violence between Israeli forces and residents in the West Bank.

## Latest Hunter bombshell: Here's the kind of access his partners had to VP Joe Biden
 - [https://www.foxnews.com/opinion/latest-hunter-bombshell-heres-access-his-partners-had-vp-joe-biden](https://www.foxnews.com/opinion/latest-hunter-bombshell-heres-access-his-partners-had-vp-joe-biden)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 04:00:51+00:00

Joe Biden&apos;s insistence that he never discussed with Hunter his overseas business dealings is belied by indisputable evidence. Yet, the president maintains the ludicrous charade.

## Iranian regime directly involved in poisoning hundreds of students in effort to stifle protests: report
 - [https://www.foxnews.com/world/iranian-regime-directly-involved-poisoning-hundreds-students-effort-stifle-protests-report](https://www.foxnews.com/world/iranian-regime-directly-involved-poisoning-hundreds-students-effort-stifle-protests-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 02:00:56+00:00

Iran acknowledged the incidents in March when Iranian President Ebrahim Raisi ordered an investigation into a few of the poisonings, with no update in the time since.

## Planets quiz! How well do you know these fun facts about our solar system?
 - [https://www.foxnews.com/lifestyle/planets-quiz-how-well-know-fun-facts-solar-system](https://www.foxnews.com/lifestyle/planets-quiz-how-well-know-fun-facts-solar-system)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 02:00:53+00:00

Earth Day is April 22 — think you know the planets? Test your knowledge of the solar system in this fun and engaging lifestyle quiz — and see how well you do!

## Virgin Mary statue withstands earthquake in Turkey as cathedral collapses: 'Inspiring symbol of hope'
 - [https://www.foxnews.com/lifestyle/virgin-mary-statue-withstands-earthquake-turkey-cathedral-collapses-inspiring-symbol-hope](https://www.foxnews.com/lifestyle/virgin-mary-statue-withstands-earthquake-turkey-cathedral-collapses-inspiring-symbol-hope)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 02:00:51+00:00

A statue symbolizing Mary, mother of Jesus, was left virtually untouched after a 7.8 magnitude earthquake hit Turkey on Feb. 6. The cathedral surrounding the piece collapsed.

## I was assaulted by a transgender mob and this is what I plan to do next
 - [https://www.foxnews.com/opinion/i-assaulted-transgender-mob-what-i-plan-next](https://www.foxnews.com/opinion/i-assaulted-transgender-mob-what-i-plan-next)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 02:00:38+00:00

I was assaulted by a transgender mob and this is what I plan to do next. As a former All-American swimmer, I know that women’s sports are under threat.

## Prince Andrew 'resentful' toward King Charles, 'dragging his heels' over leaving lavish home, experts claim
 - [https://www.foxnews.com/entertainment/prince-andrew-resentful-toward-king-charles-dragging-heels-leave-lavish-home-experts](https://www.foxnews.com/entertainment/prince-andrew-resentful-toward-king-charles-dragging-heels-leave-lavish-home-experts)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 02:00:38+00:00

Prince Andrew is allegedly refusing to exit his Royal Lodge home and move into Frogmore Cottage, the former U.K. residence of Prince Harry and Meghan Markle.

## Massachusetts man charged in murders of dismembered people found in storage unit
 - [https://www.foxnews.com/us/massachusetts-man-charged-murders-dismembered-people-found-storage-unit](https://www.foxnews.com/us/massachusetts-man-charged-murders-dismembered-people-found-storage-unit)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 01:49:05+00:00

A Massachusetts man was arrested after the dismembered bodies of two people reported missing were discovered inside bins in his storage unit, officials said.

## Shooting in Biloxi, Mississippi leaves 5 injured, including a police officer: chief
 - [https://www.foxnews.com/us/shooting-biloxi-mississippi-leaves-5-injured-including-police-officer-chief](https://www.foxnews.com/us/shooting-biloxi-mississippi-leaves-5-injured-including-police-officer-chief)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 01:22:42+00:00

Biloxi Police Chief John Miller said an officer from his department and at least four other victims were injured in a shooting Sunday evening. The incident is being investigated.

## Nuggets run away with Game 1 win over Timberwolves
 - [https://www.foxnews.com/sports/nuggets-run-away-game-1-win-over-timberwolves](https://www.foxnews.com/sports/nuggets-run-away-game-1-win-over-timberwolves)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 01:19:06+00:00

The Denver Nuggets used a third-quarter surge to truly run away with Game 1 in a win over the Minnesota Timberwolves on Sunday. Six players finished with double-digit points.

## Rep. Harshbarger endorses Donald Trump to be president: 'Biden administration has failed us'
 - [https://www.foxnews.com/politics/rep-harshbarger-endorses-donald-trump-president-biden-administration-has-failed-us](https://www.foxnews.com/politics/rep-harshbarger-endorses-donald-trump-president-biden-administration-has-failed-us)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 00:07:01+00:00

Tennessee Republican Rep. Diana Harshbarger endorsed Donald Trump to be President of the United States ahead of a potential rematch with President Joe Biden.

## On this day in history, April 17, 1970, Apollo 13 astronauts return alive, defy odds after space explosion
 - [https://www.foxnews.com/lifestyle/this-day-history-april-17-1970-apollo-13-astronauts-return-alive-defy-odds-space-explosion](https://www.foxnews.com/lifestyle/this-day-history-april-17-1970-apollo-13-astronauts-return-alive-defy-odds-space-explosion)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-04-17 00:02:22+00:00

The three astronauts on board the Apollo 13 mission safely returned to Earth after an explosion in space threatened their lives on this day in history, April 17, 1970.

