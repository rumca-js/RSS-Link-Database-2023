# Source:MSN, URL:http://www.msn.com/rss/news.aspx, language:en-US

## Soros-funded DA Pamela Price calls for rally to condemn ‘anti-Price’ news outlet that criticized her
 - [http://www.msn.com/en-us/news/us/soros-funded-da-pamela-price-calls-for-rally-to-condemn-anti-price-news-outlet-that-criticized-her/ar-AA19YSQc?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/soros-funded-da-pamela-price-calls-for-rally-to-condemn-anti-price-news-outlet-that-criticized-her/ar-AA19YSQc?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 23:02:05.211401+00:00



## Republican Cities That Have Higher Crime Rates Than New York
 - [http://www.msn.com/en-us/news/crime/republican-cities-that-have-higher-crime-rates-than-new-york/ar-AA19YI5K?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/republican-cities-that-have-higher-crime-rates-than-new-york/ar-AA19YI5K?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 23:02:05.204027+00:00



## Ohio officers won’t be charged in shooting of Jayland Walker
 - [http://www.msn.com/en-us/news/crime/ohio-officers-won-t-be-charged-in-shooting-of-jayland-walker/ar-AA19YI9n?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/ohio-officers-won-t-be-charged-in-shooting-of-jayland-walker/ar-AA19YI9n?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 23:02:05.195021+00:00



## Grand jury declines to indict officers involved in Jayland Walker's death
 - [http://www.msn.com/en-us/news/crime/grand-jury-declines-to-indict-officers-involved-in-jayland-walker-s-death/ar-AA19Yrha?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/grand-jury-declines-to-indict-officers-involved-in-jayland-walker-s-death/ar-AA19Yrha?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 23:02:05.187423+00:00



## McConnell returns to Capitol as GOP faces full plate of challenges
 - [http://www.msn.com/en-us/news/politics/mcconnell-returns-to-capitol-as-gop-faces-full-plate-of-challenges/ar-AA19YKMR?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/mcconnell-returns-to-capitol-as-gop-faces-full-plate-of-challenges/ar-AA19YKMR?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 23:02:05.178984+00:00



## Charges filed in shooting of Kansas City teen who rang wrong doorbell
 - [http://www.msn.com/en-us/news/us/charges-filed-in-shooting-of-kansas-city-teen-who-rang-wrong-doorbell/ar-AA19YJki?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/charges-filed-in-shooting-of-kansas-city-teen-who-rang-wrong-doorbell/ar-AA19YJki?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 23:02:05.170032+00:00



## Rep. George Santos announces reelection bid
 - [http://www.msn.com/en-us/news/politics/rep-george-santos-announces-reelection-bid/ar-AA19YKPK?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/rep-george-santos-announces-reelection-bid/ar-AA19YKPK?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 23:02:05.163077+00:00



## George Santos is running for reelection because “good isn’t good enough”
 - [http://www.msn.com/en-us/news/politics/george-santos-is-running-for-reelection-because-good-isn-t-good-enough/ar-AA19YCOt?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/george-santos-is-running-for-reelection-because-good-isn-t-good-enough/ar-AA19YCOt?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 23:02:05.152976+00:00



## China to conduct ‘major military activity’ in Yellow Sea amid heightened tensions in region
 - [http://www.msn.com/en-us/news/world/china-to-conduct-major-military-activity-in-yellow-sea-amid-heightened-tensions-in-region/ar-AA19YzW3?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/china-to-conduct-major-military-activity-in-yellow-sea-amid-heightened-tensions-in-region/ar-AA19YzW3?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 22:02:01.255184+00:00



## Republicans look to extend transgender restrictions to adults
 - [http://www.msn.com/en-us/news/us/republicans-look-to-extend-transgender-restrictions-to-adults/ar-AA19YpaA?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/republicans-look-to-extend-transgender-restrictions-to-adults/ar-AA19YpaA?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 22:02:01.247495+00:00



## Creationist Theme Park Pal Charged with Child Sex Abuse—Again
 - [http://www.msn.com/en-us/news/crime/creationist-theme-park-pal-charged-with-child-sex-abuse-again/ar-AA19YA1H?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/creationist-theme-park-pal-charged-with-child-sex-abuse-again/ar-AA19YA1H?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 22:02:01.237919+00:00



## Republicans reject Feinstein committee swap, putting Democrats in a bind
 - [http://www.msn.com/en-us/news/politics/republicans-reject-feinstein-committee-swap-putting-democrats-in-a-bind/ar-AA19YuxA?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/republicans-reject-feinstein-committee-swap-putting-democrats-in-a-bind/ar-AA19YuxA?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 22:02:01.230057+00:00



## Fugees rapper in political conspiracy trial launches defense
 - [http://www.msn.com/en-us/news/politics/fugees-rapper-in-political-conspiracy-trial-launches-defense/ar-AA19YEK8?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/fugees-rapper-in-political-conspiracy-trial-launches-defense/ar-AA19YEK8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 22:02:01.222840+00:00



## If Dianne Feinstein resigns, here's what would happen next to her Senate seat
 - [http://www.msn.com/en-us/news/politics/if-dianne-feinstein-resigns-here-s-what-would-happen-next-to-her-senate-seat/ar-AA19YMej?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/if-dianne-feinstein-resigns-here-s-what-would-happen-next-to-her-senate-seat/ar-AA19YMej?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 22:02:01.215552+00:00



## Teen died saving sister's life in Alabama shooting
 - [http://www.msn.com/en-us/news/world/teen-died-saving-sister-s-life-in-alabama-shooting/ar-AA19Ypcd?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/teen-died-saving-sister-s-life-in-alabama-shooting/ar-AA19Ypcd?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 22:02:01.207053+00:00



## GOP immigration bill sketches battle lines for 2024
 - [http://www.msn.com/en-us/news/politics/gop-immigration-bill-sketches-battle-lines-for-2024/ar-AA19YuCS?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/gop-immigration-bill-sketches-battle-lines-for-2024/ar-AA19YuCS?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 22:02:01.193187+00:00



## I was a hacker. These are the scariest things I saw on the dark web
 - [http://www.msn.com/en-us/news/technology/i-was-a-hacker-these-are-the-scariest-things-i-saw-on-the-dark-web/ar-AA19YH7S?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/i-was-a-hacker-these-are-the-scariest-things-i-saw-on-the-dark-web/ar-AA19YH7S?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 21:01:47.231624+00:00



## Victims of Alabama birthday party shooting included students months away from graduation
 - [http://www.msn.com/en-us/news/us/victims-of-alabama-birthday-party-shooting-included-students-months-away-from-graduation/ar-AA19YAMc?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/victims-of-alabama-birthday-party-shooting-included-students-months-away-from-graduation/ar-AA19YAMc?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 21:01:47.223143+00:00



## Defendant charged with kidnapping mother, child testifies
 - [http://www.msn.com/en-us/news/crime/defendant-charged-with-kidnapping-mother-child-testifies/ar-AA19YH2j?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/defendant-charged-with-kidnapping-mother-child-testifies/ar-AA19YH2j?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 21:01:47.214394+00:00



## Gavin Newsom slashes funding for foster care program amid California budget crunch
 - [http://www.msn.com/en-us/news/us/gavin-newsom-slashes-funding-for-foster-care-program-amid-california-budget-crunch/ar-AA19YH8G?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/gavin-newsom-slashes-funding-for-foster-care-program-amid-california-budget-crunch/ar-AA19YH8G?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 21:01:47.206590+00:00



## Alabama birthday party mass shooting: 4 slain victims identified
 - [http://www.msn.com/en-us/news/us/alabama-birthday-party-mass-shooting-4-slain-victims-identified/ar-AA19Y5Kz?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/alabama-birthday-party-mass-shooting-4-slain-victims-identified/ar-AA19Y5Kz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 21:01:47.198569+00:00



## The standoff between Jim Jordan and Manhattan DA Alvin Bragg, explained
 - [http://www.msn.com/en-us/news/politics/the-standoff-between-jim-jordan-and-manhattan-da-alvin-bragg-explained/ar-AA19Msk3?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/the-standoff-between-jim-jordan-and-manhattan-da-alvin-bragg-explained/ar-AA19Msk3?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 21:01:47.189070+00:00



## GOP House intel chairman slaps down praise of accused Pentagon leaker from MAGA Republicans
 - [http://www.msn.com/en-us/news/politics/gop-house-intel-chairman-slaps-down-praise-of-accused-pentagon-leaker-from-maga-republicans/ar-AA19YHes?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/gop-house-intel-chairman-slaps-down-praise-of-accused-pentagon-leaker-from-maga-republicans/ar-AA19YHes?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 21:01:47.181053+00:00



## West Virginia’s sole abortion clinic drops challenge to state ban
 - [http://www.msn.com/en-us/news/politics/west-virginia-s-sole-abortion-clinic-drops-challenge-to-state-ban/ar-AA19YQ9K?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/west-virginia-s-sole-abortion-clinic-drops-challenge-to-state-ban/ar-AA19YQ9K?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 21:01:47.172937+00:00



## Antisemitic incidents rise 'alarmingly' in U.S., fall in other countries, report finds
 - [http://www.msn.com/en-us/news/us/antisemitic-incidents-rise-alarmingly-in-u-s-fall-in-other-countries-report-finds/ar-AA19XPvx?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/antisemitic-incidents-rise-alarmingly-in-u-s-fall-in-other-countries-report-finds/ar-AA19XPvx?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 20:02:08.015995+00:00



## Pentagon issues warning about offshore wind projects, threatening Biden goals
 - [http://www.msn.com/en-us/news/us/pentagon-issues-warning-about-offshore-wind-projects-threatening-biden-goals/ar-AA19XPvV?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/pentagon-issues-warning-about-offshore-wind-projects-threatening-biden-goals/ar-AA19XPvV?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 20:02:08.006840+00:00



## Katie Porter blames sexism when pressed on 'The View' about staff mistreatment allegations
 - [http://www.msn.com/en-us/news/us/katie-porter-blames-sexism-when-pressed-on-the-view-about-staff-mistreatment-allegations/ar-AA19YDKz?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/katie-porter-blames-sexism-when-pressed-on-the-view-about-staff-mistreatment-allegations/ar-AA19YDKz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 20:02:07.999638+00:00



## George Santos announces reelection bid
 - [http://www.msn.com/en-us/news/politics/george-santos-announces-reelection-bid/ar-AA19Yosc?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/george-santos-announces-reelection-bid/ar-AA19Yosc?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 20:02:07.991376+00:00



## What we know about the Dadeville, Alabama, mass shooting
 - [http://www.msn.com/en-us/news/crime/what-we-know-about-the-dadeville-alabama-mass-shooting/ar-AA19XVMM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/what-we-know-about-the-dadeville-alabama-mass-shooting/ar-AA19XVMM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 20:02:07.981875+00:00



## Democrats face obstacles in replacing Feinstein on panel
 - [http://www.msn.com/en-us/news/politics/democrats-face-obstacles-in-replacing-feinstein-on-panel/ar-AA19YwFu?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/democrats-face-obstacles-in-replacing-feinstein-on-panel/ar-AA19YwFu?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 20:02:07.974111+00:00



## Rep. George Santos announces re-election bid
 - [http://www.msn.com/en-us/news/politics/rep-george-santos-announces-re-election-bid/ar-AA19YrgZ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/rep-george-santos-announces-re-election-bid/ar-AA19YrgZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 20:02:07.966089+00:00



## Kayleigh McEnany calls out Lori Lightfoot, progressive mayor-elect after Chicago's 'Teen Takeover' chaos
 - [http://www.msn.com/en-us/news/us/kayleigh-mcenany-calls-out-lori-lightfoot-progressive-mayor-elect-after-chicago-s-teen-takeover-chaos/ar-AA19Ynu8?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/kayleigh-mcenany-calls-out-lori-lightfoot-progressive-mayor-elect-after-chicago-s-teen-takeover-chaos/ar-AA19Ynu8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 19:02:01.664782+00:00



## US arrests two in connection with ‘secret’ Chinese police station in NY
 - [http://www.msn.com/en-us/news/politics/us-arrests-two-in-connection-with-secret-chinese-police-station-in-ny/ar-AA19YvUu?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/us-arrests-two-in-connection-with-secret-chinese-police-station-in-ny/ar-AA19YvUu?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 19:02:01.656648+00:00



## The outrage over Black teen Ralph Yarl’s shooting, explained
 - [http://www.msn.com/en-us/news/crime/the-outrage-over-black-teen-ralph-yarl-s-shooting-explained/ar-AA19Yo3F?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/the-outrage-over-black-teen-ralph-yarl-s-shooting-explained/ar-AA19Yo3F?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 19:02:01.648720+00:00



## Nikki Haley gets early support from wealthy donors while some remain on the sidelines
 - [http://www.msn.com/en-us/news/politics/nikki-haley-gets-early-support-from-wealthy-donors-while-some-remain-on-the-sidelines/ar-AA19YawB?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/nikki-haley-gets-early-support-from-wealthy-donors-while-some-remain-on-the-sidelines/ar-AA19YawB?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 19:02:01.640662+00:00



## Paul Whelan's family says he feels 'abandoned' by US in Russian prison
 - [http://www.msn.com/en-us/news/world/paul-whelan-s-family-says-he-feels-abandoned-by-us-in-russian-prison/ar-AA19Yc8I?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/paul-whelan-s-family-says-he-feels-abandoned-by-us-in-russian-prison/ar-AA19Yc8I?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 19:02:01.632845+00:00



## Israel president urges unity on Holocaust Remembrance Day
 - [http://www.msn.com/en-us/news/world/israel-president-urges-unity-on-holocaust-remembrance-day/ar-AA19Ynun?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/israel-president-urges-unity-on-holocaust-remembrance-day/ar-AA19Ynun?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 19:02:01.623860+00:00



## Dems plan to push Feinstein-replacement strategy this week
 - [http://www.msn.com/en-us/news/politics/dems-plan-to-push-feinstein-replacement-strategy-this-week/ar-AA19YDdk?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/dems-plan-to-push-feinstein-replacement-strategy-this-week/ar-AA19YDdk?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 19:02:01.615809+00:00



## Owl Filmed Feasting on Snake in Shocking Video
 - [http://www.msn.com/en-us/news/technology/owl-filmed-feasting-on-snake-in-shocking-video/ar-AA19YqcG?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/owl-filmed-feasting-on-snake-in-shocking-video/ar-AA19YqcG?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 18:02:02.269637+00:00



## News Analysis: FDA case may reveal if Supreme Court conservative justices are abortion foes above all else
 - [http://www.msn.com/en-us/news/politics/news-analysis-fda-case-may-reveal-if-supreme-court-conservative-justices-are-abortion-foes-above-all-else/ar-AA19XWTm?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/news-analysis-fda-case-may-reveal-if-supreme-court-conservative-justices-are-abortion-foes-above-all-else/ar-AA19XWTm?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 18:02:02.260818+00:00



## Trump urges Murdoch to embrace false 2020 election claims in Dominion trial
 - [http://www.msn.com/en-us/news/politics/trump-urges-murdoch-to-embrace-false-2020-election-claims-in-dominion-trial/ar-AA19XP8r?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/trump-urges-murdoch-to-embrace-false-2020-election-claims-in-dominion-trial/ar-AA19XP8r?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 18:02:02.252766+00:00



## FBI makes arrests over US Chinese 'police stations'
 - [http://www.msn.com/en-us/news/world/fbi-makes-arrests-over-us-chinese-police-stations/ar-AA19YmJw?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/fbi-makes-arrests-over-us-chinese-police-stations/ar-AA19YmJw?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 18:02:02.245460+00:00



## Huge mob ransacks California gas station; police 'outnumbered': video
 - [http://www.msn.com/en-us/news/crime/huge-mob-ransacks-california-gas-station-police-outnumbered-video/ar-AA19YfuN?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/huge-mob-ransacks-california-gas-station-police-outnumbered-video/ar-AA19YfuN?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 18:02:02.237315+00:00



## Gun-toting Jan. 6 defendant says 'instinct took over' when he charged police line with wooden pallet
 - [http://www.msn.com/en-us/news/us/gun-toting-jan-6-defendant-says-instinct-took-over-when-he-charged-police-line-with-wooden-pallet/ar-AA19XWP4?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/gun-toting-jan-6-defendant-says-instinct-took-over-when-he-charged-police-line-with-wooden-pallet/ar-AA19XWP4?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 18:02:02.229980+00:00



## McCarthy tells Wall Street GOP will vote to raise debt limit but tied to budget cuts
 - [http://www.msn.com/en-us/news/politics/mccarthy-tells-wall-street-gop-will-vote-to-raise-debt-limit-but-tied-to-budget-cuts/ar-AA19XHqf?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/mccarthy-tells-wall-street-gop-will-vote-to-raise-debt-limit-but-tied-to-budget-cuts/ar-AA19XHqf?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 18:02:02.220748+00:00



## UK prime minister seeks to reverse 'anti-math' culture
 - [http://www.msn.com/en-us/news/world/uk-prime-minister-seeks-to-reverse-anti-math-culture/ar-AA19YqgV?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/uk-prime-minister-seeks-to-reverse-anti-math-culture/ar-AA19YqgV?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 18:02:02.212351+00:00



## A giant, rotting mass of seaweed threatens beach season in the U.S.
 - [http://www.msn.com/en-us/news/us/a-giant-rotting-mass-of-seaweed-threatens-beach-season-in-the-u-s/ar-AA18IRCl?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/a-giant-rotting-mass-of-seaweed-threatens-beach-season-in-the-u-s/ar-AA18IRCl?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 17:02:08.775335+00:00



## A Sommelier Reveals the Best Way to Find Great-Tasting Bargain Wines
 - [http://www.msn.com/en-us/news/technology/a-sommelier-reveals-the-best-way-to-find-great-tasting-bargain-wines/ar-AAZMq04?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/a-sommelier-reveals-the-best-way-to-find-great-tasting-bargain-wines/ar-AAZMq04?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 17:02:08.767277+00:00



## More NATO MiG-29s for Ukraine Ahead of Counteroffensive
 - [http://www.msn.com/en-us/news/world/more-nato-mig-29s-for-ukraine-ahead-of-counteroffensive/ar-AA19YgXr?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/more-nato-mig-29s-for-ukraine-ahead-of-counteroffensive/ar-AA19YgXr?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 17:02:08.758660+00:00



## Ex-Cardinal McCarrick charged in Wisconsin with sex abuse
 - [http://www.msn.com/en-us/news/politics/ex-cardinal-mccarrick-charged-in-wisconsin-with-sex-abuse/ar-AA19XWr6?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/ex-cardinal-mccarrick-charged-in-wisconsin-with-sex-abuse/ar-AA19XWr6?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 17:02:08.750565+00:00



## Speaker McCarthy says House Republicans will vote on a debt limit bill into 2024
 - [http://www.msn.com/en-us/news/politics/speaker-mccarthy-says-house-republicans-will-vote-on-a-debt-limit-bill-into-2024/ar-AA19XUEU?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/speaker-mccarthy-says-house-republicans-will-vote-on-a-debt-limit-bill-into-2024/ar-AA19XUEU?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 17:02:08.741050+00:00



## 'Hypocrisy': New York Democrats deride Judiciary Committee's Manhattan hearing
 - [http://www.msn.com/en-us/news/politics/hypocrisy-new-york-democrats-deride-judiciary-committee-s-manhattan-hearing/ar-AA19XHFp?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/hypocrisy-new-york-democrats-deride-judiciary-committee-s-manhattan-hearing/ar-AA19XHFp?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 17:02:08.732566+00:00



## Pressing 'Print Screen' on your keyboard may do something different if you have Windows 11
 - [http://www.msn.com/en-us/news/technology/pressing-print-screen-on-your-keyboard-may-do-something-different-if-you-have-windows-11/ar-AA19Y7d8?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/pressing-print-screen-on-your-keyboard-may-do-something-different-if-you-have-windows-11/ar-AA19Y7d8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 17:02:08.723389+00:00



## Half of North American bat species are at risk, report warns
 - [http://www.msn.com/en-us/news/us/half-of-north-american-bat-species-are-at-risk-report-warns/ar-AA19Yjxx?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/half-of-north-american-bat-species-are-at-risk-report-warns/ar-AA19Yjxx?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 17:02:08.712823+00:00



## Sunak investigated in UK over possible undeclared interest
 - [http://www.msn.com/en-us/news/world/sunak-investigated-in-uk-over-possible-undeclared-interest/ar-AA19Y1he?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/sunak-investigated-in-uk-over-possible-undeclared-interest/ar-AA19Y1he?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 16:02:16.771431+00:00



## Fatal Tiger Attacks Spark Curfew Across Dozens of Villages
 - [http://www.msn.com/en-us/news/world/fatal-tiger-attacks-spark-curfew-across-dozens-of-villages/ar-AA19Y07r?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/fatal-tiger-attacks-spark-curfew-across-dozens-of-villages/ar-AA19Y07r?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 16:02:16.763912+00:00



## LA business owner closes stores after 12th break-in: 'Can't do it anymore'
 - [http://www.msn.com/en-us/news/us/la-business-owner-closes-stores-after-12th-break-in-can-t-do-it-anymore/ar-AA19YdVN?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/la-business-owner-closes-stores-after-12th-break-in-can-t-do-it-anymore/ar-AA19YdVN?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 16:02:16.754669+00:00



## The two generals fighting over Sudan's future
 - [http://www.msn.com/en-us/news/world/the-two-generals-fighting-over-sudan-s-future/ar-AA19XOq9?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/the-two-generals-fighting-over-sudan-s-future/ar-AA19XOq9?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 16:02:16.745418+00:00



## Air National Guardsman faces charges after applying to RentAHitman.com, feds say
 - [http://www.msn.com/en-us/news/politics/air-national-guardsman-faces-charges-after-applying-to-rentahitman-com-feds-say/ar-AA19Y6g4?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/air-national-guardsman-faces-charges-after-applying-to-rentahitman-com-feds-say/ar-AA19Y6g4?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 16:02:16.737301+00:00



## Jordan, House Republicans hold New York City hearing to focus on crime, attack Bragg
 - [http://www.msn.com/en-us/news/politics/jordan-house-republicans-hold-new-york-city-hearing-to-focus-on-crime-attack-bragg/ar-AA19X4bh?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/jordan-house-republicans-hold-new-york-city-hearing-to-focus-on-crime-attack-bragg/ar-AA19X4bh?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 16:02:16.729846+00:00



## Pelosi campaign pays Illinois man $7,500 after he sued over 'invasive and harassing' fundraising texts
 - [http://www.msn.com/en-us/news/politics/pelosi-campaign-pays-illinois-man-7-500-after-he-sued-over-invasive-and-harassing-fundraising-texts/ar-AA19Yl3b?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/pelosi-campaign-pays-illinois-man-7-500-after-he-sued-over-invasive-and-harassing-fundraising-texts/ar-AA19Yl3b?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 16:02:16.721997+00:00



## Watch SpaceX launch Starship, the tallest and most powerful rocket ever built, on its first orbital flight this week
 - [http://www.msn.com/en-us/news/technology/watch-spacex-launch-starship-the-tallest-and-most-powerful-rocket-ever-built-on-its-first-orbital-flight-this-week/ar-AA19SxNv?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/watch-spacex-launch-starship-the-tallest-and-most-powerful-rocket-ever-built-on-its-first-orbital-flight-this-week/ar-AA19SxNv?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 15:01:47.547293+00:00



## Trump allies take fight to Bragg's backyard with hearing on NYC crime
 - [http://www.msn.com/en-us/news/politics/trump-allies-take-fight-to-bragg-s-backyard-with-hearing-on-nyc-crime/ar-AA19XnPB?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/trump-allies-take-fight-to-bragg-s-backyard-with-hearing-on-nyc-crime/ar-AA19XnPB?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 15:01:47.539220+00:00



## Ralph Yarl GoFundMe Raises $1M as Anger Grows Over Shooting of Black Teen
 - [http://www.msn.com/en-us/news/crime/ralph-yarl-gofundme-raises-1m-as-anger-grows-over-shooting-of-black-teen/ar-AA19Y5z0?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/ralph-yarl-gofundme-raises-1m-as-anger-grows-over-shooting-of-black-teen/ar-AA19Y5z0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 15:01:47.531177+00:00



## 11 Die of Heatstroke at Government-Backed Festival in 100-Degree Heat
 - [http://www.msn.com/en-us/news/world/11-die-of-heatstroke-at-government-backed-festival-in-100-degree-heat/ar-AA19XUn0?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/11-die-of-heatstroke-at-government-backed-festival-in-100-degree-heat/ar-AA19XUn0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 15:01:47.523530+00:00



## When are social media threats a crime? Supreme Court to decide
 - [http://www.msn.com/en-us/news/us/when-are-social-media-threats-a-crime-supreme-court-to-decide/ar-AA19X8FZ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/when-are-social-media-threats-a-crime-supreme-court-to-decide/ar-AA19X8FZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 15:01:47.514193+00:00



## Biden's pick for top WH economist faces Senate grilling
 - [http://www.msn.com/en-us/news/politics/biden-s-pick-for-top-wh-economist-faces-senate-grilling/ar-AA19XZfX?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-s-pick-for-top-wh-economist-faces-senate-grilling/ar-AA19XZfX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 15:01:47.506017+00:00



## Republicans call for TikTok ban in House, Senate
 - [http://www.msn.com/en-us/news/politics/republicans-call-for-tiktok-ban-in-house-senate/ar-AA19Y5zd?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/republicans-call-for-tiktok-ban-in-house-senate/ar-AA19Y5zd?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 15:01:47.497878+00:00



## America’s unique, enduring gun problem, explained
 - [http://www.msn.com/en-us/news/us/america-s-unique-enduring-gun-problem-explained/ar-AA19XRP4?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/america-s-unique-enduring-gun-problem-explained/ar-AA19XRP4?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 15:01:47.488034+00:00



## Slightly fewer Americans concerned about multiple environmental problems: Gallup
 - [http://www.msn.com/en-us/news/politics/slightly-fewer-americans-concerned-about-multiple-environmental-problems-gallup/ar-AA19XzdC?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/slightly-fewer-americans-concerned-about-multiple-environmental-problems-gallup/ar-AA19XzdC?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 14:02:06.115663+00:00



## U.S. Special Forces Silently Hunting ISIS in Syria
 - [http://www.msn.com/en-us/news/world/u-s-special-forces-silently-hunting-isis-in-syria/ar-AA19Xzo1?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/u-s-special-forces-silently-hunting-isis-in-syria/ar-AA19Xzo1?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 14:02:06.107728+00:00



## WATCH: House Judiciary Committee set to take Bragg to task over 'choosing to not enforce the laws'
 - [http://www.msn.com/en-us/news/politics/watch-house-judiciary-committee-set-to-take-bragg-to-task-over-choosing-to-not-enforce-the-laws/ar-AA19XYjF?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/watch-house-judiciary-committee-set-to-take-bragg-to-task-over-choosing-to-not-enforce-the-laws/ar-AA19XYjF?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 14:02:06.099820+00:00



## Watch SpaceX launch Starship, the tallest and most powerful rocket ever built, on its first orbital flight
 - [http://www.msn.com/en-us/news/technology/watch-spacex-launch-starship-the-tallest-and-most-powerful-rocket-ever-built-on-its-first-orbital-flight/ar-AA19SxNv?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/watch-spacex-launch-starship-the-tallest-and-most-powerful-rocket-ever-built-on-its-first-orbital-flight/ar-AA19SxNv?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 14:02:06.090017+00:00



## Chinese minister's tour underscores closer ties with Russia
 - [http://www.msn.com/en-us/news/world/chinese-minister-s-tour-underscores-closer-ties-with-russia/ar-AA19XT9N?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/chinese-minister-s-tour-underscores-closer-ties-with-russia/ar-AA19XT9N?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 14:02:06.082241+00:00



## Alternative Inventor? Biden admin opens door to non-human, AI patent holders
 - [http://www.msn.com/en-us/news/technology/alternative-inventor-biden-admin-opens-door-to-non-human-ai-patent-holders/ar-AA19XCfc?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/alternative-inventor-biden-admin-opens-door-to-non-human-ai-patent-holders/ar-AA19XCfc?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 14:02:06.074097+00:00



## SpaceX scrubs test flight of giant Starship rocket
 - [http://www.msn.com/en-us/news/technology/spacex-scrubs-test-flight-of-giant-starship-rocket/ar-AA19UrfJ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/spacex-scrubs-test-flight-of-giant-starship-rocket/ar-AA19UrfJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 14:02:06.065683+00:00



## House Speaker McCarthy opens next phase of debt ceiling fight with direct pitch to Wall Street
 - [http://www.msn.com/en-us/news/politics/house-speaker-mccarthy-opens-next-phase-of-debt-ceiling-fight-with-direct-pitch-to-wall-street/ar-AA19XYuG?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/house-speaker-mccarthy-opens-next-phase-of-debt-ceiling-fight-with-direct-pitch-to-wall-street/ar-AA19XYuG?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 14:02:06.056632+00:00



## Italian police scoop up 2 tons of cocaine bobbing in sea
 - [http://www.msn.com/en-us/news/world/italian-police-scoop-up-2-tons-of-cocaine-bobbing-in-sea/ar-AA19XNgh?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/italian-police-scoop-up-2-tons-of-cocaine-bobbing-in-sea/ar-AA19XNgh?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 13:02:17.050845+00:00



## Andrew Gillum, Former DeSantis Rival, Pleads for Donations as Trial Begins
 - [http://www.msn.com/en-us/news/politics/andrew-gillum-former-desantis-rival-pleads-for-donations-as-trial-begins/ar-AA19XFLh?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/andrew-gillum-former-desantis-rival-pleads-for-donations-as-trial-begins/ar-AA19XFLh?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 13:02:17.042025+00:00



## Noem blocks state agencies from banks that shun firearms manufacturers
 - [http://www.msn.com/en-us/news/politics/noem-blocks-state-agencies-from-banks-that-shun-firearms-manufacturers/ar-AA19XE11?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/noem-blocks-state-agencies-from-banks-that-shun-firearms-manufacturers/ar-AA19XE11?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 13:02:17.033208+00:00



## Russian spies are using Tinder to ensnare German soldiers and politicians to get them to disclose Ukraine war secrets, counterintelligence warns
 - [http://www.msn.com/en-us/news/world/russian-spies-are-using-tinder-to-ensnare-german-soldiers-and-politicians-to-get-them-to-disclose-ukraine-war-secrets-counterintelligence-warns/ar-AA19XxaM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russian-spies-are-using-tinder-to-ensnare-german-soldiers-and-politicians-to-get-them-to-disclose-ukraine-war-secrets-counterintelligence-warns/ar-AA19XxaM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 13:02:17.024503+00:00



## House Homeland Republicans mark 100 days of ‘well overdue’ oversight on border crisis, China
 - [http://www.msn.com/en-us/news/politics/house-homeland-republicans-mark-100-days-of-well-overdue-oversight-on-border-crisis-china/ar-AA19XSpF?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/house-homeland-republicans-mark-100-days-of-well-overdue-oversight-on-border-crisis-china/ar-AA19XSpF?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 13:02:17.014617+00:00



## Roman aristocrats visited a lavish winery to celebrate the 'theater' of winemaking
 - [http://www.msn.com/en-us/news/world/roman-aristocrats-visited-a-lavish-winery-to-celebrate-the-theater-of-winemaking/ar-AA19XIIL?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/roman-aristocrats-visited-a-lavish-winery-to-celebrate-the-theater-of-winemaking/ar-AA19XIIL?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 13:02:17.006400+00:00



## G-7 members vow tough position on China, North Korea and Russia aggression
 - [http://www.msn.com/en-us/news/world/g-7-members-vow-tough-position-on-china-north-korea-and-russia-aggression/ar-AA19XDZh?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/g-7-members-vow-tough-position-on-china-north-korea-and-russia-aggression/ar-AA19XDZh?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 13:02:16.998909+00:00



## Woman Threatening To Take Brother to Court Over $30K Engagement Ring Backed
 - [http://www.msn.com/en-us/news/world/woman-threatening-to-take-brother-to-court-over-30k-engagement-ring-backed/ar-AA19XtXo?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/woman-threatening-to-take-brother-to-court-over-30k-engagement-ring-backed/ar-AA19XtXo?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 12:02:12.106528+00:00



## G-7 Displays United Front on China After Macron Controversy
 - [http://www.msn.com/en-us/news/world/g-7-displays-united-front-on-china-after-macron-controversy/ar-AA19XqDa?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/g-7-displays-united-front-on-china-after-macron-controversy/ar-AA19XqDa?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 12:02:12.098723+00:00



## Sudan's civilian death toll nears 100 as fighting intensifies
 - [http://www.msn.com/en-us/news/world/sudan-s-civilian-death-toll-nears-100-as-fighting-intensifies/ar-AA19XtQ2?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/sudan-s-civilian-death-toll-nears-100-as-fighting-intensifies/ar-AA19XtQ2?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 12:02:12.090920+00:00



## The 100-year-old-mistake that’s reshaping the American West
 - [http://www.msn.com/en-us/news/us/the-100-year-old-mistake-that-s-reshaping-the-american-west/ar-AA19XfbL?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/the-100-year-old-mistake-that-s-reshaping-the-american-west/ar-AA19XfbL?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 12:02:12.083157+00:00



## ‘Meta-Content’ Is Taking Over the Internet
 - [http://www.msn.com/en-us/news/technology/meta-content-is-taking-over-the-internet/ar-AA19XCWS?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/meta-content-is-taking-over-the-internet/ar-AA19XCWS?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 12:02:12.074630+00:00



## Elon Musk says he's concerned that SpaceX's Starship could melt the launch pad if it 'fireballed' during takeoff
 - [http://www.msn.com/en-us/news/technology/elon-musk-says-he-s-concerned-that-spacex-s-starship-could-melt-the-launch-pad-if-it-fireballed-during-takeoff/ar-AA19XAwW?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/elon-musk-says-he-s-concerned-that-spacex-s-starship-could-melt-the-launch-pad-if-it-fireballed-during-takeoff/ar-AA19XAwW?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 12:02:12.066420+00:00



## Mitch McConnell returns to the Senate on Monday, six weeks after head injury
 - [http://www.msn.com/en-us/news/politics/mitch-mcconnell-returns-to-the-senate-on-monday-six-weeks-after-head-injury/ar-AA19XmYC?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/mitch-mcconnell-returns-to-the-senate-on-monday-six-weeks-after-head-injury/ar-AA19XmYC?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 12:02:12.057524+00:00



## Alabama authorities ask for community’s help after mass shooting kills 4
 - [http://www.msn.com/en-us/news/politics/alabama-authorities-ask-for-community-s-help-after-mass-shooting-kills-4/ar-AA19XpgA?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/alabama-authorities-ask-for-community-s-help-after-mass-shooting-kills-4/ar-AA19XpgA?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 12:02:12.049547+00:00



## Democrats seek negotiating advantage in GOP budget turmoil
 - [http://www.msn.com/en-us/news/politics/democrats-seek-negotiating-advantage-in-gop-budget-turmoil/ar-AA19WYs7?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/democrats-seek-negotiating-advantage-in-gop-budget-turmoil/ar-AA19WYs7?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 11:01:57.244762+00:00



## Fox News has lost control of its viewers
 - [http://www.msn.com/en-us/news/us/fox-news-has-lost-control-of-its-viewers/ar-AA19XnV0?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/fox-news-has-lost-control-of-its-viewers/ar-AA19XnV0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 11:01:57.236373+00:00



## Slovakia delivers remaining 9 of 13 warplanes promised to Ukraine
 - [http://www.msn.com/en-us/news/world/slovakia-delivers-remaining-9-of-13-warplanes-promised-to-ukraine/ar-AA19Xhve?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/slovakia-delivers-remaining-9-of-13-warplanes-promised-to-ukraine/ar-AA19Xhve?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 11:01:57.227397+00:00



## 500 Days Living in Underground Cave
 - [http://www.msn.com/en-us/news/world/500-days-living-in-underground-cave/ar-AA19WYHZ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/500-days-living-in-underground-cave/ar-AA19WYHZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 11:01:57.217779+00:00



## IS militants kill 31 truffle pickers in Syria
 - [http://www.msn.com/en-us/news/world/is-militants-kill-31-truffle-pickers-in-syria/ar-AA19X1vP?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/is-militants-kill-31-truffle-pickers-in-syria/ar-AA19X1vP?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 11:01:57.209043+00:00



## What is the child care crisis, exactly?
 - [http://www.msn.com/en-us/news/us/what-is-the-child-care-crisis-exactly/ar-AA19Xqqk?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/what-is-the-child-care-crisis-exactly/ar-AA19Xqqk?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 11:01:57.199728+00:00



## House panel led by Jim Jordan holds crime hearing in Alvin Bragg's New York City
 - [http://www.msn.com/en-us/news/politics/house-panel-led-by-jim-jordan-holds-crime-hearing-in-alvin-bragg-s-new-york-city/ar-AA19X4bh?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/house-panel-led-by-jim-jordan-holds-crime-hearing-in-alvin-bragg-s-new-york-city/ar-AA19X4bh?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 11:01:57.191963+00:00



## Sundar Pichai said AI will impact 'everything' including 'every product across every company'
 - [http://www.msn.com/en-us/money/technology/sundar-pichai-said-ai-will-impact-everything-including-every-product-across-every-company/ar-AA19X1zl?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/money/technology/sundar-pichai-said-ai-will-impact-everything-including-every-product-across-every-company/ar-AA19X1zl?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 11:01:57.181497+00:00



## SpaceX's Starship, the Biggest Rocket Ever Built, Is Poised to Fly
 - [http://www.msn.com/en-us/news/technology/spacex-s-starship-the-biggest-rocket-ever-built-is-poised-to-fly/ar-AA19X3IR?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/spacex-s-starship-the-biggest-rocket-ever-built-is-poised-to-fly/ar-AA19X3IR?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 10:02:01.336990+00:00



## Revenge is not a winning election message
 - [http://www.msn.com/en-us/news/politics/revenge-is-not-a-winning-election-message/ar-AA19X6qK?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/revenge-is-not-a-winning-election-message/ar-AA19X6qK?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 10:02:01.327345+00:00



## Joe Exotic Sends Message to Donald Trump From Prison: 'Screwed Me Over'
 - [http://www.msn.com/en-us/news/politics/joe-exotic-sends-message-to-donald-trump-from-prison-screwed-me-over/ar-AA19X4DA?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/joe-exotic-sends-message-to-donald-trump-from-prison-screwed-me-over/ar-AA19X4DA?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 10:02:01.319186+00:00



## US CENTCOM launches helicopter raid in northern Syria resulting in 'probable death' of ISIS senior leader
 - [http://www.msn.com/en-us/news/world/us-centcom-launches-helicopter-raid-in-northern-syria-resulting-in-probable-death-of-isis-senior-leader/ar-AA19X4qd?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/us-centcom-launches-helicopter-raid-in-northern-syria-resulting-in-probable-death-of-isis-senior-leader/ar-AA19X4qd?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 10:02:01.310690+00:00



## How Spotify Knows What You Want to Hear Next
 - [http://www.msn.com/en-us/news/technology/how-spotify-knows-what-you-want-to-hear-next/vi-AA19XiQz?srcref=rss](http://www.msn.com/en-us/news/technology/how-spotify-knows-what-you-want-to-hear-next/vi-AA19XiQz?srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 10:02:01.301635+00:00



## Design Recipes: 9 tips to make a spring move less stressful
 - [http://www.msn.com/en-us/news/us/design-recipes-9-tips-to-make-a-spring-move-less-stressful/ar-AA19X9fb?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/design-recipes-9-tips-to-make-a-spring-move-less-stressful/ar-AA19X9fb?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 10:02:01.293420+00:00



## Timeline: Trump's efforts to overturn Georgia election results
 - [http://www.msn.com/en-us/news/politics/timeline-trump-s-efforts-to-overturn-georgia-election-results/ar-AA19XiAB?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/timeline-trump-s-efforts-to-overturn-georgia-election-results/ar-AA19XiAB?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 10:02:01.284905+00:00



## Slovakia gives Ukraine remaining 9 of 13 promised warplanes
 - [http://www.msn.com/en-us/news/world/slovakia-gives-ukraine-remaining-9-of-13-promised-warplanes/ar-AA19X4Jb?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/slovakia-gives-ukraine-remaining-9-of-13-promised-warplanes/ar-AA19X4Jb?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 10:02:01.276324+00:00



## Jerry Zezima: Bathroom remodeling is a real soap opera
 - [http://www.msn.com/en-us/news/us/jerry-zezima-bathroom-remodeling-is-a-real-soap-opera/ar-AA19WWrX?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/jerry-zezima-bathroom-remodeling-is-a-real-soap-opera/ar-AA19WWrX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 09:02:05.976247+00:00



## Biden tries to break through as GOP primary brawl starts
 - [http://www.msn.com/en-us/news/politics/biden-tries-to-break-through-as-gop-primary-brawl-starts/ar-AA19X0mr?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-tries-to-break-through-as-gop-primary-brawl-starts/ar-AA19X0mr?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 09:02:05.967498+00:00



## VP Harris is top White House messenger on abortion fight
 - [http://www.msn.com/en-us/news/politics/vp-harris-is-top-white-house-messenger-on-abortion-fight/ar-AA19WOKZ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/vp-harris-is-top-white-house-messenger-on-abortion-fight/ar-AA19WOKZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 09:02:05.958798+00:00



## Alabama Birthday Party Shooting Leaves Four Killed and 28 Injured
 - [http://www.msn.com/en-us/video/news/alabama-birthday-party-shooting-leaves-four-killed-and-28-injured/vi-AA19WGUJ?srcref=rss](http://www.msn.com/en-us/video/news/alabama-birthday-party-shooting-leaves-four-killed-and-28-injured/vi-AA19WGUJ?srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 09:02:05.950733+00:00



## Russia Shifting Offensive Ops to Elite Airborne Troops—ISW
 - [http://www.msn.com/en-us/news/world/russia-shifting-offensive-ops-to-elite-airborne-troops-isw/ar-AA19XcO9?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russia-shifting-offensive-ops-to-elite-airborne-troops-isw/ar-AA19XcO9?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 09:02:05.942883+00:00



## Why GOP culture warriors lost big in school board races this month
 - [http://www.msn.com/en-us/news/politics/why-gop-culture-warriors-lost-big-in-school-board-races-this-month/ar-AA19XcTp?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/why-gop-culture-warriors-lost-big-in-school-board-races-this-month/ar-AA19XcTp?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 09:02:05.934294+00:00



## 6 children rescued near water diversion tunnel in Auburn, Massachusetts
 - [http://www.msn.com/en-us/news/crime/6-children-rescued-near-water-diversion-tunnel-in-auburn-massachusetts/ar-AA19WzF0?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/6-children-rescued-near-water-diversion-tunnel-in-auburn-massachusetts/ar-AA19WzF0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 08:02:00.343197+00:00



## 'Never Asked': Woman Not Telling Boyfriend She Speaks His Language Backed
 - [http://www.msn.com/en-us/news/world/never-asked-woman-not-telling-boyfriend-she-speaks-his-language-backed/ar-AA19WVYM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/never-asked-woman-not-telling-boyfriend-she-speaks-his-language-backed/ar-AA19WVYM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 08:02:00.334163+00:00



## Police release body camera footage after shooting homeowner at wrong address
 - [http://www.msn.com/en-us/news/crime/police-release-body-camera-footage-after-shooting-homeowner-at-wrong-address/ar-AA19WyTk?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/police-release-body-camera-footage-after-shooting-homeowner-at-wrong-address/ar-AA19WyTk?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 07:02:09.419548+00:00



## Prince Andrew 'resentful' toward King Charles, 'dragging his heels' over leaving lavish home, experts claim
 - [http://www.msn.com/en-us/news/world/prince-andrew-resentful-toward-king-charles-dragging-his-heels-over-leaving-lavish-home-experts-claim/ar-AA19WUXE?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/prince-andrew-resentful-toward-king-charles-dragging-his-heels-over-leaving-lavish-home-experts-claim/ar-AA19WUXE?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 07:02:09.408524+00:00



## Eleven die of heatstroke at Indian award function
 - [http://www.msn.com/en-us/news/world/eleven-die-of-heatstroke-at-indian-award-function/ar-AA19WSJV?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/eleven-die-of-heatstroke-at-indian-award-function/ar-AA19WSJV?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 07:02:09.400223+00:00



## Ex-leader Merkel to be decorated with highest German honor
 - [http://www.msn.com/en-us/news/world/ex-leader-merkel-to-be-decorated-with-highest-german-honor/ar-AA19WVlw?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/ex-leader-merkel-to-be-decorated-with-highest-german-honor/ar-AA19WVlw?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 07:02:09.390971+00:00



## Elon Musk claims the US Government had 'full access' to your private Twitter DMs
 - [http://www.msn.com/en-us/news/technology/elon-musk-claims-the-us-government-had-full-access-to-your-private-twitter-dms/ar-AA19WbJz?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/elon-musk-claims-the-us-government-had-full-access-to-your-private-twitter-dms/ar-AA19WbJz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 06:01:58.500688+00:00



## John Oliver Roasts the NRA Over Mortifying ‘Diversity’ Gaffe
 - [http://www.msn.com/en-us/news/politics/john-oliver-roasts-the-nra-over-mortifying-diversity-gaffe/ar-AA19WbIm?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/john-oliver-roasts-the-nra-over-mortifying-diversity-gaffe/ar-AA19WbIm?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 06:01:58.484882+00:00



## Trump’s House GOP allies take fight to Manhattan DA's turf
 - [http://www.msn.com/en-us/news/politics/trump-s-house-gop-allies-take-fight-to-manhattan-da-s-turf/ar-AA19WUFk?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/trump-s-house-gop-allies-take-fight-to-manhattan-da-s-turf/ar-AA19WUFk?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 06:01:58.474963+00:00



## Family of Black teen shot after ringing wrong doorbell retains civil rights lawyers
 - [http://www.msn.com/en-us/news/crime/family-of-black-teen-shot-after-ringing-wrong-doorbell-retains-civil-rights-lawyers/ar-AA19WS7o?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/family-of-black-teen-shot-after-ringing-wrong-doorbell-retains-civil-rights-lawyers/ar-AA19WS7o?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 06:01:58.465728+00:00



## Almost half of Taiwan's aircraft isn't ready for war, and its air force doesn't have a coordinated radio network to stave off a Chinese invasion: Pentagon leak
 - [http://www.msn.com/en-us/news/world/almost-half-of-taiwan-s-aircraft-isn-t-ready-for-war-and-its-air-force-doesn-t-have-a-coordinated-radio-network-to-stave-off-a-chinese-invasion-pentagon-leak/ar-AA19W6QL?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/almost-half-of-taiwan-s-aircraft-isn-t-ready-for-war-and-its-air-force-doesn-t-have-a-coordinated-radio-network-to-stave-off-a-chinese-invasion-pentagon-leak/ar-AA19W6QL?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 06:01:58.455598+00:00



## GOP congressman blames Biden for shutdown of largest coal plant in Pennsylvania
 - [http://www.msn.com/en-us/news/politics/gop-congressman-blames-biden-for-shutdown-of-largest-coal-plant-in-pennsylvania/ar-AA19WAnL?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/gop-congressman-blames-biden-for-shutdown-of-largest-coal-plant-in-pennsylvania/ar-AA19WAnL?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 05:01:50.383449+00:00



## US, allies conduct more drills in face of N. Korean threat
 - [http://www.msn.com/en-us/news/world/us-allies-conduct-more-drills-in-face-of-n-korean-threat/ar-AA19WKkQ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/us-allies-conduct-more-drills-in-face-of-n-korean-threat/ar-AA19WKkQ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 05:01:50.372705+00:00



## Papua rebels attack soldiers searching for NZ pilot
 - [http://www.msn.com/en-us/news/world/papua-rebels-attack-soldiers-searching-for-nz-pilot/ar-AA19Wmqy?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/papua-rebels-attack-soldiers-searching-for-nz-pilot/ar-AA19Wmqy?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 05:01:50.362948+00:00



## Alabama mass shooting updates: 4 killed, 28 hurt in shooting at birthday party
 - [http://www.msn.com/en-us/news/crime/alabama-mass-shooting-updates-4-killed-28-hurt-in-shooting-at-birthday-party/ar-AA19VAlR?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/alabama-mass-shooting-updates-4-killed-28-hurt-in-shooting-at-birthday-party/ar-AA19VAlR?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 05:01:50.353711+00:00



## Read the Leaked Secret Intelligence Documents on Ukraine and Vladimir Putin
 - [http://www.msn.com/en-us/news/world/read-the-leaked-secret-intelligence-documents-on-ukraine-and-vladimir-putin/ar-AA19WtyR?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/read-the-leaked-secret-intelligence-documents-on-ukraine-and-vladimir-putin/ar-AA19WtyR?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 04:02:09.152657+00:00



## 4 killed, 28 injured at 16-year-old's birthday party in Alabama, police say
 - [http://www.msn.com/en-us/news/crime/4-killed-28-injured-at-16-year-old-s-birthday-party-in-alabama-police-say/ar-AA19VBni?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/4-killed-28-injured-at-16-year-old-s-birthday-party-in-alabama-police-say/ar-AA19VBni?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 04:02:09.144538+00:00



## Hagerty becomes eighth GOP senator to endorse Trump in 2024 primary
 - [http://www.msn.com/en-us/news/politics/hagerty-becomes-eighth-gop-senator-to-endorse-trump-in-2024-primary/ar-AA19WlUp?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/hagerty-becomes-eighth-gop-senator-to-endorse-trump-in-2024-primary/ar-AA19WlUp?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 04:02:09.136327+00:00



## Judge in Proud Boys trial rejects claims of government misconduct
 - [http://www.msn.com/en-us/news/crime/judge-in-proud-boys-trial-rejects-claims-of-government-misconduct/ar-AA19WzU6?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/judge-in-proud-boys-trial-rejects-claims-of-government-misconduct/ar-AA19WzU6?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 04:02:09.128363+00:00



## SpaceX Eyes Monday Test Flight for its Massive Starship Rocket
 - [http://www.msn.com/en-us/news/technology/spacex-eyes-monday-test-flight-for-its-massive-starship-rocket/ar-AA19WCCP?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/spacex-eyes-monday-test-flight-for-its-massive-starship-rocket/ar-AA19WCCP?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 04:02:09.121036+00:00



## U.S. warship sails in Taiwan Strait after China's exercises
 - [http://www.msn.com/en-us/news/world/u-s-warship-sails-in-taiwan-strait-after-china-s-exercises/ar-AA19W6lM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/u-s-warship-sails-in-taiwan-strait-after-china-s-exercises/ar-AA19W6lM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 04:02:09.111419+00:00



## Google May Lose Search on Samsung Devices to Microsoft Bing: NYT
 - [http://www.msn.com/en-us/news/technology/google-may-lose-search-on-samsung-devices-to-microsoft-bing-nyt/ar-AA19W5yN?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/google-may-lose-search-on-samsung-devices-to-microsoft-bing-nyt/ar-AA19W5yN?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 03:01:44.227807+00:00



## GOP Congresswoman Pleads With Colleagues to Ease Off ‘Extreme’ Positions
 - [http://www.msn.com/en-us/news/politics/gop-congresswoman-pleads-with-colleagues-to-ease-off-extreme-positions/ar-AA19VZ3n?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/gop-congresswoman-pleads-with-colleagues-to-ease-off-extreme-positions/ar-AA19VZ3n?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 03:01:44.215240+00:00



## G-7 envoys urge tough stance on Chinese, N Korean aggression
 - [http://www.msn.com/en-us/news/world/g-7-envoys-urge-tough-stance-on-chinese-n-korean-aggression/ar-AA19Wlv9?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/g-7-envoys-urge-tough-stance-on-chinese-n-korean-aggression/ar-AA19Wlv9?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 03:01:44.207272+00:00



## US conducts raid against ISIS fighters in Syria: Official
 - [http://www.msn.com/en-us/news/world/us-conducts-raid-against-isis-fighters-in-syria-official/ar-AA19WqqX?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/us-conducts-raid-against-isis-fighters-in-syria-official/ar-AA19WqqX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 03:01:44.199172+00:00



## Marjorie Taylor Greene Mocks Lindsey Graham With Doctored Bud Light Photo
 - [http://www.msn.com/en-us/news/politics/marjorie-taylor-greene-mocks-lindsey-graham-with-doctored-bud-light-photo/ar-AA19VTXT?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/marjorie-taylor-greene-mocks-lindsey-graham-with-doctored-bud-light-photo/ar-AA19VTXT?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 02:01:31.039927+00:00



## Uganda's failure to jail child rapists
 - [http://www.msn.com/en-us/news/world/uganda-s-failure-to-jail-child-rapists/ar-AA19WgxB?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/uganda-s-failure-to-jail-child-rapists/ar-AA19WgxB?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 02:01:31.028724+00:00



## Tennessee Air National Guardsman charged with applying to be hit man
 - [http://www.msn.com/en-us/news/us/tennessee-air-national-guardsman-charged-with-applying-to-be-hit-man/ar-AA19W4Qm?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/tennessee-air-national-guardsman-charged-with-applying-to-be-hit-man/ar-AA19W4Qm?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 02:01:31.021166+00:00



## Google working on dramatic search changes to counter AI rivals: report
 - [http://www.msn.com/en-us/news/technology/google-working-on-dramatic-search-changes-to-counter-ai-rivals-report/ar-AA19WpWk?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/google-working-on-dramatic-search-changes-to-counter-ai-rivals-report/ar-AA19WpWk?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 02:01:31.013734+00:00



## 4 killed, 28 injured at 16-year-old's birthday party in Alabama, police say
 - [http://www.msn.com/en-us/news/us/4-killed-28-injured-at-16-year-old-s-birthday-party-in-alabama-police-say/ar-AA19VBni?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/4-killed-28-injured-at-16-year-old-s-birthday-party-in-alabama-police-say/ar-AA19VBni?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 02:01:31.004656+00:00



## Florida police want to speak to woman with 'long blonde hair' in 35-year-old cold case murder investigation
 - [http://www.msn.com/en-us/news/crime/florida-police-want-to-speak-to-woman-with-long-blonde-hair-in-35-year-old-cold-case-murder-investigation/ar-AA19WaO6?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/florida-police-want-to-speak-to-woman-with-long-blonde-hair-in-35-year-old-cold-case-murder-investigation/ar-AA19WaO6?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 02:01:30.996653+00:00



## Danish Royal Family celebrate Queen Margrethe's 83rd birthday
 - [http://www.msn.com/en-us/news/world/danish-royal-family-celebrate-queen-margrethe-s-83rd-birthday/ar-AA19W9Cd?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/danish-royal-family-celebrate-queen-margrethe-s-83rd-birthday/ar-AA19W9Cd?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 00:57:32.361649+00:00



## In 2023, All the Best Video Games Are Old
 - [http://www.msn.com/en-us/news/technology/in-2023-all-the-best-video-games-are-old/ar-AA19Qdu3?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/in-2023-all-the-best-video-games-are-old/ar-AA19Qdu3?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 00:57:32.352345+00:00



## Tim Scott Could Win—if Trump and DeSantis Go Nuclear
 - [http://www.msn.com/en-us/news/politics/tim-scott-could-win-if-trump-and-desantis-go-nuclear/ar-AA19VYuX?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/tim-scott-could-win-if-trump-and-desantis-go-nuclear/ar-AA19VYuX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 00:57:32.344527+00:00



## Fathers shot, daughters killed in bombings: Ghosts of the blood-soaked Troubles haunt Northern Ireland
 - [http://www.msn.com/en-us/news/world/fathers-shot-daughters-killed-in-bombings-ghosts-of-the-blood-soaked-troubles-haunt-northern-ireland/ar-AA19WdM5?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/fathers-shot-daughters-killed-in-bombings-ghosts-of-the-blood-soaked-troubles-haunt-northern-ireland/ar-AA19WdM5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 00:57:32.337146+00:00



## 7 dead, including child, after gunmen storm Mexican resort
 - [http://www.msn.com/en-us/news/world/7-dead-including-child-after-gunmen-storm-mexican-resort/ar-AA19VR3s?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/7-dead-including-child-after-gunmen-storm-mexican-resort/ar-AA19VR3s?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 00:57:30.796995+00:00



## Start of trial in Dominion lawsuit against Fox News delayed
 - [http://www.msn.com/en-us/news/us/start-of-trial-in-dominion-lawsuit-against-fox-news-delayed/ar-AA19Ws3K?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/start-of-trial-in-dominion-lawsuit-against-fox-news-delayed/ar-AA19Ws3K?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 00:57:30.788334+00:00



## 'Fiddler on the Roof' star Chaim Topol lived double life as Mossad agent, family says following his death
 - [http://www.msn.com/en-us/news/world/fiddler-on-the-roof-star-chaim-topol-lived-double-life-as-mossad-agent-family-says-following-his-death/ar-AA19Wgr4?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/fiddler-on-the-roof-star-chaim-topol-lived-double-life-as-mossad-agent-family-says-following-his-death/ar-AA19Wgr4?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 00:57:30.777970+00:00



## Judge delays Fox News vs. Dominion trial by one day
 - [http://www.msn.com/en-us/news/politics/judge-delays-fox-news-vs-dominion-trial-by-one-day/ar-AA19WkOU?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/judge-delays-fox-news-vs-dominion-trial-by-one-day/ar-AA19WkOU?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-04-17 00:57:29.229660+00:00



