# Source:Sky News, URL:http://feeds.skynews.com/feeds/rss/world.xml, language:en-US

## Eight police officers who shot unarmed man 46 times cleared of wrongdoing
 - [https://news.sky.com/story/jayland-walker-eight-police-officers-who-shot-unarmed-man-46-times-cleared-of-wrongdoing-12859727](https://news.sky.com/story/jayland-walker-eight-police-officers-who-shot-unarmed-man-46-times-cleared-of-wrongdoing-12859727)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-04-17 19:57:00+00:00

Eight police officers who killed an unarmed man after shooting him 46 times have been cleared of wrongdoing.

## Climate for intervention by African leaders 'not suitable', Sudan's army chief says, as millions remain trapped
 - [https://news.sky.com/story/sudans-army-chief-says-climate-for-intervention-by-african-leaders-not-suitable-as-millions-remain-trapped-12859635](https://news.sky.com/story/sudans-army-chief-says-climate-for-intervention-by-african-leaders-not-suitable-as-millions-remain-trapped-12859635)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-04-17 17:30:00+00:00

Abdel-Fattah al Burhan's voice was jovial when he first answered the phone.

## Two charged with 'running illegal police station' in New York for Chinese government
 - [https://news.sky.com/story/two-charged-with-running-illegal-police-station-in-new-york-for-chinese-government-12859634](https://news.sky.com/story/two-charged-with-running-illegal-police-station-in-new-york-for-chinese-government-12859634)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-04-17 17:15:00+00:00

Two New York residents have been arrested and charged after allegedly running an illegal Manhattan police station for the Chinese government.

## Revealed: The three food groups responsible for type 2 diabetes rise
 - [https://news.sky.com/story/three-dietary-factors-most-to-blame-for-the-increase-in-type-2-diabetes-research-says-12859590](https://news.sky.com/story/three-dietary-factors-most-to-blame-for-the-increase-in-type-2-diabetes-research-says-12859590)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-04-17 16:06:00+00:00

Researchers have identified three dietary factors that could be most to blame for the increase in type 2 diabetes.

## Sudan army chief open to negotiations - but says his troops will 'definitely' defeat paramilitary group
 - [https://news.sky.com/story/sudan-army-chief-open-to-negotiations-but-says-his-troops-will-definitely-defeat-paramilitary-group-12859492](https://news.sky.com/story/sudan-army-chief-open-to-negotiations-but-says-his-troops-will-definitely-defeat-paramilitary-group-12859492)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-04-17 13:43:00+00:00

The head of Sudan's army has told Sky News his troops will "definitely" defeat an attacking paramilitary group, but he is open to negotiations.

## German cannibal's former home destroyed in fire
 - [https://news.sky.com/story/fire-destroys-home-of-german-cannibal-armin-meiwes-12859474](https://news.sky.com/story/fire-destroys-home-of-german-cannibal-armin-meiwes-12859474)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-04-17 13:20:00+00:00

The former home of a German cannibal has been destroyed in a fire, police say.

## 'Record' haul of cocaine found floating in sea
 - [https://news.sky.com/story/record-haul-of-cocaine-found-floating-off-coast-of-sicily-12859400](https://news.sky.com/story/record-haul-of-cocaine-found-floating-off-coast-of-sicily-12859400)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-04-17 11:28:00+00:00

A "record" amount of cocaine worth &#8364;400m (&#163;353m) has been recovered off the coast of Sicily.

## Treason trial of Putin critic shows near-total removal of basic rights in Russia
 - [https://news.sky.com/story/vladimir-kara-murza-treason-trial-of-putin-critic-shows-near-total-removal-of-basic-rights-in-russia-12859345](https://news.sky.com/story/vladimir-kara-murza-treason-trial-of-putin-critic-shows-near-total-removal-of-basic-rights-in-russia-12859345)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-04-17 10:24:00+00:00

Vladimir Kara-Murza has been sentenced by Moscow's city court to 25 years in jail after it found him guilty of charges including treason and spreading misinformation about Russia's military.&#160;

## UK forms nuclear alliance designed to edge Russia out of international market
 - [https://news.sky.com/story/uk-forms-nuclear-alliance-designed-to-edge-russia-out-of-international-market-12859340](https://news.sky.com/story/uk-forms-nuclear-alliance-designed-to-edge-russia-out-of-international-market-12859340)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-04-17 10:20:00+00:00

Five of the world's largest economies are hoping to undermine Russia's grip on nuclear power supplies by shutting it out of a new alliance.

## Black teenager shot 'in head' after going to wrong house to collect younger brothers
 - [https://news.sky.com/story/kansas-city-black-teenager-shot-in-head-after-going-to-wrong-house-to-collect-younger-brothers-12859309](https://news.sky.com/story/kansas-city-black-teenager-shot-in-head-after-going-to-wrong-house-to-collect-younger-brothers-12859309)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-04-17 09:50:00+00:00

A black teenager in the US has been shot in the head after going to the wrong house to pick up his younger twin brothers, his family has said.

## Russian opposition leader jailed for 25 years after treason conviction
 - [https://news.sky.com/story/vladimir160kara-murza-putin-critic-jailed-for-25-years-in-russia-for-treason-after-criticising-ukraine-invasion-12859257](https://news.sky.com/story/vladimir160kara-murza-putin-critic-jailed-for-25-years-in-russia-for-treason-after-criticising-ukraine-invasion-12859257)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-04-17 08:19:00+00:00

One of Vladimir Putin's biggest critics has been jailed in Russia for 25 years after being found guilty of treason.

## Gerry Hutch found not guilty of gangland hotel murder
 - [https://news.sky.com/story/gerry-hutch-found-not-guilty-of-gangland-regency-hotel-murder-12859255](https://news.sky.com/story/gerry-hutch-found-not-guilty-of-gangland-regency-hotel-murder-12859255)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-04-17 08:05:00+00:00

Gerry Hutch has been found not guilty of murdering a man at a Dublin hotel in 2016.

## Dramatic before-and-after images show impact of deadly Sudan clashes
 - [https://news.sky.com/story/sudan-dramatic-before-and-after-images-show-impact-of-deadly-clashes-12859238](https://news.sky.com/story/sudan-dramatic-before-and-after-images-show-impact-of-deadly-clashes-12859238)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-04-17 07:22:00+00:00

Dramatic before-and-after pictures show fire and smoke pouring from the airport in Sudan's capital amid fierce clashes in the country.

## SpaceX to launch Starship, its most powerful rocket, today
 - [https://news.sky.com/story/spacex-will-launch-first-flight-test-of-starship-rocket-today-12858642](https://news.sky.com/story/spacex-will-launch-first-flight-test-of-starship-rocket-today-12858642)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-04-17 06:30:00+00:00

SpaceX will launch its Starship rocket system for the first time today.

## Air France and Airbus cleared of involuntary manslaughter over 2009 crash which killed 228 people
 - [https://news.sky.com/story/air-france-and-airbus-cleared-of-involuntary-manslaughter-over-2009-crash-which-killed-228-people-12859191](https://news.sky.com/story/air-france-and-airbus-cleared-of-involuntary-manslaughter-over-2009-crash-which-killed-228-people-12859191)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-04-17 05:09:00+00:00

Air France and Airbus have been found not guilty of involuntary manslaughter over the crash of Flight 447 in 2009 that killed 228 people.

