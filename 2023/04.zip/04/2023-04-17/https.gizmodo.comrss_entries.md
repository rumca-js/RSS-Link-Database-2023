# Source:Gizmodo, URL:https://gizmodo.com/rss, language:en-US

## Who Is Jack Teixeira, the Man Accused of Leaking Pentagon Documents on Discord?
 - [https://gizmodo.com/jack-teixeira-discord-pentagon-leaked-documents-1850338094](https://gizmodo.com/jack-teixeira-discord-pentagon-leaked-documents-1850338094)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-17 22:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--bWiq1htf--/c_fit,fl_progressive,q_80,w_636/ac967f12f328a1c6737d8ea273a64307.png" /><p>Last week, the U.S. government <a href="https://gizmodo.com/jack-teixeira-pentagon-leaks-discord-massachusetts-air-1850332980">arrested</a> a man accused of one the worst leaks of national security material in years.</p><p><a href="https://gizmodo.com/jack-teixeira-discord-pentagon-leaked-documents-1850338094">Read more...</a></p>

## AMC+ is Jumping on the Ad-Supported Bandwagon
 - [https://gizmodo.com/amc-plus-streaming-ad-supported-tier-netflix-disney-rok-1850345499](https://gizmodo.com/amc-plus-streaming-ad-supported-tier-netflix-disney-rok-1850345499)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-17 21:25:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--x3vuGT3D--/c_fit,fl_progressive,q_80,w_636/641368a5567e5fba73898b9d4f551dd7.png" /><p>Streaming services are in their struggle season.  An increasingly crowded field of offerings seems to have heightened competition and left would-be customers ambivalent and overwhelmed by the many and often less-than-comprehensive options. As varying streaming services strain to maintain and/or attract subscribers, <a href="https://gizmodo.com/netflix-netflix-with-ads-streaming-services-1849738107">…</a></p><p><a href="https://gizmodo.com/amc-plus-streaming-ad-supported-tier-netflix-disney-rok-1850345499">Read more...</a></p>

## Anne Rice's Interview With the Vampire Spinoff, Night Island, Finds its Writer
 - [https://gizmodo.com/anne-rice-interview-with-the-vampire-night-island-amc-1850344962](https://gizmodo.com/anne-rice-interview-with-the-vampire-night-island-amc-1850344962)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-17 21:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--RPrRswPv--/c_fit,fl_progressive,q_80,w_636/b60e034cdfd1d0a2dd0f25adf22af264.jpg" /><p>In the <a href="https://gizmodo.com/everything-we-know-anne-rice-immortal-universe-faq-1849832285">Anne Rice universe</a>, Night Island is a special place for vampires: a haven of sorts, where all their needs are taken care of. <a href="https://gizmodo.com/interview-with-the-vampire-eric-bogosian-assad-zaman-1849792499">AMC</a> had previously announced a <a href="https://gizmodo.com/interview-with-vampire-season-2-claudia-recast-1850290405">spinoff series</a> featuring the supernatural spa town, but has now released a little more information—namely that Jonathan Ceniceroz, one of the writers for <em></em>…</p><p><a href="https://gizmodo.com/anne-rice-interview-with-the-vampire-night-island-amc-1850344962">Read more...</a></p>

## Spotify Drops Paywall for Gimlet Shows as It Struggles With Podcasts and Audiobooks
 - [https://gizmodo.com/spotify-gimlet-podcasts-paywall-dropped-science-vs-1850345046](https://gizmodo.com/spotify-gimlet-podcasts-paywall-dropped-science-vs-1850345046)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-17 20:41:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--XvVZ582Y--/c_fit,fl_progressive,q_80,w_636/e016122082ee8d91249a881bff4605da.jpg" /><p>After spending years and hundreds of millions of dollars in building up an in-house suite of paywalled podcasts on its streaming service, Spotify is now re-evaluating that exclusivity and has revealed to employees that Gimlet Media podcasts will start being licensed to other platforms.<br /></p><p><a href="https://gizmodo.com/spotify-gimlet-podcasts-paywall-dropped-science-vs-1850345046">Read more...</a></p>

## James McAvoy Will Star in a Remake of One of the Most Horrifying Movies Ever Made
 - [https://gizmodo.com/james-mcavoy-blumhouse-horror-remake-speak-no-evil-1850345255](https://gizmodo.com/james-mcavoy-blumhouse-horror-remake-speak-no-evil-1850345255)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-17 20:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--_cLWHpqQ--/c_fit,fl_progressive,q_80,w_636/a4582d5e9e1c9bd908f323bfcdd3c06f.jpg" /><p><a href="https://gizmodo.com/speak-no-evil-horror-sundance-tafdrup-shudder-1848418109"><em>Speak No Evil</em></a>—the tale of two families who meet on vacation and plan a weekend reunion, which one family rapidly comes to regret—is the kind of movie that aims to traumatize the viewer... and succeeds. Now the 2002 Dutch horror standout is getting an American remake starring <a href="https://gizmodo.com/james-mcavoy-on-standing-next-to-pennywise-i-dont-like-1831868626">James McAvoy</a>.</p><p><a href="https://gizmodo.com/james-mcavoy-blumhouse-horror-remake-speak-no-evil-1850345255">Read more...</a></p>

## Rapid Test Could Tell You If There's Salmonella in Your Chicken
 - [https://gizmodo.com/researchers-create-rapid-salmonella-test-food-1850345457](https://gizmodo.com/researchers-create-rapid-salmonella-test-food-1850345457)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-17 20:26:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--_ipIQ2Wu--/c_fit,fl_progressive,q_80,w_636/82779a179163d0e0231dd7893dc0104d.jpg" /><p>Scientists in Canada say they’ve developed a cheap and easy way to find out <em>Salmonella</em> is lurking in food. Their method can apparently detect the bacteria within an hour’s time and with less set-up required than a typical at-home covid test. They believe that their test could be used by poultry processors and food…</p><p><a href="https://gizmodo.com/researchers-create-rapid-salmonella-test-food-1850345457">Read more...</a></p>

## Feds Allege China Disrupted and Spied on Dissidents’ Zoom Calls
 - [https://gizmodo.com/feds-china-disrupted-and-spied-on-dissidents-zoom-call-1850345340](https://gizmodo.com/feds-china-disrupted-and-spied-on-dissidents-zoom-call-1850345340)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-17 20:20:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--WAGygscy--/c_fit,fl_progressive,q_80,w_636/e6ce08f7869dad043b564eec6441b45e.jpg" /><p>On Monday, the U.S. Attorney’s Office for the Eastern District of New York <a href="https://www.facebook.com/EDNYnews/videos/760656668989892/" rel="noopener noreferrer" target="_blank">alleged</a> that the Chinese government used all sorts of techniques to harass and spy on Chinese dissidents living in the United States. This included a massive bot farm on Twitter, harassing dissidents on Zoom calls, and even physically setting…</p><p><a href="https://gizmodo.com/feds-china-disrupted-and-spied-on-dissidents-zoom-call-1850345340">Read more...</a></p>

## Chinese Satellite Goes on Inexplicable Sightseeing Tour After Researchers Put AI in Control
 - [https://gizmodo.com/chinese-researchers-let-ai-control-satellite-1850344169](https://gizmodo.com/chinese-researchers-let-ai-control-satellite-1850344169)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-17 20:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--OplJGi6Y--/c_fit,fl_progressive,q_80,w_636/6c8593bf3d817cc49a566743dee949a5.jpg" /><p>There’s been plenty of conversation around using AI in writing and  art, but researchers in China have evidently brought machine intelligence to spaceflight. An AI was allowed to control a satellite’s camera for a full day, during which time it took photos of different locations on Earth—and it chose targets for…</p><p><a href="https://gizmodo.com/chinese-researchers-let-ai-control-satellite-1850344169">Read more...</a></p>

## The Military Could Throw a Big Wrench in Biden's Offshore Wind Plans
 - [https://gizmodo.com/the-military-could-throw-a-big-wrench-in-bidens-offshor-1850344176](https://gizmodo.com/the-military-could-throw-a-big-wrench-in-bidens-offshor-1850344176)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-17 20:05:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--38Tfp-Zv--/c_fit,fl_progressive,q_80,w_636/828772311734bd3dd7d594c078ee6650.jpg" /><p>Pentagon pushback could imperil national plans for a sustainably powered future. Maps from the Department of Defense show that the U.S. military has serious concerns about planned offshore wind development, according to a <a href="https://www.bloomberg.com/news/articles/2023-04-17/pentagon-calls-biden-wind-farm-plans-problematic-for-us-military" rel="noopener noreferrer" target="_blank">Monday report</a> from Bloomberg.<br /></p><p><a href="https://gizmodo.com/the-military-could-throw-a-big-wrench-in-bidens-offshor-1850344176">Read more...</a></p>

## 10 Things We Liked (and 3 We Didn't) About Prime Video's Dead Ringers Series
 - [https://gizmodo.com/dead-ringers-rachel-weisz-review-prime-video-cronenberg-1850319159](https://gizmodo.com/dead-ringers-rachel-weisz-review-prime-video-cronenberg-1850319159)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-17 20:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--SYsIZ2Yc--/c_fit,fl_progressive,q_80,w_636/f413a6185d766e796b920e874f1e3917.png" /><p>The horror of David Cronenberg’s 1988 <em>Dead Ringers </em>is <a href="https://gizmodo.com/dead-ringers-1988-cronenberg-jeremy-irons-retro-review-1850259966">still potent enough to get under your skin</a>, but <a href="https://gizmodo.com/dead-ringers-promises-tainted-love-and-psycho-sisters-i-1850269529">Prime Video’s six-episode <em>Dead Ringers</em> series</a> starring Rachel Weisz as the Mantle twins—played by Jeremy Irons in the original film—offers <a href="https://gizmodo.com/dead-ringers-rachel-weisz-prime-video-series-cronenberg-1850300071?rev=1681239076424">a similarly potent yet significantly altered</a> exploration of medical…</p><p><a href="https://gizmodo.com/dead-ringers-rachel-weisz-review-prime-video-cronenberg-1850319159">Read more...</a></p>

## Google Stock Drops as Samsung Considers Switching Its Devices to Bing
 - [https://gizmodo.com/google-stock-drop-samsung-bing-search-engine-galaxy-1850345119](https://gizmodo.com/google-stock-drop-samsung-bing-search-engine-galaxy-1850345119)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-17 19:50:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--1wRZxxiA--/c_fit,fl_progressive,q_80,w_636/9a908945bf9691449528b7f19bb67508.jpg" /><p><a href="https://gizmodo.com/microsoft-bing-surpasses-100-million-daily-active-users-1850206640">Bing could be taking over</a> as the default search engine on <a href="https://gizmodo.com/tech/samsung">Samsung</a> devices thanks to its integration of ChatGPT <a href="https://gizmodo.com/tech/artificial-intelligence">Artificial Intelligence</a> features. The shift would mark the first time in 12 years that Samsung has strayed away from <a href="https://gizmodo.com/tech/google">Google</a>, which has historically dominated the search engine market.</p><p><a href="https://gizmodo.com/google-stock-drop-samsung-bing-search-engine-galaxy-1850345119">Read more...</a></p>

## Samples From Deep Ocean Trench Contain Alarming Levels of Industrial Chemicals
 - [https://gizmodo.com/pcbs-found-atacama-trench-deep-ocean-pollution-1850343485](https://gizmodo.com/pcbs-found-atacama-trench-deep-ocean-pollution-1850343485)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-17 19:42:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--Q5hsWREK--/c_fit,fl_progressive,q_80,w_636/670c75aaf802aa7842bdebe785fb1f2a.jpg" /><p>Decades after manufacturers have stopped producing a class of harmful chemicals once used in electrical equipment, traces of these chemicals have found in a deep sea trench.</p><p><a href="https://gizmodo.com/pcbs-found-atacama-trench-deep-ocean-pollution-1850343485">Read more...</a></p>

## Fitbit's Wearable for Tracking Kids Has a Camera and Cute Colors
 - [https://gizmodo.com/fitbit-kids-watch-smartwatch-wearable-tracking-fitness-1850344900](https://gizmodo.com/fitbit-kids-watch-smartwatch-wearable-tracking-fitness-1850344900)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-17 19:25:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--lRX_ds6x--/c_fit,fl_progressive,q_80,w_636/06890cae41c04110dfa13023b9f44af3.png" /><p>What’s the easiest way to get a kid to wear something? You make it cute. Fitbit’s next child-focused wearable is making the rounds in Rumorville. <a href="https://9to5google.com/2023/04/17/fitbit-kids-smartwatch/" rel="noopener noreferrer" target="_blank">9to5Google</a> has photos that claim to be of the next Fitbit smartwatch meant for your kid, and while it’s bulbous compared to the rest of the fitness wearable lineup, it seems…</p><p><a href="https://gizmodo.com/fitbit-kids-watch-smartwatch-wearable-tracking-fitness-1850344900">Read more...</a></p>

## HBO Max's Fired on Mars Looks Like Office Space in Outer Space
 - [https://gizmodo.com/hbo-max-fired-on-mars-animated-comedy-show-luke-wilson-1850344860](https://gizmodo.com/hbo-max-fired-on-mars-animated-comedy-show-luke-wilson-1850344860)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-17 19:20:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--U5VRwwV---/c_fit,fl_progressive,q_80,w_636/1a873d1068efd3451cf31b2810bb5eca.jpg" /><p>Imagine uprooting your entire life for a—well, not a <em>dream</em> job, but a decent enough job doing corporate graphic design... on <a href="https://gizmodo.com/nasa-second-review-board-mars-sample-return-esa-1850337292">Mars</a>. Then suddenly you’re let go, and you’re stuck on <a href="https://gizmodo.com/the-8-most-inaccurate-depictions-of-mars-ever-put-on-fi-1792025960">a strange planet</a> surrounded by even stranger people. That’s the premise for <a href="https://gizmodo.com/max-game-of-thrones-conjuring-penguin-rick-and-morty-1850328513">HBO Max</a>’s adult animated series <em>Fired on Mars</em>, which has just…</p><p><a href="https://gizmodo.com/hbo-max-fired-on-mars-animated-comedy-show-luke-wilson-1850344860">Read more...</a></p>

## World Leaders Agree to Boost Nuclear Power, While Germany Shuts Its Plants
 - [https://gizmodo.com/world-leaders-agree-to-boost-nuclear-power-while-germa-1850344865](https://gizmodo.com/world-leaders-agree-to-boost-nuclear-power-while-germa-1850344865)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-17 18:55:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--CI_gev3q--/c_fit,fl_progressive,q_80,w_636/3a36a5be2a97eb57ea26c4a5d022f63e.jpg" /><p>Some of the world’s largest most influential nations have formed an alliance to create new supply chains for nuclear energy—the same weekend that another country announced it had completely weaned itself off the energy source.</p><p><a href="https://gizmodo.com/world-leaders-agree-to-boost-nuclear-power-while-germa-1850344865">Read more...</a></p>

## George R.R. Martin Thinks He Can Write More Dunk and Egg Stories Before the New Game of Thrones Show
 - [https://gizmodo.com/game-of-thrones-knight-seven-kingdoms-dunk-egg-grrm-1850343908](https://gizmodo.com/game-of-thrones-knight-seven-kingdoms-dunk-egg-grrm-1850343908)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-17 18:40:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--i3b3m6KX--/c_fit,fl_progressive,q_80,w_636/1d148934e0489d354aeabba02b69a5c4.jpg" /><p>Now that HBO has announced a <a href="https://gizmodo.com/max-game-of-thrones-conjuring-penguin-rick-and-morty-1850328513">pair of new shows</a> set in the <a href="https://gizmodo.com/io9/television/game-of-thrones"><em>Game of Thrones</em></a> Westerosiverse (for the lack of a better term), it’s high time for <em>A Song of Ice and Fire</em>’s George R.R. Martin to weigh in on the next televisual representations of the world he created. While he doesn’t have much to say about the spinoff…</p><p><a href="https://gizmodo.com/game-of-thrones-knight-seven-kingdoms-dunk-egg-grrm-1850343908">Read more...</a></p>

## Nintendo 'Villain' Gary Bowser Will Soon Be on the Loose Once More
 - [https://gizmodo.com/nintendo-hacker-gary-bowser-soon-to-be-released-prison-1850344573](https://gizmodo.com/nintendo-hacker-gary-bowser-soon-to-be-released-prison-1850344573)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-17 18:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--HX8DLJTS--/c_fit,fl_progressive,q_80,w_636/730f36d46393e31b83615dd9f03a53a8.jpg" /><p>Gary Bowser, a public face of the aftermarket console modding scene, unwittingly became one of Nintendo’s most hated antagonists. Now after more than a year in the proverbial federal dungeons, Bowser finally has his shot at freedom. Though even as Bowser looks to return home to Canada (and not some massive castle in…</p><p><a href="https://gizmodo.com/nintendo-hacker-gary-bowser-soon-to-be-released-prison-1850344573">Read more...</a></p>

## Chinese Surveillance Giant Knew Its Cameras Spied on Uyghurs, War Crimes Investigator Says
 - [https://gizmodo.com/hikvision-uyghurs-china-cctv-cameras-spying-detained-1850344113](https://gizmodo.com/hikvision-uyghurs-china-cctv-cameras-spying-detained-1850344113)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-17 17:43:15+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--wJtc2WDQ--/c_fit,fl_progressive,q_80,w_636/ee07fa5e2feb3358643562db4e82d82c.jpg" /><p>Hikvision, a Chinese surveillance camera company <a href="https://techcrunch.com/2022/11/28/fcc-huawei-zte-hikvision-hytera-dahua-ban/#:~:text=Security-,US%20government%20bans%20Huawei%2C%20ZTE%20and,tech%20over%20'unacceptable'%20spying%20fears&amp;text=The%20U.S.%20government%20said%20it,protect%20the%20nation's%20communications%20network." rel="noopener noreferrer" target="_blank">restricted</a> in parts of the US and the UK, knew its tech was <a href="https://gizmodo.com/u-s-considers-export-ban-on-surveillance-company-that-1834942021">used to monitor</a> the country’s Uyghur Muslim minority <a href="https://www.businessinsider.com/hikvision-denies-role-uyghur-mps-call-uk-ban-2021-8" rel="noopener noreferrer" target="_blank">despite previously denials of exactly that</a>, according to a war crimes investigator hired by Hikvision itself. New leaked recordings give more credibility to…</p><p><a href="https://gizmodo.com/hikvision-uyghurs-china-cctv-cameras-spying-detained-1850344113">Read more...</a></p>

## The Boogeyman Trailer Reminds Us to Leave the Lights On
 - [https://gizmodo.com/boogeyman-trailer-horror-stephen-king-rob-savage-host-1850344217](https://gizmodo.com/boogeyman-trailer-horror-stephen-king-rob-savage-host-1850344217)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-17 17:40:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--CdT5fjZO--/c_fit,fl_progressive,q_80,w_636/f5176c4fcd77ce0467a10f636324ff2b.png" /><p>There’s something under the bed... and in the dark, it comes out to play. </p><p><a href="https://gizmodo.com/boogeyman-trailer-horror-stephen-king-rob-savage-host-1850344217">Read more...</a></p>

## NASA’s Enigmatic Green Lasers Spotted by Japanese Astronomer
 - [https://gizmodo.com/nasa-green-lasers-satellite-japan-icesat2-1850344322](https://gizmodo.com/nasa-green-lasers-satellite-japan-icesat2-1850344322)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-17 17:27:00+00:00

<video loop="" poster="https://i.kinja-img.com/gawker-media/image/upload/s--SZ98AOsF--/c_fit,fl_progressive,q_80,w_636/77258fe2738493dd22e6fa2a9f1449dd.jpg"><source src="https://i.kinja-img.com/gawker-media/image/upload/s--jZnLEIUU--/c_fit,fl_progressive,q_80,w_636/77258fe2738493dd22e6fa2a9f1449dd.mp4" type="video/mp4" /></video><p>Japanese museum curator and astronomer Daichi Fujii spotted something irregular last September in several motion-sensing cameras he had set up: three brilliant green lights that streaked across the sky.<br /></p><p><a href="https://gizmodo.com/nasa-green-lasers-satellite-japan-icesat2-1850344322">Read more...</a></p>

## The National Guard Plans to Geofence High Schools and Target Kids' Phones With Recruitment Ads
 - [https://gizmodo.com/national-guard-georgia-recruitment-ads-kids-phones-1850343364](https://gizmodo.com/national-guard-georgia-recruitment-ads-kids-phones-1850343364)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-17 16:44:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--CtJ_7j0l--/c_fit,fl_progressive,q_80,w_636/aad423e06674f480b9337d720562267c.png" /><p>Teens love their screens, and the Department of Defense is prepared to take advantage of that. The Georgia Army National Guard has big plans to boost its recruitment efforts through targeted ads on high schoolers’ cell phones, according to <a href="https://s3.documentcloud.org/documents/23775102/solicitation-amendment-w912jm23q0004-0001.pdf" rel="noopener noreferrer" target="_blank">a federal contract document</a> obtained and <a href="https://theintercept.com/2023/04/16/georgia-army-national-guard-location-tracking-high-school/" rel="noopener noreferrer" target="_blank">first reported on</a> by the Intercept.<br /></p><p><a href="https://gizmodo.com/national-guard-georgia-recruitment-ads-kids-phones-1850343364">Read more...</a></p>

## The Witch From Mercury Did the Gundam Thing
 - [https://gizmodo.com/witch-from-mercury-eri-aerial-gundam-prospera-explained-1850343984](https://gizmodo.com/witch-from-mercury-eri-aerial-gundam-prospera-explained-1850343984)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-17 16:40:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--T8noCKWY--/c_fit,fl_progressive,q_80,w_636/4f779275656cf1c59a4c2d9340eb06e7.png" /><p>Remember when the first season of the <a href="https://gizmodo.com/best-animation-2022-gundam-pinocchio-chainsaw-man-1849927257">excellent new <em>Gundam</em> show</a>, <em>The Witch From Mercury</em>, <a href="https://gizmodo.com/gundam-witch-from-mercury-slap-aerial-suletta-miorine-1849971348">ended and shocked everyone</a> with a reminder that it is, indeed, a <em>Mobile Suit Gundam</em> show? Well, good news: <a href="https://gizmodo.com/gundam-witch-from-mercury-season-2-trailer-crunchyroll-1850212543">its second season</a> is not slowing down on reminding you of that fact in the most gutwrenching manner possible.<br /></p><p><a href="https://gizmodo.com/witch-from-mercury-eri-aerial-gundam-prospera-explained-1850343984">Read more...</a></p>

## This Week in Spaceflight: An ISS Spacewalk and SpaceX's Second Starship Launch Attempt
 - [https://gizmodo.com/this-week-in-spaceflight-an-iss-spacewalk-and-spacexs-1850336945](https://gizmodo.com/this-week-in-spaceflight-an-iss-spacewalk-and-spacexs-1850336945)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-17 16:35:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--Rbgw8x2j--/c_fit,fl_progressive,q_80,w_636/2a853843daa5d97a1ceb36697a808749.jpg" /><p>Elon’s gigantic Starship rocket is expected to dominate the news this week, but there will be other spaceflight happenings vying for our attention.<br /></p><p><a href="https://gizmodo.com/this-week-in-spaceflight-an-iss-spacewalk-and-spacexs-1850336945">Read more...</a></p>

## The Biggest Killers of Americans: Heart Disease, Cancer—and Being Poor
 - [https://gizmodo.com/poverty-leading-cause-of-death-usa-1850343936](https://gizmodo.com/poverty-leading-cause-of-death-usa-1850343936)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-17 16:22:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--BMCcbJx1--/c_fit,fl_progressive,q_80,w_636/f1ed30dc87ff1f33c19b060ebcf3ee8d.jpg" /><p>Being poor is a major leading cause of death in America, new research  suggests. The study’s authors estimate that there were roughly 180,000 poverty-related deaths among people over the age of 15 in 2019—a total only surpassed by deaths from heart disease, cancer, and smoking that year.</p><p><a href="https://gizmodo.com/poverty-leading-cause-of-death-usa-1850343936">Read more...</a></p>

## Dominion v. Fox News Defamation Trial Delayed for Settlement Talks
 - [https://gizmodo.com/fox-news-dominion-trial-delayed-settlement-1850343717](https://gizmodo.com/fox-news-dominion-trial-delayed-settlement-1850343717)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-17 16:07:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--8ncWcLes--/c_fit,fl_progressive,q_80,w_636/3a6c88fab7428ebf2f9e0ae2f1ece1d2.jpg" /><p>Fox News’ defamation trial, set to begin Monday, has been delayed by a day after the conservative cable channel proposed an out-of-court settlement. The news station is being sued by Dominion Voting Systems, the maker of a small number of voting machines used in the 2020 presidential election, for its claims that the…</p><p><a href="https://gizmodo.com/fox-news-dominion-trial-delayed-settlement-1850343717">Read more...</a></p>

## Tetris Creators on The One Version of Tetris They Would Play the Rest of Their Life
 - [https://gizmodo.com/tetris-creators-on-the-one-version-of-tetris-they-would-1850303177](https://gizmodo.com/tetris-creators-on-the-one-version-of-tetris-they-would-1850303177)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-17 15:50:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--m7BEUcdv--/c_fit,fl_progressive,q_80,w_636/3f7cef3e28913eb21f4309689f6f9c1c.jpg" /><p><a href="https://gizmodo.com/tetris-creators-on-the-one-version-of-tetris-they-would-1850303177">Read more...</a></p>

## JUICE Spacecraft Sends Farewell Photos of Earth as it Heads for Jupiter
 - [https://gizmodo.com/juice-spacecraft-farewell-photos-earth-jupiter-esa-1850343578](https://gizmodo.com/juice-spacecraft-farewell-photos-earth-jupiter-esa-1850343578)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-17 15:45:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--fB2S4tmx--/c_fit,fl_progressive,q_80,w_636/d4804df14462979ca1c6b9168b2d5ada.jpg" /><p>Shortly after beginning its eight-year journey to Jupiter, the European Space Agency’s (ESA) JUICE mission posed with its home planet for some parting shots.</p><p><a href="https://gizmodo.com/juice-spacecraft-farewell-photos-earth-jupiter-esa-1850343578">Read more...</a></p>

## Microsoft Isn’t Done Shoving Ads Into Windows 11
 - [https://gizmodo.com/microsoft-windows-11-ads-start-menu-365-onedrive-badgin-1850343412](https://gizmodo.com/microsoft-windows-11-ads-start-menu-365-onedrive-badgin-1850343412)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-17 15:05:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--jFjI4C09--/c_fit,fl_progressive,q_80,w_636/5e0d2a1375aa3b68d32b1dedd9c716b5.jpg" /><p>Microsoft’s Windows 11 Start Menu is becoming more and more like a dancing inflatable tube man gesticulating wildly outside a used car lot. The last <a href="https://gizmodo.com/microsoft-windows-11-onedrive-notifications-start-menu-1850327990">Windows 11 update added advertisements for Microsoft’s OneDrive</a> cloud backups for some users when they click on the little Windows icon on the desktop. Now the Redmond,…</p><p><a href="https://gizmodo.com/microsoft-windows-11-ads-start-menu-365-onedrive-badgin-1850343412">Read more...</a></p>

## How Damon Lindelof and Tara Hernandez Found the Line With Mrs. Davis, Then Blew Past It
 - [https://gizmodo.com/mrs-davis-peacock-damon-lindelof-tara-hernandez-ai-nun-1850338287](https://gizmodo.com/mrs-davis-peacock-damon-lindelof-tara-hernandez-ai-nun-1850338287)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-17 15:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--kGC8tlSB--/c_fit,fl_progressive,q_80,w_636/cfb3fb1766b294d9e91667f44bbd7706.jpg" /><p><a href="https://gizmodo.com/betty-gilpin-will-play-a-nun-fighting-a-powerful-ai-in-1848680676">A renegade nun</a> is tasked by an all-powerful artificial intelligence to hunt down the Holy Grail, and that’s just the first episode. <a href="https://gizmodo.com/damon-lindelof-peacock-scifi-teaser-mrs-davis-betty-gil-1850173259">Peacock’s new show <em>Mrs. Davis</em></a>, which debuts April 20, is <a href="https://gizmodo.com/mrs-davis-trailer-betty-gilpin-peacock-damon-lindelof-1850224452">as wild and surprising</a> as any show you’ve seen in recent memory. So, when given a chance to talk to co-creators Damon Lindelof and…</p><p><a href="https://gizmodo.com/mrs-davis-peacock-damon-lindelof-tara-hernandez-ai-nun-1850338287">Read more...</a></p>

## SpaceX Forced to Postpone First Launch Attempt of Giant Starship Rocket
 - [https://gizmodo.com/spacex-starship-launch-scrub-frozen-valve-1850343562](https://gizmodo.com/spacex-starship-launch-scrub-frozen-valve-1850343562)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-17 14:53:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--a32LHHsC--/c_fit,fl_progressive,q_80,w_636/5111aeeace8455e4bb24f7fc2914e809.jpg" /><p>Everything was looking so good today, until it wasn’t. Ground controllers announced the scrub with roughly 11 minutes left in the countdown clock, with a pressurization issue associated with the SpaceX Super Heavy booster to blame. The company says it will likely re-attempt a launch of its Starship megarocket later…</p><p><a href="https://gizmodo.com/spacex-starship-launch-scrub-frozen-valve-1850343562">Read more...</a></p>

## How Can You Be a Steward of Good Tech in 2023? | Gizmodo Interview
 - [https://gizmodo.com/how-can-we-be-a-steward-of-good-tech-in-2023-1850343580](https://gizmodo.com/how-can-we-be-a-steward-of-good-tech-in-2023-1850343580)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-17 14:45:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--p5EQHAEt--/c_fit,fl_progressive,q_80,w_636/1d71a91540e1e66f05982ecaf91f9b27.jpg" /><p><a href="https://gizmodo.com/how-can-we-be-a-steward-of-good-tech-in-2023-1850343580">Read more...</a></p>

## AI Art Piece Wins Sony's Photography Contest, Artist Refuses the Award
 - [https://gizmodo.com/sony-world-photography-award-ai-art-winner-eldagsen-1850343317](https://gizmodo.com/sony-world-photography-award-ai-art-winner-eldagsen-1850343317)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-17 14:35:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--ObOLQj8D--/c_fit,fl_progressive,q_80,w_636/060958924c6b5cd48829981f9ca5025a.jpg" /><p>An entry into the World Photography Organization’s Sony World Photography Awards has brought new attention to the conversation around AI-generated art. After  artist Boris Eldagsen entered his AI-generated piece “The Electrician” into the art contest and won, he opted to turn down the prize.<br /></p><p><a href="https://gizmodo.com/sony-world-photography-award-ai-art-winner-eldagsen-1850343317">Read more...</a></p>

## A Massive Transmission Line Will Send Wind Power From Wyoming to California
 - [https://gizmodo.com/a-massive-transmission-line-will-send-wind-power-from-w-1850343588](https://gizmodo.com/a-massive-transmission-line-will-send-wind-power-from-w-1850343588)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-17 14:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s---OlePR2m--/c_fit,fl_progressive,q_80,w_636/60129ec10875fa9f2541184179a477aa.jpg" /><p><em>This story was originally published by <a href="https://grist.org/" rel="noopener noreferrer" target="_blank">Grist</a>. Sign up for Grist’s <a href="https://go.grist.org/signup/weekly/partner?utm_campaign=republish-content&amp;utm_medium=syndication&amp;utm_source=partner" rel="noopener noreferrer" target="_blank">weekly newsletter here</a>.<br /></em></p><p><a href="https://gizmodo.com/a-massive-transmission-line-will-send-wind-power-from-w-1850343588">Read more...</a></p>

## Mia Goth's Blade Character Might Have Been Revealed
 - [https://gizmodo.com/mia-goth-blade-mcu-lilith-drake-1850342294](https://gizmodo.com/mia-goth-blade-mcu-lilith-drake-1850342294)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-17 14:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--NnB6Q2Mu--/c_fit,fl_progressive,q_80,w_636/e4ba14369a4dfdb8ad40480302ca10aa.png" /><p>The next <em>Insidious</em> has its title. <em>It</em> prequel <em>Welcome to Derry</em> welcomes more people to its cast. Plus, the CW teases what’s coming on <em>Gotham Knights</em>, <em>Superman &amp; Lois</em>, and <em>The Flash</em>. To me, my spoilers!<br /></p><p><a href="https://gizmodo.com/mia-goth-blade-mcu-lilith-drake-1850342294">Read more...</a></p>

## This Company Will 3D-Print Your Hand's Ideal Mouse for $142
 - [https://gizmodo.com/3d-printed-mouse-custom-tailored-fit-kickstarter-gaming-1850343347](https://gizmodo.com/3d-printed-mouse-custom-tailored-fit-kickstarter-gaming-1850343347)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-17 14:25:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--db01bMZU--/c_fit,fl_progressive,q_80,w_636/e5d753097421539f1ff0c3fa58033aa1.jpg" /><p>Assuming it’s already got an ergonomic enough design, like most modern offerings, you probably don’t give much thought to your computer mouse. But to others, like professional gamers, the size, shape, and performance of a mouse can help or hinder their job, so a <a href="https://www.formify.ca/" rel="noopener noreferrer" target="_blank">Toronto-based company called Formify</a> has come up with a…</p><p><a href="https://gizmodo.com/3d-printed-mouse-custom-tailored-fit-kickstarter-gaming-1850343347">Read more...</a></p>

## This Week's Merch News Knows the Way (to Some Wonderful Toys)
 - [https://gizmodo.com/lego-space-star-wars-armorer-helmet-neca-batman-belt-1850327127](https://gizmodo.com/lego-space-star-wars-armorer-helmet-neca-batman-belt-1850327127)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-17 13:45:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--gCfKpvvW--/c_fit,fl_progressive,q_80,w_636/d136309e1f29f9b60aa5cbea7924140a.jpg" /><p>Welcome back to Toy Aisle, io9's regular round-up of the latest and greatest toy news on the internet. This week, Lego takes us to space with a gorgeous new Ideas set—and to the race track with a wild new Technic one. Also, get ready to cosplay the worlds of <em>The Mandalorian</em> and Tim Burton’s <em>Batman</em> with new replicas.…</p><p><a href="https://gizmodo.com/lego-space-star-wars-armorer-helmet-neca-batman-belt-1850327127">Read more...</a></p>

## Adobe’s ‘Firefly’ Image Generator Brings Powerful AI Features to Video, Including Automatic Storyboarding
 - [https://gizmodo.com/adobe-firefly-video-editing-storyboards-music-sfx-b-rol-1850342629](https://gizmodo.com/adobe-firefly-video-editing-storyboards-music-sfx-b-rol-1850342629)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-17 13:00:00+00:00

<video loop="" poster="https://i.kinja-img.com/gawker-media/image/upload/s--PRGLXSqc--/c_fit,fl_progressive,q_80,w_636/915f636caa4d610ab99b7b86c2d37bc9.jpg"><source src="https://i.kinja-img.com/gawker-media/image/upload/s--80P_M4O5--/c_fit,fl_progressive,q_80,w_636/915f636caa4d610ab99b7b86c2d37bc9.mp4" type="video/mp4" /></video><p>You no longer need a TV studio, millions of dollars of equipment, and a team of editors, animators, colorists, and artists to produce professional looking video content. You do, however, need a bit of talent, but maybe not for long, as Adobe is introducing new video tools that let you enhance, manipulate, and even…</p><p><a href="https://gizmodo.com/adobe-firefly-video-editing-storyboards-music-sfx-b-rol-1850342629">Read more...</a></p>

## Fandoms Collide in DC Studios' The Flash Toys and Merch
 - [https://gizmodo.com/dc-studios-the-flash-batman-supergirl-warner-bros-toys-1850339457](https://gizmodo.com/dc-studios-the-flash-batman-supergirl-warner-bros-toys-1850339457)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-17 13:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--W79PSaLm--/c_fit,fl_progressive,q_80,w_636/1c4001b64bf45b08daadba487c102bd0.jpg" /><p><em>Batman </em>‘89 fans rejoice! Merch for DC’s <a href="https://gizmodo.com/flash-movie-trailer-ezra-miller-batman-dc-films-gunn-1850090503"><em>The Flash</em></a> movie might be headlined by <a href="https://gizmodo.com/flash-death-tv-grant-gustin-series-finale-barry-allen-1850304989">Barry Allen</a>, but Michael Keaton’s Batman dominates so much of it. </p><p><a href="https://gizmodo.com/dc-studios-the-flash-batman-supergirl-warner-bros-toys-1850339457">Read more...</a></p>

## Netflix's Rivals Gleefully Made Fun of Its Disastrous Love Is Blind Reunion Livestream
 - [https://gizmodo.com/netflix-cancels-love-is-blind-season-4-reunion-delay-1850343050](https://gizmodo.com/netflix-cancels-love-is-blind-season-4-reunion-delay-1850343050)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-17 12:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--TSzOEKnB--/c_fit,fl_progressive,q_80,w_636/1ab337281f8c0b41989816e8043696b8.png" /><p>Netflix’s competitors, including Bravo and Hulu, gleefully made fun of the platform’s livestream woes on Sunday, when it struggled to air its much-hyped <em>Love Is Blind </em>season four reunion. In the end, Netflix ended up canceling the livestream, its second-ever live event, and told fans they would be able to stream it on…</p><p><a href="https://gizmodo.com/netflix-cancels-love-is-blind-season-4-reunion-delay-1850343050">Read more...</a></p>

## Gizmodo Monday Puzzle: Help the Gecko Find a Shortcut
 - [https://gizmodo.com/gizmodo-monday-puzzle-gecko-shortcut-geometry-1850249206](https://gizmodo.com/gizmodo-monday-puzzle-gecko-shortcut-geometry-1850249206)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-17 11:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--Ocaf9dCZ--/c_fit,fl_progressive,q_80,w_636/eaff642a5d0876b1cf2f17784dbf97c1.jpg" /><p>We were all taught that the shortest distance between two points is a straight line, but does this maxim hold up under deeper reflection? It actually depends on what geometry you use! Consider the shortest route for flying from L.A. to Dubai. Looking at a rectangular map, you might think that flying east across the…</p><p><a href="https://gizmodo.com/gizmodo-monday-puzzle-gecko-shortcut-geometry-1850249206">Read more...</a></p>

## Watch Live as SpaceX Attempts First Launch of Starship Megarocket
 - [https://gizmodo.com/watch-live-as-spacex-attempts-first-launch-of-starship-1850337290](https://gizmodo.com/watch-live-as-spacex-attempts-first-launch-of-starship-1850337290)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-04-17 03:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--F0hJ9fCi--/c_fit,fl_progressive,q_80,w_636/32334a9e866f8932cf3c55ef65620698.jpg" /><p>The stage is finally set for SpaceX to launch its much-anticipated Starship. The two-stage rocket may or may not reach orbit during its maiden voyage, but SpaceX says “excitement guaranteed.”<br /></p><p><a href="https://gizmodo.com/watch-live-as-spacex-attempts-first-launch-of-starship-1850337290">Read more...</a></p>

