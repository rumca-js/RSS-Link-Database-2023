# Source:Money PL, URL:https://www.money.pl/rss/, language:pl-PL

## Prezydent Macron studzi nastroje. Padła deklaracja ws. reformy emerytalnej
 - [https://www.money.pl/emerytury/prezydent-macron-studzi-nastroje-padla-deklaracja-ws-reformy-emerytalnej-6888483042900896a.html](https://www.money.pl/emerytury/prezydent-macron-studzi-nastroje-padla-deklaracja-ws-reformy-emerytalnej-6888483042900896a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-04-17 19:09:12+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/aa1e6341-c94a-452d-9fed-69a27a8f87f3" width="308" /> Francja od tygodni mierzy się z ogromną falą protestów, które wywołały plany podniesienia wieku emerytalnego. Prezydent Emmanuel Macron kilka dni temu zatwierdził reformę, a w poniedziałek wygłosił na temat orędzie do narodu. Zapewnił, że zmiany nie zostaną nagle wprowadzone.

## Turcji marzy się wielki handel gazem. Wśród wymienionych dostawców Rosja oraz Iran
 - [https://www.money.pl/gielda/turcji-marzy-sie-wielki-handel-gazem-wsrod-wymienionych-dostawcow-rosja-oraz-iran-6888429131512768a.html](https://www.money.pl/gielda/turcji-marzy-sie-wielki-handel-gazem-wsrod-wymienionych-dostawcow-rosja-oraz-iran-6888429131512768a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-04-17 15:29:49+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/fd1dc269-6e23-4a07-b800-19412f6c21b7" width="308" /> Turcja ma ambitne plany, by dostarczać Europie 40 mld metrów sześciennych gazu. Ankara nie ukrywa, że liczy głównie na dostawy tego surowca m.in. z Rosji i Iranu. Ukrainę szczególnie niepokoić może pierwsze źródło. Podobnie jak Zachód, który stara się ograniczyć przychody Kremla.

## "Totalna panika" na granicy. "To jest absurd, niszczenie działalności gospodarczej"
 - [https://www.money.pl/gospodarka/totalna-panika-na-granicy-to-jest-absurd-niszczenie-dzialalnosci-gospodarczej-6888307691068320a.html](https://www.money.pl/gospodarka/totalna-panika-na-granicy-to-jest-absurd-niszczenie-dzialalnosci-gospodarczej-6888307691068320a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-04-17 15:02:12+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/0b4ccde1-ebf9-4e1c-9360-a15b3b177963" width="308" /> Zakaz importu zboża i żywności z Ukrainy ma pomóc rządowi ugasić pożar na wsi. Problem w tym, że ta decyzja może dolać tylko oliwy do ognia i wcale nie rozwiązać kryzysu, a wywołać kolejne kłopoty. - Na granicy jest totalna panika i niezrozumienie sytuacji - słyszymy.

## Są najnowsze dane o inflacji bazowej w Polsce. Znowu rekord
 - [https://www.money.pl/gospodarka/inflacja-bazowa-w-polsce-marzec-2023-r-6888328297102240a.html](https://www.money.pl/gospodarka/inflacja-bazowa-w-polsce-marzec-2023-r-6888328297102240a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-04-17 12:01:14+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/bb029988-29d4-4775-9054-6f829fbc032a" width="308" /> Inflacja bazowa (z wyłączeniem cen energii i żywności) wyniosła w marcu 12,3 proc. wobec 12 proc. miesiąc wcześniej – podał NBP. To nowy rekord inflacji bazowej w Polsce.

## Długość życia Polaków. Resort rodziny pokazuje skutki pandemii
 - [https://www.money.pl/emerytury/dlugosc-zycia-polakow-resort-rodziny-pokazuje-skutki-pandemii-6888356517718944a.html](https://www.money.pl/emerytury/dlugosc-zycia-polakow-resort-rodziny-pokazuje-skutki-pandemii-6888356517718944a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-04-17 11:11:27+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/95678a81-96f9-4844-8ead-299475b9602a" width="308" /> Pandemia COVID-19 znacząco przyczyniła się do pogorszenia stanu zdrowia ludności i obniżyła prognozowaną długość życia Polaków. Wpłynęła również na sytuację materialną osób starszych.

## Nikt nie rośnie w Polsce tak jak Dino. Pół miliarda więcej na pracowników w rok
 - [https://www.money.pl/gospodarka/nikt-nie-rosnie-w-polsce-tak-jak-dino-pol-miliarda-wiecej-na-pracownikow-w-rok-6888334198418336a.html](https://www.money.pl/gospodarka/nikt-nie-rosnie-w-polsce-tak-jak-dino-pol-miliarda-wiecej-na-pracownikow-w-rok-6888334198418336a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-04-17 10:36:05+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/60fd6e27-d3a2-4b4e-8fac-fbdebe3d97d8" width="308" /> Na mapie pojawiają się nowe sklepy Dino. Co za tym idzie, rosną też koszty. Same świadczenia pracownicze kosztowały polską sieć handlową pół miliarda złotych więcej w 2022 r. niż w 2021. W ciągu 12 miesięcy w Dino znalazło zatrudnienie dodatkowe 5 tys. osób.

## Zakaz importu zboża z Ukrainy. Jest decyzja Słowacji
 - [https://www.money.pl/gospodarka/zakaz-importu-zboza-z-ukrainy-jest-decyzja-slowacji-6888352588024736a.html](https://www.money.pl/gospodarka/zakaz-importu-zboza-z-ukrainy-jest-decyzja-slowacji-6888352588024736a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-04-17 10:25:52+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/d7ca8d5b-9e07-4690-9e99-1545f6a32d2e" width="308" /> Rząd Słowacji wprowadził zakaz importu zboża z Ukrainy. Politycy podkreślają, że strona słowacka wyczerpała wszystkie prawne możliwości kontroli napływu zboża z kierunku wschodniego. Wcześniej w związku ze stężeniem pestycydów Słowacy wprowadzili zakaz wprowadzania do obrotu zboża z tego kierunku.

## Kurs Ten Square Games się załamał. Wielka wyprzedaż
 - [https://www.money.pl/gielda/gpw-kurs-ten-square-games-sie-zalamal-wielka-wyprzedaz-6879473723767616a.html](https://www.money.pl/gielda/gpw-kurs-ten-square-games-sie-zalamal-wielka-wyprzedaz-6879473723767616a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-04-17 10:15:12+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/0b562cde-30d8-4c34-9b93-4e4ed932e473" width="308" /> Ten Square Games wstrzymuje prace nad grami "Undead Clash" i "Fishing Masters" – podała spółka w komunikacie. TSG planuje też przeprowadzić zwolnienia grupowe 25 proc. osób. Po tej informacji kurs akcji załamał się i wyznacza nowe minima. Spadki są rzędu 10 proc.

## Władysław Kosiniak-Kamysz: miód z Ukrainy zalewa Polskę. Pszczelarze alarmują
 - [https://www.money.pl/gospodarka/zboze-z-ukrainy-to-dopiero-poczatek-pszczelarze-alarmuja-6888340710685632a.html](https://www.money.pl/gospodarka/zboze-z-ukrainy-to-dopiero-poczatek-pszczelarze-alarmuja-6888340710685632a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-04-17 09:36:31+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/745e1a17-b5a8-411a-a6d3-b0ef4191f23f" width="308" /> W poniedziałek działanie rozpoczął Parlamentarny Zespół ds. Zbadania Afery Zbożowo-Drobiowej. I już na wstępie Władysław Kosiniak-Kamysz podkreślił, że problem z ukraińskim zbożem to dopiero wierzchołek góry lodowej. Za chwilę nawarstwiać się będą problemy m.in. sadowników czy pszczelarzy.

## Bruksela ostrzega Polskę. Jest odpowiedź. "Sytuacja nadzwyczajna uzasadnia nadzwyczajne środki"
 - [https://www.money.pl/gospodarka/bruksela-ostrzega-polske-jest-odpowiedz-sytuacja-nadzwyczajna-uzasadnia-nadzwyczajne-srodki-6888339893734304a.html](https://www.money.pl/gospodarka/bruksela-ostrzega-polske-jest-odpowiedz-sytuacja-nadzwyczajna-uzasadnia-nadzwyczajne-srodki-6888339893734304a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-04-17 09:27:12+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/7f38e089-cd93-410e-8820-db48201683e1" width="308" /> Minister ds. UE Szymon Szynkowski vel Sęk zapewnił, że Polska pozostaje w kontakcie z Komisją Europejską. Chodzi o oddolną decyzję Warszawy o zakazie wjazdu produktów żywnościowych z Ukrainy. Jednak nasze stanowisko jest jasne. – Sytuacja nadzwyczajna uzasadnia nadzwyczajne środki – stwierdził minister.

## ZUS rozda 100 mln zł. Wnioski można składać do 18 maja
 - [https://www.money.pl/pieniadze/zus-rozda-100-mln-zl-wnioski-mozna-skladac-do-18-maja-6888327473253312a.html](https://www.money.pl/pieniadze/zus-rozda-100-mln-zl-wnioski-mozna-skladac-do-18-maja-6888327473253312a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-04-17 09:00:18+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/1d6f14d9-158a-4252-ad24-6dd1619239bd" width="308" /> Do Zakładu Ubezpieczeń Społecznych wpłynęły pierwsze wnioski w konkursie na projekty w zakresie poprawy bezpieczeństwa i higieny pracy. - Na ten cel ZUS przeznaczył 100 mln zł - poinformowała prezes ZUS prof. Gertruda Uścińska.

## Awaria w PKO BP. Klienci nie mogli zalogować się do serwisu internetowego
 - [https://www.money.pl/banki/awaria-w-pko-bp-klienci-nie-moga-zalogowac-sie-do-serwisu-internetowego-6888321266531264a.html](https://www.money.pl/banki/awaria-w-pko-bp-klienci-nie-moga-zalogowac-sie-do-serwisu-internetowego-6888321266531264a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-04-17 08:10:50+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/054f758a-61ba-43d7-a4ab-56fe76afdff9" width="308" /> Klienci PKO Banku Polskiego od rana zgłaszają problemy z zalogowaniem się do konta internetowego. Trudności pojawiają się też w działaniu aplikacji mobilnej. Aktualizacja: bank zapewnił money.pl, że jego systemy działają już bez zakłóceń.

## Cloud computing – klucz do nowoczesnego biznesu. Czym jest i jakie ma zastosowanie?
 - [https://www.money.pl/gospodarka/cloud-computing-klucz-do-nowoczesnego-biznesu-czym-jest-i-jakie-ma-zastosowanie-6888313823452096a.html](https://www.money.pl/gospodarka/cloud-computing-klucz-do-nowoczesnego-biznesu-czym-jest-i-jakie-ma-zastosowanie-6888313823452096a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-04-17 07:40:39+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/3862d19c-59df-49ac-9984-cc230c2dd814" width="308" /> Jeszcze do niedawna dla uzyskania odpowiedniego oprogramowania i aplikacji kupowaliśmy płyty CD. Dziś nie ma już takiej konieczności. Można bezpośrednio z internetu pobierać pożądane programy. Idąc o krok dalej, można korzystać z oprogramowania i innych narzędzi dostarczanych użytkownikom prywatnym czy biznesowym za pośrednictwem cloud computingu. Co to znaczy? Jakie jest jego zastosowanie prócz dostarczania użytkownikom usług IT?

## Niespodzianka dla przedsiębiorców. Rząd przed wyborami chce ułatwić im życie
 - [https://www.money.pl/gospodarka/niespodzianka-dla-przedsiebiorcow-rzad-przed-wyborami-chce-ulatwic-im-zycie-6888307550808992a.html](https://www.money.pl/gospodarka/niespodzianka-dla-przedsiebiorcow-rzad-przed-wyborami-chce-ulatwic-im-zycie-6888307550808992a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-04-17 07:15:06+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/0a3b5994-1abd-4339-9b48-f27b94cb47bd" width="308" /> Tuż przed wyborami parlamentarnymi rząd przygotował szereg zmian ułatwiających działalność przedsiębiorcom. Przewidują one m.in. że koncesja na sprzedaż alkoholu przejdzie na nowego właściciela sklepu monopolowego po poprzednim. Projekt zmian autorstwa resortu rozwoju trafił do publicznych konsultacji.

## CPK chce inwestować też w szybkie pociągi. Były prezes spółki mówi o "nierealnych terminach"
 - [https://www.money.pl/gospodarka/cpk-chce-inwestowac-tez-w-szybkie-pociagi-byly-prezes-spolki-mowi-o-nierealnych-terminach-6888297071696832a.html](https://www.money.pl/gospodarka/cpk-chce-inwestowac-tez-w-szybkie-pociagi-byly-prezes-spolki-mowi-o-nierealnych-terminach-6888297071696832a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-04-17 06:32:26+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/21e5a281-ad6a-4ebe-8531-d86d8a9fcdea" width="308" /> Centralny Port Komunikacyjny ma już w lipcu doczekać się decyzji, która otworzy drogę do budowy terminalu. Walczy nie tylko o dotacje na tory, ale chce również rozbudować tabor o szybkie pociągi. Były prezes spółki jednak przyznaje, że termin oddania lotniska do użytkowania jest nierealny.

## Nie płacą czynszu i rachunków. KRD: długi rosną
 - [https://www.money.pl/pieniadze/nie-placa-czynszu-i-rachunkow-krd-dlugi-rosna-6888275785681856a.html](https://www.money.pl/pieniadze/nie-placa-czynszu-i-rachunkow-krd-dlugi-rosna-6888275785681856a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-04-17 05:36:12+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/a55bfb07-e082-44db-b283-1ac73dbf593b" width="308" /> Zaległości finansowe Polaków z tytułu czynszu i wszelkich opłat związanych z użytkowaniem lokalu mieszkalnego sięgają 290,8 mln zł. Większość dłużników czynszowych nie płaci też za telefon, telewizję czy energię elektryczną.

## "Rosja powinna zapłacić Ukrainie za szkody". Sekretarz skarbu USA zabrała głos
 - [https://www.money.pl/gospodarka/rosja-powinna-zaplacic-ukrainie-za-szkody-sekretarz-skarbu-usa-zabrala-glos-6888282927459264a.html](https://www.money.pl/gospodarka/rosja-powinna-zaplacic-ukrainie-za-szkody-sekretarz-skarbu-usa-zabrala-glos-6888282927459264a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-04-17 05:34:54+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/8fc4f7de-f5ab-47d3-a628-2134892e0514" width="308" /> Rosja powinna zapłacić za szkody, które wyrządziła w Ukrainie – wprost stwierdziła Janet Yellen w wywiadzie telewizyjnym. Sekretarz skarbu USA zarazem sceptycznie się odniosła do pomysłu, by straty ukraińskie sfinansować z zamrożonych aktywów rosyjskich, gdyż, jak przyznała, "są blokady prawne".

## Kursy walut 17.04.2023. Poniedziałkowy kurs funta, euro, dolara i franka szwajcarskiego
 - [https://www.money.pl/pieniadze/kursy-walut-17-04-2023-poniedzialkowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6888276934679488a.html](https://www.money.pl/pieniadze/kursy-walut-17-04-2023-poniedzialkowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6888276934679488a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-04-17 05:10:33+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/f25df134-ca5f-469f-b693-7773e001842b" width="308" /> Kursy walut - 17.04.2023. W poniedziałek za jednego dolara (USD) zapłacimy 4,2267 zł. Cena jednego funta szterlinga (GBP) to 5,2458 zł, a franka szwajcarskiego (CHF) 4,7264 zł. Z kolei euro (EUR) możemy zakupić za 4,6439 zł.

## Włochy zrywają zależność gazową od Rosji. Energię wezmą z OZE i atomu
 - [https://www.money.pl/gielda/wlochy-zrywaja-zaleznosc-gazowa-od-rosji-energie-wezma-z-oze-i-atomu-6888275565505440a.html](https://www.money.pl/gielda/wlochy-zrywaja-zaleznosc-gazowa-od-rosji-energie-wezma-z-oze-i-atomu-6888275565505440a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-04-17 05:04:58+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/ffaf6c2b-76a1-4e1c-a3bc-73476be3b208" width="308" /> Włochy były po Niemczech drugim w Unii odbiorcą rosyjskiego gazu. Błękitne paliwo ze wschodu pokrywało 40 proc. zapotrzebowania kraju, dziś wolumen skurczył się do 10 proc.

## Ile kosztuje dolar? Kurs dolara do złotego PLN/USD 17.04.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-17-04-2023-6888275153435552a.html](https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-17-04-2023-6888275153435552a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-04-17 05:03:23+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e0ba71a8-9c02-482d-85dd-ebac5362ee3b" width="308" /> Kurs dolara - 17.04.2023. W poniedziałek za jednego dolara (USD) trzeba zapłacić 4.2256 zł.

## Ile kosztuje funt? Kurs funta do złotego PLN/GBP 17.04.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-17-04-2023-6888275153443776a.html](https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-17-04-2023-6888275153443776a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-04-17 05:03:23+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c374eefc-9e8b-424a-aaa7-91759b47d116" width="308" /> Kurs funta szterlinga - 17.04.2023. W poniedziałek za jednego funta brytyjskiego (GBP) trzeba zapłacić 5.2437 zł.

## Ile kosztuje frank szwajcarski? Kurs franka do złotego PLN/CHF 17.04.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-17-04-2023-6888275150523296a.html](https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-17-04-2023-6888275150523296a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-04-17 05:03:22+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b1c04e3f-7bce-4c35-b03c-7a8d7b0adc65" width="308" /> Kurs franka szwajcarskiego - 17.04.2023. W poniedziałek za jednego franka (CHF) trzeba zapłacić 4.7253 zł.

## Ile kosztuje euro? Kurs euro do złotego PLN/EUR 17.04.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-17-04-2023-6888275146705856a.html](https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-17-04-2023-6888275146705856a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-04-17 05:03:21+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cf3a8300-d9c9-461f-9fbc-2f314332a28c" width="308" /> Kurs euro - 17.04.2023. W poniedziałek za jedno euro (EUR) trzeba zapłacić 4.6423 zł.

## Bułgaria pójdzie śladem Polski i Węgier? Rozważa zamknięcie granic przed zbożem z Ukrainy
 - [https://www.money.pl/gospodarka/bulgaria-pojdzie-sladem-polski-i-wegier-rozwaza-zamkniecie-granic-przed-zbozem-z-ukrainy-6888274432957376a.html](https://www.money.pl/gospodarka/bulgaria-pojdzie-sladem-polski-i-wegier-rozwaza-zamkniecie-granic-przed-zbozem-z-ukrainy-6888274432957376a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-04-17 05:00:19+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/db35fb36-945f-4a91-a329-6ef20581b77b" width="308" /> Polska i Węgry zdecydowały się nie czekać na ruch Brukseli i zamknęły granice przed importem z Ukrainy. Na podobny krok w przypadku zboża może się zdecydować Bułgaria. – Konieczna jest ochrona bułgarskich interesów – oświadczył minister rolnictwa Bułgarii Jawor Geczew.

