# Source:Wydarzenia Interia - Świat, URL:https://wydarzenia.interia.pl/swiat/feed, language:pl-PL

## Słowacja wprowadza zakaz importu ukraińskiego zboża
 - [https://wydarzenia.interia.pl/zagranica/news-slowacja-wprowadza-zakaz-importu-ukrainskiego-zboza,nId,6722544](https://wydarzenia.interia.pl/zagranica/news-slowacja-wprowadza-zakaz-importu-ukrainskiego-zboza,nId,6722544)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-04-17 10:00:10+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-slowacja-wprowadza-zakaz-importu-ukrainskiego-zboza,nId,6722544"><img align="left" alt="Słowacja wprowadza zakaz importu ukraińskiego zboża" src="https://i.iplsc.com/slowacja-wprowadza-zakaz-importu-ukrainskiego-zboza/000G336ZOXNE4CEX-C321.jpg" /></a>Rząd Słowacji wprowadził czasowy zakaz importu ukraińskiego zboża. Ministerstwo rolnictwa oświadczyło, że wyczerpało już wszystkie prawne możliwości kontroli napływu zboża z Ukrainy przy jednoczesnym zachowaniu tzw. korytarzy solidarności.</p><br clear="all" />

