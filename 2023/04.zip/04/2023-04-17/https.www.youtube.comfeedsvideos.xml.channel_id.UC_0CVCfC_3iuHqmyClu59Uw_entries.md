# Source:ETA PRIME, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_0CVCfC_3iuHqmyClu59Uw, language:en-US

## Yes, You Can Overclock The Steam Deck! And We Push It To The Limit
 - [https://www.youtube.com/watch?v=5abD4KWLnks](https://www.youtube.com/watch?v=5abD4KWLnks)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_0CVCfC_3iuHqmyClu59Uw
 - date published: 2023-04-17 14:06:00+00:00

It is Not recommend to overclock the Steam deck, I’m doing this at my own risk and understand that I’m running this risk of breaking something or bricking my Steam deck.
We overclocked the Steam deck! But should you? So yeah, This is pretty awesome using a bios utility called Smokeless UMAF we can access the steam decks hidden bios settings, This allows you to change the TDP, Under volt the CPU and iGPU and even Overclock the Steam Deck CPU and GPU! In this video I have Overclocked the Steam deck to 4.0Ghz and 2000Mhz on the iGPU. So does it help out with perforce in PC gaming and Emulation? Lets find out

Get Smokeless UMAF by DavidS95 Here: https://github.com/DavidS95/Smokeless_UMAF
CryoByte33 Youtube: https://www.youtube.com/@cryobyte33

We Overclocked The Steam Deck To The Limit! Is This The Most Powerful Steam Deck Yet?

Follow Me On Twitter: https://twitter.com/theetaprime
Follow Me On Instagram: https://www.instagram.com/etaprime/

25% Code for software: ETA
Windows 10 Pro OEM Key($15): https://biitt.ly/KpEmf
Windows10 Home Key($14): https://biitt.ly/2tPi1
Windows 11 Pro Key($22): https://biitt.ly/RUZiX
Office 2019 pro key($49): https://biitt.ly/o0OQT

Equipment I Use:
Monitor: Pixio 277 Pro On Amazon: https://amzn.to/3PGUBwe
Elgato HD60 X Screen Capture Device: https://amzn.to/3GkP2AL
Tool Kit: https://amzn.to/3Wo8bpX
Camera: https://amzn.to/3XJfFoI

DISCLAIMER: This video and description contains affiliate links, which means that if you click on one of the product links, I’ll receive a small commission at no extra cost to you!
Under section 107 of the Copyright Act 1976, allowance is made for “fair use” for purposes such as criticism, comment, news reporting, teaching, scholarship, education, and research.
No Games Are Included Or Added

This video and Channel and Video are for viewers 14 years older and up. This video is not made for viewers under the age of 14. 

Want to send me something?
ETAPRIME 
12520 Capital Blvd Ste 401 Number 108
Wake Forest, NC 27587 US

THIS VIDEO IS FOR EDUCATIONAL PURPOSES ONLY!

#steamdeck #etaprime
00:00 Introduction
00:16 Overview
01:03 Hidden Bios Settings steam deck
04:45 steam deck Power tools TDP Overclocking
05:42 Overclocked steam deck benchmarks and testing
09:16 Should you Overclock the steam deck

