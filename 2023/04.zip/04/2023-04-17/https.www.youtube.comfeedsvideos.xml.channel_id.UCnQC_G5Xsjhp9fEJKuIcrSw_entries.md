# Source:Ben Shapiro, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw, language:en-US

## You MUST Hear Bud Light’s Half-Brewed Apology
 - [https://www.youtube.com/watch?v=RceQ-q9rOq4](https://www.youtube.com/watch?v=RceQ-q9rOq4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-04-17 22:13:12+00:00

Bud Light has taken a severe financial hit after their failed marketing campaign. Anheuser-Busch's CEO has now put out a ridiculously weak statement "addressing" the damage they have caused.

Get up to 20% OFF + 2 FREE pillows with all mattress orders: https://helixsleep.com/BEN

Get 90% off RexMD and only pay $2 per dosage with our exclusive link https://rexmd.com/ben #rexmdpod 

Watch the member-only portion of my show on DailyWire+: bit.ly/3SUaXn3

LIKE & SUBSCRIBE for new videos every day. https://www.youtube.com/@BenShapiro?sub_confirmation=1

Watch the full episode here: https://youtu.be/oislTAb8Cng

Stop giving your money to woke corporations that hate you. Get your Jeremy's Razors today at https://bit.ly/3IfCVEI

Grab your Ben Shapiro merch here: https://bit.ly/3IgkGig

#BenShapiro #TheBenShapiroShow #News #Politics #DailyWire #budlight #anheuserbusch #dylanmulvaney #lgbtq #cancelculture

## MrBeast's Sidekick Chris Tyson Goes Trans
 - [https://www.youtube.com/watch?v=GsCUKMPGOzc](https://www.youtube.com/watch?v=GsCUKMPGOzc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-04-17 22:00:14+00:00

Get 3 Months FREE of ExpressVPN: https://www.expressvpn.com/shapiroshorts

Watch the member-only portion of my show on DailyWire+: bit.ly/3SUaXn3

LIKE & SUBSCRIBE for new videos every day. https://www.youtube.com/@BenShapiro?sub_confirmation=1

Stop giving your money to woke corporations that hate you. Get your Jeremy's Razors today at https://bit.ly/3IfCVEI

Grab your Ben Shapiro merch here: https://bit.ly/3IgkGig

#shorts #BenShapiro #TheBenShapiroShow #News #Politics #DailyWire #shortsfeed #shortsnews #reaction #mrbeast #christyson #trans #gender #lgbtq

## World Famous YouTuber MrBeast Hit With Trans Controversy
 - [https://www.youtube.com/watch?v=oislTAb8Cng](https://www.youtube.com/watch?v=oislTAb8Cng)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-04-17 15:55:45+00:00

The biggest YouTuber in the world, Mr. Beast, finds himself trapped as one of his co-stars begins gender transitioning; Bud Light tries to walk back its Dylan Mulvaney snafu; and Chicago is overrun with violence as the city’s incoming mayor urges people not to “demonize youth starved of opportunities."

- - - 

Click here to join the member exclusive portion of my show: https://utm.io/ueSEj

- - - 

DailyWire+:

Become a DailyWire+ member to watch brand new episodes of the series “Exodus” by Dr. Jordan B. Peterson: https://bit.ly/3lfVtwK 
Shop all Jeremy’s Razors products here: https://bit.ly/3xuFD43 

Get your Ben Shapiro merch here: https://bit.ly/3TAu2cw

 - - - 

Today’s Sponsors:

Good Ranchers - Use code "BEN" at checkout and get $20 off your order: https://www.goodranchers.com/Ben?utm_source=DailyWire&amp;utm_medium=referral&amp;utm_campaign=BenShapiro

IFCJ - Head to BenforTheFellowship.org or call 800-331-3737 to rush a Passover Food Box.

Helix - Get up to 20% OFF + 2 FREE pillows with all mattress orders: https://helixsleep.com/BEN

Stamps - Get a 4-week trial, free postage, and a digital scale at https://www.stamps.com/shapiro. Thanks to Stamps.com for sponsoring the show!

RexMD - Get 90% off RexMD and only pay $2 per dosage with our exclusive link - https://rexmd.com/ben #rexmdpod

- - -

Socials:

Follow on Twitter: https://bit.ly/3cXUn53 

Follow on Instagram: https://bit.ly/3QtuibJ 

Follow on Facebook: https://bit.ly/3TTirqd 

Subscribe on YouTube: https://bit.ly/3RPyBiB

#BenShapiro #TheBenShapiroShow #News #Politics #DailyWire

