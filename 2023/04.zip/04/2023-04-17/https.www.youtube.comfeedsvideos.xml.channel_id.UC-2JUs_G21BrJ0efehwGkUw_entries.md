# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## Redbone | @childishgambino | funk cover ft. @StaceyRyanMusic & @belafleckbanjo
 - [https://www.youtube.com/watch?v=8029laYr5P4](https://www.youtube.com/watch?v=8029laYr5P4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2023-04-17 13:00:04+00:00

Get tickets to see us on tour! https://www.scarypocketsfunk.com
Store: https://www.scarypocketsfunk.com
Patreon: http://modal.scarypocketsfunk.com/patreon
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A funk cover of Childish Gambino's "Redbone" by Scary Pockets & Stacey Ryan.

MUSICIAN CREDITS
Vocals: Stacey Ryan
Banjo: Béla Fleck
Drums: Rob Humphreys
Bass: Tim Lefebvre
Keys: Jack Conte
Guitar: Ryan Lerman

AUDIO CREDITS
Recording Engineer: Caleb Parker
Asst. Engineer: Nicole Schmidt
Mixing/Mastering: Caleb Parker

VIDEO CREDITS
DP: Ricky Chavez
ACs: Alejandro Echevarria, Chad Carlstone, Mason Mejia
Editor: Adam Kritzberg

Recorded Live at The Village Studios in Los Angeles, CA.

#ScaryPockets #Funk #childishgambino #staceyryan #belafleck #donaldglover #redbone

