# Source:Nerdstalgic, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXjmz8dFzRJZrZY8eFiXNUQ, language:en-US

## Why Do All Superheroes Need Secret Identities?
 - [https://www.youtube.com/watch?v=rGrnqlo49O4](https://www.youtube.com/watch?v=rGrnqlo49O4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXjmz8dFzRJZrZY8eFiXNUQ
 - date published: 2023-04-17 17:00:34+00:00

Secret Identities used to be a staple for all superheroes.  Clark Kent to Superman, Bruce Wayne to Batman, Peter Parker to Spider-Man, but in todays' modern superhero landscape all that has fallen to the side.  The MCU and DCU have put our favorite superheroes into the public eye, and have put more focus on their superhero identity rather than their public persona.  Everyone knows who's Iron Man, it's no secret who Black Widow is, but how has that changed how we consume these adaptations? 

#superhero #marvel #nerdstalgic 

Written by Dave Baker
Edited by Paul Ritchey

