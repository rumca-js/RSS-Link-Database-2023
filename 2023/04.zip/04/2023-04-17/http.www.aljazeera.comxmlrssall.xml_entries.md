# Source:Aljazeera, URL:http://www.aljazeera.com/xml/rss/all.xml, language:en-US

## Japan, S Korea, US conduct drill amid tension with N Korea
 - [https://www.aljazeera.com/news/2023/4/17/north-korea-condemns-us-military-drill-with-japan-and-south-korea](https://www.aljazeera.com/news/2023/4/17/north-korea-condemns-us-military-drill-with-japan-and-south-korea)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 23:18:44+00:00

Drills between the three countries follow North Korea&#039;s test of a solid-fuel intercontinental missile.

## Canadian broadcaster latest to ‘pause’ Twitter over funding label
 - [https://www.aljazeera.com/news/2023/4/17/canadian-broadcaster-latest-to-chafe-at-twitter-funding-label](https://www.aljazeera.com/news/2023/4/17/canadian-broadcaster-latest-to-chafe-at-twitter-funding-label)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 22:45:55+00:00

Public broadcaster CBC said it was effectively quitting the platform over its &#039;government-funded&#039; media label.

## US officers won’t be charged in ‘grievous’ Jayland Walker killing
 - [https://www.aljazeera.com/news/2023/4/17/us-officers-wont-be-charged-in-grievous-jayland-walker-killing](https://www.aljazeera.com/news/2023/4/17/us-officers-wont-be-charged-in-grievous-jayland-walker-killing)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 22:06:31+00:00

Walker fired at police first, attorney general says, as grand jury votes not to charge officers who shot him 46 times.

## Lavrov to meet with Brazil’s Lula as US fumes over Ukraine stance
 - [https://www.aljazeera.com/news/2023/4/17/lavrov-to-meet-with-brazils-lula-as-us-fumes-over-ukraine-stance](https://www.aljazeera.com/news/2023/4/17/lavrov-to-meet-with-brazils-lula-as-us-fumes-over-ukraine-stance)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 21:53:16+00:00

Lula has denounced Western efforts to supply Ukraine with weapons, a position Russia has praised amid its invasion.

## US military: Senior ISIL leader killed in Syria helicopter raid
 - [https://www.aljazeera.com/news/2023/4/17/us-military-senior-isil-leader-killed-in-syria-helicopter-raid](https://www.aljazeera.com/news/2023/4/17/us-military-senior-isil-leader-killed-in-syria-helicopter-raid)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 21:27:56+00:00

US Central Command says Abd-al-Hadi Mahmud al-Haji Ali was a planner of &#039;terror attacks in the Middle East and Europe&#039;.

## US financial institutions hit by deposit flight
 - [https://www.aljazeera.com/economy/2023/4/17/us-financial-institutions-hit-by-deposit-flight](https://www.aljazeera.com/economy/2023/4/17/us-financial-institutions-hit-by-deposit-flight)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 21:24:30+00:00

The collapse of two US banks last month has led to a flight of capital from small regional banks.

## More than 180 people killed in Sudan fighting: UN envoy
 - [https://www.aljazeera.com/news/2023/4/17/more-than-180-people-killed-in-sudan-fighting-un-envoy-to-sudan](https://www.aljazeera.com/news/2023/4/17/more-than-180-people-killed-in-sudan-fighting-un-envoy-to-sudan)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 20:52:11+00:00

Volker Perthes says warring sides don&#039;t appear to want peace mediation as strong clashes continue in the country.

## Florida Governor DeSantis intensifies battle with Disney
 - [https://www.aljazeera.com/economy/2023/4/17/florida-governor-desantis-intensifies-battle-with-disney](https://www.aljazeera.com/economy/2023/4/17/florida-governor-desantis-intensifies-battle-with-disney)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 20:34:24+00:00

DeSantis said the US state will nullify a development agreement that Disney had put in place to safeguard its business.

## What’s behind Washington’s wooing of Vietnam?
 - [https://www.aljazeera.com/program/inside-story/2023/4/17/whats-behind-washingtons-wooing-of-vietnam](https://www.aljazeera.com/program/inside-story/2023/4/17/whats-behind-washingtons-wooing-of-vietnam)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 20:21:33+00:00

US Secretary of State Antony Blinken visits Hanoi seeking closer relations.

## US arrests two for running secret Chinese ‘police station’ in NYC
 - [https://www.aljazeera.com/news/2023/4/17/us-arrests-two-for-running-secret-chinese-police-station-in-nyc](https://www.aljazeera.com/news/2023/4/17/us-arrests-two-for-running-secret-chinese-police-station-in-nyc)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 20:00:36+00:00

US officials accuse two men of engaging in &#039;transnational repression&#039; of Chinese diaspora in US at the behest of China.

## Kuwait crown prince announces new elections
 - [https://www.aljazeera.com/news/2023/4/17/kuwait-crown-prince-announces-new-elections](https://www.aljazeera.com/news/2023/4/17/kuwait-crown-prince-announces-new-elections)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 19:54:29+00:00

Crown prince says newly reinstated parliament to be dissolved and elections held in coming months.

## US envoy visits WSJ journalist Evan Gershkovich in Russian jail
 - [https://www.aljazeera.com/news/2023/4/17/us-envoy-visits-wsj-journalist-evan-gershkovich-in-russian-jail](https://www.aljazeera.com/news/2023/4/17/us-envoy-visits-wsj-journalist-evan-gershkovich-in-russian-jail)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 18:29:45+00:00

Ambassador says reporter is &#039;in good health and remains strong&#039; as dozens of countries voice concern over his arrest.

## New York judge: Defamation trial against Trump to start next week
 - [https://www.aljazeera.com/news/2023/4/17/new-york-judge-defamation-trial-against-trump-to-start-next-week](https://www.aljazeera.com/news/2023/4/17/new-york-judge-defamation-trial-against-trump-to-start-next-week)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 18:25:53+00:00

Judge rejects request to delay trial tied to rape allegation by E Jean Carroll against former US President Trump.

## What is Palestinian Prisoners’ Day?
 - [https://www.aljazeera.com/news/2023/4/17/what-is-palestinian-prisoners-day](https://www.aljazeera.com/news/2023/4/17/what-is-palestinian-prisoners-day)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 17:47:23+00:00

Marked every year on April 17, the event is dedicated to the centrality of prisoners to the Palestinian cause.

## McCarthy calls for spending caps to raise US debt ceiling
 - [https://www.aljazeera.com/news/2023/4/17/republican-leader-mccarthy-gives-speech-on-us-debt-ceiling](https://www.aljazeera.com/news/2023/4/17/republican-leader-mccarthy-gives-speech-on-us-debt-ceiling)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 17:45:24+00:00

Republican House Speaker Kevin McCarthy denounces US debt as a &#039;time bomb&#039; in a major New York City speech.

## There is much danger in the Sudan crisis but also an opportunity
 - [https://www.aljazeera.com/opinions/2023/4/17/there-is-much-danger-in-the-sudan-crisis-but-also-an-opportunity](https://www.aljazeera.com/opinions/2023/4/17/there-is-much-danger-in-the-sudan-crisis-but-also-an-opportunity)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 17:41:31+00:00

The proliferation of militias has long undermined the Sudanese state. The ongoing fighting could put an end to it.

## Alphabet shares fall on report Samsung may switch search to Bing
 - [https://www.aljazeera.com/economy/2023/4/17/alphabet-shares-fall-on-report-samsung-may-switch-search-to-bing](https://www.aljazeera.com/economy/2023/4/17/alphabet-shares-fall-on-report-samsung-may-switch-search-to-bing)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 17:01:56+00:00

Bing, a minor player, has risen to prominence with AI tech behind ChatGPT, posing a real challenge to Google.

## French court acquits Air France, Airbus over 2009 Rio-Paris crash
 - [https://www.aljazeera.com/news/2023/4/17/french-court-acquits-air-france-airbus-over-2009-rio-paris-crash](https://www.aljazeera.com/news/2023/4/17/french-court-acquits-air-france-airbus-over-2009-rio-paris-crash)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 16:48:52+00:00

The ruling is a huge blow to families of victims who have waged a 14-year campaign for justice.

## Russian mercenaries in Sudan: What is the Wagner Group’s role?
 - [https://www.aljazeera.com/news/2023/4/17/what-is-the-wagner-groups-role-in-sudan](https://www.aljazeera.com/news/2023/4/17/what-is-the-wagner-groups-role-in-sudan)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 16:33:35+00:00

The Russian mercenary group has been accused of plundering Sudan&#039;s gold resources to bankroll operations in Ukraine.

## Sunak investigated over wife’s interest in UK childcare firm
 - [https://www.aljazeera.com/news/2023/4/17/sunak-investigated-in-uk-over-possible-undeclared-interes](https://www.aljazeera.com/news/2023/4/17/sunak-investigated-in-uk-over-possible-undeclared-interes)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 16:30:13+00:00

Probe launched into shares Akshata Murty holds in a childcare agency, according to update given to Parliament members.

## UN chief appeals to rival Sudan leaders to end violence
 - [https://www.aljazeera.com/news/2023/4/17/un-chief-appeals-to-rival-sudan-leaders-to-end-violence](https://www.aljazeera.com/news/2023/4/17/un-chief-appeals-to-rival-sudan-leaders-to-end-violence)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 15:41:39+00:00

As fighting escalates, Antonio Guterres calls on army and paramilitary chiefs to restore calm and engage in dialogue.

## Chinese engineer charged with blasphemy in Pakistan
 - [https://www.aljazeera.com/news/2023/4/17/chinese-engineer-charged-with-blasphemy-in-pakistan](https://www.aljazeera.com/news/2023/4/17/chinese-engineer-charged-with-blasphemy-in-pakistan)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 15:32:36+00:00

The engineer allegedly became upset and reprimanded two local drivers for taking too much time from work to pray.

## SpaceX scrubs first test launch of behemoth Starship
 - [https://www.aljazeera.com/news/2023/4/17/spacex-scrubs-first-test-launch-of-behemoth-starship](https://www.aljazeera.com/news/2023/4/17/spacex-scrubs-first-test-launch-of-behemoth-starship)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 15:25:07+00:00

SpaceX says the vessel, which would be most powerful space rocket ever launched, will be key to one day reaching Mars.

## Sudan army declares RSF a rebel group, orders dissolution
 - [https://www.aljazeera.com/news/2023/4/17/sudan-army-declares-rsf-a-rebel-group-orders-dissolution](https://www.aljazeera.com/news/2023/4/17/sudan-army-declares-rsf-a-rebel-group-orders-dissolution)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 14:58:26+00:00

The Sudanese army also declares it has control of the national radio and television headquarters, despite RSF claims.

## In Poland, a Syrian fights for life after falling off border wall
 - [https://www.aljazeera.com/news/2023/4/17/in-poland-a-syrian-fights-for-life-after-falling-off-border-wall](https://www.aljazeera.com/news/2023/4/17/in-poland-a-syrian-fights-for-life-after-falling-off-border-wall)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 14:31:44+00:00

Like many refugees before him, Mohammad fled Belarus on April 7, but a tragic accident has left him in a coma.

## Nigerian aviation workers block roads as strike over pay begins
 - [https://www.aljazeera.com/news/2023/4/17/nigerian-aviation-workers-block-roads-as-strike-over-pay-begins](https://www.aljazeera.com/news/2023/4/17/nigerian-aviation-workers-block-roads-as-strike-over-pay-begins)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 14:04:32+00:00

Chanting Nigerian aviation workers block roads to the domestic terminal to protest working conditions and wages.

## Kenya: The making of a political crisis that never was
 - [https://www.aljazeera.com/opinions/2023/4/17/kenya-the-making-of-a-political-crisis-that-never-was](https://www.aljazeera.com/opinions/2023/4/17/kenya-the-making-of-a-political-crisis-that-never-was)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 13:26:49+00:00

In their competition for power, Kenyan politicians purposely instigate upheaval yet again.

## Taiwan in the hot seat during Paraguay presidential elections
 - [https://www.aljazeera.com/news/2023/4/17/taiwan-in-the-hot-seat-during-paraguay-presidential-elections](https://www.aljazeera.com/news/2023/4/17/taiwan-in-the-hot-seat-during-paraguay-presidential-elections)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 13:20:28+00:00

Paraguay’s presidential election features opposing views over whether to maintain diplomatic relations with Taiwan.

## Papua rebels ambush Indonesian troops looking for kidnapped pilot
 - [https://www.aljazeera.com/news/2023/4/17/papua-rebels-ambush-indonesian-troops-looking-for-kidnapped-pilot](https://www.aljazeera.com/news/2023/4/17/papua-rebels-ambush-indonesian-troops-looking-for-kidnapped-pilot)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 12:45:19+00:00

Armed separatists say they attacked soldiers as army was searching for a captured New Zealand pilot.

## Barcelona President Laporta denies crimes in refereeing scandal
 - [https://www.aljazeera.com/sports/2023/4/17/barcelona-president-laporta-denies-crimes-in-refereeing-scandal](https://www.aljazeera.com/sports/2023/4/17/barcelona-president-laporta-denies-crimes-in-refereeing-scandal)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 12:35:58+00:00

Barcelona and former club presidents face corruption charges related to allegations of improper payments.

## South Africa’s gold mining legacy
 - [https://www.aljazeera.com/gallery/2023/4/17/photos-south-africas-gold-mining-legacy](https://www.aljazeera.com/gallery/2023/4/17/photos-south-africas-gold-mining-legacy)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 12:31:29+00:00

In Johannesburg’s impoverished townships, poor communities are paying the price for the country’s rich gold mining past.

## Slovakia joins countries banning Ukrainian grain imports
 - [https://www.aljazeera.com/news/2023/4/17/hungary-threatens-to-extend-ban-on-ukrainian-grain](https://www.aljazeera.com/news/2023/4/17/hungary-threatens-to-extend-ban-on-ukrainian-grain)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 12:26:33+00:00

Meanwhile, Hungary says it may extend a ban if the EU fails to act and protect Hungarian farmers against price falls.

## Air pollution impacts every stage of human life, report finds
 - [https://www.aljazeera.com/news/2023/4/17/air-pollution-impacts-every-stage-of-human-life-report-finds](https://www.aljazeera.com/news/2023/4/17/air-pollution-impacts-every-stage-of-human-life-report-finds)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 11:53:06+00:00

From foetal development to dementia, 10 years of studies show the adverse impact of air pollution.

## Ethiopia recruits 500,000 women for domestic work in Saudi Arabia
 - [https://www.aljazeera.com/features/2023/4/17/ethiopia-recruits-500000-women-for-domestic-work-in-saudi-arabia](https://www.aljazeera.com/features/2023/4/17/ethiopia-recruits-500000-women-for-domestic-work-in-saudi-arabia)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 11:52:32+00:00

Human rights activists have criticised Ethiopia&#039;s continuing recruitment of women for domestic work in Saudi Arabia.

## Faith Thomas, first Indigenous Australian Test cricketer, dies
 - [https://www.aljazeera.com/sports/2023/4/17/faith-thomas-first-indigenous-australian-test-cricketer-dies](https://www.aljazeera.com/sports/2023/4/17/faith-thomas-first-indigenous-australian-test-cricketer-dies)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 11:14:32+00:00

Thomas, who has died aged 90, hailed for her &#039;groundbreaking contribution&#039; to cricket.

## Sudan fighting: How military rivalry descended into open warfare
 - [https://www.aljazeera.com/news/2023/4/17/sudan-fighting-how-military-rivalry-descended-into-open-warfare](https://www.aljazeera.com/news/2023/4/17/sudan-fighting-how-military-rivalry-descended-into-open-warfare)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 10:55:18+00:00

After years of protests and pressure to form a civilian government, how did things devolve into fighting on the streets?

## Heatstroke kills 11 at gov’t awards event in India’s Maharashtra
 - [https://www.aljazeera.com/news/2023/4/17/heatstroke-kills-11-at-govt-awards-event-in-indias-maharashtra](https://www.aljazeera.com/news/2023/4/17/heatstroke-kills-11-at-govt-awards-event-in-indias-maharashtra)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 10:34:22+00:00

Deaths reported as an estimated one million people waited in the sun for hours at the ceremony held near Mumbai.

## Battles between Sudanese army and RSF intensify on third day
 - [https://www.aljazeera.com/gallery/2023/4/17/battles-between-sudanese-army-and-rsf-intensify-on-third-day](https://www.aljazeera.com/gallery/2023/4/17/battles-between-sudanese-army-and-rsf-intensify-on-third-day)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 10:26:34+00:00

Air raids and shelling strike parts of Khartoum and the adjoining city of Omdurman.

## US stun Canada to win women’s ice hockey world championship
 - [https://www.aljazeera.com/sports/2023/4/17/us-stun-canada-to-win-womens-ice-hockey-world-championship](https://www.aljazeera.com/sports/2023/4/17/us-stun-canada-to-win-womens-ice-hockey-world-championship)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 10:18:02+00:00

Hilary Knight scores three times to secure the US a 6-3 win over archrival Canada.

## Elon Musk’s Space X to launch Starship rocket: What to know
 - [https://www.aljazeera.com/news/2023/4/17/elon-musks-space-x-to-launch-starship-rocket-what-to-know](https://www.aljazeera.com/news/2023/4/17/elon-musks-space-x-to-launch-starship-rocket-what-to-know)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 10:05:00+00:00

SpaceX is counting down to the first test flight of its Starship, the most powerful rocket ever built.

## Pakistan reacts to ex-Kashmir governor’s revelations on Pulwama
 - [https://www.aljazeera.com/news/2023/4/17/pakistan-reacts-to-ex-kashmir-governors-revelations-on-pulwama](https://www.aljazeera.com/news/2023/4/17/pakistan-reacts-to-ex-kashmir-governors-revelations-on-pulwama)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 10:03:21+00:00

In interview with Indian website, ex-official claims he was told by Modi to &#039;keep quiet&#039; over alleged security lapses.

## Colombia’s FARC rebel faction ready for ‘peace talks’
 - [https://www.aljazeera.com/news/2023/4/17/colombias-farc-rebel-faction-ready-for-peace-talks](https://www.aljazeera.com/news/2023/4/17/colombias-farc-rebel-faction-ready-for-peace-talks)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 09:18:32+00:00

The Estado Mayor Central armed group, a FARC breakaway organisation, says it is ready to start peace talks on May 16.

## As India becomes the most populous nation, Kerala ages
 - [https://www.aljazeera.com/gallery/2023/4/17/as-india-becomes-most-populous-an-ageing-trend-in-kerala](https://www.aljazeera.com/gallery/2023/4/17/as-india-becomes-most-populous-an-ageing-trend-in-kerala)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 09:06:36+00:00

The percentage of people aged 60-plus in Kerala has shot up from 5.1 percent to 16.5 percent - the highest among states.

## Putin critic Vladimir Kara-Murza sentenced to 25 years in prison
 - [https://www.aljazeera.com/news/2023/4/17/russian-court-sentences-opposition-activist-to-25-years-in-jail](https://www.aljazeera.com/news/2023/4/17/russian-court-sentences-opposition-activist-to-25-years-in-jail)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 09:00:19+00:00

Vladimir Kara-Murza, who has denounced Russia&#039;s war in Ukraine, jailed for treason and denigrating the army.

## New Zealand radio threatens to quit Twitter over ‘government’ tag
 - [https://www.aljazeera.com/economy/2023/4/17/new-zealand-radio-threatens-to-quit-twitter-over-government-tag](https://www.aljazeera.com/economy/2023/4/17/new-zealand-radio-threatens-to-quit-twitter-over-government-tag)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 08:10:02+00:00

Radio New Zealand says &#039;government-funded&#039; label does not reflect broadcaster’s editorial independence.

## IMF wants Egypt to make reforms before bailout review: Report
 - [https://www.aljazeera.com/economy/2023/4/17/imf-wants-egypt-to-make-reforms-before-bailout-review-report](https://www.aljazeera.com/economy/2023/4/17/imf-wants-egypt-to-make-reforms-before-bailout-review-report)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 07:10:01+00:00

IMF wants Cairo to privatise state assets and allow flexibility in its currency, Bloomberg report says.

## Myanmar military pardons more than 3,000 prisoners for New Year
 - [https://www.aljazeera.com/news/2023/4/17/myanmar-military-pardons-more-than-3000-prisoners-for-new-year](https://www.aljazeera.com/news/2023/4/17/myanmar-military-pardons-more-than-3000-prisoners-for-new-year)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 07:06:11+00:00

The military did not specify whether those jailed for opposing its power grab in February 2021 would be freed.

## South Korea, Japan finance heads to hold first talks since 2016
 - [https://www.aljazeera.com/economy/2023/4/17/south-korea-japan-finance-heads-to-hold-first-talks-since-2016](https://www.aljazeera.com/economy/2023/4/17/south-korea-japan-finance-heads-to-hold-first-talks-since-2016)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 05:34:04+00:00

South Korean Finance Minister Choo Kyung-ho tells reporters he will meet with his Japanese counterpart next month.

## US warship sails through Taiwan Strait following China war games
 - [https://www.aljazeera.com/news/2023/4/17/us-warship-sails-through-taiwan-strait-following-china-war-games](https://www.aljazeera.com/news/2023/4/17/us-warship-sails-through-taiwan-strait-following-china-war-games)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 03:22:34+00:00

USS Milius conducted a &#039;routine&#039; transit to demonstrate US commitment to a free and open Indo-Pacific, navy says.

## Russia-Ukraine war: List of key events, day 418
 - [https://www.aljazeera.com/news/2023/4/17/russia-ukraine-war-list-of-key-events-day-418](https://www.aljazeera.com/news/2023/4/17/russia-ukraine-war-list-of-key-events-day-418)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 03:04:19+00:00

As the conflict enters its 418th day, we take a look at the main developments.

## Four killed at ‘Sweet 16’ shooting in US state of Alabama
 - [https://www.aljazeera.com/news/2023/4/17/four-killed-at-sweet-16-shooting-in-us-state-of-alabama](https://www.aljazeera.com/news/2023/4/17/four-killed-at-sweet-16-shooting-in-us-state-of-alabama)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 01:35:28+00:00

Mass shooting at teen&#039;s birthday party is third high-profile outbreak of gun violence in US South in as many weeks.

## Four killed in shooting at Alabama ‘Sweet 16’ birthday party
 - [https://www.aljazeera.com/news/2023/4/17/four-killed-in-shooting-at-alabama-sweet-16-birthday-party](https://www.aljazeera.com/news/2023/4/17/four-killed-in-shooting-at-alabama-sweet-16-birthday-party)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-04-17 01:34:18+00:00

Attack in Dadeville, Alabama, marks the third high-profile mass shooting in as many weeks in the US.

