# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## How LinkedIn is changing and why some are not happy
 - [https://www.bbc.co.uk/news/business-65123115?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-65123115?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-04-17 23:05:19+00:00

LinkedIn's reputation for being dry and corporate is changing but not all users like the more personal tone.

## TUC: Government failing to protect workers from AI
 - [https://www.bbc.co.uk/news/technology-65301630?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-65301630?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-04-17 23:04:42+00:00

Union group claims using artificial intelligence to hire and fire staff could lead to greater discrimination.

## Sony World Photography Award 2023: Winner refuses award after revealing AI creation
 - [https://www.bbc.co.uk/news/entertainment-arts-65296763?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-65296763?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-04-17 11:44:48+00:00

Boris Eldagsen said he used the image to test the competition and to create an "open discussion".

## Netflix apologises as Love is Blind reunion delayed for UK viewers
 - [https://www.bbc.co.uk/news/technology-65298352?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-65298352?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-04-17 11:32:18+00:00

The special episode was pre-recorded and aired it in the US, but global viewers are left waiting.

## Angry Birds: Sega in talks to buy video game maker Rovio
 - [https://www.bbc.co.uk/news/business-65295724?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-65295724?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-04-17 03:31:16+00:00

The Japan-based entertainment giant Sega is in discussions over a deal for Rovio reportedly worth $1bn.

