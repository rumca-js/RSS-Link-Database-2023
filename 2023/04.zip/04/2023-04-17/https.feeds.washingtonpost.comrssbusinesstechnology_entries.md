# Source:The Washington Post - Tech, URL:https://feeds.washingtonpost.com/rss/business/technology, language:en-US

## SpaceX postpones Starship launch attempt
 - [https://www.washingtonpost.com/technology/2023/04/17/spacex-starship-launch-test-scrub/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2023/04/17/spacex-starship-launch-test-scrub/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-04-17 10:37:19+00:00

A valve on the rocket’s first stage apparently froze, SpaceX CEO Elon Musk said, leading to a pressurization issue.

## Fewer electric vehicles qualify for federal tax credits under new rules
 - [https://www.washingtonpost.com/business/2023/04/17/ev-tax-credit-list/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/business/2023/04/17/ev-tax-credit-list/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-04-17 10:00:00+00:00

Biden administration releases new and shorter list of EVs qualifying for federal tax credits as it begins enforcing tougher rules to comply with law.

## Watch Live: SpaceX readies Starship for critical test launch
 - [https://www.washingtonpost.com/technology/2023/04/17/space-x-starship-launch-live-updates/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2023/04/17/space-x-starship-launch-live-updates/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-04-17 09:03:14+00:00

The test launch of what, if successful, would be the world's most powerful rocket is set for a window of 8 a.m. to 10:30 a.m. Eastern time.

## What did the pandemic do to lunch?
 - [https://www.washingtonpost.com/business/2023/04/17/business-lunch-power-lunch-pandemic-recovery/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/business/2023/04/17/business-lunch-power-lunch-pandemic-recovery/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-04-17 06:00:01+00:00

Business lunch will never die, but it’s evolving as the reassessment of work continues.

## Discord leak suggests China doesn’t need TikTok to find U.S. secrets
 - [https://www.washingtonpost.com/technology/2023/04/17/discord-document-leak-tiktok-ban/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2023/04/17/discord-document-leak-tiktok-ban/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-04-17 06:00:00+00:00

The leak of classified documents via U.S.-based app Discord is a reminder that social media is hard to control.

