# Source:Ryan Reynolds, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCA3-nIYWu4PTWkb6NwhEpzg, language:en-US

## Aboot Nuvei
 - [https://www.youtube.com/watch?v=lDDlXSWbHLQ](https://www.youtube.com/watch?v=lDDlXSWbHLQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCA3-nIYWu4PTWkb6NwhEpzg
 - date published: 2023-04-17 12:49:42+00:00

This isn’t the Canadian national anthem but it’s okay if you stand up. @Nuvei 

https://nuvei.com/

