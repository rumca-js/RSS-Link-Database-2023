# Source:SAMTIME, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCd6vEDS3SOhWbXZrxbrf_bw, language:en-US

## If Linux Took Over the World
 - [https://www.youtube.com/watch?v=p5Aebv3RoAA](https://www.youtube.com/watch?v=p5Aebv3RoAA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCd6vEDS3SOhWbXZrxbrf_bw
 - date published: 2023-04-17 17:59:03+00:00

If Linux took over the world, things would be a lot cheaper.

19 Things Linux Users Never Say: https://youtu.be/zJL6siOu3e0
If Linux Took Over Apple: https://youtu.be/8zqn8BcBHe0

FUNKY TIME WEBSITE: https://funkytime.tv
SUPPORT: https://funkytime.tv/patriot-signup/
MERCH: https://funkytime.tv/shop/

FACEBOOK: http://www.facebook.com/SamtimeNews
TWITTER: http://twitter.com/SamtimeNews
INSTAGRAM: http://instagram.com/samtimenews

-----------------------------------

'Escape the ordinary. Embrace the FUNKY!'

-----------------------------------

For business enquiries only: business@funkytime.tv
Copyright FUNKY TIME PRODUCTIONS 2023

