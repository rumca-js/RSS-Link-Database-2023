# Source:The Hill, URL:https://thehill.com/news/feed/, language:en-US

## GOP education committee chair: 'I don't know what a trans girl is'
 - [https://thehill.com/homenews/lgbtq/3955775-gop-education-committee-chair-i-dont-know-what-a-trans-girl-is/](https://thehill.com/homenews/lgbtq/3955775-gop-education-committee-chair-i-dont-know-what-a-trans-girl-is/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 23:34:24+00:00

Rep. Virginia Foxx (R-N.C.) on Monday said she did not know what a transgender person was during a hearing on federal legislation to ban transgender women and girls from competing on female sports teams.  “I don't know what a trans girl is,” Foxx said Monday during a House hearing on H.R. 734, a bill that...

## Ben & Jerry's workers announce plan to unionize in Vermont
 - [https://thehill.com/homenews/ap/3955766-ben-jerrys-workers-announce-plan-to-unionize-in-vermont/](https://thehill.com/homenews/ap/3955766-ben-jerrys-workers-announce-plan-to-unionize-in-vermont/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 23:33:41+00:00

BURLINGTON, Vt. (AP) — About 40 workers at the Ben &#38; Jerry's ice cream shop in the Vermont city where the company was founded announced Monday that they plan to form a union."Collectively, we have come to embody Ben and Jerry's slogan of 'peace, love, and ice cream,'" they said they wrote to management. The...

## 5 takeaways from Jim Jordan’s NYC hearing into Alvin Bragg and crime
 - [https://thehill.com/homenews/house/3955513-5-takeaways-from-jim-jordans-nyc-hearing-into-alvin-bragg-and-crime/](https://thehill.com/homenews/house/3955513-5-takeaways-from-jim-jordans-nyc-hearing-into-alvin-bragg-and-crime/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 23:32:56+00:00

A new battle in the political war over former President Trump’s indictment took place in New York on Monday. House Judiciary Committee Chairman Jim Jordan (R-Ohio), a key Trump ally, held a field hearing. The hearing’s official title was “Victims of Violent Crime in Manhattan” — and several such victims did testify. But the hearing was...

## Biden's EV push will require efforts on charging, price
 - [https://thehill.com/newsletters/energy-environment/3955668-bidens-ev-push-will-require-efforts-on-charging-price/](https://thehill.com/newsletters/energy-environment/3955668-bidens-ev-push-will-require-efforts-on-charging-price/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 23:08:02+00:00

Welcome to The Hill's Energy &#38; Environment newsletter {beacon} Energy &#38; Environment Energy &#38; Environment   The Big Story  Biden's EV push will require efforts on charging, price Electric vehicles have a long way to go on pricing and charging infrastructure to meet a push by the president for EVs to make up two-thirds of...

## Canada's public broadcaster quits Twitter, joining US outlets
 - [https://thehill.com/homenews/media/3955671-canadas-public-broadcaster-quits-twitter-joining-us-outlets/](https://thehill.com/homenews/media/3955671-canadas-public-broadcaster-quits-twitter-joining-us-outlets/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 23:03:50+00:00

The Canadian Broadcasting Corporation (CBC) announced that it will quit posting content on Elon Musk-owned Twitter, joining other U.S.-based media outlets.  “Our journalism is impartial and independent. To suggest otherwise is untrue. That is why we are pausing our activities on @Twitter,” CBC wrote in a tweet on Monday.  Twitter hit CBC, along with other...

## McCarthy pitches Wall Street on plan to avert default
 - [https://thehill.com/newsletters/business-economy/3955672-mccarthy-pitches-wall-street-on-plan-to-avert-default/](https://thehill.com/newsletters/business-economy/3955672-mccarthy-pitches-wall-street-on-plan-to-avert-default/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 22:38:05+00:00

Welcome to The Hill's Business &#038; Economy newsletter {beacon} Business &#038; Economy Business &#038; Economy &#8202; The Big Story  McCarthy pitches Wall Street on plan to avert default The GOP House Speaker took to Wall Street to call for significant fiscal reforms to go hand in hand with raising the debt limit later this year,...

## GOP coalesces around work requirements
 - [https://thehill.com/newsletters/health-care/3955663-gop-coalesces-around-work-requirements/](https://thehill.com/newsletters/health-care/3955663-gop-coalesces-around-work-requirements/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 22:36:05+00:00

Welcome to The Hill's Health Care newsletter {beacon} Health Care Health Care &#8202; The Big Story  McCarthy, GOP pushing work requirements  In a speech Monday, Speaker Kevin McCarthy (R-Calif.) did not identify which federal programs need stricter rules, but in recent weeks Republicans have pointed to Medicaid and food assistance programs. © AP McCarthy on...

## McConnell returns to Capitol as GOP faces full plate of challenges
 - [https://thehill.com/homenews/senate/3955605-mcconnell-returns-to-capitol-as-gop-faces-full-plate-of-challenges/](https://thehill.com/homenews/senate/3955605-mcconnell-returns-to-capitol-as-gop-faces-full-plate-of-challenges/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 22:23:21+00:00

Senate Republican Leader Mitch McConnell (Ky.) returned to the Capitol Monday after a five-and-a-half-week absence as his party faces an array of tough political problems: the expiration of the debt limit, a messy fight over the 2024 presidential nomination and divisions over abortion policy.    McConnell has been the GOP’s steady hand on the levers...

## Republicans eye Democrats' votes on energy package ahead of 2024 election: memo
 - [https://thehill.com/policy/energy-environment/3955612-republicans-eye-democrats-votes-on-energy-package-ahead-of-2024-election-memo/](https://thehill.com/policy/energy-environment/3955612-republicans-eye-democrats-votes-on-energy-package-ahead-of-2024-election-memo/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 22:12:25+00:00

Republicans are looking to use vulnerable Democrats’ votes on a GOP energy bill against them in the next election cycle.  A memo from the National Republican Congressional Committee (NRCC), the party’s campaign arm, that was obtained by The Hill states that “vulnerable House Democrats representing districts with jobs tied to domestic energy production made a...

## Clarence Thomas to amend financial disclosures after ProPublica reports: CNN
 - [https://thehill.com/blogs/blog-briefing-room/3955573-clarence-thomas-to-amend-financial-disclosures-after-propublica-reports-cnn/](https://thehill.com/blogs/blog-briefing-room/3955573-clarence-thomas-to-amend-financial-disclosures-after-propublica-reports-cnn/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 21:59:20+00:00

Supreme Court Justice Clarence Thomas is planning to amend his financial disclosure documents after ProPublica reported that he failed to report a real estate deal he made with a prominent Republican donor in 2014, according to CNN. The move by Thomas comes after the conservative justice has faced intense scrutiny over his relationship with Harlan...

## Appeals court upholds Derek Chauvin’s conviction for the murder of George Floyd
 - [https://thehill.com/regulation/court-battles/3955580-appeals-court-upholds-derek-chauvins-conviction-for-the-murder-of-george-floyd/](https://thehill.com/regulation/court-battles/3955580-appeals-court-upholds-derek-chauvins-conviction-for-the-murder-of-george-floyd/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 21:53:51+00:00

The Minnesota Court of Appeals on Monday upheld the second-degree murder conviction of former Minneapolis police officer Derek Chauvin for the 2020 killing of George Floyd, rejecting Chauvin's request for a new trial. Chauvin, who is white, was called to arrest Floyd, who was Black, outside a store after the clerk believed the 43-year-old was...

## GOP immigration bill sketches battle lines for 2024
 - [https://thehill.com/homenews/house/3955546-house-gop-immigration-bill/](https://thehill.com/homenews/house/3955546-house-gop-immigration-bill/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 21:47:57+00:00

House Republicans on Monday unveiled a 130-page immigration bill packed with President Trump-era immigration proposals that is poised to set battle lines within the GOP and between the two parties. Among other proposals, the bill includes severe restrictions on asylum-seekers, an issue that's caused a rift in the party and led to a public feud...

## Man removed from NYC crime hearing after shouting insults at Schiff
 - [https://thehill.com/homenews/house/3955528-man-removed-from-nyc-crime-hearing-after-shouting-insults-at-schiff/](https://thehill.com/homenews/house/3955528-man-removed-from-nyc-crime-hearing-after-shouting-insults-at-schiff/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 21:39:46+00:00

The House Judiciary Committee hearing about violent crime held in New York on Monday descended into disarray after hecklers interrupted Rep. Adam Schiff (D-Calif.) and shouted at him, calling him a “scumbag” and humoring the lawmakers with a “very unfortunate attack” on Ralph Nader. During Schiff’s opening remarks, in which he criticized Republicans for holding...

## Can AI solve the air traffic control problem?
 - [https://thehill.com/opinion/technology/3955450-can-ai-solve-the-air-traffic-control-problem/](https://thehill.com/opinion/technology/3955450-can-ai-solve-the-air-traffic-control-problem/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 21:30:00+00:00

When it comes to air traffic control, safety can never be compromised.

## Democrat mockingly endorses Santos to win GOP House primary
 - [https://thehill.com/homenews/house/3955502-democrat-mockingly-endorses-santos-to-win-gop-house-primary/](https://thehill.com/homenews/house/3955502-democrat-mockingly-endorses-santos-to-win-gop-house-primary/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 21:27:53+00:00

Rep. Brendan Boyle (D-Pa.) mockingly endorsed fellow Rep. George Santos (R-N.Y.) to win his GOP House primary election after the first-term congressman, who has admitted to lying about his resume, announced his run for reelection on Monday. “I hereby formally endorse George Santos to win the GOP nomination for Congress from his district,” Boyle wrote...

## GOP confronts raucous field hearing on NYC crime
 - [https://thehill.com/homenews/house/3955426-gop-confronts-raucous-field-hearing-on-nyc-crime/](https://thehill.com/homenews/house/3955426-gop-confronts-raucous-field-hearing-on-nyc-crime/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 21:06:20+00:00

Lawmakers of both parties may have gotten more than they bargained for during a field hearing in New York City on Monday organized in the shadow of former President Trump’s indictment in the city. Ostensibly about high crime rates in New York under the leadership of Manhattan District Attorney Alvin Bragg (D), who is prosecuting...

## Here are the House, Senate members who have endorsed Trump for 2024
 - [https://thehill.com/homenews/campaign/3955314-here-are-the-house-senate-members-who-have-endorsed-trump-for-2024/](https://thehill.com/homenews/campaign/3955314-here-are-the-house-senate-members-who-have-endorsed-trump-for-2024/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 21:06:19+00:00

As the Republican field for 2024 comes into sharper focus, GOP lawmakers in Washington have started to pick sides early in the primary fight. Even after he became the first sitting or former president to face criminal charges, former President Trump has seen a flock of Republicans in D.C. line up behind him as he...

## Trump to deliver remarks in New Hampshire next week
 - [https://thehill.com/homenews/campaign/3955448-trump-to-deliver-remarks-in-new-hampshire-next-week/](https://thehill.com/homenews/campaign/3955448-trump-to-deliver-remarks-in-new-hampshire-next-week/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 21:01:17+00:00

Former President Trump will travel to New Hampshire next week to deliver remarks in the first primary state on the GOP calendar, his campaign announced Monday. Trump will travel to Manchester for a speech on April 27. It will mark his first visit to the Granite State since late January, when he spoke at an...

## Achieving an affordable health care future for patients
 - [https://thehill.com/opinion/congress-blog/3955465-achieving-an-affordable-health-care-future-for-patients/](https://thehill.com/opinion/congress-blog/3955465-achieving-an-affordable-health-care-future-for-patients/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 21:00:00+00:00

The drug pricing debate in Washington has kicked back into high gear, and it is more contentious, convoluted and misguided than ever. Who’s on what team? Whose “turn” is next? And, most importantly, what is in the best interest of patients and taxpayers? These questions may sound rhetorical, but they’re questions that Congress should be...

## West Virginia's sole abortion clinic drops challenge to state ban
 - [https://thehill.com/policy/healthcare/3955388-west-virginias-sole-abortion-clinic-drops-challenge-to-state-ban/](https://thehill.com/policy/healthcare/3955388-west-virginias-sole-abortion-clinic-drops-challenge-to-state-ban/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 20:42:03+00:00

The sole abortion provider in West Virginia is no longer challenging the state law imposing a near-total ban on abortions. In a court filing Monday, Women's Health Center of West Virginia said it voluntarily dismissed the lawsuit after its physician "determined that he will not be able to resume providing abortion care in West Virginia"...

## House, Senate leaders return to debt limit debate
 - [https://thehill.com/newsletters/evening-report/3955432-house-senate-leaders-return-to-debt-limit-debate/](https://thehill.com/newsletters/evening-report/3955432-house-senate-leaders-return-to-debt-limit-debate/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 20:35:07+00:00

{beacon}    Evening Report Monday, April 17   ©  The Hill Schumer pans proposal pushed by McCarthy Fresh off a two-week congressional recess, House Speaker Kevin McCarthy (R-Calif.) previewed the next step in the debt limit debate Monday at the New York Stock Exchange, saying a vote to raise the ceiling will take place in "the coming...

## Watch live: House Rules Committee holds hearing on transgender athlete legislation
 - [https://thehill.com/homenews/3955235-watch-live-house-rules-committee-holds-hearing-on-transgender-athlete-legislation/](https://thehill.com/homenews/3955235-watch-live-house-rules-committee-holds-hearing-on-transgender-athlete-legislation/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 20:10:00+00:00

The House Rules Committee is holding a hearing Monday afternoon on legislation that would ban transgender women and girls from competing on female sports teams. The measure, known as the “Protection of Women and Girls in Sports Act,” would amend Title IX, the federal civil rights law prohibiting sex-based discrimination in education, to recognize sex as that...

## McConnell returns to Senate: 'It’s good to be back'
 - [https://thehill.com/homenews/senate/3955376-mcconnell-returns-to-senate-its-good-to-be-back/](https://thehill.com/homenews/senate/3955376-mcconnell-returns-to-senate-its-good-to-be-back/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 20:07:49+00:00

Senate Republican Leader Mitch McConnell (Ky.) returned to the Senate floor Monday for the first time since suffering a concussion on March 8, declaring: “It’s good to be back.”  McConnell, who is 81, thanked his Senate colleagues “for their warm wishes” shared over the past few weeks and joked about his injury not being worse...

## Biden’s climate blind spot
 - [https://thehill.com/opinion/energy-environment/3955210-bidens-climate-blind-spot/](https://thehill.com/opinion/energy-environment/3955210-bidens-climate-blind-spot/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 20:00:00+00:00

Biden needs his own Keystone moment to stave off a massive fossil fuel buildout under his watch.

## Apple unveils savings account
 - [https://thehill.com/policy/technology/3955294-apple-unveils-savings-account/](https://thehill.com/policy/technology/3955294-apple-unveils-savings-account/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 19:59:58+00:00

Apple on Monday launched savings accounts for its Apple Card users, which can be accessed and tracked through the Apple Wallet app on iPhones. In a news release, the company said users can deposit cash back on purchases into Goldman Sachs savings accounts, without any additional deposit feed. It said the accounts have an annual...

## How the IRS is trying to make tax filing day easier
 - [https://thehill.com/business/3955248-how-the-irs-is-trying-to-make-tax-filing-day-easier/](https://thehill.com/business/3955248-how-the-irs-is-trying-to-make-tax-filing-day-easier/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 19:51:50+00:00

The due date to file a tax return this year is April 18 and it comes against the backdrop of some major structural changes in U.S. tax administration that have been a serious point of contention between Democrats and Republicans. But those changes, which will impact audits rates and help the government collect hundreds of...

## George Santos announces reelection bid
 - [https://thehill.com/homenews/house/3955270-george-santos-announces-reelection-bid/](https://thehill.com/homenews/house/3955270-george-santos-announces-reelection-bid/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 19:30:31+00:00

Rep. George Santos (R-N.Y.) on Monday announced he is running for reelection, despite being dogged by multiple investigations, facing questions about his resume and finances and being the target of calls from members of his own party to resign. “Since the Left is pushing radical agendas, the economy is struggling, and Washington is incapable of solving anything, we need...

## Schumer pans McCarthy’s one-year debt-ceiling extension as 'terrible idea'
 - [https://thehill.com/homenews/senate/3955223-schumer-pans-mccarthys-one-year-debt-ceiling-extension-as-terrible-idea/](https://thehill.com/homenews/senate/3955223-schumer-pans-mccarthys-one-year-debt-ceiling-extension-as-terrible-idea/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 19:19:59+00:00

Senate Majority Leader Chuck Schumer (D-N.Y.) on Monday panned Speaker Kevin McCarthy’s (R-Calif.) proposal to extend the nation’s debt ceiling until May of 2024 as a “terrible idea,” making it clear to everyone in Washington that Democrats don’t want to debate the issue again before the next election.   McCarthy formally unveiled his proposal to...

## Oklahoma governor calls for resignations after county officials reportedly discussed killing journalists, hanging Black people
 - [https://thehill.com/homenews/state-watch/3955209-oklahoma-governor-calls-for-resignations-after-county-officials-reportedly-discussed-killing-journalists-hanging-black-people/](https://thehill.com/homenews/state-watch/3955209-oklahoma-governor-calls-for-resignations-after-county-officials-reportedly-discussed-killing-journalists-hanging-black-people/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 19:16:12+00:00

Oklahoma Gov. Kevin Stitt (R) has called for the McCurtain County sheriff and multiple county officials to resign after leaked audio showed the county leaders discussing killing local reporters and lynching Black people.  Sheriff Kevin Clardy, his investigator Alicia Manning, Commissioners Mark Jennings and Robert Beck, commissioners' secretary Heather Carter and jail administrator Larry Hendrix...

## Democrat quotes Logan Roy from 'Succession' in blasting GOP crime hearing
 - [https://thehill.com/blogs/in-the-know/3955221-democrat-quotes-logan-roy-from-succession-in-blasting-gop-crime-hearing/](https://thehill.com/blogs/in-the-know/3955221-democrat-quotes-logan-roy-from-succession-in-blasting-gop-crime-hearing/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 19:04:39+00:00

Rep. Madeleine Dean (D-Pa.) is using the words of “Succession’s” Logan Roy to blast her Republican colleagues on the House Judiciary Committee, accusing them of “gesturing about violent crime" by holding a field hearing in New York City. “None of this is new: Hearing after hearing, one Congress to the next, the numbers keep repeating...

## Ex-Biden chief of staff Ron Klain rejoins law firm O’Melveny
 - [https://thehill.com/homenews/3955165-ex-biden-chief-of-staff-ron-klain-rejoins-law-firm-omelveny/](https://thehill.com/homenews/3955165-ex-biden-chief-of-staff-ron-klain-rejoins-law-firm-omelveny/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 18:55:12+00:00

Former White House chief of staff Ron Klain has rejoined global law firm O’Melveny as a partner after leaving the Biden administration, the firm announced Monday.  Klain, who was sought after by law and lobbying firms for his close relationship with President Biden, previously was a partner at O’Melveny from 1999 to 2004.  This time...

## DeSantis floats building prison on land next to Disney World
 - [https://thehill.com/homenews/state-watch/3955160-desantis-floats-building-prison-on-land-next-to-disney-world/](https://thehill.com/homenews/state-watch/3955160-desantis-floats-building-prison-on-land-next-to-disney-world/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 18:50:32+00:00

Florida Gov. Ron DeSantis (R) said Monday that the state might consider building a prison or potentially another amusement park next to land owned by Disney amid his administration's ongoing feud with the entertainment giant. The governor’s clash with Disney started when the company came out against his education plan that limits the instruction of...

## McDonald's making these 4 changes to its burgers by 2024, company says
 - [https://thehill.com/changing-america/enrichment/arts-culture/3954878-mcdonalds-making-these-4-changes-to-its-burgers-by-2024-company-says/](https://thehill.com/changing-america/enrichment/arts-culture/3954878-mcdonalds-making-these-4-changes-to-its-burgers-by-2024-company-says/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 18:40:11+00:00

Your Big Mac taste a little different lately? McDonald's said it's been tweaking the way they make their signatures burgers in about a dozen large cities, and plans to roll out the changes nationwide.

## What should parents do over the summer to counter pandemic learning loss?
 - [https://thehill.com/blogs/blog-briefing-room/3950725-what-should-parents-do-over-the-summer-to-counter-pandemic-learning-loss/](https://thehill.com/blogs/blog-briefing-room/3950725-what-should-parents-do-over-the-summer-to-counter-pandemic-learning-loss/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 18:36:41+00:00

The fast-approaching summer offers a precious opportunity for parents of students suffering severe learning loss from the coronavirus pandemic. Schools and policymakers have been scrambling since the 2022 Nation’s Report Card last fall showed that students lost decades of progress in reading and math when they missed out on in-person classes. Now, students are set...

## US arrests two in connection with 'secret' Chinese police station in NY
 - [https://thehill.com/policy/national-security/3955150-us-arrests-two-in-connection-with-secret-chinese-police-station-in-ny/](https://thehill.com/policy/national-security/3955150-us-arrests-two-in-connection-with-secret-chinese-police-station-in-ny/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 18:33:56+00:00

Federal authorities in New York made two arrests Monday in connection with the establishment of a Chinese-government run police station in Manhattan where officials allegedly monitored pro-democracy activists. The clandestine station, run by China’s Ministry of Public Security (MPS), was announced alongside a complaint charging 34 individuals accused of working at a “troll farm” run...

## Republicans’ cult of the assault weapon won’t withstand Gen Z
 - [https://thehill.com/opinion/campaign/3954930-republicans-cult-of-the-assault-weapon-wont-withstand-gen-z/](https://thehill.com/opinion/campaign/3954930-republicans-cult-of-the-assault-weapon-wont-withstand-gen-z/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 18:30:00+00:00

The out-of-control gun crisis is not being ignored by the generation that has grown up practicing shelter-in-place drills.

## Louisville police official after second mass shooting in a week: 'This is not okay'
 - [https://thehill.com/homenews/state-watch/3955102-louisville-police-official-after-second-mass-shooting-in-a-week-this-is-not-okay/](https://thehill.com/homenews/state-watch/3955102-louisville-police-official-after-second-mass-shooting-in-a-week-this-is-not-okay/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 18:27:09+00:00

Louisville Metro Police Deputy Chief Paul Humphrey decried gun violence and pushed for change after the city suffered its second mass shooting in a week. The two incidents have left a total of seven people dead.  A shooter killed five people and injured at least eight others after opening fire at Old National Bank in...

## Schumer will move to replace Feinstein on Judiciary panel this week
 - [https://thehill.com/homenews/senate/3955085-schumer-will-move-to-replace-feinstein-on-judiciary-panel-this-week/](https://thehill.com/homenews/senate/3955085-schumer-will-move-to-replace-feinstein-on-judiciary-panel-this-week/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 18:01:45+00:00

Senate Majority Leader Chuck Schumer (D-N.Y.) says he will move a resolution this week to temporarily replace Sen. Dianne Feinstein (D-Calif.) on the Judiciary Committee to keep President Biden’s judicial nominees moving to the floor.   Schumer said he hopes Republicans will support the resolution to fill Feinstein’s seat on the committee while the 89-year-old...

## Judy Blume clarifies J.K. Rowling remarks: 'I wholly support the trans community'
 - [https://thehill.com/blogs/in-the-know/3955074-judy-blume-clarifies-j-k-rowling-remarks-i-wholly-support-the-trans-community/](https://thehill.com/blogs/in-the-know/3955074-judy-blume-clarifies-j-k-rowling-remarks-i-wholly-support-the-trans-community/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 18:00:27+00:00

Judy Blume is responding to Sunday Times headline stating she is “100 percent” behind fellow author J.K. Rowling, seeking to emphasize that she stands "with the trans community" against discrimination. In an interview with the British newspaper, Blume said of Rowling, “I love her. I am behind her 100 percent as I watch from afar.” According to...

## Why is the FTC blocking free market health care solutions?
 - [https://thehill.com/opinion/healthcare/3952403-why-is-the-ftc-blocking-free-market-health-care-solutions/](https://thehill.com/opinion/healthcare/3952403-why-is-the-ftc-blocking-free-market-health-care-solutions/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 18:00:00+00:00

Anti-trust laws, which the FTC is attempting to apply to hospitals, were designed to ensure fair and open competitive markets — not to eliminate entire segments of an industry.

## Trump urges Murdoch to embrace false 2020 election claims in Dominion trial
 - [https://thehill.com/homenews/media/3954988-trump-urges-murdoch-to-embrace-false-2020-election-claims-in-dominion-trial/](https://thehill.com/homenews/media/3954988-trump-urges-murdoch-to-embrace-false-2020-election-claims-in-dominion-trial/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 17:32:07+00:00

Former President Trump is urging Rupert Murdoch, the chairman of Fox Corp., to embrace his false allegations of voter fraud if the media mogul is to give testimony during a jury trial in the defamation lawsuit facing Fox News this week. "Fox News is in big trouble if they do not expose the truth on...

## Judge denies Trump bid to delay trial over E. Jean Carroll rape allegation
 - [https://thehill.com/regulation/court-battles/3954955-judge-denies-trump-bid-to-delay-trial-over-e-jean-carroll-rape-allegation/](https://thehill.com/regulation/court-battles/3954955-judge-denies-trump-bid-to-delay-trial-over-e-jean-carroll-rape-allegation/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 17:30:13+00:00

Former President Trump’s trial in a case for alleged rape and libel is set to begin next week after a judge on Monday rejected Trump’s request for a one-month delay of the proceedings. The civil trial stemming from author E. Jean Carroll's allegation that Trump raped her in a New York department store in the...

## We should all get into good trouble like Tenn. state Reps. Pearson and Jones
 - [https://thehill.com/opinion/congress-blog/3954853-we-should-all-get-into-good-trouble-like-tenn-state-reps-pearson-and-jones/](https://thehill.com/opinion/congress-blog/3954853-we-should-all-get-into-good-trouble-like-tenn-state-reps-pearson-and-jones/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 17:30:00+00:00

In his prolific final words, Brother John Lewis wrote "When you see something that is not right, you must say something. You must do something. Democracy is not a state. It is an act..." and demanded that each of us “answer the highest calling of your heart and stand up for what you truly believe.”   ...

## Minnesota settles with Juul, Altria over youth vaping allegations
 - [https://thehill.com/policy/healthcare/3954966-minnesota-settles-with-juul-altria-over-youth-vaping-allegations/](https://thehill.com/policy/healthcare/3954966-minnesota-settles-with-juul-altria-over-youth-vaping-allegations/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 17:04:47+00:00

Minnesota settled its lawsuit against e-cigarette company Juul and its largest former investor, Altria, over allegations the companies intentionally marketed to young people. Attorney General Keith Ellison (D) said the terms of the settlement will be kept confidential until formal papers are publicly filed with the court, which is anticipated to happen in the next...

## Gabby Giffords denounces shooting of Black Kansas City teen 'for simply ringing a doorbell'
 - [https://thehill.com/homenews/state-watch/3954929-gabby-giffords-denounces-shooting-of-black-kansas-city-teen-for-simply-ringing-a-doorbell/](https://thehill.com/homenews/state-watch/3954929-gabby-giffords-denounces-shooting-of-black-kansas-city-teen-for-simply-ringing-a-doorbell/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 17:04:26+00:00

Former Rep. Gabby Giffords (D-Ariz.) on Monday denounced last week's shooting of a Black Kansas City, Mo., teenager who had arrived at a wrong address. “As someone who is still recovering from a gunshot to the head, I am heartbroken and infuriated that Ralph Yarl now faces a lifetime of recovery. At 16 years old....

## A dangerous new low: Supreme Court must reform — or be reformed
 - [https://thehill.com/opinion/judiciary/3954866-a-dangerous-new-low-supreme-court-must-reform-or-be-reformed/](https://thehill.com/opinion/judiciary/3954866-a-dangerous-new-low-supreme-court-must-reform-or-be-reformed/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 17:00:00+00:00

Apparent ethical improprieties by Associate Justice Clarence Thomas go to the heart of the court’s legitimacy.

## Kari Lake holds wide lead in hypothetical Arizona Senate GOP primary: poll
 - [https://thehill.com/homenews/campaign/3954933-kari-lake-holds-wide-lead-in-hypothetical-arizona-senate-gop-primary-poll/](https://thehill.com/homenews/campaign/3954933-kari-lake-holds-wide-lead-in-hypothetical-arizona-senate-gop-primary-poll/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 16:58:17+00:00

Former Arizona gubernatorial candidate Kari Lake holds a wide lead over other prospective challengers in a hypothetical Arizona Senate Republican primary, according to a new poll. A poll released by J. L. Partners shared with The Hill on Monday found Lake receiving 38 percent support in an Arizona Senate GOP primary among registered Republican and...

## Nadler says Jordan 'is doing the bidding' of Trump with hearing on Manhattan crime
 - [https://thehill.com/homenews/house/3954881-nadler-says-jordan-is-doing-the-bidding-of-trump-with-judiciary-hearing-on-manhattan-crime/](https://thehill.com/homenews/house/3954881-nadler-says-jordan-is-doing-the-bidding-of-trump-with-judiciary-hearing-on-manhattan-crime/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 16:56:47+00:00

Rep. Jerry Nadler (D-N.Y.) accused Rep. Jim Jordan (R-Ohio) of “doing the bidding” of former President Trump during the House Judiciary Committee’s hearing on violent crime in Manhattan on Monday. The GOP-led committee announced the field hearing in New York City shortly after a grand jury empaneled by Manhattan District Attorney Alvin Bragg (D) voted...

## Amazon's HQ2 pause hasn't quelled worries about gentrification, promised jobs
 - [https://thehill.com/business/3954849-amazon-hq2-arlington-gentrification/](https://thehill.com/business/3954849-amazon-hq2-arlington-gentrification/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 16:55:55+00:00

Amazon’s pause in construction at its second headquarters in Arlington, Va. has not quelled enthusiasm for the expected economic boost to the region.  There is still a sense in the community that the incoming workers will increase traffic at local businesses, and some community leaders pointed to the critical economic benefits Arlington’s partnership with the company has already brought. ...

## Half of North American bat species are at risk, report warns
 - [https://thehill.com/policy/energy-environment/3954887-half-of-north-american-bat-species-are-at-risk-report-warns/](https://thehill.com/policy/energy-environment/3954887-half-of-north-american-bat-species-are-at-risk-report-warns/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 16:50:25+00:00

Roughly half of North America’s 154 bat species are under threat from population decline in the next 15 years, according to a new report. The inaugural “State of the Bats” report from the North American Bat Conservation Alliance indicates 52 percent of species could be at risk and that climate change will affect up to...

## Kinzinger says snake hitched a ride on his plane from Texas to Illinois
 - [https://thehill.com/blogs/in-the-know/3954884-kinzinger-says-snake-hitched-a-ride-on-his-plane-from-texas-to-illinois/](https://thehill.com/blogs/in-the-know/3954884-kinzinger-says-snake-hitched-a-ride-on-his-plane-from-texas-to-illinois/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 16:33:43+00:00

Former Rep. Adam Kinzinger says he had a real-life “Snakes on a Plane” moment after a slithering creature seemingly stowed away aboard his aircraft. The Illinois Republican detailed his close encounter with a scaly, uninvited guest in a Monday tweet. “Yesterday I flew from Texas to Illinois, four hours at 17,500,” wrote Kinzinger, a 45-year-old former...

## The Hill's 12:30 Report — Lawmakers flock back to Capitol Hill
 - [https://thehill.com/homenews/3954773-the-hills-1230-report-lawmakers-flock-back-to-capitol-hill/](https://thehill.com/homenews/3954773-the-hills-1230-report-lawmakers-flock-back-to-capitol-hill/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 16:30:00+00:00

To view past editions of The Hill's 12:30 Report, click here: https://bit.ly/41ZMHnw  To receive The Hill's 12:30 Report in your inbox, please sign up here: https://bit.ly/3qmIoS9  --&#62; A midday take on what's happening in politics and how to have a sense of humor about it.*  *Ha. Haha. Hahah. Sniff. Haha. Sniff. Ha--breaks down crying hysterically. TALK OF THE MORNING  ...

## White House warns Biden would veto GOP's trans sports ban
 - [https://thehill.com/homenews/administration/3954842-white-house-warns-biden-would-veto-gops-trans-sports-ban/](https://thehill.com/homenews/administration/3954842-white-house-warns-biden-would-veto-gops-trans-sports-ban/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 16:18:03+00:00

President Biden would veto legislation to bar transgender women and girls from competing on female sports teams if it reaches his desk, the White House warned Monday, denouncing House Republicans' bill as “unnecessary” and discriminatory. “If the President were presented with H.R. 734, he would veto it,” the White House said Monday in a Statement of...

## The Republican Party is working tirelessly to blow the 2024 election
 - [https://thehill.com/opinion/campaign/3952384-the-republican-party-is-working-tirelessly-to-blow-the-2024-election/](https://thehill.com/opinion/campaign/3952384-the-republican-party-is-working-tirelessly-to-blow-the-2024-election/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 16:00:00+00:00

The Republican Party may see a wave coming but has painted itself in a MAGA corner from which it can’t escape in time.

## When can we stop punishing those who keep the Sabbath?
 - [https://thehill.com/opinion/civil-rights/3954728-when-can-we-stop-punishing-those-who-keep-the-sabbath/](https://thehill.com/opinion/civil-rights/3954728-when-can-we-stop-punishing-those-who-keep-the-sabbath/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 16:00:00+00:00

The Supreme Court is poised to correct an old error that has hurt religious workers for decades by depriving them of their civil rights.

## 10 models qualify for full revamped EV tax credit under Democrats’ climate law
 - [https://thehill.com/policy/energy-environment/3954747-10-models-qualify-for-full-revamped-ev-tax-credit-under-democrats-climate-law/](https://thehill.com/policy/energy-environment/3954747-10-models-qualify-for-full-revamped-ev-tax-credit-under-democrats-climate-law/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 15:47:03+00:00

Ten car models qualify for full electric vehicle tax credits for consumers under the Democrats’ Inflation Reduction Act, according to a list released on Monday.  The climate, tax and healthcare law lifted a cap on how many vehicles can qualify for the EV tax credits, but also added new stipulations on which vehicles qualify.  For...

## Air National Guardsman faces charges after applying to RentAHitman.com, feds say
 - [https://thehill.com/homenews/state-watch/3954737-air-national-guardsman-faces-charges-after-applying-to-rentahitman-com-feds-say/](https://thehill.com/homenews/state-watch/3954737-air-national-guardsman-faces-charges-after-applying-to-rentahitman-com-feds-say/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 15:39:45+00:00

A 21-year-old Air National Guardsman faces federal charges after being arrested in connection with a murder-for-hire scheme. Josiah Ernesto Garcia, 21, of Hermitage, Tennessee, was charged last week with the use of interstate facilities in the commission of murder-for-hire, according to federal authorities. The charges were filed after Garcia allegedly attempted to find work as...

## GOP mega donor says Clarence Thomas is victim of 'political hit job'
 - [https://thehill.com/blogs/blog-briefing-room/3954678-gop-mega-donor-says-clarence-thomas-is-victim-of-political-hit-job/](https://thehill.com/blogs/blog-briefing-room/3954678-gop-mega-donor-says-clarence-thomas-is-victim-of-political-hit-job/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 15:38:43+00:00

Republican billionaire Harlan Crow says his friend Clarence Thomas is the victim of a “political hit job” amid outrage over reports that the Supreme Court justice failed to disclose various luxury vacations Crow paid for, as well as a real estate deal.  “I think it’s a political hit job,” Crow said in an interview with...

## US ambassador visits WSJ reporter jailed in Russia, urges release
 - [https://thehill.com/policy/international/3954723-us-ambassador-visits-wsj-reporter-jailed-in-russia-urges-release/](https://thehill.com/policy/international/3954723-us-ambassador-visits-wsj-reporter-jailed-in-russia-urges-release/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 15:37:05+00:00

The United States' ambassador to Russia has visited detained Wall Street Journal reporter Evan Gershkovich, the diplomat announced Monday, the first time a U.S. official has been able to access him since his arrest last month. “He is in good health and remains strong. We reiterate our call for his immediate release,” Ambassador Lynne Tracy...

## The Supreme Court can restore religious liberty in the workplace
 - [https://thehill.com/opinion/judiciary/3946940-the-supreme-court-can-restore-religious-liberty-in-the-workplace/](https://thehill.com/opinion/judiciary/3946940-the-supreme-court-can-restore-religious-liberty-in-the-workplace/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 15:30:00+00:00

Forty-five years ago, writing in dissent in Trans World Airlines v. Hardison, Supreme Court Justice Thurgood Marshall said, “The ultimate tragedy is that despite Congress’ best efforts, one of this Nation’s pillars of strength — our hospitality to religious diversity — has been seriously eroded. All Americans will be a little poorer until today’s decision...

## Victims identified in Alabama birthday party shooting that killed 4, injured 28
 - [https://thehill.com/homenews/state-watch/3954716-victims-identified-in-alabama-birthday-party-shooting-that-killed-4-injured-28/](https://thehill.com/homenews/state-watch/3954716-victims-identified-in-alabama-birthday-party-shooting-that-killed-4-injured-28/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 15:29:14+00:00

Alabama officials continued investigating a weekend shooting that killed four and injured 28 at a teenager's birthday party.

## McCarthy slams Biden, makes case for GOP moving on debt ceiling 'in the coming weeks'
 - [https://thehill.com/business/budget/3954654-mccarthy-looks-to-dial-up-pressure-on-biden-says-gop-will-move-on-debt-ceiling-in-the-coming-weeks/](https://thehill.com/business/budget/3954654-mccarthy-looks-to-dial-up-pressure-on-biden-says-gop-will-move-on-debt-ceiling-in-the-coming-weeks/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 15:13:36+00:00

Speaker Kevin McCarthy (R-Calif.) on Monday took his case for spending cuts to Wall Street, going after President Biden and detailing the House Republican Conference's plan to move forward with its own measure “in the coming weeks” to stave off a national default. “In the coming weeks, the House will vote on a bill to...

## Senior ISIS leader suspected killed in US raid
 - [https://thehill.com/policy/defense/3954639-senior-isis-leader-suspected-killed-in-us-raid/](https://thehill.com/policy/defense/3954639-senior-isis-leader-suspected-killed-in-us-raid/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 15:01:29+00:00

U.S. forces believe they killed a senior Islamic State leader on Monday in an early morning helicopter raid in northern Syria, according to U.S. Central Command.     The raid sought the senior ISIS Syria leader, an unnamed operational planner responsible for orchestrating attacks in the Middle East and Europe, in a raid that “resulted in the probable...

## Biden’s economy is stuck between a rock and a hard place
 - [https://thehill.com/opinion/white-house/3954460-bidens-economy-is-stuck-between-a-rock-and-a-hard-place/](https://thehill.com/opinion/white-house/3954460-bidens-economy-is-stuck-between-a-rock-and-a-hard-place/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 15:00:00+00:00

How he handles this moment will define his presidency, and determine whether or not he sees a second term in the White House.

## Blackburn says she won't go along with plan to replace Feinstein on Judiciary panel
 - [https://thehill.com/homenews/senate/3954648-blackburn-says-she-wont-go-along-with-plan-to-replace-feinstein-on-judiciary-panel/](https://thehill.com/homenews/senate/3954648-blackburn-says-she-wont-go-along-with-plan-to-replace-feinstein-on-judiciary-panel/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 14:58:40+00:00

Sen. Marsha Blackburn (R-Tenn.) said she would not support a move by Senate Democrats to temporarily replace Sen. Dianne Feinstein (D-Calif.) on the Senate Judiciary Committee, arguing such a move would help Democrats “pack the court with activist judges.” “I will not go along with Chuck Schumer’s plan to replace Senator Feinstein on the Judiciary...

## Republicans call for TikTok ban in House, Senate
 - [https://thehill.com/homenews/house/3954599-republicans-call-for-tiktok-ban-in-house-senate/](https://thehill.com/homenews/house/3954599-republicans-call-for-tiktok-ban-in-house-senate/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 14:40:08+00:00

A group of Republicans are calling on House and Senate leaders to bar lawmakers from using TikTok amid a raging the debate over whether to ban the social media platform at the federal level. “We urge you to amend the House and Senate rules to bar members of Congress from continued use of TikTok and...

## Fox News-Dominion trial delayed amid last-minute settlement push: reports
 - [https://thehill.com/homenews/media/3954585-fox-news-dominion-trial-delayed-amid-last-minute-settlement-push-reports/](https://thehill.com/homenews/media/3954585-fox-news-dominion-trial-delayed-amid-last-minute-settlement-push-reports/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 14:38:35+00:00

Wilmington, Del. — This week's blockbuster trial in Dominion Voting Systems defamation lawsuit against Fox News was delayed by 24 hours, reportedly due to ongoing settlement talks. Superior Court Judge Eric Davis said in a statement late Sunday evening, just hours before opening arguments in the case were slated to begin, that he would delay the start...

## Trump picks two more endorsements from Senate Republicans
 - [https://thehill.com/homenews/campaign/3954517-trump-picks-two-more-endorsements-from-senate-republicans/](https://thehill.com/homenews/campaign/3954517-trump-picks-two-more-endorsements-from-senate-republicans/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 14:27:58+00:00

Former President Trump has picked up two more endorsements from Tennessee’s Republican senators as he campaigns to reclaim the White House in 2024.  “It is my honor to give my whole-hearted endorsement to Donald J. Trump to be the next President of the United States,” Sen. Bill Hagerty (R-Tenn.) said on Twitter.  The senator said...

## Navy sends warship through Taiwan Strait after Chinese exercise around Taiwan
 - [https://thehill.com/policy/defense/3954523-navy-sends-warship-through-taiwan-strait-after-chinese-exercise-around-taiwan/](https://thehill.com/policy/defense/3954523-navy-sends-warship-through-taiwan-strait-after-chinese-exercise-around-taiwan/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 14:24:10+00:00

The U.S. Navy sailed through international waters in the Taiwan Strait on Sunday with a destroyer ship, leading China to denounce the move as a threat to its national security. The USS Milius transited a part of the Taiwan Strait "beyond the territorial sea of any coastal state," according to the U.S. 7th Fleet. "Milius’...

## GOP mega-donor pauses plans to back DeSantis over social issues
 - [https://thehill.com/homenews/campaign/3954522-gop-mega-donor-pauses-plans-to-back-desantis-over-social-issues/](https://thehill.com/homenews/campaign/3954522-gop-mega-donor-pauses-plans-to-back-desantis-over-social-issues/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 14:22:20+00:00

A top Republican mega-donor says he is holding off on financially backing Florida Gov. Ron DeSantis (R) ahead of his widely expected presidential bid, citing his policies on a number of social issues in the state. “Because of his stance on abortion and book banning . . . myself, and a bunch of friends, are holding our powder dry,”...

## Google CEO says AI will impact 'every product of every company,' calls for regs
 - [https://thehill.com/policy/technology/3954570-google-ceo-says-ai-will-impact-every-product-of-every-company-calls-for-regs/](https://thehill.com/policy/technology/3954570-google-ceo-says-ai-will-impact-every-product-of-every-company-calls-for-regs/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 14:20:54+00:00

Google CEO Sundar Pichai on Sunday called for AI regulations and guidelines to ensure the breakthrough technology is “aligned to human values.”  AI will soon impact "every product of every company" and disrupt jobs, Pichai said during an interview with CBS’s “60 Minutes.” He said that writers, accountants, architects, software engineers and other “knowledge workers”...

## Attorney Ben Crump retained by family of Black teen shot for going to wrong house
 - [https://thehill.com/homenews/state-watch/3954571-attorney-ben-crump-retained-by-family-of-black-teen-shot-for-going-to-wrong-house/](https://thehill.com/homenews/state-watch/3954571-attorney-ben-crump-retained-by-family-of-black-teen-shot-for-going-to-wrong-house/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 14:19:28+00:00

Prominent civil rights attorney Ben Crump has been retained by the family of a Black 16-year-old boy who was shot by a white homeowner for appearing at the wrong address last week.  Crump announced on Sunday that the family of Ralph Paul Yarl, a high school junior in Kansas City, Mo., retained his offices after...

## SpaceX stands down from Starship test flight
 - [https://thehill.com/homenews/space/3954556-spacex-delays-starship-test-flight/](https://thehill.com/homenews/space/3954556-spacex-delays-starship-test-flight/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 14:11:49+00:00

SpaceX will have to wait another day to launch its massive Starship rocket. During the launch countdown, the team detected a pressurization issue in the rocket's first stage.  SpaceX decided to pivot during the countdown and treat this as another wet dress rehearsal, opting to scrub the launch and try to fly again another day....

## Dozens of countries rip Russia over reporter's detention
 - [https://thehill.com/policy/international/3954559-dozens-of-countries-rip-russia-over-reporters-detention/](https://thehill.com/policy/international/3954559-dozens-of-countries-rip-russia-over-reporters-detention/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 14:10:35+00:00

Dozens of nations have signed onto a statement protesting Russia’s detention of Wall Street Journal reporter Evan Gershkovich, who Moscow has accused of spying. "We urge Russian Federation authorities to release those they hold on political grounds, and to end the draconian crackdown on freedom of expression, including against members of the media," the statement...

## Stalled in Ukraine, the Kremlin increasingly turns to political theater
 - [https://thehill.com/opinion/international/3952355-stalled-in-ukraine-the-kremlin-increasingly-turns-to-political-theater/](https://thehill.com/opinion/international/3952355-stalled-in-ukraine-the-kremlin-increasingly-turns-to-political-theater/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 14:00:00+00:00

Kremlin propaganda aims at eroding Western will while preparing Russians for the pain of a protracted conflict.

## Watch live: McCarthy delivers remarks from the New York Stock Exchange
 - [https://thehill.com/homenews/3954499-watch-live-mccarthy-delivers-remarks-from-the-new-york-stock-exchange/](https://thehill.com/homenews/3954499-watch-live-mccarthy-delivers-remarks-from-the-new-york-stock-exchange/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 14:00:00+00:00

House Speaker Kevin McCarthy (R-Calif.) is giving a speech at the New York Stock Exchange Monday morning, following a two-week Congressional recess, with an unresolved intra-party dispute on a budget proposal set to resume. McCarthy is expected to outline the Republican caucus’s position that the debt ceiling will not be raised unless the final budget...

## I consider Clarence Thomas a friend, and I’m shocked by recent reports
 - [https://thehill.com/opinion/columnists/3954416-i-consider-clarence-thomas-a-friend-and-im-shocked-by-recent-reports/](https://thehill.com/opinion/columnists/3954416-i-consider-clarence-thomas-a-friend-and-im-shocked-by-recent-reports/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 13:30:00+00:00

The real problem is that none of us can ever again get away from wondering.

## Slightly fewer Americans concerned about multiple environmental problems: Gallup
 - [https://thehill.com/policy/energy-environment/3954483-slightly-fewer-americans-concerned-about-multiple-environmental-problems-gallup/](https://thehill.com/policy/energy-environment/3954483-slightly-fewer-americans-concerned-about-multiple-environmental-problems-gallup/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 13:04:05+00:00

Fewer Americans in a new poll are concerned about multiple environmental problems, with small declines seen in reported worries since last year.  The Gallup poll found that 55 percent of Americans say they have a “great deal” of worry about the pollution of drinking water in the U.S., down from 57 percent last year.  Fifty...

## Impossible and possible solutions to the Russo-Ukrainian War
 - [https://thehill.com/opinion/international/3943927-impossible-and-possible-solutions-to-the-russo-ukrainian-war/](https://thehill.com/opinion/international/3943927-impossible-and-possible-solutions-to-the-russo-ukrainian-war/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 13:00:00+00:00

Everyone wants the Russo-Ukrainian War to end, but exactly how peace is to be achieved is rather less clear. Easy solutions rest on unrealistic assumptions and are impossible, while difficult solutions rest on realistic assumptions and are possible. Understandably, the former are more appealing, because they promise fabulous results with little effort. There are two...

## David's Bridal files for bankruptcy
 - [https://thehill.com/homenews/3954472-davids-bridal-files-for-bankruptcy/](https://thehill.com/homenews/3954472-davids-bridal-files-for-bankruptcy/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 12:56:49+00:00

David's Bridal has filed for Chapter 11 bankruptcy, according to the Wall Street Journal.

## G-7 members vow tough position on China, North Korea and Russia aggression
 - [https://thehill.com/policy/international/3954461-g-7-members-vow-tough-position-on-china-north-korea-and-russia-aggression/](https://thehill.com/policy/international/3954461-g-7-members-vow-tough-position-on-china-north-korea-and-russia-aggression/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 12:49:18+00:00

Members of the Group of Seven have promised to take a tough position on Russia’s invasion of Ukraine, China’s aggression toward Taiwan and North Korea’s missile tests. Top G-7 diplomats representing the world’s wealthiest economies — the U.S., the United Kingdom, Canada, France, Germany, Italy, Japan and the European Union — on Monday talked over...

## National Guard member accused of applying to work as hitman on website
 - [https://thehill.com/homenews/3954451-national-guard-member-accused-of-applying-to-work-as-hitman-on-website/](https://thehill.com/homenews/3954451-national-guard-member-accused-of-applying-to-work-as-hitman-on-website/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 12:41:49+00:00

A National Guard member in Tennessee who is accused of sending his resume to a website called Rent-A-Hitman is facing federal charges.

## The China paradox
 - [https://thehill.com/opinion/international/3953685-the-china-paradox/](https://thehill.com/opinion/international/3953685-the-china-paradox/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 12:30:00+00:00

Resolving the China paradox will not resolve all the tensions. But failing to understand this paradox will not lead to a happy outcome.

## US calls for ceasefire in Sudan
 - [https://thehill.com/policy/international/3954396-us-calls-for-ceasefire-in-sudan/](https://thehill.com/policy/international/3954396-us-calls-for-ceasefire-in-sudan/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 12:10:09+00:00

U.S. Secretary of State Antony Blinken is calling for a ceasefire in Sudan amid days of fighting as the army and a rival force battle for control of the country. “There is a shared deep concern about the fighting, the violence that’s going on in Sudan; the threat that that poses to civilians, that it...

## 10 key questions for this week’s historic UFO hearing
 - [https://thehill.com/opinion/national-security/3953558-10-key-questions-for-this-weeks-historic-ufo-hearing/](https://thehill.com/opinion/national-security/3953558-10-key-questions-for-this-weeks-historic-ufo-hearing/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 12:00:00+00:00

In 1953, Cold War fears led the U.S. government to adopt a semi-official policy of “debunking” all UAP reports, no matter how credible. Trust in government plummeted.

## Alabama authorities ask for community's help after mass shooting kills 4
 - [https://thehill.com/homenews/state-watch/3954382-alabama-authorities-ask-for-communitys-help-after-mass-shooting-kills-4/](https://thehill.com/homenews/state-watch/3954382-alabama-authorities-ask-for-communitys-help-after-mass-shooting-kills-4/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 11:38:37+00:00

Alabama authorities are asking for the community’s help as they search for answers surrounding a mass shooting that killed four people and injured more than two dozen others at a birthday party in the city of Dadeville.   “We’ve got to have information from the community,” Sgt. Jeremy Burkett of the Alabama Law Enforcement Agency said...

## The truth about NPR's funding — and its possible future
 - [https://thehill.com/opinion/campaign/3950550-the-truth-about-nprs-funding-and-its-possible-future/](https://thehill.com/opinion/campaign/3950550-the-truth-about-nprs-funding-and-its-possible-future/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 11:30:00+00:00

It was tendentious — and inaccurate — for Elon Musk to identify NPR on his Twitter platform as a “government-affiliated” news organization. NPR may have its biases, notably in its story selection, but to class it in the same category as the New China News Agency or, in their day, Pravda or Tass, is both...

## Home equity theft: Can the government take more than it's owed?
 - [https://thehill.com/opinion/judiciary/3951453-home-equity-theft-can-the-government-take-more-than-its-owed/](https://thehill.com/opinion/judiciary/3951453-home-equity-theft-can-the-government-take-more-than-its-owed/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 11:00:00+00:00

If you owe the government $100 in property taxes, should they be able to take thousands or even hundreds of thousands more than what you owe?  That’s the essence of Tyler v. Hennepin County, a case that will be argued before the Supreme Court on April 26. The case concerns Geraldine Tyler, a 94-year-old grandmother...

## The Hill's Morning Report — McCarthy to spotlight debt ceiling on Wall St. today
 - [https://thehill.com/newsletters/morning-report/3954354-the-hills-morning-report-mccarthy-to-spotlight-debt-ceiling-on-wall-st-today/](https://thehill.com/newsletters/morning-report/3954354-the-hills-morning-report-mccarthy-to-spotlight-debt-ceiling-on-wall-st-today/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 10:20:00+00:00

Editor’s note: The Hill’s Morning Report is our daily newsletter that dives deep into Washington’s agenda. To subscribe, click here or fill out the box below. Three months into a year of conservative House dominance and many budget promises, the GOP still has no consensus spending blueprint to wield against Democrats and President Biden. It’s...

## Part of Nashville Airport evacuated due to 'noxious odor'
 - [https://thehill.com/homenews/3953954-part-of-nashville-airport-evacuated-due-to-noxious-odor/](https://thehill.com/homenews/3953954-part-of-nashville-airport-evacuated-due-to-noxious-odor/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 10:01:37+00:00

"Something airborne" caused part of Nashville International Airport to be evacuated Sunday afternoon.

## Netflix won't air 'Love Is Blind' event live after technical errors
 - [https://thehill.com/homenews/3954030-netflix-wont-air-love-is-blind-event-live-after-technical-errors/](https://thehill.com/homenews/3954030-netflix-wont-air-love-is-blind-event-live-after-technical-errors/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 10:01:03+00:00

Many Netflix users hoping to tune in to a live event Sunday night were met with an unfortunate message: "We're having trouble playting this title right now."

## A free market no more? Rules of the game have changed after banking crisis, some say
 - [https://thehill.com/business/3951264-a-free-market-no-more-rules-of-the-game-have-changed-after-banking-crisis-some-say/](https://thehill.com/business/3951264-a-free-market-no-more-rules-of-the-game-have-changed-after-banking-crisis-some-say/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 10:00:00+00:00

Following the latest rescues of big banks at the same time the Federal Reserve is warning of a recession that could put more than a million Americans out of work, economists, historians and market commentators are drawing comparisons to previous eras of global capitalism when the government and the banking sector were more officially entwined....

## Debt ceiling, abortion ruling, 2024: Congress faces questions upon return to Washington
 - [https://thehill.com/homenews/house/3954155-debt-ceiling-abortion-ruling-2024-congress-faces-questions-upon-return-to-washington/](https://thehill.com/homenews/house/3954155-debt-ceiling-abortion-ruling-2024-congress-faces-questions-upon-return-to-washington/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 10:00:00+00:00

House and Senate lawmakers will face questions on a number of high-stakes matters as they return to Washington on Monday after a two-week recess. The looming debt ceiling deadline, a legal battle over a widely used abortion pill and the Republican 2024 presidential field will all dominate Capitol Hill this week, as lawmakers react to...

## Democratic senators favor forcing House vote on debt limit increase
 - [https://thehill.com/homenews/senate/3951451-democratic-senators-favor-forcing-house-vote-on-debt-limit-increase/](https://thehill.com/homenews/senate/3951451-democratic-senators-favor-forcing-house-vote-on-debt-limit-increase/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 10:00:00+00:00

Democratic senators are getting antsy over the lack of progress on legislation to avoid a national default and want House Democrats to begin working on a plan to force Republicans to vote on a bill to raise the debt limit.   Democratic senators want to avoid a summer standoff on extending the nation’s borrowing authority,...

## Democrats seek negotiating advantage in GOP budget turmoil
 - [https://thehill.com/business/budget/3951448-democrats-seek-negotiating-advantage-in-gop-budget-turmoil/](https://thehill.com/business/budget/3951448-democrats-seek-negotiating-advantage-in-gop-budget-turmoil/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 10:00:00+00:00

House Democrats are hoping Republicans’ internal clashes over the size and substance of their budget-cutting plans will lend President Biden a tactical boost in the looming fights over the debt ceiling and government spending. Speaker Kevin McCarthy (R-Calif.) has, for months, demanded that Biden negotiate steep spending cuts and other policy concessions as a condition...

## Google working on dramatic search changes to counter AI rivals: report
 - [https://thehill.com/policy/technology/3954070-google-working-on-dramatic-search-changes-to-counter-ai-rivals-report/](https://thehill.com/policy/technology/3954070-google-working-on-dramatic-search-changes-to-counter-ai-rivals-report/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 01:20:00+00:00

Google is working on search changes to counter artificial intelligence (AI) rivals that pose a threat to the company's search engine, The New York Times reported. The Times reported that Samsung was considering using Microsoft's Bing instead of Google as its default search engine on its devices. This news comes after Microsoft announced plans to...

## Kennedy family backing Biden over their own in 2024 Dem primary: report
 - [https://thehill.com/homenews/campaign/3953994-kennedy-family-backing-biden-over-their-own-in-2024-dem-primary-report/](https://thehill.com/homenews/campaign/3953994-kennedy-family-backing-biden-over-their-own-in-2024-dem-primary-report/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 00:53:38+00:00

The Kennedy family is reportedly backing President Biden over their own family member in the 2024 Democrat primary, CNN reported. Multiple Kennedy family members signaled that they would not back Robert F. Kennedy Jr. in his bid for the Democrat nominee for president, according to interviews with CNN. Robert F. Kennedy Jr., a longtime anti-vaccine...

## Judge delays Fox News vs. Dominion trial by one day
 - [https://thehill.com/homenews/3954046-judge-delays-fox-news-vs-dominion-trial-by-one-day/](https://thehill.com/homenews/3954046-judge-delays-fox-news-vs-dominion-trial-by-one-day/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 00:38:48+00:00

A judge in Delaware said late Sunday he would delay by 24 hours the beginning of a blockbuster trial in Dominion Voting Systems' defamation lawsuit against Fox News. “The Court has decided to continue the start of the trial, including jury selection, until Tuesday, April 18, 2023 at 9:00 a.m.," Superior Court Judge Eric Davis...

## Marjorie Taylor Greene fires back at Lindsey Graham by posting Photoshopped pic of senator hoisting a Bud Light with trans influencer’s image
 - [https://thehill.com/homenews/3953968-marjorie-taylor-greene-fires-back-at-lindsey-graham-by-posting-photoshopped-pic-of-senator-hoisting-a-bud-light-with-trans-influencers-image/](https://thehill.com/homenews/3953968-marjorie-taylor-greene-fires-back-at-lindsey-graham-by-posting-photoshopped-pic-of-senator-hoisting-a-bud-light-with-trans-influencers-image/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 00:12:20+00:00

Rep. Marjorie Taylor Greene (R-Ga.) appeared to fire back at Sen. Lindsey Graham (R-S.C.) for criticizing her defense of the alleged Pentagon document leaker on Sunday by posting a photoshopped image of Graham holding a Bud Light can sporting the image of a trans social media influencer. Graham earlier on Sunday slammed Greene's Thursday tweet about Jake Teixeira,...

## Elon Musk claims the US government had ‘full access’ to private Twitter DMs
 - [https://thehill.com/homenews/3953995-elon-musk-claims-the-us-government-had-full-access-to-private-twitter-dms/](https://thehill.com/homenews/3953995-elon-musk-claims-the-us-government-had-full-access-to-private-twitter-dms/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-04-17 00:11:33+00:00

Twitter CEO Elon Musk claimed in an interview that the U.S. government has “full access” to users’ private direct messages, saying knowing that information blew his mind.  In an excerpt of his Fox News interview with host Tucker Carlson, Musk told Carlson that he was shocked to find out about the government’s ability to read...

