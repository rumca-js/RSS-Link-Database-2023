# Source:ABC News, URL:http://feeds.abcnews.com/abcnews/topstories, language:en-US

## Ben & Jerry's workers announce plan to unionize in Vermont
 - [https://abcnews.go.com/US/wireStory/ben-jerrys-workers-announce-plan-unionize-vermont-98646716](https://abcnews.go.com/US/wireStory/ben-jerrys-workers-announce-plan-unionize-vermont-98646716)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-04-17 23:36:53+00:00

About 40 workers at the Ben &amp; Jerry&rsquo;s ice cream shop in the Vermont city where the company was founded have announced that they plan to form a union

## NY woman driven to wrong address fatally shot by homeowner
 - [https://abcnews.go.com/US/wireStory/ny-woman-driven-wrong-address-fatally-shot-homeowner-98645999](https://abcnews.go.com/US/wireStory/ny-woman-driven-wrong-address-fatally-shot-homeowner-98645999)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-04-17 23:36:29+00:00

Authorities say a 20-year-old woman on her way to a friend&rsquo;s house in upstate New York was driven to the wrong address and quickly shot to death by the homeowner

## Families displaced from California neighborhood seek $2B
 - [https://abcnews.go.com/US/wireStory/families-displaced-california-neighborhood-seek-2b-98643737](https://abcnews.go.com/US/wireStory/families-displaced-california-neighborhood-seek-2b-98643737)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-04-17 23:32:50+00:00

Black and Latino Californians who were displaced from a neighborhood in Palm Springs are seeking $2.3 billion in compensation from the city

## Prosecutor files 2 felony charges against suspect in Ralph Yarl shooting
 - [https://abcnews.go.com/US/suspect-charged-ralph-yarl-shooting/story?id=98643347](https://abcnews.go.com/US/suspect-charged-ralph-yarl-shooting/story?id=98643347)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-04-17 22:36:41+00:00

The Clay County Prosecutor's Office said it filed two criminal charges against a suspect in the April 13 shooting of 16-year-old Ralph Yarl.

## 3 missing sailors likely encountered 20-foot seas near Mexico: Coast Guard commander
 - [https://abcnews.go.com/US/3-missing-sailors-encountered-20-foot-seas-mexico/story?id=98631258](https://abcnews.go.com/US/3-missing-sailors-encountered-20-foot-seas-mexico/story?id=98631258)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-04-17 20:38:45+00:00

Three Americans missing off the coast of Mexico likely encountered "significant" weather and waves as they attempted to sail their 41-foot sailboat to San Diego.

## Manhattan DA asks judge to look into Trump attorney's potential conflict of interest
 - [https://abcnews.go.com/US/manhattan-da-asks-judge-trump-attorneys-potential-conflict/story?id=98643960](https://abcnews.go.com/US/manhattan-da-asks-judge-trump-attorneys-potential-conflict/story?id=98643960)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-04-17 20:34:51+00:00

Prosecutors have asked a judge in former President Trump's criminal case to look further into a potential conflict of interest on the part of Trump lawyer Joe Tacopina.

## WATCH:  Italian police find 2 tons of cocaine at sea
 - [https://abcnews.go.com/International/video/italian-police-find-2-tons-cocaine-sea-98645800](https://abcnews.go.com/International/video/italian-police-find-2-tons-cocaine-sea-98645800)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-04-17 20:13:31+00:00

Police in Italy found over 2 tons of cocaine with a market value of more than 400 million euros ($439 million) off the eastern coast of Sicily.

## WATCH:  Pizza delivery driver stops suspect from fleeing police
 - [https://abcnews.go.com/US/video/pizza-delivery-driver-stops-suspect-fleeing-police-98645738](https://abcnews.go.com/US/video/pizza-delivery-driver-stops-suspect-fleeing-police-98645738)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-04-17 20:12:11+00:00

A pizza delivery driver's quick thinking ended a high-speed chase in Pennsylvania.

## Officers will not face state charges in Jayland Walker police shooting
 - [https://abcnews.go.com/US/officers-face-state-charges-jayland-walker-police-shooting/story?id=98502782](https://abcnews.go.com/US/officers-face-state-charges-jayland-walker-police-shooting/story?id=98502782)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-04-17 19:57:26+00:00

A grand jury has decided not to indict officers on state criminal charges involved in the death of Jayland Walker.

## Santos announces reelection bid amid multiple scandals
 - [https://abcnews.go.com/Politics/santos-announces-reelection-bid-amid-multiple-scandals/story?id=98643808](https://abcnews.go.com/Politics/santos-announces-reelection-bid-amid-multiple-scandals/story?id=98643808)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-04-17 19:28:33+00:00

Embattled Rep. George Santos, R-N.Y., launched his reelection bid Monday despite being mired in several scandals.

## Boy, 13, gets stuck climbing into claw machine for prize
 - [https://abcnews.go.com/US/wireStory/boy-13-gets-stuck-climbing-claw-machine-prize-98641983](https://abcnews.go.com/US/wireStory/boy-13-gets-stuck-climbing-claw-machine-prize-98641983)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-04-17 19:01:55+00:00

An official says a 13-year-old boy had to be freed from a claw machine after he climbed inside hoping to score a prize at a North Carolina amusement park south of Charlotte

## Report: Serial rapist sentenced to more than 150 years
 - [https://abcnews.go.com/US/wireStory/report-serial-rapist-sentenced-150-years-98640840](https://abcnews.go.com/US/wireStory/report-serial-rapist-sentenced-150-years-98640840)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-04-17 18:56:44+00:00

A television station is reporting that a convicted serial rapist has been sentenced to more than 150 years in prison

## Supreme Court to deliver answer in religious mailman's case
 - [https://abcnews.go.com/US/wireStory/supreme-court-deliver-answer-religious-mailmans-case-98639618](https://abcnews.go.com/US/wireStory/supreme-court-deliver-answer-religious-mailmans-case-98639618)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-04-17 17:33:43+00:00

A religious mail carrier refused to deliver Amazon packages on Sundays.

## DOJ accuses China of using 'police station' to spy on, harass dissidents inside US
 - [https://abcnews.go.com/Politics/doj-accuses-china-spying-harassing-dissidents-inside-us/story?id=98635039](https://abcnews.go.com/Politics/doj-accuses-china-spying-harassing-dissidents-inside-us/story?id=98635039)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-04-17 17:33:10+00:00

One case involves Chinese security officials spying Zoom calls, sources said.

## Ex-Cardinal McCarrick charged in Wisconsin with sex abuse
 - [https://abcnews.go.com/US/wireStory/cardinal-mccarrick-charged-wisconsin-sex-abuse-98639243](https://abcnews.go.com/US/wireStory/cardinal-mccarrick-charged-wisconsin-sex-abuse-98639243)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-04-17 16:53:48+00:00

Defrocked Roman Catholic cardinal became the face of the clergy sex abuse crisis

## Judge denies Trump's request for delay in E. Jean Carroll defamation, battery trial
 - [https://abcnews.go.com/US/judge-denies-trumps-request-delay-jean-carroll-defamation/story?id=98635729](https://abcnews.go.com/US/judge-denies-trumps-request-delay-jean-carroll-defamation/story?id=98635729)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-04-17 16:31:43+00:00

A federal judge has denied former President Trump's latest attempt to delay the trial in the defamation and battery case brought by former Elle columnist E. Jean Carroll.

## EU investigates after 3 countries ban Ukraine grain imports
 - [https://abcnews.go.com/International/wireStory/eu-investigates-after-3-countries-ban-ukraine-grain-98634800](https://abcnews.go.com/International/wireStory/eu-investigates-after-3-countries-ban-ukraine-grain-98634800)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-04-17 15:32:22+00:00

Slovakia is the third European Union country to ban food imports from Ukraine.

## Longtime New Yorker cartoonist Edward Koren dies
 - [https://abcnews.go.com/Entertainment/wireStory/longtime-new-yorker-cartoonist-edward-koren-dies-98635803](https://abcnews.go.com/Entertainment/wireStory/longtime-new-yorker-cartoonist-edward-koren-dies-98635803)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-04-17 15:29:28+00:00

Koren is known for his hairy, huminoid creatures.

## Chauvin murder conviction upheld in George Floyd killing
 - [https://abcnews.go.com/US/wireStory/chauvin-murder-conviction-upheld-george-floyd-killing-98636395](https://abcnews.go.com/US/wireStory/chauvin-murder-conviction-upheld-george-floyd-killing-98636395)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-04-17 15:26:45+00:00

Minnesota&rsquo;s Court of Appeals upholds Chauvin's second-degree murder conviction.

## South Carolina trooper shot in face during traffic stop
 - [https://abcnews.go.com/US/wireStory/south-carolina-trooper-shot-face-traffic-stop-98634359](https://abcnews.go.com/US/wireStory/south-carolina-trooper-shot-face-traffic-stop-98634359)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-04-17 14:50:06+00:00

The South Carolina trooper had stopped a vehicle for speeding.

## Explosive targeting Japan PM renews worries of homemade arms
 - [https://abcnews.go.com/International/wireStory/explosive-targeting-japan-pm-renews-worry-homemade-arms-98629475](https://abcnews.go.com/International/wireStory/explosive-targeting-japan-pm-renews-worry-homemade-arms-98629475)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-04-17 13:47:18+00:00

Japanese police say they have confiscated metal tubes, tools and possible gunpowder from the home of a man suspected of throwing what was believed to be a homemade pipe bomb at Prime Minister Fumio Kishida at a campaign event

## Fast field departs for start of 127th Boston Marathon
 - [https://abcnews.go.com/Sports/wireStory/fast-field-gathers-start-127th-boston-marathon-98629474](https://abcnews.go.com/Sports/wireStory/fast-field-gathers-start-127th-boston-marathon-98629474)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-04-17 13:47:15+00:00

The fastest and most-decorated field in race history left Hopkinton for the start of the 127th Boston Marathon

## Following delay, judge says Dominion-Fox defamation trial will begin Tuesday
 - [https://abcnews.go.com/US/start-dominion-fox-defamation-trial-delayed-tuesday/story?id=98624770](https://abcnews.go.com/US/start-dominion-fox-defamation-trial-delayed-tuesday/story?id=98624770)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-04-17 13:46:26+00:00

The judge overseeing Dominion Voting Systems' 1.6 billion defamation lawsuit against Fox News said Monday morning that the trial will proceed Tuesday.

## Sudan's civilian death toll nears 100 as fighting intensifies
 - [https://abcnews.go.com/International/sudan-death-toll-rises-fighting-intensifies/story?id=98626877](https://abcnews.go.com/International/sudan-death-toll-rises-fighting-intensifies/story?id=98626877)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-04-17 11:49:25+00:00

Dozens of civilians have died and hundreds have been injured in Sudan as forces loyal to two rival generals battle for control of the resource-rich North African nation.

## WATCH:  Bear family emerges from dumpster
 - [https://abcnews.go.com/US/video/bear-family-emerges-dumpster-98628855](https://abcnews.go.com/US/video/bear-family-emerges-dumpster-98628855)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-04-17 11:34:16+00:00

A Connecticut woman captured adorable footage of a family of bears looking for a snack.

## Russian opposition activist given 25-year prison sentence
 - [https://abcnews.go.com/International/wireStory/russian-opposition-activist-25-year-prison-sentence-98627988](https://abcnews.go.com/International/wireStory/russian-opposition-activist-25-year-prison-sentence-98627988)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-04-17 09:32:16+00:00

A court in Moscow has convicted a top Kremlin foe on charges of treason and denigrating the Russian military and sentenced him to 25 years in prison

## US helicopter raid in Syria targets an Islamic State leader
 - [https://abcnews.go.com/US/wireStory/us-helicopter-raid-syria-targets-islamic-state-leader-98627716](https://abcnews.go.com/US/wireStory/us-helicopter-raid-syria-targets-islamic-state-leader-98627716)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-04-17 09:03:56+00:00

The U.S. military says a helicopter raid by U.S. forces in northern Syria has resulted in the &ldquo;probable death&rdquo; of a senior leader of the militant Islamic State group

## Airbus, Air France face verdict over 2009 Rio-Paris crash
 - [https://abcnews.go.com/International/wireStory/airbus-air-france-face-verdict-2009-rio-paris-98627136](https://abcnews.go.com/International/wireStory/airbus-air-france-face-verdict-2009-rio-paris-98627136)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-04-17 08:02:14+00:00

A French court is ruling Monday on whether Airbus and Air France are guilty of manslaughter over the 2009 crash of Flight 447 en route from Rio to Paris

## Ex-leader Merkel to be decorated with highest German honor
 - [https://abcnews.go.com/International/wireStory/leader-merkel-decorated-highest-german-honor-98627258](https://abcnews.go.com/International/wireStory/leader-merkel-decorated-highest-german-honor-98627258)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-04-17 07:47:11+00:00

Former Chancellor Angela Merkel is to be decorated with Germany&rsquo;s highest possible honor in recognition of her near-record 16 years at the helm of the country

## 6 children rescued near water diversion tunnel in Auburn, Massachusetts
 - [https://abcnews.go.com/US/6-children-rescued-water-diversion-tunnel-auburn-massachusetts/story?id=98627419](https://abcnews.go.com/US/6-children-rescued-water-diversion-tunnel-auburn-massachusetts/story?id=98627419)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-04-17 07:17:54+00:00

Six teenagers were rescued near a diversion water tunnel in Auburn, Massachusetts, after authorities said the group was unable to "make it back to land on their own."

## Clinton, Blair to mark Northern Ireland peace milestone
 - [https://abcnews.go.com/International/wireStory/clinton-blair-mark-northern-ireland-peace-milestone-98627058](https://abcnews.go.com/International/wireStory/clinton-blair-mark-northern-ireland-peace-milestone-98627058)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-04-17 06:53:12+00:00

Former U.S. President Bill Clinton and past leaders of the U.K. and Ireland are gathering in Belfast on Monday, 25 years after their charm, clout and determination helped Northern Ireland strike a historic peace accord

## US tax breaks lure European clean tech companies as EU lags
 - [https://abcnews.go.com/Business/wireStory/us-tax-breaks-lure-european-clean-tech-companies-98627060](https://abcnews.go.com/Business/wireStory/us-tax-breaks-lure-european-clean-tech-companies-98627060)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-04-17 06:51:56+00:00

Norwegian battery startup Freyr is planning its next factory in an Atlanta suburb because a new U.S. clean energy law offers generous tax credits for local production

## Kansas City police: Probe of teen's shooting moving quickly
 - [https://abcnews.go.com/US/wireStory/kansas-city-police-probe-teens-shooting-moving-quickly-98626498](https://abcnews.go.com/US/wireStory/kansas-city-police-probe-teens-shooting-moving-quickly-98626498)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-04-17 05:46:51+00:00

Kansas City police are working to quickly prepare evidence for the Clay County prosecutor in the shooting of a Black teenager while trying to pick up his younger brothers from a friend&rsquo;s house Thursday

## Netflix keeps 'Love Is Blind' fans waiting for live reunion
 - [https://abcnews.go.com/Technology/wireStory/netflix-love-blind-fans-waiting-live-reunion-98625200](https://abcnews.go.com/Technology/wireStory/netflix-love-blind-fans-waiting-live-reunion-98625200)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-04-17 05:15:41+00:00

Love isn&rsquo;t patient, love isn&rsquo;t kind &mdash; at least if you ask the fans of Netflix&rsquo;s &ldquo;Love Is Blind.&rdquo;

## Evacuation order lifted in area near Indiana plastics fire
 - [https://abcnews.go.com/US/wireStory/evacuation-order-lifted-area-indiana-plastics-fire-98623345](https://abcnews.go.com/US/wireStory/evacuation-order-lifted-area-indiana-plastics-fire-98623345)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-04-17 05:10:04+00:00

Authorities in eastern Indiana lifted a dayslong evacuation order Sunday for an area near a plastics fire after they said it was determined air quality and other environmental concerns were safe

## US conducts raid against ISIS fighters in Syria: Official
 - [https://abcnews.go.com/International/us-conducts-raid-isis-fighters-syria-official/story?id=98625209](https://abcnews.go.com/International/us-conducts-raid-isis-fighters-syria-official/story?id=98625209)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-04-17 02:42:54+00:00

U.S. forces conducted a raid against ISIS militants in northwest Syria on Sunday, according to a U.S. official.

## Parts of Upper Midwest bracing for heavy snow, strong winds
 - [https://abcnews.go.com/US/parts-upper-midwest-bracing-heavy-snow-strong-winds/story?id=98620162](https://abcnews.go.com/US/parts-upper-midwest-bracing-heavy-snow-strong-winds/story?id=98620162)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-04-17 02:00:15+00:00

A spring storm moving across the Great Lakes region is set to deliver a blast of snow to parts of the Upper Midwest by Sunday evening.

