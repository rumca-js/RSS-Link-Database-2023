# Source:Valuetainment, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCIHdDJ0tjn_3j-FS7s_X1kQ, language:en-US

## You Just Need One True Believer
 - [https://www.youtube.com/watch?v=HkL5Uzif-6g](https://www.youtube.com/watch?v=HkL5Uzif-6g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIHdDJ0tjn_3j-FS7s_X1kQ
 - date published: 2023-04-17 19:00:06+00:00

#shorts #short #valuetainment #patrickbetdavid

## Warren Buffet Investing Strategy
 - [https://www.youtube.com/watch?v=338GHC0ZGpk](https://www.youtube.com/watch?v=338GHC0ZGpk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIHdDJ0tjn_3j-FS7s_X1kQ
 - date published: 2023-04-17 14:56:11+00:00

#shorts #short #valuetainment #patrickbetdavid

## The Dark Side Of CBDC Explained
 - [https://www.youtube.com/watch?v=EAhuOJ3bo8g](https://www.youtube.com/watch?v=EAhuOJ3bo8g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIHdDJ0tjn_3j-FS7s_X1kQ
 - date published: 2023-04-17 13:00:08+00:00

Do you feel okay being tracked? In this episode, Patrick Bet-David talks about the dark side of CBCD and what you should consider before buying into this concept. 

FaceTime or Ask Patrick any questions on https://minnect.com/

Recommended video: 
Banking Crisis In America - How It Affects YOU: https://youtu.be/cnDkVRJsyPQ

Subscribe to our channel: http://bit.ly/2aPEwD4 

To reach the Valuetainment team, you can email: info@valuetainment.com

## Shaq's Humble Response After Kobe's Statement
 - [https://www.youtube.com/watch?v=ie9cINZu2CQ](https://www.youtube.com/watch?v=ie9cINZu2CQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIHdDJ0tjn_3j-FS7s_X1kQ
 - date published: 2023-04-17 02:43:30+00:00

#shorts #short #valuetainment #patrickbetdavid

