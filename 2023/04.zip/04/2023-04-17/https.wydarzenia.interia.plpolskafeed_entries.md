# Source:Wydarzenia Interia - Polska, URL:https://wydarzenia.interia.pl/polska/feed, language:pl-PL

## Podejrzenie zamachu i zabójstwa. Podkomisja smoleńska złożyła zawiadomienie
 - [https://wydarzenia.interia.pl/kraj/news-podejrzenie-zamachu-i-zabojstwa-podkomisja-smolenska-zlozyla,nId,6722807](https://wydarzenia.interia.pl/kraj/news-podejrzenie-zamachu-i-zabojstwa-podkomisja-smolenska-zlozyla,nId,6722807)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-04-17 15:33:33+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-podejrzenie-zamachu-i-zabojstwa-podkomisja-smolenska-zlozyla,nId,6722807"><img align="left" alt="Podejrzenie zamachu i zabójstwa. Podkomisja smoleńska złożyła zawiadomienie" src="https://i.iplsc.com/podejrzenie-zamachu-i-zabojstwa-podkomisja-smolenska-zlozyla/000H1HIYD26NUBYX-C321.jpg" /></a>Podkomisja smoleńska złożyła zawiadomienie o podejrzeniu popełnienia przestępstwa zamachu na prezydenta Lecha Kaczyńskiego i &quot;usunięcia poprzez zabójstwo&quot; organu konstytucyjnego RP oraz morderstwa 95 innych osób. </p><br clear="all" />

## Zapomniałeś o tym przed majówką? Możesz się pożegnać z wyjazdem
 - [https://wydarzenia.interia.pl/kraj/news-zapomniales-o-tym-przed-majowka-mozesz-sie-pozegnac-z-wyjazd,nId,6719246](https://wydarzenia.interia.pl/kraj/news-zapomniales-o-tym-przed-majowka-mozesz-sie-pozegnac-z-wyjazd,nId,6719246)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-04-17 14:04:41+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-zapomniales-o-tym-przed-majowka-mozesz-sie-pozegnac-z-wyjazd,nId,6719246"><img align="left" alt="Zapomniałeś o tym przed majówką? Możesz się pożegnać z wyjazdem" src="https://i.iplsc.com/zapomniales-o-tym-przed-majowka-mozesz-sie-pozegnac-z-wyjazd/000H14ZJ7RCCRSNW-C321.jpg" /></a>Paszport tymczasowy to dokument przydający się w pilnych sytuacjach, które wymagają wyjazdu za granicę. Często korzystają z niego również osoby niemogące powrócić do kraju. Tak się dzieje, gdy paszport biometryczny stracił ważność, a wyrobienie nowego może zabrać zbyt wiele czasu. Ile jest ważny paszport tymczasowy i jak długo trzeba na niego czekać?</p><br clear="all" />

## Szczecin: Wyrok za zabicie niemowlęcia. Matka trafi do więzienia
 - [https://wydarzenia.interia.pl/zachodniopomorskie/news-szczecin-wyrok-za-zabicie-niemowlecia-matka-trafi-do-wiezien,nId,6722556](https://wydarzenia.interia.pl/zachodniopomorskie/news-szczecin-wyrok-za-zabicie-niemowlecia-matka-trafi-do-wiezien,nId,6722556)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-04-17 10:47:00+00:00

<p><a href="https://wydarzenia.interia.pl/zachodniopomorskie/news-szczecin-wyrok-za-zabicie-niemowlecia-matka-trafi-do-wiezien,nId,6722556"><img align="left" alt="Szczecin: Wyrok za zabicie niemowlęcia. Matka trafi do więzienia  " src="https://i.iplsc.com/szczecin-wyrok-za-zabicie-niemowlecia-matka-trafi-do-wiezien/000GAGRYRSP4JD6U-C321.jpg" /></a>Sześć lat więzienia - taki wyrok usłyszała Patrcyja C. za zabójstwo swojego pięciomiesięcznego syna. Chłopiec został uduszony. W związku z tym, że 26-latka miała znacznie ograniczoną zdolność rozumienia i kierowania swoim postępowaniem w chwili popełnienia zbrodni, sąd zdecydował się nadzwyczajne złagodzenie kary. </p><br clear="all" />

