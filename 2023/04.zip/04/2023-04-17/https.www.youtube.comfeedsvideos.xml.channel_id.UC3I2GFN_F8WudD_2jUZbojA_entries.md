# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Naima Bock  - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=adhJGfpZl9c](https://www.youtube.com/watch?v=adhJGfpZl9c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-04-17 15:00:02+00:00

http://KEXP.ORG presents Naima Bock performing live in the KEXP studio. Recorded March 8, 2023

Songs:
Every Morning
Campervan
The Grey Funnel Line
Lines

Naima Bock - Vocals, Guitar
Oliver Hamilton - Violin
Lewis Maynard - Bass
Holly Witaker - Vocal

Host: Cheryl Waters
Audio Engineers: Kevin Suggs
Audio Mixer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Scott Holpainen

https://www.naimabock.com
http://kexp.org

## Naima Bock - Every Morning (Live on KEXP)
 - [https://www.youtube.com/watch?v=yj1lgBIv4Vo](https://www.youtube.com/watch?v=yj1lgBIv4Vo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-04-17 11:00:47+00:00

http://KEXP.ORG presents Naima Bock performing “Every Morning” live in the KEXP studio. Recorded March 8, 2023

Naima Bock - Vocals, Guitar
Oliver Hamilton - Violin
Lewis Maynard - Bass
Holly Witaker - Vocal

Host: Cheryl Waters
Audio Engineers: Kevin Suggs
Audio Mixer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Scott Holpainen

https://www.naimabock.com
http://kexp.org

## Naima Bock - The Grey Funnel Line (Live on KEXP)
 - [https://www.youtube.com/watch?v=vmhBAgr4bIU](https://www.youtube.com/watch?v=vmhBAgr4bIU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-04-17 11:00:42+00:00

http://KEXP.ORG presents Naima Bock performing “The Grey Funnel Line” live in the KEXP studio. Recorded March 8, 2023

Naima Bock - Vocals, Guitar
Oliver Hamilton - Violin
Lewis Maynard - Bass
Holly Witaker - Vocal

Host: Cheryl Waters
Audio Engineers: Kevin Suggs
Audio Mixer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Scott Holpainen

https://www.naimabock.com
http://kexp.org

## Naima Bock - Lines (Live on KEXP)
 - [https://www.youtube.com/watch?v=D3PdK_J9gE8](https://www.youtube.com/watch?v=D3PdK_J9gE8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-04-17 11:00:12+00:00

http://KEXP.ORG presents Naima Bock performing “Lines” live in the KEXP studio. Recorded March 8, 2023

Naima Bock - Vocals, Guitar
Oliver Hamilton - Violin
Lewis Maynard - Bass
Holly Witaker - Vocal

Host: Cheryl Waters
Audio Engineers: Kevin Suggs
Audio Mixer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Scott Holpainen

https://www.naimabock.com
http://kexp.org

## Naima Bock - Campervan (Live on KEXP)
 - [https://www.youtube.com/watch?v=aFtSQfNxAwE](https://www.youtube.com/watch?v=aFtSQfNxAwE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-04-17 11:00:00+00:00

http://KEXP.ORG presents Naima Bock performing “Campervan” live in the KEXP studio. Recorded March 8, 2023

Naima Bock - Vocals, Guitar
Oliver Hamilton - Violin
Lewis Maynard - Bass
Holly Witaker - Vocal

Host: Cheryl Waters
Audio Engineers: Kevin Suggs
Audio Mixer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Scott Holpainen

https://www.naimabock.com
http://kexp.org

