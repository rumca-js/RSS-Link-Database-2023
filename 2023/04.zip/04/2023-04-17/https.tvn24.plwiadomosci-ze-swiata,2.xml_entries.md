# Source:TVN24 Ze świata, URL:https://tvn24.pl/wiadomosci-ze-swiata,2.xml, language:pl-PL

## Do kiedy trzeba złożyć PIT
 - [https://tvn24.pl/biznes/dla-pracownika/pit-2023-do-kiedy-trzeba-zlozyc-pit-data-6930046?source=rss](https://tvn24.pl/biznes/dla-pracownika/pit-2023-do-kiedy-trzeba-zlozyc-pit-data-6930046?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-04-17 11:59:21+00:00

<img alt="Do kiedy trzeba złożyć PIT" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie105cba469c2d71f39ce4e5819a01f2b6-termin-na-rozliczenie-pit-a-za-2017-rok-mija-30-kwietnia-4562264/alternates/LANDSCAPE_1280" />
    Niedługo mija termin rozliczenia PIT za rok 2022. Zazwyczaj czas na złożenie deklaracji upływa z końcem kwietnia, jednak w tym roku - ponieważ 30 kwietnia to niedziela, a ponadto wolny od pracy jest także poniedziałek 1 maja - czasu na dopełnienie formalności jest nieco więcej. Wyjaśniamy, jaka jest ostateczna data złożenia PIT w 2023 roku.

## Po kolizji auto przewróciło się na bok, na jezdni leżały puszki po piwie. Kierowca był pijany
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-kolizja-w-alei-krakowskiej-kierowca-byl-pijany-6929588?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-kolizja-w-alei-krakowskiej-kierowca-byl-pijany-6929588?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-04-17 09:00:13+00:00

<img alt="Po kolizji auto przewróciło się na bok, na jezdni leżały puszki po piwie. Kierowca był pijany " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-ehq9t8-zdarzenie-w-alei-krakowskiej-6929638/alternates/LANDSCAPE_1280" />
    W poniedziałek w alei Krakowskiej zderzyły się dwa auta osobowe, jedno z nich przewróciło się na bok. Jak poinformowała policja, kierowca był pijany.

