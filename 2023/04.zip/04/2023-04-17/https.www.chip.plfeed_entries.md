# Source:Chip.pl, URL:https://www.chip.pl/feed, language:pl-PL

## Zakupy z OTOMOTO Pay &#8211; bezpiecznie, na raty i z gwarancją
 - [https://www.chip.pl/2023/04/otomoto-pay-finansowanie-zakupu-auta-jak-dziala-gwarancja](https://www.chip.pl/2023/04/otomoto-pay-finansowanie-zakupu-auta-jak-dziala-gwarancja)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-04-17 20:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1477" src="https://konto.chip.pl/wp-content/uploads/2023/04/otomoto-pay-1.jpg" style="margin-bottom: 10px;" width="2216" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/04/otomoto-pay-1.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Serwis OTOMOTO wprowadził niedawno nową usługę OTOMOTO Pay. To ewenement w skali, przynajmniej, Unii Europejskiej oferujący pomoc w finansowaniu zakupu, podnoszący jego bezpieczeństwo i oferujący dodatkową gwarancję nawet na auto używane. O co w tym wszystkim chodzi? Zaraz to wyjaśnimy. Podstawowe pytanie &#8211; czym jest OTOMOTO Pay? OTOMOTO to… nie, nie przesadzajmy. Chyba nie trzeba [&#8230;]</p>

## Zaobserwowali ją wkrótce przed uderzeniem. Asteroida trafiła w Ziemię
 - [https://www.chip.pl/2023/04/asteroida-uderzyla-w-ziemie-obserwacje](https://www.chip.pl/2023/04/asteroida-uderzyla-w-ziemie-obserwacje)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-04-17 19:03:44+00:00

<img alt="ziemia" class="attachment-full size-full wp-post-image" height="1080" src="https://konto.chip.pl/wp-content/uploads/2023/04/ziemia.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/04/ziemia.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Historia naszej planety pokazuje, że kosmiczne skały uderzające w jej powierzchnię mogą skutecznie “zwalczać” tutejszych mieszkańców. Z tego względu im wcześniej wykryjemy potencjalne zagrożenia, tym lepiej. Nie bez powodu naukowcy pracują nad różnego rodzaju systemami wczesnego ostrzegania przed asteroidami, a także sposobami na zmianę trajektorii takich obiektów, gdyby już któryś stanowił faktyczne zagrożenie dla naszej [&#8230;]</p>

## ChatGPT to już old news. Jak odnaleźć się w zatrzęsieniu nowych narzędzi SI?
 - [https://www.chip.pl/2023/04/sztuczna-inteligencja-wszedzie-i-do-wszystkiego](https://www.chip.pl/2023/04/sztuczna-inteligencja-wszedzie-i-do-wszystkiego)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-04-17 18:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1593" src="https://konto.chip.pl/wp-content/uploads/2023/04/sztuczna-inteligencja.jpg" style="margin-bottom: 10px;" width="2391" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/04/sztuczna-inteligencja.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Zaglądam czasem pod niepozornie wyglądające kamienie przy drodze i znajduję tam buzujące od życia środowisko (tak naprawdę zazwyczaj znajduję tam mrówki). Tymczasem wystarczy trafić na taką stronę jak There’s An AI For That, żeby przekonać się, jak wiele dzieje się obecnie w segmencie rozwoju szeroko pojętej sztucznej inteligencji. Poczynania największych graczy w branży to raptem [&#8230;]</p>

## Najstarszy fragment Ziemi, jaki udało się odkryć. Powstał na samym początku istnienia naszej planety
 - [https://www.chip.pl/2023/04/najstarszy-fragment-ziemi](https://www.chip.pl/2023/04/najstarszy-fragment-ziemi)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-04-17 17:00:00+00:00

<img alt="ziemia" class="attachment-full size-full wp-post-image" height="1080" src="https://konto.chip.pl/wp-content/uploads/2023/04/ziemia.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/04/ziemia.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Powierzchnia Ziemi w przeciwieństwie do powierzchni chociażby Księżyca czy Marsa, bezustannie ulega odświeżaniu. Procesy erozji, wybuchy wulkanów, płynąca woda, trzęsienia Ziemi, ruchy tektonicznie bezustannie powoli ale stale usuwają z powierzchni ślady mniej i bardziej istotnych zdarzeń z powierzchni Ziemi. Nic zatem dziwnego, że naukowcy mają problem z poznaniem najwcześniejszych etapów istnienia naszej planety. Nawet największe [&#8230;]</p>

## Lepsze niż Nintendo Switch. Ayn Odin to najlepsza chińska konsola do gier
 - [https://www.chip.pl/2023/04/ayn-odin-opinie-jaka-konsola-retro](https://www.chip.pl/2023/04/ayn-odin-opinie-jaka-konsola-retro)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-04-17 16:30:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1280" src="https://konto.chip.pl/wp-content/uploads/2023/04/ayn-odin-opinie-chinska-konsola-2.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/04/ayn-odin-opinie-chinska-konsola-2.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Ayn Odin to chińska konsola, o której mało kto słyszał, a która wyparła u mnie Nintendo Switcha. Niedawno na łamach Chipa pisałem o &#8220;chińskim Game Boyu&#8220;, czyli retrokonsolce Miyoo Mini. To arcyciekawy sprzęt do grania, który wprowadza duży powiew świeżości w dzisiejszym świecie nastawionym na FPS-y, piksele i inne lootboksy. Dziś chcę Wam opowiedzieć o [&#8230;]</p>

## Cyfrowy Polsat odda ci pieniądze. Koniec wciskania niechcianych usług
 - [https://www.chip.pl/2023/04/cyfrowy-polsat-uikok-decyzja-rekompensata](https://www.chip.pl/2023/04/cyfrowy-polsat-uikok-decyzja-rekompensata)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-04-17 16:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1413" src="https://konto.chip.pl/wp-content/uploads/2023/04/cyfrowy-polsat-uokik.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/04/cyfrowy-polsat-uokik.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Usługi dodatkowe potrafią być istną zmorą podczas zawierania umów, a także później, gdy już otrzymujemy fakturę i okazuje się, że pobierane są od nas pieniądze za coś, czego w ogóle nie chcieliśmy, a co zostało nam wciśnięte na siłę. Taką sytuację mieli klienci Cyfrowego Polsatu. Na szczęście sprawą zajął się UOKiK i po wnikliwym śledztwie [&#8230;]</p>

## Jeden abonament to za mało. Sprawdzamy subskrypcje na Twitterze &#8211; zapłacisz?
 - [https://www.chip.pl/2023/04/subskrybcje-na-twitterze-opinie](https://www.chip.pl/2023/04/subskrybcje-na-twitterze-opinie)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-04-17 15:45:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1280" src="https://konto.chip.pl/wp-content/uploads/2023/04/subskrypcje-na-twitterze-opinie.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/04/subskrypcje-na-twitterze-opinie.jpg" style="display: block; margin: 1em auto;" /></p>
<p>O dziwnych ruchach Twittera można ostatnio pisać regularnie i wylewać przy tym morze liter. Płatne subskrypcje nie są jednak pomysłem Elona – po raz pierwszy wprowadzone zostały w 2021 roku i nazywane były wtedy Super Followers. Nie zyskały zresztą większej popularności, także dzięki ograniczonej dostępności. Sama idea wspierania ulubionych twórców miała się zupełnie dobrze. Nowa [&#8230;]</p>

## Młodzież gubi się w Sieci. Nowy raport przeraża, ale czy naprawdę jest aż tak źle?
 - [https://www.chip.pl/2023/04/raport-mlode-glowy-2023](https://www.chip.pl/2023/04/raport-mlode-glowy-2023)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-04-17 15:30:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1080" src="https://konto.chip.pl/wp-content/uploads/2023/04/raport-mlode-glowy.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/04/raport-mlode-glowy.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Internet pełen jest pułapek czyhających na mniej świadomych użytkowników. Raport “MŁODE GŁOWY” fundacji UNAWEZA może dać wgląd w to, jak internet wpływa na młode osoby. Niestety, nie wydaje się, by był to wpływ korzystny, choć o jednoznaczną ocenę sytuacji nie jest łatwo.  Wiemy, że temat młodzieży w internecie jest zarówno tak samo ważny, jak niezbadany. [&#8230;]</p>

## Futurystyczne słuchawki Huawei FreeBuds 5 wkraczają na polski rynek. Nie obyło się bez promocji na start
 - [https://www.chip.pl/2023/04/huawei-freebuds-5-w-polsce-specyfikacja-cena](https://www.chip.pl/2023/04/huawei-freebuds-5-w-polsce-specyfikacja-cena)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-04-17 15:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1200" src="https://konto.chip.pl/wp-content/uploads/2023/04/Test-Huawei-FreeBuds-5-4.jpg" style="margin-bottom: 10px;" width="1800" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/04/Test-Huawei-FreeBuds-5-4.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Huawei wprowadził do Polski kolejne urządzenie. Tym razem są to słuchawki douszne Huawei FreeBuds 5. W porównaniu z poprzednikiem mają oferować znaczne ulepszenia, długą żywotność baterii i sporo przydatnych funkcjonalności. Przyjrzyjmy się więc im bliżej, a także sprawdźmy, w jakiej cenie są one dostępne. Huawei FreeBuds 5 przykuwają wzrok. Wyglądają jak żywcem wyjęte z filmu [&#8230;]</p>

## Samsung chce pożegnać się z Google&#8217;em. Szykuje się trzęsienie ziemi
 - [https://www.chip.pl/2023/04/samsung-porzuci-google-microsoft-bing](https://www.chip.pl/2023/04/samsung-porzuci-google-microsoft-bing)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-04-17 14:01:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1707" src="https://konto.chip.pl/wp-content/uploads/2023/04/google-scaled.jpg" style="margin-bottom: 10px;" width="2560" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/04/google-scaled.jpg" style="display: block; margin: 1em auto;" /></p>
<p>W ciągu ostatnich 12 lat Samsung przyzwyczaił swoich użytkowników do domyślnej obecności wyszukiwarki Google w swoich telefonach. Jej status może być jednak zagrożony &#8211; południowokoreański czebol, wyraźnie pod wrażeniem możliwości w zakresie wykorzystania sztucznej inteligencji, rozważa zacieśnienie współpracy z Microsoftem i przesiadkę na Binga. Jeśli Google zależy na utrzymaniu wieloletniej i owocnej finansowo współpracy, musi [&#8230;]</p>

## Cały świat śmieje się z Niemiec. Wyłączyli elektrownie atomowe i zostali z ręką w nocniku
 - [https://www.chip.pl/2023/04/niemcy-wylaczyly-elektrownie-atomowe](https://www.chip.pl/2023/04/niemcy-wylaczyly-elektrownie-atomowe)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-04-17 13:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="861" src="https://konto.chip.pl/wp-content/uploads/2023/04/energy-transition-49558_1280.jpg" style="margin-bottom: 10px;" width="1280" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/04/energy-transition-49558_1280.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Co się może stać, gdy w kraju takim jak Niemcy wyłączy się wszystkie elektrownie atomowe? Nasz zachodni sąsiad zdecydował się na radykalny krok, którego skutki były widoczne już pierwszej nocy i nie napawają optymizmem. Chociaż niektóre reakcje wydają się być spóźnione. Był rok 2011. W Japonii w wyniku trzęsienia ziemi doszło do awarii elektrowni atomowej [&#8230;]</p>

## Starship sięgnie bram kosmosu. Największa rakieta świata ma dziś swój pierwszy poważny test
 - [https://www.chip.pl/2023/04/starship-najwieksza-rakieta-swiata-test-orbitalny](https://www.chip.pl/2023/04/starship-najwieksza-rakieta-swiata-test-orbitalny)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-04-17 11:16:31+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1152" src="https://konto.chip.pl/wp-content/uploads/2023/04/Starship-Super-Heavy-1.jpg" style="margin-bottom: 10px;" width="2048" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/04/Starship-Super-Heavy-1.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Cokolwiek powiedzieć o Elonie Musku, jego firma kosmiczna SpaceX jest bardzo udanym przedsięwzięciem – złośliwi mówią, że to dlatego, że zarząd i inżynierowie nie pozwalają mu się wtrącać w bieżącą działalność. SpaceX jako pierwszy prywatny przewoźnik wykonuje regularne loty transportowe rakietami wielokrotnego użytku Falcon 9 oraz Falcon Heavy i jest w stanie dostarczać zmiany załóg [&#8230;]</p>

## Krótki test Huawei FreeBuds 5. &#8220;Inny&#8221; nie zawsze znaczy &#8220;lepszy&#8221;
 - [https://www.chip.pl/2023/04/huawei-freebuds-5-test-recenzja-opinia](https://www.chip.pl/2023/04/huawei-freebuds-5-test-recenzja-opinia)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-04-17 10:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1200" src="https://konto.chip.pl/wp-content/uploads/2023/04/Test-Huawei-FreeBuds-5-19.jpg" style="margin-bottom: 10px;" width="1800" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/04/Test-Huawei-FreeBuds-5-19.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Czas spędzony ze słuchawkami TWS Huawei FreeBuds 5 był dla mnie niczym rollercoaster emocji. Z początku był zachwyt i uznanie, a po pierwszych kilku minutach użytkowania nieustająca irytacja. Huawei FreeBuds 5 to idealny przykład tego, jak nie projektować słuchawek Pisząc te słowa, mam z tyłu głowy szereg momentów, w których podchodziłem do testu Huawei FreeBuds [&#8230;]</p>

## Samochód elektryczny może być tani jak barszcz. Wystarczy, że złożysz go samodzielnie
 - [https://www.chip.pl/2023/04/miejski-samochod-elektryczny-luvly-o](https://www.chip.pl/2023/04/miejski-samochod-elektryczny-luvly-o)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-04-17 09:30:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1080" src="https://konto.chip.pl/wp-content/uploads/2023/04/Luvly-O-samochod-elektryczny-1-3.jpg" style="margin-bottom: 10px;" width="1440" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/04/Luvly-O-samochod-elektryczny-1-3.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Szwedzka firma Luvly zaprezentowała światu swój pierwszy pojazd o nazwie Luvly O. Ten miejski samochód elektryczny jest przeznaczony zdecydowanie dla osób niewymagających i niewyściubiających zbyt często nosa ze swojego miasta lub jako któryś z kolei samochód w rodzinie. Luvly O to tani samochód elektryczny dla niewymagających rodem z Ikei BEV, czyli elektryczne pojazdy wykorzystujące akumulatory [&#8230;]</p>

## Elektryczny rower szutrowy w niskiej cenie. Fiido przygotowało coś specjalnego
 - [https://www.chip.pl/2023/04/elektryczny-rower-szutrowy-fiido-c21](https://www.chip.pl/2023/04/elektryczny-rower-szutrowy-fiido-c21)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-04-17 08:42:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1080" src="https://konto.chip.pl/wp-content/uploads/2023/04/Elektryczny-rower-szutrowy-Fiido-C21-C22-4.jpg" style="margin-bottom: 10px;" width="1811" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/04/Elektryczny-rower-szutrowy-Fiido-C21-C22-4.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Firma Fiido zaprezentowała właśnie światu dwa nowe e-bike &#8211; C21 oraz C22. Pod względem możliwości są to bliźniacze modele, którymi powinny zainteresować się osoby, chcące kupić w tym sezonie elektryczny rower szutrowy w niskiej cenie. Fiido C21 i C22 to idealny przykład na to, że elektryczny rower szutrowy nie musi być drogi Rowery szutrowe otwierają [&#8230;]</p>

## Supernowa Żagla uwieczniona w imponujących szczegółach. Tego zdjęcia nie można przegapić
 - [https://www.chip.pl/2023/04/supernowa-zagla-zdjecie-po-eksplozji](https://www.chip.pl/2023/04/supernowa-zagla-zdjecie-po-eksplozji)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-04-17 07:00:43+00:00

<img alt="trojwymiarowy model supernowej" class="attachment-full size-full wp-post-image" height="2400" src="https://konto.chip.pl/wp-content/uploads/2021/12/trojwymiarowy-model-supernowej.jpg" style="margin-bottom: 10px;" width="2400" /><p><img src="https://konto.chip.pl/wp-content/uploads/2021/12/trojwymiarowy-model-supernowej.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Vikas Chander zajmuje się astrofotografią, a jego najnowszy łup zapewne jeszcze przez długi czas będzie stanowił jeden z najjaśniejszych punktów w portfolio tego artysty. Celem jego obserwacji oraz zdjęć była tzw. supernowa Żagla. Są to pozostałości po potężnej eksplozji, jaka miała miejsce w odległości nieco ponad 800 lat świetlnych od naszej planety. Zdaniem naukowców do [&#8230;]</p>

## Nowy niszczyciel marynarki USA dostanie wielkie wyrzutnie. Będzie jeszcze bardziej niszczycielski
 - [https://www.chip.pl/2023/04/nowy-niszczyciel-marynarki-usa-g-vls](https://www.chip.pl/2023/04/nowy-niszczyciel-marynarki-usa-g-vls)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-04-17 04:06:10+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1080" src="https://konto.chip.pl/wp-content/uploads/2023/04/DDGX-Niszczyciel-marynarki-USA-nowej-generacji-2.jpg" style="margin-bottom: 10px;" width="1914" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/04/DDGX-Niszczyciel-marynarki-USA-nowej-generacji-2.jpg" style="display: block; margin: 1em auto;" /></p>
<p>DDG(X) to program marynarki wojennej USA, którego owocem będzie całkowicie nowy niszczyciel rakietowy. Ten jako okręt zupełnie nowej klasy, wprowadzi na służbę wiele nowości i stanie się jeszcze większym problemem dla wrogów, rażąc ich z większych pocisków w jeszcze większych wyrzutniach. DDG(X) odmieni możliwości niszczycieli marynarki USA. Będzie lepszy od wcześniejszych okrętów tego typu pod [&#8230;]</p>

## Ruszył największy w Europie reaktor jądrowy. Jedni rezygnują z atomu, inni wręcz przeciwnie
 - [https://www.chip.pl/2023/04/najwiekszy-reaktor-jadrowy-w-europie-uruchomiony](https://www.chip.pl/2023/04/najwiekszy-reaktor-jadrowy-w-europie-uruchomiony)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-04-17 04:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="902" src="https://konto.chip.pl/wp-content/uploads/2023/04/reaktor-atomowy.jpg" style="margin-bottom: 10px;" width="1572" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/04/reaktor-atomowy.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Z jednej strony w ostatnich dniach głośno było o decyzji Niemiec związanej z wyłączeniem trzech ostatnich reaktorów jądrowych. Z drugiej pojawiły się natomiast wieści o uruchomieniu rekordowo dużego w innym kraju. Jest nim Finlandia, gdzie swoją działalność rozpoczął Olkiluoto 3, który obecnie wytwarza około 14% energii elektrycznej w całej Finlandii. Jak zapewniają tamtejsze władze, ma [&#8230;]</p>

