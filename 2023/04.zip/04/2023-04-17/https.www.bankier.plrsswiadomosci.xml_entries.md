# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Podwyższenie wieku emerytalnego we Francji. Macron podał termin wejścia reformy w życie. "To konieczne"
 - [https://www.bankier.pl/wiadomosc/Podwyzszenie-wieku-emerytalnego-we-Francji-Macron-podal-termin-wejscia-reformy-w-zycie-To-konieczne-8524489.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Podwyzszenie-wieku-emerytalnego-we-Francji-Macron-podal-termin-wejscia-reformy-w-zycie-To-konieczne-8524489.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 19:33:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/f/e372cd1cd18f9a-948-568-0-93-2484-1490.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Reforma emerytalna będzie wchodzić w życie stopniowo od jesieni – zapowiedział prezydent Francji Emmanuel Macron w poniedziałek w telewizyjnym orędziu do narodu. Prezydent przyznał, że rozumie obawy i sprzeciw obywateli, jednak z powodu wzrostu liczby emerytów podwyższenie wieku emerytalnego jest konieczne.</p>

## Reuters: USA mogą sprzedać Turcji sprzęt wojskowy. Pierwszy raz od wielu lat
 - [https://www.bankier.pl/wiadomosc/Reuters-USA-moga-sprzedac-Turcji-sprzet-wojskowy-Pierwszy-raz-od-wielu-lat-8524485.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Reuters-USA-moga-sprzedac-Turcji-sprzet-wojskowy-Pierwszy-raz-od-wielu-lat-8524485.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 19:12:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/6/e26a61e751f930-948-568-0-266-3945-2366.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Biały Dom zamierza zezwolić na sprzedanie Turcji pakietu modernizacyjnego do posiadanych przez nią myśliwców F-16, jeśli transakcję tę zaaprobuje Kongres USA - podaje w poniedziałek agencja Reutera, powołując się na źródła.</p>

## Mennica Polska złożyła ofertę w przetargu Centralnego Banku Dominikany
 - [https://www.bankier.pl/wiadomosc/Mennica-Polska-zlozyla-oferte-w-przetargu-Centralnego-Banku-Dominikany-8524468.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Mennica-Polska-zlozyla-oferte-w-przetargu-Centralnego-Banku-Dominikany-8524468.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 18:24:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/5/e966b7a9b9aa6c-948-568-0-0-2323-1393.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Mennica Polska złożyła ofertę w przetargu na bicie 
monet obiegowych o nominałach: 1, 5, 10  i 25 pesos, w łącznej ilości 
155 mln sztuk, organizowanym przez Centralny Bank Dominikany - podała 
Mennica w komunikacie.</p>

## UE wygrywa z Indiami sprawę dot. wysokich ceł m.in. na telefony komórkowe
 - [https://www.bankier.pl/wiadomosc/UE-wygrywa-z-Indiami-sprawe-dot-wysokich-cel-m-in-na-telefony-komorkowe-8524447.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/UE-wygrywa-z-Indiami-sprawe-dot-wysokich-cel-m-in-na-telefony-komorkowe-8524447.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 17:47:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/3/b25a91ebffd22c-948-568-0-175-1672-1003.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />UE wygrała z Indiami sprawę przed Światową Organizacją Handlu (WTO) w sprawie ceł na produkty technologii informacyjno-komunikacyjnych, w tym telefony komórkowe czy słuchawki bezprzewodowe  - podała w poniedziałek Komisja Europejska.</p>

## Biedronka wprowadzała klientów w błąd. Jeronimo Martins musi zapłacić wielomilionową karę
 - [https://www.bankier.pl/wiadomosc/Biedronka-zle-oznaczala-kraj-pochodzenia-warzyw-i-owocow-Jeronimo-Martins-musi-zaplacic-wielomilionowa-kare-8524434.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Biedronka-zle-oznaczala-kraj-pochodzenia-warzyw-i-owocow-Jeronimo-Martins-musi-zaplacic-wielomilionowa-kare-8524434.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 17:24:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/c/a8298e80aecfe2-948-568-0-49-2000-1199.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Jeronimo Martins Polska, właściciel sieci sklepów 
Biedronka, musi zapłacić 60 mln zł kary. Według UOKiK-u spółka 
nieprawidłowo wskazywała kraj pochodzenia warzyw i owoców w sklepach 
Biedronka. Jest wyrok SOKiK.</p>

## Przewodnicząca KE Ursula von der Leyen pozwana w związku z kontraktami z Pfizerem
 - [https://www.bankier.pl/wiadomosc/Przewodniczaca-KE-Ursula-von-der-Leyen-pozwana-w-zwiazku-z-kontraktami-z-Pfizerem-8524425.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Przewodniczaca-KE-Ursula-von-der-Leyen-pozwana-w-zwiazku-z-kontraktami-z-Pfizerem-8524425.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 17:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/6/2b1fd098e14513-948-567-0-37-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Belgijski lobbysta złożył skargę przeciwko przewodniczącej Komisji Europejskiej Ursuli von der Leyen przed belgijskim sądem. Domaga się uchylenia jej immunitetu i zbadania wiadomości tekstowych wymienianych przez nią z dyrektorem generalnym firmy Pfizer Albertem Bourlą - informuje Euractiv.</p>

## Indeks małych spółek z szansą na historyczny szczyt. Zamieszanie na kursie Ten Square Games
 - [https://www.bankier.pl/wiadomosc/Indeks-malych-spolek-z-szansa-na-historyczny-szczyt-Zamieszanie-na-kursie-Ten-Square-Games-8524393.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Indeks-malych-spolek-z-szansa-na-historyczny-szczyt-Zamieszanie-na-kursie-Ten-Square-Games-8524393.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 16:55:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/0/62d855390f6cf3-945-560-540-540-3960-2375.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Główne indeksy skończyły sesję w poniedziałek na zielono, a notowania sWIG80 zmierzają w stronę historycznego szczytu z 2021 r. z szansą na jego poprawianie. Ogromna zmienność panowała na akcjach Ten Square Games, który ogłosił kolejne odpisy i potężną redukcję zatrudnienia.</p>

## Katastrofa smoleńska. Macierewicz zawiadamia prokuraturę ws. zamachu na prezydenta Lecha Kaczyńskiego
 - [https://www.bankier.pl/wiadomosc/Katastrofa-smolenska-Macierewicz-zawiadamia-prokurature-ws-zamachu-na-prezydenta-Lecha-Kaczynskiego-8524384.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Katastrofa-smolenska-Macierewicz-zawiadamia-prokurature-ws-zamachu-na-prezydenta-Lecha-Kaczynskiego-8524384.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 16:32:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/0/33d1bbd917da33-948-568-0-74-3300-1979.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Podkomisja smoleńska złożyła w poniedziałek w 
prokuraturze zawiadomienie o podejrzeniu popełnienia przestępstwa 
zamachu na prezydenta Lecha Kaczyńskiego oraz morderstwa pozostałych 95 
osób podróżujących Tu-154 10 kwietnia 2010 r. - poinformował PAP szef 
tej komisji Antoni Macierewicz</p>

## Sprawa męża marszałek Witek na OIOM-ie. Prokuratura podjęła decyzję ws. afery
 - [https://www.bankier.pl/wiadomosc/Prokuratura-kierownictwo-legnickiego-szpitala-nie-dzialo-niezgodnie-z-prawem-8524363.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Prokuratura-kierownictwo-legnickiego-szpitala-nie-dzialo-niezgodnie-z-prawem-8524363.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 16:09:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/f/4428764f1bc05d-948-568-0-270-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kierownictwo Wojewódzkiego Szpitala Specjalistycznego w Legnicy nie działało niezgodnie z prawem; nie ujawniono również okoliczności świadczących o uprzywilejowanym traktowaniu pacjenta – podała w poniedziałek w oświadczeniu Prokuratura Okręgowa w Legnicy.</p>

## Ceny materiałów budowlanych i dwucyfrowe wzrosty. To zdrożało najmocniej
 - [https://www.bankier.pl/wiadomosc/Ceny-materialow-budowlanych-i-dwucyfrowe-wzrosty-To-zdrozalo-najmocniej-8524337.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ceny-materialow-budowlanych-i-dwucyfrowe-wzrosty-To-zdrozalo-najmocniej-8524337.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 15:34:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/b/4152099406aa80-948-568-0-278-4288-2572.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ceny materiałów budowlanych w pierwszym kwartale tego roku, w porównaniu z analogicznym okresem 2022 r., wzrosły średnio o 14 proc. - podała w poniedziałek Grupa PSB Handel. Najmocniej, o 44 proc. zdrożały cement i wapno.</p>

## Coraz więcej niewypłacalnych firm. Problemy notuje każda branża
 - [https://www.bankier.pl/wiadomosc/Coraz-wiecej-niewyplacalnych-firm-Problemy-notuje-kazda-branza-8524314.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Coraz-wiecej-niewyplacalnych-firm-Problemy-notuje-kazda-branza-8524314.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 15:05:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/0/f4f4ca5b764f8b-948-568-0-119-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W I kwartale 2023 r. niewypłacalność przedsiębiorstw w Polsce wzrosła o 31 proc. w porównaniu z ostatnim kwartałem 2022 r. - wynika z raportu firmy Coface. Dodano, że wzrost niewypłacalności dotyczy każdej branży.</p>

## Koniec fałszywych SMS-ów? NASK będzie walczyć z cyberoszustami
 - [https://www.bankier.pl/wiadomosc/Koniec-falszywych-SMS-ow-NASK-bedzie-walczyc-z-cyberoszustami-8524295.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Koniec-falszywych-SMS-ow-NASK-bedzie-walczyc-z-cyberoszustami-8524295.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 14:49:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/5/5680ce932d6900-948-568-0-119-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ograniczenie masowej wysyłki tzw. fałszywych SMS-ów zapowiedziały NASK i Krajowa Izba Komunikacji Ethernetowej, które podpisały w poniedziałek porozumienie w tej sprawie.</p>

## Hotele na podsłuchu - tak władza inwigiluje opozycję? Jest stanowisko hotelowej spółki Skarbu Państwa
 - [https://www.bankier.pl/wiadomosc/Hotele-na-podsluchu-tak-inwigiluje-wladza-Polski-Holding-Hotelowy-8524292.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Hotele-na-podsluchu-tak-inwigiluje-wladza-Polski-Holding-Hotelowy-8524292.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 14:43:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/2/b54a3194a122ac-948-568-0-164-1603-961.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Artykuł "Gazety Wyborczej" na temat Polskiego Holdingu Hotelowego opiera się na spreparowanych, całkowicie fałszywych informacjach byłego pracownika naszej firmy - głosi oświadczenie PHH, podpisane przez prezesa Gheorghe Mariana Cristescu.</p>

## Patriotyzm według PiS-u. Chce ułatwić uczelniom budowę strzelnic
 - [https://www.bankier.pl/wiadomosc/PiS-chce-ulatwic-uczelniom-budowe-strzelnic-8524286.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PiS-chce-ulatwic-uczelniom-budowe-strzelnic-8524286.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 14:38:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/c/530afc84ed7e0c-948-568-0-62-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ułatwienie uczelniom budowy strzelnic przewiduje opublikowany na stronie Sejmu projekt ustawy grupy posłów PiS.</p>

## Sunak: Nieznajomość podstaw matematyki przez dorosłych kosztuje gospodarkę miliardy funtów
 - [https://www.bankier.pl/wiadomosc/Sunak-Nieznajomosc-podstaw-matematyki-przez-doroslych-kosztuje-gospodarke-miliardy-funtow-8524251.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sunak-Nieznajomosc-podstaw-matematyki-przez-doroslych-kosztuje-gospodarke-miliardy-funtow-8524251.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 13:49:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/2/70e6ce7885fd03-948-568-0-20-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Matematyka powinna być obowiązkowa dla wszystkich uczniów do 18. roku życia, bo nieznajomość jej podstaw przez dorosłych kosztuje potem gospodarkę miliardy funtów - powiedział w poniedziałek brytyjski premier Rishi Sunak.</p>

## Rozpoczęła się kwalifikacja wojskowa. Kogo dotyczy obowiązek?
 - [https://www.bankier.pl/wiadomosc/Kwalifikacja-wojskowa-2023-Kto-musi-sie-stawic-do-kiedy-potrwa-8524239.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kwalifikacja-wojskowa-2023-Kto-musi-sie-stawic-do-kiedy-potrwa-8524239.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 13:33:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/3/e56119cd9d901e-948-568-0-60-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W poniedziałek rozpoczęła się kwalifikacja wojskowa, która potrwa do 21 lipca i obejmie wg założeń MON ok. 230 tys. osób.</p>

## CCC rozpoczęło proces budowania księgi popytu do 14 mln nowych akcji
 - [https://www.bankier.pl/wiadomosc/CCC-rozpoczelo-proces-budowania-ksiegi-popytu-do-14-mln-nowych-akcji-8524221.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/CCC-rozpoczelo-proces-budowania-ksiegi-popytu-do-14-mln-nowych-akcji-8524221.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 13:04:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/0/c7a0477871f618-948-568-6-106-2500-1500.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />CCC rozpoczęło proces budowania księgi popytu do 14 mln nowych akcji - podała spółka w komunikacie.</p>

## Inflacja bazowa z nowym rekordem. Dezinflacja przebiega bardzo opornie
 - [https://www.bankier.pl/wiadomosc/Inflacja-bazowa-w-Polsce-marzec-2023-Dezinflacja-przebiega-bardzo-opornie-8524206.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Inflacja-bazowa-w-Polsce-marzec-2023-Dezinflacja-przebiega-bardzo-opornie-8524206.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 13:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/0/06993c2a04d137-937-562-0-0-937-562.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W marcu inflacja bazowa osiągnęła
rekordowo wysoki poziom. Sugeruje to, że presja inflacyjna w
polskiej gospodarce pozostaje silna oraz że w znacznej mierze jest ona generowana
przez czynniki krajowe.</p>

## Rząd kusi przedsiębiorców. Przed wyborami proponuje ułatwienie w prowadzeniu działalności
 - [https://www.bankier.pl/wiadomosc/Rzad-kusi-przedsiebiorcow-Przed-wyborami-proponuje-ulatwienie-w-prowadzeniu-dzialalnosci-8524186.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rzad-kusi-przedsiebiorcow-Przed-wyborami-proponuje-ulatwienie-w-prowadzeniu-dzialalnosci-8524186.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 13:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/3/ac63d8ca291337-948-568-0-97-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przedsiębiorcy są raczej zapomnianą grupą wyborców, tymczasem Ministerstwo Rozwoju przygotowuje pakiet zmian mający ułatwić prowadzenie działalności gospodarczej. Co ma się zmienić?</p>

## Koniec kłopotów Bogdanki. Spółka wróciła do pracy na trzech ścianach wydobywczych. Woda w kopalni opada
 - [https://www.bankier.pl/wiadomosc/Bogdanka-ustabilizowala-sytuacje-hydrologiczna-i-wrocila-do-pelnej-eksploatacji-trzema-scianami-8524201.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Bogdanka-ustabilizowala-sytuacje-hydrologiczna-i-wrocila-do-pelnej-eksploatacji-trzema-scianami-8524201.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 12:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/f/a1b863de20af70-948-567-18-21-1015-608.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Bogdanka ustabilizowała sytuację hydrologiczną na polu Nadrybie i wróciła do pełnej eksploatacji trzema ścianami - poinformowała spółka w mediach społecznościowych.</p>

## Zagłębie gamingowe zamiast kopalni Wieczorek. W Katowicach powstanie "Dzielnica Nowych Technologii"
 - [https://www.bankier.pl/wiadomosc/Zaglebie-gamingowe-zamiast-kopalni-Wieczorek-W-Katowicach-powstanie-Dzielnica-Nowych-Technologii-8524172.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zaglebie-gamingowe-zamiast-kopalni-Wieczorek-W-Katowicach-powstanie-Dzielnica-Nowych-Technologii-8524172.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 12:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/1/5b4a6ee7737cae-948-568-0-150-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Samorząd Katowic formalnie przejął w poniedziałek od Spółki Restrukturyzacji Kopalń 9,4 ha nieruchomości po zlikwidowanej kopalni Wieczorek. Miasto przygotowuje utworzenie tam hubu gamingowo-technologicznego, wykorzystującego m.in. zabytkowe zabudowania pokopalniane.</p>

## Ziobro: Sztuczna inteligencja w sądownictwie staje się koniecznością
 - [https://www.bankier.pl/wiadomosc/Ziobro-Sztuczna-inteligencja-w-sadownictwie-staje-sie-koniecznoscia-8524155.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ziobro-Sztuczna-inteligencja-w-sadownictwie-staje-sie-koniecznoscia-8524155.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 11:56:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/5/b26fa3be353d91-948-568-0-130-2000-1199.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zastosowanie sztucznej inteligencji w sądownictwie staje się nie tyle opcją, co koniecznością; może pozwolić na przyspieszenie postępowań sądowych - podkreślił w poniedziałek szef MS Zbigniew Ziobro. Dodał, że jednak żaden sądowy system informatyczny nie zastąpi w pełni człowieka.</p>

## Dożywocie za szpiegostwo? Posłowie PiS chcą zaostrzenia kar
 - [https://www.bankier.pl/wiadomosc/Dozywocie-za-szpiegostwo-Poslowie-PiS-chca-zaostrzenia-kar-8524152.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Dozywocie-za-szpiegostwo-Poslowie-PiS-chca-zaostrzenia-kar-8524152.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 11:55:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/4/bd4f675326a897-945-560-90-48-1410-845.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nawet kara dożywocia za szpiegostwo - takich zmian chcą posłowie klubu parlamentarnego Prawo i Sprawiedliwość - dowiedziała się PAP. Co więcej, skazany szpieg mógłby zostać pozbawiony praw publicznych i praw emerytalnych.</p>

## Orlen i Synthos wskazali potencjalne lokalizacje reaktorów SMR
 - [https://www.bankier.pl/wiadomosc/Orlen-i-Synthos-wskazali-potencjalne-lokalizacje-reaktorow-SMR-8524136.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Orlen-i-Synthos-wskazali-potencjalne-lokalizacje-reaktorow-SMR-8524136.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 11:34:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/4/7a109038d25329-948-569-0-28-1586-952.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prezes PKN Orlen Daniel Obajtek ogłosił w poniedziałek siedem wstępnych lokalizacji, w których spółka Orlen Synthos Green Energy mogłaby zbudować reaktory typu SMR. Teraz wytypowane lokalizacje czekają przynajmniej dwuletnie badania. Wcześniej informowano o 4 mld dol. amerykańskiego wsparcia dla projektu SMR Orlenu i Syntosu.</p>

## AgroUnia: Okłamali nas i okradli. Kto miał zarobić, to zarobił
 - [https://www.bankier.pl/wiadomosc/AgroUnia-Oklamali-nas-i-okradli-Kto-mial-zarobic-to-zarobil-8524050.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/AgroUnia-Oklamali-nas-i-okradli-Kto-mial-zarobic-to-zarobil-8524050.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 11:25:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/2/818522fd69d1ed-948-568-0-181-4032-2419.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przewodniczący AgroUnii Michał Kołodziejczak ostrzega, że kryzys z ukraińskim zbożem wywołany jego zdaniem przez PiS może doprowadzić nawet do wyjścia Polski z Unii Europejskiej. Jego obawy nie są nieuzasadnione wobec coraz ostrzejszych wypowiedzi płynących z Brukseli. </p>

## Główny akcjonariusz CCC ocenia, że najgorsze jest już za spółką
 - [https://www.bankier.pl/wiadomosc/Glowny-akcjonariusz-CCC-ocenia-ze-najgorsze-jest-juz-za-spolka-8524106.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Glowny-akcjonariusz-CCC-ocenia-ze-najgorsze-jest-juz-za-spolka-8524106.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 11:02:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/f/cacc92ae1e21fa-945-560-0-51-1152-691.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Dariusz Miłek, przewodniczący rady nadzorczej CCC i jej główny akcjonariusz ocenia, że grupa ma już za sobą największe problemy. Spodziewa się poprawy marż od drugiego kwartału.</p>

## Nie tylko Polska. Słowacja też zakazała importu ukraińskiego zboża
 - [https://www.bankier.pl/wiadomosc/Nie-tylko-Polska-Slowacja-tez-zakazala-importu-ukrainskiego-zboza-8524098.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nie-tylko-Polska-Slowacja-tez-zakazala-importu-ukrainskiego-zboza-8524098.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 10:54:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/d/39a6ecced4595b-945-560-0-90-1500-899.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rząd Słowacji wprowadził w poniedziałek czasowy zakaz importu ukraińskiego zboża. Ministerstwo rolnictwa oświadczyło, że wyczerpało już wszystkie prawne możliwości kontroli napływu zboża z Ukrainy przy jednoczesnym zachowaniu tzw. korytarzy solidarności.</p>

## Inflacja w Argentynie przekroczyła 100 proc.
 - [https://www.bankier.pl/wiadomosc/Inflacja-w-Argentynie-przekroczyla-100-8524088.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Inflacja-w-Argentynie-przekroczyla-100-8524088.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 10:40:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/7/dc7e447d2b4339-948-568-0-260-2000-1199.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Argentyna kolejny raz postanowiła udowodnić światu, że dla
inflacji nie istnieje górny limit.</p>

## Bank of America nie spodziewa się, by RPP obniżyła stopy proc. w 2023 roku
 - [https://www.bankier.pl/wiadomosc/Bank-of-America-RPP-nie-obnizy-stop-procentowych-w-2023-roku-8524085.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Bank-of-America-RPP-nie-obnizy-stop-procentowych-w-2023-roku-8524085.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 10:38:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/c/532355be8ee7fc-945-567-11-45-1488-893.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />RPP zacznie obniżać stopy procentowe w I kw. 2024 r., a gdyby presja inflacyjna okazała się uporczywa raczej utrzyma je dłużej na obecnym poziomie niż dokona podwyżek - uważają ekonomiści Bank of America (BofA).</p>

## Kolejne odpisy w Ten Square Games. Kurs na nowych minimach
 - [https://www.bankier.pl/wiadomosc/Ten-Square-Games-wstrzymuje-prace-deweloperskie-nad-Undead-Clash-oraz-Fishing-Masters-8524068.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ten-Square-Games-wstrzymuje-prace-deweloperskie-nad-Undead-Clash-oraz-Fishing-Masters-8524068.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 10:16:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/0/49dbe3c431812e-948-568-117-0-1803-1082.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ten Square Games wstrzymuje prace deweloperskie nad "Undead Clash" oraz "Fishing Masters"  - podała spółka w komunikacie.  Spółka podjęła również decyzję o całkowitym odpisie skapitalizowanych kosztów związanych z produkcją obu gier.</p>

## PiS szykuje odpowiedź na "babciowe". W rządzie działa już specjalny zespół
 - [https://www.bankier.pl/wiadomosc/PiS-zawalczy-o-kobiety-Granty-dla-wlascicielek-firm-bony-dla-mlodych-matek-8523983.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PiS-zawalczy-o-kobiety-Granty-dla-wlascicielek-firm-bony-dla-mlodych-matek-8523983.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 10:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/5/a8939812eaaefd-945-567-0-96-3853-2312.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Jeszcze w maju Prawo i Sprawiedliwość przedstawi projekt ustawy mający pomóc w aktywizacji zawodowej kobiet - informuje "Dziennik Gazeta Prawna". W grę wchodzą granty, zwolnienia z ZUS czy zmiany w kodeksie pracy. W ten sposób partia rządząca chce odzyskać choć kilka punktów procentowych w zniechęconym kobiecym elektoracie.  

</p>

## Ten Square Games przeprowadzi zwolnienia grupowe do końca kwietnia
 - [https://www.bankier.pl/wiadomosc/Ten-Square-Games-zamierza-zwolnic-120-osob-do-konca-kwietnia-8524066.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ten-Square-Games-zamierza-zwolnic-120-osob-do-konca-kwietnia-8524066.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 10:14:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/f/58e9bea58d392b-948-568-8-0-1592-955.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ten Square Games planuje do końca kwietnia przeprowadzić zwolnienia grupowe 25 proc. osób związanych ze spółką. Redukcja zatrudnienia obejmie 120 osób, w tym 50 osób na podstawie umów o pracę - podała spółka w komunikacie.</p>

## Znany rosyjski opozycjonista skazany na 25 lat więzienia
 - [https://www.bankier.pl/wiadomosc/Rosyjski-opozycjonista-Kara-Murza-skazany-na-25-lat-wiezienia-8524053.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rosyjski-opozycjonista-Kara-Murza-skazany-na-25-lat-wiezienia-8524053.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 09:53:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/f/07327d7d7dd155-948-568-0-0-1771-1062.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />25 lat więzienia - taki wyrok usłyszał znany działacz opozycji antykremlowskiej Władimira Kara-Murza, oskarżony o zdradę stanu. Proces toczył się za zamkniętymi drzwiami, a obrona zapowiedziała apelację.
</p>

## Senior stracił 1,8 mln złotych. Zaufał "policjantowi"
 - [https://www.bankier.pl/wiadomosc/Senior-z-Czestochowy-stracil-1-8-mln-zlotych-Zaufal-policjantowi-8524017.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Senior-z-Czestochowy-stracil-1-8-mln-zlotych-Zaufal-policjantowi-8524017.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 09:13:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/9/5f4b148d2dd28d-945-560-0-26-2037-1222.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Mimo że oszustwo na policjanta to żadna nowość, to jego ofiar nie brakuje. Prawie 1,8 mln zł stracił 85-letni mieszkaniec Częstochowy, który za namową fałszywego policjanta i prokuratora uwierzył, że jego pieniądze na kontach bankowych są zagrożone. Wypłaconą gotówkę senior przekazał obcemu mężczyźnie podczas kilku spotkań.</p>

## Kurs euro blisko tegorocznego maksimum. Dolar blisko 4,20 zł
 - [https://www.bankier.pl/wiadomosc/Kurs-euro-blisko-tegorocznego-maksimum-Dolar-blisko-4-20-zl-8524012.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kurs-euro-blisko-tegorocznego-maksimum-Dolar-blisko-4-20-zl-8524012.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 09:01:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/2/1009b9a4f36074-948-568-0-718-2603-1561.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Złotemu sprzyjają dobre nastroje na światowych
rynkach finansowych.</p>

## Awaria w PKO BP. Klienci zgłaszają problemy z logowaniem
 - [https://www.bankier.pl/wiadomosc/Awaria-w-PKO-BP-Klienci-zglaszaja-problemy-z-logowaniem-8523991.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Awaria-w-PKO-BP-Klienci-zglaszaja-problemy-z-logowaniem-8523991.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 08:05:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/2/2e0c70715f02e7-948-568-3-68-1307-784.png" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Poniedziałek rozpoczął się od awarii w PKO Banku Polskim. Klienci zgłaszają problemy z zalogowaniem się do serwisu transakcyjnego i aplikacji. Występują też problemy ze zlecaniem przelewów.</p>

## Miedź wyceniana stabilnie, ale zapasy najniższe od 18 lat
 - [https://www.bankier.pl/wiadomosc/Miedz-wyceniana-stabilnie-ale-zapasy-najnizsze-od-18-lat-8523990.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Miedz-wyceniana-stabilnie-ale-zapasy-najnizsze-od-18-lat-8523990.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 08:05:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/1/3677cc8c62d867-948-568-0-0-1500-899.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ceny miedzi na giełdzie metali LME w Londynie utrzymują stabilny poziom, ale "ciasna" sytuacja podażowa może wspierać notowania metalu. Miedź w dostawach 3-miesięcznych jest wyceniana blisko 9024,00 USD za tonę notowanych na zakończenie poprzedniej sesji - informują maklerzy.</p>

## Brzezinski: 4 mld dol. amerykańskiego wsparcia dla projektu SMR Orlenu i Syntosu
 - [https://www.bankier.pl/wiadomosc/Brzezinski-4-mld-dol-amerykanskiego-wsparcia-dla-projektu-SMR-Orlenu-i-Syntosu-8523975.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Brzezinski-4-mld-dol-amerykanskiego-wsparcia-dla-projektu-SMR-Orlenu-i-Syntosu-8523975.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 07:39:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/1/70503820345502-948-568-71-266-4024-2414.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Amerykański EXIM Bank deklaruje 3 mld dol., a agencja DFC - 1 mld dol. na rozwój reaktorów BWRX-300 w Polsce przez spółkę Orlen Synthos Green Energy - poinformował w poniedziałek ambasador USA Mark Brzezinski. W ambasadzie USA w Warszawie podpisano listy intencyjne w tej sprawie.</p>

## Rząd zamknął plażę, bo chroni LNG. Kilkaset osób może stracić pracę
 - [https://www.bankier.pl/wiadomosc/Rzad-zamknal-plaze-bo-chroni-LNG-Kilkaset-osob-moze-stracic-prace-8523955.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rzad-zamknal-plaze-bo-chroni-LNG-Kilkaset-osob-moze-stracic-prace-8523955.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 07:20:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/d/c503f5308f082d-948-568-0-194-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rząd wprowadził zakaz zbliżania się do terminala LNG w Świnoujściu, a jednocześnie wyprowadził tym samym ludzi na ulicę. Obszar, do którego nikt się nie może zbliżać, obejmuje bowiem m.in. jedyną drogę dojazdową do atrakcji turystycznych tj. latarnia morska czy Fort Gerharda. Pracę może stracić kilkaset osób. 
 </p>

## Nacjonalizacja przemysłu miedziowego w Chile? Sasin chce deklaracji tamtejszego rządu
 - [https://www.bankier.pl/wiadomosc/Nacjonalizacja-przemyslu-miedziowego-w-Chile-Sasin-chce-deklaracji-tamtejszego-rzadu-8523964.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nacjonalizacja-przemyslu-miedziowego-w-Chile-Sasin-chce-deklaracji-tamtejszego-rzadu-8523964.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 07:19:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/a/5b04cad792e494-948-568-0-107-1592-955.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Chcę usłyszeć deklarację rządu Chile, że planowana w tym kraju nacjonalizacja przemysłu miedziowego jest nieaktualna, wyjaśnienia wymaga też podatkowanie wydobycia miedzi - powiedział wicepremier, minister aktywów państwowych Jacek Sasin, który przebywa z wizytą Chile.</p>

## Hakerzy coraz bardziej wyrafinowani. Wykorzystują ofiary do kopania kryptowalut
 - [https://www.bankier.pl/wiadomosc/Hakerzy-coraz-bardziej-wyrafinowani-Wykorzystuja-ofiary-do-kopania-kryptowalut-8523953.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Hakerzy-coraz-bardziej-wyrafinowani-Wykorzystuja-ofiary-do-kopania-kryptowalut-8523953.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 07:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/c/d2f098270fcdef-948-567-0-0-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Cyberprzestępcy znaleźli nowy sposób, aby nakłonić ludzi do pobrania i
zainstalowania złośliwego oprogramowania, które będzie wykorzystywało procesory
ofiar do kopania kryptowalut.</p>

## Szpiegowanie online to dobry biznes. A perspektywy są jeszcze lepsze
 - [https://www.bankier.pl/wiadomosc/Szpiegowanie-online-to-dobry-biznes-A-perspektywy-sa-jeszcze-lepsze-8523924.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Szpiegowanie-online-to-dobry-biznes-A-perspektywy-sa-jeszcze-lepsze-8523924.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 06:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/b/abfcc7784746f3-945-560-78-86-1421-852.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Inwigilacja niemal na wyciągnięcie ręki - zagrożenie cyfrową inwigilacją nigdy nie było tak wielkie jak dzisiaj. Coraz więcej firm oferuje tzw. spyware, a klientów nie brakuje - pisze poniedziałkowa "Rzeczpospolita".</p>

## Dobry marzec dla Votum. Prawie 1600 nowych klientów walczących z bankami
 - [https://www.bankier.pl/wiadomosc/Votum-w-III-pozyskalo-1-582-umow-w-segmencie-dochodzenia-roszczen-z-tytulu-umow-bankowych-8523937.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Votum-w-III-pozyskalo-1-582-umow-w-segmencie-dochodzenia-roszczen-z-tytulu-umow-bankowych-8523937.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 06:08:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/e/bcf9a172e4087f-948-568-0-100-1600-959.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Grupa Votum w marcu w segmencie dochodzenia roszczeń z tytułu umów bankowych podpisała 1.582 nowych umów - poinformowała spółka we wstępnych danych.</p>

## Prezesi spółek, obcokrajowiec i bezdomny, zatrzmani w śledztwie KAS
 - [https://www.bankier.pl/wiadomosc/Prezesi-spolek-obcokrajowiec-i-bezdomny-zatrzmani-w-sledztwie-KAS-8523932.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Prezesi-spolek-obcokrajowiec-i-bezdomny-zatrzmani-w-sledztwie-KAS-8523932.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 06:01:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/0/818098301dd7ab-790-473-10-12-790-473.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Obcokrajowiec i bezdomny byli prezesami fasadowych spółek, których zatrzymano w związku z oszustwami podatkowymi i praniem pieniędzy. W śledztwie KAS przesłuchiwani będą także współwłaściciele firm i księgowa. </p>

## Grupa CCC notuje znaczną stratę za rok 2022/23
 - [https://www.bankier.pl/wiadomosc/Grupa-CCC-miala-w-2022-23-417-6-mln-zl-straty-netto-j-d-8523922.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Grupa-CCC-miala-w-2022-23-417-6-mln-zl-straty-netto-j-d-8523922.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 05:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/8/050459ea9c8d06-948-568-0-48-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Grupa CCC miała w roku obrotowym 2022/23, czyli w okresie luty 2022 - styczeń 2023 r., 417,6 mln zł straty netto jednostki dominującej wobec 223,4 mln zł straty w analogicznym okresie rok wcześniej - podała spółka w raporcie rocznym.</p>

## Zjednoczona Prawica z silnym poparciem. KO ma 11 punktów proc. straty
 - [https://www.bankier.pl/wiadomosc/Zjednocona-Prawica-z-silnym-poparciem-KO-ma-11-proc-straty-8523920.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zjednocona-Prawica-z-silnym-poparciem-KO-ma-11-proc-straty-8523920.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 05:47:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/9/8e4c8569866203-948-568-0-61-4096-2457.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zjednoczona Prawica cieszy się 39 proc. poparciem. Na KO zagłosowałoby 28 proc., na Lewicę 9 proc., na Konfederację i Polskę 2050 po 8 proc. W Sejmie znalazłby się także PSL z 5-proc. poparciem - wynika z sondażu Social Changes, zrealizowanego na zlecenie portalu wPolityce.pl i opublikowanego w tygodniku "Sieci".</p>

## Spore zmiany w Agencji Mienia Wojskowego. Chodzi m.in. o nieruchomości
 - [https://www.bankier.pl/wiadomosc/Spore-zmiany-w-Agencji-Mienia-Wojskowego-Chodzi-m-in-o-nieruchomosci-8523913.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Spore-zmiany-w-Agencji-Mienia-Wojskowego-Chodzi-m-in-o-nieruchomosci-8523913.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 05:29:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/2/2cb54b76d59a21-948-568-0-170-3983-2390.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Więcej zadań, które MON może zlecać Agencji Mienia Wojskowego, dostosowanie do rynku nieruchomości, zniesienie obowiązku publikacji w prasie ogłoszeń o przetargach to niektóre z założeń przygotowywanego projektu nowelizacji ustawy o AMW.</p>

## Dopłaty roczne trafiły już na konta uczestników PPK
 - [https://www.bankier.pl/wiadomosc/Doplaty-roczne-trafily-juz-na-konta-uczestnikow-PPK-8523907.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Doplaty-roczne-trafily-juz-na-konta-uczestnikow-PPK-8523907.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 05:12:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/f/ba5adf722093f8-924-554-0-87-924-554.png" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ponad 1,7 mln uczestników Pracowniczych Planów Kapitałowych otrzymało od państwa dopłaty roczne za 2022 rok. Łacznie na rachunki przelano 410,3 mln zł – poinformował PAP Robert Zapotoczny, prezes PFR Portal PPK.</p>

## Dłużnicy czynszowi nie płacą też za telefon, TV czy prąd. "Kolejny zaległy rachunek na liście"
 - [https://www.bankier.pl/wiadomosc/Dluznicy-czynszowi-nie-placa-tez-za-telefon-TV-czy-prad-8523903.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Dluznicy-czynszowi-nie-placa-tez-za-telefon-TV-czy-prad-8523903.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 05:01:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/f/0bde8268fd854a-948-568-123-78-4376-2625.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zaległości finansowe Polaków z tytułu czynszu i wszelkich opłat związanych z użytkowaniem lokalu mieszkalnego sięgają 290,8 mln zł - wynika z danych Krajowego Rejestru Długów. Dodano, że większość dłużników czynszowych nie płaci też za telefon, telewizję czy energię elektryczną.</p>

## Najlepsze konta oszczędnościowe. W czterech bankach można zgarnąć 8 proc. rocznie
 - [https://www.bankier.pl/wiadomosc/Ranking-kont-oszczednosciowych-kwiecien-2023-Najlepsze-konto-oszczednosciowe-8522693.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ranking-kont-oszczednosciowych-kwiecien-2023-Najlepsze-konto-oszczednosciowe-8522693.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/b/859abaf2229ca7-948-568-7-378-2959-1775.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Poszukujący okazji na koncie oszczędnościowym mogą liczyć na stawkę sięgającą 8 proc. w skali roku. Taką ofertę mają obecnie cztery banki. Jeden z nich proponuje rekordowy czas naliczania promocyjnej stawki, bo 6 miesięcy.</p>

## Najtańsze konto wspierające biznes
 - [https://www.bankier.pl/wiadomosc/Najtansze-konto-wspierajace-biznes-8522023.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Najtansze-konto-wspierajace-biznes-8522023.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/4/9d26abe599a66e-948-568-0-158-3023-1813.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prowadzenie firmy nie musi dotyczyć wyłącznie sprzedaży produktów i świadczenia usług na krajowym rynku. Wyjście z działalnością poza granice Polski wiąże się z koniecznością posiadania rachunku w walucie obcej umożliwiającej rozliczenia np. w euro. Przeanalizowaliśmy, na co mogą liczyć przedsiębiorcy, którzy szukają najtańszej oferty konta firmowego umożliwiającego rozwój za granicą.</p>

## U deweloperów nadal zima bez odwilży. „Nie spieszą się z odmrażaniem inwestycji”
 - [https://www.bankier.pl/wiadomosc/U-deweloperow-nadal-zima-bez-odwilzy-Nie-spiesza-sie-z-odmrazaniem-inwestycji-8523249.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/U-deweloperow-nadal-zima-bez-odwilzy-Nie-spiesza-sie-z-odmrazaniem-inwestycji-8523249.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/f/300a816aa3b634-948-568-24-59-1949-1169.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Pomimo rosnącej kwartalnie sprzedaży mieszkań oraz możliwości kredytowych klientów, które mogłyby być symptomami odwilży na rynku nieruchomości, deweloperzy nie spieszą się ani z rozpoczynaniem nowych inwestycji, ani z wystawianiem na sprzedaż mieszkań już zbudowanych.</p>

## Minister finansów USA: Rosja powinna zapłacić za szkody na Ukrainie
 - [https://www.bankier.pl/wiadomosc/Minister-finansow-USA-Rosja-powinna-zaplacic-za-szkody-na-Ukrainie-8523899.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Minister-finansow-USA-Rosja-powinna-zaplacic-za-szkody-na-Ukrainie-8523899.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-04-17 04:37:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/5/0b29065059eb79-945-560-0-252-4564-2738.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />"Uważam, że Rosja powinna zapłacić za szkody, które wyrządziła na Ukrainie" - powiedziała w niedzielę sekretarz skarbu USA Janet Yellen w wywiadzie telewizyjnym. Jednak względem żądań Kijowa o konfiskatę rosyjskich aktywów była sceptycznie nastawiona.</p>

