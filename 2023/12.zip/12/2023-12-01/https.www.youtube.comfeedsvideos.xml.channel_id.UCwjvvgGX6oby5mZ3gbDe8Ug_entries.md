# Source:China Insights, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwjvvgGX6oby5mZ3gbDe8Ug, language:en-US

## CCP: "Visa-free for 6 countries, welcome to China!" White lung reappears, the tsunami strikes again
 - [https://www.youtube.com/watch?v=zErU5erELTw](https://www.youtube.com/watch?v=zErU5erELTw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwjvvgGX6oby5mZ3gbDe8Ug
 - date published: 2023-12-01T17:28:38+00:00

#Chinainsights#Chinanews
As 2023 comes to an end, it looks like the epidemic is once again hitting mainland China on a large scale. The Chinese government has various labels for it, such as Mycoplasma Pneumonia," "Influenza," "New Coronavirus," etc. Many children's hospitals across China are overwhelmed. 
The Beijing government doesn't seem to think it’s serious. Rather, it’s inviting more international travelers to come to China.

Have questions? Do you have something to share with us about China? We want to hear from you! 
Email: Cinsights.subscription@gmail.com
Facebook www.facebook.com/EyesOnChina.

Your support allows us to produce more high-quality videos. 

Copyright @ China Insights 2021. Any illegal reproduction of this content in any form will result in immediate action against the person(s) concerned.

