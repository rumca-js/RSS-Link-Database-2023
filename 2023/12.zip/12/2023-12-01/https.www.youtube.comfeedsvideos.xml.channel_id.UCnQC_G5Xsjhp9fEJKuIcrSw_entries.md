# Source:Ben Shapiro, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw, language:en-US

## The Debate America Deserves
 - [https://www.youtube.com/watch?v=XJJM-oi1Jwc](https://www.youtube.com/watch?v=XJJM-oi1Jwc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-12-01T22:30:05+00:00



## DeSantis DeSLAMS Newsom
 - [https://www.youtube.com/watch?v=sadFPO7hbss](https://www.youtube.com/watch?v=sadFPO7hbss)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-12-01T22:00:27+00:00

In last nights debate, Ron DeSantis was seemingly victorious in his debate against Gavin Newsom. This wasn't necessarily the debate that America needed, but it certainly was one that America deserves.

1️⃣ Click here to join the member-exclusive portion of my show: https://get.dailywireplus.com/member-block/ben-shapiro

2️⃣ Become a DailyWire+ member to gain access to movies, shows, documentaries, and more: https://bit.ly/3lfVtwK 

3️⃣ Watch the full episode here: Ep.1860 - https://youtu.be/7SEzGcMHmFM

👕 Get your Ben Shapiro merch here: https://bit.ly/3TAu2cw

🔴Today's Sponsors🔴

Hallow - Try Hallow for 3 months FREE: https://hallow.com/shaprio

Good Ranchers - Save an additional 10% off the December Sale! Use promo code SHAPIRO at checkout. https://bit.ly/403CbJC

#BenShapiro #TheBenShapiroShow #News #Politics #DailyWire #Debate #RonDeSantis #DeSantis #Newsom #GavinNewsom #California #Florida #Left #Right #Conservative

## How Montana Tucker Entered the Anti-Semitism Fight
 - [https://www.youtube.com/watch?v=Q5s3Xsg9_vU](https://www.youtube.com/watch?v=Q5s3Xsg9_vU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-12-01T20:00:15+00:00



## Reaction to 'Lady Ballers' Trailer
 - [https://www.youtube.com/watch?v=_Lvz8TimmLc](https://www.youtube.com/watch?v=_Lvz8TimmLc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-12-01T18:00:31+00:00



## The Debate America Deserves
 - [https://www.youtube.com/watch?v=7SEzGcMHmFM](https://www.youtube.com/watch?v=7SEzGcMHmFM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-12-01T18:00:08+00:00

Ron DeSantis takes on Gavin Newsom on Fox News – and it doesn’t go well for the California governor; as Elon Musk goes to war with politically-motivated boycotts, The Daily Wire increases its ad spend on X; and the Biden administration puts the screws to Israel.

Ep.1860

- - -

1️⃣  Click here to join the member exclusive portion of my show:  https://bit.ly/41LQK62

2️⃣  Become a DailyWire+ member to gain access to movies, shows, documentaries, and more: https://utm.io/ueMfc 

3️⃣ Watch the official Lady Ballers movie trailer now: https://bit.ly/3R1dM5b

🔴 Today's Sponsors 🔴

ExpressVPN - Get 3 Months FREE of ExpressVPN: https://expressvpn.com/ben

Birch Gold - Text "BEN" to 989898 to check out Birch Gold’s Holiday Deals! Get FREE Silver today! http://www.birchgold.com/Ben 

Hallow - Try Hallow for 3 months FREE: https://hallow.com/shapiro

Good Ranchers - Save an additional 10% off the December Sale! Use promo code SHAPIRO at checkout. https://bit.ly/416NvWW 

Beam - Get 50% off fo

## Elon Takes Shots at Bob Iger
 - [https://www.youtube.com/watch?v=wbpAEAA2tfo](https://www.youtube.com/watch?v=wbpAEAA2tfo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-12-01T02:00:32+00:00



## Henry Kissinger Dead at 100
 - [https://www.youtube.com/watch?v=7_wKToTcfas](https://www.youtube.com/watch?v=7_wKToTcfas)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-12-01T00:00:04+00:00

Henry Kissinger, the former secretary of state, died recently at age 100. Henry was a fascinating character.

1️⃣ Click here to join the member-exclusive portion of my show: https://get.dailywireplus.com/member-block/ben-shapiro

2️⃣ Become a DailyWire+ member to gain access to movies, shows, documentaries, and more: https://bit.ly/3lfVtwK 

3️⃣ Watch the full episode here: Ep.1859 - https://youtu.be/KqF-eXeDt7c

👕 Get your Ben Shapiro merch here: https://bit.ly/3TAu2cw

🔴Today's Sponsors🔴

PureTalk - Get a FREE Moto-G 5G phone when you switch to PureTalk at https://www.puretalkusa.com/landing/shapiro 

Tax Network USA - Take the first step toward resolving your tax debt!
http://www.TaxNetworkUSA.com/Shapiro 

#BenShapiro #TheBenShapiroShow #News #Politics #DailyWire #HenryKissinger #Secretary #SecretaryOfState #Congress #Politcal #Henry #100 #100YearsOld #Conservative #Democrat

