# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Agencja S&P potwierdziła rating Polski na poziomie "A-"
 - [https://www.bankier.pl/wiadomosc/Agencja-S-P-potwierdzila-rating-Polski-na-poziomie-A-8656795.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Agencja-S-P-potwierdzila-rating-Polski-na-poziomie-A-8656795.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-01T21:22:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/2/4972d5fee1621b-948-568-82-292-2850-1709.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Agencja S&amp;P Global Ratings potwierdziła długoterminowy rating Polski w walucie obcej na poziomie "A-" - poinformowała agencja w komunikacie. Perspektywa ratingu pozostała stabilna.</p>

## Powell mówi, a rynek się śmieje. Stopy w dół, złoto blisko rekordu
 - [https://www.bankier.pl/wiadomosc/Powell-mowi-a-rynek-sie-smieje-Stopy-w-dol-zloto-blisko-rekordu-8656785.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Powell-mowi-a-rynek-sie-smieje-Stopy-w-dol-zloto-blisko-rekordu-8656785.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-01T20:54:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/3/b0e58635bec05e-948-568-0-81-2509-1505.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Szef Rezerwy Federalnej usiłował w piątek skontrować rynkowe
oczekiwania na obniżki stóp procentowych. Powiedzieć, że chyba mu nie wyszło,
to jak nic nie powiedzieć.</p>

## Co ma Szymon Hołownia. Oto majątek nowego marszałka Sejmu
 - [https://www.bankier.pl/wiadomosc/Oswiadczenie-majatkowe-marszalka-Szymona-Holowni-8656707.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Oswiadczenie-majatkowe-marszalka-Szymona-Holowni-8656707.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-01T17:25:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/e/80c5fb257228a7-948-568-14-66-2919-1751.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Szymon Hołownia, jako poseł-debiutant, po raz pierwszy opublikował swoje
 oświadczenie majątkowe. Marszałek Sejmu jest właścicielem kilku 
nieruchomości, ma też oszczędności i zobowiązania. Zerkamy na szczegóły.</p>

## Danone i Nestle pod ostrzałem. "Podnosili ceny szybciej, niż rosły koszty"
 - [https://www.bankier.pl/wiadomosc/Danone-i-Nestle-pod-ostrzalem-Podnosili-ceny-szybciej-niz-rosly-koszty-8656723.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Danone-i-Nestle-pod-ostrzalem-Podnosili-ceny-szybciej-niz-rosly-koszty-8656723.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-01T17:18:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/1/40a60d864c8e05-948-568-7-2-992-595.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Brytyjski urząd ds. Konkurencji (CMA) ustalił, że najwięksi producenci mleka dla niemowląt, Danone i Nestle, podnosili jego ceny szybciej, niż rosły koszty produkcji. Ceny mleka dla niemowląt w ciągu dwóch lat wzrosły o 25 proc. - twierdzi portal dziennika "Guardian". Szef jednej z sieci spożywczych nazwał działania producentów "wyzyskiem" i zażądał wprowadzenia kontroli cen.</p>

## Macron na COP28: Państwa G7 powinny do 2030 r. zrezygnować z węgla
 - [https://www.bankier.pl/wiadomosc/Macron-na-COP28-Panstwa-G7-powinny-do-2030-r-zrezygnowac-z-wegla-8656714.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Macron-na-COP28-Panstwa-G7-powinny-do-2030-r-zrezygnowac-z-wegla-8656714.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-01T17:07:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/c/7a757f887db678-948-568-0-40-2048-1228.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Państwa grupy G7 powinny dać przykład światu i do 2030 roku zrezygnować z wykorzystywania węgla jako źródła energii; kontynuowanie inwestycji w branżę węglową jest absurdem w odniesieniu do naszego celu, czyli walki z globalnym ociepleniem - oświadczył w piątek prezydent Francji Emmanuel Macron, który bierze udział w konferencji klimatycznej COP28 w Dubaju.</p>

## Kryptowaluty za miliony. Sławomir Mentzen pokazał swój majątek
 - [https://www.bankier.pl/wiadomosc/Kryptowaluty-za-miliony-Slawomir-Mentzen-pokazal-swoj-majatek-8656681.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kryptowaluty-za-miliony-Slawomir-Mentzen-pokazal-swoj-majatek-8656681.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-01T17:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/3/c6e2221ee1572b-948-568-0-131-4009-2405.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sławomir Mentzen został posłem X kadencji. Z tego powodu musiał pokazać 
swój majątek. Zerkamy w oświadczenie majątkowe szefa Konfederacji.</p>

## Kontrowersyjny kongresmen wydalony z Izby Reprezentantów. W tle defraudacje i zmyślona biografia
 - [https://www.bankier.pl/wiadomosc/Kontrowersyjny-kongresmen-wydalony-z-Izby-Reprezentantow-W-tle-defraudacje-i-zmyslona-biografia-8656695.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kontrowersyjny-kongresmen-wydalony-z-Izby-Reprezentantow-W-tle-defraudacje-i-zmyslona-biografia-8656695.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-01T16:51:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/e/55ef8335e4f3f0-948-568-560-463-2310-1385.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Izba Reprezentantów Stanów Zjednoczonych zdecydowała w piątek o usunięciu ze swoich szeregów kongresmena Republikanów George'a Santosa z Nowego Jorku, oskarżonego o zdefraudowanie pieniędzy na kampanię wyborczą oraz sfabrykowanie dużej części swojej biografii.</p>

## Emerytura, zegarek i zero nieruchomości. Donald Tusk złożył oświadczenie majatkowe
 - [https://www.bankier.pl/wiadomosc/Donald-Tusk-zlozyl-oswiadczenie-majatkowe-Co-posiada-8656642.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Donald-Tusk-zlozyl-oswiadczenie-majatkowe-Co-posiada-8656642.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-01T15:48:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/e/103738baa2d35c-948-568-0-104-4648-2788.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Donald Tusk jako poseł Sejmu X kadencji złożył oświadczenie majątkowe. 
Sprawdzamy, jaki majątek ma szef Koalicji Obywatelskiej i przyszły 
premier, który ostatnie kilka lat spędził w Brukseli.</p>

## Darmowe konto i premia 350 zł. Tyle oferuje na święta Citi Handlowy
 - [https://www.bankier.pl/wiadomosc/Citi-Handlowy-daje-350-zl-za-darmowe-konto-osobiste-8656525.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Citi-Handlowy-daje-350-zl-za-darmowe-konto-osobiste-8656525.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-01T14:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/d/e111b81633d33e-948-568-0-181-2020-1212.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Otwarcie darmowego CitiKonta może okazać się opłacalne nie tylko da osób, które poszukują konta osobistego bez żadnych opłat podstawowych, ale również dla polujących na atrakcyjne promocje bankowe. Do zyskania jest bowiem 350 zł premii pieniężnej.</p>

## Identyfikator chińskiego więźnia w podszewce płaszcza brytyjskiej firmy
 - [https://www.bankier.pl/wiadomosc/Identyfikator-chinskiego-wieznia-w-podszewce-plaszcza-brytyjskiej-firmy-8656531.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Identyfikator-chinskiego-wieznia-w-podszewce-plaszcza-brytyjskiej-firmy-8656531.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-01T13:57:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/5/fd08f4487e72db-905-542-57-117-905-542.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Mieszkanka angielskiego Derbyshire znalazła w płaszczu kupionym w internecie identyfikator więźnia z Chin — podaje dziennik "Guardian" w piątek. Incydent budzi obawy, że firma Regatta może wykorzystywać w swoim łańcuch dostaw przymusową pracę chińskich więźniów.</p>

## Szef PSL o proteście na granicy: będziemy stać po stronie polskich transportowców
 - [https://www.bankier.pl/wiadomosc/Szef-PSL-o-protescie-na-granicy-bedziemy-stac-po-stronie-polskich-transportowcow-8656530.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Szef-PSL-o-protescie-na-granicy-bedziemy-stac-po-stronie-polskich-transportowcow-8656530.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-01T13:57:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/7/f8c76920f1ca4f-948-568-0-61-2048-1228.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Będziemy stać po stronie polskich transportowców, szanując naszych partnerów z Ukrainy – zapowiedział prezes PSL Władysław Kosiniak-Kamysz odnosząc się do trwającego od 6 listopada protestu polskich przewoźników na granicy z Ukrainą.</p>

## Dzień rekordów na GPW. WIG20 cały na zielono
 - [https://www.bankier.pl/wiadomosc/Dzien-rekordow-na-GPW-WIG20-caly-na-zielono-8656476.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Dzien-rekordow-na-GPW-WIG20-caly-na-zielono-8656476.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-01T12:56:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/6/7af2944b53d729-948-568-1004-578-3363-2018.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W wybornych nastrojach inwestujący na GPW zaczynają nowy miesiąc. Pierwsza sesja grudnia przyniosła wysyp rekordów na kilku indeksach, w tym przede wszystkim nowy szczyt wszech czasów na WIG. Kursy wszystkich spółek z WIG20 świecą na zielono, a giełdowy wózek najmocniej ciągną w górę banki, górnictwo i energetyka.</p>

## Trzy nowe podmioty na liście ostrzeżeń publicznych KNF
 - [https://www.bankier.pl/wiadomosc/Trzy-nowe-podmioty-na-liscie-ostrzezen-publicznych-KNF-8656462.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Trzy-nowe-podmioty-na-liscie-ostrzezen-publicznych-KNF-8656462.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-01T12:48:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/b/4c1ce1b7235374-948-568-0-258-4500-2699.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Komisja Nadzoru Finansowego przekazała w piątek, że na listę ostrzeżeń publicznych wpisano kolejne podmioty: 360DA LTD, Teletrade Polska sp. z o.o., Platforma General Trust Group.</p>

## "The Guardian" ujawnił plany branży mięsnej na COP28
 - [https://www.bankier.pl/wiadomosc/The-Guardian-ujawnil-plany-branzy-miesnej-na-COP28-8656460.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/The-Guardian-ujawnil-plany-branzy-miesnej-na-COP28-8656460.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-01T12:47:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/1/c60dce631144c0-948-568-108-144-1242-745.png" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Lobbyści producentów mięsa i produktów mleczarskich będą przekonywać uczestników rozpoczętego w Dubaju szczytu klimatycznego COP28, że produkcja żywności odzwierzęcej jest korzystna dla środowiska i stanowi element "zrównoważonej diety" - ujawnił brytyjski dziennik "The Guardian", któremu razem z organizacją DeSmog udało się dotrzeć do strategii PR branży mięsnej.</p>

## Pierwszy na świecie ambasador talibów obejmuje placówkę w Chinach
 - [https://www.bankier.pl/wiadomosc/Pierwszy-na-swiecie-ambasador-talibow-obejmuje-placowke-w-Chinach-8656447.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Pierwszy-na-swiecie-ambasador-talibow-obejmuje-placowke-w-Chinach-8656447.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-01T12:33:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/7/c3bc2eb98f7a21-948-567-5-2-995-596.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Talibańska administracja mianowała swojego byłego rzecznika na ambasadora w Chinach – poinformowało w piątek afgańskie ministerstwo spraw zagranicznych. Jest to pierwszy od czasu przejęcia władzy w 2021 r. przez muzułmańskich radykałów oficjalnie akredytowany wysłannik do jakiegokolwiek kraju.</p>

## Hołownia o "ustawie wiatrakowej": sięga do źródła problemu, a nie tylko do skutków
 - [https://www.bankier.pl/wiadomosc/Holownia-o-ustawie-wiatrakowej-siega-do-zrodla-problemu-a-nie-tylko-do-skutkow-8656421.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Holownia-o-ustawie-wiatrakowej-siega-do-zrodla-problemu-a-nie-tylko-do-skutkow-8656421.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-01T12:09:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/8/b257d07209c1cf-948-568-0-49-1984-1190.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Projekt poselski dot. elektrowni wiatrowych, który został wniesiony do Senatu jest procedowany. W tej chwili trwają nad nim prace wnioskodawców, być może zostaną zgłoszone autopoprawki dotyczące najbardziej spornych kwestii - powiedział w piątek podczas konferencji prasowej marszałek Sejmu Szymon Hołownia.</p>

## Awaria w Banku Millennium. Nie działa aplikacja mobilna
 - [https://www.bankier.pl/wiadomosc/Awaria-w-Banku-Millennium-Nie-dziala-aplikacja-mobilna-8656365.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Awaria-w-Banku-Millennium-Nie-dziala-aplikacja-mobilna-8656365.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-01T11:21:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/8/62d58160ae8e8d-948-568-0-433-3578-2147.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Bank Millennium boryka się aktualnie z awarią bankowości mobilnej. Informacje o problemach potwierdza na ekranie logowania do aplikacji mobilnej. </p>

## Donald Tusk wskazał, kiedy prawdopodobnie odbędzie się zaprzysiężenie nowego premiera
 - [https://www.bankier.pl/wiadomosc/Donald-Tusk-wskazal-kiedy-prawdopodobnie-odbedzie-sie-zaprzysiezenie-nowego-premiera-8656348.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Donald-Tusk-wskazal-kiedy-prawdopodobnie-odbedzie-sie-zaprzysiezenie-nowego-premiera-8656348.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-01T11:09:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/f/7a62dc73c47ddf-948-568-0-82-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Spodziewajcie się państwo wyboru nowego rządu 11 grudnia, a jeśli czas na to nie pozwoli, 12 grudnia expose nowego premiera, a zaprzysiężenie zakładamy 13 grudnia  - powiedział w piątek lider PO Donald Tusk.</p>

## PiS broni prezesa Narodowego Banku Polskiego. Wpłynął wniosek do TK
 - [https://www.bankier.pl/wiadomosc/PiS-broni-prezesa-Narodowego-Banku-Polskiego-Wplynal-wniosek-do-TK-8656342.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PiS-broni-prezesa-Narodowego-Banku-Polskiego-Wplynal-wniosek-do-TK-8656342.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-01T11:02:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/d/60139ab8953232-948-568-0-133-2048-1228.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Do Trybunału Konstytucyjnego wpłynął wniosek posłów PiS o zbadanie zgodności z Konstytucją zapisów ustawy o Trybunale Stanu dotyczących pociągnięcia do odpowiedzialności konstytucyjnej Prezesa NBP - poinformowano w piątek na stronie TK.</p>

## Węgry bliskie odblokowania unijnych dotacji. Chodzi o 10 mld euro
 - [https://www.bankier.pl/wiadomosc/Wegry-bliskie-odblokowania-unijnych-dotacji-Chodzi-o-10-mld-euro-8656341.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wegry-bliskie-odblokowania-unijnych-dotacji-Chodzi-o-10-mld-euro-8656341.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-01T11:01:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/8/668e32f6d9f365-948-568-0-18-2508-1504.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kierowany przez Viktora Orbana rząd Węgier jest bliski spełnienia warunków Komisji Europejskiej w zakresie reformy sądownictwa, co doprowadzi do odblokowania 10 mld euro zamrożonych środków unijnych, być może jeszcze w tym roku – napisał dziennik „Nepszava”.</p>

## Tym będą żyły rynki: tydzień z amerykańskim rynkiem pracy
 - [https://www.bankier.pl/wiadomosc/Tym-beda-zyly-rynki-tydzien-z-amerykanskim-rynkiem-pracy-8656313.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tym-beda-zyly-rynki-tydzien-z-amerykanskim-rynkiem-pracy-8656313.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-01T11:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/c/2ea78453abf830-948-568-69-134-1662-997.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Motywem przewodnim nadchodzącego tygodnia powinny stać się dane z amerykańskiego rynku pracy. Od wtorku będą napływać kolejne raporty pokazujące, czy największa gospodarka świata jest równie „gorąca” co w poprzednich miesiącach.
</p>

## Rząd podjął decyzję ws. "Bezpiecznego kredytu 2 proc."
 - [https://www.bankier.pl/wiadomosc/Rzad-podjal-decyzje-ws-Bezpiecznego-kredyt-2-proc-8656324.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rzad-podjal-decyzje-ws-Bezpiecznego-kredyt-2-proc-8656324.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-01T10:44:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/e/06f30e5c2ace29-948-568-12-0-4838-2903.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zdecydowaliśmy się o zwiększeniu finansowania projektu "Bezpieczny kredyt 2 proc." - poinformował w piątek premier Mateusz Morawiecki. Dodał, że mieszkanie powinno być takim towarem, na który stać każdego Polaka, który uczciwie pracuje.
</p>

## W sklepach ma być więcej lokalnych produktów. Oto szczegóły projektu ustawy
 - [https://www.bankier.pl/wiadomosc/W-sklepach-ma-byc-wiecej-lokalnych-produktow-Oto-szczegoly-projektu-ustawy-8656307.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/W-sklepach-ma-byc-wiecej-lokalnych-produktow-Oto-szczegoly-projektu-ustawy-8656307.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-01T10:18:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/4/f49b46d11e0beb-948-568-0-119-1772-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Lokalne produkty spożywcze, np. mleko, pieczywo, owoce w sklepach mają być oznaczone grafiką polskiej flagi - zakłada opublikowany w piątek projekt ustawy o sprzedaży detalicznej produktów lokalnych. W sklepach ma być więcej lokalnych produktów - dodano.</p>

## Trzeci tydzień spadku cen paliw. Benzyna kosztuje prawie tyle co rok temu
 - [https://www.bankier.pl/wiadomosc/Ceny-paliw-w-Polsce-grudzien-2023-Ile-kosztuje-benzyna-olej-napedowy-i-LPG-8656270.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ceny-paliw-w-Polsce-grudzien-2023-Ile-kosztuje-benzyna-olej-napedowy-i-LPG-8656270.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-01T10:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/2/ee8667b226b701-948-568-0-273-3909-2345.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Benzynę i LPG
tankujemy w zasadzie równo drogo jak rok temu. Wyraźnie tańszy niż 12 miesięcy
temu jest za to olej napędowy.</p>

## Obajtek grzmi po artykule o jego darowiznach. "Sprawę kieruję na drogę prawną"
 - [https://www.bankier.pl/wiadomosc/Obajtek-grzmi-po-artykule-o-jego-darowiznach-Sprawe-kieruje-na-droge-prawna-8656253.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Obajtek-grzmi-po-artykule-o-jego-darowiznach-Sprawe-kieruje-na-droge-prawna-8656253.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-01T09:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/e/a0fa0a5d282898-948-568-0-10-4029-2417.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Mój majątek został wielokrotnie prześwietlony, a to, co komu przekazuję, jest moją prywatną sprawą - oświadczył w piątek prezes Orlenu Daniel Obajtek, komentując artykuł Wirtualnej Polski (WP) o jego darowiznach w postaci nieruchomości. Dodał, że sprawę kieruje na drogę prawną.</p>

## PiS zapowiada wnioski do prokuratury i CBA. Chodzi o "ustawę wiatrakową"
 - [https://www.bankier.pl/wiadomosc/PiS-zapowiada-wnioski-do-prokuratury-i-CBA-Chodzi-o-ustawe-wiatrakowa-8656246.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PiS-zapowiada-wnioski-do-prokuratury-i-CBA-Chodzi-o-ustawe-wiatrakowa-8656246.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-01T09:07:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/d/518fc233597b5a-948-568-26-26-3473-2084.png" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Składamy wniosek do prokuratury regionalnej i Centralnego Biura Antykorupcyjnego, żeby te służby sprawdziły, kto stoi za projektem ustawy ws. cen energii; widać że nie napisali jej posłowie, pytanie, jaka firma ma na tym zarobić - powiedział poseł PiS, szef MEiN Krzysztof Szczucki w piątek.</p>

## Utrudnienia powróciły. Lepiej zaopatrz się w gotówkę
 - [https://www.bankier.pl/wiadomosc/Przerwa-techniczna-w-PKO-Banku-Pekao-mBanku-Nest-Banku-VeloBanku-8656180.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Przerwa-techniczna-w-PKO-Banku-Pekao-mBanku-Nest-Banku-VeloBanku-8656180.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-01T09:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/7/8b91f221a64375-948-568-0-107-1439-863.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Pierwszy weekend grudnia będzie stał pod znakiem przerw technicznych w bankach. Utrudnienia dla swoich klientów zapowiedziało pięć instytucji. Weekendową sztafetę przerw rozpocznie największy polski bank – PKO BP.</p>

## Orlen zostanie sprywatyzowany? Poseł ma inne rozwiązanie
 - [https://www.bankier.pl/wiadomosc/Orlen-zostanie-sprywatyzowany-Posel-ma-inne-rozwiazanie-8656235.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Orlen-zostanie-sprywatyzowany-Posel-ma-inne-rozwiazanie-8656235.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-01T08:53:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/3/a4e1227ab7a0ed-948-568-20-40-3980-2387.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nie ma mowy o tym, by prywatyzować firmę tak strategiczną jak Orlen; należy ją jednak odpartyjnić; do tej pory np. w zależności od sytuacji politycznej manipulowała cenami paliwa na stacjach - powiedział w piątek wiceszef Polski 2050 Michał Kobosko w Programie Trzecim Polskiego Radia.</p>

## Kopalnie poszły na rekord. W październiku najwyższe wydobycie i sprzedaż węgla w tym roku
 - [https://www.bankier.pl/wiadomosc/Kopalnie-poszly-na-rekord-W-pazdzierniku-najwyzsze-wydobycie-i-sprzedaz-wegla-w-tym-roku-8656234.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kopalnie-poszly-na-rekord-W-pazdzierniku-najwyzsze-wydobycie-i-sprzedaz-wegla-w-tym-roku-8656234.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-01T08:52:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/c/fb188879e974b6-948-568-0-230-3543-2125.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W październiku br. miesięczne wydobycie i sprzedaż węgla kamiennego z polskich kopalń były najwyższe w tym roku - wynika z danych Agencji Rozwoju Przemysłu (ARP). W dziesiątym miesiącu roku produkcja węgla przekroczyła 4,8 mln ton, a miesięczna sprzedaż zbliżyła się do 4,7 mln ton.</p>

## Osłabienia złotego. Kurs euro odbija od covidowego dna
 - [https://www.bankier.pl/wiadomosc/Kurs-euro-odbija-od-covidowego-dna-Frank-i-dolar-wyraznie-drozsze-8656225.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kurs-euro-odbija-od-covidowego-dna-Frank-i-dolar-wyraznie-drozsze-8656225.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-01T08:42:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/7/295f3fd3403b8e-948-567-0-25-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kurs euro odbija z najniższych poziomów od marca 2020. Przeciwko naszej walucie
przemawia ostry zwrot na parze euro-dolar.</p>

## Najdłuższa recesja w polskim przemyśle dobiega końca. Ożywienie stoi tuż za rogiem?
 - [https://www.bankier.pl/wiadomosc/PMI-Polska-listopad-2023-8656189.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PMI-Polska-listopad-2023-8656189.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-01T08:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/5/d50de5fc149f67-948-568-38-115-1881-1128.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Mocny wzrost wskaźnika PMI dla polskiego sektora wytwórczego
 jest zapowiedzią poprawy koniunktury w
2024 roku. Powoli dobiega końca najdłuższa recesja w polskim przemyśle.</p>

## To temu politykowi Polacy ufają najbardziej. Prezydent na piątej pozycji
 - [https://www.bankier.pl/wiadomosc/To-temu-politykowi-Polacy-ufaja-najbardziej-Prezydent-na-piatej-pozycji-8656188.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/To-temu-politykowi-Polacy-ufaja-najbardziej-Prezydent-na-piatej-pozycji-8656188.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-01T07:47:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/2/f542f904a19a4e-948-568-17-103-2595-1557.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Szymon Hołownia po raz pierwszy znajduje się na czele rankingu zaufania osiągając 49 proc. pozytywnych wskazań. Prezydent Andrzej Duda pierwszy raz od ośmiu lat znalazł się poza podium - na piątym miejscu. Zaufanie dla prezydenta wyraziło 39 proc. badanych - wynika z sondażu IBRIS dla Onetu.</p>

## Zapłacimy więcej za ubezpieczenie samochodu. I to nie z winy kierowców
 - [https://www.bankier.pl/wiadomosc/Zaplacimy-wiecej-za-ubezpieczenie-samochodu-I-to-nie-z-winy-kierowcow-8656169.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zaplacimy-wiecej-za-ubezpieczenie-samochodu-I-to-nie-z-winy-kierowcow-8656169.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-01T07:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/2/212e9521eb6556-945-560-0-0-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Choć liczba wypadków na polskich drogach jest coraz
mniejsza, to właściciele pojazdów już niedługo mogą zapłacić więcej za ich
ubezpieczenie – wynika z raportu Ubezpieczeniowego Funduszu Gwarancyjnego.</p>

## Polska firma po 20 latach działalności ogłosiła upadłość. W listopadzie otworzyła jeszcze sklep
 - [https://www.bankier.pl/wiadomosc/Neonet-oglasza-upadlosc-po-20-latach-dzialalnosci-8656151.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Neonet-oglasza-upadlosc-po-20-latach-dzialalnosci-8656151.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-01T06:17:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/5/f68f3373bbf366-948-568-0-110-1772-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sąd Rejonowy we Wrocławiu wpisał do repertorium Krajowego Rejestru Zadłużonych wniosek o ogłoszenie upadłości sieci Neonet. Firma jeszcze w ostatnich dniach listopada otworzyła nowy sklep. Według nieoficjalnych informacji przedsiębiorstwo zamierza przeprowadzić restrukturyzację.</p>

## Miliarderzy wcale nie są tacy przedsiębiorczy? Połowę majątku zgromadzili przez dziedziczenie
 - [https://www.bankier.pl/wiadomosc/Miliarderzy-wcale-nie-sa-tacy-przedsiebiorczy-Polowe-majatku-zgromadzili-przez-dziedziczenie-8656150.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Miliarderzy-wcale-nie-sa-tacy-przedsiebiorczy-Polowe-majatku-zgromadzili-przez-dziedziczenie-8656150.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-01T06:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/3/659926baea3924-948-568-2-104-997-598.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ponad połowa majątku miliarderów została zgromadzona przez dziedziczenie. To pierwsza taka sytuacja od początku historii przeprowadzania badań UBS Billionaire Ambitions Report 2023. 65 proc. miliarderów uważa AI, za jedną z największych szans dla prowadzonej działalności.</p>

## Tyle osób w Polsce pobierało świadczenia emerytalno-rentowe
 - [https://www.bankier.pl/wiadomosc/Tyle-osob-w-Polsce-pobieralo-swiadczenia-emerytalno-rentowe-8656135.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tyle-osob-w-Polsce-pobieralo-swiadczenia-emerytalno-rentowe-8656135.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-01T05:54:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/8/068699c28ab3b1-948-568-0-181-2688-1612.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W grudniu 2022 r. w Polsce było 2,3 mln osób pobierających świadczenia emerytalno-rentowe lub zgłoszonych do ubezpieczenia przez płatników składek w ZUS, które posiadały orzeczenie o niepełnosprawności, stopniu niepełnosprawności albo o stopniu niezdolności do pracy - wynika z danych GUS.</p>

## Hakerzy wykradli dane pacjentów z ALAB. Zażądali kilkuset tysięcy dolarów okupu
 - [https://www.bankier.pl/wiadomosc/Hakerzy-wykradli-dane-pacjentow-z-ALAB-Zazadali-kilkuset-tysiecy-dolarow-okupu-8656127.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Hakerzy-wykradli-dane-pacjentow-z-ALAB-Zazadali-kilkuset-tysiecy-dolarow-okupu-8656127.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-01T05:43:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/e/299380f72296e4-929-557-70-2-929-557.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Warszawska Prokuratura Regionalna wszczęła śledztwo w sprawie hakerów, którzy wykradli dane pacjentów Alab Laboratoria. Śledztwo obejmuje również wątek dotyczący żądania okupu. Jak nieoficjalnie ustaliła PAP, szantażyści zażądali od firmy kilkuset tysięcy dolarów.</p>

## Firma z branży recyklingu wskazuje, ile w Polsce powinna wynosić kaucja
 - [https://www.bankier.pl/wiadomosc/Firma-z-branzy-recyklingu-wskazuje-ile-w-Polsce-powinna-wynosic-kaucja-8656114.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Firma-z-branzy-recyklingu-wskazuje-ile-w-Polsce-powinna-wynosic-kaucja-8656114.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-01T05:31:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/c/e0f49b1b367881-948-568-2-5-997-598.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zaproponowana przez resort klimatu stawka 50 gr. kaucji za butelki ze szkła i plastiku oraz metalowe puszki wydaje się za niska, bardziej odpowiednią kwotą jest 1 zł - przekonuje Anna Sapota z firmy Tomra komentując dla PAP ostatnią propozycję MKiŚ.</p>

## Praca natychmiastowa coraz popularniejsza. Zyskują pracodawcy i pracownicy
 - [https://www.bankier.pl/wiadomosc/Praca-natychmiastowa-coraz-popularniejsza-Zyskuja-pracodawcy-i-pracownicy-8656112.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Praca-natychmiastowa-coraz-popularniejsza-Zyskuja-pracodawcy-i-pracownicy-8656112.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-01T05:25:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/9/342673458b4cf1-948-568-0-367-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Niemal 90 proc. firm odczuwa brak pracowników na szeregowych stanowiskach. Rozwiązaniem, które w takich okolicznościach coraz częściej ratuje firmy, jest praca natychmiastowa. Za pomocą specjalnej platformy firmy mogą w ciągu kilku dni, a nawet godzin znaleźć pracownika, który wykona dla nich określoną stawkę. Również dla osób szukających możliwości dorobienia jest to wygodna opcja, które nie wymaga długofalowych kontraktów. IV kwartał to tradycyjnie okres wzmożonego zapotrzebowania na prace dorywcze - na listopadowe i grudniowe tygodnie przypada bowiem szczyt aktywności w handlu tradycyjnym, e-commerce, logistyce i magazynach.
</p>

## Dodatkowe niedziele handlowe zaskoczyły. Głównie pracowników
 - [https://www.bankier.pl/wiadomosc/Dodatkowe-niedziele-handlowe-zaskoczyly-Glownie-pracownikow-8656099.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Dodatkowe-niedziele-handlowe-zaskoczyly-Glownie-pracownikow-8656099.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-01T05:01:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/5/6fbc02df9fc048-948-568-0-242-1672-1003.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wprowadzenie dodatkowych niedziel handlowych jest zaskoczeniem dla pracowników, którzy niemal w ostatniej chwili dowiadują się, że muszą stawić się do pracy 10 i 17 grudnia - powiedział PAP przewodniczący Ogólnopolskiego Porozumienia Związków Zawodowych Piotr Ostrowski.</p>

## Ranking kont osobistych w grudniu. W których bankach tanie wypłaty?
 - [https://www.bankier.pl/wiadomosc/Ranking-kont-osobistych-grudzien-2023-Najtansze-konta-bankowe-ROR-8655664.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ranking-kont-osobistych-grudzien-2023-Najtansze-konta-bankowe-ROR-8655664.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-01T05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/9/b55a34685a96e4-948-568-0-69-2144-1286.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Mimo że płatności kartą i telefonem już na dobre wkroczyły do naszej codzienności, wciąż czasami przyda się gotówka. Niektóre banki każą sobie jednak słono płacić za wypłatę środków z konta w bankomacie obcym lub placówce. W najnowszym rankingu sprawdzamy, w których bankach ceny za podjęcie gotówki nie są zbyt wygórowane.</p>

## Takich wyborów jeszcze nie było - głosować mogą miliardy ludzi. Jak zareaguje rynek?
 - [https://www.bankier.pl/wiadomosc/Takich-wyborow-jeszcze-nie-bylo-glosowac-moga-miliardy-ludzi-Jak-zareaguje-rynek-8655321.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Takich-wyborow-jeszcze-nie-bylo-glosowac-moga-miliardy-ludzi-Jak-zareaguje-rynek-8655321.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-01T05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/2/f4b88d59340c9f-948-568-0-154-2429-1457.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W krajach o populacji przekraczającej w sumie ponad połowę mieszkańców świata w 2024 r. odbędą się wybory. Według obliczeń Bloomberga i The Economist takiego roku w historii ludzkości jeszcze nie było. Trudno nad tym faktem przejść obojętnie, zwłaszcza inwestorom, którzy widzieli, co działo się ostatnio na giełdach w Polsce czy w Argentynie. O komentarz na ten temat zapytaliśmy rynkowych ekspertów: Piotra Kuczyńskiego i Wojciecha Białka.
</p>

## W tym roku jest trudniej dorobić przed świętami. Na tym stanowisku płacą najlepiej
 - [https://www.bankier.pl/wiadomosc/W-tym-roku-jest-trudniej-dorobic-przed-swietami-Na-tym-stanowisku-placa-najlepiej-8655955.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/W-tym-roku-jest-trudniej-dorobic-przed-swietami-Na-tym-stanowisku-placa-najlepiej-8655955.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-01T05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/f/3f6aefc59df58b-945-560-0-124-3543-2125.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Okres przedświąteczny to czas, gdy osoby poszukujące
dorywczej lub tymczasowej pracy mają szansę dorobić nieco do domowego budżetu. Pracę
wciąż można znaleźć m.in. w logistyce, sprzedaży ryb czy choinek, przy pakowaniu
prezentów czy promocji produktów, jednak jest jej mniej niż rok temu.</p>

