# Source:CppCast, URL:https://cppcast.com/feed.rss, language:en

## Catch2 v3 and Random Numbers
 - [https://cppcast.com/catch2_v3_and_random_numbers](https://cppcast.com/catch2_v3_and_random_numbers)
 - RSS feed: https://cppcast.com/feed.rss
 - date published: 2023-12-01T09:00:00+00:00

Martin Hořeňovský joins Timur and Phil. Martin returns to talk about v3 of Catch2 and how it is different to v2. We also revisit the topic of random numbers and how Martin is still working on portable distributions and why that is important to testing and other domains.

