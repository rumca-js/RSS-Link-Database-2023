# Source:SomeOrdinaryGamers, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCtMVHI3AJD4Qk4hcbZnI9ZQ, language:en-US

## Emulating Might Be More Illegal Than I Thought...
 - [https://www.youtube.com/watch?v=SWQb3LQdB48](https://www.youtube.com/watch?v=SWQb3LQdB48)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtMVHI3AJD4Qk4hcbZnI9ZQ
 - date published: 2023-12-01T00:40:33+00:00

To try everything Brilliant has to offer—free—for a full 30 days, visit https://brilliant.org/SOG/ . The first 200 of you will get 20% off Brilliant’s annual premium subscription.

Hello guys and gals, it's me Mutahar again! This time we take a look at what appears to be the laws surrounding emulation and how over the course of the year a few actions have taken place which could respark the debate and potentially make some aspects down right illicit in the eyes of the law. Thanks for watching!
Like, Comment and Subscribe for more videos!

