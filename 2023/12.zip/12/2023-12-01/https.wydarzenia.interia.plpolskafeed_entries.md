# Source:Wydarzenia Interia - Polska, URL:https://wydarzenia.interia.pl/polska/feed, language:pl-PL

## PiS składa wniosek do Trybunału Konstytucyjnego w sprawie prezesa NBP
 - [https://wydarzenia.interia.pl/kraj/news-pis-sklada-wniosek-do-trybunalu-konstytucyjnego-w-sprawie-pr,nId,7183780](https://wydarzenia.interia.pl/kraj/news-pis-sklada-wniosek-do-trybunalu-konstytucyjnego-w-sprawie-pr,nId,7183780)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-12-01T13:17:14+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-pis-sklada-wniosek-do-trybunalu-konstytucyjnego-w-sprawie-pr,nId,7183780"><img align="left" alt="PiS składa wniosek do Trybunału Konstytucyjnego w sprawie prezesa NBP" src="https://i.iplsc.com/pis-sklada-wniosek-do-trybunalu-konstytucyjnego-w-sprawie-pr/000GGFHEDT1PH8S9-C321.jpg" /></a>Posłowie PiS skierowali do Trybunału Konstytucyjnego wniosek, w którym zaskarżają przepisy ustawy o Trybunale Stanu. Chodzi m.in. o zapis, zgodnie z którym sejmowa większość decyduje o odwołaniu ze stanowiska szefa banku centralnego. </p><br clear="all" />

## Zbliża się groźna zmiana. RCB ostrzega kierowców
 - [https://wydarzenia.interia.pl/kraj/news-zbliza-sie-grozna-zmiana-rcb-ostrzega-kierowcow,nId,7183801](https://wydarzenia.interia.pl/kraj/news-zbliza-sie-grozna-zmiana-rcb-ostrzega-kierowcow,nId,7183801)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-12-01T13:12:02+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-zbliza-sie-grozna-zmiana-rcb-ostrzega-kierowcow,nId,7183801"><img align="left" alt="Zbliża się groźna zmiana. RCB ostrzega kierowców" src="https://i.iplsc.com/zbliza-sie-grozna-zmiana-rcb-ostrzega-kierowcow/000I4SBVAGI6B3I9-C321.jpg" /></a>Pogoda wkrótce stanie się bardzo groźna w dużej części kraju. Rządowe Centrum Bezpieczeństwa wystosowało alert w związku ze spodziewanymi intensywnymi opadami śniegu. Niektóre drogi mogą się stać nieprzejezdne. Kierowcom polecono zachować ostrożność i wyposażyć się odpowiednio przed podróżą.</p><br clear="all" />

## Daria Zawiałow o wyborach: Bardzo się martwiłam
 - [https://wydarzenia.interia.pl/kraj/news-daria-zawialow-o-wyborach-bardzo-sie-martwilam,nId,7179590](https://wydarzenia.interia.pl/kraj/news-daria-zawialow-o-wyborach-bardzo-sie-martwilam,nId,7179590)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-12-01T09:58:30+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-daria-zawialow-o-wyborach-bardzo-sie-martwilam,nId,7179590"><img align="left" alt="Daria Zawiałow o wyborach: Bardzo się martwiłam" src="https://i.iplsc.com/daria-zawialow-o-wyborach-bardzo-sie-martwilam/000I4B4PSW5XCU9S-C321.jpg" /></a>- Odetchnęłam z ulgą i cieszę się z takiego obrotu spraw, jaki nastał po 15 października - mówi w rozmowie z Piotrem Witwickim Daria Zawiałow. Jak przyznaje, wcześniej &quot;bardzo się bała&quot;. Podkreśla jednak, że nie zamierza wspierać żadnej opcji politycznej i brać udziału w kampaniach. Piosenkarka 20 października wydała swój czwarty album studyjny &quot;Dziewczyna Pop&quot;. W videocaście &quot;Bez Uników&quot; artystka opowiada o brzmieniu nowej płyty i tym, dlaczego &quot;bardzo ostrożnie dobiera sobie współprace&quot;.</p><br clear="all" />

## Nowy lider rankingu zaufania. Niespodziewana zmiana na podium
 - [https://wydarzenia.interia.pl/kraj/news-nowy-lider-rankingu-zaufania-niespodziewana-zmiana-na-podium,nId,7183264](https://wydarzenia.interia.pl/kraj/news-nowy-lider-rankingu-zaufania-niespodziewana-zmiana-na-podium,nId,7183264)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-12-01T08:33:29+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-nowy-lider-rankingu-zaufania-niespodziewana-zmiana-na-podium,nId,7183264"><img align="left" alt="Nowy lider rankingu zaufania. Niespodziewana zmiana na podium" src="https://i.iplsc.com/nowy-lider-rankingu-zaufania-niespodziewana-zmiana-na-podium/000I4OUJMOJNM9D3-C321.jpg" /></a>Ranking zaufania dla polityków ma nowego lidera. Jest nim marszałek Sejmu Szymon Hołownia, któremu ufa 49 proc. respondentów. Za nim znaleźli się przedstawiciele nowej koalicji parlamentarnej. Po raz pierwszy od ośmiu lat poza podium znalazł się prezydent Andrzej Duda. Najwięcej Polaków nie ufa Zbigniewowi Ziobrze.</p><br clear="all" />

## Święta w górach mogą kosztować fortunę. Beskidy czekają na turystów
 - [https://wydarzenia.interia.pl/kraj/news-swieta-w-gorach-moga-kosztowac-fortune-beskidy-czekaja-na-tu,nId,7183243](https://wydarzenia.interia.pl/kraj/news-swieta-w-gorach-moga-kosztowac-fortune-beskidy-czekaja-na-tu,nId,7183243)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-12-01T07:45:36+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-swieta-w-gorach-moga-kosztowac-fortune-beskidy-czekaja-na-tu,nId,7183243"><img align="left" alt="Święta w górach mogą kosztować fortunę. Beskidy czekają na turystów" src="https://i.iplsc.com/swieta-w-gorach-moga-kosztowac-fortune-beskidy-czekaja-na-tu/000GMSGNWME4DJKB-C321.jpg" /></a>Droższe pobyty w hotelach i ceny karnetów - na to muszą przygotować się w tym roku narciarze. Listopadowe opady śniegu przyczyniły się do szybszego otwarcia części ośrodków w Beskidach, a wielu Polaków planuje w górach spędzić święta Bożego Narodzenia i Sylwester. Branża turystyczna naśnieża stoki i przewiduje udany sezon. </p><br clear="all" />

## Zagrożenie w powietrzu. Ogłoszono alert RCB
 - [https://wydarzenia.interia.pl/kraj/news-zagrozenie-w-powietrzu-ogloszono-alert-rcb,nId,7183280](https://wydarzenia.interia.pl/kraj/news-zagrozenie-w-powietrzu-ogloszono-alert-rcb,nId,7183280)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-12-01T07:44:20+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-zagrozenie-w-powietrzu-ogloszono-alert-rcb,nId,7183280"><img align="left" alt="Zagrożenie w powietrzu. Ogłoszono alert RCB" src="https://i.iplsc.com/zagrozenie-w-powietrzu-ogloszono-alert-rcb/000I4NX2Q0S30T2T-C321.jpg" /></a>Gwałtownie pogorszyła się jakość powietrza w wybranych miejscach Polski. Rządowe Centrum Bezpieczeństwa ogłosiło alert związany z prognozowaną złą jakością powietrza w zakresie pyłu zawieszonego PM10. Z powodu smogu specjaliści odradzają mieszkańcom niektórych powiatów aktywność na zewnątrz. Dowiedz się, w których miejscach warto w piątek w miarę możliwości unikać wychodzenia na dwór.</p><br clear="all" />

## Wrażliwe dane pacjentów wykradzione. Hakerzy zażądali okupu
 - [https://wydarzenia.interia.pl/kraj/news-wrazliwe-dane-pacjentow-wykradzione-hakerzy-zazadali-okupu,nId,7183235](https://wydarzenia.interia.pl/kraj/news-wrazliwe-dane-pacjentow-wykradzione-hakerzy-zazadali-okupu,nId,7183235)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-12-01T07:33:36+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-wrazliwe-dane-pacjentow-wykradzione-hakerzy-zazadali-okupu,nId,7183235"><img align="left" alt="Wrażliwe dane pacjentów wykradzione. Hakerzy zażądali okupu" src="https://i.iplsc.com/wrazliwe-dane-pacjentow-wykradzione-hakerzy-zazadali-okupu/000A6QKFGSP5JB17-C321.jpg" /></a>Ruszyło śledztwo w sprawie kradzieży danych pacjentów ALAB przez hakerów. - Dochodzenie obejmuje również wątek zażądania okupu - przekazała rzeczniczka warszawskiej prokuratury Aleksandra Skrzyniarz. Z nieoficjalnych ustaleń wiadomo, że szantażyści zażądali od firmy kilkuset tysięcy dolarów. Postępowanie w tej sprawie wszczyna także Rzecznik Praw Pacjenta.</p><br clear="all" />

