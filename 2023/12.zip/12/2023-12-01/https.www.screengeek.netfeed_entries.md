# Source:ScreenGeek, URL:https://www.screengeek.net/feed/, language:en-US

## Jussie Smollett Likely Headed Back To Jail After Court Upholds Conviction
 - [https://www.screengeek.net/2023/12/01/jussie-smollett-jail-court-upholds-conviction](https://www.screengeek.net/2023/12/01/jussie-smollett-jail-court-upholds-conviction)
 - RSS feed: https://www.screengeek.net/feed/
 - date published: 2023-12-01T23:26:42+00:00

<p>Actor Jussie Smollett, known for his role in Empire, was convicted for disorderly conduct after making false reports to the Chicago Police Department in 2019. Smollett claimed that he was the victim of a hate crime. His claims were false. Now, as noted via NY Daily News, &#8220;an Illinois appeals court on Friday declined to [...]</p>
<p>The post <a href="https://www.screengeek.net/2023/12/01/jussie-smollett-jail-court-upholds-conviction/">Jussie Smollett Likely Headed Back To Jail After Court Upholds Conviction</a> appeared first on <a href="https://www.screengeek.net">ScreenGeek</a>.</p>

## Zack Snyder Says He Doesn’t Get The Backlash Against Amber Heard
 - [https://www.screengeek.net/2023/12/01/zack-snyder-amber-heard-backlash](https://www.screengeek.net/2023/12/01/zack-snyder-amber-heard-backlash)
 - RSS feed: https://www.screengeek.net/feed/
 - date published: 2023-12-01T20:38:02+00:00

<p>Zack Snyder has been responsible for several movies set in the DCEU. In fact, he directed some of its earliest entries, including Man of Steel and Batman v Superman: Dawn of Justice. Now Zack Snyder has opened up about one of the DCEU&#8217;s most controversial stars &#8211; Amber Heard. Fans will recall that Amber Heard [...]</p>
<p>The post <a href="https://www.screengeek.net/2023/12/01/zack-snyder-amber-heard-backlash/">Zack Snyder Says He Doesn&#8217;t Get The Backlash Against Amber Heard</a> appeared first on <a href="https://www.screengeek.net">ScreenGeek</a>.</p>

## Fans Demand Sequel To Number One Netflix Horror Movie
 - [https://www.screengeek.net/2023/12/01/netflix-number-one-horror-movie-sequel-fans-demand](https://www.screengeek.net/2023/12/01/netflix-number-one-horror-movie-sequel-fans-demand)
 - RSS feed: https://www.screengeek.net/feed/
 - date published: 2023-12-01T20:05:53+00:00

<p>One genre that almost always guarantees a sequel has been the horror genre. After all, horror movies are often cheap to make and thus highly profitable. It&#8217;s the reason franchises like Halloween and Friday the 13th were able to produce so many installments. Now Netflix subscribers are demanding the streaming service to develop a sequel [...]</p>
<p>The post <a href="https://www.screengeek.net/2023/12/01/netflix-number-one-horror-movie-sequel-fans-demand/">Fans Demand Sequel To Number One Netflix Horror Movie</a> appeared first on <a href="https://www.screengeek.net">ScreenGeek</a>.</p>

## Fan-Favorite Marvel Star Reportedly Returning For ‘Deadpool 3’
 - [https://www.screengeek.net/2023/12/01/deadpool-3-fan-favorite-marvel-star-return-rumor](https://www.screengeek.net/2023/12/01/deadpool-3-fan-favorite-marvel-star-return-rumor)
 - RSS feed: https://www.screengeek.net/feed/
 - date published: 2023-12-01T16:51:22+00:00

<p>The production of the upcoming MCU movie Deadpool 3 has been quite interesting to follow. In addition to behind-the-scenes issues like the SAG-AFTRA strike, there have been plenty of other interesting developments including the film&#8217;s cast. Now it looks like one fan-favorite Marvel star in particular could be returning for Deadpool 3. It&#8217;s worth noting [...]</p>
<p>The post <a href="https://www.screengeek.net/2023/12/01/deadpool-3-fan-favorite-marvel-star-return-rumor/">Fan-Favorite Marvel Star Reportedly Returning For &#8216;Deadpool 3&#8217;</a> appeared first on <a href="https://www.screengeek.net">ScreenGeek</a>.</p>

## Ethan Hawke And Original Cast Returning For ‘The Black Phone 2’
 - [https://www.screengeek.net/2023/12/01/the-black-phone-2-original-cast-ethan-hawke](https://www.screengeek.net/2023/12/01/the-black-phone-2-original-cast-ethan-hawke)
 - RSS feed: https://www.screengeek.net/feed/
 - date published: 2023-12-01T15:56:24+00:00

<p>Work is currently underway on a sequel to 2022&#8217;s horror hit, The Black Phone. Scott Derrickson directed the film which was based on a short story by Joe Hill. Now it looks like the original cast is set to return for The Black Phone 2. As shared by Deadline, this includes Ethan Hawke, who memorably [...]</p>
<p>The post <a href="https://www.screengeek.net/2023/12/01/the-black-phone-2-original-cast-ethan-hawke/">Ethan Hawke And Original Cast Returning For &#8216;The Black Phone 2&#8217;</a> appeared first on <a href="https://www.screengeek.net">ScreenGeek</a>.</p>

## Elizabeth Hurley Shocks Fans With Bikini Video
 - [https://www.screengeek.net/2023/12/01/elizabeth-hurley-bikini-video-shocks-fans](https://www.screengeek.net/2023/12/01/elizabeth-hurley-bikini-video-shocks-fans)
 - RSS feed: https://www.screengeek.net/feed/
 - date published: 2023-12-01T15:54:37+00:00

<p>Celebrity Elizabeth Hurley, at 58-years-old, has fans shocked with her latest bikini video. Of course, with more than 2.8 million followers on Instagram, it&#8217;s no surprise that her fans love her content. But this time fans are especially impressed as the comments reveal. &#8220;At 60 most hotties in their 20&#8217;s cannot even compete with you [...]</p>
<p>The post <a href="https://www.screengeek.net/2023/12/01/elizabeth-hurley-bikini-video-shocks-fans/">Elizabeth Hurley Shocks Fans With Bikini Video</a> appeared first on <a href="https://www.screengeek.net">ScreenGeek</a>.</p>

