# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## Rosja. Władimir Putin zwiększył liczebność armii. Obowiązuje nowy dekret
 - [https://www.polsatnews.pl/wiadomosc/2023-12-01/rosja-wladimir-putin-zwiekszyl-liczebnosc-armii-obowiazuje-nowy-dekret](https://www.polsatnews.pl/wiadomosc/2023-12-01/rosja-wladimir-putin-zwiekszyl-liczebnosc-armii-obowiazuje-nowy-dekret)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-12-01T20:25:00+00:00

Prezydent Rosji Władimir Putin podpisał dekret zwiększający liczebność rosyjskiej armii. Resort obrony zastrzega, że więcej żołnierzy nie oznacza jednak powszechnego poboru do wojska, ale przeciwnicy Kremla mówią o ukrytej mobilizacji.

## Afganistan. Talibowie ustanowili ambasadora w pierwszym kraju. Chodzi o światowe mocarstwo
 - [https://www.polsatnews.pl/wiadomosc/2023-12-01/afganistan-talibowie-ustanowili-ambasadora-w-pierwszym-kraju-chodzi-o-swiatowe-mocarstwo](https://www.polsatnews.pl/wiadomosc/2023-12-01/afganistan-talibowie-ustanowili-ambasadora-w-pierwszym-kraju-chodzi-o-swiatowe-mocarstwo)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-12-01T16:44:00+00:00

Talibowie, którzy przejęli władzę w Afganistanie, po dwóch latach swoich rządów wyznaczyli ambasadora w pierwszym kraju. To stanowisko objął w Chinach był rzecznik administracji Bilal Karimi. Dyplomatyczne zacieśnianie więzi między tymi państwami rozpoczęło się już wcześniej.

## COP28. Andrzej Duda: Stabilna energia z atomu jest niezbędna
 - [https://www.polsatnews.pl/wiadomosc/2023-12-01/cop28-prezydent-duda-stabilna-energia-z-atomu-jest-niezbedna-w-takim-kraju-jak-polska](https://www.polsatnews.pl/wiadomosc/2023-12-01/cop28-prezydent-duda-stabilna-energia-z-atomu-jest-niezbedna-w-takim-kraju-jak-polska)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-12-01T15:07:00+00:00

- Stabilna energia z atomu jest niezbędna w dużym i uprzemysłowionym kraju, jakim jest Polska. Weźmiemy udział w deklaracji o potrojeniu energii z atomu na świecie do 2050 roku - powiedział prezydent Andrzej Duda podczas konferencji COP28 w Dubaju. Wskazywał, że Polska przechodzi obecnie transformację energetyczną.

## Uganda. Siedemdziesięciolatka urodziła bliźnięta. "Osiągnęliśmy coś niezwykłego"
 - [https://www.polsatnews.pl/wiadomosc/2023-12-01/uganda-siedemdziesieciolatka-urodzila-bliznieta](https://www.polsatnews.pl/wiadomosc/2023-12-01/uganda-siedemdziesieciolatka-urodzila-bliznieta)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-12-01T14:58:00+00:00

Siedemdziesięcioletnia kobieta z Ugandy urodziła bliźniaki. Jak podał szpital, do narodzin doszło w wyniku zapłodnienia in vitro. To jedna z najstarszych kobiet na świecie, które doczekały się potomstwa.

## Hiszpania. Śmigłowiec rozbił się na środku autostrady w Madrycie. Do szpitala trafiły trzy osoby
 - [https://www.polsatnews.pl/wiadomosc/2023-12-01/hiszpania-smiglowiec-rozbil-sie-na-srodku-autostrady-w-madrycie-do-szpitala-trafily-trzy-osoby](https://www.polsatnews.pl/wiadomosc/2023-12-01/hiszpania-smiglowiec-rozbil-sie-na-srodku-autostrady-w-madrycie-do-szpitala-trafily-trzy-osoby)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-12-01T14:28:00+00:00

Na autostradzie w Madrycie rozbił się śmigłowiec z dwiema osobami na pokładzie. Maszyna uderzyła w samochód, którym podróżowała jedna osoba. Miejsce wypadku zabezpiecza kilkudziesięciu funkcjonariuszy służb ratunkowych.

## USA. Nowe sankcje na Koreę Północną. To reakcja na wystrzelenie satelity szpiegowskiego
 - [https://www.polsatnews.pl/wiadomosc/2023-12-01/usa-nowe-sankcje-na-koree-polnocna-to-reakcja-na-wystrzelenie-satelity-szpiegowskiego](https://www.polsatnews.pl/wiadomosc/2023-12-01/usa-nowe-sankcje-na-koree-polnocna-to-reakcja-na-wystrzelenie-satelity-szpiegowskiego)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-12-01T14:21:00+00:00

Cztery państwa nałożyły wspólne sankcje na przedstawicieli Korei Północnej. To reakcja na wystrzelenie przez reżim Kim Dzong Una satelity szpiegowskiego.

## Dieta wegańska sprzyja zdrowiu. Eksperci mają nowe wyniki badań
 - [https://www.polsatnews.pl/wiadomosc/2023-12-01/dieta-weganska-sprzyja-zdrowiu-eksperci-maja-nowe-wyniki-badan](https://www.polsatnews.pl/wiadomosc/2023-12-01/dieta-weganska-sprzyja-zdrowiu-eksperci-maja-nowe-wyniki-badan)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-12-01T14:10:00+00:00

Dieta wegańska sprzyja utracie cholesterolu i masy ciała. Takie wnioski przedstawili naukowcy, którzy przeprowadzili badanie na bliźniakach. Jedna osoba z rodzeństwa spożywała produkty wyłącznie pochodzenia roślinnego, a druga jadła bez ograniczeń. Rezultaty były widoczne już po ośmiu tygodniach.

## Szczyt COP28. Odmówili wspólnego zdjęcia z jednym przywódcą. Bunt Polski, Łotwy i Litwy
 - [https://www.polsatnews.pl/wiadomosc/2023-12-01/szczyt-cop28-odmowili-wspolnego-zdjecia-z-jednym-przywodca-bunt-polski-lotwy-i-litwy](https://www.polsatnews.pl/wiadomosc/2023-12-01/szczyt-cop28-odmowili-wspolnego-zdjecia-z-jednym-przywodca-bunt-polski-lotwy-i-litwy)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-12-01T13:09:00+00:00

Przedstawiciele państw Polski, Łotwy i Litwy odmówili wykonania wspólnego zdjęcia podczas szczytu klimatycznego. Powodem ich decyzji była obecność przywódcy Białorusi Alaksandra Łukaszenki na fotografii. - Byłoby hipokryzją - mówił prezydent Litwy Gitanas Nauseda

## Miasto w Europie najdroższym miejscem do życia na świecie w 2023 roku
 - [https://www.polsatnews.pl/wiadomosc/2023-11-30/miasto-w-europie-najdrozszym-miejscem-do-zycia-na-swiecie](https://www.polsatnews.pl/wiadomosc/2023-11-30/miasto-w-europie-najdrozszym-miejscem-do-zycia-na-swiecie)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-12-01T12:47:00+00:00

Opublikowano najnowszy ranking dotyczący kosztów życia na świecie. Analitycy przeanalizowali dane z 173 miast i wskazali, gdzie było najdrożej, a gdzie najtaniej w 2023 roku. W pierwszej dziesiątce znalazły się cztery europejskie miasta.

## Niemcy. Podejrzany w sprawie Madeleine McCann stanie przed sądem
 - [https://www.polsatnews.pl/wiadomosc/2023-12-01/zaginiecie-madeleine-mccann-niemiec-stanie-przed-sadem](https://www.polsatnews.pl/wiadomosc/2023-12-01/zaginiecie-madeleine-mccann-niemiec-stanie-przed-sadem)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-12-01T11:40:00+00:00

Po latach wraca temat zaginięcia Madeleine McCann, a dokładnie podejrzanego w jej sprawie Christiana B. Mężczyzna stanie przed wymiarem sprawiedliwości, jednak odpowie za inne, ciążące za nim zarzuty. Akt oskarżenia liczący ponad 100 stron dotyczy m.in. wykorzystywania dzieci.

## Birmingham. Zamieszki przed meczem Legii. 39 osób zatrzymanych
 - [https://www.polsatnews.pl/wiadomosc/2023-12-01/birmingham-zamieszki-przed-meczem-legii-39-osob-zatrzymanych](https://www.polsatnews.pl/wiadomosc/2023-12-01/birmingham-zamieszki-przed-meczem-legii-39-osob-zatrzymanych)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-12-01T09:10:00+00:00

39 osób aresztowanych, czterech rannych policjantów - to według stacji BBC efekt zamieszek, do jakich doszło w Birmingham z udziałem kibiców Legii Warszawa przed meczem piłkarskiej Ligi Konferencji Europy z Aston Villą. Powodem była niewystarczająca - jak twierdzą - liczba biletów dla lojalnych kibiców z Polski. Ostatecznie fani Legii nie zostali wpuszczeni na trybuny.

## Koniec rozejmu w Strefie Gazy. Znów słychać strzały
 - [https://www.polsatnews.pl/wiadomosc/2023-12-01/koniec-rozejmu-w-strefie-gazy-znow-slychac-strzaly](https://www.polsatnews.pl/wiadomosc/2023-12-01/koniec-rozejmu-w-strefie-gazy-znow-slychac-strzaly)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-12-01T06:24:00+00:00

Wygasł tymczasowy rozejm między Izraelem a bojownikami Hamasu. Zawieszenie broni trwało siedem dni i było dwukrotnie przedłużane. W tym czasie doszło do wymiany zakładników i udzielenia pomocy humanitarnej na terenach najbardziej dotkniętych wojną, gdzie wcześniej nie było to możliwe ze względu na ostrzały i wymianę ognia.

