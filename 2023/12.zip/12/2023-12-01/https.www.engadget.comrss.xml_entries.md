# Source:Engadget, URL:https://www.engadget.com/rss.xml, language:en-US

## Walmart says it’s no longer advertising on X
 - [https://www.engadget.com/walmart-says-its-no-longer-advertising-on-x-215940504.html?src=rss](https://www.engadget.com/walmart-says-its-no-longer-advertising-on-x-215940504.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-12-01T21:59:40+00:00

<p>Walmart has seen enough from X. The retailer, America’s single biggest employer and largest company by revenue, <a class="no-affiliate-link" href="https://www.reuters.com/business/retail-consumer/walmart-says-it-is-not-advertising-social-platform-x-2023-12-01/?taid=656a288567e55600014f4914">told</a> <em>Reuters</em> on Friday it’s no longer advertising on the platform formerly known as Twitter. The departure follows owner Elon Musk amplifying antisemitic posts and flinging expletives at fleeing advertisers. “We aren’t advertising on X as we’ve found other platforms to better reach our customers,” a Walmart spokesperson told <em>Reuters</em>.</p>
<p>Walmart’s exit adds to a growing list of companies that have pulled ads from the platform. <a href="https://www.engadget.com/apple-reportedly-pulls-ads-from-x-amid-a-growing-backlash-to-antisemitic-content-on-the-platform-205849759.html">Apple, Disney</a>, <a href="https://www.engadget.com/ibm-suspends-advertising-on-x-after-its-ads-wer

## The Game Awards raises an old question: What does indie mean?
 - [https://www.engadget.com/the-game-awards-raises-an-old-question-what-does-indie-mean-205211035.html?src=rss](https://www.engadget.com/the-game-awards-raises-an-old-question-what-does-indie-mean-205211035.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-12-01T20:52:11+00:00

<p>The Game Awards got it wrong this year. One of the titles nominated for Best Independent Game, <em>Dave the Diver</em>, was produced by Nexon, one of the largest video game studios in South Korea. No matter how hard you squint, it is not indie. <em>Dave the Diver</em> is an excellent pixel-art game about deep-sea fishing and restaurant management, but it was commissioned and bankrolled by Nexon subsidiary Mintrocket, with billions of dollars and decades of experience at its back.</p>
<p>When The Game Awards nominees <a href="https://www.engadget.com/baldurs-gate-3-and-alan-wake-2-lead-the-2023-game-awards-nominees-185729344.html">were announced</a> on November 13, fans were quick to point out the error, and the recurring debate over what “indie” means was reignited. Taehwan Kim, Nexon’s overseer of Mintrocket, weighed in on November 14, saying <em>Dave the Diver</em> “may look like an indie, but it's not necessarily the case.” The <a href="https://twitter.com/thegameawards/status/

## Google’s new AI experiment composes abstract musical clips inspired by instruments
 - [https://www.engadget.com/googles-new-ai-experiment-composes-abstract-musical-clips-inspired-by-instruments-203732054.html?src=rss](https://www.engadget.com/googles-new-ai-experiment-composes-abstract-musical-clips-inspired-by-instruments-203732054.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-12-01T20:37:32+00:00

<p>Google’s new generative AI experiment lets you create music “inspired by” over 100 instruments worldwide. <a class="no-affiliate-link" href="https://blog.google/outreach-initiatives/arts-culture/google-arts-culture-new-music-ai-experiment/">Instrument Playground</a> starts by asking for a simple prompt containing a musical instrument’s name, optionally preceded by an adjective like “upbeat,” “strange” or “gloomy.” It will then spit out a 20-second audio clip as a starting point to compose (often extremely offbeat or abstract) music that may or may not include the sound of the specific instrument you entered.</p>
<p>Simon Doury, an Artist in Residence at Google Arts &amp; Culture Lab, designed the experiment. It taps into <a href="https://www.engadget.com/google-opens-up-access-to-its-text-to-music-ai-202251175.html">Google’s MusicLM</a>, a text-to-AI tool it made available to the public in May.</p>
<span id="end-legacy-contents"></span><p>Instrument Playground invites you to “choo

## What did an iPhone camera do to this poor woman's arms?
 - [https://www.engadget.com/what-did-an-iphone-camera-do-to-this-poor-womans-arms-201507227.html?src=rss](https://www.engadget.com/what-did-an-iphone-camera-do-to-this-poor-womans-arms-201507227.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-12-01T20:15:07+00:00

<p>A woman <a href="https://www.instagram.com/p/CzPGNmJIebC/?utm_source=ig_embed&amp;ig_rid=3478bcba-e7a8-4676-b314-ce7e1790a994">was photographed standing in front of two mirrors</a> with an iPhone camera, but the actual photo shows three completely different arm positions. The arms are in different locations in mirror number one, mirror number two and in actual real life. Is it Photoshop? Is it a glitch in the Matrix? Did the woman take a 25-year trip inside of <em>Twin Peak’s</em> black lodge? No, it’s just a computational photography error, but it still makes for one heck of an image.</p>
<div id="7562d5a0a57e49b49e5b879180dd5c1f"><blockquote class="instagram-media" style="border: 0; margin: 1px; padding: 0; width: 99.375%;"><div style="padding: 16px;"> <a href="https://www.instagram.com/p/CzPGNmJIebC/?utm_source=ig_embed&amp;utm_campaign=loading" style="padding: 0 0; text-align: center; text-decoration: none; width: 100%;" target="_blank"> <div style="display: flex;"> <div style

## Meta's apps are still promoting child predation content, report finds
 - [https://www.engadget.com/metas-apps-are-still-promoting-child-predation-content-report-finds-195357362.html?src=rss](https://www.engadget.com/metas-apps-are-still-promoting-child-predation-content-report-finds-195357362.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-12-01T19:53:57+00:00

<p>Meta is failing to stop vast networks of people using its platform to promote child abuse content, a <a class="no-affiliate-link" href="https://www.wsj.com/tech/meta-facebook-instagram-pedophiles-enforcement-struggles-dceb3548"><ins>new report</ins></a> in <em>The Wall Street Journal </em>says, citing numerous disturbing examples of child exploitation it uncovered on Facebook and Instagram. The report, which comes as Meta faces renewed pressure over its handling of children’s safety, has prompted fresh scrutiny from European Union regulators.</p>
<p>In the report, <em>The Wall Street Journal</em> detailed tests it conducted  with the Canadian Centre for Child Protection showing how Meta’s recommendations can suggest Facebook Groups, Instagram hashtags and other accounts that are used to promote and share child exploitation material. According to their tests, Meta was slow to respond to reports about such content, and its own algorithms often made it easier for people to connect wi

## A big Analogue Pocket restock is coming, but cart adapters are delayed again
 - [https://www.engadget.com/a-big-analogue-pocket-restock-is-coming-but-cart-adapters-are-delayed-again-191423716.html?src=rss](https://www.engadget.com/a-big-analogue-pocket-restock-is-coming-but-cart-adapters-are-delayed-again-191423716.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-12-01T19:14:23+00:00

<p>The <a href="https://www.engadget.com/analogue-pocket-first-look-handheld-gaming-as-good-as-it-ever-was-160050430.html">acclaimed Analogue Pocket</a> multi-system portable handheld console is a bona fide hit. It’s so popular, in fact, that it's been sold out for weeks. Have no fear, would-be purchasers. Analogue <a href="https://www.analogue.co/announcements/analogue-duo-shipping-pocket-restock-white-dock-limited-editions-pocket-os-releas"><ins>just announced a major restock.</ins></a> The consoles will be available to buy on December 4 at 11AM ET. The company promises that these orders will arrive in time for the holidays.</p>
<p>This restock only applies to the original black and white designs, and not those <a href="https://www.engadget.com/analogues-limited-edition-pockets-are-delightful-and-frustrating-140012471.html"><ins>nifty limited edition colors,</ins></a> most of which remain sold out. If you miss the window on December 4, the company is doing another restock on Decemb

## Telegram now offers all users limited transcriptions of voice messages
 - [https://www.engadget.com/telegram-now-offers-all-users-limited-transcriptions-of-voice-messages-185114448.html?src=rss](https://www.engadget.com/telegram-now-offers-all-users-limited-transcriptions-of-voice-messages-185114448.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-12-01T18:51:14+00:00

<p><a href="https://www.engadget.com/tag/telegram/">Telegram</a> has released <a href="https://telegram.org/blog/similar-channels">a major update</a> for its iOS and Android apps that includes an array of new and upgraded features. Since last year, Telegram Premium users have been able to get transcriptions of voice and video messages and now the platform is opening up that feature to everyone, albeit on a more limited basis. Free users will be able to convert two messages per week into text. Just hit the →A icon on a voice message and you'll get a text version of the memo. Telegram notes that it's rolling out this feature gradually, so you may not have access to it right away.</p>
<p>Elsewhere, Telegram is looking to improve channel discovery. Whenever you join a channel, you'll see a selection of similar public channels. Telegram is basing these recommendations on similarities in subscriber bases. You'll be able to view these recommendations at any time by going to a channel's prof

## Researchers quantify the carbon footprint of generating AI images
 - [https://www.engadget.com/researchers-quantify-the-carbon-footprint-of-generating-ai-images-173538174.html?src=rss](https://www.engadget.com/researchers-quantify-the-carbon-footprint-of-generating-ai-images-173538174.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-12-01T17:35:38+00:00

<p><a href="https://arxiv.org/pdf/2311.16863.pdf">Researchers</a> at the AI startup <a href="https://huggingface.co/">Hugging Face</a> collaborated with Carnegie Mellon University and discovered that <a href="https://www.engadget.com/blender-can-now-use-ai-to-create-images-and-effects-from-text-descriptions-175001548.html">generating an image</a> using artificial intelligence, whether it's to create <a href="https://www.engadget.com/shutterstock-ai-generated-stock-images-dall-e-133903619.html">stock images</a> or <a href="https://www.engadget.com/ai-can-produce-detailed-photos-of-faces-from-simple-sketches-122924655.html">realistic ID photos</a>, has a carbon footprint equivalent to charging a smartphone. However, researchers discern that generating text, whether it be to create a <a href="https://www.engadget.com/google-messages-now-lets-you-choose-your-own-chat-bubble-colors-170042264.html">conversation with a chatbot </a>or clean up an essay, requires much less energy than generat

## All the best Cyber Monday deals that are still live on Amazon right now
 - [https://www.engadget.com/all-the-best-cyber-monday-deals-that-are-still-live-on-amazon-right-now-164349983.html?src=rss](https://www.engadget.com/all-the-best-cyber-monday-deals-that-are-still-live-on-amazon-right-now-164349983.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-12-01T16:43:49+00:00

<p>Cyber Monday may have come and gone, but quite a few of the deals are still live. We're also seeing new discounts and bundles pop up that weren't previously listed. If you didn't get everything you need during the frenzy of Black Friday sales, you can still save on Amazon Echos, Dyson vacs, Google Nests and Sony headphones. Amazon has the most deals remaining at the moment, but other retailers, including Sonos, Wellbots, Target and Walmart, still have some worthy sale prices too. There's no telling how long these leftover savings will last, so you may not want to wait much longer to shop. Here are the best Cyber Monday tech deals you can still get today.&nbsp;</p>
<h2>Amazon Echo Dot</h2>
<p></p>
<p>The <a class="rapid-with-clickid" href="https://shopping.yahoo.com/rdlw?merchantId=66ea567a-c987-4c2e-a2ff-02904efde6ea&amp;siteId=us-engadget&amp;pageId=1p-autolink&amp;featureId=text-link&amp;merchantName=Amazon&amp;custData=eyJzb3VyY2VOYW1lIjoiV2ViLURlc2t0b3AtVmVyaXpvbiIsImxhbmRpbmd

## Apple's MacBook Pro M3 is on sale for $200 off
 - [https://www.engadget.com/apples-macbook-pro-m3-is-on-sale-for-200-off-162051385.html?src=rss](https://www.engadget.com/apples-macbook-pro-m3-is-on-sale-for-200-off-162051385.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-12-01T16:20:51+00:00

<p>The just-released Apple MacBook Pro M3 is already on sale. You can snag the <a class="rapid-with-clickid" href="https://shopping.yahoo.com/rdlw?merchantId=66ea567a-c987-4c2e-a2ff-02904efde6ea&amp;siteId=us-engadget&amp;pageId=1p-autolink&amp;featureId=text-link&amp;merchantName=Amazon&amp;custData=eyJzb3VyY2VOYW1lIjoiV2ViLURlc2t0b3AtVmVyaXpvbiIsImxhbmRpbmdVcmwiOiJodHRwczovL3d3dy5hbWF6b24uY29tL2RwL0IwQ001TFpXSjE_dGFnPWdkZ3QwYy1wLW8tNTdoLTIwIiwiY29udGVudFV1aWQiOiJhMmMwZmVhMy00ZjgxLTQ1ZTUtYTNjYS1jYmM3MjhiYjFkMmQifQ&amp;signature=AQAAAX5E36ju-ZT3BvU-ShfwT2S6dejJ853IwyqRIIPFJQvn&amp;gcReferrer=https%3A%2F%2Fwww.amazon.com%2Fdp%2FB0CM5LZWJ1"><ins>14-inch model for $1,600</ins></a> via Amazon. That’s a savings of $200, or 11 percent for the math fanatics out there. Not bad for a laptop that launched just three weeks ago.</p>
<p></p>
<p>Here are the pertinent specs. This model includes an 8-core CPU, a 10-core GPU and a 14.2-inch XDR display. You also get 8GB of RAM and 1TB of SSD storage

## Sony's WH-1000XM5 headphones are back on sale for $328
 - [https://www.engadget.com/sonys-wh-1000xm5-headphones-are-back-on-sale-for-328-160516896.html?src=rss](https://www.engadget.com/sonys-wh-1000xm5-headphones-are-back-on-sale-for-328-160516896.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-12-01T16:05:16+00:00

<p>Perplexing name aside, the <a class="rapid-with-clickid" href="https://shopping.yahoo.com/rdlw?merchantId=66ea567a-c987-4c2e-a2ff-02904efde6ea&amp;siteId=us-engadget&amp;pageId=1p-autolink&amp;featureId=text-link&amp;merchantName=Amazon&amp;custData=eyJzb3VyY2VOYW1lIjoiV2ViLURlc2t0b3AtVmVyaXpvbiIsImxhbmRpbmdVcmwiOiJodHRwczovL3d3dy5hbWF6b24uY29tL1NvbnktV0gtMTAwMFhNNS1DYW5jZWxpbmctSGVhZHBob25lcy1IYW5kcy1GcmVlL2RwL0IwOVhTN0pXSEg_dGFnPWdkZ3QwYy1wLW8tNTdnLTIwIiwiY29udGVudFV1aWQiOiIzYjVhYzQ3MC1jYjRmLTRhMmYtYmEwZC1mOThjYmU0OTc3Y2UifQ&amp;signature=AQAAAZTnWzX4jR8VzgEguowQ-oBAjur7Hp916NPaOmGuHFAO&amp;gcReferrer=https%3A%2F%2Fwww.amazon.com%2FSony-WH-1000XM5-Canceling-Headphones-Hands-Free%2Fdp%2FB09XS7JWHH">Sony WH-1000XM5</a> is our favorite pair of <a href="https://www.engadget.com/best-headphones-wireless-bluetooth-120543205.html">wireless headphones for most people</a>, and now the noise-canceling cans are back on sale for $328. This deal has popped up multiple times in the past year,

## Sci-fi RTS sequel Homeworld 3 will arrive on March 8
 - [https://www.engadget.com/sci-fi-rts-sequel-homeworld-3-will-arrive-on-march-8-153139081.html?src=rss](https://www.engadget.com/sci-fi-rts-sequel-homeworld-3-will-arrive-on-march-8-153139081.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-12-01T15:31:39+00:00

<p>The long-awaited sci-fi strategy sequel <a href="https://www.engadget.com/homeworld-3-2022-release-date-011502637.html"><em>Homeworld 3</em></a> at last has a release date. It’s now slated to arrive on March 8. That’s <a href="https://www.engadget.com/homeworld-3-delay-gearbox-interactive-blackbird-rts-165808680.html">another slight delay</a>, given the <a href="https://www.engadget.com/sci-fi-strategy-game-homeworld-3-has-been-delayed-to-february-2024-061237843.html">February release window</a> that developer Blackbird Interactive and publisher Gearbox were aiming for, but at least there’s now a concrete date. Those who pick up the Fleet Command edition, meanwhile, will get access 72 hours earlier.</p>
<p>In a short <a href="https://twitter.com/homeworldgame/status/1730308248824324553">behind-the-scenes video</a>, Blackbird CEO and co-founder Rob Cunningham said this was &quot;really our original dream of <em>Homeworld 2.</em> The problem was, in the late '90s, early 2000s, the v

## Inside the 'arms race' between YouTube and ad blockers
 - [https://www.engadget.com/inside-the-arms-race-between-youtube-and-ad-blockers-140031824.html?src=rss](https://www.engadget.com/inside-the-arms-race-between-youtube-and-ad-blockers-140031824.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-12-01T14:00:31+00:00

<p>YouTube recently <a href="https://www.engadget.com/youtube-is-taking-its-fight-against-ad-blockers-global-122041223.html">took dramatic action</a> against anyone visiting its site with an ad blocker running — after a few pieces of content, it'll simply stop serving you videos. If you want to get past the wall, that ad blocker will (probably) need to be turned off; and if you want an ad-free experience, better cough up a couple bucks for a Premium subscription.</p>
<p>Although this is an aggressive move that seemingly left ad blocking companies scrambling to respond, it didn’t come out the blue — YouTube had been <a href="https://www.engadget.com/youtube-test-threatens-to-block-viewers-if-they-continue-using-ad-blockers-053117556.html">testing something similar</a> for months. And even before this most recent clampdown, the Google-owned video service has been engaged in an ongoing conflict — a game of cat-and-mouse, an arms race, pick your metaphor — with ad-blocking software: YouT

## The Xbox Series X is down to just $349 right now
 - [https://www.engadget.com/the-xbox-series-x-is-down-to-just-349-right-now-133430874.html?src=rss](https://www.engadget.com/the-xbox-series-x-is-down-to-just-349-right-now-133430874.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-12-01T13:34:30+00:00

<p>If you've been meaning to pick up an <a class="rapid-with-clickid" href="https://shopping.yahoo.com/rdlw?merchantId=3719d8d4-5edd-4817-998a-91f3229e7323&amp;siteId=us-engadget&amp;pageId=1p-autolink&amp;featureId=text-link&amp;merchantName=Walmart&amp;custData=eyJzb3VyY2VOYW1lIjoiV2ViLURlc2t0b3AtVmVyaXpvbiIsImxhbmRpbmdVcmwiOiJodHRwczovL3d3dy53YWxtYXJ0LmNvbS9pcC9YYm94LVNlcmllcy1YLURpYWJsby1JVi1CdW5kbGUvMjA5MDMwNTI3MCIsImNvbnRlbnRVdWlkIjoiNTVhNmMyYjctNDMwYi00MmI5LWFkYmEtNzBiYTJmZjkzZmZlIn0&amp;signature=AQAAAclHbQxAg1gpzPPxEYl_upn_UGc6lD7giZP3BNSo9gHt&amp;gcReferrer=https%3A%2F%2Fwww.walmart.com%2Fip%2FXbox-Series-X-Diablo-IV-Bundle%2F2090305270">Xbox Series X</a> but weren't able to grab one on Black Friday, good news: Walmart has a bundle that pairs the powerful console with a digital copy of the action-RPG <em>Diablo IV </em>on sale for $349. That's the largest discount we've tracked and a full $151 off the Series X's normal going rate. The game, meanwhile, normally goes for $70.

## The Morning After: NASA and IBM team up for powerful AI weather model
 - [https://www.engadget.com/the-morning-after-nasa-and-ibm-team-up-for-powerful-ai-weather-model-121532358.html?src=rss](https://www.engadget.com/the-morning-after-nasa-and-ibm-team-up-for-powerful-ai-weather-model-121532358.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-12-01T12:15:32+00:00

<p>NASA and IBM are building an AI model for weather and climate applications, combining their knowledge and skills in earth science and AI. They say the <a href="https://www.engadget.com/nasa-and-ibm-are-building-an-ai-for-weather-and-climate-applications-050141545.html">foundation model</a> (more on that in a bit) should offer “significant advantages over existing technology.” Current AI models, such as GraphCast and FourCastNet, are already generating weather forecasts more quickly than traditional meteorological models. As IBM notes, those are AI emulators rather than foundation models. AI emulators can make weather predictions based on sets of training data, but they don’t have applications beyond that.</p>
<p>The model may predict meteorological phenomena better, inferring high-res information based on low-res data and “identifying conditions conducive to everything from airplane turbulence to wildfires.”</p>
<p>— Mat Smith</p>
<h3>The biggest stories you might have missed</h3>

## Prime members can buy a Blink Video Doorbell and two Outdoor Cameras for $100
 - [https://www.engadget.com/prime-members-can-buy-a-blink-video-doorbell-and-two-outdoor-cameras-for-100-103504782.html?src=rss](https://www.engadget.com/prime-members-can-buy-a-blink-video-doorbell-and-two-outdoor-cameras-for-100-103504782.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-12-01T10:35:04+00:00

<p>If you recently moved into a new place or are just looking to <a href="https://www.engadget.com/best-smart-home-devices-154557162.html">update your home's security</a>, now's a good time to do so. Though Black Friday has come and gone, <a class="rapid-with-clickid" href="https://shopping.yahoo.com/rdlw?merchantId=66ea567a-c987-4c2e-a2ff-02904efde6ea&amp;siteId=us-engadget&amp;pageId=1p-autolink&amp;featureId=text-link&amp;merchantName=Amazon&amp;custData=eyJzb3VyY2VOYW1lIjoiV2ViLURlc2t0b3AtVmVyaXpvbiIsImxhbmRpbmdVcmwiOiJodHRwczovL3d3dy5hbWF6b24uY29tL0JsaW5rLURvb3JiZWxsLXNlY3VyaXR5LVR3by15ZWFyLWRldGVjdGlvbi9kcC9CMEJXRkpINjVQP3RhZz1nZGd0MGMtcC1vLTU3Yi0yMCIsImNvbnRlbnRVdWlkIjoiYWQ5YzliOTUtYjM1MS00Zjk0LWEyNmMtY2M0YjhhZjRiNjMwIn0&amp;signature=AQAAAfae-l4VU4TBb1zaxGO1V7x_8q372EvGa15vVTugeZHu&amp;gcReferrer=https%3A%2F%2Fwww.amazon.com%2FBlink-Doorbell-security-Two-year-detection%2Fdp%2FB0BWFJH65P">Blink's video doorbell and two fourth-generation outdoor smart security cameras bundle</a

## Huawei is allegedly building a self-sufficient chip network using state investment fund
 - [https://www.engadget.com/huawei-is-allegedly-building-a-self-sufficient-chip-network-using-state-investment-fund-051823202.html?src=rss](https://www.engadget.com/huawei-is-allegedly-building-a-self-sufficient-chip-network-using-state-investment-fund-051823202.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-12-01T05:18:23+00:00

<p>We've seen Huawei's surprising strides with its <a href="https://www.engadget.com/huaweis-new-foldable-provokes-scrutiny-over-chinese-made-chips-104105500.html">recent smartphones</a> — especially the in-house 7nm 5G processor within, but apparently the company has been working on something far more significant to bypass the US import ban. According to a new <a href="https://www.bloomberg.com/graphics/2023-china-huawei-semiconductor/"><em>Bloomberg</em></a> investigation, a Shenzhen city government investment fund created in 2019 has been helping Huawei build &quot;a self-sufficient chip network.&quot;&nbsp;</p>
<p>Such a network would give the tech giant access to enterprises — most notably, the three subsidiaries under a firm called SiCarrier — that are key to developing lithography machines. Lithography, especially the high-end extreme ultraviolet flavor, would usually have to be imported into China, but it's currently restricted by <a href="https://www.engadget.com/us-netherla

## TikTok ban in Montana blocked by US judge over free speech rights
 - [https://www.engadget.com/tiktok-ban-in-montana-blocked-by-us-judge-over-free-speech-rights-011846138.html?src=rss](https://www.engadget.com/tiktok-ban-in-montana-blocked-by-us-judge-over-free-speech-rights-011846138.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-12-01T01:18:46+00:00

<p>Montana's unprecedented <a href="https://www.engadget.com/montanas-governor-signs-bill-banning-tiktok-225326086.html">state-wide ban</a> of Chinese short-video app, TikTok, was supposed to take effect on January 1, 2024, but as reported by <a href="https://www.reuters.com/legal/us-judge-blocks-montana-banning-tiktok-use-state-2023-11-30/"><em>Reuters</em></a>, US District Judge Donald Molloy issued a preliminary injunction just one month ahead to block said ban. This means that for now, ByteDance and app stores are allowed to continue serving TikTok to users within the Montana state, without being fined $10,000 daily from the start date of the ban.</p>
<p>The judge was quoted saying the ban &quot;oversteps state power and infringes on the constitutional rights of users&quot; — echoing the legal challenge <a href="https://www.engadget.com/tiktok-creators-sue-montana-over-statewide-ban-of-the-app-225725851.html">filed</a> by five TikTok creators on the day after the bill was signed 

