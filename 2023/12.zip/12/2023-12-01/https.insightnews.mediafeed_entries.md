# Source:Insight News Media, URL:https://insightnews.media/feed/, language:en-US

## EU should consider Ukraine’s military needs in its defense strategy – von der Leyen
 - [https://insightnews.media/eu-should-consider-ukraines-military-needs-in-its-defense-strategy-von-der-leyen](https://insightnews.media/eu-should-consider-ukraines-military-needs-in-its-defense-strategy-von-der-leyen)
 - RSS feed: https://insightnews.media/feed/
 - date published: 2023-12-01T07:46:04+00:00

<p>The European Union should consider Ukraine&#8217;s military needs when determining the future strategy of the EU defense industry, European Commission President Ursula von der Leyen &#8230;</p>
<p class="read-more"> <a class="ast-button" href="https://insightnews.media/eu-should-consider-ukraines-military-needs-in-its-defense-strategy-von-der-leyen/"> <span class="screen-reader-text">EU should consider Ukraine&#8217;s military needs in its defense strategy &#8211; von der Leyen</span> Read More »</a></p>
<p>The post <a href="https://insightnews.media/eu-should-consider-ukraines-military-needs-in-its-defense-strategy-von-der-leyen/">EU should consider Ukraine&#8217;s military needs in its defense strategy &#8211; von der Leyen</a> appeared first on <a href="https://insightnews.media">Insight News Media</a>.</p>

## European Commissioner’s insight on the talks on EU’s multi-year €50 billion aid for Ukraine
 - [https://insightnews.media/european-commissioners-insight-on-the-talks-on-eus-multi-year-e50-billion-aid-for-ukraine](https://insightnews.media/european-commissioners-insight-on-the-talks-on-eus-multi-year-e50-billion-aid-for-ukraine)
 - RSS feed: https://insightnews.media/feed/
 - date published: 2023-12-01T07:11:36+00:00

<p>European Commissioner for Budgetary Affairs Johannes Hahn said that a multi-year €50 billion support package for Ukraine can only be approved as part of a &#8230;</p>
<p class="read-more"> <a class="ast-button" href="https://insightnews.media/european-commissioners-insight-on-the-talks-on-eus-multi-year-e50-billion-aid-for-ukraine/"> <span class="screen-reader-text">European Commissioner&#8217;s insight on the talks on EU&#8217;s multi-year €50 billion aid for Ukraine</span> Read More »</a></p>
<p>The post <a href="https://insightnews.media/european-commissioners-insight-on-the-talks-on-eus-multi-year-e50-billion-aid-for-ukraine/">European Commissioner&#8217;s insight on the talks on EU&#8217;s multi-year €50 billion aid for Ukraine</a> appeared first on <a href="https://insightnews.media">Insight News Media</a>.</p>

