# Source:Epoch Times - World, URL:https://feed.theepochtimes.com/world/feed, language:en-US

## Rep. Mike Flood Rebuffs UN Talks to Stifle Meat Production
 - [https://www.theepochtimes.com/us/rep-mike-flood-rebuffs-un-talks-to-stifle-meat-production-5539750](https://www.theepochtimes.com/us/rep-mike-flood-rebuffs-un-talks-to-stifle-meat-production-5539750)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T23:09:18+00:00

Mike Flood, (R) Nebraska, in a still released by NTD on May 2, 2023. (NTD)

## EXPLAINER: The Winners and Losers in the $100 Million Google Deal for Media
 - [https://www.theepochtimes.com/world/explainer-the-winners-and-losers-of-the-100-million-google-deal-for-media-5539754](https://www.theepochtimes.com/world/explainer-the-winners-and-losers-of-the-100-million-google-deal-for-media-5539754)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T23:03:04+00:00

A Google sign at the company's office in San Francisco, Calif., on April 12, 2023. (Jeff Chiu/AP Photo)

## Filmmaker Aaron Gunn Wins Conservative Nomination for BC Riding
 - [https://www.theepochtimes.com/world/filmmaker-aaron-gunn-wins-tory-nomination-for-bc-riding-5539726](https://www.theepochtimes.com/world/filmmaker-aaron-gunn-wins-tory-nomination-for-bc-riding-5539726)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T23:02:01+00:00

Conservative activist Aaron Gunn. (Courtesy of Aaron Gunn)

## Banking ‘Bullies’ Leave Vulnerable People Open to Scams
 - [https://www.theepochtimes.com/world/banking-bullies-leave-vulnerable-people-open-to-scams-5539426](https://www.theepochtimes.com/world/banking-bullies-leave-vulnerable-people-open-to-scams-5539426)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T23:00:53+00:00

Australian banks have launched a new digital platform  to help combat fraudulent transactions. (Peter Parks/AFP via Getty Images)

## Court Decisions Forced Some Rethink of Oil, Gas Emissions Cap: Minister Guilbeault
 - [https://www.theepochtimes.com/world/court-decisions-forced-some-rethink-of-oil-gas-emissions-cap-minister-guilbeault-5539798](https://www.theepochtimes.com/world/court-decisions-forced-some-rethink-of-oil-gas-emissions-cap-minister-guilbeault-5539798)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T23:00:24+00:00

Minister of Environment and Climate Change Steven Guilbeault rises during Question Period in the House of Commons on Parliament Hill in Ottawa on Nov. 28, 2023. (The Canadian Press/Justin Tang)

## Ambulance Pay Dispute Could Cripple New Year Services
 - [https://www.theepochtimes.com/world/ambulance-pay-dispute-could-cripple-new-year-services-5539425](https://www.theepochtimes.com/world/ambulance-pay-dispute-could-cripple-new-year-services-5539425)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T22:00:01+00:00

Ambulances arrive at St Vincent's Hospital in Sydney, Australia, on Dec. 28, 2021. (Jenny Evans/Getty Images)

## Group Behind Alberta Town Plebiscite Over Sidewalk, Flagpole Bylaw Seeking ‘Equality’
 - [https://www.theepochtimes.com/world/group-behind-alberta-town-plebiscite-over-sidewalk-flagpole-bylaw-seeking-equality-5539688](https://www.theepochtimes.com/world/group-behind-alberta-town-plebiscite-over-sidewalk-flagpole-bylaw-seeking-equality-5539688)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T21:36:15+00:00

File photo of a rainbow flag painted on a public roadway near Ft. Lauderdale Beach, Fla., on Feb. 10, 2023. (Chris Nelson for The Epoch Times)

## Holiday Turkey Dinner to Cost Average Canadian Family $104.85: Report
 - [https://www.theepochtimes.com/world/holiday-turkey-dinner-to-cost-average-canadian-family-104-85-report-5539627](https://www.theepochtimes.com/world/holiday-turkey-dinner-to-cost-average-canadian-family-104-85-report-5539627)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T20:50:02+00:00

The average turkey dinner will cost more this Christmas, according to a new report. (Mario Tama/Getty Images)

## Can Canadian Downtowns Find New Purpose in a Post-Office Era?
 - [https://www.theepochtimes.com/world/can-canadian-downtowns-find-new-purpose-in-a-post-office-era-5539687](https://www.theepochtimes.com/world/can-canadian-downtowns-find-new-purpose-in-a-post-office-era-5539687)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T20:36:38+00:00

A woman takes a photo of the new Bonjour Montreal in the Old Port in Montreal on July 6, 2023. (The Canadian Press/Ryan Remiorz)

## Banks Focus on Staff Cuts, Provisions for Bad Loans in Q4 Ahead of Uncertain 2024
 - [https://www.theepochtimes.com/world/banks-focus-on-staff-cuts-provisions-for-bad-loans-in-q4-ahead-of-uncertain-2024-post-5539710](https://www.theepochtimes.com/world/banks-focus-on-staff-cuts-provisions-for-bad-loans-in-q4-ahead-of-uncertain-2024-post-5539710)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T20:34:55+00:00

National Bank President and CEO Laurent Ferreira addresses the Montreal Chamber of Commerce in Montreal on Sept. 21, 2023. (The Canadian Press/Christinne Muschi)

## Australia Post to Vill Void Made By Bank Branch Closures
 - [https://www.theepochtimes.com/world/australia-post-to-vill-void-made-by-bank-branch-closures-5539363](https://www.theepochtimes.com/world/australia-post-to-vill-void-made-by-bank-branch-closures-5539363)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T20:30:31+00:00

A general view of an Australia Post outlet in Sydney, Australia, on Oct. 28, 2020. (Ryan Pierse/Getty Images)

## Australian House Price Growth Loses Steam in November
 - [https://www.theepochtimes.com/world/australian-house-price-growth-loses-steam-in-november-5539361](https://www.theepochtimes.com/world/australian-house-price-growth-loses-steam-in-november-5539361)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T20:24:16+00:00

A woman walks past an auction sign outside a house in Melbourne, Australia, on Sept. 5, 2023. (William West/AFP via Getty Images)

## Cory Morgan: Why Digital ID for Canadians Is a Really Bad Idea
 - [https://www.theepochtimes.com/opinion/cory-morgan-why-digital-id-for-canadians-is-a-really-bad-idea-5539523](https://www.theepochtimes.com/opinion/cory-morgan-why-digital-id-for-canadians-is-a-really-bad-idea-5539523)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T20:20:27+00:00

European Commission vice-president in charge of "A Europe fit for the digital age" Margrethe Vestager participates in a press conference on establishing a European Digital Identity Framework at the European Commission in Brussels on June 3, 2021. (Stephanie Lecocq/Pool/AFP via Getty Images)

## Minister Tight Lipped on Whether It’s Looking at New Regulator to Fight Online Harms
 - [https://www.theepochtimes.com/world/minister-tight-lipped-on-whether-its-looking-at-new-regulator-to-fight-online-harms-5539691](https://www.theepochtimes.com/world/minister-tight-lipped-on-whether-its-looking-at-new-regulator-to-fight-online-harms-5539691)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T20:00:14+00:00

Justice Minister and Attorney General of Canada Arif Virani speaks during question period in Ottawa on Dec. 1, 2023. (The Canadian Press/Adrian Wyld)

## Brian Giesbrecht: Should Canada Hold an Indigenous Referendum?
 - [https://www.theepochtimes.com/opinion/brian-giesbrecht-should-canada-hold-an-indigenous-referendum-5537209](https://www.theepochtimes.com/opinion/brian-giesbrecht-should-canada-hold-an-indigenous-referendum-5537209)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T19:55:37+00:00

"Vote Yes" and "Vote No" campaign signage is seen outside a polling centre in Perth, Australia, on Oct. 7, 2023. (Matt Jelonek/Getty Images)

## Body of US Airman Recovered as Search for 7 More Crewmembers in Osprey Crash Continues
 - [https://www.theepochtimes.com/us/body-of-us-airman-recovered-as-search-for-7-more-crewmembers-in-osprey-crash-continues-5539658](https://www.theepochtimes.com/us/body-of-us-airman-recovered-as-search-for-7-more-crewmembers-in-osprey-crash-continues-5539658)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T19:54:00+00:00

A US Marine Corps (USMC) Bell Boeing V-22 Osprey tiltrotor military aircraft performs air maneuvers during the 2018 Bahrain International Airshow (BIAS) at the Sakhir Airbase. (STR/AFP via Getty Images)

## MP Warns Against Handing Over Chagos Islands to China-Aligned Mauritius
 - [https://www.theepochtimes.com/world/mp-warns-against-handing-over-chagos-islands-to-china-aligned-mauritius-5539590](https://www.theepochtimes.com/world/mp-warns-against-handing-over-chagos-islands-to-china-aligned-mauritius-5539590)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T18:11:19+00:00

MP Daniel Kawczynski speaks during the "From The Depths Zabinski Awards" ceremony, honoring non-Jews who saved Jews during the Holocaust and WWII, in Warsaw, on Sept. 18, 2017. (Wojtek Radwanski/AFP via Getty Images)

## LIVE NOW: Live View Over Israel–Gaza Border (Dec. 1)
 - [https://www.theepochtimes.com/epochtv/live-view-over-israel-gaza-border-dec-1-post-5539518](https://www.theepochtimes.com/epochtv/live-view-over-israel-gaza-border-dec-1-post-5539518)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T18:10:07+00:00

In this photograph taken near the Israeli border with the Gaza Strip, destroyed buildings of Beit Hanoun in Northern Gaza are seen, from Sedorot, Israel, on Nov. 16, 2023. (Christopher Furlong/Getty Images)

## Quebec Teachers Accuse Legault of ‘Emotional Blackmail’ After Plea to End Strike
 - [https://www.theepochtimes.com/world/quebec-teachers-accuse-legault-of-emotional-blackmail-after-plea-to-end-strike-5539610](https://www.theepochtimes.com/world/quebec-teachers-accuse-legault-of-emotional-blackmail-after-plea-to-end-strike-5539610)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T17:57:33+00:00

Quebec Premier François Legault speaks at a news conference on immigration and French language, at the legislature in Quebec City on Nov. 1, 2023. (The Canadian Press/Jacques Boissinot)

## Significant Rise in Nurses From ‘Red List’ Countries Registered to Work in NHS: Report
 - [https://www.theepochtimes.com/world/significant-rise-in-nurses-from-red-list-countries-registered-to-work-in-nhs-report-5539440](https://www.theepochtimes.com/world/significant-rise-in-nurses-from-red-list-countries-registered-to-work-in-nhs-report-5539440)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T17:57:20+00:00

A general view of staff on a NHS hospital ward on Jan. 18, 2023. (Jeff Moore/PA)

## Chinese Prison ID Found Sewn in Coat Sold in UK
 - [https://www.theepochtimes.com/world/chinese-prison-id-found-sewn-in-coat-sold-in-uk-5539542](https://www.theepochtimes.com/world/chinese-prison-id-found-sewn-in-coat-sold-in-uk-5539542)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T17:43:17+00:00

A guard looks through the window of a hallway inside the No.1 Detention Center during a government guided tour in Beijing, China on Oct. 25, 2012. (Ed Jones/AFP via Getty Images)

## BBC Acknowledges Controversy Over ‘White Privilege’ Following Complaint
 - [https://www.theepochtimes.com/world/bbc-acknowledges-controversy-over-white-privilege-following-complaint-5539581](https://www.theepochtimes.com/world/bbc-acknowledges-controversy-over-white-privilege-following-complaint-5539581)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T17:42:48+00:00

The scene at BBC Broadcasting House in London, after red paint was sprayed over the entrance on Oct. 14, 2023. (James Manning/PA)

## Suspect Believed to Be Behind Fake Bomb Threats at Ont. Schools Arrested in Morocco: OPP
 - [https://www.theepochtimes.com/world/suspect-believed-to-be-behind-fake-bomb-threats-at-ont-schools-arrested-in-morocco-opp-5539585](https://www.theepochtimes.com/world/suspect-believed-to-be-behind-fake-bomb-threats-at-ont-schools-arrested-in-morocco-opp-5539585)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T17:34:50+00:00

A file photo of an Ontario Provincial Police logo. (Nathan Denette/The Canadian Press)

## Trucking Boss Gets 7 Years for Role in 2019 Smuggling That Led to Deaths of 39 Vietnamese Migrants
 - [https://www.theepochtimes.com/world/trucking-boss-gets-7-years-for-role-in-2019-smuggling-that-led-to-deaths-of-39-vietnamese-migrants-5539156](https://www.theepochtimes.com/world/trucking-boss-gets-7-years-for-role-in-2019-smuggling-that-led-to-deaths-of-39-vietnamese-migrants-5539156)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T17:33:07+00:00

Police escort the truck that was found to contain a large number of dead bodies as they move it from an industrial estate in Thurrock, south England, on Oct. 23, 2019. (Alastair Grant/AP Photo)

## CCP Influenced Top British Universities, Documentary Claims
 - [https://www.theepochtimes.com/world/ccp-influenced-top-british-universities-documentary-claims-5538845](https://www.theepochtimes.com/world/ccp-influenced-top-british-universities-documentary-claims-5538845)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T17:22:58+00:00

British Chancellor of the Exchequer George Osborne (L) and Chinese leader Xi Jinping (2nd R)  visit Britain's National Graphene Institute at the University of Manchester in Manchester, northwest England, on Oct. 23, 2015. (Richard Stonehouse/AFP via Getty Images)

## Man Charged With Second-Degree Murder After Four Killed in Winnipeg Shooting
 - [https://www.theepochtimes.com/world/man-charged-with-second-degree-murder-after-four-killed-in-winnipeg-shooting-5539500](https://www.theepochtimes.com/world/man-charged-with-second-degree-murder-after-four-killed-in-winnipeg-shooting-5539500)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T17:16:19+00:00

Police vehicles are shown outside the scene of a shooting at a home in Winnipeg on Nov. 27, 2023. (The Canadian Press/Aaron Vincent Elkaim)

## Nuclear Power is Crucial Solution to Energy Insecurity, UN Nuclear Chief Says
 - [https://www.theepochtimes.com/business/nuclear-power-is-crucial-solution-to-energy-insecurity-un-nuclear-chief-says-5539456](https://www.theepochtimes.com/business/nuclear-power-is-crucial-solution-to-energy-insecurity-un-nuclear-chief-says-5539456)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T17:13:54+00:00

International Atomic Energy Agency (IAEA) Director General Rafael Mariano Grossi speaks with journalists after he and a part of the IAEA mission came back from a Zaporizhzhia nuclear power plant at a Ukrainian checkpoint in Zaporizhzhia region, Ukraine, on Sept. 1, 2022. (Anna Voitenko/Reuters)

## 4 Migrants Who Were Pushed Out of Boat Die Just Yards From Spain’s Southern Coast
 - [https://www.theepochtimes.com/world/4-migrants-who-were-pushed-out-of-boat-die-just-yards-from-spains-southern-coast-5539077](https://www.theepochtimes.com/world/4-migrants-who-were-pushed-out-of-boat-die-just-yards-from-spains-southern-coast-5539077)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T17:09:40+00:00

Migrants are rescued by locals on the shore of a beach close to the southwestern city of Cádiz, Spain, on Nov. 30, 2023. (Jorge Gonzalez Casares/AP Photo)

## Feds Won’t Release Research Verifying Claims GST Holiday for Builders Will Lower Rents
 - [https://www.theepochtimes.com/world/feds-wont-release-research-verifying-claims-gst-holiday-for-builders-will-lower-rents-5539502](https://www.theepochtimes.com/world/feds-wont-release-research-verifying-claims-gst-holiday-for-builders-will-lower-rents-5539502)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T16:57:16+00:00

Deputy Prime Minister and Minister of Finance Chrystia Freeland speaks during a news conference in Ottawa on Nov. 7, 2023. (The Canadian Press/Adrian Wyld)

## Claims COVID-19 Vaccines Are Beneficial Are ‘Without Basis or Merit’: Research Group
 - [https://www.theepochtimes.com/article/claims-covid-19-vaccines-are-beneficial-are-without-basis-or-merit-research-group-5538803](https://www.theepochtimes.com/article/claims-covid-19-vaccines-are-beneficial-are-without-basis-or-merit-research-group-5538803)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T16:43:36+00:00

Empty COVID-19 vaccine vials at a vaccination center in Rosenheim, Germany, on April 20, 2021. (Christof Stache/AFP via Getty Images)

## Russia Draws Western Ire After Top Court Dubs LGBT Movement ‘Extremist’
 - [https://www.theepochtimes.com/world/russia-draws-western-ire-after-top-court-dubs-lgbt-movement-extremist-5539490](https://www.theepochtimes.com/world/russia-draws-western-ire-after-top-court-dubs-lgbt-movement-extremist-5539490)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T16:34:42+00:00

Russian President Vladimir Putin attends the G20 virtual summit via a video link in Moscow on Nov. 22, 2023. (Sputnik/Mikhail Klimentyev/Kremlin via Reuters)

## House Unanimously Denounces Watchdog’s Claim That Christmas Holiday Is ‘Religious Discrimination’
 - [https://www.theepochtimes.com/world/house-unanimously-denounces-watchdogs-claim-that-christmas-holiday-is-religious-discrimination-5539510](https://www.theepochtimes.com/world/house-unanimously-denounces-watchdogs-claim-that-christmas-holiday-is-religious-discrimination-5539510)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T16:26:47+00:00

Bloc Quebecois MP and House leader of the Bloc Québécois Alain Therrien rises during Question Period on Parliament Hill in Ottawa, on Oct. 5, 2023. (Spencer Colby/The Canadian Press)

## Culture Secretary Steps in After Tory MPs Call for Telegraph Sale to Be Paused
 - [https://www.theepochtimes.com/world/culture-secretary-steps-in-after-tory-mps-call-for-telegraph-sale-to-be-paused-5539443](https://www.theepochtimes.com/world/culture-secretary-steps-in-after-tory-mps-call-for-telegraph-sale-to-be-paused-5539443)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T16:13:53+00:00

A woman reads a copy of The Daily Telegraph newspaper in London, on May 21, 2009. (Leon Neal/AFP via Getty Images)

## Unemployment Rate Rises to 5.8%, Economy Adds Modest 25,000 Jobs in November
 - [https://www.theepochtimes.com/world/unemployment-rate-rises-to-5-8-economy-adds-modest-25000-jobs-in-november-5539496](https://www.theepochtimes.com/world/unemployment-rate-rises-to-5-8-economy-adds-modest-25000-jobs-in-november-5539496)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T15:04:31+00:00

A sign for help wanted is pictured in a business window in Ottawa on July 12, 2022. (The Canadian Press/Sean Kilpatrick)

## TD Bank Cuts Jobs as Quarterly Results Reflect a Gloomy Economic Picture
 - [https://www.theepochtimes.com/world/td-bank-cuts-jobs-as-quarterly-results-reflect-a-gloomy-economic-picture-5539484](https://www.theepochtimes.com/world/td-bank-cuts-jobs-as-quarterly-results-reflect-a-gloomy-economic-picture-5539484)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T14:49:51+00:00

Toronto-Dominion Bank signage is pictured in Ottawa on Sept. 7, 2022. (The Canadian Press/Sean Kilpatrick)

## Cameron Pledges £60 Million in UN Climate ‘Reparations’
 - [https://www.theepochtimes.com/world/cameron-pledges-60-million-in-un-climate-reparations-5539441](https://www.theepochtimes.com/world/cameron-pledges-60-million-in-un-climate-reparations-5539441)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T14:38:35+00:00

King Charles III is greeted by Foreign Secretary Lord David Cameron as part of COP28 during a visit to  Heriot-Watt University's Dubai campus on Nov. 30, 2023. (Andrew Matthews/PA Wire)

## ‘Trucks of the Sky’: Light Airships Would Be Ideal for Arctic Defence, Disaster Response, Experts Say
 - [https://www.theepochtimes.com/world/trucks-of-the-sky-light-airships-would-be-ideal-for-arctic-defence-disaster-response-experts-say-5537833](https://www.theepochtimes.com/world/trucks-of-the-sky-light-airships-would-be-ideal-for-arctic-defence-disaster-response-experts-say-5537833)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T14:37:44+00:00

A file photo of the Airlander 10 during its maiden flight at Cardington Airfield in England on Aug. 17, 2016. The Airlander 10 crashed during its second test flight on Aug. 24, 2016, but manufacturer Hybrid Air Vehicles said no one was injured. (Joe Giddens/PA via AP)

## Conservative MP Apologizes for Asking Minister to Speak English After Criticism From Bloc
 - [https://www.theepochtimes.com/world/conservative-mp-apologizes-for-asking-minister-to-speak-english-after-criticism-from-bloc-5539476](https://www.theepochtimes.com/world/conservative-mp-apologizes-for-asking-minister-to-speak-english-after-criticism-from-bloc-5539476)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T14:36:55+00:00

Conservative MP Rachael Thomas stands during Question Period in the House of Commons on Parliament Hill in Ottawa on Dec. 2, 2022. (The Canadian Press/Sean Kilpatrick)

## Liberal Bail Reforms Poised to Become Law After Year of Increased Crime Concerns
 - [https://www.theepochtimes.com/world/liberal-bail-reforms-poised-to-become-law-after-year-of-increased-crime-concerns-5539130](https://www.theepochtimes.com/world/liberal-bail-reforms-poised-to-become-law-after-year-of-increased-crime-concerns-5539130)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T14:23:03+00:00

Minister of Justice and Attorney General of Canada Arif Virani rises during question period in the House of Commons on Parliament Hill in Ottawa on Oct. 26, 2023. (The Canadian Press/Sean Kilpatrick)

## Attempted Murder Trial Begins in London but Jury Warned Gunman has Since Died
 - [https://www.theepochtimes.com/world/attempted-murder-trial-begins-in-london-but-jury-warned-gunman-has-since-died-5539391](https://www.theepochtimes.com/world/attempted-murder-trial-begins-in-london-but-jury-warned-gunman-has-since-died-5539391)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T13:19:31+00:00

A sign is pictured at the main entrance of the Central Criminal Court, commonly referred to as The Old Bailey in central London on Aug. 21, 2016.
(Niklas Halle'n/AFP/Getty Images)

## UN Climate Push: Likely Calls to Cut Meat Intake Face Skepticism
 - [https://www.theepochtimes.com/science/un-climate-push-likely-calls-to-cut-meat-intake-face-skepticism-5539181](https://www.theepochtimes.com/science/un-climate-push-likely-calls-to-cut-meat-intake-face-skepticism-5539181)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T13:00:22+00:00

Beef ranchers survey their herd of cattle in Quemado, Texas on June 13, 2023. (Brandon Bell/Getty Images)

## IN DEPTH: Why Reactive Policing Will Not Break Hold Criminal Gangs Have Over London’s Turkish Community
 - [https://www.theepochtimes.com/world/in-depth-why-reactive-policing-will-not-break-hold-criminal-gangs-have-over-londons-turkish-community-5522384](https://www.theepochtimes.com/world/in-depth-why-reactive-policing-will-not-break-hold-criminal-gangs-have-over-londons-turkish-community-5522384)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T12:39:34+00:00

A police car and van drive down Tottenham High Road - heart of London's Turkish and Kurdish community - in Tottenham, north London, on Nov. 8, 2023. (Chris Summers/The Epoch Times)

## Search for 7 Onboard Crashed US Military Osprey Continues, as Officials Confirm 1 Death
 - [https://www.theepochtimes.com/world/search-for-7-onboard-crashed-us-military-osprey-continues-as-officials-confirm-1-death-5539353](https://www.theepochtimes.com/world/search-for-7-onboard-crashed-us-military-osprey-continues-as-officials-confirm-1-death-5539353)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T12:06:09+00:00

An MV-22B Osprey with Marine Operational Test and Evaluation Squadron (VMX) 1 transports ordnance during an Expeditionary Advanced Base Operation (EABO) exercise to Old Highway 101 near Marine Corps Base Camp Pendleton, Calif., on May 25, 2022. (U.S. Marine Corps via AP)

## Israel-Hamas Fighting Resumes With Rocket Fire, Airstrikes
 - [https://www.theepochtimes.com/world/israel-hamas-fighting-resumes-with-rocket-fire-airstrikes-5539351](https://www.theepochtimes.com/world/israel-hamas-fighting-resumes-with-rocket-fire-airstrikes-5539351)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T06:40:03+00:00

Smoke billows in Rafah on the southern Gaza Strip city after the end of a seven-day ceasefire, on Dec. 1, 2023. (Said Khatib/ AFP via Getty Images)

## Half-Dose of COVID-19 Booster Just as Effective as a Full Dose: Study
 - [https://www.theepochtimes.com/article/half-dose-of-covid-19-booster-just-as-effective-as-a-full-dose-study-5539297](https://www.theepochtimes.com/article/half-dose-of-covid-19-booster-just-as-effective-as-a-full-dose-study-5539297)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T06:16:47+00:00

Pfizer company logo is seen at a Pfizer office in Puurs, Belgium, on Dec. 2, 2022. (Johanna Geron/Reuters)

## WA Council Rejects Proposal to Scrap Indigenous Ceremony at Council Events
 - [https://www.theepochtimes.com/world/wa-council-rejects-proposal-to-scrap-indigenous-ceremony-at-council-events-5539354](https://www.theepochtimes.com/world/wa-council-rejects-proposal-to-scrap-indigenous-ceremony-at-council-events-5539354)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T06:07:27+00:00

Indigenous performers perform the Welcome to Country during a smoke ceremony prior to the state funeral service for Uncle Jack Charles at Hamer Hall in Melbourne, Australia on Oct. 18, 2022. (Asanka Ratnayake/Getty Images)

## Households Stuck With Bill Shock, As Energy-Saving Tips Too Hard to Navigate
 - [https://www.theepochtimes.com/world/households-stuck-with-bill-shock-as-energy-saving-tips-too-hard-to-navigate-5539344](https://www.theepochtimes.com/world/households-stuck-with-bill-shock-as-energy-saving-tips-too-hard-to-navigate-5539344)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T05:43:07+00:00

An Origin Energy power bill is pictured in Brisbane, Tuesday, June 5, 2018. Origin Energy has announced it will cut the power bills of customers in south-east Queensland and South Australia from July 1. (AAP Image/Dan Peled) NO ARCHIVING

## Coroner Issues Warning After 2 Young Women Die From Taking Oral Contraceptives
 - [https://www.theepochtimes.com/world/coroner-issues-warning-after-2-young-women-die-from-taking-oral-contraceptives-5539326](https://www.theepochtimes.com/world/coroner-issues-warning-after-2-young-women-die-from-taking-oral-contraceptives-5539326)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T05:16:18+00:00

The risk of developing a blood clot increases substantially in women with the Heterozygous Factor V Leiden mutation who take oral contraceptives. (areeya_ann/shutterstock)

## South Australia to Outlaw Nazi Symbols and Salutes
 - [https://www.theepochtimes.com/world/south-australia-to-outlaw-nazi-symbols-and-salutes-5538079](https://www.theepochtimes.com/world/south-australia-to-outlaw-nazi-symbols-and-salutes-5538079)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T04:51:40+00:00

Members of the Australian Jewish community wave Israeli flags during a vigil in Sydney, Australia, on Oct. 11, 2023. (David Gray/AFP via Getty Images)

## Australia’s Official Cash Rate Unlikely to Increase in 2024: OECD
 - [https://www.theepochtimes.com/world/australias-official-cash-rate-unlikely-to-increase-in-2024-oced-5539305](https://www.theepochtimes.com/world/australias-official-cash-rate-unlikely-to-increase-in-2024-oced-5539305)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T04:28:54+00:00

Guests arrive at the OECD headquarters in Paris, France, on Nov. 27, 2013. (Antoine Antoniol/Getty Images)

## Ottawa Taking Legal Action to Recoup Anti-Racism Funds From Laith Marouf: Bureaucrat
 - [https://www.theepochtimes.com/world/ottawa-taking-legal-action-to-recoup-anti-racism-funds-from-laith-marouf-bureaucrat-5539308](https://www.theepochtimes.com/world/ottawa-taking-legal-action-to-recoup-anti-racism-funds-from-laith-marouf-bureaucrat-5539308)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T03:30:43+00:00

Witness Isabelle Mondou, Deputy Minister of Canadian Heritage, appears at the standing committee on Canadian Heritage in Ottawa on July 26, 2022. (The Canadian Press/Sean Kilpatrick)

## Doctors Could Face Criminal Charges for Online Euthanasia Consultations
 - [https://www.theepochtimes.com/world/doctors-could-face-criminal-charges-for-online-euthanasia-consultations-5539268](https://www.theepochtimes.com/world/doctors-could-face-criminal-charges-for-online-euthanasia-consultations-5539268)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T02:04:50+00:00

A ruling by the Federal Court of Australia has deemed it illegal for doctors to provide online euthanasia consultations. (Pixabay)

## Chiefs of Ontario Call Trudeau’s Carbon Tax ‘Discriminatory,’ File Judicial Review
 - [https://www.theepochtimes.com/world/chiefs-of-ontario-call-trudeaus-carbon-tax-discriminatory-file-judicial-review-5539096](https://www.theepochtimes.com/world/chiefs-of-ontario-call-trudeaus-carbon-tax-discriminatory-file-judicial-review-5539096)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-01T00:02:52+00:00

Prime Minister Justin Trudeau makes an announcement about the carbon tax during a news conference in Ottawa on Oct. 26, 2023. (The Canadian Press/Sean Kilpatrick)

