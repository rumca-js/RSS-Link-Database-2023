# Source:Hacker News - frontpage, URL:https://hnrss.org/frontpage, language:en-US

## Parrots learn to make video calls to chat with other parrots: study
 - [https://news.northeastern.edu/2023/04/21/parrots-talking-video-calls](https://news.northeastern.edu/2023/04/21/parrots-talking-video-calls)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T22:19:50+00:00

<p>Article URL: <a href="https://news.northeastern.edu/2023/04/21/parrots-talking-video-calls/">https://news.northeastern.edu/2023/04/21/parrots-talking-video-calls/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38493299">https://news.ycombinator.com/item?id=38493299</a></p>
<p>Points: 10</p>
<p># Comments: 1</p>

## A Nouveau graphics driver update
 - [https://lwn.net/SubscriberLink/953144/b85b695d0c760692](https://lwn.net/SubscriberLink/953144/b85b695d0c760692)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T22:02:11+00:00

<p>Article URL: <a href="https://lwn.net/SubscriberLink/953144/b85b695d0c760692/">https://lwn.net/SubscriberLink/953144/b85b695d0c760692/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38493105">https://news.ycombinator.com/item?id=38493105</a></p>
<p>Points: 17</p>
<p># Comments: 0</p>

## Members of the OpenAI board had found Altman an unnervingly slippery operator
 - [https://twitter.com/GaryMarcus/status/1730685674708201880](https://twitter.com/GaryMarcus/status/1730685674708201880)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T21:59:11+00:00

<p>Article URL: <a href="https://twitter.com/GaryMarcus/status/1730685674708201880">https://twitter.com/GaryMarcus/status/1730685674708201880</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38493069">https://news.ycombinator.com/item?id=38493069</a></p>
<p>Points: 9</p>
<p># Comments: 1</p>

## Playstation removing previously purchased Discovery content
 - [https://www.playstation.com/en-us/legal/psvideocontent](https://www.playstation.com/en-us/legal/psvideocontent)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T21:32:54+00:00

<p>Article URL: <a href="https://www.playstation.com/en-us/legal/psvideocontent/">https://www.playstation.com/en-us/legal/psvideocontent/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38492747">https://news.ycombinator.com/item?id=38492747</a></p>
<p>Points: 57</p>
<p># Comments: 21</p>

## 80% faster, 50% less memory, 0% accuracy loss Llama finetuning
 - [https://old.reddit.com/r/LocalLLaMA/comments/188197j/80_faster_50_less_memory_0_accuracy_loss_llama](https://old.reddit.com/r/LocalLLaMA/comments/188197j/80_faster_50_less_memory_0_accuracy_loss_llama)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T21:25:36+00:00

<p>Article URL: <a href="https://old.reddit.com/r/LocalLLaMA/comments/188197j/80_faster_50_less_memory_0_accuracy_loss_llama/">https://old.reddit.com/r/LocalLLaMA/comments/188197j/80_faster_50_less_memory_0_accuracy_loss_llama/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38492652">https://news.ycombinator.com/item?id=38492652</a></p>
<p>Points: 28</p>
<p># Comments: 0</p>

## The Neglected Books page: Where forgotten books are remembered
 - [https://neglectedbooks.com](https://neglectedbooks.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T20:55:10+00:00

<p>Article URL: <a href="https://neglectedbooks.com/">https://neglectedbooks.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38492236">https://news.ycombinator.com/item?id=38492236</a></p>
<p>Points: 19</p>
<p># Comments: 4</p>

## Cocoa harvested by kids as young as 5 in Ghana: CBS News investigation
 - [https://www.cbsnews.com/news/children-harvesting-cocoa-used-by-major-corporations-ghana](https://www.cbsnews.com/news/children-harvesting-cocoa-used-by-major-corporations-ghana)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T20:24:37+00:00

<p>Article URL: <a href="https://www.cbsnews.com/news/children-harvesting-cocoa-used-by-major-corporations-ghana/">https://www.cbsnews.com/news/children-harvesting-cocoa-used-by-major-corporations-ghana/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38491826">https://news.ycombinator.com/item?id=38491826</a></p>
<p>Points: 47</p>
<p># Comments: 19</p>

## Seraph Secure: anti-scam software co-founded by Kitboga
 - [https://www.seraphsecure.com](https://www.seraphsecure.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T19:55:21+00:00

<p>Article URL: <a href="https://www.seraphsecure.com/">https://www.seraphsecure.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38491424">https://news.ycombinator.com/item?id=38491424</a></p>
<p>Points: 9</p>
<p># Comments: 4</p>

## Who is responsible for grade inflation at Yale?
 - [https://marginalrevolution.com/marginalrevolution/2023/12/who-is-responsible-for-grade-inflation-at-yale-economists-are-meanies.html](https://marginalrevolution.com/marginalrevolution/2023/12/who-is-responsible-for-grade-inflation-at-yale-economists-are-meanies.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T19:53:30+00:00

<p>Article URL: <a href="https://marginalrevolution.com/marginalrevolution/2023/12/who-is-responsible-for-grade-inflation-at-yale-economists-are-meanies.html">https://marginalrevolution.com/marginalrevolution/2023/12/who-is-responsible-for-grade-inflation-at-yale-economists-are-meanies.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38491394">https://news.ycombinator.com/item?id=38491394</a></p>
<p>Points: 15</p>
<p># Comments: 3</p>

## OpenAI delays launch of custom GPT store until early 2024
 - [https://www.axios.com/2023/12/01/openai-delays-launch-custom-gpt-store-2024](https://www.axios.com/2023/12/01/openai-delays-launch-custom-gpt-store-2024)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T19:47:56+00:00

<p>Article URL: <a href="https://www.axios.com/2023/12/01/openai-delays-launch-custom-gpt-store-2024">https://www.axios.com/2023/12/01/openai-delays-launch-custom-gpt-store-2024</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38491314">https://news.ycombinator.com/item?id=38491314</a></p>
<p>Points: 18</p>
<p># Comments: 2</p>

## What Is Retrieval-Augmented Generation a.k.a. RAG?
 - [https://blogs.nvidia.com/blog/what-is-retrieval-augmented-generation](https://blogs.nvidia.com/blog/what-is-retrieval-augmented-generation)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T19:42:57+00:00

<p>Article URL: <a href="https://blogs.nvidia.com/blog/what-is-retrieval-augmented-generation/">https://blogs.nvidia.com/blog/what-is-retrieval-augmented-generation/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38491251">https://news.ycombinator.com/item?id=38491251</a></p>
<p>Points: 38</p>
<p># Comments: 10</p>

## The future of air defense must be smarter, more affordable, and reusable
 - [https://www.anduril.com/article/the-future-of-air-defense](https://www.anduril.com/article/the-future-of-air-defense)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T19:42:44+00:00

<p>Article URL: <a href="https://www.anduril.com/article/the-future-of-air-defense/">https://www.anduril.com/article/the-future-of-air-defense/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38491246">https://news.ycombinator.com/item?id=38491246</a></p>
<p>Points: 26</p>
<p># Comments: 21</p>

## Google Cloud causes another outage for customer that got ratelimited erroneously
 - [https://twitter.com/gergelyorosz/status/1730648618401481019](https://twitter.com/gergelyorosz/status/1730648618401481019)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T19:40:06+00:00

<p>Article URL: <a href="https://twitter.com/gergelyorosz/status/1730648618401481019">https://twitter.com/gergelyorosz/status/1730648618401481019</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38491215">https://news.ycombinator.com/item?id=38491215</a></p>
<p>Points: 33</p>
<p># Comments: 3</p>

## Salad Fingers and the dawn of ‘weird YouTube’
 - [https://theconversation.com/salad-fingers-wasnt-just-strange-it-was-art-heres-how-its-still-influencing-the-weird-part-of-youtube-2-decades-on-216911](https://theconversation.com/salad-fingers-wasnt-just-strange-it-was-art-heres-how-its-still-influencing-the-weird-part-of-youtube-2-decades-on-216911)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T19:29:50+00:00

<p>Article URL: <a href="https://theconversation.com/salad-fingers-wasnt-just-strange-it-was-art-heres-how-its-still-influencing-the-weird-part-of-youtube-2-decades-on-216911">https://theconversation.com/salad-fingers-wasnt-just-strange-it-was-art-heres-how-its-still-influencing-the-weird-part-of-youtube-2-decades-on-216911</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38491088">https://news.ycombinator.com/item?id=38491088</a></p>
<p>Points: 6</p>
<p># Comments: 1</p>

## Automakers must build cheaper, smaller EVs to spur adoption, report says
 - [https://arstechnica.com/cars/2023/12/automakers-must-build-cheaper-smaller-evs-to-spur-adoption-report-says](https://arstechnica.com/cars/2023/12/automakers-must-build-cheaper-smaller-evs-to-spur-adoption-report-says)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T19:24:51+00:00

<p>Article URL: <a href="https://arstechnica.com/cars/2023/12/automakers-must-build-cheaper-smaller-evs-to-spur-adoption-report-says/">https://arstechnica.com/cars/2023/12/automakers-must-build-cheaper-smaller-evs-to-spur-adoption-report-says/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38491028">https://news.ycombinator.com/item?id=38491028</a></p>
<p>Points: 8</p>
<p># Comments: 4</p>

## Income by Zip, Population by City, Home Ownership Stats – ACS Data from Cybersyn
 - [https://app.snowflake.com/marketplace/listing/GZTSZAS2KGK](https://app.snowflake.com/marketplace/listing/GZTSZAS2KGK)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T19:13:20+00:00

<p>Article URL: <a href="https://app.snowflake.com/marketplace/listing/GZTSZAS2KGK">https://app.snowflake.com/marketplace/listing/GZTSZAS2KGK</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38490887">https://news.ycombinator.com/item?id=38490887</a></p>
<p>Points: 4</p>
<p># Comments: 2</p>

## Ask HN: Freelancer? Seeking freelancer? (December 2023)
 - [https://news.ycombinator.com/item?id=38490810](https://news.ycombinator.com/item?id=38490810)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T19:07:02+00:00

<p>Please lead with either SEEKING WORK or SEEKING FREELANCER,
your location, and whether remote work is a possibility.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38490810">https://news.ycombinator.com/item?id=38490810</a></p>
<p>Points: 11</p>
<p># Comments: 9</p>

## Ask HN: Who is hiring? (December 2023)
 - [https://news.ycombinator.com/item?id=38490811](https://news.ycombinator.com/item?id=38490811)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T19:07:02+00:00

<p>Please state the location and include REMOTE, INTERNS and/or VISA
when that sort of candidate is welcome. When remote work is <i>not</i> an option,
include ONSITE.<p>Please only post if you personally are part of the hiring company—no
recruiting firms or job boards. One post per company. If it isn't a household name,
explain what your company does.<p>Commenters: please don't reply to job posts to complain about
something. It's off topic here.<p>Readers: please only email if you are personally interested in the job.<p>Searchers: try <a href="https://www.remotenbs.com" rel="nofollow noreferrer">https://www.remotenbs.com</a>, <a href="https://hnjobs.u-turn.dev" rel="nofollow noreferrer">https://hnjobs.u-turn.dev</a>, <a href="https://hnresumetojobs.com" rel="nofollow noreferrer">https://hnresumetojobs.com</a>,
<a href="https://hnhired.fly.dev" rel="nofollow noreferrer">https://hnhired.fly.dev</a>, <a href="https://kennytilton.github.io/whoishiring/" rel="nofollow noreferrer">https://

## Ask HN: Who wants to be hired? (December 2023)
 - [https://news.ycombinator.com/item?id=38490809](https://news.ycombinator.com/item?id=38490809)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T19:07:01+00:00

<p>Share your information if you are looking for work. Please use this format:<p><pre><code>  Location:
  Remote:
  Willing to relocate:
  Technologies:
  Résumé/CV:
  Email:
</code></pre>
Readers: please only email these addresses to discuss work opportunities.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38490809">https://news.ycombinator.com/item?id=38490809</a></p>
<p>Points: 8</p>
<p># Comments: 17</p>

## Cloudflare Gen 12 Server: Bigger, Better, Cooler in a 2U1N Form Factor
 - [https://blog.cloudflare.com/cloudflare-gen-12-server-bigger-better-cooler-in-a-2u1n-form-factor](https://blog.cloudflare.com/cloudflare-gen-12-server-bigger-better-cooler-in-a-2u1n-form-factor)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T18:46:57+00:00

<p>Article URL: <a href="https://blog.cloudflare.com/cloudflare-gen-12-server-bigger-better-cooler-in-a-2u1n-form-factor/">https://blog.cloudflare.com/cloudflare-gen-12-server-bigger-better-cooler-in-a-2u1n-form-factor/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38490575">https://news.ycombinator.com/item?id=38490575</a></p>
<p>Points: 20</p>
<p># Comments: 4</p>

## Show HN: Unofficial YouTube Wrapped 2023, see top creators and watching habits
 - [https://videorecap.viewodyssey.com](https://videorecap.viewodyssey.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T18:26:03+00:00

<p>Article URL: <a href="https://videorecap.viewodyssey.com/">https://videorecap.viewodyssey.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38490314">https://news.ycombinator.com/item?id=38490314</a></p>
<p>Points: 20</p>
<p># Comments: 5</p>

## How China is tearing down Islam – FT
 - [http://webcache.googleusercontent.com/search?q=cache:https://ig.ft.com/china-mosques](http://webcache.googleusercontent.com/search?q=cache:https://ig.ft.com/china-mosques)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T18:13:08+00:00

<p>Article URL: <a href="http://webcache.googleusercontent.com/search?q=cache:https://ig.ft.com/china-mosques/">http://webcache.googleusercontent.com/search?q=cache:https://ig.ft.com/china-mosques/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38490112">https://news.ycombinator.com/item?id=38490112</a></p>
<p>Points: 14</p>
<p># Comments: 4</p>

## Llamafile is the new best way to run a LLM on your own computer
 - [http://simonwillison.net/2023/Nov/29/llamafile/#atom-everything](http://simonwillison.net/2023/Nov/29/llamafile/#atom-everything)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T17:36:50+00:00

<p>Article URL: <a href="http://simonwillison.net/2023/Nov/29/llamafile/#atom-everything">http://simonwillison.net/2023/Nov/29/llamafile/#atom-everything</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38489533">https://news.ycombinator.com/item?id=38489533</a></p>
<p>Points: 53</p>
<p># Comments: 9</p>

## Should you split that file?
 - [https://www.pathsensitive.com/2023/12/should-you-split-that-file.html](https://www.pathsensitive.com/2023/12/should-you-split-that-file.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T17:33:25+00:00

<p>Article URL: <a href="https://www.pathsensitive.com/2023/12/should-you-split-that-file.html">https://www.pathsensitive.com/2023/12/should-you-split-that-file.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38489485">https://news.ycombinator.com/item?id=38489485</a></p>
<p>Points: 22</p>
<p># Comments: 7</p>

## 500 Highest Paying Tech Companies (Dec 2023)
 - [https://github.com/miketromba/highest-paying-software-companies](https://github.com/miketromba/highest-paying-software-companies)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T17:25:09+00:00

<p>Article URL: <a href="https://github.com/miketromba/highest-paying-software-companies">https://github.com/miketromba/highest-paying-software-companies</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38489378">https://news.ycombinator.com/item?id=38489378</a></p>
<p>Points: 22</p>
<p># Comments: 10</p>

## Onyx, a new programming language powered by WebAssembly
 - [https://wasmer.io/posts/onyxlang-powered-by-wasmer](https://wasmer.io/posts/onyxlang-powered-by-wasmer)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T17:22:01+00:00

<p>Article URL: <a href="https://wasmer.io/posts/onyxlang-powered-by-wasmer">https://wasmer.io/posts/onyxlang-powered-by-wasmer</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38489340">https://news.ycombinator.com/item?id=38489340</a></p>
<p>Points: 16</p>
<p># Comments: 1</p>

## SQLSync – Stop Building Databases
 - [https://sqlsync.dev/posts/stop-building-databases](https://sqlsync.dev/posts/stop-building-databases)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T17:19:28+00:00

<p>Article URL: <a href="https://sqlsync.dev/posts/stop-building-databases/">https://sqlsync.dev/posts/stop-building-databases/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38489307">https://news.ycombinator.com/item?id=38489307</a></p>
<p>Points: 57</p>
<p># Comments: 12</p>

## PropelAuth (YC W22) Is Hiring Support Engineers
 - [https://www.workatastartup.com/jobs/63193](https://www.workatastartup.com/jobs/63193)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T17:00:37+00:00

<p>Article URL: <a href="https://www.workatastartup.com/jobs/63193">https://www.workatastartup.com/jobs/63193</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38489044">https://news.ycombinator.com/item?id=38489044</a></p>
<p>Points: 0</p>
<p># Comments: 0</p>

## Backblaze Hard Drive Lifetime Annualized 2013-2023
 - [https://www.backblaze.com/blog/wp-content/uploads/2023/11/4-Lifetime-AFR-Table-1.jpg](https://www.backblaze.com/blog/wp-content/uploads/2023/11/4-Lifetime-AFR-Table-1.jpg)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T16:18:46+00:00

<p>Article URL: <a href="https://www.backblaze.com/blog/wp-content/uploads/2023/11/4-Lifetime-AFR-Table-1.jpg">https://www.backblaze.com/blog/wp-content/uploads/2023/11/4-Lifetime-AFR-Table-1.jpg</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38488430">https://news.ycombinator.com/item?id=38488430</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## Apple's chip lab, home to the most 'profound change' in decades
 - [https://www.cnbc.com/2023/12/01/how-apple-makes-its-own-chips-for-iphone-and-mac-edging-out-intel.html](https://www.cnbc.com/2023/12/01/how-apple-makes-its-own-chips-for-iphone-and-mac-edging-out-intel.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T15:27:14+00:00

<p>Article URL: <a href="https://www.cnbc.com/2023/12/01/how-apple-makes-its-own-chips-for-iphone-and-mac-edging-out-intel.html">https://www.cnbc.com/2023/12/01/how-apple-makes-its-own-chips-for-iphone-and-mac-edging-out-intel.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38487823">https://news.ycombinator.com/item?id=38487823</a></p>
<p>Points: 24</p>
<p># Comments: 16</p>

## Show HN: Generate a video to animate stars of any GitHub repository
 - [https://scastiel.dev/github-stars?ref=hn](https://scastiel.dev/github-stars?ref=hn)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T15:09:33+00:00

<p>I made this as a fun tiny project to experiment with Remotion [1] to generate videos. You can find the source code on GitHub [2].<p>[1] <a href="https://www.remotion.dev/" rel="nofollow noreferrer">https://www.remotion.dev/</a><p>[2] <a href="https://github.com/scastiel/github-stars-video">https://github.com/scastiel/github-stars-video</a></p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38487587">https://news.ycombinator.com/item?id=38487587</a></p>
<p>Points: 11</p>
<p># Comments: 4</p>

## Seamless: Meta's New Speech Models
 - [https://ai.meta.com/research/seamless-communication](https://ai.meta.com/research/seamless-communication)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T14:53:21+00:00

<p>Article URL: <a href="https://ai.meta.com/research/seamless-communication/">https://ai.meta.com/research/seamless-communication/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38487359">https://news.ycombinator.com/item?id=38487359</a></p>
<p>Points: 33</p>
<p># Comments: 0</p>

## The Persistent Myth That Most Americans Are Miserable at Work
 - [https://www.theatlantic.com/ideas/archive/2023/12/great-resignation-myth-polls/676189](https://www.theatlantic.com/ideas/archive/2023/12/great-resignation-myth-polls/676189)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T14:47:29+00:00

<p>Article URL: <a href="https://www.theatlantic.com/ideas/archive/2023/12/great-resignation-myth-polls/676189/">https://www.theatlantic.com/ideas/archive/2023/12/great-resignation-myth-polls/676189/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38487266">https://news.ycombinator.com/item?id=38487266</a></p>
<p>Points: 15</p>
<p># Comments: 19</p>

## Easy Stable Diffusion XL in your device, offline
 - [https://noiselith.com](https://noiselith.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T14:34:50+00:00

<p>Article URL: <a href="https://noiselith.com/">https://noiselith.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38487112">https://news.ycombinator.com/item?id=38487112</a></p>
<p>Points: 32</p>
<p># Comments: 11</p>

## Return to office is 'dead,' Stanford economist says
 - [https://www.cnbc.com/2023/11/30/return-to-office-is-dead-stanford-economist-says-heres-why.html](https://www.cnbc.com/2023/11/30/return-to-office-is-dead-stanford-economist-says-heres-why.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T14:17:13+00:00

<p>Article URL: <a href="https://www.cnbc.com/2023/11/30/return-to-office-is-dead-stanford-economist-says-heres-why.html">https://www.cnbc.com/2023/11/30/return-to-office-is-dead-stanford-economist-says-heres-why.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38486907">https://news.ycombinator.com/item?id=38486907</a></p>
<p>Points: 142</p>
<p># Comments: 148</p>

## "Useless Ruby sugar": Endless (one-line) methods
 - [https://zverok.space/blog/2023-12-01-syntax-sugar5-endless-methods.html](https://zverok.space/blog/2023-12-01-syntax-sugar5-endless-methods.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T14:11:50+00:00

<p>Article URL: <a href="https://zverok.space/blog/2023-12-01-syntax-sugar5-endless-methods.html">https://zverok.space/blog/2023-12-01-syntax-sugar5-endless-methods.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38486849">https://news.ycombinator.com/item?id=38486849</a></p>
<p>Points: 8</p>
<p># Comments: 2</p>

## Buggy animation in Atlassian Bitbucket is wasting half a CPU core at all times
 - [https://thehftguy.com/2023/11/21/buggy-animation-in-atlassian-bitbucket-is-wasting-half-a-cpu-core-at-all-times](https://thehftguy.com/2023/11/21/buggy-animation-in-atlassian-bitbucket-is-wasting-half-a-cpu-core-at-all-times)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T13:11:25+00:00

<p>Article URL: <a href="https://thehftguy.com/2023/11/21/buggy-animation-in-atlassian-bitbucket-is-wasting-half-a-cpu-core-at-all-times/">https://thehftguy.com/2023/11/21/buggy-animation-in-atlassian-bitbucket-is-wasting-half-a-cpu-core-at-all-times/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38486259">https://news.ycombinator.com/item?id=38486259</a></p>
<p>Points: 131</p>
<p># Comments: 41</p>

## Is the Turing Test Dead?
 - [https://spectrum.ieee.org/turing-test](https://spectrum.ieee.org/turing-test)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T13:00:53+00:00

<p>Article URL: <a href="https://spectrum.ieee.org/turing-test">https://spectrum.ieee.org/turing-test</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38486177">https://news.ycombinator.com/item?id=38486177</a></p>
<p>Points: 20</p>
<p># Comments: 18</p>

## Chip machine maker ASML names Christophe Fouquet as new CEO
 - [https://nltimes.nl/2023/11/30/chip-machine-maker-asml-names-christophe-fouquet-new-ceo](https://nltimes.nl/2023/11/30/chip-machine-maker-asml-names-christophe-fouquet-new-ceo)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T12:47:15+00:00

<p>Article URL: <a href="https://nltimes.nl/2023/11/30/chip-machine-maker-asml-names-christophe-fouquet-new-ceo">https://nltimes.nl/2023/11/30/chip-machine-maker-asml-names-christophe-fouquet-new-ceo</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38486075">https://news.ycombinator.com/item?id=38486075</a></p>
<p>Points: 18</p>
<p># Comments: 6</p>

## As We May Toast
 - [https://kevinlynagh.com/newsletter/2023_04_as_we_may_toast](https://kevinlynagh.com/newsletter/2023_04_as_we_may_toast)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T12:25:33+00:00

<p>Article URL: <a href="https://kevinlynagh.com/newsletter/2023_04_as_we_may_toast/">https://kevinlynagh.com/newsletter/2023_04_as_we_may_toast/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38485939">https://news.ycombinator.com/item?id=38485939</a></p>
<p>Points: 4</p>
<p># Comments: 1</p>

## Penguin survives on 4-second microsleeps – times a day
 - [https://www.nature.com/articles/d41586-023-03751-7](https://www.nature.com/articles/d41586-023-03751-7)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T11:31:23+00:00

<p>Article URL: <a href="https://www.nature.com/articles/d41586-023-03751-7">https://www.nature.com/articles/d41586-023-03751-7</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38485614">https://news.ycombinator.com/item?id=38485614</a></p>
<p>Points: 17</p>
<p># Comments: 6</p>

## RavynOS Finesse of macOS. Freedom of FreeBSD
 - [https://ravynos.com](https://ravynos.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T11:29:23+00:00

<p>Article URL: <a href="https://ravynos.com/">https://ravynos.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38485596">https://news.ycombinator.com/item?id=38485596</a></p>
<p>Points: 31</p>
<p># Comments: 17</p>

## My insulin pump controller has a bug
 - [https://twitter.com/morganherlocker/status/1730455721815527429](https://twitter.com/morganherlocker/status/1730455721815527429)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T11:23:29+00:00

<p>Article URL: <a href="https://twitter.com/morganherlocker/status/1730455721815527429">https://twitter.com/morganherlocker/status/1730455721815527429</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38485562">https://news.ycombinator.com/item?id=38485562</a></p>
<p>Points: 61</p>
<p># Comments: 37</p>

## 10 Weird HTML Hacks That Shaped the Internet
 - [https://tedium.co/2023/11/24/weird-html-hacks-history](https://tedium.co/2023/11/24/weird-html-hacks-history)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T10:37:00+00:00

<p>Article URL: <a href="https://tedium.co/2023/11/24/weird-html-hacks-history/">https://tedium.co/2023/11/24/weird-html-hacks-history/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38485295">https://news.ycombinator.com/item?id=38485295</a></p>
<p>Points: 80</p>
<p># Comments: 50</p>

## 99 Years of Charlie Munger Wisdom in 44 Minutes [video]
 - [https://www.youtube.com/watch?v=ySErrOs093o](https://www.youtube.com/watch?v=ySErrOs093o)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T10:01:08+00:00

<p>Article URL: <a href="https://www.youtube.com/watch?v=ySErrOs093o">https://www.youtube.com/watch?v=ySErrOs093o</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38485073">https://news.ycombinator.com/item?id=38485073</a></p>
<p>Points: 14</p>
<p># Comments: 0</p>

## Segment Anything Model (Sam) Visualized
 - [https://flowforward.simple.ink](https://flowforward.simple.ink)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T08:26:18+00:00

<p>Article URL: <a href="https://flowforward.simple.ink/">https://flowforward.simple.ink/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38484463">https://news.ycombinator.com/item?id=38484463</a></p>
<p>Points: 5</p>
<p># Comments: 1</p>

## Show HN: Australian Acoustic Observatory Search
 - [https://search.acousticobservatory.org](https://search.acousticobservatory.org)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T05:57:47+00:00

<p>The Australian Acoustic Observatory (<a href="https://acousticobservatory.org/" rel="nofollow noreferrer">https://acousticobservatory.org/</a>) has 360 microphones across the continent, and over 2 million hours of audio. However, none of it is labeled: We want to make this enormous repository useful to researchers. We have found that researchers are often looking for 'hard' signals - specific call-types, birds with very little available training data, and so on. So we built an acoustic-similarity search tool, allowing researchers to provide an example of what they're looking for, which we then match against embeddings from the A2O dataset.<p>Here's some fun examples!<p>Laughing Kookaburra: <<a href="https://search.acousticobservatory.org/search/index.html?q=https://api.search.acousticobservatory.org/api/v1/a2o/audio_recordings/download/flac/372176?start_offset%3D25%26end_offset%3D30" rel="nofollow noreferrer">https://search.acousticobservatory.org/search/index.html?q=h...</a>><p>P

## Quantum particles can feel the influence of gravitational fields
 - [https://www.sciencenews.org/article/quantum-particles-gravity-spacetime-aharonov-bohm-effect](https://www.sciencenews.org/article/quantum-particles-gravity-spacetime-aharonov-bohm-effect)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T05:48:10+00:00

<p>Article URL: <a href="https://www.sciencenews.org/article/quantum-particles-gravity-spacetime-aharonov-bohm-effect">https://www.sciencenews.org/article/quantum-particles-gravity-spacetime-aharonov-bohm-effect</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38483597">https://news.ycombinator.com/item?id=38483597</a></p>
<p>Points: 28</p>
<p># Comments: 4</p>

## An architect has found a way to build flood-proof homes
 - [https://www.washingtonpost.com/climate-solutions/interactive/2023/flood-resistant-home-bamboo](https://www.washingtonpost.com/climate-solutions/interactive/2023/flood-resistant-home-bamboo)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T05:42:18+00:00

<p>Article URL: <a href="https://www.washingtonpost.com/climate-solutions/interactive/2023/flood-resistant-home-bamboo/">https://www.washingtonpost.com/climate-solutions/interactive/2023/flood-resistant-home-bamboo/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38483564">https://news.ycombinator.com/item?id=38483564</a></p>
<p>Points: 14</p>
<p># Comments: 7</p>

## Anduril announces Roadrunner, jet-powered VTOL drone
 - [https://www.anduril.com/roadrunner](https://www.anduril.com/roadrunner)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T05:04:30+00:00

<p>Article URL: <a href="https://www.anduril.com/roadrunner/">https://www.anduril.com/roadrunner/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38483353">https://news.ycombinator.com/item?id=38483353</a></p>
<p>Points: 142</p>
<p># Comments: 155</p>

## James-Lange Theory
 - [https://en.wikipedia.org/wiki/James%E2%80%93Lange_theory](https://en.wikipedia.org/wiki/James%E2%80%93Lange_theory)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T05:02:20+00:00

<p>Article URL: <a href="https://en.wikipedia.org/wiki/James%E2%80%93Lange_theory">https://en.wikipedia.org/wiki/James%E2%80%93Lange_theory</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38483343">https://news.ycombinator.com/item?id=38483343</a></p>
<p>Points: 12</p>
<p># Comments: 1</p>

## Advent of Code 2023 is nigh
 - [https://adventofcode.com/2023](https://adventofcode.com/2023)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T04:50:39+00:00

<p>Article URL: <a href="https://adventofcode.com/2023/">https://adventofcode.com/2023/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38483271">https://news.ycombinator.com/item?id=38483271</a></p>
<p>Points: 16</p>
<p># Comments: 0</p>

## Code is run more than read
 - [https://olano.dev/2023-11-30-code-is-run-more-than-read](https://olano.dev/2023-11-30-code-is-run-more-than-read)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T04:37:22+00:00

<p>Article URL: <a href="https://olano.dev/2023-11-30-code-is-run-more-than-read/">https://olano.dev/2023-11-30-code-is-run-more-than-read/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38483181">https://news.ycombinator.com/item?id=38483181</a></p>
<p>Points: 258</p>
<p># Comments: 134</p>

## How to pick more beautiful colors for your data visualizations (2020)
 - [https://blog.datawrapper.de/beautifulcolors](https://blog.datawrapper.de/beautifulcolors)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T02:56:14+00:00

<p>Article URL: <a href="https://blog.datawrapper.de/beautifulcolors/">https://blog.datawrapper.de/beautifulcolors/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38482486">https://news.ycombinator.com/item?id=38482486</a></p>
<p>Points: 210</p>
<p># Comments: 31</p>

## A reality bending mistake in Apple's computational photography
 - [https://appleinsider.com/articles/23/11/30/a-bride-to-be-discovers-a-reality-bending-mistake-in-apples-computational-photography](https://appleinsider.com/articles/23/11/30/a-bride-to-be-discovers-a-reality-bending-mistake-in-apples-computational-photography)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T02:02:25+00:00

<p>Article URL: <a href="https://appleinsider.com/articles/23/11/30/a-bride-to-be-discovers-a-reality-bending-mistake-in-apples-computational-photography">https://appleinsider.com/articles/23/11/30/a-bride-to-be-discovers-a-reality-bending-mistake-in-apples-computational-photography</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38482085">https://news.ycombinator.com/item?id=38482085</a></p>
<p>Points: 394</p>
<p># Comments: 256</p>

## Marker: Convert PDF to Markdown quickly with high accuracy
 - [https://github.com/VikParuchuri/marker](https://github.com/VikParuchuri/marker)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T01:53:45+00:00

<p>Article URL: <a href="https://github.com/VikParuchuri/marker">https://github.com/VikParuchuri/marker</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38482007">https://news.ycombinator.com/item?id=38482007</a></p>
<p>Points: 314</p>
<p># Comments: 37</p>

## Are Open-Source Large Language Models Catching Up?
 - [https://arxiv.org/abs/2311.16989](https://arxiv.org/abs/2311.16989)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T01:49:36+00:00

<p>Article URL: <a href="https://arxiv.org/abs/2311.16989">https://arxiv.org/abs/2311.16989</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38481970">https://news.ycombinator.com/item?id=38481970</a></p>
<p>Points: 211</p>
<p># Comments: 109</p>

## Music-Map – Find Similar Music
 - [https://www.music-map.com](https://www.music-map.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T00:44:21+00:00

<p>Article URL: <a href="https://www.music-map.com">https://www.music-map.com</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38481426">https://news.ycombinator.com/item?id=38481426</a></p>
<p>Points: 124</p>
<p># Comments: 79</p>

## Booking.com hackers increase attacks on customers
 - [https://www.bbc.co.uk/news/technology-67583486](https://www.bbc.co.uk/news/technology-67583486)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T00:26:06+00:00

<p>Article URL: <a href="https://www.bbc.co.uk/news/technology-67583486">https://www.bbc.co.uk/news/technology-67583486</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38481258">https://news.ycombinator.com/item?id=38481258</a></p>
<p>Points: 12</p>
<p># Comments: 1</p>

## Skyfield: Elegant Astronomy for Python
 - [https://rhodesmill.org/skyfield](https://rhodesmill.org/skyfield)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-01T00:03:11+00:00

<p>Article URL: <a href="https://rhodesmill.org/skyfield/">https://rhodesmill.org/skyfield/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38481063">https://news.ycombinator.com/item?id=38481063</a></p>
<p>Points: 118</p>
<p># Comments: 19</p>

