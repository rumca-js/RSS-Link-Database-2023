# Source:LMG Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFLFc8Lpbwt4jPtY1_Ai5yA, language:en-US

## Why I'm Afraid of Pharmacies
 - [https://www.youtube.com/watch?v=NVTYVm1RbGs](https://www.youtube.com/watch?v=NVTYVm1RbGs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFLFc8Lpbwt4jPtY1_Ai5yA
 - date published: 2023-12-01T17:00:30+00:00

MM: What kind of inside-industry knowledge has most changed the way that you interact with a service? Ft. Pharmacies and the medical system.

Watch the full WAN Show: https://www.youtube.com/watch?v=nVZTLLLkaXU&amp;list=PL8mG-RkN2uTw7PhlnAr4pZZz2QubIbujH&amp;index=2

► GET MERCH: https://lttstore.com
► LTX 2023 TICKETS AVAILABLE NOW: https://lmg.gg/ltx23
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► OUR WAN PODCAST GEAR: https://lmg.gg/wanset
 
FOLLOW US ON SOCIAL
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
TikTok (LMG Clips): www.tiktok.com/@_lmgclips_
Twitch: https://www.twitch.tv/linustech

## Legally Dubious but Fascinating
 - [https://www.youtube.com/watch?v=4xLjL-snwRQ](https://www.youtube.com/watch?v=4xLjL-snwRQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFLFc8Lpbwt4jPtY1_Ai5yA
 - date published: 2023-12-01T17:00:07+00:00

MM: How does LTT handle covering more legally grey uses of technology, like emulators, Plex, Pi-Hole, etc.

Watch the full WAN Show: https://www.youtube.com/watch?v=nVZTLLLkaXU&amp;list=PL8mG-RkN2uTw7PhlnAr4pZZz2QubIbujH&amp;index=2

► GET MERCH: https://lttstore.com
► LTX 2023 TICKETS AVAILABLE NOW: https://lmg.gg/ltx23
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► OUR WAN PODCAST GEAR: https://lmg.gg/wanset
 
FOLLOW US ON SOCIAL
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
TikTok (LMG Clips): www.tiktok.com/@_lmgclips_
Twitch: https://www.twitch.tv/linustech

## Linus Blasts Hackers (1995) for 30 Minutes
 - [https://www.youtube.com/watch?v=4l9KmPe-_ng](https://www.youtube.com/watch?v=4l9KmPe-_ng)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFLFc8Lpbwt4jPtY1_Ai5yA
 - date published: 2023-12-01T17:00:03+00:00

Luke, Linus, and Dan discuss the concept of “So Bad it’s Good” in movies. Ft. Hackers (1995.) 

Watch the full WAN Show: https://www.youtube.com/watch?v=nVZTLLLkaXU&amp;list=PL8mG-RkN2uTw7PhlnAr4pZZz2QubIbujH&amp;index=2

► GET MERCH: https://lttstore.com
► LTX 2023 TICKETS AVAILABLE NOW: https://lmg.gg/ltx23
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► OUR WAN PODCAST GEAR: https://lmg.gg/wanset
 
FOLLOW US ON SOCIAL
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
TikTok (LMG Clips): www.tiktok.com/@_lmgclips_
Twitch: https://www.twitch.tv/linustech

