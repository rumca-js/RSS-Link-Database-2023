## Windsor police officer who donated to Ottawa convoy will learn his penalty in May | CBC News
 - [https://www.cbc.ca/news/canada/windsor/windsor-police-convoy-donation-1.6792348](https://www.cbc.ca/news/canada/windsor/windsor-police-convoy-donation-1.6792348)
 - RSS feed: https://www.cbc.ca
 - date published: 2023-12-01T08:26:27+00:00

Windsor police officer who donated to Ottawa convoy will learn his penalty in May | CBC News

