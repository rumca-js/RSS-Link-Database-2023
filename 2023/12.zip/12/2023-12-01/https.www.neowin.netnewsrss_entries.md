# Source:Neowin, URL:https://www.neowin.net/news/rss/, language:en-us

## OpenAI delays GPT Store launch due to "a few unexpected things keeping them busy"
 - [https://www.neowin.net/news/openai-delays-gpt-store-launch-due-to-a-few-unexpected-things-keeping-them-busy](https://www.neowin.net/news/openai-delays-gpt-store-launch-due-to-a-few-unexpected-things-keeping-them-busy)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-12-01T23:18:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/03/1679598128_chatgpt_medium.jpg" /></div>OpenAI has delayed the planned launch of the GPT Store for custom AI models until early 2024. The marketplace was intended to allow users to train and deploy specialized versions of GPT. <a href="https://www.neowin.net/news/openai-delays-gpt-store-launch-due-to-a-few-unexpected-things-keeping-them-busy">Read more...</a>

## Microsoft may release Windows '12' in June 2024, dedicated AI hardware might be recommended
 - [https://www.neowin.net/news/microsoft-may-release-windows-12-in-june-2024-dedicated-ai-hardware-might-be-recommended](https://www.neowin.net/news/microsoft-may-release-windows-12-in-june-2024-dedicated-ai-hardware-might-be-recommended)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-12-01T21:40:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/03/1677686728_windows_12_medium.jpg" /></div>While it has been expected for a while that Windows 12 will be released sometime next year, a new report suggests it will be in the middle of the year in June, possibly sometime around Computex. <a href="https://www.neowin.net/news/microsoft-may-release-windows-12-in-june-2024-dedicated-ai-hardware-might-be-recommended">Read more...</a>

## Halo Infinite and Fall Guys pay homage to GTA 6's trailer news with their own reveals
 - [https://www.neowin.net/news/halo-infinite-and-fall-guys-pay-homage-to-gta-6s-trailer-news-with-their-own-reveals](https://www.neowin.net/news/halo-infinite-and-fall-guys-pay-homage-to-gta-6s-trailer-news-with-their-own-reveals)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-12-01T21:26:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/12/1701464411_halo-infinite-trailer_medium.jpg" /></div>The official X pages for Halo Infinite and Fall Guys paid tribute to today&#039;s Grand Theft Auto 6&#039;s trailer announcement by making their own trailer news reveals in similar art styles. <a href="https://www.neowin.net/news/halo-infinite-and-fall-guys-pay-homage-to-gta-6s-trailer-news-with-their-own-reveals">Read more...</a>

## Microsoft Copilot (formerly Bing Chat) leaves public preview and is now generally available
 - [https://www.neowin.net/news/microsoft-copilot-formerly-bing-chat-leaves-public-preview-and-is-now-generally-available](https://www.neowin.net/news/microsoft-copilot-formerly-bing-chat-leaves-public-preview-and-is-now-generally-available)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-12-01T20:38:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/12/1701461713_microsoft-copilot-generally-available_medium.jpg" /></div>Microsoft has confirmed that its Copilot chatbot, formerly known as Bing Chat, has left the public preview status several months after it launch and is now considered to be generally available. <a href="https://www.neowin.net/news/microsoft-copilot-formerly-bing-chat-leaves-public-preview-and-is-now-generally-available">Read more...</a>

## Microsoft Gaming CEO Phil Spencer hints at Xbox achievement improvements and more
 - [https://www.neowin.net/news/microsoft-gaming-ceo-phil-spencer-hints-at-xbox-achievement-improvements-and-more](https://www.neowin.net/news/microsoft-gaming-ceo-phil-spencer-hints-at-xbox-achievement-improvements-and-more)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-12-01T20:12:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/06/1686537722_hexen-phil-spencer_medium.jpg" /></div>In a new interview, Microsoft Gaming CEO Phil Spencer hints about its roadmaps for future improvements in Xbox achievements, along with a revival for its Xbox Family Plan and more. <a href="https://www.neowin.net/news/microsoft-gaming-ceo-phil-spencer-hints-at-xbox-achievement-improvements-and-more">Read more...</a>

## Microsoft 365 Insiders can check out typography improvements in Word and Outlook for Windows
 - [https://www.neowin.net/news/microsoft-365-insiders-can-check-out-typography-improvements-in-word-and-outlook-for-windows](https://www.neowin.net/news/microsoft-365-insiders-can-check-out-typography-improvements-in-word-and-outlook-for-windows)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-12-01T18:24:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2019/03/1553428075_word3_medium.jpg" /></div>Members of the Microsoft 365 Insiders program can now check out some new and automatic typography features and improvements that have been put in both the Word and Outlook apps for Windows. <a href="https://www.neowin.net/news/microsoft-365-insiders-can-check-out-typography-improvements-in-word-and-outlook-for-windows">Read more...</a>

## Save 82% on a lifetime subscription to DoRoyal Web Hosting (Jester's Plan)
 - [https://www.neowin.net/deals/save-77-on-a-lifetime-subscription-to-doroyal-web-hosting-jesters-plan](https://www.neowin.net/deals/save-77-on-a-lifetime-subscription-to-doroyal-web-hosting-jesters-plan)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-12-01T18:00:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/09/1694431415_doroyal_medium.jpg" /></div>Get your site up and running in no time! This dependable website hosting lifetime deal includes unlimited domains, unmetered bandwidth and more. Price Dropped now, at Neowin Deals. <a href="https://www.neowin.net/deals/save-77-on-a-lifetime-subscription-to-doroyal-web-hosting-jesters-plan">Read more...</a>

## Cyberpunk 2077 Update 2.1 will add a city metro system, improved boss fights and more Dec. 5
 - [https://www.neowin.net/news/cyberpunk-2077-update-21-will-add-a-city-metro-system-improved-boss-fights-and-more-dec-5](https://www.neowin.net/news/cyberpunk-2077-update-21-will-add-a-city-metro-system-improved-boss-fights-and-more-dec-5)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-12-01T17:44:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2021/06/1623779816_cyberpunk_2077_website_1617083795450_medium.jpg" /></div>CD Projekt RED has announced what will be included in the upcoming Cyberpunk 2077 2.1 update on December 5. It will bring a new city metro system for fast travel and more features. <a href="https://www.neowin.net/news/cyberpunk-2077-update-21-will-add-a-city-metro-system-improved-boss-fights-and-more-dec-5">Read more...</a>

## Microsoft launches the Copilot for Service public preview program for businesses
 - [https://www.neowin.net/news/microsoft-launches-the-copilot-for-service-public-preview-program-for-businesses](https://www.neowin.net/news/microsoft-launches-the-copilot-for-service-public-preview-program-for-businesses)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-12-01T17:16:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/09/1696075943_windows_copilot_medium.jpg" /></div>Microsoft has launched the public preview for its Copilot for Service product that was first announced in November. It&#039;s designed to help customer service reps with their jobs and tasks <a href="https://www.neowin.net/news/microsoft-launches-the-copilot-for-service-public-preview-program-for-businesses">Read more...</a>

## Microsoft's "Windows 11 24H2" mention could throw a wrench at the 'Windows 12' rumor mill
 - [https://www.neowin.net/news/microsofts-windows-11-24h2-mention-could-throw-a-wrench-at-the-windows-12-rumor-mill](https://www.neowin.net/news/microsofts-windows-11-24h2-mention-could-throw-a-wrench-at-the-windows-12-rumor-mill)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-12-01T16:38:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/12/1701448091_windows_11_24h2_medium.jpg" /></div>Microsoft has mentioned Windows 11 &quot;24H2&quot; for the first time, which calls into question some of the leaks, rumors, and reports about &#039;Windows 12&#039; and its possible 2024 launch date. <a href="https://www.neowin.net/news/microsofts-windows-11-24h2-mention-could-throw-a-wrench-at-the-windows-12-rumor-mill">Read more...</a>

## Windows 11 will soon get improved and better optimized energy saver
 - [https://www.neowin.net/news/windows-11-will-soon-get-improved-and-better-optimized-energy-saver](https://www.neowin.net/news/windows-11-will-soon-get-improved-and-better-optimized-energy-saver)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-12-01T15:18:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/12/1701443277_windows_11_energy_saver_medium.jpg" /></div>Microsoft is working on an improved energy saver for its operating system. The latest Canary build brings an &quot;extended and enhanced&quot; battery saver to laptops, tablets, and even desktop computers.  <a href="https://www.neowin.net/news/windows-11-will-soon-get-improved-and-better-optimized-energy-saver">Read more...</a>

## Apple might join hands with Paramount to offer cheap streaming bundle
 - [https://www.neowin.net/news/apple-might-join-hands-with-paramount-to-offer-cheap-streaming-bundle](https://www.neowin.net/news/apple-might-join-hands-with-paramount-to-offer-cheap-streaming-bundle)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-12-01T14:38:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2019/03/1553540452_screenshot_(160)_medium.jpg" /></div>Apple and Paramount are reportedly planning to offer Apple TV+ and Paramount+ streaming services as a combined bundle. The bundle is expected to cost less than buying both services separately. <a href="https://www.neowin.net/news/apple-might-join-hands-with-paramount-to-offer-cheap-streaming-bundle">Read more...</a>

## The Grand Theft Auto VI trailer will break the internet on December 5 at 9 am Eastern time
 - [https://www.neowin.net/news/the-grand-theft-auto-vi-trailer-will-break-the-internet-on-december-5-at-9-am-eastern-time](https://www.neowin.net/news/the-grand-theft-auto-vi-trailer-will-break-the-internet-on-december-5-at-9-am-eastern-time)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-12-01T14:21:50+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/12/1701440194_gtavi-trailer_medium.jpg" /></div>Rockstar has announced that the trailer for the next Grand Theft Auto game, which will likely be titled Grand Theft Auto  VI, will be dropped on Tuesday, December 5 at 9 am Eastern time. <a href="https://www.neowin.net/news/the-grand-theft-auto-vi-trailer-will-break-the-internet-on-december-5-at-9-am-eastern-time">Read more...</a>

## Microsoft is working on 'Advanced Windows Settings' to give you more control over your PC
 - [https://www.neowin.net/news/microsoft-is-working-on-advanced-windows-settings-to-give-you-more-control-over-your-pc](https://www.neowin.net/news/microsoft-is-working-on-advanced-windows-settings-to-give-you-more-control-over-your-pc)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-12-01T14:14:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/07/1689261142_windows_repair_medium.jpg" /></div>Microsoft is working on &quot;Advanced Windows Settings,&quot; a special section of the Dev Home app, to give users and developers more control over their PCs and make toggling in-depth options much easier. <a href="https://www.neowin.net/news/microsoft-is-working-on-advanced-windows-settings-to-give-you-more-control-over-your-pc">Read more...</a>

## Get these Hisense QLED Fire TVs for rock bottom prices right now at Amazon
 - [https://www.neowin.net/deals/get-these-hisense-qled-fire-tvs-for-rock-bottom-prices-right-now-at-amazon](https://www.neowin.net/deals/get-these-hisense-qled-fire-tvs-for-rock-bottom-prices-right-now-at-amazon)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-12-01T13:56:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/12/1701437021_hisense-fire-tv_medium.jpg" /></div>Hisense is selling its QLED-based smart televisions for rock bottom prices right now at Amazon. You can get a 75-inch Hiense Fire TV for only $649.99, or a 65-inch version for $449. <a href="https://www.neowin.net/deals/get-these-hisense-qled-fire-tvs-for-rock-bottom-prices-right-now-at-amazon">Read more...</a>

## Statcounter: Microsoft Edge hits all-time high market share, still barely above 11%
 - [https://www.neowin.net/news/statcounter-microsoft-edge-hits-all-time-high-market-share-still-barely-above-11](https://www.neowin.net/news/statcounter-microsoft-edge-hits-all-time-high-market-share-still-barely-above-11)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-12-01T12:58:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/08/1690886754_browsers_medium.jpg" /></div>According to the November 2023 report from Statcounter, Microsoft Edge achieved its biggest market share to date. However, the browser is still far away from Google Chrome and even Apple&#039;s Safari. <a href="https://www.neowin.net/news/statcounter-microsoft-edge-hits-all-time-high-market-share-still-barely-above-11">Read more...</a>

## Skype Insider gets stacked media albums, now lets you use your phone as a secondary camera
 - [https://www.neowin.net/news/skype-insider-gets-stacked-media-albums-now-lets-you-use-your-phone-as-a-secondary-camera](https://www.neowin.net/news/skype-insider-gets-stacked-media-albums-now-lets-you-use-your-phone-as-a-secondary-camera)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-12-01T09:54:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/08/1692366496_skype_preview_medium.jpg" /></div>Microsoft has released another feature-packed preview update for Skype Insiders. Version 8.110 adds stacked media albums and the ability to use your phone as an extra camera during calls. <a href="https://www.neowin.net/news/skype-insider-gets-stacked-media-albums-now-lets-you-use-your-phone-as-a-secondary-camera">Read more...</a>

## Statcounter: 26.66% of all PCs run Windows 11
 - [https://www.neowin.net/news/statcounter-2666-of-all-pcs-run-windows-11](https://www.neowin.net/news/statcounter-2666-of-all-pcs-run-windows-11)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-12-01T09:34:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/05/1682950344_windows_11_medium.jpg" /></div>Statcounter has released the latest report, revealing that Windows 11 is now installed on more than 25% of all Windows computers. Windows 10 is slowly going down, now at a 68% mark. <a href="https://www.neowin.net/news/statcounter-2666-of-all-pcs-run-windows-11">Read more...</a>

## Mozilla Firefox fixes slow startup, 100% CPU use, green screen YouTube videos, and more
 - [https://www.neowin.net/news/mozilla-firefox-fixes-slow-startup-100-cpu-use-green-screen-youtube-videos-and-more](https://www.neowin.net/news/mozilla-firefox-fixes-slow-startup-100-cpu-use-green-screen-youtube-videos-and-more)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-12-01T09:20:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2019/09/1568742272_firefoxnew2_medium.jpg" /></div>Mozilla&#039;s latest Firefox update has several important bug fixes including ones for YouTube&#039;s green screen when trying to play videos, a 100% CPU usage bug, a slow startup issue, and more. <a href="https://www.neowin.net/news/mozilla-firefox-fixes-slow-startup-100-cpu-use-green-screen-youtube-videos-and-more">Read more...</a>

## GTA Online is finally getting wildlife from story mode, but only on Xbox Series X|S and PS5
 - [https://www.neowin.net/news/gta-online-is-finally-getting-wildlife-from-story-mode-but-only-on-xbox-series-xs-and-ps5](https://www.neowin.net/news/gta-online-is-finally-getting-wildlife-from-story-mode-but-only-on-xbox-series-xs-and-ps5)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-12-01T09:04:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/12/1701420017_4dce984ae625f0951943a28e09d4b08992287d0b_medium.jpg" /></div>Rockstar is finally bringing the wildlife from GTA V&#039;s story mode to GTA Online, but it will be exclusive to current-generation consoles. Yusuf Amir from GTA IV is also returning as a quest giver. <a href="https://www.neowin.net/news/gta-online-is-finally-getting-wildlife-from-story-mode-but-only-on-xbox-series-xs-and-ps5">Read more...</a>

## WhatsApp Android beta adds more to its username feature currently in development
 - [https://www.neowin.net/news/whatsapp-android-beta-adds-more-to-its-username-feature-currently-in-development](https://www.neowin.net/news/whatsapp-android-beta-adds-more-to-its-username-feature-currently-in-development)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-12-01T08:48:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/09/1696093299_whatsapp-1357489_1920_medium.jpg" /></div>WhatsApp has done some more work on its username feature which was spotted in development earlier this year. It&#039;s working on the ability to type usernames in the search bar to find users in the app. <a href="https://www.neowin.net/news/whatsapp-android-beta-adds-more-to-its-username-feature-currently-in-development">Read more...</a>

## Big update coming to Android with new messaging features, Wear OS improvements, more
 - [https://www.neowin.net/news/big-update-coming-to-android-with-new-messaging-features-wear-os-improvements-more](https://www.neowin.net/news/big-update-coming-to-android-with-new-messaging-features-wear-os-improvements-more)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-12-01T08:14:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/12/1701416351_android-blog_header_medium.jpg" /></div>Google&#039;s latest Android release includes new messaging features such as Voice Moods, Reaction Effects, and smart home controls on Wear OS. Security is improved with FIDO2 passwordless login. <a href="https://www.neowin.net/news/big-update-coming-to-android-with-new-messaging-features-wear-os-improvements-more">Read more...</a>

## As Microsoft also pushes it to Windows 10, buggy Copilot puts the brakes on Windows 11 23H2
 - [https://www.neowin.net/news/as-microsoft-also-pushes-it-to-windows-10-buggy-copilot-puts-the-brakes-on-windows-11-23h2](https://www.neowin.net/news/as-microsoft-also-pushes-it-to-windows-10-buggy-copilot-puts-the-brakes-on-windows-11-23h2)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-12-01T06:38:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/10/1696410841_windows_copilot_red_medium.jpg" /></div>Microsoft has confirmed that a Copilot issue, which was there on Windows 11, has now been introduced in Windows 10 as well, given that the company is now pushing the feature on the latter too. <a href="https://www.neowin.net/news/as-microsoft-also-pushes-it-to-windows-10-buggy-copilot-puts-the-brakes-on-windows-11-23h2">Read more...</a>

## Google asks UK regulators to investigate Microsoft's dominance in the cloud computing market
 - [https://www.neowin.net/news/google-asks-uk-regulators-to-investigate-microsofts-dominance-in-the-cloud-computing-market](https://www.neowin.net/news/google-asks-uk-regulators-to-investigate-microsofts-dominance-in-the-cloud-computing-market)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-12-01T04:54:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2016/01/mg_8125-edit-4_medium.jpg" /></div>Google has sent a letter to the CMA alleging that Microsoft&#039;s business practices in the cloud computing industry are hampering the competition and is preventing users from switching to its rivals. <a href="https://www.neowin.net/news/google-asks-uk-regulators-to-investigate-microsofts-dominance-in-the-cloud-computing-market">Read more...</a>

## Montana's attempt to ban access to TikTok is blocked by US district judge
 - [https://www.neowin.net/news/montanas-attempt-to-ban-access-to-tiktok-is-blocked-by-us-district-judge](https://www.neowin.net/news/montanas-attempt-to-ban-access-to-tiktok-is-blocked-by-us-district-judge)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-12-01T02:56:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2021/08/1628783808_tiktok-3d_medium.jpg" /></div>U.S. District Judge Donald Molloy issued a preliminary injunction today to block the state of Montana from enforcing its law that would have banned access to TikTok in that state on January. 1, 2024. <a href="https://www.neowin.net/news/montanas-attempt-to-ban-access-to-tiktok-is-blocked-by-us-district-judge">Read more...</a>

## Microsoft Gaming CEO Phil Spencer confirms talks with "other partners" for mobile game store
 - [https://www.neowin.net/news/microsoft-gaming-ceo-phil-spencer-confirms-talks-with-other-partners-for-mobile-game-store](https://www.neowin.net/news/microsoft-gaming-ceo-phil-spencer-confirms-talks-with-other-partners-for-mobile-game-store)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-12-01T02:30:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/03/1679507919_xbox_medium.jpg" /></div>Microsoft Gaming CEO Phil Spencer has confirmed in an interview the company has been &quot;talking to other partners&quot; about launching a new mobile game store to compete directly with Apple and Google. <a href="https://www.neowin.net/news/microsoft-gaming-ceo-phil-spencer-confirms-talks-with-other-partners-for-mobile-game-store">Read more...</a>

## You can check out Season 1 of the Halo live action TV series for free on YouTube right now
 - [https://www.neowin.net/news/you-can-check-out-season-1-of-the-halo-live-action-tv-series-for-free-on-youtube-right-now](https://www.neowin.net/news/you-can-check-out-season-1-of-the-halo-live-action-tv-series-for-free-on-youtube-right-now)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-12-01T00:08:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/11/1701382597_mv5bztaxywzlztutywu0nc00nmnklwfiyjytngjjnzrmmjcznjfkxkeyxkfqcgdeqwrvb2xpbmhk._v1__medium.jpg" /></div>Paramount+ has added the entire 9-episode first season of the Halo live-action TV series to its YouTube channel, letting people in the US watch the show for free for the first time.  <a href="https://www.neowin.net/news/you-can-check-out-season-1-of-the-halo-live-action-tv-series-for-free-on-youtube-right-now">Read more...</a>

