# Source:Reclaim The Net, URL:https://reclaimthenet.org/feed/, language:en-US

## How The Government Plots to Control Your Digital Identity
 - [https://reclaimthenet.org/how-the-government-plots-to-control-your-digital-identity](https://reclaimthenet.org/how-the-government-plots-to-control-your-digital-identity)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-12-01T18:15:42+00:00

<a href="https://reclaimthenet.org/how-the-government-plots-to-control-your-digital-identity" rel="nofollow" title="How The Government Plots to Control Your Digital Identity"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/12/us-digita-id.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>A threat to privacy and free speech.</p>
<p>The post <a href="https://reclaimthenet.org/how-the-government-plots-to-control-your-digital-identity">How The Government Plots to Control Your Digital Identity</a> appeared first on <a href="https://reclaimthenet.org">Reclaim The Net</a>.</p>

## Irish Justice Minister To Grant Police Sweeping Powers To Intercept Private Conversations on Social Media Sites Under New Legislation
 - [https://reclaimthenet.org/irish-justice-minister-to-grant-police-sweeping-powers-to-intercept-private-conversations](https://reclaimthenet.org/irish-justice-minister-to-grant-police-sweeping-powers-to-intercept-private-conversations)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-12-01T18:05:01+00:00

<a href="https://reclaimthenet.org/irish-justice-minister-to-grant-police-sweeping-powers-to-intercept-private-conversations" rel="nofollow" title="Irish Justice Minister To Grant Police Sweeping Powers To Intercept Private Conversations on Social Media Sites Under New Legislation"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/11/Minister-Helen-McEntee.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>New levels of censorship and surveillance.</p>
<p>The post <a href="https://reclaimthenet.org/irish-justice-minister-to-grant-police-sweeping-powers-to-intercept-private-conversations">Irish Justice Minister To Grant Police Sweeping Powers To Intercept Private Conversations on Social Media Sites Under New Legislation</a> appeared first on <a href="https://reclaimthenet.org">Reclaim The Net</a>.</p>

## Ireland’s New Media Commission Is Calling on the Public To Report Any “Hate Speech” They See Online to the Police
 - [https://reclaimthenet.org/ireland-calling-on-the-public-to-report-any-hate-speech](https://reclaimthenet.org/ireland-calling-on-the-public-to-report-any-hate-speech)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-12-01T17:58:08+00:00

<a href="https://reclaimthenet.org/ireland-calling-on-the-public-to-report-any-hate-speech" rel="nofollow" title="Ireland’s New Media Commission Is Calling on the Public To Report Any “Hate Speech” They See Online to the Police"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/11/Catherine-Martin.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Speech police.</p>
<p>The post <a href="https://reclaimthenet.org/ireland-calling-on-the-public-to-report-any-hate-speech">Ireland’s New Media Commission Is Calling on the Public To Report Any “Hate Speech” They See Online to the Police</a> appeared first on <a href="https://reclaimthenet.org">Reclaim The Net</a>.</p>

## Trump Prosecutor Jack Smith’s Overreaching Warrant Seeks Data on People Who Liked, Retweeted Trump Tweets
 - [https://reclaimthenet.org/trump-prosecutor-jack-smith-overreaching-warrant](https://reclaimthenet.org/trump-prosecutor-jack-smith-overreaching-warrant)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-12-01T17:23:07+00:00

<a href="https://reclaimthenet.org/trump-prosecutor-jack-smith-overreaching-warrant" rel="nofollow" title="Trump Prosecutor Jack Smith’s Overreaching Warrant Seeks Data on People Who Liked, Retweeted Trump Tweets"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/11/trump-warrant.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Clearly not narrow in scope.</p>
<p>The post <a href="https://reclaimthenet.org/trump-prosecutor-jack-smith-overreaching-warrant">Trump Prosecutor Jack Smith’s Overreaching Warrant Seeks Data on People Who Liked, Retweeted Trump Tweets</a> appeared first on <a href="https://reclaimthenet.org">Reclaim The Net</a>.</p>

## Texas Attorney General Ken Paxton Files Lawsuit Against Pfizer, Alleging It Conspired To Censor Vaccine Criticism
 - [https://reclaimthenet.org/texas-attorney-general-ken-paxton-files-lawsuit-against-pfizer](https://reclaimthenet.org/texas-attorney-general-ken-paxton-files-lawsuit-against-pfizer)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-12-01T12:38:19+00:00

<a href="https://reclaimthenet.org/texas-attorney-general-ken-paxton-files-lawsuit-against-pfizer" rel="nofollow" title="Texas Attorney General Ken Paxton Files Lawsuit Against Pfizer, Alleging It Conspired To Censor Vaccine Criticism"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/11/pen-paxton-pf.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Paxton highlighted the actions of a Pfizer board member's demands on social media platforms.</p>
<p>The post <a href="https://reclaimthenet.org/texas-attorney-general-ken-paxton-files-lawsuit-against-pfizer">Texas Attorney General Ken Paxton Files Lawsuit Against Pfizer, Alleging It Conspired To Censor Vaccine Criticism</a> appeared first on <a href="https://reclaimthenet.org">Reclaim The Net</a>.</p>

