# Source:TVN24 Ze świata, URL:https://tvn24.pl/wiadomosci-ze-swiata,2.xml, language:pl-PL

## Tusk zabiera głos w sprawie Glapińskiego. "Nerwowość ma swoje uzasadnienie"
 - [https://tvn24.pl/biznes/z-kraju/prezes-nbp-a-trybunal-stanu-donald-tusk-nerwowosc-wokol-adama-glapinskiego-ma-swoje-uzasadnienie-st7464653?source=rss](https://tvn24.pl/biznes/z-kraju/prezes-nbp-a-trybunal-stanu-donald-tusk-nerwowosc-wokol-adama-glapinskiego-ma-swoje-uzasadnienie-st7464653?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-12-01T12:51:25+00:00

<img alt="Tusk zabiera głos w sprawie Glapińskiego. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-k14wtf-donald-tusk-marcin-kierwinski-borys-budka-w-sejmie-7464678/alternates/LANDSCAPE_1280" />
    Nie zrobimy niczego, co podważyłoby zaufanie do państwa polskiego - zapowiedział lider Platformy Obywatelskiej Donald Tusk, pytany o wniosek do Trybunału Stanu wobec prezesa Narodowego Banku Polskiego Adama Glapińskiego. Zaznaczył, że w tej sprawie będzie jeszcze podejmowana decyzja. Marszałek Sejmu Szymon Hołownia dodał, że nad każdym takim wnioskiem trzeba się dobrze zastanowić.

## Walka policji z dzikimi lokatorami zajmującymi dwa budynki w Barcelonie
 - [https://tvn24.pl/swiat/barcelona-walka-policji-z-dzikimi-lokatorami-zajmujacymi-dwa-budynki-na-placu-bonanova-7463840?source=rss](https://tvn24.pl/swiat/barcelona-walka-policji-z-dzikimi-lokatorami-zajmujacymi-dwa-budynki-na-placu-bonanova-7463840?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-12-01T10:08:52+00:00

<img alt="Walka policji z dzikimi lokatorami zajmującymi dwa budynki w Barcelonie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3eufn2-walka-policji-z-dzikimi-lokatorami-zajmujacymi-dwa-budynki-w-barcelonie-7463838/alternates/LANDSCAPE_1280" />
    Katalońska policja starła się w Barcelonie z dzikimi lokatorami zajmującymi dwa budynki na placu Bonanova. Jak poinformowała policja, podczas eksmisji zostało zatrzymanych siedem osób. Jeden funkcjonariusz odniósł obrażenia.

