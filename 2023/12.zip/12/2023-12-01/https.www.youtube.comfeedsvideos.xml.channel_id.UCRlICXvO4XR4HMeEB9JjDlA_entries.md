# Source:Thoughty2, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRlICXvO4XR4HMeEB9JjDlA, language:en-US

## Oppenheimer's Famous Bombs Could Have Been Even Bigger
 - [https://www.youtube.com/watch?v=P19-bOr9odM](https://www.youtube.com/watch?v=P19-bOr9odM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRlICXvO4XR4HMeEB9JjDlA
 - date published: 2023-12-01T19:00:19+00:00

Thoughty2 Patreon & Discord: https://www.patreon.com/thoughty2
Thoughty2 Audiobook: https://geni.us/t2audio
Thoughty2 Book: https://geni.us/t2book

Follow Thoughty2
TikTok: https://www.tiktok.com/@realthoughty2
Facebook: https://facebook.com/thoughty2
Instagram: https://instagram.com/thoughty2
Website: http://thoughty2.com

About Thoughty2
Thoughty2 (Arran) is a British YouTuber and gatekeeper of useless facts. Thoughty2 creates mind-blowing factual videos about science, tech, history, opinion and just about everything else.
#Thoughty2

