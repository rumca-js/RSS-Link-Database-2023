# Source:Wydarzenia Interia, URL:https://wydarzenia.interia.pl/feed, language:pl-PL

## Kapitan zabronił pasażerowi wylotu. Wszystko przez wybuch złości
 - [https://wydarzenia.interia.pl/slaskie/news-kapitan-zabronil-pasazerowi-wylotu-wszystko-przez-wybuch-zlo,nId,7184201](https://wydarzenia.interia.pl/slaskie/news-kapitan-zabronil-pasazerowi-wylotu-wszystko-przez-wybuch-zlo,nId,7184201)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-01T21:28:49+00:00

<p><a href="https://wydarzenia.interia.pl/slaskie/news-kapitan-zabronil-pasazerowi-wylotu-wszystko-przez-wybuch-zlo,nId,7184201"><img align="left" alt="Kapitan zabronił pasażerowi wylotu. Wszystko przez wybuch złości" src="https://i.iplsc.com/kapitan-zabronil-pasazerowi-wylotu-wszystko-przez-wybuch-zlo/000I4V4V3LPV8GO4-C321.jpg" /></a>W sprawie 35-letniego podróżnego, obywatela Turcji, musiała interweniować Straż Graniczna na lotnisku w Katowicach. Wszystko przez jego nietypowe zachowanie. Gdy dowiedział się, że będzie musiał uiścić opłatę za nadbagaż, zdenerwował się do tego stopnia, że wtargnął na płytę lotniska, a następnie do środka samolotu. Po interwencji kapitan zdecydował, że pasażer na Maltę nie poleci. Dodatkowo został ukarany mandatem.</p><br clear="all" />

## Białoruś zawieszona w światowej organizacji. "Nie możemy tego akceptować"
 - [https://wydarzenia.interia.pl/zagranica/news-bialorus-zawieszona-w-swiatowej-organizacji-nie-mozemy-tego-,nId,7184186](https://wydarzenia.interia.pl/zagranica/news-bialorus-zawieszona-w-swiatowej-organizacji-nie-mozemy-tego-,nId,7184186)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-01T21:19:41+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-bialorus-zawieszona-w-swiatowej-organizacji-nie-mozemy-tego-,nId,7184186"><img align="left" alt="Białoruś zawieszona w światowej organizacji. &quot;Nie możemy tego akceptować&quot;" src="https://i.iplsc.com/bialorus-zawieszona-w-swiatowej-organizacji-nie-mozemy-tego/000GFFTAXPOEVAPS-C321.jpg" /></a>Białoruś została zawieszona w prawach członka Międzynarodowego Czerwonego Krzyża i Czerwonego Półksiężyca - przekazała organizacja w oficjalnym oświadczeniu. Decyzja została podyktowana niezastosowaniem się Mińska do wniosku Rady Zarządzającej IFRC o odwołanie ze stanowiska sekretarza generalnego białoruskiej komórki Dymitra Szewcowa. Mężczyzna jest podejrzany o współudział w deportacji ukraińskich dzieci oraz popieranie rozmieszenia rosyjskiej broni nuklearnej na terytorium Białorusi. Sam zainteresowany uznał decyzję za &quot;upolitycznioną&quot;. </p><br clear="all" />

## Hezbollah zaatakował wojska izraelskie. Uzasadnił to "wsparciem"
 - [https://wydarzenia.interia.pl/raport-wojna-w-izraelu/news-hezbollah-zaatakowal-wojska-izraelskie-uzasadnil-to-wsparcie,nId,7184187](https://wydarzenia.interia.pl/raport-wojna-w-izraelu/news-hezbollah-zaatakowal-wojska-izraelskie-uzasadnil-to-wsparcie,nId,7184187)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-01T20:47:52+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wojna-w-izraelu/news-hezbollah-zaatakowal-wojska-izraelskie-uzasadnil-to-wsparcie,nId,7184187"><img align="left" alt="Hezbollah zaatakował wojska izraelskie. Uzasadnił to &quot;wsparciem&quot;" src="https://i.iplsc.com/hezbollah-zaatakowal-wojska-izraelskie-uzasadnil-to-wsparcie/000I4V283CJQ0UAV-C321.jpg" /></a>Hezbollah poinformował o dokonanych w piątek atakach, podając, że ostrzelał on kilka posterunków granicznych armii izraelskiej. Ta odpowiedziała ogniem. W wyniku ostrzału zginęły dwie osoby - przekazała agencja AP, powołując się na lokalne władze libańskie.</p><br clear="all" />

## Nadciąga pogodowy armagedon. Potężne śnieżyce i siarczysty mróz
 - [https://wydarzenia.interia.pl/kraj/news-nadciaga-pogodowy-armagedon-potezne-sniezyce-i-siarczysty-mr,nId,7184168](https://wydarzenia.interia.pl/kraj/news-nadciaga-pogodowy-armagedon-potezne-sniezyce-i-siarczysty-mr,nId,7184168)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-01T20:16:05+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-nadciaga-pogodowy-armagedon-potezne-sniezyce-i-siarczysty-mr,nId,7184168"><img align="left" alt="Nadciąga pogodowy armagedon. Potężne śnieżyce i siarczysty mróz" src="https://i.iplsc.com/nadciaga-pogodowy-armagedon-potezne-sniezyce-i-siarczysty-mr/000I4UULUGO3FW9L-C321.jpg" /></a>Część Polski czeka prawdziwy, pogodowy armagedon - w nocy spodziewane są potężne śnieżyce, a w pasie od Śląska przez Małopolskę po Lubelszczyznę i Podkarpacie wystąpi gołoledź. To jednak nie wszystko - po silnych opadach nad kraj nadciągnie siarczysty mróz, a termometry wskażą nawet -25 stopni. To efekt uderzenia niżu Robin, który nadciąga znad Alp.</p><br clear="all" />

## 70-latka urodziła bliźnięta. "Dokonaliśmy czegoś niezwykłego"
 - [https://wydarzenia.interia.pl/ciekawostki/news-70-latka-urodzila-bliznieta-dokonalismy-czegos-niezwyklego,nId,7184133](https://wydarzenia.interia.pl/ciekawostki/news-70-latka-urodzila-bliznieta-dokonalismy-czegos-niezwyklego,nId,7184133)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-01T20:11:03+00:00

<p><a href="https://wydarzenia.interia.pl/ciekawostki/news-70-latka-urodzila-bliznieta-dokonalismy-czegos-niezwyklego,nId,7184133"><img align="left" alt="70-latka urodziła bliźnięta. &quot;Dokonaliśmy czegoś niezwykłego&quot;" src="https://i.iplsc.com/70-latka-urodzila-bliznieta-dokonalismy-czegos-niezwyklego/000I4UJOJY87C4JF-C321.jpg" /></a>70-letnia Ugandyjka urodziła bliźnięta - chłopca i dziewczynkę. &quot;Udało nam się osiągnąć coś niezwykłego - to najstarsza matka w Afryce!&quot; - napisał w mediach społecznościowych szpital, w którym dzieci przyszły na świat. Bliźnięta urodziły się jako wcześniaki, jednak stan ich zdrowia jest stabilny. </p><br clear="all" />

## Sensacja w Nowej Zelandii. Pierwsze takie narodziny od ponad 150 lat
 - [https://wydarzenia.interia.pl/zagranica/news-sensacja-w-nowej-zelandii-pierwsze-takie-narodziny-od-ponad-,nId,7184122](https://wydarzenia.interia.pl/zagranica/news-sensacja-w-nowej-zelandii-pierwsze-takie-narodziny-od-ponad-,nId,7184122)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-01T19:25:39+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-sensacja-w-nowej-zelandii-pierwsze-takie-narodziny-od-ponad-,nId,7184122"><img align="left" alt="Sensacja w Nowej Zelandii. Pierwsze takie narodziny od ponad 150 lat" src="https://i.iplsc.com/sensacja-w-nowej-zelandii-pierwsze-takie-narodziny-od-ponad/000I4UEBPMY2ERQF-C321.jpg" /></a>Do niesamowitego odkrycia doszło na początku tygodnia w Wellington w Nowej Zelandii. Znaleziono tam dwa pisklęta kiwi. To pierwsze od ponad 150 lat dzikie narodziny tego ptaka na przedmieściach stolicy kraju. Populacja kiwi - symbolu Nowej Zelandii - nieustannie maleje, a eksperci ostrzegają, że ptaki mogą wyginąć w ciągu dwóch pokoleń.</p><br clear="all" />

## Wielka radość w Nowej Zelandii. Pierwsze takie narodziny od ponad 150 lat
 - [https://wydarzenia.interia.pl/zagranica/news-wielka-radosc-w-nowej-zelandii-pierwsze-takie-narodziny-od-p,nId,7184122](https://wydarzenia.interia.pl/zagranica/news-wielka-radosc-w-nowej-zelandii-pierwsze-takie-narodziny-od-p,nId,7184122)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-01T19:25:39+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wielka-radosc-w-nowej-zelandii-pierwsze-takie-narodziny-od-p,nId,7184122"><img align="left" alt="Wielka radość w Nowej Zelandii. Pierwsze takie narodziny od ponad 150 lat" src="https://i.iplsc.com/wielka-radosc-w-nowej-zelandii-pierwsze-takie-narodziny-od-p/000I4UEBPMY2ERQF-C321.jpg" /></a>Do niesamowitego odkrycia doszło na początku tygodnia w Wellington w Nowej Zelandii. Znaleziono tam dwa pisklęta kiwi. To pierwsze od ponad 150 lat dzikie narodziny tego ptaka w stolicy kraju. Populacja kiwi - symbolu Nowej Zelandii - nieustannie maleje, a eksperci ostrzegają, że ptaki mogą wyginąć w ciągu dwóch pokoleń.</p><br clear="all" />

## Jak komputery wpływają na uczniów? Naukowcy alarmują
 - [https://wydarzenia.interia.pl/zagranica/news-jak-komputery-wplywaja-na-uczniow-naukowcy-alarmuja,nId,7184136](https://wydarzenia.interia.pl/zagranica/news-jak-komputery-wplywaja-na-uczniow-naukowcy-alarmuja,nId,7184136)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-01T19:15:55+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-jak-komputery-wplywaja-na-uczniow-naukowcy-alarmuja,nId,7184136"><img align="left" alt="Jak komputery wpływają na uczniów? Naukowcy alarmują" src="https://i.iplsc.com/jak-komputery-wplywaja-na-uczniow-naukowcy-alarmuja/000I4UKA4JD98BVJ-C321.jpg" /></a>Część naukowców jest przeciwna dalszemu rozwojowi cyfryzacji w niemieckich szkołach. Wskazują, że używanie komputerów w edukacji ogranicza kontakty społeczne i nie pozwala wystarczająco skupić się na indywidualnym nauczaniu. Badacze wystosowali w tej sprawie petycję.  </p><br clear="all" />

## Putin podpisał ważny dekret. Dotyczy armii i od razu wchodzi w życie
 - [https://wydarzenia.interia.pl/zagranica/news-putin-podpisal-wazny-dekret-dotyczy-armii-i-od-razu-wchodzi-,nId,7184164](https://wydarzenia.interia.pl/zagranica/news-putin-podpisal-wazny-dekret-dotyczy-armii-i-od-razu-wchodzi-,nId,7184164)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-01T18:54:40+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-putin-podpisal-wazny-dekret-dotyczy-armii-i-od-razu-wchodzi-,nId,7184164"><img align="left" alt="Putin podpisał ważny dekret. Dotyczy armii i od razu wchodzi w życie" src="https://i.iplsc.com/putin-podpisal-wazny-dekret-dotyczy-armii-i-od-razu-wchodzi/000I4UPHGV2O97AT-C321.jpg" /></a>Prezydent Rosji Władimir Putin podpisał w piątek dekret zwiększający liczebność armii o 15 procent. Decyzja ta ma być związana z &quot;rosnącymi zagrożeniami dla Rosji&quot;, dotyczącymi &quot;specjalnej operacji wojskowej i ciągłej ekspansji NATO&quot;. </p><br clear="all" />

## 61-latek potrzebował pomocy. Policję zaalarmowało dziecko
 - [https://wydarzenia.interia.pl/warminsko-mazurskie/news-61-latek-potrzebowal-pomocy-policje-zaalarmowalo-dziecko,nId,7183939](https://wydarzenia.interia.pl/warminsko-mazurskie/news-61-latek-potrzebowal-pomocy-policje-zaalarmowalo-dziecko,nId,7183939)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-01T18:10:57+00:00

<p><a href="https://wydarzenia.interia.pl/warminsko-mazurskie/news-61-latek-potrzebowal-pomocy-policje-zaalarmowalo-dziecko,nId,7183939"><img align="left" alt="61-latek potrzebował pomocy. Policję zaalarmowało dziecko" src="https://i.iplsc.com/61-latek-potrzebowal-pomocy-policje-zaalarmowalo-dziecko/000GNF4VF6KFCJMJ-C321.jpg" /></a>Godnym naśladowania zachowaniem wykazał się 10-latek, który ruszył na pomoc spotkanemu na ulicy mężczyźnie. Gdy tylko chłopiec zauważył 61-latka, który upadł na jezdnię, natychmiast pobiegł po pomoc do znajdujących się w pobliżu policjantów. 
</p><br clear="all" />

## Napad na kantor w Tarnogrodzie. Trwa obława
 - [https://wydarzenia.interia.pl/lubelskie/news-napad-na-kantor-w-tarnogrodzie-trwa-oblawa,nId,7184134](https://wydarzenia.interia.pl/lubelskie/news-napad-na-kantor-w-tarnogrodzie-trwa-oblawa,nId,7184134)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-01T17:48:44+00:00

<p><a href="https://wydarzenia.interia.pl/lubelskie/news-napad-na-kantor-w-tarnogrodzie-trwa-oblawa,nId,7184134"><img align="left" alt="Napad na kantor w Tarnogrodzie. Trwa obława" src="https://i.iplsc.com/napad-na-kantor-w-tarnogrodzie-trwa-oblawa/000I4UH44B767IYB-C321.jpg" /></a>W Tarnogrodzie (woj. lubelskie) doszło w piątek do napadu na kantor. Nieznany mężczyzna miał wcześniej sterroryzować pracującą tam kobietę, obezwładnić ją, następnie ukraść pieniądze i uciec. Napastnik posiadał przy sobie przedmiot przypominający broń palną - przekazała w rozmowie z Interią asp. Joanna Klimek, oficer prasowa Komendanta Powiatowego Policji w Biłgoraju. Trwa policyjna obława. </p><br clear="all" />

## 11-latek w szkole z nożem. "Miał straszyć młodszych kolegów"
 - [https://wydarzenia.interia.pl/wiadomosci-lokalne/news-11-latek-w-szkole-z-nozem-mial-straszyc-mlodszych-kolegow,nId,7183963](https://wydarzenia.interia.pl/wiadomosci-lokalne/news-11-latek-w-szkole-z-nozem-mial-straszyc-mlodszych-kolegow,nId,7183963)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-01T17:26:08+00:00

<p><a href="https://wydarzenia.interia.pl/wiadomosci-lokalne/news-11-latek-w-szkole-z-nozem-mial-straszyc-mlodszych-kolegow,nId,7183963"><img align="left" alt="11-latek w szkole z nożem. &quot;Miał straszyć młodszych kolegów&quot;" src="https://i.iplsc.com/11-latek-w-szkole-z-nozem-mial-straszyc-mlodszych-kolegow/000I4UEA4GYHKC3C-C321.jpg" /></a>Sąd Rodzinny zajmie się sprawą 11-latka, który przyniósł nóż do szkoły podstawowej w Łukowie (woj. lubelskie). Chłopiec miał straszyć nim młodszych kolegów. Przestraszone dzieci zgłosiły sprawę nauczycielom. 
</p><br clear="all" />

## Ogromny wzrost zakażeń dengą w Europie. Eksperci biją na alarm
 - [https://wydarzenia.interia.pl/zagranica/news-ogromny-wzrost-zakazen-denga-w-europie-eksperci-bija-na-alar,nId,7183868](https://wydarzenia.interia.pl/zagranica/news-ogromny-wzrost-zakazen-denga-w-europie-eksperci-bija-na-alar,nId,7183868)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-01T17:04:17+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-ogromny-wzrost-zakazen-denga-w-europie-eksperci-bija-na-alar,nId,7183868"><img align="left" alt="Ogromny wzrost zakażeń dengą w Europie. Eksperci biją na alarm" src="https://i.iplsc.com/ogromny-wzrost-zakazen-denga-w-europie-eksperci-bija-na-alar/000I4TGFGH420T58-C321.jpg" /></a>Denga rozprzestrzenia się w Europie w najszybszym tempie od niemal 80 lat - alarmują eksperci. Dotychczas wirus był na naszym kontynencie niezwykle rzadki, a obecne zakażenia mają duży związek z podróżami zagranicznymi. Na trzy tysiące przypadków tylko dziewięć zostało nabytych lokalnie.</p><br clear="all" />

## Projekt CPK do likwidacji? Poseł KO wyjaśnia
 - [https://wydarzenia.interia.pl/kraj/news-projekt-cpk-do-likwidacji-posel-ko-wyjasnia,nId,7183919](https://wydarzenia.interia.pl/kraj/news-projekt-cpk-do-likwidacji-posel-ko-wyjasnia,nId,7183919)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-01T16:37:28+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-projekt-cpk-do-likwidacji-posel-ko-wyjasnia,nId,7183919"><img align="left" alt="Projekt CPK do likwidacji? Poseł KO wyjaśnia" src="https://i.iplsc.com/projekt-cpk-do-likwidacji-posel-ko-wyjasnia/000I4TZS9MD0UC6T-C321.jpg" /></a>Przyszłość Centralnego Portu Komunikacyjnego jeszcze nie jest przesądzona. Projekt autorstwa Prawa i Sprawiedliwości budzi wątpliwości nowej większości parlamentarnej, ale politycy potrzebują szerszego obrazu sytuacji. - Najpierw audyt, potem decyzja - mówi poseł Maciej Lasek w rozmowie z Interią. </p><br clear="all" />

## Oświadczenia polityków. Takie majątki mają liderzy największych partii
 - [https://wydarzenia.interia.pl/kraj/news-oswiadczenia-politykow-takie-majatki-maja-liderzy-najwiekszy,nId,7183941](https://wydarzenia.interia.pl/kraj/news-oswiadczenia-politykow-takie-majatki-maja-liderzy-najwiekszy,nId,7183941)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-01T16:13:32+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-oswiadczenia-politykow-takie-majatki-maja-liderzy-najwiekszy,nId,7183941"><img align="left" alt="Oświadczenia polityków. Takie majątki mają liderzy największych partii" src="https://i.iplsc.com/oswiadczenia-politykow-takie-majatki-maja-liderzy-najwiekszy/0004TY3X3BBPLWR4-C321.jpg" /></a>Na sejmowej stronie pojawiły się oświadczenia majątkowe polityków. Sprawdziliśmy, jakimi oszczędnościami dysponują liderzy największych partii politycznych: Szymon Hołownia, Władysław Kosiniak-Kamysz, Włodzimierz Czarzasty i Krzysztof Bosak.</p><br clear="all" />

## Kaczyński i Tusk złożyli oświadczenia majątkowe. Spore oszczędności
 - [https://wydarzenia.interia.pl/kraj/news-kaczynski-i-tusk-zlozyli-oswiadczenia-majatkowe-spore-oszcze,nId,7183916](https://wydarzenia.interia.pl/kraj/news-kaczynski-i-tusk-zlozyli-oswiadczenia-majatkowe-spore-oszcze,nId,7183916)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-01T15:35:43+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-kaczynski-i-tusk-zlozyli-oswiadczenia-majatkowe-spore-oszcze,nId,7183916"><img align="left" alt="Kaczyński i Tusk złożyli oświadczenia majątkowe. Spore oszczędności " src="https://i.iplsc.com/kaczynski-i-tusk-zlozyli-oswiadczenia-majatkowe-spore-oszcze/000I2ZILAE6OYPQI-C321.jpg" /></a>Na stronie sejmowej pojawiły się oświadczenia majątkowe Jarosława Kaczyńskiego i Donalda Tuska. Prezes PiS za pełnienie funkcji wicepremiera otrzymał ponad 215 tys. złotych, z kolei kandydat nowej większości na premiera dysponuje sporymi oszczędnościami na ponad milion złotych i ma sporą emeryturę z Komisji Europejskiej.</p><br clear="all" />

## Podróże limitowane? Wraca temat "paszportów węglowych"
 - [https://wydarzenia.interia.pl/ciekawostki/news-podroze-limitowane-wraca-temat-paszportow-weglowych,nId,7181117](https://wydarzenia.interia.pl/ciekawostki/news-podroze-limitowane-wraca-temat-paszportow-weglowych,nId,7181117)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-01T14:30:00+00:00

<p><a href="https://wydarzenia.interia.pl/ciekawostki/news-podroze-limitowane-wraca-temat-paszportow-weglowych,nId,7181117"><img align="left" alt="Podróże limitowane? Wraca temat &quot;paszportów węglowych&quot;" src="https://i.iplsc.com/podroze-limitowane-wraca-temat-paszportow-weglowych/000I4SAGT8NM5V0D-C321.jpg" /></a>Branża turystyczna wciąż wraca do siebie po pandemii COVID-19, jednak najnowsze dane sugerują, że to końcowe etapy regeneracji. Wzrost zainteresowania wycieczkami bezpośrednio wiąże się też z większym popytem na bilety lotnicze – to z kolei na nowo rozgrzewa dyskusję o branży lotniczej w kontekście emisji gazów cieplarnianych. Jednym z elementów całego systemu mają być tzw. paszporty węglowe. Na czym polega to rozwiązanie? Kiedy może wejść w życie?</p><br clear="all" />

## Andrzej Duda o ustawie ws. in vitro: Podchodzę do tego bardzo spokojnie
 - [https://wydarzenia.interia.pl/kraj/news-prezydent-o-ustawie-ws-in-vitro-podchodze-do-tego-bardzo-spo,nId,7183812](https://wydarzenia.interia.pl/kraj/news-prezydent-o-ustawie-ws-in-vitro-podchodze-do-tego-bardzo-spo,nId,7183812)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-01T14:18:51+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-prezydent-o-ustawie-ws-in-vitro-podchodze-do-tego-bardzo-spo,nId,7183812"><img align="left" alt="Andrzej Duda o ustawie ws. in vitro: Podchodzę do tego bardzo spokojnie" src="https://i.iplsc.com/andrzej-duda-o-ustawie-ws-in-vitro-podchodze-do-tego-bardzo/000I4SLKJHRGXFA6-C321.jpg" /></a>- Pochylę się nad tymi przepisami, tak jak nad każdą ustawą - powiedział prezydent Andrzej Duda, pytany, czy jest za finansowaniem in vitro z budżetu państwa. W środę posłowie uchwalili nowelizację ustawy o świadczeniach opieki zdrowotnej finansowanych ze środków publicznych, która zakłada refundację tej metody z budżetu państwa. </p><br clear="all" />

## Blokada na granicy: Wina Morawieckiego? A co z naszymi relacjami z Unią?
 - [https://wydarzenia.interia.pl/felietony/news-blokada-na-granicy-wina-morawieckiego-a-co-z-naszymi-relacja,nId,7183819](https://wydarzenia.interia.pl/felietony/news-blokada-na-granicy-wina-morawieckiego-a-co-z-naszymi-relacja,nId,7183819)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-01T14:01:23+00:00

<p><a href="https://wydarzenia.interia.pl/felietony/news-blokada-na-granicy-wina-morawieckiego-a-co-z-naszymi-relacja,nId,7183819"><img align="left" alt="Blokada na granicy: Wina Morawieckiego? A co z naszymi relacjami z Unią? " src="https://i.iplsc.com/blokada-na-granicy-wina-morawieckiego-a-co-z-naszymi-relacja/000I4SL923A61N72-C321.jpg" /></a>Tusk jako krytyk nadmiernej ustępliwości wobec Unii to jeden wielki paradoks. Przy akcji transportowców krząta się poseł KO Michał Kołodziejczak. To co, zmierza do polexitu? </p><br clear="all" />

## Coraz trudniejsze warunki w górach. Zasypuje szlaki
 - [https://wydarzenia.interia.pl/kraj/news-coraz-trudniejsze-warunki-w-gorach-zasypuje-szlaki,nId,7183841](https://wydarzenia.interia.pl/kraj/news-coraz-trudniejsze-warunki-w-gorach-zasypuje-szlaki,nId,7183841)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-01T13:56:40+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-coraz-trudniejsze-warunki-w-gorach-zasypuje-szlaki,nId,7183841"><img align="left" alt="Coraz trudniejsze warunki w górach. Zasypuje szlaki" src="https://i.iplsc.com/coraz-trudniejsze-warunki-w-gorach-zasypuje-szlaki/000I4SK4V1G7NRSS-C321.jpg" /></a>Pogoda w górach staje się coraz bardziej wymagająca. Z powodu dużej ilości śniegu tworzą się głębokie zaspy, a w Tatrach obowiązuje drugi stopień zagrożenia lawinowego. Z kolei w Karkonoszach miejscami zaspy mają nawet dwa metry wysokości. Specjaliści podkreślają, że osoby wybierające się w góry muszą zabrać ze sobą zimowy sprzęt turystyczny.</p><br clear="all" />

## Śmigłowiec rozbił się na autostradzie. Trzy osoby ranne
 - [https://wydarzenia.interia.pl/zagranica/news-smiglowiec-rozbil-sie-na-autostradzie-trzy-osoby-ranne,nId,7183779](https://wydarzenia.interia.pl/zagranica/news-smiglowiec-rozbil-sie-na-autostradzie-trzy-osoby-ranne,nId,7183779)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-01T13:41:26+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-smiglowiec-rozbil-sie-na-autostradzie-trzy-osoby-ranne,nId,7183779"><img align="left" alt="Śmigłowiec rozbił się na autostradzie. Trzy osoby ranne" src="https://i.iplsc.com/smiglowiec-rozbil-sie-na-autostradzie-trzy-osoby-ranne/000I4SG0FN03EPG4-C321.jpg" /></a>Prywatny śmigłowiec rozbił się na środkowym pasie obwodnicy M-40 w pobliżu Madrytu. W wyniku wypadku obrażenia odniosła dwójka pasażerów, a także kierowca samochodu, który znalazł się na drodze w chwili wypadku. Ranni zostali przetransportowani do szpitala, ich życiu nie zagraża niebezpieczeństwo.</p><br clear="all" />

## Prezydent o transformacji energetycznej. "Człowiek musi być na czele"
 - [https://wydarzenia.interia.pl/zagranica/news-prezydent-o-transformacji-energetycznej-czlowiek-musi-byc-na,nId,7183799](https://wydarzenia.interia.pl/zagranica/news-prezydent-o-transformacji-energetycznej-czlowiek-musi-byc-na,nId,7183799)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-01T13:17:29+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-prezydent-o-transformacji-energetycznej-czlowiek-musi-byc-na,nId,7183799"><img align="left" alt="Prezydent o transformacji energetycznej. &quot;Człowiek musi być na czele&quot;" src="https://i.iplsc.com/prezydent-o-transformacji-energetycznej-czlowiek-musi-byc-na/000I4SBSGPAAL3MX-C321.jpg" /></a>- Człowiek i jego potrzeby muszą być na czele transformacji energetycznej. To obecne i przyszłe zdrowie, bezpieczeństwo i dobrobyt ludzi powinny być umieszczane w centrum każdej polityki klimatycznej - stwierdził prezydent Andrzej Duda, który przebywa na szczycie klimatycznym COP28 w Dubaju. Głowa państwa odniosła się również do budowy elektrowni jądrowej w Polsce, podkreślając, że stabilna energia pochodząca z atomu jest niezbędna w dużym i uprzemysłowionym kraju, jakim jest Polska.</p><br clear="all" />

## Były prezydent Ukrainy nie może opuścić kraju. Wskazał winnego
 - [https://wydarzenia.interia.pl/zagranica/news-byly-prezydent-ukrainy-nie-moze-opuscic-kraju-wskazal-winneg,nId,7183497](https://wydarzenia.interia.pl/zagranica/news-byly-prezydent-ukrainy-nie-moze-opuscic-kraju-wskazal-winneg,nId,7183497)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-01T12:15:57+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-byly-prezydent-ukrainy-nie-moze-opuscic-kraju-wskazal-winneg,nId,7183497"><img align="left" alt="Były prezydent Ukrainy nie może opuścić kraju. Wskazał winnego" src="https://i.iplsc.com/byly-prezydent-ukrainy-nie-moze-opuscic-kraju-wskazal-winneg/000I4RCTMFCF6KC2-C321.jpg" /></a>Petro Poroszenko nie został wypuszczony poza granice państwa. Były prezydent chciał dostać się do Polski, by negocjować w sprawie strajku przewoźników, na przejściu zatrzymali go jednak ukraińscy strażnicy graniczni. Polityk poskarżył się na nieoczekiwaną sytuację w mediach społecznościowych, a winą obarczył Wołodymyra Zełenskiego. </p><br clear="all" />

## Śmierć 14-latki w Andrychowie. Wstępne wyniki sekcji zwłok
 - [https://wydarzenia.interia.pl/malopolskie/news-smierc-14-latki-w-andrychowie-wstepne-wyniki-sekcji-zwlok,nId,7183513](https://wydarzenia.interia.pl/malopolskie/news-smierc-14-latki-w-andrychowie-wstepne-wyniki-sekcji-zwlok,nId,7183513)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-01T12:10:06+00:00

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-smierc-14-latki-w-andrychowie-wstepne-wyniki-sekcji-zwlok,nId,7183513"><img align="left" alt="Śmierć 14-latki w Andrychowie. Wstępne wyniki sekcji zwłok" src="https://i.iplsc.com/smierc-14-latki-w-andrychowie-wstepne-wyniki-sekcji-zwlok/000I4S29RYHJBXR0-C321.jpg" /></a>- Wstępną przyczyną zgonu 14-latki był obrzęk mózgu spowodowany masywnym krwawieniem - przekazał w rozmowie z Polsat News rzecznik Prokuratury Okręgowej w Krakowie. Dziewczynka przez kilka godzin była poszukiwana przez rodzinę i bliskich. Siedziała przed sklepem w centrum Andrychowa. </p><br clear="all" />

## Jarmarki świąteczne pod lupą. "Zagrożenie jest realne"
 - [https://wydarzenia.interia.pl/zagranica/news-jarmarki-swiateczne-pod-lupa-zagrozenie-jest-realne,nId,7183354](https://wydarzenia.interia.pl/zagranica/news-jarmarki-swiateczne-pod-lupa-zagrozenie-jest-realne,nId,7183354)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-01T12:01:36+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-jarmarki-swiateczne-pod-lupa-zagrozenie-jest-realne,nId,7183354"><img align="left" alt="Jarmarki świąteczne pod lupą. &quot;Zagrożenie jest realne&quot;" src="https://i.iplsc.com/jarmarki-swiateczne-pod-lupa-zagrozenie-jest-realne/000I4RI8LVJ4XD3A-C321.jpg" /></a>Niemiecka policja zatrzymała 20-letniego mężczyznę z Bliskiego Wschodu. Jest on podejrzany o planowanie ataku podczas jarmarku świątecznego. To już trzecie aresztowanie w Niemczech związane z możliwym atakiem w okresie świątecznym. - Zagrożenie jest realne i ponownie wzrosło - powiedział szef Federalnego Urzędu Ochrony Konstytucji Thomas Haldenwang.</p><br clear="all" />

## Zmiany w przepisach dotyczących wcześniejszych emerytur. Skorzystają tysiące Polaków
 - [https://wydarzenia.interia.pl/kraj/news-zmiany-w-przepisach-dotyczacych-wczesniejszych-emerytur-skor,nId,7177113](https://wydarzenia.interia.pl/kraj/news-zmiany-w-przepisach-dotyczacych-wczesniejszych-emerytur-skor,nId,7177113)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-01T11:55:51+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-zmiany-w-przepisach-dotyczacych-wczesniejszych-emerytur-skor,nId,7177113"><img align="left" alt="Zmiany w przepisach dotyczących wcześniejszych emerytur. Skorzystają tysiące Polaków" src="https://i.iplsc.com/zmiany-w-przepisach-dotyczacych-wczesniejszych-emerytur-skor/000I4R16NAGFQFXG-C321.jpg" /></a>Od nowego roku w życie wchodzą istotne zmiany w ustawie o emeryturach pomostowych. Dzięki nim więcej osób będzie mogło skorzystać z możliwości pobierania wcześniejszego świadczenia. </p><br clear="all" />

## Ławrow o negocjacjach pokojowych: Nie widzimy żadnych sygnałów
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-lawrow-o-negocjacjach-pokojowych-nie-widzimy-zadnych-sygnalo,nId,7183420](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-lawrow-o-negocjacjach-pokojowych-nie-widzimy-zadnych-sygnalo,nId,7183420)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-01T11:13:46+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-lawrow-o-negocjacjach-pokojowych-nie-widzimy-zadnych-sygnalo,nId,7183420"><img align="left" alt="Ławrow o negocjacjach pokojowych: Nie widzimy żadnych sygnałów" src="https://i.iplsc.com/lawrow-o-negocjacjach-pokojowych-nie-widzimy-zadnych-sygnalo/000I4PZJ68K9K3O8-C321.jpg" /></a>- Nie widzimy żadnych sygnałów o gotowości Ukrainy do przejścia do procesu politycznego - przekazał szef rosyjskiego MSZ, Siergiej Ławrow. Dodał, że nie ma powodu, by Rosja &quot;zmieniała cele specjalnej operacji wojskowej&quot;. Objęty sankcjami dyplomata bierze udział w spotkaniu OBWE w Macedonii Północnej. Jego zaproszenie na szczyt wywołało falę sprzeciwu ze strony zagranicznych przedstawicieli, w tym polskich.</p><br clear="all" />

## Posłanka opublikowała zdjęcie z przesłaniem. "Wylało się szambo"
 - [https://wydarzenia.interia.pl/kraj/news-poslanka-opublikowala-zdjecie-z-przeslaniem-wylalo-sie-szamb,nId,7183370](https://wydarzenia.interia.pl/kraj/news-poslanka-opublikowala-zdjecie-z-przeslaniem-wylalo-sie-szamb,nId,7183370)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-01T11:02:21+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-poslanka-opublikowala-zdjecie-z-przeslaniem-wylalo-sie-szamb,nId,7183370"><img align="left" alt="Posłanka opublikowała zdjęcie z przesłaniem. &quot;Wylało się szambo&quot;" src="https://i.iplsc.com/poslanka-opublikowala-zdjecie-z-przeslaniem-wylalo-sie-szamb/000I4QAN1DT2T1L0-C321.jpg" /></a>- Wylał się na mnie niesamowity hejt - mówi Interii Joanna Wicha, posłanka Razem, pielęgniarka, która wzięła udział w akcji &quot;Stop seksualizacji zawodów medycznych&quot;. - Przyznam, że jeszcze rok temu pewnie siedziałabym i płakała. Tylko jak idzie się do polityki, człowiek musi mieć trochę grubszą skórę - dodaje. W rozmowie z Jakubem Szczepańskim opowiada o swoim wyborczym fenomenie, łączeniu trzech ról i zastanawia się, czy jako posłance wypada jej jeszcze &quot;podrygiwać&quot;?</p><br clear="all" />

## Reporter Interii Dawid Serafin nominowany do nagrody Grand Press
 - [https://wydarzenia.interia.pl/kraj/news-reporter-interii-dawid-serafin-nominowany-do-nagrody-grand-p,nId,7183403](https://wydarzenia.interia.pl/kraj/news-reporter-interii-dawid-serafin-nominowany-do-nagrody-grand-p,nId,7183403)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-01T10:53:50+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-reporter-interii-dawid-serafin-nominowany-do-nagrody-grand-p,nId,7183403"><img align="left" alt="Reporter Interii Dawid Serafin nominowany do nagrody Grand Press" src="https://i.iplsc.com/reporter-interii-dawid-serafin-nominowany-do-nagrody-grand-p/000I4QB6HJC3GYHJ-C321.jpg" /></a>Dawid Serafin z jednym z najważniejszych tekstów roku. Reporter Interii otrzymał nominację do dziennikarskiej nagrody Grand Press za reportaż &quot;Skazany za niewinność&quot; opublikowany na naszych łamach 29 maja.</p><br clear="all" />

## Był poszukiwany listem gończym. Wpadł przez ślady na śniegu
 - [https://wydarzenia.interia.pl/mazowieckie/news-byl-poszukiwany-listem-gonczym-wpadl-przez-slady-na-sniegu,nId,7183346](https://wydarzenia.interia.pl/mazowieckie/news-byl-poszukiwany-listem-gonczym-wpadl-przez-slady-na-sniegu,nId,7183346)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-01T10:43:57+00:00

<p><a href="https://wydarzenia.interia.pl/mazowieckie/news-byl-poszukiwany-listem-gonczym-wpadl-przez-slady-na-sniegu,nId,7183346"><img align="left" alt="Był poszukiwany listem gończym. Wpadł przez ślady na śniegu " src="https://i.iplsc.com/byl-poszukiwany-listem-gonczym-wpadl-przez-slady-na-sniegu/000I4PEZ7SFRLNIL-C321.jpg" /></a>Radomscy policjanci ścigali 31-latka, który uchylał się od płacenia alimentów. W czasie przeszukania okolicy domu należącego do jego krewnych, funkcjonariusze zauważyli uciekającego w las mężczyznę. Jego plan przechytrzenia służb nie powiódł się. Zdradziły go bowiem pozostawione na śniegu ślady. </p><br clear="all" />

## Premier o kredycie 2 procent: Zdecydowaliśmy o zwiększeniu finansowania
 - [https://wydarzenia.interia.pl/kraj/news-premier-o-kredycie-2-procent-zdecydowalismy-o-zwiekszeniu-fi,nId,7183422](https://wydarzenia.interia.pl/kraj/news-premier-o-kredycie-2-procent-zdecydowalismy-o-zwiekszeniu-fi,nId,7183422)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-01T10:27:56+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-premier-o-kredycie-2-procent-zdecydowalismy-o-zwiekszeniu-fi,nId,7183422"><img align="left" alt="Premier o kredycie 2 procent: Zdecydowaliśmy o zwiększeniu finansowania" src="https://i.iplsc.com/premier-o-kredycie-2-procent-zdecydowalismy-o-zwiekszeniu-fi/000I4QBFY017VUOU-C321.jpg" /></a>Zdecydowaliśmy o zwiększeniu finansowania projektu &quot;Bezpieczny kredyt 2 proc.&quot; - ogłosił w piątek Mateusz Morawiecki. - Nas nie interesuje perspektywa banków, tylko ludzi. Z ich perspektywy kredyt powinien być przede wszystkim bezpieczny i tani. Nasza propozycja spełnia te warunki - mówił premier.</p><br clear="all" />

## Atak w szkole w Kadzidle. Nożownik usłyszał zarzut
 - [https://wydarzenia.interia.pl/mazowieckie/news-atak-w-szkole-w-kadzidle-nozownik-uslyszal-zarzut,nId,7183380](https://wydarzenia.interia.pl/mazowieckie/news-atak-w-szkole-w-kadzidle-nozownik-uslyszal-zarzut,nId,7183380)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-01T09:44:09+00:00

<p><a href="https://wydarzenia.interia.pl/mazowieckie/news-atak-w-szkole-w-kadzidle-nozownik-uslyszal-zarzut,nId,7183380"><img align="left" alt="Atak w szkole w Kadzidle. Nożownik usłyszał zarzut" src="https://i.iplsc.com/atak-w-szkole-w-kadzidle-nozownik-uslyszal-zarzut/000I4PTD7HVW0AFC-C321.jpg" /></a>- 18-latek, który zaatakował nożem uczniów w szkole w Kadzidle, usłyszał zarzut usiłowania zabójstwa wielu osób - powiedziała Interii rzeczniczka Prokuratury Okręgowej w Ostrołęce. Jak dodała, nastolatek złożył wyjaśnienia i częściowo przyznał się do winy. - Możemy wykluczyć motyw zawodu miłosnego - zaznaczyła rzeczniczka.</p><br clear="all" />

## PiS zawiadamia CBA i prokuraturę. Chodzi o ustawę wiatrakową
 - [https://wydarzenia.interia.pl/kraj/news-pis-zawiadamia-cba-i-prokurature-chodzi-o-ustawe-wiatrakowa,nId,7183369](https://wydarzenia.interia.pl/kraj/news-pis-zawiadamia-cba-i-prokurature-chodzi-o-ustawe-wiatrakowa,nId,7183369)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-01T09:33:03+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-pis-zawiadamia-cba-i-prokurature-chodzi-o-ustawe-wiatrakowa,nId,7183369"><img align="left" alt="PiS zawiadamia CBA i prokuraturę. Chodzi o ustawę wiatrakową" src="https://i.iplsc.com/pis-zawiadamia-cba-i-prokurature-chodzi-o-ustawe-wiatrakowa/000ATAO16YBPLXUI-C321.jpg" /></a>- Składamy wniosek do prokuratury regionalnej i Centralnego Biura Antykorupcyjnego, żeby te służby sprawdziły, kto stoi za tą ustawą - przekazał poseł PiS, Krzysztof Szczucki. Chodzi o przygotowany przez KO i Polskę 2050 projekt nowelizacji ustawy dot. wsparcia odbiorców energii. W treści znalazły się kontrowersyjne propozycje liberalizacji zasad budowy elektrowni wiatrowych. Politycy PiS zarzucają autorom projektu współpracę z lobbystami.  </p><br clear="all" />

## Spotkanie marszałka Sejmu z Donaldem Tuskiem. Rozmowy o powołaniu rządu
 - [https://wydarzenia.interia.pl/kraj/news-spotkanie-marszalka-sejmu-z-donaldem-tuskiem-rozmowy-o-powol,nId,7183361](https://wydarzenia.interia.pl/kraj/news-spotkanie-marszalka-sejmu-z-donaldem-tuskiem-rozmowy-o-powol,nId,7183361)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-01T09:16:56+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-spotkanie-marszalka-sejmu-z-donaldem-tuskiem-rozmowy-o-powol,nId,7183361"><img align="left" alt="Spotkanie marszałka Sejmu z Donaldem Tuskiem. Rozmowy o powołaniu rządu" src="https://i.iplsc.com/spotkanie-marszalka-sejmu-z-donaldem-tuskiem-rozmowy-o-powol/000I4QC4WS7OQRKL-C321.jpg" /></a>- Spotkaliśmy się po to, aby porozmawiać o realizacji drugiego konstytucyjnego kroku powoływania rządu - powiedział Szymon Hołownia po spotkaniu z liderem KO. - Jeżeli czas pozwoli, to 11 grudnia dokonamy wyboru nowego premiera - dodał Donald Tusk. Politycy po rozmowie wystąpili na wspólnej konferencji prasowej.</p><br clear="all" />

## Idą święta. Ceny biletów PKP poszybowały
 - [https://wydarzenia.interia.pl/raport-transport-publiczny/news-ida-swieta-ceny-biletow-pkp-poszybowaly,nId,7179692](https://wydarzenia.interia.pl/raport-transport-publiczny/news-ida-swieta-ceny-biletow-pkp-poszybowaly,nId,7179692)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-01T09:13:25+00:00

<p><a href="https://wydarzenia.interia.pl/raport-transport-publiczny/news-ida-swieta-ceny-biletow-pkp-poszybowaly,nId,7179692"><img align="left" alt="Idą święta. Ceny biletów PKP poszybowały" src="https://i.iplsc.com/ida-swieta-ceny-biletow-pkp-poszybowaly/000I4M9P92JK7D81-C321.jpg" /></a>Złapałem się za kieszeń, kiedy sprawdziłem ceny biletów na interesujące mnie połączenia w okolicach świąt. Ceny biletów na Pendolino wzrosły do maksymalnych jeszcze w listopadzie. Droższe są też połączenia PKP Intercity niższych kategorii. Mimo to przewoźnik widzi szansę na pozytywne zaskoczenie, a w międzyczasie szykuje się na frekwencyjny rekord. Ma też wskazówkę dla chcących zaoszczędzić.</p><br clear="all" />

## O młodym pośle zrobiło się głośno. Odpowiada na zarzuty
 - [https://wydarzenia.interia.pl/kraj/news-o-mlodym-posle-zrobilo-sie-glosno-odpowiada-na-zarzuty,nId,7183247](https://wydarzenia.interia.pl/kraj/news-o-mlodym-posle-zrobilo-sie-glosno-odpowiada-na-zarzuty,nId,7183247)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-01T07:22:45+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-o-mlodym-posle-zrobilo-sie-glosno-odpowiada-na-zarzuty,nId,7183247"><img align="left" alt="O młodym pośle zrobiło się głośno. Odpowiada na zarzuty" src="https://i.iplsc.com/o-mlodym-posle-zrobilo-sie-glosno-odpowiada-na-zarzuty/000I4NCSRV65A05O-C321.jpg" /></a>- Nie będzie mojej zgody na ataki wymierzone w moich bliskich -  powiedział Interii Adam Gomoła, najmłodszy poseł w Sejmie, o którym zrobiło się głośno za sprawą ostatniego wystąpienia. W sieci zaczęto spekulować, że pierwsze miejsce na opolskiej liście wyborczej Polski 2050 24-latek dostał dzięki wpłatom jego rodziny na partię. - Moją kampanię wsparło finansowo kilkadziesiąt osób, w tym dwoje członków mojej rodziny. Wpłacona przez nich kwota to równowartość 1/3 kosztu jednego z &quot;Pikników 800+&quot;, które to z ominięciem zasad finansowania...</p><br clear="all" />

