# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## "Rozproszona odpowiedzialność" i "kryzys troski"
 - [https://tvn24.pl/polska/smierc-natalii-z-andrychowa-spoleczna-znieczulica-anna-krawczak-z-fundacji-dajemy-dzieciom-sile-mamy-kryzys-troski-i-rozproszenia-odpowiedzialnosci-7465138?source=rss](https://tvn24.pl/polska/smierc-natalii-z-andrychowa-spoleczna-znieczulica-anna-krawczak-z-fundacji-dajemy-dzieciom-sile-mamy-kryzys-troski-i-rozproszenia-odpowiedzialnosci-7465138?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T21:12:48+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9b7lst-anna-krawczak-7465332/alternates/LANDSCAPE_1280" />
    Ekspertka o społecznych reakcjach na dziecko potrzebujące pomocy.

## Zamknięty popularny szlak w Tatrach. Zimuje tam niedźwiedzica
 - [https://tvn24.pl/tvnmeteo/polska/zamkniety-popularny-szlak-w-tatrach-zimuje-tam-niedzwiedzica-st7465330?source=rss](https://tvn24.pl/tvnmeteo/polska/zamkniety-popularny-szlak-w-tatrach-zimuje-tam-niedzwiedzica-st7465330?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T20:57:00+00:00

<img alt="Zamknięty popularny szlak w Tatrach. Zimuje tam niedźwiedzica" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3mq526-morskie-oko-7465329/alternates/LANDSCAPE_1280" />
    Informują służby Tatrzańskiego Parku Narodowego.

## Mężczyzna potrącony przez dwa samochody trafił do szpitala
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-potracenie-w-alejach-jerozolimskich-mezczyzna-trafil-do-szpitala-st7465294?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-potracenie-w-alejach-jerozolimskich-mezczyzna-trafil-do-szpitala-st7465294?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T20:30:37+00:00

<img alt="Mężczyzna potrącony przez dwa samochody trafił do szpitala" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-fmgr0n-potracenie-w-alejach-jerozolimskich-7465296/alternates/LANDSCAPE_1280" />
    Wypadek w Alejach Jerozolimskich.

## Kumulacja w Eurojackpot rośnie
 - [https://tvn24.pl/biznes/z-kraju/eurojackpot-wyniki-z-dnia-11223-liczby-z-ostatniego-losowania-st7465295?source=rss](https://tvn24.pl/biznes/z-kraju/eurojackpot-wyniki-z-dnia-11223-liczby-z-ostatniego-losowania-st7465295?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T20:28:58+00:00

<img alt="Kumulacja w Eurojackpot rośnie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-b7a3hv-eurojackpot-shutterstock1603798027-5772919/alternates/LANDSCAPE_1280" />
    Wyniki losowania.

## Aston Villa składa skargę na Legię
 - [https://eurosport.tvn24.pl/pilka-nozna/liga-konferencji/2023-2024/aston-villa-zlozyla-do-uefa-skarge-na-legie-warszawa-liga-konferencji_sto9903780/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/liga-konferencji/2023-2024/aston-villa-zlozyla-do-uefa-skarge-na-legie-warszawa-liga-konferencji_sto9903780/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T20:25:00+00:00

<img alt="Aston Villa składa skargę na Legię" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pi0gbg-unai-emery-przechytrzyl-koste-runjaicia-7465306/alternates/LANDSCAPE_1280" />
    Władzom stołecznego klubu zarzucono "brak współpracy i kłamstwo".

## Jest jeden cel tej ustawy. A PiS walczy z wiatrakami
 - [https://fakty.tvn24.pl/zobacz-fakty/jest-jeden-cel-tej-ustawy-a-pis-walczy-z-wiatrakami-st7465072?source=rss](https://fakty.tvn24.pl/zobacz-fakty/jest-jeden-cel-tej-ustawy-a-pis-walczy-z-wiatrakami-st7465072?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T20:07:40+00:00

<img alt="Jest jeden cel tej ustawy. A PiS walczy z wiatrakami" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-kdc9sg-pis-walczy-z-wiatrakami-kto-jest-autorem-tego-projektu-ustawy-kto-przygotowal-ktory-lobbysta-7465107/alternates/LANDSCAPE_1280" />
    PiS dopatruje się afery, strasząc, że Polacy będą wywłaszczani, żeby postawić farmy wiatrowe.

## "Zarzucam sobie, że czekaliśmy"
 - [https://fakty.tvn24.pl/zobacz-fakty/kiedy-natalia-umierala-policjanci-przesluchiwali-swiadka-w-innej-sprawie-zarzucam-sobie-ze-czekalismy-st7465053?source=rss](https://fakty.tvn24.pl/zobacz-fakty/kiedy-natalia-umierala-policjanci-przesluchiwali-swiadka-w-innej-sprawie-zarzucam-sobie-ze-czekalismy-st7465053?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T19:53:21+00:00

<img alt="" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-yk80yl-kiedy-natalia-umierala-policjanci-przesluchiwali-swiadka-w-innej-sprawie-zarzucam-sobie-ze-czekalismy-7465113/alternates/LANDSCAPE_1280" />
    Policja i znajomi rodziny przekazują różne informacje co do tego, kiedy informacja o zaginięciu dziecka trafiła do funkcjonariuszy.

## Sprawcy przemocy z zarzutami i nakazami natychmiastowego opuszczenia mieszkań
 - [https://tvn24.pl/tvnwarszawa/okolice/stare-babice-zwolen-by-bliscy-mogli-odpoczac-sprawcy-przemocy-z-zarzutami-i-nakazami-opuszczenia-mieszkan-st7464608?source=rss](https://tvn24.pl/tvnwarszawa/okolice/stare-babice-zwolen-by-bliscy-mogli-odpoczac-sprawcy-przemocy-z-zarzutami-i-nakazami-opuszczenia-mieszkan-st7464608?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T19:53:00+00:00

<img alt="Sprawcy przemocy z zarzutami i nakazami natychmiastowego opuszczenia mieszkań" src="https://tvn24.pl/najnowsze/cdn-zdjecie-tqujkd-warszawa-rusza-z-kampania-przemoc-karmi-sie-milczeniem-zdj-ilustracyjne-7454051/alternates/LANDSCAPE_1280" />
    Wydają je policjanci lub prokurator.

## "To pytanie dla nas wszystkich: dlaczego nie reagujemy?"
 - [https://tvn24.pl/polska/andrychow-smierc-14-letniej-natalii-izabela-jezierska-swiergiel-to-jest-pytanie-dla-nas-wszystkich-dlaczego-nie-reagujemy-7465248?source=rss](https://tvn24.pl/polska/andrychow-smierc-14-letniej-natalii-izabela-jezierska-swiergiel-to-jest-pytanie-dla-nas-wszystkich-dlaczego-nie-reagujemy-7465248?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T19:49:30+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6hukh1-andrychow-7464768/alternates/LANDSCAPE_1280" />
    Goście "Faktów po Faktach" o śmierci 14-letniej Natalii.

## Co dalej z abonamentem RTV? "Nie do uratowania"
 - [https://tvn24.pl/biznes/z-kraju/abonament-rtv-robert-kwiatkowski-jest-nie-do-uratowania-st7465240?source=rss](https://tvn24.pl/biznes/z-kraju/abonament-rtv-robert-kwiatkowski-jest-nie-do-uratowania-st7465240?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T19:45:05+00:00

<img alt="Co dalej z abonamentem RTV? " src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-y3ccdc-telewizja-4190063/alternates/LANDSCAPE_1280" />
    Członek Rady Mediów Narodowych Robert Kwiatkowski w radiowym wywiadzie.

## Szczęście w nieszczęściu Kubackiego
 - [https://eurosport.tvn24.pl/skoki-narciarskie/lillehammer/2023-2024/skoki-narciarskie-lillehammer-2023.-jak-spisal-dawid-kubacki-ile-skoczyl-w-kwalifikacjach-ktore-miej_sto9903392/story.shtml?source=rss](https://eurosport.tvn24.pl/skoki-narciarskie/lillehammer/2023-2024/skoki-narciarskie-lillehammer-2023.-jak-spisal-dawid-kubacki-ile-skoczyl-w-kwalifikacjach-ktore-miej_sto9903392/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T19:29:00+00:00

<img alt="Szczęście w nieszczęściu Kubackiego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fc38hb-skok-kubackiego-z-piatkowych-kwalifikacji-w-lillehammer-7465249/alternates/LANDSCAPE_1280" />
    Sześć punktów mniej i sobotni konkurs obejrzałby w telewizji.

## "Ten gość okradał swoją kampanię". Stracił mandat
 - [https://tvn24.pl/swiat/usa-republikanin-george-santos-usuniety-z-izby-reprezentantow-kontrowersje-wokol-polityka-7465101?source=rss](https://tvn24.pl/swiat/usa-republikanin-george-santos-usuniety-z-izby-reprezentantow-kontrowersje-wokol-polityka-7465101?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T19:26:07+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-n4acdq-george-santos-opuszcza-kapitol-7465089/alternates/LANDSCAPE_1280" />
    O jego usunięcie wnioskowali nowojorscy republikanie.

## Trzy priorytetowe stopnie poszukiwań, a zaginięcie Natalii z inną kategorią
 - [https://tvn24.pl/polska/andrychow-smierc-14-letniej-natalii-trzy-priorytetowe-stopnie-poszukiwan-sprawa-nastolatki-potraktowana-jako-zaginiecie-opiekuncze-7465052?source=rss](https://tvn24.pl/polska/andrychow-smierc-14-letniej-natalii-trzy-priorytetowe-stopnie-poszukiwan-sprawa-nastolatki-potraktowana-jako-zaginiecie-opiekuncze-7465052?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T19:22:38+00:00

<img alt="Trzy priorytetowe stopnie poszukiwań, a zaginięcie Natalii z inną kategorią " src="https://tvn24.pl/najnowsze/cdn-zdjecie-3vmjjy-andrychow-7465179/alternates/LANDSCAPE_1280" />
    Ustalenia tvn24.pl w sprawie działań policji.

## "Król Zakopanego", czyli jeden z najbogatszych posłów
 - [https://tvn24.pl/biznes/z-kraju/andrzej-gut-mostowy-oswiadczenie-majatkowe-posla-pis-za-2022-rok-st7465083?source=rss](https://tvn24.pl/biznes/z-kraju/andrzej-gut-mostowy-oswiadczenie-majatkowe-posla-pis-za-2022-rok-st7465083?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T19:11:26+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-r9lgff-pap_20230806_0oe-7465146/alternates/LANDSCAPE_1280" />
    To Andrzej Gut-Mostowy.

## Szeroka kadra Polaków na mistrzostwa Europy
 - [https://eurosport.tvn24.pl/pilka-reczna/mistrzostwa-europy/2024/mistrzostwa-europy-2024.-szeroka-kadra-reprezentacji-polski-pilka-reczna_sto9903619/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-reczna/mistrzostwa-europy/2024/mistrzostwa-europy-2024.-szeroka-kadra-reprezentacji-polski-pilka-reczna_sto9903619/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T19:02:45+00:00

<img alt="Szeroka kadra Polaków na mistrzostwa Europy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ngdson-marcin-lijewski-powolal-szeroka-kadre-na-euro-2024-7465221/alternates/LANDSCAPE_1280" />
    Kilku debiutantów, większość sprawdzonych zawodników. Łącznie aż 35 piłkarzy ręcznych liczy szeroka kadra reprezentacji Polski na mistrzostwa Europy. Tak zdecydował w piątek selekcjoner Marcin Lijewski.

## Nad Polską zimno zderza się z ciepłem. Będzie padać intensywnie
 - [https://tvn24.pl/tvnmeteo/najnowsze/pogoda-na-jutro-sobota-0212-obfite-opady-sniegu-w-duzej-czesci-kraju-st7465139?source=rss](https://tvn24.pl/tvnmeteo/najnowsze/pogoda-na-jutro-sobota-0212-obfite-opady-sniegu-w-duzej-czesci-kraju-st7465139?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T18:39:34+00:00

<img alt="Nad Polską zimno zderza się z ciepłem. Będzie padać intensywnie" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-9vj8fl-intensywne-opady-sniegu-7465187/alternates/LANDSCAPE_1280" />
    Prognoza pogody na noc i na sobotę.

## Prezes i członek zarządu spółki nie mieli odpowiednich zezwoleń na pracę
 - [https://tvn24.pl/kujawsko-pomorskie/bydgoszcz-prezes-i-czlonek-zarzadu-spolki-nie-mieli-odpowiednich-zezwolen-na-prace-7465190?source=rss](https://tvn24.pl/kujawsko-pomorskie/bydgoszcz-prezes-i-czlonek-zarzadu-spolki-nie-mieli-odpowiednich-zezwolen-na-prace-7465190?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T18:38:57+00:00

<img alt="Prezes i członek zarządu spółki nie mieli odpowiednich zezwoleń na pracę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-nf3nh5-budowa-shutterstock_151222856-7368249/alternates/LANDSCAPE_1280" />
    Azer i Uzbek muszą opuścić Polskę i nie będą mogli wrócić przez rok.

## To ma być przyszły minister finansów. Pokazał majątek, w tym akcje żony
 - [https://tvn24.pl/biznes/z-kraju/andrzej-domanski-oswiadczenie-majatkowe-to-ma-byc-przyszly-minister-finansow-st7465069?source=rss](https://tvn24.pl/biznes/z-kraju/andrzej-domanski-oswiadczenie-majatkowe-to-ma-byc-przyszly-minister-finansow-st7465069?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T18:16:16+00:00

<img alt="To ma być przyszły minister finansów. Pokazał majątek, w tym akcje żony" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4wqfe8-pap_20231103_05t-7465081/alternates/LANDSCAPE_1280" />
    Na stronie Sejmu pojawiło się oświadczenie majątkowe posła Koalicji Obywatelskiej (KO) Andrzeja Domańskiego.

## "Decyzja rażąco naruszyła ustalenia". Zanim doszło do gorszących scen z kibicami Legii
 - [https://eurosport.tvn24.pl/pilka-nozna/liga-konferencji/2023-2024/mecz-aston-villa-legia-w-lidze-konferencji-bez-kibicow-z-warszawy.-jak-do-tego-doszlo-chronologia-zd_sto9902972/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/liga-konferencji/2023-2024/mecz-aston-villa-legia-w-lidze-konferencji-bez-kibicow-z-warszawy.-jak-do-tego-doszlo-chronologia-zd_sto9902972/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T18:00:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ewfong-zamieszki-przed-meczem-w-birmingham-7465103/alternates/LANDSCAPE_1280" />
    W tle awantura o bilety.

## Król bitcoinów w Sejmie. Oto majątek Sławomira Mentzena
 - [https://tvn24.pl/biznes/z-kraju/slawomir-mentzen-jest-oswiadczenie-majatkowe-bitcoiny-domy-kredyty-st7465086?source=rss](https://tvn24.pl/biznes/z-kraju/slawomir-mentzen-jest-oswiadczenie-majatkowe-bitcoiny-domy-kredyty-st7465086?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T17:49:57+00:00

<img alt="Król bitcoinów w Sejmie. Oto majątek Sławomira Mentzena" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7py452-slawomir-mentzen-w-sejmie-7441047/alternates/LANDSCAPE_1280" />
    Oświadczenie majątkowe posła zostało opublikowane na stronie Sejmu.

## Zderzenie pięciu samochodów. Dwa leżą w rowie
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-zderzenie-pieciu-samochodow-na-wirazowej-dwa-leza-w-rowie-sa-ranni-st7465047?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-zderzenie-pieciu-samochodow-na-wirazowej-dwa-leza-w-rowie-sa-ranni-st7465047?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T17:34:51+00:00

<img alt="Zderzenie pięciu samochodów. Dwa leżą w rowie" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-tqsr6t-zderzenie-na-ulicy-wirazowej-7465065/alternates/LANDSCAPE_1280" />
    Na ulicy Wirażowej.

## "Pamiętajmy, jeden telefon może uratować czyjeś życie"
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-wychlodzenie-organizmu-moze-byc-grozne-policjanci-zwracaja-sie-z-apelem-st7464984?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-wychlodzenie-organizmu-moze-byc-grozne-policjanci-zwracaja-sie-z-apelem-st7464984?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T17:28:00+00:00

<img alt="" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-4nnw18-policjanci-zwracaja-sie-z-apelem-7464996/alternates/LANDSCAPE_1280" />
    Wychłodzenie może doprowadzić do utraty życia lub zdrowia.

## Coś drgnęło. Pewny awans Stocha
 - [https://eurosport.tvn24.pl/skoki-narciarskie/lillehammer/2023-2024/skoki-narciarskie-lillehammer-2023.-jak-spisal-sie-kamil-stoch-w-kwalifikacjach.-ile-skoczyl-puchar-_sto9903370/story.shtml?source=rss](https://eurosport.tvn24.pl/skoki-narciarskie/lillehammer/2023-2024/skoki-narciarskie-lillehammer-2023.-jak-spisal-sie-kamil-stoch-w-kwalifikacjach.-ile-skoczyl-puchar-_sto9903370/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T17:25:00+00:00

<img alt="Coś drgnęło. Pewny awans Stocha" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jtyah3-skok-stocha-z-piatkowych-kwalifikacji-w-lillehammer-7465067/alternates/LANDSCAPE_1280" />
    Ma w końcu jakieś powody do zadowolenia.

## Polacy z postępami w Lillehammer. Komplet w konkursie
 - [https://eurosport.tvn24.pl/skoki-narciarskie/lillehammer/2023-2024/skoki-narciarskie-lillehammer-2023-wyniki-piatkowych-kwalifikacji-i-relacja-ps-w-skokach-narciarskic_sto9903391/story.shtml?source=rss](https://eurosport.tvn24.pl/skoki-narciarskie/lillehammer/2023-2024/skoki-narciarskie-lillehammer-2023-wyniki-piatkowych-kwalifikacji-i-relacja-ps-w-skokach-narciarskic_sto9903391/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T17:10:26+00:00

<img alt="Polacy z postępami w Lillehammer. Komplet w konkursie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-tcrohw-piotr-zyla-7465048/alternates/LANDSCAPE_1280" />
    Piotr Żyła najlepszy z Biało-Czerwonych.

## Przebił barierki na parkingu i spadł na drogę zjazdową
 - [https://tvn24.pl/katowice/sosnowiec-przebil-barierki-na-parkingu-i-spadl-na-droge-zjazdowa-7464956?source=rss](https://tvn24.pl/katowice/sosnowiec-przebil-barierki-na-parkingu-i-spadl-na-droge-zjazdowa-7464956?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T17:04:44+00:00

<img alt="Przebił barierki na parkingu i spadł na drogę zjazdową" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hky8jy-samochodzik-2-7465050/alternates/LANDSCAPE_1280" />
    W Sosnowcu.

## Muzyk The Beatles żartował nawet po tym, jak napastnik dźgnął go 40 razy
 - [https://tvn24.pl/kultura-i-styl/the-beatles-george-harrison-otarl-sie-o-smierc-biografia-o-tym-jak-skomentowal-atak-7464992?source=rss](https://tvn24.pl/kultura-i-styl/the-beatles-george-harrison-otarl-sie-o-smierc-biografia-o-tym-jak-skomentowal-atak-7464992?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T16:51:49+00:00

<img alt="Muzyk The Beatles żartował nawet po tym, jak napastnik dźgnął go 40 razy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-saqs39-george-harrison-7465009/alternates/LANDSCAPE_1280" />
    Ujawnia nowa biografia.

## Jaka pogoda w grudniu? Czy święta będą białe? Sprawdza nasza synoptyk
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-grudzien-2023-jakie-beda-swieta-bozego-narodzenia-czy-bedzie-snieg-st7464628?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-grudzien-2023-jakie-beda-swieta-bozego-narodzenia-czy-bedzie-snieg-st7464628?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T16:50:42+00:00

<img alt="Jaka pogoda w grudniu? Czy święta będą białe? Sprawdza nasza synoptyk" src="https://tvn24.pl/najnowsze/cdn-zdjecie-gpvbms-meteo-sklej-16-7464976/alternates/LANDSCAPE_1280" />
    Blog Arlety Unton-Pyziołek.

## Jest oświadczenie majątkowe Donalda Tuska
 - [https://tvn24.pl/biznes/z-kraju/jest-oswiadczenie-majatkowe-donalda-tuska-st7464999?source=rss](https://tvn24.pl/biznes/z-kraju/jest-oswiadczenie-majatkowe-donalda-tuska-st7464999?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T16:48:55+00:00

<img alt="Jest oświadczenie majątkowe Donalda Tuska" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xg9cdj-donald-tusk-w-sejmie-7448369/alternates/LANDSCAPE_1280" />
    W związku z początkiem kadencji Sejmu.

## Było czterech skazanych, po apelacji został jeden. Ten, który "oddał w głowę ofiary dwa strzały"
 - [https://tvn24.pl/tvnwarszawa/okolice/bylo-czterech-skazanych-po-apelacji-zostal-jeden-ten-ktory-oddal-w-glowe-ofiary-dwa-strzaly-z-pistoletu-st7464989?source=rss](https://tvn24.pl/tvnwarszawa/okolice/bylo-czterech-skazanych-po-apelacji-zostal-jeden-ten-ktory-oddal-w-glowe-ofiary-dwa-strzaly-z-pistoletu-st7464989?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T16:24:30+00:00

<img alt="Było czterech skazanych, po apelacji został jeden. Ten, który " src="https://tvn24.pl/najnowsze/cdn-zdjecie-tj1380-sala-sadowa-5021554/alternates/LANDSCAPE_1280" />
    Trzech uniewinnionych, jeden skazany na 15 lat więzienia - to już prawomocny wyrok.

## Zablokował wyjazd strażakom. "Kogoś poniosła fantazja"
 - [https://tvn24.pl/tvnwarszawa/okolice/ozarow-mazowiecki-zablokowal-wyjazd-strazakom-kierowca-ukarany-mandatem-st7464933?source=rss](https://tvn24.pl/tvnwarszawa/okolice/ozarow-mazowiecki-zablokowal-wyjazd-strazakom-kierowca-ukarany-mandatem-st7464933?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T15:44:42+00:00

<img alt="Zablokował wyjazd strażakom. " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-gfsskx-samochod-zastawil-wyjazd-strazakom-7464949/alternates/LANDSCAPE_1280" />
    Kierowcę ukarano mandatem.

## "Bajkowe miasto" z Polski na liście "najlepszych miejsc do spędzenia świąt"
 - [https://tvn24.pl/ciekawostki/boze-narodzenie-lista-najlepszych-miast-na-swieta-na-swiecie-na-liscie-jest-gdansk-7464930?source=rss](https://tvn24.pl/ciekawostki/boze-narodzenie-lista-najlepszych-miast-na-swieta-na-swiecie-na-liscie-jest-gdansk-7464930?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T15:36:28+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-r5y4gl-starowka-w-gdansku-5515577/alternates/LANDSCAPE_1280" />
    Na liście są też Berlin, Paryż i Hongkong.

## Rok więzienia za działalność szpiegowską na rzecz Rosji
 - [https://tvn24.pl/trojmiasto/gdansk-rok-wiezienia-dla-44-latka-za-dzialalnosc-szpiegowska-na-rzecz-rosji-7464409?source=rss](https://tvn24.pl/trojmiasto/gdansk-rok-wiezienia-dla-44-latka-za-dzialalnosc-szpiegowska-na-rzecz-rosji-7464409?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T15:24:39+00:00

<img alt="Rok więzienia za działalność szpiegowską na rzecz Rosji" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pk8mdd-sad-skazal-mezczyzne-na-rok-wiezienia-7464407/alternates/LANDSCAPE_1280" />
    Dla obywatela Ukrainy.

## "Mamy nowy etap wojny i to jest fakt"
 - [https://tvn24.pl/swiat/atak-rosji-na-ukraine-wolodymyr-zelenski-armia-ukrainska-nie-osiagnela-rezultatow-ktorych-bym-sobie-zyczyl-7464878?source=rss](https://tvn24.pl/swiat/atak-rosji-na-ukraine-wolodymyr-zelenski-armia-ukrainska-nie-osiagnela-rezultatow-ktorych-bym-sobie-zyczyl-7464878?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T15:18:31+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-626l7t-ukrainscy-zolnierze-demonstruja-dzialo-przeciwlotnicze-zu-23-2-pod-kijowem-zdjecie-z-30-listopada-7464910/alternates/LANDSCAPE_1280" />
    Prezydent Ukrainy w wywiadzie dla Associated Press.

## Zaśpiewał z zespołem Chłopcy z Placu Broni. Pożegnano Jarosława Mikulskiego, miał 52 lata
 - [https://tvn24.pl/katowice/gliwice-zaspiewal-z-zespolem-chlopcy-z-placu-broni-pozegnano-jaroslawa-mikulskiego-mial-52-lata-7464686?source=rss](https://tvn24.pl/katowice/gliwice-zaspiewal-z-zespolem-chlopcy-z-placu-broni-pozegnano-jaroslawa-mikulskiego-mial-52-lata-7464686?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T15:06:16+00:00

<img alt="Zaśpiewał z zespołem Chłopcy z Placu Broni. Pożegnano Jarosława Mikulskiego, miał 52 lata" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lglj77-jarek-mikulski-2005-7464641/alternates/LANDSCAPE_1280" />
    "Bardzo fajny gość z którym spędziliśmy dobre dni" - wspomnieli muzycy zespołu.

## Nowy rekord upadłości. "Najmłodsza osoba ma 13 lat, a najstarsza 93"
 - [https://tvn24.pl/biznes/z-kraju/upadlosci-konsumenckie-pazdziernik-2023-nowy-rekord-st7464859?source=rss](https://tvn24.pl/biznes/z-kraju/upadlosci-konsumenckie-pazdziernik-2023-nowy-rekord-st7464859?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T15:05:51+00:00

<img alt="Nowy rekord upadłości. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-w8jmce-ludzie-ulica-7439574/alternates/LANDSCAPE_1280" />
    Dane zebrane przez Centralny Ośrodek Informacji Gospodarczej.

## 12-letnia Anastazja po operacji. Zaatakował ją 16-latek, gdy szła do sklepu
 - [https://tvn24.pl/krakow/rzeszow-12-letnia-anastazja-po-operacji-pocial-ja-16-latek-gdy-szla-do-osiedlowego-sklepu-7464876?source=rss](https://tvn24.pl/krakow/rzeszow-12-letnia-anastazja-po-operacji-pocial-ja-16-latek-gdy-szla-do-osiedlowego-sklepu-7464876?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T15:04:38+00:00

<img alt="12-letnia Anastazja po operacji. Zaatakował ją 16-latek, gdy szła do sklepu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-x4kjax-dziewczynka-przebywa-w-klinicznym-szpitalu-wojewodzkim-w-rzeszowie-7406606/alternates/LANDSCAPE_1280" />
    W szpitalu właśnie zszyto jej powiekę. Wcześniej przeszła inne operacje.

## Mieli pokłócić się o pieniądze i kota. Policja znalazła 84-latka "z krwią na rękach, twarzy i ubraniu"
 - [https://tvn24.pl/swiat/usa-zabojstwo-kobiety-w-pensylwanii-mieli-poklocic-sie-o-pieniadze-i-kota-7463081?source=rss](https://tvn24.pl/swiat/usa-zabojstwo-kobiety-w-pensylwanii-mieli-poklocic-sie-o-pieniadze-i-kota-7463081?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T14:47:46+00:00

<img alt="Mieli pokłócić się o pieniądze i kota. Policja znalazła 84-latka " src="https://tvn24.pl/najnowsze/cdn-zdjecie-mqjlok-barton-seltmann-7464845/alternates/LANDSCAPE_1280" />
    Są wyniki sekcji zwłok.

## "Drogi mogą być nieprzejezdne. Śledź komunikaty pogodowe"
 - [https://tvn24.pl/tvnmeteo/pogoda/alert-rcb-dla-wojewodztw-malopolskiego-i-podkarpackiego-sniezyce-i-nieprzejezdne-drogi-st7464853?source=rss](https://tvn24.pl/tvnmeteo/pogoda/alert-rcb-dla-wojewodztw-malopolskiego-i-podkarpackiego-sniezyce-i-nieprzejezdne-drogi-st7464853?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T14:41:31+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-r9p5wq-rcm-meteo-7464860/alternates/LANDSCAPE_1280" />
    Intensywne opady śniegu na znacznym obszarze dwóch województw.

## Jak namierzyć telefon dziecka?
 - [https://tvn24.pl/polska/smierc-natalii-z-andrychowa-jak-lokalizowac-telefon-dziecka-usluga-family-link-7464700?source=rss](https://tvn24.pl/polska/smierc-natalii-z-andrychowa-jak-lokalizowac-telefon-dziecka-usluga-family-link-7464700?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T14:25:15+00:00

<img alt="Jak namierzyć telefon dziecka? " src="https://tvn24.pl/najnowsze/cdn-zdjecie-1nxeio-smartfon-snieg-zima-mroz-shutterstock_2252725251_1_1-7464848/alternates/LANDSCAPE_1280" />
    "Ustawienie trwa chwilę".

## Zatrzymali kierowcę i wezwali jego matkę
 - [https://tvn24.pl/tvnwarszawa/ulice/zatrzymali-kierowce-i-wezwali-jego-matke-st7464868?source=rss](https://tvn24.pl/tvnwarszawa/ulice/zatrzymali-kierowce-i-wezwali-jego-matke-st7464868?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T14:23:59+00:00

<img alt="Zatrzymali kierowcę i wezwali jego matkę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-biwlb5-samochod-auto-droga-kierowca-kierownica-4563817/alternates/LANDSCAPE_1280" />
    Chłopak ma dopiero 15 lat.

## Doskonałe wyniki TVN24, "Faktów" TVN i tvn24.pl. Dziękujemy widzom i czytelnikom!
 - [https://tvn24.pl/biznes/z-kraju/tvn24-fakty-tvn-tvn24pl-wyniki-ogladalnosci-w-listopadzie-2023-st7464708?source=rss](https://tvn24.pl/biznes/z-kraju/tvn24-fakty-tvn-tvn24pl-wyniki-ogladalnosci-w-listopadzie-2023-st7464708?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T14:23:14+00:00

<img alt="Doskonałe wyniki TVN24, " src="https://tvn24.pl/najnowsze/cdn-zdjecie-lqtuje-tvn-5510678/alternates/LANDSCAPE_1280" />
    Dane za listopad.

## III edycja Kongresu ESG Polska Moc Biznesu już w grudniu
 - [https://tvn24.pl/biznes/dlafirm/iii-edycja-kongresu-esg-polska-moc-biznesu-juz-w-grudniu-st7464827?source=rss](https://tvn24.pl/biznes/dlafirm/iii-edycja-kongresu-esg-polska-moc-biznesu-juz-w-grudniu-st7464827?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T14:10:27+00:00

<img alt="III edycja Kongresu ESG Polska Moc Biznesu już w grudniu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6z7s1b-1-1-7464895/alternates/LANDSCAPE_1280" />
    Odbędzie się 4 grudnia 2023 na PGE Narodowym w Warszawie.

## Sprawdzono rzeczywistą skuteczność leków chroniących przed HIV
 - [https://tvn24.pl/ciekawostki/nauka-leki-chroniace-przed-hiv-rzeczywista-skutecznosc-86-proc-badanie-7464634?source=rss](https://tvn24.pl/ciekawostki/nauka-leki-chroniace-przed-hiv-rzeczywista-skutecznosc-86-proc-badanie-7464634?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T14:10:08+00:00

<img alt="Sprawdzono rzeczywistą skuteczność leków chroniących przed HIV" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7xz4p0-wirus-hiv-5601091/alternates/LANDSCAPE_1280" />
    Pierwsze takie badanie.

## Łódzkie liceum przeszło na zdalne nauczanie
 - [https://tvn24.pl/lodz/lodz-covid-19-grypa-i-inne-wirusy-sezon-na-zachorowania-w-pelni-7464531?source=rss](https://tvn24.pl/lodz/lodz-covid-19-grypa-i-inne-wirusy-sezon-na-zachorowania-w-pelni-7464531?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T14:06:11+00:00

<img alt="Łódzkie liceum przeszło na zdalne nauczanie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mu5tkj-duza-liczba-zachorowan-7464527/alternates/LANDSCAPE_1280" />
    Blisko połowa nauczycieli jest na zwolnieniu. Fala zachorowań na COVID-19 i grypę

## "Społeczność międzynarodowa powinna stać z tym problemem twarzą w twarz"
 - [https://tvn24.pl/tvnmeteo/swiat/cop28-prezydent-andrzej-duda-duda-wyglosil-oswiadczenie-narodowe-st7464698?source=rss](https://tvn24.pl/tvnmeteo/swiat/cop28-prezydent-andrzej-duda-duda-wyglosil-oswiadczenie-narodowe-st7464698?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T13:51:42+00:00

<img alt="" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-r6nuic-andrzej-duda-na-konferencji-klimatycznej-cop28-7464782/alternates/LANDSCAPE_1280" />
    Prezydent Andrzej Duda bierze udział w konferencji klimatycznej COP28 w Dubaju.

## Śmierć Natalii. Rodzina i znajomi ojca dziewczynki rekonstruują przebieg wydarzeń
 - [https://tvn24.pl/krakow/andrychow-wadowice-krakow-smierc-natalii-w-andrychowie-w-policji-rusza-wewnetrzna-kontrola-7463924?source=rss](https://tvn24.pl/krakow/andrychow-wadowice-krakow-smierc-natalii-w-andrychowie-w-policji-rusza-wewnetrzna-kontrola-7463924?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T13:50:13+00:00

<img alt="Śmierć Natalii. Rodzina i znajomi ojca dziewczynki rekonstruują przebieg wydarzeń " src="https://tvn24.pl/najnowsze/cdn-zdjecie-k1fb4n-andrychow-kartka-sklej-drv-7464802/alternates/LANDSCAPE_1280" />
    Zaginioną 14-latkę znalazł na mrozie na parkingu pod sklepem przyjaciel rodziny.

## "Osobiście dopilnujemy, żeby żadne zdanie w tym projekcie nie budziło najmniejszych wątpliwości czy emocji"
 - [https://tvn24.pl/biznes/z-kraju/ustawa-wiatrakowa-donald-tusk-i-szymon-holownia-zabieraja-glos-w-sprawie-projektu-st7464689?source=rss](https://tvn24.pl/biznes/z-kraju/ustawa-wiatrakowa-donald-tusk-i-szymon-holownia-zabieraja-glos-w-sprawie-projektu-st7464689?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T13:27:08+00:00

<img alt="" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecied41d8cd98f00b204e9800998ecf8427e-co-z-ustawa-wiatrakowa-poslowie-nie-moga-sie-dogadac-co-do-odleglosci-od-zabudowan-5376365/alternates/LANDSCAPE_1280" />
    Donald Tusk i Szymon Hołownia o projekcie w sprawie cen prądu i farm wiatrowych.

## Uderzył w znaki drogowe, "szyby w aucie nie były odmrożone"
 - [https://tvn24.pl/tvnwarszawa/ulice/ciechanow-uderzyl-w-znaki-drogowe-szyby-auta-nie-byly-odmrozone-st7464673?source=rss](https://tvn24.pl/tvnwarszawa/ulice/ciechanow-uderzyl-w-znaki-drogowe-szyby-auta-nie-byly-odmrozone-st7464673?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T13:25:00+00:00

<img alt="Uderzył w znaki drogowe, " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-b72wnl-uderzyl-w-znaki-drogowe-7464658/alternates/LANDSCAPE_1280" />
    Grozi za to bardzo wysoki mandat.

## Żądają od Cristiano Ronaldo ponad miliard dolarów
 - [https://tvn24.pl/swiat/usa-cristiano-ronaldo-pozwany-o-miliard-dolarow-za-promocje-binance-gieldy-kryptowalut-7464459?source=rss](https://tvn24.pl/swiat/usa-cristiano-ronaldo-pozwany-o-miliard-dolarow-za-promocje-binance-gieldy-kryptowalut-7464459?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T13:19:12+00:00

<img alt="Żądają od Cristiano Ronaldo ponad miliard dolarów " src="https://tvn24.pl/najnowsze/cdn-zdjecie-e4p76i-cristiano-ronaldo/alternates/LANDSCAPE_1280" />
    Pozew zbiorowy został złożony na Florydzie.

## Prezydent zabrał głos w sprawie powołania rządu Tuska
 - [https://tvn24.pl/polska/rzad-donalda-tuska-kiedy-prezydent-andrzej-duda-nie-bede-przeciagal-i-nie-bede-opoznial-7464713?source=rss](https://tvn24.pl/polska/rzad-donalda-tuska-kiedy-prezydent-andrzej-duda-nie-bede-przeciagal-i-nie-bede-opoznial-7464713?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T13:16:32+00:00

<img alt="Prezydent zabrał głos w sprawie powołania rządu Tuska" src="https://tvn24.pl/najnowsze/cdn-zdjecie-k17j4i-andrzej-duda-7464749/alternates/LANDSCAPE_1280" />
    "Będę to robił spokojnie, zgodnie ze zwyczajem u nas obowiązującym".

## Udawał, że zasypia w pociągu, po czym atakował kobiety. Wpadł przez SMS-a
 - [https://tvn24.pl/swiat/wielka-brytania-wyrok-za-napasci-seksualne-w-pociagach-udawal-ze-zasypia-po-czym-atakowal-kobiety-7464420?source=rss](https://tvn24.pl/swiat/wielka-brytania-wyrok-za-napasci-seksualne-w-pociagach-udawal-ze-zasypia-po-czym-atakowal-kobiety-7464420?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T13:09:00+00:00

46-latek usłyszał wyrok.

## Były prezydent zatrzymany na granicy. "Teatr absurdu"
 - [https://tvn24.pl/swiat/ukraina-petro-poroszenko-nie-przepuszczony-na-granicy-7464455?source=rss](https://tvn24.pl/swiat/ukraina-petro-poroszenko-nie-przepuszczony-na-granicy-7464455?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T12:26:31+00:00

<img alt="Były prezydent zatrzymany na granicy. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-qbiuah-petro-poroszenko-nie-zostal-przepuszczony-przez-straz-graniczna-7464546/alternates/LANDSCAPE_1280" />
    Petro Poroszenko nie mógł wyjechać z Ukrainy.

## "Wybory kobiet". Seksizm w Sejmie, "jak w każdym innym zakładzie pracy". Jak z nim walczyć
 - [https://tvn24.pl/polska/wybory-kobiet-klaudia-jachira-to-jest-rzecz-o-ktora-jeszcze-jako-kobiety-musimy-walczyc-7463824?source=rss](https://tvn24.pl/polska/wybory-kobiet-klaudia-jachira-to-jest-rzecz-o-ktora-jeszcze-jako-kobiety-musimy-walczyc-7463824?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T12:21:04+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-39jx9h-klaudia-jachira-w-wyborach-kobiet-7464495/alternates/LANDSCAPE_1280" />
    Klaudia Jachira, posłanka Koalicji Obywatelskiej w podcaście "Wybory kobiet".

## Śmierć 14-letniej Natalii. Znamy wstępne wyniki sekcji zwłok
 - [https://tvn24.pl/krakow/andrychow-krakow-smierc-14-letniej-natalii-znamy-wstepne-wyniki-sekcji-zwlok-7464573?source=rss](https://tvn24.pl/krakow/andrychow-krakow-smierc-14-letniej-natalii-znamy-wstepne-wyniki-sekcji-zwlok-7464573?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T12:12:51+00:00

<img alt="Śmierć 14-letniej Natalii. Znamy wstępne wyniki sekcji zwłok" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8824hx-sprawa-smierci-nastolatki-z-andrychowa-7463290/alternates/LANDSCAPE_1280" />
    Prokuratura podała wstępne informacje na temat śmierci 14-latki.

## 10-letni chłopiec zaalarmował policjantów o leżącym na ulicy mężczyźnie
 - [https://tvn24.pl/olsztyn/olsztyn-10-letni-chlopiec-zaalarmowal-policjantow-o-lezacym-na-ulicy-mezczyznie-7464327?source=rss](https://tvn24.pl/olsztyn/olsztyn-10-letni-chlopiec-zaalarmowal-policjantow-o-lezacym-na-ulicy-mezczyznie-7464327?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T11:55:50+00:00

<img alt="10-letni chłopiec zaalarmował policjantów o leżącym na ulicy mężczyźnie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8yt2gz-mezczyzna-zostal-przewieziony-do-szpitala-7464337/alternates/LANDSCAPE_1280" />
    Człowiek przewrócił się i nie mógł samodzielnie wstać.

## Nowa broń na nieuczciwych skoczków. Reporter Eurosportu sprawdził na własnej skórze
 - [https://eurosport.tvn24.pl/skoki-narciarskie/lillehammer/2023-2024/skanery-3d-w-skokach-narciarskich.-o-co-chodzi-jak-sie-ich-uzywa-wyjasniamy-puchar-swiata_sto9902229/story.shtml?source=rss](https://eurosport.tvn24.pl/skoki-narciarskie/lillehammer/2023-2024/skanery-3d-w-skokach-narciarskich.-o-co-chodzi-jak-sie-ich-uzywa-wyjasniamy-puchar-swiata_sto9902229/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T11:52:45+00:00

<img alt="Nowa broń na nieuczciwych skoczków. Reporter Eurosportu sprawdził na własnej skórze" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lcuyk9-rewolucja-w-skokach-7464538/alternates/LANDSCAPE_1280" />
    Ten sezon Pucharu Świata w skokach narciarskich ma być inny. Kacper Merk sprawdził, jak prześwietla się zawodnika.

## Media: Daniel Obajtek pozbywa się nieruchomości. Przekazuje je synowi
 - [https://tvn24.pl/biznes/najnowsze/daniel-obajtek-prezes-orlenu-przepisuje-majatek-na-syna-ustalenia-wirtualnej-polski-st7463879?source=rss](https://tvn24.pl/biznes/najnowsze/daniel-obajtek-prezes-orlenu-przepisuje-majatek-na-syna-ustalenia-wirtualnej-polski-st7463879?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T11:52:15+00:00

<img alt="Media: Daniel Obajtek pozbywa się nieruchomości. Przekazuje je synowi" src="https://tvn24.pl/najnowsze/cdn-zdjecie-q7u8k2-daniel-obajtek-7396790/alternates/LANDSCAPE_1280" />
    Wpisy w księgach wieczystych po wyborach.

## Kupiła nowy płaszcz. W podszewce legitymacja chińskiego więźnia
 - [https://tvn24.pl/swiat/wielka-brytania-kobieta-znalazla-legitymacje-chinskiego-wieznia-w-nowym-plaszczu-7464321?source=rss](https://tvn24.pl/swiat/wielka-brytania-kobieta-znalazla-legitymacje-chinskiego-wieznia-w-nowym-plaszczu-7464321?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T11:50:26+00:00

<img alt="Kupiła nowy płaszcz. W podszewce legitymacja chińskiego więźnia" src="https://tvn24.pl/najnowsze/cdn-zdjecie-u7plj5-shutterstock_1463791133-7464528/alternates/LANDSCAPE_1280" />
    "Jeśli więzień umieścił to w płaszczu, nad którym pracował, celem jest poinformowanie ludzi".

## Egzekucja 59-latka wykonana, mimo pozytywnej opinii w sprawie ułaskawienia
 - [https://tvn24.pl/swiat/kara-smierci-w-usa-oklahoma-stracono-59-latka-pomimo-rekomendacji-ulaskawienia-7464400?source=rss](https://tvn24.pl/swiat/kara-smierci-w-usa-oklahoma-stracono-59-latka-pomimo-rekomendacji-ulaskawienia-7464400?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T11:40:57+00:00

<img alt="Egzekucja 59-latka wykonana, mimo pozytywnej opinii w sprawie ułaskawienia" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8namds-kara-smierci-egzekucja-6226006/alternates/LANDSCAPE_1280" />
    Do końca twierdził, że działał w obronie własnej.

## Śmigłowiec spadł na samochód. Trzy osoby ranne
 - [https://tvn24.pl/swiat/hiszpania-madryt-smiglowiec-rozbil-sie-na-obwodnicy-spadl-na-samochod-sa-ranni-7464326?source=rss](https://tvn24.pl/swiat/hiszpania-madryt-smiglowiec-rozbil-sie-na-obwodnicy-spadl-na-samochod-sa-ranni-7464326?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T11:38:27+00:00

<img alt="Śmigłowiec spadł na samochód. Trzy osoby ranne" src="https://tvn24.pl/najnowsze/cdn-zdjecie-d6my3p-madryt-7464656/alternates/LANDSCAPE_1280" />
    Do zdarzenia doszło na obwodnicy Madrytu.

## Kowalczyk: naprotechnologia skuteczniejsza niż in vitro. "Za wypowiedzą posła stoi niewiedza"
 - [https://konkret24.tvn24.pl/zdrowie/kowalczyk-naprotechnologia-skuteczniejsza-niz-in-vitro-za-wypowiedza-posla-stoi-niewiedza-st7449868?source=rss](https://konkret24.tvn24.pl/zdrowie/kowalczyk-naprotechnologia-skuteczniejsza-niz-in-vitro-za-wypowiedza-posla-stoi-niewiedza-st7449868?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T11:29:39+00:00

<img alt="Kowalczyk: naprotechnologia skuteczniejsza niż in vitro. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-mjwsti-kowalczyk-naprotechnologia-jest-skuteczniejsza-niz-in-vitro-nieprawda-7463420/alternates/LANDSCAPE_1280" />
    Eksperci wyjaśniają, dlaczego poseł PiS nie ma racji i tych metod nie można porównywać.

## Jadą na pomoc, chociaż sami są celem
 - [https://tvn24.pl/swiat/ukraina-praca-strazakow-ktorzy-jezdza-na-akcje-po-rosyjskich-atakach-relacja-tomasza-kanika-7464270?source=rss](https://tvn24.pl/swiat/ukraina-praca-strazakow-ktorzy-jezdza-na-akcje-po-rosyjskich-atakach-relacja-tomasza-kanika-7464270?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T11:25:40+00:00

<img alt="Jadą na pomoc, chociaż sami są celem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-t5azsn-miejscowi-nazywaja-strazakow-wybawicielami-7464352/alternates/LANDSCAPE_1280" />
    "Wybawiciele", których Rosjanie chcą zabijać "dwururką".

## Trzech mężczyzn miało wielokrotnie wykorzystać seksualnie 14-letnią dziewczynkę
 - [https://tvn24.pl/krakow/limanowa-krakow-zarzuty-wykorzystania-seksualnego-14-latki-dla-trzech-mezczyzn-7464255?source=rss](https://tvn24.pl/krakow/limanowa-krakow-zarzuty-wykorzystania-seksualnego-14-latki-dla-trzech-mezczyzn-7464255?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T11:19:36+00:00

<img alt="Trzech mężczyzn miało wielokrotnie wykorzystać seksualnie 14-letnią dziewczynkę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jaljfd-decyzja-sadu-mezczyzna-trafil-do-aresztu-na-trzy-miesiace-7450902/alternates/LANDSCAPE_1280" />
    Jeden trafił do aresztu, dwóch pozostało na wolności.

## PiS broni Adama Glapińskiego. Wniosek do TK w sprawie przepisów o Trybunale Stanu
 - [https://tvn24.pl/biznes/z-kraju/pis-broni-adama-glapinskiego-wniosek-do-tk-w-sprawie-przepisow-o-trybunale-stanu-st7464365?source=rss](https://tvn24.pl/biznes/z-kraju/pis-broni-adama-glapinskiego-wniosek-do-tk-w-sprawie-przepisow-o-trybunale-stanu-st7464365?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T11:18:27+00:00

<img alt="PiS broni Adama Glapińskiego. Wniosek do TK w sprawie przepisów o Trybunale Stanu" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-yshjwo-trybunal-konstytucyjny-wciaz-sparalizowany-opozycja-ma-pomysl-jak-to-zmienic-7403179/alternates/LANDSCAPE_1280" />
    Na czele grupy posłów stoi nowy minister Krzysztof Szczucki.

## "Kardiolodzy dali zielone światło". Syn LeBrona Jamesa może grać
 - [https://eurosport.tvn24.pl/koszykowka/bronny-james-syn-lebrona-jamesa-moze-wrocic-do-treningow-koszykowka_sto9902877/story.shtml?source=rss](https://eurosport.tvn24.pl/koszykowka/bronny-james-syn-lebrona-jamesa-moze-wrocic-do-treningow-koszykowka_sto9902877/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T11:16:22+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-s0y6nt-bronny-james-fa-riscaldamento-con-la-squadra-prima-della-partita-tra-usc-e-brown-ncaa-2023-24-7464432/alternates/LANDSCAPE_1280" />
    Cztery miesiące temu doznał zatrzymania akcji serca.

## Wjechał w drzewo, zmarły jego siostra i matka. Nic nie pamięta
 - [https://tvn24.pl/katowice/wreczyca-wielka-wjechal-w-drzewo-zmarly-jego-siostra-i-matka-odpowie-za-to-przed-sadem-chociaz-nie-przekroczyl-predkosci-7464202?source=rss](https://tvn24.pl/katowice/wreczyca-wielka-wjechal-w-drzewo-zmarly-jego-siostra-i-matka-odpowie-za-to-przed-sadem-chociaz-nie-przekroczyl-predkosci-7464202?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T11:14:34+00:00

<img alt="Wjechał w drzewo, zmarły jego siostra i matka. Nic nie pamięta" src="https://tvn24.pl/najnowsze/cdn-zdjecie-a8siy5-w-wypadku-zginely-matka-i-corka-6185675/alternates/LANDSCAPE_1280" />
    Prawo jazdy miał od kilku miesięcy. Stanie przed sądem.

## 70-latka urodziła bliźnięta. "Matka i dzieci czują się dobrze"
 - [https://tvn24.pl/swiat/uganda-70-latka-urodzila-bliznieta-matka-i-dzieci-czuja-sie-dobrze-7464291?source=rss](https://tvn24.pl/swiat/uganda-70-latka-urodzila-bliznieta-matka-i-dzieci-czuja-sie-dobrze-7464291?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T11:10:52+00:00

<img alt="70-latka urodziła bliźnięta. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-9x74xe-safina-namukwaya-fb-7464313/alternates/LANDSCAPE_1280" />
    "Historyczne wydarzenie".

## Erupcja Etny o świcie. Ognisty pióropusz rozświetlił niebo
 - [https://tvn24.pl/tvnmeteo/swiat/wlochy-sycylia-etna-erupcja-etny-o-swiecie-ognista-lawa-rozswietlila-niebo-st7464276?source=rss](https://tvn24.pl/tvnmeteo/swiat/wlochy-sycylia-etna-erupcja-etny-o-swiecie-ognista-lawa-rozswietlila-niebo-st7464276?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T11:05:43+00:00

<img alt="Erupcja Etny o świcie. Ognisty pióropusz rozświetlił niebo " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-fj313e-etna-7464316/alternates/LANDSCAPE_1280" />
    Najwyższy wulkan Europy pokazał znów swoją moc.

## Drastyczne szczegóły sprawy. Oskarżony o zabójstwo rodziców
 - [https://tvn24.pl/katowice/jaworzynka-cieszyn-oskarzony-o-zabojstwo-rodzicow-ciala-znalezli-w-domu-7463982?source=rss](https://tvn24.pl/katowice/jaworzynka-cieszyn-oskarzony-o-zabojstwo-rodzicow-ciala-znalezli-w-domu-7463982?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T11:04:18+00:00

<img alt="Drastyczne szczegóły sprawy. Oskarżony o zabójstwo rodziców" src="https://tvn24.pl/najnowsze/cdn-zdjecie-tdpvah-prokuratura-w-cieszynie-7192957/alternates/LANDSCAPE_1280" />
    Prokuratura zdecydowała się ich nie ujawniać.

## Podpisał umowę z nieistniejącym "państwem". Urzędnik podał się do dymisji
 - [https://tvn24.pl/swiat/paragwaj-porozumienie-z-nieistniejacym-panstwem-usk-dymisja-urzednika-arnaldo-chamorro-7464240?source=rss](https://tvn24.pl/swiat/paragwaj-porozumienie-z-nieistniejacym-panstwem-usk-dymisja-urzednika-arnaldo-chamorro-7464240?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T10:59:57+00:00

<img alt="Podpisał umowę z nieistniejącym " src="https://tvn24.pl/najnowsze/cdn-zdjecie-od78s2-arnaldo-chamorro-podpisal-porozumienie-z-stanami-zjednoczonymi-kailasa-7464064/alternates/LANDSCAPE_1280" />
    Niby-państwo miało obiecywać pomoc.

## Izraelska armia podzieliła Strefę Gazy na obszary. Będzie ostrzegać ich mieszkańców przed atakiem
 - [https://tvn24.pl/swiat/koniec-rozejmu-w-strefie-gazy-izraelska-armia-opublikowala-mape-majaca-pomoc-mieszkancom-w-ewakuacji-7464209?source=rss](https://tvn24.pl/swiat/koniec-rozejmu-w-strefie-gazy-izraelska-armia-opublikowala-mape-majaca-pomoc-mieszkancom-w-ewakuacji-7464209?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T10:57:47+00:00

<img alt="Izraelska armia podzieliła Strefę Gazy na obszary. Będzie ostrzegać ich mieszkańców przed atakiem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lds368-mapka-gaza-sklej-16-7464369/alternates/LANDSCAPE_1280" />
    "IDF zdecydowanie działa przeciwko organizacjom terrorystycznym, dokładając jednocześnie wszelkich starań, aby rozróżnić cywilów od terrorystów"

## Kiedy nowy rząd? Data po spotkaniu Tuska z Hołownią
 - [https://tvn24.pl/polska/donald-tusk-kiedy-powolanie-rzadu-spotkanie-z-marszalkiem-sejmu-szymonem-holownia-wspolna-konferencja-7464368?source=rss](https://tvn24.pl/polska/donald-tusk-kiedy-powolanie-rzadu-spotkanie-z-marszalkiem-sejmu-szymonem-holownia-wspolna-konferencja-7464368?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T10:57:42+00:00

<img alt="Kiedy nowy rząd? Data po spotkaniu Tuska z Hołownią" src="https://tvn24.pl/najnowsze/cdn-zdjecie-o7wv01-szymon-holownia-donald-tusk-7464378/alternates/LANDSCAPE_1280" />
    Kandydat na premiera powyborczej koalicji po spotkaniu z Szymonem Hołownią.

## PiS dorzuca więcej środków na Bezpieczny Kredyt 2 procent
 - [https://tvn24.pl/biznes/najnowsze/podwyzszenie-limitow-wydatkow-budzetu-z-programu-bezpieczny-kredyt-2-proc-ma-wzrosnac-o-5-mld-zlotych-do-16-mld-st7464371?source=rss](https://tvn24.pl/biznes/najnowsze/podwyzszenie-limitow-wydatkow-budzetu-z-programu-bezpieczny-kredyt-2-proc-ma-wzrosnac-o-5-mld-zlotych-do-16-mld-st7464371?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T10:56:16+00:00

<img alt="PiS dorzuca więcej środków na Bezpieczny Kredyt 2 procent" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-br84e5-na-zakup-nieruchomosci-na-kredyt-potrzeba-dzis-znacznie-wiecej-gotowki-niz-przed-rokiem-4670823/alternates/LANDSCAPE_1280" />
    Poinformował premier.

## Scorsese i Spielberg połączą siły przy adaptacji kultowej powieści grozy
 - [https://tvn24.pl/kultura-i-styl/scorsese-i-spielberg-polacza-sily-przy-adaptacji-kultowej-powiesci-grozy-przyladek-strachu-7463598?source=rss](https://tvn24.pl/kultura-i-styl/scorsese-i-spielberg-polacza-sily-przy-adaptacji-kultowej-powiesci-grozy-przyladek-strachu-7463598?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T10:54:21+00:00

<img alt="Scorsese i Spielberg połączą siły przy adaptacji kultowej powieści grozy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-g4j40d-scorsese-i-spielberg-lacza-sily-7457187/alternates/LANDSCAPE_1280" />
    Na jej podstawie powstały już dwa filmy.

## Śmiertelne potrącenie na przejściu dla pieszych
 - [https://tvn24.pl/poznan/niepruszewo-smiertelne-potracenie-na-przejsciu-dla-pieszych-7464088?source=rss](https://tvn24.pl/poznan/niepruszewo-smiertelne-potracenie-na-przejsciu-dla-pieszych-7464088?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T10:50:52+00:00

<img alt="Śmiertelne potrącenie na przejściu dla pieszych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-37vaqf-potracenie-na-przejsciu-dla-pieszych-zdjecie-ilustracyjne-7464069/alternates/LANDSCAPE_1280" />
    Zginęła 66-latka, kierowca był trzeźwy.

## 10 dobrych książek pod choinkę. Reportaże, biografie i powieści
 - [https://tvn24.pl/kultura-i-styl/prezenty-na-boze-narodzenie-2023-10-dobrych-ksiazek-pod-choinke-reportaze-biografie-powiesci-7453596?source=rss](https://tvn24.pl/kultura-i-styl/prezenty-na-boze-narodzenie-2023-10-dobrych-ksiazek-pod-choinke-reportaze-biografie-powiesci-7453596?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T10:37:32+00:00

<img alt="10 dobrych książek pod choinkę. Reportaże, biografie i powieści" src="https://tvn24.pl/najnowsze/cdn-zdjecie-y5w24h-shutterstock_2225498509-7463134/alternates/LANDSCAPE_1280" />
    Rok 2023 obfitował w zarówno polskie, jak i zagraniczne ciekawe premiery.

## Paradoks Polaków. Nie awansowali, a mogą trafić do wymarzonej grupy
 - [https://eurosport.tvn24.pl/pilka-nozna/euro/2024/losowanie-grup-euro-2024.-potencjalna-grupa-marzen-i-smierci-reprezentacji-polski-pilka-nozna_sto9902769/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/euro/2024/losowanie-grup-euro-2024.-potencjalna-grupa-marzen-i-smierci-reprezentacji-polski-pilka-nozna_sto9902769/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T10:36:22+00:00

<img alt="Paradoks Polaków. Nie awansowali, a mogą trafić do wymarzonej grupy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ea7g1z-reprezentacja-polski-7464348/alternates/LANDSCAPE_1280" />
    W sobotę losowanie grup piłkarskiego Euro 2024.

## Wołodymyr Zełenski na linii frontu. "Dziękuję za służbę"
 - [https://tvn24.pl/swiat/ukraina-wolodymyr-zelenski-odwiedzil-linie-frontu-w-poblizu-kupianska-7463821?source=rss](https://tvn24.pl/swiat/ukraina-wolodymyr-zelenski-odwiedzil-linie-frontu-w-poblizu-kupianska-7463821?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T09:40:00+00:00

<img alt="Wołodymyr Zełenski na linii frontu. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-v4opya-zelenski-odwiedzil-linie-frontu-w-poblizu-kupianska-7463820/alternates/LANDSCAPE_1280" />
    Prezydent rozmawiał z żołnierzami.

## Był poszukiwany listem gończym za niepłacenie alimentów, zdradziły go ślady na śniegu
 - [https://tvn24.pl/tvnwarszawa/okolice/gozd-mazowsze-ukrywal-sie-bo-nie-placil-alimentow-zdradzily-go-slady-na-sniegu-st7464217?source=rss](https://tvn24.pl/tvnwarszawa/okolice/gozd-mazowsze-ukrywal-sie-bo-nie-placil-alimentow-zdradzily-go-slady-na-sniegu-st7464217?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T09:32:28+00:00

<img alt="Był poszukiwany listem gończym za niepłacenie alimentów, zdradziły go ślady na śniegu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qev2z5-slady-na-sniegu-doprowadzily-policjantow-do-poszukiwanego-zdj-ilustracyjne-7464208/alternates/LANDSCAPE_1280" />
    Policjanci z Radomia przewieźli 31-latka do aresztu śledczego.

## "Uważamy to za zapowiedź tego, co ma nadejść"
 - [https://tvn24.pl/swiat/ukraina-bialy-dom-spodziewamy-sie-ze-rosja-tej-zimy-ponownie-bedzie-chciala-zniszczyc-infrastrukture-energetyczna-ukrainy-7463818?source=rss](https://tvn24.pl/swiat/ukraina-bialy-dom-spodziewamy-sie-ze-rosja-tej-zimy-ponownie-bedzie-chciala-zniszczyc-infrastrukture-energetyczna-ukrainy-7463818?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T09:32:07+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4td0b0-ukraina-od-ponad-600-dni-broni-sie-przed-rosyjska-agresja-7459652/alternates/LANDSCAPE_1280" />
    Biały Dom o ostatnich atakach Rosji.

## "Nie muszę być w moim kraju, żeby poczuć się odpowiedzialna za śmierć osoby w lesie"
 - [https://tvn24.pl/kultura-i-styl/kasia-smutniak-nie-musze-byc-w-moim-kraju-zeby-poczuc-sie-odpowiedzialna-za-smierc-osoby-w-lesie-7463826?source=rss](https://tvn24.pl/kultura-i-styl/kasia-smutniak-nie-musze-byc-w-moim-kraju-zeby-poczuc-sie-odpowiedzialna-za-smierc-osoby-w-lesie-7463826?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T09:22:07+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pqe3o4-fragment-filmu-mur-kasi-smutniak-7463825/alternates/LANDSCAPE_1280" />
    Dokument "Mur" otworzył festiwal Watch Docs 2023.

## Śmierć Gabriela Seweryna. Znane są wyniki sekcji
 - [https://tvn24.pl/wroclaw/wroclaw-smierc-gabriela-seweryna-znane-sa-wyniki-sekcji-7464172?source=rss](https://tvn24.pl/wroclaw/wroclaw-smierc-gabriela-seweryna-znane-sa-wyniki-sekcji-7464172?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T09:11:08+00:00

<img alt="Śmierć Gabriela Seweryna. Znane są wyniki sekcji" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xvlo2e-gabriel-seweryn-7460283/alternates/LANDSCAPE_1280" />
    Potrzebne są dodatkowe badania. Sekcja wykluczyła obrażenia ciała.

## Alert RCB przed złą jakością powietrza. "Zrezygnuj z aktywności na zewnątrz"
 - [https://tvn24.pl/tvnmeteo/polska/alert-rcb-smog-w-polsce-zrezygnuj-z-aktywnosci-na-zewnatrz-st7464096?source=rss](https://tvn24.pl/tvnmeteo/polska/alert-rcb-smog-w-polsce-zrezygnuj-z-aktywnosci-na-zewnatrz-st7464096?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T08:55:56+00:00

<img alt="Alert RCB przed złą jakością powietrza. " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-3pbakw-smog-7464118/alternates/LANDSCAPE_1280" />
    Zła jakość powietrza w części kraju.

## Alert RCB przed złą jakością powietrza. "Zrezygnuj z aktywności na zewnątrz"
 - [https://tvn24.pl/tvnmeteo/smog/alert-rcb-smog-w-polsce-zrezygnuj-z-aktywnosci-na-zewnatrz-st7464096?source=rss](https://tvn24.pl/tvnmeteo/smog/alert-rcb-smog-w-polsce-zrezygnuj-z-aktywnosci-na-zewnatrz-st7464096?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T08:55:56+00:00

<img alt="Alert RCB przed złą jakością powietrza. " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-3pbakw-smog-7464118/alternates/LANDSCAPE_1280" />
    Zła jakość powietrza w części kraju.

## W tych miastach oddycha się najgorzej. Normy znacznie przekroczone
 - [https://tvn24.pl/tvnmeteo/smog/smog-w-polsce-jakosc-powietrza-w-piatek-wieczorem-alert-rcb-w-trzech-wojewodztwach-st7464096?source=rss](https://tvn24.pl/tvnmeteo/smog/smog-w-polsce-jakosc-powietrza-w-piatek-wieczorem-alert-rcb-w-trzech-wojewodztwach-st7464096?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T08:55:56+00:00

<img alt="W tych miastach oddycha się najgorzej. Normy znacznie przekroczone" src="https://tvn24.pl/najnowsze/cdn-zdjecie-08g6i2-smog-jakosc-powietrza-6366534/alternates/LANDSCAPE_1280" />
    Smog nad Polską.

## "Żyjemy w takim świecie, gdzie pośpiech zabija człowieczeństwo"
 - [https://tvn24.pl/polska/smierc-natalii-z-andrychowa-ekspertka-o-braku-udzielenia-pomocy-i-psychologii-tlumu-7463979?source=rss](https://tvn24.pl/polska/smierc-natalii-z-andrychowa-ekspertka-o-braku-udzielenia-pomocy-i-psychologii-tlumu-7463979?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T08:48:56+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-oravgz-znicze-w-centrum-andrychowa-7464028/alternates/LANDSCAPE_1280" />
    Profesor Krystyna Skarżyńska odniosła się do sprawy śmierci 14-letniej Natalii z Andrychowa.

## Referendum nie wypaliło, publiczne pieniądze wydano
 - [https://konkret24.tvn24.pl/polityka/wybory-2023-referendum-nie-wypalilo-publiczne-pieniadze-wydano-st7404067?source=rss](https://konkret24.tvn24.pl/polityka/wybory-2023-referendum-nie-wypalilo-publiczne-pieniadze-wydano-st7404067?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T08:47:39+00:00

<img alt="Referendum nie wypaliło, publiczne pieniądze wydano" src="https://tvn24.pl/najnowsze/cdn-zdjecie-73i8z-referendum-razem-z-wyborami-do-sejmu-i-senatu-2023-7395960/alternates/LANDSCAPE_1280" />
    Trzy miliony, pięć milionów złotych czy więcej? Z szacunkowych danych wynika, że koszty "profrekwencyjnej akcji informacyjnej" o referendum były wyższe.

## Nakaz aresztowania mistrza. Miał zaatakować kobietę w ciąży
 - [https://eurosport.tvn24.pl/futbol-amerykanski/nfl/2022-2023/zawodnik-nfl-von-miller-oskarzony-o-zaatakowanie-kobiety-w-ciazy_sto9902698/story.shtml?source=rss](https://eurosport.tvn24.pl/futbol-amerykanski/nfl/2022-2023/zawodnik-nfl-von-miller-oskarzony-o-zaatakowanie-kobiety-w-ciazy_sto9902698/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T08:44:02+00:00

<img alt="Nakaz aresztowania mistrza. Miał zaatakować kobietę w ciąży" src="https://tvn24.pl/najnowsze/cdn-zdjecie-u9y5p1-von-miller-jest-zawodnikiem-buffalo-bills-7464121/alternates/LANDSCAPE_1280" />
    Poważne problemy obrońcy zespołu NFL Buffalo Bills Von Millera.

## Obawiano się porachunków, ściągnięto dodatkowe siły. Ściganym okazał się pies
 - [https://tvn24.pl/tvnmeteo/ciekawostki/wlochy-pies-dziurawil-opony-w-miescie-vastogirardi-policja-zlapala-go-po-16-miesiacach-st7464016?source=rss](https://tvn24.pl/tvnmeteo/ciekawostki/wlochy-pies-dziurawil-opony-w-miescie-vastogirardi-policja-zlapala-go-po-16-miesiacach-st7464016?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T08:36:34+00:00

<img alt="Obawiano się porachunków, ściągnięto dodatkowe siły. Ściganym okazał się pies  " src="https://tvn24.pl/najnowsze/cdn-zdjecie-vy5by0-pies-dziurawil-opony-mieszkancow-vastogirardi-7463897/alternates/LANDSCAPE_1280" />
    Sprawę po ponad roku rozwiązano dzięki kamerom.

## Kaskadowy Łuk Wulkaniczny zagraża milionom ludzi
 - [https://tvn24.pl/tvnmeteo/nauka/kaskadowy-luk-wulkaniczny-zagraza-milionom-ludzi-st7462275?source=rss](https://tvn24.pl/tvnmeteo/nauka/kaskadowy-luk-wulkaniczny-zagraza-milionom-ludzi-st7462275?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T08:26:49+00:00

<img alt="Kaskadowy Łuk Wulkaniczny zagraża milionom ludzi" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6xrxbb-widok-na-mount-baker-7462303/alternates/LANDSCAPE_1280" />
    Donoszą amerykańscy eksperci.

## Senator PiS i tajemnicza inwestycja w Sopocie. Dla kogo ta kamienica?
 - [https://tvn24.pl/premium/tajemnicza-inwestycja-tworcy-skok-ow-dla-kogo-kamienica-w-centrum-sopotu-7456638?source=rss](https://tvn24.pl/premium/tajemnicza-inwestycja-tworcy-skok-ow-dla-kogo-kamienica-w-centrum-sopotu-7456638?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T08:19:48+00:00

<img alt="Senator PiS i tajemnicza inwestycja w Sopocie. Dla kogo ta kamienica?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-uy7936-grzegorz-bierecki-7463968/alternates/LANDSCAPE_1280" />
    Senator PiS Grzegorz Bierecki pod szyldem działalności badawczej i rozwojowej robi kolejny interes. Właśnie zamienia na mieszkania powierzchnię biurową będącą własnością Spółdzielczego Instytutu Naukowego. Wszystko to dzieje się w centrum Sopotu, gdzie ceny nieruchomości są najwyższe w Polsce. Dla kogo szykowane są lokale w doskonałej lokalizacji?

## Samochód przewrócił się na bok na trasie ekspresowej
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-samochod-przewrocil-sie-na-bok-na-drodze-ekspresowej-st7464045?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-samochod-przewrocil-sie-na-bok-na-drodze-ekspresowej-st7464045?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T08:18:31+00:00

<img alt="Samochód przewrócił się na bok na trasie ekspresowej" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-s6gx5i-samochod-przewrocil-sie-na-bok-7464035/alternates/LANDSCAPE_1280" />
    Na wysokości Marynarskiej.

## Ranking zaufania. Szymon Hołownia blisko rekordu wszech czasów. Andrzej Duda spadł z podium
 - [https://tvn24.pl/polska/sondaz-ktoremu-politykowi-najbardziej-ufaja-polacy-ranking-zaufania-szymon-holownia-na-czele-7463893?source=rss](https://tvn24.pl/polska/sondaz-ktoremu-politykowi-najbardziej-ufaja-polacy-ranking-zaufania-szymon-holownia-na-czele-7463893?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T07:53:24+00:00

<img alt="Ranking zaufania. Szymon Hołownia blisko rekordu wszech czasów. Andrzej Duda spadł z podium" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ae94ou-szymon-holownia-i-andrzej-duda-7463915/alternates/LANDSCAPE_1280" />
    Sondaż IBRiS dla Onetu.

## "Noc zszargana brutalnym zachowaniem kibiców Legii"
 - [https://eurosport.tvn24.pl/pilka-nozna/liga-konferencji/2023-2024/brytyjskie-media-po-meczu-aston-villa-legia-warszawa-w-lidze-konferencji-europy-2023-2024_sto9902690/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/liga-konferencji/2023-2024/brytyjskie-media-po-meczu-aston-villa-legia-warszawa-w-lidze-konferencji-europy-2023-2024_sto9902690/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T07:53:18+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1jpg0s-kibice-legii-warszawa-w-birmingham-7464007/alternates/LANDSCAPE_1280" />
    Brytyjskie media po meczu Aston Villi z warszawskim zespołem.

## Petru: Orlen złupił Polaków. Przez nowy podatek "ma zwrócić narodowi to, co zabrał"
 - [https://tvn24.pl/biznes/pieniadze/podatek-od-nadmiarowych-zyskow-ma-byc-nalozony-na-orlen-komentuje-ryszard-petru-st7463951?source=rss](https://tvn24.pl/biznes/pieniadze/podatek-od-nadmiarowych-zyskow-ma-byc-nalozony-na-orlen-komentuje-ryszard-petru-st7463951?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T07:48:46+00:00

<img alt="Petru: Orlen złupił Polaków. Przez nowy podatek " src="https://tvn24.pl/najnowsze/cdn-zdjecie-syup2o-orlen-mozco-mateusz-szymanski-shutterstock_2293077545-7399230/alternates/LANDSCAPE_1280" />
    Ryszard Petru o planie opodatkowania Orlenu.

## Przy gruncie -18 stopni. Rozpoczęła się meteorologiczna zima
 - [https://tvn24.pl/tvnmeteo/pogoda/mroz-w-polsce-meteorologiczna-zima-przy-gruncie-18-stopni-snieg-st7463896?source=rss](https://tvn24.pl/tvnmeteo/pogoda/mroz-w-polsce-meteorologiczna-zima-przy-gruncie-18-stopni-snieg-st7463896?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T07:33:42+00:00

<img alt="Przy gruncie -18 stopni. Rozpoczęła się meteorologiczna zima" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pvflki-zimno-7463909/alternates/LANDSCAPE_1280" />
    Gdzie minionej nocy ścisnął mróz?

## Poruszający dokument o sytuacji na granicy polsko-białoruskiej
 - [https://tvn24.pl/polska/poruszajacy-dokument-o-sytuacji-na-granicy-polsko-bialoruskiej-7463792?source=rss](https://tvn24.pl/polska/poruszajacy-dokument-o-sytuacji-na-granicy-polsko-bialoruskiej-7463792?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T07:27:44+00:00

<img alt="Poruszający dokument o sytuacji na granicy polsko-białoruskiej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-skhh1c-kakol-7463783/alternates/LANDSCAPE_1280" />
    "Mur" - debiut reżyserski znanej aktorki Kasi Smutniak - otwiera festiwal Watch Docs organizowany przez Helsińską Fundację Praw Człowieka.

## Zderzenie tramwajów przy Dworcu Wileńskim. Poszkodowane dwie osoby
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-zderzenie-dwoch-tramwajow-przy-dworcu-wilenskim-utrudnienia-st7463929?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-zderzenie-dwoch-tramwajow-przy-dworcu-wilenskim-utrudnienia-st7463929?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T07:22:26+00:00

<img alt="Zderzenie tramwajów przy Dworcu Wileńskim. Poszkodowane dwie osoby" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-fmldm5-zderzenie-dwoch-tramwajow-na-przy-dworcu-wilenskim-zdj-ilustracyjne-7463927/alternates/LANDSCAPE_1280" />
    Są utrudnienia w ruchu.

## Sochan szalał. Padł nawet rekord
 - [https://eurosport.tvn24.pl/koszykowka/nba/2023-2024/san-antonio-spurs-atlanta-hawks-wynik-meczu-i-relacja.-jeremy-sochan-ustanowil-rekord-punktowy-w-kar_sto9902685/story.shtml?source=rss](https://eurosport.tvn24.pl/koszykowka/nba/2023-2024/san-antonio-spurs-atlanta-hawks-wynik-meczu-i-relacja.-jeremy-sochan-ustanowil-rekord-punktowy-w-kar_sto9902685/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T07:06:17+00:00

<img alt="Sochan szalał. Padł nawet rekord" src="https://tvn24.pl/najnowsze/cdn-zdjecie-dff61x-jeremy-sochan-w-akcji-7463916/alternates/LANDSCAPE_1280" />
    Polak w wybornej formie, ale jego zespół przegrał kolejne spotkanie w lidze.

## Chcieli się ogrzać tuż przy magazynie broni. Granatnik stoczył się do ognia i wybuchł. Większość nie żyje
 - [https://tvn24.pl/swiat/rosja-12-zolnierzy-rosyjskich-zginelo-gdy-granatnik-stoczyl-im-sie-do-ogniska-i-wybuchl-7463819?source=rss](https://tvn24.pl/swiat/rosja-12-zolnierzy-rosyjskich-zginelo-gdy-granatnik-stoczyl-im-sie-do-ogniska-i-wybuchl-7463819?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T07:00:41+00:00

<img alt="Chcieli się ogrzać tuż przy magazynie broni. Granatnik stoczył się do ognia i wybuchł. Większość nie żyje" src="https://tvn24.pl/najnowsze/cdn-zdjecie-f663bw-rosyjscy-zolnierze-6728212/alternates/LANDSCAPE_1280" />
    Kolejnych ośmiu jest rannych.

## Były Hawaje, teraz zadziwia świat skoków
 - [https://eurosport.tvn24.pl/skoki-narciarskie/lillehammer/2023-2024/stefan-kraft-przed-konkursami-w-lillehammer-puchar-swiata-w-skokach-narciarskich_sto9902092/story.shtml?source=rss](https://eurosport.tvn24.pl/skoki-narciarskie/lillehammer/2023-2024/stefan-kraft-przed-konkursami-w-lillehammer-puchar-swiata-w-skokach-narciarskich_sto9902092/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T06:56:15+00:00

<img alt="Były Hawaje, teraz zadziwia świat skoków" src="https://tvn24.pl/najnowsze/cdn-zdjecie-iilsa1-stefan-kraft-7463902/alternates/LANDSCAPE_1280" />
    Stefan Kraft dla Eurosportu o wybuchu swojej formy.

## Co dalej z inflacją? Ryszard Petru nie ma dobrych informacji
 - [https://tvn24.pl/biznes/najnowsze/inflacja-w-polsce-ryszard-petru-w-jeden-na-jeden-rzad-i-narodowy-bank-polski-polegli-w-walce-z-inflacja-st7463894?source=rss](https://tvn24.pl/biznes/najnowsze/inflacja-w-polsce-ryszard-petru-w-jeden-na-jeden-rzad-i-narodowy-bank-polski-polegli-w-walce-z-inflacja-st7463894?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T06:55:18+00:00

<img alt="Co dalej z inflacją? Ryszard Petru nie ma dobrych informacji" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pu46t2-petru-7463891/alternates/LANDSCAPE_1280" />
    Ryszard Petru był gościem programu "Jeden na jeden".

## Uwolnieni w ostatniej chwili
 - [https://tvn24.pl/swiat/izrael-koniec-rozejmu-w-strefie-gazy-ostatnia-wymiana-zakladnikow-kim-sa-uwolnieni-7463853?source=rss](https://tvn24.pl/swiat/izrael-koniec-rozejmu-w-strefie-gazy-ostatnia-wymiana-zakladnikow-kim-sa-uwolnieni-7463853?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T06:50:38+00:00

<img alt="Uwolnieni w ostatniej chwili" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wb19rx-w-czwartek-uwolniono-osmiu%20izraelskich-zakladnikow-ze-strefy-gazy-7463882/alternates/LANDSCAPE_1280" />
    O 6 rano czasu polskiego zakończył się rozejm między Izraelem i Hamasem.

## Mer Militopola: siły ukraińskie zniszczyły w Tokmaku sztab wojskowy wroga. Wielu oficerów zginęło
 - [https://tvn24.pl/swiat/ukraina-najwazniejsze-wydarzenia-ostatnich-godzin-1-grudnia-7463834?source=rss](https://tvn24.pl/swiat/ukraina-najwazniejsze-wydarzenia-ostatnich-godzin-1-grudnia-7463834?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T06:22:21+00:00

<img alt="Mer Militopola: siły ukraińskie zniszczyły w Tokmaku sztab wojskowy wroga. Wielu oficerów zginęło" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9biobs-ukraina-wojsko-7462195/alternates/LANDSCAPE_1280" />
    Rosyjska pełnoskalowa inwazja na Ukrainę trwa już od 646 dni.

## "Wystrzelono race, są ranni". Kibice Legii starli się z angielską policją
 - [https://eurosport.tvn24.pl/pilka-nozna/kibice-legii-starli-sie-z-angielska-policja-przed-meczem-z-aston-villa-liga-konferencji_sto9902675/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/kibice-legii-starli-sie-z-angielska-policja-przed-meczem-z-aston-villa-liga-konferencji_sto9902675/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T05:46:49+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-w3kgs6-kibice-legii-starli-sie-z-angielska-policja-7463869/alternates/LANDSCAPE_1280" />
    Burdy przed meczem w Birmingham.

## Dodatkowe niedziele handlowe w grudniu. "Pracownicy zaskoczeni"
 - [https://tvn24.pl/biznes/z-kraju/niedziele-handlowe-w-grudniu-dwie-dodatkowe-zaskoczyly-pracownikow-st7463856?source=rss](https://tvn24.pl/biznes/z-kraju/niedziele-handlowe-w-grudniu-dwie-dodatkowe-zaskoczyly-pracownikow-st7463856?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T05:39:20+00:00

<img alt="Dodatkowe niedziele handlowe w grudniu. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-y64acu-supermarket-lubin-kasa-sklep-zakupy-niedziela-handlowa-5122015/alternates/LANDSCAPE_1280" />
    Twierdzą związkowcy.

## Alerty przed gołoledzią i obfitymi opadami śniegu. IMGW ostrzega
 - [https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-drugiego-stopnia-dla-czesci-kraju-snieg-gololedz-opady-marznace-w-kolejnych-dniach-mozliwe-sniezyce-i-silny-mroz-st7463850?source=rss](https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-drugiego-stopnia-dla-czesci-kraju-snieg-gololedz-opady-marznace-w-kolejnych-dniach-mozliwe-sniezyce-i-silny-mroz-st7463850?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T05:34:51+00:00

<img alt="Alerty przed gołoledzią i obfitymi opadami śniegu. IMGW ostrzega" src="https://tvn24.pl/najnowsze/cdn-zdjecie-67o40q-snieg-6430195/alternates/LANDSCAPE_1280" />
    Obowiązują pomarańczowe i żółte ostrzeżenia.

## Potężne śnieżyce, spadnie nawet pół metra. Alerty najwyższego stopnia
 - [https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-potezne-sniezyce-w-polsce-spadnie-nawet-pol-metra-sniegu-czerwone-ostrzezenia-st7463850?source=rss](https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-potezne-sniezyce-w-polsce-spadnie-nawet-pol-metra-sniegu-czerwone-ostrzezenia-st7463850?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T05:34:51+00:00

<img alt="Potężne śnieżyce, spadnie nawet pół metra. Alerty najwyższego stopnia " src="https://tvn24.pl/najnowsze/cdn-zdjecie-m95ty8-intensywne-opady-sniegu-7465247/alternates/LANDSCAPE_1280" />
    Ostrzeżenia IMGW.

## Zima uderzy z podwójną mocą. IMGW wydał czerwony alert
 - [https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-niz-robin-alarmy-trzeciego-stopnia-czerwone-alerty-snieg-gololedz-opady-marznace-sniezyce-niz-robin-st7463850?source=rss](https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-niz-robin-alarmy-trzeciego-stopnia-czerwone-alerty-snieg-gololedz-opady-marznace-sniezyce-niz-robin-st7463850?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T05:34:51+00:00

<img alt="Zima uderzy z podwójną mocą. IMGW wydał czerwony alert" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3hgr0q-meteo-sklej-7464484/alternates/LANDSCAPE_1280" />
    Alarmy.

## Pierwsze ofiary w Gazie. Nieoficjalnie: negocjacje w sprawie rozejmu w toku
 - [https://tvn24.pl/swiat/izrael-koniec-rozejmu-w-strefie-gazy-izraelskie-lotnictwo-i-artyleria-ostrzeliwuja-gaze-7463830?source=rss](https://tvn24.pl/swiat/izrael-koniec-rozejmu-w-strefie-gazy-izraelskie-lotnictwo-i-artyleria-ostrzeliwuja-gaze-7463830?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T05:30:00+00:00

<img alt="Pierwsze ofiary w Gazie. Nieoficjalnie: negocjacje w sprawie rozejmu w toku" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qjgc40-gaza2-7463952/alternates/LANDSCAPE_1280" />
    14 Palestyńczyków zginęło w piątek rano po wznowieniu przez Izrael działań wojskowych w Strefie Gazy.

## Chłopiec bez kurtki na ławce. W zimny dzień. Trudno uwierzyć w wynik eksperymentu
 - [https://tvn24.pl/polska/eksperyment-dzien-dobry-tvn-sprawdzilismy-ile-osob-pomoze-zmarznietemu-dziecku-7463811?source=rss](https://tvn24.pl/polska/eksperyment-dzien-dobry-tvn-sprawdzilismy-ile-osob-pomoze-zmarznietemu-dziecku-7463811?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-01T04:47:22+00:00

<img alt="Chłopiec bez kurtki na ławce. W zimny dzień. Trudno uwierzyć w wynik eksperymentu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-867pgf-reporterzy-dzien-dobry-tvn-postanowili-sprawdzic-ilu-przechodniow-zainteresuje-sie-losem-dziecka-7463808/alternates/LANDSCAPE_1280" />
    Przeszło koło niego około 800 warszawianek i warszawiaków. Kto zainteresował się jego losem?

