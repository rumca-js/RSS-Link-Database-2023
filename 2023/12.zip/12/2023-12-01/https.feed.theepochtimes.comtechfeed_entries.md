# Source:Epoch Times - Tech, URL:https://feed.theepochtimes.com/tech/feed, language:en-US

## Apple Responds to Police Warnings About New iPhone Feature
 - [https://www.theepochtimes.com/business/apple-responds-to-police-warnings-about-new-iphone-feature-5539635](https://www.theepochtimes.com/business/apple-responds-to-police-warnings-about-new-iphone-feature-5539635)
 - RSS feed: https://feed.theepochtimes.com/tech/feed
 - date published: 2023-12-01T19:28:36+00:00

A woman uses her iPhone in a file photo. (Jack Guez/AFP via Getty Images)

