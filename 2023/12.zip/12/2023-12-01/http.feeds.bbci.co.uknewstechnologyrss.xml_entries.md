# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Why weather in games is getting more realistic
 - [https://www.bbc.co.uk/news/newsbeat-67155047?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-67155047?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-12-01T12:12:32+00:00

Games developers are putting more effort into recreating lifelike rain, fog and wind - but why?

## TikTok: US judge blocks Montana's ban citing free speech
 - [https://www.bbc.co.uk/news/business-67586224?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-67586224?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-12-01T04:48:10+00:00

Chinese-owned app welcomes the ruling against "unconstitutional law" due to come into effect in January.

