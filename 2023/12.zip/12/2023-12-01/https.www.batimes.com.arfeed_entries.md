# Source:Argentina - Buenos Aires Times, URL:https://www.batimes.com.ar/feed, language:en

## President Alberto Fernández: ‘Milei should give Macri as wide a berth as possible’
 - [https://www.batimes.com.ar/news/argentina/alberto-fernandez-milei-should-give-macri-as-wide-a-berth-as-possible.phtml](https://www.batimes.com.ar/news/argentina/alberto-fernandez-milei-should-give-macri-as-wide-a-berth-as-possible.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2023-12-01T18:04:09+00:00

<p><img alt="President Alberto Fernández." src="https://fotos.perfil.com/2023/12/01/trim/540/304/president-alberto-fernandez-1710346.jpg" /></p>Just days after meeting with his successor, Argentina’s outgoing president Alberto Fernández sits down to reflect on his four years of government, the challenges he faced and why he believes Javier Milei won last month’s run-off.
 <a href="https://www.batimes.com.ar/news/argentina/alberto-fernandez-milei-should-give-macri-as-wide-a-berth-as-possible.phtml">Leer más</a>

## Patricia Bullrich returns to government as security minister in Javier Milei's Cabinet
 - [https://www.batimes.com.ar/news/argentina/bullrich-returns-to-government-as-security-minister-in-mileis-cabinet.phtml](https://www.batimes.com.ar/news/argentina/bullrich-returns-to-government-as-security-minister-in-mileis-cabinet.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2023-12-01T16:43:53+00:00

<p><img alt="Patricia Bullrich, offices, stock" src="https://fotos.perfil.com/2023/08/22/trim/540/304/patricia-bullrich-offices-stock-1636987.jpg" /></p>President-elect confirms in statement that Patricia Bullrich will return to the Security Ministry for a second time; Former rivals now aligned together in government. <a href="https://www.batimes.com.ar/news/argentina/bullrich-returns-to-government-as-security-minister-in-mileis-cabinet.phtml">Leer más</a>

## Maud Daverio de Cox, author who helped expose dictatorship abuses, dies at 92
 - [https://www.batimes.com.ar/news/argentina/author-and-human-rights-activist-maud-daverio-de-cox-dies-at-92.phtml](https://www.batimes.com.ar/news/argentina/author-and-human-rights-activist-maud-daverio-de-cox-dies-at-92.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2023-12-01T14:38:37+00:00

<p><img alt="Maud Daverio de Cox." src="https://fotos.perfil.com/2023/12/01/trim/540/304/maud-daverio-de-cox-1710160.jpg" /></p>Author Maud Daverio de Cox, the wife of former 'Buenos Aires Herald' editor Robert Cox who helped expose abuses perpetrated by 1976-1983 military dictatorship, passes away aged 92.
 <a href="https://www.batimes.com.ar/news/argentina/author-and-human-rights-activist-maud-daverio-de-cox-dies-at-92.phtml">Leer más</a>

