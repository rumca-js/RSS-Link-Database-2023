# Source:It's FOSS News, URL:https://news.itsfoss.com/rss/, language:en-US

## Open-Source Webmail Roundcube Joins Nextcloud
 - [https://news.itsfoss.com/nextcloud-roundcube](https://news.itsfoss.com/nextcloud-roundcube)
 - RSS feed: https://news.itsfoss.com/rss/
 - date published: 2023-12-01T12:13:26+00:00

Roundcube is teaming up with Nextcloud for its future.

## Godot 4.2 Released: Taking The Open-Source Game Engine Up a Notch
 - [https://news.itsfoss.com/godot-4-2](https://news.itsfoss.com/godot-4-2)
 - RSS feed: https://news.itsfoss.com/rss/
 - date published: 2023-12-01T10:00:24+00:00

Another update to Godot with useful changes to close-in on proprietary options like Unreal, Unity, etc.

