# Source:Home Repair Tutor, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCP2vaEZS8MvZrFklwBtW1GA, language:en

## Announcement - #shorts
 - [https://www.youtube.com/watch?v=bB_CB6LQOds](https://www.youtube.com/watch?v=bB_CB6LQOds)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCP2vaEZS8MvZrFklwBtW1GA
 - date published: 2023-12-01T16:25:24+00:00



