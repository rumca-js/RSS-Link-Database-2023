# Source:Screen Junkies, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCOpcACMWblDls9Z6GERVi1A, language:en-US

## He's Got a Type | Oppenheimer Honest Trailers
 - [https://www.youtube.com/watch?v=xyJQmaKyyLg](https://www.youtube.com/watch?v=xyJQmaKyyLg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCOpcACMWblDls9Z6GERVi1A
 - date published: 2023-12-01T16:51:51+00:00

Watch the full Honest Trailer here: https://youtu.be/mzwE-8-L5YA
#shorts #oppenheimer #honesttrailers

