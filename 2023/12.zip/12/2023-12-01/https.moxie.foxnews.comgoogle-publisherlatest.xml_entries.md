# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## Steve Kerr says wife was annoyed with him 'tossing and turning,' thinking about Warriors' struggles
 - [https://www.foxnews.com/sports/steve-kerr-wife-annoyed-tossing-turning-warriors-struggles](https://www.foxnews.com/sports/steve-kerr-wife-annoyed-tossing-turning-warriors-struggles)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T23:18:36+00:00

Golden State Warriors head coach Steve Kerr didn&apos;t get much sleep after his team blew a 24-point lead to the Sacramento Kings in the In-Season Tournament.

## Authorities in Haiti hold former rebel leader Guy Philippe after the US repatriated him
 - [https://www.foxnews.com/world/authorities-haiti-hold-former-rebel-leader-guy-philippe-us-repatriated](https://www.foxnews.com/world/authorities-haiti-hold-former-rebel-leader-guy-philippe-us-repatriated)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T23:11:31+00:00

Former rebel leader Guy Philippe has been repatriated to Haiti, following the completion of his US prison sentence for money laundering.

## Drunk paramedic crashes Detroit ambulance with patient in back: Officials
 - [https://www.foxnews.com/us/drunk-paramedic-crashes-detroit-ambulance-patient-back-officials](https://www.foxnews.com/us/drunk-paramedic-crashes-detroit-ambulance-patient-back-officials)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T23:11:06+00:00

A Detroit paramedic who crashed the ambulance he was driving while a patient was being transported to the hospital was found to be under the influence and placed on unpaid leave.

## Ramaswamy challenges Iowa governor on use of eminent domain for CO2 pipelines
 - [https://www.foxnews.com/politics/ramaswamy-challenges-iowa-governor-use-eminent-domain-co2-pipelines](https://www.foxnews.com/politics/ramaswamy-challenges-iowa-governor-use-eminent-domain-co2-pipelines)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T23:02:37+00:00

Republican presidential candidate Vivek Ramaswamy on Friday challenged Iowa Governor Kim Reynolds on using eminent domain for CO2 pipelines during a policy speech.

## Tyreek Hill says he will pay wages of cameraman suspended for being part of his touchdown celebration
 - [https://www.foxnews.com/sports/tyreek-hill-pay-wages-cameraman-suspended-touchdown-celebration](https://www.foxnews.com/sports/tyreek-hill-pay-wages-cameraman-suspended-touchdown-celebration)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T22:38:47+00:00

Tyreek Hill said he will cover the wages of the content creator who was suspended for his participation in one of the wide receiver&apos;s touchdown celebrations.

## Blackburn questions why Biden's Commerce Dept chose to 'lift sanctions' on Chinese communist group
 - [https://www.foxnews.com/politics/blackburn-questions-bidens-commerce-dept-chose-lift-sanctions-chinese-communist-group](https://www.foxnews.com/politics/blackburn-questions-bidens-commerce-dept-chose-lift-sanctions-chinese-communist-group)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T22:34:55+00:00

Sen. Marsha Blackburn, R-Tenn., sent a letter to the Department of Commerce over the removal of a CCP institute from its Entity List, which restricts trade from certain groups or individuals.

## Inmate transport driver charged with kidnapping after quitting mid-trip, going off-course
 - [https://www.foxnews.com/us/inmate-transport-driver-charged-kidnapping-quitting-mid-trip-going-off-course](https://www.foxnews.com/us/inmate-transport-driver-charged-kidnapping-quitting-mid-trip-going-off-course)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T22:29:17+00:00

Joshua Pinquet, 21, of Orlando, Florida, has been charged with kidnapping for refusing to drop inmates off in North Carolina after quitting his transport job mid-trip.

## Arizona inmate charged with attempted murder after Derek Chauvin stabbing
 - [https://www.foxnews.com/us/arizona-inmate-charged-attempted-murder-derek-chauvin-stabbing](https://www.foxnews.com/us/arizona-inmate-charged-attempted-murder-derek-chauvin-stabbing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T22:27:47+00:00

Federal prosecutors have filed attempted murder charges against a 52-year-old accused of stabbing ex-Minneapolis cop Derek Chauvin in an Arizona prison.

## Fifth person confirmed dead in Alaska landslide; 1 still missing
 - [https://www.foxnews.com/us/fifth-person-confirmed-dead-alaska-landslide-1-still-missing](https://www.foxnews.com/us/fifth-person-confirmed-dead-alaska-landslide-1-still-missing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T22:27:30+00:00

65-year-old Otto Florschutz has been reported as the fifth confirmed fatality in last week&apos;s Wrangell, Alaska-area landslide. A sixth person remains unaccounted for.

## NH trooper who fatally shot suspect at psych ward likely prevented further injury, state AG says
 - [https://www.foxnews.com/us/nh-trooper-fatally-shot-suspect-psych-ward-likely-prevented-further-injury-state-ag-says](https://www.foxnews.com/us/nh-trooper-fatally-shot-suspect-psych-ward-likely-prevented-further-injury-state-ag-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T22:25:49+00:00

New Hampshire State Trooper Nathan Sleight&apos;s fatal shooting of a security guard&apos;s killer likely prevented further injury or death, state Attorney General John Formella opined Thursday.

## Lions' Amon-Ra St. Brown suggests recent NFL fine was excessive: 'It is a lot of money'
 - [https://www.foxnews.com/sports/lions-amon-ra-st-brown-suggests-recent-nfl-fine-was-excessive-it-is-a-lot-of-money](https://www.foxnews.com/sports/lions-amon-ra-st-brown-suggests-recent-nfl-fine-was-excessive-it-is-a-lot-of-money)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T22:23:41+00:00

Amon-Ra St. Brown&apos;s wallet recently took a significant hit when the NFL handed down a hefty fine for the Lions star&apos;s unnecessary roughness.

## Los Angeles manhunt underway for serial killer suspected in string of deaths
 - [https://www.foxnews.com/us/los-angeles-manhunt-underway-serial-killer-suspected-string-deaths](https://www.foxnews.com/us/los-angeles-manhunt-underway-serial-killer-suspected-string-deaths)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T21:59:44+00:00

Los Angeles leaders are warning that a potential serial killer has been linked to at least three fatal shootings in the past week.

## Zambia reports over 30 people trapped beneath rubble after open-pit mine collapse
 - [https://www.foxnews.com/world/zambia-reports-30-people-trapped-rubble-open-pit-mine-collapse](https://www.foxnews.com/world/zambia-reports-30-people-trapped-rubble-open-pit-mine-collapse)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T21:51:53+00:00

Over 30 people were trapped beneath rubble after an open-pit mine collapsed in Chingola, Zambia, on Friday, according to the country&apos;s government.

## Kenyan cult leader sentenced to 18 months for film violations but still not charged over mass graves
 - [https://www.foxnews.com/world/kenyan-cult-leader-sentenced-18-months-film-violations-still-charged-mass-graves](https://www.foxnews.com/world/kenyan-cult-leader-sentenced-18-months-film-violations-still-charged-mass-graves)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T21:49:26+00:00

Controversial doomsday preacher Paul Mackenzie has been sentenced for illegal film distribution and production, but had pleaded not guilty, saying he didn&apos;t know he needed a license.

## Oregon female athletes file Title IX lawsuit against school citing unfair treatment
 - [https://www.foxnews.com/sports/oregon-female-athletes-title-ix-lawsuit-school-unfair-treatment](https://www.foxnews.com/sports/oregon-female-athletes-title-ix-lawsuit-school-unfair-treatment)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T21:34:03+00:00

Thirty-two female University of Oregon athletes are suing the school for “depriving women of equal treatment and benefits, equal athletic aid, and equal opportunities.&quot;

## Roswell's International UFO Museum celebrates 5 million visitors
 - [https://www.foxnews.com/us/roswells-international-ufo-museum-celebrates-5-million-visitors](https://www.foxnews.com/us/roswells-international-ufo-museum-celebrates-5-million-visitors)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T21:33:57+00:00

The International UFO Museum &amp; Research Center in Roswell, New Mexico, has reported its 5 millionth visitor since its opening in 1992.

## Fox News Politics: Santos goes down
 - [https://www.foxnews.com/politics/fox-news-politics-santos-goes-down](https://www.foxnews.com/politics/fox-news-politics-santos-goes-down)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T21:33:02+00:00

The latest updates from the 2024 campaign trail, exclusive interviews and more Fox News politics content

## Funeral held for Indi Gregory, infant forced off life support in UK: 'True warrior'
 - [https://www.foxnews.com/world/funeral-held-indi-gregory-infant-forced-off-life-support-uk-true-warrior](https://www.foxnews.com/world/funeral-held-indi-gregory-infant-forced-off-life-support-uk-true-warrior)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T21:21:04+00:00

Indi Gregory, the infant forced off life support by the United Kingdom&apos;s court system last month, was laid to rest Friday at a Cathedral in Nottingham, England.

## VP Kamala Harris' 2019 Jussie Smollett defense remains after actor's hate crime hoax conviction, failed appeal
 - [https://www.foxnews.com/politics/vp-kamala-harris-jussie-smollett-defense-remains-actors-hate-crime-hoax-conviction-failed-appeal](https://www.foxnews.com/politics/vp-kamala-harris-jussie-smollett-defense-remains-actors-hate-crime-hoax-conviction-failed-appeal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T21:16:05+00:00

Vice President Kamala Harris&apos; X account still contains a post from 2019 defending Jussie Smollett as the victim of an attempted &quot;modern day lynching.&quot;

## Putin orders Russian military to add 170,000 troops for a total of about 1.32 million
 - [https://www.foxnews.com/world/putin-orders-russian-military-add-170000-troops-total-about-1-32-million](https://www.foxnews.com/world/putin-orders-russian-military-add-170000-troops-total-about-1-32-million)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T21:00:17+00:00

As the Russian invasion of Ukraine stretches to nearly 2 years, Putin is ordering a massive increase in troops, which will bring the overall number of Russian military personnel to 2.2M.

## Kathy Hochul clarifies claim of 'filling' George Santos seat, pledges special election
 - [https://www.foxnews.com/politics/kathy-hochul-clarifies-claim-filling-george-santos-seat-pledges-special-election](https://www.foxnews.com/politics/kathy-hochul-clarifies-claim-filling-george-santos-seat-pledges-special-election)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T21:00:06+00:00

A post on X by New York Gov. Kathy Hochul sparked confusion online as some users believed the remarks to mean would not hold a special election to fill George Santos&apos; Congress vacancy.

## Fetterman demands Sen. Menendez to be expelled from Senate on ‘The View’: ‘Senator for Egypt not New Jersey’
 - [https://www.foxnews.com/media/fetterman-demands-sen-menendez-expelled-from-senate-view-senator-egypt-not-new-jersey](https://www.foxnews.com/media/fetterman-demands-sen-menendez-expelled-from-senate-view-senator-egypt-not-new-jersey)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T21:00:00+00:00

Sen. John Fetterman told the ladies of ABC&apos;s &quot;The View&quot; Friday that Senator Bob Menendez, D-N.J., needs to be expelled from the U.S. Senate.

## Biden DOE to probe Wisconsin school district after claim trans woman showered with four high school girls
 - [https://www.foxnews.com/media/biden-doe-probe-wisconsin-school-district-after-claim-trans-woman-showered-with-four-high-school-girls](https://www.foxnews.com/media/biden-doe-probe-wisconsin-school-district-after-claim-trans-woman-showered-with-four-high-school-girls)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T20:53:48+00:00

The Department of Education is probing a Wisconsin school district after an 18-year-old transgender student allegedly showered completely undressed with high school girls.

## Hitchhiker’s Guide to how the Santos expulsion will amplify pressure on Democrats to deal with men
 - [https://www.foxnews.com/politics/hitchhikers-guide-santos-expulsion-will-amplify-pressure-democrats-deal-men](https://www.foxnews.com/politics/hitchhikers-guide-santos-expulsion-will-amplify-pressure-democrats-deal-men)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T20:49:54+00:00

GOP Rep. George Santos of New York has been indicted by the House of Representatives. Will the Senate follow suit with Democrat Bob Menendez?

## VA's role in migrant medical care draws scrutiny from advocates as border crisis intensifies
 - [https://www.foxnews.com/politics/vas-role-migrant-medical-care-draws-scrutiny-advocates-border-crisis-intensifies](https://www.foxnews.com/politics/vas-role-migrant-medical-care-draws-scrutiny-advocates-border-crisis-intensifies)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T20:36:33+00:00

A long-standing arrangement between ICE and the VA is worrying veterans&apos; advocates, who are concerned that it could be having a knock-on effect on veteran care.

## Tennis star Rafael Nadal announces return to the ATP stage after year-long absence: 'It is time to come back'
 - [https://www.foxnews.com/sports/tennis-star-rafael-nadal-announces-return-atp-stage-after-year-long-absence-it-is-time-to-come-back](https://www.foxnews.com/sports/tennis-star-rafael-nadal-announces-return-atp-stage-after-year-long-absence-it-is-time-to-come-back)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T20:35:12+00:00

Tennis legend Rafael Nadal intends to make his long-awaited return from injury in Australia next month in what is expected to be his final season.

## Fox News True Crime Newsletter: Brian Laundrie hired Gitmo lawyer, Alex Murdaugh faces hometown victims
 - [https://www.foxnews.com/us/fox-news-true-crime-newsletter-brian-laundrie-hired-terror-lawyer-alex-murdaugh-faces-hometown-victims](https://www.foxnews.com/us/fox-news-true-crime-newsletter-brian-laundrie-hired-terror-lawyer-alex-murdaugh-faces-hometown-victims)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T20:34:38+00:00

Stay up to date with the Fox News True Crime Newsletter, which brings you the latest cases ripped from the headlines, from crime to courts, legal and scandal.

## Authorities respond to Atlanta building that houses Israeli Consulate General, several injured
 - [https://www.foxnews.com/us/authorities-respond-atlanta-building-houses-israeli-consulate-general-several-injured](https://www.foxnews.com/us/authorities-respond-atlanta-building-houses-israeli-consulate-general-several-injured)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T20:33:55+00:00

Several people were injured at an Atlanta building that houses the Israeli Consulate General, Atlanta police said Friday afternoon.

## Aaron Rodgers not worried about potential re-injury of Achilles: 'What's the worst that can happen?'
 - [https://www.foxnews.com/sports/aaron-rodgers-not-worried-potential-re-injury-achilles-whats-worst-that-can-happen](https://www.foxnews.com/sports/aaron-rodgers-not-worried-potential-re-injury-achilles-whats-worst-that-can-happen)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T20:27:20+00:00

If Aaron Rodgers returns on his target date of December 24, it will have been 104 days from the day he ruptured his Achilles to the day he came back to the field.

## Dutch coalition talks delayed as officials hesitant to caucus with right-wing firebrand Wilders
 - [https://www.foxnews.com/world/dutch-coalition-talks-delayed-officials-hesitant-caucus-right-wing-firebrand-wilders](https://www.foxnews.com/world/dutch-coalition-talks-delayed-officials-hesitant-caucus-right-wing-firebrand-wilders)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T20:18:39+00:00

Talks of potential coalitions under a Geert Wilders-led Dutch parliament are taking longer than expected, as numerous politicians are reluctant to form a government with him.

## House Republicans anticipate vote to formalize Biden impeachment inquiry 'soon'
 - [https://www.foxnews.com/politics/house-republicans-anticipate-vote-formalize-biden-impeachment-inquiry-soon](https://www.foxnews.com/politics/house-republicans-anticipate-vote-formalize-biden-impeachment-inquiry-soon)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T20:17:39+00:00

Multiple House Republican lawmakers indicated that a vote to formalize the impeachment inquiry of President Biden could happen &quot;soon&quot; before the House recesses.

## AMLO announces 20% hike in Mexico's minimum wage
 - [https://www.foxnews.com/world/amlo-announces-20-hike-mexicos-minimum-wage](https://www.foxnews.com/world/amlo-announces-20-hike-mexicos-minimum-wage)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T20:16:57+00:00

Left-wing Mexican President Andrés Manuel López Obrador announced Friday that the country&apos;s minimum wage will increase to about $1.75 per hour come Jan. 1.

## Number of nonbinary-identifying students spikes nearly 57% in West Coast state
 - [https://www.foxnews.com/media/number-nonbinary-identifying-students-spikes-57-west-coast-state](https://www.foxnews.com/media/number-nonbinary-identifying-students-spikes-57-west-coast-state)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T20:13:01+00:00

The number of students identifying as nonbinary in Oregon has increased every year since the state began including the third gender option, educational data show.

## Twitter Files co-author says censorship of social media was worse than he originally thought
 - [https://www.foxnews.com/media/twitter-files-co-author-says-censorship-social-media-worse-originally-thought](https://www.foxnews.com/media/twitter-files-co-author-says-censorship-social-media-worse-originally-thought)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T20:00:02+00:00

&quot;Twitter Files&quot; co-author Michael Shellenberger joined &quot;America&apos;s Newsroom&quot; after telling Congress government censorship is &quot;worse&quot; than initially thought.

## Brian Laundrie hired Wyoming lawyer who defended bin Laden bodyguard in Guantanamo
 - [https://www.foxnews.com/us/brian-laundrie-hired-wyoming-lawyer-who-defended-bin-laden-bodyguard-in-guantanamo](https://www.foxnews.com/us/brian-laundrie-hired-wyoming-lawyer-who-defended-bin-laden-bodyguard-in-guantanamo)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T19:58:58+00:00

Panicked Brian Laundrie had a Wyoming defense team in place well before his murdered fiancee Gabby Petito was reported missing, according to new court filings.

## Rep. Rosendale demands answers from Mayorkas on CBP document instructing agents to use preferred pronouns
 - [https://www.foxnews.com/politics/rep-rosendale-demands-answers-mayorkas-cbp-document-instructing-agents-use-preferred-pronouns](https://www.foxnews.com/politics/rep-rosendale-demands-answers-mayorkas-cbp-document-instructing-agents-use-preferred-pronouns)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T19:52:10+00:00

Rep. Rosendale presses U.S. DHS for answers on pronoun policy for border agents amid concerns over border security and priorities.

## These four House Dems voted 'present' or against expelling George Santos from Congress
 - [https://www.foxnews.com/politics/these-four-house-dems-voted-present-against-expelling-george-santos-congress](https://www.foxnews.com/politics/these-four-house-dems-voted-present-against-expelling-george-santos-congress)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T19:50:09+00:00

George Santos was expelled from Congress on Friday after a short-lived, controversial tenure. But two Democrats voted against removing him from office.

## Dead longhorn found in front yard of Oklahoma State fraternity ahead of Big 12 Championship Game
 - [https://www.foxnews.com/sports/dead-longhorn-found-front-yard-oklahoma-state-fraternity-ahead-big-12-championship-game](https://www.foxnews.com/sports/dead-longhorn-found-front-yard-oklahoma-state-fraternity-ahead-big-12-championship-game)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T19:43:45+00:00

A dead longhorn cow was found in front of an Oklahoma State University fraternity ahead of the Big 12 Championship Game between OSU and Texas.

## Madagascar high court ratifies president's controversial re-election win
 - [https://www.foxnews.com/world/madagascar-high-court-ratifies-presidents-controversial-re-election-win](https://www.foxnews.com/world/madagascar-high-court-ratifies-presidents-controversial-re-election-win)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T19:42:17+00:00

Malagasy President Andry Rajoelina&apos;s re-election was ratified by his country&apos;s top court Friday — a landslide win after opposition candidates urged supporters to boycott the vote.

## UMich grad sues state after losing 'G0BLUE' vanity plates
 - [https://www.foxnews.com/us/umich-grad-sues-state-losing-g0blue-vanity-plates](https://www.foxnews.com/us/umich-grad-sues-state-losing-g0blue-vanity-plates)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T19:40:50+00:00

University of Michigan graduate Joseph Hardig III, 65, of suburban Detroit, is suing the state over the reassignment of his long-held &quot;G0BLUE&quot; vanity plate number.

## Another GOP candidate enters crowded primary for Michigan Sen. Stabenow's seat
 - [https://www.foxnews.com/politics/another-gop-candidate-enters-crowded-primary-michigan-sen-stabenows-seat](https://www.foxnews.com/politics/another-gop-candidate-enters-crowded-primary-michigan-sen-stabenows-seat)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T19:39:07+00:00

Republican businessman Sandy Pensler has announced his candidacy for the U.S. Senate seat being vacated next year by four-term Democratic incumbent Debbie Stabenow.

## Armed group kills 11 in eastern Iraq
 - [https://www.foxnews.com/world/armed-group-kills-11-eastern-iraq](https://www.foxnews.com/world/armed-group-kills-11-eastern-iraq)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T19:37:38+00:00

A group brandishing firearms and explosives reportedly killed 11 people in the Muqdadiyah area of Iraq&apos;s Diyala province on Thursday night.

## Comer, Jordan demand Hunter Biden appear for deposition, say he will not receive 'special treatment'
 - [https://www.foxnews.com/politics/comer-jordan-demand-hunter-biden-appear-deposition-not-receive-special-treatment](https://www.foxnews.com/politics/comer-jordan-demand-hunter-biden-appear-deposition-not-receive-special-treatment)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T19:30:23+00:00

FIRST ON FOX: House Oversight Committee Chairman James Comer and House Judiciary Committee Chairman Jim Jordan demanded Hunter Biden appear for his deposition in December

## The Robertson clan is hunting for life’s biggest treasures in new episodes of ‘Duck Family Treasure’
 - [https://www.foxnews.com/media/robertson-clan-hunting-lifes-biggest-treasures-new-episodes-duck-family-treasure](https://www.foxnews.com/media/robertson-clan-hunting-lifes-biggest-treasures-new-episodes-duck-family-treasure)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T19:19:31+00:00

The beloved Robertson family is back with more episodes of &apos;Duck Family Treasure&apos; available exclusively to FOX Nation subscribers.

## Joe Manchin goes scorched-earth on Biden admin over EV actions boosting China
 - [https://www.foxnews.com/politics/joe-manchin-goes-scorched-earth-biden-admin-ev-actions-boosting-china](https://www.foxnews.com/politics/joe-manchin-goes-scorched-earth-biden-admin-ev-actions-boosting-china)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T19:04:32+00:00

Democratic West Virginia Sen. Joe Manchin is blasting the Biden administration and accusing it of breaking the law after the Treasury Department released electric vehicle guidance.

## Climate activists interrupt opera performance, angering audience: 'Shut up!'
 - [https://www.foxnews.com/media/climate-activists-interrupt-opera-performance-angering-audience-shut-up](https://www.foxnews.com/media/climate-activists-interrupt-opera-performance-angering-audience-shut-up)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T18:58:06+00:00

Climate activists angered a New York City opera audience Thursday, for disrupting an opening night performance, saying there would &quot;be no opera on a dead planet.&quot;

## Reagan historian looks back at historic O'Connor appointment: 'most qualified'
 - [https://www.foxnews.com/politics/reagan-historian-looks-back-historic-oconnor-appointment-most-qualified](https://www.foxnews.com/politics/reagan-historian-looks-back-historic-oconnor-appointment-most-qualified)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T18:41:21+00:00

Sandra Day O&apos;Connor was &quot;the most qualified woman&quot; President Reagan &quot;could possibly find&quot; to serve as the first woman on the U.S. Supreme Court in 1981.

## Biden campaign has 'massive failure of messaging,' especially 'Bidenomics': Liberal NY Times columnist
 - [https://www.foxnews.com/media/biden-campaign-massive-failure-messaging-especially-bidenomics-liberal-ny-times-columnist](https://www.foxnews.com/media/biden-campaign-massive-failure-messaging-especially-bidenomics-liberal-ny-times-columnist)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T18:37:54+00:00

New York Times opinion columnist Charles Blow hammered President Biden&apos;s campaign for “disastrous branding&quot; and bad messaging, especially on the economy.

## Majority of Americans say China is greatest national security threat, up 30 points in five years
 - [https://www.foxnews.com/media/majority-americans-say-china-greatest-national-security-threat-30-points-five-years](https://www.foxnews.com/media/majority-americans-say-china-greatest-national-security-threat-30-points-five-years)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T18:22:41+00:00

A Reagan National Defense Survey found a growing number of Americans believe China is an &quot;enemy&quot; of the United States, rather than an ally.

## Finnish hockey star, Olympian Sanni Hakala paralyzed from chest down after in-game collision
 - [https://www.foxnews.com/sports/olympic-hockey-star-sanni-hakala-paralyzed-after-collision](https://www.foxnews.com/sports/olympic-hockey-star-sanni-hakala-paralyzed-after-collision)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T18:12:56+00:00

Two-time Olympian Sanni Hakala revealed that she is paralyzed from the chest down after a scary collision during a recent Swedish Women&apos;s Hockey League game.

## Bus driver who claimed to accidentally eat THC gummies, pass out on highway granted probation
 - [https://www.foxnews.com/us/bus-driver-claimed-accidentally-eat-thc-gummies-pass-highway-granted-probation](https://www.foxnews.com/us/bus-driver-claimed-accidentally-eat-thc-gummies-pass-highway-granted-probation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T18:06:02+00:00

A bus driver in Bridgeport, Connecticut, has been offered a two-year probation program after saying he accidentally ingested THC gummies while driving on the interstate.

## Kelly Clarkson's ex Brandon Blackstock ordered to pay her $2.6 million for ‘unlawful’ business deals
 - [https://www.foxnews.com/entertainment/kelly-clarksons-ex-brandon-blackstock-ordered-pay-2-6-million-unlawful-business-deals](https://www.foxnews.com/entertainment/kelly-clarksons-ex-brandon-blackstock-ordered-pay-2-6-million-unlawful-business-deals)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T18:04:07+00:00

&quot;Since You&apos;ve Been Gone&quot; singer Kelly Clarkson is involved in a legal battle with her ex-husband, Brandon Blackstock, who now owes her more than $2.6 million.

## 'Toughest uphill climb': Race forecaster reveals shift toward GOP in top 2024 Senate race
 - [https://www.foxnews.com/politics/toughest-uphill-climb-forecaster-shift-toward-gop-2024-senate-race](https://www.foxnews.com/politics/toughest-uphill-climb-forecaster-shift-toward-gop-2024-senate-race)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T18:01:27+00:00

Cook Political Report adjusted the blue Montana Senate race, a seat currently held by Democrat Sen. Jon Tester, from &quot;Lean Democrat&quot; to a &quot;Toss Up.&quot;

## Indiana teen lured to death by neighbor who hired her, ‘acted like a jealous boyfriend’: report
 - [https://www.foxnews.com/us/indiana-teen-lured-death-neighbor-who-hired-her-acted-jealous-boyfriend-report](https://www.foxnews.com/us/indiana-teen-lured-death-neighbor-who-hired-her-acted-jealous-boyfriend-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T17:55:52+00:00

Patrick Scott, 59, faces murder charges after 17-year-old Valerie Tindall&apos;s body was found buried in a homemade box on his property. The neighbor reportedly hired Tindall to mow lawns.

## Newt Gingrich roasts John Kerry's climate conference trip: 'Deeply committed to taking your money'
 - [https://www.foxnews.com/media/newt-gingrich-roasts-john-kerry-climate-conference-trip-deeply-committed-taking-money](https://www.foxnews.com/media/newt-gingrich-roasts-john-kerry-climate-conference-trip-deeply-committed-taking-money)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T17:51:33+00:00

Former House Speaker Newt Gingrich reacts to John Kerry&apos;s trip to the COP28 climate conference in Dubai, calling it a &quot;ripoff&quot; of workers across the world.

## Long-distance date ideas that will bring you together even when you're far apart
 - [https://www.foxnews.com/lifestyle/long-distance-date-ideas](https://www.foxnews.com/lifestyle/long-distance-date-ideas)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T17:47:01+00:00

Long-distance dating can be challenging, but it also opens the door for extra creativity when planning things to do together. Try these activities during your next date night.

## Jussie Smollett conviction upheld by Illinois appeals court
 - [https://www.foxnews.com/entertainment/jussie-smollett-conviction-upheld-illinois-appeals-court](https://www.foxnews.com/entertainment/jussie-smollett-conviction-upheld-illinois-appeals-court)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T17:44:22+00:00

&quot;Empire&quot; actor Jussie Smollet had his conviction upheld by an Illinois appeals court after he staged a hate crime and filed a false police report to the Chicago Police Department

## 'Killers of the Flower Moon' named best film of the year by NY critics group
 - [https://www.foxnews.com/entertainment/killers-flower-moon-named-best-film-year-ny-critics-group](https://www.foxnews.com/entertainment/killers-flower-moon-named-best-film-year-ny-critics-group)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T17:29:04+00:00

The New York Film Critics Circle has chosen Martin Scorsese&apos;s &apos;Killers of the Flower Moon&apos; as the Best Film of the Year. The Apple Studios production is based on a bestseller.

## Ugandan woman, 70, welcomes twins after receiving IVF fertility treatment
 - [https://www.foxnews.com/world/ugandan-woman-70-welcomes-twins-receiving-ivf-fertility-treatment](https://www.foxnews.com/world/ugandan-woman-70-welcomes-twins-receiving-ivf-fertility-treatment)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T17:27:22+00:00

A 70-year-old woman in Uganda has given birth to twins after undergoing in vitro fertilization (IVF) treatment. Breakthroughs in IVF research are seeing improved success rates.

## Taylor Swift's rep shuts down rumor singer secretly married Joe Alwyn
 - [https://www.foxnews.com/entertainment/taylor-swifts-rep-shuts-down-rumor-singer-secretly-married-joe-alwyn](https://www.foxnews.com/entertainment/taylor-swifts-rep-shuts-down-rumor-singer-secretly-married-joe-alwyn)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T17:18:12+00:00

Taylor Swift&apos;s representative shut down the long-standing rumor that the &quot;Midnights&quot; singer secretly married her now ex-boyfriend Joe Alwyn. They dated for six years before splitting in March.

## IN police officer fatally shoots man found on top of bleeding woman in semitruck
 - [https://www.foxnews.com/us/in-police-officer-fatally-shoots-man-found-top-bleeding-woman-semitruck](https://www.foxnews.com/us/in-police-officer-fatally-shoots-man-found-top-bleeding-woman-semitruck)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T17:09:44+00:00

An Indiana police officer fatally shot a man who was allegedly holding down a bleeding woman inside a semitruck. A bystander reported that the woman was calling for help.

## 'Jeopardy!' fans dumbfounded when contestants can't recognize legendary rockers: 'A complete societal failure'
 - [https://www.foxnews.com/entertainment/jeopardy-fans-dumbfounded-contestants-fail-recognize-legendary-rockers](https://www.foxnews.com/entertainment/jeopardy-fans-dumbfounded-contestants-fail-recognize-legendary-rockers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T17:05:54+00:00

&quot;Jeopardy!&quot; contestants were not able to answer a clue about rock band Led Zeppelin during a recent episode of the game show, and fans responded with outrage.

## Legendary rock band Kiss to give final performances this weekend at Madison Square Garden
 - [https://www.foxnews.com/entertainment/rock-band-kiss-give-final-performances-weekend-madison-square-garden](https://www.foxnews.com/entertainment/rock-band-kiss-give-final-performances-weekend-madison-square-garden)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T17:00:27+00:00

After 50 years, the legendary rock band Kiss will give its final performances on Friday and Saturday at Madison Square Garden. Here is a look at how the band has evolved over the years.

## GOP senators call for China travel ban to prevent mystery illness spread
 - [https://www.foxnews.com/us/gop-senators-call-china-travel-ban-prevent-mystery-illness-spread](https://www.foxnews.com/us/gop-senators-call-china-travel-ban-prevent-mystery-illness-spread)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T16:59:25+00:00

Five senators have demanded that President Biden puts in place a travel ban on China due to an alarming spike in an unknown respiratory illness.

## Fox News Channel’s ‘Hannity’ to host town hall with former President Trump on December 5
 - [https://www.foxnews.com/media/hannity-host-town-hall-former-president-trump-december-5](https://www.foxnews.com/media/hannity-host-town-hall-former-president-trump-december-5)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T16:58:05+00:00

Sean Hannity will host a town hall with former President Donald Trump in Davenport, Iowa on Fox News Channel on Tuesday, Dec. 5 at 9 p.m. ET.

## Trump reacts to DeSantis, Newsom at Red State vs Blue State debate: 'Both worked hard'
 - [https://www.foxnews.com/politics/trump-reacts-desantis-newsom-red-state-vs-blue-state-debate-both-worked-hard](https://www.foxnews.com/politics/trump-reacts-desantis-newsom-red-state-vs-blue-state-debate-both-worked-hard)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T16:53:57+00:00

EXCLUSIVE: Former President Trump reacted to the debate between Florida Gov. Ron DeSantis and California Gov. Gavin Newsom, telling Fox News Digital he thinks “they both worked hard and they both did well.&quot;

## By kicking out Santos, GOP reminds Americans there are consequences for doing wrong … sometimes
 - [https://www.foxnews.com/opinion/kicking-santos-gop-reminds-americans-consequences-doing-wrong-sometimes](https://www.foxnews.com/opinion/kicking-santos-gop-reminds-americans-consequences-doing-wrong-sometimes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T16:53:54+00:00

In just 35 years, American ethical and moral standards have fallen and citizens now distrust all major institutions. GOP expulsion of Santos is a sign things might get better.

## 'Too massive for its star': Scientists discover enormous planet that changes what we know about red dwarfs
 - [https://www.foxnews.com/science/too-massive-star-scientists-discover-enormous-planet-changes-know-red-dwarfs](https://www.foxnews.com/science/too-massive-star-scientists-discover-enormous-planet-changes-know-red-dwarfs)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T16:35:39+00:00

Scienstists have discovered a planet circling a a red dwarf. The enormous mass of the planet compared to its host star is forcing scientists to reconsider current theories.

## Louisville freshman barely plays in first half due to not having ‘tights that he wanted,’ coach says
 - [https://www.foxnews.com/sports/louisville-freshman-barely-plays-first-half-due-not-having-tights-he-wanted-coach-says](https://www.foxnews.com/sports/louisville-freshman-barely-plays-first-half-due-not-having-tights-he-wanted-coach-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T16:25:43+00:00

Louisville head coach Kenny Payne said freshman guard Ty-Laur Johnson barely played in the first half against Bellarmine due to not having the &quot;tights that he wanted.&quot;

## Newsom and Biden share weak polling numbers, but not the president’s biggest vulnerability
 - [https://www.foxnews.com/politics/newsom-biden-share-weak-polling-numbers-not-presidents-biggest-vulnerability](https://www.foxnews.com/politics/newsom-biden-share-weak-polling-numbers-not-presidents-biggest-vulnerability)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T16:20:28+00:00

Recent polling numbers reveal that California Democratic Governor Gavin Newsom shares weak levels of support with President Joe Biden across the board.

## Trump is not immune from civil lawsuits related to Jan. 6, federal appeals court rules
 - [https://www.foxnews.com/politics/trump-not-immune-civil-lawsuits-related-jan-6-federal-appeals-court-rules](https://www.foxnews.com/politics/trump-not-immune-civil-lawsuits-related-jan-6-federal-appeals-court-rules)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T16:10:34+00:00

A federal appeals court has ruled Friday that former President Donald Trump is not immune to facing civil lawsuits relating to the events on Jan. 6, 2021.

## Idaho baby abducted by 'heavily armed and dangerous' homicide suspect: authorities
 - [https://www.foxnews.com/us/idaho-baby-abducted-heavily-armed-dangerous-homicide-suspect-authorities](https://www.foxnews.com/us/idaho-baby-abducted-heavily-armed-dangerous-homicide-suspect-authorities)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T16:07:51+00:00

Idaho authorities are searching for Jeremy Best, a homicide and kidnapping suspect accused of abducting his son, Zeke Best, from a residence in Victor on Thursday.

## The real winner of DeSantis, Newsom debate, Walt Disney's wisdom, and more from Fox News Opinion
 - [https://www.foxnews.com/opinion/real-winner-desantis-newsom-debate-walt-disney-wisdom-more-fox-news-opinion](https://www.foxnews.com/opinion/real-winner-desantis-newsom-debate-walt-disney-wisdom-more-fox-news-opinion)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T16:02:14+00:00

Read the latest from Fox News Opinion &amp; watch videos from Sean Hannity, Raymond Arroyo &amp; more.

## Embattled GOP Rep. George Santos expelled from House
 - [https://www.foxnews.com/politics/embattled-gop-rep-george-santos-expelled-from-house](https://www.foxnews.com/politics/embattled-gop-rep-george-santos-expelled-from-house)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T16:01:30+00:00

Rep. George Santos, D-N.Y., was expelled from the House on Friday after being charged with nearly two dozen federal counts, including identity theft and falsification of records.

## How to find any recipe with just a photo on iPhone
 - [https://www.foxnews.com/tech/how-to-find-any-recipe-with-just-photo-on-iphone](https://www.foxnews.com/tech/how-to-find-any-recipe-with-just-photo-on-iphone)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T16:00:50+00:00

The iPhone uses Visual Look Up technology that allows phone users to search for and find recipes using only a photo. Kurt &quot;CyberGuy&quot; Knutsson explains.

## GA county officials seek to dismiss lawsuit filed by slave descendants fighting against zoning changes
 - [https://www.foxnews.com/us/ga-county-officials-seek-dismiss-lawsuit-filed-slave-descendants-fighting-against-zoning-changes](https://www.foxnews.com/us/ga-county-officials-seek-dismiss-lawsuit-filed-slave-descendants-fighting-against-zoning-changes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T15:55:10+00:00

Georgia county officials face a lawsuit from Black residents in an island community. The residents, descended from slaves, fear new zoning will force them to sell their homes.

## US watchdog investigates Biden administration's site selection for new FBI headquarters
 - [https://www.foxnews.com/us/us-watchdog-investigates-biden-administrations-site-selection-new-fbi-headquarters](https://www.foxnews.com/us/us-watchdog-investigates-biden-administrations-site-selection-new-fbi-headquarters)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T15:42:39+00:00

A federal watchdog is investigating the decision-making process behind the selected site for a new FBI headquarters, which has faced allegations of a conflict of interest.

## Israel-Hamas war: Israeli authorities announce 3 hostages taken into Gaza are dead
 - [https://www.foxnews.com/world/israel-hamas-war-israeli-authorities-announce-3-hostages-taken-into-gaza-dead](https://www.foxnews.com/world/israel-hamas-war-israeli-authorities-announce-3-hostages-taken-into-gaza-dead)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T15:32:40+00:00

Authorities of the Israeli border community Kibbutz Nir-Oz announced three residents who were taken by Hamas terrorists during the Oct. 7 attack have died in Hamas captivity.

## Julianna Margulies says NY Times 'sat' on her op-ed about antisemitism before going to USA Today
 - [https://www.foxnews.com/media/julianna-margulies-says-ny-times-sat-on-op-ed-antisemitism-before-going-usa-today](https://www.foxnews.com/media/julianna-margulies-says-ny-times-sat-on-op-ed-antisemitism-before-going-usa-today)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T15:29:54+00:00

&quot;The Good Wife&quot; star Julianna Margulies revealed she butted heads with The New York Times over an op-ed she penned about antisemitism, accusing the paper of sitting on it for a week.

## As childhood pneumonia spreads, here’s what parents can do to keep their kids healthy
 - [https://www.foxnews.com/health/childhood-pneumonia-spreads-heres-what-parents-can-do-keep-kids-healthy](https://www.foxnews.com/health/childhood-pneumonia-spreads-heres-what-parents-can-do-keep-kids-healthy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T15:21:13+00:00

With some U.S. states now reporting outbreaks of childhood pneumonia cases, health experts share tips and insights for parents to prevent the illness from making its way into their households.

## Homeless suspect in Hollywood activist murder warned 'My Glock is loaded': court docs
 - [https://www.foxnews.com/us/homeless-suspect-hollywood-activist-murder-warned-my-glock-loaded-court-docs](https://www.foxnews.com/us/homeless-suspect-hollywood-activist-murder-warned-my-glock-loaded-court-docs)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T15:13:49+00:00

Suspect in home invasion murder of progressive social justice activist Michael Latt had no home but did own a gun, Los Angeles court documents reveal.

## Sandra Day O'Connor, former Supreme Court Justice, dead at 93
 - [https://www.foxnews.com/politics/sandra-day-oconnor-former-supreme-court-justice-dead-93](https://www.foxnews.com/politics/sandra-day-oconnor-former-supreme-court-justice-dead-93)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T15:09:45+00:00

Retired Supreme Court Associate Justice Sandra Day O&apos;Connor has died of complications from dementia, most likely Alzheimer&apos;s, and a respiratory illness, the Supreme Court said Friday.

## Las Vegas man indicted for antisemitic threats against US Sen. Jacky Rosen
 - [https://www.foxnews.com/us/las-vegas-man-indicted-antisemitic-threats-against-us-sen-jacky-rosen](https://www.foxnews.com/us/las-vegas-man-indicted-antisemitic-threats-against-us-sen-jacky-rosen)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T15:09:27+00:00

A federal jury has indicted John Miller, a Las Vegas man arrested last month, for making antisemitic threats against U.S. Sen. Jacky Rosen. The Democrat says she was targeted.

## Chicago police officer fired, charged for fake story about being robbed of $5k at gunpoint
 - [https://www.foxnews.com/us/chicago-police-officer-fired-charged-fake-story-robbed-5k-at-gunpoint](https://www.foxnews.com/us/chicago-police-officer-fired-charged-fake-story-robbed-5k-at-gunpoint)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T15:03:12+00:00

A Chicago police officer has been fired from her job and is facing charges after she allegedly reported a fake story of her being robbed of $5,000 at gunpoint.

## Ukraine to receive NATO support for 'as long as it takes,' gain alliance membership after conflict
 - [https://www.foxnews.com/world/ukraine-receive-nato-support-long-takes-gain-alliance-membership-conflict](https://www.foxnews.com/world/ukraine-receive-nato-support-long-takes-gain-alliance-membership-conflict)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T14:56:44+00:00

The North Atlantic Treaty Organization pledged Wednesday to continue support of Ukraine in its defensive war against Russia for &quot;as long as it takes.&quot;

## Death penalty is increasingly seen by Americans as being 'unfairly' administered, Gallup report finds
 - [https://www.foxnews.com/us/death-penalty-increasingly-americans-being-unfairly-administered-gallup-report-finds](https://www.foxnews.com/us/death-penalty-increasingly-americans-being-unfairly-administered-gallup-report-finds)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T14:54:25+00:00

An annual report on capital punishment says more Americans now believe the death penalty is administered unfairly. The report says a Gallup poll from October that found 50% of Americans believe capital punishment is applied unfairly is another sign of the death penalty&apos;s further isolation in the U.S.

## Senate Dems say any changes to asylum system must be coupled with amnesty for illegal immigrants
 - [https://www.foxnews.com/politics/democrats-fume-at-prospect-of-harmful-limits-to-asylum-claims-as-part-of-supplemental-funding-deal](https://www.foxnews.com/politics/democrats-fume-at-prospect-of-harmful-limits-to-asylum-claims-as-part-of-supplemental-funding-deal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T14:30:34+00:00

Senate Democrats are warning of what they say would be &quot;harmful&quot; changes to the U.S. asylum system as part of funding talks, saying that permanent changes must be coupled by amnesty.

## US Marine admits to firebombing California Planned Parenthood clinic
 - [https://www.foxnews.com/us/us-marine-admits-firebombing-california-planned-parenthood-clinic](https://www.foxnews.com/us/us-marine-admits-firebombing-california-planned-parenthood-clinic)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T14:28:23+00:00

A former U.S. Marine has pleaded guilty in federal court to firebombing a Planned Parenthood clinic in Southern California in 2022. Chance Brannon, 24, conspired with two others.

## Arizona lawmaker calls for National Guard deployment to handle Tucson migrant surge: 'Overrun and undermanned'
 - [https://www.foxnews.com/politics/arizona-lawmaker-calls-national-guard-deployment-handle-tucson-migrant-surge](https://www.foxnews.com/politics/arizona-lawmaker-calls-national-guard-deployment-handle-tucson-migrant-surge)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T14:27:52+00:00

Rep. Juan Ciscomani is calling for DHS to request the deployment of the Arizona National Guard to the southern border to help authorities deal with a surge in the Tucson Sector.

## Felicity Huffman says she ‘had to break law’ in college admissions scandal to ‘give my daughter a future’
 - [https://www.foxnews.com/entertainment/felicity-huffman-break-law-college-admissions-scandal-daughter-future](https://www.foxnews.com/entertainment/felicity-huffman-break-law-college-admissions-scandal-daughter-future)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T14:25:52+00:00

Oscar-nominated actress Felicity Huffman broke her silence about her involvement in the &quot;Operation Varsity Blues&quot; college admissions scandal.

## Western Massachusetts reports RSV uptick as child pneumonia outbreak hits Ohio
 - [https://www.foxnews.com/health/western-massachusetts-reports-rsv-uptick-child-pneumonia-outbreak-hits-ohio](https://www.foxnews.com/health/western-massachusetts-reports-rsv-uptick-child-pneumonia-outbreak-hits-ohio)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T14:20:08+00:00

An uptick in RSV cases is happening in western Massachusetts, leading some children to suffer from mild cases of pneumonia, according to a report.

## LSU star Angel Reese returns to game action after mysterious absence: ‘I am human’
 - [https://www.foxnews.com/sports/lsu-star-angel-reese-returns-game-action-mysterious-absence-i-am-human](https://www.foxnews.com/sports/lsu-star-angel-reese-returns-game-action-mysterious-absence-i-am-human)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T14:18:16+00:00

LSU star Angel Reese returned to game action Thursday night against Virginia Tech after missing the past four games for unknown reasons.

## Former Wisconsin Attorney General Brad Schimel announces candidacy for state Supreme Court race in 2025
 - [https://www.foxnews.com/politics/former-wisconsin-attorney-general-brad-schimel-announces-candidacy-state-supreme-court-race-2025](https://www.foxnews.com/politics/former-wisconsin-attorney-general-brad-schimel-announces-candidacy-state-supreme-court-race-2025)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T14:15:04+00:00

Former Wisconsin Attorney General Brad Schimel has announced his candidacy for state Supreme Court in 2025. Schimel challenges incumbent Justice Ann Walsh Bradley.

## Hamas terrorists branded Israeli children hostages in case they escaped, relative says
 - [https://www.foxnews.com/world/hamas-terrorists-branded-israeli-children-hostages-case-escaped-relative](https://www.foxnews.com/world/hamas-terrorists-branded-israeli-children-hostages-case-escaped-relative)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T14:13:42+00:00

The family members of released Israeli hostages continue to detail gruesome conditions under Hamas captivity in Gaza, including terrorists beating, drugging, and even branding children.

## House passes bill to stop federal funds being used to house illegal immigrants
 - [https://www.foxnews.com/politics/house-passes-bill-stop-federal-funds-used-house-illegal-immigrants](https://www.foxnews.com/politics/house-passes-bill-stop-federal-funds-used-house-illegal-immigrants)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T14:05:51+00:00

Legislation that would stop federal funds from being used to house illegal immigrants on land controlled by the federal government passed the House on Thursday.

## Amazon holiday deals: 15 gifts that cost less than $100
 - [https://www.foxnews.com/lifestyle/amazon-perfect-gift-ideas-under-100](https://www.foxnews.com/lifestyle/amazon-perfect-gift-ideas-under-100)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T14:01:46+00:00

Find the perfect gift for anyone on your list for under $100 this holiday season on Amazon.

## US poised to impose travel bans on Israelis engaging in violence, official tells AP
 - [https://www.foxnews.com/world/us-poised-impose-travel-bans-israelis-engaging-violence-official-tells-ap](https://www.foxnews.com/world/us-poised-impose-travel-bans-israelis-engaging-violence-official-tells-ap)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T13:59:05+00:00

The U.S. Department of State is reportedly seeking to issue travel bans on Israeli settlers responsible for violence against Palestinians in the West Bank.

## Portland city council approves $2.6 million to equip police with body cameras
 - [https://www.foxnews.com/us/portland-city-council-approves-2-6-million-equip-police-body-cameras](https://www.foxnews.com/us/portland-city-council-approves-2-6-million-equip-police-body-cameras)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T13:46:04+00:00

The Portland City Council has unanimously approved $2.6 million for permanent police body cameras. All 800 uniformed officers are expected to have body-worn cameras by summer.

## Ilhan Omar, Ro Khanna blast MSNBC canceling Mehdi Hasan's show as Israel-Hamas war unfolds: 'Deeply troubling'
 - [https://www.foxnews.com/media/ilhan-omar-ro-khanna-blast-msnbc-canceling-mehdi-hasans-show-israel-hamas-war-unfolds-deeply-troubling](https://www.foxnews.com/media/ilhan-omar-ro-khanna-blast-msnbc-canceling-mehdi-hasans-show-israel-hamas-war-unfolds-deeply-troubling)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T13:45:32+00:00

Reps. Ilhan Omar and Ro Khanna are among prominent progressives slamming MSNBC&apos;s decision to pull far-left host Mehdi Hasan&apos;s program from its weekend schedule.

## Georgia Republicans push forward with redistricting plans by advancing new legislative maps
 - [https://www.foxnews.com/politics/georgia-republicans-push-forward-redistricting-plans-advancing-new-legislative-maps](https://www.foxnews.com/politics/georgia-republicans-push-forward-redistricting-plans-advancing-new-legislative-maps)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T13:29:45+00:00

Georgia Republicans are advancing new legislative maps that would secure majorities in the state House. The redrawing of Georgia&apos;s 14 congressional districts remains undisclosed.

## Calf of humpback whale 'Smiley' delights Seattle residents with Elliott Bay visit
 - [https://www.foxnews.com/us/calf-humpback-whale-smiley-delights-seattle-residents-elliott-bay-visit](https://www.foxnews.com/us/calf-humpback-whale-smiley-delights-seattle-residents-elliott-bay-visit)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T13:22:41+00:00

A humpback whale, identified as the calf of an adult female known as &quot;Smiley,&quot; visited onlookers in Seattle by breaching for about 40 minutes on Thursday.

## Amid childhood pneumonia outbreaks, infectious diseases expert reveals key facts about ‘white lung syndrome’
 - [https://www.foxnews.com/health/childhood-pneumonia-outbreaks-infectious-diseases-expert-shares-white-lung-syndrome](https://www.foxnews.com/health/childhood-pneumonia-outbreaks-infectious-diseases-expert-shares-white-lung-syndrome)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T13:17:51+00:00

As childhood pneumonia outbreaks begin to crop up in regions around the U.S., an infectious diseases experts weighs in on possible causes and risks and presents key facts.

## Mother to charge family members nearly $200 each for Christmas dinner: 'Everything I do is for profit'
 - [https://www.foxnews.com/media/mother-charge-family-members-200-christmas-dinner-everything-profit](https://www.foxnews.com/media/mother-charge-family-members-200-christmas-dinner-everything-profit)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T13:13:47+00:00

Carla Bellucci, a British mother and former model made headlines when she announced she would be charging relatives money to host them for Christmas dinner.

## As Biden’s border disintegrates, Texas Democrats plot with Mexico
 - [https://www.foxnews.com/opinion/bidens-border-disintegrates-texas-democrats-plot-mexico](https://www.foxnews.com/opinion/bidens-border-disintegrates-texas-democrats-plot-mexico)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T13:00:51+00:00

With Biden&apos;s border crisis showing no signs of abating, Texas is passing new laws, including one that lets state and local authorities to arrest and order to return to Mexico would-be migrants.

## LeBron James will miss Lakers game for Bronny’s USC debut if necessary: ‘Family over everything’
 - [https://www.foxnews.com/sports/lebron-james-will-miss-lakers-game-bronnys-usc-debut-necessary-family-over-everything](https://www.foxnews.com/sports/lebron-james-will-miss-lakers-game-bronnys-usc-debut-necessary-family-over-everything)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T12:56:53+00:00

Los Angeles Lakers star LeBron James told reporters Thursday that he will miss a Lakers game if it conflicts with Bronny James&apos; college basketball debut.

## Fox News ‘Antisemitism Exposed’ Newsletter: Social media platforms 'hijacked' by hate after Oct. 7
 - [https://www.foxnews.com/us/fox-news-antisemitism-exposed-newsletter-social-media-platforms-hijacked-hate-oct-7](https://www.foxnews.com/us/fox-news-antisemitism-exposed-newsletter-social-media-platforms-hijacked-hate-oct-7)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T12:36:40+00:00

Fox News&apos; &quot;Antisemitism Exposed&quot; newsletter brings you stories on the rising anti-Jewish prejudice across the U.S. and the world.

## KY State Rep. Kevin Bratcher announces run for Louisville Metro Council seat
 - [https://www.foxnews.com/politics/ky-state-rep-kevin-bratcher-announces-run-louisville-metro-council-seat](https://www.foxnews.com/politics/ky-state-rep-kevin-bratcher-announces-run-louisville-metro-council-seat)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T12:18:53+00:00

Kentucky State Rep. Kevin Bratcher has declared his intention to run for a Louisville Metro Council seat in 2024. He currently chairs a committee overseeing election legislation.

## Gov. Kemp rips Biden for honoring slain 'Cop City' activist who allegedly shot Georgia officer: 'Disgraceful'
 - [https://www.foxnews.com/media/gov-kemp-rips-biden-honoring-slain-cop-city-activist-allegedly-shot-georgia-officer-disgraceful](https://www.foxnews.com/media/gov-kemp-rips-biden-honoring-slain-cop-city-activist-allegedly-shot-georgia-officer-disgraceful)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T12:00:23+00:00

Georgia Gov. Brian Kemp slammed the Biden administration for honoring an environmental activist who allegedly attacked Georgia officials, calling it &quot;disgraceful.&quot;

## Comer defends private deposition of Hunter Biden, vows to release transcript and hold public hearing
 - [https://www.foxnews.com/politics/comer-defends-private-deposition-hunter-biden-vows-release-transcript-hold-public-hearing](https://www.foxnews.com/politics/comer-defends-private-deposition-hunter-biden-vows-release-transcript-hold-public-hearing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T12:00:09+00:00

House Oversight Committee Chairman James Comer told Fox News Digital that Hunter Biden will have his chance to testify at a public hearing—but not before he sits for a deposition

## Indiana man faces murder charges in disappearance of 17-year-old neighbor
 - [https://www.foxnews.com/us/indiana-man-faces-murder-charges-disappearance-17-year-old-neighbor](https://www.foxnews.com/us/indiana-man-faces-murder-charges-disappearance-17-year-old-neighbor)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T11:54:05+00:00

An Indiana man has been charged with murder, obstruction of justice and false informing in the June disappearance of 17-year-old Valerie Tindall, his neighbor and employee.

## US Justice Department urged to investigate after foreign hackers breach Pennsylvania water supply
 - [https://www.foxnews.com/us/us-justice-department-urged-investigate-foreign-hackers-breach-pennsylvania-water-supply](https://www.foxnews.com/us/us-justice-department-urged-investigate-foreign-hackers-breach-pennsylvania-water-supply)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T11:49:01+00:00

Members of Congress have called on the U.S. Justice Department to investigate a cyberattack by on a Pennsylvania water utility. The hacking group is believed to be from Iran.

## Philippine coast guard constructs new surveillance base in the South China Sea to monitor Chinese vessels
 - [https://www.foxnews.com/world/philippine-coast-guard-constructs-new-surveillance-base-south-china-sea-monitor-chinese-vessels](https://www.foxnews.com/world/philippine-coast-guard-constructs-new-surveillance-base-south-china-sea-monitor-chinese-vessels)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T11:47:07+00:00

The Philippine coast guard has announced a new surveillance base on the Thitu Island in the South China Sea, in an effort to monitor China&apos;s aggressive behavior in the disputed waters.

## Israel publishes map of Gaza Strip zones to help civilians evacuate as fighting resumes
 - [https://www.foxnews.com/world/israel-publishes-map-gaza-strip-zones-help-civilians-evacuate-fighting-resumes](https://www.foxnews.com/world/israel-publishes-map-gaza-strip-zones-help-civilians-evacuate-fighting-resumes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T11:45:28+00:00

Israel’s military has published a map that it says will help civilians in the Gaza Strip reach safe areas if they are ordered to evacuate due to fighting.

## Heisman Trophy winner predicts 'salary cap' in college sports: 'Something's gotta give'
 - [https://www.foxnews.com/sports/heisman-trophy-winner-predicts-salary-cap-college-sports-somethings-gotta-give](https://www.foxnews.com/sports/heisman-trophy-winner-predicts-salary-cap-college-sports-somethings-gotta-give)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T11:45:19+00:00

Heisman Trophy winner Ty Detmer is a fan of college athletes profiting off their name, image and likeness, but he says it needs to be regulated a bit.

## Illegal immigrant charged for fatally shooting 2 Texas sisters
 - [https://www.foxnews.com/us/illegal-immigrant-charged-fatally-shooting-2-texas-sisters](https://www.foxnews.com/us/illegal-immigrant-charged-fatally-shooting-2-texas-sisters)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T11:39:57+00:00

Jose Santiago Chairez, an illegal immigrant, has been arrested for fatally shooting two sisters in their home in Dallas while he also allegedly shot his daughter.

## Top 5 moments of DeSantis-Newsom debate, fighting in Gaza resumes and more top headlines
 - [https://www.foxnews.com/us/top-5-moments-of-desantis-newsom-debate-fighting-in-gaza-resumes-and-more-top-headlines](https://www.foxnews.com/us/top-5-moments-of-desantis-newsom-debate-fighting-in-gaza-resumes-and-more-top-headlines)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T11:32:50+00:00

Get all the stories you need-to-know from the most powerful name in news delivered first thing every morning to your inbox.

## Julianna Margulies: College kids with ‘they/them’ pronouns supporting Hamas would be ‘beheaded’ in Gaza
 - [https://www.foxnews.com/media/julianna-margulies-college-kids-they-them-pronouns-supporting-hamas-would-be-beheaded-in-gaza](https://www.foxnews.com/media/julianna-margulies-college-kids-they-them-pronouns-supporting-hamas-would-be-beheaded-in-gaza)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T11:30:57+00:00

Emmy-winning actress Julianna Margulies slammed college students who have been marching in support of Hamas following the Oct. 7 terrorist attacks against Israel.

## Social media companies unprepared for Hamas 'hijacking' their platforms, tech expert says
 - [https://www.foxnews.com/media/social-media-companies-unprepared-hamas-hijacking-platforms-tech-expert-says](https://www.foxnews.com/media/social-media-companies-unprepared-hamas-hijacking-platforms-tech-expert-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T11:30:13+00:00

Hamas&apos; attack on Israel was the &quot;largest hijacking of social media platforms by a terrorist organization&quot; and companies still aren&apos;t prepared, a tech expert warned.

## ‘Zoom fatigue’ is a common struggle for remote workers. Here’s how to handle it, according to experts
 - [https://www.foxnews.com/health/zoom-fatigue-common-struggle-remote-workers-heres-how-handle-according-experts](https://www.foxnews.com/health/zoom-fatigue-common-struggle-remote-workers-heres-how-handle-according-experts)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T11:25:35+00:00

In the years since the pandemic triggered a spike in permanent telecommuting, many have complained of so-called “Zoom fatigue.&quot; Experts weigh in on the effects and prevention tips.

## Penguins goalie Tristan Jarry joins rare company after scoring unlikely goal
 - [https://www.foxnews.com/sports/penguins-goalie-tristan-jarry-joins-rare-company-scoring-unlikely-goal](https://www.foxnews.com/sports/penguins-goalie-tristan-jarry-joins-rare-company-scoring-unlikely-goal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T11:24:01+00:00

Pittsburgh Penguins goalie Tristan Jarry became just the 14th goalie to ever score a goal on Wednesday, and only the ninth to do it on his own shot.

## Panthers' Hayden Hurst defends rookie Bryce Young, praises leadership through rough season
 - [https://www.foxnews.com/sports/panthers-hayden-hurst-defends-rookie-bryce-young-praises-leadership-rough-season](https://www.foxnews.com/sports/panthers-hayden-hurst-defends-rookie-bryce-young-praises-leadership-rough-season)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T11:15:10+00:00

The Carolina Panthers are going through an adverse 2023 campaign, and tight end Hayden Hurst doesn&apos;t think blame needs to fall on rookie quarterback Bryce Young&apos;s shoulders.

## Ghost hacking: How to protect yourself from scams from beyond the grave of those you knew
 - [https://www.foxnews.com/tech/ghost-hacking-how-to-protect-yourself-from-scams-beyond-grave-those-you-knew](https://www.foxnews.com/tech/ghost-hacking-how-to-protect-yourself-from-scams-beyond-grave-those-you-knew)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T11:00:49+00:00

Scammers and hackers prey on those who are dead and their friends and families, especially on Facebook, according to Kurt &quot;CyberGuy&quot; Knutsson.

## Pac-12 Championship preview: Washington, Oregon meet again as teams bid farewell with CFP berth on the line
 - [https://www.foxnews.com/sports/pac-12-championship-preview-washington-oregon-meet-again-teams-bid-farewell-cfp-berth-line](https://www.foxnews.com/sports/pac-12-championship-preview-washington-oregon-meet-again-teams-bid-farewell-cfp-berth-line)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T11:00:37+00:00

No. 5 Oregon and No. 3 Washington square off Friday for the second time this season in the Pac-12 Championship Game as the conference reaches its end stages.

## Israel-Hamas war: Israeli warplanes carry out strikes across Gaza as cease-fire expires, offensive resumes
 - [https://www.foxnews.com/world/israel-hamas-war-israeli-warplanes-carry-strikes-across-gaza-cease-fire-expires-offensive-resumes](https://www.foxnews.com/world/israel-hamas-war-israeli-warplanes-carry-strikes-across-gaza-cease-fire-expires-offensive-resumes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T10:53:19+00:00

Israeli resumed its offensive against Hamas in Gaza after a temporary cease-fire expired on Friday. Its collapse came as both sides claim the other violated its terms.

## Jennifer Aniston, George Clooney, Kevin Bacon's early struggles before Hollywood fame
 - [https://www.foxnews.com/entertainment/jennifer-aniston-george-clooney-kevin-bacons-early-struggles-before-hollywood-fame](https://www.foxnews.com/entertainment/jennifer-aniston-george-clooney-kevin-bacons-early-struggles-before-hollywood-fame)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T10:30:49+00:00

Kevin Bacon recently discussed his early years as a struggling actor. Jennifer Aniston, George Clooney and Mariah Carey have also opened up about their journeys to fame.

## Former NBA star Chandler Parsons says league brought Miles Bridges back too soon: 'A man never hits a woman'
 - [https://www.foxnews.com/sports/former-nba-star-chandler-parsons-says-league-brought-miles-bridges-back-too-soon-a-man-never-hits-a-woman](https://www.foxnews.com/sports/former-nba-star-chandler-parsons-says-league-brought-miles-bridges-back-too-soon-a-man-never-hits-a-woman)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T10:30:48+00:00

Former NBA star Chandler Parsons said his piece on Miles Bridges, who returned to the Hornets following a domestic violence incident, that he isn&apos;t sure how Bridges is still playing.

## Disney indicts its woke self with founder’s own words in newly published book
 - [https://www.foxnews.com/opinion/disney-indicts-woke-self-founders-own-words-newly-published-book](https://www.foxnews.com/opinion/disney-indicts-woke-self-founders-own-words-newly-published-book)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T10:00:46+00:00

&quot;The Official Walt Disney Quote Book&quot; was compiled by the staff of the Walt Disney Archives – a division first established just four years after its founder’s death at the age of 65.

## Royal tell-all 'Endgame' is 'high camp' and nuts but it still works in one key way
 - [https://www.foxnews.com/opinion/royal-tell-all-endgame-high-camp-nuts-still-works-one-key-way](https://www.foxnews.com/opinion/royal-tell-all-endgame-high-camp-nuts-still-works-one-key-way)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T10:00:39+00:00

A new book on the British royal family was published this week. &quot;Endgame&quot; from author Omid Scobie makes wild claims but offers little evidence for them. Here&apos;s what we know

## Transgender runner complains about being 'slow' and 'out of shape' after winning women's half-marathon
 - [https://www.foxnews.com/media/transgender-runner-complains-being-slow-out-shape-after-winning-womens-half-marathon](https://www.foxnews.com/media/transgender-runner-complains-being-slow-out-shape-after-winning-womens-half-marathon)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T10:00:38+00:00

Transgender runner Kae Luci Ravichandran draws criticism after complaining about being &apos;out of shape&apos; after winning women&apos;s category in a New York half-marathon run.

## 'Twilight' star Kellan Lutz chose Nashville over Los Angeles for his family, 'you only have so much time'
 - [https://www.foxnews.com/entertainment/twilight-star-kellan-lutz-chose-nashville-over-los-angeles-family-you-only-have-so-much-time](https://www.foxnews.com/entertainment/twilight-star-kellan-lutz-chose-nashville-over-los-angeles-family-you-only-have-so-much-time)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T10:00:18+00:00

&quot;Twilight&quot; star Kellan Lutz shared secrets to his marriage with Fox News Digital, as well as why he moved his family to Nashville.

## Americans aren’t happier about Biden economy despite major media outlets telling them how good they have it
 - [https://www.foxnews.com/media/americans-arent-happier-about-biden-economy-despite-major-media-outlets-telling-them-how-good-they-have-it](https://www.foxnews.com/media/americans-arent-happier-about-biden-economy-despite-major-media-outlets-telling-them-how-good-they-have-it)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T10:00:13+00:00

Multiple media outlets and figures have insisted the U.S. economy is strong and claimed that those who don&apos;t recognize it aren&apos;t getting correct information.

## Depression and anxiety rates higher among college students than their peers, new study suggests
 - [https://www.foxnews.com/health/depression-anxiety-rates-higher-college-students-than-peers-study-suggests](https://www.foxnews.com/health/depression-anxiety-rates-higher-college-students-than-peers-study-suggests)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T09:45:58+00:00

College students may be at a greater risk of experiencing depression and anxiety compared to those not in higher education, according to a new study published in The Lancet Public Health.

## Teen used kitchen knife, pot in vicious triple murder after dad's date night: police
 - [https://www.foxnews.com/us/teen-used-kitchen-knife-pot-vicious-triple-murder-after-dads-date-night-police](https://www.foxnews.com/us/teen-used-kitchen-knife-pot-vicious-triple-murder-after-dads-date-night-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T09:34:10+00:00

The NYPD arrested and charged 19-year-old Jayden Rivera for the brutal triple stabbing that left the teen&apos;s dad, the dad&apos;s girlfriend and the couple&apos;s young son dead.

## More Hispanic voters realizing they’re conservative due to family and faith, Spanish-language radio star says
 - [https://www.foxnews.com/media/more-hispanic-voters-realizing-theyre-conservative-due-family-faith-spanish-language-radio-star-says](https://www.foxnews.com/media/more-hispanic-voters-realizing-theyre-conservative-due-family-faith-spanish-language-radio-star-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T09:30:31+00:00

Lourdes Ubieta believes Hispanic voters are finally realizing that their family values and emphasis on faith make them conservative... at least in the United States.

## Alaskan Native Americans unleash on Biden admin's climate agenda: 'Communities and culture are at risk'
 - [https://www.foxnews.com/politics/alaskan-native-americans-unleash-biden-admins-climate-agenda](https://www.foxnews.com/politics/alaskan-native-americans-unleash-biden-admins-climate-agenda)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T09:00:59+00:00

The Biden administration was criticized by tribal leaders in Alaska for its restrictions on fossil fuel development which provide a key source of revenue for their communities.

## Delivery drivers navigate holiday havoc as carjackers, robbers disrupt package rush
 - [https://www.foxnews.com/us/delivery-drivers-navigate-holiday-havoc-carjackers-robbers-disrupt-package-rush](https://www.foxnews.com/us/delivery-drivers-navigate-holiday-havoc-carjackers-robbers-disrupt-package-rush)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T09:00:47+00:00

Delivery drivers and postal workers face threats of robberies and carjackings this holiday season, with assaults of postal workers reportedly surging.

## Henry Kissinger’s friends, former colleagues reflect on his legacy: ‘A titanic figure’
 - [https://www.foxnews.com/politics/henry-kissingers-friends-former-colleagues-reflect-his-legacy-titanic-figure](https://www.foxnews.com/politics/henry-kissingers-friends-former-colleagues-reflect-his-legacy-titanic-figure)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T09:00:47+00:00

The legacy of esteemed diplomat Henry Kissinger, who died Wednesday at 100, includes praise for negotiation skills amid controversy, with colleagues lauding his brilliance, mentorship.

## 'Saved by the Bell' star Tiffani Thiessen 'fell in love' with ice plunging as she nears 50
 - [https://www.foxnews.com/entertainment/saved-by-the-bell-star-tiffani-thiessen-fell-love-ice-plunging-nears-50](https://www.foxnews.com/entertainment/saved-by-the-bell-star-tiffani-thiessen-fell-love-ice-plunging-nears-50)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T09:00:36+00:00

Tiffani Thiessen tells Fox News Digital about her thoughts on turning 50 and how she&apos;s staying fit while still practicing her love of cooking.

## 'It's a Wonderful Life' quiz! How well do you know this iconic film?
 - [https://www.foxnews.com/lifestyle/its-wonderful-life-quiz-how-well-do-you-know-iconic-film](https://www.foxnews.com/lifestyle/its-wonderful-life-quiz-how-well-do-you-know-iconic-film)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T09:00:32+00:00

Try your hand at this new lifestyle quiz from Fox News Digital. Test your knowledge of &quot;It&apos;s a Wonderful Life,&quot; one of the most beloved Christmas movies of all time.

## Red vs Blue State Debate highlights: Top 5 moments from the DeSantis, Newsom slugfest
 - [https://www.foxnews.com/politics/red-vs-blue-state-debate-highlights-top-5-moments-desantis-newsom-slugfest](https://www.foxnews.com/politics/red-vs-blue-state-debate-highlights-top-5-moments-desantis-newsom-slugfest)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T09:00:31+00:00

The Red vs. Blue State featuring Govs. Ron DeSantis, of Florida, and Gavin Newsom, of California, had several tense moments as the pair clashed over crime, taxes and the pandemic.

## Buster Murdaugh's classmate Stephen Smith died in hit-and-run with large skull fracture: pathologist
 - [https://www.foxnews.com/us/buster-murdaugh-classmate-stephen-smith-died-hit-run-large-skull-fracture-pathologist](https://www.foxnews.com/us/buster-murdaugh-classmate-stephen-smith-died-hit-run-large-skull-fracture-pathologist)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T09:00:30+00:00

Stephen Smith, Buster Murdaugh&apos;s high school classmate, died in a hit-and-run on a rural road in Hampton County in 2015, according to a pathologist who oversaw his autopsy.

## Outrage as UN-Palestinian exhibition uses murdered Israeli child's image as a Palestinian civilian casualty
 - [https://www.foxnews.com/world/outrage-un-geneva-palestinian-exhibition-murdered-israeli-childs-image-photo-palestinian-civilian-casualty](https://www.foxnews.com/world/outrage-un-geneva-palestinian-exhibition-murdered-israeli-childs-image-photo-palestinian-civilian-casualty)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T09:00:25+00:00

The U.N. office in Geneva takes down photos of Israeli children included in a pro-Palestinian exhibit; officials say they do not know who posted the &quot;unofficial&quot; pictures.

## House to attempt to expel George Santos for a third time, as Johnson says members will 'vote their conscience'
 - [https://www.foxnews.com/politics/house-attempt-expel-george-santos-third-time-johnson-says-members-will-vote-their-conscience](https://www.foxnews.com/politics/house-attempt-expel-george-santos-third-time-johnson-says-members-will-vote-their-conscience)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T09:00:22+00:00

The House of Representatives will try for the third time Friday to expel Rep. George Santos from Congress amid a slew of allegations against him including campaign finance abuses.

## Conservatives praise DeSantis debate performance against Newsom on social media: 'Whipped him'
 - [https://www.foxnews.com/politics/conservatives-praise-desantis-debate-performance-against-newsom-social-media-whipped-him](https://www.foxnews.com/politics/conservatives-praise-desantis-debate-performance-against-newsom-social-media-whipped-him)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T09:00:17+00:00

Conservatives praised Florida Gov. Ron DeSantis for his debate performance against California Gov. Gavin Newsom after the two went toe-to-toe in a Fox News debate on Thursday.

## As good cops flee progressive cities for conservative suburbs, doors open for unqualified candidates
 - [https://www.foxnews.com/us/good-cops-flee-progressive-cities-conservative-suburbs-doors-open-unqualified-candidates](https://www.foxnews.com/us/good-cops-flee-progressive-cities-conservative-suburbs-doors-open-unqualified-candidates)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T09:00:02+00:00

What happens to American cities when police departments can&apos;t hire &quot;good&quot; candidates to serve in law enforcement? Experts say it wouldn&apos;t look good.

## Meet the American who launched Cabbage Patch Kids, Xavier Roberts, dolls ignited Christmas shopping craze
 - [https://www.foxnews.com/lifestyle/meet-american-launched-cabbage-patch-kids-xavier-roberts-dolls-ignited-christmas-shopping-craze](https://www.foxnews.com/lifestyle/meet-american-launched-cabbage-patch-kids-xavier-roberts-dolls-ignited-christmas-shopping-craze)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T08:50:15+00:00

Xavier Roberts, an artist from rural Georgia, created Cabbage Patch Kids in the 1970s, which then caused a consumer frenzy during the Christmas shopping season in 1983.

## Nevada state troopers killed by drunken driver on Las Vegas freeway identified: 'Deep sorrow'
 - [https://www.foxnews.com/us/nevada-state-troopers-killed-drunken-driver-las-vegas-freeway-identified](https://www.foxnews.com/us/nevada-state-troopers-killed-drunken-driver-las-vegas-freeway-identified)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T08:17:05+00:00

Nevada Highway Patrol Sergeant Michael Abbate and Trooper Alberto Felix were killed after a drunken driver hit them while they were assisting another motorist on a Las Vegas freeway.

## AI-driven platform Play Anywhere launches game-changing partnership to reimagine interactive TV sports rights
 - [https://www.foxnews.com/sports/ai-driven-platform-play-anywhere-launches-game-changing-partnership-to-reimagine-interactive-tv-sports-rights](https://www.foxnews.com/sports/ai-driven-platform-play-anywhere-launches-game-changing-partnership-to-reimagine-interactive-tv-sports-rights)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T07:00:51+00:00

The need to land sports media rights continues to grow. But companies are also seeking creative solutions on driving fan engagement and monetizing different types of rights.

## Ridley Scott warns AI will be ‘technical hydrogen bomb’ in film industry
 - [https://www.foxnews.com/entertainment/ridley-scott-warns-ai-will-be-technical-hydrogen-bomb-in-film-industry](https://www.foxnews.com/entertainment/ridley-scott-warns-ai-will-be-technical-hydrogen-bomb-in-film-industry)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T07:00:46+00:00

Director Ridley Scott expressed his fears about artificial intelligence going unregulated in a new interview, saying we &quot;need to lock it down.&quot;

## Jeffrey Epstein flight log subpoena request denied by Democrat-led Senate Judiciary Committee, Blackburn says
 - [https://www.foxnews.com/politics/jeffrey-epstein-flight-logs-denied-democrat-led-senate-judiciary-committee-blackburn-says](https://www.foxnews.com/politics/jeffrey-epstein-flight-logs-denied-democrat-led-senate-judiciary-committee-blackburn-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T02:41:29+00:00

Sen. Marsha Blackburn, R-Tenn., criticized Sen. Dick Durbin for allegedly blocking her request for a subpoena looking into Jeffrey Epstein&apos;s flight logs.

## Pop star who filmed ‘inappropriate’ music video in Catholic Church defends actions: ‘Jesus was a carpenter'
 - [https://www.foxnews.com/media/pop-star-filmed-inappropriate-music-video-catholic-church-defends-actions-jesus-carpenter](https://www.foxnews.com/media/pop-star-filmed-inappropriate-music-video-catholic-church-defends-actions-jesus-carpenter)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T02:00:45+00:00

Pop star Sabrina Carpenter recently defended her decision to shoot a music video in the sanctuary of a Catholic Church, saying, &quot;Jesus was a carpenter.&quot;

## Bills' Von Miller turns himself in to police as details of alleged domestic violence incident emerge
 - [https://www.foxnews.com/sports/bills-von-miller-turns-himself-police-details-emerge-alleged-domestic-violence-incident](https://www.foxnews.com/sports/bills-von-miller-turns-himself-police-details-emerge-alleged-domestic-violence-incident)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-01T01:27:00+00:00

Buffalo Bills veteran edge rusher Von Miller turned himself in to Glenn Heights Police Thursday after an arrest warrant was issued for an alleged assault on his pregnant girlfriend.

