# Source:Politico, URL:https://rss.politico.com/politics-news.xml, language:en-US

## Sandra Day O’Connor: A life in pictures
 - [https://www.politico.com/gallery/2023/12/01/sandra-day-oconnor-life-pictures-photos-002957](https://www.politico.com/gallery/2023/12/01/sandra-day-oconnor-life-pictures-photos-002957)
 - RSS feed: https://rss.politico.com/politics-news.xml
 - date published: 2023-12-01T13:41:52+00:00

The first woman Supreme Court justice died on Friday at 93.

## The nation’s cartoonists on the week in politics
 - [https://www.politico.com/gallery/2023/12/01/the-nations-cartoonists-on-the-week-in-politics-00129447](https://www.politico.com/gallery/2023/12/01/the-nations-cartoonists-on-the-week-in-politics-00129447)
 - RSS feed: https://rss.politico.com/politics-news.xml
 - date published: 2023-12-01T05:00:00+00:00

Every week political cartoonists throughout the country and across the political spectrum apply their ink-stained skills to capture the foibles, memes, hypocrisies and other head-slapping events in the world of politics. The fruits of these labors are hundreds of cartoons that entertain and enrage readers of all political stripes. Here's an offering of the best of this week's crop, picked fresh off the Toonosphere. Edited by Matt Wuerker.

## Watch the DeSantis vs. Newsom debate in 3 minutes
 - [https://www.politico.com/video/2023/12/01/watch-the-desantis-vs-newsom-debate-in-3-minutes-1153824](https://www.politico.com/video/2023/12/01/watch-the-desantis-vs-newsom-debate-in-3-minutes-1153824)
 - RSS feed: https://rss.politico.com/politics-news.xml
 - date published: 2023-12-01T00:33:21+00:00



