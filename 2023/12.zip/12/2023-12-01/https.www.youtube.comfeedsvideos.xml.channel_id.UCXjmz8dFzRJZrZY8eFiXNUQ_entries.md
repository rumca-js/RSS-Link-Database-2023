# Source:Nerdstalgic, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXjmz8dFzRJZrZY8eFiXNUQ, language:en-US

## Why This Ryan Gosling Film Wasn't Allowed A Sequel
 - [https://www.youtube.com/watch?v=36bD6MKwM0U](https://www.youtube.com/watch?v=36bD6MKwM0U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXjmz8dFzRJZrZY8eFiXNUQ
 - date published: 2023-12-01T18:00:01+00:00

Ryan Gosling is an actor that most everyone seems to have a specific image of.  With a run of movies like The Notebook and Crazy Stupid Love, Ryan Gosling was seen as nothing more than a handsome heart throb relegated to romantic comedy and dramas.  But one movie proved Ryan Gosling was so much more than that, he was legitimately funny and could carry multiple genres on his back.  The Nice Guys was a movie so underrated, no studio even looked at sequel opportunities.  Though one could argue, Ryan Gosling doesn't show up as Ken in Barbie, without The Nice Guys.

#ryangosling #barbie #nerdstalgic 

Sources:
https://whatculture.com/film/neil-marshall-shifts-gears-to-drive-at-universal-with-hugh-jackman
https://variety.com/2008/film/markets-festivals/marshall-shifting-gears-for-universal-1117982679/
https://www.complex.com/pop-culture/a/matt-barone/interview-drive-director-nicolas-winding-refn
https://younghollywood.com/news/ryan-gosling-first-meeting-with-drive-director-was-like-a-bad-d

