# Source:Vlog Casha, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLsnJt_eyqkGZ4ZEM__xCOg, language:pl-PL

## TAK WYGLĄDA NAJPIĘKNIEJSZA PLAŻA ŚWIATA - Australia #10
 - [https://www.youtube.com/watch?v=FiU3F2uFXqk](https://www.youtube.com/watch?v=FiU3F2uFXqk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLsnJt_eyqkGZ4ZEM__xCOg
 - date published: 2023-12-01T14:06:24+00:00

🗺️ Australia #10. Wchodzimy na wyższy poziom Australii. Dużo się dzieje. Popłyniemy na plażę Whitehaven, która była ogłoszona najpiękniejszą plażą na świecie, oprócz tego będą dinozaury, wodospady no i nowe, ulepszone muchy... :)

❗ Zostań Patronem kanału!
https://patronite.pl/vlogcasha

Kanał Nejta:  @swiatwedlugnejtana  

Playlisty filmów z moich podróży:
Kambodża (2022): http://bit.ly/3mVA9xv
Indie (2022): http://bit.ly/3viDgAg
USA (2022): https://bit.ly/3uGVdbd
Kuba (2021): https://bit.ly/3dhLIqK
USA (2021): https://bit.ly/35J0zKd
Meksyk (2021): http://bit.ly/3c7Jycf
Turcja (2019-2020): https://bit.ly/31VPCR3
Kolumbia (2020): https://bit.ly/36tqlhH
Tajlandia, Laos, Wietnam (2019): https://bit.ly/2wrM9t2
Australia (2018): https://bit.ly/2OJWYOy
USA (2017): https://bit.ly/2ya73NV
Autostop (2018): https://bit.ly/2NbHzos

Mój sprzęt:
Aparat/Obiektywy: Sony A7IV / FE 16-35mm F2.8 / FE 24-105mm F4
Plecak zielony: https://bit.ly/3y9cX1Y
Dron: http://bit.ly/3Lpih8t

(Linki afiliacyjne. J

