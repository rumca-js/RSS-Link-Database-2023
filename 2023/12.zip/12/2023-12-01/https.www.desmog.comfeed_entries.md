# Source:DeSmog, URL:https://www.desmog.com/feed/, language:en-US

## Mapped: Big Ag’s Routes to Influence at COP28
 - [https://www.desmog.com/2023/12/01/mapped-big-ags-routes-to-influence-at-cop28](https://www.desmog.com/2023/12/01/mapped-big-ags-routes-to-influence-at-cop28)
 - RSS feed: https://www.desmog.com/feed/
 - date published: 2023-12-01T18:42:05+00:00

<p>As this year’s climate summit gets underway in Dubai, powerful food and farming companies are well positioned to ensure their interests are protected. They will use their connections to network, lobby – and even raise investment. These agri-giants will be rubbing shoulders with over 80,000 participants – the highest attendance of any climate conference – [&#8230;]</p>
<p>The post <a href="https://www.desmog.com/2023/12/01/mapped-big-ags-routes-to-influence-at-cop28/" rel="nofollow">Mapped: Big Ag’s Routes to Influence at COP28</a> appeared first on <a href="https://www.desmog.com" rel="nofollow">DeSmog</a>.</p>

## Corporate Promotion of Carbon Capture and Storage Contradicts Science, Study Finds
 - [https://www.desmog.com/2023/11/30/influencemap-report-carbon-capture-corporations-paris-agreement](https://www.desmog.com/2023/11/30/influencemap-report-carbon-capture-corporations-paris-agreement)
 - RSS feed: https://www.desmog.com/feed/
 - date published: 2023-12-01T05:01:00+00:00

<p>A new InfluenceMap report reveals that over 80 percent of corporate policy engagement on carbon capture and storage contradicts the Intergovernmental Panel on Climate Change’s science-based policy guidance, leading to misguided ideas behind CCS use.</p>
<p>The post <a href="https://www.desmog.com/2023/11/30/influencemap-report-carbon-capture-corporations-paris-agreement/" rel="nofollow">Corporate Promotion of Carbon Capture and Storage Contradicts Science, Study Finds</a> appeared first on <a href="https://www.desmog.com" rel="nofollow">DeSmog</a>.</p>

