# Source:The Telegraph News, URL:https://www.telegraph.co.uk/news/rss.xml, language:en-UK

## Friday evening news briefing: BBC names royal figures at centre of racism row
 - [https://www.telegraph.co.uk/news/2023/12/01/friday-evening-news-briefing-bbc-names-royal-racism-row](https://www.telegraph.co.uk/news/2023/12/01/friday-evening-news-briefing-bbc-names-royal-racism-row)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-12-01T17:41:20+00:00



## What's inside? Meerkats get in the festive spirit at London Zoo
 - [https://www.telegraph.co.uk/news/2023/12/01/london-zoo-advent-calendars-christmas-meerkat-tiger](https://www.telegraph.co.uk/news/2023/12/01/london-zoo-advent-calendars-christmas-meerkat-tiger)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-12-01T13:18:58+00:00



## Covid Inquiry latest: Matt Hancock faces second day of questioning - watch live
 - [https://www.telegraph.co.uk/news/2023/12/01/covid-inquiry-uk-latest-news-matt-hancock-day-2](https://www.telegraph.co.uk/news/2023/12/01/covid-inquiry-uk-latest-news-matt-hancock-day-2)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-12-01T10:19:14+00:00



## Pictured: The greatest karaoke band of all time?
 - [https://www.telegraph.co.uk/news/2023/12/01/gary-barlow-rod-stewart-ronnie-wood-geri-horner-emma-bunton](https://www.telegraph.co.uk/news/2023/12/01/gary-barlow-rod-stewart-ronnie-wood-geri-horner-emma-bunton)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-12-01T09:50:26+00:00



## UK weather latest: Up to 5cm of snow to fall in parts as temperatures plummet
 - [https://www.telegraph.co.uk/news/2023/12/01/uk-weather-news-latest-snow-ice-live](https://www.telegraph.co.uk/news/2023/12/01/uk-weather-news-latest-snow-ice-live)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-12-01T07:54:28+00:00



