# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Premiership: Harlequins 36-3 Sale - Marcus Smith stars as leaders are crushed at Quins
 - [https://www.bbc.co.uk/sport/rugby-union/67578465?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/67578465?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T22:48:29+00:00

Marcus Smith impresses as Harlequins score five tries to beat Premiership leaders Sale 36-3.

## England 3-2 Netherlands: Mary Earps says she 'really let the team down' with first-half error
 - [https://www.bbc.co.uk/sport/football/67593500?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67593500?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T22:46:36+00:00

England stand-in captain Mary Earps believes she "really let the team down" in their comeback win over the Netherlands in the Women's Nations League.

## Preston North End 0-2 Queens Park Rangers: Ilias Chair sets up both goals in R's win
 - [https://www.bbc.co.uk/sport/football/67516669?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67516669?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T22:26:09+00:00

Ilias Chair sets up both QPR goals as the Championship strugglers add to Preston's woes with victory at Deepdale.

## 'I’m not ready to lose hope’: The hostages still in Gaza
 - [https://www.bbc.co.uk/news/world-middle-east-67595798?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-67595798?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T21:35:04+00:00

There are still over 100 hostages being held by Hamas in Gaza, including at least 16 women.

## Belgium 1-1 Scotland: Visitors relegated to Nations League B after draw
 - [https://www.bbc.co.uk/sport/football/67543676?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67543676?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T21:27:17+00:00

Scotland will be relegated to Women's Nations League B despite Erin Cuthbert's stunning equaliser against Belgium.

## Wales 1-2 Iceland: Wales relegated from Women's Nations League top tier after loss
 - [https://www.bbc.co.uk/sport/football/67580812?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67580812?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T21:18:43+00:00

Wales are relegated from the top tier of the Nations League as they are beaten 2-1 by Iceland in Cardiff.

## Ukraine war: Putin to boost Russian troop numbers by 15%
 - [https://www.bbc.co.uk/news/world-europe-67592803?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-67592803?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T20:58:46+00:00

Russia's president signs a decree aimed at increasing numbers of serving military personnel by 170,000.

## Danny Macklin: Essex Police appeals to find ex-Wimbledon chief
 - [https://www.bbc.co.uk/news/uk-england-essex-67589660?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-essex-67589660?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T19:38:07+00:00

Essex Police officers are searching for Danny Macklin, 32, after he was reported missing.

## The Vivienne: Drag Race star attack was homophobic - magistrates
 - [https://www.bbc.co.uk/news/uk-england-merseyside-67594641?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-merseyside-67594641?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T19:27:03+00:00

Alan Whitfield punched The Vivienne in the face in a fast food outlet in Liverpool in June.

## US House votes to expel George Santos from Congress
 - [https://www.bbc.co.uk/news/world-us-canada-67593885?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-67593885?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T18:52:29+00:00

The Republican becomes only the sixth elected member of the lower chamber of Congress ever to be removed.

## COP28: UN climate talks take aim at planet-warming food
 - [https://www.bbc.co.uk/news/science-environment-67594303?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-67594303?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T18:41:38+00:00

World leaders agree to tackle the huge carbon footprint of the food we produce and eat.

## Brigit Forsyth: Still Open All Hours actress dies aged 83
 - [https://www.bbc.co.uk/news/entertainment-arts-67590697?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-67590697?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T18:06:24+00:00

The star was best known for TV shows Whatever Happened to the Likely Lads? and Still Open All Hours.

## Three network down for tens of thousands across UK
 - [https://www.bbc.co.uk/news/technology-67595457?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-67595457?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T18:04:15+00:00

The network says its working on the issue now to fix it as soon as possible.

## Albania 0-4 Northern Ireland: Simone Magill scores twice as visitors boost hopes
 - [https://www.bbc.co.uk/sport/football/67561249?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67561249?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T17:59:53+00:00

Northern Ireland keep their hopes of progression to League A of the Women's Nations alive with a 4-0 win over Albania in Tirana.

## King's tie features Greek flag after Elgin Marbles row
 - [https://www.bbc.co.uk/news/uk-67589075?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-67589075?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T17:51:47+00:00

Royal sources say the tie was a coincidence and not linked to Rishi Sunak's spat with the Greek PM.

## 'Ghana Must Go' bags: Ethiopian Airlines bans the well-known luggage
 - [https://www.bbc.co.uk/news/world-africa-67581683?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-67581683?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T17:50:30+00:00

Ethiopian Airlines says the luggage, known by various names across Africa, can damage equipment.

## UK Championship 2023: Ronnie O'Sullivan survives scare against Zhou Yuelong to reach semi-finals
 - [https://www.bbc.co.uk/sport/snooker/67595076?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/snooker/67595076?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T17:49:10+00:00

Ronnie O'Sullivan keeps his hopes of a record-extending eighth UK Championship crown alive with a courageous 6-5 comeback victory against Zhou Yuelong in York.

## India v Australia: Axar Patel stars as hosts complete T20 series win
 - [https://www.bbc.co.uk/sport/cricket/67595962?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/67595962?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T17:34:08+00:00

India beat a much-changed Australia by 20 runs to complete a T20 series victory in Raipur.

## Rugby concussion: Players' litigation decision due in 2024
 - [https://www.bbc.co.uk/news/uk-wales-67594313?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-67594313?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T17:27:24+00:00

An application by ex-players to sue as a group may be heard in April or May, the High Court hears.

## GTA 6: Game to be unveiled with 5 December trailer
 - [https://www.bbc.co.uk/news/technology-67595452?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-67595452?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T17:20:37+00:00

Ten years after the release of GTA 5, the next game in the series is due to be unveiled on 5 December.

## Young Sports Personality 2023: Mia Brookes, Penny Healey & Charlie McIntyre on shortlist
 - [https://www.bbc.co.uk/sport/sports-personality/67542498?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/sports-personality/67542498?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T17:00:23+00:00

Mia Brookes, Penny Healey and Charlie McIntyre are shortlisted for the BBC Young Sports Personality of the Year award.

## Rise in English bathing sites rated unfit to swim
 - [https://www.bbc.co.uk/news/science-environment-67593143?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-67593143?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T16:58:28+00:00

Fewer swimming spots are rated "excellent" and more rated "poor" by the environment watchdog.

## University Challenge: Christmas episode axed after ableism complaints
 - [https://www.bbc.co.uk/news/entertainment-arts-67589079?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-67589079?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T16:56:06+00:00

Two contestants in the Christmas version of the BBC quiz say their disabilities weren't provided for.

## Pontins: Former holiday park giant shrinks further
 - [https://www.bbc.co.uk/news/uk-wales-67589538?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-67589538?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T16:51:03+00:00

At its peak, the holiday park had 30 venues across the UK, now it is left with just four.

## Sandra Day O'Connor: A ranch girl who became 'queen of the court'
 - [https://www.bbc.co.uk/news/world-us-canada-54937286?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-54937286?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T16:37:15+00:00

As the first woman on the Supreme Court, Justice O'Connor was a trailblazer and a powerful moderate.

## Ukraine says it blew up railway in eastern Russia
 - [https://www.bbc.co.uk/news/world-europe-67593041?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-67593041?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T16:15:14+00:00

Explosions are said to have hit trains on the Baikal Amur mainline 500km from the Chinese border.

## Lawrence Jones: Ex-tech boss who drugged and raped women jailed
 - [https://www.bbc.co.uk/news/uk-england-manchester-67592108?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-manchester-67592108?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T15:49:35+00:00

Lawrence Jones, 55, committed the two rapes when he was working as a hotel pianist in the early 1990s.

## Ex-Supreme Court Justice Sandra Day O'Connor dies aged 93
 - [https://www.bbc.co.uk/news/world-us-canada-67593879?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-67593879?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T15:25:16+00:00

Sandra Day O'Connor, the first woman to sit on the US Supreme Court, has died aged 93

## How the Palace got stuck in Scobie-gate
 - [https://www.bbc.co.uk/news/uk-67589069?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-67589069?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T15:21:04+00:00

After the naming of names in the race row, the Royal Family has to tackle difficult questions.

## Andre Onana: Man Utd boss Erik ten Hag says goalkeeper is second best 'based on stats' in the league
 - [https://www.bbc.co.uk/sport/football/67587754?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67587754?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T14:30:01+00:00

Manchester United manager Erik ten Hag says goalkeeper Andre Onana is the Premier League's second-best goalkeeper "based on stats".

## Trafalgar Square Christmas tree arrives at Port of Immingham
 - [https://www.bbc.co.uk/news/uk-england-humber-67590719?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-humber-67590719?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T14:27:47+00:00

The 70-year-old Norwegian spruce grew near Oslo and is destined for Trafalgar Square in the capital.

## The Traitors to be uncloaked in spin-off series
 - [https://www.bbc.co.uk/news/articles/czd2234gq38o?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/articles/czd2234gq38o?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T14:24:11+00:00

The Traitors: Uncloaked will show eliminated players from the reality TV hit who the traitors are.

## George Santos faces expulsion in historic House vote
 - [https://www.bbc.co.uk/news/world-us-canada-67586030?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-67586030?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T14:09:48+00:00

The New York congressman could be kicked out after a damning ethics report and criminal charges of fraud.

## COP28: 'The Earth does not belong to us' - King Charles III
 - [https://www.bbc.co.uk/news/science-environment-67588259?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-67588259?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T13:37:36+00:00

Speaking at COP28, the King says we are carrying out a "vast, frightening experiment" on the planet.

## Train strikes: Drivers vote to continue walkouts
 - [https://www.bbc.co.uk/news/business-67591258?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-67591258?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T13:37:29+00:00

Aslef members back walkouts for the next six months, as the union begins nine days of action.

## UN says end of ceasefire 'nightmare' for people in Gaza
 - [https://www.bbc.co.uk/news/world-middle-east-67587999?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-67587999?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T13:36:14+00:00

The resumption of fighting between Israel and Hamas is "catastrophic", Unicef says.

## Israel Gaza: How missiles and destruction quickly returned after ceasefire
 - [https://www.bbc.co.uk/news/world-middle-east-67591768?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-67591768?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T13:25:27+00:00

A seven-day ceasefire between Israel and Hamas has ended, bringing with it explosions and bloodshed.

## Sultan al-Jaber: A quick guide to the COP28 president
 - [https://www.bbc.co.uk/news/science-environment-67591804?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-67591804?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T13:22:03+00:00

Here's what you need to know about the man in charge of the UN climate conference

## Covid inquiry: Some local leaders put politics ahead of public health, says Hancock
 - [https://www.bbc.co.uk/news/uk-politics-67587763?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-67587763?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T13:06:23+00:00

The ex-health secretary says plans for local Covid restrictions were hindered by Manchester politicians.

## Murder inquiry over assault at National Trust property
 - [https://www.bbc.co.uk/news/uk-england-lincolnshire-67590711?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-lincolnshire-67590711?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T12:54:18+00:00

Police work is ongoing "at a number of locations" in Lincolnshire and Nottinghamshire, officers say.

## Everton make formal appeal over 10-point deduction
 - [https://www.bbc.co.uk/sport/football/67591673?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67591673?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T12:54:04+00:00

Everton submit a formal appeal against an independent commission's decision to hand them an unprecedented 10-point Premier League deduction.

## Why has the Gaza ceasefire come to an end?
 - [https://www.bbc.co.uk/news/world-middle-east-67589259?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-67589259?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T12:40:25+00:00

Both Israel and Hamas are blaming each other for violating the terms of the agreement.

## Saudi Arabia 'in fifth gear' but is it 'right' for women's tennis to go there?
 - [https://www.bbc.co.uk/sport/tennis/67585844?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/67585844?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T12:36:05+00:00

After taking its first steps into staging professional tennis, Saudi Arabia is now eyeing a deal for the WTA finals.

## Sir James Dyson loses libel claim against Daily Mirror publisher
 - [https://www.bbc.co.uk/news/uk-england-bristol-67589147?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-bristol-67589147?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T12:29:45+00:00

The inventor was suing the newspaper for libel over an article published in January 2022.

## Artist and Tutti Frutti writer John Byrne dies, aged 83
 - [https://www.bbc.co.uk/news/uk-scotland-67589431?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-67589431?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T12:01:23+00:00

The 83-year-old was an acclaimed designer and painter and found his widest audience writing for TV.

## Bank branch closures hits Prime Minister Rishi Sunak's constituency
 - [https://www.bbc.co.uk/news/business-67583574?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-67583574?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T11:55:25+00:00

The last bank in Richmond, North Yorkshire, is one of 18 branch closures announced by Barclays.

## Nick Kyrgios thanks Andy Murray for helping him with mental health struggles
 - [https://www.bbc.co.uk/sport/tennis/67587748?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/67587748?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T11:27:54+00:00

Nick Kyrgios says he is "very thankful" to Andy Murray for helping him with his mental health struggles.

## Taylor Swift: Publicist denies star secretly married Joe Alwyn
 - [https://www.bbc.co.uk/news/newsbeat-67588850?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-67588850?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T11:14:18+00:00

Tree Paine has been part of the singer's team since 2014, calling the Deuxmoi rumours "fabricated lies".

## Strictly Come Dancing: Amy Dowden's blood clot after chemo
 - [https://www.bbc.co.uk/news/uk-wales-67587530?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-67587530?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T11:01:21+00:00

The dancer, 33, says her "nightmare seems to be never ending" after a blood clot on her lung.

## House prices edge up as hopes rise of lower mortgage rates
 - [https://www.bbc.co.uk/news/business-67587236?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-67587236?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T10:32:04+00:00

The Nationwide says there are "encouraging signs" that mortgage rates are starting to come down.

## UK weather: Snow forecast and warnings in place as temperatures plummet
 - [https://www.bbc.co.uk/news/uk-67588099?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-67588099?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T10:30:37+00:00

Thursday was the coldest night in the UK since mid-March, with temperatures as low as -9.4C.

## Euro 2020: Harry Kane, Cristiano Ronaldo, Luka Modric, Patrik Schick goals from the tournament
 - [https://www.bbc.co.uk/sport/av/football/67584339?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/67584339?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T10:18:53+00:00

BBC Sport relives 10 goals that tell the story of the Euro 2020 tournament - featuring memorable strikes from Harry Kane, Cristiano Ronaldo and Luka Modric.

## Ukraine war: Zelensky says fortifying front lines must be accelerated
 - [https://www.bbc.co.uk/news/world-europe-67587331?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-67587331?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T10:14:08+00:00

Ukraine's president meets frontline commanders and says winter is a new phase of the war with Russia.

## Farrell decision a 'wake-up call' - Wales boss Gatland
 - [https://www.bbc.co.uk/sport/rugby-union/67588023?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/67588023?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T10:10:58+00:00

Wales coach Warren Gatland believes Owen Farrell's decision to step away from international rugby should be a "wake-up call for all of us".

## Joshua Cheptegei: Eliud Kipchoge backs Ugandan for greatness before marathon debut
 - [https://www.bbc.co.uk/sport/africa/67568878?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/africa/67568878?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T10:08:36+00:00

Kenyan legend Eliud Kipchoge says Olympic 5,000m champion Joshua Cheptegei can break the marathon world record one day.

## Aston Villa: Officer believed burnt in clashes with Legia Warsaw fans
 - [https://www.bbc.co.uk/news/uk-england-birmingham-67588149?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-birmingham-67588149?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T10:06:17+00:00

Forty six are in custody as Villa fans say all hell broke loose before the game with Legia Warsaw.

## Endgame: Royal race row naming not publicity stunt, says author Omid Scobie
 - [https://www.bbc.co.uk/news/uk-67584565?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-67584565?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T09:48:44+00:00

Omid Scobie denies in a BBC interview claims a version of his book deliberately identified two royals.

## Shane MacGowan: U2 and Paul Weller lead tributes to Pogues singer
 - [https://www.bbc.co.uk/news/world-us-canada-67587867?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-67587867?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T09:48:30+00:00

U2, Paul Weller and Pete Doherty lead the tributes to the Pogues frontman, who died on Thursday.

## Alistair Darling: Gordon Brown says briefings against ex-chancellor unfair
 - [https://www.bbc.co.uk/news/uk-politics-67584668?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-67584668?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T08:54:16+00:00

The former prime minister hails the "integrity" of Lord Darling following his death aged 70.

## Crunch calls Southgate must face before Euro 2024 reckoning
 - [https://www.bbc.co.uk/sport/football/67569276?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67569276?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T08:14:10+00:00

With the Euro 2024 draw taking place on Saturday, manager Gareth Southgate has a lot to ponder as he looks to finally deliver silverware for England.

## Von Miller: Buffalo Bills linebacker turns himself in to police after arrest warrant issued
 - [https://www.bbc.co.uk/sport/american-football/67584335?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/american-football/67584335?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T07:50:12+00:00

Buffalo Bills linebacker Von Miller turns himself in to police to face a charge of assaulting a pregnant woman.

## The race against time to repair Edinburgh Airport's runway
 - [https://www.bbc.co.uk/news/uk-scotland-67579869?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-67579869?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T06:34:27+00:00

Engineers have been working throughout the past month to repair cracks in the surface of Edinburgh Airport's runway.

## The Ashes: Stuart Broad bowls England to victory in fairytale finale
 - [https://www.bbc.co.uk/sport/av/cricket/67572092?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/67572092?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T06:28:23+00:00

Stuart Broad ends his glittering career by bowling England to a dramatic victory in the fifth Test against Australia at The Oval, featuring his bail switching antics.

## Bristol man breeding glow worms in his bedroom
 - [https://www.bbc.co.uk/news/uk-england-bristol-67545651?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-bristol-67545651?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T06:09:37+00:00

Pete Cooper, from Bristol, wants to help stop the decline of the "magical" beetles.

## 'Airspace' above Battersea house to be auctioned
 - [https://www.bbc.co.uk/news/uk-england-london-67575318?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-67575318?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T05:57:36+00:00

Vacant space above a building is offered with a guide price of £10,000, and no planning permission.

## Palestinian man criticises Israeli prison as 30 more freed
 - [https://www.bbc.co.uk/news/world-middle-east-67585594?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-67585594?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T04:49:02+00:00

In the seventh exchange of prisoners and hostages, eight Israelis are also released by Hamas.

## Watch: Does Musk's window-smashing stunt work?
 - [https://www.bbc.co.uk/news/technology-67586213?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-67586213?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T03:52:19+00:00

The pickup truck - Tesla’s latest offering - had its windows smashed during a demonstration in 2019.

## Blinken steps up call for Israel to spare civilians in strongest remarks yet
 - [https://www.bbc.co.uk/news/world-us-canada-67586033?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-67586033?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T02:58:16+00:00

The top diplomat delivers the strongest US remarks yet in Israel on protecting Palestinian civilians.

## US Senator Rand Paul performs Heimlich on Senator Joni Ernst
 - [https://www.bbc.co.uk/news/world-us-canada-67572747?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-67572747?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T01:59:16+00:00

Rand Paul of Kentucky performs the Heimlich manoeuvre on fellow Republican Joni Ernst of Iowa.

## Climate crisis: Three women helping wildlife survive
 - [https://www.bbc.co.uk/news/science-environment-67308974?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-67308974?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T01:25:18+00:00

Climate change is a threat to thousands of animal species, including gorillas, pangolins and turtles.

## Head teacher says autistic student died despite family's plea for support
 - [https://www.bbc.co.uk/news/uk-67526409?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-67526409?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T01:24:21+00:00

Isaac Uzoegbu was hit by a car when he ran from home. His head teacher says it could have been prevented.

## Beyoncé tells fans (and Taylor Swift) to 'laugh and dance' at Renaissance premiere
 - [https://www.bbc.co.uk/news/entertainment-arts-67581043?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-67581043?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T01:22:27+00:00

The London premiere of Beyoncé's tour film included an special guest and a demand for dancing.

## Released Palestinians allege abuse in Israeli jails
 - [https://www.bbc.co.uk/news/world-middle-east-67581915?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-67581915?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T00:59:28+00:00

Palestinians tell the BBC they were beaten and had dogs set on them while in Israeli detention.

## 'Sued by my abuser for millions, I set up a social network instead'
 - [https://www.bbc.co.uk/news/business-67559541?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-67559541?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T00:18:42+00:00

The app that gives women a place to speak out about about sexual harassment and other #MeToo issues.

## Filmmakers discover 128-year-old shipwreck
 - [https://www.bbc.co.uk/news/world-us-canada-67585811?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-67585811?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-01T00:02:19+00:00

The hulk of the 'Africa' is found on the bed of Lake Huron in Canada by filmmakers looking for mussels.

