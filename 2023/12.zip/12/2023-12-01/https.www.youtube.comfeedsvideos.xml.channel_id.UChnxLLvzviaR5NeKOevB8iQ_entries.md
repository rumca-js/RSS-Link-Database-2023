# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## This is Tempera #granulator #granularsynthesis
 - [https://www.youtube.com/watch?v=5VkSUycunjg](https://www.youtube.com/watch?v=5VkSUycunjg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2023-12-01T16:50:34+00:00

Support the channel on Patreon: http://bit.ly/rmrpatreon
Take a lesson with me: https://rmr.media/education

Find my music here: 
Bandcamp: http://bit.ly/2Kq617o
Spotify: https://spoti.fi/2N40SoX
YouTube Music: https://bit.ly/3PZQ4ol
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

Connect:
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia

