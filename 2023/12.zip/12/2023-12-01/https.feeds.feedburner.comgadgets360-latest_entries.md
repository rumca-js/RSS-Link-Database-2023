# Source:Gadgets 360, URL:https://feeds.feedburner.com/gadgets360-latest, language:en

## GTA 6 Trailer Coming This Tuesday, Rockstar Games Confirms
 - [https://www.gadgets360.com/games/news/gta-6-trailer-release-date-december-5-announcement-grand-theft-auto-rockstar-games-4625605](https://www.gadgets360.com/games/news/gta-6-trailer-release-date-december-5-announcement-grand-theft-auto-rockstar-games-4625605)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2023-12-01T16:37:40+00:00

The last Grand Theft Auto game was released in 2013

## Xbox Game Pass December 2023: Far Cry 6, Remnant I and II, and More
 - [https://www.gadgets360.com/games/news/xbox-game-pass-december-2023-games-far-cry-6-remnant-2-rise-of-tomb-raider-pc-xbox-series-one-4625289](https://www.gadgets360.com/games/news/xbox-game-pass-december-2023-games-far-cry-6-remnant-2-rise-of-tomb-raider-pc-xbox-series-one-4625289)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2023-12-01T14:58:33+00:00

Breaking Bad star Giancarlo Esposito plays the lead villain in Far Cry 6

## Aquaman 2, Sam Bahadur, Rebel Moon Part One, and More: Movie Guide to Cinemas and Streaming in December 2023
 - [https://www.gadgets360.com/entertainment/features/movies-releasing-in-december-2023-sam-bahadur-aquaman-2-rebel-moon-part-1-dunki-netflix-4625058](https://www.gadgets360.com/entertainment/features/movies-releasing-in-december-2023-sam-bahadur-aquaman-2-rebel-moon-part-1-dunki-netflix-4625058)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2023-12-01T14:23:50+00:00

Zack Snyder has planned longer explicit cuts for Rebel Moon in the future

## Apple Plans to Equip All iPhone 16 Models With Revamped Action Button: Report
 - [https://www.gadgets360.com/mobiles/news/iphone-16-series-action-button-all-models-report-4625097](https://www.gadgets360.com/mobiles/news/iphone-16-series-action-button-all-models-report-4625097)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2023-12-01T13:59:34+00:00

Apple replaced the mute switch on the iPhone 15 Pro and Pro Max (pictured) with the Action Button

## iQoo 12 Priority Pass Announced: Benefits Include Early Access to the Sale and a Free Vivo TWS
 - [https://www.gadgets360.com/mobiles/news/iqoo-12-iqoo-12-pro-india-launch-offers-date-priority-pass-details-4625093](https://www.gadgets360.com/mobiles/news/iqoo-12-iqoo-12-pro-india-launch-offers-date-priority-pass-details-4625093)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2023-12-01T13:56:08+00:00

The iQoo 12 was launched in China on 7 November with a starting price of CNY 3,999 (roughly Rs. 45,000).

## iQoo 12 Camera First Look: A Sneak Peek at the Camera Performance of iQoo's Upcoming Flagship
 - [https://www.gadgets360.com/mobiles/features/iqoo-12-camera-samples-first-look-telephoto-zoom-jaisalmer-visit-4618347](https://www.gadgets360.com/mobiles/features/iqoo-12-camera-samples-first-look-telephoto-zoom-jaisalmer-visit-4618347)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2023-12-01T12:08:57+00:00

The iQoo 12 is equipped with a 50-megapixel triple rear camera setup

## Call of Duty: Modern Warfare III Campaign Review: Activision's First-Person Shooter Runs Out of Ammo
 - [https://www.gadgets360.com/games/reviews/call-of-duty-modern-warfare-3-campaign-review-cod-mw3-2023-story-gameplay-warzone-ps5-activision-4623251](https://www.gadgets360.com/games/reviews/call-of-duty-modern-warfare-3-campaign-review-cod-mw3-2023-story-gameplay-warzone-ps5-activision-4623251)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2023-12-01T11:59:26+00:00

Modern Warfare 3's campaign follows Captain Price and Task Force 141's efforts to capture Makarov

## Oppo Reno 10 Pro 5G Price in India Slashed by Rs. 2,000: Know How Much It Costs Now
 - [https://www.gadgets360.com/mobiles/news/oppo-reno-10-pro-5g-price-in-india-drop-cut-rs-37999-specifications-4624301](https://www.gadgets360.com/mobiles/news/oppo-reno-10-pro-5g-price-in-india-drop-cut-rs-37999-specifications-4624301)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2023-12-01T11:39:01+00:00

Oppo Reno 10 Pro 5G is offered in Glossy Purple and Silvery Grey shades

## Google Chrome Update Fixes High-Severity Zero-Day Vulnerability That Was Actively Exploited
 - [https://www.gadgets360.com/apps/news/google-chrome-update-security-flaw-zero-day-vulnerability-actively-exploited-4624004](https://www.gadgets360.com/apps/news/google-chrome-update-security-flaw-zero-day-vulnerability-actively-exploited-4624004)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2023-12-01T09:52:47+00:00

Google Chrome users with automatic updates enabled should already be protected

## UN to Educate Over 22,000 Staff Members on Blockchain, Web3: Here’s Why
 - [https://www.gadgets360.com/cryptocurrency/news/un-blockchain-educate-22000-staff-members-web3-4624005](https://www.gadgets360.com/cryptocurrency/news/un-blockchain-educate-22000-staff-members-web3-4624005)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2023-12-01T09:13:14+00:00

UNDP’s over 22,000 staff members will get recorded lectures, interactive workshops

## Nothing Phone 2 Price in India Gets a Permanent Price Cut; Now Starts at Rs. 39,999
 - [https://www.gadgets360.com/mobiles/news/nothing-phone-2-price-in-india-drop-cut-rs-39999-44999-49999-specifications-4623921](https://www.gadgets360.com/mobiles/news/nothing-phone-2-price-in-india-drop-cut-rs-39999-44999-49999-specifications-4623921)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2023-12-01T08:58:35+00:00

Nothing Phone 2 is now up for grabs with revised price tags on Flipkart

## Realme GT 5 Pro Design Revealed; Teased to Offer 4,500 Nits Peak Brightness
 - [https://www.gadgets360.com/mobiles/news/realme-gt-5-pro-design-renders-first-look-display-specifications-launch-december-7-4623744](https://www.gadgets360.com/mobiles/news/realme-gt-5-pro-design-renders-first-look-display-specifications-launch-december-7-4623744)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2023-12-01T07:57:03+00:00

Realme GT 5 Pro teased to have curved Pro-XDR AMOLED 8T LTPO screen

## Threads Expands Keyword Search Feature to Users Globally in All Languages
 - [https://www.gadgets360.com/social-networking/news/threads-keyword-search-feature-expanded-users-languages-instagram-4623661](https://www.gadgets360.com/social-networking/news/threads-keyword-search-feature-expanded-users-languages-instagram-4623661)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2023-12-01T07:09:57+00:00

Threads users around the world can now search for posts in all languages

## Furiosa: A Mad Max Saga Trailer: Anya Taylor-Joy Takes on Chris Hemsworth in Post-Apocalyptic Wasteland
 - [https://www.gadgets360.com/entertainment/news/furiosa-a-mad-max-saga-trailer-release-date-cast-anya-taylor-joy-chris-hemsworth-hindi-warner-bros-4623643](https://www.gadgets360.com/entertainment/news/furiosa-a-mad-max-saga-trailer-release-date-cast-anya-taylor-joy-chris-hemsworth-hindi-warner-bros-4623643)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2023-12-01T07:05:46+00:00

Anya Taylor-Joy in and as Furiosa

## Apple Announces 2023 App Store Award Winners, Hiking App AllTrails Named iPhone App of the Year
 - [https://www.gadgets360.com/apps/news/apple-2023-app-store-awards-winners-announced-alltrails-honkai-star-rail-lies-of-p-iphone-ipad-mac-4623555](https://www.gadgets360.com/apps/news/apple-2023-app-store-awards-winners-announced-alltrails-honkai-star-rail-lies-of-p-iphone-ipad-mac-4623555)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2023-12-01T06:48:42+00:00

App Store Awards winners were picked from a list of 40 finalists

## These Three iPhone Features Make Technology More Accessible for Persons With Disabilities
 - [https://www.gadgets360.com/mobiles/features/apple-personal-voice-live-speech-assistive-access-accessibility-features-4623446](https://www.gadgets360.com/mobiles/features/apple-personal-voice-live-speech-assistive-access-accessibility-features-4623446)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2023-12-01T06:44:17+00:00

Live Speech and Personal Voice can also be used during FaceTime calls

## Crypto Price Today: Bitcoin Currently Trading at $38,000, Altcoins Show Mixed Movement
 - [https://www.gadgets360.com/cryptocurrency/news/bitcoin-price-today-december-1-usd-38000-altcoins-mixed-price-cryptocurrency-india-4623512](https://www.gadgets360.com/cryptocurrency/news/bitcoin-price-today-december-1-usd-38000-altcoins-mixed-price-cryptocurrency-india-4623512)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2023-12-01T06:19:32+00:00

The crypto market cap, as of December 1, stands at $1.44 trillion

## OnePlus 12 With Snapdragon 8 Gen 3 SoC Allegedly Tops AnTuTu Benchmark With 2.3 Million Points
 - [https://www.gadgets360.com/mobiles/news/oneplus-12-tops-antutu-benchmark-ranking-launch-december-5-specifications-leak-weibo-4623421](https://www.gadgets360.com/mobiles/news/oneplus-12-tops-antutu-benchmark-ranking-launch-december-5-specifications-leak-weibo-4623421)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2023-12-01T06:12:05+00:00

OnePlus 12 will debut in Pale Green, Rock Black, and White colour options

## Samsung Galaxy S24 Series RAM Variants Tipped; Phones Reportedly Spotted on FCC Site
 - [https://www.gadgets360.com/mobiles/news/samsung-galaxy-s24-plus-ultra-ram-variants-leak-fcc-listing-4623285](https://www.gadgets360.com/mobiles/news/samsung-galaxy-s24-plus-ultra-ram-variants-leak-fcc-listing-4623285)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2023-12-01T04:51:51+00:00

Samsung Galaxy S23 series (pictured) was introduced in February this year

## Apple Releases iOS 17.1.2, macOS Sonoma 14.1.2 With Security Updates, Fixes for WebKit Flaws
 - [https://www.gadgets360.com/mobiles/news/ios-17-1-2-macos-sonoma-14-1-2-update-released-security-fix-webkit-flaws-apple-4623170](https://www.gadgets360.com/mobiles/news/ios-17-1-2-macos-sonoma-14-1-2-update-released-security-fix-webkit-flaws-apple-4623170)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2023-12-01T04:25:42+00:00

Apple released iOS 17 for all users in September alongside the new iPhone 15 series

