# Source:RT - Daily news, URL:https://www.rt.com/rss/, language:en

## Meta struggling to control pedophiles – WSJ
 - [https://www.rt.com/news/588369-meta-facebook-instagram-child-abuse/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/588369-meta-facebook-instagram-child-abuse/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T23:44:51+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/656a6f5785f540198414bb70.jpg" style="margin-right: 10px;" /> Child sex abuse and exploitation is still a problem on Instagram and Facebook, months after the Wall Street Journal first reported it <br /><a href="https://www.rt.com/news/588369-meta-facebook-instagram-child-abuse/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## US threatens to ‘pause’ sanctions relief for Venezuela
 - [https://www.rt.com/news/588370-us-threatens-to-reimpose-venezuela-sanctons/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/588370-us-threatens-to-reimpose-venezuela-sanctons/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T22:52:39+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/656a611d85f54026ae147748.jpg" style="margin-right: 10px;" /> White House says Venezuela must make more progress in meeting US demands to avoid halt to sanctions relief <br /><a href="https://www.rt.com/news/588370-us-threatens-to-reimpose-venezuela-sanctons/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Farmers protest proposed dog-eating ban (VIDEOS)
 - [https://www.rt.com/news/588368-korean-dog-meat-protest-ban/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/588368-korean-dog-meat-protest-ban/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T22:17:04+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/656a52442030271c1b11e9f8.jpeg" style="margin-right: 10px;" /> South Korean dog farmers clashed with police when they took to the streets to protest a ban on their livelihood <br /><a href="https://www.rt.com/news/588368-korean-dog-meat-protest-ban/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## US sanctions will last ‘for many years’ – Kremlin
 - [https://www.rt.com/russia/588367-kremlin-us-sanctions-reaction/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/588367-kremlin-us-sanctions-reaction/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T21:31:45+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/656a4d4d20302759290725f6.jpg" style="margin-right: 10px;" /> While the US may be committed to maintaining its illegal embargo on Russia, there is a world elsewhere, President Putin’s spokesman has said <br /><a href="https://www.rt.com/russia/588367-kremlin-us-sanctions-reaction/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## History-making American judge dies
 - [https://www.rt.com/news/588365-sandra-day-oconnor-obit/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/588365-sandra-day-oconnor-obit/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T21:05:55+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/656a41a785f5402b93405c3e.jpg" style="margin-right: 10px;" /> Retired US Supreme Court Justice Sandra Day O’Connor dies at age 93 <br /><a href="https://www.rt.com/news/588365-sandra-day-oconnor-obit/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Ukraine has lost up to 300,000 soldiers – ex-Zelensky aide
 - [https://www.rt.com/russia/588358-ukraine-losses-zelensky-aide/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/588358-ukraine-losses-zelensky-aide/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T21:03:56+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/656a49bf2030271c0622b6b8.jpg" style="margin-right: 10px;" /> Kiev has lost up to 300,000 soldiers due to its refusal to talk with Moscow, former presidential aide Aleksey Arestovich has said <br /><a href="https://www.rt.com/russia/588358-ukraine-losses-zelensky-aide/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## EU sets new military spending record
 - [https://www.rt.com/news/588364-eu-record-military-spending/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/588364-eu-record-military-spending/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T20:21:10+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/656a3f4885f54076b81d115a.jpg" style="margin-right: 10px;" /> The EU increased its combined military spending to a record $261 billion in 2022, according to new figures from Brussels <br /><a href="https://www.rt.com/news/588364-eu-record-military-spending/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russia reveals new size of army
 - [https://www.rt.com/russia/588359-putin-expands-army-size/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/588359-putin-expands-army-size/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T19:43:01+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/656a36fe85f5400fa737f3b3.jpg" style="margin-right: 10px;" /> President Vladimir Putin has expanded the armed forces by 170,000 members, for a total of 1.32 million troops <br /><a href="https://www.rt.com/russia/588359-putin-expands-army-size/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## US ally to retire fighter jet struck by bird
 - [https://www.rt.com/news/588360-south-korea-retires-damaged-f35-jet/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/588360-south-korea-retires-damaged-f35-jet/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T19:35:28+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/656a2a4c2030273d945bc198.jpg" style="margin-right: 10px;" /> South Korea will scrap a US-made F-35 fighter jet damaged by a bird because repair costs would exceed the purchase price <br /><a href="https://www.rt.com/news/588360-south-korea-retires-damaged-f35-jet/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Foreign-born percentage of US population reaches record high – think tank
 - [https://www.rt.com/news/588363-us-immigrant-population-record-high/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/588363-us-immigrant-population-record-high/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T19:22:08+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/656a30dc20302737540676c5.jpeg" style="margin-right: 10px;" /> The total immigrant population of the US has reached 49.5 million due to the policies of Joe Biden, the Center for Immigration Studies said <br /><a href="https://www.rt.com/news/588363-us-immigrant-population-record-high/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Zelensky rival says he’s banned from leaving Ukraine
 - [https://www.rt.com/russia/588355-poroshenko-ukraine-poland-border/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/588355-poroshenko-ukraine-poland-border/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T18:42:18+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/656a130b85f54012446c3f45.jpg" style="margin-right: 10px;" /> Former president Poroshenko said he was on his way to Poland and the US to negotiate more aid for Kiev when border guards stopped him <br /><a href="https://www.rt.com/russia/588355-poroshenko-ukraine-poland-border/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russia’s LGBT ban explained
 - [https://www.rt.com/russia/588339-russian-lgbt-ban-explained/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/588339-russian-lgbt-ban-explained/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T18:26:13+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/656a24fe20302737540676bd.jpg" style="margin-right: 10px;" /> The Supreme Court of Russia has outlawed the “international LGBT movement,” branding it an extremist group <br /><a href="https://www.rt.com/russia/588339-russian-lgbt-ban-explained/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## US politician expelled from Congress
 - [https://www.rt.com/news/588356-santos-expelled-from-us-congress/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/588356-santos-expelled-from-us-congress/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T17:44:11+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/656a18c32030273f255ef282.jpg" style="margin-right: 10px;" /> US House lawmakers voted to expel Representative George Santos after he was accused of fraud and lying about his background <br /><a href="https://www.rt.com/news/588356-santos-expelled-from-us-congress/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Ronaldo faces billion-dollar lawsuit for endorsing worthless NFTs
 - [https://www.rt.com/business/588344-cristiano-ronaldo-lawsuit-binance-crypto/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/588344-cristiano-ronaldo-lawsuit-binance-crypto/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T17:23:56+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6569f4732030273d945bc175.jpg" style="margin-right: 10px;" /> Football sensation Cristiano Ronaldo is facing a class-action lawsuit stemming from his endorsement of cryptocurrency exchange Binance <br /><a href="https://www.rt.com/business/588344-cristiano-ronaldo-lawsuit-binance-crypto/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## US vows to halve Russia’s energy revenues by 2030
 - [https://www.rt.com/business/588354-us-russia-energy-sanctions/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/588354-us-russia-energy-sanctions/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T17:15:55+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/656a111f85f540346b3b1ff5.jpg" style="margin-right: 10px;" /> The US will stick to its sanctions on Russian energy in a bid to harm the country’s economy “for years to come,” a senior official has said <br /><a href="https://www.rt.com/business/588354-us-russia-energy-sanctions/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Over 109 Palestinians killed since ceasefire ended – Gaza
 - [https://www.rt.com/news/588353-gaza-civilians-killed-israel-ceasefire/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/588353-gaza-civilians-killed-israel-ceasefire/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T16:34:46+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/656a0a4a20302737a91353bf.jpeg" style="margin-right: 10px;" /> More than 109 Palestinians have been killed in Israeli airstrikes less than 24 hours after a week-long ceasefire, Gaza officials say <br /><a href="https://www.rt.com/news/588353-gaza-civilians-killed-israel-ceasefire/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Modi urges more ‘decisive’ steps to fight global warming
 - [https://www.rt.com/india/588347-modi-india-host-climate-conference/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/india/588347-modi-india-host-climate-conference/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T16:26:48+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6569f02a85f540346b3b1fe5.jpg" style="margin-right: 10px;" /> Narendra Modi has highlighted the disparity in contributions to climate action and the need for every nation to stick to commitments <br /><a href="https://www.rt.com/india/588347-modi-india-host-climate-conference/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Blinken and Borrell ‘chickened out’ of talking to Russia – Lavrov
 - [https://www.rt.com/russia/588346-blinken-borrell-scared-talking-russia/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/588346-blinken-borrell-scared-talking-russia/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T15:50:48+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6569ee452030273d945bc161.jpg" style="margin-right: 10px;" /> Top US and EU diplomats were too scared to engage in frank talks with Moscow at the OSCE, Sergey Lavrov has said <br /><a href="https://www.rt.com/russia/588346-blinken-borrell-scared-talking-russia/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russian ships loaded with free grain have started reaching Africa. What you need to know
 - [https://www.rt.com/russia/588351-free-russian-grain-africa/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/588351-free-russian-grain-africa/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T15:44:31+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6569fc2920302738b9487810.jpg" style="margin-right: 10px;" /> Russia has delivered the first batches of free grain to African nations under an aid program announced by President Vladimir Putin <br /><a href="https://www.rt.com/russia/588351-free-russian-grain-africa/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Orban suggests putting off Ukraine’s EU membership
 - [https://www.rt.com/news/588349-hungary-orban-postpone-ukraine-eu-membership/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/588349-hungary-orban-postpone-ukraine-eu-membership/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T15:44:24+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6569f5f485f540204f25ffc2.jpg" style="margin-right: 10px;" /> Hungarian PM Viktor Orban suggests postponing accession talks with Ukraine by several years and opting for a strategic partnership for now <br /><a href="https://www.rt.com/news/588349-hungary-orban-postpone-ukraine-eu-membership/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Trump can be sued for Capitol riot, court rules
 - [https://www.rt.com/news/588352-trump-court-presidential-immunity/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/588352-trump-court-presidential-immunity/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T15:44:02+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6569fdd720302759290725be.jpg" style="margin-right: 10px;" /> A Washington DC court has ruled that former President Donald Trump is not immune to lawsuits over the Capitol Hill riot of 2021 <br /><a href="https://www.rt.com/news/588352-trump-court-presidential-immunity/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## RT SPANISH WINS MEXICAN PRESS CLUB AWARDS
 - [https://www.rt.com/about-us/press-releases/rt-spanish-mexican-press-club-awards/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/about-us/press-releases/rt-spanish-mexican-press-club-awards/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T15:16:51+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6569f80485f5400a7d709af5.jpg" style="margin-right: 10px;" />  <br /><a href="https://www.rt.com/about-us/press-releases/rt-spanish-mexican-press-club-awards/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Kiev’s counteroffensive casualties top 125,000 – Moscow
 - [https://www.rt.com/russia/588340-shoigu-ukrainian-casualties-counteroffensive/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/588340-shoigu-ukrainian-casualties-counteroffensive/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T15:01:55+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6569e0ad85f5400a7d709ae7.jpg" style="margin-right: 10px;" /> Russian Defense Minister Sergey Shoigu has given an updated estimate of Ukraine’s battlefield losses <br /><a href="https://www.rt.com/russia/588340-shoigu-ukrainian-casualties-counteroffensive/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## German car industry concerned by Ukraine blockade – Bild
 - [https://www.rt.com/news/588348-germany-car-industry-ukraine-blockade/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/588348-germany-car-industry-ukraine-blockade/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T15:00:24+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6569f4ee203027575f2e99c2.jpg" style="margin-right: 10px;" /> The Polish trucker blockade of border crossings with Ukraine threatens vital supply lines for the car industry, writes Bild  <br /><a href="https://www.rt.com/news/588348-germany-car-industry-ukraine-blockade/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Israel plans global assassination campaign – WSJ
 - [https://www.rt.com/news/588345-mossad-hamas-assassination-plan/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/588345-mossad-hamas-assassination-plan/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T14:30:49+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6569ed57203027575f2e99b4.jpg" style="margin-right: 10px;" /> Israeli spies are preparing to assassinate Hamas leaders in Lebanon, Türkiye, and Qatar, the Wall Street Journal has reported <br /><a href="https://www.rt.com/news/588345-mossad-hamas-assassination-plan/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Another BRICS member to join OPEC+
 - [https://www.rt.com/business/588342-brazil-opec-membership/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/588342-brazil-opec-membership/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T14:22:57+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6569e7ee85f54030c05934f8.jpg" style="margin-right: 10px;" /> Brazil is set to become a member of the OPEC+ group of oil-producing countries led by Russia and Saudi Arabia in 2024 <br /><a href="https://www.rt.com/business/588342-brazil-opec-membership/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Somalia receives free wheat from Moscow
 - [https://www.rt.com/africa/588341-somalia-russia-food-aid-delivery/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/africa/588341-somalia-russia-food-aid-delivery/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T14:06:57+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6569e5aa20302759290725b4.jpg" style="margin-right: 10px;" /> Russia’s ambassador to Somalia has handed over a cargo of free food to the African country <br /><a href="https://www.rt.com/africa/588341-somalia-russia-food-aid-delivery/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russia considers banning cellphones in schools
 - [https://www.rt.com/russia/588335-russian-mps-bill-ban-cell-phones-schools/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/588335-russian-mps-bill-ban-cell-phones-schools/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T13:22:51+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6569ca4385f5402b93405c1a.jpg" style="margin-right: 10px;" /> Several Russian lawmakers have introduced an amendment that seeks to ban the use of cellphones in schools, even for educational purposes <br /><a href="https://www.rt.com/russia/588335-russian-mps-bill-ban-cell-phones-schools/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## India’s appetite for Russian oil growing – Kpler
 - [https://www.rt.com/india/588325-india-oil-imports-russia/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/india/588325-india-oil-imports-russia/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T13:18:49+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6569cb15203027375406768d.jpg" style="margin-right: 10px;" /> Indian refiners have ramped up purchases of Russian and Iraqi crude amid growing demand, Bloomberg reports <br /><a href="https://www.rt.com/india/588325-india-oil-imports-russia/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## West’s ‘breakdancing’ is blocking Ukraine peace hopes – Lavrov
 - [https://www.rt.com/russia/588338-west-breakdance-block-ukraine-peace/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/588338-west-breakdance-block-ukraine-peace/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T13:05:34+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6569d98985f5401b163040b5.jpg" style="margin-right: 10px;" /> Kiev and its Western backers are unwilling to “tango” with Moscow to resolve the Ukraine conflict, Sergey Lavrov has said <br /><a href="https://www.rt.com/russia/588338-west-breakdance-block-ukraine-peace/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russians’ three greatest fears revealed
 - [https://www.rt.com/russia/588333-russians-main-worries-poll/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/588333-russians-main-worries-poll/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T12:36:40+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6569c81d85f5400c1c4b0e75.jpg" style="margin-right: 10px;" /> A new poll by NAFI research and VSK insurance asked people in Russia about their main worries heading into the New Year <br /><a href="https://www.rt.com/russia/588333-russians-main-worries-poll/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russia takes control of major airport from foreign shareholders
 - [https://www.rt.com/business/588329-pulkovo-airport-putin-decree/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/588329-pulkovo-airport-putin-decree/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T12:19:34+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6569c0552030273754067683.jpg" style="margin-right: 10px;" /> President Vladimir Putin signed a decree transferring all foreign-held shares of St. Petersburg’s Pulkovo Airport to Russian management

  <br /><a href="https://www.rt.com/business/588329-pulkovo-airport-putin-decree/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Zelensky assesses results of counteroffensive
 - [https://www.rt.com/russia/588336-zelensky-ukraine-not-retreating/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/588336-zelensky-ukraine-not-retreating/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T12:10:48+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6569cc1685f54017df7a9ab3.jpg" style="margin-right: 10px;" /> Ukrainian President Vladimir Zelensky is “satisfied” that his troops are not currently in retreat <br /><a href="https://www.rt.com/russia/588336-zelensky-ukraine-not-retreating/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Zelensky urges Western loans for Ukrainian arms self-sufficiency
 - [https://www.rt.com/russia/588332-zelensky-western-loans-defense/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/588332-zelensky-western-loans-defense/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T12:02:56+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6569ca2a20302738b9487800.jpg" style="margin-right: 10px;" /> Ukrainian President Vladimir Zelensky has urged Western nations to fund a buildup of the defense industry in his nation <br /><a href="https://www.rt.com/russia/588332-zelensky-western-loans-defense/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## China helps BRICS partner solve power outages – media
 - [https://www.rt.com/africa/588331-china-south-africa-energy/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/africa/588331-china-south-africa-energy/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T11:29:44+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6569c12985f540191d5b817f.jpg" style="margin-right: 10px;" /> China has donated 450 gasoline generators to South Africa to deal with electricity shortages <br /><a href="https://www.rt.com/africa/588331-china-south-africa-energy/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Suspect in ‘Ukrainian terrorist train attack’ detained – Moscow
 - [https://www.rt.com/russia/588328-suspect-ukraine-train-attack-detained/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/588328-suspect-ukraine-train-attack-detained/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T11:11:51+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6569bed8203027324e632559.jpg" style="margin-right: 10px;" /> Russian security services have arrested an alleged Ukraine-linked saboteur responsible for two attacks in Ryazan Region <br /><a href="https://www.rt.com/russia/588328-suspect-ukraine-train-attack-detained/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Biden promises return to Angola
 - [https://www.rt.com/africa/588324-biden-angola-trip-plans/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/africa/588324-biden-angola-trip-plans/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T10:33:41+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6569b1e1203027431264fb54.jpg" style="margin-right: 10px;" /> US President Joe Biden has hinted at a trip to Angola but provided no specifics <br /><a href="https://www.rt.com/africa/588324-biden-angola-trip-plans/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## OPEC+ to extend oil output cuts
 - [https://www.rt.com/business/588323-opec-extends-oil-output-cuts/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/588323-opec-extends-oil-output-cuts/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T10:09:11+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6569ade485f5401e207c8342.jpg" style="margin-right: 10px;" /> Oil-producing countries from OPEC+ have agreed to a significant additional production cut of 1 million barrels a day <br /><a href="https://www.rt.com/business/588323-opec-extends-oil-output-cuts/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Ministerial offical fired after signing accord with fake country
 - [https://www.rt.com/news/588321-paraguayan-official-dismissed-fake-country-accord/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/588321-paraguayan-official-dismissed-fake-country-accord/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T09:48:32+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6569a3c92030273d945bc134.jpg" style="margin-right: 10px;" /> Paraguay’s Ministry of Agriculture has sacked its chief of staff, Arnaldo Chamorro, for signing a treaty with a fictitious nation <br /><a href="https://www.rt.com/news/588321-paraguayan-official-dismissed-fake-country-accord/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## VDNH’s ‘House of Russian Cuisine’ hosts gastronomic presentations by several Russian regions
 - [https://www.rt.com/pop-culture/588317-vdnh-house-russian-cuisine/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/pop-culture/588317-vdnh-house-russian-cuisine/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T09:42:43+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6569a59a2030274f0a7e7d1a.png" style="margin-right: 10px;" />  <br /><a href="https://www.rt.com/pop-culture/588317-vdnh-house-russian-cuisine/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## White House demands accountability over Indian assassination plot
 - [https://www.rt.com/india/588322-us-indian-assasination-plot/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/india/588322-us-indian-assasination-plot/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T09:39:50+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6569a6c385f5401e207c8338.jpg" style="margin-right: 10px;" /> A senior US official says Washington is taking allegations of New Delhi’s involvement in an assassination plot “seriously” <br /><a href="https://www.rt.com/india/588322-us-indian-assasination-plot/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## More explosive power used against Gaza in a month than on Hiroshima (VIDEO)
 - [https://www.rt.com/news/588318-israel-gaza-bombing-report/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/588318-israel-gaza-bombing-report/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T09:27:28+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6569a6682030273d945bc13b.jpg" style="margin-right: 10px;" /> RT’s Steve Sweeney examines a UN report claiming the death toll from Israel’s Gaza assault exceeds that from years of US bombings campaigns <br /><a href="https://www.rt.com/news/588318-israel-gaza-bombing-report/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## WATCH: More explosive power used against Gaza in a month than on Hiroshima
 - [https://www.rt.com/news/588318-israel-gaza-bombimg-report/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/588318-israel-gaza-bombimg-report/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T09:27:28+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6569a6682030273d945bc13b.jpg" style="margin-right: 10px;" /> RT’s Steve Sweeney examines a UN report claiming the death toll from Israel’s Gaza assault exceeds that from years of US bombings campaigns <br /><a href="https://www.rt.com/news/588318-israel-gaza-bombimg-report/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Israel knew of Hamas attack plan one year in advance – NYT
 - [https://www.rt.com/news/588319-hamas-attack-blueprint-nyt/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/588319-hamas-attack-blueprint-nyt/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T09:16:59+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/65699147203027592907258b.jpg" style="margin-right: 10px;" /> A Hamas blueprint for an attack on Israel accurately predicted details of the October 7 raid, the New York Times has reported <br /><a href="https://www.rt.com/news/588319-hamas-attack-blueprint-nyt/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## WATCH Russian kamikaze drone destroying Ukrainian warplane
 - [https://www.rt.com/russia/588320-russian-drone-strike-ukraine-jet/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/588320-russian-drone-strike-ukraine-jet/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T08:29:31+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6569985f203027324e63254d.jpg" style="margin-right: 10px;" /> A Russian Lancet kamikaze drone has destroyed a Ukrainian Su-25 warplane in Dnepropetrovsk Region, a new video shows <br /><a href="https://www.rt.com/russia/588320-russian-drone-strike-ukraine-jet/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Ukraine to get $1.2 billion from World Bank
 - [https://www.rt.com/business/588309-worrld-bank-loan-ukraine/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/588309-worrld-bank-loan-ukraine/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T06:43:35+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6569800320302737a913536b.jpg" style="margin-right: 10px;" /> Japan has agreed to guarantee a $1.2 billion World Bank loan to Ukraine <br /><a href="https://www.rt.com/business/588309-worrld-bank-loan-ukraine/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Israel resumes operation against Gaza – IDF
 - [https://www.rt.com/news/588308-israel-operation-gaza-idf/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/588308-israel-operation-gaza-idf/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T05:23:44+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/656979c185f54030c05934cd.jpg" style="margin-right: 10px;" /> Israel says it has resumed combat against Hamas after accusing it of violating the Qatari-brokered ceasefire <br /><a href="https://www.rt.com/news/588308-israel-operation-gaza-idf/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russian tech giant to expand robot fleet
 - [https://www.rt.com/business/588262-russia-yandex-delivery-robots/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/588262-russia-yandex-delivery-robots/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T05:17:12+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/6568978a85f54019491dbbcd.jpg" style="margin-right: 10px;" /> Russia’s Yandex has announced plans to double the number of its delivery robots to 260 next year <br /><a href="https://www.rt.com/business/588262-russia-yandex-delivery-robots/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Britons want to exit Brexit – poll
 - [https://www.rt.com/business/588256-uk-brexit-eu-poll/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/588256-uk-brexit-eu-poll/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T05:17:03+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/65686be685f5400c1c4b0df3.jpg" style="margin-right: 10px;" /> A majority of Britons regret Brexit and want to rejoin the EU, even though it would restore the free movement of migrants, a poll says <br /><a href="https://www.rt.com/business/588256-uk-brexit-eu-poll/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Man charged for anti-Semitic threats against US senators
 - [https://www.rt.com/news/588307-antisemitic-threats-us-senators/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/588307-antisemitic-threats-us-senators/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T05:16:38+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/656962b685f54019491dbbff.jpg" style="margin-right: 10px;" /> A US federal grand jury has agreed to indict a man accused of making anti-Jewish threats against Jacky Rosen and another US senator <br /><a href="https://www.rt.com/news/588307-antisemitic-threats-us-senators/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Beijing too busy to occupy Taiwan – local leader
 - [https://www.rt.com/news/588306-beijing-busy-invade-taiwan/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/588306-beijing-busy-invade-taiwan/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T03:14:32+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/65694e7985f540191d5b8161.jpg" style="margin-right: 10px;" /> The government in Beijing is too “overwhelmed” with domestic issues to launch an attack on Taiwan, the island’s leader Tsai Ing-wen said <br /><a href="https://www.rt.com/news/588306-beijing-busy-invade-taiwan/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## British NGO blasts Russia’s LGBT ban
 - [https://www.rt.com/news/588305-amnesty-blasts-russia-lgbt-ban/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/588305-amnesty-blasts-russia-lgbt-ban/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T02:26:19+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6569440585f5400c1c4b0e43.jpg" style="margin-right: 10px;" /> Amnesty International has condemned Russia’s ban on the “LGBT movement” <br /><a href="https://www.rt.com/news/588305-amnesty-blasts-russia-lgbt-ban/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## The new ‘Chinese disease’ panic is upon us
 - [https://www.rt.com/news/588296-china-pneumonia-disease-panic/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/588296-china-pneumonia-disease-panic/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T01:18:50+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6569344285f540191d5b815e.jpg" style="margin-right: 10px;" /> With Covid-19 being old news, China detractors will take every opportunity to portray an ordinary winter outbreak as something sinister <br /><a href="https://www.rt.com/news/588296-china-pneumonia-disease-panic/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## US lawmaker saves colleague from choking
 - [https://www.rt.com/news/588304-rand-paul-saves-colleague/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/588304-rand-paul-saves-colleague/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-01T00:10:01+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.11/thumbnail/656921182030275bbc0ea17b.jpg" style="margin-right: 10px;" /> US Senator Rand Paul has saved his colleague Joni Ernst from choking on food at a lunch meeting in Washington <br /><a href="https://www.rt.com/news/588304-rand-paul-saves-colleague/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

