# Source:TVN24 Z kraju, URL:https://tvn24.pl/wiadomosci-z-kraju,3.xml, language:pl-PL

## Krążą plotki, że jest jedna rzecz, która przekona Orbana, żeby nie zablokować wsparcia UE dla Ukrainy
 - [https://fakty.tvn24.pl/fakty-o-swiecie/kraza-plotki-ze-jest-jedna-rzecz-ktora-przekona-orbana-zeby-nie-zablokowac-wsparcia-ue-dla-ukrainy-st7465290?source=rss](https://fakty.tvn24.pl/fakty-o-swiecie/kraza-plotki-ze-jest-jedna-rzecz-ktora-przekona-orbana-zeby-nie-zablokowac-wsparcia-ue-dla-ukrainy-st7465290?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-01T21:20:14+00:00

<img alt="Krążą plotki, że jest jedna rzecz, która przekona Orbana, żeby nie zablokować wsparcia UE dla Ukrainy" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-2uzkbh-0112b080x-fos-los-wegry-zenex-002440-7465226/alternates/LANDSCAPE_1280" />
    Szczyt Rady Europejskiej w grudniu będzie bardzo istotny i nie chodzi tylko o to, kto będzie na nim reprezentował Polskę. Chodzi o płynność finansową Ukrainy. Przywódcy mają na nim przyklepać 50 miliardów euro pomocy dla tego kraju. Problem w tym, że konsekwentnie przeciwny temu jest Viktor Orban. Ta decyzja Unii wymaga jednomyślności. W Brukseli spekuluje się, że premier Węgier za zrezygnowanie z weta w sprawie Ukrainy chce 13 miliardów euro z unijnych funduszy dla swojego kraju.

## Rosja: aktywiści na rzecz praw LGBT+ zostali uznani za ekstremistów. "Sytuacja się tylko pogorszy"
 - [https://fakty.tvn24.pl/fakty-o-swiecie/rosja-aktywisci-na-rzecz-praw-lgbt-zostali-uznani-za-ekstremistow-sytuacja-sie-tylko-pogorszy-st7465276?source=rss](https://fakty.tvn24.pl/fakty-o-swiecie/rosja-aktywisci-na-rzecz-praw-lgbt-zostali-uznani-za-ekstremistow-sytuacja-sie-tylko-pogorszy-st7465276?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-01T21:06:22+00:00

<img alt="Rosja: aktywiści na rzecz praw LGBT+ zostali uznani za ekstremistów. " src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-xpz8w8-zuber-reuters-001054-7465228/alternates/LANDSCAPE_1280" />
    Putin ma kolejnego wroga. To osoby z tęczową flagą. Rosyjski Sąd Najwyższy uznał ruchy na rzecz LGBT za ekstremistyczne. W marcu w Rosji są wybory prezydenckie. Społeczeństwo musi się bać, by popierać dyktatora.

## Znamy majątek marszałka Sejmu
 - [https://tvn24.pl/biznes/z-kraju/szymon-holownia-oswiadczenie-majatkowe-znamy-majatek-marszalka-sejmu-st7465197?source=rss](https://tvn24.pl/biznes/z-kraju/szymon-holownia-oswiadczenie-majatkowe-znamy-majatek-marszalka-sejmu-st7465197?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-01T18:51:01+00:00

<img alt="Znamy majątek marszałka Sejmu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-aws0bm-szymon-holownia-w-bialymstoku-7453667/alternates/LANDSCAPE_1280" />
    Szymon Hołownia do oświadczenia majątkowego wpisał między innymi dom, mieszkanie, siedlisko wiejskie oraz dwa kredyty hipoteczne. Jako składniki mienia ruchomego marszałek Sejmu wymienił współczesną ikonę i obraz.

## Rekordowa kwota w 11. edycji budżetu obywatelskiego. Można już składać wnioski
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-budzet-obywatelski-11-edycja-terminy-jak-zglosic-projekt-st7465140?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-budzet-obywatelski-11-edycja-terminy-jak-zglosic-projekt-st7465140?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-01T18:46:09+00:00

<img alt="Rekordowa kwota w 11. edycji budżetu obywatelskiego. Można już składać wnioski" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-fhtrih-projekty-do-budzetu-obywatelskiego-zdjecie-ilustracyjne-7224146/alternates/LANDSCAPE_1280" />
    Wystartowała 11. edycja budżetu obywatelskiego. Od 1 grudnia do 25 stycznia można składać projekty, zarówno online, jak i w urzędzie dzielnicy. Do dyspozycji mieszkańców przeznaczono rekordową kwotę 105 milionów 782 tysięcy 530 złotych.

## Pogoda na jutro - sobota 02.12. Obfite opady śniegu w dużej części kraju
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-jutro-sobota-0212-obfite-opady-sniegu-w-duzej-czesci-kraju-st7465139?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-jutro-sobota-0212-obfite-opady-sniegu-w-duzej-czesci-kraju-st7465139?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-01T18:39:34+00:00

<img alt="Pogoda na jutro - sobota 02.12. Obfite opady śniegu w dużej części kraju " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-9vj8fl-intensywne-opady-sniegu-7465187/alternates/LANDSCAPE_1280" />
    W nocy z piątku na sobotę i w sobotę na południu kraju będą występować intensywne opady śniegu. Termometry w ciągu dnia wskażą od -3 do 0 stopni Celsjusza.

## Z dwoma promilami i dożywotnim zakazem kierował autem
 - [https://tvn24.pl/tvnwarszawa/okolice/otwock-z-dwoma-promilami-i-dozywotnim-zakazem-kierowal-autem-st7465094?source=rss](https://tvn24.pl/tvnwarszawa/okolice/otwock-z-dwoma-promilami-i-dozywotnim-zakazem-kierowal-autem-st7465094?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-01T17:57:43+00:00

<img alt="Z dwoma promilami i dożywotnim zakazem kierował autem" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-s6r6cq-mial-dwa-promile-w-organizmie-i-dozywotni-zakaz-prowadzenia-aut-7465096/alternates/LANDSCAPE_1280" />
    Policjanci zatrzymali kierowcę bmw, który podczas kontroli trzeźwości "wydmuchał" ponad dwa promile alkoholu. Po sprawdzeniu w systemie okazało się, że ma już dożywotni zakaz prowadzenia pojazdów. 64-latkowi grozi do pięciu lat pozbawienia wolności.

## Defilada wojskowa w Bukareszcie. Był też polski akcent
 - [https://tvn24.pl/swiat/bukareszt-rumunia-defilada-z-okazji-swieta-narodowego-byli-tez-polscy-zolnierze-na-transporterach-rosomak-7464988?source=rss](https://tvn24.pl/swiat/bukareszt-rumunia-defilada-z-okazji-swieta-narodowego-byli-tez-polscy-zolnierze-na-transporterach-rosomak-7464988?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-01T17:38:47+00:00

<img alt="Defilada wojskowa w Bukareszcie. Był też polski akcent" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qf66zw-defilada-wojskowa-w-rumunii-7465070/alternates/LANDSCAPE_1280" />
    W związku ze świętem narodowym Rumunii, Dniem Wielkiej Unii, w Bukareszcie odbyła się defilada wojskowa. Obok rumuńskich pododdziałów, sprzętu wojskowego i samolotów, mieszkańcy stolicy mogli oglądać również przemarsz żołnierzy z państw członkowskich NATO, w tym Polaków na transporterach Rosomak. W obchodach, jak podają media, wzięła udział rekordowa liczba 100 tysięcy mieszkańców.

## Przebił barierki na parkingu i spadł na drogę dojazdową
 - [https://tvn24.pl/katowice/przebil-barierki-na-parkingu-i-spadl-na-droge-dojazdowa-7464956?source=rss](https://tvn24.pl/katowice/przebil-barierki-na-parkingu-i-spadl-na-droge-dojazdowa-7464956?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-01T17:04:44+00:00

<img alt="Przebił barierki na parkingu i spadł na drogę dojazdową" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1zpe4x-zdarzenie-w-sosnowcu-przy-drodze-krajowej-94-7464955/alternates/LANDSCAPE_1280" />
    Kierowca hyundaia uderzył na parkingu w barierki ochronne i spadł na drogę zjazdową z DK 94. Na szczęście wtedy pustą. Skończyło się na strachu, uszkodzeniach auta i mandacie. Policjanci apelują, by dostosować prędkość samochodu do warunków panujących na drodze oraz o ostrożną jazdę.

## Nowa zapowiedź PiS. "Dlaczego pan premier nie wspomniał o totalnej destabilizacji rynku"
 - [https://tvn24.pl/biznes/nieruchomosci/bezpieczny-kredyt-2-procent-zapowiedz-premiera-damian-kazmierczak-z-pzpb-komentuje-st7464968?source=rss](https://tvn24.pl/biznes/nieruchomosci/bezpieczny-kredyt-2-procent-zapowiedz-premiera-damian-kazmierczak-z-pzpb-komentuje-st7464968?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-01T16:37:52+00:00

<img alt="Nowa zapowiedź PiS. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-k6frx1-nieruchomosci-mieszkania-deweloper-deweloperzy-kredyt-hipoteczny-budowa-7192354/alternates/LANDSCAPE_1280" />
    Program Bezpieczny kredyt 2 procent cieszy głównie deweloperów i aktywnych inwestorów, a odcina od rynku ogromną rzeszę potencjalnych nabywców, których na nowe mieszkania po wzroście cen po prostu nie stać - stwierdził Damian Kaźmierczak, członek zarządu Polskiego Związku Pracodawców Budownictwa (PZPB). W piątek rząd przyjął projekt zwiększający około dwukrotnie środki na program Bezpieczny kredyt 2 procent.

## Ważna zmiana w zakazie handlu. Tak ma wyglądać grudniowy kalendarz
 - [https://tvn24.pl/biznes/z-kraju/zmiany-w-zakazie-handlu-tak-ma-wygladac-kalendarz-handlowy-na-grudzien-2023-st7464931?source=rss](https://tvn24.pl/biznes/z-kraju/zmiany-w-zakazie-handlu-tak-ma-wygladac-kalendarz-handlowy-na-grudzien-2023-st7464931?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-01T15:52:40+00:00

<img alt="Ważna zmiana w zakazie handlu. Tak ma wyglądać grudniowy kalendarz" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8ywiat-shutterstock_2136216415-7464959/alternates/LANDSCAPE_1280" />
    Jeśli zaakceptowana przez parlament ustawa zyska aprobatę prezydenta Andrzeja Dudy, zmieni się kalendarz handlowy w grudniu. Przygotowana przez posłów nowelizacja miała związek z faktem, że Wigilia w tym roku wypada w niedzielę i zgodnie z obecnymi przepisami mógłby być tego dnia prowadzony handel w większych sieciach.

## Powstał plan miejscowy dla Parku Ujazdowskiego i jego okolic, ruszają konsultacje
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-plan-miejscowy-dla-parku-ujazdowskiego-i-jego-okolic-co-zawiera-konsultacje-spoleczne-terminy-st7464841?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-plan-miejscowy-dla-parku-ujazdowskiego-i-jego-okolic-co-zawiera-konsultacje-spoleczne-terminy-st7464841?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-01T14:59:12+00:00

<img alt="Powstał plan miejscowy dla Parku Ujazdowskiego i jego okolic, ruszają konsultacje" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-xpdp24-osiedle-jazdow-7464906/alternates/LANDSCAPE_1280" />
    Powstał plan miejscowy dla rejonu Parku Ujazdowskiego. Co zawiera? Ochronę dla domków fińskich i Osiedla Jazdów, a także Parku Ujazdowskiego, czy Parku Tadeusza Mazowieckiego. Mieszkańcy będą mogli zabrać głos w sprawie planu ratusza. Ruszają konsultacje społeczne, które potrwają do 8 stycznia 2024 roku.

## Dzieci utknęły w niecce na terenie skateparku. Jeden z chłopców wezwał pomoc
 - [https://tvn24.pl/opole/opole-dzieci-utknely-w-niecce-na-terenie-skateparku-jeden-z-chlopcow-wezwal-pomoc-7464916?source=rss](https://tvn24.pl/opole/opole-dzieci-utknely-w-niecce-na-terenie-skateparku-jeden-z-chlopcow-wezwal-pomoc-7464916?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-01T14:54:15+00:00

<img alt="Dzieci utknęły w niecce na terenie skateparku. Jeden z chłopców wezwał pomoc" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-olwogi-dzieci-utknely-w-niecce-na-terenie-miejskiego-skateparku-7464911/alternates/LANDSCAPE_1280" />
    Troje dzieci w wieku 11 i 9 lat wpadło do stromej i zaśnieżonej niecki w skateparku i nie mogło się z niej wydostać. Jednemu z chłopców udało się wezwać pomoc, dzwoniąc na numer 112.

## Zaatakował kolegę nożem, odpowie za usiłowanie zabójstwa
 - [https://tvn24.pl/tvnwarszawa/okolice/pniewy-grojec-pili-razem-alkohol-doszlo-do-klotni-w-pewnym-momencie-jeden-zaatakowal-drugiego-nozem-st7464723?source=rss](https://tvn24.pl/tvnwarszawa/okolice/pniewy-grojec-pili-razem-alkohol-doszlo-do-klotni-w-pewnym-momencie-jeden-zaatakowal-drugiego-nozem-st7464723?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-01T14:02:56+00:00

<img alt="Zaatakował kolegę nożem, odpowie za usiłowanie zabójstwa" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-6iagq1-dziadkowie-byli-pod-wplywem-alkoholu-5549841/alternates/LANDSCAPE_1280" />
    Policjanci interweniowali w okolicach Grójca. W jednym z domów trzy osoby piły alkohol. Pomiędzy mężczyznami doszło do kłótni. W pewnym momencie 53-latek zaatakował nożem 47-latka. Poszkodowany trafił do szpitala.

## Antroboty pomagają, ale nie wiadomo dlaczego
 - [https://tvn24.pl/swiat/usa-naukowcy-wynalezli-antroboty-roboty-z-ludzkich-komorek-7464405?source=rss](https://tvn24.pl/swiat/usa-naukowcy-wynalezli-antroboty-roboty-z-ludzkich-komorek-7464405?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-01T13:56:24+00:00

<img alt="Antroboty pomagają, ale nie wiadomo dlaczego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-u7ayv3-amerykanscy-naukowcy-stworzyli-antroboty-na-podstawie-ludzkich-komorek-7464744/alternates/LANDSCAPE_1280" />
    Czy to roboty, zwierzęta, a może maszyny? Takie pytania nie służą sprawie, powinniśmy wyjść ponad to - mówi Michael Levin, profesor biologii na jednej z uczelni w stanie Massachusetts (USA). Wraz ze swoim zespołem opracował metodę stworzenia mikroskopijnych robotów na bazie ludzkich komórek pozyskanych z tchawicy. Zdaniem naukowców cytowanych przez CNN, to kolejny krok w kierunku wykorzystania mikrorobotów w medycynie.

## Policja konfiskuje kobietom samochody. "Reakcja na ubiegłoroczne protesty"
 - [https://tvn24.pl/swiat/iran-policja-konfiskuje-kobietom-samochody-za-nienoszenie-hidzabu-7464777?source=rss](https://tvn24.pl/swiat/iran-policja-konfiskuje-kobietom-samochody-za-nienoszenie-hidzabu-7464777?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-01T13:52:11+00:00

<img alt="Policja konfiskuje kobietom samochody. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-h5kbyi-teheran-iran-adobestock_325238182_editorial_use_only-7464737/alternates/LANDSCAPE_1280" />
    Irańska policja konfiskuje kobietom samochody za nienoszenie za kierownicą hidżabu - donosi portal Iran International, dodając, że w Teheranie "zajęte zostały już setki aut". W ocenie portalu nasilenie kontroli przestrzegania przepisów nakazujących kobietom zakrywanie ciała i włosów jest następstwem protestów, które w 2022 roku przetoczyły się przez Iran.

## Alarmy przeciwrakietowe na północy Izraela. Ponad setka zakładników wciąż w rękach Hamasu
 - [https://tvn24.pl/swiat/izrael-alarmy-przeciwrakietowe-na-polnocy-izraela-hamas-przetrzymuje-ponad-stu-zakladnikow-7464729?source=rss](https://tvn24.pl/swiat/izrael-alarmy-przeciwrakietowe-na-polnocy-izraela-hamas-przetrzymuje-ponad-stu-zakladnikow-7464729?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-01T13:48:47+00:00

<img alt="Alarmy przeciwrakietowe na północy Izraela. Ponad setka zakładników wciąż w rękach Hamasu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ru1ptu-izraelska-armia-wznowila-dzialania-wojenne-w-strefie-gazy-7464760/alternates/LANDSCAPE_1280" />
    Kancelaria premiera Izraela Benjamina Netanjahu wyraziła w piątek przekonanie, że Hamas nadal  przetrzymuje 137 osób, porwanych w ataku z 7 października. Po zakończonym tygodniowym rozejmie, po południu w kilku miastach na północy Izraela znów słychać było syreny alarmowe.

## Autobusy linii 211 wracają na swoją trasę
 - [https://tvn24.pl/tvnwarszawa/ulice/autobusy-linii-211-wracaja-na-swoja-trase-st7464789?source=rss](https://tvn24.pl/tvnwarszawa/ulice/autobusy-linii-211-wracaja-na-swoja-trase-st7464789?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-01T13:46:42+00:00

<img alt="Autobusy linii 211 wracają na swoją trasę" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-fm267i-autobusy-linii-739-beda-kursowac-czesciej-zdjecie-ilustracyjne-7436488/alternates/LANDSCAPE_1280" />
    Zakończyła się modernizacja kolektora ściekowego na ulicy Myśliborskiej. Autobusy linii 211 od soboty 2 grudnia dojadą do pętli Żerań-FSO - poinformował Zarząd Transportu Miejskiego.

## Wdarła się do mieszkania sąsiadki, łamiąc zakaz zbliżania się. Trafiła do aresztu
 - [https://tvn24.pl/tvnwarszawa/okolice/ciechanow-wdarla-sie-do-mieszkania-sasiadki-i-kilkukrotnie-ja-uderzyla-zarzuty-dla-50-latki-st7464649?source=rss](https://tvn24.pl/tvnwarszawa/okolice/ciechanow-wdarla-sie-do-mieszkania-sasiadki-i-kilkukrotnie-ja-uderzyla-zarzuty-dla-50-latki-st7464649?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-01T13:02:35+00:00

<img alt="Wdarła się do mieszkania sąsiadki, łamiąc zakaz zbliżania się. Trafiła do aresztu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lyo95f-kobieta-zostala-zatrzymana-zdjecie-ilustracyjne-4617000/alternates/LANDSCAPE_1280" />
    Policjanci zatrzymali 50-letnią mieszkankę Ciechanowa, która wdarła się do mieszkania swojej 75-letniej sąsiadki i kilka razy ją uderzyła. Następnie zaatakowała 25-latkę, wobec której miała orzeczony prokuratorski zakaz zbliżania. Kobiecie przedstawiono zarzuty uporczywego nękania, naruszenia nietykalności cielesnej, naruszenia miru domowego oraz uszkodzenia mienia - poinformowała tamtejsza policja.

## "Wysadzili budynek parlamentu w Gazie"? Nie, to inne miejsce
 - [https://konkret24.tvn24.pl/swiat/izrael-strefa-gazy-wysadzili-budynek-parlamentu-w-gazie-to-inne-miejsce-st7463237?source=rss](https://konkret24.tvn24.pl/swiat/izrael-strefa-gazy-wysadzili-budynek-parlamentu-w-gazie-to-inne-miejsce-st7463237?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-01T12:40:54+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-maosba-to-nie-jest-eksplozja-budynku-parlamentu-w-strefie-gazy-7463326/alternates/LANDSCAPE_1280" />
    Tysiące wyświetleń w mediach społecznościowych ma nagranie, które według internautów pokazuje moment zniszczenia budynku parlamentu w Gazie. Jednak choć do tej eksplozji doszło na tamtym terenie, przekaz rozsyłany z filmem jest fake newsem.

## Awaria w dużym banku. "Przepraszamy za utrudnienia"
 - [https://tvn24.pl/biznes/z-kraju/bank-millennium-utrudnienia-w-dostepie-do-aplikacji-st7464615?source=rss](https://tvn24.pl/biznes/z-kraju/bank-millennium-utrudnienia-w-dostepie-do-aplikacji-st7464615?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-01T12:30:57+00:00

<img alt="Awaria w dużym banku. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-v9bwak-23-latek-mial-podawac-sie-za-pracownika-banku-zdjecie-ilustracyjne-7391013/alternates/LANDSCAPE_1280" />
    Klienci Banku Millennium mają utrudniony dostęp do swoich pieniędzy. Przy otwieraniu aplikacji mobilnej pojawia się komunikat o "chwilowych utrudnieniach".

## Klienci mieli kłopot z dostępem do pieniędzy. "Aplikacja już działa poprawnie"
 - [https://tvn24.pl/biznes/z-kraju/awaria-w-banku-millennium-usunieta-aplikacja-juz-dziala-poprawnie-st7464615?source=rss](https://tvn24.pl/biznes/z-kraju/awaria-w-banku-millennium-usunieta-aplikacja-juz-dziala-poprawnie-st7464615?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-01T12:30:57+00:00

<img alt="Klienci mieli kłopot z dostępem do pieniędzy. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-v9bwak-23-latek-mial-podawac-sie-za-pracownika-banku-zdjecie-ilustracyjne-7391013/alternates/LANDSCAPE_1280" />
    Klienci Banku Millennium mieli w piątek utrudniony dostęp do swoich pieniędzy. Przy otwieraniu aplikacji mobilnej pojawiał się komunikat o "chwilowych utrudnieniach". "Aplikacja już działa poprawnie" - poinformowali redakcję biznesową tvn24.pl przed 15.00 przedstawiciele banku.

## Dwie 10-latki wbiegły na zamarznięty staw, żeby złapać kota
 - [https://tvn24.pl/lublin/parczew-dwie-10-latki-wbiegly-na-zamarzniety-staw-zeby-zlapac-kota-7464285?source=rss](https://tvn24.pl/lublin/parczew-dwie-10-latki-wbiegly-na-zamarzniety-staw-zeby-zlapac-kota-7464285?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-01T12:03:13+00:00

<img alt="Dwie 10-latki wbiegły na zamarznięty staw, żeby złapać kota" src="https://tvn24.pl/najnowsze/cdn-zdjecie-w9u9gn-dziewczynki-wbiegly-na-zamarzniety-staw-zeby-zlapac-kota-7464288/alternates/LANDSCAPE_1280" />
    Dwie 10-letnie dziewczynki wbiegły na zamarznięty staw w Parczewie (woj. lubelskie), żeby złapać kota, który wbiegł na lód. Niebezpieczną sytuację zauważył świadek, który zaalarmował policjantów. Dzieciom na szczęście nic się nie stało, mundurowi pomogli im bezpiecznie zejść z lodu.

## Wpadła w poślizg i dachowała w rzece
 - [https://tvn24.pl/bialystok/bielsk-podlaski-kobieta-wpadla-w-poslizg-i-wjechala-do-rzeki-7464363?source=rss](https://tvn24.pl/bialystok/bielsk-podlaski-kobieta-wpadla-w-poslizg-i-wjechala-do-rzeki-7464363?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-01T11:48:44+00:00

<img alt="Wpadła w poślizg i dachowała w rzece" src="https://tvn24.pl/najnowsze/cdn-zdjecie-gl5afu-kobieta-wpadla-w-poslizg-i-wjechala-rzeki-7464355/alternates/LANDSCAPE_1280" />
    32-latka z gminy Bielsk Podlaski straciła panowanie nad samochodem i dachowała w rzece. Kobiecie i jadącemu z nią mężczyźnie nic się nie stało, zdołali o własnych siłach wydostać się z samochodu. Policja apeluje o ostrożną jazdę.

## "Chcąc ratować kolegę, zamknął przed policjantami bramę, a kluczyk do niej wyrzucił"
 - [https://tvn24.pl/tvnwarszawa/praga-polnoc/warszawa-akcja-policjantow-na-brzeskiej-przeciwko-handlarzom-narkotykow-dwoch-zatrzymanych-st7464458?source=rss](https://tvn24.pl/tvnwarszawa/praga-polnoc/warszawa-akcja-policjantow-na-brzeskiej-przeciwko-handlarzom-narkotykow-dwoch-zatrzymanych-st7464458?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-01T11:44:36+00:00

<img alt="" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-uvs6h8-akcja-stolecznych-policjantow-na-brzeskiej-7464448/alternates/LANDSCAPE_1280" />
    Stołeczni policjanci podczas akcji wymierzonej przeciwko handlarzom narkotyków, zatrzymali dwóch mężczyzn na Brzeskiej. - Pierwszy wpadł podczas segregowania narkotyków. Drugi, chcąc ratować kolegę, zamknął przez policjantami bramę, a kluczyk do niej wyrzucił - poinformował sierżant Bartłomiej Śniadała ze stołecznej policji. Obaj mężczyźni usłyszeli już zarzuty.

## Są darmowe, anonimowe i bez skierowania - testy w kierunku HIV
 - [https://tvn24.pl/szczecin/szczecin-sa-darmowe-anonimowe-i-bez-skierowania-testy-w-kierunku-hiv-7464193?source=rss](https://tvn24.pl/szczecin/szczecin-sa-darmowe-anonimowe-i-bez-skierowania-testy-w-kierunku-hiv-7464193?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-01T11:28:24+00:00

<img alt="Są darmowe, anonimowe i bez skierowania - testy w kierunku HIV" src="https://tvn24.pl/najnowsze/cdn-zdjecie-105mvf-szczecinski-punkt-konsultacyjno-diagnostyczny-czynny-jest-trzy-razy-w-tygodniu-7464206/alternates/LANDSCAPE_1280" />
    W Szczecinie i Koszalinie funkcjonują punkty konsultacyjno-diagnostyczne, w których każdy chętny może przetestować się w kierunku HIV. Oferują one także profesjonalne doradztwo w zakresie m.in. profilaktyki. Badania są anonimowe, darmowe i bez skierowania. Rok 2023 jest rekordowy pod względem liczby zakażeń wirusem HIV w Polsce.

## 58-latek zmarł z wychłodzenia. Policja apeluje: "Pomoc nic nie kosztuje, a może ocalić czyjeś życie"
 - [https://tvn24.pl/lublin/gmina-krasniczyn-58-latek-zmarl-z-wychlodzenia-policja-apeluje-7464166?source=rss](https://tvn24.pl/lublin/gmina-krasniczyn-58-latek-zmarl-z-wychlodzenia-policja-apeluje-7464166?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-01T11:06:19+00:00

<img alt="58-latek zmarł z wychłodzenia. Policja apeluje: " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-8yfb9i-smierc-z-wychlodzenia-5184021/alternates/LANDSCAPE_1280" />
    Policja wyjaśnia szczegóły śmierci 58-latka znalezionego w pustostanie w gminie Kraśniczyn (woj. lubelskie). Według wstępnych ustaleń przyczyną śmierci było wychłodzenie organizmu. Funkcjonariusze apelują o czujność i zainteresowanie osobami, które mogą być narażone na działanie niskich temperatur.

## Neonet z wnioskiem o upadłość i postępowanie sanacyjne. Co z zamówieniami?
 - [https://tvn24.pl/biznes/z-kraju/klopoty-sieci-neonet-wniosek-o-upadlosc-i-postepowanie-sanacyjne-st7464284?source=rss](https://tvn24.pl/biznes/z-kraju/klopoty-sieci-neonet-wniosek-o-upadlosc-i-postepowanie-sanacyjne-st7464284?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-01T10:07:29+00:00

<img alt="Neonet z wnioskiem o upadłość i postępowanie sanacyjne. Co z zamówieniami?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2zlzku-neonet-7464296/alternates/LANDSCAPE_1280" />
    Grupa Neonet, do której należy sieć ponad 300 sklepów ze sprzętem AGD, RTV i IT, ma poważne kłopoty. W krajowym Rejestrze Zadłużonych 30 listopada zarejestrowano wniosek o wszczęcie postępowania o ogłoszenie upadłości przedsiębiorcy. To na wypadek, gdyby nie udało się dojść do porozumienia z kontrahentami. Spółka poinformowała, że zarząd złożył wniosek o otwarcie postępowania sanacyjnego.

## Zaatakował nożem w szkole, 18-latek usłyszał zarzut usiłowania zabójstwa wielu osób
 - [https://tvn24.pl/tvnwarszawa/okolice/kadzidlo-atak-w-szkole-zarzuty-dla-18-letniego-nozownika-ktory-ranil-trzy-osoby-st7463871?source=rss](https://tvn24.pl/tvnwarszawa/okolice/kadzidlo-atak-w-szkole-zarzuty-dla-18-letniego-nozownika-ktory-ranil-trzy-osoby-st7463871?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-01T10:00:39+00:00

<img alt="Zaatakował nożem w szkole, 18-latek usłyszał zarzut usiłowania zabójstwa wielu osób " src="https://tvn24.pl/najnowsze/cdn-zdjecie-7t805f-do-ataku-nozownika-doszlo-w-kadzidle-7464031/alternates/LANDSCAPE_1280" />
    Po ataku w szkole w Kadzidle prokuratura przedstawiła 18-letniemu Albertowi G. zarzut usiłowania zabójstwa wielu osób. Spośród trójki rannych, dwie osoby są w stanie ciężkim. Świadkowie relacjonowali, że G. wyszedł w czasie lekcji do łazienki, wrócił zamaskowany i zaczął atakować "pierwsze napotkane osoby".

## Grożą wypuszczeniem dwóch milionów psów. Protesty przeciwko zakazowi jedzenia psiego mięsa
 - [https://tvn24.pl/swiat/korea-poludniowa-zakaz-jedzenia-psiego-miesa-rolnicy-protestuja-i-groza-wypuszczeniem-dwoch-milionow-psow-7463948?source=rss](https://tvn24.pl/swiat/korea-poludniowa-zakaz-jedzenia-psiego-miesa-rolnicy-protestuja-i-groza-wypuszczeniem-dwoch-milionow-psow-7463948?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-01T09:53:31+00:00

<img alt="Grożą wypuszczeniem dwóch milionów psów. Protesty przeciwko zakazowi jedzenia psiego mięsa" src="https://tvn24.pl/najnowsze/cdn-zdjecie-b4xuh8-korea-poludniowa-pies-w-klatce-podczas-protestu-rolnikow-w-seulu-7463920/alternates/LANDSCAPE_1280" />
    Południowokoreańscy rolnicy grożą wypuszczeniem na wolność dwóch milionów psów w związku z rządową ustawą, która ma zakazać spożywania psiego mięsa. W czwartek w Seulu odbyły się protesty, podczas których doszło do starć z policją.

## Pożar mieszkania w bloku, zginął 64-letni mężczyzna, ewakuowano mieszkańców
 - [https://tvn24.pl/rzeszow/stalowa-wola-pozar-mieszkania-w-bloku-ewakuowano-mieszkancow-zginal-64-letni-mezczyzna-7463911?source=rss](https://tvn24.pl/rzeszow/stalowa-wola-pozar-mieszkania-w-bloku-ewakuowano-mieszkancow-zginal-64-letni-mezczyzna-7463911?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-01T08:09:51+00:00

<img alt="Pożar mieszkania w bloku, zginął 64-letni mężczyzna, ewakuowano mieszkańców" src="https://tvn24.pl/najnowsze/cdn-zdjecie-nb4kxp-stalowa-wola-pozar-mieszkania-w-bloku-ewakuowano-mieszkancow-zginal-64-letni-mezczyzna-7464018/alternates/LANDSCAPE_1280" />
    W pożarze mieszkania w Stalowej Woli (woj. podkarpackie) zginął 64 mężczyzna. Strażacy ewakuowali też 25 lokatorów bloku. Na razie nie wiadomo co spowodowało pożar.

## "Rzucił psem o szafki kuchenne, zwierzę nie przeżyło". 32-latek usłyszał zarzuty i trafił do aresztu
 - [https://tvn24.pl/tvnwarszawa/wola/rzucil-psem-o-szafki-kuchenne-zwierze-nie-przezylo-32-latek-uslyszal-zarzuty-i-trafil-do-aresztu-st7463949?source=rss](https://tvn24.pl/tvnwarszawa/wola/rzucil-psem-o-szafki-kuchenne-zwierze-nie-przezylo-32-latek-uslyszal-zarzuty-i-trafil-do-aresztu-st7463949?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-01T07:40:48+00:00

<img alt="" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-6b4b1j-mezczyzna-uslyszal-zarzuty-7463961/alternates/LANDSCAPE_1280" />
    Policjanci zatrzymali mężczyznę podejrzanego o zabicie psa i uszkodzenie ciała. Mężczyzna uderzył matkę w twarz, a po chwili rzucił psem o szafki kuchenne, zwierzę nie przeżyło - poinformowała nadkom. Marta Sulowska z komendy na Woli.

## Ryszard Petru: Jestem przeciwnikiem grubej kreski. Jeżeli ktoś ewidentnie złamał prawo, to kara musi być
 - [https://tvn24.pl/polska/ryszard-petru-jestem-przeciwnikiem-grubej-kreski-jezeli-ktos-ewidentnie-zlamal-prawo-to-kara-musi-byc-7463874?source=rss](https://tvn24.pl/polska/ryszard-petru-jestem-przeciwnikiem-grubej-kreski-jezeli-ktos-ewidentnie-zlamal-prawo-to-kara-musi-byc-7463874?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-01T07:17:09+00:00

<img alt="Ryszard Petru: Jestem przeciwnikiem grubej kreski. Jeżeli ktoś ewidentnie złamał prawo, to kara musi być" src="https://tvn24.pl/najnowsze/cdn-zdjecie-is9fd7-glapinski-7333058/alternates/LANDSCAPE_1280" />
    Jestem przeciwnikiem grubej kreski. Uważam, że w przypadku osób w PiS-ie, które popełniały przestępstwa, albo łamały prawo, nie może być grubej kreski - mówił w "Jeden na jeden" poseł Ryszard Petru (Polska 2050-Trzecia Droga). Pytany przez Agatę Adamek, dziennikarkę TVN24 o postawienie przez większość sejmową przed Trybunałem Stanu obecnego prezesa NBP Adama Glapińskiego, polityk stwierdził, że "wniosek jest przygotowywany".

## Miejscami pojawiają się marznące mgły ograniczające widzialność
 - [https://tvn24.pl/tvnmeteo/pogoda/miejscami-pojawiaja-sie-marznace-mgly-ograniczajace-widzialnosc-st7463885?source=rss](https://tvn24.pl/tvnmeteo/pogoda/miejscami-pojawiaja-sie-marznace-mgly-ograniczajace-widzialnosc-st7463885?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-01T06:36:59+00:00

<img alt="Miejscami pojawiają się marznące mgły ograniczające widzialność" src="https://tvn24.pl/najnowsze/cdn-zdjecie-btvx2c-mgly-7361425/alternates/LANDSCAPE_1280" />
    Marznące mgły pojawiają się w piątek rano w części Polski. Widzialność w niektórych regionach jest ograniczona do 100 metrów. Gdzie kierowcy powinni zachować szczególna ostrożność?

