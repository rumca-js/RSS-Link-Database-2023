# Source:The Wall Street - Tech, URL:https://feeds.a.dj.com/rss/RSSWSJD.xml, language:en-US

## Amazon Hires Elon Musk's SpaceX for Three Rocket Launches
 - [https://www.wsj.com/articles/amazon-hires-elon-musks-spacex-for-three-rocket-launches-a8408f9f?mod=rss_Technology](https://www.wsj.com/articles/amazon-hires-elon-musks-spacex-for-three-rocket-launches-a8408f9f?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-12-01T21:12:00+00:00

The deal marks the first time Amazon is turning to SpaceX as it builds satellite internet division. Amazon founder Jeff Bezos’ Blue Origin is also set to launch Amazon satellites.

## Adam D'Angelo Bridges the Past, Future for OpenAI Board
 - [https://www.wsj.com/articles/adam-dangelo-openai-board-19ab00ee?mod=rss_Technology](https://www.wsj.com/articles/adam-dangelo-openai-board-19ab00ee?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-12-01T12:30:00+00:00

The Quora CEO, one of the four board members who fired Sam Altman, is the only director remaining on the new board.

## Meta Is Struggling to Boot Pedophiles Off Facebook and Instagram
 - [https://www.wsj.com/articles/meta-facebook-instagram-pedophiles-enforcement-struggles-dceb3548?mod=rss_Technology](https://www.wsj.com/articles/meta-facebook-instagram-pedophiles-enforcement-struggles-dceb3548?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-12-01T10:30:00+00:00

The social-media company has stepped up enforcement, but its algorithms continue to promote problematic content

## Montana Judge Says TikTok Ban 'Likely Violates First Amendment'
 - [https://www.wsj.com/articles/tiktok-gets-montana-reprieve-after-federal-judge-blocks-ban-c617d72e?mod=rss_Technology](https://www.wsj.com/articles/tiktok-gets-montana-reprieve-after-federal-judge-blocks-ban-c617d72e?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-12-01T04:31:00+00:00

The social-media app sued after the state passed a law banning TikTok to protect residents’ privacy.

## Elon Musk's F-Bombs Make Linda Yaccarino's Job at X Even Harder
 - [https://www.wsj.com/articles/elon-musks-f-bombs-make-linda-yaccarinos-job-at-x-even-harder-b45ff13d?mod=rss_Technology](https://www.wsj.com/articles/elon-musks-f-bombs-make-linda-yaccarinos-job-at-x-even-harder-b45ff13d?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-12-01T02:24:00+00:00

Musk’s outburst is “a line in the sand that can’t be undrawn,” one ad-industry insider said.

