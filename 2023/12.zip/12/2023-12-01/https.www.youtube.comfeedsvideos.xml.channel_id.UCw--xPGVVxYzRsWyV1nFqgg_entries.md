# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## I Attempt NaNoWriMo! ⌨️ ( 2023 )
 - [https://www.youtube.com/watch?v=m5e1ILrxnMw](https://www.youtube.com/watch?v=m5e1ILrxnMw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2023-12-01T14:00:37+00:00

Let's take a stab at writing some books! Thank you Campfire for sponsoring today's video. Read or Write Your Story at: https://www.campfirewriting.com/reading-app?utm_source=youtube&amp;utm_medium=video&amp;utm_campaign=DG_Q4_23 

My books
Neon Ghosts: https://amzn.to/3Y2N1QI (digital)
Neon Ghosts: Physical: https://tinyurl.com/NGPreOrder 
Breach of Peace: https://tinyurl.com/BoPTLT  
Rebels Creed: https://tinyurl.com/RCTLTDG 
merch: https://www.danielbgreene.com

Patreon: https://www.patreon.com/DanielBGreene 
Join the Discord here: https://discord.gg/xUrPj6EP3f
All the Me Social Links: https://linktr.ee/DanielGreene

