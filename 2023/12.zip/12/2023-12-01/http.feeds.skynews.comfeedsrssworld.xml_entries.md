# Source:Sky News, URL:http://feeds.skynews.com/feeds/rss/world.xml, language:en-US

## The ceasefire is over - and now Gazans have to flee once more for safety
 - [https://news.sky.com/story/the-ceasefire-between-israel-and-hamas-is-over-and-now-gazans-have-to-flee-once-more-for-safety-13020542](https://news.sky.com/story/the-ceasefire-between-israel-and-hamas-is-over-and-now-gazans-have-to-flee-once-more-for-safety-13020542)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-12-01T18:59:00+00:00

Plumes of smoke rise once again into the clear skies over Gaza. &#160;

## Republican who used campaign cash for Botox and OnlyFans expelled from House
 - [https://news.sky.com/story/george-santos-expelled-from-house-over-criminal-charges-and-damning-ethics-report-13020438](https://news.sky.com/story/george-santos-expelled-from-house-over-criminal-charges-and-damning-ethics-report-13020438)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-12-01T16:09:00+00:00

Republican congressman George Santos has been expelled from the US House of Representatives after a report found "overwhelming evidence" he misused campaign donations.

## Israel 'knew about Hamas attack plans' a year before it happened, report says
 - [https://news.sky.com/story/israel-knew-about-hamas-attack-plans-over-a-year-before-it-happened-new-york-times-reports-13020432](https://news.sky.com/story/israel-knew-about-hamas-attack-plans-over-a-year-before-it-happened-new-york-times-reports-13020432)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-12-01T16:05:00+00:00

Israel knew about plans for a Hamas attack on its soil more than a year before the 7 October assault that killed more than a thousand people, according to the New York Times.

## Key to solving mystery of man found dead in barn 'lies in France' after bone analysis
 - [https://news.sky.com/story/key-to-solving-mystery-of-remains-found-in-hampshire-barn-lies-in-france-after-bones-analysed-13020404](https://news.sky.com/story/key-to-solving-mystery-of-remains-found-in-hampshire-barn-lies-in-france-after-bones-analysed-13020404)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-12-01T16:03:00+00:00

The key to solving the mystery of a man whose remains were found in a disused barn in the English countryside likely lies in France, according to detectives, who have launched a new appeal after his bones were analysed by experts.

## First woman to serve on US Supreme Court has died
 - [https://news.sky.com/story/sandra-day-oconnor-first-woman-on-us-supreme-court-dies-aged-93-13020399](https://news.sky.com/story/sandra-day-oconnor-first-woman-on-us-supreme-court-dies-aged-93-13020399)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-12-01T15:08:00+00:00

Sandra Day O'Connor, the first woman to serve on the US Supreme Court, has died at the age of 93.

## COP28 feels like the centre of the universe, but will it change the world?
 - [https://news.sky.com/story/cop28-feels-like-the-centre-of-the-universe-but-will-it-actually-change-the-world-13020355](https://news.sky.com/story/cop28-feels-like-the-centre-of-the-universe-but-will-it-actually-change-the-world-13020355)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-12-01T14:02:00+00:00

For these two days every year, you feel like you're in the centre of the world.

## King sports Greek tie in wake of Elgin Marbles row
 - [https://news.sky.com/story/king-wears-greek-tie-following-elgin-marbles-row-between-athens-and-downing-street-13020325](https://news.sky.com/story/king-wears-greek-tie-following-elgin-marbles-row-between-athens-and-downing-street-13020325)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-12-01T13:22:00+00:00

The King wore a tie depicting the Greek flag as he appeared at the COP28 climate summit following a diplomatic row over the Elgin Marbles.

## Rafael Nadal set for tennis return after year out injured
 - [https://news.sky.com/story/rafael-nadal-announces-tennis-comeback-in-brisbane-after-year-out-injured-13020304](https://news.sky.com/story/rafael-nadal-announces-tennis-comeback-in-brisbane-after-year-out-injured-13020304)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-12-01T12:57:00+00:00

Rafael Nadal has announced when he will make his comeback after a year out injured.

## Surge in respiratory illnesses in China provokes uncomfortable memories of COVID pandemic
 - [https://news.sky.com/story/china-surge-in-respiratory-illnesses-provokes-uncomfortable-memories-of-covid-pandemic-13020233](https://news.sky.com/story/china-surge-in-respiratory-illnesses-provokes-uncomfortable-memories-of-covid-pandemic-13020233)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-12-01T11:09:00+00:00

In China's hospitals, the patients keep coming.

## Helicopter hits car after crashing on motorway ring road in Madrid
 - [https://news.sky.com/story/madrid-helicopter-hits-car-after-crashing-on-motorway-ring-road-13020207](https://news.sky.com/story/madrid-helicopter-hits-car-after-crashing-on-motorway-ring-road-13020207)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-12-01T10:31:00+00:00

A helicopter has crashed on a motorway ring road in Madrid, hitting a car and leaving three people injured.

## Israel releases map 'advising Gazans of safe evacuation zones' as it resumes strikes
 - [https://news.sky.com/story/israel-releases-map-advising-gazans-of-safe-evacuation-zones-as-it-resumes-strikes-13020178](https://news.sky.com/story/israel-releases-map-advising-gazans-of-safe-evacuation-zones-as-it-resumes-strikes-13020178)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-12-01T09:52:00+00:00

The Israeli military has published a map that it says advises Gazans of safe evacuation zones - as its fighter jets resumed striking targets in the densely populated strip of land.

## Olympian ice hockey player 'paralysed from chest down' after goal collision
 - [https://news.sky.com/story/finnish-olympian-ice-hockey-player-sanni-hakala-paralysed-from-chest-down-after-goal-collision-13020162](https://news.sky.com/story/finnish-olympian-ice-hockey-player-sanni-hakala-paralysed-from-chest-down-after-goal-collision-13020162)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-12-01T09:12:00+00:00

An Olympic ice hockey player says she may have to spend the rest of her life in a wheelchair after falling and crashing into a goal post head-first during a match.

## Woman becomes 'Africa's oldest mother' after giving birth at 70 to twins
 - [https://news.sky.com/story/uganda-woman-becomes-africas-oldest-mother-after-giving-birth-aged-70-13020110](https://news.sky.com/story/uganda-woman-becomes-africas-oldest-mother-after-giving-birth-aged-70-13020110)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-12-01T08:07:00+00:00

A woman has become "Africa's oldest mother" after giving birth to twins aged 70.

## Israel accuses Hamas of violating truce deal - military operations resume
 - [https://news.sky.com/story/israel-accuses-hamas-of-violating-truce-deal-military-operations-set-to-resume-13020047](https://news.sky.com/story/israel-accuses-hamas-of-violating-truce-deal-military-operations-set-to-resume-13020047)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-12-01T00:37:00+00:00

Israel's military has resumed combat in Gaza after accusing Hamas of violating the seven-day truce.

