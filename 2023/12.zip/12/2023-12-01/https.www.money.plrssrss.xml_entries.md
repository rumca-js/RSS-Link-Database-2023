# Source:Money PL, URL:https://www.money.pl/rss/rss.xml, language:pl-PL

## Paweł Kukiz pokazał majątek. Jedna pozycja mocno się zmieniła
 - [https://www.money.pl/pieniadze/pawel-kukiz-pokazal-majatek-jedna-pozycja-mocno-sie-zmienila-6969189629594496a.html](https://www.money.pl/pieniadze/pawel-kukiz-pokazal-majatek-jedna-pozycja-mocno-sie-zmienila-6969189629594496a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-12-01T20:55:33+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c8053073-2a14-4aaf-ad42-fdd627c71159" width="308" /> Ma 450-metrowy dom i niewielkie mieszkanie, jeździ SUV-em sprzed 14 lat, kończy spłacać kredyt. Na stronie internetowej Sejmu opublikowane zostało oświadczenie majątkowe Pawła Kukiza. W porównaniu z poprzednim oświadczeniem wiele pozycji się nie zmieniło. Ale jedna rzecz mocno się poprawiła.

## Michał Kołodziejczak pokazał majątek. Gospodarstwo warte 3 mln zł i spore oszczędności
 - [https://www.money.pl/pieniadze/michal-kolodziejczak-pokazal-majatek-gospodarstwo-warte-3-mln-zl-i-spore-oszczednosci-6969131687860736a.html](https://www.money.pl/pieniadze/michal-kolodziejczak-pokazal-majatek-gospodarstwo-warte-3-mln-zl-i-spore-oszczednosci-6969131687860736a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-12-01T17:45:06+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/1ff02f45-f8c8-4790-a1d4-f16b97d8ea22" width="308" /> Zaczynał od rolniczych protestów, teraz zasiadł w Sejmie. Dla Michała Kołodziejczaka to pierwszy raz w polskim parlamencie. Po raz pierwszy musiał też złożyć oświadczenie majątkowe. Co w nim wpisał?

## Warszawka giełda bije rekordy. Najwyższy WIG w historii
 - [https://www.money.pl/gielda/warszawka-gielda-bije-rekordy-najwyzszy-wig-w-historii-6969121749318528a.html](https://www.money.pl/gielda/warszawka-gielda-bije-rekordy-najwyzszy-wig-w-historii-6969121749318528a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-12-01T16:15:07+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/66ec3a7c-424e-4c37-a984-8a3affa78c3c" width="308" /> Piątek upłynął na warszawskiej giełdzie pod znakiem wzrostu wszystkich spółek z indeksu WIG. Jego wartość wzrosła o 3 proc. - do 2.283 punktów. Największe wzrosty zaliczyły JSW i Pekao, które podrożały odpowiednio o 5,21 proc. i 5,19 proc.

## "Król Zakopanego" pokazał majątek. Robi wrażenie
 - [https://www.money.pl/pieniadze/krol-zakopanego-i-jeden-z-najbogatszych-poslow-andrzej-gut-mostowy-ma-ponad-60-mln-zl-6969115441265536a.html](https://www.money.pl/pieniadze/krol-zakopanego-i-jeden-z-najbogatszych-poslow-andrzej-gut-mostowy-ma-ponad-60-mln-zl-6969115441265536a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-12-01T15:57:50+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/d8c03cce-8635-4e25-83fa-dc74ff6caaf1" width="308" /> Ma 340-metrowy dom, 12 innych nieruchomości i udziały w hotelu na Krupówkach. W garażu trzyma mercedesa G i bmw serii 7, na koncie zaś - ponad trzy miliony złotych. Oto majątek posła Andrzeja Guta-Mostowego.

## Znana firma znów przeżywa ciężkie chwile. Ważne porozumienie wygasło
 - [https://www.money.pl/gospodarka/znana-firma-znow-przezywa-ciezkie-chwile-wazne-porozumienie-wygaslo-6969113088846336a.html](https://www.money.pl/gospodarka/znana-firma-znow-przezywa-ciezkie-chwile-wazne-porozumienie-wygaslo-6969113088846336a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-12-01T15:34:30+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/fd4c3312-913c-4000-98c7-efd3abc42e45" width="308" /> Rafako, polski producent infrastruktury przemysłowej, znów przeżywa ciężkie chwile. Jedno z porozumień pozwalających uniknięcia egzekucji długów wygasło. Prawdziwa próba sił odbędzie się jednak za kilka tygodni, kiedy to akcjonariusze spółki zdecydują o emisji specjalnych akcji.

## Jak maksymalizować zyski z IKE? Sprawdzone strategie inwestycyjne na emeryturę z IKE i IKZE
 - [https://www.money.pl/emerytury/jak-maksymalizowac-zyski-z-ike-sprawdzone-strategie-inwestycyjne-na-emeryture-z-ike-i-ikze-6969105681963904a.html](https://www.money.pl/emerytury/jak-maksymalizowac-zyski-z-ike-sprawdzone-strategie-inwestycyjne-na-emeryture-z-ike-i-ikze-6969105681963904a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-12-01T14:58:38+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b49149b6-2239-48e6-9580-7d801aa1ef25" width="308" /> Zyski z inwestycji nigdy nie są pewne, a samo inwestowanie wiąże się z ryzykiem utraty części lub całości posiadanych środków finansowych. Sztuką wyboru jest to, by działać tak, by maksymalizować przychody, a minimalizować możliwe starty. Dlatego ważne jest dywersyfikowanie portfela. Jak zastosować taką zasadę w przypadku oszczędzania w ramach IKE?

## Polska "na trajektorii ożywienia". Ekonomiści komentują najnowsze dane
 - [https://www.money.pl/gospodarka/polska-na-trajektorii-ozywienia-ekonomisci-komentuja-najnowsze-dane-6969062122994560a.html](https://www.money.pl/gospodarka/polska-na-trajektorii-ozywienia-ekonomisci-komentuja-najnowsze-dane-6969062122994560a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-12-01T14:40:36+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b5b45845-4883-47e6-af51-3d4d77ef846e" width="308" /> Mijający tydzień przyniósł ważne odczyty dla polskiej gospodarki. Pozytywne dane dotyczą zarówno PKB jak i PMI. "Krajowa gospodarka na dobre wyszła z fazy spowolnienia i jest obecnie na trajektorii ożywienia w kierunku 3-procentowego wzrostu PKB" - piszą analitycy banku Santander.

## Więcej pieniędzy na kredyt 2 proc. Premier o "ogromnym popycie"
 - [https://www.money.pl/gospodarka/bezpieczny-kredyt-2-proc-jest-kluczowa-decyzja-6969040571300736a.html](https://www.money.pl/gospodarka/bezpieczny-kredyt-2-proc-jest-kluczowa-decyzja-6969040571300736a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-12-01T10:27:44+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/6de74055-9e4f-4a1e-ae3e-d90b05731ae5" width="308" /> Rząd w piątek 1 grudnia zdecydował o zwiększeniu finansowania programu "Bezpieczny kredyt 2 procent". - Popyt na ten produkt jest ogromny - powiedział premier Mateusz Morawiecki. Dodał, że ten "kredyt stał się spełnieniem marzeń wielu rodzin".

## Dezinflacja szerzy się w Europie - jak reagują inwestorzy?
 - [https://www.money.pl/pieniadze/dezinflacja-szerzy-sie-w-europie-jak-reaguja-inwestorzy-6969023618087424a.html](https://www.money.pl/pieniadze/dezinflacja-szerzy-sie-w-europie-jak-reaguja-inwestorzy-6969023618087424a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-12-01T10:15:10+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/d7256790-7d4c-437c-9aac-8e1d98a60537" width="308" /> Od ponad dwóch lat odmieniamy inflację przez wszystkie przypadki. Od kilku miesięcy oswajamy się z pojęciem dezinflacji, czyli procesu powrotu do celów wyznaczonych przez banki centralne. Właśnie z tej perspektywy jest to zagadnienia kluczowe, ponieważ rozpala dyskusję już nie o możliwości kolejnych podwyżek stóp procentowych, ale o perspektywie obniżek kosztu pieniądza.

## "Bezpieczny kredyt 2 proc.". Rząd zdecyduje ws. zwiększenia limitu
 - [https://www.money.pl/gospodarka/bezpieczny-kredyt-2-proc-rzad-zdecyduje-ws-zwiekszenia-limitu-6969018276539264a.html](https://www.money.pl/gospodarka/bezpieczny-kredyt-2-proc-rzad-zdecyduje-ws-zwiekszenia-limitu-6969018276539264a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-12-01T09:02:18+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/5feac92e-8b25-4a19-9a72-fbfebfb8e0a4" width="308" /> - Dzisiaj mamy kolejne posiedzenie rządu w tym tygodniu - powiedziała w piątek minister rozwoju i technologii Marlena Maląg w Program 1 Polskiego Radia. Jak dodała, Rada Ministrów ma zająć się m.in. projektem dotyczącym zwiększenia limitu na "bezpieczny kredyt 2 proc.".

## Zaskakujący sygnał z przemysłu. Takich danych jeszcze nie było
 - [https://www.money.pl/pieniadze/zaskakujacy-sygnal-z-przemyslu-takich-danych-jeszcze-nie-bylo-6969008918174208a.html](https://www.money.pl/pieniadze/zaskakujacy-sygnal-z-przemyslu-takich-danych-jeszcze-nie-bylo-6969008918174208a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-12-01T08:45:00+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/6994a28e-50bd-4889-bba4-0fbd67578f0a" width="308" /> PMI dla przemysłu wzrósł względem października o 4,2 pkt, co jest najwyższy wzrostem w historii. Jest coraz bliżej granicznej wartości. - Listopadowe dane są najwyraźniejszym sygnałem, że kończy się długi spadek produkcji w Polsce - stwierdza Trevor Balchin, dyrektor ds. ekonomii w S&amp;P.

## Obajtek ostrzega, że to pierwszy krok ku prywatyzacji Orlenu. "Niech nie przesadza"
 - [https://www.money.pl/podatki/obajtek-ostrzega-ze-to-pierwszy-krok-ku-prywatyzacji-orlenu-niech-nie-przesadza-6969015410387073v.html](https://www.money.pl/podatki/obajtek-ostrzega-ze-to-pierwszy-krok-ku-prywatyzacji-orlenu-niech-nie-przesadza-6969015410387073v.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-12-01T08:37:16+00:00

<img src="https://i.wpimg.pl/308x/wptv-upload-api.wpcdn.pl/7e9a318c-b21e-4273-84e1-58ee765af469.jpg" width="308" /> Orlen ma pokryć część kosztów dalszego mrożenia cen energii, gazu i ciepła. Projekt ustawy Koalicji Obywatelskiej i Polski 2050 zakłada, że koncern zostałby obciążony składką w wysokości 15 mld zł. Informacja ta uderzyła w kurs energetycznego giganta. Prezes Orlenu ostrzega, że to może być krok do prywatyzacji Orlenu. - Niech pan Obajtek nie przesadza. Nie ma tutaj racji. Nie wierzę w prywatyzację Orlenu, choć rozbicia na mniejsze podmioty bym nie wykluczał - stwierdził Piotr Kuczyński, analityk Domu Inwestycyjnego Xelion, w programie "Newsroom" Wirtualnej Polski. 
- Mamy wybór: albo obciążyć ludność całą horrendalnym wzrostem cen energii o 50-70 proc., albo zadłużyć Polskę bardziej 15-20 mld zł dorzuconymi do deficytu budżetu, albo zastosować tzw. windfall tax, podatek od nadmiarowych zysków. Z bólem serca, jeśli mam wybrać spośród tych trzech rzeczy, to już wolę windf

## Gigant  traci. Koalicja komentuje. "Orlen dorabiał się na wojnie"
 - [https://www.money.pl/gospodarka/gigant-traci-koalicja-komentuje-orlen-dorabial-sie-na-wojnie-6969000087423872a.html](https://www.money.pl/gospodarka/gigant-traci-koalicja-komentuje-orlen-dorabial-sie-na-wojnie-6969000087423872a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-12-01T08:36:18+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/3bf62626-6717-4ae2-9055-7375690780e9" width="308" /> - Orlen dorabiał się na wojnie. Generował zyski w efekcie kryzysu paliwowo-energetycznego wywołanego wojną i chwianiem tymi rynkami przez Rosję - mówiła w Radiu ZET posłanka Polski 2050 Paulina Hennig-Kloska, odnosząc się do informacji o tym, że Orlen mocno stracił  na giełdzie po informacji o planach zamrożenia cen energii i zmianach dotyczących  farm wiatrowych.

## "Nie było żadnych lobbystów. Nie ma mowy o wywłaszczeniach"
 - [https://www.money.pl/gospodarka/pis-grzmi-o-aferze-wiatrakowej-koalicja-gesto-sie-tlumaczy-6968991745059328a.html](https://www.money.pl/gospodarka/pis-grzmi-o-aferze-wiatrakowej-koalicja-gesto-sie-tlumaczy-6968991745059328a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-12-01T07:28:03+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/8055cef7-f5c0-45f3-8051-db186e52c6f2" width="308" /> Wnioskodawcą tej ustawy jest PO, ale ja nad nią pracowałam przez ostatnie 2 tygodnie. Przygotowaliśmy bardzo dobrą ustawę, która wymaga doprecyzowania przepisów, by rozwiać wątpliwości co do naszej intencji - mówiła w Radiu ZET posłanka Polski 2050 Paulina Hennig-Kloska.

## Kościół chce przejąć hektary państwowej ziemi
 - [https://www.money.pl/gospodarka/kosciol-chce-przejac-hektary-panstwowej-ziemi-6968981993814912a.html](https://www.money.pl/gospodarka/kosciol-chce-przejac-hektary-panstwowej-ziemi-6968981993814912a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-12-01T06:54:54+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e1b1719e-bfb5-42c7-8e4e-e9c5a3beab7a" width="308" /> Kościół w województwie opolskim wyraził chęć przejęcia 2600 hektarów państwowej ziemi rolnej, której wartość szacuje się na setki milionów złotych - informuje portal Oko.press. I dodaje, że w innych województwach na tzw. Ziemiach Odzyskanych, Kościół również stara się o tysiące hektarów.

## Ukraińcy w Polsce kredyty biorą głównie na mieszkanie
 - [https://www.money.pl/banki/ukraincy-w-polsce-kredyty-biora-glownie-na-mieszkanie-6968982157507072a.html](https://www.money.pl/banki/ukraincy-w-polsce-kredyty-biora-glownie-na-mieszkanie-6968982157507072a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-12-01T06:37:53+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/859651c3-6ff7-42b3-a0ec-a3a8f60d95db" width="308" /> Ukraińcy w Polsce chętnie korzystają z kart i aplikacji, odkładają pieniądze, a kredyty biorą tylko na mieszkanie - pisze "Puls Biznesu", powołując się&nbsp;na dane Biura Informacji Kredytowej (BIK).

## Kursy walut 01.12.2023. Piątkowy kurs funta, euro, dolara i franka szwajcarskiego
 - [https://www.money.pl/pieniadze/kursy-walut-01-12-2023-piatkowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6968979853908480a.html](https://www.money.pl/pieniadze/kursy-walut-01-12-2023-piatkowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6968979853908480a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-12-01T06:14:34+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/42673486-e5fa-426a-a05b-a827a357deb3" width="308" /> Kursy walut - 1.12.2023. W piątek za jednego dolara (USD) zapłacimy 3,99 zł. Cena jednego funta szterlinga (GBP) to 5,04 zł, a franka szwajcarskiego (CHF) 4,56 zł. Z kolei euro (EUR) możemy zakupić za 4,35 zł.

## Ważna zmiana dla tych emerytów. ZUS przypomina o nowych progach
 - [https://www.money.pl/emerytury/wazna-zmiana-dla-tych-emerytow-zus-przypomina-o-nowych-progach-6968976990550528a.html](https://www.money.pl/emerytury/wazna-zmiana-dla-tych-emerytow-zus-przypomina-o-nowych-progach-6968976990550528a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-12-01T06:13:35+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/179f1d3c-5c63-4f8b-bec3-ee3b2d0c1ac1" width="308" /> Emeryci i renciści mogą pracować i dorabiać, ale niektórych z nich obowiązują limity zarobkowe. Gdy je przekroczą, ZUS może zmniejszyć lub zawiesić wypłacane świadczenie - przypomina rzecznik ZUS Paweł Żebrowski. Od 1 grudnia limity będą wyższe.

## Ile kosztuje dolar? Kurs dolara do złotego PLN/USD 01.12.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-01-12-2023-6968977108171648a.html](https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-01-12-2023-6968977108171648a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-12-01T06:00:28+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e0ba71a8-9c02-482d-85dd-ebac5362ee3b" width="308" /> Kurs dolara - 01.12.2023. W piątek za jednego dolara (USD) trzeba zapłacić 3.9872 zł.

## Ile kosztuje frank szwajcarski? Kurs franka do złotego PLN/CHF 01.12.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-01-12-2023-6968977108937600a.html](https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-01-12-2023-6968977108937600a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-12-01T06:00:28+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b1c04e3f-7bce-4c35-b03c-7a8d7b0adc65" width="308" /> Kurs franka szwajcarskiego - 01.12.2023. W piątek za jednego franka (CHF) trzeba zapłacić 4.561 zł.

## Ile kosztuje euro? Kurs euro do złotego PLN/EUR 01.12.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-01-12-2023-6968977083902848a.html](https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-01-12-2023-6968977083902848a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-12-01T06:00:22+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cf3a8300-d9c9-461f-9fbc-2f314332a28c" width="308" /> Kurs euro - 01.12.2023. W piątek za jedno euro (EUR) trzeba zapłacić 4.3507 zł.

## Ile kosztuje funt? Kurs funta do złotego PLN/GBP 01.12.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-01-12-2023-6968977083927040a.html](https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-01-12-2023-6968977083927040a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-12-01T06:00:22+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c374eefc-9e8b-424a-aaa7-91759b47d116" width="308" /> Kurs funta szterlinga - 01.12.2023. W piątek za jednego funta brytyjskiego (GBP) trzeba zapłacić 5.0417 zł.

## Handel zaskoczony. "Dowiadują się, że muszą stawić się do pracy w ostatniej chwili"
 - [https://www.money.pl/gospodarka/handel-zaskoczony-dowiaduja-sie-ze-musza-stawic-sie-do-pracy-w-ostatniej-chwili-6968973769317248a.html](https://www.money.pl/gospodarka/handel-zaskoczony-dowiaduja-sie-ze-musza-stawic-sie-do-pracy-w-ostatniej-chwili-6968973769317248a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-12-01T05:54:58+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/21626186-2d26-4b3f-af45-29fe3c76b135" width="308" /> Wprowadzenie dodatkowych niedziel handlowych jest zaskoczeniem dla pracowników, którzy niemal w ostatniej chwili dowiadują się, że muszą stawić się do pracy 10 i 17 grudnia - powiedział  przewodniczący Ogólnopolskiego Porozumienia Związków Zawodowych Piotr Ostrowski.

## Ekipa Tuska ma poważny problem. Sprawa się rozlewa. Jest deklaracja
 - [https://www.money.pl/gospodarka/kosiniak-kamysz-odpowiada-beacie-szydlo-nie-ma-zadnej-afery-6968963377850880a.html](https://www.money.pl/gospodarka/kosiniak-kamysz-odpowiada-beacie-szydlo-nie-ma-zadnej-afery-6968963377850880a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-12-01T05:16:52+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b7cd4d8d-0fa8-440b-8cb7-281bd4c826f8" width="308" /> - Nie będzie żadnego wywłaszczania pod farmy wiatrowe,  nie ma żadnej afery - powiedział  prezes PSL Władysław Kosiniak-Kamysz, odnosząc się do krytyki polityków PiS, którzy mówią o "aferze wiatrakowej" ws. projektu nowelizacji ustawy dot. wsparcia odbiorców energii.

