# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## WTF did Samsung just do?!
 - [https://www.youtube.com/watch?v=S8inhWG0zEM](https://www.youtube.com/watch?v=S8inhWG0zEM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2023-12-01T16:02:02+00:00

Visit https://brilliant.org/TFC/ to get started learning STEM with a 30 day free trial, and the first 200 people will get 20% off their annual premium subscription - Sponsored by Brilliant.

 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  
 
►►► This video ◄◄◄  

This week Samsung released and then unreleased its Samsung Internet web browser on Windows, the company's sales data reveals the Fold isn't selling great and Amazon at re:Invent said it can do AI too!

Episode 175
 
This video on Nebula: https://nebula.tv/videos/tfc-finally-a-new-desktop-browser

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► TechAltar links ◄◄◄  
 
Social media:  
https://mas.to/@techaltar
https://bsky.app/profile/techaltar.bsky.social
https://instagram.com/TechAltar 
https://discord.gg/npKQebe  
 
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
 
►►► Attributions & Time stamps◄◄◄

Writing & Research: Tristan Rayner
Music by Edemski: https://soundcloud.com/edemski 

Stock assets: Getty Images, AP Archive

0:00 Intro
0:29 The Brief
3:25 Samsung Browser meets Windows
5

