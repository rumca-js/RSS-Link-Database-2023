# Source:CBC | Top Stories News, URL:https://www.cbc.ca/webfeed/rss/rss-topstories, language:en

## Mating dance of sea fireflies is 'the coolest fireworks show that you've ever seen'
 - [https://www.cbc.ca/radio/asithappens/sea-firefly-mating-dance-1.7046972?cmp=rss](https://www.cbc.ca/radio/asithappens/sea-firefly-mating-dance-1.7046972?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-12-01T18:25:58+00:00

<img alt="A clear blob with a pink shrimp-like body inside emits a blue light." height="349" src="https://i.cbc.ca/1.7047039.1701470762!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/ostracod.jpg" title="Ostracods are crustaceans about the size of a sesame seed." width="620" /><p>Scientists have discovered a species of crustaceans, each the size of a sesame seed, whose males lure potential mates with a synchronized and dazzling lights display powered by iridescent mucus.</p>

## Doctor will repay $100K loan provided as incentive to work in northern Manitoba town
 - [https://www.cbc.ca/news/canada/manitoba-doctor-loan-repayment-1.7046207?cmp=rss](https://www.cbc.ca/news/canada/manitoba-doctor-loan-repayment-1.7046207?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-12-01T18:09:01+00:00

<img alt="Doctor with stethoscope." height="349" src="https://i.cbc.ca/1.6204399.1700006222!/cumulusImage/httpImage/image.jpg_gen/derivatives/16x9_620/shutterstock-medium-file.jpg" title="There is growing opposition to a plan by the College of Family Physicians of Canada to increase the time it takes to train a family doctor from two years to three – and it’s coming from medical students, family doctors and provincial health ministers." width="620" /><p>Dr. Andrea Wilson, a family doctor who committed to work for a decade in the northern Manitoba community of The Pas — and then left within two years — says she has agreed to repay a $100,000 interest-free loan provided as a recruitment incentive.</p>

## Inmate charged in prison stabbing of ex-police officer convicted of killing George Floyd
 - [https://www.cbc.ca/news/world/derek-chauvin-stabbed-jail-george-floyd-inmate-charged-attempted-murder-1.7046925?cmp=rss](https://www.cbc.ca/news/world/derek-chauvin-stabbed-jail-george-floyd-inmate-charged-attempted-murder-1.7046925?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-12-01T17:04:25+00:00

<img alt="A screengrab from a video shows a person in prison garb." height="349" src="https://i.cbc.ca/1.7040041.1700880149!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/george-floyd-officer-tax-evasion.jpg" title="Former Minneapolis police officer Derek Chauvin, serving time for the 2020 murder of George Floyd, appears via Zoom from a federal prison in Tucson, Ariz., on Friday, March 17, 2023. Chauvin pleaded guilty to aiding and abetting, failing to file tax returns to the state of Minnesota for the years 2016 and 2017." width="620" /><p>A U.S. federal inmate was charged Friday with attempted murder in the prison stabbing of Derek Chauvin, the former Minneapolis police officer convicted of murdering George Floyd.</p>

## Man charged in Winnipeg rooming house shootings was in Canadian military
 - [https://www.cbc.ca/news/canada/manitoba/jamie-felix-background-west-broadway-shooting-1.7046788?cmp=rss](https://www.cbc.ca/news/canada/manitoba/jamie-felix-background-west-broadway-shooting-1.7046788?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-12-01T16:59:29+00:00

<img alt="A man wearing sunglasses and a camo military uniform. " height="349" src="https://i.cbc.ca/1.7046819.1701466465!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/jamie-felix-militay.jpg" title="A photo from Jamie Felix&apos;s Instagram show him in a military uniform. He was arrested by Winnipeg police on Friday, Dec. 1, 2023, and faces four counts of second-degree murder in the fatal Nov. 26 shooting of four people in Winnipeg&apos;s West Broadway neighbourhood." width="620" /><p></p>

## Runaway kangaroo shocks Toronto-area family
 - [https://www.cbc.ca/news/canada/toronto/runaway-kangaroo-shocks-toronto-area-family-1.7046910?cmp=rss](https://www.cbc.ca/news/canada/toronto/runaway-kangaroo-shocks-toronto-area-family-1.7046910?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-12-01T16:32:00+00:00

<img alt="" height="349" src="https://thumbnails.cbc.ca/maven_legacy/thumbnails/513/322/16x9_Thumbs_(15).png" title="" width="620" /><p>Paul Rellinger was taking his son to school when they came across a kangaroo hopping along the side of the road in Oshawa, Ont.</p>

## What we know so far about Google's $100M media fund
 - [https://www.cbc.ca/news/politics/google-money-media-compensation-details-1.7046677?cmp=rss](https://www.cbc.ca/news/politics/google-money-media-compensation-details-1.7046677?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-12-01T16:16:52+00:00

<img alt="A photograph of the Google on the side of a glass building. " height="349" src="https://i.cbc.ca/1.6447026.1701461716!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/google-office-return-delay.jpg" title="A sign is shown on a Google building at their campus in Mountain View, Calif. in this file photo from 2019. The internet search giant says its advertising technology supports thousands of businesses, from small advertisers to major publishers, rejecting a claim that it had colluded with Facebook to exploit ad markets." width="620" /><p>This week, Google struck an agreement with the federal government that will see it pay $100 million in financial support to news outlets across the country. Detailed regulations on how the money will be managed and distributed have not yet been published. Here is what we know so far.</p>

## Sheet music written by Auschwitz prisoners collected dust for decades. This British composer restored it
 - [https://www.cbc.ca/radio/asithappens/sheet-music-written-by-auschwitz-prisoners-collected-dust-for-decades-this-british-composer-restored-it-1.7046374?cmp=rss](https://www.cbc.ca/radio/asithappens/sheet-music-written-by-auschwitz-prisoners-collected-dust-for-decades-this-british-composer-restored-it-1.7046374?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-12-01T16:12:07+00:00

<img alt="A white piece of sheet music, with black music notes filling the bars of the page. There&apos;s a hole in the middle of the page and the bottom edge is scorched." height="349" src="https://i.cbc.ca/1.7046415.1701451583!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/auschwitz-recovered-sheet-music.jpg" title="Some of the recovered sheet music held in the archives of the Auschwitz-Birkenau memorial and museum. Some of the edges are ripped and scorched, and none of the sheets form complete orchestra scores, making it difficult to understand." width="620" /><p>After eight years spent recovering the documents, Leo Geyer finally brought one of the pieces to an audience. He hopes the music helps people better understand Holocaust history.</p>

## Courthouse serving Cree and Inuit in northern Quebec burns, further delaying justice
 - [https://www.cbc.ca/news/canada/montreal/whapmagoostui-courthouse-fire-1.7046173?cmp=rss](https://www.cbc.ca/news/canada/montreal/whapmagoostui-courthouse-fire-1.7046173?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-12-01T15:03:43+00:00

<img alt="A building is on fire." height="349" src="https://i.cbc.ca/1.7046175.1701460262!/fileImage/httpImage/image.png_gen/derivatives/16x9_620/whapmagoostui-courthouse-fire.png" title="The fire started Tuesday night. Investigators are still trying to determine how it started." width="620" /><p>Court cases in the already backlogged system are being rescheduled for February as Nunavik police continue investigating what caused the fire.</p>

## Calgary man who searched 'killing of gay persons,' posted ISIS propaganda to TikTok, pleads to terror charge
 - [https://www.cbc.ca/news/canada/calgary/zakarya-hussein-terrorism-plea-calgary-rcmp-court-tiktok-social-media-1.7046447?cmp=rss](https://www.cbc.ca/news/canada/calgary/zakarya-hussein-terrorism-plea-calgary-rcmp-court-tiktok-social-media-1.7046447?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-12-01T13:54:15+00:00

<img alt="Gold doors out front of the Calgary Court Centre&apos;s main entrance." height="349" src="https://i.cbc.ca/1.3043576.1687195511!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/calgary-court-centre.jpg" title="Jynelle Marshall is one of two Mount Royal University students who served on a jury and then had to fight to get the school to refund course fees for classes they were unable to finish. " width="620" /><p>A Calgary man who purported to be a member of ISIS appeared to be planning to kill gay people participating in local pride events, a judge heard during a guilty plea to a terrorism charge Friday.</p>

## 81-year-old ex-Montrealer coming back to face Canadian justice in 1975 cold-case killing
 - [https://www.cbc.ca/news/canada/ottawa/81-year-old-ex-montrealer-coming-back-to-face-canadian-justice-in-1975-cold-case-killing-1.7046410?cmp=rss](https://www.cbc.ca/news/canada/ottawa/81-year-old-ex-montrealer-coming-back-to-face-canadian-justice-in-1975-cold-case-killing-1.7046410?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-12-01T13:47:08+00:00

<img alt="A man fills out a job application." height="349" src="https://i.cbc.ca/1.6939273.1692287932!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/rodney-nichols.jpg" title="A photo of Rodney Nichols taken from the South Florida Sun Sentinel. Nichols is facing extradition to Canada from Florida to face charges related to the death of Jewell Parchman Langford." width="620" /><p>Officers from the Ontario Provincial Police have gone to Florida to repatriate a former Montreal resident charged with the murder of his former girlfriend, who was found strangled in the Nation River in eastern Ontario 48 years ago.</p>

## U.S. politician George Santos expelled from Congress
 - [https://www.cbc.ca/news/world/george-santos-expelled-from-house-1.7046258?cmp=rss](https://www.cbc.ca/news/world/george-santos-expelled-from-house-1.7046258?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-12-01T11:15:26+00:00

<img alt="A man in a navy sweater and black jacket walks down a hall filled with TV cameras." height="349" src="https://i.cbc.ca/1.7046267.1701447007!/fileImage/httpImage/image.JPG_gen/derivatives/16x9_620/usa-congress-santos.JPG" title="U.S. Representative George Santos walks to a series of votes including a vote to expel him from the House of Representatives on Capitol Hill in Washington on Dec. 1, 2023." width="620" /><p>New York Rep. George Santos, who has been embroiled in criminal and ethical investigations over his conduct, has been expelled from Congress after a vote by his Republican peers on Friday, becoming only the sixth member ousted from the chamber in its history.</p>

## Zelenskyy says domestic weapons production, U.S. election critical for Ukraine war success
 - [https://www.cbc.ca/news/world/ukraine-war-status-zelenskyy-1.7046024?cmp=rss](https://www.cbc.ca/news/world/ukraine-war-status-zelenskyy-1.7046024?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-12-01T10:27:51+00:00

<img alt="A bearded man is shown in a closeup photograph." height="349" src="https://i.cbc.ca/1.7046084.1701441339!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/the-ap-interview-zelenskyy.jpg" title="Ukrainian President Volodymyr Zelenskyy poses for a photo after his interview with The Associated Press in Kharkiv, Ukraine, Thursday, Nov. 30, 2023. (AP Photo/" width="620" /><p>Ukrainian President Volodymyr praised his troops in an exclusive interview Thursday with The Associated Press but admitted this year's counteroffensive 'did not achieve the desired result.' As well, he said, there are many challenges ahead.</p>

## Canada added 25,000 jobs last month, StatsCan says
 - [https://www.cbc.ca/news/business/canada-jobs-november-1.7046030?cmp=rss](https://www.cbc.ca/news/business/canada-jobs-november-1.7046030?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-12-01T08:51:16+00:00

<img alt="Canadian employers added more than 270,000 jobs in the last five months." height="349" src="https://i.cbc.ca/1.6601072.1680813535!/fileImage/httpImage/image.JPG_gen/derivatives/16x9_620/now-hiring-sign-urban-outfitters.JPG" title="According to the labour survey recently released by Statistics Canada, the province is up by 6,300 jobs compared to this time last year.  " width="620" /><p>Canada's economy added 25,000 new jobs in November, Statistics Canada reported Friday.</p>

## What to know about the electricity regulations Alberta is threatening to defy
 - [https://www.cbc.ca/news/canada/calgary/ottawa-electricity-emissions-regulations-alberta-net-zero-1.7045646?cmp=rss](https://www.cbc.ca/news/canada/calgary/ottawa-electricity-emissions-regulations-alberta-net-zero-1.7045646?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-12-01T08:00:00+00:00

<img alt="A woman stands behind a podium that reads &quot;Standing up for Alberta.&quot;" height="349" src="https://i.cbc.ca/1.7045687.1701392310!/fileImage/httpImage/image.JPG_gen/derivatives/16x9_620/alta-sovereignty-act-20231127.JPG" title="Alberta Premier Danielle Smith speaks on invoking her government’s sovereignty act over federal clean energy regulations, in Edmonton on Nov. 27." width="620" /><p>If you haven’t been following this debate closely, it can be difficult to suss out exactly what everyone is talking about when it comes to Ottawa's net-zero rules. Here's why Alberta is upset, and what's really in the draft regulations.</p>

## Decision in former Regina junior hockey coach's sexual assault trial expected Friday
 - [https://www.cbc.ca/news/canada/saskatchewan/bernie-lynch-decision-1.7044910?cmp=rss](https://www.cbc.ca/news/canada/saskatchewan/bernie-lynch-decision-1.7044910?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-12-01T06:00:00+00:00

<img alt="A man in a speckled shirt walks down the stairs of a courthouse." height="349" src="https://i.cbc.ca/1.6972916.1701379347!/fileImage/httpImage/image.jpeg_gen/derivatives/16x9_620/bernard-bernie-lynch.jpeg" title="Former junior hockey coach Bernard &apos;Bernie&apos; Lynch leaves the Court of King&apos;s Bench in Regina on Wednesday. Lynch has entered not guilty pleas to a count of assault and sexual assault. " width="620" /><p>The one-time coach of the Regina Pats has entered pleas of not guilty to assault and sexual assault charges.</p>

## Counting sheep, and their burps, may help lower global methane emissions
 - [https://www.cbc.ca/news/world/sheep-methane-climate-cop28-1.7045185?cmp=rss](https://www.cbc.ca/news/world/sheep-methane-climate-cop28-1.7045185?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-12-01T04:00:00+00:00

<img alt="Five sheep in an indoor pen look at the camera. " height="349" src="https://i.cbc.ca/1.7045217.1701378492!/fileImage/httpImage/image.JPG_gen/derivatives/16x9_620/sheep.JPG" title="The United Kingdom is home to 33 million sheep.  The government has provided almost three million pounds to track and research how their methane emissions are contributing to climate change." width="620" /><p>Two years ago at the UN Climate Summit in Glasgow, global leaders pledged to cut methane emissions by 30 per cent. In the U.K., some of that work is happening on sheep farms in the English countryside.</p>

## Federal green fund faces new hurdles before its suspension is lifted
 - [https://www.cbc.ca/news/politics/sdtc-investigation-suspension-1.7044145?cmp=rss](https://www.cbc.ca/news/politics/sdtc-investigation-suspension-1.7044145?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-12-01T04:00:00+00:00

<img alt="Minister of Innovation, Science and Industry Francois-Philippe Champagne speaks during a news conference on the next phase of the government’s economic plan at the National Press Theatre in Ottawa, on Tuesday, Nov. 28, 2023." height="349" src="https://i.cbc.ca/1.7044164.1701295330!/fileImage/httpImage/image.JPG_gen/derivatives/16x9_620/housing-affordability-20231128.JPG" title="Minister of Innovation, Science and Industry Francois-Philippe Champagne speaks during a news conference on the next phase of the government’s economic plan at the National Press Theatre in Ottawa, on Tuesday, Nov. 28, 2023." width="620" /><p>The federal government will await the results of another investigation into a controversial green fund before it decides whether to allow the organization to resume distributing funds to companies in the clean tech sector.</p>

## Maestro — Bradley Cooper's cinematic symphony — soars
 - [https://www.cbc.ca/news/entertainment/bradley-cooper-maestro-review-1.7045818?cmp=rss](https://www.cbc.ca/news/entertainment/bradley-cooper-maestro-review-1.7045818?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-12-01T04:00:00+00:00

<img alt="Bradley Cooper, his head sweaty with effort, in a tuxedo as conductor Leonard Berstein. " height="349" src="https://i.cbc.ca/1.7045842.1701392478!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/maestro.jpg" title="Bradley Cooper as Leonard Bernstein, the conductor who he says would pretend to emulate as a child." width="620" /><p>Bradley Cooper, the director and star of A Star is Born, is back in Maestro, his new movie about Leonard Bernstein that CBC's Eli Glasner say is a stunning portrait of a complicated love story.</p>

## Murda Beatz returns to Fort Erie high school a star, after producing Drake, Ariana Grande and more
 - [https://www.cbc.ca/news/canada/hamilton/murda-beatz-school-visit-1.7043732?cmp=rss](https://www.cbc.ca/news/canada/hamilton/murda-beatz-school-visit-1.7043732?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-12-01T04:00:00+00:00

<img alt="A man takes a selfie with a group of excited teens" height="349" src="https://i.cbc.ca/1.7043761.1701285320!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/murda-selfie-bryan-chong.jpg" title="Musician Shane &quot;Murda Beatz&quot; Lindstrom takes a selfie with students at Greater Fort Erie Secondary School. " width="620" /><p>The Nov. 17 spirit assembly at Greater Fort Erie Secondary School, was “without a doubt, the most electric I’ve ever felt this building,” principal Fred Luows said. It was a full house as students and teachers gathered to celebrate student achievement, and special guest, musician and “hometown boy,” Murda Beatz.</p>

## Mushroom farmer takes centre stage in Trudeau-Poilievre carbon tax exchange
 - [https://www.cbc.ca/news/canada/ottawa/justin-trudeau-and-conservative-leader-pierre-poilievre-1.7044919?cmp=rss](https://www.cbc.ca/news/canada/ottawa/justin-trudeau-and-conservative-leader-pierre-poilievre-1.7044919?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-12-01T04:00:00+00:00

<img alt="Mike Medeiros is the co-owner of Carleton Mushroom Farms in southeast Ottawa." height="349" src="https://i.cbc.ca/1.7045282.1701373552!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/mike-medeiros-is-the-co-owner-of-carleton-mushroom-farms-in-southeast-ottawa.jpg" title="Mike Medeiros is the co-owner of Carleton Mushroom Farms in southeast Ottawa." width="620" /><p>A heated exchange in the House of Commons thrust one south Ottawa mushroom farm into the spotlight earlier this week.</p>

## Mushroom farmer takes centre stage in Trudeau-Poilievre carbon tax exchange
 - [https://www.cbc.ca/news/canada/ottawa/justin-trudeau-pierre-poilievre-carbon-tax-mushroom-farm-1.7044919?cmp=rss](https://www.cbc.ca/news/canada/ottawa/justin-trudeau-pierre-poilievre-carbon-tax-mushroom-farm-1.7044919?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-12-01T04:00:00+00:00

<img alt="A farmer waves in a greenhouse-style building with racks of mushrooms." height="349" src="https://i.cbc.ca/1.7045113.1701444137!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/mike-medeiros-is-the-co-owner-of-carleton-mushroom-farms.jpg" title="Mike Medeiros is the co-owner of Carleton Mushroom Farms. " width="620" /><p>A heated exchange in the House of Commons thrust a south Ottawa mushroom farm into the spotlight earlier this week.</p>

## Ottawa starts work on alert system for missing Indigenous women, girls and two-spirit people
 - [https://www.cbc.ca/news/politics/national-red-dress-alert-consultations-begin-1.7037538?cmp=rss](https://www.cbc.ca/news/politics/national-red-dress-alert-consultations-begin-1.7037538?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-12-01T04:00:00+00:00

<img alt="A red dress hangs from a lamppost in front of a legislature." height="349" src="https://i.cbc.ca/1.6836099.1683566027!/fileImage/httpImage/image.JPG_gen/derivatives/16x9_620/red-dress-day-mmiwg-ottawa-2023.JPG" title="A red dress hangs on a light fixture during on the National Day of Awareness for Missing and Murdered Indigenous Women, also known as Red Dress Day, in Ottawa on May 5, 2023." width="620" /><p>Ottawa is beginning consultations today on creating a public alert system for missing Indigenous women, girls and two-spirit people, as some advocates call on the federal government to expand emergency notifications for all Indigenous people.</p>

## The fight over the Senate's handling of the carbon tax is a portent of things to come
 - [https://www.cbc.ca/news/politics/carbon-tax-poilievre-trudeau-senate-1.7044938?cmp=rss](https://www.cbc.ca/news/politics/carbon-tax-poilievre-trudeau-senate-1.7044938?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-12-01T04:00:00+00:00

<img alt="A man in a blue suit stands and gestures." height="349" src="https://i.cbc.ca/1.7045640.1701384550!/fileImage/httpImage/image.JPG_gen/derivatives/16x9_620/question-period-20231128.JPG" title="Conservative Leader Pierre Poilievre rises during question period in the House of Commons on Parliament Hill in Ottawa on Tuesday, Nov. 28, 2023." width="620" /><p>It seems that personal views of the Senate's rights and privileges can depend on where one happens to be sitting in Parliament at the time. At least one major aspect of the Senate has changed in the past 13 years — it has a mind of its own now.</p>

