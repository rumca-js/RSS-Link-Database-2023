# Source:The Telegraph Business, URL:https://www.telegraph.co.uk/business/rss.xml, language:en-UK

## Ryanair caught up in 'fake' airline parts scandal - latest updates
 - [https://www.telegraph.co.uk/business/2023/12/01/ftse-100-markets-news-house-price-index-live](https://www.telegraph.co.uk/business/2023/12/01/ftse-100-markets-news-house-price-index-live)
 - RSS feed: https://www.telegraph.co.uk/business/rss.xml
 - date published: 2023-12-01T09:16:43+00:00



