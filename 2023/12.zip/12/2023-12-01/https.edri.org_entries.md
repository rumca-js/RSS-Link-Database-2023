## EP rejects mass scanning of private messages - European Digital Rights (EDRi)
 - [https://edri.org/our-work/csar-european-parliament-rejects-mass-scanning-of-private-messages](https://edri.org/our-work/csar-european-parliament-rejects-mass-scanning-of-private-messages)
 - RSS feed: https://edri.org
 - date published: 2023-12-01T08:30:16+00:00

EP rejects mass scanning of private messages - European Digital Rights (EDRi)

