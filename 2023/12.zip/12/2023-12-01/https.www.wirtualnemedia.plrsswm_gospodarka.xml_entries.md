# Source:Wirtualne Media, URL:https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml, language:pl-PL

## Dla 68 proc. firm zatory płatnicze to bariera w działalności gospodarczej
 - [https://www.wirtualnemedia.pl/artykul/zatory-platnicze-bariera-w-dzialalnosci-gospodarczej](https://www.wirtualnemedia.pl/artykul/zatory-platnicze-bariera-w-dzialalnosci-gospodarczej)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-12-01T11:22:22.334140+00:00

Dla 68 proc. firm zatory płatnicze są barierą w działalności gospodarczej; regulowanie zobowiązań z opóźnieniem jest dotkliwe głównie dla branży budowlanej i handlowej - wynika z badania "Przeterminowanie faktur w polskich przedsiębiorstwach", o czym informuje Krajowy Rejestr Długów.

## Polscy konsumenci w najlepszych nastrojach od wybuchu pandemii koronawirusa
 - [https://www.wirtualnemedia.pl/artykul/polscy-konsumenci-w-najlepszych-nastrojach-od-wybuchu-pandemii-koronawirusa](https://www.wirtualnemedia.pl/artykul/polscy-konsumenci-w-najlepszych-nastrojach-od-wybuchu-pandemii-koronawirusa)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-12-01T11:22:22.333304+00:00

W listopadzie br. wskaźnik nastrojów konsumenckich w Polsce lekko wzrósł, zbliżając się do zera. Ostatni raz „na plusie” nastroje znajdowały się bowiem w marcu 2020 r. Konsumencki optymizm napędzają przede wszystkim młodzi. Bardziej sceptyczni są Polacy w średnim wieku oraz seniorzy – pokazują nowe dane z Barometru Nastrojów Konsumenckich opracowanego przez firmę GfK– An NIQ Company.

## CCC mniej zadłużone. Spłaciło 160 mln zł
 - [https://www.wirtualnemedia.pl/artykul/ccc-dlug-kredyty-kurs-akcji](https://www.wirtualnemedia.pl/artykul/ccc-dlug-kredyty-kurs-akcji)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-12-01T11:22:22.332455+00:00

Grupa CCC przedterminowo spłaciła 160 mln zł zadłużenia wobec instytucji finansujących. To ostatni w br. etap delewarowania firmy.

## Najwięcej wśród freelancerów zarabiają programiści, najsłabiej copywriterzy
 - [https://www.wirtualnemedia.pl/artykul/najwiecej-wsrod-freelancerow-zarabiaja-programisci-najslabiej-copywriterzy](https://www.wirtualnemedia.pl/artykul/najwiecej-wsrod-freelancerow-zarabiaja-programisci-najslabiej-copywriterzy)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-12-01T11:22:22.331527+00:00

Najwięcej wśród freelancerów zarabiają programiści. W tej branży miesięczne wynagrodzenie powyżej 10 tys. złotych wskazało 8,3 proc. programistów, a aż 44,5 proc. badanych zadeklarowało, że ich zarobki wzrosły – wynika z raportu firmy Useme.

## Daniel Obajtek zapowiada kroki prawne. Wirtualna Polska ujawniła, że przepisał działki na syna
 - [https://www.wirtualnemedia.pl/artykul/daniel-obajtek-dzialki-majatek-przepisal-syna-pozew-wirtualna-polska-szymon-jadczak-maciej-zaborowski-adwokat](https://www.wirtualnemedia.pl/artykul/daniel-obajtek-dzialki-majatek-przepisal-syna-pozew-wirtualna-polska-szymon-jadczak-maciej-zaborowski-adwokat)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-12-01T11:22:22.330624+00:00

Wirtualna Polska opisała, prezes Orlenu Daniel Obajtek niedawno przepisał swoje wszystkie nieruchomości na syna. Obajtek zapowiedział, że podejmie w tej sprawie działania prawne. - Mój majątek został wielokrotnie prześwietlony, a to, co komu przekazuję, jest moją prywatną sprawą - podkreślił.

