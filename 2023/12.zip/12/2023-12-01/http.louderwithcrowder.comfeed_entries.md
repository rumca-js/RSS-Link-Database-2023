# Source:Louder With Crowder, URL:http://louderwithcrowder.com/feed/, language:en-US

## Philadelphia Votes To Ban Ski Masks In Public, Then Gets Accused Of Criminalizing Black Men
 - [https://www.louderwithcrowder.com/philadelphia-ski-masks](https://www.louderwithcrowder.com/philadelphia-ski-masks)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-12-01T21:50:25+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=50619658&amp;width=1200&amp;height=800&amp;coordinates=109%2C0%2C41%2C0" /><br /><br /><p>If you look at any progressive-run city, it is hard to tell if that is America or part of the third world. This is because when progressives run anything, they create utter ruin. After all, it turns out that when you run things based on identity politics, things turn out very, very bad. </p><p>This has become painfully obvious. So for progressives to pretend they care, they pass little bills that they claim will prevent crime. We know it won't since the DA does not prosecute crime. So Philidelphian progressives are just doing what they do best, which is to signal virtue and pretend they are working on the issues. </p><p>The Philadelphia City Council voted 13-2 Thursday to pass legislation banning facial coverings in public in hopes of cutting down on the violent crime that continues to plague the Progressive-run city. This ha

## LOL! Gavin Newsom’s Wife Forced Him Off Debate Stage: Report
 - [https://www.louderwithcrowder.com/gavion-newsoms-wife-stopped-debate](https://www.louderwithcrowder.com/gavion-newsoms-wife-stopped-debate)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-12-01T21:43:14+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=50619612&amp;width=1200&amp;height=800&amp;coordinates=73%2C0%2C127%2C0" /><br /><br /><p>The biggest win for Gavin Newsom last night was that he even agreed to the debate in the first place knowing what a dismal failure he is. But unfortunately, sometimes people don’t know when to quit. That is why Newsom’s wife had to tell him he had made enough of a fool for one night. </p><p><a href="https://www.nbcnews.com/politics/2024-election/gavin-newsom-fox-debate-rcna127563" rel="noopener noreferrer" target="_blank">According </a>to NBC: </p><p>“According to four sources in the DeSantis camp — one who witnessed the moment in the room and three others who were standing backstage (where there was no press or live studio audience) — Newsom’s wife, Jennifer Siebel Newsom, came into the debate room on at least two occasions to raise some objections. She also made her way to the stage during the break after the candidates agr

## New Vegan Propaganda Film Attacks Christianity, Claims Eating Delicious Meat Is Blasphemy
 - [https://www.louderwithcrowder.com/vegan-film-christianity](https://www.louderwithcrowder.com/vegan-film-christianity)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-12-01T18:44:16+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=50618027&amp;width=1200&amp;height=800&amp;coordinates=200%2C0%2C0%2C0" /><br /><br /><p>Vegan film producers are in the making of a new propaganda film that is by far the worst one yet. </p><p>From the trailer and descriptions, it appears that the film makes false claims that the “true” believers of several religions should be vegans by using manipulated explanations of Biblical and religious texts to impose their lifestyle onto others. </p><p>I am sure the film will also use holidays to try and push their propaganda as we often see vegans try and manipulate the meaning of Lent to abstain from meat. I am also sure the film will painfully ignore the fact that the Bible, Torah, and Qur’an all explain the human role of dominion over other creatures.</p><p>When Friedrich Nietzsche <a href="https://www.thecollector.com/why-did-friedrich-nietzsche-say-god-is-dead/" rel="noopener noreferrer" target="_blank">said </a>“Go

## Ex-con arrested concealing a gun during a traffic stop. He was concealing it in his butt, police say
 - [https://www.louderwithcrowder.com/ex-con-gun-rectum](https://www.louderwithcrowder.com/ex-con-gun-rectum)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-12-01T18:03:07+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=50616185&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C2" /><br /><br /><p>I'll skip the part where I lead with a "concealed carry" joke since, at this point, I'm sure they've all been done. But, yeah. An ex-con was caught with a handgun shoved up his rump. LFG!</p><p>Christopher Boyd got pulled over at 2 AM in Indiana because his license plate was obscured. Cops caught him with pills he claimed he scored from his aunt to deal with the pain of having a bullet lodged in his spine.</p><p>During the patdown, Boyd claimed he couldn't spread his legs because of his spinal injury. No, that wasn't the real reason.</p><blockquote>After being taken into custody, officials noticed he was “walking with a limp and appeared to be clenching his buttocks when he walked,” the police report said.<br /><br /><span></span>A body scan revealed a “large object” in his groin area, and a strip search revealed that Boyd had a

## Florida Enacts Law Saying Govt Funded Orgs Can't Force Pronouns On People. Those Who Force Pronouns Are Pissed.
 - [https://www.louderwithcrowder.com/pronoun-florida-bill](https://www.louderwithcrowder.com/pronoun-florida-bill)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-12-01T17:15:13+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=50616148&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C0" /><br /><br /><p>Children are constantly being targeted with sexual content. This is not just on social media. We now live in a time where this is rampant in school curriculums. That is why Florida did something about that. </p><p>Not too long ago, Liberal activists claimed that Florida’s parental rights bill would harm kids, which was a bunch of nonsense since it protects kids from what is de facto sexual grooming. </p><p>Obviously, the alphabet mob did not like the bill. It is not clear why they hated it so much but it is probably safe to assume that they didn’t like how Florida recognized the rights of parents to raise and teach their children. </p><p>Anyone with common sense knows that we should protect young children from sexual content but I guess when you think Sally can become Joe, well not much sense is common. </p><p>Anyway, LGBT organ

## Girls HS Volleyball Player Suffers Concussion Thanks To Male Opponent, Her Dad's Afraid Of Being Called "Transphobe"
 - [https://www.louderwithcrowder.com/girls-volleyball-player-injured-male](https://www.louderwithcrowder.com/girls-volleyball-player-injured-male)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-12-01T15:21:11+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=50611318&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C0" /><br /><br /><p>A female high school student suffered a concussion in a San Francisco area volleyball game. I'd say stop me if you've heard this one before, <a href="https://www.louderwithcrowder.com/female-volleyball-player-concussed" target="_blank">but I know you have</a>. Her opponent was a dude. But a dude who identifies as a girl. And the female high school student's dad is having a struggle session with himself because, on one hand, he doesn't want to deny the trans-identifying male's identity.</p><p>On the other hand, that trans-identifying male JUST GAVE HIS DAUGHTER A F*CKING CONCUSSION.</p><p>Shout out to <a href="https://reduxx.info/" target="_blank">Reduxx</a>, who has been crushing it <a href="https://www.louderwithcrowder.com/female-boxer-pulls-put-of-fight" target="_blank">with the exclusives</a> lately.</p><blockquote class="rm

## Watch: Meet the trans professor teaching a HARVARD class on Taylor Swift's relationship with Travis Kelce
 - [https://www.louderwithcrowder.com/taylor-swift-harvard-professor](https://www.louderwithcrowder.com/taylor-swift-harvard-professor)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-12-01T14:28:19+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=50607333&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C0" /><br /><br /><p>Harvard has become a bastion of many things as of late. <a href="https://www.louderwithcrowder.com/harbard-israel-hamas-protest" target="_blank">Rampant antisemitism</a>. Former child star David Hogg. <a href="https://www.louderwithcrowder.com/harvard-free-speech" target="_blank">Not defunding the Thought Police</a>. But now they're about to go from an obscure New England school to the most prestigious institute of higher learning in America. They are offering a class on Taylor Swift. "Taylor Swift and Her World." We can confirm her relationship with Travis Kelce will be on the syllabus.</p><p>Don't get too excited yet, though, Chiefs fans. Taylor hasn't written a song about him yet, so at best, there will only be a pop-up quiz until she does.</p><p>The class will be taught by Harvard English professor Stephanie Burt. As you can

## Watch: Did the Irish Government get YouTube to remove our Ireland riots/Conor McGregor video?
 - [https://www.louderwithcrowder.com/irish-government-censoring-steven-crowder](https://www.louderwithcrowder.com/irish-government-censoring-steven-crowder)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-12-01T13:10:18+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=50607000&amp;width=1200&amp;height=800&amp;coordinates=82%2C0%2C118%2C0" /><br /><br /><p>It hurts me that the old country has become our latest "Pay Attention, America" example. I have my Irish flag, the one I wore to <a href="https://www.louderwithcrowder.com/dana-white-donald-trump-protest" target="_blank">UFC 205 when Conor McGregor</a> became the champ-champ (and when Becky Lynch did at WrestleMania), hanging up in my gym. But this video that I had bookmarked from yesterday took on a new meaning after YouTube removed ANOTHER one of our videos.</p><p>For those of you playing the home game, <a href="https://www.louderwithcrowder.com/crowder-bongino-youtube-suspension" target="_blank">that now makes THREE this week</a>.</p><p>Fine Gael, the party of the progressive centre and part of the current coalition Government of Ireland (that's what they call it when you don't have a two-party system like a proper country

