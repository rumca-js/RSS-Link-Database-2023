# Source:Wydarzenia Interia - Świat, URL:https://wydarzenia.interia.pl/swiat/feed, language:pl-PL

## Tajne gry wojenne w Szwecji. Przygotowanie przed ważnym wydarzeniem
 - [https://wydarzenia.interia.pl/zagranica/news-tajne-gry-wojenne-w-szwecji-przygotowanie-przed-waznym-wydar,nId,7183252](https://wydarzenia.interia.pl/zagranica/news-tajne-gry-wojenne-w-szwecji-przygotowanie-przed-waznym-wydar,nId,7183252)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-12-01T07:24:02+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-tajne-gry-wojenne-w-szwecji-przygotowanie-przed-waznym-wydar,nId,7183252"><img align="left" alt="Tajne gry wojenne w Szwecji. Przygotowanie przed ważnym wydarzeniem" src="https://i.iplsc.com/tajne-gry-wojenne-w-szwecji-przygotowanie-przed-waznym-wydar/000I4NF716RCHDDT-C321.jpg" /></a>Ostatnie zapewnienia ze strony Turcji wskazują, że Szwecja może dołączyć do NATO za kilka tygodni. Chociaż na przyjęcie do Sojuszu Północnoatlantyckiego czeka już półtora roku, wojsko już ćwiczy. Oficerowie ze Szwecji biorą udział w tajnych grach wojennych NATO. </p><br clear="all" />

## "The Washington Post": Po 56 latach od pierwszego listu spotkali się po raz pierwszy w życiu
 - [https://wydarzenia.interia.pl/raport-media-zagraniczne/news-the-washington-post-po-56-latach-od-pierwszego-listu-spotkal,nId,7177385](https://wydarzenia.interia.pl/raport-media-zagraniczne/news-the-washington-post-po-56-latach-od-pierwszego-listu-spotkal,nId,7177385)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-12-01T06:55:00+00:00

<p><a href="https://wydarzenia.interia.pl/raport-media-zagraniczne/news-the-washington-post-po-56-latach-od-pierwszego-listu-spotkal,nId,7177385"><img align="left" alt="&quot;The Washington Post&quot;: Po 56 latach od pierwszego listu spotkali się po raz pierwszy w życiu" src="https://i.iplsc.com/the-washington-post-po-56-latach-od-pierwszego-listu-spotkal/000I48P3ABPN5QDJ-C321.jpg" /></a>Ona była 12-letni uczennicą z Michigan, on 30-letnim żołnierzem na wojnie w Wietnamie. W 1967 roku zaczęli do siebie pisać. Ona opowiadała mu o swoich ocenach, on starał się nie wspominać o okropieństwach wojny. Teraz spotkali się po raz pierwszy w życiu.</p><br clear="all" />

## Jan Piekło: To wygląda na przygotowanie do większego konfliktu światowego
 - [https://wydarzenia.interia.pl/zagranica/news-jan-pieklo-to-wyglada-na-przygotowanie-do-wiekszego-konflikt,nId,7181344](https://wydarzenia.interia.pl/zagranica/news-jan-pieklo-to-wyglada-na-przygotowanie-do-wiekszego-konflikt,nId,7181344)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-12-01T06:53:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-jan-pieklo-to-wyglada-na-przygotowanie-do-wiekszego-konflikt,nId,7181344"><img align="left" alt="Jan Piekło: To wygląda na przygotowanie do większego konfliktu światowego" src="https://i.iplsc.com/jan-pieklo-to-wyglada-na-przygotowanie-do-wiekszego-konflikt/000I4IMCMAJX2G4A-C321.jpg" /></a>- Nie wiemy, co się dzieje z Władimirem Putinem. Trwa tam jakaś walka, roszady w elicie kremlowskiej. Poza tym doszło do wybuchu magistrali kolejowej Rosja-Chiny, co oznacza zniszczenie korytarza transportowego z Chin, a może nim być dostarczana broń - mówi Interii Jan Piekło, ambasador RP w Ukrainie w latach 2016-2019.</p><br clear="all" />

## "The Telegraph": Teoria wielkich ludzi kształtujących historię chwieje się w posadach
 - [https://wydarzenia.interia.pl/raport-media-zagraniczne/news-the-telegraph-teoria-wielkich-ludzi-ksztaltujacych-historie-,nId,7164767](https://wydarzenia.interia.pl/raport-media-zagraniczne/news-the-telegraph-teoria-wielkich-ludzi-ksztaltujacych-historie-,nId,7164767)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-12-01T06:51:00+00:00

<p><a href="https://wydarzenia.interia.pl/raport-media-zagraniczne/news-the-telegraph-teoria-wielkich-ludzi-ksztaltujacych-historie-,nId,7164767"><img align="left" alt="&quot;The Telegraph&quot;: Teoria wielkich ludzi kształtujących historię chwieje się w posadach" src="https://i.iplsc.com/the-telegraph-teoria-wielkich-ludzi-ksztaltujacych-historie/000I28J6CF7NPMY2-C321.jpg" /></a>Czy pojedynczy człowiek, nawet jeśli wybitny, może zmienić historię i wpłynąć na życie milionów ludzi? Historia zna przypadki Aleksandra Wielkiego, Napoleona, Winstona Churchilla czy Franklina Delano Roosevelta, którzy swoim postępowaniem odcisnęli znaczące piętno w dziejach świata. A jak jest teraz?</p><br clear="all" />

## Czystki w argentyńskim rządzie. Pierwsze decyzje nowego prezydenta
 - [https://wydarzenia.interia.pl/zagranica/news-czystki-w-argentynskim-rzadzie-pierwsze-decyzje-nowego-prezy,nId,7183225](https://wydarzenia.interia.pl/zagranica/news-czystki-w-argentynskim-rzadzie-pierwsze-decyzje-nowego-prezy,nId,7183225)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-12-01T06:00:06+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-czystki-w-argentynskim-rzadzie-pierwsze-decyzje-nowego-prezy,nId,7183225"><img align="left" alt="Czystki w argentyńskim rządzie. Pierwsze decyzje nowego prezydenta" src="https://i.iplsc.com/czystki-w-argentynskim-rzadzie-pierwsze-decyzje-nowego-prezy/000I4N6MTA183QH8-C321.jpg" /></a>Nowy prezydent Argentyny przeprowadził ministerialne czystki. Skonstruowany przez Javiera Milei gabinet będzie składał się z ośmiu ministrów - wcześniej było ich 19. Część resortów, w tym m.in. ministerstwo zdrowia i kultury zostaną zlikwidowane lub włączone do innych jednostek. Znany ze skrajnie liberalnego podejścia do ekonomii polityk zamierza w ten sposób walczyć z nadmiernymi wydatkami państwa i wysoką inflacją. </p><br clear="all" />

## "Działania zbrojne wznowione". Komunikat ws. rozejmu w Strefie Gazy
 - [https://wydarzenia.interia.pl/raport-wojna-w-izraelu/news-dzialania-zbrojne-wznowione-komunikat-ws-rozejmu-w-strefie-g,nId,7183222](https://wydarzenia.interia.pl/raport-wojna-w-izraelu/news-dzialania-zbrojne-wznowione-komunikat-ws-rozejmu-w-strefie-g,nId,7183222)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-12-01T05:23:14+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wojna-w-izraelu/news-dzialania-zbrojne-wznowione-komunikat-ws-rozejmu-w-strefie-g,nId,7183222"><img align="left" alt="&quot;Działania zbrojne wznowione&quot;. Komunikat ws. rozejmu w Strefie Gazy" src="https://i.iplsc.com/dzialania-zbrojne-wznowione-komunikat-ws-rozejmu-w-strefie-g/000I4N6DO015MS1R-C321.jpg" /></a>Działania zbrojne przeciwko Hamasowi w Strefie Gazy zostały wznowione - przekazała izraelska armia w piątek rano. Jak dodaje agencja Reutera, powołując się na komunikat wojska, samoloty zaczęły już atakować cele Hamasu w Gazie.</p><br clear="all" />

## Alarm w Izraelu. Rakieta wystrzelona przed końcem rozejmu
 - [https://wydarzenia.interia.pl/raport-wojna-w-izraelu/news-alarm-w-izraelu-rakieta-wystrzelona-przed-koncem-rozejmu,nId,7183220](https://wydarzenia.interia.pl/raport-wojna-w-izraelu/news-alarm-w-izraelu-rakieta-wystrzelona-przed-koncem-rozejmu,nId,7183220)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-12-01T04:57:41+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wojna-w-izraelu/news-alarm-w-izraelu-rakieta-wystrzelona-przed-koncem-rozejmu,nId,7183220"><img align="left" alt="Alarm w Izraelu. Rakieta wystrzelona przed końcem rozejmu" src="https://i.iplsc.com/alarm-w-izraelu-rakieta-wystrzelona-przed-koncem-rozejmu/000I4N50Q94RIC5O-C321.jpg" /></a>W piątek rano izraelskie wojsko oświadczyło, że przechwyciło rakietę wystrzeloną ze Strefy Gazy. Pocisk wystrzelono na około godzinę przed planowanym wygaśnięciem rozejmu, który w czwartek został przedłużony. Syreny zawyły po raz pierwszy od wejścia w życie zawieszania broni między Izraelem a Hamasem.</p><br clear="all" />

