# Source:Wiadomosci - Gazeta.pl, URL:https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml, language:pl-PL

## Historyczne głosowanie w USA. Republikanin usunięty z Izby ReprezentantĂłw. "Do diabła z tym miejscem"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30465460,kongres-usa-pierwszy-raz-od-ponad-dwoch-dekad-wyrzucil-kongresmena.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30465460,kongres-usa-pierwszy-raz-od-ponad-dwoch-dekad-wyrzucil-kongresmena.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-01T22:08:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/cd/0d/1d/z30465485M,Kongresmen-George-Santos-wyrzucony-z-Izby-Reprezen.jpg" vspace="2" />- Do diabła z tym miejscem - powiedział George Santos, po czym odjechał z siedziby amerykańskiego Kongresu. Jego członkowie w historycznym głosowaniu wyrzucili go z Izby ReprezentantĂłw. To zaledwie szĂłsty raz w historii StanĂłw Zjednoczonych, kiedy wydalono urzędującego senatora. Ostatni taki przypadek miał miejsce ponad 20 lat temu.

## Szabla, jacht motorowy, księgozbiory i dzieła sztuki. Zebraliśmy ciekawostki z oświadczeń posłĂłw
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30465276,szabla-jacht-motorowy-ksiegozbiory-i-dziela-sztuki-zebralismy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30465276,szabla-jacht-motorowy-ksiegozbiory-i-dziela-sztuki-zebralismy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-01T20:33:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a8/0d/1d/z30463400M,Slubowanie-poselskie-podczas-inauguracyjnego-posie.jpg" vspace="2" />Roman Giertych wpisał do oświadczenia majątkowego szablę wartą 15 tysięcy zł, Witold Tumanowicz z Konfederacji miejsce na cmentarzu, a Włodzimierz Czarzasty jacht motorowy i pokaźną bibliotekę. Oto wybrane ciekawostki z oświadczeń majątkowych posłĂłw.

## Napad na kantor na Lubelszczyźnie. Złodziej sterroryzował pracownicę
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30465171,napad-na-kantor-na-lubelszczyznie-zlodziej-sterroryzowal-pracownice.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30465171,napad-na-kantor-na-lubelszczyznie-zlodziej-sterroryzowal-pracownice.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-01T19:13:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/b3/0d/1d/z30465203M,Napad-na-kantor-na-Lubelszczyznie--Zlodziej-sterro.jpg" vspace="2" />Policja poszukuje mężczyzny, ktĂłry napadł na kantor w miejscowości TarnogrĂłd, około 70 kilometrĂłw od Zamościa (woj. lubelskie). Napastnik zastraszył pracownicę i ukradł gotĂłwkę.

## Horoskop na weekend 2-3 grudnia [Baran, Byk, Bliźnięta, Rak, Lew, Panna, Waga, Skorpion, Strzelec, Koziorożec, Wodnik, Ryby]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,168571,30459705,horoskop-na-weekend-2-3-grudnia-baran-byk-bliznieta-rak.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,168571,30459705,horoskop-na-weekend-2-3-grudnia-baran-byk-bliznieta-rak.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-01T18:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ec/0c/1d/z30460140M,Horoskop-na-weekend-2-3-grudnia-2023-r-.jpg" vspace="2" />Horoskop na weekend 2-3 grudnia 2023 r. Baran wywraca dom do gĂłry nogami, Bliźnięta odkrywają kolejne świetne miejsce na imprezy, a Strzelec niebawem wyrusza w wyczekiwaną podrĂłż. Odszukaj swĂłj znak zodiaku i sprawdź, co czeka cię w ten weekend.

## Śnieg, deszcz i błoto, a Rosjanie pełzną naprzĂłd. Nie tylko Awdijiwka, teraz też Bachmut i Kupiańsk
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30464500,teraz-jeszcze-bachmut-i-plotki-o-nowym-froncie-rosjanie-sa.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30464500,teraz-jeszcze-bachmut-i-plotki-o-nowym-froncie-rosjanie-sa.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-01T17:57:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/bb/0d/1d/z30464699M,Raport-z-sytuacji-na-froncie-w-Ukrainie--Druga-pol.jpg" vspace="2" />Rosjanie osiągają drobne sukcesy na froncie. NiektĂłre bardziej zauważalne (np. pod Bachmutem). Sytuacja nie jest optymistyczna.

## Atak nożownika w szkole na Mazowszu. Sąd podjął decyzję w sprawie aresztu dla 18-latka
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30465021,atak-nozownika-w-szkole-na-mazowszu-sad-podjal-decyzje-w-sprawie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30465021,atak-nozownika-w-szkole-na-mazowszu-sad-podjal-decyzje-w-sprawie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-01T17:29:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/b9/0c/1d/z30459577M,Zespol-Szkol-Powiatowych-w-Kadzidle.jpg" vspace="2" />18-letni uczeń, ktĂłry jest podejrzany o zaatakowanie trojga szkolnych kolegĂłw nożem, trafi do aresztu tymczasowego. Młodemu mężczyźnie postawiono zarzuty usiłowania zabĂłjstwa wielu osĂłb.

## Dlaczego nie namierzano komĂłrki 14-latki z Andrychowa? Policjant stawia sprawę jasno
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30464735,dlaczego-nie-namierzano-komorki-14-latki-z-andrychowa-policjant.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30464735,dlaczego-nie-namierzano-komorki-14-latki-z-andrychowa-policjant.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-01T17:09:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e7/0c/1d/z30459111M,Andrychow--Miejsce--w-ktorym-odnaleziono-dziewczyn.jpg" vspace="2" />Komisariat policji w Andrychowie nie ma możliwości technicznych, by zlokalizować telefon komĂłrkowy - informuje "Rzeczpospolita". Policjant w rozmowie z gazetą tłumaczy, że zgłoszenie musi przyjąć Komenda WojewĂłdzka Policji w Krakowie i przyznaje, że działania funkcjonariuszy trzeba wyjaśnić, ale dopiero od momentu, kiedy przyjęli zgłoszenie. Tutaj wersje rodziny i bliskich zmarłej w Andrychowie 14-latki oraz policji są nieco rozbieżne.

## Kuriozalna sytuacja w Rosji. Opozycjonistę ukarano, bo nie złożył sprawozdania. Jest w więzieniu
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30464240,rosyjski-opozycjonista-zostal-ukarany-w-wiezieniu-powodem-brak.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30464240,rosyjski-opozycjonista-zostal-ukarany-w-wiezieniu-powodem-brak.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-01T16:48:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/74/0d/1d/z30464884M,Rosja--Opozycjonista-Wladimir-Kara-Murza.jpg" vspace="2" />Władimir Kara-Murza został ukarany grzywną w wysokości 50 tysięcy rubli. Powodem jest to, że rosyjski opozycjonista nie złożył sprawozdania ze swojej działalności, mimo że przebywa w syberyjskiej kolonii karnej. Rosyjska ustawa, ktĂłra definiuje opozycjonistĂłw jako "zagranicznych agentĂłw" nie pierwszy raz doprowadziła do kuriozalnej sytuacji.

## Była sędzia Sądu Najwyższego USA Sandra Day O'Connor nie żyje. Była pierwszą kobietą na tym stanowisku
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30464770,byla-sedzia-sadu-najwyzszego-usa-sandra-day-o-connor-nie-zyje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30464770,byla-sedzia-sadu-najwyzszego-usa-sandra-day-o-connor-nie-zyje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-01T16:43:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/08/0d/1d/z30464776M,Sandra-Day-O-Connor.jpg" vspace="2" />W wieku 93 lat zmarła Sandra Day O'Connor, była sędzia amerykańskiego Sądu Najwżyszego, pierwsza kobieta na tym stanowisku.

## Drastycznie wzrosła liczba przypadkĂłw dengi w Europie. Przyczyn jest kilka
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,127561,30463961,rosnie-liczba-przypadkow-dengi-w-europie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,127561,30463961,rosnie-liczba-przypadkow-dengi-w-europie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-01T16:02:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a5/0d/1d/z30464677M,Test-na-denge.jpg" vspace="2" />W 2023 roku w Europie odnotowano najwyższą od niemal 80 lat liczbę lokalnie przenoszonych zakażeń wirusem dengi. Według ekspertĂłw jest wiele możliwych wyjaśnień dla wzrostu przypadkĂłw lokalnie przenoszonej dengi w 2023 roku, ale jasnej odpowiedzi jak dotąd nie ma.

## 12-letnia Anastazja nie odzyska wzroku po ataku nożownika. "Doszło do ślepoty gałki ocznej"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30464372,anastazja-przeszla-zabieg-po-ataku-nozownika-doszlo-do-slepoty.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30464372,anastazja-przeszla-zabieg-po-ataku-nozownika-doszlo-do-slepoty.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-01T15:39:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/dd/0d/1d/z30464733M,Rzeszow--12-letnia-Anastazja-przeszla-zabieg-w-szp.jpg" vspace="2" />Anastazja przeszła w piątek zabieg w szpitalu po ataku nożownika. - Jednak okazało się to nieskuteczne i doszło do ślepoty gałki ocznej - przekazał PAP rzecznik Uniwersyteckiego Szpitala Klinicznego Andrzej Sroka. Prokuratura wszczęła śledztwo w sprawie usiłowania zabĂłjstwa. Podejrzanym jest 16-letni Kyrylo H., ktĂłrego miejsce pobytu zostało wyznaczone przez Ministerstwo Sprawiedliwości.

## ŁukĂłw. 11-latek przyszedł do szkoły z nożem. "Miał straszyć młodszych kolegĂłw"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30464526,lukow-11-latek-przyszedl-do-szkoly-z-nozem-mial-straszyc.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30464526,lukow-11-latek-przyszedl-do-szkoly-z-nozem-mial-straszyc.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-01T15:36:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/b0/0d/1d/z30464688M,Szkolna-szatnia---zdjecie-ilustracyjne.jpg" vspace="2" />Sąd rodzinny w Łukowie zajmie się 11-latkiem, ktĂłry przyszedł do szkoły z nożem. Chłopiec miał straszyć nim kolegĂłw.

## Andrzej Duda odmĂłwił wspĂłlnego zdjęcia na szczycie w Dubaju. Ministerka tłumaczy
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30464224,bojkot-andrzeja-dudy-w-dubaju-nie-ustawil-sie-do-wspolnego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30464224,bojkot-andrzeja-dudy-w-dubaju-nie-ustawil-sie-do-wspolnego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-01T15:11:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/b2/0d/1d/z30464434M,Bojkot-Andrzeja-Dudy-w-Dubaju--Nie-ustawil-sie-do-.jpg" vspace="2" />Prezydent Polski zbojkotował jeden z punktĂłw trwającego w Dubaju szczytu klimatycznego COP28. Andrzej Duda nie zapozował do wspĂłlnego zdjęcia przywĂłdcĂłw światowych z powodu obecności jednego z sąsiadĂłw Polski. Nie był jedynym prezydentem, ktĂłry zdecydował się na taki krok.

## Otrucie żony szefa ukraińskiego wywiadu wojskowego. Jusow: Latem było 10 prĂłb zamachu na Budanowa
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30463839,zona-szefa-ukrainskiego-wywiadu-zostala-otruta-rosja-ma-wysylac.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30463839,zona-szefa-ukrainskiego-wywiadu-zostala-otruta-rosja-ma-wysylac.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-01T14:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d9/0d/1d/z30464217M,Kyrylo-Budanow.jpg" vspace="2" />Żona szefa wywiadu wojskowego Ukrainy (HUR) Marianna Budanowa została otruta, potwierdził rzecznik HUR Andriej Jusow. Incydent wywołał podejrzenia, że Rosja wzmaga wysiłki, aby uderzyć w najwyższe kierownictwo Ukrainy. "Sugerowałoby to, że jej agenci działali bliżej wewnętrznych kręgĂłw władzy w Kijowie, niż wcześniej sądzono" - napisał "The New York Times".

## Śmierć 14-latki w Andrychowie. Bliscy: Policjanci kazali czekać ojcu. "Ludzie, co wy robicie?"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30463527,smierc-14-letniej-dziewczynki-w-andrychowie-bliscy-policjanci.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30463527,smierc-14-letniej-dziewczynki-w-andrychowie-bliscy-policjanci.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-01T14:27:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f7/0d/1d/z30463735M,Komisariat-policji-w-Andrychowie.jpg" vspace="2" />Pani Anna, bliska znajoma rodziny 14-letniej Natalii przekazała, że jej ojciec już po godzinie 9:36 zadzwonił na komisariat i informował o zaginięciu cĂłrki. - Przed godziną 10 był na komisariacie. (...) Udzielił wstępnych informacji, że prosi o lokalizację telefonu. Przekazał, że prĂłbował sam szukać, że dzwonił do szkoły i do szpitala. Kazali mu czekać, aż zejdzie inny funkcjonariusz - mĂłwiła pani Anna. Jak powiedziała, o 12:36 ojciec 14-latki stwierdził, że wychodzi z komisariatu.

## Andrzej Duda zapytany o ustawę w sprawie in vitro. "Oczywiście to rozważę"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30463867,andrzej-duda-zapytany-o-ustawe-w-sprawie-in-vitro-oczywiscie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30463867,andrzej-duda-zapytany-o-ustawe-w-sprawie-in-vitro-oczywiscie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-01T14:12:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/98/0d/1d/z30463896M,Andrzej-Duda.jpg" vspace="2" />- Posłowie, jako przedstawiciele wybrani przez społeczeństwo, mają prawo decydować w sprawach ważnych. Ja oczywiście to rozważę - mĂłwił Andrzej Duda o decyzji Sejmu ws. projektu o finansowaniu in vitro z budżetu państwa.

## Andrzej Duda zapewnia, że "nie będzie opĂłźniał zaprzysiężenia rządu Donalda Tuska"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30463956,andrzej-duda-zapewnia-ze-nie-bedzie-opoznial-zaprzysiezenia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30463956,andrzej-duda-zapewnia-ze-nie-bedzie-opoznial-zaprzysiezenia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-01T13:34:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/aa/0a/1b/z28353450M,Prezydent-Andrzej-Duda--zdjecie-ilustracyjne-.jpg" vspace="2" />Andrzej Duda został zapytany w piątek o to, kiedy spodziewa się zaprzysiężenia rządu Donalda Tuska. - Nie będę przeciągał i nie będę tego opĂłźniał - zapewnił prezydent.

## Nauczyciel skazany za molestowanie seksualne uczennic bywa na szkolnych imprezach? "Ktoś się pomylił"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30462514,nauczyciel-skazany-za-molestowanie-seksualne-uczennic-bywa-na.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30462514,nauczyciel-skazany-za-molestowanie-seksualne-uczennic-bywa-na.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-01T13:31:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/68/0d/1d/z30463336M,Zapadl-wyrok-w-sprawie-nauczyciela-z-Zambrowa--woj.jpg" vspace="2" />56-letni anglista z Zambrowa został skazany za molestowanie seksualne uczennic podczas udzielania im korepetycji. Białostocką "Wyborczą" zaalarmował czytelnik: że nauczyciel bywa w szkole nauczyciel i że mĂłgł kontynuować karierę pomimo poważnych oskarżeń. Dyrektor szkoły zaprzecza temu. Twierdzi za to, że anglista ma bardzo podobnego do siebie brata, ktĂłry bywa w szkole: - Może ktoś się pomylił.

## Nowe fakty o ochroniarzach Kaczyńskiego. Media: Chwalą się, że są "nie do tknięcia"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30462975,nowe-fakty-o-ochroniarzach-kaczynskiego-media-chwala-sie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30462975,nowe-fakty-o-ochroniarzach-kaczynskiego-media-chwala-sie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-01T12:48:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d2/35/16/z23288530M,Prezes-PiS-Jaroslaw-Kaczynski-z-ochrona-w-Sejmie.jpg" vspace="2" />Nie milkną echa doniesień na temat ochrony Jarosława Kaczyńskiego. Pracownicy firmy GROM Group mieli chwalić się, że są "nie do tknięcia", bo "są przy Kaczyńskim". W ocenie informatorĂłw są oni uważani w PiS za najsilniejszą grupę nacisku na prezesa.

## "WSJ": Władze USA i Izraela rozważają wydalenie bojownikĂłw Hamasu do Rosji
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30463182,wsj-wladze-usa-i-izraela-rozwazaja-wydalenie-bojownikow-hamasu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30463182,wsj-wladze-usa-i-izraela-rozwazaja-wydalenie-bojownikow-hamasu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-01T12:45:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/62/0d/1d/z30463330M,Prezydent-USA-Joe-Biden.jpg" vspace="2" />Przedstawiciele władz Izraela i USA rozważają wydalenie ze Strefy Gazy niżej usytuowanych bojownikĂłw Hamasu - przekazał na podstawie rozmĂłw z "wysokimi urzędnikami izraelskimi i amerykańskimi" amerykański dziennik "The Wall Street Journal".

## Śmierć 14-latki w Andrychowie. Ekspertka: W tłumie czujemy się bezkarni. "Teraz wszędzie są kamery"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30462948,smierc-14-latki-w-andrychowie-ekspertka-w-tlumie-czujemy-sie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30462948,smierc-14-latki-w-andrychowie-ekspertka-w-tlumie-czujemy-sie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-01T12:35:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/fe/0d/1d/z30462974M.jpg" vspace="2" />- Jak ktoś ma tendencję do gotowości do zareagowania, to zareaguje. Ale jeżeli ktoś takiej gotowości nie ma, to nie zareaguje. Zawsze znajdzie jakiś powĂłd, dlaczego nic nie zrobił. (...) Lepiej zapytać kogoś o pomoc i usłyszeć odmowę lub nawet niemiłą odpowiedź, niż dopuszczać do tego typu sytuacji - mĂłwi w rozmowie z Gazeta.pl dr Ewa Tokarczyk z Instytutu Psychologii i Psychiatrii Sądowej.

## Donald Tusk komentuje "awanturę wiatrakową". "Jesteśmy tu po to, żeby lękĂłw już nie było"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30463341,donald-tusk-uspokaja-w-sprawie-awantury-o-wiatraki-jestesmy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30463341,donald-tusk-uspokaja-w-sprawie-awantury-o-wiatraki-jestesmy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-01T12:28:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c0/0d/1d/z30463424M,Donald-Tusk-podczas-konferencji-prasowej--1-grudni.jpg" vspace="2" />Donald Tusk odniĂłsł się do tzw. afery wiatrakowej. - Jesteśmy tutaj po to, żeby lękĂłw o niesprawiedliwe działanie władzy już nie było - zapewniał kandydat koalicyjnej większości na premiera. Tego samego dnia PiS poinformowało, że zgłosiło sprawę projektu ustawy koalicji demokratycznej do CBA.

## Śmierć 14-letniej Natalii. Są wstępne wyniki sekcji zwłok
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30463540,smierc-14-letniej-natalii-sa-wstepne-wyniki-sekcji-zwlok.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30463540,smierc-14-letniej-natalii-sa-wstepne-wyniki-sekcji-zwlok.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-01T12:19:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ce/0d/1d/z30462414M,Andrychow--Miejsce-odnalezienia-14-letniej-Natalii.jpg" vspace="2" />Przyczyną śmierci 14-letniej Natalii był masywny krwotok, ktĂłry doprowadził do obrzęku mĂłzgu. Dziewczynkę znaleziono nieprzytomną w Andrychowie po tym, jak przez kilka godzin leżała przy pobliskim sklepie.

## Skandal w żłobku. Dzieci znanych piłkarzy miały być prześladowane przez wychowawcĂłw
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30462682,skandal-w-zlobku-dzieci-znanych-pilkarzy-mialy-byc-przesladowane.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30462682,skandal-w-zlobku-dzieci-znanych-pilkarzy-mialy-byc-przesladowane.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-01T11:41:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/9b/0d/1d/z30463131M,Buty-dzieciece---zdj--ilustr-.jpg" vspace="2" />Dwaj pracownicy żłobka w Madrycie zostali aresztowani pod zarzutem znęcania się nad dziećmi. Oskarżeni mieli w zły sposĂłb traktować podopiecznych z powodu statusu materialnego ich rodzicĂłw. Jak donoszą lokalne media, do prywatnej placĂłwki uczęszczają dzieci znanych piłkarzy.

## Jest data zaprzysiężenia i exposĂŠ nowego premiera. Hołownia po spotkaniu z Tuskiem: Tworzymy historię
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30463109,jest-data-expose-nowego-premiera-i-zaprzysiezenia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30463109,jest-data-expose-nowego-premiera-i-zaprzysiezenia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-01T10:54:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/b0/e7/1c/z30310064M,Donald-Tusk-i-Szymon-Holownia.jpg" vspace="2" />- 11 grudnia będziemy wysłuchiwali expose Mateusza Morawieckiego, jeśli czas pozwoli także 11 grudnia dokonamy wyboru nowego premiera - przekazał Donald Tusk. Jeśli okaże się, że czasowo nie uda się tego zorganizować to szef nowego rządu zostanie wybrany dzień pĂłźniej.

## Trwa ważne spotkanie. O czym rozmawia Szymon Hołownia z Donaldem Tuskiem?
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30462922,trwa-wazne-spotkanie-o-czym-rozmawia-szymon-holownia-z-donaldem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30462922,trwa-wazne-spotkanie-o-czym-rozmawia-szymon-holownia-z-donaldem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-01T10:25:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/79/35/1c/z29578105M,WAZNE.jpg" vspace="2" />Trwa spotkanie marszałka Sejmu Szymona Hołowni z przewodniczącym Platformy Obywatelskiej Donaldem Tuskiem. Tematem rozmĂłw ma być utworzenie nowego rządu.

## ZwrĂłcił się do Kaczyńskiego "prezesie". "ObrĂłcił się, paluszkiem przed twarz"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30462533,zwrocil-sie-do-kaczynskiego-prezesie-obrocil-sie-paluszkiem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30462533,zwrocil-sie-do-kaczynskiego-prezesie-obrocil-sie-paluszkiem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-01T09:56:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/8c/0a/1d/z30453132M,Jaroslaw-Kaczynski.jpg" vspace="2" />Jarosław Kaczyński miał zdecydowanie zareagować, gdy poseł Koalicji Obywatelskiej Witold Zembaczyński pozdrowił go słowami: "dobry wieczĂłr prezesie". - Panie prezesie, chłopcze - miał poprawić go Kaczyński, jak relacjonuje poseł.

## Są zarzuty dla nożownika z Kadzidła. "Usiłowanie zabĂłjstwa wielu osĂłb"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30462792,sa-zarzuty-dla-nozownika-z-kadzidla-usilowanie-zabojstwa-wielu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30462792,sa-zarzuty-dla-nozownika-z-kadzidla-usilowanie-zabojstwa-wielu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-01T09:55:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/16/0c/1d/z30458134M,Mazowsze--Zatrzymano-nozownika--ktory-zaatakowal-w.jpg" vspace="2" />18-letni Albert G., ktĂłry wtargnął na lekcję i zaatakował nożem dwoje uczniĂłw, usłyszał zarzut. Jak dowiedział się Polsat News, 18-latek odpowie za usiłowanie zabĂłjstwa wielu osĂłb. Grozi za to minimalna kara 15 lat pozbawienia wolności.

## Robi karierę "na skalę światową". Prokurator, ktĂłry odmĂłwił ścigania Zbigniewa Ziobry, znĂłw awansował
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30462283,robi-kariere-na-skale-swiatowa-prokurator-ktory-odmowil.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30462283,robi-kariere-na-skale-swiatowa-prokurator-ktory-odmowil.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-01T09:27:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/89/0d/1d/z30462345M,Zbigniew-Ziobro.jpg" vspace="2" />Szef Prokuratury Okręgowej w Lublinie Robert Malicki otrzymał awans na prokuratora regionalnego. Ten były radca prawny zyskał w oczach Zbigniewa Ziobry, gdy w 2019 roku odmĂłwił ukarania go za rzekomo nielegalne poprowadzenie agitacji wyborczej. - Ten człowiek w kilka lat przeszedł niemal wszelkie szczeble kariery - zauważają oburzone "środowiska prokuratorskie".

## PiS składa wniosek do CBA. PowĂłd? "Afera wiatrakowa", czyli projekt ustawy koalicji ws. cen energii
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30462653,pis-sklada-wniosek-do-cba-powodem-afera-wiatrakowa-wokol.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30462653,pis-sklada-wniosek-do-cba-powodem-afera-wiatrakowa-wokol.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-01T09:20:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/91/0d/1d/z30462865M,Konferencja-prasowa-PiS--1-grudnia-2023-r--.jpg" vspace="2" />- Składamy wniosek do prokuratury regionalnej i Centralnego Biura Antykorupcyjnego, żeby te służby sprawdziły, kto stoi za projektem ustawy ws. cen energii - przekazał poseł PiS, minister edukacji Krzysztof Szczucki.

## Śmierć 14-latki z Andrychowa. Kto, kogo i o ktĂłrej powiadomił, że zasłabła? Co dotąd wiadomo?
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30462231,smierc-14-latki-z-andrychowa-kto-kogo-powiadomil-i-o-ktorej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30462231,smierc-14-latki-z-andrychowa-kto-kogo-powiadomil-i-o-ktorej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-01T09:05:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/cc/0d/1d/z30462412M,Andrychow--Miejsce-odnalezienia-14-letniej-Natalii.jpg" vspace="2" />14-letnia Natalia z Andrychowa (woj. małopolskie) zasłabła w centrum miasta po godzinie 8 rano. Dziewczyna została odnaleziona dopiero po ponad pięciu godzinach. Zmarła z wyziębienia. Kontrowersje budzi zachowanie policji. Rzecznicy podają inną sekwencję zdarzeń niż bliscy nastolatki, ktĂłrzy prowadzili poszukiwania na własną rękę.

## Rozkopana przez Wody Polskie, "renaturyzowana" przez bobry. Wielki przykład rzeki Małej
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,174372,30460142,rozkopana-przez-wody-polskie-renaturyzowana-przez-bobry.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,174372,30460142,rozkopana-przez-wody-polskie-renaturyzowana-przez-bobry.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-01T09:04:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/3b/0c/1d/z30461243M,Rozlewisko-rzeki-Malej-w-czasie-zimy.jpg" vspace="2" />Nie tylko opieka, ale "odbudowywanie" przyrody - to cel przełomowego prawa, nad ktĂłrym pracuje Unia Europejska. W Polsce nowa koalicja rządząca obiecuje "renaturyzację" rzek. Co w praktyce kryje się za takimi hasłami? Dobrze widać to wokĂłł rzeki Małej, ktĂłra daje wielki przykład działań dla przyrody.

## Śmierć 14-letniej Natalii w Andrychowie. Wszczęto wewnętrzną kontrolę w policji
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30462590,smierc-14-letniej-natalii-w-andrychowie-wszczeto-wewnetrzna.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30462590,smierc-14-letniej-natalii-w-andrychowie-wszczeto-wewnetrzna.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-01T08:57:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/57/82/1b/z28845911M,Pilne.jpg" vspace="2" />Po śmierci 14-letniej Natalii w Andrychowie policja wszczęła wewnętrzną, rutynową kontrolę dotyczącą działań podjętych przez funkcjonariuszy - przekazała PAP w piątek rzecznik Komendy WojewĂłdzkiej Policji w Krakowie podinsp. Katarzyna Cisło.

## Holecka odchodzi z "Wiadomości" TVP. Internauci mają pomysł, jak ją pożegnać. "Bądźmy z nią w trakcie"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30462321,holecka-odchodzi-z-wiadomosci-tvp-internauci-maja-pomysl.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30462321,holecka-odchodzi-z-wiadomosci-tvp-internauci-maja-pomysl.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-01T08:53:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/7e/0d/1d/z30462334M,Danuta-Holecka.jpg" vspace="2" />W czwartek 30 listopada media obiegła informacja o odejściu Danuty Holeckiej z "Wiadomości" TVP. Ustalenia takie przekazał także dziennikarz Gazeta.pl Jacek Gądek. Internauci postanowili z tej okazji przygotować specjalne wydarzenie.

## Mieszkańcy Andrychowa o śmierci 14-latki przed sklepem. "W ogĂłle nie zwrĂłciłam na nią uwagi"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30462267,mieszkancy-andrychowa-o-smierci-14-latki-przed-sklepem-w-ogole.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30462267,mieszkancy-andrychowa-o-smierci-14-latki-przed-sklepem-w-ogole.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-01T08:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/fd/0c/1d/z30460925M,Andrychow--Znicze-w-miejscu-odnalezienia-14-latki.jpg" vspace="2" />- Ja sama tędy przechodziłam. Wczoraj i przedwczoraj. I jak Boga kocham, dziecka leżącego tutaj nie widziałam - mĂłwi w rozmowie z "Gazetą Wyborczą" jedna z mieszkanek Andrychowa. W supermarkecie ekspedientki podkreślają, że zrobiły wszystko, co mogły. - Nie mamy sobie nic do zarzucenia. Mamy w sklepie mnĂłstwo pracy, nie wychodzimy co chwila na zewnątrz - mĂłwią.

## To on zmiął zdjęcie Tuska z Putinem. Poseł KO zaczynał od "Idola"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30462185,to-on-zmial-zdjecie-tuska-z-putinem-posel-ko-zaczynal-od-idola.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30462185,to-on-zmial-zdjecie-tuska-z-putinem-posel-ko-zaczynal-od-idola.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-01T08:06:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/41/0c/1d/z30457921M,Sejm--Dariusz-Matecki-krazyl-po-sali-ze-zdjeciem--.jpg" vspace="2" />Pokazanie przez Jacka Ozdobę zdjęcia z Donaldem Tuskiem i Władimirem Putinem wywołało awanturę w Sejmie. Sytuacja doprowadziła niemal do bĂłjki między posłem KO - Jakubem Rutnickim a Jackiem Ozdobą z Suwerennej Polski. Poseł KO to barwna postać, ktĂłrą wyborcy kojarzą nie tylko z ław sejmowych, lecz także z popularnego niegdyś programu Idol.

## Do Polski nadciąga silny mrĂłz. Nowe alerty IMGW. Nawet 50 cm śniegu w ciągu 24 godzin
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30462184,do-polski-nadciaga-silny-mroz-nowe-alerty-imgw-nawet-50-cm.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30462184,do-polski-nadciaga-silny-mroz-nowe-alerty-imgw-nawet-50-cm.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-01T07:54:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ef/0d/1d/z30462191M,Intensywne-opady-sniegu---zdj--ilustr-.jpg" vspace="2" />Zima do Polski dotarła wraz z niżem Robin. IMGW wydał ostrzeżenia pierwszego i drugiego stopnia przed intensywnymi opadami śniegu. W najbliższych dniach temperatura w niektĂłrych regionach może spaść do nawet -25 st. C.

## Nowe informacje ws. śmierci 14-latki w Andrychowie. Mamy komentarz sklepu. "Personel obłożył ją kocami"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30462220,nowe-informacje-ws-smierci-14-latki-w-andrychowie-mamy-komentarz.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30462220,nowe-informacje-ws-smierci-14-latki-w-andrychowie-mamy-komentarz.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-01T07:52:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/15/0d/1d/z30462229M,Miejsce-odnalezienia-14-latki-w-Andrychowie.jpg" vspace="2" />"Nasz personel obłożył ją kocami, kurtkami i asystował przy reanimacji" - przekazało nam biuro prasowe sklepu Aldi, nieopodal ktĂłrego znaleziono wyziębniętą 14-latkę. Jak dodano, na miejscu zdarzenia, wśrĂłd klientĂłw sieci dyskontĂłw, znalazła się także pielęgniarka, ktĂłra udzieliła niezwłocznie pomocy.

## Morawiecki twierdzi, że "zawsze optował za in vitro". Hołownia zakpił ze słĂłw premiera
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30462194,morawiecki-twierdzi-ze-zawsze-optowal-za-in-vitro-holownia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30462194,morawiecki-twierdzi-ze-zawsze-optowal-za-in-vitro-holownia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-01T07:29:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f5/0d/1d/z30462197M,Szymon-Holownia.jpg" vspace="2" />Mateusz Morawiecki twierdził, że "zawsze optował" za metodą in vitro. Dzień pĂłźniej do wypowiedzi premiera odniĂłsł się Szymon Hołownia. - Trudno jest mi w jakiś sposĂłb komentować te spektakularne nawrĂłcenia - mĂłwił między innymi marszałek Sejmu.

## Śmierć Natalii w Andrychowie. Sprzeczne doniesienia świadkĂłw i policji. Nieoficjalnie: Trwa kontrola
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30462155,smierc-natalii-w-andrychowie-sprzeczne-doniesienia-swiadkow.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30462155,smierc-natalii-w-andrychowie-sprzeczne-doniesienia-swiadkow.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-01T06:04:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/77/0c/1d/z30461303M,Andrychow--Miejsce--gdzie-14-letnia-Natalia-zostal.jpg" vspace="2" />W sprawie śmierci 14-letniej Natalii z Andrychowa śledztwo prowadzi prokuratura, a działania policji sprawdzają kontrolerzy. Jak wynika z nioficjalnych informacji TVN24, weryfikują to, w jaki sposĂłb funkcjonariusze działali od momentu przyjęcia zawiadomienia o zaginięciu dziewczynki.

## W Izraelu zawyły syreny. IDF: Przechwyciliśmy rakietę ze strefy Gazy. Hamas naruszył rozejm
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30462164,w-izraelu-zawyly-syreny-idf-przechwycilismy-rakiete-ze-strefy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30462164,w-izraelu-zawyly-syreny-idf-przechwycilismy-rakiete-ze-strefy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-01T05:34:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/de/0d/1d/z30462174M,Rakiety-wystrzelane-ze-Strefy-Gazy--zdjecie-ilustr.jpg" vspace="2" />Mimo trwającego zawieszenia działań bojowych w Strefie Gazy słychać było rano strzelaninę - podaje agencja Shehab, powiązana z Hamasem. Według danych, niepotwierdzonych dotąd przez inne źrĂłdła, z pĂłłnocnej części Strefy dochodziły odgłosy walk. Tymczasem armia izraelska donosi o zestrzeleniu rakiety, odpalonej ze Strefy Gazy.

## Horoskop dzienny - piątek 1 grudnia 2023 [Baran, Byk, Bliźnięta, Rak, Lew, Panna, Waga, Skorpion, Strzelec, Koziorożec, Wodnik, Ryby]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,168571,30459994,horoskop-dzienny-piatek-1-grudnia-2023-baran-byk-bliznieta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,168571,30459994,horoskop-dzienny-piatek-1-grudnia-2023-baran-byk-bliznieta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-01T04:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/2c/d0/1c/z30214700M,Horoskop-na-piatek.jpg" vspace="2" />Horoskop dzienny na piątek 1 grudnia dla wszystkich znakĂłw zodiaku. Los będzie sprzyjał żądnym przygĂłd Rakom. W Lwach na nowo zacznie tlić się uczucie, ktĂłre na chwile przygasło. Znajdź swĂłj znak zodiaku i zobacz, co przygotowały dla ciebie gwiazdy.

## Skrępowali i wyrzucili 29-latka z balkonu we Włodawie. W ten sposĂłb mieli "wyjaśniać zaległe sprawy"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30461278,skrepowali-i-wyrzucili-29-latka-z-balkonu-we-wlodawie-w-ten.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30461278,skrepowali-i-wyrzucili-29-latka-z-balkonu-we-wlodawie-w-ten.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-01T04:20:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/71/0c/1d/z30461297M,Mezczyzni-wyrzucili-znajomego-przez-balkon-we-Wlod.jpg" vspace="2" />DwĂłch mężczyzn skrępowało 29-latka i wyrzuciło go przez balkon jednego z blokĂłw we Włodawie. Mieli w ten sposĂłb "wyjaśniać zaległe sprawy". Sąd zdecydował o tymczasowym zatrzymaniu mężczyzn.

## Ławrow zaskoczony podczas szczytu OBWE. Dyplomaci opuścili salę, gdy tylko się odezwał [WIDEO]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30460949,lawrow-zaskoczony-podczas-szczytu-obwe-dyplomaci-opuscili-sale.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30460949,lawrow-zaskoczony-podczas-szczytu-obwe-dyplomaci-opuscili-sale.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-01T04:10:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/2f/0c/1d/z30461231M,Siergiej-Lawrow--rosyjski-szef-dyplomacji.jpg" vspace="2" />Podczas obrad szczytu OBWE w Skopje część dyplomatĂłw opuściła salę po tym, jak swoje przemĂłwienie rozpoczął Siergiej Ławrow. Kilka państw członkowskich, w tym Polska i Ukraina zbojkotowały wydarzenie, a ich przedstawiciele nie pojawili się na obradach.

## Jaka pogoda będzie w święta? Synoptycy już podali pierwsze prognozy. Pojawi się "lekko zimowy trend"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30461550,jaka-pogoda-bedzie-w-swieta-synoptycy-juz-podali-pierwsze-prognozy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30461550,jaka-pogoda-bedzie-w-swieta-synoptycy-juz-podali-pierwsze-prognozy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-01T04:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d3/0c/1d/z30461651M,Zima-nie-opuszcza-Polski.jpg" vspace="2" />W tym roku zima zawitała do Polski znacznie wcześniej. W ostatnich dniach listopada w całym kraju pojawił się śnieg oraz mrĂłź. Czy taka pogoda zostanie z nami aż do świąt? Zapowiedzi synoptykĂłw są jednoznaczne.

