# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Young Fathers - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=_yHfko6Kz6k](https://www.youtube.com/watch?v=_yHfko6Kz6k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-12-01T16:00:33+00:00

http://KEXP.ORG presents Young Fathers performing live in the KEXP studio. Recorded September 27, 2023

Songs:
I Saw
Drum
Geronimo
Rice

Alloysious Massaquoi - Vocals
Afolabi Oluka-yode Bankole - Vocals
Graham Hastings - Vocals, Synth
Steven Morrison - Drums
Callum Easter - Guitar, Organ
Amber Joy Greenidge-Sabral - Backing Vocals
Kimberley Mandindo - Backing Vocals

Host: Cheryl Waters
Audio Engineers: Kevin Suggs, Julian Martlew
Guest Audio Engineer: Graeme Stee
Audio Mixer: Graeme Stee
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Scott Holpainen, Ettie Wahl
Editor: Scott Holpainen

https://www.young-fathers.com
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Young Fathers - Geronimo (Live on KEXP)
 - [https://www.youtube.com/watch?v=rhBZqUq_Sco](https://www.youtube.com/watch?v=rhBZqUq_Sco)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-12-01T12:00:56+00:00

http://KEXP.ORG presents Young Fathers performing “Geronimo” live in the KEXP studio. Recorded September 27, 2023

Alloysious Massaquoi - Vocals
Afolabi Oluka-yode Bankole - Vocals
Graham Hastings - Vocals, Synth
Steven Morrison - Drums
Callum Easter - Guitar, Organ
Amber Joy Greenidge-Sabral - Backing Vocals
Kimberley Mandindo - Backing Vocals

Host: Cheryl Waters
Audio Engineers: Kevin Suggs, Julian Martlew
Guest Audio Engineer: Graeme Stee
Audio Mixer: Graeme Stee
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Scott Holpainen, Ettie Wahl
Editor: Scott Holpainen

https://www.young-fathers.com
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Young Fathers - Rice (Live on KEXP)
 - [https://www.youtube.com/watch?v=nPZ4wQbqfAc](https://www.youtube.com/watch?v=nPZ4wQbqfAc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-12-01T12:00:51+00:00

http://KEXP.ORG presents Young Fathers performing “Rice” live in the KEXP studio. Recorded September 27, 2023

Alloysious Massaquoi - Vocals
Afolabi Oluka-yode Bankole - Vocals
Graham Hastings - Vocals, Synth
Steven Morrison - Drums
Callum Easter - Guitar, Organ
Amber Joy Greenidge-Sabral - Backing Vocals
Kimberley Mandindo - Backing Vocals

Host: Cheryl Waters
Audio Engineers: Kevin Suggs, Julian Martlew
Guest Audio Engineer: Graeme Stee
Audio Mixer: Graeme Stee
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Scott Holpainen, Ettie Wahl
Editor: Scott Holpainen

https://www.young-fathers.com
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Young Fathers - I Saw (Live on KEXP)
 - [https://www.youtube.com/watch?v=gQbouSzXkuU](https://www.youtube.com/watch?v=gQbouSzXkuU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-12-01T12:00:43+00:00

http://KEXP.ORG presents Young Fathers performing “I Saw” live in the KEXP studio. Recorded September 27, 2023

Alloysious Massaquoi - Vocals
Afolabi Oluka-yode Bankole - Vocals
Graham Hastings - Vocals, Synth
Steven Morrison - Drums
Callum Easter - Guitar, Organ
Amber Joy Greenidge-Sabral - Backing Vocals
Kimberley Mandindo - Backing Vocals

Host: Cheryl Waters
Audio Engineers: Kevin Suggs, Julian Martlew
Guest Audio Engineer: Graeme Stee
Audio Mixer: Graeme Stee
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Scott Holpainen, Ettie Wahl
Editor: Scott Holpainen

https://www.young-fathers.com
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Young Fathers - Drum (Live on KEXP)
 - [https://www.youtube.com/watch?v=Ij7nc87fxlU](https://www.youtube.com/watch?v=Ij7nc87fxlU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-12-01T12:00:19+00:00

http://KEXP.ORG presents Young Fathers performing “Drum” live in the KEXP studio. Recorded September 27, 2023

Alloysious Massaquoi - Vocals
Afolabi Oluka-yode Bankole - Vocals
Graham Hastings - Vocals, Synth
Steven Morrison - Drums
Callum Easter - Guitar, Organ
Amber Joy Greenidge-Sabral - Backing Vocals
Kimberley Mandindo - Backing Vocals

Host: Cheryl Waters
Audio Engineers: Kevin Suggs, Julian Martlew
Guest Audio Engineer: Graeme Stee
Audio Mixer: Graeme Stee
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Scott Holpainen, Ettie Wahl
Editor: Scott Holpainen

https://www.young-fathers.com
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

