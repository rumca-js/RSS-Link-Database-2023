## Hamas was created by Israeli and US intelligence services to counteract Yasser Arafat, Ron Paul explains   – NaturalNews.com
 - [https://www.naturalnews.com/2023-10-12-hamas-created-israel-yasser-arafat-ron-paul.html](https://www.naturalnews.com/2023-10-12-hamas-created-israel-yasser-arafat-ron-paul.html)
 - RSS feed: https://www.naturalnews.com
 - date published: 2023-12-01T08:29:25+00:00

Hamas was created by Israeli and US intelligence services to counteract Yasser Arafat, Ron Paul explains   – NaturalNews.com

