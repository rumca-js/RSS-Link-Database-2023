# Source:RMF24.pl, URL:https://www.rmf24.pl/feed, language:pl

## Błaszczak: Polska zawarła umowę na zakup pond 150 koreańskich haubic
 - [https://www.rmf24.pl/polityka/news-blaszczak-polska-zawarla-umowe-na-zakup-pond-150-koreanskich,nId,7184205](https://www.rmf24.pl/polityka/news-blaszczak-polska-zawarla-umowe-na-zakup-pond-150-koreanskich,nId,7184205)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T21:45:57+00:00

<p><a href="https://www.rmf24.pl/polityka/news-blaszczak-polska-zawarla-umowe-na-zakup-pond-150-koreanskich,nId,7184205"><img align="left" alt="Błaszczak: Polska zawarła umowę na zakup pond 150 koreańskich haubic" src="https://interia-s.pluscdn.pl/blaszczak-polska-zawarla-umowe-na-zakup-pond-150-koreanskich/000I4VBGY6W4TSKD-C307.jpg" /></a>Wyciągamy wnioski z wojny na Ukrainie, modernizujemy wojska rakietowe i artylerię; w piątek zawarto kolejną umowę wykonawczą na pozyskanie 6 haubic samobieżnych K9A1 oraz 146 w wersji K9PL wraz z pakietem szkoleniowym, logistycznym i zapasem amunicji - przekazał szef MON Mariusz Błaszczak.</p><br clear="all" />

## Biały Dom: Pomoc USA dla Ukrainy coraz bardziej zagrożona
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-bialy-dom-pomoc-usa-dla-ukrainy-coraz-bardziej-zagrozona,nId,7184193](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-bialy-dom-pomoc-usa-dla-ukrainy-coraz-bardziej-zagrozona,nId,7184193)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T20:35:46+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-bialy-dom-pomoc-usa-dla-ukrainy-coraz-bardziej-zagrozona,nId,7184193"><img align="left" alt="Biały Dom: Pomoc USA dla Ukrainy coraz bardziej zagrożona" src="https://interia-s.pluscdn.pl/bialy-dom-pomoc-usa-dla-ukrainy-coraz-bardziej-zagrozona/000I4V31WJ2O7X4S-C307.jpg" /></a>Rzecznik Rady Bezpieczeństwa Narodowego USA John Kirby oznajmił, że wsparcie Stanów Zjednoczonych dla Ukrainy będzie niezmiernei trudne. Wszystko przez to, że amerykański Kongres nie podejmuje decyzji, które pozwoliłyby administracji prezydenta Joe Bidena na kontynuowanie pomocy finansowej i wojskowej dla Kijowa.</p><br clear="all" />

## Majątki posłów: Kaczyński z kredytem, Czarzasty z jachtem, Mentzem z bitcoinami
 - [https://www.rmf24.pl/polityka/news-majatki-poslow-kaczynski-z-kredytem-czarzasty-z-jachtem-ment,nId,7184156](https://www.rmf24.pl/polityka/news-majatki-poslow-kaczynski-z-kredytem-czarzasty-z-jachtem-ment,nId,7184156)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T20:32:00+00:00

<p><a href="https://www.rmf24.pl/polityka/news-majatki-poslow-kaczynski-z-kredytem-czarzasty-z-jachtem-ment,nId,7184156"><img align="left" alt="Majątki posłów: Kaczyński z kredytem, Czarzasty z jachtem, Mentzem z bitcoinami " src="https://interia-s.pluscdn.pl/majatki-poslow-kaczynski-z-kredytem-czarzasty-z-jachtem-ment/000I4V3FXAL4RH8N-C307.jpg" /></a>Na stronie internetowej Sejmu pojawiły się oświadczenia majątkowe posłów X kadencji. Szef Platformy Obywatelskiej i kandydat sejmowej większości na premiera Donald Tusk posiada ponad milion złotych oszczędności. Prezes Prawa i Sprawiedliwości Jarosław Kaczyński ma kredyt. Marszałek Sejmu i lider Polski 2050 Szymon Hołownia uwagę przykuwa liczbą nieruchomości. Jeden z liderów Lewicy i wicemarszałek Sejmu Włodzimierz Czarzasty jest właścicielem jachtu motorowego, a jeden z czołowych polityków Konfederacji Sławomir Mentzen ma bitcoiny warte...</p><br clear="all" />

## Putin powiększa armię. Już drugi raz od agresji na Ukrainę
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-putin-powieksza-armie-juz-drugi-raz-od-agresji-na-ukraine,nId,7184181](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-putin-powieksza-armie-juz-drugi-raz-od-agresji-na-ukraine,nId,7184181)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T19:52:08+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-putin-powieksza-armie-juz-drugi-raz-od-agresji-na-ukraine,nId,7184181"><img align="left" alt="Putin powiększa armię. Już drugi raz od agresji na Ukrainę" src="https://interia-s.pluscdn.pl/putin-powieksza-armie-juz-drugi-raz-od-agresji-na-ukraine/000I4UVNY71KR7NQ-C307.jpg" /></a>Po raz drugi od napaści na Ukrainę w lutym 2022 r. prezydent Rosji Władimir Putin zarządził powiększenie liczebności armii. Tym razem, oprócz posłużenia się argumentem o prowadzeniu &quot;specjalnej operacji wojskowej&quot;, Putin powołał się na zagrożenie &quot;kontynuacją rozszerzenia NATO&quot;.</p><br clear="all" />

## Donald Tusk ujawnił majątek. Oszczędności i imponująca emerytura z Komisji Europejskiej
 - [https://www.rmf24.pl/polityka/news-donald-tusk-ujawnil-majatek-oszczednosci-i-imponujaca-emeryt,nId,7184150](https://www.rmf24.pl/polityka/news-donald-tusk-ujawnil-majatek-oszczednosci-i-imponujaca-emeryt,nId,7184150)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T18:42:00+00:00

<p><a href="https://www.rmf24.pl/polityka/news-donald-tusk-ujawnil-majatek-oszczednosci-i-imponujaca-emeryt,nId,7184150"><img align="left" alt="Donald Tusk ujawnił majątek. Oszczędności i imponująca emerytura z Komisji Europejskiej" src="https://interia-s.pluscdn.pl/donald-tusk-ujawnil-majatek-oszczednosci-i-imponujaca-emeryt/000I4ULHRRIC4MS3-C307.jpg" /></a>Na stronie internetowej Sejmu pojawiły się oświadczenia majątkowe posłów X kadencji, a wśród nich lidera Koalicji Obywatelskiej i kandydata sejmowej większości na premiera Donalda Tuska. Polityk, w przeszłości przewodniczący Rady Europejskiej, zgromadził oszczędności zarówno w złotówkach, jak i euro.</p><br clear="all" />

## Napad na kantor w Tarnogrodzie. Policja szuka sprawcy
 - [https://www.rmf24.pl/regiony/lublin/news-napad-na-kantor-w-tarnogrodzie-policja-szuka-sprawcy,nId,7184127](https://www.rmf24.pl/regiony/lublin/news-napad-na-kantor-w-tarnogrodzie-policja-szuka-sprawcy,nId,7184127)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T17:41:00+00:00

<p><a href="https://www.rmf24.pl/regiony/lublin/news-napad-na-kantor-w-tarnogrodzie-policja-szuka-sprawcy,nId,7184127"><img align="left" alt="Napad na kantor w Tarnogrodzie. Policja szuka sprawcy " src="https://interia-s.pluscdn.pl/napad-na-kantor-w-tarnogrodzie-policja-szuka-sprawcy/000I4UH5OWJ0DT1P-C307.jpg" /></a>Napad na kantor w Tarnogrodzie na Lubelszczyźnie. Mężczyzna zastraszył pracownicę, ukradł gotówkę i uciekł. Policja szuka sprawcy. </p><br clear="all" />

## Skoki narciarskie: Piotr Żyła 17. w kwalifikacjach w Lillehammer
 - [https://www.rmf24.pl/raport-skoki-narciarskie-2023-2024/news-skoki-narciarskie-piotr-zyla-17-w-kwalifikacjach-w-lillehamm,nId,7184120](https://www.rmf24.pl/raport-skoki-narciarskie-2023-2024/news-skoki-narciarskie-piotr-zyla-17-w-kwalifikacjach-w-lillehamm,nId,7184120)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T17:30:00+00:00

<p><a href="https://www.rmf24.pl/raport-skoki-narciarskie-2023-2024/news-skoki-narciarskie-piotr-zyla-17-w-kwalifikacjach-w-lillehamm,nId,7184120"><img align="left" alt="Skoki narciarskie: Piotr Żyła 17. w kwalifikacjach w Lillehammer" src="https://interia-s.pluscdn.pl/skoki-narciarskie-piotr-zyla-17-w-kwalifikacjach-w-lillehamm/000I4UDHFCG7PXMD-C307.jpg" /></a>Piotr Żyła zajął 17. miejsce w kwalifikacjach do sobotniego konkursu Pucharu Świata w skokach narciarskich w norweskim Lillehammer. Wygrał Austriak Stefan Kraft.</p><br clear="all" />

## Zmiany traktatów UE: Są opóźnienia w procedurach
 - [https://www.rmf24.pl/fakty/swiat/news-zmiany-traktatow-ue-sa-opoznienia-w-procedurach,nId,7183971](https://www.rmf24.pl/fakty/swiat/news-zmiany-traktatow-ue-sa-opoznienia-w-procedurach,nId,7183971)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T17:27:00+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-zmiany-traktatow-ue-sa-opoznienia-w-procedurach,nId,7183971"><img align="left" alt="Zmiany traktatów UE: Są opóźnienia w procedurach " src="https://interia-s.pluscdn.pl/zmiany-traktatow-ue-sa-opoznienia-w-procedurach/000I4U1J0WMF9Y6X-C307.jpg" /></a>Opóźnia się procedura w sprawie zmian traktatowych Unii Europejskiej. Hiszpańska prezydencja w UE, wbrew wcześniejszym zapowiedziom, nie przedstawi wniosku PE w sprawie zmian traktatowych 12 grudnia na posiedzeniu ministrów ds. europejskich. Hiszpanie przyznają, że nie ma w tej sprawie zgody krajów członkowskich UE  – dowiedziała się dziennikarka RMF FM Katarzyna Szymańska-Borginon.</p><br clear="all" />

## Kadzidło. 18-letni nożownik trafi do aresztu
 - [https://www.rmf24.pl/regiony/warszawa/news-kadzidlo-18-letni-nozownik-trafi-do-aresztu,nId,7183968](https://www.rmf24.pl/regiony/warszawa/news-kadzidlo-18-letni-nozownik-trafi-do-aresztu,nId,7183968)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T17:03:00+00:00

<p><a href="https://www.rmf24.pl/regiony/warszawa/news-kadzidlo-18-letni-nozownik-trafi-do-aresztu,nId,7183968"><img align="left" alt="Kadzidło. 18-letni nożownik trafi do aresztu" src="https://interia-s.pluscdn.pl/kadzidlo-18-letni-nozownik-trafi-do-aresztu/000I4U3S0HGUX755-C307.jpg" /></a>18-letni uczeń, który w szkole w Kadzidle k. Ostrołęki (Mazowieckie) zaatakował nożem troje swoich kolegów, decyzją sądu trafi do aresztu. Albert K. ma postawione zarzuty usiłowania zabójstwa wielu osób, za co grozi mu co najmniej 15 lat pozbawienia wolności, a maksymalnie nawet kara dożywocia.</p><br clear="all" />

## Kwiatkowski: Abonament do likwidacji, media publiczne finansowane z budżetu
 - [https://www.rmf24.pl/tylko-w-rmf24/popoludniowa-rozmowa/news-kwiatkowski-abonament-do-likwidacji-media-publiczne-finansow,nId,7183880](https://www.rmf24.pl/tylko-w-rmf24/popoludniowa-rozmowa/news-kwiatkowski-abonament-do-likwidacji-media-publiczne-finansow,nId,7183880)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T16:45:12+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/popoludniowa-rozmowa/news-kwiatkowski-abonament-do-likwidacji-media-publiczne-finansow,nId,7183880"><img align="left" alt="Kwiatkowski: Abonament do likwidacji, media publiczne finansowane z budżetu" src="https://interia-s.pluscdn.pl/kwiatkowski-abonament-do-likwidacji-media-publiczne-finansow/000I4SRD27TI4338-C307.jpg" /></a>&quot;Abonament jest nie do uratowania&quot; – stwierdził gość Popołudniowej rozmowy w RMF FM Robert Kwiatkowski. Zdaniem byłego prezesa TVP, to budżet państwa będzie przejmował finansowanie mediów publicznych. &quot;Nie da się szybko naprawić mediów publicznych&quot; – zastrzegł Kwiatkowski. Według niego jedną z przyczyn „odejścia od modelu dobrej telewizji” jest zepsucie poziomu kultury politycznej, która „ześlizguje się w stronę agresywną”, przy obserwowanym „narastaniu atmosfery konfrontacji i wrogości”.</p><br clear="all" />

## Robert Kwiatkowski gościem Popołudniowej rozmowy w RMF FM
 - [https://www.rmf24.pl/tylko-w-rmf24/popoludniowa-rozmowa/news-robert-kwiatkowski-gosciem-popoludniowej-rozmowy-w-rmf-fm,nId,7183880](https://www.rmf24.pl/tylko-w-rmf24/popoludniowa-rozmowa/news-robert-kwiatkowski-gosciem-popoludniowej-rozmowy-w-rmf-fm,nId,7183880)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T16:45:12+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/popoludniowa-rozmowa/news-robert-kwiatkowski-gosciem-popoludniowej-rozmowy-w-rmf-fm,nId,7183880"><img align="left" alt="Robert Kwiatkowski gościem Popołudniowej rozmowy w RMF FM" src="https://interia-s.pluscdn.pl/robert-kwiatkowski-gosciem-popoludniowej-rozmowy-w-rmf-fm/000I4SRD27TI4338-C307.jpg" /></a>Gościem Piotra Salaka w Popołudniowej rozmowie w RMF FM będzie dziś Robert Kwiatkowski, członek Rady Mediów Narodowych i były prezes TVP. Porozmawiamy o tym, czy nowej większości sejmowej uda się odzyskać media publiczne i jaki będzie ich dalszy los – czy odpolitycznienie w tym przypadku jest realne czy to czysta utopia? </p><br clear="all" />

## Kontrole na polsko-słowackiej granicy przedłużone do 2 stycznia
 - [https://www.rmf24.pl/fakty/polska/news-kontrole-na-polsko-slowackiej-granicy-przedluzone-do-2-stycz,nId,7183946](https://www.rmf24.pl/fakty/polska/news-kontrole-na-polsko-slowackiej-granicy-przedluzone-do-2-stycz,nId,7183946)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T16:44:00+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-kontrole-na-polsko-slowackiej-granicy-przedluzone-do-2-stycz,nId,7183946"><img align="left" alt="Kontrole na polsko-słowackiej granicy przedłużone do 2 stycznia" src="https://interia-s.pluscdn.pl/kontrole-na-polsko-slowackiej-granicy-przedluzone-do-2-stycz/000I4U0H0HHW51OC-C307.jpg" /></a>Minister Spraw Wewnętrznych i Administracji Paweł Szefernaker o przedłużeniu kontroli na polsko-słowackiej granicy. Będą one prowadzone do 2 stycznia 2024 r. </p><br clear="all" />

## Słowaccy przewoźnicy rozpoczęli blokadę jedynego przejścia z Ukrainą
 - [https://www.rmf24.pl/fakty/swiat/news-slowaccy-przewoznicy-rozpoczeli-blokade-jedynego-przejscia-z,nId,7183921](https://www.rmf24.pl/fakty/swiat/news-slowaccy-przewoznicy-rozpoczeli-blokade-jedynego-przejscia-z,nId,7183921)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T15:39:43+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-slowaccy-przewoznicy-rozpoczeli-blokade-jedynego-przejscia-z,nId,7183921"><img align="left" alt="Słowaccy przewoźnicy rozpoczęli blokadę jedynego przejścia z Ukrainą" src="https://interia-s.pluscdn.pl/slowaccy-przewoznicy-rozpoczeli-blokade-jedynego-przejscia-z/000I4TT42VAS5CCM-C307.jpg" /></a>Do 30 grudnia ma potrwać blokada jedynego słowacko-ukraińskiego przejścia granicznego w Vyżnem Nemieckiem-Użhorodzie. Protest zorganizowany przez transportowców ze Słowacji rozpoczął się w piątek po południu.</p><br clear="all" />

## Najnowsze sankcje wobec Rosji nie będą obejmować diamentów?
 - [https://www.rmf24.pl/polityka/news-najnowsze-sankcje-wobec-rosji-nie-beda-obejmowac-diamentow,nId,7183882](https://www.rmf24.pl/polityka/news-najnowsze-sankcje-wobec-rosji-nie-beda-obejmowac-diamentow,nId,7183882)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T15:30:00+00:00

<p><a href="https://www.rmf24.pl/polityka/news-najnowsze-sankcje-wobec-rosji-nie-beda-obejmowac-diamentow,nId,7183882"><img align="left" alt="Najnowsze sankcje wobec Rosji nie będą obejmować diamentów?" src="https://interia-s.pluscdn.pl/najnowsze-sankcje-wobec-rosji-nie-beda-obejmowac-diamentow/000I4TDXFO4I8NM5-C307.jpg" /></a>Diamenty mogą wypaść z 12. unijnego pakietu sankcji wobec Rosji – alarmuje jeden z unijnych dyplomatów w rozmowie z brukselską korespondentką RMF FM Katarzyną Szymańską-Borginon. Kraje UE mozolnie próbują uzgodnić 12. pakiet sankcji, osłabiając go w porównaniu z pierwotną propozycją. </p><br clear="all" />

## Ważne zmiany dla emerytów i rencistów. Od dziś mogą więcej dorobić
 - [https://www.rmf24.pl/ekonomia/news-wazne-zmiany-dla-emerytow-i-rencistow-od-dzis-moga-wiecej-do,nId,7183906](https://www.rmf24.pl/ekonomia/news-wazne-zmiany-dla-emerytow-i-rencistow-od-dzis-moga-wiecej-do,nId,7183906)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T15:10:54+00:00

<p><a href="https://www.rmf24.pl/ekonomia/news-wazne-zmiany-dla-emerytow-i-rencistow-od-dzis-moga-wiecej-do,nId,7183906"><img align="left" alt="Ważne zmiany dla emerytów i rencistów. Od dziś mogą więcej dorobić" src="https://interia-s.pluscdn.pl/wazne-zmiany-dla-emerytow-i-rencistow-od-dzis-moga-wiecej-do/000I4THJ28X4N015-C307.jpg" /></a>Emeryci i renciści od dziś mogą nieco więcej dorobić. Zmieniły się limity dorabiania do świadczenia - przypomina Zakład Ubezpieczeń Społecznych. ​Ta kwota wzrasta o ponad 130 zł.</p><br clear="all" />

## Tragedia podczas budowy kanalizacji. Ziemia przysypała 31-latka
 - [https://www.rmf24.pl/regiony/poznan/news-tragedia-podczas-budowy-kanalizacji-ziemia-przysypala-31-lat,nId,7183893](https://www.rmf24.pl/regiony/poznan/news-tragedia-podczas-budowy-kanalizacji-ziemia-przysypala-31-lat,nId,7183893)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T15:09:59+00:00

<p><a href="https://www.rmf24.pl/regiony/poznan/news-tragedia-podczas-budowy-kanalizacji-ziemia-przysypala-31-lat,nId,7183893"><img align="left" alt="Tragedia podczas budowy kanalizacji. Ziemia przysypała 31-latka  " src="https://interia-s.pluscdn.pl/tragedia-podczas-budowy-kanalizacji-ziemia-przysypala-31-lat/000I4TEHYNCSW67I-C307.jpg" /></a>Podczas budowy kanalizacji ziemia przysypała mężczyznę w Nowym Borówku (Wielkopolskie). Życia 31-latka nie udało się uratować.</p><br clear="all" />

## Atak nożownika w Rzeszowie. Nowe informacje o stanie zdrowia 12-latki
 - [https://www.rmf24.pl/regiony/rzeszow/news-atak-nozownika-w-rzeszowie-nowe-informacje-o-stanie-zdrowia-,nId,7183832](https://www.rmf24.pl/regiony/rzeszow/news-atak-nozownika-w-rzeszowie-nowe-informacje-o-stanie-zdrowia-,nId,7183832)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T14:16:00+00:00

<p><a href="https://www.rmf24.pl/regiony/rzeszow/news-atak-nozownika-w-rzeszowie-nowe-informacje-o-stanie-zdrowia-,nId,7183832"><img align="left" alt="Atak nożownika w Rzeszowie. Nowe informacje o stanie zdrowia 12-latki" src="https://interia-s.pluscdn.pl/atak-nozownika-w-rzeszowie-nowe-informacje-o-stanie-zdrowia/000I4SLH6HX8AS35-C307.jpg" /></a>12-letnia Anastasia, która 13 listopada została poraniona nożem przez 16-latka, przeszła w Uniwersyteckim Szpitalu Klinicznym w Rzeszowie zabieg zszycia powieki. Dziewczynka najprawdopodobniej w weekend opuści szpital. </p><br clear="all" />

## Protest przewoźników. Ukraińcy informują o uzgodnieniach z polskim rządem
 - [https://www.rmf24.pl/fakty/polska/news-protest-przewoznikow-ukraincy-informuja-o-uzgodnieniach-z-po,nId,7183845](https://www.rmf24.pl/fakty/polska/news-protest-przewoznikow-ukraincy-informuja-o-uzgodnieniach-z-po,nId,7183845)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T14:14:00+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-protest-przewoznikow-ukraincy-informuja-o-uzgodnieniach-z-po,nId,7183845"><img align="left" alt="Protest przewoźników. Ukraińcy informują o uzgodnieniach z polskim rządem" src="https://interia-s.pluscdn.pl/protest-przewoznikow-ukraincy-informuja-o-uzgodnieniach-z-po/000I4SKB1RUVY5SK-C307.jpg" /></a>Ministerstwo Odbudowy Ukrainy po spotkaniu z przedstawicielami polskiego Ministerstwa Infrastruktury podało, że obie strony porozumiały się w sprawie kilku działań, które mają załagodzić napiętą sytuację na przejściach granicznych zablokowanych przez polskich przewoźników. Dziś mija 25. dzień od rozpoczęcia protestu transportowców. </p><br clear="all" />

## Duda o powołaniu rządu Tuska: Nie będę tego przeciągał
 - [https://www.rmf24.pl/polityka/news-duda-o-powolaniu-rzadu-tuska-nie-bede-tego-przeciagal,nId,7183830](https://www.rmf24.pl/polityka/news-duda-o-powolaniu-rzadu-tuska-nie-bede-tego-przeciagal,nId,7183830)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T14:02:00+00:00

<p><a href="https://www.rmf24.pl/polityka/news-duda-o-powolaniu-rzadu-tuska-nie-bede-tego-przeciagal,nId,7183830"><img align="left" alt="Duda o powołaniu rządu Tuska: Nie będę tego przeciągał " src="https://interia-s.pluscdn.pl/duda-o-powolaniu-rzadu-tuska-nie-bede-tego-przeciagal/000I4SIC28WX2DRP-C307.jpg" /></a>&quot;Nie będę tego przeciągał i nie będę tego opóźniał&quot; - podkreślił w Dubaju prezydent Andrzej Duda, pytany o powołanie rządu w tzw. drugim kroku konstytucyjnym. Zaznaczył, że wszystko będzie zgodnie z konstytucyjnymi unormowaniami i terminami.</p><br clear="all" />

## Alerty RCB! W prognozach śnieżyce, drogi mogą być nieprzejezdne
 - [https://www.rmf24.pl/pogoda/news-alerty-rcb-w-prognozach-sniezyce-drogi-moga-byc-nieprzejezdn,nId,7183802](https://www.rmf24.pl/pogoda/news-alerty-rcb-w-prognozach-sniezyce-drogi-moga-byc-nieprzejezdn,nId,7183802)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T13:39:00+00:00

<p><a href="https://www.rmf24.pl/pogoda/news-alerty-rcb-w-prognozach-sniezyce-drogi-moga-byc-nieprzejezdn,nId,7183802"><img align="left" alt="Alerty RCB! W prognozach śnieżyce, drogi mogą być nieprzejezdne" src="https://interia-s.pluscdn.pl/alerty-rcb-w-prognozach-sniezyce-drogi-moga-byc-nieprzejezdn/000I4SDXG9XXWPU5-C307.jpg" /></a>Niż Robin wkracza do Polski. Rządowe Centrum Bezpieczeństwa rozesłało do mieszkańców południowych regionów Polski ostrzeżenia przed intensywnymi opadami śniegu. &quot;Drogi mogą być nieprzejezdne&quot; – czytamy w komunikacie. </p><br clear="all" />

## Na szczyt klimatyczny polecieli trzema odrzutowcami. Karol III, Sunak i Cameron w ogniu krytyki
 - [https://www.rmf24.pl/fakty/swiat/news-na-szczyt-klimatyczny-polecieli-trzema-odrzutowcami-karol-ii,nId,7183788](https://www.rmf24.pl/fakty/swiat/news-na-szczyt-klimatyczny-polecieli-trzema-odrzutowcami-karol-ii,nId,7183788)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T12:59:00+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-na-szczyt-klimatyczny-polecieli-trzema-odrzutowcami-karol-ii,nId,7183788"><img align="left" alt="Na szczyt klimatyczny polecieli trzema odrzutowcami. Karol III, Sunak i Cameron w ogniu krytyki" src="https://interia-s.pluscdn.pl/na-szczyt-klimatyczny-polecieli-trzema-odrzutowcami-karol-ii/000I4S51FXGH30PK-C307.jpg" /></a>Brytyjskie media oskarżają o hipokryzję Karola III, Rishiego Sunaka i ministra spraw zagranicznych Davida Camerona. To ta trójka reprezentuje Wielką Brytanie na konferencji klimatycznej COP28. Krytykę wywołał sposób podróży monarchy i polityków. Do Dubaju dotarli osobnymi odrzutowcami.</p><br clear="all" />

## Helikopter rozbił się na autostradzie w Madrycie. Trzy osoby ranne
 - [https://www.rmf24.pl/fakty/swiat/news-helikopter-rozbil-sie-na-autostradzie-w-madrycie-trzy-osoby-,nId,7183756](https://www.rmf24.pl/fakty/swiat/news-helikopter-rozbil-sie-na-autostradzie-w-madrycie-trzy-osoby-,nId,7183756)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T12:45:00+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-helikopter-rozbil-sie-na-autostradzie-w-madrycie-trzy-osoby-,nId,7183756"><img align="left" alt="Helikopter rozbił się na autostradzie w Madrycie. Trzy osoby ranne" src="https://interia-s.pluscdn.pl/helikopter-rozbil-sie-na-autostradzie-w-madrycie-trzy-osoby/000I4RLTDODSV2O6-C307.jpg" /></a>Trzy osoby zostały ranne w katastrofie śmigłowca, który rozbił się na autostradzie M-40 w Madrycie. Na trasie utworzyły się ogromne korki w obu kierunkach.</p><br clear="all" />

## Gabriel Seweryn nie żyje. Są wyniki sekcji zwłok
 - [https://www.rmf24.pl/fakty/polska/news-gabriel-seweryn-nie-zyje-sa-wyniki-sekcji-zwlok,nId,7183516](https://www.rmf24.pl/fakty/polska/news-gabriel-seweryn-nie-zyje-sa-wyniki-sekcji-zwlok,nId,7183516)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T12:36:59+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-gabriel-seweryn-nie-zyje-sa-wyniki-sekcji-zwlok,nId,7183516"><img align="left" alt="Gabriel Seweryn nie żyje. Są wyniki sekcji zwłok" src="https://interia-s.pluscdn.pl/gabriel-seweryn-nie-zyje-sa-wyniki-sekcji-zwlok/000I4S0TG45HW7AR-C307.jpg" /></a>Sekcja zwłok nie przyniosła odpowiedzi na pytanie o przyczynę śmierci Gabriela Seweryna - poinformował TVN24. Jak podała stacja, wykluczono jednak, że zgon nastąpił w wyniku obrażeń ciała.</p><br clear="all" />

## Śmierć 14-letniej Natalii. Znamy wstępne wyniki sekcji zwłok
 - [https://www.rmf24.pl/regiony/krakow/news-smierc-14-letniej-natalii-znamy-wstepne-wyniki-sekcji-zwlok,nId,7183508](https://www.rmf24.pl/regiony/krakow/news-smierc-14-letniej-natalii-znamy-wstepne-wyniki-sekcji-zwlok,nId,7183508)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T12:03:38+00:00

<p><a href="https://www.rmf24.pl/regiony/krakow/news-smierc-14-letniej-natalii-znamy-wstepne-wyniki-sekcji-zwlok,nId,7183508"><img align="left" alt="Śmierć 14-letniej Natalii. Znamy wstępne wyniki sekcji zwłok" src="https://interia-s.pluscdn.pl/smierc-14-letniej-natalii-znamy-wstepne-wyniki-sekcji-zwlok/000I4RJ48AR0RSRE-C307.jpg" /></a>Śmierć mózgowa spowodowana masywnym krwotokiem i obrzękiem mózgu. To - jak dowiedział się reporter RMF FM - wstępne wyniki sekcji zwłok 14-letniej Natalii. Dziewczynka we wtorek przez kilka godzin była poszukiwana w Andrychowie przez policję i rodzinę.</p><br clear="all" />

## Kiedy wybór nowego premiera? Tusk podał datę
 - [https://www.rmf24.pl/polityka/news-kiedy-wybor-nowego-premiera-tusk-podal-date,nId,7183462](https://www.rmf24.pl/polityka/news-kiedy-wybor-nowego-premiera-tusk-podal-date,nId,7183462)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T11:19:41+00:00

<p><a href="https://www.rmf24.pl/polityka/news-kiedy-wybor-nowego-premiera-tusk-podal-date,nId,7183462"><img align="left" alt="Kiedy wybór nowego premiera? Tusk podał datę " src="https://interia-s.pluscdn.pl/kiedy-wybor-nowego-premiera-tusk-podal-date/000I4QTAQ39Y2H8O-C307.jpg" /></a>&quot;Spodziewajcie się państwo wyboru nowego rządu 11 grudnia, a jeśli czas na to nie pozwoli, to 12 grudnia expose nowego premiera. Zaprzysiężenie zakładamy natomiast 13 grudnia&quot; - podkreślił lider PO Donald Tusk.</p><br clear="all" />

## Rząd chce zwiększyć finansowanie programu "Bezpieczny kredyt 2 proc."
 - [https://www.rmf24.pl/ekonomia/news-rzad-chce-zwiekszyc-finansowanie-programu-bezpieczny-kredyt-,nId,7183440](https://www.rmf24.pl/ekonomia/news-rzad-chce-zwiekszyc-finansowanie-programu-bezpieczny-kredyt-,nId,7183440)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T11:19:00+00:00

<p><a href="https://www.rmf24.pl/ekonomia/news-rzad-chce-zwiekszyc-finansowanie-programu-bezpieczny-kredyt-,nId,7183440"><img align="left" alt="Rząd chce zwiększyć finansowanie programu &quot;Bezpieczny kredyt 2 proc.&quot;" src="https://interia-s.pluscdn.pl/rzad-chce-zwiekszyc-finansowanie-programu-bezpieczny-kredyt/000I4QS6P5JAT9TE-C307.jpg" /></a>Rząd chce zwiększyć finansowanie programu &quot;Bezpieczny kredyt 2 proc.&quot; - poinformował na konferencji prasowej premier Mateusz Morawiecki.</p><br clear="all" />

## Neonet ma problemy. Firma złożyła wniosek o upadłość
 - [https://www.rmf24.pl/ekonomia/news-neonet-ma-problemy-firma-zlozyla-wniosek-o-upadlosc,nId,7183416](https://www.rmf24.pl/ekonomia/news-neonet-ma-problemy-firma-zlozyla-wniosek-o-upadlosc,nId,7183416)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T11:05:10+00:00

<p><a href="https://www.rmf24.pl/ekonomia/news-neonet-ma-problemy-firma-zlozyla-wniosek-o-upadlosc,nId,7183416"><img align="left" alt="Neonet ma problemy. Firma złożyła wniosek o upadłość " src="https://interia-s.pluscdn.pl/neonet-ma-problemy-firma-zlozyla-wniosek-o-upadlosc/000I4QCHOXPPIFMU-C307.jpg" /></a>Neonet złożył do Krajowego Rejestru Zadłużonych wniosek o wszczęcie postępowania upadłościowego. Firma wyjaśnia, że &quot;krok ten został podjęty wyłącznie na wypadek&quot;, gdyby spółce nie udało się osiągnąć zamierzonego celu podczas restrukturyzacji. Neonet zapewnia, że &quot;żaden klient sieci nie odczuje trudności i problemów w zakupach oraz obsłudze obecnych oraz przyszłych zamówień realizowanych w sklepach stacjonarnych oraz online&quot;.</p><br clear="all" />

## Prof. Orłowski: Tegoroczne święta Bożego Narodzenia znów najdroższe w historii
 - [https://www.rmf24.pl/tylko-w-rmf24/rozmowa-w-poludnie/news-prof-orlowski-tegoroczne-swieta-bozego-narodzenia-znow-najdr,nId,7183375](https://www.rmf24.pl/tylko-w-rmf24/rozmowa-w-poludnie/news-prof-orlowski-tegoroczne-swieta-bozego-narodzenia-znow-najdr,nId,7183375)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T11:02:00+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/rozmowa-w-poludnie/news-prof-orlowski-tegoroczne-swieta-bozego-narodzenia-znow-najdr,nId,7183375"><img align="left" alt="Prof. Orłowski: Tegoroczne święta Bożego Narodzenia znów najdroższe w historii" src="https://interia-s.pluscdn.pl/prof-orlowski-tegoroczne-swieta-bozego-narodzenia-znow-najdr/000I4POSN4LNGCBM-C307.jpg" /></a>„Nadchodzące święta Bożego Narodzenia będą kolejny rok z rzędu najdroższymi w historii” – ocenił ekonomista, prof. Witold Orłowski, który był w piątek gościem Rozmowy w południe w RMF FM i Radiu RMF24. Zwrócił uwagę, że inflacja - ze względu na obniżony VAT na żywność czy zamrożone ceny energii elektrycznej – jest sztucznie zaniżona, więc ceny będą w dalszym ciągu rosnąć.</p><br clear="all" />

## Prof. Witold Orłowski: Branie kredytu w Polsce jest w tej chwili bardzo opłacalne
 - [https://www.rmf24.pl/tylko-w-rmf24/rozmowa-w-poludnie/news-prof-witold-orlowski-branie-kredytu-w-polsce-jest-w-tej-chwi,nId,7183375](https://www.rmf24.pl/tylko-w-rmf24/rozmowa-w-poludnie/news-prof-witold-orlowski-branie-kredytu-w-polsce-jest-w-tej-chwi,nId,7183375)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T11:02:00+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/rozmowa-w-poludnie/news-prof-witold-orlowski-branie-kredytu-w-polsce-jest-w-tej-chwi,nId,7183375"><img align="left" alt="Prof. Witold Orłowski: Branie kredytu w Polsce jest w tej chwili bardzo opłacalne" src="https://interia-s.pluscdn.pl/prof-witold-orlowski-branie-kredytu-w-polsce-jest-w-tej-chwi/000I4POSN4LNGCBM-C307.jpg" /></a>&quot;Dlaczego ludzie biorą kredyty? Po pierwsze dlatego, że wydaje się, że najtrudniejszy okres gospodarczy już przeszedł, a ponieważ nie było dużego ryzyka wzrostu bezrobocia, ludzie czuli się dość bezpiecznie i nie bali się tego, że będą mieli problemy. Z drugiej strony trzeba powiedzieć, troszkę wbrew temu, co się powszechnie mówi: branie kredytu (konsumpcyjnego – przyp. RMF FM) w Polsce jest w tej chwili bardzo opłacalne&quot; – mówił w Rozmowie w południe w RMF FM i Radiu RMF24 prof. Witold Orłowski. </p><br clear="all" />

## Nożownik z Kadzidła z zarzutem usiłowania zabójstwa wielu osób
 - [https://www.rmf24.pl/regiony/warszawa/news-nozownik-z-kadzidla-z-zarzutem-usilowania-zabojstwa-wielu-os,nId,7183372](https://www.rmf24.pl/regiony/warszawa/news-nozownik-z-kadzidla-z-zarzutem-usilowania-zabojstwa-wielu-os,nId,7183372)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T09:50:00+00:00

<p><a href="https://www.rmf24.pl/regiony/warszawa/news-nozownik-z-kadzidla-z-zarzutem-usilowania-zabojstwa-wielu-os,nId,7183372"><img align="left" alt="Nożownik z Kadzidła z zarzutem usiłowania zabójstwa wielu osób" src="https://interia-s.pluscdn.pl/nozownik-z-kadzidla-z-zarzutem-usilowania-zabojstwa-wielu-os/000I4PPM1U55A1AD-C307.jpg" /></a>Zarzut usiłowania wielu osób usłyszał Albert G. - nożownik z Kadzidła. Grozi mu dożywocie. </p><br clear="all" />

## Prof. Witold Orłowski gościem Rozmowy w południe w RMF FM i Radiu RMF24
 - [https://www.rmf24.pl/tylko-w-rmf24/rozmowa-w-poludnie/news-prof-witold-orlowski-gosciem-rozmowy-w-poludnie-w-rmf-fm-i-r,nId,7183375](https://www.rmf24.pl/tylko-w-rmf24/rozmowa-w-poludnie/news-prof-witold-orlowski-gosciem-rozmowy-w-poludnie-w-rmf-fm-i-r,nId,7183375)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T09:34:42+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/rozmowa-w-poludnie/news-prof-witold-orlowski-gosciem-rozmowy-w-poludnie-w-rmf-fm-i-r,nId,7183375"><img align="left" alt="Prof. Witold Orłowski gościem Rozmowy w południe w RMF FM i Radiu RMF24" src="https://interia-s.pluscdn.pl/prof-witold-orlowski-gosciem-rozmowy-w-poludnie-w-rmf-fm-i-r/000I4POSN4LNGCBM-C307.jpg" /></a>Z ekonomistą porozmawiamy między innymi o inflacji, która - według wstępnych danych GUS - w listopadzie rok do roku wyniosła 6,5 proc., prawie tyle samo, co w październiku (6,6 proc.). Czy to koniec trendu spadkowego? W poprzednich miesiącach różnice te były większe.</p><br clear="all" />

## Ustawa wiatrakowa. PiS zapowiada wnioski do prokuratury i CBA
 - [https://www.rmf24.pl/polityka/news-ustawa-wiatrakowa-pis-zapowiada-wnioski-do-prokuratury-i-cba,nId,7183373](https://www.rmf24.pl/polityka/news-ustawa-wiatrakowa-pis-zapowiada-wnioski-do-prokuratury-i-cba,nId,7183373)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T09:32:17+00:00

<p><a href="https://www.rmf24.pl/polityka/news-ustawa-wiatrakowa-pis-zapowiada-wnioski-do-prokuratury-i-cba,nId,7183373"><img align="left" alt="Ustawa wiatrakowa. PiS zapowiada wnioski do prokuratury i CBA" src="https://interia-s.pluscdn.pl/ustawa-wiatrakowa-pis-zapowiada-wnioski-do-prokuratury-i-cba/000I4PNN8FGYHLK1-C307.jpg" /></a>&quot;Składamy wniosek do prokuratury regionalnej i Centralnego Biura Antykorupcyjnego, żeby te służby sprawdziły, kto stoi za poselskim projektem ustawy ws. cen energii. Widać że nie napisali jej posłowie, pytanie, jaka firma ma na tym zarobić&quot; - powiedział poseł PiS, szef MEiN Krzysztof Szczucki.</p><br clear="all" />

## Alert ws. smogu w Polsce. "Zrezygnuj z aktywności na zewnątrz"
 - [https://www.rmf24.pl/pogoda/news-alert-ws-smogu-w-polsce-zrezygnuj-z-aktywnosci-na-zewnatrz,nId,7183304](https://www.rmf24.pl/pogoda/news-alert-ws-smogu-w-polsce-zrezygnuj-z-aktywnosci-na-zewnatrz,nId,7183304)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T09:04:15+00:00

<p><a href="https://www.rmf24.pl/pogoda/news-alert-ws-smogu-w-polsce-zrezygnuj-z-aktywnosci-na-zewnatrz,nId,7183304"><img align="left" alt="Alert ws. smogu w Polsce. &quot;Zrezygnuj z aktywności na zewnątrz&quot;" src="https://interia-s.pluscdn.pl/alert-ws-smogu-w-polsce-zrezygnuj-z-aktywnosci-na-zewnatrz/000I4OWZA4PAAJUQ-C307.jpg" /></a>&quot;Zrezygnuj z aktywności na zewnątrz&quot; - przestrzega Rządowe Centrum Bezpieczeństwa (RCB) w wydanym dziś rano alercie dotyczącym smogu. Komunikat dotyczy kilkunastu miejscowości i kilku powiatów w różnych częściach Polski. </p><br clear="all" />

## Alerty najwyższego stopnia. Niż Robin przyniesie śnieżyce
 - [https://www.rmf24.pl/pogoda/news-alerty-najwyzszego-stopnia-niz-robin-przyniesie-sniezyce,nId,7183337](https://www.rmf24.pl/pogoda/news-alerty-najwyzszego-stopnia-niz-robin-przyniesie-sniezyce,nId,7183337)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T08:55:59+00:00

<p><a href="https://www.rmf24.pl/pogoda/news-alerty-najwyzszego-stopnia-niz-robin-przyniesie-sniezyce,nId,7183337"><img align="left" alt="Alerty najwyższego stopnia. Niż Robin przyniesie śnieżyce" src="https://interia-s.pluscdn.pl/alerty-najwyzszego-stopnia-niz-robin-przyniesie-sniezyce/000I4PDXYL640QO9-C307.jpg" /></a>Instytut Meteorologii i Gospodarki Wodnej wydał ostrzeżenia trzeciego stopnia dla części kraju przed intensywnymi opadami śniegu. Możliwy jest przyrost pokrywy śnieżnej o 40 cm do nawet 55 cm. Alerty trzeciego stopnia dotyczą południa kraju. IMGW wydał też ostrzeżenia pierwszego i drugiego stopnia.</p><br clear="all" />

## Prawie pół metra śniegu. Niż Robin przyniesie śnieżyce
 - [https://www.rmf24.pl/pogoda/news-prawie-pol-metra-sniegu-niz-robin-przyniesie-sniezyce,nId,7183337](https://www.rmf24.pl/pogoda/news-prawie-pol-metra-sniegu-niz-robin-przyniesie-sniezyce,nId,7183337)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T08:55:59+00:00

<p><a href="https://www.rmf24.pl/pogoda/news-prawie-pol-metra-sniegu-niz-robin-przyniesie-sniezyce,nId,7183337"><img align="left" alt="Prawie pół metra śniegu. Niż Robin przyniesie śnieżyce" src="https://interia-s.pluscdn.pl/prawie-pol-metra-sniegu-niz-robin-przyniesie-sniezyce/000I4PDXYL640QO9-C307.jpg" /></a>Instytut Meteorologii i Gospodarki Wodnej wydał ostrzeżenia drugiego stopnia dla części kraju przed intensywnymi opadami śniegu. Możliwy jest przyrost pokrywy śnieżnej o 30 cm do nawet 40 cm. Alerty dotyczą południa kraju. </p><br clear="all" />

## Śmierć 14-letniej Natalii. Policja wszczyna kontrolę, dziś sekcja zwłok
 - [https://www.rmf24.pl/regiony/news-smierc-14-letniej-natalii-policja-wszczyna-kontrole-dzis-sek,nId,7183322](https://www.rmf24.pl/regiony/news-smierc-14-letniej-natalii-policja-wszczyna-kontrole-dzis-sek,nId,7183322)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T08:45:23+00:00

<p><a href="https://www.rmf24.pl/regiony/news-smierc-14-letniej-natalii-policja-wszczyna-kontrole-dzis-sek,nId,7183322"><img align="left" alt="Śmierć 14-letniej Natalii. Policja wszczyna kontrolę, dziś sekcja zwłok" src="https://interia-s.pluscdn.pl/smierc-14-letniej-natalii-policja-wszczyna-kontrole-dzis-sek/000I4OXDJ0F238Y3-C307.jpg" /></a>Dziś poznamy wstępne wyniki sekcji zwłok 14-letniej Natalii, która zmarła w środę w Uniwersyteckim Szpitalu Dziecięcym w Krakowie. Wcześniej nastolatka kilka godzin spędziła siedząc koło sklepu w Andrychowie. Małopolska policja rozpoczęła z kolei kontrolę działań podjętych przez mundurowych z Andrychowa w sprawie zaginięcia 14-latki. </p><br clear="all" />

## Zełenski: Nie wycofujemy się i jestem z tego zadowolony [RELACJA]
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/na-zywo/news-zelenski-nie-wycofujemy-sie-i-jestem-z-tego-zadowolony-relac,nId,7183311](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/na-zywo/news-zelenski-nie-wycofujemy-sie-i-jestem-z-tego-zadowolony-relac,nId,7183311)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T08:34:13+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/na-zywo/news-zelenski-nie-wycofujemy-sie-i-jestem-z-tego-zadowolony-relac,nId,7183311"><img align="left" alt="Zełenski: Nie wycofujemy się i jestem z tego zadowolony [RELACJA]" src="https://interia-s.pluscdn.pl/zelenski-nie-wycofujemy-sie-i-jestem-z-tego-zadowolony-relac/000I4OWLFH7IX9HO-C307.jpg" /></a>&quot;Nie wystarcza nam mocy, by szybciej dostać to, czego chcemy. Nie oznacza to jednak, że powinniśmy się poddać, że powinniśmy skapitulować. Wierzymy w swoje działania. Walczymy o to, co do nas należy&quot; - oświadczył prezydent Ukrainy Wołodymyr Zełenski w wywiadzie dla Associated Press. &quot;Nie wycofujemy się i jestem z tego zadowolony. Walczymy z drugą armią świata i jestem z tego zadowolony. Tracimy ludzi i z tego nie jestem zadowolony&quot; - podkreślał. Rosja ponownie zaatakowała Ukrainę dronami Shahed, wypuszczając w nocy 25 takich maszyn. 18 z...</p><br clear="all" />

## Dramat 14-latki. Trzech mężczyzn miało ją wykorzystać seksualnie
 - [https://www.rmf24.pl/regiony/zakopane/news-dramat-14-latki-trzech-mezczyzn-mialo-ja-wykorzystac-seksual,nId,7183283](https://www.rmf24.pl/regiony/zakopane/news-dramat-14-latki-trzech-mezczyzn-mialo-ja-wykorzystac-seksual,nId,7183283)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T07:50:32+00:00

<p><a href="https://www.rmf24.pl/regiony/zakopane/news-dramat-14-latki-trzech-mezczyzn-mialo-ja-wykorzystac-seksual,nId,7183283"><img align="left" alt="Dramat 14-latki. Trzech mężczyzn miało ją wykorzystać seksualnie  " src="https://interia-s.pluscdn.pl/dramat-14-latki-trzech-mezczyzn-mialo-ja-wykorzystac-seksual/000I4O3DQDM198D7-C307.jpg" /></a>Sąd aresztował jednego z trzech mężczyzn podejrzanych o wykorzystanie seksualne 14-letniej mieszkanki powiatu limanowskiego. Podejrzani to mężczyźni w wieku 25, 27 i 28 lat - informuje portal limanowa.in. </p><br clear="all" />

## Zderzenie tramwajów w Warszawie. Dwie osoby poszkodowane
 - [https://www.rmf24.pl/regiony/warszawa/news-zderzenie-tramwajow-w-warszawie-dwie-osoby-poszkodowane,nId,7183262](https://www.rmf24.pl/regiony/warszawa/news-zderzenie-tramwajow-w-warszawie-dwie-osoby-poszkodowane,nId,7183262)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T07:23:00+00:00

<p><a href="https://www.rmf24.pl/regiony/warszawa/news-zderzenie-tramwajow-w-warszawie-dwie-osoby-poszkodowane,nId,7183262"><img align="left" alt="Zderzenie tramwajów w Warszawie. Dwie osoby poszkodowane" src="https://interia-s.pluscdn.pl/zderzenie-tramwajow-w-warszawie-dwie-osoby-poszkodowane/000I4NF6JY9C27WX-C307.jpg" /></a>Tramwaj linii 3 w kierunku Gocławka najechał na stojący na przystanku Dworzec Wileński tramwaj linii 28. Dwie osoby zostały poszkodowane, mają stłuczenia. Maciej Dutkiewicz, rzecznik Tramwajów Warszawskich poinformował, że po godz. 9 zakończyły się utrudnienia. </p><br clear="all" />

## Tragiczny pożar w Stalowej Woli. Nie żyje 64-latek
 - [https://www.rmf24.pl/regiony/rzeszow/news-tragiczny-pozar-w-stalowej-woli-nie-zyje-64-latek,nId,7183257](https://www.rmf24.pl/regiony/rzeszow/news-tragiczny-pozar-w-stalowej-woli-nie-zyje-64-latek,nId,7183257)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T07:07:39+00:00

<p><a href="https://www.rmf24.pl/regiony/rzeszow/news-tragiczny-pozar-w-stalowej-woli-nie-zyje-64-latek,nId,7183257"><img align="left" alt="Tragiczny pożar w Stalowej Woli. Nie żyje 64-latek" src="https://interia-s.pluscdn.pl/tragiczny-pozar-w-stalowej-woli-nie-zyje-64-latek/000I4NBX5H3WE8Y7-C307.jpg" /></a>64-latek zginął w pożarze mieszkania w bloku przy ul. Poniatowskiego w Stalowej Woli na Podkarpaciu. Z budynku ewakuowano 25 osób.</p><br clear="all" />

## Wawer: Atakujemy każdego, kto na to zasługuje
 - [https://www.rmf24.pl/tylko-w-rmf24/poranna-rozmowa/news-wawer-atakujemy-kazdego-kto-na-to-zasluguje,nId,7181523](https://www.rmf24.pl/tylko-w-rmf24/poranna-rozmowa/news-wawer-atakujemy-kazdego-kto-na-to-zasluguje,nId,7181523)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T07:02:00+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/poranna-rozmowa/news-wawer-atakujemy-kazdego-kto-na-to-zasluguje,nId,7181523"><img align="left" alt="Wawer: Atakujemy każdego, kto na to zasługuje " src="https://interia-s.pluscdn.pl/wawer-atakujemy-kazdego-kto-na-to-zasluguje/000I4OL9U0GCBM4Q-C307.jpg" /></a>&quot;Jest wiedzą powszechną, że doszło do patologii i przestępstw&quot; - w ten sposób potrzebę powołania komisji śledczej ds. Pegasusa uzasadniał poseł Konfederacji Michał Wawer, który był gościem Robert Mazurka w Porannej rozmowie w RMF FM. Parlamentarzysta zaznaczył, że &quot;jeżeli okaże się, iż nikt nie zawinił i wszyscy byli niewinni, to też komisja spełni swoją funkcję&quot;. Poseł powoływał się na doniesienia medialne w tej sprawie, a także mówił, że &quot;organizacje pozarządowe wykazują, iż wielu ludzi było podsłuchiwanych&quot;.</p><br clear="all" />

## ​600 ton chemikaliów z Białorusi. Dlaczego GIOŚ zgodził się na transport?
 - [https://www.rmf24.pl/fakty/polska/news-600-ton-chemikaliow-z-bialorusi-dlaczego-gios-zgodzil-sie-na,nId,7181881](https://www.rmf24.pl/fakty/polska/news-600-ton-chemikaliow-z-bialorusi-dlaczego-gios-zgodzil-sie-na,nId,7181881)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T06:40:00+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-600-ton-chemikaliow-z-bialorusi-dlaczego-gios-zgodzil-sie-na,nId,7181881"><img align="left" alt="​600 ton chemikaliów z Białorusi. Dlaczego GIOŚ zgodził się na transport?" src="https://interia-s.pluscdn.pl/600-ton-chemikaliow-z-bialorusi-dlaczego-gios-zgodzil-sie-na/000I4ME6VEABOII2-C307.jpg" /></a>Kilkaset ton niebezpiecznych odpadów chemicznych może w najbliższych miesiącach wjechać z Białorusi do Polski. Zgodę na ich tranzyt przez nasz kraj wydał niedawno Główny Inspektor Ochrony Środowiska. Przez Polskę chemiczne śmieci mają teoretycznie tylko przejechać, ale w decyzji GIOŚ nie ma mowy o konieczności ich konwojowania. Pytamy więc, czy polskie służby są gotowe na ewentualne kontrole tego rodzaju ładunków i jakie mają do tego narzędzia.</p><br clear="all" />

## Zamieszki z udziałem kibiców Legii. 39 osób aresztowanych
 - [https://www.rmf24.pl/sport/pilka-nozna/news-zamieszki-z-udzialem-kibicow-legii-39-osob-aresztowanych,nId,7183237](https://www.rmf24.pl/sport/pilka-nozna/news-zamieszki-z-udzialem-kibicow-legii-39-osob-aresztowanych,nId,7183237)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T06:27:52+00:00

<p><a href="https://www.rmf24.pl/sport/pilka-nozna/news-zamieszki-z-udzialem-kibicow-legii-39-osob-aresztowanych,nId,7183237"><img align="left" alt="Zamieszki z udziałem kibiców Legii. 39 osób aresztowanych " src="https://interia-s.pluscdn.pl/zamieszki-z-udzialem-kibicow-legii-39-osob-aresztowanych/000I4N8ALISGUX63-C307.jpg" /></a>Trzydzieści dziewięć osób aresztowanych, czterech rannych policjantów - to według stacji BBC efekt zamieszek, do jakich doszło w Birmingham z udziałem kibiców Legii Warszawa przed czwartkowym meczem piłkarskiej Ligi Konferencji z Aston Villą (1:2). Fani polskiego klubu nie zostali wpuszczeni na trybuny.</p><br clear="all" />

## Zamieszki z udziałem kibiców Legii. 46 osób aresztowanych
 - [https://www.rmf24.pl/sport/pilka-nozna/news-zamieszki-z-udzialem-kibicow-legii-46-osob-aresztowanych,nId,7183237](https://www.rmf24.pl/sport/pilka-nozna/news-zamieszki-z-udzialem-kibicow-legii-46-osob-aresztowanych,nId,7183237)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T06:27:52+00:00

<p><a href="https://www.rmf24.pl/sport/pilka-nozna/news-zamieszki-z-udzialem-kibicow-legii-46-osob-aresztowanych,nId,7183237"><img align="left" alt="Zamieszki z udziałem kibiców Legii. 46 osób aresztowanych " src="https://interia-s.pluscdn.pl/zamieszki-z-udzialem-kibicow-legii-46-osob-aresztowanych/000I4N8ALISGUX63-C307.jpg" /></a>Czterdzieści sześć osób aresztowanych i czterech rannych policjantów - to oficjalny efekt zamieszek, do jakich doszło w Birmingham z udziałem kibiców Legii Warszawa przed czwartkowym meczem piłkarskiej Ligi Konferencji z Aston Villą (1:2). Fani polskiego klubu nie zostali wpuszczeni na trybuny.</p><br clear="all" />

## Kniażycki o kryzysie na granicy: Nasze rządy niewiele zrobiły w tej sprawie
 - [https://www.rmf24.pl/tylko-w-rmf24/rozmowa-o-7/news-kniazycki-o-kryzysie-na-granicy-nasze-rzady-niewiele-zrobily,nId,7181586](https://www.rmf24.pl/tylko-w-rmf24/rozmowa-o-7/news-kniazycki-o-kryzysie-na-granicy-nasze-rzady-niewiele-zrobily,nId,7181586)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T06:00:00+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/rozmowa-o-7/news-kniazycki-o-kryzysie-na-granicy-nasze-rzady-niewiele-zrobily,nId,7181586"><img align="left" alt="Kniażycki o kryzysie na granicy: Nasze rządy niewiele zrobiły w tej sprawie" src="https://interia-s.pluscdn.pl/kniazycki-o-kryzysie-na-granicy-nasze-rzady-niewiele-zrobily/000I4KYSOPLTDDPJ-C307.jpg" /></a>Ani polski, ani ukraiński rząd dotychczas niewiele zrobiły, by zakończyć kryzys na granicy związany z protestem polskich przewoźników - ocenił deputowany do Rady Najwyższej Ukrainy Mykoła Kniażycki, który był gościem Rozmowy o 7:00 w RMF FM i Radiu RMF24. Według niego, na obecnej sytuacji korzysta jedynie Rosja.</p><br clear="all" />

## Wyciek danych z ALAB Laboratoria. Hakerzy zażądali kilkuset tysięcy dolarów
 - [https://www.rmf24.pl/fakty/polska/news-wyciek-danych-z-alab-laboratoria-hakerzy-zazadali-kilkuset-t,nId,7183228](https://www.rmf24.pl/fakty/polska/news-wyciek-danych-z-alab-laboratoria-hakerzy-zazadali-kilkuset-t,nId,7183228)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T05:53:24+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-wyciek-danych-z-alab-laboratoria-hakerzy-zazadali-kilkuset-t,nId,7183228"><img align="left" alt="Wyciek danych z ALAB Laboratoria. Hakerzy zażądali kilkuset tysięcy dolarów" src="https://interia-s.pluscdn.pl/wyciek-danych-z-alab-laboratoria-hakerzy-zazadali-kilkuset-t/000I4N6U9HRDLUGR-C307.jpg" /></a>Warszawska Prokuratura Regionalna wszczęła śledztwo w sprawie hakerów, którzy wykradli dane pacjentów ALAB Laboratoria. Śledztwo obejmuje również wątek dotyczący żądania okupu. Jak nieoficjalnie ustaliła PAP, szantażyści zażądali od firmy kilkuset tysięcy dolarów.</p><br clear="all" />

## Koniec rozejmu. Izrael wznowił walkę z Hamasem
 - [https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-koniec-rozejmu-izrael-wznowil-walke-z-hamasem,nId,7183219](https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-koniec-rozejmu-izrael-wznowil-walke-z-hamasem,nId,7183219)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-01T04:38:06+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-koniec-rozejmu-izrael-wznowil-walke-z-hamasem,nId,7183219"><img align="left" alt="Koniec rozejmu. Izrael wznowił walkę z Hamasem" src="https://interia-s.pluscdn.pl/koniec-rozejmu-izrael-wznowil-walke-z-hamasem/000I4PTBN5RDJNNC-C307.jpg" /></a>Izraelska armia poinformowała, że wznowiła działania zbrojne przeciwko Hamasowi w Strefie Gazy. Izraelskie lotnictwo i artyleria ostrzeliwują rano miasto Gaza - poinformowała francuska agencja AFP. Rozejm wygasł w piątek o godzinie 7:00 czasu lokalnego, czyli 6:00 polskiego czasu.</p><br clear="all" />

