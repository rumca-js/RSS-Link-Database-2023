# Source:Chip.pl, URL:https://www.chip.pl/feed, language:pl-PL

## Splątanie kwantowe w zasięgu ręki. Naukowcy zaobserwowali coś, co do tej pory pozostawało jedynie teorią
 - [https://www.chip.pl/2023/12/splatanie-kwantowe-nowe-narzedzie-do-badania](https://www.chip.pl/2023/12/splatanie-kwantowe-nowe-narzedzie-do-badania)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-12-01T20:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1100" src="https://konto.chip.pl/wp-content/uploads/2023/06/splatanie.jpeg" style="margin-bottom: 10px;" width="2400" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/06/splatanie.jpeg" style="display: block; margin: 1em auto;" /></p>
<p>Splątanie kwantowe jest równie dziwne, co obiecujące. Opracowane niedawno rozwiązanie powinno pozwolić na dogłębne zbadanie tego stanu, dzięki czemu pojawią się liczne jego zastosowania.  Ostatnimi badaniami w tej sprawie zajął się Peter Zoller z Uniwersytetu w Innsbrucku. Ustalenia jego zespołu w tej sprawie zostały opisane w Nature. Zanim jednak przejdziemy do zaprezentowania dokładnych wiosków naukowców, [&#8230;]</p>

## Największy reaktor fuzyjny na świecie uruchomiony! To jeszcze nie jest koniec
 - [https://www.chip.pl/2023/12/najwiekszy-reaktor-fuzyjny-jt-60sa-uruchomiony](https://www.chip.pl/2023/12/najwiekszy-reaktor-fuzyjny-jt-60sa-uruchomiony)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-12-01T18:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1500" src="https://konto.chip.pl/wp-content/uploads/2023/12/JT-60Sa.jpeg" style="margin-bottom: 10px;" width="2248" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/12/JT-60Sa.jpeg" style="display: block; margin: 1em auto;" /></p>
<p>1 grudnia 2023 roku po latach przygotowań otwarto największy jak dotąd reaktor fuzyjny na świecie. Mowa tutaj o reaktorze JT-60SA w Japonii. To duże osiągnięcie na drodze do osiągnięcia całkowicie czystej energii w fuzji jądrowej. Choć droga do tego jest przed nami jeszcze długa, to gra jest warta świeczki. Opanowanie pozyskiwania energii z fuzji jądrowej [&#8230;]</p>

## Polsat Box ma dla nas świąteczny prezent. Nawet 21 kanałów w &#8220;otwartym oknie&#8221;
 - [https://www.chip.pl/2023/12/polsat-box-swiateczny-prezent-nawet-21-kanalow-w-otwartym-oknie](https://www.chip.pl/2023/12/polsat-box-swiateczny-prezent-nawet-21-kanalow-w-otwartym-oknie)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-12-01T17:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="716" src="https://konto.chip.pl/wp-content/uploads/2023/12/polsat-box-promocja.jpg" style="margin-bottom: 10px;" width="1534" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/12/polsat-box-promocja.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Zbliżają się święta, a więc czas prezentów, które ma dla swoich klientów także Polsat Box. Od 1 grudnia do 7 stycznia w ramach otwartego okna klienci telewizji satelitarnej, kablowej IPTV oraz internetowej z dekoderem będą mogli oglądać nawet 21 kanałów telewizyjnych bez dodatkowych opłat. Nawet 21 kanałów bez dodatkowych opłat dla abonentów Polsat Box Choć [&#8230;]</p>

## Kolejny smartfon Infinix pojawi się w Polsce. NOTE 30 VIP Racing Edition w limitowanej edycji stworzonej wspólnie z BMW Designworks
 - [https://www.chip.pl/2023/12/infinix-note-30-vip-racing-edition-w-polsce-cena-specyfikacja](https://www.chip.pl/2023/12/infinix-note-30-vip-racing-edition-w-polsce-cena-specyfikacja)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-12-01T16:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1334" src="https://konto.chip.pl/wp-content/uploads/2023/12/Infinix_Note30VIP_RacingEdition_02.jpg" style="margin-bottom: 10px;" width="2000" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/12/Infinix_Note30VIP_RacingEdition_02.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Infinix to dość nowy gracz na polskim rynku smartfonów, ale za to wciąż dba, byśmy o nim nie zapomnieli. Tym razem szykuje się do wprowadzenia do sprzedaży kolejnego modelu. NOTE 30 VIP Racing Edition to limitowany smartfon, który powstał we współpracy z centrum projektowym Designworks należącym do grupy BMW. Od 4 grudnia w Polsce dostępna [&#8230;]</p>

## Fotowoltaiczne przechwalanki Chin. Czy oni oficjalnie mają najmocniejsze perowskity?
 - [https://www.chip.pl/2023/12/perowskity-z-chin-wydajnosc-18-proc](https://www.chip.pl/2023/12/perowskity-z-chin-wydajnosc-18-proc)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-12-01T14:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="716" src="https://konto.chip.pl/wp-content/uploads/2023/12/shanghai-5852019_1280.jpg" style="margin-bottom: 10px;" width="1280" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/12/shanghai-5852019_1280.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Słyszymy o nich coraz więcej, ale wciąż nie zdążyliśmy jeszcze dostrzec ich w praktycznym zastosowaniu. Chodzi o perowskity, które uznaje się za ogniwa słoneczne przyszłości – są tańsze w produkcji, a w konkretnych kombinacjach bywają o wiele wydajniejsze od krzemowych odpowiedników. W ostatnich dniach chińska firma badawcza przekazała, że najnowsze ich ogniwo osiągnęło zdumiewającą wydajność. [&#8230;]</p>

## Miało być 5G na Święta, ale koniec aukcji to nie koniec komplikacji
 - [https://www.chip.pl/2023/12/5g-na-swieta-aukcja-opoznienie](https://www.chip.pl/2023/12/5g-na-swieta-aukcja-opoznienie)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-12-01T12:30:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1280" src="https://konto.chip.pl/wp-content/uploads/2023/09/east-west-gate-wegry-5g-hauwei-33.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/09/east-west-gate-wegry-5g-hauwei-33.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Mamy grudzień, więc okres przedświąteczny, w którym spodziewaliśmy się zobaczyć wyścig o to, który operator jako pierwszy uruchomi sieć 5G na nowych, pachnących świeżością częstotliwościach. Na co też liczyli sami operatorzy, ale wygląda na to, że tego postępowania chyba zwyczajnie nie da się zakończyć w normalny sposób. Polska Izba Radiodyfuzji Cyfrowej może popsuć plany uruchomienia [&#8230;]</p>

## Threads w końcu w Europie? Tak &#8211; i być może szybciej niż ktokolwiek by myślał
 - [https://www.chip.pl/2023/12/meta-threads-europa-data-premiey-cena-funkcje](https://www.chip.pl/2023/12/meta-threads-europa-data-premiey-cena-funkcje)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-12-01T12:00:00+00:00

<img alt="Threads" class="attachment-full size-full wp-post-image" height="1706" src="https://konto.chip.pl/wp-content/uploads/2023/12/Threads-scaled.jpg" style="margin-bottom: 10px;" width="2560" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/12/Threads-scaled.jpg" style="display: block; margin: 1em auto;" /></p>
<p>W połowie 2023 roku wystartowała sieć społecznościowa Threads, będąca alternatywą dla platformy X po rządami Elona Muska. Ruszyła z przytupem &#8211; już pierwszego dnia stworzono ponad 70 milionów kont. Zapewne byłoby więcej, gdyby nie fakt, że nie działa ona na terenie Europy. Ale ten stan może wkrótce się zmienić. Za Threads stoi Meta, a nie [&#8230;]</p>

## Historia się powtarza? Microsoft chce usunąć z Windows 11 element, z którego wszyscy korzystają
 - [https://www.chip.pl/2023/12/windows-11-zmiany-nowosci-microsoft](https://www.chip.pl/2023/12/windows-11-zmiany-nowosci-microsoft)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-12-01T11:00:00+00:00

<img alt="Windows 11" class="attachment-full size-full wp-post-image" height="1080" src="https://konto.chip.pl/wp-content/uploads/2023/12/System-Windows-11.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/12/System-Windows-11.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Gdy Microsoft pracował nad Windows 8, jeden z tamtejszych &#8220;geniuszy&#8221; stwierdził, że z interfejsu zniknie przycisk Start, ponieważ &#8220;nikt go nie używa&#8221;. Jak się okazało w praktyce, człowiek ten żył w świecie niezależnym od prawdziwego. Ale co smutne &#8211; ta historia może się powtórzyć w przypadku Windows 11. I może Windows 12 także. Microsoft w [&#8230;]</p>

## Ten elektryczny rower ma zachwycić nawet profesjonalistów
 - [https://www.chip.pl/2023/12/ten-elektryczny-rower-ma-zachwycic-nawet-profesjonalistow](https://www.chip.pl/2023/12/ten-elektryczny-rower-ma-zachwycic-nawet-profesjonalistow)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-12-01T10:30:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="941" src="https://konto.chip.pl/wp-content/uploads/2023/12/C23_TesoroNeoCarbon1_EU_PDP_Desktop_1_V21.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/12/C23_TesoroNeoCarbon1_EU_PDP_Desktop_1_V21.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Co powiecie na elektryczny rower zaprojektowany specjalnie po to, aby połączyć w sobie esencję profesjonalnego roweru szosowego z wygodami roweru miejskiego i zaspokoić nawet najbardziej wymagających? Takim właśnie modelem ma być Tesoro Neo Carbon od Cannondale. Elektryczne rowery Tesoro Neo Carbon chcą podbić twoje serce Kiedy tylko wejdziemy na stronę Cannondale, przywita nas ogłoszenie związane [&#8230;]</p>

## Odkryją i zniszczą. Brytyjczycy wzmocnią wyjątkowe samoloty Posejdon
 - [https://www.chip.pl/2023/12/wielka-brytania-samolot-posejdon-torpedy](https://www.chip.pl/2023/12/wielka-brytania-samolot-posejdon-torpedy)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-12-01T10:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1080" src="https://konto.chip.pl/wp-content/uploads/2023/12/Samolot-Posejdon-Sting-Ray-torpeda-implementacja-2.jpg" style="margin-bottom: 10px;" width="1624" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/12/Samolot-Posejdon-Sting-Ray-torpeda-implementacja-2.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Wielka Brytania postanowiła zwiększyć potencjał samolotów patrolowych Posejdon, wykładając na znaczne ich ulepszenie ponad 1,159 miliarda złotych. Samoloty patrolowe Posejdon w rękach Wielkiej Brytanii czeka uzbrojeniowa rewolucja Posejdon MRA1 to wersja pochodna amerykańskiego samolotu patrolowego P-8A Posejdon, który to powstał na bazie pasażerskiego Boeinga 737-800ERX. W rękach Brytyjczyków ten samolot już teraz stanowi potężny element [&#8230;]</p>

## Test Dreame Z10 Station &#8211; to co najlepsze z obu światów w jednym odkurzaczu
 - [https://www.chip.pl/2023/12/dreame-z10-station-test-recenzja](https://www.chip.pl/2023/12/dreame-z10-station-test-recenzja)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-12-01T09:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1280" src="https://konto.chip.pl/wp-content/uploads/2023/11/dreame-z10-station-11.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/11/dreame-z10-station-11.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Odkurzacze pionowe są dobre, ale trzeba je ręcznie opróżniać. Roboty odkurzające są dobre, ale nie każdy ma do tego odpowiednie wnętrze. I tak dalej, i tak dalej&#8230; Dreame Z10 Station to najnowszy pionowy odkurzacz, który łączy w sobie to, co najlepsze z obu tych światów. Dreame Z10 Station to bardzo elegancki sprzęt. Tylko jeden element [&#8230;]</p>

## Ogromny strumień rozciąga się między galaktykami. Astronomowie nigdy jeszcze czegoś takiego nie widzieli
 - [https://www.chip.pl/2023/12/gcm-strumien-gwiazd-miedzy-galaktykami](https://www.chip.pl/2023/12/gcm-strumien-gwiazd-miedzy-galaktykami)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-12-01T08:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1092" src="https://konto.chip.pl/wp-content/uploads/2023/12/galaktyki-strumien.jpg" style="margin-bottom: 10px;" width="1598" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/12/galaktyki-strumien.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Jak wynika z ostatnich ustaleń astronomów, pomiędzy galaktykami istnieje strumień złożony z licznych gwiazd. Do tej pory tego typu struktury obserwowano zarówno w Drodze Mlecznej, jak i innych galaktykach, ale nie między nimi. Co więcej, ten niedawno zaobserwowany jest największym z dotychczas zidentyfikowanych, dlatego sprawa jest tym istotniejsza. O tym, czego międzynarodowy zespół dowiedział się [&#8230;]</p>

## Windows 10/Windows 11 &#8211; jak skonfigurować nowy komputer
 - [https://www.chip.pl/2023/12/windows-jak-skonfigurowac-nowy-komputer](https://www.chip.pl/2023/12/windows-jak-skonfigurowac-nowy-komputer)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-12-01T07:43:54+00:00

<img alt="Windows" class="attachment-full size-full wp-post-image" height="768" src="https://konto.chip.pl/wp-content/uploads/2021/10/windows-11.jpg" style="margin-bottom: 10px;" width="1024" /><p><img src="https://konto.chip.pl/wp-content/uploads/2021/10/windows-11.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Gdy kupujesz nowego laptopa lub desktopa, rzadko zdarza się, aby był przygotowany w komfortowy sposób. Zazwyczaj producent dokłada od siebie takie rzeczy, jak subskrypcję testową antywirusa lub inne dodatki, które niekoniecznie są Ci potrzebne. Dlatego po pierwszym uruchomieniu sprzętu warto poświęcić kilka chwil na jego oczyszczenie ze śmieci. Zobacz, jak zrobić to w przypadku systemów [&#8230;]</p>

## MG Motor debiutuje w Polsce &#8211; ktoś tu odrobił lekcje i przychodzi zdominować rynek
 - [https://www.chip.pl/2023/12/mg-motor-w-polsce-ceny-mg4-mg-hs-mg-zs](https://www.chip.pl/2023/12/mg-motor-w-polsce-ceny-mg4-mg-hs-mg-zs)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-12-01T06:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1707" src="https://konto.chip.pl/wp-content/uploads/2023/12/mg-motor-polska-premiera-35-scaled.jpg" style="margin-bottom: 10px;" width="2560" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/12/mg-motor-polska-premiera-35-scaled.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Legendarna marka MG Motor oficjalnie zadebiutowała w Polsce. Już pod chińskimi skrzydłami i robi to w sposób spektakularny. Nowe modele są idealnie dopasowane do rynku, a ich ceny&#8230; lepiej usiądźcie dobrze, bo ten ceny zrobią ogromne zamieszanie na rynku. Ile jest MG Motor w MG Motor? Nieważne, ważne jest, że Chińczycy dobrze zbadali polski rynek [&#8230;]</p>

## Takiego obrotu sprawy się nie spodziewaliśmy. Ukraiński sprzęt w rosyjskich dronach bojowych
 - [https://www.chip.pl/2023/12/rosyjskie-drony-shahed-1365-modul-lacznosci](https://www.chip.pl/2023/12/rosyjskie-drony-shahed-1365-modul-lacznosci)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-12-01T04:59:24+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1080" src="https://konto.chip.pl/wp-content/uploads/2023/05/Iranskie-drony-Shahed-136-informacje-1.jpg" style="margin-bottom: 10px;" width="1623" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/05/Iranskie-drony-Shahed-136-informacje-1.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Nie wygląda to najlepiej. Po niedawnym ataku przeprowadzonym przez Rosję broniąca się strona odkryła coś wręcz niewyobrażalnego w dronach, które wzięły udział w akcji. Takiego obrotu sprawy się nie spodziewaliśmy. Ukraiński sprzęt w rosyjskich dronach bojowych Drony Shahed-136 ewoluowały szybko od czasu ich pierwszego użycia, co obejmowało nowe projekty głowic bojowych, zmiany w procesach produkcyjnych [&#8230;]</p>

