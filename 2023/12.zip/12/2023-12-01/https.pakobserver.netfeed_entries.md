# Source:Pakistan Observer, URL:https://pakobserver.net/feed/, language:en-US

## Shane Dowrich announces international retirement
 - [https://pakobserver.net/shane-dowrich-announces-international-retirement](https://pakobserver.net/shane-dowrich-announces-international-retirement)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-12-01T23:11:32+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/12/gaoobliwoaar0n3_202312649860-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />West Indies wicketkeeper-batter Shane Dowrich has retired from international cricket with immediate effect. This means the 32-year-old, who was originally picked for West Indies’ upcoming home ODIs against England, has withdrawn from the squad. The CWI selection panel will not name a replacement for Dowrich for the three-match series, which begins on Sunday in Antigua. [&#8230;]

## Shanto to lead Bangladesh in New Zealand ODIs, T20Is
 - [https://pakobserver.net/shanto-to-lead-bangladesh-in-new-zealand-odis-t20is](https://pakobserver.net/shanto-to-lead-bangladesh-in-new-zealand-odis-t20is)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-12-01T23:11:32+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/12/Najmul-Hossain-Shanto-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Bangladesh named batsman Najmul Hossain Shanto as the country’s ODI and T20I captain for the tour of New Zealand next month. Bangladesh will tour New Zealand to play three ODI matches and three T20Is between December 17 and December 31. Najmul Hossain Shanto, who is currently leading the country’s Test side against New Zealand in [&#8230;]

## Uganda seal spot at T20 World Cup as Zimbabwe miss out
 - [https://pakobserver.net/uganda-seal-spot-at-t20-world-cup-as-zimbabwe-miss-out](https://pakobserver.net/uganda-seal-spot-at-t20-world-cup-as-zimbabwe-miss-out)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-12-01T23:11:31+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/12/0109465684aaad6-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />&#160; Uganda will make their first appearance at a cricket World Cup next year after qualifying on Thursday for the T20 tournament to be hosted by the West Indies and the United States. A nine-wicket win over Rwanda secured Uganda second place in the African regional qualifying event, joining Namibia at the 2024 T20 World [&#8230;]

## Taijul leaves Bangladesh three wickets away from victory on last day
 - [https://pakobserver.net/taijul-leaves-bangladesh-three-wickets-away-from-victory-on-last-day](https://pakobserver.net/taijul-leaves-bangladesh-three-wickets-away-from-victory-on-last-day)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-12-01T23:11:30+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/12/219127_197-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Taijul Islam led the Bangladesh spinners to put them on the verge of beating New Zealand in the Sylhet Test with three more wickets to take and an entire day left for it. New Zealand finished the day on 113 for 7, needing another 219 runs to win in their pursuit of 332, with an [&#8230;]

## Blasphemous remarks against Prophet of Islam SWA cannot be tolerated: Masarrat
 - [https://pakobserver.net/blasphemous-remarks-against-prophet-of-islam-swa-cannot-be-tolerated-masarrat](https://pakobserver.net/blasphemous-remarks-against-prophet-of-islam-swa-cannot-be-tolerated-masarrat)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-12-01T23:09:34+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/06/Masarrat--150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Illegally detained Chairman of All Parties Hurriyat Conference Masarrat Alam Butt has said that any kind of derogatory remarks against the Prophet of Islam Muhammad (SAW) cannot be tolerated by Muslims as the reverence and honour of the Khatamun Nabiyeen is greater than our own lives. According to Kashmir Media Service, Masarrat Alam Butt in [&#8230;]

## Complete shutdown observed in occupied Kashmir
 - [https://pakobserver.net/complete-shutdown-observed-in-occupied-kashmir](https://pakobserver.net/complete-shutdown-observed-in-occupied-kashmir)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-12-01T22:35:29+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/12/22-1-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Complete shutdown was observed in Indian illegally occupied Jammu and Kashmir, today, against the posting of a blasphemous video about Prophet Muhammad (peace be upon him) by a Hindu student from India studying in an institute in Srinagar. According to Kashmir Media Service, call for the shutdown was given by All Parties Hurriyat Conference and [&#8230;]

## Sindh cabinet approves Rs3.3b for repair of school buildings for polling stations
 - [https://pakobserver.net/sindh-cabinet-approves-rs3-3b-for-repair-of-school-buildings-for-polling-stations](https://pakobserver.net/sindh-cabinet-approves-rs3-3b-for-repair-of-school-buildings-for-polling-stations)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-12-01T22:30:37+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/12/WhatsApp-Image-2023-12-01-at-10.06.38-PM-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />&#160; The Provincial Caretaker cabinet of Sindh in over two hours of sitting discussed 24 agenda items and took important decisions including recruiting Assistant Sub-inspectors (ASIs) through a public service commission and approving Rs357 million for rangers to strengthen its capacity. The meeting was held under the chairmanship of Caretaker Sindh Chief Minister Justice (R) [&#8230;]

## Thai Chief Ombudsman calls on Sindh Governor
 - [https://pakobserver.net/thai-chief-ombudsman-calls-on-sindh-governor](https://pakobserver.net/thai-chief-ombudsman-calls-on-sindh-governor)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-12-01T22:30:35+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/12/governor-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Chief Ombudsman of Thailand and President of International Ombudsman Institute Asia Region Somsak Suwansujarit called on the Sindh Governor Kamran Khan Tessori at the Governor&#8217;s House. His wife and President of The Red Cross Chapter of Thailand&#8217;s Ryong province, Mrs Nipa, were also present in the meeting. Provincial Ombudsman Ejaz Ali Khan and Advisor to [&#8230;]

## Winter vacations for schools from Dec 22 to 31
 - [https://pakobserver.net/winter-vacations-for-schools-from-dec-22-to-31](https://pakobserver.net/winter-vacations-for-schools-from-dec-22-to-31)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-12-01T22:30:33+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/03/sindh-GOvt-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Sindh Government has announced winter vacations for all public and private educational institutions across the province with effect from December 22 to 31. According to a notification issued here on Thursday, as per the decision taken in the Steering Committee meeting, all public and private schools and educational institutions under the administrative control of the [&#8230;]

## CM Baqar okays Rs1.38b for Sindh Rangers operational equipment
 - [https://pakobserver.net/cm-baqar-okays-rs1-38b-for-sindh-rangers-operational-equipment](https://pakobserver.net/cm-baqar-okays-rs1-38b-for-sindh-rangers-operational-equipment)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-12-01T22:30:32+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/08/Justice-Baqar-named-Sindh-caretaker-CM-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />&#160; The Sindh Cabinet on Friday approved the release of Rs.1.38 billion funds for the purchase of water cannons, quick response vehicles and communication equipment for Pakistan Rangers. Caretaker Sindh Chief Minister chaired the provincial Cabinet meeting at CM house which was attended by Minister&#8217;s, Chief Secretary, Advocate General Sindh and other officers concerned. Sindh [&#8230;]

## Wahab grieved over party workers death
 - [https://pakobserver.net/wahab-grieved-over-party-workers-death](https://pakobserver.net/wahab-grieved-over-party-workers-death)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-12-01T22:30:29+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2021/01/murtaza-wahab-1-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />&#160; Mayor Karachi Barrister Murtaza Wahab has expressed deep grief over the martyrdom of Pakistan People&#8217;s Party workers from Naushero Ferozin in a traffic accident. In a statement on Friday, he said that these workers were returning after attending the foundation day &#8220;Yum-e-Tasees&#8221; when they met with the accident near Shikarpur.  Barrister Murtaza Wahab said [&#8230;]

## 11 policemen lost job for involvement in organized crimes
 - [https://pakobserver.net/11-policemen-lost-job-for-involvement-in-organized-crimes](https://pakobserver.net/11-policemen-lost-job-for-involvement-in-organized-crimes)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-12-01T22:30:25+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2022/11/karachi-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />&#160; SSP District Keamari, Arif Aslam Rao took stringent measures against officers and officials engaged in organized crimes, resulting in the dismissal of 11 individuals involved in drug-related activities, gutka/mawa, smuggling, and other criminal acts.  Following the issuance of show cause notices, an inquiry was conducted by the authorized officer, said Keamari Police spokesperson.  After [&#8230;]

## Agencies decide joint check post at Mochko
 - [https://pakobserver.net/agencies-decide-joint-check-post-at-mochko](https://pakobserver.net/agencies-decide-joint-check-post-at-mochko)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-12-01T22:30:22+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2022/11/karachi-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />The authorities have decided to establish a collaborative check post at Mochko aimed at streamlining traffic flow, curbing smuggling activities, and catering to passenger needs.   The meeting, spearheaded by DIGP &#8211; South Syed Asad Raza at the DIGP &#8211; South Office, focused on evaluating challenges in implementing this joint check post, according to a spokesman [&#8230;]

## 16th Int’l Urdu Conference unfolds insightful sessions at ACP
 - [https://pakobserver.net/16th-intl-urdu-conference-unfolds-insightful-sessions-at-acp](https://pakobserver.net/16th-intl-urdu-conference-unfolds-insightful-sessions-at-acp)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-12-01T22:27:07+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/12/WhatsApp-Image-2023-12-01-at-9.43.35-PM-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />&#160; The second day of the 16th International Urdu Conference, organized by the Arts Council of Pakistan, unfolded with a multitude of insightful sessions. The day commenced with the session &#8220;Urdu Novel K Musha&#8217;heer,&#8221; featuring discussions on the contributions of literary giants such as Khalid Akhtar, Banu Qudsiya, Abdullah Hussain, Shams ur Rehman Faruqi, Qurratulain [&#8230;]

## KTPL season 3 kicks off with colorful ceremony
 - [https://pakobserver.net/ktpl-season-3-kicks-off-with-colorful-ceremony](https://pakobserver.net/ktpl-season-3-kicks-off-with-colorful-ceremony)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-12-01T22:27:05+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2022/11/karachi-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />&#160; The Karachi Tapeball Premier League (KTPL) season 3, inaugurated by the Governor Sindh Kamran Khan Tessori at Dha Sports Club Moin Khan Academy.Defending champion DHA Dabangs and players from other teams were also present at the opening ceremony of season 3 organized by Pakistan Tapeball Foundation and Badar Expo Solutions. Governor Sindh Kamran Tessori [&#8230;]

## Sindh tourism announces New Year celebrations  at Bhambhore
 - [https://pakobserver.net/sindh-tourism-announces-new-year-celebrations-at-bhambhore](https://pakobserver.net/sindh-tourism-announces-new-year-celebrations-at-bhambhore)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-12-01T22:27:04+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/12/loogo-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />&#160; The Ministry of Tourism, Climate Change, Environment, and Coastal Development of Sindh is delighted to announce an exceptional New Year celebration at the historic and culturally rich site of Bhambhore. The event, spearheaded by the Honorable Minister Arshad Wali Muhammad, promises to blend the ancient allure of Bhambhore with the modern comfort of glamping, [&#8230;]

## Samsung Galaxy Note 20 Ultra PTA Tax, Custom Duty December 2023 update
 - [https://pakobserver.net/samsung-galaxy-note-20-ultra-pta-tax-custom-duty-december-2023-update](https://pakobserver.net/samsung-galaxy-note-20-ultra-pta-tax-custom-duty-december-2023-update)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-12-01T19:53:15+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/12/Samsung-Galaxy-Note20-Ultra-5G-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Samsung continues to dominate the smartphone market globally and in the Android region, the South Korean tech giant is no less than a pioneer, offering the finest smartphones that leave an impression and the Samsung Galaxy Note Ultra is nothing short of brilliant. The company has made its name in flagship devices, giving tough time [&#8230;]

## Pakistan records 34pc drop in trade deficit as imports tumble
 - [https://pakobserver.net/pakistan-records-34pc-drop-in-trade-deficit-as-imports-tumble](https://pakobserver.net/pakistan-records-34pc-drop-in-trade-deficit-as-imports-tumble)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-12-01T17:28:21+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/12/1381777-trade-1492060856-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Pakistan’s trade deficit has dropped by 34 percent to $9.38 billion in the first five months of Fiscal Year 2024, mainly due to significant drop in imports. Significant decrease in trade deficit in recent times eased pressure on the country’s depleting foreign exchange reserves, which remained under struggle despite inflows from the International Monetary Fund [&#8230;]

## Honda CD 70 2024 zero markup installment plans in Pakistan
 - [https://pakobserver.net/honda-cd-70-2024-zero-markup-installment-plans-in-pakistan](https://pakobserver.net/honda-cd-70-2024-zero-markup-installment-plans-in-pakistan)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-12-01T17:11:02+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/12/367778400_6455819931151872_7052206599245542470_n-2-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Honda bikes remained front runner in local two wheeler industry and Honda CD 70 2024 is king of all bikes in its league as its sales continue to top the charts despite the prices of Japanese automaker touching the roof amid an economic crisis. The entry-level bike comes with a robust build and adequate performance, [&#8230;]

## Suzuki Mehran price in Pakistan December 2023
 - [https://pakobserver.net/suzuki-mehran-price-in-pakistan-december-2023](https://pakobserver.net/suzuki-mehran-price-in-pakistan-december-2023)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-12-01T15:33:00+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/12/suzuki-mehran-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Amid the presence of latest sedans and SUVs in major cities like Karachi and Lahore, Mehran is still spotted despite being discontinued for years, as the people in the country hold deep relationship with the iconic 800cc car. Pakistan’s oldest automakers introduced the car with only basic features, and people still rely on it for [&#8230;]

## Weather outlook of Lahore Punjab; fog may cause Motorway closure
 - [https://pakobserver.net/weather-outlook-of-lahore-punjab-fog-may-cause-motorway-closure](https://pakobserver.net/weather-outlook-of-lahore-punjab-fog-may-cause-motorway-closure)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-12-01T15:00:44+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/11/fog-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />LAHORE – The Pakistan Meteorological Department (PMD) has forecast mainly cold and dry weather for Lahore and most parts of Punjab during the next two days. According to the synoptic situation, continental air prevails over most parts of Pakistan. A westerly wave is still affecting northern parts of the country. Under these conditions, cold and [&#8230;]

## Has Jannat Mirza tied the knot in a private wedding ceremony?
 - [https://pakobserver.net/has-jannat-mirza-tied-the-knot-in-a-private-wedding-ceremony](https://pakobserver.net/has-jannat-mirza-tied-the-knot-in-a-private-wedding-ceremony)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-12-01T14:45:16+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/12/hh2-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />LAHORE &#8211; Pakistani TikToker Jannat Mirza remained in the limelight all the time, keeping admirers on their toes. The social media sensation earlier ended a relationship with another TikToker Umar Butt, and is reportedly enjoying her time being single. Lately, a clip of the TikToker is doing rounds online, showing Jannat in an extravagant wedding [&#8230;]

## Islamabad, Pakistan weather update for weekend
 - [https://pakobserver.net/islamabad-pakistan-weather-update-for-weekend](https://pakobserver.net/islamabad-pakistan-weather-update-for-weekend)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-12-01T14:34:02+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/09/FM-1-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />ISLAMABAD – The Pakistan Meteorological Department (PMD) has forecast mainly cold and dry weather for Islamabad, Rawalpindi and most parts of Pakistan during weekend. According to the synoptic situation, continental air prevails over most parts of Pakistan. A westerly wave is still affecting northern parts of the country. Under these conditions, cold and dry weather [&#8230;]

## Karachi Tape-Ball Premier League Season 3 begins
 - [https://pakobserver.net/karachi-tape-ball-premier-league-season-3-begins](https://pakobserver.net/karachi-tape-ball-premier-league-season-3-begins)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-12-01T14:10:48+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/12/KTPL-150x150.png" style="display: block; margin-bottom: 5px; clear: both;" width="150" />KARACHI &#8211; The highly anticipated Karachi Tape-Ball Premier League (KTPL) Season Three kicked off at the DHA Sports Club Moin Khan Academy. The inaugural match witnessed an intense showdown between defending champions DHA Dabanggs and Clifton Popular teams. Adding an extra layer of excitement, a celebratory match between Chief Minister Sindh XI and KTPL XI [&#8230;]

## Pakistan’s policies lack mechanisms to curtail hazardous pollution levels
 - [https://pakobserver.net/pakistans-policies-lack-mechanisms-to-curtail-hazardous-pollution-levels](https://pakobserver.net/pakistans-policies-lack-mechanisms-to-curtail-hazardous-pollution-levels)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-12-01T13:17:12+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/12/pollution-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />ISLAMABAD – Pakistan’s clean air policies lack mechanism to curtail hazardous pollution levels, reveals a report released by the Centre for Research on Energy and Clean Air (CREA). In March 2023, Pakistan introduced the National Clean Air Policy (NCAP) and followed up with the Punjab Clean Air Plan (PbCAP) in April. Upon review, CREA found [&#8230;]

## Pakistani rupee’s upwards march against dollar continues amid strong economic cues
 - [https://pakobserver.net/pakistani-rupees-upwards-march-against-dollar-continues-amid-strong-economic-cues](https://pakobserver.net/pakistani-rupees-upwards-march-against-dollar-continues-amid-strong-economic-cues)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-12-01T12:59:53+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/12/Paksitani-Rupee-Dollar-Smk-mojo-222-pakistan-1-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />KARACHI – Pakistan has witnessed continuous rupee recovery and marked improvement in the stock market as positive economic indicators have shown results. Data shared by the central bank shows rupee marching up against greenback for fourth successive session as PKR appreciated 0.07pc in the inter-bank market. The local currency on Friday settled at 284.97, with [&#8230;]

## SBP releases annual report on bank deposit protection
 - [https://pakobserver.net/sbp-releases-annual-report-on-bank-deposit-protection](https://pakobserver.net/sbp-releases-annual-report-on-bank-deposit-protection)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-12-01T12:30:08+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/08/SBPR-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />KARACHI &#8211; The Deposit Protection Corporation (DPC), a subsidiary of the State Bank of Pakistan, has released its third Annual Report for the year 2022-23 with objective to enhance awareness among bank depositors and general public regarding protection of deposits of its member banks. The Annual Report emphasizes DPC&#8217;s unwavering commitment to safeguarding depositors&#8217; funds, [&#8230;]

## Punjab announces holiday in schools on Saturday amid measures to tackle toxic smog
 - [https://pakobserver.net/punjab-announces-holiday-in-schools-on-saturday-amid-measures-to-tackle-toxic-smog](https://pakobserver.net/punjab-announces-holiday-in-schools-on-saturday-amid-measures-to-tackle-toxic-smog)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-12-01T12:23:07+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/12/6301556-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />LAHORE &#8211; Authorities in Punjab are taking extreme steps amid alarming levels of smog pollution, and the now interim government has decided to shut down schools, and other educational institutions. The Saturday holiday in schools is the latest in series of steps to protect children from alarming air pollution. Punjab Interim Chief Minister Mohsin Naqvi [&#8230;]

## LDA clears parking spaces in commercial areas of Lahore
 - [https://pakobserver.net/lda-clears-parking-spaces-in-commercial-areas-of-lahore](https://pakobserver.net/lda-clears-parking-spaces-in-commercial-areas-of-lahore)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-12-01T11:51:17+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/12/parking-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />LAHORE – Lahore Development Authority (LDA) on Friday removed permanent and temporary encroachments from designated parking spaces in commercial areas of Lahore. Joint teams of LDA and Traffic Engineering and Transport Planning Agency (TEPA) cleared parking spaces outside several plazas on Jail Road. کمشنر و ڈی جی ایل ڈی اے محمد علی رندھاوا @RandhawaAli کی [&#8230;]

## Suzuki shuts motorcycle plant in Pakistan as sales slump
 - [https://pakobserver.net/suzuki-shuts-motorcycle-plant-in-pakistan-as-sales-slump](https://pakobserver.net/suzuki-shuts-motorcycle-plant-in-pakistan-as-sales-slump)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-12-01T11:12:21+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/12/Capture6-e1654163395111-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />KARACHI – Pak Suzuki Motor Company has closed its motorcycle manufacturing facility in the absence of required parts and amid slowdown in sales. Pakistan’s auto industry is in dire straits in the wake of an unfavourable operating environment and low demand for brand new vehicles due to huge surge in prices. Amid the current situation, [&#8230;]

## Gold loses some of its glitter in Pakistan; Check latest rates
 - [https://pakobserver.net/gold-loses-some-of-its-glitter-in-pakistan-check-latest-rates](https://pakobserver.net/gold-loses-some-of-its-glitter-in-pakistan-check-latest-rates)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-12-01T10:08:31+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/10/gold6-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />KARACHI – Gold saw a slight decline in Pakistan on Friday after it registered significant gains earlier this week. An association of gold jewellers said the price of the precious commodity fell by Rs500 per tola to reach Rs220,500 while the price for the 10-graim gold dropped to Rs189,043 after a decline of Rs429. The [&#8230;]

## Caretaker PM arrives at Dubai Expo City to take part in COP28 summit
 - [https://pakobserver.net/caretaker-pm-arrives-at-dubai-expo-city-to-take-part-in-cop28-summit](https://pakobserver.net/caretaker-pm-arrives-at-dubai-expo-city-to-take-part-in-cop28-summit)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-12-01T09:01:55+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/12/PM-for-COP-28-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />DUBAI- Caretaker Prime Minister Anwaar-ul-Haq Kakar has arrived at Dubai Expo City to participate in the high-level segment of the 28th Conference of the Parties (COP 28) of the United Nations. The Prime Minister was received by President of the United Arab Emirates Sheikh Mohamed bin Zayed Al Nahyan and the Secretary General of the [&#8230;]

## Fresh attacks in Gaza as Israel resumes operations post-truce
 - [https://pakobserver.net/fresh-attacks-in-gaza-as-israel-resumes-operations-post-truce](https://pakobserver.net/fresh-attacks-in-gaza-as-israel-resumes-operations-post-truce)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-12-01T08:52:29+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/12/Gaza-under-attack-150x150.png" style="display: block; margin-bottom: 5px; clear: both;" width="150" />GAZA-  The heavy clashes erupted on Friday as Israel&#8217;s military resumed combat operations against Hamas, alleging a breach of a temporary truce with rocket fire toward Israeli territory. The seven-day pause, extended twice, allowed for the exchange of hostages and facilitated the entry of humanitarian aid into the beleaguered coastal strip. Prior to the truce&#8217;s [&#8230;]

## Pakistan U19 squad announced for ACC U19 Asia Cup 2023
 - [https://pakobserver.net/pakistan-u19-squad-announced-for-acc-u19-asia-cup-2023](https://pakobserver.net/pakistan-u19-squad-announced-for-acc-u19-asia-cup-2023)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-12-01T08:43:36+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/12/U19-squad-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />LAHORE- Saad Baig will continue to lead Pakistan U19 in the ACC U19 Asia Cup 2023 set to take place in Dubai. The junior selection committee, headed by Sohail Tanvir, has finalised the 15-member squad for the eight-team tournament scheduled from 8 to 17 December. Saad Baig, who captained the Pakistan U19 team in the [&#8230;]

## PCB appoints Kamran Akmal, Rao Iftikhar and Salman Butt Butt as consultants
 - [https://pakobserver.net/pcb-appoints-kamran-akmal-rao-iftikhar-and-salman-butt-butt-as-consultants](https://pakobserver.net/pcb-appoints-kamran-akmal-rao-iftikhar-and-salman-butt-butt-as-consultants)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-12-01T08:41:07+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/12/consultants-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />LAHORE- The PCB has confirmed the appointment of former Pakistan cricketers Kamran Akmal, Rao Iftikhar Anjum and Salman Butt as consultant members to chief selector Wahab Riaz. The three have assumed their responsibilities in the selection panel with immediate effect. Their first assignment as consultant members to the chief selector includes the upcoming five-match T20I [&#8230;]

## Honda 125 2024 latest price in Pakistan December 2023
 - [https://pakobserver.net/honda-125-2024-latest-price-in-pakistan-december-2023](https://pakobserver.net/honda-125-2024-latest-price-in-pakistan-december-2023)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-12-01T08:20:03+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/12/hond4-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Honda CG 125 continues to hold strong share in motorcycle market of Pakistan due to its vibrant looks and efficiency despite launch of two-wheelers by competitor companies. Honda CG 125 2024’s design is smooth as it produces upright aerodynamics for a quick pace. Its aesthetics and robust performance are no less than a craze as [&#8230;]

## Nadra new smart ID card fee update December 2023
 - [https://pakobserver.net/nadra-new-smart-id-card-fee-update-december-2023](https://pakobserver.net/nadra-new-smart-id-card-fee-update-december-2023)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-12-01T07:13:26+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/12/nadr-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />LAHORE &#8211; New Smart National Identity Card (NIC) is issued to the citizens of Pakistan by the National Registration and Database Authority (Nadra). The unique 13 digit identification number is recognised all over the country. It is the first requirement of individuals as it is mandatory to obtain documents like license, NTN, bank account, passport, [&#8230;]

## LPG prices go up in Pakistan for December 2023
 - [https://pakobserver.net/lpg-prices-go-up-in-pakistan-for-december-2023](https://pakobserver.net/lpg-prices-go-up-in-pakistan-for-december-2023)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-12-01T06:43:53+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/12/lpg-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />ISLAMABAD – The Oil and Gas Regulatory Authority (OGRA) has increase the price of Liquefied Petroleum Gas (LPG) by Rs3.82 per kg to Rs255 per kg for December 2023. A notification issued by the authority said that the price of 11.8 kg domestic cylinder has been increase by Rs45.18 to Rs3,097.35 for December compared to [&#8230;]

## UAE visa protector fee in Pakistan December 2023 update
 - [https://pakobserver.net/uae-visa-protector-fee-in-pakistan-december-2023-update](https://pakobserver.net/uae-visa-protector-fee-in-pakistan-december-2023-update)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-12-01T06:18:15+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/11/protector-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />LAHORE – Pakistani citizens intending to go abroad, including the United Arab Emirates (UAE), on a work visa are legally bound to get their foreign employment agreement protected from the concerned Protectorate of Emigrants (PE) office. After paying OPF, registration, life insurance and OEC fee, the department imposed a protector stamp on the applicant’s passport [&#8230;]

## When will winter vacation 2023 for schools start in Punjab? Check latest update
 - [https://pakobserver.net/when-will-winter-vacation-2023-for-schools-start-in-punjab-check-latest-update](https://pakobserver.net/when-will-winter-vacation-2023-for-schools-start-in-punjab-check-latest-update)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2023-12-01T05:58:57+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/12/punjab-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />LAHORE &#8211; The Punjab government has announced the schedule for winter vacations for all public and private schools across the province. Punjab caretaker Chief Minister Mohsin Naqvi made the announcement, adding that there would be no restrictions in the upcoming week due to improved air quality. Winter Holidays in Punjab 2023 The chief minister took [&#8230;]

