# Source:Colombia News | Colombia Reports, URL:https://colombiareports.com/feed/, language:en-US

## Colombia’s constitutional court signs off on Petro’s peace policy
 - [https://colombiareports.com/colombias-constitutional-court](https://colombiareports.com/colombias-constitutional-court)
 - RSS feed: https://colombiareports.com/feed/
 - date published: 2023-12-01T14:32:35+00:00

<p>Colombia&#8217;s constitutional court has rejected a far-right appeal to sink the peace policy of President Gustavo Petro. The court did impose limits on Petro&#8217;s &#8220;Total Peace&#8221; policy to prevent abuses&#8230;</p>
<p>The post <a href="https://colombiareports.com/colombias-constitutional-court/" rel="nofollow">Colombia&#8217;s constitutional court signs off on Petro&#8217;s peace policy</a> appeared first on <a href="https://colombiareports.com" rel="nofollow">Colombia News | Colombia Reports</a>.</p>

