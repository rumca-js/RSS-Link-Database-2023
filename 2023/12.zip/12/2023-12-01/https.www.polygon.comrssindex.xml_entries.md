# Source:Polygon -  All, URL:https://www.polygon.com/rss/index.xml, language:en

## Candy Cane Lane, Netflix’s May December, and every new movie to watch this weekend
 - [https://www.polygon.com/2023/12/1/23977722/new-movies-candy-cane-lane-eddie-murphy-christmas-netflix-may-december-indiana-jones-dial-of-destiny](https://www.polygon.com/2023/12/1/23977722/new-movies-candy-cane-lane-eddie-murphy-christmas-netflix-may-december-indiana-jones-dial-of-destiny)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-12-01T23:15:00+00:00

<figure>
      <img alt="Eddie Murphy in a cheery Christmas sweater" src="https://cdn.vox-cdn.com/thumbor/kZuyt__Kzi03UFkHjMOyf9niRWM=/0x0:3900x2194/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72922269/unnamed.0.jpg" />
        <figcaption>Image: Prime Video</figcaption>
    </figure>

  <p>Eddie Murphy has a new Christmas movie!</p>
  <p>
    <a href="https://www.polygon.com/2023/12/1/23977722/new-movies-candy-cane-lane-eddie-murphy-christmas-netflix-may-december-indiana-jones-dial-of-destiny">Continue reading&hellip;</a>
  </p>

## The best Wizard subclass, feats, and build in Baldur’s Gate 3
 - [https://www.polygon.com/baldurs-gate-3-guides/23814037/wizard-class-subclasses-stats-features-proficiencies](https://www.polygon.com/baldurs-gate-3-guides/23814037/wizard-class-subclasses-stats-features-proficiencies)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-12-01T22:53:03+00:00

<figure>
      <img alt="Baldur’s Gate 3 Wizard emblem over a grey tone backdrop." src="https://cdn.vox-cdn.com/thumbor/pFTeA-IR-Ne2qIeKXLMzGfqYzHE=/0x0:1920x1080/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72510625/Baldurs_Gate_3_Classes_Wizard.0.png" />
        <figcaption>Graphic: Jeffrey Parkin/Polygon | Source images: Larian Studios via Polygon</figcaption>
    </figure>

  <p>Let’s spell this out</p>
  <p>
    <a href="https://www.polygon.com/baldurs-gate-3-guides/23814037/wizard-class-subclasses-stats-features-proficiencies">Continue reading&hellip;</a>
  </p>

## The best Warlock subclass, feats, and build in Baldur’s Gate 3
 - [https://www.polygon.com/baldurs-gate-3-guides/23814020/warlock-class-subclasses-stats-features-proficiencies](https://www.polygon.com/baldurs-gate-3-guides/23814020/warlock-class-subclasses-stats-features-proficiencies)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-12-01T22:53:00+00:00

<figure>
      <img alt="Warlock icon from Baldur’s Gate 3 over a grey tone backdrop." src="https://cdn.vox-cdn.com/thumbor/7x0Gh_ledEFNLTax9u4PnHgOttM=/0x0:1920x1080/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72510631/Baldurs_Gate_3_Classes_Warlock.0.png" />
        <figcaption>Graphic: Jeffrey Parkin | Source images: Larian Studios via Polygon</figcaption>
    </figure>

  <p>How to make a pact with demons</p>
  <p>
    <a href="https://www.polygon.com/baldurs-gate-3-guides/23814020/warlock-class-subclasses-stats-features-proficiencies">Continue reading&hellip;</a>
  </p>

## The best Sorcerer subclass, feats, and build in Baldur’s Gate 3
 - [https://www.polygon.com/baldurs-gate-3-guides/23814031/sorcerer-class-subclasses-stats-features-proficiencies](https://www.polygon.com/baldurs-gate-3-guides/23814031/sorcerer-class-subclasses-stats-features-proficiencies)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-12-01T22:52:57+00:00

<figure>
      <img alt="Sorcerer class emblem from Baldur’s Gate 3 over a grey tone backdrop." src="https://cdn.vox-cdn.com/thumbor/r3KQkaYqSvjS3QJHhuNyDxawsgQ=/0x0:1920x1080/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72510639/Baldurs_Gate_3_Classes_Sorcerer.0.png" />
        <figcaption>Graphic: Jeffrey Parkin | Source images: Larian Studios via Polygon</figcaption>
    </figure>

  <p>Casting call for magicians...</p>
  <p>
    <a href="https://www.polygon.com/baldurs-gate-3-guides/23814031/sorcerer-class-subclasses-stats-features-proficiencies">Continue reading&hellip;</a>
  </p>

## The best Paladin subclass, feats, and build in Baldur’s Gate 3
 - [https://www.polygon.com/baldurs-gate-3-guides/23811265/paladin-class-subclasses-stats-features-proficiencies](https://www.polygon.com/baldurs-gate-3-guides/23811265/paladin-class-subclasses-stats-features-proficiencies)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-12-01T22:52:53+00:00

<figure>
      <img alt="Baldur’s Gate 3 Paladin emblem over a grey tone backdrop." src="https://cdn.vox-cdn.com/thumbor/7X8C5GGKnS_m_j1J8LTvdlZ4XYY=/0x0:1920x1080/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72510614/Baldurs_Gate_3_Classes_Paladin.0.png" />
        <figcaption>Graphic: Jeffrey Parkin/Polygon | Source images: Larian Studios via Polygon</figcaption>
    </figure>

  <p>Break a vow</p>
  <p>
    <a href="https://www.polygon.com/baldurs-gate-3-guides/23811265/paladin-class-subclasses-stats-features-proficiencies">Continue reading&hellip;</a>
  </p>

## The best Ranger subclass, feats, and build in Baldur’s Gate 3
 - [https://www.polygon.com/baldurs-gate-3-guides/23814026/ranger-class-subclasses-stats-features-proficiencies](https://www.polygon.com/baldurs-gate-3-guides/23814026/ranger-class-subclasses-stats-features-proficiencies)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-12-01T22:52:50+00:00

<figure>
      <img alt="Baldur’s Gate 3 Ranger emblem over a grey tone back drop." src="https://cdn.vox-cdn.com/thumbor/mA04-TZCKkSNKzJgKPv92X6GVUk=/0x0:1920x1080/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72510616/Baldurs_Gate_3_Classes_Ranger.0.png" />
        <figcaption>Graphic: Jeffrey Parkin/Polygon | Source images: Larian Studios via Polygon</figcaption>
    </figure>

  <p>Hit your mark</p>
  <p>
    <a href="https://www.polygon.com/baldurs-gate-3-guides/23814026/ranger-class-subclasses-stats-features-proficiencies">Continue reading&hellip;</a>
  </p>

## The best Rogue subclass, feats, and build in Baldur’s Gate 3
 - [https://www.polygon.com/baldurs-gate-3-guides/23814036/rogue-class-subclasses-stats-features-proficiencies](https://www.polygon.com/baldurs-gate-3-guides/23814036/rogue-class-subclasses-stats-features-proficiencies)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-12-01T22:52:45+00:00

<figure>
      <img alt="Baldur’s Gate 3 Rogue emblem over a grey tone backdrop." src="https://cdn.vox-cdn.com/thumbor/Flw-AQuCfRRSzxyVN22CoV6_nqk=/0x0:1920x1080/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72510634/Baldurs_Gate_3_Classes_Rogue.0.png" />
        <figcaption>Graphic: Jeffrey Parkin/Polygon | Source images: Larian Studios via Polygon</figcaption>
    </figure>

  <p>Who’s ready to join the gallery?</p>
  <p>
    <a href="https://www.polygon.com/baldurs-gate-3-guides/23814036/rogue-class-subclasses-stats-features-proficiencies">Continue reading&hellip;</a>
  </p>

## Street Fighter 6’s great new costumes are being sold in the worst way
 - [https://www.polygon.com/23984737/street-fighter-6-costume-dlc-outfit-3-pricing](https://www.polygon.com/23984737/street-fighter-6-costume-dlc-outfit-3-pricing)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-12-01T22:45:00+00:00

<figure>
      <img alt="Marisa poses in her new wedding dress costume from Street Fighter 6" src="https://cdn.vox-cdn.com/thumbor/C4_zzqE2jQWjAUYuzKXswkwBKv4=/0x0:1920x1080/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72922155/marisa_Outfit_3_SF6.0.jpg" />
        <figcaption>Image: Capcom</figcaption>
    </figure>

  <p>It’s an old tactic, but an annoying one</p>
  <p>
    <a href="https://www.polygon.com/23984737/street-fighter-6-costume-dlc-outfit-3-pricing">Continue reading&hellip;</a>
  </p>

## The GTA 6 trailer tease is already meme fodder
 - [https://www.polygon.com/23984755/gta-6-grand-theft-auto-trailer-announcement-memes](https://www.polygon.com/23984755/gta-6-grand-theft-auto-trailer-announcement-memes)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-12-01T22:15:00+00:00

<figure>
      <img alt="A teaser image for GTA 6’s Trailer 1 and the text ‘Tuesday, December 5, 9am ET’ on an orange and pink sky with palm trees either side" src="https://cdn.vox-cdn.com/thumbor/ukj70PEXjAP_Ep_N92MLR-mqU3k=/6x309:1074x910/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72922125/gta_6_trailer_teaser.0.jpg" />
        <figcaption>Image: Rockstar Games</figcaption>
    </figure>

  <p>Is the Grand Theft Auto 6 sunset the new Cyberpunk 2077 yellow banner?</p>
  <p>
    <a href="https://www.polygon.com/23984755/gta-6-grand-theft-auto-trailer-announcement-memes">Continue reading&hellip;</a>
  </p>

## Zelda: Tears of the Kingdom player remakes an entire Godzilla movie in the game
 - [https://www.polygon.com/legend-zelda-tears-kingdom/23984473/zelda-totk-tears-of-the-kingdom-godzilla-movie](https://www.polygon.com/legend-zelda-tears-kingdom/23984473/zelda-totk-tears-of-the-kingdom-godzilla-movie)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-12-01T22:00:00+00:00

<figure>
      <img alt="An image of a monster built with Zonai devices in The Legend of Zelda: Tears of the Kingdom. The mosnter has been built to resemble Godzilla. It’s breathing fire. " src="https://cdn.vox-cdn.com/thumbor/zFyqTcShpl1RFu3Zw7JsJp9eqHs=/0x0:1280x720/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72922060/vlcsnap_2023_12_01_13h52m28s908.0.jpg" />
        <figcaption>Image: <a class="ql-link" href="https://twitter.com/sumoguri2323/status/1727626043933213155" target="_blank">Sumoguri2323</a>/X</figcaption>
    </figure>

  <p>“We have Godzilla at home.” The Godzilla at home...</p>
  <p>
    <a href="https://www.polygon.com/legend-zelda-tears-kingdom/23984473/zelda-totk-tears-of-the-kingdom-godzilla-movie">Continue reading&hellip;</a>
  </p>

## How I learned to love Stardew Valley’s terrible fishing
 - [https://www.polygon.com/videos/2023/12/1/23984614/stardew-valley-fishing-ernest-hemingway-video](https://www.polygon.com/videos/2023/12/1/23984614/stardew-valley-fishing-ernest-hemingway-video)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-12-01T21:45:00+00:00

<figure>
      <img alt="A Stardew Valley character modeled after Ernest Hemingway fishes at the end of the dock. Superimposed over that image is an Animal Crossing: New Horizons character based on Simone, a white woman with brown hair. She is holding a fish." src="https://cdn.vox-cdn.com/thumbor/zGZgITsm1A243o_b6WbovUME5-Q=/0x0:1920x1080/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72922020/FishinNoText.0.jpg" />
        <figcaption>Image: Polygon</figcaption>
    </figure>

  <p>With a little help from a famous writer</p>
  <p>
    <a href="https://www.polygon.com/videos/2023/12/1/23984614/stardew-valley-fishing-ernest-hemingway-video">Continue reading&hellip;</a>
  </p>

## GTA 6 better let me play jai alai
 - [https://www.polygon.com/2023/12/1/23984619/gta-6-sport-jai-alai-miami-crime-gambling](https://www.polygon.com/2023/12/1/23984619/gta-6-sport-jai-alai-miami-crime-gambling)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-12-01T21:30:00+00:00

<figure>
      <img alt="A jai alai player in white pants and blue jersey, reaches out with a hook shaped basket on his right arm as he tries to catch a ball." src="https://cdn.vox-cdn.com/thumbor/QOZ3N34h5BVd3j9d1deJWrh9o9Y=/0x157:3048x1872/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72921933/GettyImages_110162417.0.jpg" />
        <figcaption>Gamma-Rapho via Getty Images</figcaption>
    </figure>

  <p>My cesta is ready</p>
  <p>
    <a href="https://www.polygon.com/2023/12/1/23984619/gta-6-sport-jai-alai-miami-crime-gambling">Continue reading&hellip;</a>
  </p>

## The feel-good Humble bundle of the year just dropped, containing Venba, Tinykin, and more for $20
 - [https://www.polygon.com/deals/23984685/humble-bundle-venba-tinykin-bear-breakfast-wylde-flowers](https://www.polygon.com/deals/23984685/humble-bundle-venba-tinykin-bear-breakfast-wylde-flowers)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-12-01T21:20:00+00:00

<figure>
      <img alt="" src="https://cdn.vox-cdn.com/thumbor/FtAXwbwCRXUthYawjZ4w7ec4RvM=/0x240:3840x2400/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72921891/ss_1125d6b351ce8ca38f74cba1ae923b7b736f4c88.0.jpg" />
    </figure>

  <p>Containing Venba, Tinykin, Bear and Breakfast, and more goodness for $20</p>
  <p>
    <a href="https://www.polygon.com/deals/23984685/humble-bundle-venba-tinykin-bear-breakfast-wylde-flowers">Continue reading&hellip;</a>
  </p>

## Forza Motorsport, Halo Infinite QA workers vote to unionize
 - [https://www.polygon.com/23984683/forza-motorsport-halo-infinite-qa-workers-union-yes](https://www.polygon.com/23984683/forza-motorsport-halo-infinite-qa-workers-union-yes)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-12-01T21:17:32+00:00

<figure>
      <img alt="two sports cars rounding a corner in Forza Motorsport on Xbox Series X" src="https://cdn.vox-cdn.com/thumbor/fIw_wiAvhO63uE8CMcN7G8psPtk=/0x0:1920x1080/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72921862/forza_motorsport_xbox_series_x_1920.0.png" />
        <figcaption>Image: Turn 10 Studios/Xbox Game Studios</figcaption>
    </figure>

  <p>Experis Game Solutions workers in Milwaukee voted 35 to 4</p>
  <p>
    <a href="https://www.polygon.com/23984683/forza-motorsport-halo-infinite-qa-workers-union-yes">Continue reading&hellip;</a>
  </p>

## It doesn’t matter when Furiosa takes place in the Mad Max timeline
 - [https://www.polygon.com/23984150/furiosa-mad-max-timeline-trailer-continuity](https://www.polygon.com/23984150/furiosa-mad-max-timeline-trailer-continuity)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-12-01T21:00:00+00:00

<figure>
      <img alt="Chris Hemsworth standing in the desert in front of a motorcycle with his shirt open  and a weapon in his hand in Furiosa" src="https://cdn.vox-cdn.com/thumbor/sdq5xWXsphHbKULjg0KM-N1zaak=/0x0:1800x1013/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72921812/FUR_38358rv2.0.jpg" />
        <figcaption>Photo: Jasin Boland/Warner Bros.</figcaption>
    </figure>

  <p>George Miller doesn’t care — and neither should you</p>
  <p>
    <a href="https://www.polygon.com/23984150/furiosa-mad-max-timeline-trailer-continuity">Continue reading&hellip;</a>
  </p>

## No one can escape the Josh Hutcherson ‘Whistle’ edit
 - [https://www.polygon.com/23984032/josh-hutcherson-whistle-edit-meme-trend-explained](https://www.polygon.com/23984032/josh-hutcherson-whistle-edit-meme-trend-explained)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-12-01T20:45:00+00:00

<figure>
      <img alt="A photo of Josh Hutcherson. It has a Ken Burns effect filter and he’s leaning back with his hands behind his head. It’s shown in the viral meme edit set to Whistle." src="https://cdn.vox-cdn.com/thumbor/taREzeGwanDsFgcKr5Vgplo0jwM=/37x17:1884x1056/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72921758/vlcsnap_2023_12_01_10h37m31s394.0.jpg" />
        <figcaption>Image: YouTube/<a class="ql-link" href="https://www.youtube.com/@MetroGirlzStation" target="_blank">MetroGirlzStation</a></figcaption>
    </figure>

  <p>It’s honestly so iconic </p>
  <p>
    <a href="https://www.polygon.com/23984032/josh-hutcherson-whistle-edit-meme-trend-explained">Continue reading&hellip;</a>
  </p>

## Cyberpunk 2077’s upcoming patch will finally add a metro system
 - [https://www.polygon.com/23984616/cyberpunk-2077-new-patch-2-1-update-metro-system](https://www.polygon.com/23984616/cyberpunk-2077-new-patch-2-1-update-metro-system)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-12-01T20:30:00+00:00

<figure>
      <img alt="A bunch of vaguely futuristic passengers ride in a subway car." src="https://cdn.vox-cdn.com/thumbor/5HTnC9sOKBkNkBiPIQkqRsNCEFo=/0x0:1920x1080/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72921683/cyberpunk2077_metro_crop.0.jpg" />
        <figcaption>Image: CD Projekt Red</figcaption>
    </figure>

  <p>Experience the wonders of Night City’s public transportation</p>
  <p>
    <a href="https://www.polygon.com/23984616/cyberpunk-2077-new-patch-2-1-update-metro-system">Continue reading&hellip;</a>
  </p>

## NSYNC convinced me to watch all the Trolls movies
 - [https://www.polygon.com/23982971/nsync-reunion-trolls-band-together-better-place](https://www.polygon.com/23982971/nsync-reunion-trolls-band-together-better-place)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-12-01T19:38:37+00:00

<figure>
      <img alt="Branch the troll (voiced by Justin Timberlake), a felty blue-skinned animated dude with a shock of vertical dark blue hair, makes meaningful eye contact with the camera and smugly offers his hand to you, the audience member he is trying to lure into his world in the animated movie Trolls Band Together" src="https://cdn.vox-cdn.com/thumbor/FaIB-B4-dI0csiwfJmrtbJPljBs=/461x0:3128x1500/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72921472/10E51_T2P_00097.0.jpg" />
        <figcaption>Image: Universal Pictures</figcaption>
    </figure>


  		<p>The band’s reunion with Justin Timberlake for ‘Better Place’ hooked me hard</p>
  <p>
    <a href="https://www.polygon.com/23982971/nsync-reunion-trolls-band-together-better-place">Continue reading&hellip;</a>
  </p>

## Lofi Girl now has chill beats to play chess to
 - [https://www.polygon.com/23978495/lofi-girl-beats-to-play-chess-to](https://www.polygon.com/23978495/lofi-girl-beats-to-play-chess-to)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-12-01T18:16:38+00:00

<figure>
      <img alt="Lo-fi girl playing chess on a laptop as her orange cat looks on." src="https://cdn.vox-cdn.com/thumbor/eb0NLOu4JmudzAxzmKNXbExESgw=/0x0:1920x1080/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72921029/Screenshot__11_.0.png" />
        <figcaption>Image: Lo-fi Girl</figcaption>
    </figure>

  <p>The Lofi empire is expanding </p>
  <p>
    <a href="https://www.polygon.com/23978495/lofi-girl-beats-to-play-chess-to">Continue reading&hellip;</a>
  </p>

## Pokémon Go ‘Eggs-pedition Access: December’ Timed Research steps, and is it worth it?
 - [https://www.polygon.com/pokemon-go-guide/2023/12/1/23984183/eggs-pedition-access-december-timed-research-worth-it](https://www.polygon.com/pokemon-go-guide/2023/12/1/23984183/eggs-pedition-access-december-timed-research-worth-it)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-12-01T17:52:52+00:00

<figure>
      <img alt="Gible roars surrounded by Pokémon Go gifts and Incubators" src="https://cdn.vox-cdn.com/thumbor/hBsLVqvhgSbtzEekrIN6NbRezEg=/166x165:1313x810/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72920910/unnamed__1_.0.jpg" />
        <figcaption>Image: Niantic</figcaption>
    </figure>

  <p>Should you buy the month-long ticket?</p>
  <p>
    <a href="https://www.polygon.com/pokemon-go-guide/2023/12/1/23984183/eggs-pedition-access-december-timed-research-worth-it">Continue reading&hellip;</a>
  </p>

## Waluigi creator reveals scrapped ‘Bad Peach’ designs — behold Wapeach
 - [https://www.polygon.com/23984146/nintendo-wapeach-design-waluigi-creator-mario-tennis](https://www.polygon.com/23984146/nintendo-wapeach-design-waluigi-creator-mario-tennis)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-12-01T17:27:12+00:00

<figure>
      <img alt="Altered artwork of Princess Peach from Super Mario 3D World, with its hue altered to be more purple" src="https://cdn.vox-cdn.com/thumbor/lsBf13Pu7ncBfMj-jsHBeyldpWs=/0x0:1920x1080/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72920835/wa_princess_peach.0.jpg" />
        <figcaption>This is not Wapeach. | Image: Nintendo via Polygon</figcaption>
    </figure>

  <p>Wapeach <strong>is</strong> real, <strong>can</strong> hurt you</p>
  <p>
    <a href="https://www.polygon.com/23984146/nintendo-wapeach-design-waluigi-creator-mario-tennis">Continue reading&hellip;</a>
  </p>

## Baldur’s Gate 3’s new patch makes a fan-favorite character canon
 - [https://www.polygon.com/23984165/baldurs-gate-3-patch-bing-bong-canon-dick-physics](https://www.polygon.com/23984165/baldurs-gate-3-patch-bing-bong-canon-dick-physics)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-12-01T17:19:06+00:00

<figure>
      <img alt="Shadowheart wears a new outfit, which includes a purple top and a cool jacket." src="https://cdn.vox-cdn.com/thumbor/iuJ-hVeP7dRguqFt_ueEwuLXV0M=/0x0:3840x2160/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72920823/shadowheart_new_outfit.0.jpeg" />
        <figcaption>Image: Larian Studios</figcaption>
    </figure>

  <p>Bing Bong, you ‘darling, sweet imp’</p>
  <p>
    <a href="https://www.polygon.com/23984165/baldurs-gate-3-patch-bing-bong-canon-dick-physics">Continue reading&hellip;</a>
  </p>

## The Halo TV show is going free-to-play in hopes you’ll watch season 2
 - [https://www.polygon.com/23984110/halo-tv-show-season-2-releaes-date-free-youtube](https://www.polygon.com/23984110/halo-tv-show-season-2-releaes-date-free-youtube)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-12-01T16:09:07+00:00

<figure>
      <img alt="Master Chief (Pablo Schreiber) with a bloodied uniform in Halo." src="https://cdn.vox-cdn.com/thumbor/M1DcDtMlqWzPJXcJAOqnct7cdOs=/0x0:3000x1688/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72920519/Halo_106_1872_RT.0.jpg" />
        <figcaption>Photo: Adrienn Szabo/Paramount Plus</figcaption>
    </figure>

  <p>On Halo’s natural home: YouTube</p>
  <p>
    <a href="https://www.polygon.com/23984110/halo-tv-show-season-2-releaes-date-free-youtube">Continue reading&hellip;</a>
  </p>

## Fortnite’s Family Guy saga may finally be coming to an end
 - [https://www.polygon.com/23984003/fortnite-big-bang-family-guy-peter-griffin-leak](https://www.polygon.com/23984003/fortnite-big-bang-family-guy-peter-griffin-leak)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-12-01T15:57:38+00:00

<figure>
      <img alt="Peter Griffin points excitedly toward a window in his house in a still from Family Guy season 15" src="https://cdn.vox-cdn.com/thumbor/-DijAlvUV5QIuwgzf0M043YTp4k=/0x0:3000x1688/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72920461/924733706.0.jpg" />
        <figcaption>Image: Fox Image Collection via Getty Images</figcaption>
    </figure>

  <p>Epic’s Big Bang event looks like it’ll be a big deal after all</p>
  <p>
    <a href="https://www.polygon.com/23984003/fortnite-big-bang-family-guy-peter-griffin-leak">Continue reading&hellip;</a>
  </p>

## Columbia’s Hoth-ready Star Wars winter wear is here
 - [https://www.polygon.com/deals/23982589/columbia-star-wars-winter-collection-where-to-buy](https://www.polygon.com/deals/23982589/columbia-star-wars-winter-collection-where-to-buy)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-12-01T15:56:59+00:00

<figure>
      <img alt="A collection of models showcasing Columbia’s new Star Wars themed winterwear" src="https://cdn.vox-cdn.com/thumbor/abkJ131xVZxIsRrRjQRj6hwXEzc=/0x0:1262x710/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72917552/hviy8szs.0.png" />
        <figcaption>Image: Columbia</figcaption>
    </figure>

  <p>Your Tauntaun will most definitely approve of this new cold weather gear lineup</p>
  <p>
    <a href="https://www.polygon.com/deals/23982589/columbia-star-wars-winter-collection-where-to-buy">Continue reading&hellip;</a>
  </p>

## Destiny 2 Iron Banner schedule dates for Season of the Wish
 - [https://www.polygon.com/destiny-2-guide-walkthrough/23971548/iron-banner-schedule-dates-when-next](https://www.polygon.com/destiny-2-guide-walkthrough/23971548/iron-banner-schedule-dates-when-next)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-12-01T15:20:15+00:00

<figure>
      <img alt="Three Guardians in Iron Banner armor " src="https://cdn.vox-cdn.com/thumbor/Z8JHNlekczsDUm6Ws_-jkV0d3i0=/0x0:1920x1080/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72920340/destiny_2_iron_banner.0.jpg" />
        <figcaption>Image: Bungie</figcaption>
    </figure>

  <p>Find out when the next week-long event takes place</p>
  <p>
    <a href="https://www.polygon.com/destiny-2-guide-walkthrough/23971548/iron-banner-schedule-dates-when-next">Continue reading&hellip;</a>
  </p>

## Where to pre-order Pokémon TCG: Scarlet and Violet — Paldean Fates sets before they launch
 - [https://www.polygon.com/pokemon/23982618/how-to-preorder-buy-pokemon-tcg-paldean-fates-etb-booster-bundle](https://www.polygon.com/pokemon/23982618/how-to-preorder-buy-pokemon-tcg-paldean-fates-etb-booster-bundle)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-12-01T15:00:00+00:00

<figure>
      <img alt="A tin, a booster pack, a booster box, and an Elite Trainer Box of Pokémon TCG: Scarlet and Violet — Paldean Fates." src="https://cdn.vox-cdn.com/thumbor/Tc6ddyTOFpzjWz-qDfa0mC4YYP4=/0x106:2040x1254/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72920245/jlee_231130_1001_paldean_fates.0.jpg" />
        <figcaption>Graphic: Julia Lee/Polygon | Source images: The Pokémon Company</figcaption>
    </figure>

  <p>The expansion launches on Jan. 26, 2024, with more stuff coming the following month</p>
  <p>
    <a href="https://www.polygon.com/pokemon/23982618/how-to-preorder-buy-pokemon-tcg-paldean-fates-etb-booster-bundle">Continue reading&hellip;</a>
  </p>

## Suicide Squad Isekai might be the DC antihero team’s best form
 - [https://www.polygon.com/23983973/suicide-squad-isekai-anime-trailer](https://www.polygon.com/23983973/suicide-squad-isekai-anime-trailer)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-12-01T14:45:32+00:00

<figure>
      <img alt="Harley Quinn in anime form swinging a bat" src="https://cdn.vox-cdn.com/thumbor/po1ByZSifhAFKmxtexA9GHi5Cs4=/0x34:823x497/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72920203/filters_quality_95_format_webp_.0.jpg" />
        <figcaption>Image: Warner Bros. Japan</figcaption>
    </figure>

  <p>Joker, Harley Quinn, Peacemaker, and King Shark go full anime with help from Wit</p>
  <p>
    <a href="https://www.polygon.com/23983973/suicide-squad-isekai-anime-trailer">Continue reading&hellip;</a>
  </p>

## The Xbox Series X is discounted, and now costs the same as a Nintendo Switch OLED
 - [https://www.polygon.com/deals/23983948/xbox-series-x-349-deal-discount](https://www.polygon.com/deals/23983948/xbox-series-x-349-deal-discount)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-12-01T14:14:31+00:00

<figure>
      <img alt="Xbox Series X console and controller on a graphic linear background" src="https://cdn.vox-cdn.com/thumbor/Ut17daV9tPkh8d98wIuRRR9Doh0=/0x223:3000x1911/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72920128/jbareham_201020_ecl1040_xbox_lead_0001.0.jpg" />
        <figcaption>Photo: Henry Hargreaves for Polygon | Graphics: James Bareham/Polygon</figcaption>
    </figure>

  <p>Get your console now for 30% off</p>
  <p>
    <a href="https://www.polygon.com/deals/23983948/xbox-series-x-349-deal-discount">Continue reading&hellip;</a>
  </p>

## Maestro captures Bradley Cooper’s struggle to define what he really wants to be
 - [https://www.polygon.com/reviews/23983210/maestro-review-netflix-bradley-cooper](https://www.polygon.com/reviews/23983210/maestro-review-netflix-bradley-cooper)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-12-01T14:02:00+00:00

<figure>
      <img alt="Bradley Cooper passionately conducting as Leonard Bernstein in Netflix’s Maestro" src="https://cdn.vox-cdn.com/thumbor/JeWX350yVO9BwcD6g5qiqCu1kZI=/0x0:7838x4409/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72920087/Maestro_20221020_23291r.0.jpeg" />
        <figcaption>Photo: Jason McDonald/Netflix</figcaption>
    </figure>


  		<p>A star is torn</p>
  <p>
    <a href="https://www.polygon.com/reviews/23983210/maestro-review-netflix-bradley-cooper">Continue reading&hellip;</a>
  </p>

## Resident Evil 4’s VR mode finally arrives next week
 - [https://www.polygon.com/23983870/resident-evil-4-vr-mode-release-date](https://www.polygon.com/23983870/resident-evil-4-vr-mode-release-date)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-12-01T13:00:37+00:00

<figure>
      <img alt="A first person view of Leon reloading his pistol in the village section in Resident Evil 4" src="https://cdn.vox-cdn.com/thumbor/YR_pkeJAfMjPGiMqZiLVCZ_VNog=/0x0:3840x2160/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72919864/RE4_VR_Mode_SS_02.0.png" />
        <figcaption>Image: Capcom</figcaption>
    </figure>

  <p>PlayStation VR2 version of the 2023 remake arrives as a free update on Dec. 8</p>
  <p>
    <a href="https://www.polygon.com/23983870/resident-evil-4-vr-mode-release-date">Continue reading&hellip;</a>
  </p>

## Every movie and show coming to Netflix in December
 - [https://www.polygon.com/entertainment/2023/12/1/23972823/new-netflix-movies-tv-shows-watch-december-2023](https://www.polygon.com/entertainment/2023/12/1/23972823/new-netflix-movies-tv-shows-watch-december-2023)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-12-01T13:00:00+00:00

<figure>
      <img alt="Image: MARGOT ROBBIE grins on a background of purple and blue smoke as Harley Quinn in Warner Bros. Pictures’ “BIRDS OF PREY (AND THE FANTABULOUS EMANCIPATION OF ONE HARLEY QUINN)." src="https://cdn.vox-cdn.com/thumbor/DqE0rnCjbdzAeQwZvm_O5e47ohs=/0x94:1800x1107/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/72919820/rev_1_BOP_FP_0006_High_Res_JPEG.0.jpeg" />
        <figcaption>Image: Warner Bros.</figcaption>
    </figure>

  <p>It’s a DC-December</p>
  <p>
    <a href="https://www.polygon.com/entertainment/2023/12/1/23972823/new-netflix-movies-tv-shows-watch-december-2023">Continue reading&hellip;</a>
  </p>

