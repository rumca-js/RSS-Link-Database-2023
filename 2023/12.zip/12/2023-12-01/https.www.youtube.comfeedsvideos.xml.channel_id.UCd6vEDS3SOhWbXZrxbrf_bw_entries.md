# Source:SAMTIME, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCd6vEDS3SOhWbXZrxbrf_bw, language:en-US

## Google Apologises For Deleting Your Files
 - [https://www.youtube.com/watch?v=ssa3IaBpjoc](https://www.youtube.com/watch?v=ssa3IaBpjoc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCd6vEDS3SOhWbXZrxbrf_bw
 - date published: 2023-12-01T18:00:34+00:00

Google apologises for flushing some users' Google Drive documents down the toilet!

ARTICLE: https://www.theverge.com/2023/11/27/23978591/google-drive-desktop-data-loss-bug-files-missing-investigation

SUPPORT: https://funkytime.tv/patriot-signup/
MERCH: https://funkytime.tv/shop/
FUNKY TIME WEBSITE: https://funkytime.tv

FACEBOOK: http://www.facebook.com/SamtimeNews
TWITTER: http://twitter.com/SamtimeNews
INSTAGRAM: http://instagram.com/samtimenews

-----------------------------------

#GoogleDrive #GoogleDelete

'Escape the ordinary. Embrace the FUNKY!'

-----------------------------------

For sponsorship enquiries: samtime@bossmgmtgrp.com
For other business enquiries: business@funkytime.tv
Copyright FUNKY TIME PRODUCTIONS 2023

