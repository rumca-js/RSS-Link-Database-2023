# Source:Daily Wire, URL:https://www.dailywire.com/feeds/rss.xml, language:en-US

## ‘Like Mrs. Doubtfire, But Evil’: Libs Triggered By ‘Lady Ballers’ Release On DailyWire+
 - [https://www.dailywire.com/news/like-mrs-doubtfire-but-evil-libs-triggered-by-lady-ballers-release-on-dailywire](https://www.dailywire.com/news/like-mrs-doubtfire-but-evil-libs-triggered-by-lady-ballers-release-on-dailywire)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-12-01T17:57:22+00:00

Unsurprisingly, leftists are outraged over the release of The Daily Wire’s first-ever feature-length comedy “Lady Ballers.” The film openly mocks trans-identifying men competing in women’s sports. “Lady Ballers” is directed by the company’s co-founder Jeremy Boreing. Daily Wire sports show “Crain &amp; Co.” hosts also have roles, while there are cameos by other Daily Wire ...

## GOP Senators Urge Biden To Ban Travel From China Over ‘Unknown Respiratory Illness’
 - [https://www.dailywire.com/news/gop-senators-urge-biden-to-ban-travel-from-china-over-unknown-respiratory-illness](https://www.dailywire.com/news/gop-senators-urge-biden-to-ban-travel-from-china-over-unknown-respiratory-illness)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-12-01T17:39:19+00:00

A group of GOP senators is pushing President Joe Biden to ban travel from China over the appearance of a new respiratory illness. A group of five senators sent a letter to the White House on Friday raising alarm about “an unknown respiratory illness spreading throughout the People’s Republic of China.” The senators – Marco ...

## Anti-Semitism On Campus: 73% Of Jewish College Students Say They’ve Experienced It Or Seen It: Report
 - [https://www.dailywire.com/news/anti-semitism-on-campus-73-of-jewish-college-students-say-theyve-experienced-it-or-seen-it-report](https://www.dailywire.com/news/anti-semitism-on-campus-73-of-jewish-college-students-say-theyve-experienced-it-or-seen-it-report)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-12-01T17:15:07+00:00

Roughly 3 out of every 4 Jewish college student report they have either experienced anti-Semitism or seen others victimized by it on their campus since the Oct. 7 Hamas terror attack on Israel. According to a study conducted by the Anti-Defamation League and Hillel International, nearly 73% of students — a rise from 63% in ...

## Comedian Matt Rife Remains Unapologetic For Having A Sense Of Humor
 - [https://www.dailywire.com/news/comedian-matt-rife-remains-unapologetic-for-having-a-sense-of-humor](https://www.dailywire.com/news/comedian-matt-rife-remains-unapologetic-for-having-a-sense-of-humor)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-12-01T16:50:06+00:00

The following is a transcript excerpt from Dr. Jordan Peterson’s conversation with comedian Matt Rife. In this segment, they discuss the criticism over Matt’s Netflix special, how he responded, and the lack of consequences for leveling an accusation. You can listen to or watch the full podcast episode on DailyWire+. Start time: 1:01:29  Jordan: One ...

## Pope Quietly Confirms Through A Blog He Intends To Rescind U.S. Cardinal’s Vatican Privileges
 - [https://www.dailywire.com/news/pope-quietly-confirms-through-a-blog-he-intends-to-rescind-u-s-cardinals-vatican-privileges](https://www.dailywire.com/news/pope-quietly-confirms-through-a-blog-he-intends-to-rescind-u-s-cardinals-vatican-privileges)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-12-01T16:46:00+00:00

VATICAN CITY — Pope Francis quietly confirmed through a blog that he intends to rescind Vatican privileges for U.S. Cardinal Raymond Burke, who says he remains uninformed about his status as rumors circulate about his status with the church. Numerous outlets citing anonymous sources reported earlier this week that Pope Francis intended to react against ...

## ‘Aquaman’ Sequel Projected To Make Less Than Half Of Original Movie On Opening Weekend As Superhero Genre Struggles
 - [https://www.dailywire.com/news/aquaman-sequel-projected-to-make-less-than-half-of-original-movie-on-opening-weekend-as-superhero-genre-struggles](https://www.dailywire.com/news/aquaman-sequel-projected-to-make-less-than-half-of-original-movie-on-opening-weekend-as-superhero-genre-struggles)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-12-01T16:26:26+00:00

DC&#8217;s &#8220;Aquaman&#8221; sequel is projected to make less than half of what the original film did its opening holiday weekend as the superhero genre continues to struggle at the box office. &#8220;Aquaman and the Lost Kingdom&#8221; is currently tracking to make $40 million in projected ticket sales over the four-day Christmas holiday weekend (Dec. 22-Dec ...

## DailyWire+ Announces Adult Animated Comedy Series, ‘Mr. Birchum,’ Created By Adam Carolla
 - [https://www.dailywire.com/news/dailywire-announces-adult-animated-comedy-series-mr-birchum-created-by-adam-carolla](https://www.dailywire.com/news/dailywire-announces-adult-animated-comedy-series-mr-birchum-created-by-adam-carolla)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-12-01T16:21:20+00:00

Just days after dropping a viral trailer for its first feature-length comedy, “Lady Ballers,” the Daily Wire announced its first animated scripted series, “Mr. Birchum,” created by comedian Adam Carolla. The teaser trailer, which was first screened at the “Lady Ballers” red carpet premiere, will be released before the premiere of “Lady Ballers” on Friday, ...

## Hamas Terrorists Violate Ceasefire With Rocket Attack; Israel Responds With Precision Strikes
 - [https://www.dailywire.com/news/hamas-terrorists-violate-ceasefire-with-rocket-attack-israel-responds-with-precision-strikes](https://www.dailywire.com/news/hamas-terrorists-violate-ceasefire-with-rocket-attack-israel-responds-with-precision-strikes)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-12-01T15:53:36+00:00

Hamas terrorists violated on Friday the temporary ceasefire agreement that was in effect with Israel that had allowed hostages to be returned to Israel in exchange for Israel releasing convicted Palestinian criminals. The Palestinian Islamic terrorists violated the terms of the pause by failing to provide an adequate list of hostages to release to extend ...

## Tennessee Court Rules That Parents Can Intervene In Fight Over Release Of Nashville Shooter’s Manifesto
 - [https://www.dailywire.com/news/tennessee-court-rules-that-parents-can-intervene-in-fight-over-release-of-nashville-shooters-manifesto](https://www.dailywire.com/news/tennessee-court-rules-that-parents-can-intervene-in-fight-over-release-of-nashville-shooters-manifesto)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-12-01T15:36:13+00:00

A Tennessee court ruled on Thursday that a group of parents can intervene in the legal fight to block the release of the manifesto of the transgender-identifying woman who murdered six people at a Christian school in Nashville earlier this year.  The Tennessee Court of Appeals said that the Covenant School, Covenant Presbyterian Church, and ...

## ‘Lady Ballers,’ ‘The Most Triggering Comedy Of The Year,’ Premieres On DailyWire+ Tonight
 - [https://www.dailywire.com/news/lady-ballers-the-most-triggering-comedy-of-the-year-premieres-on-dailywire-tonight](https://www.dailywire.com/news/lady-ballers-the-most-triggering-comedy-of-the-year-premieres-on-dailywire-tonight)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-12-01T15:24:02+00:00

“Lady Ballers,” a movie that mocks the recent and controversial phenomenon of men competing in women’s sports, will be released by The Daily Wire at 8:00 p.m. ET Friday.  The DailyWire+ original and the company’s first-ever feature-length comedy has already received praise following its red-carpet premiere. “Lady Ballers” tells the story of one down-on-his-luck former ...

## ‘Too Many Bad Stories’: Former Child Stars Say Hollywood Is Too Dangerous For Kids
 - [https://www.dailywire.com/news/too-many-bad-stories-former-child-stars-say-hollywood-is-too-dangerous-for-kids](https://www.dailywire.com/news/too-many-bad-stories-former-child-stars-say-hollywood-is-too-dangerous-for-kids)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-12-01T14:55:24+00:00

There are certainly examples of former child actors who grew up to become happy, healthy, and well-adjusted adults. Unfortunately, there are also dozens of examples of the opposite happening.  The pitfalls of stepping into Hollywood under the age of 18 are so bad that many former child stars are speaking publicly against the concept and ...

## Kelly Clarkson’s Ex-Husband Ordered To Pay Back Singer Huge Sum In Ongoing Legal Battle
 - [https://www.dailywire.com/news/kelly-clarksons-ex-husband-ordered-to-pay-back-singer-huge-sum-in-ongoing-legal-battle](https://www.dailywire.com/news/kelly-clarksons-ex-husband-ordered-to-pay-back-singer-huge-sum-in-ongoing-legal-battle)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-12-01T14:46:49+00:00

Kelly Clarkson&#8216;s ex-husband Brandon Blackstock has been ordered to pay back the singer almost $3 million dollars in their ongoing legal battle after being found guilty of overcharging the singer on several of her contracts while acting as her manager. The California Labor Commission found that Blackstock unlawfully procured business deals for Clarkson as her ...

## ‘We’re Done’: Newsom’s Wife Intervened To End Debate Against DeSantis, Report Says
 - [https://www.dailywire.com/news/were-done-newsoms-wife-intervened-to-end-debate-against-desantis-report-says](https://www.dailywire.com/news/were-done-newsoms-wife-intervened-to-end-debate-against-desantis-report-says)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-12-01T14:32:51+00:00

California Democrat Governor Gavin Newsom&#8217;s wife reportedly ended the Fox News debate on Thursday night between Newsom and Florida Governor Ron DeSantis. After the first 90 minutes of the debate were finished, moderator Sean Hannity said that he had more time to extend the debate. Both candidates agreed to stay and Newsom said that he ...

## EXCLUSIVE: Biden Admin Praised YouTube’s Censorship, Used It To Pressure Facebook To Intensify Suppression Of Vaccine Stories
 - [https://www.dailywire.com/news/exclusive-biden-admin-praised-youtubes-censorship-used-it-to-pressure-facebook-to-intensify-suppression-of-vaccine-stories](https://www.dailywire.com/news/exclusive-biden-admin-praised-youtubes-censorship-used-it-to-pressure-facebook-to-intensify-suppression-of-vaccine-stories)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-12-01T14:13:16+00:00

As the Biden administration pressured Big Tech companies to censor Americans’ speech during the COVID vaccine rollout, Google&#8217;s YouTube went along with the White House’s requests before Facebook was pressured to follow suit, according to documents shared with House Judiciary Chairman Jim Jordan and obtained by The Daily Wire. In an April 18, 2021, email, ...

## Taylor Swift’s Publicist Shuts Down Joe Alwyn Marriage Rumors
 - [https://www.dailywire.com/news/taylor-swifts-publicist-shuts-down-joe-alwyn-marriage-rumors](https://www.dailywire.com/news/taylor-swifts-publicist-shuts-down-joe-alwyn-marriage-rumors)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-12-01T13:58:18+00:00

Taylor Swift&#8217;s longtime publicist Tree Paine blasted the &#8220;fabricated&#8221; and &#8220;insane&#8221; rumor that surfaced on Thursday that claimed the pop star and her ex-boyfriend Joe Alywn secretly married at one point. A popular Instagram celebrity gossip account by the name of Deuxmoi posted that the 33-year-old singer &#8220;did have a ceremony in either 2020 or ...

## Immigration Agent Who ‘Celebrates’ Hamas Is Using Paid Leave From DHS To Threaten Military Officials
 - [https://www.dailywire.com/news/immigration-agent-who-celebrates-hamas-is-using-paid-leave-from-dhs-to-threaten-military-officials](https://www.dailywire.com/news/immigration-agent-who-celebrates-hamas-is-using-paid-leave-from-dhs-to-threaten-military-officials)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-12-01T12:44:25+00:00

Nejwa Ali, who the Department of Homeland Security hired to vet asylum seekers, was put on paid leave after The Daily Wire exposed her extreme bias and anti-Semitism&#8211;but now she’s using all that free time to protest the Israeli embassy and call for doxing uniformed military personnel who she accused of contributing to “genocide.”

## ‘Epic Contrast Between Freedom Vs Statism’: Commentators Weigh In On DeSantis, Newsom Debate
 - [https://www.dailywire.com/news/epic-contrast-between-freedom-vs-statism-commentators-weigh-in-on-desantis-newsom-debate](https://www.dailywire.com/news/epic-contrast-between-freedom-vs-statism-commentators-weigh-in-on-desantis-newsom-debate)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-12-01T12:40:10+00:00

Florida Governor Ron DeSantis received strong praise online from many prominent conservative commentators following his debate performance against California Governor Gavin Newsom. The Thursday night debate in Georgia on Fox News was supposed to be about which state America should be like, California or Florida. Instead, the event turned quickly turned into DeSantis repeatedly going ...

## ‘Don’t Invite Parents’: School Teacher Called LGBT Club ‘Bubbles’ To Keep It From Being Identified, Emails Show
 - [https://www.dailywire.com/news/dont-invite-parents-school-teacher-called-lgbt-club-bubbles-to-keep-it-from-being-identified-emails-show](https://www.dailywire.com/news/dont-invite-parents-school-teacher-called-lgbt-club-bubbles-to-keep-it-from-being-identified-emails-show)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-12-01T12:32:41+00:00

A teacher at a high school in southern Illinois kept parents in the dark about students participating in an LGBT club, according to emails between school teachers. A teacher at Red Bud High School purposely excluded parents from knowledge about a Gay-Straight Alliance (GSA) Club by calling it “Bubbles” and not inviting parents to Google ...

## DNA From Gilgo Beach Serial Killer Suspect’s Wife Matches Hairs Found On Bodies, But She Is Not Accused Of Wrongdoing
 - [https://www.dailywire.com/news/dna-from-gilgo-beach-serial-killer-suspects-wife-matches-hairs-found-on-bodies-but-she-is-not-accused-of-wrongdoing](https://www.dailywire.com/news/dna-from-gilgo-beach-serial-killer-suspects-wife-matches-hairs-found-on-bodies-but-she-is-not-accused-of-wrongdoing)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-12-01T12:30:32+00:00

DNA from the wife of the accused Gilgo Beach serial killer matches DNA found on one of the alleged victims, but she is not accused of any wrongdoing. The wife, who is not being named by The Daily Wire because we are not naming the suspect, provided a cheek swab to authorities on the night ...

## Education Dept. Investigating Alleged Incident Of 18-Year-Old Trans-Identifying Student Exposing Male Genitalia To Freshmen Girls
 - [https://www.dailywire.com/news/education-dept-investigating-alleged-incident-of-18-year-old-trans-identifying-student-exposing-male-genitalia-to-freshmen-girls](https://www.dailywire.com/news/education-dept-investigating-alleged-incident-of-18-year-old-trans-identifying-student-exposing-male-genitalia-to-freshmen-girls)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-12-01T11:51:40+00:00

In a move that could pit women’s advocates and transgender activists against each other, the Education Department has opened an investigation into an alleged incident involving a trans-identifying student exposing his male genitalia to freshman girls. The Department’s Office for Civil Rights (OCR), which investigates schools for potential violations of the anti-sex discrimination statute Title ...

## House Votes To Expel George Santos
 - [https://www.dailywire.com/news/house-votes-to-expel-george-santos](https://www.dailywire.com/news/house-votes-to-expel-george-santos)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-12-01T11:17:36+00:00

The House voted Friday to expel Rep. George Santos (R-NY) following his numerous federal charges, including alleged aggravated identity theft, wire fraud, and conspiracy. The expulsion vote, which required a two-thirds majority, passed easily with 311 representatives voting in the affirmative to 114 voting against, and two voting present. Democrats, who remained mostly united in ...

## ‘Iran-Loving, Hamas-Appeasing Buffoon’: Blinken Blasted For Reportedly Threatening Israel It’s Running Out Of Time To Destroy Hamas
 - [https://www.dailywire.com/news/iran-loving-hamas-appeasing-buffoon-blinken-blasted-for-reportedly-threatening-israel-its-running-out-of-time-to-destroy-hamas](https://www.dailywire.com/news/iran-loving-hamas-appeasing-buffoon-blinken-blasted-for-reportedly-threatening-israel-its-running-out-of-time-to-destroy-hamas)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-12-01T11:12:43+00:00

Backlash erupted against U.S. Secretary of State Antony Blinken after he reportedly threatened Israeli officials who said it could take months to eradicate the terror group Hamas. A report from The Times Of Israel derived from Channel 12 News claimed that when Israeli Defense Minister Yoav Gallant told Blinken that all of Israel backs the ...

## Democratic Staffer Triggered By Border Patrol-Themed Christmas Decor
 - [https://www.dailywire.com/news/democratic-staffer-triggered-by-border-patrol-themed-christmas-decor](https://www.dailywire.com/news/democratic-staffer-triggered-by-border-patrol-themed-christmas-decor)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-12-01T11:10:39+00:00

A Democratic staffer on Capitol Hill was apparently triggered by the Christmas decorations put up outside a neighboring congressman&#8217;s office, calling the U.S. Border Patrol-themed display &#8220;insensitive, charged and insulting.&#8221; Jason Tufele Carl Johnson, who works in communications for Rep. Raul Grijalva (D-AZ), objected to the decor outside Rep. Eli Crane&#8217;s (R-AZ) office in a ...

## Felicity Huffman Speaks About College Admissions Scandal: ‘Felt Like I Had to Give My Daughter…A Future’
 - [https://www.dailywire.com/news/felicity-huffman-speaks-about-college-admissions-scandal-felt-like-i-had-to-give-my-daughter-a-future](https://www.dailywire.com/news/felicity-huffman-speaks-about-college-admissions-scandal-felt-like-i-had-to-give-my-daughter-a-future)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-12-01T10:27:25+00:00

Actress Felicity Huffman is breaking her silence on her involvement in a college admissions scandal which included dozens of parents using bribery and cheating to help get their children into elite institutions.  Huffman served 11 days in jail in 2019 and completed 250 hours of community service after it was discovered that she paid $15,000 ...

## BREAKING: Sandra Day O’Connor, First Woman On U.S. Supreme Court, Dies At 93
 - [https://www.dailywire.com/news/breaking-sandra-day-oconnor-first-woman-on-u-s-supreme-court-dies-at-93](https://www.dailywire.com/news/breaking-sandra-day-oconnor-first-woman-on-u-s-supreme-court-dies-at-93)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-12-01T10:12:09+00:00

Retired Associate Justice of the U.S. Supreme Court Sandra Day O&#8217;Connor passed away on Friday morning. She was 93 years old. O&#8217;Connor, who made history as the first woman to serve on the U.S. Supreme Court when she was appointed by former President Ronald Reagan in 1981, died in Phoenix, Arizona, from complications related to ...

## Actress Julianna Margulies Mocks Pronoun Crowd For Hamas Support, Said They’d Be ‘Beheaded’ In Gaza
 - [https://www.dailywire.com/news/actress-julianna-margulies-mocks-pronoun-crowd-for-hamas-support-said-theyd-be-beheaded-in-gaza](https://www.dailywire.com/news/actress-julianna-margulies-mocks-pronoun-crowd-for-hamas-support-said-theyd-be-beheaded-in-gaza)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-12-01T09:46:55+00:00

Actress Julianna Margulies had some harsh words of condemnation for Hamas supporters who are also proponents of the LGBT social movement, saying their stance is contradictory. The 57-year-old “The Morning Show” star made the comments during an appearance on Andy Ostroy’s “Back Room” podcast.  &#8220;It&#8217;s those kids who are spewing anti-Semitic hate that have no ...

## Illegal Immigrant Charged After Allegedly Shooting Two Sisters In The Head In Their Texas Home
 - [https://www.dailywire.com/news/illegal-immigrant-charged-after-allegedly-shooting-two-sisters-in-the-head-in-their-texas-home](https://www.dailywire.com/news/illegal-immigrant-charged-after-allegedly-shooting-two-sisters-in-the-head-in-their-texas-home)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-12-01T09:12:30+00:00

A 50-year-old illegal immigrant was arrested and charged after allegedly fatally shooting two sisters in the head in their Dallas-area home last week and also shooting his daughter in the arm.  Police booked Jose Santiago Chairez at the Dallas County Jail on charges of capital murder of multiple persons and aggravated assault. Sisters Catalina Andrade ...

