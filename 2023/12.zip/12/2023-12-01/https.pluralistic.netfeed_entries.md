# Source:Pluralistic: Daily links from Cory Doctorow, URL:https://pluralistic.net/feed, language:en-US

## Pluralistic: All the books I reviewed in 2023 (01 Dec 2023)
 - [https://pluralistic.net/2023/12/01/bookmaker](https://pluralistic.net/2023/12/01/bookmaker)
 - RSS feed: https://pluralistic.net/feed
 - date published: 2023-12-01T12:58:56+00:00

Today's links All the books I reviewed in 2023: Plus three of my own. Hey look at this: Delights to delectate. This day in history: 2003, 2008, 2018, 2022 Colophon: Recent publications, upcoming/recent appearances, current writing projects, current reading All the books I reviewed in 2023 (permalink) It's that time of year again, when I round up all the books I reviewed for my newsletter in the previous year. I posted 21 reviews last year, covering 31 books (there are two series in there!). I also published three books of my own last year (two novels and one nonfiction). A busy year in books! Every year, these roundups remind me that I did actually manager to get a lot of reading done, even if the list of extremely good books that I didn't read is much longer than the list of books I did read. I read many of these books while doing physiotherapy for my chronic pain, specifically as audiobooks I listened to on my underwater MP3 player while doing my daily laps at the public pool acros

