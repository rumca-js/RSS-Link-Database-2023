# Source:POLITICO, URL:https://www.politico.eu/feed, language:en-US

## Renewed Israel-Gaza war crowds out climate at COP28
 - [https://www.politico.eu/article/israel-hamas-war-diplomacy-united-nations-climate-summmit-cop28-dubai/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/israel-hamas-war-diplomacy-united-nations-climate-summmit-cop28-dubai/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-12-01T17:03:44+00:00

The Iranian delegation walked out, several leaders chided Israel and a flurry of diplomacy broke out as the ceasefire collapsed.

## Rishi Sunak hits back at criticism of fleeting COP28 visit
 - [https://www.politico.eu/article/uk-rishi-sunak-criticism-half-day-cop-28-visit-king-charles/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/uk-rishi-sunak-criticism-half-day-cop-28-visit-king-charles/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-12-01T16:29:06+00:00

UK prime minister rejects suggestion half-day stay shows lack of 'seriousness.'

## Germany is too distracted to deal with EU budget talks, Commission says
 - [https://www.politico.eu/article/germany-distracted-eu-budget-commission-johannes-hahn/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/germany-distracted-eu-budget-commission-johannes-hahn/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-12-01T16:05:20+00:00

Germany is distracted by domestic issues, said Johannes Hahn.

## ‘Everything indicates’ Chinese ship damaged Baltic pipeline on purpose, Finland says
 - [https://www.politico.eu/article/balticconnector-damage-likely-to-be-intentional-finnish-minister-says-china-estonia/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/balticconnector-damage-likely-to-be-intentional-finnish-minister-says-china-estonia/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-12-01T15:32:34+00:00

'I would think that you would notice that you're dragging an anchor behind you for hundreds of kilometers,' says minister.

## A balanced transition
 - [https://www.politico.eu/sponsored-content/a-balanced-transition/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/sponsored-content/a-balanced-transition/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-12-01T15:17:00+00:00

This content focuses on Equinor’s role in the EU energy transition, please visit their pages to learn more about their wider European and global operations.

## Greek PM moves to smooth over UK marbles row, as King Charles raises eyebrows
 - [https://www.politico.eu/article/greek-pm-mitsotakis-smooth-uk-elgin-marbles-row-parthenon-king-charles/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/greek-pm-mitsotakis-smooth-uk-elgin-marbles-row-parthenon-king-charles/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-12-01T14:54:04+00:00

After week of fury, Kyriakos Mitsotakis offers Rishi Sunak an olive branch.

## Ukraine seethes at Gazprom tennis tournament starring top pros
 - [https://www.politico.eu/article/gazprom-russia-ukraine-tennis-tournament-lesia-tsurenko/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/gazprom-russia-ukraine-tennis-tournament-lesia-tsurenko/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-12-01T13:17:55+00:00

Star Ukrainian player tells POLITICO that St. Petersburg competition is 'shameful.'

## Argentina snubs BRICS invitation
 - [https://www.politico.eu/article/argentina-snubs-brics-invitation/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/argentina-snubs-brics-invitation/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-12-01T13:01:02+00:00

The country's membership would have taken effect on January 1, 2024.

## How to watch the climate summit like an expert
 - [https://www.politico.com/news/2023/11/30/cop28-climate-summit-uae-00129325?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.com/news/2023/11/30/cop28-climate-summit-uae-00129325?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-12-01T12:21:24+00:00

Interested in the 200-nation effort to save the planet? Get used to squabbles about money and “phasing out” versus “phasing down” fossil fuels.

## No pressure, Rishi: King Charles urges leaders to act as COP28 kicks off
 - [https://www.politico.eu/article/no-pressure-rishi-king-charles-urges-leaders-to-act-as-cop28-kicks-off/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/no-pressure-rishi-king-charles-urges-leaders-to-act-as-cop28-kicks-off/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-12-01T09:27:04+00:00

The king warned global leaders at the climate summit that the world was entering 'dangerous uncharted territory.'

## Ukraine blows up main railway connection between Russia and China
 - [https://www.politico.eu/article/ukraine-security-service-blew-up-main-railway-connection-between-russia-china/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/ukraine-security-service-blew-up-main-railway-connection-between-russia-china/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-12-01T09:09:36+00:00

Kyiv's saboteurs strike deep in enemy territory, with Russian media reporting that authorities are investigating it as a terror attack.

## Israel recalls envoy in Madrid over Spanish PM’s comments
 - [https://www.politico.eu/article/israel-recalls-ambassador-spain-madrid-over-pm-pedro-sanchez-comments/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/israel-recalls-ambassador-spain-madrid-over-pm-pedro-sanchez-comments/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-12-01T08:38:17+00:00

Prime Minister Pedro Sánchez has repeatedly criticized Israel's actions in Gaza.

## Gaza truce crumbles as Israel and Hamas resume war
 - [https://www.politico.eu/article/israel-resumes-military-operations-gaza-cease-fire-crumbles-hamas/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/israel-resumes-military-operations-gaza-cease-fire-crumbles-hamas/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-12-01T08:31:46+00:00

The IDF says the militant group 'violated' the terms of the cease-fire, which expired early Friday.

## Pilote, l’appli pour suivre les réformes qui a fait flop
 - [https://www.politico.eu/article/pilote-lappli-pour-suivre-les-reformes-qui-a-fait-flop/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/pilote-lappli-pour-suivre-les-reformes-qui-a-fait-flop/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-12-01T05:00:00+00:00

La première version de l'application développée par Capgemini était un “enfer d'ergonomie”, selon plusieurs utilisateurs.

## How to get ready for government
 - [https://www.politico.eu/podcast/how-to-get-ready-for-government/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/podcast/how-to-get-ready-for-government/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-12-01T04:09:57+00:00

Presented by Equinor.

## ‘Joe Biden is your best friend, until he isn’t’
 - [https://www.politico.eu/article/joe-biden-is-your-best-friend-until-he-isnt/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/joe-biden-is-your-best-friend-until-he-isnt/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-12-01T03:04:00+00:00

The US leader tends to go by his gut instincts when making decisions. ‘Does that mean we’re hostages to the fortunes of his digestive tract?’ queried a senior Israeli official.

## Hey, Greece! You want your marbles back? Steal ’em
 - [https://www.politico.eu/article/declassified-elgin-marbles-sunak-mitsotakis-athens/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/declassified-elgin-marbles-sunak-mitsotakis-athens/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-12-01T03:03:00+00:00

Coming soon to a movie theater near you, The Great Elgin Marbles Caper.

## Rishi Sunak’s blink-and-you’ll-miss-it COP28
 - [https://www.politico.eu/article/britain-pm-rishi-sunak-blink-miss-cop28-climate-summit-uae/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/britain-pm-rishi-sunak-blink-miss-cop28-climate-summit-uae/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-12-01T03:03:00+00:00

UK prime minister, who has eased climate targets at home, is making a flying visit to the Dubai. He insists he's still got a strong green message to sell.

## Mayor of Paris hits back at ‘misogyny’ after scandal-ridden Tahiti trip
 - [https://www.politico.eu/article/mayor-paris-anne-hidalgo-hits-back-misogyny-scandal-ridden-tahiti-trip-2024-olympic-games/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/mayor-paris-anne-hidalgo-hits-back-misogyny-scandal-ridden-tahiti-trip-2024-olympic-games/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-12-01T03:02:00+00:00

Anne Hidalgo says her opponents are jealous of the fame that goes with the 2024 Olympic Games.

