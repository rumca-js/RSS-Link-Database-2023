# Source:Forsal.pl, URL:https://forsal.pl/.feed, language:pl-PL

## Wsparcie dla Ukrainy od USA. Bez tych pieniędzy pomoc będzie "niezmiernie trudna"
 - [https://forsal.pl/swiat/ukraina/artykuly/9371409,wsparcie-dla-ukrainy-od-usa-bez-tych-pieniedzy-pomoc-bedzie-niezmiernie-trudna.html](https://forsal.pl/swiat/ukraina/artykuly/9371409,wsparcie-dla-ukrainy-od-usa-bez-tych-pieniedzy-pomoc-bedzie-niezmiernie-trudna.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-01T20:53:48+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/RfvktkuTURBXy8yNjg0MDc1YS05ZTQxLTRjMDEtYmU2MS0xMDAwNTM4MmJlNzkuanBlZ5GTBc0BHcyg" />Jeśli Kongres nie uchwali pakietu środków na pomoc Ukrainie do końca roku, dalsze wsparcie Kijowa na wymaganym poziomie będzie niezmiernie trudne - oświadczył w piątek rzecznik Rady Bezpieczeństwa Narodowego John Kirby.

## Rosyjska armia będzie większa? Władimir Putin wydał dekret
 - [https://forsal.pl/swiat/rosja/artykuly/9371329,rosyjska-armia-bedzie-wieksza-wladimir-putin-wydal-dekret.html](https://forsal.pl/swiat/rosja/artykuly/9371329,rosyjska-armia-bedzie-wieksza-wladimir-putin-wydal-dekret.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-01T19:38:34+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/oqektkuTURBXy8zMjRjMjBkYi0wOWZiLTQyNmItODQwZC1mYWVjNjM1NWNjMTcuanBlZ5GTBc0BHcyg" />Dyktator Rosji Władimir Putin wydał w piątek dekret, na mocy którego liczebność żołnierzy w rosyjskich siłach zbrojnych zwiększy się do 1,32 mln; oznacza to wzrost o 170 tys. w porównaniu ze stanem obecnym - poinformowała agencja Interfax-Ukraina za bazą aktów prawnych Kremla.

## Sprawa George'a Santosa. Jest decyzja Izby Reprezentantów USA
 - [https://forsal.pl/swiat/usa/artykuly/9371305,sprawa-georgea-santosa-jest-decyzja-izby-reprezentantow-usa.html](https://forsal.pl/swiat/usa/artykuly/9371305,sprawa-georgea-santosa-jest-decyzja-izby-reprezentantow-usa.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-01T17:04:25+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ZDFktkuTURBXy8xN2JmNzk0Yi1kZDgyLTQ3MTUtOWQ4Yi1iZTcwZDU3MjdmZjMuanBlZ5GTBc0BHcyg" />Izba Reprezentantów Stanów Zjednoczonych zdecydowała w piątek o usunięciu ze swoich szeregów kongresmena Republikanów George'a Santosa z Nowego Jorku, oskarżonego o zdefraudowanie pieniędzy na kampanię wyborczą oraz sfabrykowanie dużej części swojej biografii.

## Kobietom na rynku pracy brakuje odwagi? Można to… zmierzyć
 - [https://forsal.pl/praca/kariera/artykuly/9367587,kobietom-na-rynku-pracy-brakuje-odwagi-mozna-to-zmierzyc.html](https://forsal.pl/praca/kariera/artykuly/9367587,kobietom-na-rynku-pracy-brakuje-odwagi-mozna-to-zmierzyc.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-01T17:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/719ktkuTURBXy9kMWU2MTU4ZS1hY2U5LTRlM2MtOGJhMC1lNWQ4ZWZiN2VlN2YuanBlZ5GTBc0BHcyg" />Pod koniec 2022 roku kobiety stanowiły zaledwie 15,5 proc. członków zarządów i rad nadzorczych spółek giełdowych w Polsce. To o 0,7 punktów procentowych mniej niż rok wcześniej. Między innymi po to, by podnieść ten odsetek, Gdańska Fundacja Kształcenia Menedżerów (GFKM) bada kobiecą odwagę i wspiera kobiety w jej budowaniu.

## Religia w szkołach. Co planuje przyszły rząd Donalda Tuska?
 - [https://forsal.pl/lifestyle/edukacja/artykuly/9366803,religia-w-szkolach-co-planuje-przyszly-rzad-donalda-tuska.html](https://forsal.pl/lifestyle/edukacja/artykuly/9366803,religia-w-szkolach-co-planuje-przyszly-rzad-donalda-tuska.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-01T16:21:23+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/-MNktkuTURBXy85OTc4YjZmMS0wZDBjLTQzODgtYmQyOS1hM2ZkZjYwZDEzNDcuanBlZ5GTBc0BHcyg" />W polskim systemie edukacji religia od dawna była obecna jako istotny element programu nauczania. Jednak ostatnie zapowiedzi nowej koalicji rządowej pod przewodnictwem Donalda Tuska sugerują znaczące zmiany. Jakie zmiany proponuje koalicja rządowa i jak do sprawy ma się Umowa Koalicyjna?

## Jak nie zbankrutować w czasie przedświątecznych wyprzedaży? Oto pięć żelaznych zasad
 - [https://forsal.pl/finanse/finanse-osobiste/artykuly/9366685,jak-nie-zbankrutowac-w-czasie-przedswiatecznych-wyprzedazy-oto-piec-zelaznych-zasad.html](https://forsal.pl/finanse/finanse-osobiste/artykuly/9366685,jak-nie-zbankrutowac-w-czasie-przedswiatecznych-wyprzedazy-oto-piec-zelaznych-zasad.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-01T15:46:05+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/fyEktkuTURBXy9mZDExNjBkYi01ZWZjLTRmN2EtOTUzMi1lNWNmNWU0NjIzM2EuanBlZ5GTBc0BHcyg" />Pod wpływem emocji zdarza nam się robić różne „głupie” rzeczy, których potem żałujemy. O jednych dość szybko zapominamy. Inne, jak zakupione na poprawę humory ciuchy czy elektronika, mogą nam o sobie długo przypominać. Brak miejsca w szafie czy na półce albo ciche dni z mężem lubo żoną są niczym w porównaniu ze stresem, jaki może wywołać debet na koncie. Jak zatem uchronić się przez zakusami branży handlowej i nie „popłynąć” z przedświątecznymi zakupami?

## Reuters: Członek rady doradczej COP28 rezygnuje. O co oskarża Zjednoczone Emiraty Arabskie?
 - [https://forsal.pl/biznes/aktualnosci/artykuly/9371265,reuters-czlonek-rady-doradczej-cop28-rezygnuje-oskarzajac-zjednoczone-emiraty-arabskie-o-wspieranie-paliw-kopalnych.html](https://forsal.pl/biznes/aktualnosci/artykuly/9371265,reuters-czlonek-rady-doradczej-cop28-rezygnuje-oskarzajac-zjednoczone-emiraty-arabskie-o-wspieranie-paliw-kopalnych.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-01T15:40:14+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/EG8ktkuTURBXy9mMWY3NTVjOC0wMWMyLTRjOWMtYTBkOS1iMjZjZDgyN2ZlMzEuanBlZ5GTBc0BHcyg" />Była prezydent Republiki Wysp Marshalla Hilda Heine zrezygnowała w piątek z członkostwa w radzie doradczej COP28, sprzeciwiając się wspieraniu przez Zjednoczone Emiraty Arabskie (ZEA) dalszego wykorzystywania paliw kopalnych i wykorzystywaniu szczytu COP28 do zawarcia nowych umów w tym zakresie – donosi agencja Reutera.

## Szmyhal: Szwajcaria zamroziła rosyjskie aktywa o wartości 8,8 mld dolarów
 - [https://forsal.pl/finanse/aktualnosci/artykuly/9371260,szmyhal-szwajcaria-zamrozila-rosyjskie-aktywa-o-wartosci-88-mld-dolarow.html](https://forsal.pl/finanse/aktualnosci/artykuly/9371260,szmyhal-szwajcaria-zamrozila-rosyjskie-aktywa-o-wartosci-88-mld-dolarow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-01T15:33:05+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/31GktkuTURBXy8wYjMxMmIyYi1lMGZjLTQ5MDMtOWM4Yy1lMDcyOWRhMGZhNGMuanBlZ5GTBc0BHcyg" />Szwajcaria zamroziła w ramach sankcji aktywa należące do Rosjan o wartości niemal 8,8 mld dolarów - poinformował w piątek na platformie X (d. Twitterze) premier Ukrainy Denys Szmyhal. Wraz z naszymi partnerami dążymy do stworzenia mechanizmu umożliwiającego wykorzystanie przejętych aktywów na rzecz odbudowy Ukrainy - zadeklarował szef ukraińskiego rządu.

## Szef MON: Podpisano umowę ramową na wozy wspierające do armatohaubic Krab i K9
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9371187,szef-mon-podpisano-umowe-ramowa-na-wozy-wspierajace-do-armatohaubic-krab-i-k9.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9371187,szef-mon-podpisano-umowe-ramowa-na-wozy-wspierajace-do-armatohaubic-krab-i-k9.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-01T14:09:50+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/WfZktkuTURBXy9lMmQ1YTA5YS1iMWU1LTRmYTItOThjNi0wZWU4ZWFkYzMzMzYuanBlZ5GTBc0BHcyg" />Dobra wiadomość dla Wojsk Rakietowych i Artylerii w Dniu Ich Święta. Agencja Uzbrojenia oraz konsorcjum PGZ i HSW podpisały umowę ramową na dostarczenie dla WP wozów wspierających armatohaubice na polu walki. Sprzęt współdziała zarówno z Krabem jak i K9 - poinformował szef MON Mariusz Błaszczak.

## Pierwsze Cybertrucki Tesli trafiły do klientów. Znamy cenę
 - [https://forsal.pl/motoforsal/artykuly/9370990,pierwsze-cybertrucki-tesli-trafily-do-klientow-znamy-cene.html](https://forsal.pl/motoforsal/artykuly/9370990,pierwsze-cybertrucki-tesli-trafily-do-klientow-znamy-cene.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-01T13:47:46+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/jgxktkuTURBXy81ODExM2NjYS1kYTEwLTQyOGQtODY5Ni1hYTQ0NTYwMWEwZmMuanBlZ5GTBc0BHcyg" />Po dwóch latach opóźnień i problemów w produkcji Tesla w końcu przekazała klientom pierwsze egzemplarze terenówki Cybertruck w stylu Blade Runnera.

## COP28. Duda: Stabilna energia z atomu jest niezbędna w takim kraju jak Polska
 - [https://forsal.pl/biznes/energetyka/artykuly/9371135,cop28-duda-stabilna-energia-z-atomu-jest-niezbedna-w-takim-kraju-jak-polska.html](https://forsal.pl/biznes/energetyka/artykuly/9371135,cop28-duda-stabilna-energia-z-atomu-jest-niezbedna-w-takim-kraju-jak-polska.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-01T13:43:28+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/1I2ktkuTURBXy8zMmZhMDgyMi0xNjUzLTQ3YjAtOTIxZi1iYmVhNjdjY2Q1NWMuanBlZ5GTBc0BHcyg" />Stabilna energia z atomu jest niezbędna w dużym i uprzemysłowionym kraju, jakim jak Polska; to ważne także dla realizacji naszych zobowiązań klimatycznych; weźmiemy udział w deklaracji o potrojeniu energii z atomu na świecie do 2050 roku - powiedział prezydent Andrzej Duda podczas konferencji COP28 w Dubaju.

## Pod koniec grudnia nadzwyczajna Rada UE ostatecznie przyjmie unijny pakiet migracyjno-azylowy
 - [https://forsal.pl/swiat/unia-europejska/artykuly/9371124,pod-koniec-grudnia-nadzwyczajna-rada-ue-ostatecznie-przyjmie-unijny-pa.html](https://forsal.pl/swiat/unia-europejska/artykuly/9371124,pod-koniec-grudnia-nadzwyczajna-rada-ue-ostatecznie-przyjmie-unijny-pa.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-01T13:27:23+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/3qMktkuTURBXy9mMzFmZDcyZC1hNjY0LTQ2MTEtOTI3Zi1hYjYwYzlkMGJjZjIuanBlZ5GTBc0BHcyg" />Na sesji plenarnej w Strasburgu, która zaplanowana jest w dniach 11-14 grudnia, PE ma głosować nad zapisami pakietu azylowo-migracyjnego. Następnie 22 grudnia ma zostać zwołana nadzwyczajna Rada UE, która ma ostatecznie przyjąć pakiet poparty przez PE - przekazało PAP wysokiej rangi źródło unijne.

## Tusk podał mapę drogową utworzenia swojego nowego rządu
 - [https://forsal.pl/gospodarka/polityka/artykuly/9371117,tusk-podal-mape-drogowa-utworzenia-swojego-nowego-rzadu.html](https://forsal.pl/gospodarka/polityka/artykuly/9371117,tusk-podal-mape-drogowa-utworzenia-swojego-nowego-rzadu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-01T13:21:44+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/IJQktkuTURBXy9lZmQ5MzUwYy0wMzczLTQ5YzQtYmNhNy1hOWQ2YzQxNDU3NGUuanBlZ5GTBc0BHcyg" />Spodziewajcie się państwo wyboru nowego rządu 11 grudnia, a jeśli czas na to nie pozwoli, to 12 grudnia expose nowego premiera, a zaprzysiężenie zakładamy 13 grudnia - podkreślił w piątek lider PO Donald Tusk.

## Znów awaria w Banku Millennium? Nie działa aplikacja mobilna
 - [https://forsal.pl/biznes/bankowosc/artykuly/9371092,znow-awaria-w-banku-millennium-nie-dziala-aplikacja-mobilna.html](https://forsal.pl/biznes/bankowosc/artykuly/9371092,znow-awaria-w-banku-millennium-nie-dziala-aplikacja-mobilna.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-01T13:03:34+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/AhtktkuTURBXy9mNTVkZDljMi1hYTE5LTQxYjMtOGVmZi1iMjYzYzc3OTk1MjIuanBlZ5GTBc0BHcyg" />Bank Millennium napotkał znaczące zakłócenia w swoich usługach bankowości mobilnej. Klienci zostali powitani komunikatem o &quot;chwilowych trudnościach&quot; podczas próby logowania do aplikacji, sygnalizującym rozległe problemy.

## Poroszenko nie mógł wyjechać z Ukrainy. O problemy oskarża biuro Zełenskiego
 - [https://forsal.pl/swiat/ukraina/artykuly/9370966,poroszenko-nie-mogl-wyjechac-z-ukrainy-o-problemy-oskarza-biuro-zelen.html](https://forsal.pl/swiat/ukraina/artykuly/9370966,poroszenko-nie-mogl-wyjechac-z-ukrainy-o-problemy-oskarza-biuro-zelen.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-01T10:29:03+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/bQ_ktkuTURBXy9lMzE2YmZmYS05Yjk5LTQwYWQtODgzMy1lZDFiMzQwNWZlNmUuanBlZ5GTBc0BHcyg" />B. prezydent Ukrainy Petro Poroszenko i szef opozycyjnej partii Europejska Solidarność oświadczył, że służby graniczne nie zezwoliły mu na wyjazd za granicę. Polityk ogłosił, że zakaz jest bezprawny i stoi za nim biuro jego przeciwnika, urzędującego prezydenta Wołodymyra Zełenskiego.

## Obajtek przekazał synowi część swoich nieruchomości. Zapowiedziała kroki prawne wobec WP
 - [https://forsal.pl/gospodarka/prawo/artykuly/9370945,obajtek-przekazal-synowi-czesc-swoich-nieruchomosci-zapowiedziala-kro.html](https://forsal.pl/gospodarka/prawo/artykuly/9370945,obajtek-przekazal-synowi-czesc-swoich-nieruchomosci-zapowiedziala-kro.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-01T09:57:19+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/2CoktkuTURBXy8yY2FjMmIxYi1mN2ZkLTQ5MWQtOTZhMS0zMWFmOGI2MDU0NGQuanBlZ5GTBc0BHcyg" />Mój majątek został wielokrotnie prześwietlony, a to, co komu przekazuję, jest moją prywatną sprawą - oświadczył w piątek prezes Orlenu Daniel Obajtek, komentując artykuł Wirtualnej Polski (WP) o jego darowiznach w postaci nieruchomości. Dodał, że sprawę kieruje na drogę prawną.

## Koronawirus w Polsce: 2412 zakażeń, zmarło 9 osób [DANE Z 1.12]
 - [https://forsal.pl/artykuly/1458115,koronawirus-w-polsce-2412-zakazen-zmarlo-9-osob-dane-z-112.html](https://forsal.pl/artykuly/1458115,koronawirus-w-polsce-2412-zakazen-zmarlo-9-osob-dane-z-112.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-01T09:39:01+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/3QYktkuTURBXy9lNjE1ZGFlZC02OTg5LTQzNzItOTg5OS1jZWEzOWVhODg4OWYuanBlZ5GTBc0BHcyg" />Minionej doby badania potwierdziły 2412 zakażeń koronawirusem, w tym 733 ponowne. Z powodu COVID-19 zmarło dziewięciu pacjentów – poinformowano w piątek na stronach rządowych. Wykonano ponad 4,7 tys. testów w kierunku SARS-CoV-2.

## Wskaźnik PMI dla przemysłu strefy euro wzrósł w listopadzie do 44,2 pkt
 - [https://forsal.pl/swiat/unia-europejska/artykuly/9370909,wskaznik-pmi-dla-przemyslu-strefy-euro-wzrosl-w-listopadzie-do-442-pk.html](https://forsal.pl/swiat/unia-europejska/artykuly/9370909,wskaznik-pmi-dla-przemyslu-strefy-euro-wzrosl-w-listopadzie-do-442-pk.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-01T09:15:35+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/RrZktkuTURBXy85NjZhZGYxZi01OGYxLTQ0ZTktOGQ1Zi04YjlkYjNjMWUxY2IuanBlZ5GTBc0BHcyg" />undefined

## Petru: Budżet na 2024 r. będzie musiał zostać znowelizowany w połowie roku
 - [https://forsal.pl/gospodarka/finanse-publiczne/artykuly/9370906,petru-budzet-na-2024-r-bedzie-musial-zostac-znowelizowany-w-polowie.html](https://forsal.pl/gospodarka/finanse-publiczne/artykuly/9370906,petru-budzet-na-2024-r-bedzie-musial-zostac-znowelizowany-w-polowie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-01T09:10:31+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/aJMktkuTURBXy9iODVhZGFlOS1lZTI1LTQ2ZmEtODBiMy1mN2JhNDEwMGEwYjMuanBlZ5GTBc0BHcyg" />undefined

## Unijny akt o cyberodporności na przedostatniej prostej. Ustali odpowiedzialnych za bezpieczeństwo użytkowników w sieci
 - [https://forsal.pl/swiat/unia-europejska/artykuly/9370903,unijny-akt-o-cyberodpornosci-na-przedostatniej-prostej-ustali-odpowie.html](https://forsal.pl/swiat/unia-europejska/artykuly/9370903,unijny-akt-o-cyberodpornosci-na-przedostatniej-prostej-ustali-odpowie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-01T09:03:51+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/CZvktkuTURBXy85MDkzMjQ1ZC1hOTllLTQzYWMtYTJhYS0yZDQxM2ZkMzNjYmUuanBlZ5GTBc0BHcyg" />Prezydencja Rady Unii Europejskiej i negocjatorzy Parlamentu Europejskiego osiągnęli porozumienie w sprawie proponowanych przepisów o wymogach cyberbezpieczeństwa dla produktów cyfrowych. Przepisy te mają sprawić, by produkty, takie jak podłączone do internetu domowe kamery, inteligentne lodówki, telewizory i zabawki, były bezpieczne w użytkowaniu.

## Wskaźnik PMI dla Polski wzrósł m: m do 48,7 pkt. W listopadzie wynosił 45,3 pkt
 - [https://forsal.pl/gospodarka/artykuly/9370886,wskaznik-pmi-dla-polski-wzrosl-m-m-do-487-pkt-w-listopadzie-wynosil.html](https://forsal.pl/gospodarka/artykuly/9370886,wskaznik-pmi-dla-polski-wzrosl-m-m-do-487-pkt-w-listopadzie-wynosil.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-01T08:37:22+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/V4yktkuTURBXy81YjE1N2E1NC0zY2JmLTQ4ZTUtYmYzMi04ZDNlMmMyMWI1NDUuanBlZ5GTBc0BHcyg" />undefined

## Duża sieć polskich sklepów ogłasza upadłość
 - [https://forsal.pl/biznes/handel/artykuly/9370878,neonet-upadlosc-duza-siec-polskich-sklepow-rtv.html](https://forsal.pl/biznes/handel/artykuly/9370878,neonet-upadlosc-duza-siec-polskich-sklepow-rtv.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-01T08:25:49+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/WABktkuTURBXy85OGQwNzRmOC0zMDhkLTQ1MDYtYjU4NS1iYWNmODUwMjhiZWIuanBlZ5GTBc0BHcyg" />Neonet, duża sieć sklepów ze sprzętem elektronicznym, ogłosiła upadłość. Firma działała w Polsce od 2002 roku, a w ostatnim czasie jeszcze otwierała nowe sklepy.

## Szwecja uczestniczy w grach wojennych NATO. Za kilka tygodni może zostać pełnoprawnym członkiem Sojuszu
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9370877,szwecja-uczestniczy-w-grach-wojennych-nato-za-kilka-tygodni-moze-zost.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9370877,szwecja-uczestniczy-w-grach-wojennych-nato-za-kilka-tygodni-moze-zost.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-01T08:22:57+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/7P2ktkuTURBXy9jNDg4OGQyMi0zZDUyLTRmNmMtOTc4My1kZGZhMDljMmEzODcuanBlZ5GTBc0BHcyg" />Szwecja za kilka tygodni po półtora roku oczekiwania może być pełnoprawnym członkiem NATO wynika z ostatnich zapewnień Turcji. Opóźnienie nie ma wpływu na integrację wojska, Sztokholm już jest w planach obronnych Sojuszu Północnoatlantyckiego i bierze udział w tajnych grach wojennych.

## PIE: Niepewność sytuacji gospodarczej jest barierą najsilniej utrudniającą działanie firm. Ale nie jedyną
 - [https://forsal.pl/biznes/aktualnosci/artykuly/9370876,pie-niepewnosc-sytuacji-gospodarczej-jest-bariera-najsilniej-utrudnia.html](https://forsal.pl/biznes/aktualnosci/artykuly/9370876,pie-niepewnosc-sytuacji-gospodarczej-jest-bariera-najsilniej-utrudnia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-01T08:15:17+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/HJzktkuTURBXy8wMzFmN2Y3ZC02NWVmLTQ3YzYtYTQ3OC0wNTcwYzVlMTY2YzcuanBlZ5GTBc0BHcyg" />Niepewność sytuacji gospodarczej jest barierą najsilniej utrudniającą działanie firm – czytamy w najnowszym numerze Tygodnika Gospodarczego PIE. Według Instytutu, odsetek wskazujących na jej silną uciążliwość wyniósł w listopadzie 2023 r. 66 proc.

## Ukraińcy odmłodzili polski rynek bankowy. Imigranci chętnie korzystają z kart i aplikacji
 - [https://forsal.pl/biznes/bankowosc/artykuly/9370869,ukraincy-odmlodzili-polski-rynek-bankowy-imigranci-chetnie-korzystaja.html](https://forsal.pl/biznes/bankowosc/artykuly/9370869,ukraincy-odmlodzili-polski-rynek-bankowy-imigranci-chetnie-korzystaja.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-01T08:08:11+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/rhTktkuTURBXy8yMzE4Mjk1My1kZTY5LTRhN2YtYmJmZC1hM2Q3YjAyOGQ2M2QuanBlZ5GTBc0BHcyg" />Ukraińcy odmłodzili polski rynek bankowy, chętnie korzystają z kart i aplikacji, odkładają pieniądze, a kredyty biorą tylko na mieszkanie - czytamy w piątek w &quot;Pulsie Biznesu&quot;.

## Rynek walutowy: Złoty umocnił się wobec głównych walut
 - [https://forsal.pl/finanse/waluty/artykuly/9370867,rynek-walutowy-zloty-umocnil-sie-wobec-glownych-walut.html](https://forsal.pl/finanse/waluty/artykuly/9370867,rynek-walutowy-zloty-umocnil-sie-wobec-glownych-walut.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-01T08:03:46+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/WCIktkuTURBXy80ZTAyMjg4Zi02OGM3LTRmYTQtOTcxZC05NDFkNTE5ZWNhODguanBlZ5GTBc0BHcyg" />W piątek rano polska waluta zyskała na wartości wobec euro, franka szwajcarskiego i dolara amerykańskiego. Euro kosztowało 4,35 zł, frank szwajcarski 4,56 zł, a dolar – 3,98 zł.

## Izrael prowadzi negocjacje w sprawie zakładników. Wznowiono walki w Gazie
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9370864,izrael-prowadzi-negocjacje-w-sprawie-zakladnikow-wznowiono-walki-w-ga.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9370864,izrael-prowadzi-negocjacje-w-sprawie-zakladnikow-wznowiono-walki-w-ga.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-01T08:00:35+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/gjHktkuTURBXy81YmVlODk1My01NGVmLTQzNDktYmQwYy1kNTNkZGM2MGEwOTMuanBlZ5GTBc0BHcyg" />Wciąż trwają negocjacje w sprawie uwolnienia zakładników uprowadzonych przez palestyńską organizację terrorystyczną Hamas, mimo że Izrael ogłosił wznowienie walk w Strefie Gazy - podała w piątek telewizja CNN, powołując się na źródło zaznajomione z przebiegiem rozmów.

## Ile osób w Polsce pobiera świadczenia emerytalno-rentowe? Dane za grudzień 2022 r.
 - [https://forsal.pl/gospodarka/aktualnosci/artykuly/9370865,ile-osob-w-polsce-pobiera-swiadczenia-emerytalno-rentowe-dane-za-grud.html](https://forsal.pl/gospodarka/aktualnosci/artykuly/9370865,ile-osob-w-polsce-pobiera-swiadczenia-emerytalno-rentowe-dane-za-grud.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-01T07:57:48+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/PwaktkuTURBXy82ZGJmOTYxMy04NjEwLTRiYWMtYjU1My05MTJhYjY2YTQzZWIuanBlZ5GTBc0BHcyg" />W grudniu 2022 r. w Polsce było 2,3 mln osób pobierających świadczenia emerytalno-rentowe lub zgłoszonych do ubezpieczenia przez płatników składek w ZUS, które posiadały orzeczenie o niepełnosprawności, stopniu niepełnosprawności albo o stopniu niezdolności do pracy - wynika z danych GUS.

## MCC Brussel: Polityka klimatyczna UE blokuje unijną politykę rolną. Grozi to wzrostem cen żywności [RAPORT]
 - [https://forsal.pl/biznes/rolnictwo/artykuly/9370853,mcc-brussel-polityka-klimatyczna-ue-blokuje-unijna-polityke-rolna-gr.html](https://forsal.pl/biznes/rolnictwo/artykuly/9370853,mcc-brussel-polityka-klimatyczna-ue-blokuje-unijna-polityke-rolna-gr.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-01T07:44:45+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/YQ0ktkuTURBXy83NmY4YmM5MC1lMGZkLTRkYjUtOWJkYS0xNzg2NjNhZTg1YzcuanBlZ5GTBc0BHcyg" />Dzisiejsza polityka rolna ma służyć przede wszystkim interesom środowiskowym i klimatycznym, a dopiero w drugiej kolejności bezpieczeństwu żywnościowemu; prowadzi to do sytuacji, w której nie opłaca się być rolnikiem - diagnozuje najnowszy raport brukselskiego think tanku MCC Brussels pt. &quot;Cicha wojna z rolnictwem&quot;.

## Dla wielu firm zatory płatnicze to bariera w działalności gospodarczej. Teraz mogą stracić nawet 121 mld zł [BADANIE}
 - [https://forsal.pl/biznes/aktualnosci/artykuly/9370849,dla-wielu-firm-zatory-platnicze-to-bariera-w-dzialalnosci-gospodarczej.html](https://forsal.pl/biznes/aktualnosci/artykuly/9370849,dla-wielu-firm-zatory-platnicze-to-bariera-w-dzialalnosci-gospodarczej.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-01T07:31:36+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/dUPktkuTURBXy8xMmIzNWQxZi0zZGVhLTQxOGEtOTAxYS1hZTRkYzQ0YTlkMDguanBlZ5GTBc0BHcyg" />Dla 68 proc. firm zatory płatnicze są barierą w działalności gospodarczej; regulowanie zobowiązań z opóźnieniem jest dotkliwe głównie dla branży budowlanej i handlowej - wynika z badania &quot;Przeterminowanie faktur w polskich przedsiębiorstwach&quot;, o czym informuje Krajowy Rejestr Długów.

## CCC dokonało częściowej dodatkowej redukcji zadłużenia na 160 mln zł
 - [https://forsal.pl/finanse/gielda/artykuly/9370846,ccc-dokonalo-czesciowej-dodatkowej-redukcji-zadluzenia-na-160-mln-zl.html](https://forsal.pl/finanse/gielda/artykuly/9370846,ccc-dokonalo-czesciowej-dodatkowej-redukcji-zadluzenia-na-160-mln-zl.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-01T07:30:36+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/IgKktkuTURBXy8xNmJkZWIxYS1iZjU0LTRmZDUtOWFhNi03MjNkZjVlMzhmM2MuanBlZ5GTBc0BHcyg" />undefined

## XPlus wyemituje do 2,5 mln akcji serii E2 z wyłączeniem prawa poboru
 - [https://forsal.pl/finanse/gielda/artykuly/9370844,xplus-wyemituje-do-25-mln-akcji-serii-e2-z-wylaczeniem-prawa-poboru.html](https://forsal.pl/finanse/gielda/artykuly/9370844,xplus-wyemituje-do-25-mln-akcji-serii-e2-z-wylaczeniem-prawa-poboru.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-01T07:28:53+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/LWrktkuTURBXy80NjcxYTk2Yy00OWIwLTQ4N2EtOTUyYS1kNjIzZmJlNDNjYTguanBlZ5GTBc0BHcyg" />undefined

## Vigo Photonics przydzieliło 145 799 akcji serii F po cenie emisyjnej 430 zł
 - [https://forsal.pl/finanse/gielda/artykuly/9370843,vigo-photonics-przydzielilo-145-799-akcji-serii-f-po-cenie-emisyjnej-4.html](https://forsal.pl/finanse/gielda/artykuly/9370843,vigo-photonics-przydzielilo-145-799-akcji-serii-f-po-cenie-emisyjnej-4.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-01T07:26:57+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/boUktkuTURBXy9kOTE0ODFjYS1kNWIwLTQ3ODEtOGNmNy1lOTY3NDliYzg0OWUuanBlZ5GTBc0BHcyg" />undefined

## Strefy Gazy: Zakończył się siedmiodniowy rozejm. Izrael ponowił ataki na północy i południu
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9370841,strefy-gazy-zakonczyl-sie-siedmiodniowy-rozejm-izrael-ponowil-ataki.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9370841,strefy-gazy-zakonczyl-sie-siedmiodniowy-rozejm-izrael-ponowil-ataki.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-01T07:23:36+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/1OtktkuTURBXy9mMTkzYzY4Yy1iMGY2LTQ5OGYtYmVmOS03M2U1ZDNkYzQ4NjkuanBlZ5GTBc0BHcyg" />Po wygaśnięciu trwającego siedem dni rozejmu Izrael ostrzeliwuje z ziemi i powietrza zarówno północną, jak i południową część Strefy Gazy; zginęło jak dotąd co najmniej osiem osób - poinformowały w piątek rano kontrolowane przez Hamas władze Strefy Gazy, cytowane przez CNN.

## Najwięcej wśród freelancerów zarabiają programiści. Copywriting znacznie niżej wyceniany? [RAPORT]
 - [https://forsal.pl/praca/wynagrodzenia/artykuly/9370834,najwiecej-wsrod-freelancerow-zarabiaja-programisci-copywriting-znaczn.html](https://forsal.pl/praca/wynagrodzenia/artykuly/9370834,najwiecej-wsrod-freelancerow-zarabiaja-programisci-copywriting-znaczn.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-01T07:18:18+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/v9JktkuTURBXy9lNzQyMzhmNi0zOGFhLTQxMGUtOTkwZi1mNzlhMDc1ODE0NjIuanBlZ5GTBc0BHcyg" />Najwięcej wśród freelancerów zarabiają programiści. W tej branży miesięczne wynagrodzenie powyżej 10 tys. złotych wskazało 8,3 proc. programistów, a aż 44,5 proc. badanych zadeklarowało, że ich zarobki wzrosły – wynika z raportu firmy Useme.

## Włoska "Magma" to wyjątkowo drogi czarny rogalik śniadaniowy z Neapolu
 - [https://forsal.pl/lifestyle/turystyka/artykuly/9370827,wloska-magma-to-wyjatkowo-drogi-czarny-rogalik-sniadaniowy-z-neapolu.html](https://forsal.pl/lifestyle/turystyka/artykuly/9370827,wloska-magma-to-wyjatkowo-drogi-czarny-rogalik-sniadaniowy-z-neapolu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-01T07:07:38+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/fMXktkuTURBXy82MGFjMzE2Ny05ZDhhLTQ5MTEtOTFmNC1iOTdjYzhlZWU0ZTEuanBlZ5GTBc0BHcyg" />Aż 100 euro kosztuje zapewne najdroższy śniadaniowy rogalik, czyli cornetto we Włoszech. Można go kupić w Neapolu i jest dziełem znanego cukiernika. Wypiek został nazwany &quot;Magma&quot;, a jego inspiracją jest Wezuwiusz. Czarny rogalik przypomina wulkan, a dla wzmocnienia efektu posypany jest &quot;popiołem&quot;.

## Eksperci: Polska na końcu krajów UE pod względem wczesnej diagnostyki raka piersi
 - [https://forsal.pl/lifestyle/zdrowie/artykuly/9370820,eksperci-polska-na-koncu-krajow-ue-pod-wzgledem-wczesnej-diagnostyki.html](https://forsal.pl/lifestyle/zdrowie/artykuly/9370820,eksperci-polska-na-koncu-krajow-ue-pod-wzgledem-wczesnej-diagnostyki.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-01T06:53:32+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/AFsktkuTURBXy85ODc1ZWE0My1iMTFlLTQ1ZjMtYWM5Ny02OWFhN2NjY2VlOTguanBlZ5GTBc0BHcyg" />W Polsce tylko u 41 proc. pacjentek rak piersi wykrywany jest we wczesnych stadiach, średnia unijna to 51 proc. – alarmują eksperci z Koalicji Wspólnie dla Zdrowia Kobiet. To sprawia, że śmiertelność Polek z rakiem piersi jest wyższa niż średnia w UE - oceniają.

## Izrael uwolnił 30 palestyńskich więźniów w ramach wymiany na izraelskich zakładników
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9370813,izrael-uwolnil-30-palestynskich-wiezniow-w-ramach-wymiany-na-izraelski.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9370813,izrael-uwolnil-30-palestynskich-wiezniow-w-ramach-wymiany-na-izraelski.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-01T06:42:46+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/cESktkuTURBXy9iNGU1NjdhMi03MjYyLTRiYWItOTJmZC01NjJiMjg5YmIxMDYuanBlZ5GTBc0BHcyg" />Izraelska służba więzienna poinformowała w nocy z czwartku na piątek, że wypuściła 30 Palestyńczyków z izraelskich więzień w ramach siódmej wymiany na izraelskich zakładników, zgodnie z porozumieniem o rozejmie między Izraelem a Hamasem w Gazie.

## Polska armia trampoliną dla koreańskiej zbrojeniówki?
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9366684,polska-armia-trampolina-dla-koreanskiej-zbrojeniowki.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9366684,polska-armia-trampolina-dla-koreanskiej-zbrojeniowki.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-01T05:50:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/hMTktkuTURBXy9iZDY3MDI3Yy0zMTM3LTRkMGMtOWE0NS01NjhkNTJjNmIxNzQuanBlZ5GTBc0BHcyg" />Seul postawił na rozwój przemysłu zbrojeniowego, a dostawy uzbrojenia dla polskiej armii to dopiero początek. Do 2027 roku Korea Południowa chce dołączyć do Stanów Zjednoczonych, Rosji oraz Francji i zostać czwartym co do wielkości eksporterem broni na świecie.

## Eurokołchoz i inne kłamstwa ludzi Kremla oraz ich prawicowo pożytecznych akolitów [FELIETON]
 - [https://forsal.pl/gospodarka/polityka/artykuly/9370764,eurokolchoz-i-inne-klamstwa-ludzi-kremla-oraz-ich-prawicowo-pozytecznych-akolitow-felieton.html](https://forsal.pl/gospodarka/polityka/artykuly/9370764,eurokolchoz-i-inne-klamstwa-ludzi-kremla-oraz-ich-prawicowo-pozytecznych-akolitow-felieton.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-01T05:45:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/3TnktkuTURBXy9jMDA0YzA3NC1hMjFiLTQ5ODEtODBmMC03Y2I5Yzk0MTE1MzYuanBlZ5GTBc0BHcyg" />Wolisz być landem w Eurolandzie czy „autonomiczną” republiką Rosji? Wybór, jakiego mogą dokonać kraje Europy, wydaje się dziś oczywisty. Mimo to wielu poddaje go w wątpliwość. Równie wielu ośmiela się snuć kosmicznie idiotyczne porównania między dobrowolną wspólnotą Zachodu a morderczą satrapią Wschodu. Mówię im dziś: „sprawdzam”.

## "Bezpieczny kredyt 2 proc.". Najbardziej skorzystali single i deweloperzy [RAPORT]
 - [https://forsal.pl/nieruchomosci/mieszkania/artykuly/9368362,bezpieczny-kredyt-2-proc-najbardziej-skorzystali-single.html](https://forsal.pl/nieruchomosci/mieszkania/artykuly/9368362,bezpieczny-kredyt-2-proc-najbardziej-skorzystali-single.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-01T05:30:23+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Ne0ktkuTURBXy85NGVhYTY4ZC1jY2FmLTQ2MDktYjJlMi1lZGY4ZDRjMmUxNzEuanBlZ5GTBc0BHcyg" />Single z dużych miast i deweloperzy – oni, jak pokazuje analiza banku PKO BP, najbardziej skorzystali na Bezpiecznym kredycie 2 proc. Powinniśmy chyba dodać do tego jeszcze banki.

## Sankcje USA nie działają? Kolejna chińska firma rusza z produkcją procesorów
 - [https://forsal.pl/lifestyle/technologie/artykuly/9370222,sankcje-usa-nie-dzialaja-kolejna-chinska-firma-rusza-z-produkcja-proc.html](https://forsal.pl/lifestyle/technologie/artykuly/9370222,sankcje-usa-nie-dzialaja-kolejna-chinska-firma-rusza-z-produkcja-proc.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-01T05:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/kTGktkuTURBXy9mODkyYTNhYi1lNGJlLTQ5MzktYjY4NC02M2E1YWJmM2Q2NWIuanBlZ5GTBc0BHcyg" />Pomimo ograniczeń nałożonych przez USA, chińskie firmy zajmujące się chipami starają się dotrzymać kroku producentom z Korei i Stanów Zjednoczonych.

## "Nie" dla nowego łącznika Polska-Ukraina. Bruksela nie wpisała go na strategiczną listę
 - [https://forsal.pl/biznes/energetyka/artykuly/9367626,nie-dla-nowego-lacznika-polska-ukraina-bruksela-nie-wpisala-go-na-strategiczna-liste.html](https://forsal.pl/biznes/energetyka/artykuly/9367626,nie-dla-nowego-lacznika-polska-ukraina-bruksela-nie-wpisala-go-na-strategiczna-liste.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-01T04:35:25+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/b_zktktTURBXy9lYWZjYTc1Yi04MjUwLTRmNzktOTY1Mi04ZGE5ZjNmNWJkM2QucG5nkZMFzQEdzKA" />Forsowany przez spółkę Orlenu i Synthosu projekt ma już historię pełną intryg i zwrotów akcji. Na rozstrzygnięcie, czy jest naprawdę potrzebny, przyjdzie nam jeszcze poczekać.

