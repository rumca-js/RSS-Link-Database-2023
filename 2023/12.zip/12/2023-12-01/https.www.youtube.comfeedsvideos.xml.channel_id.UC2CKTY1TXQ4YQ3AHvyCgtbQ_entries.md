# Source:Tabletop Miniatures, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2CKTY1TXQ4YQ3AHvyCgtbQ, language:en-US

## Why there's not a normal video today...
 - [https://www.youtube.com/watch?v=NDGx--4t3BU](https://www.youtube.com/watch?v=NDGx--4t3BU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2CKTY1TXQ4YQ3AHvyCgtbQ
 - date published: 2023-12-01T08:00:24+00:00

He was the best cat, and there may never be another like him.

