# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Lucius – Stranger Danger (live at The Current) #shorts #music
 - [https://www.youtube.com/watch?v=P7bXyqBlOug](https://www.youtube.com/watch?v=P7bXyqBlOug)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2023-12-01T20:53:48+00:00

Lucius visited The Current studio where they performed this fantastic rendition of their new single, "Stranger Danger," available on @FantasyRecordings.  

Watch the full session here: https://www.youtube.com/watch?v=HTfQXbVXVso

Musicians
Lead singers – Jess Wolfe, Holly Laessig
Drums – Dan Molad
Bass – Solomon Dorsey
Piano, Guitar – Alex Pfender
Guitar – Jacob Peter

Credits
Guests – @Luciusyt 
Host – Jill Riley
Producer – Derrick Stevens
Video Director – Eric Xu Romani
Camera Operators – Micah Kopecky, Eric Xu Romani
Audio – Josh Sauvageau
Graphics – Natalia Toledo
Digital Producer – Luke Taylor

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube  

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1  

Like/Follow:
https://www.facebook.com/TheCurrent/  
https://www.inst

