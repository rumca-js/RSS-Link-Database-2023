# Source:rp.pl, URL:https://www.rp.pl/rss_main, language:pl-PL

## Mediazona liczy poległych Rosjan. Całkowite szacunki są zróżnicowane
 - [https://www.rp.pl/konflikty-zbrojne/art39506841-mediazona-liczy-poleglych-rosjan-calkowite-szacunki-sa-zroznicowane](https://www.rp.pl/konflikty-zbrojne/art39506841-mediazona-liczy-poleglych-rosjan-calkowite-szacunki-sa-zroznicowane)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T21:39:00+00:00

Rosyjski niezależny portal Mediazona wraz z BBC Russia potwierdził 1 grudnia nazwiska 38 261 rosyjskich żołnierzy, którzy zginęli od rozpoczęcia rosyjskiej inwazji na Ukrainę na pełną skalę w lutym 2022 roku.

## Święta Rodzina z warsztatu Rubensa na polskim rynku sztuki
 - [https://www.rp.pl/malarstwo/art39506541-swieta-rodzina-z-warsztatu-rubensa-na-polskim-rynku-sztuki](https://www.rp.pl/malarstwo/art39506541-swieta-rodzina-z-warsztatu-rubensa-na-polskim-rynku-sztuki)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T20:33:32+00:00

12 grudnia na aukcję Polswiss Art w Warszawie trafi dzieło z warsztatu barokowego mistrza. To rzadkość na polskim rynku. Jego estymacja wynosi 4-6 mln zł.

## PŚ w skokach. W Lillehammer zmian nie widać
 - [https://www.rp.pl/skoki-narciarskie/art39506771-ps-w-skokach-w-lillehammer-zmian-nie-widac](https://www.rp.pl/skoki-narciarskie/art39506771-ps-w-skokach-w-lillehammer-zmian-nie-widac)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T20:24:51+00:00

Kwalifikacje do konkursu na skoczni normalnej wygrał lider PŚ Stefan Kraft. Polacy awansowali do sobotniego konkursu całą piątką, lecz tylko Piotr Żyła pokazał lekki wzrost formy

## Głodówka ukraińskich kierowców przerwana: „pewne porozumienie” osiągnięte
 - [https://www.rp.pl/transport/art39506671-glodowka-ukrainskich-kierowcow-przerwana-pewne-porozumienie-osiagniete](https://www.rp.pl/transport/art39506671-glodowka-ukrainskich-kierowcow-przerwana-pewne-porozumienie-osiagniete)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T19:45:00+00:00

Ukraińscy kierowcy koczujący trzeci tydzień na polsko-ukraińskiej granicy w Korczowej ogłosili strajk głodowy. Zgodzili się przerwać protest po tym, jak Polacy obiecali przepuszczać przez przejście po 7 tirów na godzinę, a ładunki humanitarne i wojskowe poza kolejnością.

## Elektroniczna kolejka to ukraiński „eksperyment”
 - [https://logistyka.rp.pl/drogowy/art39506621-elektroniczna-kolejka-to-ukrainski-eksperyment](https://logistyka.rp.pl/drogowy/art39506621-elektroniczna-kolejka-to-ukrainski-eksperyment)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T19:16:36+00:00

Delegacja ukraińskich przedsiębiorców przyjechała na rozmowy z polskimi organizacjami pozarządowymi apelować o zniesienie blokady.

## Putin zwiększa liczebność armii. "Odpowiedź na agresywne działania NATO"
 - [https://www.rp.pl/konflikty-zbrojne/art39506631-putin-zwieksza-liczebnosc-armii-odpowiedz-na-agresywne-dzialania-nato](https://www.rp.pl/konflikty-zbrojne/art39506631-putin-zwieksza-liczebnosc-armii-odpowiedz-na-agresywne-dzialania-nato)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T19:15:00+00:00

Prezydent Rosji Władimir Putin dekretem zwiększył liczebność żołnierzy w Siłach Zbrojnych Rosji o prawie 170 tys. osób - podaje rosyjska propagandowa agencja TASS.

## Jan Bończa-Szabłowski: Czterej pancerni i PiS
 - [https://www.rp.pl/opinie-polityczno-spoleczne/art39505351-jan-boncza-szablowski-czterej-pancerni-i-pis](https://www.rp.pl/opinie-polityczno-spoleczne/art39505351-jan-boncza-szablowski-czterej-pancerni-i-pis)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T19:08:12+00:00

Powołanie Rządu Donalda Tuska z wiadomych względów rozciągnięte jest na wiele tygodni. Można więc przyjąć, że codziennie obserwujemy kolejny odcinek trzymającego w napięciu serialu pt. „Czterej pancerni i PiS”.

## Europejscy 16-latkowie coraz częściej idą do urn
 - [https://www.rp.pl/polityka/art39506241-europejscy-16-latkowie-coraz-czesciej-ida-do-urn](https://www.rp.pl/polityka/art39506241-europejscy-16-latkowie-coraz-czesciej-ida-do-urn)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T18:34:48+00:00

Szymon Hołownia obiecał młodzieży obniżenie wieku wyborczego w Polsce do 16 lat. Coraz więcej krajów daje 16 i 17-latkom prawo do wybierania swoich przedstawicieli w parlamentach.

## Egzaminy maturalne: łacina wraca do łask. Biznes i zarządzanie jak informatyka
 - [https://www.rp.pl/prawo-dla-ciebie/art39505171-egzaminy-maturalne-lacina-wraca-do-lask-biznes-i-zarzadzanie-jak-informatyka](https://www.rp.pl/prawo-dla-ciebie/art39505171-egzaminy-maturalne-lacina-wraca-do-lask-biznes-i-zarzadzanie-jak-informatyka)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T18:15:07+00:00

Biznes i zarządzanie oraz łacinę będzie można zdawać pisemnie na egzaminie maturalnym. Przewiduje to skierowany w piątek do konsultacji projekt rozporządzenia ministra edukacji i nauki.

## Śmierć 14-letniej Natalii wstrząsnęła całą Polską. Mamy obowiązek reagowania
 - [https://www.rp.pl/spoleczenstwo/art39506401-smierc-14-letniej-natalii-wstrzasnela-cala-polska-mamy-obowiazek-reagowania](https://www.rp.pl/spoleczenstwo/art39506401-smierc-14-letniej-natalii-wstrzasnela-cala-polska-mamy-obowiazek-reagowania)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T18:00:00+00:00

Psycholożka Anna Alończyk apeluje: Wszyscy mamy obowiązek reagowania na innych. Po okresie pandemii, coraz więcej młodych ludzi ma obniżony nastrój, depresję, myśli samobójcze.

## Zmarła pierwsza kobieta sędzia Sądu Najwyższego Stanów Zjednoczonych
 - [https://www.rp.pl/sady-i-trybunaly/art39505791-zmarla-pierwsza-kobieta-sedzia-sadu-najwyzszego-stanow-zjednoczonych](https://www.rp.pl/sady-i-trybunaly/art39505791-zmarla-pierwsza-kobieta-sedzia-sadu-najwyzszego-stanow-zjednoczonych)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T17:39:35+00:00

W wieku 93 lat zarła była sędzia Sądu Najwyższego Stanów Zjednoczonych Sandra Day O'Connor. To pierwsza kobieta w historii sądu, która została powołana na to stanowisko.

## Joanna Ćwiek: W sprawie głosowania młodych Hołownia może mieć rację
 - [https://www.rp.pl/komentarze/art39505261-joanna-cwiek-w-sprawie-glosowania-mlodych-holownia-moze-miec-racje](https://www.rp.pl/komentarze/art39505261-joanna-cwiek-w-sprawie-glosowania-mlodych-holownia-moze-miec-racje)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T17:32:00+00:00

Aż 85 proc. ósmoklasistów deklaruje, że będzie chodzić na wybory. A 41 proc. regularnie sprawdza informacje polityczne w internecie. Mniej więcej wiedzą, o co chodzi w demokracji.

## Dziennik Ustaw z 1 grudnia 2023 (2610-2620)
 - [https://www.rp.pl/akty-prawne/art39505711-dziennik-ustaw-z-1-grudnia-2023-2610-2620](https://www.rp.pl/akty-prawne/art39505711-dziennik-ustaw-z-1-grudnia-2023-2610-2620)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T16:57:58+00:00



## Mikołajki na GPW przyszły wcześnie. Historyczne rekordy WIGu
 - [https://www.rp.pl/gielda/art39505681-mikolajki-na-gpw-przyszly-wczesnie-historyczne-rekordy-wigu](https://www.rp.pl/gielda/art39505681-mikolajki-na-gpw-przyszly-wczesnie-historyczne-rekordy-wigu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T16:52:00+00:00

Ledwie inwestorzy zdążyli podsumować udany listopad, a podczas pierwszej sesji grudnia WIG20 zyskał więcej niż w całym poprzednim miesiącu.

## Monitor Polski z 1 grudnia 2023 (1323-1332)
 - [https://www.rp.pl/akty-prawne/art39505441-monitor-polski-z-1-grudnia-2023-1323-1332](https://www.rp.pl/akty-prawne/art39505441-monitor-polski-z-1-grudnia-2023-1323-1332)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T16:50:32+00:00



## Dolar znów poniżej 4 zł. Złoty wraca do dobrej formy
 - [https://www.rp.pl/waluty/art39505431-dolar-znow-ponizej-4-zl-zloty-wraca-do-dobrej-formy](https://www.rp.pl/waluty/art39505431-dolar-znow-ponizej-4-zl-zloty-wraca-do-dobrej-formy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T16:44:00+00:00

Złoty w piątkowe po południe zyskuje na wartości./ Kurs USD/PLN oddala się od okrągłego poziomu.

## Były prezydent Ukrainy zablokowany na granicy z Polską. Petro Poroszenko nie mógł wyjechać z kraju
 - [https://www.rp.pl/polityka/art39505061-byly-prezydent-ukrainy-zablokowany-na-granicy-z-polska-petro-poroszenko-nie-mogl-wyjechac-z-kraju](https://www.rp.pl/polityka/art39505061-byly-prezydent-ukrainy-zablokowany-na-granicy-z-polska-petro-poroszenko-nie-mogl-wyjechac-z-kraju)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T16:39:07+00:00

Były prezydent Ukrainy Petro Poroszenko oświadczył, że uniemożliwiono mu opuszczenie kraju i ocenił, że była to politycznie motywowana próba zakłócenia jego pracy.

## Viaplay opuści Polskę w połowie 2025 roku
 - [https://www.rp.pl/sport/art39505411-viaplay-opusci-polske-w-polowie-2025-roku](https://www.rp.pl/sport/art39505411-viaplay-opusci-polske-w-polowie-2025-roku)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T16:35:00+00:00

Po ujawnieniu niekorzystnych wyników finansowych za trzeci kwartał koncern Viaplay Group potwierdził zamiar opuszczenia runku polskiego, brytyjskiego i krajów bałtyckich do lata 2025 roku, czyli nieco poźniej, niż pierwotnie sugerowano

## Miasta gotowe na zimę. Pługosolarki wyjeżdżają na ulice
 - [https://regiony.rp.pl/z-regionow/art39505391-miasta-gotowe-na-zime-plugosolarki-wyjezdzaja-na-ulice](https://regiony.rp.pl/z-regionow/art39505391-miasta-gotowe-na-zime-plugosolarki-wyjezdzaja-na-ulice)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T16:14:38+00:00

Solarki, pługopiaskarki czy ciągniki z pługiem i rozsiewaczem – ciężki sprzęt jest już w całodobowej gotowości, by wyjechać na drogi.

## Miliony Mentzena, unijna emerytura Tuska. Politycy ujawniają majątki
 - [https://www.rp.pl/polityka/art39505221-miliony-mentzena-unijna-emerytura-tuska-politycy-ujawniaja-majatki](https://www.rp.pl/polityka/art39505221-miliony-mentzena-unijna-emerytura-tuska-politycy-ujawniaja-majatki)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T16:12:00+00:00

Na stronach Sejmu opublikowane zostały oświadczenia majątkowe aktualnych posłów. Poznaliśmy majątki m.in.  lidera Platformy Obywatelskiej i kandydata na premiera, Donalda Tuska oraz debiutującego w Sejmie Sławomira Mentzena z Konfederacji.

## Putin wyrzuca Niemców i Katarczyków z lotniska w St Petersburgu
 - [https://www.rp.pl/transport/art39504891-putin-wyrzuca-niemcow-i-katarczykow-z-lotniska-w-st-petersburgu](https://www.rp.pl/transport/art39504891-putin-wyrzuca-niemcow-i-katarczykow-z-lotniska-w-st-petersburgu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T16:11:00+00:00

To ma być zemsta na Niemczech za zachodnie sankcje. Katarczycy zostali ukarani właściwie „przy okazji”.

## Peter Gabriel na nowej płycie proponuje nowy świat
 - [https://www.rp.pl/muzyka-popularna/art39505271-peter-gabriel-na-nowej-plycie-proponuje-nowy-swiat](https://www.rp.pl/muzyka-popularna/art39505271-peter-gabriel-na-nowej-plycie-proponuje-nowy-swiat)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T16:10:00+00:00

„i/o” Petera Gabriela to album roku. Nie tylko dlatego, że artysta dozował nam single od stycznia do grudnia.

## "O czasie. Historia cywilizacji w dwunastu zegarach": Czas w różnych czasach
 - [https://www.rp.pl/plus-minus/art39498781-o-czasie-historia-cywilizacji-w-dwunastu-zegarach-czas-w-roznych-czasach](https://www.rp.pl/plus-minus/art39498781-o-czasie-historia-cywilizacji-w-dwunastu-zegarach-czas-w-roznych-czasach)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T16:00:00+00:00

David Ronney rekonstruuje, jaką drogę przebyły zegary, zanim zawładnęły człowiekiem.

## Irena Lasota: Palestynę trzeba wyzwolić od Hamasu i filozofii nienawiści
 - [https://www.rp.pl/plus-minus/art39498641-irena-lasota-palestyne-trzeba-wyzwolic-od-hamasu-i-filozofii-nienawisci](https://www.rp.pl/plus-minus/art39498641-irena-lasota-palestyne-trzeba-wyzwolic-od-hamasu-i-filozofii-nienawisci)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T16:00:00+00:00

Trzeba wyzwolić Palestynę – od Hamasu, Islamskiego Dżihadu, skorumpowanego rządu Autonomii Palestyńskiej, od filozofii nienawiści, od żądzy krwi.

## Jan Maciejewski: Atomowa era moralności
 - [https://www.rp.pl/plus-minus/art39498621-jan-maciejewski-atomowa-era-moralnosci](https://www.rp.pl/plus-minus/art39498621-jan-maciejewski-atomowa-era-moralnosci)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T16:00:00+00:00

Odrzucenie całej, zdobywanej od Arystotelesa, przez św. Tomasza aż do nowożytności wiedzy o ludzkiej duszy i charakterze jest tak samo „otwierające przed człowiekiem nowe horyzonty”, jak dla fizyki wyzwalające byłoby zniszczenie dorobku Newtona, Faradaya i Einsteina razem wziętych.

## Kompas Młodej Sztuki 2023: Najlepsi artyści XIII edycji
 - [https://www.rp.pl/plus-minus/art39498851-kompas-mlodej-sztuki-2023-najlepsi-artysci-xiii-edycji](https://www.rp.pl/plus-minus/art39498851-kompas-mlodej-sztuki-2023-najlepsi-artysci-xiii-edycji)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T16:00:00+00:00

Pierwsza dziesiątka Kompasu Młodej Sztuki 2023 zdominowana jest przez artystki. Skupiają się na wątkach feministycznych, ekologicznych, mówią także o braku tolerancji, zrozumienia dla inności. Ich prace są o lękach, marzeniach, rozczarowaniach. Są głosem pokolenia.

## Lubię tych, co stają okoniem
 - [https://www.rp.pl/plus-minus/art39498771-lubie-tych-co-staja-okoniem](https://www.rp.pl/plus-minus/art39498771-lubie-tych-co-staja-okoniem)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T16:00:00+00:00

Dlaczego literatura ma być komunikatywna i łatwa? To tak, jakby wszyscy mieli jeść parówki.

## Maria Callas – kobieta, która zamilkła zbyt wcześnie
 - [https://www.rp.pl/plus-minus/art39498711-maria-callas-kobieta-ktora-zamilkla-zbyt-wczesnie](https://www.rp.pl/plus-minus/art39498711-maria-callas-kobieta-ktora-zamilkla-zbyt-wczesnie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T16:00:00+00:00

Aby stać się legendą, trzeba odejść zbyt wcześnie, zostawiając świat w zadziwieniu, że to się rzeczywiście stało. Tak właśnie zrobiła Maria Callas i do dziś nie straciła statusu gwiazdy, która nadal fascynuje i zaciekawia.

## Michał Szułdrzyński: Media społecznościowe to komunikacyjne piekło
 - [https://www.rp.pl/plus-minus/art39498531-michal-szuldrzynski-media-spolecznosciowe-to-komunikacyjne-pieklo](https://www.rp.pl/plus-minus/art39498531-michal-szuldrzynski-media-spolecznosciowe-to-komunikacyjne-pieklo)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T16:00:00+00:00

Rzeczywistość zbudowana na dosłowności byłaby najgorszym z możliwych miejsc.

## Piłka łączy nas w bólu
 - [https://www.rp.pl/plus-minus/art39498761-pilka-laczy-nas-w-bolu](https://www.rp.pl/plus-minus/art39498761-pilka-laczy-nas-w-bolu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T16:00:00+00:00

Rok 2023 był dla polskiej piłki fatalny pod każdym względem. Reprezentacja nie awansowała do finałów mistrzostw Europy, a PZPN uwikłany w afery kompromitował się decyzjami sportowymi.

## Prof. Piotr Sztompka: Polska po wyborach odzyskała wiarygodność
 - [https://www.rp.pl/plus-minus/art39498681-prof-piotr-sztompka-polska-po-wyborach-odzyskala-wiarygodnosc](https://www.rp.pl/plus-minus/art39498681-prof-piotr-sztompka-polska-po-wyborach-odzyskala-wiarygodnosc)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T16:00:00+00:00

Są fenomeny, które zdarzają się tak nagle w masowej skali, jeżeli powstaną ku temu jakieś podstawowe warunki. Co będzie dalej? Tu pojawia się znak zapytania, bo polskie zrywy miewały to do siebie, że szybko mijały - mówi prof. Piotr Sztompka, socjolog.

## Robert Mazurek: Pierwszy Mulat w mieście
 - [https://www.rp.pl/plus-minus/art39498661-robert-mazurek-pierwszy-mulat-w-miescie](https://www.rp.pl/plus-minus/art39498661-robert-mazurek-pierwszy-mulat-w-miescie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T16:00:00+00:00

Cieszę się z każdej chwili, gdy przyłapię świat na niezmienności. Wszystko wokół się zmienia, a tu proszę, pan Marian strzyże na Mokotowie od 57 lat. I bardzo się cieszę, że znów nie wolno mówić „Ciemno jak w dupie u Murzyna”. Choć tym razem nikomu nie zawadza swojska „dupa”.

## Stanisław Lilpop – mieszczański sarmata z aparatem
 - [https://www.rp.pl/plus-minus/art39498741-stanislaw-lilpop-mieszczanski-sarmata-z-aparatem](https://www.rp.pl/plus-minus/art39498741-stanislaw-lilpop-mieszczanski-sarmata-z-aparatem)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T16:00:00+00:00

Stworzenie słynnego miasta-ogrodu, ekstrawagancka wyprawa do Kenii, pionierskie dokonania fotograficzne, wreszcie sukces biznesowy, który okazał się przekleństwem – urodzony 160 lat temu Stanisław Wilhelm Lilpop był nietuzinkową postacią.

## Tomasz P. Terlikowski: Nie ma zgody na hejt wobec Doroty Chorosińskiej
 - [https://www.rp.pl/plus-minus/art39498631-tomasz-p-terlikowski-nie-ma-zgody-na-hejt-wobec-doroty-chorosinskiej](https://www.rp.pl/plus-minus/art39498631-tomasz-p-terlikowski-nie-ma-zgody-na-hejt-wobec-doroty-chorosinskiej)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T16:00:00+00:00

To już nie jest kwestia niszczenia debaty publicznej, siania ordynarnej nienawiści, ale destrukcji zwykłej ludzkiej uczciwości. I właśnie dlatego w sprawie hejtu wobec posłanki i minister kultury Dominiki Chorosińskiej nie mogę i nie chcę milczeć.

## Tylko taki szaleniec jak Javier Milei uratuje Argentynę
 - [https://www.rp.pl/plus-minus/art39498691-tylko-taki-szaleniec-jak-javier-milei-uratuje-argentyne](https://www.rp.pl/plus-minus/art39498691-tylko-taki-szaleniec-jak-javier-milei-uratuje-argentyne)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T16:00:00+00:00

Wysadzenie w powietrze banku centralnego, likwidacja edukacji publicznej, zamknięcie większości ministerstw… Nie wiadomo, który z pomysłów Javiera Milei jest najbardziej szalony. Ale prawdziwa tragedia zdarzy się, jeśli żaden nie zostanie wprowadzony w życie.

## Wina Mazurka: Nie ma głupich pytań
 - [https://www.rp.pl/plus-minus/art39498651-wina-mazurka-nie-ma-glupich-pytan](https://www.rp.pl/plus-minus/art39498651-wina-mazurka-nie-ma-glupich-pytan)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T16:00:00+00:00

Ale są pytania zaskakujące. Słyszałem ich dziesiątki przez te ponad 12 lat, a że to remanent, to niektóre przypomnę.

## „Dzień dobry, ja też umieram”: Opowieści z krypty
 - [https://www.rp.pl/plus-minus/art39498791-dzien-dobry-ja-tez-umieram-opowiesci-z-krypty](https://www.rp.pl/plus-minus/art39498791-dzien-dobry-ja-tez-umieram-opowiesci-z-krypty)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T16:00:00+00:00

Olga Ptak w swoich esejach o śmierci potrafi wprowadzić nas w intymną przestrzeń, w której przestajemy być intruzami czy turystami.

## „Flashback 2": Dawne sztuczki nie działają
 - [https://www.rp.pl/plus-minus/art39498821-flashback-2-dawne-sztuczki-nie-dzialaja](https://www.rp.pl/plus-minus/art39498821-flashback-2-dawne-sztuczki-nie-dzialaja)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T16:00:00+00:00

Czy powrót „Flashbacka”, legendarnej platformówki sprzed 30 lat, okazał się udany?

## „Siódemka. SzÓs polskich królowa”: Mijając ze sceny Wodzisław i Jędrzejów
 - [https://www.rp.pl/plus-minus/art39498831-siodemka-szos-polskich-krolowa-mijajac-ze-sceny-wodzislaw-i-jedrzejow](https://www.rp.pl/plus-minus/art39498831-siodemka-szos-polskich-krolowa-mijajac-ze-sceny-wodzislaw-i-jedrzejow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T16:00:00+00:00

Ciąg fantastycznych przygód na krajowej siódemce kończy się apokaliptyczną wizją ataku Rosji na Polskę. Tak było w powieści Ziemowita Szczerka z 2014 r. i tak jest w przekonującej teatralnej adaptacji „Siódemki” Rafała Szumskiego.

## W Paryżu odbył się "ślub stulecia". Wartość atrakcji dla pary młodej i ich gości ocenia się na 59 milionów dolarów.
 - [https://kobieta.rp.pl/styl-zycia/art39501951-w-paryzu-odbyl-sie-slub-stulecia-wartosc-atrakcji-dla-pary-mlodej-i-ich-gosci-ocenia-sie-na-59-milionow-dolarow](https://kobieta.rp.pl/styl-zycia/art39501951-w-paryzu-odbyl-sie-slub-stulecia-wartosc-atrakcji-dla-pary-mlodej-i-ich-gosci-ocenia-sie-na-59-milionow-dolarow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T14:28:18+00:00

Mówi się, że rozmach tego ślubu zawstydziłby samą Marię Antoninę. W mediach społecznościowych pojawiły się relacje z pięciodniowych uroczystości zaślubin amerykańskiej pary - Madelaine Brockway i Jacoba LaGrone - w Paryżu.

## Przełom na szczycie klimatycznym. „Żywność znalazła się w centrum uwagi”
 - [https://klimat.rp.pl/klimat/art39504061-przelom-na-szczycie-klimatycznym-zywnosc-znalazla-sie-w-centrum-uwagi](https://klimat.rp.pl/klimat/art39504061-przelom-na-szczycie-klimatycznym-zywnosc-znalazla-sie-w-centrum-uwagi)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T14:27:32+00:00

Organizatorzy tegorocznego szczytu klimatycznego COP28 wykazali się sprawnością: drugiego dnia szczytu podpisano deklarację, którą wielu obserwatorów określa jako „przełomową”. Dotyczy ona transformacji systemów żywnościowych. Dlaczego jest tak istotna?

## Podrobione części w silnikach Ryanaira. To nie pierwszy taki przypadek
 - [https://www.rp.pl/transport/art39504771-podrobione-czesci-w-silnikach-ryanaira-to-nie-pierwszy-taki-przypadek](https://www.rp.pl/transport/art39504771-podrobione-czesci-w-silnikach-ryanaira-to-nie-pierwszy-taki-przypadek)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T14:25:00+00:00

Ryanair Holdings poinformował, że znalazł niecertyfikowane części w dwóch silnikach swoich samolotów. To kolejny przewoźnik, który ma kłopoty z podzespołami ze sfałszowanymi dokumentami.

## Frances Sternhagen zmarła w wieku 93 lat. „Opadła kurtyna na bogate życie”
 - [https://kobieta.rp.pl/ludzie/art39502211-frances-sternhagen-zmarla-w-wieku-93-lat-opadla-kurtyna-na-bogate-zycie](https://kobieta.rp.pl/ludzie/art39502211-frances-sternhagen-zmarla-w-wieku-93-lat-opadla-kurtyna-na-bogate-zycie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T14:24:09+00:00

Była gwiazdą scen teatralnych, małego i dużego ekranu. Ostatnio bawiła widzów (i trochę przerażała) jako potworna teściowa Charlotte z serialu „Seks w wielkim mieście”.

## Archicom na zakupach w Łodzi
 - [https://www.rp.pl/nieruchomosci/art39504831-archicom-na-zakupach-w-lodzi](https://www.rp.pl/nieruchomosci/art39504831-archicom-na-zakupach-w-lodzi)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T14:21:36+00:00

Deweloper kupił grunt w samym centrum miasta. Wartość nieruchomości to 90 mln zł.

## Amal Clooney - gwiazda wśród prawniczek
 - [https://kobieta.rp.pl/jej-historia/art39501921-amal-clooney-gwiazda-wsrod-prawniczek](https://kobieta.rp.pl/jej-historia/art39501921-amal-clooney-gwiazda-wsrod-prawniczek)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T14:14:39+00:00

Pochodząca z Libanu Amal Clooney, żona George'a Clooneya, opisywana jest jako „genialny umysł prawniczy”, który zajmuje się sprawami o prawdziwym znaczeniu międzynarodowym.

## Tusk i Hołownia ws. NBP. "Wspólnie podejmiemy decyzję"
 - [https://www.rp.pl/banki/art39504821-tusk-i-holownia-ws-nbp-wspolnie-podejmiemy-decyzje](https://www.rp.pl/banki/art39504821-tusk-i-holownia-ws-nbp-wspolnie-podejmiemy-decyzje)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T14:09:34+00:00

Nie zrobimy niczego ws. Narodowego Banku Polskiego, co by naruszyło reputację Polski za granicą - powiedział przewodniczący KO Donald Tusk, odnosząc się do ewentualnego postawienia prezesa NBP przed Trybunałem Stanu.

## W Polsce produkowany będzie Volkswagen Golf
 - [https://moto.rp.pl/tu-i-teraz/art39504461-w-polsce-produkowany-bedzie-volkswagen-golf](https://moto.rp.pl/tu-i-teraz/art39504461-w-polsce-produkowany-bedzie-volkswagen-golf)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T14:00:01+00:00

Volkswagen przeniesie do Polski z Niemiec część produkcji Golfa, jednego z najpopularniejszych aut w Europie – dowiedziała się „Rzeczpospolita”. Decyzję w tej sprawie podjęła w połowie listopada 2023 r. rada nadzorcza Volkswagen AG.

## Śmierć 14-latki z Andrychowa. Trwa kontrola działań policji
 - [https://www.rp.pl/spoleczenstwo/art39504431-smierc-14-latki-z-andrychowa-trwa-kontrola-dzialan-policji](https://www.rp.pl/spoleczenstwo/art39504431-smierc-14-latki-z-andrychowa-trwa-kontrola-dzialan-policji)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T13:53:23+00:00

Trwa wewnętrzna kontrola policyjna, która ma wyjaśnić, czy w sprawie zaginionej 14-latki z Andrychowa funkcjonariusze dopełnili wszelkich procedur. Czternastoletnia Natalia zmarła po tym, jak przez kilka godzin przebywała na mrozie w centrum Andrychowa.

## „Wioska Alzheimera” nagrodzona. Zaprojektowano ją z myślą o seniorach
 - [https://sukces.rp.pl/architektura/art39504631-wioska-alzheimera-nagrodzona-zaprojektowano-ja-z-mysla-o-seniorach](https://sukces.rp.pl/architektura/art39504631-wioska-alzheimera-nagrodzona-zaprojektowano-ja-z-mysla-o-seniorach)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T13:50:05+00:00

„Wioska Alzheimera”, dzielnica we francuskim mieście Dax stworzona z myślą o seniorach i osobach cierpiących na demencję czy chorobę Alzheimera, zdobyła nagrodę architektoniczną w prestiżowym konkursie serwisu Dezeen.

## Śmierć Izabeli z Pszczyny: wiadomo, kto stanie przed sądem
 - [https://www.rp.pl/prawo-karne/art39504641-smierc-izabeli-z-pszczyny-wiadomo-kto-stanie-przed-sadem](https://www.rp.pl/prawo-karne/art39504641-smierc-izabeli-z-pszczyny-wiadomo-kto-stanie-przed-sadem)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T13:46:55+00:00

Do Sądu Rejonowego w Pszczynie wpłynął w czwartek akt oskarżenia w sprawie śmierci ciężarnej Izabeli z Pszczyny. Trzem osobom, które staną przed sądem, grozi pięć lat więzienia.

## Katarzyna Urbańska: To, co wręczamy, świadczy o nas. Jakie prezenty warto kupić bliskim na Gwiazdkę
 - [https://kobieta.rp.pl/styl-zycia/art39502401-katarzyna-urbanska-to-co-wreczamy-swiadczy-o-nas-jakie-prezenty-warto-kupic-bliskim-na-gwiazdke](https://kobieta.rp.pl/styl-zycia/art39502401-katarzyna-urbanska-to-co-wreczamy-swiadczy-o-nas-jakie-prezenty-warto-kupic-bliskim-na-gwiazdke)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T13:40:39+00:00

Skarpety, kapcie, pieniądze, alkohol wciąż są w czołówce najpopularniejszych prezentów pod choinkę, a nie powinno tak być. O tym, dlaczego nie dawać pod choinkę bonu do sklepu, opowiada Katarzyna Urbańska, ekspertka w zakresie etykiety.

## Andrzej Duda mówił o powołaniu rządu Donalda Tuska
 - [https://www.rp.pl/polityka/art39504571-andrzej-duda-mowil-o-powolaniu-rzadu-donalda-tuska](https://www.rp.pl/polityka/art39504571-andrzej-duda-mowil-o-powolaniu-rzadu-donalda-tuska)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T13:29:45+00:00

Mamy demokratyczne zasady i one są realizowane, ostatnie wybory to pokazują przy wielkiej frekwencji, najwyższej jak do tej pory te wybory się odbyły, został wyłoniony zwycięzca wyborów, w tej chwili trwają parlamentarne procedury i konstytucyjne jeśli chodzi o formowanie nowego rządu - mówił w Dubaju, w czasie spotkania z dziennikarzami, prezydent Andrzej Duda.

## Nowe przepisy UE. Mają położyć kres bezkarności kierowców
 - [https://www.rp.pl/prawo-drogowe/art39504531-nowe-przepisy-ue-maja-polozyc-kres-bezkarnosci-kierowcow](https://www.rp.pl/prawo-drogowe/art39504531-nowe-przepisy-ue-maja-polozyc-kres-bezkarnosci-kierowcow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T13:07:33+00:00

Europosłowie chcą, aby decyzje o pozbawieniu prawa jazdy obowiązywały we wszystkich państwach członkowskich UE i aby więcej wykroczeń uruchamiało dochodzenia transgraniczne.

## Zuckerberg rzuca wyzwanie Muskowi w Europie. Znalazł sposób, by obejść regulacje
 - [https://cyfrowa.rp.pl/globalne-interesy/art39504471-zuckerberg-rzuca-wyzwanie-muskowi-w-europie-znalazl-sposob-by-obejsc-regulacje](https://cyfrowa.rp.pl/globalne-interesy/art39504471-zuckerberg-rzuca-wyzwanie-muskowi-w-europie-znalazl-sposob-by-obejsc-regulacje)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T12:59:00+00:00

To może być jedno z największych zaskoczeń w świecie mediów społecznościowych – aplikacja społecznościowa Threads, wbrew wcześniejszym zapowiedziom, jednak zadebiutuje w krajach Unii Europejskiej. I to szybciej niż ktokolwiek mógł sądzić.

## Alert pogodowy dla Polski: W weekend może spaść do 65 cm śniegu
 - [https://www.rp.pl/kraj/art39504411-alert-pogodowy-dla-polski-w-weekend-moze-spasc-do-65-cm-sniegu](https://www.rp.pl/kraj/art39504411-alert-pogodowy-dla-polski-w-weekend-moze-spasc-do-65-cm-sniegu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T12:58:18+00:00

IMGW wydało alarmy pogodowe pierwszego i drugiego stopnia przed intensywnymi opadami śniegu, które mają przejść nad Polską.

## KKLW świadczyła doradztwo transakcyjne na rzecz Pomorskiej Specjalnej Strefy Ekonomicznej Sp. z o.o.
 - [https://www.rp.pl/w-kancelariach/art39504481-kklw-swiadczyla-doradztwo-transakcyjne-na-rzecz-pomorskiej-specjalnej-strefy-ekonomicznej-sp-z-o-o](https://www.rp.pl/w-kancelariach/art39504481-kklw-swiadczyla-doradztwo-transakcyjne-na-rzecz-pomorskiej-specjalnej-strefy-ekonomicznej-sp-z-o-o)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T12:47:44+00:00

Kancelaria KKLW świadczyła doradztwo transakcyjne na rzecz Pomorskiej Specjalnej Strefy Ekonomicznej Sp. z o.o. w przedsięwzięciu zakładającym umorzenie wszystkich udziałów, które w wymienionej spółce przysługiwały Agencji Rozwoju Przemysłu S.A.

## Dlaczego zmarła 14-letnia Natalia z Andrychowa? Są wyniki sekcji zwłok
 - [https://www.rp.pl/spoleczenstwo/art39504401-dlaczego-zmarla-14-letnia-natalia-z-andrychowa-sa-wyniki-sekcji-zwlok](https://www.rp.pl/spoleczenstwo/art39504401-dlaczego-zmarla-14-letnia-natalia-z-andrychowa-sa-wyniki-sekcji-zwlok)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T12:36:05+00:00

Śmierć mózgu w efekcie wylewu i obrzęku była bezpośrednią przyczyną śmierci dziewczynki - pokazuje sekcja zwłok, której wyniki poznała „Rzeczpospolita”.

## Lobby paliwowe na szczycie klimatycznym w Dubaju. Padnie rekord?
 - [https://klimat.rp.pl/klimat/art39504181-lobby-paliwowe-na-szczycie-klimatycznym-w-dubaju-padnie-rekord](https://klimat.rp.pl/klimat/art39504181-lobby-paliwowe-na-szczycie-klimatycznym-w-dubaju-padnie-rekord)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T12:34:09+00:00

Gospodarz szczytu klimatycznego COP28 w Dubaju podkreśla, że konferencja ma mieć charakter inkluzywny, co zdaniem ekspertów klimatycznych oraz aktywistów może oznaczać udział rekordowej liczby lobbystów z branży paliw kopalnych.

## Niemiecka zbrodnia w Łańcucie. Polka zamordowana, bo ukrywała Żydów
 - [https://www.rp.pl/historia/art39504101-niemiecka-zbrodnia-w-lancucie-polka-zamordowana-bo-ukrywala-zydow](https://www.rp.pl/historia/art39504101-niemiecka-zbrodnia-w-lancucie-polka-zamordowana-bo-ukrywala-zydow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T12:19:56+00:00

Instytut Pileckiego upamiętni mieszkankę Łańcuta na Podkarpaciu, którą Niemcy zamordowali za ukrywanie Żydów. Wśród oprawców był żandarm Józef Kokot, który w Markowej zabił rodzinę Ulmów.

## Rosja: Więziony opozycjonista zapłaci grzywnę, bo nie meldował władzom co robi
 - [https://www.rp.pl/polityka/art39504261-rosja-wieziony-opozycjonista-zaplaci-grzywne-bo-nie-meldowal-wladzom-co-robi](https://www.rp.pl/polityka/art39504261-rosja-wieziony-opozycjonista-zaplaci-grzywne-bo-nie-meldowal-wladzom-co-robi)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T12:05:55+00:00

Rosyjski opozycjonista Władimir Kara-Murza został ukarany grzywną w wysokości 50 tys. rubli (ok. 560 dolarów) za to, że nie dostarczył szczegółowego raportu na temat swoich działań, do czego jest zobligowany jako osoba uznana za "zagranicznego agenta". Tymczasem Kara-Murza odsiaduje wyrok 25 lat więzienia za zdradę w kolonii karnej na Syberii.

## Kto nowym prezesem UODO? To on może zastąpić Nowaka
 - [https://www.rp.pl/urzednicy/art39503751-kto-nowym-prezesem-uodo-to-on-moze-zastapic-nowaka](https://www.rp.pl/urzednicy/art39503751-kto-nowym-prezesem-uodo-to-on-moze-zastapic-nowaka)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T11:56:59+00:00

Jak nieoficjalnie dowiedziała się "Rzeczpospolita" do funkcji nowego prezesa Urzędu Ochrony Danych Osobowych jest przymierzany prof. Grzegorz Sibiga  z Instytutu Nauk Prawnych PAN.

## Tomasz Krzyżak i Piotr Litka nominowani do Grand Press za cykl w "Rzeczpospolitej"
 - [https://www.rp.pl/kraj/art39504171-tomasz-krzyzak-i-piotr-litka-nominowani-do-grand-press-za-cykl-w-rzeczpospolitej](https://www.rp.pl/kraj/art39504171-tomasz-krzyzak-i-piotr-litka-nominowani-do-grand-press-za-cykl-w-rzeczpospolitej)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T11:51:00+00:00

Tomasz Krzyżak oraz Piotr Litka zostali nominowani do nagrody Grand Press w kategorii „Dziennikarstwo specjalistyczne i nowe formy dziennikarstwa” za cykl „Kościół tysięcy skrzywdzonych”, który ukazał się w „Rzeczpospolitej”.

## Młodzież czerpie od olimpijczyków
 - [https://www.rp.pl/sport/art39497471-mlodziez-czerpie-od-olimpijczykow](https://www.rp.pl/sport/art39497471-mlodziez-czerpie-od-olimpijczykow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T11:44:41+00:00

Uczniowie pięciu szkół wyłonionych w trzeciej edycji #BieguFairPlayPKOl biorą udział w Olimpijskich Campach Fair Play. To obozy  podczas których uczestnicy mogą doskonalić umiejętności sportowe i czerpać inspiracje od polskich olimpijczyków.

## Pierwsza skarga następcy Ziobry. Zarzuca sądowi "bezduszny formalizm"
 - [https://www.rp.pl/w-sadzie-i-w-urzedzie/art39504111-pierwsza-skarga-nastepcy-ziobry-zarzuca-sadowi-bezduszny-formalizm](https://www.rp.pl/w-sadzie-i-w-urzedzie/art39504111-pierwsza-skarga-nastepcy-ziobry-zarzuca-sadowi-bezduszny-formalizm)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T11:42:03+00:00

Prokurator Generalny Marcin Warchoł skierował do Sądu Najwyższego skargę nadzwyczajną w sprawie kobiety, której skradziono tożsamość. Działanie sądu określił mianem "bezdusznego formalizmu".

## Jeremy Sochan pobił rekord. "Najlepsza noc w NBA"
 - [https://www.rp.pl/koszykowka/art39503731-jeremy-sochan-pobil-rekord-najlepsza-noc-w-nba](https://www.rp.pl/koszykowka/art39503731-jeremy-sochan-pobil-rekord-najlepsza-noc-w-nba)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T11:38:21+00:00

Jeremy Sochan zdobył 33 punkty w meczu z Atlantą Hawks, ale San Antonio Spurs przegrali 135:137. To dla zespołu Polaka 13. porażka z rzędu w NBA.

## Kiedy powołanie nowego rządu? Donald Tusk i Szymon Hołownia uzgodnili szczegóły. "Mamy plan"
 - [https://www.rp.pl/polityka/art39504081-kiedy-powolanie-nowego-rzadu-donald-tusk-i-szymon-holownia-uzgodnili-szczegoly-mamy-plan](https://www.rp.pl/polityka/art39504081-kiedy-powolanie-nowego-rzadu-donald-tusk-i-szymon-holownia-uzgodnili-szczegoly-mamy-plan)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T11:18:00+00:00

Podczas spotkania marszałek Sejmu Szymon Hołownia (Polska 2050) i kandydat na premiera Donald Tusk (PO) ustalili, kiedy - w przypadku nieuzyskania wotum zaufania przez gabinet Mateusza Morawieckiego - Sejm ma wybrać premiera, a premier ma wygłosić exposé. - Zaprzysiężenie zakładamy 13 grudnia, tak jak pan prezydent sugerował - powiedział Tusk.

## Cristiano Ronaldo pozwany za reklamę kryptowalut. Chodzi o miliard dolarów
 - [https://www.rp.pl/prawo-dla-ciebie/art39504021-cristiano-ronaldo-pozwany-za-reklame-kryptowalut-chodzi-o-miliard-dolarow](https://www.rp.pl/prawo-dla-ciebie/art39504021-cristiano-ronaldo-pozwany-za-reklame-kryptowalut-chodzi-o-miliard-dolarow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T11:03:00+00:00

Cristiano Ronaldo został pozwany przez grupę klientów firmy finansowej Binance, zajmującej się obrotem kryptowalutami, które Ronaldo jest ambasadorem tej marki, reklamującym handel tym środkiem płatniczym. Chodzi o kwotę miliarda dolarów - poinformował portal Super Express.

## Kto, poza PiS, popiera rząd Morawieckiego? Premier: Nie potrafię powiedzieć
 - [https://www.rp.pl/polityka/art39503851-kto-poza-pis-popiera-rzad-morawieckiego-premier-nie-potrafie-powiedziec](https://www.rp.pl/polityka/art39503851-kto-poza-pis-popiera-rzad-morawieckiego-premier-nie-potrafie-powiedziec)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T10:59:31+00:00

Chciałem zwrócić uwagę na to, że każdy poseł odpowiada przed swoimi wyborcami, a nie liderami - mówił na konferencji prasowej premier Mateusz Morawiecki.

## Trybunał Konstytucyjny obroni Glapińskiego? Jest wniosek PiS
 - [https://www.rp.pl/prawo-dla-ciebie/art39503831-trybunal-konstytucyjny-obroni-glapinskiego-jest-wniosek-pis](https://www.rp.pl/prawo-dla-ciebie/art39503831-trybunal-konstytucyjny-obroni-glapinskiego-jest-wniosek-pis)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T10:53:22+00:00

Posłowie PiS zaskarżą do Trybunału Konstytucyjnego przepisy ustawy o Trybunale Stanu, które umożliwiłby nowej większości parlamentarnej zawieszenie obecnego prezesa Narodowego Banku Polskiego, Adama Glapińskiego. Tak wynika z nieoficjalnych ustaleń portalu "Wirtualna Polska".

## Komisja ds. Pegasusa. Poseł Konfederacji: Wiemy, że politycy byli podsłuchiwani. Doszło do przestępstw
 - [https://www.rp.pl/polityka/art39502981-komisja-ds-pegasusa-posel-konfederacji-wiemy-ze-politycy-byli-podsluchiwani-doszlo-do-przestepstw](https://www.rp.pl/polityka/art39502981-komisja-ds-pegasusa-posel-konfederacji-wiemy-ze-politycy-byli-podsluchiwani-doszlo-do-przestepstw)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T10:24:29+00:00

Komisja śledcza ds. Pegasusa powinna powstać, by ustalić, kogo dokładnie postawić przed sądem, kogo wysłać do więzienia - powiedział w RMF FM poseł Konfederacji Michał Wawer.

## Hakerzy atakują Booking.com. "To oszustwo działa"
 - [https://www.rp.pl/uslugi/art39503451-hakerzy-atakuja-booking-com-to-oszustwo-dziala](https://www.rp.pl/uslugi/art39503451-hakerzy-atakuja-booking-com-to-oszustwo-dziala)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T10:19:14+00:00

Od marca 2023 roku cyberprzestępcy zaczęli atakować platformę rezerwacyjną Booking.com. Zdaniem ekspertów serwis mógłby robić więcej, by chronić klientów przed oszustami.

## Słabość strefy euro polskim producentom nie straszna
 - [https://www.rp.pl/dane-gospodarcze/art39503241-slabosc-strefy-euro-polskim-producentom-nie-straszna](https://www.rp.pl/dane-gospodarcze/art39503241-slabosc-strefy-euro-polskim-producentom-nie-straszna)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T10:08:00+00:00

PMI, popularny wskaźnik koniunktury w polskim przemyśle przetwórczym, podskoczył w listopadzie najbardziej od lipca 2020 r. Firmy dostrzegają odbicie popytu, zarówno w kraju, jak i za granicą.

## Paragwaj: Urzędnik chciał nawiązać relacje dyplomatyczne z krajem, którego nie ma
 - [https://www.rp.pl/polityka/art39503521-paragwaj-urzednik-chcial-nawiazac-relacje-dyplomatyczne-z-krajem-ktorego-nie-ma](https://www.rp.pl/polityka/art39503521-paragwaj-urzednik-chcial-nawiazac-relacje-dyplomatyczne-z-krajem-ktorego-nie-ma)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T10:06:58+00:00

Arnaldo Chamorro, szef gabinetu ministra rolnictwa Paragwaju, został zwolniony ze stanowiska ponieważ podpisał umowę z państwem, które nie istnieje.

## Radosław Fogiel: Propozycje ws. wiatraków? Ustawa pisana pod dyktando lobbystów
 - [https://www.rp.pl/polityka/art39503661-radoslaw-fogiel-propozycje-ws-wiatrakow-ustawa-pisana-pod-dyktando-lobbystow](https://www.rp.pl/polityka/art39503661-radoslaw-fogiel-propozycje-ws-wiatrakow-ustawa-pisana-pod-dyktando-lobbystow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T10:02:00+00:00

Propozycje przepisów ws. wiatraków wyglądają na ustawę pisaną pod dyktando lobbystów. W tym projekcie są takie kwiatki jak możliwość przełamywania planów zagospodarowania zwykłą uchwałą rady gminy czy budowa wiatraków w parkach krajobrazowych - powiedział w TVP1 Radosław Fogiel.

## Awantura na posiedzeniu KRS. Przewodnicząca: Nawacki powinien przeprosić
 - [https://www.rp.pl/sady-i-trybunaly/art39503361-awantura-na-posiedzeniu-krs-przewodniczaca-nawacki-powinien-przeprosic](https://www.rp.pl/sady-i-trybunaly/art39503361-awantura-na-posiedzeniu-krs-przewodniczaca-nawacki-powinien-przeprosic)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T10:00:00+00:00

Sędzia Maciej Nawacki powinien przeprosić posłankę Kamilę Gasiuk-Pihowicz za swoje słowa - stwierdziła przewodnicząca Krajowej Rady Sądownictwa, Dagmara Pawełczyk-Woicka.

## Prof. Sadurski: Weryfikacja neo-sędziów byłaby błędem z trzech powodów
 - [https://www.rp.pl/sady-i-trybunaly/art39503191-prof-sadurski-weryfikacja-neo-sedziow-bylaby-bledem-z-trzech-powodow](https://www.rp.pl/sady-i-trybunaly/art39503191-prof-sadurski-weryfikacja-neo-sedziow-bylaby-bledem-z-trzech-powodow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T09:33:09+00:00

Nowe konkursy dla neo-sędziów byłyby głęboko niemoralne i krzywdzące dla tych sędziów, którzy którzy byli zbrzydzeni perspektywą proszenia nielegalnej KRS o nominację - uważa prof. Wojciech Sadurski.

## Ranking UEFA: Raków Częstochowa i Legia Warszawa grają dla siebie i Polski
 - [https://www.rp.pl/pilka-nozna/art39503011-ranking-uefa-rakow-czestochowa-i-legia-warszawa-graja-dla-siebie-i-polski](https://www.rp.pl/pilka-nozna/art39503011-ranking-uefa-rakow-czestochowa-i-legia-warszawa-graja-dla-siebie-i-polski)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T09:32:09+00:00

Polska umocniła się na 20. miejscu w Rankingu UEFA i perspektywa dwóch drużyn z PKO BP Ekstraklasy w eliminacjach Ligi Mistrzów staje się coraz bardziej realna. W rankingu pną się także Raków Częstochowa oraz Legia Warszawa.

## Gdula: Ludzie powinni poczuć ulgę. To pierwsza spokojna Wigilia od ośmiu lat
 - [https://www.rp.pl/polityka/art39503341-gdula-ludzie-powinni-poczuc-ulge-to-pierwsza-spokojna-wigilia-od-osmiu-lat](https://www.rp.pl/polityka/art39503341-gdula-ludzie-powinni-poczuc-ulge-to-pierwsza-spokojna-wigilia-od-osmiu-lat)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T09:31:00+00:00

To jest pierwsza od ośmiu lat spokojna Wigilia. To ważne, żeby wykreować takie poczucie i żeby ludzie z nadzieją patrzyli na tę ekipę. Ta ekipa będzie realizować plan w zupełnie innym stylu niż było to robione w ostatnich ośmiu latach - powiedział w programie #RZECZoPOLITYCE prof. Maciej Gdula, Nowa Lewica.

## Duża sieć polskich elektromarketów niespodziewanie ogłasza upadłość
 - [https://www.rp.pl/handel/art39503321-duza-siec-polskich-elektromarketow-niespodziewanie-oglasza-upadlosc](https://www.rp.pl/handel/art39503321-duza-siec-polskich-elektromarketow-niespodziewanie-oglasza-upadlosc)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T09:29:00+00:00

NEONET, polska sieć elektromarketów, otworzyła nowy sklep i niespodziewanie złożyła w sądzie wniosek o upadłość.

## Mural Banksy'ego na temat Brexitu zniszczony. Był wart ponad milion dolarów
 - [https://sukces.rp.pl/sztuka/art39498341-mural-banksy-ego-na-temat-brexitu-zniszczony-byl-wart-ponad-milion-dolarow](https://sukces.rp.pl/sztuka/art39498341-mural-banksy-ego-na-temat-brexitu-zniszczony-byl-wart-ponad-milion-dolarow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T09:24:29+00:00

Mural Banksy’ego komentujący Brexit został zniszczony. Praca zniknęła w wyniku rozbiórki budynku, na ścianie którego została umieszczona. Wcześniej wielokrotnie apelowano o uratwanie muralu.

## Złoty oddaje część rajdu. Euro i dolar mocniejsze
 - [https://www.rp.pl/waluty/art39503151-zloty-oddaje-czesc-rajdu-euro-i-dolar-mocniejsze](https://www.rp.pl/waluty/art39503151-zloty-oddaje-czesc-rajdu-euro-i-dolar-mocniejsze)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T09:17:47+00:00

Euro i dolar umacniają się w piątkowy poranek wobec złotego.

## Spotkanie Hołownia-Tusk. Marszałek Sejmu i lider PO mają mówić o rządzie
 - [https://www.rp.pl/polityka/art39503001-spotkanie-holownia-tusk-marszalek-sejmu-i-lider-po-maja-mowic-o-rzadzie](https://www.rp.pl/polityka/art39503001-spotkanie-holownia-tusk-marszalek-sejmu-i-lider-po-maja-mowic-o-rzadzie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T09:14:32+00:00

Po godz. 10:00 rozpoczęło się spotkanie marszałka Sejmu Szymona Hołowni (Polska 2050) i kandydata nowej większości na premiera Donalda Tuska (PO). Tematem rozmów ma być nowy rząd.

## Orban: Stwórzmy w UE fundusz wsparcia Ukrainy. Niech płaci ten, kto chce
 - [https://www.rp.pl/konflikty-zbrojne/art39503161-orban-stworzmy-w-ue-fundusz-wsparcia-ukrainy-niech-placi-ten-kto-chce](https://www.rp.pl/konflikty-zbrojne/art39503161-orban-stworzmy-w-ue-fundusz-wsparcia-ukrainy-niech-placi-ten-kto-chce)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T09:10:34+00:00

Unia Europejska powinna najpierw podpisać partnerstwo strategiczne z Ukrainą, zamiast rozpoczynać rozmowy o członkostwie Ukrainy w UE - oświadczył Viktor Orban, premier Węgier, na antenie węgierskiego radia.

## Dostałeś takiego maila? Ministerstwo Finansów ostrzega
 - [https://www.rp.pl/podatki/art39503171-dostales-takiego-maila-ministerstwo-finansow-ostrzega](https://www.rp.pl/podatki/art39503171-dostales-takiego-maila-ministerstwo-finansow-ostrzega)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T09:00:37+00:00

Pocztą elektroniczną rozsyłane są fałszywe wiadomości, których autor podszywa się pod Ministerstwo Finansów i informuje o zwrocie nadpłaconego podatku za 2022 r.

## Generatywna rewolucja sztucznej inteligencji
 - [https://www.rp.pl/plus-minus/art39498541-generatywna-rewolucja-sztucznej-inteligencji](https://www.rp.pl/plus-minus/art39498541-generatywna-rewolucja-sztucznej-inteligencji)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T09:00:00+00:00

OpenAI zdążyła już zmienić świat. Niekoniecznie na lepsze.

## Nowe technologie to tylko narzędzia w ludzkich rękach
 - [https://www.rp.pl/plus-minus/art39498551-nowe-technologie-to-tylko-narzedzia-w-ludzkich-rekach](https://www.rp.pl/plus-minus/art39498551-nowe-technologie-to-tylko-narzedzia-w-ludzkich-rekach)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T09:00:00+00:00

Pokładamy wiarę w tymt, że każda nowa technologia przyniesie nam postęp. Ale wraz z nim przychodzi rozczarowanie, bo nie tak wyobrażaliśmy sobie jego konsekwencje. Zapominamy, że technologie nie żyją własnym, niezależnym życiem – to nasza natura decyduje o tym, jak zostaną wykorzystane.

## Rozliczanie PiS i inne powyborcze atrakcje
 - [https://www.rp.pl/plus-minus/art39498571-rozliczanie-pis-i-inne-powyborcze-atrakcje](https://www.rp.pl/plus-minus/art39498571-rozliczanie-pis-i-inne-powyborcze-atrakcje)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T09:00:00+00:00

Mamy dwa rządy: efemerydę Mateusza Morawieckiego i realny, choć wciąż formalnie nieistniejący, rząd Donalda Tuska. Ten pierwszy jest najwyżej mglistą zapowiedzią pokoleniowych zmian w PiS. Ten drugi wywołuje więcej pytań, niż daje odpowiedzi.

## Wojna Rosji z Ukrainą. Dzień 646
 - [https://www.rp.pl/swiat/art39502631-wojna-rosji-z-ukraina-dzien-646](https://www.rp.pl/swiat/art39502631-wojna-rosji-z-ukraina-dzien-646)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T03:42:01+00:00

24 lutego 2022 roku Rosja rozpoczęła pełnowymiarową inwazję na Ukrainę. Porozumienie ws. współpracy granicznej między Finlandią i Rosją przestanie obowiązywać 24 stycznia 2024 roku.

## Możliwe trudności z realizacją części recept i zakupem leków
 - [https://www.rp.pl/zdrowie/art39500631-mozliwe-trudnosci-z-realizacja-czesci-recept-i-zakupem-lekow](https://www.rp.pl/zdrowie/art39500631-mozliwe-trudnosci-z-realizacja-czesci-recept-i-zakupem-lekow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-01T02:00:00+00:00

Przez nieuczciwych lekarzy i aptekarzy pacjenci będą mieli problem z wykupieniem leków recepturowych i psychotropowych.

