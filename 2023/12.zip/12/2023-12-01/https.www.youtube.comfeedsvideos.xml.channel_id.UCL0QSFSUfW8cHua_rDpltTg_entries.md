# Source:Call Me Chato, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCL0QSFSUfW8cHua_rDpltTg, language:en-US

## In search of the MODERN AUDIENCE.
 - [https://www.youtube.com/watch?v=jl_rkKmZHkQ](https://www.youtube.com/watch?v=jl_rkKmZHkQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCL0QSFSUfW8cHua_rDpltTg
 - date published: 2023-12-01T14:50:56+00:00

#FormerNetworkExec #CallMeChato #criticaldrinker
Thanks for watching my channel. Please subscribe, SHARE and touch yourselves.

Call Me Chato T-shirt
https://my-store-6121db.creator-spring.com/listing/ppc-cartoon-t-colour

https://twitter.com/PaulChato
http://www.paulchato.com

