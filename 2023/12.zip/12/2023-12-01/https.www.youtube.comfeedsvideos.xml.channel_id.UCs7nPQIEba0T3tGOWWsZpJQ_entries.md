# Source:Like Stories of Old, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCs7nPQIEba0T3tGOWWsZpJQ, language:en

## Lighting the Beacons, and Other Perfect Movie Metaphors
 - [https://www.youtube.com/watch?v=KUuf_ZzZGVM](https://www.youtube.com/watch?v=KUuf_ZzZGVM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCs7nPQIEba0T3tGOWWsZpJQ
 - date published: 2023-12-01T16:11:35+00:00

Get Nebula for a year, or for the rest of your life (this month only!): https://go.nebula.tv/lsoo
Watch this video as it was meant to be: https://nebula.tv/videos/lsoo-lighting-the-beacons-and-other-perfect-movie-metaphors

Help me make more videos!
Support this channel: https://www.patreon.com/LikeStoriesofOld 
Leave a One-Time Donation: https://www.paypal.me/TomvanderLinden

Facebook: https://www.facebook.com/LikeStoriesofOld 
Instagram: https://www.instagram.com/tom.vd.linden
Twitter: https://twitter.com/Tom_LSOO 

About this video essay: 
Sometimes, whether by design or by accident, the metaphorical weight of a movie scene can become so dense that it captures not just one story element, but the entire story in its fullness, thereby becoming a perfect microcosm of everything that it’s about.

Content:
00:00 An Enigmatic Moment
03:26 Perfect Movie Metaphors
04:49 The Essence of a Rebellion
07:58 One Movie, One Scene
11:42 A Story of Hope and Despair
13:40 Setting the Context
16:20 

