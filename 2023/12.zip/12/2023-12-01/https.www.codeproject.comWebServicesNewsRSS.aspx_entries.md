# Source:CodeProject, URL:https://www.codeproject.com/WebServices/NewsRSS.aspx, language:en-US

## A 'silly' attack made ChatGPT reveal real phone numbers and email addresses
 - [https://www.codeproject.com/script/News/View.aspx?nwid=63451](https://www.codeproject.com/script/News/View.aspx?nwid=63451)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-12-01T05:00:00+00:00

The power of poems?

## AWS Clean Rooms ML lets companies securely collaborate on AI
 - [https://www.codeproject.com/script/News/View.aspx?nwid=63448](https://www.codeproject.com/script/News/View.aspx?nwid=63448)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-12-01T05:00:00+00:00

Called Clean Rooms ML — an offshoot of AWS’ existing Clean Rooms product — the service removes the need for AWS customers to share proprietary data with their outside partners to build, train and deploy AI models.

## Announcing ML.NET 3.0
 - [https://www.codeproject.com/script/News/View.aspx?nwid=63444](https://www.codeproject.com/script/News/View.aspx?nwid=63444)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-12-01T05:00:00+00:00

Deep Learning scenarios were substantially expanded in this release with new capabilities in Object Detection, Named Entity Recognition, and Question Answering.

## Demand for developers remains high
 - [https://www.codeproject.com/script/News/View.aspx?nwid=63455](https://www.codeproject.com/script/News/View.aspx?nwid=63455)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-12-01T05:00:00+00:00

That code isn't going to write itself (if you don't count the CoPilots etc.)

## HP printer software turns up uninvited on Windows systems
 - [https://www.codeproject.com/script/News/View.aspx?nwid=63443](https://www.codeproject.com/script/News/View.aspx?nwid=63443)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-12-01T05:00:00+00:00

That HP printer must be around. Have you looked everywhere?

## How to Use the Automated Machine Learning API With ML.NET
 - [https://www.codeproject.com/script/News/View.aspx?nwid=63449](https://www.codeproject.com/script/News/View.aspx?nwid=63449)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-12-01T05:00:00+00:00

Continuing our ML.NET series, we will take a closer look at the Machine Learning API With ML.NET.

## How to make libraries compatible with native AOT
 - [https://www.codeproject.com/script/News/View.aspx?nwid=63453](https://www.codeproject.com/script/News/View.aspx?nwid=63453)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-12-01T05:00:00+00:00

File, New Project?

## Learn ML
 - [https://www.codeproject.com/script/News/View.aspx?nwid=63446](https://www.codeproject.com/script/News/View.aspx?nwid=63446)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-12-01T05:00:00+00:00

To become an expert in machine learning, you first need a strong foundation in four learning areas: coding, math, ML theory, and how to build your own ML project from start to finish.

## Microsoft Paint adds DALL-E 3 AI support from OpenAI to keep the creative juices flowing in Windows 11
 - [https://www.codeproject.com/script/News/View.aspx?nwid=63454](https://www.codeproject.com/script/News/View.aspx?nwid=63454)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-12-01T05:00:00+00:00

"Must I paint you a picture, about the way that I'd feel?"

## Microsoft opens sources ThreadX under MIT license
 - [https://www.codeproject.com/script/News/View.aspx?nwid=63447](https://www.codeproject.com/script/News/View.aspx?nwid=63447)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-12-01T05:00:00+00:00

The 'Azure RTOS' used in millions of Raspberry Pis is now FOSS

## My favorite features in Visual Studio 17.8
 - [https://www.codeproject.com/script/News/View.aspx?nwid=63442](https://www.codeproject.com/script/News/View.aspx?nwid=63442)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-12-01T05:00:00+00:00

Not mine, his. But you get the idea?

## New Amazon Lex AI features aim to let developers quickly build, enhance bots
 - [https://www.codeproject.com/script/News/View.aspx?nwid=63450](https://www.codeproject.com/script/News/View.aspx?nwid=63450)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-12-01T05:00:00+00:00

Amazon has added generative AI capabilities to Lex, its chatbot development tool.

## Preferred Pedagogical Paradigmatic Protocol
 - [https://www.codeproject.com/script/News/View.aspx?nwid=63445](https://www.codeproject.com/script/News/View.aspx?nwid=63445)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-12-01T05:00:00+00:00

Will this be on the exam?

## Researchers made an IQ test for AI, found they're all pretty stupid
 - [https://www.codeproject.com/script/News/View.aspx?nwid=63452](https://www.codeproject.com/script/News/View.aspx?nwid=63452)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-12-01T05:00:00+00:00

The AI, or the researchers?

## Stable Diffusion XL Turbo can generate AI images as fast as you can type
 - [https://www.codeproject.com/script/News/View.aspx?nwid=63456](https://www.codeproject.com/script/News/View.aspx?nwid=63456)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-12-01T05:00:00+00:00

"The artist is nothing without the gift"

## The Power of Prompting
 - [https://www.codeproject.com/script/News/View.aspx?nwid=63458](https://www.codeproject.com/script/News/View.aspx?nwid=63458)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-12-01T05:00:00+00:00

We published an exploration of the power of prompting strategies that demonstrates how the generalist GPT-4 model can perform as a specialist on medical challenge problem benchmarks.

