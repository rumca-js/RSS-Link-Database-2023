# Source:LinuxGizmos.com, URL:https://linuxgizmos.com/feed/, language:en-US

## Renesas reveals its first 32-bit RISC-V CPU
 - [https://linuxgizmos.com/renesas-reveals-its-first-32-bit-risc-v-cpu](https://linuxgizmos.com/renesas-reveals-its-first-32-bit-risc-v-cpu)
 - RSS feed: https://linuxgizmos.com/feed/
 - date published: 2023-12-01T05:17:40+00:00

Renesas Electronics recently announced the release of its first 32-bit CPU core based on the RISC-V open-standard instruction set architecture (ISA). This development represents Renesas&#8217; entry into the RISC-V based market. The new CPU core will be compatible with Renesas&#8217; e2 studio IDE, in addition to supporting third-party IDEs tailored for RISC-V based MCUs, facilitating [&#8230;]

