# Source:GameSpot - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## What We Want To See At The Game Awards 2023 | Spot On
 - [https://www.youtube.com/watch?v=4VdonFltO4g](https://www.youtube.com/watch?v=4VdonFltO4g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2023-12-01T21:30:00+00:00

This week on Spot On, Tam and Lucy get excited for the Game Awards, and discuss their hopes for this year’s show.

#gaming #TheGameAwards #gamespot

It’s Game Awards season, which means we should be getting some pretty big announcements from a variety of developers and publishers. Host and producer Geoff Keighley usually has a surprise or two up his sleeve too. This week on Spot On, Tam and Lucy discuss what they hope to see from the show, including big announcements from Xbox like a potential release date for Hellblade 2, a glimpse at Wonder Woman, and perhaps, even an appearance from Hideo Kojima and Death Stranding 2.

Timestamps:
00:52 - Beyond Good And Evil
02:02 - Hellblade 2
03:03 - GTA 6
03:27 - Suicide Squad
03:41 - Wonder Woman
04:10 - Elden Ring DLC
04:26 - Wolverine
04:44 - Death Stranding 2

## Cyberpunk 2077 Update 2.1 Overview Showcase
 - [https://www.youtube.com/watch?v=d0o9Dnn_rzc](https://www.youtube.com/watch?v=d0o9Dnn_rzc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2023-12-01T18:01:35+00:00

Today during the Redstream we learned more about the Cyberpunk 2077 update 2.1 coming December 5th, 2023. We got more details on Romance Hangouts, Metro Tourism, updated boss fights, new vehicles and more.

Timestamps
0:00 Intro
1:45 Adding in the Metro System
3:00 How the Metro System works
7:07 Radio on the go
12:05 Updated Adam Smasher Boss Fight
14:40 Replayable Car Races
15:54 New Vehicles
18:08 Updated Motorcycle Combat
20:10 New Car Chases
23:14 New Accessibility Tab
25:00 Outro

#cyberpunk2077 #gaming

