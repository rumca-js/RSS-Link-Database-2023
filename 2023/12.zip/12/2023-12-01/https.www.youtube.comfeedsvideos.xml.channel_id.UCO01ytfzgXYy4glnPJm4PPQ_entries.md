# Source:Matt Walsh, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ, language:en-US

## Matt's Truth
 - [https://www.youtube.com/watch?v=EUPUYwnXHus](https://www.youtube.com/watch?v=EUPUYwnXHus)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2023-12-01T23:00:09+00:00



## Matt Walsh and @LibsofTikTok Creator Chaya Raichik On Being Attacked By Leftists
 - [https://www.youtube.com/watch?v=XsRX_i7sR0s](https://www.youtube.com/watch?v=XsRX_i7sR0s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2023-12-01T19:56:25+00:00

Chaya Raichik joins Matt Walsh to talk about their experiences while battling leftist keyboard warriors.

- - - 

Today’s Sponsors:

Ruff Greens - Get a FREE Jumpstart Trial Bag http://www.RuffGreens.com/Matt
Or call 844-RUFF-700

Genucel Skincare - Exclusive discounts for my listeners! https://bit.ly/428Hmtq

Birch Gold - Text "WALSH" to 989898 to check out Birch Gold’s Holiday Deals! Get FREE Silver today! https://birchgold.com/Walsh

Windshield WOW - Exclusive Discount for my Listeners! Use promo code WALSH at checkout. http://www.WindshieldWOW.com 

- - - 

LIKE & SUBSCRIBE for new videos every day. https://www.youtube.com/c/MattWalsh?sub_confirmation=1

Stop giving your money to woke corporations that hate you. Get your Jeremy’s Razors today at https://bit.ly/3lSGpWa

Watch my hit documentary, “What Is A Woman?” here: https://utm.io/ueSdV

Represent the Sweet Baby Gang by shopping my merch: https://tinyurl.com/y5dscrmm

#MattWalsh #TheMattWalshShow #News #Politics #DailyWire #Wh

## Elon Tells Off Disney
 - [https://www.youtube.com/watch?v=rStudf6ZOjY](https://www.youtube.com/watch?v=rStudf6ZOjY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2023-12-01T16:00:38+00:00



## This Common Worry Women Have Is Based On A Lie
 - [https://www.youtube.com/watch?v=Xx8mIp5YgEo](https://www.youtube.com/watch?v=Xx8mIp5YgEo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2023-12-01T16:00:24+00:00

Genucel - Exclusive discounts for my listeners! https://bit.ly/428Hmtq

Renewal by Andersen - Get your FREE Consultation. Text WALSH to 200-300

The New Yorker asks a tough question: should we stop having kids and embrace our own extinction in order to stop climate change?

Become a DailyWire+ member and watch the full show: https://bit.ly/3xI9PZL

LIKE & SUBSCRIBE for new videos every day. https://www.youtube.com/c/MattWalsh?sub_confirmation=1

Watch the full episode here: Ep.1270 - https://bit.ly/3R1cMxH 

Stop giving your money to woke corporations that hate you. Get your Jeremy’s Razors today at https://bit.ly/3lSGpWa

Watch my hit documentary, “What Is A Woman?” here: https://utm.io/ueSdV

Represent the Sweet Baby Gang by shopping my merch: https://tinyurl.com/y5dscrmm

#MattWalsh #TheMattWalshShow #News #Politics #DailyWire #WhatIsAWoman

## EXCLUSIVE: Matt Walsh’s Character Will SHOCK You In The New Daily Wire Comedy Film
 - [https://www.youtube.com/watch?v=pjkyh2zpgts](https://www.youtube.com/watch?v=pjkyh2zpgts)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2023-12-01T01:30:27+00:00

Matt Walsh talks about his Oscar-winning performance in Daily Wire's new comedy, Lady Ballers. 

Become a DailyWire+ member and watch the full show: https://bit.ly/3xI9PZL

LIKE & SUBSCRIBE for new videos every day. https://www.youtube.com/c/MattWalsh?sub_confirmation=1

Watch the full episode here: Ep.1270 - https://bit.ly/3R1cMxH 

Stop giving your money to woke corporations that hate you. Get your Jeremy’s Razors today at https://bit.ly/3lSGpWa

Watch my hit documentary, “What Is A Woman?” here: https://utm.io/ueSdV

Represent the Sweet Baby Gang by shopping my merch: https://tinyurl.com/y5dscrmm

#MattWalsh #TheMattWalshShow #News #Politics #DailyWire #WhatIsAWoman

