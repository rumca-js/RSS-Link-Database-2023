# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## YouTube utrudnia pomijanie reklam
 - [https://ithardware.pl/aktualnosci/youtube_utrudnia_pomijanie_reklam-30514.html](https://ithardware.pl/aktualnosci/youtube_utrudnia_pomijanie_reklam-30514.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-12-01T20:45:50+00:00

<img src="https://ithardware.pl/artykuly/min/30514_1.jpg" />            YouTube wypowiedział wojnę użytkownikom ad blocker&oacute;w i pr&oacute;buje uniemożliwić im oglądanie film&oacute;w, zachęcając do skorzystania z subskrypcji Premium, kt&oacute;ra wyłącza reklamy. Jak się okazuje platforma Google zaczęła...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/youtube_utrudnia_pomijanie_reklam-30514.html">https://ithardware.pl/aktualnosci/youtube_utrudnia_pomijanie_reklam-30514.html</a></p>

## CD Projekt RED ujawnia szczegóły aktualizacji 2.1 do Cyberpunka 2077
 - [https://ithardware.pl/aktualnosci/cd_projekt_red_ujawnia_szczegoly_aktualizacji_2_1_do_cyberpunka_2077-30513.html](https://ithardware.pl/aktualnosci/cd_projekt_red_ujawnia_szczegoly_aktualizacji_2_1_do_cyberpunka_2077-30513.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-12-01T18:45:00+00:00

<img src="https://ithardware.pl/artykuly/min/30513_1.jpg" />            CD Projekt RED podczas transmisji na żywo om&oacute;wił szczeg&oacute;ły aktualizacji 2.1 do Cyberpunka 2077. Gra dostanie wreszcie metro z prawdziwego zdarzenia (dotychczas trzeba było korzystać z fanowskiej modyfikacji) i kilka innych mniejszych...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/cd_projekt_red_ujawnia_szczegoly_aktualizacji_2_1_do_cyberpunka_2077-30513.html">https://ithardware.pl/aktualnosci/cd_projekt_red_ujawnia_szczegoly_aktualizacji_2_1_do_cyberpunka_2077-30513.html</a></p>

## Action Button również w tańszych iPhonach. Ale dopiero od przyszłej generacji
 - [https://ithardware.pl/aktualnosci/action_button_rowniez_w_tanszych_iphonach_ale_dopiero_od_przyszlej_generacji-30512.html](https://ithardware.pl/aktualnosci/action_button_rowniez_w_tanszych_iphonach_ale_dopiero_od_przyszlej_generacji-30512.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-12-01T17:48:00+00:00

<img src="https://ithardware.pl/artykuly/min/30512_1.jpg" />            Zupełnie nowy przycisk Action Button zastępujący kultowy przełącznik wyciszania jest obecnie dostępny wyłącznie w droższych iPhonach 15 Pro i Pro Max. Dodatek ten może jednak być stosowany r&oacute;wnież na pokładach tańszych modeli. Taką...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/action_button_rowniez_w_tanszych_iphonach_ale_dopiero_od_przyszlej_generacji-30512.html">https://ithardware.pl/aktualnosci/action_button_rowniez_w_tanszych_iphonach_ale_dopiero_od_przyszlej_generacji-30512.html</a></p>

## Rockstar Games ujawnił datę prezentacji Grand Theft Auto 6
 - [https://ithardware.pl/aktualnosci/rockstar_games_ujawnia_kiedy_pokaze_zwiastun_grand_theft_auto_6-30511.html](https://ithardware.pl/aktualnosci/rockstar_games_ujawnia_kiedy_pokaze_zwiastun_grand_theft_auto_6-30511.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-12-01T17:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/30511_1.jpg" />            Grand Theft Auto 6 to najbardziej wyczekiwana gra, kt&oacute;ra nadal nie została oficjalnie zaprezentowana. To jednak zmieni się za niespełna tydzień, bowiem Rockstar Games zdradził, kiedy opublikuje zwiastun produkcji.

Rockstar ujawnia, kiedy...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/rockstar_games_ujawnia_kiedy_pokaze_zwiastun_grand_theft_auto_6-30511.html">https://ithardware.pl/aktualnosci/rockstar_games_ujawnia_kiedy_pokaze_zwiastun_grand_theft_auto_6-30511.html</a></p>

## Apple stawia na silną współpracę z firmą Amkor. Chipy będą pakowane tuż obok zakładu TSMC
 - [https://ithardware.pl/aktualnosci/apple_stawia_na_silna_wspolprace_z_firma_amkor_chipy_beda_pakowane_tuz_obok_zakladu_tsmc-30509.html](https://ithardware.pl/aktualnosci/apple_stawia_na_silna_wspolprace_z_firma_amkor_chipy_beda_pakowane_tuz_obok_zakladu_tsmc-30509.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-12-01T16:54:20+00:00

<img src="https://ithardware.pl/artykuly/min/30509_1.jpg" />            Apple udostępniło nową wiadomość w swoim Newsroomie. Tym razem jednak nie chodzi o zupełnie nowy sprzęt, a o podjęcie silnej wsp&oacute;łpracy z firmą Amkor. Firma zarządzana przez Tima Cooka ogłosiła, że będzie pierwszym i jednocześnie...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/apple_stawia_na_silna_wspolprace_z_firma_amkor_chipy_beda_pakowane_tuz_obok_zakladu_tsmc-30509.html">https://ithardware.pl/aktualnosci/apple_stawia_na_silna_wspolprace_z_firma_amkor_chipy_beda_pakowane_tuz_obok_zakladu_tsmc-30509.html</a></p>

## Turtle Beach ujawnia kontroler bezprzewodowy Stealth Ultra
 - [https://ithardware.pl/aktualnosci/turtle_beach_ujawnia_kontroler_bezprzewodowy_stealth_ultra-30508.html](https://ithardware.pl/aktualnosci/turtle_beach_ujawnia_kontroler_bezprzewodowy_stealth_ultra-30508.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-12-01T15:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/30508_1.jpg" />            Firma&nbsp;Turtle Beach prezentuje kontroler&nbsp;bezprzewodowy Stealth Ultra zaprojektowany dla konsoli Xbox, urządzeń z systemem Android, smart TV oraz komputer&oacute;w.

Stealth Ultra to bezprzewodowy kontroler do gier od&nbsp;Turtle Beach,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/turtle_beach_ujawnia_kontroler_bezprzewodowy_stealth_ultra-30508.html">https://ithardware.pl/aktualnosci/turtle_beach_ujawnia_kontroler_bezprzewodowy_stealth_ultra-30508.html</a></p>

## Czy to chłodzenie to aby nie przesada? Tak wygląda 4-slotowy RTX 4070 Ti z wentylatorami Noctua
 - [https://ithardware.pl/aktualnosci/czy_to_chlodzenie_to_aby_nie_przesada_tak_wyglada_4_slotowy_rtx_4070_ti_z_wentylatorami_noctua-30507.html](https://ithardware.pl/aktualnosci/czy_to_chlodzenie_to_aby_nie_przesada_tak_wyglada_4_slotowy_rtx_4070_ti_z_wentylatorami_noctua-30507.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-12-01T14:30:40+00:00

<img src="https://ithardware.pl/artykuly/min/30507_1.jpg" />            Firma Sycom powiększyła&nbsp;swoją ofertę kart graficznych o kolejny model. Do rodziny Silent Master Graphics dołącza teraz nowy produkt bazujący na układzie graficznym NVIDII. To GeForce RTX 4070 Ti wyposażony w masywne, 4-slotowe chłodzenie,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/czy_to_chlodzenie_to_aby_nie_przesada_tak_wyglada_4_slotowy_rtx_4070_ti_z_wentylatorami_noctua-30507.html">https://ithardware.pl/aktualnosci/czy_to_chlodzenie_to_aby_nie_przesada_tak_wyglada_4_slotowy_rtx_4070_ti_z_wentylatorami_noctua-30507.html</a></p>

## Test AiO SMX Snowy Blackout 360 mm. Wydajnie nie oznacza drogo
 - [https://ithardware.pl/testyirecenzje/test_aio_smx_snowy_blackout_360_mm_wydajnie_nie_oznacza_drogo-30471.html](https://ithardware.pl/testyirecenzje/test_aio_smx_snowy_blackout_360_mm_wydajnie_nie_oznacza_drogo-30471.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-12-01T14:05:10+00:00

<img src="https://ithardware.pl/artykuly/min/30471_1.jpg" />            Nie zawsze trzeba wydawać fortuny, by mieć wydajne chłodzenie wodne typu AiO. Idealnym przykładem jest testowany dziś&nbsp;SMX Snowy Blackout 360 mm, czyli kompaktowe chłodzenie cieczą AiO z radiatorem 360 mm w cenie poniżej 500 zł.&nbsp;SMX...
            <p>Pełna wersja strony <a href="https://ithardware.pl/testyirecenzje/test_aio_smx_snowy_blackout_360_mm_wydajnie_nie_oznacza_drogo-30471.html">https://ithardware.pl/testyirecenzje/test_aio_smx_snowy_blackout_360_mm_wydajnie_nie_oznacza_drogo-30471.html</a></p>

## Meta planuje uruchomienie Threads dla UE w grudniu
 - [https://ithardware.pl/aktualnosci/meta_planuje_uruchomienie_threads_dla_ue_w_grudniu-30502.html](https://ithardware.pl/aktualnosci/meta_planuje_uruchomienie_threads_dla_ue_w_grudniu-30502.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-12-01T13:42:01+00:00

<img src="https://ithardware.pl/artykuly/min/30502_1.jpg" />            Meta blokowało użytkownikom z Unii Europejskiej dostęp do platformy Threads za pośrednictwem obejść VPN. Obecnie firma podejmuje kroki, aby legalnie udostępnić aplikację na rynku europejskim. Firma przygotowuje się do uruchomienia swojej...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/meta_planuje_uruchomienie_threads_dla_ue_w_grudniu-30502.html">https://ithardware.pl/aktualnosci/meta_planuje_uruchomienie_threads_dla_ue_w_grudniu-30502.html</a></p>

## STALKER 2: Heart of Chornobyl - znajmowe twarze na nowym zwiastunie gry. Premiera coraz bliżej
 - [https://ithardware.pl/aktualnosci/stalker_2_heart_of_chornobyl_znajmowe_twarze_na_nowym_zwiastunie_gry_premiera_coraz_blizej-30503.html](https://ithardware.pl/aktualnosci/stalker_2_heart_of_chornobyl_znajmowe_twarze_na_nowym_zwiastunie_gry_premiera_coraz_blizej-30503.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-12-01T12:28:01+00:00

<img src="https://ithardware.pl/artykuly/min/30503_1.jpg" />            Premiera STALKER 2: Heart of Chornobyl zbliża się coraz większymi krokami i podczas PC Gaming Show deweloper GSC Game World przedstawił nowy fabularny zwiastun gry.&nbsp;

W trailerze pojawia się znajoma twarz, nie kto inny jak Strider, kluczowa...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/stalker_2_heart_of_chornobyl_znajmowe_twarze_na_nowym_zwiastunie_gry_premiera_coraz_blizej-30503.html">https://ithardware.pl/aktualnosci/stalker_2_heart_of_chornobyl_znajmowe_twarze_na_nowym_zwiastunie_gry_premiera_coraz_blizej-30503.html</a></p>

## Tajwańska policja jednego dnia zarekwirowała podrabiane kable HDMI o wartości 10 mln zł
 - [https://ithardware.pl/aktualnosci/tajwanska_policja_jednego_dnia_zarekwirowala_podrabiane_kable_hdmi_o_wartosci_10_mln_zl-30501.html](https://ithardware.pl/aktualnosci/tajwanska_policja_jednego_dnia_zarekwirowala_podrabiane_kable_hdmi_o_wartosci_10_mln_zl-30501.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-12-01T11:06:01+00:00

<img src="https://ithardware.pl/artykuly/min/30501_1.jpg" />            Skoordynowany nalot na gł&oacute;wne miasta Tajwanu doprowadził policję do przejęcia znacznej ilości produkt&oacute;w oznaczonych jako &bdquo;HDMI&rdquo;, kt&oacute;re nie miały oficjalnego zezwolenia. Trzeba bowiem pamiętać, że HDMI jest...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/tajwanska_policja_jednego_dnia_zarekwirowala_podrabiane_kable_hdmi_o_wartosci_10_mln_zl-30501.html">https://ithardware.pl/aktualnosci/tajwanska_policja_jednego_dnia_zarekwirowala_podrabiane_kable_hdmi_o_wartosci_10_mln_zl-30501.html</a></p>

## Konkurs adwentowy ITHardware.pl 2023! Dzień #1
 - [https://ithardware.pl/aktualnosci/konkurs_adwentowy_2023_dzien_1-30505.html](https://ithardware.pl/aktualnosci/konkurs_adwentowy_2023_dzien_1-30505.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-12-01T10:38:30+00:00

<img src="https://ithardware.pl/artykuly/min/30505_1.jpg" />            Witajcie! Święta zbliżają się wielkimi krokami, dlatego wracamy do Was, drodzy czytelnicy, z naszym corocznym konkursem adwentowym. Codziennie nowa nagroda!

W tym roku przygotowaliśmy dla Was nagrody o łącznej wartości ok. 20 tys zł. Do...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/konkurs_adwentowy_2023_dzien_1-30505.html">https://ithardware.pl/aktualnosci/konkurs_adwentowy_2023_dzien_1-30505.html</a></p>

## Apple cenzuruje przemówienie Roberta De Niro. Chciał skrytykować Donalda Trumpa
 - [https://ithardware.pl/aktualnosci/apple_cenzuruje_przemowienie_roberta_de_niro_chcial_skrytykowac_donalda_trumpa-30500.html](https://ithardware.pl/aktualnosci/apple_cenzuruje_przemowienie_roberta_de_niro_chcial_skrytykowac_donalda_trumpa-30500.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-12-01T10:36:01+00:00

<img src="https://ithardware.pl/artykuly/min/30500_1.jpg" />            Robert De Niro, kt&oacute;ry ostatnio zagrał w filmie Czas krwawego księżyca, przygotowywał się do wygłoszenia przem&oacute;wienia na Gotham Awards, w kt&oacute;rym ostro miał skrytykować Donalda Trumpa, gdy kierownictwo Apple w ostatniej chwili...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/apple_cenzuruje_przemowienie_roberta_de_niro_chcial_skrytykowac_donalda_trumpa-30500.html">https://ithardware.pl/aktualnosci/apple_cenzuruje_przemowienie_roberta_de_niro_chcial_skrytykowac_donalda_trumpa-30500.html</a></p>

## Dreame prezentuje DreameBOT Z10 Station. Bezprzewodowy, samoopróżniający, samoładujący się odkurzacz
 - [https://ithardware.pl/aktualnosci/dreame_prezentuje_dreamebot_z10_station_to_bezprzewodowy_inteligentny_odkurzacz-30504.html](https://ithardware.pl/aktualnosci/dreame_prezentuje_dreamebot_z10_station_to_bezprzewodowy_inteligentny_odkurzacz-30504.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-12-01T09:38:40+00:00

<img src="https://ithardware.pl/artykuly/min/30504_1.jpg" />            Potężna siła ssania, automatyczne opr&oacute;żnianie i inteligentne funkcje wyznaczają nowe standardy w sprzątaniu dzięki nowemu DreameBot Z10 Station. 

Dreame, firma znana z innowacji w dziedzinie domowych urządzeń czyszczących, ogłasza...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/dreame_prezentuje_dreamebot_z10_station_to_bezprzewodowy_inteligentny_odkurzacz-30504.html">https://ithardware.pl/aktualnosci/dreame_prezentuje_dreamebot_z10_station_to_bezprzewodowy_inteligentny_odkurzacz-30504.html</a></p>

## Plotka: PlayStation 6 z rekonstrukcję ray tracingu, a path tracing nie będzie rzadkością w grach
 - [https://ithardware.pl/aktualnosci/plotka_playstation_6_z_rekonstrukcje_ray_tracingu_a_path_tracing_nie_bedzie_rzadkoscia_w_grach-30499.html](https://ithardware.pl/aktualnosci/plotka_playstation_6_z_rekonstrukcje_ray_tracingu_a_path_tracing_nie_bedzie_rzadkoscia_w_grach-30499.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-12-01T09:17:01+00:00

<img src="https://ithardware.pl/artykuly/min/30499_1.jpg" />            Jak wynika z ostatnich przeciek&oacute;w, Sony szykuje ulepszoną konsolę PlayStation 5 Pro na przyszły rok, ale nie marnuje czasu i pracować ma już także nad PlayStation 6, czyli potężną konsolą nowej generacji.

Znany informator z kanału...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/plotka_playstation_6_z_rekonstrukcje_ray_tracingu_a_path_tracing_nie_bedzie_rzadkoscia_w_grach-30499.html">https://ithardware.pl/aktualnosci/plotka_playstation_6_z_rekonstrukcje_ray_tracingu_a_path_tracing_nie_bedzie_rzadkoscia_w_grach-30499.html</a></p>

## Meizu 21 to flagowiec ze Snapdragonem 8 Gen 3 i 200 MP aparatem głównym
 - [https://ithardware.pl/aktualnosci/meizu_21_to_flagowiec_ze_snapdragonem_8_gen_3_i_200_mp_aparatem_glownym-30498.html](https://ithardware.pl/aktualnosci/meizu_21_to_flagowiec_ze_snapdragonem_8_gen_3_i_200_mp_aparatem_glownym-30498.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-12-01T08:06:58+00:00

<img src="https://ithardware.pl/artykuly/min/30498_1.jpg" />            Meizu zaprezentowało podczas specjalnej imprezy w Chinach sw&oacute;j najnowszy flagowy smartfon z systemem Android &ndash; Meizu 21. Urządzenie jest następcą zeszłorocznego Meizu 20, oferując najnowszy chipset Snapdragon 8 Gen 3, gł&oacute;wny...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/meizu_21_to_flagowiec_ze_snapdragonem_8_gen_3_i_200_mp_aparatem_glownym-30498.html">https://ithardware.pl/aktualnosci/meizu_21_to_flagowiec_ze_snapdragonem_8_gen_3_i_200_mp_aparatem_glownym-30498.html</a></p>

## NEONET złożył wniosek o upadłość. Problemy z zamówieniami klientów
 - [https://ithardware.pl/aktualnosci/neonet_zlozyl_wniosek_o_upadlosc_problemy_z_zamowieniami_klientow-30497.html](https://ithardware.pl/aktualnosci/neonet_zlozyl_wniosek_o_upadlosc_problemy_z_zamowieniami_klientow-30497.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-12-01T07:20:47+00:00

<img src="https://ithardware.pl/artykuly/min/30497_1.jpg" />            Nic tego nie zwiastowało, tymczasem jedna z najpopularniejszych w naszym kraju sieci elektromarket&oacute;w, pod dw&oacute;ch dekadach działalności, złożyła właśnie wniosek o upadłość.&nbsp;

Mowa tu o polskiej sieci NEONET, kt&oacute;ra...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/neonet_zlozyl_wniosek_o_upadlosc_problemy_z_zamowieniami_klientow-30497.html">https://ithardware.pl/aktualnosci/neonet_zlozyl_wniosek_o_upadlosc_problemy_z_zamowieniami_klientow-30497.html</a></p>

