# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Elon's "F*CK YOURSELF" Rallying Cry - What It REALLY Means
 - [https://www.youtube.com/watch?v=XKwkKQJYkMI](https://www.youtube.com/watch?v=XKwkKQJYkMI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2023-12-01T18:19:03+00:00

At the New York Times' DealBook Summit Elon Musk slammed advertisers that have left X

Support Me Directly HERE: https://rb.rumble.com

WATCH me LIVE weekdays on Rumble: https://bit.ly/russellbrand-rumble

