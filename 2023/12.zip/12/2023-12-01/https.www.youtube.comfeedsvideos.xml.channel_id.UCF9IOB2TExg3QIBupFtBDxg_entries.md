# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## Close contact spread
 - [https://www.youtube.com/watch?v=x7xthEl4SXs](https://www.youtube.com/watch?v=x7xthEl4SXs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2023-12-01T09:01:20+00:00

COVID, the untold story. So much more makes sense after this book and my first illuminating discussion with Dr. Craig. Get your copy in the UK here:
https://www.amazon.co.uk/Expired-untold-Dr-Clare-Craig/dp/1739344707

For friends in the US get your copy here, https://www.amazon.com/Expired-untold-Dr-Clare-Craig/dp/1739344707

Have you ever felt the covid story did not entirely add up? Expired contains multiple eye-opening revelations about covid with compelling evidence that provides a coherent, sober and clear explanation that better fits the data we have so far. 
Meticulous research by pathologist Dr Clare Craig sheds light on the largely overlooked evidence of airborne virus transmission, examining twelve related beliefs on spread, lockdowns, asymptomatic infections, and masks. In addition, Expired champions the importance of Western ethical principles, damaged by pandemic actions and calls for their restoration. 
The covid debate has proved incredibly polarising. One side believ

