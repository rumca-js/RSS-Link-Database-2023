# Source:Forbs - innovation, URL:https://www.forbes.com/innovation/feed2, language:en-US

## Advertisers Say They Won’t Return To Elon Musk’s X, At Least For Now
 - [https://www.forbes.com/sites/johnbbrandon/2023/12/01/advertisers-say-they-wont-return-to-elon-musks-x-at-least-for-now](https://www.forbes.com/sites/johnbbrandon/2023/12/01/advertisers-say-they-wont-return-to-elon-musks-x-at-least-for-now)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T22:53:20+00:00

Over the last week, advertisers have been jumping ship from what I’ve often called my favorite social media app.

## Apple Loop: iPhone 16 Pro Design Problems, NameDrop Safety Concerns, Apple Fights Spotify Unwrapped
 - [https://www.forbes.com/sites/ewanspence/2023/12/01/apple-headlines-iphone-16-pro-leak-macbook-air-touchscreen-namedrop-arm-spotify-unwrapped](https://www.forbes.com/sites/ewanspence/2023/12/01/apple-headlines-iphone-16-pro-leak-macbook-air-touchscreen-namedrop-arm-spotify-unwrapped)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T22:33:46+00:00

This week’s Apple headlines; iPhone 16 Pro problems, Apple’s modem misery, the safety of NameDrop, a MacBook touchscreen, UK to investigate Apple dominance, Apple challenges Spotify Unwrapped, and more...

## Android Circuit: Pixel 8 Pro’s Massive Update, Honor’s Folding Strategy, OnePlus 12 Confirmed
 - [https://www.forbes.com/sites/ewanspence/2023/12/01/android-headlines-samsung-galaxy-s24-ultra-pixel8-pro-ai-honor-oneplus-realme](https://www.forbes.com/sites/ewanspence/2023/12/01/android-headlines-samsung-galaxy-s24-ultra-pixel8-pro-ai-honor-oneplus-realme)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T21:55:29+00:00

This week’s Android headlines; Galaxy S24 Ultra design leaks, Pixel 8 Pro AI updates, latest cameraphone shootout, Honor’s folding phone strategy, OnePlus 12 confirmed, Realme’s retail success, and more...

## New Shows And Movies To Stream This Weekend On Netflix, Hulu, HBO Max, Disney+ And More
 - [https://www.forbes.com/sites/erikkain/2023/12/01/new-tv-shows-and-movies-to-stream-this-weekend-on-netflix-hulu--apple-tv-amazon-prime-disney-and-more](https://www.forbes.com/sites/erikkain/2023/12/01/new-tv-shows-and-movies-to-stream-this-weekend-on-netflix-hulu--apple-tv-amazon-prime-disney-and-more)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T21:26:20+00:00

December is here and we have the very first weekend of December to kick back and relax with some new shows and movies.

## Elon Musk Offered 'F U' To Advertisers—They Won't Be Coming Back
 - [https://www.forbes.com/sites/petersuciu/2023/12/01/elon-musk-offered-f-u-to-advertisers-they-wont-be-coming-back](https://www.forbes.com/sites/petersuciu/2023/12/01/elon-musk-offered-f-u-to-advertisers-they-wont-be-coming-back)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T21:13:59+00:00

X has increasingly been in the spotlight—but usually for actions that have been questioned by media watchers.

## The U.S. Is Further Along On Some Climate Goals Than Expected, Biden Administration Says
 - [https://www.forbes.com/sites/alanohnsman/2023/12/01/the-us-is-further-along-on-some-climate-goals-than-expected-biden-administration-says](https://www.forbes.com/sites/alanohnsman/2023/12/01/the-us-is-further-along-on-some-climate-goals-than-expected-biden-administration-says)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T21:02:55+00:00

The COP28 delegation led by Vice President Kamala Harris said new federal efforts to accelerate clean energy launched by the Biden Administration set a meaningful...

## What Is Mycoplasma Pneumonia? Dubbed ‘Walking Pneumonia’ Or ‘White Lung Pneumonia’ And Linked To Pediatric Outbreaks In Ohio And Massachusetts
 - [https://www.forbes.com/sites/ariannajohnson/2023/12/01/what-is-mycoplasma-pneumonia-dubbed-walking-pneumonia-or-white-lung-pneumonia-and-linked-to-pediatric-outbreaks-in-ohio-and-massachusetts](https://www.forbes.com/sites/ariannajohnson/2023/12/01/what-is-mycoplasma-pneumonia-dubbed-walking-pneumonia-or-white-lung-pneumonia-and-linked-to-pediatric-outbreaks-in-ohio-and-massachusetts)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T20:52:30+00:00

Mycoplasma pneumonia infections are typically mild, affect children and young adults, and usually occur during late summer or the fall.

## Does The Dept. Of Transport Know What To Do With $7B For EV Charging?
 - [https://www.forbes.com/sites/bradtempleton/2023/12/01/does-the-dept-of-transport-know-what-to-do-with-7b-for-ev-charging](https://www.forbes.com/sites/bradtempleton/2023/12/01/does-the-dept-of-transport-know-what-to-do-with-7b-for-ev-charging)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T19:20:57+00:00

They have $7B to spend, but previous subsidies caused a broken charging network.   Here's how to do it better

## New Samsung Galaxy S24 Moves Closer To Surprise Early Launch
 - [https://www.forbes.com/sites/jaymcgregor/2023/12/01/new-samsung-galaxy-s24-moves-closer-to-surprise-early-launch](https://www.forbes.com/sites/jaymcgregor/2023/12/01/new-samsung-galaxy-s24-moves-closer-to-surprise-early-launch)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T18:53:22+00:00

Samsung's upcoming Galaxy S24 is moving closer to a January launch according to new details.

## Navigating The AI Landscape: Part 1
 - [https://www.forbes.com/sites/sunilrajaraman/2023/12/01/navigating-the-ai-landscape-part-1](https://www.forbes.com/sites/sunilrajaraman/2023/12/01/navigating-the-ai-landscape-part-1)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T18:41:23+00:00

The basics of AI -including a glossary of terms and key concepts to understand for beginners. This is Part 1 of a series that will cover AI concepts for those interested.

## 17 Business And Social Processes Blockchain Technology Could Improve
 - [https://www.forbes.com/sites/forbestechcouncil/2023/12/01/17-business-and-social-processes-blockchain-technology-could-improve](https://www.forbes.com/sites/forbestechcouncil/2023/12/01/17-business-and-social-processes-blockchain-technology-could-improve)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T18:15:57+00:00

Across various sectors, blockchain technology holds the promise of streamlining operations, enhancing security and improving transparency.

## ‘House Of The Dragon’ Season 2 Posters Show Rhaenyra And Alicent At War, ‘First Look’ Coming Soon
 - [https://www.forbes.com/sites/erikkain/2023/12/01/first-house-of-the-dragon-season-2-posters-show-rhaenyra-and-alicent-at-war-first-look-coming-soon](https://www.forbes.com/sites/erikkain/2023/12/01/first-house-of-the-dragon-season-2-posters-show-rhaenyra-and-alicent-at-war-first-look-coming-soon)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T18:08:04+00:00

There will be fire and blood.

## New Detroit Road Marks Major Step Toward Wireless EV Charging
 - [https://www.forbes.com/sites/billkoenig/2023/12/01/new-detroit-road-marks-major-step-toward-wireless-ev-charging](https://www.forbes.com/sites/billkoenig/2023/12/01/new-detroit-road-marks-major-step-toward-wireless-ev-charging)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T17:44:29+00:00

The city of Detroit and the Michigan Department of Transportation said crews have finished installing a wireless-charging public roadway.

## Wireless Charging For Electric Vehicles May Be Advancing
 - [https://www.forbes.com/sites/billkoenig/2023/12/01/wireless-charging-for-electric-vehicles-may-be-advancing](https://www.forbes.com/sites/billkoenig/2023/12/01/wireless-charging-for-electric-vehicles-may-be-advancing)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T17:44:29+00:00

On Wednesday, the city of Detroit and the Michigan Department of Transportation said crews have finished installing a wireless-charging public roadway.

## Apple’s Latest Reveal Is A Dazzling Christmas Collaboration With David Hockney
 - [https://www.forbes.com/sites/davidphelan/2023/12/01/apples-latest-reveal-is-a-dazzling-christmas-collaboration-with-david-hockney](https://www.forbes.com/sites/davidphelan/2023/12/01/apples-latest-reveal-is-a-dazzling-christmas-collaboration-with-david-hockney)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T17:15:00+00:00

A dazzling light projection is decorating Apple’s London offices, drawn by David Hockney on an iPad. It’s the most remarkable Battersea decoration since Pink Floyd flew a pig between the chimneys.

## Activision Just Killed Call Of Duty’s DMZ Mode, But You Can Still Sort Of Play It For Now
 - [https://www.forbes.com/sites/erikkain/2023/12/01/activision-just-killed-call-of-dutys-dmz-mode-but-you-can-still-sort-of-play-it-for-now](https://www.forbes.com/sites/erikkain/2023/12/01/activision-just-killed-call-of-dutys-dmz-mode-but-you-can-still-sort-of-play-it-for-now)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T17:07:14+00:00

The DMZ is dead.

## Why Global Sustainable Food Systems Needs To Be Addressed At COP28
 - [https://www.forbes.com/sites/daniellenierenberg/2023/12/01/why-global-sustainable-food-systems-needs-to-be-addressed-at-cop28](https://www.forbes.com/sites/daniellenierenberg/2023/12/01/why-global-sustainable-food-systems-needs-to-be-addressed-at-cop28)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T17:01:53+00:00

At COP28, policymakers, experts, scientists, advocates, farmers, young people, and passionate eaters will come together to guide the world forward.

## Apple iOS 17.1.2 iPhone Software Release: Should You Upgrade?
 - [https://www.forbes.com/sites/davidphelan/2023/12/01/apple-ios-1712-iphone-software-release-should-you-upgrade](https://www.forbes.com/sites/davidphelan/2023/12/01/apple-ios-1712-iphone-software-release-should-you-upgrade)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T17:00:52+00:00

The latest iPhone software update is out and it’s focused on fixing security issues. So, should you stay with iOS 17.1.1 or move on up?

## CDC Improves Their Covid-19 Reporting With A New Wastewater Dashboard
 - [https://www.forbes.com/sites/judystone/2023/12/01/cdc-improves-their-covid-19-reporting-with-a-new-wastewater-dashboard](https://www.forbes.com/sites/judystone/2023/12/01/cdc-improves-their-covid-19-reporting-with-a-new-wastewater-dashboard)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T17:00:00+00:00

To their credit, the CDC just unrolled a new wastewater reporting dashboard.

## ‘Call Of Duty: Modern Warfare III’ And ‘Warzone’ Season 1 Release Date, New Maps, Guns, Battle Pass And Everything You Need To Know
 - [https://www.forbes.com/sites/erikkain/2023/12/01/call-of-duty-modern-warfare-iii-and-warzone-season-1-release-date-new-maps-guns-battle-pass-and-everything-you-need-to-know](https://www.forbes.com/sites/erikkain/2023/12/01/call-of-duty-modern-warfare-iii-and-warzone-season-1-release-date-new-maps-guns-battle-pass-and-everything-you-need-to-know)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T16:51:39+00:00

A ton of new content is headed to Modern Warfare III and a completely overhauled Warzone next week.

## Neo Banks In The U.S. Have Grown, But They Aren’t Profitable
 - [https://www.forbes.com/sites/tomgroenfeldt/2023/12/01/neo-banks-in-the-us-have-grown-but-they-arent-profitable](https://www.forbes.com/sites/tomgroenfeldt/2023/12/01/neo-banks-in-the-us-have-grown-but-they-arent-profitable)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T16:32:32+00:00

Neo banks offer features like savings envelopes, free short-term overdrafts and no fees but they struggle to become profitable.

## Nacon Revolution 5 Pro (PS5) Controller Review: A True Contender
 - [https://www.forbes.com/sites/mattgardner1/2023/12/01/nacon-revolution-5-pro-ps5-controller-review-a-true-contender](https://www.forbes.com/sites/mattgardner1/2023/12/01/nacon-revolution-5-pro-ps5-controller-review-a-true-contender)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T16:30:08+00:00

Nacon’s R5P PlayStation 5 controller might be held back by Sony policies, but it still doesn’t diminish this fantastic bit of kit.

## Bitcoin Ordinals Take Center Stage With Nolcha Shows, Miami Art Week
 - [https://www.forbes.com/sites/zengernews/2023/12/01/bitcoin-ordinals-take-center-stage-with-nolcha-shows-miami-art-week](https://www.forbes.com/sites/zengernews/2023/12/01/bitcoin-ordinals-take-center-stage-with-nolcha-shows-miami-art-week)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T16:30:00+00:00

Miami's new Nolcha Shows merges art and Bitcoin innovation, showcasing Ordinal inscriptions with panels, workshops, and AR experiences, redefining art's digital future.

## Qwiet AI Raises ‘Volume’ Of Application Vulnerability Fixes
 - [https://www.forbes.com/sites/adrianbridgwater/2023/12/01/qwiet-ai-raises-volume-of-application-vulnerability-fixes](https://www.forbes.com/sites/adrianbridgwater/2023/12/01/qwiet-ai-raises-volume-of-application-vulnerability-fixes)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T16:28:52+00:00

Software runs on engines. This analogy works in the app security industry, but at a level that helps us explain how vulnerability detection &amp; remediation is now evolving.

## A Psychologist Calls Out The Failings Of ‘Snowplow Parenting’
 - [https://www.forbes.com/sites/traversmark/2023/12/01/snowplow-parenting-and-its-unseen-impact-on-children](https://www.forbes.com/sites/traversmark/2023/12/01/snowplow-parenting-and-its-unseen-impact-on-children)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T16:15:52+00:00

Clearing obstacles or clouding autonomy? Here are the subtle dangers that snowplow parenting exposes your child to.

## 19 Tech Experts Bust Common Cybersecurity Myths And Misconceptions
 - [https://www.forbes.com/sites/forbestechcouncil/2023/12/01/19-tech-experts-bust-common-cybersecurity-myths-and-misconceptions](https://www.forbes.com/sites/forbestechcouncil/2023/12/01/19-tech-experts-bust-common-cybersecurity-myths-and-misconceptions)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T16:15:00+00:00

Numerous myths and misconceptions persist—even among tech leaders—leading many companies to make misguided decisions when developing their cybersecurity strategies.

## ‘Baldur’s Gate 3’ Patch Notes: A New Ending, Two New Game Modes And Tons Of Bug Fixes In Patch 5
 - [https://www.forbes.com/sites/erikkain/2023/12/01/baldurs-gate-3-patch-notes-a-new-ending-two-new-game-modes-and-tons-of-bug-fixes-in-patch-5](https://www.forbes.com/sites/erikkain/2023/12/01/baldurs-gate-3-patch-notes-a-new-ending-two-new-game-modes-and-tons-of-bug-fixes-in-patch-5)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T16:00:34+00:00

Baldur’s Gate 3 just got even bigger and better with Larian’s latest update, Patch 5, expanding the game and fixing many of its remaining bugs.

## Survey Reveals Female Founder Optimism Is At A 5 Year Low
 - [https://www.forbes.com/sites/marenbannon/2023/12/01/survey-reveals-female-founder-optimism-is-at-a-5-year-low](https://www.forbes.com/sites/marenbannon/2023/12/01/survey-reveals-female-founder-optimism-is-at-a-5-year-low)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T15:50:49+00:00

A survey of over 400 founders revealed optimism about raising capital is at a 5 year high. Female founders, however, feel much differently about the funding environment.

## Cyberpunk 2077’s 2.1 Update Will Add NCART, Romance Hangouts And More
 - [https://www.forbes.com/sites/paultassi/2023/12/01/cyberpunk-2077s-21-update-will-add-ncart-romance-hangouts-and-more](https://www.forbes.com/sites/paultassi/2023/12/01/cyberpunk-2077s-21-update-will-add-ncart-romance-hangouts-and-more)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T15:42:00+00:00

CDPR is adding a bunch of requested features and content items to Cyberpunk 2077 in its new 2.1 patch, which was just revealed on stream and is out soon.

## Advancing Pain Management: Exploring The Frontiers Of Electroanalgesia
 - [https://www.forbes.com/sites/williamhaseltine/2023/12/01/advancing-pain-management-exploring-the-frontiers-of-electroanalgesia](https://www.forbes.com/sites/williamhaseltine/2023/12/01/advancing-pain-management-exploring-the-frontiers-of-electroanalgesia)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T15:19:07+00:00

Chronic pain is among the most common ailments in the United States, affecting roughly 100 million adult Americans.

## Deconstructing Telemetry Pipelines: Streamlining Data Management For The Future
 - [https://www.forbes.com/sites/forbestechcouncil/2023/12/01/deconstructing-telemetry-pipelines-streamlining-data-management-for-the-future](https://www.forbes.com/sites/forbestechcouncil/2023/12/01/deconstructing-telemetry-pipelines-streamlining-data-management-for-the-future)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T15:15:00+00:00

The primary objectives of telemetry pipelines are to reduce data clutter, add context and save resources.

## Does Your Tech Startup Really Need A Founding CTO?
 - [https://www.forbes.com/sites/forbestechcouncil/2023/12/01/does-your-tech-startup-really-need-a-founding-cto](https://www.forbes.com/sites/forbestechcouncil/2023/12/01/does-your-tech-startup-really-need-a-founding-cto)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T15:00:00+00:00

Are CTOs a must-have on every startup team, or are there other routes that can offer the unique insights this position provides?

## How To Boost Recruiting And Retention Efforts With Employee Benefits
 - [https://www.forbes.com/sites/quora/2023/12/01/how-to-boost-recruiting-and-retention-efforts-with-employee-benefits](https://www.forbes.com/sites/quora/2023/12/01/how-to-boost-recruiting-and-retention-efforts-with-employee-benefits)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T15:00:00+00:00

What employee benefits should employers consider for boosting their recruiting and retention efforts? Answer by Angela Surra, Principal Benefits Expert at Mineral HR &amp; Compliance

## Writing Accurate AI Prompts For  Best Results In An AI Chatbot
 - [https://www.forbes.com/sites/timbajarin/2023/12/01/writing-accurate-ai-prompts-for--best-results-in-an-ai-chatbot](https://www.forbes.com/sites/timbajarin/2023/12/01/writing-accurate-ai-prompts-for--best-results-in-an-ai-chatbot)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T15:00:00+00:00

Learning to write prompts that chatbots understand will give a person the best results for their queries.

## Technological Innovations For Enhanced Casino Security
 - [https://www.forbes.com/sites/forbestechcouncil/2023/12/01/technological-innovations-for-enhanced-casino-security](https://www.forbes.com/sites/forbestechcouncil/2023/12/01/technological-innovations-for-enhanced-casino-security)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T14:45:00+00:00

The alarming nature of these security concerns necessitates prompt action. Technological advancements can significantly bolster casino security.

## Why AI Is Popular Now—And Two Ways To Use It Better
 - [https://www.forbes.com/sites/forbestechcouncil/2023/12/01/why-ai-is-popular-now-and-two-ways-to-use-it-better](https://www.forbes.com/sites/forbestechcouncil/2023/12/01/why-ai-is-popular-now-and-two-ways-to-use-it-better)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T14:30:00+00:00

As a business tool, it’s critical that AI is applied to a specific area or "domain" to solve its problems and open the door to other unforeseen opportunities.

## The Good News You Don’t Often Hear About Sustainability
 - [https://www.forbes.com/sites/sap/2023/12/01/the-good-news-you-dont-often-hear-about-sustainability](https://www.forbes.com/sites/sap/2023/12/01/the-good-news-you-dont-often-hear-about-sustainability)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T14:20:27+00:00

Having the right sustainability data means understanding where the entire business stands by establishing a baseline everyone can act on at any given moment.

## Rockstar Reveals ‘GTA 6’ Trailer Release Date And Time In December
 - [https://www.forbes.com/sites/paultassi/2023/12/01/rockstar-reveals-gta-6-trailer-release-date-and-time-in-december](https://www.forbes.com/sites/paultassi/2023/12/01/rockstar-reveals-gta-6-trailer-release-date-and-time-in-december)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T14:17:48+00:00

Here is the GTA 6 trailer release date and time, which is imminent, as Rockstar presents the first look at the Grand Theft Auto game players have waited a decade for.

## Scope Creep: Managing Clients' Desire For Ever-Expanding Features
 - [https://www.forbes.com/sites/forbestechcouncil/2023/12/01/scope-creep-managing-clients-desire-for-ever-expanding-features](https://www.forbes.com/sites/forbestechcouncil/2023/12/01/scope-creep-managing-clients-desire-for-ever-expanding-features)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T14:15:00+00:00

If you've never seen scope creep before, count yourself lucky. But when it happens to you—and it will—the rest of this article will help you manage the situation better.

## Strategies For Measuring And Improving InfoSec Efficiency
 - [https://www.forbes.com/sites/davidbalaban/2023/12/01/strategies-for-measuring-and-improving-infosec-efficiency](https://www.forbes.com/sites/davidbalaban/2023/12/01/strategies-for-measuring-and-improving-infosec-efficiency)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T14:14:25+00:00

Explore key strategies for boosting InfoSec efficiency. Learn about risk assessment, proactive planning, and integrating a strong security culture.

## Tips To Combat Medical Misinformation And Rebuild Trust
 - [https://www.forbes.com/sites/omerawan/2023/12/01/tips-to-combat-medical-misinformation-and-rebuild-trust](https://www.forbes.com/sites/omerawan/2023/12/01/tips-to-combat-medical-misinformation-and-rebuild-trust)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T14:05:39+00:00

Given the potential impact misinformation can have with respect to public health, addressing strategies to combat medical misinformation remains paramount.

## When Should You Replace A Cybersecurity Vendor?
 - [https://www.forbes.com/sites/forbestechcouncil/2023/12/01/when-should-you-replace-a-cybersecurity-vendor](https://www.forbes.com/sites/forbestechcouncil/2023/12/01/when-should-you-replace-a-cybersecurity-vendor)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T14:00:00+00:00

What reasons would a CISO need to even consider replacing an existing solution?

## The 10 Games That Survived The Game Awards’ Players Choice Voting
 - [https://www.forbes.com/sites/paultassi/2023/12/01/the-10-games-that-survived-the-game-awards-players-choice-voting](https://www.forbes.com/sites/paultassi/2023/12/01/the-10-games-that-survived-the-game-awards-players-choice-voting)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T13:53:48+00:00

Here are the ten games that have survived round 1 of Player's Choice Voting for The Game Awards, ranging from Hogwarts Legacy to Genshin Impact to Lies of P.

## The Art Of Incremental Improvements: Innovate From Within Your Culture
 - [https://www.forbes.com/sites/forbestechcouncil/2023/12/01/the-art-of-incremental-improvements-innovate-from-within-your-culture](https://www.forbes.com/sites/forbestechcouncil/2023/12/01/the-art-of-incremental-improvements-innovate-from-within-your-culture)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T13:45:00+00:00

Every company is staffed by employees who have ideas about how the business runs.

## World AIDS Day 2023: Thinking Locally About The Global HIV/AIDS Epidemic
 - [https://www.forbes.com/sites/davewessner/2023/12/01/world-aids-day-2023-thinking-locally-about-the-global-hivaids-epidemic](https://www.forbes.com/sites/davewessner/2023/12/01/world-aids-day-2023-thinking-locally-about-the-global-hivaids-epidemic)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T13:31:58+00:00

On this World AIDS Day, the HIV landscape looks a lot different than it did on the first WAD in 1988. But more needs to be done. Community organizations can help.

## Skyhawk Launches Proactive AI-Based Cloud Security
 - [https://www.forbes.com/sites/waynerash/2023/12/01/skyhawk-launches-proactive-ai-based-cloud-security](https://www.forbes.com/sites/waynerash/2023/12/01/skyhawk-launches-proactive-ai-based-cloud-security)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T13:30:00+00:00

AI-based anti-malware solutions have begun to show up. One of the first is Skyhawk Security, which has upgraded its Synthesis platform to work in real time examining vulnerabilities and perform posture management.

## Why Visibility Is A Crucial Component Of SaaS Security
 - [https://www.forbes.com/sites/forbestechcouncil/2023/12/01/why-visibility-is-a-crucial-component-of-saas-security](https://www.forbes.com/sites/forbestechcouncil/2023/12/01/why-visibility-is-a-crucial-component-of-saas-security)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T13:30:00+00:00

If anyone with a credit card and email can expense a SaaS application, it can easily open your organization up to risk.

## Warning: Don’t Buy This ‘Destiny 2’ Riven Coil Wish That Will Kill You
 - [https://www.forbes.com/sites/paultassi/2023/12/01/warning-dont-buy-this-destiny-2-riven-coil-wish-that-will-kill-you](https://www.forbes.com/sites/paultassi/2023/12/01/warning-dont-buy-this-destiny-2-riven-coil-wish-that-will-kill-you)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T13:28:55+00:00

There is a new Coil Wish you can buy in Destiny 2 from Riven that will throttle you within an inch of your life, so you're going to want to avoid it at all costs.

## U.S. Life Expectancy Rebounds Modestly, But Public Health Crisis Continues
 - [https://www.forbes.com/sites/joshuacohen/2023/12/01/us-life-expectancy-rebounds-modestly-but-public-health-crisis-continues](https://www.forbes.com/sites/joshuacohen/2023/12/01/us-life-expectancy-rebounds-modestly-but-public-health-crisis-continues)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T13:15:04+00:00

U.S. life expectancy added 1.1 years from 2021 to 2022. But the public health crisis continues unabated, as fewer resources are being allocated to preventive care.

## Generative AI: 20 Ways It Can Boost A Company’s Bottom Line
 - [https://www.forbes.com/sites/forbestechcouncil/2023/12/01/generative-ai-20-ways-it-can-boost-a-companys-bottom-line](https://www.forbes.com/sites/forbestechcouncil/2023/12/01/generative-ai-20-ways-it-can-boost-a-companys-bottom-line)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T13:15:00+00:00

Organizations are exploring innovative ways to monetize generative AI, both in terms of creating public-facing content and lowering overall production costs.

## How AI Can Help With Business’s Context-Switching Problem
 - [https://www.forbes.com/sites/forbestechcouncil/2023/12/01/how-ai-can-help-with-businesss-context-switching-problem](https://www.forbes.com/sites/forbestechcouncil/2023/12/01/how-ai-can-help-with-businesss-context-switching-problem)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T13:15:00+00:00

Forcing employees to switch between endless tabs, websites and applications is a productivity killer.

## Pediatricians Are Now Recommending Goat Milk Formula For Infants
 - [https://www.forbes.com/sites/ninashapiro/2023/12/01/pediatricians-are-now-recommending-goat-milk-formula-for-infants](https://www.forbes.com/sites/ninashapiro/2023/12/01/pediatricians-are-now-recommending-goat-milk-formula-for-infants)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T13:15:00+00:00

The American Academy of Pediatrics has now included goat milk-based formula as a nutritional option for infants.

## Action And Activism: Gen Z Influence On Holiday Shopping
 - [https://www.forbes.com/sites/sap/2023/12/01/action-and-activism-gen-z-influence-on-holiday-shopping](https://www.forbes.com/sites/sap/2023/12/01/action-and-activism-gen-z-influence-on-holiday-shopping)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T13:13:40+00:00

Gen Z will spend 15% more this holiday compared to 2022, the widest percentage increase of any age group. Let’s take a closer look at how this impacts your business.

## Fortnite’s Chapter 5 Battle Pass Has Leaked, With Wild Crossover Skins
 - [https://www.forbes.com/sites/paultassi/2023/12/01/fortnites-chapter-5-battle-pass-has-leaked-with-wild-crossover-skins](https://www.forbes.com/sites/paultassi/2023/12/01/fortnites-chapter-5-battle-pass-has-leaked-with-wild-crossover-skins)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T13:10:35+00:00

Here are the leaked skins in Fortnite's new Chapter 5 Season 1 battle pass, including a video game legend and a crossover years in the making.

## ‘Lord Of The Rings’ And ‘Game Of Thrones’ Fans Need To Read This Fantasy Trilogy ASAP
 - [https://www.forbes.com/sites/erikkain/2023/12/01/lord-of-the-rings-and-game-of-thrones-fans-need-to-read-this-fantasy-trilogy-asap](https://www.forbes.com/sites/erikkain/2023/12/01/lord-of-the-rings-and-game-of-thrones-fans-need-to-read-this-fantasy-trilogy-asap)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T13:07:00+00:00

This week, I finished the third book in the very long, very epic fantasy series I’ve been reading for the past few months.

## Unveiling The Secrets Of Planktivorous Sharks
 - [https://www.forbes.com/sites/melissacristinamarquez/2023/12/01/unveiling-the-secrets-of-planktivorous-sharks](https://www.forbes.com/sites/melissacristinamarquez/2023/12/01/unveiling-the-secrets-of-planktivorous-sharks)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T13:02:00+00:00

Embarking on a 27-year journey into the depths of Cocos Island's waters, researchers have unveiled the secrets of planktivorous elasmobranchs.

## Sherwin-Williams ‘Blue Steel’ Process Fights Fires At EV Battery Plants
 - [https://www.forbes.com/sites/edgarsten/2023/12/01/sherwin-williams-blue-steel-process-fights-fires-at-ev-battery-plants](https://www.forbes.com/sites/edgarsten/2023/12/01/sherwin-williams-blue-steel-process-fights-fires-at-ev-battery-plants)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T13:00:47+00:00

A process developed by Sherwin-Williams is aimed at preventing plants that product batteries for electric vehicles from collapsing in the event of a fire.

## Doing More With Less: Cybersecurity Tools And Budget Efficiency
 - [https://www.forbes.com/sites/forbestechcouncil/2023/12/01/doing-more-with-less-cybersecurity-tools-and-budget-efficiency](https://www.forbes.com/sites/forbestechcouncil/2023/12/01/doing-more-with-less-cybersecurity-tools-and-budget-efficiency)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T13:00:00+00:00

Optimizing your security stack, and in turn, your budget, doesn’t have to be a guessing game.

## Megafire And New AI/ML Models For Change
 - [https://www.forbes.com/sites/johnwerner/2023/12/01/megafire-and-new-aiml-models-for-change](https://www.forbes.com/sites/johnwerner/2023/12/01/megafire-and-new-aiml-models-for-change)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T12:51:48+00:00

The problem is one that lots of people understand intuitively – in changing the habitats and the landscape of the continent, we started to suppress natural fire cycles...

## The Impact Of Biomanufacturing On The Automotive Industry
 - [https://www.forbes.com/sites/forbestechcouncil/2023/12/01/the-impact-of-biomanufacturing-on-the-automotive-industry](https://www.forbes.com/sites/forbestechcouncil/2023/12/01/the-impact-of-biomanufacturing-on-the-automotive-industry)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T12:45:00+00:00

The automotive industry is witnessing several technological revolutions related to biomanufacturing.

## Building Customer Loyalty In B2B: Strategies That Really Work
 - [https://www.forbes.com/sites/forbestechcouncil/2023/12/01/building-customer-loyalty-in-b2b-strategies-that-really-work](https://www.forbes.com/sites/forbestechcouncil/2023/12/01/building-customer-loyalty-in-b2b-strategies-that-really-work)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T12:30:00+00:00

In the competitive world of B2B, customer loyalty isn't just a nice-to-have; it's a must-have for long-term success.

## Giant Coconut-Gnawing Rat Captured Alive On Camera For First Time
 - [https://www.forbes.com/sites/amandakooser/2023/12/01/giant-coconut-gnawing-rat-captured-alive-on-camera-for-first-time](https://www.forbes.com/sites/amandakooser/2023/12/01/giant-coconut-gnawing-rat-captured-alive-on-camera-for-first-time)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T12:30:00+00:00

Captivating images of giant rats from the Solomon Islands have given researchers a valuable glimpse into the secret world of a critically endangered animal.

## Cult Puzzle Game ‘Ballance’ Gets Re-Release For 20th Anniversary
 - [https://www.forbes.com/sites/mattgardner1/2023/12/01/cult-puzzle-game-ballance-gets-re-release-for-20th-anniversary](https://www.forbes.com/sites/mattgardner1/2023/12/01/cult-puzzle-game-ballance-gets-re-release-for-20th-anniversary)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T12:23:36+00:00

The classic marble-rolling game from the early 2000s is getting a well-deserved birthday re-release in early 2024.

## Okay, Sam Altman Is Back At OpenAI
 - [https://www.forbes.com/sites/johnwerner/2023/12/01/okay-sam-altman-is-back-at-openai](https://www.forbes.com/sites/johnwerner/2023/12/01/okay-sam-altman-is-back-at-openai)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T12:20:40+00:00

Alternate titles Of Course Altman is Back at OpenAI It's been a whirlwind, to say the least – but it looks like the figure who was so central to chatGPT is going to be...

## Any Season Is The Right One To Manage Shipping Agreements
 - [https://www.forbes.com/sites/forbestechcouncil/2023/12/01/any-season-is-the-right-one-to-manage-shipping-agreements](https://www.forbes.com/sites/forbestechcouncil/2023/12/01/any-season-is-the-right-one-to-manage-shipping-agreements)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T12:15:00+00:00

For any business that relies on parcel shipping, costs can easily spiral out of control if not given enough forethought and attention.

## Why Teams, Not Managers, Should Own Developer Productivity
 - [https://www.forbes.com/sites/forbestechcouncil/2023/12/01/why-teams-not-managers-should-own-developer-productivity](https://www.forbes.com/sites/forbestechcouncil/2023/12/01/why-teams-not-managers-should-own-developer-productivity)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T12:00:00+00:00

In this article, we’ll cover three reasons why developer productivity should be owned by the team.

## Beyond Bots: How Generative AI Can Help Companies Reimagine Customer Experience
 - [https://www.forbes.com/sites/forbestechcouncil/2023/12/01/beyond-bots-how-generative-ai-can-help-companies-reimagine-customer-experience](https://www.forbes.com/sites/forbestechcouncil/2023/12/01/beyond-bots-how-generative-ai-can-help-companies-reimagine-customer-experience)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T11:45:00+00:00

To get to the real potential of generative AI, companies need to focus on customer experience.

## Navigating Sustainability: Location Technology's Role In Greener Transportation
 - [https://www.forbes.com/sites/forbestechcouncil/2023/12/01/navigating-sustainability-location-technologys-role-in-greener-transportation](https://www.forbes.com/sites/forbestechcouncil/2023/12/01/navigating-sustainability-location-technologys-role-in-greener-transportation)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T11:30:00+00:00

Location technology offers several promising ways to address environmental challenges.

## What DRESSX’s New Desktop Camera Means For Zoom, Google Meet, Teams
 - [https://www.forbes.com/sites/stephaniehirschmiller/2023/12/01/what-dressxs-new-desktop-camera-means-for-zoom-google-meet-teams](https://www.forbes.com/sites/stephaniehirschmiller/2023/12/01/what-dressxs-new-desktop-camera-means-for-zoom-google-meet-teams)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T11:18:44+00:00

The B2B based video conferencing environment is an underexploited area for digital fashion and could prove a lucrative one.

## 3 Ways Better Data Can Change Employee Benefits For Good
 - [https://www.forbes.com/sites/forbestechcouncil/2023/12/01/3-ways-better-data-can-change-employee-benefits-for-good](https://www.forbes.com/sites/forbestechcouncil/2023/12/01/3-ways-better-data-can-change-employee-benefits-for-good)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T11:15:00+00:00

A new reality is emerging as insurance carriers and benefits software begin to make real-time connectivity a priority.

## Esports Awards 2023 Winners: Faker, Team Vitality, Riot Get Top Honors
 - [https://www.forbes.com/sites/mattgardner1/2023/12/01/esports-awards-2023-winners-t1-team-vitality-riot-take-top-honors](https://www.forbes.com/sites/mattgardner1/2023/12/01/esports-awards-2023-winners-t1-team-vitality-riot-take-top-honors)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T11:00:29+00:00

The Esports Awards handed out 30 awards in Las Vegas, with a few big winners standing out in a competitive field.

## This Is The Only Way To Save Healthcare In The U.S.
 - [https://www.forbes.com/sites/steveforbes/2023/12/01/this-is-the-only-way-to-save-healthcare-in-the-us](https://www.forbes.com/sites/steveforbes/2023/12/01/this-is-the-only-way-to-save-healthcare-in-the-us)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T11:00:00+00:00

The only way to save American healthcare is to put patients—not third parties—truly in charge. Two bills making their way through Congress will help this process.

## This Week In XR: Pica Labs Text-To- Video Gen AI Scores $55 Million, XR Companies In The Money
 - [https://www.forbes.com/sites/charliefink/2023/12/01/this-week-in-xr-pica-labs-text-tovideo-gen-ai-scores-55-million-xr-companies-in-the-money](https://www.forbes.com/sites/charliefink/2023/12/01/this-week-in-xr-pica-labs-text-tovideo-gen-ai-scores-55-million-xr-companies-in-the-money)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T11:00:00+00:00

HoloLight, VRgineers, and Thirdverse also raised money this week.

## What Financial Institutions Should Know About APIs
 - [https://www.forbes.com/sites/forbestechcouncil/2023/12/01/what-financial-institutions-should-know-about-apis](https://www.forbes.com/sites/forbestechcouncil/2023/12/01/what-financial-institutions-should-know-about-apis)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T11:00:00+00:00

Financial institutions are historically slow to adapt to digital changes, and compliance is often cited as a reason why, but that’s becoming an increasingly weak excuse.

## FiiO’s Innovative New Keyboard Can Play Music While You Work
 - [https://www.forbes.com/sites/marksparrow/2023/12/01/fiios-innovative-new-keyboard-can-play-music-while-you-work](https://www.forbes.com/sites/marksparrow/2023/12/01/fiios-innovative-new-keyboard-can-play-music-while-you-work)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T10:54:56+00:00

If you enjoy listening to music, this innovative KB3 keyboard from FiiO includes a DAC and amplifier so you can plug your headphones in and listen while you work.

## iOS 17.1.2—Update Now Warning Issued To All iPhone Users
 - [https://www.forbes.com/sites/kateoflahertyuk/2023/12/01/ios-1712-update-now-warning-issued-to-all-iphone-users](https://www.forbes.com/sites/kateoflahertyuk/2023/12/01/ios-1712-update-now-warning-issued-to-all-iphone-users)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T09:01:28+00:00

Apple has released iOS 17.1.2, an emergency iPhone update fixing two flaws—both of which are being used in real-life attacks.

## How Online Influencers And Idols Are Using Generative AI
 - [https://www.forbes.com/sites/bernardmarr/2023/12/01/how-online-influencers-and-idols-are-using-generative-ai](https://www.forbes.com/sites/bernardmarr/2023/12/01/how-online-influencers-and-idols-are-using-generative-ai)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T06:17:32+00:00

Discover how generative AI is revolutionizing influencer marketing, from automating content creation and fan engagement to the rise of virtual idols.

## Billionaire Palmer Luckey Unveils A New Jet-Powered Drone — And It Looks Bonkers
 - [https://www.forbes.com/sites/jeremybogaisky/2023/12/01/billionaire-palmer-luckey-anduril-drone](https://www.forbes.com/sites/jeremybogaisky/2023/12/01/billionaire-palmer-luckey-anduril-drone)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T05:01:02+00:00

The fast autonomous drone, called Roadrunner, is designed by Luckey’s Anduril Industries to intercept and blow up enemy aircraft.

## Year In AI: ChatGPT Valued At $86 Billion On Birthday; Google Rides On
 - [https://www.forbes.com/sites/martineparis/2023/11/30/year-in-ai-chatgpt-now-valued-at-86-billion-google-takes-epic-ride](https://www.forbes.com/sites/martineparis/2023/11/30/year-in-ai-chatgpt-now-valued-at-86-billion-google-takes-epic-ride)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T04:26:32+00:00

Happy Birthday, ChatGPT! The year began with the chatbot's viral launch and ended with it talking. Along the way billions were raised. A look at where the AI is at.

## 3/4 Of Consumers Want More Control Over Healthcare Costs, Survey Shows
 - [https://www.forbes.com/sites/debgordon/2023/11/30/34-of-consumers-want-more-control-over-healthcare-costs-survey-shows](https://www.forbes.com/sites/debgordon/2023/11/30/34-of-consumers-want-more-control-over-healthcare-costs-survey-shows)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T03:10:06+00:00

Consumers increasingly rely on their health plans for information, as cost becomes even more important in consumer healthcare decisions, according to a recent survey.

## How COP28 Can Tell Stories To Engage People - From Master Storytellers
 - [https://www.forbes.com/sites/joanmichelson2/2023/11/30/how-cop28-can-tell-stories-to-engage-peoplefrom-master-storytellers](https://www.forbes.com/sites/joanmichelson2/2023/11/30/how-cop28-can-tell-stories-to-engage-peoplefrom-master-storytellers)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T03:08:51+00:00

Daniella Ortega was looking for a way to tell her kids about the environment and how it was changing. She did some research &amp; started to write something about an atom.

## Elastic Shows Robust Growth on the Back of GenAI & Cloud Expansion
 - [https://www.forbes.com/sites/stevemcdowell/2023/11/30/elastic-shows-robust-growth-on-the-back-of-genai--cloud-expansion](https://www.forbes.com/sites/stevemcdowell/2023/11/30/elastic-shows-robust-growth-on-the-back-of-genai--cloud-expansion)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T02:59:00+00:00

Elastic showcased an impressive performance in its latest earnings, beating consensus estimates for revenue and EPS, and even surprised Wall Street with its forecast.

## The Strongest Cybersecurity Stocks In Q3
 - [https://www.forbes.com/sites/bethkindig/2023/11/30/the-strongest-cybersecurity-stocks-in-q3](https://www.forbes.com/sites/bethkindig/2023/11/30/the-strongest-cybersecurity-stocks-in-q3)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T02:40:25+00:00

Cybersecurity stocks have performed well in 2023, rising about +26.5% YTD, with the security backdrop boosted by an increase in data breaches and ransomware.

## AI And ESG Linkages Are Critical To Our Society
 - [https://www.forbes.com/sites/cindygordon/2023/11/30/ai-and-esg-linkages-are-critical](https://www.forbes.com/sites/cindygordon/2023/11/30/ai-and-esg-linkages-are-critical)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T02:37:26+00:00

This article examines the topic of AI and the importance of ESG leadership.

## Contrarian Views: Is AI Increasing Productivity Or Not?
 - [https://www.forbes.com/sites/cindygordon/2023/11/30/contrarian-views-is-ai-increasing-productivity-or-not](https://www.forbes.com/sites/cindygordon/2023/11/30/contrarian-views-is-ai-increasing-productivity-or-not)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T02:13:55+00:00

This article discusses contrarian views on AI increasing value or reducing productivity like most new technologies have as productivity is done since the 1980s.

## Sensors And Drones Deployed To Fight Disease In Peruvian Amazon
 - [https://www.forbes.com/sites/andrewwight/2023/11/30/sensors-and-drones-deployed-to-fight-disease-in-peruvian-amazon](https://www.forbes.com/sites/andrewwight/2023/11/30/sensors-and-drones-deployed-to-fight-disease-in-peruvian-amazon)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T01:38:49+00:00

Climate factors can play a role in the spread of tropical diseases — now a Peruvian researcher is developing tools to better understand those relationships.

## Xreal Air 2 Smart Glasses Simulate 330-Inch Screen
 - [https://www.forbes.com/sites/charliefink/2023/11/30/xreal-air-2-smart-glasses-simulalte-330-inch-screen](https://www.forbes.com/sites/charliefink/2023/11/30/xreal-air-2-smart-glasses-simulalte-330-inch-screen)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T00:37:21+00:00

The biggest, brightest, and most expensive of a new category of mobile phone accessories.

## Today’s Wordle #895 Hints, Clues And Answer For Friday, December 1st
 - [https://www.forbes.com/sites/erikkain/2023/11/30/todays-wordle-895-hints-clues-and-answer-for-friday-december-1st](https://www.forbes.com/sites/erikkain/2023/11/30/todays-wordle-895-hints-clues-and-answer-for-friday-december-1st)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T00:30:00+00:00

How to solve today's Wordle. Hints, clues and the daily Wordle answer. Also, play competitive Wordle and learn more about each day's word.

## ‘Star Of Bethlehem’ Shines, Year’s Best ‘Shooting Stars’ And Betelgeuse Eclipsed: December’s Night Sky
 - [https://www.forbes.com/sites/jamiecartereurope/2023/11/30/star-of-bethlehem-shines-as-betelgeuse-is-eclipsed-and-shooting-stars-fall-decembers-night-sky](https://www.forbes.com/sites/jamiecartereurope/2023/11/30/star-of-bethlehem-shines-as-betelgeuse-is-eclipsed-and-shooting-stars-fall-decembers-night-sky)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-12-01T00:15:00+00:00

From the year's best meteor shower to a rare eclipse of bright red supergiant star, there's plenty to get excited about in the night sky in December 2023.

