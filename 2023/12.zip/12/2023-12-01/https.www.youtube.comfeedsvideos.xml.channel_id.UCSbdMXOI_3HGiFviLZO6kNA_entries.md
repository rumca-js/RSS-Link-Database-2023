# Source:Thrillseeker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA, language:en-US

## The BEST VR Headset in the WORLD Just Got REPLACED. The XR4 Has ARRIVED!
 - [https://www.youtube.com/watch?v=WoiEhoxKXTc](https://www.youtube.com/watch?v=WoiEhoxKXTc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSbdMXOI_3HGiFviLZO6kNA
 - date published: 2023-12-01T23:03:39+00:00

Thanks to Squarespace for sponsoring this video! Head to squarespace.com/thrillseeker to save 10% off your first purchase of a website or domain using code thrillseeker at checkout.

Hello and welcome to TUESDAY NEWSDAY! Your number one resource for the entire week's worth of VR news! Today we have probably one of the craziest weeks of VR news we've had in a long time. New Vive tracker ultimate has launched, Valve launched Steamlink, Assassins Creed Nexus launched, VRChat gets some huge changes and best of all, Varjo's newest headset the XR4 has also launched- follow up to the XR3, what I would call "The Best VR Headset in the world". 

And I got a chance to try it out!

Come check out my Discord community!
 https://discord.com/invite/thrill 

Support my content on Patreon with exclusive benefits:
 https://www.patreon.com/Thrillseeker

00:00 Intro
00:59 SquareSpace Ad
01:40 STEAMLINK!
03:05 THE VARJO XR4 HANDS ON
09:16 VIVE ULTIMATE TRACKERS
10:42 BIG VRCHAT CHANGES
12:35 QUESTION OF

