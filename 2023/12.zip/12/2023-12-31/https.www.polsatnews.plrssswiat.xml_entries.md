# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## Wojny, wybory i plany na 2024 rok. Noworoczne orędzia światowych przywódców
 - [https://www.polsatnews.pl/wiadomosc/2023-12-31/wojny-wybory-i-plany-na-2024-rok-noworoczne-oredzia-swiatowych-przywodcow](https://www.polsatnews.pl/wiadomosc/2023-12-31/wojny-wybory-i-plany-na-2024-rok-noworoczne-oredzia-swiatowych-przywodcow)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-12-31T21:55:00+00:00

W sylwestrową noc życzenia noworoczne płynęły ze wszystkich stron świata. Przywódcy występowali w telewizyjnych orędziach i zamieszczali najważniejsze słowa w mediach społecznościowych - pojawiły się w nich podsumowania mijającego roku i plany na ten nadchodzący.

## Królowa Danii Małgorzata II abdykuje. Ogłosiła decyzję podczas orędzia
 - [https://www.polsatnews.pl/wiadomosc/2023-12-31/krolowa-danii-malgorzata-ii-abdykuje-oglosila-decyzje-podczas-oredzia](https://www.polsatnews.pl/wiadomosc/2023-12-31/krolowa-danii-malgorzata-ii-abdykuje-oglosila-decyzje-podczas-oredzia)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-12-31T18:02:00+00:00

Królowa Danii Małgorzata II abdykuje 14 stycznia 2024 roku - powiadomiła agencja Reuters. Po 52 latach na tronie władza przekaże starszemu synowi Fryderykowi.

## Wznowiono połączenia pociągów Eurostar. Przewoźnik ostrzega przed licznymi opóźnieniami
 - [https://www.polsatnews.pl/wiadomosc/2023-12-31/wznowiono-polaczenia-pociagow-eurostar-przewoznik-ostrzega-przed-licznymi-opoznieniami](https://www.polsatnews.pl/wiadomosc/2023-12-31/wznowiono-polaczenia-pociagow-eurostar-przewoznik-ostrzega-przed-licznymi-opoznieniami)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-12-31T14:19:00+00:00

Połączenia pociągów Eurostar z Wielkiej Brytanii do różnych europejskich miast zostały wznowione w niedzielę po południu. Przejazdy mogą być jednak znacznie opóźnione. Mają na to wpływ poważne sobotnie zakłócenia wywołane zalaniem tuneli.

## Nadzwyczajna sytuacja na pokładzie samolotu. U pasażerki doszło do zatrzymania akcji serca
 - [https://www.polsatnews.pl/wiadomosc/2023-12-31/nadzwyczajna-sytuacja-na-pokladzie-samolotu-u-pasazerki-doszlo-do-zatrzymania-akcji-serca](https://www.polsatnews.pl/wiadomosc/2023-12-31/nadzwyczajna-sytuacja-na-pokladzie-samolotu-u-pasazerki-doszlo-do-zatrzymania-akcji-serca)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-12-31T13:42:00+00:00

Samolot wylądował kilkadziesiąt minut po starcie po tym, gdy załoga wszczęła alarm. Okazało się, że na pokładzie znajduje się chora pasażerka. U kobiety doszło do zatrzymania akcji serca.

## Bangladesz. Każdego roku burze zabijają w kraju setki osób. U źródła problemu stoi zmiana klimatu
 - [https://www.polsatnews.pl/wiadomosc/2023-12-31/bangladesz-kazdego-roku-burze-zabijaja-w-kraju-setki-osob-u-zrodla-problemu-stoi-zmiana-klimatu](https://www.polsatnews.pl/wiadomosc/2023-12-31/bangladesz-kazdego-roku-burze-zabijaja-w-kraju-setki-osob-u-zrodla-problemu-stoi-zmiana-klimatu)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-12-31T12:59:00+00:00

Około 300 osób rocznie ginie w Bangladeszu na skutek porażenia piorunem. Jeszcze na początku XXI wieku notowano dziesięciokrotnie mniej takich przypadków. Naukowcy podkreślają, że istotnym czynnikiem wpływającym na częstotliwość tragedii są postępujące zmiany klimatu.

## Sylwester 2023. Pierwsze państwa na świecie przywitały już Nowy Rok
 - [https://www.polsatnews.pl/wiadomosc/2023-12-31/sylwester-2023-pierwsze-panstwa-na-swiecie-przywitaly-juz-nowy-rok](https://www.polsatnews.pl/wiadomosc/2023-12-31/sylwester-2023-pierwsze-panstwa-na-swiecie-przywitaly-juz-nowy-rok)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-12-31T11:26:00+00:00

Mieszkańcy Kiribati i Tokelau świętują już 2024 rok. Jako pierwsi przywitali Nowy Rok już o godzinie 11:00 czasu polskiego. Dołączyli do nich również mieszkańcy Tonga, Wysp Samoa, a także Nowej Zelandii, u których Nowy Rok wybił w samo południe.

## Włochy. Wenecja ma dość turystów. Kolejne ograniczenia
 - [https://www.polsatnews.pl/wiadomosc/2023-12-31/wlochy-wenecja-ma-dosc-turystow-kolejne-ograniczenia](https://www.polsatnews.pl/wiadomosc/2023-12-31/wlochy-wenecja-ma-dosc-turystow-kolejne-ograniczenia)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-12-31T11:24:00+00:00

Zorganizowane grupy turystyczne będą mogły liczyć maksymalnie 25 osób, a ich przewodnicy będą mieli zakaz korzystania z głośników w trakcie oprowadzania - to kolejne ograniczenia proponowane przez władze Wenecji w celu kontroli liczby zwiedzających. Nowe zasady mają wejść w życie od czerwca.

## Kalifornia: Potężne fale i ulewne deszcze. Część mieszkańców ewakuowana
 - [https://www.polsatnews.pl/wiadomosc/2023-12-31/kalifornia-potezne-fale-i-ulewne-deszcze-czesc-mieszkancow-ewakuowana](https://www.polsatnews.pl/wiadomosc/2023-12-31/kalifornia-potezne-fale-i-ulewne-deszcze-czesc-mieszkancow-ewakuowana)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-12-31T10:15:00+00:00

Ogromna powódź nawiedziła Kalifornię. Kilkumetrowe fale zmusiły część mieszkańców do ewakuacji. Lokalna ludność ostatnio musi borykać się z zalanymi ulicami i zniszczonym wybrzeżem. Służby ostrzegły, że dramatyczna sytuacja stwarza wyjątkowe ryzyko utonięć.

## Ostrzał Biełgorodu. Zginęło 21 osób, 111 zostało rannych. "Ta zbrodnia nie pozostanie bez kary"
 - [https://www.polsatnews.pl/wiadomosc/2023-12-31/ostrzal-bielgorodu-zginelo-21-cywilow-rosja-oskarza-ukraine-i-wzywa](https://www.polsatnews.pl/wiadomosc/2023-12-31/ostrzal-bielgorodu-zginelo-21-cywilow-rosja-oskarza-ukraine-i-wzywa)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-12-31T06:36:00+00:00

Ta zbrodnia nie pozostanie bez kary - brzmią groźby Moskwy w kierunku Kijowa po sobotnim ataku ukraińskich dronów na rosyjskie miasta. W ostrzale przygranicznego Biełgorodu zginęło 21 osób, a ponad sto zostało rannych. Według władz lokalnych wśród ofiar są dzieci. Strona rosyjska zarzuciła Ukraińcom, że w czasie ataku użyli amunicji kasetowej.

