# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Sylwestrowe zamulanie w Nowej Normalności!
 - [https://www.youtube.com/watch?v=RArSwb354CU](https://www.youtube.com/watch?v=RArSwb354CU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2023-12-31T21:58:11+00:00



