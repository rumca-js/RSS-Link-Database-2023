# Source:HackRead, URL:https://www.hackread.com/feed, language:en-US

## Microsoft Disables App Installer After Feature is Abused for Malware
 - [https://www.hackread.com/microsoft-disables-app-installer-malware-abuse](https://www.hackread.com/microsoft-disables-app-installer-malware-abuse)
 - RSS feed: https://www.hackread.com/feed
 - date published: 2023-12-31T19:14:22+00:00

<p>By <a href="https://www.hackread.com/author/deeba/" rel="nofollow">Deeba Ahmed</a></p>
<p>According to the Microsoft Threat Intelligence Team, threat actors labeled as 'financially motivated' utilize the ms-appinstaller URI scheme for malware distribution.</p>
<p>This is a post from HackRead.com Read the original post: <a href="https://www.hackread.com/microsoft-disables-app-installer-malware-abuse/" rel="nofollow">Microsoft Disables App Installer After Feature is Abused for Malware</a></p>

