# Source:The Brazilian Report, URL:https://brazilian.report/feed/, language:en-US

## The new species that came out of a São Paulo tap
 - [https://brazilian.report/environment/2023/12/31/new-species-sao-paulo-tap](https://brazilian.report/environment/2023/12/31/new-species-sao-paulo-tap)
 - RSS feed: https://brazilian.report/feed/
 - date published: 2023-12-31T20:37:49+00:00

<p>The post <a href="https://brazilian.report/environment/2023/12/31/new-species-sao-paulo-tap/">The new species that came out of a São Paulo tap</a> appeared first on <a href="https://brazilian.report">The Brazilian Report</a>.</p>

