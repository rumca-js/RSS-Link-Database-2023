# Source:Mateusz Chrobok, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw, language:pl-PL

## Jak w roku 2000 uniknęliśmy apokalipsy?
 - [https://www.youtube.com/watch?v=FL3nvoutEpQ](https://www.youtube.com/watch?v=FL3nvoutEpQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw
 - date published: 2023-12-31T17:00:15+00:00

📆 Okazja zacna, więc opowiem Wam dzisiaj o problemie roku dwutysięcznego, zwanym też bardziej pieszczotliwie pluskwą milenijną. W sumie nic wielkiego się nie stało. Czy w takim razie problem ten w ogóle istniał? Czy jeszcze kiedyś się powtórzy? I czego się dzięki niemu nauczyliśmy?
 
Źródła:
🇮🇳 What was the Y2K bug and how it helped India's IT sector?
https://www.jagranjosh.com/general-knowledge/y2k-bug-1589540224-1

💬 Dyskusja na Usenecie z 1985 roku na temat potencjalnego błędu
https://groups.google.com/g/net.bugs/c/ZGlqGwNaq3I

👀 Spojrzenie na problem z perspektywy czasu, The New York Times.
https://www.nytimes.com/2013/05/27/booming/revisiting-y2k-much-ado-about-nothing.html

⏰ The Time po 20 latach wspomina Y2K problem
https://time.com/5752129/y2k-bug-history/

🦾 Howtogeek, bardziej technicznie na temat
https://www.howtogeek.com/671087/what-was-the-y2k-bug-and-why-did-it-terrify-the-world/

📑 Co naprawdę wydarzyło się w Y2K - praca prof. Martyna Thomasa, polecam
https://s3-eu-we

