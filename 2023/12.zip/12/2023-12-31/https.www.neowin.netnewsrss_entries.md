# Source:Neowin, URL:https://www.neowin.net/news/rss/, language:en-us

## Amazon Limited Time Deal: Hisense 58" U6HF Series ULED 4K UHD Smart Fire TV now 40% off
 - [https://www.neowin.net/deals/amazon-limited-time-deal-hisense-58-u6hf-series-uled-4k-uhd-smart-fire-tv-now-40-off](https://www.neowin.net/deals/amazon-limited-time-deal-hisense-58-u6hf-series-uled-4k-uhd-smart-fire-tv-now-40-off)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-12-31T18:00:10+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/12/1704041490_untitled_design_1_medium.jpg" /></div>Save $240 today with Amazon&#039;s limited time deal on Hisense 58&quot; Class U6HF Series ULED 4K UHD Smart Fire TV. Get your hands on it, with 600-Nit Dolby Vision and more, while stocks last. <a href="https://www.neowin.net/deals/amazon-limited-time-deal-hisense-58-u6hf-series-uled-4k-uhd-smart-fire-tv-now-40-off">Read more...</a>

## Save 82% on a lifetime license to Microsoft Office 2019 for Windows & Office 2019 Basics
 - [https://www.neowin.net/deals/save-82-on-a-lifetime-license-to-microsoft-office-2019-for-windows--office-2019-basics](https://www.neowin.net/deals/save-82-on-a-lifetime-license-to-microsoft-office-2019-for-windows--office-2019-basics)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-12-31T18:00:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2019/12/1575804313_officemobile_medium.jpg" /></div>Get classic Office apps and email, including Word, Excel, PowerPoint, Outlook, Teams, and OneNote. And discover the power of Microsoft Office with this comprehensive 4-course bundle today! <a href="https://www.neowin.net/deals/save-82-on-a-lifetime-license-to-microsoft-office-2019-for-windows--office-2019-basics">Read more...</a>

## Here are our picks for the most anticipated upcoming PC games of 2024
 - [https://www.neowin.net/news/here-are-our-picks-for-the-most-anticipated-upcoming-pc-games-of-2024](https://www.neowin.net/news/here-are-our-picks-for-the-most-anticipated-upcoming-pc-games-of-2024)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-12-31T17:00:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/05/1685056039_homeworld-3_medium.jpg" /></div>There are a ton of games coming on PC, including many exclusive to the platform, that are due out in the next year. Check out our list of our most anticipated upcoming PC games in 2024. <a href="https://www.neowin.net/news/here-are-our-picks-for-the-most-anticipated-upcoming-pc-games-of-2024">Read more...</a>

## Ghostrunner is free to claim on the Epic Games Store today
 - [https://www.neowin.net/news/ghostrunner-is-free-to-claim-on-the-epic-games-store-today](https://www.neowin.net/news/ghostrunner-is-free-to-claim-on-the-epic-games-store-today)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-12-31T16:00:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2020/10/1603379917_ghostrunner_medium.jpg" /></div>The final Epic Games Store freebie of 2023 has turned out to be a copy of Ghostrunner. This fast-paced action platformer from 2020 lets you become a cyberpunk ninja and slice bullets. <a href="https://www.neowin.net/news/ghostrunner-is-free-to-claim-on-the-epic-games-store-today">Read more...</a>

## The head of Microsoft's Windows team wants your thoughts about UX frameworks
 - [https://www.neowin.net/news/the-head-of-microsofts-windows-team-wants-your-thoughts-about-ux-frameworks](https://www.neowin.net/news/the-head-of-microsofts-windows-team-wants-your-thoughts-about-ux-frameworks)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-12-31T15:44:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/10/1697149010_windows_11_medium.jpg" /></div>Mikhail Parakhin, the recently named leader of Microsoft&#039;s Windows and Web Experiences team, went on X earlier today to ask people, &quot;Which UX framework in Windows should we invest more in?&quot; <a href="https://www.neowin.net/news/the-head-of-microsofts-windows-team-wants-your-thoughts-about-ux-frameworks">Read more...</a>

## Microsoft Teams will add Intelligent Recap for Copilot users in January 2024
 - [https://www.neowin.net/news/microsoft-teams-will-add-intelligent-recap-for-copilot-users-in-january-2024](https://www.neowin.net/news/microsoft-teams-will-add-intelligent-recap-for-copilot-users-in-january-2024)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-12-31T14:00:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2021/06/1623452685_microsoft_teams_9_medium.jpg" /></div>The Microsoft 365 Roadmap site added a couple of new entries for its Teams services that will be rolled out in January 2024. One of them will add the Intelligent Recap for Copilot users. <a href="https://www.neowin.net/news/microsoft-teams-will-add-intelligent-recap-for-copilot-users-in-january-2024">Read more...</a>

## Here are the top 10 most viewed stories on Neowin in 2023
 - [https://www.neowin.net/news/here-are-the-top-10-most-viewed-stories-on-neowin-in-2023](https://www.neowin.net/news/here-are-the-top-10-most-viewed-stories-on-neowin-in-2023)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-12-31T13:00:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/12/1703844688_neowin_logo_medium.jpg" /></div>With 2023 over, it is time to look back at the most popular stories published on Neowin during the year. Edge annoyances, small Windows 11 installs, odd upgrade prompts, deprecated features, and more. <a href="https://www.neowin.net/news/here-are-the-top-10-most-viewed-stories-on-neowin-in-2023">Read more...</a>

## Microsoft Weekly: Upcoming Surface updates, Copilot apps, and more
 - [https://www.neowin.net/news/microsoft-weekly-upcoming-surface-updates-copilot-apps-and-more](https://www.neowin.net/news/microsoft-weekly-upcoming-surface-updates-copilot-apps-and-more)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-12-31T09:00:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/12/1703406849_microsoft_weekly_medium.jpg" /></div>Here is the final Microsoft Weekly of 2023, a news recap with the most interesting stories of the week from the world of Microsoft. Copilot apps on Android and iOS, big Surface updates, and more. <a href="https://www.neowin.net/news/microsoft-weekly-upcoming-surface-updates-copilot-apps-and-more">Read more...</a>

