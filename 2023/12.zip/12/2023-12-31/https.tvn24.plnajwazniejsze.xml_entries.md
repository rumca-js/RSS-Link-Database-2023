# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## "Nigdy się nie cofniemy". Orędzie noworoczne Putina
 - [https://tvn24.pl/swiat/rosja-wladimir-putin-wyglosil-oredzie-noworoczne-7663596?source=rss](https://tvn24.pl/swiat/rosja-wladimir-putin-wyglosil-oredzie-noworoczne-7663596?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T21:30:51+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jyr5kw-2023-12-31t210140z_1_lwd907631122023rp1_rtrwnev_c_9076-new-year-russia-putin-0002-7663639/alternates/LANDSCAPE_1280" />
    Nie użył słowa "Ukraina" ani zwrotu "specjalna operacja wojskowa", jak władze Rosji nazywają trwającą od lutego 2022 roku inwazję na Ukrainę - pisze Reuters.

## Prezydent użył kilku sformułowań, których "szczególnie nie wypada mu używać"
 - [https://tvn24.pl/polska/oredzie-noworoczne-prezydenta-andrzeja-dudy-dominika-sitnicka-i-lukasz-lipinski-komentuja-7663602?source=rss](https://tvn24.pl/polska/oredzie-noworoczne-prezydenta-andrzeja-dudy-dominika-sitnicka-i-lukasz-lipinski-komentuja-7663602?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T20:40:34+00:00

<img alt="Prezydent użył kilku sformułowań, których " src="https://tvn24.pl/najnowsze/cdn-zdjecie-osxpir-andrzej-duda-7663598/alternates/LANDSCAPE_1280" />
    Komentarze po wystąpieniu noworocznym prezydenta.

## "Odchodzący 2023 rok był pełen cudów. Ostatni z nich to słowa z orędzia Prezydenta"
 - [https://tvn24.pl/polska/andrzej-duda-w-noworocznym-oredziu-donald-tusk-komentuje-2023-rok-byl-pelen-cudow-ostatni-z-nich-to-slowa-z-oredzia-prezydenta-7663614?source=rss](https://tvn24.pl/polska/andrzej-duda-w-noworocznym-oredziu-donald-tusk-komentuje-2023-rok-byl-pelen-cudow-ostatni-z-nich-to-slowa-z-oredzia-prezydenta-7663614?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T20:03:56+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fmuzxn-pap_20231227_0v4-7654592/alternates/LANDSCAPE_1280" />
    Premier Donald Tusk skomentował noworoczne orędzie Andrzeja Dudy,

## Nowy Rok, nowe miasta. "Sprawiedliwości dziejowej staje się zadość"
 - [https://fakty.tvn24.pl/zobacz-fakty/nowy-rok-nowe-miasta-sprawiedliwosci-dziejowej-staje-sie-zadosc-st7663589?source=rss](https://fakty.tvn24.pl/zobacz-fakty/nowy-rok-nowe-miasta-sprawiedliwosci-dziejowej-staje-sie-zadosc-st7663589?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T19:23:40+00:00

<img alt="Nowy Rok, nowe miasta. " src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-nhhni0-mazur-2-7663593/alternates/LANDSCAPE_1280" />
    Na mapie Polski pojawią się nowe miasta.

## Nieoczekiwana abdykacja królowej
 - [https://tvn24.pl/swiat/dania-krolowa-malgorzata-ii-nieoczekiwanie-oglosila-abdykacje-7663569?source=rss](https://tvn24.pl/swiat/dania-krolowa-malgorzata-ii-nieoczekiwanie-oglosila-abdykacje-7663569?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T18:38:16+00:00

<img alt="Nieoczekiwana abdykacja królowej " src="https://tvn24.pl/najnowsze/cdn-zdjecie-8jxexq-krolowa-malgorzata-ii-7663573/alternates/LANDSCAPE_1280" />
    Tron obejmie jej syn.

## Finalista igrzysk znaleziony martwy. "Policja szuka wskazówek"
 - [https://eurosport.tvn24.pl/lekkoatletyka/benjamin-kiplagat-znaleziony-martwy-w-kenii.-ugandyjski-lekkoatleta-mogl-zostac-zamordowany_sto9940233/story.shtml?source=rss](https://eurosport.tvn24.pl/lekkoatletyka/benjamin-kiplagat-znaleziony-martwy-w-kenii.-ugandyjski-lekkoatleta-mogl-zostac-zamordowany_sto9940233/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T18:28:37+00:00

<img alt="Finalista igrzysk znaleziony martwy. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-wfcyp5-benjamin-kiplagat-7663575/alternates/LANDSCAPE_1280" />
    Miał 34 lata.

## Atak hakerski na Centralny Ośrodek Sportu. Mogło dojść do wycieku danych
 - [https://tvn24.pl/polska/zakopane-atak-hakerski-na-centralny-osrodek-sportu-moglo-dojsc-do-wycieku-danych-7663536?source=rss](https://tvn24.pl/polska/zakopane-atak-hakerski-na-centralny-osrodek-sportu-moglo-dojsc-do-wycieku-danych-7663536?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T17:47:17+00:00

<img alt="Atak hakerski na Centralny Ośrodek Sportu. Mogło dojść do wycieku danych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wpa1mr-cos-zakopane-7663523/alternates/LANDSCAPE_1280" />
    W Zakopanem.

## O pracy z politykami, prezydenturze i srebrnym przycisku z YouTube'a
 - [https://fakty.tvn24.pl/fakty-po-poludniu/o-pracy-z-politykami-prezydenturze-i-srebrnym-przycisku-z-youtubea-szymon-holownia-byl-gosciem-dzien-dobry-tvn-st7663506?source=rss](https://fakty.tvn24.pl/fakty-po-poludniu/o-pracy-z-politykami-prezydenturze-i-srebrnym-przycisku-z-youtubea-szymon-holownia-byl-gosciem-dzien-dobry-tvn-st7663506?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T17:18:11+00:00

<img alt="O pracy z politykami, prezydenturze i srebrnym przycisku z YouTube'a" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-5ryuno-holownia-7663509/alternates/LANDSCAPE_1280" />
    Szymon Hołownia był gościem "Dzień Dobry TVN".

## Kubacki świadomy problemu
 - [https://eurosport.tvn24.pl/skoki-narciarskie/garmisch-partenkirchen/2023-2024/skoki-narciarskie-garmisch-partenkirchen-2023.-dawid-kubacki-po-kwalifikacjach.-co-powiedzial-turnie_sto9940207/story.shtml?source=rss](https://eurosport.tvn24.pl/skoki-narciarskie/garmisch-partenkirchen/2023-2024/skoki-narciarskie-garmisch-partenkirchen-2023.-dawid-kubacki-po-kwalifikacjach.-co-powiedzial-turnie_sto9940207/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T17:14:28+00:00

<img alt="Kubacki świadomy problemu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-g2quhk-dawid-kubacki-7663516/alternates/LANDSCAPE_1280" />
     "To jak dwie, trzy belki niżej".

## Niemowlę z obrażeniami głowy w szpitalu. Zatrzymano rodziców
 - [https://tvn24.pl/polska/kepno-niemowle-z-obrazeniami-glowy-trafilo-do-szpitala-zatrzymano-rodzicow-7663507?source=rss](https://tvn24.pl/polska/kepno-niemowle-z-obrazeniami-glowy-trafilo-do-szpitala-zatrzymano-rodzicow-7663507?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T17:13:39+00:00

<img alt="Niemowlę z obrażeniami głowy w szpitalu. Zatrzymano rodziców" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5qpnqe-kepno-szpital-7663479/alternates/LANDSCAPE_1280" />
    19-letnia kobieta przywiozła dziewczynkę do szpitala w Kępnie.

## Niemowlę z pęknięciem czaszki w szpitalu. Zatrzymano rodziców
 - [https://tvn24.pl/polska/kepno-niemowle-z-peknieciem-czaszki-trafilo-do-szpitala-zatrzymano-rodzicow-7663507?source=rss](https://tvn24.pl/polska/kepno-niemowle-z-peknieciem-czaszki-trafilo-do-szpitala-zatrzymano-rodzicow-7663507?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T17:13:39+00:00

<img alt="Niemowlę z pęknięciem czaszki w szpitalu. Zatrzymano rodziców" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5qpnqe-kepno-szpital-7663479/alternates/LANDSCAPE_1280" />
    19-letnia kobieta przywiozła dziewczynkę do szpitala w Kępnie.

## "Nie wyobrażamy sobie, żeby WOŚP-u nie było"
 - [https://fakty.tvn24.pl/fakty-po-poludniu/nadchodzi-final-wielkiej-orkiestry-swiatecznej-pomocy-nie-wyobrazamy-sobie-zeby-wosp-u-nie-bylo-st7663473?source=rss](https://fakty.tvn24.pl/fakty-po-poludniu/nadchodzi-final-wielkiej-orkiestry-swiatecznej-pomocy-nie-wyobrazamy-sobie-zeby-wosp-u-nie-bylo-st7663473?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T17:00:09+00:00

<img alt="" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-4v2ug7-wosp-7663476/alternates/LANDSCAPE_1280" />
    32. Finał Wielkiej Orkiestry Świątecznej Pomocy odbędzie się 28 stycznia.

## Fatalna końcówka roku Arsenalu
 - [https://eurosport.tvn24.pl/pilka-nozna/premier-league/2023-2024/fulham-arsenal-wynik-meczu-i-relacja-premier-league_sto9940153/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/premier-league/2023-2024/fulham-arsenal-wynik-meczu-i-relacja-premier-league_sto9940153/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T16:31:50+00:00

<img alt="Fatalna końcówka roku Arsenalu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ifjum-jakub-kiwior-w-meczu-fulham-arsenal-7663474/alternates/LANDSCAPE_1280" />
    Nieudany mecz reprezentanta Polski.

## Wojna i śmierć. Nadzieja i krzyk radości. 2023 rok na zdjęciach
 - [https://tvn24.pl/premium/najlepsze-zdjecia-2023-roku-7641033?source=rss](https://tvn24.pl/premium/najlepsze-zdjecia-2023-roku-7641033?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T16:29:39+00:00

<img alt="Wojna i śmierć. Nadzieja i krzyk radości. 2023 rok na zdjęciach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6suhrh-epa10997234-7640980/alternates/LANDSCAPE_1280" />
    W obiektywach światowych fotografów.

## Powrót zimy. W prognozie zagrożeń widać zawieje i zamiecie śnieżne
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-sie-zmieni-zima-wraca-do-polski-prognoza-zagrozen-imgw-na-poczatek-stycznia-st7663433?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-sie-zmieni-zima-wraca-do-polski-prognoza-zagrozen-imgw-na-poczatek-stycznia-st7663433?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T16:09:29+00:00

<img alt="Powrót zimy. W prognozie zagrożeń widać zawieje i zamiecie śnieżne" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-plt0sn-intensywne-opady-sniegu-7663446/alternates/LANDSCAPE_1280" />
    Prognoza zagrożeń IMGW.

## Czas powrotów, pożegnań i wielkich debiutów
 - [https://fakty.tvn24.pl/fakty-po-poludniu/muzyczne-podsumowanie-2023-roku-czas-powrotow-pozegnan-i-wielkich-debiutow-st7663391?source=rss](https://fakty.tvn24.pl/fakty-po-poludniu/muzyczne-podsumowanie-2023-roku-czas-powrotow-pozegnan-i-wielkich-debiutow-st7663391?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T15:57:33+00:00

<img alt="Czas powrotów, pożegnań i wielkich debiutów" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-d4ibvr-laskosz-7663441/alternates/LANDSCAPE_1280" />
    Muzyczne podsumowanie 2023 roku.

## Ten jeden blok jest jak całe miasto powiatowe
 - [https://tvn24.pl/go/programy,7/tylko-w-tvn24-go-odcinki,283316/odcinek-3197,S00E3197,1248018?source=rss](https://tvn24.pl/go/programy,7/tylko-w-tvn24-go-odcinki,283316/odcinek-3197,S00E3197,1248018?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T15:29:20+00:00

<img alt="Ten jeden blok jest jak całe miasto powiatowe" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fm34tj-falowiec-7663423/alternates/LANDSCAPE_1280" />
    Jak wygląda codzienność w gdańskim falowcu? Reportaż Mateusza Półchłopka i Kamila Klamuta.

## "Co jako premier odradzam robić w sylwestra?"
 - [https://tvn24.pl/polska/donald-tusk-na-nagraniu-co-jako-premier-odradzam-robic-w-sylwestra-odpalac-petardy-przy-tych-ktorzy-sie-boja-7663382?source=rss](https://tvn24.pl/polska/donald-tusk-na-nagraniu-co-jako-premier-odradzam-robic-w-sylwestra-odpalac-petardy-przy-tych-ktorzy-sie-boja-7663382?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T15:27:38+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-u5ppv6-co-jako-premier-odradzam-robic-w-sylwestra-donald-tusk-opublikowal-nagranie-7663402/alternates/LANDSCAPE_1280" />
    Donald Tusk opublikował nagranie.

## Kwaśna mina Stocha
 - [https://eurosport.tvn24.pl/skoki-narciarskie/garmisch-partenkirchen-1/2023-2024/kamil-stoch-po-kwalifikacjach-w-garmisch-partenkirchen-turniej-czterech-skoczni_sto9940010/story.shtml?source=rss](https://eurosport.tvn24.pl/skoki-narciarskie/garmisch-partenkirchen-1/2023-2024/kamil-stoch-po-kwalifikacjach-w-garmisch-partenkirchen-turniej-czterech-skoczni_sto9940010/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T15:22:25+00:00

<img alt="Kwaśna mina Stocha" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1vrz7x-kamil-stoch-7663414/alternates/LANDSCAPE_1280" />
    "Żaden skok mi się nie podobał".

## Mistrz świata podejrzewany o spowodowanie śmierci żony
 - [https://eurosport.tvn24.pl/kolarstwo/rohan-dennis-oskarzony-o-zabicie-zony_sto9939768/story.shtml?source=rss](https://eurosport.tvn24.pl/kolarstwo/rohan-dennis-oskarzony-o-zabicie-zony_sto9939768/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T15:14:00+00:00

<img alt="Mistrz świata podejrzewany o spowodowanie śmierci żony" src="https://tvn24.pl/najnowsze/cdn-zdjecie-t553hj-rohan-dennis-7663397/alternates/LANDSCAPE_1280" />
    13 marca stanie przed sądem.

## Z rzeki wyłowili kobietę. Nie udało się jej uratować
 - [https://tvn24.pl/poznan/kolo-z-rzeki-wydobyli-kobiete-nie-udalo-sie-jej-uratowac-7663390?source=rss](https://tvn24.pl/poznan/kolo-z-rzeki-wydobyli-kobiete-nie-udalo-sie-jej-uratowac-7663390?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T15:13:47+00:00

<img alt="Z rzeki wyłowili kobietę. Nie udało się jej uratować" src="https://tvn24.pl/najnowsze/cdn-zdjecie-uyxyhg-brutalne-zabojstwo-60-letniej-kobiety-7439944/alternates/LANDSCAPE_1280" />
    W Kole (woj. wielkopolskie).

## Tusk na koniec 2023 roku
 - [https://tvn24.pl/polska/donald-tusk-w-nagraniu-podsumowujacym-2023-rok-bedziemy-mogli-naprawiac-krzywdy-zeby-wszyscy-w-polsce-poczuli-sie-jak-w-domu-7663383?source=rss](https://tvn24.pl/polska/donald-tusk-w-nagraniu-podsumowujacym-2023-rok-bedziemy-mogli-naprawiac-krzywdy-zeby-wszyscy-w-polsce-poczuli-sie-jak-w-domu-7663383?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T15:13:32+00:00

<img alt="Tusk na koniec 2023 roku" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8y0nq8-tusk-klip_03-7663408/alternates/LANDSCAPE_1280" />
    Premier w nagraniu.

## Spędzacie sylwestra na świeżym powietrzu? Sprawdźcie najnowszą prognozę pogody
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-noc-sylwestrowa-i-nowy-rok-2024-st7663284?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-noc-sylwestrowa-i-nowy-rok-2024-st7663284?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T14:10:42+00:00

<img alt="Spędzacie sylwestra na świeżym powietrzu? Sprawdźcie najnowszą prognozę pogody" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1f62lh-zakopane-sylwester-nowy-rok-fajerwerki-shutterstock_2118566765-7663318/alternates/LANDSCAPE_1280" />
    Sprawdź prognozę na noc sylwestrową i Nowy Rok.

## Nie wszyscy Polacy przebrnęli przez kwalifikacje w Ga-Pa
 - [https://eurosport.tvn24.pl/skoki-narciarskie/garmisch-partenkirchen/2023-2024/skoki-narciarskie-garmisch-partenkirchen-2023.-kwalifikacje-wyniki-i-relacja-72.-turniej-czterech-sk_sto9939827/story.shtml?source=rss](https://eurosport.tvn24.pl/skoki-narciarskie/garmisch-partenkirchen/2023-2024/skoki-narciarskie-garmisch-partenkirchen-2023.-kwalifikacje-wyniki-i-relacja-72.-turniej-czterech-sk_sto9939827/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T14:01:28+00:00

<img alt="Nie wszyscy Polacy przebrnęli przez kwalifikacje w Ga-Pa" src="https://tvn24.pl/najnowsze/cdn-zdjecie-apk0xo-kamil-stoch-oberstdorf-7663345/alternates/LANDSCAPE_1280" />
    Konkurs w poniedziałek.

## Podatek od nieruchomości w górę
 - [https://tvn24.pl/biznes/nieruchomosci/podatek-od-nieruchomosci-2024-maksymalne-stawki-w-gore-st7663223?source=rss](https://tvn24.pl/biznes/nieruchomosci/podatek-od-nieruchomosci-2024-maksymalne-stawki-w-gore-st7663223?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T13:43:51+00:00

<img alt="Podatek od nieruchomości w górę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-13kv33-niedoszly-zlodziej-wszedl-do-mieszkania-przez-uchylone-okno-zdj-ilustracyjne-7442587/alternates/LANDSCAPE_1280" />
    Wzrosną maksymalne stawki.

## Ośmiolatka w piżamce chodziła w nocy sama po ulicy. Rodzice spali pijani w domu
 - [https://tvn24.pl/lublin/wlodawa-8-latka-w-pizamce-chodzila-w-nocy-sama-po-ulicy-rodzice-spali-pijani-w-domu-7663244?source=rss](https://tvn24.pl/lublin/wlodawa-8-latka-w-pizamce-chodzila-w-nocy-sama-po-ulicy-rodzice-spali-pijani-w-domu-7663244?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T13:14:00+00:00

<img alt="Ośmiolatka w piżamce chodziła w nocy sama po ulicy. Rodzice spali pijani w domu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5jd9oa-jedno-z-dzieci-bylo-na-jezdni-drugie-na-chodniku-zdjecie-ilustracyjne-7348986/alternates/LANDSCAPE_1280" />
    "Dziewczynka trzęsła się z zimna".

## Bezprecedensowy atak, wielkie straty Rosji, najtrudniejszy miesiąc dla ukraińskich sił zbrojnych
 - [https://tvn24.pl/swiat/tydzien-w-ukrainie-bezprecedensowy-atak-rakietowy-rosja-stracila-desantowiec-najtrudniejszy-miesiac-dla-sil-ukrainskich-7662788?source=rss](https://tvn24.pl/swiat/tydzien-w-ukrainie-bezprecedensowy-atak-rakietowy-rosja-stracila-desantowiec-najtrudniejszy-miesiac-dla-sil-ukrainskich-7662788?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T13:09:34+00:00

<img alt="Bezprecedensowy atak, wielkie straty Rosji, najtrudniejszy miesiąc dla ukraińskich sił zbrojnych  " src="https://tvn24.pl/najnowsze/cdn-zdjecie-9cm685-ukraina-wojsko-7663186/alternates/LANDSCAPE_1280" />
    Podsumowujemy miniony tydzień walk w Ukrainie.

## Porzucony szczeniak w centrum miasta. Strażnicy o "nieudanym prezencie świątecznym"
 - [https://tvn24.pl/lodz/lodz-porzucony-szczeniak-w-kartonie-straz-miejska-szuka-sprawcy-7663202?source=rss](https://tvn24.pl/lodz/lodz-porzucony-szczeniak-w-kartonie-straz-miejska-szuka-sprawcy-7663202?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T12:59:37+00:00

<img alt="Porzucony szczeniak w centrum miasta. Strażnicy o " src="https://tvn24.pl/najnowsze/cdn-zdjecie-g502zw-zwierze-trafilo-do-schroniska-7663231/alternates/LANDSCAPE_1280" />
    Sprawcy grozi kara do trzech lat więzienia.

## Ukradł 46 milionów dolarów i "myślał, że to gra"
 - [https://tvn24.pl/go/programy,7/filmy-dokumentalne-odcinki,74501/odcinek-3200,S00E3200,1248014?source=rss](https://tvn24.pl/go/programy,7/filmy-dokumentalne-odcinki,74501/odcinek-3200,S00E3200,1248014?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T12:50:52+00:00

<img alt="Ukradł 46 milionów dolarów i " src="https://tvn24.pl/najnowsze/cdn-zdjecie-n7e0wx-filmdokumentalny-7663253/alternates/LANDSCAPE_1280" />
    Historia największej, indywidualnej kradzieży kryptowalut, która została zaplanowana przez 17-letniego chłopaka.

## "Ogłuszająca kakofonia pobitych rekordów". W 2023 było źle, w nowym roku może nie być lepiej
 - [https://tvn24.pl/tvnmeteo/nauka/2023-rok-w-klimacie-ogluszajaca-kakofonia-pobitych-rekordow-bylo-zle-moze-byc-jeszcze-gorzej-st7641900?source=rss](https://tvn24.pl/tvnmeteo/nauka/2023-rok-w-klimacie-ogluszajaca-kakofonia-pobitych-rekordow-bylo-zle-moze-byc-jeszcze-gorzej-st7641900?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T12:50:44+00:00

<img alt="" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-5h9gzv-zmiany-klimatu-wplywaja-na-powstanie-zagrazajacych-zyciu-powodzi-5573263/alternates/LANDSCAPE_1280" />
    2023 to rok, w którym w klimacie działo się wiele.

## Tak świat wita Nowy Rok
 - [https://tvn24.pl/swiat/sylwester-2023-i-nowy-rok-2024-jak-swiat-wchodzi-w-nowy-rok-relacja-7663208?source=rss](https://tvn24.pl/swiat/sylwester-2023-i-nowy-rok-2024-jak-swiat-wchodzi-w-nowy-rok-relacja-7663208?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T12:50:24+00:00

<img alt="Tak świat wita Nowy Rok" src="https://tvn24.pl/najnowsze/cdn-zdjecie-itm402-tancerze-podczas-sylwestrowej-parady-w-czasie-obchodow-sylwestra-przy-glownej-drodze-w-miejscowosci-denpasar-na-bali-w-indonezji-7663225/alternates/LANDSCAPE_1280" />
    Relacja z ostatniego dnia mijającego roku.

## Druga odsłona Turnieju Czterech Skoczni. Kwalifikacje w Garmisch-Partenkirchen
 - [https://eurosport.tvn24.pl/skoki-narciarskie/garmisch-partenkirchen-1/2023-2024/liveevent.shtml?source=rss](https://eurosport.tvn24.pl/skoki-narciarskie/garmisch-partenkirchen-1/2023-2024/liveevent.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T12:44:38+00:00

<img alt="Druga odsłona Turnieju Czterech Skoczni. Kwalifikacje w Garmisch-Partenkirchen" src="https://tvn24.pl/najnowsze/cdn-zdjecie-30hicf-zyla-w-locie-7653483/alternates/LANDSCAPE_1280" />
    Wyniki i relacja na żywo w Eurosport.pl.

## Niedziele handlowe w 2024 roku. Kiedy będą otwarte większe sklepy?
 - [https://tvn24.pl/biznes/z-kraju/zakaz-handlu-w-niedziele-2024-niedziele-handlowe-w-2024-roku-kalendarz-handlowy-st7663201?source=rss](https://tvn24.pl/biznes/z-kraju/zakaz-handlu-w-niedziele-2024-niedziele-handlowe-w-2024-roku-kalendarz-handlowy-st7663201?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T12:28:55+00:00

<img alt="Niedziele handlowe w 2024 roku. Kiedy będą otwarte większe sklepy?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-nd1t8b-sklepy-zakupy-inflacja-7438523/alternates/LANDSCAPE_1280" />
    Kalendarz handlowy.

## Rosjanie "dali prezent na Nowy Rok"
 - [https://tvn24.pl/swiat/ukraina-charkow-pocisk-iskander-spadl-na-hotel-w-centrum-miasta-sa-ranni-7662791?source=rss](https://tvn24.pl/swiat/ukraina-charkow-pocisk-iskander-spadl-na-hotel-w-centrum-miasta-sa-ranni-7662791?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T12:19:13+00:00

<img alt="Rosjanie " src="https://tvn24.pl/najnowsze/cdn-zdjecie-wezuxh-mieszkanka-charkowa-zaatakowanego-przez-sily-rosyjskie-7663206/alternates/LANDSCAPE_1280" />
    Kolejny atak sił rosyjskich na centrum Charkowa.

## Duże zmiany w Bułgarii i Rumunii. Jest jednogłośna decyzja
 - [https://tvn24.pl/biznes/turystyka/bulgaria-i-rumunia-w-strefie-schengen-rada-unii-europejskiej-o-szczegolach-st7663139?source=rss](https://tvn24.pl/biznes/turystyka/bulgaria-i-rumunia-w-strefie-schengen-rada-unii-europejskiej-o-szczegolach-st7663139?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T12:06:30+00:00

<img alt="Duże zmiany w Bułgarii i Rumunii. Jest jednogłośna decyzja" src="https://tvn24.pl/najnowsze/cdn-zdjecie-04kt9h-sofia-bulgaria-s-shutterstock605510027-5051298/alternates/LANDSCAPE_1280" />
    Poinformowała Rada Unii Europejskiej.

## "To nie jest likwidacja mediów publicznych. To jest likwidacja waszego szarogęszenia"
 - [https://tvn24.pl/polska/zmiany-w-mediach-publicznych-dyskusja-politykow-w-kawie-na-lawe-to-jest-likwidacja-waszego-szarogeszenia-7663066?source=rss](https://tvn24.pl/polska/zmiany-w-mediach-publicznych-dyskusja-politykow-w-kawie-na-lawe-to-jest-likwidacja-waszego-szarogeszenia-7663066?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T11:57:50+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-p0xi3v-31-1045-kawa-cl-0005-7663031/alternates/LANDSCAPE_1280" />
    Dyskusja w "Kawie na ławę".

## Zamiast do Czech, wjechał do parku narodowego. Twierdzi, że "zaufał nawigacji"
 - [https://tvn24.pl/wroclaw/jagniatkow-wjechal-samochodem-do-parku-narodowego-twierdzi-ze-zaufal-nawigacji-7663171?source=rss](https://tvn24.pl/wroclaw/jagniatkow-wjechal-samochodem-do-parku-narodowego-twierdzi-ze-zaufal-nawigacji-7663171?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T11:52:39+00:00

<img alt="Zamiast do Czech, wjechał do parku narodowego. Twierdzi, że " src="https://tvn24.pl/najnowsze/cdn-zdjecie-qob4li-kierowca-zostal-ukarany-mandatem-w-wysokosci-tysiaca-zlotych-7663172/alternates/LANDSCAPE_1280" />
    Obywatel Niemiec dostał tysiąc złotych mandatu.

## Jak dobrze wejść w nowy rok? Psycholożka radzi "mikro korekty" zamiast twardych postanowień
 - [https://tvn24.pl/polska/postanowienia-na-nowy-rok-2024-psycholog-radzi-jak-do-tego-podejsc-7662946?source=rss](https://tvn24.pl/polska/postanowienia-na-nowy-rok-2024-psycholog-radzi-jak-do-tego-podejsc-7662946?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T11:46:25+00:00

<img alt="Jak dobrze wejść w nowy rok? Psycholożka radzi " src="https://tvn24.pl/najnowsze/cdn-zdjecie-gb6iw1-joanna-heidtman-7662975/alternates/LANDSCAPE_1280" />
    Joanna Heidtman była gościnią programu "Wstajesz i weekend".

## Ceny prądu w 2024 roku. Zmiany weszły w życie
 - [https://tvn24.pl/biznes/z-kraju/ceny-energii-w2024-roku-ustawa-weszla-w-zycie-st7663042?source=rss](https://tvn24.pl/biznes/z-kraju/ceny-energii-w2024-roku-ustawa-weszla-w-zycie-st7663042?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T11:03:25+00:00

<img alt="Ceny prądu w 2024 roku. Zmiany weszły w życie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-94m9rm-prad-listwa-zasilanie-wlacznik-wylacznik-przedluzacz-wtyczka-shutterstock_566836174-5412254/alternates/LANDSCAPE_1280" />
    W niedzielę.

## Pogoda na 16 dni: dojdzie do starcia dwóch kolosów
 - [https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-16-dni-dojdzie-do-starcia-dwoch-kolosow-st7663079?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-16-dni-dojdzie-do-starcia-dwoch-kolosow-st7663079?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T10:57:39+00:00

<img alt="Pogoda na 16 dni: dojdzie do starcia dwóch kolosów" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-jcb10-pogoda-na-16-dni-7663097/alternates/LANDSCAPE_1280" />
    Autorska długoterminowa prognoza pogody Tomasza Wasilewskiego z tvnmeteo.pl.

## Chciała "postraszyć" znajomego, odpowie za zabójstwo
 - [https://tvn24.pl/rzeszow/krosno-ugodzila-nozem-znajomego-mezczyzna-zmarl-sledczym-tlumaczyla-ze-nie-chciala-zabic-a-jedynie-postraszyc-odpowie-za-zabojstwo-7662917?source=rss](https://tvn24.pl/rzeszow/krosno-ugodzila-nozem-znajomego-mezczyzna-zmarl-sledczym-tlumaczyla-ze-nie-chciala-zabic-a-jedynie-postraszyc-odpowie-za-zabojstwo-7662917?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T10:45:22+00:00

<img alt="Chciała " src="https://tvn24.pl/najnowsze/cdn-zdjecie-99t1uj-do-zdarzenia-doszlo-na-jednym-z-krosnienskich-osiedli-6930915/alternates/LANDSCAPE_1280" />
    32-latce grozi dożywocie.

## Dezinformacja w 2023 roku. Pięć nowych trendów
 - [https://konkret24.tvn24.pl/polityka/dezinformacja-w-2023-roku-piec-nowych-trendow-st7653041?source=rss](https://konkret24.tvn24.pl/polityka/dezinformacja-w-2023-roku-piec-nowych-trendow-st7653041?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T10:27:19+00:00

<img alt="Dezinformacja w 2023 roku. Pięć nowych trendów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2fs4rh-piec-nowych-trendow-w-dezinformacji-w-2023-roku-7651785/alternates/LANDSCAPE_1280" />
    Podsumowanie.

## Zdawała egzamin w Gdyni, w tym czasie zatrzymano "jej" prawo jazdy w stolicy
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-zdawala-egzamin-w-gdyni-w-tym-czasie-zatrzymano-jej-prawo-jazdy-w-stolicy-sledczy-wiedza-co-sie-stalo-st7653217?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-zdawala-egzamin-w-gdyni-w-tym-czasie-zatrzymano-jej-prawo-jazdy-w-stolicy-sledczy-wiedza-co-sie-stalo-st7653217?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T10:21:20+00:00

<img alt="Zdawała egzamin w Gdyni, w tym czasie zatrzymano " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-idqbp4-do-kontroli-doszlo-na-ulicy-sobieskiego-7653429/alternates/LANDSCAPE_1280" />
    Śledczy już wiedzą, co się stało.

## Od jutra zakaz w kilku województwach. Kara może sięgnąć pięciu tysięcy złotych
 - [https://tvn24.pl/biznes/z-kraju/kopciuchy-z-zakazem-od-1-stycznia-2024-roku-lista-wojewodztw-st7662933?source=rss](https://tvn24.pl/biznes/z-kraju/kopciuchy-z-zakazem-od-1-stycznia-2024-roku-lista-wojewodztw-st7662933?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T10:13:20+00:00

<img alt="Od jutra zakaz w kilku województwach. Kara może sięgnąć pięciu tysięcy złotych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-nlc92s-uwaga-na-smog-5648893/alternates/LANDSCAPE_1280" />
    Szczegóły.

## Był nieprzytomny, kiedy postawiono mu zarzuty zabójstwa. 37-latek zmarł
 - [https://tvn24.pl/lodz/lodz-zabojstwo-81-latki-podejrzany-37-latek-nie-zyje-sledztwo-zostalo-umorzone-7663020?source=rss](https://tvn24.pl/lodz/lodz-zabojstwo-81-latki-podejrzany-37-latek-nie-zyje-sledztwo-zostalo-umorzone-7663020?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T10:10:38+00:00

<img alt="Był nieprzytomny, kiedy postawiono mu zarzuty zabójstwa. 37-latek zmarł" src="https://tvn24.pl/najnowsze/cdn-zdjecie-site4s-okolicznosci-tragedii-bada-policja-zdjecie-ilustracyjne-7378167/alternates/LANDSCAPE_1280" />
    Mężczyzna był podejrzany o zabicie 81-letniej łodzianki.

## Zwłoki kobiety w stawie. Ciało 36-latki zauważył spacerowicz
 - [https://tvn24.pl/tvnwarszawa/najnowsze/kroczewo-cialo-kobiety-w-stawie-w-parku-st7662932?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/kroczewo-cialo-kobiety-w-stawie-w-parku-st7662932?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T09:50:44+00:00

<img alt="Zwłoki kobiety w stawie. Ciało 36-latki zauważył spacerowicz" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-shhmq9-w-stawie-odnaleziono-cialo-7662943/alternates/LANDSCAPE_1280" />
    Policja ustala okoliczności jej śmierci.

## Jeśli już strzelać z fajerwerków, to tylko w taki sposób
 - [https://tvn24.pl/lodz/noc-sylwestrowa-jak-bezpiecznie-korzystac-z-fajerwerkow-podstawowe-zasady-bezpieczenstwa-7662980?source=rss](https://tvn24.pl/lodz/noc-sylwestrowa-jak-bezpiecznie-korzystac-z-fajerwerkow-podstawowe-zasady-bezpieczenstwa-7662980?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T09:37:32+00:00

<img alt="Jeśli już strzelać z fajerwerków, to tylko w taki sposób" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pyp96t-sluzby-kontroluja-punkty-sprzedazy-fajerwerkow-7663002/alternates/LANDSCAPE_1280" />
    Podstawowe zasady bezpieczeństwa.

## Był prezydentem przez 13 lat. Więcej już nie może
 - [https://tvn24.pl/swiat/boliwia-evo-morales-nie-moze-ubiegac-sie-o-urzad-prezydenta-7662900?source=rss](https://tvn24.pl/swiat/boliwia-evo-morales-nie-moze-ubiegac-sie-o-urzad-prezydenta-7662900?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T09:02:25+00:00

<img alt="Był prezydentem przez 13 lat. Więcej już nie może" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kohcwv-evo-morales-7662876/alternates/LANDSCAPE_1280" />
    Po wyroku Trybunału Konstytucyjnego.

## Jak "kozacy" stali się "idiotami". Przestajemy być drogowym piekłem
 - [https://tvn24.pl/lodz/statystyki-wypadkow-w-2023-roku-lepsze-niz-rok-temu-polska-zbliza-sie-do-europejskiej-sredniej-7544272?source=rss](https://tvn24.pl/lodz/statystyki-wypadkow-w-2023-roku-lepsze-niz-rok-temu-polska-zbliza-sie-do-europejskiej-sredniej-7544272?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T09:01:31+00:00

<img alt="Jak " src="https://tvn24.pl/najnowsze/cdn-zdjecie-9bcmh-smiertelny-wypadek-w-okolicach-przystanku-grenadierow-na-alei-waszyngtona-7430176/alternates/LANDSCAPE_1280" />
    Wiemy, jak zmieniły się statystyki wypadków w porównaniu do 2022 roku.

## Wakacje kredytowe nie dla wszystkich chętnych
 - [https://tvn24.pl/biznes/pieniadze/wakacje-kredytowe-2024-parametr-raty-do-dochodu-rata-a-dochody-wyliczenia-ekonomisty-rafala-mundrego-st7662875?source=rss](https://tvn24.pl/biznes/pieniadze/wakacje-kredytowe-2024-parametr-raty-do-dochodu-rata-a-dochody-wyliczenia-ekonomisty-rafala-mundrego-st7662875?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T08:44:21+00:00

<img alt="Wakacje kredytowe nie dla wszystkich chętnych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lkvkoy-komputer-podatki-platnosc-bankowosc-cyberbezpieczenstwo-6721732/alternates/LANDSCAPE_1280" />
    Wyliczenia ekonomisty Rafała Mundrego.

## Mieszkańcy Poland powitali Nowy Rok jako pierwsi na świecie
 - [https://tvn24.pl/tvnmeteo/swiat/nowy-rok-2024-kto-powita-nowy-rok-jako-pierwszy-mieszkancy-wioski-poland-st7662859?source=rss](https://tvn24.pl/tvnmeteo/swiat/nowy-rok-2024-kto-powita-nowy-rok-jako-pierwszy-mieszkancy-wioski-poland-st7662859?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T08:15:01+00:00

<img alt="Mieszkańcy Poland powitali Nowy Rok jako pierwsi na świecie" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-umth4y-wioska-poland-polozona-na-atolu-kiritimati-7662890/alternates/LANDSCAPE_1280" />
    Wioska położona jest na Pacyfiku.

## 2023 rokiem sztucznej inteligencji. I zbiorowej "halucynacji" o niej
 - [https://tvn24.pl/premium/2023-rokiem-sztucznej-inteligencji-i-zbiorowej-halucynacji-o-niej-7653717?source=rss](https://tvn24.pl/premium/2023-rokiem-sztucznej-inteligencji-i-zbiorowej-halucynacji-o-niej-7653717?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T08:11:50+00:00

<img alt="2023 rokiem sztucznej inteligencji. I zbiorowej " src="https://tvn24.pl/najnowsze/cdn-zdjecie-l2ta3f-shutterstock_2278965815-7653779/alternates/LANDSCAPE_1280" />
    ChatGPT od roku programuje, pisze listy motywacyjne, wypracowania i korporacyjne raporty. Stał się kolejnym narzędziem w walce o naszą uwagę. I przeniósł debatę o sztucznej inteligencji do mainstreamu. Z pomocą ekspertów w tvn24.pl spróbowaliśmy odsiać to, co jest w tej dyskusji ważne, od tego, co jest tylko "zbiorową halucynacją".

## Wymiana ognia na Morzu Czerwonym. Trzy łodzie zatopione
 - [https://tvn24.pl/swiat/jemen-sily-amerykanskie-stracily-dwa-pociski-wystrzelone-z-terenow-kontrolowanych-przez-bojownikow-huti-7662786?source=rss](https://tvn24.pl/swiat/jemen-sily-amerykanskie-stracily-dwa-pociski-wystrzelone-z-terenow-kontrolowanych-przez-bojownikow-huti-7662786?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T07:41:44+00:00

<img alt="Wymiana ognia na Morzu Czerwonym. Trzy łodzie zatopione" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ryxcdt-gcoyk3cbeaax8i5-7662825/alternates/LANDSCAPE_1280" />
    Podało Dowództwo Centralne Stanów Zjednoczonych.

## "Obietnica pojednania", "pustosłowie". Polityczne komentarze po orędziu
 - [https://tvn24.pl/polska/oredzie-donalda-tuska-komentarze-politykow-7662839?source=rss](https://tvn24.pl/polska/oredzie-donalda-tuska-komentarze-politykow-7662839?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T07:39:12+00:00

<img alt="" src="https://tvn24.pl/polska/cdn-zdjecie-11x7mm-tusk-7662858/alternates/LANDSCAPE_1280" />
    Premier wygłosił w sobotę orędzie do narodu.

## "Ukraina odzyskała morze, niebo stało się bezpieczniejsze"
 - [https://tvn24.pl/swiat/wolodymyr-zelenski-ukraina-odzyskala-morze-niebo-stalo-sie-bezpieczniejsze-7658243?source=rss](https://tvn24.pl/swiat/wolodymyr-zelenski-ukraina-odzyskala-morze-niebo-stalo-sie-bezpieczniejsze-7658243?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T07:13:57+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1v6m3z-zelenski-7662840/alternates/LANDSCAPE_1280" />
    Wołodymyr Zełenski oświadczył, że siły ukraińskie nie wycofały się na żadnym kierunku w wojnie z Rosją.

## Wielkie chwile Świątek, złoci siatkarze i skompromitowani piłkarze. Taki był rok 2023
 - [https://eurosport.tvn24.pl/inne-sporty/sportowe-podsumowanie-2023.-piec-najwazniejszych-wydarzen-w-polskim-i-swiatowym-sporcie_sto9936419/story.shtml?source=rss](https://eurosport.tvn24.pl/inne-sporty/sportowe-podsumowanie-2023.-piec-najwazniejszych-wydarzen-w-polskim-i-swiatowym-sporcie_sto9936419/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T07:13:38+00:00

<img alt="Wielkie chwile Świątek, złoci siatkarze i skompromitowani piłkarze. Taki był rok 2023" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qil88g-sportowe-podsumowanie-2023-roku-7662860/alternates/LANDSCAPE_1280" />
    Eurosport.pl wybrał pięć najważniejszych wydarzeń w polskim i światowym sporcie.

## Potężne fale porywają ludzi i zalewają ulice
 - [https://tvn24.pl/tvnmeteo/swiat/usa-kalifornia-potezne-fale-porywaja-ludzi-i-zalewaja-ulice-wydano-nakaz-ewakuacji-st7662795?source=rss](https://tvn24.pl/tvnmeteo/swiat/usa-kalifornia-potezne-fale-porywaja-ludzi-i-zalewaja-ulice-wydano-nakaz-ewakuacji-st7662795?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T06:13:12+00:00

<img alt="Potężne fale porywają ludzi i zalewają ulice" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-8783u3-kalifornia-7662820/alternates/LANDSCAPE_1280" />
    Sztorm szaleje u wybrzeży Kalifornii.

## Szturm na placówki medyczne "największy od 15 lat". Lekarze alarmują
 - [https://tvn24.pl/swiat/hiszpania-wlochy-coraz-wiecej-zachorowan-na-grype-i-koronawirusa-trwa-szturm-na-placowki-medyczne-7660360?source=rss](https://tvn24.pl/swiat/hiszpania-wlochy-coraz-wiecej-zachorowan-na-grype-i-koronawirusa-trwa-szturm-na-placowki-medyczne-7660360?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T05:51:15+00:00

<img alt="Szturm na placówki medyczne " src="https://tvn24.pl/najnowsze/cdn-zdjecie-9tga8f-szpital-wlochy-7662805/alternates/LANDSCAPE_1280" />
    W Hiszpanii i we Włoszech.

## Świątek w czołówce, odległa lokata Lewandowskiego
 - [https://eurosport.tvn24.pl/tenis/iga-swiatek-szosta-w-w-plebiscycie-swiatowego-stowarzyszenia-prasy-sportowej-aips-.-robert-lewandows_sto9939526/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/iga-swiatek-szosta-w-w-plebiscycie-swiatowego-stowarzyszenia-prasy-sportowej-aips-.-robert-lewandows_sto9939526/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T05:21:40+00:00

<img alt="Świątek w czołówce, odległa lokata Lewandowskiego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9esrsb-iga-swiatek-7662796/alternates/LANDSCAPE_1280" />
    Bezkonkurencyjni okazali się gimnastyczka Simone Biles i tenisista Novak Djoković.

## Specjalny patrol wyruszy w sylwestrową noc
 - [https://tvn24.pl/trojmiasto/sylwester-2024-zaginione-psy-specjalny-partol-w-warszawie-i-na-pomorzu-gdzie-dzwonic-7654913?source=rss](https://tvn24.pl/trojmiasto/sylwester-2024-zaginione-psy-specjalny-partol-w-warszawie-i-na-pomorzu-gdzie-dzwonic-7654913?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T04:46:37+00:00

<img alt="Specjalny patrol wyruszy w sylwestrową noc" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mjqpil-noc-sylwestrowa-to-dla-zwierzat-najtrudniejszy-czas-w-roku-7654906/alternates/LANDSCAPE_1280" />
    OTOZ Animals chce wesprzeć służby odpowiedzialne za zabezpieczenie uciekających zwierząt.

## "Polska religijność, etyka jest bezmyślna kompletnie". Profesor Gadacz o "ślepych ideach" w Polsce
 - [https://tvn24.pl/go/programy,7/bez-polityki-odcinki,413879/odcinek-165,S00E165,1246300?source=rss](https://tvn24.pl/go/programy,7/bez-polityki-odcinki,413879/odcinek-165,S00E165,1246300?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T04:10:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-l9phpc-prof-tadeusz-gadacz-piotr-jacon-7654376/alternates/LANDSCAPE_1280" />
    Rozmowa Piotra Jaconia.

## Sylwester z dodatnią temperaturą. W części kraju musimy spodziewać się deszczu
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-dzis-niedziela-3112-miejscami-moze-popadac-od-3-do-8-stopni-st7654901?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-dzis-niedziela-3112-miejscami-moze-popadac-od-3-do-8-stopni-st7654901?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-12-31T01:00:00+00:00

<img alt="Sylwester z dodatnią temperaturą. W części kraju musimy spodziewać się deszczu" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-jq2lg2-deszcz-6591723/alternates/LANDSCAPE_1280" />
    Sprawdź szczegóły prognozy pogody.

