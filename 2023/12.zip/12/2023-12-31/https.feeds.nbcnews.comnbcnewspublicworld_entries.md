# Source:NBC world, URL:https://feeds.nbcnews.com/nbcnews/public/world, language:en-US

## Denmark’s Queen Margrethe II announces she will abdicate the throne
 - [https://www.nbcnews.com/video/denmark-s-queen-margrethe-ii-announces-she-will-abdicate-the-throne-201165893820](https://www.nbcnews.com/video/denmark-s-queen-margrethe-ii-announces-she-will-abdicate-the-throne-201165893820)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/world
 - date published: 2023-12-31T19:50:07+00:00

Queen Margrethe II of Denmark said she will abdicate the throne on January 14, 2024, in a surprise announcement during her traditional New Year speech. The 83-year-old queen is Denmark’s longest-serving monarch in Europe following the death of Queen Elizabeth II.

## North Korea’s Kim vows to launch 3 more spy satellites and produce more nuclear materials in 2024
 - [https://www.nbcnews.com/news/world/north-koreas-kim-vows-launch-3-spy-satellites-produce-nuclear-material-rcna131752](https://www.nbcnews.com/news/world/north-koreas-kim-vows-launch-3-spy-satellites-produce-nuclear-material-rcna131752)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/world
 - date published: 2023-12-31T16:32:01+00:00

SEOUL, South Korea — North Korean leader Kim Jong Un vowed to launch three additional military spy satellites, produce more nuclear materials and introduce attack drones in 2024, as he called for “overwhelming” war readiness to cope with U.S.-led confrontational moves, state media reported Sunday.

## U.S. shoots down 2 missiles fired from Houthi-controlled areas
 - [https://www.nbcnews.com/news/world/blog/israel-hamas-war-live-updates-rcna131667](https://www.nbcnews.com/news/world/blog/israel-hamas-war-live-updates-rcna131667)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/world
 - date published: 2023-12-31T03:01:04+00:00

Follow NBC News for the latest live updates on the Israel-Hamas war as the Biden administration approves a $147.5 million weapons sale to Israel and the IDF advances on refugee camps

