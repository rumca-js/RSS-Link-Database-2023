# Source:3D Printing, URL:https://www.reddit.com/r/3Dprinting/.rss, language:en

## Got mad and converted my ender 3 max to direct drive lol
 - [https://www.reddit.com/r/3Dprinting/comments/18viwis/got_mad_and_converted_my_ender_3_max_to_direct](https://www.reddit.com/r/3Dprinting/comments/18viwis/got_mad_and_converted_my_ender_3_max_to_direct)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-12-31T22:35:33+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18viwis/got_mad_and_converted_my_ender_3_max_to_direct/"> <img alt="Got mad and converted my ender 3 max to direct drive lol" src="https://external-preview.redd.it/MjY1cGp6Mm1qcDljMVYPgKw3YL18AAiW7GtP0Ed7cgSYuYE1gPLGPO8VTXUB.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=3e0dcb94adf999a3051d0f0fd2e9c6a1039bfde8" title="Got mad and converted my ender 3 max to direct drive lol" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Michael_Yurov"> /u/Michael_Yurov </a> <br /> <span><a href="https://v.redd.it/ol8qf25mjp9c1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18viwis/got_mad_and_converted_my_ender_3_max_to_direct/">[comments]</a></span> </td></tr></table>

## Cat-printer
 - [https://www.reddit.com/r/3Dprinting/comments/18vhq1h/catprinter](https://www.reddit.com/r/3Dprinting/comments/18vhq1h/catprinter)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-12-31T21:35:23+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18vhq1h/catprinter/"> <img alt="Cat-printer" src="https://preview.redd.it/x8yk17qv8p9c1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=f96336d9c084af4c6da59cca5895c32dfdedc47e" title="Cat-printer" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Bam_904__"> /u/Bam_904__ </a> <br /> <span><a href="https://i.redd.it/x8yk17qv8p9c1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18vhq1h/catprinter/">[comments]</a></span> </td></tr></table>

## What is the most USEFUL or practical thing you've ever printed?
 - [https://www.reddit.com/r/3Dprinting/comments/18vhp8r/what_is_the_most_useful_or_practical_thing_youve](https://www.reddit.com/r/3Dprinting/comments/18vhp8r/what_is_the_most_useful_or_practical_thing_youve)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-12-31T21:34:20+00:00

<!-- SC_OFF --><div class="md"><p>I've seen a lot of impressive decorative designs, but what is the most useful/practical thing you've ever printed?</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Exact_Vacation7299"> /u/Exact_Vacation7299 </a> <br /> <span><a href="https://www.reddit.com/r/3Dprinting/comments/18vhp8r/what_is_the_most_useful_or_practical_thing_youve/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18vhp8r/what_is_the_most_useful_or_practical_thing_youve/">[comments]</a></span>

## I like the orange and white fusion
 - [https://www.reddit.com/r/3Dprinting/comments/18vfte5/i_like_the_orange_and_white_fusion](https://www.reddit.com/r/3Dprinting/comments/18vfte5/i_like_the_orange_and_white_fusion)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-12-31T20:02:06+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18vfte5/i_like_the_orange_and_white_fusion/"> <img alt="I like the orange and white fusion" src="https://preview.redd.it/u79kmwr7so9c1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=8cdd04afec313ea0dd322159ca2ca70da958d606" title="I like the orange and white fusion" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Printing an iphone 15 pro case, using esun abs + material for both color. Stl is here. <a href="https://www.printables.com/model/612104-iphone-15-pro-case">https://www.printables.com/model/612104-iphone-15-pro-case</a></p> <p>Will remix the corners so the sides bend and allow the phone to be inserted, for now ill make a cut vertically on corners.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Sandy_SN"> /u/Sandy_SN </a> <br /> <span><a href="https://i.redd.it/u79kmwr7so9c1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/commen

## My second attempt at a 3D printed PC case
 - [https://www.reddit.com/r/3Dprinting/comments/18vep3m/my_second_attempt_at_a_3d_printed_pc_case](https://www.reddit.com/r/3Dprinting/comments/18vep3m/my_second_attempt_at_a_3d_printed_pc_case)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-12-31T19:09:57+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18vep3m/my_second_attempt_at_a_3d_printed_pc_case/"> <img alt="My second attempt at a 3D printed PC case" src="https://b.thumbs.redditmedia.com/TULhxFAcH8jRT9BySw1yCF7-vu9PNpGl1CEjwlBgg-Q.jpg" title="My second attempt at a 3D printed PC case" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/YMCUPN"> /u/YMCUPN </a> <br /> <span><a href="https://www.reddit.com/gallery/18venqc">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18vep3m/my_second_attempt_at_a_3d_printed_pc_case/">[comments]</a></span> </td></tr></table>

## Did I just find the bed dry box ever?
 - [https://www.reddit.com/r/3Dprinting/comments/18ve9v0/did_i_just_find_the_bed_dry_box_ever](https://www.reddit.com/r/3Dprinting/comments/18ve9v0/did_i_just_find_the_bed_dry_box_ever)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-12-31T18:50:02+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18ve9v0/did_i_just_find_the_bed_dry_box_ever/"> <img alt="Did I just find the bed dry box ever?" src="https://b.thumbs.redditmedia.com/XODiY5EmeYYJT1nTcf3riimsaei3bOrBK7IePJV5chY.jpg" title="Did I just find the bed dry box ever?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Dekatater"> /u/Dekatater </a> <br /> <span><a href="https://www.reddit.com/gallery/18ve9v0">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18ve9v0/did_i_just_find_the_bed_dry_box_ever/">[comments]</a></span> </td></tr></table>

## Impressive adhesion
 - [https://www.reddit.com/r/3Dprinting/comments/18vdskg/impressive_adhesion](https://www.reddit.com/r/3Dprinting/comments/18vdskg/impressive_adhesion)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-12-31T18:27:10+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18vdskg/impressive_adhesion/"> <img alt="Impressive adhesion" src="https://preview.redd.it/3pm67iuabo9c1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=6d1ca4440977d108c19587ae49be9b4098858c4f" title="Impressive adhesion" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>No glue stick, just the default textured plate.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/sunsetodrive"> /u/sunsetodrive </a> <br /> <span><a href="https://i.redd.it/3pm67iuabo9c1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18vdskg/impressive_adhesion/">[comments]</a></span> </td></tr></table>

## Making Pokémon is fun
 - [https://www.reddit.com/r/3Dprinting/comments/18vdn2o/making_pokémon_is_fun](https://www.reddit.com/r/3Dprinting/comments/18vdn2o/making_pokémon_is_fun)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-12-31T18:20:00+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18vdn2o/making_pokémon_is_fun/"> <img alt="Making Pokémon is fun" src="https://preview.redd.it/e29avml0ao9c1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=3bf45d846a4c172a63c884ba3b70474e0556b805" title="Making Pokémon is fun" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/MightyH3idi"> /u/MightyH3idi </a> <br /> <span><a href="https://i.redd.it/e29avml0ao9c1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18vdn2o/making_pokémon_is_fun/">[comments]</a></span> </td></tr></table>

## Just bought a filament dryer, and they had the balls to ask me for a tip.
 - [https://www.reddit.com/r/3Dprinting/comments/18vdluu/just_bought_a_filament_dryer_and_they_had_the](https://www.reddit.com/r/3Dprinting/comments/18vdluu/just_bought_a_filament_dryer_and_they_had_the)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-12-31T18:18:16+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18vdluu/just_bought_a_filament_dryer_and_they_had_the/"> <img alt="Just bought a filament dryer, and they had the balls to ask me for a tip." src="https://preview.redd.it/lo5l1lpp9o9c1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=6e0b9a662c394c92600e266f0f0203da31a434bf" title="Just bought a filament dryer, and they had the balls to ask me for a tip." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Aluzuka"> /u/Aluzuka </a> <br /> <span><a href="https://i.redd.it/lo5l1lpp9o9c1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18vdluu/just_bought_a_filament_dryer_and_they_had_the/">[comments]</a></span> </td></tr></table>

## Yoda has patinaed nicely he has
 - [https://www.reddit.com/r/3Dprinting/comments/18vbzx7/yoda_has_patinaed_nicely_he_has](https://www.reddit.com/r/3Dprinting/comments/18vbzx7/yoda_has_patinaed_nicely_he_has)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-12-31T17:01:59+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18vbzx7/yoda_has_patinaed_nicely_he_has/"> <img alt="Yoda has patinaed nicely he has" src="https://b.thumbs.redditmedia.com/y3YeyatX2rFoLtyzjYXj8QB9YwPD-6KPcpucS25tUPc.jpg" title="Yoda has patinaed nicely he has" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Printed with Protopasta Bronze metal composite HTPLA about 9 months ago.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/hue_sick"> /u/hue_sick </a> <br /> <span><a href="https://www.reddit.com/gallery/18vbzx7">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18vbzx7/yoda_has_patinaed_nicely_he_has/">[comments]</a></span> </td></tr></table>

## My 6th print.
 - [https://www.reddit.com/r/3Dprinting/comments/18vbchx/my_6th_print](https://www.reddit.com/r/3Dprinting/comments/18vbchx/my_6th_print)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-12-31T16:32:10+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18vbchx/my_6th_print/"> <img alt="My 6th print." src="https://b.thumbs.redditmedia.com/pPAPKZk6x1tJx0pMoDKUtWYMbqGbeSIM-2Xpkc8DF-k.jpg" title="My 6th print." /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Four dragons and one cat later.</p> <p>Printer: Ender 3 V2 Slicer: Creality Slicer Mods: PEI bed, Bltouch, mriscoc firmware</p> <p>Tried the tramming and auto bed leveling. 15 hours, but I think my speed was too high so I changed from 100 to 50.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/TheCircuitBox"> /u/TheCircuitBox </a> <br /> <span><a href="https://www.reddit.com/gallery/18vbchx">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18vbchx/my_6th_print/">[comments]</a></span> </td></tr></table>

## DNA Style Pencil Holder
 - [https://www.reddit.com/r/3Dprinting/comments/18vapue/dna_style_pencil_holder](https://www.reddit.com/r/3Dprinting/comments/18vapue/dna_style_pencil_holder)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-12-31T16:02:21+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18vapue/dna_style_pencil_holder/"> <img alt="DNA Style Pencil Holder" src="https://b.thumbs.redditmedia.com/NNSOkc8YdGM2UcRyLUpsmvhMMEhLUiV9e41-wp8VSjk.jpg" title="DNA Style Pencil Holder" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ego1138"> /u/ego1138 </a> <br /> <span><a href="https://www.reddit.com/gallery/18vapue">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18vapue/dna_style_pencil_holder/">[comments]</a></span> </td></tr></table>

## "Dragons may not have much real use for all their wealth, but they know it to an ounce as a rule, especially after long possession."
 - [https://www.reddit.com/r/3Dprinting/comments/18vaijz/dragons_may_not_have_much_real_use_for_all_their](https://www.reddit.com/r/3Dprinting/comments/18vaijz/dragons_may_not_have_much_real_use_for_all_their)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-12-31T15:52:48+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18vaijz/dragons_may_not_have_much_real_use_for_all_their/"> <img alt="&quot;Dragons may not have much real use for all their wealth, but they know it to an ounce as a rule, especially after long possession.&quot;" src="https://b.thumbs.redditmedia.com/yY0hoQU0BkWhj6F89ZzNvjyhf5B9OSGsCoAdBWHsqkU.jpg" title="&quot;Dragons may not have much real use for all their wealth, but they know it to an ounce as a rule, especially after long possession.&quot;" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/BaZing3"> /u/BaZing3 </a> <br /> <span><a href="https://www.reddit.com/gallery/18vaijz">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18vaijz/dragons_may_not_have_much_real_use_for_all_their/">[comments]</a></span> </td></tr></table>

## Weird little light I made.
 - [https://www.reddit.com/r/3Dprinting/comments/18vahav/weird_little_light_i_made](https://www.reddit.com/r/3Dprinting/comments/18vahav/weird_little_light_i_made)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-12-31T15:51:05+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18vahav/weird_little_light_i_made/"> <img alt="Weird little light I made." src="https://b.thumbs.redditmedia.com/WVCu7L3z7NEvJpGUS5JoYi-H5fWXC-LigbD4syOmirA.jpg" title="Weird little light I made." /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Pretty happy with the numakers filament. Cheap(ish) and prints nicely.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/kingrobin"> /u/kingrobin </a> <br /> <span><a href="https://www.reddit.com/gallery/18vahav">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18vahav/weird_little_light_i_made/">[comments]</a></span> </td></tr></table>

## Carbon PLA is perfect for the mouse kit.
 - [https://www.reddit.com/r/3Dprinting/comments/18v9g2h/carbon_pla_is_perfect_for_the_mouse_kit](https://www.reddit.com/r/3Dprinting/comments/18v9g2h/carbon_pla_is_perfect_for_the_mouse_kit)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-12-31T15:00:28+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18v9g2h/carbon_pla_is_perfect_for_the_mouse_kit/"> <img alt="Carbon PLA is perfect for the mouse kit." src="https://preview.redd.it/nm69fp7fan9c1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=aac079423b8205dfab7061a54348da5283d464f6" title="Carbon PLA is perfect for the mouse kit." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/auto_egr"> /u/auto_egr </a> <br /> <span><a href="https://i.redd.it/nm69fp7fan9c1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18v9g2h/carbon_pla_is_perfect_for_the_mouse_kit/">[comments]</a></span> </td></tr></table>

## 0.2mm nozzles are pretty magical
 - [https://www.reddit.com/r/3Dprinting/comments/18v8mmp/02mm_nozzles_are_pretty_magical](https://www.reddit.com/r/3Dprinting/comments/18v8mmp/02mm_nozzles_are_pretty_magical)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-12-31T14:15:48+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18v8mmp/02mm_nozzles_are_pretty_magical/"> <img alt="0.2mm nozzles are pretty magical" src="https://preview.redd.it/n8yh5bnc2n9c1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=5e51b49ca5b66b525f242b166134839da046a1e5" title="0.2mm nozzles are pretty magical" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/TheSameNameTwice"> /u/TheSameNameTwice </a> <br /> <span><a href="https://i.redd.it/n8yh5bnc2n9c1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18v8mmp/02mm_nozzles_are_pretty_magical/">[comments]</a></span> </td></tr></table>

## Weathered Smilodon Skull
 - [https://www.reddit.com/r/3Dprinting/comments/18v7yto/weathered_smilodon_skull](https://www.reddit.com/r/3Dprinting/comments/18v7yto/weathered_smilodon_skull)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-12-31T13:39:22+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18v7yto/weathered_smilodon_skull/"> <img alt="Weathered Smilodon Skull" src="https://b.thumbs.redditmedia.com/YUcCebMV6SjLMYmCEMs65SFLeP_SrNzvu5qqjb3JQzE.jpg" title="Weathered Smilodon Skull" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Boonlink"> /u/Boonlink </a> <br /> <span><a href="https://www.reddit.com/gallery/18v7yto">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18v7yto/weathered_smilodon_skull/">[comments]</a></span> </td></tr></table>

## Tool for holding sonicator in place to release virus from cells. Don’t ask me for details on that application , I just build the stuff for the wife.
 - [https://www.reddit.com/r/3Dprinting/comments/18v7jve/tool_for_holding_sonicator_in_place_to_release](https://www.reddit.com/r/3Dprinting/comments/18v7jve/tool_for_holding_sonicator_in_place_to_release)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-12-31T13:15:46+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18v7jve/tool_for_holding_sonicator_in_place_to_release/"> <img alt="Tool for holding sonicator in place to release virus from cells. Don’t ask me for details on that application , I just build the stuff for the wife." src="https://b.thumbs.redditmedia.com/_QAst_QRKg4DOnWme8t5BFvCcQvWQkd_IZzueq7wV5I.jpg" title="Tool for holding sonicator in place to release virus from cells. Don’t ask me for details on that application , I just build the stuff for the wife." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/g713"> /u/g713 </a> <br /> <span><a href="https://www.reddit.com/gallery/18v7jve">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18v7jve/tool_for_holding_sonicator_in_place_to_release/">[comments]</a></span> </td></tr></table>

## Gosper curve fractal printed in vase mode
 - [https://www.reddit.com/r/3Dprinting/comments/18v7igm/gosper_curve_fractal_printed_in_vase_mode](https://www.reddit.com/r/3Dprinting/comments/18v7igm/gosper_curve_fractal_printed_in_vase_mode)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-12-31T13:13:24+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18v7igm/gosper_curve_fractal_printed_in_vase_mode/"> <img alt="Gosper curve fractal printed in vase mode" src="https://external-preview.redd.it/eXBzZnBpa2JybTljMTG-zvK2iNwFG42Eh3ow7beAlOR8RmK1mYZR4GztKHh_.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=cbe1bbc8487a33babe01adfdeeb1279513d6daae" title="Gosper curve fractal printed in vase mode" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/SmoothDragon561"> /u/SmoothDragon561 </a> <br /> <span><a href="https://v.redd.it/b0ymb6u0rm9c1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18v7igm/gosper_curve_fractal_printed_in_vase_mode/">[comments]</a></span> </td></tr></table>

## Something to print in time for the new year
 - [https://www.reddit.com/r/3Dprinting/comments/18v73il/something_to_print_in_time_for_the_new_year](https://www.reddit.com/r/3Dprinting/comments/18v73il/something_to_print_in_time_for_the_new_year)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-12-31T12:48:33+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18v73il/something_to_print_in_time_for_the_new_year/"> <img alt="Something to print in time for the new year" src="https://external-preview.redd.it/MWVzeGRyc3VtbTljMYQkac4qiJomeM1brPxlnS8JpZN5MRTn_lcXUwANEDqW.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=6c6850ebfacd57191fb33b0d211dce8ca263bb98" title="Something to print in time for the new year" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Jeandre11"> /u/Jeandre11 </a> <br /> <span><a href="https://v.redd.it/n1ld23crmm9c1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18v73il/something_to_print_in_time_for_the_new_year/">[comments]</a></span> </td></tr></table>

## My first annual Christmas house 🎄🎉
 - [https://www.reddit.com/r/3Dprinting/comments/18v6r9c/my_first_annual_christmas_house](https://www.reddit.com/r/3Dprinting/comments/18v6r9c/my_first_annual_christmas_house)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-12-31T12:25:59+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18v6r9c/my_first_annual_christmas_house/"> <img alt="My first annual Christmas house 🎄🎉" src="https://external-preview.redd.it/cmJxczJnenNpbTljMa_MlWb-AmxDxIxPKglXiqiJzXL4nbRYwKOklM9k0Tye.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=274ebaaaa8732a2b21e2674dd8e54bc1b81b4ee0" title="My first annual Christmas house 🎄🎉" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I love little dioramas and Christmas houses and this is the first year I’ve had a printer to make our own. Father-son project (he’s only 6 so I did most of the work). Now we have our first annual family Christmas house and I’ll do this every year. ❤️🎄</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/InfiniteShowrooms"> /u/InfiniteShowrooms </a> <br /> <span><a href="https://v.redd.it/wk16an6tim9c1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18v6r9c/my_first_annual_chris

## First layer
 - [https://www.reddit.com/r/3Dprinting/comments/18v6nqn/first_layer](https://www.reddit.com/r/3Dprinting/comments/18v6nqn/first_layer)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-12-31T12:19:19+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18v6nqn/first_layer/"> <img alt="First layer" src="https://preview.redd.it/pubqrjznhm9c1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=a91f3b26ca7000e99bc4564a67a48cf19669e511" title="First layer" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Hello community,</p> <p>Im having a hard time figuring to perfect my first layer. Currently using BL Touch with 5x5 probing on magnetic bed sheet. Creality CR-10S</p> <p>Anyone can tell me whats going on here? I thought BL Touch will eliminate first layer issue, maybe im wrong here...</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Extra_Pizza_8117"> /u/Extra_Pizza_8117 </a> <br /> <span><a href="https://i.redd.it/pubqrjznhm9c1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18v6nqn/first_layer/">[comments]</a></span> </td></tr></table>

## I printed a kebab stand
 - [https://www.reddit.com/r/3Dprinting/comments/18v6dix/i_printed_a_kebab_stand](https://www.reddit.com/r/3Dprinting/comments/18v6dix/i_printed_a_kebab_stand)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-12-31T12:00:27+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18v6dix/i_printed_a_kebab_stand/"> <img alt="I printed a kebab stand" src="https://preview.redd.it/hojeroj5em9c1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=925e1db1db5b0039be3ca5644211a8b05fc56bca" title="I printed a kebab stand" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ogmudbone54"> /u/ogmudbone54 </a> <br /> <span><a href="https://i.redd.it/hojeroj5em9c1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18v6dix/i_printed_a_kebab_stand/">[comments]</a></span> </td></tr></table>

## First Prototype of my Swiss Escapement desktop fidget
 - [https://www.reddit.com/r/3Dprinting/comments/18v42pk/first_prototype_of_my_swiss_escapement_desktop](https://www.reddit.com/r/3Dprinting/comments/18v42pk/first_prototype_of_my_swiss_escapement_desktop)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-12-31T09:18:56+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18v42pk/first_prototype_of_my_swiss_escapement_desktop/"> <img alt="First Prototype of my Swiss Escapement desktop fidget" src="https://external-preview.redd.it/YmxrbG45OHJrbDljMc4EBpq2kLH0_m_stg111hBarPQaWrmdvH8f4SqapLqG.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=57954e48d1d7eeddcfa5d19708850e0d112e1963" title="First Prototype of my Swiss Escapement desktop fidget" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I really love the sound of old mechanical clocks and I like wind-up little things.</p> <p>So I figured I'd try and design a little Swiss Escapement toy that I could wind up real quick and hear that soothing click-clack.</p> <p>I've never done any mechanical engineering, so my challenge was to create it entirely myself. I could look at schematics, but couldn't use any premade models or copy a design someone already had made.</p> <p>Right now, I can get about 30 seconds per wind, and I want to try

## What Slicing Program are you using and why?
 - [https://www.reddit.com/r/3Dprinting/comments/18v40ia/what_slicing_program_are_you_using_and_why](https://www.reddit.com/r/3Dprinting/comments/18v40ia/what_slicing_program_are_you_using_and_why)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-12-31T09:14:45+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18v40ia/what_slicing_program_are_you_using_and_why/"> <img alt="What Slicing Program are you using and why?" src="https://preview.redd.it/1dmjc7uqkl9c1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=c79832dffd9338aa560370a78084a2ee6fa49a49" title="What Slicing Program are you using and why?" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>What made you choose to use the slicer software you are currently using? What benefits did it have over other slicing programs?</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/MisfitPanda94"> /u/MisfitPanda94 </a> <br /> <span><a href="https://i.redd.it/1dmjc7uqkl9c1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18v40ia/what_slicing_program_are_you_using_and_why/">[comments]</a></span> </td></tr></table>

## I'm super pleased with myself when I solve a practical problem for practically free
 - [https://www.reddit.com/r/3Dprinting/comments/18v3n1f/im_super_pleased_with_myself_when_i_solve_a](https://www.reddit.com/r/3Dprinting/comments/18v3n1f/im_super_pleased_with_myself_when_i_solve_a)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-12-31T08:49:16+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18v3n1f/im_super_pleased_with_myself_when_i_solve_a/"> <img alt="I'm super pleased with myself when I solve a practical problem for practically free" src="https://b.thumbs.redditmedia.com/_A1C-ME31NRsuOGuoIkZCVQ5zqTwisVyFxxzUGxIdbo.jpg" title="I'm super pleased with myself when I solve a practical problem for practically free" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>The ability to create your own customized, specific items is really the selling point of 3D design and printing for me.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/BPCustomCreations"> /u/BPCustomCreations </a> <br /> <span><a href="https://www.reddit.com/gallery/18v3n1f">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18v3n1f/im_super_pleased_with_myself_when_i_solve_a/">[comments]</a></span> </td></tr></table>

## Cheapest Filament dryer
 - [https://www.reddit.com/r/3Dprinting/comments/18v31tx/cheapest_filament_dryer](https://www.reddit.com/r/3Dprinting/comments/18v31tx/cheapest_filament_dryer)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-12-31T08:09:23+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18v31tx/cheapest_filament_dryer/"> <img alt="Cheapest Filament dryer" src="https://preview.redd.it/1hs49rt29l9c1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=1741cd8a6bdd0d2bc59772152863315c83e58ff9" title="Cheapest Filament dryer" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Today I just discovered the ENORMOUS effect of drying filaments. The Quality improvement a lot.</p> <p>But I didn’t want to purchase expensive dryers or have plastics backing in my kitchen oven (a big no no as a hobby cook).</p> <p>My concept: just store the filament on the heating. It never gets to hot, is absolutely free (I heat anyway) and works great, even for multiple spools.</p> <p>Hope this helps other diy enthusiasts :D</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Dr7House"> /u/Dr7House </a> <br /> <span><a href="https://i.redd.it/1hs49rt29l9c1.jpeg">[link]</a></span> &#32; <span><

## New Dock For Alexa Echo Dot 4/5 Gen
 - [https://www.reddit.com/r/3Dprinting/comments/18v2rh3/new_dock_for_alexa_echo_dot_45_gen](https://www.reddit.com/r/3Dprinting/comments/18v2rh3/new_dock_for_alexa_echo_dot_45_gen)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-12-31T07:50:11+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18v2rh3/new_dock_for_alexa_echo_dot_45_gen/"> <img alt="New Dock For Alexa Echo Dot 4/5 Gen" src="https://external-preview.redd.it/OXFuZHRiaG41bDljMba69Io_N-KMOxEC8fs_iY5n1Sz1NSlvsRjNmvEE0A9E.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=c2160985d702410aeb3fff74ffbea69f8ce66dc7" title="New Dock For Alexa Echo Dot 4/5 Gen" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Deep_Concentrate_616"> /u/Deep_Concentrate_616 </a> <br /> <span><a href="https://v.redd.it/etcc2rkn5l9c1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18v2rh3/new_dock_for_alexa_echo_dot_45_gen/">[comments]</a></span> </td></tr></table>

## 50 hours of printing, 4 hours of gluing
 - [https://www.reddit.com/r/3Dprinting/comments/18v0h29/50_hours_of_printing_4_hours_of_gluing](https://www.reddit.com/r/3Dprinting/comments/18v0h29/50_hours_of_printing_4_hours_of_gluing)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-12-31T05:32:06+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18v0h29/50_hours_of_printing_4_hours_of_gluing/"> <img alt="50 hours of printing, 4 hours of gluing" src="https://b.thumbs.redditmedia.com/wuJRF1fN237CY54aXKG-1jjxIQduzRUwAzr6MBFUDDE.jpg" title="50 hours of printing, 4 hours of gluing" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Bambu X1C/AMS 113 parts 6 colors 50 hours of printing (zero failures) 3 hours of gluing. Model created by Bambulab</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/DarkHeliopause"> /u/DarkHeliopause </a> <br /> <span><a href="https://www.reddit.com/gallery/18v0h29">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18v0h29/50_hours_of_printing_4_hours_of_gluing/">[comments]</a></span> </td></tr></table>

## Architectural model
 - [https://www.reddit.com/r/3Dprinting/comments/18uzqx2/architectural_model](https://www.reddit.com/r/3Dprinting/comments/18uzqx2/architectural_model)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-12-31T04:52:45+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18uzqx2/architectural_model/"> <img alt="Architectural model" src="https://b.thumbs.redditmedia.com/mtIUOlmxRQaI708brKzV38W868WfDL6xSf2KCWVV8pg.jpg" title="Architectural model" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Recently got a p1p, this is my first project using it. It’s a scaled down version of my neighbours house. Printed 15 different parts. All PLA. Cad work was done in fusion 360 and auto desk.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Blackhawk_Larry69"> /u/Blackhawk_Larry69 </a> <br /> <span><a href="https://www.reddit.com/gallery/18uzqx2">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18uzqx2/architectural_model/">[comments]</a></span> </td></tr></table>

## Alright I reprinted it, is this better?
 - [https://www.reddit.com/r/3Dprinting/comments/18uyqqi/alright_i_reprinted_it_is_this_better](https://www.reddit.com/r/3Dprinting/comments/18uyqqi/alright_i_reprinted_it_is_this_better)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-12-31T03:58:53+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18uyqqi/alright_i_reprinted_it_is_this_better/"> <img alt="Alright I reprinted it, is this better?" src="https://preview.redd.it/9irx4t1e0k9c1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=0fec511cebb1da0eda082349ed82f3037aca0f6a" title="Alright I reprinted it, is this better?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/WoooshToTheMax"> /u/WoooshToTheMax </a> <br /> <span><a href="https://i.redd.it/9irx4t1e0k9c1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18uyqqi/alright_i_reprinted_it_is_this_better/">[comments]</a></span> </td></tr></table>

## I design and print microscale metamaterials - These structures are about as large as the thickness of a single stand of hair!
 - [https://www.reddit.com/r/3Dprinting/comments/18uy92c/i_design_and_print_microscale_metamaterials_these](https://www.reddit.com/r/3Dprinting/comments/18uy92c/i_design_and_print_microscale_metamaterials_these)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-12-31T03:32:58+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18uy92c/i_design_and_print_microscale_metamaterials_these/"> <img alt="I design and print microscale metamaterials - These structures are about as large as the thickness of a single stand of hair!" src="https://preview.redd.it/0l2yxx6bvj9c1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=09c1cd07f81139117454c8200f861a12e88070e2" title="I design and print microscale metamaterials - These structures are about as large as the thickness of a single stand of hair!" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Herbologisty"> /u/Herbologisty </a> <br /> <span><a href="https://i.redd.it/0l2yxx6bvj9c1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18uy92c/i_design_and_print_microscale_metamaterials_these/">[comments]</a></span> </td></tr></table>

## Having so much better luck with ABS than PLA or PETG
 - [https://www.reddit.com/r/3Dprinting/comments/18uxx5v/having_so_much_better_luck_with_abs_than_pla_or](https://www.reddit.com/r/3Dprinting/comments/18uxx5v/having_so_much_better_luck_with_abs_than_pla_or)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-12-31T03:15:58+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18uxx5v/having_so_much_better_luck_with_abs_than_pla_or/"> <img alt="Having so much better luck with ABS than PLA or PETG" src="https://external-preview.redd.it/ZzhhOHBhbHBzajljMebuWoYs6gWnsuZ31PlkxIfOP66kuiH2hVFkBl0SidD4.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=f47c91c1af5cfe419dfecaf15bb56560ce8fb083" title="Having so much better luck with ABS than PLA or PETG" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I have hardly ever had prints come out this clean! Loving ABS right now. Not even using an enclosure, just using a draft shield. I'm slowly getting the courage for larger and larger prints to see where I need to actually get one for it to succeed.</p> <p>This printer is in what is effectively a basement, hardly ever go down there, and the central heat and air vent is shut, so no drafts. </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/davidvoigt96"> /u/david

## Brother in law surprised me for Christmas
 - [https://www.reddit.com/r/3Dprinting/comments/18uwfl0/brother_in_law_surprised_me_for_christmas](https://www.reddit.com/r/3Dprinting/comments/18uwfl0/brother_in_law_surprised_me_for_christmas)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-12-31T02:02:05+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18uwfl0/brother_in_law_surprised_me_for_christmas/"> <img alt="Brother in law surprised me for Christmas" src="https://b.thumbs.redditmedia.com/M6tyx9qklWf9g_tue5Uy2IGprgzJxgvURJkE-HwUv7I.jpg" title="Brother in law surprised me for Christmas" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>He called me months ago asking what printer he should get and which would be like the best one and I was like, oh if I were to get a printer (I have on recurrently a Elegoo Neptune 4 Pro, which I adore) I told him a P1S with an AMS would be perfect but that it was rather pricey. He goes oh okay well thanks for the info. Fast forward to today, totally forgot about that conversation and we did a late Christmas gift exchanged and brought out this honker. Still at a loss right now.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/BreakfastPikachu"> /u/BreakfastPikachu </a> <br /> <span><a hr

## My buddy sent me this, he's had a good holiday printing season.
 - [https://www.reddit.com/r/3Dprinting/comments/18uw9iu/my_buddy_sent_me_this_hes_had_a_good_holiday](https://www.reddit.com/r/3Dprinting/comments/18uw9iu/my_buddy_sent_me_this_hes_had_a_good_holiday)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-12-31T01:54:06+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Ghostx416"> /u/Ghostx416 </a> <br /> <span><a href="https://v.redd.it/1ehd0el4ej9c1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18uw9iu/my_buddy_sent_me_this_hes_had_a_good_holiday/">[comments]</a></span>

## Just finished my largest 3D print ever. 3 days and 2 1/2 hours…
 - [https://www.reddit.com/r/3Dprinting/comments/18uvsvr/just_finished_my_largest_3d_print_ever_3_days_and](https://www.reddit.com/r/3Dprinting/comments/18uvsvr/just_finished_my_largest_3d_print_ever_3_days_and)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-12-31T01:32:08+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18uvsvr/just_finished_my_largest_3d_print_ever_3_days_and/"> <img alt="Just finished my largest 3D print ever. 3 days and 2 1/2 hours…" src="https://preview.redd.it/s1p6t9g7aj9c1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=ae3aaab931afbda9926e85a7b4d9a1b325824b3a" title="Just finished my largest 3D print ever. 3 days and 2 1/2 hours…" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Printed with Eryone gold and silver dual colour PLA on my Ender 3 Pro with a Z height upgrade and a Sprite Extruder Pro</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/definitynotluke"> /u/definitynotluke </a> <br /> <span><a href="https://i.redd.it/s1p6t9g7aj9c1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18uvsvr/just_finished_my_largest_3d_print_ever_3_days_and/">[comments]</a></span> </td></tr></table>

## Tried a new finish on my print.
 - [https://www.reddit.com/r/3Dprinting/comments/18uv1mk/tried_a_new_finish_on_my_print](https://www.reddit.com/r/3Dprinting/comments/18uv1mk/tried_a_new_finish_on_my_print)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2023-12-31T00:57:19+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18uv1mk/tried_a_new_finish_on_my_print/"> <img alt="Tried a new finish on my print. " src="https://external-preview.redd.it/ODJ4dHYwdnozajljMSf6ewSUPnf6yd0borSkW3MG4-0NVnw52fyLmNgaksRC.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=e9c465083cb6035ff945db21e1fcf5fb5377edab" title="Tried a new finish on my print. " /> </a> </td><td> <!-- SC_OFF --><div class="md"><ul> <li>Matte PLA</li> <li>0.18 mm layer height</li> <li>20-30 min. of gradual sanding (wet sanding) </li> <li>2 coats of Beeswax Paste as a finish. </li> </ul> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Azazel_Tsubuzaki"> /u/Azazel_Tsubuzaki </a> <br /> <span><a href="https://v.redd.it/4ftfopwz3j9c1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18uv1mk/tried_a_new_finish_on_my_print/">[comments]</a></span> </td></tr></table>

