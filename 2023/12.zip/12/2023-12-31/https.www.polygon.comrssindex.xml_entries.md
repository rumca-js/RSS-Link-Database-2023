# Source:Polygon -  All, URL:https://www.polygon.com/rss/index.xml, language:en

## The year I read 20 Hercule Poirot mysteries and fell for Agatha Christie
 - [https://www.polygon.com/24009421/agatha-christie-hercule-poirot-mystery-books](https://www.polygon.com/24009421/agatha-christie-hercule-poirot-mystery-books)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-12-31T18:00:00+00:00

<figure>
      <img alt="A black-and-white image of Agatha Christie sitting at her desk. Huge stacks of books sit on either side of her." src="https://cdn.vox-cdn.com/thumbor/TPOUVJQWLzXJFRz5nCxaRLO5tMQ=/0x1230:4105x3539/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/73012329/1450652626.0.jpg" />
        <figcaption>Photo: Daily Mirror/Mirrorpix via Getty Images</figcaption>
    </figure>


  		<p>The man, the myth, the mustaches</p>
  <p>
    <a href="https://www.polygon.com/24009421/agatha-christie-hercule-poirot-mystery-books">Continue reading&hellip;</a>
  </p>

## The Legend of Zelda games, ranked
 - [https://www.polygon.com/zelda/24012081/best-zelda-games-ranked](https://www.polygon.com/zelda/24012081/best-zelda-games-ranked)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2023-12-31T14:00:00+00:00

<figure>
      <img alt="Link stands on a rock and surveys the sunrise over Hyrule in Zelda: Breath of the Wild" src="https://cdn.vox-cdn.com/thumbor/tJmgKJgiw2YhHAXmAKZ_hiZSSfM=/0x231:4500x2762/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/73011710/NintendoSwitch_TLOZBreathoftheWild_artwork_illustration_01.0.jpg" />
        <figcaption>Image: Nintendo</figcaption>
    </figure>


  		<p>In a series that’s (almost) all classics, which of Link’s adventures is best?</p>
  <p>
    <a href="https://www.polygon.com/zelda/24012081/best-zelda-games-ranked">Continue reading&hellip;</a>
  </p>

