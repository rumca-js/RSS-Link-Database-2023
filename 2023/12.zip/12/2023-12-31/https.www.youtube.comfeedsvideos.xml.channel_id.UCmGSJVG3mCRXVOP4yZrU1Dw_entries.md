# Source:John Harris, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCmGSJVG3mCRXVOP4yZrU1Dw, language:en-US

## Our 2023, Wrapped.
 - [https://www.youtube.com/watch?v=n959EFX1nnY](https://www.youtube.com/watch?v=n959EFX1nnY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmGSJVG3mCRXVOP4yZrU1Dw
 - date published: 2023-12-31T13:00:36+00:00

Hi friends, thank you for being here - see you in 2024.

Head over to Patreon to support our independent journalism and get access to our BTS videos: https://patreon.com/johnnyharris

Check out and subscribe to Search Party: https://www.youtube.com/@search-party

Use our music for free in your videos (*see terms): https://on.soundcloud.com/4AamY

