# Source:Politico, URL:https://rss.politico.com/politics-news.xml, language:en-US

## A crazy ride through 2023 on the Cartoon Carousel
 - [https://www.politico.com/cartoons/2023/12/31/cartoon-carousel-rewind-00133317](https://www.politico.com/cartoons/2023/12/31/cartoon-carousel-rewind-00133317)
 - RSS feed: https://rss.politico.com/politics-news.xml
 - date published: 2023-12-31T07:00:00+00:00

2023, it was one crazy year. A Chinese spy balloon flies across the country ... pretty crazy. Kevin McCarthy dousing his speakership with gasoline and handing the Gaetz Gang the matches … certifiably crazy. Canadian wildfires blacking out the sky in New York and Washington ... climatically crazy. Donald Trump getting indicted on 91 counts and using it to increase his standing in the polls (and raise yet more millions of dollars) … confoundingly crazy. Hamas attacking Israel and the devastating war that's followed … horrifyingly crazy. Elon Musk’s unhinged trolling on X… kookily crazy. ChatGPT giving us a glimpse of AI taking over the world … unsettling crazy, and that’s just the half of it. Over the past 12 months, cartoonists captured all the crazy in our weekly Cartoon Carousel. We picked out some of the best, mindful to include viewpoints from across the political spectrum. Some will make you laugh, some will make you groan … and some will make you ... crazy! 2023 has been that ki

