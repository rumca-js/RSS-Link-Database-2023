# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## Księga Ezechiela || Rozdział 38
 - [https://www.youtube.com/watch?v=pz8V6n9iFU0](https://www.youtube.com/watch?v=pz8V6n9iFU0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2023-12-31T23:00:36+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.

________________________________________
Audiobooka znajdziecie tu ♡
➡  https://bit.ly/nowennapompejanska
Dostępny także w zestawie z Audiobookiem "Jak się modlić"
➡ https://bit.ly/nowennaijaksięmodlic
________________________________________
Książkę "Jak się modlić?" znajdziecie tu:
→ https://langustanapalmie.pl/produkt/jaksiemodlic/

Książka jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Spreake

## Zasypiaki || 31.12.2023 Niedziela
 - [https://www.youtube.com/watch?v=9RdtxwRhx3k](https://www.youtube.com/watch?v=9RdtxwRhx3k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2023-12-31T19:00:05+00:00

Czy szukasz czegoś więcej niż zwykłej kołysanki na dobranoc? Oto "Zasypiaki" - wieczorne Langustowe spotkania z Bogiem. 🌙🙏

Bez względu na to, czy jesteś na początku swojej podróży, czy jesteś już w przyjaźni z Nim, znajdziesz tu coś dla siebie. 🛤️💖 To więcej niż podcast, to społeczność ludzi, którzy, podobnie jak Ty, szukają prawdziwych odpowiedzi. 🎧💭

Działaj! 🚀 Dołącz do nas na "Zasypiakach" i daj szansę Bogu i sobie. Czekamy na Ciebie codziennie o 20:00. ⏰🌟

🔥 Działaj z nami! ☞
→ https://niezlafundacja.pl/#darowizna
→ https://langustanapalmie.pl/przekaz-darowizne/
→ https://patronite.pl/langustanapalmie

#Zasypiaki #Podcast #AdamSzustak #NocneSpotkania 💫🌌

 @Langustanapalmie  
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQZv
Google Pod

## Dobranocka [#267] Poprawka
 - [https://www.youtube.com/watch?v=j34o1vECU5Q](https://www.youtube.com/watch?v=j34o1vECU5Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2023-12-31T18:00:20+00:00

@Langustanapalmie       #dobranocka 

Bajka na dobranoc dla tych starszych dzieci. 
Opowiada ojciec Adam Szustak OP.

zdjęcia i montaż: Łukasz Głąb
Produkcja Serii: Sylwia Smoczyńska || Kamil Siciak

Muzyka:
Kai Engel: Brooks, z albumu Chapter Two: Mild – na licencji Creative Commons Attribution (https://creativecommons.org/licenses/...)
Źródło: http://freemusicarchive.org/music/Kai...
Wykonawca: http://www.kai-engel.com/

________________________________________
Audiobooka znajdziecie tu ♡
➡  https://bit.ly/nowennapompejańska
Dostępny także w zestawie z Audiobookiem "Jak się modlić"
➡ https://bit.ly/nowennaijaksięmodlić
________________________________________
Książkę "Jak się modlić?" znajdziecie tu:
→ https://langustanapalmie.pl/produkt/jaksiemodlic/

Książka jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.

## Nowenna do Matki Bożej rozwiązującej węzły
 - [https://www.youtube.com/watch?v=C2uICrmNAus](https://www.youtube.com/watch?v=C2uICrmNAus)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2023-12-31T15:00:15+00:00

🙏 Jak dobrze rozpocząć rok 2024?! Wiadomo – z Maryją! 
Przez kolejnych dziewięć dni będziemy wspólnie odmawiać Nowennę do Matki Bożej Rozwiązującej Węzły. 
Chcemy przez ręce Mamy oddać to co dla nas trudne i nierozwiązywalne, a Ona pomoże Nam – wiadomo!
🌸 Dzień po dniu będziemy oddawać w JEJ ręce różne "węzły" naszego życia. 

 @Langustanapalmie   #NowennaDoMatkiBożej#adamszustak #RozwiązującaWęzły #zasypiaki 
________________________________________
PORADNIK ANTYZWIĄZKOWY
→ https://langustanapalmie.pl/produkt/poradnik-antyzwiazkowy/
________________________________________
Książkę "Jak się modlić?" znajdziecie tu:
→ https://langustanapalmie.pl/produkt/jaksiemodlic/

Książka jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.
________________________________________
Audiobooka znajdziecie tu ♡
➡  https://bit.ly/nowennapompejańska
Dostępny także w zestawie z Audiobookiem "Jak się modlić"
➡ https://bit.l

