# Source:RT - Daily news, URL:https://www.rt.com/rss/, language:en

## Trump warns of new ‘Great Depression’
 - [https://www.rt.com/news/589989-trump-predicts-stock-market-depression/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/589989-trump-predicts-stock-market-depression/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-31T23:27:47+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6591ea052030274a2b073bb3.jpeg" style="margin-right: 10px;" /> The US will suffer the worst stock market crash in history if Joe Biden remains president, his chief rival Donald Trump said <br /><a href="https://www.rt.com/news/589989-trump-predicts-stock-market-depression/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Zelensky personally ordered bombing attack on civilians – RT source
 - [https://www.rt.com/russia/589987-zelensky-order-belgorod-attack-civilians/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/589987-zelensky-order-belgorod-attack-civilians/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-31T21:45:56+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6591e09f85f5400497451046.jpg" style="margin-right: 10px;" /> The Belgorod strike has been ordered by Ukrainian President Vladimir Zelensky and launched by a nationalist force, a source has told RT <br /><a href="https://www.rt.com/russia/589987-zelensky-order-belgorod-attack-civilians/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Ukraine fires ‘massive barrage’ at Donetsk – officials
 - [https://www.rt.com/russia/589988-ukraine-shells-donetsk-2024/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/589988-ukraine-shells-donetsk-2024/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-31T21:42:19+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/static.en/thumbnail/breaking.jpg" style="margin-right: 10px;" /> Ukrainian forces shelled the Russian city of Donetsk on Monday, local authorities said <br /><a href="https://www.rt.com/russia/589988-ukraine-shells-donetsk-2024/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## LISTEN: Putin New Year’s address – in English
 - [https://www.rt.com/russia/589982-putin-new-year-address-english/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/589982-putin-new-year-address-english/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-31T20:56:03+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6591ae5985f5407d7011ac06.jpg" style="margin-right: 10px;" /> Russian President Vladimir Putin’s annual New Year’s address is to be broadcast by RT in English with his real voice processed by AI <br /><a href="https://www.rt.com/russia/589982-putin-new-year-address-english/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Most Brits regret Brexit – poll
 - [https://www.rt.com/news/589986-british-regret-brexit-poll-economy/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/589986-british-regret-brexit-poll-economy/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-31T20:38:57+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6591d0ee203027462970ac86.jpeg" style="margin-right: 10px;" /> More than half of Britons polled held Brexit partially responsible for fueling inflation and the cost-of-living crisis <br /><a href="https://www.rt.com/news/589986-british-regret-brexit-poll-economy/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Neo-fascism must be destroyed in 2024 – Medvedev
 - [https://www.rt.com/russia/589985-neo-fascism-destroyed-2024-medvedev/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/589985-neo-fascism-destroyed-2024-medvedev/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-31T20:21:19+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6591cc912030273e9f598d27.jpg" style="margin-right: 10px;" /> Former Russian President Dmitry Medvedev has wished for 2024 to become the year when neo-fascism is dealt an “ultimate defeat” <br /><a href="https://www.rt.com/russia/589985-neo-fascism-destroyed-2024-medvedev/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Putin praises ‘hero soldiers’ in New Year’s address
 - [https://www.rt.com/russia/589983-putin-hero-soldiers-new-year/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/589983-putin-hero-soldiers-new-year/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-31T19:56:21+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6591b82e85f54067630ab31b.jpg" style="margin-right: 10px;" /> Russian President Vladimir Putin has hailed the nation’s military fighting on the frontlines and assured them of universal public support <br /><a href="https://www.rt.com/russia/589983-putin-hero-soldiers-new-year/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## NATO state warns of unnamed anti-Semitic threat
 - [https://www.rt.com/news/589984-norway-police-antisemitic-threat/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/589984-norway-police-antisemitic-threat/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-31T19:50:31+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6591c45785f540084f0d06bb.jpg" style="margin-right: 10px;" /> Norway will arm its police officers in response to unnamed threats to “Jewish and Israeli targets” <br /><a href="https://www.rt.com/news/589984-norway-police-antisemitic-threat/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## UK preparing to attack Houthis – The Times
 - [https://www.rt.com/news/589981-uk-us-attack-houthis/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/589981-uk-us-attack-houthis/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-31T17:37:45+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6591a6a885f5407b33109514.jpg" style="margin-right: 10px;" /> The UK is reportedly gearing up to launch airstrikes against Yemen’s Houthi militants in response to attacks on commercial shipping <br /><a href="https://www.rt.com/news/589981-uk-us-attack-houthis/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Iconic journalist John Pilger dies
 - [https://www.rt.com/news/589980-john-pilger-dead-rattansi/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/589980-john-pilger-dead-rattansi/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-31T16:08:40+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6591917b203027390203d22e.jpeg" style="margin-right: 10px;" /> Australian-born investigative journalist and filmmaker John Pilger has died at the age of 84 <br /><a href="https://www.rt.com/news/589980-john-pilger-dead-rattansi/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Biden on Putin’s ‘naughty list’ for second consecutive year
 - [https://www.rt.com/news/589977-biden-putins-naughty-list/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/589977-biden-putins-naughty-list/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-31T15:47:47+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6591747f85f5404b2b6513a9.jpg" style="margin-right: 10px;" /> Vladimir Putin has not wished a Happy New Year to most Western leaders, including Joe Biden, amid the Ukraine conflict <br /><a href="https://www.rt.com/news/589977-biden-putins-naughty-list/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russian cities cancel New Year’s festivities in solidarity with Belgorod
 - [https://www.rt.com/russia/589979-new-year-festivities-solidarity-belgorod/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/589979-new-year-festivities-solidarity-belgorod/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-31T15:45:15+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/65918bc020302741ba206eeb.jpg" style="margin-right: 10px;" /> Cities across Russia have called off New Year’s celebrations to support Belgorod, where more than 20 people died in a Ukrainian strike <br /><a href="https://www.rt.com/russia/589979-new-year-festivities-solidarity-belgorod/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Reunification with Taiwan is ‘inevitable’ – Xi
 - [https://www.rt.com/news/589978-china-xi-taiwan-reuinfication/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/589978-china-xi-taiwan-reuinfication/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-31T15:40:19+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6591864a2030273e5267cabf.jpg" style="margin-right: 10px;" /> Chinese President Xi Jinping has called the reunification of Taiwan and the Chinese mainland a “historical inevitability” <br /><a href="https://www.rt.com/news/589978-china-xi-taiwan-reuinfication/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## USA Boxing to allow transgender people to fight women
 - [https://www.rt.com/news/589975-usa-boxing-transgender-women/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/589975-usa-boxing-transgender-women/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-31T14:19:22+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/65916de42030274a2b073ba1.jpg" style="margin-right: 10px;" /> USA Boxing will allow transgender women to fight against biological women once they’ve had hormone therapy and surgery <br /><a href="https://www.rt.com/news/589975-usa-boxing-transgender-women/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russia’s gas production soars – data
 - [https://www.rt.com/business/589806-russia-gas-production-growth/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/589806-russia-gas-production-growth/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-31T14:04:46+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/658d81b385f54038096e8f19.jpg" style="margin-right: 10px;" /> Russia produced nearly 60 billion cubic meters of gas in November in annual terms, Kommersant reports <br /><a href="https://www.rt.com/business/589806-russia-gas-production-growth/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Korean unification ‘impossible’ – Kim
 - [https://www.rt.com/news/589971-kim-korea-unification-impossible/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/589971-kim-korea-unification-impossible/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-31T13:36:36+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/659163f285f54039ca5f7e7d.jpg" style="margin-right: 10px;" /> Kim Jong-un rules out reunification between North and South Korea, saying relations are no longer “consanguineous” <br /><a href="https://www.rt.com/news/589971-kim-korea-unification-impossible/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Gold to hit new highs next year – Reuters
 - [https://www.rt.com/business/589974-gold-prices-new-highs/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/589974-gold-prices-new-highs/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-31T13:30:08+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/65916cb385f540696551b18f.jpg" style="margin-right: 10px;" /> Global economic uncertainty is likely to push gold prices higher in 2024, Reuters reports, citing analysts <br /><a href="https://www.rt.com/business/589974-gold-prices-new-highs/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Ukrainian men finding it harder to leave country – media
 - [https://www.rt.com/russia/589972-ukraine-men-harder-leave-recruitment/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/589972-ukraine-men-harder-leave-recruitment/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-31T13:21:59+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/659168f8203027531a48dfa0.jpg" style="margin-right: 10px;" /> Ukrainian border guards are preventing from leaving the country even those men who are allowed to do so, local media have reported <br /><a href="https://www.rt.com/russia/589972-ukraine-men-harder-leave-recruitment/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Iran and Russia officially ditch dollar – media
 - [https://www.rt.com/business/589836-iran-russia-ditch-dollar/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/589836-iran-russia-ditch-dollar/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-31T12:59:10+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/658da73c2030274f97359e49.jpg" style="margin-right: 10px;" /> Moscow and Tehran have agreed to trade in rials and rubles instead of the dollar, and to use alternative platforms to the West’s SWIFT <br /><a href="https://www.rt.com/business/589836-iran-russia-ditch-dollar/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## US wary of completely ruining relations with Russia – Lavrov
 - [https://www.rt.com/russia/589970-us-relations-russia-lavrov/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/589970-us-relations-russia-lavrov/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-31T12:58:47+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6591617485f5402fdc34ec46.jpg" style="margin-right: 10px;" /> Washington is wary of cutting off relations with Moscow completely, Russian Foreign Minister Sergey Lavrov has said <br /><a href="https://www.rt.com/russia/589970-us-relations-russia-lavrov/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Modi ends 2023 with $2bn infra push in sacred town
 - [https://www.rt.com/india/589969-modi-ends-2023-ayodhya/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/india/589969-modi-ends-2023-ayodhya/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-31T12:39:20+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/65915fdb85f5405ea46071ed.jpg" style="margin-right: 10px;" /> The prime minister unveiled dozens of projects in Ayodhya, the site of the Ram temple which is due to be consecrated on January 22 <br /><a href="https://www.rt.com/india/589969-modi-ends-2023-ayodhya/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russia’s forex reserves surging
 - [https://www.rt.com/business/589827-russia-forex-reserves-growth/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/589827-russia-forex-reserves-growth/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-31T11:52:03+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/658d936920302730d6587ee5.jpg" style="margin-right: 10px;" /> Moscow has already earned double the amount of gold and foreign exchange reserves frozen by the West <br /><a href="https://www.rt.com/business/589827-russia-forex-reserves-growth/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## McDonald’s franchise sues Israel boycott movement – Reuters
 - [https://www.rt.com/business/589964-mcdonalds-sues-israel-boycott-movement/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/589964-mcdonalds-sues-israel-boycott-movement/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-31T10:45:56+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/65914578203027390203d21a.jpg" style="margin-right: 10px;" /> McDonald’s Malaysia is seeking damages from a movement that called for a boycott of the chain on social media, Reuters reports <br /><a href="https://www.rt.com/business/589964-mcdonalds-sues-israel-boycott-movement/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Egypt-Russia trade soaring – official
 - [https://www.rt.com/business/589959-egypt-russia-trade-soaring/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/589959-egypt-russia-trade-soaring/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-31T09:32:18+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/65911e9820302756ce47740c.jpg" style="margin-right: 10px;" /> The turnover of goods between Russia and Egypt has risen by around one-fourth this year, trade representative Aleksey Tevanyan says <br /><a href="https://www.rt.com/business/589959-egypt-russia-trade-soaring/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russia explains retaliation for Ukrainian 'terror attack'
 - [https://www.rt.com/russia/589963-moscow-retaliates-ukrainian-terrorist-attack/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/589963-moscow-retaliates-ukrainian-terrorist-attack/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-31T09:24:12+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6591390285f5402bc637db20.jpg" style="margin-right: 10px;" /> Moscow has conducted high-precision strikes on Ukrainian military facilities in response to Kiev’s deadly attack on Belgorod <br /><a href="https://www.rt.com/russia/589963-moscow-retaliates-ukrainian-terrorist-attack/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Deeper than diplomacy: There is a reason why New Delhi and Moscow rely on each other
 - [https://www.rt.com/india/589923-russia-india-ties-jaishankar/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/india/589923-russia-india-ties-jaishankar/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-31T08:46:06+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/658fb90185f5404b2b65133d.jpg" style="margin-right: 10px;" /> Russia’s respect for India’s policy of strategic autonomy is the core strength of bilateral ties <br /><a href="https://www.rt.com/india/589923-russia-india-ties-jaishankar/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russian factory activity humming – survey
 - [https://www.rt.com/business/589905-russia-factory-activity-soaring/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/589905-russia-factory-activity-soaring/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-31T08:17:11+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/658eeefc85f54038096e8f8e.jpg" style="margin-right: 10px;" /> Russia’s manufacturing activity in December grew at its fastest pace since 2017, driven by strong demand and increased output, S&amp;P says <br /><a href="https://www.rt.com/business/589905-russia-factory-activity-soaring/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Alarm sirens sound in Russian border city day after deadly Ukrainian attack
 - [https://www.rt.com/russia/589962-alarm-sirens-sounding-belgorod/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/589962-alarm-sirens-sounding-belgorod/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-31T08:01:38+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6591271820302751db351b0e.jpg" style="margin-right: 10px;" /> A new alert has been declared in Belgorod following a deadly Ukrainian missile attack <br /><a href="https://www.rt.com/russia/589962-alarm-sirens-sounding-belgorod/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Houthi missile hits containership in Red Sea – Pentagon
 - [https://www.rt.com/news/589961-houthi-red-sea-attack-maersk/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/589961-houthi-red-sea-attack-maersk/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-31T07:51:06+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/65911cfb2030274c4a1cdcaa.jpg" style="margin-right: 10px;" /> Yemen’s Houthi rebels struck a cargo ship in the Southern Red Sea with a missile, the US military has said <br /><a href="https://www.rt.com/news/589961-houthi-red-sea-attack-maersk/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Kiev seeking to kill ‘as many Russians as possible’ – Moscow
 - [https://www.rt.com/russia/589960-kiev-seeks-kill-russians/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/589960-kiev-seeks-kill-russians/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-31T07:30:35+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6591168485f54033be485122.jpg" style="margin-right: 10px;" /> Ukraine’s attack on Belgorod shows that it seeks to kill as many Russians as possible to please its Western masters, Moscow has said <br /><a href="https://www.rt.com/russia/589960-kiev-seeks-kill-russians/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Share of dollar in global reserves nosedives – IMF
 - [https://www.rt.com/business/589896-us-dollar-losing-dominance-imf/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/589896-us-dollar-losing-dominance-imf/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-31T05:21:24+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/658ef4f2203027142934e8cc.jpg" style="margin-right: 10px;" /> De-dollarization is gaining momentum across the globe, according to International Monetary Fund data for 2023 <br /><a href="https://www.rt.com/business/589896-us-dollar-losing-dominance-imf/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Israel must have full control over Gaza-Egypt border – Netanyahu
 - [https://www.rt.com/news/589957-israel-seeks-control-over-gaza-border/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/589957-israel-seeks-control-over-gaza-border/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-31T04:53:12+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6590f35e2030274f606bc042.jpg" style="margin-right: 10px;" /> The Israeli prime minister says the Egypt-Gaza border must be controlled by the IDF in order to prevent further Hamas incursions <br /><a href="https://www.rt.com/news/589957-israel-seeks-control-over-gaza-border/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## NATO state too ‘scared’ to attend UN meeting – Russian diplomat
 - [https://www.rt.com/russia/589956-czech-cowardice-un-security/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/589956-czech-cowardice-un-security/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-31T02:36:15+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6590d5f085f54047f11c0242.jpg" style="margin-right: 10px;" /> The Czech Republic was too cowardly to attend the UN Security Council meeting on Saturday, a senior Russian diplomat has said <br /><a href="https://www.rt.com/russia/589956-czech-cowardice-un-security/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Will 2023 be known as the last year of global US hegemony?
 - [https://www.rt.com/news/589933-2023-us-hegemony-last/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/589933-2023-us-hegemony-last/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-31T01:48:31+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6590c82485f540696551b16a.jpg" style="margin-right: 10px;" /> From Ukraine to Israel to China, the chaos of the past year saw the American hold on the reins of the world slip <br /><a href="https://www.rt.com/news/589933-2023-us-hegemony-last/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Ukrainian attack on Belgorod ‘unacceptable’ – UN
 - [https://www.rt.com/russia/589955-ukrainian-attack-on-belgorod-unacceptable/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/589955-ukrainian-attack-on-belgorod-unacceptable/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-12-31T00:13:44+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6590b0b185f54038604178c1.jpg" style="margin-right: 10px;" /> The UN has condemned Ukraine’s recent missile strikes against Belgorod, Russia <br /><a href="https://www.rt.com/russia/589955-ukrainian-attack-on-belgorod-unacceptable/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

