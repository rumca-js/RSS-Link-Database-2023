# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## "Reforma mediów publicznych tylko zgodnie z prawem". Orędzie noworoczne prezydenta Dudy
 - [https://www.bankier.pl/wiadomosc/Reforma-mediow-publicznych-tylko-zgodnie-z-prawem-Oredzie-noworoczne-prezydenta-Dudy-8671862.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Reforma-mediow-publicznych-tylko-zgodnie-z-prawem-Oredzie-noworoczne-prezydenta-Dudy-8671862.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-31T19:04:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/e/4a4f5199608fe2-948-567-0-0-1080-647.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rządzący mogą reformować media publiczne, ale musi się to odbywać zgodnie z prawem. Zawsze byłem i jestem na taką dyskusję dotyczącą zmian prawnych otwarty. Jednak z mojej strony nie będzie zgody na łamanie konstytucji - powiedział w niedzielnym orędziu noworocznym prezydent Andrzej Duda.</p>

## Abdykacja na jednym europejskim tronie.  "Czas ucieka, a choroby nasilają się"
 - [https://www.bankier.pl/wiadomosc/Krolowa-Malgorzata-II-abdykuje-Zmiana-na-tronie-w-Danii-8671853.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Krolowa-Malgorzata-II-abdykuje-Zmiana-na-tronie-w-Danii-8671853.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-31T17:49:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/a/977a79f8f521d9-948-568-0-0-4027-2416.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />83-letnia królowa Danii Małgorzata II nieoczekiwanie ogłosiła w niedzielę w swoim przemówieniu noworocznym abdykację z dniem 14 stycznia 2024 roku. Duński tron obejmie wówczas jej syn, 55-letni książę Fryderyk.</p>

## "Unowocześniony i zaangażowany"? Plany polityczne nowego MSZ
 - [https://www.bankier.pl/wiadomosc/Unowoczesniona-i-zaangazowania-Zalozenia-nowego-MSZ-8671748.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Unowoczesniona-i-zaangazowania-Zalozenia-nowego-MSZ-8671748.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-31T15:20:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/7/0331130f64deb8-948-568-15-66-2032-1219.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Szef komisji spraw zagranicznych Paweł Kowal chciałby, żeby komisja została unowocześniona i wzmacniała to, co nazywamy dyplomacją społeczną. Zapowiedział m.in. wciągnięcie do działań ws. międzynarodowych organizacji pozarządowych i działania na rzecz uwolnienia Andrzeja Poczobuta.</p>

## Holendrzy są niezadowoleni ze świątecznych prezentów od pracodawców. Sprzedają je w sieci
 - [https://www.bankier.pl/wiadomosc/Holendrzy-sa-niezadowoleni-ze-swiatecznych-prezentow-od-pracodawcow-Sprzedaja-je-w-sieci-8669899.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Holendrzy-sa-niezadowoleni-ze-swiatecznych-prezentow-od-pracodawcow-Sprzedaja-je-w-sieci-8669899.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-31T15:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/1/b19fa9fb5f33dc-948-568-0-432-2400-1439.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Holendrzy są niezadowoleni z tegorocznych prezentów świątecznych od swoich pracodawców i masowo sprzedają je na platformach internetowych - informuje dziennik „Algemeen Dagblad”.</p>

## Sylwester pod ochroną. Tysiące policjantów i jednostki antyterrorystyczne na Times Square
 - [https://www.bankier.pl/wiadomosc/Sylwester-pod-ochrona-Tysiace-policjantow-i-jednostki-antyterrorystyczne-na-Times-Square-8671707.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sylwester-pod-ochrona-Tysiace-policjantow-i-jednostki-antyterrorystyczne-na-Times-Square-8671707.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-31T15:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/b/b5e35c30da5180-933-560-65-2-933-560.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nowojorska policja przygotowuje się do zapewnienia bezpieczeństwa na Times Square podczas tradycyjnej uroczystości powitania Nowego Roku. Władze spodziewają się przybycia tam do miliona osób, których chronić mają funkcjonariusze wraz z jednostkami antyterrorystycznymi, a z powietrza helikoptery i drony.</p>

## Premier odradza, co nie należy robić w Sylwestra i udostępnia filmik
 - [https://www.bankier.pl/wiadomosc/Premier-odradza-co-nie-nalezy-robic-w-Sylwestra-i-udostepnil-filmik-8671833.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Premier-odradza-co-nie-nalezy-robic-w-Sylwestra-i-udostepnil-filmik-8671833.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-31T14:38:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/4/fe6c911428ac11-945-560-33-56-4466-2679.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />"Odpalać petardy przy tych, którzy się boją" - nagranie o takiej treści umieścił w niedzielę w mediach społecznościowych premier Donald Tusk.</p>

## Fort Zuckerberg. Założyciel Facebooka "kolonizuje" hawajską wyspę, za co zapłaci krocie
 - [https://www.bankier.pl/wiadomosc/Fort-Zuckerberg-Zalozyciel-Facebooka-kolonizuje-hawajska-wyspe-za-co-zaplaci-krocie-8667021.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Fort-Zuckerberg-Zalozyciel-Facebooka-kolonizuje-hawajska-wyspe-za-co-zaplaci-krocie-8667021.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-31T14:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/2/fba393b0ebdc95-948-567-0-0-950-569.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Pancerne drzwi, ogromny podziemny bunkier i 
wszechobecna ochrona - choć wygląda jak forteca arcywroga 007 (bo po 
sąsiedzku z agentem Pierce’em Brosnanem), to tylko hawajski "domek" 
Marka Zuckerberga położony na wyspie Kauai na północ od wyspy O'ahu z 
Honolulu. </p>

## Chiny zapinają pas i startują. Xi Jinping zapowiada głębsze reformy
 - [https://www.bankier.pl/wiadomosc/Chiny-zapinaja-pas-i-startuja-Xi-Jinping-zapowiada-glebsze-reformy-8671823.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Chiny-zapinaja-pas-i-startuja-Xi-Jinping-zapowiada-glebsze-reformy-8671823.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-31T13:39:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/d/b9bfa3d2155698-948-568-0-69-1626-975.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przywódca ChRL Xi Jinping zapowiedział w niedzielę, że Chiny skonsolidują i wzmocnią w 2024 roku pozytywny trend w gospodarce i utrzymają długoterminowy rozwój dzięki jeszcze głębszym reformom.</p>

## W tym roku wycofano rekordową liczbę artykułów naukowych. To wyniki "drapieżnego publikowania"
 - [https://www.bankier.pl/wiadomosc/W-tym-roku-wycofano-rekordowa-liczbe-artykulow-naukowych-To-wyniki-drapieznego-publikowania-8669718.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/W-tym-roku-wycofano-rekordowa-liczbe-artykulow-naukowych-To-wyniki-drapieznego-publikowania-8669718.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-31T13:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/a/c41858b4416262-948-568-0-49-2470-1481.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W tym roku wydawcy musieli wycofać rekordową liczbę 10 tys. artykułów naukowych ze względu na niską jakość lub podejrzenie, że są plagiatami - wynika z analizy dokonanej przez tygodnik naukowy „Nature”.</p>

## Zaufał GPS-owi i zapłaci 1 tys. zł mandatu. Kierowca wjechał do parku narodowego
 - [https://www.bankier.pl/wiadomosc/Zaufal-GPS-owi-i-zaplaci-1-tys-zl-mandatu-Kierowca-wjechal-do-parku-narodowego-8671811.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zaufal-GPS-owi-i-zaplaci-1-tys-zl-mandatu-Kierowca-wjechal-do-parku-narodowego-8671811.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-31T12:25:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/1/2cf005cef4afca-948-568-25-291-2022-1213.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Obywatel Niemiec chciał przejechać do Czech czarnym szlakiem z Jagniątkowa. Jest to nie tylko nielegalne, ale i niemożliwe, bo ten szlak u góry jest tylko ścieżką - poinformowali przedstawiciele Karkonoskiego Parku Narodowego. Teraz zapłaci tysiąc złotych mandatu.</p>

## ChatGPT czy deepfake. Sztuczna inteligencja zmieniła w 2023 roku muzykę, filmy i sztukę
 - [https://www.bankier.pl/wiadomosc/ChatGPT-czy-deepfake-Sztuczna-inteligencja-zmienila-w-2023-roku-muzyke-filmy-i-sztuke-8669120.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/ChatGPT-czy-deepfake-Sztuczna-inteligencja-zmienila-w-2023-roku-muzyke-filmy-i-sztuke-8669120.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-31T11:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/9/6fd5251269bb40-948-568-0-203-3878-2326.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sztuczna inteligencja (AI) zmieniła w 2023 roku muzykę, filmy i sztukę - ocenił amerykański tygodnik "Time". Kiedy pojawiły się narzędzia tworzące tekst i obraz, takie jak ChatGPT i Midjourney, hollywoodzcy twórcy zaczęli się martwić, że AI zabierze im pracę; po miesiącach negocjacji stowarzyszenia reprezentujące każdą z profesji opracowały jednak zabezpieczenia przed przyszłą wersją Hollywood, stworzoną głównie za pomocą AI - czytamy na łamach "Time'a".</p>

## Zatrudnienie cudzoziemców w Polsce będzie się zwiększać. I to nie tylko naszych sąsiadów
 - [https://www.bankier.pl/wiadomosc/Zatrudnienie-cudzoziemcow-w-Polsce-bedzie-sie-zwiekszac-I-to-nie-tylko-naszych-sasiadow-8670894.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zatrudnienie-cudzoziemcow-w-Polsce-bedzie-sie-zwiekszac-I-to-nie-tylko-naszych-sasiadow-8670894.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-31T11:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/4/ea3d0b0af8870c-948-568-84-23-2598-1559.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W Polsce jest coraz więcej emigrantów zarobkowych, w 2024 r. zatrudnienie cudzoziemców będzie się zwiększać.  W 2025 roku do Polski liczniej przybywać będą w Hindusi, Gruzini i Uzbecy - prognozuje agencja Gremi Personal w przekazanej PAP analizie.</p>

## Kim Dzong Un polecił armii przygotować się do ewentualnej wojny
 - [https://www.bankier.pl/wiadomosc/Kim-Dzong-Un-polecil-armii-przygotowac-sie-do-ewentualnej-wojny-8671773.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kim-Dzong-Un-polecil-armii-przygotowac-sie-do-ewentualnej-wojny-8671773.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-31T09:27:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/b/8272efa1ab7fe1-948-568-0-115-3534-2120.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przywódca Korei Północnej Kim Dzong Un ponownie zagroził atakiem nuklearnym na Seul i zlecił przyśpieszenie przygotowań wojskowych do „wojny”, która „może zostać wywołana w każdej chwili” na Półwyspie Koreańskim – podała w niedzielę państwowa agencja KCNA.</p>

## "Epidemia" donosicielstwa w Rosji. Sypią się kary za niebieskie i żółte kwiaty czy komplementowanie Zełenskiego
 - [https://www.bankier.pl/wiadomosc/Epidemia-donosicielstwa-w-Rosji-Sypia-sie-kary-za-niebieskie-i-zolte-kwiaty-czy-komplementowanie-Zelenskiego-8670200.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Epidemia-donosicielstwa-w-Rosji-Sypia-sie-kary-za-niebieskie-i-zolte-kwiaty-czy-komplementowanie-Zelenskiego-8670200.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-31T09:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/8/e924bcab08c0a9-948-568-0-288-4272-2563.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W wyniku wojny na Ukrainie i zachęt ze strony Putina 
Rosja przeżywa "epidemię" donosicielstwa - pisze "Wall Street Journal". 
Karane są osoby komplementujące wygląd prezydenta Ukrainy Wołodymyra 
Zełenskiego, noszące antywojenne przypinki czy słuchające we własnym 
mieszkaniu ukraińskiego hymnu.</p>

## 800+ nie wystarczy? System pomocy społecznej wymaga głębokich reform. Zapaść kadrowa na horyzoncie
 - [https://www.bankier.pl/wiadomosc/800-nie-wystarczy-System-pomocy-spolecznej-wymaga-glebokich-reform-Zapasc-kadrowa-na-horyzoncie-8667647.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/800-nie-wystarczy-System-pomocy-spolecznej-wymaga-glebokich-reform-Zapasc-kadrowa-na-horyzoncie-8667647.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-31T09:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/3/76a55a3f9f28cd-948-568-0-336-2988-1792.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ustawa regulująca system pomocy społecznej ma prawie 20 lat i nie przystaje już do aktualnych problemów i wyzwań - wskazują eksperci. Pomoc społeczna opiera się w dużej mierze na świadczeniach finansowych i pomija kwestie usług społecznych, a to na nich opierają się nowoczesne systemy. Poza tym z sektora odchodzi coraz więcej osób.</p>

## Polacy piją mniej alkoholu. Króluje prosecco
 - [https://www.bankier.pl/wiadomosc/Polacy-pija-mniej-alkoholu-Kroluje-prosecco-8671141.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polacy-pija-mniej-alkoholu-Kroluje-prosecco-8671141.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-31T09:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/8/e355fb5ddbb2be-948-568-0-0-1584-950.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Polacy rezygnują z mocnych alkoholi, decydując się na napoje lżejsze lub pozbawione procentów – wynika z danych Nielsen IQ. Jednym z powodów jest inflacja.</p>

## Paradoks litu, czyli ciemna strona transformacji energetycznej
 - [https://www.bankier.pl/wiadomosc/Paradoks-litu-czyli-ciemna-strona-transformacji-energetycznej-8671770.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Paradoks-litu-czyli-ciemna-strona-transformacji-energetycznej-8671770.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-31T08:40:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/b/bcf72558a8b11f-948-567-0-80-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Plany cięcia emisji gazów cieplarnianych windują zapotrzebowanie na lit - kluczowy składnik baterii w telefonach komórkowych, pojazdach elektrycznych i magazynach energii ze źródeł odnawialnych. Wydobycie tego metalu, zwanego dziś „białym złotem”, zużywa zaś olbrzymie ilości wody, zanieczyszcza środowisko i często wywołuje protesty lokalnych społeczności. Eksperci mówią o „paradoksie litu”.</p>

## Od 1 stycznia 2024 r. kierowcy zatankują na stacjach benzynę E10
 - [https://www.bankier.pl/wiadomosc/Od-1-stycznia-2024-r-kierowcy-zatankuja-na-stacjach-benzyne-E10-8671755.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Od-1-stycznia-2024-r-kierowcy-zatankuja-na-stacjach-benzyne-E10-8671755.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-31T07:31:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/5/e3fa9536f36abd-948-567-0-67-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Właściciele aut mogą sprawdzić w specjalnej internetowej wyszukiwarce, czy ich samochód jest przystosowany do korzystania z benzyny E10, która zawiera do 10 proc. biokomponentów. </p>

## Oszuści nie odpuszczają. Straty finansowe na skutek przestępstw telefonicznych są ogromne
 - [https://www.bankier.pl/wiadomosc/Oszusci-nie-odpuszczaja-Straty-finansowe-na-skutek-przestepstw-telefonicznych-sa-ogromne-8670303.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Oszusci-nie-odpuszczaja-Straty-finansowe-na-skutek-przestepstw-telefonicznych-sa-ogromne-8670303.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-31T07:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/6/50516eabaafb66-948-568-30-120-3970-2381.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wartość strat finansowych poniesionych w ubiegłym roku na skutek przestępstw telefonicznych to ponad 141 mln zł.  Wśród ofiar tego typu oszustw aż 3,5 tysiąca to osoby w wieku powyżej 65 lat - poinformowała Naukowa i Akademicka Sieć Komputerowa.</p>

## Wenecja nakłada wycieczkom "kaganiec". Grupy tylko do 25 osób i bez głośników
 - [https://www.bankier.pl/wiadomosc/Wenecja-naklada-wycieczkom-kaganiec-Grupy-tylko-do-25-osob-i-bez-glosnikow-8671727.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wenecja-naklada-wycieczkom-kaganiec-Grupy-tylko-do-25-osob-i-bez-glosnikow-8671727.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-31T05:11:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/4/2957966f9e54e5-945-560-0-108-1736-1041.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Grupy wycieczkowe liczące maksymalnie 25 osób, zakaz używania głośników podczas ich oprowadzania - to kolejne kroki zapowiedziane przez władze Wenecji, których celem jest ograniczenie negatywnego wpływu masowej turystyki na życie mieszkańców. Wcześniej zapadła decyzja o wprowadzeniu od wiosny przyszłego roku biletu wstępu do Wenecji w cenie 5 euro.</p>

## Nie każdy niewykorzystany urlop przejdzie na 2024 rok. Ekspert tłumaczy
 - [https://www.bankier.pl/wiadomosc/Nie-kazdy-niewykorzystany-urlop-przejdzie-na-2024-rok-Ekspert-tlumaczy-8669738.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nie-kazdy-niewykorzystany-urlop-przejdzie-na-2024-rok-Ekspert-tlumaczy-8669738.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-31T05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/0/b2cb12e1459afa-948-568-0-203-3008-1804.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Urlop wypoczynkowy niewykorzystany w roku bieżącym przejdzie jako urlop zaległy na rok 2024 r. - powiedział PAP prawnik, ekspert prawa pracy Sebastian Kryczka. Dodał, że nie wszystkie uprawnienia związane z czasem wolnym od pracy da się przenieść.</p>

## PIE: energetyka oparta na węglu wymaga miliardowych dopłat
 - [https://www.bankier.pl/wiadomosc/PIE-energetyka-oparta-na-weglu-wymaga-miliardowych-doplat-8670525.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PIE-energetyka-oparta-na-weglu-wymaga-miliardowych-doplat-8670525.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-31T05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/e/d1e1daf7ff2835-948-568-0-220-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Energetyka oparta na węglu wymaga miliardowych dopłat - podkreślili eksperci Polskiego Instytutu Ekonomicznego. Całkowity koszt rozwoju miksu elektroenergetycznego z utrzymaniem energetyki węglowej wynosi ponad 2,1 bln zł, czyli o 393 mld zł więcej niż przyspieszony rozwój OZE - dodali.</p>

## Przed nami wybory w USA, zmiana prezesa PiS, halving bitcoina i poszerzenie BRICS, czyli rok 2024 w pigułce
 - [https://www.bankier.pl/wiadomosc/Co-sie-wydarzy-w-2024-roku-Wybory-w-USA-halving-bitcoina-poszerzenie-BRICS-i-zmiana-prezesa-PiS-8670596.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Co-sie-wydarzy-w-2024-roku-Wybory-w-USA-halving-bitcoina-poszerzenie-BRICS-i-zmiana-prezesa-PiS-8670596.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-31T05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/a/9ad155776b1cbb-948-568-0-220-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nowy rok za pasem, więc warto spojrzeć na to, co już zapisano w kalendarzu
na nadchodzące 12 miesięcy. Ciekawych dat nie brakuje.</p>

## Źle się dzieje w państwie holenderskim, czyli kryzys mieszkaniowy w Niderlandach. Oto główne "grzechy” tamtejszej polityki
 - [https://www.bankier.pl/wiadomosc/Kryzys-mieszkaniowy-w-Holandii-Zle-sie-dzieje-w-Niderlandach-8668598.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kryzys-mieszkaniowy-w-Holandii-Zle-sie-dzieje-w-Niderlandach-8668598.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-31T05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/d/d83b255b7adeb3-948-568-0-10-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />
W
     Holandii kryzys mieszkaniowy jest tak duży, że rozważa się limit liczby
     zagranicznych studentów. Jakie są przyczyny kryzysu w kraju, który czasem
     był stawiany Polsce za wzór?
</p>

## Zwolni 7 tys. urzędników. Milei wprowadza w życie swój plan ratowania Argentyny
 - [https://www.bankier.pl/wiadomosc/Zwolni-7-tys-urzednikow-Milei-wprowadza-w-zycie-swoj-plan-ratowania-Argentyny-8671718.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zwolni-7-tys-urzednikow-Milei-wprowadza-w-zycie-swoj-plan-ratowania-Argentyny-8671718.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-12-31T04:44:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/1/4cf30bbf26f71e-948-568-0-111-2976-1785.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zacznie od redukcji zatrudnienia w sektorze publicznym, a zwolnienia pójdą w tysiące.  Prezydent Javier Milei przystępuje do urzeczywistniania swego radykalnego planu ratowania argentyńskiej gospodarki zrujnowanej za rządów peronistowskiej lewicy 150-procentową w skali rocznej inflacją i brakiem inwestycji.</p>

