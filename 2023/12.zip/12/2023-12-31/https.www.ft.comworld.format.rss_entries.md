# Source:Financial Times World, URL:https://www.ft.com/world?format=rss, language:en-US

## Year in a word: ‘Global south’
 - [https://www.ft.com/content/33566a47-f3c3-4c10-b7fd-97d58d6c5198](https://www.ft.com/content/33566a47-f3c3-4c10-b7fd-97d58d6c5198)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-12-31T13:00:43+00:00

The term has entered the mainstream this year. It embodies the dreams of many but infuriates others

