# Source:Wydarzenia Interia - Świat, URL:https://wydarzenia.interia.pl/swiat/feed, language:pl-PL

## Ukraińskie wojsko o nowej "czerwonej linii". "Prezent pod choinkę"
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-ukrainskie-wojsko-o-nowej-czerwonej-linii-prezent-pod-choink,nId,7241422](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-ukrainskie-wojsko-o-nowej-czerwonej-linii-prezent-pod-choink,nId,7241422)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-12-31T08:19:16+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-ukrainskie-wojsko-o-nowej-czerwonej-linii-prezent-pod-choink,nId,7241422"><img align="left" alt="Ukraińskie wojsko o nowej &quot;czerwonej linii&quot;. &quot;Prezent pod choinkę&quot;" src="https://i.iplsc.com/ukrainskie-wojsko-o-nowej-czerwonej-linii-prezent-pod-choink/000IB9JC6I57KAPP-C321.jpg" /></a>Straty Rosji w Ukrainie rosną z dnia na dzień. Od początku wojny Ukraińcy &quot;wyeliminowali&quot; ponad 359 tys. rosyjskich najeźdźców. Tylko minionej doby zginęło 960 bojowników. Ukraińskim obrońcom udało się także zadać inny cios rosyjskiemu wojsku. W ciągu doby zniszczono prawie 20 opancerzonych wozów bojowych wroga.</p><br clear="all" />

## Miasto walczy z turystami. Wprowadzą ograniczenia
 - [https://wydarzenia.interia.pl/zagranica/news-miasto-walczy-z-turystami-wprowadza-ograniczenia,nId,7241413](https://wydarzenia.interia.pl/zagranica/news-miasto-walczy-z-turystami-wprowadza-ograniczenia,nId,7241413)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-12-31T05:53:27+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-miasto-walczy-z-turystami-wprowadza-ograniczenia,nId,7241413"><img align="left" alt="Miasto walczy z turystami. Wprowadzą ograniczenia" src="https://i.iplsc.com/miasto-walczy-z-turystami-wprowadza-ograniczenia/000IB9IPPQO5O15L-C321.jpg" /></a>Władze Wenecji zapowiedziały kolejne kroki, by ograniczyć negatywny wpływ masowej turystyki na życie mieszkańców. Zgodnie z planami grupy wycieczkowe odwiedzające miasto mogłyby liczyć maksymalnie 25 osób, wprowadzony byłby także zakaz używania głośników podczas ich oprowadzania. Przepisy miałyby wejść w życie od czerwca 2024 roku. </p><br clear="all" />

## Bez paszportów po strefie Schengen. Dwa nowe kraje
 - [https://wydarzenia.interia.pl/zagranica/news-bez-paszportow-po-strefie-schengen-dwa-nowe-kraje,nId,7241409](https://wydarzenia.interia.pl/zagranica/news-bez-paszportow-po-strefie-schengen-dwa-nowe-kraje,nId,7241409)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-12-31T05:17:11+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-bez-paszportow-po-strefie-schengen-dwa-nowe-kraje,nId,7241409"><img align="left" alt="Bez paszportów po strefie Schengen. Dwa nowe kraje" src="https://i.iplsc.com/bez-paszportow-po-strefie-schengen-dwa-nowe-kraje/000IB9HSFB89L7AT-C321.jpg" /></a>Rumunia i Bułgaria to kolejne kraje, które zostaną przyjęte do strefy Schengen - ogłosiła hiszpańska prezydencja w Radzie Unii Europejskiej. Obywatele tych państw będą mogli podróżować po Europie bez paszportów od 31 marca 2024 r.</p><br clear="all" />

