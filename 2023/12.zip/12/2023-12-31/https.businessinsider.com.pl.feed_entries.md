# Source:Business insider, URL:https://businessinsider.com.pl/.feed, language:pl-PL

## Niedziele handlowe w 2024 r. Kiedy zrobimy weekendowe zakupy? [INFOGRAFIKA]
 - [https://businessinsider.com.pl/wiadomosci/siedem-niedziel-handlowych-w-nadchodzacym-roku-kiedy-wypadaja/0rydj5t](https://businessinsider.com.pl/wiadomosci/siedem-niedziel-handlowych-w-nadchodzacym-roku-kiedy-wypadaja/0rydj5t)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-12-31T16:03:14+00:00

W 2024 r. wypadnie siedem niedziel handlowych — z czego aż dwie w grudniu. Wiadomo już, kiedy Polacy będą mogli zrobić zakupy w drugi dzień weekendu. Czy to jeszcze zdąży się zmienić?

## To oni połączyli właśnie Tołpę z Bielendą. Wielki inwestor o polskich szansach [WYWIAD]
 - [https://businessinsider.com.pl/biznes/to-oni-polaczyli-wlasnie-tolpe-z-bielenda-wielki-inwestor-o-polskich-szansach-wywiad/j2e70wf](https://businessinsider.com.pl/biznes/to-oni-polaczyli-wlasnie-tolpe-z-bielenda-wielki-inwestor-o-polskich-szansach-wywiad/j2e70wf)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-12-31T14:45:40+00:00

Jest optymizm wśród wielkich inwestorów po wyborach i oby nie wyparował. Fundusz Innova Capital, która ma za sobą w Polsce inwestycje w Bakalland i połączenie Wirtualnej Polski z o2, inwestycje w Expandera czy Empik, a ostatnio Oshee wciąż obecny jest na naszym rynku, a właśnie przyłączył znane marki kosmetyków Tołpa do Bielendy. Zainwestował też w odnoszącą sukcesy nie tylko w kraju firmę dystrybuującą markowe stroje i sprzęt piłkarski R-Goal. Czy w Polsce wciąż jest miejsce na duże inwestycje funduszy private equity, skoro liczba inwestycji Innovy w naszym kraju spadła w ostatnich latach do jednej rocznie? Wszystko wyjaśnia w rozmowie z Business Insiderem starszy partner Innovy Leszek Muzyczyszyn.

## Reaktor, który można przewieźć na lawecie i działa 8 lat bez uzupełniania paliwa
 - [https://businessinsider.com.pl/gospodarka/smr-jakiego-jeszcze-nie-bylo-reaktor-zmiesci-sie-na-lawecie/qxnfs7j](https://businessinsider.com.pl/gospodarka/smr-jakiego-jeszcze-nie-bylo-reaktor-zmiesci-sie-na-lawecie/qxnfs7j)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-12-31T14:40:24+00:00

To może być przyszłość energetyki. Amerykańscy inżynierowie wypracowali minireaktor, który może pracować aż osiem lat bez uzupełniania paliwa. Urządzenie może być rozwiązaniem dla mniejszych skupisk ludzkich, ale być może zainteresuje także sektor wojskowy.

## Sprzedają burgery, które ważą sześć kilogramów. Co wchodzi w skład tak ogromnej kanapki?
 - [https://businessinsider.com.pl/wideo/burger-wazy-szesc-kilogramow-to-nie-bicie-rekordu-a-normalna-oferta-restauracji/yrl1vgq](https://businessinsider.com.pl/wideo/burger-wazy-szesc-kilogramow-to-nie-bicie-rekordu-a-normalna-oferta-restauracji/yrl1vgq)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-12-31T14:20:00+00:00

Burger-gigant z jednej z amerykańskich restauracji waży sześć kilogramów i jest przeznaczony dla co najmniej sześciu osób. Koszt? 85 dol. Sprawdziliśmy, z czego jest zrobiony.

## Od jutra na stacjach benzynowych nie kupisz Pb95. Zastąpi je zupełnie nowe paliwo
 - [https://businessinsider.com.pl/gospodarka/nowy-rok-nowe-paliwo-na-stacjach-znika-popularna-pb95/0cymntq](https://businessinsider.com.pl/gospodarka/nowy-rok-nowe-paliwo-na-stacjach-znika-popularna-pb95/0cymntq)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-12-31T14:10:59+00:00

Nadszedł moment, który wywoływał wiele wątpliwości i obaw wśród kierowców. Na stacjach benzynowych od 1 stycznia nie można będzie kupić benzyny Pb95. Zostanie zastąpione nowym paliwem, które może nie być odpowiednie dla niektórych pojazdów. Oto co trzeba wiedzieć na ten temat.

## W 2024 r. pierwszy komercyjny spacer w kosmosie. W planach też inne podboje
 - [https://businessinsider.com.pl/technologie/nauka/w-2024-r-pierwszy-komercyjny-spacer-w-kosmosie-beda-tez-inne-podboje/28vnfg7](https://businessinsider.com.pl/technologie/nauka/w-2024-r-pierwszy-komercyjny-spacer-w-kosmosie-beda-tez-inne-podboje/28vnfg7)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-12-31T13:59:24+00:00

Rok 2024 zapowiada się jako ekscytujący czas dla eksploracji kosmosu. Rusza wiele nowych misji, w dodatku organizowanych przez różne kraje. Doczekamy się nawet czegoś, co mógł zapewnić chyba tylko miliarder Elon Musk.

## Problemy Nvidii: bogaci pracownicy przestają pracować
 - [https://businessinsider.com.pl/technologie/nowe-technologie/problemy-nvidii-bogaci-pracownicy-przestaja-pracowac/c8tl3nh](https://businessinsider.com.pl/technologie/nowe-technologie/problemy-nvidii-bogaci-pracownicy-przestaja-pracowac/c8tl3nh)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-12-31T13:30:00+00:00

Gwałtowny wzrost Nvidii w tym roku spowodował niecodzienny problem: niektórzy pracownicy z dłuższym stażem posiadający mnóstwo akcji firmy szybko się wzbogacili i nie wykonują już swoich obowiązków. Jest to na tyle poważny temat, że CEO Nvidii, Jensen Huang, uznał za stosowne poruszyć go podczas wewnętrznego spotkania wszystkich pracowników, które odbyło się w zeszłym miesiącu. Z listy wcześniej przesłanych pytań pracowników Huang wybrał jedno, którego autor chciał dowiedzieć się, co można zrobić ze starszymi stażem kolegami, którzy sprawiają wrażenie, jakby przeszli już na emeryturę.

## Czy oglądanie filmów z napisami pomaga w nauce języków? Tak, ale możliwe, że robisz to źle
 - [https://businessinsider.com.pl/technologie/nowe-technologie/czy-ogladanie-filmow-z-napisami-rzeczywiscie-pomaga-w-nauce-jezykow/g9h4q7f](https://businessinsider.com.pl/technologie/nowe-technologie/czy-ogladanie-filmow-z-napisami-rzeczywiscie-pomaga-w-nauce-jezykow/g9h4q7f)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-12-31T13:07:32+00:00

Filmy oferowane w oryginalnym języku wraz z napisami w różnych językach są szeroko dostępne w Europie, w tym w Polsce. Oglądanie ich w wersji z napisami często postrzegane jest przez pryzmat edukacyjny. Wychodzimy z założenia, że jeśli oglądamy np. anglojęzyczny film z polskimi napisami, to pomagamy sobie w nauce angielskiego. Naukowcy nie byli co do tego pewni, więc przeprowadzili stosowne badanie.

## Akcja amerykańskich helikopterów nad Morzem Czerwonym. Maersk wstrzymuje kontenerowce
 - [https://businessinsider.com.pl/wiadomosci/atak-na-dunski-kontenerowiec-interwencja-usa-na-morzu-czerwonym/6v52rt3](https://businessinsider.com.pl/wiadomosci/atak-na-dunski-kontenerowiec-interwencja-usa-na-morzu-czerwonym/6v52rt3)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-12-31T13:06:05+00:00

Śmigłowce z amerykańskiego lotniskowca USS Eisenhower interweniowały po ataku na duński kontenerowiec Maersk Hangzhou na Morzu Czerwonym. Statek został ostrzelany przez jednostki jemeńskiego ruchu Huti. Trzy statki atakujących zostały zatopione, czwartemu udało się odpłynąć. To nie pierwszy taki przypadek.

## Eksperci nie mają wątpliwości. Energetyka oparta na węglu wymaga gigantycznych dopłat
 - [https://businessinsider.com.pl/gospodarka/eksperci-pie-energetyka-oparta-na-weglu-wymaga-gigantycznych-doplat/239skf8](https://businessinsider.com.pl/gospodarka/eksperci-pie-energetyka-oparta-na-weglu-wymaga-gigantycznych-doplat/239skf8)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-12-31T12:50:04+00:00

Utrzymywanie energetyki opartej na węglu jest wyjątkowo kosztowne. Eksperci z Polskiego Instytutu Ekonomicznego wyliczyli, że całkowity koszt rozwoju miksu elektroenergetycznego z utrzymaniem energetyki węglowej wynosi ponad 2,1 bln zł. Według analizy ekspertów, polski miks elektroenergetyczny, czyli struktura wytwarzania energii elektrycznej, może być bez węgla już w 2040 r.

## Na liście 500 najbogatszych ludzi świata znalazł się tylko jeden Polak. Wcale nie najbardziej znany
 - [https://businessinsider.com.pl/gospodarka/na-liscie-500-najbogatszych-ludzi-swiata-znalazl-sie-tylko-jeden-polak/bdjjmc2](https://businessinsider.com.pl/gospodarka/na-liscie-500-najbogatszych-ludzi-swiata-znalazl-sie-tylko-jeden-polak/bdjjmc2)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-12-31T12:48:20+00:00

W zestawieniu 500 najbogatszych ludzi świata w 2023 r. na szczycie większych zaskoczeń nie było. Liderem został Elon Musk, który wyprzedził Bernarda Arnaulta i Jeffa Bezosa. Jednak w kraju nad Wisłą wielkim zaskoczeniem może być fakt, że na liście został umieszczony jeden Polak. I to na dodatek najbardziej tajemniczy.

## Jak zmieniały się ceny metrów na rynku wtórnym? "Rok niespotykanych wzrostów"
 - [https://businessinsider.com.pl/wiadomosci/tak-wygladaly-ceny-mieszkan-na-rynku-wtornym-od-lat-widac-wzrost/yjbgyv8](https://businessinsider.com.pl/wiadomosci/tak-wygladaly-ceny-mieszkan-na-rynku-wtornym-od-lat-widac-wzrost/yjbgyv8)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-12-31T12:10:28+00:00

Ostatnie lata na rynku nieruchomości upłynęły pod znakiem wzrostu cen za m kw. Jak pokazują dane z 2023 r., w niektórych miastach w ciągu kilku lat ceny mieszkań poszły w górę nawet o 31 proc. Gdzie wzrosły najbardziej?

## Rok 2024 – prognozy dla rynku fuzji i przejęć
 - [https://businessinsider.com.pl/gospodarka/prognozy-dla-fuzji-i-przejec-w-2024-r/bw8z5be](https://businessinsider.com.pl/gospodarka/prognozy-dla-fuzji-i-przejec-w-2024-r/bw8z5be)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-12-31T11:21:33+00:00

W 2024 r. możemy spodziewać się większej liczby transakcji na rynku fuzji i przejęć, jak również ożywienia rynku IPO. Fundusze PE będą brały pod lupę m.in. inwestycje w firmy rozwijające mark cyfrowe, zielony Climatech, czy też spółki Software as a Serwise – pisze dla Business Insider Tomasz Czechowicz, partner zarządzający i założyciel MCI Capital.

## Co piąty Polak nie ma żadnych oszczędności. Powód jest oczywisty
 - [https://businessinsider.com.pl/gospodarka/co-piaty-polak-nie-ma-zadnych-oszczednosci-powod-jest-oczywisty/48vzbnw](https://businessinsider.com.pl/gospodarka/co-piaty-polak-nie-ma-zadnych-oszczednosci-powod-jest-oczywisty/48vzbnw)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-12-31T11:16:47+00:00

Stan oszczędności Polaków nie jest — mówiąc delikatnie — najlepszy. Ponad 20 proc. z nas nie posiada żadnych oszczędności. Największa grupa tych, którym udaje się odłożyć pieniądze "na czarną godzinę", byłaby w stanie za zgromadzone środki przeżyć zaledwie miesiąc.

## Tysiące ofiar straciły pieniądze. Rok 2023 rekordowy pod względem cyberataków
 - [https://businessinsider.com.pl/technologie/nowe-technologie/tysiace-ofiar-stracily-pieniadze-rok-2023-rekordowy-pod-wzgledem-cyberatakow/xhs8rgw](https://businessinsider.com.pl/technologie/nowe-technologie/tysiace-ofiar-stracily-pieniadze-rok-2023-rekordowy-pod-wzgledem-cyberatakow/xhs8rgw)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-12-31T10:43:16+00:00

To był rok cyberwymuszeń. Liczba ofiar cyberataków w pierwszych trzech kwartałach 2023 roku była o 33 proc. wyższa niż w całym roku poprzednim. Przypominamy głośne ataki, ale też kluczowe porady dotyczące bezpieczeństwa.

## Posiedzenie Rady Mediów Narodowych nagle odwołane
 - [https://businessinsider.com.pl/wiadomosci/posiedzenie-rady-mediow-narodowych-nagle-odwolane/qdb7hdb](https://businessinsider.com.pl/wiadomosci/posiedzenie-rady-mediow-narodowych-nagle-odwolane/qdb7hdb)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-12-31T10:30:01+00:00

Niedzielne posiedzenie Rady Mediów Narodowych zostało odwołane — poinformowała PAP posłanka PiS Joanna Lichocka, członkini RMN. Nie ujawniła, skąd decyzja o odwołaniu posiedzenia Rady.

## Samochód stanie się dodatkiem do smartfona. Huawei i Xiaomi prezentują własne pojazdy
 - [https://businessinsider.com.pl/technologie/motoryzacja/huawei-i-xiaomi-prezentuja-swoje-samochody-a-gdzie-sa-icar-applea/d986jd8](https://businessinsider.com.pl/technologie/motoryzacja/huawei-i-xiaomi-prezentuja-swoje-samochody-a-gdzie-sa-icar-applea/d986jd8)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-12-31T09:45:56+00:00

Huawei i Xiaomi wprowadzają na rynek elektryczne pojazdy zaprojektowane do współpracy z ich telefonami. Apple podobno pracuje nad własnym samochodem już od lat, ale firma nie zaprezentowała nic do tej pory. Wygląda na to, że pozwala się wyprzedzić chińskim rywalom.

## Kim Dzong Un nakazuje przygotowania do ewentualnej wojny nuklearnej
 - [https://businessinsider.com.pl/wiadomosci/przywodca-korei-pld-znow-grozi-atakiem-nuklearnym/yzf1k90](https://businessinsider.com.pl/wiadomosci/przywodca-korei-pld-znow-grozi-atakiem-nuklearnym/yzf1k90)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-12-31T09:45:28+00:00

Przywódca Korei Północnej, Kim Dzong Un, zlecił armii przyspieszenie przygotowań do ewentualnej wojny, ponownie grożąc atakiem nuklearnym na Seul. Oskarżył Stany Zjednoczone o "różne rodzaje zagrożeń militarnych" i nakazał utrzymanie rosnącego potencjału odpowiedzi na wojnę.

## Buffett pomaga spod Warszawy. Sprawdziliśmy, skąd pomoc trafia nie tylko do Ukrainy
 - [https://businessinsider.com.pl/gospodarka/buffett-pomaga-spod-warszawy-sprawdzilismy-jak-sle-pomoc-do-ukrainy/0mthnzm](https://businessinsider.com.pl/gospodarka/buffett-pomaga-spod-warszawy-sprawdzilismy-jak-sle-pomoc-do-ukrainy/0mthnzm)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-12-31T09:16:05+00:00

Niepozornie wyglądający magazyn pod Warszawą nie rzuca się w oczy. Ale to właśnie z tego utrzymywanego głównie pieniędzmi syna Warrena Buffetta kompleksu pracownicy błyskawicznie trafiają na miejsca dotknięte katastrofami humanitarnymi na całym świecie. To regionalne centrum jednej z największych organizacji pomocowych obok Czerwonego Krzyża i Caritasu. Sprawdziliśmy od wewnątrz, jak działa europejski oddział Global Empowerment Mission z siedzibą w Polsce.

## Tu kupowaliśmy przed erą Biedronki i Lidla. Pamiętasz te sklepy?
 - [https://businessinsider.com.pl/finanse/handel/kupowales-w-tych-sklepach-oto-popularne-sieci-ktore-zniknely-z-polski/1ws4k43](https://businessinsider.com.pl/finanse/handel/kupowales-w-tych-sklepach-oto-popularne-sieci-ktore-zniknely-z-polski/1ws4k43)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-12-31T07:48:36+00:00

Dziś wszyscy kupujemy w Biedronkach, Lidlach, Żabkach czy Dino. Ale zanim zaczęła się era dyskontów, w Polsce istniało przynajmniej kilka sieci supermarketów, które w latach 90. i na początku XXI w. stawały się w naszym kraju namiastką Zachodu. Oto marki, które zniknęły już z naszego kraju. Pamiętasz je?

## Pojechałem na Mazury elektrykiem – okazało się, że to kraina tysiąca niespodzianek
 - [https://businessinsider.com.pl/technologie/motoryzacja/pojechalem-na-mazury-elektrykiem-okazalo-sie-ze-to-kraina-tysiaca-niespodzianek/z7y2rxv](https://businessinsider.com.pl/technologie/motoryzacja/pojechalem-na-mazury-elektrykiem-okazalo-sie-ze-to-kraina-tysiaca-niespodzianek/z7y2rxv)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-12-31T07:10:00+00:00

Elektryczne samochody, w tym rodzinny Volkswagen ID.5, kojarzą się z ekologią, podobnie jak nasze Mazury, czyli Kraina Tysiąca Jezior. Choć to region urokliwy, to jednak jazda w tym regionie samochodem na prąd, nawet wyposażonym w pojemne akumulatory, stanowi nie lada wyzwanie. Postanowiłem je podjąć. Szczególnie że Mazury, tuż po sezonie, to piękne miejsce.

## "Warszawski Hongkong" już nie przypomina pustyni. Za to ceny zwalają z nóg
 - [https://businessinsider.com.pl/wiadomosci/warszawski-hongkong-juz-nie-jest-pustynia-ceny-zwalaja-z-nog/8yz27yc](https://businessinsider.com.pl/wiadomosci/warszawski-hongkong-juz-nie-jest-pustynia-ceny-zwalaja-z-nog/8yz27yc)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-12-31T06:00:00+00:00

Po roku wróciliśmy na warszawską Bliską Wolę, czyli na jedną z najbardziej kontrowersyjnych inwestycji ostatnich lat. Co się zmieniło? Przede wszystkim widać coraz więcej życia, a coraz mniej ekip budowlanych. Na każdym kroku można się jednak przekonać, że bynajmniej nie jest to typowe stołeczne osiedle.

