# Source:The Hill, URL:https://thehill.com/news/feed, language:en-US

## Netanyahu rejects claims accusing Israel of genocide in Gaza
 - [https://thehill.com/policy/international/4383588-netanyahu-rejects-claims-accusing-israel-of-genocide-in-gaza](https://thehill.com/policy/international/4383588-netanyahu-rejects-claims-accusing-israel-of-genocide-in-gaza)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-12-31T23:21:01+00:00

Israeli Prime Minister Benjamin Netanyahu on Sunday pushed back against claims that Israel is committing genocide in Gaza, calling such accusations "false" after South Africa filed a case against Israel at the United Nations' top court. "I would like to say a word about South Africa's false accusation that Israel is committing genocide. No, South...

## Chief justice centers Supreme Court annual report on AI's dangers
 - [https://thehill.com/regulation/court-battles/4383324-chief-justice-centers-supreme-court-annual-report-on-ais-dangers](https://thehill.com/regulation/court-battles/4383324-chief-justice-centers-supreme-court-annual-report-on-ais-dangers)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-12-31T23:00:00+00:00

Chief Justice John Roberts warned that courts will need to consider the proper use of artificial intelligence (AI), portraying it as a new frontier for change in an annual report that follows a turbulent year for the Supreme Court. “I predict that human judges will be around for a while,” Roberts wrote in his report....

## Congress must track foreign money in higher education
 - [https://thehill.com/opinion/congress-blog/4383606-congress-must-track-foreign-money-in-higher-education](https://thehill.com/opinion/congress-blog/4383606-congress-must-track-foreign-money-in-higher-education)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-12-31T23:00:00+00:00

The public needs to know who is contributing money to American postsecondary institutions. Strengthening reporting requirements is a matter of national security.

## Appeals court allows California law banning guns in public places to go into effect
 - [https://thehill.com/homenews/state-watch/4383463-appeals-court-allows-california-law-banning-guns-in-public-places-to-go-into-effect](https://thehill.com/homenews/state-watch/4383463-appeals-court-allows-california-law-banning-guns-in-public-places-to-go-into-effect)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-12-31T19:29:21+00:00

A California bill that prohibits the carrying of firearms in most public places is slated to become law on Jan. 1, after a U.S. Appeals Court on Saturday put a temporary hold on a district court’s decision blocking the law from taking effect. The appeals court decision comes 10 days after U.S. District Judge Cormac...

## Czechs refuse to attend UN security council meeting called by Russia
 - [https://thehill.com/policy/international/4383333-czechs-refuse-to-attend-un-security-council-meeting-called-by-russia](https://thehill.com/policy/international/4383333-czechs-refuse-to-attend-un-security-council-meeting-called-by-russia)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-12-31T17:29:29+00:00

The Czech Republic is refusing to attend an emergency United Nations Security Council meeting that was called by Russia, arguing Moscow was responsible for the nearly two-year war in Ukraine. “We refuse to be summoned anywhere by Russia. Czechia will not serve the lie-poisoned propaganda of the aggressor,” Czech Foreign Minister Jan Lipavsky wrote in...

## Five ways artificial intelligence is rapidly changing our world
 - [https://thehill.com/policy/technology/4372445-five-ways-artificial-intelligence-is-rapidly-changing-our-world](https://thehill.com/policy/technology/4372445-five-ways-artificial-intelligence-is-rapidly-changing-our-world)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-12-31T16:49:44+00:00

The reach of generative artificial intelligence (AI) skyrocketed this year as tech companies raced to get ahead of each other while regulators and lawmakers looked to add guardrails.   As AI became more common and accessible — especially OpenAI’s popular ChatGPT chatbot — — it shaped society by posing new opportunities and risks for sectors ranging...

## Utah governor says social media causes increases in anxiety, depression, self-harm among youth
 - [https://thehill.com/homenews/state-watch/4383171-utah-governor-says-social-media-causes-increases-in-anxiety-depression-self-harm-among-youth](https://thehill.com/homenews/state-watch/4383171-utah-governor-says-social-media-causes-increases-in-anxiety-depression-self-harm-among-youth)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-12-31T16:33:20+00:00

Utah Gov. Spencer Cox (R) is sounding the alarm on the dangers of social media in a new interview, pointing out that it could lead to more mental health issues especially among young people. Cox said on NBC's "Meet the Press" that youth mental health is "the issue of our time" in an interview that...

## Three women who spoke out on Trump give grave warning on his return to office
 - [https://thehill.com/homenews/campaign/4383263-three-women-who-spoke-out-on-trump-give-grave-warning-on-his-return-to-office](https://thehill.com/homenews/campaign/4383263-three-women-who-spoke-out-on-trump-give-grave-warning-on-his-return-to-office)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-12-31T15:55:18+00:00

Three former Trump administration officials who vocally criticized the former president in the aftermath of the Jan. 6, 2021 attack on the U.S. Capitol in a joint interview on Sunday warned he represents a danger to democracy if he is reelected to a second term. Former White House Communications Director Alyssa Farah Griffin, former White...

## Raskin suggests Clarence Thomas should recuse himself from Trump 14th Amendment decision
 - [https://thehill.com/homenews/house/4383219-raskin-suggests-clarence-thomas-should-recuse-himself-from-trump-14th-amendment-decision](https://thehill.com/homenews/house/4383219-raskin-suggests-clarence-thomas-should-recuse-himself-from-trump-14th-amendment-decision)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-12-31T15:34:33+00:00

Rep. Jamie Raskin (D-Md.) suggested Sunday that Supreme Court Justice Clarence Thomas should recuse himself from a future ruling on whether former President Trump can be disqualified from the 2024 ballot under the 14th Amendment. Raskin said he thinks "anybody looking at this in any kind of dispassionate, reasonable way would say if your wife...

## As a true challenger, Nikki Haley is more vulnerable but would also have more upside
 - [https://thehill.com/opinion/campaign/4380399-as-a-true-challenger-haley-is-more-vulnerable-but-would-also-have-more-upside](https://thehill.com/opinion/campaign/4380399-as-a-true-challenger-haley-is-more-vulnerable-but-would-also-have-more-upside)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-12-31T13:00:00+00:00

Nikki Haley would also be better suited than Trump to run on a message of change that appeals to swing voters, who want to move on from both Biden and Trump.

## US sinks 3 Houthi boats in Red Sea after attack on merchant ship
 - [https://thehill.com/policy/international/4383140-us-sinks-3-houthi-boats-in-red-sea-after-attack-on-merchant-ship](https://thehill.com/policy/international/4383140-us-sinks-3-houthi-boats-in-red-sea-after-attack-on-merchant-ship)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-12-31T12:56:54+00:00

The United States sunk three small Houthi boats in the Red Sea early Sunday morning following another attack on a merchant ship as tensions continue to rise in the region.   U.S. Navy helicopters from the USS Eisenhower and the Gravely responded to a distress call issued by the container ship Maersk Hangzhao — the...

## No Labels' Lieberman: 'I’ve never seen this much anger at the two major parties'
 - [https://thehill.com/homenews/campaign/4383014-no-labels-lieberman-ive-never-seen-this-much-anger-at-the-two-major-parties](https://thehill.com/homenews/campaign/4383014-no-labels-lieberman-ive-never-seen-this-much-anger-at-the-two-major-parties)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-12-31T12:00:00+00:00

Political organization No Labels’ founding chair and former Connecticut Sen. Joe Lieberman (I-Conn.) said the anger among Americans at the Republican and Democratic parties is unlike anything he's seen before. “I've never seen this much anger at the two major parties,” Lieberman said in a Sunday interview with radio host John Catsimatidis on “The Cats...

## Six Americans who left lasting legacies in 2023
 - [https://thehill.com/opinion/civil-rights/4382731-six-americans-who-left-lasting-legacies-in-2023](https://thehill.com/opinion/civil-rights/4382731-six-americans-who-left-lasting-legacies-in-2023)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-12-31T12:00:00+00:00

Remembering their compassion, convictions and courage reminds us that self-absorbed, self-interested cynics need not dominate our public life.

## 'The year that defied all odds': How Wall Street powered through recession fears
 - [https://thehill.com/business/4381828-the-year-that-defied-all-odds-how-wall-street-powered-through-recession-fears](https://thehill.com/business/4381828-the-year-that-defied-all-odds-how-wall-street-powered-through-recession-fears)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-12-31T11:00:00+00:00

The stock market closed to books on a winning year on Friday despite earlier recession fears. “2023 may go down in history as the year that defied all odds,” Kelly Milligan, co-founder of Quorum Private Wealth, told The Hill. “At the end of 2022, nearly every expert at the major banks predicted a recession and/or...

## Houthi squeeze on Red Sea shipping risks enormous cost to global economy
 - [https://thehill.com/policy/defense/4382064-houthis-force-cargo-ships-to-take-long-route-at-a-cost](https://thehill.com/policy/defense/4382064-houthis-force-cargo-ships-to-take-long-route-at-a-cost)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-12-31T11:00:00+00:00

The Houthi rebel group in Yemen has almost completely shut down a key shipping route in the Red Sea, costing the global economy and setting up a huge challenge for the White House.  The relentless Houthi attacks on merchant vessels and commercial boats pushed several of the world’s largest shipping companies to cancel transits through the Red Sea. Oil-producing...

## The political winners and losers of 2023
 - [https://thehill.com/homenews/administration/4367614-the-political-winners-and-losers-of-2023](https://thehill.com/homenews/administration/4367614-the-political-winners-and-losers-of-2023)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-12-31T11:00:00+00:00

Political winners were hard to come by in 2023. At home, congressional dysfunction and toxic partisanship dominated. Overseas, in Ukraine and the Middle East, grave conflicts posed big challenges to the United States. The signature political accomplishments, such as they were, tended to be centered on the avoidance of disaster. A U.S. default was headed...

## Revelers set to pack into Times Square for annual New Year's Eve ball drop
 - [https://thehill.com/homenews/ap/ap-u-s-news/4383011-revelers-set-to-pack-into-times-square-for-annual-new-years-eve-ball-drop](https://thehill.com/homenews/ap/ap-u-s-news/4383011-revelers-set-to-pack-into-times-square-for-annual-new-years-eve-ball-drop)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-12-31T03:45:25+00:00

NEW YORK (AP) — The confetti has been tested for airiness. The giant numerals – 2 0 2 4 – are in place. And the luminous ball, bedazzled with 2,688 crystal triangles, is fixed to the pole from which it makes its 60-second descent at 11:59 p.m. With throngs of revelers set to usher in the new year under...

## Haley appears to mix up CNN anchor and Iowa women's basketball star
 - [https://thehill.com/homenews/campaign/4382984-haley-appears-to-mix-up-cnn-anchor-and-iowa-womens-basketball-star](https://thehill.com/homenews/campaign/4382984-haley-appears-to-mix-up-cnn-anchor-and-iowa-womens-basketball-star)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-12-31T02:41:58+00:00

GOP presidential candidate Nikki Haley appeared to mix up a CNN anchor and a college women’s basketball star in a clip posted Saturday. According to The Des Moines Register, Haley was speaking to a crowd in Coralville, Iowa, before the University of Iowa women’s basketball game Saturday when the incident occurred.  “[W]e’re super excited to...

## Shelling kills 21 in Russian city of Belgorod following Moscow's aerial attacks across Ukraine
 - [https://thehill.com/homenews/ap/ap-international/4382970-shelling-kills-21-in-russian-city-of-belgorod-following-moscows-aerial-attacks-across-ukraine](https://thehill.com/homenews/ap/ap-international/4382970-shelling-kills-21-in-russian-city-of-belgorod-following-moscows-aerial-attacks-across-ukraine)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-12-31T02:01:27+00:00

Shelling in the center of the Russian border city of Belgorod Saturday killed 21 people, including three children, local officials reported. A further 110 people were wounded in the strike, said regional governor Vyacheslav Gladkov, making it one of the deadliest attacks on Russian soil since the start of Moscow’s invasion of Ukraine 22 months...

## New York City prepares for New Years celebration protestors
 - [https://thehill.com/homenews/state-watch/4382946-new-york-city-prepares-for-new-years-celebration-protestors](https://thehill.com/homenews/state-watch/4382946-new-york-city-prepares-for-new-years-celebration-protestors)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-12-31T01:47:07+00:00

New York City is preparing for protestors during its New Year’s celebrations, officials said at a press conference Friday. “[T]he groups that have regularly protested, in regards to Israel-Palestine, have been 1,000 to 5,000 on occasion, and we're prepared for ‘em at any number,” New York Police Department (NYPD) Assistant Chief John Hart said. “We're...

## 5 things to know about Tom Wilkinson
 - [https://thehill.com/blogs/in-the-know/4382832-tom-wilkinson-what-to-know-full-monty-actor](https://thehill.com/blogs/in-the-know/4382832-tom-wilkinson-what-to-know-full-monty-actor)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-12-31T01:17:43+00:00

Oscar-nominated actor Tom Wilkinson, who passed away "suddenly" Saturday at the age of 75, according to an announcement by his family, had a long 50-year career in Hollywood with both television and film credits to his name. The English actor starred in more than 130 roles on the big and small screens and was recognized...

## Maine secretary of state latest victim of swatting spree
 - [https://thehill.com/homenews/state-watch/4382874-maine-secretary-state-latest-victim-of-swatting-spree](https://thehill.com/homenews/state-watch/4382874-maine-secretary-state-latest-victim-of-swatting-spree)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-12-31T01:14:24+00:00

The home of Maine Secretary of State Shenna Bellows was swatted on Friday, making her the latest victim in a string of such incidents. Bellows said she's become the victim of a series of threats in the wake of her decision to remove former President Trump from the ballot under the 14th Amendment on Friday. "We were not home...

## Ramaswamy slams CNN's 'egregious interference' with Iowa GOP caucus over town halls
 - [https://thehill.com/homenews/campaign/4382897-ramaswamy-slams-cnns-egregious-interference-with-iowa-gop-caucus-town-halls](https://thehill.com/homenews/campaign/4382897-ramaswamy-slams-cnns-egregious-interference-with-iowa-gop-caucus-town-halls)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-12-31T00:57:17+00:00

GOP presidential primary candidate Vivek Ramaswamy went after CNN in a Saturday post on X, the platform formerly known as Twitter. “CNN’s egregious interference with the Iowa GOP caucus is offensive,” Ramaswamy wrote. “My CNN town hall with the voters here went so well that they cut it off early &#38; then threatened our campaign...

