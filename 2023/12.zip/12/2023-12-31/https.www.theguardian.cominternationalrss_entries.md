# Source:The Guardian - International, URL:https://www.theguardian.com/international/rss, language:en-US

## NFL roundup: Purdy rebounds as San Francisco 49ers clinch NFC’s top seed
 - [https://www.theguardian.com/sport/2023/dec/31/nfl-roundup-week-17-scores](https://www.theguardian.com/sport/2023/dec/31/nfl-roundup-week-17-scores)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-12-31T21:31:17+00:00

<ul><li>Niners beat Commanders 27-10 to clinch No 1 seed in NFC</li><li>Eagles stunned by Cardinals 35-31 for fourth loss in December</li><li>Jaguars blank Panthers 26-0 to end four-game losing streak</li></ul><p>Brock Purdy bounced back from the worst game of his NFL career to throw two touchdown passes, and the San Francisco 49ers clinched the top seed in the NFC by beating the Washington Commanders 27-10 on Sunday.</p><p>Philadelphia’s stunning home loss to Arizona, combined with Detroit’s defeat at Dallas on Saturday, allowed the 49ers (12-4) to sure up a first-round bye and home-field advantage before Week 18. A large cheer erupted from the visiting locker room when the Eagles lost.</p> <a href="https://www.theguardian.com/sport/2023/dec/31/nfl-roundup-week-17-scores">Continue reading...</a>

## XFL and USFL announce new, merged spring football league
 - [https://www.theguardian.com/sport/2023/dec/31/xfl-and-usfl-announce-new-merged-spring-football-league](https://www.theguardian.com/sport/2023/dec/31/xfl-and-usfl-announce-new-merged-spring-football-league)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-12-31T18:13:30+00:00

<ul><li>The United Football League to kickoff in March 2024</li><li>2023 XFL and USFL champions will play in opening game</li></ul><p>The latest edition of a spring football league will be called the “United Football League”, after the merged XFL-USFL leagues confirmed they will be merging.</p><p>Former XFL president/CEO Russ Brandon will hold the same position in the UFL. Former USFL president of football operations and current Fox Sports broadcaster Daryl Johnston will lead the new league’s football operations, the league announced in a press release.</p> <a href="https://www.theguardian.com/sport/2023/dec/31/xfl-and-usfl-announce-new-merged-spring-football-league">Continue reading...</a>

## Venice to limit tourist group size to 25 to protect historic city
 - [https://www.theguardian.com/world/2023/dec/31/venice-to-limit-tourist-group-size-to-25-to-protect-historic-city](https://www.theguardian.com/world/2023/dec/31/venice-to-limit-tourist-group-size-to-25-to-protect-historic-city)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-12-31T16:50:08+00:00

<p>Move aims to reduce pressure of thousands of daily visitors to Italian city and protect residents</p><p>Venice is to limit the size of tourist groups in an attempt to reduce the pressure of <a href="https://www.theguardian.com/world/2019/jan/06/venice-losing-fight-with-tourism-and-flooding">thousands of visitors</a> crowding its squares, bridges and narrow walkways each day.</p><p>From June, groups visiting the Italian canal city will be limited to 25 people, or roughly half the capacity of a tourist bus, the city announced this weekend. The use of loudspeakers, popular among tour groups, and “which can generate confusion and disturbances”, will be banned in the city and on nearby islands, officials said in a statement.</p> <a href="https://www.theguardian.com/world/2023/dec/31/venice-to-limit-tourist-group-size-to-25-to-protect-historic-city">Continue reading...</a>

## Clarence Thomas must recuse himself from ruling on Trump’s 2024 eligibility, Raskin says
 - [https://www.theguardian.com/us-news/2023/dec/31/clarence-thomas-supreme-court-trump-2024-eligibility](https://www.theguardian.com/us-news/2023/dec/31/clarence-thomas-supreme-court-trump-2024-eligibility)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-12-31T16:43:22+00:00

<p>Democrat speaks on supreme court stepping in to adjudicate Maine and Colorado rulings that removed Trump from ballots</p><p>Supreme court justice <a href="https://www.theguardian.com/us-news/clarence-thomas">Clarence Thomas</a> must recuse himself from ruling on Donald Trump’s eligibility for the 2024 presidential election, a prominent Democrat said Sunday, warning that the leading Republican candidate is seeking to become a “political martyr” as he pursues a second presidency.</p><p>Maryland congressman Jamie Raskin was speaking ahead of the nation’s highest court stepping in to adjudicate recent <a href="https://www.theguardian.com/us-news/2023/dec/19/why-did-colorado-disqualify-trump-white-house-2024-election">state rulings in Maine and Colorado</a> that struck the former president from the general election primaries under the US constitution’s 14th amendment insurrection clause.</p> <a href="https://www.theguardian.com/us-news/2023/dec/31/clarence-thomas-supreme-court-trump-20

## ‘What we got replay for?’: LeBron James criticises officiating call in Lakers defeat
 - [https://www.theguardian.com/sport/2023/dec/31/lakers-timberwolves-lebron-james-nba-officials](https://www.theguardian.com/sport/2023/dec/31/lakers-timberwolves-lebron-james-nba-officials)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-12-31T12:23:57+00:00

<ul><li>LA fell 108-106 to the Minnesota Timberwolves on Saturday</li><li>A potential game-tying three-pointer was ruled a two-point shot</li></ul><p>LeBron James thought he added to his legacy with another big shot on his 39th birthday.</p><p>The NBA’s replay center had a different view, causing James to call out the league’s replay process.</p> <a href="https://www.theguardian.com/sport/2023/dec/31/lakers-timberwolves-lebron-james-nba-officials">Continue reading...</a>

## Mainstream media is playing into Trump’s neo-fascist hands. I’m sticking with democracy and the Guardian | Robert Reich
 - [https://www.theguardian.com/commentisfree/2023/dec/31/mainstream-media-is-playing-into-trumps-neo-fascist-hands-im-sticking-with-democracy-and-the-guardian](https://www.theguardian.com/commentisfree/2023/dec/31/mainstream-media-is-playing-into-trumps-neo-fascist-hands-im-sticking-with-democracy-and-the-guardian)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-12-31T11:00:03+00:00

<p>I trust the Guardian to illuminate what’s really happening as America faces an election in which one of the two likely candidates engaged in an attempted coup</p><p>The reason I write a column for the Guardian is the same reason I read it daily: I trust it.</p><p>Not just the facts it conveys but also its judgment about <em>what</em> to convey – the stories it believes worthy of reporting, and doing it in ways that illuminate what’s really happening.</p><p>Robert Reich, a former US secretary of labor, is a professor of public policy at the University of California, Berkeley, and the author of <a href="https://bookshop.org/books/saving-capitalism-for-the-many-not-the-few/9780345806222">Saving Capitalism: For the Many, Not the Few</a> and <a href="https://bookshop.org/books/the-common-good-9780525436379/9780525436379">The Common Good</a>. His newest book, <a href="https://bookshop.org/books/the-system-who-rigged-it-how-we-fix-it/9780525659044">The System: Who Rigged It, How We Fix I

## In Italy by Cynthia Zarin review – essays to bookmark with a train ticket stub
 - [https://www.theguardian.com/books/2023/dec/31/in-italy-venice-rome-and-beyond-by-cynthia-zarin-review-essays-to-bookmark-with-a-train-ticket-stub](https://www.theguardian.com/books/2023/dec/31/in-italy-venice-rome-and-beyond-by-cynthia-zarin-review-essays-to-bookmark-with-a-train-ticket-stub)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-12-31T11:00:02+00:00

<p>The American poet’s acutely observed writing about cities she has visited across 40 years is haunted by past lovers</p><p>The American poet Cynthia Zarin was 19 when she first travelled to Venice. The trip was a summer sojourn of sorts with “a boy I thought I might marry”, and the city turned out to be hot and expensive to room in. Zarin and her boyfriend stayed in a grotty boarding house in Padua and took the train to Venice one morning, planning to meet another friend of Zarin’s, who was also making a day trip from Florence. The couple ate veal sandwiches and idled around the steps of the Santa Maria della Salute, but Zarin soon wearied of her boyfriend’s chatter (“I did not want to hear any more about Savonarola”) and ended up arguing with him. Later, the boy was rude to Zarin’s friend from Florence. “To annoy me,” Zarin writes, “because I would not listen…”</p><p>In the opening essay of her new collection, <em>In Italy</em>, Zarin recalls this first encounter with Venice halfw

## ‘He had a sensitive soul’: inside Silvio Berlusconi’s bizarre art collection
 - [https://www.theguardian.com/world/2023/dec/31/silvio-berlusconi-art-collection-italy-lucas-vianini-curator](https://www.theguardian.com/world/2023/dec/31/silvio-berlusconi-art-collection-italy-lucas-vianini-curator)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-12-31T09:48:16+00:00

<p>During the final years of his life, the former Italian premier amassed thousands of ‘mostly worthless’ works from late-night shopping channels. Lucas Vianini became their curator</p><p>Lucas Vianini was presenting what he described as “a very suggestive” painting of a grieving Virgin Mary on a late-night shopping channel when the art expert received a call from a keen buyer.</p><p>It was not uncommon to receive prank calls when presenting paintings during the live TV auctions. So when the channel’s telephone operator told him that the buyer was called Silvio Berlusconi, he thought it was a joke.</p> <a href="https://www.theguardian.com/world/2023/dec/31/silvio-berlusconi-art-collection-italy-lucas-vianini-curator">Continue reading...</a>

## Enjoy a low-key reset after all the OTT fun | Funmi Fetto
 - [https://www.theguardian.com/lifeandstyle/2023/dec/31/enjoy-a-low-key-reset-after-all-the-ott-fun](https://www.theguardian.com/lifeandstyle/2023/dec/31/enjoy-a-low-key-reset-after-all-the-ott-fun)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-12-31T08:00:56+00:00

<p>Start the year with a clean slate and opt for a minimal look through the dark weeks of January</p><p>I don’t really believe in new year resolutions – too fickle, too much pressure. However, I do believe in a reset. After a season of sparkle and OTT maquillage for endless events, a clean, minimal approach to makeup can be a breath of fresh air. Also, if you intend to be out or up late to ring in 2024 (good for you!), the last thing you want is an elaborate makeup look that takes ages to wash off when you are finally able to slide into bed. Happy New Year.</p><p><strong>1. U Beauty The Super Tinted Hydrator</strong> £98, <a href="https://www.cultbeauty.co.uk/">cultbeauty.co.uk</a> <br /><strong>2. Max Factor 2000 Calorie Brow Gel</strong> £9.99, <a href="https://www.boots.com/">boots.com</a> <br /><strong>3. Tula Radiant Skin Brightening Serum Concealer</strong> £25, <a href="https://www.tula.com/">tula.com </a><br /><strong>4. Westman Atelier Eye Want You Mascara</strong> £42, <a h

## Simone Lia: Endings – cartoon
 - [https://www.theguardian.com/lifeandstyle/picture/2023/dec/31/simone-lia-endings-cartoon](https://www.theguardian.com/lifeandstyle/picture/2023/dec/31/simone-lia-endings-cartoon)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-12-31T08:00:56+00:00

<a href="https://www.theguardian.com/lifeandstyle/picture/2023/dec/31/simone-lia-endings-cartoon">Continue reading...</a>

## The conflict between history and memory lies at the heart of today’s cultural divides | Kenan Malik
 - [https://www.theguardian.com/commentisfree/2023/dec/31/arno-mayer-conflict-between-history-and-memory-lies-at-heart-of-todays-cultural-divides](https://www.theguardian.com/commentisfree/2023/dec/31/arno-mayer-conflict-between-history-and-memory-lies-at-heart-of-todays-cultural-divides)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-12-31T07:30:55+00:00

In his willingness to provoke unorthodox thinking, Arno Mayer, who died this month, was one of our most vital historians<p>The difference between the study of history and the construction of public memory, the American historian Arno Mayer observed, is that “whereas the voice of memory is univocal and uncontested, that of history is polyphonic and open to debate”. Memory, he added, “tends to rigidify over time, while history calls for revision”.</p><p>When Mayer died earlier <a href="https://history.princeton.edu/news-events/news/arno-mayer-passes-away" title="">this month</a>, his death was barely marked in the media. Yet, in an age in which the clash between history and memory lies at the heart of much political conflict, from culture war debates over statues and slavery to the confrontation between the origin stories of Jews and Palestinians, Mayer’s work remains indispensable in making sense not just of where we are, but also of how we got here.</p> <a href="https://www.theguardi

## How many daughters does a man need to see date rape jokes as a sackable offence? | Catherine Bennett
 - [https://www.theguardian.com/commentisfree/2023/dec/31/rishi-sunak-how-many-daughters-before-take-date-rape-jokes-seriously](https://www.theguardian.com/commentisfree/2023/dec/31/rishi-sunak-how-many-daughters-before-take-date-rape-jokes-seriously)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-12-31T07:00:56+00:00

Despite Rishi Sunak using his girls to show his grasp of women’s rights, he still brushed James Cleverly’s spiking gag aside<p>In his time in office, Rishi Sunak has done much to popularise an intensifier favoured by men wanting to advertise their commitment to women’s interests while effacing any earlier indifference: “As a father of daughters.”</p><p>Without his in-house epiphanies, Sunak might never have <a href="https://x.com/RishiSunak/status/1605572798075871232?s=20" title="">understood, “as a father to daughters”,</a> the need for girls to feel safe walking around in the evening or to be educated to the same extent as boys. Which is disturbing, but still. Better late, etc. His daughters are credited, too, in Sunak’s tribute to the Lionesses’ victories and with – “women’s rights are personal to me” – his appreciating the need for women’s single-sex spaces.</p> <a href="https://www.theguardian.com/commentisfree/2023/dec/31/rishi-sunak-how-many-daughters-before-take-date-rape-jok

## Smiles all round as financial markets end 2023 on an unexpected high
 - [https://www.theguardian.com/business/2023/dec/31/smiles-all-round-as-financial-markets-end-2023-on-an-unexpected-high](https://www.theguardian.com/business/2023/dec/31/smiles-all-round-as-financial-markets-end-2023-on-an-unexpected-high)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-12-31T07:00:56+00:00

<p>Equities worldwide have had a good year, the pound looks healthy and gold is positively gleaming. Shame about the lacklustre state of most UK shares</p><p>Global financial markets confounded gloomy expectations in 2023. Stocks rallied, and bonds reversed heavy losses made early in the year as recession fears were replaced by growing confidence that US policymakers would achieve an economic soft landing.</p><p>Many major share indices recorded double-digit gains during the year, helped by a strong rally in November and December as falling inflation made traders more hopeful of an interest rate cut in 2024.</p> <a href="https://www.theguardian.com/business/2023/dec/31/smiles-all-round-as-financial-markets-end-2023-on-an-unexpected-high">Continue reading...</a>

## I campervanned across Ireland alone – and climbed as many mountains as I could
 - [https://www.theguardian.com/travel/2023/dec/31/i-campervanned-across-ireland-alone-and-climbed-as-many-mountains-as-i-could](https://www.theguardian.com/travel/2023/dec/31/i-campervanned-across-ireland-alone-and-climbed-as-many-mountains-as-i-could)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-12-31T07:00:55+00:00

<p>Soon after a painful separation, this traveller had to overcome fears of solitude – but the mountains, seas and bars she found helped her let go</p><p><br />Voices outside the van woke me in the night. I lay still, my mind racing. There had been no one around when I parked at the end of a single track next to a wild beach. Campervanning alone as a woman was going to bring challenges, I knew, and sleeping in remote spots was high on the list of them.</p><p>Eventually an engine started, they drove off and there was silence. The next morning’s reward was a sunrise of shifting colours over a deserted beach in County Donegal – another new day all to myself to explore.</p> <a href="https://www.theguardian.com/travel/2023/dec/31/i-campervanned-across-ireland-alone-and-climbed-as-many-mountains-as-i-could">Continue reading...</a>

## What’s in store for 2024? Read our experts’ predictions, from Trump 2.0 to a super el Niño
 - [https://www.theguardian.com/world/2023/dec/31/whats-in-store-for-2024-read-expert-predictions-trump-el-nino](https://www.theguardian.com/world/2023/dec/31/whats-in-store-for-2024-read-expert-predictions-trump-el-nino)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-12-31T05:00:52+00:00

<p>Will KJ-T strike Olympic gold? Will Sunak go for an early election? How much will Taylor Swift fans bring to the UK economy? From tech to fashion, food to politics, the Observer’s top writers predict who and what will make the headlines</p><p><em>by Ellie Bramley</em></p> <a href="https://www.theguardian.com/world/2023/dec/31/whats-in-store-for-2024-read-expert-predictions-trump-el-nino">Continue reading...</a>

## Novak Djokovic calls for innovation but still in dark over LIV Golf-style tennis tour
 - [https://www.theguardian.com/sport/2023/dec/31/novak-djokovic-calls-for-innovation-but-still-in-dark-over-liv-golf-style-tennis-tour](https://www.theguardian.com/sport/2023/dec/31/novak-djokovic-calls-for-innovation-but-still-in-dark-over-liv-golf-style-tennis-tour)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-12-31T04:16:38+00:00

<ul><li>World No 1 says tennis needs to change amid rumours of rebel tour</li><li>Serbia star is in Perth for United Cup ahead of Australian Open</li></ul><p>World No 1 Novak Djokovic says tennis needs to innovate, but that he remains in the dark about a potential rebel tour.</p><p>Rumours are growing that a LIV Golf-style elite tennis tour could be launched, possibly as early as 2025, to rival the ATP and WTA tours.</p> <a href="https://www.theguardian.com/sport/2023/dec/31/novak-djokovic-calls-for-innovation-but-still-in-dark-over-liv-golf-style-tennis-tour">Continue reading...</a>

