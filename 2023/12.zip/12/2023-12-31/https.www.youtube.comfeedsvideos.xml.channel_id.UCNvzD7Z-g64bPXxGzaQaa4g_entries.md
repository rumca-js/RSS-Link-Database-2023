# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 HOLY SH*T In Game Moments in Recent Games
 - [https://www.youtube.com/watch?v=fxxP7L1xM2A](https://www.youtube.com/watch?v=fxxP7L1xM2A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2023-12-31T16:00:25+00:00

We have gotten some twists and turns in video games this year...without question.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

0:00 Intro
0:29 Number 10
1:45 Number 9
3:46 Number 8
5:36 Number 7
6:37 Number 6
8:11 Number 5
10:16 Number 4
11:49 Number 3 
13:18 Number 2 
14:44 Number 1

