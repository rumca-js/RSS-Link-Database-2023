# Source:NY times technology, URL:https://rss.nytimes.com/services/xml/rss/nyt/Technology.xml, language:en-US

## A 9-Month Cruise Is TikTok’s Favorite New ‘Reality Show’
 - [https://www.nytimes.com/2023/12/31/travel/tiktok-royal-caribbean-cruise.html](https://www.nytimes.com/2023/12/31/travel/tiktok-royal-caribbean-cruise.html)
 - RSS feed: https://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-12-31T10:02:00+00:00

Social media users, gripped by the potential for drama on Royal Caribbean’s world cruise, have turned the ship’s unwitting passengers into “cast members” overnight.

## How Tracking and Technology in Cars Is Being Weaponized by Abusive Partners
 - [https://www.nytimes.com/2023/12/31/technology/car-trackers-gps-abuse.html](https://www.nytimes.com/2023/12/31/technology/car-trackers-gps-abuse.html)
 - RSS feed: https://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-12-31T08:00:23+00:00

Apps that remotely track and control cars are being weaponized by abusive partners. Car manufacturers have been slow to respond, according to victims and experts.

