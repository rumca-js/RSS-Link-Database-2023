# Source:Seth's Blog, URL:https://seths.blog/feed, language:en-US

## On choosing a college
 - [https://seths.blog/2023/12/on-choosing-a-college](https://seths.blog/2023/12/on-choosing-a-college)
 - RSS feed: https://seths.blog/feed
 - date published: 2023-12-31T09:47:00+00:00

For some fortunate 17 year olds, the end of the year is the day for a momentous decision, one that&#8217;s largely out of the comfort zone of a 17 year old. A four-year college education in the US can cost nearly half a million dollars once we count the expenses and foregone opportunities that go [&#8230;]

