# Source:Wydarzenia Interia - Polska, URL:https://wydarzenia.interia.pl/polska/feed, language:pl-PL

## Atak hakerów na COS OPO. Wyciekły dane klientów
 - [https://wydarzenia.interia.pl/kraj/news-atak-hakerow-na-cos-opo-wyciekly-dane-klientow,nId,7241592](https://wydarzenia.interia.pl/kraj/news-atak-hakerow-na-cos-opo-wyciekly-dane-klientow,nId,7241592)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-12-31T17:54:50+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-atak-hakerow-na-cos-opo-wyciekly-dane-klientow,nId,7241592"><img align="left" alt="Atak hakerów na COS OPO. Wyciekły dane klientów " src="https://i.iplsc.com/atak-hakerow-na-cos-opo-wyciekly-dane-klientow/000IBBNAQ5KFG1PJ-C321.jpg" /></a>W Centralnym Ośrodku Sportu Ośrodku Przygotowań Olimpijskim w Zakopanem doszło do hakerskiego. Władze ośrodka poinformowały, że wykradzione mogły zostać prywatne dane klientów i gości ośrodka. Złodzieje mogli uzyskać dostęp do imion, nazwisk, numerów PESEL, adresów zamieszkania, adresów e-mail i numerów telefonu.
</p><br clear="all" />

## Sylwester: Tej nocy baluje cały świat. W których miastach bawić się w Polsce?
 - [https://wydarzenia.interia.pl/ciekawostki/news-sylwester-tej-nocy-baluje-caly-swiat-w-ktorych-miastach-bawi,nId,7235706](https://wydarzenia.interia.pl/ciekawostki/news-sylwester-tej-nocy-baluje-caly-swiat-w-ktorych-miastach-bawi,nId,7235706)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-12-31T08:00:00+00:00

<p><a href="https://wydarzenia.interia.pl/ciekawostki/news-sylwester-tej-nocy-baluje-caly-swiat-w-ktorych-miastach-bawi,nId,7235706"><img align="left" alt="Sylwester: Tej nocy baluje cały świat. W których miastach bawić się w Polsce?" src="https://i.iplsc.com/sylwester-tej-nocy-baluje-caly-swiat-w-ktorych-miastach-bawi/000IAT9GB16TKGLM-C321.jpg" /></a>Ostatni dzień roku popularnie nazywany jest sylwestrem. Świętujemy wtedy koniec starego roku i początek nowego. Robimy tak już od 999 roku, choć niektórzy sylwestrową tradycję wywodzą z antycznych Dionizjów. Ten wieczór jest pełen muzyki, tańca i fajerwerków. Gdzie odbędą się w Polsce największe plenerowe zabawy sylwestrowe? Wybór jest mniejszy niż w ubiegłych latach. </p><br clear="all" />

## Zima blisko, ale nie w sylwestra. Pogoda spłata figla
 - [https://wydarzenia.interia.pl/kraj/news-zima-blisko-ale-nie-w-sylwestra-pogoda-splata-figla,nId,7241423](https://wydarzenia.interia.pl/kraj/news-zima-blisko-ale-nie-w-sylwestra-pogoda-splata-figla,nId,7241423)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-12-31T07:36:20+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-zima-blisko-ale-nie-w-sylwestra-pogoda-splata-figla,nId,7241423"><img align="left" alt="Zima blisko, ale nie w sylwestra. Pogoda spłata figla" src="https://i.iplsc.com/zima-blisko-ale-nie-w-sylwestra-pogoda-splata-figla/000IB9JSSYGCCQM1-C321.jpg" /></a>Pogoda w sylwestra i Nowy rok powita nas wiosenną aurą. W części kraju prognozowane są opady deszczu, jednak nigdzie termometry nie wskażą ujemnych wartości. W rejonach górskich należy spodziewać się mocniejszych podmuchów wiatru, dochodzących do 70 km/h. Jak wskazują prognozy pogody, wszystko zmieni się jednak w styczniu, kiedy odczujemy powrót zimy.</p><br clear="all" />

## RCB alarmuje. "Pod żadnym pozorem"
 - [https://wydarzenia.interia.pl/kraj/news-rcb-alarmuje-pod-zadnym-pozorem,nId,7241417](https://wydarzenia.interia.pl/kraj/news-rcb-alarmuje-pod-zadnym-pozorem,nId,7241417)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-12-31T07:14:39+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-rcb-alarmuje-pod-zadnym-pozorem,nId,7241417"><img align="left" alt="RCB alarmuje. &quot;Pod żadnym pozorem&quot;" src="https://i.iplsc.com/rcb-alarmuje-pod-zadnym-pozorem/000IB9JT10WLANF5-C321.jpg" /></a>W związku z sylwestrem Rządowe Centrum Bezpieczeństwa wystosowało komunikat ostrzegający przed zagrożeniami. Zwraca się w nim uwagę na spożywanie alkoholu, odpalanie fajerwerków oraz na ochronę zwierząt. &quot;Jeżeli odpalasz fajerwerki, rób to ostrożnie i stosuj się do instrukcji. Zapewnij bezpieczeństwo i spokój swoim zwierzętom i nie wsiadaj za kierownicę po spożyciu alkoholu&quot; - apeluje RCB.</p><br clear="all" />

