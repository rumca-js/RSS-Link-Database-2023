# Source:Techradar, URL:https://www.techradar.com/rss, language:en-US

## The top spec OnePlus 12 phone may not be available to everyone
 - [https://www.techradar.com/phones/oneplus-phones/the-top-spec-oneplus-12-phone-may-not-be-available-to-everyone](https://www.techradar.com/phones/oneplus-phones/the-top-spec-oneplus-12-phone-may-not-be-available-to-everyone)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-12-31T17:30:36+00:00

It looks as though those outside China will miss out on the OnePlus 12 model with the most RAM and storage.

## Some of the Samsung Galaxy S24's key AI features just leaked
 - [https://www.techradar.com/phones/samsung-galaxy-phones/some-of-the-samsung-galaxy-s24s-key-ai-features-just-leaked](https://www.techradar.com/phones/samsung-galaxy-phones/some-of-the-samsung-galaxy-s24s-key-ai-features-just-leaked)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-12-31T13:30:28+00:00

Earlier rumors suggested that the Galaxy S24 series would go big on AI, and now we've got some more details.

## Tech Resolutions 2024 – 14 inspiring ways to boost your life with tech this year
 - [https://www.techradar.com/tech/tech-resolutions-2024](https://www.techradar.com/tech/tech-resolutions-2024)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-12-31T13:00:11+00:00

Looking to upgrade your tech life in 2024? Here are 14 ways the TechRadar team is doing it – and how you can do the same.

## AMD in 2023: year in review
 - [https://www.techradar.com/computing/gpu/amd-in-2023-year-in-review](https://www.techradar.com/computing/gpu/amd-in-2023-year-in-review)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-12-31T11:30:14+00:00

We examine AMD’s year, including a renewed push with AI, and some excellent introductions on the CPU and GPU fronts.

## Quordle today – hints and answers for Sunday, December 31 (game #706)
 - [https://www.techradar.com/computing/websites-apps/quordle-today-answers-clues-31-december-2023](https://www.techradar.com/computing/websites-apps/quordle-today-answers-clues-31-december-2023)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-12-31T00:15:07+00:00

Looking for Quordle clues? We can help. Plus get the answers to Quordle today and past solutions.

