# Source:RMF24.pl, URL:https://www.rmf24.pl/feed, language:pl

## Wszystkiego najlepszego w 2024 roku!
 - [https://www.rmf24.pl/fakty/polska/news-wszystkiego-najlepszego-w-2024-roku,nId,7241611](https://www.rmf24.pl/fakty/polska/news-wszystkiego-najlepszego-w-2024-roku,nId,7241611)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-31T23:00:00+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-wszystkiego-najlepszego-w-2024-roku,nId,7241611"><img align="left" alt="Wszystkiego najlepszego w 2024 roku!" src="https://interia-s.pluscdn.pl/wszystkiego-najlepszego-w-2024-roku/000IBBVAX78J3RMS-C307.jpg" /></a>Miliardy ludzi na świecie przywitały już 2024 rok. Również w Polsce - równo o północy - wystrzeliły korki od szampana, a na niebie rozbłysły fajerwerki. W ten sposób powitaliśmy Nowy Rok!</p><br clear="all" />

## Brytyjskie wielbłądy najlepsze w konkursie króla Arabii Saudyjskiej
 - [https://www.rmf24.pl/ciekawostki/news-brytyjskie-wielblady-najlepsze-w-konkursie-krola-arabii-saud,nId,7241615](https://www.rmf24.pl/ciekawostki/news-brytyjskie-wielblady-najlepsze-w-konkursie-krola-arabii-saud,nId,7241615)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-31T21:51:09+00:00

<p><a href="https://www.rmf24.pl/ciekawostki/news-brytyjskie-wielblady-najlepsze-w-konkursie-krola-arabii-saud,nId,7241615"><img align="left" alt="Brytyjskie wielbłądy najlepsze w konkursie króla Arabii Saudyjskiej" src="https://interia-s.pluscdn.pl/brytyjskie-wielblady-najlepsze-w-konkursie-krola-arabii-saud/000IBC2RI3U3U4WC-C307.jpg" /></a>W Arabii Saudyjskiej rozstrzygnięto konkurs &quot;wielbłądzich piękności&quot;. Rywalizację wierzchowców z garbem wygrali hodowcy z Wielkiej Brytanii.</p><br clear="all" />

## Kim Dzong Un: Nie będzie zjednoczenia z Koreą Południową
 - [https://www.rmf24.pl/fakty/swiat/news-kim-dzong-un-nie-bedzie-zjednoczenia-z-korea-poludniowa,nId,7241614](https://www.rmf24.pl/fakty/swiat/news-kim-dzong-un-nie-bedzie-zjednoczenia-z-korea-poludniowa,nId,7241614)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-31T21:17:24+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-kim-dzong-un-nie-bedzie-zjednoczenia-z-korea-poludniowa,nId,7241614"><img align="left" alt="Kim Dzong Un: Nie będzie zjednoczenia z Koreą Południową" src="https://interia-s.pluscdn.pl/kim-dzong-un-nie-bedzie-zjednoczenia-z-korea-poludniowa/000IBBYQD4IAS8PW-C307.jpg" /></a>Północnokoreański dyktator Kim Dzong Un ogłosił, że rządzone przez niego państwo nie będzie już dążyć do pojednania i zjednoczenia z Koreą Południową. Jak zapowiedział, w 2024 r. Korea Północna umieści na orbicie trzy nowe wojskowe satelity szpiegowskie.</p><br clear="all" />

## Ukraińcy zestrzeliwują "niezwyciężone" Kindżały. To zasługa systemów Patriot
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-ukraincy-zestrzeliwuja-niezwyciezone-kindzaly-to-zasluga-sys,nId,7241612](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-ukraincy-zestrzeliwuja-niezwyciezone-kindzaly-to-zasluga-sys,nId,7241612)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-31T20:34:54+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-ukraincy-zestrzeliwuja-niezwyciezone-kindzaly-to-zasluga-sys,nId,7241612"><img align="left" alt="Ukraińcy zestrzeliwują &quot;niezwyciężone&quot; Kindżały. To zasługa systemów Patriot" src="https://interia-s.pluscdn.pl/ukraincy-zestrzeliwuja-niezwyciezone-kindzaly-to-zasluga-sys/000IBBX1UJ4XFDII-C307.jpg" /></a>Armii ukraińskiej udaje się unieszkodliwiać rakiety balistyczne Kindżał odpalane z rosyjskich myśliwców. Skuteczną bronią na pociski wychwalane przez Kreml jako &quot;niezwyciężone&quot; są amerykańskie systemy antyrakietowe Patriot.</p><br clear="all" />

## 65-letni kierowca nie żyje. Wjechał autem pod szynobus
 - [https://www.rmf24.pl/regiony/warszawa/news-65-letni-kierowca-nie-zyje-wjechal-autem-pod-szynobus,nId,7241610](https://www.rmf24.pl/regiony/warszawa/news-65-letni-kierowca-nie-zyje-wjechal-autem-pod-szynobus,nId,7241610)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-31T19:56:42+00:00

<p><a href="https://www.rmf24.pl/regiony/warszawa/news-65-letni-kierowca-nie-zyje-wjechal-autem-pod-szynobus,nId,7241610"><img align="left" alt="65-letni kierowca nie żyje. Wjechał autem pod szynobus" src="https://interia-s.pluscdn.pl/65-letni-kierowca-nie-zyje-wjechal-autem-pod-szynobus/000IBBTW978IX5YE-C307.jpg" /></a>Do tragedii doszło w niedzielę wieczorem na niestrzeżonym przejeździe kolejowym w Płońsku (woj. mazowieckie). W wypadku zginął 65-letni męeżczyzna.</p><br clear="all" />

## Groził wysadzeniem bloku. Akcja antyterrorystów w Lublinie
 - [https://www.rmf24.pl/regiony/lublin/news-grozil-wysadzeniem-bloku-akcja-antyterrorystow-w-lublinie,nId,7241606](https://www.rmf24.pl/regiony/lublin/news-grozil-wysadzeniem-bloku-akcja-antyterrorystow-w-lublinie,nId,7241606)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-31T19:33:05+00:00

<p><a href="https://www.rmf24.pl/regiony/lublin/news-grozil-wysadzeniem-bloku-akcja-antyterrorystow-w-lublinie,nId,7241606"><img align="left" alt="Groził wysadzeniem bloku. Akcja antyterrorystów w Lublinie" src="https://interia-s.pluscdn.pl/grozil-wysadzeniem-bloku-akcja-antyterrorystow-w-lublinie/000IBBT4D81HCBIP-C307.jpg" /></a>Policyjni antyterroryści dokonali siłowego wejścia do mieszkania przy ul. Dożnkowej w Lublinie, zatrzymując przebywającego tam mężczyznę, który groził wysadzeniem budynku.</p><br clear="all" />

## Duda w orędziu uderza we władzę: Doszło do próby siłowego przejęcia mediów
 - [https://www.rmf24.pl/polityka/news-duda-w-oredziu-uderza-we-wladze-doszlo-do-proby-silowego-prz,nId,7241602](https://www.rmf24.pl/polityka/news-duda-w-oredziu-uderza-we-wladze-doszlo-do-proby-silowego-prz,nId,7241602)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-31T19:04:44+00:00

<p><a href="https://www.rmf24.pl/polityka/news-duda-w-oredziu-uderza-we-wladze-doszlo-do-proby-silowego-prz,nId,7241602"><img align="left" alt="Duda w orędziu uderza we władzę: Doszło do próby siłowego przejęcia mediów" src="https://interia-s.pluscdn.pl/duda-w-oredziu-uderza-we-wladze-doszlo-do-proby-silowego-prz/000IBBOENE1YS5AY-C307.jpg" /></a>&quot;Bezpieczeństwo Polski nie ma ceny, a dla mnie jest i będzie najważniejszą polską sprawą. Jako zwierzchnik Sił Zbrojnych jestem zawsze gotowy do współpracy z rządem w tematach dotyczących wzmacniania naszego bezpieczeństwa&quot; - powiedział w niedzielnym orędziu noworocznym prezydent Andrzej Duda.</p><br clear="all" />

## Piorun zabił mu rodzinę. Jechali na jego ślub
 - [https://www.rmf24.pl/fakty/swiat/news-piorun-zabil-mu-rodzine-jechali-na-jego-slub,nId,7241599](https://www.rmf24.pl/fakty/swiat/news-piorun-zabil-mu-rodzine-jechali-na-jego-slub,nId,7241599)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-31T18:34:05+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-piorun-zabil-mu-rodzine-jechali-na-jego-slub,nId,7241599"><img align="left" alt="Piorun zabił mu rodzinę. Jechali na jego ślub" src="https://interia-s.pluscdn.pl/piorun-zabil-mu-rodzine-jechali-na-jego-slub/000IBBQDFTVY7545-C307.jpg" /></a>Ojciec, dziadkowie, kuzyni, wujkowie i ciotki – razem 16 osób – zginęli od pioruna, gdy jechali na ślub 21-letniego Mamuna. O tragedii, która rozegrała się w Bangladeszu,  pisze na stronie internetowej stacja BBC.</p><br clear="all" />

## Królowa Danii Małgorzata II podjęła decyzję o abdykacji
 - [https://www.rmf24.pl/fakty/swiat/news-krolowa-danii-malgorzata-ii-podjela-decyzje-o-abdykacji,nId,7241586](https://www.rmf24.pl/fakty/swiat/news-krolowa-danii-malgorzata-ii-podjela-decyzje-o-abdykacji,nId,7241586)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-31T17:33:26+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-krolowa-danii-malgorzata-ii-podjela-decyzje-o-abdykacji,nId,7241586"><img align="left" alt="Królowa Danii Małgorzata II podjęła decyzję o abdykacji" src="https://interia-s.pluscdn.pl/krolowa-danii-malgorzata-ii-podjela-decyzje-o-abdykacji/000IBBKG2100WNKT-C307.jpg" /></a>Królowa Danii Małgorzata II podjęła decyzję o abdykacji, która nastąpi 14 stycznia 2024 roku. Monarchini przekazała tę informację w niedzielnym przemówieniu noworocznym.</p><br clear="all" />

## Niemowlę z pękniętą czaszką trafiło do szpitala. Zatrzymano rodziców
 - [https://www.rmf24.pl/regiony/poznan/news-niemowle-z-peknieta-czaszka-trafilo-do-szpitala-zatrzymano-r,nId,7241569](https://www.rmf24.pl/regiony/poznan/news-niemowle-z-peknieta-czaszka-trafilo-do-szpitala-zatrzymano-r,nId,7241569)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-31T16:43:52+00:00

<p><a href="https://www.rmf24.pl/regiony/poznan/news-niemowle-z-peknieta-czaszka-trafilo-do-szpitala-zatrzymano-r,nId,7241569"><img align="left" alt="Niemowlę z pękniętą czaszką trafiło do szpitala. Zatrzymano rodziców" src="https://interia-s.pluscdn.pl/niemowle-z-peknieta-czaszka-trafilo-do-szpitala-zatrzymano-r/000IBBH5W63YM8BU-C307.jpg" /></a>Dwumiesięczna dziewczynka w poważnym stanie trafiła do szpitala, dziecko ma pękniętą czaszkę. W związku z tą sprawą policja zatrzymała rodziców dziewczynki.</p><br clear="all" />

## Atak hakerski na ośrodek olimpijski. Mogło dojść do wycieku danych
 - [https://www.rmf24.pl/regiony/zakopane/news-atak-hakerski-na-osrodek-olimpijski-moglo-dojsc-do-wycieku-d,nId,7241572](https://www.rmf24.pl/regiony/zakopane/news-atak-hakerski-na-osrodek-olimpijski-moglo-dojsc-do-wycieku-d,nId,7241572)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-31T16:43:49+00:00

<p><a href="https://www.rmf24.pl/regiony/zakopane/news-atak-hakerski-na-osrodek-olimpijski-moglo-dojsc-do-wycieku-d,nId,7241572"><img align="left" alt="Atak hakerski na ośrodek olimpijski. Mogło dojść do wycieku danych" src="https://interia-s.pluscdn.pl/atak-hakerski-na-osrodek-olimpijski-moglo-dojsc-do-wycieku-d/000IBBIIT0HGUVX0-C307.jpg" /></a>W Centralnym Ośrodku Sportu - Ośrodku Przygotowań Olimpijskich (COS - OPO) w Zakopanem doszło do ataku hakerskiego na infrastrukturę sieciową – poinformowały władze obiektu. Mogły zostać wykradzione dane osobowe, w tym imiona i nazwiska, numery PESEL, adresy, numery telefonów, a także numery NIP i REGON oraz rachunków bankowych.</p><br clear="all" />

## Putin w orędziu: Nie ma na świecie siły, która mogłaby nas zatrzymać
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-putin-w-oredziu-nie-ma-na-swiecie-sily-ktora-moglaby-nas-zat,nId,7241567](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-putin-w-oredziu-nie-ma-na-swiecie-sily-ktora-moglaby-nas-zat,nId,7241567)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-31T16:22:16+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-putin-w-oredziu-nie-ma-na-swiecie-sily-ktora-moglaby-nas-zat,nId,7241567"><img align="left" alt="Putin w orędziu: Nie ma na świecie siły, która mogłaby nas zatrzymać" src="https://interia-s.pluscdn.pl/putin-w-oredziu-nie-ma-na-swiecie-sily-ktora-moglaby-nas-zat/000IBBEWCNAHI42X-C307.jpg" /></a>Prezydent Rosji Władimir Putin wygłosił przemówienie noworoczne, które po południu czasu moskiewskiego po raz pierwszy wyemitowano w telewizji na Dalekim Wschodzie kraju. Orędzie jaskrawo kontrastuje z zeszłorocznym przemówieniem - choć rosyjski przywódca chwalił swoich żołnierzy za odwagę, to głównie podkreślał jedność i determinację Rosjan.</p><br clear="all" />

## Mistrzyni świata w kolarstwie nie żyje. Mąż podejrzany o spowodowanie śmierci
 - [https://www.rmf24.pl/sport/news-mistrzyni-swiata-w-kolarstwie-nie-zyje-maz-podejrzany-o-spow,nId,7241565](https://www.rmf24.pl/sport/news-mistrzyni-swiata-w-kolarstwie-nie-zyje-maz-podejrzany-o-spow,nId,7241565)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-31T16:14:30+00:00

<p><a href="https://www.rmf24.pl/sport/news-mistrzyni-swiata-w-kolarstwie-nie-zyje-maz-podejrzany-o-spow,nId,7241565"><img align="left" alt="Mistrzyni świata w kolarstwie nie żyje. Mąż podejrzany o spowodowanie śmierci" src="https://interia-s.pluscdn.pl/mistrzyni-swiata-w-kolarstwie-nie-zyje-maz-podejrzany-o-spow/000IBBIB3N15O129-C307.jpg" /></a>Nie żyje była mistrzyni świata w kolarstwie torowym. 32-letnia Melissa Dennis z Australii zmarła w wyniku potrącenia przez samochód. Sprawcą wypadku był jej mąż.</p><br clear="all" />

## Zabójstwo biegacza. Ciało olimpijczyka znaleziono w samochodzie
 - [https://www.rmf24.pl/sport/news-zabojstwo-biegacza-cialo-olimpijczyka-znaleziono-w-samochodz,nId,7241561](https://www.rmf24.pl/sport/news-zabojstwo-biegacza-cialo-olimpijczyka-znaleziono-w-samochodz,nId,7241561)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-31T15:48:20+00:00

<p><a href="https://www.rmf24.pl/sport/news-zabojstwo-biegacza-cialo-olimpijczyka-znaleziono-w-samochodz,nId,7241561"><img align="left" alt="Zabójstwo biegacza. Ciało olimpijczyka znaleziono w samochodzie" src="https://interia-s.pluscdn.pl/zabojstwo-biegacza-cialo-olimpijczyka-znaleziono-w-samochodz/000IBBBF7RA5W50J-C307.jpg" /></a>Zwłoki uczestnika Igrzysk Olimpijskich w biegach długodystansowych odkryła w niedzielę rano policja na przedmieściach miasta Ekdoret w Kenii. Według śledczych 34-letni ​Benjamin Kiplagat z Ugandy padł ofiarą zabójstwa - na szyi zmarłego sportowca stwierdzono głęboką ranę kłutą szyi. </p><br clear="all" />

## Pożar w centrum Białogardu. 20 Filipińczyków straciło dach nad głową
 - [https://www.rmf24.pl/regiony/szczecin/news-pozar-w-centrum-bialogardu-20-filipinczykow-stracilo-dach-na,nId,7241560](https://www.rmf24.pl/regiony/szczecin/news-pozar-w-centrum-bialogardu-20-filipinczykow-stracilo-dach-na,nId,7241560)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-31T15:47:36+00:00

<p><a href="https://www.rmf24.pl/regiony/szczecin/news-pozar-w-centrum-bialogardu-20-filipinczykow-stracilo-dach-na,nId,7241560"><img align="left" alt="Pożar w centrum Białogardu. 20 Filipińczyków straciło dach nad głową" src="https://interia-s.pluscdn.pl/pozar-w-centrum-bialogardu-20-filipinczykow-stracilo-dach-na/000IBBC09IW099K2-C307.jpg" /></a>W wyniku pożaru przy placu Wolności w Białogardzie około 20 obywateli Filipin, pracujących w okolicznych firmach, straciło dach nad głową - przekazał za pośrednictwem mediów społecznościowych starosta białogardzki Piotr Pakuszto.</p><br clear="all" />

## Strażacy wyłowili kobietę z Warty. Nie udało się jej uratować
 - [https://www.rmf24.pl/regiony/poznan/news-strazacy-wylowili-kobiete-z-warty-nie-udalo-sie-jej-uratowac,nId,7241554](https://www.rmf24.pl/regiony/poznan/news-strazacy-wylowili-kobiete-z-warty-nie-udalo-sie-jej-uratowac,nId,7241554)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-31T15:30:31+00:00

<p><a href="https://www.rmf24.pl/regiony/poznan/news-strazacy-wylowili-kobiete-z-warty-nie-udalo-sie-jej-uratowac,nId,7241554"><img align="left" alt="Strażacy wyłowili kobietę z Warty. Nie udało się jej uratować" src="https://interia-s.pluscdn.pl/strazacy-wylowili-kobiete-z-warty-nie-udalo-sie-jej-uratowac/000IBB9WO3A9FEPC-C307.jpg" /></a>Z Warty w wielkopolskim Kole wyłowiono w niedzielę kobietę. Niestety, mimo podjętych czynności reanimacyjnych jej życia nie udało się uratować.</p><br clear="all" />

## Z Warty wyciągnięto ciało kobiety. Nie udało jej się uratować
 - [https://www.rmf24.pl/regiony/poznan/news-z-warty-wyciagnieto-cialo-kobiety-nie-udalo-jej-sie-uratowac,nId,7241554](https://www.rmf24.pl/regiony/poznan/news-z-warty-wyciagnieto-cialo-kobiety-nie-udalo-jej-sie-uratowac,nId,7241554)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-31T15:30:31+00:00

<p><a href="https://www.rmf24.pl/regiony/poznan/news-z-warty-wyciagnieto-cialo-kobiety-nie-udalo-jej-sie-uratowac,nId,7241554"><img align="left" alt="Z Warty wyciągnięto ciało kobiety. Nie udało jej się uratować" src="https://interia-s.pluscdn.pl/z-warty-wyciagnieto-cialo-kobiety-nie-udalo-jej-sie-uratowac/000IBB9WO3A9FEPC-C307.jpg" /></a>Z Warty w wielkopolskim Kole wyłowiono w niedzielę ciało kobiety. Niestety, mimo podjętych czynności reanimacyjnych jej życia nie udało się uratować.</p><br clear="all" />

## Z Warty wyłowiono ciało kobiety. Dramat w wielkopolskim Kole
 - [https://www.rmf24.pl/regiony/poznan/news-z-warty-wylowiono-cialo-kobiety-dramat-w-wielkopolskim-kole,nId,7241554](https://www.rmf24.pl/regiony/poznan/news-z-warty-wylowiono-cialo-kobiety-dramat-w-wielkopolskim-kole,nId,7241554)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-31T15:30:31+00:00

<p><a href="https://www.rmf24.pl/regiony/poznan/news-z-warty-wylowiono-cialo-kobiety-dramat-w-wielkopolskim-kole,nId,7241554"><img align="left" alt="Z Warty wyłowiono ciało kobiety. Dramat w wielkopolskim Kole" src="https://interia-s.pluscdn.pl/z-warty-wylowiono-cialo-kobiety-dramat-w-wielkopolskim-kole/000IBB9WO3A9FEPC-C307.jpg" /></a>Z Warty w wielkopolskim Kole wyłowiono w niedzielę kobietę. Niestety, mimo podjętych czynności reanimacyjnych jej życia nie udało się uratować.</p><br clear="all" />

## Opozycja chce wygaszenia mandatu senatorskiego Adama Bodnara
 - [https://www.rmf24.pl/polityka/news-opozycja-chce-wygaszenia-mandatu-senatorskiego-adama-bodnara,nId,7241550](https://www.rmf24.pl/polityka/news-opozycja-chce-wygaszenia-mandatu-senatorskiego-adama-bodnara,nId,7241550)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-31T14:57:34+00:00

<p><a href="https://www.rmf24.pl/polityka/news-opozycja-chce-wygaszenia-mandatu-senatorskiego-adama-bodnara,nId,7241550"><img align="left" alt="Opozycja chce wygaszenia mandatu senatorskiego Adama Bodnara" src="https://interia-s.pluscdn.pl/opozycja-chce-wygaszenia-mandatu-senatorskiego-adama-bodnara/000IBB93RTUUNQSR-C307.jpg" /></a>Posłowie opozycji, Marcin Romanowski i Maria Kurowska (obydwoje z Suwerennej Polski) wystąpili do marszałek Senatu Małgorzaty Kidawy-Błońskiej o wygaszenie mandatu senatorskiego ministra sprawiedliwości i prokuratora generalnego Adama Bodnara. Jak uzasadnili, ma to związek z doniesieniami medialnymi, według których szef MS przejął sprawy cywilne, rejestrowe związane ze zmianą kierownictwa w mediach publicznych.</p><br clear="all" />

## Bez fajerwerków w Rosji po śmiercionośnym ataku Ukraińców
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-bez-fajerwerkow-w-rosji-po-smiercionosnym-ataku-ukraincow,nId,7241525](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-bez-fajerwerkow-w-rosji-po-smiercionosnym-ataku-ukraincow,nId,7241525)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-31T14:26:34+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-bez-fajerwerkow-w-rosji-po-smiercionosnym-ataku-ukraincow,nId,7241525"><img align="left" alt="Bez fajerwerków w Rosji po śmiercionośnym ataku Ukraińców" src="https://interia-s.pluscdn.pl/bez-fajerwerkow-w-rosji-po-smiercionosnym-ataku-ukraincow/000IBAFHQH9SA1AF-C307.jpg" /></a>W sobotę po południu siły ukraińskie ostrzelały centrum przygranicznego rosyjskiego miasta Biełgorod. W ataku zginęły co najmniej 24 osoby, a 108 zostało rannych. Po ostrzale w kolejnych rosyjskich miastach zaczęto odwoływać sylwestrowe pokazy sztucznych ogni i zabawy.</p><br clear="all" />

## Turniej Czterech Skoczni. Łut szczęścia Piotra Żyły
 - [https://www.rmf24.pl/sport/news-turniej-czterech-skoczni-lut-szczescia-piotra-zyly,nId,7241540](https://www.rmf24.pl/sport/news-turniej-czterech-skoczni-lut-szczescia-piotra-zyly,nId,7241540)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-31T14:23:58+00:00

<p><a href="https://www.rmf24.pl/sport/news-turniej-czterech-skoczni-lut-szczescia-piotra-zyly,nId,7241540"><img align="left" alt="Turniej Czterech Skoczni. Łut szczęścia Piotra Żyły" src="https://interia-s.pluscdn.pl/turniej-czterech-skoczni-lut-szczescia-piotra-zyly/000IBB6P5V1KQ1UA-C307.jpg" /></a>Tylko dzięki dyskwalifikacji Domena Prevca ze Słowenii Piotr Żyła zakwalifikował się do noworocznych zawodów 72. Turnieju Czterech Skoczni w Garmisch-Partenkirchen. W rywalizacji o przebicie się do rundy finałowej Polak, który zajął 50. miejsce, zmierzy się z najlepszym w kwalifikacjach Anze Laniskiem. </p><br clear="all" />

## Nowa Zelandia już powitała nowy, 2024 rok!
 - [https://www.rmf24.pl/fakty/swiat/news-nowa-zelandia-juz-powitala-nowy-2024-rok,nId,7241524](https://www.rmf24.pl/fakty/swiat/news-nowa-zelandia-juz-powitala-nowy-2024-rok,nId,7241524)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-31T13:35:00+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-nowa-zelandia-juz-powitala-nowy-2024-rok,nId,7241524"><img align="left" alt="Nowa Zelandia już powitała nowy, 2024 rok! " src="https://interia-s.pluscdn.pl/nowa-zelandia-juz-powitala-nowy-2024-rok/000IBAA8Y9FCHCBL-C307.jpg" /></a>Nowa Zelandia powitała już 2024 rok. Zgodnie ze zwyczajem na słynnej Sky Tower w Auckland odbył się pokaz sztucznych ogni. To pierwsze na świecie duże miasto, które powitało Nowy Rok.</p><br clear="all" />

## Pamiętny 2023
 - [https://www.rmf24.pl/tylko-w-rmf24/tomasz-skory/komentarze/news-pamietny-2023,nId,7241520](https://www.rmf24.pl/tylko-w-rmf24/tomasz-skory/komentarze/news-pamietny-2023,nId,7241520)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-31T13:11:00+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/tomasz-skory/komentarze/news-pamietny-2023,nId,7241520"><img align="left" alt="SKORY NA BLOGU Pamiętny 2023" src="https://interia-s.pluscdn.pl/skory-na-blogu-pamietny-2023/000IBA8W0VD976A0-C307.jpg" /></a>Podsumowania i nadzieje na przyszłość to dość podstawowe tematy zajmujące nas w ostatnim dniu roku. Wydarzenia 2023 nie zachwycały treścią ani stylem i jego koniec raczej przyjmujemy z ulgą i nadzieją niż nostalgią.</p><br clear="all" />

## Tragedia koło Gliwic. W wypadku drogowym zginęły trzy osoby
 - [https://www.rmf24.pl/regiony/slaskie/news-tragedia-kolo-gliwic-w-wypadku-drogowym-zginely-trzy-osoby,nId,7241515](https://www.rmf24.pl/regiony/slaskie/news-tragedia-kolo-gliwic-w-wypadku-drogowym-zginely-trzy-osoby,nId,7241515)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-31T13:03:00+00:00

<p><a href="https://www.rmf24.pl/regiony/slaskie/news-tragedia-kolo-gliwic-w-wypadku-drogowym-zginely-trzy-osoby,nId,7241515"><img align="left" alt="Tragedia koło Gliwic. W wypadku drogowym zginęły trzy osoby" src="https://interia-s.pluscdn.pl/tragedia-kolo-gliwic-w-wypadku-drogowym-zginely-trzy-osoby/000IBA95UGP7W1CL-C307.jpg" /></a>Trzy osoby zginęły w wypadku drogowym w Żernicy w powiecie gliwickim w Śląskiem. Informację otrzymaliśmy na Gorącą Linię RMF FM - potwierdziły nam ją służby.</p><br clear="all" />

## Wypadek awionetki w Wielkopolsce. Dwie osoby ranne
 - [https://www.rmf24.pl/regiony/poznan/news-wypadek-awionetki-w-wielkopolsce-dwie-osoby-ranne,nId,7241504](https://www.rmf24.pl/regiony/poznan/news-wypadek-awionetki-w-wielkopolsce-dwie-osoby-ranne,nId,7241504)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-31T12:51:47+00:00

<p><a href="https://www.rmf24.pl/regiony/poznan/news-wypadek-awionetki-w-wielkopolsce-dwie-osoby-ranne,nId,7241504"><img align="left" alt="Wypadek awionetki w Wielkopolsce. Dwie osoby ranne" src="https://interia-s.pluscdn.pl/wypadek-awionetki-w-wielkopolsce-dwie-osoby-ranne/000IBA7NV6AUJ2QJ-C307.jpg" /></a>Dwie osoby zostały ranne w wyniku wypadku awionetki koło lotniska Oborniki-Słonawy w Wielkopolsce. &quot;Maszyna spadła na las około 500 metrów przed lądowiskiem&quot; - poinformował RMF FM mł. bryg. Leszek Walczak z PSP w Obornikach Wielkopolskich.</p><br clear="all" />

## Atak nożownika w Legnicy. Ranił dwie osoby, jedną ciężko
 - [https://www.rmf24.pl/regiony/wroclaw/news-nozownik-zaatakowal-w-legnicy-dwie-osoby-jedna-z-nich-jest-w,nId,7241484](https://www.rmf24.pl/regiony/wroclaw/news-nozownik-zaatakowal-w-legnicy-dwie-osoby-jedna-z-nich-jest-w,nId,7241484)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-31T11:11:00+00:00

<p><a href="https://www.rmf24.pl/regiony/wroclaw/news-nozownik-zaatakowal-w-legnicy-dwie-osoby-jedna-z-nich-jest-w,nId,7241484"><img align="left" alt="Atak nożownika w Legnicy. Ranił dwie osoby, jedną ciężko" src="https://interia-s.pluscdn.pl/atak-nozownika-w-legnicy-ranil-dwie-osoby-jedna-ciezko/000IB9ZDI8J3SP7T-C307.jpg" /></a>Policjanci zatrzymali 30-letniego mieszkańca Legnicy, który uszkodził 5 samochodów przy ul. Złotego Florena w Legnicy. W toku czynności okazało się, że mężczyzna w nocy ranił dwie osoby. Jedna osoba w stanie ciężkim trafiła do szpitala - powiedziała kom. Jagoda Ekiert z KMP w Legnicy.</p><br clear="all" />

## RCB ostrzega przed zagrożeniami w sylwestra. O tym musimy pamiętać
 - [https://www.rmf24.pl/fakty/polska/news-rcb-ostrzega-przed-zagrozeniami-w-sylwestra-o-tym-musimy-pam,nId,7241463](https://www.rmf24.pl/fakty/polska/news-rcb-ostrzega-przed-zagrozeniami-w-sylwestra-o-tym-musimy-pam,nId,7241463)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-31T09:59:53+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-rcb-ostrzega-przed-zagrozeniami-w-sylwestra-o-tym-musimy-pam,nId,7241463"><img align="left" alt="RCB ostrzega przed zagrożeniami w sylwestra. O tym musimy pamiętać" src="https://interia-s.pluscdn.pl/rcb-ostrzega-przed-zagrozeniami-w-sylwestra-o-tym-musimy-pam/000IB9TYJLFDII3U-C307.jpg" /></a>Jeżeli odpalasz fajerwerki, rób to ostrożnie i stosuj się do instrukcji. Zapewnij bezpieczeństwo i spokój swoim zwierzętom i nie wsiadaj za kierownicę po spożyciu alkoholu - apeluje Rządowe Centrum Bezpieczeństwa.</p><br clear="all" />

## Śląskie: Leżał na jezdni, zginął pod kołami samochodu
 - [https://www.rmf24.pl/regiony/slaskie/news-lezal-na-jezdni-zginal-pod-kolami-samochodu-koszmarny-wypade,nId,7241458](https://www.rmf24.pl/regiony/slaskie/news-lezal-na-jezdni-zginal-pod-kolami-samochodu-koszmarny-wypade,nId,7241458)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-31T09:34:13+00:00

<p><a href="https://www.rmf24.pl/regiony/slaskie/news-lezal-na-jezdni-zginal-pod-kolami-samochodu-koszmarny-wypade,nId,7241458"><img align="left" alt="Śląskie: Leżał na jezdni, zginął pod kołami samochodu" src="https://interia-s.pluscdn.pl/slaskie-lezal-na-jezdni-zginal-pod-kolami-samochodu/000IB9TDGJ9PSTSJ-C307.jpg" /></a>Tragedia koło Lublińca w Śląskiem. W nocy na jednej z lokalnych dróg kobieta jadąca samochodem osobowym najechała na leżącego na jedni mężczyznę. </p><br clear="all" />

## 34 nowe miasta w Polsce od 1 stycznia. Sprawdź listę
 - [https://www.rmf24.pl/fakty/polska/news-34-nowe-miasta-w-polsce-od-1-stycznia-sprawdz-liste,nId,7239991](https://www.rmf24.pl/fakty/polska/news-34-nowe-miasta-w-polsce-od-1-stycznia-sprawdz-liste,nId,7239991)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-31T09:00:00+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-34-nowe-miasta-w-polsce-od-1-stycznia-sprawdz-liste,nId,7239991"><img align="left" alt="34 nowe miasta w Polsce od 1 stycznia. Sprawdź listę" src="https://interia-s.pluscdn.pl/34-nowe-miasta-w-polsce-od-1-stycznia-sprawdz-liste/000IB7J4P390COEY-C307.jpg" /></a>1 stycznia 2024 roku to dla 34 miejscowości w Polsce dzień otrzymania statusu miasta. Najwięcej takich lokalizacji jest na Mazowszu (11) i w Łódzkiem (8), najmniej (1) - w Lubuskiem, Opolskiem i Śląskiem.</p><br clear="all" />

## Sondaż RMF FM: Gdzie spędzimy sylwestra?
 - [https://www.rmf24.pl/fakty/polska/news-sondaz-rmf-fm-gdzie-spedzimy-sylwestra,nId,7241447](https://www.rmf24.pl/fakty/polska/news-sondaz-rmf-fm-gdzie-spedzimy-sylwestra,nId,7241447)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-31T08:51:00+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-sondaz-rmf-fm-gdzie-spedzimy-sylwestra,nId,7241447"><img align="left" alt="Sondaż RMF FM: Gdzie spędzimy sylwestra?" src="https://interia-s.pluscdn.pl/sondaz-rmf-fm-gdzie-spedzimy-sylwestra/000IB9OZLAOII40P-C307.jpg" /></a>Prawie 40 proc. słuchaczy RMF FM powita Nowy Rok w swoich czterech ścianach samotnie lub z innymi domownikami. Na &quot;domówce&quot; u przyjaciół ten czas spędzi 12 proc. ankietowanych - wynika z badań własnych Grupy RMF. Znacznie rzadziej będziemy się bawić w lokalu, na wyjeździe w kraju lub zagranicą. </p><br clear="all" />

## Tragiczny pożar DPS-u w Warszawie. Jedna osoba zginęła
 - [https://www.rmf24.pl/regiony/warszawa/news-tragiczny-pozar-dps-u-w-warszawie-jedna-osoba-zginela,nId,7241436](https://www.rmf24.pl/regiony/warszawa/news-tragiczny-pozar-dps-u-w-warszawie-jedna-osoba-zginela,nId,7241436)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-31T07:59:09+00:00

<p><a href="https://www.rmf24.pl/regiony/warszawa/news-tragiczny-pozar-dps-u-w-warszawie-jedna-osoba-zginela,nId,7241436"><img align="left" alt="Tragiczny pożar DPS-u w Warszawie. Jedna osoba zginęła " src="https://interia-s.pluscdn.pl/tragiczny-pozar-dps-u-w-warszawie-jedna-osoba-zginela/000IB9LKIMJUQ24F-C307.jpg" /></a>Nocny pożar Domu Pomocy Społecznej na Nowym Mieście w Warszawie. Jedna osoba zginęła, a kolejna trafiła do szpitala. Konieczna była ewakuacja 25 osób.</p><br clear="all" />

## Sylwester w krajach Europy - bez fajerwerków, ale z... winogronem
 - [https://www.rmf24.pl/fakty/swiat/news-bez-fajerwerkow-z-policyjna-ochrona-i-winogronem-sylwester-w,nId,7241421](https://www.rmf24.pl/fakty/swiat/news-bez-fajerwerkow-z-policyjna-ochrona-i-winogronem-sylwester-w,nId,7241421)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-31T07:44:00+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-bez-fajerwerkow-z-policyjna-ochrona-i-winogronem-sylwester-w,nId,7241421"><img align="left" alt="Sylwester w krajach Europy - bez fajerwerków, ale z... winogronem" src="https://interia-s.pluscdn.pl/sylwester-w-krajach-europy-bez-fajerwerkow-ale-z-winogronem/000IB9K2QSSMQU0I-C307.jpg" /></a>Wiele włoskich miast z zakazem odpalania petard, ale tylko na papierze. W Hiszpanii świętowanie będzie odbywało się głównie w turystycznych kurortach. Uczestnicy zabawy nowy rok przywitają m.in. jedząc winogrono na szczęście. We Francji porządku będzie pilnowało 90 tys. mundurowych. Dziś na portalu RMF24 sprawdzamy, jak będzie wyglądała sylwestrowa noc w europejskich krajach. </p><br clear="all" />

## Kolejne dwa kraje wejdą do strefy Schengen. Jest decyzja
 - [https://www.rmf24.pl/fakty/swiat/news-kolejne-dwa-kraje-wejda-do-strefy-schengen-jest-decyzja,nId,7241431](https://www.rmf24.pl/fakty/swiat/news-kolejne-dwa-kraje-wejda-do-strefy-schengen-jest-decyzja,nId,7241431)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-31T07:40:45+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-kolejne-dwa-kraje-wejda-do-strefy-schengen-jest-decyzja,nId,7241431"><img align="left" alt="Kolejne dwa kraje wejdą do strefy Schengen. Jest decyzja" src="https://interia-s.pluscdn.pl/kolejne-dwa-kraje-wejda-do-strefy-schengen-jest-decyzja/000IB9L0XGEPEV7B-C307.jpg" /></a>Rumunia i Bułgaria zostaną od 31 marca 2024 r. przyjęte do strefy Schengen. Ogłosiła to hiszpańska prezydencja w Radzie Unii Europejskiej.</p><br clear="all" />

## Mark Brzeziński: Mamy wspólne cele na arenie międzynarodowej
 - [https://www.rmf24.pl/fakty/swiat/news-mark-brzezinski-mamy-wspolne-cele-na-arenie-miedzynarodowej,nId,7235543](https://www.rmf24.pl/fakty/swiat/news-mark-brzezinski-mamy-wspolne-cele-na-arenie-miedzynarodowej,nId,7235543)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-31T07:01:20+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-mark-brzezinski-mamy-wspolne-cele-na-arenie-miedzynarodowej,nId,7235543"><img align="left" alt="TYLKO W RMF FM Mark Brzeziński: Mamy wspólne cele na arenie międzynarodowej" src="https://interia-s.pluscdn.pl/tylko-w-rmf-fm-mark-brzezinski-mamy-wspolne-cele-na-arenie-m/000IAQYN9Y4MUGMU-C307.jpg" /></a>&quot;Polska jest niezastąpionym sojusznikiem&quot; – mówi ambasador Stanów Zjednoczonych Mark Brzeziński w wypowiedzi dla RMF FM. &quot;W 2023 roku nasze relacje się rozwijały i jestem niezwykle dumny z pracy, jaką razem wykonaliśmy&quot; - mówi amerykański dyplomata. Podkreślił, że ważnym elementem współpracy były kwestie bezpieczeństwa. &quot;Mówiłem to wiele razy. Bezpieczna Polska to bezpieczne Stany Zjednoczone&quot; – dodał.  </p><br clear="all" />

## Okolice Doniecka i Charkowa pod rosyjskim ostrzałem [RELACJA]
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/na-zywo/news-okolice-doniecka-i-charkowa-pod-rosyjskim-ostrzalem-relacja,nId,7241429](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/na-zywo/news-okolice-doniecka-i-charkowa-pod-rosyjskim-ostrzalem-relacja,nId,7241429)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-31T07:00:00+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/na-zywo/news-okolice-doniecka-i-charkowa-pod-rosyjskim-ostrzalem-relacja,nId,7241429"><img align="left" alt="Okolice Doniecka i Charkowa pod rosyjskim ostrzałem [RELACJA] " src="https://interia-s.pluscdn.pl/okolice-doniecka-i-charkowa-pod-rosyjskim-ostrzalem-relacja/000IB9LYUYCT5AWQ-C307.jpg" /></a>7 osób zginęło, a 12 zostało rannych w wyniku rosyjskich ataków w obwodach donieckim i charkowskim w ciągu ostatniej doby. 21 z 49 rosyjskich dronów udało się zniszczyć ukraińskiemu wojsku. Niedziela jest 676. dniem rosyjskiej agresji na Ukrainę. Najważniejsze informacje zbieramy w naszej relacji z 31.12.2023 r.</p><br clear="all" />

## Zełenski: Kto sprowadzi piekło na naszą ziemię, zobaczy je ze swojego okna [ZAPIS RELACJI]
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/na-zywo/news-zelenski-kto-sprowadzi-pieklo-na-nasza-ziemie-zobaczy-je-ze-,nId,7241429](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/na-zywo/news-zelenski-kto-sprowadzi-pieklo-na-nasza-ziemie-zobaczy-je-ze-,nId,7241429)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-31T07:00:00+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/na-zywo/news-zelenski-kto-sprowadzi-pieklo-na-nasza-ziemie-zobaczy-je-ze-,nId,7241429"><img align="left" alt="Zełenski: Kto sprowadzi piekło na naszą ziemię, zobaczy je ze swojego okna [ZAPIS RELACJI] " src="https://interia-s.pluscdn.pl/zelenski-kto-sprowadzi-pieklo-na-nasza-ziemie-zobaczy-je-ze/000IB9LYUYCT5AWQ-C307.jpg" /></a>7 osób zginęło, a 12 zostało rannych w wyniku rosyjskich ataków w obwodach donieckim i charkowskim w ciągu ostatniej doby. 21 z 49 rosyjskich dronów udało się zniszczyć ukraińskiemu wojsku. Niedziela jest 676. dniem rosyjskiej agresji na Ukrainę. Najważniejsze informacje zbieramy w naszej relacji z 31.12.2023 r.</p><br clear="all" />

## 800 plus wchodzi w życie. Pierwsze przelewy już na kontach rodziców
 - [https://www.rmf24.pl/ekonomia/news-800-plus-wchodzi-w-zycie-pierwsze-przelewy-juz-na-kontach-ro,nId,7241419](https://www.rmf24.pl/ekonomia/news-800-plus-wchodzi-w-zycie-pierwsze-przelewy-juz-na-kontach-ro,nId,7241419)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-31T06:23:12+00:00

<p><a href="https://www.rmf24.pl/ekonomia/news-800-plus-wchodzi-w-zycie-pierwsze-przelewy-juz-na-kontach-ro,nId,7241419"><img align="left" alt="800 plus wchodzi w życie. Pierwsze przelewy już na kontach rodziców" src="https://interia-s.pluscdn.pl/800-plus-wchodzi-w-zycie-pierwsze-przelewy-juz-na-kontach-ro/000IB9HH7J3TUTJB-C307.jpg" /></a>Od 1 stycznia 2024 r. kwota świadczenia wychowawczego zostanie podniesiona z 500 zł do 800 zł. Rodzice otrzymają wypłaty w tych samych terminach, co dotychczas. Według rządowych szacunków w 2024 r. do 800 plus będzie uprawnionych 6,6 mln dzieci.</p><br clear="all" />

## ​Przed nami rok długich weekendów! Sprawdź szczegóły
 - [https://www.rmf24.pl/fakty/polska/news-przed-nami-rok-dlugich-weekendow-sprawdz-szczegoly,nId,7240050](https://www.rmf24.pl/fakty/polska/news-przed-nami-rok-dlugich-weekendow-sprawdz-szczegoly,nId,7240050)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2023-12-31T05:15:00+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-przed-nami-rok-dlugich-weekendow-sprawdz-szczegoly,nId,7240050"><img align="left" alt="​Przed nami rok długich weekendów! Sprawdź szczegóły" src="https://interia-s.pluscdn.pl/przed-nami-rok-dlugich-weekendow-sprawdz-szczegoly/000IB831NL0AFA5U-C307.jpg" /></a>Wiele możliwości przedłużania weekendów szykuje się w nowym 2024 roku. Nasz dziennikarz przeanalizował kalendarz właśnie pod tym kątem.</p><br clear="all" />

