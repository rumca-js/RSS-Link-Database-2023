# Source:Ryan George, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ, language:en-US

## The First Guy To Ever Make A New Year's Resolution
 - [https://www.youtube.com/watch?v=byauTRO4t30](https://www.youtube.com/watch?v=byauTRO4t30)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ
 - date published: 2023-12-31T20:48:15+00:00

Happy New Year, and thanks for all your support in 2023! :)

Hi there hello please click the subscribe button and turn on notifications so I can feed my cats and dog.
Twitter/Instagram: @TheRyanGeorge

