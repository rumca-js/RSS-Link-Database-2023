# Source:CBC | Top Stories News, URL:https://www.cbc.ca/webfeed/rss/rss-topstories, language:en

## Israeli siblings freed from Hamas describe passing notes, painful surgeries during captivity
 - [https://www.cbc.ca/news/world/israel-siblings-hamas-israel-1.7071981?cmp=rss](https://www.cbc.ca/news/world/israel-siblings-hamas-israel-1.7071981?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-12-31T17:07:28+00:00

<img alt="A patient in a hospital bed reaches up to embrace a person standing beside them." height="349" src="https://i.cbc.ca/1.7071984.1704057496!/fileImage/httpImage/image.JPG_gen/derivatives/16x9_620/israel-palestinians-hostages.JPG" title="FILE PHOTO: Itay Regev, 18, is reunited with his sister Maya Regev, 21, shortly after his arrival in Israel after being held hostage by the Palestinian militant group Hamas in the Gaza Strip, at Soroka Medical Center in Beersheba, Israel, in this handout image obtained by Reuters on November 30, 2023. Maya was also held hostage in Gaza and was released days before Itay. Prime Minister&apos;s Office/handout via Reuters THIS IMAGE HAS BEEN SUPPLIED BY A THIRD PARTY/File Photo" width="620" /><p>The Regev siblings were among more than 100 hostages freed during a weeklong ceasefire in late November.</p>

## Canada reaches quarter-finals of world junior hockey championship
 - [https://www.cbc.ca/sports/hockey/world-juniors-canada-germany-dec-31-recap-1.7071827?cmp=rss](https://www.cbc.ca/sports/hockey/world-juniors-canada-germany-dec-31-recap-1.7071827?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-12-31T16:29:39+00:00

<img alt="A men&apos;s hockey player celebrates a goal while a goaltender in the background looks dejected." height="349" src="https://i.cbc.ca/1.7071948.1704058061!/fileImage/httpImage/image.JPG_gen/derivatives/16x9_620/hko-world-juniors-canada-germany-20231231.JPG" title="Canada&apos;s Macklin Celebrini (17) celebrates a goal on Germany&apos;s Matthias Bittner (1) during a 6-3 win at the IIHF World Junior Hockey Championship in Gothenburg, Sweden, on Sunday." width="620" /><p>Jordan Dumais scored the winner on a power play in the third period and Macklin Celebrini had two goals of his own as Canada beat Germany 6-3 to wrap up the preliminary round at the world junior hockey championship in unimpressive fashion Sunday in Gothenburg, Sweden.</p>

## Denmark's monarch to step down on Jan. 14
 - [https://www.cbc.ca/news/world/denmark-queen-margrethe-abdication-1.7071921?cmp=rss](https://www.cbc.ca/news/world/denmark-queen-margrethe-abdication-1.7071921?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-12-31T14:25:13+00:00

<img alt="A woman wearing a red hat and glasses waves." height="349" src="https://i.cbc.ca/1.7071922.1704047309!/fileImage/httpImage/image.JPG_gen/derivatives/16x9_620/denmark-royals-queen.JPG" title="Danish Queen Margrethe visits Lynge school during a city visit in Alleroed Municipality, Denmark September 12, 2023.    " width="620" /><p>Denmark's Queen Margrethe II, Europe's longest-serving monarch, will abdicate on Jan. 14 after 52 years on the throne and will be succeeded by her eldest son, Crown Prince Frederik, she announced on Sunday.</p>

## U.S. helicopters kill several Houthi rebels in latest Red Sea shipping attack
 - [https://www.cbc.ca/news/world/red-sea-houthi-pirate-united-states-navy-1.7071869?cmp=rss](https://www.cbc.ca/news/world/red-sea-houthi-pirate-united-states-navy-1.7071869?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-12-31T12:30:33+00:00

<img alt="A U.S. sailor stands watch with binoculars on a ship sailing behind an aircraft carrier." height="349" src="https://i.cbc.ca/1.7071885.1704042127!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/persian-gulf-tensions.jpg" title="The aircraft carrier USS Dwight D. Eisenhower and other warships crosses the Strait of Hormuz into the Persian Gulf on Sunday, Nov. 26, 2023, as part of a wider American deployment in the Middle East amid the Israel-Hamas war. The Eisenhower was accompanied by the guided-missile cruiser USS Philippine Sea, the guided-missile destroyers USS Gravely and the USS Stethem and the French frigate Languedoc. " width="620" /><p>The U.S. military said Sunday that its forces opened fire on Houthi rebels after they attacked a cargo ship in the Red Sea, killing several of them in an escalation of the maritime conflict linked to the war in Gaza.</p>

## Russia launches new wave of drone and missile strikes on Kharkiv, Ukraine
 - [https://www.cbc.ca/news/world/russia-ukraine-kharkiv-1.7071810?cmp=rss](https://www.cbc.ca/news/world/russia-ukraine-kharkiv-1.7071810?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-12-31T08:41:37+00:00

<img alt="A man clears broken glass in a storefront." height="349" src="https://i.cbc.ca/1.7071811.1704023400!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/russia-ukraine-war.jpg" title="In this photo provided by Kharkiv Regional Administration, a man clears broken glass in a storefront after a Russian missile attack in Kharkiv, Ukraine, Sunday, Dec. 31, 2023. (Kharkiv Regional Administration via AP)" width="620" /><p>Russia on Sunday said it attacked military facilities in the Ukrainian city of Kharkiv overnight, including a hotel housing military commanders and "foreign mercenaries," in response to Ukraine's strikes on Belgorod the previous day.</p>

## Each year I give my mom, who has Alzheimer's, a calendar she can't use
 - [https://www.cbc.ca/news/canada/ottawa/alzheimer-calendar-first-person-ottawa-1.7058367?cmp=rss](https://www.cbc.ca/news/canada/ottawa/alzheimer-calendar-first-person-ottawa-1.7058367?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-12-31T04:00:00+00:00

<img alt="An illustration of a mother, daughter and a calendar." height="349" src="https://i.cbc.ca/1.7064334.1703019867!/fileImage/httpImage/image.jpeg_gen/derivatives/16x9_620/alzheimers-calendar-illustration.jpeg" title="Despite the fact that her mother can no longer use the annual calendar gift, Nicole Robichaud continues the tradition of buying her one each year in hopes that at some level that cannot be seen, the gift communicates the love that went into it, and connects her mom to the family&apos;s traditions at this time of year." width="620" /><p>Nicole Robichaud writes about why her first Christmas shopping item each year is a folk art calendar for her mom, even though she can't use it with her declining health and memory.</p>

## For 100 years, this Mickey Mouse operation has thrived. Is Disney now losing its magic?
 - [https://www.cbc.ca/radio/sunday/disney-at-100-1.7066511?cmp=rss](https://www.cbc.ca/radio/sunday/disney-at-100-1.7066511?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-12-31T04:00:00+00:00

<img alt="Mickey and Minnie mouse wave to the crowd." height="349" src="https://i.cbc.ca/1.7068055.1703267236!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/mickey-and-minnie-mouse.jpg" title="URAYASU, JAPAN - JANUARY 17: Actors dressed as Walt Disney characters Minnie Mouse (L) and Mickey Mouse (R) perform during a press preview for the &quot;Minnie Besties Bash!&quot; parade at Tokyo DisneySea on January 17, 2023 in Urayasu, Japan. The special event is held for 73 days from January 18 to March 31. (Photo by Tomohiro Ohsumi/Getty Images)" width="620" /><p>From box office flops to a shifting media landscape, Disney's brand has taken a beating. But with its theme parks doing booming business, perhaps the Magic Kingdom still has a few cards up its sleeve.</p>

## Seniors housing in Toronto has a language problem. Experts say it's getting more urgent
 - [https://www.cbc.ca/news/canada/toronto/seniors-housing-in-toronto-has-a-language-problem-experts-say-it-s-getting-more-urgent-1.7056619?cmp=rss](https://www.cbc.ca/news/canada/toronto/seniors-housing-in-toronto-has-a-language-problem-experts-say-it-s-getting-more-urgent-1.7056619?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-12-31T04:00:00+00:00

<img alt="Young person holding the hand of an older person, who is holding a cane." height="349" src="https://i.cbc.ca/1.5778838.1704012984!/cumulusImage/httpImage/image.jpg_gen/derivatives/16x9_620/doctor-holding-a-senior-patients-s-hand.jpg" title="Doctor holding a senior patient&apos;s hand on a walking stick — special medical care concept for Alzheimer &apos;s syndrome." width="620" /><p>Great strides have been made in seniors housing, experts say, but communication remains a struggle — one that requires urgent attention as Canada’s immigrant population ages.</p>

