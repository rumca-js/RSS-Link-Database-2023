# Source:Wydarzenia Interia, URL:https://wydarzenia.interia.pl/feed, language:pl-PL

## Witamy Nowy Rok. Przemowy i życzenia światowych przywódców
 - [https://wydarzenia.interia.pl/kraj/news-witamy-nowy-rok-przemowy-i-zyczenia-swiatowych-przywodcow,nId,7241617](https://wydarzenia.interia.pl/kraj/news-witamy-nowy-rok-przemowy-i-zyczenia-swiatowych-przywodcow,nId,7241617)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-31T23:00:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-witamy-nowy-rok-przemowy-i-zyczenia-swiatowych-przywodcow,nId,7241617"><img align="left" alt="Witamy Nowy Rok. Przemowy i życzenia światowych przywódców" src="https://i.iplsc.com/witamy-nowy-rok-przemowy-i-zyczenia-swiatowych-przywodcow/000IBC35T3YL5UX5-C321.jpg" /></a>Polska, wraz z wieloma europejskimi krajami, powitała Nowy Rok. Wcześniej 2024 rok rozpoczął się w Azji, na świętowanie czekają wciąż z kolei obie Ameryki. W Polsce sylwestrową zabawę poprzedziły dwa orędzia - premiera i prezydenta. Podobnie było w wielu innych państwach, gdzie przywódcy podsumowywali wydarzenia, mówili o wyzwaniach i składali życzenia. Jakie tematy dominowały? Wojna w Ukrainie i na Bliskim Wschodzie, wybory czy... niespodziewana abdykacja.</p><br clear="all" />

## Burza w sieci po orędziu Dudy. Komentujący o Konstytucji i łamaniu prawa
 - [https://wydarzenia.interia.pl/kraj/news-burza-w-sieci-po-oredziu-dudy-komentujacy-o-konstytucji-i-la,nId,7241613](https://wydarzenia.interia.pl/kraj/news-burza-w-sieci-po-oredziu-dudy-komentujacy-o-konstytucji-i-la,nId,7241613)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-31T21:52:58+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-burza-w-sieci-po-oredziu-dudy-komentujacy-o-konstytucji-i-la,nId,7241613"><img align="left" alt="Burza w sieci po orędziu Dudy. Komentujący o Konstytucji i łamaniu prawa" src="https://i.iplsc.com/burza-w-sieci-po-oredziu-dudy-komentujacy-o-konstytucji-i-la/000IBC088HRDKR49-C321.jpg" /></a>&quot;Twarde słowa z prezydenckiego orędzia brzmiałyby znacznie mocniej i wiarygodniej, gdybyśmy wcześniej słyszeli podobne wobec poprzedniego rządu, gdy deptał on standardy państwa prawa&quot; - ocenił orędzie prezydenta wicemarszałek Sejmu i polityk Konfederacji Krzysztof Bosak. Podobnych opinii nie brakuje - komentujący zarzucają prezydentowi, że w przeszłości sam nie dochował wierności przepisom ustawy zasadniczej. Są też odmienne głosy. &quot;I to było orędzie męża stanu&quot; - napisał były szef resortu dyplomacji Witold Waszczykowski.</p><br clear="all" />

## Błyskawiczna reakcja Donalda Tuska. Jest odpowiedź na orędzie prezydenta
 - [https://wydarzenia.interia.pl/kraj/news-blyskawiczna-reakcja-donalda-tuska-jest-odpowiedz-na-oredzie,nId,7241609](https://wydarzenia.interia.pl/kraj/news-blyskawiczna-reakcja-donalda-tuska-jest-odpowiedz-na-oredzie,nId,7241609)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-31T19:56:18+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-blyskawiczna-reakcja-donalda-tuska-jest-odpowiedz-na-oredzie,nId,7241609"><img align="left" alt="Błyskawiczna reakcja Donalda Tuska. Jest odpowiedź na orędzie prezydenta " src="https://i.iplsc.com/blyskawiczna-reakcja-donalda-tuska-jest-odpowiedz-na-oredzie/000IBBV078J3RO27-C321.jpg" /></a>&quot;Odchodzący 2023 rok był pełen cudów. Ostatni z nich to słowa z orędzia Prezydenta, że trzeba bronić Konstytucji&quot; - tak orędzie prezydenta Andrzeja Dudy skomentował premier Donald Tusk. &quot;Sylwester marzeń&quot; - skwitował. W wystąpieniu przywódca mówił o sporze wokół mediów publicznych i podkreślał, że &quot;trzeba przestrzegać Konstytucji&quot;, a nowa koalicja rządząca - jego zdaniem - &quot;złamała te zasady&quot;.</p><br clear="all" />

## Premier o cudzie w orędziu prezydenta. "Słowa, że trzeba bronić Konstytucji"
 - [https://wydarzenia.interia.pl/kraj/news-premier-o-cudzie-w-oredziu-prezydenta-slowa-ze-trzeba-bronic,nId,7241609](https://wydarzenia.interia.pl/kraj/news-premier-o-cudzie-w-oredziu-prezydenta-slowa-ze-trzeba-bronic,nId,7241609)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-31T19:56:18+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-premier-o-cudzie-w-oredziu-prezydenta-slowa-ze-trzeba-bronic,nId,7241609"><img align="left" alt="Premier o cudzie w orędziu prezydenta. &quot;Słowa, że trzeba bronić Konstytucji&quot;" src="https://i.iplsc.com/premier-o-cudzie-w-oredziu-prezydenta-slowa-ze-trzeba-bronic/000IBBV078J3RO27-C321.jpg" /></a>&quot;Odchodzący 2023 rok był pełen cudów. Ostatni z nich to słowa z orędzia prezydenta, że trzeba bronić Konstytucji&quot; - tak przemówienie Andrzeja Dudy skomentował premier Donald Tusk. &quot;Sylwester marzeń&quot; - skwitował szef rządu. W wystąpieniu przywódca Polski mówił o sporze wokół mediów publicznych i podkreślał, że &quot;trzeba przestrzegać Konstytucji&quot;, a nowa koalicja rządząca - jego zdaniem - &quot;złamała te zasady&quot;.</p><br clear="all" />

## Mężczyzna groził wysadzeniem bloku. Akcja policji w Lublinie
 - [https://wydarzenia.interia.pl/wiadomosci-lokalne/news-mezczyzna-grozil-wysadzeniem-bloku-akcja-policji-w-lublinie,nId,7241607](https://wydarzenia.interia.pl/wiadomosci-lokalne/news-mezczyzna-grozil-wysadzeniem-bloku-akcja-policji-w-lublinie,nId,7241607)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-31T19:45:21+00:00

<p><a href="https://wydarzenia.interia.pl/wiadomosci-lokalne/news-mezczyzna-grozil-wysadzeniem-bloku-akcja-policji-w-lublinie,nId,7241607"><img align="left" alt="Mężczyzna groził wysadzeniem bloku. Akcja policji w Lublinie" src="https://i.iplsc.com/mezczyzna-grozil-wysadzeniem-bloku-akcja-policji-w-lublinie/000IBBT29E7UML63-C321.jpg" /></a>Poszukiwany przez policję 30-latek groził w niedzielę wysadzeniem bloku przy ul. Dożynkowej w Lublinie. Mężczyzna zabarykadował się w mieszkaniu i groził, że zdetonuje granaty. Z budynku trzeba było ewakuować mieszkańców, a do akcji ruszyli kontrterroryści. </p><br clear="all" />

## Domniemany zamach na słynną katedrę w Niemczech. Akcja służb
 - [https://wydarzenia.interia.pl/zagranica/news-domniemany-zamach-na-slynna-katedre-w-niemczech-akcja-sluzb,nId,7241597](https://wydarzenia.interia.pl/zagranica/news-domniemany-zamach-na-slynna-katedre-w-niemczech-akcja-sluzb,nId,7241597)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-31T19:24:02+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-domniemany-zamach-na-slynna-katedre-w-niemczech-akcja-sluzb,nId,7241597"><img align="left" alt="Domniemany zamach na słynną katedrę w Niemczech. Akcja służb" src="https://i.iplsc.com/domniemany-zamach-na-slynna-katedre-w-niemczech-akcja-sluzb/000IBBS1PXL642YP-C321.jpg" /></a>Niemieckie służby zatrzymały trzy osoby, które podejrzewane są o planowanie ataku terrorystycznego na katedrę w Kolonii. Do prawdopodobnego zamachu miało dojść w sylwestrową noc, a aresztowanym posłużyć miał w tym celu samochód. Obecnie teren wokół słynnej świątyni jest intensywnie monitorowany.  Zatrzymani prawdopodobnie związani są z obywatelem Tadżykistanu, który nosił się z podobnymi zamiarami i został zatrzymany w wigilię Bożego Narodzenia.</p><br clear="all" />

## "Cyberprezent" od Ukraińców. Zablokowali terminale płatnicze w Rosji
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-cyberprezent-od-ukraincow-zablokowali-terminale-platnicze-w-,nId,7241604](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-cyberprezent-od-ukraincow-zablokowali-terminale-platnicze-w-,nId,7241604)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-31T19:11:40+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-cyberprezent-od-ukraincow-zablokowali-terminale-platnicze-w-,nId,7241604"><img align="left" alt="&quot;Cyberprezent&quot; od Ukraińców. Zablokowali terminale płatnicze w Rosji" src="https://i.iplsc.com/cyberprezent-od-ukraincow-zablokowali-terminale-platnicze-w/000IBBRRJSDF5ELS-C321.jpg" /></a>Ukraińska Armia IT zablokowała działanie terminali płatniczych w Rosji. Celem ataku został największy dostawca urządzeń w tym kraju - Evotor. O operacji hakerów poinformowało ukraińskie ministerstwo cyfryzacji. &quot;Noworoczny szał zakupów stał się prawdziwą zapaścią&quot; - napisał resort.</p><br clear="all" />

## Orędzie Andrzeja Dudy. Prezydent o zagrożeniach, które "nigdzie nie zniknęły"
 - [https://wydarzenia.interia.pl/kraj/news-oredzie-andrzeja-dudy-prezydent-o-zagrozeniach-ktore-nigdzie,nId,7241558](https://wydarzenia.interia.pl/kraj/news-oredzie-andrzeja-dudy-prezydent-o-zagrozeniach-ktore-nigdzie,nId,7241558)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-31T19:00:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-oredzie-andrzeja-dudy-prezydent-o-zagrozeniach-ktore-nigdzie,nId,7241558"><img align="left" alt="Orędzie Andrzeja Dudy. Prezydent o zagrożeniach, które &quot;nigdzie nie zniknęły&quot;" src="https://i.iplsc.com/oredzie-andrzeja-dudy-prezydent-o-zagrozeniach-ktore-nigdzie/000IBBR37HRH2WE9-C321.jpg" /></a>- Kończący się właśnie rok był rokiem zmiany w polskiej polityce. Po ośmiu latach zmieniła się w naszym kraju większość parlamentarna, zmienił się premier, zmienił się rząd. Ale nie zmieniło się najważniejsze zadanie, jakie stoi przed rządzącymi: to konieczność dbania o  bezpieczeństwo naszej ojczyzny, o bezpieczeństwo Polek i Polaków - rozpoczął swoje orędzie prezydent Polski Andrzej Duda. - Tak było w 2023 roku i dokładnie tak samo będzie w rozpoczynającym się właśnie 2024 roku - podkreślił, po czym dodał, że &quot;poważne zagrożenia zewnętrzne...</p><br clear="all" />

## Nieoczekiwana decyzja królowej Małgorzaty II. Sytuacja bez precedensu
 - [https://wydarzenia.interia.pl/zagranica/news-nieoczekiwana-decyzja-krolowej-malgorzaty-ii-sytuacja-bez-pr,nId,7241593](https://wydarzenia.interia.pl/zagranica/news-nieoczekiwana-decyzja-krolowej-malgorzaty-ii-sytuacja-bez-pr,nId,7241593)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-31T18:18:10+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-nieoczekiwana-decyzja-krolowej-malgorzaty-ii-sytuacja-bez-pr,nId,7241593"><img align="left" alt="Nieoczekiwana decyzja królowej Małgorzaty II. Sytuacja bez precedensu " src="https://i.iplsc.com/nieoczekiwana-decyzja-krolowej-malgorzaty-ii-sytuacja-bez-pr/000IBBMJBT7J51SY-C321.jpg" /></a>Królowa Danii Małgorzata II ogłosiła abdykację. O swej decyzji poinformowała niespodziewanie, w noworocznym orędziu. Do przekazania władzy 55-letniemu synowi Fryderykowi dojdzie 14 stycznia, dokładnie 52 lata po tym, jak monarchini zastąpiła na tronie swojego ojca.</p><br clear="all" />

## Kim Dzong Un o zjednoczeniu z Koreą Południową. Podjął ostateczną decyzję
 - [https://wydarzenia.interia.pl/zagranica/news-kim-dzong-un-o-zjednoczeniu-z-korea-poludniowa-podjal-ostate,nId,7241583](https://wydarzenia.interia.pl/zagranica/news-kim-dzong-un-o-zjednoczeniu-z-korea-poludniowa-podjal-ostate,nId,7241583)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-31T17:52:44+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-kim-dzong-un-o-zjednoczeniu-z-korea-poludniowa-podjal-ostate,nId,7241583"><img align="left" alt="Kim Dzong Un o zjednoczeniu z Koreą Południową. Podjął ostateczną decyzję" src="https://i.iplsc.com/kim-dzong-un-o-zjednoczeniu-z-korea-poludniowa-podjal-ostate/000IBBJB37RCBNAJ-C321.jpg" /></a>- Korea Północna nie będzie już dążyć do pojednania i zjednoczenia się z Koreą Południową - zadeklarował Kim Dzong Un. Stwierdził też, że dotychczasowe wysiłki mające na celu unormowanie relacji były &quot;błędem, którego nie można już popełniać&quot;. W przemówieniu stwierdził także, że wojna na Półwyspie Koreańskim może &quot;wybuchnąć w każdym momencie&quot;, po czym wskazał, kogo obwiniłby za eskalację.</p><br clear="all" />

## Azja i Australia witają rok 2024. Spektakularne pokazy sztucznych ogni
 - [https://wydarzenia.interia.pl/zagranica/news-azja-i-australia-witaja-rok-2024-spektakularne-pokazy-sztucz,nId,7241579](https://wydarzenia.interia.pl/zagranica/news-azja-i-australia-witaja-rok-2024-spektakularne-pokazy-sztucz,nId,7241579)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-31T17:06:32+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-azja-i-australia-witaja-rok-2024-spektakularne-pokazy-sztucz,nId,7241579"><img align="left" alt="Azja i Australia witają rok 2024. Spektakularne pokazy sztucznych ogni" src="https://i.iplsc.com/azja-i-australia-witaja-rok-2024-spektakularne-pokazy-sztucz/000IBBISU8NINSYI-C321.jpg" /></a>Rok 2024 przywitały już między innymi Australia i część Azji. Żeby uczcić nadejście nowego roku, Sydney, Tajpej oraz Hongkong przygotowały kilkunastominutowe pokazy sztucznych ogni. Na Tajwanie z mierzącego ponad 500 m wysokości wieżowca Taipei 101 odpalono 16 tys. ładunków pirotechnicznych. </p><br clear="all" />

## Kępno: Niemowlę w poważnym stanie trafiło do szpitala. Rodzice w areszcie
 - [https://wydarzenia.interia.pl/wielkopolskie/news-kepno-niemowle-w-powaznym-stanie-trafilo-do-szpitala-rodzice,nId,7241571](https://wydarzenia.interia.pl/wielkopolskie/news-kepno-niemowle-w-powaznym-stanie-trafilo-do-szpitala-rodzice,nId,7241571)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-31T16:53:03+00:00

<p><a href="https://wydarzenia.interia.pl/wielkopolskie/news-kepno-niemowle-w-powaznym-stanie-trafilo-do-szpitala-rodzice,nId,7241571"><img align="left" alt="Kępno: Niemowlę w poważnym stanie trafiło do szpitala. Rodzice w areszcie" src="https://i.iplsc.com/kepno-niemowle-w-powaznym-stanie-trafilo-do-szpitala-rodzice/000D5EFR2LTDCL3J-C321.jpg" /></a>Dwumiesięczna dziewczynka z poważnym urazem głowy trafiła do szpitala, a jej rodzice zostali zatrzymani w areszcie. Policja w Kępnie (woj. wielkopolskie) podejrzewa 19-letnią matkę i 30-letniego ojca o popełnienie przestępstwa wobec dziecka. Funkcjonariusze badają sprawę pod nadzorem prokuratora.</p><br clear="all" />

## Putin wygłosił orędzie noworoczne. "Nigdy się nie cofniemy"
 - [https://wydarzenia.interia.pl/zagranica/news-putin-wyglosil-oredzie-noworoczne-nigdy-sie-nie-cofniemy,nId,7241563](https://wydarzenia.interia.pl/zagranica/news-putin-wyglosil-oredzie-noworoczne-nigdy-sie-nie-cofniemy,nId,7241563)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-31T15:57:05+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-putin-wyglosil-oredzie-noworoczne-nigdy-sie-nie-cofniemy,nId,7241563"><img align="left" alt="Putin wygłosił orędzie noworoczne. &quot;Nigdy się nie cofniemy&quot;" src="https://i.iplsc.com/putin-wyglosil-oredzie-noworoczne-nigdy-sie-nie-cofniemy/000IBBC94A3LPRRK-C321.jpg" /></a>Władimir Putin wystąpił z orędziem noworocznym. Przywódca, który zapowiedział start w przyszłorocznych wyborach prezydenckich, nie wspomniał w przemówieniu o wojnie w Ukrainie. Ograniczył się jedynie do pochwalenia swoich żołnierzy, którzy według niego &quot;stoją na czele walki o wolność i sprawiedliwość&quot;.</p><br clear="all" />

## Wypadek awionetki. Samolot spadł na las
 - [https://wydarzenia.interia.pl/wielkopolskie/news-wypadek-awionetki-samolot-spadl-na-las,nId,7241545](https://wydarzenia.interia.pl/wielkopolskie/news-wypadek-awionetki-samolot-spadl-na-las,nId,7241545)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-31T14:41:06+00:00

<p><a href="https://wydarzenia.interia.pl/wielkopolskie/news-wypadek-awionetki-samolot-spadl-na-las,nId,7241545"><img align="left" alt="Wypadek awionetki. Samolot spadł na las" src="https://i.iplsc.com/wypadek-awionetki-samolot-spadl-na-las/000IBAGL6X9GJEBF-C321.jpg" /></a>W niedzielę po południu w powiecie obornickim doszło do groźnego wypadku awionetki. Samolot spadł na las około pół kilometra od lądowiska. W wyniku wypadku poszkodowane zostały dwie osoby: pilot oraz pasażer maszyny. </p><br clear="all" />

## W Berlinie spłonęły samochody. Policja bada sprawę
 - [https://wydarzenia.interia.pl/zagranica/news-w-berlinie-splonely-samochody-policja-bada-sprawe,nId,7241536](https://wydarzenia.interia.pl/zagranica/news-w-berlinie-splonely-samochody-policja-bada-sprawe,nId,7241536)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-31T14:08:22+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-w-berlinie-splonely-samochody-policja-bada-sprawe,nId,7241536"><img align="left" alt="W Berlinie spłonęły samochody. Policja bada sprawę" src="https://i.iplsc.com/w-berlinie-splonely-samochody-policja-bada-sprawe/000IBAETO0YS338S-C321.jpg" /></a>W kilku dzielnicach Berlina już dobę przed sylwestrem spłonęło kilka samochodów - poinformowała policja. Funkcjonariusze zakładają, że pojazdy zostały celowo podpalone. Dochodzenie w tej sprawie prowadzi specjalny wydział berlińskiej policji. Czy to przedsmak tegorocznego sylwestra? - zastanawia się portal dziennika &quot;Bild&quot;. </p><br clear="all" />

## "Ona żyje, ona żyje". Dramatyczna akcja ratunkowa
 - [https://wydarzenia.interia.pl/raport-wojna-w-izraelu/news-ona-zyje-ona-zyje-dramatyczna-akcja-ratunkowa,nId,7241505](https://wydarzenia.interia.pl/raport-wojna-w-izraelu/news-ona-zyje-ona-zyje-dramatyczna-akcja-ratunkowa,nId,7241505)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-31T13:56:11+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wojna-w-izraelu/news-ona-zyje-ona-zyje-dramatyczna-akcja-ratunkowa,nId,7241505"><img align="left" alt="&quot;Ona żyje, ona żyje&quot;. Dramatyczna akcja ratunkowa" src="https://i.iplsc.com/ona-zyje-ona-zyje-dramatyczna-akcja-ratunkowa/000IBAC98C014H6F-C321.jpg" /></a>- Ona żyje, ona żyje - krzyczały osoby, które odnalazły Talę Rouqah w gruzach budynku w mieście Rafah. Dziesięciomiesięczną dziewczynkę uratowano po izraelskim nalocie, w którym zginęło co najmniej 20 osób. Atak przeżył również ojciec - jej matka oraz rodzeństwo nie mieli tyle szczęścia.</p><br clear="all" />

## Co z Konkordatem? Jedna grupa wyborców wyraźnie zdecydowana
 - [https://wydarzenia.interia.pl/kraj/news-co-z-konkordatem-jedna-grupa-wyborcow-wyraznie-zdecydowana,nId,7241530](https://wydarzenia.interia.pl/kraj/news-co-z-konkordatem-jedna-grupa-wyborcow-wyraznie-zdecydowana,nId,7241530)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-31T13:42:37+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-co-z-konkordatem-jedna-grupa-wyborcow-wyraznie-zdecydowana,nId,7241530"><img align="left" alt="Co z Konkordatem? Jedna grupa wyborców wyraźnie zdecydowana" src="https://i.iplsc.com/co-z-konkordatem-jedna-grupa-wyborcow-wyraznie-zdecydowana/0005J2M0XHJC17TN-C321.jpg" /></a>W najnowszym sondażu Polki i Polaków zapytano &quot;czy zgadzają się ze stwierdzeniem, że nowy rząd powinien wypowiedzieć dotychczasowy Konkordat z Kościołem i negocjować zasady na linii państwo-Kościół na nowo?&quot;. 48,6 proc. ankietowanych odpowiedziało twierdząco, 33,1 proc. było odmiennego zdania. Przedstawiono również, jak odpowiadali wyborcy koalicji rządzącej i obecnej opozycji.</p><br clear="all" />

## Tysiące policjantów na ulicach. Francja i Niemcy szykują się na sylwestra
 - [https://wydarzenia.interia.pl/zagranica/news-tysiace-policjantow-na-ulicach-francja-i-niemcy-szykuja-sie-,nId,7241528](https://wydarzenia.interia.pl/zagranica/news-tysiace-policjantow-na-ulicach-francja-i-niemcy-szykuja-sie-,nId,7241528)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-31T13:37:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-tysiace-policjantow-na-ulicach-francja-i-niemcy-szykuja-sie-,nId,7241528"><img align="left" alt="Tysiące policjantów na ulicach. Francja i Niemcy szykują się na sylwestra" src="https://i.iplsc.com/tysiace-policjantow-na-ulicach-francja-i-niemcy-szykuja-sie/000IBAAW0UEESTP4-C321.jpg" /></a>Największe miasta w Niemczech i we Francji przygotowują się na noc sylwestrową. W tym celu na ulicach pojawią się setki dodatkowych policjantów. Policja obawia się nie tylko rozrób. W związku z trwającą w Izraelu wojną z Hamasem w obydwu państwach wzrosły obawy przed atakami terrorystycznymi.</p><br clear="all" />

## Tajemnicza "grupa Kakao". Hołownia wymienił trzech posłów
 - [https://wydarzenia.interia.pl/kraj/news-tajemnicza-grupa-kakao-holownia-wymienil-trzech-poslow,nId,7241503](https://wydarzenia.interia.pl/kraj/news-tajemnicza-grupa-kakao-holownia-wymienil-trzech-poslow,nId,7241503)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-31T13:31:40+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-tajemnicza-grupa-kakao-holownia-wymienil-trzech-poslow,nId,7241503"><img align="left" alt="Tajemnicza &quot;grupa Kakao&quot;. Hołownia wymienił trzech posłów" src="https://i.iplsc.com/tajemnicza-grupa-kakao-holownia-wymienil-trzech-poslow/000IA5BQ5MMDWGMR-C321.jpg" /></a>Tajemnicza &quot;grupa Kakao&quot; w Sejmie. O szczegółach w programie na żywo mówił marszałek Szymon Hołownia. W skład &quot;grupy&quot; ma wchodzić trzech polityków Suwerennej Polski. Jak ocenił lider Polski 2050, wspomniani posłowie &quot;dają do pieca&quot; w czasie obrad parlamentu.</p><br clear="all" />

## Wracali z Niemiec, oddali się przyjemności. Z auta uciekali w popłochu
 - [https://wydarzenia.interia.pl/zagranica/news-wracali-z-niemiec-oddali-sie-przyjemnosci-z-auta-uciekali-w-,nId,7241508](https://wydarzenia.interia.pl/zagranica/news-wracali-z-niemiec-oddali-sie-przyjemnosci-z-auta-uciekali-w-,nId,7241508)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-31T13:12:22+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wracali-z-niemiec-oddali-sie-przyjemnosci-z-auta-uciekali-w-,nId,7241508"><img align="left" alt="Wracali z Niemiec, oddali się przyjemności. Z auta uciekali w popłochu" src="https://i.iplsc.com/wracali-z-niemiec-oddali-sie-przyjemnosci-z-auta-uciekali-w/0003RBQRGTUTLIRB-C321.jpg" /></a>Niebezpieczna sytuacja w Holandii. - Nagle nastąpił bardzo duży wybuch. Szybko zatrzymaliśmy samochód i wysiedliśmy z niego - relacjonował 21-letni mężczyzna, który wraz z kolegą wybrał się do Niemiec po fajerwerki. W drodze powrotnej zapalili papierosa, a wiatr wrzucił niedopałek z powrotem do auta. Na tylnym siedzeniu znajdowało się około 75 kilogramów kolorowych petard.</p><br clear="all" />

## Donald Tusk apeluje i pokazuje film. "Zdecydowanie odradzam"
 - [https://wydarzenia.interia.pl/kraj/news-donald-tusk-apeluje-i-pokazuje-film-zdecydowanie-odradzam,nId,7241483](https://wydarzenia.interia.pl/kraj/news-donald-tusk-apeluje-i-pokazuje-film-zdecydowanie-odradzam,nId,7241483)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-31T12:40:06+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-donald-tusk-apeluje-i-pokazuje-film-zdecydowanie-odradzam,nId,7241483"><img align="left" alt="Donald Tusk apeluje i pokazuje film. &quot;Zdecydowanie odradzam&quot;" src="https://i.iplsc.com/donald-tusk-apeluje-i-pokazuje-film-zdecydowanie-odradzam/000IBA216Q7VQ24D-C321.jpg" /></a>W związku z sylwestrem na profilu Donalda Tuska w mediach społecznościowych pojawił się specjalny komunikat. Na krótkim nagraniu szef rządu pojawił się z psem i zaapelował do Polaków przed wieczorną zabawą.</p><br clear="all" />

## Przekrzykiwali się nawzajem. W pewnym momencie polityk nie wytrzymał
 - [https://wydarzenia.interia.pl/kraj/news-przekrzykiwali-sie-nawzajem-w-pewnym-momencie-polityk-nie-wy,nId,7241489](https://wydarzenia.interia.pl/kraj/news-przekrzykiwali-sie-nawzajem-w-pewnym-momencie-polityk-nie-wy,nId,7241489)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-31T12:21:07+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-przekrzykiwali-sie-nawzajem-w-pewnym-momencie-polityk-nie-wy,nId,7241489"><img align="left" alt="Przekrzykiwali się nawzajem. W pewnym momencie polityk nie wytrzymał" src="https://i.iplsc.com/przekrzykiwali-sie-nawzajem-w-pewnym-momencie-polityk-nie-wy/000IBA0EHX9GH6C9-C321.jpg" /></a>Gorąca dyskusja między Jackiem Ozdobą a Markiem Sawickim. Tematem dyskusji były działania Bartłomieja Sienkiewicza związane z mediami publicznymi. W pewnej chwili politycy zaczęli się wzajemnie przekrzykiwać, na co musiał zareagować prowadzący. Spokój nie trwał jednak długo. - Z takim człowiekiem nie da się dyskutować. Proszę pana, odrobina wychowania i szacunku - rzucił w stronę polityka PiS Sawicki.</p><br clear="all" />

## Kreml nie szczędzi wysiłków. Poufne dokumenty o "komentarzu Francuza"
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-kreml-nie-szczedzi-wysilkow-poufne-dokumenty-o-komentarzu-fr,nId,7241474](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-kreml-nie-szczedzi-wysilkow-poufne-dokumenty-o-komentarzu-fr,nId,7241474)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-31T11:40:19+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-kreml-nie-szczedzi-wysilkow-poufne-dokumenty-o-komentarzu-fr,nId,7241474"><img align="left" alt="Kreml nie szczędzi wysiłków. Poufne dokumenty o &quot;komentarzu Francuza&quot;" src="https://i.iplsc.com/kreml-nie-szczedzi-wysilkow-poufne-dokumenty-o-komentarzu-fr/000IB9WD93KMIMK3-C321.jpg" /></a>Rosja stale zabiega o zniechęcenie zachodnich sojuszników w pomocy dla Ukrainy. &quot;The Washington Post&quot; dotarł do dokumentów Kremla, w których mowa jest o prowadzeniu dezinformacji we Francji. Rosyjscy urzędnicy poprosili o pomoc pracownika farmy trolli, któremu polecono napisanie &quot;200-znakowego komentarza Francuza w średnim wieku&quot;, w którym to stwierdza, że europejskie wsparcie dla Ukrainy jest &quot;głupią przygodą&quot;.</p><br clear="all" />

## Rosjanie zaskoczyli ekspertów. "Pierwszy taki przypadek w historii"
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rosjanie-zaskoczyli-ekspertow-pierwszy-taki-przypadek-w-hist,nId,7241460](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rosjanie-zaskoczyli-ekspertow-pierwszy-taki-przypadek-w-hist,nId,7241460)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-31T11:15:07+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rosjanie-zaskoczyli-ekspertow-pierwszy-taki-przypadek-w-hist,nId,7241460"><img align="left" alt="Rosjanie zaskoczyli ekspertów. &quot;Pierwszy taki przypadek w historii&quot;" src="https://i.iplsc.com/rosjanie-zaskoczyli-ekspertow-pierwszy-taki-przypadek-w-hist/000IB9ZFC70DXK0C-C321.jpg" /></a>Analitycy wojskowi są przekonani, że Rosjanie zmodyfikowali pociski manewrujące Ch-101 tak, by uruchamiać tzw. pułapki cieplne. W sieci pojawiło się nagranie, sugerujące wystrzelenie takich pułapek z rosyjskiego pocisku Ch-101 podczas ostatniego zmasowanego ataku na Ukrainę. Eksperci twierdzą, że jest to wersja produkcyjna Ch-101, która powstała przed lutym 2022 roku. </p><br clear="all" />

## Przez lata ukrywał mroczną tajemnicę. Śledczy mieli asa w rękawie
 - [https://wydarzenia.interia.pl/wielkopolskie/news-przez-lata-ukrywal-mroczna-tajemnice-sledczy-mieli-asa-w-rek,nId,7238028](https://wydarzenia.interia.pl/wielkopolskie/news-przez-lata-ukrywal-mroczna-tajemnice-sledczy-mieli-asa-w-rek,nId,7238028)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-31T11:02:56+00:00

<p><a href="https://wydarzenia.interia.pl/wielkopolskie/news-przez-lata-ukrywal-mroczna-tajemnice-sledczy-mieli-asa-w-rek,nId,7238028"><img align="left" alt="Przez lata ukrywał mroczną tajemnicę. Śledczy mieli asa w rękawie" src="https://i.iplsc.com/przez-lata-ukrywal-mroczna-tajemnice-sledczy-mieli-asa-w-rek/000IB0INFXHLK3RI-C321.jpg" /></a>Po obiedzie Zyta wychodzi na spacer, aby nazbierać wiosennych kwiatów. Sąsiadka dostrzega, że idzie w kierunku lasu. Kobieta jest ostatnią osobą, która widzi dziewczynę żywą. Następnego dnia mama Zyty znajdzie ciało swojej córki przykryte kurtką. Sprawca przez lata żyje spokojnie niedaleko domu rodzinnego zamordowanej kobiety, żeni się, zostaje ojcem. Minie 26 lat, zanim śledczy rozwiążą wstrząsającą zagadkę i zatrzymają zabójcę. </p><br clear="all" />

## Nagła zmiana planów. Chodzi o Radę Mediów Narodowych
 - [https://wydarzenia.interia.pl/kraj/news-nagla-zmiana-planow-chodzi-o-rade-mediow-narodowych,nId,7241468](https://wydarzenia.interia.pl/kraj/news-nagla-zmiana-planow-chodzi-o-rade-mediow-narodowych,nId,7241468)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-31T10:20:17+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-nagla-zmiana-planow-chodzi-o-rade-mediow-narodowych,nId,7241468"><img align="left" alt="Nagła zmiana planów. Chodzi o Radę Mediów Narodowych" src="https://i.iplsc.com/nagla-zmiana-planow-chodzi-o-rade-mediow-narodowych/000I7PW3QU1N70E2-C321.jpg" /></a>Niedzielne posiedzenie Rady Mediów Narodowych zostało odwołane - przekazała posłanka PiS i członkini RMN Joanna Lichocka. Wcześniej - we wtorek - członek Rady Marek Rutka opublikował informację o sześciu zaplanowanych posiedzenia gremium. Jak z kolei przekazał w niedzielę, posiedzenie zostało przełożone na inny termin.</p><br clear="all" />

## Pierwsi powitali Nowy Rok. W tle polski akcent
 - [https://wydarzenia.interia.pl/ciekawostki/news-pierwsi-powitali-nowy-rok-w-tle-polski-akcent,nId,7241445](https://wydarzenia.interia.pl/ciekawostki/news-pierwsi-powitali-nowy-rok-w-tle-polski-akcent,nId,7241445)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-31T10:02:18+00:00

<p><a href="https://wydarzenia.interia.pl/ciekawostki/news-pierwsi-powitali-nowy-rok-w-tle-polski-akcent,nId,7241445"><img align="left" alt="Pierwsi powitali Nowy Rok. W tle polski akcent" src="https://i.iplsc.com/pierwsi-powitali-nowy-rok-w-tle-polski-akcent/000IB9SERWAPOCPH-C321.jpg" /></a>Na wyspie Kiritimati na Oceanie Spokojnym - tuż przed godz. 11:00 czasu polskiego - rozpoczęło się odliczanie do północy. Mieszkańcy tego regionu jako pierwsi na świecie powitali Nowy Rok. Co ciekawe jedna z osad na wyspie nosi nazwę Poland.</p><br clear="all" />

## Akcja przed TVP. Tego dziennikarz TV Republika się nie spodziewał
 - [https://wydarzenia.interia.pl/kraj/news-akcja-przed-tvp-tego-dziennikarz-tv-republika-sie-nie-spodzi,nId,7241443](https://wydarzenia.interia.pl/kraj/news-akcja-przed-tvp-tego-dziennikarz-tv-republika-sie-nie-spodzi,nId,7241443)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-12-31T09:21:05+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-akcja-przed-tvp-tego-dziennikarz-tv-republika-sie-nie-spodzi,nId,7241443"><img align="left" alt="Akcja przed TVP. Tego dziennikarz TV Republika się nie spodziewał" src="https://i.iplsc.com/akcja-przed-tvp-tego-dziennikarz-tv-republika-sie-nie-spodzi/000IB9MTR8VOS0JR-C321.jpg" /></a>Dziennikarz Telewizji Republika zaskoczony w czasie protestu przed TVP. - Jest mi bardzo przykro, do czego doprowadziła Telewizja Polska w ostatnich ośmiu latach - mówił młody mężczyzna, pytany przez reportera o to, dlaczego pojawił się na proteście. Sytuację próbowała uratować dziennikarka w studiu.</p><br clear="all" />

