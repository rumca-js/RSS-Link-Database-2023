# Source:The Washington Post - Tech, URL:https://feeds.washingtonpost.com/rss/business/technology, language:en-US

## Testing Tesla’s Autopilot recall, I don’t feel much safer — and neither should you
 - [https://www.washingtonpost.com/technology/2023/12/31/tesla-autopilot-recall-test](https://www.washingtonpost.com/technology/2023/12/31/tesla-autopilot-recall-test)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-12-31T11:00:14+00:00

On the streets of San Francisco, Tesla’s updated driver-assistance software still took the wheel in places it wasn’t designed to handle, including blowing through stop signs.

## Your Gen Z New Year’s Eve party may have been planned on Partiful
 - [https://www.washingtonpost.com/technology/2023/12/31/partiful-gen-z-new-years-eve](https://www.washingtonpost.com/technology/2023/12/31/partiful-gen-z-new-years-eve)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-12-31T11:00:07+00:00

Millions of mostly under-30s are turning to the text-based party-planning platform, the company said, after shunning Facebook and email-based event organizers.

