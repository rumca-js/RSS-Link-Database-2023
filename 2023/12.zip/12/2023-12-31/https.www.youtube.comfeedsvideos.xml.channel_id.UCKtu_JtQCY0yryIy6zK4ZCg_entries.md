# Source:Marc Brunet, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCKtu_JtQCY0yryIy6zK4ZCg, language:en-US

## LEARN TO DRAW FROM LVL 0 to 100 🚀
 - [https://www.youtube.com/watch?v=tyIKUNovq4s](https://www.youtube.com/watch?v=tyIKUNovq4s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKtu_JtQCY0yryIy6zK4ZCg
 - date published: 2023-12-31T14:24:47+00:00

🎅 SALE OF THE YEAR!! Get 40% OFF ($240) the ART School: Digital Artists program  🎓 http://cgart.school until December 31st 2023 ONLY!! 

Join the program and access our private art community on Discord! WE JUST PASSED 20,000 ENROLLED STUDENTS! Nani?! What are you waiting for!

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

🖌 Get my brushes for FREE here: http://cbr.sh/befto
💻 HOW TO USE THE FREE BRUSHES: https://youtu.be/8EC1Ibda3BI
🖌 Clip Studio Paint MB LENGENDARY Lineart Brush: http://cbr.sh/vb2lt6
🖌 Get my advanced brush set here: http://cbr.sh/btml0

🚀 My Store: https://cubebrush.co/mb
🎨 Practice files download: http://cbr.sh/xsqi64

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

Class mentioned in the video: https://youtu.be/soPF6BRwQyQ

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

FOLLOW ME ON SOCIAL MEDIA:
✏ Twitter: https://twitter.com/ytartschool
📷 Instagram: https://instagram.com/bluefley

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ 

#learntodraw #arttips #learnart

