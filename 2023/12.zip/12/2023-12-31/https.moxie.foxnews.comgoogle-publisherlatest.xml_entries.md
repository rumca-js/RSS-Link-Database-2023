# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## Commanders' Christian Holmes collapses to turf in scary scene vs 49ers
 - [https://www.foxnews.com/sports/commanders-christian-holmes-collapses-turf-scary-scene-49ers](https://www.foxnews.com/sports/commanders-christian-holmes-collapses-turf-scary-scene-49ers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T22:51:41+00:00

Washington Commanders cornerback Christian Holmes gave his team a scare in Sunday&apos;s loss to the San Francisco 49ers after he suddenly collapsed to the turf.

## Illegal immigrants using fake passports to pose as minors when crossing US-Mexico border
 - [https://www.foxnews.com/us/illegal-immigrants-using-fake-passports-pose-minors-crossing-us-mexico-border](https://www.foxnews.com/us/illegal-immigrants-using-fake-passports-pose-minors-crossing-us-mexico-border)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T22:40:49+00:00

A Border Patrol notice obtained by Fox News advises agents that illegal immigrants from Guinea are using fake passports to pose as minors when illegally crossing the border.

## Justice Thomas should 'absolutely' recuse himself from Trump ballot access decision: Dem lawmaker
 - [https://www.foxnews.com/media/justice-thomas-absolutely-recuse-himself-trump-ballot-access-decision-dem-rep](https://www.foxnews.com/media/justice-thomas-absolutely-recuse-himself-trump-ballot-access-decision-dem-rep)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T22:35:32+00:00

Maryland Rep. Jamie Raskin argued that Justice Clarence Thomas should recuse himself if the case of Donald Trump’s ballot access reaches the Supreme Court.

## Gypsy Rose Blanchard takes to social media after prison release: 'Finally free'
 - [https://www.foxnews.com/us/gypsy-rose-blanchard-takes-social-media-after-prison-release-finally-free](https://www.foxnews.com/us/gypsy-rose-blanchard-takes-social-media-after-prison-release-finally-free)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T22:08:22+00:00

Gypsy Rose Blanchard took to Instagram to share a glimpse at her new freedom after serving eight years of a 10-year sentence for her role in plotting the murder of her mother.

## California authorities arrest traveling carnival worker accused of sexually abusing children: police
 - [https://www.foxnews.com/us/california-authorities-arrest-traveling-carnival-worker-accused-sexually-abusing-children-police](https://www.foxnews.com/us/california-authorities-arrest-traveling-carnival-worker-accused-sexually-abusing-children-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T21:58:56+00:00

Carnival worker James Donnelly was arrested by San Bernardino Police Department officers Dec. 23, after he was accused of sexually assaulting children.

## Ravens demolish Dolphins to claim No. 1 seed in AFC playoffs
 - [https://www.foxnews.com/sports/ravens-demolish-dolphins-claim-no-1-seed-afc-playoffs](https://www.foxnews.com/sports/ravens-demolish-dolphins-claim-no-1-seed-afc-playoffs)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T21:50:13+00:00

Lamar Jackson continued to add to his MVP resume while the Baltimore Ravens clinched the No. 1 seed in the AFC after demolishing the Miami Dolphins at home.

## Denmark's Queen Margrethe II announces she's stepping down from throne: 'Now is the right time'
 - [https://www.foxnews.com/world/denmarks-queen-margrethe-second-announces-shes-stepping-down-throne-now-right-time](https://www.foxnews.com/world/denmarks-queen-margrethe-second-announces-shes-stepping-down-throne-now-right-time)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T21:44:31+00:00

Denmark&apos;s 86-year-old monarch Queen Margrethe II announced that she is abdicating the throne during a speech on Sunday, surprising her Danish subjects.

## Cardinals shock Eagles on the road to drastically alter NFC playoff picture
 - [https://www.foxnews.com/sports/cardinals-shock-eagles-on-road-drastically-alter-nfc-playoff-picture](https://www.foxnews.com/sports/cardinals-shock-eagles-on-road-drastically-alter-nfc-playoff-picture)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T21:32:20+00:00

Kyler Murray and the Arizona Cardinals stunned the Philadelphia Eagles, picking up the team&apos;s fourth win of the season, which drastically alters the NFC playoff picture.

## North Carolina pastor attempted to stick wife's co-worker's head into deep fryer: police
 - [https://www.foxnews.com/us/north-carolina-pastor-attempted-stick-wifes-co-workers-head-into-deep-fryer-police](https://www.foxnews.com/us/north-carolina-pastor-attempted-stick-wifes-co-workers-head-into-deep-fryer-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T21:24:04+00:00

A North Carolina pastor was arrested for allegedly pushing his wife&apos;s coworker&apos;s head toward a McDonald&apos;s deep fryer after he disrespected her at work.

## Arizona nonprofit provides safe place and support for homeless, pregnant moms: 'Owe my blessings to them'
 - [https://www.foxnews.com/lifestyle/arizona-nonprofit-provides-safe-place-support-homeless-pregnant-moms-blessings-them](https://www.foxnews.com/lifestyle/arizona-nonprofit-provides-safe-place-support-homeless-pregnant-moms-blessings-them)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T20:57:26+00:00

Maggie&apos;s Place, an Arizona nonprofit, is expanding to meet the increasing needs of homeless pregnant women in the state. The organization currently has five homes.

## Al-Qaeda threatens Western and Jewish targets ahead of New Year's bash
 - [https://www.foxnews.com/us/al-qaeda-threatens-western-jewish-targets-ahead-new-years-bash](https://www.foxnews.com/us/al-qaeda-threatens-western-jewish-targets-ahead-new-years-bash)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T20:56:37+00:00

Al-Qaeda threatened “open-source Jihad,&quot; according to one report, against Wester and Jewish targets, including airlines, which has the TSA on high alert

## 'Friends' star David Schwimmer calls out skeptics of Hamas sexual assaults: 'Where is their outrage?'
 - [https://www.foxnews.com/entertainment/friends-star-david-schwimmer-calls-out-skeptics-of-hamas-sexual-assaults-where-outrage](https://www.foxnews.com/entertainment/friends-star-david-schwimmer-calls-out-skeptics-of-hamas-sexual-assaults-where-outrage)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T20:39:38+00:00

&quot;Friends&quot; actor David Schwimmer called out some advocates against sexual violence, arguing that they ignored reports of Hamas terrorists&apos; sex crimes on Oct. 7.

## Jimmy Johnson emotional as he talks entering Cowboys Ring of Honor
 - [https://www.foxnews.com/sports/jimmy-johnson-emotional-talks-entering-cowboys-ring-of-honor](https://www.foxnews.com/sports/jimmy-johnson-emotional-talks-entering-cowboys-ring-of-honor)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T20:38:31+00:00

Pro Football Hall of Famer Jimmy Johnson was emotional Sunday talking about being inducted into the Dallas Cowboys Ring of Honor on &quot;FOX NFL Sunday.&quot;

## Comedy legend Shecky Greene dead at 97
 - [https://www.foxnews.com/entertainment/comedy-legend-shecky-greene-dead-at-97](https://www.foxnews.com/entertainment/comedy-legend-shecky-greene-dead-at-97)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T20:03:55+00:00

Shecky Greene, the comedy legend known for his decades of work in Las Vegas and working relationships with Frank Sinatra and Elvis Presley, has died at age 97.

## Cowboys' CeeDee Lamb hit with random drug test after breaking franchise marks
 - [https://www.foxnews.com/sports/cowboys-ceedee-lamb-hit-random-drug-test-breaking-franchise-marks](https://www.foxnews.com/sports/cowboys-ceedee-lamb-hit-random-drug-test-breaking-franchise-marks)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T19:54:16+00:00

Dallas Cowboys star wide receiver CeeDee Lamb was hit with a random drug test after his record-breaking game against the Detroit Lions on Saturday.

## Woman 'lured' by man's romance and gifts forced into disturbing prostitution hustle: prosecutors
 - [https://www.foxnews.com/us/homeless-woman-lured-mans-romance-gifts-forced-disturbing-prostitution-hustle-prosecutors](https://www.foxnews.com/us/homeless-woman-lured-mans-romance-gifts-forced-disturbing-prostitution-hustle-prosecutors)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T19:40:13+00:00

Leon Sims, of Ohio, was sentenced to 37 months in prison for coercing a homeless woman into prostitution across state lines, according to the DOJ.

## 3 suspects arrested after killing of off-duty police sergeant at North Carolina gas station
 - [https://www.foxnews.com/us/3-suspects-arrested-killing-off-duty-police-sergeant-north-carolina-gas-station](https://www.foxnews.com/us/3-suspects-arrested-killing-off-duty-police-sergeant-north-carolina-gas-station)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T19:25:59+00:00

An off-duty police sergeant who served for 23 years was shot dead after confronting suspects allegedly committing a crime at a Sheetz gas station Saturday.

## Nick Carter shares video ‘cherishing these moments' with son following sister’s sudden death
 - [https://www.foxnews.com/entertainment/nick-carter-shares-video-cherishing-moments-son-following-sisters-sudden-death](https://www.foxnews.com/entertainment/nick-carter-shares-video-cherishing-moments-son-following-sisters-sudden-death)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T19:06:55+00:00

Backstreet Boys singer Nick Carter shared his first social media post following the sudden death of his sister, Bobbie Jean Carter, last week.

## Conor McGregor sets UFC return date, reveals opponent
 - [https://www.foxnews.com/sports/conor-mcgregor-sets-ufc-return-date-reveals-opponent](https://www.foxnews.com/sports/conor-mcgregor-sets-ufc-return-date-reveals-opponent)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T18:44:01+00:00

UFC great Conor McGregor announced Sunday he will fight Michael Chandler on June 29 in his return to the Octagon since suffering a broken leg against Dustin Poirier.

## German cardinal says Pope Francis’ same-sex blessings declaration ‘never would have happened’ under Benedict
 - [https://www.foxnews.com/world/german-cardinal-says-pope-francis-same-sex-blessings-declaration-never-happened-benedict](https://www.foxnews.com/world/german-cardinal-says-pope-francis-same-sex-blessings-declaration-never-happened-benedict)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T18:30:33+00:00

Pope Benedict would &quot;never&quot; have approved a policy granting priests the ability to bless people in same-sex relationships, a close ally of the former pope says.

## Harvard honor council student says Claudine Gay got by on 'lower standard' in plagiarism case, should resign
 - [https://www.foxnews.com/politics/harvard-honor-council-student-says-claudine-gay-lower-standard-plagiarism-case-should-resign](https://www.foxnews.com/politics/harvard-honor-council-student-says-claudine-gay-lower-standard-plagiarism-case-should-resign)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T18:23:01+00:00

A Harvard undergraduate student who votes on honor code infractions at the university says president Claudine Gay is benefiting from a &apos;lower standard.&apos;

## Texas AG blasts Biden admin for ‘aiding and abetting’ cartels after migration numbers smash record
 - [https://www.foxnews.com/politics/texas-ag-blasts-biden-admin-aiding-abetting-cartels-migration-numbers-smash-record](https://www.foxnews.com/politics/texas-ag-blasts-biden-admin-aiding-abetting-cartels-migration-numbers-smash-record)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T18:16:38+00:00

Republican Texas Attorney General Ken Paxton accused the Biden administration of &quot;aiding and abetting&quot; drug cartels as migrant crisis swells.

## United Football League born out of USFL-XFL merger, 1st matchup revealed
 - [https://www.foxnews.com/sports/united-football-league-born-out-usfl-xfl-merger-1st-matchup-revealed](https://www.foxnews.com/sports/united-football-league-born-out-usfl-xfl-merger-1st-matchup-revealed)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T18:03:29+00:00

The USFL-XFL merger officially birthed the United Football League, it was announced on Sunday. The Birmingham Stallions and Arlington Renegades will meet in the first game.

## Hunter Biden laptop repairman John Paul Mac Isaac's home 'swatted'
 - [https://www.foxnews.com/us/hunter-biden-laptop-repairman-john-paul-mac-isaacs-home-swatted](https://www.foxnews.com/us/hunter-biden-laptop-repairman-john-paul-mac-isaacs-home-swatted)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T17:34:04+00:00

The computer repair shop owner who turned a laptop belonging to the president&apos;s son over to authorities says his home was swatted.

## NFL officiating crew in controversial Lions-Cowboys game may be downgraded ahead of playoffs: report
 - [https://www.foxnews.com/sports/nfl-officiating-crew-controversial-lions-cowboys-game-may-be-downgraded-ahead-playoffs-report](https://www.foxnews.com/sports/nfl-officiating-crew-controversial-lions-cowboys-game-may-be-downgraded-ahead-playoffs-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T17:25:39+00:00

The officiating crew that worked the Detroit Lions-Dallas Cowboys game may not get a chance to work the postseason, according to NFL insider Adam Schefter.

## Biden reveals New Year's resolution is to 'come back next year': Report
 - [https://www.foxnews.com/media/biden-reveals-new-years-resolution-come-back-next-year-report](https://www.foxnews.com/media/biden-reveals-new-years-resolution-come-back-next-year-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T17:22:38+00:00

President Biden reveals his 2024 New Year&apos;s resolution is to &quot;come back next year,&quot; during vacation in St. Croix on Saturday as he gets ready for election year.

## Georgia's Kirby Smart takes issue with Florida State opt outs after 60-point win: 'It needs to be fixed'
 - [https://www.foxnews.com/sports/georgias-kirby-smart-takes-issue-florida-state-opt-outs-60-point-win-needs-fixed](https://www.foxnews.com/sports/georgias-kirby-smart-takes-issue-florida-state-opt-outs-60-point-win-needs-fixed)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T16:47:26+00:00

Georgia Bulldogs coach Kirby Smart lamented the Florida State opt outs after the team&apos;s 63-3 victory on Saturday. He said it&apos;s a problem that needs fixing.

## Biden's polling problem: Running for re-election in 2024, the president ends 2023 underwater
 - [https://www.foxnews.com/politics/bidens-polling-problem-running-re-election-2024-president-ends-2023-underwater](https://www.foxnews.com/politics/bidens-polling-problem-running-re-election-2024-president-ends-2023-underwater)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T16:36:46+00:00

When it comes to his approval rating, President Biden ends 2023 where he started the year – in negative territory.

## Hamas leaders lived like wealthy celebrities in Gaza terror reign prior to Oct. 7 massacre
 - [https://www.foxnews.com/world/hamas-leaders-lived-like-wealthy-celebrities-gaza-terror-reign-prior-oct-7-massacre](https://www.foxnews.com/world/hamas-leaders-lived-like-wealthy-celebrities-gaza-terror-reign-prior-oct-7-massacre)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T16:30:02+00:00

Rubble and craters now stand where the luxury homes of Hamas’ top leaders once stood, and Israeli troops reveal an elaborate tunnel system snaking beneath urban centers in Gaza.

## 2023 rewind, will Biden quit the race? and more from Fox News Opinion
 - [https://www.foxnews.com/opinion/2023-rewind-will-biden-quit-race-more-fox-news-opinion](https://www.foxnews.com/opinion/2023-rewind-will-biden-quit-race-more-fox-news-opinion)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T16:00:57+00:00

Read the latest from Fox News Opinion &amp; watch videos from Sean Hannity, Raymond Arroyo &amp; more.

## NASCAR legend Cale Yarborough dead at 84
 - [https://www.foxnews.com/sports/nascar-legend-cale-yarborough-dead](https://www.foxnews.com/sports/nascar-legend-cale-yarborough-dead)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T15:55:16+00:00

Legendary NASCAR driver Cale Yarborough has died at the age of 84, officials said. Yarborough had been dealing with an ailment since the beginning of the year.

## Detransitioner blasts GOP governor's veto of ban on gender-affirming care for minors: 'Complicit' in this
 - [https://www.foxnews.com/media/detransitioner-blasts-gop-governor-veto-ban-gender-affirming-care-minors-complicit](https://www.foxnews.com/media/detransitioner-blasts-gop-governor-veto-ban-gender-affirming-care-minors-complicit)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T15:50:57+00:00

Detransitioner Chloe Cole blasted Ohio Gov. Mike DeWine&apos;s decision to veto a ban on gender-affirming care for minors, alleging he ignored testimonies like her own.

## China's Xi Jinping says Taiwan will 'surely be reunified' in year-end address
 - [https://www.foxnews.com/world/chinas-xi-jinping-says-taiwan-surely-reunified-year-end-address](https://www.foxnews.com/world/chinas-xi-jinping-says-taiwan-surely-reunified-year-end-address)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T15:41:26+00:00

Chinese leader Xi Jinping vowed to unify &quot;both sides of the Taiwan Strait&quot; during a New Year&apos;s Eve address on Sunday.

## Tom Brady reveals he nearly unretired in May but didn't because of 1 reason
 - [https://www.foxnews.com/sports/tom-brady-reveals-he-nearly-unretired-may-didnt-because-reason](https://www.foxnews.com/sports/tom-brady-reveals-he-nearly-unretired-may-didnt-because-reason)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T15:32:26+00:00

Tom Brady revealed on Instagram on Sunday that he nearly unretired in May but didn&apos;t because his friends were throwing him a retirement party.

## Fetterman believed going public with mental health struggles would ‘end’ his career
 - [https://www.foxnews.com/us/fetterman-believed-going-public-mental-health-struggles-end-career](https://www.foxnews.com/us/fetterman-believed-going-public-mental-health-struggles-end-career)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T15:28:36+00:00

Democratic Pennsylvania Sen. John Fetterman said he feared his political career would end when he checked himself into Walter Reed for clinical depression this year.

## LeBron James erupts in fury as crunch-time shot ruled 2-pointer: 'Super frustrating'
 - [https://www.foxnews.com/sports/lebron-james-erupts-fury-crunch-time-shot-ruled-2-pointer-super-frustrating](https://www.foxnews.com/sports/lebron-james-erupts-fury-crunch-time-shot-ruled-2-pointer-super-frustrating)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T15:14:31+00:00

LeBron James erupted at NBA officials on Saturday night in the Los Angeles Lakers&apos; loss to the Minnesota Timberwolves and had words for the replay center.

## Super Bowl champ Emmanuel Ogbah talks Dolphins playoff berth, learning from 'genius' coach Vic Fangio
 - [https://www.foxnews.com/sports/super-bowl-champ-emmanuel-ogbah-talks-dolphins-playoff-berth-learning-from-genius-coach-vic-fangio](https://www.foxnews.com/sports/super-bowl-champ-emmanuel-ogbah-talks-dolphins-playoff-berth-learning-from-genius-coach-vic-fangio)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T15:01:53+00:00

The Miami Dolphins have had another strong regular season, with much of the credit going to quarterback Tua Tagovailoa and the coaching staff.

## 2023: A year of innovation and disruption in tech
 - [https://www.foxnews.com/tech/2023-year-innovation-disruption-in-tech](https://www.foxnews.com/tech/2023-year-innovation-disruption-in-tech)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T15:00:57+00:00

Artificial intelligence, robots, drones and aircraft underwent technological advancements in 2023. Technology continues to evolve at an unprecedented pace.

## 3 profound New Year's resolutions you can make when you feel helpless in our chaotic times
 - [https://www.foxnews.com/opinion/3-profound-new-years-resolutions-make-when-feel-helpless-chaotic-times](https://www.foxnews.com/opinion/3-profound-new-years-resolutions-make-when-feel-helpless-chaotic-times)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T15:00:34+00:00

Many have told me they feel helpless. Maybe you feel that. I certainly have, and yet I am in the “hope&quot; business! Is there anything you can do? The answer is a resounding “yes.&quot;

## Lions-Cowboys game ends in controversy as penalty thwarts Detroit's go-ahead 2-point conversion
 - [https://www.foxnews.com/sports/lions-cowboys-game-ends-controversy-penalty-thwarts-detroits-go-ahead-2-point-conversion](https://www.foxnews.com/sports/lions-cowboys-game-ends-controversy-penalty-thwarts-detroits-go-ahead-2-point-conversion)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T14:51:04+00:00

Controversy reared its ugly head at the end of the Detroit Lions&apos; loss to the Dallas Cowboys on Saturday night. Don&apos;t call it report-gate, but it&apos;s pretty close.

## Armed off-duty cop sends suspected carjackers fleeing as crime spirals near nation's capital
 - [https://www.foxnews.com/us/armed-off-duty-cop-sends-suspected-carjackers-fleeing-as-crime-spirals-near-nations-capital](https://www.foxnews.com/us/armed-off-duty-cop-sends-suspected-carjackers-fleeing-as-crime-spirals-near-nations-capital)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T14:40:10+00:00

An off-duty Prince George&apos;s County police officer chased off two suspected carjackers as he helped family around the holidays, the Maryland police department says.

## The James Bond martini: Recreate the classic drink ordered by 007
 - [https://www.foxnews.com/lifestyle/james-bond-martini-recipe](https://www.foxnews.com/lifestyle/james-bond-martini-recipe)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T14:15:41+00:00

James Bond orders many drinks, but perhaps the most famous is a martini. The recipe for Bond&apos;s drink was shared in Ian Fleming&apos;s 1953 book and in the movie version of the story.

## The biggest viral TikTok trends of 2023, from 'girl dinner' to 'Roman Empire'
 - [https://www.foxnews.com/media/biggest-viral-tiktok-trends-2023-girl-dinner-roman-empire](https://www.foxnews.com/media/biggest-viral-tiktok-trends-2023-girl-dinner-roman-empire)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T14:00:32+00:00

Social media users created numerous viral TikTok trends in 2023 that included asking men how often they think of the Roman Empire and revealing &quot;beige flags.&quot;

## 10 New Year's Eve rituals and traditions to do before and when the clock strikes 12
 - [https://www.foxnews.com/lifestyle/news-year-eve-rituals](https://www.foxnews.com/lifestyle/news-year-eve-rituals)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T13:23:45+00:00

There are many rituals on New Year&apos;s Eve that are thought to bring luck in the coming year. Some are rather superstitious, while others are a lot more common and traditional.

## New Year's resolution: Exercise trainer reveals ways to ‘jump’ into the New Year
 - [https://www.foxnews.com/lifestyle/new-years-resolution-exercise-trainer-discusses-ways-to-jump-new-year](https://www.foxnews.com/lifestyle/new-years-resolution-exercise-trainer-discusses-ways-to-jump-new-year)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T13:15:36+00:00

The year 2023 is here — and so is the choice of how to start fresh this New Year. A fitness instructor shared tips on &quot;Fox &amp; Friends&quot; for how to get fit this year using a mini trampoline.

## ‘Missed the mark’: Americans give President Biden final report card for 2023 as approval rating remains dismal
 - [https://www.foxnews.com/us/missed-mark-americans-give-president-biden-final-report-card-2023-approval-rating-remains-dismal](https://www.foxnews.com/us/missed-mark-americans-give-president-biden-final-report-card-2023-approval-rating-remains-dismal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T13:00:12+00:00

Americans in several cities across the United States graded President Biden&apos;s performance and offered suggestions for him to focus on in 2024.

## 2023’s most-watched trials offer lessons in life, and death
 - [https://www.foxnews.com/opinion/2023s-most-watched-trials-offer-lessons-life-death](https://www.foxnews.com/opinion/2023s-most-watched-trials-offer-lessons-life-death)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T13:00:05+00:00

The most-watched trials of 2023 are more than just court cases. They are detailed lessons about how some criminals will go to any length to get what they want -- even murder.

## Kim Jong Un reveals New Year's resolution to make more nukes and launch military satellites
 - [https://www.foxnews.com/world/kim-jong-un-reveals-new-years-resolution-make-more-nukes-launch-military-satellites](https://www.foxnews.com/world/kim-jong-un-reveals-new-years-resolution-make-more-nukes-launch-military-satellites)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T12:28:13+00:00

North Korea&apos;s Kim Jong Un vowed to develop an &quot;overwhelming war response capability&quot; on Saturday by developing nuclear materials and military satellites.

## Nuns take to TikTok to evangelize, reverse Hollywood's depiction
 - [https://www.foxnews.com/media/nuns-take-tiktok-evangelize-reverse-hollywoods-depiction](https://www.foxnews.com/media/nuns-take-tiktok-evangelize-reverse-hollywoods-depiction)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T12:00:22+00:00

A group of Catholic sisters known as the #MediaNuns are taking to TikTok to show others the love of God and reinforce the belief that people &quot;are made for more.&quot;

## How to protect your Android from a banking threat that bypasses fingerprint unlock and steals your PIN
 - [https://www.foxnews.com/tech/how-to-protect-your-android-from-banking-threat-bypasses-fingerprint-unlock-steals-your-pin](https://www.foxnews.com/tech/how-to-protect-your-android-from-banking-threat-bypasses-fingerprint-unlock-steals-your-pin)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T11:00:50+00:00

Hackers have developed Android malware known as the Chameleon Android banking, trojan capable of disabling biometric security to steal PINs and data.

## Mexico eagerly prepares for historic first Latin American lunar mission: 'Elevates the name of our country'
 - [https://www.foxnews.com/world/mexico-eagerly-prepares-historic-first-latin-american-lunar-mission-elevates-name-country](https://www.foxnews.com/world/mexico-eagerly-prepares-historic-first-latin-american-lunar-mission-elevates-name-country)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T11:00:40+00:00

Mexico will complete the project as part of NASA&apos;s Artemis initiative, which works with developing space programs in countries, including Brazil and South Korea.

## Five of the most memorable political and cultural Joe Rogan moments in 2023
 - [https://www.foxnews.com/media/five-most-memorable-political-cultural-joe-rogan-moments-2023](https://www.foxnews.com/media/five-most-memorable-political-cultural-joe-rogan-moments-2023)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T11:00:11+00:00

In 2023, podcaster Joe Rogan called out the left and the right, speaking freely in attention-grabbing moments about some of the year&apos;s most contentious political and cultural topics.

## Obesity org chair calls for measuring waistlines of 5-year-olds, fining employers for larger workers
 - [https://www.foxnews.com/media/obesity-org-chairman-calls-measuring-waistlines-5-year-olds-fining-employers-larger-workers](https://www.foxnews.com/media/obesity-org-chairman-calls-measuring-waistlines-5-year-olds-fining-employers-larger-workers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T11:00:08+00:00

Tam Fry, National Obesity Forum chair, pushed for annual waist measurements for children once they begin school and backed Japan&apos;s &quot;Metabo Law&quot; as an example for Britons.

## Meg Ryan, Cameron Diaz's return to Hollywood after leaving at peak of career
 - [https://www.foxnews.com/entertainment/meg-ryan-cameron-diazs-return-hollywood-after-leaving-peak-career](https://www.foxnews.com/entertainment/meg-ryan-cameron-diazs-return-hollywood-after-leaving-peak-career)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T10:30:54+00:00

Some of the biggest stars in Hollywood know it&apos;s better to go out on top than when you&apos;re at the bottom. Actors like Meg Ryan, Cameron Diaz and Joe Pesci left the industry at their peak.

## Sleep tracking going too far? You might be suffering from this condition, expert says
 - [https://www.foxnews.com/health/sleep-tracking-too-far-you-might-suffering-condition-expert](https://www.foxnews.com/health/sleep-tracking-too-far-you-might-suffering-condition-expert)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T10:00:33+00:00

People who obsessively track their sleep may suffer from a condition called orthosomnia. Sleep neurologist Meredith Broderick, M.D., shared the warning signs and remedies.

## NHL Hall of Famer advocates for added protection after Adam Johnson's death: 'It's worth it'
 - [https://www.foxnews.com/sports/nhl-hall-famer-advocates-added-protection-adam-johnsons-death-its-worth-it](https://www.foxnews.com/sports/nhl-hall-famer-advocates-added-protection-adam-johnsons-death-its-worth-it)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T10:00:14+00:00

After Adam Johnson&apos;s untimely death from a skate blade to his neck, NHL Hall of Famer Pat LaFontaine is advocating for players to wear neck guards.

## Ariana Grande, Britney Spears and 'Scandoval': Cheating scandals that rocked 2023
 - [https://www.foxnews.com/entertainment/ariana-grande-britney-spears-scandoval-cheating-scandals-rocked-2023](https://www.foxnews.com/entertainment/ariana-grande-britney-spears-scandoval-cheating-scandals-rocked-2023)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T10:00:08+00:00

Stars like Ariana Grande, Britney Spears, and the cast of &quot;Vanderpump Rules&quot; became embroiled in alleged cheating scandals in 2023.

## Alyssa Milano allegedly had Shannen Doherty fired from 'Charmed' and more explosive TV show feuds
 - [https://www.foxnews.com/entertainment/alyssa-milano-allegedly-had-shannen-doherty-fired-from-charmed-more-explosive-tv-show-feuds](https://www.foxnews.com/entertainment/alyssa-milano-allegedly-had-shannen-doherty-fired-from-charmed-more-explosive-tv-show-feuds)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T10:00:01+00:00

Holly Marie Combs claimed that Alyssa Milano was responsible for having Shannen Doherty fired from &quot;Charmed.&quot; Fox News Digital reviews this and other major feuds between co-stars on popular TV shows.

## Mark Wahlberg, Melissa Joan Hart, Kat Von D among stars proudly sharing their faith in Hollywood
 - [https://www.foxnews.com/entertainment/mark-wahlberg-melissa-joan-hart-kat-von-d-stars-proudly-sharing-faith-hollywood](https://www.foxnews.com/entertainment/mark-wahlberg-melissa-joan-hart-kat-von-d-stars-proudly-sharing-faith-hollywood)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T09:30:39+00:00

Stars like Mark Wahlberg, Kat Von D and Melissa Joan Hart have spoken openly and proudly about their faith and why it matters so much in their lives.

## 2023 REWIND: From a Swift takeover of the NFL to chaos on Capitol Hill and more
 - [https://www.foxnews.com/media/2023-rewind-from-swift-takeover-nfl-chaos-capitol-hill-more](https://www.foxnews.com/media/2023-rewind-from-swift-takeover-nfl-chaos-capitol-hill-more)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T09:30:12+00:00

From a Taylor Swift takeover to Capitol Hill chaos and everything in between, Fox News&apos; Digital Originals takes a look back on the top headlines of 2023.

## Vibrating weight loss pill could provide alternative to Ozempic and Wegovy, researchers say
 - [https://www.foxnews.com/health/vibrating-weight-loss-pill-could-provide-alternative-ozempic-wegovy-researchers](https://www.foxnews.com/health/vibrating-weight-loss-pill-could-provide-alternative-ozempic-wegovy-researchers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T09:30:02+00:00

Engineers at MIT have developed a new vibrating pill that could soon serve as an alternative to treat obesity. Dr. Marc Siegel shared thoughts on the &quot;smart pill technology.&quot;

## Australian world champion cyclist Rohan Dennis charged over death of wife: Report
 - [https://www.foxnews.com/sports/australian-world-champion-cyclist-rohan-dennis-charged-over-death-wife-report](https://www.foxnews.com/sports/australian-world-champion-cyclist-rohan-dennis-charged-over-death-wife-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T09:28:53+00:00

Australian professional cyclist Rohan Dennis was arrested on accusations he struck his wife, retired Olympic cyclist Melissa Hoskins, with his car, leading to her death.

## Texas toddler's sweet interaction with Virgin Mary and Baby Jesus nativity goes viral
 - [https://www.foxnews.com/lifestyle/texas-toddlers-sweet-interaction-virgin-mary-baby-jesus-nativity-goes-viral](https://www.foxnews.com/lifestyle/texas-toddlers-sweet-interaction-virgin-mary-baby-jesus-nativity-goes-viral)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T09:15:18+00:00

A two-year-old from Texas is touching hearts on Instagram after her mother shared a video of the child greeting Mother Mary and Baby Jesus figures, which were on display during Christmas.

## New Jersey rabbi says Joseph's story in Genesis is a reminder to put family first
 - [https://www.foxnews.com/lifestyle/new-jersey-rabbi-says-josephs-story-genesis-reminder-put-family-first](https://www.foxnews.com/lifestyle/new-jersey-rabbi-says-josephs-story-genesis-reminder-put-family-first)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T09:00:56+00:00

Joseph&apos;s actions in Genesis 50:19-21 are a reminder about the importance of family and forgiveness, Rabbi Akiva Block of Kehilat Kesher told Fox News Digital.

## MLB great Steve Garvey looks to revive 'heartbeat' of California 'for all the people' with Senate run
 - [https://www.foxnews.com/politics/mlb-great-steve-garvey-looks-revive-heartbeat-california-people-senate-run](https://www.foxnews.com/politics/mlb-great-steve-garvey-looks-revive-heartbeat-california-people-senate-run)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T09:00:39+00:00

California Senate candidate and MLB legend Steve Garvey is looking to represent everyone and bring stability to a &quot;dysfunctional Washington&quot; while brushing off his opposition.

## Biden's foreign policy challenges in 2023: China, Russia and war in the Middle East
 - [https://www.foxnews.com/world/bidens-foreign-policy-challenges-2023-china-russia-war-in-middle-east](https://www.foxnews.com/world/bidens-foreign-policy-challenges-2023-china-russia-war-in-middle-east)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T09:00:34+00:00

The Biden administration has faced a difficult year that ends with two major wars and China advancing its ambitions, but some experts praised the White House for embracing foreign policy again.

## 2023 in political scandals: A Senate sex tape and indictments galore
 - [https://www.foxnews.com/politics/2023-in-political-scandals-a-senate-sex-tape-and-indictments-galore](https://www.foxnews.com/politics/2023-in-political-scandals-a-senate-sex-tape-and-indictments-galore)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T09:00:30+00:00

The year 2023 was not short of political drama. Here is a look back at some of the most prominent scandals that rocked Washington, D.C., and the country.

## Former FBI agent recalls the one serial killer who left her ‘shaken’: ‘He just didn’t seem human’
 - [https://www.foxnews.com/us/former-fbi-agent-recalls-serial-killer-left-shaken-didnt-seem-human](https://www.foxnews.com/us/former-fbi-agent-recalls-serial-killer-left-shaken-didnt-seem-human)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T09:00:28+00:00

Former FBI agent Jana Monroe wrote about her studies of infamous serial killers Ted Bundy, Jeffrey Dahmer, Edmund Kemper and more in her memoir &quot;Hearts of Darkness.&quot;

## New Year brain teaser: Can you find 3 empty champagne flutes?
 - [https://www.foxnews.com/lifestyle/new-year-brain-teaser-can-find-3-empty-champagne-flutes](https://www.foxnews.com/lifestyle/new-year-brain-teaser-can-find-3-empty-champagne-flutes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-12-31T05:00:41+00:00

Test your mind with this fun, New Year-themed brain teaser that was shared with Fox News Digital. How fast can you find the animals that are holding three empty glasses?

