# Source:pcgamer, URL:https://www.pcgamer.com/rss, language:en-US

## Hardcore survival shooter Road to Vostok is looking really good after switching engines from Unity to Godot
 - [https://www.pcgamer.com/hardcore-survival-shooter-road-to-vostok-is-looking-really-good-after-switching-engines-from-unity-to-godot](https://www.pcgamer.com/hardcore-survival-shooter-road-to-vostok-is-looking-really-good-after-switching-engines-from-unity-to-godot)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2023-12-31T22:56:01+00:00

The single player, post-apocalyptic survival game has gotten a lot of buzz.

## Delve a hopeless dungeon and die of despair in indie action RPG Into the Necrovale
 - [https://www.pcgamer.com/delve-a-hopeless-dungeon-and-die-of-despair-in-indie-action-rpg-into-the-necrovale](https://www.pcgamer.com/delve-a-hopeless-dungeon-and-die-of-despair-in-indie-action-rpg-into-the-necrovale)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2023-12-31T22:17:15+00:00

It has a nice little demo.

## The PC Gamer Needlessly Terrible Hardware Naming Awards 2023: Our favourite awful names for otherwise reasonable products
 - [https://www.pcgamer.com/the-pc-gamer-needlessly-terrible-hardware-naming-awards-2023-our-favourite-awful-names-for-otherwise-reasonable-products](https://www.pcgamer.com/the-pc-gamer-needlessly-terrible-hardware-naming-awards-2023-our-favourite-awful-names-for-otherwise-reasonable-products)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2023-12-31T15:00:31+00:00

It's award season here at PC Gamer, and we'd be remiss if we didn't point out some of the very best terrible, awful, no-good product names we've seen.

## PC Gamer Hardware Awards 2023: The winners
 - [https://www.pcgamer.com/pc-gamer-hardware-awards-2023-the-winners](https://www.pcgamer.com/pc-gamer-hardware-awards-2023-the-winners)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2023-12-31T14:00:25+00:00

All the winners from the best tech released and tested in the past 12 months of PC gaming.

## 2023 was a decade-defining year for game releases, but so brutal for the industry it's hard to imagine another one like it happening for a long time
 - [https://www.pcgamer.com/2023-was-a-decade-defining-year-for-game-releases-but-so-brutal-for-the-industry-its-hard-to-imagine-another-one-like-it-happening-for-a-long-time](https://www.pcgamer.com/2023-was-a-decade-defining-year-for-game-releases-but-so-brutal-for-the-industry-its-hard-to-imagine-another-one-like-it-happening-for-a-long-time)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2023-12-31T14:00:19+00:00

Was 2023 good for the world? No. For the industry? Also no. But the games themselves? Boy did they rule.

## Forget alignment: Here's where Baldur's Gate 3's companions fall on the real-life political compass
 - [https://www.pcgamer.com/forget-alignment-heres-where-baldurs-gate-3s-companions-fall-on-the-real-life-political-compass](https://www.pcgamer.com/forget-alignment-heres-where-baldurs-gate-3s-companions-fall-on-the-real-life-political-compass)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2023-12-31T12:00:04+00:00

No, I'm not interested in discussing how long this took me.

## Wordle today: Hint and answer #925 for Sunday, December 31
 - [https://www.pcgamer.com/wordle-today-answer-925-december-31](https://www.pcgamer.com/wordle-today-answer-925-december-31)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2023-12-31T04:10:26+00:00

A hint to help you out and today's Wordle answer if you need it.

## Grim fantasy retro-RPG Skald: Against the Black Priory has a new demo ahead of a spring 2024 release
 - [https://www.pcgamer.com/grim-fantasy-retro-rpg-skald-against-the-black-priory-has-a-new-demo-ahead-of-a-spring-2024-release](https://www.pcgamer.com/grim-fantasy-retro-rpg-skald-against-the-black-priory-has-a-new-demo-ahead-of-a-spring-2024-release)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2023-12-31T03:04:47+00:00

Prepare to kill a truly remarkable number of fishmen in pursuit of their horrible masters.

## Action roguelike Skul: The Hero Slayer has sold more than 2M copies
 - [https://www.pcgamer.com/action-roguelike-skul-the-hero-slayer-has-sold-more-than-2m-copies](https://www.pcgamer.com/action-roguelike-skul-the-hero-slayer-has-sold-more-than-2m-copies)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2023-12-31T00:18:29+00:00

The side-scroller's on sale, 50% off, for a while longer.

