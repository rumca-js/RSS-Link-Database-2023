# Source:GameSpot - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## MP5: The Most Slapped Gun In Games - Loadout
 - [https://www.youtube.com/watch?v=yJV865aqEBU](https://www.youtube.com/watch?v=yJV865aqEBU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2023-12-31T15:01:01+00:00

From classic action movies like The Matrix and Die Hard to gaming franchises like Call of Duty and Battlefield, the MP5 has stolen the spotlight to truly become the iconic submachine gun.

With the help of Keeper of Firearms & Artillery, Jonathan Ferguson, we’ve come to the Royal Armouries museum in the UK to take a deep dive into the MP5, the origin of its popularity, the weapon’s place in video games and, of course, answer the question: just why do people slap it?

Notes: In this episode of Loadout, Dave Jewitt visits the Royal Armouries to talk to Keeper of Firearms & Artillery Jonathan Ferguson to chat about the most iconic submachine guns of all time: the MP5.

You can check out more episodes of Loadout right here. - https://www.youtube.com/watch?v=yzSrmGkpWKk&amp;list=PLpg6WLs8kxGMzIemU1gyyLmg5VlKI2UvC

You can check out our Firearms Expert Reacts series here. - https://www.youtube.com/watch?v=D3zux8jMtgk&amp;list=PLpg6WLs8kxGMgYb13XjPgOKbm5O-CDq7R

If you're interested in seei

