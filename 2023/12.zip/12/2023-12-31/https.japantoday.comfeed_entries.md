# Source:Japan Today, URL:https://japantoday.com/feed, language:en

## Foreign English teacher in Japan calls student’s ability garbage; says it was an 'American joke'
 - [https://japantoday.com/category/national/foreign-english-teacher-in-japan-calls-student%E2%80%99s-ability-garbage-says-it-was-an-american-joke](https://japantoday.com/category/national/foreign-english-teacher-in-japan-calls-student%E2%80%99s-ability-garbage-says-it-was-an-american-joke)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-12-31T22:48:14+00:00

In Japan, students start learning English as a mandatory subject from the third grade of elementary school. As part of their studies, pupils take part in English conversation classes…

## Japan's 18-year-olds at record-low 1.06 mil on falling births
 - [https://japantoday.com/category/national/japan%27s-18-yr-olds-at-record-low-1.06-mil.-on-falling-births](https://japantoday.com/category/national/japan%27s-18-yr-olds-at-record-low-1.06-mil.-on-falling-births)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-12-31T21:03:06+00:00

The number of 18-year-olds in Japan totaled a record low of 1.06 million as of Monday, a government estimate showed, as the country continues to grapple with a…

## Man faces arrest for dangerous driving resulting in death, injury
 - [https://japantoday.com/category/crime/man-faces-arrest-for-dangerous-driving-resulting-in-death-injury](https://japantoday.com/category/crime/man-faces-arrest-for-dangerous-driving-resulting-in-death-injury)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-12-31T21:02:25+00:00

A 30-year-old man faces arrest on suspicion of dangerous driving resulting in death and injury after the car he was driving hit and killed an 82-year-old woman and…

## Eurostar services resume as cause of flooded tunnel probed
 - [https://japantoday.com/category/world/eurostar-services-resume-as-cause-of-flooded-tunnel-probed](https://japantoday.com/category/world/eurostar-services-resume-as-cause-of-flooded-tunnel-probed)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-12-31T21:01:18+00:00

Eurostar warned customers travelling from London on Sunday of potential delays after flooding forced the cancellation all Saturday trains.
The first Eurostar train left London St Pancras International…

## Denmark’s Queen Margrethe II to step down from throne on Jan 14
 - [https://japantoday.com/category/world/denmark%E2%80%99s-queen-margrethe-ii-to-step-down-from-throne-on-jan.-14](https://japantoday.com/category/world/denmark%E2%80%99s-queen-margrethe-ii-to-step-down-from-throne-on-jan.-14)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-12-31T21:01:09+00:00

Denmark’s Queen Margrethe II announced Sunday that she plans to abdicate after 52 years and hand over the throne to her son, Crown Prince Frederik.
The queen, who…

## Taliban say security forces killed dozens of Tajiks, Pakistanis involved in attacks in Afghanistan
 - [https://japantoday.com/category/world/taliban-say-security-forces-killed-dozens-of-tajiks-pakistanis-involved-in-attacks-in-afghanistan](https://japantoday.com/category/world/taliban-say-security-forces-killed-dozens-of-tajiks-pakistanis-involved-in-attacks-in-afghanistan)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-12-31T21:01:02+00:00

Security forces in Afghanistan killed a number of Tajik and Pakistani nationals and arrested scores others involved in attacks against religious clerics, the public, and mosques, a senior…

## U.S. Navy helicopters fire at Yemen's Houthi rebels and kill several in latest Red Sea shipping attack
 - [https://japantoday.com/category/world/us-forces-shoot-down-ballistic-missiles-in-red-sea-kills-gunmen-in-attack-by-yemen%27s-houthi-rebels](https://japantoday.com/category/world/us-forces-shoot-down-ballistic-missiles-in-red-sea-kills-gunmen-in-attack-by-yemen%27s-houthi-rebels)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-12-31T21:00:42+00:00

The U.S. military said Sunday that its forces opened fire on Houthi rebels after they attacked a cargo ship in the Red Sea, killing several of them in…

## China's Xi says 'reunification' with Taiwan is inevitable
 - [https://japantoday.com/category/world/china%27s-xi-says-%27reunification%27-with-taiwan-is-inevitable](https://japantoday.com/category/world/china%27s-xi-says-%27reunification%27-with-taiwan-is-inevitable)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-12-31T21:00:35+00:00

China's &quot;reunification&quot; with Taiwan is inevitable, President Xi Jinping said in his New Year's address on Sunday, striking a stronger tone than he did last year with less…

## Russia launches fresh drone strikes in Ukraine after promising retaliation for Belgorod attack
 - [https://japantoday.com/category/world/russia-launches-fresh-drone-strikes-on-ukraine-after-promising-retaliation-for-belgorod-attack](https://japantoday.com/category/world/russia-launches-fresh-drone-strikes-on-ukraine-after-promising-retaliation-for-belgorod-attack)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-12-31T21:00:28+00:00

Russia launched a fresh drone assault on Ukraine after promising that strikes on the Russian border city of Belgorod that killed 24 people Saturday “would not go unpunished.”…

## Israeli strikes in central Gaza kill at least 35 as Netanyahu says war will continue for months
 - [https://japantoday.com/category/world/israeli-strikes-in-central-gaza-kill-at-least-35-as-netanyahu-says-war-will-continue-for-months](https://japantoday.com/category/world/israeli-strikes-in-central-gaza-kill-at-least-35-as-netanyahu-says-war-will-continue-for-months)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-12-31T21:00:20+00:00

Israeli strikes in central Gaza killed at least 35 people Sunday, hospital officials said, as fighting raged across the tiny enclave a day after Israel’s prime minister said…

## Conor McGregor says he's returning to octagon vs Michael Chandler. UFC neither confirms nor denies
 - [https://japantoday.com/category/sports/conor-mcgregor-says-he%27s-returning-to-octagon-vs-michael-chandler.-ufc-neither-confirms-nor-denies](https://japantoday.com/category/sports/conor-mcgregor-says-he%27s-returning-to-octagon-vs-michael-chandler.-ufc-neither-confirms-nor-denies)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-12-31T21:00:00+00:00

Conor McGregor announced Sunday he's returning to the octagon for a fight against Michael Chandler on June 29 in Las Vegas.
McGregor made the announcement in a video…

## Former cycling world champ Dennis charged after Olympian wife struck, killed by vehicle
 - [https://japantoday.com/category/sports/reports-former-cycling-world-champ-dennis-charged-after-olympian-wife-struck-killed-by-vehicle](https://japantoday.com/category/sports/reports-former-cycling-world-champ-dennis-charged-after-olympian-wife-struck-killed-by-vehicle)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-12-31T20:59:54+00:00

Former world champion cyclist Rohan Dennis is reported to have been charged in connection with the death of his wife, Olympic cyclist Melissa Hoskins, who died after being…

## Djokovic leads Serbia to a 2-1 victory over China; U.S. also wins in United Cup
 - [https://japantoday.com/category/sports/fernandez-leads-canada-to-win-over-chile-at-united-cup.-pegula-stunned-by-great-britain%27s-boulter](https://japantoday.com/category/sports/fernandez-leads-canada-to-win-over-chile-at-united-cup.-pegula-stunned-by-great-britain%27s-boulter)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-12-31T20:59:46+00:00

Making a triumphant return to Perth after a decade, Novak Djokovic led Serbia to a 2-1 win over China at the United Cup on Sunday.
Djokovic, playing in…

## Arsenal limps into 2024 after 'worst performance of the season'
 - [https://japantoday.com/category/sports/arsenal-limps-into-2024-after-%27worst-performance-of-the-season.%27-tottenham-closes-in-on-top-four](https://japantoday.com/category/sports/arsenal-limps-into-2024-after-%27worst-performance-of-the-season.%27-tottenham-closes-in-on-top-four)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-12-31T20:59:36+00:00

Arsenal is limping into 2024 after a damaging stretch that culminated in what coach Mikel Arteta called “the worst performance of the season” on the final day of…

## Paula Abdul accuses 'American Idol' producer Nigel Lythgoe of sexual assault in lawsuit
 - [https://japantoday.com/category/entertainment/paula-abdul-accuses-%27american-idol%27-producer-nigel-lythgoe-of-sexual-assault-in-lawsuit](https://japantoday.com/category/entertainment/paula-abdul-accuses-%27american-idol%27-producer-nigel-lythgoe-of-sexual-assault-in-lawsuit)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-12-31T20:58:52+00:00

Paula Abdul has accused former “American Idol” producer Nigel Lythgoe of sexually assaulting her in the early 2000s when she was a judge on the reality competition show,…

## 'Wonka' ends the year No. 1 at the box office; 2023 sales reach $9 billion in post-pandemic best
 - [https://japantoday.com/category/entertainment/%27wonka%27-ends-the-year-no.-1-at-the-box-office-2023-sales-reach-9-billion-in-post-pandemic-best](https://japantoday.com/category/entertainment/%27wonka%27-ends-the-year-no.-1-at-the-box-office-2023-sales-reach-9-billion-in-post-pandemic-best)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-12-31T20:58:42+00:00

Hollywood closed out an up and down 2023 with “Wonka” regaining No. 1 at the box office, strong sales for “The Color Purple” and an overall $9 billion…

## Kishida considers forgoing Latin America trip due to fund scandal
 - [https://japantoday.com/category/politics/japan-pm-kishida-mulls-forgoing-latin-america-trip-amid-fund-scandal](https://japantoday.com/category/politics/japan-pm-kishida-mulls-forgoing-latin-america-trip-amid-fund-scandal)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-12-31T20:57:12+00:00

Japanese Prime Minister Fumio Kishida is considering forgoing a plan to visit Brazil and other Latin American nations in January amid a political fundraising scandal involving his party's…

## Foreign English teacher in Japan calls student’s ability garbage; says it was an 'American joke'
 - [https://japantoday.com/category/national/foreign-english-teacher-in-japan-calls-student%E2%80%99s-ability-garbage-says-it-was-an-%27american-joke%27](https://japantoday.com/category/national/foreign-english-teacher-in-japan-calls-student%E2%80%99s-ability-garbage-says-it-was-an-%27american-joke%27)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-12-31T20:56:31+00:00

In Japan, students start learning English as a mandatory subject from the third grade of elementary school. As part of their studies, pupils take part in English conversation classes…

## With eye on 'if Trump wins' scenario, Japan weighs committing to its own defense
 - [https://japantoday.com/category/politics/focus-eyeing-if-trump-scenario-japan-must-commit-to-its-own-defense](https://japantoday.com/category/politics/focus-eyeing-if-trump-scenario-japan-must-commit-to-its-own-defense)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-12-31T20:55:35+00:00

The year 2024 will see key elections in a number of large and geopolitically significant polities such as Russia, India, Indonesia, South Korea and Taiwan, but the U.S.…

## At the stroke of midnight, the New Year gives a clean slate for long-elusive resolutions
 - [https://japantoday.com/category/features/lifestyle/at-the-stroke-of-midnight-the-new-year-gives-a-clean-slate-for-long-elusive-resolutions](https://japantoday.com/category/features/lifestyle/at-the-stroke-of-midnight-the-new-year-gives-a-clean-slate-for-long-elusive-resolutions)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-12-31T20:51:29+00:00

It’s an annual end-of-year exercise in futility for many. But a clean slate awaits at the stroke of midnight for the next round of resolutions.
From the first…

## Happy New Year
 - [https://japantoday.com/category/picture-of-the-day/happy-new-year-14](https://japantoday.com/category/picture-of-the-day/happy-new-year-14)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-12-31T20:40:10+00:00

People gather at the Zojoji Buddhist temple in Tokyo to celebrate the New Year early Monday.

## Body found in suitcase identified as that of 46-year-old man
 - [https://japantoday.com/category/crime/body-found-in-suitcase-identified-as-that-of-46-year-old-man](https://japantoday.com/category/crime/body-found-in-suitcase-identified-as-that-of-46-year-old-man)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-12-31T07:34:51+00:00

Kanagawa prefectural police say a body found in a large suitcase at the edge of a river in Kawasaki on Friday has been identified as that of a…

## Bedbug consultations surge in Tokyo, Osaka as pests see resurgence
 - [https://japantoday.com/category/national/bedbug-consultations-surge-in-tokyo-osaka-as-pests-see-resurgence](https://japantoday.com/category/national/bedbug-consultations-surge-in-tokyo-osaka-as-pests-see-resurgence)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-12-31T07:33:52+00:00

Bedbug-related consultations in the major Japanese metropolitan areas of Tokyo and Osaka have surged this year to hit their highest numbers on record, according to pest control associations…

## Inflation, weak yen hit appetite for holiday spending in Japan
 - [https://japantoday.com/category/business/refiling-inflation-weak-yen-hit-appetite-for-holiday-spending-in-japan](https://japantoday.com/category/business/refiling-inflation-weak-yen-hit-appetite-for-holiday-spending-in-japan)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-12-31T07:33:29+00:00

Japan's high inflation and weak yen have discouraged spending by individuals and households during the year-end and New Year holidays, according to a private sector survey.
The average…

## After war, heat, bots and Barbie, world set to ring in 2024
 - [https://japantoday.com/category/world/after-war-bots-and-barbie-world-rings-in-2024](https://japantoday.com/category/world/after-war-bots-and-barbie-world-rings-in-2024)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-12-31T07:10:44+00:00

Jubilant crowds will bid farewell to the hottest year on record Sunday, closing a turbulent 12 months marked by clever chatbots, climate crises and wrenching wars in Gaza…

## Fernandez leads Canada to United Cup win over Chile
 - [https://japantoday.com/category/sports/fernandez-leads-canada-to-united-cup-win-over-chile](https://japantoday.com/category/sports/fernandez-leads-canada-to-united-cup-win-over-chile)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-12-31T07:10:12+00:00

Leylah Fernandez led Canada to a fighting victory over Chile at the United Cup on Sunday, with the former US Open finalist winning her singles rubber and then…

## Nadal leaves door open to playing beyond 2024
 - [https://japantoday.com/category/sports/nadal-leaves-door-open-to-playing-beyond-2024](https://japantoday.com/category/sports/nadal-leaves-door-open-to-playing-beyond-2024)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-12-31T07:09:37+00:00

Rafael Nadal left the door ajar Sunday to continuing after the 2024 season, but conceded there was &quot;a high percentage&quot; that he was on his last trip as…

## N Korea to launch new satellites, build drones as it warns war inevitable
 - [https://japantoday.com/category/world/north-korea-to-launch-new-satellites-build-drones-as-it-warns-war-inevitable1](https://japantoday.com/category/world/north-korea-to-launch-new-satellites-build-drones-as-it-warns-war-inevitable1)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-12-31T07:04:41+00:00

North Korea vowed to launch three new spy satellites, build military drones, and boost its nuclear arsenal in 2024 as leader Kim Jong Un said U.S. policy is…

