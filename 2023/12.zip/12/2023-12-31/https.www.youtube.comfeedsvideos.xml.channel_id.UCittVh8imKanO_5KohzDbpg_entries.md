# Source:Paul Joseph Watson, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCittVh8imKanO_5KohzDbpg, language:en-US

## Beyond cringe.
 - [https://www.youtube.com/watch?v=j6aKsu5feKA](https://www.youtube.com/watch?v=j6aKsu5feKA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCittVh8imKanO_5KohzDbpg
 - date published: 2023-12-31T18:56:23+00:00

Please subscribe to the channel for more: https://www.youtube.com/PrisonPlanetLive?sub_confirmation=1

