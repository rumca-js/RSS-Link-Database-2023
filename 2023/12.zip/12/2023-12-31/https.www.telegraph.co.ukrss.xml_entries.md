# Source:The Telegraph Top Stories, URL:https://www.telegraph.co.uk/rss.xml, language:en-UK

## New Year’s Eve: Sydney and Auckland among first cities to ring in 2024
 - [https://www.telegraph.co.uk/world-news/2023/12/31/new-years-eve-2024-fireworks-sydney](https://www.telegraph.co.uk/world-news/2023/12/31/new-years-eve-2024-fireworks-sydney)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-12-31T16:02:30+00:00



## Tom Lockyer planning return to Luton after cardiac arrest – but maybe not as a player
 - [https://www.telegraph.co.uk/football/2023/12/31/tom-lockyer-return-luton-cardiac-arrest-instagram-post](https://www.telegraph.co.uk/football/2023/12/31/tom-lockyer-return-luton-cardiac-arrest-instagram-post)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-12-31T15:35:05+00:00



## Fulham vs Arsenal live: Kai Havertz returns from suspension as managers name lineups
 - [https://www.telegraph.co.uk/football/2023/12/31/fulham-vs-arsenal-live-score-updates-premier-league](https://www.telegraph.co.uk/football/2023/12/31/fulham-vs-arsenal-live-score-updates-premier-league)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-12-31T13:42:22+00:00



## Tottenham vs Bournemouth live: Lo Celso and Bentancur return to Spurs lineup
 - [https://www.telegraph.co.uk/football/2023/12/31/tottenham-vs-bournemouth-live-score-updates-premier-league](https://www.telegraph.co.uk/football/2023/12/31/tottenham-vs-bournemouth-live-score-updates-premier-league)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-12-31T13:20:01+00:00



## Rohan Dennis, former pro cyclist, charged with killing his wife
 - [https://www.telegraph.co.uk/cycling/2023/12/31/rohan-dennis-former-pro-cyclist-charged-killing-wife-car](https://www.telegraph.co.uk/cycling/2023/12/31/rohan-dennis-former-pro-cyclist-charged-killing-wife-car)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-12-31T12:32:16+00:00



## ‘I hope the research we’ve been a part of can be someone else’s miracle’
 - [https://www.telegraph.co.uk/christmas/2023/12/31/research-weve-been-part-of-can-be-someone-elses-miracle](https://www.telegraph.co.uk/christmas/2023/12/31/research-weve-been-part-of-can-be-someone-elses-miracle)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-12-31T12:00:00+00:00



## Watch moment cyclist Mathieu van der Poel spits into crowd who jeered him
 - [https://www.telegraph.co.uk/cycling/2023/12/31/video-mathieu-van-der-poel-spits-into-crowd-jeered-him](https://www.telegraph.co.uk/cycling/2023/12/31/video-mathieu-van-der-poel-spits-into-crowd-jeered-him)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-12-31T11:40:19+00:00



## Priscilla, review: Sofia Coppola shunts Elvis to the shadows, to beautiful effect
 - [https://www.telegraph.co.uk/films/0/priscilla-review-sofia-coppola-cailee-spaeny-jacob-elordi](https://www.telegraph.co.uk/films/0/priscilla-review-sofia-coppola-cailee-spaeny-jacob-elordi)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-12-31T11:00:00+00:00



## Israel-Hamas war live: US Navy helicopters sink three Houthi ships
 - [https://www.telegraph.co.uk/world-news/2023/12/31/israel-hamas-war-latest-news1](https://www.telegraph.co.uk/world-news/2023/12/31/israel-hamas-war-latest-news1)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-12-31T10:14:11+00:00



## US shoots down Red Sea missiles after ship reports explosion
 - [https://www.telegraph.co.uk/world-news/2023/12/31/container-ship-reports-explosion-in-red-sea-on-saturday](https://www.telegraph.co.uk/world-news/2023/12/31/container-ship-reports-explosion-in-red-sea-on-saturday)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-12-31T05:42:33+00:00



