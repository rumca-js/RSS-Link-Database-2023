# Source:Forsal.pl, URL:https://forsal.pl/.feed, language:pl-PL

## Tusk komentuje orędzie Dudy. "Słowa prezydenta, że trzeba bronić Konstytucji, to ostatni z cudów 2023 roku"
 - [https://forsal.pl/gospodarka/polityka/artykuly/9392664,tusk-komentuje-oredzie-dudy-slowa-prezydenta-ze-trzeba-bronic-konst.html](https://forsal.pl/gospodarka/polityka/artykuly/9392664,tusk-komentuje-oredzie-dudy-slowa-prezydenta-ze-trzeba-bronic-konst.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-31T20:11:39+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/qjvktkuTURBXy9iNWNhZDljOS0wYjAxLTRlYTctYTllMS1jYTZlYmY3N2RjMWIuanBlZ5GTBc0BHcyg" />Odchodzący 2023 rok był pełen cudów; ostatni z nich to słowa z orędzia prezydenta Andrzeja Dudy, że trzeba bronić konstytucji - ocenił w niedzielę premier Donald Tusk, odnosząc się do noworocznego orędzia prezydenta Andrzeja Dudy.

## Orędzie noworoczne prezydenta Andrzeja Dudy. "Zagrożenia zewnętrzne dla naszej ojczyzny nigdzie nie zniknęły"
 - [https://forsal.pl/gospodarka/polityka/artykuly/9392661,oredzie-noworoczne-prezydenta-andrzeja-dudy-zagrozenia-zewnetrzne-dl.html](https://forsal.pl/gospodarka/polityka/artykuly/9392661,oredzie-noworoczne-prezydenta-andrzeja-dudy-zagrozenia-zewnetrzne-dl.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-31T19:13:24+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/G60ktkuTURBXy8wZGVkMDc4Yy0yMjQ4LTRiY2EtOTE3Yi04YjZkNzdlODBhNDIuanBlZ5GTBc0BHcyg" />Po ośmiu latach zmieniła się większość parlamentarna, zmienił się premier, zmienił się rząd, ale najważniejsze zadanie rządu się nie zmieniło - jest to bezpieczeństwo Polski - powiedział prezydent Andrzej Duda w orędziu noworocznym.

## Czy Polacy chcą, żeby rząd wypowiedział Konkordat z Kościołem? [SONDAŻ]
 - [https://forsal.pl/gospodarka/polityka/artykuly/9392659,czy-polacy-chca-zeby-rzad-wypowiedzial-konkordat-z-kosciolem-sondaz.html](https://forsal.pl/gospodarka/polityka/artykuly/9392659,czy-polacy-chca-zeby-rzad-wypowiedzial-konkordat-z-kosciolem-sondaz.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-31T18:43:44+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Ml2ktkuTURBXy8wNTk4NGI2NC03MGYzLTRiNzYtYTNlYy05NTczZGIwMWRkYWMuanBlZ5GTBc0BHcyg" />48,6 proc. badanych uważa, że rząd powinien wypowiedzieć dotychczasowy Konkordat z Kościołem i negocjować na nowo relacje na linii państwo - Kościół. Przeciwnego zdania jest 33,1 proc. respondentów - wynika z opublikowanego w niedzielę przez Wirtualną Polskę sondażu United Surveys.

## Demokratyczna Republika Konga wybrała prezydenta
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9392651,demokratyczna-republika-konga-wybrala-prezydenta.html](https://forsal.pl/swiat/aktualnosci/artykuly/9392651,demokratyczna-republika-konga-wybrala-prezydenta.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-31T17:45:12+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/YtQktkuTURBXy9hMTA4M2ExNS1lZmIzLTRmNDAtOWUzYi04Zjk5OGJkYThlNzUuanBlZ5GTBc0BHcyg" />Prezydent Demokratycznej Republiki Konga Felix Tshisekedi wywalczył drugą kadencję na stanowisku szefa państwa, zdobywając w wyborach z 20 grudnia ponad 73 proc. głosów - poinformowała w niedzielę centralna komisja wyborcza w Kinszasie. Opozycyjni kandydaci nie uznają wyniku wyborów.

## Gdzie już jest 2024 rok? Które państwo przywitało go jako pierwsze?
 - [https://forsal.pl/lifestyle/rozrywka/artykuly/9392646,gdzie-juz-jest-2024-rok-ktore-panstwo-przywitalo-go-jako-pierwsze.html](https://forsal.pl/lifestyle/rozrywka/artykuly/9392646,gdzie-juz-jest-2024-rok-ktore-panstwo-przywitalo-go-jako-pierwsze.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-31T16:00:57+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/qnoktkuTURBXy85ZDFlNTkyZS04ZTRiLTRkZGMtODI1ZS04ZTdkMGIwZTFmMjYuanBlZ5GTBc0BHcyg" />Dzwony świątynne rozbrzmiewały w całej Japonii, gdy ludzie gromadzili się w sanktuariach i świątyniach, aby powitać 2024 rok. Australia także powitała już 2024 rok.

## Izrael zezwala na transport pomocy humanitarnej dla Strefy Gazy drogą morską
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9392634,izrael-zezwala-na-transport-pomocy-humanitarnej-dla-strefy-gazy-droga.html](https://forsal.pl/swiat/aktualnosci/artykuly/9392634,izrael-zezwala-na-transport-pomocy-humanitarnej-dla-strefy-gazy-droga.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-31T13:28:17+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/a0FktkuTURBXy8zMzQyZWRjNC1mMjE5LTQyMjYtODdmYy0wYmI2OTYxMWJiN2YuanBlZ5GTBc0BHcyg" />Izrael jest gotowy pozwolić statkom na &quot;natychmiastowe&quot; dostarczenie pomocy humanitarnej do Strefy Gazy w ramach proponowanego korytarza morskiego z Cypru - oznajmił w niedzielę izraelski minister spraw zagranicznych Eli Cohen. Jego zdaniem w projekcie mają brać udział Wielka Brytania, Francja, Grecja i Holandia.

## W nowym roku po 32 latach przestanie istnieć Republika Górskiego Karabachu
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9392627,w-nowym-roku-po-32-latach-przestanie-istniec-republika-gorskiego-karab.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9392627,w-nowym-roku-po-32-latach-przestanie-istniec-republika-gorskiego-karab.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-31T11:48:10+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/JKcktkuTURBXy9hMTQxN2I4MS1hNGUzLTQ5MzgtYTRmYy1mZTQyZDFhZGM5ZWQuanBlZ5GTBc0BHcyg" />1 stycznia 2024 roku dojdzie do samorozwiązania Republiki Górskiego Karabachu - separatystycznego ormiańskiego parapaństwa na terytorium Azerbejdżanu, które istniało od grudnia 1991 roku. Koniec niezależności tego regionu to konsekwencja operacji wojskowej azerbejdżańskiej armii, przeprowadzonej tam we wrześniu br. i skutkującej exodusem mieszkańców Górskiego Karabachu do Armenii.

## Korea Północna: Kim Dzong Un polecił armii przygotować się do wojny
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9392626,korea-polnocna-kim-dzong-un-polecil-armii-przygotowac-sie-do-wojny.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9392626,korea-polnocna-kim-dzong-un-polecil-armii-przygotowac-sie-do-wojny.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-31T11:43:06+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/YVIktkuTURBXy80ZDlkOTE3ZC05ODc0LTQwMDctOWRlYi01ZGRkZDJmN2YyNzcuanBlZ5GTBc0BHcyg" />Przywódca Korei Północnej Kim Dzong Un ponownie zagroził atakiem nuklearnym na Seul i zlecił przyśpieszenie przygotowań wojskowych do „wojny”, która „może zostać wywołana w każdej chwili” na Półwyspie Koreańskim – podała w niedzielę państwowa agencja KCNA.

## Koronawirus w Polsce: 153 zakażenia, nie było przypadków śmiertelnych [DANE Z 31.12]
 - [https://forsal.pl/artykuly/1458115,koronawirus-w-polsce-153-zakazenia-nie-bylo-przypadkow-smiertelnych.html](https://forsal.pl/artykuly/1458115,koronawirus-w-polsce-153-zakazenia-nie-bylo-przypadkow-smiertelnych.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-31T09:55:38+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/3QYktkuTURBXy9lNjE1ZGFlZC02OTg5LTQzNzItOTg5OS1jZWEzOWVhODg4OWYuanBlZ5GTBc0BHcyg" />Minionej doby badania potwierdziły 153 zakażenia koronawirusem, w tym 30 ponownych. Z powodu COVID-19 nie zmarł żaden pacjent – poinformowano w niedzielę na stronach rządowych. Wykonano 853 testy w kierunku SARS-CoV-2.

## Orędzie noworoczne prezydenta Andrzeja Dudy. Gdzie można obejrzeć transmisję?
 - [https://forsal.pl/gospodarka/polityka/artykuly/9392594,oredzie-noworoczne-prezydenta-andrzeja-dudy-gdzie-mozna-obejrzec-transmisje.html](https://forsal.pl/gospodarka/polityka/artykuly/9392594,oredzie-noworoczne-prezydenta-andrzeja-dudy-gdzie-mozna-obejrzec-transmisje.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-31T09:38:22+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/FYMktkuTURBXy8yMDg4NDIwZC01YzVhLTRiMDgtYTFkNS05YzFhOWRjYjkzYmEuanBlZ5GTBc0BHcyg" />W niedzielę (31 grudnia 2023 r.) prezydent RP Andrzej Duda wygłosi orędzie noworoczne, w którym przedstawi m.in. największe wyzwania na 2024 rok dla Polski.

## Od nowego roku zatankujesz na stacjach benzynę E10. Czym się wyróżnia?
 - [https://forsal.pl/transport/aktualnosci/artykuly/9392589,od-nowego-roku-zatankujesz-na-stacjach-benzyne-e10-czym-sie-wyroznia.html](https://forsal.pl/transport/aktualnosci/artykuly/9392589,od-nowego-roku-zatankujesz-na-stacjach-benzyne-e10-czym-sie-wyroznia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-31T08:52:57+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/kqCktkuTURBXy9jMzFmYzBmZi00NGIxLTRiM2EtYjQ5Ny00NGEzN2U2MjdlZjguanBlZ5GTBc0BHcyg" />Od 1 stycznia 2024 r. kierowcy zatankują na stacjach benzynę E10, zawierającą do 10 proc. biokomponentów. Właściciele aut mogą sprawdzić w specjalnej internetowej wyszukiwarce, czy ich samochód jest przystosowany do korzystania z benzyny E10.

## Świadczenie wspierające dla osób z niepełnosprawnościami. Uścińska: Jesteśmy gotowi do realizacji
 - [https://forsal.pl/finanse/finanse-osobiste/artykuly/9392585,swiadczenie-wspierajace-dla-osob-z-niepelnosprawnosciami-uscinska-je.html](https://forsal.pl/finanse/finanse-osobiste/artykuly/9392585,swiadczenie-wspierajace-dla-osob-z-niepelnosprawnosciami-uscinska-je.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-31T08:47:28+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/rgiktkuTURBXy83OWJlMmFiMi04ZTQ4LTQ4YmItYjljYy01YTkxNzAzYWRkZmMuanBlZ5GTBc0BHcyg" />Jesteśmy gotowi do realizacji świadczenia wspierającego dla osób z niepełnosprawnościami. Warto jednak pamiętać, że przed złożeniem wniosku do ZUS należy najpierw zgłosić się do wojewódzkiego zespołu ds. orzecznictwa - poinformowała PAP prezes ZUS prof. Gertruda Uścińska.

## Ultraradykalny plan ratowania gospodarki Argentyny uruchomiony
 - [https://forsal.pl/gospodarka/aktualnosci/artykuly/9392582,ultraradykalny-plan-ratowania-gospodarki-argentyny-uruchomiony.html](https://forsal.pl/gospodarka/aktualnosci/artykuly/9392582,ultraradykalny-plan-ratowania-gospodarki-argentyny-uruchomiony.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-31T08:42:23+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/DHsktkuTURBXy8wNzhlYzQ2MC1hMzU5LTRiYzAtYjBiZC04NWJiODc4MTI5MDguanBlZ5GTBc0BHcyg" />Trzy tygodnie po objęciu urzędu prezydent Javier Milei przystępuje do urzeczywistniania swego radykalnego planu ratowania argentyńskiej gospodarki zrujnowanej za rządów peronistowskiej lewicy 150-procentową w skali rocznej inflacją i brakiem inwestycji.

## Kiedy Rumunia i Bułgaria wejdą do strefy Schengen? Znamy datę
 - [https://forsal.pl/swiat/unia-europejska/artykuly/9392580,kiedy-rumunia-i-bulgaria-wejda-do-strefy-schengen-znamy-date.html](https://forsal.pl/swiat/unia-europejska/artykuly/9392580,kiedy-rumunia-i-bulgaria-wejda-do-strefy-schengen-znamy-date.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-31T08:38:03+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/3MXktkuTURBXy9iM2E2NWQ2Yi0zNTYyLTQ1OWQtYTMxYy0xMDRjNmY2NzE4MjAuanBlZ5GTBc0BHcyg" />Rumunia i Bułgaria zostaną od 31 marca 2024 r. przyjęte do strefy Schengen - ogłosiła w sobotę późnym wieczorem hiszpańska prezydencja w Radzie Unii Europejskiej.

## Wielka Brytania odzyska połączenie z kontynentem europejskim
 - [https://forsal.pl/transport/aktualnosci/artykuly/9392577,wielka-brytania-odzyska-polaczenie-z-kontynentem-europejskim.html](https://forsal.pl/transport/aktualnosci/artykuly/9392577,wielka-brytania-odzyska-polaczenie-z-kontynentem-europejskim.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-31T08:34:52+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/yWsktkuTURBXy9kODQyNzdhOS05OGY3LTRmMDEtOWIwNi03ZWQxY2JjOTA0OGYuanBlZ5GTBc0BHcyg" />Międzynarodowy operator kolejowy Eurostar zapowiedział wznowienie w niedzielę połączeń kolejowych między Londynem a kontynentem europejskim. W sobotę odwołano wszystkie pociągi z powodu zalania tuneli kolejowych w południowo-wschodniej Anglii.

## Korea Północna wystrzeli kolejnych satelitów szpiegowskich
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9392575,korea-polnocna-wystrzeli-kolejnych-satelitow-szpiegowskich.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9392575,korea-polnocna-wystrzeli-kolejnych-satelitow-szpiegowskich.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-31T08:32:10+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/WzUktkuTURBXy82NmIxNDZmMC1iMTUzLTQyMzUtODQ5MS1mMWMxNWQ0NWU0YjIuanBlZ5GTBc0BHcyg" />Wśród celów Korei Północnej na 2024 rok jest umieszczenie na orbicie kolejnych trzech satelitów zwiadowczych oraz budowa dronów, które wzmocnią armię tego kraju – podała w niedzielę czasu miejscowego państwowa północnokoreańska agencja prasowa KCNA.

## Niedziela, 31 grudnia. Gdzie dziś można zrobić zakupy? Jakie sklepy są otwarte w sylwestra?
 - [https://forsal.pl/biznes/handel/artykuly/9392566,niedziela-31-grudnia-gdzie-dzis-mozna-zrobic-zakupy-jakie-sklepy-sa-otwarte-w-sylwestra.html](https://forsal.pl/biznes/handel/artykuly/9392566,niedziela-31-grudnia-gdzie-dzis-mozna-zrobic-zakupy-jakie-sklepy-sa-otwarte-w-sylwestra.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-31T06:33:58+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/zsHktkuTURBXy80NTllODY2YS1jNWE3LTQ2NTktODBlZC1mZTNkMGUxMTZkOWQuanBlZ5GTBc0BHcyg" />W niedzielę (31 grudnia 2023 r.) większe sklepy w Polsce są nieczynne ze względu na zakaz handlu. Sprawdź, gdzie w sylwestra można zrobić zakupy.

## Pięć lekcji z zimnej wojny. Czy USA i Chiny wyciągną z nich wnioski?
 - [https://forsal.pl/swiat/usa/artykuly/9391964,piec-lekcji-z-zimnej-wojny-czy-usa-i-chiny-wyciagna-z-nich-wnioski.html](https://forsal.pl/swiat/usa/artykuly/9391964,piec-lekcji-z-zimnej-wojny-czy-usa-i-chiny-wyciagna-z-nich-wnioski.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-31T06:01:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/5vMktkuTURBXy81MjhjNjIyYy01ZWY1LTQ3MzctYmE0My00MjBhYjFhZDQ5MDUuanBlZ5GTBc0BHcyg" />Siła militarna ma znaczenie, tak samo jak posiadanie sojuszników.

## Dlaczego świat potrzebuje Międzynarodowego Funduszu GenAI? [OPINIA]
 - [https://forsal.pl/lifestyle/technologie/artykuly/9391306,dlaczego-swiat-potrzebuje-miedzynarodowego-funduszu-genai-opinia.html](https://forsal.pl/lifestyle/technologie/artykuly/9391306,dlaczego-swiat-potrzebuje-miedzynarodowego-funduszu-genai-opinia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-31T06:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/WmnktkuTURBXy8zMzIzNGU4NS05OGQwLTRmMzQtODViNS03YjVjMWU0NWVkNWEuanBlZ5GTBc0BHcyg" />Błyskawiczne upowszechnianie się generatywnej sztucznej inteligencji (GenAI) jest oszałamiające. Technologia ta wniknęła w nasze życie tak, że nie ma już odwrotu – ani szansy na wstrzymanie prac nad jej rozwojem. GenAI to nie medialny szum, lecz fakt.

## Europejski przemysł zbrojeniowy, głupcze! Czy Europa tego potrzebuje?
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9391281,europejski-przemysl-zbrojeniowy-glupcze-czy-europa-tego-potrzebuje.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9391281,europejski-przemysl-zbrojeniowy-glupcze-czy-europa-tego-potrzebuje.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-31T06:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/atMktkuTURBXy84Yjc2M2YzZC0xNDBjLTQ3YmEtYmU0MS1hZDE3MmY3MDJhZTMuanBlZ5GTBc0BHcyg" />Europa musi pokazać, że jest gotowa być atutem, a nie obciążeniem dla zbiorowego bezpieczeństwa Zachodu.

## Globalna wojna modeli. Nie chodzi o modę, tylko o AI
 - [https://forsal.pl/lifestyle/technologie/artykuly/9391311,globalna-wojna-modeli-nie-chodzi-o-mode-tylko-o-ai.html](https://forsal.pl/lifestyle/technologie/artykuly/9391311,globalna-wojna-modeli-nie-chodzi-o-mode-tylko-o-ai.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-31T06:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/nmhktkuTURBXy80NGMwZjI4My1kZjMxLTQyYzktYjRjZS1hODYyYjZkZDczZDUuanBlZ5GTBc0BHcyg" />Patentują jak szaleni, inwestują miliardy. Czy to wystarczy Chinom, aby stać się globalnym imperium sztucznej inteligencji?

## Liczba urodzeń w Czechach spadła w 2 lata o ponad 20 proc. Nawet w Polsce spadek był mniejszy
 - [https://forsal.pl/gospodarka/demografia/artykuly/9391979,liczba-urodzen-w-czechach-spadla-w-2-lata-o-ponad-20-proc-nawet-w-pol.html](https://forsal.pl/gospodarka/demografia/artykuly/9391979,liczba-urodzen-w-czechach-spadla-w-2-lata-o-ponad-20-proc-nawet-w-pol.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-31T06:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/kvJktkuTURBXy9lNTEwNTE0OS01NDhkLTRhZmItYjRlOS0yMzI2ZDYwYWI2NDcuanBlZ5GTBc0BHcyg" />Liczba urodzeń spada nie tylko w Polsce. W Czechach urodziło się w ciągu pierwszych dziewięciu miesięcy znacznie mniej dzieci niż rok wcześniej. W ujęciu dwuletnim, 3. kwartał był o ponad 20 proc. słabszy. Spadek to wynik niższej dzietności Czeszek, ale także struktury wieku w Czechach. Mimo ujemnego przyrostu naturalnego populacja Czech rośnie.

## Potocki: Ukraina czeka na czarnego łabędzia [OPINIA]
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9391037,potocki-ukraina-czeka-na-czarnego-labedzia-opinia.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9391037,potocki-ukraina-czeka-na-czarnego-labedzia-opinia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-31T06:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/RrWktkuTURBXy82ZWNmNTg0ZS1iYzA2LTQ2NzktOGRlYy01YTVhYjVjYzQzZGQuanBlZ5GTBc0BHcyg" />2024 rok na Wschodzie pod wieloma względami może być decydujący. Rosjanie czekają na rezultaty listopadowych wyborów w Stanach Zjednoczonych, by zdecydować, czy opłaca im się przystępować do rozmów o pokoju, czy nie. Przez kolejne miesiące w USA i Unii Europejskiej będą ważyć się losy pomocy finansowej i wojskowej dla Ukrainy. Z kolei w marcu Władimir Putin zostanie wybrany na piątą kadencję prezydencką.

## Rosnące ceny miały wpływ na przedświąteczne zakupy Polaków. Alternatywą dla karpia okazała się… gęś
 - [https://forsal.pl/biznes/handel/artykuly/9392464,rosnace-ceny-mialy-wplyw-na-przedswiateczne-zakupy-polakow-alternatywa-dla-karpia-okazala-sie-ges.html](https://forsal.pl/biznes/handel/artykuly/9392464,rosnace-ceny-mialy-wplyw-na-przedswiateczne-zakupy-polakow-alternatywa-dla-karpia-okazala-sie-ges.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-31T06:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/5roktktTURBXy9mZjM5ZjQ5ZS04NDA3LTQyMGUtYmZlNS0wMDBjODFjNmM0NWMucG5nkZMFzQEdzKA" />Przygotowując tegoroczne święta mniej chętnie kupowaliśmy m.in. mandarynki, kapustę czy barszcz. Największym zaskoczeniem jest jednak zdecydowany odwrót Polaków od wigilijnego karpia – w tym roku aż o ponad 50 proc. rzadziej wpisywaliśmy tę rybę na listę przedświątecznych zakupów.

## Siedem wyzwań dla sektora energetycznego. Które z nich są najpilniejsze?
 - [https://forsal.pl/biznes/energetyka/artykuly/9391381,siedem-wyzwan-dla-sektora-energetycznego-ktore-z-nich-sa-najpilniejsz.html](https://forsal.pl/biznes/energetyka/artykuly/9391381,siedem-wyzwan-dla-sektora-energetycznego-ktore-z-nich-sa-najpilniejsz.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-31T06:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/eAQktkuTURBXy80YTkyNmVhZi1jNmVlLTRiOTktODFjMy0xMmRjZDBlNGZmOWUuanBlZ5GTBc0BHcyg" />Nic nie będzie miało tak dużego znaczenia dla cen energii w długim terminie jak decyzja dotycząca miksu energetycznego. A zwłaszcza programu lądowych farm wiatrowych i energetyki jądrowej.

## Nowy rok, nowy podatek. Kto zapłaci więcej za plastikowe opakowania?
 - [https://forsal.pl/finanse/aktualnosci/artykuly/9386787,nowy-podatek-od-1-stycznia-produkty-z-plastiku.html](https://forsal.pl/finanse/aktualnosci/artykuly/9386787,nowy-podatek-od-1-stycznia-produkty-z-plastiku.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-12-31T05:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/RI0ktkuTURBXy82NWM5ZTNjMi03ZDc4LTQ1NTgtYTIwYS1mYjA0ZWZlZTA3MDMuanBlZ5GTBc0BHcyg" />Od początku 2024 roku Polska wprowadza nowe regulacje dotyczące opłat za jednorazowe produkty wykonane z tworzyw sztucznych, czyli nowy podatek na produkty z tworzyw sztucznych.

