# Source:TVN24 Z kraju, URL:https://tvn24.pl/wiadomosci-z-kraju,3.xml, language:pl-PL

## Pogorszyła się jakość powietrza. Znacznie przekroczone normy
 - [https://tvn24.pl/tvnmeteo/smog/smog-w-polsce-niedziela-3112-sprawdz-jakosc-powietrza-w-swoim-miescie-st7663634?source=rss](https://tvn24.pl/tvnmeteo/smog/smog-w-polsce-niedziela-3112-sprawdz-jakosc-powietrza-w-swoim-miescie-st7663634?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-31T20:37:00+00:00

<img alt="Pogorszyła się jakość powietrza. Znacznie przekroczone normy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lufbob-smog-jakosc-powietrza-6366534/alternates/LANDSCAPE_1280" />
    Smog w niedzielę wieczorem spowija południowe miasta Polski. Złą jakość powietrza notuje się między innymi w Nowej Rudzie i Rabce-Zdroju. Sprawdź sytuację w swojej okolicy.

## Wysoka woda nie ustępuje, a synoptycy zapowiadają kolejne ulewy
 - [https://tvn24.pl/tvnmeteo/swiat/niemcy-dolna-saksonia-trudna-sytuacja-powodziowa-kanclerz-olaf-scholz-odwiedzil-zalane-tereny-st7663603?source=rss](https://tvn24.pl/tvnmeteo/swiat/niemcy-dolna-saksonia-trudna-sytuacja-powodziowa-kanclerz-olaf-scholz-odwiedzil-zalane-tereny-st7663603?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-31T19:52:00+00:00

<img alt="Wysoka woda nie ustępuje, a synoptycy zapowiadają kolejne ulewy" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-aag2qr-trudna-sytuacja-powodziowa-w-dolnej-saksonii-7663618/alternates/LANDSCAPE_1280" />
    Kanclerz Niemiec Olaf Scholz odwiedził w niedzielę zalane tereny Dolnej Saksonii w wyniku zeszłotygodniowych ulew. Podkreślił, że w północnej części tego kraju związkowego sytuacja pozostaje trudna. W prognozach na nadchodzące dni zapowiadane są następne obfite opady.

## Orędzie noworoczne prezydenta. "Wzywam koalicję rządową..."
 - [https://tvn24.pl/polska/oredzie-noworoczne-prezydenta-andrzeja-dudy-7663461?source=rss](https://tvn24.pl/polska/oredzie-noworoczne-prezydenta-andrzeja-dudy-7663461?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-31T19:02:42+00:00

<img alt="Orędzie noworoczne prezydenta. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-whmexk-oredzie_pad_tv-0001-7663450/alternates/LANDSCAPE_1280" />
    Po ośmiu latach zmieniła się w naszym kraju większość parlamentarna, ale nie zmieniło się najważniejsze zadanie, jakie stoi przed rządzącymi - to konieczność dbania o bezpieczeństwo naszej ojczyzny, o bezpieczeństwo Polek i Polaków - powiedział w orędziu noworocznym prezydent Andrzej Duda. Wezwał "koalicję rządową, żeby zaczęła przestrzegać zasad demokratycznego państwa prawa i szanować obywateli bez względu na ich poglądy polityczne". Mówił, że jest "gotowy do współpracy w najważniejszych dla Polski sprawach, ale jest również przygotowany na sytuację, że rząd takiej współpracy nie będzie chciał".

## Jaki był 2023 rok dla kobiet? "Absolutnie przełomowy. Już żadna z nas nie może powiedzieć, że nie mamy siły"
 - [https://tvn24.pl/polska/prawa-kobiet-prawa-czlowieka-wartosci-demokratyczne-dominika-lasota-barbara-labuda-i-dr-hanna-machinska-o-2023-roku-7663432?source=rss](https://tvn24.pl/polska/prawa-kobiet-prawa-czlowieka-wartosci-demokratyczne-dominika-lasota-barbara-labuda-i-dr-hanna-machinska-o-2023-roku-7663432?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-31T18:58:29+00:00

<img alt="Jaki był 2023 rok dla kobiet? " src="https://tvn24.pl/najnowsze/cdn-zdjecie-mjzrpo-31-1300-fpf-cl-0014-7663467/alternates/LANDSCAPE_1280" />
    Rok 2023 był złym dla praw kobiet, natomiast nie dla samych kobiet - oceniła w "Faktach po Faktach" działaczka opozycji w PRL Barbara Labuda. Zdaniem byłej zastępczyni RPO dr Hanny Machińskiej "to był rok nadziei", jednak obecna w nim była "straszliwa opresja wobec kobiet". - To było coś takiego, co doprowadziło nas, kobiety, a zwłaszcza młode kobiety, do wyjścia na ulice - wskazywała. Aktywistka Dominika Lasota mówiła zaś, że to rok, "po którym już żadna z nas nie może powiedzieć, że nie mamy siły i nie mamy prawa głosu". - Bo i ta nasza siła, i ten głos jest niesamowicie wielki i obala rządy - dodała.

## Sylwester 2023. Strażacy i ratownicy radzą, jak bezpiecznie odpalać fajerwerki
 - [https://fakty.tvn24.pl/zobacz-fakty/sylwester-2023-strazacy-i-ratownicy-radza-jak-bezpiecznie-odpalac-fajerwerki-st7663563?source=rss](https://fakty.tvn24.pl/zobacz-fakty/sylwester-2023-strazacy-i-ratownicy-radza-jak-bezpiecznie-odpalac-fajerwerki-st7663563?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-31T18:43:26+00:00

<img alt="Sylwester 2023. Strażacy i ratownicy radzą, jak bezpiecznie odpalać fajerwerki" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-gnjzgz-kostek-7663580/alternates/LANDSCAPE_1280" />
    Fajerwerki i petardy czasem zamiast lecieć w niebo, wpadają do mieszkań, powodują pożary, wybuchają w rękach. Wystarczy chwila nieuwagi i noc sylwestrową można zapamiętać do końca życia. Dlatego strażacy i ratownicy medyczni apelując o ostrożność, przypominają podstawowe zasady bezpieczeństwa.

## Pogoda na jutro - poniedziałek 01.01. Nowy Rok z dodatnią temperaturą i pełen opadów
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-jutro-poniedzialek-0101-nowy-rok-z-dodatnia-temperatura-i-pelen-opadow-st7663553?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-jutro-poniedzialek-0101-nowy-rok-z-dodatnia-temperatura-i-pelen-opadow-st7663553?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-31T18:19:00+00:00

<img alt="Pogoda na jutro - poniedziałek 01.01. Nowy Rok z dodatnią temperaturą i pełen opadów" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-atq0x4-popada-deszcz-snieg-i-deszcz-ze-sniegiem-6810720/alternates/LANDSCAPE_1280" />
    Pogoda na jutro. Poniedziałek 01.01, Nowy Rok, prawie w całym kraju zapowiada się deszczowo. W niektórych regionach spadnie również deszcz ze śniegiem. Termometry wskażą od 1 do 8 stopni Celsjusza.

## Na sportowo, w gronie najbliższych czy w domowym zaciszu? Plany Polaków na sylwestra
 - [https://fakty.tvn24.pl/fakty-po-poludniu/plany-polakow-na-sylwestra-na-sportowo-w-gronie-najblizszych-czy-w-domowym-zaciszu-st7663436?source=rss](https://fakty.tvn24.pl/fakty-po-poludniu/plany-polakow-na-sylwestra-na-sportowo-w-gronie-najblizszych-czy-w-domowym-zaciszu-st7663436?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-31T16:09:53+00:00

<img alt="Na sportowo, w gronie najbliższych czy w domowym zaciszu? Plany Polaków na sylwestra" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-sgey67-chacinska-7663452/alternates/LANDSCAPE_1280" />
    Wiele osób postawiło na sportowo spędzić ostatni dzień roku i wziąć udział w biegach organizowanych w Krakowie czy w Łodzi. W Sławatyczach z kolei stary rok pożegnali brodacze, a na rynku w Gnieźnie spotkali się właściciele koni, by złożyć sobie noworoczne życzenia. A jak wielu z nas spędza sylwestrową noc? Większość w gronie najbliższych i przyjaciół.

## 13-latek zabrał mamie kluczyki i ruszył autem do dziewczyny. Podróż zakończył na słupie
 - [https://tvn24.pl/lublin/klebow-13-latek-zabral-mamie-kluczyki-i-ruszyl-autem-do-dziewczyny-podroz-zakonczyl-na-slupie-7663384?source=rss](https://tvn24.pl/lublin/klebow-13-latek-zabral-mamie-kluczyki-i-ruszyl-autem-do-dziewczyny-podroz-zakonczyl-na-slupie-7663384?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-31T15:28:41+00:00

<img alt="13-latek zabrał mamie kluczyki i ruszył autem do dziewczyny. Podróż zakończył na słupie " src="https://tvn24.pl/najnowsze/cdn-zdjecie-dcxvfu-chlopcu-na-szczescie-nic-sie-nie-stalo-sprawa-zajmie-sie-sad-rodzinny-7663388/alternates/LANDSCAPE_1280" />
    Sąd rodzinny zajmie się sprawą 13-latka, który w miejscowości Kłębów (woj. lubelskie) rozbił samochód swojej matki na słupie oświetleniowym. Jak przekazała policja, chłopiec zabrał kluczyki do auta i chciał pojechać do dziewczyny.

## Dowód, prawo jazdy, weksel. Fałszerze z Bazaru Różyckiego staną przed sądem
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-falszerze-z-bazaru-rozyckiego-stana-przed-sadem-st7653434?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-falszerze-z-bazaru-rozyckiego-stana-przed-sadem-st7653434?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-31T15:02:33+00:00

<img alt="Dowód, prawo jazdy, weksel. Fałszerze z Bazaru Różyckiego staną przed sądem " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-46yj0f-wpadli-kolejni-czlonkowie-gangu-praskich-falszerzy-dokumentow-6749070/alternates/LANDSCAPE_1280" />
    Dowody osobiste, prawa jazdy, świadectwa ukończenia szkół, akty notarialne czy weksle. Na Bazarze Różyckiego można było kupić falsyfikat niemal każdego z dokumentów. Jak to możliwe? Śledczy rozbili dużą grupę przestępczą, która trudniła się tym od lat. Kilkadziesiąt osób stanie w tej sprawie przed sądem.

## Wypadek awionetki. Samolot rozbił się w lesie, ucierpiał pilot i pasażer
 - [https://tvn24.pl/poznan/slonawy-k-obornik-awionetka-rozbila-sie-w-lesie-ucierpialpilot-i-pasazer-7663342?source=rss](https://tvn24.pl/poznan/slonawy-k-obornik-awionetka-rozbila-sie-w-lesie-ucierpialpilot-i-pasazer-7663342?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-31T14:42:42+00:00

<img alt="Wypadek awionetki. Samolot rozbił się w lesie, ucierpiał pilot i pasażer" src="https://tvn24.pl/najnowsze/cdn-zdjecie-71h8hs-samolot-rozbil-sie-w-lesie-7663356/alternates/LANDSCAPE_1280" />
    Ultralekki samolot rozbił się niedaleko lądowiska w Słonawach (woj. wielkopolskie). W maszynie znajdował się 55-letni pilot i 42-letni pasażer. Po wypadku pierwszy mężczyzna uskarżał się na ból w klatce piersiowej i ogólne potłuczenia, drugi miał złamany palec ręki. Filmy z miejsca zdarzenia dostaliśmy na Kontakt 24.

## W 2024 roku popracujemy dłużej
 - [https://tvn24.pl/biznes/dla-pracownika/czas-pracy-w-2024-roku-pracownicy-przepracuja-wiecej-godzin-niz-w-2023-roku-wyliczenia-infakt-st7663282?source=rss](https://tvn24.pl/biznes/dla-pracownika/czas-pracy-w-2024-roku-pracownicy-przepracuja-wiecej-godzin-niz-w-2023-roku-wyliczenia-infakt-st7663282?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-31T14:32:54+00:00

<img alt="W 2024 roku popracujemy dłużej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-339elw-firma-4686716/alternates/LANDSCAPE_1280" />
    W 2024 roku pracownicy przepracują 251 dni - policzyła firma inFakt. To o jeden dzień więcej niż w tym roku. Najwięcej dni pracy w ciągu jednego miesiąca wypada w lipcu i październiku. Z kolei najwięcej okazji do odpoczynku będzie w maju, listopadzie oraz grudniu.

## "Jechało się jak w jakimś kanionie", setki autobusów utknęły w zaspach. 45 lat od ataku zimy stulecia
 - [https://tvn24.pl/tvnwarszawa/najnowsze/jechalo-sie-jak-w-jakims-kanionie-setki-autobusow-utknely-w-zaspach-45-lat-od-ataku-zimy-stulecia-st7662926?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/jechalo-sie-jak-w-jakims-kanionie-setki-autobusow-utknely-w-zaspach-45-lat-od-ataku-zimy-stulecia-st7662926?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-31T14:17:15+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2n93dg-droga-z-haldami-sniegu-7663286/alternates/LANDSCAPE_1280" />
    31 grudnia 1978 r. w całej Polsce nastąpiły gwałtowne opady śniegu. - Zima stulecia była katalizatorem w procesie upadku rządów Edwarda Gierka w PRL. System okazał się niewydolny, a skala paraliżu - porażająca - ocenia prof. Andrzej Zawistowski, historyk i ekonomista, wykładowca Szkoły Głównej Handlowej w Warszawie.

## Auto wjechało w drzewo. Trzy osoby nie żyją
 - [https://tvn24.pl/katowice/gliwice-smiertelny-wypadek-auto-wjechalo-w-drzewo-trzy-osoby-nie-zyja-7663275?source=rss](https://tvn24.pl/katowice/gliwice-smiertelny-wypadek-auto-wjechalo-w-drzewo-trzy-osoby-nie-zyja-7663275?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-31T13:36:29+00:00

<img alt="Auto wjechało w drzewo. Trzy osoby nie żyją" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7pdcts-policja-7523531/alternates/LANDSCAPE_1280" />
    Trzej mężczyźni zginęli w niedzielę po południu w wypadku drogowym, do którego doszło na pograniczu Gliwic i Żernicy (woj. śląskie). Samochód, którym jechali uderzył w drzewo. Ofiary to obywatele Ukrainy.

## Są pierwsze pieniądze na remont "Jowity". Minister przekazał pół miliona złotych
 - [https://tvn24.pl/poznan/poznan-sa-pierwsze-srodki-na-remont-domu-studenckiego-jowita-7663252?source=rss](https://tvn24.pl/poznan/poznan-sa-pierwsze-srodki-na-remont-domu-studenckiego-jowita-7663252?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-31T12:56:06+00:00

<img alt="Są pierwsze pieniądze na remont " src="https://tvn24.pl/najnowsze/cdn-zdjecie-lilvbz-od-piatkowego-wieczoru-kilkadziesiat-osob-okupuje-ds-jowita-w-poznaniu-7543791/alternates/LANDSCAPE_1280" />
    Pół miliona złotych na organizację konkursu architektonicznego na modernizację i przebudowę Domu Studenckiego "Jowita" otrzymał Uniwersytet im. Adama Mickiewicza w Poznaniu od ministra nauki Dariusza Wieczorka. W połowie grudnia obiecał on protestującym studentom, że akademik zostanie uratowany.

## Zwęzili jednię na popularnym mostku, mieszkańcy narzekają. "Kierowcy muszą się przyzwyczaić"
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-zwezenie-jedni-na-mostku-w-wawrze-mieszkancy-narzekaja-zdm-odpowiada-st7662906?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-zwezenie-jedni-na-mostku-w-wawrze-mieszkancy-narzekaja-zdm-odpowiada-st7662906?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-31T12:39:23+00:00

<img alt="Zwęzili jednię na popularnym mostku, mieszkańcy narzekają. " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-4wlvd3-zwezenie-jezdni-na-mostku-na-ulicy-lucerny-7663089/alternates/LANDSCAPE_1280" />
    Stołeczni drogowcy zdecydowali się na zwężenie jezdni na mostku na ulicy Lucerny w Wawrze. Decyzję tłumaczyli względami bezpieczeństwa. Teraz jednak narzekają mieszkańcy. Ich zdaniem rozwiązanie zaproponowane przez Zarząd Dróg Miejskich doprowadza do niebezpiecznych sytuacji.

## Ranił dwie osoby, w tym jedną ciężko. Uszkodził też pięć samochodów
 - [https://tvn24.pl/wroclaw/legnica-nozownik-ranil-dwie-osoby-w-tym-jedna-ciezko-uszkodzil-tez-piecsamochodow-przy-zlotego-florena-7663209?source=rss](https://tvn24.pl/wroclaw/legnica-nozownik-ranil-dwie-osoby-w-tym-jedna-ciezko-uszkodzil-tez-piecsamochodow-przy-zlotego-florena-7663209?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-31T12:26:04+00:00

<img alt="Ranił dwie osoby, w tym jedną ciężko. Uszkodził też pięć samochodów" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-f3dyfy-mezczyzna-zostal-zatrzymany-7663212/alternates/LANDSCAPE_1280" />
    Policjanci w Legnicy zatrzymali 30-latka, który w nocy uszkodził pięć samochodów przy ulicy Złotego Florena. Funkcjonariusze ustalili, że ten sam mężczyzna miał tej samej nocy ciężko ranić nożem dwie osoby. Jedna z nich trafiła w ciężkim stanie do szpitala.

## Pożar w mieszkaniu nad ośrodkiem zdrowia. Strażacy wynieśli 77-latka
 - [https://tvn24.pl/opole/burgrabice-nocny-pozar-strazacy-wyniesli-z-budynku-77-latka-7663140?source=rss](https://tvn24.pl/opole/burgrabice-nocny-pozar-strazacy-wyniesli-z-budynku-77-latka-7663140?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-31T11:27:57+00:00

<img alt="Pożar w mieszkaniu nad ośrodkiem zdrowia. Strażacy wynieśli 77-latka" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5lg6dr-pozar-w-budynku-osrodka-zdrowia-w-burgrabicach-kolo-glucholaz-7663141/alternates/LANDSCAPE_1280" />
    W nocy z soboty na niedzielę wybuchł pożar w budynku mieszkalno-usługowym w Burgrabicach koło Głuchołaz (woj. opolskie). Jak poinformowała straż pożarna, do szpitala przewieziono 77-letniego mieszkańca jednego z lokali.

## Tajemnicze zatrucie na poczcie w Wągrowcu. Policja bada sprawę
 - [https://tvn24.pl/poznan/wagrowiec-tajemnicze-zatrucie-na-poczcie-policja-bada-sprawe-7663024?source=rss](https://tvn24.pl/poznan/wagrowiec-tajemnicze-zatrucie-na-poczcie-policja-bada-sprawe-7663024?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-31T10:55:33+00:00

<img alt="Tajemnicze zatrucie na poczcie w Wągrowcu. Policja bada sprawę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1iophf-12-osob-skarzylo-sie-na-zle-samopoczucie-7663025/alternates/LANDSCAPE_1280" />
    Policja wszczyna postępowanie sprawdzające w związku z piątkowym zdarzeniem na poczcie w Wągrowcu (woj. wielkopolskie). W budynku kilkanaście osób źle się poczuło, cztery trafiły do szpitala.

## Tory przez dawny obóz pracy, dworzec w miejscu mogił ofiar Holokaustu. "Nie wykluczamy zmiany"
 - [https://tvn24.pl/lublin/krasnik-tory-maja-biec-przez-dawny-oboz-pracy-budzyn-koleje-nie-wykluczaja-zmiany-przebiegu-trasy-7642922?source=rss](https://tvn24.pl/lublin/krasnik-tory-maja-biec-przez-dawny-oboz-pracy-budzyn-koleje-nie-wykluczaja-zmiany-przebiegu-trasy-7642922?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-12-31T10:27:06+00:00

<img alt="Tory przez dawny obóz pracy, dworzec w miejscu mogił ofiar Holokaustu. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ypprtm-dworzec-ma-byc-zlokalizowany-w-miejscu-zbiorowej-mogily-7642944/alternates/LANDSCAPE_1280" />
    Linia kolejowa biegnąca przez las, w którym zachowały się relikty obozu pracy Budzyń – podobozu "Majdanka", oraz dworzec kolejowy w miejscu, gdzie mogą być mogiły ofiar Holokaustu. Po tym, jak sprawą zainteresował się społeczny opiekun zabytków oraz służby konserwatorskie, kolejarze nie wykluczają zmiany przebiegu trasy.

