# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## I’m Keeping the World’s Biggest TV.
 - [https://www.youtube.com/watch?v=d8dlz5LWq3E](https://www.youtube.com/watch?v=d8dlz5LWq3E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2023-12-31T16:54:58+00:00

Thanks to MANSCAPED for sponsoring today's video. Get 20% Off + Free International Shipping with promo code TECHTIPS or visit http://manscaped.com/techtips

Check out MotionGrey’s ergonomic workplace solutions at https://lmg.gg/motiongrey and use code LINUS for 10% off!

I bought the TCL X11G Max, the biggest single-piece TV on the market at 115”. Actually, it’s not really on the market as it’s China-only but I somehow got it here and three people mounted it on my wall. But now that it’s set up, is it any good? Does it REALLY have over 20,000 local dimming zones? Are giant TVs going to destroy the market for projectors??

Buy an Alienware AW3423DW 34" 175Hz QD-OLED Curved Monitor: https://geni.us/uI3BPnL

Purchases made through some store links may provide some compensation to Linus Media Group.

Discuss on the forum: https://linustechtips.com/topic/1550175-i%E2%80%99m-keeping-the-world%E2%80%99s-biggest-tv/

► GET MERCH: https://lttstore.com
► GET EXCLUSIVE CONTENT ON FLOATPLANE: ht

