# Source:Nerdrotic, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC5T0tXJN5CrMZUEJuz4oovw, language:en-US

## Top 5 Woke Hollywood DISASTERS of 2023
 - [https://www.youtube.com/watch?v=GM9H02WvAHs](https://www.youtube.com/watch?v=GM9H02WvAHs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC5T0tXJN5CrMZUEJuz4oovw
 - date published: 2023-12-31T22:29:51+00:00

2023 was the Year Woke Hollywood FAILED, and that's a good thing.
#hollywood #disney #marvel 

Edited by @PierryChan 

Become a Nerdrotic Channel Member
www.youtube.com/c/sutrowatchtower/join

Special thanks to @QTRBlackGarrett @XrayGirl_ @LadyGravemaster @MauLerYT @HeelvsBabyface @FilmThreat 

Please subscribe to the Nerdrotic Network: @nerdrotic @NerdroticLive @NerdroticDaily 

FLEUR - Bang Bang (My Baby Shot Me Down)
https://www.youtube.com/watch?v=RVMQZTDQDNY

Chapters:
Intro: 00:00
Number 6 00:40
Number 5 04:58
Number 4 10:12
Number 3 15:00
Number 2 20:15
Dishonorable Mentions 25:35
Number 1 27:45

Nerdrotic Merch Store!
https://mixedtees.com/nerdrotic

FNT T-Shirt!
https://mixedtees.com/nerdrotic/friday-night-tights

Sponsored by MetaPCs!
Click here to get a discount on a PC: http://Metapcs.com/Nerdrotic/ref

Sponsored by GEEK GRIND!
Nerdrotic Blend Coffee from Geek Grind
Use Promo Code "Nerdrotic" for 20% off:
https://geekgrindcoffee.com/products/...

Nerdrotic Coffee Cup from

