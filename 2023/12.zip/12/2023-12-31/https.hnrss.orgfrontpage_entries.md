# Source:Hacker News - frontpage, URL:https://hnrss.org/frontpage, language:en-US

## Bazzite – a Steam0S-like OCI image for desktop, living room, and handheld PCs
 - [https://github.com/ublue-os/bazzite](https://github.com/ublue-os/bazzite)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-31T22:21:56+00:00

<p>Article URL: <a href="https://github.com/ublue-os/bazzite">https://github.com/ublue-os/bazzite</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38828040">https://news.ycombinator.com/item?id=38828040</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## Molecular jackhammers eradicate cancer cells by vibronic-driven action
 - [https://www.nature.com/articles/s41557-023-01383-y](https://www.nature.com/articles/s41557-023-01383-y)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-31T21:21:30+00:00

<p>Article URL: <a href="https://www.nature.com/articles/s41557-023-01383-y">https://www.nature.com/articles/s41557-023-01383-y</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38827620">https://news.ycombinator.com/item?id=38827620</a></p>
<p>Points: 9</p>
<p># Comments: 1</p>

## Half of High School Seniors Won't Apply to Colleges Costing More Than $40k
 - [https://www.forbes.com/sites/emmawhitford/2023/11/07/half-of-high-school-seniors-wont-apply-to-colleges-costing-more-than-40000](https://www.forbes.com/sites/emmawhitford/2023/11/07/half-of-high-school-seniors-wont-apply-to-colleges-costing-more-than-40000)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-31T20:45:42+00:00

<p>Article URL: <a href="https://www.forbes.com/sites/emmawhitford/2023/11/07/half-of-high-school-seniors-wont-apply-to-colleges-costing-more-than-40000/">https://www.forbes.com/sites/emmawhitford/2023/11/07/half-of-high-school-seniors-wont-apply-to-colleges-costing-more-than-40000/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38827388">https://news.ycombinator.com/item?id=38827388</a></p>
<p>Points: 31</p>
<p># Comments: 39</p>

## 2023: Year in Review
 - [https://jvns.ca/blog/2023/12/31/2023--year-in-review](https://jvns.ca/blog/2023/12/31/2023--year-in-review)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-31T19:59:33+00:00

<p>Article URL: <a href="https://jvns.ca/blog/2023/12/31/2023--year-in-review/">https://jvns.ca/blog/2023/12/31/2023--year-in-review/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38827026">https://news.ycombinator.com/item?id=38827026</a></p>
<p>Points: 9</p>
<p># Comments: 1</p>

## Test Smarter, Not Harder: Focus on Outcomes, Not Outputs
 - [https://markus.oberlehner.net/blog/test-smarter-not-harder-focus-on-outcomes-not-outputs](https://markus.oberlehner.net/blog/test-smarter-not-harder-focus-on-outcomes-not-outputs)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-31T19:16:11+00:00

<p>Article URL: <a href="https://markus.oberlehner.net/blog/test-smarter-not-harder-focus-on-outcomes-not-outputs/">https://markus.oberlehner.net/blog/test-smarter-not-harder-focus-on-outcomes-not-outputs/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38826649">https://news.ycombinator.com/item?id=38826649</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## Meta could pull off the most extraordinary pivot in tech history
 - [https://www.fromjason.xyz/p/notebook/copy-acquire-kill-how-meta-could-pull-off-the-most-extraordinary-pivot-in-tech-history](https://www.fromjason.xyz/p/notebook/copy-acquire-kill-how-meta-could-pull-off-the-most-extraordinary-pivot-in-tech-history)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-31T19:13:01+00:00

<p>Article URL: <a href="https://www.fromjason.xyz/p/notebook/copy-acquire-kill-how-meta-could-pull-off-the-most-extraordinary-pivot-in-tech-history/">https://www.fromjason.xyz/p/notebook/copy-acquire-kill-how-meta-could-pull-off-the-most-extraordinary-pivot-in-tech-history/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38826617">https://news.ycombinator.com/item?id=38826617</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## Happy New Year HN!
 - [https://news.ycombinator.com/item?id=38826283](https://news.ycombinator.com/item?id=38826283)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-31T18:33:34+00:00

<p>I spend too much time on HN. But of all the places on the internet, this is the only place which feels worth visiting multiple times a day!<p>Wishing everyone a great 2024!</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38826283">https://news.ycombinator.com/item?id=38826283</a></p>
<p>Points: 338</p>
<p># Comments: 77</p>

## Electric school buses more than doubled in USA from March 2022 to June 2023
 - [https://cleantechnica.com/2023/12/29/electric-school-buses-more-than-doubled-in-usa-from-march-2022-to-june-2023](https://cleantechnica.com/2023/12/29/electric-school-buses-more-than-doubled-in-usa-from-march-2022-to-june-2023)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-31T18:28:41+00:00

<p>Article URL: <a href="https://cleantechnica.com/2023/12/29/electric-school-buses-more-than-doubled-in-usa-from-march-2022-to-june-2023/">https://cleantechnica.com/2023/12/29/electric-school-buses-more-than-doubled-in-usa-from-march-2022-to-june-2023/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38826242">https://news.ycombinator.com/item?id=38826242</a></p>
<p>Points: 11</p>
<p># Comments: 2</p>

## Interesting double-poly latches inside AMD's vintage LANCE Ethernet chip
 - [https://www.righto.com/2023/12/amd-lance-ethernet-double-poly.html](https://www.righto.com/2023/12/amd-lance-ethernet-double-poly.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-31T18:20:55+00:00

<p>Article URL: <a href="https://www.righto.com/2023/12/amd-lance-ethernet-double-poly.html">https://www.righto.com/2023/12/amd-lance-ethernet-double-poly.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38826187">https://news.ycombinator.com/item?id=38826187</a></p>
<p>Points: 10</p>
<p># Comments: 2</p>

## WWII heroics of 'Bazooka Charlie' doubted until daughter sets record straight
 - [https://www.dispatch.com/story/news/local/2023/12/31/bazooka-charlies-granville-daughter-shares-wwii-heroics-in-new-book/72033226007](https://www.dispatch.com/story/news/local/2023/12/31/bazooka-charlies-granville-daughter-shares-wwii-heroics-in-new-book/72033226007)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-31T18:13:16+00:00

<p>Article URL: <a href="https://www.dispatch.com/story/news/local/2023/12/31/bazooka-charlies-granville-daughter-shares-wwii-heroics-in-new-book/72033226007/">https://www.dispatch.com/story/news/local/2023/12/31/bazooka-charlies-granville-daughter-shares-wwii-heroics-in-new-book/72033226007/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38826130">https://news.ycombinator.com/item?id=38826130</a></p>
<p>Points: 11</p>
<p># Comments: 1</p>

## Get your work recognized: write a brag document
 - [https://jvns.ca/blog/brag-documents](https://jvns.ca/blog/brag-documents)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-31T17:58:48+00:00

<p>Article URL: <a href="https://jvns.ca/blog/brag-documents/">https://jvns.ca/blog/brag-documents/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38826014">https://news.ycombinator.com/item?id=38826014</a></p>
<p>Points: 9</p>
<p># Comments: 5</p>

## Warchalking
 - [https://en.wikipedia.org/wiki/Warchalking](https://en.wikipedia.org/wiki/Warchalking)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-31T17:44:58+00:00

<p>Article URL: <a href="https://en.wikipedia.org/wiki/Warchalking">https://en.wikipedia.org/wiki/Warchalking</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38825884">https://news.ycombinator.com/item?id=38825884</a></p>
<p>Points: 13</p>
<p># Comments: 4</p>

## Sony software updates breaks movie theater projectors
 - [https://bsky.app/profile/donohoe.dev/post/3khu7w2kz7l2b](https://bsky.app/profile/donohoe.dev/post/3khu7w2kz7l2b)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-31T17:20:51+00:00

<p>Article URL: <a href="https://bsky.app/profile/donohoe.dev/post/3khu7w2kz7l2b">https://bsky.app/profile/donohoe.dev/post/3khu7w2kz7l2b</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38825623">https://news.ycombinator.com/item?id=38825623</a></p>
<p>Points: 22</p>
<p># Comments: 0</p>

## How to run a small social network
 - [https://runyourown.social](https://runyourown.social)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-31T17:08:13+00:00

<p>Article URL: <a href="https://runyourown.social/">https://runyourown.social/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38825520">https://news.ycombinator.com/item?id=38825520</a></p>
<p>Points: 32</p>
<p># Comments: 14</p>

## Logistic Regression for Image Classification Using OpenCV
 - [https://machinelearningmastery.com/logistic-regression-for-image-classification-using-opencv](https://machinelearningmastery.com/logistic-regression-for-image-classification-using-opencv)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-31T16:26:37+00:00

<p>Article URL: <a href="https://machinelearningmastery.com/logistic-regression-for-image-classification-using-opencv/">https://machinelearningmastery.com/logistic-regression-for-image-classification-using-opencv/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38825158">https://news.ycombinator.com/item?id=38825158</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## Ambient Co-Presence
 - [https://maggieappleton.com/ambient-copresence](https://maggieappleton.com/ambient-copresence)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-31T15:54:55+00:00

<p>Article URL: <a href="https://maggieappleton.com/ambient-copresence">https://maggieappleton.com/ambient-copresence</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38824886">https://news.ycombinator.com/item?id=38824886</a></p>
<p>Points: 8</p>
<p># Comments: 1</p>

## iOS Wi-Fi Profile Generator
 - [https://daduckmsft.github.io/WiFiProfileGenerator](https://daduckmsft.github.io/WiFiProfileGenerator)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-31T15:25:49+00:00

<p>Article URL: <a href="https://daduckmsft.github.io/WiFiProfileGenerator/">https://daduckmsft.github.io/WiFiProfileGenerator/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38824644">https://news.ycombinator.com/item?id=38824644</a></p>
<p>Points: 23</p>
<p># Comments: 8</p>

## Synctify – Sync a music drop with a time in the real world
 - [https://synctify.app](https://synctify.app)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-31T15:05:32+00:00

<p>Article URL: <a href="https://synctify.app">https://synctify.app</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38824504">https://news.ycombinator.com/item?id=38824504</a></p>
<p>Points: 5</p>
<p># Comments: 2</p>

## Farewell, Java stingaree: Scientist declare the first marine fish extinction
 - [https://news.mongabay.com/2023/12/farewell-java-stingaree-scientist-declare-the-first-marine-fish-extinction](https://news.mongabay.com/2023/12/farewell-java-stingaree-scientist-declare-the-first-marine-fish-extinction)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-31T14:12:48+00:00

<p>Article URL: <a href="https://news.mongabay.com/2023/12/farewell-java-stingaree-scientist-declare-the-first-marine-fish-extinction/">https://news.mongabay.com/2023/12/farewell-java-stingaree-scientist-declare-the-first-marine-fish-extinction/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38824149">https://news.ycombinator.com/item?id=38824149</a></p>
<p>Points: 11</p>
<p># Comments: 1</p>

## Genuary 2024: Generative Art / Creative Coding Month
 - [https://genuary.art](https://genuary.art)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-31T14:09:15+00:00

<p>Article URL: <a href="https://genuary.art">https://genuary.art</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38824121">https://news.ycombinator.com/item?id=38824121</a></p>
<p>Points: 9</p>
<p># Comments: 1</p>

## A Modern Web for Hacker News – Open-Source and Seeking Feedback
 - [https://modern-hacker-news.vercel.app](https://modern-hacker-news.vercel.app)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-31T14:00:00+00:00

<p>Article URL: <a href="https://modern-hacker-news.vercel.app/">https://modern-hacker-news.vercel.app/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38824070">https://news.ycombinator.com/item?id=38824070</a></p>
<p>Points: 4</p>
<p># Comments: 7</p>

## January 1, 2024 is Public Domain Day
 - [https://web.law.duke.edu/cspd/publicdomainday/2024](https://web.law.duke.edu/cspd/publicdomainday/2024)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-31T13:40:20+00:00

<p>Article URL: <a href="https://web.law.duke.edu/cspd/publicdomainday/2024/">https://web.law.duke.edu/cspd/publicdomainday/2024/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38823973">https://news.ycombinator.com/item?id=38823973</a></p>
<p>Points: 18</p>
<p># Comments: 0</p>

## Instant Messaging: Protocols Are "Commons", Let's Take Them Seriously
 - [https://www.process-one.net/blog/instant-messaging-protocols-are-commons-lets-take-them-seriously](https://www.process-one.net/blog/instant-messaging-protocols-are-commons-lets-take-them-seriously)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-31T13:13:05+00:00

<p>Article URL: <a href="https://www.process-one.net/blog/instant-messaging-protocols-are-commons-lets-take-them-seriously/">https://www.process-one.net/blog/instant-messaging-protocols-are-commons-lets-take-them-seriously/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38823819">https://news.ycombinator.com/item?id=38823819</a></p>
<p>Points: 19</p>
<p># Comments: 6</p>

## Email addresses are not good 'permanent' identifiers for accounts
 - [https://utcc.utoronto.ca/~cks/space/blog/tech/EmailAddressesBadPermanentIDs](https://utcc.utoronto.ca/~cks/space/blog/tech/EmailAddressesBadPermanentIDs)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-31T13:13:00+00:00

<p>Article URL: <a href="https://utcc.utoronto.ca/~cks/space/blog/tech/EmailAddressesBadPermanentIDs">https://utcc.utoronto.ca/~cks/space/blog/tech/EmailAddressesBadPermanentIDs</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38823817">https://news.ycombinator.com/item?id=38823817</a></p>
<p>Points: 42</p>
<p># Comments: 16</p>

## There is an oom kill count in Linux
 - [https://medium.com/opsops/there-is-an-oom-kill-count-in-linux-e9936aa33102](https://medium.com/opsops/there-is-an-oom-kill-count-in-linux-e9936aa33102)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-31T12:49:04+00:00

<p>Article URL: <a href="https://medium.com/opsops/there-is-an-oom-kill-count-in-linux-e9936aa33102">https://medium.com/opsops/there-is-an-oom-kill-count-in-linux-e9936aa33102</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38823719">https://news.ycombinator.com/item?id=38823719</a></p>
<p>Points: 16</p>
<p># Comments: 3</p>

## Bun, JavaScript, and TCO
 - [https://www.onsclom.net/posts/javascript-tco](https://www.onsclom.net/posts/javascript-tco)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-31T12:40:39+00:00

<p>Article URL: <a href="https://www.onsclom.net/posts/javascript-tco">https://www.onsclom.net/posts/javascript-tco</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38823673">https://news.ycombinator.com/item?id=38823673</a></p>
<p>Points: 16</p>
<p># Comments: 4</p>

## The Forecasting Fallacy
 - [https://www.alexmurrell.co.uk/articles/the-forecasting-fallacy](https://www.alexmurrell.co.uk/articles/the-forecasting-fallacy)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-31T12:16:36+00:00

<p>Article URL: <a href="https://www.alexmurrell.co.uk/articles/the-forecasting-fallacy">https://www.alexmurrell.co.uk/articles/the-forecasting-fallacy</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38823542">https://news.ycombinator.com/item?id=38823542</a></p>
<p>Points: 3</p>
<p># Comments: 2</p>

## 7 watts idle – building a low powered server/NAS on Intel 12th/13th gen
 - [https://mattgadient.com/7-watts-idle-on-intel-12th-13th-gen-the-foundation-for-building-a-low-power-server-nas](https://mattgadient.com/7-watts-idle-on-intel-12th-13th-gen-the-foundation-for-building-a-low-power-server-nas)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-31T12:10:52+00:00

<p>Article URL: <a href="https://mattgadient.com/7-watts-idle-on-intel-12th-13th-gen-the-foundation-for-building-a-low-power-server-nas/">https://mattgadient.com/7-watts-idle-on-intel-12th-13th-gen-the-foundation-for-building-a-low-power-server-nas/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38823514">https://news.ycombinator.com/item?id=38823514</a></p>
<p>Points: 32</p>
<p># Comments: 9</p>

## Sweden Solar System
 - [https://en.wikipedia.org/wiki/Sweden_Solar_System](https://en.wikipedia.org/wiki/Sweden_Solar_System)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-31T12:04:23+00:00

<p>Article URL: <a href="https://en.wikipedia.org/wiki/Sweden_Solar_System">https://en.wikipedia.org/wiki/Sweden_Solar_System</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38823482">https://news.ycombinator.com/item?id=38823482</a></p>
<p>Points: 23</p>
<p># Comments: 2</p>

## A future for SQL on the web (2021)
 - [https://jlongster.com/future-sql-web](https://jlongster.com/future-sql-web)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-31T11:56:29+00:00

<p>Article URL: <a href="https://jlongster.com/future-sql-web">https://jlongster.com/future-sql-web</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38823445">https://news.ycombinator.com/item?id=38823445</a></p>
<p>Points: 10</p>
<p># Comments: 0</p>

## A 1690s Peanut is Reborn
 - [https://nationalpeanutboard.org/news/a-1690s-peanut-is-reborn](https://nationalpeanutboard.org/news/a-1690s-peanut-is-reborn)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-31T11:28:25+00:00

<p>Article URL: <a href="https://nationalpeanutboard.org/news/a-1690s-peanut-is-reborn/">https://nationalpeanutboard.org/news/a-1690s-peanut-is-reborn/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38823304">https://news.ycombinator.com/item?id=38823304</a></p>
<p>Points: 29</p>
<p># Comments: 7</p>

## Mazzle – A Pipelines as Code Tool
 - [https://devops-pipeline.com](https://devops-pipeline.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-31T11:15:08+00:00

<p>Article URL: <a href="http://devops-pipeline.com/">http://devops-pipeline.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38823252">https://news.ycombinator.com/item?id=38823252</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## I forked SteamOS for my living room PC
 - [https://iliana.fyi/blog/build-your-own-steamos-updates](https://iliana.fyi/blog/build-your-own-steamos-updates)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-31T10:45:33+00:00

<p>Article URL: <a href="https://iliana.fyi/blog/build-your-own-steamos-updates/">https://iliana.fyi/blog/build-your-own-steamos-updates/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38823101">https://news.ycombinator.com/item?id=38823101</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## Emacs-copilot: Large language model code completion for Emacs
 - [https://github.com/jart/emacs-copilot](https://github.com/jart/emacs-copilot)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-31T05:59:11+00:00

<p>Article URL: <a href="https://github.com/jart/emacs-copilot">https://github.com/jart/emacs-copilot</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38822164">https://news.ycombinator.com/item?id=38822164</a></p>
<p>Points: 153</p>
<p># Comments: 46</p>

## Pascal in Forth (1983)
 - [https://tangentstorm.github.io/winfield-pascal-83.html](https://tangentstorm.github.io/winfield-pascal-83.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-31T05:38:44+00:00

<p>Article URL: <a href="http://tangentstorm.github.io/winfield-pascal-83.html">http://tangentstorm.github.io/winfield-pascal-83.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38822094">https://news.ycombinator.com/item?id=38822094</a></p>
<p>Points: 66</p>
<p># Comments: 7</p>

## Design Principles Behind Smalltalk (1981)
 - [https://www.cs.virginia.edu/~evans/cs655/readings/smalltalk.html](https://www.cs.virginia.edu/~evans/cs655/readings/smalltalk.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-31T03:36:01+00:00

<p>Article URL: <a href="https://www.cs.virginia.edu/~evans/cs655/readings/smalltalk.html">https://www.cs.virginia.edu/~evans/cs655/readings/smalltalk.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38821506">https://news.ycombinator.com/item?id=38821506</a></p>
<p>Points: 33</p>
<p># Comments: 4</p>

## Compare Google, Bing, Marginalia, Kagi, Mwmbl, and ChatGPT
 - [https://danluu.com/seo-spam](https://danluu.com/seo-spam)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-31T02:32:22+00:00

<p>Article URL: <a href="https://danluu.com/seo-spam/">https://danluu.com/seo-spam/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38821248">https://news.ycombinator.com/item?id=38821248</a></p>
<p>Points: 576</p>
<p># Comments: 257</p>

## Building ColdFusion for the Web
 - [https://thehistoryoftheweb.com/building-coldfusion-for-the-web](https://thehistoryoftheweb.com/building-coldfusion-for-the-web)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-31T02:28:56+00:00

<p>Article URL: <a href="https://thehistoryoftheweb.com/building-coldfusion-for-the-web/">https://thehistoryoftheweb.com/building-coldfusion-for-the-web/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38821224">https://news.ycombinator.com/item?id=38821224</a></p>
<p>Points: 46</p>
<p># Comments: 31</p>

## Show HN: Spindle, a cross between Wordle and a Rubik's Cube made in PHP
 - [https://playspindle.com](https://playspindle.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-31T02:20:44+00:00

<p>Hi HN,<p>I was late to wordle, so I am also late to making my own version.<p>In Spindle, you rotate words on a grid with the aim of assembling the day’s target word. I enjoy it, so I thought some of you might enjoy it too.<p>From a tech perspective, it’s a very simple Laravel / Livewire app. My happy place in recent years has been Typescript and SvelteKit, so this was a bit of an adjustment, but it allowed me to take advantage of an existing shared hosting server meaning no additional financial outlay. Happy to report a positive experience with PHP and this framework, although I do miss types! Deploying with rsync feels enjoyably old school.<p>(I gather PHP does have types now, but perhaps I’m using the wrong IDE or need a specific VS.Code plugin…)<p>Very happy to answer any questions, although I’m the first to admit it’s very simple from a tech perspective. Your guess at how it was implemented is probably a better solution than what I actually did :)<p>Happy holidays all!</p>
<hr

## Simulating Non-CRT Monitors with FFmpeg: Flat Panel Displays (2021)
 - [https://int10h.org/blog/2021/03/simulating-non-crt-monitors-ffmpeg-flat-panels](https://int10h.org/blog/2021/03/simulating-non-crt-monitors-ffmpeg-flat-panels)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-31T02:16:24+00:00

<p>Article URL: <a href="https://int10h.org/blog/2021/03/simulating-non-crt-monitors-ffmpeg-flat-panels/">https://int10h.org/blog/2021/03/simulating-non-crt-monitors-ffmpeg-flat-panels/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38821166">https://news.ycombinator.com/item?id=38821166</a></p>
<p>Points: 30</p>
<p># Comments: 0</p>

## Cuis-Smalltalk
 - [https://cuis.st](https://cuis.st)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-12-31T00:10:41+00:00

<p>Article URL: <a href="https://cuis.st/">https://cuis.st/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38820557">https://news.ycombinator.com/item?id=38820557</a></p>
<p>Points: 79</p>
<p># Comments: 18</p>

