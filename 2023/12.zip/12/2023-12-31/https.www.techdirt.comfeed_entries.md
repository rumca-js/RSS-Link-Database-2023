# Source:Techdirt, URL:https://www.techdirt.com/feed/, language:en-US

## Funniest/Most Insightful Comments Of 2023 At Techdirt
 - [https://www.techdirt.com/2023/12/31/funniest-most-insightful-comments-of-2023-at-techdirt](https://www.techdirt.com/2023/12/31/funniest-most-insightful-comments-of-2023-at-techdirt)
 - RSS feed: https://www.techdirt.com/feed/
 - date published: 2023-12-31T20:00:00+00:00

Happy (almost) new year, Techdirt readers! As always, it&#8217;s time to take take a break from the regular weekly post and take a look at the comments that got the most votes from our community this year in the insightful and funny categories, plus a special look at the comments that got the most combined [&#8230;]

