# Source:Channel Asia Latest News, URL:https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml, language:en

## US Supreme Court's Roberts urges 'caution' as AI reshapes legal field
 - [https://www.channelnewsasia.com/business/us-supreme-courts-roberts-urges-caution-ai-reshapes-legal-field-4019266](https://www.channelnewsasia.com/business/us-supreme-courts-roberts-urges-caution-ai-reshapes-legal-field-4019266)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-12-31T23:04:02+00:00



## Zelenskyy vows to wreak 'wrath' against Russia in 2024
 - [https://www.channelnewsasia.com/world/ukraine-zelenskyy-vows-wrath-russia-2024-putin-4019246](https://www.channelnewsasia.com/world/ukraine-zelenskyy-vows-wrath-russia-2024-putin-4019246)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-12-31T22:53:00+00:00



## A happy place, a sanctuary: Singapore's libraries through the eyes of volunteers who love them
 - [https://www.channelnewsasia.com/singapore/national-library-board-volunteer-learn-facilitate-books-4014381](https://www.channelnewsasia.com/singapore/national-library-board-volunteer-learn-facilitate-books-4014381)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-12-31T22:05:27+00:00

These three individuals dedicated themselves to libraries at different stages of their lives, and are now contributing in their own ways to the learning "ecosystem".

## Commentary: A mid-life career change is as good as a rest
 - [https://www.channelnewsasia.com/commentary/mid-life-career-change-older-workers-reskill-upskill-4018516](https://www.channelnewsasia.com/commentary/mid-life-career-change-older-workers-reskill-upskill-4018516)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-12-31T22:00:00+00:00

Options don’t have to narrow for the over-50s, but it pays to prepare the ground, says Camilla Cavendish for the Financial Times.

## Commentary: Our youths must make self-reflection their New Year resolution
 - [https://www.channelnewsasia.com/commentary/new-year-resolutions-youth-hustle-culture-learn-self-reflection-4015916](https://www.channelnewsasia.com/commentary/new-year-resolutions-youth-hustle-culture-learn-self-reflection-4015916)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-12-31T22:00:00+00:00

Pausing to reflect feels like stagnant inactivity, but it’s crucial for our youths, says NUS lecturer Jonathan Sim.

## Commentary: Will 2024 be the year fake news destroys democracy?
 - [https://www.channelnewsasia.com/commentary/2024-elections-us-eu-indonesia-india-fake-news-social-media-4018691](https://www.channelnewsasia.com/commentary/2024-elections-us-eu-indonesia-india-fake-news-social-media-4018691)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-12-31T22:00:00+00:00

With almost a billion people heading to the polls, countries urgently need to band together to combat a flood of disinformation, says Mihir Sharma for Bloomberg Opinion.

## Off-roading in the 2024 Range Rover Velar through the vineyards of the Champagne region in France
 - [https://www.channelnewsasia.com/obsessions/2024-range-rover-velar-4012651](https://www.channelnewsasia.com/obsessions/2024-range-rover-velar-4012651)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-12-31T21:41:19+00:00

Navigating through rows and rows of neatly lined grapevines as far as the eye can see on this once-in-a-lifetime experience in the 2024 Range Rover Velar.

## German police arrest three more over alleged Cologne Cathedral attack plot
 - [https://www.channelnewsasia.com/world/german-police-arrest-three-more-over-alleged-cologne-cathedral-attack-plot-4019136](https://www.channelnewsasia.com/world/german-police-arrest-three-more-over-alleged-cologne-cathedral-attack-plot-4019136)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-12-31T21:11:03+00:00



## Denmark's Queen Margrethe II to abdicate after 52 years on the throne
 - [https://www.channelnewsasia.com/world/denmark-queen-margrethe-abdicate-52-years-4019071](https://www.channelnewsasia.com/world/denmark-queen-margrethe-abdicate-52-years-4019071)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-12-31T18:43:06+00:00



## Arteta laments 'worst game of the season' as Arsenal miss out on top spot
 - [https://www.channelnewsasia.com/sport/arteta-laments-worst-game-season-arsenal-miss-out-top-spot-4019066](https://www.channelnewsasia.com/sport/arteta-laments-worst-game-season-arsenal-miss-out-top-spot-4019066)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-12-31T18:06:07+00:00



## Djokovic delivers as Serbia beat China in United Cup
 - [https://www.channelnewsasia.com/sport/djokovic-delivers-serbia-beat-china-united-cup-4018966](https://www.channelnewsasia.com/sport/djokovic-delivers-serbia-beat-china-united-cup-4018966)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-12-31T16:31:07+00:00



## Tottenham end Bournemouth hot streak with 3-1 victory
 - [https://www.channelnewsasia.com/sport/tottenham-end-bournemouth-hot-streak-3-1-victory-4018951](https://www.channelnewsasia.com/sport/tottenham-end-bournemouth-hot-streak-3-1-victory-4018951)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-12-31T16:27:37+00:00



## Fulham fight back to beat Arsenal 2-1
 - [https://www.channelnewsasia.com/sport/fulham-fight-back-beat-arsenal-2-1-4018956](https://www.channelnewsasia.com/sport/fulham-fight-back-beat-arsenal-2-1-4018956)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-12-31T16:24:20+00:00



## Luton's Lockyer doing well after cardiac arrest, thanks those who saved his life
 - [https://www.channelnewsasia.com/sport/lutons-lockyer-doing-well-after-cardiac-arrest-thanks-those-who-saved-his-life-4018866](https://www.channelnewsasia.com/sport/lutons-lockyer-doing-well-after-cardiac-arrest-thanks-those-who-saved-his-life-4018866)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-12-31T15:13:00+00:00



## Putin, in New Year address, makes only passing reference to Ukraine
 - [https://www.channelnewsasia.com/world/russia-president-vladimir-putin-new-year-address-upcoming-election-4018846](https://www.channelnewsasia.com/world/russia-president-vladimir-putin-new-year-address-upcoming-election-4018846)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-12-31T15:10:11+00:00



## China's Li Auto expects to launch first fully electric EV in March
 - [https://www.channelnewsasia.com/business/chinas-li-auto-expects-launch-first-fully-electric-ev-march-4018861](https://www.channelnewsasia.com/business/chinas-li-auto-expects-launch-first-fully-electric-ev-march-4018861)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-12-31T14:58:01+00:00



## China's Xi hails 'resilient' economy in bullish New Year speech
 - [https://www.channelnewsasia.com/asia/china-2024-enhance-economic-recovery-xi-jinping-4018791](https://www.channelnewsasia.com/asia/china-2024-enhance-economic-recovery-xi-jinping-4018791)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-12-31T13:10:00+00:00



## Israelis and Palestinians end dark year, with no end in sight to war
 - [https://www.channelnewsasia.com/world/israel-hamas-war-no-end-sight-palestinians-gaza-4018786](https://www.channelnewsasia.com/world/israel-hamas-war-no-end-sight-palestinians-gaza-4018786)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-12-31T12:04:28+00:00



## Eurostar services resume as cause of flooded tunnel probed
 - [https://www.channelnewsasia.com/world/eurostar-services-resume-flooded-tunnel-4018731](https://www.channelnewsasia.com/world/eurostar-services-resume-flooded-tunnel-4018731)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-12-31T11:30:00+00:00



## Maersk pauses Red Sea sailings after Houthi attack on Singapore-flagged container ship
 - [https://www.channelnewsasia.com/world/maersk-container-vessel-sailing-pause-houthi-attack-red-sea-yemen-israel-hamas-war-4018741](https://www.channelnewsasia.com/world/maersk-container-vessel-sailing-pause-houthi-attack-red-sea-yemen-israel-hamas-war-4018741)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-12-31T11:20:00+00:00



## Australian Open 2024 prize money: how much do winners of men's, women's and doubles finals win?
 - [https://www.channelnewsasia.com/sport/australian-open-2024-prize-money-how-much-do-winners-mens-womens-and-doubles-finals-win-4018766](https://www.channelnewsasia.com/sport/australian-open-2024-prize-money-how-much-do-winners-mens-womens-and-doubles-finals-win-4018766)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-12-31T11:19:55+00:00



## Kewell takes over from Muscat as new Yokohama F Marinos manager
 - [https://www.channelnewsasia.com/sport/kewell-takes-over-muscat-new-yokohama-f-marinos-manager-4018756](https://www.channelnewsasia.com/sport/kewell-takes-over-muscat-new-yokohama-f-marinos-manager-4018756)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-12-31T11:03:40+00:00



## Israeli government approves appointment of new foreign minister
 - [https://www.channelnewsasia.com/world/israel-government-approves-new-foreign-minister-4018751](https://www.channelnewsasia.com/world/israel-government-approves-new-foreign-minister-4018751)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-12-31T11:02:45+00:00



## Nadal makes long-awaited comeback in Brisbane doubles defeat
 - [https://www.channelnewsasia.com/sport/nadal-makes-long-awaited-comeback-brisbane-doubles-defeat-4018726](https://www.channelnewsasia.com/sport/nadal-makes-long-awaited-comeback-brisbane-doubles-defeat-4018726)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-12-31T10:02:00+00:00



## Singapore GDP grew 1.2% in 2023 but expect less favourable external environment ahead: PM Lee
 - [https://www.channelnewsasia.com/singapore/pm-lee-new-year-message-2024-singapore-gdp-grew-12-cent-2023-4018631](https://www.channelnewsasia.com/singapore/pm-lee-new-year-message-2024-singapore-gdp-grew-12-cent-2023-4018631)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-12-31T10:00:21+00:00

Prime Minister Lee Hsien Loong also addressed Singapore's leadership transition and the Israel-Hamas war in his New Year message for 2024.

## Salah leads Egypt at African Cup of Nations
 - [https://www.channelnewsasia.com/sport/salah-leads-egypt-african-cup-nations-4018711](https://www.channelnewsasia.com/sport/salah-leads-egypt-african-cup-nations-4018711)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-12-31T09:46:54+00:00



## Final bodies found after China's most serious earthquake in a decade
 - [https://www.channelnewsasia.com/asia/china-earthquake-most-serious-decade-final-two-found-4018666](https://www.channelnewsasia.com/asia/china-earthquake-most-serious-decade-final-two-found-4018666)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-12-31T09:24:12+00:00



## Fit-again Nadal leaves door open to continuing career beyond 2024
 - [https://www.channelnewsasia.com/sport/fit-again-nadal-leaves-door-open-continuing-career-beyond-2024-4018706](https://www.channelnewsasia.com/sport/fit-again-nadal-leaves-door-open-continuing-career-beyond-2024-4018706)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-12-31T09:10:08+00:00



## Marina Bay New Year countdown: Expect large crowds, road closures and security checks
 - [https://www.channelnewsasia.com/singapore/marina-bay-new-year-countdown-2023-singapore-police-4016186](https://www.channelnewsasia.com/singapore/marina-bay-new-year-countdown-2023-singapore-police-4016186)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-12-31T09:00:00+00:00

Members of the public are encouraged to check the crowd situation online using the Crowd@MarinaBay platform before heading down for the festivities.

## Russia pounds Kharkiv with missiles and drones, Ukraine says
 - [https://www.channelnewsasia.com/world/russia-ukraine-missiles-drones-belgorod-4018686](https://www.channelnewsasia.com/world/russia-ukraine-missiles-drones-belgorod-4018686)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-12-31T08:29:00+00:00



## Sabalenka equipped with new mindset to handle pressure of 2024 season
 - [https://www.channelnewsasia.com/sport/sabalenka-equipped-new-mindset-handle-pressure-2024-season-4018641](https://www.channelnewsasia.com/sport/sabalenka-equipped-new-mindset-handle-pressure-2024-season-4018641)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-12-31T06:43:01+00:00



## Villarreal re-sign former Man Utd defender Bailly on free transfer
 - [https://www.channelnewsasia.com/sport/villarreal-re-sign-former-man-utd-defender-bailly-free-transfer-4018581](https://www.channelnewsasia.com/sport/villarreal-re-sign-former-man-utd-defender-bailly-free-transfer-4018581)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-12-31T05:01:23+00:00



## Adversity has strengthened A-League table-topping Victory claims Popovic
 - [https://www.channelnewsasia.com/sport/adversity-has-strengthened-league-table-topping-victory-claims-popovic-4018561](https://www.channelnewsasia.com/sport/adversity-has-strengthened-league-table-topping-victory-claims-popovic-4018561)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-12-31T04:25:39+00:00



## New Zealand beat Bangladesh in rain-hit final T20 to level series
 - [https://www.channelnewsasia.com/sport/new-zealand-beat-bangladesh-rain-hit-final-t20-level-series-4018511](https://www.channelnewsasia.com/sport/new-zealand-beat-bangladesh-rain-hit-final-t20-level-series-4018511)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-12-31T03:42:06+00:00



## Villa good but want to get better, says boss Emery
 - [https://www.channelnewsasia.com/sport/villa-good-want-get-better-says-boss-emery-4018501](https://www.channelnewsasia.com/sport/villa-good-want-get-better-says-boss-emery-4018501)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-12-31T03:26:21+00:00



## US destroyer shoots down anti-ship missiles fired from Yemen
 - [https://www.channelnewsasia.com/world/houthi-red-sea-attacks-us-destroyer-shoots-down-anti-ship-missiles-fired-yemen-4018461](https://www.channelnewsasia.com/world/houthi-red-sea-attacks-us-destroyer-shoots-down-anti-ship-missiles-fired-yemen-4018461)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-12-31T02:46:35+00:00



## China Dec factory contraction deepens, more stimulus on the cards
 - [https://www.channelnewsasia.com/business/china-dec-factory-contraction-deepens-more-stimulus-cards-4018431](https://www.channelnewsasia.com/business/china-dec-factory-contraction-deepens-more-stimulus-cards-4018431)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2023-12-31T01:44:11+00:00



