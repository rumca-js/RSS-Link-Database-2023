# Source:ABC News, URL:http://feeds.abcnews.com/abcnews/topstories, language:en-US

## 10-year-old in California charged with alleged murder of another 10-year-old: Police
 - [https://abcnews.go.com/US/10-year-california-charged-alleged-murder-10-year/story?id=106023957](https://abcnews.go.com/US/10-year-california-charged-alleged-murder-10-year/story?id=106023957)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-12-31T23:27:40+00:00

The Sacramento County Sheriff's Office has arrested a 10-year-old on a murder charge after allegedly shooting another 10-year-old who later died on Saturday.

## WATCH:  Nairobi celebrates the start of 2024
 - [https://abcnews.go.com/International/video/nairobi-celebrates-start-2024-106023158](https://abcnews.go.com/International/video/nairobi-celebrates-start-2024-106023158)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-12-31T21:31:02+00:00

Kenya's capital Nairobi celebrates bringing in the new year with a fireworks display.

## Reports: Former cycling world champ Dennis charged after Olympian wife struck, killed by vehicle
 - [https://abcnews.go.com/Sports/wireStory/reports-former-cycling-world-champ-dennis-charged-after-106021917](https://abcnews.go.com/Sports/wireStory/reports-former-cycling-world-champ-dennis-charged-after-106021917)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-12-31T20:54:02+00:00

Olympic cyclist Melissa Hoskins was biking when she was fatally struck.

## WATCH:  Dubai celebrates the start of 2024
 - [https://abcnews.go.com/International/video/dubai-celebrates-start-2024-106022619](https://abcnews.go.com/International/video/dubai-celebrates-start-2024-106022619)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-12-31T20:51:27+00:00

United Arab Emirates celebrates bringing in the new year with fireworks display.

## In rare apology, Israeli minister says she 'sinned' for her role in reforms that tore country apart
 - [https://abcnews.go.com/International/wireStory/rare-apology-israeli-minister-sinned-role-reforms-tore-106021842](https://abcnews.go.com/International/wireStory/rare-apology-israeli-minister-sinned-role-reforms-tore-106021842)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-12-31T20:34:16+00:00

A member of Prime Minister Benjamin Netanyahu&rsquo;s political party has offered one of the party&rsquo;s first public apologies for the internal strife that preceded Hamas&rsquo; Oct. 7 attack

## Exclusive: US to bring back aircraft carrier from eastern Mediterranean
 - [https://abcnews.go.com/International/exclusive-us-bring-back-gerald-r-ford-aircraft-carrier-eastern-mediterranean/story?id=106021259](https://abcnews.go.com/International/exclusive-us-bring-back-gerald-r-ford-aircraft-carrier-eastern-mediterranean/story?id=106021259)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-12-31T20:18:02+00:00

Exclusive: The USS Gerald R. Ford aircraft carrier strike group will leave the eastern Mediterranean Sea in the "coming days," two U.S. officials tell ABC News.

## WATCH:  Seal tries to pull off scuba diver's hood
 - [https://abcnews.go.com/International/video/seal-pull-off-scuba-divers-hood-106022194](https://abcnews.go.com/International/video/seal-pull-off-scuba-divers-hood-106022194)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-12-31T20:15:34+00:00

A scuba diver had an amusing interaction with a pair of seals when one of them tried to yank off his hood while they were off the coast of northern England.

## Queen of Denmark says in New Year's speech that she will abdicate her throne
 - [https://abcnews.go.com/International/surprise-move-queen-denmark-new-years-speech-abdicate/story?id=106021035](https://abcnews.go.com/International/surprise-move-queen-denmark-new-years-speech-abdicate/story?id=106021035)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-12-31T20:10:16+00:00

Denmark's Queen Margrethe II said she plans to abdicate her throne more than five decades after succeeding her father King Frederik IX.

## Lithium-ion battery fire in a cargo ship's hold is out after several days of burning
 - [https://abcnews.go.com/Business/wireStory/lithium-ion-battery-fire-cargo-ships-hold-after-106021528](https://abcnews.go.com/Business/wireStory/lithium-ion-battery-fire-cargo-ships-hold-after-106021528)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-12-31T19:34:07+00:00

The lithium-ion battery fire burned for days on a ship off the coast of Alaska.

## Denmark’s Queen Margrethe II to step down from throne on Jan. 14
 - [https://abcnews.go.com/International/wireStory/denmarks-queen-margrethe-ii-step-throne-jan-14-106020695](https://abcnews.go.com/International/wireStory/denmarks-queen-margrethe-ii-step-throne-jan-14-106020695)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-12-31T19:34:04+00:00

Denmark&rsquo;s Queen Margrethe II has announced that she plans to leave the throne to make way for her son, Crown Prince Frederik

## Shecky Greene, legendary standup comic, improv master and lord of Las Vegas, dies at 97
 - [https://abcnews.go.com/Entertainment/wireStory/shecky-greene-legendary-standup-comic-improv-master-lord-106021526](https://abcnews.go.com/Entertainment/wireStory/shecky-greene-legendary-standup-comic-improv-master-lord-106021526)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-12-31T19:25:54+00:00

The legendary standup comic was lord of the Las Vegas strip for decades.

## NASCAR Hall of Famer Cale Yarborough, a 3-time Cup champion in the 1970s, dies at 84
 - [https://abcnews.go.com/Sports/wireStory/nascar-hall-famer-cale-yarborough-3-time-cup-106020932](https://abcnews.go.com/Sports/wireStory/nascar-hall-famer-cale-yarborough-3-time-cup-106020932)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-12-31T19:24:46+00:00

Yarborough is considered one of NASCAR&rsquo;s all-time greatest drivers.

## WATCH:  Celebration in India for New Year's
 - [https://abcnews.go.com/International/video/celebration-india-new-years-106021448](https://abcnews.go.com/International/video/celebration-india-new-years-106021448)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-12-31T19:08:04+00:00

A large crowd gathered in Mumbai, India, for New Year's celebrations.

## WATCH:  Sydney, Australia rings in the New Year
 - [https://abcnews.go.com/International/video/sydney-australia-rings-new-year-106019758](https://abcnews.go.com/International/video/sydney-australia-rings-new-year-106019758)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-12-31T17:16:05+00:00

The city of Sydney celebrates 2024.

## WATCH:  New Year's celebration in Seoul, South Korea
 - [https://abcnews.go.com/International/video/new-years-celebration-seoul-south-korea-106019848](https://abcnews.go.com/International/video/new-years-celebration-seoul-south-korea-106019848)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-12-31T17:16:01+00:00

See the countdown ceremony and bell-ringing celebration at Bosingak Pavilion.

## Putin lauds Russian unity in New Year’s address amid Ukraine war
 - [https://abcnews.go.com/International/wireStory/putin-lauds-russian-unity-new-years-address-ukraine-106019180](https://abcnews.go.com/International/wireStory/putin-lauds-russian-unity-new-years-address-ukraine-106019180)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-12-31T15:52:36+00:00

Russian state news agencies say President Vladimir Putin has praised Russia&rsquo;s &ldquo;united society&rdquo; in his prerecorded New Year&rsquo;s address to the nation

## Man dies after shark encounter at Maui's Paia Bay: Officials
 - [https://abcnews.go.com/US/man-dies-shark-encounter-maui-paia-bay/story?id=106017431](https://abcnews.go.com/US/man-dies-shark-encounter-maui-paia-bay/story?id=106017431)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-12-31T14:41:38+00:00

A 39-year-old man has died following a shark "encounter" at Maui's Paia Bay, officials said.

## Former Trump White House insiders warn against possible 2nd term
 - [https://abcnews.go.com/Politics/former-trump-white-house-insiders-call-2nd-term/story?id=105998679](https://abcnews.go.com/Politics/former-trump-white-house-insiders-call-2nd-term/story?id=105998679)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-12-31T14:12:56+00:00

"We don't need to speculate," one told "This Week" co-anchor Jonathan Karl.

## American democracy has overcome big stress tests since the 2020 election
 - [https://abcnews.go.com/Politics/wireStory/american-democracy-overcome-big-stress-tests-2020-election-106018036](https://abcnews.go.com/Politics/wireStory/american-democracy-overcome-big-stress-tests-2020-election-106018036)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-12-31T13:55:49+00:00

Over the past three years, the world&rsquo;s oldest democracy has been tested in ways not seen in decades

## US Navy sinks 3 Houthi boats attacking merchant ship in Red Sea, US says
 - [https://abcnews.go.com/International/us-navy-sinks-3-houthi-boats-attacking-merchant/story?id=106016731](https://abcnews.go.com/International/us-navy-sinks-3-houthi-boats-attacking-merchant/story?id=106016731)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-12-31T12:51:35+00:00

Service members aboard the Navy helicopters returned fire and sank three of the four small boats, killing the crews, U.S. officials said.

## Jeffrey Epstein documents featuring prominent names to be released
 - [https://abcnews.go.com/US/court-documents-naming-jeffrey-epsteins-associates-unsealed/story?id=105993160](https://abcnews.go.com/US/court-documents-naming-jeffrey-epsteins-associates-unsealed/story?id=105993160)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-12-31T11:17:11+00:00

Hundreds of sealed court filings pertaining to the late sex-offender Jeffrey Epstein are set to be made public this week.

## Russia launches drone assault after accusing Ukraine of deadly attack within Russia
 - [https://abcnews.go.com/International/russia-launches-drone-assault-after-accusing-ukraine-deadly/story?id=106016404](https://abcnews.go.com/International/russia-launches-drone-assault-after-accusing-ukraine-deadly/story?id=106016404)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-12-31T07:53:40+00:00

The aerial assault followed two days of escalating shelling, including a strike on Saturday in Belgorod, Russia, that killed at least 21 people, according to Russia.

## Pistons beat Raptors 129-127 to end NBA record-tying losing streak at 28 games
 - [https://abcnews.go.com/Sports/wireStory/pistons-beat-raptors-129-127-end-nba-record-106013813](https://abcnews.go.com/Sports/wireStory/pistons-beat-raptors-129-127-end-nba-record-106013813)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-12-31T06:06:33+00:00

The Pistons matched the 76ers&rsquo; record, over the 2014-15 and 2015-16 seasons.

