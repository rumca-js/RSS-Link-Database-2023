# Source:Ign - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw, language:en-US

## Marvel Studios' What If...? Season 2 - Official All Episodes Streaming Trailer (2023) Hayley Atwell
 - [https://www.youtube.com/watch?v=kflm6r5CJ-4](https://www.youtube.com/watch?v=kflm6r5CJ-4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-12-31T20:00:17+00:00

Marvel Studios' What If... ? Season 2 is the second season in the anthology series about different fates and circumstances of the heroes within the Marvel Cinematic Universe with The Watcher acting as the guide for the viewer on the various tales. Fans can now enjoy the entire 9-episode season and get prepped for what may come in Season 3 of 'What If?...'. Marvel Studios' What If... ? Season 2 is streaming now in its entirety on Disney Plus.

#IGN #WhatIf #Marvel

## Pokemon Scarlet and Violet: The Teal Mask DLC – How to Catch the Loyal Three
 - [https://www.youtube.com/watch?v=8Fl0gz_PJcA](https://www.youtube.com/watch?v=8Fl0gz_PJcA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-12-31T18:00:04+00:00

This video originally aired on September 20, 2023.

In this video for Pokemon Scarlet and Violet: The Teal Mask DLC, we show you how to find and catch the Loyal Three.

00:00 - Intro
00:18 - Prerequisites for catching the Loyal Three
00:31 - Where to find the Loyal Three
00:38 - Recommended Pokemon to use
00:55 - Final prep before taking the Loyal Three on
01:06 - Head to Paradise Barrens to find Okidogi
01:59 - Battle strategies for catching these Legendary Pokemon
02:58 - Travel to Wisteria Pond to find Munkidori
04:09 - Travel to Fellhorn Gorge to find Fezandipiti
05:24 - Fezandipiti-specific strategies
06:44 - Outro

For more on Pokemon Scarlet and Violet: The Teal Mask, including a list of new and returning Pokemon, as well as more walkthroughs, visit IGN https://www.ign.com/wikis/pokemon-scarlet-violet/The_Teal_Mask_DLC

#IGN #Gaming #PokemonScarletAndViolet #TealMaskDLC #LoyalThree

## Percy Jackson and the Olympians - Official 'Book to Screen' Featurette (2023) Walker Scobell
 - [https://www.youtube.com/watch?v=QVGsZTMhhSY](https://www.youtube.com/watch?v=QVGsZTMhhSY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-12-31T17:00:31+00:00

Check out the latest featurette for Percy Jackson and the Olympians as the cast and crew explore what the process was like to adapt the iconic book to the screen.

Percy Jackson & The Olympians tells the fantastical story of a 12-year-old modern demigod, Percy Jackson, who’s just coming to terms with his newfound supernatural powers when the sky god Zeus accuses him of stealing his master lightning bolt. Now Percy must trek across America to find it and restore order to Olympus.

Percy Jackson and the Olympians stars Walker Scobell, Leah Jeffries, Aryan Simhadri, Charlie Bushnell, Azriel Dalman, and Glynn Turman. The series is directed by Anders Engström, Jet Wilkinson, and James Bobin. 

Percy Jackson and the Olympians first 3 episodes are available now for streaming on Disney Plus with new episodes weekly.

#IGN #PercyJacksonAndTheOlympians #Featurette

## Cyberpunk 2077: Full Judy Romance Gameplay Walkthrough (Update 2.1)
 - [https://www.youtube.com/watch?v=Ct51lWF3u6E](https://www.youtube.com/watch?v=Ct51lWF3u6E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-12-31T16:00:13+00:00

In Cyberpunk 2077, Judy Alvarez is a romanceable character who specializes in braindances. Here's a full video walkthrough of Judy's Questline and first romantic hangout in Cyberpunk 2077, including which dialogue options to select to keep the romance alive.

0:00 Requirements
0:04 Both Sides, Now
6:42 Ex-Factor
18:02 Choice 1: Talk Judy Down
18:42 Choice 2: Kill Woodman
21:27 Complete Ex-Factor
22:40 Talkin' 'Bout A Revolution
32:53 Pisces
39:42 Choice 1: Draw Weapon
40:47 Choice 2: Play Along with Maiko's Plan
43:22 Consequence If You Selected Choice 1
44:05 Consequence If You Selected Choice 2
45:21 Pyramid Song
1:07:22 Hangout with Judy

For more Cyberpunk 2077 tips and walkthroughs, check out our wiki at https://www.ign.com/wikis/cyberpunk-2077/

#IGN #Gaming #Cyberpunk2077 #Judy #Romance

## The Biggest Movies Coming in 2024
 - [https://www.youtube.com/watch?v=Qp1um46b8H4](https://www.youtube.com/watch?v=Qp1um46b8H4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-12-31T15:00:29+00:00

The past few years have been a whirlwind in the world of cinema, but as we look towards 2024 the landscape is changing. With the MCU and DC releasing just one film each, the stage is set for a diverse array of blockbusters. Anticipate the excitement of 'Dune: Part Two', 'Godzilla x Kong: The New Empire', and a new 'Planet of the Apes'. 'Furiosa' returns sans Mad Max, while Bong Joon Ho's 'Mickey 17' and Robert Eggers' 'Nosferatu' remake promise to captivate. Plus, keep an eye out for Jordan Peele's latest mystery project.

Get ready for the some of the biggest movies of 2024, coming soon to a theater near you.

## Ridley Scott Picks a Favorite Shot From Each of His Most Iconic Movies | My Best Shots
 - [https://www.youtube.com/watch?v=BX1PDiXeBQk](https://www.youtube.com/watch?v=BX1PDiXeBQk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-12-31T12:00:08+00:00

From Alien and Blade Runner to Gladiator and Napoleon, Ridley Scott picks his best shots from some of his most iconic movies, as well as one from any other film in cinema history.

Napoleon released in theatres on November 22, 2023.

#Movies #IGN #Alien

