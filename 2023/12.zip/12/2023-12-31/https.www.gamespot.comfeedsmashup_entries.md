# Source:GameSpot, URL:https://www.gamespot.com/feeds/mashup, language:en-US

## MP5: The Most Slapped Gun In Games - Loadout
 - [https://www.gamespot.com/videos/mp5-the-most-slapped-gun-in-games-loadout/2300-6463100](https://www.gamespot.com/videos/mp5-the-most-slapped-gun-in-games-loadout/2300-6463100)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2023-12-31T15:00:00+00:00

<img height="480" src="https://www.gamespot.com/a/uploads/square_medium/1574/15746725/4235530-loadout_mp5_site.jpg" width="480" /> From classic action movies like The Matrix and Die Hard to gaming franchises like Call of Duty and Battlefield, the MP5 has stolen the spotlight to truly become the iconic submachine gun.

## Best Of 2023: Hi-Fi Rush's Roquefort Fight Proves That Boss Battles Can Still Be Exciting
 - [https://www.gamespot.com/articles/hi-fi-rush-roquefort-fight-proves-that-boss-battles-can-still-be-exciting/1100-6519922/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/hi-fi-rush-roquefort-fight-proves-that-boss-battles-can-still-be-exciting/1100-6519922/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2023-12-31T13:00:00+00:00

<p> </p><p dir="ltr">Following the lukewarm reception to its latest horror game Ghostwire: Tokyo, few might have expected the next game from the Shinji Mikami led-Tango Gameworks to be a brightly colored, rhythm-based character-action game. Hi-Fi Rush saw a surprise release early in 2023, arguably kicking off the stellar year of unexpected brilliance with its tightly designed combat, incredibly likable cast of rebels, and standout boss fights. Each one of Hi-Fi Rush's numerous boss fights is memorable for one reason or another (the scale and complexity of the final fight against Kale is as awe-inspiring as the first fast-paced duel with antagonist-turned-ally Korsica), but none come close to comparing with what might be the most adrenaline-fuelled three-phase fight of the year: Roquefort.</p><p dir="ltr">Like much of Hi-Fi Rush, Roquefort isn't memorable because of his outright challenge. The character-action presented in Tango Gameworks' latest pairs rhythm-based sensibilities with 

