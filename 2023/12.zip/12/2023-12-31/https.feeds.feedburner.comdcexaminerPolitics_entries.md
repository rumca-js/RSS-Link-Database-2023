# Source:Washington Examiner - politics, URL:https://feeds.feedburner.com/dcexaminer/Politics, language:en-US

## 2023 review: Smash-and-grab epidemic crippled Democratic cities
 - [https://www.washingtonexaminer.com/news/smash-and-grab-epidemic-crippled-democrat-cities-in-2023](https://www.washingtonexaminer.com/news/smash-and-grab-epidemic-crippled-democrat-cities-in-2023)
 - RSS feed: https://feeds.feedburner.com/dcexaminer/Politics
 - date published: 2023-12-31T12:00:11+00:00

Smash-and-grab crime crippled retailers in Democratic-controlled cities across the United States throughout 2023.

