# Source:The Moscow Times, URL:https://www.themoscowtimes.com/rss/news, language:en-us

## Putin Praises Army in Scaled-Back New Year's Eve Address
 - [https://www.themoscowtimes.com/2023/12/31/putin-praises-army-in-scaled-back-new-years-eve-address-a83620](https://www.themoscowtimes.com/2023/12/31/putin-praises-army-in-scaled-back-new-years-eve-address-a83620)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2023-12-31T14:02:00+00:00

In contrast to last year's speech, Putin stood in front of the traditional backdrop of the Kremlin, declaring 2024 would be the "year of the family."

## China's Xi Says Ties With Russia Grew Stronger in 2023
 - [https://www.themoscowtimes.com/2023/12/31/chinas-xi-says-ties-with-russia-grew-stronger-in-2023-a83619](https://www.themoscowtimes.com/2023/12/31/chinas-xi-says-ties-with-russia-grew-stronger-in-2023-a83619)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2023-12-31T12:13:58+00:00

"The material and public opinion foundation of our relationship has become stronger," Xi Jinping said in his recap of the year to Putin.

## Russia Strikes Ukraine in Retaliation for Attack on Belgorod
 - [https://www.themoscowtimes.com/2023/12/31/russia-strikes-ukraine-in-retaliation-for-attack-on-belgorod-a83618](https://www.themoscowtimes.com/2023/12/31/russia-strikes-ukraine-in-retaliation-for-attack-on-belgorod-a83618)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2023-12-31T09:58:09+00:00

"On the eve of the New Year, Russians want to intimidate our city, but we are not scared," the mayor of Ukraine's northeastern city of Kharkiv said.

