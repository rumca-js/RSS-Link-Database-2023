# Source:Phys.org, URL:https://phys.org/rss-feed/, language:en-us

## Why some people don't trust science—and how to change their minds
 - [https://phys.org/news/2023-12-people-dont-scienceand-minds.html](https://phys.org/news/2023-12-people-dont-scienceand-minds.html)
 - RSS feed: https://phys.org/rss-feed/
 - date published: 2023-12-31T09:50:01+00:00

During the pandemic, a third of people in the UK reported that their trust in science had increased, we recently discovered. But 7% said that it had decreased. Why is there such variety of responses?

