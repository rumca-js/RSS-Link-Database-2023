# Source:Washington Examiner - world, URL:https://feeds.feedburner.com/dcexaminer/WorldNews, language:en-US

## Denmark's Queen Margrethe II announces abrupt abdication of throne, son will succeed her
 - [https://www.washingtonexaminer.com/news/denmarks-queen-margrethe-ii-abdication-throne](https://www.washingtonexaminer.com/news/denmarks-queen-margrethe-ii-abdication-throne)
 - RSS feed: https://feeds.feedburner.com/dcexaminer/WorldNews
 - date published: 2023-12-31T18:00:53+00:00

Queen Margrethe II of Denmark made a surprise announcement during her television address Sunday, marking the New Year, telling citizens she would be abdicating the throne.

