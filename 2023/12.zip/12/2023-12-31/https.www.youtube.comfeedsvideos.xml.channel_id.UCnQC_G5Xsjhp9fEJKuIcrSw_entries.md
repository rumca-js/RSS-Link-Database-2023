# Source:Ben Shapiro, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw, language:en-US

## Climate Change vs. Nuclear Warfare
 - [https://www.youtube.com/watch?v=wDcTRo0DvzU](https://www.youtube.com/watch?v=wDcTRo0DvzU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-12-31T20:00:21+00:00



## Stan Lee on the History of Spider-Man
 - [https://www.youtube.com/watch?v=AlM1hozavVI](https://www.youtube.com/watch?v=AlM1hozavVI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-12-31T18:00:11+00:00



