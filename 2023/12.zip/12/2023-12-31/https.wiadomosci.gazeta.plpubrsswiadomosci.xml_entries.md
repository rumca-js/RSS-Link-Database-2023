# Source:Wiadomosci - Gazeta.pl, URL:https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml, language:pl-PL

## Donald Tusk reaguje na orędzie prezydenta i słowa o konstytucji. "Sylwester Marzeń"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30552877,pojedynek-na-oredzia-prezydenta-i-premiera-ostatnie-slowo-dla.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30552877,pojedynek-na-oredzia-prezydenta-i-premiera-ostatnie-slowo-dla.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-31T21:06:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/3d/23/1d/z30552893M,Pojedynek-na-oredzia-prezydenta-i-premiera--Ostatn.jpg" vspace="2" />W sylwestrowym orędziu do PolakĂłw emitowanym w Telewizji Polskiej i Polskim Radiu prezydent Andrzej Duda zaatakował premiera i rząd, oceniając, że koalicja łamie "zasady demokratycznego państwa i konstytucję". Na odpowiedź szefa rządu nie trzeba było długo czekać. Donald Tusk podsumował wystąpienie Dudy trzema zdaniami na portalu X.

## Monika Jaruzelska płaci za wywiad z Braunem. Było zawiadomienie do prokuratury, teraz utrata pracy
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30552857,monika-jaruzelska-placi-za-wywiad-z-braunem-bylo-zawiadomienie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30552857,monika-jaruzelska-placi-za-wywiad-z-braunem-bylo-zawiadomienie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-31T20:37:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/26/23/1d/z30552870M,Grzegorz-Braun-i-Monika-Jaruzelska.jpg" vspace="2" />22 grudnia Monika Jaruzelska opublikowała na swoim kanale na YouTubie wywiad z Grzegorzem Braunem. Po tej rozmowie do prokuratury wpłynęło zawiadomienie dotyczące rozpowszechniania nienawistnych treści. W niedzielę Jaruzelska, ktĂłra nagrywała programy dla "Super Expressu", poinformowała o utracie pracy.

## Orędzie prezydenta Andrzeja Dudy. Uderzył w rząd, wskazał "postanowienia noworoczne" i życzył "miłości"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30552719,oredzie-prezydenta-andrzeja-dudy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30552719,oredzie-prezydenta-andrzeja-dudy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-31T19:01:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/09/23/1d/z30552841M,Duda.jpg" vspace="2" />- Nie zmieniło się najważniejsze zadanie, jakie stoi przed rządzącymi. To konieczność dbania o bezpieczeństwo naszej ojczyzny - mĂłwił w niedzielnym orędziu prezydent. Andrzej Duda mĂłwił o zmianach o mediach publicznych i uderzył w rząd, ktĂłry w jego ocenie "siłowo" je przejmuje.

## KrĂłlowa Danii Małgorzata II ogłosiła abdykację w telewizyjnym wystąpieniu na żywo
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30552673,krolowa-danii-malgorzata-ii-oglosila-abdykacje-w-telewizyjnym.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30552673,krolowa-danii-malgorzata-ii-oglosila-abdykacje-w-telewizyjnym.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-31T18:09:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/6c/23/1d/z30552684M,Krolowa-Danii-Malgorzata-II-nieoczekiwanie-oglosil.jpg" vspace="2" />KrĂłlowa Danii ogłosiła swoją abdykację w noworocznym przemĂłwieniu telewizyjnym. Małgorzata II pozostanie na tronie swego państwa do połowy stycznia. BBC ocenia, że to "niespodziewana decyzja".

## Wielkopolska. Niemowlę z podejrzeniem pęknięcia czaszki. Aresztowano rodzicĂłw
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30552640,wielkopolska-niemowle-z-podejrzeniem-pekniecia-czaszki-aresztowano.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30552640,wielkopolska-niemowle-z-podejrzeniem-pekniecia-czaszki-aresztowano.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-31T17:53:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/5f/23/1d/z30552671M,Wielkopolska--Niemowle-z-podejrzeniem-pekniecia-cz.jpg" vspace="2" />Do szpitala w Poznaniu trafiła dwumiesięczna dziewczynka z podejrzeniem pęknięcia czaszki. Jej rodzice zostali aresztowani.

## Mastalerek robi wstęp do orędzia Andrzeja Dudy. I komentuje wystąpienie Donalda Tuska. "Mowa trawa"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30552612,mastalerek-robi-wstep-do-oredzia-andrzeja-dudy-i-komentuje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30552612,mastalerek-robi-wstep-do-oredzia-andrzeja-dudy-i-komentuje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-31T17:19:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/2b/23/1d/z30552619M,Marcin-Mastalerek-robi-wstep-do-oredzia-Andrzeja-D.jpg" vspace="2" />- Piękne słowa, brzydkie czyny - tak podsumował sobotnie orędzie premiera Donalda Tuska szef gabinetu prezydenta Andrzeja Dudy. Marcin Mastalerek stwierdził, że wystąpienie "to była mowa trawa, z ktĂłrej nikt niczego nie zapamięta". Zapowiedział też, jakie tematy w niedzielnym, sylwestrowym orędziu poruszy prezydent.

## Suwerenna Polska domaga się wygaszenia mandatu senatorskiego Adama Bodnara. W tle zmiany w TVP
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30552524,suwerenna-polska-domaga-sie-wygaszenia-mandatu-senatorskiego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30552524,suwerenna-polska-domaga-sie-wygaszenia-mandatu-senatorskiego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-31T16:24:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/16/22/1d/z30550038M,Minister-sprawiedliwosci-Adam-Bodnar.jpg" vspace="2" />Były wiceminister sprawiedliwości chce pozbawienia obecnego ministra mandatu senatora. Dwoje posłĂłw Suwerennej Polski poinformowało o złożeniu do marszałkini Senatu Małgorzaty Kidawy Błońskiej wniosku o "wygaszenie mandatu senatorskiego Adama Bodnara w związku z jego bezprawnymi działaniami". Chodzi o rzekome przejęcie śledztw dot. zmian w TVP, Polskim Radiu i PAP przez ministra sprawiedliwości. Adam Bodnar zaprzeczył tym doniesieniom.

## Marek Sierocki zwolniony z TVP. Władze telewizji dementują. "Potencjał zostanie wykorzystany"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30552430,marek-sierocki-zwolniony-z-tvp-wladze-telewizji-dementuja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30552430,marek-sierocki-zwolniony-z-tvp-wladze-telewizji-dementuja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-31T14:56:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c2/22/1d/z30550466M,Marek-Sierocki.jpg" vspace="2" />Tomasz Sygut, dyrektor generalny postawionej w stan likwidacji Telewizji Polskiej zdementował informacje o zwolnieniu z TVP Marka Sierockiego. Dwa dni temu pojawiły się pierwsze doniesienia o rozwiązaniu umowy z dziennikarzem "Teleexpressu". Sierocki od ponad 30 lat przygotowywał informacje muzyczne o programie TVP1.

## Tragiczny wypadek koło Gliwic. SamochĂłd uderzył w drzewo. Zginęły trzy osoby
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30552311,tragiczny-wypadek-kolo-gliwic-samochod-uderzyl-w-drzewo-zginely.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30552311,tragiczny-wypadek-kolo-gliwic-samochod-uderzyl-w-drzewo-zginely.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-31T13:20:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/04/23/1d/z30552324M,Wypadek-kolo-Gliwic.jpg" vspace="2" />W miejscowości Żernica, pow. gliwicki doszło do tragicznego wypadku. SamochĂłd osobowy uderzył w drzewo. Zginęły trzy osoby narodowości ukraińskiej - informuje portal Remiza.pl.

## "Takiej sytuacji nie było od wielu lat". Szpitale są przepełnione. PowĂłd? COVID-19 i grypa
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30551938,takiej-sytuacji-nie-bylo-od-wielu-lat-szpitale-sa-przepelnione.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30551938,takiej-sytuacji-nie-bylo-od-wielu-lat-szpitale-sa-przepelnione.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-31T12:16:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/07/07/1d/z30437639M,Szpital--zdjecie-ilustracyjne-.jpg" vspace="2" />We Włoszech w ciągu ubiegłego tygodnia odnotowano ponad milion przypadkĂłw zachorowań na grypę. - To najwięcej od 15 lat - oceniają lekarze z krajowego Instytutu Zdrowia. Podobna sytuacja jest w Hiszpanii.

## "Co jako premier odradzam robić w sylwestra?". Donald Tusk opublikował poruszające wideo
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30551971,donald-tusk.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30551971,donald-tusk.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-31T12:09:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/28/23/1d/z30552104M,Donald-Tusk.jpg" vspace="2" />Donald Tusk opublikował w mediach społecznościowych nagranie, na ktĂłrym przekazał, co jako premier odradza robić w sylwestra. Do filmu dołączył prywatne nagranie ze swoich przyjacielem. "Tak trzymać" - skomentował Tomasz Trela z Lewicy.

## Magdalena Adamowicz o zarobkach w TVP. "Nie chcę wiedzieć, czy wynagrodzenia uciszyły ich sumienia"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30551947,magdalena-adamowicz-o-zarobkach-w-tvp-nie-chce-wiedziec-czy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30551947,magdalena-adamowicz-o-zarobkach-w-tvp-nie-chce-wiedziec-czy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-31T11:49:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c2/ff/1b/z29356994M,Magdalena-Adamowicz.jpg" vspace="2" />Ujawnienie zarobkĂłw gwiazd telewizji publicznej wzburzyło Magdalenę Adamowicz, wdowę po zamordowanym prezydencie Gdańska Pawle Adamowiczu. "Jedno wiem i domagam się tego także w imieniu naszych cĂłrek: czarno na białym musimy wszyscy zobaczyć a potem do szpiku kości rozliczyć ten mechanizm zła w tvpis" - napisała na portalu X.

## W TVP rozmawiali o "Zielonej granicy" Holland. Zaskakująca zmiana narracji. "Oglądałem trzykrotnie"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30551865,zaskakujace-opinie-o-zielonej-granicy-agnieszki-holland-w.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30551865,zaskakujace-opinie-o-zielonej-granicy-agnieszki-holland-w.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-31T11:34:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/99/22/1d/z30551961M,Agnieszka-Holland.jpg" vspace="2" />Niespodziewanie na antenie TVP pojawiły się pozytywne komentarze dotyczące... Agnieszki Holland i jej ostatniej produkcji. - Film "Zielona granica" nie jest absolutnie zamachem na polski mundur - stwierdził pracownik Telewizji Polskiej Mateusz Szymkowiak.

## Szymon Hołownia o kandydowaniu na prezydenta. Ujawnił, kiedy podejmie decyzję
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30551871,szymon-holownia-o-kandydowaniu-na-prezydenta-ujawnil-kiedy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30551871,szymon-holownia-o-kandydowaniu-na-prezydenta-ujawnil-kiedy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-31T11:04:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/03/1d/1d/z30529027M,Szymon-Holownia.jpg" vspace="2" />Szymon Hołownia w "Dzień Dobry TVN" ujawnił, jakie ma plany na przyszłość. Zapowiedział, że decyzję w sprawie startu w wyborach prezydenckich podejmie w 2024 roku. - Rok w polityce to wieczność. Wszystko może się wydarzyć - mĂłwił.

## Zaatakował syna nożem. Mężczyzna trafił do szpitala z "poważnymi obrażeniami"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30551839,zaatakowal-syna-nozem-mezczyzna-trafil-do-szpitala-z-powaznymi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30551839,zaatakowal-syna-nozem-mezczyzna-trafil-do-szpitala-z-powaznymi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-31T10:12:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c4/04/1d/z30428612M,Policja--zdjecie-ilustracyjne-.jpg" vspace="2" />W Ostrowie Wielkopolskim 63-latek zaatakował nożem swojego 38-letniego syna. Poszkodowany mężczyzna z "poważnymi obrażeniami" został przetransportowany do szpitala.

## Kolejny atak Rosji na Ukrainę. W ogniu stanął znany hotel, wielu poszkodowanych
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30551749,kolejny-atak-rosji-na-ukraine-w-ogniu-stanal-znany-hotel-wielu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30551749,kolejny-atak-rosji-na-ukraine-w-ogniu-stanal-znany-hotel-wielu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-31T10:04:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e0/22/1d/z30550752M,Zaporoze--Akcja-ratunkowa-po-rosyjskim-nalocie.jpg" vspace="2" />W nocy Rosja przeprowadziła kolejny atak na Ukrainę. Ostrzelany został między innymi KijĂłw. Miejscowe dowĂłdztwo wojskowe informowało o aktywności obrony przeciwlotniczej w okolicach stolicy. Dronami Shaded Rosjanie zaatakowano CharkĂłw - w centrum miasta doszło do serii eksplozji, zniszczone i uszkodzone zostały budynki mieszkalne, hotel i przedszkole. Wybuchy spowodowały pożary.

## Władimir Putin złożył życzenia na Nowy Rok. Papieża wyrĂłżnił za "niestrudzone działania"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30551741,wladimir-putin-zlozyl-zyczenia-noworoczne-wybranym-przywodcom.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30551741,wladimir-putin-zlozyl-zyczenia-noworoczne-wybranym-przywodcom.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-31T09:41:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/29/22/1d/z30551849M,Wladimir-Putin--ilustracyjne-.jpg" vspace="2" />Jak co roku Władimir Putin rozesłał życzenia noworoczne przywĂłdcom innych państw. Zaadresował je m.in. do premiera Węgier Viktora Orbana czy papieża Franciszka. Życzeń nie otrzymali m.in. przedstawiciele polskich czy amerykańskich władz.

## Hołownia zdradza kulisy pracy w Sejmie i mĂłwi o "grupie KaKaO": Fenomen, ktĂłrego nie mogę zrozumieć
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30551828,szymon-holownia-o-sejmie-to-dwoistosc-fenomen-ktorego-nie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30551828,szymon-holownia-o-sejmie-to-dwoistosc-fenomen-ktorego-nie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-31T09:27:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/1c/22/1d/z30551836M,Szymon-Holownia-w--DDTVN--.jpg" vspace="2" />- W Sejmie są ludzie szalenie powikłani politycznie, poglądowo, ale nie mĂłgłbym żadnej z tych osĂłb tam nazwać złym człowiekiem - mĂłwił w "Dzień Dobry TVN" Szymon Hołownia. Wymienił także trzech awanturnikĂłw, nazywając ich "grupą KaKaO".

## PiS grzmi: "Cenzura wrĂłciła". Poszło o wypowiedź Kaczyńskiego. PAP odpowiada na ostrą krytykę
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30551715,pap-nie-opublikowala-wypowiedzi-jaroslawa-kaczynskiego-pis.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30551715,pap-nie-opublikowala-wypowiedzi-jaroslawa-kaczynskiego-pis.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-31T08:25:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/b8/22/1d/z30551736M,Jaroslaw-Kaczynski.jpg" vspace="2" />"Cenzura wrĂłciła w pełnej okazałości" - grzmi Prawo i Sprawiedliwość w najnowszym wpisie w mediach społecznościowych. PowĂłd? Polska Agencja Prasowa (PAP) nie opublikowała wypowiedzi Jarosława Kaczyńskiego.

## Dziennikarz TV Republika był w szoku, gdy usłyszał odpowiedź na pytanie. "Wszystko się im sypie" [WIDEO]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30551713,dziennikarz-tv-republika-byl-w-szoku-gdy-uslyszal-odpowiedz.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30551713,dziennikarz-tv-republika-byl-w-szoku-gdy-uslyszal-odpowiedz.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-31T08:17:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e2/22/1d/z30551778M,TV-Republika.jpg" vspace="2" />Podczas relacjonowania na żywo protestu przeciwnikĂłw zmian w mediach publicznych reporter TV Republika Witold Newelicz zaliczył wpadkę. Postanowił poprosić o komentarz dwĂłch młodych mężczyzn, jednak usłyszał całkiem inną odpowiedź, niż zapewne przypuszczał. - Jest mi bardzo przykro, do czego doprowadziła Telewizja Polska w ostatnich latach, do jakiego podziału narodu - mĂłwił jeden z nich. Nagranie z relacji stało się hitem internetu.

## Donald Tusk wygłosił orędzie. W sieci fala komentarzy. "Dziwnie trochę bez żadnego 'fur Deutschland' ;)"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30551703,donald-tusk-wyglosil-oredzie-w-sieci-fala-komentarzy-dziwnie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30551703,donald-tusk-wyglosil-oredzie-w-sieci-fala-komentarzy-dziwnie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-31T06:58:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/fb/d3/ee/z15651835M,Donald-Tusk-w-wieczornym-oredziu-wygloszonym-w-TVP.jpg" vspace="2" />Donald Tusk wygłosił w sobotę pierwsze orędzie w TVP. Premier zapowiedział w nim przede wszystkim pojednanie PolakĂłw. W mediach społecznościowych pojawiły się liczne oceny wystąpienia szefa rządu.

## Horoskop dzienny - niedziela 31 grudnia 2023 [Baran, Byk, Bliźnięta, Rak, Lew, Panna, Waga, Skorpion, Strzelec, Koziorożec, Wodnik, Ryby]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,168571,30551047,horoskop-dzienny-niedziela-31-grudnia-2023-baran-byk-bliznieta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,168571,30551047,horoskop-dzienny-niedziela-31-grudnia-2023-baran-byk-bliznieta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-12-31T04:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c3/01/1b/z28319683M,Horoskop-na-niedziele.jpg" vspace="2" />Horoskop dzienny - niedziela 31 grudnia 2023 r. Co nas czeka w ostatni dzień w roku? Okazuje się, że będzie to przełomowy dzień dla BaranĂłw, SkorpionĂłw i StrzelcĂłw. Co gwiazdy przyniosą pozostałym znakom zodiaku?

