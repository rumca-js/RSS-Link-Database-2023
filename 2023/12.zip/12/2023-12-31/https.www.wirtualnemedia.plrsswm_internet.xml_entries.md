# Source:Wirtualne Media - Internet, URL:https://www.wirtualnemedia.pl/rss/wm_internet.xml, language:pl-PL

## Dominik Piechota żegna się z Kanałem Sportowym
 - [https://www.wirtualnemedia.pl/artykul/dominik-piechota-kanal-sportowy-koniec](https://www.wirtualnemedia.pl/artykul/dominik-piechota-kanal-sportowy-koniec)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-12-31T19:24:24.024896+00:00

Dziennikarz piłkarski Dominik Piechota po ponad trzech latach współpracy odchodzi z Kanału Sportowego. Wcześniej pracował m.in. w Newonce i „Przeglądzie Sportowym”.

## Była prezenterka „Pytania na śniadanie” oskarżona. Ujawniła adres nowej partnerki swojego eksmęża
 - [https://www.wirtualnemedia.pl/artykul/paulina-s-oskarzona-katarzyna-cichopek-adres](https://www.wirtualnemedia.pl/artykul/paulina-s-oskarzona-katarzyna-cichopek-adres)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-12-31T13:52:49.089619+00:00

Dziennikarka Paulina S., w przeszłości m.in. prezenterka „Pytania na śniadanie”, została oskarżona przez warszawską prokuraturę o nielegalne upublicznienie danych adresowych znanej aktorki Katarzyny Cichopek, obecnej partnerki życiowej jej byłego męża Macieja Kurzajewskiego.

## Amazon Prime Video z reklamami od 29 stycznia. Za ich wyłączenie trzeba dopłacić
 - [https://www.wirtualnemedia.pl/artykul/amazon-prime-video-reklamy-jak-zrezygnowac](https://www.wirtualnemedia.pl/artykul/amazon-prime-video-reklamy-jak-zrezygnowac)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-12-31T13:52:49.088389+00:00

Serwis streamingowy Amazon Prime Video poinformował subskrybentów w Stanach Zjednoczonych, że od 29 stycznia będzie wyświetlał reklamy. Za ich wyłączenie można do dotychczasowej opłaty abonamentowej dopłacić 2,99 dol. miesięcznie.

## Maciej Orłoś wraca do TVP. Ale kanał na YouTubie też mu „fajnie żre”
 - [https://www.wirtualnemedia.pl/artykul/maciej-orlos-teleexpress-tvp](https://www.wirtualnemedia.pl/artykul/maciej-orlos-teleexpress-tvp)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-12-31T13:52:49.087268+00:00

Maciej Orłoś wraca do „Teleexpressu”, w którym pracował przez ćwierć wieku. Od kilku lat prezenter prowadzi własne kanały na YouTubie. Czy będzie łączył obie aktywności? Zdaniem naszych rozmówców powinien. - Odnalazł się w formule zbliżonej do tego, co robił w telewizji. I to zażarło – ocenia Paweł Kwaśniewski. Sam Orłoś zapowiada zmniejszenie swojej aktywności na YouTubie, ale ma nadzieję, że uda mu się wszystko połączyć.

## Globalne przychody ze streamingu i rynku telewizyjnego wyniosą w tym roku 700 miliardów dolarów
 - [https://www.wirtualnemedia.pl/artykul/globalne-przychody-ze-streamingu-i-rynku-telewizyjnego-wyniki-koszty-reklamy-subskrypcje-2](https://www.wirtualnemedia.pl/artykul/globalne-przychody-ze-streamingu-i-rynku-telewizyjnego-wyniki-koszty-reklamy-subskrypcje-2)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-12-31T11:32:00+00:00

Podczas tegorocznych targów telewizyjnych Mipcom odbywających się w Cannes, analityk firmy Omdia - Tim Westcott, oszacował, że globalny rynek telewizji i streamingu będzie wart 700 miliardów dolarów w 2023 roku, z czego 164 miliardy dolarów zostaną przeznaczone na inwestycje w kolejne filmy, seriale i programy.

