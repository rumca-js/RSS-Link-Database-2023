# Source:The Telegraph News, URL:https://www.telegraph.co.uk/news/rss.xml, language:en-UK

## New Year’s Eve fireworks in London – watch live
 - [https://www.telegraph.co.uk/news/2023/12/31/new-years-eve-fireworks-in-london-watch-live-around-world](https://www.telegraph.co.uk/news/2023/12/31/new-years-eve-fireworks-in-london-watch-live-around-world)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-12-31T23:30:00+00:00



## Man arrested on suspicion of abduction of missing Leah Mullins, 14
 - [https://www.telegraph.co.uk/news/2023/12/31/missing-leah-mullins-14-last-seen-getting-into-car](https://www.telegraph.co.uk/news/2023/12/31/missing-leah-mullins-14-last-seen-getting-into-car)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-12-31T23:27:53+00:00



