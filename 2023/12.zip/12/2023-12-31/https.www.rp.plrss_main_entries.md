# Source:rp.pl, URL:https://www.rp.pl/rss_main, language:pl-PL

## Donald Tusk: Odchodzący 2023 rok był pełen cudów
 - [https://www.rp.pl/polityka/art39640591-donald-tusk-odchodzacy-2023-rok-byl-pelen-cudow](https://www.rp.pl/polityka/art39640591-donald-tusk-odchodzacy-2023-rok-byl-pelen-cudow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-31T21:22:09+00:00

Premier Tusk skomentował w mediach społecznościowych orędzie prezydenta Dudy: "Sylwester marzeń".

## Monitor Polski z 31 grudnia 2023 r. (poz. 1483)
 - [https://www.rp.pl/akty-prawne/art39640521-monitor-polski-z-31-grudnia-2023-r-poz-1483](https://www.rp.pl/akty-prawne/art39640521-monitor-polski-z-31-grudnia-2023-r-poz-1483)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-31T20:34:14+00:00



## Dziennik Ustaw z 31 grudnia 2023 r. (poz. 2824)
 - [https://www.rp.pl/akty-prawne/art39640501-dziennik-ustaw-z-31-grudnia-2023-r-poz-2824](https://www.rp.pl/akty-prawne/art39640501-dziennik-ustaw-z-31-grudnia-2023-r-poz-2824)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-31T20:31:53+00:00



## Artur Bartkiewicz: Czym orędzie Andrzeja Dudy różniło się od orędzia Donalda Tuska?
 - [https://www.rp.pl/komentarze/art39640241-artur-bartkiewicz-czym-oredzie-andrzeja-dudy-roznilo-sie-od-oredzia-donalda-tuska](https://www.rp.pl/komentarze/art39640241-artur-bartkiewicz-czym-oredzie-andrzeja-dudy-roznilo-sie-od-oredzia-donalda-tuska)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-31T19:24:00+00:00

Porównanie orędzi noworocznych premiera Donalda Tuska i prezydenta Andrzeja Dudę wyraźnie wskazuje na to, który z tych polityków kończy rok z poczuciem politycznego zwycięstwa, a który zamierza walczyć o odbicie utraconych szańców.

## Noworoczne orędzie prezydenta Andrzeja Dudy
 - [https://www.rp.pl/polityka/art39640311-noworoczne-oredzie-prezydenta-andrzeja-dudy](https://www.rp.pl/polityka/art39640311-noworoczne-oredzie-prezydenta-andrzeja-dudy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-31T19:06:01+00:00

- Kończący się właśnie rok był rokiem zmiany w polskiej polityce. Po ośmiu latach zmieniła się w naszym kraju większość parlamentarna, zmienił się premier, zmienił się rząd. Ale nie zmieniło się najważniejsze zadanie, jakie stoi przed rządzącymi. To konieczność dbania o bezpieczeństwo naszej ojczyzny - powiedział w noworocznym orędziu prezydent Andrzej Duda.

## Zmiany dla kierowców w 2024 r. Wyższe kary, nowe paliwo E10, konfiskata auta
 - [https://moto.rp.pl/tu-i-teraz/art39640051-zmiany-dla-kierowcow-w-2024-r-wyzsze-kary-nowe-paliwo-e10-konfiskata-auta](https://moto.rp.pl/tu-i-teraz/art39640051-zmiany-dla-kierowcow-w-2024-r-wyzsze-kary-nowe-paliwo-e10-konfiskata-auta)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-31T18:19:26+00:00

Co nowego czeka kierowców w 2024 roku? Wyższe opłaty i kar za wykroczenia, wejdą również w życie kolejne elementy znowelizowanego kodeksu karnego i zmiany niektórych przepisów.

## Królowa Danii niespodziewanie abdykowała
 - [https://www.rp.pl/polityka/art39640271-krolowa-danii-niespodziewanie-abdykowala](https://www.rp.pl/polityka/art39640271-krolowa-danii-niespodziewanie-abdykowala)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-31T18:00:00+00:00

"Nadszedł czas, aby przekazać władzę następnemu pokoleniu" - oznajmiła duńska królowa Małgorzata II podczas przemówienia noworocznego.

## Rosja: Kawior jest, ale chiński
 - [https://www.rp.pl/polityka/art39639951-rosja-kawior-jest-ale-chinski](https://www.rp.pl/polityka/art39639951-rosja-kawior-jest-ale-chinski)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-31T17:56:16+00:00

Cena politycznego sojuszu z Pekinem: 40 proc. czarnego kawioru na rosyjskim rynku to chińska podróbka.

## Tani kredyt wymiótł z rynku tanie mieszkania
 - [https://www.rp.pl/nieruchomosci/art39640161-tani-kredyt-wymiotl-z-rynku-tanie-mieszkania](https://www.rp.pl/nieruchomosci/art39640161-tani-kredyt-wymiotl-z-rynku-tanie-mieszkania)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-31T17:55:52+00:00

Najtańsze lokale w 2023 roku znikały z oferty w mgnieniu oka.

## "Rzeczpospolita" na rok 2024
 - [https://www.rp.pl/spoleczenstwo/art39640171-rzeczpospolita-na-rok-2024](https://www.rp.pl/spoleczenstwo/art39640171-rzeczpospolita-na-rok-2024)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-31T17:34:54+00:00

Życzymy naszym Czytelnikom samych naprawdę dobrych zmian w Polsce, świata bez wojen, przemocy i głodu oraz tyle szczęścia, ile tylko zmieści się w naszych sercach i domach.

## Michał Szułdrzyński: To nie będzie sylwester marzeń prezesa Jarosława Kaczyńskiego
 - [https://www.rp.pl/komentarze/art39640021-michal-szuldrzynski-to-nie-bedzie-sylwester-marzen-prezesa-jaroslawa-kaczynskiego](https://www.rp.pl/komentarze/art39640021-michal-szuldrzynski-to-nie-bedzie-sylwester-marzen-prezesa-jaroslawa-kaczynskiego)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-31T16:15:50+00:00

W 2023 roku rozsypał się projekt polityczny Jarosława Kaczyńskiego. W dodatku ujawnione milionowe zarobki w TVP skompromitowały idee rewolucji moralnej PiS. Dla prezesa PiS będzie to gorzki koniec roku klęski, a nie sylwester marzeń.

## Reżimowe bajki dla ludu: Gospodarki Rosji i Białorusi rosną coraz szybciej
 - [https://www.rp.pl/gospodarka/art39640031-rezimowe-bajki-dla-ludu-gospodarki-rosji-i-bialorusi-rosna-coraz-szybciej](https://www.rp.pl/gospodarka/art39640031-rezimowe-bajki-dla-ludu-gospodarki-rosji-i-bialorusi-rosna-coraz-szybciej)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-31T15:32:34+00:00

Reżimy Rosji i Białorusi ogłosiły „wspaniałe wyniki” osiągnięte przez obie gospodarki w 2023 roku. PKB obu krajów zaliczył „silny wzrost” o 3,5 proc., a oba kraje są „oazą ekonomicznej stabilności”. Nie można tych danych w żaden sposób zweryfikować.

## Jest wniosek o wygaszenie mandatu Adama Bodnara
 - [https://www.rp.pl/prawnicy/art39639991-jest-wniosek-o-wygaszenie-mandatu-adama-bodnara](https://www.rp.pl/prawnicy/art39639991-jest-wniosek-o-wygaszenie-mandatu-adama-bodnara)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-31T15:12:23+00:00

Złożyliśmy wniosek do marszałek Małgorzaty Kidawy-Błońskiej o wygaszenie mandatu senatorskiego Adama Bodnara w związku z jego bezprawnymi działaniami - poinformował na Facebooku poseł Suwerennej Polski Marcin Romanowski.

## 72. TCS. Kwalifikacje w Ga-Pa dla Anze Laniska
 - [https://www.rp.pl/skoki-narciarskie/art39639981-72-tcs-kwalifikacje-w-ga-pa-dla-anze-laniska](https://www.rp.pl/skoki-narciarskie/art39639981-72-tcs-kwalifikacje-w-ga-pa-dla-anze-laniska)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-31T14:50:00+00:00

Seria kwalifikacyjna na Wielkiej Skoczni Olimpijskiej w Garmisch-Partenkirchen dała zwycięstwo Słoweńcowi Anze Laniskowi, który wyprzedził lidera 72. TCS Andreasa Wellingera oraz Manuela Fettnera. Polskich błysków jak nie było, tak nie ma.

## Adrian Zandberg: Czekam, aż posłowie PiS-u zaczną występować w koszulkach „OTUA”
 - [https://www.rp.pl/polityka/art39639941-adrian-zandberg-czekam-az-poslowie-pis-u-zaczna-wystepowac-w-koszulkach-otua](https://www.rp.pl/polityka/art39639941-adrian-zandberg-czekam-az-poslowie-pis-u-zaczna-wystepowac-w-koszulkach-otua)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-31T14:06:16+00:00

- Ten ściek nie powinien płynąć dalej, natomiast droga do tego powinna być taka, żeby nie budziła wątpliwości prawnych - powiedział Adrian Zandberg, współprzewodniczący partii Razem, komentując zmiany w mediach publicznych.

## Marcin Mastalerek: Donald Tusk przegrał wybory, a zachowuje się, jakby je wygrał
 - [https://www.rp.pl/polityka/art39639891-marcin-mastalerek-donald-tusk-przegral-wybory-a-zachowuje-sie-jakby-je-wygral](https://www.rp.pl/polityka/art39639891-marcin-mastalerek-donald-tusk-przegral-wybory-a-zachowuje-sie-jakby-je-wygral)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-31T13:21:43+00:00

- Pan Donald Tusk żyje przeszłością, tym co wydarzyło się 15 października. Przegrał wybory. Zachowuje się tak, jakby wygrał i jeszcze nie zrozumiał, co się stało - przekonywał Marcin Mastalerek, szef Gabinetu Prezydenta RP.

## Ceny paliw w 2024 r. Początek stycznia stabilnie, później drożej
 - [https://moto.rp.pl/tu-i-teraz/art39639871-ceny-paliw-w-2024-r-poczatek-stycznia-stabilnie-pozniej-drozej](https://moto.rp.pl/tu-i-teraz/art39639871-ceny-paliw-w-2024-r-poczatek-stycznia-stabilnie-pozniej-drozej)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-31T13:18:16+00:00

Dobre informacje dla kierowców. Początek 2024 roku zapowiada się stabilnie pod kątem cen paliw, które wg. niektórych ekspertów mogą nawet jeszcze nieco spaść. Większą niewiadomą jest podwyżka, która może się pojawić po zapowiedzianej opłacie paliwowej.

## Jak Elon Musk wykończył Twittera w 2023 r.
 - [https://www.rp.pl/biznes/art39639801-jak-elon-musk-wykonczyl-twittera-w-2023-r](https://www.rp.pl/biznes/art39639801-jak-elon-musk-wykonczyl-twittera-w-2023-r)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-31T12:41:24+00:00

Twitter o nowej nazwie X w pełni kontrolowany przez Elona Muska kończy pierwszy pełny rok w żałosnym stanie. Miliarder popsuł ten serwis. Szerząca się dezinformacja zainteresowała władze Unii Europejskiej, które mają nowe uprawnienia w zakresie sankcji. Ogłoszeniodawcy pouciekali i nie wracają. Sam Musk przyznał, że w 2024 r. X będzie walczyć o przetrwanie — pisze dziennik „La Tribune”.

## Poważne wpadki wielkich prezesów. Buta, oszustwa, bezmyślność
 - [https://www.rp.pl/biznes/art39639811-powazne-wpadki-wielkich-prezesow-buta-oszustwa-bezmyslnosc](https://www.rp.pl/biznes/art39639811-powazne-wpadki-wielkich-prezesow-buta-oszustwa-bezmyslnosc)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-31T12:30:03+00:00

Oczywiście nikt nie jest w stanie pobić Elona Muska. Najbogatszy człowiek świata kończy ten rok gigantyczną porażką w Szwecji, gdzie przegrywa wojnę ze związkami zawodowymi i uparcie stara się zmienić nordycką kulturę korporacyjną.

## Do 3,5 tys. zł dla niepełnosprawnych. Wchodzi nowe świadczenie
 - [https://www.rp.pl/niepelnosprawni/art39638931-do-3-5-tys-zl-dla-niepelnosprawnych-wchodzi-nowe-swiadczenie](https://www.rp.pl/niepelnosprawni/art39638931-do-3-5-tys-zl-dla-niepelnosprawnych-wchodzi-nowe-swiadczenie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-31T11:23:47+00:00

Najpierw niepełnosprawni powinni wystąpić o ustalenie tzw. poziomu potrzeby wsparcia, a potem zadecydować, czy warto przejść na nowe świadczenie z Zakładu Ubezpieczeń Społecznych.

## Mistrz świata w kolarstwie oskarżony o zabicie swojej żony
 - [https://www.rp.pl/kolarstwo/art39639781-mistrz-swiata-w-kolarstwie-oskarzony-o-zabicie-swojej-zony](https://www.rp.pl/kolarstwo/art39639781-mistrz-swiata-w-kolarstwie-oskarzony-o-zabicie-swojej-zony)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-31T11:02:09+00:00

Podwójny mistrz świata w jeździe indywidualnej na czas, dwukrotny medalista olimpijski Rohan Dennis został oskarżony o spowodowanie śmierci swojej żony, byłej kolarki Melissy Hoskins, w wypadku, który miał miejsce w sobotę w Adelajdzie.

## Premier Donald Tusk i RCB z apelem na sylwestra. „Zdecydowanie odradzam”
 - [https://www.rp.pl/prawo-dla-ciebie/art39639751-premier-donald-tusk-i-rcb-z-apelem-na-sylwestra-zdecydowanie-odradzam](https://www.rp.pl/prawo-dla-ciebie/art39639751-premier-donald-tusk-i-rcb-z-apelem-na-sylwestra-zdecydowanie-odradzam)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-31T10:49:00+00:00

Jeżeli odpalasz fajerwerki, rób to ostrożnie i stosuj się do instrukcji. Zapewnij bezpieczeństwo i spokój swoim zwierzakom. Piłeś? Nie wsiadaj za kierownicę - to sylwestrowy apel Rządowego Centrum Bezpieczeństwa. Wpis w mediach społecznościowych dotyczący świętowania końca roku zamieścił też Donald Tusk.

## Christine Lagarde : euro zapewnia suwerenność w niespokojnym świecie
 - [https://www.rp.pl/gospodarka/art39639551-christine-lagarde-euro-zapewnia-suwerennosc-w-niespokojnym-swiecie](https://www.rp.pl/gospodarka/art39639551-christine-lagarde-euro-zapewnia-suwerennosc-w-niespokojnym-swiecie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-31T10:25:00+00:00

Wspólna waluta  zapewnia suwerenność w niepewnych czasach i pomaga Europie zachować samostanowienie na całym świecie — napisała prezes EBC Christine Lagarde w artykule z okazji zbliżającej się 25. rocznicy wprowadzenia europejskiego pieniądza.

## Moda na rezonans magnetyczny: nowy symbol statusu i bogactwa
 - [https://sukces.rp.pl/zdrowie-uroda/art39639691-moda-na-rezonans-magnetyczny-nowy-symbol-statusu-i-bogactwa](https://sukces.rp.pl/zdrowie-uroda/art39639691-moda-na-rezonans-magnetyczny-nowy-symbol-statusu-i-bogactwa)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-31T09:48:10+00:00

Wśród najbogatszych przedstawicieli naszego społeczeństwa popularność zyskuje osobliwy trend: poddawanie się prywatnym badaniom przy użyciu rezonansu magnetycznego. Ci, których stać na te badania, chcą upewnić się, że są całkowicie zdrowi.

## Andrzej Zybertowicz skrytykował TVP za rządów PiS. Mówił o „złej propagandzie”
 - [https://www.rp.pl/polityka/art39639591-andrzej-zybertowicz-skrytykowal-tvp-za-rzadow-pis-mowil-o-zlej-propagandzie](https://www.rp.pl/polityka/art39639591-andrzej-zybertowicz-skrytykowal-tvp-za-rzadow-pis-mowil-o-zlej-propagandzie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-31T09:46:54+00:00

Prof. Andrzej Zybertowicz, doradca prezydenta Andrzeja Dudy, skrytykował decyzje nowego ministra kultury Bartłomieja Sienkiewicza w sprawie mediów publicznych. W rozmowie z radiową Trójką negatywnie odniósł się jednak również do tego, jak działała TVP w czasach rządów PiS.

## Celebrytka Paulina S. oskarżona
 - [https://www.rp.pl/prawo-karne/art39639521-celebrytka-paulina-s-oskarzona](https://www.rp.pl/prawo-karne/art39639521-celebrytka-paulina-s-oskarzona)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-31T09:19:53+00:00

Prokuratura Rejonowa Warszawa – Śródmieście skierowała do sądu akt oskarżenia Pauliny S., celebrytki i prezenterki telewizyjnej, o nielegalne udostępnianie na Instagramie danych osobowych obecnej partnerki byłego męża. Kobiecie grozi do dwóch lat pozbawienia wolności.

## Ostatni w tym roku problem techniczny w samolotach B737 MAX
 - [https://www.rp.pl/transport/art39639481-ostatni-w-tym-roku-problem-techniczny-w-samolotach-b737-max](https://www.rp.pl/transport/art39639481-ostatni-w-tym-roku-problem-techniczny-w-samolotach-b737-max)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-31T08:55:11+00:00

Boeing wezwał linie lotnicze do sprawdzenia w MAX-ach poluzowanych śrub w układzie kontroli steru.

## Przewóz 42 do wzięcia
 - [https://www.rp.pl/nieruchomosci/art39639541-przewoz-42-do-wziecia](https://www.rp.pl/nieruchomosci/art39639541-przewoz-42-do-wziecia)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-31T08:50:29+00:00

Sprzedaż mieszkań na krakowskim Podgórzu rozpoczyna Atal. Ceny lokali wahają się od 11,8 do 15 tys. zł za metr.

## Europejska stal i aluminium nadal bez cła w USA
 - [https://www.rp.pl/biznes/art39639491-europejska-stal-i-aluminium-nadal-bez-cla-w-usa](https://www.rp.pl/biznes/art39639491-europejska-stal-i-aluminium-nadal-bez-cla-w-usa)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-31T08:49:28+00:00

Trzy dni przed końcem roku prezydent Joe Biden przedłużył o 2 lata zawieszenie amerykańskiego cła na stal i aluminium z Unii Europejskiej. Decyzja zacznie obowiązywać od 1 stycznia 2024, umożliwi kontynuowanie w tym okresie negocjacji o ostatecznym rozwiązaniu problemu stworzonego przez Donalda Trumpa.

## Lotnisko w Toronto szuka właścicieli 5 tys. laptopów
 - [https://www.rp.pl/transport/art39639311-lotnisko-w-toronto-szuka-wlascicieli-5-tys-laptopow](https://www.rp.pl/transport/art39639311-lotnisko-w-toronto-szuka-wlascicieli-5-tys-laptopow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-31T08:38:38+00:00

Ponad 5 tysięcy laptopów czeka na właścicieli na kanadyjskim lotnisku w Toronto. Oprócz tego tablety, telefony komórkowe i torby podręczne.

## Nie zrezygnuje z niezdrowych przyjemności. Odważne wyznanie Vanessy Paradis
 - [https://kobieta.rp.pl/styl-zycia/art39630231-nie-zrezygnuje-z-niezdrowych-przyjemnosci-odwazne-wyznanie-vanessy-paradis](https://kobieta.rp.pl/styl-zycia/art39630231-nie-zrezygnuje-z-niezdrowych-przyjemnosci-odwazne-wyznanie-vanessy-paradis)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-31T08:00:00+00:00

„Chciałbym być jak Mick Jagger w wieku 80 lat, ale on nie pali, nie pije i kilka godzin dziennie uprawia sport” – mówi Vanessa Paradis w niedawnym wywiadzie dla francuskiego Harper’s BAAZAR. „Ja mam problemy z dyscypliną, za bardzo kocham przyjemności życia, żeby rezygnować z papierosów i kieliszka wina”.

## Wieczny głód sukcesu. Jastrzębski Węgiel chce wygrać wszystko
 - [https://www.rp.pl/siatkowka/art39634181-wieczny-glod-sukcesu-jastrzebski-wegiel-chce-wygrac-wszystko](https://www.rp.pl/siatkowka/art39634181-wieczny-glod-sukcesu-jastrzebski-wegiel-chce-wygrac-wszystko)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-31T07:50:51+00:00

Jastrzębski Węgiel ma za sobą bardzo udany rok, ale władze klubu chcą więcej. Plany na nadchodzące miesiące są bardzo ambitne.

## Wojna Rosji z Ukrainą. Dzień 676
 - [https://www.rp.pl/live/art39639441-wojna-rosji-z-ukraina-dzien-676-relacja-na-zywo](https://www.rp.pl/live/art39639441-wojna-rosji-z-ukraina-dzien-676-relacja-na-zywo)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-12-31T05:00:00+00:00

24 lutego 2022 roku Rosja rozpoczęła pełnowymiarową inwazję na Ukrainę.

