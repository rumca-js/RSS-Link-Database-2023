# Source:searchmysite.net results, URL:https://searchmysite.net/api/v1/feed/search/browse/, language:en

## mattgadient.com | Tech stuff, some fixes/solutions, and occasionally a passionate rant.
 - [https://mattgadient.com](https://mattgadient.com)
 - RSS feed: https://searchmysite.net/api/v1/feed/search/browse/
 - date published: 2023-12-31T21:42:10.737714+00:00



## iliana.fyi
 - [https://iliana.fyi](https://iliana.fyi)
 - RSS feed: https://searchmysite.net/api/v1/feed/search/browse/
 - date published: 2023-12-31T21:42:10.737611+00:00



## Erthalion's blog
 - [https://erthalion.info/blog](https://erthalion.info/blog)
 - RSS feed: https://searchmysite.net/api/v1/feed/search/browse/
 - date published: 2023-12-31T21:42:10.737504+00:00



## James Long - blog & knowledge graph
 - [https://jlongster.com](https://jlongster.com)
 - RSS feed: https://searchmysite.net/api/v1/feed/search/browse/
 - date published: 2023-12-31T21:42:10.737265+00:00



## Math ∩ Programming
 - [https://jeremykun.com](https://jeremykun.com)
 - RSS feed: https://searchmysite.net/api/v1/feed/search/browse/
 - date published: 2023-12-31T19:05:07.574087+00:00



## eLib.at
 - [https://elib.at/index.php?title=Hauptseite](https://elib.at/index.php?title=Hauptseite)
 - RSS feed: https://searchmysite.net/api/v1/feed/search/browse/
 - date published: 2023-12-31T19:05:07.573982+00:00



## InspireMari.nl - Old school blog about life, cats and everything kawaii.
 - [https://inspiremari.nl](https://inspiremari.nl)
 - RSS feed: https://searchmysite.net/api/v1/feed/search/browse/
 - date published: 2023-12-31T19:05:07.573876+00:00



## joev.dev: thoughts, engineering, art, life
 - [https://joev.dev](https://joev.dev)
 - RSS feed: https://searchmysite.net/api/v1/feed/search/browse/
 - date published: 2023-12-31T19:05:07.573745+00:00



