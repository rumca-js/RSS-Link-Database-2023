# Source:Security Affairs, URL:https://securityaffairs.com/feed, language:en-US

## Google agreed to settle a $5 billion privacy lawsuit
 - [https://securityaffairs.com/156704/laws-and-regulations/google-settlement-5-billion-lawsuit.html](https://securityaffairs.com/156704/laws-and-regulations/google-settlement-5-billion-lawsuit.html)
 - RSS feed: https://securityaffairs.com/feed
 - date published: 2023-12-31T17:08:13+00:00

Google has agreed to settle a $5 billion privacy lawsuit, which alleged that the company monitored individuals using the Chrome &#8220;incognito&#8221; mode. Google agreed to settle a $5 billion privacy lawsuit over claims that the company monitored online activity of people who used the &#8216;incognito&#8217; mode in its Chrome web browser. The class action, filed [&#8230;]

## Security Affairs newsletter Round 452 by Pierluigi Paganini – INTERNATIONAL EDITION
 - [https://securityaffairs.com/156696/breaking-news/security-affairs-newsletter-round-452-by-pierluigi-paganini-international-edition.html](https://securityaffairs.com/156696/breaking-news/security-affairs-newsletter-round-452-by-pierluigi-paganini-international-edition.html)
 - RSS feed: https://securityaffairs.com/feed
 - date published: 2023-12-31T09:51:28+00:00

A new round of the weekly SecurityAffairs newsletter arrived! Every week the best security articles from Security Affairs are free for you in your email box. Enjoy a new round of the weekly SecurityAffairs newsletter, including the international press. INC RANSOM ransomware gang claims to have breached Xerox Corp Spotify music converter TuneFab puts users [&#8230;]

