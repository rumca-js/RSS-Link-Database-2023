# Source:Kotaku, URL:https://kotaku.com/rss, language:en

## Genre Bests, Personal Top 10 Lists And More: One Last Look Back At 2023
 - [https://kotaku.com/games-goty-best-rpgs-shooters-2023-1851129069](https://kotaku.com/games-goty-best-rpgs-shooters-2023-1851129069)
 - RSS feed: https://kotaku.com/rss
 - date published: 2023-12-31T15:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/97297007d11430488c00f71cc22526e9.jpg" /><p>This week, we continued taking stock of 2023 with looks back at how the Switch and the Steam Deck fared, our picks for the cream of the crop among shooters and role-playing games, and more juicy commentary on everything the year had to offer. </p><p><a href="https://kotaku.com/games-goty-best-rpgs-shooters-2023-1851129069">Read more...</a></p>

