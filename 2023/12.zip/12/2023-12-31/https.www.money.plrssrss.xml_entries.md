# Source:Money PL, URL:https://www.money.pl/rss/rss.xml, language:pl-PL

## Najwięksi krezusi PiS. Pięć osób, które zarobiły najwięcej w czasie Dobrej Zmiany
 - [https://www.money.pl/pieniadze/najwieksi-krezusi-pis-piec-osob-ktore-zarobily-najwiecej-w-czasie-dobrej-zmiany-6979720285969376a.html](https://www.money.pl/pieniadze/najwieksi-krezusi-pis-piec-osob-ktore-zarobily-najwiecej-w-czasie-dobrej-zmiany-6979720285969376a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-12-31T15:54:21+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/5480308d-2e07-454c-87ed-ebe71801b666" width="308" /> Okres Dobrej Zmiany pozwolił zarobić osobom związanym z obozem Zjednoczonej Prawicy całkiem spore sumy. Pięć osób z "listy milionerów PiS" otrzymało łącznie 56 mln zł. Kto znalazł się wśród tych szczęśliwców?

## Inwestorzy mają dużo powodów do świętowania po 2023 r.
 - [https://www.money.pl/gielda/tomasz-hondo/inwestorzy-maja-duzo-powodow-do-swietowania-po-2023-r-6978955618372576a.html](https://www.money.pl/gielda/tomasz-hondo/inwestorzy-maja-duzo-powodow-do-swietowania-po-2023-r-6978955618372576a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-12-31T15:15:53+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e34adf50-0b48-433a-ba44-1b676fc0de76" width="308" /> Kończący się 2023 rok okazał się, wbrew wielu pesymistycznym prognozom, zaskakująco pozytywny na rynkach finansowych.

## Zarobi miliard dolarów dosłownie za nic. To wyjątek nawet wśród najbogatszych
 - [https://www.money.pl/gielda/zarobi-miliard-dolarow-doslownie-za-nic-to-wyjatek-nawet-wsrod-najbogatszych-6979699264142304a.html](https://www.money.pl/gielda/zarobi-miliard-dolarow-doslownie-za-nic-to-wyjatek-nawet-wsrod-najbogatszych-6979699264142304a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-12-31T13:55:10+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/adeb100f-0755-4f56-9a15-a5b4413c82f1" width="308" /> Steve Ballmer to mało znany powszechnie miliarder, który ostatnio wskoczył na 5. miejsce listy najbogatszych Bloomberga. Co więcej, Ballmer w 2024 r. zarobi niemal miliard dolarów w gotówce dosłownie za nicnierobienie - podaje CNN. To spory wynik nawet w gronie najbogatszych.

## Podwyżki dla ponad 3 mln Polaków. Zarobki wzrosną już od 1 stycznia
 - [https://www.money.pl/gospodarka/podwyzki-dla-ponad-3-mln-polakow-zarobki-wzrosna-juz-od-1-stycznia-6979689830894560a.html](https://www.money.pl/gospodarka/podwyzki-dla-ponad-3-mln-polakow-zarobki-wzrosna-juz-od-1-stycznia-6979689830894560a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-12-31T13:02:54+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/d743cdc3-0f1b-460e-aa3f-5b2537e09f9f" width="308" /> Od początku nowego roku, czyli od 1 stycznia, minimalne wynagrodzenie za pracę ulegnie podwyższeniu, do kwoty 4242 zł brutto. Z kolei minimalna stawka godzinowa wyniesie 27,70 zł. Podwyżka dotknie ok. 3,6 mln osób w całej Polsce.

## Nie mieli nic wspólnego z aferą NCBiR, wciąż czekają na pieniądze. "Zostaliśmy niemal znokautowani"
 - [https://www.money.pl/pieniadze/nie-mieli-nic-wspolnego-z-afera-ncbir-wciaz-czekaja-na-pieniadze-zostalismy-niemal-znokautowani-6979671062445024a.html](https://www.money.pl/pieniadze/nie-mieli-nic-wspolnego-z-afera-ncbir-wciaz-czekaja-na-pieniadze-zostalismy-niemal-znokautowani-6979671062445024a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-12-31T11:36:28+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/24834d5b-c486-44a7-babe-2eaa3d77fa03" width="308" /> Wrocławska firma Aidar, specjalizująca się w produkcji oprogramowania do technologii wirtualnej i rozszerzonej rzeczywistości, w wyniku afery w Narodowym Centrum Badań i Rozwoju (NCBiR) wciąż nie otrzymała 1,7 mln zł dotacji. - Zostaliśmy przez państwową instytucję niemal znokautowani. Lata naszej pracy mogą teraz zostać zniweczone - tłumaczy przedstawiciel spółki w rozmowie z "Wyborczą".

## Fatalny sygnał z Chin. Tak źle nie było od miesięcy
 - [https://www.money.pl/gospodarka/fatalny-sygnal-z-chin-na-koniec-roku-tak-zle-nie-bylo-od-miesiecy-6979639138417152a.html](https://www.money.pl/gospodarka/fatalny-sygnal-z-chin-na-koniec-roku-tak-zle-nie-bylo-od-miesiecy-6979639138417152a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-12-31T09:19:28+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/317b96a1-f9b0-4ffe-87b2-6cfe2715f10f" width="308" /> W grudniu wskaźnik PMI dla przemysłu w Chinach skurczył się do najniższego poziomu od sześciu miesięcy. Spada popyt wewnętrzny i zamówienia z innych krajów. Wyniki ciągnie w dół słaba aktywność na rynku nieruchomości. Chińskie władze mogą wkrótce być zmuszone podjąć działania w celu stymulowania gospodarki.

## 800 plus wchodzi w życie. To będzie kosztować miliardy złotych
 - [https://www.money.pl/pieniadze/800-plus-wchodzi-w-zycie-to-bedzie-kosztowac-miliardy-zlotych-6979594148518880a.html](https://www.money.pl/pieniadze/800-plus-wchodzi-w-zycie-to-bedzie-kosztowac-miliardy-zlotych-6979594148518880a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-12-31T06:15:08+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/39c094cd-6e21-4a71-a70b-0e7420d4ad24" width="308" /> Od 1 stycznia 2024 r. kwota świadczenia wychowawczego wzrośnie z 500 zł do 800 zł. Rodzice otrzymają wypłaty w tych samych terminach, co dotychczas. Rząd szacuje, że 800 plus trafi do 6,6 mln dzieci. Wydatki budżetu państwa wzrosną o 24 mld zł.

