# Source:ArsTechnica, URL:https://feeds.arstechnica.com/arstechnica/index, language:en-US

## How archaeologists reconstructed the burning of Jerusalem in 586 BCE
 - [https://arstechnica.com/?p=1993081](https://arstechnica.com/?p=1993081)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2023-12-31T20:23:09+00:00

Hebrew bible is only surviving account of siege that laid waste to Solomon's Temple.

## Smartphone manufacturers still want to make foldables a thing
 - [https://arstechnica.com/?p=1993084](https://arstechnica.com/?p=1993084)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2023-12-31T04:26:56+00:00

Foldables are barely 1% of the market, but that's not stopping anyone but Apple.

