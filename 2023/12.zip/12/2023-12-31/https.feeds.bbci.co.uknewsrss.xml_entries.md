# Source:BBC, URL:https://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Match of the Day 2 analysis: What's wrong at Arsenal?
 - [https://www.bbc.co.uk/sport/av/football/67854563?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/67854563?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-31T23:32:11+00:00

Match of the Day 2 pundits Nedum Onuoha and Paul Robinson analyse how Fulham stopped Arsenal from going top of the Premier League.

## Match of the Day 2 Good 2 Bad: Mauricio Pochettino, silky skills and ponchos
 - [https://www.bbc.co.uk/sport/av/football/67854913?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/67854913?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-31T23:31:32+00:00

Watch 2 Good 2 Bad from Match of the Day 2, featuring some silky skills, poncho problems and a "mickey-taking mouse".

## Who is Frederik, the next king of Denmark once nicknamed 'Pingo'?
 - [https://www.bbc.co.uk/news/world-europe-67855112?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-67855112?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-31T23:04:07+00:00

"I don't want to lock myself in a fortress. I want to be myself," Crown Prince Frederik once said.

## January transfer window: Who could be on the move?
 - [https://www.bbc.co.uk/sport/football/67722978?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67722978?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-31T22:00:53+00:00

The January transfer window is open and several players have been linked with a move to and from Premier League clubs.

## Queen Margrethe II: Danish monarch's 52-year reign in pictures
 - [https://www.bbc.co.uk/news/in-pictures-67853397?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/in-pictures-67853397?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-31T20:44:12+00:00

83-year-old Margrethe II is Europe's longest-serving living monarch, having taken the throne in 1972.

## Spanish football fan held in Tehran released, Iran says
 - [https://www.bbc.co.uk/news/world-europe-67854444?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-67854444?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-31T19:19:20+00:00

Santiago Sánchez was detained during a trek in 2022 to the men's football World Cup in Qatar.

## Fulham 2-1 Arsenal: 'Lost' Gunners 'need a new striker' in January transfer window
 - [https://www.bbc.co.uk/sport/football/67854364?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67854364?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-31T18:43:33+00:00

Following Arsenal's 2-1 defeat at Fulham on New Year's Eve, manager Mikel Arteta claimed they would not need new signings in January. The truth, however, may be quite different.

## Queen of Denmark Margrethe II announces abdication live on TV
 - [https://www.bbc.co.uk/news/world-europe-67854395?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-67854395?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-31T18:23:27+00:00

Margrethe II, who has reigned for 52 years, will step down on 14 January to be replaced by her son.

## Arbroath goalkeeper Ali Adams scores 35-yard screamer
 - [https://www.bbc.co.uk/sport/av/football/67854712?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/67854712?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-31T18:00:43+00:00

Watch the goal everyone is talking about - Arbroath substitute goalkeeper Ali Adams scores from 35 yards against Raith Rovers.

## New Year celebrations: How the world is welcoming 2024
 - [https://www.bbc.co.uk/news/world-67854630?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-67854630?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-31T17:22:23+00:00

People around the world gather to celebrate the new year, with fireworks shows in major cities.

## Family 'heartbroken' after mother and son die in avalanche
 - [https://www.bbc.co.uk/news/uk-67853989?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-67853989?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-31T17:01:31+00:00

Kate Vokes, 54, and her son Archie, 22, were killed in an avalanche near Mont Blanc in the French Alps.

## Premiership: Leicester 35-22 Bath - Tigers end year with bonus-point win
 - [https://www.bbc.co.uk/sport/rugby-union/67843734?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/67843734?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-31T16:59:13+00:00

Leicester end 2023 by beating a much-changed Bath side, who miss the chance to go top of the Premiership.

## Fulham 2-1 Arsenal: Mikel Arteta on 'worst game of Gunners' season'
 - [https://www.bbc.co.uk/sport/av/football/67854044?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/67854044?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-31T16:58:22+00:00

Arsenal manager Mikel Arteta was "really disappointed" after his side's 2-1 loss at Fulham, describing the performance as "the worst game of the season".

## Tottenham 3-1 Bournemouth: Pape Sarr, Son Heung-min & Richarlison score for hosts
 - [https://www.bbc.co.uk/sport/football/67814390?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67814390?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-31T16:16:57+00:00

Tottenham finish 2023 on a high with victory over an energetic Bournemouth in the Premier League at Tottenham Hotspur Stadium.

## Fulham 2-1 Arsenal: Gunners beaten and miss chance to go top of Premier League
 - [https://www.bbc.co.uk/sport/football/67814391?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67814391?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-31T16:14:22+00:00

Arsenal miss chance to go top of the Premier League at new year after defeat at Fulham with Bukayo Saka's opener cancelled out by Raul Jimenez and Bobby Decordova-Reid

## Vladimir Putin makes little mention of Ukraine in new year speech
 - [https://www.bbc.co.uk/news/world-67853415?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-67853415?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-31T16:08:31+00:00

The Russian president hailed soldiers as heroes, but didn't directly mention the war in Ukraine.

## Luke Littler v Brendan Dolan: Teenager 'daring to dream' of World Championship glory
 - [https://www.bbc.co.uk/sport/darts/67853905?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/darts/67853905?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-31T16:02:08+00:00

Luke Littler says he is "daring to dream" of winning the PDC World Darts Championship as the 16-year-old prepares to face Northern Ireland's Brendan Dolan in the quarter-finals.

## Kai Zhuang: Police in Utah say student feared kidnapped may be 'camping'
 - [https://www.bbc.co.uk/news/world-us-canada-67854112?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-67854112?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-31T15:55:58+00:00

Police in Utah initially feared that missing Chinese student Kai Zhuang, 17, had been kidnapped.

## DR Congo election: President Felix Tshisekedi declared landslide winner
 - [https://www.bbc.co.uk/news/world-africa-67850563?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-67850563?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-31T15:24:00+00:00

President Tshisekedi wins a landslide with 73% of the vote, while the opposition calls for a rerun.

## Benjamin Kiplagat: Ugandan athlete stabbed to death in Kenya - reports
 - [https://www.bbc.co.uk/news/world-africa-67853338?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-67853338?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-31T14:20:01+00:00

Benjamin Kiplagat, 34, reached the semi-finals of the 2012 London Olympics in the 3,000m steeplechase.

## Tom Lockyer: Luton Town captain says he will meet specialists in the new year to determine his future in football
 - [https://www.bbc.co.uk/sport/football/67853237?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67853237?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-31T14:07:41+00:00

Luton Town captain Tom Lockyer says he will meet specialists in the new year to determine his future in football after suffering a cardiac arrest.

## John Pilger: Campaigning Australian journalist dies
 - [https://www.bbc.co.uk/news/world-australia-67853392?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-australia-67853392?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-31T12:47:48+00:00

Throughout his career, the writer was a vocal critic of Western foreign policy.

## Croydon house fire: Police try to identify men killed
 - [https://www.bbc.co.uk/news/uk-england-london-67852279?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-67852279?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-31T12:33:43+00:00

Three men have died and another is in a life-threatening condition.

## North Korea says it will launch three new spy satellites in 2024
 - [https://www.bbc.co.uk/news/world-asia-67851529?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-67851529?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-31T12:28:34+00:00

Setting out his aims for next year, Kim Jong Un also hardened his stance on unification with South Korea.

## US Navy helicopters destroy Houthi boats in Red Sea after attempted hijack
 - [https://www.bbc.co.uk/news/world-middle-east-67851897?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-67851897?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-31T12:10:08+00:00

The US military says it was responding to a second attack on the same vessel near Yemen in 24 hours.

## American bully XL dogs must now be kept on a lead
 - [https://www.bbc.co.uk/news/uk-67851343?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-67851343?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-31T11:21:56+00:00

Under new rules, owners of the breed must also ensure their dog is muzzled in public.

## Venice to ban large tourist groups and loudspeakers
 - [https://www.bbc.co.uk/news/world-europe-67851201?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-67851201?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-31T11:21:00+00:00

The new rules will come into effect in June and are part of an effort to ease the impact of tourism.

## Rohan Dennis: Australian cyclist reportedly charged by police with causing wife's death
 - [https://www.bbc.co.uk/sport/cycling/67852900?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cycling/67852900?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-31T11:18:13+00:00

Australian cyclist Rohan Dennis has reportedly been charged by police with the death of his wife after she was hit by a car on Saturday.

## Rafael Nadal says he may continue playing beyond 2024 after starting comeback in Brisbane
 - [https://www.bbc.co.uk/sport/tennis/67852702?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/67852702?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-31T10:53:50+00:00

Rafael Nadal makes his return to tennis at the Brisbane International after almost a year out and his desire to play on remains strong.

## Ukraine war: Russia hits back after Kyiv attack on border city
 - [https://www.bbc.co.uk/news/world-europe-67851431?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-67851431?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-31T10:48:17+00:00

The latest attacks on Kyiv and Kharkiv come after two days of major aerial assaults by both sides.

## Dominic Cummings: Sunak wanted me to secretly work on election strategy
 - [https://www.bbc.co.uk/news/uk-politics-67851985?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-67851985?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-31T10:31:00+00:00

Rishi Sunak twice met the former No 10 adviser to discuss campaigns, Downing Street says.

## If I’m not enjoying it, it could be my last year - Murray
 - [https://www.bbc.co.uk/sport/tennis/67852289?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/67852289?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-31T10:05:27+00:00

A shoulder injury, illness and a bruised knee made for a "tricky" pre-season for Andy Murray, who accepts it could be the final one of his career.

## United Cup: Katie Boulter beats Jessica Pegula in GB defeat by US
 - [https://www.bbc.co.uk/sport/tennis/67851879?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/67851879?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-31T09:54:11+00:00

GB's Katie Boulter records the best win of her career by beating American world number five Jessica Pegula at the United Cup in Perth.

## How will the UK economy compare to other countries in 2024?
 - [https://www.bbc.co.uk/news/business-66269947?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-66269947?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-31T02:29:13+00:00

After a tough 2023, will things improve for the UK and other economies in the new year?

## EastEnders: Max Bowden leaving role as Ben Mitchell
 - [https://www.bbc.co.uk/news/entertainment-arts-67851337?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-67851337?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-31T01:04:29+00:00

He departs next year but it is unclear if his character will be killed off or return at some stage.

## Vogue model Ellie Goldstein: 'Doctors said I wouldn't walk or talk'
 - [https://www.bbc.co.uk/news/uk-england-essex-67613146?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-essex-67613146?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-31T00:33:46+00:00

Model Ellie Goldstein, who has Down's syndrome, says people should never give up on their dreams.

## Big Ben: New Year's Eve marks 100 years of live bongs on radio
 - [https://www.bbc.co.uk/news/entertainment-arts-67632538?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-67632538?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-31T00:31:12+00:00

The UK's most famous chimes were first broadcast live by the BBC on New Year's Eve 1923.

## Sahara migrant smuggling: Double-edged sword of overturning Niger's ban
 - [https://www.bbc.co.uk/news/world-africa-67771597?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-67771597?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-31T00:27:53+00:00

Will Niger's ending of a seven-year ban on migrant-trafficking lead to more deaths?

## Rick Astley: Ready to roll into 2024 with BBC One New Year's Eve concert
 - [https://www.bbc.co.uk/news/entertainment-arts-67732552?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-67732552?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-31T00:26:07+00:00

The singer will be joined by Rylan Clark and Sharleen Spiteri for the BBC's New Year's Eve concert.

## Mason: Get ready - general election talk will dominate 2024
 - [https://www.bbc.co.uk/news/uk-politics-67771076?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-67771076?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-31T00:23:20+00:00

A new year, and all the political parties are focusing their planning and attention on the polls ahead.

## The Pavilion: The Pakistani cricket show that charmed Indians in 2023
 - [https://www.bbc.co.uk/news/world-asia-india-67650892?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-india-67650892?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-31T00:22:40+00:00

A show featuring top Pakistani cricketers won thousands of fans across the border in India in 2023.

## Bangladesh sees dramatic rise in lightning deaths linked to climate change
 - [https://www.bbc.co.uk/news/world-asia-67779223?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-67779223?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-31T00:21:04+00:00

Reported deaths and injuries due to lightning have risen dramatically in Bangladesh.

## Baldur's Gate 3, Lego Fortnite, and 7 other games that defined 2023
 - [https://www.bbc.co.uk/news/newsbeat-67726601?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-67726601?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-31T00:15:17+00:00

Despite lay-offs and the end of a gaming mainstay, 2023 was a year filled with brilliant video games.

## Inside Russia as war in Ukraine grinds into new year
 - [https://www.bbc.co.uk/news/world-europe-67843830?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-67843830?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-12-31T00:13:20+00:00

The BBC's Steve Rosenberg looks at life in a town near Moscow, and asks residents about the war.

