# Source:Wirtualne Media, URL:https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml, language:pl-PL

## TV Republika z kolejnych multipleksów naziemnych
 - [https://www.wirtualnemedia.pl/artykul/jak-odbierac-tv-republika-mux-l1-mux-l3-mux-l4-multipleks-polsat-box-cyfrowy-polsat-canal-upc-polska-vectra](https://www.wirtualnemedia.pl/artykul/jak-odbierac-tv-republika-mux-l1-mux-l3-mux-l4-multipleks-polsat-box-cyfrowy-polsat-canal-upc-polska-vectra)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-12-31T13:52:48.334724+00:00

TV Republika dołączyła do multipleksów lokalnych firmy MWE Teleport w Jeleniej Górze, we Wrocławiu i Świdnicy, gdzie zastąpiła kanał muzyczny Nuta TV. Fakt ten potwierdził w rozmowie z Wirtualnemeda.pl Michał Winnicki, właściciel Grupy MWE. -  Możemy komunikować tylko nowości dotyczące naszych własnych programów - zaznacza.

