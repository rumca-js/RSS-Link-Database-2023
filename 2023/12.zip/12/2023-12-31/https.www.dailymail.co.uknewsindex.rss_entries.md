# Source:Daily Mail, URL:https://www.dailymail.co.uk/news/index.rss, language:en-US

## Fox cub spotted cowering by a London roadside is given the gift of sight by life-saving vet after rescuers realise the six-month-old is blinded by cataracts in both eyes
 - [https://www.dailymail.co.uk/news/article-12915201/Fox-cub-spotted-cowering-London-roadside-given-gift-sight-life-saving-vet-rescuers-realise-six-month-old-blinded-cataracts-eyes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915201/Fox-cub-spotted-cowering-London-roadside-given-gift-sight-life-saving-vet-rescuers-realise-six-month-old-blinded-cataracts-eyes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T22:54:50+00:00

A group of animal lovers from arranging a sight-saving operation for a fox cub blinded by cataracts spotted cowering by a roadside in Woolwich, south-east London .

## New Year's Eve washout as wild storms disrupt celebrations on the Gold Coast but revellers refuse to let the heavy downpours dampen their spirits
 - [https://www.dailymail.co.uk/news/article-12915033/New-Years-Eve-storms-Gold-Coast-NYE.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915033/New-Years-Eve-storms-Gold-Coast-NYE.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T22:49:18+00:00

As wild weather lashed the Gold Coast on New Year's Eve plucky revellers refused to let it spoil their fun as hundreds braved torrential rain to ring in 2024 in style.

## One in five resort to buying their own medication online as patients face appointments crisis and doctor strikes
 - [https://www.dailymail.co.uk/news/article-12915191/One-five-resort-buying-medication-online-patients-face-appointments-crisis-doctor-strikes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915191/One-five-resort-buying-medication-online-patients-face-appointments-crisis-doctor-strikes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T22:36:10+00:00

A quarter of people have tried and failed to see their general practitioner over the past year, according to a nationwide survey, with 21 per cent of those polled resorting to buying medication without advice.

## Surfer is killed by shark in Maui: Rescuers rushed the victim to shore by jet ski but 39-year-old died of his wounds in hospital
 - [https://www.dailymail.co.uk/news/article-12915059/maui-hawaii-shark-attack-man-surfer-dead-Paia-Bay.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915059/maui-hawaii-shark-attack-man-surfer-dead-Paia-Bay.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T22:34:20+00:00

An unidentified man, 39, was killed by a shark in Maui, Hawaii as he surfed in Paia Bay. He was taken to Maui Memorial Medical Center where he later died of his injuries around 5.30pm.

## Five teenage boys including two as young as 14 are arrested on suspicion of rape after a girl was attacked in an alleyway
 - [https://www.dailymail.co.uk/news/article-12915189/five-teenagers-arrested-rape-st-marys-memorial-gardens-newark.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915189/five-teenagers-arrested-rape-st-marys-memorial-gardens-newark.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T22:30:30+00:00

The girl, whose age has not been released, was allegedly sexually assaulted on a path off St Mary's Memorial Gardens in Newark at around 7.45pm on Thursday, December 28.

## Pope Francis offers prayers for 'the tormented Ukrainian people and the Palestinian and Israeli populations' as he recalls 2023 as a year marked by wartime suffering
 - [https://www.dailymail.co.uk/news/article-12915131/Pope-Francis-offers-prayers-tormented-Ukrainian-people-Palestinian-Israeli-populations-recalls-2023-year-marked-wartime-suffering.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915131/Pope-Francis-offers-prayers-tormented-Ukrainian-people-Palestinian-Israeli-populations-recalls-2023-year-marked-wartime-suffering.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T22:28:09+00:00

In the last year, the Russian invasion of Ukraine has raged on, while Israel went to war with Hamas after the terrorist group slaughtered 1,200 Israelis on October 7.

## Man, 68, is arrested on suspicion of murder after two women are found dead in market town on New Year's Eve
 - [https://www.dailymail.co.uk/news/article-12915199/Man-arrested-murder-two-women-die-Park-Lane-cheadle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915199/Man-arrested-murder-two-women-die-Park-Lane-cheadle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T22:28:06+00:00

The women were found at a house in Park Lane, in the Staffordshire town of Cheadle, at around 3pm on Sunday afternoon.
Pictured: The entrance to Park Lane.

## CNN is slammed for airing Democrat's claims that Clarence Thomas should RECUSE himself from Trump ballot cases over wife's January 6 claims
 - [https://www.dailymail.co.uk/news/article-12914979/CNN-Democrats-Clarence-Thomas-recuse-Ginni-Jamie-Raskin-Donald-Trump-ballot-SCOTUS-Supreme-Court-January-wife.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914979/CNN-Democrats-Clarence-Thomas-recuse-Ginni-Jamie-Raskin-Donald-Trump-ballot-SCOTUS-Supreme-Court-January-wife.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T21:51:15+00:00

Democrat Rep Jamie Raskin said SCOTUS judge Clarence Thomas should recuse himself from Donald Trump 's ballot cases due to his wife's ties to Jan 6.

## Cargo ship carrying burning lithium ion batteries reaches Alaska but is kept offshore amid frantic battle to extinguish the blaze as crew fears explosion
 - [https://www.dailymail.co.uk/news/article-12915069/Cargo-ship-carrying-burning-lithium-ion-batteries-reaches-Alaska-kept-offshore-amid-frantic-battle-extinguish-blaze-crew-fears-explosion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915069/Cargo-ship-carrying-burning-lithium-ion-batteries-reaches-Alaska-kept-offshore-amid-frantic-battle-extinguish-blaze-crew-fears-explosion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T21:46:46+00:00

A large cargo ship carrying lithium batteries which caught on fire has reached Alaska but continues to be held three kilometers offshore while responders attempt to extinguish the blaze.

## Two-year-old girl dies after being found unconscious in a hot car in Eungella, Central Queensland
 - [https://www.dailymail.co.uk/news/article-12915037/Two-year-old-girl-dies-unconscious-hot-car-Eungella-Central-Queensland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915037/Two-year-old-girl-dies-unconscious-hot-car-Eungella-Central-Queensland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T21:28:29+00:00

A two-year-old girl has died after being found unconscious in a hot car  parked at a home in Central Queensland.

## New Year's Day stabbing: Three men knifed in Wolloomooloo after midnight
 - [https://www.dailymail.co.uk/news/article-12914919/New-Years-Day-stabbing-Three-men-knifed-Wolloomooloo-midnight.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914919/New-Years-Day-stabbing-Three-men-knifed-Wolloomooloo-midnight.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T21:24:36+00:00

Thousands flooded into the city centre on Sunday night to ring in the new year with more than 225,000 people crowding into 49 vantage points across Sydney to watch the fireworks display.

## Don't rain on our parade! Hardy Brits brave miserable weather as they hit the town for New Year's Eve parties and firework displays
 - [https://www.dailymail.co.uk/news/article-12914915/Brits-miserable-weather-New-Years-Eve-parties-firework-displays.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914915/Brits-miserable-weather-New-Years-Eve-parties-firework-displays.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T20:46:55+00:00

In true British fashion, large parts of the country are set to welcome 2024 in with a deluge of rain, but many who are out and about will do their best not to let it dampen their spirits.

## John Fetterman reveals he felt 'desolate' after opening up about depression and feared admission would end his career
 - [https://www.dailymail.co.uk/news/article-12914867/John-Fetterman-reveals-felt-desolate-opening-depression-feared-admission-end-career.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914867/John-Fetterman-reveals-felt-desolate-opening-depression-feared-admission-end-career.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T20:46:55+00:00

Senator John Fetterman has revealed he was concerned admitting his struggles with mental health would 'end' his political career.

## 'America is full!' Lindsey Graham laments as more migrants flood into US and senator vows Congress will approve more Ukraine aid if Biden's White House helps 'stop the flow' at the border
 - [https://www.dailymail.co.uk/news/article-12914857/America-Lindsey-Graham-laments-migrants-flood-senator-vows-Congress-approve-Ukraine-aid-Bidens-White-House-helps-stop-flow-border.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914857/America-Lindsey-Graham-laments-migrants-flood-senator-vows-Congress-approve-Ukraine-aid-Bidens-White-House-helps-stop-flow-border.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T20:46:41+00:00

Sen. Lindsey Graham said there is no more room in the U.S. for the continued migrants flooding over the southern border as he demanded President Joe Biden provide Congress the tools to stop the flow.

## Managing expectations, Joe? Biden tells reporters on his tropical getaway in St. Croix that his NYE resolution is 'to come back next year' - despite 2024 deciding fate of the White House
 - [https://www.dailymail.co.uk/news/article-12914849/joe-Biden-St-Croix-NYE-resolution.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914849/joe-Biden-St-Croix-NYE-resolution.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T20:45:25+00:00

The president, 81, revealed his one and only resolution for 2024 as he got into a car while on a winter vacation on St. Croix in the U.S. Virgin Islands.

## Facebook bans Libs of TikTok over breaking 'community standards' as popular conservative account slams 'extreme censorship' ahead of 2024 election
 - [https://www.dailymail.co.uk/news/article-12914819/Facebook-libs-tiktok-chaya-raichik-mark-zuckerberg.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914819/Facebook-libs-tiktok-chaya-raichik-mark-zuckerberg.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T20:38:56+00:00

Facebook has banned Libs of TikTok from their platform and said that the page violated 'community standards.' Chaya Raichik, the owner of the page then slammed the platform for preventing free speech.

## Infamous former Playboy Bunny Carole Gold is RELEASED from jail after being given life sentence for hiring hitman to execute her husband in 1992
 - [https://www.dailymail.co.uk/news/article-12914623/Playboy-Bunny-Carole-Gold-RELEASED-prison.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914623/Playboy-Bunny-Carole-Gold-RELEASED-prison.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T20:32:19+00:00

Currently 84, Carole Gold was released from the Perryville prison in Arizona on August 31, inmate records show, after being sentenced for the 1992 scheme.

## Meet the world's first Aussie-born queen: How Princess Mary worked as an advertising executive before meeting her future husband in a Sydney pub - with no idea he was Denmark's heir to the throne
 - [https://www.dailymail.co.uk/news/article-12914829/Meet-Princess-Mary-Denmark-worlds-Aussie-born-queen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914829/Meet-Princess-Mary-Denmark-worlds-Aussie-born-queen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T20:01:27+00:00

Mary was working as an advertising executive when she first met Frederik in a packed city pub 23 years ago and had no idea he was actually the future king of Denmark.

## New Year's Eve horror as woman in her 20s is killed in house fire - in latest deadly blaze this festive season
 - [https://www.dailymail.co.uk/news/article-12914591/New-Years-Eve-woman-20s-killed-house-fire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914591/New-Years-Eve-woman-20s-killed-house-fire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T19:49:37+00:00

A young woman died in hospital after an unexplained fire tore through her home in Oxford this morning, police have confirmed.

## Former Alcatraz residents recall its wild parties and dark secrets - with one revealing how the notorious lock-up known for housing criminals like Al Capone was 'a really wonderful place to live'
 - [https://www.dailymail.co.uk/news/article-12877901/Former-Alcatraz-residents-recall-wild-parties-dark-secrets-prison-Al-Capone.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12877901/Former-Alcatraz-residents-recall-wild-parties-dark-secrets-prison-Al-Capone.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T19:44:14+00:00

Better known for it's notorious criminal residents - including Al Capone and Alvin 'Creepy' Carvis - the island off the coast of San Francisco was also home to several civilian families.

## Spate of homeless camp shootings in LA, Vegas, New Hampshire and North Carolina leave communities on edge
 - [https://www.dailymail.co.uk/news/article-12869667/Homeless-shootings-LA-Vegas-New-Hampshire-North-Carolina.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12869667/Homeless-shootings-LA-Vegas-New-Hampshire-North-Carolina.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T19:42:11+00:00

Homeless communities across the country have been hit by a wave of violent attacks - with encampments in four different states targeted by shooters in just three months.

## Five men aged between 19 and 34 are arrested on suspicion of murder after man is found dead at seaside hotel
 - [https://www.dailymail.co.uk/news/article-12914865/police-arrest-men-murder-hotel-central-weymouth-dorset.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914865/police-arrest-men-murder-hotel-central-weymouth-dorset.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T19:39:53+00:00

Police were called to the Hotel Central in Weymouth, Dorset, on Saturday night at 11.07pm where a man 'required medical assistance'. He was pronounced dead shortly after midnight.

## Mother's heartbreak after grave dedicated to her tragic stillborn baby is destroyed SIX times in two years by 'scum of the earth' vandals
 - [https://www.dailymail.co.uk/news/article-12914859/Mothers-heartbreak-grave-dedicated-tragic-stillborn-baby-destroyed-SIX-times-two-years-scum-earth-vandals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914859/Mothers-heartbreak-grave-dedicated-tragic-stillborn-baby-destroyed-SIX-times-two-years-scum-earth-vandals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T19:38:47+00:00

Charlotte Haynes daughter Bonnie was buried at Gorton Cemetery in Greater Manchester following her stillbirth in September 2021 and has since been vandalised on multiple occasions.

## Now clampdown on illegal e-scooters: Calls for urgent ban as figures show illicit two-wheeled vehicles account for more than HALF of all casualties they claim
 - [https://www.dailymail.co.uk/news/article-12914655/Calls-urgent-ban-illegal-e-scooters.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914655/Calls-urgent-ban-illegal-e-scooters.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T19:08:55+00:00

Data has found that in the year leading up to June 2023, 556 of the 1,080 casualties caused by e-scooter collisions were caused by scooters used outside designated trial areas.

## The chain-smoking 'people's monarch': How Denmark's Queen Margrethe defied convention by doing her own supermarket shopping and lighting cigarettes in public - and was even a set designer for a Netflix film
 - [https://www.dailymail.co.uk/news/article-12914771/queen-margrethe-chain-smoking-supermarket-shopping-netflix-film.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914771/queen-margrethe-chain-smoking-supermarket-shopping-netflix-film.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T18:35:16+00:00

Denmark's Queen Margrethe II shocked the world tonight announcing her abdication from the throne in her traditional New Year's Eve speech.

## Rep. Jamie Raskin demands Justice Clarence Thomas recuse himself from 14th Amendment case on disqualifying Trump from 2024 ballot as Colorado case could head to Supreme Court
 - [https://www.dailymail.co.uk/news/article-12914705/Rep-Jamie-Raskin-demands-Justice-Clarence-Thomas-recuse-14th-Amendment-case-disqualifying-Trump-2024-ballot-Colorado-case-head-Supreme-Court.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914705/Rep-Jamie-Raskin-demands-Justice-Clarence-Thomas-recuse-14th-Amendment-case-disqualifying-Trump-2024-ballot-Colorado-case-head-Supreme-Court.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T18:19:51+00:00

Rep. Jamie Raskin said conservative Supreme Court Justice Clarence Thomas should excuse himself from ruling on cases involving Trump's ability to remain on the 2024 presidential ballot.

## Leah Mullins mother makes desperate plea to missing daughter, 14, wearing a Bambi t-shirt who was last seen getting into a dark car near a pub: 'Please come home, you're not in trouble:'
 - [https://www.dailymail.co.uk/news/article-12914737/missing-leah-mullins-mother-plea-sherston-malmesbury.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914737/missing-leah-mullins-mother-plea-sherston-malmesbury.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T18:19:44+00:00

Leah Mullins, 14, from Sherston, near Malmesbury, was last seen at around 7.30pm on Friday evening and her family are growing increasingly concerned for her welfare.

## Virginia college graduate goes viral after eating and reviewing the final meals of death row inmates including notorious serial killers Ted Bundy and John Wayne Gacy
 - [https://www.dailymail.co.uk/news/article-12914339/death-row-meals-josh-slavin-ted-bundy-john-wayne-gacy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914339/death-row-meals-josh-slavin-ted-bundy-john-wayne-gacy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T17:56:43+00:00

Josh Slavin, 23, has made, tasted and rated last meals of infamous serial killers and posted videos of each one on his Instagram. He gave an overall rating of each one after he tried it.

## Harvard Crimson editorial board SPLITS over embattled president Claudine Gay and two members call for her to quit over anti-semitism denial debacle and plagiarism claims - saying they need a 'leader who can do better'
 - [https://www.dailymail.co.uk/news/article-12914637/Harvard-Crimson-editorial-board-SPLITS-president-Claudine-Gay.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914637/Harvard-Crimson-editorial-board-SPLITS-president-Claudine-Gay.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T17:31:53+00:00

The Crimson, which was founded in 1873, has decided to back Gay despite the swirling antisemitism and plagiarism allegations lodged against her in the last three months.

## Highly-contagious infection spread by feces breaks out in Portland as homeless crisis sparks disease common in Third World
 - [https://www.dailymail.co.uk/news/article-12914469/Shigella-infection-Portland-homeless-crisis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914469/Shigella-infection-Portland-homeless-crisis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T17:19:49+00:00

Shigella is a bacteria that spreads through human feces. People transmit the infection after getting the bacteria on their hands and by touching their mouths.

## Nikki Haley's chances of a win in New Hampshire could be foiled by Chris Christie's candidacy, says Gov. Chris Sununu
 - [https://www.dailymail.co.uk/news/article-12914477/Nikki-Haleys-chances-win-New-Hampshire-foiled-Chris-Christies-candidacy-says-Gov-Chris-Sununu.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914477/Nikki-Haleys-chances-win-New-Hampshire-foiled-Chris-Christies-candidacy-says-Gov-Chris-Sununu.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T17:19:46+00:00

'There's no doubt that, if Christie stays in the race, the risk is that he takes [Haley's] margin of the win,' New Hampshire Gov. Chris Sununu told CNN in urging Chris Christie to 'do the right thing.'

## Family of British mother, 54, and her son, 22, were killed in French Alps avalanche are 'beyond heartbroken' following 'tragic accident' - as police hunt cross-country skiiers who may have sparked disaster
 - [https://www.dailymail.co.uk/news/article-12914563/Family-British-mother-54-son-22-killed-French-Alps-avalanche-heartbroken-following-tragic-accident-police-hunt-cross-country-skiiers-sparked-disaster.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914563/Family-British-mother-54-son-22-killed-French-Alps-avalanche-heartbroken-following-tragic-accident-police-hunt-cross-country-skiiers-sparked-disaster.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T16:30:34+00:00

Kate Vokes, 54, and her son Archie Vokes, 22, died when an avalanche swept through an off-piste area of the Saint-Gervais-les-Bains ski resort near Mont Blanc on December 28.

## More than they bargained for! Winter Wonderland ride breaks down in mid-air leaving thrillseekers dangling for 35 MINUTES - a year after slingshot attraction malfunctioned
 - [https://www.dailymail.co.uk/news/article-12914463/Winter-Wonderland-ride-breaks-mid-air-leaving-thrillseekers-dangling-35-MINUTES-year-slingshot-attraction-malfunctioned.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914463/Winter-Wonderland-ride-breaks-mid-air-leaving-thrillseekers-dangling-35-MINUTES-year-slingshot-attraction-malfunctioned.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T16:27:50+00:00

Stomach-churning footage posted on social media shows the giant ride leaning still at a diagonal as it towers over the rest of Hyde Park in London.

## Ron DeSantis commits to PARDONING Trump if he is convicted of any charges he faces as president and compares it to Ford doing the same for Nixon
 - [https://www.dailymail.co.uk/news/article-12914425/ron-desantis-donald-trump-pardon.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914425/ron-desantis-donald-trump-pardon.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T16:22:53+00:00

The declaration, provided to reporters Friday, came after the Florida governor's appearance in Iowa Friday, and clarifies DeSantis's half-handed answers on how he would use his powers if elected.

## Jack Grealish cops probe if burglary gang behind £1m Boxing Day raid 'were given inside information' about footballer's whereabouts before staging terrifying home invasion
 - [https://www.dailymail.co.uk/news/article-12914435/Jack-Grealish-burglary-inside-information-footballers-whereabouts.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914435/Jack-Grealish-burglary-inside-information-footballers-whereabouts.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T15:23:23+00:00

EXCLUSIVE: Burglars struck the Manchester City winger's home in Cheshire on December 26, while he was playing against Everton at Goodison Park, and stole up to £1million in jewels and watches.

## Ohio man nearly dies after eating FOUR poisonous mushrooms he foraged from his backyard with his Italian pasta - and claims smartphone app Plant Identifier told him fungi was EDIBLE
 - [https://www.dailymail.co.uk/news/article-12914349/Ohio-man-nearly-dies-eating-FOUR-poisonous-mushrooms-foraged-backyard-Italian-pasta-claims-smartphone-app-Plant-Identifier-told-fungi-EDIBLE.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914349/Ohio-man-nearly-dies-eating-FOUR-poisonous-mushrooms-foraged-backyard-Italian-pasta-claims-smartphone-app-Plant-Identifier-told-fungi-EDIBLE.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T15:22:26+00:00

An Ohio man experienced a brush with death after accidentally eating four poisonous mushrooms that his plant identifier app told him were edible.

## Woman is rushed to hospital after she's 'attacked' at £500k bungalow in quiet Dorset cul-de-sac
 - [https://www.dailymail.co.uk/news/article-12914437/Woman-rushed-hospital-shes-attacked-500k-bungalow-quiet-Dorset-cul-sac.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914437/Woman-rushed-hospital-shes-attacked-500k-bungalow-quiet-Dorset-cul-sac.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T15:16:46+00:00

A woman suffered a serious head injury in an incident outside an address in Priors Close, Christchurch, Dorset.

## Networks plan for the worst this NYE in NYC and are prepared to pull A-list hosts - as anti-Israel protesters threaten to derail celebrations for 1M plus revelers across the Big Apple
 - [https://www.dailymail.co.uk/news/article-12914343/Networks-plan-worst-NYE-NYC-protesters-threaten-derail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914343/Networks-plan-worst-NYE-NYC-protesters-threaten-derail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T15:13:04+00:00

Anti-Israel protesters are threatening to derail December 31 celebrations in the Big Apple - where more than one million revelers are expected to be bringing in the new year.

## Joe Lieberman says his 2024 goal is for No Labels to get 'a third line on the ballot in all 50 states' while Sen. Joe Manchin and ex- Maryland Gov. Larry Hogan are top contenders for the ticket
 - [https://www.dailymail.co.uk/news/article-12914401/Joe-Lieberman-says-2024-No-Labels-ballot-Joe-Manchin-Larry-Hogan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914401/Joe-Lieberman-says-2024-No-Labels-ballot-Joe-Manchin-Larry-Hogan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T15:11:51+00:00

No Labels is working to get a ticket of candidates on the 2024 ballot - with Sen. Joe Manchin (D-W.V.) and former Maryland Gov. Larry Hogan (R) leading the field of potential hopefuls.

## Unmasked! The REAL celebrity villains - and heroes - of 2023: MAUREEN CALLAHAN's deadly and hilarious verdict... from Swift-mania and Scandoval, to the beastly Bezoses, Gwynnie on trial... and a royally gruesome twosome!
 - [https://www.dailymail.co.uk/news/article-12894609/Unmasked-REAL-celebrity-villains-heroes-2023-MAUREEN-CALLAHAN.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12894609/Unmasked-REAL-celebrity-villains-heroes-2023-MAUREEN-CALLAHAN.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T14:59:47+00:00

This year gave us no shortage of heroes and villains - from the triumphs of Swift and 'Succession', to the shamelessness of George Santos and a certain California-based couple in exile...

## Glammed up NYE revellers spill onto the streets in Sydney as city fills up with a million strong crowd ahead of midnight fireworks
 - [https://www.dailymail.co.uk/news/article-12914257/New-Years-Eve-Australia-Sydney-fireworks-party.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914257/New-Years-Eve-Australia-Sydney-fireworks-party.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T14:35:36+00:00

Revellers spilled onto the street after the clock struck 12, scrambling to make their way home or in some cases, keep the party going.

## An air guitar-playing kangaroo, a ballet-dancing otter and one VERY angry bird... winners of the 2023 Comedy Wildlife Photography Awards revealed
 - [https://www.dailymail.co.uk/news/article-12860777/An-air-guitar-playing-kangaroo-ballet-dancing-otter-one-angry-bird-winners-2023-Comedy-Wildlife-Photography-Awards-revealed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12860777/An-air-guitar-playing-kangaroo-ballet-dancing-otter-one-angry-bird-winners-2023-Comedy-Wildlife-Photography-Awards-revealed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T14:14:48+00:00

Animal lovers looking to laugh will enjoy this year's winning pictures at the Comedy Wildlife Photography Awards.

## The business of Mickey Mouse: How Disney's original creation has helped company reach its $171 billion worth over 95 years as character's copyright expires in January
 - [https://www.dailymail.co.uk/news/article-12877237/Mickey-Mouse-worth-Disney-creation-century-business.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12877237/Mickey-Mouse-worth-Disney-creation-century-business.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T14:14:32+00:00

Mickey Mouse has brought in billions for Disney over the past century through box office sales, TV series, merchandise, toys and gadgets, theme parks, partnerships and general promotion of the brand.

## Eleanor Hunton Hoppe - Virginia socialite mom snared in FBI pedophile sting - makes another bid for freedom, claiming inadequate medical care behind bars
 - [https://www.dailymail.co.uk/news/article-12901837/Virginia-socialite-mom-Eleanor-Hunton-Hoppe-second-bid-freedom.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12901837/Virginia-socialite-mom-Eleanor-Hunton-Hoppe-second-bid-freedom.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T14:13:47+00:00

Eleanor Hunton Hoppe has again asked for pre-trial release from the Central Detention Facility in Washington DC where she has been held since her dramatic arrest at a hotel in March.

## His mother is a hellraising icon of fashion, music and film - and he's inherited her striking looks. So, can you guess who he is?
 - [https://www.dailymail.co.uk/news/article-12865813/His-mother-hellraising-icon-fashion-music-film-hes-inherited-striking-looks-guess-is.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12865813/His-mother-hellraising-icon-fashion-music-film-hes-inherited-striking-looks-guess-is.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T14:11:48+00:00

He is the handsome model son of '70s model Grace Jones and French graphic designer and illustrator Jean-Paul Goude

## The winners and losers of 2023: Taylor Swift is the standout success (with Travis Kelce at her side), joined by Barbenheimer and Gwyneth Paltrow - while Sam Bankman-Fried and George Santos join Hunter Biden and Bud Light on the list of colossal failures
 - [https://www.dailymail.co.uk/news/article-12890155/winners-losers-2023-Taylor-Swift-Travis-Kelce-Hunter-Biden-Bud-Light.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12890155/winners-losers-2023-Taylor-Swift-Travis-Kelce-Hunter-Biden-Bud-Light.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T14:08:33+00:00

DailyMail.com chronicles ten of the year's greatest victors - and ten of its colossal failures.

## Australia welcomes 2024 in style with spectacular fireworks extravaganza as millions of revellers line Sydney Harbour to get the perfect vantage point
 - [https://www.dailymail.co.uk/news/article-12914329/New-Years-Eve-2024-fireworks-Sydney-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914329/New-Years-Eve-2024-fireworks-Sydney-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T13:59:28+00:00

Huge crowds of Aussies have gathered across the country to celebrate the beginning on 2024 with spectacular fireworks displays, with millions flocking to Sydney Harbour to get the best view.

## We deployed to Iraq and Afghanistan years ago, but we are still losing men: Veterans from the War on Terror who have struggled since returning home reveal how suicide still ravages the men they served with
 - [https://www.dailymail.co.uk/news/article-12904185/We-deployed-Iraq-Afghanistan-years-ago-losing-men-Veterans-War-Terror-struggled-returning-home-reveal-suicide-ravages-men-served-with.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12904185/We-deployed-Iraq-Afghanistan-years-ago-losing-men-Veterans-War-Terror-struggled-returning-home-reveal-suicide-ravages-men-served-with.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T13:55:18+00:00

After two deployments in Afghanistan and Iraq , the horrors of the War on Terror didn't end for Army Staff Sergeant Mark Kershaw and his unit.

## Biden administration doesn't 'want to turn ANYONE away' at the border: Republican Senator Eric Schmitt says 'nine out of 10 asylum claims are bogus' in interview with Daily Mail laying out his predictions for next year
 - [https://www.dailymail.co.uk/news/article-12894677/Biden-administration-doesnt-want-turn-away-border-Republican-Senator-Eric-Schmitt-says-nine-10-asylum-claims-bogus-interview-Daily-Mail-laying-predictions-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12894677/Biden-administration-doesnt-want-turn-away-border-Republican-Senator-Eric-Schmitt-says-nine-10-asylum-claims-bogus-interview-Daily-Mail-laying-predictions-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T13:55:10+00:00

Sen. Eric Schmitt predicted Congress will never come together on a foreign aid and immigration package because Biden 'is not interested at all in securing our southern border.'

## 'The beginning of the end': The preppers who fear global meltdown in 2024 caused by 'perfect storm' of war, soaring costs of living and the migrant crisis - plus a presidential election which threatens to tear America in half
 - [https://www.dailymail.co.uk/news/article-12877275/global-conflicts-cost-living-election-preppers-2024.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12877275/global-conflicts-cost-living-election-preppers-2024.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T13:54:22+00:00

Global conflicts. Rising costs of living. The migrant crisis.

## The glamour and grit of Golden Age America - after dark: Inside Manhattan's 1940s and 1950s nightlife scene
 - [https://www.dailymail.co.uk/news/article-12878389/The-glamour-grit-Golden-Age-America-dark-Inside-Manhattans-1940s-1950s-nightlife-scene.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12878389/The-glamour-grit-Golden-Age-America-dark-Inside-Manhattans-1940s-1950s-nightlife-scene.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T13:54:04+00:00

It's the city that never sleeps... and never was that truer than in the heyday of Manhattan nightlife - the post-war 1940s and the Golden Age of the 1950s.

## Fury as luxury £450k beach huts on Dorset sandbank face being cut off from the mainland until the SUMMER as council 'takes ages' to fix 'lifeline' jetty damaged by Storm Ciaran
 - [https://www.dailymail.co.uk/news/article-12914291/luxury-beach-huts-dorset-cut-damage-storm-ciaran-cut-summer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914291/luxury-beach-huts-dorset-cut-damage-storm-ciaran-cut-summer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T13:51:54+00:00

Furious owners at the remote Mudeford Sandbank have told the local council to 'pull their finger out' and repair the section of the jetty which has been closed since November.

## GoFundMe fundraiser to help Good Samaritan Chris Marriott's grief-stricken family raises around £30k - as murder-accused appears in court over Sheffield 'car ram attack'
 - [https://www.dailymail.co.uk/news/article-12914355/GoFundMe-fundraiser-help-Good-Samaritan-Chris-Marriotts-grief-stricken-family-raises-30k-murder-accused-appears-court-Sheffield-car-ram-attack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914355/GoFundMe-fundraiser-help-Good-Samaritan-Chris-Marriotts-grief-stricken-family-raises-30k-murder-accused-appears-court-Sheffield-car-ram-attack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T13:50:23+00:00

Father-of-two Chris Marriott was mowed down and killed by a car as he tried to help a woman who was unconscious in the street in the Burngreave area of Sheffield, South Yorkshire, on Wednesday.

## Remember this Rishi? Moment Sunak insisted Dominic Cummings would have 'absolutely nothing to do with any government that I lead' - amid claims PM 'held secret talks with ex-aide to bring him back to No10'
 - [https://www.dailymail.co.uk/news/article-12914333/Rishi-Sunak-Dominic-Cummings-government-secret-talks-return-No10.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914333/Rishi-Sunak-Dominic-Cummings-government-secret-talks-return-No10.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T13:47:27+00:00

A clip from the Tory leadership contest in 2022 shows Mr Sunak play down rumours that Mr Cummings had any role in his campaign and would have no role in his government.

## Australian traveller slams meal deals as 'confusing' as he reveals the strangest things about living in the UK
 - [https://www.dailymail.co.uk/news/article-12909715/Australian-traveller-slams-meal-deals-confusing-reveals-strangest-things-living-UK.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12909715/Australian-traveller-slams-meal-deals-confusing-reveals-strangest-things-living-UK.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T13:32:45+00:00

Marc Murphy, from Australia, relocated to Scotland, UK, in January 2023 and has since experienced a 'culture shock' of finding meal deals in pharmacies and a lack of vanilla Coca Cola

## US Navy sinks three Houthi militant boats in the Red Sea after they attacked a Maersk merchant ship with missiles - amid heightened operations to protect vital shipping lane
 - [https://www.dailymail.co.uk/news/article-12914295/US-Navy-sinks-three-Houthi-boats-Red-Sea-rebels.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914295/US-Navy-sinks-three-Houthi-boats-Red-Sea-rebels.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T13:10:55+00:00

The incident, confirmed by The United States Central Command (CENTCOM) Sunday, comes as the US continues its patrol mission to counter threats from the Iranian-backed rebels.

## Married British woman, 43, took her own life with a poison she bought from Amazon after using internet chat site to forge a suicide pact with fellow members, inquest hears
 - [https://www.dailymail.co.uk/news/article-12914211/married-british-woman-suicide-poison-amazon-internet-chat-pact.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914211/married-british-woman-suicide-poison-amazon-internet-chat-pact.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T13:06:14+00:00

Chloe Macdermott, 43, took her own life using an unnamed 'product' ordered from the United States in 2021 after she joined an online forum that 'encouraged' suicide.

## John Pilger, Australian journalist and documentary filmmaker, dies aged 84: Heartbroken family pay tribute to 'the most amazing and loved Dad, Grandad and partner'
 - [https://www.dailymail.co.uk/news/article-12914313/Journalist-John-Pilger-dies-aged-84.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914313/Journalist-John-Pilger-dies-aged-84.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T13:02:10+00:00

Mr Pilger, who made his name as a foreign correspondent, reported on some of the most important world events of the 20th century, including the Vietnam War and Pol Pot's dictatorship.

## Cronulla blue grouper: Outrage as fisherman illegally spears protected species at a popular beach
 - [https://www.dailymail.co.uk/news/article-12914157/Cronulla-blue-grouper-fisherman-illegally-spears-protected-species.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914157/Cronulla-blue-grouper-fisherman-illegally-spears-protected-species.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T12:56:36+00:00

The fisherman on Saturday 'triumphantly' pulled the protected species from the Oak Park rock pool in Cronulla - a no-spearfishing zone in South Sydney .

## Two children rushed to hospital after being found floating in the Perth River near New Year's Eve revellers
 - [https://www.dailymail.co.uk/news/article-12914319/Perth-River-two-children-hospital.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914319/Perth-River-two-children-hospital.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T12:46:36+00:00

The boy and girl, both under the age of 10, were spotted at Burswood near Perth Stadium about 5.15pm on Sunday.

## ABC is slammed for making New Year's Eve 9pm show all about 'Invasion Day' with 'woke' Aboriginal rappers - as disappointed parents ask: 'Where's the Bluey fireworks for kids?'
 - [https://www.dailymail.co.uk/news/article-12914179/ABC-slammed-making-New-Years-Eve-9pm-Invasion-Day-woke-Aboriginal-rapper-disappointed-parents-ask-Wheres-Bluey-fireworks-kids.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914179/ABC-slammed-making-New-Years-Eve-9pm-Invasion-Day-woke-Aboriginal-rapper-disappointed-parents-ask-Wheres-Bluey-fireworks-kids.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T12:40:45+00:00

The ABC has been slammed over its coverage the family friendly 9pm New Year's Eve fireworks, with fed-up Aussies venting their frustrations at the 'woke' display.

## Queen Camilla admits she is 'hopeless' at mimicking characters when reading Harry Potter to her grandchildren - and says King Charles is a much better impressionist who can 'do all the voices'
 - [https://www.dailymail.co.uk/news/article-12913603/Queen-Camilla-admits-hopeless-mimicking-characters-reading-Harry-Potter-grandchildren-says-King-Charles-better-impressionist-voices.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913603/Queen-Camilla-admits-hopeless-mimicking-characters-reading-Harry-Potter-grandchildren-says-King-Charles-better-impressionist-voices.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T12:06:51+00:00

The 76-year-old has been delving into her literary favourites in a new podcast series called The Queen's Reading Room , which will be released weekly from January 8.

## Ben Needham's mother reveals Alex Batty's reappearance has given her fresh hope - more than 30 years after toddler went missing in Greece
 - [https://www.dailymail.co.uk/news/article-12914059/Ben-Needhams-mother-reveals-Alex-Battys-reappearance-given-fresh-hope-30-years-toddler-went-missing-Greece.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914059/Ben-Needhams-mother-reveals-Alex-Battys-reappearance-given-fresh-hope-30-years-toddler-went-missing-Greece.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T12:04:04+00:00

Kerry, Ben Needham's mother, says her hope for finding her son, who went missing at just 21 months in 1991, has been renewed following the reappearance of Alex Batty

## Man in his 30s is stabbed at award-winning Indian restaurant - as police launch probe into attack
 - [https://www.dailymail.co.uk/news/article-12914217/Man-30s-stabbed-award-winning-Indian-restaurant-police-launch-probe-attack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914217/Man-30s-stabbed-award-winning-Indian-restaurant-police-launch-probe-attack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T11:57:27+00:00

Up to nine police cars were spotted outside Westbourne Tandoori in Bournemouth after a stabbing.

## Police probe horror Croydon house fire that left three Polish men dead and two others injured - as detectives investigate cause of blaze
 - [https://www.dailymail.co.uk/news/article-12914235/Croydon-house-fire-polish-men-dead-police-probe.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914235/Croydon-house-fire-polish-men-dead-police-probe.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T11:56:32+00:00

Emergency services rushed to the two-storey, end-of-terrace house on Sanderstead Road just after 11pm on Friday, where two men were declared dead.

## Moment e-scooter rider is caught hurtling down the M5 'while twice the drink-drive limit' - as 29-year-old man is charged
 - [https://www.dailymail.co.uk/news/article-12914223/Moment-e-scooter-rider-caught-hurtling-M5-twice-drink-drive-limit-29-year-old-man-charged.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914223/Moment-e-scooter-rider-caught-hurtling-M5-twice-drink-drive-limit-29-year-old-man-charged.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T11:51:52+00:00

Jamal Rabeh, 29, of Staplegrove, Somerset, is accused of driving while under the influence of alcohol, driving without insurance and being a learner driver on a motorway.

## Moment car overtaking Jeremy Vine nearly crashes into oncoming cyclist in Richmond Park - as driver is furiously called an 'a**hole' in near-collision
 - [https://www.dailymail.co.uk/news/article-12914189/Moment-car-overtaking-Jeremy-Vine-nearly-crashes-oncoming-cyclist-Richmond-Park-driver-furiously-called-hole-near-collision.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914189/Moment-car-overtaking-Jeremy-Vine-nearly-crashes-oncoming-cyclist-Richmond-Park-driver-furiously-called-hole-near-collision.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T11:50:32+00:00

Footage posted by BBC presenter Jeremy Vine on social media shows a car driving past cyclist Vine while ensuring a wide overtake in Richmond Park.

## How Hamas brainwash children to become jihadis: Terrorists teach Gazan kids how to shoot guns, launch anti-tank missiles and stage suicide attacks against Israel at summer camps - after indoctrinating them with anti-Semitic Mickey Mouse knock-off
 - [https://www.dailymail.co.uk/news/article-12914133/How-Hamas-brainwash-children-jihadis-Terrorists-teach-Gazan-kids-shoot-guns-launch-anti-tank-missiles-stage-suicide-attacks-against-Israel-summer-camps-indoctrinating-anti-Semitic-Mickey-Mouse-knock-off.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914133/How-Hamas-brainwash-children-jihadis-Terrorists-teach-Gazan-kids-shoot-guns-launch-anti-tank-missiles-stage-suicide-attacks-against-Israel-summer-camps-indoctrinating-anti-Semitic-Mickey-Mouse-knock-off.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T11:43:19+00:00

Farfour the Mouse, a costumed character with a high-pitched voice who captured the attention of children, was broadcast on Al-Aqsa, the Hamas-run TV channel at the centre of its propaganda

## We live in one of Britain's most remote villages - we've lost our library, shop and bus service, and now the Royal Mail's shut our one post box. We feel completely cut off
 - [https://www.dailymail.co.uk/news/article-12914195/We-live-one-Britains-remote-villages-weve-lost-library-shop-bus-service-Royal-Mails-shut-one-post-box-feel-completely-cut-off.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914195/We-live-one-Britains-remote-villages-weve-lost-library-shop-bus-service-Royal-Mails-shut-one-post-box-feel-completely-cut-off.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T11:12:24+00:00

Villagers in Bradford Abbas, Dorset, have already lost their library, shop and bus service and now will have to fork out £30 on a taxi ride just to send letters and cards.

## Man wages war with council after mystery neighbour reports him over subtle colour of his £350k house - can YOU spot what the fuss was about?
 - [https://www.dailymail.co.uk/news/article-12907285/Man-wages-war-council-mystery-neighbour-reports-subtle-colour-350k-house-spot-fuss-about.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12907285/Man-wages-war-council-mystery-neighbour-reports-subtle-colour-350k-house-spot-fuss-about.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T11:08:18+00:00

EXCLUSIVE: Chris Elston wanted to give his house in a Norwich conservation area a face lift and opted for an off-white paintjob with a subtle yellow tinge but was reported to the council by a nosey local.

## Dramatic moment climber is saved from brutal -2C blizzard in the Scottish Highlands as he's stretchered off by mountain team in daring rescue
 - [https://www.dailymail.co.uk/news/article-12914093/climber-blizzard-Scottish-Highlands-mountain-team-rescue.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914093/climber-blizzard-Scottish-Highlands-mountain-team-rescue.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T10:57:51+00:00

The video shows emergency responders stretchering a female climber to safety after she became seperated from a group almost 4000 feet up in the Cairngorm mountains.

## Wedding DJ facing jail for deliberately urinating on cancer patient is banned from tennis club where he filmed vile Snapchat prank
 - [https://www.dailymail.co.uk/news/article-12914065/DJ-facing-jail-deliberately-urinating-cancer-patient-banned-tennis-club.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914065/DJ-facing-jail-deliberately-urinating-cancer-patient-banned-tennis-club.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T10:56:55+00:00

Leigh Brookfield, 40, admitted common assault on Friday after posting a video of himself on Snapchat deliberately splashing Peter Barton with pee at Llanelli Tennis and Squash Club.

## Rohan Dennis: World champion cyclist is charged over Olympian wife's death - after the mother-of-two was allegedly struck by a ute
 - [https://www.dailymail.co.uk/news/article-12913527/Medindie-crash-Woman-dies-hit-car-man-known-charged.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913527/Medindie-crash-Woman-dies-hit-car-man-known-charged.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T10:52:55+00:00

A former world champion cyclist has been charged with the death of his wife after allegedly hitting her with a ute.

## Lawless London's 'bike-jacking epidemic': Nearly 770 bicycles were stolen by robbers across the capital last year - or TWO every day
 - [https://www.dailymail.co.uk/news/article-12914017/Lawless-Londons-bike-jacking-epidemic-Nearly-770-bicycles-stolen-robbers-capital-year-TWO-day.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914017/Lawless-Londons-bike-jacking-epidemic-Nearly-770-bicycles-stolen-robbers-capital-year-TWO-day.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T10:33:09+00:00

Cyclists have demanded police do more to tackle the bike-stealing epidemic in London with some bikes costing as much as £15,000 new being taken from their owners.

## BBC is accused of a 'weak-willed whitewash' on Gary Lineker's tweets that mocked Conservative MPs
 - [https://www.dailymail.co.uk/news/article-12913389/BBC-accused-weak-willed-whitewash-Gary-Linekers-tweets-mocked-Conservative-MPs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913389/BBC-accused-weak-willed-whitewash-Gary-Linekers-tweets-mocked-Conservative-MPs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T10:32:33+00:00

Tory backbencher Jonathan Gullis blasted the Corporation's 'pathetic response' to his complaint over Mr Lineker's X/Twitter post that suggested the Stoke-on-Trent North MP could not read.

## Woke crime guidelines branded 'ludicrous' as victims will be asked: Are you male, female... or intersex?
 - [https://www.dailymail.co.uk/news/article-12913423/Woke-crime-guidelines-branded-ludicrous-victims-asked-male-female-intersex.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913423/Woke-crime-guidelines-branded-ludicrous-victims-asked-male-female-intersex.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T10:31:25+00:00

Dr Nicola Williams, pictured, a biologist and director of feminist group Fair Play For Women, opposes the guidance.

## Eritrean protesters attacked Met police vans with sticks in lawless scenes outside South London theatre 'after community tensions boiled over' - with four cops hurt and eight people arrested
 - [https://www.dailymail.co.uk/news/article-12914013/Eritrean-protesters-attacked-Met-police-vans-sticks-lawless-scenes-outside-South-London-theatre-community-tensions-boiled-four-cops-hurt-eight-people-arrested.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914013/Eritrean-protesters-attacked-Met-police-vans-sticks-lawless-scenes-outside-South-London-theatre-community-tensions-boiled-four-cops-hurt-eight-people-arrested.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T10:25:47+00:00

Around 50 people gathered outside a private venue in South London before violence broke out, the Metropolitan Police said.

## Artist recreates microscopic '£75k' version of Banksy's famous Girl with Balloon painting inside the eye of a needle... before shredding it just like the original
 - [https://www.dailymail.co.uk/news/article-12914123/Artist-recreates-microscopic-75k-version-Banksys-famous-Girl-Balloon-painting-inside-eye-needle-shredding-just-like-original.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914123/Artist-recreates-microscopic-75k-version-Banksys-famous-Girl-Balloon-painting-inside-eye-needle-shredding-just-like-original.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T10:17:14+00:00

Bournemouth microartist David A Lindon spent months painting Banky's Girl with Balloon before shredding it, just like the original was shredded during a live auction in 2018.

## Grace Millane's mum reveals she's 'serving a life sentence' over her daughter's sickening Tinder date murder as she receives OBE for Kilimanjaro charity climb: 'I'm never going to see my Grace in a wedding dress'
 - [https://www.dailymail.co.uk/news/article-12914073/grace-millane-obe-kilimanjaro-charity-climb-mum-daughter-tinder-date.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914073/grace-millane-obe-kilimanjaro-charity-climb-mum-daughter-tinder-date.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T10:11:51+00:00

Grace Millane (pictured) was brutally killed by Jesse Kempson, who she met on Tinder, on the eve of her 22nd birthday while backpacking in New Zealand five years ago.

## Revealed: Councils are hiking car parking prices by up to 54% next year with Hertfordshire, the New Forest and Southampton seeing the sharpest increases - how does YOUR area fare?
 - [https://www.dailymail.co.uk/news/article-12881399/Councils-hiking-car-parking-prices-54-year-Hertfordshire-New-Forest-Southampton-seeing-sharpest-increases-does-area-fare.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12881399/Councils-hiking-car-parking-prices-54-year-Hertfordshire-New-Forest-Southampton-seeing-sharpest-increases-does-area-fare.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T10:10:22+00:00

Local authorities across England have proposed a slate of increased fees for the new year which they claim are needed to help bolster their finances.

## Everything you need to know about the 2024 New Year's Eve fireworks in Melbourne
 - [https://www.dailymail.co.uk/news/article-12914147/new-years-eve-fireworks-melbourne-information.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914147/new-years-eve-fireworks-melbourne-information.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T10:04:36+00:00

Melbourne is gearing up to ring in the new year with midnight fireworks in front of massive crowds.

## Darts sensation Luke Littler, 16, reveals what his idol Raymond van Barneveld told him after beating him 4-1 to reach World Darts Championship quarter finals - after euphoric crowd sang 'Walking in a Littler Wonderland'
 - [https://www.dailymail.co.uk/news/article-12914011/luke-littler-darts-idol-raymond-van-barneveld-world-championship-quarter-finals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914011/luke-littler-darts-idol-raymond-van-barneveld-world-championship-quarter-finals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T10:04:22+00:00

The 16-year-old swept the five-time world champion aside last night in a 4-1 masterclass much to the delight of the euphoric crowd at the Alexandra Palace who sang 'Walking in a Littler Wonderland'.

## Jack Grealish's fiancée Sasha Attwood is left 'terrified' by Boxing Day raid on their Cheshire mansion and no longer feels safe after burglars stole up to £1m in jewels and watches
 - [https://www.dailymail.co.uk/news/article-12914113/jack-grealish-fiancee-sasha-attwood-terrified-boxing-day-raid-cheshire-mansion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914113/jack-grealish-fiancee-sasha-attwood-terrified-boxing-day-raid-cheshire-mansion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T09:59:32+00:00

EXCLUSIVE: Sources say that she is 'in pieces' following the thefts, which happened just days after Grealish moved into the £5.6m mansion and may have been planned for days beforehand.

## Charles is turning into the 'Convenor King' - defending all religions, not just Christianity, writes CATHERINE PEPINSTER. Now he needs his family to hear the message of unity...
 - [https://www.dailymail.co.uk/news/article-12890239/Charles-Convenor-King-defending-faiths.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12890239/Charles-Convenor-King-defending-faiths.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T09:59:07+00:00

Charles's admission to  Jonathan Dimbleby that he wanted to be 'defender of faith', rather than Defender of the Faith caused alarm bells to ring, especially in the Church of England.

## The season for merriment, joy (and a touch of mischief...) How five-year-old Prince Louis became the heart-melting spirit of Christmas, as these pictures and videos show
 - [https://www.dailymail.co.uk/news/article-12903429/Merriment-joy-touch-mischief-Louis-spirit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12903429/Merriment-joy-touch-mischief-Louis-spirit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T09:57:18+00:00

It was down to Prince Louis to add a note of spontaneity to the seasonal proceedings - putting a smile on even the most hardened faces.

## Putin launches terrifying New Year's Eve blitz on Ukraine using Iranian 'suicide drones' in dawn raid revenge after Kyiv attacked Russian border city in escalating tit-for-tat
 - [https://www.dailymail.co.uk/news/article-12913999/Putin-launches-terrifying-New-Years-Eve-blitz-Ukraine-using-Iranian-suicide-drones-dawn-raid-revenge-Kyiv-attacked-Russian-border-city-escalating-tit-tat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913999/Putin-launches-terrifying-New-Years-Eve-blitz-Ukraine-using-Iranian-suicide-drones-dawn-raid-revenge-Kyiv-attacked-Russian-border-city-escalating-tit-tat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T09:44:21+00:00

Several Iranian-made 'Shahed' drones targeted Ukraine's northeastern city of Kharkiv overnight, according to local authorities, as the two sides accused each other of targeting civilians

## Alex Batty's mother tells friends she's 'got to keep running' as she 'goes into hiding with her father and flees to remote French village popular with conspiracy theorists' six years after 'kidnapping' her son
 - [https://www.dailymail.co.uk/news/article-12913979/alex-batty-mother-hiding-father-french-village-conspiracy-theorists.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913979/alex-batty-mother-hiding-father-french-village-conspiracy-theorists.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T09:43:05+00:00

Expat Tony Smith, who used to let his converted cowshed in the French Pyrenees to Alex's mother Melanie, said she told him last week that she was 'staying on the run'.

## Britain's FBI probe £3million payment into Baroness Bra's bank account as detectives investigate lingerie tycoon over Covid PPE scandal
 - [https://www.dailymail.co.uk/news/article-12914007/Britains-FBI-Baroness-Bras-detectives-Covid-PPE-scandal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914007/Britains-FBI-Baroness-Bras-detectives-Covid-PPE-scandal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T09:37:35+00:00

The NCA is probing the transaction which was made into the 52-year-old's Coutts bank account as part of its investigation over allegations of fraud and bribery surrounding PPE Medpro.

## Weather New Years Eve: Monster storm measuring more than 1000km is set to smash Australia's east coast bringing damaging winds and large hail - as it's revealed SES volunteers have been abused by frustrated homeowners
 - [https://www.dailymail.co.uk/news/article-12913985/New-Years-Eve-weather.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913985/New-Years-Eve-weather.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T09:34:38+00:00

Heavy rain, thunderstorms and large hail forecast for northern NSW and Queensland have emergency crews on stand-by on New Year's Eve.

## Mum-of-three, 29, reveals horrifying moment she found a SPIDER NEST in her ear following weeks of 'scratchy pain'
 - [https://www.dailymail.co.uk/news/article-12909605/mum-reveals-spider-nest-ear-earbud-camera-scratching-pain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12909605/mum-reveals-spider-nest-ear-earbud-camera-scratching-pain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T09:33:53+00:00

Mother-of-three Lucy Wild, 29, from Sale, Cheshire, made the grim discovery of a spider nest while investigating irritation and pain in one of her ears - after removing a spider from it three weeks prior

## Is YOUR home near a sewage overflow pipe? Interactive map reveals hidden sluice network that can spew filth and chemicals in an emergency
 - [https://www.dailymail.co.uk/news/article-12838077/Is-home-near-sewage-overflow-pipe-Interactive-map-reveals-hidden-sluice-network-spew-filth-chemicals-emergency.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12838077/Is-home-near-sewage-overflow-pipe-Interactive-map-reveals-hidden-sluice-network-spew-filth-chemicals-emergency.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T09:31:55+00:00

EXCLUSIVE: These are the 107 places in England and Wales where homes, schools and even a playground have been built on top of sluices that are allowed to spew filth and chemicals.

## Man is stabbed after confronting dog-walker about cleaning up their pet's mess in the City of London - as cops hunt knifeman
 - [https://www.dailymail.co.uk/news/article-12914081/Man-stabbed-confronting-dog-walker-cleaning-pets-mess-City-London-cops-hunt-knifeman.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914081/Man-stabbed-confronting-dog-walker-cleaning-pets-mess-City-London-cops-hunt-knifeman.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T09:30:29+00:00

A manhunt is underway for a suspect who allegedly stabbed someone when they asked him to pick up his dog's mess.

## How Putin is preparing Russia for a long war in Ukraine: Despot hikes military spending to more than six per cent as he sets economy on a 'permanent war footing' as invasion nears two-year mark
 - [https://www.dailymail.co.uk/news/article-12914025/How-Putin-preparing-Russia-long-war-Ukraine-Despot-hikes-military-spending-six-cent-sets-economy-permanent-war-footing-invasion-nears-two-year-mark.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914025/How-Putin-preparing-Russia-long-war-Ukraine-Despot-hikes-military-spending-six-cent-sets-economy-permanent-war-footing-invasion-nears-two-year-mark.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T09:22:29+00:00

A third of government spending in 2024 will be on the military alone, according to the draft budget. Some of this will be paid for by increased oil revenues and trade with non-Western countries

## Dozens of XL Bully owners gather on seafront to walk their dogs unmuzzled for the last time before new restrictions come into force TODAY
 - [https://www.dailymail.co.uk/news/article-12912887/XL-Bully-owners-seafront-walk-dogs-unmuzzled.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12912887/XL-Bully-owners-seafront-walk-dogs-unmuzzled.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T09:21:38+00:00

EXCLUSIVE: More than 30 dogs including those of the huge breed packed the seafront in Margate, Kent, as the meet-up promenaded through the seaside town.

## Drones are being used by drug gangs to spy on rivals and stalkers use them to look at victims, as police reveal they get called more than a dozen times a day about their criminal use
 - [https://www.dailymail.co.uk/news/article-12913647/Drones-used-drug-gangs-spy-rivals-stalkers-use-look-victims-police-reveal-called-dozen-times-day-criminal-use.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913647/Drones-used-drug-gangs-spy-rivals-stalkers-use-look-victims-police-reveal-called-dozen-times-day-criminal-use.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T09:15:34+00:00

Police forces are being called out around 16 times a day because of spy drones, with forces receiving 18,290 complaints about drone misuse in the last three years.

## Bizarre four words to cabin crew that sparked a mid-air meltdown on a Qantas flight from Bali to Melbourne
 - [https://www.dailymail.co.uk/news/article-12914023/Bizarre-four-words-cabin-crew-sparked-mid-air-meltdown-Qantas-flight-Bali-Melbourne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12914023/Bizarre-four-words-cabin-crew-sparked-mid-air-meltdown-Qantas-flight-Bali-Melbourne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T09:15:20+00:00

The man had to be restrained by crew and passengers after allegedly attacking staff on Qantas flight QF46 between Bali and Melbourne.

## Met Police's wall of shame: Disgraced cops sacked for gross misconduct in 2023 - from the rookie who shared sick porn to the wannabe stuntman sacked for beating up boy then lying about it
 - [https://www.dailymail.co.uk/news/article-12850129/Metropolitan-police-officers-sacked-gross-misconduct-2023.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12850129/Metropolitan-police-officers-sacked-gross-misconduct-2023.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T09:06:20+00:00

More than 100 officers have been sacked by the Met as it seeks to root out dodgy cops and predators from within its rank, as part of a sweeping crackdown on standards.

## Major backflip by Anthony Albanese's government on electric vehicles outrages environmentalists
 - [https://www.dailymail.co.uk/news/article-12913993/Albanese-backflip-electric-vehicles.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913993/Albanese-backflip-electric-vehicles.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T09:06:13+00:00

The Albanese has failed to unveil mandatory pollution caps on vehicles sold in Australia that they promised would by introduced 'by the end of the year'.

## North Korea vows to launch three new spy satellites and build up its arsenal of drones and nuclear warheads as Kim Jong Un says he will no longer seek reconciliation with the South
 - [https://www.dailymail.co.uk/news/article-12913851/North-Korea-vows-launch-three-new-spy-satellites-build-arsenal-drones-nuclear-warheads-Kim-Jong-says-no-longer-seek-reconciliation-South.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913851/North-Korea-vows-launch-three-new-spy-satellites-build-arsenal-drones-nuclear-warheads-Kim-Jong-says-no-longer-seek-reconciliation-South.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T08:30:01+00:00

Kim lashed out at America in lengthy remarks on Sunday, wrapping up five days of ruling party meetings that set economic, military and foreign policy goals for the coming year.

## Distressing moment 'fentanyl user' writhes and moans in San Francisco street for TWO HOURS, as local journalist slams progressive activists she says want to cover-up the crisis
 - [https://www.dailymail.co.uk/news/article-12913237/San-Francisco-fentanyl-video-journalist-cover-up.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913237/San-Francisco-fentanyl-video-journalist-cover-up.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T08:25:56+00:00

Shocking video shows a man in San Francisco allegedly high on fentanyl thrashing around on the ground for two hours. Journalist Erica Sandberg said leaders are trying to cover up the crisis.

## Smiling through the pain: Kentucky nurse, 41, wears a heartbreaking smile as she leaves her hospital bed for the first time since waking up from routine kidney stone surgery to find she'd had QUADRUPLE amputation due to sepsis
 - [https://www.dailymail.co.uk/news/article-12913813/Smiling-pain-Kentucky-nurse-41-wears-heartbreaking-smile-leaves-hospital-bed-time-waking-routine-kidney-stone-surgery-shed-QUADRUPLE-amputation-sepsis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913813/Smiling-pain-Kentucky-nurse-41-wears-heartbreaking-smile-leaves-hospital-bed-time-waking-routine-kidney-stone-surgery-shed-QUADRUPLE-amputation-sepsis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T08:22:55+00:00

Lucinda Mullins, 41, a Kentucky mother of two boys, is seen smiling after losing both of her legs and arms. She had gone for a regular kidney stone surgery but had a quadruple amputation

## Labour's 'reckless' opposition to new North Sea gas and oilfields 'is risking 200,000 jobs' and would 'decimate communities'
 - [https://www.dailymail.co.uk/news/article-12913689/Labours-reckless-opposition-new-North-Sea-gas-oilfields-risking-200-000-jobs-decimate-communities.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913689/Labours-reckless-opposition-new-North-Sea-gas-oilfields-risking-200-000-jobs-decimate-communities.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T08:10:50+00:00

Energy Security Secretary Claire Coutinho tore into the Labour leader, accusing Sir Keir Starmer of risking 200,000 British jobs over his opposition to new North Sea gas and oilfields.

## Tyson Boardman: Young motorcyclist is killed in horrific crash as his mother flies across the country to bury her son
 - [https://www.dailymail.co.uk/news/article-12913913/Tyson-Boardman-motorcyclist-killed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913913/Tyson-Boardman-motorcyclist-killed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T07:53:52+00:00

Tyson Boardman, 21, was killed on Boxing Day after he lost control of Honda motorcycle in Perth, as tributes flow for the young man and his mother flies across the country to with her son.

## Howard University launches investigation after TikTokers broke into the HBCU's former Divinity School building, which houses priceless art and historical books
 - [https://www.dailymail.co.uk/news/article-12913755/Howard-University-launches-investigation-TikTokers-broke-HBCUs-former-Divinity-School-building-houses-priceless-art-historical-books.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913755/Howard-University-launches-investigation-TikTokers-broke-HBCUs-former-Divinity-School-building-houses-priceless-art-historical-books.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T07:27:12+00:00

A group of TikTokers broke into the former site of Howard University's School of Divinity, Benjamin E. Mays Hall in Washington D.C., uncovering a wealth of treasures as they did so.

## MSNBC doctor claims systemic factors like racism determine 80% of a person's health while people themselves are only 'about 20%' responsible
 - [https://www.dailymail.co.uk/news/article-12913847/MSNBC-doctor-claims-systemic-factors-like-racism-determine-80-persons-health-people-20-responsible.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913847/MSNBC-doctor-claims-systemic-factors-like-racism-determine-80-persons-health-people-20-responsible.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T07:26:48+00:00

Dr. Uché Blackstock and Dr. L. Ebony Boulware appeared on MSNBC to discuss Boulware's new study on racism and health conditions.

## Biden's Democratic challenger Dean Phillips oversaw raunchy ad campaign as young liquor CEO: Advertisements showed strippers and suggested men needed to drink more to be around overweight women
 - [https://www.dailymail.co.uk/news/article-12907693/Bidens-Democratic-challenger-Dean-Phillips-oversaw-raunchy-ad-campaign-young-liquor-CEO-Advertisements-showed-strippers-suggested-men-needed-drink-overweight-women.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12907693/Bidens-Democratic-challenger-Dean-Phillips-oversaw-raunchy-ad-campaign-young-liquor-CEO-Advertisements-showed-strippers-suggested-men-needed-drink-overweight-women.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T07:26:46+00:00

When 2024 Democratic presidential hopeful Rep. Dean Phillips took over his family's booze business in 2000 he oversaw a raunchy ad campaign used to sell Revelstoke, a spiced Canadian whisky.

## Nikki Haley confuses Iowa Hawkeyes star Caitlin Clark with CNN anchor Kaitlan Collins - after her Civil War gaffe drew backlash in New Hampshire
 - [https://www.dailymail.co.uk/news/article-12913599/Nikki-Haley-gaffe-Iowa-basketball-Caitlin-Clark.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913599/Nikki-Haley-gaffe-Iowa-basketball-Caitlin-Clark.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T07:26:36+00:00

Speaking at the Iowa Athletic Club in Coralville, Haley accidentally referred to Iowa Hawkeyes superstar Caitlin Clark as 'Kaitlan Collins', the name of the rising-star CNN anchor.

## Bodycam video shows LA sheriff's deputy fatally shooting woman, 27, FOUR times in front of child
 - [https://www.dailymail.co.uk/news/article-12913607/Video-LA-sheriffs-deputy-kills-woman-child.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913607/Video-LA-sheriffs-deputy-kills-woman-child.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T07:26:33+00:00

Newly released bodycam footage Niani Finlayson, 27, being shot to death by Deputy Ty Shelton. She had told the officers she was going to stab her ex-boyfriend for hurting her  daughter Xaisha

## 'You never know what's going on in someone's head': Friend of New York police sergeant says her 'heart is super heavy' after cop shot dead wife, two sons, 10 and 12, and himself at $600k home - just two months before retiring
 - [https://www.dailymail.co.uk/news/article-12913293/Family-dead-Rockland-County-murder-suicide.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913293/Family-dead-Rockland-County-murder-suicide.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T07:26:24+00:00

Clarkstown Police Department found Watson Morgan, 49, his wife Ornela Morgan, 43, and their two sons aged 10 and 12 dead in their home.

## 'He's soaking up the sun while illegal aliens crash our border': Republicans slam Joe Biden for taking New Year's holiday to Caribbean island of St Croix when 6,000-strong migrant caravan rumbles towards the US
 - [https://www.dailymail.co.uk/news/article-12913883/Hes-soaking-sun-illegal-aliens-crash-border-Republicans-slam-Joe-Biden-taking-New-Years-holiday-Caribbean-island-St-Croix-6-000-strong-migrant-caravan-rumbles-US.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913883/Hes-soaking-sun-illegal-aliens-crash-border-Republicans-slam-Joe-Biden-taking-New-Years-holiday-Caribbean-island-St-Croix-6-000-strong-migrant-caravan-rumbles-US.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T07:26:21+00:00

Republicans are criticizing Biden for vacationing in St. Croix during a border crisis, accusing the White House of neglecting the issue. Biden's trip coincides with increased border crossings.

## California animal shelter houses adorable SPECIAL NEEDS cats who are most at risk of being euthanized in regular animal pounds
 - [https://www.dailymail.co.uk/news/article-12913503/California-animal-shelter-houses-adorable-SPECIAL-NEEDS-cats-risk-euthanized-regular-animal-pounds.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913503/California-animal-shelter-houses-adorable-SPECIAL-NEEDS-cats-risk-euthanized-regular-animal-pounds.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T07:21:29+00:00

California's SNAP Cats specializes in caring for cats with special needs including ailments and physical deformities that might make them harder to adopt.

## American Idol producer Nigel Lythgoe is 'disgusting human being' source close to Paula Abdul claims after singer sued the TV tycoon for sexual assault
 - [https://www.dailymail.co.uk/news/article-12913257/American-Idol-producer-Nigel-Lythgoe-disgusting-human-source-close-Paula-Abdul-claims-singer-sued-TV-tycoon-sexual-assault.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913257/American-Idol-producer-Nigel-Lythgoe-disgusting-human-source-close-Paula-Abdul-claims-singer-sued-TV-tycoon-sexual-assault.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T07:21:02+00:00

American Idol producer Nigel Lythgoe is facing serious allegations of sexual assault in a lawsuit filed by fellow judge Paula Abdul.

## Republicans slam DOJ for dropping campaign finance charges against major Democratic donor Sam Bankman-Fried: 'So we won't know which politicians he bribed?'
 - [https://www.dailymail.co.uk/news/article-12913961/SBF-campaign-finance-donations-coverup.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913961/SBF-campaign-finance-donations-coverup.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T07:20:48+00:00

In a letter filed on Friday night in federal court in Manhattan, prosecutors said the 'strong public interest' in a prompt resolution of the case outweighed the benefits of a second trial.

## Chilling moment Florida honors student Derek Rosa, 13, calmly 'confesses' to brutally stabbing his mom to death as she slept next to her baby - even showing cops his bloody hands
 - [https://www.dailymail.co.uk/news/article-12913927/Chilling-moment-Florida-honors-student-Derek-Rosa-13-calmly-confesses-brutally-stabbing-mom-death-slept-baby-showing-cops-bloody-hands.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913927/Chilling-moment-Florida-honors-student-Derek-Rosa-13-calmly-confesses-brutally-stabbing-mom-death-slept-baby-showing-cops-bloody-hands.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T07:15:02+00:00

In a newly obtained police interrogation video, Derek Rosa, 13, confessed to brutally stabbing and killing his mother despite pleading not guilty

## A wedding fit for a £9.8billion duke: Harry and Meghan won't be there... but almost all the rest of high society will be: The inside story of the man 'born with the longest ever silver spoon' and his English rose bride
 - [https://www.dailymail.co.uk/news/article-12912899/A-wedding-fit-duke-Harry-Meghan-wont-rest-high-society.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12912899/A-wedding-fit-duke-Harry-Meghan-wont-rest-high-society.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T06:59:11+00:00

Here we reveal everything you need to know about the nuptials of Hugh Grosvenor, 7th Duke of Westminster, to gourmet food firm executive Olivia Henson in June, in Chester Cathedral.

## Heroic moment St Louis neighbor helps mother and ten-year-old son make daring escape after they were taken hostage by mom's ex-boyfriend
 - [https://www.dailymail.co.uk/news/article-12913489/St-Louis-neighbor-mother-son-escape-hostage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913489/St-Louis-neighbor-mother-son-escape-hostage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T06:54:56+00:00

An unidentified mother and her 10-year-old son were heard begging for help from a neighbor on camera after her ex-boyfriend took them hostage

## 'They're killing me': Shocking moment American Airlines passenger has to be held down by crew while having MELTDOWN on flight to Miami - as passengers try to restrain him with DUCT TAPE
 - [https://www.dailymail.co.uk/news/article-12913239/Theyre-killing-Shocking-moment-American-Airlines-passenger-held-crew-having-MELTDOWN-flight-Miami-passengers-try-restrain-DUCT-TAPE.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913239/Theyre-killing-Shocking-moment-American-Airlines-passenger-held-crew-having-MELTDOWN-flight-Miami-passengers-try-restrain-DUCT-TAPE.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T06:54:02+00:00

An unidentified Spanish-speaking American Airlines had a meltdown and can be heard screaming for 'help' and 'they're killing me' while being restrained by a crew member and four passengers

## Adam Magnus: Paedophile scumbag married to wedding planner to the stars is jailed after trying to groom a mother and abuse her 11-year-old daughter
 - [https://www.dailymail.co.uk/news/article-12913881/Adam-Magnus-paedophile-wedding-planner.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913881/Adam-Magnus-paedophile-wedding-planner.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T06:47:02+00:00

The husband of a wedding planner who organised Margot Robbie 's nuptials has been jailed after making plans to sexually abuse an 11-year-old with what he thought was the girl's mother.

## Special Counsel Jack Smith asks court to reject Donald Trump's claim of 'absolute immunity' on Jan. 6 charges and says granting presidents such power would be 'dangerous'
 - [https://www.dailymail.co.uk/news/article-12913439/Trump-immunity-appeals-court-ruling.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913439/Trump-immunity-appeals-court-ruling.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T06:39:30+00:00

Special Counsel Jack Smith on Saturday urged a federal appeals court to reject former President Donald Trumps claim that he has presidential immunity against criminal charges.

## Shocking aftermath of road rage attack in Byron Bay after Argentinian tourist had her windshield smashed in by wild Aussie couple
 - [https://www.dailymail.co.uk/news/article-12913803/road-rage-attack-Argentinian-tourist-windshield.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913803/road-rage-attack-Argentinian-tourist-windshield.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T05:44:28+00:00

An Argentinian tourist has suffered a shocking road rage ordeal which has tarnished her time in Australia, which had up until now been 'beautiful'.

## Sea World crash survivor speaks out a year on from the tragedy as authorities prepare to release key report and never-seen-before footage of disaster
 - [https://www.dailymail.co.uk/news/article-12913567/Sea-World-crash-survivor-speaks-report-due.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913567/Sea-World-crash-survivor-speaks-report-due.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T05:33:26+00:00

A Sea World helicopter crash survivor has spoken out about her continuing pain, distress and regret almost a year on from the January 2, 2023 disaster.

## Two people die after train collides with a truck shutting down major highway connecting NSW and South Australia
 - [https://www.dailymail.co.uk/news/article-12913843/Horror-train-collides-truck-shutting-major-highway-connecting-NSW-South-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913843/Horror-train-collides-truck-shutting-major-highway-connecting-NSW-South-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T05:14:55+00:00

South Australian police responded to reports of a serious crash on the Barrier Highway at Bindarrah near the NSW border about 10.30am on Sunday.

## Happy new year Anthony Albanese! Huge pay bump for the PM and his public servants - and you won't believe the salary of one minister
 - [https://www.dailymail.co.uk/news/article-12913705/Happy-new-year-Anthony-Albanese-Huge-pay-bump-PM-public-servants-wont-believe-salary-one-minister.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913705/Happy-new-year-Anthony-Albanese-Huge-pay-bump-PM-public-servants-wont-believe-salary-one-minister.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T03:36:19+00:00

As many ordinary Aussies struggle to pay for the basics the Prime Minister, top public servants and judges go into 2024 with huge salary increases, with one mandarin on almost a $1million a year.

## Kevin headed to Bali to celebrate New Year's Eve. The young dad is now fighting for life as his heavily pregnant wife rushes to his bedside
 - [https://www.dailymail.co.uk/news/article-12913387/Kevin-dad-Bali-coma-pregnant-wife-Aussie-tourist.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913387/Kevin-dad-Bali-coma-pregnant-wife-Aussie-tourist.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T03:20:06+00:00

An Australian man who went to Bali to ring in the new year is instead fighting for his life in an induced coma in Bali after falling off the back of a moped.

## Victim of Lithgow crash had spoken ominously of the 'shadow of death' - as his family gathers in vigil for siblings still fighting for life
 - [https://www.dailymail.co.uk/news/article-12913465/Victim-Lithgow-crash-spoken-ominously-shadow-death-family-gathers-vigil-siblings-fighting-life.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913465/Victim-Lithgow-crash-spoken-ominously-shadow-death-family-gathers-vigil-siblings-fighting-life.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T02:21:58+00:00

A haunting sermon delivered by one of two Sydney fathers killed in the horror smash near Lithgow on Friday has resurfaced as family and friends pay tribute to the father of nine.

## Labour veteran Jon Cruddas accuses Starmer of being 'detached from his own party' as infighting about Sir Keir bursts into the open
 - [https://www.dailymail.co.uk/news/article-12913665/Labour-veteran-Jon-Cruddas-accuses-Starmer-detached-party-infighting-Sir-Keir-bursts-open.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913665/Labour-veteran-Jon-Cruddas-accuses-Starmer-detached-party-infighting-Sir-Keir-bursts-open.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T02:09:11+00:00

Dagenham and Rainham Labour MP Jon Cruddas has accused Sir Keir Starmer of being 'detached' and said that it was 'difficult to identify the purpose of a future Starmer government'.

## Dead whale found washed up on the shore of the Thames by a dogwalker is removed after three days as boat crews drag the carcass across the river
 - [https://www.dailymail.co.uk/news/article-12913253/Dead-whale-washed-shore-Thames-dogwalker-removed-three-days-boat-crews-drag-carcass-river.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913253/Dead-whale-washed-shore-Thames-dogwalker-removed-three-days-boat-crews-drag-carcass-river.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T02:04:15+00:00

The marine giant was found by dog walker Jack Theed and his son Jude on the Thames estuary shoreline in a remote part of Cliffe, on the Hoo Peninsula, on Wednesday.

## Joe take Jill out for a night on the town in St. Croix and vows his New Year's resolution is 'to come back next year' as he prepares to run for re-election
 - [https://www.dailymail.co.uk/news/article-12913491/joe-jill-biden-dinner-date-vacation-caribbean.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913491/joe-jill-biden-dinner-date-vacation-caribbean.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T02:03:48+00:00

President Joe Biden took wife Jill and granddaughter Natalie out to dinner in St. Croix on Saturday as he closes out the year on the U.S. Virgin Island.

## The fall of the Glenconner empire: He was the Scots aristocrat and close friend of Princess Margaret who left most of his luxury estate to his faithful servant. Now, in a final bitter twist, his entire legacy has been put up for sale
 - [https://www.dailymail.co.uk/news/article-12913651/Glenconner-empire-Scots-aristocrat-Princess-Margaret-estate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913651/Glenconner-empire-Scots-aristocrat-Princess-Margaret-estate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T02:01:43+00:00

He arrived on the golden sands of St Lucia in 1987, the self-styled 'King of the Caribbean'. Riding his pet elephant, Bupa, in a white linen suit and straw hat, Lord Glenconner was sure to make an entrance.

## Britain set for New Year's Eve weather chaos: Experts forecast 75mph winds amid tornado warning after heavy rain leaves towns and cities flooded
 - [https://www.dailymail.co.uk/news/article-12913193/uk-weather-forecast-tornado-warning-heavy-rain-flooding.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913193/uk-weather-forecast-tornado-warning-heavy-rain-flooding.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T01:59:09+00:00

A 260-mile stretch of Britain has been slapped with a tornado warning lasting until the early hours of December 31 by a specialist forecaster that predicts cyclones.

## Statistically speaking, it's been a year of big numbers... but can we count on you to figure out our 20 questions?
 - [https://www.dailymail.co.uk/news/article-12913657/Statistically-speaking-year-big-numbers-count-figure-20-questions.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913657/Statistically-speaking-year-big-numbers-count-figure-20-questions.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T01:58:02+00:00

Here, Mark Mason sets an end-of-year, stat-tastic quiz to test your knowledge of how the numbers stacked up in 2023...

## Look Mac in laughter! Six of the best from another vintage year for our brilliant cartoonist in 2023
 - [https://www.dailymail.co.uk/news/article-12913513/Look-Mac-laughter-Six-best-vintage-year-brilliant-cartoonist-2023.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913513/Look-Mac-laughter-Six-best-vintage-year-brilliant-cartoonist-2023.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T01:56:20+00:00

No story was too small - or too big - in 2023 to receive the inimitable tongue-in-cheek humour and signature wit of our beloved The Mail On Sunday cartoonist, Mac.

## Beefeaters clip a pair of rebel raven's wings who pose a flight risk from the Tower of London after the mischievous duo disobeyed their master's calls
 - [https://www.dailymail.co.uk/news/article-12913589/Beefeaters-clip-rebel-ravens-wings-Tower-London.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913589/Beefeaters-clip-rebel-ravens-wings-Tower-London.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T01:54:54+00:00

The guards have had to clip both wings of the errant birds after they started to defy their Ravenmaster's calls, risking their safety - and that of the Crown.

## It may not pay to look on the bright side: Being optimistic can lead to making bad decisions, research finds
 - [https://www.dailymail.co.uk/news/article-12913621/It-not-pay-look-bright-optimistic-lead-making-bad-decisions-research-finds.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913621/It-not-pay-look-bright-optimistic-lead-making-bad-decisions-research-finds.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T01:54:16+00:00

Researchers at Bath University have found that an optimistic outlook can lead to poor decision-making, with serious implications for people's financial wellbeing.

## High street set to bounce back from economic downturn... as economists predict the Bank of England will cut interest rates next year
 - [https://www.dailymail.co.uk/news/article-12913587/High-street-set-bounce-economic-downturn-economists-predict-Bank-England-cut-rates-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913587/High-street-set-bounce-economic-downturn-economists-predict-Bank-England-cut-rates-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T01:51:05+00:00

Economists have 'cautious optimism' that 2024 will prove to be a better year financially, thanks to inflation easing and consumer confidence slowly returning.

## Murder suspect, 23, accused of ramming car into 'Good Samaritan' father-of-two in wedding party row 'also tried to kill his own mother and sister'
 - [https://www.dailymail.co.uk/news/article-12913615/Murder-suspect-23-accused-ramming-car-Good-Samaritan-father-two-wedding-party-row-tried-kill-mother-sister.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913615/Murder-suspect-23-accused-ramming-car-Good-Samaritan-father-two-wedding-party-row-tried-kill-mother-sister.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T01:39:45+00:00

Hassan Jhangur, 23, appeared at Sheffield Magistrates' Court yesterday accused of murdering Chris Marriott, who was struck by a vehicle while trying to help a stranger.

## Israeli army is locked in street battles in Hamas stronghold as Tel-Aviv also launches strikes on Iran-backed Hezbollah militants in Lebanon and Syria
 - [https://www.dailymail.co.uk/news/article-12913623/Israeli-Hamas-Tel-Aviv-Iran-Hezbollah-Lebanon-Syria.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913623/Israeli-Hamas-Tel-Aviv-Iran-Hezbollah-Lebanon-Syria.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T01:33:02+00:00

Israeli troops fought street battles against Hamas terrorists in southern Gaza yesterday as they sought to capture the key city of Khan Yunis.

## Who'd have thought it! Crime increases in areas hit by worst cuts to police force
 - [https://www.dailymail.co.uk/news/article-12912945/Whod-thought-Crime-increases-areas-hit-worst-cuts-police-force.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12912945/Whod-thought-Crime-increases-areas-hit-worst-cuts-police-force.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T01:29:18+00:00

Crime is rising where cuts to police officer numbers have been deepest, a Scottish Mail on Sunday investigation has discovered.

## Trans activists and Left-wing rivals are trying to force me out over my views on gender, Conservative police tsar says
 - [https://www.dailymail.co.uk/news/article-12913617/Trans-activists-Left-wing-gender-Conservative-police.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913617/Trans-activists-Left-wing-gender-Conservative-police.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T01:24:19+00:00

Surrey Crime Commissioner Lisa Townsend (pictured) survived a vote of no confidence after she criticised pro-trans lobby group Stonewall.

## Mother of the year! Woman, 57, drove for eight hours to pick up her daughter after she was stranded in Belgium by Eurostar cancellations
 - [https://www.dailymail.co.uk/news/article-12912933/Mother-drove-pick-daughter-stranded-Belgium-Eurostar.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12912933/Mother-drove-pick-daughter-stranded-Belgium-Eurostar.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T01:13:34+00:00

EXCLUSIVE: Joanna Mitchell, 57, and husband Grahame Mitchell, also 57, drove from Whitstable, Kent, to Bruges after their daughter Jade, 34, was stranded by cancellations on the channel-crossing.

## 'One-click' energy switch will let households change energy supplier in just seven days under plans considered by Ministers
 - [https://www.dailymail.co.uk/news/article-12913583/One-click-energy-switch-let-households-change-energy-supplier-just-seven-days-plans-considered-Ministers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913583/One-click-energy-switch-let-households-change-energy-supplier-just-seven-days-plans-considered-Ministers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T01:06:34+00:00

Officials are looking at replicating the banking switch guarantee, which lets people easily change current accounts, in the energy industry.

## Victory! Mail on Sunday campaign sees stores face a ban on wrapping fruit and vegetables in plastic
 - [https://www.dailymail.co.uk/news/article-12913547/Victory-Mail-Sunday-campaign-sees-stores-face-ban-wrapping-fruit-vegetables-plastic.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913547/Victory-Mail-Sunday-campaign-sees-stores-face-ban-wrapping-fruit-vegetables-plastic.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T01:04:19+00:00

The Government is considering introducing a a ban on plastic packaging for fruit and vegetables in a bid to force supermarkets to sell more fresh produce loose.

## Some of Britain's top CEOs earn more in week than average annual salary
 - [https://www.dailymail.co.uk/news/article-12913569/Some-Britains-CEOs-earn-week-average-annual-salary.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913569/Some-Britains-CEOs-earn-week-average-annual-salary.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T01:02:00+00:00

Our Fat Cat Files show that a typical chief executive of a FTSE 100 company is now paid £4 million, well over 100 times a full-time UK employee's average salary.

## Number of women freezing their eggs rose 54% during Covid because lockdowns sparked widespread anxiety about finding 'the one'
 - [https://www.dailymail.co.uk/health/article-12913529/Number-women-freezing-eggs-rose-Covid-lockdowns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-12913529/Number-women-freezing-eggs-rose-Covid-lockdowns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T00:58:10+00:00

Professor Geeta Nargund, revealed demand for egg-freezing services at her clinics jumped to record levels during the coronavirus outbreak.

## Ridiculous push to ban the phrase 'brother' and 'sister' - as 'woke' equality group reveals the new 'inclusive' term we should be calling our loved ones
 - [https://www.dailymail.co.uk/news/article-12913397/Ridiculous-push-ban-phrase-brother-sister-woke-equality-group-reveals-new-inclusive-term-calling-loved-ones.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913397/Ridiculous-push-ban-phrase-brother-sister-woke-equality-group-reveals-new-inclusive-term-calling-loved-ones.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T00:52:51+00:00

'Brother' and 'sister' could be banned from official documents and other public communication and be replaced by the term 'siblings', under one state's updated anti-discrimination laws.

## Mission to planet WOKE! More than 50 years since America last sent a man to the Moon, it's planning a new lunar adventure... But as Nasa trumpets its commitment to 'diversity' and a gender split between the astronauts, cynics are pillorying it
 - [https://www.dailymail.co.uk/news/article-12913521/WOKE-America-man-Moon-lunar-Nasa-diversity-gender-astronauts.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913521/WOKE-America-man-Moon-lunar-Nasa-diversity-gender-astronauts.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T00:50:00+00:00

Astronaut Gene Cernan paused for one final look at Earth from the Moon before climbing the ladder into his spaceship and closing the hatch on Nasa's last lunar mission more than 50 years ago.

## The right to disagree is a public good - like clean air and water, Government's free speech tsar ARIF AHMED says
 - [https://www.dailymail.co.uk/debate/article-12912925/right-disagree-public-good-Government-free-speech-tsar-ARIF-AHMED.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/debate/article-12912925/right-disagree-public-good-Government-free-speech-tsar-ARIF-AHMED.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T00:49:46+00:00

ARIF AHMED: Freedom of speech is not the property of one side in any culture war. It belongs to the whole human race. Indeed, for those of us who enjoy it, nothing is more precious.

## With tonight's original deadline to scrap all EU-era law, a former Minister reveals his 10 New Year's Resolutions to finally get Brexit done
 - [https://www.dailymail.co.uk/news/article-12912919/deadline-scrap-EU-law-former-Minister-New-Years-Resolutions-Brexit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12912919/deadline-scrap-EU-law-former-Minister-New-Years-Resolutions-Brexit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T00:46:03+00:00

DAVID JONES: Almost four years on from the UK's formal departure from the EU, there is no shortage of talk of Brexit freedoms.

## How much attention have you been paying this year? Test your news nous in our tricky Headliners Quiz
 - [https://www.dailymail.co.uk/news/article-12913377/Test-news-nous-tricky-Headliners-Quiz.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913377/Test-news-nous-tricky-Headliners-Quiz.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T00:38:05+00:00

Here are 20 genuine headlines from 2023, each referring to a famous name. Take part in our fun quiz and choose the correct identity from three people that the story could be about.

## King Charles turns to the Instagram queens to help boost his image with the young: Bake Off runner-up and Love Island star attend Royal events to boost monarch's Gen Z popularity
 - [https://www.dailymail.co.uk/tvshowbiz/article-12912967/King-Charles-turns-Instagram-queens-help-boost-image-Bake-Love-Island-star-attend-Royal-events.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-12912967/King-Charles-turns-Instagram-queens-help-boost-image-Bake-Love-Island-star-attend-Royal-events.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T00:36:31+00:00

Palace aides have been inviting social media celebrities with millions of fans, including 2021 Bake Off runner-up Crystelle Pereira and Love Islander Tasha Ghouri, to boost King Charles' popularity.

## Scott O'Neill shares his investing secrets: Young Rich Lister tells how he went from being a humble engineer to owning a property empire worth $81million in just 14 years
 - [https://www.dailymail.co.uk/news/article-12879769/Scott-ONeill-shares-investing-secrets-Young-Rich-Lister-tells-went-humble-engineer-owning-property-empire-worth-81million-just-14-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12879769/Scott-ONeill-shares-investing-secrets-Young-Rich-Lister-tells-went-humble-engineer-owning-property-empire-worth-81million-just-14-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T00:28:03+00:00

Scott and Mina O'Neill are on Australia's Young Rich List with an $81million empire spanning more than 20 properties, a buyer's agency called Rethink Investing and a holiday house in Greece.

## 'It's a total disgrace... the yobs are getting away with it': Just 'one in 20 thugs face charges for vandalism'
 - [https://www.dailymail.co.uk/news/article-12913419/Its-total-disgrace-yobs-getting-away-Just-one-20-thugs-face-charges-vandalism.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12913419/Its-total-disgrace-yobs-getting-away-Just-one-20-thugs-face-charges-vandalism.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T00:27:00+00:00

Home Secretary James Cleverly faced calls for a crackdown on vandalism  after 20,180 criminal damage charges were brought out of the 490,534 cases recorded last year in England and Wales.

## MAIL ON SUNDAY COMMENT: A momentous year lies ahead - and you can change it for the better
 - [https://www.dailymail.co.uk/debate/article-12913411/MAIL-SUNDAY-COMMENT-momentous-year-lies-ahead-change-better.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/debate/article-12913411/MAIL-SUNDAY-COMMENT-momentous-year-lies-ahead-change-better.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T00:18:59+00:00

MAIL ON SUNDAY COMMENT: We are pretty much compelled to turn our minds to midnight thoughts, cheerful or gloomy, on what the next 12 months may bring.

## If 2023 was an Annus Horribilis for Humza's SNP, could 2024 be even WORSE? Writes Euan McColm
 - [https://www.dailymail.co.uk/news/article-12912897/If-2023-Annus-Horribilis-Humzas-SNP-2024-WORSE-Writes-Euan-McColm.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12912897/If-2023-Annus-Horribilis-Humzas-SNP-2024-WORSE-Writes-Euan-McColm.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T00:08:35+00:00

In her last New Year ­message to the nation, ­delivered on December 31, 2022, Nicola Sturgeon sounded like a woman on a mission. Just 46 days later, she announced her resignation.

## Virus expert fears more victims of deadly E.coli - One Scot has died and 11 in hospital as health chiefs probe poison food link to festive hampers
 - [https://www.dailymail.co.uk/news/article-12912929/Virus-expert-fears-victims-deadly-E-coli-One-Scot-died-11-hospital-health-chiefs-probe-poison-food-link-festive-hampers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12912929/Virus-expert-fears-victims-deadly-E-coli-One-Scot-died-11-hospital-health-chiefs-probe-poison-food-link-festive-hampers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-12-31T00:08:26+00:00

Scotland's leading expert on bacteria has warned that there could be further cases of a potentially deadly E.coli strain linked to artisan cheese.

