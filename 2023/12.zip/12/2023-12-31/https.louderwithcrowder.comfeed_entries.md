# Source:Louder With Crowder, URL:https://louderwithcrowder.com/feed/, language:en-US

## Watch: DEBUNKING The Claim That Bidenomics Is Working
 - [https://www.louderwithcrowder.com/debunking-bidenomics](https://www.louderwithcrowder.com/debunking-bidenomics)
 - RSS feed: https://louderwithcrowder.com/feed/
 - date published: 2023-12-31T14:30:34+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=50966249&amp;width=1200&amp;height=800&amp;coordinates=200%2C0%2C0%2C0" /><br /><br /><p>Here is all the proof you need.</p>
<p class="shortcode-media shortcode-media-youtube">
<span class="rm-shortcode" style="display: block; padding-top: 56.25%;"></span>
<small class="image-media media-caption">FACT-CHECK: Debunking The Claim That Bidenomics Is Working!</small>
<small class="image-media media-photo-credit">
<a href="https://youtu.be/DJNNTUmGVCg" target="_blank">youtu.be</a>
</small>
</p>
<p><strong>Sources:</strong></p><ul><li><a href="https://x.com/WhiteHouse/status/1731070741179682909?s=20" rel="noopener noreferrer" target="_blank">"Under Bidenomics, inflation is falling and the economy is growing from the middle out and bottom up."</a></li><li><a href="https://x.com/WhiteHouse/status/1731070741179682909?s=20" rel="noopener noreferrer" target="_blank"></a><a href="https://www.bls.gov/news.release/pdf/cpi.pdf" 

## USA Boxing announces new rules allowing men to hit women if they identify as trans
 - [https://www.louderwithcrowder.com/usa-boxing-women-regulations](https://www.louderwithcrowder.com/usa-boxing-women-regulations)
 - RSS feed: https://louderwithcrowder.com/feed/
 - date published: 2023-12-31T14:12:13+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=50966108&amp;width=1200&amp;height=800&amp;coordinates=100%2C0%2C100%2C0" /><br /><br /><p>The national governing body for Olympic boxing announced brand new rules for 2024, allowing women born as men to compete against women who were born as women and have not had the benefit of going through male puberty.</p><p>If you were born a dude but now think you're a lady, in order to box real ladies <a href="https://www.nationalreview.com/news/usa-boxing-codifies-rule-allowing-male-participation-in-womens-division/" target="_blank">you need to meet the following requirements</a>:</p><ul><li>Declare your gender identity as female</li><li>Have undergone gender reassignment surgery</li><li>Have done hormone testing for a minimum of four years after such procedures</li><li>Have met testosterone limits set by USA Boxing</li><li>Anyone under the age of 18 MUST compete against the gender they were born in</li></ul><p>If we're b

## "It’s a pretty sh*tty platform": Libs of TikTok SUSPENDED by Facebook over unclear community standards excuse
 - [https://www.louderwithcrowder.com/libs-of-tiktok-facebook](https://www.louderwithcrowder.com/libs-of-tiktok-facebook)
 - RSS feed: https://louderwithcrowder.com/feed/
 - date published: 2023-12-31T13:18:51+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=50965878&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C0" /><br /><br /><p>Libs of TikTok posted on Saturday that they have been suspended by Facebook over alleged "community standards" violations. And I know what you're thinking, "Wait, Libs of TikTok was on Facebook?" Apparently!</p><p>Like most LOTT fans, I follow them on X-Twitter. Facebook is mainly an app to joke with friends and family while I watch Louder with Crowder Dot Com website articles get throttled. The Left can no longer successfully have LOTT <a href="https://www.louderwithcrowder.com/libs-of-tiktok-demonetized" target="_blank">suspended from X-Twitter</a>. They needed to move on to a different app to feel like big shots.</p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/libsoftiktok/status/1741309118034669594"></a>
</blockquote>
<p>LOTT proprietor Chaya Raich

