# Source:Gizmodo, URL:https://gizmodo.com/rss, language:en-US

## Open Channel: What Are You Looking Forward to in 2024?
 - [https://gizmodo.com/open-channel-2024-entertainment-look-forward-1851132252](https://gizmodo.com/open-channel-2024-entertainment-look-forward-1851132252)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-12-31T19:40:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/057bbb620ae4e1abde32eaa9c4d70280.png" /><p>In terms of entertainment, 2023 was a big year all around. We got many <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/when-evil-lurks-horror-review-scary-possession-movie-1850895770">wholly new things</a> that were excellent in their own special way, while the majority of reliable brands and franchises <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/guardians-of-galaxy-3-review-james-gunn-chris-pratt-mar-1850385522">stayed firm</a> in greatness or took a few hits with their new entries. And on this, the final day of the year, it’s time to think…</p><p><a href="https://gizmodo.com/open-channel-2024-entertainment-look-forward-1851132252">Read more...</a></p>

## Tom Wilkinson, Beloved Character Actor, Passes Away at Age 75
 - [https://gizmodo.com/obituary-tom-wilkinson-british-actor-1851131934](https://gizmodo.com/obituary-tom-wilkinson-british-actor-1851131934)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-12-31T15:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/cf319a49a4c1ebf952486fea812a6fda.jpg" /><p>British actor Tom Wilkinson died on Saturday. He was 75, and per <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://www.hollywoodreporter.com/news/general-news/tom-wilkinson-dead-full-monty-michael-clayton-1235776939/" rel="noopener noreferrer" target="_blank">the Hollywood Reporter</a>, his family say his death was at home and “sudden.”<br /></p><p><a href="https://gizmodo.com/obituary-tom-wilkinson-british-actor-1851131934">Read more...</a></p>

