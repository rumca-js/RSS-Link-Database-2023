# Source:Warhammer, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg, language:en-US

## This Week in Warhammer – Conquer the Old World
 - [https://www.youtube.com/watch?v=QGE7y_a87Mo](https://www.youtube.com/watch?v=QGE7y_a87Mo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg
 - date published: 2023-12-31T18:00:12+00:00

Return to the World of Legend! See what Warhammer: The Old World pre-orders are coming next week: https://ow.ly/xzaf50QlGy9

Follow for more Warhammer, more often:
- Twitter: https://twitter.com/warhammer
- Facebook: https://www.facebook.com/warhammer40000uk
- Instagram: https://www.instagram.com/warhammerofficial/
- Warhammer Community: https://www.warhammer-community.com/

