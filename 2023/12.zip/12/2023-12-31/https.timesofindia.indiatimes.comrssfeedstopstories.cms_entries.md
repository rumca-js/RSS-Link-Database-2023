# Source:Times of India, URL:https://timesofindia.indiatimes.com/rssfeedstopstories.cms, language:en-gb

## Fast-shrinking Chor Bazaar fights to keep edge in e-age
 - [https://timesofindia.indiatimes.com/india/fast-shrinking-chor-bazaar-fights-to-keep-edge-in-e-age/articleshow/106428437.cms](https://timesofindia.indiatimes.com/india/fast-shrinking-chor-bazaar-fights-to-keep-edge-in-e-age/articleshow/106428437.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T23:11:14+00:00

Haji Ebrahim Record Shop and Chor Bazaar in Mumbai have lost their relevance. The famous Mutton Street in Chor Bazaar has been partially taken over by a redevelopment project. Despite rumors of Chor Bazaar's demise, it will survive as long as people have a taste for antique pieces. Chor Bazaar got its name from the distortion of 'Shor Bazaar,' which was known for scrap units and the noise they created. Chor Bazaar continues to attract buyers and visitors with its unique offerings, including old film posters and rare objects.

## Achieved 95% conviction rate, arrested 625 accused in '23: NIA
 - [https://timesofindia.indiatimes.com/india/achieved-95-conviction-rate-arrested-625-accused-in-23-nia/articleshow/106428424.cms](https://timesofindia.indiatimes.com/india/achieved-95-conviction-rate-arrested-625-accused-in-23-nia/articleshow/106428424.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T23:08:39+00:00

NIA identifies 43 suspects linked to vandalism on Indian high commissions in UK, US, and Canada. 50 raids, 80 people examined in India. Overall conviction rate of 94.7%, 625 arrests, attachment of 240 assets worth Rs 56 crore. 28% rise in arrests, including ISIS, jihadi terror, human trafficking, terrorist and organized crime, and LWE cases. 68 cases registered in 2023, including jihadi terror, J&amp;K, LWE, Punjab, north-east, and fake currency. 513 chargesheeted, 74 convicted. 47 accused tracked down and arrested. Increase in searches and raids, attachment of properties worth Rs 56 crore.

## '91 batch IAS officer, Sudhansh Pant named Raj chief secretary
 - [https://timesofindia.indiatimes.com/india/91-batch-ias-officer-sudhansh-pant-named-rajasthan-chief-secretary/articleshow/106428234.cms](https://timesofindia.indiatimes.com/india/91-batch-ias-officer-sudhansh-pant-named-rajasthan-chief-secretary/articleshow/106428234.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T22:52:09+00:00

Sudhansh Pant, an IAS officer of the 1991 batch, was appointed chief secretary of Rajasthan on Sunday, barely hours after he was suddenly repatriated to his home cadre. This came a day after 1984 batch IAS officer D S Mishra got a six-month extension as Uttar Pradesh chief secretary. There is speculation over the Centre sending another top IAS officer from Delhi to MP to become the new chief secretary. Currently, Veera Rana, a 1998 batch IAS officer, is holding additional charge of chief secretary in the state where BJP came back to office with more seats in the recently-held assembly elections. Rana, the second woman chief secretary of MP, is due for retirement in March 2024.

## Rape FIR against pharma firm CMD after HC order
 - [https://timesofindia.indiatimes.com/india/rape-fir-against-pharma-firm-cmd-after-hc-order/articleshow/106428208.cms](https://timesofindia.indiatimes.com/india/rape-fir-against-pharma-firm-cmd-after-hc-order/articleshow/106428208.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T22:51:30+00:00

The Ahmedabad police on Sunday booked the CMD of a major pharmaceutical company in the state for rape following the Gujarat HC's order on allegations levelled by a Bulgarian woman. ACP H M Kansagra said, "Complying with the court order, we filed a complaint on Sunday against Cadila Pharmaceuticals CMD Rajiv Modi under IPC sections 376 (rape), 354 (molestation), and 504 (intentional insult with intent to provoking breach of peace." The investigating officer, inspector of the Sola police station, said the cops will take the statement of the complainant and the witnesses after which they will arrest the accused.

## Social boycott has no place in civilised society: Calcutta HC
 - [https://timesofindia.indiatimes.com/india/social-boycott-has-no-place-in-civilised-society-calcutta-hc/articleshow/106427778.cms](https://timesofindia.indiatimes.com/india/social-boycott-has-no-place-in-civilised-society-calcutta-hc/articleshow/106427778.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T22:37:12+00:00

There is no place for social boycott of a citizen in a civilized society, the Calcutta high court said Wednesday while addressing a case where a man faced ostracism for reporting illegal temple construction in front of his property in the Arambag area of Bengal's Hooghly. "Any social boycott of a citizen or his family member has to be dealt with strictly by the administration. This has no place in a civilised society," said Justice Jay Sengupta, directing police to maintain vigilant patrols to prevent any breach of peace or violation of the civil court order in the area.

## Unescorted 2-year-old adds to ‘donkey flight’ mystery
 - [https://timesofindia.indiatimes.com/india/unescorted-2-year-old-adds-to-donkey-flight-mystery/articleshow/106427307.cms](https://timesofindia.indiatimes.com/india/unescorted-2-year-old-adds-to-donkey-flight-mystery/articleshow/106427307.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T22:36:50+00:00

Amidst the unfolding saga of the “donkey flight” grounded in France, one passenger stands out — a two-year-old boy from Gujarat who was onboard as an unaccompanied minor. However, he is now untraceable. Gujarat police have launched an investigation to locate the child, identify his parents or guardians, and unravel whether he was part of a complex plan orchestrated by human smugglers, possibly facing a fate similar to the many children abandoned on the US-Canada border.

## Midnight rave party busted in Maharashtra, 95 revellers held
 - [https://timesofindia.indiatimes.com/india/midnight-rave-party-busted-in-maharashtra-95-revellers-held/articleshow/106427337.cms](https://timesofindia.indiatimes.com/india/midnight-rave-party-busted-in-maharashtra-95-revellers-held/articleshow/106427337.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T22:22:38+00:00

Police busted a rave party held at an isolated stretch in Thane's Kasarwadavli creek, nearly 2km off the busy Ghodbunder road, in the wee hours of Sunday and detained 95 revellers, including five women, and arrested the two organisers. Following a tipoff, a joint team from crime branch unit-V Wagle Estate and unit-II Bhiwandi swooped down on the revellers - mostly students and call centre employees - around 3am. The organisers - Tejas Kubal (23) and Sujal Mahajan (19) - and the 95 guests were booked under relevant sections of the Narcotics Drugs and Psychotropic Substances Act and the Maharashtra Prohibition Act.

## Packaged items to display price per unit
 - [https://timesofindia.indiatimes.com/india/packaged-items-to-display-price-per-unit/articleshow/106426821.cms](https://timesofindia.indiatimes.com/india/packaged-items-to-display-price-per-unit/articleshow/106426821.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T22:00:15+00:00

Starting Monday, manufacturers and importers must display the price per unit along with the overall MRP on packaged items. Additionally, the month and year of manufacturing must be mentioned. The new rule eliminates the option to mention the month and year of 'pre-packed or imported' items. The unit price must be mentioned in per kg or per litre for items weighing more than a kg or litre, and in per gram or millilitre for items weighing less. Manufacturers must also mention the price per piece for items with multiple units.

## Part of oppn bloc, says AAP, focuses on LS, Haryana polls
 - [https://timesofindia.indiatimes.com/india/part-of-opposition-bloc-says-aap-focuses-on-ls-haryana-polls/articleshow/106426804.cms](https://timesofindia.indiatimes.com/india/part-of-opposition-bloc-says-aap-focuses-on-ls-haryana-polls/articleshow/106426804.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T21:46:49+00:00

Setting in motion preparations for the 2024 Lok Sabha elections, Delhi CM Arvind Kejriwal said as a member of the 'INDIA' group of opposition parties, the party would put up a strong fight on whichever seats came its way after seat-sharing talks. "AAP is part of the INDIA group. Whatever seats we get, we will fight with all our might and win them," Kejriwal said at AAP's national executive and national council meeting on Sunday. "Elections cannot be won without a strong organisation; therefore, now we need to build our organisation across the entire country," he added.

## MoD denies tableau bias, Punjab hits back
 - [https://timesofindia.indiatimes.com/india/mod-denies-tableau-bias-punjab-hits-back/articleshow/106426798.cms](https://timesofindia.indiatimes.com/india/mod-denies-tableau-bias-punjab-hits-back/articleshow/106426798.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T21:43:27+00:00

Calling the "discrimination" charge of Punjab, Delhi and West Bengal for rejecting their state tableaux "baseless", the ministry of defence on Sunday clarified that their tableaux were not included in the Republic Day 2024 parade as they were not aligned with the broader themes of this year's tableau. Punjab CM Bhagwant Mann criticised the BJP-led government for not including the state's tableau in the parade and said that both Punjab and Delhi were excluded from the list of states whose tableaux have been selected for the parade on January 26.

## Govt building strong domestic defence industrial ecosystem: Rajnath
 - [https://timesofindia.indiatimes.com/india/government-building-strong-base-of-domestic-defence-industrial-ecosystem-rajnath-singh/articleshow/106426794.cms](https://timesofindia.indiatimes.com/india/government-building-strong-base-of-domestic-defence-industrial-ecosystem-rajnath-singh/articleshow/106426794.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T21:42:23+00:00

Defence minister Rajnath Singh on Sunday said keeping in mind the aspirations and capabilities of a New India, the country needs strategic autonomy and the government is developing a strong base of domestic defence industrial ecosystem to achieve that. He was speaking at the 21st convocation of Tezpur University (TU), a central varsity located near the Assam-Arunachal Pradesh border in northern Assam. Tezpur is an important Army base and the headquarters of the 4 Corps, which is responsible for the security of India's northern boundary with China in the Tawang sector.

## Navy boosts surveillance amid surge in ship attacks
 - [https://timesofindia.indiatimes.com/india/navy-boosts-surveillance-amid-surge-in-ship-attacks/articleshow/106426633.cms](https://timesofindia.indiatimes.com/india/navy-boosts-surveillance-amid-surge-in-ship-attacks/articleshow/106426633.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T21:11:40+00:00

In the wake of the recent drone strikes on India-bound commercial ships and increased attacks from Iran-backed Houthi rebels, the defence ministry on Sunday that "Indian Navy has enhanced maritime surveillance" by deploying task groups comprising destroyers and a frigate in the Red Sea, Gulf of Aden and Central &amp; North Arabian Sea to protect its commercial assets and interest even as Navy chief Admiral R Hari Kumar has issued directions to the Navy to take all possible actions to enhance security and look out for any suspicious activity in the Arabian Sea region.

## J&K terror incidents fell to 44 in 2023 from 228 in 2018: MHA
 - [https://timesofindia.indiatimes.com/india/jk-terror-incidents-fell-to-44-in-2023-from-228-in-2018-mha/articleshow/106426551.cms](https://timesofindia.indiatimes.com/india/jk-terror-incidents-fell-to-44-in-2023-from-228-in-2018-mha/articleshow/106426551.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T20:36:54+00:00

Year 2023 in Jammu and Kashmir saw a significant decline in incidents of bandhs and street violence compared to previous years. Until December 15, there were no organised hartals or organised stone-pelting incidents related to terrorism and separatism, in contrast to 52 hartals and 1,221 stone-pelting incidents in 2018. Additionally, the home ministry reported a decrease in terrorist-initiated incidents, encounters, civilian and security personnel fatalities. The tourism sector in J&amp;K experienced remarkable growth, with over 1.9 crore incoming tourists and a record-breaking 4.4 lakh yatris participating in the Amarnath Yatra.

## Covid cases rise 22% in a week, Kerala numbers fall
 - [https://timesofindia.indiatimes.com/india/covid-cases-rise-22-in-a-week-kerala-numbers-fall/articleshow/106426480.cms](https://timesofindia.indiatimes.com/india/covid-cases-rise-22-in-a-week-kerala-numbers-fall/articleshow/106426480.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T20:09:52+00:00

India recorded a 22% rise in Covid cases this week as compared to the last, with the tally in the past 24 hours crossing 800 for the first time in seven months, reports Amit Bhattacharya. While the overall numbers remain very low and the rise has been gradual - possibly because of sparse testing and a large number of cases remaining mild - data shows that the JN.1-driven surge is spreading across the country and that infections may already have peaked in Kerala, the state logging the highest counts in the current phase.

## Entire country is excited over Ram mandir: PM Modi
 - [https://timesofindia.indiatimes.com/india/entire-country-is-excited-over-ram-mandir-pm-modi/articleshow/106426436.cms](https://timesofindia.indiatimes.com/india/entire-country-is-excited-over-ram-mandir-pm-modi/articleshow/106426436.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T19:52:54+00:00

PM Modi, in the 108th edition of his 'Mann Ki Baat' on Sunday, said there was excitement and enthusiasm in the entire country in connection with the Ram mandir as he called it a "historic moment" and urged people to share artistic creations by using a common hashtag. The PM emphasised the special edition as '108', an auspicious number as per Hindu belief, as he mentioned the excitement surrounding the temple and said, "People are expressing their feelings in a multitude of ways."

## No ‘cold day’ as city logs warmest December in 6 years
 - [https://timesofindia.indiatimes.com/india/no-cold-day-as-city-logs-warmest-december-in-6-years/articleshow/106426434.cms](https://timesofindia.indiatimes.com/india/no-cold-day-as-city-logs-warmest-december-in-6-years/articleshow/106426434.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T19:52:33+00:00

In December this year, the mean maximum temperature was 24.1 degrees Celsius, significantly higher than the normal of 22.8 degrees C, while the mean minimum was 8.6 degrees C, a shade higher than the normal (8.4 degrees C). Not since 2017 have both the mean maximum and minimum temperatures been above normal in December. On the last day of the year, however, the day temperature dipped to the season’s lowest of 15.9 degrees Celsius at Safdarjung on Sunday, 4.5 degrees below normal.

## BJP IT cell duo among 3 held for IIT-BHU girl's gang rape
 - [https://timesofindia.indiatimes.com/india/bjp-it-cell-duo-among-3-held-for-iit-bhu-girls-gang-rape/articleshow/106426429.cms](https://timesofindia.indiatimes.com/india/bjp-it-cell-duo-among-3-held-for-iit-bhu-girls-gang-rape/articleshow/106426429.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T19:50:25+00:00

Two members of BJP's IT cell in Varanasi were among three people arrested late Saturday for the gangrape of a 20-year-old BTech student of IIT-BHU. The arrested trio confessed to the crime, including disrobing and filming the survivor at gunpoint. The three could face charges under the National Security Act and the UP Gangsters and Anti-Social Activities (Prevention) Act. One of the arrested individuals was identified as the convenor of BJP's IT cell's city unit, while another was identified as its co-convenor. The revelation sparked a political controversy in UP.

## 4 commandos hurt as militants attack Manipur police post
 - [https://timesofindia.indiatimes.com/india/4-commandos-hurt-as-militants-attack-manipur-police-post-near-myanmar/articleshow/106426407.cms](https://timesofindia.indiatimes.com/india/4-commandos-hurt-as-militants-attack-manipur-police-post-near-myanmar/articleshow/106426407.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T19:41:35+00:00

Suspected militants attacked a police outpost in Moreh Turelwangma Leikai, bordering Myanmar, with a shower of rocket-propelled grenades, mortar fire, and bullets. Four commandos and a village guard were injured in the attack. The injured commandos were moved to Imphal for advanced treatment and are out of danger. The N Biren Singh government sent reinforcements to Moreh, and some houses were set ablaze during the attack. Displaced residents staged a demonstration against the renewed attacks on state forces.

## MHA declares outfit founded by Geelani 'unlawful association'
 - [https://timesofindia.indiatimes.com/india/mha-declares-outfit-founded-by-geelani-unlawful-association/articleshow/106426372.cms](https://timesofindia.indiatimes.com/india/mha-declares-outfit-founded-by-geelani-unlawful-association/articleshow/106426372.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T19:34:28+00:00

The Centre designates the Tehreek-e-Hurriyat (TeH), a separatist outfit in Jammu and Kashmir, as an 'unlawful association' under the UAPA. The group is involved in anti-India activities and aims to establish Islamic rule. Home Minister Amit Shah warns that any involvement in anti-India activities will be thwarted. The ban on TeH is part of the government's zero-tolerance policy against terrorism. The group has been involved in fomenting terrorism, secessionism, and anti-India propaganda, and receives funds from Pakistan and proxy organizations. TeH also opposes the democratic system and boycotts assembly elections.

## J&K Police offers 12L reward against anti-national activities
 - [https://timesofindia.indiatimes.com/india/jk-police-announces-reward-up-to-rs-12l-to-curb-anti-national-activities/articleshow/106426257.cms](https://timesofindia.indiatimes.com/india/jk-police-announces-reward-up-to-rs-12l-to-curb-anti-national-activities/articleshow/106426257.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T19:15:30+00:00

In an attempt to curb ‘anti-national activities’ in the Union Territory, the J&amp;K Police has announced cash reward of up to Rs 12.50 lakh for people who provide information and intelligence on trans-border tunnels, drones, narcotics, terror activities and terrorists. The cash reward for providing information about trans-border tunnels used by anti-national elements is Rs 5 lakh, according to the J&amp;K Police. Further, the police announced Rs 3 lakh reward for those who sight drones from the across the border and provide information about the same.

## Denmark's Queen Margrethe II to abdicate on Jan 14
 - [https://timesofindia.indiatimes.com/world/europe/denmarks-queen-margrethe-ii-to-abdicate-on-january-14/articleshow/106425578.cms](https://timesofindia.indiatimes.com/world/europe/denmarks-queen-margrethe-ii-to-abdicate-on-january-14/articleshow/106425578.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T17:33:55+00:00



## 75+ Happy New Year messages, greetings, wishes and quotes for 2024
 - [https://timesofindia.indiatimes.com/life-style/events/new-year-wishes-messages-75-happy-new-year-messages-greetings-wishes-and-quotes-for-2024/articleshow/106358347.cms](https://timesofindia.indiatimes.com/life-style/events/new-year-wishes-messages-75-happy-new-year-messages-greetings-wishes-and-quotes-for-2024/articleshow/106358347.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T17:30:00+00:00

Here are some of the warmest New Year greetings for the coming year.

## BB17: Rinku gets eliminated; Munawar and Neil cry inconsolably
 - [https://timesofindia.indiatimes.com/tv/news/hindi/bigg-boss-17-rinku-dhawan-gets-eliminated-munawar-faruqui-and-neil-bhatt-cry-inconsolably/articleshow/106425491.cms](https://timesofindia.indiatimes.com/tv/news/hindi/bigg-boss-17-rinku-dhawan-gets-eliminated-munawar-faruqui-and-neil-bhatt-cry-inconsolably/articleshow/106425491.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T17:23:40+00:00

Dharmendra, Mika Singh, Arbaaz Khan, and Sohail Khan grace the stage on the latest episode of Bigg Boss 17. Krushna Abhishek entertains with a Jackie Shroff skit. Salman Khan announces a double elimination. The contestants perform a dance tribute to Dharmendra. Rinku Dhawan gets eliminated and advises Munawar to get his things together. Ayesha Khan suffers a panic attack and is taken to the hospital. Take a look at what happened inside the house for new year's celebration:

## How India's humanitarian leadership shined in 2023
 - [https://timesofindia.indiatimes.com/india/indias-humanitarian-leadership-shines-in-2023-a-year-of-global-aid-and-compassion/articleshow/106425124.cms](https://timesofindia.indiatimes.com/india/indias-humanitarian-leadership-shines-in-2023-a-year-of-global-aid-and-compassion/articleshow/106425124.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T17:09:41+00:00

India's humanitarian efforts in 2023 include Operation Dost for earthquake relief in Turkey, Operation Karuna for Cyclone Sitrang in Myanmar, and Operation Kaveri for aid in Sudan. India also pledged $12.25 billion for development projects in Africa and played a key role in global vaccination efforts through "Vaccine Maitri". India collaborated with UN agencies, participated in regional organizations, and invested in strengthening its HADR capabilities. These actions demonstrate India's commitment to global solidarity, compassion, and crisis response, solidifying its position as a responsible global player.

## After UP chief secretary's tenure extension; Raj gets new CS
 - [https://timesofindia.indiatimes.com/india/after-up-chief-secretarys-tenure-extension-rajasthan-gets-new-cs-mp-may-be-the-next/articleshow/106424916.cms](https://timesofindia.indiatimes.com/india/after-up-chief-secretarys-tenure-extension-rajasthan-gets-new-cs-mp-may-be-the-next/articleshow/106424916.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T16:22:48+00:00

IAS officer Sudhansh Pant was appointed as the new chief secretary of Rajasthan after being repatriated. D S Mishra got a six-month extension as the chief secretary of Uttar Pradesh. There is speculation about another IAS official being sent from Delhi to become the new chief secretary of Madhya Pradesh. Veera Rana, the current chief secretary, will retire in March 2024. A reshuffle of secretary level appointments is expected.

## Check B737 MAX for loose nut, Boeing tells airlines: AI Express, Akasa & SpiceJet affected
 - [https://timesofindia.indiatimes.com/india/check-b737-max-for-loose-rudder-nut-boeing-tells-airlines-ai-express-akasa-spicejet-affected/articleshow/106424666.cms](https://timesofindia.indiatimes.com/india/check-b737-max-for-loose-rudder-nut-boeing-tells-airlines-ai-express-akasa-spicejet-affected/articleshow/106424666.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T15:59:26+00:00

Boeing has asked operators of Boeing 737 MAX globally, including Air India Express, SpiceJet, and Akasa, to inspect tie rods controlling rudder movement for loose hardware. The Directorate General of India (DGCA) confirms that the necessary checks are being carried out as per Boeing's instructions. The issue does not impact the operations of Akasa and SpiceJet, who operate a combined total of 32 B737 MAX aircraft. The B737 MAX was previously grounded globally but was allowed to fly again after safety improvements.

## 2023: When climate change truly became a hot topic
 - [https://timesofindia.indiatimes.com/home/environment/year-ender-2023-key-moments-and-significant-advances-in-climate-change-conference-cop28/articleshow/106424577.cms](https://timesofindia.indiatimes.com/home/environment/year-ender-2023-key-moments-and-significant-advances-in-climate-change-conference-cop28/articleshow/106424577.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T15:47:45+00:00

Representatives from almost 200 nations gathered in Dubai for the COP28 climate summit, where they reached an agreement to phase out fossil fuels and achieve net-zero emissions by 2050. Over $85 billion was pledged in support of climate action. The World Bank implemented reforms, freeing up $4 billion annually. 2023 was declared the hottest year on record, prompting calls for a complete phase-out of fossil fuels. Insufficient commitments from oil companies were criticized. 134 countries signed a declaration to address the climate impacts of the food industry.

## Happy New Year 2024: Wishes, Messages, Quotes, Images, FB & WA status
 - [https://timesofindia.indiatimes.com/life-style/events/happy-new-year-2024-wishes-messages-quotes-images-facebook-whatsapp-status/articleshow/106380807.cms](https://timesofindia.indiatimes.com/life-style/events/happy-new-year-2024-wishes-messages-quotes-images-facebook-whatsapp-status/articleshow/106380807.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T15:30:00+00:00

Happy New Year 2024 Wishes &amp; Messages: New Year is celebrated worldwide as a symbol of the passage of time, offering reflection, renewal, and anticipation. Cultures embrace this transition with festive gatherings, fireworks, and traditions. It is a time to set goals, make resolutions, and welcome positive changes. The celebration fosters unity and a sense of shared experience. The significance of New Year transcends cultural boundaries, holding profound meaning for individuals and societies. It serves as a moment of reflection, offering a fresh start and personal renewal. The celebration unites people in acknowledging the continuous journey through time.

## How China's is using AI to outsmart American spies
 - [https://timesofindia.indiatimes.com/world/china/a-new-era-in-intel-game-how-chinas-is-using-ai-to-outsmart-american-spies/articleshow/106424019.cms](https://timesofindia.indiatimes.com/world/china/a-new-era-in-intel-game-how-chinas-is-using-ai-to-outsmart-american-spies/articleshow/106424019.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T14:58:06+00:00



## Harsh lessons learnt in 2023 about green sustenance
 - [https://timesofindia.indiatimes.com/india/environment-sustenance-few-lessons-that-were-and-werent-learnt-by-india-in-2023/articleshow/106423722.cms](https://timesofindia.indiatimes.com/india/environment-sustenance-few-lessons-that-were-and-werent-learnt-by-india-in-2023/articleshow/106423722.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T14:39:36+00:00

India takes major steps towards an eco-friendly transformation in 2023. The National Electricity plan (NEP) aims to increase non-fossil-based capacity to 68.4% by 2031-32. The National Green Hydrogen Mission positions India as a global centre for green hydrogen production. The Green Credits Programme incentivizes positive environmental impact, while amendments in environmental and forest laws improve eco-friendliness. However, challenges remain with India's dependence on fossil fuels, pollution, water crisis, extreme weather conditions, and garbage disposal problems.

## PM, Mamata broke poll promises to farmers: Congress
 - [https://timesofindia.indiatimes.com/city/kolkata/neither-modi-nor-didi-kept-promises-made-to-the-farmers-adhir-chowdhury/articleshow/106423222.cms](https://timesofindia.indiatimes.com/city/kolkata/neither-modi-nor-didi-kept-promises-made-to-the-farmers-adhir-chowdhury/articleshow/106423222.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T14:09:10+00:00

Adhir Chowdhury, West Bengal Congress president, highlighted the deplorable condition of farmers in the country and in West Bengal. He compared the functioning of Prime Minister Narendra Modi and West Bengal chief minister Mamata Banerjee, stating that both have failed to fulfill their promises to increase farmers' income. Chowdhury also criticized the BJP for using the Ram Mandir issue as a political tool and urges them not to turn it into a political ploy. He also took a dig at the internal feud within the Trinamool Congress.

## Isto to welcome 2024 with historic satellite launch
 - [https://timesofindia.indiatimes.com/home/science/isro-to-launch-xposat-on-january-1-all-you-need-to-know-about-indias-first-mission-to-study-black-holes/articleshow/106421793.cms](https://timesofindia.indiatimes.com/home/science/isro-to-launch-xposat-on-january-1-all-you-need-to-know-about-indias-first-mission-to-study-black-holes/articleshow/106421793.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T12:51:37+00:00



## QR code fraud alert ahead of Ram Temple event
 - [https://timesofindia.indiatimes.com/india/qr-code-fraud-targets-devotees-ahead-of-ram-temple-consecration-event/articleshow/106421317.cms](https://timesofindia.indiatimes.com/india/qr-code-fraud-targets-devotees-ahead-of-ram-temple-consecration-event/articleshow/106421317.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T12:00:34+00:00

A fraudulent scheme exploiting devotees on the pretext of seeking donations for the Ram Temple has emerged. The Vishwa Hindu Parishad (VHP) has warned about a cybercriminal network circulating social media messages with QR codes to swindle money. The Shri Ram Janmbhoomi Teerth Kshetra has not authorized anyone to collect funds. The matter has been reported to the home ministry and police authorities. VHP released an audio clip exposing the fraudsters' tactics and their divisive narrative. Scammers use malicious QR codes to steal personal and financial data or install malware.

## 'Not chokers but...': Prasad on India's ICC trophy-less run
 - [https://timesofindia.indiatimes.com/sports/cricket/news/not-chokers-but-venkatesh-prasad-weighs-in-on-indias-icc-trophy-less-run/articleshow/106420356.cms](https://timesofindia.indiatimes.com/sports/cricket/news/not-chokers-but-venkatesh-prasad-weighs-in-on-indias-icc-trophy-less-run/articleshow/106420356.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T11:11:33+00:00

The ongoing discussion surrounds India's extended quest for an ICC trophy, with former players and fans alike questioning the team's persistent issue. The last time India secured a major ICC tournament victory was in 2013, clinching the ICC Champions Trophy under the captaincy of MS Dhoni. In 2023, the 'Men in Blue' reached the final of ICC World Cup at home. They reached the finals of the 2019-21 and 2021-23 ICC World Test Championship, but have failed to win any of these tournaments.

## 'Ye bhai gaya...': Axar recalls chilling moment after Pant's accident
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/ye-bhai-gaya-axar-patel-recalls-chilling-moment-when-he-heard-about-rishabh-pants-accident/articleshow/106420258.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/ye-bhai-gaya-axar-patel-recalls-chilling-moment-when-he-heard-about-rishabh-pants-accident/articleshow/106420258.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T11:02:06+00:00

As Saturday marked one year of Rishabh Pant's near-fatal car accident, his India and Delhi Capitals teammate Axar Patel recalled the chilling moment when he first got to know about the mishap. Last year, Pant was involved in a horrific car accident as he escaped from his burning car after it hit a divider on the Delhi-Roorkee highway.

## A real rollercoaster: India's diplomatic highs and lows of 2023
 - [https://timesofindia.indiatimes.com/india/indias-diplomatic-rollercoaster-navigating-indias-highs-and-lows-in-2023/articleshow/106419599.cms](https://timesofindia.indiatimes.com/india/indias-diplomatic-rollercoaster-navigating-indias-highs-and-lows-in-2023/articleshow/106419599.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T10:55:06+00:00

India's diplomatic journey in 2023 was marked by successes and challenges. Relations between India and Canada hit rock bottom due to allegations of Indian government involvement in the death of a Canadian citizen linked to Khalistan extremism. India-China border tensions worsened when China asserted its claim over parts of Arunachal Pradesh and released a new map. India faced twists and turns in its relations with the United States, with high-profile visits and historic deals, but also a plot to harm a US national. PM Modi undertook diplomatic visits to multiple countries, and India inaugurated new embassies.

## A review of 2023 through 7 revealing global factors
 - [https://timesofindia.indiatimes.com/india/dwindling-press-freedom-to-wealth-inequality-assessing-2023-through-seven-indices/articleshow/106419572.cms](https://timesofindia.indiatimes.com/india/dwindling-press-freedom-to-wealth-inequality-assessing-2023-through-seven-indices/articleshow/106419572.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T10:52:24+00:00

Press freedom deteriorates globally due to the fake content industry, while illiberal incumbents contribute to the decline of democracy. Poverty persists, with child wasting as a key indicator. The world is faced with pressing challenges like inequality and climate change that require immediate action. Freedom, democracy, and equality are at stake, and the interrelatedness of these issues must be acknowledged. The international community's collective will and action are crucial to create a more equitable and sustainable future.

## India's link to Europe hit as shipping firm suspends ops in Red Sea
 - [https://timesofindia.indiatimes.com/world/rest-of-world/maersk-suspends-vessels-passage-through-red-sea-strait-for-48-hours/articleshow/106419536.cms](https://timesofindia.indiatimes.com/world/rest-of-world/maersk-suspends-vessels-passage-through-red-sea-strait-for-48-hours/articleshow/106419536.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T10:10:39+00:00

Maersk suspends Red Sea strait passage for 48 hours after Yemeni rebels attack the Maersk Hangzhou container ship. The vessel faced additional aggression from four Houthi ships attempting to board it. India heavily relies on the Bab-el-Mandeb Strait for trade with the Middle East, Africa, and Europe. Closure of the route increases voyage distances by 40% and raises transportation time and cost. India faces increased costs and security risks, prompting efforts to diversify trade routes and enhance regional maritime security cooperation.

## New car launches in 2024: New Kia Sonet to Hyundai Creta facelift
 - [https://timesofindia.indiatimes.com/auto/cars/new-car-launches-in-january-2024-new-kia-sonet-to-hyundai-creta-facelift/articleshow/106419214.cms](https://timesofindia.indiatimes.com/auto/cars/new-car-launches-in-january-2024-new-kia-sonet-to-hyundai-creta-facelift/articleshow/106419214.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T10:03:12+00:00

The new Sonet will be offered in three engines and give gearbox options. a 1.2-litre NA Petrol engine which puts out 82 bhp of power and 115 Nm of peak torque. The engine comes paired with a 5-speed manual gearbox. The second engine is the 1.0-litre, 3-cyl turbo petrol engine which puts out 118 bhp of power and 172 Nm of peak torque.

## Govt bans Tehreek-e-Hurriyat under UAPA for 5 years
 - [https://timesofindia.indiatimes.com/india/mha-declares-tehreek-e-hurriyat-an-unlawful-association-under-uapa-for-five-years/articleshow/106418531.cms](https://timesofindia.indiatimes.com/india/mha-declares-tehreek-e-hurriyat-an-unlawful-association-under-uapa-for-five-years/articleshow/106418531.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T09:10:17+00:00

The Ministry of Home Affairs has officially declared 'Tehreek-e-Hurriyat (TeH)' as an 'unlawful association' for the next five years under the Unlawful Activities (Prevention) Act. In a notification issued, the MHA mentioned that it has declared TeH as an unlawful association for a five-year period, using the authority granted by section 3 of the Unlawful Activities (Prevention) Act, 1967 (37 of 1967). Following this announcement, Union Home Minister Amit Shah posted on 'X', "The 'Tehreek-e-Hurriyat, J&amp;K (TeH) has been declared an 'Unlawful Association' under UAPA.

## 100 'young guests' held after Mumbai cops bust rave party; drugs worth Rs 8 lakh seized
 - [https://timesofindia.indiatimes.com/city/mumbai/thane-police-busts-rave-party-detains-two-hosts-100-young-guests/articleshow/106418168.cms](https://timesofindia.indiatimes.com/city/mumbai/thane-police-busts-rave-party-detains-two-hosts-100-young-guests/articleshow/106418168.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T08:53:07+00:00

Thane police busted a rave party along Kasarwadavli creekside and detained 100 young guests, including two local hosts. Chief Minister Eknath Shinde ordered action against drug sellers. The hosts posted an invite on social media, attracting youngsters from Mumbai, Navi Mumbai, Thane, Mira-Bhayender. Police seized LSD, charas, ecstasy pills worth Rs 8 lakhs. Investigations are ongoing.

## How India is achieving 'domain awareness' in Arabian Sea
 - [https://timesofindia.indiatimes.com/india/attack-on-merchant-vessels-mv-ruen-mv-chem-pluto-indian-navy-enhances-maritime-surveillance-efforts-in-arabian-sea/articleshow/106417489.cms](https://timesofindia.indiatimes.com/india/attack-on-merchant-vessels-mv-ruen-mv-chem-pluto-indian-navy-enhances-maritime-surveillance-efforts-in-arabian-sea/articleshow/106417489.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T08:39:13+00:00

Task Groups comprising destroyers and frigates have also been deployed to undertake maritime security operations and render assistance to merchant vessels in case of any incident. "Aerial surveillance by long-range maritime patrol aircraft and Remotely Piloted Aircraft (RPAs) has been enhanced to have complete maritime domain awareness. Towards effective surveillance of Exclusive Economic Zone (EEZ), the Indian Navy is operating in close coordination with the Indian Coast Guard," it said in a statement on Saturday.

## Watch: Team India gears up for 2nd Test against South Africa
 - [https://timesofindia.indiatimes.com/sports/cricket/india-in-south-africa/watch-team-india-gears-up-for-2nd-test-against-south-africa/articleshow/106417592.cms](https://timesofindia.indiatimes.com/sports/cricket/india-in-south-africa/watch-team-india-gears-up-for-2nd-test-against-south-africa/articleshow/106417592.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T08:15:28+00:00

The Indian cricket team hit the nets ahead of the second Test at Newlands in Cape Town. India's dream of winning a Test series in South Africa for the first time was ended inside three days. Virat Kohli hit an aggressive 76 for India. Dean Elgar was named man of the match. He has announced he will retire from international cricket after the second Test. With the series consisting of only two matches India can at best earn a share of the honours if they win the second Test.

## Rahul reacts on Vinesh returning awards, accuses PM of 'cruelty'
 - [https://timesofindia.indiatimes.com/india/rahul-gandhi-reacts-on-vinesh-phogat-returning-awards-accuses-pm-modi-of-cruelty/articleshow/106416984.cms](https://timesofindia.indiatimes.com/india/rahul-gandhi-reacts-on-vinesh-phogat-returning-awards-accuses-pm-modi-of-cruelty/articleshow/106416984.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T07:39:49+00:00

Congress leader Rahul Gandhi on Sunday hit out at PM Modi after wrestler Vinesh Phogat returned her Khel Ratna and Arjuna Award at Delhi's Kartavya Path. Rahul accused the PM of 'cruelty'. World Championship medalist Phogat returned left her awards in the middle of Kartavya Path after the Delhi Police stopped her before reaching the Prime Minister's Office. Phogat and others protested against the election of Sanjay Singh, a close aide of former WFI chief Brij Bhushan, accused of sexual harassment.

## BB 17: Netizens slam makers for whitewashing Munawar's image
 - [https://timesofindia.indiatimes.com/tv/news/hindi/bigg-boss-17-netizens-slam-makers-and-salman-khan-for-whitewashing-munawar-faruquis-image-and-support-ayesha-khan-says-stop-normalising-victim-blaming-and-silencing-them/articleshow/106416746.cms](https://timesofindia.indiatimes.com/tv/news/hindi/bigg-boss-17-netizens-slam-makers-and-salman-khan-for-whitewashing-munawar-faruquis-image-and-support-ayesha-khan-says-stop-normalising-victim-blaming-and-silencing-them/articleshow/106416746.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T07:08:54+00:00

In the recent episode of Bigg Boss 17, Ayesha Khan suffered a panic attack and was rushed to the medical room. Salman Khan, along with the housemates, consulted the doctor about Ayesha's health. Netizens criticized Munawar Faruqui and Salman Khan for Ayesha's condition. They accused Salman Khan of normalizing Munawar's behavior and blamed Munawar for Ayesha's severe condition. Fans praised Anurag Dhobal for taking a stand for Ayesha. The makers of the show were slammed for whitewashing Munawar and making a joke out of Ayesha's mental health.

## Highlights of PM Modi's last Mann Ki Baat episode of 2023
 - [https://timesofindia.indiatimes.com/india/mann-ki-baat-pm-modi-highlights-viksit-bharat-physical-mental-health-ai-tool-space-missions-sports-achievements-and-others-in-last-episode-of-2023/articleshow/106415887.cms](https://timesofindia.indiatimes.com/india/mann-ki-baat-pm-modi-highlights-viksit-bharat-physical-mental-health-ai-tool-space-missions-sports-achievements-and-others-in-last-episode-of-2023/articleshow/106415887.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T06:32:58+00:00

Prime Minister Narendra Modi, in his latest address, highlighted India's growing self-confidence and commitment to self-reliance. Speaking during the 108th episode of his Mann Ki Baat radio program, Modi focused on the nation's embodiment of the 'Viksit Bharat' (developed India) spirit, emphasizing the importance of sustaining this momentum into 2024. The broadcast also featured a segment on physical and mental well-being as part of the 'Fit India' initiative, with contributions from Sadhguru, Harmanpreet Kaur, Vishwanathan Anand, and Akshay Kumar.

## Dense fog grips Delhi; 23 trains running late
 - [https://timesofindia.indiatimes.com/city/delhi/dense-fog-grips-delhi-23-trains-running-late/articleshow/106415334.cms](https://timesofindia.indiatimes.com/city/delhi/dense-fog-grips-delhi-23-trains-running-late/articleshow/106415334.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T05:38:39+00:00



## Hopeful of 'box office' Pant's successful return in 2024: Nasser Hussain
 - [https://timesofindia.indiatimes.com/sports/cricket/news/hopeful-of-box-office-rishabh-pants-successful-return-in-2024-nasser-hussain/articleshow/106414947.cms](https://timesofindia.indiatimes.com/sports/cricket/news/hopeful-of-box-office-rishabh-pants-successful-return-in-2024-nasser-hussain/articleshow/106414947.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T05:15:53+00:00

Former England captain Nasser Hussain predicts that Rishabh Pant, the cricketer who survived a serious car accident in 2022, will make a successful comeback in 2024. Pant's recovery has been closely followed on social media and he has been seen progressing in the gym and playing cricket. KL Rahul, who replaced Pant during his absence, performed well in the recent ODI World Cup. Hussain also hopes that young opener Shubman Gill will improve in Test cricket and become the next sensation for India in 2024.

## Taapsee: Shah Rukh Khan doesn’t have an intimidating personality
 - [https://timesofindia.indiatimes.com/entertainment/hindi/bollywood/news/taapsee-pannu-srk-doesnt-have-an-intimidating-personality-exclusive/articleshow/106414720.cms](https://timesofindia.indiatimes.com/entertainment/hindi/bollywood/news/taapsee-pannu-srk-doesnt-have-an-intimidating-personality-exclusive/articleshow/106414720.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T04:59:27+00:00

Taapsee Pannu shares her experience working on "Dunki," expressing gratitude for the positive response and calling it a fitting end to the year. She reflects on the initial awe of working with Shah Rukh Khan, describing him as warm and welcoming. Taapsee discusses her changed perspective on romance post her role alongside SRK. She also addresses her unique birthday roast and talks about her upcoming projects, including the sequel to "Haseen Dilruba."

## Watch: Nasser Hussain picks Virat and Babar to have a great 2024
 - [https://timesofindia.indiatimes.com/sports/cricket/news/watch-nasser-hussain-picks-virat-kohli-and-babar-azam-to-have-a-great-2024/articleshow/106414238.cms](https://timesofindia.indiatimes.com/sports/cricket/news/watch-nasser-hussain-picks-virat-kohli-and-babar-azam-to-have-a-great-2024/articleshow/106414238.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T04:16:58+00:00

Former England captain Nasser Hussain selected Indian superstar Virat Kohli and former Pakistani captain Babar Azam as players who will have a fantastic 2024. Hussain praised Kohli's exceptional batting form in 2023 and highlighted his mental space and good order in the game. He emphasized the importance of Babar Azam scoring big for Pakistan in the upcoming ICC T20 World Cup 2024. Babar's relinquishment of captaincy may relieve the weight on his shoulders, allowing him to focus on getting runs. Pakistan's success in the previous T20 World Cup and their need for Babar's outstanding performance were also mentioned.

## Playing through pain, how Neeraj Chopra surged to victories in 2023
 - [https://timesofindia.indiatimes.com/sports/more-sports/athletics/playing-through-pain-how-neeraj-chopra-surged-to-victories-in-2023/articleshow/106413197.cms](https://timesofindia.indiatimes.com/sports/more-sports/athletics/playing-through-pain-how-neeraj-chopra-surged-to-victories-in-2023/articleshow/106413197.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T03:02:50+00:00

Neeraj Chopra's performance in the 2024 Paris Olympics will determine his position among Indian greats. He completed all the necessary tasks to become a champion athlete this year. Neeraj's journey has been filled with preparation, discipline, and hard work. He understands that failure is a setback but also an opportunity for inspiration. Neeraj is not only a champion on the field but also a symbol of peace, voicing his opinion on important issues and supporting fellow athletes. The hunger for Olympic gold pushes him to work harder and achieve more for his country.

## 6 dead in Maha hand glove factory fire, dousing ops under way
 - [https://timesofindia.indiatimes.com/city/aurangabad/six-dead-in-maharashtra-hand-glove-factory-fire-dousing-operation-underway/articleshow/106413116.cms](https://timesofindia.indiatimes.com/city/aurangabad/six-dead-in-maharashtra-hand-glove-factory-fire-dousing-operation-underway/articleshow/106413116.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T02:59:35+00:00



## How Elon Musk’s X is the reason for LinkedIn’s rise in ad revenue
 - [https://timesofindia.indiatimes.com/gadgets-news/how-elon-musks-x-is-the-reason-for-linkedins-rise-in-ad-revenue/articleshow/106409159.cms](https://timesofindia.indiatimes.com/gadgets-news/how-elon-musks-x-is-the-reason-for-linkedins-rise-in-ad-revenue/articleshow/106409159.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T02:38:19+00:00

LinkedIn experiences gold rush in digital advertising as brands flock to the platform, thanks to Elon Musk and Twitter. Ad prices skyrocket as companies pull advertising money from LinkedIn. LinkedIn's ad revenue jumps 10.1% in 2023, reaching nearly $4 billion. Improved targeting capabilities and refined tools attract brands seeking specific audiences. Concerns over ads flashing next to some posts present an opportunity for LinkedIn to capture lost revenue. Ad prices increase as high as 30% in the past year. Brands switch from Twitter to LinkedIn for advertising.

## UP man held for raping minor, trying to convert her to Islam
 - [https://timesofindia.indiatimes.com/city/kanpur/man-held-for-raping-minor-girl-trying-to-convert-her-to-islam/articleshow/106412374.cms](https://timesofindia.indiatimes.com/city/kanpur/man-held-for-raping-minor-girl-trying-to-convert-her-to-islam/articleshow/106412374.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T02:16:05+00:00

A 14-year-old girl in Kanpur accused a 20-year-old Muslim man of kidnapping, raping, and forcibly converting her to Islam. The accused befriended the girl on Instagram and lured her to stay with him. He allegedly forced her to consume non-vegetarian food and offer 'namaz'. The police have registered a case and arrested the accused. The girl was rescued by members of a Hindu outfit. The accused's arrest has been made and investigations are ongoing.

## Man kills mother in fight over drugs, walks to police station
 - [https://timesofindia.indiatimes.com/city/ghaziabad/ghaziabad-man-kills-mother-in-fight-over-drugs-walks-to-police-station/articleshow/106412215.cms](https://timesofindia.indiatimes.com/city/ghaziabad/ghaziabad-man-kills-mother-in-fight-over-drugs-walks-to-police-station/articleshow/106412215.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T01:56:47+00:00

In Ghaziabad's Aman Garden area, a 24-year-old man addicted to drugs killed his mother during a fight over money for drugs. The man, Shahrukh, went to the Loni police station and filed a complaint after murdering his 65-year-old mother, Dilshad Begam. Shahrukh confessed to stabbing his mother multiple times with a dagger knife after she refused to give him money. He then tried to clean up the blood before reporting the incident to the police. Shahrukh, who was currently unemployed, suspected that his mother wanted to sell their house.

## Drainage work in Mysuru unearths 11th century Jain sculptures
 - [https://timesofindia.indiatimes.com/city/mysuru/drainage-work-in-mys-dist-unearths-jain-sculptures/articleshow/106411828.cms](https://timesofindia.indiatimes.com/city/mysuru/drainage-work-in-mys-dist-unearths-jain-sculptures/articleshow/106411828.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-12-31T00:39:17+00:00

Drainage work on Ambedkar Road in Varuna town, Mysuru district, unearthed three Jain sculptures from the 11th century AD. The sculptures, including an idol of goddess Kushmandini Devi and two Jain Tirthankaras, were found at a depth of three feet. The artefacts have been conserved at the city museum for further investigation. Manjula CN, the director of the Karnataka Department of Archaeology, Museums, and Heritage, instructed officials to move the sculptures to the museum for conservation. NS Rangaraju highlighted the need for archaeological excavations in Varuna, Muguru, T Narasipura, Hemmige, and other localities that were once important Jain centers.

