# Source:It's FOSS News, URL:https://news.itsfoss.com/rss/, language:en-US

## 9 Interesting Distros That You May Have Missed in 2023
 - [https://news.itsfoss.com/interesting-distros-missed-in-2023](https://news.itsfoss.com/interesting-distros-missed-in-2023)
 - RSS feed: https://news.itsfoss.com/rss/
 - date published: 2023-12-31T12:48:38+00:00

Did you spot these releases in 2023? What distro surprised you this year?

