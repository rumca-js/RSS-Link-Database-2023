# Source:Moon, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCmFeOdJI3IXgTBDzqBLD8qg, language:en-US

## The Disturbing Rise of iPad Kids
 - [https://www.youtube.com/watch?v=A7seExq02H8](https://www.youtube.com/watch?v=A7seExq02H8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmFeOdJI3IXgTBDzqBLD8qg
 - date published: 2023-12-31T12:11:15+00:00

Moon Newsletter - https://mailchi.mp/3ded12821743/moon

Support the channel here (all money goes straight back into the channel):
►  Become a Patron:  https://www.patreon.com/MoonReal
► Follow my Twitter: https://twitter.com/MoonRealYT

