# Source:E Poznan, URL:https://epoznan.pl/rss, language:pl-PL

## Niemowlę z pękniętą czaszką trafiło do poznańskiego szpitala. Rodzice zatrzymani
 - [https://epoznan.pl/news-news-146494-niemowle_z_peknieta_czaszka_trafilo_do_poznanskiego_szpitala_rodzice_zatrzymani?rss=1](https://epoznan.pl/news-news-146494-niemowle_z_peknieta_czaszka_trafilo_do_poznanskiego_szpitala_rodzice_zatrzymani?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-12-31T17:30:00+00:00

Dwumiesięczną córkę do szpitala przywiozła 19-letnia matka.

## Szukają tego mężczyzny. Rozpoznajesz?
 - [https://epoznan.pl/news-news-146492-szukaja_tego_mezczyzny_rozpoznajesz?rss=1](https://epoznan.pl/news-news-146492-szukaja_tego_mezczyzny_rozpoznajesz?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-12-31T16:00:00+00:00

Sprawa dotyczy kradzieży.

## Sylwester w Poznaniu. Bez rekordów, ale ma być ciepło
 - [https://epoznan.pl/news-news-146488-sylwester_w_poznaniu_bez_rekordow_ale_ma_byc_cieplo?rss=1](https://epoznan.pl/news-news-146488-sylwester_w_poznaniu_bez_rekordow_ale_ma_byc_cieplo?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-12-31T15:45:00+00:00

Sylwestrowa noc ma być w naszym mieście ma być pogodna.

## Libelta/al. Niepodległości: zderzyły się dwa samochody
 - [https://epoznan.pl/news-news-146493-libeltaal_niepodleglosci_zderzyly_sie_dwa_samochody?rss=1](https://epoznan.pl/news-news-146493-libeltaal_niepodleglosci_zderzyly_sie_dwa_samochody?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-12-31T15:40:00+00:00

Kierowcy muszą się liczyć z utrudnieniami.

## Jedne inwestycje się zakończą, kolejne już są planowane. Będą nowe mieszkania komunalne dla poznaniaków!
 - [https://epoznan.pl/news-news-146491-jedne_inwestycje_sie_zakoncza_kolejne_juz_sa_planowane_beda_nowe_mieszkania_komunalne_dla_poznaniakow?rss=1](https://epoznan.pl/news-news-146491-jedne_inwestycje_sie_zakoncza_kolejne_juz_sa_planowane_beda_nowe_mieszkania_komunalne_dla_poznaniakow?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-12-31T15:30:00+00:00

Zarząd Komunalnych Zasobów Lokalowych zapewnia, że sukcesywnie realizuje swoje cele postawione w planie długofalowym.

## Akcja policji na ul. Krzyżowej. Chodziło o petardy
 - [https://epoznan.pl/news-news-146490-akcja_policji_na_ul_krzyzowej_chodzilo_o_petardy?rss=1](https://epoznan.pl/news-news-146490-akcja_policji_na_ul_krzyzowej_chodzilo_o_petardy?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-12-31T15:15:00+00:00

Na miejscu pojawiło się kilka radiowozów.

## 17-latka zaatakowała nożem babcię. &quot;Miała z nią bardzo dobre relacje i często ją odwiedzała&quot;
 - [https://epoznan.pl/news-news-146489-17_latka_zaatakowala_nozem_babcie_miala_z_nia_bardzo_dobre_relacje_i_czesto_ja_odwiedzala?rss=1](https://epoznan.pl/news-news-146489-17_latka_zaatakowala_nozem_babcie_miala_z_nia_bardzo_dobre_relacje_i_czesto_ja_odwiedzala?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-12-31T15:00:00+00:00

Nastolatka została aresztowana.

## Dodatkowe kursy, korekty godzin odjazdów i zmiany! Sporo się zmieni od 1 stycznia w komunikacji autobusowej
 - [https://epoznan.pl/news-news-146487-dodatkowe_kursy_korekty_godzin_odjazdow_i_zmiany_sporo_sie_zmieni_od_1_stycznia_w_komunikacji_autobusowej?rss=1](https://epoznan.pl/news-news-146487-dodatkowe_kursy_korekty_godzin_odjazdow_i_zmiany_sporo_sie_zmieni_od_1_stycznia_w_komunikacji_autobusowej?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-12-31T14:30:00+00:00

Zmiany dotyczą kilku linii.

## Awionetka runęła na ziemię. Są poszkodowani
 - [https://epoznan.pl/news-news-146486-awionetka_runela_na_ziemie_sa_poszkodowani?rss=1](https://epoznan.pl/news-news-146486-awionetka_runela_na_ziemie_sa_poszkodowani?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-12-31T13:45:00+00:00

Do zdarzenia doszło po godzinie 13.

## Z Warty wyłowiono osobę. Trwa reanimacja
 - [https://epoznan.pl/news-news-146485-z_warty_wylowiono_osobe_trwa_reanimacja?rss=1](https://epoznan.pl/news-news-146485-z_warty_wylowiono_osobe_trwa_reanimacja?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-12-31T13:40:00+00:00

Na brzegu zauważono ubrania.

## Najpopularniejsze teksty 2023 roku na epoznan.pl
 - [https://epoznan.pl/news-news-146484-najpopularniejsze_teksty_2023_roku_na_epoznanpl?rss=1](https://epoznan.pl/news-news-146484-najpopularniejsze_teksty_2023_roku_na_epoznanpl?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-12-31T13:30:00+00:00

Oto zestawienie artykułów, które cieszyły się w tym roku największą popularnością wśród naszych Czytelników.

## Od Nowego roku tą kartą nie zapłacisz w parkomacie!
 - [https://epoznan.pl/news-news-146483-od_nowego_roku_ta_karta_nie_zaplacisz_w_parkomacie?rss=1](https://epoznan.pl/news-news-146483-od_nowego_roku_ta_karta_nie_zaplacisz_w_parkomacie?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-12-31T13:00:00+00:00

Wejdą w życie już wcześniej zapowiadane zmiany.

## W 2023 roku te teksty na naszym portalu komentowane były najczęściej
 - [https://epoznan.pl/news-news-146482-w_2023_roku_te_teksty_na_naszym_portalu_komentowane_byly_najczesciej?rss=1](https://epoznan.pl/news-news-146482-w_2023_roku_te_teksty_na_naszym_portalu_komentowane_byly_najczesciej?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-12-31T12:30:00+00:00



## Warszawska: uciekający przed policją kierowca skasował samochód należący do Barki. Jest apel!
 - [https://epoznan.pl/news-news-146481-warszawska_uciekajacy_przed_policja_kierowca_skasowal_samochod_nalezacy_do_barki_jest_apel?rss=1](https://epoznan.pl/news-news-146481-warszawska_uciekajacy_przed_policja_kierowca_skasowal_samochod_nalezacy_do_barki_jest_apel?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-12-31T11:30:00+00:00

Sytuacja miała miejsce w czwartek.

## 14-letni &quot;artysta&quot; przyłapany na dworcu
 - [https://epoznan.pl/news-news-146480-14_letni_artysta_przylapany_na_dworcu?rss=1](https://epoznan.pl/news-news-146480-14_letni_artysta_przylapany_na_dworcu?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-12-31T10:30:00+00:00

Musi liczyć się z konsekwencjami.

## W kilku punktach miasta już od 2 dnia Nowego Roku rozpoczną się prace. Będą utrudnienia!
 - [https://epoznan.pl/news-news-146479-w_kilku_punktach_miasta_juz_od_2_dnia_nowego_roku_rozpoczna_sie_prace_beda_utrudnienia?rss=1](https://epoznan.pl/news-news-146479-w_kilku_punktach_miasta_juz_od_2_dnia_nowego_roku_rozpoczna_sie_prace_beda_utrudnienia?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-12-31T10:00:00+00:00

To remonty chodników.

## Już czwarty raz z rzędu Sylwestra Miejskiego w Poznaniu nie będzie. Można wybrać się na jarmark na pl. Wolności
 - [https://epoznan.pl/news-news-146478-juz_czwarty_raz_z_rzedu_sylwestra_miejskiego_w_poznaniu_nie_bedzie_mozna_wybrac_sie_na_jarmark_na_pl_wolnosci?rss=1](https://epoznan.pl/news-news-146478-juz_czwarty_raz_z_rzedu_sylwestra_miejskiego_w_poznaniu_nie_bedzie_mozna_wybrac_sie_na_jarmark_na_pl_wolnosci?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-12-31T09:33:00+00:00

Powodem są oszczędności.

## Piesza potrącona przez pociąg
 - [https://epoznan.pl/news-news-146477-piesza_potracona_przez_pociag?rss=1](https://epoznan.pl/news-news-146477-piesza_potracona_przez_pociag?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-12-31T09:00:00+00:00

Do zdarzenia doszło w sobotę wieczorem.

## Komunikacja miejska w okresie sylwestrowo- noworocznym. Sporo zmian, warto spojrzeć w rozkład!
 - [https://epoznan.pl/news-news-146475-komunikacja_miejska_w_okresie_sylwestrowo_noworocznym_sporo_zmian_warto_spojrzec_w_rozklad?rss=1](https://epoznan.pl/news-news-146475-komunikacja_miejska_w_okresie_sylwestrowo_noworocznym_sporo_zmian_warto_spojrzec_w_rozklad?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-12-31T08:45:00+00:00

Zarówno w niedziele, jak i w poniedziałek na wszystkich liniach obowiązuje świąteczny rozkład jazdy.

## Trwają poszukiwania dwóch nastolatek. Nie wróciły do domu
 - [https://epoznan.pl/news-news-146476-trwaja_poszukiwania_dwoch_nastolatek_nie_wrocily_do_domu?rss=1](https://epoznan.pl/news-news-146476-trwaja_poszukiwania_dwoch_nastolatek_nie_wrocily_do_domu?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-12-31T08:15:00+00:00

Dziewczyny od wczoraj nie kontaktowały się z bliskimi.

