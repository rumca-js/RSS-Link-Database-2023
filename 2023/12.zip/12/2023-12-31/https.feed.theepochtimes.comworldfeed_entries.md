# Source:Epoch Times - World, URL:https://feed.theepochtimes.com/world/feed, language:en-US

## South Korea’s Capital Records Heaviest Single-Day Snowfall in December for 40 Years
 - [https://www.theepochtimes.com/world/south-koreas-capital-records-heaviest-single-day-snowfall-in-december-for-40-years-5555999](https://www.theepochtimes.com/world/south-koreas-capital-records-heaviest-single-day-snowfall-in-december-for-40-years-5555999)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-31T23:02:27+00:00

Visitors walk through the snow in Goyang, South Korea, on Dec. 30, 2023. (Lee Jin-man/AP Photo)

## New Year Resolutions Could ‘Do More Harm Than Good’
 - [https://www.theepochtimes.com/world/new-year-resolutions-could-do-more-harm-than-good-5556147](https://www.theepochtimes.com/world/new-year-resolutions-could-do-more-harm-than-good-5556147)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-31T22:43:01+00:00

Enjoying outdoor activities with your kids can help build positive long term habits that can keep them healthy years later. (Shutterstock)

## German Officials Detain 3 More Suspects in Connection With Cologne Cathedral Attack Threat
 - [https://www.theepochtimes.com/world/german-officials-detain-3-more-suspects-in-connection-with-cologne-cathedral-attack-threat-5556081](https://www.theepochtimes.com/world/german-officials-detain-3-more-suspects-in-connection-with-cologne-cathedral-attack-threat-5556081)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-31T22:16:10+00:00

A police officer guards the Cologne Cathedral in Cologne, Germany, on Dec. 31, 2023. (Thomas Banneyer/dpa via AP)

## Michael Taube: Gazing Into the Crystal Ball for Canada’s Three Major Party Leaders in 2024
 - [https://www.theepochtimes.com/opinion/michael-taube-gazing-into-the-crystal-ball-for-canadas-three-major-party-leaders-in-2024-post-5556067](https://www.theepochtimes.com/opinion/michael-taube-gazing-into-the-crystal-ball-for-canadas-three-major-party-leaders-in-2024-post-5556067)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-31T21:06:17+00:00

Prime Minister Justin Trudeau shakes hands with NDP Leader Jagmeet Singh as Conservative Leader Pierre Poilievre looks on, at an event in Ottawa on Jan. 30, 2023. (The Canadian Press/Adrian Wyld)

## Denmark’s Queen Margrethe II Announces Surprise Abdication on Live TV
 - [https://www.theepochtimes.com/world/denmarks-queen-margrethe-ii-announces-surprise-abdication-on-live-tv-5556075](https://www.theepochtimes.com/world/denmarks-queen-margrethe-ii-announces-surprise-abdication-on-live-tv-5556075)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-31T20:42:03+00:00

Queen Margrethe II gives a New Year's speech and announces her abdication from Christian IX's Palace, Amalienborg Castle, in Copenhagen on Dec. 31 2023. (Keld Navntoft/Ritzau Scanpix via AP)

## MP Asks Why Man Deported by US for Alleged Terrorism Ties Holds Canadian Permanent Residency
 - [https://www.theepochtimes.com/world/mp-asks-why-man-deported-by-us-for-alleged-terrorism-ties-holds-canadian-permanent-residency-status-5555908](https://www.theepochtimes.com/world/mp-asks-why-man-deported-by-us-for-alleged-terrorism-ties-holds-canadian-permanent-residency-status-5555908)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-31T19:08:55+00:00

A Canada Border Services Agency (CBSA) patch is seen on a CBSA officer’s uniform in Tsawwassen, B.C. on Dec. 16, 2022. (The Canadian Press/Darryl Dyck)

## While Some Montreal Streets Boom, Downtown Is Dotted With Vacant Storefronts
 - [https://www.theepochtimes.com/world/while-some-montreal-streets-boom-downtown-is-dotted-with-vacant-storefronts-5556051](https://www.theepochtimes.com/world/while-some-montreal-streets-boom-downtown-is-dotted-with-vacant-storefronts-5556051)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-31T17:14:55+00:00

Shoppers walk past a boarded up storefront on Ste-Catherine Street in downtown Montreal, on Dec. 19, 2023. (The Canadian Press/Christinne Muschi)

## Israel’s Warfront: US Interests, Iran’s Goals, and Survivor Stories | IRR
 - [https://www.theepochtimes.com/epochtv/israels-warfront-us-interests-irans-goals-and-survivor-stories-irr-5555941](https://www.theepochtimes.com/epochtv/israels-warfront-us-interests-irans-goals-and-survivor-stories-irr-5555941)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-31T15:38:07+00:00



## New Zealand’s Auckland Is the First Major City to Ring in 2024
 - [https://www.theepochtimes.com/world/new-zealands-auckland-is-the-first-major-city-to-ring-in-2024-post-5555968](https://www.theepochtimes.com/world/new-zealands-auckland-is-the-first-major-city-to-ring-in-2024-post-5555968)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-31T13:18:12+00:00

Fireworks burst from the Sky Tower in Auckland, New Zealand, to celebrate the New Year, on Jan. 1, 2024. (Hayden Woodward/New Zealand Herald via AP)

## XL Bully Rules Come Into Force Amid as Ban Looms
 - [https://www.theepochtimes.com/world/xl-bully-rules-come-into-force-amid-as-ban-looms-5555966](https://www.theepochtimes.com/world/xl-bully-rules-come-into-force-amid-as-ban-looms-5555966)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-31T12:44:59+00:00

An XL bully dog in an undated 2023 file image taken in England. (Jacob King/PA)

## Israel’s Warfront: US Interests, Iran’s Goals, and Survivor Stories | IRR
 - [https://www.theepochtimes.com/world/israels-warfront-us-interests-irans-goals-and-survivor-stories-irr-5555941](https://www.theepochtimes.com/world/israels-warfront-us-interests-irans-goals-and-survivor-stories-irr-5555941)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-31T12:43:07+00:00



## Warnings of Further Delays as Eurostar Services Restart
 - [https://www.theepochtimes.com/world/warnings-of-further-delays-as-eurostar-services-restart-5555958](https://www.theepochtimes.com/world/warnings-of-further-delays-as-eurostar-services-restart-5555958)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-31T11:49:07+00:00

Passengers in line at the Eurostar terminal in St Pancras International station, central London on Dec. 31, 2023. (Yui Mok/PA)

## Beyond the Headlines: 10 Best Feel-Good Stories That Shined Amidst the Tragic News of 2023
 - [https://www.theepochtimes.com/traditional-values/beyond-the-headlines-10-best-feel-good-stories-that-shined-amidst-the-tragic-news-of-2023-post-5553126](https://www.theepochtimes.com/traditional-values/beyond-the-headlines-10-best-feel-good-stories-that-shined-amidst-the-tragic-news-of-2023-post-5553126)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-31T11:00:46+00:00

An image designed by The Epoch Times.

## CCP Issues Contradictory Policies on Chinese Gaming Industry, Causing Sharp Stock Market Fluctuations
 - [https://www.theepochtimes.com/china/ccp-issues-contradictory-policies-on-chinese-gaming-industry-causing-sharp-stock-market-fluctuations-5555886](https://www.theepochtimes.com/china/ccp-issues-contradictory-policies-on-chinese-gaming-industry-causing-sharp-stock-market-fluctuations-5555886)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-31T06:16:43+00:00

Students play video games on their phones as they wait at an intersection during rush hour in Beijing, China, on Nov. 15, 2023. (Kevin Frayer/Getty Images)

## LIVE 10:45 AM ET: New Year’s Countdown 2024
 - [https://www.theepochtimes.com/epochtv/new-years-countdown-2024-post-5555903](https://www.theepochtimes.com/epochtv/new-years-countdown-2024-post-5555903)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-31T05:33:33+00:00

(NTD)

## British Actor Tom Wilkinson Dies at 75
 - [https://www.theepochtimes.com/entertainment/british-actor-tom-wilkinson-dies-at-75-post-5555770](https://www.theepochtimes.com/entertainment/british-actor-tom-wilkinson-dies-at-75-post-5555770)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-31T05:33:27+00:00

Tom Wilkinson at Toronto International Film Festival at the Princess of Wales Theatre in Toronto, Canada, on Sept. 11, 2016. (Chris Pizzello/Invision/AP)

## Flash Floods Kill 21 People in South Africa’s Coastal Province of Kwazulu-Natal, Police Say
 - [https://www.theepochtimes.com/world/flash-floods-kill-21-people-in-south-africas-coastal-province-of-kwazulu-natal-police-say-5555820](https://www.theepochtimes.com/world/flash-floods-kill-21-people-in-south-africas-coastal-province-of-kwazulu-natal-police-say-5555820)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-31T04:49:08+00:00

A local holidaymaker uses an umbrella to protect himself against the rain and braves the inclement weather at the South beach during Boxing Day festivities in Durban, on Dec. 26, 2023. (Rajesh Jantilal/AFP via Getty Images)

## 6.5 Magnitude Earthquake Shakes Part of Indonesia’s Papua Region, No Immediate Reports of Casualties
 - [https://www.theepochtimes.com/world/6-5-magnitude-earthquake-shakes-part-of-indonesias-papua-region-no-immediate-reports-of-casualties-5555774](https://www.theepochtimes.com/world/6-5-magnitude-earthquake-shakes-part-of-indonesias-papua-region-no-immediate-reports-of-casualties-5555774)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-31T04:46:32+00:00

A map shows the location of an earthquake that struck Indonesia’s easternmost region of Papua on Dec. 31, 2023. (USGS)

## Hail, Thunderstorms Forecast for New Year’s Eve in NSW and Queensland
 - [https://www.theepochtimes.com/world/hail-thunderstorms-forecast-for-new-years-eve-in-nsw-and-queensland-5555923](https://www.theepochtimes.com/world/hail-thunderstorms-forecast-for-new-years-eve-in-nsw-and-queensland-5555923)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-31T04:20:12+00:00

Two days of storms delivered a month worth of rain and flash flooding to some parts of Queensland. Suburb of Rosslea in Townsville, Australia on Feb. 5, 2019. (Ian Hitchcock/Getty Images)

## Challenging Month for Canadian Food Banks Amid Holidays, Rising Demand
 - [https://www.theepochtimes.com/world/challenging-month-for-canadian-food-banks-amid-holidays-rising-demand-5555921](https://www.theepochtimes.com/world/challenging-month-for-canadian-food-banks-amid-holidays-rising-demand-5555921)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-31T04:15:35+00:00

Boxes of donated food items are shown at the Moisson Montreal food bank in Montreal, Dec. 7, 2019. (The Canadian Press/Graham Hughes)

## Man Restrained on Qantas Flight After Allegedly Attacking Passengers
 - [https://www.theepochtimes.com/world/man-restrained-on-qantas-flight-after-allegedly-attacking-passengers-5555914](https://www.theepochtimes.com/world/man-restrained-on-qantas-flight-after-allegedly-attacking-passengers-5555914)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-31T04:07:54+00:00

The enclosed first class suite aboard the A350, the ultra-long-range Airbus that will fly between Sydney and London beginning in 2025, will have 50 percent more suite space than the A380 and features a 22-inch wide reclining armchair and 80-inch long flat bed. (Qantas/TNS)

## Joint Venture of Arctic Mining Companies Assisting Plane Crash Victims
 - [https://www.theepochtimes.com/world/joint-venture-of-arctic-mining-companies-assisting-plane-crash-victims-5555919](https://www.theepochtimes.com/world/joint-venture-of-arctic-mining-companies-assisting-plane-crash-victims-5555919)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-31T04:00:45+00:00

The Northwest Territories provincial flag flies on a flag pole in Ottawa, on July 6, 2020. (The Canadian Press/Adrian Wyld)

## Bring on the New Year, Aussies Set to Welcome 2024
 - [https://www.theepochtimes.com/world/bring-on-the-new-year-aussies-set-to-welcome-2024-post-5555905](https://www.theepochtimes.com/world/bring-on-the-new-year-aussies-set-to-welcome-2024-post-5555905)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-31T02:46:06+00:00

Fireworks light up the sky over the Sydney Harbour Bridge during New Year's Eve celebrations in Sydney, Australia, on Jan. 1, 2022. (Mark Evans/Getty Images)

## Parts of Australia Set to Swelter Into a New Year
 - [https://www.theepochtimes.com/world/australians-are-ready-to-ignite-in-force-for-2024-post-5555892](https://www.theepochtimes.com/world/australians-are-ready-to-ignite-in-force-for-2024-post-5555892)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-12-31T01:29:55+00:00

Enjoying the sunny beach in Australia and chasing dreams at the age of 30, Yung listens to his inner voice, and living the life he wants is also a kind of success. The photo was taken in Sydney, Australia, in January 2023. (Courtesy of Yung Jai)

