# Source:POLITICO, URL:https://www.politico.eu/feed, language:en-US

## Queen of Denmark announces surprise abdication in New Year’s address
 - [https://www.politico.eu/article/queen-of-denmark-announces-surprise-abdication-in-new-years-address/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/queen-of-denmark-announces-surprise-abdication-in-new-years-address/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-12-31T18:01:44+00:00

Queen Margrethe II, who has reigned for half a century, said she will step down on January 14.

## China’s Xi says reunification with Taiwan ‘inevitable,’ ahead of crucial vote on island
 - [https://www.politico.eu/article/taiwan-china-reunification-inevitable-xi-jinping-election-2024/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/taiwan-china-reunification-inevitable-xi-jinping-election-2024/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-12-31T17:00:38+00:00

In his New Year's address, Chinese leader urged a 'common sense of purpose' by those 'on both sides of the Taiwan Strait.'

## Israel green-lights Cypriot aid plan for Palestinians as military pounds central Gaza
 - [https://www.politico.eu/article/israel-green-lights-cypriot-aid-plan-for-palestinians-as-military-pounds-central-gaza/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/israel-green-lights-cypriot-aid-plan-for-palestinians-as-military-pounds-central-gaza/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-12-31T15:01:19+00:00

French, British, Greek and Dutch ships could carry aid directly to Gaza under new plan.

## Former Albania PM put under house arrest amid corruption probe
 - [https://www.politico.eu/article/sali-berisha-former-albania-pm-corruption-house-arrest/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/sali-berisha-former-albania-pm-corruption-house-arrest/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-12-31T13:25:53+00:00

Sali Berisha is accused of abusing his power when he led Albania over a decade ago.

## US Navy sinks Houthi rebel boats after Red Sea attack on container ship
 - [https://www.politico.eu/article/us-navy-sinks-houthi-rebel-boats-israel-palestine-gaza-war-iran/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/us-navy-sinks-houthi-rebel-boats-israel-palestine-gaza-war-iran/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-12-31T12:21:44+00:00

The incident was the second attack against the vessel in just 24 hours.

## Russia hammers Kharkiv with New Year’s Eve strikes after Ukraine’s attack on border city
 - [https://www.politico.eu/article/kharkiv-russia-ukraine-war-attack/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/kharkiv-russia-ukraine-war-attack/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-12-31T11:43:12+00:00

Sunday's assaults come a day after Moscow accused Kyiv of launching a deadly air attack inside Russia.

## Bulgaria, Romania get official green light for partial entry into Schengen area
 - [https://www.politico.eu/article/bulgaria-romania-schengen-area-green-light-partial-entry/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/bulgaria-romania-schengen-area-green-light-partial-entry/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-12-31T11:11:58+00:00

Controls at sea and air borders with Romania and Bulgaria to be lifted as of March 31.

## Dominic Cummings says Sunak sought ‘secret deal’ for election help
 - [https://www.politico.eu/article/dominic-cummings-held-secret-talks-with-rishi-sunak/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/dominic-cummings-held-secret-talks-with-rishi-sunak/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2023-12-31T09:40:07+00:00

Controversial former Johnson adviser claims Sunak wanted him to ‘work secretly on politics and communication.’

