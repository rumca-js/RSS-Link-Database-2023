# Source:Brodie Robertson, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCld68syR8Wi-GY_n4CaoJGA, language:en-US

## Why Isn't Every Linux Distro Shipping KDE?
 - [https://www.youtube.com/watch?v=VXe2gGpg1cw](https://www.youtube.com/watch?v=VXe2gGpg1cw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCld68syR8Wi-GY_n4CaoJGA
 - date published: 2023-12-31T20:00:09+00:00

When you look at the Linux world it looks very GNOME but KDE does exist and it looks like it's great so why don't more distros just ship KDE instead, well the answer might not be that complex.

==========Support The Channel==========
► Patreon: https://brodierobertson.xyz/patreon
► Paypal: https://brodierobertson.xyz/paypal
► Liberapay: https://brodierobertson.xyz/liberapay
► Amazon USA: https://brodierobertson.xyz/amazonusa

==========Resources==========
RHEL 7 KDE: https://access.redhat.com/documentation/en-us/red_hat_enterprise_linux/7/html/7.9_release_notes/deprecated_functionality
Question 1: https://www.reddit.com/r/kde/comments/cmheub/why_do_so_few_distributions_ship_with_kde_plasma/
Question 2: https://www.reddit.com/r/linux/comments/x8m0bt/why_do_none_of_the_major_distros_have_kde_plasma/
Question 3: https://www.reddit.com/r/kde/comments/akyuns/why_isnt_kde_default_on_more_linux_distros/
Question 4: https://www.reddit.com/r/DistroHopping/comments/uzqvho/why_do_no_distros_fla

