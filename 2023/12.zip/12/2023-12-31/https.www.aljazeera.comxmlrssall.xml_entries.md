# Source:Aljazeera, URL:https://www.aljazeera.com/xml/rss/all.xml, language:en-US

## Ugandan athlete Benjamin Kiplagat found dead in Kenya
 - [https://www.aljazeera.com/news/2023/12/31/ugandan-athlete-benjamin-kiplagat-found-dead-in-kenya?traffic_source=rss](https://www.aljazeera.com/news/2023/12/31/ugandan-athlete-benjamin-kiplagat-found-dead-in-kenya?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-12-31T21:38:07+00:00

Kiplagat&#039;s body was found with a knife wound to his neck, suggesting he was murdered, according to the local police.

## Is the war in Ukraine at a stalemate?
 - [https://www.aljazeera.com/program/inside-story/2023/12/31/is-the-war-in-ukraine-at-a-stalemate-3?traffic_source=rss](https://www.aljazeera.com/program/inside-story/2023/12/31/is-the-war-in-ukraine-at-a-stalemate-3?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-12-31T20:40:41+00:00

Russia&#039;s economy withstands Western sanctions, while US political divisions are worrying Kyiv.

## Photos: New Year 2024 celebrations around the world
 - [https://www.aljazeera.com/gallery/2023/12/31/photos-new-year-2024-celebrations-around-the-world?traffic_source=rss](https://www.aljazeera.com/gallery/2023/12/31/photos-new-year-2024-celebrations-around-the-world?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-12-31T20:27:28+00:00

The celebrations come as ongoing conflicts raise security concerns and lead to muted or cancelled festivities.

## Peace and potato chips: Dreams big and small as 2024 approaches in Gaza
 - [https://www.aljazeera.com/features/longform/2023/12/31/peace-and-potato-chips-dreams-big-and-small-as-2024-approaches-in-gaza?traffic_source=rss](https://www.aljazeera.com/features/longform/2023/12/31/peace-and-potato-chips-dreams-big-and-small-as-2024-approaches-in-gaza?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-12-31T20:23:55+00:00

As the year draws to a close, Al Jazeera talks to five people who have lost everything but hope and prayers.

## Israeli minister reiterates calls for Palestinians to leave Gaza
 - [https://www.aljazeera.com/news/2023/12/31/israeli-minister-reiterates-calls-for-palestinians-to-leave-gaza?traffic_source=rss](https://www.aljazeera.com/news/2023/12/31/israeli-minister-reiterates-calls-for-palestinians-to-leave-gaza?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-12-31T19:34:14+00:00

Israel&#039;s far-right finance minister says Israelis who would replace Palestinians would &#039;make the desert bloom&#039;.

## Denmark’s Queen Margrethe II to abdicate after 52 years on the throne
 - [https://www.aljazeera.com/news/2023/12/31/denmarks-queen-margrethe-ii-to-abdicate-after-52-years-on-the-throne?traffic_source=rss](https://www.aljazeera.com/news/2023/12/31/denmarks-queen-margrethe-ii-to-abdicate-after-52-years-on-the-throne?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-12-31T18:34:06+00:00

The Danish queen announces abdication on January 14 during New Year&#039;s Eve address live on TV.

## Assad forces target crowded market, kill two: Syria’s White Helmets
 - [https://www.aljazeera.com/news/2023/12/31/assad-forces-target-crowded-market-kill-two-syrias-white-helmets?traffic_source=rss](https://www.aljazeera.com/news/2023/12/31/assad-forces-target-crowded-market-kill-two-syrias-white-helmets?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-12-31T18:28:54+00:00

Meanwhile, Israel bombed Aleppo and Neirab, leaving Syrians trapped between two forces raining fire from the sky.

## ‘Outraged’: Brazilian Muslims face growing Islamophobia over Gaza war
 - [https://www.aljazeera.com/news/2023/12/31/outraged-brazilian-muslims-face-growing-islamophobia-over-gaza-war?traffic_source=rss](https://www.aljazeera.com/news/2023/12/31/outraged-brazilian-muslims-face-growing-islamophobia-over-gaza-war?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-12-31T18:12:42+00:00

A survey released last month suggests approximately 60 percent of Brazilian Muslims experienced religious intolerance.

## The displaced Afghans making gruelling journeys to survive
 - [https://www.aljazeera.com/gallery/2023/12/31/the-displaced-afghans-making-gruelling-journeys-to-survive?traffic_source=rss](https://www.aljazeera.com/gallery/2023/12/31/the-displaced-afghans-making-gruelling-journeys-to-survive?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-12-31T17:37:19+00:00

More than 40 years of war, violence and poverty have created one of the world’s most uprooted populations.

## Watching the watchdogs: US media reporting from Gaza
 - [https://www.aljazeera.com/opinions/2023/12/31/watching-the-watchdogs-us-media-reporting-from-gaza?traffic_source=rss](https://www.aljazeera.com/opinions/2023/12/31/watching-the-watchdogs-us-media-reporting-from-gaza?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-12-31T16:53:40+00:00

A recent CNN report from a field hospital in Gaza reveals the power and deficiencies of US TV coverage.

## Head of Sudan’s paramilitary RSF visits Djibouti amid ceasefire efforts
 - [https://www.aljazeera.com/news/2023/12/31/head-of-sudans-paramilitary-rsf-visits-djibouti-amid-ceasefire-efforts?traffic_source=rss](https://www.aljazeera.com/news/2023/12/31/head-of-sudans-paramilitary-rsf-visits-djibouti-amid-ceasefire-efforts?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-12-31T16:43:00+00:00

Hemedti visits Djibouti as East African countries attempt to broker a ceasefire between the RSF and the Sudanese army.

## World starts welcoming the New Year with fireworks and prayers
 - [https://www.aljazeera.com/news/2023/12/31/world-starts-welcoming-the-new-year-with-fireworks-and-prayers?traffic_source=rss](https://www.aljazeera.com/news/2023/12/31/world-starts-welcoming-the-new-year-with-fireworks-and-prayers?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-12-31T15:27:21+00:00

Sydney and Auckland are the first major world cities to celebrate the arrival of 2024.

## Tshisekedi re-elected DRC president in election opposition wanted redone
 - [https://www.aljazeera.com/news/2023/12/31/felix-tshisekedi-re-elected-dr-congo-president-election-commission-says?traffic_source=rss](https://www.aljazeera.com/news/2023/12/31/felix-tshisekedi-re-elected-dr-congo-president-election-commission-says?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-12-31T15:24:51+00:00

Felix Tshisekedi wins a landslide victory to secure a second term in election the opposition has labelled a &#039;farce&#039;.

## A library of the ‘future’: Can it make the world a better place?
 - [https://www.aljazeera.com/features/2023/12/31/the-future-library-a-century-long-prayer-for-humanity-in-books?traffic_source=rss](https://www.aljazeera.com/features/2023/12/31/the-future-library-a-century-long-prayer-for-humanity-in-books?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-12-31T15:04:57+00:00

Each year, a new manuscript will be sealed in the Silent Room in the Future Library in Norway. The goal? Inspire hope.

## Walkout over weapons: British school students battle Gaza protest curbs
 - [https://www.aljazeera.com/features/2023/12/31/walkout-weapon-british-school-students-battle-curbs-on-gaza-war-protests?traffic_source=rss](https://www.aljazeera.com/features/2023/12/31/walkout-weapon-british-school-students-battle-curbs-on-gaza-war-protests?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-12-31T14:20:21+00:00

Luton Sixth Form College suspended its student council after a walkout, amid scrutiny of links to an arms major.

## Renowned Australian journalist John Pilger passes away at 84
 - [https://www.aljazeera.com/news/2023/12/31/renowned-australian-journalist-john-pilger-passes-away-at-84?traffic_source=rss](https://www.aljazeera.com/news/2023/12/31/renowned-australian-journalist-john-pilger-passes-away-at-84?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-12-31T14:14:51+00:00

From Palestine to Cambodia, Pilger worked extensively to expose human suffering caused by imperialist governments.

## I don’t care who wins the US presidential election
 - [https://www.aljazeera.com/opinions/2023/12/31/i-dont-care-who-wins-the-us-presidential-election?traffic_source=rss](https://www.aljazeera.com/opinions/2023/12/31/i-dont-care-who-wins-the-us-presidential-election?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-12-31T13:57:14+00:00

America is bound to cause more death, pain and suffering across the globe – whoever is its president.

## Israel-Hamas war: List of key events, day 86
 - [https://www.aljazeera.com/news/2023/12/31/israel-hamas-war-list-of-key-events-day-86?traffic_source=rss](https://www.aljazeera.com/news/2023/12/31/israel-hamas-war-list-of-key-events-day-86?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-12-31T12:56:12+00:00

At least 100 killed in central Gaza, while night-time raids injure 17 in occupied West Bank - here is the latest.

## Pro-Palestine campaigners call for Gaza ceasefire on New Year’s Eve
 - [https://www.aljazeera.com/news/2023/12/31/pro-palestine-campaigners-call-for-gaza-ceasefire-on-new-years-eve?traffic_source=rss](https://www.aljazeera.com/news/2023/12/31/pro-palestine-campaigners-call-for-gaza-ceasefire-on-new-years-eve?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-12-31T12:13:20+00:00

Activists are asking people to turn the New Year&#039;s countdown in their countries into a countdown for a ceasefire.

## What’s the Philadelphi Corridor border zone that Israel wants to control?
 - [https://www.aljazeera.com/news/2023/12/31/whats-the-philadelphi-corridor-border-zone-that-israel-wants-to-control?traffic_source=rss](https://www.aljazeera.com/news/2023/12/31/whats-the-philadelphi-corridor-border-zone-that-israel-wants-to-control?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-12-31T11:38:15+00:00

Israeli control over the corridor between Gaza and Egypt would mean a de facto full reoccupation of the Gaza Strip.

## US forces sink ‘Houthi’ boats in Red Sea after attack on Maersk vessel
 - [https://www.aljazeera.com/news/2023/12/31/us-forces-sink-houthi-boats-in-red-sea-after-attack-on-maersk-vessel?traffic_source=rss](https://www.aljazeera.com/news/2023/12/31/us-forces-sink-houthi-boats-in-red-sea-after-attack-on-maersk-vessel?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-12-31T11:09:18+00:00

Global shipping giant Maersk is suspending operations in the Red Sea for 48 hours after the attack.

## Au revoir, Sahel: Did 2023 crush France’s influence in Africa?
 - [https://www.aljazeera.com/news/2023/12/31/au-revoir-sahel-did-2023-crush-frances-influence-in-africa?traffic_source=rss](https://www.aljazeera.com/news/2023/12/31/au-revoir-sahel-did-2023-crush-frances-influence-in-africa?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-12-31T10:46:28+00:00

France’s hold on its African allies significantly shrunk in 2023. Here&#039;s a timeline of how that unfolded.

## Israel detains Palestinians in renewed West Bank incursions
 - [https://www.aljazeera.com/news/2023/12/31/israel-detains-palestinians-in-renewed-west-bank-incursions?traffic_source=rss](https://www.aljazeera.com/news/2023/12/31/israel-detains-palestinians-in-renewed-west-bank-incursions?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-12-31T10:33:38+00:00

At least four Palestinians detained and 17 others injured from Israeli drone strikes on Tulkarem.

## Russia targets Ukraine ‘military’ sites in retaliation for Belgorod attack
 - [https://www.aljazeera.com/news/2023/12/31/russia-targets-ukraine-military-sites-in-retaliation-for-belgorod-attack?traffic_source=rss](https://www.aljazeera.com/news/2023/12/31/russia-targets-ukraine-military-sites-in-retaliation-for-belgorod-attack?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-12-31T09:35:54+00:00

Kharkiv, Kyiv and other cities attacked in the latest wave of attacks, while missile alert sounded in Russia&#039;s Belgorod.

## ‘He never hesitated’: Samer Abudaqa – father, friend, fearless photographer
 - [https://www.aljazeera.com/features/2023/12/31/he-never-hesitated-samer-abudaqa-father-friend-fearless-photographer?traffic_source=rss](https://www.aljazeera.com/features/2023/12/31/he-never-hesitated-samer-abudaqa-father-friend-fearless-photographer?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-12-31T09:25:08+00:00

Al Jazeera’s cameraman in Gaza bled to death after being hit during an Israeli air raid; medics could not reach him.

## Israeli bombardment destroyed over 70% of Gaza homes: Media office
 - [https://www.aljazeera.com/news/2023/12/31/israeli-bombardment-destroyed-over-70-of-gaza-homes-media-office?traffic_source=rss](https://www.aljazeera.com/news/2023/12/31/israeli-bombardment-destroyed-over-70-of-gaza-homes-media-office?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-12-31T08:19:15+00:00

Experts say the besieged strip is unrecognisable and its bombing is the most destructive in modern history.

## Heat and fire, rains and drought: How 2023 broke climate records
 - [https://www.aljazeera.com/news/longform/2023/12/31/what-climate-records-were-broken-in-2023?traffic_source=rss](https://www.aljazeera.com/news/longform/2023/12/31/what-climate-records-were-broken-in-2023?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-12-31T07:08:28+00:00

Al Jazeera takes a look at the unparalleled climate events from the past year.

## Nepal court finds former cricket captain Sandeep Lamichhane guilty of rape
 - [https://www.aljazeera.com/sports/2023/12/31/nepal-former-cricket-captain-sandeep-lamichhane-found-guilty-of-rape-court?traffic_source=rss](https://www.aljazeera.com/sports/2023/12/31/nepal-former-cricket-captain-sandeep-lamichhane-found-guilty-of-rape-court?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-12-31T06:34:41+00:00

Court in Nepal finds Lamichhane guilty of raping an 18-year-old woman at a Kathmandu hotel in 2022.

## North Korea to launch 3 new satellites in 2024, as Kim warns war inevitable
 - [https://www.aljazeera.com/news/2023/12/31/north-korea-to-launch-3-new-satellites-in-2024-as-kim-warns-war-inevitable?traffic_source=rss](https://www.aljazeera.com/news/2023/12/31/north-korea-to-launch-3-new-satellites-in-2024-as-kim-warns-war-inevitable?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-12-31T02:43:36+00:00

Kim promises further military modernisation after conducting a record number of weapons tests in 2023.

## Russia-Ukraine war: List of key events, day 676
 - [https://www.aljazeera.com/news/2023/12/31/russia-ukraine-war-list-of-key-events-day-676?traffic_source=rss](https://www.aljazeera.com/news/2023/12/31/russia-ukraine-war-list-of-key-events-day-676?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-12-31T01:21:37+00:00

As the war enters its 676th day, these are the main developments.

## Netanyahu says Gaza-Egypt border zone should be under Israeli control
 - [https://www.aljazeera.com/news/2023/12/31/netanyahu-says-gaza-egypt-border-zone-should-be-under-israeli-control?traffic_source=rss](https://www.aljazeera.com/news/2023/12/31/netanyahu-says-gaza-egypt-border-zone-should-be-under-israeli-control?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-12-31T00:11:41+00:00

The Israeli prime minister also predicts the war in Gaza and on other regional fronts would last many months.

## US appeals court allows California to ban guns in most public places
 - [https://www.aljazeera.com/news/2023/12/31/us-appeals-court-allows-california-to-ban-guns-in-most-public-places?traffic_source=rss](https://www.aljazeera.com/news/2023/12/31/us-appeals-court-allows-california-to-ban-guns-in-most-public-places?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-12-31T00:07:34+00:00

A federal appeals court put on hold judge&#039;s ruling that declared the law, set to take effect in 2024, unconstitutional.

