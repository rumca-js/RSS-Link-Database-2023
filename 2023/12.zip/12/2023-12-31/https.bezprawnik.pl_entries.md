# Source:Bezprawnik, URL:https://bezprawnik.pl, language:pl-PL

## Kolejki na stacjach benzynowych. Gra toczy się o szaloną kwotę - średnio 2 złote
 - [https://bezprawnik.pl/kolejki-na-stacjach-benzynowych-gra-toczy-sie-o-szalona-kwote-srednio-2-zlote](https://bezprawnik.pl/kolejki-na-stacjach-benzynowych-gra-toczy-sie-o-szalona-kwote-srednio-2-zlote)
 - RSS feed: https://bezprawnik.pl
 - date published: 2023-12-31T16:15:00.182179+00:00

Polacy bojąc się wzrostu cen na stacjach paliw masowo wyciągnęli kanistry i ruszyli tankować. Zaoszczędzą kilka złotych.

## Bezprawnik - prawo, biznes, finanse, eCommerce
 - [https://bezprawnik.pl/page/1899](https://bezprawnik.pl/page/1899)
 - RSS feed: https://bezprawnik.pl
 - date published: 2023-12-31T16:14:54.342065+00:00

Najnowsze informacje, opinie i analizy na temat zmian prawa i podatków, prowadzenia biznesu oraz finansów osobistych

## Ogarnijcie się już w tej Biedronce, niedługo nie da się policzyć ceny towaru bez dyplomu z trygonometrii
 - [https://bezprawnik.pl/ogarnijcie-sie-juz-w-tej-biedronce-niedlugo-nie-da-sie-policzyc-ceny-towaru-bez-dyplomu-z-trygonometrii](https://bezprawnik.pl/ogarnijcie-sie-juz-w-tej-biedronce-niedlugo-nie-da-sie-policzyc-ceny-towaru-bez-dyplomu-z-trygonometrii)
 - RSS feed: https://bezprawnik.pl
 - date published: 2023-12-31T13:55:47.537880+00:00

Promocje potrafią być bardziej skomplikowane niż instrukcja, jak samodzielnie złożyć skrzynię biegów. W marketach to niestety standard.

## Zakaz sprzedaży brokatu w Unii Europejskiej
 - [https://bezprawnik.pl/zakaz-sprzedazy-brokatu](https://bezprawnik.pl/zakaz-sprzedazy-brokatu)
 - RSS feed: https://bezprawnik.pl
 - date published: 2023-12-31T13:14:09.338770+00:00

16 października 2023 roku weszły w życie przepisy unijne regulujące użycie mikroplastiku w różnych produktach. To właśnie dlatego tegoroczny sylwester może różnić się od poprzednich. Zakaz obejmuje m.in. zakaz sprzedaży brokatu. Zakaz sprzedaży brokatu Mikroplastik to bardzo małe cząstki plastiku, które mają średnicę mniejszą niż 5 mm. Ze względu na wpływ mikroplastiku na środowisko i […]

## Odpalenie fajerwerków może zostać uznane za znęcanie się nad zwierzętami
 - [https://bezprawnik.pl/odpalenie-fajerwerkow-moze-zostac-uznane-za-znecanie-sie-nad-zwierzetami](https://bezprawnik.pl/odpalenie-fajerwerkow-moze-zostac-uznane-za-znecanie-sie-nad-zwierzetami)
 - RSS feed: https://bezprawnik.pl
 - date published: 2023-12-31T13:13:55.506310+00:00

Odpalenie sztucznych ogni w pobliżu miejsc, gdzie przebywają zwierzęta, może zostać zakwalifikowane jako znęcanie się nad zwierzętami.

## Do kiedy trzeba wykorzystać zaległy urlop?
 - [https://bezprawnik.pl/do-kiedy-trzeba-wykorzystac-zalegly-urlop](https://bezprawnik.pl/do-kiedy-trzeba-wykorzystac-zalegly-urlop)
 - RSS feed: https://bezprawnik.pl
 - date published: 2023-12-31T13:13:39.052721+00:00

Początek roku, to także nowe pule urlopowe. Do kiedy powinniśmy wykorzystać zaległy urlop za 2023 rok

